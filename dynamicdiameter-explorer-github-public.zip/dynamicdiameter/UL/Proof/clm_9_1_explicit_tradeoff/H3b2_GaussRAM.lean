import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Def.def_core_witness_halfspaces
import UL.Def.def_shells_configurations
import UL.Proof.cit_hpj19_thm18.H0
import UL.Proof.clm_9_1_explicit_tradeoff.H3b1_PolyCDF
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H3b2

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1

/-! ### 1. Universal modulo-sampling cardinality bound (`u % sz` over `q_idx`-bit words) -/

private lemma sub_pow_ge_one_sub_mul :
    ∀ (M : ℕ) {x : ℝ}, 0 ≤ x → x ≤ 1 → 1 - (M : ℝ) * x ≤ (1 - x) ^ M
  | 0, _, _, _ => by simp
  | M + 1, x, hx0, hx1 => by
      have ih := sub_pow_ge_one_sub_mul M hx0 hx1
      have hmul : (1 - (M : ℝ) * x) * (1 - x) ≤ (1 - x) ^ (M + 1) := by
        rw [pow_succ]
        exact mul_le_mul_of_nonneg_right ih (by linarith only [hx1])
      have hexp : 1 - ((M + 1 : ℕ) : ℝ) * x ≤ (1 - (M : ℝ) * x) * (1 - x) := by
        have hnn : 0 ≤ (M : ℝ) * (x * x) := by positivity
        push_cast
        linarith only [hnn]
      exact hexp.trans hmul

/-- Converting a uniform sample bound `(1 - δ₁) * sz^M ≤ GoodUnif.card` on `Fin M → Fin sz` into
a fixed-bit modulo-sampling bound on `Fin M → Fin (2 ^ q_idx)` via `u ↦ u % sz`: the modulo-bias
loss is at most `(M * sz : ℝ) * 2^{-q_idx}`. -/
theorem modSample_good_card_ge {M sz q_idx : ℕ} (hsz : 1 ≤ sz)
    (Good : (Fin M → Fin sz) → Prop) [DecidablePred Good]
    {δ₁ : ℝ} (hδ₁ : 0 ≤ δ₁)
    (hunif : (1 - δ₁) * (Fintype.card (Fin M → Fin sz) : ℝ) ≤
      ((Finset.univ.filter Good).card : ℝ)) :
    (1 - δ₁ - ((M * sz : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))) *
        (Fintype.card (Fin M → Fin (2 ^ q_idx)) : ℝ) ≤
      ((Finset.univ.filter (fun u : Fin M → Fin (2 ^ q_idx) =>
        Good (fun j => ⟨(u j).val % sz, Nat.mod_lt _ hsz⟩))).card : ℝ) := by
  classical
  let N2 : ℕ := 2 ^ q_idx
  have hN2_pos : 0 < N2 := Nat.two_pow_pos q_idx
  let Q : ℕ := N2 / sz
  let R : ℕ := N2 % sz
  have hdiv : sz * Q + R = N2 := Nat.div_add_mod N2 sz
  have hR_lt : R < sz := Nat.mod_lt N2 hsz
  by_cases hQ0 : Q = 0
  · cases M with
    | zero =>
      have hcard1 : Fintype.card (Fin 0 → Fin sz) = 1 := by simp
      have hcard2 : Fintype.card (Fin 0 → Fin (2 ^ q_idx)) = 1 := by simp
      rw [hcard1, Nat.cast_one, mul_one] at hunif
      rw [hcard2]
      simp only [Nat.cast_zero, zero_mul, sub_zero, Nat.cast_one, mul_one]
      let f0_sz : Fin 0 → Fin sz := Fin.elim0
      let f0_N2 : Fin 0 → Fin N2 := Fin.elim0
      by_cases hg : Good f0_sz
      · have hfilt : (Finset.univ.filter (fun u : Fin 0 → Fin (2 ^ q_idx) =>
            Good (fun j => ⟨(u j).val % sz, Nat.mod_lt _ hsz⟩))).card = 1 := by
          rw [Finset.card_eq_one]
          refine ⟨f0_N2, Finset.eq_singleton_iff_unique_mem.mpr ⟨?_, fun u _ => Subsingleton.elim u f0_N2⟩⟩
          rw [Finset.mem_filter]
          refine ⟨Finset.mem_univ _, ?_⟩
          have heq_f : (fun j : Fin 0 => (⟨(f0_N2 j).val % sz, Nat.mod_lt _ hsz⟩ : Fin sz)) = f0_sz := by
            ext j; exact Fin.elim0 j
          rwa [heq_f]
        rw [hfilt, Nat.cast_one]
        linarith only [hδ₁]
      · have hempty : (Finset.univ.filter Good).card = 0 := by
          rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
          intro u _
          have hu : u = f0_sz := Subsingleton.elim u f0_sz
          rwa [hu]
        rw [hempty, Nat.cast_zero] at hunif
        exact hunif.trans (Nat.cast_nonneg _)
    | succ m =>
      have hN2_le_sz : (N2 : ℝ) ≤ (sz : ℝ) := by
        rw [hQ0, Nat.mul_zero, zero_add] at hdiv
        have : N2 ≤ sz := by omega
        exact_mod_cast this
      have hge1 : (1 : ℝ) ≤ (((m + 1) * sz : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ)) := by
        have hm1 : (sz : ℝ) ≤ (((m + 1) * sz : ℕ) : ℝ) := by
          have : sz ≤ (m + 1) * sz := Nat.le_mul_of_pos_left sz (Nat.succ_pos m)
          exact_mod_cast this
        have hN2_z : (2 : ℝ) ^ (-(q_idx : ℤ)) = (N2 : ℝ)⁻¹ := by
          dsimp [N2]; rw [zpow_neg, zpow_natCast, Nat.cast_pow, Nat.cast_ofNat]
        rw [hN2_z]
        have hN2_rpos : (0 : ℝ) < (N2 : ℝ) := Nat.cast_pos.mpr hN2_pos
        rw [← div_eq_mul_inv, one_le_div hN2_rpos]
        exact hN2_le_sz.trans hm1
      have hneg : 1 - δ₁ - (((m + 1) * sz : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ)) ≤ 0 := by
        linarith only [hδ₁, hge1]
      exact (mul_nonpos_of_nonpos_of_nonneg hneg (Nat.cast_nonneg _)).trans (Nat.cast_nonneg _)
  · have hszQ_le : sz * Q ≤ N2 := by omega
    let Box1 : Finset (Fin N2) := Finset.univ.filter (fun x : Fin N2 => x.val < sz * Q)
    let fwd1 : Fin sz × Fin Q → Fin N2 := fun rq =>
      ⟨rq.2.val * sz + rq.1.val, by
        have hq := rq.2.isLt; have hr := rq.1.isLt
        have hle : rq.2.val * sz + sz ≤ Q * sz := by
          simpa [Nat.add_mul] using Nat.mul_le_mul_right sz hq
        have hcomm : Q * sz = sz * Q := Nat.mul_comm Q sz
        omega⟩
    have hfiber1 : ∀ r : Fin sz,
        (Box1.filter (fun x : Fin N2 => x.val % sz = r.val)).card = Q := by
      intro r
      have hcardQ : (Finset.univ : Finset (Fin Q)).card = Q := by simp
      rw [← hcardQ]
      symm
      refine Finset.card_bij (fun (q : Fin Q) _ => fwd1 (r, q)) ?_ ?_ ?_
      · intro q _
        simp only [Box1, Finset.mem_filter, Finset.mem_univ, true_and, fwd1]
        refine ⟨?_, ?_⟩
        · have hq := q.isLt; have hr := r.isLt
          have hle : q.val * sz + sz ≤ Q * sz := by
            simpa [Nat.add_mul] using Nat.mul_le_mul_right sz hq
          have hcomm : Q * sz = sz * Q := Nat.mul_comm Q sz
          omega
        · rw [Nat.mul_add_mod_self_right, Nat.mod_eq_of_lt r.isLt]
      · intro q₁ _ q₂ _ heq
        have hval := congrArg Fin.val heq
        dsimp [fwd1] at hval
        have hmul_eq : q₁.val * sz = q₂.val * sz := by omega
        exact Fin.ext (Nat.eq_of_mul_eq_mul_right hsz hmul_eq)
      · intro x hx
        simp only [Box1, Finset.mem_filter, Finset.mem_univ, true_and] at hx
        rcases hx with ⟨hx_lt, hx_mod⟩
        have hq_lt : x.val / sz < Q :=
          (Nat.div_lt_iff_lt_mul hsz).mpr (by rw [Nat.mul_comm]; exact hx_lt)
        refine ⟨⟨x.val / sz, hq_lt⟩, Finset.mem_univ _, ?_⟩
        ext; dsimp [fwd1]
        have hdm := Nat.div_add_mod x.val sz
        rw [Nat.mul_comm sz (x.val / sz), hx_mod] at hdm
        exact hdm
    let proj : (Fin M → Fin N2) → (Fin M → Fin sz) :=
      fun u j => ⟨(u j).val % sz, Nat.mod_lt _ hsz⟩
    let GoodUnif := Finset.univ.filter Good
    let GoodMod := Finset.univ.filter (fun u : Fin M → Fin N2 => Good (proj u))
    have hfiberM : ∀ ω ∈ GoodUnif,
        Q ^ M ≤ (GoodMod.filter (fun u => proj u = ω)).card := by
      intro ω hω
      have hω_good : Good ω := (Finset.mem_filter.mp hω).2
      let Fib : Finset (Fin M → Fin N2) :=
        Fintype.piFinset (fun j : Fin M => Box1.filter (fun x : Fin N2 => x.val % sz = (ω j).val))
      have hFib_card : Fib.card = Q ^ M := by
        rw [Fintype.card_piFinset]
        simp_rw [hfiber1]
        simp
      rw [← hFib_card]
      refine Finset.card_le_card fun u hu => ?_
      rw [Fintype.mem_piFinset] at hu
      have hproj_eq : proj u = ω := by
        ext j
        exact (Finset.mem_filter.mp (hu j)).2
      exact Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, by rwa [hproj_eq]⟩, hproj_eq⟩
    have hMod_ge : GoodUnif.card * Q ^ M ≤ GoodMod.card := by
      calc GoodUnif.card * Q ^ M
          = ∑ _ω ∈ GoodUnif, Q ^ M := by rw [Finset.sum_const, smul_eq_mul]
        _ ≤ ∑ ω ∈ GoodUnif, (GoodMod.filter (fun u => proj u = ω)).card :=
            Finset.sum_le_sum hfiberM
        _ ≤ ∑ ω ∈ Finset.univ, (GoodMod.filter (fun u => proj u = ω)).card :=
            Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun _ _ _ => Nat.zero_le _)
        _ = GoodMod.card := (Finset.card_eq_sum_card_fiberwise (fun u _ => Finset.mem_univ (proj u))).symm
    have hcard_sz : (Fintype.card (Fin M → Fin sz) : ℝ) = (sz : ℝ) ^ M := by
      simp [Fintype.card_fun]
    have hcard_N2 : (Fintype.card (Fin M → Fin N2) : ℝ) = (N2 : ℝ) ^ M := by
      simp [Fintype.card_fun]
    rw [hcard_sz] at hunif
    rw [hcard_N2]
    have hMod_real : (1 - δ₁) * ((sz : ℝ) * (Q : ℝ)) ^ M ≤ (GoodMod.card : ℝ) := by
      calc (1 - δ₁) * ((sz : ℝ) * (Q : ℝ)) ^ M
          = ((1 - δ₁) * (sz : ℝ) ^ M) * (Q : ℝ) ^ M := by rw [mul_pow]; ring
        _ ≤ (GoodUnif.card : ℝ) * (Q : ℝ) ^ M :=
            mul_le_mul_of_nonneg_right hunif (by positivity)
        _ ≤ (GoodMod.card : ℝ) := by exact_mod_cast hMod_ge
    have hN2_rpos : (0 : ℝ) < (N2 : ℝ) := Nat.cast_pos.mpr hN2_pos
    let x_err : ℝ := (R : ℝ) / (N2 : ℝ)
    have hx0 : 0 ≤ x_err := by positivity
    have hx1 : x_err ≤ 1 := by
      dsimp [x_err]; rw [div_le_one hN2_rpos]
      have : R ≤ N2 := by omega
      exact_mod_cast this
    have hratio : ((sz : ℝ) * (Q : ℝ)) / (N2 : ℝ) = 1 - x_err := by
      dsimp [x_err]
      have hdiv_r : (sz : ℝ) * (Q : ℝ) + (R : ℝ) = (N2 : ℝ) := by exact_mod_cast hdiv
      field_simp [hN2_rpos.ne']
      linarith only [hdiv_r]
    have hpow_ge : (1 - (M : ℝ) * x_err) * (N2 : ℝ) ^ M ≤ ((sz : ℝ) * (Q : ℝ)) ^ M := by
      have h1 := sub_pow_ge_one_sub_mul M hx0 hx1
      rw [← hratio, div_pow] at h1
      exact (le_div_iff₀ (pow_pos hN2_rpos M)).mp h1
    have hx_le_sz : (M : ℝ) * x_err ≤ ((M * sz : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ)) := by
      dsimp [x_err, N2]
      rw [div_eq_mul_inv, ← mul_assoc, zpow_neg, zpow_natCast, Nat.cast_pow, Nat.cast_ofNat]
      refine mul_le_mul_of_nonneg_right ?_ (by positivity)
      push_cast
      exact mul_le_mul_of_nonneg_left (by exact_mod_cast hR_lt.le) (Nat.cast_nonneg M)
    by_cases hδ1_ge1 : 1 ≤ δ₁
    · have hneg : 1 - δ₁ - ((M * sz : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ)) ≤ 0 := by
        have hnn : (0 : ℝ) ≤ ((M * sz : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ)) := by positivity
        linarith only [hδ1_ge1, hnn]
      exact (mul_nonpos_of_nonpos_of_nonneg hneg (by positivity)).trans (Nat.cast_nonneg _)
    · push_neg at hδ1_ge1
      have h1mδ : 0 ≤ 1 - δ₁ := by linarith only [hδ1_ge1]
      have hprod_lb :
          (1 - δ₁ - ((M * sz : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) ≤
            (1 - δ₁) * (1 - (M : ℝ) * x_err) := by
        have h1 : 1 - δ₁ - (M : ℝ) * x_err ≤ (1 - δ₁) * (1 - (M : ℝ) * x_err) := by
          have hnn : 0 ≤ δ₁ * ((M : ℝ) * x_err) := mul_nonneg hδ₁ (mul_nonneg (Nat.cast_nonneg M) hx0)
          linarith only [hnn]
        linarith only [h1, hx_le_sz]
      calc (1 - δ₁ - ((M * sz : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) * (N2 : ℝ) ^ M
          ≤ ((1 - δ₁) * (1 - (M : ℝ) * x_err)) * (N2 : ℝ) ^ M :=
            mul_le_mul_of_nonneg_right hprod_lb (by positivity)
        _ = (1 - δ₁) * ((1 - (M : ℝ) * x_err) * (N2 : ℝ) ^ M) := by ring
        _ ≤ (1 - δ₁) * ((sz : ℝ) * (Q : ℝ)) ^ M :=
            mul_le_mul_of_nonneg_left hpow_ge h1mδ
        _ ≤ (GoodMod.card : ℝ) := hMod_real

/-! ### 2. `PreservesNonScratch` and `ExecScratch` Hoare combinators -/

def PreservesNonScratch (scrW scrR : ℕ) (m₀ m₁ : ArithRAMMemory) : Prop :=
  (∀ t, t ≠ scrW → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
  (∀ t, t ≠ scrR → ∀ i, rRead m₁ t i = rRead m₀ t i)

theorem PreservesNonScratch.refl (scrW scrR : ℕ) (m : ArithRAMMemory) :
    PreservesNonScratch scrW scrR m m :=
  ⟨fun _ _ _ => rfl, fun _ _ _ => rfl⟩

theorem PreservesNonScratch.trans {scrW scrR : ℕ} {m₀ m₁ m₂ : ArithRAMMemory}
    (h₁ : PreservesNonScratch scrW scrR m₀ m₁)
    (h₂ : PreservesNonScratch scrW scrR m₁ m₂) :
    PreservesNonScratch scrW scrR m₀ m₂ :=
  ⟨fun t ht i => (h₂.1 t ht i).trans (h₁.1 t ht i),
   fun t ht i => (h₂.2 t ht i).trans (h₁.2 t ht i)⟩

theorem PreservesNonScratch.wWrite_scr (scrW scrR : ℕ) (m : ArithRAMMemory) (idx val : ℤ) :
    PreservesNonScratch scrW scrR m (H3a.wWrite m scrW idx val) :=
  ⟨fun t ht i => wRead_wWrite_of_ne m val (Or.inl ht),
   fun t _ i => rRead_wWrite m t scrW i idx val⟩

theorem PreservesNonScratch.rWrite_scr (scrW scrR : ℕ) (m : ArithRAMMemory) (idx : ℤ) (val : ℝ) :
    PreservesNonScratch scrW scrR m (H3a.rWrite m scrR idx val) :=
  ⟨fun t _ i => wRead_rWrite m t scrR i idx val,
   fun t ht i => rRead_rWrite_of_ne m val (Or.inl ht)⟩

def ExecScratch {d : ℕ} (TW BW TR BR scrW scrR : ℕ) (inp : ArithRAMInput d) (s : ArithRAMStmt)
    (m₀ : ArithRAMMemory) (Post : ArithRAMMemory → Prop) (C : ℕ) : Prop :=
  ExecDet TW BW TR BR inp s m₀ (fun m₁ => PreservesNonScratch scrW scrR m₀ m₁ ∧ Post m₁) C

theorem ExecScratch.mono {d : ℕ} {TW BW TR BR scrW scrR : ℕ} {inp : ArithRAMInput d}
    {s : ArithRAMStmt} {m₀ : ArithRAMMemory} {P Q : ArithRAMMemory → Prop} {C C' : ℕ}
    (h : ExecScratch TW BW TR BR scrW scrR inp s m₀ P C)
    (hPQ : ∀ m₁, PreservesNonScratch scrW scrR m₀ m₁ → P m₁ → InFootprint TW BW TR BR m₁ → Q m₁)
    (hC : C ≤ C') :
    ExecScratch TW BW TR BR scrW scrR inp s m₀ Q C' :=
  ExecDet.mono h (fun m₁ ⟨hpr, hp⟩ hfp => ⟨hpr, hPQ m₁ hpr hp hfp⟩) hC

theorem ExecScratch.skip {d : ℕ} {TW BW TR BR scrW scrR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} {Post : ArithRAMMemory → Prop} {C : ℕ}
    (hfp : InFootprint TW BW TR BR m₀) (hP : Post m₀) (hC : 1 ≤ C) :
    ExecScratch TW BW TR BR scrW scrR inp .skip m₀ Post C :=
  ExecDet.skip inp hfp ⟨PreservesNonScratch.refl scrW scrR m₀, hP⟩ hC

theorem ExecScratch.seq {d : ℕ} {TW BW TR BR scrW scrR : ℕ} {inp : ArithRAMInput d}
    {s₁ s₂ : ArithRAMStmt} {m₀ : ArithRAMMemory} {Mid Post : ArithRAMMemory → Prop} {C₁ C₂ : ℕ}
    (h₁ : ExecScratch TW BW TR BR scrW scrR inp s₁ m₀ Mid C₁)
    (h₂ : ∀ m₁, PreservesNonScratch scrW scrR m₀ m₁ → Mid m₁ → InFootprint TW BW TR BR m₁ →
      ExecScratch TW BW TR BR scrW scrR inp s₂ m₁ Post C₂) :
    ExecScratch TW BW TR BR scrW scrR inp (.seq s₁ s₂) m₀ Post (C₁ + C₂) := by
  refine ExecDet.seq h₁ (fun m₁ ⟨hpr₁, hmid⟩ hfp₁ => ?_)
  exact ExecDet.mono (h₂ m₁ hpr₁ hmid hfp₁)
    (fun m₂ ⟨hpr₂, hpost⟩ _ => ⟨hpr₁.trans hpr₂, hpost⟩) le_rfl

theorem ExecScratch.seq' {d : ℕ} {TW BW TR BR scrW scrR : ℕ} {inp : ArithRAMInput d}
    {s₁ s₂ : ArithRAMStmt} {m₀ : ArithRAMMemory} {Mid Post : ArithRAMMemory → Prop}
    (C₂ : ℕ) {C : ℕ}
    (h₁ : ExecScratch TW BW TR BR scrW scrR inp s₁ m₀ Mid (C - C₂))
    (hC : C₂ ≤ C)
    (h₂ : ∀ m₁, PreservesNonScratch scrW scrR m₀ m₁ → Mid m₁ → InFootprint TW BW TR BR m₁ →
      ExecScratch TW BW TR BR scrW scrR inp s₂ m₁ Post C₂) :
    ExecScratch TW BW TR BR scrW scrR inp (.seq s₁ s₂) m₀ Post C :=
  (h₁.seq h₂).mono (fun _ _ hp _ => hp) (by omega)

theorem ExecScratch.wSetScr {d : ℕ} {TW BW TR BR scrW scrR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (idxE valE : IntExpr) (idx val : ℤ)
    {Post : ArithRAMMemory → Prop} {C : ℕ}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbl : scrW < TW) (hi0 : 0 ≤ idx) (hiB : idx < (BW : ℤ))
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hval : (evalIntExpr inp.toWordView 0 m₀.words valE).1 = val)
    (hcost : intExprOps idxE + intExprOps valE + 1 ≤ C)
    (hPost : Post (H3a.wWrite m₀ scrW idx val)) :
    ExecScratch TW BW TR BR scrW scrR inp (.writeWordHeap scrW idxE valE) m₀ Post C :=
  ExecDet.wWrite inp scrW idxE valE idx val hfp₀ htbl hi0 hiB hidx hval hcost
    ⟨PreservesNonScratch.wWrite_scr scrW scrR m₀ idx val, hPost⟩

theorem ExecScratch.rSetScr {d : ℕ} {TW BW TR BR scrW scrR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (idxE : IntExpr) (valE : RealExpr) (idx : ℤ) (val : ℝ)
    {Post : ArithRAMMemory → Prop} {C : ℕ}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbl : scrR < TR) (hi0 : 0 ≤ idx) (hiB : idx < (BR : ℤ))
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hval : (evalRealExpr inp 0 m₀ valE).1 = val)
    (hcost : intExprOps idxE + realExprOps valE + 1 ≤ C)
    (hPost : Post (H3a.rWrite m₀ scrR idx val)) :
    ExecScratch TW BW TR BR scrW scrR inp (.writeRealHeap scrR idxE valE) m₀ Post C :=
  ExecDet.rWrite inp scrR idxE valE idx val hfp₀ htbl hi0 hiB hidx hval hcost
    ⟨PreservesNonScratch.rWrite_scr scrW scrR m₀ idx val, hPost⟩

theorem ExecScratch.ite {d : ℕ} {TW BW TR BR scrW scrR : ℕ} {inp : ArithRAMInput d}
    (cond : ArithCondExpr) (tB fB : ArithRAMStmt)
    {m₀ : ArithRAMMemory} {Post : ArithRAMMemory → Prop} {C_c C_b : ℕ}
    (huc : condExprOps cond ≤ C_c)
    (ht : (evalArithCond inp 0 m₀ cond).1 = true →
      ExecScratch TW BW TR BR scrW scrR inp tB m₀ Post C_b)
    (hf : (evalArithCond inp 0 m₀ cond).1 = false →
      ExecScratch TW BW TR BR scrW scrR inp fB m₀ Post C_b) :
    ExecScratch TW BW TR BR scrW scrR inp (.ite cond tB fB) m₀ Post (C_c + C_b) :=
  ExecDet.ite cond tB fB huc ht hf

theorem ExecScratch.forLoop {d : ℕ} {TW BW TR BR scrW scrR : ℕ} {inp : ArithRAMInput d}
    (ctrIdx : ℤ) (N : ℕ) (body : ArithRAMStmt)
    {m₀ : ArithRAMMemory} (Inv : ℕ → ArithRAMMemory → Prop) (C_b : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hctrT : scrW < TW) (hctr0 : 0 ≤ ctrIdx) (hctrB : ctrIdx < (BW : ℤ))
    (hInv₀ : Inv 0 (H3a.wWrite m₀ scrW ctrIdx 0))
    (hbody : ∀ i < N, ∀ m, PreservesNonScratch scrW scrR m₀ m →
      Inv i m → wRead m scrW ctrIdx = (i : ℤ) → InFootprint TW BW TR BR m →
      ExecScratch TW BW TR BR scrW scrR inp body m
        (fun m' => wRead m' scrW ctrIdx = (i : ℤ) ∧ Inv (i + 1) m') C_b)
    (hInv_ctr : ∀ k m v, Inv k m → Inv k (H3a.wWrite m scrW ctrIdx v) := by
      intro _ _ _ h
      simp only [rRead_wWrite] at h ⊢
      try exact h
      try (rcases h with ⟨h1, h2⟩; exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1, h2⟩)
      try (rcases h with ⟨h1, h2, h3, h4⟩; exact
        ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1,
         by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h2,
         by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h3, h4⟩)
      try (rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h)) :
    ExecScratch TW BW TR BR scrW scrR inp (forLoopStmt scrW ctrIdx N body) m₀
      (Inv N) (10 + N * (C_b + 8)) := by
  have hcost_le : 4 + (1 + N * (C_b + 6)) ≤ 10 + N * (C_b + 8) := by
    have hmul : N * (C_b + 6) ≤ N * (C_b + 8) := Nat.mul_le_mul_left N (by omega)
    omega
  refine (ExecDet.forLoop scrW ctrIdx N body
    (fun i m => PreservesNonScratch scrW scrR m₀ m ∧ Inv i m) C_b
    hfp₀ hctrT hctr0 hctrB ⟨PreservesNonScratch.wWrite_scr scrW scrR m₀ ctrIdx 0, hInv₀⟩ ?_).mono
    (fun _ h _ => h) hcost_le
  intro i hi m ⟨hpr, hI⟩ hctr hfp
  refine ExecDet.mono (hbody i hi m hpr hI hctr hfp) ?_ le_rfl
  intro m' ⟨hpr', hctr', hI'⟩ _
  exact ⟨hctr',
    (hpr.trans hpr').trans (PreservesNonScratch.wWrite_scr scrW scrR m' ctrIdx ((i : ℤ) + 1)),
    hInv_ctr (i + 1) m' ((i : ℤ) + 1) hI'⟩

private lemma mem_words_read_heap (m : ArithRAMMemory) (t : ℕ) (i : ℤ) :
    m.words.read (.heap t i) = wRead m t i := rfl

private lemma mem_reals_read_heap (m : ArithRAMMemory) (t : ℕ) (i : ℤ) :
    m.reals.read (.heap t i) = rRead m t i := rfl

/-! ### 3. Subroutine 1: `decodeBitsStmt` (MSB-first `q`-bit decoding from coin array) -/

def decodeBitsStmt (scrW tblCoins : ℕ) (regCtr dstReg : ℤ) (baseOffE : IntExpr) (q : ℕ) :
    ArithRAMStmt :=
  .seq (.writeWordHeap scrW (.lit dstReg) (.lit 0))
    (forLoopStmt scrW regCtr q
      (.writeWordHeap scrW (.lit dstReg)
        (.add (.mul (.lit 2) (.readHeap scrW (.lit dstReg)))
              (.readHeap tblCoins (.add baseOffE (.readHeap scrW (.lit regCtr)))))))

private lemma bitsFnToNat_prefix_step {q : ℕ} (f : Fin q → Bool) :
    ∀ (k : ℕ) (hk : k ≤ q),
      (Nat.recOn k 0 (fun i acc =>
        if hi : i < q then 2 * acc + (if f ⟨i, hi⟩ then 1 else 0) else acc) : ℕ) =
      bitsFnToNat k (fun j : Fin k => f ⟨j.val, lt_of_lt_of_le j.isLt hk⟩)
  | 0, _ => by simp [bitsFnToNat]
  | k + 1, hk => by
      have hk_lt : k < q := by omega
      have ih := bitsFnToNat_prefix_step f k (by omega)
      change (if hi : k < q then 2 * _ + (if f ⟨k, hi⟩ then 1 else 0) else _) = _
      dsimp [Nat.recOn] at ih
      rw [dif_pos hk_lt, ih]
      rfl

theorem exec_decodeBitsStmt {d : ℕ} {TW BW TR BR scrW scrR tblCoins : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (regCtr dstReg baseOff : ℤ) (q : ℕ) (bits : Fin q → Bool)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hneTbl : tblCoins ≠ scrW)
    (hreg_ne : regCtr ≠ dstReg)
    (hctr0 : 0 ≤ regCtr) (hctrB : regCtr < (BW : ℤ))
    (hdst0 : 0 ≤ dstReg) (hdstB : dstReg < (BW : ℤ))
    (hcoins : ∀ j : Fin q, wRead m₀ tblCoins (baseOff + (j.val : ℤ)) = if bits j then 1 else 0) :
    ExecScratch TW BW TR BR scrW scrR inp
      (decodeBitsStmt scrW tblCoins regCtr dstReg (.lit baseOff) q) m₀
      (fun m₁ => wRead m₁ scrW dstReg = ((bitsFnToFin q bits).val : ℤ))
      (20 + 20 * q) := by
  let pfx : ℕ → ℕ := fun k =>
    Nat.recOn k (0 : ℕ) (fun i acc =>
      if hi : i < q then 2 * acc + (if bits ⟨i, hi⟩ then (1 : ℕ) else 0) else acc)
  unfold decodeBitsStmt
  refine ExecScratch.seq' (10 + q * (12 + 8))
    (ExecScratch.wSetScr inp (.lit dstReg) (.lit 0) dstReg 0 hfp₀ hscrW hdst0 hdstB rfl rfl
      (by dsimp [intExprOps]; omega)
      (Post := fun mx_p => wRead mx_p scrW dstReg = 0) (wRead_wWrite_self _ _ _ _))
    (by omega)
    (fun m₁ hpr₁ hd₀ hfp₁ => ?_)
  refine (ExecScratch.forLoop regCtr q _
    (Inv := fun i m => wRead m scrW dstReg = Int.ofNat (pfx i)) 12
    hfp₁ hscrW hctr0 hctrB
    (by dsimp only; rw [wRead_wWrite_of_ne _ _ (Or.inr hreg_ne.symm), hd₀]; rfl) ?_
    (by intro _ _ _ h; rw [wRead_wWrite_of_ne _ _ (Or.inr hreg_ne.symm)]; exact h)).mono
    (fun m₂ _ hIN _ => by
      rw [hIN]
      have hfinal := bitsFnToNat_prefix_step bits q le_rfl
      exact congrArg Int.ofNat hfinal)
    le_rfl
  intro i hi m hpr_m hI hctr hfp_m
  have hpr_tot : PreservesNonScratch scrW scrR m₀ m := hpr₁.trans hpr_m
  have hbit_val : wRead m tblCoins (baseOff + (i : ℤ)) = if bits ⟨i, hi⟩ then 1 else 0 := by
    rw [hpr_tot.1 tblCoins hneTbl]
    exact hcoins ⟨i, hi⟩
  refine ExecScratch.wSetScr inp (.lit dstReg) _ dstReg
    (2 * Int.ofNat (pfx i) + (if bits ⟨i, hi⟩ then 1 else 0))
    hfp_m hscrW hdst0 hdstB rfl
    (by
      change 2 * wRead m scrW dstReg + wRead m tblCoins (baseOff + wRead m scrW regCtr) = _
      rw [hI, hctr, hbit_val])
    (by dsimp [intExprOps]; omega)
    ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr hreg_ne)]; exact hctr, ?_⟩
  dsimp only
  rw [wRead_wWrite_self]
  have hpfx_step : pfx (i + 1) = 2 * pfx i + (if bits ⟨i, hi⟩ then 1 else 0) := by
    change (if h : i < q then 2 * pfx i + (if bits ⟨i, h⟩ then 1 else 0) else pfx i) = _
    rw [dif_pos hi]
  rw [hpfx_step]; cases bits ⟨i, hi⟩ <;> (simp only [Int.ofNat_eq_coe]; push_cast; ring)

/-! ### 4. Subroutine 2: `polyQuantileStmt` (`polySample1D b T p_coord`) -/

def ratExpr (q : ℚ) : RealExpr :=
  .div (.ofInt (.lit q.num)) (.ofInt (.lit (q.den : ℤ)))

theorem evalRealExpr_ratExpr {d : ℕ} (inp : ArithRAMInput d) (fd : ℕ) (mem : ArithRAMMemory)
    (q : ℚ) :
    (evalRealExpr inp fd mem (ratExpr q)).1 = (q : ℝ) := by
  simp only [ratExpr, evalRealExpr, evalIntExpr]
  rw [Rat.cast_def]; push_cast; rfl

theorem realExprOps_ratExpr (q : ℚ) : realExprOps (ratExpr q) = 5 := rfl

private noncomputable def gaussRecTerm (y : ℝ) : ℕ → ℝ
  | 0 => y
  | m + 1 => gaussRecTerm y m * (-(y * y / 2)) / ((m + 1 : ℕ) : ℝ)

private lemma gaussRecTerm_eq (y : ℝ) :
    ∀ m : ℕ, gaussRecTerm y m = ((-(1 / 2 : ℝ)) ^ m / (m.factorial : ℝ)) * y ^ (2 * m + 1)
  | 0 => by simp [gaussRecTerm]
  | m + 1 => by
      rw [gaussRecTerm, gaussRecTerm_eq y m, Nat.factorial_succ, Nat.cast_mul]
      have hfac : (m.factorial : ℝ) ≠ 0 := by positivity
      have hm1 : (((m + 1 : ℕ) : ℝ)) ≠ 0 := by positivity
      have hpow : y ^ (2 * (m + 1) + 1) = y ^ (2 * m + 1) * (y * y) := by
        have : 2 * (m + 1) + 1 = (2 * m + 1) + 2 := by omega
        rw [this, pow_add, sq]
      rw [hpow, pow_succ]
      field_simp [hfac, hm1]
      ring

private lemma gaussIntPoly_succ (K : ℕ) (y : ℝ) :
    gaussIntPoly (K + 1) y =
      gaussIntPoly K y + gaussRecTerm y K / ((2 * K + 1 : ℕ) : ℝ) := by
  unfold gaussIntPoly
  rw [Finset.sum_range_succ, gaussRecTerm_eq y K]
  congr 1
  push_cast
  have hfac : (K.factorial : ℝ) ≠ 0 := by positivity
  have h2K : (2 * (K : ℝ) + 1) ≠ 0 := by positivity
  field_simp [hfac, h2K]

def gaussIntPolyStmt (scrW scrR : ℕ) (wCtr rY rTerm rAcc : ℤ) (K : ℕ) : ArithRAMStmt :=
  .seq (.writeRealHeap scrR (.lit rAcc) (.ofInt (.lit 0)))
    (.seq (.writeRealHeap scrR (.lit rTerm) (.readRealHeap scrR (.lit rY)))
      (forLoopStmt scrW wCtr K
        (.seq
          (.writeRealHeap scrR (.lit rAcc)
            (.add (.readRealHeap scrR (.lit rAcc))
              (.div (.readRealHeap scrR (.lit rTerm))
                (.ofInt (.add (.mul (.lit 2) (.readHeap scrW (.lit wCtr))) (.lit 1))))))
          (.writeRealHeap scrR (.lit rTerm)
            (.div
              (.mul (.readRealHeap scrR (.lit rTerm))
                (.neg (.div (.mul (.readRealHeap scrR (.lit rY)) (.readRealHeap scrR (.lit rY)))
                            (.ofInt (.lit 2)))))
              (.ofInt (.add (.readHeap scrW (.lit wCtr)) (.lit 1))))))))

def polyCDFStmt (scrW scrR : ℕ) (wCtr rX rY rTerm rAcc rOut : ℤ) (K : ℕ) (c_pi : ℚ) :
    ArithRAMStmt :=
  .ite (.realLe (.ofInt (.lit 0)) (.readRealHeap scrR (.lit rX)))
    (.seq (.writeRealHeap scrR (.lit rY) (.readRealHeap scrR (.lit rX)))
      (.seq (gaussIntPolyStmt scrW scrR wCtr rY rTerm rAcc K)
        (.writeRealHeap scrR (.lit rOut)
          (.add (ratExpr (1 / 2)) (.mul (ratExpr c_pi) (.readRealHeap scrR (.lit rAcc)))))))
    (.seq (.writeRealHeap scrR (.lit rY) (.neg (.readRealHeap scrR (.lit rX))))
      (.seq (gaussIntPolyStmt scrW scrR wCtr rY rTerm rAcc K)
        (.writeRealHeap scrR (.lit rOut)
          (.sub (ratExpr (1 / 2)) (.mul (ratExpr c_pi) (.readRealHeap scrR (.lit rAcc)))))))

noncomputable def polyQuantileStmt (scrW scrR : ℕ) (wK wBase rBase rOut : ℤ) (b T p_coord : ℕ) :
    ArithRAMStmt :=
  let K := cdfDegree T b
  let c_pi := cPiRat (cdfPiBits T b)
  let S_bis := T + p_coord + 6
  let wCtr := wBase
  let wBis := wBase + 1
  let rLo := rBase
  let rHi := rBase + 1
  let rMid := rBase + 2
  let rPtgt := rBase + 3
  let rY := rBase + 4
  let rTerm := rBase + 5
  let rAcc := rBase + 6
  let rCdf := rBase + 7
  .ite (.intEq (.readHeap scrW (.lit wK)) (.lit 0))
    (.writeRealHeap scrR (.lit rOut) (.ofInt (.lit 0)))
    (.seq (.writeRealHeap scrR (.lit rAcc) (.ofInt (.lit 1)))
    (.seq (forLoopStmt scrW wCtr b
            (.writeRealHeap scrR (.lit rAcc)
              (.mul (.ofInt (.lit 2)) (.readRealHeap scrR (.lit rAcc)))))
    (.seq (.writeRealHeap scrR (.lit rPtgt)
            (.div (.ofInt (.readHeap scrW (.lit wK))) (.readRealHeap scrR (.lit rAcc))))
    (.seq (.writeRealHeap scrR (.lit rLo) (.neg (.ofInt (.lit ((T + 1 : ℕ) : ℤ)))))
    (.seq (.writeRealHeap scrR (.lit rHi) (.ofInt (.lit ((T + 1 : ℕ) : ℤ))))
    (.seq (forLoopStmt scrW wBis S_bis
            (.seq (.writeRealHeap scrR (.lit rMid)
                    (.div (.add (.readRealHeap scrR (.lit rLo)) (.readRealHeap scrR (.lit rHi)))
                          (.ofInt (.lit 2))))
              (.seq (polyCDFStmt scrW scrR wCtr rMid rY rTerm rAcc rCdf K c_pi)
                (.ite (.realLe (.readRealHeap scrR (.lit rCdf)) (.readRealHeap scrR (.lit rPtgt)))
                  (.writeRealHeap scrR (.lit rLo) (.readRealHeap scrR (.lit rMid)))
                  (.writeRealHeap scrR (.lit rHi) (.readRealHeap scrR (.lit rMid)))))))
          (.writeRealHeap scrR (.lit rOut) (.readRealHeap scrR (.lit rLo)))))))))

private lemma exec_gaussIntPoly_frame {d : ℕ} {TW BW TR BR scrW scrR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCtr rY rTerm rAcc : ℤ) (K : ℕ) (y : ℝ)
    (Frame : ArithRAMMemory → Prop)
    (hFrame_w : ∀ m v, Frame m → Frame (H3a.wWrite m scrW wCtr v))
    (hFrame_r : ∀ m r v, r = rTerm ∨ r = rAcc → Frame m → Frame (H3a.rWrite m scrR r v))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hwCtr : 0 ≤ wCtr ∧ wCtr < (BW : ℤ))
    (_hrY : 0 ≤ rY ∧ rY < (BR : ℤ))
    (hrT : 0 ≤ rTerm ∧ rTerm < (BR : ℤ))
    (hrA : 0 ≤ rAcc ∧ rAcc < (BR : ℤ))
    (hne_YT : rY ≠ rTerm) (hne_YA : rY ≠ rAcc) (hne_TA : rTerm ≠ rAcc)
    (hF₀ : Frame m₀) (hy : rRead m₀ scrR rY = y) :
    ExecScratch TW BW TR BR scrW scrR inp
      (gaussIntPolyStmt scrW scrR wCtr rY rTerm rAcc K) m₀
      (fun m₁ => Frame m₁ ∧ rRead m₁ scrR rAcc = gaussIntPoly K y)
      (40 + 48 * K) := by
  unfold gaussIntPolyStmt
  refine ExecScratch.seq' (30 + 48 * K)
    ((ExecScratch.rSetScr (C := 10) inp (.lit rAcc) (.ofInt (.lit 0)) rAcc 0 hfp₀ hscrR hrA.1 hrA.2 rfl
      (by simp [evalRealExpr, evalIntExpr]) (by dsimp [intExprOps, realExprOps]; omega)
      (Post := fun mx_p => Frame mx_p ∧ rRead mx_p scrR rY = y ∧ rRead mx_p scrR rAcc = 0)
        ⟨hFrame_r m₀ rAcc 0 (Or.inr rfl) hF₀,
         by rw [rRead_rWrite_of_ne _ _ (Or.inr hne_YA)]; exact hy,
         rRead_rWrite_self _ _ _ _⟩).mono (fun _ _ h _ => h) (by omega))
    (by omega) (fun m₁ _ ⟨hF₁, hy₁, ha₁⟩ hfp₁ => ?_)
  refine ExecScratch.seq' (10 + 48 * K)
    ((ExecScratch.rSetScr (C := 20) inp (.lit rTerm) (.readRealHeap scrR (.lit rY)) rTerm y
      hfp₁ hscrR hrT.1 hrT.2 rfl hy₁
      (by dsimp [intExprOps, realExprOps]; omega)
      (Post := fun mx_p => Frame mx_p ∧ rRead mx_p scrR rY = y ∧ rRead mx_p scrR rTerm = gaussRecTerm y 0 ∧
            rRead mx_p scrR rAcc = gaussIntPoly 0 y)
        ⟨hFrame_r m₁ rTerm y (Or.inl rfl) hF₁,
         by rw [rRead_rWrite_of_ne _ _ (Or.inr hne_YT)]; exact hy₁,
         by rw [rRead_rWrite_self]; rfl,
         by rw [rRead_rWrite_of_ne _ _ (Or.inr hne_TA.symm), ha₁]; simp [gaussIntPoly]⟩).mono
      (fun _ _ h _ => h) (by omega))
    (by omega) (fun m₂ _ ⟨hF₂, hy₂, ht₂, ha₂⟩ hfp₂ => ?_)
  refine ExecDet.mono
    (ExecDet.forLoop scrW wCtr K _
      (Inv := fun i m => PreservesNonScratch scrW scrR m₂ m ∧ Frame m ∧
        rRead m scrR rY = y ∧ rRead m scrR rTerm = gaussRecTerm y i ∧
        rRead m scrR rAcc = gaussIntPoly i y) 40
      hfp₂ hscrW hwCtr.1 hwCtr.2
      ⟨PreservesNonScratch.wWrite_scr scrW scrR m₂ wCtr 0,
       hFrame_w m₂ 0 hF₂,
       by simp only [rRead_wWrite]; exact ⟨hy₂, ht₂, ha₂⟩⟩ ?_)
    (fun m₃ ⟨hpr₃, hF₃, _, _, ha₃⟩ _ => ⟨hpr₃, hF₃, ha₃⟩)
    (by have := Nat.mul_le_mul_left K (by decide : 46 ≤ 48); rw [Nat.mul_comm K 48] at this; omega)
  intro i _ m ⟨hprm, hFm, hym, htm, ham⟩ hctr hfpm
  refine ExecDet.mono
    (ExecScratch.seq' (Post := fun m'' => Frame m'' ∧ wRead m'' scrW wCtr = (i : ℤ) ∧
        rRead m'' scrR rY = y ∧ rRead m'' scrR rTerm = gaussRecTerm y (i + 1) ∧
        rRead m'' scrR rAcc = gaussIntPoly (i + 1) y) 22
      (ExecScratch.rSetScr inp (.lit rAcc) _ rAcc (gaussIntPoly (i + 1) y)
        hfpm hscrR hrA.1 hrA.2 rfl
        (by
          change rRead m scrR rAcc + rRead m scrR rTerm / (((2 * wRead m scrW wCtr + 1 : ℤ)) : ℝ) = _
          rw [ham, htm, hctr, gaussIntPoly_succ]; push_cast; rfl)
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun mx_p => Frame mx_p ∧ wRead mx_p scrW wCtr = (i : ℤ) ∧ rRead mx_p scrR rY = y ∧
              rRead mx_p scrR rTerm = gaussRecTerm y i ∧ rRead mx_p scrR rAcc = gaussIntPoly (i + 1) y)
        ⟨hFrame_r m rAcc _ (Or.inr rfl) hFm,
           by rw [wRead_rWrite]; exact hctr,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr hne_YA)]; exact hym,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr hne_TA)]; exact htm,
           rRead_rWrite_self _ _ _ _⟩)
      (by omega) (fun m' _ ⟨hFm', hctr', hym', htm', ham'⟩ hfp' =>
        ExecScratch.rSetScr inp (.lit rTerm) _ rTerm (gaussRecTerm y (i + 1))
          hfp' hscrR hrT.1 hrT.2 rfl
          (by
            change (rRead m' scrR rTerm * (-((rRead m' scrR rY * rRead m' scrR rY) / 2))) /
              (((wRead m' scrW wCtr + 1 : ℤ)) : ℝ) = _
            rw [htm', hym', hctr', gaussRecTerm]; push_cast; rfl)
          (by dsimp [intExprOps, realExprOps]; omega)
          ⟨hFrame_r m' rTerm _ (Or.inl rfl) hFm',
           by rw [wRead_rWrite]; exact hctr',
           by rw [rRead_rWrite_of_ne _ _ (Or.inr hne_YT)]; exact hym',
           rRead_rWrite_self _ _ _ _,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr hne_TA.symm)]; exact ham'⟩))
    (fun m'' ⟨hpr'', hFm'', hctr'', hym'', htm'', ham''⟩ _ =>
      ⟨hctr'', (hprm.trans hpr'').trans (PreservesNonScratch.wWrite_scr scrW scrR m'' wCtr ((i : ℤ) + 1)),
       hFrame_w m'' ((i : ℤ) + 1) hFm'',
       by simp only [rRead_wWrite]; exact ⟨hym'', htm'', ham''⟩⟩)
    le_rfl

theorem exec_polyQuantileStmt {d : ℕ} {TW BW TR BR scrW scrR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wK wBase rBase rOut : ℤ) (b T p_coord : ℕ) (k : Fin (2 ^ b))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (_hwK : 0 ≤ wK ∧ wK < (BW : ℤ))
    (hwB : 0 ≤ wBase ∧ wBase + 2 ≤ (BW : ℤ))
    (hw_disj : wK < wBase ∨ wBase + 2 ≤ wK)
    (hrB : 0 ≤ rBase ∧ rBase + 8 ≤ (BR : ℤ))
    (hrOut : 0 ≤ rOut ∧ rOut < (BR : ℤ))
    (hk_reg : wRead m₀ scrW wK = (k.val : ℤ)) :
    ExecScratch TW BW TR BR scrW scrR inp
      (polyQuantileStmt scrW scrR wK wBase rBase rOut b T p_coord) m₀
      (fun m₁ => rRead m₁ scrR rOut = ((polySample1D b T p_coord k : ℚ) : ℝ))
      (200 + 25 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b)) := by
  let K := cdfDegree T b
  let c_pi := cPiRat (cdfPiBits T b)
  let S_bis := T + p_coord + 6
  let p_tgt : ℚ := (k.val : ℚ) / ((2 ^ b : ℕ) : ℚ)
  let initLH : ℚ × ℚ := (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))
  unfold polyQuantileStmt
  refine (ExecScratch.ite (C_c := 6)
    (C_b := 194 + 25 * b + S_bis * (120 + 48 * K))
    _ _ _ (by dsimp [condExprOps, intExprOps]; omega) ?_ ?_).mono
    (fun _ _ h _ => h) (by dsimp [S_bis, K]; omega)
  · intro hc_true
    have hk0 : k.val = 0 := by
      simp only [evalArithCond, evalIntExpr, decide_eq_true_eq] at hc_true
      change wRead m₀ scrW wK = 0 at hc_true
      rw [hk_reg] at hc_true
      exact Int.ofNat.inj hc_true
    refine ExecScratch.rSetScr inp (.lit rOut) (.ofInt (.lit 0)) rOut 0
      hfp₀ hscrR hrOut.1 hrOut.2 rfl (by simp [evalRealExpr, evalIntExpr])
      (by dsimp [intExprOps, realExprOps]; omega) ?_
    rw [rRead_rWrite_self, polySample1D_def, if_pos hk0]
    norm_num
  · intro hc_false
    have hk0 : k.val ≠ 0 := by
      simp only [evalArithCond, evalIntExpr, decide_eq_false_iff_not] at hc_false
      change ¬ (wRead m₀ scrW wK = 0) at hc_false
      rw [hk_reg] at hc_false
      intro h; apply hc_false; rw [h]; rfl
    refine ExecScratch.seq' (184 + 25 * b + S_bis * (120 + 48 * K))
      (ExecScratch.rSetScr inp (.lit (rBase + 6)) (.ofInt (.lit 1)) (rBase + 6) 1
        hfp₀ hscrR (by omega) (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun mx_p => wRead mx_p scrW wK = (k.val : ℤ) ∧ rRead mx_p scrR (rBase + 6) = (2 : ℝ) ^ (0 : ℕ))
        ⟨by rw [wRead_rWrite]; exact hk_reg, by rw [rRead_rWrite_self]; simp⟩)
      (by omega) (fun m₁ _ ⟨hk₁, hp₁⟩ hfp₁ => ?_)
    refine ExecScratch.seq' (164 + S_bis * (120 + 48 * K))
      ((ExecScratch.forLoop wBase b _
        (fun i m => wRead m scrW wK = (k.val : ℤ) ∧ rRead m scrR (rBase + 6) = (2 : ℝ) ^ i) 15
        hfp₁ hscrW hwB.1 (by omega)
        (⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hk₁,
          by rw [rRead_wWrite]; exact hp₁⟩)
        (fun i _ m _ ⟨hkm, hpm⟩ hctr hfpm =>
          ExecScratch.rSetScr inp (.lit (rBase + 6)) _ (rBase + 6) ((2 : ℝ) ^ (i + 1))
            hfpm hscrR (by omega) (by omega) rfl
            (by change (2 : ℝ) * rRead m scrR (rBase + 6) = (2 : ℝ) ^ (i + 1); rw [hpm, pow_succ'])
            (by dsimp [intExprOps, realExprOps]; omega)
            ⟨by rw [wRead_rWrite]; exact hctr,
             by rw [wRead_rWrite]; exact hkm,
             rRead_rWrite_self _ _ _ _⟩)
        (by intro _ _ _ ⟨h1, h2⟩; exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1, by rw [rRead_wWrite]; exact h2⟩)).mono
        (fun _ _ h _ => h)
        (by have := Nat.mul_le_mul_left b (by decide : 23 ≤ 25); omega))
      (by omega) (fun m₂ _ ⟨hk₂, hp₂⟩ hfp₂ => ?_)
    have hp_eq : ((k.val : ℤ) : ℝ) / ((2 : ℝ) ^ b) = (p_tgt : ℝ) := by
      dsimp [p_tgt]; push_cast; rfl
    refine ExecScratch.seq' (148 + S_bis * (120 + 48 * K))
      (ExecScratch.rSetScr inp (.lit (rBase + 3)) _ (rBase + 3) (p_tgt : ℝ)
        hfp₂ hscrR (by omega) (by omega) rfl
        (by change ((wRead m₂ scrW wK : ℝ)) / rRead m₂ scrR (rBase + 6) = (p_tgt : ℝ); rw [hk₂, hp₂, hp_eq])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun mx_p => rRead mx_p scrR (rBase + 3) = (p_tgt : ℝ)) (rRead_rWrite_self _ _ _ _))
      (by omega) (fun m₃ _ hpt₃ hfp₃ => ?_)
    refine ExecScratch.seq' (134 + S_bis * (120 + 48 * K))
      (ExecScratch.rSetScr inp (.lit rBase) _ rBase (initLH.1 : ℝ)
        hfp₃ hscrR (by omega) (by omega) rfl
        (by dsimp [initLH]; simp [evalRealExpr, evalIntExpr])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun mx_p => rRead mx_p scrR rBase = (initLH.1 : ℝ) ∧ rRead mx_p scrR (rBase + 3) = (p_tgt : ℝ))
        ⟨rRead_rWrite_self _ _ _ _,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hpt₃⟩)
      (by omega) (fun m₄ _ ⟨hlo₄, hpt₄⟩ hfp₄ => ?_)
    refine ExecScratch.seq' (120 + S_bis * (120 + 48 * K))
      (ExecScratch.rSetScr inp (.lit (rBase + 1)) _ (rBase + 1) (initLH.2 : ℝ)
        hfp₄ hscrR (by omega) (by omega) rfl
        (by dsimp [initLH]; simp [evalRealExpr, evalIntExpr])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun mx_p => rRead mx_p scrR rBase = (initLH.1 : ℝ) ∧
              rRead mx_p scrR (rBase + 1) = (initLH.2 : ℝ) ∧
              rRead mx_p scrR (rBase + 3) = (p_tgt : ℝ))
        ⟨by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hlo₄,
           rRead_rWrite_self _ _ _ _,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hpt₄⟩)
      (by omega) (fun m₅ _ ⟨hlo₅, hhi₅, hpt₅⟩ hfp₅ => ?_)
    refine ExecScratch.seq' 14
      ((ExecScratch.forLoop (wBase + 1) S_bis _
        (fun s m =>
          let lh := (bisectStep K c_pi p_tgt)^[s] initLH
          rRead m scrR rBase = (lh.1 : ℝ) ∧
          rRead m scrR (rBase + 1) = (lh.2 : ℝ) ∧
          rRead m scrR (rBase + 3) = (p_tgt : ℝ))
        (110 + 48 * K)
        hfp₅ hscrW (by omega) (by omega)
        (by simp only [Function.iterate_zero, id_eq, rRead_wWrite]; exact ⟨hlo₅, hhi₅, hpt₅⟩)
        ?_).mono (fun _ _ h _ => h)
        (by have := Nat.mul_le_mul_left S_bis (by omega : 110 + 48 * K + 8 ≤ 120 + 48 * K); omega))
      (by omega) (fun m₆ _ ⟨hlo₆, _, _⟩ hfp₆ => ?_)
    · intro s _ m _ ⟨hlo_s, hhi_s, hpt_s⟩ hctr_s hfp_s
      set lh := (bisectStep K c_pi p_tgt)^[s] initLH
      let mid_q : ℚ := (lh.1 + lh.2) / 2
      have hmid_r : ((lh.1 : ℝ) + (lh.2 : ℝ)) / 2 = (mid_q : ℝ) := by
        dsimp [mid_q]; push_cast; rfl
      let Frame : ArithRAMMemory → Prop := fun mx =>
        wRead mx scrW (wBase + 1) = (s : ℤ) ∧
        rRead mx scrR rBase = (lh.1 : ℝ) ∧
        rRead mx scrR (rBase + 1) = (lh.2 : ℝ) ∧
        rRead mx scrR (rBase + 2) = (mid_q : ℝ) ∧
        rRead mx scrR (rBase + 3) = (p_tgt : ℝ)
      have hFrame_w : ∀ mx v, Frame mx → Frame (H3a.wWrite mx scrW wBase v) := by
        intro mx v ⟨h1, h2, h3, h4, h5⟩
        exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1,
               by simp only [rRead_wWrite]; exact ⟨h2, h3, h4, h5⟩⟩
      have hFrame_r : ∀ mx r v, r = rBase + 5 ∨ r = rBase + 6 → Frame mx → Frame (H3a.rWrite mx scrR r v) := by
        intro mx r v hr ⟨h1, h2, h3, h4, h5⟩
        refine ⟨by rw [wRead_rWrite]; exact h1, ?_, ?_, ?_, ?_⟩ <;>
          (rcases hr with rfl | rfl <;> rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))] <;> assumption)
      refine ExecScratch.seq' (96 + 48 * K)
        (ExecScratch.rSetScr inp (.lit (rBase + 2)) _ (rBase + 2) (mid_q : ℝ)
          hfp_s hscrR (by omega) (by omega) rfl
          (by change (rRead m scrR rBase + rRead m scrR (rBase + 1)) / 2 = (mid_q : ℝ); rw [hlo_s, hhi_s, hmid_r])
          (by dsimp [intExprOps, realExprOps]; omega)
          (Post := fun mx_p => Frame mx_p)
        ⟨by rw [wRead_rWrite]; exact hctr_s,
             by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hlo_s,
             by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hhi_s,
             rRead_rWrite_self _ _ _ _,
             by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hpt_s⟩)
        (by omega) (fun ma _ hFa hfp_a => ?_)
      have hcdf_step : ExecScratch TW BW TR BR scrW scrR inp
          (polyCDFStmt scrW scrR wBase (rBase + 2) (rBase + 4) (rBase + 5) (rBase + 6) (rBase + 7) K c_pi) ma
          (fun mb => Frame mb ∧ rRead mb scrR (rBase + 7) = polyCDF K c_pi (mid_q : ℝ))
          (78 + 48 * K) := by
        unfold polyCDFStmt
        refine (ExecScratch.ite (C_c := 8) (C_b := 70 + 48 * K) _ _ _
          (by dsimp [condExprOps, realExprOps, intExprOps]; omega) ?_ ?_).mono
          (fun _ _ h _ => h) (by omega)
        · intro hc_nn
          have hnn : 0 ≤ (mid_q : ℝ) := by
            simp only [evalArithCond, evalRealExpr, evalIntExpr, Int.cast_zero, mem_reals_read_heap, hFa.2.2.2.1, decide_eq_true_eq] at hc_nn
            exact hc_nn
          refine ExecScratch.seq' (58 + 48 * K)
            (ExecScratch.rSetScr inp (.lit (rBase + 4)) _ (rBase + 4) (mid_q : ℝ)
              hfp_a hscrR (by omega) (by omega) rfl hFa.2.2.2.1
              (by dsimp [intExprOps, realExprOps]; omega)
              (Post := fun mx_p => Frame mx_p ∧ rRead mx_p scrR (rBase + 4) = (mid_q : ℝ))
        ⟨⟨by rw [wRead_rWrite]; exact hFa.1,
                  by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hFa.2.1,
                  by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hFa.2.2.1,
                  by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hFa.2.2.2.1,
                  by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hFa.2.2.2.2⟩,
                 rRead_rWrite_self _ _ _ _⟩)
            (by omega) (fun m' _ ⟨hF', hy'⟩ hfp' => ?_)
          refine ExecScratch.seq' 16
            ((exec_gaussIntPoly_frame inp wBase (rBase + 4) (rBase + 5) (rBase + 6) K (mid_q : ℝ)
              Frame hFrame_w hFrame_r hfp' hscrW hscrR ⟨hwB.1, by omega⟩
              ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
              (by omega) (by omega) (by omega) hF' hy').mono (fun _ _ h _ => h) (by omega))
            (by omega) (fun m'' _ ⟨hF'', ha''⟩ hfp'' => ?_)
          exact ExecScratch.rSetScr inp (.lit (rBase + 7)) _ (rBase + 7) (polyCDF K c_pi (mid_q : ℝ))
            hfp'' hscrR (by omega) (by omega) rfl
            (by change (evalRealExpr inp 0 m'' (ratExpr (1 / 2))).1 + (evalRealExpr inp 0 m'' (ratExpr c_pi)).1 * rRead m'' scrR (rBase + 6) = _; unfold polyCDF; rw [if_pos hnn, evalRealExpr_ratExpr, evalRealExpr_ratExpr, ha'']; push_cast; rfl)
            (by dsimp [intExprOps, realExprOps, realExprOps_ratExpr]; omega)
            ⟨⟨by rw [wRead_rWrite]; exact hF''.1,
              by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hF''.2.1,
              by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hF''.2.2.1,
              by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hF''.2.2.2.1,
              by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hF''.2.2.2.2⟩,
             rRead_rWrite_self _ _ _ _⟩
        · intro hc_neg
          have hneg : ¬ (0 ≤ (mid_q : ℝ)) := by
            simp only [evalArithCond, evalRealExpr, evalIntExpr, Int.cast_zero, mem_reals_read_heap, hFa.2.2.2.1, decide_eq_false_iff_not] at hc_neg
            exact hc_neg
          refine ExecScratch.seq' (58 + 48 * K)
            (ExecScratch.rSetScr inp (.lit (rBase + 4)) _ (rBase + 4) (-(mid_q : ℝ))
              hfp_a hscrR (by omega) (by omega) rfl (by change -(rRead ma scrR (rBase + 2)) = -(mid_q : ℝ); rw [hFa.2.2.2.1])
              (by dsimp [intExprOps, realExprOps]; omega)
              (Post := fun mx_p => Frame mx_p ∧ rRead mx_p scrR (rBase + 4) = -(mid_q : ℝ))
        ⟨⟨by rw [wRead_rWrite]; exact hFa.1,
                  by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hFa.2.1,
                  by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hFa.2.2.1,
                  by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hFa.2.2.2.1,
                  by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hFa.2.2.2.2⟩,
                 rRead_rWrite_self _ _ _ _⟩)
            (by omega) (fun m' _ ⟨hF', hy'⟩ hfp' => ?_)
          refine ExecScratch.seq' 16
            ((exec_gaussIntPoly_frame inp wBase (rBase + 4) (rBase + 5) (rBase + 6) K (-(mid_q : ℝ))
              Frame hFrame_w hFrame_r hfp' hscrW hscrR ⟨hwB.1, by omega⟩
              ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
              (by omega) (by omega) (by omega) hF' hy').mono (fun _ _ h _ => h) (by omega))
            (by omega) (fun m'' _ ⟨hF'', ha''⟩ hfp'' => ?_)
          exact ExecScratch.rSetScr inp (.lit (rBase + 7)) _ (rBase + 7) (polyCDF K c_pi (mid_q : ℝ))
            hfp'' hscrR (by omega) (by omega) rfl
            (by change (evalRealExpr inp 0 m'' (ratExpr (1 / 2))).1 - (evalRealExpr inp 0 m'' (ratExpr c_pi)).1 * rRead m'' scrR (rBase + 6) = _; unfold polyCDF; rw [if_neg hneg, evalRealExpr_ratExpr, evalRealExpr_ratExpr, ha'']; push_cast; rfl)
            (by dsimp [intExprOps, realExprOps, realExprOps_ratExpr]; omega)
            ⟨⟨by rw [wRead_rWrite]; exact hF''.1,
              by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hF''.2.1,
              by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hF''.2.2.1,
              by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hF''.2.2.2.1,
              by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hF''.2.2.2.2⟩,
             rRead_rWrite_self _ _ _ _⟩
      refine ExecScratch.seq' 18 (hcdf_step.mono (fun _ _ h _ => h) (by omega)) (by omega)
        (fun mb _ ⟨⟨hctr_b, hlo_b, hhi_b, hmid_b, hpt_b⟩, hcdf_b⟩ hfp_b => ?_)
      refine ExecScratch.ite (C_c := 8) (C_b := 10) _ _ _
        (by dsimp [condExprOps, realExprOps, intExprOps]; omega) ?_ ?_
      · intro hle_c
        have hle : polyCDF K c_pi (mid_q : ℝ) ≤ (p_tgt : ℝ) := by
          simp only [evalArithCond, evalRealExpr, evalIntExpr, mem_reals_read_heap, hcdf_b, hpt_b, decide_eq_true_eq] at hle_c
          exact hle_c
        refine ExecScratch.rSetScr inp (.lit rBase) _ rBase (mid_q : ℝ)
          hfp_b hscrR (by omega) (by omega) rfl hmid_b
          (by dsimp [intExprOps, realExprOps]; omega) ?_
        dsimp only
        rw [Function.iterate_succ_apply']
        change wRead _ scrW (wBase + 1) = (s : ℤ) ∧
          rRead _ scrR rBase = ((bisectStep K c_pi p_tgt lh).1 : ℝ) ∧
          rRead _ scrR (rBase + 1) = ((bisectStep K c_pi p_tgt lh).2 : ℝ) ∧
          rRead _ scrR (rBase + 3) = (p_tgt : ℝ)
        unfold bisectStep; rw [if_pos hle]
        exact ⟨by rw [wRead_rWrite]; exact hctr_b,
               rRead_rWrite_self _ _ _ _,
               by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hhi_b,
               by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hpt_b⟩
      · intro hgt_c
        have hgt : ¬ (polyCDF K c_pi (mid_q : ℝ) ≤ (p_tgt : ℝ)) := by
          simp only [evalArithCond, evalRealExpr, evalIntExpr, mem_reals_read_heap, hcdf_b, hpt_b, decide_eq_false_iff_not] at hgt_c
          exact hgt_c
        refine ExecScratch.rSetScr inp (.lit (rBase + 1)) _ (rBase + 1) (mid_q : ℝ)
          hfp_b hscrR (by omega) (by omega) rfl hmid_b
          (by dsimp [intExprOps, realExprOps]; omega) ?_
        dsimp only
        rw [Function.iterate_succ_apply']
        change wRead _ scrW (wBase + 1) = (s : ℤ) ∧
          rRead _ scrR rBase = ((bisectStep K c_pi p_tgt lh).1 : ℝ) ∧
          rRead _ scrR (rBase + 1) = ((bisectStep K c_pi p_tgt lh).2 : ℝ) ∧
          rRead _ scrR (rBase + 3) = (p_tgt : ℝ)
        unfold bisectStep; rw [if_neg hgt]
        exact ⟨by rw [wRead_rWrite]; exact hctr_b,
               by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hlo_b,
               rRead_rWrite_self _ _ _ _,
               by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hpt_b⟩
    · refine ExecScratch.rSetScr inp (.lit rOut) _ rOut
        ((((bisectStep K c_pi p_tgt)^[S_bis] initLH).1 : ℚ) : ℝ)
        hfp₆ hscrR hrOut.1 hrOut.2 rfl hlo₆
        (by dsimp [intExprOps, realExprOps]; omega) ?_
      rw [rRead_rWrite_self, polySample1D_def, if_neg hk0]

/-! ### 5. Subroutine 3: `signedSqCapTestStmt` (`realSignedSqCapCond`) -/

def evalSignedSqCondStmt (scrW scrR : ℕ) (rL rR rN wDst : ℤ) : ArithRAMStmt :=
  let eL := RealExpr.readRealHeap scrR (.lit rL)
  let eR := RealExpr.readRealHeap scrR (.lit rR)
  let eN := RealExpr.readRealHeap scrR (.lit rN)
  let eL2 := RealExpr.mul eL eL
  let eR2N := RealExpr.mul (.mul eR eR) eN
  let cond : ArithCondExpr :=
    .or
      (.and (.realLt (.ofInt (.lit 0)) eR)
            (.and (.realLe (.ofInt (.lit 0)) eL) (.realLe eR2N eL2)))
      (.and (.realLe eR (.ofInt (.lit 0)))
            (.or (.realLe (.ofInt (.lit 0)) eL) (.realLe eL2 eR2N)))
  .ite cond
    (.writeWordHeap scrW (.lit wDst) (.lit 1))
    (.writeWordHeap scrW (.lit wDst) (.lit 0))

theorem exec_evalSignedSqCondStmt {d : ℕ} {TW BW TR BR scrW scrR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (rL rR rN wDst : ℤ) (L R normSq : ℝ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW)
    (hwDst : 0 ≤ wDst ∧ wDst < (BW : ℤ))
    (hL : rRead m₀ scrR rL = L) (hR : rRead m₀ scrR rR = R) (hN : rRead m₀ scrR rN = normSq) :
    ExecScratch TW BW TR BR scrW scrR inp
      (evalSignedSqCondStmt scrW scrR rL rR rN wDst) m₀
      (fun m₁ => open Classical in
        wRead m₁ scrW wDst =
          if ((0 < R ∧ 0 ≤ L ∧ R ^ 2 * normSq ≤ L ^ 2) ∨
              (R ≤ 0 ∧ (0 ≤ L ∨ L ^ 2 ≤ R ^ 2 * normSq))) then 1 else 0)
      80 := by
  let P_cond : Prop :=
    (0 < R ∧ 0 ≤ L ∧ R ^ 2 * normSq ≤ L ^ 2) ∨
    (R ≤ 0 ∧ (0 ≤ L ∨ L ^ 2 ≤ R ^ 2 * normSq))
  classical
  unfold evalSignedSqCondStmt
  refine (ExecScratch.ite (C_c := 70) (C_b := 10) _ _ _
    (by dsimp [condExprOps, realExprOps, intExprOps]; omega) ?_ ?_)
  · intro hc_t
    have hP : P_cond := by
      simp only [evalArithCond, evalRealExpr, evalIntExpr, mem_reals_read_heap, hL, hR, hN,
        Int.cast_zero, ← sq, Bool.or_eq_true, Bool.and_eq_true, decide_eq_true_eq] at hc_t
      exact hc_t
    refine ExecScratch.wSetScr inp (.lit wDst) (.lit 1) wDst 1
      hfp₀ hscrW hwDst.1 hwDst.2 rfl rfl (by dsimp [intExprOps]; omega) ?_
    rw [wRead_wWrite_self, if_pos hP]
  · intro hc_f
    have hP : ¬ P_cond := by
      simp only [evalArithCond, evalRealExpr, evalIntExpr, mem_reals_read_heap, hL, hR, hN,
        Int.cast_zero, ← sq, Bool.or_eq_false_iff, Bool.and_eq_false_iff, decide_eq_false_iff_not] at hc_f
      intro h; rcases h with ⟨h1, h2, h3⟩ | ⟨h1, h2 | h3⟩
      · rcases hc_f.1 with n1 | n2 | n3
        · exact n1 h1
        · exact n2 h2
        · exact n3 h3
      · rcases hc_f.2 with n1 | ⟨n2, _⟩
        · exact n1 h1
        · exact n2 h2
      · rcases hc_f.2 with n1 | ⟨_, n3⟩
        · exact n1 h1
        · exact n3 h3
    refine ExecScratch.wSetScr inp (.lit wDst) (.lit 0) wDst 0
      hfp₀ hscrW hwDst.1 hwDst.2 rfl rfl (by dsimp [intExprOps]; omega) ?_
    rw [wRead_wWrite_self, if_neg hP]

def signedSqCapTestStmt (scrW scrR tblG tblW : ℕ)
    (wCtr wDst rBase : ℤ) (offGE offWE : IntExpr) (d : ℕ) (A B_signed a₀ : ℚ) : ArithRAMStmt :=
  let rDot := rBase
  let rN := rBase + 1
  let rR := rBase + 2
  .seq (.writeRealHeap scrR (.lit rDot) (.ofInt (.lit 0)))
  (.seq (.writeRealHeap scrR (.lit rN) (.ofInt (.lit 0)))
  (.seq (forLoopStmt scrW wCtr d
          (.seq
            (.writeRealHeap scrR (.lit rDot)
              (.add (.readRealHeap scrR (.lit rDot))
                (.mul (.readRealHeap tblG (.add offGE (.readHeap scrW (.lit wCtr))))
                      (.readRealHeap tblW (.add offWE (.readHeap scrW (.lit wCtr)))))))
            (.writeRealHeap scrR (.lit rN)
              (.add (.readRealHeap scrR (.lit rN))
                (.mul (.readRealHeap tblW (.add offWE (.readHeap scrW (.lit wCtr))))
                      (.readRealHeap tblW (.add offWE (.readHeap scrW (.lit wCtr)))))))))
  (.seq (.writeRealHeap scrR (.lit rDot)
          (.mul (ratExpr A) (.readRealHeap scrR (.lit rDot))))
  (.seq (.writeRealHeap scrR (.lit rR)
          (.sub (ratExpr a₀)
            (.mul (ratExpr B_signed) (.readRealHeap tblG (.add offGE (.lit (d : ℤ)))))))
        (evalSignedSqCondStmt scrW scrR rDot rR rN wDst)))))

theorem exec_signedSqCapTestStmt {d : ℕ} {TW BW TR BR scrW scrR tblG tblW : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCtr wDst rBase offG offW : ℤ) (A B_signed a₀ : ℚ)
    (G : EuclideanSpace ℝ (Fin (d + 1))) (w : EuclideanSpace ℝ (Fin d))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hwCtr : 0 ≤ wCtr ∧ wCtr < (BW : ℤ))
    (hwDst : 0 ≤ wDst ∧ wDst < (BW : ℤ))
    (hrB : 0 ≤ rBase ∧ rBase + 3 ≤ (BR : ℤ))
    (hdisjG : tblG ≠ scrR ∨ offG + (d : ℤ) < rBase ∨ rBase + 3 ≤ offG)
    (hdisjW : tblW ≠ scrR ∨ offW + (d : ℤ) ≤ rBase ∨ rBase + 3 ≤ offW)
    (hG : ∀ j : Fin (d + 1), rRead m₀ tblG (offG + (j.val : ℤ)) = euclideanCoord G j)
    (hw : ∀ i : Fin d, rRead m₀ tblW (offW + (i.val : ℤ)) = euclideanCoord w i) :
    ExecScratch TW BW TR BR scrW scrR inp
      (signedSqCapTestStmt scrW scrR tblG tblW wCtr wDst rBase (.lit offG) (.lit offW) d A B_signed a₀) m₀
      (fun m₁ => open Classical in
        wRead m₁ scrW wDst = if realSignedSqCapCond (A : ℝ) (B_signed : ℝ) (a₀ : ℝ) G w then 1 else 0)
      (160 + 48 * d) := by
  have hkeepGW : ∀ (m : ArithRAMMemory),
      (∀ j : Fin (d + 1), rRead m tblG (offG + (j.val : ℤ)) = euclideanCoord G j) →
      (∀ i : Fin d, rRead m tblW (offW + (i.val : ℤ)) = euclideanCoord w i) →
      ∀ (r : ℤ) (_hr : rBase ≤ r ∧ r < rBase + 3) (v : ℝ),
        (∀ j : Fin (d + 1), rRead (H3a.rWrite m scrR r v) tblG (offG + (j.val : ℤ)) = euclideanCoord G j) ∧
        (∀ i : Fin d, rRead (H3a.rWrite m scrR r v) tblW (offW + (i.val : ℤ)) = euclideanCoord w i) := by
    intro m hmG hmW r hr v
    refine ⟨fun j => ?_, fun i => ?_⟩
    · have hj := j.isLt
      have hne : tblG ≠ scrR ∨ offG + (j.val : ℤ) ≠ r := by
        rcases hdisjG with h1 | h2 | h3
        · exact Or.inl h1
        · exact Or.inr (by omega)
        · exact Or.inr (by omega)
      rw [rRead_rWrite_of_ne _ _ hne]; exact hmG j
    · have hi := i.isLt
      have hne : tblW ≠ scrR ∨ offW + (i.val : ℤ) ≠ r := by
        rcases hdisjW with h1 | h2 | h3
        · exact Or.inl h1
        · exact Or.inr (by omega)
        · exact Or.inr (by omega)
      rw [rRead_rWrite_of_ne _ _ hne]; exact hmW i
  let dotPfx : ℕ → ℝ := fun k =>
    ∑ i ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k),
      euclideanCoord G i.castSucc * euclideanCoord w i
  let sqPfx : ℕ → ℝ := fun k =>
    ∑ i ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k),
      (euclideanCoord w i) ^ 2
  unfold signedSqCapTestStmt
  refine ExecScratch.seq' (145 + 48 * d)
    (ExecScratch.rSetScr inp (.lit rBase) (.ofInt (.lit 0)) rBase 0
      hfp₀ hscrR hrB.1 (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
      (by dsimp [intExprOps, realExprOps]; omega)
      (Post := fun mx_p => rRead mx_p scrR rBase = 0 ∧
            (∀ j : Fin (d + 1), rRead mx_p tblG (offG + (j.val : ℤ)) = euclideanCoord G j) ∧
            (∀ i : Fin d, rRead mx_p tblW (offW + (i.val : ℤ)) = euclideanCoord w i))
        ⟨rRead_rWrite_self _ _ _ _, hkeepGW m₀ hG hw rBase ⟨le_rfl, by omega⟩ 0⟩)
    (by omega) (fun m₁ _ ⟨hd₁, hG₁, hw₁⟩ hfp₁ => ?_)
  refine ExecScratch.seq' (130 + 48 * d)
    (ExecScratch.rSetScr inp (.lit (rBase + 1)) (.ofInt (.lit 0)) (rBase + 1) 0
      hfp₁ hscrR (by omega) (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
      (by dsimp [intExprOps, realExprOps]; omega)
      (Post := fun mx_p => rRead mx_p scrR rBase = dotPfx 0 ∧ rRead mx_p scrR (rBase + 1) = sqPfx 0 ∧
            (∀ j : Fin (d + 1), rRead mx_p tblG (offG + (j.val : ℤ)) = euclideanCoord G j) ∧
            (∀ i : Fin d, rRead mx_p tblW (offW + (i.val : ℤ)) = euclideanCoord w i))
        ⟨by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega)), hd₁]; simp [dotPfx],
         by rw [rRead_rWrite_self]; simp [sqPfx],
         hkeepGW m₁ hG₁ hw₁ (rBase + 1) ⟨by omega, by omega⟩ 0⟩)
    (by omega) (fun m₂ _ ⟨hd₂, hn₂, hG₂, hw₂⟩ hfp₂ => ?_)
  refine ExecScratch.seq' 116
    ((ExecScratch.forLoop wCtr d _
      (fun k m => rRead m scrR rBase = dotPfx k ∧ rRead m scrR (rBase + 1) = sqPfx k ∧
        (∀ j : Fin (d + 1), rRead m tblG (offG + (j.val : ℤ)) = euclideanCoord G j) ∧
        (∀ i : Fin d, rRead m tblW (offW + (i.val : ℤ)) = euclideanCoord w i)) 40
      hfp₂ hscrW hwCtr.1 hwCtr.2
      (by simp only [rRead_wWrite]; exact ⟨hd₂, hn₂, hG₂, hw₂⟩) ?_).mono
      (fun _ _ h _ => h) (by omega))
    (by omega) (fun m₃ _ ⟨hd₃, hn₃, hG₃, hw₃⟩ hfp₃ => ?_)
  · intro k hk m _ ⟨hdm, hnm, hGm, hwm⟩ hctr hfpm
    let ik : Fin d := ⟨k, hk⟩
    have hsplit : ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k + 1)) =
        insert ik ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by
      ext c; simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert, Fin.ext_iff, ik]
      omega
    have hnot : ik ∉ ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by
      simp [ik]
    have hdot_succ : dotPfx (k + 1) = dotPfx k + euclideanCoord G ik.castSucc * euclideanCoord w ik := by
      dsimp only [dotPfx]; rw [hsplit, Finset.sum_insert hnot, add_comm]
    have hsq_succ : sqPfx (k + 1) = sqPfx k + (euclideanCoord w ik) ^ 2 := by
      dsimp only [sqPfx]; rw [hsplit, Finset.sum_insert hnot, add_comm]
    refine ExecScratch.seq' 20
      (ExecScratch.rSetScr inp (.lit rBase) _ rBase (dotPfx (k + 1))
        hfpm hscrR hrB.1 (by omega) rfl
        (by
          change rRead m scrR rBase +
            rRead m tblG (offG + wRead m scrW wCtr) * rRead m tblW (offW + wRead m scrW wCtr) = dotPfx (k + 1)
          rw [hdm, hctr]
          have hg1 : rRead m tblG (offG + (k : ℤ)) = euclideanCoord G ik.castSucc := hGm ik.castSucc
          have hw1 : rRead m tblW (offW + (k : ℤ)) = euclideanCoord w ik := hwm ik
          rw [hg1, hw1, hdot_succ])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun mx_p => wRead mx_p scrW wCtr = (k : ℤ) ∧ rRead mx_p scrR rBase = dotPfx (k + 1) ∧
              rRead mx_p scrR (rBase + 1) = sqPfx k ∧
              (∀ j : Fin (d + 1), rRead mx_p tblG (offG + (j.val : ℤ)) = euclideanCoord G j) ∧
              (∀ i : Fin d, rRead mx_p tblW (offW + (i.val : ℤ)) = euclideanCoord w i))
        ⟨by rw [wRead_rWrite]; exact hctr,
           rRead_rWrite_self _ _ _ _,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hnm,
           hkeepGW m hGm hwm rBase ⟨le_rfl, by omega⟩ _⟩)
      (by omega) (fun m' _ ⟨hctr', hd', hn', hG', hw'⟩ hfp' => ?_)
    refine ExecScratch.rSetScr inp (.lit (rBase + 1)) _ (rBase + 1) (sqPfx (k + 1))
      hfp' hscrR (by omega) (by omega) rfl
      (by
        change rRead m' scrR (rBase + 1) +
          rRead m' tblW (offW + wRead m' scrW wCtr) * rRead m' tblW (offW + wRead m' scrW wCtr) = sqPfx (k + 1)
        rw [hn', hctr']
        have hw1 : rRead m' tblW (offW + (k : ℤ)) = euclideanCoord w ik := hw' ik
        rw [hw1, hsq_succ, sq])
      (by dsimp [intExprOps, realExprOps]; omega)
      ⟨by rw [wRead_rWrite]; exact hctr',
       by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hd',
       rRead_rWrite_self _ _ _ _,
       hkeepGW m' hG' hw' (rBase + 1) ⟨by omega, by omega⟩ _⟩
  · have hdot_full : dotPfx d = ∑ i : Fin d, euclideanCoord G i.castSucc * euclideanCoord w i := by
      dsimp [dotPfx]; congr 1; ext i; simp
    have hsq_full : sqPfx d = ∑ i : Fin d, (euclideanCoord w i) ^ 2 := by
      dsimp [sqPfx]; congr 1; ext i; simp
    let L_val : ℝ := (A : ℝ) * ∑ i : Fin d, euclideanCoord G i.castSucc * euclideanCoord w i
    let R_val : ℝ := (a₀ : ℝ) - (B_signed : ℝ) * euclideanCoord G (Fin.last d)
    let N_val : ℝ := ∑ i : Fin d, (euclideanCoord w i) ^ 2
    refine ExecScratch.seq' 102
      (ExecScratch.rSetScr inp (.lit rBase) _ rBase L_val
        hfp₃ hscrR hrB.1 (by omega) rfl
        (by change (evalRealExpr inp 0 m₃ (ratExpr A)).1 * rRead m₃ scrR rBase = L_val; rw [evalRealExpr_ratExpr, hd₃, hdot_full])
        (by dsimp [intExprOps, realExprOps, realExprOps_ratExpr]; omega)
        (Post := fun mx_p => rRead mx_p scrR rBase = L_val ∧ rRead mx_p scrR (rBase + 1) = N_val ∧
              rRead mx_p tblG (offG + (d : ℤ)) = euclideanCoord G (Fin.last d))
        ⟨rRead_rWrite_self _ _ _ _,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega)), hn₃, hsq_full],
           (hkeepGW m₃ hG₃ hw₃ rBase ⟨le_rfl, by omega⟩ L_val).1 (Fin.last d)⟩)
      (by omega) (fun m₄ _ ⟨hL₄, hN₄, hGd₄⟩ hfp₄ => ?_)
    refine ExecScratch.seq' 80
      (ExecScratch.rSetScr inp (.lit (rBase + 2)) _ (rBase + 2) R_val
        hfp₄ hscrR (by omega) (by omega) rfl
        (by change (evalRealExpr inp 0 m₄ (ratExpr a₀)).1 - (evalRealExpr inp 0 m₄ (ratExpr B_signed)).1 * rRead m₄ tblG (offG + (d : ℤ)) = R_val; rw [evalRealExpr_ratExpr, evalRealExpr_ratExpr, hGd₄])
        (by dsimp [intExprOps, realExprOps, realExprOps_ratExpr]; omega)
        (Post := fun mx_p => rRead mx_p scrR rBase = L_val ∧ rRead mx_p scrR (rBase + 2) = R_val ∧
              rRead mx_p scrR (rBase + 1) = N_val)
        ⟨by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hL₄,
           rRead_rWrite_self _ _ _ _,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hN₄⟩)
      (by omega) (fun m₅ _ ⟨hL₅, hR₅, hN₅⟩ hfp₅ => ?_)
    refine (exec_evalSignedSqCondStmt inp rBase (rBase + 2) (rBase + 1) wDst L_val R_val N_val
      hfp₅ hscrW hwDst hL₅ hR₅ hN₅).mono (fun m₁ _ h _ => ?_) le_rfl
    rw [h]; unfold realSignedSqCapCond; dsimp only [L_val, R_val, N_val]
    split_ifs <;> rfl

/-! ### 6. Subroutine 4: `roundQueryLatStmt` (`sqrt`-free lattice rounding via `latBisect_eq_floor`) -/

def roundQueryLatStmt (scrW scrR tblW : ℕ)
    (wBase rBase offW offOut : ℤ) (d M_lat S_lat : ℕ) : ArithRAMStmt :=
  let wI := wBase
  let wS := wBase + 1
  let wLo := wBase + 2
  let wHi := wBase + 3
  let wMid := wBase + 4
  let wCmp := wBase + 5
  let rN := rBase
  let rL := rBase + 1
  let rR := rBase + 2
  .seq (.writeRealHeap scrR (.lit rN) (.ofInt (.lit 0)))
  (.seq (forLoopStmt scrW wI d
          (.writeRealHeap scrR (.lit rN)
            (.add (.readRealHeap scrR (.lit rN))
              (.mul (.readRealHeap tblW (.add (.lit offW) (.readHeap scrW (.lit wI))))
                    (.readRealHeap tblW (.add (.lit offW) (.readHeap scrW (.lit wI))))))))
        (forLoopStmt scrW wI d
          (.seq (.writeWordHeap scrW (.lit wLo) (.lit 0))
          (.seq (.writeWordHeap scrW (.lit wHi) (.lit ((2 * M_lat + 1 : ℕ) : ℤ)))
          (.seq (forLoopStmt scrW wS S_lat
                  (.ite (.intLe (.readHeap scrW (.lit wHi))
                                (.add (.readHeap scrW (.lit wLo)) (.lit 1)))
                    .skip
                    (.seq (.writeWordHeap scrW (.lit wMid)
                            (.div (.add (.readHeap scrW (.lit wLo)) (.readHeap scrW (.lit wHi))) (.lit 2)))
                    (.seq (.writeRealHeap scrR (.lit rR)
                            (.ofInt (.sub (.sub (.mul (.lit 2) (.readHeap scrW (.lit wMid)))
                                                (.lit ((2 * M_lat : ℕ) : ℤ)))
                                          (.lit 1))))
                    (.seq (.writeRealHeap scrR (.lit rL)
                            (.mul (.ofInt (.lit ((2 * M_lat : ℕ) : ℤ)))
                                  (.readRealHeap tblW (.add (.lit offW) (.readHeap scrW (.lit wI))))))
                    (.seq (evalSignedSqCondStmt scrW scrR rL rR rN wCmp)
                          (.ite (.intEq (.readHeap scrW (.lit wCmp)) (.lit 1))
                            (.writeWordHeap scrW (.lit wLo) (.readHeap scrW (.lit wMid)))
                            (.writeWordHeap scrW (.lit wHi) (.readHeap scrW (.lit wMid))))))))))
                (.writeRealHeap scrR (.add (.lit offOut) (.readHeap scrW (.lit wI)))
                  (.ofInt (.sub (.readHeap scrW (.lit wLo)) (.lit (M_lat : ℤ))))))))))

theorem exec_roundQueryLatStmt {d : ℕ} {TW BW TR BR scrW scrR tblW : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBase rBase offW offOut : ℤ) (M_lat S_lat : ℕ)
    (hS : 2 * M_lat + 1 ≤ 2 ^ S_lat)
    (w : EuclideanSpace ℝ (Fin d)) (hw_ne : w ≠ 0)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hwB : 0 ≤ wBase ∧ wBase + 6 ≤ (BW : ℤ))
    (hrB : 0 ≤ rBase ∧ rBase + 3 ≤ (BR : ℤ))
    (hrOut : 0 ≤ offOut ∧ offOut + (d : ℤ) ≤ (BR : ℤ))
    (hrB_out : rBase + 3 ≤ offOut ∨ offOut + (d : ℤ) ≤ rBase)
    (hw_disj1 : tblW ≠ scrR ∨ offW + (d : ℤ) ≤ rBase ∨ rBase + 3 ≤ offW)
    (hw_disj2 : tblW ≠ scrR ∨ offW + (d : ℤ) ≤ offOut ∨ offOut + (d : ℤ) ≤ offW)
    (hw : ∀ i : Fin d, rRead m₀ tblW (offW + (i.val : ℤ)) = euclideanCoord w i) :
    let z : EuclideanSpace ℝ (Fin d) := ‖w‖⁻¹ • w
    ExecScratch TW BW TR BR scrW scrR inp
      (roundQueryLatStmt scrW scrR tblW wBase rBase offW offOut d M_lat S_lat) m₀
      (fun m₁ => ∀ i : Fin d,
        rRead m₁ scrR (offOut + (i.val : ℤ)) =
          ((Int.floor ((M_lat : ℝ) * euclideanCoord z i + 1 / 2) : ℤ) : ℝ))
      (80 + 30 * d + d * (60 + 165 * S_lat)) := by
  intro z
  have hkeepW_B : ∀ (m : ArithRAMMemory),
      (∀ c : Fin d, rRead m tblW (offW + (c.val : ℤ)) = euclideanCoord w c) →
      ∀ r (_hr : rBase ≤ r ∧ r < rBase + 3) (v : ℝ),
        ∀ c : Fin d, rRead (H3a.rWrite m scrR r v) tblW (offW + (c.val : ℤ)) = euclideanCoord w c := by
    intro m hm r hr v c
    have hc := c.isLt
    have hne : tblW ≠ scrR ∨ offW + (c.val : ℤ) ≠ r := by
      rcases hw_disj1 with h1 | h2 | h3
      · exact Or.inl h1
      · exact Or.inr (by omega)
      · exact Or.inr (by omega)
    rw [rRead_rWrite_of_ne _ _ hne]; exact hm c
  have hkeepW_O : ∀ (m : ArithRAMMemory),
      (∀ c : Fin d, rRead m tblW (offW + (c.val : ℤ)) = euclideanCoord w c) →
      ∀ k (_hk : k < d) (v : ℝ),
        ∀ c : Fin d, rRead (H3a.rWrite m scrR (offOut + (k : ℤ)) v) tblW (offW + (c.val : ℤ)) = euclideanCoord w c := by
    intro m hm k hk v c
    have hc := c.isLt
    have hne : tblW ≠ scrR ∨ offW + (c.val : ℤ) ≠ offOut + (k : ℤ) := by
      rcases hw_disj2 with h1 | h2 | h3
      · exact Or.inl h1
      · exact Or.inr (by omega)
      · exact Or.inr (by omega)
    rw [rRead_rWrite_of_ne _ _ hne]; exact hm c
  let sqPfx : ℕ → ℝ := fun k =>
    ∑ c ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k), (euclideanCoord w c) ^ 2
  let normSq : ℝ := ∑ c : Fin d, (euclideanCoord w c) ^ 2
  unfold roundQueryLatStmt
  refine ExecScratch.seq' (70 + 30 * d + d * (60 + 165 * S_lat))
    (ExecScratch.rSetScr inp (.lit rBase) (.ofInt (.lit 0)) rBase 0
      hfp₀ hscrR hrB.1 (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
      (by dsimp [intExprOps, realExprOps]; omega)
      (Post := fun mx_p => rRead mx_p scrR rBase = sqPfx 0 ∧
            (∀ c : Fin d, rRead mx_p tblW (offW + (c.val : ℤ)) = euclideanCoord w c))
        ⟨by rw [rRead_rWrite_self]; simp [sqPfx], hkeepW_B m₀ hw rBase ⟨le_rfl, by omega⟩ 0⟩)
    (by omega) (fun m₁ _ ⟨hn₁, hw₁⟩ hfp₁ => ?_)
  refine ExecScratch.seq' (50 + d * (60 + 165 * S_lat))
    ((ExecScratch.forLoop wBase d _
      (fun k m => rRead m scrR rBase = sqPfx k ∧
        (∀ c : Fin d, rRead m tblW (offW + (c.val : ℤ)) = euclideanCoord w c)) 20
      hfp₁ hscrW hwB.1 (by omega) (by simp only [rRead_wWrite]; exact ⟨hn₁, hw₁⟩)
      (fun k hk m _ ⟨hnm, hwm⟩ hctr hfpm => by
        let ik : Fin d := ⟨k, hk⟩
        have hsplit : ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k + 1)) =
            insert ik ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by
          ext c; simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert, Fin.ext_iff, ik]; omega
        have hnot : ik ∉ ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by simp [ik]
        have hsq_s : sqPfx (k + 1) = sqPfx k + (euclideanCoord w ik) ^ 2 := by
          dsimp only [sqPfx]; rw [hsplit, Finset.sum_insert hnot, add_comm]
        exact ExecScratch.rSetScr inp (.lit rBase) _ rBase (sqPfx (k + 1))
          hfpm hscrR hrB.1 (by omega) rfl
          (by
            change rRead m scrR rBase + rRead m tblW (offW + wRead m scrW wBase) * rRead m tblW (offW + wRead m scrW wBase) = sqPfx (k + 1)
            rw [hnm, hctr]
            have hw1 : rRead m tblW (offW + (k : ℤ)) = euclideanCoord w ik := hwm ik
            rw [hw1, hsq_s, sq])
          (by dsimp [intExprOps, realExprOps]; omega)
          ⟨by rw [wRead_rWrite]; exact hctr, rRead_rWrite_self _ _ _ _,
           hkeepW_B m hwm rBase ⟨le_rfl, by omega⟩ _⟩)).mono (fun _ _ h _ => h)
        (by have := Nat.mul_le_mul_left d (by decide : 28 ≤ 30); omega))
    (by omega) (fun m₂ _ ⟨hn₂, hw₂⟩ hfp₂ => ?_)
  have hn_full : rRead m₂ scrR rBase = normSq := by
    rw [hn₂]; dsimp [sqPfx, normSq]; congr 1; ext c; simp
  refine (ExecScratch.forLoop wBase d _
    (fun k m => rRead m scrR rBase = normSq ∧
      (∀ c : Fin d, rRead m tblW (offW + (c.val : ℤ)) = euclideanCoord w c) ∧
      (∀ c : Fin d, c.val < k →
        rRead m scrR (offOut + (c.val : ℤ)) =
          ((Int.floor ((M_lat : ℝ) * euclideanCoord z c + 1 / 2) : ℤ) : ℝ)))
    (50 + 165 * S_lat)
    hfp₂ hscrW hwB.1 (by omega)
    (by simp only [rRead_wWrite]; exact ⟨hn_full, hw₂, fun _ hc => absurd hc (Nat.not_lt_zero _)⟩)
    ?_).mono (fun m₃ _ ⟨_, _, hout₃⟩ _ => fun i => hout₃ i i.isLt)
    (by have := Nat.mul_le_mul_left d (by omega : 50 + 165 * S_lat + 8 ≤ 60 + 165 * S_lat); omega)
  intro k hk m _ ⟨hnm, hwm, hout_prev⟩ hctrk hfpm
  let ik : Fin d := ⟨k, hk⟩
  refine ExecScratch.seq' (40 + 165 * S_lat)
    (ExecScratch.wSetScr inp (.lit (wBase + 2)) (.lit 0) (wBase + 2) 0
      hfpm hscrW (by omega) (by omega) rfl rfl (by dsimp [intExprOps]; omega)
      (Post := fun mx_p => wRead mx_p scrW wBase = (k : ℤ) ∧ wRead mx_p scrW (wBase + 2) = 0 ∧
            rRead mx_p scrR rBase = normSq ∧
            (∀ c : Fin d, rRead mx_p tblW (offW + (c.val : ℤ)) = euclideanCoord w c) ∧
            (∀ c : Fin d, c.val < k → rRead mx_p scrR (offOut + (c.val : ℤ)) =
              ((Int.floor ((M_lat : ℝ) * euclideanCoord z c + 1 / 2) : ℤ) : ℝ)))
        ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctrk,
         wRead_wWrite_self _ _ _ _,
         by simp only [rRead_wWrite]; exact ⟨hnm, hwm, hout_prev⟩⟩)
    (by omega) (fun ma _ ⟨hck_a, hlo_a, hn_a, hw_a, hout_a⟩ hfp_a => ?_)
  refine ExecScratch.seq' (30 + 165 * S_lat)
    (ExecScratch.wSetScr inp (.lit (wBase + 3)) (.lit ((2 * M_lat + 1 : ℕ) : ℤ)) (wBase + 3)
      ((2 * M_lat + 1 : ℕ) : ℤ)
      hfp_a hscrW (by omega) (by omega) rfl rfl (by dsimp [intExprOps]; omega)
      (Post := fun mx_p => wRead mx_p scrW wBase = (k : ℤ) ∧
            wRead mx_p scrW (wBase + 2) = (((latBisectStep M_lat w ik)^[0] (0, 2 * M_lat + 1)).1 : ℤ) ∧
            wRead mx_p scrW (wBase + 3) = (((latBisectStep M_lat w ik)^[0] (0, 2 * M_lat + 1)).2 : ℤ) ∧
            rRead mx_p scrR rBase = normSq ∧
            (∀ c : Fin d, rRead mx_p tblW (offW + (c.val : ℤ)) = euclideanCoord w c) ∧
            (∀ c : Fin d, c.val < k → rRead mx_p scrR (offOut + (c.val : ℤ)) =
              ((Int.floor ((M_lat : ℝ) * euclideanCoord z c + 1 / 2) : ℤ) : ℝ)))
        ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hck_a,
         by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hlo_a]; simp,
         by rw [wRead_wWrite_self]; simp,
         by simp only [rRead_wWrite]; exact ⟨hn_a, hw_a, hout_a⟩⟩)
    (by omega) (fun mb _ ⟨hck_b, hlo_b, hhi_b, hn_b, hw_b, hout_b⟩ hfp_b => ?_)
  refine ExecScratch.seq' 18
    ((ExecScratch.forLoop (wBase + 1) S_lat _
      (fun s ms =>
        let lh := (latBisectStep M_lat w ik)^[s] (0, 2 * M_lat + 1)
        wRead ms scrW wBase = (k : ℤ) ∧
        wRead ms scrW (wBase + 2) = (lh.1 : ℤ) ∧
        wRead ms scrW (wBase + 3) = (lh.2 : ℤ) ∧
        rRead ms scrR rBase = normSq ∧
        (∀ c : Fin d, rRead ms tblW (offW + (c.val : ℤ)) = euclideanCoord w c) ∧
        (∀ c : Fin d, c.val < k → rRead ms scrR (offOut + (c.val : ℤ)) =
          ((Int.floor ((M_lat : ℝ) * euclideanCoord z c + 1 / 2) : ℤ) : ℝ)))
      145
      hfp_b hscrW (by omega) (by omega)
      (⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hck_b,
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hlo_b,
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hhi_b,
        by simp only [rRead_wWrite]; exact ⟨hn_b, hw_b, hout_b⟩⟩)
      ?_
      (by
        intro _ _ _ ⟨h1, h2, h3, h4⟩
        exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1,
               by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h2,
               by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h3,
               by simp only [rRead_wWrite]; exact h4⟩)).mono (fun _ _ h _ => h)
      (by have := Nat.mul_le_mul_left S_lat (by decide : 153 ≤ 165); rw [Nat.mul_comm S_lat 165] at this; omega))
    (by omega) (fun mc _ ⟨hck_c, hlo_c, _, hn_c, hw_c, hout_c⟩ hfp_c => ?_)
  · intro s _ ms _ ⟨hck_s, hlo_s, hhi_s, hn_s, hw_s, hout_s⟩ hctrs hfps
    set lh := (latBisectStep M_lat w ik)^[s] (0, 2 * M_lat + 1)
    refine ExecScratch.ite (C_c := 10) (C_b := 135) _ _ _
      (by dsimp [condExprOps, intExprOps]; omega) ?_ ?_
    · intro hle1_c
      have hle1 : lh.2 ≤ lh.1 + 1 := by
        simp only [evalArithCond, evalIntExpr, mem_words_read_heap, hlo_s, hhi_s, decide_eq_true_eq] at hle1_c
        omega
      refine ExecScratch.skip inp hfps ?_ (by omega)
      dsimp only
      rw [Function.iterate_succ_apply']
      change wRead ms scrW (wBase + 1) = (s : ℤ) ∧ wRead ms scrW wBase = (k : ℤ) ∧
        wRead ms scrW (wBase + 2) = ((latBisectStep M_lat w ik lh).1 : ℤ) ∧
        wRead ms scrW (wBase + 3) = ((latBisectStep M_lat w ik lh).2 : ℤ) ∧ _
      unfold latBisectStep; rw [if_pos hle1]
      exact ⟨hctrs, hck_s, hlo_s, hhi_s, hn_s, hw_s, hout_s⟩
    · intro hgt1_c
      have hgt1 : ¬ (lh.2 ≤ lh.1 + 1) := by
        simp only [evalArithCond, evalIntExpr, mem_words_read_heap, hlo_s, hhi_s, decide_eq_false_iff_not] at hgt1_c
        omega
      let mid : ℕ := (lh.1 + lh.2) / 2
      have hmid_z : ((lh.1 : ℤ) + (lh.2 : ℤ)) / 2 = (mid : ℤ) := rfl
      let R_v : ℝ := ((2 * (mid : ℤ) - 2 * (M_lat : ℤ) - 1 : ℤ) : ℝ)
      let L_v : ℝ := 2 * (M_lat : ℝ) * euclideanCoord w ik
      refine ExecScratch.seq' 123
        (ExecScratch.wSetScr inp (.lit (wBase + 4)) _ (wBase + 4) (mid : ℤ)
          hfps hscrW (by omega) (by omega) rfl
          (by change (wRead ms scrW (wBase + 2) + wRead ms scrW (wBase + 3)) / 2 = (mid : ℤ); rw [hlo_s, hhi_s, hmid_z]) (by dsimp [intExprOps]; omega)
          (Post := fun mx_p => wRead mx_p scrW (wBase + 1) = (s : ℤ) ∧ wRead mx_p scrW wBase = (k : ℤ) ∧
                wRead mx_p scrW (wBase + 2) = (lh.1 : ℤ) ∧ wRead mx_p scrW (wBase + 3) = (lh.2 : ℤ) ∧
                wRead mx_p scrW (wBase + 4) = (mid : ℤ) ∧ rRead mx_p scrR rBase = normSq ∧
                (∀ c : Fin d, rRead mx_p tblW (offW + (c.val : ℤ)) = euclideanCoord w c) ∧
                (∀ c : Fin d, c.val < k → rRead mx_p scrR (offOut + (c.val : ℤ)) =
                  ((Int.floor ((M_lat : ℝ) * euclideanCoord z c + 1 / 2) : ℤ) : ℝ)))
        ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctrs,
             by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hck_s,
             by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hlo_s,
             by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hhi_s,
             wRead_wWrite_self _ _ _ _,
             by simp only [rRead_wWrite]; exact ⟨hn_s, hw_s, hout_s⟩⟩)
        (by omega) (fun s1 _ ⟨hcs1, hck1, hlo1, hhi1, hmid1, hn1, hw1, hout1⟩ hfps1 => ?_)
      refine ExecScratch.seq' 109
        (ExecScratch.rSetScr inp (.lit (rBase + 2)) _ (rBase + 2) R_v
          hfps1 hscrR (by omega) (by omega) rfl
          (by change (((2 * wRead s1 scrW (wBase + 4) - ((2 * M_lat : ℕ) : ℤ) - 1 : ℤ)) : ℝ) = R_v; rw [hmid1]; dsimp [R_v])
          (by dsimp [intExprOps, realExprOps]; omega)
          (Post := fun mx_p => wRead mx_p scrW (wBase + 1) = (s : ℤ) ∧ wRead mx_p scrW wBase = (k : ℤ) ∧
                wRead mx_p scrW (wBase + 2) = (lh.1 : ℤ) ∧ wRead mx_p scrW (wBase + 3) = (lh.2 : ℤ) ∧
                wRead mx_p scrW (wBase + 4) = (mid : ℤ) ∧ rRead mx_p scrR rBase = normSq ∧
                rRead mx_p scrR (rBase + 2) = R_v ∧
                (∀ c : Fin d, rRead mx_p tblW (offW + (c.val : ℤ)) = euclideanCoord w c) ∧
                (∀ c : Fin d, c.val < k → rRead mx_p scrR (offOut + (c.val : ℤ)) =
                  ((Int.floor ((M_lat : ℝ) * euclideanCoord z c + 1 / 2) : ℤ) : ℝ)))
        ⟨by rw [wRead_rWrite]; exact hcs1, by rw [wRead_rWrite]; exact hck1,
             by rw [wRead_rWrite]; exact hlo1, by rw [wRead_rWrite]; exact hhi1,
             by rw [wRead_rWrite]; exact hmid1,
             by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hn1,
             rRead_rWrite_self _ _ _ _,
             hkeepW_B s1 hw1 (rBase + 2) ⟨by omega, by omega⟩ R_v,
             fun c hc => by
               have hc_lt := c.isLt
               rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hout1 c hc⟩)
        (by omega) (fun s2 _ ⟨hcs2, hck2, hlo2, hhi2, hmid2, hn2, hR2, hw2, hout2⟩ hfps2 => ?_)
      refine ExecScratch.seq' 95
        (ExecScratch.rSetScr inp (.lit (rBase + 1)) _ (rBase + 1) L_v
          hfps2 hscrR (by omega) (by omega) rfl
          (by change (((2 * M_lat : ℕ) : ℤ) : ℝ) * rRead s2 tblW (offW + wRead s2 scrW wBase) = L_v; rw [hck2]; have hw_ik : rRead s2 tblW (offW + (k : ℤ)) = euclideanCoord w ik := hw2 ik; rw [hw_ik]; dsimp [L_v]; push_cast; ring)
          (by dsimp [intExprOps, realExprOps]; omega)
          (Post := fun mx_p => wRead mx_p scrW (wBase + 1) = (s : ℤ) ∧ wRead mx_p scrW wBase = (k : ℤ) ∧
                wRead mx_p scrW (wBase + 2) = (lh.1 : ℤ) ∧ wRead mx_p scrW (wBase + 3) = (lh.2 : ℤ) ∧
                wRead mx_p scrW (wBase + 4) = (mid : ℤ) ∧ rRead mx_p scrR rBase = normSq ∧
                rRead mx_p scrR (rBase + 1) = L_v ∧ rRead mx_p scrR (rBase + 2) = R_v ∧
                (∀ c : Fin d, rRead mx_p tblW (offW + (c.val : ℤ)) = euclideanCoord w c) ∧
                (∀ c : Fin d, c.val < k → rRead mx_p scrR (offOut + (c.val : ℤ)) =
                  ((Int.floor ((M_lat : ℝ) * euclideanCoord z c + 1 / 2) : ℤ) : ℝ)))
        ⟨by rw [wRead_rWrite]; exact hcs2, by rw [wRead_rWrite]; exact hck2,
             by rw [wRead_rWrite]; exact hlo2, by rw [wRead_rWrite]; exact hhi2,
             by rw [wRead_rWrite]; exact hmid2,
             by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hn2,
             rRead_rWrite_self _ _ _ _,
             by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hR2,
             hkeepW_B s2 hw2 (rBase + 1) ⟨by omega, by omega⟩ L_v,
             fun c hc => by
               have hc_lt := c.isLt
               rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hout2 c hc⟩)
        (by omega) (fun s3 _ ⟨hcs3, hck3, hlo3, hhi3, hmid3, hn3, hL3, hR3, hw3, hout3⟩ hfps3 => ?_)
      have hcmp_step : ExecScratch TW BW TR BR scrW scrR inp
          (evalSignedSqCondStmt scrW scrR (rBase + 1) (rBase + 2) rBase (wBase + 5)) s3
          (fun s4 => open Classical in
            wRead s4 scrW (wBase + 1) = (s : ℤ) ∧ wRead s4 scrW wBase = (k : ℤ) ∧
            wRead s4 scrW (wBase + 2) = (lh.1 : ℤ) ∧ wRead s4 scrW (wBase + 3) = (lh.2 : ℤ) ∧
            wRead s4 scrW (wBase + 4) = (mid : ℤ) ∧
            wRead s4 scrW (wBase + 5) = (if latCmp M_lat w ik mid then 1 else 0) ∧
            rRead s4 scrR rBase = normSq ∧
            (∀ c : Fin d, rRead s4 tblW (offW + (c.val : ℤ)) = euclideanCoord w c) ∧
            (∀ c : Fin d, c.val < k → rRead s4 scrR (offOut + (c.val : ℤ)) =
              ((Int.floor ((M_lat : ℝ) * euclideanCoord z c + 1 / 2) : ℤ) : ℝ))) 80 := by
        classical
        unfold evalSignedSqCondStmt
        refine ExecScratch.ite (C_c := 70) (C_b := 10) _ _ _
          (by dsimp [condExprOps, realExprOps, intExprOps]; omega) ?_ ?_
        · intro ht_c
          have hP : latCmp M_lat w ik mid := by
            simp only [evalArithCond, evalRealExpr, evalIntExpr, mem_reals_read_heap, hL3, hR3, hn3,
              Int.cast_zero, ← sq, Bool.or_eq_true, Bool.and_eq_true, decide_eq_true_eq] at ht_c
            exact ht_c
          refine ExecScratch.wSetScr inp (.lit (wBase + 5)) (.lit 1) (wBase + 5) 1
            hfps3 hscrW (by omega) (by omega) rfl rfl (by dsimp [intExprOps]; omega) ?_
          rw [if_pos hP]
          exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hcs3,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hck3,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hlo3,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hhi3,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hmid3,
                 wRead_wWrite_self _ _ _ _,
                 by simp only [rRead_wWrite]; exact ⟨hn3, hw3, hout3⟩⟩
        · intro hf_c
          have hP : ¬ latCmp M_lat w ik mid := by
            simp only [evalArithCond, evalRealExpr, evalIntExpr, mem_reals_read_heap, hL3, hR3, hn3,
              Int.cast_zero, ← sq, Bool.or_eq_false_iff, Bool.and_eq_false_iff, decide_eq_false_iff_not] at hf_c
            intro h; rcases h with ⟨h1, h2, h3⟩ | ⟨h1, h2 | h3⟩
            · rcases hf_c.1 with n1 | n2 | n3
              · exact n1 h1
              · exact n2 h2
              · exact n3 h3
            · rcases hf_c.2 with n1 | ⟨n2, _⟩
              · exact n1 h1
              · exact n2 h2
            · rcases hf_c.2 with n1 | ⟨_, n3⟩
              · exact n1 h1
              · exact n3 h3
          refine ExecScratch.wSetScr inp (.lit (wBase + 5)) (.lit 0) (wBase + 5) 0
            hfps3 hscrW (by omega) (by omega) rfl rfl (by dsimp [intExprOps]; omega) ?_
          rw [if_neg hP]
          exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hcs3,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hck3,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hlo3,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hhi3,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hmid3,
                 wRead_wWrite_self _ _ _ _,
                 by simp only [rRead_wWrite]; exact ⟨hn3, hw3, hout3⟩⟩
      refine ExecScratch.seq' 15 hcmp_step (by omega)
        (fun s4 _ ⟨hcs4, hck4, hlo4, hhi4, hmid4, hcmp4, hn4, hw4, hout4⟩ hfps4 => ?_)
      refine ExecScratch.ite (C_c := 5) (C_b := 10) _ _ _
        (by dsimp [condExprOps, intExprOps]; omega) ?_ ?_
      · intro h1_t
        have hlat : latCmp M_lat w ik mid := by
          classical
          simp only [evalArithCond, evalIntExpr, mem_words_read_heap, hcmp4, decide_eq_true_eq] at h1_t
          by_contra hnc; rw [if_neg hnc] at h1_t; omega
        refine ExecScratch.wSetScr inp (.lit (wBase + 2)) _ (wBase + 2) (mid : ℤ)
          hfps4 hscrW (by omega) (by omega) rfl hmid4
          (by dsimp [intExprOps]; omega) ?_
        dsimp only
        rw [Function.iterate_succ_apply']
        change wRead _ scrW (wBase + 1) = (s : ℤ) ∧ wRead _ scrW wBase = (k : ℤ) ∧
          wRead _ scrW (wBase + 2) = ((latBisectStep M_lat w ik lh).1 : ℤ) ∧
          wRead _ scrW (wBase + 3) = ((latBisectStep M_lat w ik lh).2 : ℤ) ∧ _
        unfold latBisectStep; rw [if_neg hgt1, if_pos hlat]
        exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hcs4,
               by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hck4,
               wRead_wWrite_self _ _ _ _,
               by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hhi4,
               by simp only [rRead_wWrite]; exact ⟨hn4, hw4, hout4⟩⟩
      · intro h1_f
        have hlat : ¬ latCmp M_lat w ik mid := by
          classical
          simp only [evalArithCond, evalIntExpr, mem_words_read_heap, hcmp4, decide_eq_false_iff_not] at h1_f
          intro hc; apply h1_f; rw [if_pos hc]
        refine ExecScratch.wSetScr inp (.lit (wBase + 3)) _ (wBase + 3) (mid : ℤ)
          hfps4 hscrW (by omega) (by omega) rfl hmid4
          (by dsimp [intExprOps]; omega) ?_
        dsimp only
        rw [Function.iterate_succ_apply']
        change wRead _ scrW (wBase + 1) = (s : ℤ) ∧ wRead _ scrW wBase = (k : ℤ) ∧
          wRead _ scrW (wBase + 2) = ((latBisectStep M_lat w ik lh).1 : ℤ) ∧
          wRead _ scrW (wBase + 3) = ((latBisectStep M_lat w ik lh).2 : ℤ) ∧ _
        unfold latBisectStep; rw [if_neg hgt1, if_neg hlat]
        exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hcs4,
               by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hck4,
               by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hlo4,
               wRead_wWrite_self _ _ _ _,
               by simp only [rRead_wWrite]; exact ⟨hn4, hw4, hout4⟩⟩
  · have hfl_eq := latBisect_eq_floor hS hw_ne ik
    dsimp only at hfl_eq
    refine ExecScratch.rSetScr inp (.add (.lit offOut) (.readHeap scrW (.lit wBase))) _
      (offOut + (k : ℤ)) (((Int.floor ((M_lat : ℝ) * euclideanCoord z ik + 1 / 2) : ℤ) : ℝ))
      hfp_c hscrR (by omega) (by omega)
      (by change offOut + wRead mc scrW wBase = offOut + (k : ℤ); rw [hck_c])
      (by change ((wRead mc scrW (wBase + 2) - (M_lat : ℤ) : ℤ) : ℝ) = _; rw [hlo_c]; exact congrArg Int.cast hfl_eq)
      (by dsimp [intExprOps, realExprOps]; omega)
      ⟨by rw [wRead_rWrite]; exact hck_c,
       by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hn_c,
       hkeepW_O mc hw_c k hk _,
       fun c hc => ?_⟩
    rcases Nat.lt_succ_iff_lt_or_eq.mp hc with hlt | heq
    · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hout_c c hlt
    · have hc_eq : c = ik := Fin.ext heq
      subst hc_eq
      exact rRead_rWrite_self _ _ _ _

/-! ### 7. `sqrt`-free shell binary search & directional correlation equivalences -/

noncomputable def shellBisectStep (m0 : ℕ) (V distSq : ℝ) (lh : ℕ × ℕ) : ℕ × ℕ :=
  open Classical in
  if lh.2 ≤ lh.1 + 1 then lh
  else if (((lh.1 + lh.2) / 2 : ℕ) : ℝ) ^ 2 * V ≤ (m0 : ℝ) ^ 2 * distSq then
    ((lh.1 + lh.2) / 2, lh.2)
  else
    (lh.1, (lh.1 + lh.2) / 2)

theorem shellBisect_eq_floor {m0 : ℕ} (_hm0 : 1 ≤ m0) {V distSq : ℝ}
    (hV : 0 < V) (hd0 : 0 ≤ distSq) {K_max S_sh : ℕ}
    (hd_ub : (m0 : ℝ) ^ 2 * distSq < ((K_max + 1 : ℕ) : ℝ) ^ 2 * V)
    (hS : K_max + 1 ≤ 2 ^ S_sh) :
    ((shellBisectStep m0 V distSq)^[S_sh] (0, K_max + 1)).1 =
      Nat.floor ((m0 : ℝ) * Real.sqrt distSq / Real.sqrt V) := by
  let j_out := ((shellBisectStep m0 V distSq)^[S_sh] (0, K_max + 1)).1
  have hinv : ∀ s ≤ S_sh,
      let lh := (shellBisectStep m0 V distSq)^[s] (0, K_max + 1)
      lh.1 < lh.2 ∧
      lh.2 - lh.1 ≤ 2 ^ (S_sh - s) ∧
      (lh.1 : ℝ) ^ 2 * V ≤ (m0 : ℝ) ^ 2 * distSq ∧
      (m0 : ℝ) ^ 2 * distSq < (lh.2 : ℝ) ^ 2 * V := by
    intro s
    induction s with
    | zero =>
      intro _
      simp only [Function.iterate_zero, id_eq, Nat.sub_zero]
      exact ⟨by omega, by omega, by simp; positivity, hd_ub⟩
    | succ s ih =>
      intro hs
      rw [Function.iterate_succ_apply']
      obtain ⟨hlt, hdiff, hlo, hhi⟩ := ih (by omega)
      set lh := (shellBisectStep m0 V distSq)^[s] (0, K_max + 1)
      have hpow : 2 ^ (S_sh - s) = 2 * 2 ^ (S_sh - (s + 1)) := by
        have : S_sh - s = (S_sh - (s + 1)) + 1 := by omega
        rw [this, pow_succ']
      unfold shellBisectStep
      split_ifs with h1 hmid
      · exact ⟨hlt, by omega, hlo, hhi⟩
      · refine ⟨by omega, ?_, hmid, hhi⟩; rw [hpow] at hdiff; omega
      · push_neg at hmid
        refine ⟨by omega, ?_, hlo, hmid⟩; rw [hpow] at hdiff; omega
  obtain ⟨hlt_f, hdiff_f, hlo_f, hhi_f⟩ := hinv S_sh le_rfl
  simp only [Nat.sub_self, pow_zero] at hdiff_f
  have hhi_eq : ((shellBisectStep m0 V distSq)^[S_sh] (0, K_max + 1)).2 = j_out + 1 := by
    dsimp [j_out] at hlt_f hdiff_f ⊢; omega
  rw [hhi_eq] at hhi_f
  have hsq_eq : ((m0 : ℝ) * Real.sqrt distSq / Real.sqrt V) ^ 2 * V = (m0 : ℝ) ^ 2 * distSq := by
    rw [div_pow, mul_pow, Real.sq_sqrt hd0, Real.sq_sqrt hV.le]
    field_simp [hV.ne']
  have hlo_le : (j_out : ℝ) ≤ (m0 : ℝ) * Real.sqrt distSq / Real.sqrt V := by
    rw [← hsq_eq] at hlo_f
    have hsq_le : (j_out : ℝ) ^ 2 ≤ ((m0 : ℝ) * Real.sqrt distSq / Real.sqrt V) ^ 2 :=
      le_of_mul_le_mul_right hlo_f hV
    exact nonneg_le_nonneg_of_sq_le_sq (by positivity) (by rwa [← sq, ← sq])
  have hlt_hi : (m0 : ℝ) * Real.sqrt distSq / Real.sqrt V < ((j_out + 1 : ℕ) : ℝ) := by
    rw [← hsq_eq] at hhi_f
    have hsq_lt : ((m0 : ℝ) * Real.sqrt distSq / Real.sqrt V) ^ 2 < ((j_out + 1 : ℕ) : ℝ) ^ 2 :=
      lt_of_mul_lt_mul_right hhi_f hV.le
    by_contra hge; push_neg at hge
    have := pow_le_pow_left₀ (by positivity) hge 2
    linarith only [hsq_lt, this]
  exact ((Nat.floor_eq_iff (by positivity)).mpr ⟨hlo_le, by push_cast at hlt_hi; exact hlt_hi⟩).symm

theorem coreBall_iff_sq {d : ℕ} (o p : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 ≤ V) :
    p ∈ coreBall o V ↔ ‖p - o‖ ^ 2 ≤ V := by
  unfold coreBall
  rw [Metric.mem_closedBall, dist_eq_norm]
  conv_rhs => rw [← Real.sq_sqrt hV]
  exact ⟨fun h => pow_le_pow_left₀ (norm_nonneg _) h 2,
         fun h => nonneg_le_nonneg_of_sq_le_sq (Real.sqrt_nonneg V) (by rwa [← sq, ← sq])⟩

theorem isEligiblePoint_iff_sq {d : ℕ} (o p : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 ≤ V)
    {K : ℤ} (hK : 0 ≤ K) :
    IsEligiblePoint o V K p ↔ ‖p - o‖ ^ 2 ≤ (K : ℝ) ^ 2 * V := by
  unfold IsEligiblePoint
  have hrhs_nn : 0 ≤ (K : ℝ) * Real.sqrt V := mul_nonneg (by exact_mod_cast hK) (Real.sqrt_nonneg V)
  have hsq : ((K : ℝ) * Real.sqrt V) ^ 2 = (K : ℝ) ^ 2 * V := by
    rw [mul_pow, Real.sq_sqrt hV]
  rw [← hsq]
  exact ⟨fun h => pow_le_pow_left₀ (norm_nonneg _) h 2,
         fun h => nonneg_le_nonneg_of_sq_le_sq hrhs_nn (by rwa [← sq, ← sq])⟩

theorem radialCorrelation_gt_iff {d : ℕ} (o x y : EuclideanSpace ℝ (Fin d))
    (hx : x ≠ o) (hy : y ≠ o) (b : ℝ) :
    let D_xy : ℝ := ∑ c : Fin d, (euclideanCoord o c - euclideanCoord x c) *
                                  (euclideanCoord y c - euclideanCoord o c)
    let Nx : ℝ := ∑ c : Fin d, (euclideanCoord x c - euclideanCoord o c) ^ 2
    let Ny : ℝ := ∑ c : Fin d, (euclideanCoord y c - euclideanCoord o c) ^ 2
    b < radialCorrelation o x y ↔
      (0 ≤ b ∧ 0 < D_xy ∧ b ^ 2 * (Nx * Ny) < D_xy ^ 2) ∨
      (b < 0 ∧ (0 ≤ D_xy ∨ D_xy ^ 2 < b ^ 2 * (Nx * Ny))) := by
  intro D_xy Nx Ny
  have hx_pos : 0 < ‖x - o‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hx)
  have hy_pos : 0 < ‖y - o‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hy)
  have hNx_eq : Nx = ‖x - o‖ ^ 2 := by
    rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
    refine Finset.sum_congr rfl fun c _ => by simp [euclideanCoord, sq]
  have hNy_eq : Ny = ‖y - o‖ ^ 2 := by
    rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
    refine Finset.sum_congr rfl fun c _ => by simp [euclideanCoord, sq]
  have hrc : radialCorrelation o x y = D_xy / (‖x - o‖ * ‖y - o‖) := by
    unfold radialCorrelation radialDirection
    rw [PiLp.inner_apply]
    have hterm : ∀ c : Fin d,
        inner ℝ ((-(‖x - o‖⁻¹ • (x - o))) c) ((‖y - o‖⁻¹ • (y - o)) c) =
          ((euclideanCoord o c - euclideanCoord x c) *
            (euclideanCoord y c - euclideanCoord o c)) / (‖x - o‖ * ‖y - o‖) := by
      intro c
      simp only [euclideanCoord, WithLp.equiv_apply, PiLp.neg_apply, PiLp.smul_apply,
        PiLp.sub_apply, smul_eq_mul, RCLike.inner_apply, conj_trivial]
      field_simp [hx_pos.ne', hy_pos.ne']
      ring
    simp_rw [hterm, ← Finset.sum_div]
    rfl
  let W_prod : ℝ := ‖x - o‖ * ‖y - o‖
  have hW_pos : 0 < W_prod := mul_pos hx_pos hy_pos
  have hW2 : W_prod ^ 2 = Nx * Ny := by dsimp [W_prod]; rw [mul_pow, hNx_eq, hNy_eq]
  rw [hrc, lt_div_iff₀ hW_pos, ← hW2]
  constructor
  · intro hlt
    by_cases hb0 : 0 ≤ b
    · left
      have hbw_nn : 0 ≤ b * W_prod := mul_nonneg hb0 hW_pos.le
      have hD_pos : 0 < D_xy := lt_of_le_of_lt hbw_nn hlt
      refine ⟨hb0, hD_pos, ?_⟩
      have hsq : (b * W_prod) ^ 2 < D_xy ^ 2 := by nlinarith only [hlt, hbw_nn]
      rwa [mul_pow] at hsq
    · right
      push_neg at hb0
      refine ⟨hb0, ?_⟩
      by_cases hD0 : 0 ≤ D_xy
      · exact Or.inl hD0
      · right
        push_neg at hD0
        have hsq : D_xy ^ 2 < (b * W_prod) ^ 2 := by nlinarith only [hlt, hD0]
        rwa [mul_pow] at hsq
  · rintro (⟨hb0, hD_pos, hsq⟩ | ⟨hb0, hD0 | hsq⟩)
    · rw [← mul_pow] at hsq
      by_contra hge; push_neg at hge
      have := pow_le_pow_left₀ hD_pos.le hge 2
      linarith only [hsq, this]
    · have hbw_neg : b * W_prod < 0 := mul_neg_of_neg_of_pos hb0 hW_pos
      linarith only [hbw_neg, hD0]
    · rw [← mul_pow] at hsq
      have hbw_neg : b * W_prod < 0 := mul_neg_of_neg_of_pos hb0 hW_pos
      by_contra hge; push_neg at hge
      have hneg_le : -(b * W_prod) ≤ -D_xy := neg_le_neg hge
      have h1 := pow_le_pow_left₀ (by linarith only [hbw_neg]) hneg_le 2
      rw [neg_sq, neg_sq] at h1
      linarith only [hsq, h1]

end UL.Proof.clm_9_1_explicit_tradeoff.H3b2
