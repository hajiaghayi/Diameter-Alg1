import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.clm_7_3_global_approx
import UL.Stmt.lem_9_1
import UL.Proof.clm_5_3_matching_invariant.H1
import UL.Proof.claim_C_2_space_reclaim.H2a_DataStructs
import UL.Proof.clm_9_1_explicit_tradeoff.H3b1_PolyCDF
import UL.Proof.clm_9_1_explicit_tradeoff.H4a1_FilterPure
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H4b

open UL
open UL.Proof_clm_5_3_matching_invariant
open UL.Proof.claim_C_2_space_reclaim
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1

/-! ### 1. Product Coin Space Cardinality Lemma -/

private lemma one_sub_mul_le_pow :
    ∀ (k : ℕ) {x : ℝ}, 0 ≤ x → x ≤ 1 → 1 - (k : ℝ) * x ≤ (1 - x) ^ k
  | 0, _, _, _ => by simp
  | k + 1, x, hx0, hx1 => by
      have ih := one_sub_mul_le_pow k hx0 hx1
      have hmul : (1 - (k : ℝ) * x) * (1 - x) ≤ (1 - x) ^ (k + 1) := by
        rw [pow_succ]
        exact mul_le_mul_of_nonneg_right ih (by linarith only [hx1])
      have hexp : 1 - ((k + 1 : ℕ) : ℝ) * x ≤ (1 - (k : ℝ) * x) * (1 - x) := by
        have hnn : 0 ≤ (k : ℝ) * (x * x) := by positivity
        push_cast
        linarith only [hnn]
      exact hexp.trans hmul

/-- General union bound over an arbitrary finite product of independent coin spaces. -/
theorem pi_good_card_ge {κ : Type*} [Fintype κ] [DecidableEq κ]
    {Ω : κ → Type*} [∀ i, Fintype (Ω i)]
    (P : ∀ i, Ω i → Prop) [∀ i, DecidablePred (P i)]
    {φ : ℝ} (hφ0 : 0 ≤ φ) (hφ1 : φ ≤ 1)
    (hcard : ∀ i, (1 - φ) * (Fintype.card (Ω i) : ℝ) ≤
      ((Finset.univ.filter (P i)).card : ℝ)) :
    (1 - (Fintype.card κ : ℝ) * φ) * (Fintype.card (∀ i, Ω i) : ℝ) ≤
      ((Finset.univ.filter (fun ω : ∀ i, Ω i => ∀ i, P i (ω i))).card : ℝ) := by
  have hpi_eq :
      (Finset.univ.filter (fun ω : ∀ i, Ω i => ∀ i, P i (ω i))) =
        Fintype.piFinset (fun i => Finset.univ.filter (P i)) := by
    ext ω
    simp [Fintype.mem_piFinset]
  rw [hpi_eq, Fintype.card_piFinset, Fintype.card_pi]
  push_cast
  have hprod :
      (∏ _i : κ, (1 - φ)) * (∏ i : κ, (Fintype.card (Ω i) : ℝ)) ≤
        ∏ i : κ, ((Finset.univ.filter (P i)).card : ℝ) := by
    rw [← Finset.prod_mul_distrib]
    refine Finset.prod_le_prod (fun i _ => ?_) (fun i _ => hcard i)
    exact mul_nonneg (by linarith only [hφ1]) (Nat.cast_nonneg _)
  rw [Finset.prod_const, Finset.card_univ] at hprod
  have hbern : 1 - (Fintype.card κ : ℝ) * φ ≤ (1 - φ) ^ Fintype.card κ :=
    one_sub_mul_le_pow (Fintype.card κ) hφ0 hφ1
  have hcard_nn : 0 ≤ (∏ i : κ, (Fintype.card (Ω i) : ℝ)) :=
    Finset.prod_nonneg (fun _ _ => Nat.cast_nonneg _)
  exact (mul_le_mul_of_nonneg_right hbern hcard_nn).trans hprod

/-! ### 2. Variance-Invariance (`0 < V`) of `retainedConfigs`, `thresholdA`, and `thresholdB` -/

theorem params_K_pos (params : LocalScaleParams) : 0 < params.K := by
  have hc : 0 < 2 / (params.c - 1) := div_pos zero_lt_two (sub_pos.mpr params.one_lt_c)
  have hKr : (0 : ℝ) < (params.K : ℝ) := lt_of_lt_of_le hc params.K_ge
  exact_mod_cast hKr

theorem params_m0_pos (params : LocalScaleParams) : 1 ≤ params.m0 := by
  unfold LocalScaleParams.m0 shellSubdiv
  exact Nat.ceil_pos.mpr (one_div_pos.mpr (by exact_mod_cast params.e_pos))

theorem retainedConfig_shells_pos (params : LocalScaleParams) {V : ℝ} {cfg : ShellConfig}
    (hcfg : cfg ∈ params.retainedConfigs V) :
    1 ≤ cfg.j ∧ cfg.j ≤ params.m0 ∧ 1 ≤ cfg.k ∧ cfg.k ≤ params.maxShellIndex ∧ cfg.ℓ ≤ params.J := by
  classical
  unfold LocalScaleParams.retainedConfigs retainedConfigs at hcfg
  rcases Finset.mem_filter.mp hcfg with ⟨hall, _⟩
  unfold allShellConfigs allShellConfigTriples at hall
  rcases Finset.mem_map.mp hall with ⟨⟨j, k, ℓ⟩, hmem, hEq⟩
  simp only [Function.Embedding.coeFn_mk] at hEq
  subst hEq
  simp only [Finset.mem_product, Finset.mem_Icc, zero_le, true_and] at hmem
  exact ⟨hmem.1.1, hmem.1.2, hmem.2.1.1, hmem.2.1.2, hmem.2.2⟩

private lemma shellRadius_eq_mul_sqrt (m0 : ℕ) {V : ℝ} (j : ℕ) :
    shellRadius m0 V j = shellRadius m0 1 j * Real.sqrt V := by
  unfold shellRadius
  simp [Real.sqrt_one]

private lemma distScale_eq_mul_sqrt (lam : ℚ) {V : ℝ} (ℓ : ℕ) :
    distScale lam V ℓ = distScale lam 1 ℓ * Real.sqrt V := by
  unfold distScale
  simp [Real.sqrt_one]
  ring

theorem retainedConfigs_eq_one (params : LocalScaleParams) {V : ℝ} (hV : 0 < V) :
    params.retainedConfigs V = params.retainedConfigs 1 := by
  classical
  have hsq : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV
  have hsq2 : 0 < Real.sqrt V ^ 2 := sq_pos_of_pos hsq
  unfold LocalScaleParams.retainedConfigs retainedConfigs
  ext cfg
  simp only [Finset.mem_filter, and_congr_right_iff]
  intro _
  unfold ShellConfig.SatisfiesRetention SatisfiesRetentionCond
  rw [shellRadius_eq_mul_sqrt, shellRadius_eq_mul_sqrt _ cfg.k, distScale_eq_mul_sqrt]
  have h1 :
      (shellRadius (shellSubdiv params.e) 1 cfg.j * Real.sqrt V) ^ 2 +
        (shellRadius (shellSubdiv params.e) 1 cfg.k * Real.sqrt V) ^ 2 =
      (shellRadius (shellSubdiv params.e) 1 cfg.j ^ 2 +
        shellRadius (shellSubdiv params.e) 1 cfg.k ^ 2) * (Real.sqrt V ^ 2) := by ring
  have h2 :
      (distScale params.lam 1 cfg.ℓ * Real.sqrt V) ^ 2 =
        (distScale params.lam 1 cfg.ℓ ^ 2) * (Real.sqrt V ^ 2) := by ring
  have h3 :
      (params.γ : ℝ) * (distScale params.lam 1 cfg.ℓ * Real.sqrt V) =
        ((params.γ : ℝ) * distScale params.lam 1 cfg.ℓ) * Real.sqrt V := by ring
  have h4 :
      shellRadius (shellSubdiv params.e) 1 cfg.j * Real.sqrt V +
        shellRadius (shellSubdiv params.e) 1 cfg.k * Real.sqrt V =
      (shellRadius (shellSubdiv params.e) 1 cfg.j +
        shellRadius (shellSubdiv params.e) 1 cfg.k) * Real.sqrt V := by ring
  rw [h1, h2, h3, h4, mul_le_mul_iff_left₀ hsq2, mul_le_mul_iff_left₀ hsq]

theorem thresholdA_eq_one (params : LocalScaleParams) {V : ℝ} (hV : 0 < V) (j k ℓ : ℕ) :
    params.thresholdA V j k ℓ = params.thresholdA 1 j k ℓ := by
  have hsq : Real.sqrt V ≠ 0 := (Real.sqrt_pos.mpr hV).ne'
  have hsq2 : Real.sqrt V ^ 2 ≠ 0 := pow_ne_zero 2 hsq
  unfold LocalScaleParams.thresholdA configThresholdA
  rw [shellRadius_eq_mul_sqrt, shellRadius_eq_mul_sqrt _ k, distScale_eq_mul_sqrt]
  have hnum :
      (params.γ : ℝ) ^ 2 * (distScale params.lam 1 ℓ * Real.sqrt V) ^ 2 -
        (shellRadius params.m0 1 j * Real.sqrt V) ^ 2 -
        (shellRadius params.m0 1 k * Real.sqrt V) ^ 2 =
      ((params.γ : ℝ) ^ 2 * distScale params.lam 1 ℓ ^ 2 -
        shellRadius params.m0 1 j ^ 2 - shellRadius params.m0 1 k ^ 2) * (Real.sqrt V ^ 2) := by
    ring
  have hden :
      2 * (shellRadius params.m0 1 j * Real.sqrt V) * (shellRadius params.m0 1 k * Real.sqrt V) =
      (2 * shellRadius params.m0 1 j * shellRadius params.m0 1 k) * (Real.sqrt V ^ 2) := by
    ring
  rw [hnum, hden, mul_div_mul_right _ _ hsq2]

/-- Exact variance-independent rational weak-edge correlation threshold `b` of `cfg`. -/
def bRatCfg (params : LocalScaleParams) (cfg : ShellConfig) : ℚ :=
  let m0 : ℚ := (params.m0 : ℚ)
  let rj : ℚ := (cfg.j : ℚ) / m0
  let rk : ℚ := (cfg.k : ℚ) / m0
  let Rl : ℚ := params.lam ^ cfg.ℓ / 2
  (Rl ^ 2 - rj ^ 2 - rk ^ 2) / (2 * rj * rk)

theorem thresholdB_eq_bRatCfg (params : LocalScaleParams) {V : ℝ} (hV : 0 < V)
    (cfg : ShellConfig) :
    params.thresholdB V cfg.j cfg.k cfg.ℓ = (bRatCfg params cfg : ℝ) := by
  have hsq : Real.sqrt V ≠ 0 := (Real.sqrt_pos.mpr hV).ne'
  have hsq2 : Real.sqrt V ^ 2 ≠ 0 := pow_ne_zero 2 hsq
  unfold LocalScaleParams.thresholdB configThresholdB
  rw [shellRadius_eq_mul_sqrt, shellRadius_eq_mul_sqrt _ cfg.k, distScale_eq_mul_sqrt]
  have hnum :
      (distScale params.lam 1 cfg.ℓ * Real.sqrt V) ^ 2 -
        (shellRadius params.m0 1 cfg.j * Real.sqrt V) ^ 2 -
        (shellRadius params.m0 1 cfg.k * Real.sqrt V) ^ 2 =
      (distScale params.lam 1 cfg.ℓ ^ 2 -
        shellRadius params.m0 1 cfg.j ^ 2 - shellRadius params.m0 1 cfg.k ^ 2) * (Real.sqrt V ^ 2) := by
    ring
  have hden :
      2 * (shellRadius params.m0 1 cfg.j * Real.sqrt V) *
        (shellRadius params.m0 1 cfg.k * Real.sqrt V) =
      (2 * shellRadius params.m0 1 cfg.j * shellRadius params.m0 1 cfg.k) * (Real.sqrt V ^ 2) := by
    ring
  rw [hnum, hden, mul_div_mul_right _ _ hsq2]
  unfold bRatCfg shellRadius distScale
  simp [Real.sqrt_one]

theorem thresholdB_le_thresholdA (params : LocalScaleParams) {V : ℝ} (hV : 0 < V)
    (cfg : ShellConfig) :
    params.thresholdB V cfg.j cfg.k cfg.ℓ ≤ params.thresholdA V cfg.j cfg.k cfg.ℓ := by
  unfold LocalScaleParams.thresholdB LocalScaleParams.thresholdA configThresholdB configThresholdA
  have hγ1 : (1 : ℝ) ≤ (params.γ : ℝ) := le_of_lt (by exact_mod_cast params.one_lt_γ)
  have hγ2 : (1 : ℝ) ≤ (params.γ : ℝ) ^ 2 := by nlinarith only [hγ1]
  have hd2 : 0 ≤ distScale params.lam V cfg.ℓ ^ 2 := sq_nonneg _
  have hnum :
      distScale params.lam V cfg.ℓ ^ 2 - shellRadius params.m0 V cfg.j ^ 2 -
        shellRadius params.m0 V cfg.k ^ 2 ≤
      (params.γ : ℝ) ^ 2 * distScale params.lam V cfg.ℓ ^ 2 -
        shellRadius params.m0 V cfg.j ^ 2 - shellRadius params.m0 V cfg.k ^ 2 := by
    nlinarith only [hγ2, hd2]
  have hrj : 0 ≤ shellRadius params.m0 V cfg.j := by
    unfold shellRadius; positivity
  have hrk : 0 ≤ shellRadius params.m0 V cfg.k := by
    unfold shellRadius; positivity
  exact div_le_div_of_nonneg_right hnum (by positivity)

theorem ne_center_of_shellIndex_pos {d m0 : ℕ} {o p : EuclideanSpace ℝ (Fin d)} {V : ℝ}
    {s : ℕ} (hs : 1 ≤ s) (hsh : shellIndex m0 o V p = s) : p ≠ o := by
  intro heq
  subst heq
  unfold shellIndex at hsh
  simp at hsh
  omega

/-! ### 3. 2-Slot Ring-Buffer Binary Epoch Coverage Theorem -/

private lemma mod_two_mul_eq (t B' : ℕ) :
    t % (2 * B') = 2 * ((t / 2) % B') + t % 2 := by
  by_cases hB : B' = 0
  · subst hB; simp; omega
  · have hpos : 0 < 2 * B' := by omega
    have h1 : t = 2 * (t / 2) + t % 2 := (Nat.div_add_mod t 2).symm
    have h2 : t / 2 = B' * ((t / 2) / B') + (t / 2) % B' := (Nat.div_add_mod (t / 2) B').symm
    have hrem_lt : 2 * ((t / 2) % B') + t % 2 < 2 * B' := by
      have hm1 : (t / 2) % B' < B' := Nat.mod_lt _ (by omega)
      have hm2 : t % 2 < 2 := Nat.mod_lt _ (by decide)
      omega
    have heq : t = (2 * B') * ((t / 2) / B') + (2 * ((t / 2) % B') + t % 2) := by
      calc t = 2 * (B' * ((t / 2) / B') + (t / 2) % B') + t % 2 := by rw [← h2]; exact h1
        _ = (2 * B') * ((t / 2) / B') + (2 * ((t / 2) % B') + t % 2) := by ring
    conv_lhs => rw [heq]
    rw [Nat.mul_add_mod, Nat.mod_eq_of_lt hrem_lt]

/-- Every arrival `eid < t < 2^{L_p2}` is covered either by the 2-element tail (`t ≤ eid + 2`)
or by one of the at most 2 ready blocks (`q - 1` when `off ≥ H`, and `q - 2` when `q ≥ 2`)
at some dyadic scale `s : Fin L_p2`. -/
theorem dyadicEpoch_coverage :
    ∀ (L_p2 t eid : ℕ), t < 2 ^ L_p2 → eid < t →
      t ≤ eid + 2 ∨
      ∃ s : Fin L_p2,
        let H := 2 ^ s.val
        let B := 2 * H
        let q := t / B
        let off := t % B
        (1 ≤ q ∧ H ≤ off ∧ (q - 1) * B ≤ eid ∧ eid < q * B) ∨
        (2 ≤ q ∧ (q - 2) * B ≤ eid ∧ eid < (q - 1) * B)
  | 0, t, eid, ht, heid => by
      simp only [pow_zero] at ht; omega
  | L_p2 + 1, t, eid, ht, heid => by
      by_cases htail : t ≤ eid + 2
      · exact Or.inl htail
      · right
        have hgap : eid + 3 ≤ t := by omega
        let q₀ := t / 2
        let off₀ := t % 2
        let eid' := eid / 2
        have ht_pow : t < 2 * 2 ^ L_p2 := by
          simpa [pow_succ, mul_comm] using ht
        have hq₀_lt : q₀ < 2 ^ L_p2 := by omega
        have heid'_lt : eid' < q₀ := by omega
        rcases dyadicEpoch_coverage L_p2 q₀ eid' hq₀_lt heid'_lt with htail' | ⟨s', hs'⟩
        · refine ⟨⟨0, Nat.succ_pos _⟩, ?_⟩
          dsimp only
          change (1 ≤ q₀ ∧ 1 ≤ off₀ ∧ (q₀ - 1) * 2 ≤ eid ∧ eid < q₀ * 2) ∨
            (2 ≤ q₀ ∧ (q₀ - 2) * 2 ≤ eid ∧ eid < (q₀ - 1) * 2)
          by_cases hq1 : q₀ = eid' + 1
          · left; omega
          · right; omega
        · refine ⟨s'.succ, ?_⟩
          dsimp only [Fin.val_succ]
          let H' := 2 ^ s'.val
          let B' := 2 * H'
          have hH_eq : 2 ^ (s'.val + 1) = 2 * H' := by rw [pow_succ]; ring
          rw [hH_eq]
          change (1 ≤ t / (2 * B') ∧ 2 * H' ≤ t % (2 * B') ∧
              (t / (2 * B') - 1) * (2 * B') ≤ eid ∧ eid < (t / (2 * B')) * (2 * B')) ∨
            (2 ≤ t / (2 * B') ∧
              (t / (2 * B') - 2) * (2 * B') ≤ eid ∧ eid < (t / (2 * B') - 1) * (2 * B'))
          have hq_eq : t / (2 * B') = q₀ / B' := by
            dsimp [q₀]; rw [Nat.div_div_eq_div_mul, mul_comm 2 B']
          have hoff_eq : t % (2 * B') = 2 * (q₀ % B') + off₀ := mod_two_mul_eq t B'
          have hoff₀_lt : off₀ < 2 := Nat.mod_lt t (by decide)
          have heid_div : eid = 2 * eid' + eid % 2 := (Nat.div_add_mod eid 2).symm
          have heid_mod : eid % 2 < 2 := Nat.mod_lt eid (by decide)
          rw [hq_eq, hoff_eq]
          rcases hs' with ⟨hq1, hoff1, hlo, hhi⟩ | ⟨hq2, hlo, hhi⟩
          · left
            have hoff1' : H' ≤ q₀ % B' := hoff1
            refine ⟨hq1, by omega, ?_, ?_⟩
            · calc (q₀ / B' - 1) * (2 * B') = 2 * ((q₀ / B' - 1) * B') := by ring
                _ ≤ 2 * eid' := Nat.mul_le_mul_left 2 hlo
                _ ≤ eid := by omega
            · have hhi' : eid' + 1 ≤ (q₀ / B') * B' := hhi
              calc eid = 2 * eid' + eid % 2 := heid_div
                _ < 2 * (eid' + 1) := by omega
                _ ≤ 2 * ((q₀ / B') * B') := Nat.mul_le_mul_left 2 hhi'
                _ = (q₀ / B') * (2 * B') := by ring
          · right
            refine ⟨hq2, ?_, ?_⟩
            · calc (q₀ / B' - 2) * (2 * B') = 2 * ((q₀ / B' - 2) * B') := by ring
                _ ≤ 2 * eid' := Nat.mul_le_mul_left 2 hlo
                _ ≤ eid := by omega
            · have hhi' : eid' + 1 ≤ (q₀ / B' - 1) * B' := hhi
              calc eid = 2 * eid' + eid % 2 := heid_div
                _ < 2 * (eid' + 1) := by omega
                _ ≤ 2 * ((q₀ / B' - 1) * B') := Nat.mul_le_mul_left 2 hhi'
                _ = (q₀ / B' - 1) * (2 * B') := by ring

/-! ### 4. Pure `DyadicSideIndex`: 2-Slot Ring Buffer + 2-Element Tail -/

/-- Non-dependent modulo-2 slot selector `Fin 2`. -/
def mod2Fin (x : ℕ) : Fin 2 := ⟨x % 2, Nat.mod_lt x (by decide)⟩

@[simp] lemma mod2Fin_val (x : ℕ) : (mod2Fin x).val = x % 2 := rfl

structure DyadicSideIndex (L_p2 R ℓ M₀ d b : ℕ) where
  t_ins : ℕ
  entryHandle : ℕ → ℕ
  entryPt : ℕ → EuclideanSpace ℝ (Fin d)
  entryAlive : ℕ → Bool
  activeEid : ℕ → ℕ
  slots : Fin L_p2 → Fin 2 → PureFilterSlot R ℓ M₀ d
  seeds : Fin L_p2 → Fin 2 → ExplicitBitSeed R ℓ M₀ (d + 1) b

noncomputable def DyadicSideIndex.empty (L_p2 R ℓ M₀ d b T p_coord : ℕ) :
    DyadicSideIndex L_p2 R ℓ M₀ d b :=
  { t_ins := 0
    entryHandle := fun _ => 0
    entryPt := fun _ => 0
    entryAlive := fun _ => false
    activeEid := fun _ => 0
    slots := fun _ _ => PureFilterSlot.init (b := b) T p_coord (fun _ => false)
    seeds := fun _ _ _ => false }

noncomputable def DyadicSideIndex.removeHandle {L_p2 R ℓ M₀ d b : ℕ}
    (h₀ : ℕ) (idx : DyadicSideIndex L_p2 R ℓ M₀ d b) :
    DyadicSideIndex L_p2 R ℓ M₀ d b :=
  let eid := idx.activeEid h₀
  if eid < idx.t_ins && idx.entryAlive eid && decide (idx.entryHandle eid = h₀) then
    { idx with entryAlive := Function.update idx.entryAlive eid false }
  else
    idx

noncomputable def DyadicSideIndex.insertHandle {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord : ℕ) (A B_rat τ_d : ℚ) (cap_u : ℕ)
    (o pt : EuclideanSpace ℝ (Fin d)) (h_new : ℕ)
    (ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (idx : DyadicSideIndex L_p2 R ℓ M₀ d b) :
    DyadicSideIndex L_p2 R ℓ M₀ d b :=
  let t := idx.t_ins
  let slots' : Fin L_p2 → Fin 2 → PureFilterSlot R ℓ M₀ d := fun s sl =>
    let H := 2 ^ s.val
    let B := 2 * H
    let q := t / B
    let off := t % B
    if 1 ≤ q ∧ off < H ∧ sl.val = (q - 1) % 2 then
      let blk := q - 1
      let e₀ := blk * B + 2 * off
      let e₁ := blk * B + 2 * off + 1
      let base := if off = 0 then PureFilterSlot.init T p_coord (ω_step s) else idx.slots s sl
      (base.insertPoint hM₀ A B_rat τ_d cap_u o (idx.entryPt e₀) e₀).insertPoint
        hM₀ A B_rat τ_d cap_u o (idx.entryPt e₁) e₁
    else
      idx.slots s sl
  let seeds' : Fin L_p2 → Fin 2 → ExplicitBitSeed R ℓ M₀ (d + 1) b := fun s sl =>
    let H := 2 ^ s.val
    let B := 2 * H
    let q := t / B
    let off := t % B
    if 1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2 then
      ω_step s
    else
      idx.seeds s sl
  { t_ins := t + 1
    entryHandle := Function.update idx.entryHandle t h_new
    entryPt := Function.update idx.entryPt t pt
    entryAlive := Function.update idx.entryAlive t true
    activeEid := Function.update idx.activeEid h_new t
    slots := slots'
    seeds := seeds' }

theorem insertHandle_slots_eq {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord : ℕ) (A B_rat τ_d : ℚ) (cap_u : ℕ)
    (o pt : EuclideanSpace ℝ (Fin d)) (h_new : ℕ)
    (ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (idx : DyadicSideIndex L_p2 R ℓ M₀ d b) (s : Fin L_p2) (sl : Fin 2) :
    (idx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o pt h_new ω_step).slots s sl =
      let H := 2 ^ s.val
      let B := 2 * H
      let q := idx.t_ins / B
      let off := idx.t_ins % B
      if 1 ≤ q ∧ off < H ∧ sl.val = (q - 1) % 2 then
        let blk := q - 1
        let e₀ := blk * B + 2 * off
        let e₁ := blk * B + 2 * off + 1
        let base := if off = 0 then PureFilterSlot.init T p_coord (ω_step s) else idx.slots s sl
        (base.insertPoint hM₀ A B_rat τ_d cap_u o (idx.entryPt e₀) e₀).insertPoint
          hM₀ A B_rat τ_d cap_u o (idx.entryPt e₁) e₁
      else
        idx.slots s sl := rfl

theorem insertHandle_seeds_eq {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord : ℕ) (A B_rat τ_d : ℚ) (cap_u : ℕ)
    (o pt : EuclideanSpace ℝ (Fin d)) (h_new : ℕ)
    (ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (idx : DyadicSideIndex L_p2 R ℓ M₀ d b) (s : Fin L_p2) (sl : Fin 2) :
    (idx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o pt h_new ω_step).seeds s sl =
      let H := 2 ^ s.val
      let B := 2 * H
      let q := idx.t_ins / B
      let off := idx.t_ins % B
      if 1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2 then
        ω_step s
      else
        idx.seeds s sl := rfl

noncomputable def DyadicSideIndex.query {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (M_lat : ℕ) (A B_rat τ_q : ℚ) (b_thr : ℝ) (cap_q : ℕ)
    (o p_v : EuclideanSpace ℝ (Fin d))
    (idx : DyadicSideIndex L_p2 R ℓ M₀ d b) : Option ℕ :=
  open Classical in
  let t := idx.t_ins
  let tail1 : Option ℕ :=
    if 1 ≤ t ∧ idx.entryAlive (t - 1) = true ∧
        b_thr < radialCorrelation o p_v (idx.entryPt (t - 1)) then
      some (idx.entryHandle (t - 1))
    else
      none
  match tail1 with
  | some w => some w
  | none =>
      let tail2 : Option ℕ :=
        if 2 ≤ t ∧ idx.entryAlive (t - 2) = true ∧
            b_thr < radialCorrelation o p_v (idx.entryPt (t - 2)) then
          some (idx.entryHandle (t - 2))
        else
          none
      match tail2 with
      | some w => some w
      | none =>
          (List.finRange L_p2).findSome? fun s =>
            let H := 2 ^ s.val
            let B := 2 * H
            let q := t / B
            let off := t % B
            let r1 : Option ℕ :=
              if 1 ≤ q ∧ H ≤ off then
                let sl : Fin 2 := mod2Fin (q - 1)
                ((idx.slots s sl).query hM₀ M_lat A B_rat τ_q b_thr cap_q
                  idx.entryPt o p_v idx.entryAlive).map idx.entryHandle
              else
                none
            match r1 with
            | some w => some w
            | none =>
                if 2 ≤ q then
                  let sl : Fin 2 := mod2Fin (q - 2)
                  ((idx.slots s sl).query hM₀ M_lat A B_rat τ_q b_thr cap_q
                    idx.entryPt o p_v idx.entryAlive).map idx.entryHandle
                else
                  none

/-- Deterministic representation & ring-buffer slot invariant (holds on ALL coin sequences). -/
def DyadicSideWF {L_p2 R ℓ M₀ d b : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (A B_rat τ_d : ℚ) (cap_u : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (U : Finset ℕ) (idx : DyadicSideIndex L_p2 R ℓ M₀ d b) : Prop :=
  (∀ eid < idx.t_ins, idx.entryPt eid ≠ o) ∧
  (∀ eid, idx.t_ins ≤ eid → idx.entryAlive eid = false) ∧
  (∀ h ∈ U,
    idx.activeEid h < idx.t_ins ∧
    idx.entryAlive (idx.activeEid h) = true ∧
    idx.entryHandle (idx.activeEid h) = h ∧
    idx.entryPt (idx.activeEid h) = pts h) ∧
  (∀ eid < idx.t_ins, idx.entryAlive eid = true →
    idx.entryHandle eid ∈ U ∧
    idx.activeEid (idx.entryHandle eid) = eid ∧
    idx.entryPt eid = pts (idx.entryHandle eid)) ∧
  (∀ s : Fin L_p2,
    let H := 2 ^ s.val
    let B := 2 * H
    let q := idx.t_ins / B
    let off := idx.t_ins % B
    (1 ≤ q → 1 ≤ off → off < H →
      idx.slots s (mod2Fin (q - 1)) =
        Fin.foldl (2 * off)
          (fun slot (j : Fin (2 * off)) =>
            let e_j := (q - 1) * B + j.val
            slot.insertPoint hM₀ A B_rat τ_d cap_u o (idx.entryPt e_j) e_j)
          (PureFilterSlot.init T p_coord (idx.seeds s (mod2Fin (q - 1))))) ∧
    (1 ≤ q → H ≤ off →
      idx.slots s (mod2Fin (q - 1)) =
        buildSlotOnBlock hM₀ T p_coord A B_rat τ_d cap_u idx.entryPt o
          (fun j : Fin B => (q - 1) * B + j.val) (idx.seeds s (mod2Fin (q - 1)))) ∧
    (2 ≤ q →
      idx.slots s (mod2Fin (q - 2)) =
        buildSlotOnBlock hM₀ T p_coord A B_rat τ_d cap_u idx.entryPt o
          (fun j : Fin B => (q - 2) * B + j.val) (idx.seeds s (mod2Fin (q - 2)))))

/-- Non-dependent good-seed invariant across all active/ready ring-buffer slots of `idx`. -/
def DyadicSideGood {L_p2 R ℓ M₀ d b : ℕ}
    (T p_coord M_lat : ℕ) (A B_rat τ_d τ_q : ℚ) (hAB : A ^ 2 + B_rat ^ 2 = 1)
    (h : ℝ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    (o : EuclideanSpace ℝ (Fin d))
    (idx : DyadicSideIndex L_p2 R ℓ M₀ d b) : Prop :=
  let hN : 1 ≤ 2 ^ L_p2 := Nat.one_le_two_pow
  let Q_net := paddedLatNet M_lat A B_rat
  ∀ s : Fin L_p2,
    let H := 2 ^ s.val
    let B := 2 * H
    let q := idx.t_ins / B
    let off := idx.t_ins % B
    (1 ≤ q → 1 ≤ off → off < H →
      ∀ (hne_arr : ∀ j : Fin B, idx.entryPt ((q - 1) * B + j.val) ≠ o),
      IsOrderIndepGoodFilter (polyFDisc T p_coord (idx.seeds s (mod2Fin (q - 1))))
        (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q
        (mkPaddedGeneration hN idx.entryPt o A B_rat hAB h hh0 hh1
          (fun j : Fin B => (q - 1) * B + j.val) hne_arr)
        Q_net) ∧
    (1 ≤ q → H ≤ off →
      ∀ (hne_arr : ∀ j : Fin B, idx.entryPt ((q - 1) * B + j.val) ≠ o),
      IsOrderIndepGoodFilter (polyFDisc T p_coord (idx.seeds s (mod2Fin (q - 1))))
        (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q
        (mkPaddedGeneration hN idx.entryPt o A B_rat hAB h hh0 hh1
          (fun j : Fin B => (q - 1) * B + j.val) hne_arr)
        Q_net) ∧
    (2 ≤ q →
      ∀ (hne_arr : ∀ j : Fin B, idx.entryPt ((q - 2) * B + j.val) ≠ o),
      IsOrderIndepGoodFilter (polyFDisc T p_coord (idx.seeds s (mod2Fin (q - 2))))
        (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q
        (mkPaddedGeneration hN idx.entryPt o A B_rat hAB h hh0 hh1
          (fun j : Fin B => (q - 2) * B + j.val) hne_arr)
        Q_net)

/-- Non-dependent pre-step good-seed predicate on `ω_step` when `insertHandle` runs on `idx`. -/
def StepSeedGood {L_p2 R ℓ M₀ d b : ℕ}
    (T p_coord M_lat : ℕ) (A B_rat τ_d τ_q : ℚ) (hAB : A ^ 2 + B_rat ^ 2 = 1)
    (h : ℝ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    (o : EuclideanSpace ℝ (Fin d))
    (idx : DyadicSideIndex L_p2 R ℓ M₀ d b)
    (ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b) : Prop :=
  let hN : 1 ≤ 2 ^ L_p2 := Nat.one_le_two_pow
  let Q_net := paddedLatNet M_lat A B_rat
  ∀ s : Fin L_p2,
    let H := 2 ^ s.val
    let B := 2 * H
    let q := idx.t_ins / B
    let off := idx.t_ins % B
    1 ≤ q → off = 0 →
      ∀ (hne_arr : ∀ j : Fin B, idx.entryPt ((q - 1) * B + j.val) ≠ o),
      IsOrderIndepGoodFilter (polyFDisc T p_coord (ω_step s))
        (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q
        (mkPaddedGeneration hN idx.entryPt o A B_rat hAB h hh0 hh1
          (fun j : Fin B => (q - 1) * B + j.val) hne_arr)
        Q_net

theorem dyadicSide_empty_wf {L_p2 R ℓ M₀ d b : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (A B_rat τ_d : ℚ) (cap_u : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) :
    DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o ∅
      (DyadicSideIndex.empty L_p2 R ℓ M₀ d b T p_coord) := by
  refine ⟨fun _ h => by simp [DyadicSideIndex.empty] at h,
    fun _ _ => rfl,
    fun _ h => absurd h (Finset.notMem_empty _),
    fun _ h => by simp [DyadicSideIndex.empty] at h,
    fun s => ?_⟩
  dsimp [DyadicSideIndex.empty]
  have hB : 0 < 2 * 2 ^ s.val := by positivity
  simp [Nat.zero_div]

theorem dyadicSide_empty_good {L_p2 R ℓ M₀ d b : ℕ}
    (T p_coord M_lat : ℕ) (A B_rat τ_d τ_q : ℚ) (hAB : A ^ 2 + B_rat ^ 2 = 1)
    (h : ℝ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) :
    DyadicSideGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o
      (DyadicSideIndex.empty L_p2 R ℓ M₀ d b T p_coord) := by
  intro s
  dsimp [DyadicSideIndex.empty]
  simp [Nat.zero_div]

theorem dyadicSide_pts_congr {L_p2 R ℓ M₀ d b : ℕ} {hM₀ : 1 ≤ M₀}
    {T p_coord : ℕ} {A B_rat τ_d : ℚ} {cap_u : ℕ}
    {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {U : Finset ℕ} {idx : DyadicSideIndex L_p2 R ℓ M₀ d b}
    (hwf : DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx)
    (heq : ∀ h ∈ U, pts' h = pts h) :
    DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts' o U idx := by
  rcases hwf with ⟨h1, h2, h3, h4, h5⟩
  refine ⟨h1, h2, ?_, ?_, h5⟩
  · intro h hh
    rcases h3 h hh with ⟨ha, hb, hc, hd⟩
    exact ⟨ha, hb, hc, hd.trans (heq h hh).symm⟩
  · intro eid heid hal
    rcases h4 eid heid hal with ⟨ha, hb, hc⟩
    exact ⟨ha, hb, hc.trans (heq _ ha).symm⟩

theorem dyadicSide_remove_spec {L_p2 R ℓ M₀ d b : ℕ} {hM₀ : 1 ≤ M₀}
    {T p_coord M_lat : ℕ} {A B_rat τ_d τ_q : ℚ} (hAB : A ^ 2 + B_rat ^ 2 = 1)
    {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1) {cap_u cap_q : ℕ}
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {U : Finset ℕ} {idx : DyadicSideIndex L_p2 R ℓ M₀ d b}
    (h₀ : ℕ)
    (hwf : DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx) :
    let idx' := idx.removeHandle h₀
    idx'.t_ins = idx.t_ins ∧
    DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o (U.erase h₀) idx' ∧
    (DyadicSideGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o idx →
      DyadicSideGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o idx') := by
  rcases hwf with ⟨hne, hge, hU, halive, hslots⟩
  dsimp only [DyadicSideIndex.removeHandle]
  by_cases hcond :
      (idx.activeEid h₀ < idx.t_ins && idx.entryAlive (idx.activeEid h₀) &&
        decide (idx.entryHandle (idx.activeEid h₀) = h₀)) = true
  · rw [if_pos hcond]
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hcond
    rcases hcond with ⟨⟨hlt₀, hal₀⟩, hhand₀⟩
    refine ⟨rfl, ⟨hne, ?_, ?_, ?_, hslots⟩, fun hgood => hgood⟩
    · intro eid heid
      dsimp only at heid ⊢
      by_cases heq : eid = idx.activeEid h₀
      · subst heq; omega
      · rw [Function.update_of_ne heq]; exact hge eid heid
    · intro x hx
      rcases Finset.mem_erase.mp hx with ⟨hne_x, hxU⟩
      rcases hU x hxU with ⟨ha, hb, hc, hd⟩
      have heid_ne : idx.activeEid x ≠ idx.activeEid h₀ := by
        intro heq; rw [heq, hhand₀] at hc; exact hne_x hc.symm
      dsimp only
      refine ⟨ha, ?_, hc, hd⟩
      rw [Function.update_of_ne heid_ne]; exact hb
    · intro eid heid hal'
      dsimp only at heid hal' ⊢
      by_cases heq : eid = idx.activeEid h₀
      · subst heq; simp at hal'
      · rw [Function.update_of_ne heq] at hal'
        rcases halive eid heid hal' with ⟨hu, hae, hpt⟩
        have hne_h : idx.entryHandle eid ≠ h₀ := by
          intro hh; rw [hh] at hae; exact heq hae.symm
        exact ⟨Finset.mem_erase.mpr ⟨hne_h, hu⟩, hae, hpt⟩
  · rw [if_neg hcond]
    have hnot_in_U : h₀ ∉ U := by
      intro hh
      rcases hU h₀ hh with ⟨ha, hb, hc, _⟩
      apply hcond
      simp [ha, hb, hc]
    have herase : U.erase h₀ = U := Finset.erase_eq_of_notMem hnot_in_U
    rw [herase]
    exact ⟨rfl, ⟨hne, hge, hU, halive, hslots⟩, fun hgood => hgood⟩

private lemma foldl_step_two {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (A B_rat τ_d : ℚ) (cap_u : ℕ)
    (entryPt : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (base : PureFilterSlot R ℓ M₀ d) (start m : ℕ) :
    let stepFn := fun (k : ℕ) (slot : PureFilterSlot R ℓ M₀ d) (j : Fin k) =>
      let e_j := start + j.val
      slot.insertPoint hM₀ A B_rat τ_d cap_u o (entryPt e_j) e_j
    ((Fin.foldl (2 * m) (stepFn (2 * m)) base).insertPoint
        hM₀ A B_rat τ_d cap_u o (entryPt (start + 2 * m)) (start + 2 * m)).insertPoint
        hM₀ A B_rat τ_d cap_u o (entryPt (start + (2 * m + 1))) (start + (2 * m + 1)) =
      Fin.foldl (2 * (m + 1)) (stepFn (2 * (m + 1))) base := by
  intro stepFn
  have h2 : 2 * (m + 1) = (2 * m + 1) + 1 := by omega
  rw [h2, Fin.foldl_succ_last, Fin.foldl_succ_last]
  rfl

private lemma block1_le_of_div {t B : ℕ} (hq1 : 1 ≤ t / B) :
    (t / B - 1) * B + B ≤ t := by
  have heq : (t / B - 1) * B + B = (t / B) * B := by
    calc (t / B - 1) * B + B = (t / B - 1 + 1) * B := by ring
      _ = (t / B) * B := by rw [Nat.sub_add_cancel hq1]
  rw [heq]
  exact Nat.div_mul_le_self t B

private lemma block2_le_of_div {t B : ℕ} (hq2 : 2 ≤ t / B) :
    (t / B - 2) * B + B ≤ t := by
  have h1 : (t / B - 2) * B + B = (t / B - 1) * B := by
    calc (t / B - 2) * B + B = (t / B - 2 + 1) * B := by ring
      _ = (t / B - 1) * B := by rw [show t / B - 2 + 1 = t / B - 1 by omega]
  rw [h1]
  exact (Nat.mul_le_mul_right B (Nat.sub_le (t / B) 1)).trans (Nat.div_mul_le_self t B)

theorem dyadicSide_insert_spec {L_p2 R ℓ M₀ d b : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord M_lat : ℕ) (A B_rat τ_d τ_q : ℚ) (hAB : A ^ 2 + B_rat ^ 2 = 1)
    (h : ℝ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {U : Finset ℕ} {idx : DyadicSideIndex L_p2 R ℓ M₀ d b}
    {h_new : ℕ} (hnotU : h_new ∉ U) (hne_new : pts h_new ≠ o)
    (ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (hwf : DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx) :
    let idx' := idx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o (pts h_new) h_new ω_step
    idx'.t_ins = idx.t_ins + 1 ∧
    DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o (insert h_new U) idx' ∧
    (DyadicSideGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o idx →
     StepSeedGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o idx ω_step →
     DyadicSideGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o idx') := by
  rcases hwf with ⟨hne, hge, hU, halive, hslots⟩
  let t := idx.t_ins
  have ht_def : idx.t_ins = t := rfl
  let idx' := idx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o (pts h_new) h_new ω_step
  have ht_eq : idx'.t_ins = t + 1 := rfl
  have hpt_old : ∀ eid < t, idx'.entryPt eid = idx.entryPt eid := by
    intro eid heid
    have hne_t : eid ≠ t := by omega
    dsimp only [idx', DyadicSideIndex.insertHandle]
    rw [ht_def]
    exact Function.update_of_ne hne_t (pts h_new) idx.entryPt
  have hne' : ∀ eid < idx'.t_ins, idx'.entryPt eid ≠ o := by
    intro eid heid
    rw [ht_eq] at heid
    by_cases heq : eid = t
    · rw [heq]
      dsimp only [idx', DyadicSideIndex.insertHandle]
      rw [ht_def, Function.update_self]
      exact hne_new
    · rw [hpt_old eid (by omega)]
      exact hne eid (by omega)
  have hge' : ∀ eid, idx'.t_ins ≤ eid → idx'.entryAlive eid = false := by
    intro eid heid
    rw [ht_eq] at heid
    have hne_t : eid ≠ t := by omega
    dsimp only [idx', DyadicSideIndex.insertHandle]
    rw [ht_def, Function.update_of_ne hne_t]
    exact hge eid (by omega)
  have hU' : ∀ x ∈ insert h_new U,
      idx'.activeEid x < idx'.t_ins ∧
      idx'.entryAlive (idx'.activeEid x) = true ∧
      idx'.entryHandle (idx'.activeEid x) = x ∧
      idx'.entryPt (idx'.activeEid x) = pts x := by
    intro x hx
    rcases Finset.mem_insert.mp hx with rfl | hxU
    · dsimp only [idx', DyadicSideIndex.insertHandle]
      rw [ht_def, Function.update_self, Function.update_self, Function.update_self, Function.update_self]
      exact ⟨Nat.lt_succ_self t, rfl, rfl, rfl⟩
    · have hne_x : x ≠ h_new := fun hh => hnotU (hh ▸ hxU)
      rcases hU x hxU with ⟨ha, hb, hc, hd⟩
      have ha_t : idx.activeEid x < t := ha
      have ha_ne : idx.activeEid x ≠ t := by omega
      dsimp only [idx', DyadicSideIndex.insertHandle]
      rw [ht_def, Function.update_of_ne hne_x, Function.update_of_ne ha_ne,
        Function.update_of_ne ha_ne, Function.update_of_ne ha_ne]
      exact ⟨by omega, hb, hc, hd⟩
  have halive' : ∀ eid < idx'.t_ins, idx'.entryAlive eid = true →
      idx'.entryHandle eid ∈ insert h_new U ∧
      idx'.activeEid (idx'.entryHandle eid) = eid ∧
      idx'.entryPt eid = pts (idx'.entryHandle eid) := by
    intro eid heid hal'
    rw [ht_eq] at heid
    by_cases heq : eid = t
    · rw [heq]
      dsimp only [idx', DyadicSideIndex.insertHandle]
      rw [ht_def, Function.update_self, Function.update_self, Function.update_self]
      exact ⟨Finset.mem_insert_self h_new U, rfl, rfl⟩
    · have hlt : eid < t := by omega
      dsimp only [idx', DyadicSideIndex.insertHandle] at hal' ⊢
      rw [ht_def, Function.update_of_ne heq] at hal'
      rw [ht_def, Function.update_of_ne heq, Function.update_of_ne heq]
      rcases halive eid hlt hal' with ⟨hu, hae, hpt⟩
      have hne_h : idx.entryHandle eid ≠ h_new := fun hh => hnotU (hh ▸ hu)
      rw [Function.update_of_ne hne_h]
      exact ⟨Finset.mem_insert_of_mem hu, hae, hpt⟩
  have hfold_congr : ∀ (k start : ℕ) (base : PureFilterSlot R ℓ M₀ d),
      start + k ≤ t →
      Fin.foldl k (fun slot (j : Fin k) =>
        slot.insertPoint hM₀ A B_rat τ_d cap_u o (idx.entryPt (start + j.val)) (start + j.val)) base =
      Fin.foldl k (fun slot (j : Fin k) =>
        slot.insertPoint hM₀ A B_rat τ_d cap_u o (idx'.entryPt (start + j.val)) (start + j.val)) base := by
    intro k start base hbound
    induction k generalizing base with
    | zero => simp [Fin.foldl_zero]
    | succ k ih =>
        rw [Fin.foldl_succ_last, Fin.foldl_succ_last]
        dsimp only [Fin.val_castSucc, Fin.val_last]
        rw [ih base (by omega), hpt_old (start + k) (by omega)]
  have hbuild_congr : ∀ (B start : ℕ) (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b),
      start + B ≤ t →
      buildSlotOnBlock hM₀ T p_coord A B_rat τ_d cap_u idx.entryPt o (fun j : Fin B => start + j.val) ω =
      buildSlotOnBlock hM₀ T p_coord A B_rat τ_d cap_u idx'.entryPt o (fun j : Fin B => start + j.val) ω := by
    intro B start ω hbound
    unfold buildSlotOnBlock
    exact hfold_congr B start (PureFilterSlot.init T p_coord ω) hbound
  have hslots' : ∀ s : Fin L_p2,
      let H := 2 ^ s.val
      let B := 2 * H
      let q' := idx'.t_ins / B
      let off' := idx'.t_ins % B
      (1 ≤ q' → 1 ≤ off' → off' < H →
        idx'.slots s (mod2Fin (q' - 1)) =
          Fin.foldl (2 * off')
            (fun slot (j : Fin (2 * off')) =>
              let e_j := (q' - 1) * B + j.val
              slot.insertPoint hM₀ A B_rat τ_d cap_u o (idx'.entryPt e_j) e_j)
            (PureFilterSlot.init T p_coord (idx'.seeds s (mod2Fin (q' - 1))))) ∧
      (1 ≤ q' → H ≤ off' →
        idx'.slots s (mod2Fin (q' - 1)) =
          buildSlotOnBlock hM₀ T p_coord A B_rat τ_d cap_u idx'.entryPt o
            (fun j : Fin B => (q' - 1) * B + j.val) (idx'.seeds s (mod2Fin (q' - 1)))) ∧
      (2 ≤ q' →
        idx'.slots s (mod2Fin (q' - 2)) =
          buildSlotOnBlock hM₀ T p_coord A B_rat τ_d cap_u idx'.entryPt o
            (fun j : Fin B => (q' - 2) * B + j.val) (idx'.seeds s (mod2Fin (q' - 2)))) := by
    intro s
    let H := 2 ^ s.val
    let B := 2 * H
    have hH_pos : 1 ≤ H := Nat.one_le_two_pow
    have hB_pos : 2 ≤ B := by dsimp [B]; omega
    let q := t / B
    let off := t % B
    have hq_def : t / B = q := rfl
    have hoff_def : t % B = off := rfl
    have ht_div : t = B * q + off := (Nat.div_add_mod t B).symm
    have hoff_lt_B : off < B := Nat.mod_lt t (by omega)
    have hB_def : 2 * 2 ^ s.val = B := rfl
    rcases hslots s with ⟨hs1, hs2, hs3⟩
    dsimp only at hs1 hs2 hs3 ⊢
    rw [ht_def, hB_def] at hs1 hs2 hs3
    rw [ht_eq, hB_def]
    by_cases hwrap : off + 1 = B
    · have ht1 : t + 1 = B * (q + 1) := by linarith only [ht_div, hwrap]
      have hq' : (t + 1) / B = q + 1 := by rw [ht1, Nat.mul_div_right _ (by omega)]
      have hoff' : (t + 1) % B = 0 := by rw [ht1, Nat.mul_mod_right]
      have hoff_ge_H : H ≤ off := by dsimp [B] at hwrap; omega
      rw [hq', hoff']
      refine ⟨fun _ h1 _ => by omega, fun _ hH => by omega, fun hq2 => ?_⟩
      have hq1 : 1 ≤ q := by omega
      have hsub : q + 1 - 2 = q - 1 := by omega
      rw [hsub]
      have hnot_write : ¬ (1 ≤ q ∧ off < H ∧ (mod2Fin (q - 1)).val = (q - 1) % 2) := by omega
      have hnot_seed : ¬ (1 ≤ q ∧ off = 0 ∧ (mod2Fin (q - 1)).val = (q - 1) % 2) := by omega
      have hslot_keep : idx'.slots s (mod2Fin (q - 1)) = idx.slots s (mod2Fin (q - 1)) := by
        dsimp only [idx']; rw [insertHandle_slots_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_write]
      have hseed_keep : idx'.seeds s (mod2Fin (q - 1)) = idx.seeds s (mod2Fin (q - 1)) := by
        dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_seed]
      rw [hslot_keep, hseed_keep, hs2 hq1 hoff_ge_H]
      exact hbuild_congr B ((q - 1) * B) (idx.seeds s (mod2Fin (q - 1))) (block1_le_of_div hq1)
    · have hoff1_lt : off + 1 < B := by omega
      have ht1 : t + 1 = (off + 1) + q * B := by linarith only [ht_div]
      have hq' : (t + 1) / B = q := by
        rw [ht1, Nat.add_mul_div_right _ _ (by omega), Nat.div_eq_of_lt hoff1_lt, zero_add]
      have hoff' : (t + 1) % B = off + 1 := by
        rw [ht1, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hoff1_lt]
      rw [hq', hoff']
      refine ⟨?_, ?_, ?_⟩
      · intro hq1 _ hoff1_H
        have hoff_lt_H : off < H := by omega
        let sl : Fin 2 := mod2Fin (q - 1)
        have hw_cond : 1 ≤ q ∧ off < H ∧ sl.val = (q - 1) % 2 := ⟨hq1, hoff_lt_H, rfl⟩
        have hqb_le_t : (q - 1) * B + B ≤ t := block1_le_of_div hq1
        by_cases hoff0 : off = 0
        · have hs_cond : 1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2 := ⟨hq1, hoff0, rfl⟩
          have hslot_step : idx'.slots s sl =
              ((PureFilterSlot.init T p_coord (ω_step s)).insertPoint
                hM₀ A B_rat τ_d cap_u o (idx.entryPt ((q - 1) * B + 0)) ((q - 1) * B + 0)).insertPoint
                hM₀ A B_rat τ_d cap_u o (idx.entryPt ((q - 1) * B + 1)) ((q - 1) * B + 1) := by
            dsimp only [idx']; rw [insertHandle_slots_eq]
            dsimp only
            rw [ht_def, hB_def, hq_def, hoff_def, if_pos hw_cond]
            rw [if_pos hoff0, hoff0]
          have hseed_step : idx'.seeds s sl = ω_step s := by
            dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_pos hs_cond]
          change idx'.slots s sl = _
          rw [hslot_step, hseed_step]
          have hf0 := foldl_step_two hM₀ A B_rat τ_d cap_u idx.entryPt o
            (PureFilterSlot.init T p_coord (ω_step s)) ((q - 1) * B) 0
          dsimp only at hf0
          simp only [Nat.mul_zero, Fin.foldl_zero, Nat.zero_add, Nat.mul_one] at hf0
          simp only [hoff0, Nat.zero_add, Nat.mul_one]
          rw [hf0]
          exact hfold_congr 2 ((q - 1) * B) (PureFilterSlot.init T p_coord (ω_step s)) (by omega)
        · have hoff_pos : 1 ≤ off := by omega
          have hnot_seed : ¬ (1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2) := by simp [hoff0]
          have hseed_keep : idx'.seeds s sl = idx.seeds s sl := by
            dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_seed]
          have hslot_step : idx'.slots s sl =
              ((idx.slots s sl).insertPoint hM₀ A B_rat τ_d cap_u o
                (idx.entryPt ((q - 1) * B + 2 * off)) ((q - 1) * B + 2 * off)).insertPoint
                hM₀ A B_rat τ_d cap_u o
                (idx.entryPt ((q - 1) * B + (2 * off + 1))) ((q - 1) * B + (2 * off + 1)) := by
            dsimp only [idx']; rw [insertHandle_slots_eq]
            dsimp only
            rw [ht_def, hB_def, hq_def, hoff_def, if_pos hw_cond]
            rw [if_neg hoff0, Nat.add_assoc]
          change idx'.slots s sl = _
          rw [hslot_step, hseed_keep, hs1 hq1 hoff_pos hoff_lt_H]
          rw [foldl_step_two hM₀ A B_rat τ_d cap_u idx.entryPt o (PureFilterSlot.init T p_coord (idx.seeds s sl)) ((q - 1) * B) off]
          exact hfold_congr (2 * (off + 1)) ((q - 1) * B) (PureFilterSlot.init T p_coord (idx.seeds s sl)) (by omega)
      · intro hq1 hoff1_ge_H
        let sl : Fin 2 := mod2Fin (q - 1)
        have hqb_le_t : (q - 1) * B + B ≤ t := block1_le_of_div hq1
        by_cases heqH : off + 1 = H
        · have hoff_lt_H : off < H := by omega
          have hw_cond : 1 ≤ q ∧ off < H ∧ sl.val = (q - 1) % 2 := ⟨hq1, hoff_lt_H, rfl⟩
          have h2H : 2 * (off + 1) = B := by dsimp [B]; omega
          by_cases hoff0 : off = 0
          · have hs_cond : 1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2 := ⟨hq1, hoff0, rfl⟩
            have hseed_step : idx'.seeds s sl = ω_step s := by
              dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_pos hs_cond]
            have hslot_step : idx'.slots s sl =
                ((PureFilterSlot.init T p_coord (ω_step s)).insertPoint
                  hM₀ A B_rat τ_d cap_u o (idx.entryPt ((q - 1) * B + 0)) ((q - 1) * B + 0)).insertPoint
                  hM₀ A B_rat τ_d cap_u o (idx.entryPt ((q - 1) * B + 1)) ((q - 1) * B + 1) := by
              dsimp only [idx']; rw [insertHandle_slots_eq]
              dsimp only
              rw [ht_def, hB_def, hq_def, hoff_def, if_pos hw_cond]
              rw [if_pos hoff0, hoff0]
            change idx'.slots s sl = _
            rw [hslot_step, hseed_step]
            have hf0 := foldl_step_two hM₀ A B_rat τ_d cap_u idx.entryPt o
              (PureFilterSlot.init T p_coord (ω_step s)) ((q - 1) * B) 0
            dsimp only at hf0
            simp only [Nat.mul_zero, Fin.foldl_zero, Nat.zero_add, Nat.mul_one] at hf0
            have hB2 : B = 2 := by dsimp [B]; omega
            unfold buildSlotOnBlock
            dsimp only
            rw [hB2] at hf0 ⊢
            rw [hf0]
            exact hfold_congr 2 ((q - 1) * 2) (PureFilterSlot.init T p_coord (ω_step s))
              (by rw [← hB2]; exact hqb_le_t)
          · have hoff_pos : 1 ≤ off := by omega
            have hnot_seed : ¬ (1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2) := by simp [hoff0]
            have hseed_keep : idx'.seeds s sl = idx.seeds s sl := by
              dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_seed]
            have hslot_step : idx'.slots s sl =
                ((idx.slots s sl).insertPoint hM₀ A B_rat τ_d cap_u o
                  (idx.entryPt ((q - 1) * B + 2 * off)) ((q - 1) * B + 2 * off)).insertPoint
                  hM₀ A B_rat τ_d cap_u o
                  (idx.entryPt ((q - 1) * B + (2 * off + 1))) ((q - 1) * B + (2 * off + 1)) := by
              dsimp only [idx']; rw [insertHandle_slots_eq]
              dsimp only
              rw [ht_def, hB_def, hq_def, hoff_def, if_pos hw_cond]
              rw [if_neg hoff0, Nat.add_assoc]
            change idx'.slots s sl = _
            rw [hslot_step, hseed_keep, hs1 hq1 hoff_pos hoff_lt_H]
            rw [foldl_step_two hM₀ A B_rat τ_d cap_u idx.entryPt o (PureFilterSlot.init T p_coord (idx.seeds s sl)) ((q - 1) * B) off]
            unfold buildSlotOnBlock
            rw [h2H]
            exact hfold_congr B ((q - 1) * B) (PureFilterSlot.init T p_coord (idx.seeds s sl)) hqb_le_t
        · have hoff_ge_H : H ≤ off := by omega
          have hnot_write : ¬ (1 ≤ q ∧ off < H ∧ sl.val = (q - 1) % 2) := by dsimp [sl]; omega
          have hnot_seed : ¬ (1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2) := by dsimp [sl]; omega
          have hslot_keep : idx'.slots s sl = idx.slots s sl := by
            dsimp only [idx']; rw [insertHandle_slots_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_write]
          have hseed_keep : idx'.seeds s sl = idx.seeds s sl := by
            dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_seed]
          change idx'.slots s sl = _
          rw [hslot_keep, hseed_keep, hs2 hq1 hoff_ge_H]
          exact hbuild_congr B ((q - 1) * B) (idx.seeds s sl) hqb_le_t
      · intro hq2
        let sl2 : Fin 2 := mod2Fin (q - 2)
        have hmod_ne : (q - 2) % 2 ≠ (q - 1) % 2 := by omega
        have hnot_write : ¬ (1 ≤ q ∧ off < H ∧ sl2.val = (q - 1) % 2) := by
          dsimp [sl2]; intro hh; exact hmod_ne hh.2.2
        have hnot_seed : ¬ (1 ≤ q ∧ off = 0 ∧ sl2.val = (q - 1) % 2) := by
          dsimp [sl2]; intro hh; exact hmod_ne hh.2.2
        have hslot_keep : idx'.slots s sl2 = idx.slots s sl2 := by
          dsimp only [idx']; rw [insertHandle_slots_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_write]
        have hseed_keep : idx'.seeds s sl2 = idx.seeds s sl2 := by
          dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_seed]
        have hqb2_le_t : (q - 2) * B + B ≤ t := block2_le_of_div hq2
        change idx'.slots s sl2 = _
        rw [hslot_keep, hseed_keep, hs3 hq2]
        exact hbuild_congr B ((q - 2) * B) (idx.seeds s sl2) hqb2_le_t
  refine ⟨ht_eq, ⟨hne', hge', hU', halive', hslots'⟩, fun hgood hstep => ?_⟩
  have hgen_congr : ∀ {B : ℕ} (start : ℕ) (hbnd : start + B ≤ t)
      (h1 : ∀ j : Fin B, idx.entryPt (start + j.val) ≠ o)
      (h2 : ∀ j : Fin B, idx'.entryPt (start + j.val) ≠ o),
      mkPaddedGeneration (Nat.one_le_two_pow : 1 ≤ 2 ^ L_p2) idx'.entryPt o A B_rat hAB h hh0 hh1
        (fun j : Fin B => start + j.val) h2 =
      mkPaddedGeneration (Nat.one_le_two_pow : 1 ≤ 2 ^ L_p2) idx.entryPt o A B_rat hAB h hh0 hh1
        (fun j : Fin B => start + j.val) h1 := by
    intro B start hbnd h1 h2
    unfold mkPaddedGeneration
    congr 1
    funext k
    split_ifs with hk
    · rw [hpt_old (start + k.val) (by omega)]
    · rfl
  intro s
  let H := 2 ^ s.val
  let B := 2 * H
  have hH_pos : 1 ≤ H := Nat.one_le_two_pow
  have hB_pos : 2 ≤ B := by dsimp [B]; omega
  let q := t / B
  let off := t % B
  have ht_div : t = B * q + off := (Nat.div_add_mod t B).symm
  have hoff_lt_B : off < B := Nat.mod_lt t (by omega)
  have hB_def : 2 * 2 ^ s.val = B := rfl
  rcases hgood s with ⟨hg1, hg2, hg3⟩
  dsimp only at hg1 hg2 hg3 ⊢
  rw [ht_def, hB_def] at hg1 hg2 hg3
  rw [ht_eq, hB_def]
  by_cases hwrap : off + 1 = B
  · have ht1 : t + 1 = B * (q + 1) := by linarith only [ht_div, hwrap]
    have hq' : (t + 1) / B = q + 1 := by rw [ht1, Nat.mul_div_right _ (by omega)]
    have hoff' : (t + 1) % B = 0 := by rw [ht1, Nat.mul_mod_right]
    have hoff_ge_H : H ≤ off := by dsimp [B] at hwrap; omega
    rw [hq', hoff']
    refine ⟨fun _ h1 _ => by omega, fun _ hH => by omega, fun hq2 hne_arr' => ?_⟩
    have hq1 : 1 ≤ q := by omega
    have hsub : q + 1 - 2 = q - 1 := by omega
    have hqb_blk : (q - 1) * B + B ≤ t := block1_le_of_div hq1
    have hnot_seed : ¬ (1 ≤ q ∧ off = 0 ∧ (mod2Fin (q - 1)).val = (q - 1) % 2) := by omega
    have hseed_keep : idx'.seeds s (mod2Fin (q + 1 - 2)) = idx.seeds s (mod2Fin (q - 1)) := by
      rw [hsub]; dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_seed]
    rw [hseed_keep]
    have hqb_blk' : (q + 1 - 2) * B + B ≤ t := by rwa [hsub]
    have hne_old : ∀ j : Fin B, idx.entryPt ((q + 1 - 2) * B + j.val) ≠ o := by
      intro j
      rw [← hpt_old _ (Nat.lt_of_lt_of_le (Nat.add_lt_add_left j.isLt _) hqb_blk')]
      exact hne_arr' j
    rw [hgen_congr ((q + 1 - 2) * B) hqb_blk' hne_old hne_arr']
    have hne_old' : ∀ j : Fin B, idx.entryPt ((q - 1) * B + j.val) ≠ o := by
      simpa [hsub] using hne_old
    have hg_res := hg2 hq1 hoff_ge_H hne_old'
    have hgen_sub :
        mkPaddedGeneration (Nat.one_le_two_pow : 1 ≤ 2 ^ L_p2) idx.entryPt o A B_rat hAB h hh0 hh1
          (fun j : Fin B => (q + 1 - 2) * B + j.val) hne_old =
        mkPaddedGeneration (Nat.one_le_two_pow : 1 ≤ 2 ^ L_p2) idx.entryPt o A B_rat hAB h hh0 hh1
          (fun j : Fin B => (q - 1) * B + j.val) hne_old' := by
      simp only [hsub]
    rwa [hgen_sub]
  · have hoff1_lt : off + 1 < B := by omega
    have ht1 : t + 1 = (off + 1) + q * B := by linarith only [ht_div]
    have hq' : (t + 1) / B = q := by
      rw [ht1, Nat.add_mul_div_right _ _ (by omega), Nat.div_eq_of_lt hoff1_lt, zero_add]
    have hoff' : (t + 1) % B = off + 1 := by
      rw [ht1, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hoff1_lt]
    rw [hq', hoff']
    refine ⟨?_, ?_, ?_⟩
    · intro hq1 _ hoff1_H hne_arr'
      let sl : Fin 2 := mod2Fin (q - 1)
      have hqb_blk : (q - 1) * B + B ≤ t := block1_le_of_div hq1
      have hne_old : ∀ j : Fin B, idx.entryPt ((q - 1) * B + j.val) ≠ o := by
        intro j; rw [← hpt_old _ (by omega)]; exact hne_arr' j
      rw [hgen_congr ((q - 1) * B) hqb_blk hne_old hne_arr']
      by_cases hoff0 : off = 0
      · have hs_cond : 1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2 := ⟨hq1, hoff0, rfl⟩
        have hseed_step : idx'.seeds s sl = ω_step s := by
          dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_pos hs_cond]
        change IsOrderIndepGoodFilter (polyFDisc T p_coord (idx'.seeds s sl)) _ _ _ _ _ _
        rw [hseed_step]
        have hst_s := hstep s
        dsimp only at hst_s
        rw [ht_def, hB_def] at hst_s
        exact hst_s hq1 hoff0 hne_old
      · have hnot_seed : ¬ (1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2) := by simp [hoff0]
        have hseed_keep : idx'.seeds s sl = idx.seeds s sl := by
          dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_seed]
        change IsOrderIndepGoodFilter (polyFDisc T p_coord (idx'.seeds s sl)) _ _ _ _ _ _
        rw [hseed_keep]
        exact hg1 hq1 (by omega) (by omega) hne_old
    · intro hq1 hoff1_ge_H hne_arr'
      let sl : Fin 2 := mod2Fin (q - 1)
      have hqb_blk : (q - 1) * B + B ≤ t := block1_le_of_div hq1
      have hne_old : ∀ j : Fin B, idx.entryPt ((q - 1) * B + j.val) ≠ o := by
        intro j; rw [← hpt_old _ (by omega)]; exact hne_arr' j
      rw [hgen_congr ((q - 1) * B) hqb_blk hne_old hne_arr']
      by_cases hoff0 : off = 0
      · have hs_cond : 1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2 := ⟨hq1, hoff0, rfl⟩
        have hseed_step : idx'.seeds s sl = ω_step s := by
          dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_pos hs_cond]
        change IsOrderIndepGoodFilter (polyFDisc T p_coord (idx'.seeds s sl)) _ _ _ _ _ _
        rw [hseed_step]
        have hst_s := hstep s
        dsimp only at hst_s
        rw [ht_def, hB_def] at hst_s
        exact hst_s hq1 hoff0 hne_old
      · have hnot_seed : ¬ (1 ≤ q ∧ off = 0 ∧ sl.val = (q - 1) % 2) := by simp [hoff0]
        have hseed_keep : idx'.seeds s sl = idx.seeds s sl := by
          dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_seed]
        change IsOrderIndepGoodFilter (polyFDisc T p_coord (idx'.seeds s sl)) _ _ _ _ _ _
        rw [hseed_keep]
        by_cases hoff_lt_H : off < H
        · exact hg1 hq1 (by omega) hoff_lt_H hne_old
        · exact hg2 hq1 (by omega) hne_old
    · intro hq2 hne_arr'
      let sl2 : Fin 2 := mod2Fin (q - 2)
      have hmod_ne : (q - 2) % 2 ≠ (q - 1) % 2 := by omega
      have hnot_seed : ¬ (1 ≤ q ∧ off = 0 ∧ sl2.val = (q - 1) % 2) := by
        dsimp [sl2]; intro hh; exact hmod_ne hh.2.2
      have hseed_keep : idx'.seeds s sl2 = idx.seeds s sl2 := by
        dsimp only [idx']; rw [insertHandle_seeds_eq]; simp only [ht_def, hB_def]; rw [if_neg hnot_seed]
      have hqb2_blk : (q - 2) * B + B ≤ t := block2_le_of_div hq2
      have hne_old : ∀ j : Fin B, idx.entryPt ((q - 2) * B + j.val) ≠ o := by
        intro j; rw [← hpt_old _ (by omega)]; exact hne_arr' j
      rw [hgen_congr ((q - 2) * B) hqb2_blk hne_old hne_arr']
      change IsOrderIndepGoodFilter (polyFDisc T p_coord (idx'.seeds s sl2)) _ _ _ _ _ _
      rw [hseed_keep]
      exact hg3 hq2 hne_old

/-! ### 5. Universal Soundness & Good-Seed Search Promise of `DyadicSideIndex.query` -/

theorem dyadicSide_query_sound {L_p2 R ℓ M₀ d b : ℕ} (hM₀ : 1 ≤ M₀)
    {T p_coord : ℕ} (M_lat : ℕ) {A B_rat τ_d : ℚ} (τ_q : ℚ) (b_thr : ℝ)
    {cap_u : ℕ} (cap_q : ℕ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    (p_v : EuclideanSpace ℝ (Fin d))
    {U : Finset ℕ} {idx : DyadicSideIndex L_p2 R ℓ M₀ d b}
    (hwf : DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx)
    {w : ℕ}
    (hans : idx.query hM₀ M_lat A B_rat τ_q b_thr cap_q o p_v = some w) :
    w ∈ U ∧ b_thr < radialCorrelation o p_v (pts w) := by
  rcases hwf with ⟨_, hge, _, halive, _⟩
  have hfrom_eid : ∀ {eid : ℕ},
      idx.entryAlive eid = true →
      b_thr < radialCorrelation o p_v (idx.entryPt eid) →
      idx.entryHandle eid ∈ U ∧
        b_thr < radialCorrelation o p_v (pts (idx.entryHandle eid)) := by
    intro eid hal hcorr
    have hlt : eid < idx.t_ins := by
      by_contra hnot
      have hf := hge eid (by omega)
      rw [hf] at hal; cases hal
    rcases halive eid hlt hal with ⟨hu, _, hpt⟩
    rw [hpt] at hcorr
    exact ⟨hu, hcorr⟩
  unfold DyadicSideIndex.query at hans
  dsimp only at hans
  by_cases ht1 : 1 ≤ idx.t_ins ∧ idx.entryAlive (idx.t_ins - 1) = true ∧
      b_thr < radialCorrelation o p_v (idx.entryPt (idx.t_ins - 1))
  · rw [if_pos ht1] at hans
    dsimp only at hans
    injection hans with hw; subst hw
    exact hfrom_eid ht1.2.1 ht1.2.2
  · rw [if_neg ht1] at hans
    dsimp only at hans
    by_cases ht2 : 2 ≤ idx.t_ins ∧ idx.entryAlive (idx.t_ins - 2) = true ∧
        b_thr < radialCorrelation o p_v (idx.entryPt (idx.t_ins - 2))
    · rw [if_pos ht2] at hans
      dsimp only at hans
      injection hans with hw; subst hw
      exact hfrom_eid ht2.2.1 ht2.2.2
    · rw [if_neg ht2] at hans
      dsimp only at hans
      rw [List.findSome?_eq_some_iff] at hans
      rcases hans with ⟨xs, s, ys, _, hs_some, _⟩
      by_cases hr1_cond : 1 ≤ idx.t_ins / (2 * 2 ^ s.val) ∧ 2 ^ s.val ≤ idx.t_ins % (2 * 2 ^ s.val)
      · rw [if_pos hr1_cond] at hs_some
        cases hq1 : (idx.slots s (mod2Fin (idx.t_ins / (2 * 2 ^ s.val) - 1))).query
            hM₀ M_lat A B_rat τ_q b_thr cap_q idx.entryPt o p_v idx.entryAlive with
        | some eid =>
            rw [hq1] at hs_some
            dsimp only [Option.map] at hs_some
            injection hs_some with hw; subst hw
            have hsnd := pureFilterSlot_query_sound hM₀ M_lat A B_rat τ_q b_thr cap_q
              idx.entryPt o p_v idx.entryAlive _ hq1
            exact hfrom_eid hsnd.1 hsnd.2
        | none =>
            rw [hq1] at hs_some
            dsimp only [Option.map] at hs_some
            split_ifs at hs_some with hr2_cond
            rcases Option.map_eq_some_iff.mp hs_some with ⟨eid, hq2, rfl⟩
            have hsnd := pureFilterSlot_query_sound hM₀ M_lat A B_rat τ_q b_thr cap_q
              idx.entryPt o p_v idx.entryAlive _ hq2
            exact hfrom_eid hsnd.1 hsnd.2
      · rw [if_neg hr1_cond] at hs_some
        dsimp only at hs_some
        split_ifs at hs_some with hr2_cond
        rcases Option.map_eq_some_iff.mp hs_some with ⟨eid, hq2, rfl⟩
        have hsnd := pureFilterSlot_query_sound hM₀ M_lat A B_rat τ_q b_thr cap_q
          idx.entryPt o p_v idx.entryAlive _ hq2
        exact hfrom_eid hsnd.1 hsnd.2

theorem dyadicSide_query_promise {L_p2 R ℓ M₀ d b : ℕ}
    (hd : 1 ≤ d) (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (e A B_rat τ_d τ_q : ℚ) (he0 : 0 < (e : ℝ)) (he1 : (e : ℝ) ≤ 1)
    (hAB : A ^ 2 + B_rat ^ 2 = 1)
    (h a_thr b_thr : ℝ) (hh0 : 0 < h) (hh1 : h < 1) (hba : b_thr ≤ a_thr)
    (cap_u cap_q : ℕ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {v_id : ℕ} (hpv : pts v_id ≠ o)
    {U : Finset ℕ} {idx : DyadicSideIndex L_p2 R ℓ M₀ d b}
    (ht_lt : idx.t_ins < 2 ^ L_p2)
    (hsep : ∀ (u z z_bar : EuclideanSpace ℝ (Fin d)),
      ‖u‖ = 1 → ‖z‖ = 1 → ‖z_bar‖ = 1 → ‖z_bar - z‖ ≤ (e : ℝ) / 8 →
      (a_thr ≤ inner ℝ z u →
        h ≤ inner ℝ (liftedPoint ((A : ℝ) • z_bar) (-(B_rat : ℝ))) (liftedPoint ((A : ℝ) • u) (B_rat : ℝ))) ∧
      (inner ℝ z u ≤ b_thr →
        inner ℝ (liftedPoint ((A : ℝ) • z_bar) (-(B_rat : ℝ))) (liftedPoint ((A : ℝ) • u) (B_rat : ℝ)) < 0))
    (hwf : DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx)
    (hgood : DyadicSideGood T p_coord (M_lat_of d e) A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o idx) :
    SatisfiesAngularSearchPromise pts o a_thr b_thr U v_id
      (idx.query hM₀ (M_lat_of d e) A B_rat τ_q b_thr cap_q o (pts v_id)) := by
  let M_lat := M_lat_of d e
  cases hans : idx.query hM₀ M_lat A B_rat τ_q b_thr cap_q o (pts v_id) with
  | some w =>
      exact dyadicSide_query_sound hM₀ M_lat τ_q b_thr cap_q (pts v_id) hwf hans
  | none =>
      dsimp only [SatisfiesAngularSearchPromise]
      intro w hwU
      rcases hwf with ⟨hne, _, hU, _, hslots⟩
      rcases hU w hwU with ⟨heid_lt, heid_al, _, heid_pt⟩
      set eid := idx.activeEid w
      -- Extract from `hans : idx.query = none` that tail1, tail2, and all scales returned `none`
      unfold DyadicSideIndex.query at hans
      dsimp only at hans
      have ht1 : ¬ (1 ≤ idx.t_ins ∧ idx.entryAlive (idx.t_ins - 1) = true ∧
          b_thr < radialCorrelation o (pts v_id) (idx.entryPt (idx.t_ins - 1))) := by
        intro hc; rw [if_pos hc] at hans; cases hans
      rw [if_neg ht1] at hans
      dsimp only at hans
      have ht2 : ¬ (2 ≤ idx.t_ins ∧ idx.entryAlive (idx.t_ins - 2) = true ∧
          b_thr < radialCorrelation o (pts v_id) (idx.entryPt (idx.t_ins - 2))) := by
        intro hc; rw [if_pos hc] at hans; cases hans
      rw [if_neg ht2] at hans
      dsimp only at hans
      have hall_scales : ∀ s : Fin L_p2,
          (let H := 2 ^ s.val
           let B := 2 * H
           let q := idx.t_ins / B
           let off := idx.t_ins % B
           let r1 : Option ℕ :=
             if 1 ≤ q ∧ H ≤ off then
               let sl : Fin 2 := mod2Fin (q - 1)
               ((idx.slots s sl).query hM₀ M_lat A B_rat τ_q b_thr cap_q
                 idx.entryPt o (pts v_id) idx.entryAlive).map idx.entryHandle
             else
               none
           match r1 with
           | some x => some x
           | none =>
               if 2 ≤ q then
                 let sl : Fin 2 := mod2Fin (q - 2)
                 ((idx.slots s sl).query hM₀ M_lat A B_rat τ_q b_thr cap_q
                   idx.entryPt o (pts v_id) idx.entryAlive).map idx.entryHandle
               else
                 none) = none := by
        intro s
        exact List.findSome?_eq_none_iff.mp hans s (List.mem_finRange s)
      rcases dyadicEpoch_coverage L_p2 idx.t_ins eid ht_lt heid_lt with htail | ⟨s, hs_cov⟩
      · -- Covered by the 2-element tail!
        have heid_cases : eid = idx.t_ins - 1 ∨ (2 ≤ idx.t_ins ∧ eid = idx.t_ins - 2) := by omega
        rcases heid_cases with heq1 | ⟨ht_ge2, heq2⟩
        · have hnot_b : ¬ b_thr < radialCorrelation o (pts v_id) (idx.entryPt eid) := by
            intro hgt
            apply ht1
            rw [← heq1]
            exact ⟨by omega, heid_al, hgt⟩
          rw [heid_pt] at hnot_b
          linarith only [not_lt.mp hnot_b, hba]
        · have hnot_b : ¬ b_thr < radialCorrelation o (pts v_id) (idx.entryPt eid) := by
            intro hgt
            apply ht2
            rw [← heq2]
            exact ⟨ht_ge2, heid_al, hgt⟩
          rw [heid_pt] at hnot_b
          linarith only [not_lt.mp hnot_b, hba]
      · -- Covered by ready block at scale `s`!
        let H := 2 ^ s.val
        let B := 2 * H
        have hB_le_N : B ≤ 2 ^ L_p2 := by
          have hs_lt : s.val + 1 ≤ L_p2 := s.isLt
          calc B = 2 ^ (s.val + 1) := by dsimp [B, H]; rw [pow_succ]; ring
            _ ≤ 2 ^ L_p2 := Nat.pow_le_pow_right (by decide) hs_lt
        have hs_none := hall_scales s
        dsimp only at hs_none
        rcases hslots s with ⟨_, hsl_r1, hsl_r2⟩
        rcases hgood s with ⟨_, hgd_r1, hgd_r2⟩
        rcases hs_cov with ⟨hq1, hoffH, hlo, hhi⟩ | ⟨hq2, hlo, hhi⟩
        · -- Ready block `q - 1`
          let q := idx.t_ins / B
          let sl : Fin 2 := mod2Fin (q - 1)
          have hr1_cond : 1 ≤ q ∧ H ≤ idx.t_ins % B := ⟨hq1, hoffH⟩
          rw [if_pos hr1_cond] at hs_none
          have hq_none : (idx.slots s sl).query hM₀ M_lat A B_rat τ_q b_thr cap_q
              idx.entryPt o (pts v_id) idx.entryAlive = none := by
            cases hqq : (idx.slots s sl).query hM₀ M_lat A B_rat τ_q b_thr cap_q
                idx.entryPt o (pts v_id) idx.entryAlive with
            | none => rfl
            | some x => rw [hqq] at hs_none; simp at hs_none
          rw [hsl_r1 hq1 hoffH] at hq_none
          have hlo' : (q - 1) * B ≤ eid := hlo
          have hhi' : eid < q * B := hhi
          have hqB_eq : (q - 1) * B + B = q * B := by
            calc (q - 1) * B + B = (q - 1 + 1) * B := by ring
              _ = q * B := by rw [Nat.sub_add_cancel hq1]
          have hqt : (q - 1) * B + B ≤ idx.t_ins :=
            hqB_eq.le.trans (Nat.mul_le_of_le_div B q idx.t_ins le_rfl)
          let j_star : Fin B := ⟨eid - (q - 1) * B, by omega⟩
          have hj_eq : (q - 1) * B + j_star.val = eid := by dsimp [j_star]; omega
          have hlt_a := pureFilterSlot_query_complete hd hM₀ Nat.one_le_two_pow hB_le_N
            T p_coord e A B_rat τ_d τ_q he0 he1 hAB h a_thr b_thr hh0 hh1 cap_u cap_q
            idx.entryPt o (pts v_id) hpv (fun j : Fin B => (q - 1) * B + j.val)
            (fun j => hne _ (Nat.lt_of_lt_of_le (Nat.add_lt_add_left j.isLt _) hqt))
            idx.entryAlive (idx.seeds s sl) hsep (hgd_r1 hq1 hoffH _) hq_none j_star
            (by dsimp only; rw [hj_eq]; exact heid_al)
          dsimp only at hlt_a
          rw [hj_eq, heid_pt] at hlt_a
          exact le_of_lt hlt_a
        · -- Ready block `q - 2`
          let q := idx.t_ins / B
          let sl : Fin 2 := mod2Fin (q - 2)
          have hq_none : (idx.slots s sl).query hM₀ M_lat A B_rat τ_q b_thr cap_q
              idx.entryPt o (pts v_id) idx.entryAlive = none := by
            by_cases hr1_cond : 1 ≤ q ∧ H ≤ idx.t_ins % B
            · rw [if_pos hr1_cond] at hs_none
              cases hqq1 : (idx.slots s (mod2Fin (q - 1))).query
                  hM₀ M_lat A B_rat τ_q b_thr cap_q idx.entryPt o (pts v_id) idx.entryAlive with
              | some x => rw [hqq1] at hs_none; simp at hs_none
              | none =>
                  rw [hqq1] at hs_none
                  dsimp only [Option.map] at hs_none
                  rw [if_pos hq2] at hs_none
                  exact Option.map_eq_none_iff.mp hs_none
            · rw [if_neg hr1_cond] at hs_none
              dsimp only at hs_none
              rw [if_pos hq2] at hs_none
              exact Option.map_eq_none_iff.mp hs_none
          rw [hsl_r2 hq2] at hq_none
          have hlo' : (q - 2) * B ≤ eid := hlo
          have hhi' : eid < (q - 1) * B := hhi
          have hq2' : 2 ≤ q := hq2
          have hqB2_eq : (q - 2) * B + B = (q - 1) * B := by
            calc (q - 2) * B + B = (q - 2 + 1) * B := by ring
              _ = (q - 1) * B := by rw [show q - 2 + 1 = q - 1 by omega]
          have hq_le : q - 1 ≤ q := Nat.sub_le q 1
          have hqt : (q - 2) * B + B ≤ idx.t_ins :=
            hqB2_eq.le.trans ((Nat.mul_le_mul_right B hq_le).trans (Nat.mul_le_of_le_div B q idx.t_ins le_rfl))
          let j_star : Fin B := ⟨eid - (q - 2) * B, by omega⟩
          have hj_eq : (q - 2) * B + j_star.val = eid := by dsimp [j_star]; omega
          have hlt_a := pureFilterSlot_query_complete hd hM₀ Nat.one_le_two_pow hB_le_N
            T p_coord e A B_rat τ_d τ_q he0 he1 hAB h a_thr b_thr hh0 hh1 cap_u cap_q
            idx.entryPt o (pts v_id) hpv (fun j : Fin B => (q - 2) * B + j.val)
            (fun j => hne _ (Nat.lt_of_lt_of_le (Nat.add_lt_add_left j.isLt _) hqt))
            idx.entryAlive (idx.seeds s sl) hsep (hgd_r2 hq2 _) hq_none j_star
            (by dsimp only; rw [hj_eq]; exact heid_al)
          dsimp only at hlt_a
          rw [hj_eq, heid_pt] at hlt_a
          exact le_of_lt hlt_a

/-! ### 6. Bundled Node Configuration Matching State (`LocalMatchingState` + Left/Right Dyadic Indices) -/

/-- Compile-time static data for one retained configuration `cfg ∈ params.retainedConfigs 1`. -/
structure ConfigStaticSpec (d : ℕ) (params : LocalScaleParams) (h : ℝ) where
  cfg : ShellConfig
  mem_one : cfg ∈ params.retainedConfigs 1
  A : ℚ
  B : ℚ
  hAB : A ^ 2 + B ^ 2 = 1
  sep : ∀ (u z z_bar : EuclideanSpace ℝ (Fin d)),
    ‖u‖ = 1 → ‖z‖ = 1 → ‖z_bar‖ = 1 → ‖z_bar - z‖ ≤ (params.e : ℝ) / 8 →
    (params.thresholdA 1 cfg.j cfg.k cfg.ℓ ≤ inner ℝ z u →
      h ≤ inner ℝ (liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ))) (liftedPoint ((A : ℝ) • u) (B : ℝ))) ∧
    (inner ℝ z u ≤ params.thresholdB 1 cfg.j cfg.k cfg.ℓ →
      inner ℝ (liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ))) (liftedPoint ((A : ℝ) • u) (B : ℝ)) < 0)

structure ConfigDynamicState (L_p2 R ℓ M₀ d b : ℕ) where
  st : LocalMatchingState ℕ
  leftIdx : DyadicSideIndex L_p2 R ℓ M₀ d b
  rightIdx : DyadicSideIndex L_p2 R ℓ M₀ d b

noncomputable def ConfigDynamicState.empty (L_p2 R ℓ M₀ d b T p_coord : ℕ) :
    ConfigDynamicState L_p2 R ℓ M₀ d b :=
  { st := LocalMatchingState.empty ℕ
    leftIdx := DyadicSideIndex.empty L_p2 R ℓ M₀ d b T p_coord
    rightIdx := DyadicSideIndex.empty L_p2 R ℓ M₀ d b T p_coord }

noncomputable def syncIndicesOnAttach {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord : ℕ) (A B_rat τ_d : ℚ) (cap_u : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (v : CopyVertex ℕ) (checkedAns : Option ℕ)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (leftIdx rightIdx : DyadicSideIndex L_p2 R ℓ M₀ d b) :
    DyadicSideIndex L_p2 R ℓ M₀ d b × DyadicSideIndex L_p2 R ℓ M₀ d b :=
  match v.side, checkedAns with
  | .left, some w => (leftIdx, rightIdx.removeHandle w)
  | .left, none =>
      (leftIdx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o (pts v.id) v.id ω_L, rightIdx)
  | .right, some w => (leftIdx.removeHandle w, rightIdx)
  | .right, none =>
      (leftIdx, rightIdx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o (pts v.id) v.id ω_R)

noncomputable def ConfigDynamicState.insertOriginal {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    (A B_rat τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) (p : ℕ)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) :
    ConfigDynamicState L_p2 R ℓ M₀ d b :=
  open Classical in
  let b_thr : ℝ := (bRatCfg params cfg : ℝ)
  let rawLeft :=
    if hasApplicableLeftCopy params.m0 o V cfg.j (pts p) then
      cs.rightIdx.query hM₀ M_lat A B_rat τ_q b_thr cap_q o (pts p)
    else
      none
  let step1 : LocalMatchingState ℕ × DyadicSideIndex L_p2 R ℓ M₀ d b × DyadicSideIndex L_p2 R ℓ M₀ d b :=
    if hasApplicableLeftCopy params.m0 o V cfg.j (pts p) then
      let vL : CopyVertex ℕ := ⟨.left, p⟩
      let cL := sanitizeConfigAttachAnswer pts params o V cfg cs.st vL rawLeft
      let lr := syncIndicesOnAttach hM₀ T p_coord A B_rat τ_d cap_u pts o vL cL ω_L ω_R cs.leftIdx cs.rightIdx
      (attachStep pts cs.st vL cL, lr.1, lr.2)
    else
      (cs.st, cs.leftIdx, cs.rightIdx)
  let rawRight :=
    if hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p) then
      step1.2.1.query hM₀ M_lat A B_rat τ_q b_thr cap_q o (pts p)
    else
      none
  let step2 : LocalMatchingState ℕ × DyadicSideIndex L_p2 R ℓ M₀ d b × DyadicSideIndex L_p2 R ℓ M₀ d b :=
    if hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p) then
      let vR : CopyVertex ℕ := ⟨.right, p⟩
      let cR := sanitizeConfigAttachAnswer pts params o V cfg step1.1 vR rawRight
      let lr := syncIndicesOnAttach hM₀ T p_coord A B_rat τ_d cap_u pts o vR cR ω_L ω_R step1.2.1 step1.2.2
      (attachStep pts step1.1 vR cR, lr.1, lr.2)
    else
      step1
  { st := step2.1, leftIdx := step2.2.1, rightIdx := step2.2.2 }

noncomputable def coupledRepairList {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    (A B_rat τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b) :
    List (CopyVertex ℕ) → ConfigDynamicState L_p2 R ℓ M₀ d b →
      ConfigDynamicState L_p2 R ℓ M₀ d b × List (Option ℕ)
  | [], cs => (cs, [])
  | u :: us, cs =>
      open Classical in
      if cs.st.isCopyMatched u ∨ cs.st.isCopyInIndex u then
        coupledRepairList hM₀ T p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
          pts o V cfg ω_L ω_R us cs
      else
        let b_thr : ℝ := (bRatCfg params cfg : ℝ)
        let rawAns : Option ℕ :=
          match u.side with
          | .left => cs.rightIdx.query hM₀ M_lat A B_rat τ_q b_thr cap_q o (pts u.id)
          | .right => cs.leftIdx.query hM₀ M_lat A B_rat τ_q b_thr cap_q o (pts u.id)
        let cAns := sanitizeConfigAttachAnswer pts params o V cfg cs.st u rawAns
        let lr := syncIndicesOnAttach hM₀ T p_coord A B_rat τ_d cap_u
          pts o u cAns ω_L ω_R cs.leftIdx cs.rightIdx
        let cs₁ : ConfigDynamicState L_p2 R ℓ M₀ d b :=
          { st := attachStep pts cs.st u cAns, leftIdx := lr.1, rightIdx := lr.2 }
        let res := coupledRepairList hM₀ T p_coord M_lat params A B_rat τ_d τ_q
          cap_u cap_q pts o V cfg ω_L ω_R us cs₁
        (res.1, rawAns :: res.2)

noncomputable def ConfigDynamicState.deleteOriginal {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    (A B_rat τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) (p : ℕ)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) :
    ConfigDynamicState L_p2 R ℓ M₀ d b :=
  let cs₀ : ConfigDynamicState L_p2 R ℓ M₀ d b :=
    { st := removeCopiesFromState cs.st p
      leftIdx := cs.leftIdx.removeHandle p
      rightIdx := cs.rightIdx.removeHandle p }
  (coupledRepairList hM₀ T p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
    pts o V cfg ω_L ω_R (survivingFormerPartners cs.st p) cs₀).1

theorem coupledRepairList_st_eq {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    (A B_rat τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b) :
    ∀ (F : List (CopyVertex ℕ)) (cs : ConfigDynamicState L_p2 R ℓ M₀ d b),
      let res := coupledRepairList hM₀ T p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
        pts o V cfg ω_L ω_R F cs
      res.1.st = checkedRepairFormerPartners pts params o V cfg cs.st F res.2
  | [], _ => rfl
  | u :: us, cs => by
      dsimp only [coupledRepairList]
      by_cases hcond : cs.st.isCopyMatched u ∨ cs.st.isCopyInIndex u
      · rw [if_pos hcond]
        unfold checkedRepairFormerPartners
        rw [if_pos hcond]
        exact coupledRepairList_st_eq hM₀ T p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
          pts o V cfg ω_L ω_R us cs
      · rw [if_neg hcond]
        dsimp only
        unfold checkedRepairFormerPartners
        rw [if_neg hcond]
        dsimp only [List.head?_cons, Option.join, List.drop_succ_cons, List.drop_zero]
        exact coupledRepairList_st_eq hM₀ T p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
          pts o V cfg ω_L ω_R us _

/-- Deterministic structural invariant of `ConfigDynamicState` at `(o, V)` (`0 < V`). -/
def ConfigDynamicWF {L_p2 R ℓ M₀ d b : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams) (A B_rat τ_d : ℚ) (cap_u : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ℕ) (cfg : ShellConfig)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) : Prop :=
  cs.st.WellFormed pts
    (params.leftVertices pts o V S cfg.j)
    (params.rightVertices pts o V S cfg.k) ∧
  cs.st.matching ⊆ params.weakEdges pts o V S cfg.j cfg.k cfg.ℓ ∧
  DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o cs.st.leftIndexSet cs.leftIdx ∧
  DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o cs.st.rightIndexSet cs.rightIdx

/-- Non-dependent good-event invariant of `ConfigDynamicState` at `(o, V)` (`0 < V`). -/
def ConfigDynamicGood {L_p2 R ℓ M₀ d b : ℕ}
    (T p_coord M_lat : ℕ) (params : LocalScaleParams) (A B_rat τ_d τ_q : ℚ)
    (hAB : A ^ 2 + B_rat ^ 2 = 1) (h : ℝ) (hh0 : 0 < h) (hh1 : h < 1)
    (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ℕ) (cfg : ShellConfig)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) : Prop :=
  cs.st.SatisfiesInvariant pts
    (params.leftVertices pts o V S cfg.j)
    (params.rightVertices pts o V S cfg.k)
    (params.weakEdges pts o V S cfg.j cfg.k cfg.ℓ)
    (params.strongEdges pts o V S cfg.j cfg.k cfg.ℓ) ∧
  DyadicSideGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o cs.leftIdx ∧
  DyadicSideGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o cs.rightIdx

theorem configDynamic_empty_wf {L_p2 R ℓ M₀ d b : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams) (A B_rat τ_d : ℚ) (cap_u : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    {cfg : ShellConfig} (hcfg : cfg ∈ params.retainedConfigs 1) :
    ConfigDynamicWF hM₀ T p_coord params A B_rat τ_d cap_u pts o V ∅ cfg
      (ConfigDynamicState.empty L_p2 R ℓ M₀ d b T p_coord) := by
  have hval := empty_validNodeMatchingsOn pts (.subSqrt2 params) ⟨o, V, hV.le⟩
  have hmem_mode : cfg ∈ (Alg4Mode.subSqrt2 params).retainedConfigs V := by
    dsimp [Alg4Mode.retainedConfigs]
    rw [if_pos hV, retainedConfigs_eq_one params hV]
    exact hcfg
  rcases hval.2 cfg hmem_mode with ⟨hwf_st, hsub⟩
  have hl_empty : (LocalMatchingState.empty ℕ).leftIndexSet = ∅ := rfl
  have hr_empty : (LocalMatchingState.empty ℕ).rightIndexSet = ∅ := rfl
  refine ⟨hwf_st, hsub, ?_, ?_⟩
  · dsimp [ConfigDynamicState.empty]; rw [hl_empty]; exact dyadicSide_empty_wf hM₀ T p_coord A B_rat τ_d cap_u pts o
  · dsimp [ConfigDynamicState.empty]; rw [hr_empty]; exact dyadicSide_empty_wf hM₀ T p_coord A B_rat τ_d cap_u pts o

theorem configDynamic_empty_good {L_p2 R ℓ M₀ d b : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord M_lat : ℕ) (params : LocalScaleParams) (A B_rat τ_d τ_q : ℚ)
    (hAB : A ^ 2 + B_rat ^ 2 = 1) (h : ℝ) (hh0 : 0 < h) (hh1 : h < 1)
    (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    {cfg : ShellConfig} (hcfg : cfg ∈ params.retainedConfigs 1) :
    ConfigDynamicGood T p_coord M_lat params A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q
      pts o V ∅ cfg (ConfigDynamicState.empty L_p2 R ℓ M₀ d b T p_coord) := by
  have hwf := configDynamic_empty_wf (L_p2 := L_p2) (R := R) (ℓ := ℓ) (b := b)
    hM₀ T p_coord params A B_rat τ_d cap_u pts o hV hcfg
  have hstrong_empty : params.strongEdges pts o V ∅ cfg.j cfg.k cfg.ℓ = ∅ := by
    ext ⟨x, y⟩
    simp [LocalScaleParams.strongEdges, configStrongEdges, strongEdgesOn,
      configLeftVertices, shellSubset, nodeCore]
  refine ⟨⟨hwf.1, hwf.2.1, ?_, ?_⟩,
    dyadicSide_empty_good T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o,
    dyadicSide_empty_good T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o⟩
  · exact bipartiteMatching_of_wellFormed hwf.1
  · rw [hstrong_empty]; exact Finset.disjoint_empty_left _

theorem isStoredMatchingEdge_storedEdge {ι : Type*} (st : LocalMatchingState ι) :
    IsStoredMatchingEdge st.matching st.storedEdge := by
  classical
  unfold LocalMatchingState.storedEdge LocalMatchingState.matching
  cases hhd : st.matchingList.head? with
  | none =>
      have hnil : st.matchingList = [] := List.head?_eq_none_iff.mp hhd
      simp [hnil, IsStoredMatchingEdge]
  | some e =>
      dsimp only [Option.map, IsStoredMatchingEdge]
      exact List.mem_toFinset.mpr (List.mem_map_of_mem (List.mem_of_head? hhd))

private lemma leftIndexSet_attachStep {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (st : LocalMatchingState ℕ) (v : CopyVertex ℕ) (cAns : Option ℕ) :
    (attachStep pts st v cAns).leftIndexSet =
      match v.side, cAns with
      | .left, some _ => st.leftIndexSet
      | .left, none => insert v.id st.leftIndexSet
      | .right, some w => st.leftIndexSet.erase w
      | .right, none => st.leftIndexSet := by
  classical
  rcases v with ⟨side, vid⟩
  cases side <;> cases cAns <;>
    ext z <;> simp only [attachStep, LocalMatchingState.leftIndexSet,
      List.mem_toFinset, List.mem_map, List.mem_append, List.mem_singleton,
      List.mem_filter, decide_eq_true_eq, Finset.mem_insert, Finset.mem_erase] <;>
    aesop

private lemma rightIndexSet_attachStep {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (st : LocalMatchingState ℕ) (v : CopyVertex ℕ) (cAns : Option ℕ) :
    (attachStep pts st v cAns).rightIndexSet =
      match v.side, cAns with
      | .left, some w => st.rightIndexSet.erase w
      | .left, none => st.rightIndexSet
      | .right, some _ => st.rightIndexSet
      | .right, none => insert v.id st.rightIndexSet := by
  classical
  rcases v with ⟨side, vid⟩
  cases side <;> cases cAns <;>
    ext z <;> simp only [attachStep, LocalMatchingState.rightIndexSet,
      List.mem_toFinset, List.mem_map, List.mem_append, List.mem_singleton,
      List.mem_filter, decide_eq_true_eq, Finset.mem_insert, Finset.mem_erase] <;>
    aesop

private lemma leftIndexSet_removeCopies (st : LocalMatchingState ℕ) (p : ℕ) :
    (removeCopiesFromState st p).leftIndexSet = st.leftIndexSet.erase p := by
  classical
  ext z
  simp only [removeCopiesFromState, LocalMatchingState.leftIndexSet,
    List.mem_toFinset, List.mem_map, List.mem_filter, decide_eq_true_eq, Finset.mem_erase]
  aesop

private lemma rightIndexSet_removeCopies (st : LocalMatchingState ℕ) (p : ℕ) :
    (removeCopiesFromState st p).rightIndexSet = st.rightIndexSet.erase p := by
  classical
  ext z
  simp only [removeCopiesFromState, LocalMatchingState.rightIndexSet,
    List.mem_toFinset, List.mem_map, List.mem_filter, decide_eq_true_eq, Finset.mem_erase]
  aesop

theorem configDynamic_pts_congr {L_p2 R ℓ M₀ d b : ℕ} {hM₀ : 1 ≤ M₀}
    {T p_coord : ℕ} {params : LocalScaleParams} {A B_rat τ_d : ℚ} {cap_u : ℕ}
    {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)} {V : ℝ}
    {S : Finset ℕ} {cfg : ShellConfig}
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    (heq : ∀ x ∈ S, pts' x = pts x)
    (hwf : ConfigDynamicWF hM₀ T p_coord params A B_rat τ_d cap_u pts o V S cfg cs) :
    ConfigDynamicWF hM₀ T p_coord params A B_rat τ_d cap_u pts' o V S cfg cs := by
  classical
  rcases hwf with ⟨hwf_st, hsub, hwfL, hwfR⟩
  have hVL_eq : params.leftVertices pts' o V S cfg.j = params.leftVertices pts o V S cfg.j :=
    configLeftVertices_congr params.m0 o V cfg.j heq
  have hVR_eq : params.rightVertices pts' o V S cfg.k = params.rightVertices pts o V S cfg.k :=
    configRightVertices_congr params.m0 o V params.K cfg.k heq
  have hVL_sub : params.leftVertices pts o V S cfg.j ⊆ S := by
    intro x hx; exact nodeCore_subset _ _ _ _ (Finset.filter_subset _ _ hx)
  have hVR_sub : params.rightVertices pts o V S cfg.k ⊆ S := by
    intro x hx; exact Finset.filter_subset _ _ (Finset.filter_subset _ _ hx)
  have hEW_eq : params.weakEdges pts' o V S cfg.j cfg.k cfg.ℓ =
      params.weakEdges pts o V S cfg.j cfg.k cfg.ℓ := by
    unfold LocalScaleParams.weakEdges configWeakEdges
    rw [show configLeftVertices pts' params.m0 o V S cfg.j =
          configLeftVertices pts params.m0 o V S cfg.j from hVL_eq,
        show configRightVertices pts' params.m0 o V params.K S cfg.k =
          configRightVertices pts params.m0 o V params.K S cfg.k from hVR_eq]
    exact weakEdgesOn_congr params.m0 params.lam o V cfg.ℓ
      (fun x hx => heq x (hVL_sub hx))
      (fun y hy => heq y (hVR_sub hy))
  have hwf_st' : cs.st.WellFormed pts'
      (params.leftVertices pts' o V S cfg.j)
      (params.rightVertices pts' o V S cfg.k) := by
    rw [hVL_eq, hVR_eq]
    exact (localMatchingState_wellFormed_congr cs.st
      (fun x hx => heq x (hVL_sub hx))
      (fun y hy => heq y (hVR_sub hy))).mpr hwf_st
  have hUL_sub : cs.st.leftIndexSet ⊆ S := by
    rw [hwf_st.2.2.2.2.1]
    intro x hx
    exact hVL_sub (Finset.mem_of_mem_filter x hx)
  have hUR_sub : cs.st.rightIndexSet ⊆ S := by
    rw [hwf_st.2.2.2.2.2.2.1]
    intro x hx
    exact hVR_sub (Finset.mem_of_mem_filter x hx)
  exact ⟨hwf_st', hEW_eq ▸ hsub,
    dyadicSide_pts_congr hwfL (fun x hx => heq x (hUL_sub hx)),
    dyadicSide_pts_congr hwfR (fun x hx => heq x (hUR_sub hx))⟩

theorem configDynamic_good_pts_congr {L_p2 R ℓ M₀ d b : ℕ} {hM₀ : 1 ≤ M₀}
    {T p_coord M_lat : ℕ} {params : LocalScaleParams} {A B_rat τ_d τ_q : ℚ}
    (hAB : A ^ 2 + B_rat ^ 2 = 1) {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1)
    {cap_u cap_q : ℕ}
    {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)} {V : ℝ}
    {S : Finset ℕ} {cfg : ShellConfig}
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    (heq : ∀ x ∈ S, pts' x = pts x)
    (hwf : ConfigDynamicWF hM₀ T p_coord params A B_rat τ_d cap_u pts o V S cfg cs)
    (hgd : ConfigDynamicGood T p_coord M_lat params A B_rat τ_d τ_q hAB h hh0 hh1
      cap_u cap_q pts o V S cfg cs) :
    ConfigDynamicGood T p_coord M_lat params A B_rat τ_d τ_q hAB h hh0 hh1
      cap_u cap_q pts' o V S cfg cs := by
  classical
  have hwf' := configDynamic_pts_congr heq hwf
  have hVL_eq : params.leftVertices pts' o V S cfg.j = params.leftVertices pts o V S cfg.j :=
    configLeftVertices_congr params.m0 o V cfg.j heq
  have hVR_eq : params.rightVertices pts' o V S cfg.k = params.rightVertices pts o V S cfg.k :=
    configRightVertices_congr params.m0 o V params.K cfg.k heq
  have hES_eq : params.strongEdges pts' o V S cfg.j cfg.k cfg.ℓ =
      params.strongEdges pts o V S cfg.j cfg.k cfg.ℓ := by
    unfold LocalScaleParams.strongEdges configStrongEdges strongEdgesOn
    rw [show configLeftVertices pts' params.m0 o V S cfg.j =
          configLeftVertices pts params.m0 o V S cfg.j from hVL_eq,
        show configRightVertices pts' params.m0 o V params.K S cfg.k =
          configRightVertices pts params.m0 o V params.K S cfg.k from hVR_eq]
    ext ⟨x, y⟩
    simp only [Finset.mem_filter, Finset.mem_product, and_congr_right_iff]
    rintro ⟨hx, hy⟩
    have hxS : x ∈ S := nodeCore_subset _ _ _ _ (Finset.filter_subset _ _ hx)
    have hyS : y ∈ S := Finset.filter_subset _ _ (Finset.filter_subset _ _ hy)
    simp only [IsStrongRoundedPair, heq x hxS, heq y hyS]
  refine ⟨⟨hwf'.1, hwf'.2.1, bipartiteMatching_of_wellFormed hwf'.1, ?_⟩, hgd.2.1, hgd.2.2⟩
  rw [hVL_eq, hVR_eq, hES_eq]
  exact hgd.1.2.2.2

theorem StepSeedGood.of_eq {L_p2 R ℓ M₀ d b : ℕ}
    {T p_coord M_lat : ℕ} {A B_rat τ_d τ_q : ℚ} {hAB : A ^ 2 + B_rat ^ 2 = 1}
    {h : ℝ} {hh0 : 0 < h} {hh1 : h < 1} {cap_u cap_q : ℕ}
    {o : EuclideanSpace ℝ (Fin d)}
    {idx₁ idx₂ : DyadicSideIndex L_p2 R ℓ M₀ d b}
    {ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b}
    (ht : idx₂.t_ins = idx₁.t_ins)
    (hpt : idx₂.entryPt = idx₁.entryPt)
    (hg : StepSeedGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o idx₁ ω_step) :
    StepSeedGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o idx₂ ω_step := by
  unfold StepSeedGood at hg ⊢
  dsimp only at hg ⊢
  intro s hq2 hoff2 hne2
  have hq1 : 1 ≤ idx₁.t_ins / (2 * 2 ^ s.val) := by rwa [← ht]
  have hoff1 : idx₁.t_ins % (2 * 2 ^ s.val) = 0 := by rwa [← ht]
  have hne1 : ∀ j : Fin (2 * 2 ^ s.val),
      idx₁.entryPt ((idx₁.t_ins / (2 * 2 ^ s.val) - 1) * (2 * 2 ^ s.val) + j.val) ≠ o := by
    intro j; rw [← hpt, ← ht]; exact hne2 j
  have h1 := hg s hq1 hoff1 hne1
  have hgen_eq :
      mkPaddedGeneration (Nat.one_le_two_pow : 1 ≤ 2 ^ L_p2) idx₂.entryPt o A B_rat hAB h hh0 hh1
        (fun j : Fin (2 * 2 ^ s.val) => (idx₂.t_ins / (2 * 2 ^ s.val) - 1) * (2 * 2 ^ s.val) + j.val) hne2 =
      mkPaddedGeneration (Nat.one_le_two_pow : 1 ≤ 2 ^ L_p2) idx₁.entryPt o A B_rat hAB h hh0 hh1
        (fun j : Fin (2 * 2 ^ s.val) => (idx₁.t_ins / (2 * 2 ^ s.val) - 1) * (2 * 2 ^ s.val) + j.val) hne1 := by
    unfold mkPaddedGeneration
    congr 1
    funext k
    simp only [ht, hpt]
  rwa [hgen_eq]

private lemma validNodeMatchings_with_single {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (params : LocalScaleParams)
    (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    (S : Finset ℕ) {cfg : ShellConfig} (hcfg_V : cfg ∈ params.retainedConfigs V)
    (st : LocalMatchingState ℕ)
    (hwf_st : st.WellFormed pts (params.leftVertices pts o V S cfg.j)
      (params.rightVertices pts o V S cfg.k))
    (hsub : st.matching ⊆ params.weakEdges pts o V S cfg.j cfg.k cfg.ℓ) :
    ∃ states_all : ShellConfig → LocalMatchingState ℕ,
      ValidNodeMatchingsOn pts (.subSqrt2 params) ⟨o, V, hV.le⟩ S states_all ∧
      states_all cfg = st := by
  classical
  let ball : ChainNode d := ⟨o, V, hV.le⟩
  have hfold_val : ∀ (xs : List ℕ) (hnd : xs.Nodup) (curS : Finset ℕ)
      (curSt : ShellConfig → LocalMatchingState ℕ),
      Disjoint xs.toFinset curS →
      ValidNodeMatchingsOn pts (.subSqrt2 params) ball curS curSt →
      ValidNodeMatchingsOn pts (.subSqrt2 params) ball (xs.toFinset ∪ curS)
        (xs.foldl (fun acc x => applyNodeMatchingInsert pts (.subSqrt2 params) ball acc x
          (NodeMatchingQueryAnswers.empty ℕ)) curSt) := by
    intro xs
    induction xs with
    | nil => intro _ curS curSt _ hv; simpa using hv
    | cons x tl ih =>
        intro hnd curS curSt hdisj hv
        rcases List.nodup_cons.mp hnd with ⟨hx_tl, hnd_tl⟩
        have hx_cur : x ∉ curS :=
          Finset.disjoint_left.mp hdisj (List.mem_toFinset.mpr List.mem_cons_self)
        have hv1 := applyNodeMatchingInsert_valid pts (.subSqrt2 params) ball
          hx_cur (NodeMatchingQueryAnswers.empty ℕ) hv
        have hcls_ins : @insert ℕ (Finset ℕ) (@Finset.instInsert ℕ (Classical.decEq ℕ)) x curS = insert x curS := by
          ext z; simp
        rw [hcls_ins] at hv1
        have hdisj' : Disjoint tl.toFinset (insert x curS) := by
          rw [Finset.disjoint_left]
          intro y hy hmem
          rcases Finset.mem_insert.mp hmem with rfl | hy_cur
          · exact hx_tl (List.mem_toFinset.mp hy)
          · exact Finset.disjoint_left.mp hdisj
              (List.mem_toFinset.mpr (List.mem_cons_of_mem x (List.mem_toFinset.mp hy))) hy_cur
        have ih_res := ih hnd_tl (insert x curS) _ hdisj' hv1
        have hunion : (x :: tl).toFinset ∪ curS = tl.toFinset ∪ insert x curS := by
          ext z; simp
        rwa [hunion]
  let baseStates := S.toList.foldl
    (fun acc x => applyNodeMatchingInsert pts (.subSqrt2 params) ball acc x
      (NodeMatchingQueryAnswers.empty ℕ))
    (fun _ => LocalMatchingState.empty ℕ)
  have hbase := hfold_val S.toList S.nodup_toList ∅ _ (Finset.disjoint_empty_right _)
    (empty_validNodeMatchingsOn pts (.subSqrt2 params) ball)
  simp only [Finset.toList_toFinset, Finset.union_empty] at hbase
  refine ⟨Function.update baseStates cfg st, ⟨?_, ?_⟩, Function.update_self cfg st baseStates⟩
  · intro c hc
    have hne_c : c ≠ cfg := by
      intro heq; subst heq; apply hc
      dsimp [Alg4Mode.retainedConfigs]; rw [if_pos hV]; exact hcfg_V
    rw [Function.update_of_ne hne_c]; exact hbase.1 c hc
  · intro c hc
    by_cases heq : c = cfg
    · subst heq; simpa using ⟨hwf_st, hsub⟩
    · rw [Function.update_of_ne heq]; exact hbase.2 c hc

private lemma classical_insert_nat (p : ℕ) (S : Finset ℕ) :
    @insert ℕ (Finset ℕ) (@Finset.instInsert ℕ (Classical.decEq ℕ)) p S = insert p S := by
  ext z; simp

private lemma classical_erase_nat (p : ℕ) (S : Finset ℕ) :
    @Finset.erase ℕ (@Classical.decEq ℕ) S p = S.erase p := by
  ext z; simp

theorem configDynamic_insert_spec {L_p2 R ℓ M₀ d b : ℕ}
    (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams) (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (spec : ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1)
    (cap_u cap_q : ℕ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)} {V : ℝ} (hV : 0 < V)
    {S : Finset ℕ} {p : ℕ} (hp : p ∉ S)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    (htL : cs.leftIdx.t_ins + 1 < 2 ^ L_p2) (htR : cs.rightIdx.t_ins + 1 < 2 ^ L_p2)
    (hwf : ConfigDynamicWF hM₀ T p_coord params spec.A spec.B τ_d cap_u pts o V S spec.cfg cs) :
    let M_lat := M_lat_of d params.e
    let cs' := cs.insertOriginal hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q
      cap_u cap_q pts o V spec.cfg p ω_L ω_R
    cs'.leftIdx.t_ins ≤ cs.leftIdx.t_ins + 1 ∧
    cs'.rightIdx.t_ins ≤ cs.rightIdx.t_ins + 1 ∧
    ConfigDynamicWF hM₀ T p_coord params spec.A spec.B τ_d cap_u pts o V (insert p S) spec.cfg cs' ∧
    (ConfigDynamicGood T p_coord M_lat params spec.A spec.B τ_d τ_q spec.hAB
        h hh0 hh1 cap_u cap_q pts o V S spec.cfg cs →
     StepSeedGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.leftIdx ω_L →
     StepSeedGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.rightIdx ω_R →
     ConfigDynamicGood T p_coord M_lat params spec.A spec.B τ_d τ_q spec.hAB
        h hh0 hh1 cap_u cap_q pts o V (insert p S) spec.cfg cs') := by
  let M_lat := M_lat_of d params.e
  let cfg := spec.cfg
  have hcfg_V : cfg ∈ params.retainedConfigs V := by
    rw [retainedConfigs_eq_one params hV]; exact spec.mem_one
  rcases retainedConfig_shells_pos params spec.mem_one with ⟨hj1, _, hk1, _, _⟩
  have he0 : 0 < (params.e : ℝ) := by exact_mod_cast params.e_pos
  have hb_eq : params.thresholdB V cfg.j cfg.k cfg.ℓ = (bRatCfg params cfg : ℝ) :=
    thresholdB_eq_bRatCfg params hV cfg
  have hba : (bRatCfg params cfg : ℝ) ≤ params.thresholdA V cfg.j cfg.k cfg.ℓ := by
    rw [← hb_eq]; exact thresholdB_le_thresholdA params hV cfg
  have hsep_V : ∀ (u z z_bar : EuclideanSpace ℝ (Fin d)),
      ‖u‖ = 1 → ‖z‖ = 1 → ‖z_bar‖ = 1 → ‖z_bar - z‖ ≤ (params.e : ℝ) / 8 →
      (params.thresholdA V cfg.j cfg.k cfg.ℓ ≤ inner ℝ z u →
        h ≤ inner ℝ (liftedPoint ((spec.A : ℝ) • z_bar) (-(spec.B : ℝ)))
              (liftedPoint ((spec.A : ℝ) • u) (spec.B : ℝ))) ∧
      (inner ℝ z u ≤ (bRatCfg params cfg : ℝ) →
        inner ℝ (liftedPoint ((spec.A : ℝ) • z_bar) (-(spec.B : ℝ)))
              (liftedPoint ((spec.A : ℝ) • u) (spec.B : ℝ)) < 0) := by
    intro u z z_bar hu hz hzb hdist
    rw [thresholdA_eq_one params hV]
    have h1 := spec.sep u z z_bar hu hz hzb hdist
    rwa [thresholdB_eq_bRatCfg params zero_lt_one] at h1
  let rawLeft : Option ℕ := open Classical in
    if hasApplicableLeftCopy params.m0 o V cfg.j (pts p) then
      cs.rightIdx.query hM₀ M_lat spec.A spec.B τ_q (bRatCfg params cfg : ℝ) cap_q o (pts p)
    else none
  let step1 : LocalMatchingState ℕ × DyadicSideIndex L_p2 R ℓ M₀ d b × DyadicSideIndex L_p2 R ℓ M₀ d b :=
    open Classical in
    if hasApplicableLeftCopy params.m0 o V cfg.j (pts p) then
      let vL : CopyVertex ℕ := ⟨.left, p⟩
      let cL := sanitizeConfigAttachAnswer pts params o V cfg cs.st vL rawLeft
      let lr := syncIndicesOnAttach hM₀ T p_coord spec.A spec.B τ_d cap_u pts o vL cL ω_L ω_R cs.leftIdx cs.rightIdx
      (attachStep pts cs.st vL cL, lr.1, lr.2)
    else (cs.st, cs.leftIdx, cs.rightIdx)
  let rawRight : Option ℕ := open Classical in
    if hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p) then
      step1.2.1.query hM₀ M_lat spec.A spec.B τ_q (bRatCfg params cfg : ℝ) cap_q o (pts p)
    else none
  let cs' := cs.insertOriginal hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q
    cap_u cap_q pts o V cfg p ω_L ω_R
  have hst'_eq : cs'.st = checkedConfigInsertOriginal pts params o V cfg cs.st p rawLeft rawRight := by
    classical
    dsimp [cs', ConfigDynamicState.insertOriginal, checkedConfigInsertOriginal,
      rawLeft, step1, rawRight]
    split_ifs <;> rfl
  obtain ⟨states_all, hval_all, hst_at_cfg⟩ :=
    validNodeMatchings_with_single pts params o hV S hcfg_V cs.st hwf.1 hwf.2.1
  let qAns : NodeMatchingQueryAnswers ℕ :=
    { insertLeftAns := fun _ => rawLeft
      insertRightAns := fun _ => rawRight
      deleteRepairAns := fun _ => [] }
  have hval_ins := applyNodeMatchingInsert_valid pts (.subSqrt2 params) ⟨o, V, hV.le⟩ hp qAns hval_all
  rw [classical_insert_nat] at hval_ins
  have hmem_mode : cfg ∈ (Alg4Mode.subSqrt2 params).retainedConfigs V := by
    dsimp [Alg4Mode.retainedConfigs]; rw [if_pos hV]; exact hcfg_V
  have hcfg_ins := hval_ins.2 cfg hmem_mode
  dsimp only [applyNodeMatchingInsert, qAns] at hcfg_ins
  rw [if_pos hmem_mode, hst_at_cfg, ← hst'_eq] at hcfg_ins
  rcases hwf.1 with ⟨_, _, _, _, hlset_eq, _, hrset_eq, _⟩
  have hp_not_UL : p ∉ cs.st.leftIndexSet := by
    classical
    rw [hlset_eq]; intro hm
    exact hp (nodeCore_subset _ _ _ _ (Finset.filter_subset _ _ (Finset.mem_of_mem_filter p hm)))
  have hp_not_UR : p ∉ cs.st.rightIndexSet := by
    classical
    rw [hrset_eq]; intro hm
    exact hp (Finset.filter_subset _ _ (Finset.filter_subset _ _ (Finset.mem_of_mem_filter p hm)))
  -- Step 1 (`left` copy of `p`)
  have hstep1 :
      step1.2.1.t_ins ≤ cs.leftIdx.t_ins + 1 ∧
      step1.2.2.t_ins = cs.rightIdx.t_ins ∧
      step1.2.2.entryPt = cs.rightIdx.entryPt ∧
      DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o step1.1.leftIndexSet step1.2.1 ∧
      DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o step1.1.rightIndexSet step1.2.2 ∧
      (DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.leftIdx →
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.rightIdx →
       StepSeedGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.leftIdx ω_L →
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o step1.2.1 ∧
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o step1.2.2) := by
    classical
    dsimp only [step1]
    by_cases hL : hasApplicableLeftCopy params.m0 o V cfg.j (pts p)
    · have hp_ne_o : pts p ≠ o := ne_center_of_shellIndex_pos hj1 hL.2
      rw [if_pos hL]
      dsimp only
      set cL := sanitizeConfigAttachAnswer pts params o V cfg cs.st ⟨.left, p⟩ rawLeft
      cases hcL : cL with
      | some w =>
          dsimp only [syncIndicesOnAttach]
          rw [leftIndexSet_attachStep, rightIndexSet_attachStep]
          dsimp only
          have hrem := dyadicSide_remove_spec (M_lat := M_lat) (τ_q := τ_q) (cap_q := cap_q) spec.hAB hh0 hh1 w hwf.2.2.2
          exact ⟨Nat.le_succ _, hrem.1, by
            unfold DyadicSideIndex.removeHandle; dsimp only; split_ifs <;> rfl,
            hwf.2.2.1, hrem.2.1, fun hgL hgR _ => ⟨hgL, hrem.2.2 hgR⟩⟩
      | none =>
          dsimp only [syncIndicesOnAttach]
          rw [leftIndexSet_attachStep, rightIndexSet_attachStep]
          dsimp only
          have hins := dyadicSide_insert_spec hM₀ T p_coord M_lat spec.A spec.B τ_d τ_q
            spec.hAB h hh0 hh1 cap_u cap_q hp_not_UL hp_ne_o ω_L hwf.2.2.1
          exact ⟨le_of_eq hins.1, rfl, rfl, hins.2.1, hwf.2.2.2,
            fun hgL hgR hseedL => ⟨hins.2.2 hgL hseedL, hgR⟩⟩
    · rw [if_neg hL]
      exact ⟨Nat.le_succ _, rfl, rfl, hwf.2.2.1, hwf.2.2.2, fun hgL hgR _ => ⟨hgL, hgR⟩⟩
  have hp_not_UR1 : p ∉ step1.1.rightIndexSet := by
    classical
    dsimp only [step1]
    by_cases hL : hasApplicableLeftCopy params.m0 o V cfg.j (pts p)
    · rw [if_pos hL]; dsimp only; rw [rightIndexSet_attachStep]
      cases sanitizeConfigAttachAnswer pts params o V cfg cs.st ⟨.left, p⟩ rawLeft with
      | none => exact hp_not_UR
      | some _ => intro hm; exact hp_not_UR (Finset.mem_of_mem_erase hm)
    · rw [if_neg hL]; exact hp_not_UR
  -- Step 2 (`right` copy of `p`)
  have hstep2 :
      cs'.leftIdx.t_ins ≤ step1.2.1.t_ins ∧
      cs'.rightIdx.t_ins ≤ step1.2.2.t_ins + 1 ∧
      DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o cs'.st.leftIndexSet cs'.leftIdx ∧
      DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o cs'.st.rightIndexSet cs'.rightIdx ∧
      (DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o step1.2.1 →
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o step1.2.2 →
       StepSeedGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.rightIdx ω_R →
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs'.leftIdx ∧
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs'.rightIdx) := by
    classical
    dsimp only [cs', ConfigDynamicState.insertOriginal, rawLeft, step1, rawRight]
    change
      let step2 : LocalMatchingState ℕ × DyadicSideIndex L_p2 R ℓ M₀ d b × DyadicSideIndex L_p2 R ℓ M₀ d b :=
        if hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p) then
          let vR : CopyVertex ℕ := ⟨.right, p⟩
          let cR := sanitizeConfigAttachAnswer pts params o V cfg step1.1 vR rawRight
          let lr := syncIndicesOnAttach hM₀ T p_coord spec.A spec.B τ_d cap_u pts o vR cR ω_L ω_R step1.2.1 step1.2.2
          (attachStep pts step1.1 vR cR, lr.1, lr.2)
        else step1
      step2.2.1.t_ins ≤ step1.2.1.t_ins ∧
      step2.2.2.t_ins ≤ step1.2.2.t_ins + 1 ∧
      DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o step2.1.leftIndexSet step2.2.1 ∧
      DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o step2.1.rightIndexSet step2.2.2 ∧
      (DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o step1.2.1 →
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o step1.2.2 →
       StepSeedGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.rightIdx ω_R →
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o step2.2.1 ∧
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o step2.2.2)
    dsimp only
    by_cases hR : hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p)
    · have hp_ne_o : pts p ≠ o := ne_center_of_shellIndex_pos hk1 hR.2
      rw [if_pos hR]
      dsimp only
      set cR := sanitizeConfigAttachAnswer pts params o V cfg step1.1 ⟨.right, p⟩ rawRight
      cases hcR : cR with
      | some w =>
          dsimp only [syncIndicesOnAttach]
          rw [leftIndexSet_attachStep, rightIndexSet_attachStep]
          dsimp only
          have hrem := dyadicSide_remove_spec (M_lat := M_lat) (τ_q := τ_q) (cap_q := cap_q) spec.hAB hh0 hh1 w hstep1.2.2.2.1
          exact ⟨le_of_eq hrem.1, Nat.le_succ _, hrem.2.1, hstep1.2.2.2.2.1,
            fun hgL₁ hgR₁ _ => ⟨hrem.2.2 hgL₁, hgR₁⟩⟩
      | none =>
          dsimp only [syncIndicesOnAttach]
          rw [leftIndexSet_attachStep, rightIndexSet_attachStep]
          dsimp only
          have hins := dyadicSide_insert_spec hM₀ T p_coord M_lat spec.A spec.B τ_d τ_q
            spec.hAB h hh0 hh1 cap_u cap_q hp_not_UR1 hp_ne_o ω_R hstep1.2.2.2.2.1
          exact ⟨le_rfl, le_of_eq hins.1, hstep1.2.2.2.1, hins.2.1,
            fun hgL₁ hgR₁ hseedR => ⟨hgL₁, hins.2.2 hgR₁ (StepSeedGood.of_eq hstep1.2.1 hstep1.2.2.1 hseedR)⟩⟩
    · rw [if_neg hR]
      exact ⟨le_rfl, Nat.le_succ _, hstep1.2.2.2.1, hstep1.2.2.2.2.1, fun hgL₁ hgR₁ _ => ⟨hgL₁, hgR₁⟩⟩
  have hwf' : ConfigDynamicWF hM₀ T p_coord params spec.A spec.B τ_d cap_u
      pts o V (insert p S) cfg cs' :=
    ⟨hcfg_ins.1, hcfg_ins.2, hstep2.2.2.1, hstep2.2.2.2.1⟩
  have htL' : cs'.leftIdx.t_ins ≤ cs.leftIdx.t_ins + 1 := hstep2.1.trans hstep1.1
  have htR' : cs'.rightIdx.t_ins ≤ cs.rightIdx.t_ins + 1 := by
    have := hstep2.2.1; have := hstep1.2.1; omega
  refine ⟨htL', htR', hwf', fun hgd hseedL hseedR => ?_⟩
  rcases hstep1.2.2.2.2.2 hgd.2.1 hgd.2.2 hseedL with ⟨hgL₁, hgR₁⟩
  rcases hstep2.2.2.2.2 hgL₁ hgR₁ hseedR with ⟨hgL₂, hgR₂⟩
  have hst1_eq : step1.1 =
      (open Classical in
       if hasApplicableLeftCopy params.m0 o V cfg.j (pts p) then
         let vL : CopyVertex ℕ := ⟨.left, p⟩
         attachStep pts cs.st vL (sanitizeConfigAttachAnswer pts params o V cfg cs.st vL rawLeft)
       else cs.st) := by
    classical
    dsimp only [step1]; split_ifs <;> rfl
  have hprom : ValidCheckedInsertPromises pts params o V cfg cs.st p rawLeft rawRight := by
    classical
    unfold ValidCheckedInsertPromises
    refine ⟨?_, ?_⟩
    · intro hL
      have hp_ne_o : pts p ≠ o := ne_center_of_shellIndex_pos hj1 hL.2
      dsimp only [rawLeft]
      rw [if_pos hL]
      unfold SatisfiesConfigSearchPromise
      change SatisfiesAngularSearchPromise pts o
        (params.thresholdA V cfg.j cfg.k cfg.ℓ) (params.thresholdB V cfg.j cfg.k cfg.ℓ)
        cs.st.rightIndexSet p _
      rw [hb_eq]
      exact dyadicSide_query_promise hd hM₀ T p_coord params.e spec.A spec.B τ_d τ_q
        he0 he1 spec.hAB h _ _ hh0 hh1 hba cap_u cap_q hp_ne_o (by omega) hsep_V
        hwf.2.2.2 hgd.2.2
    · intro _st₁ hR
      have hp_ne_o : pts p ≠ o := ne_center_of_shellIndex_pos hk1 hR.2
      have h_st1_eq : _st₁ = step1.1 := hst1_eq.symm
      dsimp only [rawRight]
      rw [if_pos hR, h_st1_eq]
      unfold SatisfiesConfigSearchPromise
      change SatisfiesAngularSearchPromise pts o
        (params.thresholdA V cfg.j cfg.k cfg.ℓ) (params.thresholdB V cfg.j cfg.k cfg.ℓ)
        step1.1.leftIndexSet p _
      rw [hb_eq]
      have ht1_lt : step1.2.1.t_ins < 2 ^ L_p2 := by have := hstep1.1; omega
      exact dyadicSide_query_promise hd hM₀ T p_coord params.e spec.A spec.B τ_d τ_q
        he0 he1 spec.hAB h _ _ hh0 hh1 hba cap_u cap_q hp_ne_o ht1_lt hsep_V
        hstep1.2.2.2.1 hgL₁
  rcases h_clm_7_3.1.2 with ⟨C_rep, _, hrep⟩
  have hinv' := ((hrep d ℕ pts params o V S cfg cs.st hV hcfg_V hgd.1).1 p rawLeft rawRight hp hprom).1
  rw [← hst'_eq] at hinv'
  exact ⟨hinv', hgL₂, hgR₂⟩

private lemma survivingFormerPartners_decomp {d : ℕ}
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ℕ}
    {st : LocalMatchingState ℕ} (hwf : st.WellFormed pts V_L V_R) (p : ℕ) :
    let rP := (st.matchingList.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
      (fun e => CopyVertex.mk .right e.right)
    let lP := (st.matchingList.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
      (fun e => CopyVertex.mk .left e.left)
    survivingFormerPartners st p = rP ++ lP ∧
    rP.length ≤ 1 ∧
    lP.length ≤ 1 ∧
    (∀ u ∈ rP, u.side = .right ∧ u.id ∈ V_R.erase p) ∧
    (∀ u ∈ lP, u.side = .left ∧ u.id ∈ V_L.erase p) := by
  rcases hwf with ⟨hndL, hndR, hedges, _⟩
  let rP := (st.matchingList.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
    (fun e => CopyVertex.mk .right e.right)
  let lP := (st.matchingList.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
    (fun e => CopyVertex.mk .left e.left)
  have hlenR : rP.length ≤ 1 := by
    rw [List.length_map]
    exact filter_eq_length_le_one hndL _ p (fun x hx => (of_decide_eq_true hx).1)
  have hlenL : lP.length ≤ 1 := by
    rw [List.length_map]
    exact filter_eq_length_le_one hndR _ p (fun x hx => (of_decide_eq_true hx).1)
  have hr_props : ∀ u ∈ rP, u.side = .right ∧ u.id ∈ V_R.erase p := by
    intro u hu
    rcases List.mem_map.mp hu with ⟨e, he, rfl⟩
    rcases List.mem_filter.mp he with ⟨he_mem, hdec⟩
    rcases of_decide_eq_true hdec with ⟨_, hne⟩
    exact ⟨rfl, Finset.mem_erase.mpr ⟨hne, (hedges e he_mem).2.1⟩⟩
  have hl_props : ∀ u ∈ lP, u.side = .left ∧ u.id ∈ V_L.erase p := by
    intro u hu
    rcases List.mem_map.mp hu with ⟨e, he, rfl⟩
    rcases List.mem_filter.mp he with ⟨he_mem, hdec⟩
    rcases of_decide_eq_true hdec with ⟨_, hne⟩
    exact ⟨rfl, Finset.mem_erase.mpr ⟨hne, (hedges e he_mem).1⟩⟩
  have hnd_rP : rP.Nodup := by
    cases hr : rP with
    | nil => exact List.nodup_nil
    | cons a tl =>
        rw [hr] at hlenR
        have htl : tl = [] := List.eq_nil_of_length_eq_zero (by simpa using hlenR)
        subst htl; exact List.nodup_singleton a
  have hnd_lP : lP.Nodup := by
    cases hl : lP with
    | nil => exact List.nodup_nil
    | cons a tl =>
        rw [hl] at hlenL
        have htl : tl = [] := List.eq_nil_of_length_eq_zero (by simpa using hlenL)
        subst htl; exact List.nodup_singleton a
  have hnd_app : (rP ++ lP).Nodup := by
    refine List.nodup_append.mpr ⟨hnd_rP, hnd_lP, fun a ha b hb heq => ?_⟩
    have hsa := (hr_props a ha).1
    have hsb := (hl_props b hb).1
    rw [heq, hsb] at hsa
    cases hsa
  have heq_dedup : survivingFormerPartners st p = rP ++ lP := by
    have hdedup_inst : ∀ (xs : List (CopyVertex ℕ)) (inst : DecidableEq (CopyVertex ℕ)),
        @List.dedup (CopyVertex ℕ) inst xs = xs.dedup := by
      intro xs inst
      rw [Subsingleton.elim inst (inferInstance : DecidableEq (CopyVertex ℕ))]
    unfold survivingFormerPartners
    dsimp only
    rw [hdedup_inst]
    have hfilt_eq :
        (List.map (fun e => CopyVertex.mk .right e.right)
          (List.filter (fun e => @decide (e.left = p ∧ e.right ≠ p)
            (Classical.propDecidable _)) st.matchingList)) ++
        (List.map (fun e => CopyVertex.mk .left e.left)
          (List.filter (fun e => @decide (e.right = p ∧ e.left ≠ p)
            (Classical.propDecidable _)) st.matchingList)) = rP ++ lP := by
      congr 1
      · congr 1; apply List.filter_congr; intro e _; exact decide_eq_decide.mpr Iff.rfl
      · congr 1; apply List.filter_congr; intro e _; exact decide_eq_decide.mpr Iff.rfl
    -- Even more robustly, handle ANY Decidable instance inside List.filter via convert!
    convert List.Nodup.dedup hnd_app using 2
    congr 1
    · congr 1; apply List.filter_congr; intro e _; exact decide_eq_decide.mpr Iff.rfl
    · congr 1; apply List.filter_congr; intro e _; exact decide_eq_decide.mpr Iff.rfl
  exact ⟨heq_dedup, hlenR, hlenL, hr_props, hl_props⟩

theorem configDynamic_delete_spec {L_p2 R ℓ M₀ d b : ℕ}
    (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams) (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (spec : ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1)
    (cap_u cap_q : ℕ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)} {V : ℝ} (hV : 0 < V)
    {S : Finset ℕ} {p : ℕ} (hp : p ∈ S)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    (htL : cs.leftIdx.t_ins + 1 < 2 ^ L_p2) (htR : cs.rightIdx.t_ins + 1 < 2 ^ L_p2)
    (hwf : ConfigDynamicWF hM₀ T p_coord params spec.A spec.B τ_d cap_u pts o V S spec.cfg cs) :
    let M_lat := M_lat_of d params.e
    let cs' := cs.deleteOriginal hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q
      cap_u cap_q pts o V spec.cfg p ω_L ω_R
    cs'.leftIdx.t_ins ≤ cs.leftIdx.t_ins + 1 ∧
    cs'.rightIdx.t_ins ≤ cs.rightIdx.t_ins + 1 ∧
    ConfigDynamicWF hM₀ T p_coord params spec.A spec.B τ_d cap_u pts o V (S.erase p) spec.cfg cs' ∧
    (ConfigDynamicGood T p_coord M_lat params spec.A spec.B τ_d τ_q spec.hAB
        h hh0 hh1 cap_u cap_q pts o V S spec.cfg cs →
     StepSeedGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.leftIdx ω_L →
     StepSeedGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.rightIdx ω_R →
     ConfigDynamicGood T p_coord M_lat params spec.A spec.B τ_d τ_q spec.hAB
        h hh0 hh1 cap_u cap_q pts o V (S.erase p) spec.cfg cs') := by
  let M_lat := M_lat_of d params.e
  let cfg := spec.cfg
  have hcfg_V : cfg ∈ params.retainedConfigs V := by
    rw [retainedConfigs_eq_one params hV]; exact spec.mem_one
  rcases retainedConfig_shells_pos params spec.mem_one with ⟨hj1, _, hk1, _, _⟩
  have he0 : 0 < (params.e : ℝ) := by exact_mod_cast params.e_pos
  have hb_eq : params.thresholdB V cfg.j cfg.k cfg.ℓ = (bRatCfg params cfg : ℝ) :=
    thresholdB_eq_bRatCfg params hV cfg
  have hba : (bRatCfg params cfg : ℝ) ≤ params.thresholdA V cfg.j cfg.k cfg.ℓ := by
    rw [← hb_eq]; exact thresholdB_le_thresholdA params hV cfg
  have hsep_V : ∀ (u z z_bar : EuclideanSpace ℝ (Fin d)),
      ‖u‖ = 1 → ‖z‖ = 1 → ‖z_bar‖ = 1 → ‖z_bar - z‖ ≤ (params.e : ℝ) / 8 →
      (params.thresholdA V cfg.j cfg.k cfg.ℓ ≤ inner ℝ z u →
        h ≤ inner ℝ (liftedPoint ((spec.A : ℝ) • z_bar) (-(spec.B : ℝ)))
              (liftedPoint ((spec.A : ℝ) • u) (spec.B : ℝ))) ∧
      (inner ℝ z u ≤ (bRatCfg params cfg : ℝ) →
        inner ℝ (liftedPoint ((spec.A : ℝ) • z_bar) (-(spec.B : ℝ)))
              (liftedPoint ((spec.A : ℝ) • u) (spec.B : ℝ)) < 0) := by
    intro u z z_bar hu hz hzb hdist
    rw [thresholdA_eq_one params hV]
    have h1 := spec.sep u z z_bar hu hz hzb hdist
    rwa [thresholdB_eq_bRatCfg params zero_lt_one] at h1
  let cs₀ : ConfigDynamicState L_p2 R ℓ M₀ d b :=
    { st := removeCopiesFromState cs.st p
      leftIdx := cs.leftIdx.removeHandle p
      rightIdx := cs.rightIdx.removeHandle p }
  let F := survivingFormerPartners cs.st p
  let rep := coupledRepairList hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q
    cap_u cap_q pts o V cfg ω_L ω_R F cs₀
  let cs' := cs.deleteOriginal hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q
    cap_u cap_q pts o V cfg p ω_L ω_R
  have hcs'_eq : cs' = rep.1 := rfl
  have hst'_eq : cs'.st = checkedConfigDeleteOriginal pts params o V cfg cs.st p rep.2 := by
    rw [hcs'_eq]
    exact coupledRepairList_st_eq hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q
      cap_u cap_q pts o V cfg ω_L ω_R F cs₀
  obtain ⟨states_all, hval_all, hst_at_cfg⟩ :=
    validNodeMatchings_with_single pts params o hV S hcfg_V cs.st hwf.1 hwf.2.1
  let qAns : NodeMatchingQueryAnswers ℕ :=
    { insertLeftAns := fun _ => none
      insertRightAns := fun _ => none
      deleteRepairAns := fun _ => rep.2 }
  have hval_del := applyNodeMatchingDelete_valid pts (.subSqrt2 params) ⟨o, V, hV.le⟩ p qAns hval_all
  rw [classical_erase_nat] at hval_del
  have hmem_mode : cfg ∈ (Alg4Mode.subSqrt2 params).retainedConfigs V := by
    dsimp [Alg4Mode.retainedConfigs]; rw [if_pos hV]; exact hcfg_V
  have hcfg_del := hval_del.2 cfg hmem_mode
  dsimp only [applyNodeMatchingDelete, qAns] at hcfg_del
  rw [if_pos hmem_mode, hst_at_cfg, ← hst'_eq] at hcfg_del
  have hremL := dyadicSide_remove_spec (M_lat := M_lat) (τ_q := τ_q) (cap_q := cap_q) spec.hAB hh0 hh1 p hwf.2.2.1
  have hremR := dyadicSide_remove_spec (M_lat := M_lat) (τ_q := τ_q) (cap_q := cap_q) spec.hAB hh0 hh1 p hwf.2.2.2
  have hwfL₀ : DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o cs₀.st.leftIndexSet cs₀.leftIdx := by
    dsimp [cs₀]; rw [leftIndexSet_removeCopies]; exact hremL.2.1
  have hwfR₀ : DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o cs₀.st.rightIndexSet cs₀.rightIdx := by
    dsimp [cs₀]; rw [rightIndexSet_removeCopies]; exact hremR.2.1
  have hptL₀ : cs₀.leftIdx.entryPt = cs.leftIdx.entryPt := by
    dsimp only [cs₀]; unfold DyadicSideIndex.removeHandle; dsimp only; split_ifs <;> rfl
  have hptR₀ : cs₀.rightIdx.entryPt = cs.rightIdx.entryPt := by
    dsimp only [cs₀]; unfold DyadicSideIndex.removeHandle; dsimp only; split_ifs <;> rfl
  rcases survivingFormerPartners_decomp hwf.1 p with ⟨hF_eq, hlenR, hlenL, hr_props, hl_props⟩
  have hmem_not_inIndexL : ∀ (st_cur : LocalMatchingState ℕ) (uid : ℕ),
      ¬ st_cur.isCopyInIndex ⟨.left, uid⟩ → uid ∉ st_cur.leftIndexSet := by
    intro st_cur uid hni hm
    have hm' := @List.mem_toFinset ℕ (Classical.decEq ℕ) _ uid |>.mp hm
    rcases List.mem_map.mp hm' with ⟨e, he, hid⟩
    exact hni ⟨e, he, hid⟩
  have hmem_not_inIndexR : ∀ (st_cur : LocalMatchingState ℕ) (uid : ℕ),
      ¬ st_cur.isCopyInIndex ⟨.right, uid⟩ → uid ∉ st_cur.rightIndexSet := by
    intro st_cur uid hni hm
    have hm' := @List.mem_toFinset ℕ (Classical.decEq ℕ) _ uid |>.mp hm
    rcases List.mem_map.mp hm' with ⟨e, he, hid⟩
    exact hni ⟨e, he, hid⟩
  have hsplit_app : ∀ (xs ys : List (CopyVertex ℕ)) (cur : ConfigDynamicState L_p2 R ℓ M₀ d b),
      coupledRepairList hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q cap_u cap_q
        pts o V cfg ω_L ω_R (xs ++ ys) cur =
      let res1 := coupledRepairList hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q cap_u cap_q
        pts o V cfg ω_L ω_R xs cur
      let res2 := coupledRepairList hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q cap_u cap_q
        pts o V cfg ω_L ω_R ys res1.1
      (res2.1, res1.2 ++ res2.2) := by
    intro xs
    induction xs with
    | nil => intro ys cur; simp [coupledRepairList]
    | cons u us ih =>
        intro ys cur
        dsimp only [List.cons_append, coupledRepairList]
        split_ifs with hc
        · exact ih ys cur
        · dsimp only
          rw [ih ys _]
          rfl
  let rP := (cs.st.matchingList.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
    (fun e => CopyVertex.mk .right e.right)
  let lP := (cs.st.matchingList.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
    (fun e => CopyVertex.mk .left e.left)
  have hlenR' : rP.length ≤ 1 := hlenR
  have hlenL' : lP.length ≤ 1 := hlenL
  have hr_props' : ∀ u ∈ rP, u.side = .right ∧ u.id ∈ (params.rightVertices pts o V S cfg.k).erase p := hr_props
  have hl_props' : ∀ u ∈ lP, u.side = .left ∧ u.id ∈ (params.leftVertices pts o V S cfg.j).erase p := hl_props
  have hF_eq' : F = rP ++ lP := hF_eq
  let rep1 := coupledRepairList hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q
    cap_u cap_q pts o V cfg ω_L ω_R rP cs₀
  let rep2 := coupledRepairList hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q
    cap_u cap_q pts o V cfg ω_L ω_R lP rep1.1
  have hrep_eq : rep = (rep2.1, rep1.2 ++ rep2.2) := by
    dsimp [rep]; rw [hF_eq', hsplit_app]
  have hcs'_rep2 : cs' = rep2.1 := by rw [hcs'_eq, hrep_eq]
  -- Step 1 (`rP`, side `.right`)
  have hstep_rP :
      rep1.1.leftIdx.t_ins = cs₀.leftIdx.t_ins ∧
      rep1.1.leftIdx.entryPt = cs₀.leftIdx.entryPt ∧
      rep1.1.rightIdx.t_ins ≤ cs₀.rightIdx.t_ins + 1 ∧
      DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o rep1.1.st.leftIndexSet rep1.1.leftIdx ∧
      DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o rep1.1.st.rightIndexSet rep1.1.rightIdx ∧
      (DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs₀.leftIdx →
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs₀.rightIdx →
       StepSeedGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.rightIdx ω_R →
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o rep1.1.leftIdx ∧
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o rep1.1.rightIdx ∧
       ValidCheckedDeletePromises pts params o V cfg cs₀.st rP rep1.2) := by
    classical
    cases hr_case : rP with
    | nil =>
        dsimp [rep1]; rw [hr_case]; dsimp [coupledRepairList]
        exact ⟨rfl, rfl, Nat.le_succ _, hwfL₀, hwfR₀, fun hgL hgR _ => ⟨hgL, hgR, trivial⟩⟩
    | cons u tl =>
        have htl : tl = [] := by
          rw [hr_case] at hlenR'
          exact List.eq_nil_of_length_eq_zero (by simpa using hlenR')
        subst htl
        rcases hr_props' u (by rw [hr_case]; exact List.mem_singleton_self u) with ⟨huside, huid_VR⟩
        have hu_eq : u = ⟨.right, u.id⟩ := by cases u; cases huside; rfl
        have hu_ne_o : pts u.id ≠ o := by
          have hmem_VR := Finset.mem_of_mem_erase huid_VR
          unfold LocalScaleParams.rightVertices configRightVertices shellSubset at hmem_VR
          exact ne_center_of_shellIndex_pos hk1 (Finset.mem_filter.mp hmem_VR).2
        dsimp only [rep1]
        rw [hr_case]
        dsimp only [coupledRepairList]
        by_cases hcond : cs₀.st.isCopyMatched u ∨ cs₀.st.isCopyInIndex u
        · rw [if_pos hcond]; dsimp only [coupledRepairList]
          refine ⟨rfl, rfl, Nat.le_succ _, hwfL₀, hwfR₀, fun hgL hgR _ => ⟨hgL, hgR, ?_⟩⟩
          unfold ValidCheckedDeletePromises; rw [if_pos hcond]; exact trivial
        · rw [if_neg hcond]
          have hnot_m_i := not_or.mp hcond
          have huid_not_UR : u.id ∉ cs₀.st.rightIndexSet := by
            rw [hu_eq] at hnot_m_i
            exact hmem_not_inIndexR cs₀.st u.id hnot_m_i.2
          rw [hu_eq]
          dsimp only [coupledRepairList]
          set rawR := cs₀.leftIdx.query hM₀ M_lat spec.A spec.B τ_q (bRatCfg params cfg : ℝ) cap_q o (pts u.id)
          set cR := sanitizeConfigAttachAnswer pts params o V cfg cs₀.st ⟨.right, u.id⟩ rawR
          cases hcR : cR with
          | some w =>
              dsimp only [syncIndicesOnAttach]
              have hrem := dyadicSide_remove_spec (M_lat := M_lat) (τ_q := τ_q) (cap_q := cap_q) spec.hAB hh0 hh1 w hwfL₀
              have hwfL₁ : DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o
                  (attachStep pts cs₀.st ⟨.right, u.id⟩ (some w)).leftIndexSet (cs₀.leftIdx.removeHandle w) := by
                rw [leftIndexSet_attachStep]; exact hrem.2.1
              have hwfR₁ : DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o
                  (attachStep pts cs₀.st ⟨.right, u.id⟩ (some w)).rightIndexSet cs₀.rightIdx := by
                rw [rightIndexSet_attachStep]; exact hwfR₀
              refine ⟨hrem.1, by unfold DyadicSideIndex.removeHandle; dsimp only; split_ifs <;> rfl,
                Nat.le_succ _, hwfL₁, hwfR₁, fun hgL hgR _ => ⟨hrem.2.2 hgL, hgR, ?_⟩⟩
              unfold ValidCheckedDeletePromises
              rw [if_neg (by rwa [← hu_eq])]
              dsimp only [List.head?_cons, Option.join, List.drop_succ_cons, List.drop_zero]
              refine ⟨?_, trivial⟩
              unfold SatisfiesConfigSearchPromise
              change SatisfiesAngularSearchPromise pts o
                (params.thresholdA V cfg.j cfg.k cfg.ℓ) (params.thresholdB V cfg.j cfg.k cfg.ℓ)
                cs₀.st.leftIndexSet u.id rawR
              rw [hb_eq]
              exact dyadicSide_query_promise hd hM₀ T p_coord params.e spec.A spec.B τ_d τ_q
                he0 he1 spec.hAB h _ _ hh0 hh1 hba cap_u cap_q hu_ne_o
                (by rw [hremL.1]; omega) hsep_V hwfL₀ hgL
          | none =>
              dsimp only [syncIndicesOnAttach]
              have hins := dyadicSide_insert_spec hM₀ T p_coord M_lat spec.A spec.B τ_d τ_q
                spec.hAB h hh0 hh1 cap_u cap_q huid_not_UR hu_ne_o ω_R hwfR₀
              have hwfL₁ : DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o
                  (attachStep pts cs₀.st ⟨.right, u.id⟩ none).leftIndexSet cs₀.leftIdx := by
                rw [leftIndexSet_attachStep]; exact hwfL₀
              have hwfR₁ : DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o
                  (attachStep pts cs₀.st ⟨.right, u.id⟩ none).rightIndexSet
                  (cs₀.rightIdx.insertHandle hM₀ T p_coord spec.A spec.B τ_d cap_u o (pts u.id) u.id ω_R) := by
                rw [rightIndexSet_attachStep]; exact hins.2.1
              refine ⟨rfl, rfl, le_of_eq hins.1, hwfL₁, hwfR₁, fun hgL hgR hseedR => ?_⟩
              have hseedR₀ := StepSeedGood.of_eq hremR.1 hptR₀ hseedR
              refine ⟨hgL, hins.2.2 hgR hseedR₀, ?_⟩
              unfold ValidCheckedDeletePromises
              rw [if_neg (by rwa [← hu_eq])]
              dsimp only [List.head?_cons, Option.join, List.drop_succ_cons, List.drop_zero]
              refine ⟨?_, trivial⟩
              unfold SatisfiesConfigSearchPromise
              change SatisfiesAngularSearchPromise pts o
                (params.thresholdA V cfg.j cfg.k cfg.ℓ) (params.thresholdB V cfg.j cfg.k cfg.ℓ)
                cs₀.st.leftIndexSet u.id rawR
              rw [hb_eq]
              exact dyadicSide_query_promise hd hM₀ T p_coord params.e spec.A spec.B τ_d τ_q
                he0 he1 spec.hAB h _ _ hh0 hh1 hba cap_u cap_q hu_ne_o
                (by rw [hremL.1]; omega) hsep_V hwfL₀ hgL
  rcases hstep_rP with ⟨htL₁, hptL₁, htR₁, hwfL₁, hwfR₁, hgd_rP⟩
  -- Step 2 (`lP`, side `.left`)
  have hstep_lP :
      rep2.1.leftIdx.t_ins ≤ rep1.1.leftIdx.t_ins + 1 ∧
      rep2.1.rightIdx.t_ins ≤ rep1.1.rightIdx.t_ins ∧
      DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o rep2.1.st.leftIndexSet rep2.1.leftIdx ∧
      DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o rep2.1.st.rightIndexSet rep2.1.rightIdx ∧
      (DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o rep1.1.leftIdx →
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o rep1.1.rightIdx →
       StepSeedGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o cs.leftIdx ω_L →
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o rep2.1.leftIdx ∧
       DyadicSideGood T p_coord M_lat spec.A spec.B τ_d τ_q spec.hAB h hh0 hh1 cap_u cap_q o rep2.1.rightIdx ∧
       ValidCheckedDeletePromises pts params o V cfg rep1.1.st lP rep2.2) := by
    classical
    cases hl_case : lP with
    | nil =>
        dsimp [rep2]; rw [hl_case]; dsimp [coupledRepairList]
        exact ⟨Nat.le_succ _, le_rfl, hwfL₁, hwfR₁, fun hgL₁ hgR₁ _ => ⟨hgL₁, hgR₁, trivial⟩⟩
    | cons u tl =>
        have htl : tl = [] := by
          rw [hl_case] at hlenL'
          exact List.eq_nil_of_length_eq_zero (by simpa using hlenL')
        subst htl
        rcases hl_props' u (by rw [hl_case]; exact List.mem_singleton_self u) with ⟨huside, huid_VL⟩
        have hu_eq : u = ⟨.left, u.id⟩ := by cases u; cases huside; rfl
        have hu_ne_o : pts u.id ≠ o := by
          have hmem_VL := Finset.mem_of_mem_erase huid_VL
          unfold LocalScaleParams.leftVertices configLeftVertices shellSubset at hmem_VL
          exact ne_center_of_shellIndex_pos hj1 (Finset.mem_filter.mp hmem_VL).2
        dsimp only [rep2]
        rw [hl_case]
        dsimp only [coupledRepairList]
        by_cases hcond : rep1.1.st.isCopyMatched u ∨ rep1.1.st.isCopyInIndex u
        · rw [if_pos hcond]; dsimp only [coupledRepairList]
          refine ⟨Nat.le_succ _, le_rfl, hwfL₁, hwfR₁, fun hgL₁ hgR₁ _ => ⟨hgL₁, hgR₁, ?_⟩⟩
          unfold ValidCheckedDeletePromises; rw [if_pos hcond]; exact trivial
        · rw [if_neg hcond]
          have hnot_m_i := not_or.mp hcond
          have huid_not_UL : u.id ∉ rep1.1.st.leftIndexSet := by
            rw [hu_eq] at hnot_m_i
            exact hmem_not_inIndexL rep1.1.st u.id hnot_m_i.2
          rw [hu_eq]
          dsimp only [coupledRepairList]
          set rawL := rep1.1.rightIdx.query hM₀ M_lat spec.A spec.B τ_q (bRatCfg params cfg : ℝ) cap_q o (pts u.id)
          set cL := sanitizeConfigAttachAnswer pts params o V cfg rep1.1.st ⟨.left, u.id⟩ rawL
          cases hcL : cL with
          | some w =>
              dsimp only [syncIndicesOnAttach]
              have hrem := dyadicSide_remove_spec (M_lat := M_lat) (τ_q := τ_q) (cap_q := cap_q) spec.hAB hh0 hh1 w hwfR₁
              have hwfL₂ : DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o
                  (attachStep pts rep1.1.st ⟨.left, u.id⟩ (some w)).leftIndexSet rep1.1.leftIdx := by
                rw [leftIndexSet_attachStep]; exact hwfL₁
              have hwfR₂ : DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o
                  (attachStep pts rep1.1.st ⟨.left, u.id⟩ (some w)).rightIndexSet (rep1.1.rightIdx.removeHandle w) := by
                rw [rightIndexSet_attachStep]; exact hrem.2.1
              refine ⟨Nat.le_succ _, le_of_eq hrem.1, hwfL₂, hwfR₂, fun hgL₁ hgR₁ _ => ⟨hgL₁, hrem.2.2 hgR₁, ?_⟩⟩
              unfold ValidCheckedDeletePromises
              rw [if_neg (by rwa [← hu_eq])]
              dsimp only [List.head?_cons, Option.join, List.drop_succ_cons, List.drop_zero]
              refine ⟨?_, trivial⟩
              unfold SatisfiesConfigSearchPromise
              change SatisfiesAngularSearchPromise pts o
                (params.thresholdA V cfg.j cfg.k cfg.ℓ) (params.thresholdB V cfg.j cfg.k cfg.ℓ)
                rep1.1.st.rightIndexSet u.id rawL
              rw [hb_eq]
              exact dyadicSide_query_promise hd hM₀ T p_coord params.e spec.A spec.B τ_d τ_q
                he0 he1 spec.hAB h _ _ hh0 hh1 hba cap_u cap_q hu_ne_o
                (by rw [hremR.1] at htR₁; omega) hsep_V hwfR₁ hgR₁
          | none =>
              dsimp only [syncIndicesOnAttach]
              have hins := dyadicSide_insert_spec hM₀ T p_coord M_lat spec.A spec.B τ_d τ_q
                spec.hAB h hh0 hh1 cap_u cap_q huid_not_UL hu_ne_o ω_L hwfL₁
              have hwfL₂ : DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o
                  (attachStep pts rep1.1.st ⟨.left, u.id⟩ none).leftIndexSet
                  (rep1.1.leftIdx.insertHandle hM₀ T p_coord spec.A spec.B τ_d cap_u o (pts u.id) u.id ω_L) := by
                rw [leftIndexSet_attachStep]; exact hins.2.1
              have hwfR₂ : DyadicSideWF hM₀ T p_coord spec.A spec.B τ_d cap_u pts o
                  (attachStep pts rep1.1.st ⟨.left, u.id⟩ none).rightIndexSet rep1.1.rightIdx := by
                rw [rightIndexSet_attachStep]; exact hwfR₁
              refine ⟨le_of_eq hins.1, le_rfl, hwfL₂, hwfR₂, fun hgL₁ hgR₁ hseedL => ?_⟩
              have hseedL₁ := StepSeedGood.of_eq (htL₁.trans hremL.1) (hptL₁.trans hptL₀) hseedL
              refine ⟨hins.2.2 hgL₁ hseedL₁, hgR₁, ?_⟩
              unfold ValidCheckedDeletePromises
              rw [if_neg (by rwa [← hu_eq])]
              dsimp only [List.head?_cons, Option.join, List.drop_succ_cons, List.drop_zero]
              refine ⟨?_, trivial⟩
              unfold SatisfiesConfigSearchPromise
              change SatisfiesAngularSearchPromise pts o
                (params.thresholdA V cfg.j cfg.k cfg.ℓ) (params.thresholdB V cfg.j cfg.k cfg.ℓ)
                rep1.1.st.rightIndexSet u.id rawL
              rw [hb_eq]
              exact dyadicSide_query_promise hd hM₀ T p_coord params.e spec.A spec.B τ_d τ_q
                he0 he1 spec.hAB h _ _ hh0 hh1 hba cap_u cap_q hu_ne_o
                (by rw [hremR.1] at htR₁; omega) hsep_V hwfR₁ hgR₁
  rcases hstep_lP with ⟨htL₂, htR₂, hwfL₂, hwfR₂, hgd_lP⟩
  have hprom_append : ∀ (xs ys : List (CopyVertex ℕ)) (cur : ConfigDynamicState L_p2 R ℓ M₀ d b),
      let res1 := coupledRepairList hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q cap_u cap_q
        pts o V cfg ω_L ω_R xs cur
      let res2 := coupledRepairList hM₀ T p_coord M_lat params spec.A spec.B τ_d τ_q cap_u cap_q
        pts o V cfg ω_L ω_R ys res1.1
      ValidCheckedDeletePromises pts params o V cfg cur.st xs res1.2 →
      ValidCheckedDeletePromises pts params o V cfg res1.1.st ys res2.2 →
      ValidCheckedDeletePromises pts params o V cfg cur.st (xs ++ ys) (res1.2 ++ res2.2) := by
    intro xs
    induction xs with
    | nil =>
        intro ys cur
        dsimp only [List.nil_append, coupledRepairList]
        intro _ hp2
        simpa using hp2
    | cons u us ih =>
        intro ys cur
        dsimp only [List.cons_append, coupledRepairList]
        by_cases hc : cur.st.isCopyMatched u ∨ cur.st.isCopyInIndex u
        · rw [if_pos hc]
          intro hp1 hp2
          unfold ValidCheckedDeletePromises at hp1 ⊢
          rw [if_pos hc] at hp1 ⊢
          exact ih ys cur hp1 hp2
        · rw [if_neg hc]
          dsimp only
          intro hp1 hp2
          unfold ValidCheckedDeletePromises at hp1 ⊢
          rw [if_neg hc] at hp1 ⊢
          dsimp only [List.cons_append, List.head?_cons, Option.join, List.drop_succ_cons, List.drop_zero] at hp1 ⊢
          exact ⟨hp1.1, ih ys _ hp1.2 hp2⟩
  have hwf' : ConfigDynamicWF hM₀ T p_coord params spec.A spec.B τ_d cap_u
      pts o V (S.erase p) cfg cs' := by
    refine ⟨hcfg_del.1, hcfg_del.2, ?_, ?_⟩
    · rw [hcs'_rep2]; exact hwfL₂
    · rw [hcs'_rep2]; exact hwfR₂
  have htL_fin : cs'.leftIdx.t_ins ≤ cs.leftIdx.t_ins + 1 := by
    rw [hcs'_rep2]
    dsimp only [cs₀] at htL₁
    calc rep2.1.leftIdx.t_ins ≤ rep1.1.leftIdx.t_ins + 1 := htL₂
      _ = (cs.leftIdx.removeHandle p).t_ins + 1 := by rw [htL₁]
      _ = cs.leftIdx.t_ins + 1 := by rw [hremL.1]
  have htR_fin : cs'.rightIdx.t_ins ≤ cs.rightIdx.t_ins + 1 := by
    rw [hcs'_rep2]
    dsimp only [cs₀] at htR₁
    calc rep2.1.rightIdx.t_ins ≤ rep1.1.rightIdx.t_ins := htR₂
      _ ≤ (cs.rightIdx.removeHandle p).t_ins + 1 := htR₁
      _ = cs.rightIdx.t_ins + 1 := by rw [hremR.1]
  refine ⟨htL_fin, htR_fin, hwf', fun hgd hseedL hseedR => ?_⟩
  have hgL₀ := hremL.2.2 hgd.2.1
  have hgR₀ := hremR.2.2 hgd.2.2
  rcases hgd_rP hgL₀ hgR₀ hseedR with ⟨hgL₁, hgR₁, hprom1⟩
  rcases hgd_lP hgL₁ hgR₁ hseedL with ⟨hgL₂, hgR₂, hprom2⟩
  have hprom_full : ValidCheckedDeletePromises pts params o V cfg cs₀.st F rep.2 := by
    have hp_app := hprom_append rP lP cs₀ hprom1 hprom2
    have hrep2_eq : rep.2 = rep1.2 ++ rep2.2 := by rw [hrep_eq]
    rw [hF_eq', hrep2_eq]
    exact hp_app
  rcases h_clm_7_3.1.2 with ⟨C_rep, _, hrep⟩
  have hinv' := (((hrep d ℕ pts params o V S cfg cs.st hV hcfg_V hgd.1).2 p rep.2 hp).2.2 hprom_full).1
  rw [← hst'_eq] at hinv'
  refine ⟨hinv', ?_, ?_⟩
  · change DyadicSideGood _ _ _ _ _ _ _ _ _ _ _ _ _ _ cs'.leftIdx; rw [hcs'_rep2]; exact hgL₂
  · change DyadicSideGood _ _ _ _ _ _ _ _ _ _ _ _ _ _ cs'.rightIdx; rw [hcs'_rep2]; exact hgR₂

end UL.Proof.clm_9_1_explicit_tradeoff.H4b
