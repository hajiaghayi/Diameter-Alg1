import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideA
import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideB
import UL.Proof.clm_9_1_explicit_tradeoff.CG02_SideQuery
import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchA0
import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideRAM0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead rWrite InFootprint
  wRead_wWrite_self wRead_wWrite_of_ne wRead_rWrite rRead_wWrite rRead_rWrite_self rRead_rWrite_of_ne)
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps realExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot slotWStride slotRStride slotWStride_ge_four
  seedCoordCount seedBitCount slotInsWStride slotInsRStride slotQryWStride slotQryRStride
  evalWStride evalCopyTuplesCost liveSlotQueryStepCost liveSlotQueryCopyCost liveSlotQueryCost)

/-! ### 3. `mkSideRAMOps`: Full Concrete Instantiation of `CG17.SideRAMOps` -/

noncomputable def mkSideRAMOps
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ)
    (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    CG17.SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl where
  sideWStride := dyadicSideWStride n L_p2 R ℓ M₀ cap_u
  sideRStride := dyadicSideRStride L_p2 R ℓ M₀ d
  hsideW_ge_two := dyadicSideWStride_ge_two n L_p2 R ℓ M₀ cap_u
  hsideR_nonneg := le_trans (Nat.cast_nonneg d) (dyadicSideRStride_ge_d L_p2 R ℓ M₀ d)
  sideWScrStride := sideRAMWScrStride ℓ M₀ cap_u cap_q
  sideRScrStride := sideRAMRScrStride d
  hsideWScr_pos := sideRAMWScrStride_pos ℓ M₀ cap_u cap_q
  hsideRScr_pos := sideRAMRScrStride_pos d
  zeroInitCost := dyadicSideZeroInitCost L_p2
  clearCost := dyadicSideClearCost L_p2
  removeCost := dyadicSideRemoveCost L_p2 R cap_u
  insertCost := dyadicSideInsertUidCost L_p2 R ℓ M₀ d b T_cdf p_coord cap_u
  queryCost := dyadicSideQueryUidCost L_p2 R ℓ M₀ d M_lat cap_q

  EncSide := fun sideBaseW sideBaseR U idx m =>
    EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m

  encSide_ep_pos := fun h => h.ep_pos

  encSide_mono_slice := fun hU henc hkW hkR =>
    EncH4DyadicSide.mono_slice_uLt hU henc hkW hkR

  zeroInitStmt := fun wSideBaseW _wSideBaseR wScr _rScr =>
    dyadicSideZeroInitStmt scrW tblW wSideBaseW wScr n L_p2 R ℓ M₀ cap_u

  clearStmt := fun wSideBaseW _wSideBaseR wScr _rScr =>
    dyadicSideClearStmt scrW tblW wSideBaseW wScr n L_p2 R ℓ M₀ cap_u

  removeStmt := fun wSideBaseW _wSideBaseR wUid wScr _rScr =>
    dyadicSideRemoveStmt scrW tblW wSideBaseW wUid wScr n L_p2 R ℓ M₀ cap_u

  insertStmt := fun A B_rat wSideBaseW wSideBaseR wOffO wUid wSeedBase wScr rScr =>
    dyadicSideInsertUidStmt scrW scrR tblW tblR coinTbl
      wSideBaseW wSideBaseR wOffO wUid wSeedBase wScr rScr
      n L_p2 R ℓ M₀ d b T_cdf p_coord cap_u A B_rat τ_d

  queryStmt := fun A B_rat b_rat wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr =>
    dyadicSideQueryUidStmt scrW scrR tblW tblR
      wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr
      n L_p2 R ℓ M₀ d M_lat cap_u cap_q A B_rat τ_q b_rat

  zeroRand_zeroInitStmt := fun wBW _ wScr _ =>
    zeroRand_dyadicSideZeroInitStmt scrW tblW wBW wScr n L_p2 R ℓ M₀ cap_u

  zeroRand_clearStmt := fun wBW _ wScr _ =>
    zeroRand_dyadicSideClearStmt scrW tblW wBW wScr n L_p2 R ℓ M₀ cap_u

  zeroRand_removeStmt := fun wBW _ wUid wScr _ =>
    zeroRand_dyadicSideRemoveStmt scrW tblW wBW wUid wScr n L_p2 R ℓ M₀ cap_u

  zeroRand_insertStmt := fun A B_rat wBW wBR wOffO wUid wSeed wScr rScr =>
    zeroRand_dyadicSideInsertUidStmt scrW scrR tblW tblR coinTbl
      wBW wBR wOffO wUid wSeed wScr rScr n L_p2 R ℓ M₀ d b T_cdf p_coord cap_u A B_rat τ_d

  zeroRand_queryStmt := fun A B_rat b_rat wBW wBR wOffO wQry wAns wScr rScr =>
    zeroRand_dyadicSideQueryUidStmt scrW scrR tblW tblR
      wBW wBR wOffO wQry wAns wScr rScr n L_p2 R ℓ M₀ d M_lat cap_u cap_q A B_rat τ_q b_rat

  exec_zeroInitStmt := by
    intro TW BW TR BR inp m₀ wSideBaseW wSideBaseR wScr rScr sideBaseW sideBaseR
      hfp hvnt hsideW _hsideR hwBW _hwBR _hneB hwScr _hrScr hbW _hbR hzeroW
    have hw48 := sideRAMWScrStride_ge_48 ℓ M₀ cap_u cap_q
    rcases hvnt with ⟨hscrW, htblW, _, _, _, _, hneW, _, _, hneR, _, _⟩
    obtain ⟨m₁, hd, hfp₁, henc₁, hkW₁, _, hfr₁⟩ :=
      exec_h4_dyadicSideZeroInitStmt_anyR (TW := TW) (BW := BW) (TR := TR) (BR := BR)
        (scrR := scrR) (tblR := tblR) inp wSideBaseW wScr sideBaseW sideBaseR
        n L_p2 R ℓ M₀ b T_cdf p_coord cap_u
        hfp hscrW htblW hneW hneR hsideW
        ⟨hwScr.1, by omega⟩ (Or.inl hwBW.2) hbW hzeroW
    exact ⟨m₁, hd, hfp₁, henc₁,
      fun w hw => hkW₁ w (Or.inl hw),
      hfr₁.mono_range (Or.inr ⟨le_rfl, le_rfl⟩) (Or.inl rfl)⟩

  exec_clearStmt := by
    intro TW BW TR BR inp m₀ wSideBaseW wSideBaseR wScr rScr sideBaseW sideBaseR U idx
      hfp hvnt hsideW _hsideR hwBW _hwBR _hneB hwScr _hrScr hbW _hbR henc₀
    have hw48 := sideRAMWScrStride_ge_48 ℓ M₀ cap_u cap_q
    rcases hvnt with ⟨hscrW, htblW, _, _, _, _, hneW, _, _, hneR, _, _⟩
    obtain ⟨m₁, hd, hfp₁, henc₁, hkW₁, _, hfr₁⟩ :=
      exec_h4_dyadicSideClearStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
        (scrR := scrR) inp wSideBaseW wScr sideBaseW sideBaseR T_cdf p_coord
        hfp hscrW htblW hneW hneR hsideW
        ⟨hwScr.1, by omega⟩ (Or.inl hwBW.2) hbW henc₀
    exact ⟨m₁, hd, hfp₁, henc₁,
      fun w hw => hkW₁ w (Or.inl hw),
      hfr₁.mono_range (Or.inr ⟨le_rfl, le_rfl⟩) (Or.inl rfl)⟩

  exec_removeStmt := by
    intro TW BW TR BR inp m₀ hM₀ hn _hLp2 A B_rat _hAB
      wSideBaseW wSideBaseR wUid wScr rScr sideBaseW sideBaseR
      pts o U h₀ _hh0_lt _hU_lt idx hwf
      hfp hvnt hsideW _hsideR hwBW _hwBR hwU _hneqs hwScr _hrScr hbW _hbR hh0 henc₀
    have hw48 := sideRAMWScrStride_ge_48 ℓ M₀ cap_u cap_q
    have hrem16 : dyadicSideRemoveWStride = 16 := rfl
    rcases hvnt with ⟨hscrW, htblW, _, _, _, _, hneW, _, _, hneR, _, _⟩
    obtain ⟨m₁, hd, hfp₁, henc₁, hkW₁, _, hfr₁⟩ :=
      exec_h4_dyadicSideRemoveStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
        (scrR := scrR) inp wSideBaseW wUid wScr sideBaseW sideBaseR
        (by omega : 1 ≤ n) hM₀ hwf hfp hscrW htblW hneW hneR hsideW
        ⟨hwScr.1, by rw [hrem16]; omega⟩
        (Or.inl hwBW.2) (Or.inl hwU.2) hbW hh0 henc₀
    exact ⟨m₁, hd, hfp₁, henc₁,
      fun w hw => hkW₁ w (Or.inl hw),
      hfr₁.mono_range (Or.inr ⟨le_rfl, le_rfl⟩) (Or.inl rfl)⟩

  exec_insertStmt := by
    intro TW BW TR BR inp m₀ hM₀ hn _hLp2 A B_rat _hAB
      wSideBaseW wSideBaseR wOffO wUid wSeedBase wScr rScr
      sideBaseW sideBaseR offO seedBase
      pts o U h₀ hh0_not hh0_lt hU_lt _hne_o ω_side idx ht_lt _hwf
      hfp hvnt hsideW hsideR hoffO_b _hseed_b _hn_b
      hwBW hwBR hwO hwU hwSeed _hneqs hwScr hrScr
      hbW hbR hoffO huid hseedOff ho hpts_all hseed_sl henc₀
    have hw_ins := sideRAMWScrStride_ge_ins ℓ M₀ cap_u cap_q
    have hr_ins := sideRAMRScrStride_ge_ins d
    rcases hvnt with ⟨hscrW, htblW, _, hscrR, htblR, _, hneW, hneCoinScr, hneCoinW, hneR, _, hne1R⟩
    have hseed₀ : EncSideStepSeed coinTbl seedBase ω_side m₀ :=
      encSideStepSeed_of_slices coinTbl seedBase ω_side m₀ (fun s r a k j bi => hseed_sl s r a k j bi)
    exact exec_h4_dyadicSideInsertUidStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
      inp wSideBaseW wSideBaseR wOffO wUid wSeedBase wScr rScr
      sideBaseW sideBaseR offO seedBase
      (by omega : 1 ≤ n) hM₀ A B_rat τ_d hh0_not hh0_lt hU_lt ω_side (by omega : idx.t_ins < 2 ^ L_p2)
      hfp hscrW hscrR htblW htblR hneW hneR hneCoinScr hneCoinW hne1R
      hsideW hsideR (by omega)
      hwBW.2 hwBR.2 hwO.2 hwU.2 hwSeed.2
      ⟨hwScr.1, by omega⟩ ⟨hrScr.1, by omega⟩
      hbW hbR hoffO huid hseedOff ho
      (hpts_all h₀ (Finset.mem_insert_self h₀ U))
      hseed₀ henc₀

  exec_queryStmt := by
    intro TW BW TR BR inp m₀ hM₀ _hn _hLp2 A B_rat b_rat _hAB
      wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr
      sideBaseW sideBaseR offO
      pts o U qUid _hq_lt _hU_lt hq_ne_o idx _ht_lt hwf
      hfp hvnt _hsideW hsideR hoffO_b _hn_b
      hwBW hwBR hwO hwQ hwAns hneqs hwScr hrScr
      hbW hbR hoffO hqUid ho hpts_all henc₀
    have hw_qry := sideRAMWScrStride_ge_qry ℓ M₀ cap_u cap_q
    have hr_qry := sideRAMRScrStride_ge_qry d
    rcases hvnt with ⟨hscrW, _, _, hscrR, htblR, _, hneW, _, _, hneR, _, hne1R⟩
    rcases hneqs with ⟨_, _, _, hBW_Ans, _, _, hBR_Ans, _, hO_Ans, _⟩
    obtain ⟨m₁, hd, hfp₁, henc₁, _, hmatch, hkW₁, hfr₁⟩ :=
      exec_h4_dyadicSideQueryUidStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR) (M_lat := M_lat) (cap_q := cap_q)
        inp wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr
        sideBaseW sideBaseR offO
        hM₀ τ_q b_rat hq_ne_o hwf hfp hscrW hscrR htblR hneW hneR hne1R
        hsideR hoffO_b hwBW hwBR hwO hwQ hwAns
        ⟨hBW_Ans.symm, hBR_Ans.symm, hO_Ans.symm⟩
        ⟨hwScr.1, by omega⟩ ⟨hrScr.1, by omega⟩
        hbW hbR hoffO hqUid ho
        (hpts_all qUid (Finset.mem_insert_self qUid U))
        henc₀
    exact ⟨m₁, hd, hfp₁, henc₁, hmatch,
      fun w hw hne => hkW₁ w hne (Or.inl hw),
      hfr₁⟩

/-! ### 4. Concrete Stride, Scratch, and Cost Bound Lemmas for `mkSideRAMOps` -/

private lemma le_of_add_eq {a b c : ℕ} (h : a + c = b) : a ≤ b := by
  rw [← h]; exact Nat.le_add_right a c

@[simp] lemma mkSideRAMOps_sideWStride
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).sideWStride = dyadicSideWStride n L_p2 R ℓ M₀ cap_u := rfl

@[simp] lemma mkSideRAMOps_sideRStride
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).sideRStride = dyadicSideRStride L_p2 R ℓ M₀ d := rfl

@[simp] lemma mkSideRAMOps_sideWScrStride
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).sideWScrStride = sideRAMWScrStride ℓ M₀ cap_u cap_q := rfl

@[simp] lemma mkSideRAMOps_sideRScrStride
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).sideRScrStride = sideRAMRScrStride d := rfl

@[simp] lemma mkSideRAMOps_EncSide
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).EncSide =
      fun sideBaseW sideBaseR U idx m =>
        EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m := rfl

theorem mkSideRAMOps_sideWStride_le
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).sideWStride ≤
      (((2 + 2 * 2 ^ L_p2 + n + 2 * L_p2 * (4 + 2 * R * M₀ ^ ℓ + 5 * 2 ^ L_p2 * R * cap_u)) : ℕ) : ℤ) :=
  dyadicSideWStride_le n L_p2 R ℓ M₀ cap_u

theorem mkSideRAMOps_sideRStride_le
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).sideRStride ≤
      (((d + 2 ^ L_p2 * d + 2 * L_p2 * (R * ℓ * M₀ * (d + 1))) : ℕ) : ℤ) :=
  dyadicSideRStride_le L_p2 R ℓ M₀ d

theorem mkSideRAMOps_sideWScrStride_le
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).sideWScrStride ≤
      (((48 + ℓ + ℓ * M₀ + cap_u + cap_q) : ℕ) : ℤ) := by
  change max (dyadicSideInsertUidWStride ℓ M₀ cap_u) (dyadicSideQueryUidWStride ℓ M₀ cap_q) ≤ _
  apply max_le
  · unfold dyadicSideInsertUidWStride dyadicSideInsertWStride slotInsWStride evalWStride
    push_cast; omega
  · unfold dyadicSideQueryUidWStride slotQryWStride evalWStride
    push_cast; omega

theorem mkSideRAMOps_sideRScrStride_le
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).sideRScrStride ≤
      (((13 + 3 * d) : ℕ) : ℤ) := by
  change max (dyadicSideInsertRStride d) (dyadicSideQueryRStride d) ≤ _
  apply max_le
  · unfold dyadicSideInsertRStride slotInsRStride
    push_cast; omega
  · unfold dyadicSideQueryRStride slotQryRStride
    push_cast; omega

theorem mkSideRAMOps_zeroInitCost_le
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).zeroInitCost ≤ 340 * (L_p2 + 1) :=
  dyadicSideZeroInitCost_le L_p2

theorem mkSideRAMOps_clearCost_le
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).clearCost ≤ 380 * (L_p2 + 1) :=
  dyadicSideClearCost_le L_p2

theorem mkSideRAMOps_removeCost_le
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).removeCost ≤
      (1 + cap_u + cap_q + R * ℓ * M₀) * (800 * (L_p2 + 1) * (R + 1)) :=
  dyadicSideRemoveCost_le L_p2 R ℓ M₀ cap_u cap_q

theorem mkSideRAMOps_insertCost_le
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).insertCost ≤
      (1 + cap_u + cap_q + R * ℓ * M₀) *
        ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) *
          (2250 + 60 * b + (T_cdf + p_coord + 6) * (120 + 48 * cdfDegree T_cdf b))) :=
  dyadicSideInsertUidCost_le L_p2 R ℓ M₀ d b T_cdf p_coord cap_u cap_q

theorem mkSideRAMOps_queryCost_le
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).queryCost ≤
      12100 * (L_p2 + 1) * (R + 1) * (ℓ + 1) * (M₀ + 1) * (cap_q + 1) * (d + 1) * (M_lat + 1) :=
  dyadicSideQueryUidCost_le L_p2 R ℓ M₀ d M_lat cap_q

/-- Tight sublinear bound on `queryCost` with NO `M₀ * cap_q` cross-term: linear in
`(1 + cap_u + cap_q + R * ℓ * M₀)` times `poly(L_p2, R, ℓ, d, M_lat)`. -/
theorem mkSideRAMOps_queryCost_sublinear_le
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).queryCost ≤
      (1 + cap_u + cap_q + R * ℓ * M₀) *
        ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) * (M_lat + 1) * 6500) := by
  change dyadicSideQueryUidCost L_p2 R ℓ M₀ d M_lat cap_q ≤ _
  let S := dyadicSideQuerySlat M_lat
  let P := (R + 1) * (ℓ + 1) * (d + 1) * (S + 1)
  let C := 1 + cap_u + cap_q + R * ℓ * M₀
  have hP_ge_d : d + 1 ≤ P :=
    le_of_add_eq (c := ((R + 1) * (ℓ + 1) * (S + 1) - 1) * (d + 1)) (by
      have hpos : 1 ≤ (R + 1) * (ℓ + 1) * (S + 1) :=
        Nat.mul_pos (Nat.mul_pos (Nat.succ_pos _) (Nat.succ_pos _)) (Nat.succ_pos _)
      calc (d + 1) + ((R + 1) * (ℓ + 1) * (S + 1) - 1) * (d + 1)
          = (1 + ((R + 1) * (ℓ + 1) * (S + 1) - 1)) * (d + 1) := by ring
        _ = ((R + 1) * (ℓ + 1) * (S + 1)) * (d + 1) := by rw [Nat.add_sub_of_le hpos]
        _ = P := by dsimp only [P]; ring)
  have hP_pos : 1 ≤ P := le_trans (Nat.succ_pos d) hP_ge_d
  have hC_pos : 1 ≤ C := by dsimp only [C]; omega
  have hslot : liveSlotQueryCost R ℓ M₀ d S cap_q ≤ C * (P * 1300) := by
    unfold liveSlotQueryCost liveSlotQueryCopyCost liveSlotQueryStepCost evalCopyTuplesCost
    let X := R * ℓ * M₀
    have hbase : 250 + 70 * d + d * (60 + 165 * S) +
        R * (150 + (200 + ℓ * (250 + M₀ * (350 + 80 * d)) + cap_q * (110 + 130 * ℓ)) +
          (2 * cap_q + 2) * (450 + 130 * d) + 30) =
        (250 + 130 * d + 165 * d * S + 1280 * R + 260 * R * d + 250 * R * ℓ) +
          cap_q * (1010 * R + 130 * R * ℓ + 260 * R * d) + X * (350 + 80 * d) := by
      dsimp only [X]; ring
    rw [hbase]
    have ht1 : 250 + 130 * d + 165 * d * S + 1280 * R + 260 * R * d + 250 * R * ℓ ≤ 1 * (P * 1300) :=
      le_of_add_eq (c := 1050 + 1170 * d + 1300 * S + 1135 * d * S + 20 * R + 1040 * R * d +
          1050 * R * ℓ + 1300 * ℓ + 1300 * ℓ * d + 1300 * R * ℓ * d +
          1300 * (R * S + ℓ * S + R * ℓ * S + R * d * S + ℓ * d * S + R * ℓ * d * S))
        (by dsimp only [P]; ring)
    have ht2 : cap_q * (1010 * R + 130 * R * ℓ + 260 * R * d) ≤ cap_q * (P * 1300) :=
      Nat.mul_le_mul_left cap_q
        (le_of_add_eq (c := 1300 * (ℓ + 1) * (d + 1) + 290 * R + 1170 * R * ℓ + 1040 * R * d +
            1300 * R * ℓ * d + 1300 * (R + 1) * (ℓ + 1) * (d + 1) * S)
          (by dsimp only [P]; ring))
    have ht3 : X * (350 + 80 * d) ≤ X * (P * 1300) :=
      Nat.mul_le_mul_left X
        (le_of_add_eq (c := 950 + 1220 * d + 1300 * (R * ℓ + R + ℓ) * (d + 1) +
            1300 * (R + 1) * (ℓ + 1) * (d + 1) * S)
          (by dsimp only [P]; ring))
    calc (250 + 130 * d + 165 * d * S + 1280 * R + 260 * R * d + 250 * R * ℓ) +
          cap_q * (1010 * R + 130 * R * ℓ + 260 * R * d) + X * (350 + 80 * d)
        ≤ (1 * (P * 1300) + cap_u * (P * 1300) + cap_q * (P * 1300)) + X * (P * 1300) :=
          Nat.add_le_add
            (Nat.add_le_add (le_trans ht1 (Nat.le_add_right _ _)) ht2)
            ht3
      _ = C * (P * 1300) := by dsimp only [C, X]; ring
  have hstep : dyadicSideScaleQueryStepCost R ℓ M₀ d S cap_q + 50 ≤ C * (P * 3200) := by
    unfold dyadicSideScaleQueryStepCost dyadicSideSlotSubQueryCost
    have h570 : 570 ≤ C * (P * 600) := by
      have hp : 600 ≤ P * 600 := Nat.le_mul_of_pos_left 600 hP_pos
      have hc : P * 600 ≤ C * (P * 600) := Nat.le_mul_of_pos_left _ hC_pos
      omega
    calc 200 + 2 * (160 + liveSlotQueryCost R ℓ M₀ d S cap_q) + 50
        = 570 + 2 * liveSlotQueryCost R ℓ M₀ d S cap_q := by ring
      _ ≤ C * (P * 600) + 2 * (C * (P * 1300)) :=
          Nat.add_le_add h570 (Nat.mul_le_mul_left 2 hslot)
      _ = C * (P * 3200) := by ring
  have hqry : dyadicSideQueryCost L_p2 R ℓ M₀ d S cap_q ≤ C * ((L_p2 + 1) * P * 3200) := by
    unfold dyadicSideQueryCost dyadicSideTailCheckCost
    have htail : 200 + 35 * d + 2 * (380 + 130 * d) ≤ C * (P * 3200) := by
      have h1 : 200 + 35 * d + 2 * (380 + 130 * d) ≤ (d + 1) * 3200 := by omega
      have h2 : (d + 1) * 3200 ≤ P * 3200 := Nat.mul_le_mul_right 3200 hP_ge_d
      have h3 : P * 3200 ≤ C * (P * 3200) := Nat.le_mul_of_pos_left _ hC_pos
      exact le_trans h1 (le_trans h2 h3)
    calc 200 + 35 * d + 2 * (380 + 130 * d) +
          L_p2 * (dyadicSideScaleQueryStepCost R ℓ M₀ d S cap_q + 50)
        ≤ C * (P * 3200) + L_p2 * (C * (P * 3200)) :=
          Nat.add_le_add htail (Nat.mul_le_mul_left L_p2 hstep)
      _ = C * ((L_p2 + 1) * P * 3200) := by ring
  unfold dyadicSideQueryUidCost
  have hsl : S + 1 ≤ 2 * (M_lat + 1) := by
    have := dyadicSideQuerySlat_le M_lat; dsimp only [S]; omega
  let Base := (L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) * (M_lat + 1)
  have hBase_pos : 1 ≤ Base :=
    Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (Nat.succ_pos _) (Nat.succ_pos _))
      (Nat.succ_pos _)) (Nat.succ_pos _)) (Nat.succ_pos _)
  have h30 : 30 ≤ C * (Base * 100) := by
    have hb : 100 ≤ Base * 100 := Nat.le_mul_of_pos_left 100 hBase_pos
    have hc : Base * 100 ≤ C * (Base * 100) := Nat.le_mul_of_pos_left _ hC_pos
    omega
  have hP_le : (L_p2 + 1) * P * 3200 ≤ Base * 6400 := by
    calc (L_p2 + 1) * P * 3200
        = ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) * 3200) * (S + 1) := by dsimp only [P]; ring
      _ ≤ ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) * 3200) * (2 * (M_lat + 1)) :=
          Nat.mul_le_mul_left _ hsl
      _ = Base * 6400 := by dsimp only [Base]; ring
  calc 30 + dyadicSideQueryCost L_p2 R ℓ M₀ d S cap_q
      ≤ C * (Base * 100) + C * (Base * 6400) :=
        Nat.add_le_add h30 (le_trans hqry (Nat.mul_le_mul_left C hP_le))
    _ = (1 + cap_u + cap_q + R * ℓ * M₀) *
          ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) * (M_lat + 1) * 6500) := by
        dsimp only [C, Base]; ring

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
