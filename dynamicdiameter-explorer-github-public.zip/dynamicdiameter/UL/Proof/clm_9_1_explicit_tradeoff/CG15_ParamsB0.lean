import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG15_ParamsA
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG15

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_clm_6_1_precision_RaceV30
open UL.Proof.clm_9_1_explicit_tradeoff.H1
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 1. `NonnegPoly2` & `NatPoly2` Monotonicity and Composition Combinators -/

theorem nonnegPoly2_mono {f g : ℕ → ℕ → ℝ}
    (hf0 : ∀ d L, 0 ≤ f d L) (hfg : ∀ d L, f d L ≤ g d L) (hg : NonnegPoly2 g) :
    NonnegPoly2 f := by
  rcases hg with ⟨_, C, deg, hC, hbd⟩
  exact ⟨hf0, C, deg, hC, fun d L => (hfg d L).trans (hbd d L)⟩

theorem nonnegPoly2_comp_L {f : ℕ → ℕ → ℝ} {g : ℕ → ℕ → ℕ}
    (hf : NonnegPoly2 f) (hg : NonnegPoly2 (fun d L => (g d L : ℝ))) :
    NonnegPoly2 (fun d L => f d (g d L)) := by
  rcases hf with ⟨hf0, C, deg, hC, hbd⟩
  have hB : NonnegPoly2 (fun d L => C * ((d : ℝ) + 1) ^ deg * ((g d L : ℝ) + 1) ^ deg) :=
    nonnegPoly2_mul
      (nonnegPoly2_mul (nonnegPoly2_const hC)
        (nonnegPoly2_pow (nonnegPoly2_add nonnegPoly2_d (nonnegPoly2_const zero_le_one)) deg))
      (nonnegPoly2_pow (nonnegPoly2_add hg (nonnegPoly2_const zero_le_one)) deg)
  exact nonnegPoly2_mono (fun d L => hf0 d (g d L)) (fun d L => hbd d (g d L)) hB

def NatPoly2 (f : ℕ → ℕ → ℕ) : Prop :=
  NonnegPoly2 (fun d L => (f d L : ℝ))

theorem natPoly2_const (c : ℕ) : NatPoly2 (fun _ _ => c) :=
  nonnegPoly2_const (Nat.cast_nonneg c)

theorem natPoly2_d : NatPoly2 (fun d _ => d) :=
  nonnegPoly2_d

theorem natPoly2_L : NatPoly2 (fun _ L => L) :=
  nonnegPoly2_L

theorem natPoly2_add {f g : ℕ → ℕ → ℕ} (hf : NatPoly2 f) (hg : NatPoly2 g) :
    NatPoly2 (fun d L => f d L + g d L) :=
  nonnegPoly2_congr (fun d L => by push_cast; rfl) (nonnegPoly2_add hf hg)

theorem natPoly2_mul {f g : ℕ → ℕ → ℕ} (hf : NatPoly2 f) (hg : NatPoly2 g) :
    NatPoly2 (fun d L => f d L * g d L) :=
  nonnegPoly2_congr (fun d L => by push_cast; rfl) (nonnegPoly2_mul hf hg)

theorem natPoly2_pow {f : ℕ → ℕ → ℕ} (hf : NatPoly2 f) (k : ℕ) :
    NatPoly2 (fun d L => (f d L) ^ k) :=
  nonnegPoly2_congr (fun d L => by push_cast; rfl) (nonnegPoly2_pow hf k)

theorem R_fn_mono_L (C_net_nat d : ℕ) {L₁ L₂ : ℕ} (hL : L₁ ≤ L₂) :
    R_fn C_net_nat d L₁ ≤ R_fn C_net_nat d L₂ := by
  unfold R_fn
  have h1 : C_net_nat * d * (d + L₁) ≤ C_net_nat * d * (d + L₂) :=
    Nat.mul_le_mul_left (C_net_nat * d) (by omega)
  omega

theorem E_M_fn_mono_L (C_M_nat : ℕ) {L₁ L₂ : ℕ} (hL : L₁ ≤ L₂) :
    E_M_fn C_M_nat L₁ ≤ E_M_fn C_M_nat L₂ := by
  unfold E_M_fn
  have h1 : (L₁ + 2) ^ 2 ≤ (L₂ + 2) ^ 2 := Nat.pow_le_pow_left (by omega) 2
  omega

theorem T_fn_mono_L (ℓ C_net_nat C_M_nat d : ℕ) {L₁ L₂ : ℕ} (hL : L₁ ≤ L₂) :
    T_fn ℓ C_net_nat C_M_nat d L₁ ≤ T_fn ℓ C_net_nat C_M_nat d L₂ := by
  unfold T_fn K_tail_fn
  have hR := R_fn_mono_L C_net_nat d hL
  have hE := E_M_fn_mono_L C_M_nat hL
  omega

theorem p_coord_fn_mono_L (ℓ C_net_nat C_M_nat d : ℕ) {L₁ L₂ : ℕ} (hL : L₁ ≤ L₂) :
    p_coord_fn ℓ C_net_nat C_M_nat d L₁ ≤ p_coord_fn ℓ C_net_nat C_M_nat d L₂ := by
  unfold p_coord_fn p_bits_fn
  have hR := R_fn_mono_L C_net_nat d hL
  have hE := E_M_fn_mono_L C_M_nat hL
  have hm : 2 * C_net_nat * d * (d + L₁) ≤ 2 * C_net_nat * d * (d + L₂) :=
    Nat.mul_le_mul_left (2 * C_net_nat * d) (by omega)
  omega

theorem b_fn_mono_L (ℓ C_net_nat C_M_nat d : ℕ) {L₁ L₂ : ℕ} (hL : L₁ ≤ L₂) :
    b_fn ℓ C_net_nat C_M_nat d L₁ ≤ b_fn ℓ C_net_nat C_M_nat d L₂ := by
  unfold b_fn m_exp_fn
  have hT := T_fn_mono_L ℓ C_net_nat C_M_nat d hL
  have hsq : (T_fn ℓ C_net_nat C_M_nat d L₁ + 1) ^ 2 ≤ (T_fn ℓ C_net_nat C_M_nat d L₂ + 1) ^ 2 :=
    Nat.pow_le_pow_left (by omega) 2
  have hp := p_coord_fn_mono_L ℓ C_net_nat C_M_nat d hL
  omega

theorem B_prec_fn_mono_L (ℓ C_net_nat C_M_nat d : ℕ) {L₁ L₂ : ℕ} (hL : L₁ ≤ L₂) :
    B_prec_fn ℓ C_net_nat C_M_nat d L₁ ≤ B_prec_fn ℓ C_net_nat C_M_nat d L₂ := by
  unfold B_prec_fn
  have hb := b_fn_mono_L ℓ C_net_nat C_M_nat d hL
  have hT := T_fn_mono_L ℓ C_net_nat C_M_nat d hL
  omega

theorem poly_cap_fn_mono_L (ℓ C_net_nat C_M_nat d : ℕ) {L₁ L₂ : ℕ} (hL : L₁ ≤ L₂) :
    poly_cap_fn ℓ C_net_nat C_M_nat d L₁ ≤ poly_cap_fn ℓ C_net_nat C_M_nat d L₂ := by
  have hL_r : (L₁ : ℝ) ≤ (L₂ : ℝ) := by exact_mod_cast hL
  have hR_r : (R_fn C_net_nat d L₁ : ℝ) ≤ (R_fn C_net_nat d L₂ : ℝ) := by
    exact_mod_cast R_fn_mono_L C_net_nat d hL
  have hsq : ((L₁ : ℝ) + 2) ^ 2 ≤ ((L₂ : ℝ) + 2) ^ 2 :=
    pow_le_pow_left₀ (by positivity) (by linarith only [hL_r]) 2
  have hS_nn : 0 ≤ S_exp_val ℓ := by unfold S_exp_val; positivity
  have hKI : K_I_fn ℓ C_net_nat C_M_nat d L₁ ≤ K_I_fn ℓ C_net_nat C_M_nat d L₂ := by
    unfold K_I_fn
    push_cast
    refine mul_le_mul (mul_le_mul_of_nonneg_right hR_r (Nat.cast_nonneg ℓ)) ?_ (by positivity) (by positivity)
    have hm1 : (C_M_nat : ℝ) * ((L₁ : ℝ) + 2) ^ 2 ≤ (C_M_nat : ℝ) * ((L₂ : ℝ) + 2) ^ 2 :=
      mul_le_mul_of_nonneg_left hsq (Nat.cast_nonneg C_M_nat)
    have hm2 := mul_le_mul_of_nonneg_right hm1 (sq_nonneg (S_exp_val ℓ))
    linarith only [hm2]
  have hPM : P_M_fn ℓ C_M_nat L₁ ≤ P_M_fn ℓ C_M_nat L₂ := by
    unfold P_M_fn
    refine pow_le_pow_left₀ (by positivity) ?_ ℓ
    have hm1 : (C_M_nat : ℝ) * ((L₁ : ℝ) + 2) ^ 2 ≤ (C_M_nat : ℝ) * ((L₂ : ℝ) + 2) ^ 2 :=
      mul_le_mul_of_nonneg_left hsq (Nat.cast_nonneg C_M_nat)
    linarith only [hm1]
  have hKu : K_u_fn ℓ C_M_nat L₁ ≤ K_u_fn ℓ C_M_nat L₂ := by
    unfold K_u_fn
    have hm := mul_le_mul_of_nonneg_right hPM hS_nn
    linarith only [hm]
  have hKq : K_q_fn ℓ C_M_nat L₁ ≤ K_q_fn ℓ C_M_nat L₂ := by
    unfold K_q_fn
    have hm := mul_le_mul_of_nonneg_right hPM (sq_nonneg (S_exp_val ℓ))
    linarith only [hm]
  unfold poly_cap_fn
  push_cast
  have ht1 : K_I_fn ℓ C_net_nat C_M_nat d L₁ * ((d : ℝ) + 1) ≤
      K_I_fn ℓ C_net_nat C_M_nat d L₂ * ((d : ℝ) + 1) :=
    mul_le_mul_of_nonneg_right hKI (by positivity)
  have hKuq_nn : 0 ≤ K_u_fn ℓ C_M_nat L₁ + K_q_fn ℓ C_M_nat L₁ := by
    unfold K_u_fn K_q_fn P_M_fn
    positivity
  have ht2 : (R_fn C_net_nat d L₁ : ℝ) * ((ℓ : ℝ) + 2) * (K_u_fn ℓ C_M_nat L₁ + K_q_fn ℓ C_M_nat L₁) ≤
      (R_fn C_net_nat d L₂ : ℝ) * ((ℓ : ℝ) + 2) * (K_u_fn ℓ C_M_nat L₂ + K_q_fn ℓ C_M_nat L₂) :=
    mul_le_mul (mul_le_mul_of_nonneg_right hR_r (by positivity))
      (by linarith only [hKu, hKq]) hKuq_nn (by positivity)
  linarith only [ht1, ht2]

/-! ### 2. Elementary `Nat.clog`, `Real.log`, Dyadic Size, and Tradeoff Curve Bounds -/

theorem nat_le_two_pow (m : ℕ) : m ≤ 2 ^ m := by
  induction m with
  | zero => simp
  | succ k ih =>
      have hk1 : 1 ≤ 2 ^ k := Nat.one_le_two_pow
      rw [pow_succ]
      omega

theorem nat_clog2_le_self (m : ℕ) : Nat.clog 2 m ≤ m :=
  (Nat.clog_le_iff_le_pow (by norm_num)).mpr (nat_le_two_pow m)

theorem two_pow_clog2_le_two_mul {m : ℕ} (hm : 1 ≤ m) :
    2 ^ (Nat.clog 2 m) ≤ 2 * m := by
  cases hk : Nat.clog 2 m with
  | zero =>
      simp only [pow_zero]
      omega
  | succ k' =>
      have hlt : k' < Nat.clog 2 m := by omega
      have hpow_lt : 2 ^ k' < m := (Nat.lt_clog_iff_pow_lt (by norm_num)).mp hlt
      rw [pow_succ]
      omega

theorem real_log_le_self {x : ℝ} (hx : 0 < x) : Real.log x ≤ x := by
  have h1 := Real.add_one_le_exp (Real.log x)
  rw [Real.exp_log hx] at h1
  linarith only [h1]

theorem log_two_pow_le_nat (k : ℕ) : Real.log ((2 : ℝ) ^ k) ≤ (k : ℝ) := by
  rw [Real.log_pow]
  have h2 : Real.log 2 ≤ 1 := by
    have h1 := Real.add_one_le_exp (Real.log 2)
    rw [Real.exp_log (by norm_num)] at h1
    linarith only [h1]
  exact mul_le_of_le_one_right (Nat.cast_nonneg k) h2

theorem clog_bounds_of_logTerm {n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2) :
    let L := logTerm_of n t δ
    2 * n ≤ 2 ^ (2 * L) ∧
    L_n n ≤ 2 * L ∧
    Nat.clog 2 (n + 2) ≤ 2 * L ∧
    Nat.clog 2 (4 * n + 4) ≤ 2 * L + 2 := by
  intro L
  have hdiv : 2 * (n : ℝ) * (t : ℝ) / δ ≤ (2 : ℝ) ^ (2 * L) :=
    (n_mul_two_zpow_neg_two_logTerm hn ht hδ0).1
  have hmul : 2 * (n : ℝ) * (t : ℝ) ≤ (2 : ℝ) ^ (2 * L) * δ :=
    (div_le_iff₀ hδ0).mp hdiv
  have ht_r : (1 : ℝ) ≤ (t : ℝ) := by exact_mod_cast ht
  have hn_nn : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
  have hpow_pos : (0 : ℝ) ≤ (2 : ℝ) ^ (2 * L) := by positivity
  have h2n_le_2nt : 2 * (n : ℝ) ≤ 2 * (n : ℝ) * (t : ℝ) := by
    nlinarith only [hn_nn, ht_r]
  have hpow_d_le : (2 : ℝ) ^ (2 * L) * δ ≤ (2 : ℝ) ^ (2 * L) := by
    nlinarith only [hpow_pos, hδ1]
  have h2n_r : ((2 * n : ℕ) : ℝ) ≤ ((2 ^ (2 * L) : ℕ) : ℝ) := by
    push_cast
    linarith only [h2n_le_2nt, hmul, hpow_d_le]
  have h2n : 2 * n ≤ 2 ^ (2 * L) := Nat.cast_le.mp h2n_r
  have hLn : L_n n ≤ 2 * L := by
    unfold L_n
    exact (Nat.clog_le_iff_le_pow (by norm_num)).mpr h2n
  have hnp2 : Nat.clog 2 (n + 2) ≤ 2 * L :=
    (Nat.clog_le_iff_le_pow (by norm_num)).mpr (by omega)
  have h4n4 : Nat.clog 2 (4 * n + 4) ≤ 2 * L + 2 := by
    rw [Nat.clog_le_iff_le_pow (by norm_num)]
    have hpow4 : 2 ^ (2 * L + 2) = 4 * 2 ^ (2 * L) := by ring
    omega
  exact ⟨h2n, hLn, hnp2, h4n4⟩

theorem T_pow_and_Lp2_pow_bounds {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (hn : 2 ≤ n) (inst : ConcreteChainInst csp d n t δ) :
    inst.cp.T_pow ≤ 2 * n ∧
    2 ^ inst.cp.L_p2 ≤ 12 * n ∧
    2 ^ inst.cp.L_p2 ≤ 2 ^ (4 * L_n n) := by
  have hT : inst.cp.T_pow ≤ 2 * n := by
    rw [inst.hT_pow_eq]
    exact two_pow_clog2_le_two_mul (by omega)
  have hLp2_raw : 2 ^ inst.cp.L_p2 ≤ 2 * (4 * n + 4) := by
    rw [inst.hL_p2_eq]
    exact two_pow_clog2_le_two_mul (by omega)
  have hLp2_12n : 2 ^ inst.cp.L_p2 ≤ 12 * n := by omega
  have h2n_Ln : 2 * n ≤ 2 ^ (L_n n) := Nat.le_pow_clog (by norm_num) (2 * n)
  have hLn1 : 1 ≤ L_n n := one_le_L_n hn
  have hLp2_8 : 2 ^ inst.cp.L_p2 ≤ 8 * 2 ^ (L_n n) := by omega
  have h8_eq : 8 * 2 ^ (L_n n) = 2 ^ (L_n n + 3) := by ring
  have hexp : L_n n + 3 ≤ 4 * L_n n := by omega
  have hLp2_pow4 : 2 ^ inst.cp.L_p2 ≤ 2 ^ (4 * L_n n) := by
    calc 2 ^ inst.cp.L_p2 ≤ 8 * 2 ^ (L_n n) := hLp2_8
      _ = 2 ^ (L_n n + 3) := h8_eq
      _ ≤ 2 ^ (4 * L_n n) := Nat.pow_le_pow_right (by norm_num) hexp
  exact ⟨hT, hLp2_12n, hLp2_pow4⟩

theorem Q_c_bounds_of_curve {c σ : ℝ} (csp : CurveStaticParams c σ) :
    0 < rho_c c ∧
    rho_c c ≤ Q_c c σ ∧
    Q_c c σ ≤ 1 ∧
    1 ≤ 1 + σ ∧
    1 + σ ≤ 2 := by
  obtain ⟨hrho0, hrho1⟩ := rho_c_bounds csp.hc_gt csp.hc_lt
  have hrho_le_Q : rho_c c ≤ Q_c c σ :=
    rho_c_le_Q_c csp.hc_gt csp.hc_lt csp.hσ0 csp.hσ_hi
  have hg_pos : 0 < g_c c := (g_c_bounds csp.hc_gt csp.hc_lt).1
  have hsqrt_le : Real.sqrt σ ≤ Real.sqrt (rho_c c) := Real.sqrt_le_sqrt csp.hσ_hi
  have hmul_le : g_c c * Real.sqrt σ ≤ g_c c * Real.sqrt (rho_c c) :=
    mul_le_mul_of_nonneg_left hsqrt_le hg_pos.le
  have hbase_eq :
      Real.sqrt (1 - (g_c c) ^ 2) - g_c c * Real.sqrt (rho_c c) = Real.sqrt (rho_c c) := by
    have hc_pos : 0 < c := by linarith only [csp.hc_gt]
    rw [sqrt_one_sub_g_sq csp.hc_gt csp.hc_lt, sqrt_rho_c_eq csp.hc_gt csp.hc_lt]
    unfold g_c
    field_simp
    ring
  have hs_nn : 0 ≤ Real.sqrt (1 - (g_c c) ^ 2) - g_c c * Real.sqrt σ := by
    have h0 : 0 ≤ Real.sqrt (rho_c c) := Real.sqrt_nonneg _
    linarith only [h0, hbase_eq, hmul_le]
  have hsqrt1 : Real.sqrt (1 - (g_c c) ^ 2) ≤ 1 := by
    rw [Real.sqrt_le_one]
    nlinarith only [sq_nonneg (g_c c)]
  have hs_le1 : Real.sqrt (1 - (g_c c) ^ 2) - g_c c * Real.sqrt σ ≤ 1 := by
    have hgs_nn : 0 ≤ g_c c * Real.sqrt σ := mul_nonneg hg_pos.le (Real.sqrt_nonneg σ)
    linarith only [hsqrt1, hgs_nn]
  have hQ_le1 : Q_c c σ ≤ 1 := by
    unfold Q_c
    calc (Real.sqrt (1 - (g_c c) ^ 2) - g_c c * Real.sqrt σ) ^ 2
        ≤ 1 ^ 2 := pow_le_pow_left₀ hs_nn hs_le1 2
      _ = 1 := one_pow 2
  exact ⟨hrho0, hrho_le_Q, hQ_le1, by linarith only [csp.hσ0], by linarith only [csp.hσ_hi, hrho1]⟩

/-! ### 3. Pure `(d, L)` Polynomial Upper Bounds on All Integer / Logarithmic Parameters -/

noncomputable def C_sh_nat {c σ : ℝ} (csp : CurveStaticParams c σ) : ℕ :=
  Nat.ceil csp.C_shell + 1

noncomputable def C_cf_nat {c σ : ℝ} (csp : CurveStaticParams c σ) : ℕ :=
  Nat.ceil csp.C_cfg + 1

noncomputable def C_mc_nat {c σ : ℝ} (csp : CurveStaticParams c σ) : ℕ :=
  Nat.ceil csp.C_mc + 1

def Lp2_ub (_d L : ℕ) : ℕ := 2 * L + 2

def D_ub (d L : ℕ) : ℕ := 4 * K_alpha d * (2 * L + 2)

def B_ub (d L : ℕ) : ℕ := 16384 * (D_ub d L + 2) ^ 2 * (K_alpha d) ^ 2

def S1_ub (d L : ℕ) : ℕ := D_ub d L + D_ub d L * D_ub d L + D_ub d L

def S2_ub (d L : ℕ) : ℕ := D_ub d L * B_ub d L + (B_ub d L + 1)

def Ephi_ub (d L : ℕ) : ℕ := 2 * L + (D_ub d L + 2) + 4

noncomputable def hpjConstNat : ℕ := Nat.ceil hpjOpConst

noncomputable def hpj_ub_nat (d L : ℕ) : ℕ :=
  hpjConstNat * (d + 1) ^ 7 * (d + 2) ^ 3 * (Ephi_ub d L + 1) ^ 3

noncomputable def kbase_ub_nat {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℕ :=
  C_mc_nat csp * K_alpha d * Ephi_ub d L

noncomputable def qidx_ub_nat {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℕ :=
  2 * L + ((D_ub d L + 1) * (hpj_ub_nat d L + kbase_ub_nat csp d L) + 1) + 4

noncomputable def Ncfg_ub_nat {c σ : ℝ} (csp : CurveStaticParams c σ) (_d L : ℕ) : ℕ :=
  C_cf_nat csp * (2 * L) ^ 3

noncomputable def shell_ub_nat {c σ : ℝ} (csp : CurveStaticParams c σ) (_d L : ℕ) : ℕ :=
  C_sh_nat csp * (2 * L)

noncomputable def Mlat_ub_nat {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℕ :=
  16 * d * shell_ub_nat csp d L

noncomputable def Slat_ub_nat {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℕ :=
  2 * Mlat_ub_nat csp d L + 3

noncomputable def Eeps_ub_nat {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℕ :=
  2 * L + ((S1_ub d L + S2_ub d L + B_ub d L + 1) *
    (2 * (Ncfg_ub_nat csp d L + 1) * (Lp2_ub d L + 1)) + 1) + 4

noncomputable def Llog_ub_nat {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℕ :=
  1 + Lp2_ub d L + Eeps_ub_nat csp d L + (2 * shell_ub_nat csp d L + 1)

theorem natPoly2_K_alpha : NatPoly2 (fun d _ => K_alpha d) := by
  unfold K_alpha
  exact natPoly2_mul (natPoly2_const 4) (natPoly2_pow (natPoly2_add natPoly2_d (natPoly2_const 3)) 2)

theorem natPoly2_Lp2_ub : NatPoly2 Lp2_ub :=
  natPoly2_add (natPoly2_mul (natPoly2_const 2) natPoly2_L) (natPoly2_const 2)

theorem natPoly2_D_ub : NatPoly2 D_ub :=
  natPoly2_mul (natPoly2_mul (natPoly2_const 4) natPoly2_K_alpha) natPoly2_Lp2_ub

theorem natPoly2_B_ub : NatPoly2 B_ub :=
  natPoly2_mul
    (natPoly2_mul (natPoly2_const 16384) (natPoly2_pow (natPoly2_add natPoly2_D_ub (natPoly2_const 2)) 2))
    (natPoly2_pow natPoly2_K_alpha 2)

theorem natPoly2_S1_ub : NatPoly2 S1_ub :=
  natPoly2_add (natPoly2_add natPoly2_D_ub (natPoly2_mul natPoly2_D_ub natPoly2_D_ub)) natPoly2_D_ub

theorem natPoly2_S2_ub : NatPoly2 S2_ub :=
  natPoly2_add (natPoly2_mul natPoly2_D_ub natPoly2_B_ub) (natPoly2_add natPoly2_B_ub (natPoly2_const 1))

theorem natPoly2_Ephi_ub : NatPoly2 Ephi_ub :=
  natPoly2_add
    (natPoly2_add (natPoly2_mul (natPoly2_const 2) natPoly2_L) (natPoly2_add natPoly2_D_ub (natPoly2_const 2)))
    (natPoly2_const 4)

theorem natPoly2_hpj_ub : NatPoly2 hpj_ub_nat :=
  natPoly2_mul
    (natPoly2_mul
      (natPoly2_mul (natPoly2_const hpjConstNat) (natPoly2_pow (natPoly2_add natPoly2_d (natPoly2_const 1)) 7))
      (natPoly2_pow (natPoly2_add natPoly2_d (natPoly2_const 2)) 3))
    (natPoly2_pow (natPoly2_add natPoly2_Ephi_ub (natPoly2_const 1)) 3)

theorem natPoly2_kbase_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NatPoly2 (kbase_ub_nat csp) :=
  natPoly2_mul (natPoly2_mul (natPoly2_const (C_mc_nat csp)) natPoly2_K_alpha) natPoly2_Ephi_ub

theorem natPoly2_qidx_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NatPoly2 (qidx_ub_nat csp) :=
  natPoly2_add
    (natPoly2_add (natPoly2_mul (natPoly2_const 2) natPoly2_L)
      (natPoly2_add
        (natPoly2_mul (natPoly2_add natPoly2_D_ub (natPoly2_const 1))
          (natPoly2_add natPoly2_hpj_ub (natPoly2_kbase_ub csp)))
        (natPoly2_const 1)))
    (natPoly2_const 4)

theorem natPoly2_Ncfg_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NatPoly2 (Ncfg_ub_nat csp) :=
  natPoly2_mul (natPoly2_const (C_cf_nat csp)) (natPoly2_pow (natPoly2_mul (natPoly2_const 2) natPoly2_L) 3)

theorem natPoly2_shell_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NatPoly2 (shell_ub_nat csp) :=
  natPoly2_mul (natPoly2_const (C_sh_nat csp)) (natPoly2_mul (natPoly2_const 2) natPoly2_L)

theorem natPoly2_Mlat_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NatPoly2 (Mlat_ub_nat csp) :=
  natPoly2_mul (natPoly2_mul (natPoly2_const 16) natPoly2_d) (natPoly2_shell_ub csp)

theorem natPoly2_Slat_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NatPoly2 (Slat_ub_nat csp) :=
  natPoly2_add (natPoly2_mul (natPoly2_const 2) (natPoly2_Mlat_ub csp)) (natPoly2_const 3)

theorem natPoly2_Eeps_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NatPoly2 (Eeps_ub_nat csp) :=
  natPoly2_add
    (natPoly2_add (natPoly2_mul (natPoly2_const 2) natPoly2_L)
      (natPoly2_add
        (natPoly2_mul
          (natPoly2_add (natPoly2_add (natPoly2_add natPoly2_S1_ub natPoly2_S2_ub) natPoly2_B_ub) (natPoly2_const 1))
          (natPoly2_mul
            (natPoly2_mul (natPoly2_const 2) (natPoly2_add (natPoly2_Ncfg_ub csp) (natPoly2_const 1)))
            (natPoly2_add natPoly2_Lp2_ub (natPoly2_const 1))))
        (natPoly2_const 1)))
    (natPoly2_const 4)

theorem natPoly2_Llog_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NatPoly2 (Llog_ub_nat csp) :=
  natPoly2_add
    (natPoly2_add (natPoly2_add (natPoly2_const 1) natPoly2_Lp2_ub) (natPoly2_Eeps_ub csp))
    (natPoly2_add (natPoly2_mul (natPoly2_const 2) (natPoly2_shell_ub csp)) (natPoly2_const 1))

/-- Sum of all pure `(d, logTerm)` integer / logarithmic parameters of `ConcreteChainInst` (`+ 1`),
so any polynomial expression in these ~30 parameters is bounded by `(masterPolyParamNat inst) ^ k`. -/
noncomputable def masterPolyParamNat {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ) : ℕ :=
  d + L_n n + logTerm_of n t δ +
  inst.cp.L_p2 + inst.cp.D_max + inst.cp.B_scan +
  inst.cp.N_op_s1 + inst.cp.N_op_s2 + inst.cp.N_cfg +
  inst.cp.R + inst.cp.ℓ + inst.cp.T_cdf + inst.cp.p_coord + inst.cp.b +
  B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log +
  inst.cp.N_samp + inst.cp.P_hpj.m + inst.cp.P_hpj.L + inst.cp.P_hpj.q +
  inst.cp.P_hpj.k_d + inst.cp.P_hpj.k_phi + inst.cp.B_walk +
  inst.cp.q_idx + inst.cp.k_base + inst.cp.B_ctr + inst.cp.B_base +
  M_lat_of d inst.params.e + S_lat_of d inst.params.e +
  inst.params.m0 + inst.params.maxShellIndex + (inst.params.J + 1) + 1

noncomputable def masterPoly_ub_nat {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℕ :=
  let bprec := B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat d (Llog_ub_nat csp d L)
  d + 2 * L + L +
  Lp2_ub d L + D_ub d L + B_ub d L +
  S1_ub d L + S2_ub d L + Ncfg_ub_nat csp d L +
  R_fn csp.C_net_nat d (Llog_ub_nat csp d L) + csp.ℓ + bprec + bprec + bprec +
  bprec +
  7 * hpj_ub_nat d L +
  qidx_ub_nat csp d L + kbase_ub_nat csp d L +
  (hpj_ub_nat d L * qidx_ub_nat csp d L + hpj_ub_nat d L) +
  (kbase_ub_nat csp d L * qidx_ub_nat csp d L) +
  Mlat_ub_nat csp d L + Slat_ub_nat csp d L +
  3 * shell_ub_nat csp d L + 1

noncomputable def masterPoly_ub {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℝ :=
  (masterPoly_ub_nat csp d L : ℝ)

theorem nonnegPoly2_masterPoly_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NonnegPoly2 (masterPoly_ub csp) := by
  change NatPoly2 (masterPoly_ub_nat csp)
  have hR : NatPoly2 (fun d L => R_fn csp.C_net_nat d (Llog_ub_nat csp d L)) :=
    nonnegPoly2_comp_L (f := fun d L => (R_fn csp.C_net_nat d L : ℝ)) (g := Llog_ub_nat csp)
      (nonnegPoly2_R_fn csp.C_net_nat) (natPoly2_Llog_ub csp)
  have hBp : NatPoly2 (fun d L => B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat d (Llog_ub_nat csp d L)) :=
    nonnegPoly2_comp_L (f := fun d L => (B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat d L : ℝ))
      (g := Llog_ub_nat csp) (nonnegPoly2_B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat) (natPoly2_Llog_ub csp)
  unfold masterPoly_ub_nat
  dsimp only
  exact natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add
    (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add
    (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add
    (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add
      natPoly2_d (natPoly2_mul (natPoly2_const 2) natPoly2_L)) natPoly2_L)
      natPoly2_Lp2_ub) natPoly2_D_ub) natPoly2_B_ub)
      natPoly2_S1_ub) natPoly2_S2_ub) (natPoly2_Ncfg_ub csp))
      hR) (natPoly2_const csp.ℓ)) hBp) hBp) hBp) hBp)
      (natPoly2_mul (natPoly2_const 7) natPoly2_hpj_ub))
      (natPoly2_qidx_ub csp)) (natPoly2_kbase_ub csp))
      (natPoly2_add (natPoly2_mul natPoly2_hpj_ub (natPoly2_qidx_ub csp)) natPoly2_hpj_ub))
      (natPoly2_mul (natPoly2_kbase_ub csp) (natPoly2_qidx_ub csp)))
      (natPoly2_Mlat_ub csp)) (natPoly2_Slat_ub csp))
      (natPoly2_mul (natPoly2_const 3) (natPoly2_shell_ub csp))) (natPoly2_const 1)

private theorem hpj_params_le_ub {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t L : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ)
    (hEphi : inst.E_phi ≤ Ephi_ub d L) :
    inst.cp.N_samp ≤ hpj_ub_nat d L ∧
    inst.cp.P_hpj.m ≤ hpj_ub_nat d L ∧
    inst.cp.P_hpj.L ≤ hpj_ub_nat d L ∧
    inst.cp.P_hpj.q ≤ hpj_ub_nat d L ∧
    inst.cp.P_hpj.k_d ≤ hpj_ub_nat d L ∧
    inst.cp.P_hpj.k_phi ≤ hpj_ub_nat d L ∧
    inst.cp.B_walk ≤ hpj_ub_nat d L := by
  rcases inst.cp.hP_hpj with ⟨hD, _, _, _, _, _, _, hm_eq, _, _, _, _, _, hS_bound⟩
  obtain ⟨S_hpj, hS_def⟩ : ∃ s : ℕ, s = inst.cp.P_hpj.k_d + inst.cp.P_hpj.k_phi +
      inst.cp.P_hpj.m * (inst.cp.P_hpj.D + 2) +
      inst.cp.P_hpj.L * ((inst.cp.P_hpj.D + 3) * (inst.cp.P_hpj.q + 1) + (inst.cp.P_hpj.D + 3) ^ 3) :=
    ⟨_, rfl⟩
  rw [← hS_def] at hS_bound
  have h2_div_phi : 2 / (inst.cp.phiRat : ℝ) = (2 : ℝ) ^ (inst.E_phi + 1) := by
    rw [inst.hphi_eq, div_inv_eq_mul, pow_succ']
  have hlog_phi_nn : 0 ≤ Real.log (2 / (inst.cp.phiRat : ℝ)) := by
    rw [h2_div_phi]
    exact Real.log_nonneg (by exact_mod_cast (@Nat.one_le_two_pow (inst.E_phi + 1)))
  have hlog_phi_ub : Real.log (2 / (inst.cp.phiRat : ℝ)) ≤ ((Ephi_ub d L : ℝ) + 1) := by
    rw [h2_div_phi]
    have h1 := (log_two_pow_le_nat (inst.E_phi + 1)).trans (Nat.cast_le.mpr (Nat.add_le_add_right hEphi 1))
    simpa only [Nat.cast_add, Nat.cast_one] using h1
  have hlog_d2_nn : 0 ≤ Real.log ((d : ℝ) + 2) :=
    Real.log_nonneg (by linarith [Nat.cast_nonneg (α := ℝ) d])
  have hlog_d2_ub : Real.log ((d : ℝ) + 2) ≤ (d : ℝ) + 2 :=
    real_log_le_self (by linarith [Nat.cast_nonneg (α := ℝ) d])
  have hop_le : hpjOpBound d (inst.cp.phiRat : ℝ) ≤ (hpj_ub_nat d L : ℝ) := by
    unfold hpjOpBound hpj_ub_nat
    push_cast
    have hc_le : hpjOpConst ≤ (hpjConstNat : ℝ) := Nat.le_ceil hpjOpConst
    have hc_head : hpjOpConst * ((d : ℝ) + 1) ^ 7 ≤ (hpjConstNat : ℝ) * ((d : ℝ) + 1) ^ 7 :=
      mul_le_mul_of_nonneg_right hc_le (pow_nonneg (by linarith [Nat.cast_nonneg (α := ℝ) d]) 7)
    have hp1 : (Real.log ((d : ℝ) + 2)) ^ 3 ≤ ((d : ℝ) + 2) ^ 3 :=
      pow_le_pow_left₀ hlog_d2_nn hlog_d2_ub 3
    have hp2 : (Real.log (2 / (inst.cp.phiRat : ℝ))) ^ 3 ≤ ((Ephi_ub d L : ℝ) + 1) ^ 3 :=
      pow_le_pow_left₀ hlog_phi_nn hlog_phi_ub 3
    have htail : (Real.log ((d : ℝ) + 2)) ^ 3 * (Real.log (2 / (inst.cp.phiRat : ℝ))) ^ 3 ≤
        ((d : ℝ) + 2) ^ 3 * ((Ephi_ub d L : ℝ) + 1) ^ 3 :=
      mul_le_mul hp1 hp2 (pow_nonneg hlog_phi_nn 3) (pow_nonneg (by linarith [Nat.cast_nonneg (α := ℝ) d]) 3)
    have htail_nn : 0 ≤ (Real.log ((d : ℝ) + 2)) ^ 3 * (Real.log (2 / (inst.cp.phiRat : ℝ))) ^ 3 :=
      mul_nonneg (pow_nonneg hlog_d2_nn 3) (pow_nonneg hlog_phi_nn 3)
    have hhead_nn : 0 ≤ (hpjConstNat : ℝ) * ((d : ℝ) + 1) ^ 7 :=
      mul_nonneg (Nat.cast_nonneg _) (pow_nonneg (by linarith [Nat.cast_nonneg (α := ℝ) d]) 7)
    calc hpjOpConst * ((d : ℝ) + 1) ^ 7 * (Real.log ((d : ℝ) + 2)) ^ 3 *
            (Real.log (2 / (inst.cp.phiRat : ℝ))) ^ 3
        = (hpjOpConst * ((d : ℝ) + 1) ^ 7) *
            ((Real.log ((d : ℝ) + 2)) ^ 3 * (Real.log (2 / (inst.cp.phiRat : ℝ))) ^ 3) := by ring
      _ ≤ ((hpjConstNat : ℝ) * ((d : ℝ) + 1) ^ 7) *
            (((d : ℝ) + 2) ^ 3 * ((Ephi_ub d L : ℝ) + 1) ^ 3) :=
          mul_le_mul hc_head htail htail_nn hhead_nn
      _ = (hpjConstNat : ℝ) * ((d : ℝ) + 1) ^ 7 * ((d : ℝ) + 2) ^ 3 *
            ((Ephi_ub d L : ℝ) + 1) ^ 3 := by ring
  have hS_r : (S_hpj : ℝ) ≤ (hpj_ub_nat d L : ℝ) := by
    have h0 : (0 : ℝ) ≤ (S_hpj : ℝ) := Nat.cast_nonneg S_hpj
    have hS_100 : (S_hpj : ℝ) ≤ 100000 * (S_hpj : ℝ) := by linarith only [h0]
    exact (hS_100.trans hS_bound).trans hop_le
  have hS_le : S_hpj ≤ hpj_ub_nat d L := Nat.cast_le.mp hS_r
  have hm_le : inst.cp.P_hpj.m ≤ S_hpj := by
    have h1 : inst.cp.P_hpj.m * 1 ≤ inst.cp.P_hpj.m * (inst.cp.P_hpj.D + 2) :=
      Nat.mul_le_mul_left _ (by omega)
    rw [hS_def]; omega
  have hq_le : inst.cp.P_hpj.q ≤ S_hpj :=
    (hm_eq.symm ▸ nat_le_two_pow inst.cp.P_hpj.q).trans hm_le
  have hpd3_pos : 1 ≤ (inst.cp.P_hpj.D + 3) ^ 3 := Nat.one_le_pow 3 _ (by omega)
  have hL_le : inst.cp.P_hpj.L ≤ S_hpj := by
    have h1 : inst.cp.P_hpj.L * 1 ≤
        inst.cp.P_hpj.L * ((inst.cp.P_hpj.D + 3) * (inst.cp.P_hpj.q + 1) + (inst.cp.P_hpj.D + 3) ^ 3) :=
      Nat.mul_le_mul_left _ (by omega)
    rw [hS_def]; omega
  have hBw_le : inst.cp.B_walk ≤ S_hpj := by
    have hD4 : d + 1 + 3 = inst.cp.P_hpj.D + 3 := by omega
    calc inst.cp.B_walk
        = inst.cp.P_hpj.L * ((d + 1 + 3) * inst.cp.P_hpj.q) := Nat.mul_assoc _ _ _
      _ = inst.cp.P_hpj.L * ((inst.cp.P_hpj.D + 3) * inst.cp.P_hpj.q) := by rw [hD4]
      _ ≤ inst.cp.P_hpj.L *
            ((inst.cp.P_hpj.D + 3) * (inst.cp.P_hpj.q + 1) + (inst.cp.P_hpj.D + 3) ^ 3) :=
          Nat.mul_le_mul_left _
            ((Nat.mul_le_mul_left _ (Nat.le_succ _)).trans (Nat.le_add_right _ _))
      _ ≤ S_hpj := by rw [hS_def]; exact Nat.le_add_left _ _
  have hkd_le : inst.cp.P_hpj.k_d ≤ S_hpj := by rw [hS_def]; omega
  have hkphi_le : inst.cp.P_hpj.k_phi ≤ S_hpj := by rw [hS_def]; omega
  refine ⟨?_, hm_le.trans hS_le, hL_le.trans hS_le, hq_le.trans hS_le,
    hkd_le.trans hS_le, hkphi_le.trans hS_le, hBw_le.trans hS_le⟩
  rw [inst.hN_samp_eq]
  exact hm_le.trans hS_le

theorem L_log_and_masterPoly_le_ub {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (inst : ConcreteChainInst csp d n t δ) :
    inst.L_log ≤ Llog_ub_nat csp d (logTerm_of n t δ) ∧
    masterPolyParamNat inst ≤ masterPoly_ub_nat csp d (logTerm_of n t δ) := by
  obtain ⟨L, hL_def⟩ : ∃ x, x = logTerm_of n t δ := ⟨_, rfl⟩
  rw [← hL_def]
  have hcb := clog_bounds_of_logTerm hn ht hδ0 hδ1
  dsimp only at hcb
  rw [← hL_def] at hcb
  obtain ⟨_, hLn_le, hnp2_le, h4n4_le⟩ := hcb
  have hLp2_le : inst.cp.L_p2 ≤ Lp2_ub d L := by
    rw [inst.hL_p2_eq]; exact h4n4_le
  have hD_eq : inst.cp.D_max = D_max_nat d n := by
    unfold ChainParams.D_max D_max_nat; rw [inst.hn_eq]
  have hD_le : D_max_nat d n ≤ D_ub d L := by
    unfold D_max_nat D_ub
    exact Nat.mul_le_mul_left (4 * K_alpha d) (by omega)
  have hB_eq : inst.cp.B_scan = B_scan_nat d n := by
    unfold ChainParams.B_scan ChainParams.D2 B_scan_nat; rw [hD_eq]
  have hB_le : B_scan_nat d n ≤ B_ub d L := by
    unfold B_scan_nat B_ub
    exact Nat.mul_le_mul_right ((K_alpha d) ^ 2)
      (Nat.mul_le_mul_left 16384 (Nat.pow_le_pow_left (by omega) 2))
  have hS1_eq : inst.cp.N_op_s1 = N_op_s1_nat d n := by
    change inst.cp.D_max + inst.cp.D_max * inst.cp.D_max + inst.cp.D_max = N_op_s1_nat d n
    unfold N_op_s1_nat; rw [hD_eq]
  have hS1_le : N_op_s1_nat d n ≤ S1_ub d L := by
    unfold N_op_s1_nat S1_ub
    have hm := Nat.mul_le_mul hD_le hD_le
    omega
  have hS2_eq : inst.cp.N_op_s2 = N_op_s2_nat d n := by
    change inst.cp.D_max * inst.cp.B_scan + (inst.cp.B_scan + 1) = N_op_s2_nat d n
    unfold N_op_s2_nat; rw [hD_eq, hB_eq]
  have hS2_le : N_op_s2_nat d n ≤ S2_ub d L := by
    unfold N_op_s2_nat S2_ub
    have hm := Nat.mul_le_mul hD_le hB_le
    omega
  have hEphi_le : inst.E_phi ≤ Ephi_ub d L := by
    have heq := inst.hE_phi_eq
    rw [← hL_def] at heq
    rw [heq]
    have hc := (nat_clog2_le_self (D_max_nat d n + 2)).trans (Nat.add_le_add_right hD_le 2)
    unfold Ephi_ub; omega
  obtain ⟨hNs_le, hm_hpj_le, hL_hpj_le, hq_hpj_le, hkd_le, hkphi_le, hBw_le⟩ :=
    hpj_params_le_ub inst hEphi_le
  have hkbase_le : inst.cp.k_base ≤ kbase_ub_nat csp d L := by
    refine inst.hk_base_le.trans (Nat.ceil_le.mpr ?_)
    have hinv : (hpjAlpha d)⁻¹ = (K_alpha d : ℝ) := by
      rw [hpjAlpha_eq_inv_K_alpha d, one_div, inv_inv]
    have h1_psi : 1 / inst.ψ = (2 : ℝ) ^ inst.E_phi := by
      rw [inst.hψ_eq, one_div, inv_inv]
    have hlog_psi_nn : 0 ≤ Real.log (1 / inst.ψ) := by
      rw [h1_psi]
      exact Real.log_nonneg (by exact_mod_cast (@Nat.one_le_two_pow inst.E_phi))
    have hlog_psi_le : Real.log (1 / inst.ψ) ≤ (Ephi_ub d L : ℝ) := by
      rw [h1_psi]
      exact (log_two_pow_le_nat inst.E_phi).trans (Nat.cast_le.mpr hEphi_le)
    have hCmc_le : csp.C_mc ≤ (C_mc_nat csp : ℝ) := by
      unfold C_mc_nat; push_cast; linarith only [Nat.le_ceil csp.C_mc]
    rw [hinv]
    unfold kbase_ub_nat
    push_cast
    exact mul_le_mul
      (mul_le_mul_of_nonneg_right hCmc_le (Nat.cast_nonneg (K_alpha d)))
      hlog_psi_le hlog_psi_nn
      (mul_nonneg (Nat.cast_nonneg (C_mc_nat csp)) (Nat.cast_nonneg (K_alpha d)))
  have hqidx_le : inst.cp.q_idx ≤ qidx_ub_nat csp d L := by
    have heq := inst.hq_idx_eq
    rw [← hL_def] at heq
    rw [heq]
    have harg : (D_max_nat d n + 1) * (inst.cp.N_samp + inst.cp.k_base) + 1 ≤
        (D_ub d L + 1) * (hpj_ub_nat d L + kbase_ub_nat csp d L) + 1 := by
      have hm := Nat.mul_le_mul (Nat.add_le_add_right hD_le 1) (Nat.add_le_add hNs_le hkbase_le)
      omega
    have hc := (nat_clog2_le_self _).trans harg
    unfold qidx_ub_nat; omega
  have hBctr_le : inst.cp.B_ctr ≤ hpj_ub_nat d L * qidx_ub_nat csp d L + hpj_ub_nat d L := by
    change inst.cp.N_samp * inst.cp.q_idx + inst.cp.B_walk ≤ _
    exact Nat.add_le_add (Nat.mul_le_mul hNs_le hqidx_le) hBw_le
  have hBbase_le : inst.cp.B_base ≤ kbase_ub_nat csp d L * qidx_ub_nat csp d L :=
    Nat.mul_le_mul hkbase_le hqidx_le
  have hCsh_le : csp.C_shell ≤ (C_sh_nat csp : ℝ) := by
    unfold C_sh_nat; push_cast; linarith only [Nat.le_ceil csp.C_shell]
  have hCcf_le : csp.C_cfg ≤ (C_cf_nat csp : ℝ) := by
    unfold C_cf_nat; push_cast; linarith only [Nat.le_ceil csp.C_cfg]
  have hLn_r : (L_n n : ℝ) ≤ ((2 * L : ℕ) : ℝ) := by exact_mod_cast hLn_le
  have hsh_r_bound : csp.C_shell * (L_n n : ℝ) ≤ (shell_ub_nat csp d L : ℝ) := by
    unfold shell_ub_nat; push_cast
    exact mul_le_mul hCsh_le (by simpa using hLn_r) (Nat.cast_nonneg _) (Nat.cast_nonneg _)
  have hm0_le : inst.params.m0 ≤ shell_ub_nat csp d L :=
    Nat.cast_le.mp (inst.hm0_le.trans hsh_r_bound)
  have hmaxSh_le : inst.params.maxShellIndex ≤ shell_ub_nat csp d L :=
    Nat.cast_le.mp (inst.hmaxShell_le.trans hsh_r_bound)
  have hJ_le : inst.params.J + 1 ≤ shell_ub_nat csp d L :=
    Nat.cast_le.mp (inst.hJ_le.trans hsh_r_bound)
  have hNcfg_le : inst.cp.N_cfg ≤ Ncfg_ub_nat csp d L := by
    refine Nat.cast_le.mp (inst.hN_cfg_le.trans ?_)
    unfold Ncfg_ub_nat; push_cast
    exact mul_le_mul hCcf_le
      (pow_le_pow_left₀ (Nat.cast_nonneg _) (by simpa using hLn_r) 3)
      (pow_nonneg (Nat.cast_nonneg _) 3) (Nat.cast_nonneg _)
  obtain ⟨he0, _, _, he_inv_m0⟩ := params_e_bounds inst.params
  have hMlat_le : M_lat_of d inst.params.e ≤ Mlat_ub_nat csp d L := by
    unfold M_lat_of
    refine Nat.ceil_le.mpr ?_
    have hdiv_eq : 16 * (d : ℝ) / (inst.params.e : ℝ) = 16 * (d : ℝ) * (1 / (inst.params.e : ℝ)) :=
      div_eq_mul_one_div _ _
    rw [hdiv_eq]
    have hm0_r : (inst.params.m0 : ℝ) ≤ (shell_ub_nat csp d L : ℝ) := by exact_mod_cast hm0_le
    unfold Mlat_ub_nat; push_cast
    exact mul_le_mul_of_nonneg_left (he_inv_m0.trans hm0_r)
      (mul_nonneg (by norm_num) (Nat.cast_nonneg d))
  have hSlat_le : S_lat_of d inst.params.e ≤ Slat_ub_nat csp d L := by
    unfold S_lat_of Slat_ub_nat
    have hc := nat_clog2_le_self (2 * M_lat_of d inst.params.e + 2)
    omega
  have hEeps_le : inst.E_eps ≤ Eeps_ub_nat csp d L := by
    have heq := inst.hE_eps_eq
    rw [← hL_def] at heq
    rw [heq]
    have hf1 : N_op_s1_nat d n + N_op_s2_nat d n + B_scan_nat d n + 1 ≤
        S1_ub d L + S2_ub d L + B_ub d L + 1 := by omega
    have hf2 : 2 * (inst.cp.N_cfg + 1) * (inst.cp.L_p2 + 1) ≤
        2 * (Ncfg_ub_nat csp d L + 1) * (Lp2_ub d L + 1) :=
      Nat.mul_le_mul
        (Nat.mul_le_mul_left 2 (Nat.add_le_add_right hNcfg_le 1))
        (Nat.add_le_add_right hLp2_le 1)
    have harg := Nat.add_le_add_right (Nat.mul_le_mul hf1 hf2) 1
    have hc := (nat_clog2_le_self _).trans harg
    unfold Eeps_ub_nat; omega
  have hLlog_le : inst.L_log ≤ Llog_ub_nat csp d L := by
    rw [inst.hL_log_eq]
    refine Nat.ceil_le.mpr ?_
    have h1_arg : 2 * ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) / inst.ε₀ =
        (2 : ℝ) ^ (1 + inst.cp.L_p2 + inst.E_eps) := by
      rw [inst.hε₀_eq, div_inv_eq_mul]
      push_cast
      rw [pow_add, pow_add, pow_one]
    have hlog1 : Real.log (2 * ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) / inst.ε₀) ≤
        ((1 + Lp2_ub d L + Eeps_ub_nat csp d L : ℕ) : ℝ) := by
      rw [h1_arg]
      exact (log_two_pow_le_nat _).trans (Nat.cast_le.mpr (by omega : 1 + inst.cp.L_p2 + inst.E_eps ≤ 1 + Lp2_ub d L + Eeps_ub_nat csp d L))
    have h2e_pos : 0 < 2 / (inst.params.e : ℝ) := div_pos (by norm_num) he0
    have h2e_ub : 2 / (inst.params.e : ℝ) ≤ ((2 * shell_ub_nat csp d L + 1 : ℕ) : ℝ) := by
      have hm0_r : (inst.params.m0 : ℝ) ≤ (shell_ub_nat csp d L : ℝ) := by exact_mod_cast hm0_le
      have hdiv : 2 / (inst.params.e : ℝ) = 2 * (1 / (inst.params.e : ℝ)) := div_eq_mul_one_div _ _
      rw [hdiv]
      push_cast
      linarith only [he_inv_m0, hm0_r]
    have h2sh_pos : (0 : ℝ) < ((2 * shell_ub_nat csp d L + 1 : ℕ) : ℝ) := by
      exact_mod_cast Nat.succ_pos (2 * shell_ub_nat csp d L)
    have hlog2 : Real.log (2 / (inst.params.e : ℝ)) ≤ ((2 * shell_ub_nat csp d L + 1 : ℕ) : ℝ) :=
      (Real.log_le_log h2e_pos h2e_ub).trans (real_log_le_self h2sh_pos)
    unfold Llog_ub_nat
    push_cast at hlog1 hlog2 ⊢
    linarith only [hlog1, hlog2]
  have hBp_mono := B_prec_fn_mono_L csp.ℓ csp.C_net_nat csp.C_M_nat d hLlog_le
  have hR_le : inst.cp.R ≤ R_fn csp.C_net_nat d (Llog_ub_nat csp d L) := by
    rw [inst.hR_eq]; exact R_fn_mono_L csp.C_net_nat d hLlog_le
  have hb_le : inst.cp.b ≤ B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat d (Llog_ub_nat csp d L) := by
    rw [inst.hb_eq]
    exact (b_fn_le_B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log).trans hBp_mono
  have hT_le : inst.cp.T_cdf ≤ B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat d (Llog_ub_nat csp d L) := by
    rw [inst.hT_cdf_eq]
    have hT_bp : T_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log ≤
        B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log := by
      unfold B_prec_fn; omega
    exact hT_bp.trans hBp_mono
  have hpc_le : inst.cp.p_coord ≤ B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat d (Llog_ub_nat csp d L) := by
    rw [inst.hp_coord_eq]
    have hpc_bp : p_coord_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log ≤
        B_prec_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log := by
      unfold B_prec_fn b_fn; omega
    exact hpc_bp.trans hBp_mono
  refine ⟨hLlog_le, ?_⟩
  unfold masterPolyParamNat masterPoly_ub_nat
  dsimp only
  rw [← hL_def, hD_eq, hB_eq, hS1_eq, hS2_eq, inst.hℓ_eq]
  omega

end UL.Proof.clm_9_1_explicit_tradeoff.CG15
