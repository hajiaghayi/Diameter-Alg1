import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG16_Stage21a
set_option autoImplicit false
set_option maxHeartbeats 400000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG15_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
open UL.Proof.clm_9_1_explicit_tradeoff.CG16_Stage2

/-! ### Stage-2 Leaf-Spawn RAM Subroutine (`leafSpawnStage2Stmt`) -/

noncomputable def leafFinishStage2Pure {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp)
    (jobs₂ : Fin cp.D_max → Option (SuffixJob cp)) (ω₂ : Stage2Coins cp) :
    ChainEngineState cp :=
  let pts := st.hp.coords
  if !st.leafOverflow && decide (cp.B_scan < st.leafArr.length) then
    if st.serving.length < cp.D_max && decide (st.leafArr.length ≤ cp.B_scan + 1) then
      let leafCtr := ω₂.2 (Fin.last cp.D_max)
      let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts st.leafArr leafCtr
      let P₀_uid := st.leafArr.toFinset.image st.gt.uidOf
      let bs0 := BuildState.init cp st.leafArr.length st.leafArr os.1 os.2 P₀_uid
      let steps := min st.leafArr.length (cp.B_scan + 1)
      let leafSeeds : Fin steps → OpSeed cp := fun j =>
        ω₂.1 ⟨cp.D_max * cp.B_scan + j.val, by
          have hj : j.val < cp.B_scan + 1 := lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)
          exact Nat.add_lt_add_left hj _⟩
      let bsDone := advanceBuildLoop cp pts steps leafSeeds bs0
      let u_leaf := bsDone.curNode
      if u_leaf.resArr.length ≤ cp.B_scan then
        { st with
          serving := st.serving ++ [u_leaf]
          jobs := jobs₂
          leafArr := u_leaf.resArr
          leafOverflow := false }
      else
        { st with
          serving := st.serving ++ [u_leaf]
          jobs := jobs₂
          leafArr := []
          leafOverflow := true }
    else
      { st with jobs := jobs₂, leafArr := [], leafOverflow := true }
  else
    { st with jobs := jobs₂ }

def leafSyncExtendStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (leafAllocAndBuildStmt ops)
  (.seq (appendSlotToServStmt 15)
  (.seq (ops.readNodeScalarStmt .resLen 15 27)
    (.ite (.intLe (.readHeap engScrTbl (.lit 27)) (.lit (cp.B_scan : ℤ)))
      (.seq (copyNodeResToLeafStmt ops 15)
            (.writeWordHeap engMetaTbl (.lit 1) (.lit 0)))
      (.seq (.writeWordHeap engMetaTbl (.lit 2) (.lit 0))
            (.writeWordHeap engMetaTbl (.lit 1) (.lit 1))))))

theorem zeroRand_leafSyncExtendStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (leafSyncExtendStmt ops) :=
  .seq (zeroRand_leafAllocAndBuildStmt ops)
  (.seq (zeroRand_appendSlotToServStmt 15)
  (.seq (ops.zeroRand_readNodeScalar .resLen 15 27)
    (.ite (.seq (zeroRand_copyNodeResToLeafStmt ops 15) (.writeWordHeap _ _ _))
          (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))

def leafSpawnStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .ite (.and (.intEq (.readHeap engMetaTbl (.lit 1)) (.lit 0))
             (.intLt (.lit (cp.B_scan : ℤ)) (.readHeap engMetaTbl (.lit 2))))
    (.ite (.and (.intLt (.readHeap engMetaTbl (.lit 0)) (.lit (cp.D_max : ℤ)))
                (.intLe (.readHeap engMetaTbl (.lit 2)) (.lit (((cp.B_scan + 1 : ℕ) : ℤ)))))
      (leafSyncExtendStmt ops)
      (.seq (.writeWordHeap engMetaTbl (.lit 2) (.lit 0))
            (.writeWordHeap engMetaTbl (.lit 1) (.lit 1))))
    .skip

theorem zeroRand_leafSpawnStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (leafSpawnStage2Stmt ops) :=
  .ite (.ite (zeroRand_leafSyncExtendStmt ops)
             (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))
    .skip

def leafSpawnStage2Cost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  leafAllocAndBuildCost ops + 2 * ops.C_read + cp.B_scan * (ops.C_read + 120) + 190

theorem exec_leafSpawnStage2Stmt
    (h_clm_7_3 : S_clm_7_3_global_approx)
    {d : ℕ} (hd : 1 ≤ d) {params : LocalScaleParams} (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1)
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d)
    {P' : DynamicPointSet d} {st₁ : ChainEngineState cp}
    {jobs₂ : Fin cp.D_max → Option (SuffixJob cp)}
    {bits : Fin cp.B_STEP → Bool}
    {m₀ : ArithRAMMemory}
    (_hP' : P'.WellFormed cp.n)
    (hwf₁ : PostStage1WF cp P' st₁)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops { st₁ with jobs := jobs₂ } m₀)
    (hcoins₀ : MemHasStepCoins cp bits m₀) :
    let ω₂ := (bitsToStepCoinBundle cp bits).2.1
    let st₂ := leafFinishStage2Pure cp st₁ jobs₂ ω₂
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (leafSpawnStage2Stmt ops) m₀
      (fun m₁ =>
        EncChainEngine ops st₂ m₁ ∧
        MemHasStepCoins cp bits m₁ ∧
        wRead m₁ 0 0 = wRead m₀ 0 0)
      (leafSpawnStage2Cost ops) := by
  intro ω₂ st₂
  have hTW := ops.hTW
  have hBW_meta := ops.hBW_meta
  have hBW_scr := ops.hBW_scr
  rcases henc₀ with ⟨hsr₀, hhp₀, hans₀, hov₀, hlf_le₀, hlf_sp₀, hserv_le₀, hserv_len₀,
    servSlots, readySlots, curSlots, hslen₀, hserv₀, hjobs₀, hall_nd₀, hall_lt₀⟩
  change wRead m₀ engMetaTbl 1 = (if st₁.leafOverflow then 1 else 0) at hov₀
  change st₁.leafArr.length ≤ cp.B_scan + 1 at hlf_le₀
  change EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) st₁.leafArr m₀ at hlf_sp₀
  change st₁.serving.length ≤ cp.D_max at hserv_le₀
  change wRead m₀ engMetaTbl 0 = (st₁.serving.length : ℤ) at hserv_len₀
  change servSlots.length = st₁.serving.length at hslen₀
  let condOuter : ArithCondExpr :=
    .and (.intEq (.readHeap engMetaTbl (.lit 1)) (.lit 0))
         (.intLt (.lit (cp.B_scan : ℤ)) (.readHeap engMetaTbl (.lit 2)))
  have hcondOuter_eq : (evalArithCond inp 0 m₀ condOuter).1 =
      (!st₁.leafOverflow && decide (cp.B_scan < st₁.leafArr.length)) := by
    dsimp only [condOuter]; simp only [evalArithCond, evalIntExpr]
    change (decide (wRead m₀ engMetaTbl 1 = 0) &&
            decide ((cp.B_scan : ℤ) < wRead m₀ engMetaTbl 2)) = _
    rw [hov₀, hlf_sp₀.2.2.1]
    cases st₁.leafOverflow <;> simp [Int.ofNat_lt]
  unfold leafSpawnStage2Stmt
  by_cases htrig : (!st₁.leafOverflow && decide (cp.B_scan < st₁.leafArr.length)) = true
  · have hcondO_T : (evalArithCond inp 0 m₀ condOuter).1 = true := hcondOuter_eq.trans htrig
    rcases Bool.and_eq_true_iff.mp htrig with ⟨hnov_b, hgtB_b⟩
    have hov_false : st₁.leafOverflow = false := by
      cases hb : st₁.leafOverflow <;> [rfl; (rw [hb] at hnov_b; cases hnov_b)]
    have hgt_B : cp.B_scan < st₁.leafArr.length := of_decide_eq_true hgtB_b
    let condInner : ArithCondExpr :=
      .and (.intLt (.readHeap engMetaTbl (.lit 0)) (.lit (cp.D_max : ℤ)))
           (.intLe (.readHeap engMetaTbl (.lit 2)) (.lit (((cp.B_scan + 1 : ℕ) : ℤ))))
    have hcondInner_eq : (evalArithCond inp 0 m₀ condInner).1 =
        (decide (st₁.serving.length < cp.D_max) && decide (st₁.leafArr.length ≤ cp.B_scan + 1)) := by
      dsimp only [condInner]; simp only [evalArithCond, evalIntExpr]
      change (decide (wRead m₀ engMetaTbl 0 < (cp.D_max : ℤ)) &&
              decide (wRead m₀ engMetaTbl 2 ≤ (((cp.B_scan + 1 : ℕ) : ℤ)))) = _
      rw [hserv_len₀, hlf_sp₀.2.2.1]
      congr 1
      · simp [Int.ofNat_lt]
      · simp only [decide_eq_decide]; omega
    refine ExecDet.ite' (C_c := 16) (C_b := leafSpawnStage2Cost ops - 16) _ _ _ hcondO_T
      (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
      (by unfold leafSpawnStage2Cost; omega)
    by_cases hext : (decide (st₁.serving.length < cp.D_max) && decide (st₁.leafArr.length ≤ cp.B_scan + 1)) = true
    · have hcondI_T : (evalArithCond inp 0 m₀ condInner).1 = true := hcondInner_eq.trans hext
      rcases Bool.and_eq_true_iff.mp hext with ⟨hserv_lt_b, hlf_le_b⟩
      have hserv_lt : st₁.serving.length < cp.D_max := of_decide_eq_true hserv_lt_b
      have hlf_le1 : st₁.leafArr.length ≤ cp.B_scan + 1 := of_decide_eq_true hlf_le_b
      refine ExecDet.ite' (C_c := 16)
        (C_b := leafAllocAndBuildCost ops + 40 + ops.C_read +
          (108 + ops.C_read + cp.B_scan * (ops.C_read + 120)))
        _ _ _ hcondI_T (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
        (by unfold leafSpawnStage2Cost; omega)
      unfold leafSyncExtendStmt
      refine ExecDet.seq'
        (40 + ops.C_read + (108 + ops.C_read + cp.B_scan * (ops.C_read + 120)))
        (exec_leafAllocAndBuildStmt h_clm_7_3 hd he1 hh0 hh1 ops inp hwf₁ hov_false hgt_B hlf_le1
          hserv_le₀ hslen₀ hfp₀ hsr₀ hhp₀ hlf_sp₀ hserv_len₀
          (fun i his => (hserv₀ i (hslen₀ ▸ his) his).1) hjobs₀ hall_lt₀ hcoins₀)
        (by omega) ?_
      intro mL ⟨hsrL, hul_res_nd, hul_res_lt_n,
        ⟨ns, hns_M, hns_fresh, hr15_L, henc_ulL, hnd_ulL⟩, hw8_L, hr2_L, hr20_L⟩ hfpL
      let pts := st₁.hp.coords
      let leafCtr := ω₂.2 (Fin.last cp.D_max)
      let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts st₁.leafArr leafCtr
      let P₀_uid := st₁.leafArr.toFinset.image st₁.gt.uidOf
      let bs0 := BuildState.init cp st₁.leafArr.length st₁.leafArr os.1 os.2 P₀_uid
      let steps := min st₁.leafArr.length (cp.B_scan + 1)
      let leafSeeds : Fin steps → OpSeed cp := fun j =>
        ω₂.1 ⟨cp.D_max * cp.B_scan + j.val, by
          have hj : j.val < cp.B_scan + 1 := lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)
          exact Nat.add_lt_add_left hj _⟩
      let u_leaf0 := (advanceBuildLoop cp pts steps leafSeeds bs0).curNode
      change u_leaf0.resArr.Nodup at hul_res_nd
      change ∀ x ∈ u_leaf0.resArr, x < cp.n at hul_res_lt_n
      change ops.EncNode u_leaf0 ns mL at henc_ulL
      obtain ⟨u_leaf, hu_leaf_eq⟩ : ∃ x, x = u_leaf0 := ⟨_, rfl⟩
      rw [← hu_leaf_eq] at hul_res_nd hul_res_lt_n henc_ulL
      refine ExecDet.seq'
        (ops.C_read + (108 + ops.C_read + cp.B_scan * (ops.C_read + 120)))
        (exec_appendSlotToServStmt ops inp 15 hfpL hsrL (by decide)
          (hslen₀ ▸ hserv_lt)
          ((hw8_L engMetaTbl (by decide) 0).trans (hslen₀ ▸ hserv_len₀))
          hr15_L
          (fun i his => (hw8_L engMetaTbl (by decide) _).trans (hserv₀ i (hslen₀ ▸ his) his).1))
        (by omega) ?_
      intro mAp ⟨hsrAp, _, hw0Ap, hservAp, hndAp, hftAp, hfmAp, hfsAp, hfrAp⟩ hfpAp
      have hr15_Ap : wRead mAp engScrTbl 15 = (ns : ℤ) := (hfsAp 15 (by decide)).trans hr15_L
      have henc_ulAp : ops.EncNode u_leaf ns mAp := hndAp u_leaf ns hns_M henc_ulL
      refine ExecDet.seq'
        (108 + ops.C_read + cp.B_scan * (ops.C_read + 120))
        (ops.readNodeScalar_spec inp mAp u_leaf ns .resLen 15 27 hns_M
          (by omega) (by omega) (by omega) (by omega) hfpAp hsrAp henc_ulAp hr15_Ap)
        (by omega) ?_
      intro mR ⟨hsrR, hr27_R, hndR, hwR, hfsR, hrR⟩ hfpR
      change wRead mR engScrTbl 27 = (u_leaf.resArr.length : ℤ) at hr27_R
      have hcondRes : (evalArithCond inp 0 mR (.intLe (.readHeap engScrTbl (.lit 27)) (.lit (cp.B_scan : ℤ)))).1 =
          decide (u_leaf.resArr.length ≤ cp.B_scan) := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mR engScrTbl 27 ≤ (cp.B_scan : ℤ)) = _
        rw [hr27_R]; simp [Int.ofNat_le]
      let servSlots' := servSlots ++ [ns]
      have hall' := allSlots_nodup_serv_append_fresh (D := cp.D_max) (M := M_slots cp)
        (servSlots := servSlots)
        (U := fun r => jobUsedSlots (jobs₂ r) (readySlots r) (curSlots r))
        hall_nd₀ hall_lt₀ hns_M hns_fresh
      have hw_lt6_R : ∀ t < 6, ∀ i, wRead mR t i = wRead m₀ t i := fun t ht6 i =>
        (hwR t (by omega) (by unfold engScrTbl; omega) i).trans
          ((hftAp t (by unfold engMetaTbl; omega) (by unfold engScrTbl; omega) i).trans
            (hw8_L t (by omega) i))
      have hw6_R : ∀ i, i ≠ 0 → i ≠ servSlotOff servSlots.length → wRead mR engMetaTbl i = wRead m₀ engMetaTbl i :=
        fun i h0 hs => (hwR engMetaTbl (by decide) (by decide) i).trans
          ((hfmAp i h0 hs).trans (hw8_L engMetaTbl (by decide) i))
      have hw7_R : ∀ i, wRead mR engArrTbl i = wRead m₀ engArrTbl i := fun i =>
        (hwR engArrTbl (by decide) (by decide) i).trans
          ((hftAp engArrTbl (by decide) (by decide) i).trans (hw8_L engArrTbl (by decide) i))
      have hr_lt2_R : ∀ t < 2, ∀ i, rRead mR t i = rRead m₀ t i := fun t ht2 i =>
        (hrR t (by omega) i).trans ((hfrAp t i).trans (hr2_L t ht2 i))
      have hr20_R : rRead mR engRealTbl 0 = rRead m₀ engRealTbl 0 :=
        (hrR engRealTbl (by decide) 0).trans ((hfrAp engRealTbl 0).trans hr20_L)
      have hnd_other_R : ∀ mn' s', s' < M_slots cp → s' ≠ ns → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' mR :=
        fun mn' s' hs' hne he0 => hndR mn' s' hs' (hndAp mn' s' hs' (hnd_ulL mn' s' hs' hne he0))
      have henc_ulR : ops.EncNode u_leaf ns mR := hndR u_leaf ns hns_M henc_ulAp
      have hr15_R : wRead mR engScrTbl 15 = (ns : ℤ) := (hfsR 15 (by decide)).trans hr15_Ap
      have hserv_R : ∀ i (hi : i < (st₁.serving ++ [u_leaf]).length) (his : i < servSlots'.length),
          wRead mR engMetaTbl (servSlotOff i) = (servSlots'[i]'his : ℤ) ∧
          ops.EncNode ((st₁.serving ++ [u_leaf])[i]'hi) (servSlots'[i]'his) mR := by
        intro i hi his
        refine ⟨(hwR engMetaTbl (by decide) (by decide) _).trans (hservAp i his), ?_⟩
        by_cases hlt_s : i < st₁.serving.length
        · have hlt_sl : i < servSlots.length := hslen₀ ▸ hlt_s
          have hg1 : (st₁.serving ++ [u_leaf])[i]'hi = st₁.serving[i]'hlt_s :=
            List.getElem_append_left hlt_s
          have hg2 : servSlots'[i]'his = servSlots[i]'hlt_sl :=
            List.getElem_append_left hlt_sl
          have hs_in : servSlots[i]'hlt_sl ∈ servSlots := List.getElem_mem hlt_sl
          have hs_ne : servSlots[i]'hlt_sl ≠ ns :=
            fun heq => hns_fresh (heq ▸ List.mem_append_left _ hs_in)
          have hs_M : servSlots[i]'hlt_sl < M_slots cp :=
            hall_lt₀ _ (List.mem_append_left _ hs_in)
          rw [hg1, hg2]
          exact hnd_other_R _ _ hs_M hs_ne (hserv₀ i hlt_s hlt_sl).2
        · have hi_eq : i = st₁.serving.length := by simp at hi; omega
          have his_eq : i = servSlots.length := hslen₀.trans hi_eq.symm |>.symm
          have hg1 : (st₁.serving ++ [u_leaf])[i]'hi = u_leaf := by
            subst hi_eq; simp
          have hg2 : servSlots'[i]'his = ns := by
            dsimp only [servSlots']; subst his_eq; simp
          rw [hg1, hg2]; exact henc_ulR
      by_cases hres_le : u_leaf.resArr.length ≤ cp.B_scan
      · have hcT : (evalArithCond inp 0 mR (.intLe (.readHeap engScrTbl (.lit 27)) (.lit (cp.B_scan : ℤ)))).1 = true :=
          hcondRes.trans (decide_eq_true hres_le)
        have hst₂_eq : st₂ = { st₁ with
            serving := st₁.serving ++ [u_leaf]
            jobs := jobs₂
            leafArr := u_leaf.resArr
            leafOverflow := false } := by
          dsimp only [st₂, leafFinishStage2Pure]
          rw [if_pos htrig, if_pos (by simp [hserv_lt, hlf_le1])]
          change (if u_leaf0.resArr.length ≤ cp.B_scan then _ else _) = _
          rw [← hu_leaf_eq, if_pos hres_le, hu_leaf_eq]
        refine ExecDet.ite' (C_c := 8) (C_b := (80 + ops.C_read + cp.B_scan * (ops.C_read + 120)) + 12)
          _ _ _ hcT (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
          (by omega)
        refine ExecDet.seq (C₂ := 12)
          (exec_copyNodeResToLeafStmt ops inp 15 (by omega) (by omega) hns_M hfpR hsrR
            henc_ulR hr15_R hul_res_nd hul_res_lt_n hres_le) ?_
        intro mC ⟨hsrC, hlfC, hndC, hftC, hfmC, hfaC, _, hfrC⟩ hfpC
        refine ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 1) (.lit 0) 1 0 hfpC
          (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) ?_
        set mF := H3a.wWrite mC engMetaTbl 1 0
        have hw9_FC : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead mC t i :=
          fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))
        have hnd_FR : ∀ mn' s', s' < M_slots cp → ops.EncNode mn' s' mR → ops.EncNode mn' s' mF :=
          fun mn' s' hs' heR => ops.encNode_ext mn' s' mC mF (hndC mn' s' hs' heR) hw9_FC
            (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
        have hw_lt6_F : ∀ t < 6, ∀ i, wRead mF t i = wRead m₀ t i := fun t ht6 i =>
          (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))).trans
            ((hftC t (by omega) (by unfold engMetaTbl; omega) (by unfold engArrTbl; omega)
              (by unfold engScrTbl; omega) i).trans (hw_lt6_R t ht6 i))
        have hw6_F : ∀ i, i ≠ 0 → i ≠ 1 → i ≠ 2 → i ≠ servSlotOff servSlots.length →
            wRead mF engMetaTbl i = wRead m₀ engMetaTbl i := fun i h0 h1 h2 hs =>
          (wRead_wWrite_of_ne _ _ (Or.inr h1)).trans ((hfmC i h2).trans (hw6_R i h0 hs))
        have hr_lt2_F : ∀ t < 2, ∀ i, rRead mF t i = rRead m₀ t i := fun t ht2 i =>
          (rRead_wWrite _ _ _ _ _ _).trans ((hfrC t (by omega) i).trans (hr_lt2_R t ht2 i))
        have hr20_F : rRead mF engRealTbl 0 = rRead m₀ engRealTbl 0 :=
          (rRead_wWrite _ _ _ _ _ _).trans ((hfrC engRealTbl (by decide) 0).trans hr20_R)
        rw [hst₂_eq]
        refine ⟨⟨ops.slotsReady_ext mC mF hsrC hw9_FC (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
          ⟨(hw_lt6_F 0 (by decide) 4).trans hhp₀.1,
           (hw_lt6_F 0 (by decide) 5).trans hhp₀.2.1,
           (hw_lt6_F 0 (by decide) 6).trans hhp₀.2.2.1,
           fun i hi => (hw_lt6_F 1 (by decide) _).trans (hhp₀.2.2.2.1 i hi),
           fun i hi => ⟨(hw_lt6_F 2 (by decide) _).trans (hhp₀.2.2.2.2.1 i hi).1,
                        (hw_lt6_F 3 (by decide) _).trans (hhp₀.2.2.2.2.1 i hi).2⟩,
           fun x hx c => (hr_lt2_F ptsRTbl (by decide) _).trans (hhp₀.2.2.2.2.2 x hx c)⟩,
          encCachedAns_ext_345 hans₀ (hw_lt6_F 0 (by decide))
            (fun i hi => hw6_F i (by omega) (by omega) (by omega) (by unfold servSlotOff; omega))
            (hr_lt2_F 0 (by decide) 0) hr20_F,
          wRead_wWrite_self _ _ _ _,
          Nat.le_succ_of_le hres_le,
          hlfC.ext (wRead_wWrite_of_ne _ _ (Or.inr (by decide)))
            (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
            (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide))),
          by simp only [List.length_append, List.length_singleton]; omega,
          (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
            ((hfmC 0 (by decide)).trans
              ((hwR engMetaTbl (by decide) (by decide) 0).trans (by simp [hslen₀] at hw0Ap ⊢; exact hw0Ap))),
          servSlots', readySlots, curSlots,
          by simp [servSlots', hslen₀],
          fun i hi his => ⟨(wRead_wWrite_of_ne _ _ (Or.inr (by unfold servSlotOff; omega))).trans
            ((hfmC _ (by unfold servSlotOff; omega)).trans (hserv_R i hi his).1),
            hnd_FR _ _ (hall'.2 _ (List.mem_append_left _ (List.getElem_mem his))) (hserv_R i hi his).2⟩,
          fun r => encJobSlot_ext_jobsRegion (hjobs₀ r)
            (fun s hs => hall_lt₀ s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, hs⟩)))
            (fun k hk0 hk8 => by
              have hs_lt : servSlots.length < cp.D_max := hslen₀ ▸ hserv_lt
              exact hw6_F _ (by unfold jobMetaBase; omega) (by unfold jobMetaBase; omega)
                (by unfold jobMetaBase; omega) (by unfold jobMetaBase servSlotOff; omega))
            (fun q hq => by
              have hs_lt : servSlots.length < cp.D_max := hslen₀ ▸ hserv_lt
              have hnn : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) :=
                mul_nonneg (Int.natCast_nonneg _) (Int.natCast_nonneg _)
              exact hw6_F _ (by unfold readySlotOff; omega) (by unfold readySlotOff; omega)
                (by unfold readySlotOff; omega) (by unfold readySlotOff servSlotOff; omega))
            (fun i hi => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
              ((hfaC i hi).trans (hw7_R i)))
            (fun mn' s' hs' hmem_r he0 => hnd_FR mn' s' hs'
              (hnd_other_R mn' s' hs'
                (fun heq => hns_fresh (heq ▸ List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, hmem_r⟩)))
                he0)),
          hall'.1, hall'.2⟩,
          fun k => (hw_lt6_F coinTbl (by decide) _).trans (hcoins₀ k),
          hw_lt6_F 0 (by decide) 0⟩
      · have hcF : (evalArithCond inp 0 mR (.intLe (.readHeap engScrTbl (.lit 27)) (.lit (cp.B_scan : ℤ)))).1 = false :=
          hcondRes.trans (decide_eq_false hres_le)
        have hst₂_eq : st₂ = { st₁ with
            serving := st₁.serving ++ [u_leaf]
            jobs := jobs₂
            leafArr := []
            leafOverflow := true } := by
          dsimp only [st₂, leafFinishStage2Pure]
          rw [if_pos htrig, if_pos (by simp [hserv_lt, hlf_le1])]
          change (if u_leaf0.resArr.length ≤ cp.B_scan then _ else _) = _
          rw [← hu_leaf_eq, if_neg hres_le, hu_leaf_eq]
        refine ExecDet.ite' (C_c := 8) (C_b := 24)
          _ _ _ hcF (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
          (by omega)
        refine ExecDet.seq' 12
          (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 2) (.lit 0) 2 0 hfpR
            (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
          (by omega) ?_
        intro mC hmC hfpC; subst hmC
        refine ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 1) (.lit 1) 1 1 hfpC
          (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) ?_
        set mF := H3a.wWrite (H3a.wWrite mR engMetaTbl 2 0) engMetaTbl 1 1
        have hw9_FR : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead mR t i :=
          fun t ht9 _ i => (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))).trans
            (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega)))
        have hnd_FR : ∀ mn' s', s' < M_slots cp → ops.EncNode mn' s' mR → ops.EncNode mn' s' mF :=
          fun mn' s' _ heR => ops.encNode_ext mn' s' mR mF heR hw9_FR
            (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
            (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
        have hw_lt6_F : ∀ t < 6, ∀ i, wRead mF t i = wRead m₀ t i := fun t ht6 i =>
          (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))).trans
            ((wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))).trans (hw_lt6_R t ht6 i))
        have hw6_F : ∀ i, i ≠ 0 → i ≠ 1 → i ≠ 2 → i ≠ servSlotOff servSlots.length →
            wRead mF engMetaTbl i = wRead m₀ engMetaTbl i := fun i h0 h1 h2 hs =>
          (wRead_wWrite_of_ne _ _ (Or.inr h1)).trans
            ((wRead_wWrite_of_ne _ _ (Or.inr h2)).trans (hw6_R i h0 hs))
        have hr_lt2_F : ∀ t < 2, ∀ i, rRead mF t i = rRead m₀ t i := fun t ht2 i =>
          (rRead_wWrite _ _ _ _ _ _).trans ((rRead_wWrite _ _ _ _ _ _).trans (hr_lt2_R t ht2 i))
        have hr20_F : rRead mF engRealTbl 0 = rRead m₀ engRealTbl 0 :=
          (rRead_wWrite _ _ _ _ _ _).trans ((rRead_wWrite _ _ _ _ _ _).trans hr20_R)
        rw [hst₂_eq]
        refine ⟨⟨ops.slotsReady_ext mR mF hsrR hw9_FR
            (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _)),
          ⟨(hw_lt6_F 0 (by decide) 4).trans hhp₀.1,
           (hw_lt6_F 0 (by decide) 5).trans hhp₀.2.1,
           (hw_lt6_F 0 (by decide) 6).trans hhp₀.2.2.1,
           fun i hi => (hw_lt6_F 1 (by decide) _).trans (hhp₀.2.2.2.1 i hi),
           fun i hi => ⟨(hw_lt6_F 2 (by decide) _).trans (hhp₀.2.2.2.2.1 i hi).1,
                        (hw_lt6_F 3 (by decide) _).trans (hhp₀.2.2.2.2.1 i hi).2⟩,
           fun x hx c => (hr_lt2_F ptsRTbl (by decide) _).trans (hhp₀.2.2.2.2.2 x hx c)⟩,
          encCachedAns_ext_345 hans₀ (hw_lt6_F 0 (by decide))
            (fun i hi => hw6_F i (by omega) (by omega) (by omega) (by unfold servSlotOff; omega))
            (hr_lt2_F 0 (by decide) 0) hr20_F,
          wRead_wWrite_self _ _ _ _,
          Nat.zero_le _,
          encSparseSet_empty_of_zero
            ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _)),
          by simp only [List.length_append, List.length_singleton]; omega,
          (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
            ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
              ((hwR engMetaTbl (by decide) (by decide) 0).trans (by simp [hslen₀] at hw0Ap ⊢; exact hw0Ap))),
          servSlots', readySlots, curSlots,
          by simp [servSlots', hslen₀],
          fun i hi his => ⟨(wRead_wWrite_of_ne _ _ (Or.inr (by unfold servSlotOff; omega))).trans
            ((wRead_wWrite_of_ne _ _ (Or.inr (by unfold servSlotOff; omega))).trans (hserv_R i hi his).1),
            hnd_FR _ _ (hall'.2 _ (List.mem_append_left _ (List.getElem_mem his))) (hserv_R i hi his).2⟩,
          fun r => encJobSlot_ext_jobsRegion (hjobs₀ r)
            (fun s hs => hall_lt₀ s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, hs⟩)))
            (fun k hk0 hk8 => by
              have hs_lt : servSlots.length < cp.D_max := hslen₀ ▸ hserv_lt
              exact hw6_F _ (by unfold jobMetaBase; omega) (by unfold jobMetaBase; omega)
                (by unfold jobMetaBase; omega) (by unfold jobMetaBase servSlotOff; omega))
            (fun q hq => by
              have hs_lt : servSlots.length < cp.D_max := hslen₀ ▸ hserv_lt
              have hnn : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) :=
                mul_nonneg (Int.natCast_nonneg _) (Int.natCast_nonneg _)
              exact hw6_F _ (by unfold readySlotOff; omega) (by unfold readySlotOff; omega)
                (by unfold readySlotOff; omega) (by unfold readySlotOff servSlotOff; omega))
            (fun i _ => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
              ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hw7_R i)))
            (fun mn' s' hs' hmem_r he0 => hnd_FR mn' s' hs'
              (hnd_other_R mn' s' hs'
                (fun heq => hns_fresh (heq ▸ List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, hmem_r⟩)))
                he0)),
          hall'.1, hall'.2⟩,
          fun k => (hw_lt6_F coinTbl (by decide) _).trans (hcoins₀ k),
          hw_lt6_F 0 (by decide) 0⟩
    · have hext_F : (decide (st₁.serving.length < cp.D_max) && decide (st₁.leafArr.length ≤ cp.B_scan + 1)) = false :=
        Bool.eq_false_iff.mpr hext
      have hcondI_F : (evalArithCond inp 0 m₀ condInner).1 = false := hcondInner_eq.trans hext_F
      have hst₂_eq : st₂ = { st₁ with jobs := jobs₂, leafArr := [], leafOverflow := true } := by
        dsimp only [st₂, leafFinishStage2Pure]
        rw [if_pos htrig, if_neg (by rw [hext_F]; decide)]
      refine ExecDet.ite' (C_c := 16) (C_b := 24) _ _ _ hcondI_F
        (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
        (by unfold leafSpawnStage2Cost; omega)
      refine ExecDet.seq' 12
        (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 2) (.lit 0) 2 0 hfp₀
          (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
        (by omega) ?_
      intro mC hmC hfpC; subst hmC
      refine ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 1) (.lit 1) 1 1 hfpC
        (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) ?_
      set mF := H3a.wWrite (H3a.wWrite m₀ engMetaTbl 2 0) engMetaTbl 1 1
      have hw9_F : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead m₀ t i :=
        fun t ht9 _ i => (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))).trans
          (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega)))
      have hnd_F : ∀ mn' s', s' < M_slots cp → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' mF :=
        fun mn' s' _ he0 => ops.encNode_ext mn' s' m₀ mF he0 hw9_F
          (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
          (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
      have hw_ne6_F : ∀ t, t ≠ engMetaTbl → ∀ i, wRead mF t i = wRead m₀ t i := fun t ht i =>
        (wRead_wWrite_of_ne _ _ (Or.inl ht)).trans (wRead_wWrite_of_ne _ _ (Or.inl ht))
      have hw6_F : ∀ i, i ≠ 1 → i ≠ 2 → wRead mF engMetaTbl i = wRead m₀ engMetaTbl i := fun i h1 h2 =>
        (wRead_wWrite_of_ne _ _ (Or.inr h1)).trans (wRead_wWrite_of_ne _ _ (Or.inr h2))
      rw [hst₂_eq]
      exact ⟨⟨ops.slotsReady_ext m₀ mF hsr₀ hw9_F
          (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _)),
        ⟨(hw_ne6_F 0 (by decide) 4).trans hhp₀.1,
         (hw_ne6_F 0 (by decide) 5).trans hhp₀.2.1,
         (hw_ne6_F 0 (by decide) 6).trans hhp₀.2.2.1,
         fun i hi => (hw_ne6_F 1 (by decide) _).trans (hhp₀.2.2.2.1 i hi),
         fun i hi => ⟨(hw_ne6_F 2 (by decide) _).trans (hhp₀.2.2.2.2.1 i hi).1,
                      (hw_ne6_F 3 (by decide) _).trans (hhp₀.2.2.2.2.1 i hi).2⟩,
         fun x hx c => ((rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _)).trans (hhp₀.2.2.2.2.2 x hx c)⟩,
        encCachedAns_ext_345 hans₀ (hw_ne6_F 0 (by decide))
          (fun i hi => hw6_F i (by omega) (by omega))
          ((rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
          ((rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _)),
        wRead_wWrite_self _ _ _ _,
        Nat.zero_le _,
        encSparseSet_empty_of_zero
          ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _)),
        hserv_le₀,
        (hw6_F 0 (by decide) (by decide)).trans hserv_len₀,
        servSlots, readySlots, curSlots, hslen₀,
        fun i hi his => ⟨(hw6_F _ (by unfold servSlotOff; omega) (by unfold servSlotOff; omega)).trans
          (hserv₀ i hi his).1,
          hnd_F _ _ (hall_lt₀ _ (List.mem_append_left _ (List.getElem_mem his))) (hserv₀ i hi his).2⟩,
        fun r => encJobSlot_ext_jobsRegion (hjobs₀ r)
          (fun s hs => hall_lt₀ s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, hs⟩)))
          (fun k hk0 hk8 => hw6_F _ (by unfold jobMetaBase; omega) (by unfold jobMetaBase; omega))
          (fun q _ => by
            have hnn : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) :=
              mul_nonneg (Int.natCast_nonneg _) (Int.natCast_nonneg _)
            exact hw6_F _ (by unfold readySlotOff; omega) (by unfold readySlotOff; omega))
          (fun i _ => hw_ne6_F engArrTbl (by decide) i)
          (fun mn' s' hs' _ he0 => hnd_F mn' s' hs' he0),
        hall_nd₀, hall_lt₀⟩,
        fun k => (hw_ne6_F coinTbl (by decide) _).trans (hcoins₀ k),
        hw_ne6_F 0 (by decide) 0⟩
  · have htrig_F : (!st₁.leafOverflow && decide (cp.B_scan < st₁.leafArr.length)) = false :=
      Bool.eq_false_iff.mpr htrig
    have hcondO_F : (evalArithCond inp 0 m₀ condOuter).1 = false := hcondOuter_eq.trans htrig_F
    have hst₂_eq : st₂ = { st₁ with jobs := jobs₂ } := by
      dsimp only [st₂, leafFinishStage2Pure]
      rw [if_neg htrig]
    refine ExecDet.ite' (C_c := 16) (C_b := 1) _ _ _ hcondO_F
      (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
      (by unfold leafSpawnStage2Cost; omega)
    refine ExecDet.skip inp hfp₀ ?_ le_rfl
    rw [hst₂_eq]
    exact ⟨⟨hsr₀, hhp₀, hans₀, hov₀, hlf_le₀, hlf_sp₀, hserv_le₀, hserv_len₀,
      servSlots, readySlots, curSlots, hslen₀, hserv₀, hjobs₀, hall_nd₀, hall_lt₀⟩, hcoins₀, rfl⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG15_Stage2
