import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2B1
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 9a. Shared `.build` Completion Footer (`finishBuildToCopyStmt` & Postcondition Helper) -/

/-- Shared 5-write footer transitioning finished `.build` job `r` to `.copy (CopyState.init L)`
with commit status code `codeVal ∈ {0, 2, 3}` in `engScrTbl[10]` (leaving `base + 7` untouched!). -/
def finishBuildToCopyStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) (LExpr : IntExpr) (codeVal : ℤ) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  .seq (.writeWordHeap engMetaTbl (.lit (base + 2)) (.lit 0))
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 3)) LExpr)
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 4)) (.lit 0))
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 5)) (.lit 0))
        (.writeWordHeap engScrTbl (.lit 10) (.lit codeVal)))))

theorem zeroRand_finishBuildToCopyStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) (LExpr : IntExpr) (codeVal : ℤ) :
    ZeroRandStmt (finishBuildToCopyStmt cp r LExpr codeVal) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))

theorem exec_finishBuildToCopyStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max) (LExpr : IntExpr) (LVal : ℕ) (codeVal : ℤ)
    (m₀ : ArithRAMMemory)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (_hLEval : (evalIntExpr inp.toWordView 0 m₀.words LExpr).1 = (LVal : ℤ))
    (hLOps : intExprOps LExpr ≤ 4)
    (hLMeta : (evalIntExpr inp.toWordView 0
      (H3a.wWrite m₀ engMetaTbl (jobMetaBase cp r.val + 2) 0).words LExpr).1 = (LVal : ℤ)) :
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (finishBuildToCopyStmt cp r LExpr codeVal) m₀
      (fun mF =>
        mF = H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m₀
          engMetaTbl (jobMetaBase cp r.val + 2) 0)
          engMetaTbl (jobMetaBase cp r.val + 3) (LVal : ℤ))
          engMetaTbl (jobMetaBase cp r.val + 4) 0)
          engMetaTbl (jobMetaBase cp r.val + 5) 0)
          engScrTbl 10 codeVal)
      80 := by
  have hTW := ops.hTW; have hBW_meta := ops.hBW_meta; have hBW_scr := ops.hBW_scr
  let base := jobMetaBase cp r.val
  have hmeta_b : 16 + cp.D_max + 8 * r.val + 8 ≤ ops.BW := by
    have hr_lt := r.isLt; have hD2 : 0 ≤ cp.D_max * cp.D_max := Nat.zero_le _
    nlinarith only [hr_lt, hBW_meta, hD2]
  unfold finishBuildToCopyStmt
  refine ExecDet.seq' 68
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 2)) (.lit 0)
      (base + 2) 0 hfp₀ (by unfold engMetaTbl; omega) (by simp only [base, jobMetaBase]; omega)
      (by simp only [base, jobMetaBase]; omega) rfl rfl (by simp [intExprOps]) rfl) (by omega) ?_
  intro m1 hm1 hfp1; subst hm1
  refine ExecDet.seq' 50
    (ExecDet.wWrite (C := 18) inp engMetaTbl (.lit (base + 3)) LExpr
      (base + 3) (LVal : ℤ) hfp1 (by unfold engMetaTbl; omega) (by simp only [base, jobMetaBase]; omega)
      (by simp only [base, jobMetaBase]; omega) rfl hLMeta (by simp [intExprOps]; omega) rfl) (by omega) ?_
  intro m2 hm2 hfp2; subst hm2
  refine ExecDet.seq' 36
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 4)) (.lit 0)
      (base + 4) 0 hfp2 (by unfold engMetaTbl; omega) (by simp only [base, jobMetaBase]; omega)
      (by simp only [base, jobMetaBase]; omega) rfl rfl (by simp [intExprOps]) rfl) (by omega) ?_
  intro m3 hm3 hfp3; subst hm3
  refine ExecDet.seq' 20
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 5)) (.lit 0)
      (base + 5) 0 hfp3 (by unfold engMetaTbl; omega) (by simp only [base, jobMetaBase]; omega)
      (by simp only [base, jobMetaBase]; omega) rfl rfl (by simp [intExprOps]) rfl) (by omega) ?_
  intro m4 hm4 hfp4; subst hm4
  exact ExecDet.wWrite inp engScrTbl (.lit 10) (.lit codeVal) 10 codeVal
    hfp4 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
    rfl rfl (by simp [intExprOps]) rfl

/-- Shared invariant-packaging lemma for Cases B2, B3, and B4 after `finishBuildToCopyStmt`. -/
theorem finishBuildToCopy_post {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (r : Fin cp.D_max)
    {jb : SuffixJob cp} {bs : BuildState cp} {u_done : MNode cp}
    {servSlots : List ℕ}
    {curJobs : Fin cp.D_max → Option (SuffixJob cp)}
    {readySlots : Fin cp.D_max → List ℕ}
    {curSlots : Fin cp.D_max → ℕ}
    {m₀ mL mR mPre : ArithRAMMemory}
    (LVal : ℕ) (codeVal : ℤ)
    (hphase : jb.phase = .build bs)
    (hcur_r : curJobs r = some jb)
    (hrs_lt : r.val + jb.ready.length < cp.D_max)
    (hact1 : wRead m₀ engMetaTbl (jobMetaBase cp r.val) = 1)
    (hr_len : (readySlots r).length = jb.ready.length)
    (hready_enc : ∀ q (hq : q < jb.ready.length) (hqs : q < (readySlots r).length),
      wRead m₀ engMetaTbl (readySlotOff cp r.val q) = ((readySlots r)[q]'hqs : ℤ) ∧
      ops.EncNode (jb.ready[q]'hq) ((readySlots r)[q]'hqs) m₀)
    (hw_cslot : wRead m₀ engMetaTbl (jobMetaBase cp r.val + 7) = (curSlots r : ℤ))
    (hjobs_enc : ∀ r' : Fin cp.D_max,
      EncJobSlot ops r' (curJobs r') (readySlots r') (curSlots r') m₀)
    (hall_nd : (servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r'))).Nodup)
    (hall_lt : ∀ s ∈ servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r')), s < M_slots cp)
    (hcSlot_M : curSlots r < M_slots cp)
    (hq_ne_cSlot : ∀ q (hqs : q < (readySlots r).length), (readySlots r)[q]'hqs ≠ curSlots r)
    (hother_ne_cSlot : ∀ s,
      s ∈ servSlots ++ (List.finRange cp.D_max).flatMap (fun r' =>
        if r' = r then [] else jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) →
      s ≠ curSlots r)
    (henc_uL : ops.EncNode u_done (curSlots r) mL)
    (hndL : ∀ mn' s, s < M_slots cp → s ≠ curSlots r → ops.EncNode mn' s m₀ → ops.EncNode mn' s mL)
    (hftL : ∀ t < 9, t ≠ engMetaTbl → t ≠ engScrTbl → ∀ i, wRead mL t i = wRead m₀ t i)
    (hfmL : ∀ i, i ≠ jobMetaBase cp r.val + 4 → wRead mL engMetaTbl i = wRead m₀ engMetaTbl i)
    (hfsL : ∀ i, i < 18 → wRead mL engScrTbl i = wRead m₀ engScrTbl i)
    (hfrL : ∀ t < 3, ∀ i, rRead mL t i = rRead m₀ t i)
    (hndR : ∀ mn' s, s < M_slots cp → ops.EncNode mn' s (H3a.wWrite (H3a.wWrite mL
      engMetaTbl (readySlotOff cp r.val jb.ready.length) (curSlots r : ℤ))
      engMetaTbl (jobMetaBase cp r.val + 1) (((jb.ready ++ [u_done]).length : ℕ) : ℤ)) →
      ops.EncNode mn' s mR)
    (hftR : ∀ t < 9, t ≠ engScrTbl → ∀ i, wRead mR t i = wRead (H3a.wWrite (H3a.wWrite mL
      engMetaTbl (readySlotOff cp r.val jb.ready.length) (curSlots r : ℤ))
      engMetaTbl (jobMetaBase cp r.val + 1) (((jb.ready ++ [u_done]).length : ℕ) : ℤ)) t i)
    (hfsR : ∀ i, i ≠ 19 → wRead mR engScrTbl i = wRead (H3a.wWrite (H3a.wWrite mL
      engMetaTbl (readySlotOff cp r.val jb.ready.length) (curSlots r : ℤ))
      engMetaTbl (jobMetaBase cp r.val + 1) (((jb.ready ++ [u_done]).length : ℕ) : ℤ)) engScrTbl i)
    (hfrR : ∀ t < 3, ∀ i, rRead mR t i = rRead (H3a.wWrite (H3a.wWrite mL
      engMetaTbl (readySlotOff cp r.val jb.ready.length) (curSlots r : ℤ))
      engMetaTbl (jobMetaBase cp r.val + 1) (((jb.ready ++ [u_done]).length : ℕ) : ℤ)) t i)
    (hsrP : ops.SlotsReady mPre)
    (hndP : ∀ mn' s, s < M_slots cp → ops.EncNode mn' s mR → ops.EncNode mn' s mPre)
    (hftP : ∀ t < 9, t ≠ engScrTbl → ∀ i, wRead mPre t i = wRead mR t i)
    (hfsP : ∀ i, i ≠ 19 → wRead mPre engScrTbl i = wRead mR engScrTbl i)
    (hfrP : ∀ t < 3, ∀ i, rRead mPre t i = rRead mR t i) :
    let newReady := jb.ready ++ [u_done]
    let newRSlots := readySlots r ++ [curSlots r]
    let mF := H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite mPre
      engMetaTbl ((jobMetaBase cp r.val) + 2) 0) engMetaTbl ((jobMetaBase cp r.val) + 3) (LVal : ℤ))
      engMetaTbl ((jobMetaBase cp r.val) + 4) 0) engMetaTbl ((jobMetaBase cp r.val) + 5) 0) engScrTbl 10 codeVal
    let outJb : SuffixJob cp := { ready := newReady, phase := .copy (CopyState.init LVal) }
    ops.SlotsReady mF ∧
    (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead mF t i = wRead m₀ t i) ∧
    (∀ i, ¬ InJobMetaRegion cp r.val i → wRead mF engMetaTbl i = wRead m₀ engMetaTbl i) ∧
    (∀ i, ¬ InJobArrRegion cp r.val i → wRead mF engArrTbl i = wRead m₀ engArrTbl i) ∧
    (∀ i, i < 10 → wRead mF engScrTbl i = wRead m₀ engScrTbl i) ∧
    (∀ t < 2, ∀ i, rRead mF t i = rRead m₀ t i) ∧
    rRead mF engRealTbl 0 = rRead m₀ engRealTbl 0 ∧
    (∀ mn' s, s < M_slots cp →
      s ∈ servSlots ++ (List.finRange cp.D_max).flatMap (fun r' =>
        if r' = r then [] else jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) →
      ops.EncNode mn' s m₀ → ops.EncNode mn' s mF) ∧
    EncJobSlot ops r (some outJb) newRSlots 0 mF ∧
    (∀ r' : Fin cp.D_max, EncJobSlot ops r'
      (Function.update curJobs r (some outJb) r')
      (Function.update readySlots r newRSlots r')
      (Function.update curSlots r 0 r') mF) ∧
    (servSlots ++ (List.finRange cp.D_max).flatMap (fun r' =>
      jobUsedSlots (Function.update curJobs r (some outJb) r')
        (Function.update readySlots r newRSlots r')
        (Function.update curSlots r 0 r'))).Nodup ∧
    (∀ s ∈ servSlots ++ (List.finRange cp.D_max).flatMap (fun r' =>
      jobUsedSlots (Function.update curJobs r (some outJb) r')
        (Function.update readySlots r newRSlots r')
        (Function.update curSlots r 0 r')), s < M_slots cp) ∧
    wRead mF engScrTbl 10 = codeVal ∧
    wRead mF engMetaTbl ((jobMetaBase cp r.val) + 7) = (curSlots r : ℤ) ∧
    ops.EncNode u_done (curSlots r) mF := by
  intro newReady newRSlots mF outJb
  let cSlot := curSlots r
  set mA := H3a.wWrite (H3a.wWrite mL
    engMetaTbl (readySlotOff cp r.val jb.ready.length) (cSlot : ℤ))
    engMetaTbl ((jobMetaBase cp r.val) + 1) ((newReady.length : ℕ) : ℤ)
  have hnew_len : newReady.length = jb.ready.length + 1 := by simp [newReady]
  have hnew_slen : newRSlots.length = newReady.length := by simp [newRSlots, newReady, hr_len]
  have hnew_le_D : newReady.length ≤ cp.D_max := by omega
  have hnn_rD : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) := by exact_mod_cast Nat.zero_le (r.val * cp.D_max)
  have hw9_AL : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mA t i = wRead mL t i := by
    intro t ht9 _ i; simp only [mA, wRead_wWrite_eq]
    have : t ≠ engMetaTbl := by unfold engMetaTbl; omega
    simp [this]
  have hw9_FP : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead mPre t i := by
    intro t ht9 _ i; simp only [mF, wRead_wWrite_eq]
    have : t ≠ engScrTbl ∧ t ≠ engMetaTbl := ⟨by unfold engScrTbl; omega, by unfold engMetaTbl; omega⟩
    simp [this]
  have hr_FP : ∀ t i, rRead mF t i = rRead mPre t i := fun t i => by simp [mF, rRead_wWrite]
  have hnd_LF : ∀ mn' s, s < M_slots cp → ops.EncNode mn' s mL → ops.EncNode mn' s mF := by
    intro mn' s hs heL
    have heA : ops.EncNode mn' s mA := ops.encNode_ext mn' s mL mA heL hw9_AL
      (fun _ _ _ _ => by simp [mA, rRead_wWrite]) (fun _ _ _ _ => by simp [mA, rRead_wWrite])
    exact ops.encNode_ext mn' s mPre mF (hndP mn' s hs (hndR mn' s hs heA)) hw9_FP
      (fun t _ _ i => hr_FP t i) (fun _ _ _ _ => hr_FP ptsRTbl _)
  have hmeta_PA : ∀ i, wRead mPre engMetaTbl i = wRead mA engMetaTbl i :=
    fun i => (hftP engMetaTbl (by decide) (by decide) i).trans (hftR engMetaTbl (by decide) (by decide) i)
  have hfmF_job : ∀ i, ¬ InJobMetaRegion cp r.val i → wRead mF engMetaTbl i = wRead m₀ engMetaTbl i := by
    intro i hni
    have hnb : ¬ ((jobMetaBase cp r.val) ≤ i ∧ i < (jobMetaBase cp r.val) + 8) := fun hb => hni (Or.inl hb)
    have hnr : ¬ (readySlotOff cp r.val 0 ≤ i ∧ i < readySlotOff cp r.val 0 + (cp.D_max : ℤ)) :=
      fun hr => hni (Or.inr hr)
    have hir_ne : i ≠ readySlotOff cp r.val jb.ready.length := by
      intro he; apply hnr; rw [he]; unfold readySlotOff; omega
    simp only [mF, wRead_wWrite_eq]
    have : i ≠ (jobMetaBase cp r.val) + 5 ∧ i ≠ (jobMetaBase cp r.val) + 4 ∧ i ≠ (jobMetaBase cp r.val) + 3 ∧ i ≠ (jobMetaBase cp r.val) + 2 := by omega
    simp [engMetaTbl, engScrTbl, this]
    rw [hmeta_PA i]; simp only [mA, wRead_wWrite_eq]
    have : i ≠ (jobMetaBase cp r.val) + 1 := by omega
    simp [this, hir_ne]
    exact hfmL i (by omega)
  have hfaF_job : ∀ i, ¬ InJobArrRegion cp r.val i → wRead mF engArrTbl i = wRead m₀ engArrTbl i := by
    intro i _
    simp only [mF, wRead_wWrite_eq]; simp [engArrTbl, engMetaTbl, engScrTbl]
    rw [hftP engArrTbl (by decide) (by decide) i, hftR engArrTbl (by decide) (by decide) i]
    simp only [mA, wRead_wWrite_eq]; simp [engArrTbl, engMetaTbl]
    exact hftL engArrTbl (by decide) (by decide) (by decide) i
  have henc_out : EncJobSlot ops r (some outJb) newRSlots 0 mF := by
    simp only [EncJobSlot, outJb]
    refine ⟨?_, hnew_le_D, hnew_slen, ?_, fun q hq hqs => ?_,
      by simp [mF, wRead_wWrite_eq, engMetaTbl, engScrTbl],
      by simp [mF, wRead_wWrite_eq, engMetaTbl, engScrTbl, CopyState.init],
      by simp [mF, wRead_wWrite_eq, engMetaTbl, engScrTbl, CopyState.init],
      encSparseSet_empty_of_zero (by simp [mF, wRead_wWrite_eq, engMetaTbl, engScrTbl])⟩
    · simp only [mF, wRead_wWrite_eq]
      have : (jobMetaBase cp r.val) ≠ (jobMetaBase cp r.val) + 5 ∧ (jobMetaBase cp r.val) ≠ (jobMetaBase cp r.val) + 4 ∧ (jobMetaBase cp r.val) ≠ (jobMetaBase cp r.val) + 3 ∧ (jobMetaBase cp r.val) ≠ (jobMetaBase cp r.val) + 2 := by omega
      simp [engMetaTbl, engScrTbl, this, hmeta_PA (jobMetaBase cp r.val)]
      simp only [mA, wRead_wWrite_eq]
      have hne_rs : (jobMetaBase cp r.val) ≠ readySlotOff cp r.val jb.ready.length := by
        have := r.isLt; simp only [jobMetaBase, readySlotOff]; omega
      have hne_b1 : (jobMetaBase cp r.val) ≠ (jobMetaBase cp r.val) + 1 := by omega
      simp [hne_b1, hne_rs]; exact (hfmL (jobMetaBase cp r.val) (by omega)).trans hact1
    · simp only [mF, wRead_wWrite_eq]
      have : (jobMetaBase cp r.val) + 1 ≠ (jobMetaBase cp r.val) + 5 ∧ (jobMetaBase cp r.val) + 1 ≠ (jobMetaBase cp r.val) + 4 ∧ (jobMetaBase cp r.val) + 1 ≠ (jobMetaBase cp r.val) + 3 ∧ (jobMetaBase cp r.val) + 1 ≠ (jobMetaBase cp r.val) + 2 := by omega
      simp [engMetaTbl, engScrTbl, this, hmeta_PA ((jobMetaBase cp r.val) + 1)]
      simp [mA, wRead_wWrite_eq]
    · have hrd_ne : readySlotOff cp r.val q ≠ (jobMetaBase cp r.val) + 5 ∧ readySlotOff cp r.val q ≠ (jobMetaBase cp r.val) + 4 ∧
          readySlotOff cp r.val q ≠ (jobMetaBase cp r.val) + 3 ∧ readySlotOff cp r.val q ≠ (jobMetaBase cp r.val) + 2 ∧
          readySlotOff cp r.val q ≠ (jobMetaBase cp r.val) + 1 := by
        have := r.isLt; simp only [readySlotOff, jobMetaBase]; omega
      have hw_rq : wRead mF engMetaTbl (readySlotOff cp r.val q) =
          wRead mA engMetaTbl (readySlotOff cp r.val q) := by
        simp only [mF, wRead_wWrite_eq]
        simp [engMetaTbl, engScrTbl, hrd_ne.1, hrd_ne.2.1, hrd_ne.2.2.1, hrd_ne.2.2.2.1, hmeta_PA]
      rw [hw_rq]
      by_cases hq_old : q < jb.ready.length
      · have hqs_old : q < (readySlots r).length := hr_len ▸ hq_old
        have hne_last : readySlotOff cp r.val q ≠ readySlotOff cp r.val jb.ready.length := by
          unfold readySlotOff; omega
        have hget_nd : newReady[q]'hq = jb.ready[q]'hq_old := List.getElem_append_left hq_old
        have hget_sl : newRSlots[q]'hqs = (readySlots r)[q]'hqs_old := List.getElem_append_left hqs_old
        have hq_M : (readySlots r)[q]'hqs_old < M_slots cp := hall_lt _
          (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, by
            simp only [hcur_r, jobUsedSlots, hphase]; exact List.mem_append_left _ (List.getElem_mem hqs_old)⟩))
        rw [hget_nd, hget_sl]
        refine ⟨?_, hnd_LF _ _ hq_M (hndL _ _ hq_M (hq_ne_cSlot q hqs_old) (hready_enc q hq_old hqs_old).2)⟩
        simp only [mA, wRead_wWrite_eq]; simp [hrd_ne.2.2.2.2, hne_last]
        exact (hfmL _ hrd_ne.2.1).trans (hready_enc q hq_old hqs_old).1
      · have hq_eq : q = jb.ready.length := by omega
        have hget_nd : newReady[q]'hq = u_done := by
          subst hq_eq; simp [newReady]
        have hget_sl : newRSlots[q]'hqs = cSlot := by
          have hqs_eq : q = (readySlots r).length := hr_len.trans hq_eq.symm |>.symm
          subst hqs_eq; simp [newRSlots, cSlot]
        rw [hget_nd, hget_sl]
        refine ⟨?_, hnd_LF u_done cSlot hcSlot_M henc_uL⟩
        subst hq_eq; simp only [mA, wRead_wWrite_eq]; simp [hrd_ne.2.2.2.2]
  have hall_eq : (List.finRange cp.D_max).flatMap (fun r' =>
      jobUsedSlots (Function.update curJobs r (some outJb) r')
        (Function.update readySlots r newRSlots r')
        (Function.update curSlots r 0 r')) =
      (List.finRange cp.D_max).flatMap (fun r' =>
        jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) := by
    congr 1; ext r'
    by_cases heq : r' = r
    · subst heq; simp [Function.update_self, hcur_r, outJb, newRSlots, cSlot, jobUsedSlots, hphase]
    · simp [Function.update_of_ne heq]
  have hw_b7 : wRead mF engMetaTbl ((jobMetaBase cp r.val) + 7) = (cSlot : ℤ) := by
    simp only [mF, wRead_wWrite_eq]
    have : (jobMetaBase cp r.val) + 7 ≠ (jobMetaBase cp r.val) + 5 ∧ (jobMetaBase cp r.val) + 7 ≠ (jobMetaBase cp r.val) + 4 ∧ (jobMetaBase cp r.val) + 7 ≠ (jobMetaBase cp r.val) + 3 ∧ (jobMetaBase cp r.val) + 7 ≠ (jobMetaBase cp r.val) + 2 := by omega
    simp [engMetaTbl, engScrTbl, this, hmeta_PA ((jobMetaBase cp r.val) + 7)]
    simp only [mA, wRead_wWrite_eq]
    have hne1 : (jobMetaBase cp r.val) + 7 ≠ (jobMetaBase cp r.val) + 1 := by omega
    have hne2 : (jobMetaBase cp r.val) + 7 ≠ readySlotOff cp r.val jb.ready.length := by
      have := r.isLt; simp only [jobMetaBase, readySlotOff]; omega
    simp [hne1, hne2]
    exact (hfmL ((jobMetaBase cp r.val) + 7) (by omega)).trans hw_cslot
  refine ⟨ops.slotsReady_ext mPre mF hsrP hw9_FP (fun t _ _ i => hr_FP t i),
    fun t ht9 ht1 _ ht3 i => by
      simp only [mF, wRead_wWrite_eq]; simp [ht1, ht3]
      rw [hftP t ht9 ht3 i, hftR t ht9 ht3 i]
      simp only [mA, wRead_wWrite_eq]; simp [ht1]
      exact hftL t ht9 ht1 ht3 i,
    hfmF_job, hfaF_job,
    fun i hi10 => by
      simp only [mF, wRead_wWrite_eq]
      have : i ≠ 10 := by omega
      simp [engScrTbl, engMetaTbl, this]
      rw [hfsP i (by omega), hfsR i (by omega)]
      simp only [mA, wRead_wWrite_eq]; simp [engScrTbl, engMetaTbl]
      exact hfsL i (by omega),
    fun t ht2 i => (hr_FP t i).trans ((hfrP t (by omega) i).trans
      ((hfrR t (by omega) i).trans (by simp only [mA, rRead_wWrite]; exact hfrL t (by omega) i))),
    (hr_FP engRealTbl 0).trans ((hfrP engRealTbl (by decide) 0).trans
      ((hfrR engRealTbl (by decide) 0).trans (by simp only [mA, rRead_wWrite]; exact hfrL engRealTbl (by decide) 0))),
    fun mn' s hs hmem_other he0 => hnd_LF mn' s hs (hndL mn' s hs (hother_ne_cSlot s hmem_other) he0),
    henc_out,
    fun r' => by
      by_cases heq : r' = r
      · subst heq; simp only [Function.update_self]; exact henc_out
      · simp only [Function.update_of_ne heq]
        exact encJobSlot_other_of_frame heq (hjobs_enc r')
          (fun s hs => hall_lt s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r', hs⟩)))
          hfmF_job hfaF_job (fun mn' s hs hmem_r' he0 =>
            hnd_LF mn' s hs (hndL mn' s hs (hother_ne_cSlot s (List.mem_append_right _
              (flatMap_mem_iff_finRange.mpr ⟨r', by simp [if_neg heq, hmem_r']⟩))) he0)),
    by rwa [hall_eq],
    by rwa [hall_eq],
    wRead_wWrite_self _ _ _ _, hw_b7, hnd_LF u_done cSlot hcSlot_M henc_uL⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
