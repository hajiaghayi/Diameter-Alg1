import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Layout
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2A0
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Stage4PrimB
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
open UL.Proof.clm_9_1_explicit_tradeoff.CG20

/-! ### 1. Pure Serving-Dense Invariant & Sublist Slot Preservation -/

/-- Minimal pure invariant on `cur.serving` needed to execute `stepStage3` on RAM:
every serving node's `denseArr` is duplicate-free with handles `< cp.n`. -/
def ServingDenseWF {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (cur : ChainEngineState cp) : Prop :=
  ∀ mn ∈ cur.serving, mn.nd.denseArr.Nodup ∧ (∀ x ∈ mn.nd.denseArr, x < cp.n)

theorem servingDenseWF_of_postStage2WF {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {P' : DynamicPointSet d} {st₂ : ChainEngineState cp}
    (hwf₂ : PostStage2WF cp P' st₂) :
    ServingDenseWF cp st₂ := by
  intro mn hmn
  rcases List.mem_iff_getElem.mp hmn with ⟨i, hi, rfl⟩
  rcases (chainListInv_getElem P'.activeHandles st₂.serving (Finset.Subset.refl _) hwf₂.2.2.2.1).2 i hi
    with ⟨hS_sub, hln⟩
  refine ⟨hln.2.2.2.2.2.2.2.1.1, fun x hx => ?_⟩
  have hx_cur : x ∈ (st₂.serving[i]'hi).nd.curSet := List.mem_toFinset.mpr hx
  have hx_act : x ∈ P'.activeHandles := hS_sub (hln.1 ▸ hx_cur)
  exact (handle_lt_nextFresh_of_mem_act hwf₂.1 hx_act).2

theorem servingDenseWF_of_chainEngineWF {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {P : DynamicPointSet d} {st : ChainEngineState cp}
    (hwf : ChainEngineWF cp P st) :
    ServingDenseWF cp st := by
  intro mn hmn
  rcases List.mem_iff_getElem.mp hmn with ⟨i, hi, rfl⟩
  rcases (chainListInv_getElem P.activeHandles st.serving (Finset.Subset.refl _) hwf.2.2.2.1).2 i hi
    with ⟨hS_sub, hln⟩
  refine ⟨hln.2.2.2.2.2.2.2.1.1, fun x hx => ?_⟩
  have hx_cur : x ∈ (st.serving[i]'hi).nd.curSet := List.mem_toFinset.mpr hx
  have hx_act : x ∈ P.activeHandles := hS_sub (hln.1 ▸ hx_cur)
  exact (handle_lt_nextFresh_of_mem_act hwf.1 hx_act).2

theorem servingDenseWF_stage3At {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {cur : ChainEngineState cp} (r : Fin cp.D_max)
    (hsd : ServingDenseWF cp cur) :
    ServingDenseWF cp (stage3At cp cur r) := by
  unfold stage3At
  split_ifs with hr
  · cases cur.jobs r with
    | some _ => exact hsd
    | none =>
        dsimp only
        split_ifs
        · intro mn hmn
          exact hsd mn (List.mem_of_mem_take hmn)
        · exact hsd
        · exact hsd
  · exact hsd

private theorem flatMap_sublist_of_sublist {α β : Type*} {f g : α → List β} :
    ∀ (xs : List α), (∀ x ∈ xs, (f x).Sublist (g x)) → (xs.flatMap f).Sublist (xs.flatMap g)
  | [], _ => List.Sublist.slnil
  | x :: tl, h => by
      simp only [List.flatMap_cons]
      exact List.Sublist.append (h x List.mem_cons_self)
        (flatMap_sublist_of_sublist tl (fun y hy => h y (List.mem_cons_of_mem x hy)))

theorem allSlots_truncate_nodup_lt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    {jobs : Fin cp.D_max → Option (SuffixJob cp)}
    {servSlots : List ℕ} {readySlots : Fin cp.D_max → List ℕ} {curSlots : Fin cp.D_max → ℕ}
    (r : Fin cp.D_max)
    (hnd : (servSlots ++
      (List.finRange cp.D_max).flatMap (fun rr => jobUsedSlots (jobs rr) (readySlots rr) (curSlots rr))).Nodup)
    (hlt : ∀ s ∈ servSlots ++
      (List.finRange cp.D_max).flatMap (fun rr => jobUsedSlots (jobs rr) (readySlots rr) (curSlots rr)),
      s < M_slots cp) :
    let jobs' : Fin cp.D_max → Option (SuffixJob cp) :=
      fun rr => if rr.val < r.val then jobs rr else none
    let readySlots' : Fin cp.D_max → List ℕ :=
      fun rr => if rr.val < r.val then readySlots rr else []
    let all' := servSlots.take r.val ++
      (List.finRange cp.D_max).flatMap (fun rr => jobUsedSlots (jobs' rr) (readySlots' rr) (curSlots rr))
    all'.Nodup ∧ (∀ s ∈ all', s < M_slots cp) := by
  intro jobs' readySlots' all'
  have hsub_flat :
      ((List.finRange cp.D_max).flatMap
        (fun rr => jobUsedSlots (jobs' rr) (readySlots' rr) (curSlots rr))).Sublist
      ((List.finRange cp.D_max).flatMap
        (fun rr => jobUsedSlots (jobs rr) (readySlots rr) (curSlots rr))) := by
    refine flatMap_sublist_of_sublist _ (fun rr _ => ?_)
    dsimp only [jobs', readySlots']
    split_ifs
    · exact List.Sublist.refl _
    · exact List.nil_sublist _
  have hsub : all'.Sublist (servSlots ++
      (List.finRange cp.D_max).flatMap (fun rr => jobUsedSlots (jobs rr) (readySlots rr) (curSlots rr))) :=
    List.Sublist.append (List.take_sublist r.val servSlots) hsub_flat
  exact ⟨hnd.sublist hsub, fun s hs => hlt s (hsub.subset hs)⟩

/-! ### 2. Address Bounds & Localized Frame Lemmas -/

theorem jobMetaBase_bounds {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (r : Fin cp.D_max) {j : ℤ} (hj0 : 0 ≤ j) (hj7 : j ≤ 7) :
    0 ≤ jobMetaBase cp r.val + j ∧ jobMetaBase cp r.val + j < (ops.BW : ℤ) := by
  have hr := r.isLt
  have hmeta_nat : 16 + cp.D_max + 8 * r.val + 8 ≤ ops.BW := by
    have hbw := ops.hBW_meta
    have hdd : 0 ≤ cp.D_max * cp.D_max := Nat.zero_le _
    omega
  have hmeta_int : (16 : ℤ) + (cp.D_max : ℤ) + 8 * (r.val : ℤ) + 8 ≤ (ops.BW : ℤ) := by
    exact_mod_cast hmeta_nat
  unfold jobMetaBase
  omega

theorem servSlotOff_bounds {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    {i : ℕ} (hi : i < cp.D_max) :
    0 ≤ servSlotOff i ∧ servSlotOff i < (ops.BW : ℤ) := by
  have hbw_nat : 16 + i < ops.BW := by
    have hbw := ops.hBW_meta
    have hdd : 0 ≤ cp.D_max * cp.D_max := Nat.zero_le _
    omega
  have hbw_int : (16 : ℤ) + (i : ℤ) < (ops.BW : ℤ) := by exact_mod_cast hbw_nat
  unfold servSlotOff
  omega

theorem encHandlePool_ext_local {d n : ℕ} {hp : HandlePool d n} {m₀ m₁ : ArithRAMMemory}
    (hhp : EncHandlePool hp m₀)
    (hw : ∀ t < 4, ∀ i, wRead m₁ t i = wRead m₀ t i)
    (hr : ∀ i, rRead m₁ ptsRTbl i = rRead m₀ ptsRTbl i) :
    EncHandlePool hp m₁ :=
  ⟨(hw 0 (by decide) 4).trans hhp.1,
   (hw 0 (by decide) 5).trans hhp.2.1,
   (hw 0 (by decide) 6).trans hhp.2.2.1,
   fun i hi => (hw 1 (by decide) _).trans (hhp.2.2.2.1 i hi),
   fun i hi => ⟨(hw 2 (by decide) _).trans (hhp.2.2.2.2.1 i hi).1,
                (hw 3 (by decide) _).trans (hhp.2.2.2.2.1 i hi).2⟩,
   fun x hx c => (hr _).trans (hhp.2.2.2.2.2 x hx c)⟩

theorem encCachedAns_ext_local {ans : StoredDiameterAnswer} {m₀ m₁ : ArithRAMMemory}
    (ha : EncCachedAns ans m₀)
    (hw0 : ∀ i, wRead m₁ 0 i = wRead m₀ 0 i)
    (hw6_3 : wRead m₁ engMetaTbl 3 = wRead m₀ engMetaTbl 3)
    (hw6_4 : wRead m₁ engMetaTbl 4 = wRead m₀ engMetaTbl 4)
    (hw6_5 : wRead m₁ engMetaTbl 5 = wRead m₀ engMetaTbl 5)
    (hr0 : rRead m₁ 0 0 = rRead m₀ 0 0)
    (hr2 : rRead m₁ engRealTbl 0 = rRead m₀ engRealTbl 0) :
    EncCachedAns ans m₁ := by
  rcases ha with ⟨hread, hr_sh, hmatch⟩
  have hread₁ : ArithRAMDynamicProgram.readCachedAnswer m₁ =
      ArithRAMDynamicProgram.readCachedAnswer m₀ := by
    have h01 : m₁.words.read (.heap 0 1) = m₀.words.read (.heap 0 1) := hw0 1
    have h02 : m₁.words.read (.heap 0 2) = m₀.words.read (.heap 0 2) := hw0 2
    have h03 : m₁.words.read (.heap 0 3) = m₀.words.read (.heap 0 3) := hw0 3
    have hr00 : m₁.reals.read (.heap 0 0) = m₀.reals.read (.heap 0 0) := hr0
    unfold ArithRAMDynamicProgram.readCachedAnswer
    simp only [h01, h02, h03, hr00]
  refine ⟨hread₁.trans hread, hr2.trans hr_sh, ?_⟩
  cases hd : ans.diameterHandles with
  | none =>
      simp only [hd] at hmatch
      exact ⟨hw6_3.trans hmatch.1, hw6_4.trans hmatch.2.1, hw6_5.trans hmatch.2.2⟩
  | some uv =>
      rcases uv with ⟨u, v⟩
      simp only [hd] at hmatch
      exact ⟨hw6_3.trans hmatch.1, hw6_4.trans hmatch.2.1, hw6_5.trans hmatch.2.2⟩

private lemma two_stride_le_mul_off {S k x : ℕ} (hk : 2 ≤ k) :
    2 * (S : ℤ) ≤ (((k * S : ℕ) : ℤ)) + (x : ℤ) := by
  have h1 : 2 * S ≤ k * S := Nat.mul_le_mul_right S hk
  have h2 : (2 * S : ℤ) ≤ (((k * S : ℕ) : ℤ)) := by exact_mod_cast h1
  omega

theorem encJobSlot_ext_local {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {r : Fin cp.D_max} {jbOpt : Option (SuffixJob cp)} {rSlots : List ℕ} {cSlot : ℕ}
    {m₀ m₁ : ArithRAMMemory}
    (hj : EncJobSlot ops r jbOpt rSlots cSlot m₀)
    (hslots : ∀ s ∈ jobUsedSlots jbOpt rSlots cSlot, s < M_slots cp)
    (hw_meta : ∀ j : ℤ, 0 ≤ j → j ≤ 7 →
      wRead m₁ engMetaTbl (jobMetaBase cp r.val + j) =
        wRead m₀ engMetaTbl (jobMetaBase cp r.val + j))
    (hw_ready : ∀ q < cp.D_max,
      wRead m₁ engMetaTbl (readySlotOff cp r.val q) =
        wRead m₀ engMetaTbl (readySlotOff cp r.val q))
    (hw_arr : ∀ i : ℤ, 2 * (S_stride cp : ℤ) ≤ i → wRead m₁ engArrTbl i = wRead m₀ engArrTbl i)
    (hnd : ∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s m₁) :
    EncJobSlot ops r jbOpt rSlots cSlot m₁ := by
  have hm0 : wRead m₁ engMetaTbl (jobMetaBase cp r.val) =
      wRead m₀ engMetaTbl (jobMetaBase cp r.val) := by
    simpa using hw_meta 0 (by omega) (by omega)
  cases jbOpt with
  | none =>
      exact ⟨hj.1, hm0.trans hj.2⟩
  | some jb =>
      rcases hj with ⟨hact, hrle, hrlen, hwlen, hready, hph⟩
      have hrSlot_lt : ∀ q (hqs : q < rSlots.length), rSlots[q]'hqs < M_slots cp := by
        intro q hqs
        apply hslots
        dsimp only [jobUsedSlots]
        cases jb.phase with
        | copy _ => exact List.getElem_mem hqs
        | build _ => exact List.mem_append_left _ (List.getElem_mem hqs)
      refine ⟨hm0.trans hact, hrle, hrlen,
        (hw_meta 1 (by omega) (by omega)).trans hwlen,
        fun q hq hqs =>
          ⟨(hw_ready q (lt_of_lt_of_le hq hrle)).trans (hready q hq hqs).1,
           hnd _ _ (hrSlot_lt q hqs) (hready q hq hqs).2⟩, ?_⟩
      cases hjp : jb.phase with
      | copy cs =>
          simp only [hjp] at hph
          rcases hph with ⟨hp2, hp3, hp4, hsp⟩
          exact ⟨(hw_meta 2 (by omega) (by omega)).trans hp2,
            (hw_meta 3 (by omega) (by omega)).trans hp3,
            (hw_meta 4 (by omega) (by omega)).trans hp4,
            hsp.ext (hw_meta 5 (by omega) (by omega))
              (fun i _ => hw_arr _ (by unfold snapElemOff; exact two_stride_le_mul_off (by omega)))
              (fun y _ => hw_arr _ (by unfold snapPosOff; exact two_stride_le_mul_off (by omega)))⟩
      | build bs =>
          simp only [hjp] at hph
          rcases hph with ⟨hp2, hp3, hp4, hsp, hdsp, hcslot, hcenc⟩
          have hc_lt : cSlot < M_slots cp := by
            apply hslots
            simp [jobUsedSlots, hjp]
          exact ⟨(hw_meta 2 (by omega) (by omega)).trans hp2,
            (hw_meta 3 (by omega) (by omega)).trans hp3,
            (hw_meta 4 (by omega) (by omega)).trans hp4,
            hsp.ext (hw_meta 5 (by omega) (by omega))
              (fun i _ => hw_arr _ (by unfold snapElemOff; exact two_stride_le_mul_off (by omega)))
              (fun y _ => hw_arr _ (by unfold snapPosOff; exact two_stride_le_mul_off (by omega))),
            hdsp.ext (hw_meta 6 (by omega) (by omega))
              (fun i _ => hw_arr _ (by unfold delSnapElemOff; exact two_stride_le_mul_off (by omega)))
              (fun y _ => hw_arr _ (by unfold delSnapPosOff; exact two_stride_le_mul_off (by omega))),
            (hw_meta 7 (by omega) (by omega)).trans hcslot,
            hnd _ _ hc_lt hcenc⟩

theorem encChainEngine_ext_scr {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {st : ChainEngineState cp} {m₀ m₁ : ArithRAMMemory}
    (henc : EncChainEngine ops st m₀)
    (hsr₁ : ops.SlotsReady m₁)
    (hnd : ∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s m₁)
    (hw : ∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i)
    (hr : ∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i) :
    EncChainEngine ops st m₁ := by
  rcases henc with ⟨_, hhp, hans, hov, hleaf_le, hleaf_sp, hserv_le, hserv_len,
    servSlots, readySlots, curSlots, hslen, hserv, hjobs, hall_nd, hall_lt⟩
  have hw6 : ∀ i, wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i :=
    hw engMetaTbl (by decide) (by decide)
  have hw7 : ∀ i, wRead m₁ engArrTbl i = wRead m₀ engArrTbl i :=
    hw engArrTbl (by decide) (by decide)
  refine ⟨hsr₁,
    encHandlePool_ext_local hhp (fun t ht => hw t (by omega) (by unfold engScrTbl; omega))
      (hr ptsRTbl (by decide)),
    encCachedAns_ext hans (hw 0 (by decide) (by decide)) hw6 (hr 0 (by decide) 0)
      (hr engRealTbl (by decide) 0),
    (hw6 1).trans hov,
    hleaf_le,
    hleaf_sp.ext (hw6 2) (fun _ _ => hw7 _) (fun _ _ => hw7 _),
    hserv_le,
    (hw6 0).trans hserv_len,
    servSlots, readySlots, curSlots, hslen,
    fun i hi his =>
      ⟨(hw6 _).trans (hserv i hi his).1,
       hnd _ _ (hall_lt _ (List.mem_append_left _ (List.getElem_mem his))) (hserv i hi his).2⟩,
    fun r => encJobSlot_ext_local (hjobs r)
      (fun s hs => hall_lt s (List.mem_append_right _ (List.mem_flatMap.mpr ⟨r, List.mem_finRange r, hs⟩)))
      (fun j _ _ => hw6 _) (fun _ _ => hw6 _) (fun _ _ => hw7 _) hnd,
    hall_nd, hall_lt⟩

/-! ### 3. `copyNodeDenseToLeafStmt`: Copy `mn.nd.denseArr` (`≤ B_scan`) into Leaf Sparse Set -/

def copyNodeDenseToLeafStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (cSlotR : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap engMetaTbl (.lit 2) (.lit 0))
  (.seq (.writeWordHeap engScrTbl (.lit 20) (.lit 2))
  (.seq (.writeWordHeap engScrTbl (.lit 21) (.lit leafElemOff))
  (.seq (.writeWordHeap engScrTbl (.lit 22) (.lit (leafPosOff cp)))
  (.seq (ops.readNodeScalarStmt .denseLen cSlotR 30)
        (dynForLoopStmt 27 30
          (.seq (ops.readNodeArrElemStmt .dense cSlotR 27 23)
                (sparseInsertFreshStmt 20 21 22 23)))))))

theorem zeroRand_copyNodeDenseToLeafStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (cSlotR : ℤ) :
    ZeroRandStmt (copyNodeDenseToLeafStmt ops cSlotR) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (ops.zeroRand_readNodeScalar .denseLen cSlotR 30)
    (zeroRand_dynForLoopStmt 27 30
      (.seq (ops.zeroRand_readNodeArrElem .dense cSlotR 27 23)
            (zeroRand_sparseInsertFreshStmt 20 21 22 23)))))))

theorem exec_copyNodeDenseToLeafStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (cSlotR : ℤ)
    {m₀ : ArithRAMMemory} {mn : MNode cp} {cSlot : ℕ}
    (hcR0 : 0 ≤ cSlotR) (hcR20 : cSlotR < 20)
    (hcSlot : cSlot < M_slots cp)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (henc_mn : ops.EncNode mn cSlot m₀)
    (hread_cR : wRead m₀ engScrTbl cSlotR = (cSlot : ℤ))
    (hnd_dense : mn.nd.denseArr.Nodup)
    (hdense_n : ∀ x ∈ mn.nd.denseArr, x < cp.n)
    (hlen_B : mn.nd.denseArr.length ≤ cp.B_scan) :
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (copyNodeDenseToLeafStmt ops cSlotR) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) mn.nd.denseArr m₁ ∧
        (∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m₁) ∧
        (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ 2 → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, 2 * (S_stride cp : ℤ) ≤ i → wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, i < 20 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (80 + ops.C_read + cp.B_scan * (ops.C_read + 120)) := by
  have hTW := ops.hTW
  have hBW_meta := ops.hBW_meta
  have hBW_arr := ops.hBW_arr
  have hBW_scr := ops.hBW_scr
  let FrameRes (m : ArithRAMMemory) : Prop :=
    ops.SlotsReady m ∧
    (∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m) ∧
    (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ i, i ≠ 2 → wRead m engMetaTbl i = wRead m₀ engMetaTbl i) ∧
    (∀ i, 2 * (S_stride cp : ℤ) ≤ i → wRead m engArrTbl i = wRead m₀ engArrTbl i) ∧
    (∀ i, i < 20 → wRead m engScrTbl i = wRead m₀ engScrTbl i) ∧
    (∀ t < 3, ∀ i, rRead m t i = rRead m₀ t i)
  unfold copyNodeDenseToLeafStmt
  refine ExecDet.seq' (68 + ops.C_read + cp.B_scan * (ops.C_read + 120))
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 2) (.lit 0) 2 0
      hfp₀ (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
    (by nlinarith) ?_
  intro m1 hm1 hfp1; subst hm1
  refine ExecDet.seq' (56 + ops.C_read + cp.B_scan * (ops.C_read + 120))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 20) (.lit 2) 20 2
      hfp1 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) rfl) (by nlinarith) ?_
  intro m2 hm2 hfp2; subst hm2
  refine ExecDet.seq' (44 + ops.C_read + cp.B_scan * (ops.C_read + 120))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 21) (.lit leafElemOff) 21 leafElemOff
      hfp2 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) rfl) (by nlinarith) ?_
  intro m3 hm3 hfp3; subst hm3
  refine ExecDet.seq' (32 + ops.C_read + cp.B_scan * (ops.C_read + 120))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 22) (.lit (leafPosOff cp)) 22 (leafPosOff cp)
      hfp3 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) rfl) (by nlinarith) ?_
  intro m4 hm4 hfp4; subst hm4
  let m4_st := H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engMetaTbl 2 0)
    engScrTbl 20 2) engScrTbl 21 leafElemOff) engScrTbl 22 (leafPosOff cp)
  have hw9_4 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m4_st t i = wRead m₀ t i := by
    intro t ht9 _ i
    have h1 : t ≠ engScrTbl := by unfold engScrTbl; omega
    have h2 : t ≠ engMetaTbl := by unfold engMetaTbl; omega
    simp [m4_st, wRead_wWrite_eq, h1, h2]
  have hr_4 : ∀ t i, rRead m4_st t i = rRead m₀ t i := by
    intro t i; simp [m4_st]
  have hsr4 : ops.SlotsReady m4_st := ops.slotsReady_ext m₀ m4_st hsr₀ hw9_4 (fun t _ _ i => hr_4 t i)
  have hnd4 : ∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m4_st :=
    fun mn' s _ he => ops.encNode_ext mn' s m₀ m4_st he hw9_4 (fun t _ _ i => hr_4 t i)
      (fun _ _ _ _ => hr_4 ptsRTbl _)
  have hcR4 : wRead m4_st engScrTbl cSlotR = (cSlot : ℤ) := by
    have : cSlotR ≠ 22 ∧ cSlotR ≠ 21 ∧ cSlotR ≠ 20 := by omega
    simp only [m4_st, wRead_wWrite_eq, show engScrTbl ≠ engMetaTbl by decide]
    simp [this.1, this.2.1, this.2.2, hread_cR]
  refine ExecDet.seq' (16 + cp.B_scan * (ops.C_read + 120))
    (ops.readNodeScalar_spec inp m4_st mn cSlot .denseLen cSlotR 30
      hcSlot hcR0 (by omega) (by omega) (by omega) hfp4 hsr4 (hnd4 mn cSlot hcSlot henc_mn) hcR4)
    (by nlinarith) ?_
  intro m5 ⟨hsr5, hr30, hnd5, hft5, hfs5, hfr5⟩ hfp5
  dsimp [evalNodeScalar] at hr30
  let Inv (k : ℕ) (m : ArithRAMMemory) : Prop :=
    FrameRes m ∧
    wRead m engScrTbl 20 = 2 ∧
    wRead m engScrTbl 21 = leafElemOff ∧
    wRead m engScrTbl 22 = leafPosOff cp ∧
    EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) (mn.nd.denseArr.take k) m
  have hInv0 : Inv 0 (H3a.wWrite m5 engScrTbl 27 0) := by
    let m5w := H3a.wWrite m5 engScrTbl 27 0
    have hw9_5w : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m5w t i = wRead m5 t i :=
      fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
    have hr_5w : ∀ t i, rRead m5w t i = rRead m5 t i := fun t i => rRead_wWrite _ _ _ _ _ _
    refine ⟨⟨ops.slotsReady_ext m5 m5w hsr5 hw9_5w (fun t _ _ i => hr_5w t i),
      fun mn' s hs he => ops.encNode_ext mn' s m5 m5w (hnd5 mn' s hs (hnd4 mn' s hs he))
        hw9_5w (fun t _ _ i => hr_5w t i) (fun _ _ _ _ => hr_5w ptsRTbl _),
      fun t ht9 ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans
        ((hft5 t ht9 ht3 i).trans (by simp [m4_st, wRead_wWrite_eq, ht1, ht3])),
      fun i hi2 => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
        ((hft5 engMetaTbl (by decide) (by decide) i).trans
          (by simp [m4_st, wRead_wWrite_eq, hi2, show engMetaTbl ≠ engScrTbl by decide])),
      fun i _ => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
        ((hft5 engArrTbl (by decide) (by decide) i).trans
          (by simp [m4_st, wRead_wWrite_eq, show engArrTbl ≠ engScrTbl by decide,
              show engArrTbl ≠ engMetaTbl by decide])),
      fun i hi20 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans
        ((hfs5 i (by omega)).trans (by
          simp only [m4_st, wRead_wWrite_eq, show engScrTbl ≠ engMetaTbl by decide]
          have : i ≠ 22 ∧ i ≠ 21 ∧ i ≠ 20 := by omega
          simp [this.1, this.2.1, this.2.2])),
      fun t ht3 i => (hr_5w t i).trans ((hfr5 t ht3 i).trans (hr_4 t i))⟩,
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans ((hfs5 20 (by decide)).trans
        (by simp [m4_st, wRead_wWrite_eq])),
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans ((hfs5 21 (by decide)).trans
        (by simp [m4_st, wRead_wWrite_eq])),
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans ((hfs5 22 (by decide)).trans
        (by simp [m4_st, wRead_wWrite_eq])),
      encSparseSet_empty_of_zero ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
        ((hft5 engMetaTbl (by decide) (by decide) 2).trans
          (by simp [m4_st, wRead_wWrite_eq, show engMetaTbl ≠ engScrTbl by decide])))⟩
  refine (ExecDet.dynForLoop 27 30
    (.seq (ops.readNodeArrElemStmt .dense cSlotR 27 23) (sparseInsertFreshStmt 20 21 22 23))
    (N := mn.nd.denseArr.length) (N_max := cp.B_scan) (C_b := ops.C_read + 100)
    Inv hfp5 (by omega) (by omega) (by unfold M_slots at hBW_scr; omega) (by decide)
    hr30 hlen_B hInv0 ?_).mono
    (fun m ⟨⟨hsrm, hndm, hftm, hfmm, hfam, hfsm, hfrm⟩, _, _, _, henc⟩ _ => ?_) (by nlinarith)
  · intro k hk m ⟨hFR, hr20, hr21, hr22, henc_k⟩ hctr hfp
    let x := mn.nd.denseArr[k]'hk
    have hx_n : x < cp.n := hdense_n x (List.getElem_mem hk)
    rcases denseInsert_take_succ hnd_dense hk with ⟨hx_not, hdi_eq⟩
    have hcR_m : wRead m engScrTbl cSlotR = (cSlot : ℤ) := (hFR.2.2.2.2.2.1 cSlotR hcR20).trans hread_cR
    refine ExecDet.seq' 100
      (ops.readNodeArrElem_spec inp m mn cSlot k .dense hk cSlotR 27 23
        hcSlot hcR0 (by omega) (by omega) (by omega) (by omega) (by omega)
        hfp hFR.1 (hFR.2.1 mn cSlot hcSlot henc_mn) hcR_m hctr) (by omega) ?_
    intro mX ⟨hsrX, hr23, hndX, hftX, hfsX, hfrX⟩ hfpX
    dsimp [evalNodeArr] at hr23
    have henc_k' : EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) (mn.nd.denseArr.take k) mX :=
      henc_k.ext (hftX engMetaTbl (by decide) (by decide) 2)
        (fun _ _ => hftX engArrTbl (by decide) (by decide) _)
        (fun _ _ => hftX engArrTbl (by decide) (by decide) _)
    refine (exec_sparseInsertFreshStmt inp 20 21 22 23
      (by omega) (by unfold M_slots at hBW_scr; omega)
      (by decide) (by decide) (by decide) (by decide)
      (by omega) (by omega)
      (by unfold leafElemOff; omega)
      (by have h2S : 2 * S_stride cp ≤ ops.BW := by nlinarith [ops.hBW_arr]
          unfold leafElemOff S_stride at *; omega)
      (by unfold leafPosOff; omega)
      (by have h2S : 2 * S_stride cp ≤ ops.BW := by nlinarith [ops.hBW_arr]
          unfold leafPosOff S_stride at *; omega)
      (Or.inl (by unfold leafElemOff leafPosOff S_stride; omega))
      hx_n hx_not hfpX henc_k'
      ((hfsX 20 (by decide)).trans hr20)
      ((hfsX 21 (by decide)).trans hr21)
      ((hfsX 22 (by decide)).trans hr22)
      hr23).mono ?_ le_rfl
    intro mI ⟨henc_next, hftI, hfmI, hfaI, hfsI, hfrI⟩ _
    rw [hdi_eq] at henc_next
    let mN := H3a.wWrite mI engScrTbl 27 ((k : ℤ) + 1)
    have hw9_N : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mN t i = wRead mX t i :=
      fun t ht9 _ i => (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))).trans
        (hftI t (by unfold engMetaTbl; omega) (by unfold engArrTbl; omega) (by unfold engScrTbl; omega) i)
    have hr_N : ∀ t i, rRead mN t i = rRead mX t i :=
      fun t i => (rRead_wWrite _ _ _ _ _ _).trans (hfrI t i)
    refine ⟨(hfsI 27 (by omega)).trans ((hfsX 27 (by decide)).trans hctr),
      ⟨⟨ops.slotsReady_ext mX mN hsrX hw9_N (fun t _ _ i => hr_N t i),
        fun mn' s hs he0 => ops.encNode_ext mn' s mX mN
          (hndX mn' s hs (hFR.2.1 mn' s hs he0)) hw9_N (fun t _ _ i => hr_N t i) (fun _ _ _ _ => hr_N ptsRTbl _),
        fun t ht9 ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans
          ((hftI t ht1 ht2 ht3 i).trans ((hftX t ht9 ht3 i).trans (hFR.2.2.1 t ht9 ht1 ht2 ht3 i))),
        fun i hi2 => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfmI i hi2).trans ((hftX engMetaTbl (by decide) (by decide) i).trans (hFR.2.2.2.1 i hi2))),
        fun i hi_arr => ?_,
        fun i hi20 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans
          ((hfsI i (by omega)).trans ((hfsX i (by omega)).trans (hFR.2.2.2.2.2.1 i hi20))),
        fun t ht3 i => (hr_N t i).trans ((hfrX t ht3 i).trans (hFR.2.2.2.2.2.2 t ht3 i))⟩,
       (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans ((hfsI 20 (by omega)).trans ((hfsX 20 (by decide)).trans hr20)),
       (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans ((hfsI 21 (by omega)).trans ((hfsX 21 (by decide)).trans hr21)),
       (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans ((hfsI 22 (by omega)).trans ((hfsX 22 (by decide)).trans hr22)),
       henc_next.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
         (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
         (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))⟩⟩
    have hlen_tk : (mn.nd.denseArr.take k).length ≤ cp.n := by
      rw [List.length_take]
      have hsub : mn.nd.denseArr.toFinset ⊆ Finset.range cp.n := fun y hy =>
        Finset.mem_range.mpr (hdense_n y (List.mem_toFinset.mp hy))
      have hcard := Finset.card_le_card hsub
      rw [Finset.card_range, List.toFinset_card_of_nodup hnd_dense] at hcard
      exact (Nat.min_le_right _ _).trans hcard
    have hne_e : i ≠ leafElemOff + ((mn.nd.denseArr.take k).length : ℤ) := by
      unfold leafElemOff S_stride at *; omega
    have hne_p : i ≠ leafPosOff cp + (x : ℤ) := by
      unfold leafPosOff S_stride at *; omega
    exact (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
      ((hfaI i hne_e hne_p).trans ((hftX engArrTbl (by decide) (by decide) i).trans (hFR.2.2.2.2.1 i hi_arr)))
  · rw [List.take_length] at henc
    exact ⟨hsrm, henc, hndm, hftm, hfmm, hfam, hfsm, hfrm⟩

/-! ### 4. `clearJobsFromStmt`: Clear `jobMetaBase cp rr` for `r.val ≤ rr.val` -/

def clearJobsFromStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) : ArithRAMStmt :=
  seqList (List.finRange cp.D_max) (fun rr =>
    if r.val ≤ rr.val then
      .writeWordHeap engMetaTbl (.lit (jobMetaBase cp rr.val)) (.lit 0)
    else
      .skip)

theorem zeroRand_clearJobsFromStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) :
    ZeroRandStmt (clearJobsFromStmt cp r) := by
  refine zeroRand_seqList _ _ (fun rr _ => ?_)
  split_ifs
  · exact .writeWordHeap _ _ _
  · exact .skip

theorem exec_clearJobsFromStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {m₀ : ArithRAMMemory}
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀) :
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (clearJobsFromStmt cp r) m₀
      (fun m₁ =>
        (∀ rr : Fin cp.D_max, r.val ≤ rr.val →
          wRead m₁ engMetaTbl (jobMetaBase cp rr.val) = 0) ∧
        (∀ i : ℤ,
          (∀ rr : Fin cp.D_max, r.val ≤ rr.val → i ≠ jobMetaBase cp rr.val) →
          wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ t, t ≠ engMetaTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      (1 + cp.D_max * 12) := by
  have hTW := ops.hTW
  let Inv : List (Fin cp.D_max) → ArithRAMMemory → Prop := fun seen m =>
    (∀ rr ∈ seen, r.val ≤ rr.val → wRead m engMetaTbl (jobMetaBase cp rr.val) = 0) ∧
    (∀ i : ℤ,
      (∀ rr : Fin cp.D_max, r.val ≤ rr.val → i ≠ jobMetaBase cp rr.val) →
      wRead m engMetaTbl i = wRead m₀ engMetaTbl i) ∧
    (∀ t, t ≠ engMetaTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ t i, rRead m t i = rRead m₀ t i)
  have hInv₀ : Inv [] m₀ :=
    ⟨fun _ h => absurd h List.not_mem_nil, fun _ _ => rfl, fun _ _ _ => rfl, fun _ _ => rfl⟩
  have hlen : (List.finRange cp.D_max).length = cp.D_max := List.length_finRange
  unfold clearJobsFromStmt
  refine (exec_seqList (List.finRange cp.D_max)
    (fun rr => if r.val ≤ rr.val then
      .writeWordHeap engMetaTbl (.lit (jobMetaBase cp rr.val)) (.lit 0) else .skip)
    (fun seen rr => seen ++ [rr]) Inv 12 hfp₀ hInv₀ ?_).mono ?_ (by rw [hlen])
  · intro rr _ seen m ⟨hclr, hpres6, hpresT, hpresR⟩ hfp
    dsimp only
    by_cases hle : r.val ≤ rr.val
    · rw [if_pos hle]
      rcases jobMetaBase_bounds ops rr (j := 0) (by omega) (by omega) with ⟨hbase0, hbaseB⟩
      simp only [add_zero] at hbase0 hbaseB
      refine ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (jobMetaBase cp rr.val)) (.lit 0)
        (jobMetaBase cp rr.val) 0 hfp (by unfold engMetaTbl; omega) hbase0 hbaseB
        rfl rfl (by simp [intExprOps]) ?_
      refine ⟨fun rk hrk hrk_le => ?_, fun i hi_ne => ?_,
        fun t ht i => (wRead_wWrite_of_ne _ _ (Or.inl ht)).trans (hpresT t ht i),
        fun t i => (rRead_wWrite _ _ _ _ _ _).trans (hpresR t i)⟩
      · rcases List.mem_append.mp hrk with hmem | hsing
        · by_cases heq : rk = rr
          · subst heq; exact wRead_wWrite_self _ _ _ _
          · have hne_idx : jobMetaBase cp rk.val ≠ jobMetaBase cp rr.val := by
              have hne_v : rk.val ≠ rr.val := fun hv => heq (Fin.ext hv)
              unfold jobMetaBase; omega
            exact (wRead_wWrite_of_ne _ _ (Or.inr hne_idx)).trans (hclr rk hmem hrk_le)
        · rw [List.mem_singleton.mp hsing]
          exact wRead_wWrite_self _ _ _ _
      · exact (wRead_wWrite_of_ne _ _ (Or.inr (hi_ne rr hle))).trans (hpres6 i hi_ne)
    · rw [if_neg hle]
      refine ExecDet.skip inp hfp ?_ (by omega)
      refine ⟨fun rk hrk hrk_le => ?_, hpres6, hpresT, hpresR⟩
      rcases List.mem_append.mp hrk with hmem | hsing
      · exact hclr rk hmem hrk_le
      · rw [List.mem_singleton.mp hsing] at hrk_le
        exact absurd hrk_le hle
  · intro m₁ ⟨hclr, hpres6, hpresT, hpresR⟩ _
    have hfold_mem : ∀ rr : Fin cp.D_max,
        rr ∈ (List.finRange cp.D_max).foldl (fun seen x => seen ++ [x]) [] := by
      have hid : ∀ (xs acc : List (Fin cp.D_max)),
          xs.foldl (fun seen x => seen ++ [x]) acc = acc ++ xs := by
        intro xs
        induction xs with
        | nil => intro acc; simp
        | cons x tl ih =>
            intro acc
            simp only [List.foldl_cons, ih, List.append_assoc, List.singleton_append]
      intro rr
      rw [hid, List.nil_append]
      exact List.mem_finRange rr
    exact ⟨fun rr hle => hclr rr (hfold_mem rr) hle, hpres6, hpresT, hpresR⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3
