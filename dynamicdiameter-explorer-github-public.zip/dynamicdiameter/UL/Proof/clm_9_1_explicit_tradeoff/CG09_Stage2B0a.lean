import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2B0s
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 6. Copy-Loop Execution (`advanceCopyLoopStmt`, `exec_advanceCopyLoopStmt`) -/

def advanceCopyOne (srcHist targetArr : List ℕ) (cs : CopyState) : CopyState :=
  if hlt : cs.copyCur < srcHist.length then
    let x := srcHist[cs.copyCur]'hlt
    let snap' :=
      if targetArr.contains x && !cs.snapArr.contains x then
        denseInsert x cs.snapArr
      else
        cs.snapArr
    { cs with copyCur := cs.copyCur + 1, snapArr := snap' }
  else
    cs

theorem advanceCopyLoop_succ_right (srcHist targetArr : List ℕ) :
    ∀ (k : ℕ) (cs : CopyState),
      advanceCopyLoop srcHist targetArr (k + 1) cs =
        advanceCopyOne srcHist targetArr (advanceCopyLoop srcHist targetArr k cs)
  | 0, _ => rfl
  | k + 1, cs => by
      by_cases hlt : cs.copyCur < srcHist.length
      · have h1 : advanceCopyLoop srcHist targetArr (k + 2) cs =
            advanceCopyLoop srcHist targetArr (k + 1) (advanceCopyOne srcHist targetArr cs) := by
          conv_lhs => unfold advanceCopyLoop
          unfold advanceCopyOne; simp only [dif_pos hlt]
        have h2 : advanceCopyLoop srcHist targetArr (k + 1) cs =
            advanceCopyLoop srcHist targetArr k (advanceCopyOne srcHist targetArr cs) := by
          conv_lhs => unfold advanceCopyLoop
          unfold advanceCopyOne; simp only [dif_pos hlt]
        rw [h1, h2]
        exact advanceCopyLoop_succ_right srcHist targetArr k _
      · have h1 : advanceCopyLoop srcHist targetArr (k + 2) cs = cs := by
          unfold advanceCopyLoop; rw [dif_neg hlt]
        have h2 : advanceCopyLoop srcHist targetArr (k + 1) cs = cs := by
          unfold advanceCopyLoop; rw [dif_neg hlt]
        rw [h1, h2]; unfold advanceCopyOne; rw [dif_neg hlt]

def advanceCopyIterBodyStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (r : Fin cp.D_max) (useRes : Bool) (prevSlotR : ℤ) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  .seq (.writeWordHeap engScrTbl (.lit 29) (.readHeap engMetaTbl (.lit (base + 4))))
  (.seq (ops.readNodeArrElemStmt .hist prevSlotR 29 23)
  (.seq (ops.containsNodeArrStmt useRes prevSlotR 23 24)
  (.seq (sparseContainsStmt cp.n 20 21 22 23 25)
  (.seq (.ite (.and (.intEq (.readHeap engScrTbl (.lit 24)) (.lit 1))
                    (.intEq (.readHeap engScrTbl (.lit 25)) (.lit 0)))
          (sparseInsertFreshStmt 20 21 22 23)
          .skip)
        (.writeWordHeap engMetaTbl (.lit (base + 4))
          (.add (.readHeap engScrTbl (.lit 29)) (.lit 1)))))))

def advanceCopySetupStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  let remE := IntExpr.sub (.readHeap engMetaTbl (.lit (base + 3)))
                          (.readHeap engMetaTbl (.lit (base + 4)))
  .seq (.ite (.intLt remE (.lit (cp.B_scan : ℤ)))
          (.writeWordHeap engScrTbl (.lit 30) remE)
          (.writeWordHeap engScrTbl (.lit 30) (.lit (cp.B_scan : ℤ))))
  (.seq (.writeWordHeap engScrTbl (.lit 20) (.lit (base + 5)))
  (.seq (.writeWordHeap engScrTbl (.lit 21) (.lit (snapElemOff cp r.val)))
        (.writeWordHeap engScrTbl (.lit 22) (.lit (snapPosOff cp r.val)))))

def advanceCopyLoopStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (r : Fin cp.D_max) (useRes : Bool) (prevSlotR : ℤ) : ArithRAMStmt :=
  .seq (advanceCopySetupStmt cp r)
       (dynForLoopStmt 27 30 (advanceCopyIterBodyStmt ops r useRes prevSlotR))

theorem zeroRand_advanceCopyLoopStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (r : Fin cp.D_max) (useRes : Bool) (prevSlotR : ℤ) :
    ZeroRandStmt (advanceCopyLoopStmt ops r useRes prevSlotR) := by
  unfold advanceCopyLoopStmt advanceCopySetupStmt advanceCopyIterBodyStmt
  exact .seq (.seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))
      (zeroRand_dynForLoopStmt 27 30
        (.seq (.writeWordHeap _ _ _)
        (.seq (ops.zeroRand_readNodeArrElem .hist prevSlotR 29 23)
        (.seq (ops.zeroRand_containsNodeArr useRes prevSlotR 23 24)
        (.seq (zeroRand_sparseContainsStmt cp.n 20 21 22 23 25)
        (.seq (.ite (zeroRand_sparseInsertFreshStmt 20 21 22 23) .skip)
              (.writeWordHeap _ _ _)))))))

theorem exec_advanceCopyLoopStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max) (useRes : Bool) (prevSlotR : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {T_end : Finset ℕ}
    {prevNode : MNode cp} {prevSlot : ℕ} {cs : CopyState} {m₀ : ArithRAMMemory}
    (hpR0 : 0 ≤ prevSlotR) (hpR20 : prevSlotR < 20)
    (hpSlot : prevSlot < M_slots cp)
    (hcur_lt_L : cs.copyCur ≤ cs.L_hist)
    (hcs_inv : CopyStateInv prevNode.histArr T_end cs)
    (htgt_set : (if useRes then prevNode.resArr else prevNode.nd.denseArr).toFinset = T_end)
    (hTend_n : ∀ x ∈ T_end, x < cp.n)
    (hprev_cur_n : ∀ y ∈ prevNode.nd.curSet, y < cp.n)
    (hprev_wf : ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts prevNode)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (henc_prev : ops.EncNode prevNode prevSlot m₀)
    (hread_pR : wRead m₀ engScrTbl prevSlotR = (prevSlot : ℤ))
    (hw_L : wRead m₀ engMetaTbl (jobMetaBase cp r.val + 3) = (cs.L_hist : ℤ))
    (hw_cur : wRead m₀ engMetaTbl (jobMetaBase cp r.val + 4) = (cs.copyCur : ℤ))
    (hsnap_enc : EncSparseSet cp.n (jobMetaBase cp r.val + 5)
      (snapElemOff cp r.val) (snapPosOff cp r.val) cs.snapArr m₀) :
    let tgtArr := if useRes then prevNode.resArr else prevNode.nd.denseArr
    let steps := min (cs.L_hist - cs.copyCur) cp.B_scan
    let cs' := advanceCopyLoop prevNode.histArr tgtArr steps cs
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (advanceCopyLoopStmt ops r useRes prevSlotR) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        wRead m₁ engMetaTbl (jobMetaBase cp r.val + 3) = (cs'.L_hist : ℤ) ∧
        wRead m₁ engMetaTbl (jobMetaBase cp r.val + 4) = (cs'.copyCur : ℤ) ∧
        EncSparseSet cp.n (jobMetaBase cp r.val + 5)
          (snapElemOff cp r.val) (snapPosOff cp r.val) cs'.snapArr m₁ ∧
        (∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m₁) ∧
        (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ jobMetaBase cp r.val + 4 → i ≠ jobMetaBase cp r.val + 5 →
          wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, (i < snapElemOff cp r.val ∨ snapElemOff cp r.val + (cp.n : ℤ) ≤ i) →
              (i < snapPosOff cp r.val ∨ snapPosOff cp r.val + (cp.n : ℤ) ≤ i) →
              wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, i < 20 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (100 + cp.B_scan * (2 * ops.C_read + 260)) := by
  intro tgtArr steps cs'
  have hTW := ops.hTW; have hBW_meta := ops.hBW_meta
  have hBW_arr := ops.hBW_arr; have hBW_scr := ops.hBW_scr
  let base := jobMetaBase cp r.val
  have hsteps_le_B : steps ≤ cp.B_scan := Nat.min_le_right _ _
  have hsteps_le_rem : cs.copyCur + steps ≤ cs.L_hist := by dsimp [steps]; omega
  -- Frame predicate outside `base + 4`, `base + 5`, `snapElem/Pos(r)`, `engScrTbl[20..]`
  let FrameCopy (m : ArithRAMMemory) : Prop :=
    ops.SlotsReady m ∧
    (∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m) ∧
    (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ i, i ≠ base + 4 → i ≠ base + 5 → wRead m engMetaTbl i = wRead m₀ engMetaTbl i) ∧
    (∀ i, (i < snapElemOff cp r.val ∨ snapElemOff cp r.val + (cp.n : ℤ) ≤ i) →
          (i < snapPosOff cp r.val ∨ snapPosOff cp r.val + (cp.n : ℤ) ≤ i) →
          wRead m engArrTbl i = wRead m₀ engArrTbl i) ∧
    (∀ i, i < 20 → wRead m engScrTbl i = wRead m₀ engScrTbl i) ∧
    (∀ t < 3, ∀ i, rRead m t i = rRead m₀ t i)
  -- Setup: write `steps` to `30` and sparse-set descriptors to `20, 21, 22`
  let remE := IntExpr.sub (.readHeap engMetaTbl (.lit (base + 3)))
                          (.readHeap engMetaTbl (.lit (base + 4)))
  have hSetup : ExecDet ops.TW ops.BW ops.TR ops.BR inp
      (advanceCopySetupStmt cp r) m₀
      (fun mS =>
        FrameCopy mS ∧
        wRead mS engScrTbl 30 = (steps : ℤ) ∧
        wRead mS engScrTbl 20 = base + 5 ∧
        wRead mS engScrTbl 21 = snapElemOff cp r.val ∧
        wRead mS engScrTbl 22 = snapPosOff cp r.val ∧
        wRead mS engMetaTbl (base + 4) = (cs.copyCur : ℤ) ∧
        EncSparseSet cp.n (base + 5) (snapElemOff cp r.val) (snapPosOff cp r.val) cs.snapArr mS)
      64 := by
    unfold advanceCopySetupStmt
    have hrem_eval : (evalIntExpr inp.toWordView 0 m₀.words remE).1 = ((cs.L_hist - cs.copyCur : ℕ) : ℤ) := by
      simp only [remE, evalIntExpr]
      change wRead m₀ engMetaTbl (base + 3) - wRead m₀ engMetaTbl (base + 4) = _
      rw [hw_L, hw_cur]; omega
    have hIte : ExecDet ops.TW ops.BW ops.TR ops.BR inp
        (.ite (.intLt remE (.lit (cp.B_scan : ℤ)))
          (.writeWordHeap engScrTbl (.lit 30) remE)
          (.writeWordHeap engScrTbl (.lit 30) (.lit (cp.B_scan : ℤ))))
        m₀ (fun m1 => m1 = H3a.wWrite m₀ engScrTbl 30 (steps : ℤ)) 28 := by
      by_cases hlt : cs.L_hist - cs.copyCur < cp.B_scan
      · have hcondT : (evalArithCond inp 0 m₀ (.intLt remE (.lit (cp.B_scan : ℤ)))).1 = true := by
          simp only [evalArithCond, hrem_eval, evalIntExpr]; exact decide_eq_true (by exact_mod_cast hlt)
        have hst_eq : steps = cs.L_hist - cs.copyCur := Nat.min_eq_left (Nat.le_of_lt hlt)
        refine ExecDet.ite' (C_c := 12) (C_b := 16) _ _ _ hcondT
          (by simp [remE, condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf) (by omega)
        exact ExecDet.wWrite inp engScrTbl (.lit 30) remE 30 (steps : ℤ)
          hfp₀ (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl
          (by rw [hrem_eval, hst_eq]) (by simp [remE, intExprOps]) rfl
      · have hcondF : (evalArithCond inp 0 m₀ (.intLt remE (.lit (cp.B_scan : ℤ)))).1 = false := by
          simp only [evalArithCond, hrem_eval, evalIntExpr]; exact decide_eq_false (by intro hc; apply hlt; exact_mod_cast hc)
        have hst_eq : steps = cp.B_scan := Nat.min_eq_right (Nat.le_of_not_lt hlt)
        refine ExecDet.ite' (C_c := 12) (C_b := 16) _ _ _ hcondF
          (by simp [remE, condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_) (by omega)
        exact ExecDet.wWrite inp engScrTbl (.lit 30) (.lit (cp.B_scan : ℤ)) 30 (steps : ℤ)
          hfp₀ (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl
          (by simp only [evalIntExpr]; rw [hst_eq]) (by simp [intExprOps]) rfl
    refine ExecDet.seq' 36 hIte (by omega) ?_
    intro m1 hm1 hfp1; subst hm1
    refine ExecDet.seq' 24
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 20) (.lit (base + 5)) 20 (base + 5)
        hfp1 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro m2 hm2 hfp2; subst hm2
    refine ExecDet.seq' 12
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 21) (.lit (snapElemOff cp r.val)) 21 (snapElemOff cp r.val)
        hfp2 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro m3 hm3 hfp3; subst hm3
    refine ExecDet.wWrite (C := 12) inp engScrTbl (.lit 22) (.lit (snapPosOff cp r.val)) 22 (snapPosOff cp r.val)
      hfp3 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) ?_
    set mS := H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engScrTbl 30 (steps : ℤ))
      engScrTbl 20 (base + 5)) engScrTbl 21 (snapElemOff cp r.val)) engScrTbl 22 (snapPosOff cp r.val)
    have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mS t i = wRead m₀ t i := by
      intro t ht9 _ i; simp only [mS, wRead_wWrite_eq]
      have : t ≠ engScrTbl := by unfold engScrTbl; omega
      simp [this]
    have hrS : ∀ t i, rRead mS t i = rRead m₀ t i := fun t i => by simp [mS, rRead_wWrite]
    refine ⟨⟨ops.slotsReady_ext m₀ mS hsr₀ hw9 (fun t _ _ i => hrS t i),
      fun mn' s _ he => ops.encNode_ext mn' s m₀ mS he hw9 (fun t _ _ i => hrS t i) (fun _ _ _ _ => hrS ptsRTbl _),
      fun t _ _ _ ht3 i => by simp only [mS, wRead_wWrite_eq]; simp [ht3],
      fun i _ _ => by simp only [mS, wRead_wWrite_eq]; simp [engMetaTbl, engScrTbl],
      fun i _ _ => by simp only [mS, wRead_wWrite_eq]; simp [engArrTbl, engScrTbl],
      fun i hi20 => by
        simp only [mS, wRead_wWrite_eq]
        have : i ≠ 22 ∧ i ≠ 21 ∧ i ≠ 20 ∧ i ≠ 30 := by omega
        simp [this],
      fun t _ i => hrS t i⟩,
      by simp [mS, wRead_wWrite_eq],
      by simp [mS, wRead_wWrite_eq],
      by simp [mS, wRead_wWrite_eq],
      by simp [mS, wRead_wWrite_eq],
      by simp only [mS, wRead_wWrite_eq]; simp [engMetaTbl, engScrTbl]; exact hw_cur,
      hsnap_enc.ext (by simp only [mS, wRead_wWrite_eq]; simp [engMetaTbl, engScrTbl])
        (fun _ _ => by simp only [mS, wRead_wWrite_eq]; simp [engArrTbl, engScrTbl])
        (fun _ _ => by simp only [mS, wRead_wWrite_eq]; simp [engArrTbl, engScrTbl])⟩
  -- Loop invariant at iteration `k ≤ steps`
  let csAt (k : ℕ) : CopyState := advanceCopyLoop prevNode.histArr tgtArr k cs
  let InvCopy (k : ℕ) (m : ArithRAMMemory) : Prop :=
    FrameCopy m ∧
    wRead m engScrTbl 20 = base + 5 ∧
    wRead m engScrTbl 21 = snapElemOff cp r.val ∧
    wRead m engScrTbl 22 = snapPosOff cp r.val ∧
    wRead m engMetaTbl (base + 4) = ((csAt k).copyCur : ℤ) ∧
    EncSparseSet cp.n (base + 5) (snapElemOff cp r.val) (snapPosOff cp r.val) (csAt k).snapArr m
  have hSnapBounds :
      0 ≤ base + 5 ∧ base + 5 < (ops.BW : ℤ) ∧
      0 ≤ snapElemOff cp r.val ∧ snapElemOff cp r.val + (cp.n : ℤ) ≤ (ops.BW : ℤ) ∧
      0 ≤ snapPosOff cp r.val ∧ snapPosOff cp r.val + (cp.n : ℤ) ≤ (ops.BW : ℤ) ∧
      (snapElemOff cp r.val + (cp.n : ℤ) ≤ snapPosOff cp r.val ∨
       snapPosOff cp r.val + (cp.n : ℤ) ≤ snapElemOff cp r.val) := by
    have hr_lt := r.isLt
    have hD2 : cp.D_max * cp.D_max ≥ 0 := Nat.zero_le _
    have h4r : (3 + 4 * r.val) * S_stride cp + cp.n ≤ ops.BW := by
      have h1 : (4 + 4 * r.val) * S_stride cp ≤ (2 + 4 * cp.D_max) * S_stride cp :=
        Nat.mul_le_mul_right _ (by omega)
      have h2 : cp.n ≤ S_stride cp := by unfold S_stride; omega
      nlinarith only [h1, h2, hBW_arr]
    have h2r : (2 + 4 * r.val) * S_stride cp + cp.n ≤ ops.BW := by nlinarith only [h4r]
    have hmeta_b : 16 + cp.D_max + 8 * r.val + 8 ≤ ops.BW := by nlinarith only [hr_lt, hBW_meta, hD2]
    refine ⟨by unfold base jobMetaBase; omega,
            by unfold base jobMetaBase; omega,
            by unfold snapElemOff; omega,
            by unfold snapElemOff; omega,
            by unfold snapPosOff; omega,
            by unfold snapPosOff; omega,
            Or.inl (by
              have hle : (2 + 4 * r.val) * S_stride cp + cp.n ≤ (3 + 4 * r.val) * S_stride cp := by
                have hsn : cp.n ≤ S_stride cp := by unfold S_stride; omega
                nlinarith only [hsn]
              unfold snapElemOff snapPosOff; omega)⟩
  unfold advanceCopyLoopStmt
  refine ExecDet.seq' (36 + cp.B_scan * (2 * ops.C_read + 260)) hSetup (by clear * -; nlinarith) ?_
  intro mS ⟨hFC_S, hr30_S, hr20_S, hr21_S, hr22_S, hwcur_S, hsnap_S⟩ hfpS
  have hInv0 : InvCopy 0 (H3a.wWrite mS engScrTbl 27 0) := by
    have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead (H3a.wWrite mS engScrTbl 27 0) t i = wRead mS t i :=
      fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
    refine ⟨⟨ops.slotsReady_ext mS _ hFC_S.1 hw9 (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      fun mn' s hs he0 => ops.encNode_ext mn' s mS _ (hFC_S.2.1 mn' s hs he0) hw9
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      fun t ht9 ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans (hFC_S.2.2.1 t ht9 ht1 ht2 ht3 i),
      fun i h4 h5 => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hFC_S.2.2.2.1 i h4 h5),
      fun i he hp => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hFC_S.2.2.2.2.1 i he hp),
      fun i hi20 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hFC_S.2.2.2.2.2.1 i hi20),
      fun t ht3 i => (rRead_wWrite _ _ _ _ _ _).trans (hFC_S.2.2.2.2.2.2 t ht3 i)⟩,
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr20_S,
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr21_S,
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr22_S,
      (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hwcur_S,
      hsnap_S.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))⟩
  refine (ExecDet.dynForLoop (N := steps) (N_max := cp.B_scan) (C_b := 2 * ops.C_read + 240)
    27 30 _ InvCopy hfpS (by omega) (by omega) (by unfold M_slots at hBW_scr; omega)
    (by decide) hr30_S hsteps_le_B hInv0 ?_).mono
    (fun m ⟨⟨hsrm, hndm, hftm, hfmm, hfam, hfsm, hfrm⟩, _, _, _, hwcurm, hencm⟩ _ => ?_)
    (by clear * -; nlinarith)
  · intro k hk m ⟨hFC, hr20, hr21, hr22, hwcur_k, hsnap_k⟩ hctr hfp
    have hk_le : cs.copyCur + k ≤ cs.L_hist := by omega
    rcases advanceCopyLoop_spec htgt_set k hk_le hcs_inv with ⟨hLk, hcurk_eq, hinv_k, _⟩
    change (csAt k).L_hist = cs.L_hist at hLk
    change (csAt k).copyCur = cs.copyCur + k at hcurk_eq
    change CopyStateInv prevNode.histArr T_end (csAt k) at hinv_k
    have hcur_lt_hist : (csAt k).copyCur < prevNode.histArr.length := by
      have h1 : cs.copyCur + k < cs.L_hist := by dsimp [steps] at hk; omega
      have h2 := hcs_inv.2.1
      omega
    set x := prevNode.histArr[(csAt k).copyCur]'hcur_lt_hist
    have hpR_m : wRead m engScrTbl prevSlotR = (prevSlot : ℤ) :=
      (hFC.2.2.2.2.2.1 prevSlotR hpR20).trans hread_pR
    unfold advanceCopyIterBodyStmt
    -- 1. Load `(csAt k).copyCur` into `29`
    refine ExecDet.seq' (2 * ops.C_read + 228)
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 29) (.readHeap engMetaTbl (.lit (base + 4)))
        29 ((csAt k).copyCur : ℤ) hfp (by unfold engScrTbl; omega) (by omega)
        (by unfold M_slots at hBW_scr; omega) rfl
        (by simp only [evalIntExpr]; exact hwcur_k) (by simp [intExprOps]) rfl)
      (by clear * -; nlinarith) ?_
    intro m1 hm1 hfp1; subst hm1
    set m1_st := H3a.wWrite m engScrTbl 29 ((csAt k).copyCur : ℤ)
    have hw9_1 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m1_st t i = wRead m t i :=
      fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
    have hsr1 : ops.SlotsReady m1_st :=
      ops.slotsReady_ext m m1_st hFC.1 hw9_1 (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
    have henc_prev1 : ops.EncNode prevNode prevSlot m1_st :=
      ops.encNode_ext prevNode prevSlot m m1_st (hFC.2.1 prevNode prevSlot hpSlot henc_prev)
        hw9_1 (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
    -- 2. `readNodeArrElemStmt .hist prevSlotR 29 23`
    refine ExecDet.seq' (ops.C_read + 228)
      (ops.readNodeArrElem_spec inp m1_st prevNode prevSlot (csAt k).copyCur .hist hcur_lt_hist
        prevSlotR 29 23 hpSlot hpR0 (by omega) (by omega) (by omega) (by omega) (by omega)
        hfp1 hsr1 henc_prev1
        ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hpR_m)
        (wRead_wWrite_self _ _ _ _))
      (by clear * -; nlinarith) ?_
    intro m2 ⟨hsr2, hr23, hnd2, hft2, hfs2, hfr2⟩ hfp2
    dsimp only [evalNodeArr] at hr23
    change wRead m2 engScrTbl 23 = (x : ℤ) at hr23
    -- 3. `containsNodeArrStmt useRes prevSlotR 23 24`
    refine ExecDet.seq' 228
      (ops.containsNodeArr_spec inp m2 pts prevNode prevSlot x useRes prevSlotR 23 24
        hpSlot hprev_cur_n hprev_wf hpR0 (by omega) (by omega) (by omega) (by omega) (by omega)
        hfp2 hsr2 (hnd2 prevNode prevSlot hpSlot henc_prev1)
        ((hfs2 prevSlotR (by omega)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hpR_m))
        hr23)
      (by omega) ?_
    intro m3 ⟨hsr3, hr24, hnd3, hft3, hfs3, hfr3⟩ hfp3
    change wRead m3 engScrTbl 24 = (if tgtArr.contains x then 1 else 0) at hr24
    have hsnap3 : EncSparseSet cp.n (base + 5) (snapElemOff cp r.val) (snapPosOff cp r.val) (csAt k).snapArr m3 :=
      hsnap_k.ext
        ((hft3 engMetaTbl (by decide) (by decide) _).trans
          ((hft2 engMetaTbl (by decide) (by decide) _).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))))
        (fun _ _ => (hft3 engArrTbl (by decide) (by decide) _).trans
          ((hft2 engArrTbl (by decide) (by decide) _).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))))
        (fun _ _ => (hft3 engArrTbl (by decide) (by decide) _).trans
          ((hft2 engArrTbl (by decide) (by decide) _).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))))
    have hr20_3 : wRead m3 engScrTbl 20 = base + 5 :=
      (hfs3 20 (by decide)).trans ((hfs2 20 (by decide)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr20))
    have hr21_3 : wRead m3 engScrTbl 21 = snapElemOff cp r.val :=
      (hfs3 21 (by decide)).trans ((hfs2 21 (by decide)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr21))
    have hr22_3 : wRead m3 engScrTbl 22 = snapPosOff cp r.val :=
      (hfs3 22 (by decide)).trans ((hfs2 22 (by decide)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr22))
    have hr23_3 : wRead m3 engScrTbl 23 = (x : ℤ) := (hfs3 23 (by decide)).trans hr23
    -- 4. `sparseContainsStmt cp.n 20 21 22 23 25`
    refine ExecDet.seq' 128
      (exec_sparseContainsStmt inp 20 21 22 23 25 (by omega) (by unfold M_slots at hBW_scr; omega)
        (by decide) (by decide) (by decide) (by decide) (by omega) (by omega)
        hfp3 hsnap3 hr20_3 hr21_3 hr22_3 hr23_3)
      (by omega) ?_
    intro m4 ⟨hr25, hft4, hfs4, hfr4⟩ hfp4
    have hr24_4 : wRead m4 engScrTbl 24 = (if tgtArr.contains x then 1 else 0) :=
      (hfs4 24 (by omega) (by decide)).trans hr24
    have hsnap4 : EncSparseSet cp.n (base + 5) (snapElemOff cp r.val) (snapPosOff cp r.val) (csAt k).snapArr m4 :=
      hsnap3.ext (hft4 engMetaTbl (by decide) _)
        (fun _ _ => hft4 engArrTbl (by decide) _)
        (fun _ _ => hft4 engArrTbl (by decide) _)
    -- 5. Conditional `sparseInsertFreshStmt`
    let snap' := if tgtArr.contains x && !(csAt k).snapArr.contains x then
        denseInsert x (csAt k).snapArr else (csAt k).snapArr
    have hcs_succ : csAt (k + 1) = { (csAt k) with copyCur := (csAt k).copyCur + 1, snapArr := snap' } := by
      dsimp only [csAt]
      rw [advanceCopyLoop_succ_right]
      unfold advanceCopyOne
      rw [dif_pos hcur_lt_hist]
    have hcond_ins : (evalArithCond inp 0 m4
        (.and (.intEq (.readHeap engScrTbl (.lit 24)) (.lit 1))
              (.intEq (.readHeap engScrTbl (.lit 25)) (.lit 0)))).1 =
        (tgtArr.contains x && !(csAt k).snapArr.contains x) := by
      simp only [evalArithCond, evalIntExpr]
      change (decide (wRead m4 engScrTbl 24 = 1) && decide (wRead m4 engScrTbl 25 = 0)) = _
      rw [hr24_4, hr25]
      cases tgtArr.contains x <;> cases (csAt k).snapArr.contains x <;> rfl
    have hStep5 : ExecDet ops.TW ops.BW ops.TR ops.BR inp
        (.ite (.and (.intEq (.readHeap engScrTbl (.lit 24)) (.lit 1))
                    (.intEq (.readHeap engScrTbl (.lit 25)) (.lit 0)))
          (sparseInsertFreshStmt 20 21 22 23)
          .skip)
        m4
        (fun m5 =>
          EncSparseSet cp.n (base + 5) (snapElemOff cp r.val) (snapPosOff cp r.val) snap' m5 ∧
          (∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m5 t i = wRead m4 t i) ∧
          (∀ i, i ≠ base + 5 → wRead m5 engMetaTbl i = wRead m4 engMetaTbl i) ∧
          (∀ i, (i < snapElemOff cp r.val ∨ snapElemOff cp r.val + (cp.n : ℤ) ≤ i) →
                (i < snapPosOff cp r.val ∨ snapPosOff cp r.val + (cp.n : ℤ) ≤ i) →
                wRead m5 engArrTbl i = wRead m4 engArrTbl i) ∧
          (∀ i, i < 56 → wRead m5 engScrTbl i = wRead m4 engScrTbl i) ∧
          (∀ t i, rRead m5 t i = rRead m4 t i))
        112 := by
      refine ExecDet.ite' (C_c := 12) (C_b := 100) _ _ _ hcond_ins
        (by simp [condExprOps, intExprOps]) (fun htrue => ?_) (fun hfalse => ?_) (by omega)
      · have hsnap_eq : snap' = denseInsert x (csAt k).snapArr := by dsimp [snap']; rw [if_pos htrue]
        rw [Bool.and_eq_true, Bool.not_eq_true'] at htrue
        have hx_in_T : x ∈ T_end := htgt_set ▸ List.mem_toFinset.mpr (List.contains_iff_mem.mp htrue.1)
        have hx_n : x < cp.n := hTend_n x hx_in_T
        have hx_not : x ∉ (csAt k).snapArr := fun hm =>
          absurd (List.contains_iff_mem.mpr hm) (by rw [htrue.2]; decide)
        refine (exec_sparseInsertFreshStmt inp 20 21 22 23
          (by omega) (by unfold M_slots at hBW_scr; omega)
          (by decide) (by decide) (by decide) (by decide)
          hSnapBounds.1 hSnapBounds.2.1 hSnapBounds.2.2.1 hSnapBounds.2.2.2.1
          hSnapBounds.2.2.2.2.1 hSnapBounds.2.2.2.2.2.1 hSnapBounds.2.2.2.2.2.2
          hx_n hx_not hfp4 hsnap4
          ((hfs4 20 (by omega) (by decide)).trans hr20_3)
          ((hfs4 21 (by omega) (by decide)).trans hr21_3)
          ((hfs4 22 (by omega) (by decide)).trans hr22_3)
          ((hfs4 23 (by omega) (by decide)).trans hr23_3)).mono ?_ le_rfl
        intro m5 ⟨henc5, hft5, hfm5, hfa5, hfs5, hfr5⟩ _
        have hlen_lt : ((csAt k).snapArr).length < cp.n := by
          have h1 := henc5.length_le
          unfold denseInsert at h1; rw [List.length_append, List.length_singleton] at h1; omega
        rw [← hsnap_eq] at henc5
        refine ⟨henc5, hft5, hfm5, fun i he hp => hfa5 i (by omega) (by omega), hfs5, hfr5⟩
      · have hsnap_eq : snap' = (csAt k).snapArr := by dsimp [snap']; rw [if_neg (by rw [hfalse]; decide)]
        refine ExecDet.skip inp hfp4 ?_ (by omega)
        exact ⟨hsnap_eq ▸ hsnap4, fun _ _ _ _ _ => rfl, fun _ _ => rfl,
          fun _ _ _ => rfl, fun _ _ => rfl, fun _ _ => rfl⟩
    refine ExecDet.seq' 16 hStep5 (by omega) ?_
    intro m5 ⟨henc5, hft5, hfm5, hfa5, hfs5, hfr5⟩ hfp5
    have hr29_5 : wRead m5 engScrTbl 29 = ((csAt k).copyCur : ℤ) :=
      (hfs5 29 (by omega)).trans ((hfs4 29 (by omega) (by decide)).trans
        ((hfs3 29 (by decide)).trans ((hfs2 29 (by decide)).trans (wRead_wWrite_self _ _ _ _))))
    have hr27_5 : wRead m5 engScrTbl 27 = (k : ℤ) :=
      (hfs5 27 (by omega)).trans ((hfs4 27 (by omega) (by decide)).trans
        ((hfs3 27 (by decide)).trans ((hfs2 27 (by decide)).trans
          ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hctr))))
    -- 6. Increment `base + 4` (`copyCur + 1`)
    refine ExecDet.wWrite (C := 16) inp engMetaTbl (.lit (base + 4))
      (.add (.readHeap engScrTbl (.lit 29)) (.lit 1))
      (base + 4) (((csAt k).copyCur + 1 : ℕ) : ℤ)
      hfp5 (by unfold engMetaTbl; omega) (by unfold base jobMetaBase; omega)
      (by have := hSnapBounds.2.1; omega) rfl
      (by simp only [evalIntExpr]; change wRead m5 engScrTbl 29 + 1 = _; rw [hr29_5]; push_cast; rfl)
      (by simp [intExprOps]) ?_
    set m6 := H3a.wWrite m5 engMetaTbl (base + 4) (((csAt k).copyCur + 1 : ℕ) : ℤ)
    set mN := H3a.wWrite m6 engScrTbl 27 ((k : ℤ) + 1)
    have hw9_N3 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mN t i = wRead m3 t i := fun t ht9 _ i => by
      have ht_ne6 : t ≠ engMetaTbl := by unfold engMetaTbl; omega
      have ht_ne7 : t ≠ engArrTbl := by unfold engArrTbl; omega
      have ht_ne8 : t ≠ engScrTbl := by unfold engScrTbl; omega
      exact (wRead_wWrite_of_ne _ _ (Or.inl ht_ne8)).trans
        ((wRead_wWrite_of_ne _ _ (Or.inl ht_ne6)).trans
          ((hft5 t ht_ne6 ht_ne7 ht_ne8 i).trans (hft4 t ht_ne8 i)))
    have hr_N3 : ∀ t i, rRead mN t i = rRead m3 t i := fun t i =>
      (rRead_wWrite _ _ _ _ _ _).trans ((rRead_wWrite _ _ _ _ _ _).trans
        ((hfr5 t i).trans (hfr4 t i)))
    refine ⟨(wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hr27_5,
      ⟨ops.slotsReady_ext m3 mN hsr3 hw9_N3 (fun t _ _ i => hr_N3 t i),
       fun mn' s hs he0 => ops.encNode_ext mn' s m3 mN
         (hnd3 mn' s hs (hnd2 mn' s hs
           (ops.encNode_ext mn' s m m1_st (hFC.2.1 mn' s hs he0) hw9_1
             (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))))
         hw9_N3 (fun t _ _ i => hr_N3 t i) (fun _ _ _ _ => hr_N3 ptsRTbl _),
       fun t ht9 ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans
         ((wRead_wWrite_of_ne _ _ (Or.inl ht1)).trans
           ((hft5 t ht1 ht2 ht3 i).trans ((hft4 t ht3 i).trans
             ((hft3 t ht9 ht3 i).trans ((hft2 t ht9 ht3 i).trans
               ((wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans (hFC.2.2.1 t ht9 ht1 ht2 ht3 i))))))),
       fun i h4 h5 => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
         ((wRead_wWrite_of_ne _ _ (Or.inr h4)).trans
           ((hfm5 i h5).trans ((hft4 engMetaTbl (by decide) i).trans
             ((hft3 engMetaTbl (by decide) (by decide) i).trans
               ((hft2 engMetaTbl (by decide) (by decide) i).trans
                 ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hFC.2.2.2.1 i h4 h5))))))),
       fun i he hp => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
         ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
           ((hfa5 i he hp).trans ((hft4 engArrTbl (by decide) i).trans
             ((hft3 engArrTbl (by decide) (by decide) i).trans
               ((hft2 engArrTbl (by decide) (by decide) i).trans
                 ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hFC.2.2.2.2.1 i he hp))))))),
       fun i hi20 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans
         ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
           ((hfs5 i (by omega)).trans ((hfs4 i (by omega) (by omega)).trans
             ((hfs3 i (by omega)).trans ((hfs2 i (by omega)).trans
               ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hFC.2.2.2.2.2.1 i hi20))))))),
       fun t ht3 i => (hr_N3 t i).trans ((hfr3 t ht3 i).trans
         ((hfr2 t ht3 i).trans ((rRead_wWrite _ _ _ _ _ _).trans (hFC.2.2.2.2.2.2 t ht3 i))))⟩,
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
        ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfs5 20 (by omega)).trans ((hfs4 20 (by omega) (by decide)).trans hr20_3))),
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
        ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfs5 21 (by omega)).trans ((hfs4 21 (by omega) (by decide)).trans hr21_3))),
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
        ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfs5 22 (by omega)).trans ((hfs4 22 (by omega) (by decide)).trans hr22_3))),
      by rw [hcs_succ]; dsimp only [mN, m6]
         rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self],
      by rw [hcs_succ]; dsimp only [mN, m6]
         exact henc5.ext
           ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
             (wRead_wWrite_of_ne _ _ (Or.inr (by omega))))
           (fun _ _ => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
             (wRead_wWrite_of_ne _ _ (Or.inl (by decide))))
           (fun _ _ => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
             (wRead_wWrite_of_ne _ _ (Or.inl (by decide))))⟩
  · have hL_final : cs'.L_hist = cs.L_hist := (advanceCopyLoop_spec htgt_set steps hsteps_le_rem hcs_inv).1
    have hwL_m : wRead m engMetaTbl (base + 3) = (cs'.L_hist : ℤ) := by
      rw [hL_final]; exact (hfmm (base + 3) (by omega) (by omega)).trans hw_L
    exact ⟨hsrm, hwL_m, hwcurm, hencm, hndm, hftm, hfmm, hfam, hfsm, hfrm⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
