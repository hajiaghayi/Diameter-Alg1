import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3a_FilterPure
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

open UL
open UL.Proof_clm_6_1_precision_RaceV30
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2

/-! ### 1. Pure Heap-Mirrored `LiveSlot` State & Single-Node DLL Primitives -/

def truncMul (K : ℕ) {ℓ : ℕ} (cnt : Fin ℓ → ℕ) : ℕ :=
  Fin.foldl ℓ (fun acc s => min K (acc * cnt s)) (min K 1)

structure LiveSlot (R ℓ M₀ d : ℕ) where
  ep : ℕ
  blkId : ℤ
  builtCnt : ℕ
  caps : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1))
  hEp : ℕ → ℕ
  hVal : ℕ → ℤ
  nEp : ℕ → ℕ
  nBkt : ℕ → ℕ
  nEid : ℕ → ℕ
  nPrev : ℕ → ℤ
  nNext : ℕ → ℤ

noncomputable def LiveSlot.empty (R ℓ M₀ d : ℕ) : LiveSlot R ℓ M₀ d :=
  { ep := 1
    blkId := -1
    builtCnt := 0
    caps := fun _ => 0
    hEp := fun _ => 0
    hVal := fun _ => -1
    nEp := fun _ => 0
    nBkt := fun _ => 0
    nEid := fun _ => 0
    nPrev := fun _ => -1
    nNext := fun _ => -1 }

noncomputable def LiveSlot.zeroMem (R ℓ M₀ d : ℕ) : LiveSlot R ℓ M₀ d :=
  { ep := 1
    blkId := -1
    builtCnt := 0
    caps := fun _ => 0
    hEp := fun _ => 0
    hVal := fun _ => 0
    nEp := fun _ => 0
    nBkt := fun _ => 0
    nEid := fun _ => 0
    nPrev := fun _ => 0
    nNext := fun _ => 0 }

def LiveSlot.clear {R ℓ M₀ d : ℕ} (newEp : ℕ) (S : LiveSlot R ℓ M₀ d) : LiveSlot R ℓ M₀ d :=
  { S with
    ep := newEp
    blkId := -1
    builtCnt := 0 }

def LiveSlot.effHead {R ℓ M₀ d : ℕ} (S : LiveSlot R ℓ M₀ d) (bkt : ℕ) : ℤ :=
  if S.hEp bkt = S.ep then S.hVal bkt else -1

noncomputable def LiveSlot.init {R ℓ M₀ d b : ℕ} (newEp : ℕ) (newBlk : ℤ)
    (T p_coord : ℕ) (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (S : LiveSlot R ℓ M₀ d) : LiveSlot R ℓ M₀ d :=
  { S with
    ep := newEp
    blkId := newBlk
    builtCnt := 0
    caps := polyFDisc T p_coord ω }

def LiveSlot.pushNode {R ℓ M₀ d : ℕ} (bkt nd eid : ℕ)
    (S : LiveSlot R ℓ M₀ d) : LiveSlot R ℓ M₀ d :=
  let oldH := S.effHead bkt
  let prev1 := Function.update S.nPrev nd (-1)
  let next1 := Function.update S.nNext nd oldH
  let prev2 := if oldH < 0 then prev1 else Function.update prev1 oldH.toNat (nd : ℤ)
  { S with
    hEp := Function.update S.hEp bkt S.ep
    hVal := Function.update S.hVal bkt (nd : ℤ)
    nEp := Function.update S.nEp nd S.ep
    nBkt := Function.update S.nBkt nd bkt
    nEid := Function.update S.nEid nd eid
    nPrev := prev2
    nNext := next1 }

def LiveSlot.unlinkNode {R ℓ M₀ d : ℕ} (nd : ℕ)
    (S : LiveSlot R ℓ M₀ d) : LiveSlot R ℓ M₀ d :=
  if S.nEp nd = S.ep then
    let bkt := S.nBkt nd
    let p := S.nPrev nd
    let nx := S.nNext nd
    let hEp' := if p < 0 then Function.update S.hEp bkt S.ep else S.hEp
    let hVal' := if p < 0 then Function.update S.hVal bkt nx else S.hVal
    let prev' := if nx < 0 then S.nPrev else Function.update S.nPrev nx.toNat p
    let next' := if p < 0 then S.nNext else Function.update S.nNext p.toNat nx
    { S with
      hEp := hEp'
      hVal := hVal'
      nEp := Function.update S.nEp nd 0
      nPrev := prev'
      nNext := next' }
  else
    S

def LiveSlot.unlinkLoc {R ℓ M₀ d : ℕ} (C_nd loc : ℕ)
    (S : LiveSlot R ℓ M₀ d) : LiveSlot R ℓ M₀ d :=
  Fin.foldl C_nd (fun cur (sub : Fin C_nd) => cur.unlinkNode (loc * C_nd + sub.val)) S

noncomputable def LiveSlot.insertCopy {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (A B_rat τ_d : ℚ) (cap_u loc eid : ℕ) (w : EuclideanSpace ℝ (Fin d))
    (r : Fin R) (S : LiveSlot R ℓ M₀ d) : LiveSlot R ℓ M₀ d :=
  open Classical in
  let eligList : Fin ℓ → List (Fin M₀) := fun s =>
    (List.finRange M₀).filter (fun k =>
      realSignedSqCapCond (A : ℝ) (B_rat : ℝ) (τ_d : ℝ) (S.caps (r, s, k)) w)
  let cnt : Fin ℓ → ℕ := fun s => (eligList s).length
  let prodCap := truncMul (cap_u + 1) cnt
  if (∀ s : Fin ℓ, 1 ≤ cnt s) ∧ prodCap ≤ cap_u then
    let elig : Fin ℓ → ℕ → ℕ := fun s j =>
      if hj : j < (eligList s).length then ((eligList s)[j]).val else 0
    Fin.foldl prodCap (fun cur (j : Fin prodCap) =>
      let τ := mixedTuple hM₀ cnt elig j.val
      let code := encodeTuple τ
      let bkt := r.val * M₀ ^ ℓ + code
      let nd := (loc * R + r.val) * cap_u + j.val
      cur.pushNode bkt nd eid) S
  else
    S

noncomputable def LiveSlot.insertRecord {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (A B_rat τ_d : ℚ) (cap_u eid : ℕ) (alive : Bool)
    (o pt : EuclideanSpace ℝ (Fin d)) (S : LiveSlot R ℓ M₀ d) : LiveSlot R ℓ M₀ d :=
  let loc := S.builtCnt
  let S₁ := if alive then
    Fin.foldl R (fun cur r => cur.insertCopy hM₀ A B_rat τ_d cap_u loc eid (pt - o) r) S
  else
    S
  { S₁ with builtCnt := loc + 1 }

/-! ### 2. Structural Invariant `LiveSlotListInv` & `LiveSlot.WF` -/

def LiveSlotListInv {R ℓ M₀ d : ℕ} (cap_u B_max blkStart : ℕ)
    (ndL : Fin R → Fin (M₀ ^ ℓ) → List ℕ) (S : LiveSlot R ℓ M₀ d) : Prop :=
  let N_bkt := R * M₀ ^ ℓ
  let C_nd := R * cap_u
  let N_pool := B_max * C_nd
  1 ≤ S.ep ∧
  (∀ bkt < N_bkt, S.hEp bkt ≤ S.ep) ∧
  (∀ nd < N_pool, S.nEp nd ≤ S.ep) ∧
  (∀ (r : Fin R) (code : Fin (M₀ ^ ℓ)),
    IsBucketDLL (ndL r code) (S.effHead (r.val * M₀ ^ ℓ + code.val)) S.nPrev S.nNext ∧
    ∀ nd ∈ ndL r code,
      nd < N_pool ∧
      S.nEp nd = S.ep ∧
      S.nBkt nd = r.val * M₀ ^ ℓ + code.val ∧
      S.nEid nd = blkStart + nd / C_nd) ∧
  (∀ nd < N_pool, S.nEp nd = S.ep ↔ ∃ (r : Fin R) (code : Fin (M₀ ^ ℓ)), nd ∈ ndL r code)

def LiveSlot.WF {R ℓ M₀ d : ℕ} (cap_u B_max blkStart : ℕ)
    (entryAlive : ℕ → Bool) (pSlot : PureFilterSlot R ℓ M₀ d)
    (S : LiveSlot R ℓ M₀ d) : Prop :=
  S.builtCnt ≤ B_max ∧
  S.caps = pSlot.caps ∧
  ∃ ndL : Fin R → Fin (M₀ ^ ℓ) → List ℕ,
    LiveSlotListInv cap_u B_max blkStart ndL S ∧
    ∀ (r : Fin R) (code : Fin (M₀ ^ ℓ)),
      (∀ nd ∈ ndL r code, nd / (R * cap_u) < S.builtCnt) ∧
      (ndL r code).map S.nEid = (pSlot.buckets r code).filter entryAlive

private lemma bkt_code_inj {R M₀ ℓ : ℕ} (hm_pos : 1 ≤ M₀) {r₁ r₂ : Fin R} {c₁ c₂ : Fin (M₀ ^ ℓ)}
    (heq : r₁.val * M₀ ^ ℓ + c₁.val = r₂.val * M₀ ^ ℓ + c₂.val) :
    r₁ = r₂ ∧ c₁ = c₂ := by
  have hc1 := c₁.isLt
  have hc2 := c₂.isLt
  have hMpow : 0 < M₀ ^ ℓ := Nat.pow_pos hm_pos
  have hdiv : (r₁.val * M₀ ^ ℓ + c₁.val) / M₀ ^ ℓ = (r₂.val * M₀ ^ ℓ + c₂.val) / M₀ ^ ℓ :=
    congrArg (· / M₀ ^ ℓ) heq
  rw [mul_comm r₁.val, mul_comm r₂.val, Nat.mul_add_div hMpow, Nat.div_eq_of_lt hc1, add_zero,
      Nat.mul_add_div hMpow, Nat.div_eq_of_lt hc2, add_zero] at hdiv
  rw [hdiv] at heq; exact ⟨Fin.ext hdiv, Fin.ext (by omega)⟩

theorem LiveSlot.listInv_pushNode {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀) {cap_u B_max blkStart : ℕ}
    {ndL : Fin R → Fin (M₀ ^ ℓ) → List ℕ} {S : LiveSlot R ℓ M₀ d}
    (hinv : LiveSlotListInv cap_u B_max blkStart ndL S)
    (r₀ : Fin R) (code₀ : Fin (M₀ ^ ℓ)) {nd : ℕ}
    (hnd_pool : nd < B_max * (R * cap_u))
    (hgt : ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ z ∈ ndL r c, z < nd) :
    let bkt₀ := r₀.val * M₀ ^ ℓ + code₀.val
    let eid₀ := blkStart + nd / (R * cap_u)
    let S' := S.pushNode bkt₀ nd eid₀
    let ndL' : Fin R → Fin (M₀ ^ ℓ) → List ℕ := fun r c =>
      if r = r₀ ∧ c = code₀ then nd :: ndL r c else ndL r c
    LiveSlotListInv cap_u B_max blkStart ndL' S' ∧
    S'.ep = S.ep ∧ S'.caps = S.caps ∧ S'.builtCnt = S.builtCnt ∧ S'.blkId = S.blkId ∧
    (∀ z < nd, S'.nEid z = S.nEid z) ∧ S'.nEid nd = eid₀ := by
  rcases hinv with ⟨hep1, hhEp, hnEp, hrc, hiff⟩
  intro bkt₀ eid₀ S' ndL'
  have hbkt₀_lt : bkt₀ < R * M₀ ^ ℓ := by
    have hr := r₀.isLt; have hc := code₀.isLt
    calc r₀.val * M₀ ^ ℓ + code₀.val
        < r₀.val * M₀ ^ ℓ + M₀ ^ ℓ := by omega
      _ = (r₀.val + 1) * M₀ ^ ℓ := by ring
      _ ≤ R * M₀ ^ ℓ := Nat.mul_le_mul_right _ hr
  have hdll₀ := (hrc r₀ code₀).1
  have holdH_mem : S.effHead bkt₀ < 0 ∨ (S.effHead bkt₀).toNat ∈ ndL r₀ code₀ := by
    rcases hdll₀ with ⟨_, hhd, _⟩
    cases hL : ndL r₀ code₀ with
    | nil => left; rw [hhd, hL]; simp [listHeadInt]
    | cons y ys =>
        right; rw [hhd, hL]
        simp only [listHeadInt, Int.toNat_natCast]
        exact List.mem_cons_self
  refine ⟨⟨hep1, ?_, ?_, ?_, ?_⟩, rfl, rfl, rfl, rfl,
    fun z hz => by dsimp [S', LiveSlot.pushNode]; exact Function.update_of_ne (by omega : z ≠ nd) _ _,
    by dsimp [S', LiveSlot.pushNode]; exact Function.update_self nd eid₀ S.nEid⟩
  · intro bkt hbkt
    dsimp [S', LiveSlot.pushNode]
    by_cases he : bkt = bkt₀
    · subst he; rw [Function.update_self]
    · rw [Function.update_of_ne he]; exact hhEp bkt hbkt
  · intro z hz
    dsimp [S', LiveSlot.pushNode]
    by_cases he : z = nd
    · subst he; rw [Function.update_self]
    · rw [Function.update_of_ne he]; exact hnEp z hz
  · intro r c
    by_cases hrc_eq : r = r₀ ∧ c = code₀
    · rcases hrc_eq with ⟨hr_eq, hc_eq⟩
      rw [hr_eq, hc_eq]
      dsimp only [ndL']
      rw [if_pos ⟨rfl, rfl⟩]
      have heff' : S'.effHead bkt₀ = (nd : ℤ) := by
        dsimp [S', LiveSlot.pushNode, LiveSlot.effHead]
        rw [Function.update_self, if_pos rfl, Function.update_self]
      refine ⟨?_, ?_⟩
      · rw [heff']
        exact isBucketDLL_push hdll₀ (hgt r₀ code₀)
      · intro z hz
        rcases List.mem_cons.mp hz with rfl | hz_old
        · exact ⟨hnd_pool, Function.update_self _ _ _, Function.update_self _ _ _, Function.update_self _ _ _⟩
        · have hz_lt : z < nd := hgt r₀ code₀ z hz_old
          rcases (hrc r₀ code₀).2 z hz_old with ⟨hp, he, hb, heid⟩
          exact ⟨hp,
            (Function.update_of_ne (by omega : z ≠ nd) _ _).trans he,
            (Function.update_of_ne (by omega : z ≠ nd) _ _).trans hb,
            (Function.update_of_ne (by omega : z ≠ nd) _ _).trans heid⟩
    · dsimp only [ndL']
      rw [if_neg hrc_eq]
      have hbkt_ne : r.val * M₀ ^ ℓ + c.val ≠ bkt₀ := fun h => hrc_eq (bkt_code_inj hM₀ h)
      have heff' : S'.effHead (r.val * M₀ ^ ℓ + c.val) = S.effHead (r.val * M₀ ^ ℓ + c.val) := by
        dsimp [S', LiveSlot.pushNode, LiveSlot.effHead]
        rw [Function.update_of_ne hbkt_ne, Function.update_of_ne hbkt_ne]
      refine ⟨?_, ?_⟩
      · rw [heff']
        refine isBucketDLL_congr_outside (hrc r c).1 fun z hz => ?_
        have hz_lt : z < nd := hgt r c z hz
        have hzb : S.nBkt z = r.val * M₀ ^ ℓ + c.val := ((hrc r c).2 z hz).2.2.1
        dsimp [S', LiveSlot.pushNode]
        refine ⟨?_, Function.update_of_ne (by omega : z ≠ nd) _ _⟩
        rcases holdH_mem with hneg | hmem₀
        · rw [if_pos hneg]; exact Function.update_of_ne (by omega : z ≠ nd) _ _
        · by_cases hneg : S.effHead bkt₀ < 0
          · rw [if_pos hneg]; exact Function.update_of_ne (by omega : z ≠ nd) _ _
          · rw [if_neg hneg]
            have hb₀ := ((hrc r₀ code₀).2 _ hmem₀).2.2.1
            have hne_hd : z ≠ (S.effHead bkt₀).toNat := fun heq => hbkt_ne (hzb ▸ heq ▸ hb₀)
            rw [Function.update_of_ne hne_hd, Function.update_of_ne (by omega : z ≠ nd)]
      · intro z hz
        have hz_lt : z < nd := hgt r c z hz
        rcases (hrc r c).2 z hz with ⟨hp, he, hb, heid⟩
        exact ⟨hp,
          (Function.update_of_ne (by omega : z ≠ nd) _ _).trans he,
          (Function.update_of_ne (by omega : z ≠ nd) _ _).trans hb,
          (Function.update_of_ne (by omega : z ≠ nd) _ _).trans heid⟩
  · intro z hz
    dsimp [S', LiveSlot.pushNode]
    by_cases he : z = nd
    · subst he
      rw [Function.update_self]
      exact ⟨fun _ => ⟨r₀, code₀, by dsimp [ndL']; rw [if_pos ⟨rfl, rfl⟩]; exact List.mem_cons_self⟩,
             fun _ => rfl⟩
    · rw [Function.update_of_ne he, hiff z hz]
      constructor
      · rintro ⟨r, c, hm⟩
        refine ⟨r, c, ?_⟩
        dsimp [ndL']
        split_ifs with hc
        · exact List.mem_cons_of_mem nd hm
        · exact hm
      · rintro ⟨r, c, hm⟩
        dsimp [ndL'] at hm
        split_ifs at hm with hc
        · rcases List.mem_cons.mp hm with h_eq | hm'
          · exact False.elim (he h_eq)
          · exact ⟨r, c, hm'⟩
        · exact ⟨r, c, hm⟩

theorem LiveSlot.listInv_unlinkNode {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀) {cap_u B_max blkStart : ℕ}
    {ndL : Fin R → Fin (M₀ ^ ℓ) → List ℕ} {S : LiveSlot R ℓ M₀ d}
    (hinv : LiveSlotListInv cap_u B_max blkStart ndL S)
    {nd : ℕ} (hnd_pool : nd < B_max * (R * cap_u)) :
    let S' := S.unlinkNode nd
    let ndL' : Fin R → Fin (M₀ ^ ℓ) → List ℕ := fun r c => (ndL r c).erase nd
    LiveSlotListInv cap_u B_max blkStart ndL' S' ∧
    S'.ep = S.ep ∧ S'.caps = S.caps ∧ S'.builtCnt = S.builtCnt ∧ S'.blkId = S.blkId ∧
    S'.nEid = S.nEid := by
  rcases hinv with ⟨hep1, hhEp, hnEp, hrc, hiff⟩
  dsimp only [LiveSlot.unlinkNode]
  by_cases hact : S.nEp nd = S.ep
  · rw [if_pos hact]
    obtain ⟨r₀, code₀, hmem₀⟩ := (hiff nd hnd_pool).mp hact
    have hbkt₀ : S.nBkt nd = r₀.val * M₀ ^ ℓ + code₀.val := ((hrc r₀ code₀).2 nd hmem₀).2.2.1
    let bkt₀ := r₀.val * M₀ ^ ℓ + code₀.val
    obtain ⟨hp_mem, hnx_mem, hdll_er⟩ := isBucketDLL_erase (hrc r₀ code₀).1 hmem₀
    have hdisj : ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ¬ (r = r₀ ∧ c = code₀) →
        ∀ z ∈ ndL r c, z ∉ ndL r₀ code₀ := by
      intro r c hne z hz hz0
      have hb1 := ((hrc r c).2 z hz).2.2.1
      have hb2 := ((hrc r₀ code₀).2 z hz0).2.2.1
      exact hne (bkt_code_inj hM₀ (hb1.symm.trans hb2))
    refine ⟨⟨hep1, ?_, ?_, ?_, ?_⟩, rfl, rfl, rfl, rfl, rfl⟩
    · intro bkt hbkt
      by_cases hp0 : S.nPrev nd < 0
      · dsimp only; rw [if_pos hp0]
        by_cases hb : bkt = S.nBkt nd
        · subst hb; rw [Function.update_self]
        · rw [Function.update_of_ne hb]; exact hhEp bkt hbkt
      · dsimp only; rw [if_neg hp0]; exact hhEp bkt hbkt
    · intro z hz
      dsimp only
      by_cases he : z = nd
      · subst he; rw [Function.update_self]; exact Nat.zero_le _
      · rw [Function.update_of_ne he]; exact hnEp z hz
    · intro r c
      by_cases hrc_eq : r = r₀ ∧ c = code₀
      · rcases hrc_eq with ⟨hr_eq, hc_eq⟩
        rw [hr_eq, hc_eq]
        dsimp only
        have heff' : (LiveSlot.effHead
            { S with
              hEp := if S.nPrev nd < 0 then Function.update S.hEp (S.nBkt nd) S.ep else S.hEp
              hVal := if S.nPrev nd < 0 then Function.update S.hVal (S.nBkt nd) (S.nNext nd) else S.hVal
              nEp := Function.update S.nEp nd 0
              nPrev := if S.nNext nd < 0 then S.nPrev else Function.update S.nPrev (S.nNext nd).toNat (S.nPrev nd)
              nNext := if S.nPrev nd < 0 then S.nNext else Function.update S.nNext (S.nPrev nd).toNat (S.nNext nd) }
            bkt₀) =
            (if S.nPrev nd < 0 then S.nNext nd else S.effHead bkt₀) := by
          unfold LiveSlot.effHead; dsimp only
          rw [hbkt₀]
          by_cases hp0 : S.nPrev nd < 0
          · rw [if_pos hp0, if_pos hp0, if_pos hp0, Function.update_self, if_pos rfl, Function.update_self]
          · rw [if_neg hp0, if_neg hp0, if_neg hp0]
        refine ⟨?_, ?_⟩
        · rw [heff']; exact hdll_er
        · intro z hz_er
          have hndup := chain_gt_nodup (hrc r₀ code₀).1.1
          have hz_ne : z ≠ nd := by
            rw [erase_eq_filter_ne_of_nodup nd hndup] at hz_er
            exact of_decide_eq_true (List.mem_filter.mp hz_er).2
          have hz_old : z ∈ ndL r₀ code₀ := List.mem_of_mem_erase hz_er
          rcases (hrc r₀ code₀).2 z hz_old with ⟨hp, he, hb, heid⟩
          exact ⟨hp, (Function.update_of_ne hz_ne _ _).trans he, hb, heid⟩
      · have hbkt_ne : r.val * M₀ ^ ℓ + c.val ≠ S.nBkt nd := by
          rw [hbkt₀]; exact fun h => hrc_eq (bkt_code_inj hM₀ h)
        have hnot_in : nd ∉ ndL r c := fun hm => hdisj r c hrc_eq nd hm hmem₀
        have her_eq : (ndL r c).erase nd = ndL r c := List.erase_of_not_mem hnot_in
        dsimp only
        rw [her_eq]
        have heff' : (LiveSlot.effHead
            { S with
              hEp := if S.nPrev nd < 0 then Function.update S.hEp (S.nBkt nd) S.ep else S.hEp
              hVal := if S.nPrev nd < 0 then Function.update S.hVal (S.nBkt nd) (S.nNext nd) else S.hVal
              nEp := Function.update S.nEp nd 0
              nPrev := if S.nNext nd < 0 then S.nPrev else Function.update S.nPrev (S.nNext nd).toNat (S.nPrev nd)
              nNext := if S.nPrev nd < 0 then S.nNext else Function.update S.nNext (S.nPrev nd).toNat (S.nNext nd) }
            (r.val * M₀ ^ ℓ + c.val)) = S.effHead (r.val * M₀ ^ ℓ + c.val) := by
          unfold LiveSlot.effHead; dsimp only
          by_cases hp0 : S.nPrev nd < 0
          · rw [if_pos hp0, if_pos hp0, Function.update_of_ne hbkt_ne, Function.update_of_ne hbkt_ne]
          · rw [if_neg hp0, if_neg hp0]
        refine ⟨?_, ?_⟩
        · rw [heff']
          refine isBucketDLL_congr_outside (hrc r c).1 fun z hz => ?_
          dsimp only
          constructor
          · by_cases hnx0 : S.nNext nd < 0
            · rw [if_pos hnx0]
            · rw [if_neg hnx0]
              rcases hnx_mem with hneg | ⟨w, hw0, hnw⟩
              · exfalso; omega
              · have hto : (S.nNext nd).toNat = w := by rw [hnw]; exact Int.toNat_natCast w
                rw [hto]
                exact Function.update_of_ne (fun hzw => by subst hzw; exact hdisj r c hrc_eq z hz hw0) _ _
          · by_cases hp0 : S.nPrev nd < 0
            · rw [if_pos hp0]
            · rw [if_neg hp0]
              rcases hp_mem with hneg | ⟨w, hw0, hpw⟩
              · exfalso; omega
              · have hto : (S.nPrev nd).toNat = w := by rw [hpw]; exact Int.toNat_natCast w
                rw [hto]
                exact Function.update_of_ne (fun hzw => by subst hzw; exact hdisj r c hrc_eq z hz hw0) _ _
        · intro z hz
          have hz_ne : z ≠ nd := fun h => hnot_in (h ▸ hz)
          rcases (hrc r c).2 z hz with ⟨hp, he, hb, heid⟩
          exact ⟨hp, (Function.update_of_ne hz_ne _ _).trans he, hb, heid⟩
    · intro z hz
      dsimp only
      by_cases he : z = nd
      · subst he
        rw [Function.update_self]
        refine ⟨fun h0 => by omega, ?_⟩
        rintro ⟨r, c, hm⟩
        have hndup := chain_gt_nodup (hrc r c).1.1
        rw [erase_eq_filter_ne_of_nodup z hndup] at hm
        exact absurd rfl (of_decide_eq_true (List.mem_filter.mp hm).2)
      · rw [Function.update_of_ne he, hiff z hz]
        constructor
        · rintro ⟨r, c, hm⟩
          have hndup := chain_gt_nodup (hrc r c).1.1
          refine ⟨r, c, ?_⟩
          rw [erase_eq_filter_ne_of_nodup nd hndup]
          exact List.mem_filter.mpr ⟨hm, decide_eq_true he⟩
        · rintro ⟨r, c, hm⟩
          exact ⟨r, c, List.mem_of_mem_erase hm⟩
  · rw [if_neg hact]
    have hnot_all : ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), nd ∉ ndL r c :=
      fun r c hm => hact ((hiff nd hnd_pool).mpr ⟨r, c, hm⟩)
    have her_id : (fun (r : Fin R) (c : Fin (M₀ ^ ℓ)) => (ndL r c).erase nd) = ndL := by
      funext r c; exact List.erase_of_not_mem (hnot_all r c)
    rw [her_id]
    exact ⟨⟨hep1, hhEp, hnEp, hrc, hiff⟩, rfl, rfl, rfl, rfl, rfl⟩

/-! ### 3. High-Level `LiveSlot.WF` Preservation (`empty`, `init`, `unlinkLoc`, `insertRecord`) -/

theorem LiveSlot.wf_empty {R ℓ M₀ d : ℕ} (cap_u B_max : ℕ) (entryAlive : ℕ → Bool)
    (T p_coord : ℕ) :
    (LiveSlot.empty R ℓ M₀ d).WF cap_u B_max 0 entryAlive
      { caps := fun _ => 0, buckets := fun _ _ => [] } := by
  let _ := (T, p_coord)
  refine ⟨Nat.zero_le _, rfl, fun _ _ => [], ?_, fun _ _ => ⟨fun _ h => (by cases h), rfl⟩⟩
  refine ⟨le_rfl, fun _ _ => Nat.zero_le 1, fun _ _ => Nat.zero_le 1, fun r c => ?_, fun _ _ => ?_⟩
  · refine ⟨?_, fun _ h => by cases h⟩
    have heff : (LiveSlot.empty R ℓ M₀ d).effHead (r.val * M₀ ^ ℓ + c.val) = -1 := rfl
    rw [heff]; exact isBucketDLL_nil _ _
  · simp [LiveSlot.empty]

theorem LiveSlot.wf_zeroMem {R ℓ M₀ d : ℕ} (cap_u B_max : ℕ) (entryAlive : ℕ → Bool) :
    (LiveSlot.zeroMem R ℓ M₀ d).WF cap_u B_max 0 entryAlive
      { caps := fun _ => 0, buckets := fun _ _ => [] } := by
  refine ⟨Nat.zero_le _, rfl, fun _ _ => [], ?_, fun _ _ => ⟨fun _ h => (by cases h), rfl⟩⟩
  refine ⟨le_rfl, fun _ _ => Nat.zero_le 1, fun _ _ => Nat.zero_le 1, fun r c => ?_, fun _ _ => ?_⟩
  · refine ⟨?_, fun _ h => by cases h⟩
    have heff : (LiveSlot.zeroMem R ℓ M₀ d).effHead (r.val * M₀ ^ ℓ + c.val) = -1 := rfl
    rw [heff]; exact isBucketDLL_nil _ _
  · simp [LiveSlot.zeroMem]

theorem LiveSlot.wf_clear {R ℓ M₀ d : ℕ} {cap_u B_max blkStart : ℕ}
    {entryAlive : ℕ → Bool} {pSlot : PureFilterSlot R ℓ M₀ d} {S : LiveSlot R ℓ M₀ d}
    (hwf : S.WF cap_u B_max blkStart entryAlive pSlot)
    {newEp : ℕ} (hgt : S.ep < newEp) (newBlkStart : ℕ) (newAlive : ℕ → Bool) :
    (S.clear newEp).WF cap_u B_max newBlkStart newAlive
      { caps := S.caps, buckets := fun _ _ => [] } := by
  rcases hwf with ⟨_, _, _, ⟨_, hhEp, hnEp, _, _⟩, _⟩
  refine ⟨Nat.zero_le _, rfl, fun _ _ => [], ?_, fun _ _ => ⟨fun _ h => (by cases h), rfl⟩⟩
  refine ⟨by dsimp [LiveSlot.clear]; omega, fun bkt hb => le_trans (hhEp bkt hb) (le_of_lt hgt),
    fun nd hn => le_trans (hnEp nd hn) (le_of_lt hgt), fun r c => ?_, fun nd hn => ?_⟩
  · refine ⟨?_, fun _ h => by cases h⟩
    have hlt_ep : S.hEp (r.val * M₀ ^ ℓ + c.val) < newEp := by
      have hc := c.isLt
      have hr := r.isLt
      have hb : r.val * M₀ ^ ℓ + c.val < R * M₀ ^ ℓ := by
        calc r.val * M₀ ^ ℓ + c.val < r.val * M₀ ^ ℓ + M₀ ^ ℓ := by omega
          _ = (r.val + 1) * M₀ ^ ℓ := by ring
          _ ≤ R * M₀ ^ ℓ := Nat.mul_le_mul_right _ hr
      exact lt_of_le_of_lt (hhEp _ hb) hgt
    have heff : (S.clear newEp).effHead (r.val * M₀ ^ ℓ + c.val) = -1 := by
      dsimp [LiveSlot.effHead, LiveSlot.clear]
      rw [if_neg (by omega)]
    rw [heff]; exact isBucketDLL_nil _ _
  · dsimp [LiveSlot.clear]
    have hlt_n : S.nEp nd < newEp := lt_of_le_of_lt (hnEp nd hn) hgt
    exact ⟨fun heq => by omega, fun ⟨_, _, h⟩ => by cases h⟩

theorem LiveSlot.wf_init {R ℓ M₀ d b : ℕ} {cap_u B_max blkStart : ℕ}
    {entryAlive : ℕ → Bool} {pSlot : PureFilterSlot R ℓ M₀ d} {S : LiveSlot R ℓ M₀ d}
    (hwf : S.WF cap_u B_max blkStart entryAlive pSlot)
    {newEp : ℕ} (hgt : S.ep < newEp) (newBlk : ℤ) (newBlkStart : ℕ)
    (T p_coord : ℕ) (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b) :
    (S.init newEp newBlk T p_coord ω).WF cap_u B_max newBlkStart entryAlive
      (PureFilterSlot.init T p_coord ω) := by
  rcases hwf with ⟨_, _, ndL, ⟨hep1, hhEp, hnEp, _, _⟩, _⟩
  refine ⟨Nat.zero_le _, rfl, fun _ _ => [], ?_, fun _ _ => ⟨fun _ h => (by cases h), rfl⟩⟩
  refine ⟨by dsimp [LiveSlot.init]; omega,
    fun bkt hb => le_of_lt (lt_of_le_of_lt (hhEp bkt hb) hgt),
    fun nd hn => le_of_lt (lt_of_le_of_lt (hnEp nd hn) hgt),
    fun r c => ?_,
    fun nd hn => ?_⟩
  · refine ⟨?_, fun _ h => by cases h⟩
    have heff : (S.init newEp newBlk T p_coord ω).effHead (r.val * M₀ ^ ℓ + c.val) = -1 := by
      unfold LiveSlot.effHead LiveSlot.init; dsimp only
      have hb : r.val * M₀ ^ ℓ + c.val < R * M₀ ^ ℓ := by
        have hr := r.isLt; have hc := c.isLt
        calc r.val * M₀ ^ ℓ + c.val < r.val * M₀ ^ ℓ + M₀ ^ ℓ := by omega
          _ = (r.val + 1) * M₀ ^ ℓ := by ring
          _ ≤ R * M₀ ^ ℓ := Nat.mul_le_mul_right _ hr
      have := hhEp _ hb
      rw [if_neg (by omega)]
    rw [heff]; exact isBucketDLL_nil _ _
  · dsimp [LiveSlot.init]
    have := hnEp nd hn
    exact ⟨fun heq => by omega, fun ⟨_, _, hm⟩ => by cases hm⟩

theorem LiveSlot.wf_unlinkLoc {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀) {cap_u B_max blkStart : ℕ}
    {entryAlive : ℕ → Bool} {pSlot : PureFilterSlot R ℓ M₀ d} {S : LiveSlot R ℓ M₀ d}
    (hwf : S.WF cap_u B_max blkStart entryAlive pSlot)
    {loc : ℕ} (hloc : loc < B_max) :
    let C_nd := R * cap_u
    let e_del := blkStart + loc
    let S' := S.unlinkLoc C_nd loc
    S'.WF cap_u B_max blkStart (Function.update entryAlive e_del false) pSlot ∧
    S'.ep = S.ep ∧ S'.caps = S.caps ∧ S'.builtCnt = S.builtCnt ∧ S'.blkId = S.blkId := by
  rcases hwf with ⟨hbc, hcaps, ndL₀, hinv₀, hmap₀⟩
  let C_nd := R * cap_u
  let e_del := blkStart + loc
  have hfold : ∀ (k : ℕ) (hk : k ≤ C_nd),
      let Sk := Fin.foldl k (fun cur (sub : Fin k) => cur.unlinkNode (loc * C_nd + sub.val)) S
      let ndLk : Fin R → Fin (M₀ ^ ℓ) → List ℕ := fun r c =>
        (ndL₀ r c).filter (fun z => decide (z < loc * C_nd ∨ loc * C_nd + k ≤ z))
      LiveSlotListInv cap_u B_max blkStart ndLk Sk ∧
      Sk.ep = S.ep ∧ Sk.caps = S.caps ∧ Sk.builtCnt = S.builtCnt ∧ Sk.blkId = S.blkId ∧
      Sk.nEid = S.nEid := by
    intro k
    induction k with
    | zero =>
        intro _
        dsimp only
        rw [Fin.foldl_zero]
        have hid : (fun (r : Fin R) (c : Fin (M₀ ^ ℓ)) =>
            (ndL₀ r c).filter (fun z => decide (z < loc * C_nd ∨ loc * C_nd + 0 ≤ z))) = ndL₀ := by
          funext r c; refine List.filter_eq_self.mpr fun z _ => decide_eq_true (by omega)
        rw [hid]
        exact ⟨hinv₀, rfl, rfl, rfl, rfl, rfl⟩
    | succ k ih =>
        intro hk
        rw [Fin.foldl_succ_last]
        obtain ⟨hinv_k, hep_k, hcap_k, hbc_k, hblk_k, heid_k⟩ := ih (by omega)
        have hnd_lt : loc * C_nd + k < B_max * C_nd := by
          calc loc * C_nd + k < loc * C_nd + C_nd := by omega
            _ = (loc + 1) * C_nd := by ring
            _ ≤ B_max * C_nd := Nat.mul_le_mul_right _ hloc
        obtain ⟨hinv_s, hep_s, hcap_s, hbc_s, hblk_s, heid_s⟩ :=
          LiveSlot.listInv_unlinkNode hM₀ hinv_k hnd_lt
        have hndL_eq : (fun (r : Fin R) (c : Fin (M₀ ^ ℓ)) =>
            ((ndL₀ r c).filter (fun z => decide (z < loc * C_nd ∨ loc * C_nd + k ≤ z))).erase (loc * C_nd + k)) =
            (fun (r : Fin R) (c : Fin (M₀ ^ ℓ)) =>
              (ndL₀ r c).filter (fun z => decide (z < loc * C_nd ∨ loc * C_nd + (k + 1) ≤ z))) := by
          funext r c
          have hndup := chain_gt_nodup (hinv_k.2.2.2.1 r c).1.1
          rw [erase_eq_filter_ne_of_nodup _ hndup, List.filter_filter]
          refine List.filter_congr fun z _ => ?_
          by_cases h1 : z = loc * C_nd + k
          · subst h1; simp
          · have hiff : (z < loc * C_nd ∨ loc * C_nd + k ≤ z) ↔ (z < loc * C_nd ∨ loc * C_nd + (k + 1) ≤ z) := by omega
            simp [h1, hiff]
        rw [hndL_eq] at hinv_s
        exact ⟨hinv_s, hep_s.trans hep_k, hcap_s.trans hcap_k, hbc_s.trans hbc_k, hblk_s.trans hblk_k, heid_s.trans heid_k⟩
  obtain ⟨hinv_end, hep_e, hcap_e, hbc_e, hblk_e, heid_e⟩ := hfold C_nd le_rfl
  dsimp only [LiveSlot.unlinkLoc]
  refine ⟨⟨hbc_e.symm ▸ hbc, hcap_e.trans hcaps, _, hinv_end, fun r c => ?_⟩,
    hep_e, hcap_e, hbc_e, hblk_e⟩
  refine ⟨fun nd hm => ?_, ?_⟩
  · rw [hbc_e]
    exact (hmap₀ r c).1 nd (List.mem_of_mem_filter hm)
  · rw [heid_e]
    have hdiv_iff : ∀ z ∈ ndL₀ r c,
        (z < loc * C_nd ∨ loc * C_nd + C_nd ≤ z) ↔ S.nEid z ≠ e_del := by
      intro z hz
      have hz_pool : z < B_max * C_nd := ((hinv₀.2.2.2.1 r c).2 z hz).1
      have hC_pos : 0 < C_nd := by
        by_contra hc0
        have hc_zero : C_nd = 0 := by omega
        simp [hc_zero] at hz_pool
      have hzeid : S.nEid z = blkStart + z / C_nd := ((hinv₀.2.2.2.1 r c).2 z hz).2.2.2
      rw [hzeid]
      constructor
      · intro h_out heq
        have hdiv_eq : z / C_nd = loc := by dsimp [e_del] at heq; omega
        have h1 : loc * C_nd ≤ z := by rw [← hdiv_eq, mul_comm]; exact Nat.mul_div_le z C_nd
        have h2 : z < loc * C_nd + C_nd := by
          have hd1 := Nat.div_add_mod z C_nd
          have hd2 := Nat.mod_lt z hC_pos
          rw [hdiv_eq, mul_comm C_nd loc] at hd1
          omega
        omega
      · intro hne
        by_contra h_in
        push_neg at h_in
        have hC_pos : 0 < C_nd := by omega
        have hdiv_eq : z / C_nd = loc := by
          apply le_antisymm
          · exact Nat.le_of_lt_succ ((Nat.div_lt_iff_lt_mul hC_pos).mpr (by linarith))
          · exact (Nat.le_div_iff_mul_le hC_pos).mpr h_in.1
        exact hne (by dsimp [e_del]; omega)
    have hfilt_eq : (ndL₀ r c).filter (fun z => decide (z < loc * C_nd ∨ loc * C_nd + C_nd ≤ z)) =
        (ndL₀ r c).filter ((fun x => decide (x ≠ e_del)) ∘ S.nEid) :=
      List.filter_congr fun z hz => by simp only [Function.comp_apply, decide_eq_decide]; exact hdiv_iff z hz
    rw [hfilt_eq, ← List.filter_map]
    change List.filter (fun x => decide (x ≠ blkStart + loc)) (List.map S.nEid (ndL₀ r c)) = _
    rw [(hmap₀ r c).2, List.filter_filter]
    refine List.filter_congr fun x _ => ?_
    by_cases hx : x = blkStart + loc
    · subst hx; simp
    · simp [hx, Function.update_of_ne hx]

theorem LiveSlot.wf_unlink_outside {R ℓ M₀ d : ℕ} {cap_u B_max blkStart : ℕ}
    {entryAlive : ℕ → Bool} {pSlot : PureFilterSlot R ℓ M₀ d} {S : LiveSlot R ℓ M₀ d}
    (hwf : S.WF cap_u B_max blkStart entryAlive pSlot)
    {e_del : ℕ} (hout : ∀ e, blkStart ≤ e → e < blkStart + S.builtCnt → e ≠ e_del)
    (hbucket_range : ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ e ∈ pSlot.buckets r c,
      blkStart ≤ e ∧ e < blkStart + S.builtCnt) :
    S.WF cap_u B_max blkStart (Function.update entryAlive e_del false) pSlot := by
  rcases hwf with ⟨hbc, hcaps, ndL, hinv, hmap⟩
  refine ⟨hbc, hcaps, ndL, hinv, fun r c => ⟨(hmap r c).1, ?_⟩⟩
  rw [(hmap r c).2]
  refine List.filter_congr fun e he => ?_
  rcases hbucket_range r c e he with ⟨hlo, hhi⟩
  rw [Function.update_of_ne (hout e hlo hhi)]

theorem LiveSlot.wf_insertRecord {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    {A B_rat τ_d : ℚ} {cap_u B_max blkStart : ℕ}
    {entryAlive : ℕ → Bool} {pSlot : PureFilterSlot R ℓ M₀ d} {S : LiveSlot R ℓ M₀ d}
    (hwf : S.WF cap_u B_max blkStart entryAlive pSlot)
    (hlt : S.builtCnt < B_max)
    (o pt : EuclideanSpace ℝ (Fin d)) :
    let eid := blkStart + S.builtCnt
    let S' := S.insertRecord hM₀ A B_rat τ_d cap_u eid (entryAlive eid) o pt
    let pSlot' := pSlot.insertPoint hM₀ A B_rat τ_d cap_u o pt eid
    S'.WF cap_u B_max blkStart entryAlive pSlot' ∧
    S'.ep = S.ep ∧ S'.caps = S.caps ∧ S'.builtCnt = S.builtCnt + 1 ∧ S'.blkId = S.blkId := by
  classical
  rcases hwf with ⟨_, hcaps, ndL₀, hinv₀, hmap₀⟩
  let loc := S.builtCnt
  let eid := blkStart + loc
  let pSlot' := pSlot.insertPoint hM₀ A B_rat τ_d cap_u o pt eid
  let C_nd := R * cap_u
  by_cases hal : entryAlive eid = true
  · -- Alive case: fold over `r : Fin R`
    unfold LiveSlot.insertRecord
    dsimp only
    rw [if_pos hal]
    have hfoldR : ∀ (r_lim : ℕ) (hr_le : r_lim ≤ R),
        let Sr := Fin.foldl r_lim (fun cur (r : Fin r_lim) =>
          cur.insertCopy hM₀ A B_rat τ_d cap_u loc eid (pt - o) ⟨r.val, lt_of_lt_of_le r.isLt hr_le⟩) S
        ∃ ndLr : Fin R → Fin (M₀ ^ ℓ) → List ℕ,
          LiveSlotListInv cap_u B_max blkStart ndLr Sr ∧
          Sr.ep = S.ep ∧ Sr.caps = S.caps ∧ Sr.builtCnt = S.builtCnt ∧ Sr.blkId = S.blkId ∧
          (∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)),
            if r.val < r_lim then
              (∀ nd ∈ ndLr r c, nd / C_nd < loc + 1 ∧ (nd / C_nd = loc → nd < (loc * R + r_lim) * cap_u)) ∧
              (ndLr r c).map Sr.nEid = (pSlot'.buckets r c).filter entryAlive
            else
              (∀ nd ∈ ndLr r c, nd / C_nd < loc) ∧
              (ndLr r c).map Sr.nEid = (pSlot.buckets r c).filter entryAlive) := by
      intro r_lim
      induction r_lim with
      | zero =>
          intro _
          dsimp only
          rw [Fin.foldl_zero]
          refine ⟨ndL₀, hinv₀, rfl, rfl, rfl, rfl, fun r c => ?_⟩
          simp only [Nat.not_lt_zero, ↓reduceIte]
          exact hmap₀ r c
      | succ r_lim ih =>
          intro hr_le
          dsimp only
          rw [Fin.foldl_succ_last]
          simp only [Fin.val_last, Fin.val_castSucc]
          obtain ⟨ndLr, hinv_r, hep_r, hcap_r, hbc_r, hblk_r, hprop_r⟩ := ih (by omega)
          let r₀ : Fin R := ⟨r_lim, hr_le⟩
          let w := pt - o
          -- Unfold `insertCopy` on `Sr` (whose `.caps` equals `S.caps = pSlot.caps`)
          set Sr := Fin.foldl r_lim (fun cur (r : Fin r_lim) =>
            cur.insertCopy hM₀ A B_rat τ_d cap_u loc eid (pt - o) ⟨r.val, lt_of_lt_of_le r.isLt (Nat.le_of_succ_le hr_le)⟩) S
          have hcaps_Sr : Sr.caps = pSlot.caps := hcap_r.trans hcaps
          let eL : Fin ℓ → List (Fin M₀) := fun s =>
            (List.finRange M₀).filter (fun k =>
              realSignedSqCapCond (A : ℝ) (B_rat : ℝ) (τ_d : ℝ) (Sr.caps (r₀, s, k)) w)
          let cnt : Fin ℓ → ℕ := fun s => (eL s).length
          let prodCap := truncMul (cap_u + 1) cnt
          have hins_eq : Sr.insertCopy hM₀ A B_rat τ_d cap_u loc eid (pt - o) r₀ =
              (if (∀ s : Fin ℓ, 1 ≤ cnt s) ∧ prodCap ≤ cap_u then
                let elig : Fin ℓ → ℕ → ℕ := fun s j =>
                  if hj : j < (eL s).length then ((eL s)[j]).val else 0
                Fin.foldl prodCap (fun cur (j : Fin prodCap) =>
                  let τ := mixedTuple hM₀ cnt elig j.val
                  let code := encodeTuple τ
                  let bkt := r₀.val * M₀ ^ ℓ + code
                  let nd := (loc * R + r₀.val) * cap_u + j.val
                  cur.pushNode bkt nd eid) Sr
              else Sr) := rfl
          rw [hins_eq]
          let baseSets : Fin ℓ → Finset (Fin M₀) := fun s =>
            Finset.univ.filter (fun k : Fin M₀ =>
              realSignedSqCapCond (A : ℝ) (B_rat : ℝ) (τ_d : ℝ) (pSlot.caps (r₀, s, k)) w)
          let prodSet := Fintype.piFinset baseSets
          have heL_card : ∀ s : Fin ℓ, cnt s = (baseSets s).card := by
            intro s
            dsimp [cnt, eL, baseSets]
            rw [hcaps_Sr]
            have hnd : (List.finRange M₀).Nodup := List.nodup_finRange M₀
            rw [← List.toFinset_card_of_nodup (hnd.filter _)]
            congr 1; ext k; simp
          have hprodSet_card : prodSet.card = ∏ s : Fin ℓ, cnt s := by
            rw [Fintype.card_piFinset]; exact Finset.prod_congr rfl fun s _ => (heL_card s).symm
          by_cases hcond : (∀ s : Fin ℓ, 1 ≤ cnt s) ∧ prodCap ≤ cap_u
          · rw [if_pos hcond]
            rcases hcond with ⟨hcnt_pos, hprod_le⟩
            have hprod_eq : prodCap = ∏ s : Fin ℓ, cnt s := by
              have hm := truncMul_eq_min_prod (cap_u + 1) cnt hcnt_pos
              dsimp [prodCap, truncMul] at hprod_le ⊢
              rw [hm] at hprod_le ⊢
              omega
            have hcard_le : prodSet.card ≤ cap_u := by rw [hprodSet_card, ← hprod_eq]; exact hprod_le
            let elig : Fin ℓ → ℕ → ℕ := fun s j =>
              if hj : j < (eL s).length then ((eL s)[j]).val else 0
            have helig_lt : ∀ s j, j < cnt s → elig s j < M₀ := by
              intro s j hj; dsimp [elig]; rw [dif_pos hj]; exact ((eL s)[j]).isLt
            have helig_inj : ∀ s i j, i < cnt s → j < cnt s → elig s i = elig s j → i = j := by
              intro s i j hi hj heq
              dsimp [elig] at heq; rw [dif_pos hi, dif_pos hj] at heq
              have hnd : (eL s).Nodup := (List.nodup_finRange M₀).filter _
              have hinj : (⟨i, hi⟩ : Fin (eL s).length) = ⟨j, hj⟩ := (List.nodup_iff_injective_getElem.mp hnd) (Fin.ext heq)
              exact congrArg Fin.val hinj
            have helig_mem : ∀ s (k : Fin M₀), k ∈ baseSets s ↔ ∃ j < cnt s, elig s j = k.val := by
              intro s k
              simp only [baseSets, Finset.mem_filter, Finset.mem_univ, true_and]
              constructor
              · intro hcond_s
                rw [← hcaps_Sr] at hcond_s
                have hmem : k ∈ eL s := List.mem_filter.mpr ⟨List.mem_finRange _, decide_eq_true hcond_s⟩
                obtain ⟨j, hj, hget⟩ := List.getElem_of_mem hmem
                refine ⟨j, hj, ?_⟩
                dsimp [elig]; rw [dif_pos hj, hget]
              · rintro ⟨j, hj, hτ⟩
                have hj' : j < (eL s).length := hj
                have hmem : (eL s)[j] ∈ eL s := List.getElem_mem hj'
                have hcond_s := (List.mem_filter.mp hmem).2
                have hval_eq : (eL s)[j] = k := by
                  apply Fin.ext; dsimp [elig] at hτ; rw [dif_pos hj'] at hτ; exact hτ
                rw [← hval_eq, ← hcaps_Sr]
                exact of_decide_eq_true hcond_s
            have hmix := mixedTuple_image_range hM₀ baseSets cnt elig hcnt_pos helig_mem helig_lt helig_inj
            have himg_prod : (Finset.range prodCap).image (mixedTuple hM₀ cnt elig) = prodSet := by
              rw [hprod_eq]; exact hmix.1
            -- Fold over `j < prodCap`
            have hfoldJ : ∀ (m : ℕ) (hm_le : m ≤ prodCap),
                let Sm := Fin.foldl m (fun cur (j : Fin m) =>
                  let τ := mixedTuple hM₀ cnt elig j.val
                  let code := encodeTuple τ
                  cur.pushNode (r₀.val * M₀ ^ ℓ + code) ((loc * R + r₀.val) * cap_u + j.val) eid) Sr
                ∃ ndLm : Fin R → Fin (M₀ ^ ℓ) → List ℕ,
                  LiveSlotListInv cap_u B_max blkStart ndLm Sm ∧
                  Sm.ep = S.ep ∧ Sm.caps = S.caps ∧ Sm.builtCnt = S.builtCnt ∧ Sm.blkId = S.blkId ∧
                  (∀ z < (loc * R + r₀.val) * cap_u, Sm.nEid z = Sr.nEid z) ∧
                  (∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)),
                    if r = r₀ then
                      (∀ nd ∈ ndLm r₀ c,
                        nd / C_nd < loc + 1 ∧
                        (nd / C_nd = loc → (loc * R + r₀.val) * cap_u ≤ nd ∧ nd < (loc * R + r₀.val) * cap_u + m)) ∧
                      (ndLm r₀ c).map Sm.nEid =
                        if ∃ j < m, encodeTuple (mixedTuple hM₀ cnt elig j) = c.val then
                          eid :: (pSlot.buckets r₀ c).filter entryAlive
                        else
                          (pSlot.buckets r₀ c).filter entryAlive
                    else if r.val < r_lim then
                      (∀ nd ∈ ndLm r c, nd / C_nd < loc + 1 ∧ (nd / C_nd = loc → nd < (loc * R + r_lim) * cap_u)) ∧
                      (ndLm r c).map Sm.nEid = (pSlot'.buckets r c).filter entryAlive
                    else
                      (∀ nd ∈ ndLm r c, nd / C_nd < loc) ∧
                      (ndLm r c).map Sm.nEid = (pSlot.buckets r c).filter entryAlive) := by
              intro m
              induction m with
              | zero =>
                  intro _
                  dsimp only
                  rw [Fin.foldl_zero]
                  refine ⟨ndLr, hinv_r, hep_r, hcap_r, hbc_r, hblk_r, fun _ _ => rfl, fun r c => ?_⟩
                  by_cases hr0 : r = r₀
                  · subst hr0
                    rw [if_pos rfl]
                    have hp0 := hprop_r r₀ c
                    rw [if_neg (Nat.lt_irrefl r_lim)] at hp0
                    simp only [Nat.not_lt_zero, false_and, exists_false, ↓reduceIte]
                    exact ⟨fun nd hm => ⟨by have := hp0.1 nd hm; omega, fun hd => by have := hp0.1 nd hm; omega⟩, hp0.2⟩
                  · rw [if_neg hr0]; exact hprop_r r c
              | succ m ihm =>
                  intro hm_le
                  dsimp only
                  rw [Fin.foldl_succ_last]
                  simp only [Fin.val_last, Fin.val_castSucc]
                  obtain ⟨ndLm, hinv_m, hep_m, hcap_m, hbc_m, hblk_m, heid_old, hprop_m⟩ := ihm (by omega)
                  let τ_m := mixedTuple hM₀ cnt elig m
                  let c_m : Fin (M₀ ^ ℓ) := ⟨encodeTuple τ_m, encodeTuple_lt hM₀ τ_m⟩
                  let nd_m := (loc * R + r₀.val) * cap_u + m
                  have hC_pos : 0 < C_nd := Nat.mul_pos (by omega) (by omega)
                  have hlo_nd : loc * C_nd ≤ nd_m := by
                    calc loc * (R * cap_u) = (loc * R) * cap_u := (mul_assoc _ _ _).symm
                      _ ≤ (loc * R + r₀.val) * cap_u := Nat.mul_le_mul_right cap_u (Nat.le_add_right _ _)
                      _ ≤ (loc * R + r₀.val) * cap_u + m := Nat.le_add_right _ m
                  have hhi_nd : nd_m < (loc + 1) * C_nd := by
                    calc (loc * R + r₀.val) * cap_u + m
                        < (loc * R + r₀.val) * cap_u + cap_u := by omega
                      _ = (loc * R + (r₀.val + 1)) * cap_u := by ring
                      _ ≤ (loc * R + R) * cap_u := Nat.mul_le_mul_right cap_u (Nat.add_le_add_left r₀.isLt _)
                      _ = (loc + 1) * (R * cap_u) := by ring
                  have hnd_div : nd_m / C_nd = loc := by
                    apply le_antisymm
                    · exact Nat.le_of_lt_succ ((Nat.div_lt_iff_lt_mul hC_pos).mpr hhi_nd)
                    · exact (Nat.le_div_iff_mul_le hC_pos).mpr hlo_nd
                  have hnd_pool : nd_m < B_max * C_nd :=
                    lt_of_lt_of_le hhi_nd (Nat.mul_le_mul_right _ hlt)
                  have hgt_all : ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ z ∈ ndLm r c, z < nd_m := by
                    intro r c z hz
                    have hp := hprop_m r c
                    by_cases hr0 : r = r₀
                    · subst hr0; rw [if_pos rfl] at hp
                      rcases hp.1 z hz with ⟨hd_lt, hd_eq⟩
                      by_cases he : z / C_nd = loc
                      · have := (hd_eq he).2; dsimp [nd_m]; omega
                      · have hzl : z / C_nd < loc := by omega
                        exact lt_of_lt_of_le ((Nat.div_lt_iff_lt_mul hC_pos).mp hzl) hlo_nd
                    · rw [if_neg hr0] at hp
                      by_cases hrl : r.val < r_lim
                      · rw [if_pos hrl] at hp
                        rcases hp.1 z hz with ⟨hd_lt, hd_eq⟩
                        by_cases he : z / C_nd = loc
                        · have := hd_eq he; dsimp [nd_m, r₀]; omega
                        · have hzl : z / C_nd < loc := by omega
                          exact lt_of_lt_of_le ((Nat.div_lt_iff_lt_mul hC_pos).mp hzl) hlo_nd
                      · rw [if_neg hrl] at hp
                        exact lt_of_lt_of_le ((Nat.div_lt_iff_lt_mul hC_pos).mp (hp.1 z hz)) hlo_nd
                  have heid_eq : blkStart + nd_m / (R * cap_u) = eid := by
                    change blkStart + nd_m / C_nd = eid; rw [hnd_div]
                  obtain ⟨hinv_s, hep_s, hcap_s, hbc_s, hblk_s, heid_lt_nd, heid_self⟩ :=
                    LiveSlot.listInv_pushNode hM₀ hinv_m r₀ c_m hnd_pool hgt_all
                  dsimp only at hinv_s heid_lt_nd heid_self
                  rw [heid_eq] at hinv_s heid_lt_nd heid_self
                  refine ⟨_, hinv_s, hep_s.trans hep_m, hcap_s.trans hcap_m, hbc_s.trans hbc_m, hblk_s.trans hblk_m,
                    fun z hz => (heid_lt_nd z (by dsimp [nd_m]; omega)).trans (heid_old z hz),
                    fun r c => ?_⟩
                  have hp := hprop_m r c
                  by_cases hr0 : r = r₀
                  · subst hr0
                    rw [if_pos rfl] at hp ⊢
                    by_cases hcm : c = c_m
                    · subst hcm
                      rw [if_pos ⟨rfl, rfl⟩]
                      have hnot_prev : ¬ ∃ j < m, encodeTuple (mixedTuple hM₀ cnt elig j) = c_m.val := by
                        rintro ⟨j, hj, heq_c⟩
                        have hτ_eq := encodeTuple_injective hM₀ heq_c
                        have hj_in : j ∈ (Finset.range prodCap : Set ℕ) := by simp; omega
                        have hm_in : m ∈ (Finset.range prodCap : Set ℕ) := by simp; omega
                        rw [← hprod_eq] at hmix
                        have hjm := hmix.2 (by simp; omega) (by simp; omega) hτ_eq
                        omega
                      have hex_now : ∃ j < m + 1, encodeTuple (mixedTuple hM₀ cnt elig j) = c_m.val :=
                        ⟨m, Nat.lt_succ_self m, rfl⟩
                      rw [if_neg hnot_prev] at hp
                      rw [if_pos hex_now]
                      refine ⟨fun nd hm => ?_, ?_⟩
                      · rcases List.mem_cons.mp hm with rfl | hm'
                        · exact ⟨by rw [hnd_div]; omega, fun _ => ⟨by dsimp [nd_m]; omega, by dsimp [nd_m]; omega⟩⟩
                        · rcases hp.1 nd hm' with ⟨h1, h2⟩
                          exact ⟨h1, fun hd => ⟨(h2 hd).1, by have := (h2 hd).2; omega⟩⟩
                      · simp only [List.map_cons, heid_self]
                        congr 1
                        rw [← hp.2]
                        exact List.map_congr_left fun z hz => heid_lt_nd z (hgt_all r₀ c_m z hz)
                    · rw [if_neg (fun h => hcm h.2)]
                      have hex_iff : (∃ j < m + 1, encodeTuple (mixedTuple hM₀ cnt elig j) = c.val) ↔
                          (∃ j < m, encodeTuple (mixedTuple hM₀ cnt elig j) = c.val) := by
                        constructor
                        · rintro ⟨j, hj, heq_c⟩
                          by_cases hjm : j = m
                          · subst hjm; exact False.elim (hcm (Fin.ext heq_c.symm))
                          · exact ⟨j, by omega, heq_c⟩
                        · rintro ⟨j, hj, heq_c⟩; exact ⟨j, by omega, heq_c⟩
                      simp only [hex_iff]
                      refine ⟨fun nd hm => ?_, ?_⟩
                      · rcases hp.1 nd hm with ⟨h1, h2⟩
                        exact ⟨h1, fun hd => ⟨(h2 hd).1, by have := (h2 hd).2; omega⟩⟩
                      · rw [← hp.2]
                        exact List.map_congr_left fun z hz => heid_lt_nd z (hgt_all r₀ c z hz)
                  · rw [if_neg hr0] at hp ⊢
                    have hnot_rc : ¬ (r = r₀ ∧ c = c_m) := fun h => hr0 h.1
                    simp only [hnot_rc, false_and, ↓reduceIte]
                    by_cases hrl : r.val < r_lim
                    · rw [if_pos hrl] at hp ⊢
                      exact ⟨hp.1, (List.map_congr_left fun z hz => heid_lt_nd z (hgt_all r c z hz)).trans hp.2⟩
                    · rw [if_neg hrl] at hp ⊢
                      exact ⟨hp.1, (List.map_congr_left fun z hz => heid_lt_nd z (hgt_all r c z hz)).trans hp.2⟩
            obtain ⟨ndLp, hinv_p, hep_p, hcap_p, hbc_p, hblk_p, _, hprop_p⟩ := hfoldJ prodCap le_rfl
            refine ⟨ndLp, hinv_p, hep_p, hcap_p, hbc_p, hblk_p, fun r c => ?_⟩
            have hp := hprop_p r c
            by_cases hr_lt : r.val < r_lim + 1
            · rw [if_pos hr_lt]
              by_cases hr0 : r = r₀
              · subst hr0
                rw [if_pos rfl] at hp
                refine ⟨fun nd hm => ?_, ?_⟩
                · rcases hp.1 nd hm with ⟨h1, h2⟩
                  refine ⟨h1, fun hd => ?_⟩
                  have := (h2 hd).2
                  calc nd < (loc * R + r_lim) * cap_u + prodCap := this
                    _ ≤ (loc * R + r_lim) * cap_u + cap_u := by omega
                    _ = (loc * R + (r_lim + 1)) * cap_u := by ring
                · rw [hp.2]
                  dsimp only [pSlot', PureFilterSlot.insertPoint]
                  change _ = List.filter entryAlive
                    (if prodSet.card ≤ cap_u then
                      if ∃ τ ∈ prodSet, encodeTuple τ = c.val then eid :: pSlot.buckets r₀ c
                      else pSlot.buckets r₀ c
                    else pSlot.buckets r₀ c)
                  rw [if_pos hcard_le]
                  have hex_prod : (∃ j < prodCap, encodeTuple (mixedTuple hM₀ cnt elig j) = c.val) ↔
                      (∃ τ ∈ prodSet, encodeTuple τ = c.val) := by
                    rw [← himg_prod]
                    simp only [Finset.mem_image, Finset.mem_range]
                    constructor
                    · rintro ⟨j, hj, heq⟩; exact ⟨_, ⟨j, hj, rfl⟩, heq⟩
                    · rintro ⟨τ, ⟨j, hj, rfl⟩, heq⟩; exact ⟨j, hj, heq⟩
                  by_cases hex : ∃ τ ∈ prodSet, encodeTuple τ = c.val
                  · rw [if_pos (hex_prod.mpr hex), if_pos hex, List.filter_cons_of_pos hal]
                  · rw [if_neg (fun h => hex (hex_prod.mp h)), if_neg hex]
              · have hrl : r.val < r_lim := by
                  have : r.val ≠ r_lim := fun h => hr0 (Fin.ext h)
                  omega
                rw [if_neg hr0, if_pos hrl] at hp
                exact ⟨fun nd hm => ⟨(hp.1 nd hm).1, fun hd => lt_of_lt_of_le ((hp.1 nd hm).2 hd) (Nat.mul_le_mul_right cap_u (Nat.add_le_add_left (Nat.le_succ r_lim) (loc * R)))⟩, hp.2⟩
            · have hr0 : r ≠ r₀ := fun h => by subst h; dsimp [r₀] at hr_lt; omega
              have hrl : ¬ r.val < r_lim := by omega
              rw [if_neg hr_lt]
              rw [if_neg hr0, if_neg hrl] at hp
              exact hp
          · -- Condition `(∀ s, 1 ≤ cnt s) ∧ prodCap ≤ cap_u` fails: `pSlot'.buckets r₀ c = pSlot.buckets r₀ c`
            rw [if_neg hcond]
            have hbuck_same : ∀ c : Fin (M₀ ^ ℓ), pSlot'.buckets r₀ c = pSlot.buckets r₀ c := by
              intro c
              dsimp only [pSlot', PureFilterSlot.insertPoint]
              change (if prodSet.card ≤ cap_u then
                if ∃ τ ∈ prodSet, encodeTuple τ = c.val then eid :: pSlot.buckets r₀ c
                else pSlot.buckets r₀ c
              else pSlot.buckets r₀ c) = _
              by_cases hall1 : ∀ s : Fin ℓ, 1 ≤ cnt s
              · have hgt_cap : cap_u < prodCap := Nat.lt_of_not_ge (fun hle => hcond ⟨hall1, hle⟩)
                have hcard_gt : cap_u < prodSet.card := by
                  rw [hprodSet_card]
                  have hm := truncMul_eq_min_prod (cap_u + 1) cnt hall1
                  dsimp [prodCap, truncMul] at hgt_cap
                  rw [hm] at hgt_cap
                  omega
                rw [if_neg (by omega)]
              · push_neg at hall1
                rcases hall1 with ⟨s₀, hs₀⟩
                have h0 : (baseSets s₀).card = 0 := by have := heL_card s₀; omega
                have hempty : prodSet = ∅ := by
                  rw [← Finset.card_eq_zero, Fintype.card_piFinset]
                  exact Finset.prod_eq_zero (Finset.mem_univ s₀) h0
                rw [hempty]
                split_ifs with hc1 hc2
                · rcases hc2 with ⟨_, hmem, _⟩; exact absurd hmem (Finset.notMem_empty _)
                · rfl
                · rfl
            refine ⟨ndLr, hinv_r, hep_r, hcap_r, hbc_r, hblk_r, fun r c => ?_⟩
            have hp := hprop_r r c
            by_cases hr_lt : r.val < r_lim + 1
            · rw [if_pos hr_lt]
              by_cases hr0 : r = r₀
              · subst hr0
                rw [if_neg (Nat.lt_irrefl r_lim)] at hp
                rw [hbuck_same c]
                exact ⟨fun nd hm => ⟨by have := hp.1 nd hm; omega, fun hd => by have := hp.1 nd hm; omega⟩, hp.2⟩
              · have hrl : r.val < r_lim := by
                  have : r.val ≠ r_lim := fun h => hr0 (Fin.ext h)
                  omega
                rw [if_pos hrl] at hp
                exact ⟨fun nd hm => ⟨(hp.1 nd hm).1, fun hd => lt_of_lt_of_le ((hp.1 nd hm).2 hd) (Nat.mul_le_mul_right cap_u (Nat.add_le_add_left (Nat.le_succ r_lim) (loc * R)))⟩, hp.2⟩
            · rw [if_neg hr_lt]
              rw [if_neg (by omega : ¬ r.val < r_lim)] at hp
              exact hp
    obtain ⟨ndLR, hinv_R, hep_R, hcap_R, _, hblk_R, hprop_R⟩ := hfoldR R le_rfl
    have hcaps' : pSlot'.caps = pSlot.caps := rfl
    refine ⟨⟨by dsimp only [loc]; omega, hcap_R.trans (hcaps.trans hcaps'.symm), ndLR, hinv_R, fun r c => ?_⟩,
      hep_R, hcap_R, rfl, hblk_R⟩
    have hp := hprop_R r c
    rw [if_pos r.isLt] at hp
    exact ⟨fun nd hm => (hp.1 nd hm).1, hp.2⟩
  · -- Dead case (`entryAlive eid = false`): `LiveSlot` only increments `builtCnt`!
    have half : entryAlive eid = false := Bool.eq_false_iff.mpr hal
    unfold LiveSlot.insertRecord
    dsimp only
    rw [if_neg hal]
    refine ⟨⟨by dsimp only [loc]; omega, hcaps, ndL₀, hinv₀, fun r c => ?_⟩, rfl, rfl, rfl, rfl⟩
    refine ⟨fun nd hm => Nat.lt_succ_of_lt ((hmap₀ r c).1 nd hm), ?_⟩
    rw [(hmap₀ r c).2]
    dsimp only [pSlot', PureFilterSlot.insertPoint]
    split_ifs with hc1 hc2
    · exact (List.filter_cons_of_neg hal).symm
    · rfl
    · rfl

/-! ### 4. Bounded `.repeatN (2 * cap_q + 2)` Query State Machine & Exactness -/

noncomputable def queryCopyStep {R ℓ M₀ d : ℕ}
    (entryPt : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d)) (b_thr : ℝ)
    (S : LiveSlot R ℓ M₀ d) (r : Fin R) (codes : List (Fin (M₀ ^ ℓ)))
    (st : ℕ × Bool × ℤ × ℕ × Option ℕ) : ℕ × Bool × ℤ × ℕ × Option ℕ :=
  open Classical in
  let (tupIdx, inBkt, curNd, remRej, ans) := st
  if ans.isSome || decide (remRej = 0) then
    st
  else if inBkt then
    if curNd < 0 then
      (tupIdx, false, -1, remRej, ans)
    else
      let nd := curNd.toNat
      let eid := S.nEid nd
      if b_thr < radialCorrelation o p_v (entryPt eid) then
        (tupIdx, false, -1, remRej, some eid)
      else if remRej - 1 = 0 then
        (tupIdx, false, -1, 0, none)
      else
        let nx := S.nNext nd
        (tupIdx, decide (0 ≤ nx), nx, remRej - 1, none)
  else
    if hlt : tupIdx < codes.length then
      let code := codes[tupIdx]
      let hd := S.effHead (r.val * M₀ ^ ℓ + code.val)
      (tupIdx + 1, decide (0 ≤ hd), hd, remRej, none)
    else
      st

private lemma isDLL_sublist_of_head {L : List ℕ} {prv : ℤ} {prev next : ℕ → ℤ}
    (hdll : IsDLL prv L prev next) :
    L = [] ∨ ∃ (x : ℕ) (xs : List ℕ), L = x :: xs ∧ listHeadInt L = (x : ℤ) ∧
      next x = listHeadInt xs ∧ IsDLL (x : ℤ) xs prev next := by
  cases L with
  | nil => exact Or.inl rfl
  | cons x xs => exact Or.inr ⟨x, xs, rfl, rfl, hdll.2.1, hdll.2.2⟩

theorem queryCopyStep_complete {R ℓ M₀ d : ℕ}
    {cap_u B_max blkStart : ℕ} {entryAlive : ℕ → Bool}
    {pSlot : PureFilterSlot R ℓ M₀ d} {S : LiveSlot R ℓ M₀ d}
    (hwf : S.WF cap_u B_max blkStart entryAlive pSlot)
    (entryPt : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d)) (b_thr : ℝ)
    (cap_q : ℕ) (r : Fin R) (codes : List (Fin (M₀ ^ ℓ)))
    (hlen : codes.length ≤ cap_q) :
    let st_end := (queryCopyStep entryPt o p_v b_thr S r codes)^[2 * cap_q + 2]
      (0, false, -1, cap_q + 1, none)
    st_end.2.2.2.2 =
      scanCopyTuples pSlot.buckets r entryPt o p_v b_thr entryAlive (cap_q + 1) codes ∧
    ∀ t ≤ 2 * cap_q + 2,
      let st_t := (queryCopyStep entryPt o p_v b_thr S r codes)^[t] (0, false, -1, cap_q + 1, none)
      st_t.2.1 = true → 0 ≤ st_t.2.2.1 →
        let nd := st_t.2.2.1.toNat
        nd < B_max * (R * cap_u) ∧ entryAlive (S.nEid nd) = true := by
  classical
  rcases hwf with ⟨_, _, ndL, hinv, hmap⟩
  let liveB : Fin R → Fin (M₀ ^ ℓ) → List ℕ := fun r' c' => (pSlot.buckets r' c').filter entryAlive
  have htarget_eq :
      scanCopyTuples liveB r entryPt o p_v b_thr (fun _ => true) (cap_q + 1) codes =
      scanCopyTuples pSlot.buckets r entryPt o p_v b_thr entryAlive (cap_q + 1) codes :=
    scanCopyTuples_filter_alive pSlot.buckets r entryPt o p_v b_thr entryAlive codes (cap_q + 1)
  let target := scanCopyTuples liveB r entryPt o p_v b_thr (fun _ => true) (cap_q + 1) codes
  -- State invariant `Inv st`
  let Inv : (ℕ × Bool × ℤ × ℕ × Option ℕ) → Prop := fun st =>
    let (tupIdx, inBkt, curNd, remRej, ans) := st
    tupIdx ≤ codes.length ∧
    remRej ≤ cap_q + 1 ∧
    match ans with
    | some eid => target = some eid ∧ inBkt = false
    | none =>
        if remRej = 0 then
          target = none ∧ inBkt = false
        else if inBkt = true then
          ∃ (prv : ℤ) (x : ℕ) (xs : List ℕ) (c₀ : Fin (M₀ ^ ℓ)),
            curNd = (x : ℤ) ∧
            IsDLL prv (x :: xs) S.nPrev S.nNext ∧
            (∀ z ∈ x :: xs, z ∈ ndL r c₀) ∧
            target =
              (match scanLiveCands entryPt o p_v b_thr (fun _ => true) remRej ((x :: xs).map S.nEid) with
               | (some e, _) => some e
               | (none, rem') => scanCopyTuples liveB r entryPt o p_v b_thr (fun _ => true) rem' (codes.drop tupIdx))
        else
          target = scanCopyTuples liveB r entryPt o p_v b_thr (fun _ => true) remRej (codes.drop tupIdx)
  let Φ : (ℕ × Bool × ℤ × ℕ × Option ℕ) → ℕ := fun st =>
    let (tupIdx, inBkt, _, remRej, ans) := st
    if ans.isSome || decide (remRej = 0) || (!inBkt && decide (codes.length ≤ tupIdx)) then
      0
    else
      (codes.length - tupIdx) + remRej
  have hInv0 : Inv (0, false, -1, cap_q + 1, none) := by
    refine ⟨Nat.zero_le _, le_rfl, ?_⟩
    simp [target]
  have hstep : ∀ st, Inv st →
      let st' := queryCopyStep entryPt o p_v b_thr S r codes st
      Inv st' ∧ (Φ st = 0 → st' = st) ∧ (0 < Φ st → Φ st' < Φ st) := by
    rintro ⟨tupIdx, inBkt, curNd, remRej, ans⟩ hI
    rcases hI with ⟨htup_le, hrem_le, hval⟩
    cases ans with
    | some eid =>
        have hstep_eq : queryCopyStep entryPt o p_v b_thr S r codes (tupIdx, inBkt, curNd, remRej, some eid) =
            (tupIdx, inBkt, curNd, remRej, some eid) := by simp [queryCopyStep]
        have hphi0 : Φ (tupIdx, inBkt, curNd, remRej, some eid) = 0 := by simp [Φ]
        rw [hstep_eq]
        exact ⟨⟨htup_le, hrem_le, hval⟩, fun _ => rfl, fun hpos => by omega⟩
    | none =>
        by_cases hrem0 : remRej = 0
        · subst hrem0
          have hstep_eq : queryCopyStep entryPt o p_v b_thr S r codes (tupIdx, inBkt, curNd, 0, none) =
              (tupIdx, inBkt, curNd, 0, none) := by simp [queryCopyStep]
          have hphi0 : Φ (tupIdx, inBkt, curNd, 0, none) = 0 := by simp [Φ]
          rw [hstep_eq]
          exact ⟨⟨htup_le, hrem_le, hval⟩, fun _ => rfl, fun hpos => by omega⟩
        · obtain ⟨k, rfl⟩ : ∃ k, remRej = k + 1 := ⟨remRej - 1, by omega⟩
          rw [if_neg hrem0] at hval
          cases inBkt with
          | false =>
              rw [if_neg Bool.false_ne_true] at hval
              by_cases hlt : tupIdx < codes.length
              · have hphi_pos : Φ (tupIdx, false, curNd, k + 1, none) = (codes.length - tupIdx) + (k + 1) := by
                  dsimp [Φ]; rw [if_neg (by simp; omega)]
                have hstep_eq : queryCopyStep entryPt o p_v b_thr S r codes (tupIdx, false, curNd, k + 1, none) =
                    (let code := codes[tupIdx]
                     let hd := S.effHead (r.val * M₀ ^ ℓ + code.val)
                     (tupIdx + 1, decide (0 ≤ hd), hd, k + 1, none)) := by
                  unfold queryCopyStep; simp [hlt]
                rw [hstep_eq]; dsimp only
                let code := codes[tupIdx]
                let hd := S.effHead (r.val * M₀ ^ ℓ + code.val)
                have hdrop : codes.drop tupIdx = code :: codes.drop (tupIdx + 1) :=
                  List.drop_eq_getElem_cons hlt
                have hdll_c := (hinv.2.2.2.1 r code).1
                have hmap_c := (hmap r code).2
                refine ⟨⟨by omega, hrem_le, ?_⟩, fun h0 => by omega, fun _ => ?_⟩
                · rw [if_neg (Nat.succ_ne_zero k)]
                  rcases isDLL_sublist_of_head hdll_c.2.2 with hnil | ⟨x, xs, hL_eq, hhd_x, _, htl_xs⟩
                  · have hhd_neg : hd = -1 := by dsimp [hd]; rw [hdll_c.2.1, hnil]; rfl
                    have hdec_f : decide (0 ≤ hd) = false := by rw [hhd_neg]; decide
                    rw [hdec_f, if_neg Bool.false_ne_true, hval, hdrop]
                    dsimp only [scanCopyTuples]
                    have hlive_nil : liveB r code = [] := by dsimp [liveB]; rw [← hmap_c, hnil]; rfl
                    rw [hlive_nil]; simp [scanLiveCands]
                  · have hhd_eq : hd = (x : ℤ) := by dsimp [hd]; rw [hdll_c.2.1, hhd_x]
                    have hdec_t : decide (0 ≤ hd) = true := by rw [hhd_eq]; exact decide_eq_true (by omega)
                    rw [hdec_t, if_pos rfl]
                    refine ⟨-1, x, xs, code, hhd_eq, hL_eq ▸ hdll_c.2.2,
                      fun z hz => hL_eq ▸ hz, ?_⟩
                    rw [hval, hdrop]
                    simp only [scanCopyTuples]
                    have hlive_eq : liveB r code = (x :: xs).map S.nEid :=
                      hmap_c.symm.trans (congrArg (List.map S.nEid) hL_eq)
                    rw [hlive_eq]; rfl
                · rw [hphi_pos]
                  simp only [Φ, Option.isSome_none, Bool.or_eq_true,
                    Bool.and_eq_true, Bool.not_eq_true', decide_eq_true_iff]
                  split_ifs <;> omega
              · have hstep_eq : queryCopyStep entryPt o p_v b_thr S r codes (tupIdx, false, curNd, k + 1, none) =
                    (tupIdx, false, curNd, k + 1, none) := by
                  unfold queryCopyStep; simp [hlt]
                have hphi0 : Φ (tupIdx, false, curNd, k + 1, none) = 0 := by
                  dsimp [Φ]; rw [if_pos (by simp; omega)]
                rw [hstep_eq]
                exact ⟨⟨htup_le, hrem_le, by rw [if_neg hrem0, if_neg Bool.false_ne_true]; exact hval⟩,
                  fun _ => rfl, fun hpos => by omega⟩
          | true =>
              rw [if_pos rfl] at hval
              rcases hval with ⟨prv, x, xs, c₀, hcur_x, ⟨_, hnx_x, htl_xs⟩, hmem_c₀, htar⟩
              have hcur_nneg : ¬ (curNd < 0) := by rw [hcur_x]; omega
              have hcur_nat : curNd.toNat = x := by rw [hcur_x]; exact Int.toNat_natCast x
              have hphi_val : Φ (tupIdx, true, curNd, k + 1, none) = (codes.length - tupIdx) + (k + 1) := by
                simp [Φ]
              by_cases hcorr : b_thr < radialCorrelation o p_v (entryPt (S.nEid x))
              · have hstep_eq : queryCopyStep entryPt o p_v b_thr S r codes (tupIdx, true, curNd, k + 1, none) =
                    (tupIdx, false, -1, k + 1, some (S.nEid x)) := by
                  unfold queryCopyStep
                  simp only [Option.isSome_none, Nat.add_eq_zero_iff, one_ne_zero, and_false, decide_false,
                    Bool.or_self, Bool.false_eq_true, ↓reduceIte, hcur_nneg, hcur_nat, if_pos hcorr]
                rw [hstep_eq]
                refine ⟨⟨htup_le, hrem_le, ?_, rfl⟩, fun h0 => by omega, fun _ => ?_⟩
                · rw [htar]; simp [scanLiveCands, hcorr]
                · simp [Φ]
              · have htar_step : target =
                    (match scanLiveCands entryPt o p_v b_thr (fun _ => true) k (xs.map S.nEid) with
                     | (some e, _) => some e
                     | (none, rem') => scanCopyTuples liveB r entryPt o p_v b_thr (fun _ => true) rem' (codes.drop tupIdx)) := by
                  rw [htar]; simp [scanLiveCands, hcorr]
                by_cases hk0 : k = 0
                · subst hk0
                  have hstep_eq : queryCopyStep entryPt o p_v b_thr S r codes (tupIdx, true, curNd, 1, none) =
                      (tupIdx, false, -1, 0, none) := by
                    unfold queryCopyStep
                    simp only [Option.isSome_none, one_ne_zero, decide_false, Bool.or_self,
                      Bool.false_eq_true, ↓reduceIte, hcur_nneg, hcur_nat, if_neg hcorr, Nat.sub_self]
                  rw [hstep_eq]
                  refine ⟨⟨htup_le, by omega, ?_⟩, fun h0 => by omega, fun _ => by rw [hphi_val]; simp [Φ]⟩
                  rw [if_pos rfl, htar_step]
                  refine ⟨?_, rfl⟩
                  cases hxs : xs.map S.nEid <;> cases codes.drop tupIdx <;> simp [scanLiveCands, scanCopyTuples]
                · have hstep_eq : queryCopyStep entryPt o p_v b_thr S r codes (tupIdx, true, curNd, k + 1, none) =
                      (tupIdx, decide (0 ≤ S.nNext x), S.nNext x, k, none) := by
                    unfold queryCopyStep
                    simp only [Option.isSome_none, Nat.add_eq_zero_iff, one_ne_zero, and_false, decide_false,
                      Bool.or_self, Bool.false_eq_true, ↓reduceIte, hcur_nneg, hcur_nat, if_neg hcorr,
                      Nat.add_sub_cancel, if_neg hk0]
                  rw [hstep_eq]
                  refine ⟨⟨htup_le, by omega, ?_⟩, fun h0 => by omega, fun _ => ?_⟩
                  · rw [if_neg hk0]
                    cases xs with
                    | nil =>
                        have hnx_neg : S.nNext x = -1 := hnx_x
                        have hdec_f : decide (0 ≤ S.nNext x) = false := by rw [hnx_neg]; decide
                        rw [hdec_f, if_neg Bool.false_ne_true, htar_step]
                        simp [scanLiveCands]
                    | cons y ys =>
                        have hnx_y : S.nNext x = (y : ℤ) := hnx_x
                        have hdec_t : decide (0 ≤ S.nNext x) = true := by rw [hnx_y]; exact decide_eq_true (by omega)
                        rw [hdec_t, if_pos rfl]
                        exact ⟨(x : ℤ), y, ys, c₀, hnx_y, htl_xs,
                          fun z hz => hmem_c₀ z (List.mem_cons_of_mem x hz), htar_step⟩
                  · rw [hphi_val]
                    simp only [Φ, Option.isSome_none, Bool.or_eq_true,
                      Bool.and_eq_true, Bool.not_eq_true', decide_eq_true_iff]
                    split_ifs <;> omega
  have hiter : ∀ t : ℕ,
      let st_t := (queryCopyStep entryPt o p_v b_thr S r codes)^[t] (0, false, -1, cap_q + 1, none)
      Inv st_t ∧ Φ st_t ≤ (2 * cap_q + 1) - t := by
    intro t
    induction t with
    | zero =>
        simp only [Function.iterate_zero, id_eq, Nat.sub_zero]
        refine ⟨hInv0, ?_⟩
        dsimp [Φ]; split_ifs <;> omega
    | succ t ih =>
        rw [Function.iterate_succ_apply']
        obtain ⟨hIt, hPhit⟩ := ih
        obtain ⟨hIs, h0_eq, hpos_lt⟩ := hstep _ hIt
        refine ⟨hIs, ?_⟩
        by_cases h0 : Φ ((queryCopyStep entryPt o p_v b_thr S r codes)^[t] (0, false, -1, cap_q + 1, none)) = 0
        · rw [h0_eq h0, h0]; omega
        · have := hpos_lt (by omega)
          omega
  refine ⟨?_, ?_⟩
  · obtain ⟨hIe, hPhie⟩ := hiter (2 * cap_q + 2)
    have hPhi0 : Φ ((queryCopyStep entryPt o p_v b_thr S r codes)^[2 * cap_q + 2] (0, false, -1, cap_q + 1, none)) = 0 := by omega
    set st_e := (queryCopyStep entryPt o p_v b_thr S r codes)^[2 * cap_q + 2] (0, false, -1, cap_q + 1, none)
    rcases st_e with ⟨tupIdx, inBkt, curNd, remRej, ans⟩
    rcases hIe with ⟨htup_le, _, hval⟩
    dsimp only at hval ⊢
    cases ans with
    | some eid => rw [← htarget_eq]; exact hval.1.symm
    | none =>
        rw [← htarget_eq]
        by_cases hr0 : remRej = 0
        · rw [if_pos hr0] at hval; exact hval.1.symm
        · rw [if_neg hr0] at hval
          cases inBkt with
          | true =>
              dsimp [Φ] at hPhi0
              simp [hr0] at hPhi0
          | false =>
              rw [if_neg Bool.false_ne_true] at hval
              dsimp [Φ] at hPhi0
              have hge : codes.length ≤ tupIdx := by
                by_contra hlt; push_neg at hlt
                rw [if_neg (by simp; omega)] at hPhi0; omega
              have heq_len : tupIdx = codes.length := by omega
              rw [heq_len, List.drop_length] at hval
              simpa [scanCopyTuples] using hval.symm
  · intro t _
    dsimp only
    intro hin hcur0
    have hIt := (hiter t).1
    generalize (queryCopyStep entryPt o p_v b_thr S r codes)^[t] (0, false, -1, cap_q + 1, none) = st_t at hIt hin hcur0 ⊢
    rcases st_t with ⟨tupIdx, inBkt, curNd, remRej, ans⟩
    dsimp only [Inv] at hIt hin hcur0 ⊢
    rcases hIt with ⟨_, _, hval⟩
    subst hin
    cases ans with
    | some _ => dsimp only at hval; cases hval.2
    | none =>
        dsimp only at hval
        by_cases hr0 : remRej = 0
        · rw [if_pos hr0] at hval; cases hval.2
        · rw [if_neg hr0, if_pos rfl] at hval
          rcases hval with ⟨_, x, xs, c₀, hcur_x, _, hmem_c₀, _⟩
          have hnat : curNd.toNat = x := by rw [hcur_x]; exact Int.toNat_natCast x
          rw [hnat]
          have hx_in : x ∈ ndL r c₀ := hmem_c₀ x List.mem_cons_self
          have hx_pool : x < B_max * (R * cap_u) := ((hinv.2.2.2.1 r c₀).2 x hx_in).1
          have hx_eid_mem : S.nEid x ∈ (ndL r c₀).map S.nEid := List.mem_map_of_mem hx_in
          rw [(hmap r c₀).2] at hx_eid_mem
          exact ⟨hx_pool, of_decide_eq_true (by simpa using (List.mem_filter.mp hx_eid_mem).2)⟩

end UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
