import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.lem_5_1
import UL.Stmt.clm_7_3_global_approx
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H4c1_NodePrim
import UL.Proof.clm_9_1_explicit_tradeoff.H4c2_ChainSched
import UL.Proof.clm_9_1_explicit_tradeoff.H4c3a_GhostUID
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H4c3b

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a

/-! ### 1. Bundled Static Engine Parameters (`ChainParams`) & Algebraic Schedule Constants -/

structure ChainParams (d : ℕ) (params : LocalScaleParams) (h : ℝ) where
  n : ℕ
  hn : 2 ≤ n
  T_pow : ℕ
  hT_pow : n ≤ T_pow
  L_p2 : ℕ
  hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2
  R : ℕ
  ℓ : ℕ
  M₀ : ℕ
  hM₀ : 1 ≤ M₀
  b : ℕ
  T_cdf : ℕ
  p_coord : ℕ
  τ_d : ℚ
  τ_q : ℚ
  cap_u : ℕ
  cap_q : ℕ
  N_cfg : ℕ
  specs : Fin N_cfg → ConfigStaticSpec d params h
  hspecs_surj : ∀ c ∈ params.retainedConfigs 1, ∃ i : Fin N_cfg, (specs i).cfg = c
  phiRat : ℚ
  hφ0 : 0 < (phiRat : ℝ)
  hφ1 : (phiRat : ℝ) < 1 / 2
  P_hpj : HPJParams
  hP_hpj_eq : P_hpj = hpjParams d (phiRat : ℝ)
  hP_hpj : HPJParamProps d (phiRat : ℝ) P_hpj
  N_samp : ℕ
  hmN : 2 ^ P_hpj.q ≤ N_samp
  q_idx : ℕ
  k_base : ℕ
  hk_base : 1 ≤ k_base

def ChainParams.D_max {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (_cp : ChainParams d params h) : ℕ :=
  4 * K_alpha d * (Nat.clog 2 (_cp.n + 2) + 2)

def ChainParams.D2 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.D_max + 2

def ChainParams.B_scan {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  16384 * cp.D2 ^ 2 * (K_alpha d) ^ 2

theorem ChainParams.D_max_pos {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : 1 ≤ cp.D_max := by
  unfold ChainParams.D_max
  have := K_alpha_ge_36 d
  nlinarith only [this]

theorem ChainParams.B_scan_bounds {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    8192 ≤ cp.B_scan ∧
    K_alpha d < cp.B_scan ∧
    (cp.B_scan + 2) * cp.D2 ≤ cp.B_scan * (cp.D2 + 1) ∧
    128 * K_alpha d * (cp.D2 * 12) < cp.B_scan ∧
    cp.B_scan + 64 * K_alpha d * (cp.D_max * 24 + 12) + 64 * K_alpha d ≤ 2 * cp.B_scan := by
  have hK : 36 ≤ K_alpha d := K_alpha_ge_36 d
  have hD : 1 ≤ cp.D_max := cp.D_max_pos
  have hD2 : cp.D2 = cp.D_max + 2 := rfl
  have hB : cp.B_scan = 16384 * cp.D2 ^ 2 * (K_alpha d) ^ 2 := rfl
  have hK2 : 1296 ≤ (K_alpha d) ^ 2 := by nlinarith only [hK]
  have hD2_sq : 9 ≤ cp.D2 ^ 2 := by nlinarith only [hD, hD2]
  have hDK_pos : 1 ≤ cp.D2 * K_alpha d := by nlinarith only [hK, hD, hD2]
  have hDK_sq : (cp.D2 * K_alpha d) ^ 2 = cp.D2 ^ 2 * (K_alpha d) ^ 2 := by ring
  have hDK_le : cp.D2 * K_alpha d ≤ cp.D2 ^ 2 * (K_alpha d) ^ 2 := by
    nlinarith only [hDK_pos, hDK_sq]
  have hlin4 : 128 * K_alpha d * (cp.D2 * 12) = 1536 * (cp.D2 * K_alpha d) := by ring
  have hlin5 : 64 * K_alpha d * (cp.D_max * 24 + 12) + 64 * K_alpha d ≤
      1536 * (cp.D2 * K_alpha d) := by nlinarith only [hK, hD, hD2]
  have hB_ge : 16384 * (cp.D2 * K_alpha d) ≤ cp.B_scan := by
    rw [hB]; linarith only [Nat.mul_le_mul_left 16384 hDK_le]
  refine ⟨by nlinarith only [hB, hK2, hD2_sq],
    by nlinarith only [hB, hK, hK2, hD2_sq],
    by
      have h2D2 : 2 * cp.D2 < cp.B_scan := by nlinarith only [hB_ge, hK, hD, hD2]
      nlinarith only [h2D2],
    by nlinarith only [hlin4, hB_ge, hDK_pos],
    by nlinarith only [hlin5, hB_ge, hDK_pos]⟩

abbrev MNode {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) : Type :=
  ManagedNode cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b cp.N_cfg

abbrev OpSeed {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) : Type :=
  NodeOpSeed cp.N_cfg cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b

abbrev CenterSeed {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) : Type :=
  HPJCoin cp.N_samp cp.q_idx (cp.P_hpj.L * (d + 1 + 3) * cp.P_hpj.q)

/-! ### 2. Live Update Propagation Along a `List (MNode cp)` (`liveUpdateChainList`) -/

/-- Propagate a single external insertion `insert (h_new, pt)` or deletion `delete h_del` along a
prefix list of `ManagedNode`s, stopping as soon as a node's core absorbs the point. Returns
`(updatedNodes, passedAll)`. -/
noncomputable def liveUpdateChainList {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h)
    (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (isIns : Bool) (h_op : ℕ)
    (seeds : ℕ → OpSeed cp) :
    ℕ → List (MNode cp) → List (MNode cp) × Bool
  | _, [] => ([], true)
  | idx, mn :: rest =>
      let M_lat := M_lat_of d params.e
      let mn₁ :=
        if isIns then
          (mn.insertMat cp.hM₀ cp.T_cdf cp.p_coord M_lat params cp.specs
            cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_op (seeds idx)).bumpAge
        else
          (mn.deleteMat cp.hM₀ cp.T_cdf cp.p_coord M_lat params cp.specs
            cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_op (seeds idx)).bumpAge
      if inCoreBall mn.nd.o mn.nd.V (pts' h_op) then
        (mn₁ :: rest, false)
      else
        let sub := liveUpdateChainList cp pts' isIns h_op seeds (idx + 1) rest
        (mn₁ :: sub.1, sub.2)

theorem liveUpdateChainList_true_cons {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (h_op : ℕ) (seeds : ℕ → OpSeed cp) (idx : ℕ) (mn : MNode cp) (rest : List (MNode cp)) :
    liveUpdateChainList cp pts' true h_op seeds idx (mn :: rest) =
      let mn₁ := (mn.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
        cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_op (seeds idx)).bumpAge
      if inCoreBall mn.nd.o mn.nd.V (pts' h_op) then
        (mn₁ :: rest, false)
      else
        let sub := liveUpdateChainList cp pts' true h_op seeds (idx + 1) rest
        (mn₁ :: sub.1, sub.2) := rfl

theorem liveUpdateChainList_false_cons {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (h_op : ℕ) (seeds : ℕ → OpSeed cp) (idx : ℕ) (mn : MNode cp) (rest : List (MNode cp)) :
    liveUpdateChainList cp pts' false h_op seeds idx (mn :: rest) =
      let mn₁ := (mn.deleteMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
        cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_op (seeds idx)).bumpAge
      if inCoreBall mn.nd.o mn.nd.V (pts' h_op) then
        (mn₁ :: rest, false)
      else
        let sub := liveUpdateChainList cp pts' false h_op seeds (idx + 1) rest
        (mn₁ :: sub.1, sub.2) := rfl

@[simp] theorem bumpAge_o {L_p2 R ℓ M₀ d b N_cfg : ℕ} (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) :
    mn.bumpAge.nd.o = mn.nd.o := rfl
@[simp] theorem bumpAge_s {L_p2 R ℓ M₀ d b N_cfg : ℕ} (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) :
    mn.bumpAge.nd.s = mn.nd.s := rfl
@[simp] theorem bumpAge_V {L_p2 R ℓ M₀ d b N_cfg : ℕ} (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) :
    mn.bumpAge.nd.V = mn.nd.V := rfl
@[simp] theorem bumpAge_curSet {L_p2 R ℓ M₀ d b N_cfg : ℕ} (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) :
    mn.bumpAge.nd.curSet = mn.nd.curSet := rfl
@[simp] theorem bumpAge_birthSet {L_p2 R ℓ M₀ d b N_cfg : ℕ} (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) :
    mn.bumpAge.nd.birthSet = mn.nd.birthSet := rfl
@[simp] theorem bumpAge_birthSize {L_p2 R ℓ M₀ d b N_cfg : ℕ} (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) :
    mn.bumpAge.nd.birthSize = mn.nd.birthSize := rfl
@[simp] theorem bumpAge_age {L_p2 R ℓ M₀ d b N_cfg : ℕ} (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) :
    mn.bumpAge.nd.age = mn.nd.age + 1 := rfl
@[simp] theorem bumpAge_histArr {L_p2 R ℓ M₀ d b N_cfg : ℕ} (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) :
    mn.bumpAge.histArr = mn.histArr := rfl
@[simp] theorem bumpAge_maxTIns {L_p2 R ℓ M₀ d b N_cfg : ℕ} (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) (k : ℕ) :
    mn.bumpAge.nd.maxTIns k ↔ mn.nd.maxTIns k := Iff.rfl
@[simp] theorem bumpAge_wf {L_p2 R ℓ M₀ d b N_cfg : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d : ℚ) (cap_u : ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) :
    ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts mn.bumpAge ↔
      ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts mn := Iff.rfl
@[simp] theorem bumpAge_matGood {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) :
    NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts mn.bumpAge.nd ↔
      NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts mn.nd := Iff.rfl

/-- Sequential residual folding along a `List (MNode cp)` starting from input set `S₀`. -/
noncomputable def foldResiduals {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) :
    Finset ℕ → List (MNode cp) → Finset ℕ
  | S, [] => S
  | S, mn :: rest => foldResiduals pts (nodeResidual pts mn.nd.o mn.nd.V S) rest

/-- Structural invariant of a node `mn` on active input `S ⊆ actHandles` (`actHandles.card ≤ cp.n`). -/
def LiveNodeInv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h)
    (_actHandles : Finset ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (gt : GhostTracker d) (S : Finset ℕ) (mn : MNode cp) : Prop :=
  mn.nd.curSet = S ∧
  mn.nd.birthSize ≤ cp.n ∧
  cp.B_scan < mn.nd.birthSize ∧
  (∀ u ∈ mn.nd.birthSet, u < gt.nextUid) ∧
  HasNodeAge mn.nd.birthSet (S.image gt.uidOf) mn.nd.age ∧
  mn.histArr.length ≤ mn.nd.birthSize + mn.nd.age ∧
  mn.nd.maxTIns (mn.nd.birthSize + mn.nd.age) ∧
  ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts mn

def LiveNodeGood {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (gt : GhostTracker d) (mn : MNode cp) : Prop :=
  IsCenterpoint (hpjAlpha d)
    (paraboloidLiftSet (fun u : mn.nd.birthSet => gt.ghostPts u.1))
    (liftedPoint mn.nd.o mn.nd.s) ∧
  NodeInstMatGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
    cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q pts mn.nd

/-- Unchanged node preservation when the external update was absorbed by an ancestor's core! -/
theorem liveNodeInv_unchanged_insert {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles S : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} {h_new : ℕ} (hnot_act : h_new ∉ actHandles)
    (pt : EuclideanSpace ℝ (Fin d))
    (hpts_old : ∀ x ∈ actHandles, pts' x = pts x)
    (hS_sub : S ⊆ actHandles)
    {mn : MNode cp}
    (hinv : LiveNodeInv cp actHandles pts gt S mn) :
    let gt' := gt.stepInsert h_new pt
    LiveNodeInv cp (insert h_new actHandles) pts' gt' S mn ∧
    (LiveNodeGood cp hh0 hh1 pts gt mn → LiveNodeGood cp hh0 hh1 pts' gt' mn) := by
  rcases hinv with ⟨hcur, hbsz_n, hbsz_B, hbirth_uid, hage, hhist, htins, hwf⟩
  have heq_S : ∀ x ∈ mn.nd.curSet, pts' x = pts x := fun x hx => hpts_old x (hS_sub (hcur ▸ hx))
  rcases managedNode_pts_congr (M_lat := M_lat_of d params.e) (τ_q := cp.τ_q) (cap_q := cp.cap_q)
    hh0 hh1 heq_S hwf with ⟨hwf', hgd_imp⟩
  have hS_img_eq : S.image (gt.stepInsert h_new pt).uidOf = S.image gt.uidOf := by
    refine Finset.image_congr (fun x hx => ?_)
    have hne : x ≠ h_new := fun heq => hnot_act (heq ▸ hS_sub hx)
    dsimp [GhostTracker.stepInsert]
    exact Function.update_of_ne hne gt.nextUid gt.uidOf
  refine ⟨⟨hcur, hbsz_n, hbsz_B, fun u hu => Nat.lt_succ_of_lt (hbirth_uid u hu),
    by rwa [hS_img_eq], hhist, htins, hwf'⟩, fun ⟨hcp, hgd⟩ => ⟨?_, hgd_imp hgd⟩⟩
  refine isCenterpoint_congr_ghostPts (fun u hu => ?_) hcp
  have hne : u ≠ gt.nextUid := Nat.ne_of_lt (hbirth_uid u hu)
  dsimp [GhostTracker.stepInsert]
  exact Function.update_of_ne hne pt gt.ghostPts

theorem liveNodeInv_unchanged_delete {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles S : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} {h_del : ℕ} (hnot_S : h_del ∉ S)
    (hpts_old : ∀ x ∈ actHandles.erase h_del, pts' x = pts x)
    (hS_sub : S ⊆ actHandles)
    {mn : MNode cp}
    (hinv : LiveNodeInv cp actHandles pts gt S mn) :
    LiveNodeInv cp (actHandles.erase h_del) pts' gt S mn ∧
    (LiveNodeGood cp hh0 hh1 pts gt mn → LiveNodeGood cp hh0 hh1 pts' gt mn) := by
  rcases hinv with ⟨hcur, hbsz_n, hbsz_B, hbirth_uid, hage, hhist, htins, hwf⟩
  have heq_S : ∀ x ∈ mn.nd.curSet, pts' x = pts x := by
    intro x hx
    have hxS : x ∈ S := hcur ▸ hx
    have hne : x ≠ h_del := fun heq => hnot_S (heq ▸ hxS)
    exact hpts_old x (Finset.mem_erase.mpr ⟨hne, hS_sub hxS⟩)
  rcases managedNode_pts_congr (M_lat := M_lat_of d params.e) (τ_q := cp.τ_q) (cap_q := cp.cap_q)
    hh0 hh1 heq_S hwf with ⟨hwf', hgd_imp⟩
  exact ⟨⟨hcur, hbsz_n, hbsz_B, hbirth_uid, hage, hhist, htins, hwf'⟩,
    fun ⟨hcp, hgd⟩ => ⟨hcp, hgd_imp hgd⟩⟩

/-- Inductive invariant along a sequential list `nds` starting from `S₀`. -/
def ChainListInv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h)
    (actHandles : Finset ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (gt : GhostTracker d) : Finset ℕ → List (MNode cp) → Prop
  | _, [] => True
  | S, mn :: rest =>
      LiveNodeInv cp actHandles pts gt S mn ∧
      ChainListInv cp actHandles pts gt (nodeResidual pts mn.nd.o mn.nd.V S) rest

def ChainListGood {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (gt : GhostTracker d) (nds : List (MNode cp)) : Prop :=
  ∀ mn ∈ nds, LiveNodeGood cp hh0 hh1 pts gt mn

theorem chainListInv_unchanged_insert {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} {h_new : ℕ} (hnot_act : h_new ∉ actHandles)
    (pt : EuclideanSpace ℝ (Fin d))
    (hpts_old : ∀ x ∈ actHandles, pts' x = pts x) :
    ∀ (S : Finset ℕ) (nds : List (MNode cp)),
      S ⊆ actHandles →
      ChainListInv cp actHandles pts gt S nds →
      let gt' := gt.stepInsert h_new pt
      foldResiduals pts' S nds = foldResiduals pts S nds ∧
      ChainListInv cp (insert h_new actHandles) pts' gt' S nds ∧
      (ChainListGood cp hh0 hh1 pts gt nds → ChainListGood cp hh0 hh1 pts' gt' nds)
  | S, [], _, _ => ⟨rfl, trivial, fun _ _ hm => absurd hm List.not_mem_nil⟩
  | S, mn :: rest, hS_sub, ⟨hhead, htail⟩ => by
      rcases liveNodeInv_unchanged_insert hh0 hh1 hnot_act pt hpts_old hS_sub hhead with ⟨hhead', hgd_hd⟩
      have hres_eq : nodeResidual pts' mn.nd.o mn.nd.V S = nodeResidual pts mn.nd.o mn.nd.V S := by
        ext x; unfold nodeResidual nodeCore
        simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter]
        constructor <;> (rintro ⟨hx, hnc⟩; refine ⟨hx, ?_⟩; rintro ⟨_, hcb⟩; apply hnc ⟨hx, ?_⟩)
        · rwa [hpts_old x (hS_sub hx)]
        · rwa [← hpts_old x (hS_sub hx)]
      have hres_sub : nodeResidual pts mn.nd.o mn.nd.V S ⊆ actHandles := by
        intro x hx; unfold nodeResidual at hx
        rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hS_sub hx.1
      rcases chainListInv_unchanged_insert hh0 hh1 hnot_act pt hpts_old
        (nodeResidual pts mn.nd.o mn.nd.V S) rest hres_sub htail with ⟨hfold_tl, htail', hgd_tl⟩
      dsimp only [foldResiduals, ChainListInv]
      rw [hres_eq]
      refine ⟨hfold_tl, ⟨hhead', htail'⟩, fun hgd x hx => ?_⟩
      rcases List.mem_cons.mp hx with hx_eq | hx_tl
      · subst hx_eq; exact hgd_hd (hgd _ List.mem_cons_self)
      · exact hgd_tl (fun y hy => hgd y (List.mem_cons_of_mem mn hy)) x hx_tl

theorem chainListInv_unchanged_delete {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} {h_del : ℕ}
    (hpts_old : ∀ x ∈ actHandles.erase h_del, pts' x = pts x) :
    ∀ (S : Finset ℕ) (nds : List (MNode cp)),
      S ⊆ actHandles → h_del ∉ S →
      ChainListInv cp actHandles pts gt S nds →
      foldResiduals pts' S nds = foldResiduals pts S nds ∧
      ChainListInv cp (actHandles.erase h_del) pts' gt S nds ∧
      (ChainListGood cp hh0 hh1 pts gt nds → ChainListGood cp hh0 hh1 pts' gt nds)
  | S, [], _, _, _ => ⟨rfl, trivial, fun _ _ hm => absurd hm List.not_mem_nil⟩
  | S, mn :: rest, hS_sub, hnot_S, ⟨hhead, htail⟩ => by
      rcases liveNodeInv_unchanged_delete hh0 hh1 hnot_S hpts_old hS_sub hhead with ⟨hhead', hgd_hd⟩
      have hpts_S : ∀ x ∈ S, pts' x = pts x := fun x hx =>
        hpts_old x (Finset.mem_erase.mpr ⟨fun heq => hnot_S (heq ▸ hx), hS_sub hx⟩)
      have hres_eq : nodeResidual pts' mn.nd.o mn.nd.V S = nodeResidual pts mn.nd.o mn.nd.V S := by
        ext x; unfold nodeResidual nodeCore
        simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter]
        constructor <;> (rintro ⟨hx, hnc⟩; refine ⟨hx, ?_⟩; rintro ⟨_, hcb⟩; apply hnc ⟨hx, ?_⟩)
        · rwa [hpts_S x hx]
        · rwa [← hpts_S x hx]
      have hres_sub : nodeResidual pts mn.nd.o mn.nd.V S ⊆ actHandles := by
        intro x hx; unfold nodeResidual at hx
        rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hS_sub hx.1
      have hnot_res : h_del ∉ nodeResidual pts mn.nd.o mn.nd.V S := by
        intro hx; unfold nodeResidual at hx
        rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hnot_S hx.1
      rcases chainListInv_unchanged_delete hh0 hh1 hpts_old
        (nodeResidual pts mn.nd.o mn.nd.V S) rest hres_sub hnot_res htail with ⟨hfold_tl, htail', hgd_tl⟩
      dsimp only [foldResiduals, ChainListInv]
      rw [hres_eq]
      refine ⟨hfold_tl, ⟨hhead', htail'⟩, fun hgd x hx => ?_⟩
      rcases List.mem_cons.mp hx with hx_eq | hx_tl
      · subst hx_eq; exact hgd_hd (hgd _ List.mem_cons_self)
      · exact hgd_tl (fun y hy => hgd y (List.mem_cons_of_mem mn hy)) x hx_tl

/-- Master theorem for `liveUpdateChainList` on `insert (h_new, pt)` (`h_new ∉ actHandles`). -/
theorem liveUpdateChainList_insert_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hgt : GhostTrackerWF actHandles pts gt)
    {h_new : ℕ} (hnot_act : h_new ∉ actHandles) (pt : EuclideanSpace ℝ (Fin d))
    (hpts_new : pts' h_new = pt)
    (hpts_old : ∀ x ∈ actHandles, pts' x = pts x)
    (seeds : ℕ → OpSeed cp) :
    ∀ (idx : ℕ) (S : Finset ℕ) (nds : List (MNode cp)),
      S ⊆ actHandles →
      (∀ mn ∈ nds, mn.nd.age ≤ mn.nd.birthSize) →
      ChainListInv cp actHandles pts gt S nds →
      let gt' := gt.stepInsert h_new pt
      let res := liveUpdateChainList cp pts' true h_new seeds idx nds
      res.1.length = nds.length ∧
      (∀ q (hq1 : q < nds.length) (hq2 : q < res.1.length),
        let mn₀ := nds[q]'hq1
        let mn₁ := res.1[q]'hq2
        mn₁.nd.o = mn₀.nd.o ∧ mn₁.nd.V = mn₀.nd.V ∧
        mn₁.nd.birthSize = mn₀.nd.birthSize ∧
        mn₁.nd.age ≤ mn₀.nd.age + 1) ∧
      ChainListInv cp (insert h_new actHandles) pts' gt' (insert h_new S) res.1 ∧
      (if res.2 then
        foldResiduals pts' (insert h_new S) res.1 = insert h_new (foldResiduals pts S nds)
      else
        foldResiduals pts' (insert h_new S) res.1 = foldResiduals pts S nds) ∧
      (ChainListGood cp hh0 hh1 pts gt nds →
       (∀ q (hq : q < nds.length),
         NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
           cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q (nds[q]'hq).nd (seeds (idx + q))) →
       ChainListGood cp hh0 hh1 pts' gt' res.1)
  | _, S, [], _, _, _ => by
      simp [liveUpdateChainList, foldResiduals, ChainListInv, ChainListGood]
  | idx, S, mn :: rest, hS_sub, hage_le, ⟨hhead, htail⟩ => by
      let gt' := gt.stepInsert h_new pt
      let M_lat := M_lat_of d params.e
      rcases hhead with ⟨hcur, hbsz_n, hbsz_B, hbirth_uid, hage, hhist, htins, hwf⟩
      have heq_S : ∀ x ∈ mn.nd.curSet, pts' x = pts x := fun x hx => hpts_old x (hS_sub (hcur ▸ hx))
      rcases managedNode_pts_congr (M_lat := M_lat) (τ_q := cp.τ_q) (cap_q := cp.cap_q)
        hh0 hh1 heq_S hwf with ⟨hwf_pts', hgd_pts'⟩
      have hp_not_cur : h_new ∉ mn.nd.curSet := fun hm => hnot_act (hS_sub (hcur ▸ hm))
      have hcap_t : (mn.nd.birthSize + mn.nd.age) + 1 < 2 ^ cp.L_p2 := by
        have h1 := hage_le mn List.mem_cons_self
        have h2 := cp.hL_p2
        omega
      rcases managedNode_insertMat_spec h_clm_7_3 hd cp.hM₀ cp.T_cdf cp.p_coord params he1
        cp.specs cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q hp_not_cur (seeds idx)
        htins hcap_t hwf_pts'
        with ⟨ho, hs, hV, hbS, hbsz, hage_eq, hcur', hhist', htins', hwf_ins', hgd_ins⟩
      let mn_mat := mn.insertMat cp.hM₀ cp.T_cdf cp.p_coord M_lat params cp.specs
        cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_new (seeds idx)
      let mn₁ := mn_mat.bumpAge
      rcases image_insert_uidOf hgt hS_sub hnot_act pt with ⟨hu_not_img, himg_ins⟩
      have hage₁ : HasNodeAge mn₁.nd.birthSet ((insert h_new S).image gt'.uidOf) mn₁.nd.age := by
        dsimp only [mn₁, mn_mat, M_lat, gt']
        rw [bumpAge_birthSet, bumpAge_age, hbS, hage_eq, himg_ins]
        exact hasNodeAge_step hage (Or.inl ⟨gt.nextUid, hu_not_img, by ext z; simp⟩)
      have hhead₁ : LiveNodeInv cp (insert h_new actHandles) pts' gt' (insert h_new S) mn₁ := by
        refine ⟨by dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_curSet, hcur', hcur],
          by dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_birthSize, hbsz]; exact hbsz_n,
          by dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_birthSize, hbsz]; exact hbsz_B,
          fun u hu => Nat.lt_succ_of_lt (hbirth_uid u (by dsimp only [mn₁, mn_mat, M_lat] at *; simpa only [ bumpAge_birthSet, hbS] using hu)),
          hage₁, ?_, ?_, (bumpAge_wf _ _ _ _ _ _ _ _ _).mpr hwf_ins'⟩
        · dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_histArr, bumpAge_birthSize, bumpAge_age, hhist',
            List.length_append, List.length_singleton, hbsz, hage_eq]
          omega
        · dsimp only [mn₁, mn_mat, M_lat]
          rw [bumpAge_birthSize, bumpAge_age, bumpAge_maxTIns, hbsz, hage_eq,
            show mn.nd.birthSize + (mn.nd.age + 1) = (mn.nd.birthSize + mn.nd.age) + 1 by omega]
          exact htins'
      have hgd₁ : LiveNodeGood cp hh0 hh1 pts gt mn →
          NodeOpSeedGood cp.T_cdf cp.p_coord M_lat params cp.specs cp.τ_d cp.τ_q
            hh0 hh1 cp.cap_u cp.cap_q mn.nd (seeds idx) →
          LiveNodeGood cp hh0 hh1 pts' gt' mn₁ := by
        rintro ⟨hcp, hgd_m⟩ hseed₀
        refine ⟨?_, (bumpAge_matGood _ _ _ _ _ _ _ _ _ _ _ _ _).mpr (hgd_ins (hgd_pts' hgd_m) hseed₀)⟩
        dsimp only [mn₁, mn_mat, M_lat]
        rw [bumpAge_birthSet, bumpAge_o, bumpAge_s, hbS, ho, hs]
        refine isCenterpoint_congr_ghostPts (fun u hu => ?_) hcp
        have hne : u ≠ gt.nextUid := Nat.ne_of_lt (hbirth_uid u hu)
        dsimp [gt', GhostTracker.stepInsert]
        exact Function.update_of_ne hne pt gt.ghostPts
      have hV_nn : 0 ≤ mn.nd.V := le_max_left _ _
      have hres_sub : nodeResidual pts mn.nd.o mn.nd.V S ⊆ actHandles := by
        intro x hx; unfold nodeResidual at hx
        rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hS_sub hx.1
      dsimp only
      rw [liveUpdateChainList_true_cons]
      dsimp only
      by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_new) = true
      · rw [if_pos hcb]
        have hp_in_cb : pts' h_new ∈ coreBall mn.nd.o mn.nd.V :=
          (inCoreBall_eq_true_iff mn.nd.o hV_nn (pts' h_new)).mp hcb
        have hres_same : nodeResidual pts' mn₁.nd.o mn₁.nd.V (insert h_new S) =
            nodeResidual pts mn.nd.o mn.nd.V S := by
          dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_o, bumpAge_V, ho, hV]
          ext x; unfold nodeResidual nodeCore
          simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter, Finset.mem_insert]
          constructor
          · rintro ⟨rfl | hx, hnc⟩
            · exact absurd ⟨Or.inl rfl, hp_in_cb⟩ hnc
            · refine ⟨hx, fun hh => hnc ⟨Or.inr hx, ?_⟩⟩
              rw [hpts_old x (hS_sub hx)]; exact hh.2
          · rintro ⟨hx, hnc⟩
            refine ⟨Or.inr hx, fun hh => hnc ⟨hx, ?_⟩⟩
            rw [← hpts_old x (hS_sub hx)]; exact hh.2
        rcases chainListInv_unchanged_insert hh0 hh1 hnot_act pt hpts_old
          (nodeResidual pts mn.nd.o mn.nd.V S) rest hres_sub htail with ⟨hfold_tl, htail', hgd_tl⟩
        refine ⟨rfl, ?_, ⟨hhead₁, ?_⟩, ?_, ?_⟩
        · intro q hq1 hq2
          cases q with
          | zero =>
              dsimp only [List.getElem_cons_zero, mn₁, mn_mat]
              rw [bumpAge_o, bumpAge_V, bumpAge_birthSize, bumpAge_age, ho, hV, hbsz, hage_eq]
              exact ⟨rfl, rfl, rfl, le_rfl⟩
          | succ q' =>
              dsimp only [List.getElem_cons_succ]
              exact ⟨rfl, rfl, rfl, Nat.le_succ _⟩
        · change ChainListInv cp (insert h_new actHandles) pts' gt' (nodeResidual pts' mn₁.nd.o mn₁.nd.V (insert h_new S)) rest
          rwa [hres_same]
        · dsimp only [foldResiduals]
          rw [if_neg Bool.false_ne_true]
          change foldResiduals pts' (nodeResidual pts' mn₁.nd.o mn₁.nd.V (insert h_new S)) rest = _
          rw [hres_same, hfold_tl]
        · intro hgd_all hseeds_all x hx
          rcases List.mem_cons.mp hx with hx_eq | hx_tl
          · subst hx_eq
            have hs0 := hseeds_all 0 (Nat.zero_lt_succ _)
            simp only [Nat.add_zero, List.getElem_cons_zero] at hs0
            exact hgd₁ (hgd_all _ List.mem_cons_self) hs0
          · exact hgd_tl (fun y hy => hgd_all y (List.mem_cons_of_mem mn hy)) x hx_tl
      · rw [if_neg hcb]
        dsimp only
        have hp_not_cb : pts' h_new ∉ coreBall mn.nd.o mn.nd.V :=
          (inCoreBall_eq_false_iff mn.nd.o hV_nn (pts' h_new)).mp (Bool.eq_false_iff.mpr hcb)
        have hres_ins : nodeResidual pts' mn₁.nd.o mn₁.nd.V (insert h_new S) =
            insert h_new (nodeResidual pts mn.nd.o mn.nd.V S) := by
          dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_o, bumpAge_V, ho, hV]
          ext x; unfold nodeResidual nodeCore
          simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter, Finset.mem_insert]
          constructor
          · rintro ⟨rfl | hx, hnc⟩
            · exact Or.inl rfl
            · refine Or.inr ⟨hx, fun hh => hnc ⟨Or.inr hx, ?_⟩⟩
              rw [hpts_old x (hS_sub hx)]; exact hh.2
          · rintro (rfl | ⟨hx, hnc⟩)
            · exact ⟨Or.inl rfl, fun hh => hp_not_cb hh.2⟩
            · refine ⟨Or.inr hx, fun hh => hnc ⟨hx, ?_⟩⟩
              rw [← hpts_old x (hS_sub hx)]; exact hh.2
        rcases liveUpdateChainList_insert_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hnot_act pt
          hpts_new hpts_old seeds (idx + 1) (nodeResidual pts mn.nd.o mn.nd.V S) rest
          hres_sub (fun y hy => hage_le y (List.mem_cons_of_mem mn hy)) htail
          with ⟨hlen_sub, hmeta_sub, hinv_sub, hfold_sub, hgd_sub⟩
        set sub := liveUpdateChainList cp pts' true h_new seeds (idx + 1) rest
        refine ⟨by simp [hlen_sub], ?_, ⟨hhead₁, ?_⟩, ?_, ?_⟩
        · intro q hq1 hq2
          cases q with
          | zero =>
              dsimp only [List.getElem_cons_zero, mn₁, mn_mat]
              rw [bumpAge_o, bumpAge_V, bumpAge_birthSize, bumpAge_age, ho, hV, hbsz, hage_eq]
              exact ⟨rfl, rfl, rfl, le_rfl⟩
          | succ q' =>
              simp only [List.getElem_cons_succ]
              exact hmeta_sub q' (Nat.lt_of_succ_lt_succ hq1) (Nat.lt_of_succ_lt_succ hq2)
        · change ChainListInv cp (insert h_new actHandles) pts' gt' (nodeResidual pts' mn₁.nd.o mn₁.nd.V (insert h_new S)) sub.1
          rwa [hres_ins]
        · dsimp only [foldResiduals]
          change if sub.2 = true then
            foldResiduals pts' (nodeResidual pts' mn₁.nd.o mn₁.nd.V (insert h_new S)) sub.1 = _
          else
            foldResiduals pts' (nodeResidual pts' mn₁.nd.o mn₁.nd.V (insert h_new S)) sub.1 = _
          rw [hres_ins]; exact hfold_sub
        · intro hgd_all hseeds_all x hx
          rcases List.mem_cons.mp hx with hx_eq | hx_tl
          · subst hx_eq
            have hs0 := hseeds_all 0 (Nat.zero_lt_succ _)
            simp only [Nat.add_zero, List.getElem_cons_zero] at hs0
            exact hgd₁ (hgd_all _ List.mem_cons_self) hs0
          · refine hgd_sub (fun y hy => hgd_all y (List.mem_cons_of_mem mn hy))
              (fun q' hq' => ?_) x hx_tl
            have hs_q := hseeds_all (q' + 1) (Nat.succ_lt_succ hq')
            simp only [List.getElem_cons_succ] at hs_q
            rwa [show idx + (q' + 1) = idx + 1 + q' by omega] at hs_q

/-- Master theorem for `liveUpdateChainList` on `delete h_del` (`h_del ∈ S`). -/
theorem liveUpdateChainList_delete_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hgt : GhostTrackerWF actHandles pts gt)
    {h_del : ℕ}
    (hpts_del : pts' h_del = pts h_del)
    (hpts_old : ∀ x ∈ actHandles.erase h_del, pts' x = pts x)
    (seeds : ℕ → OpSeed cp) :
    ∀ (idx : ℕ) (S : Finset ℕ) (nds : List (MNode cp)),
      S ⊆ actHandles → h_del ∈ S →
      (∀ mn ∈ nds, mn.nd.age ≤ mn.nd.birthSize) →
      ChainListInv cp actHandles pts gt S nds →
      let res := liveUpdateChainList cp pts' false h_del seeds idx nds
      res.1.length = nds.length ∧
      (∀ q (hq1 : q < nds.length) (hq2 : q < res.1.length),
        let mn₀ := nds[q]'hq1
        let mn₁ := res.1[q]'hq2
        mn₁.nd.o = mn₀.nd.o ∧ mn₁.nd.V = mn₀.nd.V ∧
        mn₁.nd.birthSize = mn₀.nd.birthSize ∧
        mn₁.nd.age ≤ mn₀.nd.age + 1) ∧
      ChainListInv cp (actHandles.erase h_del) pts' gt (S.erase h_del) res.1 ∧
      (if res.2 then
        h_del ∈ foldResiduals pts S nds ∧
        foldResiduals pts' (S.erase h_del) res.1 = (foldResiduals pts S nds).erase h_del
      else
        h_del ∉ foldResiduals pts S nds ∧
        foldResiduals pts' (S.erase h_del) res.1 = foldResiduals pts S nds) ∧
      (ChainListGood cp hh0 hh1 pts gt nds →
       (∀ q (hq : q < nds.length),
         NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
           cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q (nds[q]'hq).nd (seeds (idx + q))) →
       ChainListGood cp hh0 hh1 pts' gt res.1)
  | _, S, [], _, hh_in_S, _, _ => by
      simp [liveUpdateChainList, foldResiduals, ChainListInv, ChainListGood, hh_in_S]
  | idx, S, mn :: rest, hS_sub, hh_in_S, hage_le, ⟨hhead, htail⟩ => by
      let M_lat := M_lat_of d params.e
      rcases hhead with ⟨hcur, hbsz_n, hbsz_B, hbirth_uid, hage, hhist, htins, hwf⟩
      have hpts_S : ∀ x ∈ S, pts' x = pts x := by
        intro x hx
        by_cases heq : x = h_del
        · subst heq; exact hpts_del
        · exact hpts_old x (Finset.mem_erase.mpr ⟨heq, hS_sub hx⟩)
      have heq_cur : ∀ x ∈ mn.nd.curSet, pts' x = pts x := fun x hx => hpts_S x (hcur ▸ hx)
      rcases managedNode_pts_congr (M_lat := M_lat) (τ_q := cp.τ_q) (cap_q := cp.cap_q)
        hh0 hh1 heq_cur hwf with ⟨hwf_pts', hgd_pts'⟩
      have hp_in_cur : h_del ∈ mn.nd.curSet := hcur.symm ▸ hh_in_S
      have hcap_t : (mn.nd.birthSize + mn.nd.age) + 1 < 2 ^ cp.L_p2 := by
        have h1 := hage_le mn List.mem_cons_self
        have h2 := cp.hL_p2
        omega
      rcases managedNode_deleteMat_spec h_clm_7_3 hd cp.hM₀ cp.T_cdf cp.p_coord params he1
        cp.specs cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q hp_in_cur (seeds idx)
        htins hcap_t hwf_pts'
        with ⟨ho, hs, hV, hbS, hbsz, hage_eq, hcur', hhist', htins', hwf_del', hgd_del⟩
      let mn_mat := mn.deleteMat cp.hM₀ cp.T_cdf cp.p_coord M_lat params cp.specs
        cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_del (seeds idx)
      let mn₁ := mn_mat.bumpAge
      rcases image_erase_uidOf hgt hS_sub hh_in_S with ⟨hu_in_img, himg_era⟩
      have hage₁ : HasNodeAge mn₁.nd.birthSet ((S.erase h_del).image gt.uidOf) mn₁.nd.age := by
        dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_birthSet, bumpAge_age, hbS, hage_eq, himg_era]
        exact hasNodeAge_step hage (Or.inr ⟨gt.uidOf h_del, hu_in_img, by ext z; simp⟩)
      have hhead₁ : LiveNodeInv cp (actHandles.erase h_del) pts' gt (S.erase h_del) mn₁ := by
        refine ⟨by dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_curSet, hcur', hcur],
          by dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_birthSize, hbsz]; exact hbsz_n,
          by dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_birthSize, hbsz]; exact hbsz_B,
          by dsimp only [mn₁, mn_mat, M_lat] at *; simpa only [ bumpAge_birthSet, hbS] using hbirth_uid,
          hage₁, ?_, ?_, (bumpAge_wf _ _ _ _ _ _ _ _ _).mpr hwf_del'⟩
        · dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_histArr, bumpAge_birthSize, bumpAge_age, hhist', hbsz, hage_eq]
          omega
        · dsimp only [mn₁, mn_mat, M_lat]
          rw [bumpAge_birthSize, bumpAge_age, bumpAge_maxTIns, hbsz, hage_eq,
            show mn.nd.birthSize + (mn.nd.age + 1) = (mn.nd.birthSize + mn.nd.age) + 1 by omega]
          exact htins'
      have hgd₁ : LiveNodeGood cp hh0 hh1 pts gt mn →
          NodeOpSeedGood cp.T_cdf cp.p_coord M_lat params cp.specs cp.τ_d cp.τ_q
            hh0 hh1 cp.cap_u cp.cap_q mn.nd (seeds idx) →
          LiveNodeGood cp hh0 hh1 pts' gt mn₁ := by
        rintro ⟨hcp, hgd_m⟩ hseed₀
        refine ⟨?_, (bumpAge_matGood _ _ _ _ _ _ _ _ _ _ _ _ _).mpr (hgd_del (hgd_pts' hgd_m) hseed₀)⟩
        dsimp only [mn₁, mn_mat, M_lat] at *; simpa only [ bumpAge_birthSet, bumpAge_o, bumpAge_s, hbS, ho, hs] using hcp
      have hV_nn : 0 ≤ mn.nd.V := le_max_left _ _
      have hres_sub : nodeResidual pts mn.nd.o mn.nd.V S ⊆ actHandles := by
        intro x hx; unfold nodeResidual at hx
        rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hS_sub hx.1
      have hfold_sub_res : ∀ (T : Finset ℕ) (ls : List (MNode cp)),
          foldResiduals pts T ls ⊆ T := by
        intro T ls
        induction ls generalizing T with
        | nil => exact Finset.Subset.refl _
        | cons a as ih =>
            dsimp only [foldResiduals]
            refine (ih _).trans (fun x hx => ?_)
            unfold nodeResidual at hx
            rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hx.1
      dsimp only
      rw [liveUpdateChainList_false_cons]
      dsimp only
      by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_del) = true
      · rw [if_pos hcb]
        have hp_in_cb : pts h_del ∈ coreBall mn.nd.o mn.nd.V := by
          rw [← hpts_del]; exact (inCoreBall_eq_true_iff mn.nd.o hV_nn (pts' h_del)).mp hcb
        have hnot_res : h_del ∉ nodeResidual pts mn.nd.o mn.nd.V S := by
          classical
          unfold nodeResidual nodeCore
          rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter]
          exact fun hh => hh.2 ⟨hh_in_S, hp_in_cb⟩
        have hres_same : nodeResidual pts' mn₁.nd.o mn₁.nd.V (S.erase h_del) =
            nodeResidual pts mn.nd.o mn.nd.V S := by
          dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_o, bumpAge_V, ho, hV]
          ext x; unfold nodeResidual nodeCore
          simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter, Finset.mem_erase]
          constructor
          · rintro ⟨⟨hne, hx⟩, hnc⟩
            refine ⟨hx, fun hh => hnc ⟨⟨hne, hx⟩, ?_⟩⟩
            rw [hpts_S x hx]; exact hh.2
          · rintro ⟨hx, hnc⟩
            have hne : x ≠ h_del := fun heq => hnc ⟨hx, heq ▸ hp_in_cb⟩
            refine ⟨⟨hne, hx⟩, fun hh => hnc ⟨hx, ?_⟩⟩
            rw [← hpts_S x hx]; exact hh.2
        rcases chainListInv_unchanged_delete hh0 hh1 hpts_old
          (nodeResidual pts mn.nd.o mn.nd.V S) rest hres_sub hnot_res htail with ⟨hfold_tl, htail', hgd_tl⟩
        refine ⟨rfl, ?_, ⟨hhead₁, ?_⟩, ?_, ?_⟩
        · intro q hq1 hq2
          cases q with
          | zero =>
              dsimp only [List.getElem_cons_zero, mn₁, mn_mat]
              rw [bumpAge_o, bumpAge_V, bumpAge_birthSize, bumpAge_age, ho, hV, hbsz, hage_eq]
              exact ⟨rfl, rfl, rfl, le_rfl⟩
          | succ q' =>
              dsimp only [List.getElem_cons_succ]
              exact ⟨rfl, rfl, rfl, Nat.le_succ _⟩
        · change ChainListInv cp (actHandles.erase h_del) pts' gt (nodeResidual pts' mn₁.nd.o mn₁.nd.V (S.erase h_del)) rest
          rwa [hres_same]
        · dsimp only [foldResiduals]
          rw [if_neg Bool.false_ne_true]
          change h_del ∉ _ ∧ foldResiduals pts' (nodeResidual pts' mn₁.nd.o mn₁.nd.V (S.erase h_del)) rest = _
          rw [hres_same, hfold_tl]
          exact ⟨fun hm => hnot_res (hfold_sub_res _ rest hm), rfl⟩
        · intro hgd_all hseeds_all x hx
          rcases List.mem_cons.mp hx with hx_eq | hx_tl
          · subst hx_eq
            have hs0 := hseeds_all 0 (Nat.zero_lt_succ _)
            simp only [Nat.add_zero, List.getElem_cons_zero] at hs0
            exact hgd₁ (hgd_all _ List.mem_cons_self) hs0
          · exact hgd_tl (fun y hy => hgd_all y (List.mem_cons_of_mem mn hy)) x hx_tl
      · rw [if_neg hcb]
        dsimp only
        have hp_not_cb : pts h_del ∉ coreBall mn.nd.o mn.nd.V := by
          rw [← hpts_del]
          exact (inCoreBall_eq_false_iff mn.nd.o hV_nn (pts' h_del)).mp (Bool.eq_false_iff.mpr hcb)
        have hh_in_res : h_del ∈ nodeResidual pts mn.nd.o mn.nd.V S := by
          classical
          unfold nodeResidual nodeCore
          rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter]
          exact ⟨hh_in_S, fun hh => hp_not_cb hh.2⟩
        have hres_era : nodeResidual pts' mn₁.nd.o mn₁.nd.V (S.erase h_del) =
            (nodeResidual pts mn.nd.o mn.nd.V S).erase h_del := by
          dsimp only [mn₁, mn_mat, M_lat]; simp only [ bumpAge_o, bumpAge_V, ho, hV]
          ext x; unfold nodeResidual nodeCore
          simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter, Finset.mem_erase]
          constructor
          · rintro ⟨⟨hne, hx⟩, hnc⟩
            refine ⟨hne, hx, fun hh => hnc ⟨⟨hne, hx⟩, ?_⟩⟩
            rw [hpts_S x hx]; exact hh.2
          · rintro ⟨hne, hx, hnc⟩
            refine ⟨⟨hne, hx⟩, fun hh => hnc ⟨hx, ?_⟩⟩
            rw [← hpts_S x hx]; exact hh.2
        rcases liveUpdateChainList_delete_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt
          hpts_del hpts_old seeds (idx + 1) (nodeResidual pts mn.nd.o mn.nd.V S) rest
          hres_sub hh_in_res (fun y hy => hage_le y (List.mem_cons_of_mem mn hy)) htail
          with ⟨hlen_sub, hmeta_sub, hinv_sub, hfold_sub, hgd_sub⟩
        set sub := liveUpdateChainList cp pts' false h_del seeds (idx + 1) rest
        refine ⟨by simp [hlen_sub], ?_, ⟨hhead₁, ?_⟩, ?_, ?_⟩
        · intro q hq1 hq2
          cases q with
          | zero =>
              dsimp only [List.getElem_cons_zero, mn₁, mn_mat]
              rw [bumpAge_o, bumpAge_V, bumpAge_birthSize, bumpAge_age, ho, hV, hbsz, hage_eq]
              exact ⟨rfl, rfl, rfl, le_rfl⟩
          | succ q' =>
              simp only [List.getElem_cons_succ]
              exact hmeta_sub q' (Nat.lt_of_succ_lt_succ hq1) (Nat.lt_of_succ_lt_succ hq2)
        · change ChainListInv cp (actHandles.erase h_del) pts' gt (nodeResidual pts' mn₁.nd.o mn₁.nd.V (S.erase h_del)) sub.1
          rwa [hres_era]
        · dsimp only [foldResiduals]
          change if sub.2 = true then
            _ ∧ foldResiduals pts' (nodeResidual pts' mn₁.nd.o mn₁.nd.V (S.erase h_del)) sub.1 = _
          else
            _ ∧ foldResiduals pts' (nodeResidual pts' mn₁.nd.o mn₁.nd.V (S.erase h_del)) sub.1 = _
          rw [hres_era]; exact hfold_sub
        · intro hgd_all hseeds_all x hx
          rcases List.mem_cons.mp hx with hx_eq | hx_tl
          · subst hx_eq
            have hs0 := hseeds_all 0 (Nat.zero_lt_succ _)
            simp only [Nat.add_zero, List.getElem_cons_zero] at hs0
            exact hgd₁ (hgd_all _ List.mem_cons_self) hs0
          · refine hgd_sub (fun y hy => hgd_all y (List.mem_cons_of_mem mn hy))
              (fun q' hq' => ?_) x hx_tl
            have hs_q := hseeds_all (q' + 1) (Nat.succ_lt_succ hq')
            simp only [List.getElem_cons_succ] at hs_q
            rwa [show idx + (q' + 1) = idx + 1 + q' by omega] at hs_q


/-! ### 3. Sequential Fubini Good-Coin Composition (`fubini_good_card_ge` & `seq_good_card_ge`) -/

theorem fubini_good_card_ge {A B : Type*} [Fintype A] [Fintype B]
    (PA : A → Prop) [DecidablePred PA]
    (PAB : A → B → Prop) [∀ a, DecidablePred (PAB a)]
    {φ₁ φ₂ : ℝ} (hφ₁ : 0 ≤ φ₁) (hφ₂ : 0 ≤ φ₂)
    (hA : (1 - φ₁) * (Fintype.card A : ℝ) ≤ ((Finset.univ.filter PA).card : ℝ))
    (hB : ∀ a : A, PA a →
      (1 - φ₂) * (Fintype.card B : ℝ) ≤ ((Finset.univ.filter (PAB a)).card : ℝ)) :
    open Classical in
    (1 - (φ₁ + φ₂)) * (Fintype.card (A × B) : ℝ) ≤
      ((Finset.univ.filter (fun ab : A × B => PA ab.1 ∧ PAB ab.1 ab.2)).card : ℝ) := by
  classical
  let GoodA := (Finset.univ : Finset A).filter PA
  let GoodAB := (Finset.univ : Finset (A × B)).filter (fun ab => PA ab.1 ∧ PAB ab.1 ab.2)
  have hfiber : ∀ a ∈ GoodA,
      (1 - φ₂) * (Fintype.card B : ℝ) ≤
        (((Finset.univ : Finset B).filter (fun b => (a, b) ∈ GoodAB)).card : ℝ) := by
    intro a ha
    have hpa : PA a := (Finset.mem_filter.mp ha).2
    refine (hB a hpa).trans (Nat.cast_le.mpr (Finset.card_le_card (fun b hb => ?_)))
    have hpab : PAB a b := (Finset.mem_filter.mp hb).2
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ b, Finset.mem_filter.mpr ⟨Finset.mem_univ (a, b), hpa, hpab⟩⟩
  have hsum_le :
      (∑ a ∈ GoodA, (((Finset.univ : Finset B).filter (fun b => (a, b) ∈ GoodAB)).card : ℝ)) ≤
        (GoodAB.card : ℝ) := by
    rw [← Nat.cast_sum]
    apply Nat.cast_le.mpr
    have hsub : GoodA.biUnion (fun a =>
        ((Finset.univ : Finset B).filter (fun b => (a, b) ∈ GoodAB)).map
          ⟨fun b => (a, b), fun _ _ h => (Prod.mk.inj h).2⟩) ⊆ GoodAB := by
      intro ab hab
      rcases Finset.mem_biUnion.mp hab with ⟨a, _, hmap⟩
      rcases Finset.mem_map.mp hmap with ⟨b, hfilt, rfl⟩
      exact (Finset.mem_filter.mp hfilt).2
    calc (∑ a ∈ GoodA, ((Finset.univ.filter (fun b => (a, b) ∈ GoodAB)).card))
        = ∑ a ∈ GoodA, (((Finset.univ.filter (fun b => (a, b) ∈ GoodAB)).map
            ⟨fun b => (a, b), fun _ _ h => (Prod.mk.inj h).2⟩).card) :=
          Finset.sum_congr rfl (fun _ _ => (Finset.card_map _).symm)
      _ = (GoodA.biUnion _).card := by
          refine (Finset.card_biUnion (fun a₁ _ a₂ _ hne => ?_)).symm
          unfold Function.onFun
          rw [Finset.disjoint_left]
          intro ab h1 h2
          rcases Finset.mem_map.mp h1 with ⟨_, _, rfl⟩
          rcases Finset.mem_map.mp h2 with ⟨_, _, heq⟩
          exact hne (Prod.mk.inj heq).1.symm
      _ ≤ GoodAB.card := Finset.card_le_card hsub
  have hprod_lb : (GoodA.card : ℝ) * ((1 - φ₂) * (Fintype.card B : ℝ)) ≤ (GoodAB.card : ℝ) := by
    calc (GoodA.card : ℝ) * ((1 - φ₂) * (Fintype.card B : ℝ))
        = ∑ _a ∈ GoodA, (1 - φ₂) * (Fintype.card B : ℝ) := by rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ _ := Finset.sum_le_sum hfiber
      _ ≤ (GoodAB.card : ℝ) := hsum_le
  by_cases h12_pos : 0 ≤ 1 - φ₂
  · have hfac : 1 - (φ₁ + φ₂) ≤ (1 - φ₁) * (1 - φ₂) := by nlinarith only [hφ₁, hφ₂]
    have hcard_ab : (Fintype.card (A × B) : ℝ) = (Fintype.card A : ℝ) * (Fintype.card B : ℝ) := by
      rw [Fintype.card_prod, Nat.cast_mul]
    change (1 - (φ₁ + φ₂)) * (Fintype.card (A × B) : ℝ) ≤ (GoodAB.card : ℝ)
    rw [hcard_ab]
    calc (1 - (φ₁ + φ₂)) * ((Fintype.card A : ℝ) * (Fintype.card B : ℝ))
        ≤ ((1 - φ₁) * (Fintype.card A : ℝ)) * ((1 - φ₂) * (Fintype.card B : ℝ)) := by
          have hnn : 0 ≤ (Fintype.card A : ℝ) * (Fintype.card B : ℝ) := by positivity
          have := mul_le_mul_of_nonneg_right hfac hnn
          linarith only [this]
      _ ≤ (GoodA.card : ℝ) * ((1 - φ₂) * (Fintype.card B : ℝ)) :=
          mul_le_mul_of_nonneg_right hA (mul_nonneg h12_pos (Nat.cast_nonneg _))
      _ ≤ (GoodAB.card : ℝ) := hprod_lb
  · have hneg : 1 - (φ₁ + φ₂) ≤ 0 := by linarith only [h12_pos, hφ₁]
    exact (mul_nonpos_of_nonpos_of_nonneg hneg (Nat.cast_nonneg _)).trans (Nat.cast_nonneg _)

/-- Sequential multi-step good-event predicate along `m` state transitions `step : St → Ω → St`. -/
def SeqGood {St Ω : Type*} (step : St → Ω → St) (Good : St → Ω → Prop) :
    (m : ℕ) → St → (Fin m → Ω) → Prop
  | 0, _, _ => True
  | m + 1, st, ωs =>
      Good st (ωs 0) ∧ SeqGood step Good m (step st (ωs 0)) (fun i => ωs i.succ)

theorem seq_good_card_ge {St Ω : Type*} [Fintype Ω]
    (step : St → Ω → St) (Good : St → Ω → Prop)
    {φ : ℝ} (hφ0 : 0 ≤ φ)
    (hone : ∀ st : St, open Classical in
      (1 - φ) * (Fintype.card Ω : ℝ) ≤ ((Finset.univ.filter (Good st)).card : ℝ)) :
    ∀ (m : ℕ) (st₀ : St),
      open Classical in
      (1 - (m : ℝ) * φ) * (Fintype.card (Fin m → Ω) : ℝ) ≤
        ((Finset.univ.filter (SeqGood step Good m st₀)).card : ℝ)
  | 0, st₀ => by
      classical
      have hall : (Finset.univ : Finset (Fin 0 → Ω)).filter (SeqGood step Good 0 st₀) = Finset.univ :=
        Finset.filter_true_of_mem (fun _ _ => trivial)
      change _ ≤ (((Finset.univ : Finset (Fin 0 → Ω)).filter (SeqGood step Good 0 st₀)).card : ℝ)
      rw [hall, Finset.card_univ, Nat.cast_zero, zero_mul, sub_zero, one_mul]
  | m + 1, st₀ => by
      classical
      let e : (Ω × (Fin m → Ω)) ≃ (Fin (m + 1) → Ω) :=
        { toFun := fun p => Fin.cons p.1 p.2
          invFun := fun f => (f 0, fun i => f i.succ)
          left_inv := fun ⟨a, g⟩ => by ext <;> simp
          right_inv := fun f => by ext j; refine Fin.cases ?_ (fun i => ?_) j <;> simp }
      have hfub := fubini_good_card_ge (Good st₀)
        (fun ω₀ tail => SeqGood step Good m (step st₀ ω₀) tail)
        hφ0 (mul_nonneg (Nat.cast_nonneg m) hφ0)
        (hone st₀) (fun ω₀ _ => seq_good_card_ge step Good hφ0 hone m (step st₀ ω₀))
      have hcard_eq : (Fintype.card (Ω × (Fin m → Ω)) : ℝ) = (Fintype.card (Fin (m + 1) → Ω) : ℝ) := by
        exact_mod_cast Fintype.card_congr e
      have hlin : 1 - ((m + 1 : ℕ) : ℝ) * φ = 1 - (φ + (m : ℝ) * φ) := by push_cast; ring
      change (1 - ((m + 1 : ℕ) : ℝ) * φ) * (Fintype.card (Fin (m + 1) → Ω) : ℝ) ≤ _
      rw [hlin, ← hcard_eq]
      refine hfub.trans ?_
      apply Nat.cast_le.mpr
      rw [← Finset.card_map e.toEmbedding]
      refine Finset.card_le_card (fun f hf => ?_)
      rcases Finset.mem_map.mp hf with ⟨⟨ω₀, tl⟩, hmem, rfl⟩
      have hboth := (Finset.mem_filter.mp hmem).2
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
      dsimp only [e, Equiv.toEmbedding_apply, SeqGood]
      exact hboth

/-! ### 4. Two-Phase `CopyState` & `BuildState` Streaming Primitives -/

structure CopyState where
  L_hist : ℕ
  copyCur : ℕ
  snapArr : List ℕ

def CopyState.init (L_hist : ℕ) : CopyState :=
  { L_hist := L_hist, copyCur := 0, snapArr := [] }

def CopyState.liveInsert (p : ℕ) (cs : CopyState) : CopyState :=
  { cs with snapArr := if cs.snapArr.contains p then cs.snapArr else denseInsert p cs.snapArr }

def CopyState.liveDelete (p : ℕ) (cs : CopyState) : CopyState :=
  { cs with snapArr := denseDelete p cs.snapArr }

def advanceCopyLoop (srcHist targetArr : List ℕ) : ℕ → CopyState → CopyState
  | 0, cs => cs
  | rem + 1, cs =>
      if hlt : cs.copyCur < srcHist.length then
        let x := srcHist[cs.copyCur]'hlt
        let snap' :=
          if targetArr.contains x && !cs.snapArr.contains x then
            denseInsert x cs.snapArr
          else
            cs.snapArr
        advanceCopyLoop srcHist targetArr rem { cs with copyCur := cs.copyCur + 1, snapArr := snap' }
      else
        cs

def CopyStateInv (srcHist : List ℕ) (targetSet : Finset ℕ) (cs : CopyState) : Prop :=
  cs.copyCur ≤ cs.L_hist ∧
  cs.L_hist ≤ srcHist.length ∧
  cs.snapArr.Nodup ∧
  cs.snapArr.toFinset ⊆ targetSet ∧
  (∀ x ∈ targetSet, x ∈ cs.snapArr.toFinset ∨
    ∃ j, cs.copyCur ≤ j ∧ j < cs.L_hist ∧ ∃ hj : j < srcHist.length, srcHist[j]'hj = x)

theorem copyState_init_spec {srcHist : List ℕ} {targetSet : Finset ℕ}
    (hsub : targetSet ⊆ srcHist.toFinset) :
    CopyStateInv srcHist targetSet (CopyState.init srcHist.length) := by
  refine ⟨Nat.zero_le _, le_rfl, List.nodup_nil, Finset.empty_subset _, fun x hx => Or.inr ?_⟩
  have hmem : x ∈ srcHist := List.mem_toFinset.mp (hsub hx)
  rcases List.mem_iff_getElem.mp hmem with ⟨j, hj, rfl⟩
  exact ⟨j, Nat.zero_le j, hj, hj, rfl⟩

theorem copyState_liveInsert_spec {srcHist : List ℕ} {targetSet : Finset ℕ} {cs : CopyState}
    (p : ℕ) (extraHist : List ℕ)
    (hinv : CopyStateInv srcHist targetSet cs) :
    let cs' := cs.liveInsert p
    cs'.L_hist = cs.L_hist ∧ cs'.copyCur = cs.copyCur ∧
    CopyStateInv (srcHist ++ extraHist) (insert p targetSet) cs' := by
  rcases hinv with ⟨hcur, hL, hnd, hsub, hcomp⟩
  refine ⟨rfl, rfl, hcur, hL.trans (by simp), ?_, ?_, ?_⟩
  · dsimp only [CopyState.liveInsert]
    by_cases hc : cs.snapArr.contains p = true
    · rw [if_pos hc]; exact hnd
    · rw [if_neg hc]
      have hnot : p ∉ cs.snapArr.toFinset := fun hm =>
        hc (List.contains_iff_mem.mpr (List.mem_toFinset.mp hm))
      exact (denseInsert_spec hnd hnot).1
  · dsimp only [CopyState.liveInsert]
    by_cases hc : cs.snapArr.contains p = true
    · rw [if_pos hc]; exact hsub.trans (Finset.subset_insert p targetSet)
    · rw [if_neg hc]
      have hnot : p ∉ cs.snapArr.toFinset := fun hm =>
        hc (List.contains_iff_mem.mpr (List.mem_toFinset.mp hm))
      rw [(denseInsert_spec hnd hnot).2]
      exact Finset.insert_subset_insert p hsub
  · intro x hx
    have hp_in_snap' : p ∈ (cs.liveInsert p).snapArr.toFinset := by
      dsimp only [CopyState.liveInsert]
      by_cases hc : cs.snapArr.contains p = true
      · rw [if_pos hc]; exact List.mem_toFinset.mpr (List.contains_iff_mem.mp hc)
      · rw [if_neg hc]
        have hnot : p ∉ cs.snapArr.toFinset := fun hm =>
          hc (List.contains_iff_mem.mpr (List.mem_toFinset.mp hm))
        rw [(denseInsert_spec hnd hnot).2]
        exact Finset.mem_insert_self _ _
    have hsnap_mono : cs.snapArr.toFinset ⊆ (cs.liveInsert p).snapArr.toFinset := by
      dsimp only [CopyState.liveInsert]
      by_cases hc : cs.snapArr.contains p = true
      · rw [if_pos hc]
      · rw [if_neg hc]
        have hnot : p ∉ cs.snapArr.toFinset := fun hm =>
          hc (List.contains_iff_mem.mpr (List.mem_toFinset.mp hm))
        rw [(denseInsert_spec hnd hnot).2]
        exact Finset.subset_insert _ _
    rcases Finset.mem_insert.mp hx with rfl | hx_old
    · exact Or.inl hp_in_snap'
    · rcases hcomp x hx_old with hx_s | ⟨j, hj1, hj2, hj_lt, hj_eq⟩
      · exact Or.inl (hsnap_mono hx_s)
      · refine Or.inr ⟨j, hj1, hj2, hj_lt.trans_le (by simp), ?_⟩
        rw [List.getElem_append_left hj_lt]
        exact hj_eq

theorem copyState_liveDelete_spec {srcHist : List ℕ} {targetSet : Finset ℕ} {cs : CopyState}
    (p : ℕ) (hinv : CopyStateInv srcHist targetSet cs) :
    let cs' := cs.liveDelete p
    cs'.L_hist = cs.L_hist ∧ cs'.copyCur = cs.copyCur ∧
    CopyStateInv srcHist (targetSet.erase p) cs' := by
  rcases hinv with ⟨hcur, hL, hnd, hsub, hcomp⟩
  rcases denseDelete_spec (h := p) hnd with ⟨hnd', hera⟩
  refine ⟨rfl, rfl, hcur, hL, hnd', ?_, ?_⟩
  · dsimp only [CopyState.liveDelete]; rw [hera]
    exact Finset.erase_subset_erase p hsub
  · intro x hx
    rcases Finset.mem_erase.mp hx with ⟨hne, hx_old⟩
    dsimp only [CopyState.liveDelete]
    rcases hcomp x hx_old with hx_s | ⟨j, hj1, hj2, hj_lt, hj_eq⟩
    · rw [hera]; exact Or.inl (Finset.mem_erase.mpr ⟨hne, hx_s⟩)
    · exact Or.inr ⟨j, hj1, hj2, hj_lt, hj_eq⟩

theorem advanceCopyLoop_spec {srcHist targetArr : List ℕ} {targetSet : Finset ℕ}
    (htarget : targetArr.toFinset = targetSet) :
    ∀ (steps : ℕ) {cs : CopyState},
      cs.copyCur + steps ≤ cs.L_hist →
      CopyStateInv srcHist targetSet cs →
      let cs' := advanceCopyLoop srcHist targetArr steps cs
      cs'.L_hist = cs.L_hist ∧
      cs'.copyCur = cs.copyCur + steps ∧
      CopyStateInv srcHist targetSet cs' ∧
      (cs'.copyCur = cs'.L_hist → cs'.snapArr.toFinset = targetSet)
  | 0, cs, _, hinv => by
      dsimp only [advanceCopyLoop]
      refine ⟨rfl, (Nat.add_zero _).symm, hinv, fun hdone => ?_⟩
      apply Finset.Subset.antisymm hinv.2.2.2.1
      intro x hx
      rcases hinv.2.2.2.2 x hx with hx_s | ⟨j, hj1, hj2, _⟩
      · exact hx_s
      · omega
  | steps + 1, cs, hbnd, ⟨hcur, hL, hnd, hsub, hcomp⟩ => by
      have hlt_src : cs.copyCur < srcHist.length := by omega
      dsimp only [advanceCopyLoop]
      rw [dif_pos hlt_src]
      set x₀ := srcHist[cs.copyCur]'hlt_src
      set snap' := if targetArr.contains x₀ && !cs.snapArr.contains x₀ then
        denseInsert x₀ cs.snapArr else cs.snapArr
      have hnot_of_cond : (targetArr.contains x₀ && !cs.snapArr.contains x₀) = true →
          x₀ ∈ targetSet ∧ x₀ ∉ cs.snapArr.toFinset := by
        intro hc
        rcases Bool.and_eq_true_iff.mp hc with ⟨htc, hnc⟩
        have hx_t : x₀ ∈ targetSet :=
          htarget ▸ List.mem_toFinset.mpr (List.contains_iff_mem.mp htc)
        have hx_ns : x₀ ∉ cs.snapArr.toFinset := by
          intro hm
          have hcs_true : cs.snapArr.contains x₀ = true :=
            List.contains_iff_mem.mpr (List.mem_toFinset.mp hm)
          rw [hcs_true] at hnc
          cases hnc
        exact ⟨hx_t, hx_ns⟩
      let cs₁ : CopyState := { cs with copyCur := cs.copyCur + 1, snapArr := snap' }
      have hcs₁_cur : cs₁.copyCur = cs.copyCur + 1 := rfl
      have hcs₁_L : cs₁.L_hist = cs.L_hist := rfl
      have hinv₁ : CopyStateInv srcHist targetSet cs₁ := by
        refine ⟨by rw [hcs₁_cur, hcs₁_L]; omega, by rw [hcs₁_L]; exact hL, ?_, ?_, ?_⟩
        · dsimp only [cs₁, snap']
          by_cases hc : (targetArr.contains x₀ && !cs.snapArr.contains x₀) = true
          · rw [if_pos hc]; exact (denseInsert_spec hnd (hnot_of_cond hc).2).1
          · rw [if_neg hc]; exact hnd
        · dsimp only [cs₁, snap']
          by_cases hc : (targetArr.contains x₀ && !cs.snapArr.contains x₀) = true
          · rw [if_pos hc]
            rcases hnot_of_cond hc with ⟨hx_t, hx_ns⟩
            rw [(denseInsert_spec hnd hx_ns).2]
            exact Finset.insert_subset_iff.mpr ⟨hx_t, hsub⟩
          · rw [if_neg hc]; exact hsub
        · intro y hy
          have hmono : cs.snapArr.toFinset ⊆ cs₁.snapArr.toFinset := by
            dsimp only [cs₁, snap']
            by_cases hc : (targetArr.contains x₀ && !cs.snapArr.contains x₀) = true
            · rw [if_pos hc]
              rw [(denseInsert_spec hnd (hnot_of_cond hc).2).2]
              exact Finset.subset_insert _ _
            · rw [if_neg hc]
          rcases hcomp y hy with hy_s | ⟨j, hj1, hj2, hj_lt, hj_eq⟩
          · exact Or.inl (hmono hy_s)
          · by_cases hj_cur : j = cs.copyCur
            · subst hj_cur
              have hy_x₀ : y = x₀ := hj_eq.symm
              subst hy_x₀
              apply Or.inl
              dsimp only [cs₁, snap']
              have htc : targetArr.contains x₀ = true :=
                List.contains_iff_mem.mpr (List.mem_toFinset.mp (htarget.symm ▸ hy))
              by_cases hc : (targetArr.contains x₀ && !cs.snapArr.contains x₀) = true
              · rw [if_pos hc, (denseInsert_spec hnd (hnot_of_cond hc).2).2]
                exact Finset.mem_insert_self _ _
              · rw [if_neg hc]
                have hsc : cs.snapArr.contains x₀ = true := by
                  cases h_b : cs.snapArr.contains x₀
                  · exfalso; apply hc; rw [htc, h_b]; rfl
                  · rfl
                exact List.mem_toFinset.mpr (List.contains_iff_mem.mp hsc)
            · rw [hcs₁_cur, hcs₁_L]
              exact Or.inr ⟨j, by omega, hj2, hj_lt, hj_eq⟩
      rcases advanceCopyLoop_spec htarget steps (by rw [hcs₁_cur, hcs₁_L]; omega) hinv₁
        with ⟨hL', hcur', hinv', hdone'⟩
      rw [hcs₁_L] at hL'
      rw [hcs₁_cur] at hcur'
      exact ⟨hL', hcur'.trans (by omega), hinv', hdone'⟩

/-- Phase 1 (`BuildState`): streaming insertion from frozen `snapArr` with `delSnapArr` skip filter. -/
structure BuildState {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) where
  L_hist : ℕ
  snapArr : List ℕ
  delSnapArr : List ℕ
  insCur : ℕ
  curNode : MNode cp

def BuildState.remSnap {d : ℕ} {params : LocalScaleParams} {h : ℝ} {cp : ChainParams d params h}
    (bs : BuildState cp) : Finset ℕ :=
  (bs.snapArr.drop bs.insCur).toFinset \ bs.delSnapArr.toFinset

noncomputable def BuildState.init {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (L_hist : ℕ) (snapArr : List ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (P₀_uid : Finset ℕ) : BuildState cp :=
  { L_hist := L_hist
    snapArr := snapArr
    delSnapArr := []
    insCur := 0
    curNode := ManagedNode.openEmpty cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b cp.N_cfg
      cp.T_cdf cp.p_coord o s P₀_uid snapArr.length }

noncomputable def BuildState.liveInsert {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (p : ℕ) (ω : OpSeed cp) (bs : BuildState cp) : BuildState cp :=
  { bs with
    curNode := (bs.curNode.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e)
      params cp.specs cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' p ω).bumpAge }

noncomputable def BuildState.liveDelete {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (p : ℕ) (ω : OpSeed cp) (bs : BuildState cp) : BuildState cp :=
  if bs.curNode.nd.denseArr.contains p then
    { bs with
      curNode := (bs.curNode.deleteMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e)
        params cp.specs cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' p ω).bumpAge }
  else
    { bs with
      delSnapArr := denseInsert p bs.delSnapArr
      curNode := bs.curNode.bumpAge }

noncomputable def advanceBuildStep {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (bs : BuildState cp) (ω : OpSeed cp) : BuildState cp :=
  if hlt : bs.insCur < bs.snapArr.length then
    let x := bs.snapArr[bs.insCur]'hlt
    let cur' :=
      if bs.delSnapArr.contains x then
        bs.curNode
      else
        bs.curNode.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e)
          params cp.specs cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts x ω
    { bs with insCur := bs.insCur + 1, curNode := cur' }
  else
    bs

noncomputable def advanceBuildLoop {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts : ℕ → EuclideanSpace ℝ (Fin d)) :
    (steps : ℕ) → (Fin steps → OpSeed cp) → BuildState cp → BuildState cp
  | 0, _, bs => bs
  | steps + 1, ωs, bs =>
      advanceBuildLoop cp pts steps (fun i => ωs i.succ) (advanceBuildStep cp pts bs (ωs 0))

def BuildStateInv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (gt : GhostTracker d)
    (targetSet : Finset ℕ) (bs : BuildState cp) : Prop :=
  bs.snapArr.Nodup ∧
  bs.delSnapArr.Nodup ∧
  bs.insCur ≤ bs.snapArr.length ∧
  bs.curNode.nd.birthSize = bs.snapArr.length ∧
  bs.curNode.nd.birthSize ≤ cp.n ∧
  cp.B_scan < bs.curNode.nd.birthSize ∧
  (∀ u ∈ bs.curNode.nd.birthSet, u < gt.nextUid) ∧
  Disjoint bs.curNode.nd.curSet bs.remSnap ∧
  bs.curNode.nd.curSet ∪ bs.remSnap = targetSet ∧
  HasNodeAge bs.curNode.nd.birthSet (targetSet.image gt.uidOf) bs.curNode.nd.age ∧
  bs.curNode.histArr.length ≤ bs.insCur + bs.curNode.nd.age ∧
  bs.curNode.nd.maxTIns (bs.insCur + bs.curNode.nd.age) ∧
  ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts bs.curNode

theorem buildState_init_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles targetSet : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hgt : GhostTrackerWF actHandles pts gt)
    (htgt_act : targetSet ⊆ actHandles) (htgt_n : targetSet.card ≤ cp.n)
    (L_hist : ℕ) {snapArr : List ℕ} (hnd : snapArr.Nodup)
    (hsnap_eq : snapArr.toFinset = targetSet) (hgt_B : cp.B_scan < snapArr.length)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    let P₀_uid := targetSet.image gt.uidOf
    let bs := BuildState.init cp L_hist snapArr o s P₀_uid
    BuildStateInv cp pts gt targetSet bs ∧
    NodeInstMatGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
      cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q pts bs.curNode.nd := by
  let P₀_uid := targetSet.image gt.uidOf
  have hlen_card : snapArr.length = P₀_uid.card := by
    rw [card_image_uidOf hgt htgt_act, ← hsnap_eq, List.toFinset_card_of_nodup hnd]
  have hlen_n : snapArr.length ≤ cp.n := by
    rw [← List.toFinset_card_of_nodup hnd, hsnap_eq]; exact htgt_n
  rcases managedNode_openEmpty_spec cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e)
    params cp.specs cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q pts o s P₀_uid
    with ⟨hcur0, hhist0, _, ht0, hwf0, hgd0⟩
  have hbs_eq : BuildState.init cp L_hist snapArr o s P₀_uid =
      { L_hist := L_hist, snapArr := snapArr, delSnapArr := [], insCur := 0,
        curNode := ManagedNode.openEmpty cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b cp.N_cfg
          cp.T_cdf cp.p_coord o s P₀_uid P₀_uid.card } := by
    unfold BuildState.init; rw [hlen_card]
  dsimp only
  rw [hbs_eq]
  have hrem_eq : (BuildState.mk L_hist snapArr [] 0
      (ManagedNode.openEmpty cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b cp.N_cfg
        cp.T_cdf cp.p_coord o s P₀_uid P₀_uid.card)).remSnap = targetSet := by
    unfold BuildState.remSnap; dsimp only [List.drop_zero]
    rw [hsnap_eq]; simp
  refine ⟨⟨hnd, List.nodup_nil, Nat.zero_le _, hlen_card.symm, hlen_card ▸ hlen_n,
    hlen_card ▸ hgt_B, ?_, ?_, ?_, ?_, ?_, ?_, hwf0⟩, hgd0⟩
  · intro u hu
    dsimp [ManagedNode.openEmpty, NodeInst.openEmpty] at hu
    rcases Finset.mem_image.mp hu with ⟨x, hx, rfl⟩
    exact hgt.1 x (htgt_act hx)
  · dsimp only; rw [hcur0]; exact Finset.disjoint_empty_left _
  · dsimp only; rw [hcur0, hrem_eq, Finset.empty_union]
  · dsimp [ManagedNode.openEmpty, NodeInst.openEmpty]
    exact hasNodeAge_zero P₀_uid
  · dsimp only; rw [hhist0]; simp
  · dsimp only; simpa using ht0

theorem advanceBuildStep_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    {targetSet : Finset ℕ} {bs : BuildState cp}
    (hlt : bs.insCur < bs.snapArr.length)
    (hage_le : bs.curNode.nd.age ≤ bs.curNode.nd.birthSize)
    (hinv : BuildStateInv cp pts gt targetSet bs)
    (ω : OpSeed cp) :
    let bs' := advanceBuildStep cp pts bs ω
    bs'.L_hist = bs.L_hist ∧
    bs'.snapArr = bs.snapArr ∧
    bs'.insCur = bs.insCur + 1 ∧
    bs'.curNode.nd.o = bs.curNode.nd.o ∧
    bs'.curNode.nd.s = bs.curNode.nd.s ∧
    bs'.curNode.nd.V = bs.curNode.nd.V ∧
    bs'.curNode.nd.birthSet = bs.curNode.nd.birthSet ∧
    bs'.curNode.nd.birthSize = bs.curNode.nd.birthSize ∧
    bs'.curNode.nd.age = bs.curNode.nd.age ∧
    BuildStateInv cp pts gt targetSet bs' ∧
    (LiveNodeGood cp hh0 hh1 pts gt bs.curNode →
     NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
       cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q bs.curNode.nd ω →
     LiveNodeGood cp hh0 hh1 pts gt bs'.curNode) := by
  rcases hinv with ⟨hnd_s, hnd_d, _, hbsz_eq, hbsz_n, hbsz_B, hbirth_u,
    hdisj, hunion, hage, hhist, htins, hwf⟩
  unfold advanceBuildStep
  rw [dif_pos hlt]
  dsimp only
  set x := bs.snapArr[bs.insCur]'hlt
  have hdrop_split : bs.snapArr.drop bs.insCur = x :: bs.snapArr.drop (bs.insCur + 1) :=
    List.drop_eq_getElem_cons hlt
  have hx_not_drop1 : x ∉ (bs.snapArr.drop (bs.insCur + 1)).toFinset := by
    intro hm
    have hnd_drop : (bs.snapArr.drop bs.insCur).Nodup := hnd_s.sublist (List.drop_sublist _ _)
    rw [hdrop_split] at hnd_drop
    exact (List.nodup_cons.mp hnd_drop).1 (List.mem_toFinset.mp hm)
  by_cases hdel_c : bs.delSnapArr.contains x = true
  · rw [if_pos hdel_c]
    have hx_in_del : x ∈ bs.delSnapArr.toFinset :=
      List.mem_toFinset.mpr (List.contains_iff_mem.mp hdel_c)
    have hrem_same : (BuildState.mk bs.L_hist bs.snapArr bs.delSnapArr (bs.insCur + 1) bs.curNode).remSnap =
        bs.remSnap := by
      unfold BuildState.remSnap; dsimp only
      rw [hdrop_split, List.toFinset_cons]
      ext z; simp only [Finset.mem_sdiff, Finset.mem_insert]
      constructor
      · rintro ⟨hz, hndel⟩; exact ⟨Or.inr hz, hndel⟩
      · rintro ⟨rfl | hz, hndel⟩
        · exact absurd hx_in_del hndel
        · exact ⟨hz, hndel⟩
    refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl,
      ⟨hnd_s, hnd_d, show bs.insCur + 1 ≤ bs.snapArr.length by omega, hbsz_eq, hbsz_n, hbsz_B, hbirth_u,
        by dsimp only; rwa [hrem_same],
        by dsimp only; rwa [hrem_same],
        hage, by dsimp only; omega, ?_, hwf⟩,
      fun hgd _ => hgd⟩
    dsimp only
    intro hV i
    rcases htins hV i with ⟨htL, htR⟩
    exact ⟨htL.trans (by omega), htR.trans (by omega)⟩
  · rw [if_neg hdel_c]
    have hx_not_del : x ∉ bs.delSnapArr.toFinset := fun hm =>
      hdel_c (List.contains_iff_mem.mpr (List.mem_toFinset.mp hm))
    have hx_in_rem : x ∈ bs.remSnap := by
      unfold BuildState.remSnap
      rw [hdrop_split, List.toFinset_cons]
      exact Finset.mem_sdiff.mpr ⟨Finset.mem_insert_self _ _, hx_not_del⟩
    have hx_not_cur : x ∉ bs.curNode.nd.curSet :=
      Finset.disjoint_right.mp hdisj hx_in_rem
    have hcap_t : (bs.curNode.nd.birthSize + bs.curNode.nd.age) + 1 < 2 ^ cp.L_p2 := by
      have := cp.hL_p2; omega
    have htins_le : bs.curNode.nd.maxTIns (bs.insCur + bs.curNode.nd.age) := htins
    have hcap_ins : (bs.insCur + bs.curNode.nd.age) + 1 < 2 ^ cp.L_p2 := by omega
    rcases managedNode_insertMat_spec h_clm_7_3 hd cp.hM₀ cp.T_cdf cp.p_coord params he1
      cp.specs cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q hx_not_cur ω htins_le hcap_ins hwf
      with ⟨ho, hs, hV, hbS, hbsz, hage_eq, hcur', hhist', htins', hwf', hgd_imp⟩
    set cur' := bs.curNode.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e)
      params cp.specs cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts x ω
    have hrem_era : (BuildState.mk bs.L_hist bs.snapArr bs.delSnapArr (bs.insCur + 1) cur').remSnap =
        bs.remSnap.erase x := by
      unfold BuildState.remSnap; dsimp only
      rw [hdrop_split, List.toFinset_cons]
      ext z; simp only [Finset.mem_sdiff, Finset.mem_erase, Finset.mem_insert]
      constructor
      · rintro ⟨hz, hndel⟩
        exact ⟨fun heq => hx_not_drop1 (heq ▸ hz), Or.inr hz, hndel⟩
      · rintro ⟨hne, rfl | hz, hndel⟩
        · exact absurd rfl hne
        · exact ⟨hz, hndel⟩
    refine ⟨rfl, rfl, rfl, ho, hs, hV, hbS, hbsz, hage_eq,
      ⟨hnd_s, hnd_d, show bs.insCur + 1 ≤ bs.snapArr.length by omega, hbsz.trans hbsz_eq, hbsz.symm ▸ hbsz_n, hbsz.symm ▸ hbsz_B,
        hbS.symm ▸ hbirth_u, ?_, ?_, ?_, ?_, ?_, hwf'⟩,
      fun ⟨hcp, hgd_m⟩ hseed => ⟨by simpa only [hbS, ho, hs] using hcp, hgd_imp hgd_m hseed⟩⟩
    · dsimp only; rw [hcur', hrem_era]
      rw [Finset.disjoint_left]
      intro z hz hzr
      rcases Finset.mem_erase.mp hzr with ⟨hne_z, hzr_old⟩
      rcases Finset.mem_insert.mp hz with rfl | hz_old
      · exact hne_z rfl
      · exact Finset.disjoint_left.mp hdisj hz_old hzr_old
    · dsimp only; rw [hcur', hrem_era, ← hunion]
      ext z; simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_erase]
      constructor
      · rintro ((rfl | hz) | ⟨_, hzr⟩)
        · exact Or.inr hx_in_rem
        · exact Or.inl hz
        · exact Or.inr hzr
      · rintro (hz | hzr)
        · exact Or.inl (Or.inr hz)
        · by_cases hzx : z = x
          · exact Or.inl (Or.inl hzx)
          · exact Or.inr ⟨hzx, hzr⟩
    · dsimp only; rwa [hbS, hage_eq]
    · dsimp only; rw [hhist', List.length_append, List.length_singleton]; omega
    · dsimp only
      rw [show bs.insCur + 1 + cur'.nd.age = (bs.insCur + bs.curNode.nd.age) + 1 by rw [hage_eq]; omega]
      exact htins'


theorem advanceBuildLoop_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    {targetSet : Finset ℕ} :
    ∀ (steps : ℕ) (ωs : Fin steps → OpSeed cp) {bs : BuildState cp},
      bs.insCur + steps ≤ bs.snapArr.length →
      bs.curNode.nd.age ≤ bs.curNode.nd.birthSize →
      BuildStateInv cp pts gt targetSet bs →
      let bs' := advanceBuildLoop cp pts steps ωs bs
      bs'.L_hist = bs.L_hist ∧
      bs'.snapArr = bs.snapArr ∧
      bs'.insCur = bs.insCur + steps ∧
      bs'.curNode.nd.o = bs.curNode.nd.o ∧
      bs'.curNode.nd.s = bs.curNode.nd.s ∧
      bs'.curNode.nd.V = bs.curNode.nd.V ∧
      bs'.curNode.nd.birthSet = bs.curNode.nd.birthSet ∧
      bs'.curNode.nd.birthSize = bs.curNode.nd.birthSize ∧
      bs'.curNode.nd.age = bs.curNode.nd.age ∧
      BuildStateInv cp pts gt targetSet bs' ∧
      (bs'.insCur = bs'.snapArr.length → bs'.curNode.nd.curSet = targetSet) ∧
      (LiveNodeGood cp hh0 hh1 pts gt bs.curNode →
       SeqGood (advanceBuildStep cp pts)
         (fun st ω => NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
           cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st.curNode.nd ω)
         steps bs ωs →
       LiveNodeGood cp hh0 hh1 pts gt bs'.curNode)
  | 0, _, bs, _, _, hinv => by
      dsimp only [advanceBuildLoop]
      refine ⟨rfl, rfl, (Nat.add_zero _).symm, rfl, rfl, rfl, rfl, rfl, rfl, hinv,
        fun hdone => ?_, fun hgd _ => hgd⟩
      have hrem_emp : bs.remSnap = ∅ := by
        unfold BuildState.remSnap
        rw [hdone, List.drop_length]
        simp
      have hun := hinv.2.2.2.2.2.2.2.2.1
      rwa [hrem_emp, Finset.union_empty] at hun
  | steps + 1, ωs, bs, hbnd, hage_le, hinv => by
      have hlt : bs.insCur < bs.snapArr.length := by omega
      rcases advanceBuildStep_spec h_clm_7_3 hd he1 cp hh0 hh1 hlt hage_le hinv (ωs 0)
        with ⟨hL₁, hs₁, hi₁, ho₁, hht₁, hV₁, hbS₁, hbsz₁, hage₁, hinv₁, hgd₁⟩
      let bs₁ := advanceBuildStep cp pts bs (ωs 0)
      rcases advanceBuildLoop_spec h_clm_7_3 hd he1 cp hh0 hh1 steps (fun i => ωs i.succ)
        (bs := bs₁) (by rw [hi₁, hs₁]; omega) (by rw [hage₁, hbsz₁]; exact hage_le) hinv₁
        with ⟨hL₂, hs₂, hi₂, ho₂, hht₂, hV₂, hbS₂, hbsz₂, hage₂, hinv₂, hdone₂, hgd₂⟩
      dsimp only [advanceBuildLoop]
      refine ⟨hL₂.trans hL₁, hs₂.trans hs₁, by rw [hi₂, hi₁]; omega,
        ho₂.trans ho₁, hht₂.trans hht₁, hV₂.trans hV₁, hbS₂.trans hbS₁, hbsz₂.trans hbsz₁,
        hage₂.trans hage₁, hinv₂, hdone₂, fun hgd ⟨hs0, hseq_tl⟩ => hgd₂ (hgd₁ hgd hs0) hseq_tl⟩

theorem buildState_liveInsert_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles targetSet : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hgt : GhostTrackerWF actHandles pts gt)
    (htgt_sub : targetSet ⊆ actHandles)
    {h_new : ℕ} (hnot_act : h_new ∉ actHandles) (pt : EuclideanSpace ℝ (Fin d))
    (hpts_old : ∀ x ∈ actHandles, pts' x = pts x)
    {bs : BuildState cp}
    (hage_le : bs.curNode.nd.age ≤ bs.curNode.nd.birthSize)
    (hinv : BuildStateInv cp pts gt targetSet bs)
    (ω : OpSeed cp) :
    let gt' := gt.stepInsert h_new pt
    let bs' := bs.liveInsert cp pts' h_new ω
    bs'.L_hist = bs.L_hist ∧ bs'.snapArr = bs.snapArr ∧ bs'.insCur = bs.insCur ∧
    bs'.curNode.nd.birthSize = bs.curNode.nd.birthSize ∧
    bs'.curNode.nd.age = bs.curNode.nd.age + 1 ∧
    BuildStateInv cp pts' gt' (insert h_new targetSet) bs' ∧
    (LiveNodeGood cp hh0 hh1 pts gt bs.curNode →
     NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
       cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q bs.curNode.nd ω →
     LiveNodeGood cp hh0 hh1 pts' gt' bs'.curNode) := by
  rcases hinv with ⟨hnd_s, hnd_d, hins_le, hbsz_eq, hbsz_n, hbsz_B, hbirth_u,
    hdisj, hunion, hage, hhist, htins, hwf⟩
  have hcur_sub_tgt : bs.curNode.nd.curSet ⊆ targetSet := hunion ▸ Finset.subset_union_left
  have heq_cur : ∀ x ∈ bs.curNode.nd.curSet, pts' x = pts x :=
    fun x hx => hpts_old x (htgt_sub (hcur_sub_tgt hx))
  rcases managedNode_pts_congr (M_lat := M_lat_of d params.e) (τ_q := cp.τ_q) (cap_q := cp.cap_q)
    hh0 hh1 heq_cur hwf with ⟨hwf_pts', hgd_pts'⟩
  have hp_not_tgt : h_new ∉ targetSet := fun hm => hnot_act (htgt_sub hm)
  have hp_not_cur : h_new ∉ bs.curNode.nd.curSet := fun hm => hp_not_tgt (hcur_sub_tgt hm)
  have hp_not_rem : h_new ∉ bs.remSnap := fun hm =>
    hp_not_tgt (hunion ▸ Finset.mem_union_right _ hm)
  have hcap_ins : (bs.insCur + bs.curNode.nd.age) + 1 < 2 ^ cp.L_p2 := by
    have := cp.hL_p2; omega
  rcases managedNode_insertMat_spec h_clm_7_3 hd cp.hM₀ cp.T_cdf cp.p_coord params he1
    cp.specs cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q hp_not_cur ω htins hcap_ins hwf_pts'
    with ⟨ho, hs, hV, hbS, hbsz, hage_eq, hcur', hhist', htins', hwf', hgd_imp⟩
  rcases image_insert_uidOf hgt htgt_sub hnot_act pt with ⟨hu_not_img, himg_ins⟩
  let gt' := gt.stepInsert h_new pt
  let bs' := bs.liveInsert cp pts' h_new ω
  have hrem_same : bs'.remSnap = bs.remSnap := rfl
  refine ⟨rfl, rfl, rfl,
    by dsimp only [bs', BuildState.liveInsert]; rw [bumpAge_birthSize, hbsz],
    by dsimp only [bs', BuildState.liveInsert]; rw [bumpAge_age, hage_eq],
    ⟨hnd_s, hnd_d, hins_le,
      by dsimp only [bs', BuildState.liveInsert]; rw [bumpAge_birthSize, hbsz]; exact hbsz_eq,
      by dsimp only [bs', BuildState.liveInsert]; rw [bumpAge_birthSize, hbsz]; exact hbsz_n,
      by dsimp only [bs', BuildState.liveInsert]; rw [bumpAge_birthSize, hbsz]; exact hbsz_B,
      fun u hu => Nat.lt_succ_of_lt (hbirth_u u (by dsimp only [bs', BuildState.liveInsert] at hu; rwa [bumpAge_birthSet, hbS] at hu)),
      ?_, ?_, ?_, ?_, ?_,
      (bumpAge_wf _ _ _ _ _ _ _ _ _).mpr hwf'⟩,
    fun ⟨hcp, hgd_m⟩ hseed => ⟨?_,
      (bumpAge_matGood _ _ _ _ _ _ _ _ _ _ _ _ _).mpr (hgd_imp (hgd_pts' hgd_m) hseed)⟩⟩
  · change Disjoint bs'.curNode.nd.curSet bs'.remSnap
    rw [hrem_same]; dsimp only [bs', BuildState.liveInsert]; rw [bumpAge_curSet, hcur']
    exact Finset.disjoint_insert_left.mpr ⟨hp_not_rem, hdisj⟩
  · change bs'.curNode.nd.curSet ∪ bs'.remSnap = insert h_new targetSet
    rw [hrem_same]; dsimp only [bs', BuildState.liveInsert]; rw [bumpAge_curSet, hcur', Finset.insert_union, hunion]
  · dsimp only [bs', BuildState.liveInsert, gt']
    rw [bumpAge_birthSet, bumpAge_age, hbS, hage_eq, himg_ins]
    exact hasNodeAge_step hage (Or.inl ⟨gt.nextUid, hu_not_img, by ext z; simp⟩)
  · dsimp only [bs', BuildState.liveInsert]
    rw [bumpAge_histArr, bumpAge_age, hhist', hage_eq, List.length_append, List.length_singleton]
    omega
  · dsimp only [bs', BuildState.liveInsert]
    rw [bumpAge_age, bumpAge_maxTIns, hage_eq,
      show bs.insCur + (bs.curNode.nd.age + 1) = (bs.insCur + bs.curNode.nd.age) + 1 by omega]
    exact htins'
  · dsimp only [bs', BuildState.liveInsert]
    rw [bumpAge_birthSet, bumpAge_o, bumpAge_s, hbS, ho, hs]
    refine isCenterpoint_congr_ghostPts (fun u hu => ?_) hcp
    have hne : u ≠ gt.nextUid := Nat.ne_of_lt (hbirth_u u hu)
    dsimp [gt', GhostTracker.stepInsert]
    exact Function.update_of_ne hne pt gt.ghostPts

theorem buildState_liveDelete_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles targetSet : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hgt : GhostTrackerWF actHandles pts gt)
    (htgt_sub : targetSet ⊆ actHandles)
    {h_del : ℕ} (hh_in_tgt : h_del ∈ targetSet)
    (hpts_del : pts' h_del = pts h_del)
    (hpts_old : ∀ x ∈ actHandles.erase h_del, pts' x = pts x)
    {bs : BuildState cp}
    (hage_le : bs.curNode.nd.age ≤ bs.curNode.nd.birthSize)
    (hinv : BuildStateInv cp pts gt targetSet bs)
    (ω : OpSeed cp) :
    let bs' := bs.liveDelete cp pts' h_del ω
    bs'.L_hist = bs.L_hist ∧ bs'.snapArr = bs.snapArr ∧ bs'.insCur = bs.insCur ∧
    bs'.curNode.nd.birthSize = bs.curNode.nd.birthSize ∧
    bs'.curNode.nd.age = bs.curNode.nd.age + 1 ∧
    BuildStateInv cp pts' gt (targetSet.erase h_del) bs' ∧
    (LiveNodeGood cp hh0 hh1 pts gt bs.curNode →
     NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
       cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q bs.curNode.nd ω →
     LiveNodeGood cp hh0 hh1 pts' gt bs'.curNode) := by
  rcases hinv with ⟨hnd_s, hnd_d, hins_le, hbsz_eq, hbsz_n, hbsz_B, hbirth_u,
    hdisj, hunion, hage, hhist, htins, hwf⟩
  have hcur_sub_tgt : bs.curNode.nd.curSet ⊆ targetSet := hunion ▸ Finset.subset_union_left
  have hpts_tgt : ∀ x ∈ targetSet, pts' x = pts x := by
    intro x hx
    by_cases heq : x = h_del
    · subst heq; exact hpts_del
    · exact hpts_old x (Finset.mem_erase.mpr ⟨heq, htgt_sub hx⟩)
  have heq_cur : ∀ x ∈ bs.curNode.nd.curSet, pts' x = pts x :=
    fun x hx => hpts_tgt x (hcur_sub_tgt hx)
  rcases managedNode_pts_congr (M_lat := M_lat_of d params.e) (τ_q := cp.τ_q) (cap_q := cp.cap_q)
    hh0 hh1 heq_cur hwf with ⟨hwf_pts', hgd_pts'⟩
  rcases image_erase_uidOf hgt htgt_sub hh_in_tgt with ⟨hu_in_img, himg_era⟩
  have hage_next : HasNodeAge bs.curNode.nd.birthSet
      ((targetSet.erase h_del).image gt.uidOf) (bs.curNode.nd.age + 1) := by
    rw [himg_era]
    exact hasNodeAge_step hage (Or.inr ⟨gt.uidOf h_del, hu_in_img, by ext z; simp⟩)
  dsimp only [BuildState.liveDelete]
  by_cases hc_cur : bs.curNode.nd.denseArr.contains h_del = true
  · rw [if_pos hc_cur]
    have hp_in_cur : h_del ∈ bs.curNode.nd.curSet :=
      List.mem_toFinset.mpr (List.contains_iff_mem.mp hc_cur)
    have hp_not_rem : h_del ∉ bs.remSnap :=
      Finset.disjoint_left.mp hdisj hp_in_cur
    have hcap_del : (bs.insCur + bs.curNode.nd.age) + 1 < 2 ^ cp.L_p2 := by
      have := cp.hL_p2; omega
    rcases managedNode_deleteMat_spec h_clm_7_3 hd cp.hM₀ cp.T_cdf cp.p_coord params he1
      cp.specs cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q hp_in_cur ω htins hcap_del hwf_pts'
      with ⟨ho, hs, hV, hbS, hbsz, hage_eq, hcur', hhist', htins', hwf', hgd_imp⟩
    refine ⟨rfl, rfl, rfl,
      by dsimp only; rw [bumpAge_birthSize, hbsz],
      by dsimp only; rw [bumpAge_age, hage_eq],
      ⟨hnd_s, hnd_d, hins_le,
        by dsimp only; rw [bumpAge_birthSize, hbsz]; exact hbsz_eq,
        by dsimp only; rw [bumpAge_birthSize, hbsz]; exact hbsz_n,
        by dsimp only; rw [bumpAge_birthSize, hbsz]; exact hbsz_B,
        by dsimp only; rwa [bumpAge_birthSet, hbS],
        ?_, ?_, ?_, ?_, ?_,
        (bumpAge_wf _ _ _ _ _ _ _ _ _).mpr hwf'⟩,
      fun ⟨hcp, hgd_m⟩ hseed => ⟨by dsimp only; rwa [bumpAge_birthSet, bumpAge_o, bumpAge_s, hbS, ho, hs],
        (bumpAge_matGood _ _ _ _ _ _ _ _ _ _ _ _ _).mpr (hgd_imp (hgd_pts' hgd_m) hseed)⟩⟩
    · dsimp only [BuildState.remSnap]; rw [bumpAge_curSet, hcur']
      exact Finset.disjoint_of_subset_left (Finset.erase_subset _ _) hdisj
    · dsimp only [BuildState.remSnap]; rw [bumpAge_curSet, hcur', ← hunion]
      ext z; simp only [Finset.mem_union, Finset.mem_erase]
      constructor
      · rintro (⟨hne, hz⟩ | hzr)
        · exact ⟨hne, Or.inl hz⟩
        · exact ⟨fun heq => hp_not_rem (heq ▸ hzr), Or.inr hzr⟩
      · rintro ⟨hne, hz | hzr⟩
        · exact Or.inl ⟨hne, hz⟩
        · exact Or.inr hzr
    · dsimp only; rwa [bumpAge_birthSet, bumpAge_age, hbS, hage_eq]
    · dsimp only; rw [bumpAge_histArr, bumpAge_age, hhist', hage_eq]; omega
    · dsimp only
      rw [bumpAge_age, bumpAge_maxTIns, hage_eq,
        show bs.insCur + (bs.curNode.nd.age + 1) = (bs.insCur + bs.curNode.nd.age) + 1 by omega]
      exact htins'
  · rw [if_neg hc_cur]
    have hp_not_cur : h_del ∉ bs.curNode.nd.curSet := fun hm =>
      hc_cur (List.contains_iff_mem.mpr (List.mem_toFinset.mp hm))
    have hp_in_rem : h_del ∈ bs.remSnap := by
      have hm_u : h_del ∈ bs.curNode.nd.curSet ∪ bs.remSnap := hunion.symm ▸ hh_in_tgt
      rcases Finset.mem_union.mp hm_u with h1 | h2
      · exact absurd h1 hp_not_cur
      · exact h2
    have hp_not_del : h_del ∉ bs.delSnapArr.toFinset := (Finset.mem_sdiff.mp hp_in_rem).2
    rcases denseInsert_spec hnd_d hp_not_del with ⟨hnd_d', hdel_eq⟩
    have hrem_era : (BuildState.mk bs.L_hist bs.snapArr (denseInsert h_del bs.delSnapArr)
        bs.insCur bs.curNode.bumpAge).remSnap = bs.remSnap.erase h_del := by
      unfold BuildState.remSnap; dsimp only
      rw [hdel_eq]
      ext z; simp only [Finset.mem_sdiff, Finset.mem_insert, Finset.mem_erase]
      tauto
    refine ⟨rfl, rfl, rfl, rfl, rfl,
      ⟨hnd_s, hnd_d', hins_le, hbsz_eq, hbsz_n, hbsz_B, hbirth_u,
        ?_, ?_, hage_next,
        by dsimp only [bumpAge_histArr, bumpAge_age]; omega,
        ?_,
        (bumpAge_wf _ _ _ _ _ _ _ _ _).mpr hwf_pts'⟩,
      fun ⟨hcp, hgd_m⟩ _ => ⟨hcp,
        (bumpAge_matGood _ _ _ _ _ _ _ _ _ _ _ _ _).mpr (hgd_pts' hgd_m)⟩⟩
    · dsimp only [bumpAge_curSet]; rw [hrem_era]
      exact Finset.disjoint_of_subset_right (Finset.erase_subset _ _) hdisj
    · dsimp only [bumpAge_curSet]; rw [hrem_era, ← hunion]
      ext z; simp only [Finset.mem_union, Finset.mem_erase]
      constructor
      · rintro (hz | ⟨hne, hzr⟩)
        · exact ⟨fun heq => hp_not_cur (heq ▸ hz), Or.inl hz⟩
        · exact ⟨hne, Or.inr hzr⟩
      · rintro ⟨hne, hz | hzr⟩
        · exact Or.inl hz
        · exact Or.inr ⟨hne, hzr⟩
    · dsimp only [bumpAge_age, bumpAge_maxTIns]
      intro hV i
      rcases htins hV i with ⟨htL, htR⟩
      exact ⟨htL.trans (by omega), htR.trans (by omega)⟩

end UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
