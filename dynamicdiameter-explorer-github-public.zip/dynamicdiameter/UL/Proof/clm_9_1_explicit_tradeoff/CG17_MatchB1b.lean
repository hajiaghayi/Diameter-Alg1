import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchB1a

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 1. Frame Lifting & Environment Preservation Helpers -/

theorem rfo_lift_hdr {scrW scrR tblW tblR : ℕ} {cfgBaseW cfgBaseR sideWStride sideRStride : ℤ}
    {n : ℕ} {m₀ m₁ : ArithRAMMemory}
    (hw2 : 2 ≤ sideWStride) (_hr0 : 0 ≤ sideRStride)
    (h : RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m₀ m₁) :
    RadFrameOutside scrW scrR tblW cfgBaseW (cfgTotalWStride n sideWStride)
      tblR cfgBaseR (cfgTotalRStride sideRStride) m₀ m₁ :=
  rfo_mono_range h
    (Or.inr ⟨le_rfl, by unfold cfgTotalWStride; omega⟩)
    (Or.inl rfl)

theorem rfo_lift_left {scrW scrR tblW tblR : ℕ} {cfgBaseW cfgBaseR sideWStride sideRStride : ℤ}
    {n : ℕ} {m₀ m₁ : ArithRAMMemory}
    (hw2 : 2 ≤ sideWStride) (hr0 : 0 ≤ sideRStride)
    (h : RadFrameOutside scrW scrR tblW (cfgLeftSideWOff cfgBaseW n) sideWStride
      tblR (cfgLeftSideROff cfgBaseR) sideRStride m₀ m₁) :
    RadFrameOutside scrW scrR tblW cfgBaseW (cfgTotalWStride n sideWStride)
      tblR cfgBaseR (cfgTotalRStride sideRStride) m₀ m₁ := by
  have hhdr3 := cfgHdrWStride_ge_three n
  exact rfo_mono_range h
    (Or.inr ⟨by unfold cfgLeftSideWOff; omega,
             by unfold cfgLeftSideWOff cfgTotalWStride; omega⟩)
    (Or.inr ⟨by unfold cfgLeftSideROff; omega,
             by unfold cfgLeftSideROff cfgTotalRStride; omega⟩)

theorem rfo_lift_right {scrW scrR tblW tblR : ℕ} {cfgBaseW cfgBaseR sideWStride sideRStride : ℤ}
    {n : ℕ} {m₀ m₁ : ArithRAMMemory}
    (hw2 : 2 ≤ sideWStride) (hr0 : 0 ≤ sideRStride)
    (h : RadFrameOutside scrW scrR tblW (cfgRightSideWOff cfgBaseW sideWStride n) sideWStride
      tblR (cfgRightSideROff cfgBaseR sideRStride) sideRStride m₀ m₁) :
    RadFrameOutside scrW scrR tblW cfgBaseW (cfgTotalWStride n sideWStride)
      tblR cfgBaseR (cfgTotalRStride sideRStride) m₀ m₁ := by
  have hhdr3 := cfgHdrWStride_ge_three n
  exact rfo_mono_range h
    (Or.inr ⟨by unfold cfgRightSideWOff; omega,
             by unfold cfgRightSideWOff cfgTotalWStride; omega⟩)
    (Or.inr ⟨by unfold cfgRightSideROff; omega,
             by unfold cfgRightSideROff cfgTotalRStride; omega⟩)

theorem rfo_preserves_env {d L_p2 R ℓ M₀ b TW TR scrW scrR tblW tblR coinTbl : ℕ}
    {cfgBaseW totW cfgBaseR totR offO seedOff : ℤ}
    {o : EuclideanSpace ℝ (Fin d)}
    {ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b}
    {m₀ m₁ : ArithRAMMemory}
    (hvt : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hoffO : 0 ≤ offO ∧ offO + (d : ℤ) ≤ cfgBaseR)
    (hfr : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m₀ m₁)
    (ho : ∀ c : Fin d, H3a.rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hseed : EncCfgSeedSlice coinTbl seedOff ω_L ω_R m₀) :
    (∀ c : Fin d, H3a.rRead m₁ tblR (offO + (c.val : ℤ)) = euclideanCoord o c) ∧
    (∀ idx : ℤ, H3a.rRead m₁ 1 idx = H3a.rRead m₀ 1 idx) ∧
    EncCfgSeedSlice coinTbl seedOff ω_L ω_R m₁ := by
  rcases hvt with ⟨_, _, _, _, _, _, _, hneCoinScr, hneCoinTbl, hneR, hne1Scr, hne1TblR⟩
  refine ⟨fun c => ?_, fun idx => hfr.2 1 idx hne1Scr (Or.inl hne1TblR),
    hseed.mono_coinTbl (fun idx => hfr.1 coinTbl idx hneCoinScr (Or.inl hneCoinTbl))⟩
  have hc := c.isLt
  rw [hfr.2 tblR (offO + (c.val : ℤ)) hneR (Or.inr (Or.inl (by omega)))]
  exact ho c

/-! ### 2. `attachLeftCopyStmt` and `attachRightCopyStmt` -/

def attachCopyWScr {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℤ :=
  8 + sops.sideWScrStride

def attachCopyCost {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℕ :=
  260 + sops.queryCost + max (160 + sops.insertCost) (120 + appendEdgeCost + sops.removeCost)

def attachLeftCopyStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (A B_rat b_rat : ℚ)
    (wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr : ℤ) : ArithRAMStmt :=
  let bWE := IntExpr.readHeap scrW (.lit wCfgBaseW)
  let bRE := IntExpr.readHeap scrW (.lit wCfgBaseR)
  let sSBW := wScr
  let sSBR := wScr + 1
  let sOffO := wScr + 2
  let sVId := wScr + 3
  let sAns := wScr + 4
  let sSeed := wScr + 5
  let wSub := wScr + 6
  .seq (.writeWordHeap scrW (.lit sSBW) (.add bWE (.lit (cfgHdrWStride n + sops.sideWStride))))
  (.seq (.writeWordHeap scrW (.lit sSBR) (.add bRE (.lit sops.sideRStride)))
  (.seq (.writeWordHeap scrW (.lit sOffO) (.readHeap scrW (.lit wOffO)))
  (.seq (.writeWordHeap scrW (.lit sVId) (.readHeap scrW (.lit wVId)))
  (.seq (sops.queryStmt A B_rat b_rat sSBW sSBR sOffO sVId sAns wSub rScr)
        (.ite (.intLt (.readHeap scrW (.lit sAns)) (.lit 0))
          (.seq (.writeWordHeap tblW
                  (.add (.add bWE (.lit (3 + 4 * (n : ℤ)))) (.readHeap scrW (.lit sVId)))
                  (.readHeap tblW bWE))
          (.seq (.writeWordHeap scrW (.lit sSBW) (.add bWE (.lit (cfgHdrWStride n))))
          (.seq (.writeWordHeap scrW (.lit sSBR) bRE)
          (.seq (.writeWordHeap scrW (.lit sSeed) (.readHeap scrW (.lit wSeedOff)))
                (sops.insertStmt A B_rat sSBW sSBR sOffO sVId sSeed wSub rScr)))))
          (.seq (.writeWordHeap tblW
                  (.add (.add bWE (.lit (3 + 5 * (n : ℤ)))) (.readHeap scrW (.lit sAns)))
                  (.lit 0))
          (.seq (appendEdgeStmt scrW tblW n wCfgBaseW sVId sAns wSub)
                (sops.removeStmt sSBW sSBR sAns wSub rScr))))))))

theorem zeroRand_attachLeftCopyStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (A B_rat b_rat : ℚ)
    (wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr : ℤ) :
    ZeroRandStmt (attachLeftCopyStmt sops A B_rat b_rat
      wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (sops.zeroRand_queryStmt _ _ _ _ _ _ _ _ _ _)
    (.ite
      (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _) (sops.zeroRand_insertStmt _ _ _ _ _ _ _ _ _)))))
      (.seq (.writeWordHeap _ _ _) (.seq (zeroRand_appendEdgeStmt _ _ _ _ _ _ _)
            (sops.zeroRand_removeStmt _ _ _ _ _))))))))

theorem exec_attachLeftCopyStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (hM₀ : 1 ≤ M₀) (hn : 2 ≤ n) (hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    (params : LocalScaleParams) (cfg : ShellConfig)
    {A B_rat : ℚ} (hAB : A ^ 2 + B_rat ^ 2 = 1)
    (wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr
      cfgBaseW cfgBaseR offO seedOff : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)} {V : ℝ} (hV : 0 < V)
    {vId : ℕ} (hv_lt : vId < n) (hv_ne_o : pts vId ≠ o)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    (hdj : IndexDisjoint cs.st)
    (hv_not_m : vId ∉ (cs.st.matchingList.map MatchingEdge.pair).map Prod.fst)
    (hv_not_i : vId ∉ cs.st.leftIndexSet)
    (htL : cs.leftIdx.t_ins + 1 < 2 ^ L_p2) (htR : cs.rightIdx.t_ins < 2 ^ L_p2)
    (hwfL : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs.st.leftIndexSet cs.leftIdx)
    (hwfR : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs.st.rightIndexSet cs.rightIdx)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hvt : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ cfgBaseW ∧ cfgBaseW + cfgTotalWStride n sops.sideWStride ≤ (BW : ℤ))
    (hbaseR : 0 ≤ cfgBaseR ∧ cfgBaseR + cfgTotalRStride sops.sideRStride ≤ (BR : ℤ))
    (hoffO : 0 ≤ offO ∧ offO + (d : ℤ) ≤ cfgBaseR)
    (hseedB : 0 ≤ seedOff ∧ seedOff + (cfgSeedBits L_p2 R ℓ M₀ d b : ℤ) ≤ (BW : ℤ))
    (hptsB : ((n * d : ℕ) : ℤ) ≤ (BR : ℤ))
    (hwBW : 0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr)
    (hwBR : 0 ≤ wCfgBaseR ∧ wCfgBaseR < wScr)
    (hwO : 0 ≤ wOffO ∧ wOffO < wScr)
    (hwVId : 0 ≤ wVId ∧ wVId < wScr)
    (hwSeed : 0 ≤ wSeedOff ∧ wSeedOff < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + attachCopyWScr sops ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + sops.sideRScrStride ≤ (BR : ℤ))
    (hbW : H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW)
    (hbR : H3a.wRead m₀ scrW wCfgBaseR = cfgBaseR)
    (ho_off : H3a.wRead m₀ scrW wOffO = offO)
    (hv_r : H3a.wRead m₀ scrW wVId = (vId : ℤ))
    (hseed_off : H3a.wRead m₀ scrW wSeedOff = seedOff)
    (ho_mem : ∀ c : Fin d, H3a.rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpts_L : ∀ x ∈ Insert.insert vId cs.st.leftIndexSet, ∀ c : Fin d,
      H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hpts_R : ∀ x ∈ Insert.insert vId cs.st.rightIndexSet, ∀ c : Fin d,
      H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hseed : EncCfgSeedSlice coinTbl seedOff ω_L ω_R m₀)
    (henc : EncCfgDyn sops cfgBaseW cfgBaseR cs m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (attachLeftCopyStmt sops A B_rat (bRatCfg params cfg)
        wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr)
        m₀ m₁ (attachCopyCost sops) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncCfgDyn sops cfgBaseW cfgBaseR
        (attachCopyStep hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
          pts o V cfg ⟨.left, vId⟩ ω_L ω_R cs) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgTotalWStride n sops.sideWStride)
        tblR cfgBaseR (cfgTotalRStride sops.sideRStride) m₀ m₁ := by
  have hw2 := sops.hsideW_ge_two
  have hr0 := sops.hsideR_nonneg
  have hwScr1 := sops.hsideWScr_pos
  have hhdr3 := cfgHdrWStride_ge_three n
  have hscrW : scrW < TW := hvt.1
  have htblW : tblW < TW := hvt.2.1
  have hneW : tblW ≠ scrW := hvt.2.2.2.2.2.2.1
  have hneR : tblR ≠ scrR := hvt.2.2.2.2.2.2.2.2.2.1
  have hUL_lt : ∀ x ∈ cs.st.leftIndexSet, x < n := by
    rcases henc.1 with ⟨_, _, _, _, _, _, h, _⟩; exact h
  have hUR_lt : ∀ x ∈ cs.st.rightIndexSet, x < n := by
    rcases henc.1 with ⟨_, _, _, _, _, _, _, h, _⟩; exact h
  let totW := cfgTotalWStride n sops.sideWStride
  let totR := cfgTotalRStride sops.sideRStride
  let lBW := cfgLeftSideWOff cfgBaseW n
  let rBW := cfgRightSideWOff cfgBaseW sops.sideWStride n
  let lBR := cfgLeftSideROff cfgBaseR
  let rBR := cfgRightSideROff cfgBaseR sops.sideRStride
  let sSBW := wScr
  let sSBR := wScr + 1
  let sOffO := wScr + 2
  let sVId := wScr + 3
  let sAns := wScr + 4
  let sSeed := wScr + 5
  let wSub := wScr + 6
  have hwScr' : 0 ≤ wScr ∧ wScr + (8 + sops.sideWScrStride) ≤ (BW : ℤ) := hwScr
  -- Stage 4 scratch words `m0 -> m4`
  let m1 := H3a.wWrite m₀ scrW sSBW rBW
  let m2 := H3a.wWrite m1 scrW sSBR rBR
  let m3 := H3a.wWrite m2 scrW sOffO offO
  let m4 := H3a.wWrite m3 scrW sVId (vId : ℤ)
  have hscr04 : ∀ w, w < wScr →
      H3a.wRead m1 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m3 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m4 scrW w = H3a.wRead m₀ scrW w := by
    intro w hw
    have a1 : H3a.wRead m1 scrW w = H3a.wRead m₀ scrW w := wRead_wWrite_of_ne _ _ (Or.inr (by omega))
    have a2 : H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w := (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans a1
    have a3 : H3a.wRead m3 scrW w = H3a.wRead m₀ scrW w := (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans a2
    have a4 : H3a.wRead m4 scrW w = H3a.wRead m₀ scrW w := (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans a3
    exact ⟨a1, a2, a3, a4⟩
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit sSBW)
      (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (cfgHdrWStride n + sops.sideWStride)))) m₀ m1 25 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit sSBW) _ rfl
      (by change H3a.wRead m₀ scrW wCfgBaseW + (cfgHdrWStride n + sops.sideWStride) = rBW
          rw [hbW]; unfold rBW cfgRightSideWOff; ring)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit sSBR)
      (.add (.readHeap scrW (.lit wCfgBaseR)) (.lit sops.sideRStride))) m1 m2 25 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit sSBR) _ rfl
      (by change H3a.wRead m1 scrW wCfgBaseR + sops.sideRStride = rBR
          rw [(hscr04 wCfgBaseR hwBR.2).1, hbR]; rfl)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit sOffO) (.readHeap scrW (.lit wOffO))) m2 m3 20 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit sOffO) _ rfl
      (by change H3a.wRead m2 scrW wOffO = offO; rw [(hscr04 wOffO hwO.2).2.1, ho_off])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd4 : DetExec inp (.writeWordHeap scrW (.lit sVId) (.readHeap scrW (.lit wVId))) m3 m4 20 :=
    DetExecAt.writeWordHeap 0 inp m3 scrW (.lit sVId) _ rfl
      (by change H3a.wRead m3 scrW wVId = (vId : ℤ); rw [(hscr04 wVId hwVId.2).2.2.1, hv_r])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp4 : InFootprint TW BW TR BR m4 :=
    InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀
      hscrW (by omega) (by omega)) hscrW (by omega) (by omega))
      hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
  have hfr04 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m₀ m4 :=
    (((rfo_wWrite_scr _ _ _ _ _ _ _ _ m₀ sSBW rBW).trans
      (rfo_wWrite_scr _ _ _ _ _ _ _ _ m1 sSBR rBR)).trans
      (rfo_wWrite_scr _ _ _ _ _ _ _ _ m2 sOffO offO)).trans
      (rfo_wWrite_scr _ _ _ _ _ _ _ _ m3 sVId (vId : ℤ))
  have henc4 : EncCfgDyn sops cfgBaseW cfgBaseR cs m4 :=
    henc.mono_slice sops
      (fun i _ _ => by simp [m4, m3, m2, m1, wRead_wWrite_of_ne _ _ (Or.inl hneW)])
      (fun i _ _ => by simp [m4, m3, m2, m1, rRead_wWrite])
  obtain ⟨ho4, h1_4, hseed4⟩ := rfo_preserves_env hvt hoffO hfr04 ho_mem hseed
  -- Query `rightIdx` (`m4 -> m5`)
  obtain ⟨m5, hd5, hfp5, hencR5, hans5, hkW5, hfr45_R⟩ :=
    sops.exec_queryStmt inp hM₀ hn hL_p2 A B_rat (bRatCfg params cfg) hAB
      sSBW sSBR sOffO sVId sAns wSub rScr rBW rBR offO
      hv_lt hUR_lt hv_ne_o htR hwfR hfp4 hvt
      ⟨by unfold rBW cfgRightSideWOff; omega,
       by unfold rBW cfgRightSideWOff; unfold cfgTotalWStride at hbaseW; omega⟩
      ⟨by unfold rBR cfgRightSideROff; omega,
       by unfold rBR cfgRightSideROff; unfold cfgTotalRStride at hbaseR; omega⟩
      ⟨hoffO.1, by unfold rBR cfgRightSideROff; omega⟩
      hptsB
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      ⟨by omega, by omega, by omega, by omega, by omega,
       by omega, by omega, by omega, by omega, by omega⟩
      ⟨by omega, by omega⟩ hrScr
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_self])
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
      (wRead_wWrite_self _ _ _ _)
      ho4
      (fun x hx c => (h1_4 _).trans (hpts_R x hx c))
      henc4.2.2
  have hfr45 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m4 m5 :=
    rfo_lift_right hw2 hr0 hfr45_R
  have hfr05 := hfr04.trans hfr45
  obtain ⟨ho5, h1_5, hseed5⟩ := rfo_preserves_env hvt hoffO hfr05 ho_mem hseed
  have henc_hdr5 : EncLocalMatching tblW cfgBaseW n cs.st m5 :=
    henc4.1.mono_slice (fun i _ hhi =>
      hfr45_R.1 tblW i hneW (Or.inr (Or.inl (by unfold rBW cfgRightSideWOff; omega))))
  have hencL5 : sops.EncSide lBW lBR cs.st.leftIndexSet cs.leftIdx m5 :=
    sops.encSide_mono_slice hUL_lt henc4.2.1
      (fun i _ hhi => hfr45_R.1 tblW i hneW (Or.inr (Or.inl (by
        unfold lBW cfgLeftSideWOff at hhi; unfold rBW cfgRightSideWOff; omega))))
      (fun i _ hhi => hfr45_R.2 tblR i hneR (Or.inr (Or.inl (by
        unfold lBR cfgLeftSideROff at hhi; unfold rBR cfgRightSideROff; omega))))
  have hscr05 : ∀ w, w < wScr → H3a.wRead m5 scrW w = H3a.wRead m₀ scrW w :=
    fun w hw => (hkW5 w (by omega) (by omega)).trans (hscr04 w hw).2.2.2
  have hsSBW5 : H3a.wRead m5 scrW sSBW = rBW := by
    rw [hkW5 sSBW (by omega) (by omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hsSBR5 : H3a.wRead m5 scrW sSBR = rBR := by
    rw [hkW5 sSBR (by omega) (by omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_self]
  have hsOffO5 : H3a.wRead m5 scrW sOffO = offO := by
    rw [hkW5 sOffO (by omega) (by omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hsVId5 : H3a.wRead m5 scrW sVId = (vId : ℤ) := by
    rw [hkW5 sVId (by omega) (by omega), wRead_wWrite_self]
  rw [attachCopyStep_left_eq hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
    pts o hV cfg vId ω_L ω_R cs hwfR]
  cases hraw : cs.rightIdx.query hM₀ M_lat A B_rat τ_q (bRatCfg params cfg : ℝ) cap_q o (pts vId) with
  | none =>
      rw [hraw] at hans5
      dsimp only
      have hc_t : cValAt 0 inp m5 (.intLt (.readHeap scrW (.lit sAns)) (.lit 0)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m5 scrW sAns < 0) = true
        rw [hans5]; rfl
      let st' := attachStep pts cs.st ⟨.left, vId⟩ none
      let m6 := H3a.wWrite m5 tblW (cfgInIdxLEpOff cfgBaseW n vId) (H3a.wRead m5 tblW (cfgEpOff cfgBaseW))
      let m7 := H3a.wWrite m6 scrW sSBW lBW
      let m8 := H3a.wWrite m7 scrW sSBR lBR
      let m9 := H3a.wWrite m8 scrW sSeed seedOff
      have hd6 : DetExec inp (.writeWordHeap tblW
          (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 4 * (n : ℤ))))
                (.readHeap scrW (.lit sVId)))
          (.readHeap tblW (.readHeap scrW (.lit wCfgBaseW)))) m5 m6 35 :=
        DetExecAt.writeWordHeap 0 inp m5 tblW _ _
          (by change (H3a.wRead m5 scrW wCfgBaseW + (3 + 4 * (n : ℤ))) + H3a.wRead m5 scrW sVId =
                cfgInIdxLEpOff cfgBaseW n vId
              rw [hscr05 wCfgBaseW hwBW.2, hbW, hsVId5]
              unfold cfgInIdxLEpOff; ring)
          (by change H3a.wRead m5 tblW (H3a.wRead m5 scrW wCfgBaseW) = H3a.wRead m5 tblW (cfgEpOff cfgBaseW)
              rw [hscr05 wCfgBaseW hwBW.2, hbW]; rfl)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have henc_hdr6 : EncLocalMatching tblW cfgBaseW n st' m6 :=
        henc_hdr5.write_inIdxL_ep vId hv_lt
          (by simp [st', attachStep])
          (by simpa [st'] using leftIndexSet_attachStep_eq pts cs.st ⟨.left, vId⟩ none)
          (by simpa [st'] using rightIndexSet_attachStep_eq pts cs.st ⟨.left, vId⟩ none)
      have hscr59 : ∀ w, w < wScr →
          H3a.wRead m6 scrW w = H3a.wRead m₀ scrW w ∧
          H3a.wRead m7 scrW w = H3a.wRead m₀ scrW w ∧
          H3a.wRead m8 scrW w = H3a.wRead m₀ scrW w ∧
          H3a.wRead m9 scrW w = H3a.wRead m₀ scrW w := by
        intro w hw
        have b6 : H3a.wRead m6 scrW w = H3a.wRead m₀ scrW w :=
          (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans (hscr05 w hw)
        have b7 : H3a.wRead m7 scrW w = H3a.wRead m₀ scrW w := (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans b6
        have b8 : H3a.wRead m8 scrW w = H3a.wRead m₀ scrW w := (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans b7
        have b9 : H3a.wRead m9 scrW w = H3a.wRead m₀ scrW w := (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans b8
        exact ⟨b6, b7, b8, b9⟩
      have hd7 : DetExec inp (.writeWordHeap scrW (.lit sSBW)
          (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (cfgHdrWStride n)))) m6 m7 25 :=
        DetExecAt.writeWordHeap 0 inp m6 scrW (.lit sSBW) _ rfl
          (by change H3a.wRead m6 scrW wCfgBaseW + cfgHdrWStride n = lBW
              rw [(hscr59 wCfgBaseW hwBW.2).1, hbW]; rfl)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd8 : DetExec inp (.writeWordHeap scrW (.lit sSBR) (.readHeap scrW (.lit wCfgBaseR))) m7 m8 20 :=
        DetExecAt.writeWordHeap 0 inp m7 scrW (.lit sSBR) _ rfl
          (by change H3a.wRead m7 scrW wCfgBaseR = lBR
              rw [(hscr59 wCfgBaseR hwBR.2).2.1, hbR]; rfl)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd9 : DetExec inp (.writeWordHeap scrW (.lit sSeed) (.readHeap scrW (.lit wSeedOff))) m8 m9 20 :=
        DetExecAt.writeWordHeap 0 inp m8 scrW (.lit sSeed) _ rfl
          (by change H3a.wRead m8 scrW wSeedOff = seedOff
              rw [(hscr59 wSeedOff hwSeed.2).2.2.1, hseed_off])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp6 : InFootprint TW BW TR BR m6 := by
        unfold cfgTotalWStride cfgHdrWStride at hbaseW
        exact InFootprint.wWrite hfp5 htblW (by unfold cfgInIdxLEpOff; omega) (by unfold cfgInIdxLEpOff; omega)
      have hfp9 : InFootprint TW BW TR BR m9 :=
        InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp6
          hscrW (by omega) (by omega)) hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
      have hfr56 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m5 m6 :=
        rfo_wWrite_in _ _ _ _ _ _ _ _ m5 _
          (by unfold cfgInIdxLEpOff; omega)
          (by unfold cfgInIdxLEpOff totW cfgTotalWStride cfgHdrWStride; omega)
      have hfr59 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m5 m9 :=
        ((hfr56.trans (rfo_wWrite_scr _ _ _ _ _ _ _ _ m6 sSBW lBW)).trans
          (rfo_wWrite_scr _ _ _ _ _ _ _ _ m7 sSBR lBR)).trans
          (rfo_wWrite_scr _ _ _ _ _ _ _ _ m8 sSeed seedOff)
      obtain ⟨ho9, h1_9, hseed9⟩ := rfo_preserves_env hvt hoffO (hfr05.trans hfr59) ho_mem hseed
      have hencL9 : sops.EncSide lBW lBR cs.st.leftIndexSet cs.leftIdx m9 :=
        sops.encSide_mono_slice hUL_lt hencL5
          (fun i hlo _ => by
            rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inr (by
                  unfold lBW cfgLeftSideWOff cfgHdrWStride at hlo; unfold cfgInIdxLEpOff; omega))])
          (fun i _ _ => by simp [m9, m8, m7, m6, rRead_wWrite])
      have hseedL_eq : (cfgSeedBits L_p2 R ℓ M₀ d b : ℤ) =
          ((L_p2 * oneSeedBits R ℓ M₀ d b : ℕ) : ℤ) + ((L_p2 * oneSeedBits R ℓ M₀ d b : ℕ) : ℤ) := by
        unfold cfgSeedBits; push_cast; ring
      obtain ⟨m10, hd10, hfp10, hencL10, hkW10, hfr9_10_L⟩ :=
        sops.exec_insertStmt inp hM₀ hn hL_p2 A B_rat hAB
          sSBW sSBR sOffO sVId sSeed wSub rScr lBW lBR offO seedOff
          hv_not_i hv_lt hUL_lt hv_ne_o ω_L htL hwfL hfp9 hvt
          ⟨by unfold lBW cfgLeftSideWOff; omega,
           by unfold lBW cfgLeftSideWOff; unfold cfgTotalWStride at hbaseW; omega⟩
          ⟨by unfold lBR cfgLeftSideROff; omega,
           by unfold lBR cfgLeftSideROff; unfold cfgTotalRStride at hbaseR; omega⟩
          ⟨hoffO.1, by unfold lBR cfgLeftSideROff; omega⟩
          ⟨hseedB.1, by rw [hseedL_eq] at hseedB; omega⟩
          hptsB
          ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
          ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
          ⟨by omega, by omega, by omega, by omega, by omega,
           by omega, by omega, by omega, by omega, by omega⟩
          ⟨by omega, by omega⟩ hrScr
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_self])
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
                  hsOffO5])
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
                  hsVId5])
          (wRead_wWrite_self _ _ _ _)
          ho9
          (fun x hx c => (h1_9 _).trans (hpts_L x hx c))
          hseed9.1
          hencL9
      have hfr9_10 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m9 m10 :=
        rfo_lift_left hw2 hr0 hfr9_10_L
      have henc_hdr10 : EncLocalMatching tblW cfgBaseW n st' m10 :=
        henc_hdr6.mono_slice (fun i _ hhi => by
          rw [hfr9_10_L.1 tblW i hneW (Or.inr (Or.inl (by unfold lBW cfgLeftSideWOff; omega))),
              wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
              wRead_wWrite_of_ne _ _ (Or.inl hneW)])
      have hencR10 : sops.EncSide rBW rBR st'.rightIndexSet cs.rightIdx m10 := by
        have hUR_eq : st'.rightIndexSet = cs.st.rightIndexSet := by
          simpa [st'] using rightIndexSet_attachStep_eq pts cs.st ⟨.left, vId⟩ none
        rw [hUR_eq]
        exact sops.encSide_mono_slice hUR_lt hencR5
          (fun i hlo _ => by
            rw [hfr9_10_L.1 tblW i hneW (Or.inr (Or.inr (by
                  unfold rBW cfgRightSideWOff at hlo; unfold lBW cfgLeftSideWOff; omega))),
                wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inr (by
                  unfold rBW cfgRightSideWOff cfgHdrWStride at hlo; unfold cfgInIdxLEpOff; omega))])
          (fun i hlo _ => by
            rw [hfr9_10_L.2 tblR i hneR (Or.inr (Or.inr (by
                  unfold rBR cfgRightSideROff at hlo; unfold lBR cfgLeftSideROff; omega)))]
            simp [m9, m8, m7, m6, rRead_wWrite])
      have hUL_eq : st'.leftIndexSet = Insert.insert vId cs.st.leftIndexSet := by
        simpa [st'] using leftIndexSet_attachStep_eq pts cs.st ⟨.left, vId⟩ none
      have hencL10' : sops.EncSide lBW lBR st'.leftIndexSet
          (cs.leftIdx.insertHandle hM₀ T_cdf p_coord A B_rat τ_d cap_u o (pts vId) vId ω_L) m10 := by
        rwa [hUL_eq]
      have hd_all : DetExec inp (attachLeftCopyStmt sops A B_rat (bRatCfg params cfg)
          wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr) m₀ m10 (attachCopyCost sops) :=
        (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (DetExecAt.ite_true (C_c := 15) hc_t
          (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          (hd6.seq (hd7.seq (hd8.seq (hd9.seq hd10)))))))))).mono_cost
          (by unfold attachCopyCost; omega)
      exact ⟨m10, hd_all, hfp10, ⟨henc_hdr10, hencL10', hencR10⟩,
        fun w hw => (hkW10 w (by omega)).trans (hscr59 w hw).2.2.2,
        hfr05.trans (hfr59.trans hfr9_10)⟩
  | some w =>
      rw [hraw] at hans5
      dsimp only
      obtain ⟨hw_mem, _⟩ := dyadicSide_query_sound hM₀ M_lat τ_q (bRatCfg params cfg : ℝ)
        cap_q (pts vId) hwfR hraw
      have hw_lt : w < n := hUR_lt w hw_mem
      have hw_not_R : w ∉ (cs.st.matchingList.map MatchingEdge.pair).map Prod.snd :=
        hdj.2 w hw_mem
      have hc_f : cValAt 0 inp m5 (.intLt (.readHeap scrW (.lit sAns)) (.lit 0)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m5 scrW sAns < 0) = false
        rw [hans5]; exact decide_eq_false (by omega)
      let st' := attachStep pts cs.st ⟨.left, vId⟩ (some w)
      let st_mid : LocalMatchingState ℕ :=
        { cs.st with rightUnmatchedIndex := st'.rightUnmatchedIndex }
      have hUR_eq : st'.rightIndexSet = cs.st.rightIndexSet.erase w := by
        simpa [st'] using rightIndexSet_attachStep_eq pts cs.st ⟨.left, vId⟩ (some w)
      let m6 := H3a.wWrite m5 tblW (cfgInIdxREpOff cfgBaseW n w) 0
      have hd6 : DetExec inp (.writeWordHeap tblW
          (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 5 * (n : ℤ))))
                (.readHeap scrW (.lit sAns))) (.lit 0)) m5 m6 35 :=
        DetExecAt.writeWordHeap 0 inp m5 tblW _ (.lit 0)
          (by change (H3a.wRead m5 scrW wCfgBaseW + (3 + 5 * (n : ℤ))) + H3a.wRead m5 scrW sAns =
                cfgInIdxREpOff cfgBaseW n w
              rw [hscr05 wCfgBaseW hwBW.2, hbW, hans5]
              unfold cfgInIdxREpOff; ring)
          rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have henc_hdr6 : EncLocalMatching tblW cfgBaseW n st_mid m6 :=
        henc_hdr5.write_inIdxR_zero w hw_lt rfl rfl hUR_eq
      have hfp6 : InFootprint TW BW TR BR m6 := by
        unfold cfgTotalWStride cfgHdrWStride at hbaseW
        exact InFootprint.wWrite hfp5 htblW (by unfold cfgInIdxREpOff; omega) (by unfold cfgInIdxREpOff; omega)
      have hfr56 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m5 m6 :=
        rfo_wWrite_in _ _ _ _ _ _ _ _ m5 0
          (by unfold cfgInIdxREpOff; omega)
          (by unfold cfgInIdxREpOff totW cfgTotalWStride cfgHdrWStride; omega)
      obtain ⟨m7, hd7, hfp7, henc_hdr7, hkW7, hfr67_H⟩ :=
        exec_appendEdgeStmt (tblR := tblR) (coinTbl := coinTbl) inp
          wCfgBaseW sVId sAns wSub cfgBaseW cfgBaseR (st := st_mid) (st' := st')
          hfp6 hvt
          ⟨hbaseW.1, by unfold cfgTotalWStride at hbaseW; omega⟩
          ⟨hwBW.1, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
          ⟨by omega, by omega⟩
          ((wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans ((hscr05 wCfgBaseW hwBW.2).trans hbW))
          ((wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans hsVId5)
          ((wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans hans5)
          hv_lt hw_lt hv_not_m hw_not_R
          (by simp [st', st_mid, attachStep, MatchingEdge.pair])
          rfl rfl henc_hdr6
      have hfr67 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m6 m7 :=
        rfo_lift_hdr hw2 hr0 hfr67_H
      have hencR7 : sops.EncSide rBW rBR cs.st.rightIndexSet cs.rightIdx m7 :=
        sops.encSide_mono_slice hUR_lt hencR5
          (fun i hlo _ => by
            rw [hfr67_H.1 tblW i hneW (Or.inr (Or.inr (by unfold rBW cfgRightSideWOff at hlo; omega))),
                wRead_wWrite_of_ne _ _ (Or.inr (by
                  unfold rBW cfgRightSideWOff cfgHdrWStride at hlo; unfold cfgInIdxREpOff; omega))])
          (fun i _ _ => by
            rw [hfr67_H.2 tblR i hneR (Or.inr (by rcases lt_or_ge i cfgBaseR with h | h; exact Or.inl h; exact Or.inr (by omega))),
                rRead_wWrite])
      obtain ⟨m8, hd8, hfp8, hencR8, hkW8, hfr78_R⟩ :=
        sops.exec_removeStmt inp hM₀ hn hL_p2 hAB
          sSBW sSBR sAns wSub rScr rBW rBR hw_lt hUR_lt hwfR hfp7 hvt
          ⟨by unfold rBW cfgRightSideWOff; omega,
           by unfold rBW cfgRightSideWOff; unfold cfgTotalWStride at hbaseW; omega⟩
          ⟨by unfold rBR cfgRightSideROff; omega,
           by unfold rBR cfgRightSideROff; unfold cfgTotalRStride at hbaseR; omega⟩
          ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
          ⟨by omega, by omega, by omega⟩
          ⟨by omega, by omega⟩ hrScr
          (by rw [hkW7 sSBW (by omega), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hsSBW5])
          (by rw [hkW7 sSBR (by omega), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hsSBR5])
          (by rw [hkW7 sAns (by omega), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hans5])
          hencR7
      have hfr78 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m7 m8 :=
        rfo_lift_right hw2 hr0 hfr78_R
      have henc_hdr8 : EncLocalMatching tblW cfgBaseW n st' m8 :=
        henc_hdr7.mono_slice (fun i _ hhi =>
          hfr78_R.1 tblW i hneW (Or.inr (Or.inl (by unfold rBW cfgRightSideWOff; omega))))
      have hencL8 : sops.EncSide lBW lBR st'.leftIndexSet cs.leftIdx m8 := by
        have hUL_eq : st'.leftIndexSet = cs.st.leftIndexSet := by
          simpa [st'] using leftIndexSet_attachStep_eq pts cs.st ⟨.left, vId⟩ (some w)
        rw [hUL_eq]
        exact sops.encSide_mono_slice hUL_lt hencL5
          (fun i hlo hhi => by
            rw [hfr78_R.1 tblW i hneW (Or.inr (Or.inl (by
                  unfold lBW cfgLeftSideWOff at hhi; unfold rBW cfgRightSideWOff; omega))),
                hfr67_H.1 tblW i hneW (Or.inr (Or.inr (by unfold lBW cfgLeftSideWOff at hlo; omega))),
                wRead_wWrite_of_ne _ _ (Or.inr (by
                  unfold lBW cfgLeftSideWOff cfgHdrWStride at hlo; unfold cfgInIdxREpOff; omega))])
          (fun i _ hhi => by
            rw [hfr78_R.2 tblR i hneR (Or.inr (Or.inl (by
                  unfold lBR cfgLeftSideROff at hhi; unfold rBR cfgRightSideROff; omega))),
                hfr67_H.2 tblR i hneR (Or.inr (by rcases lt_or_ge i cfgBaseR with h | h; exact Or.inl h; exact Or.inr (by omega))),
                rRead_wWrite])
      have hencR8' : sops.EncSide rBW rBR st'.rightIndexSet (cs.rightIdx.removeHandle w) m8 := by
        rwa [hUR_eq]
      have hd_all : DetExec inp (attachLeftCopyStmt sops A B_rat (bRatCfg params cfg)
          wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr) m₀ m8 (attachCopyCost sops) :=
        (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (DetExecAt.ite_false (C_c := 15) hc_f
          (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          (hd6.seq (hd7.seq hd8)))))))).mono_cost
          (by unfold attachCopyCost; omega)
      exact ⟨m8, hd_all, hfp8, ⟨henc_hdr8, hencL8, hencR8'⟩,
        fun w' hw' => by
          rw [hkW8 w' (by omega), hkW7 w' (by omega),
              wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hscr05 w' hw'],
        hfr05.trans (hfr56.trans (hfr67.trans hfr78))⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
