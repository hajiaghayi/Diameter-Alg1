import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.lem_9_1
import UL.Stmt.lem_6_2
import UL.Stmt.clm_5_1_mc_baseline
import UL.Proof.clm_9_1_explicit_tradeoff.H1_Algebra
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H3a3_ExactScan
import UL.Proof.clm_9_1_explicit_tradeoff.H3b1_PolyCDF
import UL.Proof.clm_9_1_explicit_tradeoff.H4a1_FilterPure
import UL.Proof.clm_9_1_explicit_tradeoff.H4b_DyadicMatching
import UL.Proof.clm_9_1_explicit_tradeoff.H4c1_NodePrim
import UL.Proof.clm_9_1_explicit_tradeoff.H4c2_ChainSched
import UL.Proof.clm_9_1_explicit_tradeoff.H4c3b_JobStep
import UL.Proof.clm_9_1_explicit_tradeoff.H4c3c_ChainEngine
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG15

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_clm_6_1_precision_RaceV30
open UL.Proof.clm_9_1_explicit_tradeoff.H1
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a3
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 1. Uniform `(c, σ)`-Only Cutoff & Static Curve Parameters -/

/-- Uniform `(c, σ)`-only threshold `M_cutoff` separating the `min n t ≤ M_cutoff` exact-scan
regime (`H3a3_ExactScan`) from the `min n t > M_cutoff` sublinear chain regime. -/
def M_cutoff (_c _σ : ℝ) : ℕ := 16

/-- 2-variable `(d, logTerm)` cutoff wrapper matching `SublinearCurveSpec.M_cut`. -/
def M_cut_poly (c σ : ℝ) (_d _L : ℕ) : ℕ := M_cutoff c σ

theorem M_cut_poly_bounded (c σ : ℝ) :
    IsBoundedByPoly2 (fun d L => (M_cut_poly c σ d L : ℝ)) := by
  dsimp only [M_cut_poly, M_cutoff]
  exact isBoundedByPoly2_const (by positivity)

theorem min_le_M_cutoff_or_gt (c σ : ℝ) (n t : ℕ) :
    min n t ≤ M_cutoff c σ ∨ (M_cutoff c σ < n ∧ M_cutoff c σ < t) := by
  by_cases hn : M_cutoff c σ < n
  · by_cases ht : M_cutoff c σ < t
    · exact Or.inr ⟨hn, ht⟩
    · exact Or.inl ((Nat.min_le_right n t).trans (Nat.not_lt.mp ht))
  · exact Or.inl ((Nat.min_le_left n t).trans (Nat.not_lt.mp hn))

/-- Uniform `(c, σ)`-only static constants extracted once from `S_lem_9_1`, `S_lem_6_2`,
and `S_clm_5_1_mc_baseline` (independent of `d`, `n`, `t`, `δ`). -/
structure CurveStaticParams (c σ : ℝ) where
  hc_gt : 1 < c
  hc_lt : c < Real.sqrt 2
  hσ0 : 0 ≤ σ
  hσ_hi : σ ≤ rho_c c
  C_shell : ℝ
  C_cfg : ℝ
  C_h : ℝ
  C_q : ℝ
  h_min : ℝ
  hCs0 : 0 ≤ C_shell
  hCc0 : 0 ≤ C_cfg
  hCh0 : 0 ≤ C_h
  hCq0 : 0 ≤ C_q
  hh_min0 : 0 < h_min
  hh_min_le : h_min ≤ g_c c
  lem91_at :
    ∀ (n : ℕ), 2 ≤ n →
      let L : ℕ := L_n n
      ∃ (params : LocalScaleParams) (h x : ℚ),
        params.c = c ∧
        (params.m0 : ℝ) ≤ C_shell * (L : ℝ) ∧
        (params.maxShellIndex : ℝ) ≤ C_shell * (L : ℝ) ∧
        ((params.J + 1 : ℕ) : ℝ) ≤ C_shell * (L : ℝ) ∧
        ((allShellConfigs params.m0 params.K params.J).card : ℝ) ≤ C_cfg * (L : ℝ) ^ 3 ∧
        (∀ V : ℝ, ((params.retainedConfigs V).card : ℝ) ≤ C_cfg * (L : ℝ) ^ 3) ∧
        (params.e : ℝ) ≤ ((params.γ : ℝ) ^ 2 - 1) / 16 ∧
        (h : ℝ) = ((params.γ : ℝ) ^ 2 - 1) - 11 * (params.e : ℝ) ∧
        h_min ≤ (h : ℝ) ∧
        (h : ℝ) ≤ g_c c ∧
        g_c c - (h : ℝ) ≤ C_h / (L : ℝ) ∧
        (∀ (V : ℝ), 0 < V →
          ∀ cfg ∈ params.retainedConfigs V,
            ∃ (A B : ℚ),
              0 < A ∧ 0 ≤ B ∧ A ^ 2 + B ^ 2 = 1 ∧
              ∀ (d : ℕ) (u z z_bar : EuclideanSpace ℝ (Fin d)),
                ‖u‖ = 1 → ‖z‖ = 1 → ‖z_bar‖ = 1 → ‖z_bar - z‖ ≤ (params.e : ℝ) / 8 →
                (params.thresholdA V cfg.j cfg.k cfg.ℓ ≤ inner ℝ z u →
                  (h : ℝ) ≤ inner ℝ
                    (liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ)))
                    (liftedPoint ((A : ℝ) • u) (B : ℝ))) ∧
                (inner ℝ z u ≤ params.thresholdB V cfg.j cfg.k cfg.ℓ →
                  inner ℝ
                    (liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ)))
                    (liftedPoint ((A : ℝ) • u) (B : ℝ)) < 0)) ∧
        (h : ℝ) ≤ (x : ℝ) ∧
        (x : ℝ) ≤ 1 ∧
        u_search (h : ℝ) (x : ℝ) ≤ σ ∧
        q_search (h : ℝ) (x : ℝ) ≤ Q_c c σ + C_q / (L : ℝ)
  ℓ : ℕ
  hℓ_ge1 : 1 ≤ ℓ
  hℓ_bound : 16 / rho_c c ≤ (ℓ : ℝ)
  C_net_nat : ℕ
  C_M_nat : ℕ
  polyFilter_at :
    ∀ {d : ℕ}, 1 ≤ d → ∀ {ι : Type} [DecidableEq ι]
      (gen : SearchGeneration ι (d + 1)),
      h_min ≤ gen.h → gen.h ≤ g_c c →
      ∀ {x η ε₀ : ℝ},
        gen.h ≤ x → x ≤ 1 →
        0 < η → η ≤ 1 →
        0 < ε₀ → ε₀ < 1 →
        ∀ (Q_net : List (EuclideanSpace ℝ (Fin (d + 1)))),
          (∀ z ∈ Q_net, IsUnitVec z) →
          (Q_net.length : ℝ) ≤ Real.exp (6 * (d : ℝ) * Real.log (2 * (d : ℝ) / η)) →
          let L_log : ℕ := Nat.ceil (Real.log (2 * (gen.m : ℝ) / ε₀) + Real.log (2 / η))
          let R : ℕ := R_fn C_net_nat d L_log
          let T : ℕ := T_fn ℓ C_net_nat C_M_nat d L_log
          let p_coord : ℕ := p_coord_fn ℓ C_net_nat C_M_nat d L_log
          let b : ℕ := b_fn ℓ C_net_nat C_M_nat d L_log
          let τ_d : ℚ := τ_d_of ℓ gen.m L_log
          let M₀ : ℕ := M₀_of C_M_nat gen.h x (τ_d : ℝ)
          let cap_u : ℕ := cap_u_of ℓ M₀ (τ_d : ℝ)
          let cap_q : ℕ := cap_q_of ℓ M₀ x (τ_d : ℝ)
          let τ_q : ℚ := τ_q_of b x (τ_d : ℝ)
          1 ≤ R ∧ 1 ≤ M₀ ∧ 1 ≤ cap_u ∧ 1 ≤ cap_q ∧ 1 ≤ b ∧
          ((R * ℓ * M₀ : ℕ) : ℝ) ≤
            (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ)) * poly_cap_fn ℓ C_net_nat C_M_nat d L_log ∧
          (cap_u : ℝ) ≤
            (gen.m : ℝ) ^ (u_search gen.h x) * poly_cap_fn ℓ C_net_nat C_M_nat d L_log ∧
          (cap_q : ℝ) ≤
            (gen.m : ℝ) ^ (q_search gen.h x) * poly_cap_fn ℓ C_net_nat C_M_nat d L_log ∧
          open Classical in
          (1 - ε₀) * (Fintype.card (ExplicitBitSeed R ℓ M₀ (d + 1) b) : ℝ) ≤
            ((Finset.univ.filter (fun ω : ExplicitBitSeed R ℓ M₀ (d + 1) b =>
              IsOrderIndepGoodFilter (polyFDisc T p_coord ω) (τ_d : ℝ) (τ_q : ℝ)
                cap_u cap_q gen Q_net)).card : ℝ)
  C_mc : ℝ
  hC_mc_pos : 0 < C_mc
  mc_at :
    ∀ (α ψ : ℝ), 0 < α → α ≤ 1 → 0 < ψ → ψ < 1 →
      ∃ k : ℕ, 1 ≤ k ∧ k ≤ Nat.ceil (C_mc * α⁻¹ * Real.log (1 / ψ)) ∧
        HasMCBaselineBound α ψ k

theorem exists_curveStaticParams
    (h_lem_9_1 : S_lem_9_1) (h_lem_6_2 : S_lem_6_2) (h_clm_5_1 : S_clm_5_1_mc_baseline)
    {c σ : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2)
    (hσ0 : 0 ≤ σ) (hσ_hi : σ ≤ rho_c c) :
    Nonempty (CurveStaticParams c σ) := by
  obtain ⟨C_shell, C_cfg, C_h, C_q, h_min,
    hCs0, hCc0, hCh0, hCq0, hh_min0, hh_min_le, hlem91⟩ := h_lem_9_1 c hc_gt hc_lt
  have hg1 : g_c c < 1 := (g_c_bounds hc_gt hc_lt).2
  have hrho0 : 0 < rho_c c := (rho_c_bounds hc_gt hc_lt).1
  let ℓ : ℕ := Nat.ceil (16 / rho_c c)
  have hℓ_bound : 16 / rho_c c ≤ (ℓ : ℝ) := Nat.le_ceil _
  have hℓ_ge1 : 1 ≤ ℓ := by
    have hpos : (0 : ℝ) < (ℓ : ℝ) := (div_pos (by norm_num) hrho0).trans_le hℓ_bound
    exact Nat.pos_of_ne_zero (fun h0 => by simp [h0] at hpos)
  have h62 := h_lem_6_2 h_min (g_c c) hh_min0 hh_min_le hg1
  obtain ⟨C_net_nat, C_M_nat, hpf⟩ :=
    polyFilter_goodCoins_card_ge hh_min0 hh_min_le hg1 hℓ_ge1 h62 6 (by norm_num)
  obtain ⟨C_mc, hC_mc_pos, hmc_all⟩ := exists_mcBaselineConstant h_clm_5_1
  exact ⟨{
    hc_gt := hc_gt, hc_lt := hc_lt, hσ0 := hσ0, hσ_hi := hσ_hi
    C_shell := C_shell, C_cfg := C_cfg, C_h := C_h, C_q := C_q, h_min := h_min
    hCs0 := hCs0, hCc0 := hCc0, hCh0 := hCh0, hCq0 := hCq0
    hh_min0 := hh_min0, hh_min_le := hh_min_le
    lem91_at := fun n hn => hlem91 n hn σ hσ0 hσ_hi
    ℓ := ℓ, hℓ_ge1 := hℓ_ge1, hℓ_bound := hℓ_bound
    C_net_nat := C_net_nat, C_M_nat := C_M_nat, polyFilter_at := hpf
    C_mc := C_mc, hC_mc_pos := hC_mc_pos, mc_at := hmc_all
  }⟩

/-! ### 2. `logTerm` & Dyadic Power-of-Two Error Budget Arithmetic -/

noncomputable def logTerm_of (n t : ℕ) (δ : ℝ) : ℕ :=
  Nat.ceil (Real.log (2 * (n : ℝ) * (t : ℝ) / δ))

theorem one_le_logTerm {n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2) :
    1 ≤ logTerm_of n t δ := by
  unfold logTerm_of
  have hn_r : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have ht_r : (1 : ℝ) ≤ (t : ℝ) := by exact_mod_cast ht
  have hgt1 : 1 < 2 * (n : ℝ) * (t : ℝ) / δ := by
    rw [one_lt_div hδ0]
    nlinarith only [hn_r, ht_r, hδ1]
  have hlog_pos : 0 < Real.log (2 * (n : ℝ) * (t : ℝ) / δ) := Real.log_pos hgt1
  exact Nat.ceil_pos.mpr hlog_pos

theorem n_mul_two_zpow_neg_two_logTerm {n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) :
    2 * (n : ℝ) * (t : ℝ) / δ ≤ (2 : ℝ) ^ (2 * logTerm_of n t δ) ∧
    (n : ℝ) * (2 : ℝ) ^ (-(2 * logTerm_of n t δ : ℕ) : ℤ) ≤ δ / (2 * (t : ℝ)) ∧
    (2 : ℝ) ^ (-(2 * logTerm_of n t δ : ℕ) : ℤ) ≤ δ / (4 * (t : ℝ)) := by
  let L := logTerm_of n t δ
  have hn_r : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have ht_r : (1 : ℝ) ≤ (t : ℝ) := by exact_mod_cast ht
  have harg_pos : 0 < 2 * (n : ℝ) * (t : ℝ) / δ := by positivity
  have hlog_le_L : Real.log (2 * (n : ℝ) * (t : ℝ) / δ) ≤ (L : ℝ) := Nat.le_ceil _
  have hlog2_ge : (1 / 2 : ℝ) ≤ Real.log 2 := by linarith [Real.log_two_gt_d9]
  have hL_le_pow : (L : ℝ) ≤ Real.log ((2 : ℝ) ^ (2 * L)) := by
    rw [Real.log_pow]
    push_cast
    nlinarith [Nat.cast_nonneg (α := ℝ) L]
  have hpow_pos : (0 : ℝ) < (2 : ℝ) ^ (2 * L) := by positivity
  have hdiv_le_pow : 2 * (n : ℝ) * (t : ℝ) / δ ≤ (2 : ℝ) ^ (2 * L) :=
    (Real.log_le_log_iff harg_pos hpow_pos).mp (hlog_le_L.trans hL_le_pow)
  have hmul_le : 2 * (n : ℝ) * (t : ℝ) ≤ (2 : ℝ) ^ (2 * L) * δ :=
    (div_le_iff₀ hδ0).mp hdiv_le_pow
  have hzpow_eq : (2 : ℝ) ^ (-(2 * L : ℕ) : ℤ) = ((2 : ℝ) ^ (2 * L))⁻¹ := by
    rw [zpow_neg, zpow_natCast]
  have h1 : (n : ℝ) * (2 : ℝ) ^ (-(2 * L : ℕ) : ℤ) ≤ δ / (2 * (t : ℝ)) := by
    rw [hzpow_eq, le_div_iff₀ (by positivity)]
    rw [show (n : ℝ) * ((2 : ℝ) ^ (2 * L))⁻¹ * (2 * (t : ℝ)) =
        (2 * (n : ℝ) * (t : ℝ)) / (2 : ℝ) ^ (2 * L) by ring]
    rw [div_le_iff₀ hpow_pos]
    linarith only [hmul_le]
  have h2 : (2 : ℝ) ^ (-(2 * L : ℕ) : ℤ) ≤ δ / (4 * (t : ℝ)) := by
    have h2n : 2 * (2 : ℝ) ^ (-(2 * L : ℕ) : ℤ) ≤ (n : ℝ) * (2 : ℝ) ^ (-(2 * L : ℕ) : ℤ) :=
      mul_le_mul_of_nonneg_right hn_r (by positivity)
    have hdiv4 : δ / (2 * (t : ℝ)) = 2 * (δ / (4 * (t : ℝ))) := by ring
    linarith only [h1, h2n, hdiv4]
  exact ⟨hdiv_le_pow, h1, h2⟩

/-- Core dyadic scaling lemma: shifting a negative power of `2` by `Nat.clog 2 (M + 1) + 4`
absorbs `(M : ℝ)` with an extra factor of `1 / 16`. -/
theorem mul_two_zpow_neg_clog_shift (A M : ℕ) {K B : ℝ}
    (hK0 : 0 ≤ K) (hKB : K * (2 : ℝ) ^ (-(A : ℤ)) ≤ B) :
    (M : ℝ) * (K * (2 : ℝ) ^ (-((A + Nat.clog 2 (M + 1) + 4 : ℕ) : ℤ))) ≤ B / 16 := by
  let c := Nat.clog 2 (M + 1)
  have hM_pow : M + 1 ≤ 2 ^ c := Nat.le_pow_clog (by decide) (M + 1)
  have hM_r : (M : ℝ) ≤ (2 : ℝ) ^ c := by
    have h1 : M ≤ 2 ^ c := by omega
    exact_mod_cast h1
  have hzpow_split :
      (2 : ℝ) ^ (-((A + c + 4 : ℕ) : ℤ)) =
        (2 : ℝ) ^ (-(A : ℤ)) * ((2 : ℝ) ^ c)⁻¹ * (1 / 16 : ℝ) := by
    have hsum : (-((A + c + 4 : ℕ) : ℤ)) = (-(A : ℤ)) + (-(c : ℤ)) + (-4 : ℤ) := by push_cast; ring
    rw [hsum, zpow_add₀ (by norm_num), zpow_add₀ (by norm_num), zpow_neg, zpow_natCast]
    norm_num
  change (M : ℝ) * (K * (2 : ℝ) ^ (-((A + c + 4 : ℕ) : ℤ))) ≤ B / 16
  rw [hzpow_split]
  have hMc_le1 : (M : ℝ) * ((2 : ℝ) ^ c)⁻¹ ≤ 1 := by
    rw [← div_eq_mul_inv, div_le_one (by positivity)]
    exact hM_r
  have hKA_nn : 0 ≤ K * (2 : ℝ) ^ (-(A : ℤ)) := mul_nonneg hK0 (by positivity)
  calc (M : ℝ) * (K * ((2 : ℝ) ^ (-(A : ℤ)) * ((2 : ℝ) ^ c)⁻¹ * (1 / 16 : ℝ)))
      = ((M : ℝ) * ((2 : ℝ) ^ c)⁻¹) * (K * (2 : ℝ) ^ (-(A : ℤ))) / 16 := by ring
    _ ≤ (1 * B) / 16 := by
        refine div_le_div_of_nonneg_right ?_ (by norm_num)
        exact mul_le_mul hMc_le1 hKB hKA_nn zero_le_one
    _ = B / 16 := by ring

/-! ### 3. Parameter Pre-Formulas & `LocalScaleParams.e` Bounds -/

def D_max_nat (d n : ℕ) : ℕ :=
  4 * K_alpha d * (Nat.clog 2 (n + 2) + 2)

def B_scan_nat (d n : ℕ) : ℕ :=
  16384 * (D_max_nat d n + 2) ^ 2 * (K_alpha d) ^ 2

def N_op_s1_nat (d n : ℕ) : ℕ :=
  D_max_nat d n + D_max_nat d n * D_max_nat d n + D_max_nat d n

def N_op_s2_nat (d n : ℕ) : ℕ :=
  D_max_nat d n * B_scan_nat d n + (B_scan_nat d n + 1)

theorem params_e_bounds (params : LocalScaleParams) :
    0 < (params.e : ℝ) ∧ (params.e : ℝ) < 1 / 2 ∧ (params.e : ℝ) ≤ 1 ∧
    1 / (params.e : ℝ) ≤ (params.m0 : ℝ) := by
  have he0 : 0 < (params.e : ℝ) := by exact_mod_cast params.e_pos
  have hγ1 : 1 < (params.γ : ℝ) := by exact_mod_cast params.one_lt_γ
  have hκ : (params.γ : ℝ) + 2 * (params.e : ℝ) < params.c := by
    simpa [localScaleKappa] using params.κ_lt_c
  have hsqrt2_lt2 : Real.sqrt 2 < 2 := by
    rw [Real.sqrt_lt' (by norm_num)]
    norm_num
  have hc_lt2 : params.c < 2 := params.c_lt_sqrt_two.trans hsqrt2_lt2
  have he_lt_half : (params.e : ℝ) < 1 / 2 := by linarith only [hγ1, hκ, hc_lt2]
  have hm0_q : (1 : ℚ) / params.e ≤ (params.m0 : ℚ) := by
    unfold LocalScaleParams.m0 shellSubdiv
    exact Nat.le_ceil (1 / params.e)
  have hm0_r : 1 / (params.e : ℝ) ≤ (params.m0 : ℝ) := by exact_mod_cast hm0_q
  exact ⟨he0, he_lt_half, by linarith only [he_lt_half], hm0_r⟩

/-- Dummy unit-vector `SearchGeneration` on `Fin (2 ^ L_p2)` with `m = 2 ^ L_p2`, used to extract
the generation-independent filter parameters and positivity/capacity bounds even when `N_cfg = 0`. -/
noncomputable def dummySearchGen (L_p2 d : ℕ) {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1) :
    SearchGeneration (Fin (2 ^ L_p2)) (d + 1) where
  P₀ := Finset.univ
  pts := fun _ => EuclideanSpace.single (0 : Fin (d + 1)) (1 : ℝ)
  nonempty := ⟨⟨0, Nat.two_pow_pos L_p2⟩, Finset.mem_univ _⟩
  unit_pts := fun _ _ => by simp [IsUnitVec]
  h := h
  h_pos := hh0
  h_lt_one := hh1

@[simp]
theorem dummySearchGen_m (L_p2 d : ℕ) {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1) :
    (dummySearchGen L_p2 d hh0 hh1).m = 2 ^ L_p2 := by
  simp [SearchGeneration.m, dummySearchGen]

@[simp]
theorem dummySearchGen_h (L_p2 d : ℕ) {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1) :
    (dummySearchGen L_p2 d hh0 hh1).h = h := rfl

/-! ### 4. Concrete `ChainParams` Bundle & Instantiation Theorem -/

/-- Bundled concrete `ChainParams` instantiation at `(d, n, t, δ)` together with its auxiliary
exponents `(x_rat, E_phi, E_eps, L_log, ε₀, ψ)`, all hypotheses required by
`goodStepCoins_card_ge`, the `δ_step ≤ δ / t` bound, and structural size bounds for `CG15_ParamsB`. -/
structure ConcreteChainInst {c σ : ℝ} (csp : CurveStaticParams c σ)
    (d n t : ℕ) (δ : ℝ) where
  params : LocalScaleParams
  h_rat : ℚ
  x_rat : ℚ
  cp : ChainParams d params (h_rat : ℝ)
  E_phi : ℕ
  E_eps : ℕ
  L_log : ℕ
  ε₀ : ℝ
  ψ : ℝ
  hc_eq : params.c = c
  hn_eq : cp.n = n
  hT_pow_eq : cp.T_pow = 2 ^ (Nat.clog 2 n)
  hL_p2_eq : cp.L_p2 = Nat.clog 2 (4 * n + 4)
  hℓ_eq : cp.ℓ = csp.ℓ
  hR_eq : cp.R = R_fn csp.C_net_nat d L_log
  hT_cdf_eq : cp.T_cdf = T_fn csp.ℓ csp.C_net_nat csp.C_M_nat d L_log
  hp_coord_eq : cp.p_coord = p_coord_fn csp.ℓ csp.C_net_nat csp.C_M_nat d L_log
  hb_eq : cp.b = b_fn csp.ℓ csp.C_net_nat csp.C_M_nat d L_log
  hN_samp_eq : cp.N_samp = cp.P_hpj.m
  hphi_eq : (cp.phiRat : ℝ) = ((2 : ℝ) ^ E_phi)⁻¹
  hψ_eq : ψ = ((2 : ℝ) ^ E_phi)⁻¹
  hε₀_eq : ε₀ = ((2 : ℝ) ^ E_eps)⁻¹
  hL_log_eq : L_log = Nat.ceil (Real.log (2 * ((2 ^ cp.L_p2 : ℕ) : ℝ) / ε₀) + Real.log (2 / (params.e : ℝ)))
  hE_phi_eq : E_phi = 2 * logTerm_of n t δ + Nat.clog 2 (D_max_nat d n + 2) + 4
  hq_idx_eq : cp.q_idx = 2 * logTerm_of n t δ +
    Nat.clog 2 ((D_max_nat d n + 1) * (cp.N_samp + cp.k_base) + 1) + 4
  hE_eps_eq : E_eps = 2 * logTerm_of n t δ +
    Nat.clog 2 ((N_op_s1_nat d n + N_op_s2_nat d n + B_scan_nat d n + 1) *
      (2 * (cp.N_cfg + 1) * (cp.L_p2 + 1)) + 1) + 4
  hk_base_le : cp.k_base ≤ Nat.ceil (csp.C_mc * (hpjAlpha d)⁻¹ * Real.log (1 / ψ))
  hm0_le : (params.m0 : ℝ) ≤ csp.C_shell * (L_n n : ℝ)
  hmaxShell_le : (params.maxShellIndex : ℝ) ≤ csp.C_shell * (L_n n : ℝ)
  hJ_le : ((params.J + 1 : ℕ) : ℝ) ≤ csp.C_shell * (L_n n : ℝ)
  hN_cfg_le : (cp.N_cfg : ℝ) ≤ csp.C_cfg * (L_n n : ℝ) ^ 3
  he0 : 0 < (params.e : ℝ)
  he1 : (params.e : ℝ) ≤ 1
  hh0 : 0 < (h_rat : ℝ)
  hh1 : (h_rat : ℝ) < 1
  hhx : (h_rat : ℝ) ≤ (x_rat : ℝ)
  hx1 : (x_rat : ℝ) ≤ 1
  hu_le : u_search (h_rat : ℝ) (x_rat : ℝ) ≤ σ
  hq_le : q_search (h_rat : ℝ) (x_rat : ℝ) ≤ Q_c c σ + csp.C_q / (L_n n : ℝ)
  hR_pos : 1 ≤ cp.R
  hb_pos : 1 ≤ cp.b
  hcap_u_pos : 1 ≤ cp.cap_u
  hcap_q_pos : 1 ≤ cp.cap_q
  hRlM_bound :
    ((cp.R * cp.ℓ * cp.M₀ : ℕ) : ℝ) ≤
      ((2 ^ cp.L_p2 : ℕ) : ℝ) ^ (I_h (h_rat : ℝ) (x_rat : ℝ) / (csp.ℓ : ℝ)) *
        poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat d L_log
  hcap_u_bound :
    (cp.cap_u : ℝ) ≤
      ((2 ^ cp.L_p2 : ℕ) : ℝ) ^ (u_search (h_rat : ℝ) (x_rat : ℝ)) *
        poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat d L_log
  hcap_q_bound :
    (cp.cap_q : ℝ) ≤
      ((2 ^ cp.L_p2 : ℕ) : ℝ) ^ (q_search (h_rat : ℝ) (x_rat : ℝ)) *
        poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat d L_log
  hε0 : 0 ≤ ε₀
  hε1 : ε₀ ≤ 1
  hψ0 : 0 < ψ
  hmc : HasMCBaselineBound (hpjAlpha d) ψ cp.k_base
  hjob_err_le1 :
    ((cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))) +
      (cp.B_scan : ℝ) * ((2 * cp.N_cfg * cp.L_p2 : ℝ) * ε₀) ≤ 1
  hδ_base_le1 :
    ψ + ((cp.k_base * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) ≤ 1
  hgen_card :
    ∀ (i : Fin cp.N_cfg) (gen : SearchGeneration (Fin (2 ^ cp.L_p2)) (d + 1)),
      gen.m = 2 ^ cp.L_p2 → gen.h = (h_rat : ℝ) →
      open Classical in
      (1 - ε₀) * (Fintype.card (ExplicitBitSeed cp.R cp.ℓ cp.M₀ (d + 1) cp.b) : ℝ) ≤
        ((Finset.univ.filter (fun ω : ExplicitBitSeed cp.R cp.ℓ cp.M₀ (d + 1) cp.b =>
          IsOrderIndepGoodFilter (polyFDisc cp.T_cdf cp.p_coord ω) (cp.τ_d : ℝ) (cp.τ_q : ℝ)
            cp.cap_u cp.cap_q gen
            (paddedLatNet (M_lat_of d params.e) (cp.specs i).A (cp.specs i).B))).card : ℝ)
  hδ_step_le :
    let δ_op : ℝ := (2 * cp.N_cfg * cp.L_p2 : ℝ) * ε₀
    let δ_ctr : ℝ := (cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
    let δ_base : ℝ := ψ + ((cp.k_base * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
    ((cp.N_op_s1 + cp.N_op_s2 : ℕ) : ℝ) * δ_op +
      ((cp.D_max + 1 : ℕ) : ℝ) * δ_ctr +
      (cp.D_max : ℝ) * δ_base ≤ δ / (t : ℝ)

theorem exists_concreteChainInst {c σ : ℝ} (csp : CurveStaticParams c σ)
    (d n t : ℕ) (δ : ℝ)
    (hd : 1 ≤ d) (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2) :
    Nonempty (ConcreteChainInst csp d n t δ) := by
  classical
  -- Step 1: Extract `params, h_rat, x_rat` as plain free variables
  obtain ⟨params, h_rat, x_rat,
    hc_eq, hm0_le, hmaxShell_le, hJ_le, _, hret_card_le, _, _,
    hh_min_le_h, hh_le_gc, _, hsep_all, hhx, hx1, hu_le, hq_le⟩ := csp.lem91_at n hn
  have hg1 : g_c c < 1 := (g_c_bounds csp.hc_gt csp.hc_lt).2
  have hh0 : 0 < (h_rat : ℝ) := csp.hh_min0.trans_le hh_min_le_h
  have hh1 : (h_rat : ℝ) < 1 := hh_le_gc.trans_lt hg1
  obtain ⟨he0, _, he1, _⟩ := params_e_bounds params

  -- Step 2: Enumerate retained configurations at `V = 1` into plain `fvar`s `(N_cfg, specs)`
  obtain ⟨N_cfg, hN_cfg_le, specs, hspecs_surj⟩ :
      ∃ (N_cfg : ℕ), (N_cfg : ℝ) ≤ csp.C_cfg * (L_n n : ℝ) ^ 3 ∧
        ∃ (specs : Fin N_cfg → ConfigStaticSpec d params (h_rat : ℝ)),
          ∀ cfg ∈ params.retainedConfigs 1, ∃ i : Fin N_cfg, (specs i).cfg = cfg := by
    let cfgList : List ShellConfig := (params.retainedConfigs 1).toList
    have hlen : (cfgList.length : ℝ) ≤ csp.C_cfg * (L_n n : ℝ) ^ 3 := by
      rw [show cfgList.length = (params.retainedConfigs 1).card from Finset.length_toList _]
      exact hret_card_le 1
    have hcfg_specs : ∀ i : Fin cfgList.length, ∃ spec : ConfigStaticSpec d params (h_rat : ℝ),
        spec.cfg = cfgList[i.val]'i.isLt := by
      intro i
      have hmem : cfgList[i.val]'i.isLt ∈ params.retainedConfigs 1 :=
        Finset.mem_toList.mp (List.getElem_mem i.isLt)
      obtain ⟨A, B, _, _, hAB, hsep_d⟩ := hsep_all 1 zero_lt_one _ hmem
      exact ⟨{ cfg := cfgList[i.val]'i.isLt, mem_one := hmem, A := A, B := B,
               hAB := hAB, sep := hsep_d d }, rfl⟩
    choose sp hsp_cfg using hcfg_specs
    refine ⟨cfgList.length, hlen, sp, fun cfg hmem => ?_⟩
    obtain ⟨k, hk, hget⟩ := List.mem_iff_getElem.mp (Finset.mem_toList.mpr hmem)
    exact ⟨⟨k, hk⟩, (hsp_cfg ⟨k, hk⟩).trans hget⟩

  -- Step 3: Bind every parameter via `obtain ⟨X, hX_def⟩ := ⟨_, rfl⟩` (opaque `fvar`s, no `set`!)
  obtain ⟨T_pow, hT_pow_def⟩ : ∃ x : ℕ, x = 2 ^ (Nat.clog 2 n) := ⟨_, rfl⟩
  have hT_pow : n ≤ T_pow := by rw [hT_pow_def]; exact Nat.le_pow_clog (by decide) n

  obtain ⟨L_p2, hL_p2_def⟩ : ∃ x : ℕ, x = Nat.clog 2 (4 * n + 4) := ⟨_, rfl⟩
  have hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2 := by rw [hL_p2_def]; exact Nat.le_pow_clog (by decide) (4 * n + 4)

  obtain ⟨L, hL_def⟩ : ∃ x : ℕ, x = logTerm_of n t δ := ⟨_, rfl⟩
  obtain ⟨_, hn_zpow_raw, h1_zpow_raw⟩ := n_mul_two_zpow_neg_two_logTerm hn ht hδ0
  have hn_zpow : (n : ℝ) * (2 : ℝ) ^ (-(2 * L : ℕ) : ℤ) ≤ δ / (2 * (t : ℝ)) := by
    rwa [hL_def]
  have h1_zpow' : (1 : ℝ) * (2 : ℝ) ^ (-(2 * L : ℕ) : ℤ) ≤ δ / (4 * (t : ℝ)) := by
    rw [one_mul, hL_def]; exact h1_zpow_raw

  obtain ⟨E_phi, hE_phi_def⟩ : ∃ x : ℕ, x = 2 * L + Nat.clog 2 (D_max_nat d n + 2) + 4 := ⟨_, rfl⟩
  have hE_phi_ge4 : 4 ≤ E_phi := by omega
  obtain ⟨phiRat, hphiRat_def⟩ : ∃ x : ℚ, x = ((2 : ℚ) ^ E_phi)⁻¹ := ⟨_, rfl⟩
  have hphi_eq : (phiRat : ℝ) = ((2 : ℝ) ^ E_phi)⁻¹ := by
    rw [hphiRat_def]; push_cast; rfl
  have hφ0 : 0 < (phiRat : ℝ) := by rw [hphi_eq]; positivity
  have hφ_le_16 : (phiRat : ℝ) ≤ 1 / 16 := by
    rw [hphi_eq, inv_le_iff_one_le_mul₀ (by positivity)]
    have hp4 : (2 : ℝ) ^ 4 ≤ (2 : ℝ) ^ E_phi := pow_le_pow_right₀ (by norm_num) hE_phi_ge4
    have h16 : (2 : ℝ) ^ 4 = 16 := by norm_num
    linarith only [hp4, h16]
  have hφ1 : (phiRat : ℝ) < 1 / 2 := by linarith only [hφ_le_16]

  obtain ⟨P_hpj, hP_hpj_def⟩ : ∃ x : HPJParams, x = hpjParams d (phiRat : ℝ) := ⟨_, rfl⟩
  have hP_hpj : HPJParamProps d (phiRat : ℝ) P_hpj := by
    rw [hP_hpj_def]; exact hpjParams_props d hφ0 hφ1

  obtain ⟨N_samp, hN_samp_def⟩ : ∃ x : ℕ, x = P_hpj.m := ⟨_, rfl⟩
  have hmN : 2 ^ P_hpj.q ≤ N_samp := by
    rw [hN_samp_def, hP_hpj.2.2.2.2.2.2.2.1]

  obtain ⟨ψ, hψ_def⟩ : ∃ x : ℝ, x = ((2 : ℝ) ^ E_phi)⁻¹ := ⟨_, rfl⟩
  have hψ0 : 0 < ψ := by rw [hψ_def]; positivity
  have hψ_lt1 : ψ < 1 := by
    have heq : ψ = (phiRat : ℝ) := hψ_def.trans hphi_eq.symm
    linarith only [heq, hφ_le_16]
  obtain ⟨k_base, hk_base, hk_base_le, hmc⟩ :=
    csp.mc_at (hpjAlpha d) ψ (hpjAlpha_pos d) (hpjAlpha_le_one d) hψ0 hψ_lt1

  obtain ⟨M_bias, hM_bias_def⟩ : ∃ x : ℕ, x = (D_max_nat d n + 1) * (N_samp + k_base) := ⟨_, rfl⟩
  obtain ⟨q_idx, hq_idx_def⟩ : ∃ x : ℕ, x = 2 * L + Nat.clog 2 (M_bias + 1) + 4 := ⟨_, rfl⟩

  obtain ⟨M_op, hM_op_def⟩ : ∃ x : ℕ,
      x = (N_op_s1_nat d n + N_op_s2_nat d n + B_scan_nat d n + 1) *
        (2 * (N_cfg + 1) * (L_p2 + 1)) := ⟨_, rfl⟩
  obtain ⟨E_eps, hE_eps_def⟩ : ∃ x : ℕ, x = 2 * L + Nat.clog 2 (M_op + 1) + 4 := ⟨_, rfl⟩
  have hE_eps_ge4 : 4 ≤ E_eps := by omega
  obtain ⟨ε₀, hε₀_def⟩ : ∃ x : ℝ, x = ((2 : ℝ) ^ E_eps)⁻¹ := ⟨_, rfl⟩
  have hε0_pos : 0 < ε₀ := by rw [hε₀_def]; positivity
  have hε_lt1 : ε₀ < 1 := by
    rw [hε₀_def, inv_lt_one_iff₀]
    right
    have hp4 : (2 : ℝ) ^ 4 ≤ (2 : ℝ) ^ E_eps := pow_le_pow_right₀ (by norm_num) hE_eps_ge4
    have h16 : (2 : ℝ) ^ 4 = 16 := by norm_num
    linarith only [hp4, h16]

  -- Step 4: Filter parameters via `polyFilter_at` on `dummySearchGen`
  obtain ⟨L_log, hL_log_def⟩ : ∃ x : ℕ,
      x = Nat.ceil (Real.log (2 * ((2 ^ L_p2 : ℕ) : ℝ) / ε₀) + Real.log (2 / (params.e : ℝ))) := ⟨_, rfl⟩
  obtain ⟨R, hR_def⟩ : ∃ x : ℕ, x = R_fn csp.C_net_nat d L_log := ⟨_, rfl⟩
  obtain ⟨T_cdf, hT_cdf_def⟩ : ∃ x : ℕ, x = T_fn csp.ℓ csp.C_net_nat csp.C_M_nat d L_log := ⟨_, rfl⟩
  obtain ⟨p_coord, hp_coord_def⟩ : ∃ x : ℕ, x = p_coord_fn csp.ℓ csp.C_net_nat csp.C_M_nat d L_log := ⟨_, rfl⟩
  obtain ⟨b, hb_def⟩ : ∃ x : ℕ, x = b_fn csp.ℓ csp.C_net_nat csp.C_M_nat d L_log := ⟨_, rfl⟩
  obtain ⟨τ_d, hτ_d_def⟩ : ∃ x : ℚ, x = τ_d_of csp.ℓ (2 ^ L_p2) L_log := ⟨_, rfl⟩
  obtain ⟨M₀, hM₀_def⟩ : ∃ x : ℕ, x = M₀_of csp.C_M_nat (h_rat : ℝ) (x_rat : ℝ) (τ_d : ℝ) := ⟨_, rfl⟩
  obtain ⟨cap_u, hcap_u_def⟩ : ∃ x : ℕ, x = cap_u_of csp.ℓ M₀ (τ_d : ℝ) := ⟨_, rfl⟩
  obtain ⟨cap_q, hcap_q_def⟩ : ∃ x : ℕ, x = cap_q_of csp.ℓ M₀ (x_rat : ℝ) (τ_d : ℝ) := ⟨_, rfl⟩
  obtain ⟨τ_q, hτ_q_def⟩ : ∃ x : ℚ, x = τ_q_of b (x_rat : ℝ) (τ_d : ℝ) := ⟨_, rfl⟩

  have hd_pf := csp.polyFilter_at hd (dummySearchGen L_p2 d hh0 hh1) hh_min_le_h hh_le_gc
    (x := (x_rat : ℝ)) (η := (params.e : ℝ)) (ε₀ := ε₀)
    hhx hx1 he0 he1 hε0_pos hε_lt1 []
    (fun _ hz => nomatch hz) (by simp [(Real.exp_pos _).le])
  dsimp only at hd_pf
  rw [dummySearchGen_m, dummySearchGen_h] at hd_pf
  rw [← hL_log_def, ← hR_def, ← hT_cdf_def, ← hp_coord_def, ← hb_def,
      ← hτ_d_def, ← hM₀_def, ← hcap_u_def, ← hcap_q_def, ← hτ_q_def] at hd_pf
  obtain ⟨hR_pos, hM₀_pos, hcap_u_pos, hcap_q_pos, hb_pos,
    hRlM_bound, hcap_u_bound, hcap_q_bound, _⟩ := hd_pf

  have hgen_card_raw :
      ∀ (i : Fin N_cfg) (gen : SearchGeneration (Fin (2 ^ L_p2)) (d + 1)),
        gen.m = 2 ^ L_p2 → gen.h = (h_rat : ℝ) →
        ((1 - ε₀) * (Fintype.card (ExplicitBitSeed R csp.ℓ M₀ (d + 1) b) : ℝ) ≤
          ((Finset.univ.filter (fun ω : ExplicitBitSeed R csp.ℓ M₀ (d + 1) b =>
            IsOrderIndepGoodFilter (polyFDisc T_cdf p_coord ω) (τ_d : ℝ) (τ_q : ℝ)
              cap_u cap_q gen
              (paddedLatNet (M_lat_of d params.e) (specs i).A (specs i).B))).card : ℝ)) := by
    intro i gen hgm hgh
    obtain ⟨hQ_unit, hQ_len, _⟩ :=
      concrete_paddedLatNet_spec hd he0 he1 (specs i).hAB
    have hpf_i := csp.polyFilter_at hd gen
      (by rw [hgh]; exact hh_min_le_h) (by rw [hgh]; exact hh_le_gc)
      (x := (x_rat : ℝ)) (η := (params.e : ℝ)) (ε₀ := ε₀)
      (by rw [hgh]; exact hhx) hx1 he0 he1 hε0_pos hε_lt1
      (paddedLatNet (M_lat_of d params.e) (specs i).A (specs i).B)
      hQ_unit hQ_len
    dsimp only at hpf_i
    rw [hgm, hgh, ← hL_log_def, ← hR_def, ← hT_cdf_def, ← hp_coord_def, ← hb_def,
        ← hτ_d_def, ← hM₀_def, ← hcap_u_def, ← hcap_q_def, ← hτ_q_def] at hpf_i
    exact hpf_i.2.2.2.2.2.2.2.2

  -- Step 5: Prove the 5 sub-term error bounds using `linarith only` over pure `fvar`s!
  have ht_r : (1 : ℝ) ≤ (t : ℝ) := by exact_mod_cast ht
  have hδ_div_t_le : δ / (t : ℝ) ≤ 1 / 2 := by
    have hle_δ : δ / (t : ℝ) ≤ δ := div_le_self hδ0.le ht_r
    linarith only [hle_δ, hδ1]

  have hphi_zpow : (phiRat : ℝ) = (1 : ℝ) * (2 : ℝ) ^ (-(E_phi : ℤ)) := by
    rw [hphi_eq, one_mul, zpow_neg, zpow_natCast]
  have hD1_phi : ((D_max_nat d n + 1 : ℕ) : ℝ) * (phiRat : ℝ) ≤ (δ / (4 * (t : ℝ))) / 16 := by
    rw [hphi_zpow, hE_phi_def]
    exact mul_two_zpow_neg_clog_shift (2 * L) (D_max_nat d n + 1) zero_le_one h1_zpow'
  have hD_psi : (D_max_nat d n : ℝ) * ψ ≤ (δ / (4 * (t : ℝ))) / 16 := by
    have hle : (D_max_nat d n : ℝ) ≤ ((D_max_nat d n + 1 : ℕ) : ℝ) := by push_cast; linarith only []
    have hpsi_eq_phi : ψ = (phiRat : ℝ) := hψ_def.trans hphi_eq.symm
    rw [hpsi_eq_phi]
    exact (mul_le_mul_of_nonneg_right hle hφ0.le).trans hD1_phi

  have hM_bias_bound :
      (M_bias : ℝ) * ((n : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) ≤ (δ / (2 * (t : ℝ))) / 16 := by
    rw [hq_idx_def]
    exact mul_two_zpow_neg_clog_shift (2 * L) M_bias (Nat.cast_nonneg n) hn_zpow
  have hbias_ctr :
      ((D_max_nat d n + 1 : ℕ) : ℝ) * (((N_samp * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) ≤
        (δ / (2 * (t : ℝ))) / 16 := by
    have hle_M : (D_max_nat d n + 1) * N_samp ≤ M_bias := by
      rw [hM_bias_def]; exact Nat.mul_le_mul_left _ (Nat.le_add_right _ _)
    have hcast : ((D_max_nat d n + 1 : ℕ) : ℝ) * (N_samp : ℝ) ≤ (M_bias : ℝ) := by
      exact_mod_cast hle_M
    have hrw : ((D_max_nat d n + 1 : ℕ) : ℝ) * (((N_samp * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) =
        (((D_max_nat d n + 1 : ℕ) : ℝ) * (N_samp : ℝ)) * ((n : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) := by
      push_cast; ring
    rw [hrw]
    exact (mul_le_mul_of_nonneg_right hcast (by positivity)).trans hM_bias_bound
  have hbias_base :
      (D_max_nat d n : ℝ) * (((k_base * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) ≤
        (δ / (2 * (t : ℝ))) / 16 := by
    have hle_M : D_max_nat d n * k_base ≤ M_bias := by
      rw [hM_bias_def]
      calc D_max_nat d n * k_base
          ≤ (D_max_nat d n + 1) * k_base := Nat.mul_le_mul_right _ (Nat.le_succ _)
        _ ≤ (D_max_nat d n + 1) * (N_samp + k_base) := Nat.mul_le_mul_left _ (Nat.le_add_left _ _)
    have hcast : (D_max_nat d n : ℝ) * (k_base : ℝ) ≤ (M_bias : ℝ) := by exact_mod_cast hle_M
    have hrw : (D_max_nat d n : ℝ) * (((k_base * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) =
        ((D_max_nat d n : ℝ) * (k_base : ℝ)) * ((n : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) := by
      push_cast; ring
    rw [hrw]
    exact (mul_le_mul_of_nonneg_right hcast (by positivity)).trans hM_bias_bound

  have hM_op_bound :
      (M_op : ℝ) * ((1 : ℝ) * (2 : ℝ) ^ (-(E_eps : ℤ))) ≤ (δ / (4 * (t : ℝ))) / 16 := by
    rw [hE_eps_def]
    exact mul_two_zpow_neg_clog_shift (2 * L) M_op zero_le_one h1_zpow'
  have heps_zpow : ε₀ = (1 : ℝ) * (2 : ℝ) ^ (-(E_eps : ℤ)) := by
    rw [hε₀_def, one_mul, zpow_neg, zpow_natCast]
  have hop_s12 :
      ((N_op_s1_nat d n + N_op_s2_nat d n : ℕ) : ℝ) * ((2 * (N_cfg : ℝ) * (L_p2 : ℝ)) * ε₀) ≤
        (δ / (4 * (t : ℝ))) / 16 := by
    have hle_M : (N_op_s1_nat d n + N_op_s2_nat d n) * (2 * N_cfg * L_p2) ≤ M_op := by
      rw [hM_op_def]
      refine Nat.mul_le_mul (by omega) ?_
      exact Nat.mul_le_mul (Nat.mul_le_mul_left 2 (Nat.le_succ _)) (Nat.le_succ _)
    have hcast : ((N_op_s1_nat d n + N_op_s2_nat d n : ℕ) : ℝ) * (2 * (N_cfg : ℝ) * (L_p2 : ℝ)) ≤
        (M_op : ℝ) := by exact_mod_cast hle_M
    rw [heps_zpow, ← mul_assoc]
    exact (mul_le_mul_of_nonneg_right hcast (by positivity)).trans hM_op_bound
  have hop_Bscan :
      (B_scan_nat d n : ℝ) * ((2 * (N_cfg : ℝ) * (L_p2 : ℝ)) * ε₀) ≤
        (δ / (4 * (t : ℝ))) / 16 := by
    have hle_M : B_scan_nat d n * (2 * N_cfg * L_p2) ≤ M_op := by
      rw [hM_op_def]
      refine Nat.mul_le_mul (by omega) ?_
      exact Nat.mul_le_mul (Nat.mul_le_mul_left 2 (Nat.le_succ _)) (Nat.le_succ _)
    have hcast : (B_scan_nat d n : ℝ) * (2 * (N_cfg : ℝ) * (L_p2 : ℝ)) ≤
        (M_op : ℝ) := by exact_mod_cast hle_M
    rw [heps_zpow, ← mul_assoc]
    exact (mul_le_mul_of_nonneg_right hcast (by positivity)).trans hM_op_bound

  have hD_ge1 : (1 : ℝ) ≤ (D_max_nat d n : ℝ) := by
    have hK := K_alpha_ge_36 d
    have hpos : 1 ≤ D_max_nat d n := by unfold D_max_nat; nlinarith only [hK]
    exact_mod_cast hpos
  have hD1_ge1 : (1 : ℝ) ≤ ((D_max_nat d n + 1 : ℕ) : ℝ) := by push_cast; linarith only [hD_ge1]
  have hphi_single : (phiRat : ℝ) ≤ (δ / (4 * (t : ℝ))) / 16 := by
    have h1 : 1 * (phiRat : ℝ) ≤ ((D_max_nat d n + 1 : ℕ) : ℝ) * (phiRat : ℝ) :=
      mul_le_mul_of_nonneg_right hD1_ge1 hφ0.le
    linarith only [h1, hD1_phi]
  have hpsi_single : ψ ≤ (δ / (4 * (t : ℝ))) / 16 := by
    have h1 : 1 * ψ ≤ (D_max_nat d n : ℝ) * ψ := mul_le_mul_of_nonneg_right hD_ge1 hψ0.le
    linarith only [h1, hD_psi]
  have hbias_ctr_single :
      ((N_samp * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ)) ≤ (δ / (2 * (t : ℝ))) / 16 := by
    have h1 : 1 * (((N_samp * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) ≤
        ((D_max_nat d n + 1 : ℕ) : ℝ) * (((N_samp * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) :=
      mul_le_mul_of_nonneg_right hD1_ge1 (by positivity)
    linarith only [h1, hbias_ctr]
  have hbias_base_single :
      ((k_base * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ)) ≤ (δ / (2 * (t : ℝ))) / 16 := by
    have h1 : 1 * (((k_base * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) ≤
        (D_max_nat d n : ℝ) * (((k_base * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) :=
      mul_le_mul_of_nonneg_right hD_ge1 (by positivity)
    linarith only [h1, hbias_base]

  have hdiv_eq1 : (δ / (4 * (t : ℝ))) / 16 = (1 / 64) * (δ / (t : ℝ)) := by ring
  have hdiv_eq2 : (δ / (2 * (t : ℝ))) / 16 = (1 / 32) * (δ / (t : ℝ)) := by ring
  have hpos_dt : 0 < δ / (t : ℝ) := by positivity

  have hjob_raw :
      ((phiRat : ℝ) + ((N_samp * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) +
        (B_scan_nat d n : ℝ) * ((2 * (N_cfg : ℝ) * (L_p2 : ℝ)) * ε₀) ≤ 1 := by
    linarith only [hphi_single, hbias_ctr_single, hop_Bscan, hδ_div_t_le, hdiv_eq1, hdiv_eq2]

  have hbase_raw :
      ψ + ((k_base * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ)) ≤ 1 := by
    linarith only [hpsi_single, hbias_base_single, hδ_div_t_le, hdiv_eq1, hdiv_eq2]

  have hstep_raw :
      ((N_op_s1_nat d n + N_op_s2_nat d n : ℕ) : ℝ) * ((2 * (N_cfg : ℝ) * (L_p2 : ℝ)) * ε₀) +
        ((D_max_nat d n + 1 : ℕ) : ℝ) *
          ((phiRat : ℝ) + ((N_samp * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) +
        (D_max_nat d n : ℝ) *
          (ψ + ((k_base * n : ℕ) : ℝ) * (2 : ℝ) ^ (-(q_idx : ℤ))) ≤ δ / (t : ℝ) := by
    linarith only [hop_s12, hD1_phi, hbias_ctr, hD_psi, hbias_base, hdiv_eq1, hdiv_eq2, hpos_dt]

  -- Step 6: Assemble `cp` over pure atomic variables (`fvar`s)!
  let cp : ChainParams d params (h_rat : ℝ) :=
    { n := n, hn := hn
      T_pow := T_pow, hT_pow := hT_pow
      L_p2 := L_p2, hL_p2 := hL_p2
      R := R, ℓ := csp.ℓ, M₀ := M₀, hM₀ := hM₀_pos, b := b
      T_cdf := T_cdf, p_coord := p_coord
      τ_d := τ_d, τ_q := τ_q, cap_u := cap_u, cap_q := cap_q
      N_cfg := N_cfg, specs := specs, hspecs_surj := hspecs_surj
      phiRat := phiRat, hφ0 := hφ0, hφ1 := hφ1
      P_hpj := P_hpj, hP_hpj_eq := hP_hpj_def, hP_hpj := hP_hpj
      N_samp := N_samp, hmN := hmN
      q_idx := q_idx, k_base := k_base, hk_base := hk_base }

  have hcp_D : cp.D_max = D_max_nat d n := rfl
  have hcp_B : cp.B_scan = B_scan_nat d n := rfl
  have hcp_s1 : cp.N_op_s1 = N_op_s1_nat d n := rfl
  have hcp_s2 : cp.N_op_s2 = N_op_s2_nat d n := rfl

  exact ⟨{
    params := params, h_rat := h_rat, x_rat := x_rat, cp := cp
    E_phi := E_phi, E_eps := E_eps, L_log := L_log, ε₀ := ε₀, ψ := ψ
    hc_eq := hc_eq, hn_eq := rfl, hT_pow_eq := hT_pow_def, hL_p2_eq := hL_p2_def, hℓ_eq := rfl
    hR_eq := hR_def, hT_cdf_eq := hT_cdf_def, hp_coord_eq := hp_coord_def, hb_eq := hb_def
    hN_samp_eq := hN_samp_def, hphi_eq := hphi_eq, hψ_eq := hψ_def, hε₀_eq := hε₀_def
    hL_log_eq := hL_log_def
    hE_phi_eq := by rw [hE_phi_def, hL_def]
    hq_idx_eq := by dsimp only [cp]; rw [hq_idx_def, hM_bias_def, hL_def]
    hE_eps_eq := by dsimp only [cp]; rw [hE_eps_def, hM_op_def, hL_def]
    hk_base_le := hk_base_le
    hm0_le := hm0_le, hmaxShell_le := hmaxShell_le, hJ_le := hJ_le, hN_cfg_le := hN_cfg_le
    he0 := he0, he1 := he1, hh0 := hh0, hh1 := hh1, hhx := hhx, hx1 := hx1
    hu_le := hu_le, hq_le := hq_le
    hR_pos := hR_pos, hb_pos := hb_pos, hcap_u_pos := hcap_u_pos, hcap_q_pos := hcap_q_pos
    hRlM_bound := hRlM_bound, hcap_u_bound := hcap_u_bound, hcap_q_bound := hcap_q_bound
    hε0 := hε0_pos.le, hε1 := hε_lt1.le, hψ0 := hψ0, hmc := hmc
    hjob_err_le1 := by rw [hcp_B]; exact hjob_raw
    hδ_base_le1 := hbase_raw
    hgen_card := hgen_card_raw
    hδ_step_le := by intro δ_op δ_ctr δ_base; dsimp only [δ_op, δ_ctr, δ_base]; rw [hcp_D, hcp_s1, hcp_s2]; exact hstep_raw
  }⟩

/-- Construct `ConcreteChainInst csp d n t δ` for any `1 ≤ d`, `2 ≤ n`, `1 ≤ t`, `0 < δ < 1/2`
(in particular whenever `min n t > M_cutoff c σ`). -/
noncomputable def mkConcreteChainInst {c σ : ℝ} (csp : CurveStaticParams c σ)
    (d n t : ℕ) (δ : ℝ)
    (hd : 1 ≤ d) (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2) :
    ConcreteChainInst csp d n t δ :=
  Classical.choice (exists_concreteChainInst csp d n t δ hd hn ht hδ0 hδ1)

/-! ### 5. Bad-Coin Count & Good-Coin Lower Bound Combinators for `fixedCoinBridge` -/

/-- Turn `goodStepCoins_card_ge`'s lower bound `(1 - δ_step) * 2^B_STEP ≤ Good.card` and
`inst.hδ_step_le : δ_step ≤ δ / t` directly into BOTH `(1 - δ / t) * 2^B_STEP ≤ Good.card`
(for `ChainEngineProbSpec.good_coins_card_ge`) AND `(¬Good).card ≤ (δ / t) * 2^B_STEP`
(for `fixedCoinBridge`). -/
theorem good_and_bad_stepCoins_bounds {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ)
    (GoodPred : (Fin inst.cp.B_STEP → Bool) → Prop)
    (hgood_lb :
      let δ_op : ℝ := (2 * inst.cp.N_cfg * inst.cp.L_p2 : ℝ) * inst.ε₀
      let δ_ctr : ℝ := (inst.cp.phiRat : ℝ) +
        ((inst.cp.N_samp * inst.cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(inst.cp.q_idx : ℤ))
      let δ_base : ℝ := inst.ψ +
        ((inst.cp.k_base * inst.cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(inst.cp.q_idx : ℤ))
      let δ_step : ℝ :=
        ((inst.cp.N_op_s1 + inst.cp.N_op_s2 : ℕ) : ℝ) * δ_op +
        ((inst.cp.D_max + 1 : ℕ) : ℝ) * δ_ctr +
        (inst.cp.D_max : ℝ) * δ_base
      open Classical in
      (1 - δ_step) * ((2 ^ inst.cp.B_STEP : ℕ) : ℝ) ≤
        ((Finset.univ.filter GoodPred).card : ℝ)) :
    open Classical in
    ((1 - δ / (t : ℝ)) * ((2 ^ inst.cp.B_STEP : ℕ) : ℝ) ≤
      ((Finset.univ.filter GoodPred).card : ℝ)) ∧
    (((Finset.univ.filter (fun bits => ¬ GoodPred bits)).card : ℝ) ≤
      (δ / (t : ℝ)) * ((2 ^ inst.cp.B_STEP : ℕ) : ℝ)) := by
  classical
  have hle_dt := inst.hδ_step_le
  have h1_sub : 1 - δ / (t : ℝ) ≤
      1 - (((inst.cp.N_op_s1 + inst.cp.N_op_s2 : ℕ) : ℝ) *
            ((2 * inst.cp.N_cfg * inst.cp.L_p2 : ℝ) * inst.ε₀) +
          ((inst.cp.D_max + 1 : ℕ) : ℝ) *
            ((inst.cp.phiRat : ℝ) +
              ((inst.cp.N_samp * inst.cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(inst.cp.q_idx : ℤ))) +
          (inst.cp.D_max : ℝ) *
            (inst.ψ + ((inst.cp.k_base * inst.cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(inst.cp.q_idx : ℤ)))) := by
    linarith only [hle_dt]
  have hlb_dt :
      (1 - δ / (t : ℝ)) * ((2 ^ inst.cp.B_STEP : ℕ) : ℝ) ≤
        ((Finset.univ.filter GoodPred).card : ℝ) :=
    (mul_le_mul_of_nonneg_right h1_sub (by positivity)).trans hgood_lb
  have huniv : (Finset.univ : Finset (Fin inst.cp.B_STEP → Bool)).card = 2 ^ inst.cp.B_STEP := by
    rw [Finset.card_univ, Fintype.card_fun, Fintype.card_fin, Fintype.card_bool]
  have hpart_nat :
      (Finset.univ.filter GoodPred).card +
        (Finset.univ.filter (fun bits => ¬ GoodPred bits)).card = 2 ^ inst.cp.B_STEP := by
    rw [Finset.card_filter_add_card_filter_not, huniv]
  have hpart_r :
      ((Finset.univ.filter GoodPred).card : ℝ) +
        ((Finset.univ.filter (fun bits => ¬ GoodPred bits)).card : ℝ) =
        ((2 ^ inst.cp.B_STEP : ℕ) : ℝ) := by
    exact_mod_cast hpart_nat
  refine ⟨hlb_dt, ?_⟩
  linarith only [hlb_dt, hpart_r]

end UL.Proof.clm_9_1_explicit_tradeoff.CG15
