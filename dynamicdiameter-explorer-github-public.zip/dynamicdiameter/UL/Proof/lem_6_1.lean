import UL.Stmt.lem_6_1
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_6_1 : S_lem_6_1 := by
  unfold S_lem_6_1
  intro h hh0 hh1
  have h1h : 0 < 1 - h := by linarith
  have h1ph : 0 < 1 + h := by linarith
  have h1h2 : 0 < 1 - h ^ 2 := by nlinarith
  have h1h2_ne : 1 - h ^ 2 ≠ 0 := h1h2.ne'
  have h1ph_ne : 1 + h ≠ 0 := h1ph.ne'
  set s : ℝ := Real.sqrt (1 - h ^ 2)
  have hs_pos : 0 < s := Real.sqrt_pos.mpr h1h2
  have hs_ne : s ≠ 0 := hs_pos.ne'
  have hs_sq : s ^ 2 = 1 - h ^ 2 := Real.sq_sqrt h1h2.le
  have hu_eq : ∀ x : ℝ, u_search h x = (x - h) ^ 2 / (1 - h ^ 2) := by
    intro x
    unfold u_search I_h
    field_simp
    ring
  have hq_eq : ∀ x : ℝ, q_search h x = (1 - h * x) ^ 2 / (1 - h ^ 2) := by
    intro x
    unfold q_search I_h
    field_simp
    ring
  have hrho_eq : (1 - h) ^ 2 / (1 - h ^ 2) = rho_h h := by
    unfold rho_h
    field_simp
    ring
  have hu_h : u_search h h = 0 := by
    rw [hu_eq]
    simp
  have hu_1 : u_search h 1 = rho_h h := by
    rw [hu_eq, hrho_eq]
  refine ⟨hu_h, hu_1, ?_, ?_⟩
  · ext u
    simp only [Set.mem_image, Set.mem_Icc]
    constructor
    · rintro ⟨x, ⟨hx1, hx2⟩, rfl⟩
      rw [hu_eq, ← hrho_eq]
      constructor
      · positivity
      · have hsq : (x - h) ^ 2 ≤ (1 - h) ^ 2 := by nlinarith
        exact div_le_div_of_nonneg_right hsq h1h2.le
    · rintro ⟨hu0, hu1⟩
      refine ⟨h + Real.sqrt u * s, ⟨?_, ?_⟩, ?_⟩
      · have : 0 ≤ Real.sqrt u * s := by positivity
        linarith
      · have hsqrt_u_sq : (Real.sqrt u) ^ 2 = u := Real.sq_sqrt hu0
        have hprod_nonneg : 0 ≤ Real.sqrt u * s := by positivity
        have hprod_sq : (Real.sqrt u * s) ^ 2 ≤ (1 - h) ^ 2 := by
          calc
            (Real.sqrt u * s) ^ 2 = (Real.sqrt u) ^ 2 * s ^ 2 := by ring
            _ = u * (1 - h ^ 2) := by rw [hsqrt_u_sq, hs_sq]
            _ ≤ rho_h h * (1 - h ^ 2) := mul_le_mul_of_nonneg_right hu1 h1h2.le
            _ = ((1 - h) ^ 2 / (1 - h ^ 2)) * (1 - h ^ 2) := by rw [hrho_eq]
            _ = (1 - h) ^ 2 := div_mul_cancel₀ _ h1h2_ne
        nlinarith
      · have hsqrt_u_sq : (Real.sqrt u) ^ 2 = u := Real.sq_sqrt hu0
        calc
          u_search h (h + Real.sqrt u * s) = (h + Real.sqrt u * s - h) ^ 2 / (1 - h ^ 2) := hu_eq _
          _ = (Real.sqrt u) ^ 2 * s ^ 2 / (1 - h ^ 2) := by ring
          _ = u * (1 - h ^ 2) / (1 - h ^ 2) := by rw [hsqrt_u_sq, hs_sq]
          _ = u := mul_div_cancel_right₀ u h1h2_ne
  · intro x hx1 hx2
    refine ⟨?_, ?_, ?_⟩
    · have hxh_nonneg : 0 ≤ (x - h) / s := div_nonneg (by linarith) hs_pos.le
      have hu_div_sq : u_search h x = ((x - h) / s) ^ 2 := by
        rw [hu_eq, div_pow, hs_sq]
      have hsqrt_u : Real.sqrt (u_search h x) = (x - h) / s := by
        rw [hu_div_sq, Real.sqrt_sq hxh_nonneg]
      have hlin : s - h * ((x - h) / s) = (1 - h * x) / s := by
        have h1 : (s - h * ((x - h) / s)) * s = 1 - h * x := by
          calc
            (s - h * ((x - h) / s)) * s = s ^ 2 - h * ((x - h) / s * s) := by ring
            _ = (1 - h ^ 2) - h * (x - h) := by rw [hs_sq, div_mul_cancel₀ _ hs_ne]
            _ = 1 - h * x := by ring
        exact eq_div_of_mul_eq hs_ne h1
      calc
        q_search h x = (1 - h * x) ^ 2 / (1 - h ^ 2) := hq_eq x
        _ = (1 - h * x) ^ 2 / s ^ 2 := by rw [hs_sq]
        _ = ((1 - h * x) / s) ^ 2 := by rw [div_pow]
        _ = (s - h * ((x - h) / s)) ^ 2 := by rw [hlin]
        _ = q_h h (u_search h x) := by unfold q_h; rw [hsqrt_u]
    · unfold q_search u_search
      ring
    · nlinarith

end UL
