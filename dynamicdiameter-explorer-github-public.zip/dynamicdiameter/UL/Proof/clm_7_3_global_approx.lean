import UL.Stmt.clm_7_3_global_approx
import UL.Stmt.lem_5_1
import UL.Stmt.lem_5_2
import UL.Stmt.lem_5_3
import UL.Stmt.clm_5_3_matching_invariant
import UL.Stmt.lem_5_4
import UL.Stmt.lem_5_5
import UL.Stmt.clm_5_3_global_factor_c
import UL.Stmt.lem_5_6
import UL.Stmt.lem_7_1
import UL.Stmt.claim_C_2_space_reclaim
import UL.Stmt.clm_7_2_chain_schedule
import UL.Proof.clm_7_3_global_approx.H1_Repairs
import UL.Proof.clm_7_3_global_approx.H2_SchedulePoly
import UL.Proof.clm_7_3_global_approx.H3_GlobalChain
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_7_3_global_approx (h_lem_5_1 : S_lem_5_1) (h_lem_5_2 : S_lem_5_2) (h_lem_5_3 : S_lem_5_3) (h_clm_5_3_matching_invariant : S_clm_5_3_matching_invariant) (h_lem_5_4 : S_lem_5_4) (h_lem_5_5 : S_lem_5_5) (h_clm_5_3_global_factor_c : S_clm_5_3_global_factor_c) (h_lem_5_6 : S_lem_5_6) (h_lem_7_1 : S_lem_7_1) (h_claim_C_2_space_reclaim : S_claim_C_2_space_reclaim) (h_clm_7_2_chain_schedule : S_clm_7_2_chain_schedule) : S_clm_7_3_global_approx := by
  exact ⟨UL.Proof_clm_7_3_global_approx.prove_part1 h_clm_5_3_matching_invariant,
    UL.Proof_clm_7_3_global_approx.prove_part2,
    UL.Proof_clm_7_3_global_approx.prove_part3 h_lem_5_5 h_clm_5_3_global_factor_c⟩

end UL
