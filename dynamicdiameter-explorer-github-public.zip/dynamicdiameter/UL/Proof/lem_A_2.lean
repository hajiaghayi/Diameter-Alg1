import UL.Stmt.lem_A_2
import UL.Stmt.cit_hw87_halfspace_net
import UL.Stmt.cit_gls88_rational_lp
import UL.Stmt.lem_A_1
import UL.Proof.lem_A_2.ExactA_Main
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_A_2 (h_cit_hw87_halfspace_net : S_cit_hw87_halfspace_net) (h_cit_gls88_rational_lp : S_cit_gls88_rational_lp) (h_lem_A_1 : S_lem_A_1) : S_lem_A_2 :=
  UL.Proof_lem_A_2.exact_lem_A_2_main h_cit_hw87_halfspace_net h_cit_gls88_rational_lp h_lem_A_1

end UL
