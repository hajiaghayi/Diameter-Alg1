import UL.Stmt.claim_C_2_scans
import UL.Stmt.clm_5_3_matching_invariant
set_option autoImplicit false

namespace UL

open Classical in
theorem empty_satisfiesInvariant {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (cfg : ShellConfig) :
    (LocalMatchingState.empty ι).SatisfiesInvariant pts
      (params.leftVertices pts o V ∅ cfg.j)
      (params.rightVertices pts o V ∅ cfg.k)
      (params.weakEdges pts o V ∅ cfg.j cfg.k cfg.ℓ)
      (params.strongEdges pts o V ∅ cfg.j cfg.k cfg.ℓ) := by
  have hL : params.leftVertices pts o V (∅ : Finset ι) cfg.j = ∅ := by
    simp [LocalScaleParams.leftVertices, configLeftVertices, shellSubset, nodeCore]
  have hR : params.rightVertices pts o V (∅ : Finset ι) cfg.k = ∅ := by
    simp [LocalScaleParams.rightVertices, configRightVertices, shellSubset, nodeEligible]
  have hW : params.weakEdges pts o V (∅ : Finset ι) cfg.j cfg.k cfg.ℓ = ∅ := by
    simp [LocalScaleParams.weakEdges, configWeakEdges, weakEdgesOn,
      configLeftVertices, shellSubset, nodeCore]
  have hS : params.strongEdges pts o V (∅ : Finset ι) cfg.j cfg.k cfg.ℓ = ∅ := by
    simp [LocalScaleParams.strongEdges, configStrongEdges, strongEdgesOn,
      configLeftVertices, shellSubset, nodeCore]
  rw [hL, hR, hW, hS]
  refine ⟨?_, ?_⟩
  · refine ⟨by simp [LocalMatchingState.empty], by simp [LocalMatchingState.empty],
      by intro e he; simp [LocalMatchingState.empty] at he,
      by simp [LocalMatchingState.empty],
      by simp [LocalMatchingState.empty, LocalMatchingState.leftIndexSet, unmatchedLeft],
      by simp [LocalMatchingState.empty],
      by simp [LocalMatchingState.empty, LocalMatchingState.rightIndexSet, unmatchedRight],
      by simp [LocalMatchingState.empty],
      by intro e he; simp [LocalMatchingState.empty] at he,
      by intro e he; simp [LocalMatchingState.empty] at he⟩
  · refine ⟨by simp [LocalMatchingState.empty, LocalMatchingState.matching],
      ⟨by simp [LocalMatchingState.empty, LocalMatchingState.matching],
        by intro x y₁ y₂ h1 _; simp [LocalMatchingState.empty, LocalMatchingState.matching] at h1,
        by intro x₁ x₂ y h1 _; simp [LocalMatchingState.empty, LocalMatchingState.matching] at h1⟩,
      by simp⟩

section ConfigEnumeration

private theorem canonicalShellConfigList_nodup (m0 : ℕ) (K : ℤ) (J : ℕ) :
    (canonicalShellConfigList m0 K J).Nodup := by
  unfold canonicalShellConfigList
  rw [List.nodup_flatMap]
  refine ⟨fun j0 _ => ?_, ?_⟩
  · rw [List.nodup_flatMap]
    refine ⟨fun k0 _ => ?_, ?_⟩
    · refine (List.nodup_range).map ?_
      intro a b h
      cases h
      rfl
    · refine List.nodup_range.pairwise_of_forall_ne ?_
      intro k1 _ k2 _ hne
      dsimp only [Function.onFun]
      rw [List.disjoint_left]
      intro c hc1 hc2
      rcases List.mem_map.mp hc1 with ⟨ℓ1, _, rfl⟩
      rcases List.mem_map.mp hc2 with ⟨ℓ2, _, h_eq⟩
      injection h_eq with _ hk _
      omega
  · refine List.nodup_range.pairwise_of_forall_ne ?_
    intro j1 _ j2 _ hne
    dsimp only [Function.onFun]
    rw [List.disjoint_left]
    intro c hc1 hc2
    rcases List.mem_flatMap.mp hc1 with ⟨k1, _, hc1'⟩
    rcases List.mem_map.mp hc1' with ⟨ℓ1, _, rfl⟩
    rcases List.mem_flatMap.mp hc2 with ⟨k2, _, hc2'⟩
    rcases List.mem_map.mp hc2' with ⟨ℓ2, _, h_eq⟩
    injection h_eq with hj _ _
    omega

private theorem mem_canonicalShellConfigList_iff (m0 : ℕ) (K : ℤ) (J : ℕ) (cfg : ShellConfig) :
    cfg ∈ canonicalShellConfigList m0 K J ↔ cfg ∈ allShellConfigs m0 K J := by
  unfold canonicalShellConfigList allShellConfigs allShellConfigTriples
  simp only [List.mem_flatMap, List.mem_range, List.mem_map, Finset.mem_map,
    Finset.mem_product, Finset.mem_Icc, Function.Embedding.coeFn_mk]
  constructor
  · rintro ⟨j0, hj0, k0, hk0, ℓ, hℓ, rfl⟩
    refine ⟨(j0 + 1, k0 + 1, ℓ), ?_, rfl⟩
    dsimp only
    exact ⟨⟨by omega, by omega⟩, ⟨by omega, by omega⟩, ⟨by omega, by omega⟩⟩
  · rintro ⟨⟨j, k, ℓ⟩, hmem, rfl⟩
    dsimp only at hmem
    rcases hmem with ⟨⟨hj1, hj2⟩, ⟨hk1, hk2⟩, ⟨_, hℓ2⟩⟩
    have hj : j - 1 + 1 = j := by omega
    have hk : k - 1 + 1 = k := by omega
    exact ⟨j - 1, by omega, k - 1, by omega, ℓ, by omega, by simp [hj, hk]⟩

open Classical in
private theorem canonicalShellConfigList_length (m0 : ℕ) (K : ℤ) (J : ℕ) :
    (canonicalShellConfigList m0 K J).length = (allShellConfigs m0 K J).card := by
  have htf : (canonicalShellConfigList m0 K J).toFinset = allShellConfigs m0 K J := by
    ext cfg
    rw [List.mem_toFinset, mem_canonicalShellConfigList_iff]
  rw [← htf, List.toFinset_card_of_nodup (canonicalShellConfigList_nodup m0 K J)]

open Classical in
private theorem mem_retainedConfigs_iff_canonical (params : LocalScaleParams) (V : ℝ)
    (cfg : ShellConfig) :
    cfg ∈ params.retainedConfigs V ↔
      cfg ∈ canonicalShellConfigList params.m0 params.K params.J ∧
      cfg.SatisfiesRetention params.m0 params.γ params.lam V := by
  unfold LocalScaleParams.retainedConfigs retainedConfigs LocalScaleParams.m0 LocalScaleParams.J
  rw [Finset.mem_filter, ← mem_canonicalShellConfigList_iff]

private theorem params_K_nonneg (params : LocalScaleParams) : 0 ≤ params.K := by
  have hc : 0 < params.c - 1 := sub_pos.mpr params.one_lt_c
  have hdiv : 0 < 2 / (params.c - 1) := div_pos (by norm_num) hc
  have hK_pos : (0 : ℝ) < (params.K : ℝ) := lt_of_lt_of_le hdiv params.K_ge
  exact le_of_lt (Int.cast_pos.mp hK_pos)

open Classical in
private theorem isRetainedConfig_of_mem_retainedConfigs (params : LocalScaleParams) (V : ℝ)
    {cfg : ShellConfig} (hcfg : cfg ∈ params.retainedConfigs V) :
    IsRetainedConfig params.e params.γ params.lam params.K V cfg.j cfg.k cfg.ℓ := by
  unfold LocalScaleParams.retainedConfigs retainedConfigs allShellConfigs allShellConfigTriples at hcfg
  rw [Finset.mem_filter, Finset.mem_map] at hcfg
  rcases hcfg with ⟨⟨⟨j, k, ℓ⟩, hmem, heq⟩, hret⟩
  dsimp only [Function.Embedding.coeFn_mk] at heq
  subst heq
  simp only [Finset.mem_product, Finset.mem_Icc] at hmem
  rcases hmem with ⟨⟨hj1, hj2⟩, ⟨hk1, hk2⟩, ⟨_, hℓ2⟩⟩
  refine ⟨⟨hj1, hj2, hk1, ?_, hℓ2⟩, hret⟩
  unfold maxShellIndex at hk2
  have hK0 : 0 ≤ params.K := params_K_nonneg params
  have hcast : ((params.K.toNat * shellSubdiv params.e : ℕ) : ℤ) =
      params.K * (shellSubdiv params.e : ℤ) := by
    rw [Nat.cast_mul, Int.toNat_of_nonneg hK0]
  have hk_z : (k : ℤ) ≤ ((params.K.toNat * shellSubdiv params.e : ℕ) : ℤ) := by
    exact_mod_cast hk2
  rwa [hcast] at hk_z

end ConfigEnumeration

section SingleConfigSearchSteps

open Classical in
private theorem mem_configLeftVertices_iff {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) (j : ℕ) (x : ι) :
    x ∈ configLeftVertices pts m0 o V S j ↔
      x ∈ S ∧ hasApplicableLeftCopy m0 o V j (pts x) := by
  unfold configLeftVertices shellSubset nodeCore hasApplicableLeftCopy
  simp only [Finset.mem_filter, and_assoc]

open Classical in
private theorem mem_configRightVertices_iff {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ) (S : Finset ι) (k : ℕ) (x : ι) :
    x ∈ configRightVertices pts m0 o V K S k ↔
      x ∈ S ∧ hasApplicableRightCopy m0 o V K k (pts x) := by
  unfold configRightVertices shellSubset nodeEligible hasApplicableRightCopy
  simp only [Finset.mem_filter, and_assoc]

open Classical in
private theorem configLeftVertices_subset {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) (j : ℕ) :
    configLeftVertices pts m0 o V S j ⊆ S := by
  intro x hx
  exact ((mem_configLeftVertices_iff pts m0 o V S j x).mp hx).1

open Classical in
private theorem configRightVertices_subset {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ) (S : Finset ι) (k : ℕ) :
    configRightVertices pts m0 o V K S k ⊆ S := by
  intro x hx
  exact ((mem_configRightVertices_iff pts m0 o V K S k x).mp hx).1

open Classical in
private theorem configLeftVertices_erase {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) (p : ι) (j : ℕ) :
    configLeftVertices pts m0 o V (S.erase p) j =
      (configLeftVertices pts m0 o V S j).erase p := by
  ext x
  simp only [mem_configLeftVertices_iff, Finset.mem_erase]
  tauto

open Classical in
private theorem configRightVertices_erase {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ) (S : Finset ι) (p : ι) (k : ℕ) :
    configRightVertices pts m0 o V K (S.erase p) k =
      (configRightVertices pts m0 o V K S k).erase p := by
  ext x
  simp only [mem_configRightVertices_iff, Finset.mem_erase]
  tauto

open Classical in
private theorem attachCopyViaSearch_work {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {n : ℕ} {params : LocalScaleParams} {A_n P_search : ℝ}
    {dynSearch : LocalDynamicSearchInterface d ι IdxState}
    (hSearch : SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    (ball : ChainNode d) (cfg : ShellConfig)
    (st : LocalMatchingState ι) (idx : IdxState) (v : CopyVertex ι) :
    let out := attachCopyViaSearch pts dynSearch ball cfg st idx v
    0 ≤ out.2.2 ∧ out.2.2 ≤ 2 * (A_n * P_search) := by
  dsimp only [attachCopyViaSearch]
  have hq := hSearch.2.2 ball cfg v.side (st.oppositeIndexSet v.side) v.id idx
  rcases hq with ⟨hq0, hqhi, _⟩
  cases h_ans : (dynSearch.queryOpposite ball cfg v.side (st.oppositeIndexSet v.side) v.id idx).1 with
  | none =>
    dsimp only
    have hi := hSearch.1 cfg v.side v.id
      (dynSearch.queryOpposite ball cfg v.side (st.oppositeIndexSet v.side) v.id idx).2.1
    exact ⟨by linarith [hi.1], by linarith [hi.2]⟩
  | some w =>
    dsimp only
    have hd := hSearch.2.1 cfg v.side.opposite w
      (dynSearch.queryOpposite ball cfg v.side (st.oppositeIndexSet v.side) v.id idx).2.1
    exact ⟨by linarith [hd.1], by linarith [hd.2]⟩

open Classical in
private theorem attachCopyViaSearch_valid {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {n : ℕ} {params : LocalScaleParams} {A_n P_search : ℝ}
    {dynSearch : LocalDynamicSearchInterface d ι IdxState}
    (hSearch : SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    {ball : ChainNode d} {cfg : ShellConfig}
    (hV : 0 < ball.V) (hcfg : cfg ∈ params.retainedConfigs ball.V)
    {V_L' V_R' : Finset ι}
    {st : LocalMatchingState ι} (idx : IdxState) {v : CopyVertex ι}
    (hpre : IsAttachPrecond V_L' V_R' st v)
    (hopp_card : (st.oppositeIndexSet v.side).card ≤ n) :
    ValidAttachAngularStep pts ball.o
      (configThresholdA params.m0 params.γ params.lam ball.V cfg.j cfg.k cfg.ℓ)
      (configThresholdB params.m0 params.lam ball.V cfg.j cfg.k cfg.ℓ)
      V_L' V_R' st v (attachCopyViaSearch pts dynSearch ball cfg st idx v).1 := by
  refine ⟨hpre, (dynSearch.queryOpposite ball cfg v.side (st.oppositeIndexSet v.side) v.id idx).1,
    ?_, rfl⟩
  have hq := (hSearch.2.2 ball cfg v.side (st.oppositeIndexSet v.side) v.id idx).2.2
    hV hcfg hopp_card
  exact hq

open Classical in
private theorem not_matched_not_inIndex_of_not_mem_left {d : ℕ} {ι : Type}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ι}
    {st : LocalMatchingState ι} (hwf : st.WellFormed pts V_L V_R)
    {p : ι} (hp : p ∉ V_L) :
    ¬ st.isCopyMatched ⟨.left, p⟩ ∧ ¬ st.isCopyInIndex ⟨.left, p⟩ := by
  rcases hwf with ⟨_, _, hEdges, _, hLeftSet, _, _, _, _, _⟩
  refine ⟨?_, ?_⟩
  · rintro ⟨e, he, rfl⟩
    exact hp (hEdges e he).1
  · rintro ⟨e, he, rfl⟩
    have hmem : e.id ∈ st.leftIndexSet :=
      List.mem_toFinset.mpr (List.mem_map_of_mem he)
    rw [hLeftSet] at hmem
    exact hp (Finset.mem_of_mem_filter e.id hmem)

open Classical in
private theorem not_matched_not_inIndex_of_not_mem_right {d : ℕ} {ι : Type}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ι}
    {st : LocalMatchingState ι} (hwf : st.WellFormed pts V_L V_R)
    {p : ι} (hp : p ∉ V_R) :
    ¬ st.isCopyMatched ⟨.right, p⟩ ∧ ¬ st.isCopyInIndex ⟨.right, p⟩ := by
  rcases hwf with ⟨_, _, hEdges, _, _, _, hRightSet, _, _, _⟩
  refine ⟨?_, ?_⟩
  · rintro ⟨e, he, rfl⟩
    exact hp (hEdges e he).2.1
  · rintro ⟨e, he, rfl⟩
    have hmem : e.id ∈ st.rightIndexSet :=
      List.mem_toFinset.mpr (List.mem_map_of_mem he)
    rw [hRightSet] at hmem
    exact hp (Finset.mem_of_mem_filter e.id hmem)

open Classical in
private theorem insertOriginalViaSearch_spec {d : ℕ} {ι IdxState : Type}
    (h53 : S_clm_5_3_matching_invariant)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {n : ℕ} {params : LocalScaleParams} {A_n P_search : ℝ}
    {dynSearch : LocalDynamicSearchInterface d ι IdxState}
    (hSearch : SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    {ball : ChainNode d} {cfg : ShellConfig}
    (hV : 0 < ball.V) (hcfg : cfg ∈ params.retainedConfigs ball.V)
    {S_cls : Finset ι} {p : ι}
    (hp_not : p ∉ S_cls) (hcard : (insert p S_cls).card ≤ n)
    {st : LocalMatchingState ι} (idx : IdxState)
    (hInv : st.SatisfiesInvariant pts
      (params.leftVertices pts ball.o ball.V S_cls cfg.j)
      (params.rightVertices pts ball.o ball.V S_cls cfg.k)
      (params.weakEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)
      (params.strongEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)) :
    let out := insertOriginalViaSearch pts params dynSearch ball cfg st idx p
    0 ≤ out.2.2 ∧
    out.2.2 ≤ 4 * (A_n * P_search) ∧
    out.1.SatisfiesInvariant pts
      (params.leftVertices pts ball.o ball.V (insert p S_cls) cfg.j)
      (params.rightVertices pts ball.o ball.V (insert p S_cls) cfg.k)
      (params.weakEdges pts ball.o ball.V (insert p S_cls) cfg.j cfg.k cfg.ℓ)
      (params.strongEdges pts ball.o ball.V (insert p S_cls) cfg.j cfg.k cfg.ℓ) := by
  have hret : IsRetainedConfig params.e params.γ params.lam params.K ball.V cfg.j cfg.k cfg.ℓ :=
    isRetainedConfig_of_mem_retainedConfigs params ball.V hcfg
  have hclm := h53 d ι pts ball.o ball.V params.e params.γ params.lam params.K
    cfg.j cfg.k cfg.ℓ hV params.e_pos params.one_lt_γ params.one_lt_lam hret
  rcases hclm with ⟨_, hAttInv, hInsInv, _, _⟩
  set V_L := configLeftVertices pts params.m0 ball.o ball.V S_cls cfg.j
  set V_R := configRightVertices pts params.m0 ball.o ball.V params.K S_cls cfg.k
  set V_L' := configLeftVertices pts params.m0 ball.o ball.V (insert p S_cls) cfg.j
  set V_R' := configRightVertices pts params.m0 ball.o ball.V params.K (insert p S_cls) cfg.k
  set a := configThresholdA params.m0 params.γ params.lam ball.V cfg.j cfg.k cfg.ℓ
  set b := configThresholdB params.m0 params.lam ball.V cfg.j cfg.k cfg.ℓ
  have hp_not_VL : p ∉ V_L := fun hp => hp_not (configLeftVertices_subset _ _ _ _ _ _ hp)
  have hp_not_VR : p ∉ V_R := fun hp => hp_not (configRightVertices_subset _ _ _ _ _ _ _ hp)
  have hVR_sub : V_R ⊆ V_R' := by
    intro x hx
    rw [mem_configRightVertices_iff] at hx ⊢
    exact ⟨Finset.mem_insert_of_mem hx.1, hx.2⟩
  have hVL_erase : V_L'.erase p = V_L := by
    rw [← configLeftVertices_erase, Finset.erase_insert hp_not]
  dsimp only [insertOriginalViaSearch]
  set leftOut :=
    if hasApplicableLeftCopy params.m0 ball.o ball.V cfg.j (pts p) then
      attachCopyViaSearch pts dynSearch ball cfg st idx ⟨.left, p⟩
    else (st, idx, (0 : ℝ))
  have hLeft :
      0 ≤ leftOut.2.2 ∧
      leftOut.2.2 ≤ 2 * (A_n * P_search) ∧
      ((p ∈ V_L' ∧ ValidAttachAngularStep pts ball.o a b V_L' V_R' st ⟨.left, p⟩ leftOut.1) ∨
        (p ∉ V_L' ∧ leftOut.1 = st)) ∧
      leftOut.1.SatisfiesInvariant pts V_L' V_R
        (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ V_L' V_R)
        (strongEdgesOn pts params.m0 params.γ params.lam ball.o ball.V cfg.ℓ V_L' V_R) := by
    by_cases hAppL : hasApplicableLeftCopy params.m0 ball.o ball.V cfg.j (pts p)
    · have hleft_eq : leftOut = attachCopyViaSearch pts dynSearch ball cfg st idx ⟨.left, p⟩ :=
        if_pos hAppL
      rw [hleft_eq]
      rcases attachCopyViaSearch_work pts hSearch ball cfg st idx ⟨.left, p⟩ with ⟨hw0, hwhi⟩
      have hp_in_VL' : p ∈ V_L' :=
        (mem_configLeftVertices_iff _ _ _ _ _ _ p).mpr ⟨Finset.mem_insert_self p S_cls, hAppL⟩
      rcases not_matched_not_inIndex_of_not_mem_left hInv.1 hp_not_VL with ⟨hnm, hni⟩
      have hopp_sub : st.oppositeIndexSet .left ⊆ insert p S_cls := by
        intro x hx
        dsimp only [LocalMatchingState.oppositeIndexSet] at hx
        rw [hInv.1.2.2.2.2.2.2.1] at hx
        exact Finset.mem_insert_of_mem
          (configRightVertices_subset _ _ _ _ _ _ _ (Finset.mem_of_mem_filter x hx))
      have hopp_card : (st.oppositeIndexSet .left).card ≤ n :=
        le_trans (Finset.card_le_card hopp_sub) hcard
      have hValidL' : ValidAttachAngularStep pts ball.o a b V_L' V_R' st ⟨.left, p⟩
          (attachCopyViaSearch pts dynSearch ball cfg st idx ⟨.left, p⟩).1 :=
        attachCopyViaSearch_valid pts hSearch hV hcfg idx ⟨hp_in_VL', hnm, hni⟩ hopp_card
      have hValidL_mid : ValidAttachAngularStep pts ball.o a b V_L' V_R st ⟨.left, p⟩
          (attachCopyViaSearch pts dynSearch ball cfg st idx ⟨.left, p⟩).1 :=
        attachCopyViaSearch_valid pts hSearch hV hcfg idx ⟨hp_in_VL', hnm, hni⟩ hopp_card
      have hInv_mid : (attachCopyViaSearch pts dynSearch ball cfg st idx ⟨.left, p⟩).1.SatisfiesInvariant
          pts V_L' V_R
          (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ V_L' V_R)
          (strongEdgesOn pts params.m0 params.γ params.lam ball.o ball.V cfg.ℓ V_L' V_R) := by
        apply hAttInv (insert p S_cls) V_L' V_R st ⟨.left, p⟩
          (attachCopyViaSearch pts dynSearch ball cfg st idx ⟨.left, p⟩).1
          (Finset.Subset.refl _) hVR_sub _ hValidL_mid
        dsimp only
        rw [if_pos rfl, hVL_erase]
        exact hInv
      exact ⟨hw0, hwhi, Or.inl ⟨hp_in_VL', hValidL'⟩, hInv_mid⟩
    · have hleft_eq : leftOut = (st, idx, (0 : ℝ)) := if_neg hAppL
      rw [hleft_eq]
      have hPs_nonneg : 0 ≤ A_n * P_search := (hSearch.1 cfg .left p idx).1.trans
        (hSearch.1 cfg .left p idx).2
      have hp_notin_VL' : p ∉ V_L' := by
        intro hp_in
        rcases (mem_configLeftVertices_iff _ _ _ _ _ _ p).mp hp_in with ⟨_, hApp⟩
        exact hAppL hApp
      have hVL'_eq : V_L' = V_L := by
        ext x
        simp only [V_L', V_L, mem_configLeftVertices_iff, Finset.mem_insert]
        constructor
        · rintro ⟨rfl | hxS, hxApp⟩
          · exact absurd hxApp hAppL
          · exact ⟨hxS, hxApp⟩
        · rintro ⟨hxS, hxApp⟩
          exact ⟨Or.inr hxS, hxApp⟩
      refine ⟨le_rfl, by linarith, Or.inr ⟨hp_notin_VL', rfl⟩, ?_⟩
      rw [hVL'_eq]
      exact hInv
  rcases hLeft with ⟨hwL0, hwLhi, hStepL, hInvMid⟩
  set rightOut :=
    if hasApplicableRightCopy params.m0 ball.o ball.V params.K cfg.k (pts p) then
      attachCopyViaSearch pts dynSearch ball cfg leftOut.1 leftOut.2.1 ⟨.right, p⟩
    else (leftOut.1, leftOut.2.1, (0 : ℝ))
  have hRight :
      0 ≤ rightOut.2.2 ∧
      rightOut.2.2 ≤ 2 * (A_n * P_search) ∧
      ((p ∈ V_R' ∧ ValidAttachAngularStep pts ball.o a b V_L' V_R' leftOut.1 ⟨.right, p⟩ rightOut.1) ∨
        (p ∉ V_R' ∧ rightOut.1 = leftOut.1)) := by
    by_cases hAppR : hasApplicableRightCopy params.m0 ball.o ball.V params.K cfg.k (pts p)
    · have hright_eq : rightOut =
          attachCopyViaSearch pts dynSearch ball cfg leftOut.1 leftOut.2.1 ⟨.right, p⟩ :=
        if_pos hAppR
      rw [hright_eq]
      rcases attachCopyViaSearch_work pts hSearch ball cfg leftOut.1 leftOut.2.1 ⟨.right, p⟩ with
        ⟨hw0, hwhi⟩
      have hp_in_VR' : p ∈ V_R' :=
        (mem_configRightVertices_iff _ _ _ _ _ _ _ p).mpr ⟨Finset.mem_insert_self p S_cls, hAppR⟩
      rcases not_matched_not_inIndex_of_not_mem_right hInvMid.1 hp_not_VR with ⟨hnm, hni⟩
      have hopp_sub : leftOut.1.oppositeIndexSet .right ⊆ insert p S_cls := by
        intro x hx
        dsimp only [LocalMatchingState.oppositeIndexSet] at hx
        rw [hInvMid.1.2.2.2.2.1] at hx
        exact configLeftVertices_subset _ _ _ _ _ _ (Finset.mem_of_mem_filter x hx)
      have hopp_card : (leftOut.1.oppositeIndexSet .right).card ≤ n :=
        le_trans (Finset.card_le_card hopp_sub) hcard
      have hValidR : ValidAttachAngularStep pts ball.o a b V_L' V_R' leftOut.1 ⟨.right, p⟩
          (attachCopyViaSearch pts dynSearch ball cfg leftOut.1 leftOut.2.1 ⟨.right, p⟩).1 :=
        attachCopyViaSearch_valid pts hSearch hV hcfg leftOut.2.1 ⟨hp_in_VR', hnm, hni⟩ hopp_card
      exact ⟨hw0, hwhi, Or.inl ⟨hp_in_VR', hValidR⟩⟩
    · have hright_eq : rightOut = (leftOut.1, leftOut.2.1, (0 : ℝ)) := if_neg hAppR
      rw [hright_eq]
      have hPs_nonneg : 0 ≤ A_n * P_search := (hSearch.1 cfg .left p idx).1.trans
        (hSearch.1 cfg .left p idx).2
      have hp_notin_VR' : p ∉ V_R' := by
        intro hp_in
        rcases (mem_configRightVertices_iff _ _ _ _ _ _ _ p).mp hp_in with ⟨_, hApp⟩
        exact hAppR hApp
      exact ⟨le_rfl, by linarith, Or.inr ⟨hp_notin_VR', rfl⟩⟩
  rcases hRight with ⟨hwR0, hwRhi, hStepR⟩
  refine ⟨by linarith, by linarith, ?_⟩
  exact hInsInv S_cls p st rightOut.1 hp_not hInv ⟨leftOut.1, hStepL, hStepR⟩

open Classical in
private theorem attachStep_index_subset {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {S_cls : Finset ι} {st : LocalMatchingState ι} {u : CopyVertex ι}
    (hL : st.leftIndexSet ⊆ S_cls) (hR : st.rightIndexSet ⊆ S_cls)
    (hu : u.id ∈ S_cls) (ans : Option ι) :
    (attachStep pts st u ans).leftIndexSet ⊆ S_cls ∧
    (attachStep pts st u ans).rightIndexSet ⊆ S_cls := by
  rcases u with ⟨side, uid⟩
  dsimp only at hu
  cases side <;> cases ans
  · -- left, none
    dsimp only [attachStep, LocalMatchingState.leftIndexSet, LocalMatchingState.rightIndexSet]
    refine ⟨?_, hR⟩
    intro x hx
    rw [List.map_append, List.toFinset_append, Finset.mem_union] at hx
    rcases hx with hxL | hxu
    · exact hL hxL
    · simp only [List.map_cons, List.map_nil, List.toFinset_cons, List.toFinset_nil,
        Finset.insert_empty, Finset.mem_singleton] at hxu
      rwa [hxu]
  · -- left, some w
    dsimp only [attachStep, LocalMatchingState.leftIndexSet, LocalMatchingState.rightIndexSet]
    refine ⟨hL, ?_⟩
    intro x hx
    rcases List.mem_map.mp (List.mem_toFinset.mp hx) with ⟨e, he, rfl⟩
    exact hR (List.mem_toFinset.mpr (List.mem_map_of_mem (List.mem_of_mem_filter he)))
  · -- right, none
    dsimp only [attachStep, LocalMatchingState.leftIndexSet, LocalMatchingState.rightIndexSet]
    refine ⟨hL, ?_⟩
    intro x hx
    rw [List.map_append, List.toFinset_append, Finset.mem_union] at hx
    rcases hx with hxR | hxu
    · exact hR hxR
    · simp only [List.map_cons, List.map_nil, List.toFinset_cons, List.toFinset_nil,
        Finset.insert_empty, Finset.mem_singleton] at hxu
      rwa [hxu]
  · -- right, some w
    dsimp only [attachStep, LocalMatchingState.leftIndexSet, LocalMatchingState.rightIndexSet]
    refine ⟨?_, hR⟩
    intro x hx
    rcases List.mem_map.mp (List.mem_toFinset.mp hx) with ⟨e, he, rfl⟩
    exact hL (List.mem_toFinset.mpr (List.mem_map_of_mem (List.mem_of_mem_filter he)))

open Classical in
private theorem repairPartnersViaSearch_spec {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {n : ℕ} {params : LocalScaleParams} {A_n P_search : ℝ}
    {dynSearch : LocalDynamicSearchInterface d ι IdxState}
    (hSearch : SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    {ball : ChainNode d} {cfg : ShellConfig}
    (hV : 0 < ball.V) (hcfg : cfg ∈ params.retainedConfigs ball.V)
    {S_cls V_L' V_R' : Finset ι}
    (hVL'_sub : V_L' ⊆ S_cls) (hVR'_sub : V_R' ⊆ S_cls)
    (hcard : S_cls.card ≤ n)
    (F : List (CopyVertex ι))
    (hF_act : ∀ u ∈ F, isCopyActive V_L' V_R' u)
    (st : LocalMatchingState ι) (idx : IdxState)
    (hL : st.leftIndexSet ⊆ S_cls) (hR : st.rightIndexSet ⊆ S_cls) :
    let out := repairPartnersViaSearch pts dynSearch ball cfg st idx F
    0 ≤ out.2.2 ∧
    out.2.2 ≤ 2 * (F.length : ℝ) * (A_n * P_search) ∧
    ValidRepairAngularSteps pts ball.o
      (configThresholdA params.m0 params.γ params.lam ball.V cfg.j cfg.k cfg.ℓ)
      (configThresholdB params.m0 params.lam ball.V cfg.j cfg.k cfg.ℓ)
      V_L' V_R' st F out.1 := by
  induction F generalizing st idx with
  | nil =>
    simp [repairPartnersViaSearch, ValidRepairAngularSteps]
  | cons u us ih =>
    dsimp only [repairPartnersViaSearch, ValidRepairAngularSteps]
    have hPs_nonneg : 0 ≤ A_n * P_search := (hSearch.1 cfg .left u.id idx).1.trans
      (hSearch.1 cfg .left u.id idx).2
    by_cases hskip : st.isCopyMatched u ∨ st.isCopyInIndex u
    · rw [if_pos hskip]
      rcases ih (fun v hv => hF_act v (List.mem_cons_of_mem u hv)) st idx hL hR with
        ⟨hw0, hwhi, hrep⟩
      refine ⟨hw0, ?_, Or.inl ⟨hskip, hrep⟩⟩
      simp only [List.length_cons, Nat.cast_add, Nat.cast_one]
      nlinarith
    · rw [if_neg hskip]
      dsimp only
      have hu_act : isCopyActive V_L' V_R' u := hF_act u List.mem_cons_self
      have hu_in_S : u.id ∈ S_cls := by
        cases hs : u.side
        · simp only [isCopyActive, hs] at hu_act
          exact hVL'_sub hu_act
        · simp only [isCopyActive, hs] at hu_act
          exact hVR'_sub hu_act
      have hopp_sub : st.oppositeIndexSet u.side ⊆ S_cls := by
        cases u.side <;> simp [LocalMatchingState.oppositeIndexSet, hL, hR]
      have hopp_card : (st.oppositeIndexSet u.side).card ≤ n :=
        le_trans (Finset.card_le_card hopp_sub) hcard
      have hpre : IsAttachPrecond V_L' V_R' st u := by
        rw [not_or] at hskip
        exact ⟨hu_act, hskip.1, hskip.2⟩
      rcases attachCopyViaSearch_work pts hSearch ball cfg st idx u with ⟨ha0, hahi⟩
      have hvalAtt := attachCopyViaSearch_valid pts hSearch hV hcfg idx hpre hopp_card
      have hsubAtt :
          (attachCopyViaSearch pts dynSearch ball cfg st idx u).1.leftIndexSet ⊆ S_cls ∧
          (attachCopyViaSearch pts dynSearch ball cfg st idx u).1.rightIndexSet ⊆ S_cls :=
        attachStep_index_subset pts hL hR hu_in_S _
      rcases ih (fun v hv => hF_act v (List.mem_cons_of_mem u hv))
          (attachCopyViaSearch pts dynSearch ball cfg st idx u).1
          (attachCopyViaSearch pts dynSearch ball cfg st idx u).2.1
          hsubAtt.1 hsubAtt.2 with
        ⟨hr0, hrhi, hrep⟩
      refine ⟨by linarith, ?_, Or.inr ⟨hskip, _, hvalAtt, hrep⟩⟩
      simp only [List.length_cons, Nat.cast_add, Nat.cast_one]
      nlinarith

open Classical in
private theorem deleteOriginalViaSearch_spec {d : ℕ} {ι IdxState : Type}
    (h53 : S_clm_5_3_matching_invariant)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {n : ℕ} {params : LocalScaleParams} {A_n P_search : ℝ}
    {dynSearch : LocalDynamicSearchInterface d ι IdxState}
    (hSearch : SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    {ball : ChainNode d} {cfg : ShellConfig}
    (hV : 0 < ball.V) (hcfg : cfg ∈ params.retainedConfigs ball.V)
    {S_cls : Finset ι} {p : ι}
    (hp_in : p ∈ S_cls) (hcard : S_cls.card ≤ n)
    {st : LocalMatchingState ι} (idx : IdxState)
    (hInv : st.SatisfiesInvariant pts
      (params.leftVertices pts ball.o ball.V S_cls cfg.j)
      (params.rightVertices pts ball.o ball.V S_cls cfg.k)
      (params.weakEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)
      (params.strongEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)) :
    let out := deleteOriginalViaSearch pts dynSearch ball cfg st idx p
    0 ≤ out.2.2 ∧
    out.2.2 ≤ 6 * (A_n * P_search) ∧
    out.1.SatisfiesInvariant pts
      (params.leftVertices pts ball.o ball.V (S_cls.erase p) cfg.j)
      (params.rightVertices pts ball.o ball.V (S_cls.erase p) cfg.k)
      (params.weakEdges pts ball.o ball.V (S_cls.erase p) cfg.j cfg.k cfg.ℓ)
      (params.strongEdges pts ball.o ball.V (S_cls.erase p) cfg.j cfg.k cfg.ℓ) := by
  have hret : IsRetainedConfig params.e params.γ params.lam params.K ball.V cfg.j cfg.k cfg.ℓ :=
    isRetainedConfig_of_mem_retainedConfigs params ball.V hcfg
  have hclm := h53 d ι pts ball.o ball.V params.e params.γ params.lam params.K
    cfg.j cfg.k cfg.ℓ hV params.e_pos params.one_lt_γ params.one_lt_lam hret
  rcases hclm with ⟨_, _, _, hDelInv, _⟩
  rcases hDelInv S_cls p st hp_in hInv with ⟨_, hFlen, _, hDelStep⟩
  have hPs_nonneg : 0 ≤ A_n * P_search := (hSearch.1 cfg .left p idx).1.trans
    (hSearch.1 cfg .left p idx).2
  dsimp only [deleteOriginalViaSearch]
  set dLeft := if st.isCopyInIndex ⟨.left, p⟩ then dynSearch.deleteUnmatched cfg .left p idx else (idx, 0)
  have hdL : 0 ≤ dLeft.2 ∧ dLeft.2 ≤ A_n * P_search := by
    by_cases hc : st.isCopyInIndex ⟨.left, p⟩
    · simp only [dLeft, hc, ↓reduceIte]
      exact hSearch.2.1 cfg .left p idx
    · simp only [dLeft, hc, ↓reduceIte]
      exact ⟨le_rfl, hPs_nonneg⟩
  set dRight := if st.isCopyInIndex ⟨.right, p⟩ then
      dynSearch.deleteUnmatched cfg .right p dLeft.1 else (dLeft.1, 0)
  have hdR : 0 ≤ dRight.2 ∧ dRight.2 ≤ A_n * P_search := by
    by_cases hc : st.isCopyInIndex ⟨.right, p⟩
    · simp only [dRight, hc, ↓reduceIte]
      exact hSearch.2.1 cfg .right p dLeft.1
    · simp only [dRight, hc, ↓reduceIte]
      exact ⟨le_rfl, hPs_nonneg⟩
  set V_L' := configLeftVertices pts params.m0 ball.o ball.V (S_cls.erase p) cfg.j
  set V_R' := configRightVertices pts params.m0 ball.o ball.V params.K (S_cls.erase p) cfg.k
  have hVL'_sub : V_L' ⊆ S_cls :=
    Finset.Subset.trans (configLeftVertices_subset _ _ _ _ _ _) (Finset.erase_subset p S_cls)
  have hVR'_sub : V_R' ⊆ S_cls :=
    Finset.Subset.trans (configRightVertices_subset _ _ _ _ _ _ _) (Finset.erase_subset p S_cls)
  have hF_act : ∀ u ∈ survivingFormerPartners st p, isCopyActive V_L' V_R' u := by
    intro u hu
    unfold survivingFormerPartners at hu
    rw [List.mem_dedup, List.mem_append] at hu
    rcases hu with huR | huL
    · rcases List.mem_map.mp huR with ⟨e, he, rfl⟩
      rcases List.mem_filter.mp he with ⟨heM, hpred⟩
      simp only [decide_eq_true_eq] at hpred
      dsimp only [isCopyActive, V_R']
      rw [configRightVertices_erase, Finset.mem_erase]
      exact ⟨hpred.2, (hInv.1.2.2.1 e heM).2.1⟩
    · rcases List.mem_map.mp huL with ⟨e, he, rfl⟩
      rcases List.mem_filter.mp he with ⟨heM, hpred⟩
      simp only [decide_eq_true_eq] at hpred
      dsimp only [isCopyActive, V_L']
      rw [configLeftVertices_erase, Finset.mem_erase]
      exact ⟨hpred.2, (hInv.1.2.2.1 e heM).1⟩
  have hRemL : (removeCopiesFromState st p).leftIndexSet ⊆ S_cls := by
    intro x hx
    dsimp only [removeCopiesFromState, LocalMatchingState.leftIndexSet] at hx
    rcases List.mem_map.mp (List.mem_toFinset.mp hx) with ⟨e, he, rfl⟩
    have hx_st : e.id ∈ st.leftIndexSet :=
      List.mem_toFinset.mpr (List.mem_map_of_mem (List.mem_of_mem_filter he))
    rw [hInv.1.2.2.2.2.1] at hx_st
    exact configLeftVertices_subset _ _ _ _ _ _ (Finset.mem_of_mem_filter e.id hx_st)
  have hRemR : (removeCopiesFromState st p).rightIndexSet ⊆ S_cls := by
    intro x hx
    dsimp only [removeCopiesFromState, LocalMatchingState.rightIndexSet] at hx
    rcases List.mem_map.mp (List.mem_toFinset.mp hx) with ⟨e, he, rfl⟩
    have hx_st : e.id ∈ st.rightIndexSet :=
      List.mem_toFinset.mpr (List.mem_map_of_mem (List.mem_of_mem_filter he))
    rw [hInv.1.2.2.2.2.2.2.1] at hx_st
    exact configRightVertices_subset _ _ _ _ _ _ _ (Finset.mem_of_mem_filter e.id hx_st)
  rcases repairPartnersViaSearch_spec pts hSearch hV hcfg hVL'_sub hVR'_sub hcard
      (survivingFormerPartners st p) hF_act (removeCopiesFromState st p) dRight.1 hRemL hRemR with
    ⟨hrep0, hrephi, hrepVal⟩
  have hlen_cast : ((survivingFormerPartners st p).length : ℝ) ≤ 2 := by exact_mod_cast hFlen
  refine ⟨by linarith [hdL.1, hdR.1], by nlinarith [hdL.2, hdR.2], ?_⟩
  exact hDelStep _ ⟨survivingFormerPartners st p, List.Perm.refl _, hrepVal⟩

end SingleConfigSearchSteps

section FoldlAllConfigs

private theorem foldl_configs_spec {ι IdxState : Type}
    [DecidableEq ShellConfig]
    (cond : ShellConfig → Prop) [∀ cfg, Decidable (cond cfg)]
    (step : ShellConfig → LocalMatchingState ι → IdxState → LocalMatchingState ι × IdxState × ℝ)
    (P_before P_after : ShellConfig → LocalMatchingState ι → Prop)
    (A_n P_search c_mult : ℝ)
    (hAn : 0 ≤ A_n) (hPs : 1 ≤ P_search) (hc : 0 ≤ c_mult)
    (L : List ShellConfig) (hNodup : L.Nodup)
    (hStep : ∀ cfg ∈ L, cond cfg → ∀ st idx, P_before cfg st →
      0 ≤ (step cfg st idx).2.2 ∧
      (step cfg st idx).2.2 ≤ c_mult * (A_n * P_search) ∧
      P_after cfg (step cfg st idx).1)
    (states : ShellConfig → LocalMatchingState ι) (idx : IdxState) (w₀ : ℝ)
    (hInit : ∀ cfg ∈ L, cond cfg → P_before cfg (states cfg)) :
    let out := L.foldl
      (fun acc cfg =>
        if cond cfg then
          let sOut := step cfg (acc.1 cfg) acc.2.1
          (Function.update acc.1 cfg sOut.1, sOut.2.1, acc.2.2 + A_n + sOut.2.2)
        else
          (acc.1, acc.2.1, acc.2.2 + A_n))
      (states, idx, w₀)
    w₀ ≤ out.2.2 ∧
    out.2.2 ≤ w₀ + (L.length : ℝ) * ((c_mult + 1) * A_n * P_search) ∧
    (∀ cfg, cfg ∉ L → out.1 cfg = states cfg) ∧
    (∀ cfg ∈ L, cond cfg → P_after cfg (out.1 cfg)) := by
  induction L generalizing states idx w₀ with
  | nil =>
    simp
  | cons hd tl ih =>
    rw [List.nodup_cons] at hNodup
    rcases hNodup with ⟨hhd_notin, htl_nodup⟩
    dsimp only [List.foldl_cons]
    have hAP_ge : A_n ≤ A_n * P_search := le_mul_of_one_le_right hAn hPs
    by_cases hcond : cond hd
    · rw [if_pos hcond]
      rcases hStep hd List.mem_cons_self hcond (states hd) idx (hInit hd List.mem_cons_self hcond) with
        ⟨hs0, hshi, hPafter_hd⟩
      have hInit_tl : ∀ cfg ∈ tl, cond cfg →
          P_before cfg (Function.update states hd (step hd (states hd) idx).1 cfg) := by
        intro cfg hcfg hcc
        have hne : cfg ≠ hd := fun h => hhd_notin (h ▸ hcfg)
        rw [Function.update_of_ne hne]
        exact hInit cfg (List.mem_cons_of_mem hd hcfg) hcc
      rcases ih htl_nodup (fun cfg hcfg => hStep cfg (List.mem_cons_of_mem hd hcfg))
          (Function.update states hd (step hd (states hd) idx).1)
          (step hd (states hd) idx).2.1
          (w₀ + A_n + (step hd (states hd) idx).2.2) hInit_tl with
        ⟨hw0, hwhi, hnot_tl, hP_tl⟩
      refine ⟨by linarith, ?_, ?_, ?_⟩
      · simp only [List.length_cons, Nat.cast_add, Nat.cast_one]
        nlinarith
      · intro cfg hnot
        have hnot1 : cfg ≠ hd := fun h => hnot (h ▸ List.mem_cons_self)
        have hnot2 : cfg ∉ tl := fun h => hnot (List.mem_cons_of_mem hd h)
        rw [hnot_tl cfg hnot2, Function.update_of_ne hnot1]
      · intro cfg hmem hcc
        rcases List.mem_cons.mp hmem with rfl | hmem_tl
        · rw [hnot_tl cfg hhd_notin, Function.update_self]
          exact hPafter_hd
        · exact hP_tl cfg hmem_tl hcc
    · rw [if_neg hcond]
      rcases ih htl_nodup (fun cfg hcfg => hStep cfg (List.mem_cons_of_mem hd hcfg))
          states idx (w₀ + A_n) (fun cfg hcfg => hInit cfg (List.mem_cons_of_mem hd hcfg)) with
        ⟨hw0, hwhi, hnot_tl, hP_tl⟩
      refine ⟨by linarith, ?_, ?_, ?_⟩
      · simp only [List.length_cons, Nat.cast_add, Nat.cast_one]
        nlinarith
      · intro cfg hnot
        exact hnot_tl cfg (fun h => hnot (List.mem_cons_of_mem hd h))
      · intro cfg hmem hcc
        rcases List.mem_cons.mp hmem with rfl | hmem_tl
        · exact absurd hcc hcond
        · exact hP_tl cfg hmem_tl hcc

open Classical in
theorem insertAllRetainedConfigs_spec {d : ℕ} {ι IdxState : Type}
    (h53 : S_clm_5_3_matching_invariant)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (n : ℕ) (params : LocalScaleParams) (A_n P_search P_loc : ℝ)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (S_cls : Finset ι) (p : ι)
    (states : ShellConfig → LocalMatchingState ι) (idx : IdxState)
    (hAn : 1 ≤ A_n)
    (hPloc : ValidNodeWorkFactor n (some params) P_search P_loc)
    (hSearch : SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    (hp_not : p ∉ S_cls)
    (hcard : (insert p S_cls).card ≤ n)
    (hInv : 0 < ball.V → ∀ cfg ∈ params.retainedConfigs ball.V,
      (states cfg).SatisfiesInvariant pts
        (params.leftVertices pts ball.o ball.V S_cls cfg.j)
        (params.rightVertices pts ball.o ball.V S_cls cfg.k)
        (params.weakEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)
        (params.strongEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)) :
    let out := insertAllRetainedConfigs pts params A_n dynSearch ball p states idx
    0 ≤ out.2.2 ∧
    out.2.2 ≤ 5 * A_n * P_loc ∧
    (0 < ball.V → ∀ cfg ∈ params.retainedConfigs ball.V,
      (out.1 cfg).SatisfiesInvariant pts
        (params.leftVertices pts ball.o ball.V (insert p S_cls) cfg.j)
        (params.rightVertices pts ball.o ball.V (insert p S_cls) cfg.k)
        (params.weakEdges pts ball.o ball.V (insert p S_cls) cfg.j cfg.k cfg.ℓ)
        (params.strongEdges pts ball.o ball.V (insert p S_cls) cfg.j cfg.k cfg.ℓ)) := by
  unfold ValidNodeWorkFactor at hPloc
  rcases hPloc with ⟨hPs1, hPloc_bound⟩
  dsimp only at hPloc_bound
  have hlog0 : 0 ≤ Real.log (n : ℝ) := by
    by_cases hn1 : 1 ≤ n
    · exact Real.log_nonneg (by exact_mod_cast hn1)
    · have hn0 : n = 0 := by omega
      subst hn0
      simp
  unfold insertAllRetainedConfigs
  let P_before : ShellConfig → LocalMatchingState ι → Prop := fun cfg st =>
    st.SatisfiesInvariant pts
      (params.leftVertices pts ball.o ball.V S_cls cfg.j)
      (params.rightVertices pts ball.o ball.V S_cls cfg.k)
      (params.weakEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)
      (params.strongEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)
  let P_after : ShellConfig → LocalMatchingState ι → Prop := fun cfg st =>
    st.SatisfiesInvariant pts
      (params.leftVertices pts ball.o ball.V (insert p S_cls) cfg.j)
      (params.rightVertices pts ball.o ball.V (insert p S_cls) cfg.k)
      (params.weakEdges pts ball.o ball.V (insert p S_cls) cfg.j cfg.k cfg.ℓ)
      (params.strongEdges pts ball.o ball.V (insert p S_cls) cfg.j cfg.k cfg.ℓ)
  have hStep : ∀ cfg ∈ canonicalShellConfigList params.m0 params.K params.J,
      (0 < ball.V ∧ cfg.SatisfiesRetention params.m0 params.γ params.lam ball.V) →
      ∀ st curIdx, P_before cfg st →
        0 ≤ (insertOriginalViaSearch pts params dynSearch ball cfg st curIdx p).2.2 ∧
        (insertOriginalViaSearch pts params dynSearch ball cfg st curIdx p).2.2 ≤
          4 * (A_n * P_search) ∧
        P_after cfg (insertOriginalViaSearch pts params dynSearch ball cfg st curIdx p).1 := by
    intro cfg hmem hcc st curIdx hPb
    have hcfg_ret : cfg ∈ params.retainedConfigs ball.V :=
      (mem_retainedConfigs_iff_canonical params ball.V cfg).mpr ⟨hmem, hcc.2⟩
    exact insertOriginalViaSearch_spec h53 pts hSearch hcc.1 hcfg_ret hp_not hcard curIdx hPb
  have hInit : ∀ cfg ∈ canonicalShellConfigList params.m0 params.K params.J,
      (0 < ball.V ∧ cfg.SatisfiesRetention params.m0 params.γ params.lam ball.V) →
      P_before cfg (states cfg) := by
    intro cfg hmem hcc
    exact hInv hcc.1 cfg ((mem_retainedConfigs_iff_canonical params ball.V cfg).mpr ⟨hmem, hcc.2⟩)
  rcases foldl_configs_spec
      (fun cfg => 0 < ball.V ∧ cfg.SatisfiesRetention params.m0 params.γ params.lam ball.V)
      (fun cfg st curIdx => insertOriginalViaSearch pts params dynSearch ball cfg st curIdx p)
      P_before P_after A_n P_search 4 (by linarith) hPs1 (by norm_num)
      (canonicalShellConfigList params.m0 params.K params.J)
      (canonicalShellConfigList_nodup params.m0 params.K params.J)
      hStep states idx 0 hInit with
    ⟨hw0, hwhi, _, hP_out⟩
  have hlen : ((canonicalShellConfigList params.m0 params.K params.J).length : ℝ) ≤
      (((allShellConfigs params.m0 params.K params.J).card + 1 : ℕ) : ℝ) := by
    rw [canonicalShellConfigList_length]
    exact_mod_cast Nat.le_succ _
  have hLP : ((canonicalShellConfigList params.m0 params.K params.J).length : ℝ) * P_search ≤ P_loc := by
    nlinarith
  refine ⟨hw0, ?_, ?_⟩
  · have hmul : ((canonicalShellConfigList params.m0 params.K params.J).length : ℝ) *
        ((4 + 1) * A_n * P_search) =
        5 * A_n * (((canonicalShellConfigList params.m0 params.K params.J).length : ℝ) * P_search) := by
      ring
    rw [hmul] at hwhi
    nlinarith
  · intro hV cfg hcfg
    rcases (mem_retainedConfigs_iff_canonical params ball.V cfg).mp hcfg with ⟨hmem, hret⟩
    exact hP_out cfg hmem ⟨hV, hret⟩

open Classical in
theorem deleteAllRetainedConfigs_spec {d : ℕ} {ι IdxState : Type}
    (h53 : S_clm_5_3_matching_invariant)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (n : ℕ) (params : LocalScaleParams) (A_n P_search P_loc : ℝ)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (S_cls : Finset ι) (p : ι)
    (states : ShellConfig → LocalMatchingState ι) (idx : IdxState)
    (hAn : 1 ≤ A_n)
    (hPloc : ValidNodeWorkFactor n (some params) P_search P_loc)
    (hSearch : SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    (hp_in : p ∈ S_cls)
    (hcard : S_cls.card ≤ n)
    (hInv : 0 < ball.V → ∀ cfg ∈ params.retainedConfigs ball.V,
      (states cfg).SatisfiesInvariant pts
        (params.leftVertices pts ball.o ball.V S_cls cfg.j)
        (params.rightVertices pts ball.o ball.V S_cls cfg.k)
        (params.weakEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)
        (params.strongEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)) :
    let out := deleteAllRetainedConfigs pts params A_n dynSearch ball p states idx
    0 ≤ out.2.2 ∧
    out.2.2 ≤ 7 * A_n * P_loc ∧
    (0 < ball.V → ∀ cfg ∈ params.retainedConfigs ball.V,
      (out.1 cfg).SatisfiesInvariant pts
        (params.leftVertices pts ball.o ball.V (S_cls.erase p) cfg.j)
        (params.rightVertices pts ball.o ball.V (S_cls.erase p) cfg.k)
        (params.weakEdges pts ball.o ball.V (S_cls.erase p) cfg.j cfg.k cfg.ℓ)
        (params.strongEdges pts ball.o ball.V (S_cls.erase p) cfg.j cfg.k cfg.ℓ)) := by
  unfold ValidNodeWorkFactor at hPloc
  rcases hPloc with ⟨hPs1, hPloc_bound⟩
  dsimp only at hPloc_bound
  have hlog0 : 0 ≤ Real.log (n : ℝ) := by
    by_cases hn1 : 1 ≤ n
    · exact Real.log_nonneg (by exact_mod_cast hn1)
    · have hn0 : n = 0 := by omega
      subst hn0
      simp
  unfold deleteAllRetainedConfigs
  let P_before : ShellConfig → LocalMatchingState ι → Prop := fun cfg st =>
    st.SatisfiesInvariant pts
      (params.leftVertices pts ball.o ball.V S_cls cfg.j)
      (params.rightVertices pts ball.o ball.V S_cls cfg.k)
      (params.weakEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)
      (params.strongEdges pts ball.o ball.V S_cls cfg.j cfg.k cfg.ℓ)
  let P_after : ShellConfig → LocalMatchingState ι → Prop := fun cfg st =>
    st.SatisfiesInvariant pts
      (params.leftVertices pts ball.o ball.V (S_cls.erase p) cfg.j)
      (params.rightVertices pts ball.o ball.V (S_cls.erase p) cfg.k)
      (params.weakEdges pts ball.o ball.V (S_cls.erase p) cfg.j cfg.k cfg.ℓ)
      (params.strongEdges pts ball.o ball.V (S_cls.erase p) cfg.j cfg.k cfg.ℓ)
  have hStep : ∀ cfg ∈ canonicalShellConfigList params.m0 params.K params.J,
      (0 < ball.V ∧ cfg.SatisfiesRetention params.m0 params.γ params.lam ball.V) →
      ∀ st curIdx, P_before cfg st →
        0 ≤ (deleteOriginalViaSearch pts dynSearch ball cfg st curIdx p).2.2 ∧
        (deleteOriginalViaSearch pts dynSearch ball cfg st curIdx p).2.2 ≤
          6 * (A_n * P_search) ∧
        P_after cfg (deleteOriginalViaSearch pts dynSearch ball cfg st curIdx p).1 := by
    intro cfg hmem hcc st curIdx hPb
    have hcfg_ret : cfg ∈ params.retainedConfigs ball.V :=
      (mem_retainedConfigs_iff_canonical params ball.V cfg).mpr ⟨hmem, hcc.2⟩
    exact deleteOriginalViaSearch_spec h53 pts hSearch hcc.1 hcfg_ret hp_in hcard curIdx hPb
  have hInit : ∀ cfg ∈ canonicalShellConfigList params.m0 params.K params.J,
      (0 < ball.V ∧ cfg.SatisfiesRetention params.m0 params.γ params.lam ball.V) →
      P_before cfg (states cfg) := by
    intro cfg hmem hcc
    exact hInv hcc.1 cfg ((mem_retainedConfigs_iff_canonical params ball.V cfg).mpr ⟨hmem, hcc.2⟩)
  rcases foldl_configs_spec
      (fun cfg => 0 < ball.V ∧ cfg.SatisfiesRetention params.m0 params.γ params.lam ball.V)
      (fun cfg st curIdx => deleteOriginalViaSearch pts dynSearch ball cfg st curIdx p)
      P_before P_after A_n P_search 6 (by linarith) hPs1 (by norm_num)
      (canonicalShellConfigList params.m0 params.K params.J)
      (canonicalShellConfigList_nodup params.m0 params.K params.J)
      hStep states idx 0 hInit with
    ⟨hw0, hwhi, _, hP_out⟩
  have hlen : ((canonicalShellConfigList params.m0 params.K params.J).length : ℝ) ≤
      (((allShellConfigs params.m0 params.K params.J).card + 1 : ℕ) : ℝ) := by
    rw [canonicalShellConfigList_length]
    exact_mod_cast Nat.le_succ _
  have hLP : ((canonicalShellConfigList params.m0 params.K params.J).length : ℝ) * P_search ≤ P_loc := by
    nlinarith
  refine ⟨hw0, ?_, ?_⟩
  · have hmul : ((canonicalShellConfigList params.m0 params.K params.J).length : ℝ) *
        ((6 + 1) * A_n * P_search) =
        7 * A_n * (((canonicalShellConfigList params.m0 params.K params.J).length : ℝ) * P_search) := by
      ring
    rw [hmul] at hwhi
    nlinarith
  · intro hV cfg hcfg
    rcases (mem_retainedConfigs_iff_canonical params ball.V cfg).mp hcfg with ⟨hmem, hret⟩
    exact hP_out cfg hmem ⟨hV, hret⟩

end FoldlAllConfigs

end UL
