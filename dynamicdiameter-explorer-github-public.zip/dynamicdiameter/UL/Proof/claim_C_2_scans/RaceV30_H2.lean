import UL.Proof.claim_C_2_scans.RaceV30_H2b
set_option autoImplicit false

namespace UL.C2ScansRaceV30
open UL

/-! ### 1. Greedy per-tick background step runner -/

open Classical in
noncomputable def runTickSteps {d : ℕ} {ι IdxState : Type}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (n m : ℕ) (A_n : ℝ) (prov : ChainNode d)
    (optParams : Option LocalScaleParams)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState) :
    ℕ → ℝ → TwoScanLevelState d ι IdxState → TwoScanLevelState d ι IdxState × ℕ
  | 0, _, st => (st, 0)
  | k + 1, remBudget, st =>
      match nextBgStep α pts n m A_n prov optParams dynSearch st with
      | none => (st, 0)
      | some st' =>
          let stepCost := st'.cumWork - st.cumWork
          if stepCost ≤ remBudget then
            let res := runTickSteps α pts n m A_n prov optParams dynSearch k
              (remBudget - stepCost) st'
            (res.1, res.2 + 1)
          else
            (st, 0)

open Classical in
private theorem runTickSteps_spec {d : ℕ} {ι IdxState : Type}
    (h53 : S_clm_5_3_matching_invariant)
    {α : ℝ} (pts : ι → EuclideanSpace ℝ (Fin d))
    {n : ℕ} {A_n P_search P_loc : ℝ}
    {optParams : Option LocalScaleParams}
    {dynSearch : LocalDynamicSearchInterface d ι IdxState}
    {birthSnapshotList : List (ι × ℕ)} {S_birth S_cur : Finset ι}
    {initNextLife : ℕ} {prov : ChainNode d}
    (hn : 2 ≤ n) (hAn : 1 ≤ A_n)
    (hPloc : ValidNodeWorkFactor n optParams P_search P_loc)
    (hSearch : ∀ params : LocalScaleParams, optParams = some params →
      SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    (hNodup : birthSnapshotList.Nodup)
    (hBirthPool : IsValidLifetimePool S_birth birthSnapshotList.toFinset initNextLife)
    (hBirthNonempty : S_birth.Nonempty)
    (hCapCur : S_cur.card ≤ n)
    (insCount k : ℕ) (remBudget : ℝ) (st : TwoScanLevelState d ι IdxState)
    (hBud : 0 ≤ remBudget)
    (hInv : LevelInv α pts optParams birthSnapshotList S_birth prov S_cur insCount st) :
    let out := runTickSteps α pts n S_birth.card A_n prov optParams dynSearch k remBudget st
    TwoScanBgChain α pts n S_birth.card A_n prov optParams dynSearch st out.1 ∧
    LevelInv α pts optParams birthSnapshotList S_birth prov S_cur insCount out.1 ∧
    0 ≤ out.1.cumWork - st.cumWork ∧
    out.1.cumWork - st.cumWork ≤ remBudget ∧
    out.1.cumWork - st.cumWork ≤ (out.2 : ℝ) * (6 * A_n * P_loc) ∧
    (∀ M2 : ℕ, S_birth.card + insCount ≤ M2 →
      remBgSteps M2 out.1.phase + out.2 ≤ remBgSteps M2 st.phase) ∧
    (∀ ball : ChainNode d, st.phase = .ready ball → out.1.phase = .ready ball) ∧
    (remBgSteps (S_birth.card + insCount) st.phase ≤ k →
      out.1.phase = .ready (applyBirthCoreFallback α pts S_birth prov) ∨
      remBudget < ((out.2 + 1 : ℕ) : ℝ) * (6 * A_n * P_loc)) := by
  induction k generalizing remBudget st with
  | zero =>
    dsimp only [runTickSteps]
    refine ⟨TwoScanBgChain.refl st, hInv, by linarith, by linarith, by simp,
      fun _ _ => by omega, fun _ h => h, ?_⟩
    intro hRem0
    apply Or.inl
    apply nextBgStep_none_iff_ready pts hInv (n := n) (A_n := A_n) (dynSearch := dynSearch)
    cases hPh : st.phase with
    | scan1 rem _ _ =>
      rw [hPh] at hRem0
      dsimp only [remBgSteps] at hRem0
      omega
    | scan2 _ _ rem =>
      rw [hPh] at hRem0
      dsimp only [remBgSteps] at hRem0
      omega
    | ready ball =>
      unfold nextBgStep
      simp [hPh]
  | succ k ih =>
    unfold runTickSteps
    cases hNext : nextBgStep α pts n S_birth.card A_n prov optParams dynSearch st with
    | none =>
      dsimp only
      have hReady := nextBgStep_none_iff_ready pts hInv hNext
      refine ⟨TwoScanBgChain.refl st, hInv, by linarith, by linarith, by simp,
        fun _ _ => by omega, fun _ h => h, fun _ => Or.inl hReady⟩
    | some st' =>
      dsimp only
      rcases nextBgStep_some_spec h53 pts hn hAn hPloc hSearch hNodup hBirthPool
          hBirthNonempty hCapCur hInv hNext with
        ⟨hStep, hInv', hCost0, hCostHi, hRemDec⟩
      by_cases hFit : st'.cumWork - st.cumWork ≤ remBudget
      · rw [if_pos hFit]
        dsimp only
        rcases ih (remBudget - (st'.cumWork - st.cumWork)) st' (by linarith) hInv' with
          ⟨hChain', hInvOut, hOut0, hOutBud, hOutCnt, hOutRem, hOutReady, hOutProg⟩
        refine ⟨TwoScanBgChain.step hStep hChain', hInvOut, by linarith, by linarith, ?_, ?_, ?_, ?_⟩
        · rw [Nat.cast_add, Nat.cast_one, add_one_mul]
          linarith
        · intro M2 hM2
          have h1 := hRemDec M2 hM2
          have h2 := hOutRem M2 hM2
          omega
        · intro ball hPhReady
          unfold nextBgStep at hNext
          rw [hPhReady] at hNext
          simp at hNext
        · intro hRemLe
          have hRemLe' : remBgSteps (S_birth.card + insCount) st'.phase ≤ k := by
            have h1 := hRemDec (S_birth.card + insCount) le_rfl
            omega
          rcases hOutProg hRemLe' with hDone | hShort
          · exact Or.inl hDone
          · apply Or.inr
            rw [Nat.cast_add, Nat.cast_one, add_one_mul] at hShort ⊢
            rw [Nat.cast_add, Nat.cast_one, add_one_mul]
            linarith
      · rw [if_neg hFit]
        dsimp only
        refine ⟨TwoScanBgChain.refl st, hInv, by linarith, by linarith, by simp,
          fun _ _ => by omega, fun _ h => h, ?_⟩
        intro _
        apply Or.inr
        simp only [Nat.zero_add, Nat.cast_one, one_mul]
        linarith

/-! ### 2. Prefix root-tick counting and residual drift -/

private def ticksUpTo {T : ℕ} (rootTick : Fin T → Bool) (s : ℕ) : ℕ :=
  (((List.ofFn rootTick).take s).filter (fun b => b = true)).length

private theorem ofFn_take_succ {T : ℕ} (rootTick : Fin T → Bool) {s : ℕ} (hs : s < T) :
    (List.ofFn rootTick).take (s + 1) = (List.ofFn rootTick).take s ++ [rootTick ⟨s, hs⟩] := by
  apply List.ext_getElem
  · simp [Nat.succ_le_of_lt hs, Nat.le_of_lt hs]
  · intro i hi1 hi2
    rw [List.getElem_take, List.getElem_ofFn]
    by_cases his : i < s
    · rw [List.getElem_append_left (by simp [Nat.le_of_lt hs, his]),
        List.getElem_take, List.getElem_ofFn]
    · have hieq : i = s := by
        simp [Nat.succ_le_of_lt hs] at hi1
        omega
      subst hieq
      rw [List.getElem_append_right (by simp [Nat.le_of_lt hs])]
      simp [Nat.le_of_lt hs]

private theorem ticksUpTo_zero {T : ℕ} (rootTick : Fin T → Bool) :
    ticksUpTo rootTick 0 = 0 := by
  simp [ticksUpTo]

private theorem ticksUpTo_succ {T : ℕ} (rootTick : Fin T → Bool) {s : ℕ} (hs : s < T) :
    ticksUpTo rootTick (s + 1) =
      ticksUpTo rootTick s + (if rootTick ⟨s, hs⟩ = true then 1 else 0) := by
  unfold ticksUpTo
  rw [ofFn_take_succ rootTick hs, List.filter_append, List.length_append]
  cases h : rootTick ⟨s, hs⟩ <;> simp

private theorem ticksUpTo_T {T : ℕ} (rootTick : Fin T → Bool) :
    ticksUpTo rootTick T = ((List.ofFn rootTick).filter (fun b => b = true)).length := by
  unfold ticksUpTo
  rw [List.take_of_length_le (by simp)]

open Classical in
private theorem residual_card_drift {d T : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (ball : ChainNode d)
    (S : Fin (T + 1) → Finset ι)
    (ev : Fin T → PoolUpdateEvent ι)
    (rootTick : Fin T → Bool)
    (hEv : ∀ t : Fin T, IsValidPoolUpdateEvent (S t.castSucc) (S t.succ) (ev t))
    (hRootTick : ∀ t : Fin T, (ev t).isClockTick = true → rootTick t = true) :
    ∀ (s : ℕ) (hs : s ≤ T),
      (ball.residual pts (S ⟨s, Nat.lt_succ_of_le hs⟩)).card ≤
        (ball.residual pts (S 0)).card + ticksUpTo rootTick s := by
  intro s
  induction s with
  | zero =>
    intro hs
    rw [ticksUpTo_zero]
    have h0 : (⟨0, Nat.lt_succ_of_le hs⟩ : Fin (T + 1)) = 0 := rfl
    rw [h0]
    omega
  | succ s ih =>
    intro hs
    let t : Fin T := ⟨s, hs⟩
    have hcs : t.castSucc = ⟨s, Nat.lt_succ_of_le (Nat.le_of_succ_le hs)⟩ := rfl
    have hsu : t.succ = ⟨s + 1, Nat.lt_succ_of_le hs⟩ := rfl
    have hprev := ih (Nat.le_of_succ_le hs)
    rw [ticksUpTo_succ rootTick hs]
    have hEvt := hEv t
    cases he : ev t with
    | virtualValueDelete =>
      rw [he] at hEvt
      dsimp only [IsValidPoolUpdateEvent] at hEvt
      rw [← hsu, hEvt, hcs]
      omega
    | unaffected =>
      rw [he] at hEvt
      dsimp only [IsValidPoolUpdateEvent] at hEvt
      rw [← hsu, hEvt, hcs]
      omega
    | externalDelete id =>
      rw [he] at hEvt
      rcases hEvt with ⟨_, hSeq⟩
      have hSub : ball.residual pts ((S t.castSucc).erase id) ⊆ ball.residual pts (S t.castSucc) := by
        intro x hx
        unfold ChainNode.residual nodeResidual nodeCore at hx ⊢
        rw [Finset.mem_sdiff, Finset.mem_filter] at hx ⊢
        exact ⟨Finset.mem_of_mem_erase hx.1, fun ⟨_, hc⟩ => hx.2 ⟨hx.1, hc⟩⟩
      have hCardLe := Finset.card_le_card hSub
      rw [← hsu, hSeq, hcs]
      rw [hcs] at hCardLe
      exact le_trans hCardLe (by omega)
    | externalInsert id =>
      have hTick : rootTick t = true := by
        apply hRootTick t
        simp [he, PoolUpdateEvent.isClockTick]
      rw [he] at hEvt
      rcases hEvt with ⟨_, hSeq⟩
      have hSub : ball.residual pts (insert id (S t.castSucc)) ⊆
          insert id (ball.residual pts (S t.castSucc)) := by
        intro x hx
        unfold ChainNode.residual nodeResidual nodeCore at hx ⊢
        rw [Finset.mem_sdiff, Finset.mem_filter] at hx
        rcases Finset.mem_insert.mp hx.1 with rfl | hxS
        · exact Finset.mem_insert_self _ _
        · apply Finset.mem_insert_of_mem
          rw [Finset.mem_sdiff, Finset.mem_filter]
          exact ⟨hxS, fun ⟨_, hc⟩ => hx.2 ⟨Finset.mem_insert_of_mem hxS, hc⟩⟩
      have hCardLe : (ball.residual pts (insert id (S t.castSucc))).card ≤
          (ball.residual pts (S t.castSucc)).card + 1 :=
        le_trans (Finset.card_le_card hSub) (Finset.card_insert_le _ _)
      rw [← hsu, hSeq, hcs]
      rw [hcs] at hCardLe
      simp only [show (⟨s, hs⟩ : Fin T) = t from rfl, hTick, ↓reduceIte]
      exact le_trans hCardLe (by omega)

/-! ### 3. Full horizon trajectory construction and proof of Conjunct 2 -/

open Classical in
private noncomputable def buildTrajAux {d T : ℕ} {ι IdxState : Type}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (n m : ℕ) (A_n tickBudget : ℝ)
    (optParams : Option LocalScaleParams)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (birthSnapshotList : List (ι × ℕ)) (initNextLife : ℕ)
    (prov : ChainNode d) (setupWork : ℝ)
    (ev : Fin T → PoolUpdateEvent ι)
    (rootTick : Fin T → Bool) :
    (s : ℕ) → s ≤ T → TwoScanLevelState d ι IdxState × ℕ × ℕ × ℕ
  | 0, _ =>
      (initTwoScanLevelState d birthSnapshotList initNextLife dynSearch.initIdx setupWork, 0, 0, 0)
  | s + 1, hs =>
      let prev := buildTrajAux α pts n m A_n tickBudget optParams dynSearch
        birthSnapshotList initNextLife prov setupWork ev rootTick s (Nat.le_of_succ_le hs)
      let t : Fin T := ⟨s, hs⟩
      let st_prev := prev.1
      let ins_prev := prev.2.1
      let bg_prev := prev.2.2.1
      let nr_prev := prev.2.2.2
      let st_arr := applyPoolArrivalStep pts n A_n optParams dynSearch (ev t) st_prev
      let ins_next := ins_prev + evInsInc (ev t)
      let fixedBall := applyBirthCoreFallback α pts (birthSnapshotList.toFinset.image Prod.fst) prov
      if rootTick t = true then
        let K := remBgSteps (m + ins_next) st_arr.phase
        let out := runTickSteps α pts n m A_n prov optParams dynSearch K tickBudget st_arr
        let nr_inc := if out.1.phase = .ready fixedBall then 0 else 1
        (out.1, ins_next, bg_prev + out.2, nr_prev + nr_inc)
      else
        (st_arr, ins_next, bg_prev, nr_prev)

set_option maxHeartbeats 800000 in
open Classical in
theorem claim_C_2_scans_part2 (h53 : S_clm_5_3_matching_invariant) :
    ∃ (C_scanWork C_tickMult : ℝ),
      1 ≤ C_scanWork ∧ 1 ≤ C_tickMult ∧
      ∀ (d n : ℕ) (ι IdxState : Type)
        (pts : ι → EuclideanSpace ℝ (Fin d))
        (α C : ℝ) (K₀ L : ℕ)
        (A_n P_search P_loc tickBudget : ℝ)
        (optParams : Option LocalScaleParams)
        (dynSearch : LocalDynamicSearchInterface d ι IdxState)
        (birthSnapshotList : List (ι × ℕ)) (initNextLife : ℕ)
        (res : SampledCenterResult d) (prov : ChainNode d)
        (T : ℕ)
        (S : Fin (T + 1) → Finset ι)
        (ev : Fin T → PoolUpdateEvent ι)
        (rootTick : Fin T → Bool)
        (_hn : 2 ≤ n)
        (_hα_pos : 0 < α)
        (_hα_le : α ≤ 1)
        (_hC_nonneg : 0 ≤ C)
        (_hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
        (_hA_n : 1 ≤ A_n)
        (_hP_loc : ValidNodeWorkFactor n optParams P_search P_loc)
        (_hSearch : ∀ params : LocalScaleParams, optParams = some params →
          SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
        (_hBirthNodup : birthSnapshotList.Nodup)
        (_hBirthPool : IsValidLifetimePool (S 0) birthSnapshotList.toFinset initNextLife)
        (_hLarge : IsLargeResidualLevel L (S 0).card)
        (_hProv : IsProvisionalCenter pts (S 0) res prov)
        (_hCap : ∀ s : Fin (T + 1), (S s).card ≤ n)
        (_hEv : ∀ t : Fin T, IsValidPoolUpdateEvent (S t.castSucc) (S t.succ) (ev t))
        (_hRootTick : ∀ t : Fin T, (ev t).isClockTick = true → rootTick t = true)
        (_hBudgetNonneg : 0 ≤ tickBudget),
        let S_birth := S 0
        let m := S_birth.card
        let fixedBall := applyBirthCoreFallback α pts S_birth prov
        let setupWork := C + ((d : ℝ) + Real.log (n : ℝ)) * (K₀ : ℝ) + A_n * P_loc
        let totalRootTicks := ((List.ofFn rootTick).filter (fun b => b = true)).length
        ∃ (st : Fin (T + 1) → TwoScanLevelState d ι IdxState) (b_req : ℕ),
          st 0 = initTwoScanLevelState d birthSnapshotList initNextLife dynSearch.initIdx setupWork ∧
          (∀ t : Fin T,
            let st_arr :=
              applyPoolArrivalStep pts n A_n optParams dynSearch (ev t) (st t.castSucc)
            if rootTick t = true then
              TwoScanBgChain α pts n m A_n prov optParams dynSearch st_arr (st t.succ) ∧
              (st t.succ).cumWork - st_arr.cumWork ≤ tickBudget
            else
              st t.succ = st_arr) ∧
          (st (Fin.last T)).cumWork ≤
            C_scanWork * ((m : ℝ) + (totalRootTicks : ℝ)) * A_n * P_loc ∧
          1 ≤ b_req ∧
          (b_req : ℝ) ≤ α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ)) ∧
          fixedBall.o = prov.o ∧
          PassesBirthCoreCheck α pts fixedBall S_birth ∧
          (∀ s : Fin (T + 1),
            IsValidLifetimePool (S s) (st s).activeRecords (st s).nextLife ∧
            (st s).radiusDict ⊆ (st s).activeRecords ∧
            (∀ r ∈ (st s).activeRecords, r ∈ (st s).radiusDict ↔ r.2 ∈ (st s).heapIndexed) ∧
            (∀ (coreCnt : ℕ) (maxR : ℝ),
              (st s).phase = .scan1 [] coreCnt maxR →
                coreCnt = (prov.core pts S_birth).card ∧
                maxR = nodeMaxRadius pts prov.o S_birth)) ∧
          (C_tickMult * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ * A_n * P_loc ≤ tickBudget →
            ∀ s : Fin (T + 1),
              b_req ≤ (((List.ofFn rootTick).take s.val).filter (fun b => b = true)).length →
                (st s).phase = .ready fixedBall) ∧
          (∀ (s : Fin (T + 1)) (ball : ChainNode d),
            (st s).phase = .ready ball →
              ball = fixedBall ∧
              (st s).radiusDict = (st s).activeRecords ∧
              (st s).radiusDict.image Prod.fst = S s ∧
              (st s).radiusDict.card = (S s).card ∧
              (st s).childPool =
                (st s).activeRecords.filter (fun r => pts r.1 ∉ coreBall fixedBall.o fixedBall.V) ∧
              (st s).childPool.image Prod.fst = fixedBall.residual pts (S s) ∧
              (st s).childPool.card = (fixedBall.residual pts (S s)).card ∧
              (∀ r ∈ (st s).activeRecords, r.2 ∈ (st s).classified) ∧
              (∀ params : LocalScaleParams, optParams = some params → 0 < fixedBall.V →
                ∀ cfg ∈ params.retainedConfigs fixedBall.V,
                  ((st s).localMatchings cfg).SatisfiesInvariant pts
                    (params.leftVertices pts fixedBall.o fixedBall.V (S s) cfg.j)
                    (params.rightVertices pts fixedBall.o fixedBall.V (S s) cfg.k)
                    (params.weakEdges pts fixedBall.o fixedBall.V (S s) cfg.j cfg.k cfg.ℓ)
                    (params.strongEdges pts fixedBall.o fixedBall.V (S s) cfg.j cfg.k cfg.ℓ))) ∧
          (∀ s : Fin (T + 1),
            let b_s := (((List.ofFn rootTick).take s.val).filter (fun b => b = true)).length
            (b_s : ℝ) ≤ α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ)) →
              ((fixedBall.residual pts (S s)).card : ℝ) ≤
                (1 - α / 4) * ((m : ℝ) + (b_s : ℝ))) := by
  refine ⟨30, 4096, by norm_num, by norm_num, ?_⟩
  intro d n ι IdxState pts α C K₀ L A_n P_search P_loc tickBudget optParams dynSearch
    birthSnapshotList initNextLife res prov T S ev rootTick
    hn hα_pos hα_le hC_nonneg hL hAn hPloc hSearch
    hBirthNodup hBirthPool hLarge hProv hCap hEv hRootTick hBudgetNonneg
  dsimp only
  set S_birth := S 0
  set m := S_birth.card
  set fixedBall := applyBirthCoreFallback α pts S_birth prov
  set setupWork := C + ((d : ℝ) + Real.log (n : ℝ)) * (K₀ : ℝ) + A_n * P_loc
  set totalRootTicks := ((List.ofFn rootTick).filter (fun b => b = true)).length
  rcases validNodeWorkFactor_bounds hn hAn hPloc with ⟨_, hAP1, _, _⟩
  have hAP_pos : 0 < A_n * P_loc := by linarith
  -- Parameter bounds from Equation (10) leaf cutoff and IsLargeResidualLevel
  unfold SatisfiesLeafCutoffEq10 SatisfiesLeafCutoffReal at hL
  rcases hL with ⟨hL_size, hL_cost⟩
  unfold IsLargeResidualLevel at hLarge
  have hm_ge2 : 2 ≤ m := by
    have hL_pos : (0 : ℝ) < (L : ℝ) := by
      have ha2_pos : 0 < (α ^ 2)⁻¹ := inv_pos.mpr (pow_pos hα_pos 2)
      have hcs_pos : (0 : ℝ) < (scheduleCStar : ℝ) := by unfold scheduleCStar; norm_num
      have hprod : 0 < (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ := by positivity
      linarith
    have hL1 : 1 ≤ L := by
      by_contra h0
      have : L = 0 := by omega
      subst this
      simp at hL_pos
    omega
  have hBirthNonempty : S_birth.Nonempty := Finset.card_pos.mp (by omega)
  rcases birthCoreFallback_props pts prov hα_le hBirthNonempty with ⟨hFixedO, hFixedCheck⟩
  -- Define b_req and prove its lower/upper bounds
  set X_req : ℝ := α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ))
  have ha2_pos : 0 < α ^ 2 := pow_pos hα_pos 2
  have ha2_le1 : α ^ 2 ≤ 1 := by nlinarith
  have ha2_inv_ge1 : 1 ≤ (α ^ 2)⁻¹ := (one_le_inv₀ ha2_pos).mpr ha2_le1
  have hcs_val : (scheduleCStar : ℝ) = 4096 := by unfold scheduleCStar; norm_num
  have hX_large : 32768 < X_req := by
    have h1 : ((2 : ℝ) ^ 20 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹) * (α ^ 2) ≤ (L : ℝ) * (α ^ 2) :=
      mul_le_mul_of_nonneg_right hL_size (le_of_lt ha2_pos)
    rw [inv_mul_cancel_right₀ (ne_of_gt ha2_pos)] at h1
    have hmL : 2 * (L : ℝ) < (m : ℝ) := by exact_mod_cast (by omega : 2 * L < m)
    have h2 : 2 * ((L : ℝ) * (α ^ 2)) < α ^ 2 * (m : ℝ) := by
      have h2' := mul_lt_mul_of_pos_right hmL ha2_pos
      linarith [show 2 * (L : ℝ) * (α ^ 2) = 2 * ((L : ℝ) * (α ^ 2)) by ring,
                show (m : ℝ) * (α ^ 2) = α ^ 2 * (m : ℝ) by ring]
    have hpow21 : (2 : ℝ) ^ 21 * (scheduleCStar : ℝ) = 2 * ((2 : ℝ) ^ 20 * (scheduleCStar : ℝ)) := by ring
    have h3 : (2 : ℝ) ^ 21 * (scheduleCStar : ℝ) < α ^ 2 * (m : ℝ) := by linarith
    dsimp only [X_req]
    rw [hcs_val] at h3 ⊢
    have h3' : (8589934592 : ℝ) < α ^ 2 * (m : ℝ) := by norm_num at h3; exact h3
    have hden : α ^ 2 * (m : ℝ) / (64 * 4096) = (1 / 262144 : ℝ) * (α ^ 2 * (m : ℝ)) := by ring
    rw [hden]
    linarith
  let b_req : ℕ := ⌊X_req⌋₊
  have hb_req_ge1 : 1 ≤ b_req := by
    exact (Nat.le_floor_iff (by linarith)).mpr (by norm_num; linarith)
  have hb_req_le : (b_req : ℝ) ≤ X_req := Nat.floor_le (by linarith)
  have hb_req_lower : α ^ 2 * (m : ℝ) / (128 * (scheduleCStar : ℝ)) ≤ (b_req : ℝ) := by
    have hsub : X_req - 1 < (b_req : ℝ) := Nat.sub_one_lt_floor X_req
    have hhalf : X_req / 2 ≤ X_req - 1 := by linarith
    have heq : X_req / 2 = α ^ 2 * (m : ℝ) / (128 * (scheduleCStar : ℝ)) := by
      dsimp only [X_req]
      ring
    linarith
  -- Trajectory definition
  let traj := buildTrajAux α pts n m A_n tickBudget optParams dynSearch
    birthSnapshotList initNextLife prov setupWork ev rootTick
  let st : Fin (T + 1) → TwoScanLevelState d ι IdxState :=
    fun s => (traj s.val (Nat.lt_succ_iff.mp s.isLt)).1
  have hImgBirth : birthSnapshotList.toFinset.image Prod.fst = S_birth := hBirthPool.1
  -- Inductive trajectory invariant across s = 0..T
  have hTrajInv : ∀ (s : ℕ) (hs : s ≤ T),
      let cur := traj s hs
      let b_s := ticksUpTo rootTick s
      LevelInv α pts optParams birthSnapshotList S_birth prov
        (S ⟨s, Nat.lt_succ_of_le hs⟩) cur.2.1 cur.1 ∧
      cur.2.1 ≤ b_s ∧
      cur.1.cumWork ≤ setupWork + (10 * (b_s : ℝ) + 6 * (cur.2.2.1 : ℝ)) * (A_n * P_loc) ∧
      (∀ M2 : ℕ, m + cur.2.1 ≤ M2 → remBgSteps M2 cur.1.phase + cur.2.2.1 ≤ m + M2 + 2) ∧
      (cur.1.phase ≠ .ready fixedBall → cur.2.2.2 = b_s) ∧
      (4096 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ * A_n * P_loc ≤ tickBudget →
        (cur.2.2.2 : ℝ) * (600 * ((scheduleCStar : ℝ) * (α ^ 2)⁻¹)) ≤ (cur.2.2.1 : ℝ)) := by
    intro s
    induction s with
    | zero =>
      intro hs
      dsimp only [traj, buildTrajAux]
      rw [ticksUpTo_zero]
      rcases init_levelInv α pts optParams birthSnapshotList S_birth prov
          initNextLife dynSearch.initIdx setupWork hBirthNodup hBirthPool with
        ⟨hInv0, hLen0⟩
      refine ⟨hInv0, le_rfl, ?_, ?_, ?_, ?_⟩
      · simp [initTwoScanLevelState]
      · intro M2 _
        simp only [initTwoScanLevelState, remBgSteps, hLen0]
        omega
      · intro _; rfl
      · intro _; simp
    | succ s ih =>
      intro hs
      rcases ih (Nat.le_of_succ_le hs) with
        ⟨hInvPrev, hInsPrev, hWorkPrev, hRemPrev, hNrEqPrev, hNrBoundPrev⟩
      set prev := traj s (Nat.le_of_succ_le hs)
      let t : Fin T := ⟨s, hs⟩
      have hcs : (⟨s, Nat.lt_succ_of_le (Nat.le_of_succ_le hs)⟩ : Fin (T + 1)) = t.castSucc := rfl
      have hsu : (⟨s + 1, Nat.lt_succ_of_le hs⟩ : Fin (T + 1)) = t.succ := rfl
      rw [hcs] at hInvPrev
      rcases arrival_step_spec h53 pts hn hAn hPloc hSearch (hEv t)
          (hCap t.castSucc) (hCap t.succ) hInvPrev with
        ⟨hInvArr, hRemArr, hWorkArr0, hWorkArrHi, hReadyArr⟩
      set st_arr := applyPoolArrivalStep pts n A_n optParams dynSearch (ev t) prev.1
      set ins_next := prev.2.1 + evInsInc (ev t)
      have htraj_succ : traj (s + 1) hs =
          let fb := applyBirthCoreFallback α pts (birthSnapshotList.toFinset.image Prod.fst) prov
          if rootTick t = true then
            let K := remBgSteps (m + ins_next) st_arr.phase
            let out := runTickSteps α pts n m A_n prov optParams dynSearch K tickBudget st_arr
            let nr_inc := if out.1.phase = .ready fb then 0 else 1
            (out.1, ins_next, prev.2.2.1 + out.2, prev.2.2.2 + nr_inc)
          else
            (st_arr, ins_next, prev.2.2.1, prev.2.2.2) := rfl
      dsimp only
      rw [htraj_succ, ticksUpTo_succ rootTick hs]
      dsimp only
      rw [hImgBirth, show applyBirthCoreFallback α pts S_birth prov = fixedBall from rfl,
        show rootTick ⟨s, hs⟩ = rootTick t from rfl]
      by_cases hrt : rootTick t = true
      · simp only [hrt, ↓reduceIte]
        set K := remBgSteps (m + ins_next) st_arr.phase
        have hSpec := runTickSteps_spec h53 pts hn hAn hPloc hSearch hBirthNodup hBirthPool
          hBirthNonempty (hCap t.succ) ins_next K tickBudget st_arr hBudgetNonneg hInvArr
        dsimp only at hSpec
        rw [show S_birth.card = m from rfl,
            show applyBirthCoreFallback α pts S_birth prov = fixedBall from rfl] at hSpec
        set out := runTickSteps α pts n m A_n prov optParams dynSearch K tickBudget st_arr
        rcases hSpec with
          ⟨_, hInvOut, hWorkOut0, _, hWorkOutCnt, hRemOut, hReadyOut, hProgOut⟩
        have hEvIncLe : evInsInc (ev t) ≤ 1 := by cases ev t <;> simp [evInsInc]
        have hArrBound : st_arr.cumWork - prev.1.cumWork ≤ 10 * A_n * P_loc := by
          cases hck : (ev t).isClockTick
          · rw [hck] at hWorkArrHi
            simp only [Bool.false_eq_true, ↓reduceIte] at hWorkArrHi
            linarith
          · rw [hck] at hWorkArrHi
            simp only [↓reduceIte] at hWorkArrHi
            exact hWorkArrHi
        refine ⟨by rwa [hsu], by dsimp only [ins_next]; omega, ?_, ?_, ?_, ?_⟩
        · have hring :
              setupWork + (10 * ((ticksUpTo rootTick s + 1 : ℕ) : ℝ) +
                6 * ((prev.2.2.1 + out.2 : ℕ) : ℝ)) * (A_n * P_loc) =
              setupWork + (10 * (ticksUpTo rootTick s : ℝ) + 6 * (prev.2.2.1 : ℝ)) * (A_n * P_loc) +
                10 * A_n * P_loc + (out.2 : ℝ) * (6 * A_n * P_loc) := by
            push_cast; ring
          rw [hring]
          linarith
        · intro M2 hM2
          have h1 := hRemOut M2 hM2
          have h2 := hRemArr M2
          have h3 := hRemPrev M2 (by dsimp only [ins_next] at hM2; omega)
          omega
        · intro hNotReady
          have hPrevNotReady : prev.1.phase ≠ .ready fixedBall := by
            intro hPR
            exact hNotReady (hReadyOut fixedBall (hReadyArr fixedBall hPR))
          have hPrevNr := hNrEqPrev hPrevNotReady
          simp only [hNotReady, ↓reduceIte]
          omega
        · intro hTickLarge
          have hPrevBound := hNrBoundPrev hTickLarge
          by_cases hIsReady : out.1.phase = .ready fixedBall
          · simp only [hIsReady, ↓reduceIte, Nat.add_zero]
            rw [Nat.cast_add]
            have hNonneg : (0 : ℝ) ≤ (out.2 : ℝ) := Nat.cast_nonneg _
            linarith
          · simp only [hIsReady, ↓reduceIte]
            rcases hProgOut le_rfl with hR | hShort
            · exact absurd hR hIsReady
            · have hCancel :
                  4096 * ((scheduleCStar : ℝ) * (α ^ 2)⁻¹) * (A_n * P_loc) <
                    (6 * ((out.2 : ℝ) + 1)) * (A_n * P_loc) := by
                have hL_eq : 4096 * ((scheduleCStar : ℝ) * (α ^ 2)⁻¹) * (A_n * P_loc) =
                    4096 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ * A_n * P_loc := by ring
                have hR_eq : ((out.2 + 1 : ℕ) : ℝ) * (6 * A_n * P_loc) =
                    (6 * ((out.2 : ℝ) + 1)) * (A_n * P_loc) := by push_cast; ring
                linarith
              have hDiv : 4096 * ((scheduleCStar : ℝ) * (α ^ 2)⁻¹) < 6 * ((out.2 : ℝ) + 1) :=
                lt_of_mul_lt_mul_right hCancel (le_of_lt hAP_pos)
              have hCS_ge : 4096 ≤ (scheduleCStar : ℝ) * (α ^ 2)⁻¹ := by
                rw [hcs_val]
                linarith
              have hStepCount : 600 * ((scheduleCStar : ℝ) * (α ^ 2)⁻¹) ≤ (out.2 : ℝ) := by
                linarith
              rw [Nat.cast_add, Nat.cast_one, add_one_mul, Nat.cast_add]
              linarith
      · have hrf : rootTick t = false := Bool.eq_false_iff.mpr hrt
        simp only [hrf, Bool.false_eq_true, ↓reduceIte, Nat.add_zero]
        have hNotClock : (ev t).isClockTick = false := by
          cases hck : (ev t).isClockTick
          · rfl
          · exfalso; exact hrt (hRootTick t hck)
        have hEvInc0 : evInsInc (ev t) = 0 := by
          cases h_e : ev t <;> simp [h_e, PoolUpdateEvent.isClockTick, evInsInc] at hNotClock ⊢
        have hArr0 : st_arr.cumWork - prev.1.cumWork ≤ 0 := by
          rw [hNotClock] at hWorkArrHi
          simpa using hWorkArrHi
        refine ⟨by rwa [hsu], by dsimp only [ins_next]; omega, by linarith, ?_, ?_, ?_⟩
        · intro M2 hM2
          rw [hRemArr M2]
          exact hRemPrev M2 (by dsimp only [ins_next] at hM2; omega)
        · intro hNotReady
          have hPrevNotReady : prev.1.phase ≠ .ready fixedBall := by
            intro hPR
            exact hNotReady (hReadyArr fixedBall hPR)
          exact hNrEqPrev hPrevNotReady
        · exact hNrBoundPrev
  -- Assemble all existential witnesses and conjuncts
  refine ⟨st, b_req, rfl, ?_, ?_, hb_req_ge1, hb_req_le, hFixedO, hFixedCheck, ?_, ?_, ?_, ?_⟩
  · -- Step transition relation (chain + per-tick budget)
    intro t
    have hsucc_eq : st t.succ = (traj (t.val + 1) t.isLt).1 := rfl
    have hcast_eq : st t.castSucc = (traj t.val (Nat.le_of_lt t.isLt)).1 := rfl
    rw [hsucc_eq, hcast_eq]
    dsimp only [traj, buildTrajAux]
    have ht_eq : (⟨t.val, t.isLt⟩ : Fin T) = t := Fin.ext rfl
    rw [ht_eq]
    have hInvPrev := (hTrajInv t.val (Nat.le_of_lt t.isLt)).1
    have hcs : (⟨t.val, Nat.lt_succ_of_le (Nat.le_of_lt t.isLt)⟩ : Fin (T + 1)) = t.castSucc := rfl
    rw [hcs] at hInvPrev
    rcases arrival_step_spec h53 pts hn hAn hPloc hSearch (hEv t)
        (hCap t.castSucc) (hCap t.succ) hInvPrev with
      ⟨hInvArr, _, _, _, _⟩
    by_cases hrt : rootTick t = true
    · simp only [hrt, ↓reduceIte]
      rcases runTickSteps_spec h53 pts hn hAn hPloc hSearch hBirthNodup hBirthPool
          hBirthNonempty (hCap t.succ) _ _ tickBudget _ hBudgetNonneg hInvArr with
        ⟨hChain, _, _, hBudLe, _, _, _, _⟩
      exact ⟨hChain, hBudLe⟩
    · have hrf : rootTick t = false := Bool.eq_false_iff.mpr hrt
      simp only [hrf, Bool.false_eq_true, ↓reduceIte]
  · -- Total cumulative work bound at T
    rcases hTrajInv T le_rfl with ⟨_, hInsT, hWorkT, hRemT, _, _⟩
    have hlast : st (Fin.last T) = (traj T le_rfl).1 := rfl
    rw [hlast]
    rw [ticksUpTo_T] at hInsT hWorkT
    have hBgBound : (traj T le_rfl).2.2.1 ≤ 2 * m + totalRootTicks + 2 := by
      have h1 := hRemT (m + (traj T le_rfl).2.1) le_rfl
      omega
    have hBgReal : ((traj T le_rfl).2.2.1 : ℝ) ≤ 3 * (m : ℝ) + (totalRootTicks : ℝ) := by
      have hcast : ((traj T le_rfl).2.2.1 : ℝ) ≤ (2 * m + totalRootTicks + 2 : ℕ) := by
        exact_mod_cast hBgBound
      push_cast at hcast
      have hm2 : (2 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm_ge2
      linarith
    have hSetupBound : setupWork ≤ 2 * (m : ℝ) * (A_n * P_loc) := by
      have h64_pos : 0 < 64 * α⁻¹ := by positivity
      have hCK_le_L : C + ((d : ℝ) + Real.log (n : ℝ)) * (K₀ : ℝ) ≤ (L : ℝ) := by linarith
      have hL_le_m : (L : ℝ) ≤ (m : ℝ) := by exact_mod_cast (by omega : L ≤ m)
      have hCK_le_m : C + ((d : ℝ) + Real.log (n : ℝ)) * (K₀ : ℝ) ≤ (m : ℝ) := by linarith
      have hm_le_mAP : (m : ℝ) ≤ (m : ℝ) * (A_n * P_loc) :=
        le_mul_of_one_le_right (Nat.cast_nonneg _) hAP1
      have hAP_le_mAP : A_n * P_loc ≤ (m : ℝ) * (A_n * P_loc) := by
        have hm1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast (by omega : 1 ≤ m)
        exact le_mul_of_one_le_left (le_of_lt hAP_pos) hm1
      dsimp only [setupWork]
      linarith
    have hTotNonneg : 0 ≤ (totalRootTicks : ℝ) := Nat.cast_nonneg _
    have hmNonneg : 0 ≤ (m : ℝ) := Nat.cast_nonneg _
    have hComb :
        10 * (totalRootTicks : ℝ) + 6 * ((traj T le_rfl).2.2.1 : ℝ) ≤
          28 * ((m : ℝ) + (totalRootTicks : ℝ)) := by
      linarith
    have hMul :
        (10 * (totalRootTicks : ℝ) + 6 * ((traj T le_rfl).2.2.1 : ℝ)) * (A_n * P_loc) ≤
          28 * ((m : ℝ) + (totalRootTicks : ℝ)) * (A_n * P_loc) :=
      mul_le_mul_of_nonneg_right hComb (le_of_lt hAP_pos)
    calc (traj T le_rfl).1.cumWork
        ≤ setupWork + (10 * (totalRootTicks : ℝ) + 6 * ((traj T le_rfl).2.2.1 : ℝ)) * (A_n * P_loc) :=
          hWorkT
      _ ≤ 2 * (m : ℝ) * (A_n * P_loc) + 28 * ((m : ℝ) + (totalRootTicks : ℝ)) * (A_n * P_loc) := by
          linarith
      _ ≤ 30 * ((m : ℝ) + (totalRootTicks : ℝ)) * A_n * P_loc := by
          have hdiff :
              30 * ((m : ℝ) + (totalRootTicks : ℝ)) * A_n * P_loc -
                (2 * (m : ℝ) * (A_n * P_loc) +
                  28 * ((m : ℝ) + (totalRootTicks : ℝ)) * (A_n * P_loc)) =
              2 * (totalRootTicks : ℝ) * (A_n * P_loc) := by ring
          have hpos_rhs : 0 ≤ 2 * (totalRootTicks : ℝ) * (A_n * P_loc) := by positivity
          linarith
  · -- Per-step structural invariants across all s
    intro s
    have hInvS := (hTrajInv s.val (Nat.lt_succ_iff.mp s.isLt)).1
    have hs_eq : (⟨s.val, Nat.lt_succ_of_le (Nat.lt_succ_iff.mp s.isLt)⟩ : Fin (T + 1)) = s :=
      Fin.ext rfl
    rw [hs_eq] at hInvS
    exact (levelInv_consequences pts hBirthNodup hBirthPool hBirthNonempty hInvS).1
  · -- Completion within b_req affected root ticks
    intro hTickBudget s hbs_ge
    rcases hTrajInv s.val (Nat.lt_succ_iff.mp s.isLt) with
      ⟨_, hInsS, _, hRemS, hNrEqS, hNrBoundS⟩
    change (traj s.val (Nat.lt_succ_iff.mp s.isLt)).1.phase = .ready fixedBall
    by_contra hNotReady
    have hNrEq : (traj s.val (Nat.lt_succ_iff.mp s.isLt)).2.2.2 = ticksUpTo rootTick s.val :=
      hNrEqS hNotReady
    have hBgUpperNat : (traj s.val (Nat.lt_succ_iff.mp s.isLt)).2.2.1 ≤
        2 * m + ticksUpTo rootTick s.val + 2 := by
      have h1 := hRemS (m + (traj s.val (Nat.lt_succ_iff.mp s.isLt)).2.1) le_rfl
      omega
    have hBgUpper : ((traj s.val (Nat.lt_succ_iff.mp s.isLt)).2.2.1 : ℝ) ≤
        2 * (m : ℝ) + (ticksUpTo rootTick s.val : ℝ) + 2 := by
      have hc : ((traj s.val (Nat.lt_succ_iff.mp s.isLt)).2.2.1 : ℝ) ≤
          (2 * m + ticksUpTo rootTick s.val + 2 : ℕ) := by exact_mod_cast hBgUpperNat
      push_cast at hc
      exact hc
    have hBgLower := hNrBoundS hTickBudget
    rw [hNrEq] at hBgLower
    set bs : ℝ := (ticksUpTo rootTick s.val : ℝ)
    set Q : ℝ := (scheduleCStar : ℝ) * (α ^ 2)⁻¹
    have hQ_ge : 4096 ≤ Q := by
      dsimp only [Q]
      rw [hcs_val]
      linarith
    have hbs_ge' : b_req ≤ ticksUpTo rootTick s.val := hbs_ge
    have hbs_real : (b_req : ℝ) ≤ bs := Nat.cast_le.mpr hbs_ge'
    have hPart1 : (400 / 128) * (m : ℝ) ≤ bs * (400 * Q) := by
      have h1 : (α ^ 2 * (m : ℝ) / (128 * (scheduleCStar : ℝ))) * (400 * Q) ≤
          (b_req : ℝ) * (400 * Q) :=
        mul_le_mul_of_nonneg_right hb_req_lower (by linarith only [hQ_ge])
      have h2 : (b_req : ℝ) * (400 * Q) ≤ bs * (400 * Q) :=
        mul_le_mul_of_nonneg_right hbs_real (by linarith only [hQ_ge])
      have hEq : (α ^ 2 * (m : ℝ) / (128 * (scheduleCStar : ℝ))) * (400 * Q) =
          (400 / 128) * (m : ℝ) := by
        dsimp only [Q]
        have hcs_ne : (scheduleCStar : ℝ) ≠ 0 := by unfold scheduleCStar; norm_num
        have ha2_ne : α ^ 2 ≠ 0 := ne_of_gt ha2_pos
        field_simp [hcs_ne, ha2_ne]
      linarith only [h1, h2, hEq]
    have hPart2 : bs ≤ bs * (200 * Q) :=
      le_mul_of_one_le_right (Nat.cast_nonneg _) (by linarith only [hQ_ge])
    have hSplitQ : bs * (600 * Q) = bs * (400 * Q) + bs * (200 * Q) := by ring
    have hm2 : (2 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm_ge2
    linarith only [hBgUpper, hBgLower, hPart1, hPart2, hSplitQ, hm2]
  · -- Ready-state invariants across all s
    intro s ball hReady
    have hInvS := (hTrajInv s.val (Nat.lt_succ_iff.mp s.isLt)).1
    have hs_eq : (⟨s.val, Nat.lt_succ_of_le (Nat.lt_succ_iff.mp s.isLt)⟩ : Fin (T + 1)) = s :=
      Fin.ext rfl
    rw [hs_eq] at hInvS
    exact (levelInv_consequences pts hBirthNodup hBirthPool hBirthNonempty hInvS).2 ball hReady
  · -- Child contraction bound for all s with b_s ≤ α^2 m / (64 C_*)
    intro s hbs_le
    have hDrift := residual_card_drift pts fixedBall S ev rootTick hEv hRootTick s.val
      (Nat.lt_succ_iff.mp s.isLt)
    have hs_eq : (⟨s.val, Nat.lt_succ_of_le (Nat.lt_succ_iff.mp s.isLt)⟩ : Fin (T + 1)) = s :=
      Fin.ext rfl
    rw [hs_eq] at hDrift
    have hPartCard : (fixedBall.residual pts S_birth).card + (fixedBall.core pts S_birth).card = m := by
      unfold ChainNode.residual nodeResidual ChainNode.core nodeCore
      exact Finset.card_sdiff_add_card_eq_card (Finset.filter_subset _ _)
    have hPartReal : ((fixedBall.residual pts S_birth).card : ℝ) +
        ((fixedBall.core pts S_birth).card : ℝ) = (m : ℝ) := by
      exact_mod_cast hPartCard
    unfold PassesBirthCoreCheck at hFixedCheck
    have hResBirth : ((fixedBall.residual pts S_birth).card : ℝ) ≤ (1 - α / 2) * (m : ℝ) := by
      linarith
    have hDriftReal : ((fixedBall.residual pts (S s)).card : ℝ) ≤
        ((fixedBall.residual pts S_birth).card : ℝ) + (ticksUpTo rootTick s.val : ℝ) := by
      exact_mod_cast hDrift
    set bs : ℝ := (ticksUpTo rootTick s.val : ℝ)
    have hbs_le_m : bs ≤ (m : ℝ) := by
      have hm0 : 0 ≤ (m : ℝ) := Nat.cast_nonneg _
      have ha2m : α ^ 2 * (m : ℝ) ≤ (m : ℝ) := mul_le_of_le_one_left hm0 ha2_le1
      have hbs_le' : bs ≤ α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ)) := hbs_le
      rw [hcs_val] at hbs_le'
      have hden : α ^ 2 * (m : ℝ) / (64 * 4096) = (1 / 262144 : ℝ) * (α ^ 2 * (m : ℝ)) := by ring
      rw [hden] at hbs_le'
      have ha2m0 : 0 ≤ α ^ 2 * (m : ℝ) := by positivity
      linarith
    have hGap : 0 ≤ (α / 4) * ((m : ℝ) - bs) :=
      mul_nonneg (by linarith) (by linarith)
    have hAlg : (1 - α / 2) * (m : ℝ) + bs + (α / 4) * ((m : ℝ) - bs) =
        (1 - α / 4) * ((m : ℝ) + bs) := by ring
    change ((fixedBall.residual pts (S s)).card : ℝ) ≤ (1 - α / 4) * ((m : ℝ) + bs)
    linarith only [hResBirth, hDriftReal, hGap, hAlg]

end UL.C2ScansRaceV30
