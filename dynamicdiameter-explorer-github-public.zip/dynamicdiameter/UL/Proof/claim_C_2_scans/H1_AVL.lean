import UL.Stmt.claim_C_2_scans
set_option autoImplicit false

namespace UL

section AVLHelpers

private def auxHeight {κ α : Type} : PersistentSizeTree κ α → ℕ
  | .nil => 0
  | .node h _ _ _ _ _ => h

private theorem auxHeight_eq_height {κ α : Type} {t : PersistentSizeTree κ α}
    (havl : t.IsAVL) : auxHeight t = t.height := by
  cases t with
  | nil => rfl
  | node h sz k v l r => exact havl.1

private irreducible_def mkNode {κ α : Type} (k : κ) (v : α)
    (l r : PersistentSizeTree κ α) : PersistentSizeTree κ α :=
  .node (1 + max (auxHeight l) (auxHeight r)) (l.size + 1 + r.size) k v l r

private theorem mkNode_toList {κ α : Type} (k : κ) (v : α)
    (l r : PersistentSizeTree κ α) :
    (mkNode k v l r).toList = l.toList ++ [(k, v)] ++ r.toList := by
  rw [mkNode_def]
  rfl

private theorem mkNode_size {κ α : Type} (k : κ) (v : α)
    (l r : PersistentSizeTree κ α) :
    (mkNode k v l r).size = l.size + 1 + r.size := by
  rw [mkNode_def]
  rfl

private theorem mkNode_height {κ α : Type} (k : κ) (v : α)
    (l r : PersistentSizeTree κ α) :
    (mkNode k v l r).height = 1 + max l.height r.height := by
  rw [mkNode_def]
  rfl

private theorem mkNode_wellSized {κ α : Type} (k : κ) (v : α)
    {l r : PersistentSizeTree κ α} (hl : l.WellSized) (hr : r.WellSized) :
    (mkNode k v l r).WellSized := by
  rw [mkNode_def]
  exact ⟨rfl, hl, hr⟩

private theorem mkNode_isAVL {κ α : Type} (k : κ) (v : α)
    {l r : PersistentSizeTree κ α} (hl : l.IsAVL) (hr : r.IsAVL)
    (hlr : l.height ≤ r.height + 1) (hrl : r.height ≤ l.height + 1) :
    (mkNode k v l r).IsAVL := by
  rw [mkNode_def]
  refine ⟨?_, hlr, hrl, hl, hr⟩
  rw [auxHeight_eq_height hl, auxHeight_eq_height hr]

private def balance {κ α : Type} (k : κ) (v : α)
    (l r : PersistentSizeTree κ α) : PersistentSizeTree κ α :=
  if auxHeight l > auxHeight r + 1 then
    match l with
    | .nil => mkNode k v l r
    | .node _ _ lk lv ll lr =>
        if auxHeight lr ≤ auxHeight ll then
          mkNode lk lv ll (mkNode k v lr r)
        else
          match lr with
          | .nil => mkNode lk lv ll (mkNode k v lr r)
          | .node _ _ lrk lrv lrl lrr =>
              mkNode lrk lrv (mkNode lk lv ll lrl) (mkNode k v lrr r)
  else if auxHeight r > auxHeight l + 1 then
    match r with
    | .nil => mkNode k v l r
    | .node _ _ rk rv rl rr =>
        if auxHeight rl ≤ auxHeight rr then
          mkNode rk rv (mkNode k v l rl) rr
        else
          match rl with
          | .nil => mkNode rk rv (mkNode k v l rl) rr
          | .node _ _ rlk rlv rll rlr =>
              mkNode rlk rlv (mkNode k v l rll) (mkNode rk rv rlr rr)
  else
    mkNode k v l r

private theorem balance_spec {κ α : Type} (k : κ) (v : α)
    {l r : PersistentSizeTree κ α}
    (hwl : l.WellSized) (hwr : r.WellSized)
    (hal : l.IsAVL) (har : r.IsAVL)
    (hlr2 : l.height ≤ r.height + 2) (hrl2 : r.height ≤ l.height + 2) :
    (balance k v l r).WellSized ∧
    (balance k v l r).IsAVL ∧
    (balance k v l r).toList = l.toList ++ [(k, v)] ++ r.toList ∧
    max l.height r.height ≤ (balance k v l r).height ∧
    (balance k v l r).height ≤ 1 + max l.height r.height ∧
    (l.height ≤ r.height + 1 → r.height ≤ l.height + 1 →
      (balance k v l r).height = 1 + max l.height r.height) := by
  dsimp only [balance]
  have hauxL : auxHeight l = l.height := auxHeight_eq_height hal
  have hauxR : auxHeight r = r.height := auxHeight_eq_height har
  by_cases hLbig : auxHeight l > auxHeight r + 1
  · rw [if_pos hLbig]
    have hLh : l.height = r.height + 2 := by omega
    cases l with
    | nil =>
      simp [PersistentSizeTree.height] at hLh
    | node lh lsz lk lv ll lr =>
      dsimp only
      rcases hwl with ⟨_, hwll, hwlr⟩
      rcases hal with ⟨_, hll_lr, hlr_ll, hall, halr⟩
      have hLh_def : 1 + max ll.height lr.height = r.height + 2 := by
        simpa [PersistentSizeTree.height] using hLh
      have hauxLL : auxHeight ll = ll.height := auxHeight_eq_height hall
      have hauxLR : auxHeight lr = lr.height := auxHeight_eq_height halr
      by_cases hsingle : auxHeight lr ≤ auxHeight ll
      · rw [if_pos hsingle]
        have hw_mid : (mkNode k v lr r).WellSized := mkNode_wellSized k v hwlr hwr
        have ha_mid : (mkNode k v lr r).IsAVL :=
          mkNode_isAVL k v halr har (by omega) (by omega)
        refine ⟨mkNode_wellSized lk lv hwll hw_mid,
          mkNode_isAVL lk lv hall ha_mid (by simp only [mkNode_height]; omega)
            (by simp only [mkNode_height]; omega),
          by simp only [mkNode_toList, PersistentSizeTree.toList, List.append_assoc],
          by simp only [mkNode_height, PersistentSizeTree.height]; omega,
          by simp only [mkNode_height, PersistentSizeTree.height]; omega,
          fun h1 _ => by simp only [PersistentSizeTree.height] at h1; omega⟩
      · rw [if_neg hsingle]
        have hlr_eq : lr.height = r.height + 1 := by omega
        cases lr with
        | nil =>
          simp [PersistentSizeTree.height] at hlr_eq
        | node lrh lrsz lrk lrv lrl lrr =>
          dsimp only
          rcases hwlr with ⟨_, hwlrl, hwlrr⟩
          rcases halr with ⟨_, hlrl_lrr, hlrr_lrl, halrl, halrr⟩
          have hlr_def : 1 + max lrl.height lrr.height = r.height + 1 := by
            simpa [PersistentSizeTree.height] using hlr_eq
          have hw1 : (mkNode lk lv ll lrl).WellSized := mkNode_wellSized lk lv hwll hwlrl
          have hw2 : (mkNode k v lrr r).WellSized := mkNode_wellSized k v hwlrr hwr
          have ha1 : (mkNode lk lv ll lrl).IsAVL :=
            mkNode_isAVL lk lv hall halrl (by omega) (by omega)
          have ha2 : (mkNode k v lrr r).IsAVL :=
            mkNode_isAVL k v halrr har (by omega) (by omega)
          refine ⟨mkNode_wellSized lrk lrv hw1 hw2,
            mkNode_isAVL lrk lrv ha1 ha2 (by simp only [mkNode_height]; omega)
              (by simp only [mkNode_height]; omega),
            by simp only [mkNode_toList, PersistentSizeTree.toList, List.append_assoc],
            by simp only [mkNode_height, PersistentSizeTree.height]; omega,
            by simp only [mkNode_height, PersistentSizeTree.height]; omega,
            fun h1 _ => by simp only [PersistentSizeTree.height] at h1; omega⟩
  · rw [if_neg hLbig]
    by_cases hRbig : auxHeight r > auxHeight l + 1
    · rw [if_pos hRbig]
      have hRh : r.height = l.height + 2 := by omega
      cases r with
      | nil =>
        simp [PersistentSizeTree.height] at hRh
      | node rh rsz rk rv rl rr =>
        dsimp only
        rcases hwr with ⟨_, hwrl, hwrr⟩
        rcases har with ⟨_, hrl_rr, hrr_rl, harl, harr⟩
        have hRh_def : 1 + max rl.height rr.height = l.height + 2 := by
          simpa [PersistentSizeTree.height] using hRh
        have hauxRL : auxHeight rl = rl.height := auxHeight_eq_height harl
        have hauxRR : auxHeight rr = rr.height := auxHeight_eq_height harr
        by_cases hsingle : auxHeight rl ≤ auxHeight rr
        · rw [if_pos hsingle]
          have hw_mid : (mkNode k v l rl).WellSized := mkNode_wellSized k v hwl hwrl
          have ha_mid : (mkNode k v l rl).IsAVL :=
            mkNode_isAVL k v hal harl (by omega) (by omega)
          refine ⟨mkNode_wellSized rk rv hw_mid hwrr,
            mkNode_isAVL rk rv ha_mid harr (by simp only [mkNode_height]; omega)
              (by simp only [mkNode_height]; omega),
            by simp only [mkNode_toList, PersistentSizeTree.toList, List.append_assoc],
            by simp only [mkNode_height, PersistentSizeTree.height]; omega,
            by simp only [mkNode_height, PersistentSizeTree.height]; omega,
            fun _ h2 => by simp only [PersistentSizeTree.height] at h2; omega⟩
        · rw [if_neg hsingle]
          have hrl_eq : rl.height = l.height + 1 := by omega
          cases rl with
          | nil =>
            simp [PersistentSizeTree.height] at hrl_eq
          | node rlh rlsz rlk rlv rll rlr =>
            dsimp only
            rcases hwrl with ⟨_, hwrll, hwrlr⟩
            rcases harl with ⟨_, hrll_rlr, hrlr_rll, harll, harlr⟩
            have hrl_def : 1 + max rll.height rlr.height = l.height + 1 := by
              simpa [PersistentSizeTree.height] using hrl_eq
            have hw1 : (mkNode k v l rll).WellSized := mkNode_wellSized k v hwl hwrll
            have hw2 : (mkNode rk rv rlr rr).WellSized := mkNode_wellSized rk rv hwrlr hwrr
            have ha1 : (mkNode k v l rll).IsAVL :=
              mkNode_isAVL k v hal harll (by omega) (by omega)
            have ha2 : (mkNode rk rv rlr rr).IsAVL :=
              mkNode_isAVL rk rv harlr harr (by omega) (by omega)
            refine ⟨mkNode_wellSized rlk rlv hw1 hw2,
              mkNode_isAVL rlk rlv ha1 ha2 (by simp only [mkNode_height]; omega)
                (by simp only [mkNode_height]; omega),
              by simp only [mkNode_toList, PersistentSizeTree.toList, List.append_assoc],
              by simp only [mkNode_height, PersistentSizeTree.height]; omega,
              by simp only [mkNode_height, PersistentSizeTree.height]; omega,
              fun _ h2 => by simp only [PersistentSizeTree.height] at h2; omega⟩
    · rw [if_neg hRbig]
      have hbal : l.height ≤ r.height + 1 ∧ r.height ≤ l.height + 1 := by omega
      refine ⟨mkNode_wellSized k v hwl hwr, mkNode_isAVL k v hal har hbal.1 hbal.2,
        mkNode_toList k v l r,
        by simp only [mkNode_height]; omega,
        by simp only [mkNode_height]; omega,
        fun _ _ => mkNode_height k v l r⟩

private theorem pairwise_lt_append {κ : Type} [LinearOrder κ] {A B : List κ}
    (hA : A.Pairwise (· < ·)) (hB : B.Pairwise (· < ·))
    (hAB : ∀ a ∈ A, ∀ b ∈ B, a < b) :
    (A ++ B).Pairwise (· < ·) := by
  induction A with
  | nil => simpa using hB
  | cons hd tl ih =>
    rw [List.cons_append, List.pairwise_cons]
    rw [List.pairwise_cons] at hA
    refine ⟨?_, ih hA.2 (fun a ha b hb => hAB a (List.mem_cons_of_mem _ ha) b hb)⟩
    intro x hx
    rcases List.mem_append.mp hx with hxtl | hxB
    · exact hA.1 x hxtl
    · exact hAB hd List.mem_cons_self x hxB

private theorem pairwise_lt_split {κ α : Type} [LinearOrder κ] {L R : List (κ × α)}
    {k₀ : κ} {v₀ : α}
    (hpw : ((L ++ [(k₀, v₀)] ++ R).map Prod.fst).Pairwise (· < ·)) :
    (L.map Prod.fst).Pairwise (· < ·) ∧
    (R.map Prod.fst).Pairwise (· < ·) ∧
    (∀ kv ∈ L, kv.1 < k₀) ∧
    (∀ kv ∈ R, k₀ < kv.1) := by
  have h1 : (L.map Prod.fst ++ ([k₀] ++ R.map Prod.fst)).Pairwise (· < ·) := by
    simpa [List.map_append, List.append_assoc] using hpw
  rcases List.pairwise_append.mp h1 with ⟨hpwL, hpwMidR, hL_MidR⟩
  rw [List.singleton_append, List.pairwise_cons] at hpwMidR
  refine ⟨hpwL, hpwMidR.2, ?_, ?_⟩
  · intro kv hkv
    exact hL_MidR kv.1 (List.mem_map_of_mem hkv) k₀ List.mem_cons_self
  · intro kv hkv
    exact hpwMidR.1 kv.1 (List.mem_map_of_mem hkv)

private theorem pairwise_lt_node {κ α : Type} [LinearOrder κ] {L R : List (κ × α)}
    {k₀ : κ} {v₀ : α}
    (hpwL : (L.map Prod.fst).Pairwise (· < ·))
    (hpwR : (R.map Prod.fst).Pairwise (· < ·))
    (hLk : ∀ kv ∈ L, kv.1 < k₀)
    (hkR : ∀ kv ∈ R, k₀ < kv.1) :
    ((L ++ [(k₀, v₀)] ++ R).map Prod.fst).Pairwise (· < ·) := by
  simp only [List.map_append, List.map_cons, List.map_nil]
  have h1 : (L.map Prod.fst ++ [k₀]).Pairwise (· < ·) :=
    pairwise_lt_append hpwL (List.pairwise_singleton (· < ·) k₀) (fun a ha b hb => by
      rw [List.mem_singleton] at hb
      subst hb
      rcases List.mem_map.mp ha with ⟨kv, hkv, rfl⟩
      exact hLk kv hkv)
  exact pairwise_lt_append h1 hpwR (fun a ha b hb => by
    rcases List.mem_map.mp hb with ⟨rkv, hrkv, rfl⟩
    rcases List.mem_append.mp ha with haL | hak
    · rcases List.mem_map.mp haL with ⟨lkv, hlkv, rfl⟩
      exact lt_trans (hLk lkv hlkv) (hkR rkv hrkv)
    · rw [List.mem_singleton] at hak
      subst hak
      exact hkR rkv hrkv)

private theorem size_eq_toList_length {κ α : Type} {t : PersistentSizeTree κ α}
    (hw : t.WellSized) : t.size = t.toList.length := by
  induction t with
  | nil => rfl
  | node h sz k v l r ihl ihr =>
    rcases hw with ⟨hsz, hwl, hwr⟩
    dsimp only [PersistentSizeTree.size, PersistentSizeTree.toList]
    rw [hsz, ihl hwl, ihr hwr]
    simp only [List.length_append, List.length_singleton]

private theorem le_nat_log2_of_pow_le : ∀ (k n : ℕ), 2 ^ k ≤ n → k ≤ Nat.log 2 n
  | 0, _, _ => Nat.zero_le _
  | k + 1, n, hlo => by
    have hpow_pos : 1 ≤ 2 ^ k := Nat.one_le_pow k 2 (by omega)
    have h2 : 2 ≤ n := by
      have : 2 ^ (k + 1) = 2 ^ k * 2 := by ring
      omega
    have hlo' : 2 ^ k ≤ n / 2 := by
      have : 2 ^ (k + 1) = 2 ^ k * 2 := by ring
      omega
    rw [Nat.log_of_one_lt_of_le (by omega) h2]
    exact Nat.succ_le_succ (le_nat_log2_of_pow_le k (n / 2) hlo')

private theorem avl_pow_le_size_succ {κ α : Type} {t : PersistentSizeTree κ α}
    (hw : t.WellSized) (ha : t.IsAVL) :
    2 ^ ((t.height + 1) / 2) ≤ t.size + 1 := by
  induction t with
  | nil => simp [PersistentSizeTree.height, PersistentSizeTree.size]
  | node h sz k v l r ihl ihr =>
    rcases hw with ⟨hsz, hwl, hwr⟩
    rcases ha with ⟨_, hlr, hrl, hal, har⟩
    have ihL := ihl hwl hal
    have ihR := ihr hwr har
    dsimp only [PersistentSizeTree.height, PersistentSizeTree.size]
    rw [hsz]
    set H := 1 + max l.height r.height
    by_cases hpar : H % 2 = 0
    · have hm : 1 ≤ H / 2 := by omega
      have hH_eq : (H + 1) / 2 = H / 2 := by omega
      rw [hH_eq]
      have hmax : l.height = 2 * (H / 2) - 1 ∨ r.height = 2 * (H / 2) - 1 := by omega
      rcases hmax with hL_eq | hR_eq
      · have hdivL : (l.height + 1) / 2 = H / 2 := by omega
        rw [hdivL] at ihL
        omega
      · have hdivR : (r.height + 1) / 2 = H / 2 := by omega
        rw [hdivR] at ihR
        omega
    · set m := H / 2
      have hH_eq : (H + 1) / 2 = m + 1 := by omega
      rw [hH_eq]
      by_cases hm0 : m = 0
      · rw [hm0]
        omega
      · have hdivL : m ≤ (l.height + 1) / 2 := by omega
        have hdivR : m ≤ (r.height + 1) / 2 := by omega
        have hpowL : 2 ^ m ≤ l.size + 1 :=
          le_trans (Nat.pow_le_pow_right (by omega) hdivL) ihL
        have hpowR : 2 ^ m ≤ r.size + 1 :=
          le_trans (Nat.pow_le_pow_right (by omega) hdivR) ihR
        have hpow_succ : 2 ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
        omega

private theorem avl_height_le_two_log {κ α : Type} {t : PersistentSizeTree κ α}
    (hw : t.WellSized) (ha : t.IsAVL) :
    t.height ≤ 2 * Nat.log 2 (t.size + 1) := by
  have hpow := avl_pow_le_size_succ hw ha
  have hlog := le_nat_log2_of_pow_le ((t.height + 1) / 2) (t.size + 1) hpow
  omega

private theorem lookupWithSteps_spec {κ α : Type} [LinearOrder κ]
    {t : PersistentSizeTree κ α}
    (hpw : (t.toList.map Prod.fst).Pairwise (· < ·)) (k : κ) :
    (∀ v : α, (t.lookupWithSteps k).1 = some v ↔ (k, v) ∈ t.toList) ∧
    (t.lookupWithSteps k).2 ≤ t.height + 1 := by
  induction t with
  | nil =>
    simp [PersistentSizeTree.lookupWithSteps, PersistentSizeTree.toList, PersistentSizeTree.height]
  | node h sz k₀ v₀ l r ihl ihr =>
    rcases pairwise_lt_split hpw with ⟨hpwL, hpwR, hLk, hkR⟩
    dsimp only [PersistentSizeTree.lookupWithSteps, PersistentSizeTree.height]
    by_cases hlt : k < k₀
    · rw [if_pos hlt]
      dsimp only
      rcases ihl hpwL with ⟨ih1, ih2⟩
      refine ⟨fun v => ?_, by omega⟩
      rw [ih1 v]
      simp only [PersistentSizeTree.toList, List.mem_append, List.mem_singleton]
      constructor
      · intro hv
        exact Or.inl (Or.inl hv)
      · rintro ((hv | hkv) | hvR)
        · exact hv
        · injection hkv with hk_eq _
          subst hk_eq
          exact absurd hlt (lt_irrefl _)
        · exact absurd (lt_trans hlt (hkR (k, v) hvR)) (lt_irrefl _)
    · rw [if_neg hlt]
      by_cases hgt : k₀ < k
      · rw [if_pos hgt]
        dsimp only
        rcases ihr hpwR with ⟨ih1, ih2⟩
        refine ⟨fun v => ?_, by omega⟩
        rw [ih1 v]
        simp only [PersistentSizeTree.toList, List.mem_append, List.mem_singleton]
        constructor
        · intro hv
          exact Or.inr hv
        · rintro ((hvL | hkv) | hvR)
          · exact absurd (lt_trans (hLk (k, v) hvL) hgt) (lt_irrefl _)
          · injection hkv with hk_eq _
            subst hk_eq
            exact absurd hgt (lt_irrefl _)
          · exact hvR
      · rw [if_neg hgt]
        have heq : k = k₀ := le_antisymm (not_lt.mp hgt) (not_lt.mp hlt)
        subst heq
        refine ⟨fun v => ?_, by omega⟩
        simp only [Option.some.injEq, PersistentSizeTree.toList, List.mem_append,
          List.mem_singleton, Prod.mk.injEq, true_and]
        constructor
        · rintro rfl
          exact Or.inl (Or.inr rfl)
        · rintro ((hvL | rfl) | hvR)
          · exact absurd (hLk (k, v) hvL) (lt_irrefl _)
          · rfl
          · exact absurd (hkR (k, v) hvR) (lt_irrefl _)

private theorem selectByRankWithSteps_spec {κ α : Type}
    {t : PersistentSizeTree κ α} (hw : t.WellSized)
    (rk : ℕ) (hrk : rk < t.size) :
    (t.selectByRankWithSteps rk).1 = t.toList[rk]? ∧
    (t.selectByRankWithSteps rk).1.isSome = true ∧
    (t.selectByRankWithSteps rk).2 ≤ t.height + 1 := by
  induction t generalizing rk with
  | nil =>
    simp [PersistentSizeTree.size] at hrk
  | node h sz k₀ v₀ l r ihl ihr =>
    rcases hw with ⟨hsz, hwl, hwr⟩
    have hlenL : l.size = l.toList.length := size_eq_toList_length hwl
    have hlenR : r.size = r.toList.length := size_eq_toList_length hwr
    have hrk_sz : rk < l.size + 1 + r.size := by
      simpa [PersistentSizeTree.size, hsz] using hrk
    dsimp only [PersistentSizeTree.selectByRankWithSteps, PersistentSizeTree.toList,
      PersistentSizeTree.height]
    by_cases hlt : rk < l.size
    · rw [if_pos hlt]
      rcases ihl hwl rk hlt with ⟨ih1, ih2, ih3⟩
      refine ⟨?_, ih2, by omega⟩
      rw [ih1, List.append_assoc, List.getElem?_append_left (by omega)]
    · rw [if_neg hlt]
      by_cases heq : rk = l.size
      · rw [if_pos heq]
        subst heq
        refine ⟨?_, rfl, by omega⟩
        rw [List.append_assoc, List.getElem?_append_right (by omega)]
        simp [hlenL]
      · rw [if_neg heq]
        have hsub : rk - l.size - 1 < r.size := by omega
        rcases ihr hwr (rk - l.size - 1) hsub with ⟨ih1, ih2, ih3⟩
        refine ⟨?_, ih2, by omega⟩
        rw [ih1, List.getElem?_append_right (by simp [hlenL]; omega)]
        congr 1
        simp [hlenL]
        omega

private def insertAVL {κ α : Type} [LinearOrder κ] :
    PersistentSizeTree κ α → κ → α → PersistentSizeTree κ α × ℕ
  | .nil, k, v => (mkNode k v .nil .nil, 1)
  | .node _ _ k₀ v₀ l r, k, v =>
      if k < k₀ then
        let sub := insertAVL l k v
        (balance k₀ v₀ sub.1 r, sub.2 + 1)
      else if k₀ < k then
        let sub := insertAVL r k v
        (balance k₀ v₀ l sub.1, sub.2 + 1)
      else
        (mkNode k v l r, 1)

private theorem insertAVL_spec {κ α : Type} [LinearOrder κ]
    {t : PersistentSizeTree κ α}
    (hw : t.WellSized) (ha : t.IsAVL)
    (hpw : (t.toList.map Prod.fst).Pairwise (· < ·))
    (k : κ) (v : α) :
    (insertAVL t k v).1.WellSized ∧
    (insertAVL t k v).1.IsAVL ∧
    ((insertAVL t k v).1.toList.map Prod.fst).Pairwise (· < ·) ∧
    (∀ kv : κ × α, kv ∈ (insertAVL t k v).1.toList ↔
      kv = (k, v) ∨ (kv.1 ≠ k ∧ kv ∈ t.toList)) ∧
    t.height ≤ (insertAVL t k v).1.height ∧
    (insertAVL t k v).1.height ≤ t.height + 1 ∧
    (insertAVL t k v).2 ≤ t.height + 1 := by
  induction t with
  | nil =>
    dsimp only [insertAVL]
    refine ⟨mkNode_wellSized k v trivial trivial,
      mkNode_isAVL k v trivial trivial (by simp [PersistentSizeTree.height])
        (by simp [PersistentSizeTree.height]),
      by simp [mkNode_toList, PersistentSizeTree.toList],
      fun kv => by simp [mkNode_toList, PersistentSizeTree.toList],
      by simp [mkNode_height, PersistentSizeTree.height],
      by simp [mkNode_height, PersistentSizeTree.height],
      by simp [PersistentSizeTree.height]⟩
  | node h sz k₀ v₀ l r ihl ihr =>
    rcases hw with ⟨_, hwl, hwr⟩
    rcases ha with ⟨_, hlr, hrl, hal, har⟩
    rcases pairwise_lt_split hpw with ⟨hpwL, hpwR, hLk, hkR⟩
    dsimp only [insertAVL, PersistentSizeTree.height]
    by_cases hlt : k < k₀
    · rw [if_pos hlt]
      dsimp only
      rcases ihl hwl hal hpwL with ⟨hwS, haS, hpwS, hmemS, hhlo, hhhi, hstS⟩
      rcases balance_spec k₀ v₀ hwS hwr haS har (by omega) (by omega) with
        ⟨hwB, haB, hlistB, hh1, hh2, hheq⟩
      have hLk' : ∀ kv ∈ (insertAVL l k v).1.toList, kv.1 < k₀ := by
        intro kv hkv
        rcases (hmemS kv).mp hkv with rfl | ⟨_, hkvL⟩
        · exact hlt
        · exact hLk kv hkvL
      refine ⟨hwB, haB, ?_, ?_, ?_, ?_, by omega⟩
      · rw [hlistB]
        exact pairwise_lt_node hpwS hpwR hLk' hkR
      · intro kv
        rw [hlistB]
        simp only [PersistentSizeTree.toList, List.mem_append, List.mem_singleton, hmemS kv]
        constructor
        · rintro (((rfl | ⟨hne, hkvL⟩) | rfl) | hkvR)
          · exact Or.inl rfl
          · exact Or.inr ⟨hne, Or.inl (Or.inl hkvL)⟩
          · exact Or.inr ⟨ne_of_gt hlt, Or.inl (Or.inr rfl)⟩
          · exact Or.inr ⟨ne_of_gt (lt_trans hlt (hkR kv hkvR)), Or.inr hkvR⟩
        · rintro (rfl | ⟨hne, (hkvL | hkv0) | hkvR⟩)
          · exact Or.inl (Or.inl (Or.inl rfl))
          · exact Or.inl (Or.inl (Or.inr ⟨hne, hkvL⟩))
          · exact Or.inl (Or.inr hkv0)
          · exact Or.inr hkvR
      · by_cases hb1 : (insertAVL l k v).1.height ≤ r.height + 1 ∧
            r.height ≤ (insertAVL l k v).1.height + 1
        · have := hheq hb1.1 hb1.2
          omega
        · omega
      · omega
    · rw [if_neg hlt]
      by_cases hgt : k₀ < k
      · rw [if_pos hgt]
        dsimp only
        rcases ihr hwr har hpwR with ⟨hwS, haS, hpwS, hmemS, hhlo, hhhi, hstS⟩
        rcases balance_spec k₀ v₀ hwl hwS hal haS (by omega) (by omega) with
          ⟨hwB, haB, hlistB, hh1, hh2, hheq⟩
        have hkR' : ∀ kv ∈ (insertAVL r k v).1.toList, k₀ < kv.1 := by
          intro kv hkv
          rcases (hmemS kv).mp hkv with rfl | ⟨_, hkvR⟩
          · exact hgt
          · exact hkR kv hkvR
        refine ⟨hwB, haB, ?_, ?_, ?_, ?_, by omega⟩
        · rw [hlistB]
          exact pairwise_lt_node hpwL hpwS hLk hkR'
        · intro kv
          rw [hlistB]
          simp only [PersistentSizeTree.toList, List.mem_append, List.mem_singleton, hmemS kv]
          constructor
          · rintro ((hkvL | rfl) | (rfl | ⟨hne, hkvR⟩))
            · exact Or.inr ⟨ne_of_lt (lt_trans (hLk kv hkvL) hgt), Or.inl (Or.inl hkvL)⟩
            · exact Or.inr ⟨ne_of_lt hgt, Or.inl (Or.inr rfl)⟩
            · exact Or.inl rfl
            · exact Or.inr ⟨hne, Or.inr hkvR⟩
          · rintro (rfl | ⟨hne, (hkvL | hkv0) | hkvR⟩)
            · exact Or.inr (Or.inl rfl)
            · exact Or.inl (Or.inl hkvL)
            · exact Or.inl (Or.inr hkv0)
            · exact Or.inr (Or.inr ⟨hne, hkvR⟩)
        · by_cases hb1 : l.height ≤ (insertAVL r k v).1.height + 1 ∧
              (insertAVL r k v).1.height ≤ l.height + 1
          · have := hheq hb1.1 hb1.2
            omega
          · omega
        · omega
      · rw [if_neg hgt]
        have heq : k = k₀ := le_antisymm (not_lt.mp hgt) (not_lt.mp hlt)
        subst heq
        refine ⟨mkNode_wellSized k v hwl hwr, mkNode_isAVL k v hal har hlr hrl, ?_, ?_,
          by simp [mkNode_height], by simp [mkNode_height], by omega⟩
        · rw [mkNode_toList]
          exact pairwise_lt_node hpwL hpwR hLk hkR
        · intro kv
          rw [mkNode_toList]
          simp only [PersistentSizeTree.toList, List.mem_append, List.mem_singleton]
          constructor
          · rintro ((hkvL | rfl) | hkvR)
            · exact Or.inr ⟨ne_of_lt (hLk kv hkvL), Or.inl (Or.inl hkvL)⟩
            · exact Or.inl rfl
            · exact Or.inr ⟨ne_of_gt (hkR kv hkvR), Or.inr hkvR⟩
          · rintro (rfl | ⟨hne, (hkvL | rfl) | hkvR⟩)
            · exact Or.inl (Or.inr rfl)
            · exact Or.inl (Or.inl hkvL)
            · exact absurd rfl hne
            · exact Or.inr hkvR

private def extractMin {κ α : Type} :
    PersistentSizeTree κ α → κ → α → PersistentSizeTree κ α →
      (κ × α) × PersistentSizeTree κ α × ℕ
  | .nil, k, v, r => ((k, v), r, 1)
  | .node _ _ lk lv ll lr, k, v, r =>
      let res := extractMin ll lk lv lr
      (res.1, balance k v res.2.1 r, res.2.2 + 1)

private theorem extractMin_spec {κ α : Type}
    (l : PersistentSizeTree κ α) (k : κ) (v : α) (r : PersistentSizeTree κ α)
    (hwl : l.WellSized) (hwr : r.WellSized)
    (hal : l.IsAVL) (har : r.IsAVL)
    (hlr : l.height ≤ r.height + 1) (hrl : r.height ≤ l.height + 1) :
    (extractMin l k v r).2.1.WellSized ∧
    (extractMin l k v r).2.1.IsAVL ∧
    (extractMin l k v r).1 :: (extractMin l k v r).2.1.toList =
      l.toList ++ [(k, v)] ++ r.toList ∧
    1 + max l.height r.height ≤ (extractMin l k v r).2.1.height + 1 ∧
    (extractMin l k v r).2.1.height ≤ 1 + max l.height r.height ∧
    (extractMin l k v r).2.2 ≤ 1 + max l.height r.height := by
  induction l generalizing k v r with
  | nil =>
    dsimp only [extractMin, PersistentSizeTree.toList, PersistentSizeTree.height]
    refine ⟨hwr, har, rfl, by omega, by omega, by omega⟩
  | node lh lsz lk lv ll lr ihll _ =>
    rcases hwl with ⟨_, hwll, hwlr⟩
    rcases hal with ⟨_, hll_lr, hlr_ll, hall, halr⟩
    rcases ihll lk lv lr hwll hwlr hall halr hll_lr hlr_ll with
      ⟨hwM, haM, hlistM, hhloM, hhhiM, hstM⟩
    dsimp only [extractMin, PersistentSizeTree.height] at *
    rcases balance_spec k v hwM hwr haM har (by omega) (by omega) with
      ⟨hwB, haB, hlistB, hh1, hh2, hheq⟩
    refine ⟨hwB, haB, ?_, ?_, ?_, by omega⟩
    · rw [hlistB, ← List.cons_append, ← List.cons_append, hlistM]
      rfl
    · by_cases hb1 : (extractMin ll lk lv lr).2.1.height ≤ r.height + 1 ∧
          r.height ≤ (extractMin ll lk lv lr).2.1.height + 1
      · have := hheq hb1.1 hb1.2
        omega
      · omega
    · by_cases hb1 : (extractMin ll lk lv lr).2.1.height ≤ r.height + 1 ∧
          r.height ≤ (extractMin ll lk lv lr).2.1.height + 1
      · have := hheq hb1.1 hb1.2
        omega
      · omega

private def eraseAVL {κ α : Type} [LinearOrder κ] :
    PersistentSizeTree κ α → κ → PersistentSizeTree κ α × ℕ
  | .nil, _ => (.nil, 1)
  | .node _ _ k₀ v₀ l r, k =>
      if k < k₀ then
        let sub := eraseAVL l k
        (balance k₀ v₀ sub.1 r, sub.2 + 1)
      else if k₀ < k then
        let sub := eraseAVL r k
        (balance k₀ v₀ l sub.1, sub.2 + 1)
      else
        match r with
        | .nil => (l, 1)
        | .node _ _ rk rv rl rr =>
            let m := extractMin rl rk rv rr
            (balance m.1.1 m.1.2 l m.2.1, m.2.2 + 1)

private theorem eraseAVL_spec {κ α : Type} [LinearOrder κ]
    {t : PersistentSizeTree κ α}
    (hw : t.WellSized) (ha : t.IsAVL)
    (hpw : (t.toList.map Prod.fst).Pairwise (· < ·))
    (k : κ) :
    (eraseAVL t k).1.WellSized ∧
    (eraseAVL t k).1.IsAVL ∧
    ((eraseAVL t k).1.toList.map Prod.fst).Pairwise (· < ·) ∧
    (∀ kv : κ × α, kv ∈ (eraseAVL t k).1.toList ↔ kv ∈ t.toList ∧ kv.1 ≠ k) ∧
    t.height ≤ (eraseAVL t k).1.height + 1 ∧
    (eraseAVL t k).1.height ≤ t.height ∧
    (eraseAVL t k).2 ≤ t.height + 1 := by
  induction t with
  | nil =>
    simp [eraseAVL, PersistentSizeTree.WellSized, PersistentSizeTree.IsAVL,
      PersistentSizeTree.toList, PersistentSizeTree.height]
  | node h sz k₀ v₀ l r ihl ihr =>
    rcases hw with ⟨_, hwl, hwr⟩
    rcases ha with ⟨_, hlr, hrl, hal, har⟩
    rcases pairwise_lt_split hpw with ⟨hpwL, hpwR, hLk, hkR⟩
    dsimp only [eraseAVL, PersistentSizeTree.height]
    by_cases hlt : k < k₀
    · rw [if_pos hlt]
      dsimp only
      rcases ihl hwl hal hpwL with ⟨hwS, haS, hpwS, hmemS, hhlo, hhhi, hstS⟩
      rcases balance_spec k₀ v₀ hwS hwr haS har (by omega) (by omega) with
        ⟨hwB, haB, hlistB, hh1, hh2, hheq⟩
      have hLk' : ∀ kv ∈ (eraseAVL l k).1.toList, kv.1 < k₀ :=
        fun kv hkv => hLk kv ((hmemS kv).mp hkv).1
      refine ⟨hwB, haB, ?_, ?_, ?_, ?_, by omega⟩
      · rw [hlistB]
        exact pairwise_lt_node hpwS hpwR hLk' hkR
      · intro kv
        rw [hlistB]
        simp only [PersistentSizeTree.toList, List.mem_append, List.mem_singleton, hmemS kv]
        constructor
        · rintro ((⟨hkvL, hne⟩ | rfl) | hkvR)
          · exact ⟨Or.inl (Or.inl hkvL), hne⟩
          · exact ⟨Or.inl (Or.inr rfl), ne_of_gt hlt⟩
          · exact ⟨Or.inr hkvR, ne_of_gt (lt_trans hlt (hkR kv hkvR))⟩
        · rintro ⟨(hkvL | rfl) | hkvR, hne⟩
          · exact Or.inl (Or.inl ⟨hkvL, hne⟩)
          · exact Or.inl (Or.inr rfl)
          · exact Or.inr hkvR
      · by_cases hb1 : (eraseAVL l k).1.height ≤ r.height + 1 ∧
            r.height ≤ (eraseAVL l k).1.height + 1
        · have := hheq hb1.1 hb1.2
          omega
        · omega
      · by_cases hb1 : (eraseAVL l k).1.height ≤ r.height + 1 ∧
            r.height ≤ (eraseAVL l k).1.height + 1
        · have := hheq hb1.1 hb1.2
          omega
        · omega
    · rw [if_neg hlt]
      by_cases hgt : k₀ < k
      · rw [if_pos hgt]
        dsimp only
        rcases ihr hwr har hpwR with ⟨hwS, haS, hpwS, hmemS, hhlo, hhhi, hstS⟩
        rcases balance_spec k₀ v₀ hwl hwS hal haS (by omega) (by omega) with
          ⟨hwB, haB, hlistB, hh1, hh2, hheq⟩
        have hkR' : ∀ kv ∈ (eraseAVL r k).1.toList, k₀ < kv.1 :=
          fun kv hkv => hkR kv ((hmemS kv).mp hkv).1
        refine ⟨hwB, haB, ?_, ?_, ?_, ?_, by omega⟩
        · rw [hlistB]
          exact pairwise_lt_node hpwL hpwS hLk hkR'
        · intro kv
          rw [hlistB]
          simp only [PersistentSizeTree.toList, List.mem_append, List.mem_singleton, hmemS kv]
          constructor
          · rintro ((hkvL | rfl) | ⟨hkvR, hne⟩)
            · exact ⟨Or.inl (Or.inl hkvL), ne_of_lt (lt_trans (hLk kv hkvL) hgt)⟩
            · exact ⟨Or.inl (Or.inr rfl), ne_of_lt hgt⟩
            · exact ⟨Or.inr hkvR, hne⟩
          · rintro ⟨(hkvL | rfl) | hkvR, hne⟩
            · exact Or.inl (Or.inl hkvL)
            · exact Or.inl (Or.inr rfl)
            · exact Or.inr ⟨hkvR, hne⟩
        · by_cases hb1 : l.height ≤ (eraseAVL r k).1.height + 1 ∧
              (eraseAVL r k).1.height ≤ l.height + 1
          · have := hheq hb1.1 hb1.2
            omega
          · omega
        · by_cases hb1 : l.height ≤ (eraseAVL r k).1.height + 1 ∧
              (eraseAVL r k).1.height ≤ l.height + 1
          · have := hheq hb1.1 hb1.2
            omega
          · omega
      · rw [if_neg hgt]
        have heq : k = k₀ := le_antisymm (not_lt.mp hgt) (not_lt.mp hlt)
        subst heq
        cases r with
        | nil =>
          dsimp only [PersistentSizeTree.height, PersistentSizeTree.toList] at hrl ⊢
          refine ⟨hwl, hal, hpwL, ?_, by omega, by omega, by omega⟩
          intro kv
          simp only [List.append_nil, List.mem_append, List.mem_singleton]
          constructor
          · intro hkvL
            exact ⟨Or.inl hkvL, ne_of_lt (hLk kv hkvL)⟩
          · rintro ⟨hkvL | rfl, hne⟩
            · exact hkvL
            · exact absurd rfl hne
        | node rh rsz rk rv rl rr =>
          dsimp only
          rcases hwr with ⟨_, hwrl, hwrr⟩
          rcases har with ⟨_, hrl_rr, hrr_rl, harl, harr⟩
          rcases extractMin_spec rl rk rv rr hwrl hwrr harl harr hrl_rr hrr_rl with
            ⟨hwM, haM, hlistM, hhloM, hhhiM, hstM⟩
          dsimp only [PersistentSizeTree.height] at hlr hrl ⊢
          rcases balance_spec (extractMin rl rk rv rr).1.1 (extractMin rl rk rv rr).1.2
              hwl hwM hal haM (by omega) (by omega) with
            ⟨hwB, haB, hlistB, hh1, hh2, hheq⟩
          have hlist_eq :
              (balance (extractMin rl rk rv rr).1.1 (extractMin rl rk rv rr).1.2
                l (extractMin rl rk rv rr).2.1).toList =
              l.toList ++ (PersistentSizeTree.node rh rsz rk rv rl rr).toList := by
            rw [hlistB, List.append_assoc, List.singleton_append, Prod.mk.eta, hlistM]
            rfl
          refine ⟨hwB, haB, ?_, ?_, ?_, ?_, by omega⟩
          · rw [hlist_eq, List.map_append]
            exact pairwise_lt_append hpwL hpwR (fun a ha b hb => by
              rcases List.mem_map.mp ha with ⟨lkv, hlkv, rfl⟩
              rcases List.mem_map.mp hb with ⟨rkv, hrkv, rfl⟩
              exact lt_trans (hLk lkv hlkv) (hkR rkv hrkv))
          · intro kv
            rw [hlist_eq]
            change kv ∈ l.toList ++ (PersistentSizeTree.node rh rsz rk rv rl rr).toList ↔
              kv ∈ l.toList ++ [(k, v₀)] ++ (PersistentSizeTree.node rh rsz rk rv rl rr).toList ∧
                kv.1 ≠ k
            simp only [List.mem_append, List.mem_singleton]
            constructor
            · rintro (hkvL | hkvR)
              · exact ⟨Or.inl (Or.inl hkvL), ne_of_lt (hLk kv hkvL)⟩
              · exact ⟨Or.inr hkvR, ne_of_gt (hkR kv hkvR)⟩
            · rintro ⟨(hkvL | rfl) | hkvR, hne⟩
              · exact Or.inl hkvL
              · exact absurd rfl hne
              · exact Or.inr hkvR
          · by_cases hb1 : l.height ≤ (extractMin rl rk rv rr).2.1.height + 1 ∧
                (extractMin rl rk rv rr).2.1.height ≤ l.height + 1
            · have := hheq hb1.1 hb1.2
              omega
            · omega
          · by_cases hb1 : l.height ≤ (extractMin rl rk rv rr).2.1.height + 1 ∧
                (extractMin rl rk rv rr).2.1.height ≤ l.height + 1
            · have := hheq hb1.1 hb1.2
              omega
            · omega

end AVLHelpers

theorem claim_C_2_scans_part1 :
    ∃ C_tree : ℕ, 1 ≤ C_tree ∧
      ∀ (κ α_val : Type) [LinearOrder κ],
        ∃ (insertTree : PersistentSizeTree κ α_val → κ → α_val → PersistentSizeTree κ α_val × ℕ)
          (eraseTree : PersistentSizeTree κ α_val → κ → PersistentSizeTree κ α_val × ℕ),
          IsPersistentBalancedSizeTreeOps C_tree κ α_val insertTree eraseTree := by
  refine ⟨2, by omega, fun κ α_val _ => ⟨insertAVL, eraseAVL, ?_⟩⟩
  refine ⟨?_, ?_⟩
  · exact ⟨trivial, trivial, List.Pairwise.nil, by simp [PersistentSizeTree.height]⟩
  · intro t hwf
    rcases hwf with ⟨hw, ha, hpw, hh⟩
    refine ⟨size_eq_toList_length hw, ?_, ?_, ?_, ?_⟩
    · intro k
      rcases lookupWithSteps_spec hpw k with ⟨hm, hst⟩
      exact ⟨hm, by omega⟩
    · intro rk
      rcases selectByRankWithSteps_spec hw rk.val rk.isLt with ⟨h1, h2, h3⟩
      exact ⟨h1, h2, by omega⟩
    · intro k v
      rcases insertAVL_spec hw ha hpw k v with ⟨hw', ha', hpw', hmem', _, _, hst'⟩
      exact ⟨⟨hw', ha', hpw', avl_height_le_two_log hw' ha'⟩, hmem', by omega⟩
    · intro k
      rcases eraseAVL_spec hw ha hpw k with ⟨hw', ha', hpw', hmem', _, _, hst'⟩
      exact ⟨⟨hw', ha', hpw', avl_height_le_two_log hw' ha'⟩, hmem', by omega⟩

end UL
