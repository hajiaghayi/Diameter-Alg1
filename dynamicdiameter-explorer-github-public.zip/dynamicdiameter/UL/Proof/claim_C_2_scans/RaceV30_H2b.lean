import UL.Proof.claim_C_2_scans.H2a_Matching
set_option autoImplicit false

namespace UL.C2ScansRaceV30
open UL

/-! ### Helper functions for two-scan background invariants and step counting -/

open Classical in
noncomputable def listCoreCount {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (prov : ChainNode d)
    (L : List (ι × ℕ)) : ℕ :=
  L.countP (fun r => decide (pts r.1 ∈ coreBall prov.o prov.V))

noncomputable def listMaxR {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (prov : ChainNode d)
    (L : List (ι × ℕ)) : ℝ :=
  (L.map (fun r => ‖pts r.1 - prov.o‖)).foldr max 0

open Classical in
noncomputable def clsRecords {d : ℕ} {ι IdxState : Type}
    (st : TwoScanLevelState d ι IdxState) : Finset (ι × ℕ) :=
  st.activeRecords.filter (fun r => r.2 ∈ st.classified)

open Classical in
noncomputable def clsSet {d : ℕ} {ι IdxState : Type}
    (st : TwoScanLevelState d ι IdxState) : Finset ι :=
  (clsRecords st).image Prod.fst

def evInsInc {ι : Type} : PoolUpdateEvent ι → ℕ
  | .externalInsert _ => 1
  | _ => 0

def remBgSteps {d : ℕ} {ι : Type} (M2 : ℕ) : TwoScanPhase d ι → ℕ
  | .scan1 rem _ _ => rem.length + M2 + 2
  | .scan2 _ _ rem => rem.length + 1
  | .ready _ => 0

open Classical in
noncomputable def nextBgStep {d : ℕ} {ι IdxState : Type}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (n m : ℕ) (A_n : ℝ) (prov : ChainNode d)
    (optParams : Option LocalScaleParams)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (st : TwoScanLevelState d ι IdxState) : Option (TwoScanLevelState d ι IdxState) :=
  match st.phase with
  | .scan1 (rec :: rest) coreCnt maxR =>
      some (scan1RecordNextState pts n A_n prov rec rest coreCnt maxR st)
  | .scan1 [] coreCnt maxR =>
      some (fixBallSnapshotNextState α n m A_n prov coreCnt maxR st.activeRecords.toList st)
  | .scan2 ball scan2Snap (rec :: rest) =>
      some (scan2RecordNextState pts n A_n optParams dynSearch ball scan2Snap rec rest st)
  | .scan2 ball _ [] =>
      some { st with
        phase := .ready ball
        cumWork := st.cumWork + (1 + Real.log (n : ℝ)) * A_n }
  | .ready _ => none

open Classical in
def PhaseInv {d : ℕ} {ι IdxState : Type}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (optParams : Option LocalScaleParams)
    (birthSnapshotList : List (ι × ℕ)) (S_birth : Finset ι) (prov : ChainNode d)
    (insCount : ℕ) (st : TwoScanLevelState d ι IdxState) : Prop :=
  let fixedBall := applyBirthCoreFallback α pts S_birth prov
  match st.phase with
  | .scan1 rem coreCnt maxR =>
      coreCnt + listCoreCount pts prov rem = listCoreCount pts prov birthSnapshotList ∧
      max maxR (listMaxR pts prov rem) = listMaxR pts prov birthSnapshotList ∧
      0 ≤ maxR ∧
      (∀ r ∈ st.activeRecords, r ∈ rem.toFinset ∨ r.2 ∈ st.heapIndexed) ∧
      st.classified = ∅ ∧
      st.childPool = ∅ ∧
      st.localMatchings = fun _ => LocalMatchingState.empty ι
  | .scan2 ball snap rem =>
      ball = fixedBall ∧
      st.radiusDict = st.activeRecords ∧
      snap.length ≤ S_birth.card + insCount ∧
      rem.length ≤ snap.length ∧
      (∀ r ∈ st.activeRecords, r ∈ rem.toFinset ∨ r.2 ∈ st.classified) ∧
      st.childPool = (clsRecords st).filter (fun r => pts r.1 ∉ coreBall fixedBall.o fixedBall.V) ∧
      (∀ params : LocalScaleParams, optParams = some params → 0 < fixedBall.V →
        ∀ cfg ∈ params.retainedConfigs fixedBall.V,
          (st.localMatchings cfg).SatisfiesInvariant pts
            (params.leftVertices pts fixedBall.o fixedBall.V (clsSet st) cfg.j)
            (params.rightVertices pts fixedBall.o fixedBall.V (clsSet st) cfg.k)
            (params.weakEdges pts fixedBall.o fixedBall.V (clsSet st) cfg.j cfg.k cfg.ℓ)
            (params.strongEdges pts fixedBall.o fixedBall.V (clsSet st) cfg.j cfg.k cfg.ℓ))
  | .ready ball =>
      ball = fixedBall ∧
      st.radiusDict = st.activeRecords ∧
      (∀ r ∈ st.activeRecords, r.2 ∈ st.classified) ∧
      st.childPool = (clsRecords st).filter (fun r => pts r.1 ∉ coreBall fixedBall.o fixedBall.V) ∧
      (∀ params : LocalScaleParams, optParams = some params → 0 < fixedBall.V →
        ∀ cfg ∈ params.retainedConfigs fixedBall.V,
          (st.localMatchings cfg).SatisfiesInvariant pts
            (params.leftVertices pts fixedBall.o fixedBall.V (clsSet st) cfg.j)
            (params.rightVertices pts fixedBall.o fixedBall.V (clsSet st) cfg.k)
            (params.weakEdges pts fixedBall.o fixedBall.V (clsSet st) cfg.j cfg.k cfg.ℓ)
            (params.strongEdges pts fixedBall.o fixedBall.V (clsSet st) cfg.j cfg.k cfg.ℓ))

open Classical in
def LevelInv {d : ℕ} {ι IdxState : Type}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (optParams : Option LocalScaleParams)
    (birthSnapshotList : List (ι × ℕ)) (S_birth : Finset ι) (prov : ChainNode d)
    (S_cur : Finset ι) (insCount : ℕ) (st : TwoScanLevelState d ι IdxState) : Prop :=
  IsValidLifetimePool S_cur st.activeRecords st.nextLife ∧
  st.activeRecords.card ≤ S_birth.card + insCount ∧
  st.radiusDict ⊆ st.activeRecords ∧
  (∀ r ∈ st.activeRecords, r ∈ st.radiusDict ↔ r.2 ∈ st.heapIndexed) ∧
  (∀ ℓ ∈ st.heapIndexed, ℓ < st.nextLife) ∧
  (∀ ℓ ∈ st.classified, ℓ < st.nextLife) ∧
  PhaseInv α pts optParams birthSnapshotList S_birth prov insCount st

/-! ### 1. Node work factor and birth fallback lemmas -/

theorem validNodeWorkFactor_bounds {n : ℕ} {optParams : Option LocalScaleParams}
    {P_search P_loc A_n : ℝ}
    (hn : 2 ≤ n) (hAn : 1 ≤ A_n) (hPloc : ValidNodeWorkFactor n optParams P_search P_loc) :
    1 ≤ P_loc ∧
    1 ≤ A_n * P_loc ∧
    0 ≤ (1 + Real.log (n : ℝ)) * A_n ∧
    (1 + Real.log (n : ℝ)) * A_n ≤ A_n * P_loc := by
  have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
  have hlog : 0 ≤ Real.log (n : ℝ) := Real.log_nonneg hn1
  unfold ValidNodeWorkFactor at hPloc
  rcases hPloc with ⟨hPs1, hPloc_b⟩
  have h1log_le : 1 + Real.log (n : ℝ) ≤ P_loc := by
    cases optParams with
    | none => exact hPloc_b
    | some params =>
      dsimp only at hPloc_b
      have hterm : 0 ≤ (((allShellConfigs params.m0 params.K params.J).card + 1 : ℕ) : ℝ) * P_search :=
        mul_nonneg (Nat.cast_nonneg _) (by linarith)
      linarith
  have hPloc1 : 1 ≤ P_loc := by linarith
  have hAP1 : 1 ≤ A_n * P_loc := by nlinarith
  have htw0 : 0 ≤ (1 + Real.log (n : ℝ)) * A_n := by nlinarith
  have htwhi : (1 + Real.log (n : ℝ)) * A_n ≤ A_n * P_loc := by nlinarith
  exact ⟨hPloc1, hAP1, htw0, htwhi⟩

open Classical in
theorem birthCoreFallback_props {d : ℕ} {ι : Type}
    {α : ℝ} (pts : ι → EuclideanSpace ℝ (Fin d))
    {S_birth : Finset ι} (prov : ChainNode d)
    (hα_le : α ≤ 1) (hNonempty : S_birth.Nonempty) :
    (applyBirthCoreFallback α pts S_birth prov).o = prov.o ∧
    PassesBirthCoreCheck α pts (applyBirthCoreFallback α pts S_birth prov) S_birth := by
  unfold applyBirthCoreFallback
  by_cases hPass : PassesBirthCoreCheck α pts prov S_birth
  · rw [if_pos hPass]
    exact ⟨rfl, hPass⟩
  · rw [if_neg hPass]
    refine ⟨rfl, ?_⟩
    unfold PassesBirthCoreCheck maxBirthRadiusBall ChainNode.core nodeCore
    dsimp only
    have hR0 : 0 ≤ nodeMaxRadius pts prov.o S_birth := by
      unfold nodeMaxRadius
      rw [dif_pos hNonempty]
      rcases hNonempty with ⟨x₀, hx₀⟩
      exact le_trans (norm_nonneg _) (Finset.le_sup' (fun i => ‖pts i - prov.o‖) hx₀)
    have hCoreEq : S_birth.filter (fun i => pts i ∈ coreBall prov.o ((nodeMaxRadius pts prov.o S_birth) ^ 2)) =
        S_birth := by
      apply Finset.filter_true_of_mem
      intro x hx
      unfold coreBall
      rw [Metric.mem_closedBall, dist_eq_norm, Real.sqrt_sq hR0]
      unfold nodeMaxRadius
      rw [dif_pos hNonempty]
      exact Finset.le_sup' (fun i => ‖pts i - prov.o‖) hx
    rw [hCoreEq]
    have hm0 : (0 : ℝ) ≤ (S_birth.card : ℝ) := Nat.cast_nonneg _
    nlinarith

/-! ### 2. Scan 1 list accumulator lemmas -/

private theorem listMaxR_nonneg {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (prov : ChainNode d)
    (L : List (ι × ℕ)) : 0 ≤ listMaxR pts prov L := by
  induction L with
  | nil => simp [listMaxR]
  | cons hd tl ih =>
    dsimp only [listMaxR, List.map_cons, List.foldr_cons]
    exact le_max_of_le_right ih

private theorem le_foldr_max_of_mem {x : ℝ} {xs : List ℝ} (hx : x ∈ xs) :
    x ≤ xs.foldr max 0 := by
  induction xs with
  | nil => cases hx
  | cons hd tl ih =>
    dsimp only [List.foldr_cons]
    rcases List.mem_cons.mp hx with rfl | htl
    · exact le_max_left _ _
    · exact le_max_of_le_right (ih htl)

private theorem foldr_max_le {xs : List ℝ} {B : ℝ} (h0 : 0 ≤ B)
    (hB : ∀ x ∈ xs, x ≤ B) : xs.foldr max 0 ≤ B := by
  induction xs with
  | nil => exact h0
  | cons hd tl ih =>
    dsimp only [List.foldr_cons]
    exact max_le (hB hd List.mem_cons_self) (ih (fun x hx => hB x (List.mem_cons_of_mem hd hx)))

open Classical in
theorem listCoreCount_eq_birthCoreCard {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (prov : ChainNode d)
    {birthSnapshotList : List (ι × ℕ)} {S_birth : Finset ι} {initNextLife : ℕ}
    (hNodup : birthSnapshotList.Nodup)
    (hPool : IsValidLifetimePool S_birth birthSnapshotList.toFinset initNextLife) :
    listCoreCount pts prov birthSnapshotList = (prov.core pts S_birth).card := by
  unfold listCoreCount ChainNode.core nodeCore
  have hCountEq : ∀ xs : List (ι × ℕ),
      xs.countP (fun r => decide (pts r.1 ∈ coreBall prov.o prov.V)) =
        (xs.filter (fun r => decide (pts r.1 ∈ coreBall prov.o prov.V))).length := by
    intro xs
    induction xs with
    | nil => rfl
    | cons hd tl ih =>
      rw [List.countP_cons, List.filter_cons]
      split_ifs <;> simp [ih]
  rw [hCountEq]
  have hFiltNodup : (birthSnapshotList.filter (fun r => decide (pts r.1 ∈ coreBall prov.o prov.V))).Nodup :=
    hNodup.filter _
  rw [← List.toFinset_card_of_nodup hFiltNodup]
  have hSetEq :
      (birthSnapshotList.filter (fun r => decide (pts r.1 ∈ coreBall prov.o prov.V))).toFinset =
        birthSnapshotList.toFinset.filter (fun r => pts r.1 ∈ coreBall prov.o prov.V) := by
    ext r
    simp only [List.mem_toFinset, List.mem_filter, Finset.mem_filter, decide_eq_true_eq]
  rw [hSetEq]
  have hImgEq :
      (birthSnapshotList.toFinset.filter (fun r => pts r.1 ∈ coreBall prov.o prov.V)).image Prod.fst =
        S_birth.filter (fun i => pts i ∈ coreBall prov.o prov.V) := by
    ext x
    simp only [Finset.mem_image, Finset.mem_filter]
    constructor
    · rintro ⟨r, ⟨hr_in, hr_core⟩, rfl⟩
      rw [← hPool.1]
      exact ⟨Finset.mem_image_of_mem Prod.fst hr_in, hr_core⟩
    · rintro ⟨hxS, hxCore⟩
      rw [← hPool.1] at hxS
      rcases Finset.mem_image.mp hxS with ⟨r, hr_in, rfl⟩
      exact ⟨r, ⟨hr_in, hxCore⟩, rfl⟩
  rw [← hImgEq]
  symm
  apply Finset.card_image_of_injOn
  exact hPool.2.1.mono (Finset.coe_subset.mpr (Finset.filter_subset _ _))

open Classical in
theorem listMaxR_eq_nodeMaxRadius {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (prov : ChainNode d)
    {birthSnapshotList : List (ι × ℕ)} {S_birth : Finset ι} {initNextLife : ℕ}
    (hPool : IsValidLifetimePool S_birth birthSnapshotList.toFinset initNextLife)
    (hNonempty : S_birth.Nonempty) :
    listMaxR pts prov birthSnapshotList = nodeMaxRadius pts prov.o S_birth := by
  unfold listMaxR nodeMaxRadius
  rw [dif_pos hNonempty]
  apply le_antisymm
  · apply foldr_max_le
    · rcases hNonempty with ⟨x₀, hx₀⟩
      exact le_trans (norm_nonneg _) (Finset.le_sup' (fun i => ‖pts i - prov.o‖) hx₀)
    · intro v hv
      rcases List.mem_map.mp hv with ⟨r, hr, rfl⟩
      have hr1 : r.1 ∈ S_birth := by
        rw [← hPool.1]
        exact Finset.mem_image_of_mem Prod.fst (List.mem_toFinset.mpr hr)
      exact Finset.le_sup' (fun i => ‖pts i - prov.o‖) hr1
  · apply Finset.sup'_le hNonempty
    intro x hx
    rw [← hPool.1] at hx
    rcases Finset.mem_image.mp hx with ⟨r, hr_tf, rfl⟩
    have hr_list : r ∈ birthSnapshotList := List.mem_toFinset.mp hr_tf
    exact le_foldr_max_of_mem (List.mem_map_of_mem hr_list)

open Classical in
theorem init_levelInv {d : ℕ} {ι IdxState : Type}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (optParams : Option LocalScaleParams)
    (birthSnapshotList : List (ι × ℕ)) (S_birth : Finset ι) (prov : ChainNode d)
    (initNextLife : ℕ) (initIdx : IdxState) (setupWork : ℝ)
    (hNodup : birthSnapshotList.Nodup)
    (hPool : IsValidLifetimePool S_birth birthSnapshotList.toFinset initNextLife) :
    LevelInv α pts optParams birthSnapshotList S_birth prov S_birth 0
      (initTwoScanLevelState d birthSnapshotList initNextLife initIdx setupWork) ∧
    birthSnapshotList.length = S_birth.card := by
  have hCardTf : birthSnapshotList.toFinset.card = S_birth.card := by
    rw [← hPool.1, Finset.card_image_of_injOn hPool.2.1]
  have hLen : birthSnapshotList.length = S_birth.card := by
    rw [← List.toFinset_card_of_nodup hNodup, hCardTf]
  refine ⟨?_, hLen⟩
  unfold LevelInv PhaseInv initTwoScanLevelState
  dsimp only
  refine ⟨hPool, by omega, Finset.empty_subset _, ?_, ?_, ?_, ?_⟩
  · intro r _
    simp
  · intro ℓ hℓ
    simp at hℓ
  · intro ℓ hℓ
    simp at hℓ
  · refine ⟨Nat.zero_add _, max_eq_right (listMaxR_nonneg pts prov birthSnapshotList),
      le_rfl, ?_, rfl, rfl, rfl⟩
    intro r hr
    exact Or.inl hr

/-! ### 3. Atomic classify / delete helper lemmas -/

open Classical in
private theorem clsSet_subset_pool {d : ℕ} {ι IdxState : Type}
    {S_cur : Finset ι} {st : TwoScanLevelState d ι IdxState}
    (hPool : IsValidLifetimePool S_cur st.activeRecords st.nextLife) :
    clsSet st ⊆ S_cur := by
  intro x hx
  unfold clsSet clsRecords at hx
  rcases Finset.mem_image.mp hx with ⟨r, hr, rfl⟩
  rw [← hPool.1]
  exact Finset.mem_image_of_mem Prod.fst (Finset.mem_of_mem_filter r hr)

open Classical in
private theorem classifyActiveRecordAtomically_spec {d : ℕ} {ι IdxState : Type}
    (h53 : S_clm_5_3_matching_invariant)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {n : ℕ} {A_n P_search P_loc : ℝ}
    {optParams : Option LocalScaleParams}
    {dynSearch : LocalDynamicSearchInterface d ι IdxState}
    (hn : 2 ≤ n) (hAn : 1 ≤ A_n)
    (hPloc : ValidNodeWorkFactor n optParams P_search P_loc)
    (hSearch : ∀ params : LocalScaleParams, optParams = some params →
      SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    {S_cur : Finset ι} (hCap : S_cur.card ≤ n)
    {ball : ChainNode d} {rec : ι × ℕ} {st : TwoScanLevelState d ι IdxState}
    (hPool : IsValidLifetimePool S_cur st.activeRecords st.nextLife)
    (hRecIn : rec ∈ st.activeRecords)
    (hRecNotCls : rec.2 ∉ st.classified)
    (hChild : st.childPool = (clsRecords st).filter (fun r => pts r.1 ∉ coreBall ball.o ball.V))
    (hMatch : ∀ params : LocalScaleParams, optParams = some params → 0 < ball.V →
      ∀ cfg ∈ params.retainedConfigs ball.V,
        (st.localMatchings cfg).SatisfiesInvariant pts
          (params.leftVertices pts ball.o ball.V (clsSet st) cfg.j)
          (params.rightVertices pts ball.o ball.V (clsSet st) cfg.k)
          (params.weakEdges pts ball.o ball.V (clsSet st) cfg.j cfg.k cfg.ℓ)
          (params.strongEdges pts ball.o ball.V (clsSet st) cfg.j cfg.k cfg.ℓ)) :
    let st' := classifyActiveRecordAtomically pts n A_n optParams dynSearch ball rec st
    st'.activeRecords = st.activeRecords ∧
    st'.nextLife = st.nextLife ∧
    st'.radiusDict = st.radiusDict ∧
    st'.heapIndexed = st.heapIndexed ∧
    st'.phase = st.phase ∧
    st'.classified = insert rec.2 st.classified ∧
    clsRecords st' = insert rec (clsRecords st) ∧
    clsSet st' = insert rec.1 (clsSet st) ∧
    st'.childPool = (clsRecords st').filter (fun r => pts r.1 ∉ coreBall ball.o ball.V) ∧
    0 ≤ st'.cumWork - st.cumWork ∧
    st'.cumWork - st.cumWork ≤ 6 * A_n * P_loc ∧
    (∀ params : LocalScaleParams, optParams = some params → 0 < ball.V →
      ∀ cfg ∈ params.retainedConfigs ball.V,
        (st'.localMatchings cfg).SatisfiesInvariant pts
          (params.leftVertices pts ball.o ball.V (clsSet st') cfg.j)
          (params.rightVertices pts ball.o ball.V (clsSet st') cfg.k)
          (params.weakEdges pts ball.o ball.V (clsSet st') cfg.j cfg.k cfg.ℓ)
          (params.strongEdges pts ball.o ball.V (clsSet st') cfg.j cfg.k cfg.ℓ)) := by
  rcases validNodeWorkFactor_bounds hn hAn hPloc with ⟨_, _, htw0, htwhi⟩
  have hClsRecEq :
      st.activeRecords.filter (fun r => r.2 ∈ insert rec.2 st.classified) =
        insert rec (clsRecords st) := by
    ext r
    simp only [clsRecords, Finset.mem_filter, Finset.mem_insert]
    constructor
    · rintro ⟨hrA, hrEq | hrC⟩
      · exact Or.inl (hPool.2.2.1 hrA hRecIn hrEq)
      · exact Or.inr ⟨hrA, hrC⟩
    · rintro (rfl | ⟨hrA, hrC⟩)
      · exact ⟨hRecIn, Or.inl rfl⟩
      · exact ⟨hrA, Or.inr hrC⟩
  have hClsSetEq :
      (insert rec (clsRecords st)).image Prod.fst = insert rec.1 (clsSet st) :=
    Finset.image_insert _ _ _
  have hNotMemClsSet : rec.1 ∉ clsSet st := by
    unfold clsSet clsRecords
    rintro hx
    rcases Finset.mem_image.mp hx with ⟨r, hr, hfst⟩
    rcases Finset.mem_filter.mp hr with ⟨hrA, hrC⟩
    have hEq : r = rec := hPool.2.1 hrA hRecIn hfst
    subst hEq
    exact hRecNotCls hrC
  have hInsSub : insert rec.1 (clsSet st) ⊆ S_cur := by
    intro x hx
    rcases Finset.mem_insert.mp hx with rfl | hxC
    · rw [← hPool.1]
      exact Finset.mem_image_of_mem Prod.fst hRecIn
    · exact clsSet_subset_pool hPool hxC
  have hInsCard : (insert rec.1 (clsSet st)).card ≤ n :=
    le_trans (Finset.card_le_card hInsSub) hCap
  have hChildEq :
      (if pts rec.1 ∈ coreBall ball.o ball.V then st.childPool else insert rec st.childPool) =
        (insert rec (clsRecords st)).filter (fun r => pts r.1 ∉ coreBall ball.o ball.V) := by
    rw [hChild, Finset.filter_insert]
    by_cases hc : pts rec.1 ∈ coreBall ball.o ball.V
    · simp [hc]
    · simp [hc]
  intro st'
  have hAct : st'.activeRecords = st.activeRecords := rfl
  have hLife : st'.nextLife = st.nextLife := rfl
  have hRad : st'.radiusDict = st.radiusDict := rfl
  have hHeap : st'.heapIndexed = st.heapIndexed := rfl
  have hPh : st'.phase = st.phase := rfl
  have hCls : st'.classified = insert rec.2 st.classified := rfl
  have hCR : clsRecords st' = insert rec (clsRecords st) := by
    unfold clsRecords
    rw [hAct, hCls]
    exact hClsRecEq
  have hCS : clsSet st' = insert rec.1 (clsSet st) := by
    unfold clsSet
    rw [hCR]
    exact hClsSetEq
  have hCh : st'.childPool = (clsRecords st').filter (fun r => pts r.1 ∉ coreBall ball.o ball.V) := by
    rw [hCR, ← hChildEq]
    rfl
  refine ⟨hAct, hLife, hRad, hHeap, hPh, hCls, hCR, hCS, hCh, ?_, ?_, ?_⟩
  · change 0 ≤ (classifyActiveRecordAtomically pts n A_n optParams dynSearch ball rec st).cumWork - st.cumWork
    unfold classifyActiveRecordAtomically
    cases hOpt : optParams with
    | none =>
      dsimp only
      linarith
    | some params =>
      dsimp only
      have hPlocSome : ValidNodeWorkFactor n (some params) P_search P_loc := hOpt ▸ hPloc
      rcases insertAllRetainedConfigs_spec h53 pts n params A_n P_search P_loc dynSearch
          ball (clsSet st) rec.1 st.localMatchings st.searchIdx
          hAn hPlocSome (hSearch params hOpt) hNotMemClsSet hInsCard (hMatch params hOpt) with
        ⟨hm0, _, _⟩
      linarith
  · change (classifyActiveRecordAtomically pts n A_n optParams dynSearch ball rec st).cumWork - st.cumWork ≤ 6 * A_n * P_loc
    unfold classifyActiveRecordAtomically
    cases hOpt : optParams with
    | none =>
      dsimp only
      linarith
    | some params =>
      dsimp only
      have hPlocSome : ValidNodeWorkFactor n (some params) P_search P_loc := hOpt ▸ hPloc
      rcases insertAllRetainedConfigs_spec h53 pts n params A_n P_search P_loc dynSearch
          ball (clsSet st) rec.1 st.localMatchings st.searchIdx
          hAn hPlocSome (hSearch params hOpt) hNotMemClsSet hInsCard (hMatch params hOpt) with
        ⟨_, hmhi, _⟩
      linarith
  · intro params hOpt hV cfg hcfg
    rw [hCS]
    change ((classifyActiveRecordAtomically pts n A_n optParams dynSearch ball rec st).localMatchings cfg).SatisfiesInvariant _ _ _ _ _
    subst hOpt
    unfold classifyActiveRecordAtomically
    dsimp only
    rcases insertAllRetainedConfigs_spec h53 pts n params A_n P_search P_loc dynSearch
        ball (clsSet st) rec.1 st.localMatchings st.searchIdx
        hAn hPloc (hSearch params rfl) hNotMemClsSet hInsCard (hMatch params rfl) with
      ⟨_, _, hmInv⟩
    exact hmInv hV cfg hcfg

/-! ### 4. Arrival step invariant preservation (`arrival_step_spec`) -/

open Classical in
theorem arrival_step_spec {d : ℕ} {ι IdxState : Type}
    (h53 : S_clm_5_3_matching_invariant)
    {α : ℝ} (pts : ι → EuclideanSpace ℝ (Fin d))
    {n : ℕ} {A_n P_search P_loc : ℝ}
    {optParams : Option LocalScaleParams}
    {dynSearch : LocalDynamicSearchInterface d ι IdxState}
    {birthSnapshotList : List (ι × ℕ)} {S_birth : Finset ι} {prov : ChainNode d}
    {S_cur S_next : Finset ι} {ev : PoolUpdateEvent ι}
    {insCount : ℕ} {st : TwoScanLevelState d ι IdxState}
    (hn : 2 ≤ n) (hAn : 1 ≤ A_n)
    (hPloc : ValidNodeWorkFactor n optParams P_search P_loc)
    (hSearch : ∀ params : LocalScaleParams, optParams = some params →
      SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    (hEv : IsValidPoolUpdateEvent S_cur S_next ev)
    (hCapCur : S_cur.card ≤ n) (hCapNext : S_next.card ≤ n)
    (hInv : LevelInv α pts optParams birthSnapshotList S_birth prov S_cur insCount st) :
    let st_arr := applyPoolArrivalStep pts n A_n optParams dynSearch ev st
    LevelInv α pts optParams birthSnapshotList S_birth prov S_next (insCount + evInsInc ev) st_arr ∧
    (∀ M2 : ℕ, remBgSteps M2 st_arr.phase = remBgSteps M2 st.phase) ∧
    0 ≤ st_arr.cumWork - st.cumWork ∧
    st_arr.cumWork - st.cumWork ≤
      (if ev.isClockTick = true then 10 * A_n * P_loc else 0) ∧
    (∀ ball : ChainNode d, st.phase = .ready ball → st_arr.phase = .ready ball) := by
  rcases validNodeWorkFactor_bounds hn hAn hPloc with ⟨_, hAP1, htw0, htwhi⟩
  rcases hInv with ⟨hPool, hCardB, hRadSub, hRadIff, hHeapLife, hClsLife, hPhase⟩
  cases ev with
  | virtualValueDelete =>
    dsimp only [IsValidPoolUpdateEvent] at hEv
    subst hEv
    dsimp only [applyPoolArrivalStep, evInsInc, Nat.add_zero, PoolUpdateEvent.isClockTick]
    exact ⟨⟨hPool, hCardB, hRadSub, hRadIff, hHeapLife, hClsLife, hPhase⟩,
      fun _ => rfl, by linarith, by simp, fun _ h => h⟩
  | unaffected =>
    dsimp only [IsValidPoolUpdateEvent] at hEv
    subst hEv
    dsimp only [applyPoolArrivalStep, evInsInc, Nat.add_zero, PoolUpdateEvent.isClockTick]
    exact ⟨⟨hPool, hCardB, hRadSub, hRadIff, hHeapLife, hClsLife, hPhase⟩,
      fun _ => rfl, by linarith, by simp, fun _ h => h⟩
  | externalInsert id =>
    rcases hEv with ⟨hid_not, rfl⟩
    dsimp only [evInsInc, PoolUpdateEvent.isClockTick]
    set rec_new : ι × ℕ := (id, st.nextLife)
    have hrec_not_act : rec_new ∉ st.activeRecords := by
      intro hr
      exact Nat.lt_irrefl st.nextLife (hPool.2.2.2 rec_new hr)
    have hlife_not_heap : st.nextLife ∉ st.heapIndexed := by
      intro hℓ
      exact Nat.lt_irrefl st.nextLife (hHeapLife st.nextLife hℓ)
    have hlife_not_cls : st.nextLife ∉ st.classified := by
      intro hℓ
      exact Nat.lt_irrefl st.nextLife (hClsLife st.nextLife hℓ)
    set st₁ : TwoScanLevelState d ι IdxState :=
      { st with
        activeRecords := insert rec_new st.activeRecords
        nextLife := st.nextLife + 1
        radiusDict := insert rec_new st.radiusDict
        heapIndexed := insert rec_new.2 st.heapIndexed
        cumWork := st.cumWork + 2 * ((1 + Real.log (n : ℝ)) * A_n) }
    have hPool₁ : IsValidLifetimePool (insert id S_cur) st₁.activeRecords st₁.nextLife := by
      refine ⟨?_, ?_, ?_, ?_⟩
      · dsimp only [st₁]
        rw [Finset.image_insert, hPool.1]
      · intro a ha b hb hab
        dsimp only [st₁] at ha hb
        rw [Finset.mem_coe, Finset.mem_insert] at ha
        rw [Finset.mem_coe, Finset.mem_insert] at hb
        rcases ha with rfl | ha <;> rcases hb with rfl | hb
        · rfl
        · exfalso
          dsimp only [rec_new] at hab
          have hbin : b.1 ∈ S_cur := by rw [← hPool.1]; exact Finset.mem_image_of_mem Prod.fst hb
          exact hid_not (hab ▸ hbin)
        · exfalso
          dsimp only [rec_new] at hab
          have hain : a.1 ∈ S_cur := by rw [← hPool.1]; exact Finset.mem_image_of_mem Prod.fst ha
          exact hid_not (hab.symm ▸ hain)
        · exact hPool.2.1 ha hb hab
      · intro a ha b hb hab
        dsimp only [st₁] at ha hb
        rw [Finset.mem_coe, Finset.mem_insert] at ha
        rw [Finset.mem_coe, Finset.mem_insert] at hb
        rcases ha with rfl | ha <;> rcases hb with rfl | hb
        · rfl
        · exfalso; exact absurd hab (ne_of_gt (hPool.2.2.2 b hb))
        · exfalso; exact absurd hab (ne_of_lt (hPool.2.2.2 a ha))
        · exact hPool.2.2.1 ha hb hab
      · intro r hr
        dsimp only [st₁] at hr ⊢
        rcases Finset.mem_insert.mp hr with rfl | hr
        · exact Nat.lt_succ_self _
        · exact Nat.lt_succ_of_lt (hPool.2.2.2 r hr)
    have hCard₁ : st₁.activeRecords.card ≤ S_birth.card + (insCount + 1) := by
      dsimp only [st₁]
      have hc := Finset.card_insert_le rec_new st.activeRecords
      omega
    have hRadSub₁ : st₁.radiusDict ⊆ st₁.activeRecords :=
      Finset.insert_subset_insert rec_new hRadSub
    have hRadIff₁ : ∀ r ∈ st₁.activeRecords, r ∈ st₁.radiusDict ↔ r.2 ∈ st₁.heapIndexed := by
      intro r hr
      dsimp only [st₁] at hr ⊢
      rcases Finset.mem_insert.mp hr with rfl | hrA
      · simp
      · have hne_rec : r ≠ rec_new := fun h => hrec_not_act (h ▸ hrA)
        have hne_life : r.2 ≠ st.nextLife := ne_of_lt (hPool.2.2.2 r hrA)
        dsimp only [rec_new] at hne_rec ⊢
        simp only [Finset.mem_insert, hne_rec, hne_life, false_or]
        exact hRadIff r hrA
    have hHeapLife₁ : ∀ ℓ ∈ st₁.heapIndexed, ℓ < st₁.nextLife := by
      intro ℓ hℓ
      dsimp only [st₁] at hℓ ⊢
      rcases Finset.mem_insert.mp hℓ with rfl | hℓ
      · exact Nat.lt_succ_self _
      · exact Nat.lt_succ_of_lt (hHeapLife ℓ hℓ)
    have hClsRec₁ : clsRecords st₁ = clsRecords st := by
      ext r
      simp only [clsRecords, st₁, Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨rfl | hrA, hrC⟩
        · exact absurd hrC hlife_not_cls
        · exact ⟨hrA, hrC⟩
      · rintro ⟨hrA, hrC⟩
        exact ⟨Or.inr hrA, hrC⟩
    have hClsSet₁ : clsSet st₁ = clsSet st := by
      unfold clsSet
      rw [hClsRec₁]
    have hPhCases :
        (∃ rem coreCnt maxR, st.phase = .scan1 rem coreCnt maxR) ∨
        (∃ ball snap rem, st.phase = .scan2 ball snap rem) ∨
        (∃ ball, st.phase = .ready ball) := by
      cases st.phase
      · exact Or.inl ⟨_, _, _, rfl⟩
      · exact Or.inr (Or.inl ⟨_, _, _, rfl⟩)
      · exact Or.inr (Or.inr ⟨_, rfl⟩)
    rcases hPhCases with ⟨rem, coreCnt, maxR, hPh⟩ | ⟨ball, snap, rem, hPh⟩ | ⟨ball, hPh⟩
    · have hPh1 : st₁.phase = .scan1 rem coreCnt maxR := hPh
      have hArrEq : applyPoolArrivalStep pts n A_n optParams dynSearch (.externalInsert id) st = st₁ := by
        unfold applyPoolArrivalStep
        dsimp only
        split
        · rfl
        · rename_i b1 s1 r1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
        · rename_i b1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
      unfold PhaseInv at hPhase; rw [hPh] at hPhase
      dsimp only [PhaseInv] at hPhase
      rcases hPhase with ⟨hcC, hmR, hmR0, hRemIdx, hClsEmpty, hChildEmpty, hMatchEmpty⟩
      rw [hArrEq]
      refine ⟨⟨hPool₁, hCard₁, hRadSub₁, hRadIff₁, hHeapLife₁, ?_, ?_⟩,
        fun _ => rfl, ?_, ?_, ?_⟩
      · intro ℓ hℓ
        exact Nat.lt_succ_of_lt (hClsLife ℓ hℓ)
      · unfold PhaseInv
        rw [hPh1]
        dsimp only [st₁]
        refine ⟨hcC, hmR, hmR0, ?_, hClsEmpty, hChildEmpty, hMatchEmpty⟩
        intro r hr
        rcases Finset.mem_insert.mp hr with rfl | hrA
        · exact Or.inr (Finset.mem_insert_self _ _)
        · rcases hRemIdx r hrA with hrem | hidx
          · exact Or.inl hrem
          · exact Or.inr (Finset.mem_insert_of_mem hidx)
      · dsimp only [st₁]; linarith
      · dsimp only [st₁]; simp only [↓reduceIte]; linarith
      · intro _ h; rw [hPh] at h; cases h
    ·
      have hArrEq : applyPoolArrivalStep pts n A_n optParams dynSearch (.externalInsert id) st =
          classifyActiveRecordAtomically pts n A_n optParams dynSearch ball rec_new st₁ := by
        unfold applyPoolArrivalStep
        dsimp only
        split
        · rename_i r1 c1 m1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
        · rename_i b1 s1 r1 h1; change st.phase = _ at h1; rw [hPh] at h1; injection h1 with hb _ _; subst hb; rfl
        · rename_i b1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
      unfold PhaseInv at hPhase; rw [hPh] at hPhase
      dsimp only [PhaseInv] at hPhase
      rcases hPhase with ⟨hballEq, hRadEq, hSnapLen, hRemLen, hRemCls, hChildEq, hMatchInv⟩
      have hRadEq₁ : st₁.radiusDict = st₁.activeRecords := by
        dsimp only [st₁]
        rw [hRadEq]
      have hChildEq₁ : st₁.childPool =
          (clsRecords st₁).filter (fun r => pts r.1 ∉ coreBall ball.o ball.V) := by
        rw [hClsRec₁, hballEq]
        exact hChildEq
      have hMatchInv₁ : ∀ params : LocalScaleParams, optParams = some params → 0 < ball.V →
          ∀ cfg ∈ params.retainedConfigs ball.V,
            (st₁.localMatchings cfg).SatisfiesInvariant pts
              (params.leftVertices pts ball.o ball.V (clsSet st₁) cfg.j)
              (params.rightVertices pts ball.o ball.V (clsSet st₁) cfg.k)
              (params.weakEdges pts ball.o ball.V (clsSet st₁) cfg.j cfg.k cfg.ℓ)
              (params.strongEdges pts ball.o ball.V (clsSet st₁) cfg.j cfg.k cfg.ℓ) := by
        rw [hClsSet₁, hballEq]
        exact hMatchInv
      have hPh1 : st₁.phase = .scan2 ball snap rem := hPh
      rw [hArrEq]
      rcases classifyActiveRecordAtomically_spec h53 pts hn hAn hPloc hSearch hCapNext hPool₁
          (Finset.mem_insert_self _ _) hlife_not_cls hChildEq₁ hMatchInv₁ with
        ⟨hAct', hLife', hRad', hHeap', hPh', hCls', _, _, hChild', hw0, hwhi, hMatch'⟩
      refine ⟨⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩, ?_, ?_, ?_, ?_⟩
      · rwa [hAct', hLife']
      · rwa [hAct']
      · rwa [hRad', hAct']
      · rwa [hAct', hRad', hHeap']
      · rwa [hHeap', hLife']
      · rw [hCls', hLife']
        intro ℓ hℓ
        rcases Finset.mem_insert.mp hℓ with rfl | hℓ
        · exact Nat.lt_succ_self _
        · exact Nat.lt_succ_of_lt (hClsLife ℓ hℓ)
      · unfold PhaseInv
        rw [hPh', hPh1]
        dsimp only
        refine ⟨hballEq, by rw [hRad', hAct', hRadEq₁], by omega, hRemLen, ?_, ?_, ?_⟩
        · rw [hAct', hCls']
          intro r hr
          rcases Finset.mem_insert.mp hr with rfl | hrA
          · exact Or.inr (Finset.mem_insert_self _ _)
          · rcases hRemCls r hrA with hrem | hcls
            · exact Or.inl hrem
            · exact Or.inr (Finset.mem_insert_of_mem hcls)
        · rw [← hballEq]
          exact hChild'
        · rw [← hballEq]
          exact hMatch'
      · intro M2
        rw [hPh']
      · have hd1 : st₁.cumWork - st.cumWork = 2 * ((1 + Real.log (n : ℝ)) * A_n) := by
          dsimp only [st₁]; ring
        linarith
      · have hd1 : st₁.cumWork - st.cumWork = 2 * ((1 + Real.log (n : ℝ)) * A_n) := by
          dsimp only [st₁]; ring
        simp only [↓reduceIte]
        linarith
      · intro _ h
        rw [hPh] at h
        cases h
    ·
      have hArrEq : applyPoolArrivalStep pts n A_n optParams dynSearch (.externalInsert id) st =
          classifyActiveRecordAtomically pts n A_n optParams dynSearch ball rec_new st₁ := by
        unfold applyPoolArrivalStep
        dsimp only
        split
        · rename_i r1 c1 m1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
        · rename_i b1 s1 r1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
        · rename_i b1 h1; change st.phase = _ at h1; rw [hPh] at h1; injection h1 with hb; subst hb; rfl
      unfold PhaseInv at hPhase; rw [hPh] at hPhase
      dsimp only [PhaseInv] at hPhase
      rcases hPhase with ⟨hballEq, hRadEq, hAllCls, hChildEq, hMatchInv⟩
      have hRadEq₁ : st₁.radiusDict = st₁.activeRecords := by
        dsimp only [st₁]
        rw [hRadEq]
      have hChildEq₁ : st₁.childPool =
          (clsRecords st₁).filter (fun r => pts r.1 ∉ coreBall ball.o ball.V) := by
        rw [hClsRec₁, hballEq]
        exact hChildEq
      have hMatchInv₁ : ∀ params : LocalScaleParams, optParams = some params → 0 < ball.V →
          ∀ cfg ∈ params.retainedConfigs ball.V,
            (st₁.localMatchings cfg).SatisfiesInvariant pts
              (params.leftVertices pts ball.o ball.V (clsSet st₁) cfg.j)
              (params.rightVertices pts ball.o ball.V (clsSet st₁) cfg.k)
              (params.weakEdges pts ball.o ball.V (clsSet st₁) cfg.j cfg.k cfg.ℓ)
              (params.strongEdges pts ball.o ball.V (clsSet st₁) cfg.j cfg.k cfg.ℓ) := by
        rw [hClsSet₁, hballEq]
        exact hMatchInv
      have hPh1 : st₁.phase = .ready ball := hPh
      rw [hArrEq]
      rcases classifyActiveRecordAtomically_spec h53 pts hn hAn hPloc hSearch hCapNext hPool₁
          (Finset.mem_insert_self _ _) hlife_not_cls hChildEq₁ hMatchInv₁ with
        ⟨hAct', hLife', hRad', hHeap', hPh', hCls', _, _, hChild', hw0, hwhi, hMatch'⟩
      refine ⟨⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩, ?_, ?_, ?_, ?_⟩
      · rwa [hAct', hLife']
      · rwa [hAct']
      · rwa [hRad', hAct']
      · rwa [hAct', hRad', hHeap']
      · rwa [hHeap', hLife']
      · rw [hCls', hLife']
        intro ℓ hℓ
        rcases Finset.mem_insert.mp hℓ with rfl | hℓ
        · exact Nat.lt_succ_self _
        · exact Nat.lt_succ_of_lt (hClsLife ℓ hℓ)
      · unfold PhaseInv
        rw [hPh', hPh1]
        dsimp only
        refine ⟨hballEq, by rw [hRad', hAct', hRadEq₁], ?_, ?_, ?_⟩
        · rw [hAct', hCls']
          intro r hr
          rcases Finset.mem_insert.mp hr with rfl | hrA
          · exact Finset.mem_insert_self _ _
          · exact Finset.mem_insert_of_mem (hAllCls r hrA)
        · rw [← hballEq]
          exact hChild'
        · rw [← hballEq]
          exact hMatch'
      · intro M2
        rw [hPh']
      · have hd1 : st₁.cumWork - st.cumWork = 2 * ((1 + Real.log (n : ℝ)) * A_n) := by
          dsimp only [st₁]; ring
        linarith
      · have hd1 : st₁.cumWork - st.cumWork = 2 * ((1 + Real.log (n : ℝ)) * A_n) := by
          dsimp only [st₁]; ring
        simp only [↓reduceIte]
        linarith
      · intro b hb
        rw [hPh', hb]
  | externalDelete id =>
    rcases hEv with ⟨hid_in, rfl⟩
    dsimp only [evInsInc, Nat.add_zero, PoolUpdateEvent.isClockTick]
    have hex_del : ∃ r_del ∈ st.activeRecords, r_del.1 = id := by
      rw [← hPool.1] at hid_in
      exact Finset.mem_image.mp hid_in
    rcases hex_del with ⟨r_del, hr_del_in, hr_del_id⟩
    set delRecords := st.activeRecords.filter (fun r => r.1 = id)
    set active' := st.activeRecords.filter (fun r => r.1 ≠ id)
    have hdel_eq : delRecords = {r_del} := by
      ext r
      simp only [delRecords, Finset.mem_filter, Finset.mem_singleton]
      constructor
      · rintro ⟨hrA, hrid⟩
        exact hPool.2.1 hrA hr_del_in (hrid.trans hr_del_id.symm)
      · rintro rfl
        exact ⟨hr_del_in, hr_del_id⟩
    have hPool₁_base : IsValidLifetimePool (S_cur.erase id) active' st.nextLife := by
      refine ⟨?_, ?_, ?_, ?_⟩
      · ext x
        simp only [active', Finset.mem_image, Finset.mem_filter, Finset.mem_erase]
        constructor
        · rintro ⟨r, ⟨hrA, hrne⟩, rfl⟩
          rw [← hPool.1]
          exact ⟨hrne, Finset.mem_image_of_mem Prod.fst hrA⟩
        · rintro ⟨hxne, hxS⟩
          rw [← hPool.1] at hxS
          rcases Finset.mem_image.mp hxS with ⟨r, hrA, rfl⟩
          exact ⟨r, ⟨hrA, hxne⟩, rfl⟩
      · exact hPool.2.1.mono (Finset.coe_subset.mpr (Finset.filter_subset _ _))
      · exact hPool.2.2.1.mono (Finset.coe_subset.mpr (Finset.filter_subset _ _))
      · intro r hr
        exact hPool.2.2.2 r (Finset.mem_of_mem_filter r hr)
    have hCard₁_base : active'.card ≤ S_birth.card + insCount :=
      le_trans (Finset.card_le_card (Finset.filter_subset _ _)) hCardB
    set isHeapIdx : Prop := ∃ r ∈ delRecords, r.2 ∈ st.heapIndexed
    set radiusDict' := if isHeapIdx then st.radiusDict \ delRecords else st.radiusDict
    set heapIndexed' := if isHeapIdx then st.heapIndexed \ (delRecords.image Prod.snd) else st.heapIndexed
    set heapWork : ℝ := if isHeapIdx then (1 + Real.log (n : ℝ)) * A_n else 0
    have hhw : 0 ≤ heapWork ∧ heapWork ≤ A_n * P_loc := by
      dsimp only [heapWork]
      split_ifs <;> exact ⟨by linarith, by linarith⟩
    have hRadSub₁ : radiusDict' ⊆ active' := by
      intro r hr
      dsimp only [radiusDict'] at hr
      by_cases hh : isHeapIdx
      · rw [if_pos hh, Finset.mem_sdiff] at hr
        rcases hr with ⟨hrR, hrNotDel⟩
        have hrA : r ∈ st.activeRecords := hRadSub hrR
        simp only [active', Finset.mem_filter]
        refine ⟨hrA, ?_⟩
        intro hrid
        exact hrNotDel (Finset.mem_filter.mpr ⟨hrA, hrid⟩)
      · rw [if_neg hh] at hr
        have hrA : r ∈ st.activeRecords := hRadSub hr
        simp only [active', Finset.mem_filter]
        refine ⟨hrA, ?_⟩
        intro hrid
        have hrDel : r ∈ delRecords := Finset.mem_filter.mpr ⟨hrA, hrid⟩
        exact hh ⟨r, hrDel, (hRadIff r hrA).mp hr⟩
    have hRadIff₁ : ∀ r ∈ active', r ∈ radiusDict' ↔ r.2 ∈ heapIndexed' := by
      intro r hr
      have hrA : r ∈ st.activeRecords := (Finset.mem_filter.mp hr).1
      have hrne_id : r.1 ≠ id := (Finset.mem_filter.mp hr).2
      have hrNotDel : r ∉ delRecords := by
        simp [delRecords, hrne_id]
      have hr2NotDel : r.2 ∉ delRecords.image Prod.snd := by
        intro hmem
        rcases Finset.mem_image.mp hmem with ⟨r', hr'Del, hr2eq⟩
        have hr'A : r' ∈ st.activeRecords := (Finset.mem_filter.mp hr'Del).1
        have heq : r = r' := hPool.2.2.1 hrA hr'A hr2eq.symm
        exact hrNotDel (heq ▸ hr'Del)
      dsimp only [radiusDict', heapIndexed']
      by_cases hh : isHeapIdx
      · rw [if_pos hh, if_pos hh, Finset.mem_sdiff, Finset.mem_sdiff]
        simp only [hrNotDel, hr2NotDel, not_false_eq_true, and_true]
        exact hRadIff r hrA
      · rw [if_neg hh, if_neg hh]
        exact hRadIff r hrA
    have hHeapLife₁ : ∀ ℓ ∈ heapIndexed', ℓ < st.nextLife := by
      intro ℓ hℓ
      dsimp only [heapIndexed'] at hℓ
      by_cases hh : isHeapIdx
      · rw [if_pos hh] at hℓ
        exact hHeapLife ℓ (Finset.sdiff_subset hℓ)
      · rw [if_neg hh] at hℓ
        exact hHeapLife ℓ hℓ
    set st₁ : TwoScanLevelState d ι IdxState :=
      { st with
        activeRecords := active'
        radiusDict := radiusDict'
        heapIndexed := heapIndexed'
        cumWork := st.cumWork + (1 + Real.log (n : ℝ)) * A_n + heapWork }
    have hPhCases :
        (∃ rem coreCnt maxR, st.phase = .scan1 rem coreCnt maxR) ∨
        (∃ ball snap rem, st.phase = .scan2 ball snap rem) ∨
        (∃ ball, st.phase = .ready ball) := by
      cases st.phase
      · exact Or.inl ⟨_, _, _, rfl⟩
      · exact Or.inr (Or.inl ⟨_, _, _, rfl⟩)
      · exact Or.inr (Or.inr ⟨_, rfl⟩)
    rcases hPhCases with ⟨rem, coreCnt, maxR, hPh⟩ | ⟨ball, snap, rem, hPh⟩ | ⟨ball, hPh⟩
    · have hPh1 : st₁.phase = .scan1 rem coreCnt maxR := hPh
      have hArrEq : applyPoolArrivalStep pts n A_n optParams dynSearch (.externalDelete id) st = st₁ := by
        unfold applyPoolArrivalStep
        dsimp only
        split
        · rfl
        · rename_i b1 s1 r1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
        · rename_i b1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
      unfold PhaseInv at hPhase; rw [hPh] at hPhase
      dsimp only [PhaseInv] at hPhase
      rcases hPhase with ⟨hcC, hmR, hmR0, hRemIdx, hClsEmpty, hChildEmpty, hMatchEmpty⟩
      rw [hArrEq]
      refine ⟨⟨hPool₁_base, hCard₁_base, hRadSub₁, hRadIff₁, hHeapLife₁, hClsLife, ?_⟩,
        fun _ => rfl, ?_, ?_, fun _ hb => hb⟩
      · unfold PhaseInv
        rw [hPh1]
        dsimp only [st₁]
        refine ⟨hcC, hmR, hmR0, ?_, hClsEmpty, hChildEmpty, hMatchEmpty⟩
        intro r hr
        have hrA : r ∈ st.activeRecords := (Finset.mem_filter.mp hr).1
        rcases hRemIdx r hrA with hrem | hidx
        · exact Or.inl hrem
        · apply Or.inr
          have hrR : r ∈ st.radiusDict := (hRadIff r hrA).mpr hidx
          have hrNotDel : r ∉ delRecords := by
            simp [delRecords, (Finset.mem_filter.mp hr).2]
          have hrR' : r ∈ radiusDict' := by
            dsimp only [radiusDict']
            split_ifs
            · exact Finset.mem_sdiff.mpr ⟨hrR, hrNotDel⟩
            · exact hrR
          exact (hRadIff₁ r hr).mp hrR'
      · have hd1 : st₁.cumWork - st.cumWork = (1 + Real.log (n : ℝ)) * A_n + heapWork := by
          dsimp only [st₁]; ring
        linarith [hhw.1]
      · have hd1 : st₁.cumWork - st.cumWork = (1 + Real.log (n : ℝ)) * A_n + heapWork := by
          dsimp only [st₁]; ring
        simp only [↓reduceIte]
        linarith [hhw.2]
    · have hPh1 : st₁.phase = .scan2 ball snap rem := hPh
      unfold PhaseInv at hPhase; rw [hPh] at hPhase
      dsimp only [PhaseInv] at hPhase
      rcases hPhase with ⟨hballEq, hRadEq, hSnapLen, hRemLen, hRemCls, hChildEq, hMatchInv⟩
      have hRadEq₁ : radiusDict' = active' := by
        apply Finset.Subset.antisymm hRadSub₁
        intro r hr
        have hrA : r ∈ st.activeRecords := (Finset.mem_filter.mp hr).1
        have hrR : r ∈ st.radiusDict := hRadEq ▸ hrA
        have hrNotDel : r ∉ delRecords := by simp [delRecords, (Finset.mem_filter.mp hr).2]
        dsimp only [radiusDict']
        split_ifs
        · exact Finset.mem_sdiff.mpr ⟨hrR, hrNotDel⟩
        · exact hrR
      by_cases hIsCls : ∃ r ∈ delRecords, r.2 ∈ st₁.classified
      · have hArrEq : applyPoolArrivalStep pts n A_n optParams dynSearch (.externalDelete id) st =
            removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁ := by
          unfold applyPoolArrivalStep
          dsimp only
          split
          · rename_i r1 c1 m1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
          · rename_i b1 s1 r1 h1; change st.phase = _ at h1; rw [hPh] at h1; injection h1 with hb _ _; subst hb
            exact if_pos hIsCls
          · rename_i b1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
        rw [hArrEq]
        rcases hIsCls with ⟨r_c, hr_c_del, hr_c_cls⟩
        rw [hdel_eq, Finset.mem_singleton] at hr_c_del
        subst hr_c_del
        dsimp only [st₁] at hr_c_cls
        have hid_in_cls : id ∈ clsSet st := by
          rw [← hr_del_id]
          exact Finset.mem_image_of_mem Prod.fst (Finset.mem_filter.mpr ⟨hr_del_in, hr_c_cls⟩)
        have hClsCard : (clsSet st).card ≤ n :=
          le_trans (Finset.card_le_card (clsSet_subset_pool hPool)) hCapCur
        set st_rem := removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁
        have hAct_rem : st_rem.activeRecords = active' := rfl
        have hLife_rem : st_rem.nextLife = st.nextLife := rfl
        have hRad_rem : st_rem.radiusDict = radiusDict' := rfl
        have hHeap_rem : st_rem.heapIndexed = heapIndexed' := rfl
        have hPh_rem : st_rem.phase = st.phase := rfl
        have hChild_rem : st_rem.childPool = st.childPool \ delRecords := rfl
        have hCls_rem : st_rem.classified = st.classified \ (delRecords.image Prod.snd) := rfl
        have hClsRec_rem : clsRecords st_rem = (clsRecords st) \ delRecords := by
          unfold clsRecords
          rw [hAct_rem, hCls_rem]
          ext r
          simp only [active', Finset.mem_filter, Finset.mem_sdiff]
          constructor
          · rintro ⟨⟨hrA, hrne⟩, hrC, _⟩
            exact ⟨⟨hrA, hrC⟩, by simp [delRecords, hrne]⟩
          · rintro ⟨⟨hrA, hrC⟩, hrNotDel⟩
            have hrne : r.1 ≠ id := fun h => hrNotDel (Finset.mem_filter.mpr ⟨hrA, h⟩)
            have hr2Not : r.2 ∉ delRecords.image Prod.snd := by
              intro hm
              rcases Finset.mem_image.mp hm with ⟨r', hr'd, h2⟩
              have heq := hPool.2.2.1 hrA (Finset.mem_of_mem_filter r' hr'd) h2.symm
              exact hrNotDel (heq ▸ hr'd)
            exact ⟨⟨hrA, hrne⟩, hrC, hr2Not⟩
        have hClsSet_rem : clsSet st_rem = (clsSet st).erase id := by
          unfold clsSet
          rw [hClsRec_rem]
          ext x
          simp only [Finset.mem_image, Finset.mem_sdiff, Finset.mem_erase, clsRecords,
            delRecords, Finset.mem_filter]
          constructor
          · rintro ⟨r, ⟨⟨hrA, hrC⟩, hrnot⟩, rfl⟩
            refine ⟨fun h => hrnot ⟨hrA, h⟩, r, ⟨hrA, hrC⟩, rfl⟩
          · rintro ⟨hxne, r, ⟨hrA, hrC⟩, rfl⟩
            exact ⟨r, ⟨⟨hrA, hrC⟩, fun ⟨_, hid⟩ => hxne hid⟩, rfl⟩
        refine ⟨?_, fun _ => rfl, ?_, ?_, fun _ hb => hb⟩
        · unfold LevelInv
          rw [hAct_rem, hLife_rem, hRad_rem, hHeap_rem, hCls_rem]
          refine ⟨hPool₁_base, hCard₁_base, hRadSub₁, hRadIff₁, hHeapLife₁, ?_, ?_⟩
          · intro ℓ hℓ
            exact hClsLife ℓ (Finset.sdiff_subset hℓ)
          · unfold PhaseInv
            rw [hPh_rem, hPh, hRad_rem, hAct_rem, hCls_rem, hChild_rem]
            dsimp only
            refine ⟨hballEq, hRadEq₁, hSnapLen, hRemLen, ?_, ?_, ?_⟩
            · intro r hr
              have hrA : r ∈ st.activeRecords := (Finset.mem_filter.mp hr).1
              have hrne : r.1 ≠ id := (Finset.mem_filter.mp hr).2
              have hr2Not : r.2 ∉ delRecords.image Prod.snd := by
                intro hm
                rcases Finset.mem_image.mp hm with ⟨r', hr'd, h2⟩
                have heq := hPool.2.2.1 hrA (Finset.mem_of_mem_filter r' hr'd) h2.symm
                exact hrne (heq ▸ (Finset.mem_filter.mp hr'd).2)
              rcases hRemCls r hrA with hrem | hcls
              · exact Or.inl hrem
              · exact Or.inr (Finset.mem_sdiff.mpr ⟨hcls, hr2Not⟩)
            · rw [hClsRec_rem, hChildEq]
              ext r
              simp only [Finset.mem_sdiff, Finset.mem_filter]
              tauto
            · intro params hOpt hV cfg hcfg
              rw [hClsSet_rem, ← hballEq]
              change ((removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁).localMatchings cfg).SatisfiesInvariant _ _ _ _ _
              subst hOpt
              unfold removeClassifiedDeletedAtomically
              dsimp only [st₁]
              rcases deleteAllRetainedConfigs_spec h53 pts n params A_n P_search P_loc dynSearch
                  ball (clsSet st) id st.localMatchings st.searchIdx
                  hAn hPloc (hSearch params rfl) hid_in_cls hClsCard (hballEq ▸ hMatchInv params rfl) with
                ⟨_, _, hmInv⟩
              exact hmInv (hballEq ▸ hV) cfg (hballEq ▸ hcfg)
        · change 0 ≤ (removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁).cumWork - st.cumWork
          unfold removeClassifiedDeletedAtomically
          cases hOpt : optParams with
          | none =>
            dsimp only [st₁]
            linarith [hhw.1]
          | some params =>
            dsimp only [st₁]
            have hPlocSome : ValidNodeWorkFactor n (some params) P_search P_loc := hOpt ▸ hPloc
            rcases deleteAllRetainedConfigs_spec h53 pts n params A_n P_search P_loc dynSearch
                ball (clsSet st) id st.localMatchings st.searchIdx
                hAn hPlocSome (hSearch params hOpt) hid_in_cls hClsCard (hballEq ▸ hMatchInv params hOpt) with
              ⟨hm0, _, _⟩
            linarith [hhw.1]
        · simp only [↓reduceIte]
          change (removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁).cumWork - st.cumWork ≤ 10 * A_n * P_loc
          unfold removeClassifiedDeletedAtomically
          cases hOpt : optParams with
          | none =>
            dsimp only [st₁]
            linarith [hhw.2]
          | some params =>
            dsimp only [st₁]
            have hPlocSome : ValidNodeWorkFactor n (some params) P_search P_loc := hOpt ▸ hPloc
            rcases deleteAllRetainedConfigs_spec h53 pts n params A_n P_search P_loc dynSearch
                ball (clsSet st) id st.localMatchings st.searchIdx
                hAn hPlocSome (hSearch params hOpt) hid_in_cls hClsCard (hballEq ▸ hMatchInv params hOpt) with
              ⟨_, hmhi, _⟩
            linarith [hhw.2]
      · have hArrEq : applyPoolArrivalStep pts n A_n optParams dynSearch (.externalDelete id) st = st₁ := by
          unfold applyPoolArrivalStep
          dsimp only
          split
          · rfl
          · rename_i b1 s1 r1 h1; change st.phase = _ at h1; rw [hPh] at h1; injection h1 with hb _ _; subst hb
            exact if_neg hIsCls
          · rename_i b1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
        rw [hArrEq]
        have hClsRec₁ : clsRecords st₁ = clsRecords st := by
          ext r
          simp only [clsRecords, st₁, active', Finset.mem_filter]
          constructor
          · rintro ⟨⟨hrA, _⟩, hrC⟩
            exact ⟨hrA, hrC⟩
          · rintro ⟨hrA, hrC⟩
            refine ⟨⟨hrA, ?_⟩, hrC⟩
            intro hrid
            exact hIsCls ⟨r, Finset.mem_filter.mpr ⟨hrA, hrid⟩, hrC⟩
        have hClsSet₁ : clsSet st₁ = clsSet st := by
          unfold clsSet; rw [hClsRec₁]
        refine ⟨⟨hPool₁_base, hCard₁_base, hRadSub₁, hRadIff₁, hHeapLife₁, hClsLife, ?_⟩,
          fun _ => rfl, ?_, ?_, fun _ hb => hb⟩
        · unfold PhaseInv
          rw [hPh1]
          dsimp only
          refine ⟨hballEq, hRadEq₁, hSnapLen, hRemLen, ?_, ?_, ?_⟩
          · intro r hr
            exact hRemCls r (Finset.mem_of_mem_filter r hr)
          · rw [hClsRec₁]
            exact hChildEq
          · rw [hClsSet₁]
            exact hMatchInv
        · dsimp only [st₁]
          linarith [hhw.1]
        · dsimp only [st₁]
          simp only [↓reduceIte]
          linarith [hhw.2]
    · have hPh1 : st₁.phase = .ready ball := hPh
      unfold PhaseInv at hPhase; rw [hPh] at hPhase
      dsimp only [PhaseInv] at hPhase
      rcases hPhase with ⟨hballEq, hRadEq, hAllCls, hChildEq, hMatchInv⟩
      have hRadEq₁ : radiusDict' = active' := by
        apply Finset.Subset.antisymm hRadSub₁
        intro r hr
        have hrA : r ∈ st.activeRecords := (Finset.mem_of_mem_filter r hr)
        have hrR : r ∈ st.radiusDict := hRadEq ▸ hrA
        have hrNotDel : r ∉ delRecords := by simp [delRecords, (Finset.mem_filter.mp hr).2]
        dsimp only [radiusDict']
        split_ifs
        · exact Finset.mem_sdiff.mpr ⟨hrR, hrNotDel⟩
        · exact hrR
      have hIsCls : ∃ r ∈ delRecords, r.2 ∈ st₁.classified :=
        ⟨r_del, Finset.mem_filter.mpr ⟨hr_del_in, hr_del_id⟩, hAllCls r_del hr_del_in⟩
      have hArrEq : applyPoolArrivalStep pts n A_n optParams dynSearch (.externalDelete id) st =
          removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁ := by
        unfold applyPoolArrivalStep
        dsimp only
        split
        · rename_i r1 c1 m1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
        · rename_i b1 s1 r1 h1; change st.phase = _ at h1; rw [hPh] at h1; cases h1
        · rename_i b1 h1; change st.phase = _ at h1; rw [hPh] at h1; injection h1 with hb; subst hb
          exact if_pos hIsCls
      rw [hArrEq]
      have hr_c_cls : r_del.2 ∈ st.classified := hAllCls r_del hr_del_in
      have hid_in_cls : id ∈ clsSet st := by
        rw [← hr_del_id]
        exact Finset.mem_image_of_mem Prod.fst (Finset.mem_filter.mpr ⟨hr_del_in, hr_c_cls⟩)
      have hClsCard : (clsSet st).card ≤ n :=
        le_trans (Finset.card_le_card (clsSet_subset_pool hPool)) hCapCur
      set st_rem := removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁
      have hAct_rem : st_rem.activeRecords = active' := rfl
      have hLife_rem : st_rem.nextLife = st.nextLife := rfl
      have hRad_rem : st_rem.radiusDict = radiusDict' := rfl
      have hHeap_rem : st_rem.heapIndexed = heapIndexed' := rfl
      have hPh_rem : st_rem.phase = st.phase := rfl
      have hChild_rem : st_rem.childPool = st.childPool \ delRecords := rfl
      have hCls_rem : st_rem.classified = st.classified \ (delRecords.image Prod.snd) := rfl
      have hClsRec_rem : clsRecords st_rem = (clsRecords st) \ delRecords := by
        unfold clsRecords
        rw [hAct_rem, hCls_rem]
        ext r
        simp only [active', Finset.mem_filter, Finset.mem_sdiff]
        constructor
        · rintro ⟨⟨hrA, hrne⟩, hrC, _⟩
          exact ⟨⟨hrA, hrC⟩, by simp [delRecords, hrne]⟩
        · rintro ⟨⟨hrA, hrC⟩, hrNotDel⟩
          have hrne : r.1 ≠ id := fun h => hrNotDel (Finset.mem_filter.mpr ⟨hrA, h⟩)
          have hr2Not : r.2 ∉ delRecords.image Prod.snd := by
            intro hm
            rcases Finset.mem_image.mp hm with ⟨r', hr'd, h2⟩
            have heq := hPool.2.2.1 hrA (Finset.mem_of_mem_filter r' hr'd) h2.symm
            exact hrNotDel (heq ▸ hr'd)
          exact ⟨⟨hrA, hrne⟩, hrC, hr2Not⟩
      have hClsSet_rem : clsSet st_rem = (clsSet st).erase id := by
        unfold clsSet
        rw [hClsRec_rem]
        ext x
        simp only [Finset.mem_image, Finset.mem_sdiff, Finset.mem_erase, clsRecords,
          delRecords, Finset.mem_filter]
        constructor
        · rintro ⟨r, ⟨⟨hrA, hrC⟩, hrnot⟩, rfl⟩
          refine ⟨fun h => hrnot ⟨hrA, h⟩, r, ⟨hrA, hrC⟩, rfl⟩
        · rintro ⟨hxne, r, ⟨hrA, hrC⟩, rfl⟩
          exact ⟨r, ⟨⟨hrA, hrC⟩, fun ⟨_, hid⟩ => hxne hid⟩, rfl⟩
      refine ⟨?_, fun _ => rfl, ?_, ?_, fun _ hb => hb⟩
      · unfold LevelInv
        rw [hAct_rem, hLife_rem, hRad_rem, hHeap_rem, hCls_rem]
        refine ⟨hPool₁_base, hCard₁_base, hRadSub₁, hRadIff₁, hHeapLife₁, ?_, ?_⟩
        · intro ℓ hℓ
          exact hClsLife ℓ (Finset.sdiff_subset hℓ)
        · unfold PhaseInv
          rw [hPh_rem, hPh, hRad_rem, hAct_rem, hCls_rem, hChild_rem]
          dsimp only
          refine ⟨hballEq, hRadEq₁, ?_, ?_, ?_⟩
          · intro r hr
            have hrA : r ∈ st.activeRecords := (Finset.mem_filter.mp hr).1
            have hrne : r.1 ≠ id := (Finset.mem_filter.mp hr).2
            have hr2Not : r.2 ∉ delRecords.image Prod.snd := by
              intro hm
              rcases Finset.mem_image.mp hm with ⟨r', hr'd, h2⟩
              have heq := hPool.2.2.1 hrA (Finset.mem_of_mem_filter r' hr'd) h2.symm
              exact hrne (heq ▸ (Finset.mem_filter.mp hr'd).2)
            exact Finset.mem_sdiff.mpr ⟨hAllCls r hrA, hr2Not⟩
          · rw [hClsRec_rem, hChildEq]
            ext r
            simp only [Finset.mem_sdiff, Finset.mem_filter]
            tauto
          · intro params hOpt hV cfg hcfg
            rw [hClsSet_rem, ← hballEq]
            change ((removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁).localMatchings cfg).SatisfiesInvariant _ _ _ _ _
            subst hOpt
            unfold removeClassifiedDeletedAtomically
            dsimp only [st₁]
            rcases deleteAllRetainedConfigs_spec h53 pts n params A_n P_search P_loc dynSearch
                ball (clsSet st) id st.localMatchings st.searchIdx
                hAn hPloc (hSearch params rfl) hid_in_cls hClsCard (hballEq ▸ hMatchInv params rfl) with
              ⟨_, _, hmInv⟩
            exact hmInv (hballEq ▸ hV) cfg (hballEq ▸ hcfg)
      · change 0 ≤ (removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁).cumWork - st.cumWork
        unfold removeClassifiedDeletedAtomically
        cases hOpt : optParams with
        | none =>
          dsimp only [st₁]
          linarith [hhw.1]
        | some params =>
          dsimp only [st₁]
          have hPlocSome : ValidNodeWorkFactor n (some params) P_search P_loc := hOpt ▸ hPloc
          rcases deleteAllRetainedConfigs_spec h53 pts n params A_n P_search P_loc dynSearch
              ball (clsSet st) id st.localMatchings st.searchIdx
              hAn hPlocSome (hSearch params hOpt) hid_in_cls hClsCard (hballEq ▸ hMatchInv params hOpt) with
            ⟨hm0, _, _⟩
          linarith [hhw.1]
      · simp only [↓reduceIte]
        change (removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁).cumWork - st.cumWork ≤ 10 * A_n * P_loc
        unfold removeClassifiedDeletedAtomically
        cases hOpt : optParams with
        | none =>
          dsimp only [st₁]
          linarith [hhw.2]
        | some params =>
          dsimp only [st₁]
          have hPlocSome : ValidNodeWorkFactor n (some params) P_search P_loc := hOpt ▸ hPloc
          rcases deleteAllRetainedConfigs_spec h53 pts n params A_n P_search P_loc dynSearch
              ball (clsSet st) id st.localMatchings st.searchIdx
              hAn hPlocSome (hSearch params hOpt) hid_in_cls hClsCard (hballEq ▸ hMatchInv params hOpt) with
            ⟨_, hmhi, _⟩
          linarith [hhw.2]

/-! ### 5. Canonical background step (`nextBgStep_spec`) and invariant consequences -/

open Classical in
theorem nextBgStep_none_iff_ready {d : ℕ} {ι IdxState : Type}
    {α : ℝ} (pts : ι → EuclideanSpace ℝ (Fin d))
    {n : ℕ} {A_n : ℝ} {prov : ChainNode d}
    {optParams : Option LocalScaleParams}
    {dynSearch : LocalDynamicSearchInterface d ι IdxState}
    {birthSnapshotList : List (ι × ℕ)} {S_birth S_cur : Finset ι}
    {insCount : ℕ} {st : TwoScanLevelState d ι IdxState}
    (hInv : LevelInv α pts optParams birthSnapshotList S_birth prov S_cur insCount st)
    (hNone : nextBgStep α pts n S_birth.card A_n prov optParams dynSearch st = none) :
    st.phase = .ready (applyBirthCoreFallback α pts S_birth prov) := by
  rcases hInv with ⟨_, _, _, _, _, _, hPhase⟩
  unfold nextBgStep at hNone
  cases hPh : st.phase with
  | scan1 rem coreCnt maxR =>
    cases rem <;> simp [hPh] at hNone
  | scan2 ball snap rem =>
    cases rem <;> simp [hPh] at hNone
  | ready ball =>
    unfold PhaseInv at hPhase; rw [hPh] at hPhase
    dsimp only [PhaseInv] at hPhase
    rw [hPhase.1]

open Classical in
theorem nextBgStep_some_spec {d : ℕ} {ι IdxState : Type}
    (h53 : S_clm_5_3_matching_invariant)
    {α : ℝ} (pts : ι → EuclideanSpace ℝ (Fin d))
    {n : ℕ} {A_n P_search P_loc : ℝ}
    {optParams : Option LocalScaleParams}
    {dynSearch : LocalDynamicSearchInterface d ι IdxState}
    {birthSnapshotList : List (ι × ℕ)} {S_birth S_cur : Finset ι}
    {initNextLife : ℕ} {prov : ChainNode d}
    {insCount : ℕ} {st st' : TwoScanLevelState d ι IdxState}
    (hn : 2 ≤ n) (hAn : 1 ≤ A_n)
    (hPloc : ValidNodeWorkFactor n optParams P_search P_loc)
    (hSearch : ∀ params : LocalScaleParams, optParams = some params →
      SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
    (hNodup : birthSnapshotList.Nodup)
    (hBirthPool : IsValidLifetimePool S_birth birthSnapshotList.toFinset initNextLife)
    (hBirthNonempty : S_birth.Nonempty)
    (hCapCur : S_cur.card ≤ n)
    (hInv : LevelInv α pts optParams birthSnapshotList S_birth prov S_cur insCount st)
    (hSome : nextBgStep α pts n S_birth.card A_n prov optParams dynSearch st = some st') :
    TwoScanBgStep α pts n S_birth.card A_n prov optParams dynSearch st st' ∧
    LevelInv α pts optParams birthSnapshotList S_birth prov S_cur insCount st' ∧
    0 ≤ st'.cumWork - st.cumWork ∧
    st'.cumWork - st.cumWork ≤ 6 * A_n * P_loc ∧
    (∀ M2 : ℕ, S_birth.card + insCount ≤ M2 →
      remBgSteps M2 st'.phase + 1 ≤ remBgSteps M2 st.phase) := by
  rcases validNodeWorkFactor_bounds hn hAn hPloc with ⟨_, _, htw0, htwhi⟩
  rcases hInv with ⟨hPool, hCardB, hRadSub, hRadIff, hHeapLife, hClsLife, hPhase⟩
  unfold nextBgStep at hSome
  cases hPh : st.phase with
  | scan1 rem coreCnt maxR =>
    unfold PhaseInv at hPhase; rw [hPh] at hPhase
    dsimp only [PhaseInv] at hPhase
    rcases hPhase with ⟨hcC, hmR, hmR0, hRemIdx, hClsEmpty, hChildEmpty, hMatchEmpty⟩
    cases rem with
    | cons rec rest =>
      rw [hPh] at hSome
      dsimp only at hSome
      injection hSome with hst'
      subst hst'
      refine ⟨TwoScanBgStep.scan1Record st rec rest coreCnt maxR hPh, ?_, ?_, ?_, ?_⟩
      · unfold scan1RecordNextState LevelInv PhaseInv
        dsimp only
        set shouldIdx : Prop := rec ∈ st.activeRecords ∧ rec.2 ∉ st.heapIndexed
        refine ⟨hPool, hCardB, ?_, ?_, ?_, hClsLife, ?_⟩
        · by_cases hs : shouldIdx
          · rw [if_pos hs]
            exact Finset.insert_subset hs.1 hRadSub
          · rw [if_neg hs]
            exact hRadSub
        · intro r hrA
          by_cases hs : shouldIdx
          · rw [if_pos hs, if_pos hs]
            simp only [Finset.mem_insert]
            constructor
            · rintro (rfl | hrR)
              · exact Or.inl rfl
              · exact Or.inr ((hRadIff r hrA).mp hrR)
            · rintro (hr2eq | hrH)
              · exact Or.inl (hPool.2.2.1 hrA hs.1 hr2eq)
              · exact Or.inr ((hRadIff r hrA).mpr hrH)
          · rw [if_neg hs, if_neg hs]
            exact hRadIff r hrA
        · intro ℓ hℓ
          by_cases hs : shouldIdx
          · rw [if_pos hs, Finset.mem_insert] at hℓ
            rcases hℓ with rfl | hℓ
            · exact hPool.2.2.2 rec hs.1
            · exact hHeapLife ℓ hℓ
          · rw [if_neg hs] at hℓ
            exact hHeapLife ℓ hℓ
        · refine ⟨?_, ?_, le_max_of_le_left hmR0, ?_, hClsEmpty, hChildEmpty, hMatchEmpty⟩
          · unfold listCoreCount at hcC ⊢
            rw [List.countP_cons] at hcC
            by_cases hc : pts rec.1 ∈ coreBall prov.o prov.V
            · simp only [hc, ↓reduceIte, decide_true] at hcC ⊢
              omega
            · simp only [hc, ↓reduceIte, decide_false, Bool.false_eq_true] at hcC ⊢
              omega
          · unfold listMaxR at hmR ⊢
            dsimp only [List.map_cons, List.foldr_cons] at hmR
            rw [max_assoc]
            exact hmR
          · intro r hrA
            rcases hRemIdx r hrA with hrem | hidx
            · rw [List.toFinset_cons, Finset.mem_insert] at hrem
              rcases hrem with rfl | hrest
              · by_cases hs : shouldIdx
                · rw [if_pos hs]
                  exact Or.inr (Finset.mem_insert_self _ _)
                · rw [if_neg hs]
                  have h_in_heap : r.2 ∈ st.heapIndexed := by
                    by_contra hnot
                    exact hs ⟨hrA, hnot⟩
                  exact Or.inr h_in_heap
              · exact Or.inl hrest
            · by_cases hs : shouldIdx
              · rw [if_pos hs]
                exact Or.inr (Finset.mem_insert_of_mem hidx)
              · rw [if_neg hs]
                exact Or.inr hidx
      · unfold scan1RecordNextState; dsimp only; linarith
      · unfold scan1RecordNextState; dsimp only; linarith
      · intro M2 _
        unfold scan1RecordNextState remBgSteps
        dsimp only [List.length_cons]
        omega
    | nil =>
      rw [hPh] at hSome
      dsimp only at hSome
      injection hSome with hst'
      subst hst'
      have hSnapNodup : st.activeRecords.toList.Nodup := st.activeRecords.nodup_toList
      have hSnapTf : st.activeRecords.toList.toFinset = st.activeRecords := by
        ext r; simp
      have hSnapLen : st.activeRecords.toList.length = st.activeRecords.card :=
        Finset.length_toList _
      have hcC_val : coreCnt = (prov.core pts S_birth).card := by
        have h0 : listCoreCount pts prov [] = 0 := rfl
        rw [h0, Nat.add_zero] at hcC
        rw [hcC, listCoreCount_eq_birthCoreCard pts prov hNodup hBirthPool]
      have hmR_val : maxR = nodeMaxRadius pts prov.o S_birth := by
        have h0 : listMaxR pts prov [] = 0 := rfl
        rw [h0, max_eq_left hmR0] at hmR
        rw [hmR, listMaxR_eq_nodeMaxRadius pts prov hBirthPool hBirthNonempty]
      have hRadEq : st.radiusDict = st.activeRecords := by
        apply Finset.Subset.antisymm hRadSub
        intro r hrA
        rcases hRemIdx r hrA with hrem | hidx
        · simp at hrem
        · exact (hRadIff r hrA).mpr hidx
      refine ⟨TwoScanBgStep.fixBallAndSnapshot st coreCnt maxR st.activeRecords.toList
          hPh hSnapNodup hSnapTf, ?_, ?_, ?_, ?_⟩
      · unfold fixBallSnapshotNextState LevelInv PhaseInv
        dsimp only
        have hBallEq :
            (if α * (S_birth.card : ℝ) / 2 ≤ (coreCnt : ℝ) then prov
              else { o := prov.o, V := maxR ^ 2, V_nonneg := sq_nonneg maxR }) =
            applyBirthCoreFallback α pts S_birth prov := by
          unfold applyBirthCoreFallback PassesBirthCoreCheck maxBirthRadiusBall
          rw [hcC_val, hmR_val]
        refine ⟨hPool, hCardB, hRadSub, hRadIff, hHeapLife, hClsLife, ?_⟩
        refine ⟨hBallEq, hRadEq, by omega, le_rfl, ?_, ?_, ?_⟩
        · intro r hrA
          exact Or.inl (List.mem_toFinset.mpr (Finset.mem_toList.mpr hrA))
        · have hClsRecEmpty : clsRecords { st with
              phase := .scan2
                (if α * (S_birth.card : ℝ) / 2 ≤ (coreCnt : ℝ) then prov
                  else { o := prov.o, V := maxR ^ 2, V_nonneg := sq_nonneg maxR })
                st.activeRecords.toList st.activeRecords.toList
              cumWork := st.cumWork + (1 + Real.log (n : ℝ)) * A_n } = ∅ := by
            ext r
            simp [clsRecords, hClsEmpty]
          rw [hClsRecEmpty, hChildEmpty]
          simp
        · intro params _ _ cfg _
          have hClsSetEmpty : clsSet { st with
              phase := .scan2
                (if α * (S_birth.card : ℝ) / 2 ≤ (coreCnt : ℝ) then prov
                  else { o := prov.o, V := maxR ^ 2, V_nonneg := sq_nonneg maxR })
                st.activeRecords.toList st.activeRecords.toList
              cumWork := st.cumWork + (1 + Real.log (n : ℝ)) * A_n } = ∅ := by
            ext x
            simp [clsSet, clsRecords, hClsEmpty]
          rw [hClsSetEmpty, hMatchEmpty]
          exact empty_satisfiesInvariant pts params _ _ cfg
      · unfold fixBallSnapshotNextState; dsimp only; linarith
      · unfold fixBallSnapshotNextState; dsimp only; linarith
      · intro M2 hM2
        unfold fixBallSnapshotNextState remBgSteps
        dsimp only [List.length_nil]
        rw [hSnapLen]
        omega
  | scan2 ball snap rem =>
    unfold PhaseInv at hPhase; rw [hPh] at hPhase
    dsimp only [PhaseInv] at hPhase
    rcases hPhase with ⟨hballEq, hRadEq, hSnapLen, hRemLen, hRemCls, hChildEq, hMatchInv⟩
    cases rem with
    | cons rec rest =>
      rw [hPh] at hSome
      dsimp only at hSome
      injection hSome with hst'
      subst hst'
      refine ⟨TwoScanBgStep.scan2Record st ball snap rec rest hPh, ?_, ?_, ?_, ?_⟩
      · unfold scan2RecordNextState
        set stAdv := { st with phase := .scan2 ball snap rest }
        by_cases hdo : rec ∈ stAdv.activeRecords ∧ rec.2 ∉ stAdv.classified
        · rw [if_pos hdo]
          have hPoolAdv : IsValidLifetimePool S_cur stAdv.activeRecords stAdv.nextLife := hPool
          have hChildAdv : stAdv.childPool =
              (clsRecords stAdv).filter (fun r => pts r.1 ∉ coreBall ball.o ball.V) := by
            rw [hballEq]; exact hChildEq
          have hMatchAdv : ∀ params : LocalScaleParams, optParams = some params → 0 < ball.V →
              ∀ cfg ∈ params.retainedConfigs ball.V,
                (stAdv.localMatchings cfg).SatisfiesInvariant pts
                  (params.leftVertices pts ball.o ball.V (clsSet stAdv) cfg.j)
                  (params.rightVertices pts ball.o ball.V (clsSet stAdv) cfg.k)
                  (params.weakEdges pts ball.o ball.V (clsSet stAdv) cfg.j cfg.k cfg.ℓ)
                  (params.strongEdges pts ball.o ball.V (clsSet stAdv) cfg.j cfg.k cfg.ℓ) := by
            rw [hballEq]; exact hMatchInv
          rcases classifyActiveRecordAtomically_spec h53 pts hn hAn hPloc hSearch hCapCur
              hPoolAdv hdo.1 hdo.2 hChildAdv hMatchAdv with
            ⟨hAct', hLife', hRad', hHeap', hPh', hCls', _, _, hChild', _, _, hMatch'⟩
          unfold LevelInv PhaseInv
          rw [hPh']
          dsimp only [stAdv] at hAct' hLife' hRad' hHeap' hCls' hChild' hMatch' ⊢
          refine ⟨by rwa [hAct', hLife'], by rwa [hAct'], by rwa [hRad', hAct'],
            by rwa [hAct', hRad', hHeap'], by rwa [hHeap', hLife'], ?_, ?_⟩
          · rw [hCls', hLife']
            intro ℓ hℓ
            rcases Finset.mem_insert.mp hℓ with rfl | hℓ
            · exact hPool.2.2.2 rec hdo.1
            · exact hClsLife ℓ hℓ
          · dsimp only
            refine ⟨hballEq, by rw [hRad', hAct', hRadEq], hSnapLen,
              by dsimp [List.length_cons] at hRemLen; omega, ?_, ?_, ?_⟩
            · rw [hAct', hCls']
              intro r hrA
              rcases hRemCls r hrA with hrem | hcls
              · rw [List.toFinset_cons, Finset.mem_insert] at hrem
                rcases hrem with rfl | hrest
                · exact Or.inr (Finset.mem_insert_self _ _)
                · exact Or.inl hrest
              · exact Or.inr (Finset.mem_insert_of_mem hcls)
            · rw [← hballEq]; exact hChild'
            · rw [← hballEq]; exact hMatch'
        · rw [if_neg hdo]
          unfold LevelInv PhaseInv
          dsimp only [stAdv]
          refine ⟨hPool, hCardB, hRadSub, hRadIff, hHeapLife, hClsLife,
            hballEq, hRadEq, hSnapLen, by dsimp [List.length_cons] at hRemLen; omega,
            ?_, hChildEq, hMatchInv⟩
          intro r hrA
          rcases hRemCls r hrA with hrem | hcls
          · rw [List.toFinset_cons, Finset.mem_insert] at hrem
            rcases hrem with rfl | hrest
            · have h_in_cls : r.2 ∈ st.classified := by
                by_contra hnot
                exact hdo ⟨hrA, hnot⟩
              exact Or.inr h_in_cls
            · exact Or.inl hrest
          · exact Or.inr hcls
      · unfold scan2RecordNextState
        set stAdv := { st with phase := .scan2 ball snap rest }
        by_cases hdo : rec ∈ stAdv.activeRecords ∧ rec.2 ∉ stAdv.classified
        · rw [if_pos hdo]
          have hChildAdv : stAdv.childPool =
              (clsRecords stAdv).filter (fun r => pts r.1 ∉ coreBall ball.o ball.V) := by
            rw [hballEq]; exact hChildEq
          have hMatchAdv : ∀ params : LocalScaleParams, optParams = some params → 0 < ball.V →
              ∀ cfg ∈ params.retainedConfigs ball.V,
                (stAdv.localMatchings cfg).SatisfiesInvariant pts
                  (params.leftVertices pts ball.o ball.V (clsSet stAdv) cfg.j)
                  (params.rightVertices pts ball.o ball.V (clsSet stAdv) cfg.k)
                  (params.weakEdges pts ball.o ball.V (clsSet stAdv) cfg.j cfg.k cfg.ℓ)
                  (params.strongEdges pts ball.o ball.V (clsSet stAdv) cfg.j cfg.k cfg.ℓ) := by
            rw [hballEq]; exact hMatchInv
          rcases classifyActiveRecordAtomically_spec h53 pts hn hAn hPloc hSearch hCapCur
              hPool hdo.1 hdo.2 hChildAdv hMatchAdv with
            ⟨_, _, _, _, _, _, _, _, _, hw0, _, _⟩
          exact hw0
        · rw [if_neg hdo]
          dsimp only [stAdv]
          linarith
      · unfold scan2RecordNextState
        set stAdv := { st with phase := .scan2 ball snap rest }
        by_cases hdo : rec ∈ stAdv.activeRecords ∧ rec.2 ∉ stAdv.classified
        · rw [if_pos hdo]
          have hChildAdv : stAdv.childPool =
              (clsRecords stAdv).filter (fun r => pts r.1 ∉ coreBall ball.o ball.V) := by
            rw [hballEq]; exact hChildEq
          have hMatchAdv : ∀ params : LocalScaleParams, optParams = some params → 0 < ball.V →
              ∀ cfg ∈ params.retainedConfigs ball.V,
                (stAdv.localMatchings cfg).SatisfiesInvariant pts
                  (params.leftVertices pts ball.o ball.V (clsSet stAdv) cfg.j)
                  (params.rightVertices pts ball.o ball.V (clsSet stAdv) cfg.k)
                  (params.weakEdges pts ball.o ball.V (clsSet stAdv) cfg.j cfg.k cfg.ℓ)
                  (params.strongEdges pts ball.o ball.V (clsSet stAdv) cfg.j cfg.k cfg.ℓ) := by
            rw [hballEq]; exact hMatchInv
          rcases classifyActiveRecordAtomically_spec h53 pts hn hAn hPloc hSearch hCapCur
              hPool hdo.1 hdo.2 hChildAdv hMatchAdv with
            ⟨_, _, _, _, _, _, _, _, _, _, hwhi, _⟩
          exact hwhi
        · rw [if_neg hdo]
          dsimp only [stAdv]
          linarith
      · intro M2 _
        unfold scan2RecordNextState
        set stAdv := { st with phase := .scan2 ball snap rest }
        by_cases hdo : rec ∈ stAdv.activeRecords ∧ rec.2 ∉ stAdv.classified
        · rw [if_pos hdo]
          unfold classifyActiveRecordAtomically remBgSteps
          dsimp only [stAdv, List.length_cons]
          omega
        · rw [if_neg hdo]
          unfold remBgSteps
          dsimp only [stAdv, List.length_cons]
          omega
    | nil =>
      rw [hPh] at hSome
      dsimp only at hSome
      injection hSome with hst'
      subst hst'
      refine ⟨TwoScanBgStep.finishScan2 st ball snap hPh, ?_, ?_, ?_, ?_⟩
      · unfold LevelInv PhaseInv
        dsimp only
        refine ⟨hPool, hCardB, hRadSub, hRadIff, hHeapLife, hClsLife,
          hballEq, hRadEq, ?_, hChildEq, hMatchInv⟩
        intro r hrA
        rcases hRemCls r hrA with hrem | hcls
        · simp at hrem
        · exact hcls
      · dsimp only; linarith
      · dsimp only; linarith
      · intro M2 _
        unfold remBgSteps
        dsimp only [List.length_nil]
        omega
  | ready ball =>
    rw [hPh] at hSome
    simp at hSome

open Classical in
theorem levelInv_consequences {d : ℕ} {ι IdxState : Type}
    {α : ℝ} (pts : ι → EuclideanSpace ℝ (Fin d))
    {optParams : Option LocalScaleParams}
    {birthSnapshotList : List (ι × ℕ)} {S_birth S_cur : Finset ι}
    {initNextLife : ℕ} {prov : ChainNode d}
    {insCount : ℕ} {st : TwoScanLevelState d ι IdxState}
    (hNodup : birthSnapshotList.Nodup)
    (hBirthPool : IsValidLifetimePool S_birth birthSnapshotList.toFinset initNextLife)
    (hBirthNonempty : S_birth.Nonempty)
    (hInv : LevelInv α pts optParams birthSnapshotList S_birth prov S_cur insCount st) :
    let fixedBall := applyBirthCoreFallback α pts S_birth prov
    (IsValidLifetimePool S_cur st.activeRecords st.nextLife ∧
      st.radiusDict ⊆ st.activeRecords ∧
      (∀ r ∈ st.activeRecords, r ∈ st.radiusDict ↔ r.2 ∈ st.heapIndexed) ∧
      (∀ (coreCnt : ℕ) (maxR : ℝ),
        st.phase = .scan1 [] coreCnt maxR →
          coreCnt = (prov.core pts S_birth).card ∧
          maxR = nodeMaxRadius pts prov.o S_birth)) ∧
    (∀ ball : ChainNode d,
      st.phase = .ready ball →
        ball = fixedBall ∧
        st.radiusDict = st.activeRecords ∧
        st.radiusDict.image Prod.fst = S_cur ∧
        st.radiusDict.card = S_cur.card ∧
        st.childPool =
          st.activeRecords.filter (fun r => pts r.1 ∉ coreBall fixedBall.o fixedBall.V) ∧
        st.childPool.image Prod.fst = fixedBall.residual pts S_cur ∧
        st.childPool.card = (fixedBall.residual pts S_cur).card ∧
        (∀ r ∈ st.activeRecords, r.2 ∈ st.classified) ∧
        (∀ params : LocalScaleParams, optParams = some params → 0 < fixedBall.V →
          ∀ cfg ∈ params.retainedConfigs fixedBall.V,
            (st.localMatchings cfg).SatisfiesInvariant pts
              (params.leftVertices pts fixedBall.o fixedBall.V S_cur cfg.j)
              (params.rightVertices pts fixedBall.o fixedBall.V S_cur cfg.k)
              (params.weakEdges pts fixedBall.o fixedBall.V S_cur cfg.j cfg.k cfg.ℓ)
              (params.strongEdges pts fixedBall.o fixedBall.V S_cur cfg.j cfg.k cfg.ℓ))) := by
  rcases hInv with ⟨hPool, _, hRadSub, hRadIff, _, _, hPhase⟩
  refine ⟨⟨hPool, hRadSub, hRadIff, ?_⟩, ?_⟩
  · intro coreCnt maxR hPh
    unfold PhaseInv at hPhase; rw [hPh] at hPhase
    dsimp only [PhaseInv] at hPhase
    rcases hPhase with ⟨hcC, hmR, hmR0, _, _, _, _⟩
    have h0c : listCoreCount pts prov [] = 0 := rfl
    have h0m : listMaxR pts prov [] = 0 := rfl
    rw [h0c, Nat.add_zero] at hcC
    rw [h0m, max_eq_left hmR0] at hmR
    exact ⟨hcC.trans (listCoreCount_eq_birthCoreCard pts prov hNodup hBirthPool),
      hmR.trans (listMaxR_eq_nodeMaxRadius pts prov hBirthPool hBirthNonempty)⟩
  · intro ball hPh
    unfold PhaseInv at hPhase; rw [hPh] at hPhase
    dsimp only [PhaseInv] at hPhase
    rcases hPhase with ⟨hballEq, hRadEq, hAllCls, hChildEq, hMatchInv⟩
    have hClsRecAll : clsRecords st = st.activeRecords :=
      Finset.filter_true_of_mem hAllCls
    have hClsSetAll : clsSet st = S_cur := by
      unfold clsSet
      rw [hClsRecAll, hPool.1]
    have hChildAct :
        st.childPool = st.activeRecords.filter (fun r => pts r.1 ∉ coreBall (applyBirthCoreFallback α pts S_birth prov).o (applyBirthCoreFallback α pts S_birth prov).V) := by
      rw [hChildEq, hClsRecAll]
    have hChildImg :
        st.childPool.image Prod.fst = (applyBirthCoreFallback α pts S_birth prov).residual pts S_cur := by
      rw [hChildAct]
      unfold ChainNode.residual nodeResidual nodeCore
      ext x
      simp only [Finset.mem_image, Finset.mem_filter, Finset.mem_sdiff]
      constructor
      · rintro ⟨r, ⟨hrA, hrNot⟩, rfl⟩
        rw [← hPool.1]
        exact ⟨Finset.mem_image_of_mem Prod.fst hrA, fun ⟨_, hc⟩ => hrNot hc⟩
      · rintro ⟨hxS, hxNot⟩
        rw [← hPool.1] at hxS hxNot
        rcases Finset.mem_image.mp hxS with ⟨r, hrA, rfl⟩
        exact ⟨r, ⟨hrA, fun hc => hxNot ⟨Finset.mem_image_of_mem Prod.fst hrA, hc⟩⟩, rfl⟩
    have hChildCard :
        st.childPool.card = ((applyBirthCoreFallback α pts S_birth prov).residual pts S_cur).card := by
      rw [← hChildImg, Finset.card_image_of_injOn]
      rw [hChildAct]
      exact hPool.2.1.mono (Finset.coe_subset.mpr (Finset.filter_subset _ _))
    refine ⟨hballEq, hRadEq, ?_, ?_, hChildAct, hChildImg, hChildCard, hAllCls, ?_⟩
    · rw [hRadEq, hPool.1]
    · rw [hRadEq, ← hPool.1, Finset.card_image_of_injOn hPool.2.1]
    · rw [← hClsSetAll]
      exact hMatchInv

end UL.C2ScansRaceV30
