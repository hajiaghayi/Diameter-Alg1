import Mathlib
import UL.Def.def_computation_model
import UL.Proof.lem_5_6.H1_Math
import UL.Proof.lem_6_3.H1_RAM
set_option autoImplicit false

namespace UL.Proof_lem_5_6

open UL.Proof_lem_6_3

/-! ### 1. Fuel monotonicity and halting witness lemma for `BitRAM` -/

theorem runBitRAMFuel_mono {d : ℕ} (inp : BitRAMInput d) :
    ∀ {fuel₁ fuel₂ : ℕ} {stack : List BitRAMCont} {st : BitRAMExecState}
      {res : BitRAMRunStatus},
      res ≠ .outOfFuel →
      fuel₁ ≤ fuel₂ →
      runBitRAMFuel inp fuel₁ stack st = res →
      runBitRAMFuel inp fuel₂ stack st = res
  | f₁, f₂, [], st, res, _, _, hrun => by
      cases f₁ <;> cases f₂ <;> simpa [runBitRAMFuel] using hrun
  | 0, _, _ :: _, _, res, hne, _, hrun => by
      simp [runBitRAMFuel] at hrun
      exact absurd hrun.symm hne
  | f₁ + 1, 0, _ :: _, _, _, _, hle, _ => by omega
  | f₁ + 1, f₂ + 1, item :: rest, st, res, hne, hle, hrun => by
      have hle' : f₁ ≤ f₂ := by omega
      cases item with
      | popScope prev =>
          simp only [runBitRAMFuel] at hrun ⊢
          exact runBitRAMFuel_mono inp hne hle' hrun
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | succ r =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
      | stmt s =>
          cases s with
          | skip =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | writeHeap table idxE valE =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | writeLocal var idxE valE =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | freeHeap table idxE =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | freeLocal var idxE =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | randBitHeap table idxE =>
              cases hbits : st.remainingBits with
              | nil =>
                  simp [runBitRAMFuel, hbits] at hrun ⊢
                  exact hrun
              | cons bit bs' =>
                  simp only [runBitRAMFuel, hbits] at hrun ⊢
                  exact runBitRAMFuel_mono inp hne hle' hrun
          | randBitLocal var idxE =>
              cases hbits : st.remainingBits with
              | nil =>
                  simp [runBitRAMFuel, hbits] at hrun ⊢
                  exact hrun
              | cons bit bs' =>
                  simp only [runBitRAMFuel, hbits] at hrun ⊢
                  exact runBitRAMFuel_mono inp hne hle' hrun
          | seq s₁ s₂ =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | ite cond tBranch fBranch =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | whileLoop cond body =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | repeatN countE body =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | localScope body =>
              simp only [runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun

theorem runBitRAMWithBits_eq_some_of_fuel {d : ℕ} (prog : BitRAMStmt) (inp : BitRAMInput d)
    (initWords : WordStore) (bs : List Bool) (fuel : ℕ) (out : BitRAMExecOutcome)
    (hrun : runBitRAMFuel inp fuel [.stmt prog]
      { words := initWords.popDepth 0
        frameDepth := 0
        remainingBits := bs
        unitCost := 0
        bitCost := 0
        peakCellSpace := inp.inputCellSpace + (initWords.popDepth 0).cellCount
        peakBitSpace := inp.inputBitSpace + (initWords.popDepth 0).bitSize } = .halted out) :
    runBitRAMWithBits prog inp initWords bs = some out := by
  classical
  unfold runBitRAMWithBits
  dsimp only
  have hex : ∃ f : ℕ, ∃ o : BitRAMExecOutcome,
      runBitRAMFuel inp f [.stmt prog]
        { words := initWords.popDepth 0, frameDepth := 0, remainingBits := bs,
          unitCost := 0, bitCost := 0,
          peakCellSpace := inp.inputCellSpace + (initWords.popDepth 0).cellCount,
          peakBitSpace := inp.inputBitSpace + (initWords.popDepth 0).bitSize } =
        .halted o := ⟨fuel, out, hrun⟩
  rw [dif_pos hex]
  have hle : Nat.find hex ≤ fuel := Nat.find_min' hex ⟨out, hrun⟩
  rcases Nat.find_spec hex with ⟨o₀, ho₀⟩
  have heq : BitRAMRunStatus.halted o₀ = .halted out := by
    have hm := runBitRAMFuel_mono inp (by simp) hle ho₀
    rw [hrun] at hm
    exact hm.symm
  cases heq
  simp [ho₀]

/-! ### 2. Input-free heap syntax translation & lockstep `BitRAM` → `ArithRAM` simulation -/

def PureHeapExpr : IntExpr → Bool
  | .lit _ => true
  | .readHeap _ idxE => PureHeapExpr idxE
  | .neg e => PureHeapExpr e
  | .add e₁ e₂ => PureHeapExpr e₁ && PureHeapExpr e₂
  | .sub e₁ e₂ => PureHeapExpr e₁ && PureHeapExpr e₂
  | .mul e₁ e₂ => PureHeapExpr e₁ && PureHeapExpr e₂
  | .div e₁ e₂ => PureHeapExpr e₁ && PureHeapExpr e₂
  | .mod e₁ e₂ => PureHeapExpr e₁ && PureHeapExpr e₂
  | _ => false

def PureHeapCond : BitCondExpr → Bool
  | .intEq e₁ e₂ => PureHeapExpr e₁ && PureHeapExpr e₂
  | .intLt e₁ e₂ => PureHeapExpr e₁ && PureHeapExpr e₂
  | .intLe e₁ e₂ => PureHeapExpr e₁ && PureHeapExpr e₂
  | .not c => PureHeapCond c
  | .and c₁ c₂ => PureHeapCond c₁ && PureHeapCond c₂
  | .or c₁ c₂ => PureHeapCond c₁ && PureHeapCond c₂

def PureHeapStmt : BitRAMStmt → Bool
  | .skip => true
  | .writeHeap _ idxE valE => PureHeapExpr idxE && PureHeapExpr valE
  | .seq s₁ s₂ => PureHeapStmt s₁ && PureHeapStmt s₂
  | .ite c tB fB => PureHeapCond c && PureHeapStmt tB && PureHeapStmt fB
  | .whileLoop c body => PureHeapCond c && PureHeapStmt body
  | .repeatN cntE body => PureHeapExpr cntE && PureHeapStmt body
  | _ => false

def PureHeapCont : BitRAMCont → Bool
  | .stmt s => PureHeapStmt s
  | .repeatLoop _ body => PureHeapStmt body
  | .popScope _ => false

def bitCondToArith : BitCondExpr → ArithCondExpr
  | .intEq e₁ e₂ => .intEq e₁ e₂
  | .intLt e₁ e₂ => .intLt e₁ e₂
  | .intLe e₁ e₂ => .intLe e₁ e₂
  | .not c => .not (bitCondToArith c)
  | .and c₁ c₂ => .and (bitCondToArith c₁) (bitCondToArith c₂)
  | .or c₁ c₂ => .or (bitCondToArith c₁) (bitCondToArith c₂)

def bitStmtToArith : BitRAMStmt → ArithRAMStmt
  | .skip => .skip
  | .writeHeap t idxE valE => .writeWordHeap t idxE valE
  | .writeLocal v idxE valE => .writeWordLocal v idxE valE
  | .freeHeap t idxE => .freeWordHeap t idxE
  | .freeLocal v idxE => .freeWordLocal v idxE
  | .randBitHeap t idxE => .randBitHeap t idxE
  | .randBitLocal v idxE => .randBitLocal v idxE
  | .seq s₁ s₂ => .seq (bitStmtToArith s₁) (bitStmtToArith s₂)
  | .ite c tB fB => .ite (bitCondToArith c) (bitStmtToArith tB) (bitStmtToArith fB)
  | .whileLoop c body => .whileLoop (bitCondToArith c) (bitStmtToArith body)
  | .repeatN cntE body => .repeatN cntE (bitStmtToArith body)
  | .localScope body => .localScope (bitStmtToArith body)

def bitContToArith : BitRAMCont → ArithRAMCont
  | .stmt s => .stmt (bitStmtToArith s)
  | .repeatLoop rem body => .repeatLoop rem (bitStmtToArith body)
  | .popScope prev => .popScope prev

theorem pureHeapExpr_eval_eq {d : ℕ} (inp₁ inp₂ : BitRAMInput d) (fd : ℕ) (ws : WordStore) :
    ∀ {e : IntExpr}, PureHeapExpr e = true →
      evalIntExpr inp₁ fd ws e = evalIntExpr inp₂ fd ws e
  | .lit _, _ => rfl
  | .readHeap t idxE, h => by
      simp only [PureHeapExpr] at h
      simp [evalIntExpr, pureHeapExpr_eval_eq inp₁ inp₂ fd ws h]
  | .neg e, h => by
      simp only [PureHeapExpr] at h
      simp [evalIntExpr, pureHeapExpr_eval_eq inp₁ inp₂ fd ws h]
  | .add e₁ e₂, h => by
      simp only [PureHeapExpr, Bool.and_eq_true] at h
      simp [evalIntExpr, pureHeapExpr_eval_eq inp₁ inp₂ fd ws h.1,
        pureHeapExpr_eval_eq inp₁ inp₂ fd ws h.2]
  | .sub e₁ e₂, h => by
      simp only [PureHeapExpr, Bool.and_eq_true] at h
      simp [evalIntExpr, pureHeapExpr_eval_eq inp₁ inp₂ fd ws h.1,
        pureHeapExpr_eval_eq inp₁ inp₂ fd ws h.2]
  | .mul e₁ e₂, h => by
      simp only [PureHeapExpr, Bool.and_eq_true] at h
      simp [evalIntExpr, pureHeapExpr_eval_eq inp₁ inp₂ fd ws h.1,
        pureHeapExpr_eval_eq inp₁ inp₂ fd ws h.2]
  | .div e₁ e₂, h => by
      simp only [PureHeapExpr, Bool.and_eq_true] at h
      simp [evalIntExpr, pureHeapExpr_eval_eq inp₁ inp₂ fd ws h.1,
        pureHeapExpr_eval_eq inp₁ inp₂ fd ws h.2]
  | .mod e₁ e₂, h => by
      simp only [PureHeapExpr, Bool.and_eq_true] at h
      simp [evalIntExpr, pureHeapExpr_eval_eq inp₁ inp₂ fd ws h.1,
        pureHeapExpr_eval_eq inp₁ inp₂ fd ws h.2]

theorem pureHeapCond_eval_eq {d : ℕ} (inpB : BitRAMInput d) (inpA : ArithRAMInput d)
    (fd : ℕ) (ws : WordStore) (rs : RealStore) :
    ∀ {c : BitCondExpr}, PureHeapCond c = true →
      evalArithCond inpA fd { words := ws, reals := rs } (bitCondToArith c) =
        ((evalBitCond inpB fd ws c).1, (evalBitCond inpB fd ws c).2.1)
  | .intEq e₁ e₂, h => by
      simp only [PureHeapCond, Bool.and_eq_true] at h
      rw [bitCondToArith, evalArithCond, evalBitCond,
        pureHeapExpr_eval_eq inpA.toWordView inpB fd ws h.1,
        pureHeapExpr_eval_eq inpA.toWordView inpB fd ws h.2]
  | .intLt e₁ e₂, h => by
      simp only [PureHeapCond, Bool.and_eq_true] at h
      rw [bitCondToArith, evalArithCond, evalBitCond,
        pureHeapExpr_eval_eq inpA.toWordView inpB fd ws h.1,
        pureHeapExpr_eval_eq inpA.toWordView inpB fd ws h.2]
  | .intLe e₁ e₂, h => by
      simp only [PureHeapCond, Bool.and_eq_true] at h
      rw [bitCondToArith, evalArithCond, evalBitCond,
        pureHeapExpr_eval_eq inpA.toWordView inpB fd ws h.1,
        pureHeapExpr_eval_eq inpA.toWordView inpB fd ws h.2]
  | .not c, h => by
      simp only [PureHeapCond] at h
      have ih := pureHeapCond_eval_eq inpB inpA fd ws rs h
      simp only [bitCondToArith, evalArithCond, evalBitCond, ih]
  | .and c₁ c₂, h => by
      simp only [PureHeapCond, Bool.and_eq_true] at h
      have ih₁ := pureHeapCond_eval_eq inpB inpA fd ws rs h.1
      have ih₂ := pureHeapCond_eval_eq inpB inpA fd ws rs h.2
      simp only [bitCondToArith, evalArithCond, evalBitCond, ih₁, ih₂]
  | .or c₁ c₂, h => by
      simp only [PureHeapCond, Bool.and_eq_true] at h
      have ih₁ := pureHeapCond_eval_eq inpB inpA fd ws rs h.1
      have ih₂ := pureHeapCond_eval_eq inpB inpA fd ws rs h.2
      simp only [bitCondToArith, evalArithCond, evalBitCond, ih₁, ih₂]

theorem pureHeapFuel_sim {d : ℕ} (inpB : BitRAMInput d) (inpA : ArithRAMInput d) :
    ∀ (fuel : ℕ) (stack : List BitRAMCont) (ws : WordStore) (u b mc pb : ℕ)
      (outB : BitRAMExecOutcome),
      (∀ item ∈ stack, PureHeapCont item = true) →
      runBitRAMFuel inpB fuel stack
        { words := ws, frameDepth := 0, remainingBits := [],
          unitCost := u, bitCost := b,
          peakCellSpace := inpB.inputCellSpace + mc, peakBitSpace := pb } = .halted outB →
      ∃ mc' : ℕ,
        outB.peakCellSpace = inpB.inputCellSpace + mc' ∧
        runArithRAMFuel inpA fuel (stack.map bitContToArith)
          { mem := { words := ws, reals := RealStore.empty },
            frameDepth := 0, remainingBits := [],
            unitCost := u,
            peakCellSpace := inpA.inputCellSpace + mc } =
          .halted
            { mem := { words := outB.words, reals := RealStore.empty },
              unitCost := outB.unitCost,
              peakCellSpace := inpA.inputCellSpace + mc' }
  | fuel, [], ws, u, b, mc, pb, outB, _, hrun => by
      simp only [runBitRAMFuel, List.isEmpty_nil, ↓reduceIte, BitRAMRunStatus.halted.injEq] at hrun
      subst hrun
      have hre : RealStore.empty.popDepth 0 = RealStore.empty := cleanReals_empty
      refine ⟨mc, rfl, ?_⟩
      simp only [List.map_nil, runArithRAMFuel, List.isEmpty_nil, ↓reduceIte,
        ArithRAMMemory.popDepth, hre]
  | 0, _ :: _, _, _, _, _, _, _, _, hrun => by
      simp [runBitRAMFuel] at hrun
  | fuel + 1, item :: rest, ws, u, b, mc, pb, outB, hstack, hrun => by
      have hitem : PureHeapCont item = true := hstack item List.mem_cons_self
      have hrest : ∀ x ∈ rest, PureHeapCont x = true :=
        fun x hx => hstack x (List.mem_cons_of_mem _ hx)
      cases item with
      | popScope prev =>
          simp [PureHeapCont] at hitem
      | repeatLoop rem body =>
          simp only [PureHeapCont] at hitem
          cases rem with
          | zero =>
              simp only [runBitRAMFuel] at hrun
              simp only [List.map_cons, bitContToArith, runArithRAMFuel]
              exact pureHeapFuel_sim inpB inpA fuel rest ws u b mc pb outB hrest hrun
          | succ r =>
              simp only [runBitRAMFuel] at hrun
              simp only [List.map_cons, bitContToArith, runArithRAMFuel]
              have hstack' : ∀ x ∈ (BitRAMCont.stmt body :: .repeatLoop r body :: rest),
                  PureHeapCont x = true := by
                intro x hx
                simp only [List.mem_cons] at hx
                rcases hx with rfl | rfl | hx
                · exact hitem
                · exact hitem
                · exact hrest x hx
              simpa [List.map_cons, bitContToArith] using
                pureHeapFuel_sim inpB inpA fuel
                  (.stmt body :: .repeatLoop r body :: rest) ws u b mc pb outB hstack' hrun
      | stmt s =>
          simp only [PureHeapCont] at hitem
          cases s with
          | skip =>
              simp only [runBitRAMFuel] at hrun
              simp only [List.map_cons, bitContToArith, bitStmtToArith, runArithRAMFuel]
              exact pureHeapFuel_sim inpB inpA fuel rest ws (u + 1) (b + 1) mc pb outB hrest hrun
          | writeHeap table idxE valE =>
              simp only [PureHeapStmt, Bool.and_eq_true] at hitem
              have hidx := pureHeapExpr_eval_eq inpA.toWordView inpB 0 ws hitem.1
              have hval := pureHeapExpr_eval_eq inpA.toWordView inpB 0 ws hitem.2
              rcases he₁ : evalIntExpr inpB 0 ws idxE with ⟨idx, u₁, b₁⟩
              rcases he₂ : evalIntExpr inpB 0 ws valE with ⟨val, u₂, b₂⟩
              rw [he₁] at hidx
              rw [he₂] at hval
              have hmaxB : max (inpB.inputCellSpace + mc)
                  (inpB.inputCellSpace + (ws.write (.heap table idx) val).cellCount) =
                  inpB.inputCellSpace + max mc (ws.write (.heap table idx) val).cellCount := by
                omega
              have hcellA : ({ words := ws.write (.heap table idx) val, reals := RealStore.empty } :
                  ArithRAMMemory).cellCount = (ws.write (.heap table idx) val).cellCount := by
                simp [ArithRAMMemory.cellCount, RealStore.cellCount, RealStore.empty]
              have hmaxA : max (inpA.inputCellSpace + mc)
                  (inpA.inputCellSpace + (ws.write (.heap table idx) val).cellCount) =
                  inpA.inputCellSpace + max mc (ws.write (.heap table idx) val).cellCount := by
                omega
              dsimp only [runBitRAMFuel] at hrun
              rw [he₁, he₂] at hrun
              dsimp only at hrun
              rw [hmaxB] at hrun
              dsimp only [List.map_cons, bitContToArith, bitStmtToArith, runArithRAMFuel]
              rw [hidx, hval]
              dsimp only
              rw [hcellA, hmaxA]
              exact pureHeapFuel_sim inpB inpA fuel rest (ws.write (.heap table idx) val)
                (u + u₁ + u₂ + 1)
                (b + b₁ + b₂ + (RAMCellLoc.heap table idx).bitLength + intBitLength val)
                (max mc (ws.write (.heap table idx) val).cellCount)
                (max pb (inpB.inputBitSpace + (ws.write (.heap table idx) val).bitSize))
                outB hrest hrun
          | writeLocal _ _ _ => simp [PureHeapStmt] at hitem
          | freeHeap _ _ => simp [PureHeapStmt] at hitem
          | freeLocal _ _ => simp [PureHeapStmt] at hitem
          | randBitHeap _ _ => simp [PureHeapStmt] at hitem
          | randBitLocal _ _ => simp [PureHeapStmt] at hitem
          | localScope _ => simp [PureHeapStmt] at hitem
          | seq s₁ s₂ =>
              simp only [PureHeapStmt, Bool.and_eq_true] at hitem
              simp only [runBitRAMFuel] at hrun
              simp only [List.map_cons, bitContToArith, bitStmtToArith, runArithRAMFuel]
              have hstack' : ∀ x ∈ (BitRAMCont.stmt s₁ :: .stmt s₂ :: rest),
                  PureHeapCont x = true := by
                intro x hx
                simp only [List.mem_cons] at hx
                rcases hx with rfl | rfl | hx
                · exact hitem.1
                · exact hitem.2
                · exact hrest x hx
              simpa [List.map_cons, bitContToArith] using
                pureHeapFuel_sim inpB inpA fuel (.stmt s₁ :: .stmt s₂ :: rest)
                  ws u b mc pb outB hstack' hrun
          | ite cond tB fB =>
              simp only [PureHeapStmt, Bool.and_eq_true] at hitem
              have hcond := pureHeapCond_eval_eq inpB inpA 0 ws RealStore.empty hitem.1.1
              rcases hc : evalBitCond inpB 0 ws cond with ⟨flag, u_c, b_c⟩
              rw [hc] at hcond
              simp only [runBitRAMFuel, hc] at hrun
              simp only [List.map_cons, bitContToArith, bitStmtToArith, runArithRAMFuel, hcond]
              cases flag
              · simp only [Bool.false_eq_true, ↓reduceIte] at hrun ⊢
                have hstack' : ∀ x ∈ (BitRAMCont.stmt fB :: rest), PureHeapCont x = true := by
                  intro x hx
                  rcases List.mem_cons.mp hx with rfl | hx
                  · exact hitem.2
                  · exact hrest x hx
                simpa [List.map_cons, bitContToArith] using
                  pureHeapFuel_sim inpB inpA fuel (.stmt fB :: rest)
                    ws (u + u_c) (b + b_c) mc pb outB hstack' hrun
              · simp only [↓reduceIte] at hrun ⊢
                have hstack' : ∀ x ∈ (BitRAMCont.stmt tB :: rest), PureHeapCont x = true := by
                  intro x hx
                  rcases List.mem_cons.mp hx with rfl | hx
                  · exact hitem.1.2
                  · exact hrest x hx
                simpa [List.map_cons, bitContToArith] using
                  pureHeapFuel_sim inpB inpA fuel (.stmt tB :: rest)
                    ws (u + u_c) (b + b_c) mc pb outB hstack' hrun
          | whileLoop cond body =>
              simp only [PureHeapStmt, Bool.and_eq_true] at hitem
              have hcond := pureHeapCond_eval_eq inpB inpA 0 ws RealStore.empty hitem.1
              rcases hc : evalBitCond inpB 0 ws cond with ⟨flag, u_c, b_c⟩
              rw [hc] at hcond
              simp only [runBitRAMFuel, hc] at hrun
              simp only [List.map_cons, bitContToArith, bitStmtToArith, runArithRAMFuel, hcond]
              cases flag
              · simp only [Bool.false_eq_true, ↓reduceIte] at hrun ⊢
                exact pureHeapFuel_sim inpB inpA fuel rest
                  ws (u + u_c) (b + b_c) mc pb outB hrest hrun
              · simp only [↓reduceIte] at hrun ⊢
                have hstack' : ∀ x ∈ (BitRAMCont.stmt body :: .stmt (.whileLoop cond body) :: rest),
                    PureHeapCont x = true := by
                  intro x hx
                  simp only [List.mem_cons] at hx
                  rcases hx with rfl | rfl | hx
                  · exact hitem.2
                  · simp [PureHeapCont, PureHeapStmt, hitem.1, hitem.2]
                  · exact hrest x hx
                simpa [List.map_cons, bitContToArith, bitStmtToArith] using
                  pureHeapFuel_sim inpB inpA fuel
                    (.stmt body :: .stmt (.whileLoop cond body) :: rest)
                    ws (u + u_c) (b + b_c) mc pb outB hstack' hrun
          | repeatN cntE body =>
              simp only [PureHeapStmt, Bool.and_eq_true] at hitem
              have hcnt := pureHeapExpr_eval_eq inpA.toWordView inpB 0 ws hitem.1
              rcases hc : evalIntExpr inpB 0 ws cntE with ⟨cnt, u_c, b_c⟩
              rw [hc] at hcnt
              simp only [runBitRAMFuel, hc] at hrun
              simp only [List.map_cons, bitContToArith, bitStmtToArith, runArithRAMFuel, hcnt]
              let nIter := if 0 ≤ cnt then cnt.toNat else 0
              have hstack' : ∀ x ∈ (BitRAMCont.repeatLoop nIter body :: rest),
                  PureHeapCont x = true := by
                intro x hx
                rcases List.mem_cons.mp hx with rfl | hx
                · exact hitem.2
                · exact hrest x hx
              simpa [List.map_cons, bitContToArith] using
                pureHeapFuel_sim inpB inpA fuel (.repeatLoop nIter body :: rest)
                  ws (u + u_c) (b + b_c) mc pb outB hstack' hrun

/-! ### 3. Compositional big-step relation `ExecBit` for deterministic heap-only `BitRAM` -/

def mkBitState {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (u b mc pb : ℕ) : BitRAMExecState :=
  { words := ws
    frameDepth := 0
    remainingBits := []
    unitCost := u
    bitCost := b
    peakCellSpace := inp.inputCellSpace + mc
    peakBitSpace := pb }

def ExecBit {d : ℕ} (inp : BitRAMInput d) (s : BitRAMStmt)
    (ws₀ ws₁ : WordStore) (U B M_cell S_bit : ℕ) : Prop :=
  CleanWords ws₀ ∧ CleanWords ws₁ ∧
  ∀ (u₀ b₀ mc₀ pb₀ : ℕ) (rest : List BitRAMCont),
    ∃ (fuel₀ u₁ b₁ mc₁ pb₁ : ℕ),
      u₁ ≤ u₀ + U ∧
      b₁ ≤ b₀ + B ∧
      mc₁ ≤ max mc₀ M_cell ∧
      pb₁ ≤ max pb₀ S_bit ∧
      ∀ fuel : ℕ,
        runBitRAMFuel inp (fuel₀ + fuel) (.stmt s :: rest) (mkBitState inp ws₀ u₀ b₀ mc₀ pb₀) =
          runBitRAMFuel inp fuel rest (mkBitState inp ws₁ u₁ b₁ mc₁ pb₁)

theorem ExecBit.mono {d : ℕ} {inp : BitRAMInput d} {s : BitRAMStmt} {ws₀ ws₁ : WordStore}
    {U₁ U₂ B₁ B₂ M_cell S_bit : ℕ}
    (h : ExecBit inp s ws₀ ws₁ U₁ B₁ M_cell S_bit) (hU : U₁ ≤ U₂) (hB : B₁ ≤ B₂) :
    ExecBit inp s ws₀ ws₁ U₂ B₂ M_cell S_bit := by
  refine ⟨h.1, h.2.1, fun u₀ b₀ mc₀ pb₀ rest => ?_⟩
  rcases h.2.2 u₀ b₀ mc₀ pb₀ rest with ⟨f, u₁, b₁, mc₁, pb₁, hu, hb, hmc, hpb, hstep⟩
  exact ⟨f, u₁, b₁, mc₁, pb₁, by omega, by omega, hmc, hpb, hstep⟩

theorem ExecBit.to_run {d : ℕ} {inp : BitRAMInput d} {prog : BitRAMStmt}
    {ws₁ : WordStore} {U B M_cell S_bit : ℕ}
    (h : ExecBit inp prog WordStore.empty ws₁ U B M_cell S_bit)
    (hInBit : inp.inputBitSpace ≤ S_bit) :
    ∃ out : BitRAMExecOutcome,
      runBitRAMWithBits prog inp WordStore.empty [] = some out ∧
      out.words = ws₁ ∧
      out.unitCost ≤ U ∧
      out.bitCost ≤ B ∧
      out.peakCellSpace ≤ inp.inputCellSpace + M_cell ∧
      out.peakBitSpace ≤ S_bit := by
  rcases h with ⟨hclean₀, hclean₁, hrun⟩
  have hempty_cell : WordStore.empty.cellCount = 0 := by
    simp [WordStore.cellCount, WordStore.empty]
  have hempty_bit : WordStore.empty.bitSize = 0 := by
    simp [WordStore.bitSize, WordStore.empty]
  rcases hrun 0 0 0 inp.inputBitSpace [] with
    ⟨fuel₀, u₁, b₁, mc₁, pb₁, hu₁, hb₁, hmc₁, hpb₁, hstep⟩
  let out : BitRAMExecOutcome :=
    { words := ws₁
      unitCost := u₁
      bitCost := b₁
      peakCellSpace := inp.inputCellSpace + mc₁
      peakBitSpace := pb₁ }
  refine ⟨out, ?_, rfl, by dsimp [out]; omega, by dsimp [out]; omega,
    by dsimp [out]; omega, by dsimp [out]; omega⟩
  apply runBitRAMWithBits_eq_some_of_fuel prog inp WordStore.empty [] (fuel₀ + 1) out
  rw [hclean₀, hempty_cell, hempty_bit, Nat.add_zero]
  change runBitRAMFuel inp (fuel₀ + 1) [.stmt prog]
      (mkBitState inp WordStore.empty 0 0 0 inp.inputBitSpace) = .halted out
  rw [hstep 1]
  dsimp [runBitRAMFuel, mkBitState, out]
  rw [hclean₁]

theorem ExecBit.writeHeap {d : ℕ} (inp : BitRAMInput d) {ws : WordStore}
    (hc : CleanWords ws) (table : ℕ) (idxE valE : IntExpr)
    {idx val : ℤ} {u₁ u₂ b₁ b₂ U B M_cell S_bit : ℕ}
    (hidx : evalIntExpr inp 0 ws idxE = (idx, u₁, b₁))
    (hval : evalIntExpr inp 0 ws valE = (val, u₂, b₂))
    (hU : u₁ + u₂ + 1 ≤ U)
    (hB : b₁ + b₂ + (RAMCellLoc.heap table idx).bitLength + intBitLength val ≤ B)
    (hCell : (ws.write (.heap table idx) val).cellCount ≤ M_cell)
    (hBit : inp.inputBitSpace + (ws.write (.heap table idx) val).bitSize ≤ S_bit) :
    ExecBit inp (.writeHeap table idxE valE) ws (ws.write (.heap table idx) val)
      U B M_cell S_bit := by
  refine ⟨hc, cleanWords_write_heap hc table idx val, fun u₀ b₀ mc₀ pb₀ rest => ?_⟩
  refine ⟨1, u₀ + u₁ + u₂ + 1,
    b₀ + b₁ + b₂ + (RAMCellLoc.heap table idx).bitLength + intBitLength val,
    max mc₀ (ws.write (.heap table idx) val).cellCount,
    max pb₀ (inp.inputBitSpace + (ws.write (.heap table idx) val).bitSize),
    by omega, by omega, by omega, by omega, fun fuel => ?_⟩
  rw [Nat.add_comm 1 fuel]
  have hmax : max (inp.inputCellSpace + mc₀)
      (inp.inputCellSpace + (ws.write (.heap table idx) val).cellCount) =
      inp.inputCellSpace + max mc₀ (ws.write (.heap table idx) val).cellCount := by
    omega
  dsimp only [runBitRAMFuel, mkBitState]
  rw [hidx, hval]
  dsimp only
  rw [hmax]

theorem ExecBit.seq {d : ℕ} {inp : BitRAMInput d} {s₁ s₂ : BitRAMStmt}
    {ws₀ ws₁ ws₂ : WordStore} {U₁ U₂ B₁ B₂ M_cell S_bit : ℕ}
    (h₁ : ExecBit inp s₁ ws₀ ws₁ U₁ B₁ M_cell S_bit)
    (h₂ : ExecBit inp s₂ ws₁ ws₂ U₂ B₂ M_cell S_bit) :
    ExecBit inp (.seq s₁ s₂) ws₀ ws₂ (U₁ + U₂) (B₁ + B₂) M_cell S_bit := by
  refine ⟨h₁.1, h₂.2.1, fun u₀ b₀ mc₀ pb₀ rest => ?_⟩
  rcases h₁.2.2 u₀ b₀ mc₀ pb₀ (.stmt s₂ :: rest) with
    ⟨f₁, u₁, b₁, mc₁, pb₁, hu₁, hb₁, hmc₁, hpb₁, hs₁⟩
  rcases h₂.2.2 u₁ b₁ mc₁ pb₁ rest with
    ⟨f₂, u₂, b₂, mc₂, pb₂, hu₂, hb₂, hmc₂, hpb₂, hs₂⟩
  refine ⟨1 + f₁ + f₂, u₂, b₂, mc₂, pb₂, by omega, by omega, by omega, by omega, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + f₂ + fuel = (f₁ + (f₂ + fuel)) + 1 := by omega
  rw [hfuel]
  dsimp only [runBitRAMFuel]
  rw [hs₁ (f₂ + fuel), hs₂ fuel]

theorem ExecBit.ite_true {d : ℕ} {inp : BitRAMInput d} {cond : BitCondExpr}
    {tB fB : BitRAMStmt} {ws₀ ws₁ : WordStore} {u_c b_c U_c B_c U_b B_b M_cell S_bit : ℕ}
    (hcond : evalBitCond inp 0 ws₀ cond = (true, u_c, b_c))
    (hu : u_c ≤ U_c) (hb : b_c ≤ B_c)
    (ht : ExecBit inp tB ws₀ ws₁ U_b B_b M_cell S_bit) :
    ExecBit inp (.ite cond tB fB) ws₀ ws₁ (U_c + U_b) (B_c + B_b) M_cell S_bit := by
  refine ⟨ht.1, ht.2.1, fun u₀ b₀ mc₀ pb₀ rest => ?_⟩
  rcases ht.2.2 (u₀ + u_c) (b₀ + b_c) mc₀ pb₀ rest with
    ⟨f₁, u₁, b₁, mc₁, pb₁, hu₁, hb₁, hmc₁, hpb₁, hstep⟩
  refine ⟨1 + f₁, u₁, b₁, mc₁, pb₁, by omega, by omega, hmc₁, hpb₁, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + fuel = (f₁ + fuel) + 1 := by omega
  rw [hfuel]
  simp only [runBitRAMFuel, mkBitState, hcond, ↓reduceIte]
  exact hstep fuel

theorem ExecBit.ite_false {d : ℕ} {inp : BitRAMInput d} {cond : BitCondExpr}
    {tB fB : BitRAMStmt} {ws₀ ws₁ : WordStore} {u_c b_c U_c B_c U_b B_b M_cell S_bit : ℕ}
    (hcond : evalBitCond inp 0 ws₀ cond = (false, u_c, b_c))
    (hu : u_c ≤ U_c) (hb : b_c ≤ B_c)
    (hf : ExecBit inp fB ws₀ ws₁ U_b B_b M_cell S_bit) :
    ExecBit inp (.ite cond tB fB) ws₀ ws₁ (U_c + U_b) (B_c + B_b) M_cell S_bit := by
  refine ⟨hf.1, hf.2.1, fun u₀ b₀ mc₀ pb₀ rest => ?_⟩
  rcases hf.2.2 (u₀ + u_c) (b₀ + b_c) mc₀ pb₀ rest with
    ⟨f₁, u₁, b₁, mc₁, pb₁, hu₁, hb₁, hmc₁, hpb₁, hstep⟩
  refine ⟨1 + f₁, u₁, b₁, mc₁, pb₁, by omega, by omega, hmc₁, hpb₁, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + fuel = (f₁ + fuel) + 1 := by omega
  rw [hfuel]
  simp only [runBitRAMFuel, mkBitState, hcond, Bool.false_eq_true, ↓reduceIte]
  exact hstep fuel

theorem ExecBit.whileLoop_false {d : ℕ} {inp : BitRAMInput d} {cond : BitCondExpr}
    {body : BitRAMStmt} {ws : WordStore} {u_c b_c U_c B_c M_cell S_bit : ℕ}
    (hc : CleanWords ws)
    (hcond : evalBitCond inp 0 ws cond = (false, u_c, b_c))
    (hu : u_c ≤ U_c) (hb : b_c ≤ B_c) :
    ExecBit inp (.whileLoop cond body) ws ws U_c B_c M_cell S_bit := by
  refine ⟨hc, hc, fun u₀ b₀ mc₀ pb₀ rest =>
    ⟨1, u₀ + u_c, b₀ + b_c, mc₀, pb₀, by omega, by omega, le_max_left _ _, le_max_left _ _,
      fun fuel => ?_⟩⟩
  rw [Nat.add_comm 1 fuel]
  simp [runBitRAMFuel, mkBitState, hcond]

theorem ExecBit.whileLoop_true {d : ℕ} {inp : BitRAMInput d} {cond : BitCondExpr}
    {body : BitRAMStmt} {ws₀ ws₁ ws₂ : WordStore}
    {u_c b_c U_c B_c U_b B_b U_r B_r M_cell S_bit : ℕ}
    (hcond : evalBitCond inp 0 ws₀ cond = (true, u_c, b_c))
    (hu : u_c ≤ U_c) (hb : b_c ≤ B_c)
    (hbody : ExecBit inp body ws₀ ws₁ U_b B_b M_cell S_bit)
    (hrest : ExecBit inp (.whileLoop cond body) ws₁ ws₂ U_r B_r M_cell S_bit) :
    ExecBit inp (.whileLoop cond body) ws₀ ws₂ (U_c + U_b + U_r) (B_c + B_b + B_r)
      M_cell S_bit := by
  refine ⟨hbody.1, hrest.2.1, fun u₀ b₀ mc₀ pb₀ rest => ?_⟩
  rcases hbody.2.2 (u₀ + u_c) (b₀ + b_c) mc₀ pb₀ (.stmt (.whileLoop cond body) :: rest) with
    ⟨f₁, u₁, b₁, mc₁, pb₁, hu₁, hb₁, hmc₁, hpb₁, hs₁⟩
  rcases hrest.2.2 u₁ b₁ mc₁ pb₁ rest with
    ⟨f₂, u₂, b₂, mc₂, pb₂, hu₂, hb₂, hmc₂, hpb₂, hs₂⟩
  refine ⟨1 + f₁ + f₂, u₂, b₂, mc₂, pb₂, by omega, by omega, by omega, by omega, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + f₂ + fuel = (f₁ + (f₂ + fuel)) + 1 := by omega
  rw [hfuel]
  simp only [runBitRAMFuel, mkBitState, hcond, ↓reduceIte]
  change runBitRAMFuel inp (f₁ + (f₂ + fuel)) (.stmt body :: .stmt (.whileLoop cond body) :: rest)
      (mkBitState inp ws₀ (u₀ + u_c) (b₀ + b_c) mc₀ pb₀) =
    runBitRAMFuel inp fuel rest (mkBitState inp ws₂ u₂ b₂ mc₂ pb₂)
  rw [hs₁ (f₂ + fuel), hs₂ fuel]

theorem ExecBit.whileLoop_nat {d : ℕ} {inp : BitRAMInput d} {cond : BitCondExpr}
    {body : BitRAMStmt} (N U_c B_c U_b B_b M_cell S_bit : ℕ)
    (Inv : ℕ → WordStore → Prop)
    {ws₀ : WordStore} (hc₀ : CleanWords ws₀) (hInv₀ : Inv 0 ws₀)
    (hstep : ∀ i < N, ∀ m : WordStore, CleanWords m → Inv i m →
      (∃ u_c b_c, evalBitCond inp 0 m cond = (true, u_c, b_c) ∧ u_c ≤ U_c ∧ b_c ≤ B_c) ∧
      (∃ m', ExecBit inp body m m' U_b B_b M_cell S_bit ∧ Inv (i + 1) m'))
    (hexit : ∀ m : WordStore, CleanWords m → Inv N m →
      ∃ u_c b_c, evalBitCond inp 0 m cond = (false, u_c, b_c) ∧ u_c ≤ U_c ∧ b_c ≤ B_c) :
    ∃ ws_N : WordStore,
      Inv N ws_N ∧
      ExecBit inp (.whileLoop cond body) ws₀ ws_N
        ((N + 1) * U_c + N * U_b) ((N + 1) * B_c + N * B_b) M_cell S_bit := by
  suffices hrem : ∀ k : ℕ, k ≤ N → ∀ m : WordStore, CleanWords m → Inv (N - k) m →
      ∃ m_N : WordStore,
        Inv N m_N ∧
        ExecBit inp (.whileLoop cond body) m m_N
          ((k + 1) * U_c + k * U_b) ((k + 1) * B_c + k * B_b) M_cell S_bit by
    simpa using hrem N le_rfl ws₀ hc₀ (by simpa using hInv₀)
  intro k
  induction k with
  | zero =>
      intro _ m hcm hIm
      rw [Nat.sub_zero] at hIm
      rcases hexit m hcm hIm with ⟨u_c, b_c, hcond, hu, hb⟩
      refine ⟨m, hIm, ?_⟩
      simpa using ExecBit.whileLoop_false (M_cell := M_cell) (S_bit := S_bit) hcm hcond hu hb
  | succ k ih =>
      intro hk m hcm hIm
      have hi_lt : N - (k + 1) < N := by omega
      have hsucc : N - (k + 1) + 1 = N - k := by omega
      rcases hstep (N - (k + 1)) hi_lt m hcm hIm with
        ⟨⟨u_c, b_c, hcond, hu, hb⟩, ⟨m', hbody, hIm'⟩⟩
      rw [hsucc] at hIm'
      rcases ih (by omega) m' hbody.2.1 hIm' with ⟨m_N, hIm_N, hrest⟩
      refine ⟨m_N, hIm_N, ?_⟩
      refine (ExecBit.whileLoop_true hcond hu hb hbody hrest).mono ?_ ?_ <;> linarith

theorem ExecBit.repeatN_nat {d : ℕ} {inp : BitRAMInput d} {countE : IntExpr}
    {body : BitRAMStmt} (N U_cnt B_cnt U_b B_b M_cell S_bit : ℕ)
    (Inv : ℕ → WordStore → Prop)
    {ws₀ : WordStore} (hc₀ : CleanWords ws₀) (hInv₀ : Inv 0 ws₀)
    {u_cnt b_cnt : ℕ}
    (hcnt : evalIntExpr inp 0 ws₀ countE = ((N : ℤ), u_cnt, b_cnt))
    (hucnt : u_cnt ≤ U_cnt) (hbcnt : b_cnt ≤ B_cnt)
    (hstep : ∀ i < N, ∀ m : WordStore, CleanWords m → Inv i m →
      ∃ m', ExecBit inp body m m' U_b B_b M_cell S_bit ∧ Inv (i + 1) m') :
    ∃ ws_N : WordStore,
      Inv N ws_N ∧
      ExecBit inp (.repeatN countE body) ws₀ ws_N
        (U_cnt + N * U_b) (B_cnt + N * B_b) M_cell S_bit := by
  have hloop : ∀ k : ℕ, k ≤ N → ∀ m : WordStore, CleanWords m → Inv (N - k) m →
      ∃ m_N : WordStore, CleanWords m_N ∧ Inv N m_N ∧
        ∀ (u₀ b₀ mc₀ pb₀ : ℕ) (rest : List BitRAMCont),
          ∃ (fuel₀ u₁ b₁ mc₁ pb₁ : ℕ),
            u₁ ≤ u₀ + k * U_b ∧
            b₁ ≤ b₀ + k * B_b ∧
            mc₁ ≤ max mc₀ M_cell ∧
            pb₁ ≤ max pb₀ S_bit ∧
            ∀ fuel : ℕ,
              runBitRAMFuel inp (fuel₀ + fuel) (.repeatLoop k body :: rest)
                  (mkBitState inp m u₀ b₀ mc₀ pb₀) =
                runBitRAMFuel inp fuel rest (mkBitState inp m_N u₁ b₁ mc₁ pb₁) := by
    intro k
    induction k with
    | zero =>
        intro _ m hcm hIm
        rw [Nat.sub_zero] at hIm
        refine ⟨m, hcm, hIm, fun u₀ b₀ mc₀ pb₀ rest =>
          ⟨1, u₀, b₀, mc₀, pb₀, by simp, by simp, le_max_left _ _, le_max_left _ _, fun fuel => ?_⟩⟩
        rw [Nat.add_comm 1 fuel]
        rfl
    | succ k ih =>
        intro hk m hcm hIm
        have hi_lt : N - (k + 1) < N := by omega
        have hsucc : N - (k + 1) + 1 = N - k := by omega
        rcases hstep (N - (k + 1)) hi_lt m hcm hIm with ⟨m', hbody, hIm'⟩
        rw [hsucc] at hIm'
        rcases ih (by omega) m' hbody.2.1 hIm' with ⟨m_N, hcm_N, hIm_N, hrest⟩
        refine ⟨m_N, hcm_N, hIm_N, fun u₀ b₀ mc₀ pb₀ rest => ?_⟩
        rcases hbody.2.2 u₀ b₀ mc₀ pb₀ (.repeatLoop k body :: rest) with
          ⟨f₁, u₁, b₁, mc₁, pb₁, hu₁, hb₁, hmc₁, hpb₁, hs₁⟩
        rcases hrest u₁ b₁ mc₁ pb₁ rest with
          ⟨f₂, u₂, b₂, mc₂, pb₂, hu₂, hb₂, hmc₂, hpb₂, hs₂⟩
        refine ⟨1 + f₁ + f₂, u₂, b₂, mc₂, pb₂, ?_, ?_, by omega, by omega, fun fuel => ?_⟩
        · calc u₂ ≤ u₀ + U_b + k * U_b := by omega
            _ = u₀ + (k + 1) * U_b := by ring
        · calc b₂ ≤ b₀ + B_b + k * B_b := by omega
            _ = b₀ + (k + 1) * B_b := by ring
        · have hfuel : 1 + f₁ + f₂ + fuel = (f₁ + (f₂ + fuel)) + 1 := by omega
          rw [hfuel]
          dsimp only [runBitRAMFuel]
          rw [hs₁ (f₂ + fuel), hs₂ fuel]
  rcases hloop N le_rfl ws₀ hc₀ (by simpa using hInv₀) with ⟨ws_N, hcm_N, hIm_N, hrun⟩
  refine ⟨ws_N, hIm_N, hc₀, hcm_N, fun u₀ b₀ mc₀ pb₀ rest => ?_⟩
  rcases hrun (u₀ + u_cnt) (b₀ + b_cnt) mc₀ pb₀ rest with
    ⟨f₁, u₁, b₁, mc₁, pb₁, hu₁, hb₁, hmc₁, hpb₁, hs₁⟩
  refine ⟨1 + f₁, u₁, b₁, mc₁, pb₁, by omega, by omega, hmc₁, hpb₁, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + fuel = (f₁ + fuel) + 1 := by omega
  rw [hfuel]
  have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
  simp only [runBitRAMFuel, mkBitState, hcnt, hnIter]
  exact hs₁ fuel

def seqBitStmts : List BitRAMStmt → BitRAMStmt
  | [] => .skip
  | [s] => s
  | s :: ss => .seq s (seqBitStmts ss)

/-! ### 4. Bounded 20-cell heap invariant & atomic instruction lemmas -/

def heapLocs20 : Finset RAMCellLoc :=
  (Finset.range 20).image (fun j : ℕ => RAMCellLoc.heap 0 (j : ℤ))

def HeapBounded (L_max : ℕ) (ws : WordStore) : Prop :=
  CleanWords ws ∧
  ws.live ⊆ heapLocs20 ∧
  ∀ (j : ℕ), j < 20 → intBitLength (ws.read (.heap 0 (j : ℤ))) ≤ L_max

@[simp]
theorem ws_read_empty (loc : RAMCellLoc) : WordStore.empty.read loc = 0 := by
  simp [WordStore.empty, WordStore.read]

@[simp]
theorem ws_read_write_self (ws : WordStore) (loc : RAMCellLoc) (v : ℤ) :
    (ws.write loc v).read loc = v := by
  simp [WordStore.read, WordStore.write]

theorem ws_read_write_of_ne (ws : WordStore) {i₁ i₂ : ℤ} (v : ℤ) (hne : i₁ ≠ i₂) :
    (ws.write (.heap 0 i₂) v).read (.heap 0 i₁) = ws.read (.heap 0 i₁) := by
  have hloc : RAMCellLoc.heap 0 i₁ ≠ RAMCellLoc.heap 0 i₂ := by
    intro h
    cases h
    exact hne rfl
  simp [WordStore.read, WordStore.write, hloc]

theorem intBitLength_small_nat {j : ℕ} (hj : j < 32) :
    intBitLength (j : ℤ) ≤ 7 := by
  have hlt : (j : ℤ).natAbs < 2 ^ 5 := by
    rw [Int.natAbs_natCast]
    omega
  exact (intBitLength_le_of_abs_lt_two_pow hlt).trans (by norm_num)

theorem heap0_loc_bitLength_le {j : ℕ} (hj : j < 20) :
    (RAMCellLoc.heap 0 (j : ℤ)).bitLength ≤ 8 := by
  have hj32 : j < 32 := by omega
  have hib := intBitLength_small_nat hj32
  have hnb : natBitLength 0 = 1 := by simp [natBitLength]
  dsimp [RAMCellLoc.bitLength]
  omega

theorem heapBounded_empty {L_max : ℕ} (hL : 1 ≤ L_max) :
    HeapBounded L_max WordStore.empty := by
  refine ⟨cleanWords_empty, Finset.empty_subset _, fun j _ => ?_⟩
  simp only [ws_read_empty, intBitLength, ↓reduceIte]
  omega

theorem heapBounded_write {L_max : ℕ} {ws : WordStore} (h : HeapBounded L_max ws)
    {j : ℕ} (hj : j < 20) {v : ℤ} (hv : intBitLength v ≤ L_max) :
    HeapBounded L_max (ws.write (.heap 0 (j : ℤ)) v) := by
  refine ⟨cleanWords_write_heap h.1 0 (j : ℤ) v, ?_, fun k hk => ?_⟩
  · refine Finset.insert_subset ?_ h.2.1
    exact Finset.mem_image.mpr ⟨j, Finset.mem_range.mpr hj, rfl⟩
  · by_cases hkj : k = j
    · subst hkj
      simpa using hv
    · rw [ws_read_write_of_ne ws v (by omega)]
      exact h.2.2 k hk

theorem heapBounded_cellCount {L_max : ℕ} {ws : WordStore} (h : HeapBounded L_max ws) :
    ws.cellCount ≤ 20 := by
  unfold WordStore.cellCount
  calc
    ws.live.card ≤ heapLocs20.card := Finset.card_le_card h.2.1
    _ ≤ (Finset.range 20).card := Finset.card_image_le
    _ = 20 := Finset.card_range 20

theorem heapBounded_bitSize {L_max : ℕ} {ws : WordStore} (h : HeapBounded L_max ws) :
    ws.bitSize ≤ 20 * (8 + L_max) := by
  unfold WordStore.bitSize
  have hterm : ∀ loc ∈ ws.live, loc.bitLength + intBitLength (ws.vals loc) ≤ 8 + L_max := by
    intro loc hmem
    have hmem20 := h.2.1 hmem
    rcases Finset.mem_image.mp hmem20 with ⟨j, hj_mem, rfl⟩
    have hj : j < 20 := Finset.mem_range.mp hj_mem
    have hread : ws.read (.heap 0 (j : ℤ)) = ws.vals (.heap 0 (j : ℤ)) := by
      simp [WordStore.read, hmem]
    have hbl := heap0_loc_bitLength_le hj
    have hvl := h.2.2 j hj
    rw [hread] at hvl
    omega
  have hsum : ∑ loc ∈ ws.live, (loc.bitLength + intBitLength (ws.vals loc)) ≤
      ws.live.card * (8 + L_max) := by
    simpa [nsmul_eq_mul] using Finset.sum_le_card_nsmul ws.live _ (8 + L_max) hterm
  have hcard : ws.live.card ≤ 20 := heapBounded_cellCount h
  exact hsum.trans (Nat.mul_le_mul_right (8 + L_max) hcard)

/-- Leaf operand bound (`c` literal or `.readHeap 0 (.lit i)`). -/
def BoundedLeaf {d : ℕ} (inp : BitRAMInput d) (L_max : ℕ) (ws : WordStore)
    (e : IntExpr) (v : ℤ) : Prop :=
  intBitLength v ≤ L_max ∧
  ∃ u b, evalIntExpr inp 0 ws e = (v, u, b) ∧ u ≤ 2 ∧ b ≤ 3 * L_max

theorem leaf_lit {d : ℕ} (inp : BitRAMInput d) {L_max : ℕ} (ws : WordStore)
    {c : ℤ} (hc : intBitLength c ≤ L_max) :
    BoundedLeaf inp L_max ws (.lit c) c := by
  refine ⟨hc, 1, intBitLength c, rfl, by omega, by omega⟩

theorem leaf_cell {d : ℕ} (inp : BitRAMInput d) {L_max : ℕ} (hL : 8 ≤ L_max)
    {ws : WordStore} (hws : HeapBounded L_max ws) {i : ℕ} (hi : i < 20) :
    BoundedLeaf inp L_max ws (.readHeap 0 (.lit (i : ℤ))) (ws.read (.heap 0 (i : ℤ))) := by
  have hv := hws.2.2 i hi
  have hib : intBitLength (i : ℤ) ≤ 7 := intBitLength_small_nat (by omega)
  have hnb : natBitLength 0 = 1 := by simp [natBitLength]
  refine ⟨hv, 2, intBitLength (i : ℤ) + natBitLength 0 + intBitLength (i : ℤ) +
    intBitLength (ws.read (.heap 0 (i : ℤ))), rfl, le_rfl, by omega⟩

theorem execWriteLeaf {d : ℕ} {inp : BitRAMInput d} {L_max S_bit : ℕ} (hL : 8 ≤ L_max)
    (hSbit : inp.inputBitSpace + 20 * (8 + L_max) ≤ S_bit)
    {ws : WordStore} (hws : HeapBounded L_max ws)
    {j : ℕ} (hj : j < 20) {e : IntExpr} {v : ℤ}
    (he : BoundedLeaf inp L_max ws e v) :
    HeapBounded L_max (ws.write (.heap 0 (j : ℤ)) v) ∧
    ExecBit inp (.writeHeap 0 (.lit (j : ℤ)) e) ws (ws.write (.heap 0 (j : ℤ)) v)
      10 (4 * L_max ^ 2) 20 S_bit := by
  have hws' := heapBounded_write hws hj he.1
  rcases he.2 with ⟨u₂, b₂, heval, hu₂, hb₂⟩
  have hib_j : intBitLength (j : ℤ) ≤ 7 := intBitLength_small_nat (by omega)
  have hloc_j : (RAMCellLoc.heap 0 (j : ℤ)).bitLength ≤ 8 := heap0_loc_bitLength_le hj
  have hv_le : intBitLength v ≤ L_max := he.1
  refine ⟨hws', ExecBit.writeHeap inp hws.1 0 (.lit (j : ℤ)) e rfl heval (by omega) ?_
    (heapBounded_cellCount hws') ((Nat.add_le_add_left (heapBounded_bitSize hws') _).trans hSbit)⟩
  nlinarith

theorem execWriteAdd {d : ℕ} {inp : BitRAMInput d} {L_max S_bit : ℕ} (hL : 8 ≤ L_max)
    (hSbit : inp.inputBitSpace + 20 * (8 + L_max) ≤ S_bit)
    {ws : WordStore} (hws : HeapBounded L_max ws)
    {j : ℕ} (hj : j < 20) {e₁ e₂ : IntExpr} {v₁ v₂ : ℤ}
    (he₁ : BoundedLeaf inp L_max ws e₁ v₁)
    (he₂ : BoundedLeaf inp L_max ws e₂ v₂)
    (hv : intBitLength (v₁ + v₂) ≤ L_max) :
    HeapBounded L_max (ws.write (.heap 0 (j : ℤ)) (v₁ + v₂)) ∧
    ExecBit inp (.writeHeap 0 (.lit (j : ℤ)) (.add e₁ e₂))
      ws (ws.write (.heap 0 (j : ℤ)) (v₁ + v₂))
      10 (4 * L_max ^ 2) 20 S_bit := by
  have hws' := heapBounded_write hws hj hv
  rcases he₁ with ⟨hv₁, u₁, b₁, hev₁, hu₁, hb₁⟩
  rcases he₂ with ⟨hv₂, u₂, b₂, hev₂, hu₂, hb₂⟩
  have hadd : evalIntExpr inp 0 ws (.add e₁ e₂) =
      (v₁ + v₂, u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ + intBitLength v₂) := by
    simp [evalIntExpr, hev₁, hev₂]
  have hib_j : intBitLength (j : ℤ) ≤ 7 := intBitLength_small_nat (by omega)
  have hloc_j : (RAMCellLoc.heap 0 (j : ℤ)).bitLength ≤ 8 := heap0_loc_bitLength_le hj
  refine ⟨hws', ExecBit.writeHeap inp hws.1 0 (.lit (j : ℤ)) (.add e₁ e₂) rfl hadd (by omega) ?_
    (heapBounded_cellCount hws') ((Nat.add_le_add_left (heapBounded_bitSize hws') _).trans hSbit)⟩
  nlinarith

theorem execWriteSub {d : ℕ} {inp : BitRAMInput d} {L_max S_bit : ℕ} (hL : 8 ≤ L_max)
    (hSbit : inp.inputBitSpace + 20 * (8 + L_max) ≤ S_bit)
    {ws : WordStore} (hws : HeapBounded L_max ws)
    {j : ℕ} (hj : j < 20) {e₁ e₂ : IntExpr} {v₁ v₂ : ℤ}
    (he₁ : BoundedLeaf inp L_max ws e₁ v₁)
    (he₂ : BoundedLeaf inp L_max ws e₂ v₂)
    (hv : intBitLength (v₁ - v₂) ≤ L_max) :
    HeapBounded L_max (ws.write (.heap 0 (j : ℤ)) (v₁ - v₂)) ∧
    ExecBit inp (.writeHeap 0 (.lit (j : ℤ)) (.sub e₁ e₂))
      ws (ws.write (.heap 0 (j : ℤ)) (v₁ - v₂))
      10 (4 * L_max ^ 2) 20 S_bit := by
  have hws' := heapBounded_write hws hj hv
  rcases he₁ with ⟨hv₁, u₁, b₁, hev₁, hu₁, hb₁⟩
  rcases he₂ with ⟨hv₂, u₂, b₂, hev₂, hu₂, hb₂⟩
  have hsub : evalIntExpr inp 0 ws (.sub e₁ e₂) =
      (v₁ - v₂, u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ + intBitLength v₂) := by
    simp [evalIntExpr, hev₁, hev₂]
  have hib_j : intBitLength (j : ℤ) ≤ 7 := intBitLength_small_nat (by omega)
  have hloc_j : (RAMCellLoc.heap 0 (j : ℤ)).bitLength ≤ 8 := heap0_loc_bitLength_le hj
  refine ⟨hws', ExecBit.writeHeap inp hws.1 0 (.lit (j : ℤ)) (.sub e₁ e₂) rfl hsub (by omega) ?_
    (heapBounded_cellCount hws') ((Nat.add_le_add_left (heapBounded_bitSize hws') _).trans hSbit)⟩
  nlinarith

theorem execWriteMul {d : ℕ} {inp : BitRAMInput d} {L_max S_bit : ℕ} (hL : 8 ≤ L_max)
    (hSbit : inp.inputBitSpace + 20 * (8 + L_max) ≤ S_bit)
    {ws : WordStore} (hws : HeapBounded L_max ws)
    {j : ℕ} (hj : j < 20) {e₁ e₂ : IntExpr} {v₁ v₂ : ℤ}
    (he₁ : BoundedLeaf inp L_max ws e₁ v₁)
    (he₂ : BoundedLeaf inp L_max ws e₂ v₂)
    (hv : intBitLength (v₁ * v₂) ≤ L_max) :
    HeapBounded L_max (ws.write (.heap 0 (j : ℤ)) (v₁ * v₂)) ∧
    ExecBit inp (.writeHeap 0 (.lit (j : ℤ)) (.mul e₁ e₂))
      ws (ws.write (.heap 0 (j : ℤ)) (v₁ * v₂))
      10 (4 * L_max ^ 2) 20 S_bit := by
  have hws' := heapBounded_write hws hj hv
  rcases he₁ with ⟨hv₁, u₁, b₁, hev₁, hu₁, hb₁⟩
  rcases he₂ with ⟨hv₂, u₂, b₂, hev₂, hu₂, hb₂⟩
  have hmul : evalIntExpr inp 0 ws (.mul e₁ e₂) =
      (v₁ * v₂, u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ * intBitLength v₂) := by
    simp [evalIntExpr, hev₁, hev₂]
  have hib_j : intBitLength (j : ℤ) ≤ 7 := intBitLength_small_nat (by omega)
  have hloc_j : (RAMCellLoc.heap 0 (j : ℤ)).bitLength ≤ 8 := heap0_loc_bitLength_le hj
  refine ⟨hws', ExecBit.writeHeap inp hws.1 0 (.lit (j : ℤ)) (.mul e₁ e₂) rfl hmul (by omega) ?_
    (heapBounded_cellCount hws') ((Nat.add_le_add_left (heapBounded_bitSize hws') _).trans hSbit)⟩
  nlinarith

theorem execWriteDiv {d : ℕ} {inp : BitRAMInput d} {L_max S_bit : ℕ} (hL : 8 ≤ L_max)
    (hSbit : inp.inputBitSpace + 20 * (8 + L_max) ≤ S_bit)
    {ws : WordStore} (hws : HeapBounded L_max ws)
    {j : ℕ} (hj : j < 20) {e₁ e₂ : IntExpr} {v₁ v₂ : ℤ}
    (he₁ : BoundedLeaf inp L_max ws e₁ v₁)
    (he₂ : BoundedLeaf inp L_max ws e₂ v₂)
    (hv : intBitLength (v₁ / v₂) ≤ L_max) :
    HeapBounded L_max (ws.write (.heap 0 (j : ℤ)) (v₁ / v₂)) ∧
    ExecBit inp (.writeHeap 0 (.lit (j : ℤ)) (.div e₁ e₂))
      ws (ws.write (.heap 0 (j : ℤ)) (v₁ / v₂))
      10 (4 * L_max ^ 2) 20 S_bit := by
  have hws' := heapBounded_write hws hj hv
  rcases he₁ with ⟨hv₁, u₁, b₁, hev₁, hu₁, hb₁⟩
  rcases he₂ with ⟨hv₂, u₂, b₂, hev₂, hu₂, hb₂⟩
  have hdiv : evalIntExpr inp 0 ws (.div e₁ e₂) =
      (v₁ / v₂, u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ * intBitLength v₂) := by
    simp [evalIntExpr, hev₁, hev₂]
  have hib_j : intBitLength (j : ℤ) ≤ 7 := intBitLength_small_nat (by omega)
  have hloc_j : (RAMCellLoc.heap 0 (j : ℤ)).bitLength ≤ 8 := heap0_loc_bitLength_le hj
  refine ⟨hws', ExecBit.writeHeap inp hws.1 0 (.lit (j : ℤ)) (.div e₁ e₂) rfl hdiv (by omega) ?_
    (heapBounded_cellCount hws') ((Nat.add_le_add_left (heapBounded_bitSize hws') _).trans hSbit)⟩
  nlinarith

theorem evalCondLt {d : ℕ} {inp : BitRAMInput d} {L_max : ℕ} (hL : 8 ≤ L_max)
    {ws : WordStore} {e₁ e₂ : IntExpr} {v₁ v₂ : ℤ}
    (he₁ : BoundedLeaf inp L_max ws e₁ v₁)
    (he₂ : BoundedLeaf inp L_max ws e₂ v₂) :
    ∃ u b, evalBitCond inp 0 ws (.intLt e₁ e₂) = (decide (v₁ < v₂), u, b) ∧
      u ≤ 10 ∧ b ≤ 4 * L_max ^ 2 := by
  rcases he₁ with ⟨hv₁, u₁, b₁, hev₁, hu₁, hb₁⟩
  rcases he₂ with ⟨hv₂, u₂, b₂, hev₂, hu₂, hb₂⟩
  refine ⟨u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ + intBitLength v₂, ?_, by omega, by nlinarith⟩
  simp [evalBitCond, hev₁, hev₂]

end UL.Proof_lem_5_6
