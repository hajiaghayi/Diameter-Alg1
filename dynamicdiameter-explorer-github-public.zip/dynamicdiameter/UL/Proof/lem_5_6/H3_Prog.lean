import Mathlib
import UL.Def.def_computation_model
import UL.Proof.lem_5_6.H1_Math
import UL.Proof.lem_5_6.H2_RAMBase
set_option autoImplicit false

namespace UL.Proof_lem_5_6

open UL.Proof_lem_6_3

/-! ### 1. Program syntax and atomic heap-step wrappers -/

abbrev hLoc (j : ℕ) : RAMCellLoc := .heap 0 (j : ℤ)
abbrev cE (i : ℕ) : IntExpr := .readHeap 0 (.lit (i : ℤ))
abbrev wLeaf (j : ℕ) (e : IntExpr) : BitRAMStmt := .writeHeap 0 (.lit (j : ℤ)) e
abbrev wAdd (j : ℕ) (e₁ e₂ : IntExpr) : BitRAMStmt := .writeHeap 0 (.lit (j : ℤ)) (.add e₁ e₂)
abbrev wSub (j : ℕ) (e₁ e₂ : IntExpr) : BitRAMStmt := .writeHeap 0 (.lit (j : ℤ)) (.sub e₁ e₂)
abbrev wMul (j : ℕ) (e₁ e₂ : IntExpr) : BitRAMStmt := .writeHeap 0 (.lit (j : ℤ)) (.mul e₁ e₂)
abbrev wDiv (j : ℕ) (e₁ e₂ : IntExpr) : BitRAMStmt := .writeHeap 0 (.lit (j : ℤ)) (.div e₁ e₂)

def phase1Prog : BitRAMStmt :=
  .seq (wLeaf 7 (.lit 1))
    (.seq (wLeaf 8 (.lit 2))
      (.seq (wMul 9 (.lit 16) (cE 4))
        (.whileLoop (.intLt (cE 8) (cE 9))
          (.seq (wAdd 7 (cE 7) (.lit 1))
            (wMul 8 (.lit 2) (cE 8))))))

def phase2Prog : BitRAMStmt :=
  .seq (wMul 10 (.lit 2) (cE 8))
    (.seq (wMul 11 (cE 10) (cE 10))
      (.seq (wMul 12 (cE 6) (cE 4))
        (.seq (wMul 13 (cE 5) (cE 4))
          (.seq (wMul 14 (.lit 2) (cE 6))
            (.seq (wAdd 13 (cE 13) (cE 14))
              (.seq (wLeaf 14 (.lit 0))
                (wLeaf 15 (cE 8))))))))

def bsBody : BitRAMStmt :=
  .seq (wAdd 16 (cE 14) (cE 15))
    (.seq (wDiv 16 (cE 16) (.lit 2))
      (.seq (wMul 17 (cE 16) (cE 16))
        (.seq (wMul 18 (.lit 4) (cE 17))
          (.seq (wMul 18 (cE 18) (cE 11))
            (.seq (wMul 18 (cE 18) (cE 12))
              (.seq (wSub 19 (cE 11) (cE 17))
                (.seq (wMul 19 (cE 19) (cE 19))
                  (.seq (wMul 19 (cE 13) (cE 19))
                    (.ite (.intLt (cE 18) (cE 19))
                      (wLeaf 14 (cE 16))
                      (wLeaf 15 (cE 16)))))))))))

def phase3Prog : BitRAMStmt :=
  .repeatN (cE 7) bsBody

def phase4Prog : BitRAMStmt :=
  .seq (wMul 17 (cE 15) (cE 15))
    (.seq (wSub 0 (cE 11) (cE 17))
      (.seq (wAdd 1 (cE 11) (cE 17))
        (.seq (wMul 18 (.lit 2) (cE 10))
          (.seq (wMul 2 (cE 18) (cE 15))
            (wLeaf 3 (cE 1))))))

def coreProg : BitRAMStmt :=
  .seq phase1Prog (.seq phase2Prog (.seq phase3Prog phase4Prog))

theorem coreProg_pure : PureHeapStmt coreProg = true := rfl

def preBitProg : BitRAMStmt :=
  .seq (.writeHeap 0 (.lit 4) (.intParam (.lit 0)))
    (.seq (.writeHeap 0 (.lit 5) (.extraRatNum (.lit 0)))
      (.writeHeap 0 (.lit 6) (.extraRatDen (.lit 0))))

def l56ProgBit : BitRAMStmt :=
  .seq preBitProg coreProg

def preArithProg : ArithRAMStmt :=
  .seq (.writeWordHeap 0 (.lit 4)
      (.div (.sub (.add (.intParam (.lit 3)) (.intParam (.lit 2))) (.lit 1)) (.intParam (.lit 2))))
    (.seq (.writeWordHeap 0 (.lit 5) (.intParam (.lit 0)))
      (.writeWordHeap 0 (.lit 6) (.intParam (.lit 1))))

def l56ProgArith : ArithRAMStmt :=
  .seq preArithProg (bitStmtToArith coreProg)

private theorem ib_of_le_top {n TOP M_bits : ℕ} (hle : n ≤ TOP) (hTOP : TOP < 2 ^ M_bits) :
    intBitLength (n : ℤ) ≤ M_bits + 2 :=
  intBitLength_le_of_abs_lt_two_pow (by simpa using lt_of_le_of_lt hle hTOP)

private theorem leaf_small (inp : BitRAMInput 0) {M_bits : ℕ} (ws : WordStore)
    (c : ℤ) (hc0 : 0 ≤ c) (hc : c < 32) (hM : 8 ≤ M_bits) :
    BoundedLeaf inp (M_bits + 2) ws (.lit c) c := by
  apply leaf_lit inp ws
  have heq : (c.toNat : ℤ) = c := Int.toNat_of_nonneg hc0
  rw [← heq]
  exact (intBitLength_small_nat (by omega)).trans (by omega)

private theorem stepLeaf {inp : BitRAMInput 0} {L_max S_bit : ℕ} (hL : 8 ≤ L_max)
    (hSbit : inp.inputBitSpace + 20 * (8 + L_max) ≤ S_bit)
    {ws : WordStore} (hws : HeapBounded L_max ws)
    (j : ℕ) (hj : j < 20) {e : IntExpr} {v₀ : ℤ}
    (he : BoundedLeaf inp L_max ws e v₀)
    (v : ℤ) (hv_eq : v₀ = v) :
    ∃ ws' : WordStore,
      (∀ i : ℕ, ws'.read (hLoc i) = if i = j then v else ws.read (hLoc i)) ∧
      HeapBounded L_max ws' ∧
      ExecBit inp (wLeaf j e) ws ws' 10 (4 * L_max ^ 2) 20 S_bit := by
  obtain ⟨hb', hx'⟩ := execWriteLeaf hL hSbit hws hj he
  rw [hv_eq] at hb' hx'
  refine ⟨ws.write (hLoc j) v, ?_, hb', hx'⟩
  intro i
  split_ifs with hij
  · subst hij; exact ws_read_write_self ws (hLoc i) v
  · exact ws_read_write_of_ne ws v (by omega)

private theorem stepAdd {inp : BitRAMInput 0} {L_max S_bit : ℕ} (hL : 8 ≤ L_max)
    (hSbit : inp.inputBitSpace + 20 * (8 + L_max) ≤ S_bit)
    {ws : WordStore} (hws : HeapBounded L_max ws)
    (j : ℕ) (hj : j < 20) {e₁ e₂ : IntExpr} {v₁ v₂ : ℤ}
    (he₁ : BoundedLeaf inp L_max ws e₁ v₁)
    (he₂ : BoundedLeaf inp L_max ws e₂ v₂)
    (v : ℤ) (hv_eq : v₁ + v₂ = v) (hv : intBitLength v ≤ L_max) :
    ∃ ws' : WordStore,
      (∀ i : ℕ, ws'.read (hLoc i) = if i = j then v else ws.read (hLoc i)) ∧
      HeapBounded L_max ws' ∧
      ExecBit inp (wAdd j e₁ e₂) ws ws' 10 (4 * L_max ^ 2) 20 S_bit := by
  have hv' : intBitLength (v₁ + v₂) ≤ L_max := hv_eq.symm ▸ hv
  obtain ⟨hb', hx'⟩ := execWriteAdd hL hSbit hws hj he₁ he₂ hv'
  rw [hv_eq] at hb' hx'
  refine ⟨ws.write (hLoc j) v, ?_, hb', hx'⟩
  intro i
  split_ifs with hij
  · subst hij; exact ws_read_write_self ws (hLoc i) v
  · exact ws_read_write_of_ne ws v (by omega)

private theorem stepSub {inp : BitRAMInput 0} {L_max S_bit : ℕ} (hL : 8 ≤ L_max)
    (hSbit : inp.inputBitSpace + 20 * (8 + L_max) ≤ S_bit)
    {ws : WordStore} (hws : HeapBounded L_max ws)
    (j : ℕ) (hj : j < 20) {e₁ e₂ : IntExpr} {v₁ v₂ : ℤ}
    (he₁ : BoundedLeaf inp L_max ws e₁ v₁)
    (he₂ : BoundedLeaf inp L_max ws e₂ v₂)
    (v : ℤ) (hv_eq : v₁ - v₂ = v) (hv : intBitLength v ≤ L_max) :
    ∃ ws' : WordStore,
      (∀ i : ℕ, ws'.read (hLoc i) = if i = j then v else ws.read (hLoc i)) ∧
      HeapBounded L_max ws' ∧
      ExecBit inp (wSub j e₁ e₂) ws ws' 10 (4 * L_max ^ 2) 20 S_bit := by
  have hv' : intBitLength (v₁ - v₂) ≤ L_max := hv_eq.symm ▸ hv
  obtain ⟨hb', hx'⟩ := execWriteSub hL hSbit hws hj he₁ he₂ hv'
  rw [hv_eq] at hb' hx'
  refine ⟨ws.write (hLoc j) v, ?_, hb', hx'⟩
  intro i
  split_ifs with hij
  · subst hij; exact ws_read_write_self ws (hLoc i) v
  · exact ws_read_write_of_ne ws v (by omega)

private theorem stepMul {inp : BitRAMInput 0} {L_max S_bit : ℕ} (hL : 8 ≤ L_max)
    (hSbit : inp.inputBitSpace + 20 * (8 + L_max) ≤ S_bit)
    {ws : WordStore} (hws : HeapBounded L_max ws)
    (j : ℕ) (hj : j < 20) {e₁ e₂ : IntExpr} {v₁ v₂ : ℤ}
    (he₁ : BoundedLeaf inp L_max ws e₁ v₁)
    (he₂ : BoundedLeaf inp L_max ws e₂ v₂)
    (v : ℤ) (hv_eq : v₁ * v₂ = v) (hv : intBitLength v ≤ L_max) :
    ∃ ws' : WordStore,
      (∀ i : ℕ, ws'.read (hLoc i) = if i = j then v else ws.read (hLoc i)) ∧
      HeapBounded L_max ws' ∧
      ExecBit inp (wMul j e₁ e₂) ws ws' 10 (4 * L_max ^ 2) 20 S_bit := by
  have hv' : intBitLength (v₁ * v₂) ≤ L_max := hv_eq.symm ▸ hv
  obtain ⟨hb', hx'⟩ := execWriteMul hL hSbit hws hj he₁ he₂ hv'
  rw [hv_eq] at hb' hx'
  refine ⟨ws.write (hLoc j) v, ?_, hb', hx'⟩
  intro i
  split_ifs with hij
  · subst hij; exact ws_read_write_self ws (hLoc i) v
  · exact ws_read_write_of_ne ws v (by omega)

private theorem stepDiv {inp : BitRAMInput 0} {L_max S_bit : ℕ} (hL : 8 ≤ L_max)
    (hSbit : inp.inputBitSpace + 20 * (8 + L_max) ≤ S_bit)
    {ws : WordStore} (hws : HeapBounded L_max ws)
    (j : ℕ) (hj : j < 20) {e₁ e₂ : IntExpr} {v₁ v₂ : ℤ}
    (he₁ : BoundedLeaf inp L_max ws e₁ v₁)
    (he₂ : BoundedLeaf inp L_max ws e₂ v₂)
    (v : ℤ) (hv_eq : v₁ / v₂ = v) (hv : intBitLength v ≤ L_max) :
    ∃ ws' : WordStore,
      (∀ i : ℕ, ws'.read (hLoc i) = if i = j then v else ws.read (hLoc i)) ∧
      HeapBounded L_max ws' ∧
      ExecBit inp (wDiv j e₁ e₂) ws ws' 10 (4 * L_max ^ 2) 20 S_bit := by
  have hv' : intBitLength (v₁ / v₂) ≤ L_max := hv_eq.symm ▸ hv
  obtain ⟨hb', hx'⟩ := execWriteDiv hL hSbit hws hj he₁ he₂ hv'
  rw [hv_eq] at hb' hx'
  refine ⟨ws.write (hLoc j) v, ?_, hb', hx'⟩
  intro i
  split_ifs with hij
  · subst hij; exact ws_read_write_self ws (hLoc i) v
  · exact ws_read_write_of_ne ws v (by omega)

/-! ### 2. Uniform intermediate value bounds against `TOP` and polynomial bound -/

private theorem l56_top_bounds_aux {M_e b_num b_den K P N TOP : ℕ}
    (hMe16 : 16 ≤ M_e) (hden : 1 ≤ b_den) (hb_le : b_num ≤ b_den)
    (hP_ge : 16 * M_e ≤ P) (hKP : K ≤ P) (hpow_le : ∀ j ≤ K, 2 ^ j ≤ P)
    (hN : N = 2 * P) (hTOP_eq : TOP = 4 * (b_den * M_e) * N ^ 4) :
    16 * M_e ≤ TOP ∧
    K ≤ TOP ∧
    (∀ j ≤ K, j ≤ TOP ∧ 2 ^ j ≤ TOP) ∧
    N ≤ TOP ∧
    N ^ 2 ≤ TOP ∧
    2 * N ≤ TOP ∧
    b_den * M_e ≤ TOP ∧
    b_num * M_e ≤ TOP ∧
    2 * b_den ≤ TOP ∧
    b_num * M_e + 2 * b_den ≤ TOP ∧
    (∀ m ≤ P,
      m ^ 2 < N ^ 2 ∧
      m ^ 2 ≤ TOP ∧
      4 * m ^ 2 ≤ TOP ∧
      4 * m ^ 2 * N ^ 2 ≤ TOP ∧
      4 * m ^ 2 * N ^ 2 * (b_den * M_e) ≤ TOP ∧
      N ^ 2 - m ^ 2 ≤ TOP ∧
      (N ^ 2 - m ^ 2) ^ 2 ≤ TOP ∧
      (b_num * M_e + 2 * b_den) * (N ^ 2 - m ^ 2) ^ 2 ≤ TOP ∧
      N ^ 2 + m ^ 2 ≤ TOP ∧
      2 * N * m ≤ TOP) := by
  have hP256 : 256 ≤ P := by omega
  have hN512 : 512 ≤ N := by omega
  have hN_pos : 1 ≤ N := by omega
  have hN2_pos : 1 ≤ N ^ 2 := Nat.one_le_pow 2 N hN_pos
  have hN4_pos : 1 ≤ N ^ 4 := Nat.one_le_pow 4 N hN_pos
  have hN_le_N2 : 2 * N ≤ N ^ 2 := by
    calc 2 * N ≤ N * N := Nat.mul_le_mul_right N (by omega)
      _ = N ^ 2 := by ring
  have hN2_le_N4 : N ^ 2 ≤ N ^ 4 := by
    calc N ^ 2 = N ^ 2 * 1 := (Nat.mul_one _).symm
      _ ≤ N ^ 2 * N ^ 2 := Nat.mul_le_mul_left _ hN2_pos
      _ = N ^ 4 := by ring
  have hbd16 : 16 ≤ b_den * M_e := by
    calc 16 = 1 * 16 := by norm_num
      _ ≤ b_den * M_e := Nat.mul_le_mul hden hMe16
  have hTOP_ge_2bd_N4 : 2 * (b_den * M_e) * N ^ 4 ≤ TOP := by
    rw [hTOP_eq]
    exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by norm_num))
  have hTOP_ge_2bd : 2 * (b_den * M_e) ≤ TOP := by
    calc 2 * (b_den * M_e) = 2 * (b_den * M_e) * 1 := (Nat.mul_one _).symm
      _ ≤ 2 * (b_den * M_e) * N ^ 4 := Nat.mul_le_mul_left _ hN4_pos
      _ ≤ TOP := hTOP_ge_2bd_N4
  have hTOP_ge_64N4 : 64 * N ^ 4 ≤ TOP := by
    rw [hTOP_eq]
    calc 64 * N ^ 4 = (4 * 16) * N ^ 4 := by ring
      _ ≤ (4 * (b_den * M_e)) * N ^ 4 := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 4 hbd16)
  have hbm : b_num * M_e ≤ b_den * M_e := Nat.mul_le_mul_right M_e hb_le
  have h2bd : 2 * b_den ≤ b_den * M_e := by
    calc 2 * b_den = b_den * 2 := by ring
      _ ≤ b_den * M_e := Nat.mul_le_mul_left b_den (by omega)
  have hnumF : b_num * M_e + 2 * b_den ≤ 2 * (b_den * M_e) := by omega
  refine ⟨by omega, by omega, ?_, by omega, by omega, by omega,
    by omega, by omega, by omega, by omega, ?_⟩
  · intro j hj
    have hpow := hpow_le j hj
    exact ⟨by omega, by omega⟩
  · intro m hm
    have hm2_le_P2 : m ^ 2 ≤ P ^ 2 := Nat.pow_le_pow_left hm 2
    have hP2_pos : 1 ≤ P ^ 2 := Nat.one_le_pow 2 P (by omega)
    have hN2_eq : N ^ 2 = 4 * P ^ 2 := by rw [hN]; ring
    have hm2_lt_N2 : m ^ 2 < N ^ 2 := by omega
    have h4m2_le_N2 : 4 * m ^ 2 ≤ N ^ 2 := by omega
    have h4m2N2_le_N4 : 4 * m ^ 2 * N ^ 2 ≤ N ^ 4 := by
      calc 4 * m ^ 2 * N ^ 2 ≤ N ^ 2 * N ^ 2 := Nat.mul_le_mul_right _ h4m2_le_N2
        _ = N ^ 4 := by ring
    have hsub_le_N2 : N ^ 2 - m ^ 2 ≤ N ^ 2 := Nat.sub_le _ _
    have hsub2_le_N4 : (N ^ 2 - m ^ 2) ^ 2 ≤ N ^ 4 := by
      calc (N ^ 2 - m ^ 2) ^ 2 ≤ (N ^ 2) ^ 2 := Nat.pow_le_pow_left hsub_le_N2 2
        _ = N ^ 4 := by ring
    have hrhs_le : (b_num * M_e + 2 * b_den) * (N ^ 2 - m ^ 2) ^ 2 ≤ TOP := by
      calc (b_num * M_e + 2 * b_den) * (N ^ 2 - m ^ 2) ^ 2
          ≤ (2 * (b_den * M_e)) * N ^ 4 := Nat.mul_le_mul hnumF hsub2_le_N4
        _ ≤ TOP := hTOP_ge_2bd_N4
    have hlhs_le : 4 * m ^ 2 * N ^ 2 * (b_den * M_e) ≤ TOP := by
      calc 4 * m ^ 2 * N ^ 2 * (b_den * M_e)
          ≤ N ^ 4 * (b_den * M_e) := Nat.mul_le_mul_right _ h4m2N2_le_N4
        _ = 1 * (b_den * M_e) * N ^ 4 := by ring
        _ ≤ 2 * (b_den * M_e) * N ^ 4 :=
            Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by norm_num))
        _ ≤ TOP := hTOP_ge_2bd_N4
    have h2Nm_le : 2 * N * m ≤ 2 * N ^ 2 := by
      calc 2 * N * m ≤ 2 * N * N := Nat.mul_le_mul_left _ (by omega)
        _ = 2 * N ^ 2 := by ring
    exact ⟨hm2_lt_N2, by omega, by omega, by omega, hlhs_le,
      by omega, by omega, hrhs_le, by omega, by omega⟩

private theorem l56_top_bounds {M_e b_num b_den : ℕ}
    (hMe16 : 16 ≤ M_e) (hden : 1 ≤ b_den) (hb_le : b_num ≤ b_den) :
    let K : ℕ := l56TargetK M_e
    let P : ℕ := 2 ^ K
    let N : ℕ := 2 * P
    let TOP : ℕ := 4 * (b_den * M_e) * N ^ 4
    16 * M_e ≤ TOP ∧
    K ≤ TOP ∧
    (∀ j ≤ K, j ≤ TOP ∧ 2 ^ j ≤ TOP) ∧
    N ≤ TOP ∧
    N ^ 2 ≤ TOP ∧
    2 * N ≤ TOP ∧
    b_den * M_e ≤ TOP ∧
    b_num * M_e ≤ TOP ∧
    2 * b_den ≤ TOP ∧
    b_num * M_e + 2 * b_den ≤ TOP ∧
    (∀ m ≤ P,
      m ^ 2 < N ^ 2 ∧
      m ^ 2 ≤ TOP ∧
      4 * m ^ 2 ≤ TOP ∧
      4 * m ^ 2 * N ^ 2 ≤ TOP ∧
      4 * m ^ 2 * N ^ 2 * (b_den * M_e) ≤ TOP ∧
      N ^ 2 - m ^ 2 ≤ TOP ∧
      (N ^ 2 - m ^ 2) ^ 2 ≤ TOP ∧
      (b_num * M_e + 2 * b_den) * (N ^ 2 - m ^ 2) ^ 2 ≤ TOP ∧
      N ^ 2 + m ^ 2 ≤ TOP ∧
      2 * N * m ≤ TOP) :=
  l56_top_bounds_aux hMe16 hden hb_le
    (l56TargetK_spec hMe16).2.2.1
    (Nat.lt_two_pow_self (n := l56TargetK M_e)).le
    (fun _ hj => Nat.pow_le_pow_right (by norm_num) hj)
    rfl rfl

private theorem poly_cube_bounds {S K L_max u b pc pb au apc : ℕ}
    (hS1 : 1 ≤ S) (hK : K ≤ 6 * S) (hL : L_max ≤ 32 * S)
    (hu : u ≤ 30 + (180 + 140 * K))
    (hb : b ≤ 12 * L_max ^ 2 + (72 + 56 * K) * L_max ^ 2)
    (hpc : pc ≤ 23) (hpb : pb ≤ 1000 * S)
    (hau : au ≤ 35 + (180 + 140 * K)) (hapc : apc ≤ 24) :
    u ≤ 1000000 * S ^ 3 ∧ b ≤ 1000000 * S ^ 3 ∧
    pc ≤ 1000000 * S ^ 3 ∧ pb ≤ 1000000 * S ^ 3 ∧
    au ≤ 1000000 * S ^ 3 ∧ apc ≤ 1000000 * S ^ 3 := by
  have hS2 : S ≤ S ^ 2 := by
    calc S = S * 1 := (Nat.mul_one S).symm
      _ ≤ S * S := Nat.mul_le_mul_left S hS1
      _ = S ^ 2 := by ring
  have hS3 : S ^ 2 ≤ S ^ 3 := by
    calc S ^ 2 = S ^ 2 * 1 := (Nat.mul_one _).symm
      _ ≤ S ^ 2 * S := Nat.mul_le_mul_left _ hS1
      _ = S ^ 3 := by ring
  have h1_le_S3 : 1 ≤ S ^ 3 := by omega
  have hL2 : L_max ^ 2 ≤ 1024 * S ^ 2 := by
    calc L_max ^ 2 ≤ (32 * S) ^ 2 := Nat.pow_le_pow_left hL 2
      _ = 1024 * S ^ 2 := by ring
  have hb_step : b ≤ 430080 * S ^ 3 := by
    have hsum : 12 * L_max ^ 2 + (72 + 56 * K) * L_max ^ 2 = (84 + 56 * K) * L_max ^ 2 := by ring
    calc b ≤ (84 + 56 * K) * L_max ^ 2 := hb.trans_eq hsum
      _ ≤ (420 * S) * (1024 * S ^ 2) := Nat.mul_le_mul (by omega) hL2
      _ = 430080 * S ^ 3 := by ring
  exact ⟨by omega, by omega, by omega, by omega, by omega, by omega⟩

/-! ### 3. Phase-by-phase execution of `coreProg` -/

private theorem exec_phase1 {inp : BitRAMInput 0} {M_e b_num b_den M_bits S_bit : ℕ}
    (hMe16 : 16 ≤ M_e) (hden : 1 ≤ b_den) (hb_le : b_num ≤ b_den)
    (hMbits : 8 ≤ M_bits)
    (hTOP : 4 * (b_den * M_e) * (2 * 2 ^ l56TargetK M_e) ^ 4 < 2 ^ M_bits)
    (hSbit : inp.inputBitSpace + 20 * (8 + (M_bits + 2)) ≤ S_bit)
    {ws₀ : WordStore}
    (hws₀ : HeapBounded (M_bits + 2) ws₀)
    (hc4 : ws₀.read (hLoc 4) = (M_e : ℤ))
    (hc5 : ws₀.read (hLoc 5) = (b_num : ℤ))
    (hc6 : ws₀.read (hLoc 6) = (b_den : ℤ)) :
    let K : ℕ := l56TargetK M_e
    let L_max : ℕ := M_bits + 2
    ∃ ws₁ : WordStore,
      HeapBounded L_max ws₁ ∧
      ws₁.read (hLoc 4) = (M_e : ℤ) ∧
      ws₁.read (hLoc 5) = (b_num : ℤ) ∧
      ws₁.read (hLoc 6) = (b_den : ℤ) ∧
      ws₁.read (hLoc 7) = (K : ℤ) ∧
      ws₁.read (hLoc 8) = ((2 ^ K : ℕ) : ℤ) ∧
      ExecBit inp phase1Prog ws₀ ws₁ (30 + 30 * K) ((12 + 12 * K) * L_max ^ 2) 20 S_bit := by
  intro K L_max
  have hL : 8 ≤ L_max := by dsimp [L_max]; omega
  have htb := l56_top_bounds hMe16 hden hb_le
  obtain ⟨hK_pos, hK_lt, hK_ge, _⟩ := l56TargetK_spec hMe16
  -- Step 1: cell 7 := 1
  obtain ⟨s1, hs1, hb1, hex1⟩ := stepLeaf hL hSbit hws₀ 7 (by omega)
    (leaf_small inp ws₀ 1 (by omega) (by omega) hMbits) 1 rfl
  -- Step 2: cell 8 := 2
  obtain ⟨s2, hs2, hb2, hex2⟩ := stepLeaf hL hSbit hb1 8 (by omega)
    (leaf_small inp s1 2 (by omega) (by omega) hMbits) 2 rfl
  -- Step 3: cell 9 := 16 * cell 4
  obtain ⟨s3, hs3, hb3, hex3⟩ := stepMul hL hSbit hb2 9 (by omega)
    (leaf_small inp s2 16 (by omega) (by omega) hMbits)
    (leaf_cell inp hL hb2 (i := 4) (by omega))
    ((16 * M_e : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs2, hs1, hc4, ↓reduceIte]; norm_cast)
    (ib_of_le_top htb.1 hTOP)
  -- While loop of K - 1 steps
  let Inv : ℕ → WordStore → Prop := fun i m =>
    HeapBounded L_max m ∧
    m.read (hLoc 4) = (M_e : ℤ) ∧
    m.read (hLoc 5) = (b_num : ℤ) ∧
    m.read (hLoc 6) = (b_den : ℤ) ∧
    m.read (hLoc 7) = ((1 + i : ℕ) : ℤ) ∧
    m.read (hLoc 8) = ((2 ^ (1 + i) : ℕ) : ℤ) ∧
    m.read (hLoc 9) = ((16 * M_e : ℕ) : ℤ)
  have hInv0 : Inv 0 s3 := by
    refine ⟨hb3, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · simp (config := { decide := true }) only [hs3, hs2, hs1, hc4, ↓reduceIte]
    · simp (config := { decide := true }) only [hs3, hs2, hs1, hc5, ↓reduceIte]
    · simp (config := { decide := true }) only [hs3, hs2, hs1, hc6, ↓reduceIte]
    · simp (config := { decide := true }) only [hs3, hs2, hs1, ↓reduceIte]
    · simp (config := { decide := true }) only [hs3, hs2, ↓reduceIte]
    · simp (config := { decide := true }) only [hs3, ↓reduceIte]
  have hw := ExecBit.whileLoop_nat (inp := inp)
    (cond := .intLt (cE 8) (cE 9))
    (body := .seq (wAdd 7 (cE 7) (.lit 1)) (wMul 8 (.lit 2) (cE 8)))
    (K - 1) 10 (4 * L_max ^ 2) 20 (8 * L_max ^ 2) 20 S_bit Inv hb3.1 hInv0
    (by
      intro i hi m _ hIm
      rcases hIm with ⟨hbm, hm4, hm5, hm6, hm7, hm8, hm9⟩
      constructor
      · obtain ⟨u_c, b_c, hev, hu, hb⟩ := evalCondLt hL
          (leaf_cell inp hL hbm (i := 8) (by omega))
          (leaf_cell inp hL hbm (i := 9) (by omega))
        have hlt_nat : 2 ^ (1 + i) < 16 * M_e := hK_lt i hi
        have hdec : decide (m.read (hLoc 8) < m.read (hLoc 9)) = true := by
          rw [hm8, hm9]
          exact decide_eq_true (by exact_mod_cast hlt_nat)
        rw [hdec] at hev
        exact ⟨u_c, b_c, hev, hu, hb⟩
      · have hiK : 1 + (i + 1) ≤ K := by omega
        obtain ⟨m1, hm1_rd, hbm1, hstep1⟩ := stepAdd hL hSbit hbm 7 (by omega)
          (leaf_cell inp hL hbm (i := 7) (by omega))
          (leaf_small inp m 1 (by omega) (by omega) hMbits)
          ((1 + (i + 1) : ℕ) : ℤ)
          (by rw [hm7]; push_cast; omega)
          (ib_of_le_top (htb.2.2.1 _ hiK).1 hTOP)
        obtain ⟨m2, hm2_rd, hbm2, hstep2⟩ := stepMul hL hSbit hbm1 8 (by omega)
          (leaf_small inp m1 2 (by omega) (by omega) hMbits)
          (leaf_cell inp hL hbm1 (i := 8) (by omega))
          ((2 ^ (1 + (i + 1)) : ℕ) : ℤ)
          (by
            simp (config := { decide := true }) only [hm1_rd, hm8, ↓reduceIte]
            have : 2 ^ (1 + (i + 1)) = 2 * 2 ^ (1 + i) := by
              rw [show 1 + (i + 1) = (1 + i) + 1 by omega, pow_succ']
            rw [this]; norm_cast)
          (ib_of_le_top (htb.2.2.1 _ hiK).2 hTOP)
        refine ⟨m2, (ExecBit.seq hstep1 hstep2).mono (by omega) (by ring_nf; exact le_rfl), ?_⟩
        refine ⟨hbm2, ?_, ?_, ?_, ?_, ?_, ?_⟩
        · simp (config := { decide := true }) only [hm2_rd, hm1_rd, hm4, ↓reduceIte]
        · simp (config := { decide := true }) only [hm2_rd, hm1_rd, hm5, ↓reduceIte]
        · simp (config := { decide := true }) only [hm2_rd, hm1_rd, hm6, ↓reduceIte]
        · simp (config := { decide := true }) only [hm2_rd, hm1_rd, ↓reduceIte]
        · simp (config := { decide := true }) only [hm2_rd, ↓reduceIte]
        · simp (config := { decide := true }) only [hm2_rd, hm1_rd, hm9, ↓reduceIte])
    (by
      intro m _ hIm
      rcases hIm with ⟨hbm, _, _, _, _, hm8, hm9⟩
      obtain ⟨u_c, b_c, hev, hu, hb⟩ := evalCondLt hL
        (leaf_cell inp hL hbm (i := 8) (by omega))
        (leaf_cell inp hL hbm (i := 9) (by omega))
      have h1K : 1 + (K - 1) = K := by omega
      have hdec : decide (m.read (hLoc 8) < m.read (hLoc 9)) = false := by
        rw [hm8, hm9, h1K]
        exact decide_eq_false (by intro h; exact not_lt_of_ge hK_ge (by exact_mod_cast h))
      rw [hdec] at hev
      exact ⟨u_c, b_c, hev, hu, hb⟩)
  rcases hw with ⟨ws₁, hInvK, hexW⟩
  rcases hInvK with ⟨hb_f, hf4, hf5, hf6, hf7, hf8, _⟩
  have h1K : 1 + (K - 1) = K := by omega
  rw [h1K] at hf7 hf8
  have hexAll := ExecBit.seq hex1 (ExecBit.seq hex2 (ExecBit.seq hex3 hexW))
  refine ⟨ws₁, hb_f, hf4, hf5, hf6, hf7, hf8, hexAll.mono (by omega) ?_⟩
  have hc : 16 + 12 * (K - 1) ≤ 12 + 12 * K := by omega
  calc 4 * L_max ^ 2 + (4 * L_max ^ 2 + (4 * L_max ^ 2 +
        ((K - 1 + 1) * (4 * L_max ^ 2) + (K - 1) * (8 * L_max ^ 2))))
      = (16 + 12 * (K - 1)) * L_max ^ 2 := by ring
    _ ≤ (12 + 12 * K) * L_max ^ 2 := Nat.mul_le_mul_right _ hc

private theorem exec_phase2 {inp : BitRAMInput 0} {M_e b_num b_den M_bits S_bit : ℕ}
    (hMe16 : 16 ≤ M_e) (hden : 1 ≤ b_den) (hb_le : b_num ≤ b_den)
    (hMbits : 8 ≤ M_bits)
    (hTOP : 4 * (b_den * M_e) * (2 * 2 ^ l56TargetK M_e) ^ 4 < 2 ^ M_bits)
    (hSbit : inp.inputBitSpace + 20 * (8 + (M_bits + 2)) ≤ S_bit)
    {ws₁ : WordStore}
    (hws₁ : HeapBounded (M_bits + 2) ws₁)
    (hc4 : ws₁.read (hLoc 4) = (M_e : ℤ))
    (hc5 : ws₁.read (hLoc 5) = (b_num : ℤ))
    (hc6 : ws₁.read (hLoc 6) = (b_den : ℤ))
    (hc7 : ws₁.read (hLoc 7) = (l56TargetK M_e : ℤ))
    (hc8 : ws₁.read (hLoc 8) = ((2 ^ l56TargetK M_e : ℕ) : ℤ)) :
    let K : ℕ := l56TargetK M_e
    let P : ℕ := 2 ^ K
    let N : ℕ := 2 * P
    let L_max : ℕ := M_bits + 2
    ∃ ws₂ : WordStore,
      HeapBounded L_max ws₂ ∧
      ws₂.read (hLoc 7) = (K : ℤ) ∧
      ws₂.read (hLoc 8) = (P : ℤ) ∧
      ws₂.read (hLoc 10) = (N : ℤ) ∧
      ws₂.read (hLoc 11) = ((N ^ 2 : ℕ) : ℤ) ∧
      ws₂.read (hLoc 12) = ((b_den * M_e : ℕ) : ℤ) ∧
      ws₂.read (hLoc 13) = ((b_num * M_e + 2 * b_den : ℕ) : ℤ) ∧
      ws₂.read (hLoc 14) = 0 ∧
      ws₂.read (hLoc 15) = (P : ℤ) ∧
      ExecBit inp phase2Prog ws₁ ws₂ 80 (32 * L_max ^ 2) 20 S_bit := by
  intro K P N L_max
  have hL : 8 ≤ L_max := by dsimp [L_max]; omega
  have htb := l56_top_bounds hMe16 hden hb_le
  -- 1. cell 10 := 2 * cell 8 (N)
  obtain ⟨s1, hs1, hb1, hx1⟩ := stepMul hL hSbit hws₁ 10 (by omega)
    (leaf_small inp ws₁ 2 (by omega) (by omega) hMbits)
    (leaf_cell inp hL hws₁ (i := 8) (by omega))
    (N : ℤ)
    (by rw [hc8]; dsimp [N, P])
    (ib_of_le_top htb.2.2.2.1 hTOP)
  -- 2. cell 11 := cell 10 * cell 10 (N^2)
  obtain ⟨s2, hs2, hb2, hx2⟩ := stepMul hL hSbit hb1 11 (by omega)
    (leaf_cell inp hL hb1 (i := 10) (by omega))
    (leaf_cell inp hL hb1 (i := 10) (by omega))
    ((N ^ 2 : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs1, ↓reduceIte]; push_cast; ring)
    (ib_of_le_top htb.2.2.2.2.1 hTOP)
  -- 3. cell 12 := cell 6 * cell 4 (b_den * M_e)
  obtain ⟨s3, hs3, hb3, hx3⟩ := stepMul hL hSbit hb2 12 (by omega)
    (leaf_cell inp hL hb2 (i := 6) (by omega))
    (leaf_cell inp hL hb2 (i := 4) (by omega))
    ((b_den * M_e : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs2, hs1, hc6, hc4, ↓reduceIte]; norm_cast)
    (ib_of_le_top htb.2.2.2.2.2.2.1 hTOP)
  -- 4. cell 13 := cell 5 * cell 4 (b_num * M_e)
  obtain ⟨s4, hs4, hb4, hx4⟩ := stepMul hL hSbit hb3 13 (by omega)
    (leaf_cell inp hL hb3 (i := 5) (by omega))
    (leaf_cell inp hL hb3 (i := 4) (by omega))
    ((b_num * M_e : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs3, hs2, hs1, hc5, hc4, ↓reduceIte]; norm_cast)
    (ib_of_le_top htb.2.2.2.2.2.2.2.1 hTOP)
  -- 5. cell 14 := 2 * cell 6 (2 * b_den)
  obtain ⟨s5, hs5, hb5, hx5⟩ := stepMul hL hSbit hb4 14 (by omega)
    (leaf_small inp s4 2 (by omega) (by omega) hMbits)
    (leaf_cell inp hL hb4 (i := 6) (by omega))
    ((2 * b_den : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs4, hs3, hs2, hs1, hc6, ↓reduceIte]; norm_cast)
    (ib_of_le_top htb.2.2.2.2.2.2.2.2.1 hTOP)
  -- 6. cell 13 := cell 13 + cell 14 (b_num * M_e + 2 * b_den)
  obtain ⟨s6, hs6, hb6, hx6⟩ := stepAdd hL hSbit hb5 13 (by omega)
    (leaf_cell inp hL hb5 (i := 13) (by omega))
    (leaf_cell inp hL hb5 (i := 14) (by omega))
    ((b_num * M_e + 2 * b_den : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs5, hs4, ↓reduceIte]; norm_cast)
    (ib_of_le_top htb.2.2.2.2.2.2.2.2.2.1 hTOP)
  -- 7. cell 14 := 0
  obtain ⟨s7, hs7, hb7, hx7⟩ := stepLeaf hL hSbit hb6 14 (by omega)
    (leaf_small inp s6 0 (by omega) (by omega) hMbits) 0 rfl
  -- 8. cell 15 := cell 8
  obtain ⟨s8, hs8, hb8, hx8⟩ := stepLeaf hL hSbit hb7 15 (by omega)
    (leaf_cell inp hL hb7 (i := 8) (by omega))
    (P : ℤ)
    (by simp (config := { decide := true }) only [hs7, hs6, hs5, hs4, hs3, hs2, hs1, hc8, ↓reduceIte]; rfl)
  have hxAll := ExecBit.seq hx1 (ExecBit.seq hx2 (ExecBit.seq hx3
    (ExecBit.seq hx4 (ExecBit.seq hx5 (ExecBit.seq hx6 (ExecBit.seq hx7 hx8))))))
  refine ⟨s8, hb8, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hxAll.mono (by omega) (by ring_nf; exact le_rfl)⟩
  · simp (config := { decide := true }) only [hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hc7, ↓reduceIte]; rfl
  · simp (config := { decide := true }) only [hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hc8, ↓reduceIte]; rfl
  · simp (config := { decide := true }) only [hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, ↓reduceIte]
  · simp (config := { decide := true }) only [hs8, hs7, hs6, hs5, hs4, hs3, hs2, ↓reduceIte]
  · simp (config := { decide := true }) only [hs8, hs7, hs6, hs5, hs4, hs3, ↓reduceIte]
  · simp (config := { decide := true }) only [hs8, hs7, hs6, ↓reduceIte]
  · simp (config := { decide := true }) only [hs8, hs7, ↓reduceIte]
  · simp (config := { decide := true }) only [hs8, ↓reduceIte]

private theorem exec_bsBody {inp : BitRAMInput 0} {M_e b_num b_den M_bits S_bit : ℕ}
    (hMe16 : 16 ≤ M_e) (hden : 1 ≤ b_den) (hb_le : b_num ≤ b_den)
    (hMbits : 8 ≤ M_bits)
    (hTOP : 4 * (b_den * M_e) * (2 * 2 ^ l56TargetK M_e) ^ 4 < 2 ^ M_bits)
    (hSbit : inp.inputBitSpace + 20 * (8 + (M_bits + 2)) ≤ S_bit)
    {lh : ℕ × ℕ}
    (hloP : lh.1 ≤ 2 ^ l56TargetK M_e)
    (hhiP : lh.2 ≤ 2 ^ l56TargetK M_e)
    {m : WordStore}
    (hbm : HeapBounded (M_bits + 2) m)
    (hm8 : m.read (hLoc 8) = ((2 ^ l56TargetK M_e : ℕ) : ℤ))
    (hm10 : m.read (hLoc 10) = ((2 * 2 ^ l56TargetK M_e : ℕ) : ℤ))
    (hm11 : m.read (hLoc 11) = (((2 * 2 ^ l56TargetK M_e) ^ 2 : ℕ) : ℤ))
    (hm12 : m.read (hLoc 12) = ((b_den * M_e : ℕ) : ℤ))
    (hm13 : m.read (hLoc 13) = ((b_num * M_e + 2 * b_den : ℕ) : ℤ))
    (hm14 : m.read (hLoc 14) = (lh.1 : ℤ))
    (hm15 : m.read (hLoc 15) = (lh.2 : ℤ)) :
    let P : ℕ := 2 ^ l56TargetK M_e
    let N : ℕ := 2 * P
    let L_max : ℕ := M_bits + 2
    let lh' := l56Step M_e b_num b_den P lh
    ∃ m' : WordStore,
      HeapBounded L_max m' ∧
      m'.read (hLoc 8) = (P : ℤ) ∧
      m'.read (hLoc 10) = (N : ℤ) ∧
      m'.read (hLoc 11) = ((N ^ 2 : ℕ) : ℤ) ∧
      m'.read (hLoc 12) = ((b_den * M_e : ℕ) : ℤ) ∧
      m'.read (hLoc 13) = ((b_num * M_e + 2 * b_den : ℕ) : ℤ) ∧
      m'.read (hLoc 14) = (lh'.1 : ℤ) ∧
      m'.read (hLoc 15) = (lh'.2 : ℤ) ∧
      ExecBit inp bsBody m m' 110 (44 * L_max ^ 2) 20 S_bit := by
  intro P N L_max lh'
  have hL : 8 ≤ L_max := by dsimp [L_max]; omega
  have htb := l56_top_bounds hMe16 hden hb_le
  set mid : ℕ := (lh.1 + lh.2) / 2
  have hmidP : mid ≤ P := by dsimp [mid]; omega
  have hmb := htb.2.2.2.2.2.2.2.2.2.2 mid hmidP
  have hsum_le_top : lh.1 + lh.2 ≤ 4 * (b_den * M_e) * N ^ 4 :=
    (show lh.1 + lh.2 ≤ N by dsimp [N, P]; omega).trans htb.2.2.2.1
  have hmid_le_top : mid ≤ 4 * (b_den * M_e) * N ^ 4 :=
    (show mid ≤ N by dsimp [N, P]; omega).trans htb.2.2.2.1
  -- 1. cell 16 := cell 14 + cell 15
  obtain ⟨s1, hs1, hb1, hx1⟩ := stepAdd hL hSbit hbm 16 (by omega)
    (leaf_cell inp hL hbm (i := 14) (by omega))
    (leaf_cell inp hL hbm (i := 15) (by omega))
    ((lh.1 + lh.2 : ℕ) : ℤ)
    (by rw [hm14, hm15]; norm_cast)
    (ib_of_le_top hsum_le_top hTOP)
  -- 2. cell 16 := cell 16 / 2 (mid)
  obtain ⟨s2, hs2, hb2, hx2⟩ := stepDiv hL hSbit hb1 16 (by omega)
    (leaf_cell inp hL hb1 (i := 16) (by omega))
    (leaf_small inp s1 2 (by omega) (by omega) hMbits)
    (mid : ℤ)
    (by simp (config := { decide := true }) only [hs1, mid, Int.natCast_ediv, ↓reduceIte]; rfl)
    (ib_of_le_top hmid_le_top hTOP)
  -- 3. cell 17 := cell 16 * cell 16 (mid^2)
  obtain ⟨s3, hs3, hb3, hx3⟩ := stepMul hL hSbit hb2 17 (by omega)
    (leaf_cell inp hL hb2 (i := 16) (by omega))
    (leaf_cell inp hL hb2 (i := 16) (by omega))
    ((mid ^ 2 : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs2, ↓reduceIte]; push_cast; ring)
    (ib_of_le_top hmb.2.1 hTOP)
  -- 4. cell 18 := 4 * cell 17
  obtain ⟨s4, hs4, hb4, hx4⟩ := stepMul hL hSbit hb3 18 (by omega)
    (leaf_small inp s3 4 (by omega) (by omega) hMbits)
    (leaf_cell inp hL hb3 (i := 17) (by omega))
    ((4 * mid ^ 2 : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs3, ↓reduceIte]; norm_cast)
    (ib_of_le_top hmb.2.2.1 hTOP)
  -- 5. cell 18 := cell 18 * cell 11 (4 * mid^2 * N^2)
  obtain ⟨s5, hs5, hb5, hx5⟩ := stepMul hL hSbit hb4 18 (by omega)
    (leaf_cell inp hL hb4 (i := 18) (by omega))
    (leaf_cell inp hL hb4 (i := 11) (by omega))
    ((4 * mid ^ 2 * N ^ 2 : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs4, hs3, hs2, hs1, hm11, ↓reduceIte]; dsimp [N, P])
    (ib_of_le_top hmb.2.2.2.1 hTOP)
  -- 6. cell 18 := cell 18 * cell 12 (lhs)
  obtain ⟨s6, hs6, hb6, hx6⟩ := stepMul hL hSbit hb5 18 (by omega)
    (leaf_cell inp hL hb5 (i := 18) (by omega))
    (leaf_cell inp hL hb5 (i := 12) (by omega))
    ((4 * mid ^ 2 * N ^ 2 * (b_den * M_e) : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs5, hs4, hs3, hs2, hs1, hm12, ↓reduceIte]; norm_cast)
    (ib_of_le_top hmb.2.2.2.2.1 hTOP)
  -- 7. cell 19 := cell 11 - cell 17 (N^2 - mid^2)
  obtain ⟨s7, hs7, hb7, hx7⟩ := stepSub hL hSbit hb6 19 (by omega)
    (leaf_cell inp hL hb6 (i := 11) (by omega))
    (leaf_cell inp hL hb6 (i := 17) (by omega))
    ((N ^ 2 - mid ^ 2 : ℕ) : ℤ)
    (by
      simp (config := { decide := true }) only [hs6, hs5, hs4, hs3, hs2, hs1, hm11, ↓reduceIte]
      exact (Int.ofNat_sub hmb.1.le).symm)
    (ib_of_le_top hmb.2.2.2.2.2.1 hTOP)
  -- 8. cell 19 := cell 19 * cell 19 ((N^2 - mid^2)^2)
  obtain ⟨s8, hs8, hb8, hx8⟩ := stepMul hL hSbit hb7 19 (by omega)
    (leaf_cell inp hL hb7 (i := 19) (by omega))
    (leaf_cell inp hL hb7 (i := 19) (by omega))
    (((N ^ 2 - mid ^ 2) ^ 2 : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs7, ↓reduceIte]; push_cast; ring)
    (ib_of_le_top hmb.2.2.2.2.2.2.1 hTOP)
  -- 9. cell 19 := cell 13 * cell 19 (rhs)
  obtain ⟨s9, hs9, hb9, hx9⟩ := stepMul hL hSbit hb8 19 (by omega)
    (leaf_cell inp hL hb8 (i := 13) (by omega))
    (leaf_cell inp hL hb8 (i := 19) (by omega))
    (((b_num * M_e + 2 * b_den) * (N ^ 2 - mid ^ 2) ^ 2 : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm13, ↓reduceIte]; norm_cast)
    (ib_of_le_top hmb.2.2.2.2.2.2.2.1 hTOP)
  -- 10. ite (.intLt (cE 18) (cE 19))
  obtain ⟨u_c, b_c, hev_c, hu_c, hb_c⟩ := evalCondLt hL
    (leaf_cell inp hL hb9 (i := 18) (by omega))
    (leaf_cell inp hL hb9 (i := 19) (by omega))
  have hs9_18 : s9.read (hLoc 18) = ((4 * mid ^ 2 * N ^ 2 * (b_den * M_e) : ℕ) : ℤ) := by
    simp (config := { decide := true }) only [hs9, hs8, hs7, hs6, ↓reduceIte]
  have hs9_19 : s9.read (hLoc 19) =
      (((b_num * M_e + 2 * b_den) * (N ^ 2 - mid ^ 2) ^ 2 : ℕ) : ℤ) := by
    simp (config := { decide := true }) only [hs9, ↓reduceIte]
  have hcond_eq : decide (s9.read (hLoc 18) < s9.read (hLoc 19)) =
      l56CondNat M_e b_num b_den N mid := by
    rw [hs9_18, hs9_19]
    unfold l56CondNat
    exact decide_eq_decide.mpr Int.ofNat_lt
  rw [hcond_eq] at hev_c
  cases hflag : l56CondNat M_e b_num b_den N mid
  · -- false branch: cell 15 := cell 16 (hi := mid)
    rw [hflag] at hev_c
    obtain ⟨s10, hs10, hb10, hxBr⟩ := stepLeaf hL hSbit hb9 15 (by omega)
      (leaf_cell inp hL hb9 (i := 16) (by omega))
      (mid : ℤ)
      (by simp (config := { decide := true }) only [hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, ↓reduceIte])
    have hx10 := ExecBit.ite_false (tB := wLeaf 14 (cE 16)) hev_c hu_c hb_c hxBr
    have hlh' : lh' = (lh.1, mid) := by
      dsimp [lh', l56Step, mid, N] at hflag ⊢
      simp [hflag]
    have hxAll := ExecBit.seq hx1 (ExecBit.seq hx2 (ExecBit.seq hx3 (ExecBit.seq hx4
      (ExecBit.seq hx5 (ExecBit.seq hx6 (ExecBit.seq hx7 (ExecBit.seq hx8
        (ExecBit.seq hx9 hx10))))))))
    refine ⟨s10, hb10, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hxAll.mono (by omega) (by ring_nf; exact le_rfl)⟩
    · simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm8, ↓reduceIte]; rfl
    · simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm10, ↓reduceIte]; rfl
    · simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm11, ↓reduceIte]; rfl
    · simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm12, ↓reduceIte]
    · simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm13, ↓reduceIte]
    · rw [hlh']; simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm14, ↓reduceIte]
    · rw [hlh']; simp (config := { decide := true }) only [hs10, ↓reduceIte]
  · -- true branch: cell 14 := cell 16 (lo := mid)
    rw [hflag] at hev_c
    obtain ⟨s10, hs10, hb10, hxBr⟩ := stepLeaf hL hSbit hb9 14 (by omega)
      (leaf_cell inp hL hb9 (i := 16) (by omega))
      (mid : ℤ)
      (by simp (config := { decide := true }) only [hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, ↓reduceIte])
    have hx10 := ExecBit.ite_true (fB := wLeaf 15 (cE 16)) hev_c hu_c hb_c hxBr
    have hlh' : lh' = (mid, lh.2) := by
      dsimp [lh', l56Step, mid, N] at hflag ⊢
      simp [hflag]
    have hxAll := ExecBit.seq hx1 (ExecBit.seq hx2 (ExecBit.seq hx3 (ExecBit.seq hx4
      (ExecBit.seq hx5 (ExecBit.seq hx6 (ExecBit.seq hx7 (ExecBit.seq hx8
        (ExecBit.seq hx9 hx10))))))))
    refine ⟨s10, hb10, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hxAll.mono (by omega) (by ring_nf; exact le_rfl)⟩
    · simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm8, ↓reduceIte]; rfl
    · simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm10, ↓reduceIte]; rfl
    · simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm11, ↓reduceIte]; rfl
    · simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm12, ↓reduceIte]
    · simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm13, ↓reduceIte]
    · rw [hlh']; simp (config := { decide := true }) only [hs10, ↓reduceIte]
    · rw [hlh']; simp (config := { decide := true }) only [hs10, hs9, hs8, hs7, hs6, hs5, hs4, hs3, hs2, hs1, hm15, ↓reduceIte]

private theorem exec_phase4 {inp : BitRAMInput 0} {M_e b_num b_den M_bits S_bit hi : ℕ}
    (hMe16 : 16 ≤ M_e) (hden : 1 ≤ b_den) (hb_le : b_num ≤ b_den)
    (hMbits : 8 ≤ M_bits)
    (hTOP : 4 * (b_den * M_e) * (2 * 2 ^ l56TargetK M_e) ^ 4 < 2 ^ M_bits)
    (hSbit : inp.inputBitSpace + 20 * (8 + (M_bits + 2)) ≤ S_bit)
    (hhiP : hi ≤ 2 ^ l56TargetK M_e)
    {ws₃ : WordStore}
    (hws₃ : HeapBounded (M_bits + 2) ws₃)
    (hc10 : ws₃.read (hLoc 10) = ((2 * 2 ^ l56TargetK M_e : ℕ) : ℤ))
    (hc11 : ws₃.read (hLoc 11) = (((2 * 2 ^ l56TargetK M_e) ^ 2 : ℕ) : ℤ))
    (hc15 : ws₃.read (hLoc 15) = (hi : ℤ)) :
    let N : ℕ := 2 * 2 ^ l56TargetK M_e
    let L_max : ℕ := M_bits + 2
    ∃ ws₄ : WordStore,
      HeapBounded L_max ws₄ ∧
      ws₄.read (hLoc 0) = ((N ^ 2 - hi ^ 2 : ℕ) : ℤ) ∧
      ws₄.read (hLoc 1) = ((N ^ 2 + hi ^ 2 : ℕ) : ℤ) ∧
      ws₄.read (hLoc 2) = ((2 * N * hi : ℕ) : ℤ) ∧
      ws₄.read (hLoc 3) = ((N ^ 2 + hi ^ 2 : ℕ) : ℤ) ∧
      ExecBit inp phase4Prog ws₃ ws₄ 60 (24 * L_max ^ 2) 20 S_bit := by
  intro N L_max
  have hL : 8 ≤ L_max := by dsimp [L_max]; omega
  have htb := l56_top_bounds hMe16 hden hb_le
  have hmb := htb.2.2.2.2.2.2.2.2.2.2 hi hhiP
  -- 1. cell 17 := cell 15 * cell 15 (hi^2)
  obtain ⟨s1, hs1, hb1, hx1⟩ := stepMul hL hSbit hws₃ 17 (by omega)
    (leaf_cell inp hL hws₃ (i := 15) (by omega))
    (leaf_cell inp hL hws₃ (i := 15) (by omega))
    ((hi ^ 2 : ℕ) : ℤ)
    (by rw [hc15]; push_cast; ring)
    (ib_of_le_top hmb.2.1 hTOP)
  -- 2. cell 0 := cell 11 - cell 17 (N^2 - hi^2)
  obtain ⟨s2, hs2, hb2, hx2⟩ := stepSub hL hSbit hb1 0 (by omega)
    (leaf_cell inp hL hb1 (i := 11) (by omega))
    (leaf_cell inp hL hb1 (i := 17) (by omega))
    ((N ^ 2 - hi ^ 2 : ℕ) : ℤ)
    (by
      simp (config := { decide := true }) only [hs1, hc11, ↓reduceIte]
      exact (Int.ofNat_sub hmb.1.le).symm)
    (ib_of_le_top hmb.2.2.2.2.2.1 hTOP)
  -- 3. cell 1 := cell 11 + cell 17 (N^2 + hi^2)
  obtain ⟨s3, hs3, hb3, hx3⟩ := stepAdd hL hSbit hb2 1 (by omega)
    (leaf_cell inp hL hb2 (i := 11) (by omega))
    (leaf_cell inp hL hb2 (i := 17) (by omega))
    ((N ^ 2 + hi ^ 2 : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs2, hs1, hc11, ↓reduceIte]; norm_cast)
    (ib_of_le_top hmb.2.2.2.2.2.2.2.2.1 hTOP)
  -- 4. cell 18 := 2 * cell 10 (2 * N)
  obtain ⟨s4, hs4, hb4, hx4⟩ := stepMul hL hSbit hb3 18 (by omega)
    (leaf_small inp s3 2 (by omega) (by omega) hMbits)
    (leaf_cell inp hL hb3 (i := 10) (by omega))
    ((2 * N : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs3, hs2, hs1, hc10, ↓reduceIte]; norm_cast)
    (ib_of_le_top htb.2.2.2.2.2.1 hTOP)
  -- 5. cell 2 := cell 18 * cell 15 (2 * N * hi)
  obtain ⟨s5, hs5, hb5, hx5⟩ := stepMul hL hSbit hb4 2 (by omega)
    (leaf_cell inp hL hb4 (i := 18) (by omega))
    (leaf_cell inp hL hb4 (i := 15) (by omega))
    ((2 * N * hi : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs4, hs3, hs2, hs1, hc15, ↓reduceIte]; norm_cast)
    (ib_of_le_top hmb.2.2.2.2.2.2.2.2.2 hTOP)
  -- 6. cell 3 := cell 1
  obtain ⟨s6, hs6, hb6, hx6⟩ := stepLeaf hL hSbit hb5 3 (by omega)
    (leaf_cell inp hL hb5 (i := 1) (by omega))
    ((N ^ 2 + hi ^ 2 : ℕ) : ℤ)
    (by simp (config := { decide := true }) only [hs5, hs4, hs3, ↓reduceIte])
  have hxAll := ExecBit.seq hx1 (ExecBit.seq hx2 (ExecBit.seq hx3
    (ExecBit.seq hx4 (ExecBit.seq hx5 hx6))))
  refine ⟨s6, hb6, ?_, ?_, ?_, ?_, hxAll.mono (by omega) (by ring_nf; exact le_rfl)⟩
  · simp (config := { decide := true }) only [hs6, hs5, hs4, hs3, hs2, ↓reduceIte]
  · simp (config := { decide := true }) only [hs6, hs5, hs4, hs3, ↓reduceIte]
  · simp (config := { decide := true }) only [hs6, hs5, ↓reduceIte]
  · simp (config := { decide := true }) only [hs6, ↓reduceIte]

private theorem exec_coreProg {inp : BitRAMInput 0} {M_e b_num b_den M_bits S_bit : ℕ}
    (hMe16 : 16 ≤ M_e) (hden : 1 ≤ b_den) (hb_le : b_num ≤ b_den)
    (hMbits : 8 ≤ M_bits)
    (hTOP : 4 * (b_den * M_e) * (2 * 2 ^ l56TargetK M_e) ^ 4 < 2 ^ M_bits)
    (hSbit : inp.inputBitSpace + 20 * (8 + (M_bits + 2)) ≤ S_bit)
    {ws₀ : WordStore}
    (hws₀ : HeapBounded (M_bits + 2) ws₀)
    (hc4 : ws₀.read (hLoc 4) = (M_e : ℤ))
    (hc5 : ws₀.read (hLoc 5) = (b_num : ℤ))
    (hc6 : ws₀.read (hLoc 6) = (b_den : ℤ)) :
    let K : ℕ := l56TargetK M_e
    let L_max : ℕ := M_bits + 2
    let res := l56ComputeAB M_e b_num b_den
    ∃ ws_f : WordStore,
      HeapBounded L_max ws_f ∧
      ws_f.read (hLoc 0) = (res.1 : ℤ) ∧
      ws_f.read (hLoc 1) = (res.2.1 : ℤ) ∧
      ws_f.read (hLoc 2) = (res.2.2.1 : ℤ) ∧
      ws_f.read (hLoc 3) = (res.2.2.2 : ℤ) ∧
      ExecBit inp coreProg ws₀ ws_f
        (180 + 140 * K) ((72 + 56 * K) * L_max ^ 2) 20 S_bit := by
  intro K L_max res
  have hL : 8 ≤ L_max := by dsimp [L_max]; omega
  obtain ⟨ws₁, hb1, h1_4, h1_5, h1_6, h1_7, h1_8, hx1⟩ :=
    exec_phase1 hMe16 hden hb_le hMbits hTOP hSbit hws₀ hc4 hc5 hc6
  obtain ⟨ws₂, hb2, h2_7, h2_8, h2_10, h2_11, h2_12, h2_13, h2_14, h2_15, hx2⟩ :=
    exec_phase2 hMe16 hden hb_le hMbits hTOP hSbit hb1 h1_4 h1_5 h1_6 h1_7 h1_8
  set P : ℕ := 2 ^ K
  set N : ℕ := 2 * P
  -- Phase 3: repeatN K of bsBody
  rcases (leaf_cell inp hL hb2 (i := 7) (by omega)).2 with ⟨u_cnt, b_cnt, hcnt, hu_cnt, hb_cnt⟩
  rw [h2_7] at hcnt
  let Inv3 : ℕ → WordStore → Prop := fun s m =>
    let lh := l56Iter M_e b_num b_den P s
    HeapBounded L_max m ∧
    m.read (hLoc 8) = (P : ℤ) ∧
    m.read (hLoc 10) = (N : ℤ) ∧
    m.read (hLoc 11) = ((N ^ 2 : ℕ) : ℤ) ∧
    m.read (hLoc 12) = ((b_den * M_e : ℕ) : ℤ) ∧
    m.read (hLoc 13) = ((b_num * M_e + 2 * b_den : ℕ) : ℤ) ∧
    m.read (hLoc 14) = (lh.1 : ℤ) ∧
    m.read (hLoc 15) = (lh.2 : ℤ)
  have hInv3_0 : Inv3 0 ws₂ := by
    refine ⟨hb2, h2_8, h2_10, h2_11, h2_12, h2_13, ?_, ?_⟩
    · simpa [l56Iter] using h2_14
    · simpa [l56Iter] using h2_15
  have hb_cnt' : b_cnt ≤ 4 * L_max ^ 2 := by
    calc b_cnt ≤ 3 * L_max := hb_cnt
      _ ≤ L_max * L_max := Nat.mul_le_mul_right L_max (by omega)
      _ = L_max ^ 2 := by ring
      _ ≤ 4 * L_max ^ 2 := Nat.le_mul_of_pos_left _ (by norm_num)
  obtain ⟨ws₃, hInv3_K, hx3⟩ := ExecBit.repeatN_nat (inp := inp)
    (countE := cE 7) (body := bsBody)
    K 10 (4 * L_max ^ 2) 110 (44 * L_max ^ 2) 20 S_bit Inv3 hb2.1 hInv3_0
    hcnt (by omega) hb_cnt'
    (by
      intro s hs m _ hIm
      rcases hIm with ⟨hbm, hm8, hm10, hm11, hm12, hm13, hm14, hm15⟩
      have hiter_s := l56Iter_inv hMe16 hden hb_le s (by omega)
      have hhiP : (l56Iter M_e b_num b_den P s).2 ≤ P := hiter_s.2.1
      have hloP : (l56Iter M_e b_num b_den P s).1 ≤ P := (Nat.le.intro hiter_s.1.symm).trans hhiP
      obtain ⟨m', hbm', hm'8, hm'10, hm'11, hm'12, hm'13, hm'14, hm'15, hstep⟩ :=
        exec_bsBody hMe16 hden hb_le hMbits hTOP hSbit hloP hhiP hbm
          hm8 hm10 hm11 hm12 hm13 hm14 hm15
      exact ⟨m', hstep, hbm', hm'8, hm'10, hm'11, hm'12, hm'13, hm'14, hm'15⟩)
  rcases hInv3_K with ⟨hb3, _, h3_10, h3_11, _, _, _, h3_15⟩
  have hhiK_P : (l56Iter M_e b_num b_den P K).2 ≤ P :=
    (l56Iter_inv hMe16 hden hb_le K le_rfl).2.1
  obtain ⟨ws₄, hb4, h4_0, h4_1, h4_2, h4_3, hx4⟩ :=
    exec_phase4 hMe16 hden hb_le hMbits hTOP hSbit hhiK_P hb3 h3_10 h3_11 h3_15
  have hxAll := ExecBit.seq hx1 (ExecBit.seq hx2 (ExecBit.seq hx3 hx4))
  exact ⟨ws₄, hb4, h4_0, h4_1, h4_2, h4_3,
    hxAll.mono (by omega) (by dsimp only [K, L_max]; ring_nf; exact le_rfl)⟩

/-! ### 4. Full execution theorem for `l56ProgBit` and `l56ProgArith` -/

theorem l56_ram_exec_spec
    {b e : ℚ} (hb0 : 0 ≤ b) (hb1 : b ≤ 1)
    (he0 : 0 < e) (he16 : (e : ℝ) ≤ 1 / 16) :
    let L_b : ℕ := ratBitLength b
    let L_e : ℕ := Nat.ceil (Real.log (1 / (e : ℝ)))
    let bound : ℕ := 1000000 * (L_b + L_e + 1) ^ 3
    let M_e : ℕ := Nat.ceil (1 / e)
    let res := l56ComputeAB M_e b.num.toNat b.den
    let inpBit : BitRAMInput 0 :=
      { intParams := [(M_e : ℤ)]
        activeHandles := ∅
        activeRatCoords := fun _ i => Fin.elim0 i
        extraRats := [b] }
    let inpArith : ArithRAMInput 0 :=
      { intParams := [b.num, (b.den : ℤ), e.num, (e.den : ℤ)]
        activeHandles := ∅
        activeCoords := fun _ => 0
        extraReals := [] }
    ∃ (outBit : BitRAMExecOutcome) (outArith : ArithRAMExecOutcome),
      runBitRAMWithBits l56ProgBit inpBit WordStore.empty [] = some outBit ∧
      outBit.unitCost ≤ bound ∧ outBit.bitCost ≤ bound ∧
      outBit.peakCellSpace ≤ bound ∧ outBit.peakBitSpace ≤ bound ∧
      runArithRAMWithBits l56ProgArith inpArith ArithRAMMemory.empty [] = some outArith ∧
      outArith.unitCost ≤ bound ∧ outArith.peakCellSpace ≤ bound ∧
      outBit.words.read (.heap 0 0) = (res.1 : ℤ) ∧
      outBit.words.read (.heap 0 1) = (res.2.1 : ℤ) ∧
      outBit.words.read (.heap 0 2) = (res.2.2.1 : ℤ) ∧
      outBit.words.read (.heap 0 3) = (res.2.2.2 : ℤ) ∧
      outArith.mem.words.read (.heap 0 0) = (res.1 : ℤ) ∧
      outArith.mem.words.read (.heap 0 1) = (res.2.1 : ℤ) ∧
      outArith.mem.words.read (.heap 0 2) = (res.2.2.1 : ℤ) ∧
      outArith.mem.words.read (.heap 0 3) = (res.2.2.2 : ℤ) := by
  intro L_b L_e bound M_e res inpBit inpArith
  obtain ⟨hMe16, hMe_pow, hK_le, _, _⟩ := l56_ceil_inv_e_bounds he0 he16
  set b_num : ℕ := b.num.toNat
  set b_den : ℕ := b.den
  have hb_num_nn : 0 ≤ b.num := Rat.num_nonneg.mpr hb0
  have hb_num_z : (b_num : ℤ) = b.num := Int.toNat_of_nonneg hb_num_nn
  have hb_den_pos : 1 ≤ b_den := Nat.succ_le_of_lt b.pos
  have hb_num_le_den : b_num ≤ b_den := by
    have hq : (b.num : ℚ) / (b.den : ℚ) ≤ 1 := by rw [Rat.num_div_den]; exact hb1
    have hle_z : b.num ≤ (b.den : ℤ) := by
      exact_mod_cast (div_le_one (by exact_mod_cast b.pos : (0 : ℚ) < b.den)).mp hq
    rw [← hb_num_z] at hle_z
    exact_mod_cast hle_z
  obtain ⟨hbnum_lt, hbden_lt⟩ := b_num_den_lt_two_pow b
  set S : ℕ := L_b + L_e + 1
  have hS1 : 1 ≤ S := by dsimp [S]; omega
  set M_bits : ℕ := L_b + 10 * L_e + 30
  set L_max : ℕ := M_bits + 2
  have hMbits8 : 8 ≤ M_bits := by dsimp [M_bits]; omega
  have hLmax_le : L_max ≤ 32 * S := by dsimp [L_max, M_bits, S]; omega
  -- Prove TOP < 2 ^ M_bits
  have hTOP_lt : 4 * (b_den * M_e) * (2 * 2 ^ l56TargetK M_e) ^ 4 < 2 ^ M_bits := by
    have hP_le : 2 ^ l56TargetK M_e ≤ 2 ^ (2 * L_e + 4) :=
      Nat.pow_le_pow_right (by norm_num) hK_le
    have hN_le : 2 * 2 ^ l56TargetK M_e ≤ 2 ^ (2 * L_e + 5) := by
      have : 2 ^ (2 * L_e + 5) = 2 * 2 ^ (2 * L_e + 4) := by ring
      omega
    have hN4_le : (2 * 2 ^ l56TargetK M_e) ^ 4 ≤ (2 ^ (2 * L_e + 5)) ^ 4 :=
      Nat.pow_le_pow_left hN_le 4
    have hbdMe_lt : b_den * M_e < 2 ^ L_b * 2 ^ (2 * L_e) := by
      calc b_den * M_e ≤ b_den * 2 ^ (2 * L_e) := Nat.mul_le_mul_left _ hMe_pow
        _ < 2 ^ L_b * 2 ^ (2 * L_e) :=
            Nat.mul_lt_mul_of_pos_right hbden_lt (Nat.two_pow_pos _)
    have hprod_lt : 4 * (b_den * M_e) * (2 * 2 ^ l56TargetK M_e) ^ 4 <
        4 * (2 ^ L_b * 2 ^ (2 * L_e)) * (2 ^ (2 * L_e + 5)) ^ 4 := by
      have h1 : 4 * (b_den * M_e) < 4 * (2 ^ L_b * 2 ^ (2 * L_e)) := by omega
      exact lt_of_le_of_lt (Nat.mul_le_mul_left _ hN4_le)
        (Nat.mul_lt_mul_of_pos_right h1 (Nat.pos_of_ne_zero (by positivity)))
    have hpow_eq : 4 * (2 ^ L_b * 2 ^ (2 * L_e)) * (2 ^ (2 * L_e + 5)) ^ 4 =
        2 ^ (L_b + 10 * L_e + 22) := by ring
    rw [hpow_eq] at hprod_lt
    exact hprod_lt.trans_le (Nat.pow_le_pow_right (by norm_num) (by dsimp [M_bits]; omega))
  -- Input space bounds for inpBit
  have hinpB_cell : inpBit.inputCellSpace = 3 := by
    simp [inpBit, BitRAMInput.inputCellSpace]
  have hMe_ib : intBitLength (M_e : ℤ) ≤ L_max := by
    have hlt : (M_e : ℤ).natAbs < 2 ^ M_bits := by
      rw [Int.natAbs_natCast]
      exact lt_of_le_of_lt hMe_pow
        (Nat.pow_lt_pow_right (by norm_num) (by dsimp [M_bits]; omega))
    exact intBitLength_le_of_abs_lt_two_pow hlt
  have hbnum_ib : intBitLength b.num ≤ L_max := by
    have hlt : b.num.natAbs < 2 ^ M_bits :=
      lt_of_lt_of_le hbnum_lt (Nat.pow_le_pow_right (by norm_num) (by dsimp [M_bits]; omega))
    exact intBitLength_le_of_abs_lt_two_pow hlt
  have hbden_ib : intBitLength (b_den : ℤ) ≤ L_max := by
    have hlt : (b_den : ℤ).natAbs < 2 ^ M_bits := by
      rw [Int.natAbs_natCast]
      exact lt_of_lt_of_le hbden_lt (Nat.pow_le_pow_right (by norm_num) (by dsimp [M_bits]; omega))
    exact intBitLength_le_of_abs_lt_two_pow hlt
  have hinpB_bit : inpBit.inputBitSpace ≤ L_max + L_b := by
    have heq : inpBit.inputBitSpace = intBitLength (M_e : ℤ) + ratBitLength b := by
      simp [inpBit, BitRAMInput.inputBitSpace]
    rw [heq]
    change intBitLength (M_e : ℤ) + L_b ≤ L_max + L_b
    omega
  set S_bit : ℕ := L_max + L_b + 20 * (8 + L_max)
  have hSbit : inpBit.inputBitSpace + 20 * (8 + L_max) ≤ S_bit := by
    dsimp [S_bit]; omega
  -- 3-step preBitProg on inpBit
  have hL8 : 8 ≤ L_max := by dsimp [L_max, M_bits]; omega
  have hb0_ws := heapBounded_empty (L_max := L_max) (by omega)
  have hleaf_p1 : BoundedLeaf inpBit L_max WordStore.empty (.intParam (.lit 0)) (M_e : ℤ) :=
    ⟨hMe_ib, 2, 2 + intBitLength (M_e : ℤ),
      by simp [evalIntExpr, inpBit, listGetIntD, intBitLength], le_rfl, by omega⟩
  obtain ⟨hb1_ws, hx_p1⟩ := execWriteLeaf hL8 hSbit hb0_ws (j := 4) (by omega) hleaf_p1
  simp only [Nat.cast_ofNat] at hb1_ws hx_p1
  set ws_p1 := WordStore.empty.write (.heap 0 4) (M_e : ℤ)
  have hleaf_p2 : BoundedLeaf inpBit L_max ws_p1 (.extraRatNum (.lit 0)) b.num :=
    ⟨hbnum_ib, 2, 2 + intBitLength b.num,
      by simp [evalIntExpr, inpBit, listGetIntD, intBitLength], le_rfl, by omega⟩
  obtain ⟨hb2_ws, hx_p2⟩ := execWriteLeaf hL8 hSbit hb1_ws (j := 5) (by omega) hleaf_p2
  simp only [Nat.cast_ofNat] at hb2_ws hx_p2
  set ws_p2 := ws_p1.write (.heap 0 5) b.num
  have hleaf_p3 : BoundedLeaf inpBit L_max ws_p2 (.extraRatDen (.lit 0)) (b_den : ℤ) :=
    ⟨hbden_ib, 2, 2 + intBitLength (b_den : ℤ),
      by simp [evalIntExpr, inpBit, listGetIntD, intBitLength, b_den], le_rfl, by omega⟩
  obtain ⟨hb3_ws, hx_p3⟩ := execWriteLeaf hL8 hSbit hb2_ws (j := 6) (by omega) hleaf_p3
  simp only [Nat.cast_ofNat] at hb3_ws hx_p3
  set ws_init := ws_p2.write (.heap 0 6) (b_den : ℤ)
  have hx_preBit : ExecBit inpBit preBitProg WordStore.empty ws_init
      30 (12 * L_max ^ 2) 20 S_bit :=
    (ExecBit.seq hx_p1 (ExecBit.seq hx_p2 hx_p3)).mono (by omega) (by ring_nf; exact le_rfl)
  -- Execute coreProg from ws_init
  have hw4 : ws_init.read (hLoc 4) = (M_e : ℤ) := by
    dsimp [hLoc]
    rw [ws_read_write_of_ne _ _ (by omega), ws_read_write_of_ne _ _ (by omega), ws_read_write_self]
  have hw5 : ws_init.read (hLoc 5) = (b_num : ℤ) := by
    dsimp [hLoc]
    rw [ws_read_write_of_ne _ _ (by omega), ws_read_write_self, hb_num_z]
  have hw6 : ws_init.read (hLoc 6) = (b_den : ℤ) := by
    dsimp [hLoc]
    rw [ws_read_write_self]
  obtain ⟨ws_f, hb_f, hf0, hf1, hf2, hf3, hx_core⟩ :=
    exec_coreProg hMe16 hb_den_pos hb_num_le_den hMbits8 hTOP_lt hSbit hb3_ws hw4 hw5 hw6
  simp only [hLoc, Nat.cast_zero, Nat.cast_one, Nat.cast_ofNat] at hf0 hf1 hf2 hf3
  set K : ℕ := l56TargetK M_e
  have hK_le_6S : K ≤ 6 * S := by dsimp [S]; omega
  -- Halting outcome for l56ProgBit
  have hx_fullBit := ExecBit.seq hx_preBit hx_core
  obtain ⟨outBit, hrunBit, houtB_ws, houtB_u, houtB_b, houtB_pc, houtB_pb⟩ :=
    hx_fullBit.to_run (by dsimp [S_bit]; omega)
  -- Halting outcome for l56ProgArith via preArithProg + pureHeapFuel_sim
  have hceil_z : ((e.den : ℤ) + e.num - 1) / e.num = (M_e : ℤ) := l56_int_ceil_inv_eq he0
  let ceilExpr : IntExpr :=
    .div (.sub (.add (.intParam (.lit 3)) (.intParam (.lit 2))) (.lit 1)) (.intParam (.lit 2))
  set ev1 := evalIntExpr inpArith.toWordView 0 ArithRAMMemory.empty.words ceilExpr with hev1_def
  have hev1_fst : ev1.1 = (M_e : ℤ) := by
    simp [hev1_def, ceilExpr, evalIntExpr, inpArith, ArithRAMInput.toWordView, listGetIntD, hceil_z]
  have hev1_u : ev1.2.1 ≤ 12 := by
    simp [hev1_def, ceilExpr, evalIntExpr, inpArith, ArithRAMInput.toWordView, listGetIntD]
  have ha1_ev : evalIntExpr inpArith.toWordView 0 ArithRAMMemory.empty.words ceilExpr =
      ((M_e : ℤ), ev1.2.1, ev1.2.2) := by
    rw [← hev1_def, ← hev1_fst]
  have hx_a1 : ExecStmt inpArith (.writeWordHeap 0 (.lit 4) ceilExpr)
      ArithRAMMemory.empty (wWrite ArithRAMMemory.empty 0 4 (M_e : ℤ)) 15 :=
    ExecStmt.writeWordHeap inpArith cleanMem_empty 0 (.lit 4) ceilExpr rfl ha1_ev (by omega)
  set mem_a1 := wWrite ArithRAMMemory.empty 0 4 (M_e : ℤ)
  have ha2_ev : evalIntExpr inpArith.toWordView 0 mem_a1.words (.intParam (.lit 0)) =
      (b.num, 2, 2 + intBitLength b.num) := by
    simp [evalIntExpr, inpArith, ArithRAMInput.toWordView, listGetIntD, intBitLength]
  have hx_a2 : ExecStmt inpArith (.writeWordHeap 0 (.lit 5) (.intParam (.lit 0)))
      mem_a1 (wWrite mem_a1 0 5 b.num) 10 :=
    ExecStmt.writeWordHeap inpArith hx_a1.2.1 0 (.lit 5) _ rfl ha2_ev (by omega)
  set mem_a2 := wWrite mem_a1 0 5 b.num
  set ev3 := evalIntExpr inpArith.toWordView 0 mem_a2.words (.intParam (.lit 1)) with hev3_def
  have hev3_fst : ev3.1 = (b_den : ℤ) := by
    simp [hev3_def, evalIntExpr, inpArith, ArithRAMInput.toWordView, listGetIntD, b_den]
  have hev3_u : ev3.2.1 = 2 := by
    simp [hev3_def, evalIntExpr, inpArith, ArithRAMInput.toWordView, listGetIntD]
  have ha3_ev : evalIntExpr inpArith.toWordView 0 mem_a2.words (.intParam (.lit 1)) =
      ((b_den : ℤ), 2, ev3.2.2) := by
    rw [← hev3_def, ← hev3_fst, ← hev3_u]
  have hx_a3 : ExecStmt inpArith (.writeWordHeap 0 (.lit 6) (.intParam (.lit 1)))
      mem_a2 (wWrite mem_a2 0 6 (b_den : ℤ)) 10 :=
    ExecStmt.writeWordHeap inpArith hx_a2.2.1 0 (.lit 6) _ rfl ha3_ev (by omega)
  have hmem_init_eq : wWrite mem_a2 0 6 (b_den : ℤ) =
      { words := ws_init, reals := RealStore.empty } := rfl
  have hx_preArith : ExecStmt inpArith preArithProg ArithRAMMemory.empty
      { words := ws_init, reals := RealStore.empty } 35 := by
    rw [← hmem_init_eq]
    exact ExecStmt.seq hx_a1 (ExecStmt.seq hx_a2 hx_a3)
  -- Chain preArithProg with pureHeapFuel_sim on coreProg
  rcases hx_preArith.2.2 0 [.stmt (bitStmtToArith coreProg)] with
    ⟨f_pre, u_pre, hu_pre, hstep_pre⟩
  rcases hx_core.2.2 u_pre 0 ws_init.cellCount 0 [] with
    ⟨f_core, u_end, b_end, mc_end, pb_end, hu_end, _, hmc_end, _, hstep_core⟩
  have hbit_halt : runBitRAMFuel inpBit (f_core + 1) [.stmt coreProg]
      (mkBitState inpBit ws_init u_pre 0 ws_init.cellCount 0) =
      .halted
        { words := ws_f
          unitCost := u_end
          bitCost := b_end
          peakCellSpace := inpBit.inputCellSpace + mc_end
          peakBitSpace := pb_end } := by
    rw [hstep_core 1]
    dsimp [runBitRAMFuel, mkBitState]
    rw [hb_f.1]
  have hpure_stack : ∀ item ∈ ([BitRAMCont.stmt coreProg] : List BitRAMCont),
      PureHeapCont item = true := by
    intro item hmem
    rcases List.mem_singleton.mp hmem with rfl
    exact coreProg_pure
  obtain ⟨mc', hmc'_eq, harith_core⟩ := pureHeapFuel_sim inpBit inpArith (f_core + 1)
    [.stmt coreProg] ws_init u_pre 0 ws_init.cellCount 0 _ hpure_stack hbit_halt
  dsimp only at hmc'_eq
  have hmc'_val : mc' = mc_end := Nat.add_left_cancel hmc'_eq.symm
  have hcell_init_eq : ({ words := ws_init, reals := RealStore.empty } : ArithRAMMemory).cellCount =
      ws_init.cellCount := by
    simp [ArithRAMMemory.cellCount, RealStore.cellCount, RealStore.empty]
  let outArith : ArithRAMExecOutcome :=
    { mem := { words := ws_f, reals := RealStore.empty }
      unitCost := u_end
      peakCellSpace := inpArith.inputCellSpace + mc' }
  have hrunArith : runArithRAMWithBits l56ProgArith inpArith ArithRAMMemory.empty [] =
      some outArith := by
    apply runArithRAMWithBits_eq_some_of_fuel l56ProgArith inpArith ArithRAMMemory.empty []
      (1 + f_pre + (f_core + 1)) outArith
    rw [cleanMem_empty]
    have hfuel_split : 1 + f_pre + (f_core + 1) = (f_pre + (f_core + 1)) + 1 := by omega
    rw [hfuel_split]
    have hstep1 : runArithRAMFuel inpArith ((f_pre + (f_core + 1)) + 1) [.stmt l56ProgArith]
        (mkState inpArith ArithRAMMemory.empty 0) =
      runArithRAMFuel inpArith (f_pre + (f_core + 1))
        [.stmt preArithProg, .stmt (bitStmtToArith coreProg)]
        (mkState inpArith ArithRAMMemory.empty 0) := rfl
    change runArithRAMFuel inpArith ((f_pre + (f_core + 1)) + 1) [.stmt l56ProgArith]
        (mkState inpArith ArithRAMMemory.empty 0) = .halted outArith
    rw [hstep1, hstep_pre (f_core + 1)]
    dsimp only [mkState]
    rw [hcell_init_eq]
    simpa [List.map_singleton, bitContToArith, outArith] using harith_core
  -- Bound all costs and spaces by bound = 1000000 * S ^ 3 via poly_cube_bounds
  have hws_init_cc : ws_init.cellCount ≤ 20 := heapBounded_cellCount hb3_ws
  have hinpA_cell : inpArith.inputCellSpace = 4 := by
    simp [inpArith, ArithRAMInput.inputCellSpace]
  have hLb_le_S : L_b ≤ S := by dsimp [S]; omega
  have hpb_1000 : outBit.peakBitSpace ≤ 1000 * S := by
    have : S_bit ≤ 1000 * S := by dsimp [S_bit]; omega
    omega
  have houtB_b' : outBit.bitCost ≤ 12 * L_max ^ 2 + (72 + 56 * K) * L_max ^ 2 := houtB_b
  have houtB_pc' : outBit.peakCellSpace ≤ 23 := by omega
  have houtA_u' : outArith.unitCost ≤ 35 + (180 + 140 * K) := by
    change u_end ≤ 35 + (180 + 140 * K); omega
  have houtA_pc' : outArith.peakCellSpace ≤ 24 := by
    have hmc20 : mc_end ≤ 20 := by
      have hcc : ws_init.cellCount ≤ 20 := hws_init_cc
      omega
    change inpArith.inputCellSpace + mc' ≤ 24
    omega
  obtain ⟨hU_bound, hB_bound, hPC_bound, hPB_bound, hAu_bound, hApc_bound⟩ :=
    poly_cube_bounds hS1 hK_le_6S hLmax_le
      houtB_u houtB_b' houtB_pc' hpb_1000 houtA_u' houtA_pc'
  refine ⟨outBit, outArith, hrunBit, hU_bound, hB_bound, hPC_bound, hPB_bound,
    hrunArith, hAu_bound, hApc_bound, ?_, ?_, ?_, ?_, hf0, hf1, hf2, hf3⟩
  · rw [houtB_ws, hf0]
  · rw [houtB_ws, hf1]
  · rw [houtB_ws, hf2]
  · rw [houtB_ws, hf3]

end UL.Proof_lem_5_6
