import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_paraboloid_lift_variance
set_option autoImplicit false

namespace UL.Proof_lem_5_6

/-- Exact halting exponent `K` of `k := 1; p := 2; while p < 16 * M_e do { k := k + 1; p := 2 * p }`. -/
def l56TargetK (M_e : ℕ) : ℕ :=
  Nat.log 2 (16 * M_e - 1) + 1

/-- Exact integer comparison `4 * mid^2 * N^2 * (b_den * M_e) < (b_num * M_e + 2 * b_den) * (N^2 - mid^2)^2`. -/
def l56CondNat (M_e b_num b_den N mid : ℕ) : Bool :=
  decide (4 * mid ^ 2 * N ^ 2 * (b_den * M_e) <
    (b_num * M_e + 2 * b_den) * (N ^ 2 - mid ^ 2) ^ 2)

/-- One step of the binary search on `[0, P]` with denominator `N = 2 * P`. -/
def l56Step (M_e b_num b_den P : ℕ) (lh : ℕ × ℕ) : ℕ × ℕ :=
  let mid := (lh.1 + lh.2) / 2
  if l56CondNat M_e b_num b_den (2 * P) mid then (mid, lh.2) else (lh.1, mid)

/-- `s` iterations of binary search starting from `(0, P)`. -/
def l56Iter (M_e b_num b_den P : ℕ) : ℕ → ℕ × ℕ
  | 0 => (0, P)
  | s + 1 => l56Step M_e b_num b_den P (l56Iter M_e b_num b_den P s)

/-- Final `(A_num, A_den, B_num, B_den)` output on `(M_e, b_num, b_den)`. -/
def l56ComputeAB (M_e b_num b_den : ℕ) : ℕ × ℕ × ℕ × ℕ :=
  let K := l56TargetK M_e
  let P := 2 ^ K
  let N := 2 * P
  let hi := (l56Iter M_e b_num b_den P K).2
  (N ^ 2 - hi ^ 2, N ^ 2 + hi ^ 2, 2 * N * hi, N ^ 2 + hi ^ 2)

theorem l56TargetK_spec {M_e : ℕ} (hM : 16 ≤ M_e) :
    1 ≤ l56TargetK M_e ∧
    (∀ i < l56TargetK M_e - 1, 2 ^ (1 + i) < 16 * M_e) ∧
    16 * M_e ≤ 2 ^ l56TargetK M_e ∧
    2 ^ l56TargetK M_e < 32 * M_e := by
  have hm0 : 16 * M_e - 1 ≠ 0 := by omega
  have hp_le : 2 ^ Nat.log 2 (16 * M_e - 1) ≤ 16 * M_e - 1 :=
    Nat.pow_log_le_self 2 hm0
  have hp_gt : 16 * M_e - 1 < 2 ^ (Nat.log 2 (16 * M_e - 1) + 1) :=
    Nat.lt_pow_succ_log_self (by norm_num) (16 * M_e - 1)
  refine ⟨by unfold l56TargetK; omega, ?_, ?_, ?_⟩
  · intro i hi
    have hi_le : 1 + i ≤ Nat.log 2 (16 * M_e - 1) := by
      unfold l56TargetK at hi
      omega
    have hpow : 2 ^ (1 + i) ≤ 2 ^ Nat.log 2 (16 * M_e - 1) :=
      Nat.pow_le_pow_right (by norm_num) hi_le
    omega
  · unfold l56TargetK
    omega
  · unfold l56TargetK
    rw [pow_succ]
    omega

theorem l56_exp_one_le_four : Real.exp 1 ≤ 4 := by
  have h1 : (1 / 2 : ℝ) ≤ Real.exp (-1 / 2) := by
    linarith [Real.add_one_le_exp (-1 / 2 : ℝ)]
  have h2 : Real.exp (1 / 2) * Real.exp (-1 / 2) = 1 := by
    rw [← Real.exp_add]
    norm_num
  have h3 : Real.exp (1 / 2) ≤ 2 := by
    nlinarith [Real.exp_pos (1 / 2 : ℝ)]
  have h4 : Real.exp 1 = Real.exp (1 / 2) * Real.exp (1 / 2) := by
    rw [← Real.exp_add]
    norm_num
  nlinarith [Real.exp_pos (1 / 2 : ℝ)]

theorem l56_exp_nat_le_four_pow : ∀ n : ℕ, Real.exp (n : ℝ) ≤ (4 : ℝ) ^ n
  | 0 => by simp
  | n + 1 => by
      push_cast
      rw [Real.exp_add, pow_succ]
      have ih := l56_exp_nat_le_four_pow n
      have hexp1 := l56_exp_one_le_four
      have hpos : 0 < Real.exp (n : ℝ) := Real.exp_pos _
      nlinarith

theorem l56_ceil_inv_e_bounds {e : ℚ} (he0 : 0 < e) (he16 : (e : ℝ) ≤ 1 / 16) :
    16 ≤ Nat.ceil (1 / e) ∧
    Nat.ceil (1 / e) ≤ 2 ^ (2 * Nat.ceil (Real.log (1 / (e : ℝ)))) ∧
    l56TargetK (Nat.ceil (1 / e)) ≤ 2 * Nat.ceil (Real.log (1 / (e : ℝ))) + 4 ∧
    (e : ℝ) < 2 / (Nat.ceil (1 / e) : ℝ) ∧
    1 / (Nat.ceil (1 / e) : ℝ) ≤ (e : ℝ) := by
  set M_e := Nat.ceil (1 / e)
  set L_e := Nat.ceil (Real.log (1 / (e : ℝ)))
  have he0_r : (0 : ℝ) < (e : ℝ) := by exact_mod_cast he0
  have hinv16 : (16 : ℝ) ≤ 1 / (e : ℝ) := by
    rw [le_div_iff₀ he0_r]
    linarith
  have hMe_ge_q : 1 / e ≤ (M_e : ℚ) := Nat.le_ceil _
  have hMe_ge_r : 1 / (e : ℝ) ≤ (M_e : ℝ) := by
    have h := Rat.cast_le (K := ℝ).mpr hMe_ge_q
    simpa using h
  have hMe16_r : (16 : ℝ) ≤ (M_e : ℝ) := hinv16.trans hMe_ge_r
  have hMe16 : 16 ≤ M_e := by exact_mod_cast hMe16_r
  have hMe_pos_r : (0 : ℝ) < (M_e : ℝ) := by linarith
  have hMe_lt_q : (M_e : ℚ) < 1 / e + 1 := Nat.ceil_lt_add_one (by positivity)
  have hMe_lt_r : (M_e : ℝ) < 1 / (e : ℝ) + 1 := by
    have h := Rat.cast_lt (K := ℝ).mpr hMe_lt_q
    simpa using h
  have h1Me_le_e : 1 / (M_e : ℝ) ≤ (e : ℝ) := by
    rw [div_le_iff₀ hMe_pos_r]
    have h := (div_le_iff₀ he0_r).mp hMe_ge_r
    linarith
  have he_lt_2Me : (e : ℝ) < 2 / (M_e : ℝ) := by
    rw [lt_div_iff₀ hMe_pos_r]
    have h1 : (e : ℝ) * (M_e : ℝ) < (e : ℝ) * (1 / (e : ℝ) + 1) :=
      mul_lt_mul_of_pos_left hMe_lt_r he0_r
    have h2 : (e : ℝ) * (1 / (e : ℝ) + 1) = 1 + (e : ℝ) := by
      field_simp [he0_r.ne']
    linarith
  have hlog_le : Real.log (1 / (e : ℝ)) ≤ (L_e : ℝ) := Nat.le_ceil _
  have hinv_pos : (0 : ℝ) < 1 / (e : ℝ) := by positivity
  have hinv_le_exp : 1 / (e : ℝ) ≤ Real.exp (L_e : ℝ) := by
    rw [← Real.exp_log hinv_pos]
    exact Real.exp_le_exp.mpr hlog_le
  have hexp_le_pow : Real.exp (L_e : ℝ) ≤ (2 : ℝ) ^ (2 * L_e) := by
    calc
      Real.exp (L_e : ℝ) ≤ (4 : ℝ) ^ L_e := l56_exp_nat_le_four_pow L_e
      _ = (2 : ℝ) ^ (2 * L_e) := by
        rw [pow_mul]
        norm_num
  have hinv_le_pow_q : 1 / e ≤ ((2 ^ (2 * L_e) : ℕ) : ℚ) := by
    have hcast : ((1 / e : ℚ) : ℝ) ≤ (((2 ^ (2 * L_e) : ℕ) : ℚ) : ℝ) := by
      simpa using hinv_le_exp.trans hexp_le_pow
    exact Rat.cast_le.mp hcast
  have hMe_le_pow : M_e ≤ 2 ^ (2 * L_e) := Nat.ceil_le.mpr hinv_le_pow_q
  have hK_le : l56TargetK M_e ≤ 2 * L_e + 4 := by
    have hlt_pow : 16 * M_e - 1 < 2 ^ (2 * L_e + 4) := by
      have h16 : 2 ^ (2 * L_e + 4) = 16 * 2 ^ (2 * L_e) := by ring
      omega
    have hlog_lt : Nat.log 2 (16 * M_e - 1) < 2 * L_e + 4 :=
      Nat.log_lt_of_lt_pow (by omega) hlt_pow
    unfold l56TargetK
    omega
  exact ⟨hMe16, hMe_le_pow, hK_le, he_lt_2Me, h1Me_le_e⟩

theorem l56_int_ceil_inv_eq {e : ℚ} (he0 : 0 < e) :
    ((e.den : ℤ) + e.num - 1) / e.num = (Nat.ceil (1 / e) : ℤ) := by
  set p : ℤ := e.num
  set q : ℤ := (e.den : ℤ)
  have hp : 0 < p := Rat.num_pos.mpr he0
  have hq : 0 < q := Int.natCast_pos.mpr e.pos
  set m : ℤ := (q + p - 1) / p
  have hdiv_mod := Int.mul_ediv_add_emod (q + p - 1) p
  have hmod_nn : 0 ≤ (q + p - 1) % p := Int.emod_nonneg _ hp.ne'
  have hmod_lt : (q + p - 1) % p < p := Int.emod_lt_of_pos _ hp
  have hm_bounds : p * (m - 1) < q ∧ q ≤ p * m := by
    have h1 : p * ((q + p - 1) / p) + (q + p - 1) % p = q + p - 1 := hdiv_mod
    have hm_def : (q + p - 1) / p = m := rfl
    rw [hm_def] at h1
    constructor <;> nlinarith
  have hm_pos : 1 ≤ m := by nlinarith
  let m_nat : ℕ := m.toNat
  have hm_nat_eq : (m_nat : ℤ) = m := Int.toNat_of_nonneg (by omega)
  have h1e_eq : 1 / e = (q : ℚ) / (p : ℚ) := by
    have he_eq : e = (p : ℚ) / (q : ℚ) := (Rat.num_div_den e).symm
    rw [he_eq, one_div_div]
  have hp_q : (0 : ℚ) < (p : ℚ) := by exact_mod_cast hp
  have hceil_le : Nat.ceil (1 / e) ≤ m_nat := by
    rw [Nat.ceil_le, h1e_eq, div_le_iff₀ hp_q]
    have hle_z : q ≤ m * p := by linarith [hm_bounds.2]
    rw [← hm_nat_eq] at hle_z
    exact_mod_cast hle_z
  have hceil_ge : m_nat ≤ Nat.ceil (1 / e) := by
    by_contra hlt
    push_neg at hlt
    set c : ℕ := Nat.ceil (1 / e)
    have h1 : (q : ℚ) / (p : ℚ) ≤ (c : ℚ) := by
      rw [← h1e_eq]
      exact Nat.le_ceil (1 / e)
    rw [div_le_iff₀ hp_q] at h1
    have h2 : q ≤ (c : ℤ) * p := by exact_mod_cast h1
    have hle_m1 : (c : ℤ) ≤ m - 1 := by omega
    nlinarith [hm_bounds.1]
  have h_eq_nat : Nat.ceil (1 / e) = m_nat := le_antisymm hceil_le hceil_ge
  rw [h_eq_nat, hm_nat_eq]

theorem l56Iter_inv {M_e b_num b_den : ℕ}
    (hM : 16 ≤ M_e) (hden : 1 ≤ b_den) (hb_le : b_num ≤ b_den) :
    let K := l56TargetK M_e
    let P := 2 ^ K
    let N := 2 * P
    ∀ s ≤ K,
      let lh := l56Iter M_e b_num b_den P s
      lh.2 = lh.1 + 2 ^ (K - s) ∧
      lh.2 ≤ P ∧
      4 * lh.1 ^ 2 * N ^ 2 * (b_den * M_e) <
        (b_num * M_e + 2 * b_den) * (N ^ 2 - lh.1 ^ 2) ^ 2 ∧
      (b_num * M_e + 2 * b_den) * (N ^ 2 - lh.2 ^ 2) ^ 2 ≤
        4 * lh.2 ^ 2 * N ^ 2 * (b_den * M_e) := by
  intro K P N s
  induction s with
  | zero =>
      intro _
      dsimp [l56Iter]
      have hP_pos : 1 ≤ P := Nat.one_le_pow K 2 (by norm_num)
      have hN_pos : 2 ≤ N := by dsimp [N]; omega
      refine ⟨by simp [P], le_rfl, ?_, ?_⟩
      · simp only [sq, zero_mul]
        positivity
      · have hN2_sub : N ^ 2 - P ^ 2 = 3 * P ^ 2 := by
          have hN2 : N ^ 2 = 4 * P ^ 2 := by dsimp [N]; ring
          omega
        rw [hN2_sub]
        have h1 : (b_num * M_e + 2 * b_den) * (3 * P ^ 2) ^ 2 =
            9 * (b_num * M_e + 2 * b_den) * P ^ 4 := by ring
        have h2 : 4 * P ^ 2 * N ^ 2 * (b_den * M_e) =
            16 * (b_den * M_e) * P ^ 4 := by dsimp [N]; ring
        rw [h1, h2]
        refine Nat.mul_le_mul_right (P ^ 4) ?_
        have hbm : b_num * M_e ≤ b_den * M_e := Nat.mul_le_mul_right M_e hb_le
        nlinarith
  | succ s ih =>
      intro hs
      obtain ⟨hdiff, hhiP, hlo_lt, hhi_ge⟩ := ih (by omega)
      set lh := l56Iter M_e b_num b_den P s
      have hKs : K - s = (K - (s + 1)) + 1 := by omega
      have hpow : 2 ^ (K - s) = 2 * 2 ^ (K - (s + 1)) := by
        rw [hKs, pow_succ']
      set stepPow := 2 ^ (K - (s + 1))
      have hmid_eq : (lh.1 + lh.2) / 2 = lh.1 + stepPow := by omega
      have hhi_mid : lh.2 = (lh.1 + stepPow) + stepPow := by omega
      dsimp only [l56Iter, l56Step]
      rw [hmid_eq]
      cases hcond : l56CondNat M_e b_num b_den (2 * P) (lh.1 + stepPow)
      · simp only [Bool.false_eq_true, ↓reduceIte]
        have hge : (b_num * M_e + 2 * b_den) * (N ^ 2 - (lh.1 + stepPow) ^ 2) ^ 2 ≤
            4 * (lh.1 + stepPow) ^ 2 * N ^ 2 * (b_den * M_e) := by
          unfold l56CondNat at hcond
          have hnot := of_decide_eq_false hcond
          dsimp [N]
          omega
        exact ⟨rfl, by omega, hlo_lt, hge⟩
      · simp only [↓reduceIte]
        have hlt : 4 * (lh.1 + stepPow) ^ 2 * N ^ 2 * (b_den * M_e) <
            (b_num * M_e + 2 * b_den) * (N ^ 2 - (lh.1 + stepPow) ^ 2) ^ 2 := by
          unfold l56CondNat at hcond
          exact of_decide_eq_true hcond
        exact ⟨hhi_mid, hhiP, hlt, hhi_ge⟩

theorem l56_lipschitz {u v : ℝ} (hu0 : 0 ≤ u) (huv : u ≤ v) (hv : v ≤ 1 / 2) :
    (2 * v / (1 - v ^ 2)) ^ 2 - (2 * u / (1 - u ^ 2)) ^ 2 ≤ 16 * (v - u) := by
  set du : ℝ := 1 - u ^ 2
  set dv : ℝ := 1 - v ^ 2
  have hdu34 : 3 / 4 ≤ du := by dsimp [du]; nlinarith
  have hdv34 : 3 / 4 ≤ dv := by dsimp [dv]; nlinarith
  have hdu_pos : 0 < du := by linarith
  have hdv_pos : 0 < dv := by linarith
  set gu : ℝ := 2 * u / du
  set gv : ℝ := 2 * v / dv
  have hgu_nn : 0 ≤ gu := div_nonneg (by linarith) hdu_pos.le
  have hgv_nn : 0 ≤ gv := div_nonneg (by linarith) hdv_pos.le
  have hgu_hi : gu ≤ 4 / 3 := by
    dsimp [gu]
    rw [div_le_div_iff₀ hdu_pos (by norm_num)]
    linarith
  have hgv_hi : gv ≤ 4 / 3 := by
    dsimp [gv]
    rw [div_le_div_iff₀ hdv_pos (by norm_num)]
    linarith
  have hdiff : gv - gu = 2 * (v - u) * (1 + u * v) / (dv * du) := by
    have h1 : (gv - gu) * (dv * du) = 2 * (v - u) * (1 + u * v) := by
      calc
        (gv - gu) * (dv * du)
            = (2 * v / dv) * dv * du - (2 * u / du) * du * dv := by dsimp [gu, gv]; ring
        _ = 2 * v * du - 2 * u * dv := by
              rw [div_mul_cancel₀ _ hdv_pos.ne', div_mul_cancel₀ _ hdu_pos.ne']
        _ = 2 * (v - u) * (1 + u * v) := by dsimp [du, dv]; ring
    exact eq_div_of_mul_eq (mul_pos hdv_pos hdu_pos).ne' h1
  have hdiff_le : gv - gu ≤ 5 * (v - u) := by
    rw [hdiff, div_le_iff₀ (mul_pos hdv_pos hdu_pos)]
    have h1uv : 1 + u * v ≤ 5 / 4 := by nlinarith
    have hdvdu : 9 / 16 ≤ dv * du := by nlinarith
    calc
      2 * (v - u) * (1 + u * v)
          ≤ 2 * (v - u) * (5 / 4) := mul_le_mul_of_nonneg_left h1uv (by linarith)
      _ ≤ 5 * (v - u) * (9 / 16) := by linarith
      _ ≤ 5 * (v - u) * (dv * du) := mul_le_mul_of_nonneg_left hdvdu (by linarith)
  have hsum_le : gv + gu ≤ 8 / 3 := by linarith
  calc
    gv ^ 2 - gu ^ 2 = (gv - gu) * (gv + gu) := by ring
    _ ≤ (5 * (v - u)) * (8 / 3) :=
        mul_le_mul hdiff_le hsum_le (by linarith) (by linarith)
    _ ≤ 16 * (v - u) := by linarith

private theorem l56_inner_liftedPoint {d : ℕ}
    (u v : EuclideanSpace ℝ (Fin d)) (s t : ℝ) :
    inner ℝ (UL.liftedPoint u s) (UL.liftedPoint v t) = inner ℝ u v + s * t := by
  rw [PiLp.inner_apply, Fin.sum_univ_castSucc, PiLp.inner_apply]
  congr 1
  · refine Finset.sum_congr rfl (fun i _ => ?_)
    simp [UL.liftedPoint]
  · simp [UL.liftedPoint, mul_comm]

private theorem l56_pad_norm_eq_one {d : ℕ} {A_r s : ℝ}
    (v : EuclideanSpace ℝ (Fin d)) (hv : ‖v‖ = 1) (hAs : A_r ^ 2 + s ^ 2 = 1) :
    ‖UL.liftedPoint (A_r • v) s‖ = 1 := by
  have hsq : ‖UL.liftedPoint (A_r • v) s‖ ^ 2 = 1 := by
    rw [← real_inner_self_eq_norm_sq, l56_inner_liftedPoint, real_inner_self_eq_norm_sq,
      norm_smul, Real.norm_eq_abs, hv, mul_one, sq_abs]
    linear_combination hAs
  have hnn : 0 ≤ ‖UL.liftedPoint (A_r • v) s‖ := norm_nonneg _
  nlinarith

private theorem l56_pad_inner_eq {d : ℕ} {A_r B_r : ℝ}
    (u z z_hat : EuclideanSpace ℝ (Fin d)) :
    inner ℝ (UL.liftedPoint (A_r • z_hat) (-B_r)) (UL.liftedPoint (A_r • u) B_r) =
      A_r ^ 2 * inner ℝ z u - B_r ^ 2 + A_r ^ 2 * inner ℝ (z_hat - z) u := by
  rw [l56_inner_liftedPoint, inner_smul_left, inner_smul_right, RCLike.conj_to_real]
  have hzh : inner ℝ z_hat u = inner ℝ z u + inner ℝ (z_hat - z) u := by
    rw [inner_sub_left]
    ring
  rw [hzh]
  ring

private theorem l56_corr_real_bounds
    {a_r b_r g e_r A_r B_r s err : ℝ}
    (hb0 : 0 ≤ b_r) (ha1 : a_r ≤ 1)
    (hg0 : 0 < g) (hg_gap : g ≤ a_r - (1 + g) * b_r)
    (he0 : 0 < e_r) (he_le : e_r ≤ g / 16)
    (hA0 : 0 < A_r) (hAB : A_r ^ 2 + B_r ^ 2 = 1)
    (ht_lo : b_r + e_r < B_r ^ 2 / A_r ^ 2)
    (ht_hi : B_r ^ 2 / A_r ^ 2 < b_r + 5 * e_r)
    (herr : |err| ≤ e_r / 8) :
    (a_r ≤ s → g - 11 * e_r ≤ A_r ^ 2 * s - B_r ^ 2 + A_r ^ 2 * err) ∧
    (s ≤ b_r → A_r ^ 2 * s - B_r ^ 2 + A_r ^ 2 * err < 0) := by
  have hA2_pos : 0 < A_r ^ 2 := sq_pos_of_pos hA0
  obtain ⟨Δ, hB2_eq, hΔ_lo, hΔ_hi⟩ :
      ∃ Δ : ℝ, B_r ^ 2 = (b_r + Δ) * A_r ^ 2 ∧ e_r < Δ ∧ Δ < 5 * e_r := by
    refine ⟨B_r ^ 2 / A_r ^ 2 - b_r, ?_, by linarith, by linarith⟩
    have hmul : (B_r ^ 2 / A_r ^ 2) * A_r ^ 2 = B_r ^ 2 := div_mul_cancel₀ _ hA2_pos.ne'
    linarith
  have hg1 : g ≤ 1 := by
    have : 0 ≤ (1 + g) * b_r := mul_nonneg (by linarith) hb0
    linarith
  have hb_le_1mg : b_r ≤ 1 - g := by
    have : 0 ≤ g * b_r := mul_nonneg hg0.le hb0
    linarith
  have h1t_pos : 0 < 1 + b_r + Δ := by linarith
  have h1t_lt2 : 1 + b_r + Δ < 2 := by linarith
  have hA2_sum : A_r ^ 2 * (1 + b_r + Δ) = 1 := by
    linear_combination hAB - hB2_eq
  have hA2_eq : A_r ^ 2 = 1 / (1 + b_r + Δ) :=
    eq_div_of_mul_eq h1t_pos.ne' hA2_sum
  have hA2_le1 : A_r ^ 2 ≤ 1 := by nlinarith [sq_nonneg B_r]
  have herr_lo : -(e_r / 8) ≤ A_r ^ 2 * err := by
    have h1 : -(e_r / 8) ≤ err := (abs_le.mp herr).1
    nlinarith
  have herr_hi : A_r ^ 2 * err ≤ e_r / 8 := by
    have h1 : err ≤ e_r / 8 := (abs_le.mp herr).2
    nlinarith
  have hmain_eq : A_r ^ 2 * s - B_r ^ 2 = (s - b_r - Δ) / (1 + b_r + Δ) := by
    rw [hB2_eq, hA2_eq]
    field_simp [h1t_pos.ne']
    ring
  rw [hmain_eq]
  constructor
  · intro ha_le
    have hnum_ge : g * (1 + b_r + Δ) - (1 + g) * Δ ≤ s - b_r - Δ := by linarith
    have hdiv_ge : g - (1 + g) * Δ / (1 + b_r + Δ) ≤ (s - b_r - Δ) / (1 + b_r + Δ) := by
      have h1 : (g * (1 + b_r + Δ) - (1 + g) * Δ) / (1 + b_r + Δ) =
          g - (1 + g) * Δ / (1 + b_r + Δ) := by
        field_simp [h1t_pos.ne']
      rw [← h1]
      exact div_le_div_of_nonneg_right hnum_ge h1t_pos.le
    have hpen_le : (1 + g) * Δ / (1 + b_r + Δ) ≤ 2 * Δ := by
      rw [div_le_iff₀ h1t_pos]
      nlinarith
    linarith
  · intro hb_ge
    have hnum_le : s - b_r - Δ ≤ -Δ := by linarith
    have hdiv_le : (s - b_r - Δ) / (1 + b_r + Δ) < -Δ / 2 := by
      have h1 : (s - b_r - Δ) / (1 + b_r + Δ) ≤ -Δ / (1 + b_r + Δ) :=
        div_le_div_of_nonneg_right hnum_le h1t_pos.le
      have h2 : -Δ / (1 + b_r + Δ) < -Δ / 2 := by
        rw [div_lt_div_iff₀ h1t_pos (by norm_num)]
        nlinarith
      exact h1.trans_lt h2
    linarith

theorem l56_padded_corr_bounds
    {a_r b_r g e_r A_r B_r : ℝ}
    (hb0 : 0 ≤ b_r) (ha1 : a_r ≤ 1)
    (hg0 : 0 < g) (hg_gap : g ≤ a_r - (1 + g) * b_r)
    (he0 : 0 < e_r) (he_le : e_r ≤ g / 16)
    (hA0 : 0 < A_r) (hAB : A_r ^ 2 + B_r ^ 2 = 1)
    (ht_lo : b_r + e_r < B_r ^ 2 / A_r ^ 2)
    (ht_hi : B_r ^ 2 / A_r ^ 2 < b_r + 5 * e_r)
    (d : ℕ) (u z z_hat : EuclideanSpace ℝ (Fin d))
    (hu : ‖u‖ = 1) (hz : ‖z‖ = 1) (hzh : ‖z_hat‖ = 1)
    (hdist : ‖z_hat - z‖ ≤ e_r / 8) :
    let padQuery := UL.liftedPoint (A_r • z_hat) (-B_r)
    let padData := UL.liftedPoint (A_r • u) B_r
    ‖padQuery‖ = 1 ∧
    ‖padData‖ = 1 ∧
    (a_r ≤ inner ℝ z u → g - 11 * e_r ≤ inner ℝ padQuery padData) ∧
    (inner ℝ z u ≤ b_r → inner ℝ padQuery padData < 0) := by
  intro padQuery padData
  have _ := hz
  have hAB_neg : A_r ^ 2 + (-B_r) ^ 2 = 1 := by linear_combination hAB
  have hnorm_pq : ‖padQuery‖ = 1 := l56_pad_norm_eq_one z_hat hzh hAB_neg
  have hnorm_pd : ‖padData‖ = 1 := l56_pad_norm_eq_one u hu hAB
  have herr : |inner ℝ (z_hat - z) u| ≤ e_r / 8 := by
    calc
      |inner ℝ (z_hat - z) u| ≤ ‖z_hat - z‖ * ‖u‖ := abs_real_inner_le_norm _ _
      _ = ‖z_hat - z‖ := by rw [hu, mul_one]
      _ ≤ e_r / 8 := hdist
  have hinner : inner ℝ padQuery padData =
      A_r ^ 2 * inner ℝ z u - B_r ^ 2 + A_r ^ 2 * inner ℝ (z_hat - z) u :=
    l56_pad_inner_eq u z z_hat
  have hcorr := l56_corr_real_bounds (s := inner ℝ z u) (err := inner ℝ (z_hat - z) u)
    hb0 ha1 hg0 hg_gap he0 he_le hA0 hAB ht_lo ht_hi herr
  rw [hinner]
  exact ⟨hnorm_pq, hnorm_pd, hcorr.1, hcorr.2⟩

private theorem l56_pythag_unit {N hi : ℚ} (hden : N ^ 2 + hi ^ 2 ≠ 0) :
    ((N ^ 2 - hi ^ 2) / (N ^ 2 + hi ^ 2)) ^ 2 +
      ((2 * N * hi) / (N ^ 2 + hi ^ 2)) ^ 2 = 1 := by
  field_simp [hden]
  ring

private theorem l56_g_sq_ratio {m N : ℝ} (hN : 0 < N) (hm0 : 0 ≤ m) (hmN : m < N) :
    (2 * (m / N) / (1 - (m / N) ^ 2)) ^ 2 =
      (4 * m ^ 2 * N ^ 2) / (N ^ 2 - m ^ 2) ^ 2 := by
  have hsub_pos : 0 < N ^ 2 - m ^ 2 := by nlinarith
  have h1m_eq : 1 - (m / N) ^ 2 = (N ^ 2 - m ^ 2) / N ^ 2 := by
    rw [div_pow, sub_div' (pow_ne_zero 2 hN.ne'), one_mul]
  rw [h1m_eq]
  have hfrac : 2 * (m / N) / ((N ^ 2 - m ^ 2) / N ^ 2) =
      (2 * m * N) / (N ^ 2 - m ^ 2) := by
    have hN2 : N ^ 2 ≠ 0 := pow_ne_zero 2 hN.ne'
    field_simp [hN.ne', hN2, hsub_pos.ne']
  rw [hfrac, div_pow]
  congr 1
  ring

private theorem l56_pythag_ratio {hi N : ℝ} (hsub : N ^ 2 - hi ^ 2 ≠ 0) (hadd : N ^ 2 + hi ^ 2 ≠ 0) :
    ((2 * N * hi) / (N ^ 2 + hi ^ 2)) ^ 2 /
      ((N ^ 2 - hi ^ 2) / (N ^ 2 + hi ^ 2)) ^ 2 =
      (4 * hi ^ 2 * N ^ 2) / (N ^ 2 - hi ^ 2) ^ 2 := by
  field_simp [hsub, hadd]
  ring

private theorem l56_alg_from_bounds
    {M_e b_num b_den P lo hi : ℕ}
    (hMe16 : 16 ≤ M_e)
    (hb_den_pos : 1 ≤ b_den)
    (hP_ge : 16 * M_e ≤ P)
    (hhi_lo : hi = lo + 1)
    (hhiP : hi ≤ P)
    (hlo_lt_nat : 4 * lo ^ 2 * (2 * P) ^ 2 * (b_den * M_e) <
      (b_num * M_e + 2 * b_den) * ((2 * P) ^ 2 - lo ^ 2) ^ 2)
    (hhi_ge_nat : (b_num * M_e + 2 * b_den) * ((2 * P) ^ 2 - hi ^ 2) ^ 2 ≤
      4 * hi ^ 2 * (2 * P) ^ 2 * (b_den * M_e)) :
    let N := 2 * P
    let A_num := N ^ 2 - hi ^ 2
    let A_den := N ^ 2 + hi ^ 2
    let B_num := 2 * N * hi
    let A : ℚ := (A_num : ℚ) / (A_den : ℚ)
    let B : ℚ := (B_num : ℚ) / (A_den : ℚ)
    1 ≤ A_num ∧
    A_num ≤ A_den ∧
    1 ≤ B_num ∧
    B_num ≤ A_den ∧
    A_den < 4 * N ^ 2 ∧
    0 < A ∧
    0 ≤ B ∧
    A ^ 2 + B ^ 2 = 1 ∧
    (b_num : ℝ) / (b_den : ℝ) + 2 / (M_e : ℝ) ≤ (B : ℝ) ^ 2 / (A : ℝ) ^ 2 ∧
    (B : ℝ) ^ 2 / (A : ℝ) ^ 2 < (b_num : ℝ) / (b_den : ℝ) + 3 / (M_e : ℝ) := by
  intro N A_num A_den B_num A B
  have hhi_pos : 1 ≤ hi := by omega
  have hP_pos : 256 ≤ P := by omega
  have hhi_lt_N : hi < N := by dsimp [N]; omega
  have hlo_lt_N : lo < N := by dsimp [N]; omega
  have hhi2_lt_N2 : hi ^ 2 < N ^ 2 := by
    have h1 : hi ^ 2 ≤ P ^ 2 := Nat.pow_le_pow_left hhiP 2
    have h2 : N ^ 2 = 4 * P ^ 2 := by dsimp [N]; ring
    nlinarith
  have hlo2_lt_N2 : lo ^ 2 < N ^ 2 := by
    have hlo_le_hi : lo ≤ hi := by omega
    have h1 : lo ^ 2 ≤ hi ^ 2 := Nat.pow_le_pow_left hlo_le_hi 2
    omega
  have hAn_pos : 1 ≤ A_num := by dsimp [A_num]; omega
  have hAn_le_Ad : A_num ≤ A_den := by dsimp [A_num, A_den]; omega
  have hBn_pos : 1 ≤ B_num := by
    dsimp [B_num, N]
    nlinarith
  have hBn_le_Ad : B_num ≤ A_den := by
    dsimp [B_num, A_den]
    nlinarith [sq_nonneg ((N : ℤ) - (hi : ℤ))]
  have hAd_lt_4N2 : A_den < 4 * N ^ 2 := by
    dsimp [A_den]
    omega
  have hAd_pos_q : (0 : ℚ) < (A_den : ℚ) := by
    have : 1 ≤ A_den := le_trans hAn_pos hAn_le_Ad
    exact_mod_cast this
  have hA_pos : 0 < A := div_pos (by exact_mod_cast hAn_pos) hAd_pos_q
  have hB_nn : 0 ≤ B := div_nonneg (by positivity) hAd_pos_q.le
  have hAB_one : A ^ 2 + B ^ 2 = 1 := by
    have hA_eq : A = ((N : ℚ) ^ 2 - (hi : ℚ) ^ 2) / ((N : ℚ) ^ 2 + (hi : ℚ) ^ 2) := by
      dsimp [A, A_num, A_den]
      rw [Nat.cast_sub hhi2_lt_N2.le]
      push_cast
      rfl
    have hB_eq : B = (2 * (N : ℚ) * (hi : ℚ)) / ((N : ℚ) ^ 2 + (hi : ℚ) ^ 2) := by
      dsimp [B, B_num, A_den]
      push_cast
      rfl
    have hden_ne : (N : ℚ) ^ 2 + (hi : ℚ) ^ 2 ≠ 0 := by
      have : ((N ^ 2 + hi ^ 2 : ℕ) : ℚ) ≠ 0 := hAd_pos_q.ne'
      simpa [Nat.cast_add, Nat.cast_pow] using this
    rw [hA_eq, hB_eq]
    exact l56_pythag_unit hden_ne
  set u_pt : ℝ := (lo : ℝ) / (N : ℝ)
  set v_pt : ℝ := (hi : ℝ) / (N : ℝ)
  have hN_pos_r : (0 : ℝ) < (N : ℝ) := by
    have : 1 ≤ N := by dsimp [N]; omega
    exact_mod_cast this
  have hMe_pos_r : (0 : ℝ) < (M_e : ℝ) := by
    have : 1 ≤ M_e := by omega
    exact_mod_cast this
  have hbden_pos_r : (0 : ℝ) < (b_den : ℝ) := by exact_mod_cast hb_den_pos
  have hu0 : 0 ≤ u_pt := by positivity
  have huv : u_pt ≤ v_pt := by
    dsimp [u_pt, v_pt]
    gcongr
    omega
  have hv_half : v_pt ≤ 1 / 2 := by
    dsimp [v_pt, N]
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]
    have : (hi : ℝ) ≤ (P : ℝ) := by exact_mod_cast hhiP
    push_cast
    linarith
  have hv_sub_u : v_pt - u_pt = 1 / (N : ℝ) := by
    dsimp [v_pt, u_pt]
    rw [hhi_lo, Nat.cast_add, Nat.cast_one, add_div, add_sub_cancel_left]
  have hN2_sub_hi_pos : (0 : ℝ) < (N : ℝ) ^ 2 - (hi : ℝ) ^ 2 := by
    have : (hi ^ 2 : ℝ) < (N ^ 2 : ℝ) := by exact_mod_cast hhi2_lt_N2
    simpa using sub_pos.mpr this
  have hN2_sub_lo_pos : (0 : ℝ) < (N : ℝ) ^ 2 - (lo : ℝ) ^ 2 := by
    have : (lo ^ 2 : ℝ) < (N ^ 2 : ℝ) := by exact_mod_cast hlo2_lt_N2
    simpa using sub_pos.mpr this
  have hgv_sq_val : (2 * v_pt / (1 - v_pt ^ 2)) ^ 2 =
      (4 * (hi : ℝ) ^ 2 * (N : ℝ) ^ 2) / ((N : ℝ) ^ 2 - (hi : ℝ) ^ 2) ^ 2 :=
    l56_g_sq_ratio hN_pos_r (Nat.cast_nonneg hi) (by exact_mod_cast hhi_lt_N)
  have hgu_sq_val : (2 * u_pt / (1 - u_pt ^ 2)) ^ 2 =
      (4 * (lo : ℝ) ^ 2 * (N : ℝ) ^ 2) / ((N : ℝ) ^ 2 - (lo : ℝ) ^ 2) ^ 2 :=
    l56_g_sq_ratio hN_pos_r (Nat.cast_nonneg lo) (by exact_mod_cast hlo_lt_N)
  have hBA_sq_val : (B : ℝ) ^ 2 / (A : ℝ) ^ 2 =
      (4 * (hi : ℝ) ^ 2 * (N : ℝ) ^ 2) / ((N : ℝ) ^ 2 - (hi : ℝ) ^ 2) ^ 2 := by
    have hAr : (A : ℝ) = ((N : ℝ) ^ 2 - (hi : ℝ) ^ 2) / ((N : ℝ) ^ 2 + (hi : ℝ) ^ 2) := by
      dsimp [A, A_num, A_den]
      rw [Rat.cast_div, Nat.cast_sub hhi2_lt_N2.le]
      push_cast
      rfl
    have hBr : (B : ℝ) = (2 * (N : ℝ) * (hi : ℝ)) / ((N : ℝ) ^ 2 + (hi : ℝ) ^ 2) := by
      dsimp [B, B_num, A_den]
      rw [Rat.cast_div]
      push_cast
      rfl
    have hadd_pos : (0 : ℝ) < (N : ℝ) ^ 2 + (hi : ℝ) ^ 2 := by positivity
    rw [hAr, hBr]
    exact l56_pythag_ratio hN2_sub_hi_pos.ne' hadd_pos.ne'
  have hgv_eq : (2 * v_pt / (1 - v_pt ^ 2)) ^ 2 = (B : ℝ) ^ 2 / (A : ℝ) ^ 2 :=
    hgv_sq_val.trans hBA_sq_val.symm
  have htarget_eq : (b_num : ℝ) / (b_den : ℝ) + 2 / (M_e : ℝ) =
      ((b_num : ℝ) * (M_e : ℝ) + 2 * (b_den : ℝ)) / ((b_den : ℝ) * (M_e : ℝ)) := by
    rw [div_add_div _ _ hbden_pos_r.ne' hMe_pos_r.ne']
    congr 1
    ring
  have ht_ge_b2 : (b_num : ℝ) / (b_den : ℝ) + 2 / (M_e : ℝ) ≤ (B : ℝ) ^ 2 / (A : ℝ) ^ 2 := by
    rw [hBA_sq_val, htarget_eq,
      div_le_div_iff₀ (mul_pos hbden_pos_r hMe_pos_r) (sq_pos_of_pos hN2_sub_hi_pos)]
    have hcast : (((b_num * M_e + 2 * b_den) * (N ^ 2 - hi ^ 2) ^ 2 : ℕ) : ℝ) ≤
        ((4 * hi ^ 2 * N ^ 2 * (b_den * M_e) : ℕ) : ℝ) := by exact_mod_cast hhi_ge_nat
    rw [Nat.cast_mul, Nat.cast_pow, Nat.cast_sub hhi2_lt_N2.le] at hcast
    push_cast at hcast
    linarith
  have hgu_lt_b2 : (2 * u_pt / (1 - u_pt ^ 2)) ^ 2 <
      (b_num : ℝ) / (b_den : ℝ) + 2 / (M_e : ℝ) := by
    rw [hgu_sq_val, htarget_eq,
      div_lt_div_iff₀ (sq_pos_of_pos hN2_sub_lo_pos) (mul_pos hbden_pos_r hMe_pos_r)]
    have hcast : ((4 * lo ^ 2 * N ^ 2 * (b_den * M_e) : ℕ) : ℝ) <
        (((b_num * M_e + 2 * b_den) * (N ^ 2 - lo ^ 2) ^ 2 : ℕ) : ℝ) := by
      exact_mod_cast hlo_lt_nat
    push_cast [Nat.cast_sub hlo2_lt_N2.le] at hcast
    linarith
  have h16N_le : 16 / (N : ℝ) ≤ 1 / (M_e : ℝ) := by
    rw [div_le_div_iff₀ hN_pos_r hMe_pos_r]
    have hNP : 32 * M_e ≤ N := by dsimp [N]; omega
    have hNP_r : (32 : ℝ) * (M_e : ℝ) ≤ (N : ℝ) := by exact_mod_cast hNP
    linarith
  have ht_lt_b3 : (B : ℝ) ^ 2 / (A : ℝ) ^ 2 < (b_num : ℝ) / (b_den : ℝ) + 3 / (M_e : ℝ) := by
    have hlip := l56_lipschitz hu0 huv hv_half
    rw [hv_sub_u, hgv_eq] at hlip
    have h16_eq : 16 * (1 / (N : ℝ)) = 16 / (N : ℝ) := by ring
    have h21_eq : (2 : ℝ) / (M_e : ℝ) + 1 / (M_e : ℝ) = 3 / (M_e : ℝ) := by ring
    rw [h16_eq] at hlip
    linarith
  exact ⟨hAn_pos, hAn_le_Ad, hBn_pos, hBn_le_Ad, hAd_lt_4N2,
    hA_pos, hB_nn, hAB_one, ht_ge_b2, ht_lt_b3⟩

theorem l56ComputeAB_math_spec
    {a b : ℚ} {g : ℝ} {e : ℚ}
    (hb0 : 0 ≤ b) (hba : b < a) (ha1 : a ≤ 1)
    (hg0 : 0 < g) (hg_gap : g ≤ (a : ℝ) - (1 + g) * (b : ℝ))
    (he0 : 0 < e) (he_le : (e : ℝ) ≤ g / 16) :
    let M_e := Nat.ceil (1 / e)
    let L_e := Nat.ceil (Real.log (1 / (e : ℝ)))
    let b_num := b.num.toNat
    let b_den := b.den
    let res := l56ComputeAB M_e b_num b_den
    let A : ℚ := (res.1 : ℚ) / (res.2.1 : ℚ)
    let B : ℚ := (res.2.2.1 : ℚ) / (res.2.2.2 : ℚ)
    1 ≤ res.1 ∧
    res.1 ≤ res.2.1 ∧
    1 ≤ res.2.2.1 ∧
    res.2.2.1 ≤ res.2.2.2 ∧
    res.2.2.2 = res.2.1 ∧
    res.2.1 < 2 ^ (4 * L_e + 12) ∧
    0 < (res.2.1 : ℤ) ∧
    0 < (res.2.2.2 : ℤ) ∧
    0 < A ∧
    0 ≤ B ∧
    A ^ 2 + B ^ 2 = 1 ∧
    ∀ (d : ℕ) (u z z_hat : EuclideanSpace ℝ (Fin d)),
      ‖u‖ = 1 → ‖z‖ = 1 → ‖z_hat‖ = 1 → ‖z_hat - z‖ ≤ (e : ℝ) / 8 →
      let padQuery := UL.liftedPoint ((A : ℝ) • z_hat) (-(B : ℝ))
      let padData := UL.liftedPoint ((A : ℝ) • u) (B : ℝ)
      ‖padQuery‖ = 1 ∧
      ‖padData‖ = 1 ∧
      ((a : ℝ) ≤ inner ℝ z u → g - 11 * (e : ℝ) ≤ inner ℝ padQuery padData) ∧
      (inner ℝ z u ≤ (b : ℝ) → inner ℝ padQuery padData < 0) := by
  intro M_e L_e b_num b_den res A B
  have hb0_r : (0 : ℝ) ≤ (b : ℝ) := by exact_mod_cast hb0
  have ha1_r : (a : ℝ) ≤ 1 := by exact_mod_cast ha1
  have he0_r : (0 : ℝ) < (e : ℝ) := by exact_mod_cast he0
  have hg1 : g ≤ 1 := by
    have : 0 ≤ (1 + g) * (b : ℝ) := mul_nonneg (by linarith) hb0_r
    linarith
  have he16 : (e : ℝ) ≤ 1 / 16 := by linarith
  have hceil_bds :
      16 ≤ M_e ∧ M_e ≤ 2 ^ (2 * L_e) ∧ l56TargetK M_e ≤ 2 * L_e + 4 ∧
      (e : ℝ) < 2 / (M_e : ℝ) ∧ 1 / (M_e : ℝ) ≤ (e : ℝ) :=
    l56_ceil_inv_e_bounds he0 he16
  rcases hceil_bds with ⟨hMe16, _, hK_le, he_lt_2Me, h1Me_le_e⟩
  have hb_le1 : b ≤ 1 := hba.le.trans ha1
  have hb_num_nn : 0 ≤ b.num := Rat.num_nonneg.mpr hb0
  have hb_num_z : (b_num : ℤ) = b.num := Int.toNat_of_nonneg hb_num_nn
  have hb_den_pos : 1 ≤ b_den := Nat.succ_le_of_lt b.pos
  have hb_num_le_den : b_num ≤ b_den := by
    have hq : (b.num : ℚ) / (b.den : ℚ) ≤ 1 := by
      rw [Rat.num_div_den]
      exact hb_le1
    have hden_q : (0 : ℚ) < (b.den : ℚ) := by exact_mod_cast b.pos
    have hle_q : (b.num : ℚ) ≤ (b.den : ℚ) := (div_le_one hden_q).mp hq
    have hle_z : b.num ≤ (b.den : ℤ) := by exact_mod_cast hle_q
    rw [← hb_num_z] at hle_z
    exact_mod_cast hle_z
  have hP_ge : 16 * M_e ≤ 2 ^ l56TargetK M_e := (l56TargetK_spec hMe16).2.2.1
  have hiter := l56Iter_inv hMe16 hb_den_pos hb_num_le_den (l56TargetK M_e) le_rfl
  set lh := l56Iter M_e b_num b_den (2 ^ l56TargetK M_e) (l56TargetK M_e)
  have hdiffK : lh.2 = lh.1 + 1 := by
    have h := hiter.1
    rw [Nat.sub_self, pow_zero] at h
    exact h
  have halg :
      1 ≤ res.1 ∧ res.1 ≤ res.2.1 ∧ 1 ≤ res.2.2.1 ∧ res.2.2.1 ≤ res.2.1 ∧
      res.2.1 < 4 * (2 * 2 ^ l56TargetK M_e) ^ 2 ∧
      0 < A ∧ 0 ≤ B ∧ A ^ 2 + B ^ 2 = 1 ∧
      (b_num : ℝ) / (b_den : ℝ) + 2 / (M_e : ℝ) ≤ (B : ℝ) ^ 2 / (A : ℝ) ^ 2 ∧
      (B : ℝ) ^ 2 / (A : ℝ) ^ 2 < (b_num : ℝ) / (b_den : ℝ) + 3 / (M_e : ℝ) :=
    l56_alg_from_bounds hMe16 hb_den_pos hP_ge hdiffK hiter.2.1 hiter.2.2.1 hiter.2.2.2
  rcases halg with ⟨hAn_pos, hAn_le_Ad, hBn_pos, hBn_le_Ad, hAd_lt_4N2,
    hA_pos, hB_nn, hAB_one, ht_ge_b2, ht_lt_b3⟩
  have hAd_lt_pow : res.2.1 < 2 ^ (4 * L_e + 12) := by
    have hP_le : 2 ^ l56TargetK M_e ≤ 2 ^ (2 * L_e + 4) :=
      Nat.pow_le_pow_right (by norm_num) hK_le
    have hN_le : 2 * 2 ^ l56TargetK M_e ≤ 2 ^ (2 * L_e + 5) := by
      have : 2 ^ (2 * L_e + 5) = 2 * 2 ^ (2 * L_e + 4) := by ring
      omega
    have hN2_le : (2 * 2 ^ l56TargetK M_e) ^ 2 ≤ (2 ^ (2 * L_e + 5)) ^ 2 :=
      Nat.pow_le_pow_left hN_le 2
    have hpow_eq : 4 * (2 ^ (2 * L_e + 5)) ^ 2 = 2 ^ (4 * L_e + 12) := by ring
    omega
  have hAd_pos_z : 0 < (res.2.1 : ℤ) := by
    have : 1 ≤ res.2.1 := le_trans hAn_pos hAn_le_Ad
    exact_mod_cast this
  have hb_cast_r : (b : ℝ) = (b_num : ℝ) / (b_den : ℝ) := by
    have h1 : b = (b.num : ℚ) / (b.den : ℚ) := (Rat.num_div_den b).symm
    rw [h1, ← hb_num_z]
    push_cast
    rfl
  have ht_lo_final : (b : ℝ) + (e : ℝ) < (B : ℝ) ^ 2 / (A : ℝ) ^ 2 := by
    rw [← hb_cast_r] at ht_ge_b2
    linarith
  have ht_hi_final : (B : ℝ) ^ 2 / (A : ℝ) ^ 2 < (b : ℝ) + 5 * (e : ℝ) := by
    rw [← hb_cast_r] at ht_lt_b3
    have h3_le_5e : 3 / (M_e : ℝ) ≤ 5 * (e : ℝ) := by
      have h3_eq : (3 : ℝ) / (M_e : ℝ) = 3 * (1 / (M_e : ℝ)) := by ring
      rw [h3_eq]
      linarith
    linarith
  refine ⟨hAn_pos, hAn_le_Ad, hBn_pos, hBn_le_Ad, rfl, hAd_lt_pow,
    hAd_pos_z, hAd_pos_z, hA_pos, hB_nn, hAB_one, ?_⟩
  intro d u z z_hat hu hz hzh hdist
  exact l56_padded_corr_bounds hb0_r ha1_r hg0 hg_gap he0_r he_le
    (by exact_mod_cast hA_pos) (by exact_mod_cast hAB_one)
    ht_lo_final ht_hi_final d u z z_hat hu hz hzh hdist

/-! ### Bit-length helper bounds -/

theorem intBitLength_le_of_abs_lt_two_pow {z : ℤ} {m : ℕ}
    (hlt : z.natAbs < 2 ^ m) :
    UL.intBitLength z ≤ m + 2 := by
  unfold UL.intBitLength UL.natBitLength
  split_ifs with hz0
  · omega
  · have hlog : Nat.log 2 z.natAbs < m := by
      by_cases hm0 : m = 0
      · subst hm0
        have : z.natAbs ≠ 0 := Int.natAbs_ne_zero.mpr hz0
        omega
      · exact Nat.log_lt_of_lt_pow (Int.natAbs_ne_zero.mpr hz0) hlt
    omega

theorem b_num_den_lt_two_pow (b : ℚ) :
    b.num.natAbs < 2 ^ UL.ratBitLength b ∧
    b.den < 2 ^ UL.ratBitLength b := by
  unfold UL.ratBitLength UL.intBitLength UL.natBitLength
  have hden_lt : b.den < 2 ^ (Nat.log 2 b.den + 1) :=
    Nat.lt_pow_succ_log_self (by norm_num) b.den
  constructor
  · split_ifs with h0
    · rw [h0]
      simp only [Int.natAbs_zero]
      exact Nat.two_pow_pos _
    · have hnum_lt : b.num.natAbs < 2 ^ (Nat.log 2 b.num.natAbs + 1) :=
        Nat.lt_pow_succ_log_self (by norm_num) b.num.natAbs
      exact hnum_lt.trans_le (Nat.pow_le_pow_right (by norm_num) (by omega))
  · exact hden_lt.trans_le (Nat.pow_le_pow_right (by norm_num) (by omega))

theorem ratBitLength_div_nat_le {p q m : ℕ}
    (hp : 1 ≤ p) (hpq : p ≤ q) (hq : q < 2 ^ m) :
    UL.ratBitLength ((p : ℚ) / (q : ℚ)) ≤ 2 * m + 3 := by
  set r : ℚ := (p : ℚ) / (q : ℚ)
  have hq_pos : 0 < q := by omega
  have hr_pos : 0 < r := div_pos (by exact_mod_cast hp) (by exact_mod_cast hq_pos)
  have hr_le1 : r ≤ 1 := (div_le_one (by exact_mod_cast hq_pos)).mpr (by exact_mod_cast hpq)
  have hcross_q : (r.num : ℚ) * (q : ℚ) = (p : ℚ) * (r.den : ℚ) := by
    have h1 : (r.num : ℚ) / (r.den : ℚ) = (p : ℚ) / (q : ℚ) := by
      rw [Rat.num_div_den]
    have hrd_ne : (r.den : ℚ) ≠ 0 := by exact_mod_cast r.pos.ne'
    have hq_ne : (q : ℚ) ≠ 0 := by exact_mod_cast hq_pos.ne'
    exact (div_eq_div_iff hrd_ne hq_ne).mp h1
  have hcross_z : r.num * (q : ℤ) = (p : ℤ) * (r.den : ℤ) := by exact_mod_cast hcross_q
  have hr_num_pos : 0 < r.num := Rat.num_pos.mpr hr_pos
  have hcross_nat : r.num.natAbs * q = p * r.den := by
    have h1 : (r.num.natAbs : ℤ) = r.num := Int.natAbs_of_nonneg hr_num_pos.le
    have h2 : ((r.num.natAbs * q : ℕ) : ℤ) = ((p * r.den : ℕ) : ℤ) := by
      rw [Nat.cast_mul, Nat.cast_mul, h1]
      exact hcross_z
    exact_mod_cast h2
  have hdvd_mul : r.den ∣ r.num.natAbs * q := ⟨p, by linarith [hcross_nat]⟩
  have hdvd_q : r.den ∣ q := r.reduced.symm.dvd_of_dvd_mul_left hdvd_mul
  have hr_den_le : r.den ≤ q := Nat.le_of_dvd hq_pos hdvd_q
  have hr_den_lt : r.den < 2 ^ m := lt_of_le_of_lt hr_den_le hq
  have hr_num_le_den : r.num.natAbs ≤ r.den := by
    have h1 : (r.num : ℚ) / (r.den : ℚ) ≤ 1 := by
      rw [Rat.num_div_den]
      exact hr_le1
    have h2 : (r.num : ℚ) ≤ (r.den : ℚ) := (div_le_one (by exact_mod_cast r.pos)).mp h1
    have h3 : r.num ≤ (r.den : ℤ) := by exact_mod_cast h2
    omega
  have hr_num_lt : r.num.natAbs < 2 ^ m := lt_of_le_of_lt hr_num_le_den hr_den_lt
  have h_ib : UL.intBitLength r.num ≤ m + 2 := intBitLength_le_of_abs_lt_two_pow hr_num_lt
  have h_nb : UL.natBitLength r.den ≤ m := by
    unfold UL.natBitLength
    have hm_pos : 1 ≤ m := by
      by_contra hm0
      have : m = 0 := by omega
      subst this
      omega
    have hlog : Nat.log 2 r.den < m := Nat.log_lt_of_lt_pow r.pos.ne' hr_den_lt
    omega
  unfold UL.ratBitLength
  omega

end UL.Proof_lem_5_6
