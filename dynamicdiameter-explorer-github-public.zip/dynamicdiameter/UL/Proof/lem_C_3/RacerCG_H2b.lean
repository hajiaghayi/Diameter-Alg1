import Mathlib
import UL.Proof.lem_C_3.RacerCG_H2a
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof.lem_C_3.RacerCG

/-! ### 1. Good bundle predicate, Markov per copy, independence, and union bound -/

def IsGoodCopies
    {ι : Type} {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (cap : ℕ)
    (copies : List (BirthState × PhaseState)) : Prop :=
  ∀ z ∈ N, ∃ bSt ∈ copies.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ)

theorem isGoodCopies_of_map_fst_eq
    {ι : Type} {d d_s : ℕ} {BirthState PhaseState : Type}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {cap : ℕ}
    {c₁ c₂ : List (BirthState × PhaseState)}
    (heq : c₁.map Prod.fst = c₂.map Prod.fst) :
    IsGoodCopies inst N cap c₁ ↔ IsGoodCopies inst N cap c₂ := by
  simp only [IsGoodCopies, heq]

open Classical in
theorem bad_copy_prob_le_quarter
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {hist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N hist inst)
    {z : EuclideanSpace ℝ (Fin d_s)} (hz : z ∈ N) :
    let cap := c3_cap_of A_n P_fac
    expWithBits (inst.buildWithBits hist)
      (fun bOut => if ¬ (inst.birthVar bOut.birthState z < ((cap + 1 : ℕ) : ℝ)) then 1 else 0) ≤
      (4 : ENNReal)⁻¹ := by
  intro cap
  have hExp := hVar.2.2.2.2.2.2.2.2.2.2.2.2.2.1 z hz
  have hexp_le : inst.birthVarExpected hist z ≤ ENNReal.ofReal (A_n * P_fac) :=
    ennreal_le_ofReal_of_toReal_le hExp.1 hExp.2
  have h4lt : 4 * (A_n * P_fac) < ((cap + 1 : ℕ) : ℝ) := by
    simpa [cap, mul_assoc] using lt_c3_cap_of_add_one A_n P_fac
  have hAP_le : A_n * P_fac ≤ ((cap + 1 : ℕ) : ℝ) / 4 := by linarith
  let C : ENNReal := ((cap + 1 : ℕ) : ENNReal)
  have hC_ne_zero : C ≠ 0 := by simp [C]
  have hC_ne_top : C ≠ ⊤ := by simp [C]
  let badP := expWithBits (inst.buildWithBits hist)
    (fun bOut => if ¬ (inst.birthVar bOut.birthState z < ((cap + 1 : ℕ) : ℝ)) then (1 : ENNReal) else 0)
  have hmarkov : badP * C ≤ inst.birthVarExpected hist z := by
    dsimp only [badP]
    rw [← expWithBits_const_mul]
    unfold expWithBits UL.CertifiedSearchGeneration.birthVarExpected
    refine ENNReal.tsum_le_tsum (fun bs => ?_)
    cases inst.buildWithBits hist bs with
    | none => simp
    | some bOut =>
      dsimp only
      by_cases hlt : inst.birthVar bOut.birthState z < ((cap + 1 : ℕ) : ℝ)
      · simp only [hlt, not_true_eq_false, ↓reduceIte, zero_mul, mul_zero]
        exact bot_le
      · simp only [hlt, not_false_eq_true, ↓reduceIte, one_mul]
        have hge : ((cap + 1 : ℕ) : ℝ) ≤ inst.birthVar bOut.birthState z := le_of_not_gt hlt
        have hC_le : C ≤ ENNReal.ofReal (inst.birthVar bOut.birthState z) := by
          dsimp only [C]
          rw [← ENNReal.ofReal_natCast]
          exact ENNReal.ofReal_le_ofReal hge
        exact mul_le_mul_right hC_le _
  have hbound : badP * C ≤ (4 : ENNReal)⁻¹ * C := by
    calc
      badP * C ≤ ENNReal.ofReal (A_n * P_fac) := hmarkov.trans hexp_le
      _ ≤ ENNReal.ofReal (((cap + 1 : ℕ) : ℝ) / 4) := ENNReal.ofReal_le_ofReal hAP_le
      _ = (4 : ENNReal)⁻¹ * C := by
        rw [div_eq_inv_mul, ENNReal.ofReal_mul (by norm_num)]
        have h4 : ENNReal.ofReal (4 : ℝ)⁻¹ = (4 : ENNReal)⁻¹ := by
          rw [ENNReal.ofReal_inv_of_pos (by norm_num)]
          norm_num
        have hc : ENNReal.ofReal ((cap + 1 : ℕ) : ℝ) = C := ENNReal.ofReal_natCast (cap + 1)
        rw [h4, hc]
  exact (ENNReal.mul_le_mul_iff_left hC_ne_zero hC_ne_top).mp hbound

open Classical in
theorem all_bad_copies_prob_le
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {hist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N hist inst)
    {z : EuclideanSpace ℝ (Fin d_s)} (hz : z ∈ N)
    (R : ℕ) :
    let cap := c3_cap_of A_n P_fac
    expWithBits (UL.buildRCopies inst hist R)
      (fun cw => if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
        then 1 else 0) ≤ ((4 : ENNReal)⁻¹) ^ R := by
  intro cap
  have hpf1 : IsPrefixFree (inst.buildWithBits hist) := hVar.2.2.2.2.2.2.1
  have h1copy := bad_copy_prob_le_quarter hVar hz
  induction R with
  | zero =>
    change expWithBits (UL.pureWithBits ([], 0)) _ ≤ _
    rw [expWithBits_pure]
    simp
  | succ r ih =>
    have hpf_r := (buildRCopies_props hVar r).1
    change expWithBits (UL.bindWithBits (inst.buildWithBits hist) (fun bOut =>
        UL.bindWithBits (UL.buildRCopies inst hist r) (fun cw =>
          UL.pureWithBits ((bOut.birthState, bOut.initPhase) :: cw.1, bOut.work + cw.2)))) _ ≤ _
    rw [expWithBits_bind hpf1]
    let Pr := expWithBits (UL.buildRCopies inst hist r)
      (fun cw => if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
        then (1 : ENNReal) else 0)
    have hinner : ∀ bOut : UL.CertifiedBirthOutcome BirthState PhaseState,
        expWithBits (UL.bindWithBits (UL.buildRCopies inst hist r) (fun cw =>
            UL.pureWithBits ((bOut.birthState, bOut.initPhase) :: cw.1, bOut.work + cw.2)))
          (fun cw => if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
            then (1 : ENNReal) else 0) =
        (if ¬ (inst.birthVar bOut.birthState z < ((cap + 1 : ℕ) : ℝ)) then (1 : ENNReal) else 0) * Pr := by
      intro bOut
      rw [expWithBits_bind hpf_r]
      by_cases hb : inst.birthVar bOut.birthState z < ((cap + 1 : ℕ) : ℝ)
      · have hzero : expWithBits (UL.buildRCopies inst hist r)
            (fun cw => expWithBits (UL.pureWithBits ((bOut.birthState, bOut.initPhase) :: cw.1, bOut.work + cw.2))
              (fun res => if ¬ (∃ bSt ∈ res.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
                then (1 : ENNReal) else 0)) = 0 := by
          have hc0 : expWithBits (UL.buildRCopies inst hist r)
              (fun cw => expWithBits (UL.pureWithBits ((bOut.birthState, bOut.initPhase) :: cw.1, bOut.work + cw.2))
                (fun res => if ¬ (∃ bSt ∈ res.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
                  then (1 : ENNReal) else 0)) =
              expWithBits (UL.buildRCopies inst hist r) (fun _ => 0) := by
            refine expWithBits_congr (fun _ => rfl) (fun _ cw _ => ?_)
            rw [expWithBits_pure]
            have hex : ∃ bSt ∈ ((bOut.birthState, bOut.initPhase) :: cw.1).map Prod.fst,
                inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ) := ⟨bOut.birthState, by simp, hb⟩
            simp only [hex, not_true_eq_false, ↓reduceIte]
          rw [hc0, expWithBits_const, mul_zero]
        rw [hzero]
        simp only [hb, not_true_eq_false, ↓reduceIte, zero_mul]
      · simp only [hb, not_false_eq_true, ↓reduceIte, one_mul]
        refine expWithBits_congr (fun _ => rfl) (fun _ cw _ => ?_)
        rw [expWithBits_pure]
        simp only [List.map_cons, List.mem_cons, exists_eq_or_imp, hb, false_or]
    simp_rw [hinner]
    rw [expWithBits_const_mul, pow_succ']
    exact mul_le_mul' h1copy ih

theorem card_net_mul_quarter_pow_le_half
    {d_s : ℕ} {N : Finset (EuclideanSpace ℝ (Fin d_s))} {nb : ℝ}
    (hNet : UL.IsValidImplicitDirectionNet N nb) :
    (N.card : ENNReal) * ((4 : ENNReal)⁻¹) ^ (c3_R_of nb) ≤ (2 : ENNReal)⁻¹ := by
  rcases hNet with ⟨hN_ne, _, _, hlog_le⟩
  let k : ℕ := Nat.ceil nb
  have hnb_le_k : nb ≤ (k : ℝ) := Nat.le_ceil nb
  have hcard_pos : (0 : ℝ) < (N.card : ℝ) := by exact_mod_cast hN_ne.card_pos
  have hexp1_le_4 : Real.exp 1 ≤ 4 := by
    linarith [Real.exp_one_lt_d9]
  have hcard_le_4k : (N.card : ℝ) ≤ (4 : ℝ) ^ k := by
    calc
      (N.card : ℝ) = Real.exp (Real.log (N.card : ℝ)) := (Real.exp_log hcard_pos).symm
      _ ≤ Real.exp (k : ℝ) := Real.exp_le_exp.mpr (hlog_le.trans hnb_le_k)
      _ = Real.exp ((k : ℝ) * 1) := by ring_nf
      _ = (Real.exp 1) ^ k := Real.exp_nat_mul 1 k
      _ ≤ (4 : ℝ) ^ k := pow_le_pow_left₀ (Real.exp_nonneg 1) hexp1_le_4 k
  have hreal_le : (N.card : ℝ) * ((4 : ℝ)⁻¹) ^ (c3_R_of nb) ≤ (2 : ℝ)⁻¹ := by
    have hR : c3_R_of nb = k + 2 := rfl
    rw [hR, pow_add]
    have hprod : (4 : ℝ) ^ k * ((4 : ℝ)⁻¹ ^ k * (4 : ℝ)⁻¹ ^ 2) = (16 : ℝ)⁻¹ := by
      have h1 : (4 : ℝ) ^ k * (4 : ℝ)⁻¹ ^ k = 1 := by
        rw [← mul_pow]
        norm_num
      calc
        (4 : ℝ) ^ k * ((4 : ℝ)⁻¹ ^ k * (4 : ℝ)⁻¹ ^ 2)
            = ((4 : ℝ) ^ k * (4 : ℝ)⁻¹ ^ k) * (4 : ℝ)⁻¹ ^ 2 := by ring
        _ = 1 * (4 : ℝ)⁻¹ ^ 2 := by rw [h1]
        _ = (16 : ℝ)⁻¹ := by norm_num
    have hmono : (N.card : ℝ) * ((4 : ℝ)⁻¹ ^ k * (4 : ℝ)⁻¹ ^ 2) ≤
        (4 : ℝ) ^ k * ((4 : ℝ)⁻¹ ^ k * (4 : ℝ)⁻¹ ^ 2) :=
      mul_le_mul_of_nonneg_right hcard_le_4k (by positivity)
    linarith
  have heq_enn : ENNReal.ofReal ((N.card : ℝ) * ((4 : ℝ)⁻¹) ^ (c3_R_of nb)) =
      (N.card : ENNReal) * ((4 : ENNReal)⁻¹) ^ (c3_R_of nb) := by
    rw [ENNReal.ofReal_mul (by positivity), ENNReal.ofReal_natCast,
      ENNReal.ofReal_pow (by positivity), ENNReal.ofReal_inv_of_pos (by norm_num)]
    norm_num
  have hhalf_enn : ENNReal.ofReal ((2 : ℝ)⁻¹) = (2 : ENNReal)⁻¹ := by
    rw [ENNReal.ofReal_inv_of_pos (by norm_num)]
    norm_num
  rw [← heq_enn, ← hhalf_enn]
  exact ENNReal.ofReal_le_ofReal hreal_le

open Classical in
theorem buildRCopies_bad_prob_le_half
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {hist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N hist inst) :
    let R := c3_R_of netLogBound
    let cap := c3_cap_of A_n P_fac
    expWithBits (UL.buildRCopies inst hist R)
      (fun cw => if ¬ IsGoodCopies inst N cap cw.1 then 1 else 0) ≤ (2 : ENNReal)⁻¹ := by
  intro R cap
  have hNet : UL.IsValidImplicitDirectionNet N netLogBound := hVar.2.2.2.2.2.1
  have hle_sum : expWithBits (UL.buildRCopies inst hist R)
      (fun cw => if ¬ IsGoodCopies inst N cap cw.1 then (1 : ENNReal) else 0) ≤
      expWithBits (UL.buildRCopies inst hist R)
        (fun cw => ∑ z ∈ N,
          if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
          then (1 : ENNReal) else 0) := by
    refine expWithBits_mono (fun _ cw _ => ?_)
    by_cases hg : IsGoodCopies inst N cap cw.1
    · simp [hg]
    · simp only [hg, not_false_eq_true, ↓reduceIte]
      unfold IsGoodCopies at hg
      push_neg at hg
      rcases hg with ⟨z₀, hz₀, hnone⟩
      have hterm1 : (1 : ENNReal) ≤
          (if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z₀ < ((cap + 1 : ℕ) : ℝ))
           then (1 : ENNReal) else 0) := by
        have hn : ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z₀ < ((cap + 1 : ℕ) : ℝ)) := by
          rintro ⟨bSt, hb, hlt⟩
          exact not_lt_of_ge (hnone bSt hb) hlt
        simp only [hn, not_false_eq_true, ↓reduceIte, le_rfl]
      exact hterm1.trans (Finset.single_le_sum
        (f := fun z => if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
          then (1 : ENNReal) else 0)
        (fun _ _ => bot_le) hz₀)
  have hsum_comm : ∀ s : Finset (EuclideanSpace ℝ (Fin d_s)),
      expWithBits (UL.buildRCopies inst hist R)
        (fun cw => ∑ z ∈ s,
          if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
          then (1 : ENNReal) else 0) =
      ∑ z ∈ s, expWithBits (UL.buildRCopies inst hist R)
        (fun cw => if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
          then (1 : ENNReal) else 0) := by
    intro s
    refine Finset.induction_on s ?_ ?_
    · simp only [Finset.sum_empty]
      rw [expWithBits_const, mul_zero]
    · intro z₀ s' hz₀ ihs
      have hcongr : expWithBits (UL.buildRCopies inst hist R)
          (fun cw => ∑ z ∈ insert z₀ s',
            if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
            then (1 : ENNReal) else 0) =
          expWithBits (UL.buildRCopies inst hist R)
            (fun cw =>
              (if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z₀ < ((cap + 1 : ℕ) : ℝ))
               then (1 : ENNReal) else 0) +
              ∑ z ∈ s',
                if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
                then (1 : ENNReal) else 0) :=
        expWithBits_congr (fun _ => rfl) (fun _ _ _ => Finset.sum_insert hz₀)
      rw [hcongr, expWithBits_add, ihs, Finset.sum_insert hz₀]
  calc
    _ ≤ ∑ z ∈ N, expWithBits (UL.buildRCopies inst hist R)
          (fun cw => if ¬ (∃ bSt ∈ cw.1.map Prod.fst, inst.birthVar bSt z < ((cap + 1 : ℕ) : ℝ))
            then (1 : ENNReal) else 0) := hle_sum.trans (le_of_eq (hsum_comm N))
    _ ≤ ∑ _z ∈ N, ((4 : ENNReal)⁻¹) ^ R :=
          Finset.sum_le_sum (fun z hz => all_bad_copies_prob_le hVar hz R)
    _ = (N.card : ENNReal) * ((4 : ENNReal)⁻¹) ^ R := by simp
    _ ≤ (2 : ENNReal)⁻¹ := card_net_mul_quarter_pow_le_half hNet

open Classical in
theorem rebuildCompiledBundle_bad_prob_le_half
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {curHist : UL.ExecutionHistory d}
    {bundle : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N curHist bundle.inst)
    (hreplay : ValidDelReplay bundle.inst.gen.P₀ bundle.deletedIds bundle.survivingSet) :
    let R := c3_R_of netLogBound
    let cap := c3_cap_of A_n P_fac
    expWithBits (UL.rebuildCompiledBundle R curHist bundle)
      (fun rw => if ¬ IsGoodCopies bundle.inst N cap rw.1.copies then 1 else 0) ≤
      (2 : ENNReal)⁻¹ := by
  intro R cap
  obtain ⟨hpf_b, _, hinv_b, _⟩ := buildRCopies_props hVar R
  have hsub0 : bundle.inst.gen.IsSurvivingSubset bundle.inst.gen.P₀ := Finset.Subset.refl _
  unfold UL.rebuildCompiledBundle
  rw [expWithBits_bind hpf_b]
  refine (expWithBits_mono ?_).trans (buildRCopies_bad_prob_le_half hVar)
  intro bs₁ bw hbw
  obtain ⟨_, hacc_b⟩ := hinv_b bs₁ bw hbw
  obtain ⟨hpf_l, hhp_l, hinv_l, _⟩ :=
    deleteRCopiesList_props (curHist := curHist) hVar hreplay hsub0 bw.1 hacc_b
  rw [expWithBits_bind hpf_l]
  have heq_const : expWithBits
      (UL.deleteRCopiesList bundle.inst curHist bundle.inst.gen.P₀ bundle.deletedIds bw.1)
      (fun dw => expWithBits
        (UL.pureWithBits ({ bundle with epochBirthHist := curHist, copies := dw.1 }, bw.2 + dw.2))
        (fun rw => if ¬ IsGoodCopies bundle.inst N cap rw.1.copies then (1 : ENNReal) else 0)) =
      expWithBits
        (UL.deleteRCopiesList bundle.inst curHist bundle.inst.gen.P₀ bundle.deletedIds bw.1)
        (fun _ => if ¬ IsGoodCopies bundle.inst N cap bw.1 then (1 : ENNReal) else 0) := by
    refine expWithBits_congr (fun _ => rfl) (fun u dw hdw => ?_)
    rw [expWithBits_pure]
    have hfst := (hinv_l u dw hdw).1
    have hg_iff := isGoodCopies_of_map_fst_eq (inst := bundle.inst) (N := N) (cap := cap) hfst
    simp [hg_iff]
  rw [heq_const, expWithBits_const, hhp_l, one_mul]

open Classical in
theorem rebuild_nil_must_be_good
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {curHist : UL.ExecutionHistory d}
    {bundle : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N curHist bundle.inst)
    (hreplay : ValidDelReplay bundle.inst.gen.P₀ bundle.deletedIds bundle.survivingSet)
    {rw : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState × ℕ}
    (hnil : UL.rebuildCompiledBundle (c3_R_of netLogBound) curHist bundle [] = some rw) :
    IsGoodCopies bundle.inst N (c3_cap_of A_n P_fac) rw.1.copies := by
  by_contra hbad
  have hle_half := rebuildCompiledBundle_bad_prob_le_half hVar hreplay
  have h1 : (1 : ENNReal) ≤ expWithBits
      (UL.rebuildCompiledBundle (c3_R_of netLogBound) curHist bundle)
      (fun rw' => if ¬ IsGoodCopies bundle.inst N (c3_cap_of A_n P_fac) rw'.1.copies
        then (1 : ENNReal) else 0) := by
    unfold expWithBits
    refine (le_of_eq ?_).trans (ENNReal.le_tsum ([] : List Bool))
    simp only [hnil, bitListProb_nil, one_mul, hbad, not_false_eq_true, ↓reduceIte]
  have h1_le_half : (1 : ENNReal) ≤ (2 : ENNReal)⁻¹ := h1.trans hle_half
  norm_num at h1_le_half

/-! ### 2. `queryRCopiesCapped` and `runCompiledQuery` properties -/

theorem queryRCopiesCapped_work_le
    {ι : Type} {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (S : Finset ι) (q : UL.SearchQuery ι d_s) (cap : ℕ)
    (copies : List (BirthState × PhaseState)) :
    (UL.queryRCopiesCapped inst S q cap copies).2 ≤ copies.length * cap := by
  induction copies with
  | nil => simp [UL.queryRCopiesCapped]
  | cons cp rest ih =>
    rcases cp with ⟨bSt, ph⟩
    unfold UL.queryRCopiesCapped
    dsimp only
    have hc_le : (inst.runQueryCapped bSt S ph q cap).work ≤ cap := by
      unfold UL.CertifiedSearchGeneration.runQueryCapped
      dsimp only
      split_ifs with hle
      · exact hle
      · exact le_rfl
    cases (inst.runQueryCapped bSt S ph q cap).completedAnswer with
    | some ans =>
      dsimp only
      simp only [List.length_cons]
      have h1 : cap ≤ (rest.length + 1) * cap := by
        rw [Nat.add_mul, Nat.one_mul]
        exact Nat.le_add_left _ _
      exact hc_le.trans h1
    | none =>
      dsimp only
      simp only [List.length_cons, Nat.add_mul, Nat.one_mul]
      omega

theorem queryRCopiesCapped_correct
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {epochHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N epochHist inst)
    {S : Finset ι} (hsub : inst.gen.IsSurvivingSubset S)
    {q : UL.SearchQuery ι d_s} (hcomp : UL.IsCertifiedCompatible inst.gen inst.δ S q)
    (cap : ℕ)
    (copies : List (BirthState × PhaseState))
    (hacc : IsAcceptedCopies inst epochHist S copies)
    {ans : Option ι}
    (hans : (UL.queryRCopiesCapped inst S q cap copies).1 = some ans) :
    inst.gen.IsCorrectAnswer S q ans := by
  have hQ := hVar.2.2.2.2.2.2.2.2.2.2.2.1
  induction copies with
  | nil => simp [UL.queryRCopiesCapped] at hans
  | cons cp rest ih =>
    rcases cp with ⟨bSt, ph⟩
    have hcp := hacc (bSt, ph) List.mem_cons_self
    have hrest : IsAcceptedCopies inst epochHist S rest :=
      fun cp' hmem => hacc cp' (List.mem_cons_of_mem _ hmem)
    unfold UL.queryRCopiesCapped at hans
    dsimp only at hans
    cases hc : (inst.runQueryCapped bSt S ph q cap).completedAnswer with
    | some a =>
      rw [hc] at hans
      simp only [Option.some.injEq] at hans
      subst hans
      unfold UL.CertifiedSearchGeneration.runQueryCapped at hc
      dsimp only at hc
      split_ifs at hc with hle
      simp only [Option.some.injEq] at hc
      subst hc
      exact (hQ bSt S ph q hcp.1 hsub hcp.2 hcomp).1
    | none =>
      rw [hc] at hans
      exact ih hrest hans

theorem queryRCopiesCapped_isSome_of_good
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {epochHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N epochHist inst)
    {S : Finset ι} (hsub : inst.gen.IsSurvivingSubset S)
    {q : UL.SearchQuery ι d_s} (hcomp : UL.IsCertifiedCompatible inst.gen inst.δ S q)
    (hqz : q.z ∈ N)
    {cap : ℕ}
    {copies : List (BirthState × PhaseState)}
    (hacc : IsAcceptedCopies inst epochHist S copies)
    (hgood : IsGoodCopies inst N cap copies) :
    ∃ ans : Option ι, (UL.queryRCopiesCapped inst S q cap copies).1 = some ans := by
  have hBound := hVar.2.2.2.2.2.2.2.2.2.2.2.2.2.2
  obtain ⟨bSt₀, hbSt₀, hfast⟩ := hgood q.z hqz
  clear hgood
  induction copies with
  | nil => simp at hbSt₀
  | cons cp rest ih =>
    rcases cp with ⟨bSt, ph⟩
    have hcp := hacc (bSt, ph) List.mem_cons_self
    have hrest : IsAcceptedCopies inst epochHist S rest :=
      fun cp' hmem => hacc cp' (List.mem_cons_of_mem _ hmem)
    unfold UL.queryRCopiesCapped
    dsimp only
    simp only [List.map_cons, List.mem_cons] at hbSt₀
    rcases hbSt₀ with rfl | hmem_rest
    · have hw_real : ((inst.runQuery bSt₀ S ph q).work : ℝ) ≤ inst.birthVar bSt₀ q.z :=
        hBound bSt₀ S ph q hcp.1 hsub hcp.2 hcomp hqz
      have hw_lt : ((inst.runQuery bSt₀ S ph q).work : ℝ) < ((cap + 1 : ℕ) : ℝ) :=
        hw_real.trans_lt hfast
      have hw_lt_nat : (inst.runQuery bSt₀ S ph q).work < cap + 1 := by
        exact_mod_cast hw_lt
      have hw_le : (inst.runQuery bSt₀ S ph q).work ≤ cap := by omega
      have hc : (inst.runQueryCapped bSt₀ S ph q cap).completedAnswer =
          some (inst.runQuery bSt₀ S ph q).answer := by
        unfold UL.CertifiedSearchGeneration.runQueryCapped
        dsimp only
        rw [if_pos hw_le]
      rw [hc]
      exact ⟨_, rfl⟩
    · cases (inst.runQueryCapped bSt S ph q cap).completedAnswer with
      | some a => exact ⟨a, rfl⟩
      | none => exact ih hrest hmem_rest

/-! ### 3. Bundle state invariant, `bundleCredit`, and `runCompiledQuery` -/

def IsValidLiveBundle
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    (R : ℕ) (σ A_n P_fac netLogBound : ℝ)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (bundle : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState) : Prop :=
  UL.SatisfiesCertifiedBirthVarOnNet n σ A_n P_fac netLogBound N bundle.inst ∧
  ValidDelReplay bundle.inst.gen.P₀ bundle.deletedIds bundle.survivingSet ∧
  bundle.copies.length = R ∧
  IsAcceptedCopies bundle.inst bundle.epochBirthHist bundle.survivingSet bundle.copies

noncomputable def bundleEpochCost
    (R m cap : ℕ) (A_n P_fac : ℝ) : ENNReal :=
  (R : ENNReal) * ENNReal.ofReal ((m : ℝ) * A_n * P_fac) + ((R * cap : ℕ) : ENNReal)

noncomputable def bundleCredit
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ) (A_n P_fac : ℝ)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (bundle : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState) : ENNReal :=
  open Classical in
  copiesRemWork bundle.inst bundle.survivingSet bundle.copies +
    (if IsGoodCopies bundle.inst N cap bundle.copies then 0
     else 2 * bundleEpochCost R bundle.inst.gen.m cap A_n P_fac)

theorem runCompiledQueryFuel_add_acc
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    (R cap : ℕ) (curHist : UL.ExecutionHistory d) (q : UL.SearchQuery ι d_s) :
    ∀ (fuel : ℕ) (b : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState)
      (_ : IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N b)
      (acc : ℕ) (bs : List Bool),
      UL.runCompiledQueryFuel R cap curHist q fuel b acc bs =
        (UL.runCompiledQueryFuel R cap curHist q fuel b 0 bs).map
          (fun res => (res.1, res.2.1, acc + res.2.2)) := by
  intro fuel
  induction fuel with
  | zero =>
    intro _ _ _ _
    simp [UL.runCompiledQueryFuel]
  | succ fuel ih =>
    intro b hvb acc bs
    unfold UL.runCompiledQueryFuel
    dsimp only
    cases hm : (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).1 with
    | some ans =>
      dsimp only
      split_ifs <;> simp
    | none =>
      dsimp only
      have hreb := rebuildCompiledBundle_props (hvb.1 curHist) hvb.2.1 R
      by_cases hex : ∃ u v rw, bs = u ++ v ∧ UL.rebuildCompiledBundle R curHist b u = some rw
      · rcases hex with ⟨u, v, rw, rfl, hrw⟩
        rw [bindWithBits_eq_of_prefixFree hreb.1 _ hrw,
            bindWithBits_eq_of_prefixFree hreb.1 _ hrw]
        obtain ⟨hinst, hepoch, hsurv, hdel, hlen, hacc_rw, _⟩ := hreb.2.2.1 u rw hrw
        have hvb_rw : IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N rw.1 :=
          ⟨hinst ▸ hvb.1, hinst ▸ hdel ▸ hsurv ▸ hvb.2.1, hlen,
           by simpa [hinst, hepoch, hsurv] using hacc_rw⟩
        let qWork := (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2
        rw [ih rw.1 hvb_rw (acc + qWork + rw.2) v, ih rw.1 hvb_rw (0 + qWork + rw.2) v]
        cases UL.runCompiledQueryFuel R cap curHist q fuel rw.1 0 v with
        | none => simp
        | some res =>
          simp only [Option.map_some, Option.some.injEq, Prod.mk.injEq, true_and]
          omega
      · have hnone1 : UL.bindWithBits (UL.rebuildCompiledBundle R curHist b)
            (fun rw => UL.runCompiledQueryFuel R cap curHist q fuel rw.1
              (acc + (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2 + rw.2)) bs = none := by
          unfold UL.bindWithBits
          rw [dif_neg hex]
        have hnone2 : UL.bindWithBits (UL.rebuildCompiledBundle R curHist b)
            (fun rw => UL.runCompiledQueryFuel R cap curHist q fuel rw.1
              (0 + (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2 + rw.2)) bs = none := by
          unfold UL.bindWithBits
          rw [dif_neg hex]
        rw [hnone1, hnone2]
        simp

theorem runCompiledQueryFuel_eq_of_ge
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    (curHist : UL.ExecutionHistory d) (q : UL.SearchQuery ι d_s) :
    let R := c3_R_of netLogBound
    let cap := c3_cap_of A_n P_fac
    ∀ (L : ℕ) (bs : List Bool), bs.length ≤ L →
      ∀ (b : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState)
        (_ : IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N b)
        (_ : UL.IsCertifiedCompatible b.inst.gen b.inst.δ b.survivingSet q)
        (_ : q.z ∈ N)
        (fuel : ℕ) (_ : bs.length + 2 ≤ fuel) (acc : ℕ),
        UL.runCompiledQueryFuel R cap curHist q fuel b acc bs =
          UL.runCompiledQueryFuel R cap curHist q (bs.length + 2) b acc bs := by
  intro R cap L
  induction L using Nat.strong_induction_on with
  | h L ih =>
    intro bs hbsL b hvb hcomp hqz fuel hfuel acc
    obtain ⟨f', rfl⟩ : ∃ f', fuel = f' + 1 := ⟨fuel - 1, by omega⟩
    have hstep1 : bs.length + 2 = (bs.length + 1) + 1 := rfl
    rw [hstep1]
    unfold UL.runCompiledQueryFuel
    dsimp only
    cases hm : (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).1 with
    | some ans => rfl
    | none =>
      dsimp only
      have hreb := rebuildCompiledBundle_props (hvb.1 curHist) hvb.2.1 R
      by_cases hex : ∃ u v rw, bs = u ++ v ∧ UL.rebuildCompiledBundle R curHist b u = some rw
      · rcases hex with ⟨u, v, rw, h_uv, hrw⟩
        have h_eq1 := bindWithBits_eq_of_prefixFree hreb.1
          (fun rw' => UL.runCompiledQueryFuel R cap curHist q f' rw'.1
            (acc + (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2 + rw'.2)) (bs₂ := v) hrw
        have h_eq2 := bindWithBits_eq_of_prefixFree hreb.1
          (fun rw' => UL.runCompiledQueryFuel R cap curHist q (bs.length + 1) rw'.1
            (acc + (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2 + rw'.2)) (bs₂ := v) hrw
        subst h_uv
        rw [h_eq1, h_eq2]
        dsimp only
        obtain ⟨hinst, hepoch, hsurv, hdel, hlen, hacc_rw, _⟩ := hreb.2.2.1 u rw hrw
        have hvb_rw : IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N rw.1 :=
          ⟨hinst ▸ hvb.1, hinst ▸ hdel ▸ hsurv ▸ hvb.2.1, hlen,
           by simpa [hinst, hepoch, hsurv] using hacc_rw⟩
        have hcomp_rw : UL.IsCertifiedCompatible rw.1.inst.gen rw.1.inst.δ rw.1.survivingSet q := by
          simpa [hinst, hsurv] using hcomp
        cases u with
        | nil =>
          have hgood_rw : IsGoodCopies rw.1.inst N cap rw.1.copies := by
            simpa [hinst] using rebuild_nil_must_be_good (hvb.1 curHist) hvb.2.1 hrw
          obtain ⟨ans', hans'⟩ := queryRCopiesCapped_isSome_of_good
            (hvb_rw.1 rw.1.epochBirthHist) hvb_rw.2.1.subset hcomp_rw hqz hvb_rw.2.2.2 hgood_rw
          obtain ⟨f'', rfl⟩ : ∃ f'', f' = f'' + 1 := ⟨f' - 1, by simp at hfuel; omega⟩
          have hvlen : ([] ++ v).length + 1 = v.length + 1 := by simp
          rw [hvlen]
          unfold UL.runCompiledQueryFuel
          dsimp only
          simp [hans']
        | cons bit utl =>
          have hv_lt : v.length < L := by
            simp only [List.cons_append, List.length_cons, List.length_append] at hbsL
            omega
          have hf'_ge : v.length + 2 ≤ f' := by
            simp only [List.cons_append, List.length_cons, List.length_append] at hfuel
            omega
          have hbs_ge : v.length + 2 ≤ (bit :: utl ++ v).length + 1 := by
            simp only [List.cons_append, List.length_cons, List.length_append]
            omega
          rw [ih v.length hv_lt v le_rfl rw.1 hvb_rw hcomp_rw hqz f' hf'_ge _,
              ih v.length hv_lt v le_rfl rw.1 hvb_rw hcomp_rw hqz ((bit :: utl ++ v).length + 1) hbs_ge _]
      · unfold UL.bindWithBits
        rw [dif_neg hex, dif_neg hex]

theorem runCompiledQuery_unfold_some
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ) (curHist : UL.ExecutionHistory d)
    (b : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState)
    (q : UL.SearchQuery ι d_s) {ans : Option ι}
    (hm : (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).1 = some ans) :
    UL.runCompiledQuery R cap curHist b q =
      UL.pureWithBits (b, ans, (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2) := by
  funext bs
  unfold UL.runCompiledQuery
  have h1 : bs.length + 2 = (bs.length + 1) + 1 := rfl
  rw [h1]
  unfold UL.runCompiledQueryFuel UL.pureWithBits
  dsimp only
  simp [hm]

theorem runCompiledQuery_unfold_none
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    (curHist : UL.ExecutionHistory d)
    (b : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState)
    (q : UL.SearchQuery ι d_s)
    (hvb : IsValidLiveBundle (n := n) (c3_R_of netLogBound) σ A_n P_fac netLogBound N b)
    (hcomp : UL.IsCertifiedCompatible b.inst.gen b.inst.δ b.survivingSet q)
    (hqz : q.z ∈ N)
    (hm : (UL.queryRCopiesCapped b.inst b.survivingSet q (c3_cap_of A_n P_fac) b.copies).1 = none) :
    let R := c3_R_of netLogBound
    let cap := c3_cap_of A_n P_fac
    let qWork := (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2
    UL.runCompiledQuery R cap curHist b q =
      UL.bindWithBits (UL.rebuildCompiledBundle R curHist b) (fun rw =>
        fun bs₂ => (UL.runCompiledQuery R cap curHist rw.1 q bs₂).map
          (fun res => (res.1, res.2.1, qWork + rw.2 + res.2.2))) := by
  intro R cap qWork
  funext bs
  have hreb := rebuildCompiledBundle_props (hvb.1 curHist) hvb.2.1 R
  have h1 : bs.length + 2 = (bs.length + 1) + 1 := rfl
  have hm' : (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).1 = none := hm
  conv_lhs =>
    unfold UL.runCompiledQuery
    rw [h1]
    unfold UL.runCompiledQueryFuel
  dsimp only
  simp only [hm', Nat.zero_add]
  by_cases hex : ∃ u v rw, bs = u ++ v ∧ UL.rebuildCompiledBundle R curHist b u = some rw
  · rcases hex with ⟨u, v, rw, rfl, hrw⟩
    rw [bindWithBits_eq_of_prefixFree hreb.1 _ hrw,
        bindWithBits_eq_of_prefixFree hreb.1 _ hrw]
    obtain ⟨hinst, hepoch, hsurv, hdel, hlen, hacc_rw, _⟩ := hreb.2.2.1 u rw hrw
    have hvb_rw : IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N rw.1 :=
      ⟨hinst ▸ hvb.1, hinst ▸ hdel ▸ hsurv ▸ hvb.2.1, hlen,
       by simpa [hinst, hepoch, hsurv] using hacc_rw⟩
    have hcomp_rw : UL.IsCertifiedCompatible rw.1.inst.gen rw.1.inst.δ rw.1.survivingSet q := by
      simpa [hinst, hsurv] using hcomp
    cases u with
    | nil =>
      have hgood_rw : IsGoodCopies rw.1.inst N cap rw.1.copies := by
        simpa [hinst] using rebuild_nil_must_be_good (hvb.1 curHist) hvb.2.1 hrw
      obtain ⟨ans', hans'⟩ := queryRCopiesCapped_isSome_of_good
        (hvb_rw.1 rw.1.epochBirthHist) hvb_rw.2.1.subset hcomp_rw hqz hvb_rw.2.2.2 hgood_rw
      have hv1 : ([] ++ v).length + 1 = v.length + 1 := by simp
      have hv2 : v.length + 2 = (v.length + 1) + 1 := rfl
      rw [hv1]
      unfold UL.runCompiledQuery
      rw [hv2]
      unfold UL.runCompiledQueryFuel
      dsimp only
      simp only [hans', Nat.zero_add]
      cases v <;> simp [qWork, Nat.add_assoc]
    | cons bit utl =>
      have hv_ge : v.length + 2 ≤ (bit :: utl ++ v).length + 1 := by
        simp only [List.cons_append, List.length_cons, List.length_append]
        omega
      rw [runCompiledQueryFuel_eq_of_ge curHist q v.length v le_rfl rw.1 hvb_rw hcomp_rw hqz
            ((bit :: utl ++ v).length + 1) hv_ge _,
          runCompiledQueryFuel_add_acc R cap curHist q (v.length + 2) rw.1 hvb_rw _ v]
      rfl
  · simp only [UL.bindWithBits, hex, ↓reduceDIte]

open Classical in
theorem runCompiledQuery_props
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    (curHist : UL.ExecutionHistory d)
    (bundle : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState)
    (q : UL.SearchQuery ι d_s)
    (hvb : IsValidLiveBundle (n := n) (c3_R_of netLogBound) σ A_n P_fac netLogBound N bundle)
    (hcomp : UL.IsCertifiedCompatible bundle.inst.gen bundle.inst.δ bundle.survivingSet q)
    (hqz : q.z ∈ N) :
    let R := c3_R_of netLogBound
    let cap := c3_cap_of A_n P_fac
    IsPrefixFree (UL.runCompiledQuery R cap curHist bundle q) ∧
    haltProb (UL.runCompiledQuery R cap curHist bundle q) = 1 ∧
    (∀ bs qw, UL.runCompiledQuery R cap curHist bundle q bs = some qw →
      qw.1.inst = bundle.inst ∧
      qw.1.survivingSet = bundle.survivingSet ∧
      qw.1.deletedIds = bundle.deletedIds ∧
      IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N qw.1 ∧
      bundle.inst.gen.IsCorrectAnswer bundle.survivingSet q qw.2.1) ∧
    expWithBits (UL.runCompiledQuery R cap curHist bundle q)
      (fun qw => (qw.2.2 : ENNReal) + bundleCredit R cap A_n P_fac N qw.1) ≤
      ((R * cap : ℕ) : ENNReal) + bundleCredit R cap A_n P_fac N bundle := by
  intro R cap
  -- Step 1: Prefix-freeness by strong induction on `bs₁.length`
  have hpf_all : ∀ (L : ℕ) (b : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState),
      IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N b →
      UL.IsCertifiedCompatible b.inst.gen b.inst.δ b.survivingSet q →
      ∀ bs₁ bs₂ qw₁ qw₂,
        bs₁.length ≤ L →
        UL.runCompiledQuery R cap curHist b q bs₁ = some qw₁ →
        UL.runCompiledQuery R cap curHist b q bs₂ = some qw₂ →
        bs₁ <+: bs₂ → bs₁ = bs₂ := by
    intro L
    induction L using Nat.strong_induction_on with
    | h L ih =>
      intro b hb hcb bs₁ bs₂ qw₁ qw₂ hlen1 h1 h2 hpref
      cases hm : (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).1 with
      | some ans =>
        rw [runCompiledQuery_unfold_some R cap curHist b q hm] at h1 h2
        exact isPrefixFree_pureWithBits _ bs₁ bs₂ qw₁ qw₂ h1 h2 hpref
      | none =>
        rw [runCompiledQuery_unfold_none curHist b q hb hcb hqz hm] at h1 h2
        have hreb := rebuildCompiledBundle_props (hb.1 curHist) hb.2.1 R
        rw [bindWithBits_eq_some_iff hreb.1] at h1 h2
        rcases h1 with ⟨u₁, v₁, rw₁, rfl, hu₁, hv₁⟩
        rcases h2 with ⟨u₂, v₂, rw₂, rfl, hu₂, hv₂⟩
        rcases hpref with ⟨w, hw⟩
        have heq : u₁ ++ (v₁ ++ w) = u₂ ++ v₂ := by simpa [List.append_assoc] using hw
        obtain ⟨rfl, hvw, rfl⟩ := prefixFree_append_unique hreb.1 heq hu₁ hu₂
        obtain ⟨hinst, hepoch, hsurv, hdel, hlen_rw, hacc_rw, _⟩ := hreb.2.2.1 u₁ rw₁ hu₁
        have hvb_rw : IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N rw₁.1 :=
          ⟨hinst ▸ hb.1, hinst ▸ hdel ▸ hsurv ▸ hb.2.1, hlen_rw,
           by simpa [hinst, hepoch, hsurv] using hacc_rw⟩
        have hcomp_rw : UL.IsCertifiedCompatible rw₁.1.inst.gen rw₁.1.inst.δ rw₁.1.survivingSet q := by
          simpa [hinst, hsurv] using hcb
        simp only [Option.map_eq_some_iff] at hv₁ hv₂
        rcases hv₁ with ⟨res₁, hres₁, _⟩
        rcases hv₂ with ⟨res₂, hres₂, _⟩
        cases u₁ with
        | nil =>
          have hgood_rw : IsGoodCopies rw₁.1.inst N cap rw₁.1.copies := by
            simpa [hinst] using rebuild_nil_must_be_good (hb.1 curHist) hb.2.1 hu₁
          obtain ⟨ans', hans'⟩ := queryRCopiesCapped_isSome_of_good
            (hvb_rw.1 rw₁.1.epochBirthHist) hvb_rw.2.1.subset hcomp_rw hqz hvb_rw.2.2.2 hgood_rw
          rw [runCompiledQuery_unfold_some R cap curHist rw₁.1 q hans'] at hres₁ hres₂
          have hv_eq := isPrefixFree_pureWithBits _ v₁ v₂ res₁ res₂ hres₁ hres₂ ⟨w, hvw⟩
          rw [hv_eq]
        | cons bit utl =>
          have hv_lt : v₁.length < L := by
            simp only [List.cons_append, List.length_cons, List.length_append] at hlen1
            omega
          have hv_eq := ih v₁.length hv_lt rw₁.1 hvb_rw hcomp_rw v₁ v₂ res₁ res₂ le_rfl hres₁ hres₂ ⟨w, hvw⟩
          rw [hv_eq]
  have hpf_main : IsPrefixFree (UL.runCompiledQuery R cap curHist bundle q) :=
    fun bs₁ bs₂ qw₁ qw₂ h1 h2 hpref =>
      hpf_all bs₁.length bundle hvb hcomp bs₁ bs₂ qw₁ qw₂ le_rfl h1 h2 hpref

  -- Step 2: Halting probability = 1 via `1 - (1/2)^K ≤ haltProb`
  have hhp_ge : ∀ (K : ℕ) (b : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState),
      IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N b →
      UL.IsCertifiedCompatible b.inst.gen b.inst.δ b.survivingSet q →
      1 - ((2 : ENNReal)⁻¹) ^ K ≤ haltProb (UL.runCompiledQuery R cap curHist b q) := by
    intro K
    induction K with
    | zero =>
      intro _ _ _
      simp
    | succ K ih =>
      intro b hb hcb
      cases hm : (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).1 with
      | some ans =>
        rw [runCompiledQuery_unfold_some R cap curHist b q hm, haltProb_pureWithBits]
        exact tsub_le_self
      | none =>
        rw [runCompiledQuery_unfold_none curHist b q hb hcb hqz hm]
        have hreb := rebuildCompiledBundle_props (hb.1 curHist) hb.2.1 R
        let gSub := fun rw : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState × ℕ =>
          fun bs₂ : List Bool => (UL.runCompiledQuery R cap curHist rw.1 q bs₂).map
            (fun res => (res.1, res.2.1,
              (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2 + rw.2 + res.2.2))
        rw [← expWithBits_one_eq_haltProb, expWithBits_bind hreb.1]
        have hgSub_hp : ∀ rw : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState × ℕ,
            expWithBits (gSub rw) (fun _ => 1) = haltProb (UL.runCompiledQuery R cap curHist rw.1 q) := by
          intro rw
          unfold expWithBits haltProb gSub
          refine tsum_congr (fun bs₂ => ?_)
          cases UL.runCompiledQuery R cap curHist rw.1 q bs₂ <;> simp
        rw [expWithBits_congr (fun _ => rfl) (fun _ rw _ => hgSub_hp rw)]
        let pK : ENNReal := ((2 : ENNReal)⁻¹) ^ K
        let BadP := expWithBits (UL.rebuildCompiledBundle R curHist b)
          (fun rw => if ¬ IsGoodCopies b.inst N cap rw.1.copies then (1 : ENNReal) else 0)
        have hBadP_le : BadP ≤ (2 : ENNReal)⁻¹ := rebuildCompiledBundle_bad_prob_le_half (hb.1 curHist) hb.2.1
        have hsum_ge_one : (1 : ENNReal) ≤
            expWithBits (UL.rebuildCompiledBundle R curHist b)
              (fun rw => haltProb (UL.runCompiledQuery R cap curHist rw.1 q)) + BadP * pK := by
          have h1 : haltProb (UL.rebuildCompiledBundle R curHist b) ≤
              expWithBits (UL.rebuildCompiledBundle R curHist b)
                (fun rw => haltProb (UL.runCompiledQuery R cap curHist rw.1 q) +
                  (if ¬ IsGoodCopies b.inst N cap rw.1.copies then (1 : ENNReal) else 0) * pK) := by
            rw [← expWithBits_one_eq_haltProb]
            refine expWithBits_mono (fun bs₁ rw hrw => ?_)
            obtain ⟨hinst, hepoch, hsurv, hdel, hlen_rw, hacc_rw, _⟩ := hreb.2.2.1 bs₁ rw hrw
            have hvb_rw : IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N rw.1 :=
              ⟨hinst ▸ hb.1, hinst ▸ hdel ▸ hsurv ▸ hb.2.1, hlen_rw,
               by simpa [hinst, hepoch, hsurv] using hacc_rw⟩
            have hcomp_rw : UL.IsCertifiedCompatible rw.1.inst.gen rw.1.inst.δ rw.1.survivingSet q := by
              simpa [hinst, hsurv] using hcb
            by_cases hgood : IsGoodCopies b.inst N cap rw.1.copies
            · have hgood' : IsGoodCopies rw.1.inst N cap rw.1.copies := by simpa [hinst] using hgood
              obtain ⟨ans', hans'⟩ := queryRCopiesCapped_isSome_of_good
                (hvb_rw.1 rw.1.epochBirthHist) hvb_rw.2.1.subset hcomp_rw hqz hvb_rw.2.2.2 hgood'
              rw [runCompiledQuery_unfold_some R cap curHist rw.1 q hans', haltProb_pureWithBits]
              simp [hgood]
            · simp only [hgood, not_false_eq_true, ↓reduceIte, one_mul]
              exact tsub_le_iff_right.mp (ih rw.1 hvb_rw hcomp_rw)
          rw [hreb.2.1, expWithBits_add, expWithBits_const_mul] at h1
          exact h1
        have hmul_le : BadP * pK ≤ ((2 : ENNReal)⁻¹) ^ (K + 1) := by
          rw [pow_succ']
          exact mul_le_mul_right' hBadP_le pK
        refine tsub_le_iff_right.mpr (hsum_ge_one.trans ?_)
        gcongr

  have hhp_one : haltProb (UL.runCompiledQuery R cap curHist bundle q) = 1 := by
    apply le_antisymm hpf_main.haltProb_le_one
    refine ennreal_le_of_forall_pos_le_add (fun ε hε => ?_)
    obtain ⟨K, hK⟩ := exists_pow_lt_of_lt_one hε (by norm_num : (2 : ℝ)⁻¹ < 1)
    have hK_enn : ((2 : ENNReal)⁻¹) ^ K ≤ ENNReal.ofReal ε := by
      have heq : ENNReal.ofReal (((2 : ℝ)⁻¹) ^ K) = ((2 : ENNReal)⁻¹) ^ K := by
        rw [ENNReal.ofReal_pow (by positivity), ENNReal.ofReal_inv_of_pos (by norm_num)]
        norm_num
      rw [← heq]
      exact ENNReal.ofReal_le_ofReal hK.le
    have hge := hhp_ge K bundle hvb hcomp
    refine (tsub_le_iff_right.mp hge).trans ?_
    gcongr

  -- Step 3: Output invariants and expected work + `bundleCredit` by finite `Fuel` induction
  have hpf_fuel : ∀ F₀ (b₀ : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState),
      IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N b₀ →
      IsPrefixFree (UL.runCompiledQueryFuel R cap curHist q F₀ b₀ 0) := by
    intro F₀
    induction F₀ with
    | zero =>
      intro _ _ _ _ _ _ h
      simp [UL.runCompiledQueryFuel] at h
    | succ F₀ ihF =>
      intro b₀ hb₀ u₁ u₂ r₁ r₂ h1 h2 hp
      unfold UL.runCompiledQueryFuel at h1 h2
      dsimp only at h1 h2
      cases hm0 : (UL.queryRCopiesCapped b₀.inst b₀.survivingSet q cap b₀.copies).1 with
      | some ans0 =>
        rw [hm0] at h1 h2
        dsimp only at h1 h2
        split_ifs at h1 h2 with he1 he2
        rw [List.isEmpty_iff.mp he1, List.isEmpty_iff.mp he2]
      | none =>
        rw [hm0] at h1 h2
        dsimp only at h1 h2
        have hreb0 := rebuildCompiledBundle_props (hb₀.1 curHist) hb₀.2.1 R
        rw [bindWithBits_eq_some_iff hreb0.1] at h1 h2
        rcases h1 with ⟨x₁, y₁, rw0₁, rfl, hx₁, hy₁⟩
        rcases h2 with ⟨x₂, y₂, rw0₂, rfl, hx₂, hy₂⟩
        rcases hp with ⟨w0, hw0⟩
        have heq0 : x₁ ++ (y₁ ++ w0) = x₂ ++ y₂ := by simpa [List.append_assoc] using hw0
        obtain ⟨rfl, hyw, rfl⟩ := prefixFree_append_unique hreb0.1 heq0 hx₁ hx₂
        obtain ⟨hi0, he0, hs0, hd0, hl0, ha0, _⟩ := hreb0.2.2.1 x₁ rw0₁ hx₁
        have hvb0 : IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N rw0₁.1 :=
          ⟨hi0 ▸ hb₀.1, hi0 ▸ hd0 ▸ hs0 ▸ hb₀.2.1, hl0,
           by simpa [hi0, he0, hs0] using ha0⟩
        rw [runCompiledQueryFuel_add_acc R cap curHist q F₀ rw0₁.1 hvb0 _ y₁] at hy₁
        rw [runCompiledQueryFuel_add_acc R cap curHist q F₀ rw0₁.1 hvb0 _ y₂] at hy₂
        simp only [Option.map_eq_some_iff] at hy₁ hy₂
        rcases hy₁ with ⟨z₁, hz₁, _⟩
        rcases hy₂ with ⟨z₂, hz₂, _⟩
        rw [ihF rw0₁.1 hvb0 y₁ y₂ z₁ z₂ hz₁ hz₂ ⟨w0, hyw⟩]

  have hfuel_props : ∀ (Fuel : ℕ)
      (b : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState),
      IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N b →
      UL.IsCertifiedCompatible b.inst.gen b.inst.δ b.survivingSet q →
      (∀ bs qw, UL.runCompiledQueryFuel R cap curHist q Fuel b 0 bs = some qw →
        qw.1.inst = b.inst ∧
        qw.1.survivingSet = b.survivingSet ∧
        qw.1.deletedIds = b.deletedIds ∧
        IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N qw.1 ∧
        b.inst.gen.IsCorrectAnswer b.survivingSet q qw.2.1) ∧
      expWithBits (UL.runCompiledQueryFuel R cap curHist q Fuel b 0)
        (fun qw => (qw.2.2 : ENNReal) + bundleCredit R cap A_n P_fac N qw.1) ≤
        ((R * cap : ℕ) : ENNReal) + bundleCredit R cap A_n P_fac N b := by
    intro Fuel
    induction Fuel with
    | zero =>
      intro b _ _
      refine ⟨fun _ _ h => by simp [UL.runCompiledQueryFuel] at h, ?_⟩
      simp [expWithBits, UL.runCompiledQueryFuel]
    | succ Fuel ih =>
      intro b hb hcb
      have hqWork_le : (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2 ≤ R * cap := by
        have h1 := queryRCopiesCapped_work_le b.inst b.survivingSet q cap b.copies
        simpa [hb.2.2.1] using h1
      cases hm : (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).1 with
      | some ans =>
        have hcorr : b.inst.gen.IsCorrectAnswer b.survivingSet q ans :=
          queryRCopiesCapped_correct (hb.1 b.epochBirthHist) hb.2.1.subset hcb cap b.copies hb.2.2.2 hm
        refine ⟨?_, ?_⟩
        · intro bs qw hrun
          unfold UL.runCompiledQueryFuel at hrun
          dsimp only at hrun
          rw [hm] at hrun
          dsimp only at hrun
          split_ifs at hrun
          simp only [Nat.zero_add, Option.some.injEq] at hrun
          subst hrun
          exact ⟨rfl, rfl, rfl, hb, hcorr⟩
        · have heq_pure : UL.runCompiledQueryFuel R cap curHist q (Fuel + 1) b 0 =
              UL.pureWithBits (b, ans, (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2) := by
            funext bs
            unfold UL.runCompiledQueryFuel UL.pureWithBits
            dsimp only
            simp [hm]
          rw [heq_pure, expWithBits_pure]
          gcongr
      | none =>
        have hnot_good : ¬ IsGoodCopies b.inst N cap b.copies := by
          intro hgood
          obtain ⟨ans', hans'⟩ := queryRCopiesCapped_isSome_of_good
            (hb.1 b.epochBirthHist) hb.2.1.subset hcb hqz hb.2.2.2 hgood
          rw [hm] at hans'
          simp at hans'
        have hreb := rebuildCompiledBundle_props (hb.1 curHist) hb.2.1 R
        refine ⟨?_, ?_⟩
        · intro bs qw hrun
          unfold UL.runCompiledQueryFuel at hrun
          dsimp only at hrun
          rw [hm] at hrun
          dsimp only at hrun
          rw [bindWithBits_eq_some_iff hreb.1] at hrun
          rcases hrun with ⟨bs₁, bs₂, rw, _, hrw, h2⟩
          obtain ⟨hinst, hepoch, hsurv, hdel, hlen_rw, hacc_rw, _⟩ := hreb.2.2.1 bs₁ rw hrw
          have hvb_rw : IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N rw.1 :=
            ⟨hinst ▸ hb.1, hinst ▸ hdel ▸ hsurv ▸ hb.2.1, hlen_rw,
             by simpa [hinst, hepoch, hsurv] using hacc_rw⟩
          have hcomp_rw : UL.IsCertifiedCompatible rw.1.inst.gen rw.1.inst.δ rw.1.survivingSet q := by
            simpa [hinst, hsurv] using hcb
          rw [runCompiledQueryFuel_add_acc R cap curHist q Fuel rw.1 hvb_rw _ bs₂] at h2
          simp only [Option.map_eq_some_iff] at h2
          rcases h2 with ⟨res, hres, rfl⟩
          obtain ⟨hi2, hs2, hd2, hvb2, hcorr2⟩ := (ih rw.1 hvb_rw hcomp_rw).1 bs₂ res hres
          refine ⟨hi2.trans hinst, hs2.trans hsurv, hd2.trans hdel, hvb2, ?_⟩
          simpa [hinst, hsurv] using hcorr2
        · let qWork := (UL.queryRCopiesCapped b.inst b.survivingSet q cap b.copies).2
          let M := bundleEpochCost R b.inst.gen.m cap A_n P_fac
          have hbind_eq : UL.runCompiledQueryFuel R cap curHist q (Fuel + 1) b 0 =
              UL.bindWithBits (UL.rebuildCompiledBundle R curHist b) (fun rw =>
                UL.runCompiledQueryFuel R cap curHist q Fuel rw.1 (qWork + rw.2)) := by
            funext bs
            unfold UL.runCompiledQueryFuel
            dsimp only
            simp [hm, qWork]
          rw [hbind_eq, expWithBits_bind hreb.1]
          have hinner_le : expWithBits (UL.rebuildCompiledBundle R curHist b)
              (fun rw => expWithBits (UL.runCompiledQueryFuel R cap curHist q Fuel rw.1 (qWork + rw.2))
                (fun qw => (qw.2.2 : ENNReal) + bundleCredit R cap A_n P_fac N qw.1)) ≤
              expWithBits (UL.rebuildCompiledBundle R curHist b)
                (fun rw =>
                  (((qWork : ENNReal) + ((R * cap : ℕ) : ENNReal)) +
                    ((rw.2 : ENNReal) + copiesRemWork b.inst b.survivingSet rw.1.copies)) +
                  (if ¬ IsGoodCopies b.inst N cap rw.1.copies then (1 : ENNReal) else 0) * (2 * M)) := by
            refine expWithBits_mono (fun bs₁ rw hrw => ?_)
            obtain ⟨hinst, hepoch, hsurv, hdel, hlen_rw, hacc_rw, _⟩ := hreb.2.2.1 bs₁ rw hrw
            have hvb_rw : IsValidLiveBundle (n := n) R σ A_n P_fac netLogBound N rw.1 :=
              ⟨hinst ▸ hb.1, hinst ▸ hdel ▸ hsurv ▸ hb.2.1, hlen_rw,
               by simpa [hinst, hepoch, hsurv] using hacc_rw⟩
            have hcomp_rw : UL.IsCertifiedCompatible rw.1.inst.gen rw.1.inst.δ rw.1.survivingSet q := by
              simpa [hinst, hsurv] using hcb
            have hshift_exp :
                expWithBits (UL.runCompiledQueryFuel R cap curHist q Fuel rw.1 (qWork + rw.2))
                  (fun qw => (qw.2.2 : ENNReal) + bundleCredit R cap A_n P_fac N qw.1) =
                haltProb (UL.runCompiledQueryFuel R cap curHist q Fuel rw.1 0) *
                  ((qWork : ENNReal) + (rw.2 : ENNReal)) +
                expWithBits (UL.runCompiledQueryFuel R cap curHist q Fuel rw.1 0)
                  (fun res => (res.2.2 : ENNReal) + bundleCredit R cap A_n P_fac N res.1) := by
              rw [← expWithBits_const, ← expWithBits_add]
              unfold expWithBits
              refine tsum_congr (fun bs₂ => ?_)
              rw [runCompiledQueryFuel_add_acc R cap curHist q Fuel rw.1 hvb_rw (qWork + rw.2) bs₂]
              cases UL.runCompiledQueryFuel R cap curHist q Fuel rw.1 0 bs₂ with
              | none => rfl
              | some res =>
                simp only [Option.map_some, Nat.cast_add]
                ring
            have hhp_fuel_le : haltProb (UL.runCompiledQueryFuel R cap curHist q Fuel rw.1 0) ≤ 1 :=
              (hpf_fuel Fuel rw.1 hvb_rw).haltProb_le_one
            have hcred_rw : bundleCredit R cap A_n P_fac N rw.1 =
                copiesRemWork b.inst b.survivingSet rw.1.copies +
                (if ¬ IsGoodCopies b.inst N cap rw.1.copies then (1 : ENNReal) else 0) * (2 * M) := by
              unfold bundleCredit
              simp only [hinst, hsurv]
              by_cases hg : IsGoodCopies b.inst N cap rw.1.copies <;> simp [hg, M]
            calc
              _ = haltProb (UL.runCompiledQueryFuel R cap curHist q Fuel rw.1 0) *
                    ((qWork : ENNReal) + (rw.2 : ENNReal)) +
                  expWithBits (UL.runCompiledQueryFuel R cap curHist q Fuel rw.1 0)
                    (fun res => (res.2.2 : ENNReal) + bundleCredit R cap A_n P_fac N res.1) := hshift_exp
              _ ≤ 1 * ((qWork : ENNReal) + (rw.2 : ENNReal)) +
                  (((R * cap : ℕ) : ENNReal) + bundleCredit R cap A_n P_fac N rw.1) := by
                    gcongr
                    exact (ih rw.1 hvb_rw hcomp_rw).2
              _ = _ := by
                    rw [hcred_rw]
                    ring
          have hbad_half := rebuildCompiledBundle_bad_prob_le_half (hb.1 curHist) hb.2.1
          have hhalf_2M : (2 : ENNReal)⁻¹ * (2 * M) = M := by
            rw [← mul_assoc, ENNReal.inv_mul_cancel (by norm_num) (by simp), one_mul]
          have hcred_b : 2 * M ≤ bundleCredit R cap A_n P_fac N b := by
            unfold bundleCredit
            simp only [hnot_good, ↓reduceIte]
            exact le_add_self
          calc
            _ ≤ expWithBits (UL.rebuildCompiledBundle R curHist b)
                  (fun rw =>
                    (((qWork : ENNReal) + ((R * cap : ℕ) : ENNReal)) +
                      ((rw.2 : ENNReal) + copiesRemWork b.inst b.survivingSet rw.1.copies)) +
                    (if ¬ IsGoodCopies b.inst N cap rw.1.copies then (1 : ENNReal) else 0) * (2 * M)) := hinner_le
            _ = (((qWork : ENNReal) + ((R * cap : ℕ) : ENNReal)) +
                  expWithBits (UL.rebuildCompiledBundle R curHist b)
                    (fun rw => (rw.2 : ENNReal) + copiesRemWork b.inst b.survivingSet rw.1.copies)) +
                expWithBits (UL.rebuildCompiledBundle R curHist b)
                  (fun rw => if ¬ IsGoodCopies b.inst N cap rw.1.copies then (1 : ENNReal) else 0) * (2 * M) := by
                  rw [expWithBits_add, expWithBits_const_add_of_haltProb_one hreb.2.1, expWithBits_const_mul]
            _ ≤ (((qWork : ENNReal) + ((R * cap : ℕ) : ENNReal)) +
                  (R : ENNReal) * ENNReal.ofReal ((b.inst.gen.m : ℝ) * A_n * P_fac)) +
                (2 : ENNReal)⁻¹ * (2 * M) := by
                  gcongr
                  exact hreb.2.2.2
            _ = (qWork : ENNReal) + 2 * M := by
                  rw [hhalf_2M]
                  unfold M bundleEpochCost
                  ring
            _ ≤ ((R * cap : ℕ) : ENNReal) + bundleCredit R cap A_n P_fac N b := by
                  gcongr

  refine ⟨hpf_main, hhp_one, ?_, ?_⟩
  · intro bs qw hrun
    exact (hfuel_props (bs.length + 2) bundle hvb hcomp).1 bs qw hrun
  · let g : (UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState × Option ι × ℕ) → ENNReal :=
      fun qw => (qw.2.2 : ENNReal) + bundleCredit R cap A_n P_fac N qw.1
    let F : (List Bool → Option (UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState × Option ι × ℕ)) →
        List Bool → ENNReal := fun m' bs =>
      match m' bs with
      | some qw => UL.bitListProb bs * g qw
      | none => 0
    have hexp : ∀ m', expWithBits m' g = ∑' bs, F m' bs := fun m' => by
      unfold expWithBits
      refine tsum_congr (fun bs => ?_)
      dsimp only [F]
      cases m' bs <;> rfl
    change expWithBits (UL.runCompiledQuery R cap curHist bundle q) g ≤ _
    rw [hexp (UL.runCompiledQuery R cap curHist bundle q), ENNReal.tsum_eq_iSup_sum]
    refine iSup_le (fun s => ?_)
    let Fuel := s.sup List.length + 2
    have hsum_eq : ∑ bs ∈ s, F (UL.runCompiledQuery R cap curHist bundle q) bs =
        ∑ bs ∈ s, F (UL.runCompiledQueryFuel R cap curHist q Fuel bundle 0) bs := by
      refine Finset.sum_congr rfl (fun bs hbs => ?_)
      have hge : bs.length + 2 ≤ Fuel :=
        Nat.add_le_add_right (Finset.le_sup (f := List.length) hbs) 2
      dsimp only [F]
      unfold UL.runCompiledQuery
      rw [runCompiledQueryFuel_eq_of_ge curHist q bs.length bs le_rfl bundle hvb hcomp hqz Fuel hge 0]
    calc
      ∑ bs ∈ s, F (UL.runCompiledQuery R cap curHist bundle q) bs
        = ∑ bs ∈ s, F (UL.runCompiledQueryFuel R cap curHist q Fuel bundle 0) bs := hsum_eq
      _ ≤ ∑' bs, F (UL.runCompiledQueryFuel R cap curHist q Fuel bundle 0) bs := ENNReal.sum_le_tsum s
      _ = expWithBits (UL.runCompiledQueryFuel R cap curHist q Fuel bundle 0) g :=
            (hexp (UL.runCompiledQueryFuel R cap curHist q Fuel bundle 0)).symm
      _ ≤ ((R * cap : ℕ) : ENNReal) + bundleCredit R cap A_n P_fac N bundle :=
            (hfuel_props Fuel bundle hvb hcomp).2

end UL.Proof.lem_C_3.RacerCG
