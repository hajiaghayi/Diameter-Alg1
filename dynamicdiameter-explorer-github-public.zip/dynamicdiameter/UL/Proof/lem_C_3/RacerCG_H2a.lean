import Mathlib
import UL.Proof.lem_C_3.RacerCG_H1
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof.lem_C_3.RacerCG

/-! ### 1. Horizon-free compiler parameter formulas -/

noncomputable def c3_R_of (nb : ℝ) : ℕ :=
  Nat.ceil nb + 2

noncomputable def c3_cap_of (A_n P : ℝ) : ℕ :=
  Nat.floor (4 * A_n * P)

theorem one_le_c3_R_of (nb : ℝ) : 1 ≤ c3_R_of nb := by
  unfold c3_R_of
  omega

theorem c3_cap_of_le {A_n P : ℝ} (hA : 0 ≤ A_n) (hP : 0 ≤ P) :
    (c3_cap_of A_n P : ℝ) ≤ 4 * A_n * P :=
  Nat.floor_le (by positivity)

theorem lt_c3_cap_of_add_one (A_n P : ℝ) :
    4 * A_n * P < ((c3_cap_of A_n P + 1 : ℕ) : ℝ) := by
  unfold c3_cap_of
  push_cast
  exact Nat.lt_floor_add_one (4 * A_n * P)

theorem ennreal_le_ofReal_of_toReal_le {x : ENNReal} {b : ℝ}
    (hne : x ≠ ⊤) (hle : x.toReal ≤ b) :
    x ≤ ENNReal.ofReal b := by
  rw [← ENNReal.ofReal_toReal hne]
  exact ENNReal.ofReal_le_ofReal hle

/-! ### 2. Pure remaining deletion policies and `remCopyWork` -/

theorem ofFn_finCongr_cons {m k : ℕ} (hm : m = k + 1) (bs₀ : List Bool) (rest : Fin k → List Bool) :
    List.ofFn (Equiv.arrowCongr (finCongr hm.symm) (Equiv.refl _) (Fin.cons bs₀ rest)) =
      bs₀ :: List.ofFn rest := by
  subst hm
  simp [List.ofFn_succ]

theorem prefixTraceProb_finCongr_cons {m k : ℕ} (hm : m = k + 1) (bs₀ : List Bool) (rest : Fin k → List Bool) :
    UL.prefixTraceProb (Equiv.arrowCongr (finCongr hm.symm) (Equiv.refl _) (Fin.cons bs₀ rest)) =
      UL.bitListProb bs₀ * UL.prefixTraceProb rest := by
  subst hm
  simpa using prefixTraceProb_cons bs₀ rest


abbrev PureDelPolicy (ι : Type) (d : ℕ) (PhaseState : Type) : Type :=
  Finset ι → PhaseState → List (ι × List Bool) → Option (UL.ExecutionHistory d × ι)

noncomputable def runPureDelSteps
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState) (pol : PureDelPolicy ι d PhaseState) :
    Finset ι → PhaseState → List (ι × List Bool) → List (List Bool) →
      Option (Finset ι × PhaseState × List (ι × List Bool) × ℕ)
  | S, ph, log, [] => some (S, ph, log, 0)
  | S, ph, log, bs :: rest =>
      match pol S ph log with
      | none =>
          match bs with
          | [] => runPureDelSteps inst bState pol S ph log rest
          | _ :: _ => none
      | some (stepHist, i) =>
          if i ∈ S then
            match inst.deleteWithBits stepHist bState S ph i bs with
            | none => none
            | some dOut =>
                match runPureDelSteps inst bState pol (S.erase i) dOut.nextPhase
                    (log ++ [(i, bs)]) rest with
                | none => none
                | some (S', ph', log', wRest) =>
                    some (S', ph', log', dOut.work + wRest)
          else
            none

def IsValidPureDelPolicyFromLog
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState) (S₀ : Finset ι) (ph₀ : PhaseState)
    (log₀ : List (ι × List Bool))
    (pol : PureDelPolicy ι d PhaseState) : Prop :=
  ∀ (bss : List (List Bool)) (S' : Finset ι) (ph' : PhaseState)
    (log' : List (ι × List Bool)) (w : ℕ),
    runPureDelSteps inst bState pol S₀ ph₀ log₀ bss = some (S', ph', log', w) →
      ∀ stepHist : UL.ExecutionHistory d, ∀ i : ι,
        pol S' ph' log' = some (stepHist, i) → i ∈ S'

def IsValidPureDelPolicy
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState) (S₀ : Finset ι) (ph₀ : PhaseState)
    (pol : PureDelPolicy ι d PhaseState) : Prop :=
  IsValidPureDelPolicyFromLog inst bState S₀ ph₀ [] pol

instance instNonemptyValidPureDelPolicy
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState) (S₀ : Finset ι) (ph₀ : PhaseState) :
    Nonempty { p : PureDelPolicy ι d PhaseState // IsValidPureDelPolicy inst bState S₀ ph₀ p } :=
  ⟨⟨fun _ _ _ => none, fun _ _ _ _ _ _ _ _ h => by simp at h⟩⟩

noncomputable def remCopyWork
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState) (S : Finset ι) (ph : PhaseState) : ENNReal :=
  ⨆ pol : { p : PureDelPolicy ι d PhaseState // IsValidPureDelPolicy inst bState S ph p },
    ∑' tr : Fin S.card → List Bool,
      match runPureDelSteps inst bState pol.1 S ph [] (List.ofFn tr) with
      | some (_, _, _, w) => UL.prefixTraceProb tr * (w : ENNReal)
      | none => 0

theorem runPureDelSteps_haltProb_eq_one
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {birthHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N birthHist inst)
    {bState : BirthState} (hb : inst.IsAcceptedBirth birthHist bState) :
    ∀ (k : ℕ) (S : Finset ι) (ph : PhaseState) (log : List (ι × List Bool))
      (pol : PureDelPolicy ι d PhaseState),
      inst.gen.IsSurvivingSubset S →
      inst.IsAcceptedPhase birthHist bState S ph →
      IsValidPureDelPolicyFromLog inst bState S ph log pol →
      (∑' tr : Fin k → List Bool,
        if (runPureDelSteps inst bState pol S ph log (List.ofFn tr)).isSome then
          UL.prefixTraceProb tr
        else 0) = 1 := by
  have hDel := hVar.2.2.2.2.2.2.2.2.2.1
  intro k
  induction k with
  | zero =>
    intro S ph log pol _ _ _
    rw [tsum_fin_zero]
    simp [runPureDelSteps, prefixTraceProb_zero]
  | succ k ih =>
    intro S ph log pol hsub hph hval
    rw [tsum_fin_succ]
    cases hpol : pol S ph log with
    | none =>
      have hterm : ∀ bs : List Bool,
          (∑' rest : Fin k → List Bool,
            if (runPureDelSteps inst bState pol S ph log (List.ofFn (Fin.cons bs rest))).isSome then
              UL.prefixTraceProb (Fin.cons bs rest)
            else 0) =
          if bs = [] then 1 else 0 := by
        intro bs
        cases bs with
        | nil =>
          simp only [List.ofFn_succ, Fin.cons_zero, Fin.cons_succ, runPureDelSteps, hpol,
            prefixTraceProb_cons, bitListProb_nil, one_mul, ↓reduceIte]
          exact ih S ph log pol hsub hph (fun bss S' ph' log' w hrun =>
            hval ([] :: bss) S' ph' log' w (by simpa [runPureDelSteps, hpol] using hrun))
        | cons _ _ =>
          simp [List.ofFn_succ, runPureDelSteps, hpol]
      simp_rw [hterm, tsum_ite_eq]
    | some pair =>
      rcases pair with ⟨stepHist, i⟩
      have hi : i ∈ S :=
        hval [] S ph log 0 (by simp [runPureDelSteps]) stepHist i hpol
      have hStep := hDel stepHist bState S ph i hb hsub hph hi
      have hterm : ∀ bs : List Bool,
          (∑' rest : Fin k → List Bool,
            if (runPureDelSteps inst bState pol S ph log (List.ofFn (Fin.cons bs rest))).isSome then
              UL.prefixTraceProb (Fin.cons bs rest)
            else 0) =
          if (inst.deleteWithBits stepHist bState S ph i bs).isSome then
            UL.bitListProb bs
          else 0 := by
        intro bs
        cases hdel : inst.deleteWithBits stepHist bState S ph i bs with
        | none =>
          simp [List.ofFn_succ, runPureDelSteps, hpol, hi, hdel]
        | some dOut =>
          have hnext_acc := (hStep.2.2 bs dOut hdel).1
          have hnext_sub : inst.gen.IsSurvivingSubset (S.erase i) :=
            (Finset.erase_subset i S).trans hsub
          have hnext_val : IsValidPureDelPolicyFromLog inst bState (S.erase i)
              dOut.nextPhase (log ++ [(i, bs)]) pol := by
            intro bss S' ph' log' w hrun
            exact hval (bs :: bss) S' ph' log' (dOut.work + w)
              (by simp [runPureDelSteps, hpol, hi, hdel, hrun])
          have hinner : ∀ rest : Fin k → List Bool,
              (if (runPureDelSteps inst bState pol S ph log (List.ofFn (Fin.cons bs rest))).isSome then
                UL.prefixTraceProb (Fin.cons bs rest)
              else 0) =
              UL.bitListProb bs *
                (if (runPureDelSteps inst bState pol (S.erase i) dOut.nextPhase
                    (log ++ [(i, bs)]) (List.ofFn rest)).isSome then
                  UL.prefixTraceProb rest
                else 0) := by
            intro rest
            have hof : List.ofFn (Fin.cons bs rest) = bs :: List.ofFn rest := by
              simp [List.ofFn_succ]
            have hlhs : runPureDelSteps inst bState pol S ph log (bs :: List.ofFn rest) =
                match runPureDelSteps inst bState pol (S.erase i) dOut.nextPhase
                    (log ++ [(i, bs)]) (List.ofFn rest) with
                | none => none
                | some (S', ph', log', wRest) => some (S', ph', log', dOut.work + wRest) := by
              simp [runPureDelSteps, hpol, hi, hdel]
            rw [hof, hlhs, prefixTraceProb_cons]
            cases runPureDelSteps inst bState pol (S.erase i) dOut.nextPhase
                (log ++ [(i, bs)]) (List.ofFn rest) with
            | none => simp
            | some res =>
              rcases res with ⟨_, _, _, _⟩
              simp
          simp_rw [hinner]
          rw [ENNReal.tsum_mul_left, ih (S.erase i) dOut.nextPhase (log ++ [(i, bs)])
            pol hnext_sub hnext_acc hnext_val]
          simp
      simp_rw [hterm]
      exact hStep.2.1

theorem runCertifiedDeletionStepsFrom_eq_runPureDelSteps
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (delAdv : UL.CertifiedDeletionAdversary ι d BirthState PhaseState)
    (pol : PureDelPolicy ι d PhaseState)
    (bs₀ : List Bool)
    (hadv : ∀ st : UL.CertifiedDeletionState ι BirthState PhaseState,
      st.birthCoins = bs₀ →
      delAdv st = pol st.survivingSet st.phaseState st.deletionLog) :
    ∀ (bss : List (List Bool)) (cur : UL.CertifiedDeletionState ι BirthState PhaseState),
      cur.birthCoins = bs₀ →
      (∀ out, UL.runCertifiedDeletionStepsFrom inst delAdv cur bss = some out →
        ∃ w : ℕ,
          runPureDelSteps inst cur.birthState pol cur.survivingSet cur.phaseState
            cur.deletionLog bss = some (out.survivingSet, out.phaseState, out.deletionLog, w) ∧
          out.birthCoins = bs₀ ∧
          out.totalWork = cur.totalWork + w) ∧
      (∀ S' ph' log' w,
        runPureDelSteps inst cur.birthState pol cur.survivingSet cur.phaseState
          cur.deletionLog bss = some (S', ph', log', w) →
        ∃ out, UL.runCertifiedDeletionStepsFrom inst delAdv cur bss = some out ∧
          out.survivingSet = S' ∧ out.phaseState = ph' ∧ out.deletionLog = log' ∧
          out.totalWork = cur.totalWork + w) := by
  intro bss
  induction bss with
  | nil =>
    intro cur hcoins
    refine ⟨?_, ?_⟩
    · intro out hout
      simp only [UL.runCertifiedDeletionStepsFrom, Option.some.injEq] at hout
      subst hout
      exact ⟨0, by simp [runPureDelSteps], hcoins, by simp⟩
    · intro S' ph' log' w hres
      simp only [runPureDelSteps, Option.some.injEq, Prod.mk.injEq] at hres
      rcases hres with ⟨rfl, rfl, rfl, rfl⟩
      exact ⟨cur, by simp [UL.runCertifiedDeletionStepsFrom], rfl, rfl, rfl, by simp⟩
  | cons bs rest ih =>
    intro cur hcoins
    unfold UL.runCertifiedDeletionStepsFrom runPureDelSteps
    rw [hadv cur hcoins]
    cases hpol : pol cur.survivingSet cur.phaseState cur.deletionLog with
    | none =>
      dsimp only
      cases bs with
      | nil => exact ih cur hcoins
      | cons _ _ => simp
    | some pair =>
      rcases pair with ⟨stepHist, i⟩
      dsimp only
      split_ifs with hi
      · cases hdel : inst.deleteWithBits stepHist cur.birthState cur.survivingSet cur.phaseState i bs with
        | none => simp
        | some dOut =>
          dsimp only
          let next : UL.CertifiedDeletionState ι BirthState PhaseState :=
            { birthState := cur.birthState
              birthCoins := cur.birthCoins
              survivingSet := cur.survivingSet.erase i
              phaseState := dOut.nextPhase
              deletionLog := cur.deletionLog ++ [(i, bs)]
              totalWork := cur.totalWork + dOut.work
              maxSpace := max cur.maxSpace dOut.peakSpace }
          have hih := ih next hcoins
          refine ⟨?_, ?_⟩
          · intro out hout
            obtain ⟨wRest, hres, hbc, htw⟩ := hih.1 out hout
            refine ⟨dOut.work + wRest, ?_, hbc, ?_⟩
            · dsimp [next] at hres
              rw [hres]
            · dsimp [next] at htw
              omega
          · intro S' ph' log' w hres
            cases hsub : runPureDelSteps inst cur.birthState pol (cur.survivingSet.erase i)
                dOut.nextPhase (cur.deletionLog ++ [(i, bs)]) rest with
            | none => simp [hsub] at hres
            | some q =>
              rcases q with ⟨S₁, ph₁, log₁, wRest⟩
              simp only [hsub, Option.some.injEq, Prod.mk.injEq] at hres
              rcases hres with ⟨rfl, rfl, rfl, rfl⟩
              obtain ⟨out, hout, hS, hph, hlog, htw⟩ := hih.2 S₁ ph₁ log₁ wRest hsub
              refine ⟨out, hout, hS, hph, hlog, ?_⟩
              dsimp [next] at htw
              omega
      · simp

theorem runPureDelSteps_cons_log
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState)
    (pol_comb : PureDelPolicy ι d PhaseState)
    (pol_sub : PureDelPolicy ι d PhaseState)
    (headEntry : ι × List Bool)
    (hagree : ∀ S ph log, pol_comb S ph (headEntry :: log) = pol_sub S ph log) :
    ∀ (bss : List (List Bool)) (S : Finset ι) (ph : PhaseState) (log : List (ι × List Bool)),
      runPureDelSteps inst bState pol_comb S ph (headEntry :: log) bss =
        (runPureDelSteps inst bState pol_sub S ph log bss).map
          (fun res => (res.1, res.2.1, headEntry :: res.2.2.1, res.2.2.2)) := by
  intro bss
  induction bss with
  | nil =>
    intro S ph log
    simp [runPureDelSteps]
  | cons bs rest ih =>
    intro S ph log
    unfold runPureDelSteps
    rw [hagree S ph log]
    cases pol_sub S ph log with
    | none =>
      dsimp only
      cases bs with
      | nil => exact ih S ph log
      | cons _ _ => simp
    | some pair =>
      rcases pair with ⟨stepHist, i⟩
      dsimp only
      split_ifs with hi
      · cases inst.deleteWithBits stepHist bState S ph i bs with
        | none => simp
        | some dOut =>
          dsimp only
          have hcons : (headEntry :: log) ++ [(i, bs)] = headEntry :: (log ++ [(i, bs)]) := rfl
          rw [hcons, ih (S.erase i) dOut.nextPhase (log ++ [(i, bs)])]
          cases runPureDelSteps inst bState pol_sub (S.erase i) dOut.nextPhase (log ++ [(i, bs)]) rest <;>
            simp
      · simp

open Classical in
theorem delete_remCopyWork_le
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {birthHist stepHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N birthHist inst)
    {bState : BirthState} {S : Finset ι} {ph : PhaseState} {i₀ : ι}
    (hb : inst.IsAcceptedBirth birthHist bState)
    (hsub : inst.gen.IsSurvivingSubset S)
    (hph : inst.IsAcceptedPhase birthHist bState S ph)
    (hi₀ : i₀ ∈ S) :
    expWithBits (inst.deleteWithBits stepHist bState S ph i₀)
      (fun dOut => (dOut.work : ENNReal) + remCopyWork inst bState (S.erase i₀) dOut.nextPhase) ≤
    remCopyWork inst bState S ph := by
  have hStep := hVar.2.2.2.2.2.2.2.2.2.1 stepHist bState S ph i₀ hb hsub hph hi₀
  have hpf : IsPrefixFree (inst.deleteWithBits stepHist bState S ph i₀) := hStep.1
  let SubPol := fun dOut : UL.CertifiedDeleteOutcome PhaseState =>
    { p : PureDelPolicy ι d PhaseState // IsValidPureDelPolicy inst bState (S.erase i₀) dOut.nextPhase p }
  let Φ : (dOut : UL.CertifiedDeleteOutcome PhaseState) → SubPol dOut → ENNReal :=
    fun dOut pol' =>
      ∑' tr : Fin (S.erase i₀).card → List Bool,
        match runPureDelSteps inst bState pol'.1 (S.erase i₀) dOut.nextPhase [] (List.ofFn tr) with
        | some (_, _, _, w) => UL.prefixTraceProb tr * (w : ENNReal)
        | none => 0
  have hlhs : expWithBits (inst.deleteWithBits stepHist bState S ph i₀)
      (fun dOut => (dOut.work : ENNReal) + remCopyWork inst bState (S.erase i₀) dOut.nextPhase) =
      expWithBits (inst.deleteWithBits stepHist bState S ph i₀)
        (fun dOut => (dOut.work : ENNReal) + ⨆ pol' : SubPol dOut, Φ dOut pol') :=
    expWithBits_congr (fun _ => rfl) (fun _ _ _ => rfl)
  rw [hlhs]
  refine (expWithBits_add_iSup_le hpf (fun dOut => (dOut.work : ENNReal)) Φ).trans (iSup_le (fun ch => ?_))
  unfold remCopyWork
  let pol_comb : PureDelPolicy ι d PhaseState := fun S' ph' log =>
    match log with
    | [] => some (stepHist, i₀)
    | (_, bs₀) :: restLog =>
        match inst.deleteWithBits stepHist bState S ph i₀ bs₀ with
        | some dOut => (ch bs₀ dOut).1 S' ph' restLog
        | none => none
  have hvalid : IsValidPureDelPolicy inst bState S ph pol_comb := by
    intro bss S' ph' log' w hrun stepHist' i' hpol'
    cases bss with
    | nil =>
      simp only [runPureDelSteps, Option.some.injEq, Prod.mk.injEq] at hrun
      rcases hrun with ⟨rfl, rfl, rfl, _⟩
      simp only [pol_comb, Option.some.injEq, Prod.mk.injEq] at hpol'
      rcases hpol' with ⟨_, rfl⟩
      exact hi₀
    | cons bs₀ rest =>
      have hp0 : pol_comb S ph [] = some (stepHist, i₀) := rfl
      cases hdel : inst.deleteWithBits stepHist bState S ph i₀ bs₀ with
      | none =>
        simp [runPureDelSteps, hp0, hi₀, hdel] at hrun
      | some dOut =>
        have hstep0 : runPureDelSteps inst bState pol_comb S ph [] (bs₀ :: rest) =
            match runPureDelSteps inst bState pol_comb (S.erase i₀) dOut.nextPhase [(i₀, bs₀)] rest with
            | none => none
            | some (S₁, ph₁, log₁, wRest) => some (S₁, ph₁, log₁, dOut.work + wRest) := by
          simp [runPureDelSteps, hp0, hi₀, hdel]
        rw [hstep0] at hrun
        have hshift := runPureDelSteps_cons_log inst bState pol_comb (ch bs₀ dOut).1
          (i₀, bs₀) (fun S'' ph'' lg => by simp [pol_comb, hdel]) rest (S.erase i₀) dOut.nextPhase []
        rw [hshift] at hrun
        cases hsub_r : runPureDelSteps inst bState (ch bs₀ dOut).1 (S.erase i₀) dOut.nextPhase [] rest with
        | none => simp [hsub_r] at hrun
        | some res =>
          rcases res with ⟨S₁, ph₁, log₁, wRest⟩
          rw [hsub_r] at hrun
          simp only [Option.map_some, Option.some.injEq, Prod.mk.injEq] at hrun
          rcases hrun with ⟨rfl, rfl, rfl, _⟩
          simp only [pol_comb, hdel] at hpol'
          exact (ch bs₀ dOut).2 rest S₁ ph₁ log₁ wRest hsub_r stepHist' i' hpol'
  let k := (S.erase i₀).card
  have hcard : S.card = k + 1 := (Finset.card_erase_add_one hi₀).symm
  let R_fn := fun pol : { p : PureDelPolicy ι d PhaseState // IsValidPureDelPolicy inst bState S ph p } =>
    ∑' tr : Fin S.card → List Bool,
      match runPureDelSteps inst bState pol.1 S ph [] (List.ofFn tr) with
      | some (_, _, _, w) => UL.prefixTraceProb tr * (w : ENNReal)
      | none => 0
  change _ ≤ ⨆ pol, R_fn pol
  refine le_trans ?_ (le_iSup R_fn ⟨pol_comb, hvalid⟩)
  dsimp only [R_fn]
  let castFin : (Fin (k + 1) → List Bool) ≃ (Fin S.card → List Bool) :=
    Equiv.arrowCongr (finCongr hcard.symm) (Equiv.refl _)
  rw [← castFin.tsum_eq, tsum_fin_succ]
  refine ENNReal.tsum_le_tsum (fun bs₀ => ?_)
  cases hdel : inst.deleteWithBits stepHist bState S ph i₀ bs₀ with
  | none => simp
  | some dOut =>
    dsimp only [Φ]
    have hnext_acc := (hStep.2.2 bs₀ dOut hdel).1
    have hnext_sub : inst.gen.IsSurvivingSubset (S.erase i₀) :=
      (Finset.erase_subset i₀ S).trans hsub
    have hhalt1 := runPureDelSteps_haltProb_eq_one hVar hb k (S.erase i₀) dOut.nextPhase []
      (ch bs₀ dOut).1 hnext_sub hnext_acc (ch bs₀ dOut).2
    have hshift_all : ∀ rest : Fin k → List Bool,
        (match runPureDelSteps inst bState pol_comb S ph []
            (List.ofFn (castFin (Fin.cons bs₀ rest))) with
        | some (_, _, _, w) => UL.prefixTraceProb (castFin (Fin.cons bs₀ rest)) * (w : ENNReal)
        | none => 0) =
        UL.bitListProb bs₀ *
          ((if (runPureDelSteps inst bState (ch bs₀ dOut).1 (S.erase i₀) dOut.nextPhase []
              (List.ofFn rest)).isSome then UL.prefixTraceProb rest else 0) * (dOut.work : ENNReal) +
           (match runPureDelSteps inst bState (ch bs₀ dOut).1 (S.erase i₀) dOut.nextPhase []
              (List.ofFn rest) with
            | some (_, _, _, wRest) => UL.prefixTraceProb rest * (wRest : ENNReal)
            | none => 0)) := by
      intro rest
      have hofFn : List.ofFn (castFin (Fin.cons bs₀ rest)) = bs₀ :: List.ofFn rest :=
        ofFn_finCongr_cons hcard bs₀ rest
      have hprob : UL.prefixTraceProb (castFin (Fin.cons bs₀ rest)) =
          UL.bitListProb bs₀ * UL.prefixTraceProb rest :=
        prefixTraceProb_finCongr_cons hcard bs₀ rest
      have hp0 : pol_comb S ph [] = some (stepHist, i₀) := rfl
      have hstep0 : runPureDelSteps inst bState pol_comb S ph [] (bs₀ :: List.ofFn rest) =
          match runPureDelSteps inst bState pol_comb (S.erase i₀) dOut.nextPhase [(i₀, bs₀)] (List.ofFn rest) with
          | none => none
          | some (S₁, ph₁, log₁, wRest) => some (S₁, ph₁, log₁, dOut.work + wRest) := by
        simp [runPureDelSteps, hp0, hi₀, hdel]
      rw [hofFn, hprob, hstep0]
      have hshift := runPureDelSteps_cons_log inst bState pol_comb (ch bs₀ dOut).1
        (i₀, bs₀) (fun S'' ph'' lg => by simp [pol_comb, hdel]) (List.ofFn rest)
        (S.erase i₀) dOut.nextPhase []
      rw [hshift]
      cases runPureDelSteps inst bState (ch bs₀ dOut).1 (S.erase i₀) dOut.nextPhase [] (List.ofFn rest) with
      | none => simp
      | some res =>
        rcases res with ⟨_, _, _, wRest⟩
        dsimp only [Option.map]
        simp only [Option.isSome_some, ↓reduceIte, Nat.cast_add]
        ring
    rw [tsum_congr hshift_all]
    rw [ENNReal.tsum_mul_left, ENNReal.tsum_add, ENNReal.tsum_mul_right, hhalt1, one_mul]

open Classical in
theorem birth_remCopyWork_le
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {birthHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N birthHist inst) :
    expWithBits (inst.buildWithBits birthHist)
      (fun bOut => (bOut.work : ENNReal) +
        remCopyWork inst bOut.birthState inst.gen.P₀ bOut.initPhase) ≤
    ENNReal.ofReal ((inst.gen.m : ℝ) * A_n * P_fac) := by
  have hpf : IsPrefixFree (inst.buildWithBits birthHist) := hVar.2.2.2.2.2.2.1
  have hAccBirth := hVar.2.2.2.2.2.2.2.2.1
  have hExp := hVar.2.2.2.2.2.2.2.2.2.2.1
  let SubPol := fun bOut : UL.CertifiedBirthOutcome BirthState PhaseState =>
    { p : PureDelPolicy ι d PhaseState //
      IsValidPureDelPolicy inst bOut.birthState inst.gen.P₀ bOut.initPhase p }
  let Φ : (bOut : UL.CertifiedBirthOutcome BirthState PhaseState) → SubPol bOut → ENNReal :=
    fun bOut pol =>
      ∑' tr : Fin inst.gen.P₀.card → List Bool,
        match runPureDelSteps inst bOut.birthState pol.1 inst.gen.P₀ bOut.initPhase []
            (List.ofFn tr) with
        | some (_, _, _, w) => UL.prefixTraceProb tr * (w : ENNReal)
        | none => 0
  have hlhs : expWithBits (inst.buildWithBits birthHist)
      (fun bOut => (bOut.work : ENNReal) + remCopyWork inst bOut.birthState inst.gen.P₀ bOut.initPhase) =
      expWithBits (inst.buildWithBits birthHist)
        (fun bOut => (bOut.work : ENNReal) + ⨆ pol : SubPol bOut, Φ bOut pol) :=
    expWithBits_congr (fun _ => rfl) (fun _ _ _ => rfl)
  rw [hlhs]
  refine (expWithBits_add_iSup_le hpf (fun bOut => (bOut.work : ENNReal)) Φ).trans (iSup_le (fun ch => ?_))
  let delAdv : UL.CertifiedDeletionAdversary ι d BirthState PhaseState :=
    fun st =>
      match inst.buildWithBits birthHist st.birthCoins with
      | some bOut => (ch st.birthCoins bOut).1 st.survivingSet st.phaseState st.deletionLog
      | none => none
  have hvalid_adv : UL.IsValidCertifiedDeletionAdversary inst birthHist delAdv := by
    intro k bs₀ delTrace st htraj stepHist i hadv_eq
    unfold UL.runCertifiedDeletionTrajectory at htraj
    cases hb0 : inst.buildWithBits birthHist bs₀ with
    | none => simp [hb0] at htraj
    | some bOut =>
      simp only [hb0] at htraj
      have heqv := runCertifiedDeletionStepsFrom_eq_runPureDelSteps inst delAdv
        (ch bs₀ bOut).1 bs₀ (fun st' hbc => by simp [delAdv, hbc, hb0])
        (List.ofFn delTrace)
        { birthState := bOut.birthState
          birthCoins := bs₀
          survivingSet := inst.gen.P₀
          phaseState := bOut.initPhase
          deletionLog := []
          totalWork := bOut.work
          maxSpace := bOut.peakSpace } rfl
      obtain ⟨w, hrun, hbc, _⟩ := heqv.1 st htraj
      simp only [delAdv, hbc, hb0] at hadv_eq
      exact (ch bs₀ bOut).2 (List.ofFn delTrace) st.survivingSet st.phaseState
        st.deletionLog w hrun stepHist i hadv_eq
  have hBound := hExp delAdv hvalid_adv inst.gen.P₀.card
  have hle_ofReal :
      inst.expectedTotalBuildAndRebuildWork birthHist delAdv inst.gen.P₀.card ≤
        ENNReal.ofReal ((inst.gen.m : ℝ) * A_n * P_fac) :=
    ennreal_le_ofReal_of_toReal_le hBound.1 hBound.2
  refine le_trans ?_ hle_ofReal
  unfold UL.CertifiedSearchGeneration.expectedTotalBuildAndRebuildWork
  refine ENNReal.tsum_le_tsum (fun bs₀ => ?_)
  cases hb0 : inst.buildWithBits birthHist bs₀ with
  | none => simp [UL.runCertifiedDeletionTrajectory, hb0]
  | some bOut =>
    dsimp only [Φ]
    have hb_acc := (hAccBirth bs₀ bOut hb0).1
    have hph_acc := (hAccBirth bs₀ bOut hb0).2.1
    have hsub0 : inst.gen.IsSurvivingSubset inst.gen.P₀ := Finset.Subset.refl _
    have hhalt1 := runPureDelSteps_haltProb_eq_one hVar hb_acc inst.gen.P₀.card
      inst.gen.P₀ bOut.initPhase [] (ch bs₀ bOut).1 hsub0 hph_acc (ch bs₀ bOut).2
    have heqv_all : ∀ tr : Fin inst.gen.P₀.card → List Bool,
        (match UL.runCertifiedDeletionTrajectory inst birthHist delAdv inst.gen.P₀.card bs₀ tr with
        | some out => UL.bitListProb bs₀ * UL.prefixTraceProb tr * (out.totalWork : ENNReal)
        | none => 0) =
        UL.bitListProb bs₀ *
          ((if (runPureDelSteps inst bOut.birthState (ch bs₀ bOut).1 inst.gen.P₀ bOut.initPhase
              [] (List.ofFn tr)).isSome then UL.prefixTraceProb tr else 0) * (bOut.work : ENNReal) +
           (match runPureDelSteps inst bOut.birthState (ch bs₀ bOut).1 inst.gen.P₀ bOut.initPhase
              [] (List.ofFn tr) with
            | some (_, _, _, w) => UL.prefixTraceProb tr * (w : ENNReal)
            | none => 0)) := by
      intro tr
      unfold UL.runCertifiedDeletionTrajectory
      simp only [hb0]
      let initSt : UL.CertifiedDeletionState ι BirthState PhaseState :=
        { birthState := bOut.birthState
          birthCoins := bs₀
          survivingSet := inst.gen.P₀
          phaseState := bOut.initPhase
          deletionLog := []
          totalWork := bOut.work
          maxSpace := bOut.peakSpace }
      have heqv := runCertifiedDeletionStepsFrom_eq_runPureDelSteps inst delAdv
        (ch bs₀ bOut).1 bs₀ (fun st' hbc => by simp [delAdv, hbc, hb0])
        (List.ofFn tr) initSt rfl
      cases htraj : UL.runCertifiedDeletionStepsFrom inst delAdv initSt (List.ofFn tr) with
      | none =>
        cases hrun : runPureDelSteps inst bOut.birthState (ch bs₀ bOut).1
            inst.gen.P₀ bOut.initPhase [] (List.ofFn tr) with
        | none => simp
        | some res =>
          rcases res with ⟨S', ph', log', w⟩
          obtain ⟨out, hout, _⟩ := heqv.2 S' ph' log' w hrun
          rw [htraj] at hout
          simp at hout
      | some out =>
        obtain ⟨w, hrun, _, htw⟩ := heqv.1 out htraj
        have hrun' : runPureDelSteps inst bOut.birthState (ch bs₀ bOut).1
            inst.gen.P₀ bOut.initPhase [] (List.ofFn tr) =
            some (out.survivingSet, out.phaseState, out.deletionLog, w) := hrun
        rw [hrun']
        dsimp only [initSt] at htw ⊢
        rw [htw]
        simp only [Option.isSome_some, ↓reduceIte, Nat.cast_add]
        ring
    have h_rhs_eq : (∑' delTrace : Fin inst.gen.P₀.card → List Bool,
        match UL.runCertifiedDeletionTrajectory inst birthHist delAdv inst.gen.P₀.card bs₀ delTrace with
        | some out => UL.bitListProb bs₀ * UL.prefixTraceProb delTrace * (out.totalWork : ENNReal)
        | none => 0) =
        UL.bitListProb bs₀ * ((bOut.work : ENNReal) +
          ∑' tr : Fin inst.gen.P₀.card → List Bool,
            match runPureDelSteps inst bOut.birthState (ch bs₀ bOut).1 inst.gen.P₀ bOut.initPhase []
                (List.ofFn tr) with
            | some (_, _, _, w) => UL.prefixTraceProb tr * (w : ENNReal)
            | none => 0) := by
      refine (tsum_congr heqv_all).trans ?_
      rw [ENNReal.tsum_mul_left, ENNReal.tsum_add, ENNReal.tsum_mul_right, hhalt1, one_mul]
    exact le_of_eq h_rhs_eq.symm

/-! ### 3. `buildRCopies`, `deleteRCopies`, `deleteRCopiesList`, `rebuildCompiledBundle` -/

def IsAcceptedCopies
    {ι : Type} {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (birthHist : UL.ExecutionHistory d)
    (S : Finset ι)
    (copies : List (BirthState × PhaseState)) : Prop :=
  ∀ cp ∈ copies, inst.IsAcceptedBirth birthHist cp.1 ∧ inst.IsAcceptedPhase birthHist cp.1 S cp.2

noncomputable def copiesRemWork
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (S : Finset ι)
    (copies : List (BirthState × PhaseState)) : ENNReal :=
  (copies.map (fun cp => remCopyWork inst cp.1 S cp.2)).sum

theorem buildRCopies_props
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {hist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N hist inst)
    (R : ℕ) :
    IsPrefixFree (UL.buildRCopies inst hist R) ∧
    haltProb (UL.buildRCopies inst hist R) = 1 ∧
    (∀ bs cw, UL.buildRCopies inst hist R bs = some cw →
      cw.1.length = R ∧ IsAcceptedCopies inst hist inst.gen.P₀ cw.1) ∧
    expWithBits (UL.buildRCopies inst hist R)
      (fun cw => (cw.2 : ENNReal) + copiesRemWork inst inst.gen.P₀ cw.1) ≤
      (R : ENNReal) * ENNReal.ofReal ((inst.gen.m : ℝ) * A_n * P_fac) := by
  have hpf1 : IsPrefixFree (inst.buildWithBits hist) := hVar.2.2.2.2.2.2.1
  have hhp1 : haltProb (inst.buildWithBits hist) = 1 := hVar.2.2.2.2.2.2.2.1
  have hacc1 := hVar.2.2.2.2.2.2.2.2.1
  have hbirth_exp := birth_remCopyWork_le hVar
  induction R with
  | zero =>
    refine ⟨isPrefixFree_pureWithBits _, haltProb_pureWithBits _, ?_, ?_⟩
    · intro bs cw h
      unfold UL.buildRCopies at h
      rw [pureWithBits_eq_some_iff] at h
      rcases h with ⟨_, rfl⟩
      simp [IsAcceptedCopies]
    · change expWithBits (UL.pureWithBits ([], 0)) _ ≤ _
      rw [expWithBits_pure]
      simp [copiesRemWork]
  | succ r ih =>
    rcases ih with ⟨hpf_r, hhp_r, hinv_r, hexp_r⟩
    have hpf_inner : ∀ bOut : UL.CertifiedBirthOutcome BirthState PhaseState,
        IsPrefixFree (UL.bindWithBits (UL.buildRCopies inst hist r) (fun cw =>
          UL.pureWithBits ((bOut.birthState, bOut.initPhase) :: cw.1, bOut.work + cw.2))) :=
      fun bOut => hpf_r.bindWithBits (fun _ _ _ => isPrefixFree_pureWithBits _)
    have hhp_inner : ∀ bOut : UL.CertifiedBirthOutcome BirthState PhaseState,
        haltProb (UL.bindWithBits (UL.buildRCopies inst hist r) (fun cw =>
          UL.pureWithBits ((bOut.birthState, bOut.initPhase) :: cw.1, bOut.work + cw.2))) = 1 :=
      fun bOut => haltProb_bindWithBits hpf_r hhp_r (fun _ _ _ => haltProb_pureWithBits _)
    refine ⟨hpf1.bindWithBits (fun _ bOut _ => hpf_inner bOut),
      haltProb_bindWithBits hpf1 hhp1 (fun _ bOut _ => hhp_inner bOut), ?_, ?_⟩
    · intro bs res h
      unfold UL.buildRCopies at h
      rw [bindWithBits_eq_some_iff hpf1] at h
      rcases h with ⟨bs₁, bs₂, bOut, _, hb1, hb2⟩
      rw [bindWithBits_eq_some_iff hpf_r] at hb2
      rcases hb2 with ⟨bs₂₁, bs₂₂, cw, _, hcw, hpure⟩
      rw [pureWithBits_eq_some_iff] at hpure
      rcases hpure with ⟨_, rfl⟩
      obtain ⟨hlen_r, hacc_r⟩ := hinv_r bs₂₁ cw hcw
      obtain ⟨hb_acc, hph_acc, _⟩ := hacc1 bs₁ bOut hb1
      refine ⟨by simp [hlen_r], ?_⟩
      intro cp hcp
      rcases List.mem_cons.mp hcp with rfl | hmem
      · exact ⟨hb_acc, hph_acc⟩
      · exact hacc_r cp hmem
    · change expWithBits (UL.bindWithBits (inst.buildWithBits hist) (fun bOut =>
          UL.bindWithBits (UL.buildRCopies inst hist r) (fun cw =>
            UL.pureWithBits ((bOut.birthState, bOut.initPhase) :: cw.1, bOut.work + cw.2)))) _ ≤ _
      rw [expWithBits_bind hpf1]
      have hinner_eq : ∀ bOut : UL.CertifiedBirthOutcome BirthState PhaseState,
          expWithBits (UL.bindWithBits (UL.buildRCopies inst hist r) (fun cw =>
              UL.pureWithBits ((bOut.birthState, bOut.initPhase) :: cw.1, bOut.work + cw.2)))
            (fun cw => (cw.2 : ENNReal) + copiesRemWork inst inst.gen.P₀ cw.1) =
          ((bOut.work : ENNReal) + remCopyWork inst bOut.birthState inst.gen.P₀ bOut.initPhase) +
            expWithBits (UL.buildRCopies inst hist r)
              (fun cw => (cw.2 : ENNReal) + copiesRemWork inst inst.gen.P₀ cw.1) := by
        intro bOut
        rw [expWithBits_bind hpf_r]
        have hpure_eq :
            (fun cw : List (BirthState × PhaseState) × ℕ =>
              expWithBits (UL.pureWithBits ((bOut.birthState, bOut.initPhase) :: cw.1, bOut.work + cw.2))
                (fun res => (res.2 : ENNReal) + copiesRemWork inst inst.gen.P₀ res.1)) =
            fun cw =>
              ((bOut.work : ENNReal) + remCopyWork inst bOut.birthState inst.gen.P₀ bOut.initPhase) +
                ((cw.2 : ENNReal) + copiesRemWork inst inst.gen.P₀ cw.1) := by
          ext cw
          rw [expWithBits_pure]
          simp only [copiesRemWork, List.map_cons, List.sum_cons, Nat.cast_add]
          ring
        rw [hpure_eq, expWithBits_const_add_of_haltProb_one hhp_r]
      simp_rw [hinner_eq]
      rw [expWithBits_add_const_of_haltProb_one hhp1]
      calc
        _ ≤ ENNReal.ofReal ((inst.gen.m : ℝ) * A_n * P_fac) +
              (r : ENNReal) * ENNReal.ofReal ((inst.gen.m : ℝ) * A_n * P_fac) :=
            add_le_add hbirth_exp hexp_r
        _ = ((r + 1 : ℕ) : ENNReal) * ENNReal.ofReal ((inst.gen.m : ℝ) * A_n * P_fac) := by
            push_cast
            ring

theorem deleteRCopies_props
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {birthHist stepHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N birthHist inst)
    {S : Finset ι} (hsub : inst.gen.IsSurvivingSubset S)
    {i : ι} (hi : i ∈ S)
    (copies : List (BirthState × PhaseState))
    (hacc : IsAcceptedCopies inst birthHist S copies) :
    IsPrefixFree (UL.deleteRCopies inst stepHist S i copies) ∧
    haltProb (UL.deleteRCopies inst stepHist S i copies) = 1 ∧
    (∀ bs cw, UL.deleteRCopies inst stepHist S i copies bs = some cw →
      cw.1.map Prod.fst = copies.map Prod.fst ∧
      IsAcceptedCopies inst birthHist (S.erase i) cw.1) ∧
    expWithBits (UL.deleteRCopies inst stepHist S i copies)
      (fun cw => (cw.2 : ENNReal) + copiesRemWork inst (S.erase i) cw.1) ≤
      copiesRemWork inst S copies := by
  have hDel := hVar.2.2.2.2.2.2.2.2.2.1
  induction copies with
  | nil =>
    refine ⟨isPrefixFree_pureWithBits _, haltProb_pureWithBits _, ?_, ?_⟩
    · intro bs cw h
      unfold UL.deleteRCopies at h
      rw [pureWithBits_eq_some_iff] at h
      rcases h with ⟨_, rfl⟩
      simp [IsAcceptedCopies]
    · change expWithBits (UL.pureWithBits ([], 0)) _ ≤ _
      rw [expWithBits_pure]
      simp [copiesRemWork]
  | cons cp rest ih =>
    rcases cp with ⟨bSt, ph⟩
    have hcp_acc := hacc (bSt, ph) List.mem_cons_self
    have hrest_acc : IsAcceptedCopies inst birthHist S rest :=
      fun cp' hmem => hacc cp' (List.mem_cons_of_mem _ hmem)
    rcases ih hrest_acc with ⟨hpf_r, hhp_r, hinv_r, hexp_r⟩
    have hStep := hDel stepHist bSt S ph i hcp_acc.1 hsub hcp_acc.2 hi
    have hpf1 : IsPrefixFree (inst.deleteWithBits stepHist bSt S ph i) := hStep.1
    have hhp1 : haltProb (inst.deleteWithBits stepHist bSt S ph i) = 1 := hStep.2.1
    have hdel_exp := delete_remCopyWork_le (stepHist := stepHist) hVar hcp_acc.1 hsub hcp_acc.2 hi
    have hpf_inner : ∀ dOut : UL.CertifiedDeleteOutcome PhaseState,
        IsPrefixFree (UL.bindWithBits (UL.deleteRCopies inst stepHist S i rest) (fun cw =>
          UL.pureWithBits ((bSt, dOut.nextPhase) :: cw.1, dOut.work + cw.2))) :=
      fun dOut => hpf_r.bindWithBits (fun _ _ _ => isPrefixFree_pureWithBits _)
    have hhp_inner : ∀ dOut : UL.CertifiedDeleteOutcome PhaseState,
        haltProb (UL.bindWithBits (UL.deleteRCopies inst stepHist S i rest) (fun cw =>
          UL.pureWithBits ((bSt, dOut.nextPhase) :: cw.1, dOut.work + cw.2))) = 1 :=
      fun dOut => haltProb_bindWithBits hpf_r hhp_r (fun _ _ _ => haltProb_pureWithBits _)
    refine ⟨hpf1.bindWithBits (fun _ dOut _ => hpf_inner dOut),
      haltProb_bindWithBits hpf1 hhp1 (fun _ dOut _ => hhp_inner dOut), ?_, ?_⟩
    · intro bs res h
      unfold UL.deleteRCopies at h
      rw [bindWithBits_eq_some_iff hpf1] at h
      rcases h with ⟨bs₁, bs₂, dOut, _, hd1, hd2⟩
      rw [bindWithBits_eq_some_iff hpf_r] at hd2
      rcases hd2 with ⟨bs₂₁, bs₂₂, cw, _, hcw, hpure⟩
      rw [pureWithBits_eq_some_iff] at hpure
      rcases hpure with ⟨_, rfl⟩
      obtain ⟨hfst_r, hacc_r'⟩ := hinv_r bs₂₁ cw hcw
      have hnext_ph := (hStep.2.2 bs₁ dOut hd1).1
      refine ⟨by simp [hfst_r], ?_⟩
      intro cp' hcp'
      rcases List.mem_cons.mp hcp' with rfl | hmem
      · exact ⟨hcp_acc.1, hnext_ph⟩
      · exact hacc_r' cp' hmem
    · change expWithBits (UL.bindWithBits (inst.deleteWithBits stepHist bSt S ph i) (fun dOut =>
          UL.bindWithBits (UL.deleteRCopies inst stepHist S i rest) (fun cw =>
            UL.pureWithBits ((bSt, dOut.nextPhase) :: cw.1, dOut.work + cw.2)))) _ ≤ _
      rw [expWithBits_bind hpf1]
      have hinner_eq : ∀ dOut : UL.CertifiedDeleteOutcome PhaseState,
          expWithBits (UL.bindWithBits (UL.deleteRCopies inst stepHist S i rest) (fun cw =>
              UL.pureWithBits ((bSt, dOut.nextPhase) :: cw.1, dOut.work + cw.2)))
            (fun cw => (cw.2 : ENNReal) + copiesRemWork inst (S.erase i) cw.1) =
          ((dOut.work : ENNReal) + remCopyWork inst bSt (S.erase i) dOut.nextPhase) +
            expWithBits (UL.deleteRCopies inst stepHist S i rest)
              (fun cw => (cw.2 : ENNReal) + copiesRemWork inst (S.erase i) cw.1) := by
        intro dOut
        rw [expWithBits_bind hpf_r]
        have hpure_eq :
            (fun cw : List (BirthState × PhaseState) × ℕ =>
              expWithBits (UL.pureWithBits ((bSt, dOut.nextPhase) :: cw.1, dOut.work + cw.2))
                (fun res => (res.2 : ENNReal) + copiesRemWork inst (S.erase i) res.1)) =
            fun cw =>
              ((dOut.work : ENNReal) + remCopyWork inst bSt (S.erase i) dOut.nextPhase) +
                ((cw.2 : ENNReal) + copiesRemWork inst (S.erase i) cw.1) := by
          ext cw
          rw [expWithBits_pure]
          simp only [copiesRemWork, List.map_cons, List.sum_cons, Nat.cast_add]
          ring
        rw [hpure_eq, expWithBits_const_add_of_haltProb_one hhp_r]
      simp_rw [hinner_eq]
      rw [expWithBits_add_const_of_haltProb_one hhp1]
      simp only [copiesRemWork, List.map_cons, List.sum_cons]
      exact add_le_add hdel_exp hexp_r

inductive ValidDelReplay {ι : Type} [DecidableEq ι] : Finset ι → List ι → Finset ι → Prop
  | nil (S : Finset ι) : ValidDelReplay S [] S
  | cons {S S_end : Finset ι} {i : ι} {rest : List ι}
      (hi : i ∈ S) (hrest : ValidDelReplay (S.erase i) rest S_end) :
      ValidDelReplay S (i :: rest) S_end

theorem ValidDelReplay.snoc {ι : Type} [DecidableEq ι]
    {S S_end : Finset ι} {delIds : List ι} {i : ι}
    (h : ValidDelReplay S delIds S_end) (hi : i ∈ S_end) :
    ValidDelReplay S (delIds ++ [i]) (S_end.erase i) := by
  induction h with
  | nil S => exact ValidDelReplay.cons hi (ValidDelReplay.nil _)
  | cons hi0 _ ih => exact ValidDelReplay.cons hi0 (ih hi)

theorem ValidDelReplay.subset {ι : Type} [DecidableEq ι]
    {S S_end : Finset ι} {delIds : List ι}
    (h : ValidDelReplay S delIds S_end) : S_end ⊆ S := by
  induction h with
  | nil _ => exact Finset.Subset.refl _
  | cons _ _ ih => exact ih.trans (Finset.erase_subset _ _)

theorem deleteRCopiesList_props
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {birthHist curHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N birthHist inst)
    {S S_end : Finset ι} {delIds : List ι}
    (hreplay : ValidDelReplay S delIds S_end)
    (hsub : inst.gen.IsSurvivingSubset S) :
    ∀ (copies : List (BirthState × PhaseState)),
      IsAcceptedCopies inst birthHist S copies →
      IsPrefixFree (UL.deleteRCopiesList inst curHist S delIds copies) ∧
      haltProb (UL.deleteRCopiesList inst curHist S delIds copies) = 1 ∧
      (∀ bs cw, UL.deleteRCopiesList inst curHist S delIds copies bs = some cw →
        cw.1.map Prod.fst = copies.map Prod.fst ∧
        IsAcceptedCopies inst birthHist S_end cw.1) ∧
      expWithBits (UL.deleteRCopiesList inst curHist S delIds copies)
        (fun cw => (cw.2 : ENNReal) + copiesRemWork inst S_end cw.1) ≤
        copiesRemWork inst S copies := by
  induction hreplay with
  | nil S =>
    intro copies hacc
    refine ⟨isPrefixFree_pureWithBits _, haltProb_pureWithBits _, ?_, ?_⟩
    · intro bs cw h
      unfold UL.deleteRCopiesList at h
      rw [pureWithBits_eq_some_iff] at h
      rcases h with ⟨_, rfl⟩
      exact ⟨rfl, hacc⟩
    · change expWithBits (UL.pureWithBits (copies, 0)) _ ≤ _
      rw [expWithBits_pure]
      simp
  | @cons S S_end i rest hi _ ih =>
    intro copies hacc
    have hsub' : inst.gen.IsSurvivingSubset (S.erase i) :=
      (Finset.erase_subset i S).trans hsub
    obtain ⟨hpf1, hhp1, hinv1, hexp1⟩ :=
      deleteRCopies_props (stepHist := curHist) hVar hsub hi copies hacc
    have hpf2 : ∀ bs₁ cw₁,
        UL.deleteRCopies inst curHist S i copies bs₁ = some cw₁ →
        IsPrefixFree (UL.bindWithBits (UL.deleteRCopiesList inst curHist (S.erase i) rest cw₁.1)
          (fun cw₂ => UL.pureWithBits (cw₂.1, cw₁.2 + cw₂.2))) := by
      intro bs₁ cw₁ h1
      have hacc1 := (hinv1 bs₁ cw₁ h1).2
      exact (ih hsub' cw₁.1 hacc1).1.bindWithBits (fun _ _ _ => isPrefixFree_pureWithBits _)
    have hhp2 : ∀ bs₁ cw₁,
        UL.deleteRCopies inst curHist S i copies bs₁ = some cw₁ →
        haltProb (UL.bindWithBits (UL.deleteRCopiesList inst curHist (S.erase i) rest cw₁.1)
          (fun cw₂ => UL.pureWithBits (cw₂.1, cw₁.2 + cw₂.2))) = 1 := by
      intro bs₁ cw₁ h1
      have hacc1 := (hinv1 bs₁ cw₁ h1).2
      obtain ⟨hpf_l, hhp_l, _, _⟩ := ih hsub' cw₁.1 hacc1
      exact haltProb_bindWithBits hpf_l hhp_l (fun _ _ _ => haltProb_pureWithBits _)
    refine ⟨hpf1.bindWithBits hpf2, haltProb_bindWithBits hpf1 hhp1 hhp2, ?_, ?_⟩
    · intro bs res h
      unfold UL.deleteRCopiesList at h
      rw [bindWithBits_eq_some_iff hpf1] at h
      rcases h with ⟨bs₁, bs₂, cw₁, _, h1, h2⟩
      obtain ⟨hfst1, hacc1⟩ := hinv1 bs₁ cw₁ h1
      obtain ⟨hpf_l, _, hinv_l, _⟩ := ih hsub' cw₁.1 hacc1
      rw [bindWithBits_eq_some_iff hpf_l] at h2
      rcases h2 with ⟨bs₂₁, bs₂₂, cw₂, _, h21, hpure⟩
      rw [pureWithBits_eq_some_iff] at hpure
      rcases hpure with ⟨_, rfl⟩
      obtain ⟨hfst2, hacc2⟩ := hinv_l bs₂₁ cw₂ h21
      exact ⟨hfst2.trans hfst1, hacc2⟩
    · change expWithBits (UL.bindWithBits (UL.deleteRCopies inst curHist S i copies) (fun cw₁ =>
          UL.bindWithBits (UL.deleteRCopiesList inst curHist (S.erase i) rest cw₁.1) (fun cw₂ =>
            UL.pureWithBits (cw₂.1, cw₁.2 + cw₂.2)))) _ ≤ _
      rw [expWithBits_bind hpf1]
      refine (expWithBits_mono ?_).trans hexp1
      intro bs₁ cw₁ h1
      obtain ⟨_, hacc1⟩ := hinv1 bs₁ cw₁ h1
      obtain ⟨hpf_l, hhp_l, _, hexp_l⟩ := ih hsub' cw₁.1 hacc1
      rw [expWithBits_bind hpf_l]
      have hpure_eq :
          (fun cw₂ : List (BirthState × PhaseState) × ℕ =>
            expWithBits (UL.pureWithBits (cw₂.1, cw₁.2 + cw₂.2))
              (fun res => (res.2 : ENNReal) + copiesRemWork inst S_end res.1)) =
          fun cw₂ =>
            (cw₁.2 : ENNReal) + ((cw₂.2 : ENNReal) + copiesRemWork inst S_end cw₂.1) := by
        ext cw₂
        rw [expWithBits_pure]
        simp only [Nat.cast_add]
        ring
      rw [hpure_eq, expWithBits_const_add_of_haltProb_one hhp_l]
      gcongr

theorem rebuildCompiledBundle_props
    {ι : Type} [DecidableEq ι] {d d_s n : ℕ} {BirthState PhaseState : Type}
    {σ A_n P_fac netLogBound : ℝ}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {curHist : UL.ExecutionHistory d}
    {bundle : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState}
    (hVar : UL.SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N curHist bundle.inst)
    (hreplay : ValidDelReplay bundle.inst.gen.P₀ bundle.deletedIds bundle.survivingSet)
    (R : ℕ) :
    IsPrefixFree (UL.rebuildCompiledBundle R curHist bundle) ∧
    haltProb (UL.rebuildCompiledBundle R curHist bundle) = 1 ∧
    (∀ bs rw, UL.rebuildCompiledBundle R curHist bundle bs = some rw →
      rw.1.inst = bundle.inst ∧
      rw.1.epochBirthHist = curHist ∧
      rw.1.survivingSet = bundle.survivingSet ∧
      rw.1.deletedIds = bundle.deletedIds ∧
      rw.1.copies.length = R ∧
      IsAcceptedCopies bundle.inst curHist bundle.survivingSet rw.1.copies ∧
      (∃ bs₁ bs₂ bw dw, bs = bs₁ ++ bs₂ ∧
        UL.buildRCopies bundle.inst curHist R bs₁ = some bw ∧
        UL.deleteRCopiesList bundle.inst curHist bundle.inst.gen.P₀ bundle.deletedIds bw.1 bs₂ = some dw ∧
        rw.1.copies.map Prod.fst = bw.1.map Prod.fst ∧
        rw.2 = bw.2 + dw.2)) ∧
    expWithBits (UL.rebuildCompiledBundle R curHist bundle)
      (fun rw => (rw.2 : ENNReal) + copiesRemWork bundle.inst bundle.survivingSet rw.1.copies) ≤
      (R : ENNReal) * ENNReal.ofReal ((bundle.inst.gen.m : ℝ) * A_n * P_fac) := by
  obtain ⟨hpf_b, hhp_b, hinv_b, hexp_b⟩ := buildRCopies_props hVar R
  have hsub0 : bundle.inst.gen.IsSurvivingSubset bundle.inst.gen.P₀ := Finset.Subset.refl _
  have hpf_d : ∀ bs₁ bw,
      UL.buildRCopies bundle.inst curHist R bs₁ = some bw →
      IsPrefixFree (UL.bindWithBits
        (UL.deleteRCopiesList bundle.inst curHist bundle.inst.gen.P₀ bundle.deletedIds bw.1)
        (fun dw => UL.pureWithBits
          ({ bundle with epochBirthHist := curHist, copies := dw.1 }, bw.2 + dw.2))) := by
    intro bs₁ bw hbw
    have hacc_b := (hinv_b bs₁ bw hbw).2
    exact (deleteRCopiesList_props (curHist := curHist) hVar hreplay hsub0 bw.1 hacc_b).1.bindWithBits
      (fun _ _ _ => isPrefixFree_pureWithBits _)
  have hhp_d : ∀ bs₁ bw,
      UL.buildRCopies bundle.inst curHist R bs₁ = some bw →
      haltProb (UL.bindWithBits
        (UL.deleteRCopiesList bundle.inst curHist bundle.inst.gen.P₀ bundle.deletedIds bw.1)
        (fun dw => UL.pureWithBits
          ({ bundle with epochBirthHist := curHist, copies := dw.1 }, bw.2 + dw.2))) = 1 := by
    intro bs₁ bw hbw
    have hacc_b := (hinv_b bs₁ bw hbw).2
    obtain ⟨hpf_l, hhp_l, _, _⟩ :=
      deleteRCopiesList_props (curHist := curHist) hVar hreplay hsub0 bw.1 hacc_b
    exact haltProb_bindWithBits hpf_l hhp_l (fun _ _ _ => haltProb_pureWithBits _)
  refine ⟨hpf_b.bindWithBits hpf_d, haltProb_bindWithBits hpf_b hhp_b hhp_d, ?_, ?_⟩
  · intro bs rw h
    unfold UL.rebuildCompiledBundle at h
    rw [bindWithBits_eq_some_iff hpf_b] at h
    rcases h with ⟨bs₁, bs₂, bw, rfl, hbw, h2⟩
    obtain ⟨hlen_b, hacc_b⟩ := hinv_b bs₁ bw hbw
    obtain ⟨hpf_l, _, hinv_l, _⟩ :=
      deleteRCopiesList_props (curHist := curHist) hVar hreplay hsub0 bw.1 hacc_b
    rw [bindWithBits_eq_some_iff hpf_l] at h2
    rcases h2 with ⟨bs₂₁, bs₂₂, dw, rfl, hdw, hpure⟩
    rw [pureWithBits_eq_some_iff] at hpure
    rcases hpure with ⟨rfl, rfl⟩
    obtain ⟨hfst_l, hacc_l⟩ := hinv_l bs₂₁ dw hdw
    have hlen_dw : dw.1.length = R := by
      have h1 := congrArg List.length hfst_l
      simpa [hlen_b] using h1
    refine ⟨rfl, rfl, rfl, rfl, hlen_dw, hacc_l,
      ⟨bs₁, bs₂₁, bw, dw, by simp, hbw, hdw, hfst_l, rfl⟩⟩
  · unfold UL.rebuildCompiledBundle
    rw [expWithBits_bind hpf_b]
    refine (expWithBits_mono ?_).trans hexp_b
    intro bs₁ bw hbw
    obtain ⟨_, hacc_b⟩ := hinv_b bs₁ bw hbw
    obtain ⟨hpf_l, hhp_l, _, hexp_l⟩ :=
      deleteRCopiesList_props (curHist := curHist) hVar hreplay hsub0 bw.1 hacc_b
    rw [expWithBits_bind hpf_l]
    have hpure_eq :
        (fun dw : List (BirthState × PhaseState) × ℕ =>
          expWithBits (UL.pureWithBits ({ bundle with epochBirthHist := curHist, copies := dw.1 }, bw.2 + dw.2))
            (fun rw => (rw.2 : ENNReal) + copiesRemWork bundle.inst bundle.survivingSet rw.1.copies)) =
        fun dw =>
          (bw.2 : ENNReal) + ((dw.2 : ENNReal) + copiesRemWork bundle.inst bundle.survivingSet dw.1) := by
      ext dw
      rw [expWithBits_pure]
      simp only [Nat.cast_add]
      ring
    rw [hpure_eq, expWithBits_const_add_of_haltProb_one hhp_l]
    gcongr

end UL.Proof.lem_C_3.RacerCG
