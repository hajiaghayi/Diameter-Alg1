import Mathlib
import UL.Proof.lem_C_3.RacerCG_H2b
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof.lem_C_3.RacerCG

/-! ### 1. `withConsumedBits`, `Fin.snoc`, and `List.set` helpers -/

def withConsumedBits {α : Type} (f : List Bool → Option α) (bs : List Bool) :
    Option (List Bool × α) :=
  (f bs).map (fun x => (bs, x))

theorem IsPrefixFree.withConsumedBits {α : Type} {f : List Bool → Option α}
    (hf : IsPrefixFree f) : IsPrefixFree (withConsumedBits f) := by
  intro bs₁ bs₂ p₁ p₂ h1 h2 hpref
  simp only [RacerCG.withConsumedBits, Option.map_eq_some_iff] at h1 h2
  rcases h1 with ⟨a₁, ha₁, _⟩
  rcases h2 with ⟨a₂, ha₂, _⟩
  exact hf bs₁ bs₂ a₁ a₂ ha₁ ha₂ hpref

theorem haltProb_withConsumedBits {α : Type} (f : List Bool → Option α) :
    haltProb (withConsumedBits f) = haltProb f := by
  unfold haltProb withConsumedBits
  refine tsum_congr (fun bs => ?_)
  cases f bs <;> rfl

theorem withConsumedBits_eq_some_iff {α : Type} (f : List Bool → Option α)
    (bs : List Bool) (px : List Bool × α) :
    withConsumedBits f bs = some px ↔ px.1 = bs ∧ f bs = some px.2 := by
  unfold withConsumedBits
  cases h : f bs with
  | none => simp
  | some a =>
    rcases px with ⟨u, x⟩
    simp only [Option.map_some, Option.some.injEq, Prod.mk.injEq]
    constructor
    · rintro ⟨rfl, rfl⟩
      exact ⟨rfl, rfl⟩
    · rintro ⟨rfl, rfl⟩
      exact ⟨rfl, rfl⟩

theorem expWithBits_withConsumedBits_const_fst {α : Type}
    (f : List Bool → Option α) (W : α → ENNReal) :
    expWithBits (withConsumedBits f) (fun px => W px.2) = expWithBits f W := by
  unfold expWithBits withConsumedBits
  refine tsum_congr (fun bs => ?_)
  cases f bs <;> rfl

theorem inlined_bind_eq_bindWithBits {α β : Type}
    {f : List Bool → Option α} (hf : IsPrefixFree f)
    (G : List Bool → α → List Bool → Option β) (bs : List Bool) :
    (open Classical in
      if h : ∃ (bs₁ bs₂ : List Bool) (x : α), bs = bs₁ ++ bs₂ ∧ f bs₁ = some x then
        let bs₁ := Classical.choose h
        let h₂ := Classical.choose_spec h
        let bs₂ := Classical.choose h₂
        let h₃ := Classical.choose_spec h₂
        let x := Classical.choose h₃
        G bs₁ x bs₂
      else
        none) =
    UL.bindWithBits (withConsumedBits f) (fun px => G px.1 px.2) bs := by
  by_cases hex : ∃ (bs₁ bs₂ : List Bool) (x : α), bs = bs₁ ++ bs₂ ∧ f bs₁ = some x
  · rw [dif_pos hex]
    dsimp only
    let u₁ := Classical.choose hex
    let h₂ := Classical.choose_spec hex
    let v₁ := Classical.choose h₂
    let h₃ := Classical.choose_spec h₂
    let x₁ := Classical.choose h₃
    have h_uv : bs = u₁ ++ v₁ := (Classical.choose_spec h₃).1
    have hx₁ : f u₁ = some x₁ := (Classical.choose_spec h₃).2
    have hwc : withConsumedBits f u₁ = some (u₁, x₁) := by
      simp [withConsumedBits, hx₁]
    conv_rhs => rw [h_uv]
    rw [bindWithBits_eq_of_prefixFree hf.withConsumedBits (fun px => G px.1 px.2) hwc]
  · rw [dif_neg hex]
    unfold UL.bindWithBits
    have hex2 : ¬ ∃ (u v : List Bool) (px : List Bool × α),
        bs = u ++ v ∧ withConsumedBits f u = some px := by
      rintro ⟨u, v, ⟨_, x⟩, rfl, hwc⟩
      simp only [withConsumedBits, Option.map_eq_some_iff] at hwc
      rcases hwc with ⟨a, ha, _⟩
      exact hex ⟨u, v, a, rfl, ha⟩
    rw [dif_neg hex2]

theorem list_ofFn_snoc {k : ℕ} {α : Type*} (g : Fin k → α) (x : α) :
    List.ofFn (Fin.snoc g x) = List.ofFn g ++ [x] := by
  refine List.ext_getElem (by simp) (fun i h1 h2 => ?_)
  rw [List.getElem_ofFn]
  by_cases hik : i < k
  · have hcast : ∀ hp : i < k + 1, (⟨i, hp⟩ : Fin (k + 1)) = (⟨i, hik⟩ : Fin k).castSucc :=
      fun _ => Fin.ext rfl
    rw [hcast, Fin.snoc_castSucc, List.getElem_append_left (by simpa using hik), List.getElem_ofFn]
  · have hik_eq : i = k := by
      simp only [List.length_ofFn] at h1
      omega
    have hlast : ∀ hp : i < k + 1, (⟨i, hp⟩ : Fin (k + 1)) = Fin.last k :=
      fun _ => Fin.ext hik_eq
    rw [hlast, Fin.snoc_last, List.getElem_append_right (by simp [hik_eq])]
    simp [hik_eq]

theorem list_map_sum_set {α : Type*} (xs : List α) (f : α → ℕ)
    {gid : ℕ} {x₀ : α} (hget : xs[gid]? = some x₀) (x₁ : α) :
    ((xs.set gid x₁).map f).sum + f x₀ = (xs.map f).sum + f x₁ := by
  induction xs generalizing gid with
  | nil => simp at hget
  | cons hd tl ih =>
    cases gid with
    | zero =>
      simp only [List.getElem?_cons_zero, Option.some.injEq] at hget
      subst hget
      simp [List.set]
      omega
    | succ g =>
      simp only [List.getElem?_cons_succ] at hget
      have h1 := ih hget
      simp only [List.set, List.map_cons, List.sum_cons]
      omega

theorem list_filter_isSome_set {α : Type*} (xs : List (Option α))
    {gid : ℕ} {b₀ : α} (hget : xs[gid]? = some (some b₀)) (v₁ : Option α) :
    ((xs.set gid v₁).filter Option.isSome).length + 1 =
      (xs.filter Option.isSome).length + (if v₁.isSome then 1 else 0) := by
  induction xs generalizing gid with
  | nil => simp at hget
  | cons hd tl ih =>
    cases gid with
    | zero =>
      simp only [List.getElem?_cons_zero, Option.some.injEq] at hget
      subst hget
      cases v₁ <;> simp [List.set]
    | succ g =>
      simp only [List.getElem?_cons_succ] at hget
      have h1 := ih hget
      cases hd <;> cases v₁ <;> simp [List.set] at h1 ⊢ <;> omega

theorem runCompiledSearchStepsFrom_append
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d_param B n : ℕ)
    (ctrl : UL.AdaptiveSearchController ι d d_s BirthState PhaseState) :
    ∀ (l₁ l₂ : List (List Bool))
      (cur mid : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState),
      UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl cur l₁ = some mid →
      UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl cur (l₁ ++ l₂) =
        UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl mid l₂ := by
  intro l₁
  induction l₁ with
  | nil =>
    intro l₂ cur mid h
    simp only [UL.runCompiledSearchStepsFrom, Option.some.injEq] at h
    subst h
    rfl
  | cons bs rest ih =>
    intro l₂ cur mid h
    simp only [UL.runCompiledSearchStepsFrom, List.cons_append] at h ⊢
    cases hstep : UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl cur bs with
    | none => simp [hstep] at h
    | some nxt =>
      dsimp only at h ⊢
      exact ih l₂ nxt mid (by simpa [hstep] using h)

/-! ### 2. Compiler system invariant, intra-step reachability, and Lyapunov potential -/

noncomputable def c3_P_out
    (P_fac netLogBound : ℕ → ℕ → ℕ → ℝ)
    (B_birth : ℕ → ℕ → ℝ)
    (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d B n : ℕ) : ℝ :=
  (6 * B_birth d n + 4 * Q_poly d B n) * (c3_R_of (netLogBound d B n) : ℝ) * P_fac d B n

def IsValidSystemState
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (d_param B n : ℕ) (σ A_n : ℝ)
    (P_fac netLogBound : ℕ → ℕ → ℕ → ℝ)
    (B_birth : ℕ → ℕ → ℝ)
    (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s)))
    (cur : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState) : Prop :=
  let R := c3_R_of (netLogBound d_param B n)
  let u := cur.history.length
  cur.generations.length = cur.birthSnapshots.length ∧
  (∀ gid : ℕ, ∀ bundle,
    cur.generations[gid]? = some (some bundle) →
      ∃ birthHist birthBits,
        cur.birthSnapshots[gid]? = some (birthHist, birthBits) ∧
        IsValidLiveBundle (n := n) R σ A_n (P_fac d_param B n) (netLogBound d_param B n)
          (netOfBirth gid birthHist bundle.inst) bundle) ∧
  (∀ qRec ∈ cur.queryRecords,
    qRec.gen.IsCorrectAnswer qRec.survivingSet qRec.query qRec.answer) ∧
  cur.generations.length ≤ cur.totalBirthCard ∧
  cur.totalDeletes +
    (cur.generations.map (fun opt => match opt with | some b => b.survivingSet.card | none => 0)).sum ≤
    cur.totalBirthCard ∧
  cur.totalCancels + (cur.generations.filter Option.isSome).length ≤ cur.generations.length ∧
  (cur.totalBirthCard : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * B_birth d_param n ∧
  (cur.totalQueries : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * Q_poly d_param B n

def actionPhi {ι : Type} {d d_s : ℕ} {BirthState PhaseState : Type}
    (cur : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState) : ℕ :=
  cur.generations.length + cur.totalDeletes + cur.totalCancels + cur.totalQueries

noncomputable def maxActionPhi
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d_param B n u : ℕ) : ℕ :=
  3 * Nat.floor (((u + 1 : ℕ) : ℝ) * B_birth d_param n) +
    Nat.floor (((u + 1 : ℕ) : ℝ) * Q_poly d_param B n)

theorem actionPhi_le_maxActionPhi
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    {d_param B n : ℕ} {σ A_n : ℝ}
    {P_fac netLogBound : ℕ → ℕ → ℕ → ℝ}
    {B_birth : ℕ → ℕ → ℝ} {Q_poly : ℕ → ℕ → ℕ → ℝ}
    {netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s))}
    {cur : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState}
    (_ : 0 ≤ B_birth d_param n)
    (_ : 0 ≤ Q_poly d_param B n)
    (hcur : IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth cur) :
    actionPhi cur ≤ maxActionPhi B_birth Q_poly d_param B n cur.history.length := by
  rcases hcur with ⟨_, _, _, hgen_le, hdel_le, hcan_le, hbirth_r, hq_r⟩
  have hbirth_fl : cur.totalBirthCard ≤
      Nat.floor (((cur.history.length + 1 : ℕ) : ℝ) * B_birth d_param n) :=
    Nat.le_floor hbirth_r
  have hq_fl : cur.totalQueries ≤
      Nat.floor (((cur.history.length + 1 : ℕ) : ℝ) * Q_poly d_param B n) :=
    Nat.le_floor hq_r
  unfold actionPhi maxActionPhi
  omega

/-- Exact intra-step `stepOnce` function matching `IsReachableIntraStepState` in `UL.Stmt.lem_C_3`. -/
noncomputable def c3StepOnce
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (ctrl : UL.AdaptiveSearchController ι d d_s BirthState PhaseState)
    (curAcc : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState × List Bool)
    (bs : List Bool) :
    Option (UL.CompiledSearchSystemState ι d d_s BirthState PhaseState × List Bool) :=
  match ctrl.nextAction curAcc.1 with
  | .finishExternalStep _ => none
  | .openGen inst =>
      (UL.buildRCopies inst curAcc.1.history R bs).map (fun bw =>
        let bundle : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState :=
          { inst := inst
            epochBirthHist := curAcc.1.history
            survivingSet := inst.gen.P₀
            deletedIds := []
            copies := bw.1 }
        ({ curAcc.1 with
            generations := curAcc.1.generations ++ [some bundle]
            birthSnapshots := curAcc.1.birthSnapshots ++ [(curAcc.1.history, bs)]
            totalBirthCard := curAcc.1.totalBirthCard + inst.gen.m
            totalSearchWork := curAcc.1.totalSearchWork + bw.2 },
         curAcc.2 ++ bs))
  | .deleteFromGen gid i =>
      match curAcc.1.generations[gid]? with
      | some (some bundle) =>
          if i ∈ bundle.survivingSet then
            (UL.deleteRCopies bundle.inst curAcc.1.history bundle.survivingSet i bundle.copies bs).map
              (fun dw =>
                let bundle' : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState :=
                  { bundle with
                    survivingSet := bundle.survivingSet.erase i
                    deletedIds := bundle.deletedIds ++ [i]
                    copies := dw.1 }
                ({ curAcc.1 with
                    generations := curAcc.1.generations.set gid (some bundle')
                    totalDeletes := curAcc.1.totalDeletes + 1
                    totalSearchWork := curAcc.1.totalSearchWork + dw.2 },
                 curAcc.2 ++ bs))
          else none
      | _ => none
  | .cancelGen gid =>
      match curAcc.1.generations[gid]? with
      | some (some _) =>
          if bs.isEmpty then
            some ({ curAcc.1 with
                      generations := curAcc.1.generations.set gid none
                      totalCancels := curAcc.1.totalCancels + 1 },
                  curAcc.2)
          else none
      | _ => none
  | .queryGen gid q =>
      match curAcc.1.generations[gid]? with
      | some (some bundle) =>
          (UL.runCompiledQuery R cap curAcc.1.history bundle q bs).map (fun qw =>
            let qRec : UL.CompiledQueryRecord ι d_s :=
              { gid := gid
                gen := bundle.inst.gen
                survivingSet := bundle.survivingSet
                query := q
                answer := qw.2.1 }
            ({ curAcc.1 with
                generations := curAcc.1.generations.set gid (some qw.1)
                queryRecords := curAcc.1.queryRecords ++ [qRec]
                totalQueries := curAcc.1.totalQueries + 1
                totalSearchWork := curAcc.1.totalSearchWork + qw.2.2 },
             curAcc.2 ++ bs))
      | _ => none

def IsIntraFromBoundary
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d_param B n : ℕ)
    (ctrl : UL.AdaptiveSearchController ι d d_s BirthState PhaseState)
    (prefSt cur : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState)
    (accBits : List Bool) : Prop :=
  (∃ bitTrace : List (List Bool),
    UL.runCompiledSearchSteps R cap B_birth Q_poly d_param B n ctrl bitTrace = some prefSt) ∧
  ∃ (k : ℕ) (subBits : Fin k → List Bool),
    (List.ofFn subBits).foldlM (c3StepOnce R cap ctrl) (prefSt, []) = some (cur, accBits)

theorem IsIntraFromBoundary.toReachable
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    {R cap : ℕ}
    {B_birth : ℕ → ℕ → ℝ} {Q_poly : ℕ → ℕ → ℕ → ℝ}
    {d_param B n : ℕ}
    {ctrl : UL.AdaptiveSearchController ι d d_s BirthState PhaseState}
    {prefSt cur : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState}
    {accBits : List Bool}
    (h : IsIntraFromBoundary R cap B_birth Q_poly d_param B n ctrl prefSt cur accBits) :
    UL.IsReachableIntraStepState R cap B_birth Q_poly d_param B n ctrl cur := by
  rcases h with ⟨⟨bitTrace, hbt⟩, k, subBits, hfold⟩
  exact ⟨bitTrace, prefSt, hbt, k, subBits, accBits, hfold⟩

theorem IsIntraFromBoundary.step
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    {R cap : ℕ}
    {B_birth : ℕ → ℕ → ℝ} {Q_poly : ℕ → ℕ → ℕ → ℝ}
    {d_param B n : ℕ}
    {ctrl : UL.AdaptiveSearchController ι d d_s BirthState PhaseState}
    {prefSt cur next : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState}
    {accBits accBits' bs_step : List Bool}
    (h : IsIntraFromBoundary R cap B_birth Q_poly d_param B n ctrl prefSt cur accBits)
    (hstep : c3StepOnce R cap ctrl (cur, accBits) bs_step = some (next, accBits')) :
    IsIntraFromBoundary R cap B_birth Q_poly d_param B n ctrl prefSt next accBits' := by
  rcases h with ⟨hbt, k, subBits, hfold⟩
  refine ⟨hbt, k + 1, Fin.snoc subBits bs_step, ?_⟩
  rw [list_ofFn_snoc, List.foldlM_append, hfold]
  simp [hstep]

/-! ### 3. Lyapunov supermartingale potential `sysPotential` -/

noncomputable def genSlotCredit
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ) (A_n P_val : ℝ)
    (netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s)))
    (cur : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState)
    (gid : ℕ) : ENNReal :=
  match cur.generations[gid]?, cur.birthSnapshots[gid]? with
  | some (some bundle), some (birthHist, _) =>
      bundleCredit R cap A_n P_val (netOfBirth gid birthHist bundle.inst) bundle
  | _, _ => 0

noncomputable def allGensCredit
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ) (A_n P_val : ℝ)
    (netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s)))
    (cur : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState) : ENNReal :=
  ∑ gid ∈ Finset.range cur.generations.length,
    genSlotCredit R cap A_n P_val netOfBirth cur gid

theorem allGensCredit_append_some
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ) (A_n P_val : ℝ)
    (netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s)))
    (cur next : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState)
    (bundle : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState)
    (birthHist : UL.ExecutionHistory d) (birthBits : List Bool)
    (hlen_eq : cur.generations.length = cur.birthSnapshots.length)
    (hgen_eq : next.generations = cur.generations ++ [some bundle])
    (hsnap_eq : next.birthSnapshots = cur.birthSnapshots ++ [(birthHist, birthBits)]) :
    allGensCredit R cap A_n P_val netOfBirth next =
      allGensCredit R cap A_n P_val netOfBirth cur +
        bundleCredit R cap A_n P_val
          (netOfBirth cur.generations.length birthHist bundle.inst) bundle := by
  unfold allGensCredit
  have hnlen : next.generations.length = cur.generations.length + 1 := by
    simp [hgen_eq]
  rw [hnlen, Finset.sum_range_succ]
  congr 1
  · refine Finset.sum_congr rfl (fun j hj => ?_)
    have hj_lt : j < cur.generations.length := Finset.mem_range.mp hj
    have hj_lt2 : j < cur.birthSnapshots.length := hlen_eq ▸ hj_lt
    unfold genSlotCredit
    rw [hgen_eq, hsnap_eq, List.getElem?_append_left hj_lt, List.getElem?_append_left hj_lt2]
  · unfold genSlotCredit
    have hg1 : next.generations[cur.generations.length]? = some (some bundle) := by
      rw [hgen_eq, List.getElem?_append_right le_rfl]
      simp
    have hg2 : next.birthSnapshots[cur.generations.length]? = some (birthHist, birthBits) := by
      rw [hsnap_eq, hlen_eq, List.getElem?_append_right le_rfl]
      simp
    rw [hg1, hg2]

theorem allGensCredit_set_split
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ) (A_n P_val : ℝ)
    (netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s)))
    (cur next : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState)
    (gid : ℕ) (val : Option (UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState))
    (hgid : gid < cur.generations.length)
    (hgen_eq : next.generations = cur.generations.set gid val)
    (hsnap_eq : next.birthSnapshots = cur.birthSnapshots) :
    let remSum := ∑ j ∈ (Finset.range cur.generations.length).erase gid,
      genSlotCredit R cap A_n P_val netOfBirth cur j
    allGensCredit R cap A_n P_val netOfBirth cur =
      remSum + genSlotCredit R cap A_n P_val netOfBirth cur gid ∧
    allGensCredit R cap A_n P_val netOfBirth next =
      remSum + genSlotCredit R cap A_n P_val netOfBirth next gid := by
  intro remSum
  have hmem : gid ∈ Finset.range cur.generations.length := Finset.mem_range.mpr hgid
  refine ⟨?_, ?_⟩
  · unfold allGensCredit
    rw [← Finset.add_sum_erase _ _ hmem, add_comm]
  · unfold allGensCredit
    have hnlen : next.generations.length = cur.generations.length := by
      simp [hgen_eq]
    rw [hnlen, ← Finset.add_sum_erase _ _ hmem, add_comm]
    congr 1
    refine Finset.sum_congr rfl (fun j hj => ?_)
    have hj_ne : j ≠ gid := (Finset.mem_erase.mp hj).1
    unfold genSlotCredit
    rw [hgen_eq, hsnap_eq, List.getElem?_set_ne hj_ne.symm]

noncomputable def sysPotential
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (d_param B n t : ℕ) (A_n : ℝ)
    (P_fac netLogBound : ℕ → ℕ → ℕ → ℝ)
    (B_birth : ℕ → ℕ → ℝ)
    (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s)))
    (cur : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState) : ENNReal :=
  (cur.totalSearchWork : ENNReal) +
  allGensCredit (c3_R_of (netLogBound d_param B n)) (c3_cap_of A_n (P_fac d_param B n))
    A_n (P_fac d_param B n) netOfBirth cur +
  ((Nat.floor ((t : ℝ) * B_birth d_param n) - cur.totalBirthCard : ℕ) : ENNReal) *
    (6 * (c3_R_of (netLogBound d_param B n) : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)) +
  ((Nat.floor ((t : ℝ) * Q_poly d_param B n) - cur.totalQueries : ℕ) : ENNReal) *
    ((c3_R_of (netLogBound d_param B n) * c3_cap_of A_n (P_fac d_param B n) : ℕ) : ENNReal)

/-! ### 4. Intra-step fuel theorem (`runCompiledStepActionsFuel`) -/

open Classical in
theorem runCompiledStepActionsFuel_props
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    {d_param B n : ℕ} {σ A_n : ℝ}
    {P_fac netLogBound : ℕ → ℕ → ℕ → ℝ}
    {B_birth : ℕ → ℕ → ℝ} {Q_poly : ℕ → ℕ → ℕ → ℝ}
    {ctrl : UL.AdaptiveSearchController ι d d_s BirthState PhaseState}
    {netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s))}
    (hA : 0 ≤ A_n)
    (hP_nn : 0 ≤ P_fac d_param B n)
    (hB_nn : 0 ≤ B_birth d_param n)
    (hQ_nn : 0 ≤ Q_poly d_param B n)
    (hCtrl : ∀ st : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState,
      UL.IsReachableIntraStepState (c3_R_of (netLogBound d_param B n))
        (c3_cap_of A_n (P_fac d_param B n)) B_birth Q_poly d_param B n ctrl st →
        let u : ℕ := st.history.length
        match ctrl.nextAction st with
        | .finishExternalStep _ => True
        | .openGen inst =>
            let gid := st.generations.length
            UL.SatisfiesCertifiedBirthVarOnNet n σ A_n (P_fac d_param B n)
              (netLogBound d_param B n) (netOfBirth gid st.history inst) inst ∧
            ((st.totalBirthCard + inst.gen.m : ℕ) : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * B_birth d_param n
        | .deleteFromGen gid i =>
            ∃ bundle, st.generations[gid]? = some (some bundle) ∧ i ∈ bundle.survivingSet
        | .cancelGen gid =>
            ∃ bundle, st.generations[gid]? = some (some bundle)
        | .queryGen gid q =>
            ∃ bundle birthHist birthBits,
              st.generations[gid]? = some (some bundle) ∧
              st.birthSnapshots[gid]? = some (birthHist, birthBits) ∧
              UL.IsCertifiedCompatible bundle.inst.gen bundle.inst.δ bundle.survivingSet q ∧
              q.z ∈ netOfBirth gid birthHist bundle.inst ∧
              ((st.totalQueries + 1 : ℕ) : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * Q_poly d_param B n)
    (prefSt : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState) :
    let R := c3_R_of (netLogBound d_param B n)
    let cap := c3_cap_of A_n (P_fac d_param B n)
    let u₀ := prefSt.history.length
    ∀ (fuel : ℕ) (cur : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState)
      (accBits : List Bool),
      cur.history = prefSt.history →
      IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth cur →
      IsIntraFromBoundary R cap B_birth Q_poly d_param B n ctrl prefSt cur accBits →
      maxActionPhi B_birth Q_poly d_param B n u₀ + 1 ≤ fuel + actionPhi cur →
      IsPrefixFree (UL.runCompiledStepActionsFuel R cap ctrl fuel cur accBits) ∧
      haltProb (UL.runCompiledStepActionsFuel R cap ctrl fuel cur accBits) = 1 ∧
      (∀ bs out,
        UL.runCompiledStepActionsFuel R cap ctrl fuel cur accBits bs = some out →
          out.history.length = u₀ + 1 ∧
          IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth out) ∧
      (∀ t : ℕ, u₀ < t →
        expWithBits (UL.runCompiledStepActionsFuel R cap ctrl fuel cur accBits)
          (sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth) ≤
          sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth cur) := by
  intro R cap u₀ fuel
  induction fuel with
  | zero =>
    intro cur _ hhist hcur _ hfuel
    exfalso
    have hphi := actionPhi_le_maxActionPhi hB_nn hQ_nn hcur
    rw [hhist] at hphi
    change actionPhi cur ≤ maxActionPhi B_birth Q_poly d_param B n u₀ at hphi
    omega
  | succ fuel ih =>
    intro cur accBits hhist hcur hintra hfuel
    have hact_valid := hCtrl cur hintra.toReachable
    cases hnext : ctrl.nextAction cur with
    | finishExternalStep summary =>
      let entry : UL.StepHistoryEntry d :=
        { operation := summary.operation
          randomBits := accBits
          returnedHandle := summary.returnedHandle
          answer := summary.answer
          resolvedIds := summary.resolvedIds }
      let finSt : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState :=
        { cur with history := cur.history ++ [entry] }
      have hfn_eq : UL.runCompiledStepActionsFuel R cap ctrl (fuel + 1) cur accBits =
          UL.pureWithBits finSt := by
        funext bs
        unfold UL.runCompiledStepActionsFuel UL.pureWithBits
        dsimp only
        rw [hnext]
      rw [hfn_eq]
      refine ⟨isPrefixFree_pureWithBits _, haltProb_pureWithBits _, ?_, ?_⟩
      · intro bs out hp
        rw [pureWithBits_eq_some_iff] at hp
        rcases hp with ⟨_, rfl⟩
        have hlen : finSt.history.length = u₀ + 1 := by
          simp [finSt, hhist, u₀]
        refine ⟨hlen, ?_⟩
        rcases hcur with ⟨h1, h2, h3, h4, h5, h6, h7, h8⟩
        refine ⟨h1, h2, h3, h4, h5, h6, ?_, ?_⟩
        · simp only [finSt, hlen]
          rw [hhist] at h7
          have hmono : ((u₀ + 1 : ℕ) : ℝ) * B_birth d_param n ≤
              ((u₀ + 1 + 1 : ℕ) : ℝ) * B_birth d_param n := by
            refine mul_le_mul_of_nonneg_right ?_ hB_nn
            push_cast
            linarith
          exact h7.trans hmono
        · simp only [finSt, hlen]
          rw [hhist] at h8
          have hmono : ((u₀ + 1 : ℕ) : ℝ) * Q_poly d_param B n ≤
              ((u₀ + 1 + 1 : ℕ) : ℝ) * Q_poly d_param B n := by
            refine mul_le_mul_of_nonneg_right ?_ hQ_nn
            push_cast
            linarith
          exact h8.trans hmono
      · intro t _
        rw [expWithBits_pure]
        -- `sysPotential` does not depend on `history`!
        rfl

    | openGen inst =>
      rw [hnext] at hact_valid
      rcases hact_valid with ⟨hOnNet, hbirth_new⟩
      have hVar_cur := hOnNet cur.history
      obtain ⟨hpf_b, hhp_b, hinv_b, hexp_b⟩ := buildRCopies_props hVar_cur R
      let mkNext := fun (bs₁ : List Bool) (bw : List (BirthState × PhaseState) × ℕ) =>
        let bundle : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState :=
          { inst := inst
            epochBirthHist := cur.history
            survivingSet := inst.gen.P₀
            deletedIds := []
            copies := bw.1 }
        ({ cur with
            generations := cur.generations ++ [some bundle]
            birthSnapshots := cur.birthSnapshots ++ [(cur.history, bs₁)]
            totalBirthCard := cur.totalBirthCard + inst.gen.m
            totalSearchWork := cur.totalSearchWork + bw.2 } :
          UL.CompiledSearchSystemState ι d d_s BirthState PhaseState)
      have hfn_eq : UL.runCompiledStepActionsFuel R cap ctrl (fuel + 1) cur accBits =
          UL.bindWithBits (withConsumedBits (UL.buildRCopies inst cur.history R))
            (fun pbw => UL.runCompiledStepActionsFuel R cap ctrl fuel
              (mkNext pbw.1 pbw.2) (accBits ++ pbw.1)) := by
        funext bs
        unfold UL.runCompiledStepActionsFuel
        dsimp only
        rw [hnext]
        dsimp only
        exact inlined_bind_eq_bindWithBits hpf_b
          (fun bs₁ bw bs₂ => UL.runCompiledStepActionsFuel R cap ctrl fuel
            (mkNext bs₁ bw) (accBits ++ bs₁) bs₂) bs
      have hm_pos : 1 ≤ inst.gen.m := inst.gen.nonempty.card_pos
      have hstep_inv : ∀ bs₁ bw, UL.buildRCopies inst cur.history R bs₁ = some bw →
          let nxt := mkNext bs₁ bw
          nxt.history = prefSt.history ∧
          IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth nxt ∧
          IsIntraFromBoundary R cap B_birth Q_poly d_param B n ctrl prefSt nxt (accBits ++ bs₁) ∧
          maxActionPhi B_birth Q_poly d_param B n u₀ + 1 ≤ fuel + actionPhi nxt := by
        intro bs₁ bw hbw
        dsimp only
        obtain ⟨hlen_bw, hacc_bw⟩ := hinv_b bs₁ bw hbw
        rcases hcur with ⟨hlen_gs, hlive, hqrec, hgen_le, hdel_le, hcan_le, _, hq_r⟩
        have hstep_once : c3StepOnce R cap ctrl (cur, accBits) bs₁ =
            some (mkNext bs₁ bw, accBits ++ bs₁) := by
          unfold c3StepOnce
          simp [hnext, hbw, mkNext]
        have hfuel' : maxActionPhi B_birth Q_poly d_param B n u₀ + 1 ≤
            fuel + actionPhi (mkNext bs₁ bw) := by
          have hphi_eq : actionPhi (mkNext bs₁ bw) = actionPhi cur + 1 := by
            unfold actionPhi
            simp [mkNext]
            omega
          omega
        refine ⟨hhist, ?_, hintra.step hstep_once, hfuel'⟩
        refine ⟨by simp [mkNext, hlen_gs], ?_, hqrec, ?_, ?_, ?_, hbirth_new, hq_r⟩
        · intro gid' b' hget'
          simp only [mkNext] at hget' ⊢
          by_cases hlt : gid' < cur.generations.length
          · rw [List.getElem?_append_left hlt] at hget'
            have hlt2 : gid' < cur.birthSnapshots.length := hlen_gs ▸ hlt
            rw [List.getElem?_append_left hlt2]
            exact hlive gid' b' hget'
          · have hge : cur.generations.length ≤ gid' := Nat.le_of_not_lt hlt
            rw [List.getElem?_append_right hge] at hget'
            by_cases heq : gid' = cur.generations.length
            · subst heq
              simp only [Nat.sub_self, List.getElem?_cons_zero, Option.some.injEq] at hget'
              subst hget'
              rw [hlen_gs, List.getElem?_append_right le_rfl]
              simp only [Nat.sub_self, List.getElem?_cons_zero]
              refine ⟨cur.history, bs₁, rfl, ?_⟩
              rw [← hlen_gs]
              exact ⟨hOnNet, ValidDelReplay.nil _, hlen_bw, hacc_bw⟩
            · have hgt : 1 ≤ gid' - cur.generations.length := by omega
              rcases Nat.exists_eq_add_of_le hgt with ⟨k', hk'⟩
              rw [hk', Nat.add_comm 1 k'] at hget'
              simp at hget'
        · simp only [mkNext, List.length_append, List.length_singleton]
          omega
        · simp only [mkNext, List.map_append, List.map_singleton, List.sum_append, List.sum_cons,
            List.sum_nil, Nat.add_zero]
          change cur.totalDeletes + (_ + inst.gen.m) ≤ cur.totalBirthCard + inst.gen.m
          omega
        · simp only [mkNext, List.filter_append, List.filter_cons, Option.isSome_some, ↓reduceIte,
            List.filter_nil, List.length_append, List.length_cons, List.length_nil]
          omega
      rw [hfn_eq]
      have hpf_wc := hpf_b.withConsumedBits
      have hhp_wc : haltProb (withConsumedBits (UL.buildRCopies inst cur.history R)) = 1 := by
        rw [haltProb_withConsumedBits, hhp_b]
      refine ⟨hpf_wc.bindWithBits (fun _ pbw hwc => ?_),
        haltProb_bindWithBits hpf_wc hhp_wc (fun _ pbw hwc => ?_), ?_, ?_⟩
      · obtain ⟨rfl, hbw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
        obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pbw.1 pbw.2 hbw
        exact (ih (mkNext pbw.1 pbw.2) (accBits ++ pbw.1) hh' hv' hi' hf').1
      · obtain ⟨rfl, hbw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
        obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pbw.1 pbw.2 hbw
        exact (ih (mkNext pbw.1 pbw.2) (accBits ++ pbw.1) hh' hv' hi' hf').2.1
      · intro bs out hrun
        rw [bindWithBits_eq_some_iff hpf_wc] at hrun
        rcases hrun with ⟨bs₁, bs₂, pbw, _, hwc, h2⟩
        obtain ⟨rfl, hbw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
        obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pbw.1 pbw.2 hbw
        exact (ih (mkNext pbw.1 pbw.2) (accBits ++ pbw.1) hh' hv' hi' hf').2.2.1 bs₂ out h2
      · intro t hu₀_lt
        rw [expWithBits_bind hpf_wc]
        let N_gid := netOfBirth cur.generations.length cur.history inst
        let B_cap := Nat.floor ((t : ℝ) * B_birth d_param n)
        let Q_cap := Nat.floor ((t : ℝ) * Q_poly d_param B n)
        let unitBirthCost : ENNReal := 6 * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)
        let unitQueryCost : ENNReal := ((R * cap : ℕ) : ENNReal)
        let mkBundle := fun bw : List (BirthState × PhaseState) × ℕ =>
          ({ inst := inst
             epochBirthHist := cur.history
             survivingSet := inst.gen.P₀
             deletedIds := []
             copies := bw.1 } : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState)
        have hmono_ih : expWithBits (withConsumedBits (UL.buildRCopies inst cur.history R))
            (fun pbw => expWithBits (UL.runCompiledStepActionsFuel R cap ctrl fuel
                (mkNext pbw.1 pbw.2) (accBits ++ pbw.1))
              (sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth)) ≤
            expWithBits (UL.buildRCopies inst cur.history R)
              (fun bw =>
                ((cur.totalSearchWork : ENNReal) +
                  allGensCredit R cap A_n (P_fac d_param B n) netOfBirth cur +
                  ((B_cap - (cur.totalBirthCard + inst.gen.m) : ℕ) : ENNReal) * unitBirthCost +
                  ((Q_cap - cur.totalQueries : ℕ) : ENNReal) * unitQueryCost) +
                ((bw.2 : ENNReal) +
                  bundleCredit R cap A_n (P_fac d_param B n) N_gid (mkBundle bw))) := by
          rw [← expWithBits_withConsumedBits_const_fst (UL.buildRCopies inst cur.history R)]
          refine expWithBits_mono (fun _ pbw hwc => ?_)
          obtain ⟨rfl, hbw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
          obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pbw.1 pbw.2 hbw
          have hih_le := (ih (mkNext pbw.1 pbw.2) (accBits ++ pbw.1) hh' hv' hi' hf').2.2.2 t hu₀_lt
          refine hih_le.trans ?_
          unfold sysPotential
          have hcred_app := allGensCredit_append_some R cap A_n (P_fac d_param B n) netOfBirth
            cur (mkNext pbw.1 pbw.2) (mkBundle pbw.2) cur.history pbw.1 hcur.1 rfl rfl
          rw [hcred_app]
          dsimp only [mkNext, B_cap, Q_cap, unitBirthCost, unitQueryCost, N_gid]
          simp only [Nat.cast_add]
          exact le_of_eq (by ring)
        -- Bound `E[bw.2 + bundleCredit]` by `m * unitBirthCost`
        have hbad_half := buildRCopies_bad_prob_le_half hVar_cur
        let M_cost := bundleEpochCost R inst.gen.m cap A_n (P_fac d_param B n)
        have hexp_bundle : expWithBits (UL.buildRCopies inst cur.history R)
            (fun bw => (bw.2 : ENNReal) +
              bundleCredit R cap A_n (P_fac d_param B n) N_gid (mkBundle bw)) ≤
            (inst.gen.m : ENNReal) * unitBirthCost := by
          have hsplit_cred :
              (fun bw : List (BirthState × PhaseState) × ℕ =>
                (bw.2 : ENNReal) + bundleCredit R cap A_n (P_fac d_param B n) N_gid (mkBundle bw)) =
              fun bw =>
                ((bw.2 : ENNReal) + copiesRemWork inst inst.gen.P₀ bw.1) +
                (if ¬ IsGoodCopies inst N_gid cap bw.1 then (1 : ENNReal) else 0) * (2 * M_cost) := by
            ext bw
            unfold bundleCredit
            dsimp only [mkBundle, M_cost]
            by_cases hg : IsGoodCopies inst N_gid cap bw.1 <;> simp [hg] <;> ring
          rw [hsplit_cred, expWithBits_add, expWithBits_const_mul]
          have hhalf_2M : (2 : ENNReal)⁻¹ * (2 * M_cost) = M_cost := by
            rw [← mul_assoc, ENNReal.inv_mul_cancel (by norm_num) (by simp), one_mul]
          have hm_ofReal : ENNReal.ofReal ((inst.gen.m : ℝ) * A_n * P_fac d_param B n) =
              (inst.gen.m : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n) := by
            rw [mul_assoc, ENNReal.ofReal_mul (Nat.cast_nonneg _), ENNReal.ofReal_natCast]
          have hcap_le : ((R * cap : ℕ) : ENNReal) ≤
              4 * (inst.gen.m : ENNReal) * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n) := by
            have hc_real : (cap : ℝ) ≤ 4 * (A_n * P_fac d_param B n) := by
              simpa [cap, mul_assoc] using c3_cap_of_le hA hP_nn
            have hc_enn : (cap : ENNReal) ≤ 4 * ENNReal.ofReal (A_n * P_fac d_param B n) := by
              have h1 : ENNReal.ofReal (cap : ℝ) ≤ ENNReal.ofReal (4 * (A_n * P_fac d_param B n)) :=
                ENNReal.ofReal_le_ofReal hc_real
              rw [ENNReal.ofReal_natCast, ENNReal.ofReal_mul (by norm_num),
                  show ENNReal.ofReal 4 = (4 : ENNReal) by norm_num] at h1
              exact h1
            have hm1 : (1 : ENNReal) ≤ (inst.gen.m : ENNReal) := by exact_mod_cast hm_pos
            calc
              ((R * cap : ℕ) : ENNReal) = (R : ENNReal) * (cap : ENNReal) := by push_cast; rfl
              _ ≤ (R : ENNReal) * (4 * ENNReal.ofReal (A_n * P_fac d_param B n)) :=
                    mul_le_mul_right hc_enn _
              _ = 1 * (4 * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)) := by ring
              _ ≤ (inst.gen.m : ENNReal) * (4 * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)) :=
                    mul_le_mul_right' hm1 _
              _ = _ := by ring
          calc
            _ ≤ (R : ENNReal) * ENNReal.ofReal ((inst.gen.m : ℝ) * A_n * P_fac d_param B n) +
                (2 : ENNReal)⁻¹ * (2 * M_cost) := by
                  gcongr
            _ = (R : ENNReal) * ENNReal.ofReal ((inst.gen.m : ℝ) * A_n * P_fac d_param B n) +
                ((R : ENNReal) * ENNReal.ofReal ((inst.gen.m : ℝ) * A_n * P_fac d_param B n) +
                 ((R * cap : ℕ) : ENNReal)) := by
                  rw [hhalf_2M]
                  rfl
            _ ≤ (R : ENNReal) * ((inst.gen.m : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)) +
                ((R : ENNReal) * ((inst.gen.m : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)) +
                 4 * (inst.gen.m : ENNReal) * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)) := by
                  rw [hm_ofReal]
                  gcongr
            _ = (inst.gen.m : ENNReal) * unitBirthCost := by
                  dsimp only [unitBirthCost]
                  ring
        have hB_le : cur.totalBirthCard + inst.gen.m ≤ B_cap := by
          apply Nat.le_floor
          have hu_le_t : ((cur.history.length + 1 : ℕ) : ℝ) ≤ (t : ℝ) := by
            rw [hhist]
            exact_mod_cast (show u₀ + 1 ≤ t by omega)
          exact hbirth_new.trans (mul_le_mul_of_nonneg_right hu_le_t hB_nn)
        have hB_sub : ((B_cap - (cur.totalBirthCard + inst.gen.m) : ℕ) : ENNReal) +
            (inst.gen.m : ENNReal) = ((B_cap - cur.totalBirthCard : ℕ) : ENNReal) := by
          exact_mod_cast (show B_cap - (cur.totalBirthCard + inst.gen.m) + inst.gen.m =
            B_cap - cur.totalBirthCard by omega)
        calc
          _ ≤ _ := hmono_ih
          _ = ((cur.totalSearchWork : ENNReal) +
                allGensCredit R cap A_n (P_fac d_param B n) netOfBirth cur +
                ((B_cap - (cur.totalBirthCard + inst.gen.m) : ℕ) : ENNReal) * unitBirthCost +
                ((Q_cap - cur.totalQueries : ℕ) : ENNReal) * unitQueryCost) +
              expWithBits (UL.buildRCopies inst cur.history R)
                (fun bw => (bw.2 : ENNReal) +
                  bundleCredit R cap A_n (P_fac d_param B n) N_gid (mkBundle bw)) :=
                expWithBits_const_add_of_haltProb_one hhp_b _ _
          _ ≤ ((cur.totalSearchWork : ENNReal) +
                allGensCredit R cap A_n (P_fac d_param B n) netOfBirth cur +
                ((B_cap - (cur.totalBirthCard + inst.gen.m) : ℕ) : ENNReal) * unitBirthCost +
                ((Q_cap - cur.totalQueries : ℕ) : ENNReal) * unitQueryCost) +
              (inst.gen.m : ENNReal) * unitBirthCost := by gcongr
          _ = sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth cur := by
                unfold sysPotential
                dsimp only [B_cap, Q_cap, unitBirthCost, unitQueryCost]
                calc
                  _ = (cur.totalSearchWork : ENNReal) +
                        allGensCredit R cap A_n (P_fac d_param B n) netOfBirth cur +
                        (((B_cap - (cur.totalBirthCard + inst.gen.m) : ℕ) : ENNReal) +
                          (inst.gen.m : ENNReal)) * unitBirthCost +
                        ((Q_cap - cur.totalQueries : ℕ) : ENNReal) * unitQueryCost := by ring
                  _ = _ := by rw [hB_sub]

    | deleteFromGen gid i =>
      rw [hnext] at hact_valid
      rcases hact_valid with ⟨bundle, hget_b, hi_mem⟩
      obtain ⟨birthHist, birthBits, hsnap_b, hvb⟩ := hcur.2.1 gid bundle hget_b
      have hgid_lt : gid < cur.generations.length := by
        rcases List.getElem?_eq_some_iff.mp hget_b with ⟨hlt, _⟩
        exact hlt
      obtain ⟨hpf_d, hhp_d, hinv_d, hexp_d⟩ :=
        deleteRCopies_props (stepHist := cur.history)
          (hvb.1 bundle.epochBirthHist) hvb.2.1.subset hi_mem bundle.copies hvb.2.2.2
      let mkNext := fun dw : List (BirthState × PhaseState) × ℕ =>
        let bundle' : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState :=
          { bundle with
            survivingSet := bundle.survivingSet.erase i
            deletedIds := bundle.deletedIds ++ [i]
            copies := dw.1 }
        ({ cur with
            generations := cur.generations.set gid (some bundle')
            totalDeletes := cur.totalDeletes + 1
            totalSearchWork := cur.totalSearchWork + dw.2 } :
          UL.CompiledSearchSystemState ι d d_s BirthState PhaseState)
      have hfn_eq : UL.runCompiledStepActionsFuel R cap ctrl (fuel + 1) cur accBits =
          UL.bindWithBits
            (withConsumedBits (UL.deleteRCopies bundle.inst cur.history bundle.survivingSet i bundle.copies))
            (fun pdw => UL.runCompiledStepActionsFuel R cap ctrl fuel
              (mkNext pdw.2) (accBits ++ pdw.1)) := by
        funext bs
        unfold UL.runCompiledStepActionsFuel
        dsimp only
        rw [hnext]
        dsimp only
        rw [hget_b]
        dsimp only
        rw [if_pos hi_mem]
        exact inlined_bind_eq_bindWithBits hpf_d
          (fun bs₁ dw bs₂ => UL.runCompiledStepActionsFuel R cap ctrl fuel
            (mkNext dw) (accBits ++ bs₁) bs₂) bs
      have hstep_inv : ∀ bs₁ dw,
          UL.deleteRCopies bundle.inst cur.history bundle.survivingSet i bundle.copies bs₁ = some dw →
          let nxt := mkNext dw
          nxt.history = prefSt.history ∧
          IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth nxt ∧
          IsIntraFromBoundary R cap B_birth Q_poly d_param B n ctrl prefSt nxt (accBits ++ bs₁) ∧
          maxActionPhi B_birth Q_poly d_param B n u₀ + 1 ≤ fuel + actionPhi nxt := by
        intro bs₁ dw hdw
        dsimp only
        obtain ⟨hfst_dw, hacc_dw⟩ := hinv_d bs₁ dw hdw
        have hlen_dw : dw.1.length = R := by
          have h1 := congrArg List.length hfst_dw
          simpa [hvb.2.2.1] using h1
        have hstep_once : c3StepOnce R cap ctrl (cur, accBits) bs₁ =
            some (mkNext dw, accBits ++ bs₁) := by
          unfold c3StepOnce
          simp [hnext, hget_b, hi_mem, hdw, mkNext]
        have hfuel' : maxActionPhi B_birth Q_poly d_param B n u₀ + 1 ≤
            fuel + actionPhi (mkNext dw) := by
          have hphi_eq : actionPhi (mkNext dw) = actionPhi cur + 1 := by
            unfold actionPhi
            simp [mkNext]
            omega
          omega
        rcases hcur with ⟨hlen_gs, hlive, hqrec, hgen_le, hdel_le, hcan_le, hbirth_r, hq_r⟩
        refine ⟨hhist, ?_, hintra.step hstep_once, hfuel'⟩
        refine ⟨by simp [mkNext, hlen_gs], ?_, hqrec, by simp [mkNext, hgen_le], ?_, ?_, hbirth_r, hq_r⟩
        · intro gid' b' hget'
          simp only [mkNext] at hget' ⊢
          by_cases heq : gid' = gid
          · subst heq
            rw [List.getElem?_set_self hgid_lt] at hget'
            simp only [Option.some.injEq] at hget'
            subst hget'
            exact ⟨birthHist, birthBits, hsnap_b,
              ⟨hvb.1, hvb.2.1.snoc hi_mem, hlen_dw, hacc_dw⟩⟩
          · rw [List.getElem?_set_ne (Ne.symm heq)] at hget'
            exact hlive gid' b' hget'
        · simp only [mkNext]
          have hsum_set := list_map_sum_set cur.generations
            (fun opt => match opt with | some b => b.survivingSet.card | none => 0)
            hget_b (some { bundle with
              survivingSet := bundle.survivingSet.erase i
              deletedIds := bundle.deletedIds ++ [i]
              copies := dw.1 })
          have hcard_er : (bundle.survivingSet.erase i).card + 1 = bundle.survivingSet.card :=
            Finset.card_erase_add_one hi_mem
          dsimp only at hsum_set
          omega
        · simp only [mkNext, List.length_set]
          have hflt := list_filter_isSome_set cur.generations hget_b
            (some { bundle with
              survivingSet := bundle.survivingSet.erase i
              deletedIds := bundle.deletedIds ++ [i]
              copies := dw.1 })
          simp at hflt
          omega
      rw [hfn_eq]
      have hpf_wc := hpf_d.withConsumedBits
      have hhp_wc : haltProb (withConsumedBits
          (UL.deleteRCopies bundle.inst cur.history bundle.survivingSet i bundle.copies)) = 1 := by
        rw [haltProb_withConsumedBits, hhp_d]
      refine ⟨hpf_wc.bindWithBits (fun _ pdw hwc => ?_),
        haltProb_bindWithBits hpf_wc hhp_wc (fun _ pdw hwc => ?_), ?_, ?_⟩
      · obtain ⟨rfl, hdw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
        obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pdw.1 pdw.2 hdw
        exact (ih (mkNext pdw.2) (accBits ++ pdw.1) hh' hv' hi' hf').1
      · obtain ⟨rfl, hdw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
        obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pdw.1 pdw.2 hdw
        exact (ih (mkNext pdw.2) (accBits ++ pdw.1) hh' hv' hi' hf').2.1
      · intro bs out hrun
        rw [bindWithBits_eq_some_iff hpf_wc] at hrun
        rcases hrun with ⟨bs₁, bs₂, pdw, _, hwc, h2⟩
        obtain ⟨rfl, hdw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
        obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pdw.1 pdw.2 hdw
        exact (ih (mkNext pdw.2) (accBits ++ pdw.1) hh' hv' hi' hf').2.2.1 bs₂ out h2
      · intro t hu₀_lt
        rw [expWithBits_bind hpf_wc]
        let N_gid := netOfBirth gid birthHist bundle.inst
        let remSum := ∑ j ∈ (Finset.range cur.generations.length).erase gid,
          genSlotCredit R cap A_n (P_fac d_param B n) netOfBirth cur j
        let restBudget :=
          ((Nat.floor ((t : ℝ) * B_birth d_param n) - cur.totalBirthCard : ℕ) : ENNReal) *
            (6 * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)) +
          ((Nat.floor ((t : ℝ) * Q_poly d_param B n) - cur.totalQueries : ℕ) : ENNReal) *
            ((R * cap : ℕ) : ENNReal)
        let badCred : ENNReal :=
          if IsGoodCopies bundle.inst N_gid cap bundle.copies then 0
          else 2 * bundleEpochCost R bundle.inst.gen.m cap A_n (P_fac d_param B n)
        have hmono_ih : expWithBits
            (withConsumedBits (UL.deleteRCopies bundle.inst cur.history bundle.survivingSet i bundle.copies))
            (fun pdw => expWithBits (UL.runCompiledStepActionsFuel R cap ctrl fuel
                (mkNext pdw.2) (accBits ++ pdw.1))
              (sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth)) ≤
            expWithBits (UL.deleteRCopies bundle.inst cur.history bundle.survivingSet i bundle.copies)
              (fun dw =>
                ((cur.totalSearchWork : ENNReal) + remSum + badCred + restBudget) +
                ((dw.2 : ENNReal) + copiesRemWork bundle.inst (bundle.survivingSet.erase i) dw.1)) := by
          rw [← expWithBits_withConsumedBits_const_fst
            (UL.deleteRCopies bundle.inst cur.history bundle.survivingSet i bundle.copies)]
          refine expWithBits_mono (fun _ pdw hwc => ?_)
          obtain ⟨rfl, hdw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
          obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pdw.1 pdw.2 hdw
          have hih_le := (ih (mkNext pdw.2) (accBits ++ pdw.1) hh' hv' hi' hf').2.2.2 t hu₀_lt
          refine hih_le.trans ?_
          obtain ⟨hfst_dw, _⟩ := hinv_d pdw.1 pdw.2 hdw
          have hg_iff := isGoodCopies_of_map_fst_eq (inst := bundle.inst) (N := N_gid) (cap := cap) hfst_dw
          have hsplit_set := allGensCredit_set_split R cap A_n (P_fac d_param B n) netOfBirth
            cur (mkNext pdw.2) gid _ hgid_lt rfl rfl
          have hslot_nxt : genSlotCredit R cap A_n (P_fac d_param B n) netOfBirth (mkNext pdw.2) gid =
              copiesRemWork bundle.inst (bundle.survivingSet.erase i) pdw.2.1 + badCred := by
            unfold genSlotCredit bundleCredit
            have hget_nxt : (mkNext pdw.2).generations[gid]? =
                some (some { bundle with
                  survivingSet := bundle.survivingSet.erase i
                  deletedIds := bundle.deletedIds ++ [i]
                  copies := pdw.2.1 }) := by
              simp [mkNext, List.getElem?_set_self hgid_lt]
            have hsnap_nxt : (mkNext pdw.2).birthSnapshots[gid]? = some (birthHist, birthBits) := hsnap_b
            rw [hget_nxt, hsnap_nxt]
            dsimp only [badCred, N_gid] at hg_iff ⊢
            simp only [hg_iff]
          unfold sysPotential
          rw [hsplit_set.2, hslot_nxt]
          dsimp only [mkNext, remSum, restBudget, R, cap]
          simp only [Nat.cast_add]
          exact le_of_eq (by ring)
        have hcur_pot : sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth cur =
            ((cur.totalSearchWork : ENNReal) + remSum + badCred + restBudget) +
            copiesRemWork bundle.inst bundle.survivingSet bundle.copies := by
          unfold sysPotential
          have hsplit_cur : allGensCredit R cap A_n (P_fac d_param B n) netOfBirth cur =
              remSum + genSlotCredit R cap A_n (P_fac d_param B n) netOfBirth cur gid := by
            unfold allGensCredit
            rw [← Finset.add_sum_erase _ _ (Finset.mem_range.mpr hgid_lt), add_comm]
          rw [hsplit_cur]
          unfold genSlotCredit bundleCredit
          rw [hget_b, hsnap_b]
          dsimp only [remSum, restBudget, badCred, N_gid]
          ring
        calc
          _ ≤ _ := hmono_ih
          _ = ((cur.totalSearchWork : ENNReal) + remSum + badCred + restBudget) +
              expWithBits (UL.deleteRCopies bundle.inst cur.history bundle.survivingSet i bundle.copies)
                (fun dw => (dw.2 : ENNReal) +
                  copiesRemWork bundle.inst (bundle.survivingSet.erase i) dw.1) :=
                expWithBits_const_add_of_haltProb_one hhp_d _ _
          _ ≤ ((cur.totalSearchWork : ENNReal) + remSum + badCred + restBudget) +
              copiesRemWork bundle.inst bundle.survivingSet bundle.copies :=
                by gcongr
          _ = sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth cur :=
                hcur_pot.symm

    | cancelGen gid =>
      rw [hnext] at hact_valid
      rcases hact_valid with ⟨bundle, hget_b⟩
      have hgid_lt : gid < cur.generations.length := by
        rcases List.getElem?_eq_some_iff.mp hget_b with ⟨hlt, _⟩
        exact hlt
      let nxt : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState :=
        { cur with
          generations := cur.generations.set gid none
          totalCancels := cur.totalCancels + 1 }
      have hfn_eq : UL.runCompiledStepActionsFuel R cap ctrl (fuel + 1) cur accBits =
          UL.runCompiledStepActionsFuel R cap ctrl fuel nxt accBits := by
        funext bs
        conv_lhs => unfold UL.runCompiledStepActionsFuel
        dsimp only
        rw [hnext]
        dsimp only
        rw [hget_b]
      rw [hfn_eq]
      have hstep_once : c3StepOnce R cap ctrl (cur, accBits) [] = some (nxt, accBits) := by
        unfold c3StepOnce
        simp [hnext, hget_b, nxt]
      have hfuel' : maxActionPhi B_birth Q_poly d_param B n u₀ + 1 ≤ fuel + actionPhi nxt := by
        have hphi_eq : actionPhi nxt = actionPhi cur + 1 := by
          unfold actionPhi
          simp [nxt]
          omega
        omega
      have hv_nxt : IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth nxt := by
        rcases hcur with ⟨hlen_gs, hlive, hqrec, hgen_le, hdel_le, hcan_le, hbirth_r, hq_r⟩
        refine ⟨by simp [nxt, hlen_gs], ?_, hqrec, by simp [nxt, hgen_le], ?_, ?_, hbirth_r, hq_r⟩
        · intro gid' b' hget'
          simp only [nxt] at hget' ⊢
          by_cases heq : gid' = gid
          · subst heq
            rw [List.getElem?_set_self hgid_lt] at hget'
            simp at hget'
          · rw [List.getElem?_set_ne (Ne.symm heq)] at hget'
            exact hlive gid' b' hget'
        · simp only [nxt]
          have hsum_set := list_map_sum_set cur.generations
            (fun opt => match opt with | some b => b.survivingSet.card | none => 0)
            hget_b none
          dsimp only at hsum_set
          omega
        · simp only [nxt, List.length_set]
          have hflt := list_filter_isSome_set cur.generations hget_b none
          simp at hflt
          omega
      obtain ⟨hpf_n, hhp_n, hout_n, hexp_n⟩ :=
        ih nxt accBits hhist hv_nxt (hintra.step hstep_once) hfuel'
      refine ⟨hpf_n, hhp_n, hout_n, fun t hu₀_lt => (hexp_n t hu₀_lt).trans ?_⟩
      unfold sysPotential
      have hsplit_set := allGensCredit_set_split R cap A_n (P_fac d_param B n) netOfBirth
        cur nxt gid none hgid_lt rfl rfl
      rw [hsplit_set.1, hsplit_set.2]
      have hzero_nxt : genSlotCredit R cap A_n (P_fac d_param B n) netOfBirth nxt gid = 0 := by
        unfold genSlotCredit
        simp [nxt, List.getElem?_set_self hgid_lt]
      rw [hzero_nxt, add_zero]
      dsimp only [nxt]
      gcongr
      exact self_le_add_right _ _

    | queryGen gid q =>
      rw [hnext] at hact_valid
      rcases hact_valid with ⟨bundle, birthHist, birthBits, hget_b, hsnap_b, hcomp, hqz, hq_new⟩
      obtain ⟨birthHist', birthBits', hsnap_b', hvb'⟩ := hcur.2.1 gid bundle hget_b
      have hsnap_eq : birthHist' = birthHist := by
        have h1 := hsnap_b'.symm.trans hsnap_b
        exact (Option.some.inj h1 |> Prod.mk.inj).1
      subst hsnap_eq
      have hgid_lt : gid < cur.generations.length := by
        rcases List.getElem?_eq_some_iff.mp hget_b with ⟨hlt, _⟩
        exact hlt
      obtain ⟨hpf_q, hhp_q, hinv_q, hexp_q⟩ :=
        runCompiledQuery_props cur.history bundle q hvb' hcomp hqz
      let mkNext := fun qw : UL.CompiledCertifiedGenBundle ι d d_s BirthState PhaseState × Option ι × ℕ =>
        let qRec : UL.CompiledQueryRecord ι d_s :=
          { gid := gid
            gen := bundle.inst.gen
            survivingSet := bundle.survivingSet
            query := q
            answer := qw.2.1 }
        ({ cur with
            generations := cur.generations.set gid (some qw.1)
            queryRecords := cur.queryRecords ++ [qRec]
            totalQueries := cur.totalQueries + 1
            totalSearchWork := cur.totalSearchWork + qw.2.2 } :
          UL.CompiledSearchSystemState ι d d_s BirthState PhaseState)
      have hfn_eq : UL.runCompiledStepActionsFuel R cap ctrl (fuel + 1) cur accBits =
          UL.bindWithBits (withConsumedBits (UL.runCompiledQuery R cap cur.history bundle q))
            (fun pqw => UL.runCompiledStepActionsFuel R cap ctrl fuel
              (mkNext pqw.2) (accBits ++ pqw.1)) := by
        funext bs
        unfold UL.runCompiledStepActionsFuel
        dsimp only
        rw [hnext]
        dsimp only
        rw [hget_b]
        exact inlined_bind_eq_bindWithBits hpf_q
          (fun bs₁ qw bs₂ => UL.runCompiledStepActionsFuel R cap ctrl fuel
            (mkNext qw) (accBits ++ bs₁) bs₂) bs
      have hstep_inv : ∀ bs₁ qw,
          UL.runCompiledQuery R cap cur.history bundle q bs₁ = some qw →
          let nxt := mkNext qw
          nxt.history = prefSt.history ∧
          IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth nxt ∧
          IsIntraFromBoundary R cap B_birth Q_poly d_param B n ctrl prefSt nxt (accBits ++ bs₁) ∧
          maxActionPhi B_birth Q_poly d_param B n u₀ + 1 ≤ fuel + actionPhi nxt := by
        intro bs₁ qw hqw
        dsimp only
        obtain ⟨hi_q, hs_q, _, hvb_q, hcorr_q⟩ := hinv_q bs₁ qw hqw
        have hstep_once : c3StepOnce R cap ctrl (cur, accBits) bs₁ =
            some (mkNext qw, accBits ++ bs₁) := by
          unfold c3StepOnce
          simp [hnext, hget_b, hqw, mkNext]
        have hfuel' : maxActionPhi B_birth Q_poly d_param B n u₀ + 1 ≤
            fuel + actionPhi (mkNext qw) := by
          have hphi_eq : actionPhi (mkNext qw) = actionPhi cur + 1 := by
            unfold actionPhi
            simp [mkNext]
            omega
          omega
        rcases hcur with ⟨hlen_gs, hlive, hqrec, hgen_le, hdel_le, hcan_le, hbirth_r, _⟩
        refine ⟨hhist, ?_, hintra.step hstep_once, hfuel'⟩
        refine ⟨by simp [mkNext, hlen_gs], ?_, ?_, by simp [mkNext, hgen_le], ?_, ?_, hbirth_r, hq_new⟩
        · intro gid' b' hget'
          simp only [mkNext] at hget' ⊢
          by_cases heq : gid' = gid
          · subst heq
            rw [List.getElem?_set_self hgid_lt] at hget'
            simp only [Option.some.injEq] at hget'
            subst hget'
            refine ⟨birthHist', birthBits, hsnap_b, ?_⟩
            simpa [hi_q] using hvb_q
          · rw [List.getElem?_set_ne (Ne.symm heq)] at hget'
            exact hlive gid' b' hget'
        · intro qr hqr
          simp only [mkNext, List.mem_append, List.mem_singleton] at hqr
          rcases hqr with hmem | rfl
          · exact hqrec qr hmem
          · exact hcorr_q
        · simp only [mkNext]
          have hsum_set := list_map_sum_set cur.generations
            (fun opt => match opt with | some b => b.survivingSet.card | none => 0)
            hget_b (some qw.1)
          dsimp only at hsum_set
          rw [hs_q] at hsum_set
          omega
        · simp only [mkNext, List.length_set]
          have hflt := list_filter_isSome_set cur.generations hget_b (some qw.1)
          simp at hflt
          omega
      rw [hfn_eq]
      have hpf_wc := hpf_q.withConsumedBits
      have hhp_wc : haltProb (withConsumedBits (UL.runCompiledQuery R cap cur.history bundle q)) = 1 := by
        rw [haltProb_withConsumedBits, hhp_q]
      refine ⟨hpf_wc.bindWithBits (fun _ pqw hwc => ?_),
        haltProb_bindWithBits hpf_wc hhp_wc (fun _ pqw hwc => ?_), ?_, ?_⟩
      · obtain ⟨rfl, hqw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
        obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pqw.1 pqw.2 hqw
        exact (ih (mkNext pqw.2) (accBits ++ pqw.1) hh' hv' hi' hf').1
      · obtain ⟨rfl, hqw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
        obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pqw.1 pqw.2 hqw
        exact (ih (mkNext pqw.2) (accBits ++ pqw.1) hh' hv' hi' hf').2.1
      · intro bs out hrun
        rw [bindWithBits_eq_some_iff hpf_wc] at hrun
        rcases hrun with ⟨bs₁, bs₂, pqw, _, hwc, h2⟩
        obtain ⟨rfl, hqw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
        obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pqw.1 pqw.2 hqw
        exact (ih (mkNext pqw.2) (accBits ++ pqw.1) hh' hv' hi' hf').2.2.1 bs₂ out h2
      · intro t hu₀_lt
        rw [expWithBits_bind hpf_wc]
        let N_gid := netOfBirth gid birthHist' bundle.inst
        let remSum := ∑ j ∈ (Finset.range cur.generations.length).erase gid,
          genSlotCredit R cap A_n (P_fac d_param B n) netOfBirth cur j
        let B_cap := Nat.floor ((t : ℝ) * B_birth d_param n)
        let Q_cap := Nat.floor ((t : ℝ) * Q_poly d_param B n)
        let unitBirthCost : ENNReal := 6 * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)
        let unitQueryCost : ENNReal := ((R * cap : ℕ) : ENNReal)
        let basePot :=
          (cur.totalSearchWork : ENNReal) + remSum +
          ((B_cap - cur.totalBirthCard : ℕ) : ENNReal) * unitBirthCost +
          ((Q_cap - (cur.totalQueries + 1) : ℕ) : ENNReal) * unitQueryCost
        have hmono_ih : expWithBits
            (withConsumedBits (UL.runCompiledQuery R cap cur.history bundle q))
            (fun pqw => expWithBits (UL.runCompiledStepActionsFuel R cap ctrl fuel
                (mkNext pqw.2) (accBits ++ pqw.1))
              (sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth)) ≤
            expWithBits (UL.runCompiledQuery R cap cur.history bundle q)
              (fun qw => basePot +
                ((qw.2.2 : ENNReal) + bundleCredit R cap A_n (P_fac d_param B n) N_gid qw.1)) := by
          rw [← expWithBits_withConsumedBits_const_fst (UL.runCompiledQuery R cap cur.history bundle q)]
          refine expWithBits_mono (fun _ pqw hwc => ?_)
          obtain ⟨rfl, hqw⟩ := (withConsumedBits_eq_some_iff _ _ _).mp hwc
          obtain ⟨hh', hv', hi', hf'⟩ := hstep_inv pqw.1 pqw.2 hqw
          have hih_le := (ih (mkNext pqw.2) (accBits ++ pqw.1) hh' hv' hi' hf').2.2.2 t hu₀_lt
          refine hih_le.trans ?_
          obtain ⟨hi_q, _, _, _, _⟩ := hinv_q pqw.1 pqw.2 hqw
          have hsplit_set := allGensCredit_set_split R cap A_n (P_fac d_param B n) netOfBirth
            cur (mkNext pqw.2) gid (some pqw.2.1) hgid_lt rfl rfl
          have hslot_nxt : genSlotCredit R cap A_n (P_fac d_param B n) netOfBirth (mkNext pqw.2) gid =
              bundleCredit R cap A_n (P_fac d_param B n) N_gid pqw.2.1 := by
            unfold genSlotCredit
            have hget_nxt : (mkNext pqw.2).generations[gid]? = some (some pqw.2.1) := by
              simp [mkNext, List.getElem?_set_self hgid_lt]
            have hsnap_nxt : (mkNext pqw.2).birthSnapshots[gid]? = some (birthHist', birthBits) := hsnap_b
            rw [hget_nxt, hsnap_nxt]
            dsimp only [N_gid]
            rw [hi_q]
          unfold sysPotential
          rw [hsplit_set.2, hslot_nxt]
          dsimp only [mkNext, basePot, remSum, B_cap, Q_cap, unitBirthCost, unitQueryCost, R, cap]
          simp only [Nat.cast_add]
          exact le_of_eq (by ring)
        have hQ_le : cur.totalQueries + 1 ≤ Q_cap := by
          apply Nat.le_floor
          have hu_le_t : ((cur.history.length + 1 : ℕ) : ℝ) ≤ (t : ℝ) := by
            rw [hhist]
            exact_mod_cast (show u₀ + 1 ≤ t by omega)
          exact hq_new.trans (mul_le_mul_of_nonneg_right hu_le_t hQ_nn)
        have hQ_sub : ((Q_cap - (cur.totalQueries + 1) : ℕ) : ENNReal) + 1 =
            ((Q_cap - cur.totalQueries : ℕ) : ENNReal) := by
          exact_mod_cast (show Q_cap - (cur.totalQueries + 1) + 1 = Q_cap - cur.totalQueries by omega)
        have hcur_pot : sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth cur =
            basePot + (unitQueryCost + bundleCredit R cap A_n (P_fac d_param B n) N_gid bundle) := by
          unfold sysPotential
          have hsplit_cur : allGensCredit R cap A_n (P_fac d_param B n) netOfBirth cur =
              remSum + genSlotCredit R cap A_n (P_fac d_param B n) netOfBirth cur gid := by
            unfold allGensCredit
            rw [← Finset.add_sum_erase _ _ (Finset.mem_range.mpr hgid_lt), add_comm]
          rw [hsplit_cur]
          unfold genSlotCredit
          rw [hget_b, hsnap_b]
          dsimp only [basePot, remSum, B_cap, Q_cap, unitBirthCost, unitQueryCost, N_gid]
          calc
            _ = (cur.totalSearchWork : ENNReal) +
                  (remSum + bundleCredit R cap A_n (P_fac d_param B n) N_gid bundle) +
                  ((B_cap - cur.totalBirthCard : ℕ) : ENNReal) * unitBirthCost +
                  (((Q_cap - (cur.totalQueries + 1) : ℕ) : ENNReal) + 1) * unitQueryCost := by
                    rw [hQ_sub]
            _ = _ := by ring
        calc
          _ ≤ _ := hmono_ih
          _ = basePot + expWithBits (UL.runCompiledQuery R cap cur.history bundle q)
                (fun qw => (qw.2.2 : ENNReal) +
                  bundleCredit R cap A_n (P_fac d_param B n) N_gid qw.1) :=
                expWithBits_const_add_of_haltProb_one hhp_q _ _
          _ ≤ basePot + (unitQueryCost + bundleCredit R cap A_n (P_fac d_param B n) N_gid bundle) :=
                by gcongr
          _ = sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth cur :=
                hcur_pot.symm

/-! ### 5. Single-step and multi-step prefix theorems -/

theorem runSingleCompiledSearchStep_props
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    {d_param B n : ℕ} {σ A_n : ℝ}
    {P_fac netLogBound : ℕ → ℕ → ℕ → ℝ}
    {B_birth : ℕ → ℕ → ℝ} {Q_poly : ℕ → ℕ → ℕ → ℝ}
    {ctrl : UL.AdaptiveSearchController ι d d_s BirthState PhaseState}
    {netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s))}
    (hA : 0 ≤ A_n)
    (hP_nn : 0 ≤ P_fac d_param B n)
    (hB_nn : 0 ≤ B_birth d_param n)
    (hQ_nn : 0 ≤ Q_poly d_param B n)
    (hCtrl : ∀ st : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState,
      UL.IsReachableIntraStepState (c3_R_of (netLogBound d_param B n))
        (c3_cap_of A_n (P_fac d_param B n)) B_birth Q_poly d_param B n ctrl st →
        let u : ℕ := st.history.length
        match ctrl.nextAction st with
        | .finishExternalStep _ => True
        | .openGen inst =>
            let gid := st.generations.length
            UL.SatisfiesCertifiedBirthVarOnNet n σ A_n (P_fac d_param B n)
              (netLogBound d_param B n) (netOfBirth gid st.history inst) inst ∧
            ((st.totalBirthCard + inst.gen.m : ℕ) : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * B_birth d_param n
        | .deleteFromGen gid i =>
            ∃ bundle, st.generations[gid]? = some (some bundle) ∧ i ∈ bundle.survivingSet
        | .cancelGen gid =>
            ∃ bundle, st.generations[gid]? = some (some bundle)
        | .queryGen gid q =>
            ∃ bundle birthHist birthBits,
              st.generations[gid]? = some (some bundle) ∧
              st.birthSnapshots[gid]? = some (birthHist, birthBits) ∧
              UL.IsCertifiedCompatible bundle.inst.gen bundle.inst.δ bundle.survivingSet q ∧
              q.z ∈ netOfBirth gid birthHist bundle.inst ∧
              ((st.totalQueries + 1 : ℕ) : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * Q_poly d_param B n)
    {prefSt : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState}
    (hreach_pref : ∃ bitTrace : List (List Bool),
      UL.runCompiledSearchSteps (c3_R_of (netLogBound d_param B n))
        (c3_cap_of A_n (P_fac d_param B n)) B_birth Q_poly d_param B n ctrl bitTrace = some prefSt)
    (hval_pref : IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth prefSt) :
    let R := c3_R_of (netLogBound d_param B n)
    let cap := c3_cap_of A_n (P_fac d_param B n)
    IsPrefixFree (UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl prefSt) ∧
    UL.compiledSingleStepHaltProb R cap B_birth Q_poly d_param B n ctrl prefSt = 1 ∧
    (∀ bs out,
      UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl prefSt bs = some out →
        out.history.length = prefSt.history.length + 1 ∧
        IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth out) ∧
    (∀ t : ℕ, prefSt.history.length < t →
      expWithBits (UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl prefSt)
        (sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth) ≤
        sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth prefSt) := by
  intro R cap
  have hintra0 : IsIntraFromBoundary R cap B_birth Q_poly d_param B n ctrl prefSt prefSt [] :=
    ⟨hreach_pref, 0, Fin.elim0, by simp⟩
  let budget := UL.compiledStepActionBudget B_birth Q_poly d_param B n prefSt.history.length
  have hfuel0 : maxActionPhi B_birth Q_poly d_param B n prefSt.history.length + 1 ≤
      budget + actionPhi prefSt := by
    unfold budget UL.compiledStepActionBudget maxActionPhi
    omega
  obtain ⟨hpf, hhp, hout, hexp⟩ :=
    runCompiledStepActionsFuel_props hA hP_nn hB_nn hQ_nn hCtrl prefSt
      budget prefSt [] rfl hval_pref hintra0 hfuel0
  exact ⟨hpf, hhp, hout, hexp⟩

theorem initCompiledSearchSystemState_valid
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (d_param B n : ℕ) (σ A_n : ℝ)
    (P_fac netLogBound : ℕ → ℕ → ℕ → ℝ)
    (B_birth : ℕ → ℕ → ℝ)
    (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s)))
    (hB_nn : 0 ≤ B_birth d_param n)
    (hQ_nn : 0 ≤ Q_poly d_param B n) :
    IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth
      (UL.initCompiledSearchSystemState ι d d_s BirthState PhaseState) := by
  refine ⟨rfl, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro _ _ h
    simp [UL.initCompiledSearchSystemState] at h
  · intro _ h
    simp [UL.initCompiledSearchSystemState] at h
  · simp [UL.initCompiledSearchSystemState]
  · simp [UL.initCompiledSearchSystemState]
  · simp [UL.initCompiledSearchSystemState]
  · simpa [UL.initCompiledSearchSystemState] using hB_nn
  · simpa [UL.initCompiledSearchSystemState] using hQ_nn

theorem runCompiledSearchSteps_valid
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    {d_param B n : ℕ} {σ A_n : ℝ}
    {P_fac netLogBound : ℕ → ℕ → ℕ → ℝ}
    {B_birth : ℕ → ℕ → ℝ} {Q_poly : ℕ → ℕ → ℕ → ℝ}
    {ctrl : UL.AdaptiveSearchController ι d d_s BirthState PhaseState}
    {netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s))}
    (hA : 0 ≤ A_n)
    (hP_nn : 0 ≤ P_fac d_param B n)
    (hB_nn : 0 ≤ B_birth d_param n)
    (hQ_nn : 0 ≤ Q_poly d_param B n)
    (hCtrl : ∀ st : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState,
      UL.IsReachableIntraStepState (c3_R_of (netLogBound d_param B n))
        (c3_cap_of A_n (P_fac d_param B n)) B_birth Q_poly d_param B n ctrl st →
        let u : ℕ := st.history.length
        match ctrl.nextAction st with
        | .finishExternalStep _ => True
        | .openGen inst =>
            let gid := st.generations.length
            UL.SatisfiesCertifiedBirthVarOnNet n σ A_n (P_fac d_param B n)
              (netLogBound d_param B n) (netOfBirth gid st.history inst) inst ∧
            ((st.totalBirthCard + inst.gen.m : ℕ) : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * B_birth d_param n
        | .deleteFromGen gid i =>
            ∃ bundle, st.generations[gid]? = some (some bundle) ∧ i ∈ bundle.survivingSet
        | .cancelGen gid =>
            ∃ bundle, st.generations[gid]? = some (some bundle)
        | .queryGen gid q =>
            ∃ bundle birthHist birthBits,
              st.generations[gid]? = some (some bundle) ∧
              st.birthSnapshots[gid]? = some (birthHist, birthBits) ∧
              UL.IsCertifiedCompatible bundle.inst.gen bundle.inst.δ bundle.survivingSet q ∧
              q.z ∈ netOfBirth gid birthHist bundle.inst ∧
              ((st.totalQueries + 1 : ℕ) : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * Q_poly d_param B n) :
    let R := c3_R_of (netLogBound d_param B n)
    let cap := c3_cap_of A_n (P_fac d_param B n)
    ∀ (bitTrace : List (List Bool))
      (prefSt : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState),
      UL.runCompiledSearchSteps R cap B_birth Q_poly d_param B n ctrl bitTrace = some prefSt →
        prefSt.history.length = bitTrace.length ∧
        IsValidSystemState d_param B n σ A_n P_fac netLogBound B_birth Q_poly netOfBirth prefSt := by
  intro R cap bitTrace
  induction bitTrace using List.reverseRecOn with
  | nil =>
    intro prefSt h
    simp only [UL.runCompiledSearchSteps, UL.runCompiledSearchStepsFrom, Option.some.injEq] at h
    subst h
    exact ⟨rfl, initCompiledSearchSystemState_valid d_param B n σ A_n P_fac netLogBound
      B_birth Q_poly netOfBirth hB_nn hQ_nn⟩
  | append_singleton prev bs ih =>
    intro prefSt h
    unfold UL.runCompiledSearchSteps at h
    cases hmid : UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl
        (UL.initCompiledSearchSystemState ι d d_s BirthState PhaseState) prev with
    | none =>
      have hnone : ∀ l₁ l₂ cur,
          UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl cur l₁ = none →
          UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl cur (l₁ ++ l₂) = none := by
        intro l₁
        induction l₁ with
        | nil => intros _ _ hn; simp [UL.runCompiledSearchStepsFrom] at hn
        | cons b tl ihl =>
          intro l₂ cur hn
          simp only [UL.runCompiledSearchStepsFrom, List.cons_append] at hn ⊢
          cases hst : UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl cur b with
          | none => rfl
          | some nxt =>
            dsimp only
            exact ihl l₂ nxt (by simpa [hst] using hn)
      rw [hnone prev [bs] _ hmid] at h
      simp at h
    | some mid =>
      rw [runCompiledSearchStepsFrom_append R cap B_birth Q_poly d_param B n ctrl prev [bs] _ mid hmid] at h
      simp only [UL.runCompiledSearchStepsFrom] at h
      cases hstep : UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl mid bs with
      | none => simp [hstep] at h
      | some nxt =>
        simp only [hstep, Option.some.injEq] at h
        subst h
        obtain ⟨hlen_mid, hv_mid⟩ := ih mid hmid
        have hstep_props := runSingleCompiledSearchStep_props hA hP_nn hB_nn hQ_nn hCtrl
          ⟨prev, hmid⟩ hv_mid
        obtain ⟨hlen_nxt, hv_nxt⟩ := hstep_props.2.2.1 bs nxt hstep
        refine ⟨?_, hv_nxt⟩
        simp [hlen_nxt, hlen_mid]

theorem compiledPrefix_props
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    {d_param B n : ℕ} {σ A_n : ℝ}
    {P_fac netLogBound : ℕ → ℕ → ℕ → ℝ}
    {B_birth : ℕ → ℕ → ℝ} {Q_poly : ℕ → ℕ → ℕ → ℝ}
    {ctrl : UL.AdaptiveSearchController ι d d_s BirthState PhaseState}
    {netOfBirth :
      ℕ → UL.ExecutionHistory d → UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s))}
    (hA : 0 ≤ A_n)
    (hP_nn : 0 ≤ P_fac d_param B n)
    (hB_nn : 0 ≤ B_birth d_param n)
    (hQ_nn : 0 ≤ Q_poly d_param B n)
    (hCtrl : ∀ st : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState,
      UL.IsReachableIntraStepState (c3_R_of (netLogBound d_param B n))
        (c3_cap_of A_n (P_fac d_param B n)) B_birth Q_poly d_param B n ctrl st →
        let u : ℕ := st.history.length
        match ctrl.nextAction st with
        | .finishExternalStep _ => True
        | .openGen inst =>
            let gid := st.generations.length
            UL.SatisfiesCertifiedBirthVarOnNet n σ A_n (P_fac d_param B n)
              (netLogBound d_param B n) (netOfBirth gid st.history inst) inst ∧
            ((st.totalBirthCard + inst.gen.m : ℕ) : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * B_birth d_param n
        | .deleteFromGen gid i =>
            ∃ bundle, st.generations[gid]? = some (some bundle) ∧ i ∈ bundle.survivingSet
        | .cancelGen gid =>
            ∃ bundle, st.generations[gid]? = some (some bundle)
        | .queryGen gid q =>
            ∃ bundle birthHist birthBits,
              st.generations[gid]? = some (some bundle) ∧
              st.birthSnapshots[gid]? = some (birthHist, birthBits) ∧
              UL.IsCertifiedCompatible bundle.inst.gen bundle.inst.δ bundle.survivingSet q ∧
              q.z ∈ netOfBirth gid birthHist bundle.inst ∧
              ((st.totalQueries + 1 : ℕ) : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * Q_poly d_param B n)
    (t : ℕ) :
    let R := c3_R_of (netLogBound d_param B n)
    let cap := c3_cap_of A_n (P_fac d_param B n)
    (∀ (trace : Fin t → List Bool)
       (out : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState),
      UL.runCompiledSearchPrefix R cap B_birth Q_poly d_param B n ctrl t trace = some out →
        out.history.length = t ∧
        ∀ qRec ∈ out.queryRecords,
          qRec.gen.IsCorrectAnswer qRec.survivingSet qRec.query qRec.answer) ∧
    UL.compiledPrefixExpectedWork R cap B_birth Q_poly d_param B n ctrl t ≠ ⊤ ∧
    (UL.compiledPrefixExpectedWork R cap B_birth Q_poly d_param B n ctrl t).toReal ≤
      (t : ℝ) * A_n * c3_P_out P_fac netLogBound B_birth Q_poly d_param B n := by
  intro R cap
  refine ⟨?_, ?_⟩
  · intro trace out hout
    obtain ⟨hlen, hval⟩ := runCompiledSearchSteps_valid hA hP_nn hB_nn hQ_nn hCtrl
      (List.ofFn trace) out hout
    exact ⟨by simpa using hlen, hval.2.2.1⟩
  · -- Supermartingale induction over remaining steps `s` (`cur.history.length + s = t`)
    have hsteps_pot : ∀ (s : ℕ) (bitTrace : List (List Bool))
        (cur : UL.CompiledSearchSystemState ι d d_s BirthState PhaseState),
        UL.runCompiledSearchSteps R cap B_birth Q_poly d_param B n ctrl bitTrace = some cur →
        cur.history.length + s = t →
        (∑' tr : Fin s → List Bool,
          match UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl cur
              (List.ofFn tr) with
          | some out => UL.prefixTraceProb tr *
              sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth out
          | none => 0) ≤
        sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth cur := by
      intro s
      induction s with
      | zero =>
        intro bitTrace cur _ _
        rw [tsum_fin_zero]
        simp [UL.runCompiledSearchStepsFrom, prefixTraceProb_zero]
      | succ s ih =>
        intro bitTrace cur hreach hsum_t
        obtain ⟨_, hval_cur⟩ := runCompiledSearchSteps_valid hA hP_nn hB_nn hQ_nn hCtrl
          bitTrace cur hreach
        have hu_lt_t : cur.history.length < t := by omega
        have hstep_props := runSingleCompiledSearchStep_props hA hP_nn hB_nn hQ_nn hCtrl
          ⟨bitTrace, hreach⟩ hval_cur
        rw [tsum_fin_succ]
        have hinner_le : ∀ bs : List Bool,
            (∑' rest : Fin s → List Bool,
              match UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl cur
                  (List.ofFn (Fin.cons bs rest)) with
              | some out => UL.prefixTraceProb (Fin.cons bs rest) *
                  sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth out
              | none => 0) ≤
            (match UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl cur bs with
             | some nxt => UL.bitListProb bs *
                 sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth nxt
             | none => 0) := by
          intro bs
          have hof : ∀ rest : Fin s → List Bool,
              List.ofFn (Fin.cons bs rest) = bs :: List.ofFn rest := fun rest => by
            simp [List.ofFn_succ]
          cases hstep : UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl cur bs with
          | none =>
            dsimp only
            refine le_of_eq (ENNReal.tsum_eq_zero.mpr (fun rest => ?_))
            rw [hof rest]
            simp [UL.runCompiledSearchStepsFrom, hstep]
          | some nxt =>
            dsimp only
            have hreach_nxt : UL.runCompiledSearchSteps R cap B_birth Q_poly d_param B n ctrl
                (bitTrace ++ [bs]) = some nxt := by
              unfold UL.runCompiledSearchSteps at hreach ⊢
              rw [runCompiledSearchStepsFrom_append R cap B_birth Q_poly d_param B n ctrl
                bitTrace [bs] _ cur hreach]
              simp [UL.runCompiledSearchStepsFrom, hstep]
            have hlen_nxt := (hstep_props.2.2.1 bs nxt hstep).1
            have hsum_nxt : nxt.history.length + s = t := by omega
            have hpull : ∀ rest : Fin s → List Bool,
                (match UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl cur
                    (List.ofFn (Fin.cons bs rest)) with
                | some out => UL.prefixTraceProb (Fin.cons bs rest) *
                    sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth out
                | none => 0) =
                UL.bitListProb bs *
                  (match UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl nxt
                      (List.ofFn rest) with
                   | some out => UL.prefixTraceProb rest *
                       sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth out
                   | none => 0) := by
              intro rest
              rw [hof rest, prefixTraceProb_cons]
              simp only [UL.runCompiledSearchStepsFrom, hstep]
              cases UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl nxt (List.ofFn rest) <;>
                simp [mul_assoc]
            simp_rw [hpull]
            rw [ENNReal.tsum_mul_left]
            exact mul_le_mul_right (ih (bitTrace ++ [bs]) nxt hreach_nxt hsum_nxt) _
        have hrhs_eq :
            (∑' bs : List Bool,
              match UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl cur bs with
              | some nxt => UL.bitListProb bs *
                  sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth nxt
              | none => 0) =
            expWithBits (UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl cur)
              (sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth) := by
          unfold expWithBits
          refine tsum_congr (fun bs => ?_)
          cases UL.runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl cur bs <;> rfl
        exact (ENNReal.tsum_le_tsum hinner_le).trans ((le_of_eq hrhs_eq).trans (hstep_props.2.2.2 t hu_lt_t))

    let initSt := UL.initCompiledSearchSystemState ι d d_s BirthState PhaseState
    have hexp_le_init :
        UL.compiledPrefixExpectedWork R cap B_birth Q_poly d_param B n ctrl t ≤
          sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth initSt := by
      have h1 : UL.compiledPrefixExpectedWork R cap B_birth Q_poly d_param B n ctrl t ≤
          ∑' tr : Fin t → List Bool,
            match UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl initSt
                (List.ofFn tr) with
            | some out => UL.prefixTraceProb tr *
                sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth out
            | none => 0 := by
        unfold UL.compiledPrefixExpectedWork UL.runCompiledSearchPrefix UL.runCompiledSearchSteps
        refine ENNReal.tsum_le_tsum (fun tr => ?_)
        cases UL.runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl initSt (List.ofFn tr) with
        | none => exact le_rfl
        | some out =>
          dsimp only
          refine mul_le_mul_right ?_ _
          unfold sysPotential
          exact le_add_of_le_of_nonneg
            (le_add_of_le_of_nonneg (le_add_of_le_of_nonneg le_rfl (zero_le _)) (zero_le _))
            (zero_le _)
      exact h1.trans (hsteps_pot t [] initSt rfl (by simp [initSt, UL.initCompiledSearchSystemState]))

    have hinit_le_bound :
        sysPotential d_param B n t A_n P_fac netLogBound B_birth Q_poly netOfBirth initSt ≤
          ENNReal.ofReal ((t : ℝ) * A_n * c3_P_out P_fac netLogBound B_birth Q_poly d_param B n) := by
      unfold sysPotential
      have hzero_gens : allGensCredit R cap A_n (P_fac d_param B n) netOfBirth initSt = 0 := by
        unfold allGensCredit initSt UL.initCompiledSearchSystemState
        simp
      rw [hzero_gens]
      dsimp only [initSt, UL.initCompiledSearchSystemState]
      simp only [Nat.cast_zero, zero_add, Nat.sub_zero]
      have hB_fl : ((Nat.floor ((t : ℝ) * B_birth d_param n) : ℕ) : ENNReal) ≤
          ENNReal.ofReal ((t : ℝ) * B_birth d_param n) := by
        rw [← ENNReal.ofReal_natCast]
        exact ENNReal.ofReal_le_ofReal (Nat.floor_le (by positivity))
      have hQ_fl : ((Nat.floor ((t : ℝ) * Q_poly d_param B n) : ℕ) : ENNReal) ≤
          ENNReal.ofReal ((t : ℝ) * Q_poly d_param B n) := by
        rw [← ENNReal.ofReal_natCast]
        exact ENNReal.ofReal_le_ofReal (Nat.floor_le (by positivity))
      have hcap_le : ((R * cap : ℕ) : ENNReal) ≤
          4 * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n) := by
        have hc_real : (cap : ℝ) ≤ 4 * (A_n * P_fac d_param B n) := by
          simpa [cap, mul_assoc] using c3_cap_of_le hA hP_nn
        have hc_enn : (cap : ENNReal) ≤ 4 * ENNReal.ofReal (A_n * P_fac d_param B n) := by
          have h1 := ENNReal.ofReal_le_ofReal hc_real
          rw [ENNReal.ofReal_natCast, ENNReal.ofReal_mul (by norm_num),
              show ENNReal.ofReal 4 = (4 : ENNReal) by norm_num] at h1
          exact h1
        calc
          ((R * cap : ℕ) : ENNReal) = (R : ENNReal) * (cap : ENNReal) := by push_cast; rfl
          _ ≤ (R : ENNReal) * (4 * ENNReal.ofReal (A_n * P_fac d_param B n)) :=
                mul_le_mul_right hc_enn _
          _ = 4 * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n) := by ring
      calc
        _ ≤ ENNReal.ofReal ((t : ℝ) * B_birth d_param n) *
              (6 * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)) +
            ENNReal.ofReal ((t : ℝ) * Q_poly d_param B n) *
              (4 * (R : ENNReal) * ENNReal.ofReal (A_n * P_fac d_param B n)) := by
              gcongr
        _ = ENNReal.ofReal ((t : ℝ) * A_n * c3_P_out P_fac netLogBound B_birth Q_poly d_param B n) := by
              unfold c3_P_out
              have h6 : (6 : ENNReal) = ENNReal.ofReal 6 := by norm_num
              have h4 : (4 : ENNReal) = ENNReal.ofReal 4 := by norm_num
              have hR_of : (R : ENNReal) = ENNReal.ofReal (R : ℝ) := (ENNReal.ofReal_natCast R).symm
              rw [h6, h4, hR_of]
              repeat rw [← ENNReal.ofReal_mul (by positivity)]
              rw [← ENNReal.ofReal_add (by positivity) (by positivity)]
              congr 1
              ring

    have htot := hexp_le_init.trans hinit_le_bound
    have hne_top : UL.compiledPrefixExpectedWork R cap B_birth Q_poly d_param B n ctrl t ≠ ⊤ :=
      ne_top_of_le_ne_top ENNReal.ofReal_ne_top htot
    refine ⟨hne_top, ?_⟩
    have hreal := ENNReal.toReal_mono ENNReal.ofReal_ne_top htot
    have hbound_nn : 0 ≤ (t : ℝ) * A_n * c3_P_out P_fac netLogBound B_birth Q_poly d_param B n := by
      unfold c3_P_out
      positivity
    rwa [ENNReal.toReal_ofReal hbound_nn] at hreal

end UL.Proof.lem_C_3.RacerCG
