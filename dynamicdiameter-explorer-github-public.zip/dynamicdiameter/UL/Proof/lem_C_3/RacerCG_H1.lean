import Mathlib
import UL.Stmt.lem_C_3
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof.lem_C_3.RacerCG

/-! ### 1. Basic `bitListProb` and `prefixTraceProb` properties -/

theorem bitListProb_nil : UL.bitListProb [] = 1 := by
  simp [UL.bitListProb]

theorem bitListProb_cons (b : Bool) (bs : List Bool) :
    UL.bitListProb (b :: bs) = (2 : ENNReal)⁻¹ * UL.bitListProb bs := by
  simp [UL.bitListProb, pow_succ, mul_comm]

theorem bitListProb_append (bs₁ bs₂ : List Bool) :
    UL.bitListProb (bs₁ ++ bs₂) = UL.bitListProb bs₁ * UL.bitListProb bs₂ := by
  simp [UL.bitListProb, pow_add]

theorem bitListProb_ne_zero (bs : List Bool) : UL.bitListProb bs ≠ 0 := by
  unfold UL.bitListProb
  refine pow_ne_zero _ ?_
  simp

theorem bitListProb_pos (bs : List Bool) : 0 < UL.bitListProb bs :=
  pos_iff_ne_zero.mpr (bitListProb_ne_zero bs)

theorem bitListProb_ne_top (bs : List Bool) : UL.bitListProb bs ≠ ⊤ := by
  unfold UL.bitListProb
  refine ENNReal.pow_ne_top ?_
  simp

theorem prefixTraceProb_zero (tr : Fin 0 → List Bool) : UL.prefixTraceProb tr = 1 := by
  simp [UL.prefixTraceProb]

theorem prefixTraceProb_cons {k : ℕ} (bs : List Bool) (tr : Fin k → List Bool) :
    UL.prefixTraceProb (Fin.cons bs tr) = UL.bitListProb bs * UL.prefixTraceProb tr := by
  unfold UL.prefixTraceProb
  rw [Fin.prod_univ_succ]
  simp

def finConsEquiv (k : ℕ) (α : Type*) : (α × (Fin k → α)) ≃ (Fin (k + 1) → α) where
  toFun p := Fin.cons p.1 p.2
  invFun f := (f 0, Fin.tail f)
  left_inv p := by
    ext <;> simp
  right_inv f := by
    simp

theorem tsum_fin_zero {α : Type*} (F : (Fin 0 → α) → ENNReal) :
    (∑' tr : Fin 0 → α, F tr) = F Fin.elim0 := by
  refine tsum_eq_single Fin.elim0 (fun f hf => ?_)
  exfalso
  apply hf
  funext i
  exact Fin.elim0 i

theorem tsum_fin_succ {k : ℕ} {α : Type*} (F : (Fin (k + 1) → α) → ENNReal) :
    (∑' tr : Fin (k + 1) → α, F tr) =
      ∑' x : α, ∑' rest : Fin k → α, F (Fin.cons x rest) := by
  rw [← (finConsEquiv k α).tsum_eq, ENNReal.tsum_prod']
  rfl

theorem tsum_fin_snoc {k : ℕ} {α : Type*} (F : (Fin (k + 1) → α) → ENNReal) :
    (∑' tr : Fin (k + 1) → α, F tr) =
      ∑' init : Fin k → α, ∑' last : α, F (Fin.snoc init last) := by
  let e : ((Fin k → α) × α) ≃ (Fin (k + 1) → α) :=
    { toFun := fun p => Fin.snoc p.1 p.2
      invFun := fun f => (Fin.init f, f (Fin.last k))
      left_inv := fun p => by
        ext
        · simp [Fin.init]
        · simp
      right_inv := fun f => by
        simp }
  rw [← e.tsum_eq, ENNReal.tsum_prod']
  rfl

theorem prefixTraceProb_snoc {k : ℕ} (init : Fin k → List Bool) (last : List Bool) :
    UL.prefixTraceProb (Fin.snoc init last) =
      UL.prefixTraceProb init * UL.bitListProb last := by
  unfold UL.prefixTraceProb
  rw [Fin.prod_univ_castSucc]
  simp

/-! ### 2. Prefix-free randomized computations and `haltProb ≤ 1` -/

def IsPrefixFree {α : Type*} (f : List Bool → Option α) : Prop :=
  ∀ bs₁ bs₂ : List Bool, ∀ a₁ a₂ : α,
    f bs₁ = some a₁ → f bs₂ = some a₂ → bs₁ <+: bs₂ → bs₁ = bs₂

noncomputable def haltProb {α : Type*} (f : List Bool → Option α) : ENNReal :=
  ∑' bs : List Bool, if (f bs).isSome then UL.bitListProb bs else 0

theorem isPrefixFree_finset_sum_le_one :
    ∀ (N : ℕ) (s : Finset (List Bool)),
      (∀ bs ∈ s, bs.length ≤ N) →
      (∀ x ∈ s, ∀ y ∈ s, x <+: y → x = y) →
      ∑ bs ∈ s, UL.bitListProb bs ≤ 1 := by
  intro N
  induction N with
  | zero =>
    intro s hlen _hpf
    have hsub : s ⊆ {[]} := by
      intro bs hbs
      have h0 : bs.length = 0 := Nat.eq_zero_of_le_zero (hlen bs hbs)
      rw [List.length_eq_zero_iff] at h0
      simp [h0]
    calc
      ∑ bs ∈ s, UL.bitListProb bs ≤ ∑ bs ∈ ({[]} : Finset (List Bool)), UL.bitListProb bs :=
        Finset.sum_le_sum_of_subset hsub
      _ = 1 := by simp [bitListProb_nil]
  | succ N ih =>
    intro s hlen hpf
    by_cases hnil : ([] : List Bool) ∈ s
    · have hsub : s ⊆ {[]} := by
        intro bs hbs
        have heq : [] = bs := hpf [] hnil bs hbs List.nil_prefix
        simp [heq.symm]
      calc
        ∑ bs ∈ s, UL.bitListProb bs ≤ ∑ bs ∈ ({[]} : Finset (List Bool)), UL.bitListProb bs :=
          Finset.sum_le_sum_of_subset hsub
        _ = 1 := by simp [bitListProb_nil]
    · let sF : Finset (List Bool) :=
        (s.filter (fun bs => bs.head? = some false)).image List.tail
      let sT : Finset (List Bool) :=
        (s.filter (fun bs => bs.head? = some true)).image List.tail
      have hsub_union : s ⊆ sF.image (List.cons false) ∪ sT.image (List.cons true) := by
        intro bs hbs
        cases bs with
        | nil => exact absurd hbs hnil
        | cons b tl =>
          cases b
          · apply Finset.mem_union_left
            refine Finset.mem_image.mpr ⟨tl, ?_, rfl⟩
            exact Finset.mem_image.mpr ⟨false :: tl, Finset.mem_filter.mpr ⟨hbs, rfl⟩, rfl⟩
          · apply Finset.mem_union_right
            refine Finset.mem_image.mpr ⟨tl, ?_, rfl⟩
            exact Finset.mem_image.mpr ⟨true :: tl, Finset.mem_filter.mpr ⟨hbs, rfl⟩, rfl⟩
      have hsF_mem : ∀ tl ∈ sF, (false :: tl) ∈ s := by
        intro tl htl
        rcases Finset.mem_image.mp htl with ⟨bs, hbs, rfl⟩
        rcases Finset.mem_filter.mp hbs with ⟨hbs_s, hhead⟩
        cases bs with
        | nil => simp at hhead
        | cons b tl' =>
          simp at hhead
          subst hhead
          exact hbs_s
      have hsT_mem : ∀ tl ∈ sT, (true :: tl) ∈ s := by
        intro tl htl
        rcases Finset.mem_image.mp htl with ⟨bs, hbs, rfl⟩
        rcases Finset.mem_filter.mp hbs with ⟨hbs_s, hhead⟩
        cases bs with
        | nil => simp at hhead
        | cons b tl' =>
          simp at hhead
          subst hhead
          exact hbs_s
      have hsF_len : ∀ tl ∈ sF, tl.length ≤ N := by
        intro tl htl
        have h1 := hlen (false :: tl) (hsF_mem tl htl)
        simpa using h1
      have hsT_len : ∀ tl ∈ sT, tl.length ≤ N := by
        intro tl htl
        have h1 := hlen (true :: tl) (hsT_mem tl htl)
        simpa using h1
      have hsF_pf : ∀ x ∈ sF, ∀ y ∈ sF, x <+: y → x = y := by
        intro x hx y hy hxy
        have heq := hpf (false :: x) (hsF_mem x hx) (false :: y) (hsF_mem y hy)
          (List.cons_prefix_cons.mpr ⟨rfl, hxy⟩)
        exact (List.cons.inj heq).2
      have hsT_pf : ∀ x ∈ sT, ∀ y ∈ sT, x <+: y → x = y := by
        intro x hx y hy hxy
        have heq := hpf (true :: x) (hsT_mem x hx) (true :: y) (hsT_mem y hy)
          (List.cons_prefix_cons.mpr ⟨rfl, hxy⟩)
        exact (List.cons.inj heq).2
      have hinjF : Function.Injective (List.cons false) := fun _ _ h => (List.cons.inj h).2
      have hinjT : Function.Injective (List.cons true) := fun _ _ h => (List.cons.inj h).2
      have hhalf_sum : (2 : ENNReal)⁻¹ + (2 : ENNReal)⁻¹ = 1 := ENNReal.inv_two_add_inv_two
      calc
        ∑ bs ∈ s, UL.bitListProb bs
            ≤ ∑ bs ∈ sF.image (List.cons false) ∪ sT.image (List.cons true), UL.bitListProb bs :=
              Finset.sum_le_sum_of_subset hsub_union
        _ = (∑ bs ∈ sF.image (List.cons false), UL.bitListProb bs) +
              (∑ bs ∈ sT.image (List.cons true), UL.bitListProb bs) := by
              refine Finset.sum_union (Finset.disjoint_left.mpr (fun z hzF hzT => ?_))
              rcases Finset.mem_image.mp hzF with ⟨_, _, rfl⟩
              rcases Finset.mem_image.mp hzT with ⟨_, _, hcontra⟩
              simp at hcontra
        _ = (∑ tl ∈ sF, UL.bitListProb (false :: tl)) +
              (∑ tl ∈ sT, UL.bitListProb (true :: tl)) := by
              rw [Finset.sum_image (fun _ _ _ _ h => hinjF h),
                  Finset.sum_image (fun _ _ _ _ h => hinjT h)]
        _ = (2 : ENNReal)⁻¹ * (∑ tl ∈ sF, UL.bitListProb tl) +
              (2 : ENNReal)⁻¹ * (∑ tl ∈ sT, UL.bitListProb tl) := by
              simp only [bitListProb_cons, Finset.mul_sum]
        _ ≤ (2 : ENNReal)⁻¹ * 1 + (2 : ENNReal)⁻¹ * 1 := by
              gcongr
              · exact ih sF hsF_len hsF_pf
              · exact ih sT hsT_len hsT_pf
        _ = 1 := by simp [hhalf_sum]

theorem IsPrefixFree.haltProb_le_one {α : Type*} {f : List Bool → Option α}
    (hf : IsPrefixFree f) : haltProb f ≤ 1 := by
  unfold haltProb
  rw [ENNReal.tsum_eq_iSup_sum]
  refine iSup_le (fun s => ?_)
  classical
  let s' := s.filter (fun bs => (f bs).isSome)
  have hsum_eq : (∑ bs ∈ s, if (f bs).isSome then UL.bitListProb bs else 0) =
      ∑ bs ∈ s', UL.bitListProb bs := by
    rw [Finset.sum_filter]
  rw [hsum_eq]
  let N := s'.sup List.length
  have hlen : ∀ bs ∈ s', bs.length ≤ N := fun bs hbs => Finset.le_sup (f := List.length) hbs
  have hpf : ∀ x ∈ s', ∀ y ∈ s', x <+: y → x = y := by
    intro x hx y hy hxy
    have hx_some : (f x).isSome := (Finset.mem_filter.mp hx).2
    have hy_some : (f y).isSome := (Finset.mem_filter.mp hy).2
    obtain ⟨ax, hax⟩ := Option.isSome_iff_exists.mp hx_some
    obtain ⟨ay, hay⟩ := Option.isSome_iff_exists.mp hy_some
    exact hf x y ax ay hax hay hxy
  exact isPrefixFree_finset_sum_le_one N s' hlen hpf

theorem IsPrefixFree.eq_nil_of_some_nil {α : Type*} {f : List Bool → Option α}
    (hf : IsPrefixFree f) {a₀ a : α} (h0 : f [] = some a₀) {bs : List Bool}
    (hbs : f bs = some a) : bs = [] :=
  (hf [] bs a₀ a h0 hbs List.nil_prefix).symm

/-! ### 3. `pureWithBits` and `bindWithBits` calculus -/

theorem pureWithBits_eq_some_iff {α : Type} (a x : α) (bs : List Bool) :
    UL.pureWithBits a bs = some x ↔ bs = [] ∧ a = x := by
  unfold UL.pureWithBits
  cases bs <;> simp

theorem isPrefixFree_pureWithBits {α : Type} (a : α) :
    IsPrefixFree (UL.pureWithBits a) := by
  intro bs₁ bs₂ a₁ a₂ h1 h2 _
  rw [pureWithBits_eq_some_iff] at h1 h2
  rw [h1.1, h2.1]

theorem tsum_pureWithBits {α : Type} (a : α) (W : α → ENNReal) :
    (∑' bs : List Bool,
      match UL.pureWithBits a bs with
      | some x => UL.bitListProb bs * W x
      | none => 0) = W a := by
  have hterm : (fun bs : List Bool =>
      match UL.pureWithBits a bs with
      | some x => UL.bitListProb bs * W x
      | none => 0) =
      fun bs : List Bool => if bs = [] then W a else 0 := by
    ext bs
    cases bs <;> simp [UL.pureWithBits, bitListProb_nil]
  rw [hterm, tsum_ite_eq]

theorem haltProb_pureWithBits {α : Type} (a : α) :
    haltProb (UL.pureWithBits a) = 1 := by
  unfold haltProb
  have hterm : (fun bs : List Bool => if (UL.pureWithBits a bs).isSome then UL.bitListProb bs else 0) =
      fun bs : List Bool => if bs = [] then 1 else 0 := by
    ext bs
    cases bs <;> simp [UL.pureWithBits, bitListProb_nil]
  rw [hterm, tsum_ite_eq]

theorem prefixFree_append_unique {α : Type*} {f : List Bool → Option α} (hf : IsPrefixFree f)
    {bs₁ bs₂ bs₁' bs₂' : List Bool} {a a' : α}
    (heq : bs₁ ++ bs₂ = bs₁' ++ bs₂')
    (ha : f bs₁ = some a) (ha' : f bs₁' = some a') :
    bs₁ = bs₁' ∧ bs₂ = bs₂' ∧ a = a' := by
  have hpref : bs₁ <+: bs₁' ∨ bs₁' <+: bs₁ := by
    rcases List.append_eq_append_iff.mp heq with ⟨as, rfl, _⟩ | ⟨cs, rfl, _⟩
    · exact Or.inl ⟨as, rfl⟩
    · exact Or.inr ⟨cs, rfl⟩
  have hbs₁ : bs₁ = bs₁' := by
    rcases hpref with h1 | h2
    · exact hf bs₁ bs₁' a a' ha ha' h1
    · exact (hf bs₁' bs₁ a' a ha' ha h2).symm
  subst hbs₁
  have hbs₂ : bs₂ = bs₂' := List.append_cancel_left heq
  have ha_eq : a = a' := Option.some.inj (ha.symm.trans ha')
  exact ⟨rfl, hbs₂, ha_eq⟩

theorem bindWithBits_eq_of_prefixFree {α β : Type}
    {f : List Bool → Option α} (hf : IsPrefixFree f)
    (g : α → List Bool → Option β)
    {bs₁ bs₂ : List Bool} {a : α} (ha : f bs₁ = some a) :
    UL.bindWithBits f g (bs₁ ++ bs₂) = g a bs₂ := by
  unfold UL.bindWithBits
  have hex : ∃ (u v : List Bool) (x : α), bs₁ ++ bs₂ = u ++ v ∧ f u = some x :=
    ⟨bs₁, bs₂, a, rfl, ha⟩
  rw [dif_pos hex]
  have hu := Classical.choose_spec hex
  have hv := Classical.choose_spec hu
  have hx := Classical.choose_spec hv
  obtain ⟨_, hv_eq, hx_eq⟩ := prefixFree_append_unique hf hx.1 ha hx.2
  dsimp only
  rw [← hx_eq, ← hv_eq]

theorem bindWithBits_eq_some_iff {α β : Type}
    {f : List Bool → Option α} (hf : IsPrefixFree f)
    (g : α → List Bool → Option β) (bs : List Bool) (b : β) :
    UL.bindWithBits f g bs = some b ↔
      ∃ bs₁ bs₂ a, bs = bs₁ ++ bs₂ ∧ f bs₁ = some a ∧ g a bs₂ = some b := by
  constructor
  · intro h
    unfold UL.bindWithBits at h
    split_ifs at h with hex
    · set u := Classical.choose hex
      have hu := Classical.choose_spec hex
      set v := Classical.choose hu
      have hv := Classical.choose_spec hu
      set x := Classical.choose hv
      have hx : bs = u ++ v ∧ f u = some x := Classical.choose_spec hv
      exact ⟨u, v, x, hx.1, hx.2, h⟩
  · rintro ⟨bs₁, bs₂, a, rfl, ha, hb⟩
    rw [bindWithBits_eq_of_prefixFree hf g ha]
    exact hb

theorem IsPrefixFree.bindWithBits {α β : Type}
    {f : List Bool → Option α} (hf : IsPrefixFree f)
    {g : α → List Bool → Option β}
    (hg : ∀ bs₁ a, f bs₁ = some a → IsPrefixFree (g a)) :
    IsPrefixFree (UL.bindWithBits f g) := by
  intro bs bs' b b' hb hb' hpref
  rw [bindWithBits_eq_some_iff hf] at hb hb'
  rcases hb with ⟨u, v, a, rfl, hu, hv⟩
  rcases hb' with ⟨u', v', a', rfl, hu', hv'⟩
  rcases hpref with ⟨w, hw⟩
  have heq : u ++ (v ++ w) = u' ++ v' := by simpa [List.append_assoc] using hw
  obtain ⟨rfl, hvw, rfl⟩ := prefixFree_append_unique hf heq hu hu'
  have hv_eq : v = v' := hg u a hu v v' b b' hv hv' ⟨w, hvw⟩
  rw [hv_eq]

theorem tsum_bindWithBits {α β : Type}
    {f : List Bool → Option α} (hf : IsPrefixFree f)
    (g : α → List Bool → Option β) (W : β → ENNReal) :
    (∑' bs : List Bool,
      match UL.bindWithBits f g bs with
      | some b => UL.bitListProb bs * W b
      | none => 0) =
    ∑' bs₁ : List Bool,
      match f bs₁ with
      | some a => UL.bitListProb bs₁ *
          (∑' bs₂ : List Bool,
            match g a bs₂ with
            | some b => UL.bitListProb bs₂ * W b
            | none => 0)
      | none => 0 := by
  classical
  let F : List Bool → ENNReal := fun bs =>
    match UL.bindWithBits f g bs with
    | some b => UL.bitListProb bs * W b
    | none => 0
  let G : List Bool × List Bool → ENNReal := fun p =>
    match f p.1 with
    | some a =>
        match g a p.2 with
        | some b => UL.bitListProb p.1 * (UL.bitListProb p.2 * W b)
        | none => 0
    | none => 0
  have hRHS : (∑' p : List Bool × List Bool, G p) =
      ∑' bs₁ : List Bool,
        match f bs₁ with
        | some a => UL.bitListProb bs₁ *
            (∑' bs₂ : List Bool,
              match g a bs₂ with
              | some b => UL.bitListProb bs₂ * W b
              | none => 0)
        | none => 0 := by
    rw [ENNReal.tsum_prod']
    refine tsum_congr (fun bs₁ => ?_)
    cases h1 : f bs₁ with
    | none =>
      have h0 : ∀ bs₂ : List Bool, G (bs₁, bs₂) = 0 := fun bs₂ => by simp [G, h1]
      simp [h0]
    | some a =>
      dsimp only
      rw [← ENNReal.tsum_mul_left]
      refine tsum_congr (fun bs₂ => ?_)
      dsimp only [G]
      rw [h1]
      dsimp only
      cases g a bs₂ <;> simp
  change (∑' bs : List Bool, F bs) = _
  rw [← hRHS]
  apply le_antisymm
  · rw [ENNReal.tsum_eq_iSup_sum]
    refine iSup_le (fun s => ?_)
    let s' := s.filter (fun bs => (UL.bindWithBits f g bs).isSome)
    have hsum_s : ∑ bs ∈ s, F bs = ∑ bs ∈ s', F bs := by
      rw [Finset.sum_filter]
      refine Finset.sum_congr rfl (fun bs _ => ?_)
      cases h : UL.bindWithBits f g bs <;> simp [F, h]
    rw [hsum_s]
    let toPair : List Bool → List Bool × List Bool := fun bs =>
      if hex : ∃ u v a, bs = u ++ v ∧ f u = some a then
        let u := Classical.choose hex
        let v := Classical.choose (Classical.choose_spec hex)
        (u, v)
      else
        ([], bs)
    have hpair_eq : ∀ bs ∈ s', (toPair bs).1 ++ (toPair bs).2 = bs ∧ F bs = G (toPair bs) := by
      intro bs hbs
      have hsome : (UL.bindWithBits f g bs).isSome := (Finset.mem_filter.mp hbs).2
      obtain ⟨b, hb⟩ := Option.isSome_iff_exists.mp hsome
      obtain ⟨u0, v0, a0, h_uv0, hu0, hv0⟩ := (bindWithBits_eq_some_iff hf g bs b).mp hb
      have hex : ∃ u v a, bs = u ++ v ∧ f u = some a := ⟨u0, v0, a0, h_uv0, hu0⟩
      have hu_spec := Classical.choose_spec hex
      have hv_spec := Classical.choose_spec hu_spec
      have ha_spec := Classical.choose_spec hv_spec
      obtain ⟨hu_eq, hv_eq, _⟩ :=
        prefixFree_append_unique hf (h_uv0.symm.trans ha_spec.1) hu0 ha_spec.2
      have htp' : toPair bs = (u0, v0) := by
        simp only [toPair, dif_pos hex]
        exact Prod.ext hu_eq.symm hv_eq.symm
      refine ⟨by simpa [htp'] using h_uv0.symm, ?_⟩
      dsimp only [F, G]
      rw [hb, htp', h_uv0]
      dsimp only
      rw [hu0]
      dsimp only
      rw [hv0, bitListProb_append, mul_assoc]
    have hinj : Set.InjOn toPair ↑s' := by
      intro x hx y hy hxy
      have hx_eq := (hpair_eq x hx).1
      have hy_eq := (hpair_eq y hy).1
      rw [← hx_eq, ← hy_eq, hxy]
    calc
      ∑ bs ∈ s', F bs = ∑ bs ∈ s', G (toPair bs) :=
        Finset.sum_congr rfl (fun bs hbs => (hpair_eq bs hbs).2)
      _ = ∑ p ∈ s'.image toPair, G p := (Finset.sum_image hinj).symm
      _ ≤ ∑' p : List Bool × List Bool, G p := ENNReal.sum_le_tsum _
  · rw [ENNReal.tsum_eq_iSup_sum]
    refine iSup_le (fun t => ?_)
    let t' := t.filter (fun p => (f p.1).isSome)
    have hsum_t : ∑ p ∈ t, G p = ∑ p ∈ t', G p := by
      rw [Finset.sum_filter]
      refine Finset.sum_congr rfl (fun p _ => ?_)
      cases h : f p.1 <;> simp [G, h]
    rw [hsum_t]
    let app : List Bool × List Bool → List Bool := fun p => p.1 ++ p.2
    have hinj : Set.InjOn app ↑t' := by
      intro p₁ hp₁ p₂ hp₂ heq
      obtain ⟨a₁, ha₁⟩ := Option.isSome_iff_exists.mp (Finset.mem_filter.mp hp₁).2
      obtain ⟨a₂, ha₂⟩ := Option.isSome_iff_exists.mp (Finset.mem_filter.mp hp₂).2
      obtain ⟨h1, h2, _⟩ := prefixFree_append_unique hf heq ha₁ ha₂
      exact Prod.ext h1 h2
    have hG_eq : ∀ p ∈ t', G p = F (app p) := by
      intro p hp
      obtain ⟨a, ha⟩ := Option.isSome_iff_exists.mp (Finset.mem_filter.mp hp).2
      simp only [G, F, app, ha, bindWithBits_eq_of_prefixFree hf g ha]
      cases g a p.2 <;> simp [bitListProb_append, mul_assoc]
    calc
      ∑ p ∈ t', G p = ∑ p ∈ t', F (app p) :=
        Finset.sum_congr rfl (fun p hp => hG_eq p hp)
      _ = ∑ bs ∈ t'.image app, F bs := (Finset.sum_image hinj).symm
      _ ≤ ∑' bs : List Bool, F bs := ENNReal.sum_le_tsum _

theorem haltProb_bindWithBits {α β : Type}
    {f : List Bool → Option α} (hf : IsPrefixFree f) (hf1 : haltProb f = 1)
    {g : α → List Bool → Option β}
    (hg1 : ∀ bs₁ a, f bs₁ = some a → haltProb (g a) = 1) :
    haltProb (UL.bindWithBits f g) = 1 := by
  have heq : haltProb (UL.bindWithBits f g) =
      ∑' bs : List Bool,
        match UL.bindWithBits f g bs with
        | some b => UL.bitListProb bs * (1 : ENNReal)
        | none => 0 := by
    unfold haltProb
    refine tsum_congr (fun bs => ?_)
    cases UL.bindWithBits f g bs <;> simp
  rw [heq, tsum_bindWithBits hf g (fun _ => 1)]
  have hinner : ∀ bs₁ : List Bool,
      (match f bs₁ with
      | some a => UL.bitListProb bs₁ *
          (∑' bs₂ : List Bool,
            match g a bs₂ with
            | some _ => UL.bitListProb bs₂ * (1 : ENNReal)
            | none => 0)
      | none => 0) =
      if (f bs₁).isSome then UL.bitListProb bs₁ else 0 := by
    intro bs₁
    cases h1 : f bs₁ with
    | none => simp
    | some a =>
      dsimp only
      have hg_eq : (∑' bs₂ : List Bool,
          match g a bs₂ with
          | some _ => UL.bitListProb bs₂ * (1 : ENNReal)
          | none => 0) = haltProb (g a) := by
        unfold haltProb
        refine tsum_congr (fun bs₂ => ?_)
        cases g a bs₂ <;> simp
      rw [hg_eq, hg1 bs₁ a h1]
      simp
  simp_rw [hinner]
  exact hf1

/-! ### 4. Countable `tsum`-`iSup` swap for prefix-free steps -/

theorem ennreal_le_of_forall_pos_le_add {x y : ENNReal}
    (h : ∀ ε : ℝ, 0 < ε → x ≤ y + ENNReal.ofReal ε) : x ≤ y := by
  by_cases hy : y = ⊤
  · rw [hy]
    exact le_top
  · by_contra hlt
    push_neg at hlt
    by_cases hx : x = ⊤
    · have h1 := h 1 zero_lt_one
      rw [hx] at h1
      have hne : y + ENNReal.ofReal 1 ≠ ⊤ := ENNReal.add_ne_top.mpr ⟨hy, ENNReal.ofReal_ne_top⟩
      exact hne (top_le_iff.mp h1)
    · have hpos : 0 < (x - y).toReal :=
        ENNReal.toReal_pos (tsub_pos_iff_lt.mpr hlt).ne' (ENNReal.sub_ne_top hx)
      let ε := (x - y).toReal / 2
      have hε : 0 < ε := half_pos hpos
      have hle := h ε hε
      have hreal := ENNReal.toReal_mono (ENNReal.add_ne_top.mpr ⟨hy, ENNReal.ofReal_ne_top⟩) hle
      rw [ENNReal.toReal_add hy ENNReal.ofReal_ne_top, ENNReal.toReal_ofReal hε.le] at hreal
      have hsub : (x - y).toReal = x.toReal - y.toReal :=
        ENNReal.toReal_sub_of_le hlt.le hx
      dsimp only [ε] at hreal
      linarith

theorem tsum_add_iSup_le {α : Type*} {f : List Bool → Option α}
    (hf : IsPrefixFree f)
    (c : α → ENNReal)
    {ι : α → Type*} [h_ne : ∀ a, Nonempty (ι a)]
    (Φ : (a : α) → ι a → ENNReal) :
    (∑' bs : List Bool,
      match f bs with
      | some a => UL.bitListProb bs * (c a + ⨆ x : ι a, Φ a x)
      | none => 0) ≤
    ⨆ (choice : List Bool → (a : α) → ι a),
      ∑' bs : List Bool,
        match f bs with
        | some a => UL.bitListProb bs * (c a + Φ a (choice bs a))
        | none => 0 := by
  classical
  let R_fn : (List Bool → (a : α) → ι a) → ENNReal := fun choice =>
    ∑' bs : List Bool,
      match f bs with
      | some a => UL.bitListProb bs * (c a + Φ a (choice bs a))
      | none => 0
  change _ ≤ ⨆ choice, R_fn choice
  set R := ⨆ choice, R_fn choice
  by_cases hR : R = ⊤
  · rw [hR]
    exact le_top
  · refine ennreal_le_of_forall_pos_le_add (fun ε hε => ?_)
    let δ := ENNReal.ofReal ε
    have hδ_pos : 0 < δ := ENNReal.ofReal_pos.mpr hε
    have hex_choice : ∀ (bs : List Bool) (a : α),
        f bs = some a → ∃ x : ι a, ⨆ x' : ι a, Φ a x' ≤ Φ a x + δ := by
      intro bs a hfa
      set M := ⨆ x' : ι a, Φ a x'
      have hM_ne_top : M ≠ ⊤ := by
        intro hM_top
        have hgt : R / UL.bitListProb bs < M := by
          rw [hM_top]
          exact lt_top_iff_ne_top.mpr (ENNReal.div_ne_top hR (bitListProb_ne_zero bs))
        obtain ⟨x₀, hx₀⟩ := lt_iSup_iff.mp hgt
        let ch0 : List Bool → (a' : α) → ι a' :=
          fun _ a' => if h_eq : a' = a then h_eq ▸ x₀ else Classical.choice (h_ne a')
        have hch0_le : R_fn ch0 ≤ R := le_iSup R_fn ch0
        have hsingle : UL.bitListProb bs * (c a + Φ a x₀) ≤ R := by
          have hle_tsum := ENNReal.le_tsum (f := fun bs' : List Bool =>
            match f bs' with
            | some a' => UL.bitListProb bs' * (c a' + Φ a' (ch0 bs' a'))
            | none => 0) bs
          simpa [R_fn, hfa, ch0] using hle_tsum.trans hch0_le
        have h1 : UL.bitListProb bs * Φ a x₀ ≤ R :=
          (mul_le_mul_left' le_add_self _).trans hsingle
        have h2 : Φ a x₀ ≤ R / UL.bitListProb bs :=
          (ENNReal.le_div_iff_mul_le (Or.inl (bitListProb_ne_zero bs))
            (Or.inl (bitListProb_ne_top bs))).mpr (by simpa [mul_comm] using h1)
        exact not_lt_of_ge h2 hx₀
      by_cases hM0 : M = 0
      · obtain ⟨x₀⟩ := h_ne a
        exact ⟨x₀, by simp [hM0]⟩
      · have hsub_lt : M - δ < M :=
          ENNReal.sub_lt_self hM_ne_top hM0 hδ_pos.ne'
        obtain ⟨x₀, hx₀⟩ := lt_iSup_iff.mp hsub_lt
        exact ⟨x₀, tsub_le_iff_right.mp hx₀.le⟩
    let ch : List Bool → (a : α) → ι a := fun bs a =>
      if hfa : f bs = some a then Classical.choose (hex_choice bs a hfa)
      else Classical.choice (h_ne a)
    have hch_spec : ∀ bs a, f bs = some a → ⨆ x' : ι a, Φ a x' ≤ Φ a (ch bs a) + δ := by
      intro bs a hfa
      simpa [ch, hfa] using Classical.choose_spec (hex_choice bs a hfa)
    have hterm_le : ∀ bs : List Bool,
        (match f bs with
        | some a => UL.bitListProb bs * (c a + ⨆ x : ι a, Φ a x)
        | none => 0) ≤
        (match f bs with
        | some a => UL.bitListProb bs * (c a + Φ a (ch bs a))
        | none => 0) +
        (if (f bs).isSome then UL.bitListProb bs else 0) * δ := by
      intro bs
      cases h : f bs with
      | none => simp
      | some a =>
        dsimp only
        simp only [Option.isSome_some, ↓reduceIte]
        calc
          UL.bitListProb bs * (c a + ⨆ x : ι a, Φ a x)
              ≤ UL.bitListProb bs * (c a + (Φ a (ch bs a) + δ)) := by
                gcongr
                exact hch_spec bs a h
          _ = UL.bitListProb bs * (c a + Φ a (ch bs a)) + UL.bitListProb bs * δ := by
                ring
    calc
      (∑' bs : List Bool,
        match f bs with
        | some a => UL.bitListProb bs * (c a + ⨆ x : ι a, Φ a x)
        | none => 0)
          ≤ ∑' bs : List Bool,
              ((match f bs with
                | some a => UL.bitListProb bs * (c a + Φ a (ch bs a))
                | none => 0) +
               (if (f bs).isSome then UL.bitListProb bs else 0) * δ) :=
            ENNReal.tsum_le_tsum hterm_le
      _ = R_fn ch + haltProb f * δ := by
            rw [ENNReal.tsum_add, ENNReal.tsum_mul_right]
            rfl
      _ ≤ R + 1 * δ := by
            gcongr
            · exact le_iSup R_fn ch
            · exact hf.haltProb_le_one
      _ = R + ENNReal.ofReal ε := by simp [δ]


/-! ### 5. `expWithBits` combinator (eliminates fresh `match` auxiliary constants) -/

noncomputable def expWithBits {α : Type*} (f : List Bool → Option α) (W : α → ENNReal) : ENNReal :=
  ∑' bs : List Bool,
    match f bs with
    | some a => UL.bitListProb bs * W a
    | none => 0

theorem expWithBits_eq {α : Type*} (f : List Bool → Option α) (W : α → ENNReal) :
    expWithBits f W = ∑' bs : List Bool,
      match f bs with
      | some a => UL.bitListProb bs * W a
      | none => 0 := rfl

theorem expWithBits_congr {α : Type*} {f₁ f₂ : List Bool → Option α}
    (hf : ∀ bs, f₁ bs = f₂ bs) {W₁ W₂ : α → ENNReal}
    (hW : ∀ bs a, f₂ bs = some a → W₁ a = W₂ a) :
    expWithBits f₁ W₁ = expWithBits f₂ W₂ := by
  unfold expWithBits
  refine tsum_congr (fun bs => ?_)
  rw [hf bs]
  cases h : f₂ bs with
  | none => rfl
  | some a =>
    dsimp only
    rw [hW bs a h]

theorem expWithBits_mono {α : Type*} {f : List Bool → Option α}
    {W₁ W₂ : α → ENNReal}
    (hW : ∀ bs a, f bs = some a → W₁ a ≤ W₂ a) :
    expWithBits f W₁ ≤ expWithBits f W₂ := by
  unfold expWithBits
  refine ENNReal.tsum_le_tsum (fun bs => ?_)
  cases h : f bs with
  | none => exact le_rfl
  | some a =>
    dsimp only
    exact mul_le_mul_left' (hW bs a h) _

theorem expWithBits_pure {α : Type} (a : α) (W : α → ENNReal) :
    expWithBits (UL.pureWithBits a) W = W a :=
  tsum_pureWithBits a W

theorem expWithBits_bind {α β : Type}
    {f : List Bool → Option α} (hf : IsPrefixFree f)
    (g : α → List Bool → Option β) (W : β → ENNReal) :
    expWithBits (UL.bindWithBits f g) W =
      expWithBits f (fun a => expWithBits (g a) W) :=
  tsum_bindWithBits hf g W

theorem expWithBits_one_eq_haltProb {α : Type*} (f : List Bool → Option α) :
    expWithBits f (fun _ => 1) = haltProb f := by
  unfold expWithBits haltProb
  refine tsum_congr (fun bs => ?_)
  cases f bs <;> simp

theorem expWithBits_const_mul {α : Type*} (f : List Bool → Option α)
    (W : α → ENNReal) (C : ENNReal) :
    expWithBits f (fun a => W a * C) = expWithBits f W * C := by
  unfold expWithBits
  rw [← ENNReal.tsum_mul_right]
  refine tsum_congr (fun bs => ?_)
  cases f bs <;> simp [mul_assoc]

theorem expWithBits_add {α : Type*} (f : List Bool → Option α)
    (W₁ W₂ : α → ENNReal) :
    expWithBits f (fun a => W₁ a + W₂ a) = expWithBits f W₁ + expWithBits f W₂ := by
  unfold expWithBits
  rw [← ENNReal.tsum_add]
  refine tsum_congr (fun bs => ?_)
  cases f bs with
  | none => simp
  | some a =>
    dsimp only
    ring

theorem expWithBits_const {α : Type*} (f : List Bool → Option α) (C : ENNReal) :
    expWithBits f (fun _ => C) = haltProb f * C := by
  have h1 : (fun _ : α => C) = fun a => (1 : ENNReal) * C := by ext; simp
  rw [h1, expWithBits_const_mul, expWithBits_one_eq_haltProb]

theorem expWithBits_const_add_of_haltProb_one {α : Type*}
    {f : List Bool → Option α} (hf1 : haltProb f = 1)
    (C : ENNReal) (W : α → ENNReal) :
    expWithBits f (fun a => C + W a) = C + expWithBits f W := by
  rw [expWithBits_add, expWithBits_const, hf1, one_mul]

theorem expWithBits_add_const_of_haltProb_one {α : Type*}
    {f : List Bool → Option α} (hf1 : haltProb f = 1)
    (W : α → ENNReal) (C : ENNReal) :
    expWithBits f (fun a => W a + C) = expWithBits f W + C := by
  rw [expWithBits_add, expWithBits_const, hf1, one_mul]

theorem expWithBits_add_iSup_le {α : Type*} {f : List Bool → Option α}
    (hf : IsPrefixFree f)
    (c : α → ENNReal)
    {ι : α → Type*} [∀ a, Nonempty (ι a)]
    (Φ : (a : α) → ι a → ENNReal) :
    expWithBits f (fun a => c a + ⨆ x : ι a, Φ a x) ≤
    ⨆ (choice : List Bool → (a : α) → ι a),
      ∑' bs : List Bool,
        match f bs with
        | some a => UL.bitListProb bs * (c a + Φ a (choice bs a))
        | none => 0 :=
  tsum_add_iSup_le hf c Φ

end UL.Proof.lem_C_3.RacerCG
