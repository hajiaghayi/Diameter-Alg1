import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b2_StepBLevels
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Frame Helpers (`LevelStoredInv.unchanged`, `EmptyLevelSlot.unchanged`, `jStarStep`) -/

theorem LevelStoredInv.unchanged {d s₀_d n L B B_cert K_max : ℕ}
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {qMap : ℕ → Fin d → ℚ} {S_lt : Finset ℕ}
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)} {j : ℕ} {ws₁ ws₂ : WordStore}
    (hwf₁ : WellFormedWS ws₁) (hwf₂ : WellFormedWS ws₂)
    (h : LevelStoredInv n L B B_cert K_max P ltCoords qMap S_lt v j ws₁)
    (htab3 : ∀ off < posNodeStride d L,
      ((.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
        ws₁.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)))
    (htab4 : ∀ h' < 2 ^ L,
      ((.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ))) =
        ws₁.vals (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ))))
    (htree2 : ∀ u < 2 ^ (L + 1), ∀ f < 4,
      ((.heap 2 (treeCellAddr L (2 * j + 2) u f) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 2 (treeCellAddr L (2 * j + 2) u f) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 2 (treeCellAddr L (2 * j + 2) u f)) =
        ws₁.vals (.heap 2 (treeCellAddr L (2 * j + 2) u f)))
    (htree3 : ∀ u < 2 ^ (L + 1), ∀ f < 4,
      ((.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 2 (treeCellAddr L (2 * j + 3) u f)) =
        ws₁.vals (.heap 2 (treeCellAddr L (2 * j + 3) u f))) :
    LevelStoredInv n L B B_cert K_max P ltCoords qMap S_lt v j ws₂ := by
  have hp := h.toPreTrigger.unchanged hwf₁ hwf₂ htab3 htab4 htree2 htree3
  exact
    { hj_le := hp.hj_le
      hm_bounds := hp.hm_bounds
      hage_le := h.hage_le
      hage_rel := hp.hage_rel
      hnode_o := hp.hnode_o
      hnode_s := hp.hnode_s
      hnode_V := hp.hnode_V
      hcp := hp.hcp
      hk_bounds := hp.hk_bounds
      hk_ratio := hp.hk_ratio
      hbirth_adm := hp.hbirth_adm
      hgeom := hp.hgeom
      read_age := hp.read_age
      read_mbirth := hp.read_mbirth
      read_kblk := hp.read_kblk
      hbh_lt := hp.hbh_lt
      hbh_inj := hp.hbh_inj
      hblt_mem := hp.hblt_mem
      hblt_inj := hp.hblt_inj
      hbh_active_sync := hp.hbh_active_sync
      read_bh := hp.read_bh
      unused_tab3 := hp.unused_tab3
      hcerts := hp.hcerts
      tree_Sj := hp.tree_Sj
      tab4_spec := hp.tab4_spec
      tree_intact := ⟨h.tree_intact.1, hp.tree_intact_raw⟩ }

theorem EmptyLevelSlot.unchanged {d L j : ℕ} {ws₁ ws₂ : WordStore}
    (h : EmptyLevelSlot d L j ws₁)
    (htab3 : ∀ off < posNodeStride d L,
      (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws₂.live →
        (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws₁.live)
    (htab4 : ∀ h' < 2 ^ L,
      (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ ws₂.live →
        (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ ws₁.live)
    (htree2 : ∀ u < 2 ^ (L + 1), ∀ f < 4,
      (.heap 2 (treeCellAddr L (2 * j + 2) u f) : RAMCellLoc) ∈ ws₂.live →
        (.heap 2 (treeCellAddr L (2 * j + 2) u f) : RAMCellLoc) ∈ ws₁.live)
    (htree3 : ∀ u < 2 ^ (L + 1), ∀ f < 4,
      (.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∈ ws₂.live →
        (.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∈ ws₁.live) :
    EmptyLevelSlot d L j ws₂ :=
  ⟨fun off hoff hm => h.1 off hoff (htab3 off hoff hm),
   fun h' hh' hm => h.2.1 h' hh' (htab4 h' hh' hm),
   fun u hu f hf hm => h.2.2.1 u hu f hf (htree2 u hu f hf hm),
   fun u hu f hf hm => h.2.2.2 u hu f hf (htree3 u hu f hf hm)⟩

open Classical in
noncomputable def jStarStep (k : ℕ) (trig : ℕ → Prop) : ℕ → ℕ
  | 0 => k + 1
  | m + 1 =>
      let prev := jStarStep k trig m
      if trig m ∧ m < prev then m else prev

theorem jStarStep_spec (k : ℕ) (trig : ℕ → Prop) :
    ∀ m ≤ k + 1,
      jStarStep k trig m ≤ k + 1 ∧
      (((∀ i < m, ¬ trig i) ∧ jStarStep k trig m = k + 1) ∨
       (∃ i < m, trig i ∧ jStarStep k trig m = i ∧ ∀ i' < i, ¬ trig i')) := by
  classical
  intro m hm
  induction m with
  | zero =>
      exact ⟨le_rfl, Or.inl ⟨fun i hi => absurd hi (Nat.not_lt_zero _), rfl⟩⟩
  | succ j ih =>
      obtain ⟨hle_prev, hcases⟩ := ih (Nat.le_of_succ_le hm)
      dsimp only [jStarStep]
      rcases hcases with ⟨hnone, heq_k1⟩ | ⟨i₀, hi₀_lt, htr₀, heq_i₀, hmin₀⟩
      · by_cases htr_j : trig j
        · have hj_lt : j < jStarStep k trig j := by rw [heq_k1]; omega
          rw [if_pos ⟨htr_j, hj_lt⟩]
          exact ⟨by omega, Or.inr ⟨j, Nat.lt_succ_self j, htr_j, rfl, hnone⟩⟩
        · rw [if_neg (fun h => htr_j h.1)]
          refine ⟨hle_prev, Or.inl ⟨fun i hi => ?_, heq_k1⟩⟩
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
          · exact hnone i hlt
          · exact htr_j
      · have hnlt : ¬ (j < jStarStep k trig j) := by rw [heq_i₀]; omega
        rw [if_neg (fun h => hnlt h.2)]
        exact ⟨hle_prev, Or.inr ⟨i₀, Nat.lt_succ_of_lt hi₀_lt, htr₀, heq_i₀, hmin₀⟩⟩

theorem jStarStep_final (k : ℕ) (trig : ℕ → Prop) :
    let js := jStarStep k trig (k + 1)
    (∀ (hTrig : ∃ j : ℕ, j ≤ k ∧ trig j),
      js = @Nat.find _ (Classical.decPred _) hTrig ∧ js ≤ k ∧ ∀ i < js, ¬ trig i) ∧
    ((¬ ∃ j : ℕ, j ≤ k ∧ trig j) → js = k + 1 ∧ ∀ j ≤ k, ¬ trig j) := by
  letI : DecidablePred (fun j : ℕ => j ≤ k ∧ trig j) := Classical.decPred _
  intro js
  obtain ⟨_, hcases⟩ := jStarStep_spec k trig (k + 1) le_rfl
  constructor
  · intro hTrig
    rcases hcases with ⟨hnone, _⟩ | ⟨i₀, hi₀_lt, htr₀, heq_i₀, hmin₀⟩
    · rcases hTrig with ⟨j, hj, htr⟩
      exact absurd htr (hnone j (Nat.lt_succ_of_le hj))
    · have hi₀_le : i₀ ≤ k := Nat.lt_succ_iff.mp hi₀_lt
      have hfind : @Nat.find _ (Classical.decPred _) hTrig = i₀ := by
        rw [Nat.find_eq_iff]
        exact ⟨⟨hi₀_le, htr₀⟩, fun n hn h => hmin₀ n hn h.2⟩
      have hjs_eq : js = i₀ := heq_i₀
      exact ⟨hjs_eq.trans hfind.symm, hjs_eq ▸ hi₀_le, hjs_eq ▸ hmin₀⟩
  · intro hnTrig
    rcases hcases with ⟨hnone, heq_k1⟩ | ⟨i₀, hi₀_lt, htr₀, _, _⟩
    · exact ⟨heq_k1, fun j hj => hnone j (Nat.lt_succ_of_le hj)⟩
    · exact absurd ⟨i₀, Nat.lt_succ_iff.mp hi₀_lt, htr₀⟩ hnTrig

/-! ### 2. Combined Per-Level Step (`exec_posDimStepBLevel`) -/

def opIsIns {d : ℕ} : DynamicUpdate d → ℤ
  | .insert _ _ _ => 1
  | .delete _ => 0

noncomputable def opNextLtCoords {d : ℕ} (P : DynamicPointSet d)
    (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)) : DynamicUpdate d → (ℕ → EuclideanSpace ℝ (Fin d))
  | .insert _ _ pt => Function.update ltCoords P.nextLifetime pt
  | .delete _ => ltCoords

def OpStepASpec {d : ℕ} (P P' : DynamicPointSet d) (qMap qMap' : ℕ → Fin d → ℚ) (hOp : ℕ) :
    DynamicUpdate d → Prop
  | .insert id extName pt =>
      applyDynamicUpdate P (.insert id extName pt) (some hOp) = some P' ∧
      hOp ∉ P.activeHandles ∧ hOp ∈ P'.activeHandles ∧
      ratPointToEuclidean (qMap' hOp) = pt ∧
      (∀ h ∈ P.activeHandles, qMap' h = qMap h)
  | .delete id =>
      applyDynamicUpdate P (.delete id) none = some P' ∧
      hOp = P.handleOfId id ∧ qMap' = qMap

def OpAliveSpec {d k : ℕ} (vecNodes : Fin k → ChainNode d) (m : ℕ) (alive_m : Bool) (w : WordStore) :
    DynamicUpdate d → Prop
  | .insert _ _ pt =>
      (alive_m = true ↔ ∀ (i : ℕ) (hi : i < m) (hmk : m ≤ k),
        pt ∉ coreBall (vecNodes ⟨i, lt_of_lt_of_le hi hmk⟩).o
          (vecNodes ⟨i, lt_of_lt_of_le hi hmk⟩).V) ∧
      w.read (.heap 9 105) = if alive_m then 1 else 0
  | .delete _ => True

theorem exec_posDimStepBLevel {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (h2n_pow : 2 * n ≤ 2 ^ L)
    (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P P' : DynamicPointSet d} (hwfP : P.WellFormed n) (hwfP' : P'.WellFormed n)
    {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {op : DynamicUpdate d} {hOp : ℕ} (hhOp_lt : hOp < 2 ^ L)
    {qMap qMap' : ℕ → Fin d → ℚ}
    (hop_spec : OpStepASpec P P' qMap qMap' hOp op)
    {k : ℕ} (hk_le : k ≤ K_max) {vecNodes : Fin k → ChainNode d}
    {j : ℕ} (hj : j < k)
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)}
    {u : ℕ} (hu_not : u ∉ v.ageUpdateSteps)
    {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hcoords' : ActiveCoordsStored d L B P'.activeHandles qMap' ws)
    (hlvl : LevelStoredInv n L B B_cert K_max P ltCoords qMap
              (chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩) v j ws)
    (hv_node : v.built.node = vecNodes ⟨j, hj⟩)
    (hr102 : ws.read (.heap 9 102) = opIsIns op)
    (hr103 : ws.read (.heap 9 103) = (hOp : ℤ))
    (hr104 : ws.read (.heap 9 104) = (j : ℤ))
    {jStar : ℕ} (hjS_le : jStar ≤ K_max + 1)
    (hr106 : ws.read (.heap 9 106) = (jStar : ℤ))
    (alive_j : Bool)
    (halive_spec : OpAliveSpec vecNodes j alive_j ws op)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    let ltCoords' : ℕ → EuclideanSpace ℝ (Fin d) := opNextLtCoords P ltCoords op
    let S_old := chainInput ltCoords' vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩
    let S_new := chainInput ltCoords' vecNodes (activeLifetimes P') ⟨j, Nat.lt_succ_of_lt hj⟩
    let v' : SyncLiveChainNode d (PosDimNodeData d s₀_d) :=
      open Classical in
      { v with ageUpdateSteps := if S_new ≠ S_old then insert u v.ageUpdateSteps else v.ageUpdateSteps }
    let trig_j : Prop := (1 / (4 * (s₀_d : ℝ))) * (v.birthPool.card : ℝ) / 16 < (v'.ageUpdateSteps.card : ℝ)
    let jStar' : ℕ := open Classical in if trig_j ∧ j < jStar then j else jStar
    ∃ (wsEnd : WordStore) (regsEnd : ℕ → ℤ) (alive_next : Bool),
      RegExec inp fd W C_cell C_bit (posDimStepBLevel d s₀_d L) ws regs wsEnd regsEnd
        (900 * L + 300 * d + 800) ((160 * L + 80 * d + 200) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap' S_new v' j wsEnd ∧
      wsEnd.read (.heap 9 104) = ((j + 1 : ℕ) : ℤ) ∧
      wsEnd.read (.heap 9 106) = (jStar' : ℤ) ∧
      OpAliveSpec vecNodes (j + 1) alive_next wsEnd op ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .heap 9 104 → loc ≠ .heap 9 105 → loc ≠ .heap 9 106 →
        loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j 0) →
        loc ≠ .heap 4 (((j * 2 ^ L + hOp : ℕ) : ℤ)) →
        loc ∉ treeSliceLocs L (2 * j + 2) →
        loc ∉ treeSliceLocs L (2 * j + 3) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  intro ltCoords' S_old S_new v' trig_j jStar'
  have hL1 : 1 ≤ L := by
    by_cases h0 : L = 0
    · rw [h0, pow_zero] at h2n_pow; clear * - hn h2n_pow; omega
    · exact Nat.pos_of_ne_zero h0
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hj_K : j ≤ K_max := le_trans (Nat.le_of_lt hj) hk_le
  have hj_bl : intBitLength (j : ℤ) ≤ W :=
    j_bl_of_level (d := d) (L := L) (K_max := K_max) (Nat.le_succ_of_le hj_K) (by clear * - hW; omega)
  have hhOp_bl : intBitLength (hOp : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hhOp_lt).trans (by clear * - hW; omega)
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl102 : intBitLength (102 : ℤ) ≤ W := by have : intBitLength (102 : ℤ) = 8 := (by decide); omega
  have hl103 : intBitLength (103 : ℤ) ≤ W := by have : intBitLength (103 : ℤ) = 8 := (by decide); omega
  have hl104 : intBitLength (104 : ℤ) ≤ W := by have : intBitLength (104 : ℤ) = 8 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil0], by linarith only [bs, hbCeil0]⟩
  have hisIns_bl : intBitLength (opIsIns op) ≤ W := by
    cases op <;> dsimp [opIsIns] <;> assumption
  -- Header loads: r5 := isIns, r6 := hOp, r7 := j, r14 := 1
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 102) (by decide) hl102
  set g1 := Function.update regs 10 102; have bg1 := hbnd.update (r := 10) (by decide) hl102
  have hg1_r : ws.read (.heap 9 (g1 10)) = opIsIns op := by
    simp only [g1, Function.update_self]; exact hr102
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 5) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact hisIns_bl)
  rw [hg1_r] at s2; set g2 := Function.update g1 5 (opIsIns op)
  have bg2 := bg1.update (r := 5) (by decide) hisIns_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 103) (by decide) hl103
  set g3 := Function.update g2 10 103; have bg3 := bg2.update (r := 10) (by decide) hl103
  have hg3_r : ws.read (.heap 9 (g3 10)) = (hOp : ℤ) := by simp only [g3, Function.update_self]; exact hr103
  have s4 := RegExec.load (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 6) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg3_r]; exact hhOp_bl)
  rw [hg3_r] at s4; set g4 := Function.update g3 6 (hOp : ℤ); have bg4 := bg3.update (r := 6) (by decide) hhOp_bl
  have s5 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 104) (by decide) hl104
  set g5 := Function.update g4 10 104; have bg5 := bg4.update (r := 10) (by decide) hl104
  have hg5_r : ws.read (.heap 9 (g5 10)) = (j : ℤ) := by simp only [g5, Function.update_self]; exact hr104
  have s6 := RegExec.load (inp := inp) hfd_le bg5 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 7) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg5_r]; exact hj_bl)
  rw [hg5_r] at s6; set g6 := Function.update g5 7 (j : ℤ); have bg6 := bg5.update (r := 7) (by decide) hj_bl
  have s7 := RegExec.lit (inp := inp) hfd_le bg6 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
  set g7 := Function.update g6 14 1; have bg7 := bg6.update (r := 14) (by decide) hl1
  -- Unified mid-state after `.ite (isIns == 1) (posDimStepBIns d L) (posDimStepBDel d L)`
  have hMid : ∃ (wsM : WordStore) (gM : ℕ → ℤ) (alive_next : Bool),
      RegExec inp fd W C_cell C_bit
        (.ite (.intEq (.readLocal 5 (.lit 0)) (.readLocal 14 (.lit 0))) (posDimStepBIns d L) (posDimStepBDel d L))
        ws g7 wsM gM (860 * L + 280 * d + 660) ((144 * L + 64 * d + 156) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsM ∧
      RegBounded W gM ∧
      PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap' S_new v' j wsM ∧
      v'.ageUpdateSteps.card ≤ 2 ^ L ∧
      wsM.read (.heap 9 104) = (j : ℤ) ∧
      wsM.read (.heap 9 106) = (jStar : ℤ) ∧
      OpAliveSpec vecNodes (j + 1) alive_next wsM op ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .heap 9 105 →
        loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j 0) →
        loc ≠ .heap 4 (((j * 2 ^ L + hOp : ℕ) : ℤ)) →
        loc ∉ treeSliceLocs L (2 * j + 2) →
        loc ∉ treeSliceLocs L (2 * j + 3) →
        (loc ∈ wsM.live ↔ loc ∈ ws.live) ∧ wsM.vals loc = ws.vals loc) := by
    cases op with
    | insert id extName pt =>
        rcases hop_spec with ⟨happ, hhNew_not, hhNew_in', hqNew, hqOld⟩
        rcases halive_spec with ⟨halive_iff0, hr105⟩
        have halive_iff : alive_j = true ↔ ∀ (i : ℕ) (hi : i < j),
            pt ∉ coreBall (vecNodes ⟨i, Nat.lt_trans hi hj⟩).o (vecNodes ⟨i, Nat.lt_trans hi hj⟩).V :=
          ⟨fun ht i hi => halive_iff0.mp ht i hi (Nat.le_of_lt hj),
           fun hall => halive_iff0.mpr (fun i hi _ => hall i hi)⟩
        obtain ⟨wsM, gM, sBr, hmM, bgM, hpreM, hage_leM, halive_next_iff, hr105_M, hunchM⟩ :=
          exec_posDimStepBInsLevel hd1 hs₀1 hn h2n_pow hB1 hBc1 hW hfd_le hwfP hwfP'
            happ hhOp_lt hhNew_not hqNew hqOld hk_le hj hu_not hmod hcCeil0 hbCeil0
            hcoords' hhNew_in' hlvl hv_node hr103 hr104 alive_j halive_iff hr105
            bg7 (by simp [g7, g6, g5, g4]) (by simp [g7, g6])
        have hg7_eq : g7 5 = g7 14 := by simp [g7, g6, g5, g4, g3, g2, opIsIns]
        have sBr' := sBr.weaken rfl rfl
          (u₂ := 850 * L + 280 * d + 640) (b₂ := (140 * L + 64 * d + 140) * W * W)
          (by clear * - hL1 hd1; omega) (by have h1 : 0 ≤ L * W * W := (by positivity); have h2 : 0 ≤ d * W * W := (by positivity); nlinarith only [hW40, hL1, hd1, h1, h2])
        have sIte := (RegExec.iteEq (tB := posDimStepBIns d L) (fB := posDimStepBDel d L)
          bg7 (a := 5) (b := 14) (by decide) (by decide) (by rw [if_pos hg7_eq]; exact sBr')).weaken
          rfl rfl (u₂ := 860 * L + 280 * d + 660) (b₂ := (144 * L + 64 * d + 156) * W * W)
          (by clear * - hL1 hd1; omega) (by have h1 : 0 ≤ L * W * W := (by positivity); have h2 : 0 ≤ d * W * W := (by positivity); nlinarith only [hW40, hL1, hd1, h1, h2])
        have hrM_104 : wsM.read (.heap 9 104) = (j : ℤ) := by
          rw [wordStore_read_eq_vals hmM.wf,
              (hunchM _ (by decide) (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
              ← wordStore_read_eq_vals hmod.wf]
          exact hr104
        have hrM_106 : wsM.read (.heap 9 106) = (jStar : ℤ) := by
          rw [wordStore_read_eq_vals hmM.wf,
              (hunchM _ (by decide) (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
              ← wordStore_read_eq_vals hmod.wf]
          exact hr106
        refine ⟨wsM, gM, _, sIte, hmM, bgM, hpreM, hage_leM, hrM_104, hrM_106,
          ⟨⟨fun ht i hi _ => halive_next_iff.mp ht i hi, fun hall => halive_next_iff.mpr (fun i hi => hall i hi hj)⟩, hr105_M⟩, fun loc hne105 hne30 _ hns2 _ => hunchM loc hne105 hne30 hns2⟩
    | delete id =>
        rcases hop_spec with ⟨happ, rfl, rfl⟩
        obtain ⟨ws1, gA, sTab4, hm1, bgA, htreeInt1, htab4_1, hunch1⟩ :=
          exec_posDimStepBDelTab4 hn h2n_pow (by clear * - hW; omega) hfd_le hwfP hwfP'
            happ hhOp_lt hj_K hmod hcCeil0 hbCeil0 hlvl
            bg7 (by simp [g7, g6, g5, g4]) (by simp [g7, g6])
        rcases hlvl.tree_Sj with ⟨rNum, rDen, htreeSj0, hSj_bnds0⟩
        have htreeSj1 : TreeStoredAt L (2 * j + 2)
            ((chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩).image (handleOfLifetime P))
            rNum rDen ws1 :=
          htreeSj0.unchanged (fun u hu f hf =>
            hunch1 _ (by intro h; cases h) (not_in_treeSlice_of_tid_ne hu hf (by omega)))
        have hr1_age : ws1.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) = (v.ageUpdateSteps.card : ℤ) := by
          rw [wordStore_read_eq_vals hm1.wf,
              (hunch1 _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
              ← wordStore_read_eq_vals hmod.wf]
          exact hlvl.read_age
        have hr1_103 : ws1.read (.heap 9 103) = (P.handleOfId id : ℤ) := by
          rw [wordStore_read_eq_vals hm1.wf,
              (hunch1 _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
              ← wordStore_read_eq_vals hmod.wf]
          exact hr103
        have hr1_104 : ws1.read (.heap 9 104) = (j : ℤ) := by
          rw [wordStore_read_eq_vals hm1.wf,
              (hunch1 _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
              ← wordStore_read_eq_vals hmod.wf]
          exact hr104
        have hage_lt : v.ageUpdateSteps.card < 2 ^ L :=
          age_card_lt_pow2 hs₀1 hn h2n_pow hlvl.hm_bounds.2 hlvl.hage_le
        obtain ⟨wsM, gM, sSj, hmM, bgM, hSj_imp⟩ :=
          exec_posDimStepBDelSj hs₀1 hn h2n_pow (by clear * - hW; omega) hfd_le hwfP hwfP'
            happ hhOp_lt hk_le hj hu_not hm1 hcCeil0 hbCeil0 hage_lt hr1_age htreeSj1 hSj_bnds0
            hr1_103 hr1_104 bgA
        obtain ⟨hage_relM, hage_leM, hrM_age, htreeSjM, hSj_bndsM, hunch2⟩ := hSj_imp hlvl.hage_rel
        have hg7_ne : g7 5 ≠ g7 14 := by simp [g7, g6, g5, g4, g3, g2, opIsIns]
        have sDel := (sTab4.seq sSj).weaken rfl rfl
          (u₂ := 850 * L + 280 * d + 640) (b₂ := (140 * L + 64 * d + 140) * W * W)
          (by omega)
          (by
            have h1 : 0 ≤ L * W * W := by positivity
            have h2 : 0 ≤ d * W * W := by positivity
            nlinarith only [hW40, hL1, hd1, h1, h2])
        have sIte := (RegExec.iteEq (tB := posDimStepBIns d L) (fB := posDimStepBDel d L)
          bg7 (a := 5) (b := 14) (by decide) (by decide) (by rw [if_neg hg7_ne]; exact sDel)).weaken
          rfl rfl (u₂ := 860 * L + 280 * d + 660) (b₂ := (144 * L + 64 * d + 156) * W * W)
          (by clear * - hL1 hd1; omega) (by have h1 : 0 ≤ L * W * W := (by positivity); have h2 : 0 ≤ d * W * W := (by positivity); nlinarith only [hW40, hL1, hd1, h1, h2])
        obtain ⟨_, _, hnext', _, hh_old⟩ := activeLifetimes_delete_spec hwfP hwfP' happ
        have hns_ge8 : 8 ≤ posNodeStride d L := by unfold posNodeStride; exact le_trans (Nat.le_add_right 8 (2 * d)) (Nat.le_add_right _ (2 ^ L))
        have hread3_pos : ∀ off : ℕ, 1 ≤ off → off < posNodeStride d L →
            wsM.read (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
              ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) := by
          intro off h1 hoff
          have hne0 : (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ≠
              .heap 3 (nodeCellAddr (posNodeStride d L) j 0) := by
            intro heq; injection heq with _ haddr
            have := (nodeCellAddr_inj hoff (by omega) haddr).2; omega
          rw [wordStore_read_eq_vals hmM.wf,
              (hunch2 _ hne0 (not_in_treeSlice_of_table_ne (by decide) _)).2,
              (hunch1 _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
              ← wordStore_read_eq_vals hmod.wf]
        have hgeomM : NodeGeomStored d (posNodeStride d L) B_cert j
            v.built.aux.oRat v.built.aux.V_num v.built.aux.V_den v.built.node.V wsM :=
          { hV_nn := hlvl.hgeom.hV_nn
            hV_den := hlvl.hgeom.hV_den
            hV_eq := hlvl.hgeom.hV_eq
            hVN_bl := hlvl.hgeom.hVN_bl
            hVD_bl := hlvl.hgeom.hVD_bl
            read_VN := (hread3_pos 3 (by decide) (by omega)).trans hlvl.hgeom.read_VN
            read_VD := (hread3_pos 4 (by decide) (by omega)).trans hlvl.hgeom.read_VD
            read_o := fun c => by
              have h6c : 6 + 2 * c.val < posNodeStride d L := by unfold posNodeStride; omega
              have h6c1 : 6 + 2 * c.val + 1 < posNodeStride d L := by unfold posNodeStride; omega
              dsimp only
              rw [hread3_pos _ (by omega) h6c, hread3_pos _ (by omega) h6c1]
              exact hlvl.hgeom.read_o c }
        have hpreM : PreTriggerLevelInv n L B B_cert K_max P' ltCoords qMap' S_new v' j wsM :=
          { hj_le := hlvl.hj_le
            hm_bounds := hlvl.hm_bounds
            hage_rel := hage_relM
            hnode_o := hlvl.hnode_o
            hnode_s := hlvl.hnode_s
            hnode_V := hlvl.hnode_V
            hcp := hlvl.hcp
            hk_bounds := hlvl.hk_bounds
            hk_ratio := hlvl.hk_ratio
            hbirth_adm := fun lt hlt => ⟨by rw [hnext']; exact (hlvl.hbirth_adm lt hlt).1, (hlvl.hbirth_adm lt hlt).2⟩
            hgeom := hgeomM
            read_age := hrM_age
            read_mbirth := (hread3_pos 1 (by decide) (by omega)).trans hlvl.read_mbirth
            read_kblk := (hread3_pos 2 (by decide) (by omega)).trans hlvl.read_kblk
            hbh_lt := hlvl.hbh_lt
            hbh_inj := hlvl.hbh_inj
            hblt_mem := fun b t => ⟨(hlvl.hblt_mem b t).1, by rw [hnext']; exact (hlvl.hblt_mem b t).2⟩
            hblt_inj := hlvl.hblt_inj
            hbh_active_sync := fun b t hm' => (hh_old _ hm').trans (hlvl.hbh_active_sync b t (by
              have hact' := (activeLifetimes_delete_spec hwfP hwfP' happ).2.1
              rw [hact'] at hm'; exact Finset.mem_of_mem_erase hm'))
            read_bh := fun b t => by
              have h1 : b.val * s₀_d + t.val < v.built.aux.k_blk * s₀_d := by
                have hm : (b.val + 1) * s₀_d ≤ v.built.aux.k_blk * s₀_d := Nat.mul_le_mul_right _ (Nat.succ_le_of_lt b.isLt)
                have ha : b.val * s₀_d + t.val < (b.val + 1) * s₀_d := by
                  rw [add_mul, one_mul]; exact Nat.add_lt_add_left t.isLt _
                exact lt_of_lt_of_le ha hm
              have h2 := hlvl.hk_bounds.2; have h3 := hlvl.hm_bounds.2
              have hoff : 6 + 2 * d + (b.val * s₀_d + t.val) < posNodeStride d L := by
                unfold posNodeStride; clear * - h1 h2 h3 h2n_pow hn; omega
              exact (hread3_pos _ (by omega) hoff).trans (hlvl.read_bh b t)
            unused_tab3 := fun off hlo hhi hm_in => by
              have hne0 : (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ≠
                  .heap 3 (nodeCellAddr (posNodeStride d L) j 0) := by
                intro heq; injection heq with _ haddr
                have := (nodeCellAddr_inj hhi (by omega) haddr).2; omega
              have hm1' := (hunch2 _ hne0 (not_in_treeSlice_of_table_ne (by decide) _)).1.mp hm_in
              have hm0' := (hunch1 _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).1.mp hm1'
              exact hlvl.unused_tab3 off hlo hhi hm0'
            hcerts := hlvl.hcerts
            tree_Sj := ⟨rNum, rDen, htreeSjM, hSj_bndsM⟩
            tab4_spec := fun h hh => by
              have u2 := hunch2 (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)))
                (by intro hc; cases hc) (not_in_treeSlice_of_table_ne (by decide) _)
              rcases htab4_1 h hh with ⟨b, t, hm', hbh, hlv, hvl⟩ | ⟨hno, hnlv⟩
              · exact Or.inl ⟨b, t, hm', hbh, u2.1.mpr hlv, u2.2.trans hvl⟩
              · exact Or.inr ⟨hno, fun h_in => hnlv (u2.1.mp h_in)⟩
            tree_intact_raw := htreeInt1.unchanged (fun u hu f hf =>
              hunch2 _ (by intro hc; cases hc) (not_in_treeSlice_of_tid_ne hu hf (by omega))) }
        have hrM_104 : wsM.read (.heap 9 104) = (j : ℤ) := by
          rw [wordStore_read_eq_vals hmM.wf,
              (hunch2 _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
              ← wordStore_read_eq_vals hm1.wf]
          exact hr1_104
        have hrM_106 : wsM.read (.heap 9 106) = (jStar : ℤ) := by
          rw [wordStore_read_eq_vals hmM.wf,
              (hunch2 _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
              (hunch1 _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
              ← wordStore_read_eq_vals hmod.wf]
          exact hr106
        refine ⟨wsM, gM, false, sIte, hmM, bgM, hpreM, hage_leM, hrM_104, hrM_106, trivial, ?_⟩
        intro loc _ hne30 hne4 hns2 hns3
        have u2 := hunch2 loc hne30 hns2
        have u1 := hunch1 loc hne4 hns3
        exact ⟨u2.1.trans u1.1, u2.2.trans u1.2⟩
  obtain ⟨wsM, gM, alive_next, s8, hmM, bgM, hpreM, hage_leM, hrM_104, hrM_106, halive_M, hunchM⟩ := hMid
  -- Run `rLit 10 104; rLoad 7 9 10; checkLevelTriggerStmt s₀_d (posNodeStride d L)`
  have s9 := RegExec.lit (inp := inp) hfd_le bgM (sp_ok hmM).1 (sp_ok hmM).2 (dst := 10) (c := 104) (by decide) hl104
  set g8 := Function.update gM 10 104; have bg8 := bgM.update (r := 10) (by decide) hl104
  have hg8_r : wsM.read (.heap 9 (g8 10)) = (j : ℤ) := by simp only [g8, Function.update_self]; exact hrM_104
  have s10 := RegExec.load (inp := inp) hfd_le bg8 (sp_ok hmM).1 (sp_ok hmM).2 (dst := 7) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg8_r]; exact hj_bl)
  rw [hg8_r] at s10; set g9 := Function.update g8 7 (j : ℤ); have bg9 := bg8.update (r := 7) (by decide) hj_bl
  have hm_le_pow : v.birthPool.card ≤ 2 ^ L := by
    have := hlvl.hm_bounds.2; clear * - this hn h2n_pow; omega
  obtain ⟨wsEnd, regsEnd, s11, hmEnd, bgEnd, hrEnd_104, hrEnd_106, hunchTr⟩ :=
    exec_checkLevelTriggerStmt (inp := inp) (fd := fd) hfd_le hmM hcCeil0 hbCeil0
      hs₀1 hj_K hjS_le hage_leM hm_le_pow (by clear * - hW; omega)
      (mem_posDimWriteLocs_tab9 (by decide)) (mem_posDimWriteLocs_tab9 (by decide))
      hpreM.read_age hpreM.read_mbirth hrM_106 bg9 (by simp [g9])
  have hpreEnd : PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap' S_new v' j wsEnd :=
    hpreM.unchanged hmM.wf hmEnd.wf
      (fun off _ => hunchTr _ (by intro h; cases h) (by intro h; cases h))
      (fun h' _ => hunchTr _ (by intro h; cases h) (by intro h; cases h))
      (fun u _ f _ => hunchTr _ (by intro h; cases h) (by intro h; cases h))
      (fun u _ f _ => hunchTr _ (by intro h; cases h) (by intro h; cases h))
  have halive_End : OpAliveSpec vecNodes (j + 1) alive_next wsEnd op := by
    cases op with
    | insert _ _ _ =>
        refine ⟨halive_M.1, ?_⟩
        rw [wordStore_read_eq_vals hmEnd.wf, (hunchTr _ (by decide) (by decide)).2, ← wordStore_read_eq_vals hmM.wf]
        exact halive_M.2
    | delete _ => trivial
  have hLWW : 0 ≤ L * W * W := by positivity
  have hdWW : 0 ≤ d * W * W := by positivity
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq s11)))))))))).weaken
    rfl rfl (u₂ := 900 * L + 300 * d + 800) (b₂ := (160 * L + 80 * d + 200) * W * W)
    (by clear * - hL1 hd1; omega) (by nlinarith only [hW40, hL1, hd1, hLWW, hdWW])
  refine ⟨wsEnd, regsEnd, alive_next, sTot, hmEnd, bgEnd, hpreEnd, hrEnd_104, hrEnd_106, halive_End, ?_⟩
  intro loc hne104 hne105 hne106 hne30 hne4 hns2 hns3
  have uT := hunchTr loc hne104 hne106
  have uM := hunchM loc hne105 hne30 hne4 hns2 hns3
  exact ⟨uT.1.trans uM.1, uT.2.trans uM.2⟩

end UL.C12LVE
