import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4a_ChainInv
set_option autoImplicit false
set_option maxHeartbeats 800000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Empty-Tree Live-Cell Characterization & `minPopState` / `minPopElem` -/

theorem TreeStoredAt.empty_no_live {L tid : ℕ} {rNum rDen : ℕ → ℤ} {ws : WordStore}
    (ht : TreeStoredAt L tid ∅ rNum rDen ws) :
    ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∉ ws.live := by
  intro u hu f hf
  by_cases hu0 : u = 0
  · subst hu0; exact ht.u0_empty f hf
  · let m := Nat.log 2 u
    have hm_lo : 2 ^ m ≤ u := Nat.pow_log_le_self 2 hu0
    have hm_hi : u < 2 ^ (m + 1) := Nat.lt_pow_succ_log_self (by decide) u
    have hm_le : m ≤ L := by
      by_contra hgt
      have hpow : 2 ^ (L + 1) ≤ 2 ^ m := Nat.pow_le_pow_right (by decide) (by clear * - hgt; omega)
      clear * - hu hm_lo hpow; omega
    let k := L - m
    have hk_le : k ≤ L := Nat.sub_le L m
    have hsub_eq : L - k = m := by dsimp [k]; clear * - hm_le; omega
    let off := u - 2 ^ m
    have hoff_lt : off < 2 ^ (L - k) := by
      rw [hsub_eq]
      have hp : 2 ^ (m + 1) = 2 ^ m + 2 ^ m := by rw [pow_succ]; ring
      dsimp [off]; clear * - hm_lo hm_hi hp; omega
    have hidx_eq : treeIdx L k off = u := by
      unfold treeIdx
      rw [hsub_eq]
      dsimp [off]; clear * - hm_lo; omega
    have hcnt0 : (treeNodeVal ∅ rNum rDen k off).1 = 0 := by
      rw [treeNodeVal_cnt]
      simp [treeSubSet]
    have hnode := (ht.nodes k hk_le off hoff_lt).1 hcnt0 f hf
    rwa [hidx_eq] at hnode

theorem TreeStoredAt.reweight_empty {L tid : ℕ} {rNum₁ rDen₁ : ℕ → ℤ} (rNum₂ rDen₂ : ℕ → ℤ)
    {ws : WordStore} (ht : TreeStoredAt L tid ∅ rNum₁ rDen₁ ws) :
    TreeStoredAt L tid ∅ rNum₂ rDen₂ ws :=
  TreeStoredAt.empty L tid rNum₂ rDen₂ ht.empty_no_live

noncomputable def minPopState (S : Finset ℕ) : ℕ → Finset ℕ
  | 0 => S
  | i + 1 =>
      let rem := minPopState S i
      if h : rem.Nonempty then rem.erase (rem.min' h) else ∅

noncomputable def minPopElem (S : Finset ℕ) (i : ℕ) : ℕ :=
  let rem := minPopState S i
  if h : rem.Nonempty then rem.min' h else 0

theorem minPopState_subset (S : Finset ℕ) : ∀ i : ℕ, minPopState S i ⊆ S
  | 0 => Finset.Subset.rfl
  | i + 1 => by
      dsimp only [minPopState]
      split_ifs with hne
      · exact (Finset.erase_subset _ _).trans (minPopState_subset S i)
      · exact Finset.empty_subset S

theorem minPopState_card (S : Finset ℕ) :
    ∀ {i : ℕ}, i ≤ S.card → (minPopState S i).card = S.card - i
  | 0, _ => by simp [minPopState]
  | i + 1, hi => by
      have ih := minPopState_card S (Nat.le_of_succ_le hi)
      have hpos : 0 < (minPopState S i).card := by clear * - hi ih; omega
      have hne : (minPopState S i).Nonempty := Finset.card_pos.mp hpos
      dsimp only [minPopState]
      rw [dif_pos hne, Finset.card_erase_of_mem (Finset.min'_mem _ hne), ih]
      clear * - hi; omega

theorem minPopState_end (S : Finset ℕ) : minPopState S S.card = ∅ := by
  apply Finset.card_eq_zero.mp
  rw [minPopState_card S le_rfl, Nat.sub_self]

theorem minPopElem_step {S : Finset ℕ} {i : ℕ} (hi : i < S.card) :
    (minPopState S i).Nonempty ∧
    minPopElem S i = (minPopState S i).min'
      (Finset.card_pos.mp (by have := minPopState_card S (Nat.le_of_lt hi); omega)) ∧
    minPopElem S i ∈ minPopState S i ∧
    minPopElem S i ∈ S ∧
    minPopState S (i + 1) = (minPopState S i).erase (minPopElem S i) := by
  have hcard := minPopState_card S (Nat.le_of_lt hi)
  have hne : (minPopState S i).Nonempty := Finset.card_pos.mp (by clear * - hi hcard; omega)
  have helem : minPopElem S i = (minPopState S i).min' hne := by
    unfold minPopElem; rw [dif_pos hne]
  have hmem : minPopElem S i ∈ minPopState S i := by
    rw [helem]; exact Finset.min'_mem _ hne
  refine ⟨hne, helem, hmem, minPopState_subset S i hmem, ?_⟩
  dsimp only [minPopState]
  rw [dif_pos hne, helem]

theorem minPopElem_not_mem_later {S : Finset ℕ} {i : ℕ} (hi : i < S.card) :
    ∀ {j : ℕ}, i < j → minPopElem S i ∉ minPopState S j := by
  intro j hij
  induction j with
  | zero => omega
  | succ m ih =>
      rcases Nat.lt_succ_iff_lt_or_eq.mp hij with hlt | rfl
      · intro hm
        have hsub : minPopState S (m + 1) ⊆ minPopState S m := by
          dsimp only [minPopState]
          by_cases hne : (minPopState S m).Nonempty
          · rw [dif_pos hne]; exact Finset.erase_subset _ _
          · rw [dif_neg hne]; exact Finset.empty_subset _
        exact ih hlt (hsub hm)
      · rw [(minPopElem_step hi).2.2.2.2]
        exact Finset.notMem_erase _ _

theorem minPopElem_injOn (S : Finset ℕ) :
    Set.InjOn (minPopElem S) (Finset.range S.card : Set ℕ) := by
  intro i₁ h₁ i₂ h₂ heq
  simp only [Finset.mem_coe, Finset.mem_range] at h₁ h₂
  rcases lt_trichotomy i₁ i₂ with hlt | rfl | hgt
  · exfalso
    have hm := (minPopElem_step h₂).2.2.1
    rw [← heq] at hm
    exact minPopElem_not_mem_later h₁ hlt hm
  · rfl
  · exfalso
    have hm := (minPopElem_step h₁).2.2.1
    rw [heq] at hm
    exact minPopElem_not_mem_later h₂ hgt hm

theorem image_minPopElem_eq (S : Finset ℕ) :
    (Finset.range S.card).image (minPopElem S) = S := by
  apply Finset.eq_of_subset_of_card_le
  · intro h hh
    simp only [Finset.mem_image, Finset.mem_range] at hh
    rcases hh with ⟨i, hi, rfl⟩
    exact (minPopElem_step hi).2.2.2.1
  · rw [Finset.card_image_of_injOn (minPopElem_injOn S), Finset.card_range]

/-! ### 2. `clearTreeRegs L`, `popTreeToBufRegs L`, `insertBufToUnitTreeRegs L`, `freeBufRegs` -/

def clearTreeStepStmt (L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 111)
  (.seq (rLoad 0 9 10)
  (.seq (treeMinElemRegs L)
  (.seq (rLit 2 0)
  (.seq (rLit 3 0)
  (.seq (rLit 4 0)
        (treeSetLeafRegs L))))))

def clearTreeRegs (L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 111)
  (.seq (rStore 9 10 0)
  (.seq (treeReadRootRegs L)
  (.seq (.repeatN (.readLocal 1 (.lit 0)) (clearTreeStepStmt L))
  (.seq (rLit 10 111)
        (rFree 9 10)))))

private theorem exec_clearTreeStepStmt {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid B_r : ℕ} (hL1 : 1 ≤ L) (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 20 ≤ W)
    (hSubTree : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ S_write)
    {S : Finset ℕ} {rNum rDen : ℕ → ℤ} {i : ℕ} (hi : i < S.card)
    (hS_bnds : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r)
    (htree : TreeStoredAt L tid (minPopState S i) rNum rDen ws)
    (hr111 : ws.read (.heap 9 111) = (tid : ℤ))
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (clearTreeStepStmt L) ws regs wsEnd regsEnd
        (420 * L + 240) ((70 * L + 48) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L tid (minPopState S (i + 1)) rNum rDen wsEnd ∧
      wsEnd.read (.heap 9 111) = (tid : ℤ) ∧
      (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl111 : intBitLength (111 : ℤ) ≤ W := by have : intBitLength (111 : ℤ) = 8 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have htid_bl : intBitLength (tid : ℤ) ≤ W := by
    have := intBitLength_ofNat_le tid; clear * - this hW; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  obtain ⟨hne, helem, hmem_i, hmem_S, hnext⟩ := minPopElem_step hi
  have hh_lt : minPopElem S i < 2 ^ L := (hS_bnds _ hmem_S).1
  have hRem_bnds : ∀ h ∈ minPopState S i, h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r :=
    fun h hm => hS_bnds h (minPopState_subset S i hm)
  have hNext_bnds : ∀ h ∈ minPopState S (i + 1), h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r :=
    fun h hm => hS_bnds h (minPopState_subset S (i + 1) hm)
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 111) (by decide) hl111
  set g1 := Function.update regs 10 111; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hl111
  have hg1_r : ws.read (.heap 9 (g1 10)) = (tid : ℤ) := by simp only [g1, Function.update_self]; exact hr111
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact htid_bl)
  rw [hg1_r] at s2
  set g2 := Function.update g1 0 (tid : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 0) (by decide) htid_bl
  obtain ⟨g3, s3, bg3, g3_0, g3_1, _⟩ :=
    exec_treeMinElemRegs (inp := inp) (fd := fd) hfd_le (sp_ok hmod).1 (sp_ok hmod).2 hL1 hBr1
      (by clear * - hW; omega) htree hRem_bnds hne bg2 (by simp [g2])
  rw [← helem] at g3_1
  have s4 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 2) (c := 0) (by decide) hl0
  set g4 := Function.update g3 2 0; have bg4 : RegBounded W g4 := bg3.update (r := 2) (by decide) hl0
  have s5 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 3) (c := 0) (by decide) hl0
  set g5 := Function.update g4 3 0; have bg5 : RegBounded W g5 := bg4.update (r := 3) (by decide) hl0
  have s6 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 4) (c := 0) (by decide) hl0
  set g6 := Function.update g5 4 0; have bg6 : RegBounded W g6 := bg5.update (r := 4) (by decide) hl0
  have hPathSubSlice : treePathLocs L tid (minPopElem S i) ⊆ treeSliceLocs L tid := by
    intro loc hloc
    simp only [treePathLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hloc
    rcases hloc with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
    have hoff_lt : minPopElem S i / 2 ^ k < 2 ^ (L - k) := by
      rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add, Nat.sub_add_cancel (by clear * - hk; omega)]
      exact hh_lt
    unfold treeSliceLocs
    exact Finset.mem_image.mpr ⟨(treeIdx L k (minPopElem S i / 2 ^ k), f),
      Finset.mem_product.mpr ⟨Finset.mem_range.mpr (treeIdx_bounds (by clear * - hk; omega) hoff_lt).2,
        Finset.mem_range.mpr hf⟩, rfl⟩
  have hPathSub : treePathLocs L tid (minPopElem S i) ⊆ S_write := by
    intro loc hloc
    have hs := hPathSubSlice hloc
    simp only [treeSliceLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hs
    rcases hs with ⟨⟨u, f⟩, ⟨hu, hf⟩, rfl⟩
    exact hSubTree u hu f hf
  obtain ⟨wsEnd, g7, s7, hm_End, bg7, htreeEnd, hunch⟩ :=
    exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hmod hcCeil hbCeil hL1 hh_lt hBr1
      (by clear * - hW; omega) hPathSub htree hNext_bnds
      (fun h hne_h => by rw [hnext, Finset.mem_erase]; simp [hne_h])
      (fun _ _ => rfl) (fun _ _ => rfl) false
      (by rw [hnext]; simp) bg6
      (by simp [g6, g5, g4, g3_0])
      (by simp [g6, g5, g4, g3_1])
      (by simp [g6, g5, g4])
      (by intro h; cases h) (by intro h; cases h)
  have hn111_slice : (.heap 9 111 : RAMCellLoc) ∉ treeSliceLocs L tid := by
    intro hm; simp only [treeSliceLocs, Finset.mem_image] at hm; rcases hm with ⟨_, _, h⟩; cases h
  have hrEnd_111 : wsEnd.read (.heap 9 111) = (tid : ℤ) := by
    rw [wordStore_read_eq_vals hm_End.wf, (hunch _ (fun hp => hn111_slice (hPathSubSlice hp))).2,
        ← wordStore_read_eq_vals hmod.wf]
    exact hr111
  have hLWW : 0 ≤ L * W * W := by positivity
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq s7)))))).weaken rfl rfl
    (u₂ := 420 * L + 240) (b₂ := (70 * L + 48) * W * W)
    (by clear * -; omega) (by nlinarith only [hW20, hL1, hLWW])
  exact ⟨wsEnd, g7, sTot, hm_End, bg7, htreeEnd, hrEnd_111,
    fun loc hns => hunch loc (fun hp => hns (hPathSubSlice hp))⟩

theorem exec_clearTreeRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid B_r : ℕ} (hL1 : 1 ≤ L) (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 20 ≤ W)
    (hSubTree : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ S_write)
    (hSub111 : (.heap 9 111 : RAMCellLoc) ∈ S_write)
    (hn111 : (.heap 9 111 : RAMCellLoc) ∉ ws.live)
    {S : Finset ℕ} {rNum rDen : ℕ → ℤ}
    (htree : TreeStoredAt L tid S rNum rDen ws)
    (hS_bnds : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (tid : ℤ)) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (clearTreeRegs L) ws regs wsEnd regsEnd
        ((S.card + 1) * (420 * L + 260)) ((S.card + 1) * (70 * L + 60) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L tid ∅ (fun _ => 0) (fun _ => 1) wsEnd ∧
      (∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∉ wsEnd.live) ∧
      (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hl111 : intBitLength (111 : ℤ) ≤ W := by have : intBitLength (111 : ℤ) = 8 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have hloc111 : (RAMCellLoc.heap 9 111).bitLength ≤ W := by
    have : (RAMCellLoc.heap 9 111).bitLength = 12 := (by decide); omega
  have htid_bl : intBitLength (tid : ℤ) ≤ W := by
    have := intBitLength_ofNat_le tid; clear * - this hW; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 111) (by decide) hl111
  set g1 := Function.update regs 10 111; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hl111
  have hm_w1 : ModifiedOnBounded ws₀ S_write W (ws.write (.heap 9 (g1 10)) (g1 0)) := by
    simpa [g1, hr0] using hmod.write hSub111 (tid : ℤ) hloc111 htid_bl
  have s2 := RegExec.store (inp := inp) hfd_le bg1 (table := 9) (addr := 10) (val := 0) (by decide) (by decide) hn9
    (sp_ok hm_w1).1 (sp_ok hm_w1).2
  set ws1 := ws.write (.heap 9 111) (tid : ℤ)
  have hw1_eq : ws.write (.heap 9 (g1 10)) (g1 0) = ws1 := by simp [ws1, g1, hr0]
  rw [hw1_eq] at s2 hm_w1
  have htree1 : TreeStoredAt L tid S rNum rDen ws1 :=
    htree.unchanged (fun u _ f _ => by simp [ws1, WordStore.write])
  obtain ⟨g2, s3, bg2, _, g2_1, _⟩ :=
    exec_treeReadRootRegs (inp := inp) (fd := fd) hfd_le (sp_ok hm_w1).1 (sp_ok hm_w1).2 hBr1
      (by clear * - hW; omega) htree1 hS_bnds bg1 (by simp [g1, hr0])
  -- Build loop sequence `i = 0 .. S.card`
  let LoopInv (i : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
    ModifiedOnBounded ws₀ S_write W w ∧
    RegBounded W g ∧
    (i ≤ S.card → TreeStoredAt L tid (minPopState S i) rNum rDen w) ∧
    w.read (.heap 9 111) = (tid : ℤ) ∧
    (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid →
      (loc ∈ w.live ↔ loc ∈ ws1.live) ∧ w.vals loc = ws1.vals loc)
  have hLoop : ∀ m ≤ S.card, ∃ (wsSeq : ℕ → WordStore) (regSeq : ℕ → ℕ → ℤ),
      wsSeq 0 = ws1 ∧ regSeq 0 = g2 ∧
      LoopInv m (wsSeq m) (regSeq m) ∧
      (∀ i < m, RegExec inp fd W C_cell C_bit (clearTreeStepStmt L)
        (wsSeq i) (regSeq i) (wsSeq (i + 1)) (regSeq (i + 1)) (420 * L + 240) ((70 * L + 48) * W * W)) := by
    intro m hm
    induction m with
    | zero =>
        refine ⟨fun _ => ws1, fun _ => g2, rfl, rfl,
          ⟨hm_w1, bg2, fun _ => htree1, by simp [ws1, WordStore.read, WordStore.write], fun _ _ => ⟨Iff.rfl, rfl⟩⟩,
          fun i hi => absurd hi (Nat.not_lt_zero _)⟩
    | succ k ih =>
        obtain ⟨wS, rS, hw0, hr0_eq, ⟨hmk, bgk, htk, hr111_k, hunch_k⟩, hsteps⟩ := ih (Nat.le_of_succ_le hm)
        obtain ⟨wNext, gNext, hstep_k, hmN, bgN, htN, hr111_N, hunch_N⟩ :=
          exec_clearTreeStepStmt (inp := inp) (fd := fd) hfd_le hmk hcCeil hbCeil hL1 hBr1 hW hSubTree
            (Nat.lt_of_succ_le hm) hS_bnds (htk (Nat.le_of_succ_le hm)) hr111_k bgk
        refine ⟨fun i => if i ≤ k then wS i else wNext,
                fun i => if i ≤ k then rS i else gNext,
                by simp [hw0], by simp [hr0_eq], ?_, ?_⟩
        · simp only [show ¬ (k + 1 ≤ k) by omega, ↓reduceIte]
          refine ⟨hmN, bgN, fun _ => htN, hr111_N, fun loc hns => ?_⟩
          exact ⟨(hunch_N loc hns).1.trans (hunch_k loc hns).1,
                 (hunch_N loc hns).2.trans (hunch_k loc hns).2⟩
        · intro i hi
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
          · simp only [Nat.le_of_lt hlt, Nat.succ_le_of_lt hlt, ↓reduceIte]
            exact hsteps i hlt
          · simp only [le_rfl, show ¬ (i + 1 ≤ i) by omega, ↓reduceIte]
            exact hstep_k
  obtain ⟨wsSeq, regSeq, hw0, hrg0, ⟨hmM, bgM, htM, _, hunchM⟩, hstepsM⟩ := hLoop S.card le_rfl
  have s4 := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (cntReg := 1) (by decide) S.card wsSeq regSeq (by rw [hrg0]; exact g2_1) (by rw [hrg0]; exact bg2) hstepsM
  rw [hw0, hrg0] at s4
  have s5 := RegExec.lit (inp := inp) hfd_le bgM (sp_ok hmM).1 (sp_ok hmM).2 (dst := 10) (c := 111) (by decide) hl111
  set gEnd := Function.update (regSeq S.card) 10 111
  have bgEnd : RegBounded W gEnd := bgM.update (r := 10) (by decide) hl111
  have s6 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsSeq S.card)
    bgEnd (table := 9) (addr := 10) (by decide) hn9
  set wsEnd := (wsSeq S.card).free (.heap 9 111)
  have hwE_eq : (wsSeq S.card).free (.heap 9 (gEnd 10)) = wsEnd := by simp [wsEnd, gEnd]
  rw [hwE_eq] at s6
  have hmEnd : ModifiedOnBounded ws₀ S_write W wsEnd := hmM.free hSub111
  have htreeEmpty0 : TreeStoredAt L tid ∅ rNum rDen wsEnd := by
    have ht0 := htM le_rfl
    rw [minPopState_end S] at ht0
    exact ht0.unchanged (fun u _ f _ => by simp [wsEnd, WordStore.free])
  have htreeEmpty := htreeEmpty0.reweight_empty (fun _ => 0) (fun _ => 1)
  have hLWW : 0 ≤ L * W * W := by positivity
  have hSWW : 0 ≤ S.card * (L * W * W) := by positivity
  have hSW : 0 ≤ S.card * (W * W) := by positivity
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq s6))))).weaken rfl rfl
    (u₂ := (S.card + 1) * (420 * L + 260)) (b₂ := (S.card + 1) * (70 * L + 60) * W * W)
    (by nlinarith only [hL1])
    (by
      have h1 : S.card * ((70 * L + 48) * W * W) + W + 12 + (16 * W * W + (2 * W + 16) + (5 * W + 24) + (2 * W + 16) + (3 * W + 16))
          ≤ (S.card + 1) * (70 * L + 60) * W * W := by
        nlinarith only [hW20, hL1, hLWW, hSWW, hSW]
      linarith only [h1])
  refine ⟨wsEnd, gEnd, sTot, hmEnd, bgEnd, htreeEmpty, htreeEmpty.empty_no_live, ?_⟩
  intro loc hns
  by_cases h111 : loc = .heap 9 111
  · subst h111
    exact ⟨by simp [wsEnd, WordStore.free, hn111],
           by simp [wsEnd, WordStore.free, hmod.wf _ hn111]⟩
  · have uM := hunchM loc hns
    exact ⟨by simp [wsEnd, WordStore.free, h111, uM.1, ws1, WordStore.write],
           by simp [wsEnd, WordStore.free, Function.update_of_ne h111, uM.2, ws1, WordStore.write]⟩

def popTreeStepStmt (L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 111)
  (.seq (rLoad 0 9 10)
  (.seq (treeMinElemRegs L)
  (.seq (rLit 10 112)
  (.seq (rLoad 13 9 10)
  (.seq (rStore 8 13 1)
  (.seq (rLit 14 1)
  (.seq (rAdd 13 13 14)
  (.seq (rStore 9 10 13)
  (.seq (rLit 2 0)
  (.seq (rLit 3 0)
  (.seq (rLit 4 0)
        (treeSetLeafRegs L))))))))))))

def popTreeToBufRegs (L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 111)
  (.seq (rStore 9 10 0)
  (.seq (treeReadRootRegs L)
  (.seq (rLit 10 110)
  (.seq (rStore 9 10 1)
  (.seq (rLit 10 112)
  (.seq (rLit 13 0)
  (.seq (rStore 9 10 13)
  (.seq (.repeatN (.readLocal 1 (.lit 0)) (popTreeStepStmt L))
  (.seq (rLit 10 111)
  (.seq (rFree 9 10)
  (.seq (rLit 10 112)
        (rFree 9 10))))))))))))

private theorem exec_popTreeStepStmt {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid B_r : ℕ} (hL1 : 1 ≤ L) (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 20 ≤ W)
    (hSubTree : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ S_write)
    (hSub8 : ∀ (k : ℕ), k < 2 ^ L → (.heap 8 (k : ℤ) : RAMCellLoc) ∈ S_write)
    (hSub112 : (.heap 9 112 : RAMCellLoc) ∈ S_write)
    {S : Finset ℕ} {rNum rDen : ℕ → ℤ} {i : ℕ} (hi : i < S.card)
    (hS_bnds : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r)
    (htree : TreeStoredAt L tid (minPopState S i) rNum rDen ws)
    (hr111 : ws.read (.heap 9 111) = (tid : ℤ))
    (hr112 : ws.read (.heap 9 112) = (i : ℤ))
    (hbuf : ∀ k < i, ws.read (.heap 8 (k : ℤ)) = (minPopElem S k : ℤ))
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (popTreeStepStmt L) ws regs wsEnd regsEnd
        (460 * L + 300) ((76 * L + 80) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L tid (minPopState S (i + 1)) rNum rDen wsEnd ∧
      wsEnd.read (.heap 9 111) = (tid : ℤ) ∧
      wsEnd.read (.heap 9 112) = ((i + 1 : ℕ) : ℤ) ∧
      (∀ k < i + 1, wsEnd.read (.heap 8 (k : ℤ)) = (minPopElem S k : ℤ)) ∧
      (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid →
        loc ≠ .heap 8 (i : ℤ) → loc ≠ .heap 9 112 →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hScard_lt : S.card ≤ 2 ^ L := by
    calc S.card ≤ (Finset.range (2 ^ L)).card :=
        Finset.card_le_card (fun h hh => Finset.mem_range.mpr (hS_bnds h hh).1)
      _ = 2 ^ L := Finset.card_range _
  have hi_pow : i < 2 ^ L := lt_of_lt_of_le hi hScard_lt
  have hi1_pow : i + 1 ≤ 2 ^ L := by clear * - hi_pow; omega
  have hi_bl : intBitLength (i : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hi_pow).trans (by clear * - hW; omega)
  have hi1_bl : intBitLength ((i + 1 : ℕ) : ℤ) ≤ W := by
    have : i + 1 < 2 ^ (L + 1) := by rw [pow_succ]; clear * - hi1_pow; omega
    exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl111 : intBitLength (111 : ℤ) ≤ W := by have : intBitLength (111 : ℤ) = 8 := (by decide); omega
  have hl112 : intBitLength (112 : ℤ) ≤ W := by have : intBitLength (112 : ℤ) = 8 := (by decide); omega
  have hn8 : natBitLength 8 ≤ W := by have : natBitLength 8 = 4 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have hloc8 : (RAMCellLoc.heap 8 (i : ℤ)).bitLength ≤ W := by
    dsimp [RAMCellLoc.bitLength]
    have h8 : natBitLength 8 = 4 := by decide
    have hib := nat_lt_pow2_bitLength_le hi_pow
    clear * - h8 hib hW; omega
  have hloc112 : (RAMCellLoc.heap 9 112).bitLength ≤ W := by
    have : (RAMCellLoc.heap 9 112).bitLength = 12 := (by decide); omega
  have htid_bl : intBitLength (tid : ℤ) ≤ W := by
    have := intBitLength_ofNat_le tid; clear * - this hW; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  obtain ⟨hne, helem, _, hmem_S, hnext⟩ := minPopElem_step hi
  have hh_lt : minPopElem S i < 2 ^ L := (hS_bnds _ hmem_S).1
  have hh_bl : intBitLength (minPopElem S i : ℤ) ≤ W :=
    (nat_lt_pow2_bitLength_le hh_lt).trans (by clear * - hW; omega)
  have hRem_bnds : ∀ h ∈ minPopState S i, h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r :=
    fun h hm => hS_bnds h (minPopState_subset S i hm)
  have hNext_bnds : ∀ h ∈ minPopState S (i + 1), h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r :=
    fun h hm => hS_bnds h (minPopState_subset S (i + 1) hm)
  -- 1. Load tid and treeMinElemRegs L
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 111) (by decide) hl111
  set g1 := Function.update regs 10 111; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hl111
  have hg1_r : ws.read (.heap 9 (g1 10)) = (tid : ℤ) := by simp only [g1, Function.update_self]; exact hr111
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact htid_bl)
  rw [hg1_r] at s2
  set g2 := Function.update g1 0 (tid : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 0) (by decide) htid_bl
  obtain ⟨g3, s3, bg3, g3_0, g3_1, _⟩ :=
    exec_treeMinElemRegs (inp := inp) (fd := fd) hfd_le (sp_ok hmod).1 (sp_ok hmod).2 hL1 hBr1
      (by clear * - hW; omega) htree hRem_bnds hne bg2 (by simp [g2])
  rw [← helem] at g3_1
  -- 2. Load i from heap 9 112, store minPopElem S i at heap 8 i, write i+1 to heap 9 112
  have s4 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 112) (by decide) hl112
  set g4 := Function.update g3 10 112; have bg4 : RegBounded W g4 := bg3.update (r := 10) (by decide) hl112
  have hg4_r : ws.read (.heap 9 (g4 10)) = (i : ℤ) := by simp only [g4, Function.update_self]; exact hr112
  have s5 := RegExec.load (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 13) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg4_r]; exact hi_bl)
  rw [hg4_r] at s5
  set g5 := Function.update g4 13 (i : ℤ); have bg5 : RegBounded W g5 := bg4.update (r := 13) (by decide) hi_bl
  have hm_w1 : ModifiedOnBounded ws₀ S_write W (ws.write (.heap 8 (g5 13)) (g5 1)) := by
    simpa [g5, g4, g3_1] using hmod.write (hSub8 i hi_pow) (minPopElem S i : ℤ) hloc8 hh_bl
  have s6 := RegExec.store (inp := inp) hfd_le bg5 (table := 8) (addr := 13) (val := 1) (by decide) (by decide) hn8
    (sp_ok hm_w1).1 (sp_ok hm_w1).2
  set ws1 := ws.write (.heap 8 (i : ℤ)) (minPopElem S i : ℤ)
  have hw1_eq : ws.write (.heap 8 (g5 13)) (g5 1) = ws1 := by simp [ws1, g5, g4, g3_1]
  rw [hw1_eq] at s6 hm_w1
  have s7 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 14) (c := 1) (by decide) hl1
  set g6 := Function.update g5 14 1; have bg6 : RegBounded W g6 := bg5.update (r := 14) (by decide) hl1
  have hg6_add : g6 13 + g6 14 = ((i + 1 : ℕ) : ℤ) := by simp [g6, g5]
  have s8 := RegExec.add (inp := inp) hfd_le bg6 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 13) (a := 13) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hg6_add]; exact hi1_bl)
  rw [hg6_add] at s8
  set g7 := Function.update g6 13 ((i + 1 : ℕ) : ℤ); have bg7 : RegBounded W g7 := bg6.update (r := 13) (by decide) hi1_bl
  have hm_w2 : ModifiedOnBounded ws₀ S_write W (ws1.write (.heap 9 (g7 10)) (g7 13)) := by
    simpa [g7, g6, g5, g4] using hm_w1.write hSub112 ((i + 1 : ℕ) : ℤ) hloc112 hi1_bl
  have s9 := RegExec.store (inp := inp) hfd_le bg7 (table := 9) (addr := 10) (val := 13) (by decide) (by decide) hn9
    (sp_ok hm_w2).1 (sp_ok hm_w2).2
  set ws2 := ws1.write (.heap 9 112) ((i + 1 : ℕ) : ℤ)
  have hw2_eq : ws1.write (.heap 9 (g7 10)) (g7 13) = ws2 := by simp [ws2, g7, g6, g5, g4]
  rw [hw2_eq] at s9 hm_w2
  -- 3. Remove minPopElem S i from tid
  have s10 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 2) (c := 0) (by decide) hl0
  set g8 := Function.update g7 2 0; have bg8 : RegBounded W g8 := bg7.update (r := 2) (by decide) hl0
  have s11 := RegExec.lit (inp := inp) hfd_le bg8 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 3) (c := 0) (by decide) hl0
  set g9 := Function.update g8 3 0; have bg9 : RegBounded W g9 := bg8.update (r := 3) (by decide) hl0
  have s12 := RegExec.lit (inp := inp) hfd_le bg9 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 4) (c := 0) (by decide) hl0
  set g10 := Function.update g9 4 0; have bg10 : RegBounded W g10 := bg9.update (r := 4) (by decide) hl0
  have htree2 : TreeStoredAt L tid (minPopState S i) rNum rDen ws2 :=
    htree.unchanged (fun u _ f _ => by simp [ws2, ws1, WordStore.write])
  have hPathSubSlice : treePathLocs L tid (minPopElem S i) ⊆ treeSliceLocs L tid := by
    intro loc hloc
    simp only [treePathLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hloc
    rcases hloc with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
    have hoff_lt : minPopElem S i / 2 ^ k < 2 ^ (L - k) := by
      rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add, Nat.sub_add_cancel (by clear * - hk; omega)]
      exact hh_lt
    unfold treeSliceLocs
    exact Finset.mem_image.mpr ⟨(treeIdx L k (minPopElem S i / 2 ^ k), f),
      Finset.mem_product.mpr ⟨Finset.mem_range.mpr (treeIdx_bounds (by clear * - hk; omega) hoff_lt).2,
        Finset.mem_range.mpr hf⟩, rfl⟩
  have hPathSub : treePathLocs L tid (minPopElem S i) ⊆ S_write := by
    intro loc hloc
    have hs := hPathSubSlice hloc
    simp only [treeSliceLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hs
    rcases hs with ⟨⟨u, f⟩, ⟨hu, hf⟩, rfl⟩
    exact hSubTree u hu f hf
  obtain ⟨wsEnd, g11, s13, hm_End, bg11, htreeEnd, hunch⟩ :=
    exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hm_w2 hcCeil hbCeil hL1 hh_lt hBr1
      (by clear * - hW; omega) hPathSub htree2 hNext_bnds
      (fun h hne_h => by rw [hnext, Finset.mem_erase]; simp [hne_h])
      (fun _ _ => rfl) (fun _ _ => rfl) false (by rw [hnext]; simp) bg10
      (by simp [g10, g9, g8, g7, g6, g5, g4, g3_0])
      (by simp [g10, g9, g8, g7, g6, g5, g4, g3_1])
      (by simp [g10, g9, g8])
      (by intro h; cases h) (by intro h; cases h)
  have hnot_path : ∀ t : ℕ, t ≠ 2 → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ treePathLocs L tid (minPopElem S i) := by
    intro t ht z hm; have hs := hPathSubSlice hm
    simp only [treeSliceLocs, Finset.mem_image] at hs; rcases hs with ⟨_, _, h⟩; cases h; exact ht rfl
  have hrEnd_111 : wsEnd.read (.heap 9 111) = (tid : ℤ) := by
    rw [wordStore_read_eq_vals hm_End.wf, (hunch _ (hnot_path 9 (by decide) 111)).2,
        ← wordStore_read_eq_vals hm_w2.wf, wordStore_read_write_ne _ (by decide),
        wordStore_read_write_ne _ (by intro h; cases h)]
    exact hr111
  have hrEnd_112 : wsEnd.read (.heap 9 112) = ((i + 1 : ℕ) : ℤ) := by
    rw [wordStore_read_eq_vals hm_End.wf, (hunch _ (hnot_path 9 (by decide) 112)).2,
        ← wordStore_read_eq_vals hm_w2.wf, wordStore_read_write_self]
  have hbufEnd : ∀ k < i + 1, wsEnd.read (.heap 8 (k : ℤ)) = (minPopElem S k : ℤ) := by
    intro k hk
    rw [wordStore_read_eq_vals hm_End.wf, (hunch _ (hnot_path 8 (by decide) (k : ℤ))).2,
        ← wordStore_read_eq_vals hm_w2.wf, wordStore_read_write_ne _ (by intro h; cases h)]
    rcases Nat.lt_succ_iff_lt_or_eq.mp hk with hlt | rfl
    · rw [wordStore_read_write_ne _ (by intro h; injection h with hz; omega)]
      exact hbuf k hlt
    · exact wordStore_read_write_self _ _ _
  have hLWW : 0 ≤ L * W * W := by positivity
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq (s11.seq (s12.seq s13)))))))))))).weaken
    rfl rfl (u₂ := 460 * L + 300) (b₂ := (76 * L + 80) * W * W)
    (by clear * -; omega) (by nlinarith only [hW20, hL1, hLWW])
  refine ⟨wsEnd, g11, sTot, hm_End, bg11, htreeEnd, hrEnd_111, hrEnd_112, hbufEnd, ?_⟩
  intro loc hns hne8 hne112
  have u := hunch loc (fun hp => hns (hPathSubSlice hp))
  exact ⟨by simp [u.1, ws2, ws1, WordStore.write, hne8, hne112],
         by simp [u.2, ws2, ws1, WordStore.write, Function.update_of_ne hne8, Function.update_of_ne hne112]⟩

theorem exec_popTreeToBufRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid B_r : ℕ} (hL1 : 1 ≤ L) (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 20 ≤ W)
    (hSubTree : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ S_write)
    (hSub8 : ∀ (k : ℕ), k < 2 ^ L → (.heap 8 (k : ℤ) : RAMCellLoc) ∈ S_write)
    (hSub110 : (.heap 9 110 : RAMCellLoc) ∈ S_write)
    (hSub111 : (.heap 9 111 : RAMCellLoc) ∈ S_write)
    (hSub112 : (.heap 9 112 : RAMCellLoc) ∈ S_write)
    (hn111 : (.heap 9 111 : RAMCellLoc) ∉ ws.live)
    (hn112 : (.heap 9 112 : RAMCellLoc) ∉ ws.live)
    {S : Finset ℕ} {rNum rDen : ℕ → ℤ}
    (htree : TreeStoredAt L tid S rNum rDen ws)
    (hS_bnds : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (tid : ℤ)) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (popTreeToBufRegs L) ws regs wsEnd regsEnd
        ((S.card + 1) * (460 * L + 340)) ((S.card + 1) * (76 * L + 100) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L tid ∅ (fun _ => 0) (fun _ => 1) wsEnd ∧
      wsEnd.read (.heap 9 110) = (S.card : ℤ) ∧
      (∀ k < S.card, wsEnd.read (.heap 8 (k : ℤ)) = (minPopElem S k : ℤ)) ∧
      (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid →
        loc ≠ .heap 9 110 → (∀ k < S.card, loc ≠ .heap 8 (k : ℤ)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hScard_le : S.card ≤ 2 ^ L := by
    calc S.card ≤ (Finset.range (2 ^ L)).card :=
        Finset.card_le_card (fun h hh => Finset.mem_range.mpr (hS_bnds h hh).1)
      _ = 2 ^ L := Finset.card_range _
  have hM_bl : intBitLength (S.card : ℤ) ≤ W := by
    have : S.card < 2 ^ (L + 1) := by have hp : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide); rw [pow_succ]; clear * - hScard_le hp; omega
    exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl110 : intBitLength (110 : ℤ) ≤ W := by have : intBitLength (110 : ℤ) = 8 := (by decide); omega
  have hl111 : intBitLength (111 : ℤ) ≤ W := by have : intBitLength (111 : ℤ) = 8 := (by decide); omega
  have hl112 : intBitLength (112 : ℤ) ≤ W := by have : intBitLength (112 : ℤ) = 8 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have hloc110 : (RAMCellLoc.heap 9 110).bitLength ≤ W := by have : (RAMCellLoc.heap 9 110).bitLength = 12 := (by decide); omega
  have hloc111 : (RAMCellLoc.heap 9 111).bitLength ≤ W := by have : (RAMCellLoc.heap 9 111).bitLength = 12 := (by decide); omega
  have hloc112 : (RAMCellLoc.heap 9 112).bitLength ≤ W := by have : (RAMCellLoc.heap 9 112).bitLength = 12 := (by decide); omega
  have htid_bl : intBitLength (tid : ℤ) ≤ W := by
    have := intBitLength_ofNat_le tid; clear * - this hW; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  -- Header setup: heap 9 111 := tid, treeReadRootRegs, heap 9 110 := S.card, heap 9 112 := 0
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 111) (by decide) hl111
  set g1 := Function.update regs 10 111; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hl111
  have hm_w1 : ModifiedOnBounded ws₀ S_write W (ws.write (.heap 9 (g1 10)) (g1 0)) := by
    simpa [g1, hr0] using hmod.write hSub111 (tid : ℤ) hloc111 htid_bl
  have s2 := RegExec.store (inp := inp) hfd_le bg1 (table := 9) (addr := 10) (val := 0) (by decide) (by decide) hn9
    (sp_ok hm_w1).1 (sp_ok hm_w1).2
  set ws1 := ws.write (.heap 9 111) (tid : ℤ)
  have hw1_eq : ws.write (.heap 9 (g1 10)) (g1 0) = ws1 := by simp [ws1, g1, hr0]
  rw [hw1_eq] at s2 hm_w1
  have htree1 : TreeStoredAt L tid S rNum rDen ws1 := htree.unchanged (fun u _ f _ => by simp [ws1, WordStore.write])
  obtain ⟨g2, s3, bg2, _, g2_1, _⟩ :=
    exec_treeReadRootRegs (inp := inp) (fd := fd) hfd_le (sp_ok hm_w1).1 (sp_ok hm_w1).2 hBr1
      (by clear * - hW; omega) htree1 hS_bnds bg1 (by simp [g1, hr0])
  have s4 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 10) (c := 110) (by decide) hl110
  set g3 := Function.update g2 10 110; have bg3 : RegBounded W g3 := bg2.update (r := 10) (by decide) hl110
  have hm_w2 : ModifiedOnBounded ws₀ S_write W (ws1.write (.heap 9 (g3 10)) (g3 1)) := by
    simpa [g3, g2_1] using hm_w1.write hSub110 (S.card : ℤ) hloc110 hM_bl
  have s5 := RegExec.store (inp := inp) hfd_le bg3 (table := 9) (addr := 10) (val := 1) (by decide) (by decide) hn9
    (sp_ok hm_w2).1 (sp_ok hm_w2).2
  set ws2 := ws1.write (.heap 9 110) (S.card : ℤ)
  have hw2_eq : ws1.write (.heap 9 (g3 10)) (g3 1) = ws2 := by simp [ws2, g3, g2_1]
  rw [hw2_eq] at s5 hm_w2
  have s6 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 10) (c := 112) (by decide) hl112
  set g4 := Function.update g3 10 112; have bg4 : RegBounded W g4 := bg3.update (r := 10) (by decide) hl112
  have s7 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 13) (c := 0) (by decide) hl0
  set g5 := Function.update g4 13 0; have bg5 : RegBounded W g5 := bg4.update (r := 13) (by decide) hl0
  have hm_w3 : ModifiedOnBounded ws₀ S_write W (ws2.write (.heap 9 (g5 10)) (g5 13)) := by
    simpa [g5, g4] using hm_w2.write hSub112 0 hloc112 hl0
  have s8 := RegExec.store (inp := inp) hfd_le bg5 (table := 9) (addr := 10) (val := 13) (by decide) (by decide) hn9
    (sp_ok hm_w3).1 (sp_ok hm_w3).2
  set ws3 := ws2.write (.heap 9 112) 0
  have hw3_eq : ws2.write (.heap 9 (g5 10)) (g5 13) = ws3 := by simp [ws3, g5, g4]
  rw [hw3_eq] at s8 hm_w3
  have htree3 : TreeStoredAt L tid S rNum rDen ws3 :=
    htree1.unchanged (fun u _ f _ => by simp [ws3, ws2, WordStore.write])
  -- Build loop sequence `i = 0 .. S.card`
  let LoopInv (i : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
    ModifiedOnBounded ws₀ S_write W w ∧
    RegBounded W g ∧
    (i ≤ S.card → TreeStoredAt L tid (minPopState S i) rNum rDen w) ∧
    w.read (.heap 9 111) = (tid : ℤ) ∧
    w.read (.heap 9 112) = (i : ℤ) ∧
    (∀ k < i, w.read (.heap 8 (k : ℤ)) = (minPopElem S k : ℤ)) ∧
    (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid →
      loc ≠ .heap 9 112 → (∀ k < i, loc ≠ .heap 8 (k : ℤ)) →
      (loc ∈ w.live ↔ loc ∈ ws3.live) ∧ w.vals loc = ws3.vals loc)
  have hLoop : ∀ m ≤ S.card, ∃ (wsSeq : ℕ → WordStore) (regSeq : ℕ → ℕ → ℤ),
      wsSeq 0 = ws3 ∧ regSeq 0 = g5 ∧
      LoopInv m (wsSeq m) (regSeq m) ∧
      (∀ i < m, RegExec inp fd W C_cell C_bit (popTreeStepStmt L)
        (wsSeq i) (regSeq i) (wsSeq (i + 1)) (regSeq (i + 1)) (460 * L + 300) ((76 * L + 80) * W * W)) := by
    intro m hm
    induction m with
    | zero =>
        refine ⟨fun _ => ws3, fun _ => g5, rfl, rfl,
          ⟨hm_w3, bg5, fun _ => htree3,
           by simp [ws3, ws2, ws1, WordStore.read, WordStore.write],
           by simp [ws3, WordStore.read, WordStore.write],
           fun k hk => absurd hk (Nat.not_lt_zero _),
           fun _ _ _ _ => ⟨Iff.rfl, rfl⟩⟩,
          fun i hi => absurd hi (Nat.not_lt_zero _)⟩
    | succ k ih =>
        obtain ⟨wS, rS, hw0, hr0_eq, ⟨hmk, bgk, htk, hr111_k, hr112_k, hbuf_k, hunch_k⟩, hsteps⟩ :=
          ih (Nat.le_of_succ_le hm)
        obtain ⟨wNext, gNext, hstep_k, hmN, bgN, htN, hr111_N, hr112_N, hbuf_N, hunch_N⟩ :=
          exec_popTreeStepStmt (inp := inp) (fd := fd) hfd_le hmk hcCeil hbCeil hL1 hBr1 hW
            hSubTree hSub8 hSub112 (Nat.lt_of_succ_le hm) hS_bnds (htk (Nat.le_of_succ_le hm))
            hr111_k hr112_k hbuf_k bgk
        refine ⟨fun i => if i ≤ k then wS i else wNext,
                fun i => if i ≤ k then rS i else gNext,
                by simp [hw0], by simp [hr0_eq], ?_, ?_⟩
        · simp only [show ¬ (k + 1 ≤ k) by omega, ↓reduceIte]
          refine ⟨hmN, bgN, fun _ => htN, hr111_N, hr112_N, hbuf_N, fun loc hns hne112 hne8 => ?_⟩
          have uN := hunch_N loc hns (hne8 k (Nat.lt_succ_self k)) hne112
          have uK := hunch_k loc hns hne112 (fun j hj => hne8 j (Nat.lt_succ_of_lt hj))
          exact ⟨uN.1.trans uK.1, uN.2.trans uK.2⟩
        · intro i hi
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
          · simp only [Nat.le_of_lt hlt, Nat.succ_le_of_lt hlt, ↓reduceIte]
            exact hsteps i hlt
          · simp only [le_rfl, show ¬ (i + 1 ≤ i) by omega, ↓reduceIte]
            exact hstep_k
  obtain ⟨wsSeq, regSeq, hw0, hrg0, ⟨hmM, bgM, htM, _, _, hbufM, hunchM⟩, hstepsM⟩ := hLoop S.card le_rfl
  have s9 := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (cntReg := 1) (by decide) S.card wsSeq regSeq (by rw [hrg0]; simp [g5, g4, g3, g2_1]) (by rw [hrg0]; exact bg5) hstepsM
  rw [hw0, hrg0] at s9
  -- Free heap 9 111 and heap 9 112
  have s10 := RegExec.lit (inp := inp) hfd_le bgM (sp_ok hmM).1 (sp_ok hmM).2 (dst := 10) (c := 111) (by decide) hl111
  set gA := Function.update (regSeq S.card) 10 111; have bgA : RegBounded W gA := bgM.update (r := 10) (by decide) hl111
  have s11 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsSeq S.card)
    bgA (table := 9) (addr := 10) (by decide) hn9
  set wsA := (wsSeq S.card).free (.heap 9 111)
  have hwA_eq : (wsSeq S.card).free (.heap 9 (gA 10)) = wsA := by simp [wsA, gA]
  rw [hwA_eq] at s11
  have hmA : ModifiedOnBounded ws₀ S_write W wsA := hmM.free hSub111
  have s12 := RegExec.lit (inp := inp) hfd_le bgA (sp_ok hmA).1 (sp_ok hmA).2 (dst := 10) (c := 112) (by decide) hl112
  set gEnd := Function.update gA 10 112; have bgEnd : RegBounded W gEnd := bgA.update (r := 10) (by decide) hl112
  have s13 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsA)
    bgEnd (table := 9) (addr := 10) (by decide) hn9
  set wsEnd := wsA.free (.heap 9 112)
  have hwE_eq : wsA.free (.heap 9 (gEnd 10)) = wsEnd := by simp [wsEnd, gEnd]
  rw [hwE_eq] at s13
  have hmEnd : ModifiedOnBounded ws₀ S_write W wsEnd := hmA.free hSub112
  have htreeEmpty : TreeStoredAt L tid ∅ (fun _ => 0) (fun _ => 1) wsEnd := by
    have ht0 := htM le_rfl; rw [minPopState_end S] at ht0
    exact (ht0.unchanged (fun u _ f _ => by simp [wsEnd, wsA, WordStore.free])).reweight_empty _ _
  have hn110_slice : (.heap 9 110 : RAMCellLoc) ∉ treeSliceLocs L tid := by
    intro hm; simp only [treeSliceLocs, Finset.mem_image] at hm; rcases hm with ⟨_, _, h⟩; cases h
  have hrEnd_110 : wsEnd.read (.heap 9 110) = (S.card : ℤ) := by
    rw [wordStore_read_free_ne _ (by decide), wordStore_read_free_ne _ (by decide),
        wordStore_read_eq_vals hmM.wf,
        (hunchM (.heap 9 110) hn110_slice (by decide) (fun _ _ h => by cases h)).2]
    simp [ws3, ws2, WordStore.write]
  have hbufEnd : ∀ k < S.card, wsEnd.read (.heap 8 (k : ℤ)) = (minPopElem S k : ℤ) := by
    intro k hk
    rw [wordStore_read_free_ne _ (by intro h; cases h), wordStore_read_free_ne _ (by intro h; cases h)]
    exact hbufM k hk
  have hLWW : 0 ≤ L * W * W := by positivity
  have hSWW : 0 ≤ S.card * (L * W * W) := by positivity
  have hSW : 0 ≤ S.card * (W * W) := by positivity
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq (s11.seq (s12.seq s13)))))))))))).weaken
    rfl rfl (u₂ := (S.card + 1) * (460 * L + 340)) (b₂ := (S.card + 1) * (76 * L + 100) * W * W)
    (by nlinarith only [hL1])
    (by nlinarith only [hW20, hL1, hLWW, hSWW, hSW])
  refine ⟨wsEnd, gEnd, sTot, hmEnd, bgEnd, htreeEmpty, hrEnd_110, hbufEnd, ?_⟩
  intro loc hns hne110 hne8
  by_cases h111 : loc = .heap 9 111
  · subst h111
    exact ⟨by simp [wsEnd, wsA, WordStore.free, hn111],
           by simp [wsEnd, wsA, WordStore.free, hmod.wf _ hn111]⟩
  · by_cases h112 : loc = .heap 9 112
    · subst h112
      exact ⟨by simp [wsEnd, WordStore.free, hn112],
             by simp [wsEnd, WordStore.free, hmod.wf _ hn112]⟩
    · have uM := hunchM loc hns h112 hne8
      exact ⟨by simp [wsEnd, wsA, WordStore.free, h111, h112, uM.1, ws3, ws2, ws1, WordStore.write, hne110],
             by simp [wsEnd, wsA, WordStore.free, Function.update_of_ne h111, Function.update_of_ne h112,
                  uM.2, ws3, ws2, ws1, WordStore.write, Function.update_of_ne hne110]⟩

def insertBufStepStmt (L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 111)
  (.seq (rLoad 0 9 10)
  (.seq (rLit 10 112)
  (.seq (rLoad 13 9 10)
  (.seq (rLoad 1 8 13)
  (.seq (rLit 14 1)
  (.seq (rAdd 13 13 14)
  (.seq (rStore 9 10 13)
  (.seq (rLit 2 1)
  (.seq (rLit 3 0)
  (.seq (rLit 4 1)
        (treeSetLeafRegs L)))))))))))

def insertBufToUnitTreeRegs (L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 111)
  (.seq (rStore 9 10 0)
  (.seq (rLit 10 110)
  (.seq (rLoad 5 9 10)
  (.seq (rLit 10 112)
  (.seq (rLit 13 0)
  (.seq (rStore 9 10 13)
  (.seq (.repeatN (.readLocal 5 (.lit 0)) (insertBufStepStmt L))
  (.seq (rLit 10 111)
  (.seq (rFree 9 10)
  (.seq (rLit 10 112)
        (rFree 9 10)))))))))))

theorem exec_insertBufToUnitTreeRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid M : ℕ} (hL1 : 1 ≤ L) (hM_le : M ≤ 2 ^ L)
    (hW : natBitLength tid + L + 24 ≤ W)
    (hSubTree : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ S_write)
    (hSub111 : (.heap 9 111 : RAMCellLoc) ∈ S_write)
    (hSub112 : (.heap 9 112 : RAMCellLoc) ∈ S_write)
    (hn111 : (.heap 9 111 : RAMCellLoc) ∉ ws.live)
    (hn112 : (.heap 9 112 : RAMCellLoc) ∉ ws.live)
    {hSeq : ℕ → ℕ}
    (hhSeq_lt : ∀ k < M, hSeq k < 2 ^ L)
    (hr110 : ws.read (.heap 9 110) = (M : ℤ))
    (hbuf : ∀ k < M, ws.read (.heap 8 (k : ℤ)) = (hSeq k : ℤ))
    (htree0 : TreeStoredAt L tid ∅ (fun _ => 0) (fun _ => 1) ws)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (tid : ℤ)) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (insertBufToUnitTreeRegs L) ws regs wsEnd regsEnd
        ((M + 1) * (400 * L + 300)) ((M + 1) * (64 * L + 80) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L tid ((Finset.range M).image hSeq) (fun _ => 0) (fun _ => 1) wsEnd ∧
      (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW20 : 24 ≤ W := by clear * - hW; omega
  have hM_bl : intBitLength (M : ℤ) ≤ W := by
    have : M < 2 ^ (L + 1) := by have hp : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide); rw [pow_succ]; clear * - hM_le hp; omega
    exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl110 : intBitLength (110 : ℤ) ≤ W := by have : intBitLength (110 : ℤ) = 8 := (by decide); omega
  have hl111 : intBitLength (111 : ℤ) ≤ W := by have : intBitLength (111 : ℤ) = 8 := (by decide); omega
  have hl112 : intBitLength (112 : ℤ) ≤ W := by have : intBitLength (112 : ℤ) = 8 := (by decide); omega
  have hn8 : natBitLength 8 ≤ W := by have : natBitLength 8 = 4 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have hloc111 : (RAMCellLoc.heap 9 111).bitLength ≤ W := by have : (RAMCellLoc.heap 9 111).bitLength = 12 := (by decide); omega
  have hloc112 : (RAMCellLoc.heap 9 112).bitLength ≤ W := by have : (RAMCellLoc.heap 9 112).bitLength = 12 := (by decide); omega
  have htid_bl : intBitLength (tid : ℤ) ≤ W := by
    have := intBitLength_ofNat_le tid; clear * - this hW; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  -- Header setup
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 111) (by decide) hl111
  set g1 := Function.update regs 10 111; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hl111
  have hm_w1 : ModifiedOnBounded ws₀ S_write W (ws.write (.heap 9 (g1 10)) (g1 0)) := by
    simpa [g1, hr0] using hmod.write hSub111 (tid : ℤ) hloc111 htid_bl
  have s2 := RegExec.store (inp := inp) hfd_le bg1 (table := 9) (addr := 10) (val := 0) (by decide) (by decide) hn9
    (sp_ok hm_w1).1 (sp_ok hm_w1).2
  set ws1 := ws.write (.heap 9 111) (tid : ℤ)
  have hw1_eq : ws.write (.heap 9 (g1 10)) (g1 0) = ws1 := by simp [ws1, g1, hr0]
  rw [hw1_eq] at s2 hm_w1
  have s3 := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 10) (c := 110) (by decide) hl110
  set g2 := Function.update g1 10 110; have bg2 : RegBounded W g2 := bg1.update (r := 10) (by decide) hl110
  have hg2_r : ws1.read (.heap 9 (g2 10)) = (M : ℤ) := by
    simp only [g2, Function.update_self, ws1]; rw [wordStore_read_write_ne _ (by decide)]; exact hr110
  have s4 := RegExec.load (inp := inp) hfd_le bg2 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 5) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg2_r]; exact hM_bl)
  rw [hg2_r] at s4
  set g3 := Function.update g2 5 (M : ℤ); have bg3 : RegBounded W g3 := bg2.update (r := 5) (by decide) hM_bl
  have s5 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 10) (c := 112) (by decide) hl112
  set g4 := Function.update g3 10 112; have bg4 : RegBounded W g4 := bg3.update (r := 10) (by decide) hl112
  have s6 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 13) (c := 0) (by decide) hl0
  set g5 := Function.update g4 13 0; have bg5 : RegBounded W g5 := bg4.update (r := 13) (by decide) hl0
  have hm_w2 : ModifiedOnBounded ws₀ S_write W (ws1.write (.heap 9 (g5 10)) (g5 13)) := by
    simpa [g5, g4] using hm_w1.write hSub112 0 hloc112 hl0
  have s7 := RegExec.store (inp := inp) hfd_le bg5 (table := 9) (addr := 10) (val := 13) (by decide) (by decide) hn9
    (sp_ok hm_w2).1 (sp_ok hm_w2).2
  set ws2 := ws1.write (.heap 9 112) 0
  have hw2_eq : ws1.write (.heap 9 (g5 10)) (g5 13) = ws2 := by simp [ws2, g5, g4]
  rw [hw2_eq] at s7 hm_w2
  have htree2 : TreeStoredAt L tid ((Finset.range 0).image hSeq) (fun _ => 0) (fun _ => 1) ws2 := by
    simpa using htree0.unchanged (fun u _ f _ => by simp [ws2, ws1, WordStore.write])
  -- Single loop step helper
  have hStep : ∀ i < M, ∀ w g,
      ModifiedOnBounded ws₀ S_write W w → RegBounded W g →
      TreeStoredAt L tid ((Finset.range i).image hSeq) (fun _ => 0) (fun _ => 1) w →
      w.read (.heap 9 111) = (tid : ℤ) → w.read (.heap 9 112) = (i : ℤ) →
      (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid → loc ≠ .heap 9 112 →
        (loc ∈ w.live ↔ loc ∈ ws2.live) ∧ w.vals loc = ws2.vals loc) →
      ∃ w' g',
        RegExec inp fd W C_cell C_bit (insertBufStepStmt L) w g w' g' (400 * L + 260) ((64 * L + 64) * W * W) ∧
        ModifiedOnBounded ws₀ S_write W w' ∧ RegBounded W g' ∧
        TreeStoredAt L tid ((Finset.range (i + 1)).image hSeq) (fun _ => 0) (fun _ => 1) w' ∧
        w'.read (.heap 9 111) = (tid : ℤ) ∧ w'.read (.heap 9 112) = ((i + 1 : ℕ) : ℤ) ∧
        (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid → loc ≠ .heap 9 112 →
          (loc ∈ w'.live ↔ loc ∈ ws2.live) ∧ w'.vals loc = ws2.vals loc) := by
    intro i hi w g hmw bgg hti hr111_w hr112_w hunch_w
    have hi_pow : i < 2 ^ L := lt_of_lt_of_le hi hM_le
    have hi_bl : intBitLength (i : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hi_pow).trans (by clear * - hW; omega)
    have hi1_bl : intBitLength ((i + 1 : ℕ) : ℤ) ≤ W := by
      have : i + 1 < 2 ^ (L + 1) := by rw [pow_succ]; clear * - hi_pow; omega
      exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
    have hhi_lt : hSeq i < 2 ^ L := hhSeq_lt i hi
    have hhi_bl : intBitLength (hSeq i : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hhi_lt).trans (by clear * - hW; omega)
    have hn8_slice : (.heap 8 (i : ℤ) : RAMCellLoc) ∉ treeSliceLocs L tid := by
      intro hm; simp only [treeSliceLocs, Finset.mem_image] at hm; rcases hm with ⟨_, _, h⟩; cases h
    have hr8_w : w.read (.heap 8 (i : ℤ)) = (hSeq i : ℤ) := by
      rw [wordStore_read_eq_vals hmw.wf, (hunch_w _ hn8_slice (by intro h; cases h)).2,
          ← wordStore_read_eq_vals hm_w2.wf, wordStore_read_write_ne _ (by intro h; cases h),
          wordStore_read_write_ne _ (by intro h; cases h)]
      exact hbuf i hi
    have p1 := RegExec.lit (inp := inp) hfd_le bgg (sp_ok hmw).1 (sp_ok hmw).2 (dst := 10) (c := 111) (by decide) hl111
    set q1 := Function.update g 10 111; have bq1 : RegBounded W q1 := bgg.update (r := 10) (by decide) hl111
    have hq1_r : w.read (.heap 9 (q1 10)) = (tid : ℤ) := by simp only [q1, Function.update_self]; exact hr111_w
    have p2 := RegExec.load (inp := inp) hfd_le bq1 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 0) (table := 9) (addr := 10)
      (by decide) (by decide) hn9 (by rw [hq1_r]; exact htid_bl)
    rw [hq1_r] at p2
    set q2 := Function.update q1 0 (tid : ℤ); have bq2 : RegBounded W q2 := bq1.update (r := 0) (by decide) htid_bl
    have p3 := RegExec.lit (inp := inp) hfd_le bq2 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 10) (c := 112) (by decide) hl112
    set q3 := Function.update q2 10 112; have bq3 : RegBounded W q3 := bq2.update (r := 10) (by decide) hl112
    have hq3_r : w.read (.heap 9 (q3 10)) = (i : ℤ) := by simp only [q3, Function.update_self]; exact hr112_w
    have p4 := RegExec.load (inp := inp) hfd_le bq3 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 13) (table := 9) (addr := 10)
      (by decide) (by decide) hn9 (by rw [hq3_r]; exact hi_bl)
    rw [hq3_r] at p4
    set q4 := Function.update q3 13 (i : ℤ); have bq4 : RegBounded W q4 := bq3.update (r := 13) (by decide) hi_bl
    have hq4_r8 : w.read (.heap 8 (q4 13)) = (hSeq i : ℤ) := by simp only [q4, Function.update_self]; exact hr8_w
    have p5 := RegExec.load (inp := inp) hfd_le bq4 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 1) (table := 8) (addr := 13)
      (by decide) (by decide) hn8 (by rw [hq4_r8]; exact hhi_bl)
    rw [hq4_r8] at p5
    set q5 := Function.update q4 1 (hSeq i : ℤ); have bq5 : RegBounded W q5 := bq4.update (r := 1) (by decide) hhi_bl
    have p6 := RegExec.lit (inp := inp) hfd_le bq5 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 14) (c := 1) (by decide) hl1
    set q6 := Function.update q5 14 1; have bq6 : RegBounded W q6 := bq5.update (r := 14) (by decide) hl1
    have hq6_add : q6 13 + q6 14 = ((i + 1 : ℕ) : ℤ) := by simp [q6, q5, q4]
    have p7 := RegExec.add (inp := inp) hfd_le bq6 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 13) (a := 13) (b := 14)
      (by decide) (by decide) (by decide) (by rw [hq6_add]; exact hi1_bl)
    rw [hq6_add] at p7
    set q7 := Function.update q6 13 ((i + 1 : ℕ) : ℤ); have bq7 : RegBounded W q7 := bq6.update (r := 13) (by decide) hi1_bl
    have hm_wa : ModifiedOnBounded ws₀ S_write W (w.write (.heap 9 (q7 10)) (q7 13)) := by
      simpa [q7, q6, q5, q4, q3] using hmw.write hSub112 ((i + 1 : ℕ) : ℤ) hloc112 hi1_bl
    have p8 := RegExec.store (inp := inp) hfd_le bq7 (table := 9) (addr := 10) (val := 13) (by decide) (by decide) hn9
      (sp_ok hm_wa).1 (sp_ok hm_wa).2
    set wa := w.write (.heap 9 112) ((i + 1 : ℕ) : ℤ)
    have hwa_eq : w.write (.heap 9 (q7 10)) (q7 13) = wa := by simp [wa, q7, q6, q5, q4, q3]
    rw [hwa_eq] at p8 hm_wa
    have p9 := RegExec.lit (inp := inp) hfd_le bq7 (sp_ok hm_wa).1 (sp_ok hm_wa).2 (dst := 2) (c := 1) (by decide) hl1
    set q8 := Function.update q7 2 1; have bq8 : RegBounded W q8 := bq7.update (r := 2) (by decide) hl1
    have p10 := RegExec.lit (inp := inp) hfd_le bq8 (sp_ok hm_wa).1 (sp_ok hm_wa).2 (dst := 3) (c := 0) (by decide) hl0
    set q9 := Function.update q8 3 0; have bq9 : RegBounded W q9 := bq8.update (r := 3) (by decide) hl0
    have p11 := RegExec.lit (inp := inp) hfd_le bq9 (sp_ok hm_wa).1 (sp_ok hm_wa).2 (dst := 4) (c := 1) (by decide) hl1
    set q10 := Function.update q9 4 1; have bq10 : RegBounded W q10 := bq9.update (r := 4) (by decide) hl1
    have htia : TreeStoredAt L tid ((Finset.range i).image hSeq) (fun _ => 0) (fun _ => 1) wa :=
      hti.unchanged (fun u _ f _ => by simp [wa, WordStore.write])
    have hPathSubSlice : treePathLocs L tid (hSeq i) ⊆ treeSliceLocs L tid := by
      intro loc hloc
      simp only [treePathLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hloc
      rcases hloc with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
      have hoff_lt : hSeq i / 2 ^ k < 2 ^ (L - k) := by
        rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add, Nat.sub_add_cancel (by clear * - hk; omega)]
        exact hhi_lt
      unfold treeSliceLocs
      exact Finset.mem_image.mpr ⟨(treeIdx L k (hSeq i / 2 ^ k), f),
        Finset.mem_product.mpr ⟨Finset.mem_range.mpr (treeIdx_bounds (by clear * - hk; omega) hoff_lt).2,
          Finset.mem_range.mpr hf⟩, rfl⟩
    have hPathSub : treePathLocs L tid (hSeq i) ⊆ S_write := by
      intro loc hloc; have hs := hPathSubSlice hloc
      simp only [treeSliceLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hs
      rcases hs with ⟨⟨u, f⟩, ⟨hu, hf⟩, rfl⟩; exact hSubTree u hu f hf
    have hNextSet_eq : (Finset.range (i + 1)).image hSeq = insert (hSeq i) ((Finset.range i).image hSeq) := by
      rw [Finset.range_add_one, Finset.image_insert]
    have hNext_bnds : ∀ h ∈ (Finset.range (i + 1)).image hSeq,
        h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 := by
      intro h hh
      simp only [Finset.mem_image, Finset.mem_range] at hh
      rcases hh with ⟨k, hk, rfl⟩
      exact ⟨hhSeq_lt k (lt_of_lt_of_le hk hi), by dsimp only; decide, by dsimp only; decide⟩
    obtain ⟨w', q11, p12, hm_w', bq11, htree', hunch'⟩ :=
      exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hm_wa hcCeil hbCeil hL1 hhi_lt (B_r := 2) (by decide)
        (by clear * - hW; omega) hPathSub htia hNext_bnds
        (fun h hne_h => by rw [hNextSet_eq, Finset.mem_insert]; simp [hne_h])
        (fun _ _ => rfl) (fun _ _ => rfl) true (by rw [hNextSet_eq]; simp) bq10
        (by simp [q10, q9, q8, q7, q6, q5, q4, q3, q2])
        (by simp [q10, q9, q8, q7, q6, q5])
        (by simp [q10, q9, q8])
        (fun _ => by simp [q10, q9]) (fun _ => by simp [q10])
    have hn9_path : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∉ treePathLocs L tid (hSeq i) := by
      intro z hm; have hs := hPathSubSlice hm
      simp only [treeSliceLocs, Finset.mem_image] at hs; rcases hs with ⟨_, _, h⟩; cases h
    have hr111' : w'.read (.heap 9 111) = (tid : ℤ) := by
      rw [wordStore_read_eq_vals hm_w'.wf, (hunch' _ (hn9_path 111)).2,
          ← wordStore_read_eq_vals hm_wa.wf, wordStore_read_write_ne _ (by decide)]
      exact hr111_w
    have hr112' : w'.read (.heap 9 112) = ((i + 1 : ℕ) : ℤ) := by
      rw [wordStore_read_eq_vals hm_w'.wf, (hunch' _ (hn9_path 112)).2,
          ← wordStore_read_eq_vals hm_wa.wf, wordStore_read_write_self]
    have hLWW : 0 ≤ L * W * W := by positivity
    have pTot := (p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq (p7.seq (p8.seq (p9.seq (p10.seq (p11.seq p12))))))))))).weaken
      rfl rfl (u₂ := 400 * L + 260) (b₂ := (64 * L + 64) * W * W)
      (by clear * -; omega) (by nlinarith only [hW20, hL1, hLWW])
    refine ⟨w', q11, pTot, hm_w', bq11, htree', hr111', hr112', ?_⟩
    intro loc hns hne112
    have u' := hunch' loc (fun hp => hns (hPathSubSlice hp))
    have uw := hunch_w loc hns hne112
    exact ⟨by simp [u'.1, wa, WordStore.write, hne112, uw.1],
           by simp [u'.2, wa, WordStore.write, Function.update_of_ne hne112, uw.2]⟩
  -- Build loop sequence `i = 0 .. M`
  have hLoop : ∀ m ≤ M, ∃ (wsSeq : ℕ → WordStore) (regSeq : ℕ → ℕ → ℤ),
      wsSeq 0 = ws2 ∧ regSeq 0 = g5 ∧
      ModifiedOnBounded ws₀ S_write W (wsSeq m) ∧ RegBounded W (regSeq m) ∧
      TreeStoredAt L tid ((Finset.range m).image hSeq) (fun _ => 0) (fun _ => 1) (wsSeq m) ∧
      (wsSeq m).read (.heap 9 111) = (tid : ℤ) ∧ (wsSeq m).read (.heap 9 112) = (m : ℤ) ∧
      (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid → loc ≠ .heap 9 112 →
        (loc ∈ (wsSeq m).live ↔ loc ∈ ws2.live) ∧ (wsSeq m).vals loc = ws2.vals loc) ∧
      (∀ i < m, RegExec inp fd W C_cell C_bit (insertBufStepStmt L)
        (wsSeq i) (regSeq i) (wsSeq (i + 1)) (regSeq (i + 1)) (400 * L + 260) ((64 * L + 64) * W * W)) := by
    intro m hm
    induction m with
    | zero =>
        refine ⟨fun _ => ws2, fun _ => g5, rfl, rfl, hm_w2, bg5, htree2,
          by simp [ws2, ws1, WordStore.read, WordStore.write],
          by simp [ws2, WordStore.read, WordStore.write],
          fun _ _ _ => ⟨Iff.rfl, rfl⟩,
          fun i hi => absurd hi (Nat.not_lt_zero _)⟩
    | succ k ih =>
        obtain ⟨wS, rS, hw0, hr0_eq, hmk, bgk, htk, hr111_k, hr112_k, hunch_k, hsteps⟩ := ih (Nat.le_of_succ_le hm)
        obtain ⟨wNext, gNext, hstep_k, hmN, bgN, htN, hr111_N, hr112_N, hunch_N⟩ :=
          hStep k (Nat.lt_of_succ_le hm) (wS k) (rS k) hmk bgk htk hr111_k hr112_k hunch_k
        refine ⟨fun i => if i ≤ k then wS i else wNext,
                fun i => if i ≤ k then rS i else gNext,
                by simp [hw0], by simp [hr0_eq], ?_⟩
        simp only [show ¬ (k + 1 ≤ k) by omega, ↓reduceIte]
        refine ⟨hmN, bgN, htN, hr111_N, hr112_N, hunch_N, fun i hi => ?_⟩
        rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
        · simp only [Nat.le_of_lt hlt, Nat.succ_le_of_lt hlt, ↓reduceIte]; exact hsteps i hlt
        · simp only [le_rfl, show ¬ (i + 1 ≤ i) by omega, ↓reduceIte]; exact hstep_k
  obtain ⟨wsSeq, regSeq, hw0, hrg0, hmM, bgM, htM, _, _, hunchM, hstepsM⟩ := hLoop M le_rfl
  have s8 := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (cntReg := 5) (by decide) M wsSeq regSeq (by rw [hrg0]; simp [g5, g4, g3]) (by rw [hrg0]; exact bg5) hstepsM
  rw [hw0, hrg0] at s8
  have s9 := RegExec.lit (inp := inp) hfd_le bgM (sp_ok hmM).1 (sp_ok hmM).2 (dst := 10) (c := 111) (by decide) hl111
  set gA := Function.update (regSeq M) 10 111; have bgA : RegBounded W gA := bgM.update (r := 10) (by decide) hl111
  have s10 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsSeq M)
    bgA (table := 9) (addr := 10) (by decide) hn9
  set wsA := (wsSeq M).free (.heap 9 111); have hwA_eq : (wsSeq M).free (.heap 9 (gA 10)) = wsA := by simp [wsA, gA]
  rw [hwA_eq] at s10; have hmA : ModifiedOnBounded ws₀ S_write W wsA := hmM.free hSub111
  have s11 := RegExec.lit (inp := inp) hfd_le bgA (sp_ok hmA).1 (sp_ok hmA).2 (dst := 10) (c := 112) (by decide) hl112
  set gEnd := Function.update gA 10 112; have bgEnd : RegBounded W gEnd := bgA.update (r := 10) (by decide) hl112
  have s12 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsA)
    bgEnd (table := 9) (addr := 10) (by decide) hn9
  set wsEnd := wsA.free (.heap 9 112); have hwE_eq : wsA.free (.heap 9 (gEnd 10)) = wsEnd := by simp [wsEnd, gEnd]
  rw [hwE_eq] at s12; have hmEnd : ModifiedOnBounded ws₀ S_write W wsEnd := hmA.free hSub112
  have htreeEnd : TreeStoredAt L tid ((Finset.range M).image hSeq) (fun _ => 0) (fun _ => 1) wsEnd :=
    htM.unchanged (fun u _ f _ => by simp [wsEnd, wsA, WordStore.free])
  have hLWW : 0 ≤ L * W * W := by positivity
  have hMWW : 0 ≤ M * (L * W * W) := by positivity
  have hMW : 0 ≤ M * (W * W) := by positivity
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq (s11.seq s12))))))))))).weaken
    rfl rfl (u₂ := (M + 1) * (400 * L + 300)) (b₂ := (M + 1) * (64 * L + 80) * W * W)
    (by nlinarith only [hL1])
    (by
      have h1 : M * ((64 * L + 64) * W * W) + W + 12 +
          (6 * (2 * W + 16) + 2 * (5 * W + 24) + (6 * W + 24) + 2 * (3 * W + 16))
          ≤ (M + 1) * (64 * L + 80) * W * W := by
        nlinarith only [hW20, hL1, hLWW, hMWW, hMW]
      linarith only [h1])
  refine ⟨wsEnd, gEnd, sTot, hmEnd, bgEnd, htreeEnd, ?_⟩
  intro loc hns
  by_cases h111 : loc = .heap 9 111
  · subst h111
    exact ⟨by simp [wsEnd, wsA, WordStore.free, hn111],
           by simp [wsEnd, wsA, WordStore.free, hmod.wf _ hn111]⟩
  · by_cases h112 : loc = .heap 9 112
    · subst h112
      exact ⟨by simp [wsEnd, WordStore.free, hn112],
             by simp [wsEnd, WordStore.free, hmod.wf _ hn112]⟩
    · have uM := hunchM loc hns h112
      exact ⟨by simp [wsEnd, wsA, WordStore.free, h111, h112, uM.1, ws2, ws1, WordStore.write],
             by simp [wsEnd, wsA, WordStore.free, Function.update_of_ne h111, Function.update_of_ne h112,
                  uM.2, ws2, ws1, WordStore.write]⟩

def freeBufRegs : BitRAMStmt :=
  .seq (rLit 10 110)
  (.seq (rLoad 5 9 10)
  (.seq (rLit 13 0)
  (.seq (rLit 14 1)
  (.seq (.repeatN (.readLocal 5 (.lit 0))
          (.seq (rFree 8 13) (rAdd 13 13 14)))
  (.seq (rLit 10 110)
        (rFree 9 10))))))

theorem exec_freeBufRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L M : ℕ} (hM_le : M ≤ 2 ^ L) (hW : L + 20 ≤ W)
    (hSub8 : ∀ (k : ℕ), k < 2 ^ L → (.heap 8 (k : ℤ) : RAMCellLoc) ∈ S_write)
    (hSub110 : (.heap 9 110 : RAMCellLoc) ∈ S_write)
    (hr110 : ws.read (.heap 9 110) = (M : ℤ))
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit freeBufRegs ws regs wsEnd regsEnd
        (16 * M + 40) ((12 * M + 24) * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      (∀ k < M, (.heap 8 (k : ℤ) : RAMCellLoc) ∉ wsEnd.live) ∧
      (.heap 9 110 : RAMCellLoc) ∉ wsEnd.live ∧
      (∀ loc : RAMCellLoc, loc ≠ .heap 9 110 → (∀ k < M, loc ≠ .heap 8 (k : ℤ)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hM_bl : intBitLength (M : ℤ) ≤ W := by
    have : M < 2 ^ (L + 1) := by have hp : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide); rw [pow_succ]; clear * - hM_le hp; omega
    exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl110 : intBitLength (110 : ℤ) ≤ W := by have : intBitLength (110 : ℤ) = 8 := (by decide); omega
  have hn8 : natBitLength 8 ≤ W := by have : natBitLength 8 = 4 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 110) (by decide) hl110
  set g1 := Function.update regs 10 110; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hl110
  have hg1_r : ws.read (.heap 9 (g1 10)) = (M : ℤ) := by simp only [g1, Function.update_self]; exact hr110
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 5) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact hM_bl)
  rw [hg1_r] at s2
  set g2 := Function.update g1 5 (M : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 5) (by decide) hM_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 13) (c := 0) (by decide) hl0
  set g3 := Function.update g2 13 0; have bg3 : RegBounded W g3 := bg2.update (r := 13) (by decide) hl0
  have s4 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
  set g4 := Function.update g3 14 1; have bg4 : RegBounded W g4 := bg3.update (r := 14) (by decide) hl1
  let wsSeq : ℕ → WordStore := fun n => Nat.rec ws (fun k acc => acc.free (.heap 8 (k : ℤ))) n
  have hwsSeq_0 : wsSeq 0 = ws := rfl
  have hwsSeq_succ : ∀ k, wsSeq (k + 1) = (wsSeq k).free (.heap 8 (k : ℤ)) := fun _ => rfl
  let regSeq : ℕ → ℕ → ℤ := fun k => Function.update g4 13 (k : ℤ)
  have hmodSeq : ∀ k ≤ M, ModifiedOnBounded ws₀ S_write W (wsSeq k) := by
    intro k hk; induction k with
    | zero => exact hmod
    | succ m ih =>
        exact (ih (Nat.le_of_succ_le hk)).free (hSub8 m (lt_of_lt_of_le (Nat.lt_of_succ_le hk) hM_le))
  have hbndSeq : ∀ k ≤ M, RegBounded W (regSeq k) := by
    intro k hk
    have hk_bl : intBitLength (k : ℤ) ≤ W := by
      have : k < 2 ^ (L + 1) := by have hp : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide); rw [pow_succ]; clear * - hk hM_le hp; omega
      exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
    exact bg4.update (r := 13) (by decide) hk_bl
  have hstep : ∀ i < M, RegExec inp fd W C_cell C_bit (.seq (rFree 8 13) (rAdd 13 13 14))
      (wsSeq i) (regSeq i) (wsSeq (i + 1)) (regSeq (i + 1)) 12 (9 * W + 48) := by
    intro i hi
    have hi1_bl : intBitLength ((i + 1 : ℕ) : ℤ) ≤ W := by
      have : i + 1 < 2 ^ (L + 1) := by rw [pow_succ]; clear * - hi hM_le; omega
      exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
    have p1 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsSeq i)
      (hbndSeq i (Nat.le_of_lt hi)) (table := 8) (addr := 13) (by decide) hn8
    have hwf_eq : (wsSeq i).free (.heap 8 (regSeq i 13)) = wsSeq (i + 1) := by rw [hwsSeq_succ]; simp [regSeq]
    rw [hwf_eq] at p1
    have hadd_eq : regSeq i 13 + regSeq i 14 = ((i + 1 : ℕ) : ℤ) := by simp [regSeq, g4]
    have p2 := RegExec.add (inp := inp) hfd_le (hbndSeq i (Nat.le_of_lt hi))
      (sp_ok (hmodSeq (i + 1) (Nat.succ_le_of_lt hi))).1
      (sp_ok (hmodSeq (i + 1) (Nat.succ_le_of_lt hi))).2
      (dst := 13) (a := 13) (b := 14) (by decide) (by decide) (by decide) (by rw [hadd_eq]; exact hi1_bl)
    rw [hadd_eq] at p2
    have hrg_eq : Function.update (regSeq i) 13 ((i + 1 : ℕ) : ℤ) = regSeq (i + 1) := by
      ext r; simp [regSeq]
    exact (p1.seq p2).weaken rfl hrg_eq (by omega) (by omega)
  have hg4_eq : regSeq 0 = g4 := by
    ext r; dsimp [regSeq]; by_cases hr : r = 13
    · subst hr; simp [g4, g3]
    · simp [Function.update_of_ne hr]
  have s5 := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (cntReg := 5) (by decide) M wsSeq regSeq (by rw [hg4_eq]; simp [g4, g3, g2]) (hbndSeq 0 (Nat.zero_le _)) hstep
  rw [hg4_eq] at s5
  have s6 := RegExec.lit (inp := inp) hfd_le (hbndSeq M le_rfl) (sp_ok (hmodSeq M le_rfl)).1 (sp_ok (hmodSeq M le_rfl)).2
    (dst := 10) (c := 110) (by decide) hl110
  set gEnd := Function.update (regSeq M) 10 110
  have bgEnd : RegBounded W gEnd := (hbndSeq M le_rfl).update (r := 10) (by decide) hl110
  have s7 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsSeq M)
    bgEnd (table := 9) (addr := 10) (by decide) hn9
  set wsEnd := (wsSeq M).free (.heap 9 110)
  have hwE_eq : (wsSeq M).free (.heap 9 (gEnd 10)) = wsEnd := by simp [wsEnd, gEnd]
  rw [hwE_eq] at s7
  have hmEnd : ModifiedOnBounded ws₀ S_write W wsEnd := (hmodSeq M le_rfl).free hSub110
  have hSeq_spec : ∀ m, (∀ k < m, (.heap 8 (k : ℤ) : RAMCellLoc) ∉ (wsSeq m).live) ∧
      (∀ loc : RAMCellLoc, (∀ k < m, loc ≠ .heap 8 (k : ℤ)) →
        (loc ∈ (wsSeq m).live ↔ loc ∈ ws.live) ∧ (wsSeq m).vals loc = ws.vals loc) := by
    intro m; induction m with
    | zero => exact ⟨fun k hk => absurd hk (Nat.not_lt_zero _), fun _ _ => ⟨Iff.rfl, rfl⟩⟩
    | succ j ih =>
        refine ⟨fun k hk => ?_, fun loc hne => ?_⟩
        · rcases Nat.lt_succ_iff_lt_or_eq.mp hk with hlt | rfl
          · rw [hwsSeq_succ]; simp [WordStore.free, ih.1 k hlt]
          · rw [hwsSeq_succ]; simp [WordStore.free]
        · have hnej : loc ≠ .heap 8 (j : ℤ) := hne j (Nat.lt_succ_self j)
          have u := ih.2 loc (fun k hk => hne k (Nat.lt_succ_of_lt hk))
          rw [hwsSeq_succ]
          exact ⟨by simp [WordStore.free, hnej, u.1],
                 by simp [WordStore.free, Function.update_of_ne hnej, u.2]⟩
  have hMW : 0 ≤ M * W := by positivity
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq s7)))))).weaken rfl rfl
    (u₂ := 16 * M + 40) (b₂ := (12 * M + 24) * W)
    (by clear * -; omega) (by nlinarith only [hW20, hMW])
  refine ⟨wsEnd, gEnd, sTot, hmEnd, bgEnd,
    fun k hk => by simp [wsEnd, WordStore.free, (hSeq_spec M).1 k hk],
    by simp [wsEnd, WordStore.free], ?_⟩
  intro loc hne110 hne8
  have u := (hSeq_spec M).2 loc hne8
  exact ⟨by simp [wsEnd, WordStore.free, hne110, u.1],
         by simp [wsEnd, WordStore.free, Function.update_of_ne hne110, u.2]⟩

/-! ### 3. Step A (`posDimStepA` & `exec_posDimStepA`): Handle Allocation, Table 0 & Table 1 -/

def posDimStepAIns (d L : ℕ) : BitRAMStmt :=
  .seq (rLit 0 0)
  (.seq (treeMexRegs L)
  (.seq (rLit 10 0)
  (.seq (rStore 0 10 1)
  (.seq (rLit 10 103)
  (.seq (rStore 9 10 1)
  (.seq (saveInsPointRegs d)
  (.seq (rLit 0 0)
  (.seq (rLit 10 103)
  (.seq (rLoad 1 9 10)
  (.seq (rLit 2 1)
  (.seq (rLit 3 0)
  (.seq (rLit 4 1)
        (treeSetLeafRegs L)))))))))))))

def posDimStepADel (d L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 103)
  (.seq (rStore 9 10 6)
  (.seq (rLit 0 0)
  (.seq (rCopy 1 6)
  (.seq (rLit 2 0)
  (.seq (rLit 3 0)
  (.seq (rLit 4 0)
  (.seq (treeSetLeafRegs L)
  (.seq (rLit 10 103)
  (.seq (rLoad 1 9 10)
        (freeDelPointRegs d))))))))))

def posDimStepA (d L : ℕ) : BitRAMStmt :=
  .seq (rIntParam 5 1)
  (.seq (rIntParam 6 2)
  (.seq (rLit 10 102)
  (.seq (rStore 9 10 5)
  (.seq (rLit 14 1)
        (.ite (.intEq (.readLocal 5 (.lit 0)) (.readLocal 14 (.lit 0)))
          (posDimStepAIns d L)
          (posDimStepADel d L))))))

theorem exec_posDimStepA {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    (hB1 : 1 ≤ B)
    (hW : B + natBitLength d + L + 28 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    {op : DynamicUpdate d}
    (hleg : IsLegalUpdate n (RatAdmissiblePointSet d B) P op)
    (hinp_spec : match op with
      | .insert _ _ pt =>
          ∃ qIns : Fin d → ℚ,
            RatPointBitBounded B qIns ∧
            ratPointToEuclidean qIns = pt ∧
            inp.intParams = [(n : ℤ), 1, 0] ∧
            inp.extraRats = List.ofFn qIns
      | .delete id =>
          inp.intParams = [(n : ℤ), 0, (P.handleOfId id : ℤ)] ∧
          inp.extraRats = [])
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    let retH : Option ℕ :=
      match op with
      | .insert _ _ _ => some (mexHandle P.activeHandles)
      | .delete _ => none
    let ltCoords' : ℕ → EuclideanSpace ℝ (Fin d) :=
      match op with
      | .insert _ _ pt => Function.update ltCoords P.nextLifetime pt
      | .delete _ => ltCoords
    ∃ (P' : DynamicPointSet d) (qMap' : ℕ → Fin d → ℚ) (hOp : ℕ) (wsA : WordStore) (regsA : ℕ → ℤ),
      applyDynamicUpdate P op retH = some P' ∧
      P'.WellFormed n ∧
      RegExec inp fd W C_cell C_bit (posDimStepA d L) ws regs wsA regsA
        (450 * L + 800 * d + 400) ((80 * L + 220 * d + 120) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsA ∧
      RegBounded W regsA ∧
      ActiveCoordsStored d L B P'.activeHandles qMap' wsA ∧
      TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsA ∧
      (∀ id' ∈ P'.activeIds,
        ltCoords' (P'.lifetimeOfId id') = P'.coords id' ∧
        P'.coords id' = ratPointToEuclidean (qMap' (P'.handleOfId id'))) ∧
      (∀ lt < P'.nextLifetime, ltCoords' lt ∈ RatAdmissiblePointSet d B ∨ ltCoords' lt = 0) ∧
      (∀ h ∈ P.activeHandles, (match op with | .insert _ _ _ => True | .delete id => h ≠ P.handleOfId id) →
        qMap' h = qMap h) ∧
      wsA.read (.heap 9 102) = (match op with | .insert _ _ _ => 1 | .delete _ => 0) ∧
      wsA.read (.heap 9 103) = (hOp : ℤ) ∧
      hOp < 2 ^ L ∧
      (match op with
       | .insert _ _ _ => hOp = mexHandle P.activeHandles ∧ wsA.read (.heap 0 0) = (hOp : ℤ)
       | .delete id => hOp = P.handleOfId id) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .heap 0 0 → loc ≠ .heap 9 102 → loc ≠ .heap 9 103 →
        loc ∉ treeSliceLocs L 0 →
        (∀ c < d, ∀ f < 2, loc ≠ .heap 1 (coordCellAddr d hOp c f)) →
        (loc ∈ wsA.live ↔ loc ∈ ws.live) ∧ wsA.vals loc = ws.vals loc) := by
  intro retH ltCoords'
  have ⟨hL2, _, h2n_pow, _⟩ := clog_two_mul_bounds hn
  rw [← hL] at hL2 h2n_pow
  have hL1 : 1 ≤ L := by clear * - hL2; omega
  have hW28 : 28 ≤ W := by clear * - hW; omega
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl2 : intBitLength (2 : ℤ) ≤ W := by have : intBitLength (2 : ℤ) = 3 := (by decide); omega
  have hl102 : intBitLength (102 : ℤ) ≤ W := by have : intBitLength (102 : ℤ) = 8 := (by decide); omega
  have hl103 : intBitLength (103 : ℤ) ≤ W := by have : intBitLength (103 : ℤ) = 8 := (by decide); omega
  have hn0 : natBitLength 0 ≤ W := by have : natBitLength 0 ≤ 4 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have hloc00 : (RAMCellLoc.heap 0 0).bitLength ≤ W := by have : (RAMCellLoc.heap 0 0).bitLength ≤ 16 := (by decide); omega
  have hloc102 : (RAMCellLoc.heap 9 102).bitLength ≤ W := by have : (RAMCellLoc.heap 9 102).bitLength = 12 := (by decide); omega
  have hloc103 : (RAMCellLoc.heap 9 103).bitLength ≤ W := by have : (RAMCellLoc.heap 9 103).bitLength = 12 := (by decide); omega
  have hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    have : WordStore.empty.cellCount = 0 := by simp [WordStore.cellCount, WordStore.empty]
    linarith only [hcCeil, this]
  have hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    have : WordStore.empty.bitSize = 0 := by simp [WordStore.bitSize, WordStore.empty]
    linarith only [hbCeil, this]
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil0], by linarith only [bs, hbCeil0]⟩
  have hAdm_cur : ∀ id₀ ∈ P.activeIds, P.coords id₀ ∈ RatAdmissiblePointSet d B := by
    intro id₀ hid₀
    have hsync := (hinv.hlt_sync id₀ hid₀).2
    have hh_mem : P.handleOfId id₀ ∈ P.activeHandles := (hinv.wfP.2.1 id₀ hid₀).1
    refine ⟨qMap (P.handleOfId id₀), ?_, hsync.symm⟩
    exact (hinv.coords_stored.hS _ hh_mem).2
  cases op with
  | insert id extName pt =>
      rcases hinp_spec with ⟨qIns, hqIns_bnd, hqIns_eq, hinp_int, hinp_ext⟩
      have hcard_lt : P.activeHandles.card < 2 ^ L := by
        rw [activeHandles_card_eq hinv.wfP]
        have := hinv.wfP.1; clear * - this h2n_pow hn; omega
      set hNew := mexHandle P.activeHandles
      have hhNew_not : hNew ∉ P.activeHandles := mexHandle_notMem P.activeHandles
      have hhNew_lt : hNew < 2 ^ L := mexHandle_lt_of_card_lt hcard_lt
      have hhNew_bl : intBitLength (hNew : ℤ) ≤ W :=
        (nat_lt_pow2_bitLength_le hhNew_lt).trans (by clear * - hW; omega)
      obtain ⟨P', happ, hwfP', _, hactIds', hactH', _⟩ :=
        applyDynamicUpdate_insert_spec hinv.wfP hAdm_cur hleg hhNew_not
      let qMap' : ℕ → Fin d → ℚ := fun h => if h = hNew then qIns else qMap h
      -- Execute header: rIntParam 5 1; rIntParam 6 2; rLit 10 102; rStore 9 10 5; rLit 14 1
      have hp1 : listGetIntD inp.intParams 1 0 = 1 := by simp [hinp_int, listGetIntD]
      have hp2 : listGetIntD inp.intParams 2 0 = 0 := by simp [hinp_int, listGetIntD]
      have s1 := RegExec.intParam (inp := inp) hfd_le hbnd (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
        (dst := 5) (by decide) 1 hl1 (by rw [hp1]; exact hl1)
      rw [hp1] at s1; set g1 := Function.update regs 5 1; have bg1 := hbnd.update (r := 5) (by decide) hl1
      have s2 := RegExec.intParam (inp := inp) hfd_le bg1 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
        (dst := 6) (by decide) 2 hl2 (by rw [hp2]; exact hl0)
      rw [hp2] at s2; set g2 := Function.update g1 6 0; have bg2 := bg1.update (r := 6) (by decide) hl0
      have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
        (dst := 10) (c := 102) (by decide) hl102
      set g3 := Function.update g2 10 102; have bg3 := bg2.update (r := 10) (by decide) hl102
      have hm_w1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (ws.write (.heap 9 (g3 10)) (g3 5)) := by
        simpa [g3, g2, g1] using hinv.mod.write (mem_posDimWriteLocs_tab9 (by decide)) 1 hloc102 hl1
      have s4 := RegExec.store (inp := inp) hfd_le bg3 (table := 9) (addr := 10) (val := 5) (by decide) (by decide) hn9
        (sp_ok hm_w1).1 (sp_ok hm_w1).2
      set ws1 := ws.write (.heap 9 102) 1
      have hw1_eq : ws.write (.heap 9 (g3 10)) (g3 5) = ws1 := by simp [ws1, g3, g2, g1]
      rw [hw1_eq] at s4 hm_w1
      have s5 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hm_w1).1 (sp_ok hm_w1).2
        (dst := 14) (c := 1) (by decide) hl1
      set g4 := Function.update g3 14 1; have bg4 := bg3.update (r := 14) (by decide) hl1
      -- Insert branch body
      have s6 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 0) (c := 0) (by decide) hl0
      set g5 := Function.update g4 0 0; have bg5 := bg4.update (r := 0) (by decide) hl0
      have htree_w1 : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) ws1 :=
        hinv.tree_active.unchanged (fun u _ f _ => by simp [ws1, WordStore.write])
      have hAct_bnds : ∀ h ∈ P.activeHandles, h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 :=
        fun h hm => ⟨hinv.tree_active.hS h hm, by dsimp only; decide, by dsimp only; decide⟩
      obtain ⟨g6, s7, bg6, _, g6_1, _⟩ :=
        exec_treeMexRegs (inp := inp) (fd := fd) hfd_le (sp_ok hm_w1).1 (sp_ok hm_w1).2 hL1 (B_r := 2) (by decide)
          (by have : natBitLength 0 ≤ 4 := (by decide); clear * - hW this; omega)
          htree_w1 hAct_bnds hcard_lt bg5 (by simp [g5])
      change g6 1 = (hNew : ℤ) at g6_1
      have s8 := RegExec.lit (inp := inp) hfd_le bg6 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 10) (c := 0) (by decide) hl0
      set g7 := Function.update g6 10 0; have bg7 := bg6.update (r := 10) (by decide) hl0
      have hm_w2 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (ws1.write (.heap 0 (g7 10)) (g7 1)) := by
        simpa [g7, g6_1] using hm_w1.write (mem_posDimWriteLocs_tab0 (i := 0) (by decide)) (hNew : ℤ) hloc00 hhNew_bl
      have s9 := RegExec.store (inp := inp) hfd_le bg7 (table := 0) (addr := 10) (val := 1) (by decide) (by decide) hn0
        (sp_ok hm_w2).1 (sp_ok hm_w2).2
      set ws2 := ws1.write (.heap 0 0) (hNew : ℤ)
      have hw2_eq : ws1.write (.heap 0 (g7 10)) (g7 1) = ws2 := by simp [ws2, g7, g6_1]
      rw [hw2_eq] at s9 hm_w2
      have s10 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 10) (c := 103) (by decide) hl103
      set g8 := Function.update g7 10 103; have bg8 := bg7.update (r := 10) (by decide) hl103
      have hm_w3 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (ws2.write (.heap 9 (g8 10)) (g8 1)) := by
        simpa [g8, g7, g6_1] using hm_w2.write (mem_posDimWriteLocs_tab9 (by decide)) (hNew : ℤ) hloc103 hhNew_bl
      have s11 := RegExec.store (inp := inp) hfd_le bg8 (table := 9) (addr := 10) (val := 1) (by decide) (by decide) hn9
        (sp_ok hm_w3).1 (sp_ok hm_w3).2
      set ws3 := ws2.write (.heap 9 103) (hNew : ℤ)
      have hw3_eq : ws2.write (.heap 9 (g8 10)) (g8 1) = ws3 := by simp [ws3, g8, g7, g6_1]
      rw [hw3_eq] at s11 hm_w3
      have hcoords3 : ActiveCoordsStored d L B P.activeHandles qMap ws3 :=
        hinv.coords_stored.unchanged (fun _ _ _ _ _ _ => by simp [ws3, ws2, ws1, WordStore.read, WordStore.write])
      obtain ⟨ws4, g9, s12, hm_w4, bg9, hcoords4, _, hunch4⟩ :=
        exec_saveInsPointRegs hd1 (inp := inp) (fd := fd) hfd_le hm_w3 hcCeil0 hbCeil0 hB1 hhNew_lt
          (by clear * - hW; omega) hhNew_not hcoords3 hqIns_bnd hinp_ext
          (fun c hc f hf => mem_posDimWriteLocs_coord hhNew_lt hc hf)
          bg8 (by simp [g8, g7, g6_1])
      rw [← hactH'] at hcoords4
      have s13 := RegExec.lit (inp := inp) hfd_le bg9 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 0) (c := 0) (by decide) hl0
      set g10 := Function.update g9 0 0; have bg10 := bg9.update (r := 0) (by decide) hl0
      have s14 := RegExec.lit (inp := inp) hfd_le bg10 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 10) (c := 103) (by decide) hl103
      set g11 := Function.update g10 10 103; have bg11 := bg10.update (r := 10) (by decide) hl103
      have hr4_103 : ws4.read (.heap 9 (g11 10)) = (hNew : ℤ) := by
        simp only [g11, Function.update_self]
        rw [wordStore_read_eq_vals hm_w4.wf, (hunch4 _ (fun _ _ _ _ h => by cases h)).2,
            ← wordStore_read_eq_vals hm_w3.wf]
        simp [ws3, WordStore.read, WordStore.write]
      have s15 := RegExec.load (inp := inp) hfd_le bg11 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 1) (table := 9) (addr := 10)
        (by decide) (by decide) hn9 (by rw [hr4_103]; exact hhNew_bl)
      rw [hr4_103] at s15; set g12 := Function.update g11 1 (hNew : ℤ); have bg12 := bg11.update (r := 1) (by decide) hhNew_bl
      have s16 := RegExec.lit (inp := inp) hfd_le bg12 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 2) (c := 1) (by decide) hl1
      set g13 := Function.update g12 2 1; have bg13 := bg12.update (r := 2) (by decide) hl1
      have s17 := RegExec.lit (inp := inp) hfd_le bg13 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 3) (c := 0) (by decide) hl0
      set g14 := Function.update g13 3 0; have bg14 := bg13.update (r := 3) (by decide) hl0
      have s18 := RegExec.lit (inp := inp) hfd_le bg14 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 4) (c := 1) (by decide) hl1
      set g15 := Function.update g14 4 1; have bg15 := bg14.update (r := 4) (by decide) hl1
      have htree4 : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) ws4 :=
        htree_w1.unchanged (fun u _ f _ => by
          have u4 := hunch4 (.heap 2 (treeCellAddr L 0 u f)) (fun _ _ _ _ h => by cases h)
          exact ⟨by simp [u4.1, ws3, ws2, WordStore.write], by simp [u4.2, ws3, ws2, WordStore.write]⟩)
      have hAct'_bnds : ∀ h ∈ P'.activeHandles, h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 := by
        intro h hh; rw [hactH'] at hh
        rcases Finset.mem_insert.mp hh with rfl | hold
        · exact ⟨hhNew_lt, by dsimp only; decide, by dsimp only; decide⟩
        · exact hAct_bnds h hold
      obtain ⟨wsA, gA, s19, hm_A, bgA, htreeA, hunchA⟩ :=
        exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hm_w4 hcCeil0 hbCeil0 hL1 hhNew_lt (B_r := 2) (by decide)
          (by have : natBitLength 0 ≤ 4 := (by decide); clear * - hW this; omega)
          (treePathLocs_sub_posDimWriteLocs (by omega) hhNew_lt)
          htree4 hAct'_bnds
          (fun h hne => by rw [hactH', Finset.mem_insert]; simp [hne])
          (fun _ _ => rfl) (fun _ _ => rfl) true (by rw [hactH']; simp) bg15
          (by simp [g15, g14, g13, g12, g11, g10])
          (by simp [g15, g14, g13, g12])
          (by simp [g15, g14, g13])
          (fun _ => by simp [g15, g14]) (fun _ => by simp [g15])
      have hPathSub0 : treePathLocs L 0 hNew ⊆ treeSliceLocs L 0 := by
        intro loc hloc
        simp only [treePathLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hloc
        rcases hloc with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
        have hoff_lt : hNew / 2 ^ k < 2 ^ (L - k) := by
          rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add, Nat.sub_add_cancel (by clear * - hk; omega)]
          exact hhNew_lt
        unfold treeSliceLocs
        exact Finset.mem_image.mpr ⟨(treeIdx L k (hNew / 2 ^ k), f),
          Finset.mem_product.mpr ⟨Finset.mem_range.mpr (treeIdx_bounds (by clear * - hk; omega) hoff_lt).2,
            Finset.mem_range.mpr hf⟩, rfl⟩
      have hnot_path : ∀ t : ℕ, t ≠ 2 → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ treePathLocs L 0 hNew := by
        intro t ht z hm; have hs := hPathSub0 hm
        simp only [treeSliceLocs, Finset.mem_image] at hs; rcases hs with ⟨_, _, h⟩; cases h; exact ht rfl
      have hcoordsA : ActiveCoordsStored d L B P'.activeHandles qMap' wsA :=
        hcoords4.unchanged (fun h' _ c _ f _ => by
          rw [wordStore_read_eq_vals hm_A.wf, (hunchA _ (hnot_path 1 (by decide) _)).2,
              ← wordStore_read_eq_vals hm_w4.wf])
      have sBranch := s6.seq (s7.seq (s8.seq (s9.seq (s10.seq (s11.seq (s12.seq (s13.seq (s14.seq (s15.seq (s16.seq (s17.seq (s18.seq s19))))))))))))
      have sIte := RegExec.iteEq (tB := posDimStepAIns d L) (fB := posDimStepADel d L) bg4 (a := 5) (b := 14) (by decide) (by decide)
        (by simp only [g4, g3, g2, g1, Function.update_self, Function.update_of_ne (by decide : (5 : ℕ) ≠ 14),
              Function.update_of_ne (by decide : (5 : ℕ) ≠ 10), Function.update_of_ne (by decide : (5 : ℕ) ≠ 6), ↓reduceIte]; exact sBranch)
      have hLWW : 0 ≤ L * W * W := by positivity
      have hdWW : 0 ≤ d * W * W := by positivity
      have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq sIte))))).weaken rfl rfl
        (u₂ := 450 * L + 800 * d + 400) (b₂ := (80 * L + 220 * d + 120) * W * W)
        (by clear * -; omega)
        (by
          have hsave_b : (12 * d + 16) * W * W ≤ 220 * (d * W * W) := by
            have : (12 * d + 16) * W * W = 12 * (d * W * W) + 16 * (W * W) := by ring
            nlinarith only [this, hd1, hW28, hdWW]
          nlinarith only [hW28, hL1, hd1, hLWW, hdWW, hsave_b])
      -- Verify lifetime sync and admissibility on P'
      have hlt_sync' : ∀ id' ∈ P'.activeIds,
          ltCoords' (P'.lifetimeOfId id') = P'.coords id' ∧
          P'.coords id' = ratPointToEuclidean (qMap' (P'.handleOfId id')) := by
        dsimp only [applyDynamicUpdate, retH] at happ
        split_ifs at happ with hcond
        injection happ with hP'_eq
        subst hP'_eq
        intro id' hid'
        rcases Finset.mem_insert.mp hid' with rfl | hold
        · simp [ltCoords', qMap', hqIns_eq]
        · have hne : id' ≠ id := fun h => hcond.1 (h ▸ hold)
          have hlt_lt : P.lifetimeOfId id' < P.nextLifetime := hinv.wfP.2.2.2.1 id' hold
          have hlt_ne : P.lifetimeOfId id' ≠ P.nextLifetime := Nat.ne_of_lt hlt_lt
          have hhd_ne : P.handleOfId id' ≠ hNew := fun h => hhNew_not (h ▸ (hinv.wfP.2.1 id' hold).1)
          simp only [ltCoords', qMap', Function.update_of_ne hne, Function.update_of_ne hlt_ne, hhd_ne, ↓reduceIte]
          exact hinv.hlt_sync id' hold
      have hlt_adm' : ∀ lt < P'.nextLifetime, ltCoords' lt ∈ RatAdmissiblePointSet d B ∨ ltCoords' lt = 0 := by
        have hnext_eq : P'.nextLifetime = P.nextLifetime + 1 :=
          (activeLifetimes_insert_spec hinv.wfP hwfP' happ).2.2.1
        intro lt hlt
        rw [hnext_eq] at hlt
        rcases Nat.lt_succ_iff_lt_or_eq.mp hlt with hlt_old | rfl
        · dsimp only [ltCoords']
          rw [Function.update_of_ne (Nat.ne_of_lt hlt_old)]
          exact hinv.hlt_adm lt hlt_old
        · dsimp only [ltCoords']
          rw [Function.update_self]
          exact Or.inl hleg.2.2
      have hrA_102 : wsA.read (.heap 9 102) = 1 := by
        rw [wordStore_read_eq_vals hm_A.wf, (hunchA _ (hnot_path 9 (by decide) 102)).2,
            (hunch4 _ (fun _ _ _ _ h => by cases h)).2, ← wordStore_read_eq_vals hm_w3.wf]
        simp [ws3, ws2, ws1, WordStore.read, WordStore.write]
      have hrA_103 : wsA.read (.heap 9 103) = (hNew : ℤ) := by
        rw [wordStore_read_eq_vals hm_A.wf, (hunchA _ (hnot_path 9 (by decide) 103)).2,
            (hunch4 _ (fun _ _ _ _ h => by cases h)).2, ← wordStore_read_eq_vals hm_w3.wf]
        simp [ws3, WordStore.read, WordStore.write]
      have hrA_00 : wsA.read (.heap 0 0) = (hNew : ℤ) := by
        rw [wordStore_read_eq_vals hm_A.wf, (hunchA _ (hnot_path 0 (by decide) 0)).2,
            (hunch4 _ (fun _ _ _ _ h => by cases h)).2, ← wordStore_read_eq_vals hm_w3.wf]
        simp [ws3, ws2, WordStore.read, WordStore.write]
      refine ⟨P', qMap', hNew, wsA, gA, happ, hwfP', sTot, hm_A, bgA, hcoordsA, htreeA,
        hlt_sync', hlt_adm',
        fun h hh _ => by dsimp [qMap']; rw [if_neg (fun heq : h = hNew => hhNew_not (heq ▸ hh))],
        hrA_102, hrA_103, hhNew_lt, ⟨rfl, hrA_00⟩, ?_⟩
      intro loc hne00 hne102 hne103 hns0 hne1
      have uA := hunchA loc (fun hp => hns0 (hPathSub0 hp))
      have u4 := hunch4 loc hne1
      exact ⟨by simp [uA.1, u4.1, ws3, ws2, ws1, WordStore.write, hne103, hne00, hne102],
             by simp [uA.2, u4.2, ws3, ws2, ws1, WordStore.write,
                  Function.update_of_ne hne103, Function.update_of_ne hne00, Function.update_of_ne hne102]⟩
  | delete id =>
      rcases hinp_spec with ⟨hinp_int, _⟩
      have hid_mem : id ∈ P.activeIds := hleg
      set delH := P.handleOfId id
      have hdelH_mem : delH ∈ P.activeHandles := (hinv.wfP.2.1 id hid_mem).1
      have hdelH_lt : delH < 2 ^ L := hinv.tree_active.hS delH hdelH_mem
      have hdelH_bl : intBitLength (delH : ℤ) ≤ W :=
        (nat_lt_pow2_bitLength_le hdelH_lt).trans (by clear * - hW; omega)
      obtain ⟨P', _, happ, hwfP', _, hactIds', hactH', _⟩ :=
        applyDynamicUpdate_delete_spec hinv.wfP hAdm_cur hleg
      -- Execute header: rIntParam 5 1; rIntParam 6 2; rLit 10 102; rStore 9 10 5; rLit 14 1
      have hp1 : listGetIntD inp.intParams 1 0 = 0 := by simp [hinp_int, listGetIntD]
      have hp2 : listGetIntD inp.intParams 2 0 = (delH : ℤ) := by simp [hinp_int, listGetIntD, delH]
      have s1 := RegExec.intParam (inp := inp) hfd_le hbnd (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
        (dst := 5) (by decide) 1 hl1 (by rw [hp1]; exact hl0)
      rw [hp1] at s1; set g1 := Function.update regs 5 0; have bg1 := hbnd.update (r := 5) (by decide) hl0
      have s2 := RegExec.intParam (inp := inp) hfd_le bg1 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
        (dst := 6) (by decide) 2 hl2 (by rw [hp2]; exact hdelH_bl)
      rw [hp2] at s2; set g2 := Function.update g1 6 (delH : ℤ); have bg2 := bg1.update (r := 6) (by decide) hdelH_bl
      have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
        (dst := 10) (c := 102) (by decide) hl102
      set g3 := Function.update g2 10 102; have bg3 := bg2.update (r := 10) (by decide) hl102
      have hm_w1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (ws.write (.heap 9 (g3 10)) (g3 5)) := by
        simpa [g3, g2, g1] using hinv.mod.write (mem_posDimWriteLocs_tab9 (by decide)) 0 hloc102 hl0
      have s4 := RegExec.store (inp := inp) hfd_le bg3 (table := 9) (addr := 10) (val := 5) (by decide) (by decide) hn9
        (sp_ok hm_w1).1 (sp_ok hm_w1).2
      set ws1 := ws.write (.heap 9 102) 0
      have hw1_eq : ws.write (.heap 9 (g3 10)) (g3 5) = ws1 := by simp [ws1, g3, g2, g1]
      rw [hw1_eq] at s4 hm_w1
      have s5 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hm_w1).1 (sp_ok hm_w1).2
        (dst := 14) (c := 1) (by decide) hl1
      set g4 := Function.update g3 14 1; have bg4 := bg3.update (r := 14) (by decide) hl1
      -- Delete branch body
      have s6 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 10) (c := 103) (by decide) hl103
      set g5 := Function.update g4 10 103; have bg5 := bg4.update (r := 10) (by decide) hl103
      have hm_w2 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (ws1.write (.heap 9 (g5 10)) (g5 6)) := by
        simpa [g5, g4, g3, g2] using hm_w1.write (mem_posDimWriteLocs_tab9 (by decide)) (delH : ℤ) hloc103 hdelH_bl
      have s7 := RegExec.store (inp := inp) hfd_le bg5 (table := 9) (addr := 10) (val := 6) (by decide) (by decide) hn9
        (sp_ok hm_w2).1 (sp_ok hm_w2).2
      set ws2 := ws1.write (.heap 9 103) (delH : ℤ)
      have hw2_eq : ws1.write (.heap 9 (g5 10)) (g5 6) = ws2 := by simp [ws2, g5, g4, g3, g2]
      rw [hw2_eq] at s7 hm_w2
      have s8 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 0) (c := 0) (by decide) hl0
      set g6 := Function.update g5 0 0; have bg6 := bg5.update (r := 0) (by decide) hl0
      have s9 := RegExec.copy (inp := inp) hfd_le bg6 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 1) (src := 6) (by decide) (by decide)
      set g7 := Function.update g6 1 (g6 6); have bg7 := bg6.update (r := 1) (by decide) (by simpa [g6, g5, g4, g3, g2] using hdelH_bl)
      have s10 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 2) (c := 0) (by decide) hl0
      set g8 := Function.update g7 2 0; have bg8 := bg7.update (r := 2) (by decide) hl0
      have s11 := RegExec.lit (inp := inp) hfd_le bg8 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 3) (c := 0) (by decide) hl0
      set g9 := Function.update g8 3 0; have bg9 := bg8.update (r := 3) (by decide) hl0
      have s12 := RegExec.lit (inp := inp) hfd_le bg9 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 4) (c := 0) (by decide) hl0
      set g10 := Function.update g9 4 0; have bg10 := bg9.update (r := 4) (by decide) hl0
      have htree2 : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) ws2 :=
        hinv.tree_active.unchanged (fun u _ f _ => by simp [ws2, ws1, WordStore.write])
      have hAct'_bnds : ∀ h ∈ P'.activeHandles, h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 := by
        intro h hh; rw [hactH'] at hh
        exact ⟨hinv.tree_active.hS h (Finset.mem_of_mem_erase hh), by dsimp only; decide, by dsimp only; decide⟩
      obtain ⟨ws3, g11, s13, hm_w3, bg11, htree3, hunch3⟩ :=
        exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hm_w2 hcCeil0 hbCeil0 hL1 hdelH_lt (B_r := 2) (by decide)
          (by have : natBitLength 0 ≤ 4 := (by decide); clear * - hW this; omega)
          (treePathLocs_sub_posDimWriteLocs (by omega) hdelH_lt)
          htree2 hAct'_bnds
          (fun h hne => by rw [hactH', Finset.mem_erase]; simp [hne, delH])
          (fun _ _ => rfl) (fun _ _ => rfl) false (by rw [hactH']; simp [delH]) bg10
          (by simp [g10, g9, g8, g7, g6])
          (by simp [g10, g9, g8, g7, g6, g5, g4, g3, g2])
          (by simp [g10, g9, g8])
          (by intro h; cases h) (by intro h; cases h)
      have hPathSub0 : treePathLocs L 0 delH ⊆ treeSliceLocs L 0 := by
        intro loc hloc
        simp only [treePathLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hloc
        rcases hloc with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
        have hoff_lt : delH / 2 ^ k < 2 ^ (L - k) := by
          rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add, Nat.sub_add_cancel (by clear * - hk; omega)]
          exact hdelH_lt
        unfold treeSliceLocs
        exact Finset.mem_image.mpr ⟨(treeIdx L k (delH / 2 ^ k), f),
          Finset.mem_product.mpr ⟨Finset.mem_range.mpr (treeIdx_bounds (by clear * - hk; omega) hoff_lt).2,
            Finset.mem_range.mpr hf⟩, rfl⟩
      have hnot_path : ∀ t : ℕ, t ≠ 2 → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ treePathLocs L 0 delH := by
        intro t ht z hm; have hs := hPathSub0 hm
        simp only [treeSliceLocs, Finset.mem_image] at hs; rcases hs with ⟨_, _, h⟩; cases h; exact ht rfl
      have s14 := RegExec.lit (inp := inp) hfd_le bg11 (sp_ok hm_w3).1 (sp_ok hm_w3).2 (dst := 10) (c := 103) (by decide) hl103
      set g12 := Function.update g11 10 103; have bg12 := bg11.update (r := 10) (by decide) hl103
      have hr3_103 : ws3.read (.heap 9 (g12 10)) = (delH : ℤ) := by
        simp only [g12, Function.update_self]
        rw [wordStore_read_eq_vals hm_w3.wf, (hunch3 _ (hnot_path 9 (by decide) 103)).2,
            ← wordStore_read_eq_vals hm_w2.wf]
        simp [ws2, WordStore.read, WordStore.write]
      have s15 := RegExec.load (inp := inp) hfd_le bg12 (sp_ok hm_w3).1 (sp_ok hm_w3).2 (dst := 1) (table := 9) (addr := 10)
        (by decide) (by decide) hn9 (by rw [hr3_103]; exact hdelH_bl)
      rw [hr3_103] at s15; set g13 := Function.update g12 1 (delH : ℤ); have bg13 := bg12.update (r := 1) (by decide) hdelH_bl
      have hcoords3 : ActiveCoordsStored d L B P.activeHandles qMap ws3 :=
        hinv.coords_stored.unchanged (fun _ _ _ _ _ _ => by
          rw [wordStore_read_eq_vals hm_w3.wf, (hunch3 _ (hnot_path 1 (by decide) _)).2,
              ← wordStore_read_eq_vals hm_w2.wf]
          simp [ws2, ws1, WordStore.read, WordStore.write])
      obtain ⟨wsA, gA, s16, hm_A, bgA, hcoordsA, _, _, hunchA⟩ :=
        exec_freeDelPointRegs hd1 (inp := inp) (fd := fd) hfd_le hm_w3 hcCeil0 hbCeil0 hdelH_lt
          (by clear * - hW; omega) hcoords3
          (fun c hc f hf => mem_posDimWriteLocs_coord hdelH_lt hc hf)
          bg13 (by simp [g13])
      have hactH'_del : P'.activeHandles = P.activeHandles.erase delH := hactH'; rw [← hactH'_del] at hcoordsA
      have htreeA : TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsA :=
        htree3.unchanged (fun u _ f _ => hunchA (.heap 2 (treeCellAddr L 0 u f)) (fun _ _ _ _ h => by cases h))
      have sBranch := s6.seq (s7.seq (s8.seq (s9.seq (s10.seq (s11.seq (s12.seq (s13.seq (s14.seq (s15.seq s16)))))))))
      have sIte := RegExec.iteEq (tB := posDimStepAIns d L) (fB := posDimStepADel d L) bg4 (a := 5) (b := 14) (by decide) (by decide)
        (by simp only [g4, g3, g2, g1, Function.update_self, Function.update_of_ne (by decide : (5 : ℕ) ≠ 14),
              Function.update_of_ne (by decide : (5 : ℕ) ≠ 10), Function.update_of_ne (by decide : (5 : ℕ) ≠ 6)]; simp only [zero_ne_one, ↓reduceIte]; exact sBranch)
      have hLWW : 0 ≤ L * W * W := by positivity
      have hdWW : 0 ≤ d * W * W := by positivity
      have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq sIte))))).weaken rfl rfl
        (u₂ := 450 * L + 800 * d + 400) (b₂ := (80 * L + 220 * d + 120) * W * W)
        (by clear * -; omega)
        (by
          have hfree_b : (8 * d + 8) * W * W ≤ 220 * (d * W * W) := by
            have : (8 * d + 8) * W * W = 8 * (d * W * W) + 8 * (W * W) := by ring
            nlinarith only [this, hd1, hW28, hdWW]
          nlinarith only [hW28, hL1, hd1, hLWW, hdWW, hfree_b])
      have hlt_sync' : ∀ id' ∈ P'.activeIds,
          ltCoords' (P'.lifetimeOfId id') = P'.coords id' ∧
          P'.coords id' = ratPointToEuclidean (qMap (P'.handleOfId id')) := by
        dsimp only [applyDynamicUpdate, retH] at happ
        split_ifs at happ with hid_in
        injection happ with hP'_eq
        subst hP'_eq
        intro id' hid'
        rcases Finset.mem_erase.mp hid' with ⟨hne, hold⟩
        simp only [ltCoords', Function.update_of_ne hne]
        exact hinv.hlt_sync id' hold
      have hlt_adm' : ∀ lt < P'.nextLifetime, ltCoords' lt ∈ RatAdmissiblePointSet d B ∨ ltCoords' lt = 0 := by
        have hnext_eq : P'.nextLifetime = P.nextLifetime :=
          (activeLifetimes_delete_spec hinv.wfP hwfP' happ).2.2.1
        rw [hnext_eq]
        exact hinv.hlt_adm
      have hrA_102 : wsA.read (.heap 9 102) = 0 := by
        rw [wordStore_read_eq_vals hm_A.wf, (hunchA _ (fun _ _ _ _ h => by cases h)).2,
            (hunch3 _ (hnot_path 9 (by decide) 102)).2, ← wordStore_read_eq_vals hm_w2.wf]
        simp [ws2, ws1, WordStore.read, WordStore.write]
      have hrA_103 : wsA.read (.heap 9 103) = (delH : ℤ) := by
        rw [wordStore_read_eq_vals hm_A.wf, (hunchA _ (fun _ _ _ _ h => by cases h)).2,
            (hunch3 _ (hnot_path 9 (by decide) 103)).2, ← wordStore_read_eq_vals hm_w2.wf]
        simp [ws2, WordStore.read, WordStore.write]
      refine ⟨P', qMap, delH, wsA, gA, happ, hwfP', sTot, hm_A, bgA, hcoordsA, htreeA,
        hlt_sync', hlt_adm', fun _ _ _ => rfl, hrA_102, hrA_103, hdelH_lt, rfl, ?_⟩
      intro loc _ hne102 hne103 hns0 hne1
      have uA := hunchA loc hne1
      have u3 := hunch3 loc (fun hp => hns0 (hPathSub0 hp))
      exact ⟨by simp [uA.1, u3.1, ws2, ws1, WordStore.write, hne103, hne102],
             by simp [uA.2, u3.2, ws2, ws1, WordStore.write,
                  Function.update_of_ne hne103, Function.update_of_ne hne102]⟩

end UL.C12LVE
