import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorB1
set_option autoImplicit false
set_option maxHeartbeats 400000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open scoped ENNReal
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### 1. Polynomial Bound Closure Combinators (`IsBoundedByPoly1/2/3`) -/

theorem c12_isBoundedByPoly1_mul_const {f : ℕ → ℝ} (hf : IsBoundedByPoly1 f) {c : ℝ} (hc : 0 ≤ c) :
    IsBoundedByPoly1 (fun x => c * f x) := by
  obtain ⟨C, deg, hC, hb⟩ := hf
  refine ⟨c * C, deg, mul_nonneg hc hC, fun x => ?_⟩
  calc c * f x ≤ c * (C * ((x + 1 : ℝ) ^ deg)) := mul_le_mul_of_nonneg_left (hb x) hc
    _ = (c * C) * ((x + 1 : ℝ) ^ deg) := by ring

theorem c12_isBoundedByPoly3_const (c : ℝ) : IsBoundedByPoly3 (fun _ _ _ => c) := by
  refine ⟨max 0 c, 0, le_max_left 0 c, fun d B L => ?_⟩
  simp only [pow_zero, mul_one]
  exact le_max_right 0 c

theorem c12_isBoundedByPoly3_d : IsBoundedByPoly3 (fun d _ _ => (d : ℝ)) := by
  refine ⟨1, 1, zero_le_one, fun d B L => ?_⟩
  simp only [pow_one, one_mul]
  have hB : (1 : ℝ) ≤ (B : ℝ) + 1 := by linarith
  have hL : (1 : ℝ) ≤ (L : ℝ) + 1 := by linarith
  have hd1 : (0 : ℝ) ≤ (d : ℝ) + 1 := by positivity
  calc (d : ℝ) ≤ ((d : ℝ) + 1) * 1 * 1 := by linarith
    _ ≤ ((d : ℝ) + 1) * ((B : ℝ) + 1) * ((L : ℝ) + 1) :=
      mul_le_mul (mul_le_mul_of_nonneg_left hB hd1) hL zero_le_one (by positivity)

theorem c12_isBoundedByPoly3_B : IsBoundedByPoly3 (fun _ B _ => (B : ℝ)) := by
  refine ⟨1, 1, zero_le_one, fun d B L => ?_⟩
  simp only [pow_one, one_mul]
  have hd : (1 : ℝ) ≤ (d : ℝ) + 1 := by linarith
  have hL : (1 : ℝ) ≤ (L : ℝ) + 1 := by linarith
  have hB1 : (0 : ℝ) ≤ (B : ℝ) + 1 := by positivity
  calc (B : ℝ) ≤ 1 * ((B : ℝ) + 1) * 1 := by linarith
    _ ≤ ((d : ℝ) + 1) * ((B : ℝ) + 1) * ((L : ℝ) + 1) :=
      mul_le_mul (mul_le_mul_of_nonneg_right hd hB1) hL zero_le_one (by positivity)

theorem c12_isBoundedByPoly3_L : IsBoundedByPoly3 (fun _ _ L => (L : ℝ)) := by
  refine ⟨1, 1, zero_le_one, fun d B L => ?_⟩
  simp only [pow_one, one_mul]
  have hdB : (1 : ℝ) ≤ ((d : ℝ) + 1) * ((B : ℝ) + 1) := by
    have : (1 : ℝ) ≤ (d : ℝ) + 1 := by linarith
    have : (1 : ℝ) ≤ (B : ℝ) + 1 := by linarith
    nlinarith
  have hL1 : (0 : ℝ) ≤ (L : ℝ) + 1 := by positivity
  calc (L : ℝ) ≤ 1 * ((L : ℝ) + 1) := by linarith
    _ ≤ (((d : ℝ) + 1) * ((B : ℝ) + 1)) * ((L : ℝ) + 1) := mul_le_mul_of_nonneg_right hdB hL1

theorem c12_isBoundedByPoly3_add {f g : ℕ → ℕ → ℕ → ℝ}
    (hf : IsBoundedByPoly3 f) (hg : IsBoundedByPoly3 g) :
    IsBoundedByPoly3 (fun d B L => f d B L + g d B L) := by
  obtain ⟨Cf, df, hCf, hbf⟩ := hf
  obtain ⟨Cg, dg, hCg, hbg⟩ := hg
  refine ⟨Cf + Cg, max df dg, add_nonneg hCf hCg, fun d B L => ?_⟩
  have hpf : ((d + 1 : ℝ) ^ df) * ((B + 1 : ℝ) ^ df) * ((L + 1 : ℝ) ^ df) ≤
      ((d + 1 : ℝ) ^ max df dg) * ((B + 1 : ℝ) ^ max df dg) * ((L + 1 : ℝ) ^ max df dg) := by
    have h1 := pow_le_pow_right₀ (by linarith : (1 : ℝ) ≤ (d : ℝ) + 1) (le_max_left df dg)
    have h2 := pow_le_pow_right₀ (by linarith : (1 : ℝ) ≤ (B : ℝ) + 1) (le_max_left df dg)
    have h3 := pow_le_pow_right₀ (by linarith : (1 : ℝ) ≤ (L : ℝ) + 1) (le_max_left df dg)
    exact mul_le_mul (mul_le_mul h1 h2 (by positivity) (by positivity)) h3 (by positivity) (by positivity)
  have hpg : ((d + 1 : ℝ) ^ dg) * ((B + 1 : ℝ) ^ dg) * ((L + 1 : ℝ) ^ dg) ≤
      ((d + 1 : ℝ) ^ max df dg) * ((B + 1 : ℝ) ^ max df dg) * ((L + 1 : ℝ) ^ max df dg) := by
    have h1 := pow_le_pow_right₀ (by linarith : (1 : ℝ) ≤ (d : ℝ) + 1) (le_max_right df dg)
    have h2 := pow_le_pow_right₀ (by linarith : (1 : ℝ) ≤ (B : ℝ) + 1) (le_max_right df dg)
    have h3 := pow_le_pow_right₀ (by linarith : (1 : ℝ) ≤ (L : ℝ) + 1) (le_max_right df dg)
    exact mul_le_mul (mul_le_mul h1 h2 (by positivity) (by positivity)) h3 (by positivity) (by positivity)
  calc f d B L + g d B L
    _ ≤ Cf * (((d + 1 : ℝ) ^ df) * ((B + 1 : ℝ) ^ df) * ((L + 1 : ℝ) ^ df)) +
        Cg * (((d + 1 : ℝ) ^ dg) * ((B + 1 : ℝ) ^ dg) * ((L + 1 : ℝ) ^ dg)) := by
          have := hbf d B L; have := hbg d B L; linarith
    _ ≤ Cf * (((d + 1 : ℝ) ^ max df dg) * ((B + 1 : ℝ) ^ max df dg) * ((L + 1 : ℝ) ^ max df dg)) +
        Cg * (((d + 1 : ℝ) ^ max df dg) * ((B + 1 : ℝ) ^ max df dg) * ((L + 1 : ℝ) ^ max df dg)) :=
          add_le_add (mul_le_mul_of_nonneg_left hpf hCf) (mul_le_mul_of_nonneg_left hpg hCg)
    _ = (Cf + Cg) * ((d + 1 : ℝ) ^ max df dg) * ((B + 1 : ℝ) ^ max df dg) * ((L + 1 : ℝ) ^ max df dg) := by
          ring

theorem c12_isBoundedByPoly3_mul_nonneg {f g : ℕ → ℕ → ℕ → ℝ}
    (hf : IsBoundedByPoly3 f) (hg : IsBoundedByPoly3 g)
    (hf0 : ∀ d B L, 0 ≤ f d B L) (hg0 : ∀ d B L, 0 ≤ g d B L) :
    IsBoundedByPoly3 (fun d B L => f d B L * g d B L) := by
  obtain ⟨Cf, df, hCf, hbf⟩ := hf
  obtain ⟨Cg, dg, hCg, hbg⟩ := hg
  refine ⟨Cf * Cg, df + dg, mul_nonneg hCf hCg, fun d B L => ?_⟩
  have hbf' : f d B L ≤ Cf * ((d + 1 : ℝ) ^ df) * ((B + 1 : ℝ) ^ df) * ((L + 1 : ℝ) ^ df) := hbf d B L
  have hbg' : g d B L ≤ Cg * ((d + 1 : ℝ) ^ dg) * ((B + 1 : ℝ) ^ dg) * ((L + 1 : ℝ) ^ dg) := hbg d B L
  calc f d B L * g d B L
    _ ≤ (Cf * ((d + 1 : ℝ) ^ df) * ((B + 1 : ℝ) ^ df) * ((L + 1 : ℝ) ^ df)) *
        (Cg * ((d + 1 : ℝ) ^ dg) * ((B + 1 : ℝ) ^ dg) * ((L + 1 : ℝ) ^ dg)) :=
          mul_le_mul hbf' hbg' (hg0 d B L) (le_trans (hf0 d B L) hbf')
    _ = (Cf * Cg) * ((d + 1 : ℝ) ^ (df + dg)) * ((B + 1 : ℝ) ^ (df + dg)) * ((L + 1 : ℝ) ^ (df + dg)) := by
          simp only [pow_add]; ring

theorem c12_isBoundedByPoly3_of_poly1_d {f : ℕ → ℝ} (hf : IsBoundedByPoly1 f) :
    IsBoundedByPoly3 (fun d _ _ => f d) := by
  obtain ⟨C, deg, hC, hb⟩ := hf
  refine ⟨C, deg, hC, fun d B L => ?_⟩
  have hBL : (1 : ℝ) ≤ ((B + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg) := by
    have : (1 : ℝ) ≤ (B + 1 : ℝ) ^ deg := one_le_pow₀ (by linarith)
    have : (1 : ℝ) ≤ (L + 1 : ℝ) ^ deg := one_le_pow₀ (by linarith)
    nlinarith
  calc f d ≤ C * ((d + 1 : ℝ) ^ deg) * 1 := by linarith [hb d]
    _ ≤ C * ((d + 1 : ℝ) ^ deg) * (((B + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg)) :=
          mul_le_mul_of_nonneg_left hBL (by positivity)
    _ = C * ((d + 1 : ℝ) ^ deg) * ((B + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg) := by ring

theorem c12_isBoundedByPoly3_of_poly2_dB {f : ℕ → ℕ → ℝ} (hf : IsBoundedByPoly2 f) :
    IsBoundedByPoly3 (fun d B _ => f d B) := by
  obtain ⟨C, deg, hC, hb⟩ := hf
  refine ⟨C, deg, hC, fun d B L => ?_⟩
  have hL : (1 : ℝ) ≤ (L + 1 : ℝ) ^ deg := one_le_pow₀ (by linarith)
  calc f d B ≤ C * ((d + 1 : ℝ) ^ deg) * ((B + 1 : ℝ) ^ deg) * 1 := by linarith [hb d B]
    _ ≤ C * ((d + 1 : ℝ) ^ deg) * ((B + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg) :=
          mul_le_mul_of_nonneg_left hL (by positivity)

theorem c12_isBoundedByPoly3_ceil {f : ℕ → ℕ → ℕ → ℝ} (hf : IsBoundedByPoly3 f) :
    IsBoundedByPoly3 (fun d B L => ((Nat.ceil (f d B L) : ℕ) : ℝ)) := by
  have h1 : IsBoundedByPoly3 (fun d B L => f d B L + 1) :=
    c12_isBoundedByPoly3_add hf (c12_isBoundedByPoly3_const 1)
  obtain ⟨C, deg, hC, hb⟩ := h1
  refine ⟨C, deg, hC, fun d B L => ?_⟩
  by_cases hpos : 0 < f d B L
  · exact (le_of_lt (Nat.ceil_lt_add_one hpos.le)).trans (hb d B L)
  · dsimp only
    have h0 : Nat.ceil (f d B L) = 0 := Nat.ceil_eq_zero.mpr (not_lt.mp hpos)
    rw [h0]; simp only [Nat.cast_zero]; positivity

/-! ### 2. Guarantee Monotonicity Helpers -/

theorem c12_satisfiesLasVegasGuarantee_mono {d n : ℕ} {State : Type}
    {c B₁ B₂ : ℝ} {adm : Set (EuclideanSpace ℝ (Fin d))}
    {alg : DynamicDiameterStructure d State}
    (h : SatisfiesLasVegasGuarantee n c B₁ adm alg) (hle : B₁ ≤ B₂) :
    SatisfiesLasVegasGuarantee n c B₂ adm alg :=
  ⟨h.1, fun adv hadv T hT =>
    let ⟨hfin, hbd⟩ := h.2 adv hadv T hT
    ⟨hfin, hbd.trans hle⟩⟩

theorem c12_satisfiesUnboundedSpaceBound_mono {d n : ℕ} {State : Type}
    {S₁ S₂ : ℝ} {adm : Set (EuclideanSpace ℝ (Fin d))}
    {alg : DynamicDiameterStructure d State}
    (h : SatisfiesUnboundedSpaceBound n adm alg S₁) (hle : S₁ ≤ S₂) :
    SatisfiesUnboundedSpaceBound n adm alg S₂ :=
  ⟨h.1.trans hle, fun adv hadv T tr out hr => (h.2 adv hadv T tr out hr).trans hle⟩

/-! ### 3. Master Reduction Theorem `c12_lasVegas_of_step_sim` (Conjunct 4 of Claim 7.3) -/

/-- Master reduction theorem for Conjunct (4) of `S_clm_7_3_las_vegas_endpoint`:
combines `d = 0` (`prove_part4_dim0`), the handle-ordered `SyncCertifiedNodeConstructor` from
`S_lem_A_2` + `S_claim_A_2_deletion_witness` (`c12_build_syncCtorA2`), the synchronous suffix
schedule (`S_claim_C_3_sync_suffix`), and the Kraft lockstep transfer (`c12_lasVegas_dpos_of_step_sim`),
reducing the entire Las Vegas endpoint guarantee to single-step `BitRAM` forward simulation over
`ChainStoredInv` for `d ≥ 1`. -/
theorem c12_lasVegas_of_step_sim
    (h_lem_5_2 : S_lem_5_2)
    (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction)
    (h_clm_5_1_block_witness : S_clm_5_1_block_witness)
    (h_claim_A_2 : S_claim_A_2_deletion_witness)
    (h_lem_A_2 : S_lem_A_2)
    (h_claim_C_3_sync_suffix : S_claim_C_3_sync_suffix)
    (hstep_all :
      ∀ (s₀ : ℕ → ℕ) (progA2 : BitRAMStmt)
        (timeA2 spaceA2 bitLenA2 : ℕ → ℕ → ℝ),
        (∀ d : ℕ, 1 ≤ s₀ d) →
        IsBoundedByPoly1 (fun d => (s₀ d : ℝ)) →
        IsBoundedByPoly2 timeA2 → (∀ d B : ℕ, 1 ≤ timeA2 d B) →
        IsBoundedByPoly2 spaceA2 → (∀ d B : ℕ, 1 ≤ spaceA2 d B) →
        IsBoundedByPoly2 bitLenA2 → (∀ d B : ℕ, 1 ≤ bitLenA2 d B) →
        ∃ (P_step_fn K_sim_fn Space_per_n_fn : ℕ → ℕ → ℕ → ℕ),
          IsBoundedByPoly3 (fun d B L => (P_step_fn d B L : ℝ)) ∧
          IsBoundedByPoly3 (fun d B L => (K_sim_fn d B L : ℝ)) ∧
          IsBoundedByPoly3 (fun d B L => (Space_per_n_fn d B L : ℝ)) ∧
          ∀ (d n B : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ B →
            let L : ℕ := Nat.clog 2 (2 * n)
            ∀ (ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d (s₀ d))),
              (∀ (hist : ExecutionHistory d)
                (sufPref : List (SyncSuffixPrefixEntry d (PosDimNodeData d (s₀ d))))
                (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
                (P₀ : Finset ℕ) (bs : List Bool)
                (built : SyncBuiltNode d (PosDimNodeData d (s₀ d))),
                2 * s₀ d ≤ P₀.card →
                (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) →
                ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
                  ∃ outA2 : BitRAMExecOutcome,
                    C12CertifiedNodeSpec (s₀ d) B progA2 spaceA2 bitLenA2
                      (c12ReplayHistory d hist) ltCoords P₀ bs built outA2) →
              ∃ (updStmt : BitRAMStmt) (B_cert K_max W K_cancel : ℕ),
                ∀ (c₁ C_nodes : ℝ), 0 < c₁ → 0 < C_nodes →
                  (∀ (P : Finset ℕ), P.card ≤ n →
                    ∀ (k : ℕ) (nodes : Fin k → ChainNode d)
                      (P₀ : Fin k → Finset ℕ)
                      (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
                      (age : Fin k → ℕ)
                      (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)),
                      (∀ i : Fin k,
                        (nodes i).o = o i ∧
                        (nodes i).V = liftVariance (o i) (s i) ∧
                        1 ≤ (P₀ i).card ∧
                        IsCenterpoint (1 / (4 * (s₀ d : ℝ)))
                          (paraboloidLiftSet (fun j : P₀ i => ltCoords j.1)) (liftedPoint (o i) (s i)) ∧
                        HasNodeAge (P₀ i) (chainInput ltCoords nodes P i.castSucc) (age i) ∧
                        (age i : ℝ) ≤ (1 / (4 * (s₀ d : ℝ))) * ((P₀ i).card : ℝ) / 16) →
                      (k : ℝ) ≤ C_nodes * (1 / (4 * (s₀ d : ℝ)))⁻¹ * Real.log ((n : ℝ) + 1)) →
                  ∀ (cur syncNext : SyncSchedulePrefixState d (PosDimNodeData d (s₀ d)))
                    (qMap : ℕ → Fin d → ℚ) (ws : WordStore) (op : DynamicUpdate d) (bs : List Bool)
                    (inp : BitRAMInput d),
                    C12SyncInv (s₀ d) B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) cur →
                    cur.nodes.length + 1 ≤ Nat.ceil ((C_nodes + 1) * 4) * s₀ d * L →
                    C_nodes * (4 * (s₀ d : ℝ)) * Real.log ((n : ℝ) + 1) ≤
                      ((Nat.ceil ((C_nodes + 1) * 4) * s₀ d * L : ℕ) : ℝ) →
                    ChainStoredInv n L B B_cert K_max W cur.pointSet cur.ltCoords cur.nodes qMap ws →
                    IsLegalUpdate n (RatAdmissiblePointSet d B) cur.pointSet op →
                    C12SyncStepDecomp (s₀ d) L ctor cur syncNext op bs →
                    inp.activeHandles = cur.pointSet.activeHandles →
                    (∀ h ∈ cur.pointSet.activeHandles, inp.activeRatCoords h = qMap h) →
                    (match op with
                     | .insert _ _ pt =>
                         ∃ qIns : Fin d → ℚ,
                           RatPointBitBounded B qIns ∧
                           ratPointToEuclidean qIns = pt ∧
                           inp.intParams = [(n : ℤ), 1, 0] ∧
                           inp.extraRats = List.ofFn qIns
                     | .delete id =>
                         inp.intParams = [(n : ℤ), 0, (cur.pointSet.handleOfId id : ℤ)] ∧
                         inp.extraRats = []) →
                    inp.inputCellSpace ≤ n * (2 * d + 1) + 2 * d + 3 →
                    inp.inputBitSpace ≤ n * (L + 1 + d * (2 * B + 1)) + d * (2 * B + 1) + 2 * L + 8 →
                    ∃ (rawOut : BitRAMExecOutcome) (qMap' : ℕ → Fin d → ℚ),
                      runBitRAMWithBits updStmt inp ws bs = some rawOut ∧
                      ChainStoredInv n L B B_cert K_max W
                        syncNext.pointSet syncNext.ltCoords syncNext.nodes qMap' rawOut.words ∧
                      (match op with
                       | .insert _ _ _ =>
                           rawOut.words.read (.heap 0 0) = (mexHandle cur.pointSet.activeHandles : ℤ)
                       | .delete _ => True) ∧
                      (let ca := BitRAMDynamicProgram.readCachedAnswer rawOut.words
                       ({ diameterHandles := ca.1, cachedDistSq := ca.2 } : StoredDiameterAnswer) =
                         ramCheckedAnswer L syncNext.pointSet syncNext.nodes) ∧
                      rawOut.bitCost + K_cancel * c12ChainBirthPot syncNext ≤
                        P_step_fn d B L + K_cancel * c12ChainBirthPot cur +
                          K_sim_fn d B L * (syncNext.totalRebuildWork - cur.totalRebuildWork) ∧
                      rawOut.peakBitSpace ≤ n * Space_per_n_fn d B L) :
    ∃ (spacePoly timePoly : ℕ → ℕ → ℕ → ℝ) (queryConst writeFactor : ℕ),
      IsBoundedByPoly3 spacePoly ∧ IsBoundedByPoly3 timePoly ∧
      ∀ (d n B : ℕ), 2 ≤ n → 1 ≤ B →
        let L : ℕ := Nat.clog 2 (2 * n)
        ∃ (prog : BitRAMDynamicProgram) (initOut : BitRAMExecOutcome),
          prog.evalInit n d = some initOut ∧
          let alg : DynamicDiameterStructure d WordStore :=
            { initState := initOut.words
              initWork := initOut.bitCost
              initSpace := initOut.peakBitSpace
              cachedAnswer := fun ws =>
                let ca := BitRAMDynamicProgram.readCachedAnswer ws
                { diameterHandles := ca.1, cachedDistSq := ca.2 }
              retrieveIdsAndRefCost := 5
              writeOutputCost := fun len => len + 1
              stepWithBits := fun activeH hCoords ws uop bs =>
                let rawOut :=
                  match uop with
                  | .insert pt => prog.evalUpdate n activeH hCoords ws true pt 0 bs
                  | .delete h => prog.evalUpdate n activeH hCoords ws false 0 h bs
                rawOut.map (fun out =>
                  let ca := BitRAMDynamicProgram.readCachedAnswer out.words
                  { nextState := out.words
                    returnedHandle :=
                      match uop with
                      | .insert _ => BitRAMDynamicProgram.readReturnedHandle out.words
                      | .delete _ => none
                    storedAnswer := { diameterHandles := ca.1, cachedDistSq := ca.2 }
                    work := out.bitCost
                    peakSpace := out.peakBitSpace }) }
          SatisfiesDynamicStorageAndQueryModel queryConst writeFactor alg ∧
          SatisfiesLasVegasGuarantee n (Real.sqrt 2) (timePoly d B L)
            (RatAdmissiblePointSet d B) alg ∧
          SatisfiesUnboundedSpaceBound n (RatAdmissiblePointSet d B) alg
            ((n : ℝ) * spacePoly d B L) := by
  classical
  obtain ⟨s₀, progA2, timeA2, spaceA2, bitLenA2,
    hs₀_pos, hs₀_poly, htime_poly, htime_ge1, hspace_poly, hspace_ge1, hbl_poly, hbl_ge1,
    hPn_poly, hPn_nn, hctor_all⟩ :=
    c12_build_syncCtorA2 h_lem_A_2 h_claim_A_2
  let P_node : ℕ → ℕ → ℕ → ℝ := fun d B L => 2 * (((L : ℝ) + 1) ^ 2) * timeA2 d B + 2
  let P_α : ℕ → ℝ := fun d => 4 * (s₀ d : ℝ)
  have hPα_poly : IsBoundedByPoly1 P_α :=
    c12_isBoundedByPoly1_mul_const hs₀_poly (by norm_num)
  have hPα_ge1 : ∀ d : ℕ, 1 ≤ P_α d := fun d => by
    have : (1 : ℝ) ≤ (s₀ d : ℝ) := by exact_mod_cast hs₀_pos d
    dsimp [P_α]; linarith
  obtain ⟨c_chg, C_sum, C_charge, P_suf, B_card, P_tot,
    _, _, _, _, _, _, _, hPtot_poly, hPtot_nn, hC3_spec⟩ :=
    h_claim_C_3_sync_suffix P_α P_node hPα_poly hPα_ge1 hPn_poly hPn_nn
  obtain ⟨P_step_fn, K_sim_fn, Space_per_n_fn,
    hPstep_poly, hKsim_poly, hSp_poly, hsim_dpos⟩ :=
    hstep_all s₀ progA2 timeA2 spaceA2 bitLenA2
      hs₀_pos hs₀_poly htime_poly htime_ge1 hspace_poly hspace_ge1 hbl_poly hbl_ge1
  -- Unified polynomial bounds covering both `d = 0` and `1 ≤ d`
  let timeDim0 : ℕ → ℕ → ℕ → ℝ :=
    fun _ _ L => (260 * (L : ℝ) + 321) * (((L : ℝ) + 24) * ((L : ℝ) + 24))
  let timeDpos : ℕ → ℕ → ℕ → ℝ :=
    fun d B L => 1 + (P_step_fn d B L : ℝ) + (K_sim_fn d B L : ℝ) * P_tot d B L
  let timePoly : ℕ → ℕ → ℕ → ℝ := fun d B L => timeDim0 d B L + timeDpos d B L
  let spacePoly : ℕ → ℕ → ℕ → ℝ :=
    fun d B L => 120 * ((L : ℝ) + 24) + ((L : ℝ) + 2 + (Space_per_n_fn d B L : ℝ))
  have hL_p3 : IsBoundedByPoly3 (fun _ _ L => (L : ℝ)) := c12_isBoundedByPoly3_L
  have hL24_p3 : IsBoundedByPoly3 (fun _ _ L => (L : ℝ) + 24) :=
    c12_isBoundedByPoly3_add hL_p3 (c12_isBoundedByPoly3_const 24)
  have h260L_p3 : IsBoundedByPoly3 (fun _ _ L => 260 * (L : ℝ) + 321) :=
    c12_isBoundedByPoly3_add
      (c12_isBoundedByPoly3_mul_nonneg (c12_isBoundedByPoly3_const 260) hL_p3
        (fun _ _ _ => by norm_num) (fun _ _ _ => Nat.cast_nonneg _))
      (c12_isBoundedByPoly3_const 321)
  have htimeDim0_p3 : IsBoundedByPoly3 timeDim0 :=
    c12_isBoundedByPoly3_mul_nonneg h260L_p3
      (c12_isBoundedByPoly3_mul_nonneg hL24_p3 hL24_p3
        (fun _ _ _ => by positivity) (fun _ _ _ => by positivity))
      (fun _ _ _ => by positivity) (fun _ _ _ => by positivity)
  have htimeDpos_p3 : IsBoundedByPoly3 timeDpos :=
    c12_isBoundedByPoly3_add
      (c12_isBoundedByPoly3_add (c12_isBoundedByPoly3_const 1) hPstep_poly)
      (c12_isBoundedByPoly3_mul_nonneg hKsim_poly hPtot_poly
        (fun _ _ _ => Nat.cast_nonneg _) hPtot_nn)
  have htime_p3 : IsBoundedByPoly3 timePoly :=
    c12_isBoundedByPoly3_add htimeDim0_p3 htimeDpos_p3
  have hspace_p3 : IsBoundedByPoly3 spacePoly :=
    c12_isBoundedByPoly3_add
      (c12_isBoundedByPoly3_mul_nonneg (c12_isBoundedByPoly3_const 120) hL24_p3
        (fun _ _ _ => by norm_num) (fun _ _ _ => by positivity))
      (c12_isBoundedByPoly3_add
        (c12_isBoundedByPoly3_add hL_p3 (c12_isBoundedByPoly3_const 2))
        hSp_poly)
  refine ⟨spacePoly, timePoly, 5, 1, hspace_p3, htime_p3, ?_⟩
  intro d n B hn hB L
  cases d with
  | zero =>
      obtain ⟨prog, initOut, heval, hStore, hLV, hSp⟩ := prove_part4_dim0 hn hB
      refine ⟨prog, initOut, heval, hStore, ?_, ?_⟩
      · refine c12_satisfiesLasVegasGuarantee_mono hLV ?_
        have hdpos_nn : 0 ≤ timeDpos 0 B L := by
          dsimp [timeDpos]
          have := hPtot_nn 0 B L
          positivity
        have ht0_eq : ((((260 * L + 321) * (L + 24) * (L + 24) : ℕ) : ℝ)) = timeDim0 0 B L := by
          dsimp [timeDim0]; push_cast; ring
        rw [ht0_eq]; dsimp [timePoly]; linarith
      · refine c12_satisfiesUnboundedSpaceBound_mono hSp ?_
        have hextra_nn : 0 ≤ (L : ℝ) + 2 + (Space_per_n_fn 0 B L : ℝ) := by positivity
        have hs0_eq : ((120 * (L + 24) : ℕ) : ℝ) = 120 * ((L : ℝ) + 24) := by push_cast; ring
        rw [hs0_eq]
        refine mul_le_mul_of_nonneg_left ?_ (Nat.cast_nonneg n)
        dsimp [spacePoly]; linarith
  | succ d' =>
      have hd1 : 1 ≤ d' + 1 := Nat.succ_pos d'
      set d_pos := d' + 1
      obtain ⟨ctor, hctor_valid, hctor_spec⟩ := hctor_all d_pos B n hd1 hB hn
      have hctor_wk : ∀ hist sufPref ltCoords P₀ bs built,
          2 * s₀ d_pos ≤ P₀.card →
          (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d_pos B) →
          ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
            P₀.card ≤ built.work := by
        intro hist sufPref ltCoords P₀ bs built hm hadm hb
        obtain ⟨outA2, hsp⟩ := hctor_spec hist sufPref ltCoords P₀ bs built hm hadm hb
        have hweq := hsp.work_eq
        omega
      have hs₀_R : (1 : ℝ) ≤ (s₀ d_pos : ℝ) := by exact_mod_cast hs₀_pos d_pos
      have hα_pos : 0 < (1 / (4 * (s₀ d_pos : ℝ))) := by positivity
      have hα_le1 : (1 / (4 * (s₀ d_pos : ℝ))) ≤ 1 := by
        rw [div_le_one (by positivity)]; linarith
      have hsqrt2_ge1 : (1 : ℝ) ≤ Real.sqrt 2 := by
        rw [← Real.sqrt_one]
        exact Real.sqrt_le_sqrt (by norm_num)
      have hC3_inst := hC3_spec d_pos B n (2 * s₀ d_pos - 1) (PosDimNodeData d_pos (s₀ d_pos))
        (1 / (4 * (s₀ d_pos : ℝ))) (Real.sqrt 2) 1 (RatAdmissiblePointSet d_pos B)
        ctor (ansPolPosDim d_pos (s₀ d_pos) L)
        hB hn hα_pos hα_le1 le_rfl hsqrt2_ge1 zero_le_one hctor_valid
        isValidSyncCheckedAnswerPolicy_ansPolPosDim
      have hC3_tot : ∀ adv : AdaptiveAdversary d_pos,
          IsValidSyncAdaptiveAdversary n (2 * s₀ d_pos - 1) (1 / (4 * (s₀ d_pos : ℝ)))
            (RatAdmissiblePointSet d_pos B) ctor (ansPolPosDim d_pos (s₀ d_pos) L) adv →
          ∀ T : ℕ, 1 ≤ T →
            syncPrefixExpectedRebuildWork (2 * s₀ d_pos - 1) (1 / (4 * (s₀ d_pos : ℝ))) ctor
              (ansPolPosDim d_pos (s₀ d_pos) L) adv T ≠ ⊤ ∧
            (syncPrefixExpectedRebuildWork (2 * s₀ d_pos - 1) (1 / (4 * (s₀ d_pos : ℝ))) ctor
              (ansPolPosDim d_pos (s₀ d_pos) L) adv T).toReal ≤
              (T : ℝ) * 1 * P_tot d_pos B L := by
        intro adv hadv T hT
        have h2 := (hC3_inst.2 adv hadv).2 T hT
        exact ⟨h2.2.1, h2.2.2⟩
      obtain ⟨updStmt, B_cert, K_max, W, K_cancel, hsim_inst⟩ :=
        hsim_dpos d_pos n B hd1 hn hB ctor hctor_spec
      obtain ⟨heval, hStore, hLV, hSp⟩ :=
        c12_lasVegas_dpos_of_step_sim hd1 hn hB (hs₀_pos d_pos)
          h_lem_5_2 h_clm_5_1_chain_contraction h_clm_5_1_block_witness
          (hPn_nn d_pos B L) hctor_valid hctor_wk hC3_tot
          (B_cert := B_cert) (K_max := K_max) (W := W) (K_cancel := K_cancel)
          (P_step := P_step_fn d_pos B L) (K_sim := K_sim_fn d_pos B L)
          (Space_bound := n * Space_per_n_fn d_pos B L) (updStmt := updStmt)
          hsim_inst
      refine ⟨{ initStmt := .skip, updateStmt := updStmt }, _, heval, hStore, ?_, ?_⟩
      · refine c12_satisfiesLasVegasGuarantee_mono hLV ?_
        have hdim0_nn : 0 ≤ timeDim0 d_pos B L := by dsimp [timeDim0]; positivity
        dsimp [timePoly, timeDpos]
        linarith
      · refine c12_satisfiesUnboundedSpaceBound_mono hSp ?_
        obtain ⟨_, _, h2n_pow, _⟩ := clog_two_mul_bounds hn
        change 2 * n ≤ 2 ^ L at h2n_pow
        have hn_bl : intBitLength (n : ℤ) ≤ L + 2 :=
          nat_lt_pow2_bitLength_le (by omega : n < 2 ^ L)
        have hn_ge1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (show 1 ≤ n by omega)
        have hbl_le : (intBitLength (n : ℤ) : ℝ) ≤ (n : ℝ) * spacePoly d_pos B L := by
          have h1 : (intBitLength (n : ℤ) : ℝ) ≤ (L : ℝ) + 2 := by exact_mod_cast hn_bl
          have h2 : (L : ℝ) + 2 ≤ spacePoly d_pos B L := by
            dsimp [spacePoly]
            have : 0 ≤ 120 * ((L : ℝ) + 24) := by positivity
            have : 0 ≤ (Space_per_n_fn d_pos B L : ℝ) := Nat.cast_nonneg _
            linarith
          have hsp_nn : 0 ≤ spacePoly d_pos B L := by linarith
          calc (intBitLength (n : ℤ) : ℝ) ≤ 1 * spacePoly d_pos B L := by linarith
            _ ≤ (n : ℝ) * spacePoly d_pos B L := mul_le_mul_of_nonneg_right hn_ge1 hsp_nn
        have hsp_le : ((n * Space_per_n_fn d_pos B L : ℕ) : ℝ) ≤ (n : ℝ) * spacePoly d_pos B L := by
          push_cast
          refine mul_le_mul_of_nonneg_left ?_ (Nat.cast_nonneg n)
          dsimp [spacePoly]
          have : 0 ≤ 120 * ((L : ℝ) + 24) + ((L : ℝ) + 2) := by positivity
          linarith
        exact max_le hbl_le hsp_le

end UL.C12LVE
