import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG02_StepC2f
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.CG02StepC2

open UL.C12StepC2

open UL.C12LVE
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### `c07_stepC2Provider`: Instantiating `C11StepC2Provider` for `clm_7_3_las_vegas_endpoint` -/

theorem cg02_stepC2Provider : C11StepC2Provider := by
  intro _h_lem_A_2 _h_del_wit s₀ progA2 _timeA2 spaceA2 bitLenA2
    hs₀_pos hs₀_poly _htime_poly _htime_ge1 hspace_poly hspace_ge1 hbl_poly hbl_ge1
    C_K _hCK_ge1
  let T_max : ℕ := max 4 (maxTableStmt progA2)
  let F : ℕ := max 64 (a2StmtFactor progA2)
  let B_cert_fn : ℕ → ℕ → ℕ → ℕ := fun d B _ => Nat.ceil (bitLenA2 d B) + 1
  let s₀_fn : ℕ → ℕ → ℕ → ℕ := fun d _ _ => s₀ d
  let K_max_fn : ℕ → ℕ → ℕ → ℕ := fun d _ L => C_K * s₀ d * L
  let spCeil_fn : ℕ → ℕ → ℕ → ℕ := fun d B _ => Nat.ceil (spaceA2 d B) + 1
  let W_c2_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    c07WordSizeReq d (s₀_fn d B L) B (B_cert_fn d B L) L (K_max_fn d B L) T_max
  have hd_p3 : IsBoundedByPoly3 (fun d (_ : ℕ) (_ : ℕ) => (d : ℝ)) := poly3_var_d
  have hB_p3 : IsBoundedByPoly3 (fun (_ : ℕ) B (_ : ℕ) => (B : ℝ)) := poly3_var_B
  have hL_p3 : IsBoundedByPoly3 (fun (_ : ℕ) (_ : ℕ) L => (L : ℝ)) := poly3_var_L
  have hs₀_p3 : IsBoundedByPoly3 (fun d B L => (s₀_fn d B L : ℝ)) :=
    poly3_of_poly1_d hs₀_poly
  have hBc_p3 : IsBoundedByPoly3 (fun d B L => (B_cert_fn d B L : ℝ)) := by
    have hceil : IsBoundedByPoly3 (fun d B _ => (Nat.ceil (bitLenA2 d B) : ℝ)) :=
      poly3_natCeil (poly3_of_poly2_dB hbl_poly) (fun d B _ => by linarith [hbl_ge1 d B])
    exact poly3_nat_add (f := fun d B _ => Nat.ceil (bitLenA2 d B)) (g := fun _ _ _ => 1)
      hceil (poly3_nat_const 1)
  have hspCeil_p3 : IsBoundedByPoly3 (fun d B L => (spCeil_fn d B L : ℝ)) := by
    have hceil : IsBoundedByPoly3 (fun d B _ => (Nat.ceil (spaceA2 d B) : ℝ)) :=
      poly3_natCeil (poly3_of_poly2_dB hspace_poly) (fun d B _ => by linarith [hspace_ge1 d B])
    exact poly3_nat_add (f := fun d B _ => Nat.ceil (spaceA2 d B)) (g := fun _ _ _ => 1)
      hceil (poly3_nat_const 1)
  have hK_p3 : IsBoundedByPoly3 (fun d B L => (K_max_fn d B L : ℝ)) :=
    poly3_nat_mul (f := fun d B L => C_K * s₀_fn d B L) (g := fun _ _ L => L)
      (poly3_nat_mul (f := fun _ _ _ => C_K) (g := s₀_fn) (poly3_nat_const C_K) hs₀_p3)
      hL_p3
  have hsq_p3 : IsBoundedByPoly3 (fun d B L => (sqRadBitBound d B (B_cert_fn d B L) : ℝ)) := by
    unfold sqRadBitBound
    exact poly3_nat_add
      (poly3_nat_mul (poly3_nat_add hd_p3 (poly3_nat_const 1))
        (poly3_nat_add
          (poly3_nat_mul (poly3_nat_const 2)
            (poly3_nat_add (poly3_nat_add hB_p3 (poly3_nat_const 2)) hBc_p3))
          (poly3_nat_const 4)))
      (poly3_nat_const 4)
  have hWc2_p3 : IsBoundedByPoly3 (fun d B L => (W_c2_fn d B L : ℝ)) := by
    dsimp only [W_c2_fn]
    unfold c07WordSizeReq
    have p1 := poly3_nat_mul (poly3_nat_const 2) hsq_p3
    have p2 := poly3_nat_add
      (poly3_nat_add
        (poly3_nat_mul (poly3_nat_add hK_p3 (poly3_nat_const 2))
          (poly3_nat_add (poly3_nat_mul (poly3_nat_const 2) hd_p3) (poly3_nat_const 9)))
        hL_p3)
      (poly3_nat_const 1)
    have p3 := poly3_nat_add
      (poly3_nat_add
        (poly3_nat_mul
          (poly3_nat_add (poly3_nat_mul (poly3_nat_const 2) hd_p3) (poly3_nat_const 5))
          (poly3_nat_const T_max))
        hL_p3)
      (poly3_nat_const 1)
    have p4 := poly3_nat_add hs₀_p3 (poly3_nat_const 2)
    have p5 := poly3_nat_add hd_p3 (poly3_nat_const 1)
    exact poly3_nat_add
      (poly3_nat_add (poly3_nat_add (poly3_nat_add (poly3_nat_add (poly3_nat_add p1 p2) p3) p4) p5) hL_p3)
      (poly3_nat_const 64)
  refine ⟨W_c2_fn, hWc2_p3, fun W_fn hW_p3 hW_ge => ?_⟩
  let A2_cell_per_n_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    c07A2CellPerN d (spCeil_fn d B L)
  let A2_bit_per_n_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    c07A2BitPerN d L T_max (spCeil_fn d B L) (W_fn d B L)
  let K_c2_u_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    c07StepC2UnitFactorFull d L F (spCeil_fn d B L)
  let K_c2_b_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    c07StepC2BitFactor d L T_max F (spCeil_fn d B L) (W_fn d B L)
  have hSbits_p3 : IsBoundedByPoly3 (fun d B L => ((spCeil_fn d B L + L + 6 : ℕ) : ℝ)) :=
    poly3_nat_add (poly3_nat_add hspCeil_p3 hL_p3) (poly3_nat_const 6)
  have hA2b_p3 : IsBoundedByPoly3 (fun d B L => (A2_bit_per_n_fn d B L : ℝ)) := by
    dsimp only [A2_bit_per_n_fn]
    unfold c07A2BitPerN
    dsimp only
    have q1 := poly3_nat_mul (poly3_nat_mul (poly3_nat_const 2) hW_p3)
      (poly3_nat_add (poly3_nat_mul (poly3_nat_const 2) hd_p3) (poly3_nat_const 10))
    have q2 := poly3_nat_mul (poly3_nat_const 16) (poly3_nat_add hW_p3 (poly3_nat_const 12))
    have q3 := poly3_nat_mul
      (poly3_nat_mul
        (poly3_nat_add
          (poly3_nat_add (poly3_nat_const (3 * T_max))
            (poly3_nat_mul (poly3_nat_const 2) hSbits_p3))
          (poly3_nat_const 52))
        hL_p3)
      hspCeil_p3
    have q4 := poly3_nat_mul
      (poly3_nat_mul (poly3_nat_const 4) (poly3_nat_add hspCeil_p3 (poly3_nat_const 1)))
      (poly3_nat_add hSbits_p3 (poly3_nat_const 12))
    have q5 := poly3_nat_const (16 * T_max)
    have q6 := poly3_nat_mul (poly3_nat_const 24) hSbits_p3
    have q7 := poly3_nat_const 320
    exact poly3_nat_add (poly3_nat_add (poly3_nat_add (poly3_nat_add (poly3_nat_add (poly3_nat_add q1 q2) q3) q4) q5) q6) q7
  have hKc2b_p3 : IsBoundedByPoly3 (fun d B L => (K_c2_b_fn d B L : ℝ)) := by
    dsimp only [K_c2_b_fn]
    unfold c07StepC2BitFactor
    dsimp only
    have hKub_p3 := poly3_nat_add
      (poly3_nat_add
        (poly3_nat_add (poly3_nat_add hL_p3 hd_p3) (poly3_nat_const T_max))
        (poly3_nat_const 16))
      hSbits_p3
    have r1 := poly3_nat_mul (poly3_nat_const (8 * F)) hKub_p3
    have r2 := poly3_nat_mul
      (poly3_nat_mul
        (poly3_nat_add
          (poly3_nat_add (poly3_nat_mul (poly3_nat_const 196) hd_p3)
            (poly3_nat_mul (poly3_nat_const 408) hL_p3))
          (poly3_nat_const 1400))
        hW_p3)
      hW_p3
    have r3 := poly3_nat_mul
      (poly3_nat_mul
        (poly3_nat_mul (poly3_nat_const 8)
          (poly3_nat_add
            (poly3_nat_add (poly3_nat_const (3 * T_max))
              (poly3_nat_mul (poly3_nat_const 2) hSbits_p3))
            (poly3_nat_const 40)))
        hL_p3)
      hspCeil_p3
    have r4 := poly3_nat_mul hspCeil_p3
      (poly3_nat_add (poly3_nat_mul (poly3_nat_const 72) hSbits_p3) (poly3_nat_const 512))
    have r5 := poly3_nat_mul (poly3_nat_const 28) hSbits_p3
    have r6 := poly3_nat_const 400
    exact poly3_nat_add (poly3_nat_add (poly3_nat_add (poly3_nat_add (poly3_nat_add r1 r2) r3) r4) r5) r6
  refine ⟨A2_cell_per_n_fn, A2_bit_per_n_fn, K_c2_u_fn, K_c2_b_fn,
    hKc2b_p3, hA2b_p3, fun d n B hd1 hn hB1 => ?_⟩
  dsimp only
  intro ctor _hctor_valid hctor_cert
  set L := Nat.clog 2 (2 * n)
  have hBc1 : 1 ≤ Nat.ceil (bitLenA2 d B) + 1 := by omega
  have hBc_ge : bitLenA2 d B ≤ ((Nat.ceil (bitLenA2 d B) + 1 : ℕ) : ℝ) := by
    have hc : bitLenA2 d B ≤ (Nat.ceil (bitLenA2 d B) : ℝ) := Nat.le_ceil _
    push_cast; linarith only [hc]
  exact ⟨c07StepC2Stmt d (s₀ d) L B T_max progA2 .heap0_10,
    exec_c07StepC2Stmt_spec hd1 (hs₀_pos d) hn rfl hB1 hBc1 (hspace_ge1 d B) hBc_ge
      (hW_ge d B L) hctor_cert .heap0_10⟩

end UL.CG02StepC2

namespace UL.C12LVE

theorem cg02_stepC2Provider : C11StepC2Provider :=
  UL.CG02StepC2.cg02_stepC2Provider

end UL.C12LVE
