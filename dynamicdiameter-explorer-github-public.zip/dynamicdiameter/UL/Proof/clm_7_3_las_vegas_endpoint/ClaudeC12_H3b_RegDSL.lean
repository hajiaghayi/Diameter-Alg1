import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2c2a_StoreBase
set_option autoImplicit false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. 16-Register Local-Frame Relational State (`HasRegFrame`) -/

def keepBelowDepth (fd : ℕ) : RAMCellLoc → Bool
  | .heap _ _ => true
  | .localFrame d' _ _ => decide (d' < fd)

structure HasRegFrame (fd : ℕ) (wsHeap : WordStore) (regs : ℕ → ℤ) (ws : WordStore) : Prop where
  wfHeap : WellFormedWS wsHeap
  wf : WellFormedWS ws
  heapClean : ∀ d' ≥ fd, ∀ v i, (.localFrame d' v i : RAMCellLoc) ∉ wsHeap.live
  below_live : ∀ loc, keepBelowDepth fd loc = true → (loc ∈ ws.live ↔ loc ∈ wsHeap.live)
  below_vals : ∀ loc, keepBelowDepth fd loc = true → ws.vals loc = wsHeap.vals loc
  above_empty : ∀ d' > fd, ∀ v i, (.localFrame d' v i : RAMCellLoc) ∉ ws.live
  frame_bound : ∀ v i, (.localFrame fd v i : RAMCellLoc) ∈ ws.live → v < 16 ∧ i = 0
  reg_read : ∀ r < 16, ws.read (.localFrame fd r 0) = regs r
  reg_zero : ∀ r ≥ 16, regs r = 0

def RegBounded (W : ℕ) (regs : ℕ → ℤ) : Prop :=
  8 ≤ W ∧ (∀ r < 16, intBitLength (regs r) ≤ W) ∧ (∀ r ≥ 16, regs r = 0)

theorem RegBounded.init {W : ℕ} (hW : 8 ≤ W) : RegBounded W (fun _ => 0) := by
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  exact ⟨hW, fun _ _ => by rw [hl0]; omega, fun _ _ => rfl⟩

theorem RegBounded.update {W : ℕ} {regs : ℕ → ℤ} (hb : RegBounded W regs)
    {r : ℕ} (hr : r < 16) {v : ℤ} (hv : intBitLength v ≤ W) :
    RegBounded W (Function.update regs r v) := by
  refine ⟨hb.1, fun r' hr' => ?_, fun r' hr' => ?_⟩
  · by_cases heq : r' = r
    · subst heq; simp [hv]
    · simp [Function.update_of_ne heq, hb.2.1 r' hr']
  · have hne : r' ≠ r := by omega
    simp [Function.update_of_ne hne, hb.2.2 r' hr']

theorem HasRegFrame.read_heap {fd : ℕ} {wsHeap : WordStore} {regs : ℕ → ℤ} {ws : WordStore}
    (h : HasRegFrame fd wsHeap regs ws) (t : ℕ) (idx : ℤ) :
    ws.read (.heap t idx) = wsHeap.read (.heap t idx) := by
  rw [wordStore_read_eq_vals h.wf, wordStore_read_eq_vals h.wfHeap]
  exact h.below_vals (.heap t idx) rfl

theorem HasRegFrame.enterScope {fd : ℕ} (hfd : 1 ≤ fd) {wsHeap : WordStore}
    (hwf : WellFormedWS wsHeap)
    (hclean : ∀ d' ≥ fd, ∀ v i, (.localFrame d' v i : RAMCellLoc) ∉ wsHeap.live) :
    wsHeap.popDepth (fd - 1) = wsHeap ∧
    HasRegFrame fd wsHeap (fun _ => 0) (wsHeap.popDepth (fd - 1)) := by
  have hpop : wsHeap.popDepth (fd - 1) = wsHeap := by
    cases wsHeap with
    | mk lv vl =>
      unfold WordStore.popDepth; dsimp only
      have hk : ∀ loc ∈ lv, loc.keepAtDepth (fd - 1) = true := by
        intro loc hm
        cases loc with
        | heap _ _ => rfl
        | localFrame d' v i =>
            simp only [RAMCellLoc.keepAtDepth, decide_eq_true_eq]
            by_contra hgt; exact hclean d' (by omega) v i hm
      congr 1
      · ext loc; simp only [Finset.mem_filter, and_iff_left_iff_imp]; exact hk loc
      · funext loc
        by_cases hm : loc ∈ lv
        · rw [if_pos (hk loc hm)]
        · split_ifs
          · rfl
          · exact (hwf loc hm).symm
  refine ⟨hpop, ?_⟩
  rw [hpop]
  exact
    { wfHeap := hwf
      wf := hwf
      heapClean := hclean
      below_live := fun _ _ => Iff.rfl
      below_vals := fun _ _ => rfl
      above_empty := fun d' hd' v i => hclean d' (by omega) v i
      frame_bound := fun v i hm => False.elim (hclean fd le_rfl v i hm)
      reg_read := fun r _ => by simp [WordStore.read, hclean fd le_rfl r 0]
      reg_zero := fun _ _ => rfl }

theorem HasRegFrame.exitScope {fd : ℕ} (hfd : 1 ≤ fd) {wsHeap : WordStore}
    {regs : ℕ → ℤ} {ws : WordStore}
    (h : HasRegFrame fd wsHeap regs ws) :
    ws.popDepth (fd - 1) = wsHeap := by
  have hk_eq : ∀ loc : RAMCellLoc, loc.keepAtDepth (fd - 1) = keepBelowDepth fd loc := by
    intro loc
    cases loc with
    | heap _ _ => rfl
    | localFrame d' _ _ =>
        simp only [RAMCellLoc.keepAtDepth, keepBelowDepth]
        by_cases hlt : d' < fd
        · have hle : d' ≤ fd - 1 := by omega
          simp [hlt, hle]
        · have hgle : ¬ d' ≤ fd - 1 := by omega
          simp [hlt, hgle]
  cases hEqW : ws with
  | mk lvW vlW =>
    cases hEqH : wsHeap with
    | mk lvH vlH =>
      unfold WordStore.popDepth; dsimp only
      have hlv : lvW.filter (fun loc => loc.keepAtDepth (fd - 1) = true) = lvH := by
        ext loc
        rw [Finset.mem_filter, hk_eq]
        constructor
        · rintro ⟨hmW, hk⟩
          have hb := h.below_live loc hk
          rw [hEqW, hEqH] at hb
          exact hb.mp hmW
        · intro hmH
          have hk : keepBelowDepth fd loc = true := by
            cases loc with
            | heap _ _ => rfl
            | localFrame d' v i =>
                simp only [keepBelowDepth, decide_eq_true_eq]
                by_contra hge
                have hc := h.heapClean d' (by omega) v i
                rw [hEqH] at hc; exact hc hmH
          have hb := h.below_live loc hk
          rw [hEqW, hEqH] at hb
          exact ⟨hb.mpr hmH, hk⟩
      refine congrArg₂ WordStore.mk hlv ?_
      · funext loc
        rw [hk_eq]
        by_cases hk : keepBelowDepth fd loc = true
        · rw [if_pos hk]
          have hv := h.below_vals loc hk
          rw [hEqW, hEqH] at hv; exact hv
        · rw [if_neg hk]
          have hnotH : loc ∉ lvH := by
            intro hmH; apply hk
            cases loc with
            | heap _ _ => rfl
            | localFrame d' v i =>
                simp only [keepBelowDepth, decide_eq_true_eq]
                by_contra hge
                have hc := h.heapClean d' (by omega) v i
                rw [hEqH] at hc; exact hc hmH
          have hwfH := h.wfHeap loc
          rw [hEqH] at hwfH
          exact (hwfH hnotH).symm

theorem HasRegFrame.space_le {fd W : ℕ} (hfd_le : fd ≤ 4) {wsHeap : WordStore}
    {regs : ℕ → ℤ} {ws : WordStore}
    (h : HasRegFrame fd wsHeap regs ws)
    (hb : RegBounded W regs) :
    ws.cellCount ≤ wsHeap.cellCount + 16 ∧
    ws.bitSize ≤ wsHeap.bitSize + 16 * (W + 12) := by
  classical
  let regSet : Finset RAMCellLoc := Finset.image (fun r : ℕ => RAMCellLoc.localFrame fd r 0) (Finset.range 16)
  have hcover : ws.live ⊆ wsHeap.live ∪ regSet := by
    intro loc hm
    rw [Finset.mem_union]
    cases loc with
    | heap t idx =>
        exact Or.inl ((h.below_live (.heap t idx) rfl).mp hm)
    | localFrame d' v i =>
        rcases lt_trichotomy d' fd with hlt | rfl | hgt
        · exact Or.inl ((h.below_live _ (by simp [keepBelowDepth, hlt])).mp hm)
        · obtain ⟨hv16, rfl⟩ := h.frame_bound v i hm
          exact Or.inr (Finset.mem_image.mpr ⟨v, Finset.mem_range.mpr hv16, rfl⟩)
        · exact False.elim (h.above_empty d' hgt v i hm)
  have hcard_reg : regSet.card ≤ 16 :=
    Finset.card_image_le.trans (by rw [Finset.card_range])
  have hc_tot : ws.cellCount ≤ wsHeap.cellCount + 16 := by
    have c1 := Finset.card_le_card hcover
    have c2 := Finset.card_union_le wsHeap.live regSet
    unfold WordStore.cellCount
    linarith
  -- Bit size bound
  let liveW : RAMCellLoc → ℕ := fun l =>
    if l ∈ ws.live then l.bitLength + intBitLength (ws.vals l) else 0
  have hbit_eq : ws.bitSize = ∑ l ∈ ws.live, liveW l := by
    unfold WordStore.bitSize
    exact Finset.sum_congr rfl fun l hl => by simp [liveW, hl]
  have hsum_heap : ∑ l ∈ wsHeap.live, liveW l ≤ wsHeap.bitSize := by
    unfold WordStore.bitSize
    refine Finset.sum_le_sum fun l hl => ?_
    have hk : keepBelowDepth fd l = true := by
      cases l with
      | heap _ _ => rfl
      | localFrame d' v i =>
          simp only [keepBelowDepth, decide_eq_true_eq]
          by_contra hge; exact h.heapClean d' (by omega) v i hl
    dsimp [liveW]
    split_ifs with hm
    · rw [h.below_vals l hk]
    · exact Nat.zero_le _
  have hfd_bl : natBitLength fd ≤ 4 := by
    have := natBitLength_mono hfd_le
    have hn4 : natBitLength 4 = 3 := by decide
    omega
  have hsum_reg : ∑ l ∈ regSet, liveW l ≤ 16 * (W + 12) := by
    have himg : ∑ l ∈ regSet, liveW l ≤ ∑ r ∈ Finset.range 16, liveW (.localFrame fd r 0) := by
      -- Prove sum_image_le inline by induction on Finset.range 16
      have hgen : ∀ S : Finset ℕ,
          ∑ y ∈ Finset.image (fun r : ℕ => RAMCellLoc.localFrame fd r 0) S, liveW y ≤
          ∑ r ∈ S, liveW (.localFrame fd r 0) := by
        intro S
        induction S using Finset.induction_on with
        | empty => simp
        | @insert a s ha ih =>
            rw [Finset.image_insert, Finset.sum_insert ha]
            by_cases hm_img : RAMCellLoc.localFrame fd a 0 ∈ Finset.image (fun r : ℕ => RAMCellLoc.localFrame fd r 0) s
            · rw [Finset.insert_eq_of_mem hm_img]; omega
            · rw [Finset.sum_insert hm_img]; omega
      exact hgen (Finset.range 16)
    have hterm : ∑ r ∈ Finset.range 16, liveW (.localFrame fd r 0) ≤
        ∑ _r ∈ Finset.range 16, (W + 12) := by
      refine Finset.sum_le_sum fun r hr => ?_
      have hr16 : r < 16 := Finset.mem_range.mp hr
      have hr_bl : natBitLength r ≤ 4 := by
        have := natBitLength_mono (by omega : r ≤ 15)
        have hn15 : natBitLength 15 = 4 := by decide
        omega
      have hl0 : intBitLength (0 : ℤ) = 1 := by decide
      dsimp [liveW, RAMCellLoc.bitLength]
      split_ifs with hm
      · have hv : ws.vals (.localFrame fd r 0) = regs r := by
          rw [← wordStore_read_eq_vals h.wf]; exact h.reg_read r hr16
        rw [hv, hl0]
        have hreg_W := hb.2.1 r hr16
        linarith
      · exact Nat.zero_le _
    simp only [Finset.sum_const, Finset.card_range, smul_eq_mul] at hterm
    linarith
  -- Union sum bound
  have hunion_le : ∑ l ∈ wsHeap.live ∪ regSet, liveW l ≤
      ∑ l ∈ wsHeap.live, liveW l + ∑ l ∈ regSet, liveW l := by
    have hgen : ∀ A : Finset RAMCellLoc,
        ∑ l ∈ A ∪ regSet, liveW l ≤ ∑ l ∈ A, liveW l + ∑ l ∈ regSet, liveW l := by
      intro A
      induction A using Finset.induction_on with
      | empty => simp
      | @insert a s ha ih =>
          rw [Finset.insert_union, Finset.sum_insert ha]
          by_cases hm : a ∈ s ∪ regSet
          · rw [Finset.insert_eq_of_mem hm]; omega
          · rw [Finset.sum_insert hm]; omega
    exact hgen wsHeap.live
  have hcov_sum := Finset.sum_le_sum_of_subset hcover (f := liveW)
  exact ⟨hc_tot, by linarith⟩

/-! ### 2. Register Machine Primitive Combinators (`HasRegFrame` Preservation) -/

theorem HasRegFrame.writeReg {fd : ℕ} {wsHeap : WordStore} {regs : ℕ → ℤ} {ws : WordStore}
    (h : HasRegFrame fd wsHeap regs ws) {r : ℕ} (hr : r < 16) (v : ℤ) :
    HasRegFrame fd wsHeap (Function.update regs r v) (ws.write (.localFrame fd r 0) v) :=
  { wfHeap := h.wfHeap
    wf := wellFormedWS_write h.wf _ _
    heapClean := h.heapClean
    below_live := fun loc hk => by
      have hne : loc ≠ .localFrame fd r 0 := by
        intro heq; subst heq; simp [keepBelowDepth] at hk
      simp [WordStore.write, hne, h.below_live loc hk]
    below_vals := fun loc hk => by
      have hne : loc ≠ .localFrame fd r 0 := by
        intro heq; subst heq; simp [keepBelowDepth] at hk
      simp [WordStore.write, Function.update_of_ne hne, h.below_vals loc hk]
    above_empty := fun d' hd' v' i' => by
      have hne : d' ≠ fd := by omega
      simp [WordStore.write, hne, h.above_empty d' hd' v' i']
    frame_bound := fun v' i' hm => by
      simp only [WordStore.write, Finset.mem_insert, RAMCellLoc.localFrame.injEq, true_and] at hm
      rcases hm with ⟨rfl, rfl⟩ | hm'
      · exact ⟨hr, rfl⟩
      · exact h.frame_bound v' i' hm'
    reg_read := fun r' hr' => by
      by_cases heq : r' = r
      · subst heq; simp
      · rw [wordStore_read_write_ne _ (by simp [heq]), Function.update_of_ne heq]
        exact h.reg_read r' hr'
    reg_zero := fun r' hr' => by
      have hne : r' ≠ r := by omega
      rw [Function.update_of_ne hne]; exact h.reg_zero r' hr' }

theorem HasRegFrame.writeHeap {fd : ℕ} {wsHeap : WordStore} {regs : ℕ → ℤ} {ws : WordStore}
    (h : HasRegFrame fd wsHeap regs ws) (t : ℕ) (idx val : ℤ) :
    HasRegFrame fd (wsHeap.write (.heap t idx) val) regs (ws.write (.heap t idx) val) :=
  { wfHeap := wellFormedWS_write h.wfHeap _ _
    wf := wellFormedWS_write h.wf _ _
    heapClean := fun d' hd' v i => by simp [WordStore.write, h.heapClean d' hd' v i]
    below_live := fun loc hk => by
      simp only [WordStore.write, Finset.mem_insert]
      exact or_congr_right (h.below_live loc hk)
    below_vals := fun loc hk => by
      simp only [WordStore.write]
      by_cases heq : loc = .heap t idx
      · subst heq; simp
      · simp [Function.update_of_ne heq, h.below_vals loc hk]
    above_empty := fun d' hd' v i => by simp [WordStore.write, h.above_empty d' hd' v i]
    frame_bound := fun v i hm => by
      simp only [WordStore.write, Finset.mem_insert, reduceCtorEq, false_or] at hm
      exact h.frame_bound v i hm
    reg_read := fun r hr => by
      rw [wordStore_read_write_ne _ (by simp)]; exact h.reg_read r hr
    reg_zero := h.reg_zero }

theorem HasRegFrame.freeHeap {fd : ℕ} {wsHeap : WordStore} {regs : ℕ → ℤ} {ws : WordStore}
    (h : HasRegFrame fd wsHeap regs ws) (t : ℕ) (idx : ℤ) :
    HasRegFrame fd (wsHeap.free (.heap t idx)) regs (ws.free (.heap t idx)) :=
  { wfHeap := wellFormedWS_free h.wfHeap _
    wf := wellFormedWS_free h.wf _
    heapClean := fun d' hd' v i => by simp [WordStore.free, h.heapClean d' hd' v i]
    below_live := fun loc hk => by
      simp only [WordStore.free, Finset.mem_erase]
      exact and_congr_right (fun _ => h.below_live loc hk)
    below_vals := fun loc hk => by
      simp only [WordStore.free]
      by_cases heq : loc = .heap t idx
      · subst heq; simp
      · simp [Function.update_of_ne heq, h.below_vals loc hk]
    above_empty := fun d' hd' v i => by simp [WordStore.free, h.above_empty d' hd' v i]
    frame_bound := fun v i hm => by
      simp only [WordStore.free, Finset.mem_erase] at hm
      exact h.frame_bound v i hm.2
    reg_read := fun r hr => by
      rw [wordStore_read_free_ne _ (by simp)]; exact h.reg_read r hr
    reg_zero := h.reg_zero }

/-! ### 3. High-Level Register-DSL Syntax & `RegExec` Spec -/

def rLit (r : ℕ) (c : ℤ) : BitRAMStmt := .writeLocal r (.lit 0) (.lit c)
def rCopy (dst src : ℕ) : BitRAMStmt := .writeLocal dst (.lit 0) (.readLocal src (.lit 0))
def rAdd (dst a b : ℕ) : BitRAMStmt := .writeLocal dst (.lit 0) (.add (.readLocal a (.lit 0)) (.readLocal b (.lit 0)))
def rSub (dst a b : ℕ) : BitRAMStmt := .writeLocal dst (.lit 0) (.sub (.readLocal a (.lit 0)) (.readLocal b (.lit 0)))
def rMul (dst a b : ℕ) : BitRAMStmt := .writeLocal dst (.lit 0) (.mul (.readLocal a (.lit 0)) (.readLocal b (.lit 0)))
def rDiv (dst a b : ℕ) : BitRAMStmt := .writeLocal dst (.lit 0) (.div (.readLocal a (.lit 0)) (.readLocal b (.lit 0)))
def rLoad (dst table addr : ℕ) : BitRAMStmt := .writeLocal dst (.lit 0) (.readHeap table (.readLocal addr (.lit 0)))
def rStore (table addr val : ℕ) : BitRAMStmt := .writeHeap table (.readLocal addr (.lit 0)) (.readLocal val (.lit 0))
def rFree (table addr : ℕ) : BitRAMStmt := .freeHeap table (.readLocal addr (.lit 0))
def rStoreOrFree (table addr val : ℕ) : BitRAMStmt :=
  .ite (.intEq (.readLocal val (.lit 0)) (.lit 0)) (rFree table addr) (rStore table addr val)

def RegExec {d : ℕ} (inp : BitRAMInput d) (fd W C_cell C_bit : ℕ)
    (stmt : BitRAMStmt)
    (wsHeap₁ : WordStore) (regs₁ : ℕ → ℤ)
    (wsHeap₂ : WordStore) (regs₂ : ℕ → ℤ)
    (U B : ℕ) : Prop :=
  ∀ st : BitRAMExecState,
    st.frameDepth = fd →
    HasRegFrame fd wsHeap₁ regs₁ st.words →
    st.peakCellSpace ≤ C_cell →
    st.peakBitSpace ≤ C_bit →
    ∃ st' : BitRAMExecState,
      RunsTo inp [.stmt stmt] st st' ∧
      HasRegFrame fd wsHeap₂ regs₂ st'.words ∧
      RegBounded W regs₂ ∧
      st'.frameDepth = fd ∧
      st'.remainingBits = st.remainingBits ∧
      st'.unitCost ≤ st.unitCost + U ∧
      st'.bitCost ≤ st.bitCost + B ∧
      st'.peakCellSpace ≤ C_cell ∧
      st'.peakBitSpace ≤ C_bit

theorem RegExec.seq {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    {s₁ s₂ : BitRAMStmt} {w₁ w₂ w₃ : WordStore} {r₁ r₂ r₃ : ℕ → ℤ} {U₁ B₁ U₂ B₂ : ℕ}
    (h₁ : RegExec inp fd W C_cell C_bit s₁ w₁ r₁ w₂ r₂ U₁ B₁)
    (h₂ : RegExec inp fd W C_cell C_bit s₂ w₂ r₂ w₃ r₃ U₂ B₂) :
    RegExec inp fd W C_cell C_bit (.seq s₁ s₂) w₁ r₁ w₃ r₃ (U₁ + U₂) (B₁ + B₂) := by
  intro st hfd hrf hpC hpB
  obtain ⟨st1, hr1, hrf1, _, hfd1, hrb1, huc1, hbc1, hpC1, hpB1⟩ := h₁ st hfd hrf hpC hpB
  obtain ⟨st2, hr2, hrf2, hbnd2, hfd2, hrb2, huc2, hbc2, hpC2, hpB2⟩ := h₂ st1 hfd1 hrf1 hpC1 hpB1
  exact ⟨st2, RunsTo.seq hr1 hr2, hrf2, hbnd2, hfd2, hrb2.trans hrb1,
    by linarith, by linarith, hpC2, hpB2⟩

private lemma reg_var_bl {r : ℕ} (hr : r < 16) : natBitLength r ≤ 4 := by
  have := natBitLength_mono (by omega : r ≤ 15)
  have hn15 : natBitLength 15 = 4 := by decide
  omega

private lemma reg_fd_bl {fd : ℕ} (hfd : fd ≤ 4) : natBitLength fd ≤ 3 := by
  have := natBitLength_mono hfd
  have hn4 : natBitLength 4 = 3 := by decide
  omega

/-- Generic helper for any instruction `.writeLocal dst (.lit 0) valE`! -/
theorem RegExec.writeLocalExpr {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst : ℕ} (hdst : dst < 16) (valE : IntExpr) {val : ℤ} {uV bV : ℕ}
    (hv_bl : intBitLength val ≤ W)
    (heval : ∀ ws : WordStore, HasRegFrame fd wsHeap regs ws →
      let r := evalIntExpr inp fd ws valE
      r.1 = val ∧ r.2.1 ≤ uV ∧ r.2.2 ≤ bV) :
    RegExec inp fd W C_cell C_bit (.writeLocal dst (.lit 0) valE)
      wsHeap regs wsHeap (Function.update regs dst val)
      (uV + 2) (bV + W + 12) := by
  intro st hfd hrf hpC hpB
  have hrun := RunsTo.writeLocal inp dst (.lit 0) valE st
  rw [hfd] at hrun
  have hev := heval st.words hrf; dsimp only at hev
  rcases hrV : evalIntExpr inp fd st.words valE with ⟨v', u', b'⟩
  rw [hrV] at hev; dsimp only at hev; rcases hev with ⟨rfl, hu, hb⟩
  have hr0 : evalIntExpr inp fd st.words (.lit 0) = (0, 1, 1) := by
    simp only [evalIntExpr, show intBitLength (0 : ℤ) = 1 from by decide]
  let loc := RAMCellLoc.localFrame fd dst 0
  let ws' := st.words.write loc v'
  let st' : BitRAMExecState :=
    { st with
      words := ws'
      frameDepth := fd
      unitCost := st.unitCost + 1 + u' + 1
      bitCost := st.bitCost + 1 + b' + loc.bitLength + intBitLength v'
      peakCellSpace := max st.peakCellSpace (inp.inputCellSpace + ws'.cellCount)
      peakBitSpace := max st.peakBitSpace (inp.inputBitSpace + ws'.bitSize) }
  have hrun' : RunsTo inp [.stmt (.writeLocal dst (.lit 0) valE)] st st' := by
    simpa only [hr0, hrV] using hrun
  have hrf' := hrf.writeReg hdst v'
  have hbnd' := hbnd.update hdst hv_bl
  obtain ⟨hcSp, hbSp⟩ := hrf'.space_le hfd_le hbnd'
  have hdst_bl := reg_var_bl hdst
  have hfd_bl := reg_fd_bl hfd_le
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  refine ⟨st', hrun', hrf', hbnd', rfl, rfl, ?_, ?_, max_le hpC (by linarith), max_le hpB (by linarith)⟩
  · dsimp only [st']; omega
  · dsimp only [st', loc, RAMCellLoc.bitLength]; rw [hl0]; linarith

theorem RegExec.lit {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst : ℕ} (hdst : dst < 16) {c : ℤ} (hc_bl : intBitLength c ≤ W) :
    RegExec inp fd W C_cell C_bit (rLit dst c)
      wsHeap regs wsHeap (Function.update regs dst c) 4 (2 * W + 16) := by
  have h := RegExec.writeLocalExpr (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
    hfd_le hbnd hcCeil hbCeil hdst (.lit c) hc_bl (uV := 1) (bV := W)
    (fun _ _ => ⟨rfl, le_rfl, hc_bl⟩)
  intro st hfd hrf hpC hpB
  obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := h st hfd hrf hpC hpB
  exact ⟨st', hr, hrf', hbnd', hfd', hrb', by linarith, by linarith, hpC', hpB'⟩

theorem RegExec.copy {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst src : ℕ} (hdst : dst < 16) (hsrc : src < 16) :
    RegExec inp fd W C_cell C_bit (rCopy dst src)
      wsHeap regs wsHeap (Function.update regs dst (regs src)) 5 (2 * W + 24) := by
  have hsrc_bl := hbnd.2.1 src hsrc
  have hsrc_var := reg_var_bl hsrc
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have h := RegExec.writeLocalExpr (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
    hfd_le hbnd hcCeil hbCeil hdst (.readLocal src (.lit 0)) hsrc_bl (uV := 2) (bV := W + 8)
    (fun ws hrf => by
      simp only [evalIntExpr, hrf.reg_read src hsrc, hl0]
      exact ⟨trivial, le_rfl, by linarith⟩)
  intro st hfd hrf hpC hpB
  obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := h st hfd hrf hpC hpB
  exact ⟨st', hr, hrf', hbnd', hfd', hrb', by linarith, by linarith, hpC', hpB'⟩

theorem RegExec.add {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst a b : ℕ} (hdst : dst < 16) (ha : a < 16) (hb : b < 16)
    (hres : intBitLength (regs a + regs b) ≤ W) :
    RegExec inp fd W C_cell C_bit (rAdd dst a b)
      wsHeap regs wsHeap (Function.update regs dst (regs a + regs b)) 8 (6 * W + 32) := by
  have ha_bl := hbnd.2.1 a ha; have hb_bl := hbnd.2.1 b hb
  have ha_v := reg_var_bl ha; have hb_v := reg_var_bl hb
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have h := RegExec.writeLocalExpr (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
    hfd_le hbnd hcCeil hbCeil hdst (.add (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) hres
    (uV := 5) (bV := 4 * W + 16)
    (fun ws hrf => by
      simp only [evalIntExpr, hrf.reg_read a ha, hrf.reg_read b hb, hl0]
      exact ⟨trivial, le_rfl, by linarith⟩)
  intro st hfd hrf hpC hpB
  obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := h st hfd hrf hpC hpB
  exact ⟨st', hr, hrf', hbnd', hfd', hrb', by linarith, by linarith, hpC', hpB'⟩

theorem RegExec.sub {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst a b : ℕ} (hdst : dst < 16) (ha : a < 16) (hb : b < 16)
    (hres : intBitLength (regs a - regs b) ≤ W) :
    RegExec inp fd W C_cell C_bit (rSub dst a b)
      wsHeap regs wsHeap (Function.update regs dst (regs a - regs b)) 8 (6 * W + 32) := by
  have ha_bl := hbnd.2.1 a ha; have hb_bl := hbnd.2.1 b hb
  have ha_v := reg_var_bl ha; have hb_v := reg_var_bl hb
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have h := RegExec.writeLocalExpr (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
    hfd_le hbnd hcCeil hbCeil hdst (.sub (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) hres
    (uV := 5) (bV := 4 * W + 16)
    (fun ws hrf => by
      simp only [evalIntExpr, hrf.reg_read a ha, hrf.reg_read b hb, hl0]
      exact ⟨trivial, le_rfl, by linarith⟩)
  intro st hfd hrf hpC hpB
  obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := h st hfd hrf hpC hpB
  exact ⟨st', hr, hrf', hbnd', hfd', hrb', by linarith, by linarith, hpC', hpB'⟩

theorem RegExec.mul {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst a b : ℕ} (hdst : dst < 16) (ha : a < 16) (hb : b < 16)
    (hres : intBitLength (regs a * regs b) ≤ W) :
    RegExec inp fd W C_cell C_bit (rMul dst a b)
      wsHeap regs wsHeap (Function.update regs dst (regs a * regs b)) 8 (4 * W * W) := by
  have hW8 := hbnd.1
  have ha_bl := hbnd.2.1 a ha; have hb_bl := hbnd.2.1 b hb
  have ha_v := reg_var_bl ha; have hb_v := reg_var_bl hb
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hprod : intBitLength (regs a) * intBitLength (regs b) ≤ W * W := Nat.mul_le_mul ha_bl hb_bl
  have h := RegExec.writeLocalExpr (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
    hfd_le hbnd hcCeil hbCeil hdst (.mul (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) hres
    (uV := 5) (bV := W * W + 2 * W + 16)
    (fun ws hrf => by
      simp only [evalIntExpr, hrf.reg_read a ha, hrf.reg_read b hb, hl0]
      exact ⟨trivial, le_rfl, by linarith⟩)
  intro st hfd hrf hpC hpB
  obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := h st hfd hrf hpC hpB
  exact ⟨st', hr, hrf', hbnd', hfd', hrb', by linarith, by nlinarith, hpC', hpB'⟩

theorem RegExec.div {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst a b : ℕ} (hdst : dst < 16) (ha : a < 16) (hb : b < 16)
    (h0a : 0 ≤ regs a) (h0b : 0 ≤ regs b) :
    RegExec inp fd W C_cell C_bit (rDiv dst a b)
      wsHeap regs wsHeap (Function.update regs dst (regs a / regs b)) 8 (4 * W * W) := by
  have hW8 := hbnd.1
  have ha_bl := hbnd.2.1 a ha; have hb_bl := hbnd.2.1 b hb
  have hres : intBitLength (regs a / regs b) ≤ W := by
    have hq0 : 0 ≤ regs a / regs b := Int.ediv_nonneg h0a h0b
    have hq_le : regs a / regs b ≤ regs a := by
      by_cases hb0 : regs b = 0
      · rw [hb0, Int.ediv_zero]; exact h0a
      · have hb1 : 1 ≤ regs b := by omega
        calc regs a / regs b = (regs a / regs b) * 1 := (mul_one _).symm
          _ ≤ (regs a / regs b) * regs b := Int.mul_le_mul_of_nonneg_left hb1 hq0
          _ ≤ regs a := Int.ediv_mul_le (regs a) hb0
    have habs_le : (regs a / regs b).natAbs ≤ (regs a).natAbs := by omega
    have hbl_le : intBitLength (regs a / regs b) ≤ intBitLength (regs a) := by
      unfold intBitLength natBitLength
      by_cases hqz : regs a / regs b = 0
      · rw [if_pos hqz]; split_ifs <;> omega
      · have haz : regs a ≠ 0 := by omega
        rw [if_neg hqz, if_neg haz]
        have hlog := Nat.log_mono_right (b := 2) habs_le
        omega
    exact hbl_le.trans ha_bl
  have ha_v := reg_var_bl ha; have hb_v := reg_var_bl hb
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hprod : intBitLength (regs a) * intBitLength (regs b) ≤ W * W := Nat.mul_le_mul ha_bl hb_bl
  have h := RegExec.writeLocalExpr (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
    hfd_le hbnd hcCeil hbCeil hdst (.div (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) hres
    (uV := 5) (bV := W * W + 2 * W + 16)
    (fun ws hrf => by
      simp only [evalIntExpr, hrf.reg_read a ha, hrf.reg_read b hb, hl0]
      exact ⟨trivial, le_rfl, by linarith⟩)
  intro st hfd hrf hpC hpB
  obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := h st hfd hrf hpC hpB
  exact ⟨st', hr, hrf', hbnd', hfd', hrb', by linarith, by nlinarith, hpC', hpB'⟩

theorem RegExec.load {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst table addr : ℕ} (hdst : dst < 16) (haddr : addr < 16)
    (ht_bl : natBitLength table ≤ W)
    (hv_bl : intBitLength (wsHeap.read (.heap table (regs addr))) ≤ W) :
    RegExec inp fd W C_cell C_bit (rLoad dst table addr)
      wsHeap regs wsHeap (Function.update regs dst (wsHeap.read (.heap table (regs addr))))
      6 (6 * W + 24) := by
  have ha_bl := hbnd.2.1 addr haddr
  have ha_v := reg_var_bl haddr
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have h := RegExec.writeLocalExpr (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
    hfd_le hbnd hcCeil hbCeil hdst (.readHeap table (.readLocal addr (.lit 0))) hv_bl
    (uV := 3) (bV := 4 * W + 8)
    (fun ws hrf => by
      simp only [evalIntExpr, hrf.reg_read addr haddr, hrf.read_heap table (regs addr), hl0]
      exact ⟨trivial, le_rfl, by linarith⟩)
  intro st hfd hrf hpC hpB
  obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := h st hfd hrf hpC hpB
  exact ⟨st', hr, hrf', hbnd', hfd', hrb', by linarith, by linarith, hpC', hpB'⟩

theorem RegExec.store {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    {table addr val : ℕ} (haddr : addr < 16) (hval : val < 16)
    (ht_bl : natBitLength table ≤ W)
    (hcCeil : inp.inputCellSpace + (wsHeap.write (.heap table (regs addr)) (regs val)).cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + (wsHeap.write (.heap table (regs addr)) (regs val)).bitSize + 16 * (W + 12) ≤ C_bit) :
    RegExec inp fd W C_cell C_bit (rStore table addr val)
      wsHeap regs (wsHeap.write (.heap table (regs addr)) (regs val)) regs
      6 (5 * W + 24) := by
  intro st hfd hrf hpC hpB
  have ha_bl := hbnd.2.1 addr haddr; have hv_bl := hbnd.2.1 val hval
  have ha_v := reg_var_bl haddr; have hv_v := reg_var_bl hval
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hrf' := hrf.writeHeap table (regs addr) (regs val)
  obtain ⟨hcSp, hbSp⟩ := hrf'.space_le hfd_le hbnd
  obtain ⟨st', hr, hw', hfd', hrb', huc, hbc, hpC', hpB'⟩ :=
    exec_writeHeap_ceil inp table (.readLocal addr (.lit 0)) (.readLocal val (.lit 0)) st hpC hpB
      (idx := regs addr) (val := regs val) (u₁ := 2) (b₁ := W + 6) (u₂ := 2) (b₂ := W + 6)
      (by unfold EvalIntLe; rw [hfd]; simp only [evalIntExpr, hrf.reg_read addr haddr, hl0]; exact ⟨trivial, le_rfl, by linarith⟩)
      (by unfold EvalIntLe; rw [hfd]; simp only [evalIntExpr, hrf.reg_read val hval, hl0]; exact ⟨trivial, le_rfl, by linarith⟩)
      (by linarith) (by linarith)
  rw [← hw'] at hrf'
  exact ⟨st', hr, hrf', hbnd, hfd'.trans hfd, hrb', by linarith, by linarith, hpC', hpB'⟩

theorem RegExec.free {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    {table addr : ℕ} (haddr : addr < 16)
    (ht_bl : natBitLength table ≤ W) :
    RegExec inp fd W C_cell C_bit (rFree table addr)
      wsHeap regs (wsHeap.free (.heap table (regs addr))) regs
      4 (3 * W + 16) := by
  intro st hfd hrf hpC hpB
  have ha_bl := hbnd.2.1 addr haddr; have ha_v := reg_var_bl haddr
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hrf' := hrf.freeHeap table (regs addr)
  obtain ⟨st', hr, hw', hfd', hrb', huc, hbc, hpC', hpB'⟩ :=
    exec_freeHeap_ceil inp table (.readLocal addr (.lit 0)) st hpC hpB
      (idx := regs addr) (u₁ := 2) (b₁ := W + 6)
      (by unfold EvalIntLe; rw [hfd]; simp only [evalIntExpr, hrf.reg_read addr haddr, hl0]; exact ⟨trivial, le_rfl, by linarith⟩)
  rw [← hw'] at hrf'
  exact ⟨st', hr, hrf', hbnd, hfd'.trans hfd, hrb', by linarith, by linarith, hpC', hpB'⟩

/-- Conditional `ite` on `regs a = regs b` / `regs a < regs b` / `regs a ≤ regs b`. -/
theorem RegExec.iteEq {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    {wsHeap wsOut : WordStore} {regs regsOut : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    {a b : ℕ} (ha : a < 16) (hb : b < 16)
    {tB fB : BitRAMStmt} {U B : ℕ}
    (hbranch : if regs a = regs b then RegExec inp fd W C_cell C_bit tB wsHeap regs wsOut regsOut U B
               else RegExec inp fd W C_cell C_bit fB wsHeap regs wsOut regsOut U B) :
    RegExec inp fd W C_cell C_bit (.ite (.intEq (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) tB fB)
      wsHeap regs wsOut regsOut (U + 6) (B + 4 * W + 16) := by
  intro st hfd hrf hpC hpB
  have ha_bl := hbnd.2.1 a ha; have hb_bl := hbnd.2.1 b hb
  have ha_v := reg_var_bl ha; have hb_v := reg_var_bl hb
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  rcases hcond : evalBitCond inp st.frameDepth st.words (.intEq (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) with ⟨flag, uC, bC⟩
  have hcond_spec : flag = decide (regs a = regs b) ∧ uC ≤ 5 ∧ bC ≤ 4 * W + 16 := by
    rw [hfd] at hcond
    simp only [evalBitCond, evalIntExpr, hrf.reg_read a ha, hrf.reg_read b hb, hl0] at hcond
    rcases Prod.mk.inj hcond with ⟨rfl, hub⟩
    rcases Prod.mk.inj hub with ⟨rfl, rfl⟩
    exact ⟨rfl, by omega, by linarith⟩
  let stMid : BitRAMExecState := { st with unitCost := st.unitCost + uC, bitCost := st.bitCost + bC }
  by_cases heq : regs a = regs b
  · rw [if_pos heq] at hbranch
    obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := hbranch stMid hfd hrf hpC hpB
    have hite : RunsTo inp [.stmt (.ite (.intEq (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) tB fB)] st st' := by
      apply RunsTo.ite; rw [hcond, hcond_spec.1, decide_eq_true heq]; exact hr
    exact ⟨st', hite, hrf', hbnd', hfd', hrb', by dsimp [stMid] at huc; linarith [hcond_spec.2.1],
      by dsimp [stMid] at hbc; linarith [hcond_spec.2.2], hpC', hpB'⟩
  · rw [if_neg heq] at hbranch
    obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := hbranch stMid hfd hrf hpC hpB
    have hite : RunsTo inp [.stmt (.ite (.intEq (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) tB fB)] st st' := by
      apply RunsTo.ite; rw [hcond, hcond_spec.1, decide_eq_false heq]; exact hr
    exact ⟨st', hite, hrf', hbnd', hfd', hrb', by dsimp [stMid] at huc; linarith [hcond_spec.2.1],
      by dsimp [stMid] at hbc; linarith [hcond_spec.2.2], hpC', hpB'⟩

theorem RegExec.iteLt {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    {wsHeap wsOut : WordStore} {regs regsOut : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    {a b : ℕ} (ha : a < 16) (hb : b < 16)
    {tB fB : BitRAMStmt} {U B : ℕ}
    (hbranch : if regs a < regs b then RegExec inp fd W C_cell C_bit tB wsHeap regs wsOut regsOut U B
               else RegExec inp fd W C_cell C_bit fB wsHeap regs wsOut regsOut U B) :
    RegExec inp fd W C_cell C_bit (.ite (.intLt (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) tB fB)
      wsHeap regs wsOut regsOut (U + 6) (B + 4 * W + 16) := by
  intro st hfd hrf hpC hpB
  have ha_bl := hbnd.2.1 a ha; have hb_bl := hbnd.2.1 b hb
  have ha_v := reg_var_bl ha; have hb_v := reg_var_bl hb
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  rcases hcond : evalBitCond inp st.frameDepth st.words (.intLt (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) with ⟨flag, uC, bC⟩
  have hcond_spec : flag = decide (regs a < regs b) ∧ uC ≤ 5 ∧ bC ≤ 4 * W + 16 := by
    rw [hfd] at hcond
    simp only [evalBitCond, evalIntExpr, hrf.reg_read a ha, hrf.reg_read b hb, hl0] at hcond
    rcases Prod.mk.inj hcond with ⟨rfl, hub⟩
    rcases Prod.mk.inj hub with ⟨rfl, rfl⟩
    exact ⟨rfl, by omega, by linarith⟩
  let stMid : BitRAMExecState := { st with unitCost := st.unitCost + uC, bitCost := st.bitCost + bC }
  by_cases hlt : regs a < regs b
  · rw [if_pos hlt] at hbranch
    obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := hbranch stMid hfd hrf hpC hpB
    have hite : RunsTo inp [.stmt (.ite (.intLt (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) tB fB)] st st' := by
      apply RunsTo.ite; rw [hcond, hcond_spec.1, decide_eq_true hlt]; exact hr
    exact ⟨st', hite, hrf', hbnd', hfd', hrb', by dsimp [stMid] at huc; linarith [hcond_spec.2.1],
      by dsimp [stMid] at hbc; linarith [hcond_spec.2.2], hpC', hpB'⟩
  · rw [if_neg hlt] at hbranch
    obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := hbranch stMid hfd hrf hpC hpB
    have hite : RunsTo inp [.stmt (.ite (.intLt (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) tB fB)] st st' := by
      apply RunsTo.ite; rw [hcond, hcond_spec.1, decide_eq_false hlt]; exact hr
    exact ⟨st', hite, hrf', hbnd', hfd', hrb', by dsimp [stMid] at huc; linarith [hcond_spec.2.1],
      by dsimp [stMid] at hbc; linarith [hcond_spec.2.2], hpC', hpB'⟩

theorem RegExec.iteLe {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    {wsHeap wsOut : WordStore} {regs regsOut : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    {a b : ℕ} (ha : a < 16) (hb : b < 16)
    {tB fB : BitRAMStmt} {U B : ℕ}
    (hbranch : if regs a ≤ regs b then RegExec inp fd W C_cell C_bit tB wsHeap regs wsOut regsOut U B
               else RegExec inp fd W C_cell C_bit fB wsHeap regs wsOut regsOut U B) :
    RegExec inp fd W C_cell C_bit (.ite (.intLe (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) tB fB)
      wsHeap regs wsOut regsOut (U + 6) (B + 4 * W + 16) := by
  intro st hfd hrf hpC hpB
  have ha_bl := hbnd.2.1 a ha; have hb_bl := hbnd.2.1 b hb
  have ha_v := reg_var_bl ha; have hb_v := reg_var_bl hb
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  rcases hcond : evalBitCond inp st.frameDepth st.words (.intLe (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) with ⟨flag, uC, bC⟩
  have hcond_spec : flag = decide (regs a ≤ regs b) ∧ uC ≤ 5 ∧ bC ≤ 4 * W + 16 := by
    rw [hfd] at hcond
    simp only [evalBitCond, evalIntExpr, hrf.reg_read a ha, hrf.reg_read b hb, hl0] at hcond
    rcases Prod.mk.inj hcond with ⟨rfl, hub⟩
    rcases Prod.mk.inj hub with ⟨rfl, rfl⟩
    exact ⟨rfl, by omega, by linarith⟩
  let stMid : BitRAMExecState := { st with unitCost := st.unitCost + uC, bitCost := st.bitCost + bC }
  by_cases hle : regs a ≤ regs b
  · rw [if_pos hle] at hbranch
    obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := hbranch stMid hfd hrf hpC hpB
    have hite : RunsTo inp [.stmt (.ite (.intLe (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) tB fB)] st st' := by
      apply RunsTo.ite; rw [hcond, hcond_spec.1, decide_eq_true hle]; exact hr
    exact ⟨st', hite, hrf', hbnd', hfd', hrb', by dsimp [stMid] at huc; linarith [hcond_spec.2.1],
      by dsimp [stMid] at hbc; linarith [hcond_spec.2.2], hpC', hpB'⟩
  · rw [if_neg hle] at hbranch
    obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := hbranch stMid hfd hrf hpC hpB
    have hite : RunsTo inp [.stmt (.ite (.intLe (.readLocal a (.lit 0)) (.readLocal b (.lit 0))) tB fB)] st st' := by
      apply RunsTo.ite; rw [hcond, hcond_spec.1, decide_eq_false hle]; exact hr
    exact ⟨st', hite, hrf', hbnd', hfd', hrb', by dsimp [stMid] at huc; linarith [hcond_spec.2.1],
      by dsimp [stMid] at hbc; linarith [hcond_spec.2.2], hpC', hpB'⟩

/-- Bounded loop `.repeatN countE body` indexed by `step ∈ [0, N)`. -/
theorem RegExec.repeatLit {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (N : ℕ) (hN_bl : intBitLength (N : ℤ) ≤ W)
    (wsSeq : ℕ → WordStore) (regSeq : ℕ → ℕ → ℤ)
    (h0 : RegBounded W (regSeq 0))
    {body : BitRAMStmt} {U B : ℕ}
    (hstep : ∀ i < N, RegExec inp fd W C_cell C_bit body (wsSeq i) (regSeq i) (wsSeq (i + 1)) (regSeq (i + 1)) U B) :
    RegExec inp fd W C_cell C_bit (.repeatN (.lit (N : ℤ)) body)
      (wsSeq 0) (regSeq 0) (wsSeq N) (regSeq N) (N * U + 2) (N * B + W) := by
  intro st hfd hrf0 hpC0 hpB0
  have hloop : ∀ (rem i : ℕ), i + rem = N →
      ∀ stCur : BitRAMExecState,
        stCur.frameDepth = fd →
        HasRegFrame fd (wsSeq i) (regSeq i) stCur.words →
        RegBounded W (regSeq i) →
        stCur.peakCellSpace ≤ C_cell →
        stCur.peakBitSpace ≤ C_bit →
        ∃ stEnd : BitRAMExecState,
          RunsTo inp [.repeatLoop rem body] stCur stEnd ∧
          HasRegFrame fd (wsSeq N) (regSeq N) stEnd.words ∧
          RegBounded W (regSeq N) ∧
          stEnd.frameDepth = fd ∧
          stEnd.remainingBits = stCur.remainingBits ∧
          stEnd.unitCost ≤ stCur.unitCost + rem * U ∧
          stEnd.bitCost ≤ stCur.bitCost + rem * B ∧
          stEnd.peakCellSpace ≤ C_cell ∧
          stEnd.peakBitSpace ≤ C_bit := by
    intro rem
    induction rem with
    | zero =>
        intro i hi stCur hfdC hrfC hbndC hpCC hpBC
        have hiN : i = N := by omega
        subst hiN
        exact ⟨stCur, RunsTo.repeatLoop_zero body stCur, hrfC, hbndC, hfdC, rfl,
          by simp, by simp, hpCC, hpBC⟩
    | succ rem ih =>
        intro i hi stCur hfdC hrfC _ hpCC hpBC
        have hi_lt : i < N := by omega
        obtain ⟨stMid, hrM, hrfM, hbndM, hfdM, hrbM, hucM, hbcM, hpCM, hpBM⟩ :=
          hstep i hi_lt stCur hfdC hrfC hpCC hpBC
        obtain ⟨stEnd, hrE, hrfE, hbndE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
          ih (i + 1) (by omega) stMid hfdM hrfM hbndM hpCM hpBM
        refine ⟨stEnd, RunsTo.repeatLoop_succ hrM hrE, hrfE, hbndE, hfdE, hrbE.trans hrbM,
          ?_, ?_, hpCE, hpBE⟩
        · have : (rem + 1) * U = rem * U + U := by ring
          linarith
        · have : (rem + 1) * B = rem * B + B := by ring
          linarith
  let st0 : BitRAMExecState := { st with unitCost := st.unitCost + 1, bitCost := st.bitCost + intBitLength (N : ℤ) }
  obtain ⟨stEnd, hrL, hrfE, hbndE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
    hloop N 0 (Nat.zero_add N) st0 hfd hrf0 h0 hpC0 hpB0
  have hrep : RunsTo inp [.stmt (.repeatN (.lit (N : ℤ)) body)] st stEnd := by
    apply RunsTo.repeatN
    simp only [evalIntExpr, Nat.cast_nonneg, ↓reduceIte, Int.toNat_natCast]
    exact hrL
  exact ⟨stEnd, hrep, hrfE, hbndE, hfdE, hrbE,
    by dsimp [st0] at hucE; linarith,
    by dsimp [st0] at hbcE; linarith,
    hpCE, hpBE⟩

theorem RegExec.repeatReg {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    {cntReg : ℕ} (hcnt : cntReg < 16)
    (N : ℕ)
    (wsSeq : ℕ → WordStore) (regSeq : ℕ → ℕ → ℤ)
    (hcnt_eq : regSeq 0 cntReg = (N : ℤ))
    (h0 : RegBounded W (regSeq 0))
    {body : BitRAMStmt} {U B : ℕ}
    (hstep : ∀ i < N, RegExec inp fd W C_cell C_bit body (wsSeq i) (regSeq i) (wsSeq (i + 1)) (regSeq (i + 1)) U B) :
    RegExec inp fd W C_cell C_bit (.repeatN (.readLocal cntReg (.lit 0)) body)
      (wsSeq 0) (regSeq 0) (wsSeq N) (regSeq N) (N * U + 4) (N * B + W + 12) := by
  intro st hfd hrf0 hpC0 hpB0
  have hc_bl := h0.2.1 cntReg hcnt
  have hc_v := reg_var_bl hcnt
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hloop : ∀ (rem i : ℕ), i + rem = N →
      ∀ stCur : BitRAMExecState,
        stCur.frameDepth = fd →
        HasRegFrame fd (wsSeq i) (regSeq i) stCur.words →
        RegBounded W (regSeq i) →
        stCur.peakCellSpace ≤ C_cell →
        stCur.peakBitSpace ≤ C_bit →
        ∃ stEnd : BitRAMExecState,
          RunsTo inp [.repeatLoop rem body] stCur stEnd ∧
          HasRegFrame fd (wsSeq N) (regSeq N) stEnd.words ∧
          RegBounded W (regSeq N) ∧
          stEnd.frameDepth = fd ∧
          stEnd.remainingBits = stCur.remainingBits ∧
          stEnd.unitCost ≤ stCur.unitCost + rem * U ∧
          stEnd.bitCost ≤ stCur.bitCost + rem * B ∧
          stEnd.peakCellSpace ≤ C_cell ∧
          stEnd.peakBitSpace ≤ C_bit := by
    intro rem
    induction rem with
    | zero =>
        intro i hi stCur hfdC hrfC hbndC hpCC hpBC
        have hiN : i = N := by omega
        subst hiN
        exact ⟨stCur, RunsTo.repeatLoop_zero body stCur, hrfC, hbndC, hfdC, rfl,
          by simp, by simp, hpCC, hpBC⟩
    | succ rem ih =>
        intro i hi stCur hfdC hrfC _ hpCC hpBC
        have hi_lt : i < N := by omega
        obtain ⟨stMid, hrM, hrfM, hbndM, hfdM, hrbM, hucM, hbcM, hpCM, hpBM⟩ :=
          hstep i hi_lt stCur hfdC hrfC hpCC hpBC
        obtain ⟨stEnd, hrE, hrfE, hbndE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
          ih (i + 1) (by omega) stMid hfdM hrfM hbndM hpCM hpBM
        refine ⟨stEnd, RunsTo.repeatLoop_succ hrM hrE, hrfE, hbndE, hfdE, hrbE.trans hrbM,
          ?_, ?_, hpCE, hpBE⟩
        · have : (rem + 1) * U = rem * U + U := by ring
          linarith
        · have : (rem + 1) * B = rem * B + B := by ring
          linarith
  have hev : evalIntExpr inp st.frameDepth st.words (.readLocal cntReg (.lit 0)) =
      ((N : ℤ), 2, 1 + natBitLength cntReg + 1 + intBitLength (N : ℤ)) := by
    rw [hfd]
    simp only [evalIntExpr, hrf0.reg_read cntReg hcnt, hcnt_eq, hl0]
  let st0 : BitRAMExecState :=
    { st with unitCost := st.unitCost + 2, bitCost := st.bitCost + (1 + natBitLength cntReg + 1 + intBitLength (N : ℤ)) }
  obtain ⟨stEnd, hrL, hrfE, hbndE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
    hloop N 0 (Nat.zero_add N) st0 hfd hrf0 h0 hpC0 hpB0
  have hrep : RunsTo inp [.stmt (.repeatN (.readLocal cntReg (.lit 0)) body)] st stEnd := by
    apply RunsTo.repeatN
    rw [hev]; dsimp only
    simp only [Nat.cast_nonneg, ↓reduceIte, Int.toNat_natCast]
    exact hrL
  rw [hcnt_eq] at hc_bl
  exact ⟨stEnd, hrep, hrfE, hbndE, hfdE, hrbE,
    by dsimp [st0] at hucE; linarith,
    by dsimp [st0] at hbcE; linarith,
    hpCE, hpBE⟩

/-- Wrap a `RegExec` block inside `.localScope` from caller `st.frameDepth = fd - 1`, automatically
popping all 16 registers and restoring `stOut.words = wsHeap₂`! -/
theorem RegExec.runScope {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd1 : 1 ≤ fd) (_hW8 : 8 ≤ W)
    {body : BitRAMStmt} {wsHeap₁ wsHeap₂ : WordStore} {regs₂ : ℕ → ℤ} {U B : ℕ}
    (hwf₁ : WellFormedWS wsHeap₁)
    (hclean₁ : ∀ d' ≥ fd, ∀ v i, (.localFrame d' v i : RAMCellLoc) ∉ wsHeap₁.live)
    (hbody : RegExec inp fd W C_cell C_bit body wsHeap₁ (fun _ => 0) wsHeap₂ regs₂ U B)
    (st : BitRAMExecState)
    (hfdSt : st.frameDepth = fd - 1)
    (hwSt : st.words = wsHeap₁)
    (hpC : st.peakCellSpace ≤ C_cell)
    (hpB : st.peakBitSpace ≤ C_bit) :
    ∃ st' : BitRAMExecState,
      RunsTo inp [.stmt (.localScope body)] st st' ∧
      st'.words = wsHeap₂ ∧
      st'.frameDepth = fd - 1 ∧
      st'.remainingBits = st.remainingBits ∧
      st'.unitCost ≤ st.unitCost + U ∧
      st'.bitCost ≤ st.bitCost + B ∧
      st'.peakCellSpace ≤ C_cell ∧
      st'.peakBitSpace ≤ C_bit := by
  obtain ⟨hpop1, hrf0⟩ := HasRegFrame.enterScope hfd1 hwf₁ hclean₁
  let stIn : BitRAMExecState :=
    { st with words := st.words.popDepth st.frameDepth, frameDepth := st.frameDepth + 1 }
  have hfdIn : stIn.frameDepth = fd := by dsimp [stIn]; omega
  have hrfIn : HasRegFrame fd wsHeap₁ (fun _ => 0) stIn.words := by
    dsimp [stIn]; rw [hwSt, hfdSt]; exact hrf0
  obtain ⟨stBody, hrB, hrf2, _, hfd2, hrb2, huc2, hbc2, hpC2, hpB2⟩ :=
    hbody stIn hfdIn hrfIn hpC hpB
  let stOut : BitRAMExecState :=
    { stBody with words := stBody.words.popDepth st.frameDepth, frameDepth := st.frameDepth }
  have hsc : RunsTo inp [.stmt (.localScope body)] st stOut :=
    RunsTo.localScope (inp := inp) (body := body) (st := st) (stBody := stBody) hrB
  have hexit : stOut.words = wsHeap₂ := by
    dsimp [stOut]; rw [hfdSt]; exact hrf2.exitScope hfd1
  refine ⟨stOut, hsc, hexit, hfdSt, hrb2, ?_, ?_, hpC2, hpB2⟩
  · dsimp [stOut, stIn] at huc2 ⊢; exact huc2
  · dsimp [stOut, stIn] at hbc2 ⊢; exact hbc2

theorem RegExec.skip {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    {wsHeap : WordStore} {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    RegExec inp fd W C_cell C_bit .skip wsHeap regs wsHeap regs 1 1 := by
  intro st hfd hrf hpC hpB
  let st' : BitRAMExecState := { st with unitCost := st.unitCost + 1, bitCost := st.bitCost + 1 }
  exact ⟨st', RunsTo.skip inp st, hrf, hbnd, hfd, rfl, le_rfl, le_rfl, hpC, hpB⟩

theorem RegExec.weaken {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    {s : BitRAMStmt} {ws₁ ws₂ ws₂' : WordStore} {regs₁ regs₂ regs₂' : ℕ → ℤ}
    {u₁ b₁ u₂ b₂ : ℕ}
    (h : RegExec inp fd W C_cell C_bit s ws₁ regs₁ ws₂ regs₂ u₁ b₁)
    (hws : ws₂ = ws₂') (hregs : regs₂ = regs₂') (hu : u₁ ≤ u₂) (hb : b₁ ≤ b₂) :
    RegExec inp fd W C_cell C_bit s ws₁ regs₁ ws₂' regs₂' u₂ b₂ := by
  subst hws; subst hregs
  intro st hfd hrf hpC hpB
  obtain ⟨st', hr, hrf', hbnd', hfd', hrb', huc, hbc, hpC', hpB'⟩ := h st hfd hrf hpC hpB
  exact ⟨st', hr, hrf', hbnd', hfd', hrb', by linarith, by linarith, hpC', hpB'⟩

def rIntParam (dst : ℕ) (idx : ℤ) : BitRAMStmt :=
  .writeLocal dst (.lit 0) (.intParam (.lit idx))

def rExtraRatNum (dst addr : ℕ) : BitRAMStmt :=
  .writeLocal dst (.lit 0) (.extraRatNum (.readLocal addr (.lit 0)))

def rExtraRatDen (dst addr : ℕ) : BitRAMStmt :=
  .writeLocal dst (.lit 0) (.extraRatDen (.readLocal addr (.lit 0)))

theorem RegExec.intParam {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst : ℕ} (hdst : dst < 16) (idx : ℤ)
    (hi_bl : intBitLength idx ≤ W)
    (hv_bl : intBitLength (listGetIntD inp.intParams idx 0) ≤ W) :
    RegExec inp fd W C_cell C_bit (rIntParam dst idx)
      wsHeap regs wsHeap (Function.update regs dst (listGetIntD inp.intParams idx 0))
      4 (4 * W + 12) := by
  have hr := RegExec.writeLocalExpr (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
    hfd_le hbnd hcCeil hbCeil hdst (.intParam (.lit idx)) hv_bl (uV := 2) (bV := 3 * W)
    (fun ws _ => by
      simp only [evalIntExpr]
      exact ⟨trivial, le_rfl, by linarith⟩)
  exact hr.weaken rfl rfl (by omega) (by omega)

theorem RegExec.extraRatNum {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst addr : ℕ} (hdst : dst < 16) (haddr : addr < 16)
    (hv_bl : intBitLength (listGetIntD inp.extraRats (regs addr) 0).num ≤ W) :
    RegExec inp fd W C_cell C_bit (rExtraRatNum dst addr)
      wsHeap regs wsHeap (Function.update regs dst (listGetIntD inp.extraRats (regs addr) 0).num)
      5 (4 * W + 18) := by
  have ha_bl := hbnd.2.1 addr haddr
  have ha_v := reg_var_bl haddr
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hr := RegExec.writeLocalExpr (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
    hfd_le hbnd hcCeil hbCeil hdst (.extraRatNum (.readLocal addr (.lit 0))) hv_bl
    (uV := 3) (bV := 3 * W + 6)
    (fun ws hrf => by
      simp only [evalIntExpr, hrf.reg_read addr haddr, hl0]
      exact ⟨trivial, le_rfl, by linarith⟩)
  exact hr.weaken rfl rfl (by omega) (by omega)

theorem RegExec.extraRatDen {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {wsHeap : WordStore} {regs : ℕ → ℤ}
    (hbnd : RegBounded W regs)
    (hcCeil : inp.inputCellSpace + wsHeap.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + wsHeap.bitSize + 16 * (W + 12) ≤ C_bit)
    {dst addr : ℕ} (hdst : dst < 16) (haddr : addr < 16)
    (hv_bl : intBitLength ((listGetIntD inp.extraRats (regs addr) 0).den : ℤ) ≤ W) :
    RegExec inp fd W C_cell C_bit (rExtraRatDen dst addr)
      wsHeap regs wsHeap
      (Function.update regs dst ((listGetIntD inp.extraRats (regs addr) 0).den : ℤ))
      5 (4 * W + 18) := by
  have ha_bl := hbnd.2.1 addr haddr
  have ha_v := reg_var_bl haddr
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hr := RegExec.writeLocalExpr (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
    hfd_le hbnd hcCeil hbCeil hdst (.extraRatDen (.readLocal addr (.lit 0))) hv_bl
    (uV := 3) (bV := 3 * W + 6)
    (fun ws hrf => by
      simp only [evalIntExpr, hrf.reg_read addr haddr, hl0]
      exact ⟨trivial, le_rfl, by linarith⟩)
  exact hr.weaken rfl rfl (by omega) (by omega)

end UL.C12LVE
