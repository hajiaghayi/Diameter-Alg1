import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG09_StepC1A0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

def freeLevelTab3StepStmt : BitRAMStmt :=
  .seq (rFree 3 6)
        (rAdd 6 6 14)

def freeLevelTab3Regs (d s₀_d L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 104)
  (.seq (rLoad 0 9 10)
  (.seq (rLit 8 ((posNodeStride d L) : ℤ))
  (.seq (rMul 6 0 8)
  (.seq (rLit 14 2)
  (.seq (rAdd 8 6 14)
  (.seq (rLoad 5 3 8)
  (.seq (rLit 14 (s₀_d : ℤ))
  (.seq (rMul 5 5 14)
  (.seq (rLit 14 (((6 + 2 * d : ℕ) : ℤ)))
  (.seq (rAdd 5 5 14)
  (.seq (rLit 14 1)
        (.repeatN (.readLocal 5 (.lit 0)) freeLevelTab3StepStmt))))))))))))

theorem exec_freeLevelTab3Regs {d s₀_d L K_max W M_ceil j : ℕ}
    (hs₀1 : 1 ≤ s₀_d) (hj : j ≤ K_max)
    (hW : natBitLength ((K_max + 2) * posNodeStride d L) + natBitLength (64 * s₀_d + 1) + L + 24 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hr104 : ws.read (.heap 9 104) = (j : ℤ))
    {k_blk : ℕ}
    (hk_pow : k_blk * s₀_d ≤ 2 ^ L)
    (hk_M : k_blk * s₀_d ≤ 2 * (M_ceil + 1))
    (hr_k : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (k_blk : ℤ))
    (hun3 : ∀ off : ℕ, 6 + 2 * d + k_blk * s₀_d ≤ off → off < posNodeStride d L →
      (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ ws.live)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (freeLevelTab3Regs d s₀_d L) ws regs wsEnd regsEnd
        (24 * M_ceil + 24 * d + 200) ((20 * M_ceil + 20 * d + 200) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      (∀ off < posNodeStride d L,
        (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ wsEnd.live) ∧
      (∀ loc : RAMCellLoc,
        (∀ off < posNodeStride d L, loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j off)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW24 : 24 ≤ W := by clear * - hW; omega
  have hWW : 24 * W ≤ W * W := by nlinarith only [hW24]
  have hp2_pos : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
  have hns_ge : 8 + 2 * d + 2 ^ L = (posNodeStride d L) := rfl
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hl2 : intBitLength (2 : ℤ) ≤ W := (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by omega)
  have hl104 : intBitLength (104 : ℤ) ≤ W := (show intBitLength (104 : ℤ) = 8 from by decide).trans_le (by omega)
  have hn3 : natBitLength 3 ≤ W := (show natBitLength 3 = 2 from by decide).trans_le (by omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by omega)
  have hj_bl : intBitLength (j : ℤ) ≤ W := j_bl_of_level (d := d) (L := L) (Nat.le_succ_of_le hj) (by clear * - hW; omega)
  have hns_bl : intBitLength ((posNodeStride d L) : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le (posNodeStride d L)
    have h2 : natBitLength (posNodeStride d L) ≤ natBitLength ((K_max + 2) * (posNodeStride d L)) :=
      natBitLength_mono (Nat.le_mul_of_pos_left _ (by omega))
    clear * - h1 h2 hW; omega
  have h62d_bl : intBitLength (((6 + 2 * d : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono (show 6 + 2 * d ≤ (posNodeStride d L) by clear * - hp2_pos hns_ge; omega)).trans hns_bl
  have hs₀_bl : intBitLength (s₀_d : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le s₀_d
    have h2 : natBitLength s₀_d ≤ natBitLength (64 * s₀_d + 1) := natBitLength_mono (by omega)
    clear * - h1 h2 hW; omega
  have hpow_bl : intBitLength ((2 ^ L : ℕ) : ℤ) ≤ W :=
    (nat_pow2_bitLength_le L).trans (by clear * - hW; omega)
  have hk_bl : intBitLength (k_blk : ℤ) ≤ W :=
    (intBitLength_natCast_mono (le_trans (Nat.le_mul_of_pos_right _ hs₀1) hk_pow)).trans hpow_bl
  have hks_bl : intBitLength (((k_blk * s₀_d : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono hk_pow).trans hpow_bl
  set N3 := 6 + 2 * d + k_blk * s₀_d
  have hN3_lt : N3 < (posNodeStride d L) := by dsimp [N3]; clear * - hk_pow hns_ge; omega
  have hN3_bl : intBitLength (N3 : ℤ) ≤ W :=
    (intBitLength_natCast_mono (Nat.le_of_lt hN3_lt)).trans hns_bl
  have haddr3_bl : ∀ off < (posNodeStride d L), intBitLength (nodeCellAddr (posNodeStride d L) j off) ≤ W := by
    intro off hoff
    exact (nodeCellAddr_bl (Nat.le_succ_of_le hj) hoff (by clear * - hW; omega)).2
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 104) (by decide) hl104
  set g1 := Function.update regs 10 104; have bg1 := hbnd.update (r := 10) (by decide) hl104
  have hg1_r : ws.read (.heap 9 (g1 10)) = (j : ℤ) := by simp [g1, hr104]
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact hj_bl)
  rw [hg1_r] at s2
  set g2 := Function.update g1 0 (j : ℤ); have bg2 := bg1.update (r := 0) (by decide) hj_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := ((posNodeStride d L) : ℤ)) (by decide) hns_bl
  set g3 := Function.update g2 8 ((posNodeStride d L) : ℤ); have bg3 := bg2.update (r := 8) (by decide) hns_bl
  have hmul3 : g3 0 * g3 8 = nodeCellAddr (posNodeStride d L) j 0 := by simp [g3, g2, nodeCellAddr]
  have s4 := RegExec.mul (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 6) (a := 0) (b := 8)
    (by decide) (by decide) (by decide) (by rw [hmul3]; exact haddr3_bl 0 (by clear * - hp2_pos hns_ge; omega))
  rw [hmul3] at s4
  set g4 := Function.update g3 6 (nodeCellAddr (posNodeStride d L) j 0); have bg4 := bg3.update (r := 6) (by decide) (haddr3_bl 0 (by clear * - hp2_pos hns_ge; omega))
  have s5 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 2) (by decide) hl2
  set g5 := Function.update g4 14 2; have bg5 := bg4.update (r := 14) (by decide) hl2
  have hadd5 : g5 6 + g5 14 = nodeCellAddr (posNodeStride d L) j 2 := by simp [g5, g4, nodeCellAddr]
  have s6 := RegExec.add (inp := inp) hfd_le bg5 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (a := 6) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hadd5]; exact haddr3_bl 2 (by clear * - hp2_pos hns_ge; omega))
  rw [hadd5] at s6
  set g6 := Function.update g5 8 (nodeCellAddr (posNodeStride d L) j 2); have bg6 := bg5.update (r := 8) (by decide) (haddr3_bl 2 (by clear * - hp2_pos hns_ge; omega))
  have hg6_r : ws.read (.heap 3 (g6 8)) = (k_blk : ℤ) := by simp [g6, hr_k]
  have s7 := RegExec.load (inp := inp) hfd_le bg6 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 5) (table := 3) (addr := 8)
    (by decide) (by decide) hn3 (by rw [hg6_r]; exact hk_bl)
  rw [hg6_r] at s7
  set g7 := Function.update g6 5 (k_blk : ℤ); have bg7 := bg6.update (r := 5) (by decide) hk_bl
  have s8 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := (s₀_d : ℤ)) (by decide) hs₀_bl
  set g8 := Function.update g7 14 (s₀_d : ℤ); have bg8 := bg7.update (r := 14) (by decide) hs₀_bl
  have hmul8 : g8 5 * g8 14 = ((k_blk * s₀_d : ℕ) : ℤ) := by simp [g8, g7]
  have s9 := RegExec.mul (inp := inp) hfd_le bg8 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 5) (a := 5) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hmul8]; exact hks_bl)
  rw [hmul8] at s9
  set g9 := Function.update g8 5 ((k_blk * s₀_d : ℕ) : ℤ); have bg9 := bg8.update (r := 5) (by decide) hks_bl
  have s10 := RegExec.lit (inp := inp) hfd_le bg9 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := ((6 + 2 * d : ℕ) : ℤ)) (by decide) h62d_bl
  set g10 := Function.update g9 14 ((6 + 2 * d : ℕ) : ℤ); have bg10 := bg9.update (r := 14) (by decide) h62d_bl
  have hadd10 : g10 5 + g10 14 = (N3 : ℤ) := by
    simp [g10, g9, N3]; ring
  have s11 := RegExec.add (inp := inp) hfd_le bg10 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 5) (a := 5) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hadd10]; exact hN3_bl)
  rw [hadd10] at s11
  set g11 := Function.update g10 5 (N3 : ℤ); have bg11 := bg10.update (r := 5) (by decide) hN3_bl
  have s12 := RegExec.lit (inp := inp) hfd_le bg11 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
  set g12 := Function.update g11 14 1; have bg12 := bg11.update (r := 14) (by decide) hl1
  -- Loop `off = 0 .. N3 - 1`
  let wsSeq : ℕ → WordStore := fun m =>
    Nat.rec ws (fun off acc => acc.free (.heap 3 (nodeCellAddr (posNodeStride d L) j off))) m
  have hwsSeq_succ : ∀ off,
      wsSeq (off + 1) = (wsSeq off).free (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) := fun _ => rfl
  let regSeq : ℕ → ℕ → ℤ := fun m =>
    Function.update g12 6 (nodeCellAddr (posNodeStride d L) j m)
  have hmodSeq : ∀ m ≤ N3, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (wsSeq m) := by
    intro m hm; induction m with
    | zero => exact hmod
    | succ off ih =>
        have hoff_ns : off < (posNodeStride d L) := lt_of_lt_of_le (Nat.lt_of_succ_le hm) (Nat.le_of_lt hN3_lt)
        exact (ih (Nat.le_of_succ_le hm)).free (mem_posDimWriteLocs_tab3 (Nat.le_succ_of_le hj) hoff_ns)
  have hbndSeq : ∀ m ≤ N3, RegBounded W (regSeq m) := by
    intro m hm
    exact bg12.update (r := 6) (by decide) (haddr3_bl m (lt_of_le_of_lt hm hN3_lt))
  have hstep : ∀ off < N3,
      RegExec inp fd W C_cell C_bit freeLevelTab3StepStmt
        (wsSeq off) (regSeq off) (wsSeq (off + 1)) (regSeq (off + 1))
        12 (9 * W + 48) := by
    intro off hoff
    have p1 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit)
      (wsHeap := wsSeq off) (hbndSeq off (Nat.le_of_lt hoff)) (table := 3) (addr := 6) (by decide) hn3
    have hfree_eq : (wsSeq off).free (.heap 3 (regSeq off 6)) = wsSeq (off + 1) := by
      rw [hwsSeq_succ]; simp [regSeq]
    rw [hfree_eq] at p1
    have hadd_eq : regSeq off 6 + regSeq off 14 = nodeCellAddr (posNodeStride d L) j (off + 1) := by
      simp [regSeq, g12, nodeCellAddr]; ring
    have hoff1_ns : off + 1 < (posNodeStride d L) := lt_of_le_of_lt (Nat.succ_le_of_lt hoff) hN3_lt
    have p2 := RegExec.add (inp := inp) hfd_le (hbndSeq off (Nat.le_of_lt hoff))
      (sp_ok (hmodSeq (off + 1) (Nat.succ_le_of_lt hoff))).1
      (sp_ok (hmodSeq (off + 1) (Nat.succ_le_of_lt hoff))).2
      (dst := 6) (a := 6) (b := 14) (by decide) (by decide) (by decide)
      (by rw [hadd_eq]; exact haddr3_bl _ hoff1_ns)
    rw [hadd_eq] at p2
    have hreg_eq : Function.update (regSeq off) 6 (nodeCellAddr (posNodeStride d L) j (off + 1)) =
        regSeq (off + 1) := by ext r; simp [regSeq]
    exact (p1.seq p2).weaken rfl hreg_eq (by omega) (by omega)
  have hg12_eq : regSeq 0 = g12 := by
    ext r
    by_cases hr6 : r = 6
    · subst hr6; simp [regSeq, g12, g11, g10, g9, g8, g7, g6, g5, g4]
    · simp [regSeq, hr6]
  have s13 := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (cntReg := 5) (by decide) N3 wsSeq regSeq
    (by rw [hg12_eq]; simp [g12, g11])
    (hbndSeq 0 (Nat.zero_le _)) hstep
  rw [hg12_eq] at s13
  have hSeq_spec : ∀ m,
      (∀ off < m, (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ (wsSeq m).live) ∧
      (∀ loc : RAMCellLoc,
        (∀ off < m, loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j off)) →
        (loc ∈ (wsSeq m).live ↔ loc ∈ ws.live) ∧ (wsSeq m).vals loc = ws.vals loc) := by
    intro m; induction m with
    | zero => exact ⟨fun off h => absurd h (Nat.not_lt_zero _), fun _ _ => ⟨Iff.rfl, rfl⟩⟩
    | succ off ih =>
        refine ⟨fun r hr => ?_, fun loc hne => ?_⟩
        · rw [hwsSeq_succ]
          rcases Nat.lt_succ_iff_lt_or_eq.mp hr with hlt | rfl
          · exact fun hm_er => ih.1 r hlt (Finset.mem_of_mem_erase hm_er)
          · simp [WordStore.free]
        · rw [hwsSeq_succ]
          have hnec : loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j off) := hne off (Nat.lt_succ_self off)
          simp only [WordStore.free, Finset.mem_erase, ne_eq, hnec, not_false_eq_true, true_and,
            Function.update_of_ne hnec]
          exact ih.2 loc (fun r hr => hne r (Nat.lt_succ_of_lt hr))
  refine ⟨wsSeq N3, regSeq N3, ?_, hmodSeq N3 le_rfl, hbndSeq N3 le_rfl, ?_, ?_⟩
  · have htot := s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq
      (s9.seq (s10.seq (s11.seq (s12.seq s13)))))))))))
    refine htot.weaken rfl rfl ?_ ?_
    · have hN3_le : N3 ≤ 6 + 2 * d + 2 * (M_ceil + 1) := by dsimp [N3]; clear * - hk_M; omega
      clear * - hN3_le; omega
    · have hN3_le : N3 ≤ 6 + 2 * d + 2 * (M_ceil + 1) := by dsimp [N3]; clear * - hk_M; omega
      nlinarith only [hN3_le, hW24, hWW]
  · intro off hoff
    by_cases hlt : off < N3
    · exact (hSeq_spec N3).1 off hlt
    · intro hlive
      have hlive_ws : (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws.live := by
        have hfr := (hSeq_spec N3).2 (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) (fun r hr hc => by
          injection hc with _ ha
          have heq := (nodeCellAddr_inj hoff (lt_of_lt_of_le hr (Nat.le_of_lt hN3_lt)) ha).2
          omega)
        exact hfr.1.mp hlive
      exact hun3 off (by omega) hoff hlive_ws
  · intro loc hne
    exact (hSeq_spec N3).2 loc (fun off hoff => hne off (lt_of_lt_of_le hoff (Nat.le_of_lt hN3_lt)))

def teardownOneLevelRegs (d s₀_d L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 104)
  (.seq (rLoad 7 9 10)
  (.seq (rLit 14 2)
  (.seq (rMul 0 7 14)
  (.seq (rAdd 0 0 14)
  (.seq (clearTreeRegs L)
  (.seq (rLit 10 104)
  (.seq (rLoad 7 9 10)
  (.seq (rLit 14 2)
  (.seq (rMul 0 7 14)
  (.seq (rLit 14 3)
  (.seq (rAdd 0 0 14)
  (.seq (clearTreeRegs L)
  (.seq (freeLevelTab4Regs d s₀_d L)
  (.seq (freeLevelTab3Regs d s₀_d L)
  (.seq (rLit 10 104)
  (.seq (rLoad 7 9 10)
  (.seq (rLit 14 1)
  (.seq (rAdd 7 7 14)
        (rStore 9 10 7)))))))))))))))))))

theorem exec_teardownOneLevelRegs {d s₀_d L B B_cert K_max W M_ceil j : ℕ}
    (hs₀1 : 1 ≤ s₀_d) (hL1 : 1 ≤ L) (hj : j ≤ K_max)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hr104 : ws.read (.heap 9 104) = (j : ℤ))
    (hn111 : (.heap 9 111 : RAMCellLoc) ∉ ws.live)
    (htd : TeardownableLevel d s₀_d L B B_cert j M_ceil ws)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (teardownOneLevelRegs d s₀_d L) ws regs wsEnd regsEnd
        ((M_ceil + 1) * (2100 * L + 2000) + 24 * d + 800)
        (((M_ceil + 1) * (320 * L + 450) + 20 * d + 1000) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      EmptyLevelSlot d L j wsEnd ∧
      wsEnd.read (.heap 9 104) = ((j + 1 : ℕ) : ℤ) ∧
      (.heap 9 111 : RAMCellLoc) ∉ wsEnd.live ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .heap 9 104 →
        loc ∉ treeSliceLocs L (2 * j + 2) →
        loc ∉ treeSliceLocs L (2 * j + 3) →
        (∀ off < posNodeStride d L, loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j off)) →
        (∀ h < 2 ^ L, loc ≠ .heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hWW : 40 * W ≤ W * W := by nlinarith only [hW40]
  have hBr1 : 1 ≤ sqRadBitBound d B B_cert := by unfold sqRadBitBound; omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hl2 : intBitLength (2 : ℤ) ≤ W := (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by omega)
  have hl3 : intBitLength (3 : ℤ) ≤ W := (show intBitLength (3 : ℤ) = 3 from by decide).trans_le (by omega)
  have hl104 : intBitLength (104 : ℤ) ≤ W := (show intBitLength (104 : ℤ) = 8 from by decide).trans_le (by omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by omega)
  have hloc104 : (RAMCellLoc.heap 9 104).bitLength ≤ W :=
    (show (RAMCellLoc.heap 9 104).bitLength = 12 from by decide).trans_le (by omega)
  have hj_bl : intBitLength (j : ℤ) ≤ W := j_bl_of_level (d := d) (L := L) (Nat.le_succ_of_le hj) (by clear * - hW; omega)
  have hj1_bl : intBitLength ((j + 1 : ℕ) : ℤ) ≤ W := j_bl_of_level (d := d) (L := L) (Nat.succ_le_succ hj) (by clear * - hW; omega)
  have h2j_bl : intBitLength (((2 * j : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (2 * j)
    have hns : 4 ≤ posNodeStride d L := by have := posNodeStride_ge_eight d L; omega
    have h2 := natBitLength_mono (show 2 * j ≤ (K_max + 2) * posNodeStride d L by nlinarith only [hj, hns])
    clear * - h1 h2 hW; omega
  have htid2_bl : intBitLength (((2 * j + 2 : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (2 * j + 2)
    have h2 := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (tid := 2 * j + 2) (by omega)
    clear * - h1 h2 hW; omega
  have htid3_bl : intBitLength (((2 * j + 3 : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (2 * j + 3)
    have h2 := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (tid := 2 * j + 3) (by omega)
    clear * - h1 h2 hW; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  rcases htd.tree_Sj with ⟨S_tree, rN, rD, hcS, htrS, hbS⟩
  rcases htd.tree_intact with ⟨B_tree, hcB, htrB⟩
  rcases htd.tab34 with ⟨k_blk, bh, hk_pow, hk_M, hr_k, hbh, hun3, hsp4⟩
  -- 1. Compute r0 := 2 * j + 2 and run clearTreeRegs L
  have a1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 104) (by decide) hl104
  set g1 := Function.update regs 10 104; have bg1 := hbnd.update (r := 10) (by decide) hl104
  have hg1_r : ws.read (.heap 9 (g1 10)) = (j : ℤ) := by simp [g1, hr104]
  have a2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 7) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact hj_bl)
  rw [hg1_r] at a2
  set g2 := Function.update g1 7 (j : ℤ); have bg2 := bg1.update (r := 7) (by decide) hj_bl
  have a3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 2) (by decide) hl2
  set g3 := Function.update g2 14 2; have bg3 := bg2.update (r := 14) (by decide) hl2
  have hm3 : g3 7 * g3 14 = (((2 * j : ℕ) : ℤ)) := by simp [g3, g2]; ring
  have a4 := RegExec.mul (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (a := 7) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hm3]; exact h2j_bl)
  rw [hm3] at a4
  set g4 := Function.update g3 0 (((2 * j : ℕ) : ℤ)); have bg4 := bg3.update (r := 0) (by decide) h2j_bl
  have ha4 : g4 0 + g4 14 = (((2 * j + 2 : ℕ) : ℤ)) := by simp [g4, g3]
  have a5 := RegExec.add (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (a := 0) (b := 14)
    (by decide) (by decide) (by decide) (by rw [ha4]; exact htid2_bl)
  rw [ha4] at a5
  set g5 := Function.update g4 0 (((2 * j + 2 : ℕ) : ℤ)); have bg5 := bg4.update (r := 0) (by decide) htid2_bl
  have hW_tid2 : 2 * sqRadBitBound d B B_cert + natBitLength (2 * j + 2) + L + 20 ≤ W := by
    have ht := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (tid := 2 * j + 2) (by omega)
    clear * - ht hW; omega
  obtain ⟨ws1, regs1, a6, hmod1, bregs1, _, hemp2, hfr1⟩ :=
    exec_clearTreeRegs hfd_le hmod hcCeil0 hbCeil0 hL1 hBr1 hW_tid2
      (fun u hu f hf => mem_posDimWriteLocs_tree (by omega) hu hf)
      (mem_posDimWriteLocs_tab9 (i := 111) (by decide)) hn111
      htrS hbS bg5 (by simp [g5])
  -- 2. Compute r0 := 2 * j + 3 and run clearTreeRegs L
  have hr1_104 : ws1.read (.heap 9 104) = (j : ℤ) := by
    have h := hfr1 (.heap 9 104) (not_in_treeSlice_of_table_ne (by decide) _)
    exact (wordStore_read_congr h).trans hr104
  have hn1_111 : (.heap 9 111 : RAMCellLoc) ∉ ws1.live := by
    rw [(hfr1 (.heap 9 111) (not_in_treeSlice_of_table_ne (by decide) _)).1]; exact hn111
  have htrB1 : TreeStoredAt L (2 * j + 3) B_tree (fun _ => 0) (fun _ => 1) ws1 :=
    htrB.unchanged (fun u hu f hf => hfr1 _ (not_in_treeSlice_of_tid_ne hu hf (by omega)))
  have b1 := RegExec.lit (inp := inp) hfd_le bregs1 (sp_ok hmod1).1 (sp_ok hmod1).2 (dst := 10) (c := 104) (by decide) hl104
  set q1 := Function.update regs1 10 104; have bq1 := bregs1.update (r := 10) (by decide) hl104
  have hq1_r : ws1.read (.heap 9 (q1 10)) = (j : ℤ) := by simp [q1, hr1_104]
  have b2 := RegExec.load (inp := inp) hfd_le bq1 (sp_ok hmod1).1 (sp_ok hmod1).2 (dst := 7) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hq1_r]; exact hj_bl)
  rw [hq1_r] at b2
  set q2 := Function.update q1 7 (j : ℤ); have bq2 := bq1.update (r := 7) (by decide) hj_bl
  have b3 := RegExec.lit (inp := inp) hfd_le bq2 (sp_ok hmod1).1 (sp_ok hmod1).2 (dst := 14) (c := 2) (by decide) hl2
  set q3 := Function.update q2 14 2; have bq3 := bq2.update (r := 14) (by decide) hl2
  have hmq3 : q3 7 * q3 14 = (((2 * j : ℕ) : ℤ)) := by simp [q3, q2]; ring
  have b4 := RegExec.mul (inp := inp) hfd_le bq3 (sp_ok hmod1).1 (sp_ok hmod1).2 (dst := 0) (a := 7) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hmq3]; exact h2j_bl)
  rw [hmq3] at b4
  set q4 := Function.update q3 0 (((2 * j : ℕ) : ℤ)); have bq4 := bq3.update (r := 0) (by decide) h2j_bl
  have b5 := RegExec.lit (inp := inp) hfd_le bq4 (sp_ok hmod1).1 (sp_ok hmod1).2 (dst := 14) (c := 3) (by decide) hl3
  set q5 := Function.update q4 14 3; have bq5 := bq4.update (r := 14) (by decide) hl3
  have haq5 : q5 0 + q5 14 = (((2 * j + 3 : ℕ) : ℤ)) := by simp [q5, q4]
  have b6 := RegExec.add (inp := inp) hfd_le bq5 (sp_ok hmod1).1 (sp_ok hmod1).2 (dst := 0) (a := 0) (b := 14)
    (by decide) (by decide) (by decide) (by rw [haq5]; exact htid3_bl)
  rw [haq5] at b6
  set q6 := Function.update q5 0 (((2 * j + 3 : ℕ) : ℤ)); have bq6 := bq5.update (r := 0) (by decide) htid3_bl
  have hW_tid3 : 2 * 2 + natBitLength (2 * j + 3) + L + 20 ≤ W := by
    have ht := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (tid := 2 * j + 3) (by omega)
    clear * - ht hW; omega
  have hbB : ∀ h ∈ B_tree, h < 2 ^ L ∧ intBitLength (0 : ℤ) ≤ 2 ∧ intBitLength (1 : ℤ) ≤ 2 := by
    intro h hh; exact ⟨htrB1.hS h hh, by decide, by decide⟩
  obtain ⟨ws2, regs2, b7, hmod2, bregs2, _, hemp3, hfr2⟩ :=
    exec_clearTreeRegs hfd_le hmod1 hcCeil0 hbCeil0 hL1 (by decide : 1 ≤ 2) hW_tid3
      (fun u hu f hf => mem_posDimWriteLocs_tree (by omega) hu hf)
      (mem_posDimWriteLocs_tab9 (i := 111) (by decide)) hn1_111
      htrB1 hbB bq6 (by simp [q6])
  -- 3. Lift tab3 and tab4 specs to ws2 and run freeLevelTab4Regs
  have hfr2_ws : ∀ loc : RAMCellLoc,
      loc ∉ treeSliceLocs L (2 * j + 2) → loc ∉ treeSliceLocs L (2 * j + 3) →
      (loc ∈ ws2.live ↔ loc ∈ ws.live) ∧ ws2.vals loc = ws.vals loc := by
    intro loc hn2 hn3'
    exact ⟨(hfr2 loc hn3').1.trans (hfr1 loc hn2).1, (hfr2 loc hn3').2.trans (hfr1 loc hn2).2⟩
  have hread2_eq : ∀ t : ℕ, t ≠ 2 → ∀ z : ℤ, ws2.read (.heap t z) = ws.read (.heap t z) := by
    intro t ht z
    have h := hfr2_ws (.heap t z) (not_in_treeSlice_of_table_ne ht z) (not_in_treeSlice_of_table_ne ht z)
    exact wordStore_read_congr h
  have hr2_104 : ws2.read (.heap 9 104) = (j : ℤ) := (hread2_eq 9 (by decide) 104).trans hr104
  have hr2_k : ws2.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (k_blk : ℤ) :=
    (hread2_eq 3 (by decide) _).trans hr_k
  have hbh2 : ∀ b t, bh b t < 2 ^ L ∧
      ws2.read (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b.val * s₀_d + t.val)))) = (bh b t : ℤ) :=
    fun b t => ⟨(hbh b t).1, (hread2_eq 3 (by decide) _).trans (hbh b t).2⟩
  have hsp4_2 : ∀ h < 2 ^ L,
      (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ ws2.live → ∃ b t, bh b t = h := by
    intro h hh hm
    have hm_ws := (hfr2_ws _ (not_in_treeSlice_of_table_ne (by decide) _)
      (not_in_treeSlice_of_table_ne (by decide) _)).1.mp hm
    exact hsp4 h hh hm_ws
  obtain ⟨ws3, regs3, c1, hmod3, bregs3, hemp4, hfr3⟩ :=
    exec_freeLevelTab4Regs hs₀1 hj (by clear * - hW; omega) hfd_le hmod2 hcCeil hbCeil
      hr2_104 hk_pow hk_M hr2_k hbh2 hsp4_2 bregs2
  -- 4. Lift tab3 specs to ws3 and run freeLevelTab3Regs
  have hread3_eq : ∀ t : ℕ, t ≠ 4 → ∀ z : ℤ, ws3.read (.heap t z) = ws2.read (.heap t z) := by
    intro t ht z
    have h := hfr3 (.heap t z) (by intro _ _ hc; injection hc with hteq; exact ht hteq)
    exact wordStore_read_congr h
  have hr3_104 : ws3.read (.heap 9 104) = (j : ℤ) := (hread3_eq 9 (by decide) 104).trans hr2_104
  have hr3_k : ws3.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (k_blk : ℤ) :=
    (hread3_eq 3 (by decide) _).trans hr2_k
  have hun3_3 : ∀ off, 6 + 2 * d + k_blk * s₀_d ≤ off → off < posNodeStride d L →
      (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ ws3.live := by
    intro off hlo hhi hm3
    have hm2 := (hfr3 _ (by intro _ _ hc; cases hc)).1.mp hm3
    have hm_ws := (hfr2_ws _ (not_in_treeSlice_of_table_ne (by decide) _)
      (not_in_treeSlice_of_table_ne (by decide) _)).1.mp hm2
    exact hun3 off hlo hhi hm_ws
  obtain ⟨ws4, regs4, d1, hmod4, bregs4, hemp_tab3, hfr4⟩ :=
    exec_freeLevelTab3Regs hs₀1 hj (by clear * - hW; omega) hfd_le hmod3 hcCeil hbCeil
      hr3_104 hk_pow hk_M hr3_k hun3_3 bregs3
  -- 5. Increment j in heap 9 104: j -> j + 1
  have hr4_104 : ws4.read (.heap 9 104) = (j : ℤ) := by
    have h := hfr4 (.heap 9 104) (by intro _ _ hc; cases hc)
    exact (wordStore_read_congr h).trans hr3_104
  have e1 := RegExec.lit (inp := inp) hfd_le bregs4 (sp_ok hmod4).1 (sp_ok hmod4).2 (dst := 10) (c := 104) (by decide) hl104
  set p1 := Function.update regs4 10 104; have bp1 := bregs4.update (r := 10) (by decide) hl104
  have hp1_r : ws4.read (.heap 9 (p1 10)) = (j : ℤ) := by simp [p1, hr4_104]
  have e2 := RegExec.load (inp := inp) hfd_le bp1 (sp_ok hmod4).1 (sp_ok hmod4).2 (dst := 7) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hp1_r]; exact hj_bl)
  rw [hp1_r] at e2
  set p2 := Function.update p1 7 (j : ℤ); have bp2 := bp1.update (r := 7) (by decide) hj_bl
  have e3 := RegExec.lit (inp := inp) hfd_le bp2 (sp_ok hmod4).1 (sp_ok hmod4).2 (dst := 14) (c := 1) (by decide) hl1
  set p3 := Function.update p2 14 1; have bp3 := bp2.update (r := 14) (by decide) hl1
  have hap3 : p3 7 + p3 14 = ((j + 1 : ℕ) : ℤ) := by simp [p3, p2]
  have e4 := RegExec.add (inp := inp) hfd_le bp3 (sp_ok hmod4).1 (sp_ok hmod4).2 (dst := 7) (a := 7) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hap3]; exact hj1_bl)
  rw [hap3] at e4
  set p4 := Function.update p3 7 ((j + 1 : ℕ) : ℤ); have bp4 := bp3.update (r := 7) (by decide) hj1_bl
  set wsEnd := ws4.write (.heap 9 104) ((j + 1 : ℕ) : ℤ)
  have hmodEnd : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd :=
    hmod4.write (mem_posDimWriteLocs_tab9 (i := 104) (by decide)) _ hloc104 hj1_bl
  have hwEnd_eq : ws4.write (.heap 9 (p4 10)) (p4 7) = wsEnd := by simp [wsEnd, p4, p3, p2, p1]
  have e5 := RegExec.store (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (wsHeap := ws4) hfd_le bp4 (table := 9) (addr := 10) (val := 7) (by decide) (by decide) hn9
    (by rw [hwEnd_eq]; exact (sp_ok hmodEnd).1) (by rw [hwEnd_eq]; exact (sp_ok hmodEnd).2)
  rw [hwEnd_eq] at e5
  have hempSlot : EmptyLevelSlot d L j wsEnd := by
    refine ⟨?_, ?_, ?_, ?_⟩
    · intro off hoff
      simp only [wsEnd, WordStore.write, Finset.mem_insert]
      rintro (hc | hm); · cases hc
      exact hemp_tab3 off hoff hm
    · intro h hh
      simp only [wsEnd, WordStore.write, Finset.mem_insert]
      rintro (hc | hm); · cases hc
      rw [(hfr4 _ (by intro _ _ hc; cases hc)).1] at hm
      exact hemp4 h hh hm
    · intro u hu f hf
      simp only [wsEnd, WordStore.write, Finset.mem_insert]
      rintro (hc | hm); · cases hc
      rw [(hfr4 _ (by intro _ _ hc; cases hc)).1, (hfr3 _ (by intro _ _ hc; cases hc)).1,
          (hfr2 _ (not_in_treeSlice_of_tid_ne hu hf (by omega))).1] at hm
      exact hemp2 u hu f hf hm
    · intro u hu f hf
      simp only [wsEnd, WordStore.write, Finset.mem_insert]
      rintro (hc | hm); · cases hc
      rw [(hfr4 _ (by intro _ _ hc; cases hc)).1, (hfr3 _ (by intro _ _ hc; cases hc)).1] at hm
      exact hemp3 u hu f hf hm
  have hfrEnd : ∀ loc : RAMCellLoc,
      loc ≠ .heap 9 104 →
      loc ∉ treeSliceLocs L (2 * j + 2) →
      loc ∉ treeSliceLocs L (2 * j + 3) →
      (∀ off < posNodeStride d L, loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j off)) →
      (∀ h < 2 ^ L, loc ≠ .heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) →
      (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc := by
    intro loc hn104 hn2 hn3' hnt3 hnt4
    have hw : (loc ∈ wsEnd.live ↔ loc ∈ ws4.live) ∧ wsEnd.vals loc = ws4.vals loc := by
      simp [wsEnd, WordStore.write, hn104, Function.update_of_ne hn104]
    have h4 := hfr4 loc hnt3
    have h3 := hfr3 loc hnt4
    have h21 := hfr2_ws loc hn2 hn3'
    exact ⟨hw.1.trans (h4.1.trans (h3.1.trans h21.1)),
           hw.2.trans (h4.2.trans (h3.2.trans h21.2))⟩
  have hn111_end : (.heap 9 111 : RAMCellLoc) ∉ wsEnd.live := by
    rw [(hfrEnd (.heap 9 111) (by decide)
      (not_in_treeSlice_of_table_ne (by decide) _)
      (not_in_treeSlice_of_table_ne (by decide) _)
      (by intro _ _ hc; cases hc) (by intro _ _ hc; cases hc)).1]
    exact hn111
  have hr104_end : wsEnd.read (.heap 9 104) = ((j + 1 : ℕ) : ℤ) := by
    simp [wsEnd, WordStore.read, WordStore.write]
  refine ⟨wsEnd, p4, ?_, hmodEnd, bp4, hempSlot, hr104_end, hn111_end, hfrEnd⟩
  have htot := a1.seq (a2.seq (a3.seq (a4.seq (a5.seq (a6.seq (b1.seq (b2.seq
    (b3.seq (b4.seq (b5.seq (b6.seq (b7.seq (c1.seq (d1.seq (e1.seq (e2.seq (e3.seq (e4.seq e5))))))))))))))))))
  refine htot.weaken rfl rfl ?_ ?_
  · nlinarith only [hcS, hcB, hL1]
  · have hov : (2 * W + 16) + (6 * W + 24) + (2 * W + 16) + 4 * W * W + (6 * W + 32) +
               (2 * W + 16) + (6 * W + 24) + (2 * W + 16) + 4 * W * W + (2 * W + 16) + (6 * W + 32) +
               (2 * W + 16) + (6 * W + 24) + (2 * W + 16) + (6 * W + 32) + (5 * W + 24) ≤ 12 * (W * W) := by
      nlinarith only [hW40, hWW]
    have hmS : (S_tree.card + 1) * (70 * L + 60) * W * W ≤
        ((M_ceil + 1) * (70 * L + 60)) * W * W :=
      Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by nlinarith only [hcS, hL1]))
    have hmB : (B_tree.card + 1) * (70 * L + 60) * W * W ≤
        ((2 * M_ceil + 3) * (70 * L + 60)) * W * W :=
      Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by nlinarith only [hcB, hL1]))
    have hsum : ((M_ceil + 1) * (70 * L + 60)) * W * W +
                ((2 * M_ceil + 3) * (70 * L + 60)) * W * W +
                (80 * M_ceil + 340) * W * W +
                (20 * M_ceil + 20 * d + 200) * W * W +
                12 * (W * W) ≤
                ((M_ceil + 1) * (320 * L + 450) + 20 * d + 1000) * W * W := by
      have heq : ((M_ceil + 1) * (70 * L + 60)) * W * W +
          ((2 * M_ceil + 3) * (70 * L + 60)) * W * W +
          (80 * M_ceil + 340) * W * W +
          (20 * M_ceil + 20 * d + 200) * W * W +
          12 * (W * W) =
          ((M_ceil + 1) * (70 * L + 60) + (2 * M_ceil + 3) * (70 * L + 60) +
           (80 * M_ceil + 340) + (20 * M_ceil + 20 * d + 200) + 12) * W * W := by ring
      rw [heq]
      exact Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by nlinarith only [hL1]))
    linarith only [hov, hmS, hmB, hsum]

end UL.C12LVE
