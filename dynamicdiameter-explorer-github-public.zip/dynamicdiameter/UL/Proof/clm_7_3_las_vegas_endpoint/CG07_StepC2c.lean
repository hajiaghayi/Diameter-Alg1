import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2c0
import UL.Proof.clm_7_3_las_vegas_endpoint.CG11_StepC3a
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 2. `buildIntactTreeRegs`: Populate Unit Tree `2 * j + 3` with `Finset.range k_blk` -/

def buildIntactStepStmt (L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 113)
  (.seq (rLoad 0 9 10)
  (.seq (rLit 10 114)
  (.seq (rLoad 1 9 10)
  (.seq (rLit 2 1)
  (.seq (rLit 3 0)
  (.seq (rLit 4 1)
  (.seq (treeSetLeafRegs L)
  (.seq (rLit 10 114)
  (.seq (rLoad 1 9 10)
  (.seq (rLit 4 1)
  (.seq (rAdd 1 1 4)
        (rStore 9 10 1))))))))))))

def buildIntactTreeRegs (d L : ℕ) : BitRAMStmt :=
  let nodeStride := posNodeStride d L
  .seq (rLit 10 10)
  (.seq (rLoad 0 0 10)
  (.seq (rAdd 6 0 0)
  (.seq (rLit 4 3)
  (.seq (rAdd 6 6 4)
  (.seq (rLit 10 113)
  (.seq (rStore 9 10 6)
  (.seq (rLit 10 114)
  (.seq (rLit 4 0)
  (.seq (rStore 9 10 4)
  (.seq (rLit 2 (nodeStride : ℤ))
  (.seq (rMul 2 0 2)
  (.seq (rLit 4 2)
  (.seq (rAdd 2 2 4)
  (.seq (rLoad 5 3 2)
  (.seq (.repeatN (.readLocal 5 (.lit 0)) (buildIntactStepStmt L))
  (.seq (rLit 10 113)
  (.seq (rFree 9 10)
  (.seq (rLit 10 114)
        (rFree 9 10)))))))))))))))))))

theorem exec_buildIntactTreeRegs {d : ℕ} (_hd1 : 1 ≤ d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws : WordStore}
    {L K_max j k_blk : ℕ}
    (hL1 : 1 ≤ L) (hj : j ≤ K_max) (hk_lt : k_blk < 2 ^ L)
    (hW : natBitLength ((K_max + 2) * posNodeStride d L) + L + 32 ≤ W)
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (htree_emp : TreeStoredAt L (2 * j + 3) ∅ (fun _ => 0) (fun _ => 1) ws)
    (hr_j : ws.read (.heap 0 10) = (j : ℤ))
    (hr_k : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (k_blk : ℤ))
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (buildIntactTreeRegs d L) ws regs wsEnd regsEnd
        ((k_blk + 1) * (360 * L + 240) + 160)
        ((k_blk + 1) * (58 * L + 60) * W * W + 100 * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L (2 * j + 3) (Finset.range k_blk) (fun _ => 0) (fun _ => 1) wsEnd ∧
      (.heap 9 113 : RAMCellLoc) ∉ wsEnd.live ∧
      (.heap 9 114 : RAMCellLoc) ∉ wsEnd.live ∧
      (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L (2 * j + 3) →
        loc ≠ .heap 9 113 → loc ≠ .heap 9 114 →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  set nodeStride := posNodeStride d L
  set tid := 2 * j + 3
  have htid_lt : tid < 2 * K_max + 6 := by dsimp [tid]; omega
  have hW32 : 32 ≤ W := by clear * - hW; omega
  have hWW : 32 * W ≤ W * W := by nlinarith only [hW32]
  have hj1 : j ≤ K_max + 1 := Nat.le_succ_of_le hj
  have hW_node : natBitLength ((K_max + 2) * nodeStride) + 8 ≤ W := by clear * - hW; omega
  have hns_pos : 0 < nodeStride := by dsimp [nodeStride, posNodeStride]; have := Nat.zero_le (2 ^ L); omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hCeil0C : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hCeil0B : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by clear * - hW32; omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by clear * - hW32; omega)
  have hl2 : intBitLength (2 : ℤ) ≤ W := (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by clear * - hW32; omega)
  have hl3 : intBitLength (3 : ℤ) ≤ W := (show intBitLength (3 : ℤ) = 3 from by decide).trans_le (by clear * - hW32; omega)
  have hl10 : intBitLength (10 : ℤ) ≤ W := (show intBitLength (10 : ℤ) = 5 from by decide).trans_le (by clear * - hW32; omega)
  have hl113 : intBitLength (113 : ℤ) ≤ W := (show intBitLength (113 : ℤ) = 8 from by decide).trans_le (by clear * - hW32; omega)
  have hl114 : intBitLength (114 : ℤ) ≤ W := (show intBitLength (114 : ℤ) = 8 from by decide).trans_le (by clear * - hW32; omega)
  have hn0 : natBitLength 0 ≤ W := (show natBitLength 0 = 1 from by decide).trans_le (by clear * - hW32; omega)
  have hn3 : natBitLength 3 ≤ W := (show natBitLength 3 = 2 from by decide).trans_le (by clear * - hW32; omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by clear * - hW32; omega)
  have hloc113 : (RAMCellLoc.heap 9 113).bitLength ≤ W := (show (RAMCellLoc.heap 9 113).bitLength = 12 from by decide).trans_le (by clear * - hW32; omega)
  have hloc114 : (RAMCellLoc.heap 9 114).bitLength ≤ W := (show (RAMCellLoc.heap 9 114).bitLength = 12 from by decide).trans_le (by clear * - hW32; omega)
  have htid_nbl : natBitLength tid ≤ natBitLength ((K_max + 2) * nodeStride) := by
    refine natBitLength_mono ?_
    have hns3 : 3 ≤ nodeStride := by dsimp [nodeStride, posNodeStride]; have := Nat.zero_le (2 ^ L); omega
    calc tid = 2 * j + 3 := rfl
      _ ≤ 3 * (K_max + 2) := by omega
      _ ≤ (K_max + 2) * nodeStride := by rw [Nat.mul_comm 3]; exact Nat.mul_le_mul_left _ hns3
  have htid_bl : intBitLength (tid : ℤ) ≤ W := (intBitLength_ofNat_le tid).trans (by clear * - htid_nbl hW; omega)
  have h2j_bl : intBitLength (((2 * j : ℕ) : ℤ)) ≤ W := (intBitLength_natCast_mono (show 2 * j ≤ tid from by dsimp [tid]; omega)).trans htid_bl
  have hj_bl : intBitLength (j : ℤ) ≤ W := (intBitLength_natCast_mono (show j ≤ tid from by dsimp [tid]; omega)).trans htid_bl
  have hstride_bl : intBitLength (nodeStride : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le nodeStride
    have h2 := natBitLength_mono (Nat.le_mul_of_pos_left nodeStride (show 0 < K_max + 2 from by clear * -; omega))
    clear * - h1 h2 hW; omega
  obtain ⟨_, hn0_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 0) hns_pos hW_node
  obtain ⟨_, hn2_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 2) (by dsimp [nodeStride, posNodeStride]; have := Nat.zero_le (2 ^ L); omega) hW_node
  have hk_bl : intBitLength (k_blk : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hk_lt).trans (by clear * - hW; omega)
  have hb_bl : ∀ b ≤ k_blk, intBitLength (b : ℤ) ≤ W := fun b hb =>
    (intBitLength_natCast_mono hb).trans hk_bl
  have p1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 10) (by decide) hl10
  set g1 := Function.update regs 10 10; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hl10
  have hr_g1 : ws.read (.heap 0 (g1 10)) = (j : ℤ) := by simp [g1, hr_j]
  have p2 := (RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 0) (table := 0) (addr := 10) (by decide) (by decide) hn0 (hr_g1 ▸ hj_bl)).weaken rfl (by rw [hr_g1]) le_rfl le_rfl
  set g2 := Function.update g1 0 (j : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 0) (by decide) hj_bl
  have ea3 : g2 0 + g2 0 = (((2 * j : ℕ) : ℤ)) := by simp [g2]; ring
  have p3 := (RegExec.add (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 6) (a := 0) (b := 0) (by decide) (by decide) (by decide) (ea3 ▸ h2j_bl)).weaken rfl (by rw [ea3]) le_rfl le_rfl
  set g3 := Function.update g2 6 (((2 * j : ℕ) : ℤ)); have bg3 : RegBounded W g3 := bg2.update (r := 6) (by decide) h2j_bl
  have p4 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 4) (c := 3) (by decide) hl3
  set g4 := Function.update g3 4 3; have bg4 : RegBounded W g4 := bg3.update (r := 4) (by decide) hl3
  have ea5 : g4 6 + g4 4 = (tid : ℤ) := by simp [g4, g3, tid]
  have p5 := (RegExec.add (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 6) (a := 6) (b := 4) (by decide) (by decide) (by decide) (ea5 ▸ htid_bl)).weaken rfl (by rw [ea5]) le_rfl le_rfl
  set g5 := Function.update g4 6 (tid : ℤ); have bg5 : RegBounded W g5 := bg4.update (r := 6) (by decide) htid_bl
  have p6 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 113) (by decide) hl113
  set g6 := Function.update g5 10 113; have bg6 : RegBounded W g6 := bg5.update (r := 10) (by decide) hl113
  set ws1 := ws.write (.heap 9 113) (tid : ℤ)
  have hm1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws1 := hmod.write (mem_posDimWriteLocs_tab9 (by decide)) (tid : ℤ) hloc113 htid_bl
  have p7 : RegExec inp fd W C_cell C_bit (rStore 9 10 6) ws g6 ws1 g6 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le bg6 (table := 9) (addr := 10) (val := 6) (by decide) (by decide) hn9
      (by simpa [g6, g5] using (sp_ok hm1).1) (by simpa [g6, g5] using (sp_ok hm1).2)).weaken
      (by simp [g6, g5, ws1]) rfl le_rfl le_rfl
  have p8 := RegExec.lit (inp := inp) hfd_le bg6 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 10) (c := 114) (by decide) hl114
  set g8 := Function.update g6 10 114; have bg8 : RegBounded W g8 := bg6.update (r := 10) (by decide) hl114
  have p9 := RegExec.lit (inp := inp) hfd_le bg8 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 4) (c := 0) (by decide) hl0
  set g9 := Function.update g8 4 0; have bg9 : RegBounded W g9 := bg8.update (r := 4) (by decide) hl0
  set ws2 := ws1.write (.heap 9 114) 0
  have hm2 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws2 := hm1.write (mem_posDimWriteLocs_tab9 (by decide)) 0 hloc114 hl0
  have p10 : RegExec inp fd W C_cell C_bit (rStore 9 10 4) ws1 g9 ws2 g9 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le bg9 (table := 9) (addr := 10) (val := 4) (by decide) (by decide) hn9
      (by simpa [g9, g8] using (sp_ok hm2).1) (by simpa [g9, g8] using (sp_ok hm2).2)).weaken
      (by simp [g9, g8, ws2]) rfl le_rfl le_rfl
  have p11 := RegExec.lit (inp := inp) hfd_le bg9 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 2) (c := (nodeStride : ℤ)) (by decide) hstride_bl
  set g11 := Function.update g9 2 (nodeStride : ℤ); have bg11 : RegBounded W g11 := bg9.update (r := 2) (by decide) hstride_bl
  have em12 : g11 0 * g11 2 = nodeCellAddr nodeStride j 0 := by
    simp [g11, g9, g8, g6, g5, g4, g3, g2, nodeCellAddr]
  have p12 := (RegExec.mul (inp := inp) hfd_le bg11 (sp_ok hm2).1 (sp_ok hm2).2
    (dst := 2) (a := 0) (b := 2) (by decide) (by decide) (by decide) (em12 ▸ hn0_bl)).weaken rfl (by rw [em12]) le_rfl le_rfl
  set g12 := Function.update g11 2 (nodeCellAddr nodeStride j 0); have bg12 : RegBounded W g12 := bg11.update (r := 2) (by decide) hn0_bl
  have p13 := RegExec.lit (inp := inp) hfd_le bg12 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 4) (c := 2) (by decide) hl2
  set g13 := Function.update g12 4 2; have bg13 : RegBounded W g13 := bg12.update (r := 4) (by decide) hl2
  have ea14 : g13 2 + g13 4 = nodeCellAddr nodeStride j 2 := by simp [g13, g12, nodeCellAddr]
  have p14 := (RegExec.add (inp := inp) hfd_le bg13 (sp_ok hm2).1 (sp_ok hm2).2
    (dst := 2) (a := 2) (b := 4) (by decide) (by decide) (by decide) (ea14 ▸ hn2_bl)).weaken rfl (by rw [ea14]) le_rfl le_rfl
  set g14 := Function.update g13 2 (nodeCellAddr nodeStride j 2); have bg14 : RegBounded W g14 := bg13.update (r := 2) (by decide) hn2_bl
  have hr_g14 : ws2.read (.heap 3 (g14 2)) = (k_blk : ℤ) := by
    simp only [g14, Function.update_self, ws2, ws1]
    rw [wordStore_read_write_ne _ (fun h => by cases h), wordStore_read_write_ne _ (fun h => by cases h)]
    exact hr_k
  have p15 := (RegExec.load (inp := inp) hfd_le bg14 (sp_ok hm2).1 (sp_ok hm2).2
    (dst := 5) (table := 3) (addr := 2) (by decide) (by decide) hn3 (hr_g14 ▸ hk_bl)).weaken rfl (by rw [hr_g14]) le_rfl le_rfl
  set g15 := Function.update g14 5 (k_blk : ℤ); have bg15 : RegBounded W g15 := bg14.update (r := 5) (by decide) hk_bl
  have path_sub_slice : ∀ b < 2 ^ L, treePathLocs L tid b ⊆ treeSliceLocs L tid := by
    intro b hb loc hloc
    unfold treePathLocs at hloc
    rcases Finset.mem_image.mp hloc with ⟨⟨k, f⟩, hkf, rfl⟩
    obtain ⟨hk, hf⟩ := Finset.mem_product.mp hkf
    have hk_le : k ≤ L := by have := Finset.mem_range.mp hk; omega
    have hoff : b / 2 ^ k < 2 ^ (L - k) := by
      rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add, Nat.sub_add_cancel hk_le]
      exact hb
    have hu := (treeIdx_bounds hk_le hoff).2
    unfold treeSliceLocs
    exact Finset.mem_image.mpr ⟨(treeIdx L k (b / 2 ^ k), f),
      Finset.mem_product.mpr ⟨Finset.mem_range.mpr hu, hf⟩, rfl⟩
  let IntactInv : ℕ → WordStore → (ℕ → ℤ) → Prop := fun b w r =>
    b ≤ k_blk ∧
    ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
    RegBounded W r ∧
    TreeStoredAt L tid (Finset.range b) (fun _ => 0) (fun _ => 1) w ∧
    w.read (.heap 9 113) = (tid : ℤ) ∧
    w.read (.heap 9 114) = (b : ℤ) ∧
    (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L tid → loc ≠ .heap 9 113 → loc ≠ .heap 9 114 →
      (loc ∈ w.live ↔ loc ∈ ws.live) ∧ w.vals loc = ws.vals loc)
  have hInt0 : IntactInv 0 ws2 g15 := by
    refine ⟨Nat.zero_le _, hm2, bg15, ?_, ?_, ?_, ?_⟩
    · simpa using (htree_emp.unchanged (fun _ _ _ _ => by
        dsimp [ws2, ws1, WordStore.write]
        exact ⟨by simp, by rw [Function.update_of_ne (fun h => by cases h), Function.update_of_ne (fun h => by cases h)]⟩))
    · dsimp [ws2, ws1]; rw [wordStore_read_write_ne _ (by decide), wordStore_read_write_self]
    · dsimp [ws2]; rw [wordStore_read_write_self]
    · intro loc _ h113 h114
      dsimp [ws2, ws1, WordStore.write]
      exact ⟨by simp [h114, h113], by simp [Function.update_of_ne h114, Function.update_of_ne h113]⟩
  obtain ⟨wsL, regsL, p16, ⟨_, hmL, bgL, htreeL, _, _, hunchL⟩⟩ :=
    c2_repeatReg_inv (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      (cntReg := 5) (by decide) k_blk (by simp [g15])
      IntactInv hInt0 bg15
      (U := 360 * L + 240) (B := (58 * L + 50) * W * W)
      (fun b hb w r ⟨_, hmw, br, htree_w, hr113, hr114, hunch_w⟩ => by
        have hb_lt2L : b < 2 ^ L := lt_trans hb hk_lt
        have q1 := RegExec.lit (inp := inp) hfd_le br (sp_ok hmw).1 (sp_ok hmw).2 (dst := 10) (c := 113) (by decide) hl113
        set u1 := Function.update r 10 113; have bu1 : RegBounded W u1 := br.update (r := 10) (by decide) hl113
        have hr_u1 : w.read (.heap 9 (u1 10)) = (tid : ℤ) := by simp [u1, hr113]
        have q2 := (RegExec.load (inp := inp) hfd_le bu1 (sp_ok hmw).1 (sp_ok hmw).2
          (dst := 0) (table := 9) (addr := 10) (by decide) (by decide) hn9 (hr_u1 ▸ htid_bl)).weaken rfl (by rw [hr_u1]) le_rfl le_rfl
        set u2 := Function.update u1 0 (tid : ℤ); have bu2 : RegBounded W u2 := bu1.update (r := 0) (by decide) htid_bl
        have q3 := RegExec.lit (inp := inp) hfd_le bu2 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 10) (c := 114) (by decide) hl114
        set u3 := Function.update u2 10 114; have bu3 : RegBounded W u3 := bu2.update (r := 10) (by decide) hl114
        have hr_u3 : w.read (.heap 9 (u3 10)) = (b : ℤ) := by simp [u3, hr114]
        have q4 := (RegExec.load (inp := inp) hfd_le bu3 (sp_ok hmw).1 (sp_ok hmw).2
          (dst := 1) (table := 9) (addr := 10) (by decide) (by decide) hn9 (hr_u3 ▸ hb_bl b (Nat.le_of_lt hb))).weaken rfl (by rw [hr_u3]) le_rfl le_rfl
        set u4 := Function.update u3 1 (b : ℤ); have bu4 : RegBounded W u4 := bu3.update (r := 1) (by decide) (hb_bl b (Nat.le_of_lt hb))
        have q5 := RegExec.lit (inp := inp) hfd_le bu4 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 2) (c := 1) (by decide) hl1
        set u5 := Function.update u4 2 1; have bu5 : RegBounded W u5 := bu4.update (r := 2) (by decide) hl1
        have q6 := RegExec.lit (inp := inp) hfd_le bu5 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 3) (c := 0) (by decide) hl0
        set u6 := Function.update u5 3 0; have bu6 : RegBounded W u6 := bu5.update (r := 3) (by decide) hl0
        have q7 := RegExec.lit (inp := inp) hfd_le bu6 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 4) (c := 1) (by decide) hl1
        set u7 := Function.update u6 4 1; have bu7 : RegBounded W u7 := bu6.update (r := 4) (by decide) hl1
        obtain ⟨wT, u8, q8, hmwT, bu8, htreeT, hunchT⟩ :=
          exec_treeSetLeafRegs hfd_le hmw hCeil0C hCeil0B hL1 hb_lt2L (B_r := 2) (by decide)
            (by clear * - htid_nbl hW; omega)
            (treePathLocs_sub_posDimWriteLocs htid_lt hb_lt2L)
            htree_w
            (S' := Finset.range (b + 1)) (rNum' := fun _ => 0) (rDen' := fun _ => 1)
            (fun x hx => ⟨lt_of_lt_of_le (lt_of_lt_of_le (Finset.mem_range.mp hx) hb) (Nat.le_of_lt hk_lt), by dsimp only; decide, by dsimp only; decide⟩)
            (fun x hne => by simp only [Finset.mem_range]; omega)
            (fun _ _ => rfl) (fun _ _ => rfl) true (by simp [Finset.mem_range])
            bu7 (by simp [u7, u6, u5, u4, u3, u2]) (by simp [u7, u6, u5, u4])
            (by simp [u7, u6, u5]) (fun _ => by simp [u7, u6]) (fun _ => by simp [u7])
        have not_path9 : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∉ treePathLocs L tid b := by
          intro z hm; rcases Finset.mem_image.mp hm with ⟨⟨_, _⟩, _, hc⟩; cases hc
        have hrT_113 : wT.read (.heap 9 113) = (tid : ℤ) := by
          rw [wordStore_read_eq_vals hmwT.wf, (hunchT _ (not_path9 113)).2, ← wordStore_read_eq_vals hmw.wf]
          exact hr113
        have hrT_114 : wT.read (.heap 9 114) = (b : ℤ) := by
          rw [wordStore_read_eq_vals hmwT.wf, (hunchT _ (not_path9 114)).2, ← wordStore_read_eq_vals hmw.wf]
          exact hr114
        have q9 := RegExec.lit (inp := inp) hfd_le bu8 (sp_ok hmwT).1 (sp_ok hmwT).2 (dst := 10) (c := 114) (by decide) hl114
        set u9 := Function.update u8 10 114; have bu9 : RegBounded W u9 := bu8.update (r := 10) (by decide) hl114
        have hr_u9 : wT.read (.heap 9 (u9 10)) = (b : ℤ) := by simp [u9, hrT_114]
        have q10 := (RegExec.load (inp := inp) hfd_le bu9 (sp_ok hmwT).1 (sp_ok hmwT).2
          (dst := 1) (table := 9) (addr := 10) (by decide) (by decide) hn9 (hr_u9 ▸ hb_bl b (Nat.le_of_lt hb))).weaken rfl (by rw [hr_u9]) le_rfl le_rfl
        set u10 := Function.update u9 1 (b : ℤ); have bu10 : RegBounded W u10 := bu9.update (r := 1) (by decide) (hb_bl b (Nat.le_of_lt hb))
        have q11 := RegExec.lit (inp := inp) hfd_le bu10 (sp_ok hmwT).1 (sp_ok hmwT).2 (dst := 4) (c := 1) (by decide) hl1
        set u11 := Function.update u10 4 1; have bu11 : RegBounded W u11 := bu10.update (r := 4) (by decide) hl1
        have ea12 : u11 1 + u11 4 = (((b + 1 : ℕ) : ℤ)) := by simp [u11, u10]
        have q12 := (RegExec.add (inp := inp) hfd_le bu11 (sp_ok hmwT).1 (sp_ok hmwT).2
          (dst := 1) (a := 1) (b := 4) (by decide) (by decide) (by decide) (ea12 ▸ hb_bl (b + 1) hb)).weaken rfl (by rw [ea12]) le_rfl le_rfl
        set u12 := Function.update u11 1 (((b + 1 : ℕ) : ℤ)); have bu12 : RegBounded W u12 := bu11.update (r := 1) (by decide) (hb_bl (b + 1) hb)
        set w' := wT.write (.heap 9 114) (((b + 1 : ℕ) : ℤ))
        have hmw' := hmwT.write (mem_posDimWriteLocs_tab9 (by decide)) (((b + 1 : ℕ) : ℤ)) hloc114 (hb_bl (b + 1) hb)
        have q13 : RegExec inp fd W C_cell C_bit (rStore 9 10 1) wT u12 w' u12 6 (5 * W + 24) :=
          (RegExec.store (inp := inp) hfd_le bu12 (table := 9) (addr := 10) (val := 1) (by decide) (by decide) hn9
            (by simpa [u12, u11, u10, u9] using (sp_ok hmw').1)
            (by simpa [u12, u11, u10, u9] using (sp_ok hmw').2)).weaken
            (by simp [u12, u11, u10, u9, w']) rfl le_rfl le_rfl
        have qStep := (q1.seq (q2.seq (q3.seq (q4.seq (q5.seq (q6.seq (q7.seq (q8.seq
          (q9.seq (q10.seq (q11.seq (q12.seq q13)))))))))))).weaken rfl rfl
          (u₂ := 360 * L + 240) (b₂ := (58 * L + 50) * W * W)
          (by clear * -; omega)
          (by
            have h1 : 43 * W + 240 ≤ 18 * W * W := by
              calc 43 * W + 240 ≤ 18 * (32 * W) := by clear * - hW32; omega
              _ ≤ 18 * (W * W) := Nat.mul_le_mul_left 18 hWW
              _ = 18 * W * W := by ring
            have h2 : (56 * L + 32) * W * W + 18 * W * W ≤ (58 * L + 50) * W * W := by
              calc (56 * L + 32) * W * W + 18 * W * W = (56 * L + 50) * (W * W) := by ring
              _ ≤ (58 * L + 50) * (W * W) := Nat.mul_le_mul_right (W * W) (by omega)
              _ = (58 * L + 50) * W * W := by ring
            linarith only [h1, h2])
        refine ⟨w', u12, qStep, hb, hmw', bu12,
          htreeT.unchanged (fun _ _ _ _ => by
            dsimp [w', WordStore.write]
            exact ⟨by simp, by rw [Function.update_of_ne (fun h => by cases h)]⟩),
          by dsimp [w']; rw [wordStore_read_write_ne _ (by decide)]; exact hrT_113,
          by dsimp [w']; rw [wordStore_read_write_self],
          fun loc hns h113 h114 => ?_⟩
        have hnp : loc ∉ treePathLocs L tid b := fun hp => hns (path_sub_slice b hb_lt2L hp)
        have uT := hunchT loc hnp
        have uPrev := hunch_w loc hns h113 h114
        dsimp only [w', WordStore.write]
        exact ⟨by simp [h114, uT.1, uPrev.1], by simp [Function.update_of_ne h114, uT.2, uPrev.2]⟩)
  have p17 := RegExec.lit (inp := inp) hfd_le bgL (sp_ok hmL).1 (sp_ok hmL).2 (dst := 10) (c := 113) (by decide) hl113
  set z1 := Function.update regsL 10 113; have bz1 : RegBounded W z1 := bgL.update (r := 10) (by decide) hl113
  set wsF1 := wsL.free (.heap 9 113); have hmF1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsF1 := hmL.free (mem_posDimWriteLocs_tab9 (by decide))
  have p18 : RegExec inp fd W C_cell C_bit (rFree 9 10) wsL z1 wsF1 z1 4 (3 * W + 16) :=
    (RegExec.free (inp := inp) bz1 (table := 9) (addr := 10) (by decide) hn9).weaken (by simp [z1, wsF1]) rfl le_rfl le_rfl
  have p19 := RegExec.lit (inp := inp) hfd_le bz1 (sp_ok hmF1).1 (sp_ok hmF1).2 (dst := 10) (c := 114) (by decide) hl114
  set z2 := Function.update z1 10 114; have bz2 : RegBounded W z2 := bz1.update (r := 10) (by decide) hl114
  set wsEnd := wsF1.free (.heap 9 114); have hmEnd : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd := hmF1.free (mem_posDimWriteLocs_tab9 (by decide))
  have p20 : RegExec inp fd W C_cell C_bit (rFree 9 10) wsF1 z2 wsEnd z2 4 (3 * W + 16) :=
    (RegExec.free (inp := inp) bz2 (table := 9) (addr := 10) (by decide) hn9).weaken (by simp [z2, wsEnd]) rfl le_rfl le_rfl
  have hTot := (p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq (p7.seq (p8.seq (p9.seq (p10.seq
    (p11.seq (p12.seq (p13.seq (p14.seq (p15.seq (p16.seq (p17.seq (p18.seq (p19.seq p20))))))))))))))))))).weaken rfl rfl
    (u₂ := (k_blk + 1) * (360 * L + 240) + 160)
    (b₂ := (k_blk + 1) * (58 * L + 60) * W * W + 100 * W * W)
    (by nlinarith only [hL1])
    (by
      have h1 : k_blk * ((58 * L + 50) * W * W) ≤ (k_blk + 1) * (58 * L + 60) * W * W := by
        calc k_blk * ((58 * L + 50) * W * W) = (k_blk * (58 * L + 50)) * (W * W) := by ring
        _ ≤ ((k_blk + 1) * (58 * L + 60)) * (W * W) := Nat.mul_le_mul_right (W * W) (by nlinarith only [hL1])
        _ = (k_blk + 1) * (58 * L + 60) * W * W := by ring
      have h2 : 65 * W + 380 ≤ 96 * W * W := by
        calc 65 * W + 380 ≤ 96 * (32 * W) := by clear * - hW32; omega
        _ ≤ 96 * (W * W) := Nat.mul_le_mul_left 96 hWW
        _ = 96 * W * W := by ring
      have h3 : 4 * W * W + 96 * W * W = 100 * W * W := by ring
      linarith only [h1, h2, h3])
  have htreeEnd : TreeStoredAt L tid (Finset.range k_blk) (fun _ => 0) (fun _ => 1) wsEnd :=
    htreeL.unchanged (fun _ _ _ _ => by
      dsimp [wsEnd, wsF1, WordStore.free]
      exact ⟨by simp, by rw [Function.update_of_ne (fun h => by cases h), Function.update_of_ne (fun h => by cases h)]⟩)
  refine ⟨wsEnd, z2, hTot, hmEnd, bz2, htreeEnd,
    by simp [wsEnd, wsF1, WordStore.free],
    by simp [wsEnd, WordStore.free],
    fun loc hns h113 h114 => ?_⟩
  have uL := hunchL loc hns h113 h114
  dsimp only [wsEnd, wsF1, WordStore.free]
  exact ⟨by simp [h114, h113, uL.1], by simp [Function.update_of_ne h114, Function.update_of_ne h113, uL.2]⟩

/-! ### 3. `incJFromHeap0Regs`: Increment `j` in `.heap 0 10` and Write Back to `jSrc` -/

def JSourceValid : JSource → Prop
  | .heap0_10 => True
  | .heap9 addr => addr < 256 ∧ addr ≠ 110
  | .reg r => r < 16

theorem jSourceValid_of_holds {jSrc : JSource} {j : ℕ} {ws : WordStore} {regs : ℕ → ℤ}
    (h : JSourceHolds jSrc j ws regs) : JSourceValid jSrc := by
  cases jSrc with
  | heap0_10 => trivial
  | heap9 addr => exact ⟨h.1, h.2.1⟩
  | reg r => exact h.1

def incJTailRegs : JSource → BitRAMStmt
  | .heap0_10 => .skip
  | .heap9 addr => .seq (rLit 10 (addr : ℤ)) (rStore 9 10 7)
  | .reg r => rCopy r 7

def incJFromHeap0Regs (jSrc : JSource) : BitRAMStmt :=
  .seq (rLit 10 10)
  (.seq (rLoad 7 0 10)
  (.seq (rLit 8 1)
  (.seq (rAdd 7 7 8)
  (.seq (rStore 0 10 7)
        (incJTailRegs jSrc)))))

theorem exec_incJFromHeap0Regs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {L K_max j : ℕ}
    (hW : 24 ≤ W)
    (hj_bl : intBitLength (j : ℤ) ≤ W)
    (hj1_bl : intBitLength (((j + 1 : ℕ) : ℤ)) ≤ W)
    {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hr_j : ws.read (.heap 0 10) = (j : ℤ))
    {jSrc : JSource} (hj_val : JSourceValid jSrc)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (incJFromHeap0Regs jSrc) ws regs wsEnd regsEnd
        50 (40 * W + 160) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      wsEnd.read (.heap 0 10) = (((j + 1 : ℕ) : ℤ)) ∧
      JSourceHolds jSrc (j + 1) wsEnd regsEnd ∧
      (∀ loc : RAMCellLoc, loc ≠ .heap 0 10 →
        (∀ addr : ℕ, jSrc = .heap9 addr → loc ≠ .heap 9 (addr : ℤ)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hl10 : intBitLength (10 : ℤ) ≤ W := (show intBitLength (10 : ℤ) = 5 from by decide).trans_le (by omega)
  have hn0 : natBitLength 0 ≤ W := (show natBitLength 0 = 1 from by decide).trans_le (by omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by omega)
  have hloc0_10 : (RAMCellLoc.heap 0 10).bitLength ≤ W :=
    (show (RAMCellLoc.heap 0 10).bitLength = 6 from by decide).trans_le (by omega)
  have p1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 10) (by decide) hl10
  set g1 := Function.update regs 10 10; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hl10
  have hr_g1 : ws.read (.heap 0 (g1 10)) = (j : ℤ) := by simp [g1, hr_j]
  have p2 := (RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 7) (table := 0) (addr := 10) (by decide) (by decide) hn0 (hr_g1 ▸ hj_bl)).weaken rfl (by rw [hr_g1]) le_rfl le_rfl
  set g2 := Function.update g1 7 (j : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 7) (by decide) hj_bl
  have p3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := 1) (by decide) hl1
  set g3 := Function.update g2 8 1; have bg3 : RegBounded W g3 := bg2.update (r := 8) (by decide) hl1
  have ea4 : g3 7 + g3 8 = (((j + 1 : ℕ) : ℤ)) := by simp [g3, g2]
  have p4 := (RegExec.add (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 7) (a := 7) (b := 8) (by decide) (by decide) (by decide) (ea4 ▸ hj1_bl)).weaken rfl (by rw [ea4]) le_rfl le_rfl
  set g4 := Function.update g3 7 (((j + 1 : ℕ) : ℤ)); have bg4 : RegBounded W g4 := bg3.update (r := 7) (by decide) hj1_bl
  set ws1 := ws.write (.heap 0 10) (((j + 1 : ℕ) : ℤ))
  have hm1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws1 := hmod.write (mem_posDimWriteLocs_tab0 (i := 10) (by decide)) (((j + 1 : ℕ) : ℤ)) hloc0_10 hj1_bl
  have p5 : RegExec inp fd W C_cell C_bit (rStore 0 10 7) ws g4 ws1 g4 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le bg4 (table := 0) (addr := 10) (val := 7) (by decide) (by decide) hn0
      (by simpa [g4, g3, g2, g1, ws1] using (sp_ok hm1).1)
      (by simpa [g4, g3, g2, g1, ws1] using (sp_ok hm1).2)).weaken
      (by simp [g4, g3, g2, g1, ws1]) rfl le_rfl le_rfl
  cases jSrc with
  | heap0_10 =>
      have p6 := RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws1) bg4
      have hTot := (p1.seq (p2.seq (p3.seq (p4.seq (p5.seq p6))))).weaken rfl rfl (u₂ := 50) (b₂ := 40 * W + 160) (by clear * -; omega) (by clear * -; omega)
      have hr0_end : ws1.read (.heap 0 10) = (((j + 1 : ℕ) : ℤ)) := by
        dsimp [ws1]; rw [wordStore_read_write_self]
      refine ⟨ws1, g4, hTot, hm1, bg4, hr0_end, hr0_end, fun loc hne _ => ?_⟩
      dsimp [ws1, WordStore.write]
      exact ⟨by simp [hne], by simp [Function.update_of_ne hne]⟩
  | heap9 addr =>
      rcases hj_val with ⟨haddr_lt, haddr_ne⟩
      have hl_addr9 : intBitLength (addr : ℤ) ≤ 9 := by
        have h1 := intBitLength_ofNat_le addr
        have h2 := natBitLength_mono (show addr ≤ 255 from by omega)
        have h3 : natBitLength 255 = 8 := by decide
        omega
      have hl_addr : intBitLength (addr : ℤ) ≤ W := hl_addr9.trans (by omega)
      have hloc9 : (RAMCellLoc.heap 9 (addr : ℤ)).bitLength ≤ W := by
        dsimp only [RAMCellLoc.bitLength]
        have : natBitLength 9 = 4 := by decide
        omega
      have p6 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 10) (c := (addr : ℤ)) (by decide) hl_addr
      set g5 := Function.update g4 10 (addr : ℤ); have bg5 : RegBounded W g5 := bg4.update (r := 10) (by decide) hl_addr
      set ws2 := ws1.write (.heap 9 (addr : ℤ)) (((j + 1 : ℕ) : ℤ))
      have hm2 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws2 := hm1.write (mem_posDimWriteLocs_tab9 haddr_lt) (((j + 1 : ℕ) : ℤ)) hloc9 hj1_bl
      have p7 : RegExec inp fd W C_cell C_bit (rStore 9 10 7) ws1 g5 ws2 g5 6 (5 * W + 24) :=
        (RegExec.store (inp := inp) hfd_le bg5 (table := 9) (addr := 10) (val := 7) (by decide) (by decide) hn9
          (by simpa [g5, g4, ws2] using (sp_ok hm2).1)
          (by simpa [g5, g4, ws2] using (sp_ok hm2).2)).weaken
          (by simp [g5, g4, ws2]) rfl le_rfl le_rfl
      have hTot := (p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq p7)))))).weaken rfl rfl (u₂ := 50) (b₂ := 40 * W + 160) (by clear * -; omega) (by clear * -; omega)
      have hr0_end : ws2.read (.heap 0 10) = (((j + 1 : ℕ) : ℤ)) := by
        dsimp [ws2, ws1]
        rw [wordStore_read_write_ne _ (fun h => by cases h), wordStore_read_write_self]
      have hr9_end : ws2.read (.heap 9 (addr : ℤ)) = (((j + 1 : ℕ) : ℤ)) := by
        dsimp [ws2]; rw [wordStore_read_write_self]
      refine ⟨ws2, g5, hTot, hm2, bg5, hr0_end, ⟨haddr_lt, haddr_ne, hr9_end⟩, fun loc hne0 hne9 => ?_⟩
      have hne_a := hne9 addr rfl
      dsimp [ws2, ws1, WordStore.write]
      exact ⟨by simp [hne_a, hne0], by simp [Function.update_of_ne hne_a, Function.update_of_ne hne0]⟩
  | reg r =>
      have hr_lt : r < 16 := hj_val
      have p6 := RegExec.copy (inp := inp) hfd_le bg4 (sp_ok hm1).1 (sp_ok hm1).2 (dst := r) (src := 7) hr_lt (by decide)
      set g5 := Function.update g4 r (g4 7); have bg5 : RegBounded W g5 := bg4.update (r := r) hr_lt (by simpa [g4] using hj1_bl)
      have hTot := (p1.seq (p2.seq (p3.seq (p4.seq (p5.seq p6))))).weaken rfl rfl (u₂ := 50) (b₂ := 40 * W + 160) (by clear * -; omega) (by clear * -; omega)
      have hr0_end : ws1.read (.heap 0 10) = (((j + 1 : ℕ) : ℤ)) := by
        dsimp [ws1]; rw [wordStore_read_write_self]
      refine ⟨ws1, g5, hTot, hm1, bg5, hr0_end, ⟨hr_lt, by simp [g5, g4]⟩, fun loc hne _ => ?_⟩
      dsimp [ws1, WordStore.write]
      exact ⟨by simp [hne], by simp [Function.update_of_ne hne]⟩

end UL.C12StepC2

