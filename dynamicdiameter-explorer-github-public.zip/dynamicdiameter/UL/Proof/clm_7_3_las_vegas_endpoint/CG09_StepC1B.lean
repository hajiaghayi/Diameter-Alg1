import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG09_StepC1B1
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 3. Unstaging `heap 5, 6, 7` (`clearStageA2Regs`) & Combined Gather+Stage Corollary -/

def clearStageCoordStepStmt : BitRAMStmt :=
  .seq (rFree 6 6)
  (.seq (rFree 7 6)
        (rAdd 6 6 15))

def clearStageA2Regs (d : ℕ) : BitRAMStmt :=
  .seq (rLit 8 0)
  (.seq (rLoad 2 5 8)
  (.seq (rFree 5 8)
  (.seq (rLit 8 1)
  (.seq (rFree 5 8)
  (.seq (rLit 7 (d : ℤ))
  (.seq (rMul 5 2 7)
  (.seq (rLit 6 1)
  (.seq (rLit 15 1)
        (.repeatN (.readLocal 5 (.lit 0)) clearStageCoordStepStmt)))))))))

theorem exec_clearStageA2Regs {d L K_max W m : ℕ}
    (hd1 : 1 ≤ d) (hm_le : m ≤ 2 ^ L)
    (hW : natBitLength d + L + 28 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws : WordStore} {regs : ℕ → ℤ}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hbnd : RegBounded W regs)
    (hr50 : ws.read (.heap 5 0) = (m : ℤ))
    (hlive567 : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ,
      (.heap t z : RAMCellLoc) ∈ ws.live → (.heap t z : RAMCellLoc) ∈ stageA2Locs d m) :
    ∃ wsClean regsClean,
      RegExec inp fd W C_cell C_bit (clearStageA2Regs d) ws regs wsClean regsClean
        (20 * m * d + 60) ((16 * m * d + 20) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsClean ∧
      RegBounded W regsClean ∧
      (∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsClean.live) ∧
      (∀ loc : RAMCellLoc, loc ∉ stageA2Locs d m →
        (loc ∈ wsClean.live ↔ loc ∈ ws.live) ∧ wsClean.vals loc = ws.vals loc) := by
  have hW28 : 28 ≤ W := by clear * - hW; omega
  have hWW : 28 * W ≤ W * W := by nlinarith only [hW28]
  have hSubStage : stageA2Locs d m ⊆ posDimWriteLocs d L K_max :=
    stageA2Locs_sub_posDimWriteLocs hd1 hm_le
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hn5 : natBitLength 5 ≤ W := (show natBitLength 5 = 3 from by decide).trans_le (by omega)
  have hn6 : natBitLength 6 ≤ W := (show natBitLength 6 = 3 from by decide).trans_le (by omega)
  have hn7 : natBitLength 7 ≤ W := (show natBitLength 7 = 3 from by decide).trans_le (by omega)
  have hd_bl : intBitLength (d : ℤ) ≤ W := (intBitLength_ofNat_le d).trans (by clear * - hW; omega)
  have hm_bl : intBitLength (m : ℤ) ≤ W :=
    (intBitLength_natCast_mono hm_le).trans ((nat_pow2_bitLength_le L).trans (by clear * - hW; omega))
  have htop_bl : intBitLength (((m * d + 1 : ℕ) : ℤ)) ≤ natBitLength d + L + 14 := by
    have hm_lt1 : m < 2 ^ (L + 1) := by
      have hp : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
      rw [pow_succ]; omega
    have hc_top := (coordCellAddr_bl (L := L + 1) (W := natBitLength d + (L + 1) + 12)
      hm_lt1 hd1 (f := 1) (by decide) le_rfl).2
    unfold coordCellAddr at hc_top
    exact (intBitLength_natCast_mono (show m * d + 1 ≤ (m * d + 0) * 2 + 1 by omega)).trans
      (by clear * - hc_top; omega)
  have hk1_bl : ∀ k ≤ m * d, intBitLength (((k + 1 : ℕ) : ℤ)) ≤ W := fun k hk =>
    ((intBitLength_natCast_mono (by omega)).trans htop_bl).trans (by clear * - hW; omega)
  have hmd_bl : intBitLength (((m * d : ℕ) : ℤ)) ≤ W :=
    ((intBitLength_natCast_mono (by omega)).trans htop_bl).trans (by clear * - hW; omega)
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := 0) (by decide) hl0
  set g1 := Function.update regs 8 0; have bg1 := hbnd.update (r := 8) (by decide) hl0
  have hg1_r : ws.read (.heap 5 (g1 8)) = (m : ℤ) := by simp [g1, hr50]
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 2) (table := 5) (addr := 8)
    (by decide) (by decide) hn5 (by rw [hg1_r]; exact hm_bl)
  rw [hg1_r] at s2
  set g2 := Function.update g1 2 (m : ℤ); have bg2 := bg1.update (r := 2) (by decide) hm_bl
  have s3 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) bg2 (table := 5) (addr := 8) (by decide) hn5
  set w1 := ws.free (.heap 5 0)
  have hw1 : ws.free (.heap 5 (g2 8)) = w1 := by simp [w1, g2, g1]
  rw [hw1] at s3
  have hm1 := hmod.free (hSubStage (mem_stageA2Locs_50 d m))
  have s4 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 8) (c := 1) (by decide) hl1
  set g4 := Function.update g2 8 1; have bg4 := bg2.update (r := 8) (by decide) hl1
  have s5 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := w1) bg4 (table := 5) (addr := 8) (by decide) hn5
  set w2 := w1.free (.heap 5 1)
  have hw2 : w1.free (.heap 5 (g4 8)) = w2 := by simp [w2, g4]
  rw [hw2] at s5
  have hm2 := hm1.free (hSubStage (mem_stageA2Locs_51 d m))
  have s6 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 7) (c := (d : ℤ)) (by decide) hd_bl
  set g6 := Function.update g4 7 (d : ℤ); have bg6 := bg4.update (r := 7) (by decide) hd_bl
  have hm_g6 : g6 2 * g6 7 = (((m * d : ℕ) : ℤ)) := by simp [g6, g4, g2]
  have s7 := RegExec.mul (inp := inp) hfd_le bg6 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 5) (a := 2) (b := 7)
    (by decide) (by decide) (by decide) (by rw [hm_g6]; exact hmd_bl)
  rw [hm_g6] at s7
  set g7 := Function.update g6 5 (((m * d : ℕ) : ℤ)); have bg7 := bg6.update (r := 5) (by decide) hmd_bl
  have s8 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 6) (c := 1) (by decide) hl1
  set g8 := Function.update g7 6 1; have bg8 := bg7.update (r := 6) (by decide) hl1
  have s9 := RegExec.lit (inp := inp) hfd_le bg8 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 15) (c := 1) (by decide) hl1
  set g9 := Function.update g8 15 1; have bg9 := bg8.update (r := 15) (by decide) hl1
  -- Loop `k = 0 .. m * d - 1`
  set N := m * d
  let wsSeq : ℕ → WordStore := fun n =>
    Nat.rec w2 (fun k acc => (acc.free (.heap 6 (((k + 1 : ℕ) : ℤ)))).free (.heap 7 (((k + 1 : ℕ) : ℤ)))) n
  have hwsSeq_succ : ∀ k,
      wsSeq (k + 1) = ((wsSeq k).free (.heap 6 (((k + 1 : ℕ) : ℤ)))).free (.heap 7 (((k + 1 : ℕ) : ℤ))) :=
    fun _ => rfl
  let regSeq : ℕ → ℕ → ℤ := fun n => Function.update g9 6 (((n + 1 : ℕ) : ℤ))
  have hmodSeq : ∀ n ≤ N, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (wsSeq n) := by
    intro n hn; induction n with
    | zero => exact hm2
    | succ k ih =>
        have hk_lt : k < m * d := Nat.lt_of_succ_le hn
        exact ((ih (Nat.le_of_succ_le hn)).free (hSubStage (mem_stageA2Locs_6 hk_lt))).free
          (hSubStage (mem_stageA2Locs_7 hk_lt))
  have hbndSeq : ∀ n ≤ N, RegBounded W (regSeq n) := fun n hn =>
    bg9.update (r := 6) (by decide) (hk1_bl n hn)
  have hstep : ∀ k < N, RegExec inp fd W C_cell C_bit clearStageCoordStepStmt
      (wsSeq k) (regSeq k) (wsSeq (k + 1)) (regSeq (k + 1)) 16 (12 * W + 64) := by
    intro k hk
    have f1 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit)
      (wsHeap := wsSeq k) (hbndSeq k (Nat.le_of_lt hk)) (table := 6) (addr := 6) (by decide) hn6
    have f2 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit)
      (wsHeap := (wsSeq k).free (.heap 6 (regSeq k 6))) (hbndSeq k (Nat.le_of_lt hk))
      (table := 7) (addr := 6) (by decide) hn7
    have hfree_eq : ((wsSeq k).free (.heap 6 (regSeq k 6))).free (.heap 7 (regSeq k 6)) = wsSeq (k + 1) := by
      rw [hwsSeq_succ]; simp [regSeq]
    rw [hfree_eq] at f2
    have hadd_eq : regSeq k 6 + regSeq k 15 = (((k + 1 + 1 : ℕ) : ℤ)) := by
      simp [regSeq, g9]
    have f3 := RegExec.add (inp := inp) hfd_le (hbndSeq k (Nat.le_of_lt hk))
      (sp_ok (hmodSeq (k + 1) (Nat.succ_le_of_lt hk))).1
      (sp_ok (hmodSeq (k + 1) (Nat.succ_le_of_lt hk))).2
      (dst := 6) (a := 6) (b := 15) (by decide) (by decide) (by decide)
      (by rw [hadd_eq]; exact hk1_bl (k + 1) (Nat.succ_le_of_lt hk))
    rw [hadd_eq] at f3
    have hreg_eq : Function.update (regSeq k) 6 (((k + 1 + 1 : ℕ) : ℤ)) = regSeq (k + 1) := by
      ext r; simp [regSeq]
    exact (f1.seq (f2.seq f3)).weaken rfl hreg_eq (by omega) (by omega)
  have hg9_eq : regSeq 0 = g9 := by
    ext r
    by_cases hr6 : r = 6
    · subst hr6; simp [regSeq, g9, g8]
    · simp [regSeq, hr6]
  have s10 := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (cntReg := 5) (by decide) N wsSeq regSeq
    (by rw [hg9_eq]; simp [g9, g8, g7, N])
    (hbndSeq 0 (Nat.zero_le _)) hstep
  rw [hg9_eq] at s10
  have hSeq_spec : ∀ n,
      (∀ k < n, (.heap 6 (((k + 1 : ℕ) : ℤ)) : RAMCellLoc) ∉ (wsSeq n).live ∧
                (.heap 7 (((k + 1 : ℕ) : ℤ)) : RAMCellLoc) ∉ (wsSeq n).live) ∧
      (∀ loc : RAMCellLoc,
        (∀ k < n, loc ≠ .heap 6 (((k + 1 : ℕ) : ℤ)) ∧ loc ≠ .heap 7 (((k + 1 : ℕ) : ℤ))) →
        (loc ∈ (wsSeq n).live ↔ loc ∈ w2.live) ∧ (wsSeq n).vals loc = w2.vals loc) := by
    intro n; induction n with
    | zero => exact ⟨fun k h => absurd h (Nat.not_lt_zero _), fun _ _ => ⟨Iff.rfl, rfl⟩⟩
    | succ k ih =>
        refine ⟨fun r hr => ?_, fun loc hne => ?_⟩
        · rw [hwsSeq_succ]
          rcases Nat.lt_succ_iff_lt_or_eq.mp hr with hlt | rfl
          · exact ⟨fun hm_l => (ih.1 r hlt).1 (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hm_l)),
                   fun hm_l => (ih.1 r hlt).2 (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hm_l))⟩
          · exact ⟨by simp [WordStore.free], by simp [WordStore.free]⟩
        · rw [hwsSeq_succ]
          obtain ⟨hne6, hne7⟩ := hne k (Nat.lt_succ_self k)
          simp only [WordStore.free, Finset.mem_erase, ne_eq, hne6, hne7, not_false_eq_true, true_and,
            Function.update_of_ne hne6, Function.update_of_ne hne7]
          exact ih.2 loc (fun r hr => hne r (Nat.lt_succ_of_lt hr))
  set wsClean := wsSeq N
  have hfr_clean : ∀ loc : RAMCellLoc, loc ∉ stageA2Locs d m →
      (loc ∈ wsClean.live ↔ loc ∈ ws.live) ∧ wsClean.vals loc = ws.vals loc := by
    intro loc hn_st
    have e1 := (hSeq_spec N).2 loc (fun k hk =>
      ⟨fun h => hn_st (h ▸ mem_stageA2Locs_6 hk), fun h => hn_st (h ▸ mem_stageA2Locs_7 hk)⟩)
    have h50 : loc ≠ .heap 5 0 := fun h => hn_st (h ▸ mem_stageA2Locs_50 d m)
    have h51 : loc ≠ .heap 5 1 := fun h => hn_st (h ▸ mem_stageA2Locs_51 d m)
    have e2 : (loc ∈ w2.live ↔ loc ∈ ws.live) ∧ w2.vals loc = ws.vals loc := by
      simp [w2, w1, WordStore.free, h50, h51, Function.update_of_ne h50, Function.update_of_ne h51]
    exact ⟨e1.1.trans e2.1, e1.2.trans e2.2⟩
  have hemp_clean : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsClean.live := by
    intro t ht z hlive
    have hlive_ws : (.heap t z : RAMCellLoc) ∈ ws.live := by
      have h1 : ∀ n, (.heap t z : RAMCellLoc) ∈ (wsSeq n).live → (.heap t z : RAMCellLoc) ∈ w2.live := by
        intro n; induction n with
        | zero => exact id
        | succ k ih =>
            rw [hwsSeq_succ]; intro hm_l
            exact ih (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hm_l))
      exact Finset.mem_of_mem_erase (Finset.mem_of_mem_erase (h1 N hlive))
    have hmem_st := hlive567 t ht z hlive_ws
    unfold stageA2Locs at hmem_st
    simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image,
      Finset.mem_range] at hmem_st
    rcases hmem_st with ((h50 | h51) | ⟨k, hk, h6⟩) | ⟨k, hk, h7⟩
    · rw [h50] at hlive
      have hw2_not : (.heap 5 0 : RAMCellLoc) ∉ w2.live := by simp [w2, w1, WordStore.free, show (RAMCellLoc.heap 5 0 ≠ .heap 5 1) by decide]
      exact hw2_not (((hSeq_spec N).2 _ (fun _ _ => ⟨(fun hc => by cases hc), (fun hc => by cases hc)⟩)).1.mp hlive)
    · rw [h51] at hlive
      have hw2_not : (.heap 5 1 : RAMCellLoc) ∉ w2.live := by simp [w2, WordStore.free]
      exact hw2_not (((hSeq_spec N).2 _ (fun _ _ => ⟨(fun hc => by cases hc), (fun hc => by cases hc)⟩)).1.mp hlive)
    · rw [← h6] at hlive
      exact ((hSeq_spec N).1 k hk).1 hlive
    · rw [← h7] at hlive
      exact ((hSeq_spec N).1 k hk).2 hlive
  refine ⟨wsClean, regSeq N, ?_, hmodSeq N le_rfl, hbndSeq N le_rfl, hemp_clean, hfr_clean⟩
  have htot := s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq s10))))))))
  refine htot.weaken rfl rfl ?_ ?_
  · have h20 : 20 * m * d = 20 * (m * d) := by ring
    dsimp [N]; omega
  · set WW := W * W
    have hstep_b : 12 * W + 64 ≤ 16 * WW := by dsimp [WW]; nlinarith only [hW28, hWW]
    have hN_b : N * (12 * W + 64) ≤ (16 * (m * d)) * WW := by
      calc N * (12 * W + 64)
        _ ≤ N * (16 * WW) := Nat.mul_le_mul_left N hstep_b
        _ = (16 * (m * d)) * WW := by dsimp [N]; ring
    have htot_eq : (2 * W + 16) + ((6 * W + 24) + ((3 * W + 16) + ((2 * W + 16) +
        ((3 * W + 16) + ((2 * W + 16) + (4 * W * W + ((2 * W + 16) + ((2 * W + 16) +
        (N * (12 * W + 64) + (W + 12)))))))))) =
        N * (12 * W + 64) + (4 * WW + 23 * W + 148) := by dsimp [WW]; ring
    have hov : 4 * WW + 23 * W + 148 ≤ 20 * WW := by
      dsimp [WW]; nlinarith only [hW28, hWW]
    have hsum : (16 * (m * d)) * WW + 20 * WW = (16 * m * d + 20) * W * W := by dsimp [WW]; ring
    linarith only [htot_eq, hN_b, hov, hsum]

/-- Combined Step C1 Gather + A.2 Staging when the residual pool is non-empty (`1 ≤ M`, e.g. `M > L_leaf`). -/
def posDimStepC1GatherAndStage (d s₀_d B L : ℕ) : BitRAMStmt :=
  .seq (posDimStepC1Gather d s₀_d L) (stageBufForA2Regs d B)


theorem exec_posDimStepC1GatherAndStage
    (h_del_wit : S_claim_A_2_deletion_witness)
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P' : DynamicPointSet d} (hwfP' : P'.WellFormed n)
    {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {qMap' : ℕ → Fin d → ℚ}
    {k : ℕ} (hk_le : k ≤ K_max)
    {vecNodes : Fin k → ChainNode d}
    {updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    (hupd_len : updatedNodes.length = k)
    {jStar : ℕ} (hjStar_le : jStar ≤ k)
    (hM1 : 1 ≤ (chainInput ltCoords' vecNodes (activeLifetimes P')
                  ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩).card)
    (hnoTrig_prefix : ∀ (j : ℕ) (hj : j < jStar),
      let v' := updatedNodes.get ⟨j, hupd_len ▸ lt_of_lt_of_le hj hjStar_le⟩
      (v'.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (v'.birthPool.card : ℝ) / 16)
    (hmb_suffix : ∀ (j : ℕ) (hj : j < k), jStar ≤ j →
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).birthPool.card ≤
        2 * ((chainInput ltCoords' vecNodes (activeLifetimes P')
              ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩).card + 1))
    {wsB : WordStore} {regsB : ℕ → ℤ}
    (hmodB : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsB)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hbndB : RegBounded W regsB)
    (hrk_B : wsB.read (.heap 0 10) = (k : ℤ))
    (hr106_B : wsB.read (.heap 9 106) = (jStar : ℤ))
    (hcoordsB : ActiveCoordsStored d L B P'.activeHandles qMap' wsB)
    (htree0B : TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsB)
    (htree1B : TreeStoredAt L 1
      ((chainInput ltCoords' vecNodes (activeLifetimes P') (Fin.last k)).image (handleOfLifetime P'))
      (fun _ => 0) (fun _ => 1) wsB)
    (hpreB : ∀ (j : ℕ) (hj : j < k),
      PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap'
        (chainInput ltCoords' vecNodes (activeLifetimes P') ⟨j, Nat.lt_succ_of_lt hj⟩)
        (updatedNodes.get ⟨j, hupd_len ▸ hj⟩) j wsB)
    (hemptyB : ∀ j : ℕ, k ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j wsB)
    (hclean58B : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7 ∨ t = 8) → ∀ z : ℤ,
      (.heap t z : RAMCellLoc) ∉ wsB.live)
    (hclean9B : ∀ z : ℤ, z ≠ 102 → z ≠ 103 → z ≠ 104 → z ≠ 105 → z ≠ 106 →
      (.heap 9 z : RAMCellLoc) ∉ wsB.live) :
    let S_new := chainInput ltCoords' vecNodes (activeLifetimes P')
    let R_jStar := S_new ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩
    let H_jStar := R_jStar.image (handleOfLifetime P')
    let M := H_jStar.card
    let prefixNodes := updatedNodes.take jStar
    ∃ wsStaged regsStaged,
      RegExec inp fd W C_cell C_bit (posDimStepC1GatherAndStage d s₀_d B L)
        wsB regsB wsStaged regsStaged
        ((k + 1) * ((M + 1) * (3200 * L + 120 * d + 3100) + 24 * d + 1200))
        ((k + 1) * ((M + 1) * (500 * L + 24 * d + 720) + 20 * d + 1400) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsStaged ∧
      RegBounded W regsStaged ∧
      M = R_jStar.card ∧ M ≤ n ∧ M < 2 ^ L ∧
      StagingA2Matches M B wsStaged (stagedA2Input qMap' (minPopElem H_jStar) M B) ∧
      wsStaged.read (.heap 0 0) = wsB.read (.heap 0 0) ∧
      wsStaged.read (.heap 0 10) = (jStar : ℤ) ∧
      wsStaged.read (.heap 9 110) = (M : ℤ) ∧
      (∀ idx < M, wsStaged.read (.heap 8 (idx : ℤ)) = (minPopElem H_jStar idx : ℤ)) ∧
      ActiveCoordsStored d L B P'.activeHandles qMap' wsStaged ∧
      TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsStaged ∧
      TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsStaged ∧
      (∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L 1 u f) : RAMCellLoc) ∉ wsStaged.live) ∧
      (∀ (j : ℕ) (hj : j < jStar),
        LevelStoredInv n L B B_cert K_max P' ltCoords' qMap'
          (S_new ⟨j, Nat.lt_succ_of_lt (lt_of_lt_of_le hj hjStar_le)⟩)
          (prefixNodes.get ⟨j, by rw [List.length_take_of_le (hupd_len ▸ hjStar_le)]; exact hj⟩)
          j wsStaged) ∧
      (∀ j : ℕ, jStar ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j wsStaged) ∧
      (∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ,
        (.heap t z : RAMCellLoc) ∈ wsStaged.live → (.heap t z : RAMCellLoc) ∈ stageA2Locs d M) ∧
      (∀ z : ℤ, (∀ idx < M, z ≠ (idx : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsStaged.live) ∧
      (∀ z : ℤ, z ≠ 110 → (.heap 9 z : RAMCellLoc) ∉ wsStaged.live) := by
  intro S_new R_jStar H_jStar M prefixNodes
  obtain ⟨wsC1, regsC1, hExec1, hmodC1, bregsC1, hM_eq, hM_n, hM_pow,
    hr00, hr010, hr110, hbufC1, hH_elem, _, _,
    hcoordsC1, htree0C1, htree1C1, hemp1C1, hlvlC1, hemptyC1,
    hclean57C1, hclean8C1, hclean9C1⟩ :=
    exec_posDimStepC1Gather h_del_wit hd1 hs₀1 hn hL hB1 hBc1 hW hfd_le hwfP' hk_le
      hupd_len hjStar_le hnoTrig_prefix hmb_suffix hmodB hcCeil hbCeil hbndB
      hrk_B hr106_B hcoordsB htree0B htree1B hpreB hemptyB hclean58B hclean9B
  have hB_le_sq : B ≤ sqRadBitBound d B B_cert := by
    unfold sqRadBitBound; nlinarith only [hd1, hB1]
  have hW_st : B + natBitLength d + L + 28 ≤ W := by clear * - hW hB_le_sq; omega
  have hM1' : 1 ≤ M := hM1.trans_eq hM_eq.symm
  obtain ⟨wsStaged, regsStaged, hExec2, hmodSt, bregsSt, hStage, hlive567St, hfrSt⟩ :=
    exec_stageBufForA2Regs hd1 hM1' hB1 (Nat.le_of_lt hM_pow) hW_st hfd_le
      hmodC1 hcCeil hbCeil bregsC1 hcoordsC1 hr110 hbufC1
      (fun idx hidx => (hH_elem idx hidx).1) hclean57C1
  have not_in_stage : ∀ (t : ℕ) (ht : t ≠ 5 ∧ t ≠ 6 ∧ t ≠ 7) (z : ℤ),
      (.heap t z : RAMCellLoc) ∈ wsStaged.live ↔ (.heap t z : RAMCellLoc) ∈ wsC1.live := fun t ht z =>
    (hfrSt (.heap t z) (by
      intro hm; unfold stageA2Locs at hm
      simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image] at hm
      rcases hm with (((hc | hc) | ⟨_, _, hc⟩) | ⟨_, _, hc⟩)
      · injection hc with e; exact ht.1 e
      · injection hc with e; exact ht.1 e
      · injection hc with e; exact ht.2.1 e.symm
      · injection hc with e; exact ht.2.2 e.symm)).1
  have eq_out_stage : ∀ (t : ℕ) (ht : t ≠ 5 ∧ t ≠ 6 ∧ t ≠ 7) (z : ℤ),
      ((.heap t z : RAMCellLoc) ∈ wsStaged.live ↔ (.heap t z : RAMCellLoc) ∈ wsC1.live) ∧
      wsStaged.vals (.heap t z) = wsC1.vals (.heap t z) := fun t ht z =>
    hfrSt (.heap t z) (by
      intro hm; unfold stageA2Locs at hm
      simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image] at hm
      rcases hm with (((hc | hc) | ⟨_, _, hc⟩) | ⟨_, _, hc⟩)
      · injection hc with e; exact ht.1 e
      · injection hc with e; exact ht.1 e
      · injection hc with e; exact ht.2.1 e.symm
      · injection hc with e; exact ht.2.2 e.symm)
  refine ⟨wsStaged, regsStaged, ?_, hmodSt, bregsSt, hM_eq, hM_n, hM_pow, hStage,
    (wordStore_read_congr (eq_out_stage 0 ⟨(by decide), (by decide), (by decide)⟩ 0)).trans hr00,
    (wordStore_read_congr (eq_out_stage 0 ⟨(by decide), (by decide), (by decide)⟩ 10)).trans hr010,
    (wordStore_read_congr (eq_out_stage 9 ⟨(by decide), (by decide), (by decide)⟩ 110)).trans hr110,
    fun idx hidx => (wordStore_read_congr (eq_out_stage 8 ⟨(by decide), (by decide), (by decide)⟩ _)).trans (hbufC1 idx hidx),
    hcoordsC1.unchanged (fun _ _ _ _ _ _ => wordStore_read_congr (eq_out_stage 1 ⟨(by decide), (by decide), (by decide)⟩ _)),
    htree0C1.unchanged (fun _ _ _ _ => eq_out_stage 2 ⟨(by decide), (by decide), (by decide)⟩ _),
    htree1C1.unchanged (fun _ _ _ _ => eq_out_stage 2 ⟨(by decide), (by decide), (by decide)⟩ _),
    fun u hu f hf => by rw [not_in_stage 2 ⟨(by decide), (by decide), (by decide)⟩ _]; exact hemp1C1 u hu f hf,
    fun j hj => (hlvlC1 j hj).unchanged hmodC1.wf hmodSt.wf
      (fun _ _ => eq_out_stage 3 ⟨(by decide), (by decide), (by decide)⟩ _)
      (fun _ _ => eq_out_stage 4 ⟨(by decide), (by decide), (by decide)⟩ _)
      (fun _ _ _ _ => eq_out_stage 2 ⟨(by decide), (by decide), (by decide)⟩ _)
      (fun _ _ _ _ => eq_out_stage 2 ⟨(by decide), (by decide), (by decide)⟩ _),
    fun j hlo hhi => (hemptyC1 j hlo hhi).unchanged
      (fun _ _ hm => (not_in_stage 3 ⟨(by decide), (by decide), (by decide)⟩ _).mp hm)
      (fun _ _ hm => (not_in_stage 4 ⟨(by decide), (by decide), (by decide)⟩ _).mp hm)
      (fun _ _ _ _ hm => (not_in_stage 2 ⟨(by decide), (by decide), (by decide)⟩ _).mp hm)
      (fun _ _ _ _ hm => (not_in_stage 2 ⟨(by decide), (by decide), (by decide)⟩ _).mp hm),
    hlive567St,
    fun z hne => by rw [not_in_stage 8 ⟨(by decide), (by decide), (by decide)⟩ _]; exact hclean8C1 z hne,
    fun z hne => by rw [not_in_stage 9 ⟨(by decide), (by decide), (by decide)⟩ _]; exact hclean9C1 z hne⟩
  refine (hExec1.seq hExec2).weaken rfl rfl ?_ ?_
  · have h1 : (M + 1) * (120 * d + 40) ≤ (M + 1) * (120 * d + 100) := Nat.mul_le_mul_left _ (by omega)
    have h2 : (k + 1) * ((M + 1) * (3200 * L + 3000) + 24 * d + 1200) + (M + 1) * (120 * d + 40) ≤
        (k + 1) * ((M + 1) * (3200 * L + 120 * d + 3100) + 24 * d + 1200) := by
      have hk1 : 1 ≤ k + 1 := Nat.succ_pos k
      have hsub : (M + 1) * (120 * d + 100) ≤ (k + 1) * ((M + 1) * (120 * d + 100)) :=
        Nat.le_mul_of_pos_left _ hk1
      have hsplit : (k + 1) * ((M + 1) * (3200 * L + 120 * d + 3100) + 24 * d + 1200) =
          (k + 1) * ((M + 1) * (3200 * L + 3000) + 24 * d + 1200) +
          (k + 1) * ((M + 1) * (120 * d + 100)) := by ring
      linarith only [h1, hsub, hsplit]
    exact h2
  · have hcoef : (k + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) + (M + 1) * (24 * d + 12) ≤
        (k + 1) * ((M + 1) * (500 * L + 24 * d + 720) + 20 * d + 1400) := by
      have hk1 : 1 ≤ k + 1 := Nat.succ_pos k
      have hsub : (M + 1) * (24 * d + 20) ≤ (k + 1) * ((M + 1) * (24 * d + 20)) :=
        Nat.le_mul_of_pos_left _ hk1
      have hle1 : (M + 1) * (24 * d + 12) ≤ (M + 1) * (24 * d + 20) :=
        Nat.mul_le_mul_left _ (by omega)
      have hsplit : (k + 1) * ((M + 1) * (500 * L + 24 * d + 720) + 20 * d + 1400) =
          (k + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) +
          (k + 1) * ((M + 1) * (24 * d + 20)) := by ring
      linarith only [hle1, hsub, hsplit]
    have heq : (k + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) * W * W +
        (M + 1) * (24 * d + 12) * W * W =
        ((k + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) + (M + 1) * (24 * d + 12)) * W * W := by ring
    rw [heq]
    exact Nat.mul_le_mul_right W (Nat.mul_le_mul_right W hcoef)

end UL.C12LVE
