import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2b2_SubExpr
set_option autoImplicit false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Finite-union sum/cardinality helpers and base-location classification -/

private lemma finset_sum_insert_le {α : Type*} [DecidableEq α]
    (a : α) (S : Finset α) (w : α → ℕ) :
    ∑ x ∈ insert a S, w x ≤ w a + ∑ x ∈ S, w x := by
  by_cases ha : a ∈ S
  · rw [Finset.insert_eq_of_mem ha]; omega
  · rw [Finset.sum_insert ha]

private lemma finset_sum_union_le {α : Type*} [DecidableEq α]
    (A B : Finset α) (w : α → ℕ) :
    ∑ x ∈ A ∪ B, w x ≤ ∑ x ∈ A, w x + ∑ x ∈ B, w x := by
  induction A using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      rw [Finset.insert_union, Finset.sum_insert ha]
      have h1 := finset_sum_insert_le a (s ∪ B) w
      omega

private lemma finset_sum_image_le {α β : Type*} [DecidableEq α] [DecidableEq β]
    (S : Finset α) (f : α → β) (w : β → ℕ) :
    ∑ y ∈ S.image f, w y ≤ ∑ x ∈ S, w (f x) := by
  induction S using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      rw [Finset.image_insert, Finset.sum_insert ha]
      exact (finset_sum_insert_le (f a) (s.image f) w).trans (Nat.add_le_add_left ih _)

private lemma finset_sum_biUnion_le {α β : Type*} [DecidableEq α] [DecidableEq β]
    (S : Finset α) (g : α → Finset β) (w : β → ℕ) :
    ∑ y ∈ S.biUnion g, w y ≤ ∑ x ∈ S, ∑ y ∈ g x, w y := by
  induction S using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      rw [Finset.biUnion_insert, Finset.sum_insert ha]
      exact le_trans (finset_sum_union_le _ _ w) (Nat.add_le_add_left ih _)

private lemma finset_card_biUnion_one_le {α β : Type*} [DecidableEq α] [DecidableEq β]
    (S : Finset α) (g : α → Finset β) (hg : ∀ x ∈ S, (g x).card ≤ 1) :
    (S.biUnion g).card ≤ S.card := by
  calc (S.biUnion g).card
      ≤ ∑ x ∈ S, (g x).card := Finset.card_biUnion_le
    _ ≤ ∑ _x ∈ S, 1 := Finset.sum_le_sum hg
    _ = S.card := by simp

/-- Locations owned by the caller at `frameDepth = 1`: heap tables `< 10` and `.localFrame 1 _ _`. -/
def IsA2BaseLoc : RAMCellLoc → Prop
  | .heap t _ => t < 10
  | .localFrame d _ _ => d = 1

def IsA2BaseStore (wsBase : WordStore) : Prop :=
  WellFormedWS wsBase ∧ ∀ loc ∈ wsBase.live, IsA2BaseLoc loc

/-! ### 2. Relational invariant `A2SimInv` for the `sid` free-stack live-heap tracker -/

structure A2SimInv (wsBase : WordStore) (T_max S_max : ℕ)
    (wsSub wsSim : WordStore)
    (highSid : ℕ) (sidOfEnc : ℤ → Option ℕ) (encOfSid : ℕ → ℤ)
    (freeStack : List ℕ) : Prop where
  wfBase : IsA2BaseStore wsBase
  wfSub : WellFormedWS wsSub
  wfSim : WellFormedWS wsSim
  hT : 1 ≤ T_max
  high_le : highSid ≤ S_max
  sub_tables : ∀ t idx, (.heap t idx : RAMCellLoc) ∈ wsSub.live → t < T_max
  -- Base store agreement
  base_live : ∀ loc, IsA2BaseLoc loc → (loc ∈ wsSim.live ↔ loc ∈ wsBase.live)
  base_vals : ∀ loc, IsA2BaseLoc loc → wsSim.vals loc = wsBase.vals loc
  -- Subroutine local frames (`d` mapped to `2 + d`)
  local_live : ∀ d var idx,
    (.localFrame (2 + d) var idx : RAMCellLoc) ∈ wsSim.live ↔
      (.localFrame d var idx : RAMCellLoc) ∈ wsSub.live
  local_vals : ∀ d var idx,
    wsSim.vals (.localFrame (2 + d) var idx) = wsSub.vals (.localFrame d var idx)
  -- Subroutine heap table 10 (`enc = idx * T_max + t`)
  tab10_live : ∀ e : ℤ,
    (.heap 10 e : RAMCellLoc) ∈ wsSim.live ↔
      ∃ t < T_max, ∃ idx : ℤ, e = idx * (T_max : ℤ) + (t : ℤ) ∧ (.heap t idx) ∈ wsSub.live
  tab10_read : ∀ t < T_max, ∀ idx : ℤ,
    wsSim.read (.heap 10 (idx * (T_max : ℤ) + (t : ℤ))) = wsSub.read (.heap t idx)
  -- Free-stack & active `sid ∈ [0, highSid)` bijection with live `.heap 10`
  free_nodup : freeStack.Nodup
  free_lt : ∀ s ∈ freeStack, s < highSid
  active_iff : ∀ e : ℤ, (.heap 10 e : RAMCellLoc) ∈ wsSim.live ↔ (sidOfEnc e).isSome
  sid_lt : ∀ e s, sidOfEnc e = some s → s < highSid ∧ s ∉ freeStack ∧ encOfSid s = e
  enc_sid : ∀ s < highSid, s ∉ freeStack → sidOfEnc (encOfSid s) = some s
  -- Concrete contents of tables 12, 13, 14, 15, 16
  tab12_4 : (freeStack = [] → (.heap 12 4 : RAMCellLoc) ∉ wsSim.live) ∧
            wsSim.read (.heap 12 4) = (freeStack.length : ℤ)
  tab12_5 : (highSid = 0 → (.heap 12 5 : RAMCellLoc) ∉ wsSim.live) ∧
            wsSim.read (.heap 12 5) = (highSid : ℤ)
  tab12_other : ∀ idx : ℤ, idx ≠ 4 → idx ≠ 5 → (.heap 12 idx : RAMCellLoc) ∉ wsSim.live
  tab13_spec : ∀ e : ℤ,
    (∀ s, sidOfEnc e = some s →
      (.heap 13 e : RAMCellLoc) ∈ wsSim.live ∧ wsSim.vals (.heap 13 e) = ((s + 1 : ℕ) : ℤ)) ∧
    (sidOfEnc e = none → (.heap 13 e : RAMCellLoc) ∉ wsSim.live)
  tab14_spec : ∀ z : ℤ,
    (∀ (_hz : 0 ≤ z) (hlt : z.toNat < freeStack.length),
      (.heap 14 z : RAMCellLoc) ∈ wsSim.live ∧
      wsSim.vals (.heap 14 z) = (freeStack[z.toNat] : ℤ)) ∧
    (¬ (0 ≤ z ∧ z.toNat < freeStack.length) → (.heap 14 z : RAMCellLoc) ∉ wsSim.live)
  tab15_16_spec : ∀ z : ℤ,
    (0 ≤ z ∧ z.toNat < highSid ∧ z.toNat ∉ freeStack →
      (.heap 15 z : RAMCellLoc) ∈ wsSim.live ∧ wsSim.vals (.heap 15 z) = encOfSid z.toNat ∧
      (.heap 16 z : RAMCellLoc) ∈ wsSim.live ∧ wsSim.vals (.heap 16 z) = 1) ∧
    (¬ (0 ≤ z ∧ z.toNat < highSid ∧ z.toNat ∉ freeStack) →
      (.heap 15 z : RAMCellLoc) ∉ wsSim.live ∧ (.heap 16 z : RAMCellLoc) ∉ wsSim.live)
  -- Exhaustiveness of `wsSim.live`
  live_cases : ∀ loc ∈ wsSim.live,
    IsA2BaseLoc loc ∨
    (∃ d var idx, loc = .localFrame (2 + d) var idx) ∨
    (∃ t idx, (t = 10 ∨ t = 12 ∨ t = 13 ∨ t = 14 ∨ t = 15 ∨ t = 16) ∧ loc = .heap t idx)

theorem A2SimInv.agreesForExpr {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    (fdSub : ℕ) :
    AgreesForA2Expr wsBase T_max wsSub fdSub wsSim := by
  refine ⟨?_, hinv.tab10_read, ?_⟩
  · intro t ht idx
    have hb : IsA2BaseLoc (.heap t idx) := ht
    rw [wordStore_read_eq_vals hinv.wfSim, wordStore_read_eq_vals hinv.wfBase.1]
    exact hinv.base_vals _ hb
  · intro var idx
    rw [wordStore_read_eq_vals hinv.wfSim, wordStore_read_eq_vals hinv.wfSub]
    exact hinv.local_vals fdSub var idx

theorem A2SimInv.init {wsBase : WordStore} (hbase : IsA2BaseStore wsBase)
    {T_max S_max : ℕ} (hT : 1 ≤ T_max)
    (hclean : ∀ loc ∈ wsBase.live, IsA2BaseLoc loc) :
    A2SimInv wsBase T_max S_max WordStore.empty wsBase 0 (fun _ => none) (fun _ => 0) [] := by
  have hnot_base_other : ∀ loc, ¬ IsA2BaseLoc loc → loc ∉ wsBase.live :=
    fun loc hnb hmem => hnb (hclean loc hmem)
  refine
    { wfBase := hbase
      wfSub := wellFormedWS_empty
      wfSim := hbase.1
      hT := hT
      high_le := Nat.zero_le _
      sub_tables := fun _ _ h => by simp [WordStore.empty] at h
      base_live := fun _ _ => Iff.rfl
      base_vals := fun _ _ => rfl
      local_live := fun d var idx => by
        simp only [WordStore.empty, Finset.notMem_empty, iff_false]
        exact hnot_base_other (.localFrame (2 + d) var idx) (by simp [IsA2BaseLoc]; omega)
      local_vals := fun d var idx =>
        hbase.1 _ (hnot_base_other (.localFrame (2 + d) var idx) (by simp [IsA2BaseLoc]; omega))
      tab10_live := fun e => by
        simp only [WordStore.empty, Finset.notMem_empty, and_false, exists_false, iff_false]
        exact hnot_base_other (.heap 10 e) (by simp [IsA2BaseLoc])
      tab10_read := fun t _ idx => by
        rw [wordStore_read_eq_vals hbase.1]
        exact hbase.1 _ (hnot_base_other _ (by simp [IsA2BaseLoc]))
      free_nodup := List.nodup_nil
      free_lt := fun _ h => by simp at h
      active_iff := fun e => by
        simp only [Option.isSome_none, Bool.false_eq_true, iff_false]
        exact hnot_base_other _ (by simp [IsA2BaseLoc])
      sid_lt := fun _ _ h => by simp at h
      enc_sid := fun _ hs => by omega
      tab12_4 := ⟨fun _ => hnot_base_other _ (by simp [IsA2BaseLoc]), by
        rw [wordStore_read_eq_vals hbase.1]
        simpa using hbase.1 _ (hnot_base_other _ (by simp [IsA2BaseLoc]))⟩
      tab12_5 := ⟨fun _ => hnot_base_other _ (by simp [IsA2BaseLoc]), by
        rw [wordStore_read_eq_vals hbase.1]
        simpa using hbase.1 _ (hnot_base_other _ (by simp [IsA2BaseLoc]))⟩
      tab12_other := fun _ _ _ => hnot_base_other _ (by simp [IsA2BaseLoc])
      tab13_spec := fun e => ⟨fun _ h => by simp at h,
        fun _ => hnot_base_other _ (by simp [IsA2BaseLoc])⟩
      tab14_spec := fun z => ⟨fun _ hlt => by simp at hlt,
        fun _ => hnot_base_other _ (by simp [IsA2BaseLoc])⟩
      tab15_16_spec := fun z => ⟨fun h => by omega,
        fun _ => ⟨hnot_base_other _ (by simp [IsA2BaseLoc]),
                  hnot_base_other _ (by simp [IsA2BaseLoc])⟩⟩
      live_cases := fun loc hmem => Or.inl (hclean loc hmem) }

/-! ### 3. Retry-safe `cellCount` and `bitSize` bounds for `A2SimInv` -/

theorem A2SimInv.highSid_sub_free_le {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack) :
    freeStack.length ≤ highSid ∧ highSid - freeStack.length ≤ wsSub.cellCount := by
  classical
  have hsub_free : freeStack.toFinset ⊆ Finset.range highSid := by
    intro s hs
    exact Finset.mem_range.mpr (hinv.free_lt s (List.mem_toFinset.mp hs))
  have hfree_card : freeStack.toFinset.card = freeStack.length :=
    List.toFinset_card_of_nodup hinv.free_nodup
  have hle_high : freeStack.length ≤ highSid := by
    rw [← hfree_card]
    exact (Finset.card_le_card hsub_free).trans (by simp)
  let actSet : Finset ℕ := Finset.range highSid \ freeStack.toFinset
  have hact_card : actSet.card = highSid - freeStack.length := by
    rw [Finset.card_sdiff, Finset.inter_eq_left.mpr hsub_free, Finset.card_range, hfree_card]
  -- Map each active `s ∈ actSet` to `.heap t idx ∈ wsSub.live`
  have hact_to_t10 : ∀ s ∈ actSet, (.heap 10 (encOfSid s) : RAMCellLoc) ∈ wsSim.live := by
    intro s hs
    rcases Finset.mem_sdiff.mp hs with ⟨hr, hnf⟩
    have hs_lt : s < highSid := Finset.mem_range.mp hr
    have hs_not : s ∉ freeStack := fun hm => hnf (List.mem_toFinset.mpr hm)
    rw [hinv.active_iff, hinv.enc_sid s hs_lt hs_not]
    rfl
  have hinj_enc : Set.InjOn encOfSid (actSet : Set ℕ) := by
    intro s₁ hs₁ s₂ hs₂ heq
    rcases Finset.mem_sdiff.mp (Finset.mem_coe.mp hs₁) with ⟨hr1, hnf1⟩
    rcases Finset.mem_sdiff.mp (Finset.mem_coe.mp hs₂) with ⟨hr2, hnf2⟩
    have h1 := hinv.enc_sid s₁ (Finset.mem_range.mp hr1) (fun hm => hnf1 (List.mem_toFinset.mpr hm))
    have h2 := hinv.enc_sid s₂ (Finset.mem_range.mp hr2) (fun hm => hnf2 (List.mem_toFinset.mpr hm))
    rw [heq] at h1
    rw [h1] at h2
    exact Option.some.inj h2
  let t10Sub : Finset RAMCellLoc :=
    wsSub.live.biUnion (fun loc =>
      match loc with
      | .heap t idx => if t < T_max then {.heap 10 (idx * (T_max : ℤ) + (t : ℤ))} else ∅
      | .localFrame _ _ _ => ∅)
  have himg_sub : actSet.image (fun s => RAMCellLoc.heap 10 (encOfSid s)) ⊆ t10Sub := by
    intro loc hloc
    rcases Finset.mem_image.mp hloc with ⟨s, hs, rfl⟩
    have hm10 := hact_to_t10 s hs
    obtain ⟨t, ht, idx, heq_e, hmem_sub⟩ := (hinv.tab10_live (encOfSid s)).mp hm10
    refine Finset.mem_biUnion.mpr ⟨.heap t idx, hmem_sub, ?_⟩
    simp [ht, heq_e]
  have hinj_loc : Set.InjOn (fun s => RAMCellLoc.heap 10 (encOfSid s)) (actSet : Set ℕ) := by
    intro s₁ hs₁ s₂ hs₂ h
    injection h with _ he
    exact hinj_enc hs₁ hs₂ he
  have hcard1 : actSet.card = (actSet.image (fun s => RAMCellLoc.heap 10 (encOfSid s))).card :=
    (Finset.card_image_of_injOn hinj_loc).symm
  have hcard2 : t10Sub.card ≤ wsSub.cellCount := by
    refine finset_card_biUnion_one_le wsSub.live _ fun loc _ => ?_
    cases loc with
    | heap t idx => dsimp only; split_ifs <;> simp
    | localFrame _ _ _ => simp
  refine ⟨hle_high, ?_⟩
  rw [← hact_card, hcard1]
  exact (Finset.card_le_card himg_sub).trans hcard2

theorem A2SimInv.space_bounds {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack) :
    let S_bits : ℕ := natBitLength S_max + 4
    wsSim.cellCount ≤ wsBase.cellCount + 4 * wsSub.cellCount + 2 * S_max + 2 ∧
    wsSim.bitSize ≤
      wsBase.bitSize +
      (3 * natBitLength T_max + 2 * S_bits + 36) * wsSub.bitSize +
      4 * S_max * (S_bits + 8) + 2 * (S_bits + 12) := by
  classical
  intro S_bits
  have hSb4 : 4 ≤ S_bits := by dsimp [S_bits]; omega
  obtain ⟨hfree_le, _⟩ := hinv.highSid_sub_free_le
  have hhigh_S : highSid ≤ S_max := hinv.high_le
  -- Cover `wsSim.live` by `wsBase.live ∪ subPart ∪ auxPart ∪ hdrPart`
  let subMap : RAMCellLoc → Finset RAMCellLoc := fun u =>
    match u with
    | .localFrame d var idx => {.localFrame (2 + d) var idx}
    | .heap t idx =>
        let e : ℤ := idx * (T_max : ℤ) + (t : ℤ)
        if t < T_max then
          match sidOfEnc e with
          | some s => {.heap 10 e, .heap 13 e, .heap 15 (s : ℤ)}
          | none => {.heap 10 e, .heap 13 e}
        else ∅
  let subPart : Finset RAMCellLoc := wsSub.live.biUnion subMap
  let aux14 : Finset RAMCellLoc := Finset.image (fun r : ℕ => RAMCellLoc.heap 14 (r : ℤ)) (Finset.range freeStack.length)
  let aux16 : Finset RAMCellLoc := Finset.image (fun s : ℕ => RAMCellLoc.heap 16 (s : ℤ)) (Finset.range highSid)
  let hdrPart : Finset RAMCellLoc := {.heap 12 4, .heap 12 5}
  have hcover : wsSim.live ⊆ ((wsBase.live ∪ subPart) ∪ (aux14 ∪ aux16)) ∪ hdrPart := by
    intro loc hloc
    simp only [Finset.mem_union]
    rcases hinv.live_cases loc hloc with hbase | ⟨d, var, idx, rfl⟩ | ⟨t, idx, ht_cases, rfl⟩
    · exact Or.inl (Or.inl (Or.inl ((hinv.base_live loc hbase).mp hloc)))
    · left; left; right
      have hsub : (.localFrame d var idx : RAMCellLoc) ∈ wsSub.live :=
        (hinv.local_live d var idx).mp hloc
      exact Finset.mem_biUnion.mpr ⟨.localFrame d var idx, hsub, by simp [subMap]⟩
    · rcases ht_cases with rfl | rfl | rfl | rfl | rfl | rfl
      · -- t = 10
        left; left; right
        obtain ⟨t₀, ht₀, idx₀, rfl, hsub⟩ := (hinv.tab10_live idx).mp hloc
        refine Finset.mem_biUnion.mpr ⟨.heap t₀ idx₀, hsub, ?_⟩
        dsimp [subMap]
        rw [if_pos ht₀]
        cases sidOfEnc (idx₀ * (T_max : ℤ) + (t₀ : ℤ)) <;> simp
      · -- t = 12
        right
        by_cases h4 : idx = 4
        · subst h4; simp [hdrPart]
        · by_cases h5 : idx = 5
          · subst h5; simp [hdrPart]
          · exact False.elim (hinv.tab12_other idx h4 h5 hloc)
      · -- t = 13
        left; left; right
        cases hs : sidOfEnc idx with
        | none => exact False.elim ((hinv.tab13_spec idx).2 hs hloc)
        | some s =>
            have hm10 : (.heap 10 idx : RAMCellLoc) ∈ wsSim.live := by
              rw [hinv.active_iff, hs]; rfl
            obtain ⟨t₀, ht₀, idx₀, rfl, hsub⟩ := (hinv.tab10_live idx).mp hm10
            refine Finset.mem_biUnion.mpr ⟨.heap t₀ idx₀, hsub, ?_⟩
            dsimp [subMap]; rw [if_pos ht₀, hs]; simp
      · -- t = 14
        left; right; left
        by_cases hz : 0 ≤ idx ∧ idx.toNat < freeStack.length
        · refine Finset.mem_image.mpr ⟨idx.toNat, Finset.mem_range.mpr hz.2, ?_⟩
          rw [Int.toNat_of_nonneg hz.1]
        · exact False.elim ((hinv.tab14_spec idx).2 hz hloc)
      · -- t = 15
        left; left; right
        by_cases hz : 0 ≤ idx ∧ idx.toNat < highSid ∧ idx.toNat ∉ freeStack
        · rcases hz with ⟨hz0, hlt, hnf⟩
          have hsid := hinv.enc_sid idx.toNat hlt hnf
          have hm10 : (.heap 10 (encOfSid idx.toNat) : RAMCellLoc) ∈ wsSim.live := by
            rw [hinv.active_iff, hsid]; rfl
          obtain ⟨t₀, ht₀, idx₀, heq_e, hsub⟩ := (hinv.tab10_live _).mp hm10
          refine Finset.mem_biUnion.mpr ⟨.heap t₀ idx₀, hsub, ?_⟩
          dsimp [subMap]
          rw [if_pos ht₀, ← heq_e, hsid]
          simp [Int.toNat_of_nonneg hz0]
        · exact False.elim (((hinv.tab15_16_spec idx).2 hz).1 hloc)
      · -- t = 16
        left; right; right
        by_cases hz : 0 ≤ idx ∧ idx.toNat < highSid ∧ idx.toNat ∉ freeStack
        · refine Finset.mem_image.mpr ⟨idx.toNat, Finset.mem_range.mpr hz.2.1, ?_⟩
          rw [Int.toNat_of_nonneg hz.1]
        · exact False.elim (((hinv.tab15_16_spec idx).2 hz).2 hloc)
  -- 1. Cell count bound
  have hcard_sub : subPart.card ≤ 3 * wsSub.cellCount := by
    calc subPart.card
        ≤ ∑ u ∈ wsSub.live, (subMap u).card := Finset.card_biUnion_le
      _ ≤ ∑ _u ∈ wsSub.live, 3 := by
          refine Finset.sum_le_sum fun u _ => ?_
          cases u with
          | localFrame d var idx => simp [subMap]
          | heap t idx =>
              dsimp [subMap]
              split_ifs with ht
              · cases sidOfEnc (idx * (T_max : ℤ) + (t : ℤ))
                · exact (Finset.card_insert_le _ _).trans (by simp)
                · exact (Finset.card_insert_le _ _).trans
                    (Nat.add_le_add_right (Finset.card_insert_le _ _) 1)
              · simp
      _ = 3 * wsSub.cellCount := by
          simp [WordStore.cellCount, Nat.mul_comm]
  have hcard_14 : aux14.card ≤ S_max :=
    Finset.card_image_le.trans (by rw [Finset.card_range]; linarith)
  have hcard_16 : aux16.card ≤ S_max :=
    Finset.card_image_le.trans (by rw [Finset.card_range]; exact hhigh_S)
  have hcard_hdr : hdrPart.card ≤ 2 := by
    simpa [hdrPart] using Finset.card_insert_le (.heap 12 4) ({.heap 12 5} : Finset RAMCellLoc)
  have hcell_tot : wsSim.cellCount ≤ wsBase.cellCount + 4 * wsSub.cellCount + 2 * S_max + 2 := by
    have hc1 := Finset.card_le_card hcover
    have hc2 := Finset.card_union_le ((wsBase.live ∪ subPart) ∪ (aux14 ∪ aux16)) hdrPart
    have hc2b := Finset.card_union_le (wsBase.live ∪ subPart) (aux14 ∪ aux16)
    have hc3 := Finset.card_union_le wsBase.live subPart
    have hc4 := Finset.card_union_le aux14 aux16
    unfold WordStore.cellCount at hcard_sub ⊢
    linarith
  -- 2. Bit size bound
  let cellWeight : RAMCellLoc → ℕ := fun l => l.bitLength + intBitLength (wsSim.vals l)
  -- Only count elements in `wsSim.live` by intersecting or weighting by `if l ∈ wsSim.live`!
  let liveW : RAMCellLoc → ℕ := fun l => if l ∈ wsSim.live then cellWeight l else 0
  have hbit_eq : wsSim.bitSize = ∑ l ∈ wsSim.live, liveW l := by
    unfold WordStore.bitSize
    refine Finset.sum_congr rfl fun l hl => ?_
    simp [liveW, cellWeight, hl]
  have hbit_le_union : wsSim.bitSize ≤
      ∑ l ∈ wsBase.live, liveW l + ∑ l ∈ subPart, liveW l +
      ∑ l ∈ aux14, liveW l + ∑ l ∈ aux16, liveW l + ∑ l ∈ hdrPart, liveW l := by
    rw [hbit_eq]
    have hs0 := Finset.sum_le_sum_of_subset hcover (f := liveW)
    have hs1 := finset_sum_union_le (((wsBase.live ∪ subPart) ∪ (aux14 ∪ aux16))) hdrPart liveW
    have hs2 := finset_sum_union_le (wsBase.live ∪ subPart) (aux14 ∪ aux16) liveW
    have hs3 := finset_sum_union_le wsBase.live subPart liveW
    have hs4 := finset_sum_union_le aux14 aux16 liveW
    linarith
  have hsum_base : ∑ l ∈ wsBase.live, liveW l ≤ wsBase.bitSize := by
    unfold WordStore.bitSize
    refine Finset.sum_le_sum fun l hl => ?_
    have hb : IsA2BaseLoc l := hinv.wfBase.2 l hl
    dsimp [liveW, cellWeight]
    split_ifs with hm
    · rw [hinv.base_vals l hb]
    · exact Nat.zero_le _
  have hsid_bl : ∀ s : ℕ, s ≤ S_max → intBitLength (s : ℤ) ≤ S_bits := by
    intro s hs
    have h1 := intBitLength_ofNat_le s
    have h2 := natBitLength_mono hs
    dsimp [S_bits]; linarith
  have hsum_sub : ∑ l ∈ subPart, liveW l ≤
      (3 * natBitLength T_max + 2 * S_bits + 36) * wsSub.bitSize := by
    calc ∑ l ∈ subPart, liveW l
        ≤ ∑ u ∈ wsSub.live, ∑ l ∈ subMap u, liveW l :=
          finset_sum_biUnion_le wsSub.live subMap liveW
      _ ≤ ∑ u ∈ wsSub.live,
            (3 * natBitLength T_max + 2 * S_bits + 36) *
              (u.bitLength + intBitLength (wsSub.vals u)) := by
          refine Finset.sum_le_sum fun u hu => ?_
          have hu_pos : 1 ≤ u.bitLength + intBitLength (wsSub.vals u) := by
            have := intBitLength_pos (wsSub.vals u); omega
          cases u with
          | localFrame d var idx =>
              dsimp [subMap]
              rw [Finset.sum_singleton]
              dsimp [liveW, cellWeight]
              split_ifs with hm
              · rw [hinv.local_vals d var idx]
                dsimp [RAMCellLoc.bitLength]
                have hd_pos := natBitLength_pos d
                have hd2 : natBitLength (2 + d) ≤ natBitLength d + 2 := by
                  have h1 := natBitLength_add_le 2 d
                  have hn2 : natBitLength 2 = 2 := by decide
                  rw [hn2] at h1
                  omega
                have hcoeff : 3 ≤ 3 * natBitLength T_max + 2 * S_bits + 36 := by linarith
                calc natBitLength (2 + d) + natBitLength var + intBitLength idx +
                        intBitLength (wsSub.vals (.localFrame d var idx))
                    ≤ 3 * (natBitLength d + natBitLength var + intBitLength idx +
                        intBitLength (wsSub.vals (.localFrame d var idx))) := by linarith
                  _ ≤ (3 * natBitLength T_max + 2 * S_bits + 36) *
                        (natBitLength d + natBitLength var + intBitLength idx +
                        intBitLength (wsSub.vals (.localFrame d var idx))) :=
                      Nat.mul_le_mul_right _ hcoeff
              · exact Nat.zero_le _
          | heap t idx =>
              have ht : t < T_max := hinv.sub_tables t idx hu
              set e : ℤ := idx * (T_max : ℤ) + (t : ℤ)
              have he_bl : intBitLength e ≤ intBitLength idx + natBitLength T_max + 4 :=
                intBitLength_encA2_le ht idx
              have hw10 : liveW (.heap 10 e) ≤
                  intBitLength idx + intBitLength (wsSub.vals (.heap t idx)) +
                  natBitLength T_max + 8 := by
                dsimp [liveW, cellWeight, RAMCellLoc.bitLength]
                split_ifs with hm10
                · have hr10 := hinv.tab10_read t ht idx
                  rw [wordStore_read_eq_vals hinv.wfSim, wordStore_read_eq_vals hinv.wfSub] at hr10
                  change wsSim.vals (.heap 10 e) = wsSub.vals (.heap t idx) at hr10
                  rw [hr10]
                  have hn10 : natBitLength 10 = 4 := by decide
                  rw [hn10]; linarith
                · exact Nat.zero_le _
              have hw13 : liveW (.heap 13 e) ≤
                  intBitLength idx + natBitLength T_max + S_bits + 8 := by
                dsimp [liveW, cellWeight, RAMCellLoc.bitLength]
                split_ifs with hm13
                · cases hs : sidOfEnc e with
                  | none => exact False.elim ((hinv.tab13_spec e).2 hs hm13)
                  | some s =>
                      have hv13 := ((hinv.tab13_spec e).1 s hs).2
                      have hs_lt := (hinv.sid_lt e s hs).1
                      have hs1_bl : intBitLength ((s + 1 : ℕ) : ℤ) ≤ S_bits :=
                        hsid_bl (s + 1) (by omega)
                      rw [hv13]
                      have hn13 : natBitLength 13 = 4 := by decide
                      rw [hn13]; linarith
                · exact Nat.zero_le _
              dsimp [subMap]
              rw [if_pos ht]
              change ∑ l ∈ (match sidOfEnc e with
                | some s => {.heap 10 e, .heap 13 e, .heap 15 (s : ℤ)}
                | none => {.heap 10 e, .heap 13 e}), liveW l ≤ _
              cases hs : sidOfEnc e with
              | none =>
                  have hsum2 : ∑ l ∈ ({.heap 10 e, .heap 13 e} : Finset RAMCellLoc), liveW l ≤
                      liveW (.heap 10 e) + liveW (.heap 13 e) := by
                    simpa using finset_sum_insert_le (.heap 10 e) ({.heap 13 e} : Finset RAMCellLoc) liveW
                  dsimp [RAMCellLoc.bitLength]
                  have hbase_ge : intBitLength idx + intBitLength (wsSub.vals (.heap t idx)) ≤
                      natBitLength t + intBitLength idx + intBitLength (wsSub.vals (.heap t idx)) := by omega
                  have h1_le : 1 ≤ natBitLength t + intBitLength idx + intBitLength (wsSub.vals (.heap t idx)) :=
                    hu_pos
                  set U := natBitLength t + intBitLength idx + intBitLength (wsSub.vals (.heap t idx))
                  calc ∑ l ∈ ({.heap 10 e, .heap 13 e} : Finset RAMCellLoc), liveW l
                      ≤ 2 * U + (2 * natBitLength T_max + S_bits + 16) * 1 := by linarith
                    _ ≤ 2 * U + (2 * natBitLength T_max + S_bits + 16) * U :=
                        Nat.add_le_add_left (Nat.mul_le_mul_left _ h1_le) _
                    _ ≤ (3 * natBitLength T_max + 2 * S_bits + 36) * U := by
                        have hK : 2 + (2 * natBitLength T_max + S_bits + 16) ≤
                            3 * natBitLength T_max + 2 * S_bits + 36 := by omega
                        calc 2 * U + (2 * natBitLength T_max + S_bits + 16) * U
                            = (2 + (2 * natBitLength T_max + S_bits + 16)) * U := by ring
                          _ ≤ (3 * natBitLength T_max + 2 * S_bits + 36) * U :=
                              Nat.mul_le_mul_right U hK
              | some s =>
                  obtain ⟨hs_lt, hnf, henc_s⟩ := hinv.sid_lt e s hs
                  have hw15 : liveW (.heap 15 (s : ℤ)) ≤
                      intBitLength idx + natBitLength T_max + S_bits + 8 := by
                    dsimp [liveW, cellWeight, RAMCellLoc.bitLength]
                    split_ifs with hm15
                    · have hz_ok : 0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack := by
                        simp [hs_lt, hnf]
                      have hv15 := ((hinv.tab15_16_spec (s : ℤ)).1 hz_ok).2.1
                      simp only [Int.toNat_natCast] at hv15
                      rw [hv15, henc_s]
                      have hs_bl : intBitLength (s : ℤ) ≤ S_bits := hsid_bl s (by omega)
                      have hn15 : natBitLength 15 = 4 := by decide
                      rw [hn15]; linarith
                    · exact Nat.zero_le _
                  have hsum3 : ∑ l ∈ ({.heap 10 e, .heap 13 e, .heap 15 (s : ℤ)} : Finset RAMCellLoc), liveW l ≤
                      liveW (.heap 10 e) + liveW (.heap 13 e) + liveW (.heap 15 (s : ℤ)) := by
                    have h3a := finset_sum_insert_le (.heap 10 e) ({.heap 13 e, .heap 15 (s : ℤ)} : Finset RAMCellLoc) liveW
                    have h3b : ∑ l ∈ ({.heap 13 e, .heap 15 (s : ℤ)} : Finset RAMCellLoc), liveW l ≤
                        liveW (.heap 13 e) + liveW (.heap 15 (s : ℤ)) := by
                      simpa using finset_sum_insert_le (.heap 13 e) ({.heap 15 (s : ℤ)} : Finset RAMCellLoc) liveW
                    linarith
                  dsimp [RAMCellLoc.bitLength]
                  set U := natBitLength t + intBitLength idx + intBitLength (wsSub.vals (.heap t idx))
                  have hU_ge : intBitLength idx + intBitLength (wsSub.vals (.heap t idx)) ≤ U := by
                    dsimp [U]; omega
                  have h2idx : 3 * intBitLength idx + intBitLength (wsSub.vals (.heap t idx)) ≤ 3 * U := by
                    dsimp [U]; omega
                  have h1_le : 1 ≤ U := hu_pos
                  calc ∑ l ∈ ({.heap 10 e, .heap 13 e, .heap 15 (s : ℤ)} : Finset RAMCellLoc), liveW l
                      ≤ 3 * U + (3 * natBitLength T_max + 2 * S_bits + 24) * 1 := by linarith
                    _ ≤ 3 * U + (3 * natBitLength T_max + 2 * S_bits + 24) * U :=
                        Nat.add_le_add_left (Nat.mul_le_mul_left _ h1_le) _
                    _ ≤ (3 * natBitLength T_max + 2 * S_bits + 36) * U := by
                        have hK : 3 + (3 * natBitLength T_max + 2 * S_bits + 24) ≤
                            3 * natBitLength T_max + 2 * S_bits + 36 := by omega
                        calc 3 * U + (3 * natBitLength T_max + 2 * S_bits + 24) * U
                            = (3 + (3 * natBitLength T_max + 2 * S_bits + 24)) * U := by ring
                          _ ≤ (3 * natBitLength T_max + 2 * S_bits + 36) * U :=
                              Nat.mul_le_mul_right U hK
      _ = (3 * natBitLength T_max + 2 * S_bits + 36) * wsSub.bitSize := by
          rw [← Finset.mul_sum]; rfl
  have hsum_14 : ∑ l ∈ aux14, liveW l ≤ 2 * S_max * (S_bits + 8) := by
    calc ∑ l ∈ aux14, liveW l
        ≤ ∑ r ∈ Finset.range freeStack.length, liveW (.heap 14 (r : ℤ)) :=
          finset_sum_image_le (Finset.range freeStack.length) (fun r : ℕ => (.heap 14 (r : ℤ) : RAMCellLoc)) liveW
      _ ≤ ∑ _r ∈ Finset.range freeStack.length, 2 * (S_bits + 8) := by
          refine Finset.sum_le_sum fun r hr => ?_
          have hr_lt : r < freeStack.length := Finset.mem_range.mp hr
          dsimp [liveW, cellWeight, RAMCellLoc.bitLength]
          split_ifs with hm14
          · have hv14 := ((hinv.tab14_spec (r : ℤ)).1 (by omega) (by simpa using hr_lt)).2
            simp only [Int.toNat_natCast] at hv14
            rw [hv14]
            have hr_bl : intBitLength (r : ℤ) ≤ S_bits := hsid_bl r (by omega)
            have hval_lt : freeStack[r] < highSid := hinv.free_lt _ (List.getElem_mem hr_lt)
            have hv_bl : intBitLength (freeStack[r] : ℤ) ≤ S_bits := hsid_bl _ (by omega)
            have hn14 : natBitLength 14 = 4 := by decide
            rw [hn14]; linarith
          · exact Nat.zero_le _
      _ = freeStack.length * (2 * (S_bits + 8)) := by simp
      _ ≤ S_max * (2 * (S_bits + 8)) := Nat.mul_le_mul_right _ (by omega)
      _ = 2 * S_max * (S_bits + 8) := by ring
  have hsum_16 : ∑ l ∈ aux16, liveW l ≤ 2 * S_max * (S_bits + 8) := by
    calc ∑ l ∈ aux16, liveW l
        ≤ ∑ s ∈ Finset.range highSid, liveW (.heap 16 (s : ℤ)) :=
          finset_sum_image_le (Finset.range highSid) (fun s : ℕ => (.heap 16 (s : ℤ) : RAMCellLoc)) liveW
      _ ≤ ∑ _s ∈ Finset.range highSid, 2 * (S_bits + 8) := by
          refine Finset.sum_le_sum fun s hs => ?_
          have hs_lt : s < highSid := Finset.mem_range.mp hs
          dsimp [liveW, cellWeight, RAMCellLoc.bitLength]
          split_ifs with hm16
          · by_cases hnf : s ∉ freeStack
            · have hz_ok : 0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack := by
                simp [hs_lt, hnf]
              have hv16 := ((hinv.tab15_16_spec (s : ℤ)).1 hz_ok).2.2.2
              rw [hv16]
              have hs_bl : intBitLength (s : ℤ) ≤ S_bits := hsid_bl s (by omega)
              have hn16 : natBitLength 16 = 5 := by decide
              have hl1 : intBitLength 1 = 2 := by decide
              rw [hn16, hl1]; linarith
            · have hz_not : ¬ (0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack) := by
                simp [hnf]
              exact False.elim (((hinv.tab15_16_spec (s : ℤ)).2 hz_not).2 hm16)
          · exact Nat.zero_le _
      _ = highSid * (2 * (S_bits + 8)) := by simp
      _ ≤ S_max * (2 * (S_bits + 8)) := Nat.mul_le_mul_right _ hhigh_S
      _ = 2 * S_max * (S_bits + 8) := by ring
  have hsum_hdr : ∑ l ∈ hdrPart, liveW l ≤ 2 * (S_bits + 12) := by
    have hw4 : liveW (.heap 12 4) ≤ S_bits + 12 := by
      dsimp [liveW, cellWeight, RAMCellLoc.bitLength]
      split_ifs with hm4
      · have hr4 := hinv.tab12_4.2
        rw [wordStore_read_eq_vals hinv.wfSim] at hr4
        rw [hr4]
        have hf_bl : intBitLength (freeStack.length : ℤ) ≤ S_bits :=
          hsid_bl freeStack.length (by omega)
        have hn12 : natBitLength 12 = 4 := by decide
        have hl4 : intBitLength 4 = 4 := by decide
        rw [hn12, hl4]; linarith
      · exact Nat.zero_le _
    have hw5 : liveW (.heap 12 5) ≤ S_bits + 12 := by
      dsimp [liveW, cellWeight, RAMCellLoc.bitLength]
      split_ifs with hm5
      · have hr5 := hinv.tab12_5.2
        rw [wordStore_read_eq_vals hinv.wfSim] at hr5
        rw [hr5]
        have hh_bl : intBitLength (highSid : ℤ) ≤ S_bits := hsid_bl highSid hhigh_S
        have hn12 : natBitLength 12 = 4 := by decide
        have hl5 : intBitLength 5 = 4 := by decide
        rw [hn12, hl5]; linarith
      · exact Nat.zero_le _
    have hle : ∑ l ∈ hdrPart, liveW l ≤ liveW (.heap 12 4) + liveW (.heap 12 5) := by
      simpa [hdrPart] using finset_sum_insert_le (.heap 12 4) ({.heap 12 5} : Finset RAMCellLoc) liveW
    linarith
  refine ⟨hcell_tot, by linarith⟩

end UL.C12LVE
