import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG08_StepDA
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Arithmetic & Heap-Counter Helpers for Step D Loops -/

theorem natCast_bitLength_le_of_le {x y W : ℕ} (hxy : x ≤ y) (hyW : natBitLength y + 2 ≤ W) :
    intBitLength (x : ℤ) ≤ W := by
  have h1 := intBitLength_ofNat_le x
  have h2 := natBitLength_mono hxy
  omega

def incrHeap9Regs (c : ℤ) : BitRAMStmt :=
  .seq (.seq (rLit 10 c) (rLoad 13 9 10))
  (.seq (rLit 14 1)
  (.seq (rAdd 13 13 14)
        (.seq (rLit 10 c) (rStore 9 10 13))))

theorem exec_incrHeap9Regs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    (hW24 : 24 ≤ W)
    {c v : ℤ} (hc_bl : intBitLength c ≤ W)
    (hloc_bl : (RAMCellLoc.heap 9 c).bitLength ≤ W)
    (hsub : (.heap 9 c : RAMCellLoc) ∈ S_write)
    (hread : ws.read (.heap 9 c) = v)
    (hv_bl : intBitLength v ≤ W) (hv1_bl : intBitLength (v + 1) ≤ W)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ regsEnd,
      RegExec inp fd W C_cell C_bit (incrHeap9Regs c) ws regs
        (ws.write (.heap 9 c) (v + 1)) regsEnd 32 (24 * W + 128) ∧
      ModifiedOnBounded ws₀ S_write W (ws.write (.heap 9 c) (v + 1)) ∧
      RegBounded W regsEnd := by
  obtain ⟨cs, bs⟩ := hmod.space_le
  have spC : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell := by linarith only [cs, hcCeil]
  have spB : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit := by linarith only [bs, hbCeil]
  have hn9 : natBitLength 9 ≤ W := Nat.le_trans (by decide) hW24
  have hl1 : intBitLength (1 : ℤ) ≤ W := Nat.le_trans (by decide) hW24
  obtain ⟨s1, bg1⟩ := exec_litLoadHeap hfd_le hmod hcCeil hbCeil hbnd (dst := 13) (table := 9) (c := c)
    (by decide) hn9 hc_bl hread hv_bl
  set g1 := Function.update (Function.update regs 10 c) 13 v
  have s2 := RegExec.lit (inp := inp) hfd_le bg1 spC spB (dst := 14) (c := 1) (by decide) hl1
  set g2 := Function.update g1 14 1; have bg2 := bg1.update (r := 14) (by decide) hl1
  have hsum_bl : intBitLength (g2 13 + g2 14) ≤ W := by simpa [g2, g1] using hv1_bl
  have s3 := RegExec.add (inp := inp) hfd_le bg2 spC spB (dst := 13) (a := 13) (b := 14)
    (by decide) (by decide) (by decide) hsum_bl
  set g3 := Function.update g2 13 (g2 13 + g2 14); have bg3 := bg2.update (r := 13) (by decide) hsum_bl
  obtain ⟨s4, hm4, bg4⟩ := exec_litStoreHeap (regs := g3) hfd_le hmod hcCeil hbCeil bg3 (table := 9) (valReg := 13) (c := c)
    (by decide) (by decide) hn9 hc_bl hsub hloc_bl
  have hg3_13 : g3 13 = v + 1 := by simp [g3, g2, g1]
  rw [hg3_13] at s4 hm4
  exact ⟨_, (s1.seq (s2.seq (s3.seq s4))).weaken rfl rfl (by omega) (by omega), hm4, bg4⟩

/-! ### 2. Active-Chain Level Scan (`scanAllLevelsRegs`) -/

def levelBlockCandStepRegs (d : ℕ) : BitRAMStmt :=
  .seq (.seq (rLit 10 122) (rLoad 13 9 10))
  (.seq (rLoad 1 3 13)
  (.seq (rLit 14 1)
  (.seq (rAdd 13 13 14)
  (.seq (.seq (rLit 10 122) (rStore 9 10 13))
  (.seq (.seq (rLit 10 121) (rLoad 2 9 10))
        (considerCandRegs d))))))

def levelScanNonemptyRegs (d s₀_d L : ℕ) : BitRAMStmt :=
  .seq (.seq (rLit 10 121) (rStore 9 10 2))
  (.seq (.seq (rLit 10 120) (rLoad 6 9 10))
  (.seq (rAdd 0 6 6)
  (.seq (rLit 14 3)
  (.seq (rAdd 0 0 14)
  (.seq (treeMinElemRegs L)
  (.seq (.seq (rLit 10 120) (rLoad 6 9 10))
  (.seq (rLit 14 (posNodeStride d L : ℤ))
  (.seq (rMul 13 6 14)
  (.seq (rLit 14 ((6 + 2 * d : ℕ) : ℤ))
  (.seq (rAdd 13 13 14)
  (.seq (rLit 14 (s₀_d : ℤ))
  (.seq (rMul 14 1 14)
  (.seq (rAdd 13 13 14)
  (.seq (.seq (rLit 10 122) (rStore 9 10 13))
  (.seq (.repeatN (.lit (s₀_d : ℤ)) (levelBlockCandStepRegs d))
  (.seq (.seq (rLit 10 121) (rFree 9 10))
        (.seq (rLit 10 122) (rFree 9 10))))))))))))))))))

def levelScanStepRegs (d s₀_d L : ℕ) : BitRAMStmt :=
  .seq (.seq (rLit 10 120) (rLoad 6 9 10))
  (.seq (rAdd 0 6 6)
  (.seq (rLit 14 2)
  (.seq (rAdd 0 0 14)
  (.seq (treeReadRootRegs L)
  (.seq (rLit 14 0)
  (.seq (.ite (.intLt (.readLocal 14 (.lit 0)) (.readLocal 1 (.lit 0)))
          (levelScanNonemptyRegs d s₀_d L)
          .skip)
        (incrHeap9Regs 120)))))))

def scanAllLevelsRegs (d s₀_d L : ℕ) : BitRAMStmt :=
  .seq (rLit 13 0)
  (.seq (.seq (rLit 10 120) (rStore 9 10 13))
  (.seq (.seq (rLit 10 10) (rLoad 5 0 10))
  (.seq (.repeatN (.readLocal 5 (.lit 0)) (levelScanStepRegs d s₀_d L))
        (.seq (rLit 10 120) (rFree 9 10)))))

theorem exec_levelScanStepRegs {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hL1 : 1 ≤ L) (h2n : 2 * n ≤ 2 ^ L) (hB1 : 1 ≤ B)
    (hW : 2 * sqRadBitBound d B B_cert + d * (8 * B + 24) +
          natBitLength ((K_max + 2) * posNodeStride d L) + natBitLength s₀_d + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {wsRef ws : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap wsRef)
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    {j : ℕ} (hj : j < nodes.length)
    (hr120 : ws.read (.heap 9 120) = (j : ℤ))
    (hn121 : (.heap 9 121 : RAMCellLoc) ∉ ws.live)
    (hn122 : (.heap 9 122 : RAMCellLoc) ∉ ws.live)
    (hunchRef : ∀ loc : RAMCellLoc, ¬ isAnsHeaderLoc loc → loc ∉ treeSliceLocs L 0 → loc ≠ .heap 9 120 →
      (loc ∈ ws.live ↔ loc ∈ wsRef.live) ∧ ws.vals loc = wsRef.vals loc)
    {cur : ℕ × ℕ} (hbest : BestPairStored B P cur ws)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (levelScanStepRegs d s₀_d L) ws regs wsEnd regsEnd
        (s₀_d * (220 * d + 200) + 64 * L + 340)
        ((s₀_d * (52 * d + 48) + 12 * L + 60) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      BestPairStored B P (foldBestPairs P cur (levelScanCands L P nodes ⟨j, hj⟩)) wsEnd ∧
      wsEnd.read (.heap 9 120) = ((j + 1 : ℕ) : ℤ) ∧
      (.heap 9 121 : RAMCellLoc) ∉ wsEnd.live ∧
      (.heap 9 122 : RAMCellLoc) ∉ wsEnd.live ∧
      (∀ loc : RAMCellLoc, ¬ isBestPairLoc loc → loc ≠ .heap 9 120 →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW32 : 32 ≤ W := by omega
  have hCeilC : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hCeilB : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hCeilC], by linarith only [bs, hCeilB]⟩
  have hstride_ge8 : 8 ≤ posNodeStride d L := by unfold posNodeStride; omega
  have hj_leK : j ≤ K_max := Nat.le_of_lt (lt_of_lt_of_le hj hinv.hk_le)
  have hN_W : natBitLength ((K_max + 2) * posNodeStride d L) + 8 ≤ W := by clear * - hW; omega
  have hj_le_N : j + 1 ≤ ((K_max + 2) * posNodeStride d L) := by
    calc j + 1 ≤ K_max + 2 := by omega
      _ ≤ (K_max + 2) * posNodeStride d L := Nat.le_mul_of_pos_right _ (by omega)
  have hj_bl : intBitLength (j : ℤ) ≤ W := natCast_bitLength_le_of_le (Nat.le_trans (by omega) hj_le_N) (by omega)
  have hj1_bl : intBitLength ((j + 1 : ℕ) : ℤ) ≤ W := natCast_bitLength_le_of_le hj_le_N (by omega)
  have htid2_le : 2 * j + 3 ≤ ((K_max + 2) * posNodeStride d L) := by
    calc 2 * j + 3 ≤ 8 * (K_max + 2) := by omega
      _ ≤ (K_max + 2) * posNodeStride d L := by nlinarith only [hstride_ge8]
  have htid2_bl : intBitLength ((2 * j + 2 : ℕ) : ℤ) ≤ W := natCast_bitLength_le_of_le (Nat.le_trans (by omega) htid2_le) (by omega)
  have htid3_bl : intBitLength ((2 * j + 3 : ℕ) : ℤ) ≤ W := natCast_bitLength_le_of_le htid2_le (by omega)
  have h2j_bl : intBitLength ((2 * j : ℕ) : ℤ) ≤ W := natCast_bitLength_le_of_le (Nat.le_trans (by omega) htid2_le) (by omega)
  have hn9 : natBitLength 9 ≤ W := Nat.le_trans (by decide) hW32
  have hn3 : natBitLength 3 ≤ W := Nat.le_trans (by decide) hW32
  have hl0 : intBitLength (0 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl1 : intBitLength (1 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl2 : intBitLength (2 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl3 : intBitLength (3 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl120 : intBitLength (120 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl121 : intBitLength (121 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl122 : intBitLength (122 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  set vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
  set S_lt := chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩
  set S_j_h := chainInput (fun h => P.coords (P.idOfHandle h)) vecNodes P.activeHandles (⟨j, hj⟩ : Fin nodes.length).castSucc
  have hlt_to_h : ∀ lt ∈ activeLifetimes P,
      P.coords (P.idOfHandle (handleOfLifetime P lt)) = ltCoords lt := by
    intro lt hlt
    rcases Finset.mem_image.mp hlt with ⟨id₀, hid₀, rfl⟩
    rw [handleOfLifetime_of_mem hinv.wfP hid₀, (hinv.wfP.2.1 id₀ hid₀).2, (hinv.hlt_sync id₀ hid₀).1]
  have hS_eq : S_lt.image (handleOfLifetime P) = S_j_h := by
    change (chainInput ltCoords vecNodes (activeLifetimes P) (⟨j, hj⟩ : Fin nodes.length).castSucc).image (handleOfLifetime P) = S_j_h
    rw [chainInput_image_eq ltCoords (fun h => P.coords (P.idOfHandle h)) vecNodes
          (activeLifetimes P) (handleOfLifetime P) hlt_to_h (⟨j, hj⟩ : Fin nodes.length).castSucc,
        image_handleOfLifetime_active hinv.wfP]
  have hlvl := hinv.levels j hj
  obtain ⟨rNum, rDen, htreeSj_ref, hSj_bnds⟩ := hlvl.tree_Sj
  rw [hS_eq] at htreeSj_ref hSj_bnds
  have htreeSj : TreeStoredAt L (2 * j + 2) S_j_h rNum rDen ws :=
    htreeSj_ref.unchanged (fun u hu f hf =>
      hunchRef _ (by rintro (h | h | h | h | h) <;> cases h)
        (not_in_treeSlice_of_tid_ne hu hf (by omega)) (by simp))
  have hBr1 : 1 ≤ sqRadBitBound d B B_cert := by unfold sqRadBitBound; omega
  have hW_rroot : 2 * sqRadBitBound d B B_cert + natBitLength (2 * j + 2) + L + 16 ≤ W := by
    have hm : natBitLength (2 * j + 2) ≤ natBitLength ((K_max + 2) * posNodeStride d L) := natBitLength_mono (Nat.le_trans (by omega) htid2_le)
    clear * - hW hm; omega
  have hSj_tree_bnds : ∀ h ∈ S_j_h, h < 2 ^ L ∧
      intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧ intBitLength (rDen h) ≤ sqRadBitBound d B B_cert :=
    fun h hh => ⟨htreeSj.hS h hh, (hSj_bnds h hh).2.2.1, (hSj_bnds h hh).2.2.2⟩
  obtain ⟨p1, bg1⟩ := exec_litLoadHeap hfd_le hmod hCeilC hCeilB hbnd (dst := 6) (table := 9) (c := 120)
    (by decide) hn9 hl120 hr120 hj_bl
  set g1 := Function.update (Function.update regs 10 120) 6 (j : ℤ)
  have hg1_2j : intBitLength (g1 6 + g1 6) ≤ W := by
    have : g1 6 + g1 6 = ((2 * j : ℕ) : ℤ) := by simp [g1]; ring
    rw [this]; exact h2j_bl
  have p2 := RegExec.add (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (a := 6) (b := 6)
    (by decide) (by decide) (by decide) hg1_2j
  set g2 := Function.update g1 0 (g1 6 + g1 6); have bg2 := bg1.update (r := 0) (by decide) hg1_2j
  have p3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 2) (by decide) hl2
  set g3 := Function.update g2 14 2; have bg3 := bg2.update (r := 14) (by decide) hl2
  have hg3_tid : g3 0 + g3 14 = ((2 * j + 2 : ℕ) : ℤ) := by simp [g3, g2, g1]; ring
  have p4 := RegExec.add (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (a := 0) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hg3_tid]; exact htid2_bl)
  set g4 := Function.update g3 0 (g3 0 + g3 14); have bg4 := bg3.update (r := 0) (v := g3 0 + g3 14) (by decide) (by rw [hg3_tid]; exact htid2_bl)
  obtain ⟨g5, p5, bg5, _, hg5_1, hg5_2, _, _, _⟩ :=
    exec_treeReadRootRegs (inp := inp) (fd := fd) hfd_le (sp_ok hmod).1 (sp_ok hmod).2
      hBr1 hW_rroot htreeSj hSj_tree_bnds bg4 (by simp [g4, hg3_tid])
  have p6 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 0) (by decide) hl0
  set g6 := Function.update g5 14 0; have bg6 := bg5.update (r := 14) (by decide) hl0
  have hg6_1 : g6 1 = (S_j_h.card : ℤ) := by simp [g6, hg5_1]
  have hg6_14 : g6 14 = 0 := by simp [g6]
  have hIte : ∃ wsMid regsMid,
      RegExec inp fd W C_cell C_bit
        (.ite (.intLt (.readLocal 14 (.lit 0)) (.readLocal 1 (.lit 0)))
          (levelScanNonemptyRegs d s₀_d L) .skip)
        ws g6 wsMid regsMid
        (s₀_d * (220 * d + 200) + 64 * L + 160)
        ((s₀_d * (52 * d + 48) + 12 * L + 28) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsMid ∧
      RegBounded W regsMid ∧
      BestPairStored B P (foldBestPairs P cur (levelScanCands L P nodes ⟨j, hj⟩)) wsMid ∧
      wsMid.read (.heap 9 120) = (j : ℤ) ∧
      (.heap 9 121 : RAMCellLoc) ∉ wsMid.live ∧
      (.heap 9 122 : RAMCellLoc) ∉ wsMid.live ∧
      (∀ loc : RAMCellLoc, ¬ isBestPairLoc loc →
        (loc ∈ wsMid.live ↔ loc ∈ ws.live) ∧ wsMid.vals loc = ws.vals loc) := by
    by_cases hSne : S_j_h.Nonempty
    · have hlt_reg : g6 14 < g6 1 := by rw [hg6_14, hg6_1]; exact_mod_cast hSne.card_pos
      set v := nodes.get ⟨j, hj⟩
      have hDen_pos : ∀ h ∈ S_j_h, 1 ≤ rDen h := fun h hh => (hSj_bnds h hh).1
      have hw_eq : ∀ h ∈ S_j_h, ((rNum h : ℝ) / (rDen h : ℝ)) =
          ‖P.coords (P.idOfHandle h) - v.built.node.o‖ ^ 2 := by
        intro h hh
        have hsub_h : S_j_h ⊆ P.activeHandles := chainInput_subset_base _ _ _ _
        have hid_in := (hinv.wfP.2.2.1 h (hsub_h hh)).1
        have hq_eq := (hinv.hlt_sync _ hid_in).2
        rw [(hinv.wfP.2.2.1 h (hsub_h hh)).2] at hq_eq
        rw [(hSj_bnds h hh).2.1, ← hq_eq]
      have htv_eq := treeNodeVal_eq_realTreeVal hDen_pos hw_eq L 0
      set y_h := (realTreeVal S_j_h (fun h => ‖P.coords (P.idOfHandle h) - v.built.node.o‖ ^ 2) L 0).2.1
      have hc_pos : 0 < (treeNodeVal S_j_h rNum rDen L 0).1 := by
        rw [treeNodeVal_cnt, treeSubSet_root htreeSj.hS]; exact hSne.card_pos
      obtain ⟨hy_in_sub, _, _, _⟩ := treeNodeVal_winner rNum hDen_pos L 0 hc_pos
      rw [htv_eq.2.1] at hy_in_sub
      have hy_in_Sj : y_h ∈ S_j_h := (treeSubSet_root htreeSj.hS) ▸ hy_in_sub
      have hy_act : y_h ∈ P.activeHandles := chainInput_subset_base _ _ _ _ hy_in_Sj
      have hy_bl : intBitLength (y_h : ℤ) ≤ W :=
        (nat_lt_pow2_bitLength_le (htreeSj.hS y_h hy_in_Sj)).trans (by omega)
      have hg6_2 : g6 2 = (y_h : ℤ) := by simp [g6, hg5_2, htv_eq.2.1, y_h]
      have hBi : (intactBlocksOf v P).Nonempty := hlvl.tree_intact.1
      have htreeBi : TreeStoredAt L (2 * j + 3) (intactBlocksOf v P) (fun _ => 0) (fun _ => 1) ws :=
        hlvl.tree_intact.2.unchanged (fun u hu f hf =>
          hunchRef _ (by rintro (h | h | h | h | h) <;> cases h)
            (not_in_treeSlice_of_tid_ne hu hf (by omega)) (by simp))
      set b_min := (intactBlocksOf v P).min' hBi
      have hb_mem := Finset.min'_mem _ hBi
      rcases Finset.mem_image.mp hb_mem with ⟨b_fin, hb_flt, hb_val⟩
      have hb_lt : b_min < v.built.aux.k_blk := by have := b_fin.isLt; omega
      have hb_fin_eq : (⟨b_min, hb_lt⟩ : Fin v.built.aux.k_blk) = b_fin := Fin.ext hb_val.symm
      have hb_act_lt : ∀ t : Fin s₀_d, v.built.aux.birthLifetimes ⟨b_min, hb_lt⟩ t ∈ activeLifetimes P := by
        rw [hb_fin_eq]; exact (Finset.mem_filter.mp hb_flt).2
      have hbh_act : ∀ t : Fin s₀_d, v.built.aux.birthHandles ⟨b_min, hb_lt⟩ t ∈ P.activeHandles := by
        intro t
        rw [← image_handleOfLifetime_active hinv.wfP]
        exact Finset.mem_image.mpr ⟨v.built.aux.birthLifetimes ⟨b_min, hb_lt⟩ t, hb_act_lt t,
          hlvl.hbh_active_sync ⟨b_min, hb_lt⟩ t (hb_act_lt t)⟩
      have hlcands_eq : levelScanCands L P nodes ⟨j, hj⟩ =
          (List.finRange s₀_d).map (fun t => (v.built.aux.birthHandles ⟨b_min, hb_lt⟩ t, y_h)) := by
        simp +zetaDelta only [levelScanCands, hSne, hBi, hb_lt, ↓reduceIte, ↓reduceDIte]
      obtain ⟨q1, hm_w1, bq1⟩ := exec_litStoreHeap hfd_le hmod hCeilC hCeilB bg6
        (table := 9) (valReg := 2) (c := 121) (by decide) (by decide) hn9 hl121
        (mem_posDimWriteLocs_tab9 (by decide)) (Nat.le_trans (by decide) hW32)
      set w1 := ws.write (.heap 9 121) (g6 2)
      have hw1_120 : w1.read (.heap 9 120) = (j : ℤ) := by
        rw [wordStore_read_write_ne ws (by decide)]; exact hr120
      obtain ⟨q2, bq2⟩ := exec_litLoadHeap hfd_le hm_w1 hCeilC hCeilB bq1 (dst := 6) (table := 9) (c := 120)
        (by decide) hn9 hl120 hw1_120 hj_bl
      set r_2 := Function.update (Function.update (Function.update g6 10 121) 10 120) 6 (j : ℤ)
      have hr2_add : intBitLength (r_2 6 + r_2 6) ≤ W := by
        have : r_2 6 + r_2 6 = ((2 * j : ℕ) : ℤ) := by simp [r_2]; ring
        rw [this]; exact h2j_bl
      have q3 := RegExec.add (inp := inp) hfd_le bq2 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 0) (a := 6) (b := 6)
        (by decide) (by decide) (by decide) hr2_add
      set r_3 := Function.update r_2 0 (r_2 6 + r_2 6); have bq3 := bq2.update (r := 0) (by decide) hr2_add
      have q4 := RegExec.lit (inp := inp) hfd_le bq3 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 14) (c := 3) (by decide) hl3
      set r_4 := Function.update r_3 14 3; have bq4 := bq3.update (r := 14) (by decide) hl3
      have hr4_tid : r_4 0 + r_4 14 = ((2 * j + 3 : ℕ) : ℤ) := by simp [r_4, r_3, r_2]; ring
      have q5 := RegExec.add (inp := inp) hfd_le bq4 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 0) (a := 0) (b := 14)
        (by decide) (by decide) (by decide) (by rw [hr4_tid]; exact htid3_bl)
      set r_5 := Function.update r_4 0 (r_4 0 + r_4 14); have bq5 := bq4.update (r := 0) (v := r_4 0 + r_4 14) (by decide) (by rw [hr4_tid]; exact htid3_bl)
      have htreeBi_w1 : TreeStoredAt L (2 * j + 3) (intactBlocksOf v P) (fun _ => 0) (fun _ => 1) w1 :=
        htreeBi.unchanged (fun u _ f _ => by simp [w1, WordStore.write])
      have hW_bi : 2 * 2 + natBitLength (2 * j + 3) + L + 16 ≤ W := by
        have hm : natBitLength (2 * j + 3) ≤ natBitLength ((K_max + 2) * posNodeStride d L) := natBitLength_mono htid2_le
        clear * - hW hm; omega
      obtain ⟨r_6, q6, bq6, _, hr6_1, _⟩ :=
        exec_treeMinElemRegs (inp := inp) (fd := fd) hfd_le (sp_ok hm_w1).1 (sp_ok hm_w1).2 hL1
          (B_r := 2) (by decide) hW_bi htreeBi_w1
          (fun b hb => ⟨htreeBi_w1.hS b hb, by decide, by decide⟩)
          hBi bq5 (by simp [r_5, hr4_tid])
      obtain ⟨q7, bq7⟩ := exec_litLoadHeap hfd_le hm_w1 hCeilC hCeilB bq6 (dst := 6) (table := 9) (c := 120)
        (by decide) hn9 hl120 hw1_120 hj_bl
      set r_7 := Function.update (Function.update r_6 10 120) 6 (j : ℤ)
      have hstride_le : posNodeStride d L ≤ ((K_max + 2) * posNodeStride d L) := Nat.le_mul_of_pos_left _ (by omega)
      have hstride_bl : intBitLength (posNodeStride d L : ℤ) ≤ W := natCast_bitLength_le_of_le hstride_le (by omega)
      have q8 := RegExec.lit (inp := inp) hfd_le bq7 (sp_ok hm_w1).1 (sp_ok hm_w1).2
        (dst := 14) (c := (posNodeStride d L : ℤ)) (by decide) hstride_bl
      set r_8 := Function.update r_7 14 (posNodeStride d L : ℤ); have bq8 := bq7.update (r := 14) (by decide) hstride_bl
      have hjstride_le : j * posNodeStride d L ≤ ((K_max + 2) * posNodeStride d L) := Nat.mul_le_mul_right _ (by omega)
      have hr8_mul : r_8 6 * r_8 14 = ((j * posNodeStride d L : ℕ) : ℤ) := by simp [r_8, r_7]
      have hjstride_bl : intBitLength (r_8 6 * r_8 14) ≤ W := by
        rw [hr8_mul]; exact natCast_bitLength_le_of_le hjstride_le (by omega)
      have q9 := RegExec.mul (inp := inp) hfd_le bq8 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 13) (a := 6) (b := 14)
        (by decide) (by decide) (by decide) hjstride_bl
      set r_9 := Function.update r_8 13 (r_8 6 * r_8 14); have bq9 := bq8.update (r := 13) (by decide) hjstride_bl
      have h62d_le : 6 + 2 * d ≤ posNodeStride d L := by unfold posNodeStride; omega
      have h62d_bl : intBitLength ((6 + 2 * d : ℕ) : ℤ) ≤ W :=
        natCast_bitLength_le_of_le (h62d_le.trans hstride_le) (by omega)
      have q10 := RegExec.lit (inp := inp) hfd_le bq9 (sp_ok hm_w1).1 (sp_ok hm_w1).2
        (dst := 14) (c := ((6 + 2 * d : ℕ) : ℤ)) (by decide) h62d_bl
      set r_10 := Function.update r_9 14 ((6 + 2 * d : ℕ) : ℤ); have bq10 := bq9.update (r := 14) (by decide) h62d_bl
      have hb_prod_le : (b_min + 1) * s₀_d ≤ n :=
        (Nat.mul_le_mul_right s₀_d (Nat.succ_le_of_lt hb_lt)).trans (hlvl.hk_bounds.2.trans hlvl.hm_bounds.2)
      have hoff_max_lt : 6 + 2 * d + (b_min * s₀_d + s₀_d) < posNodeStride d L := by
        unfold posNodeStride
        have : b_min * s₀_d + s₀_d = (b_min + 1) * s₀_d := by ring
        omega
      have hadd1_le : j * posNodeStride d L + (6 + 2 * d) ≤ ((K_max + 2) * posNodeStride d L) := by
        calc j * posNodeStride d L + (6 + 2 * d) ≤ j * posNodeStride d L + posNodeStride d L := by omega
          _ = (j + 1) * posNodeStride d L := by ring
          _ ≤ ((K_max + 2) * posNodeStride d L) := Nat.mul_le_mul_right _ (by omega)
      have hr10_add : r_10 13 + r_10 14 = ((j * posNodeStride d L + (6 + 2 * d) : ℕ) : ℤ) := by
        simp [r_10, r_9, hr8_mul]
      have hadd1_bl : intBitLength (r_10 13 + r_10 14) ≤ W := by
        rw [hr10_add]; exact natCast_bitLength_le_of_le hadd1_le (by omega)
      have q11 := RegExec.add (inp := inp) hfd_le bq10 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 13) (a := 13) (b := 14)
        (by decide) (by decide) (by decide) hadd1_bl
      set r_11 := Function.update r_10 13 (r_10 13 + r_10 14); have bq11 := bq10.update (r := 13) (by decide) hadd1_bl
      have hs0_bl : intBitLength (s₀_d : ℤ) ≤ W := natCast_bitLength_le_of_le le_rfl (by omega)
      have q12 := RegExec.lit (inp := inp) hfd_le bq11 (sp_ok hm_w1).1 (sp_ok hm_w1).2
        (dst := 14) (c := (s₀_d : ℤ)) (by decide) hs0_bl
      set r_12 := Function.update r_11 14 (s₀_d : ℤ); have bq12 := bq11.update (r := 14) (by decide) hs0_bl
      have hr12_mul : r_12 1 * r_12 14 = ((b_min * s₀_d : ℕ) : ℤ) := by
        simp [r_12, r_11, r_10, r_9, r_8, r_7, hr6_1, b_min]
      have hbmul_le : b_min * s₀_d ≤ ((K_max + 2) * posNodeStride d L) := by
        have : b_min * s₀_d ≤ posNodeStride d L := by omega
        exact this.trans hstride_le
      have hbmul_bl : intBitLength (r_12 1 * r_12 14) ≤ W := by
        rw [hr12_mul]; exact natCast_bitLength_le_of_le hbmul_le (by omega)
      have q13 := RegExec.mul (inp := inp) hfd_le bq12 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 14) (a := 1) (b := 14)
        (by decide) (by decide) (by decide) hbmul_bl
      set r_13 := Function.update r_12 14 (r_12 1 * r_12 14); have bq13 := bq12.update (r := 14) (by decide) hbmul_bl
      have hr13_base : r_13 13 + r_13 14 = nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b_min * s₀_d + 0)) := by
        have h13 : r_13 13 = r_10 13 + r_10 14 := by simp [r_13, r_12, r_11]
        have h14 : r_13 14 = r_12 1 * r_12 14 := by simp [r_13]
        rw [h13, h14, hr10_add, hr12_mul]; unfold nodeCellAddr; push_cast; ring
      have hbase_bl : intBitLength (r_13 13 + r_13 14) ≤ W := by
        rw [hr13_base]
        exact (nodeCellAddr_bl (K_max := K_max) (by omega) (by omega) hN_W).2
      have q14 := RegExec.add (inp := inp) hfd_le bq13 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 13) (a := 13) (b := 14)
        (by decide) (by decide) (by decide) hbase_bl
      set r_14 := Function.update r_13 13 (r_13 13 + r_13 14); have bq14 := bq13.update (r := 13) (by decide) hbase_bl
      obtain ⟨q15, hm_w2, bq15⟩ := exec_litStoreHeap hfd_le hm_w1 hCeilC hCeilB bq14
        (table := 9) (valReg := 13) (c := 122) (by decide) (by decide) hn9 hl122
        (mem_posDimWriteLocs_tab9 (by decide)) (Nat.le_trans (by decide) hW32)
      set w2 := w1.write (.heap 9 122) (r_14 13)
      set r_15 := Function.update r_14 10 122
      let candFn : Fin s₀_d → ℕ × ℕ := fun t => (v.built.aux.birthHandles ⟨b_min, hb_lt⟩ t, y_h)
      let InnerInv : ℕ → WordStore → (ℕ → ℤ) → Prop := fun t w r =>
        t ≤ s₀_d ∧
        ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
        RegBounded W r ∧
        BestPairStored B P (foldBestPairs P cur (((List.finRange s₀_d).take t).map candFn)) w ∧
        w.read (.heap 9 121) = (y_h : ℤ) ∧
        w.read (.heap 9 122) = nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b_min * s₀_d + t)) ∧
        (∀ loc : RAMCellLoc, ¬ isBestPairLoc loc → loc ≠ .heap 9 122 →
          (loc ∈ w.live ↔ loc ∈ w1.live) ∧ w.vals loc = w1.vals loc)
      have hbest_w2 : BestPairStored B P cur w2 :=
        hbest.of_unchanged_vals hmod.wf hm_w2.wf (fun i _ _ => by simp [w2, w1, WordStore.write])
      have hInner0 : InnerInv 0 w2 r_15 := by
        refine ⟨Nat.zero_le _, hm_w2, bq15, by simpa using hbest_w2, ?_, ?_, ?_⟩
        · rw [wordStore_read_write_ne w1 (by decide)]
          simp [w1, WordStore.read, WordStore.write, hg6_2]
        · simp [w2, r_14, hr13_base, WordStore.read, WordStore.write]
        · intro loc _ hne122
          exact ⟨by simp [w2, WordStore.write, hne122], by simp [w2, WordStore.write, Function.update_of_ne hne122]⟩
      obtain ⟨wLoop, rLoop, q16, hInnerEnd⟩ :=
        RegExec.repeatLit_inv (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
          s₀_d hs0_bl InnerInv hInner0 bq15
          (U := 220 * d + 200) (B := (52 * d + 48) * W * W)
          (fun t ht wCur rCur ⟨_, hmCur, brCur, hbestCur, hr121Cur, hr122Cur, hunchCur⟩ => by
            have hoff_t : 6 + 2 * d + (b_min * s₀_d + t) < posNodeStride d L := by omega
            have hoff_t1 : 6 + 2 * d + (b_min * s₀_d + (t + 1)) < posNodeStride d L := by omega
            have haddr_t_bl : intBitLength (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b_min * s₀_d + t))) ≤ W :=
              (nodeCellAddr_bl (K_max := K_max) (by omega) hoff_t hN_W).2
            have haddr_t1_bl : intBitLength (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b_min * s₀_d + (t + 1)))) ≤ W :=
              (nodeCellAddr_bl (K_max := K_max) (by omega) hoff_t1 hN_W).2
            obtain ⟨i1, bi1⟩ := exec_litLoadHeap hfd_le hmCur hCeilC hCeilB brCur (dst := 13) (table := 9) (c := 122)
              (by decide) hn9 hl122 hr122Cur haddr_t_bl
            set gi1 := Function.update (Function.update rCur 10 122) 13
              (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b_min * s₀_d + t)))
            have hread_bh : wCur.read (.heap 3 (gi1 13)) = (v.built.aux.birthHandles ⟨b_min, hb_lt⟩ ⟨t, ht⟩ : ℤ) := by
              simp only [gi1, Function.update_self]
              have hval_eq : wCur.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b_min * s₀_d + t)))) =
                  wsRef.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b_min * s₀_d + t)))) := by
                let loc3 : RAMCellLoc := .heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b_min * s₀_d + t)))
                have u1 := (hunchCur loc3 (by simp [loc3, isBestPairLoc]) (by simp [loc3])).2
                have u2 : w1.vals loc3 = ws.vals loc3 := by simp [w1, loc3, WordStore.write]
                have u3 := (hunchRef loc3 (by simp [loc3, isAnsHeaderLoc])
                  (not_in_treeSlice_of_table_ne (by decide) _) (by simp [loc3])).2
                exact u1.trans (u2.trans u3)
              rw [wordStore_read_eq_vals hmCur.wf, hval_eq, ← wordStore_read_eq_vals hinv.mod.wf]
              exact hlvl.read_bh ⟨b_min, hb_lt⟩ ⟨t, ht⟩
            have hbh_bl : intBitLength (v.built.aux.birthHandles ⟨b_min, hb_lt⟩ ⟨t, ht⟩ : ℤ) ≤ W :=
              (nat_lt_pow2_bitLength_le (hlvl.hbh_lt ⟨b_min, hb_lt⟩ ⟨t, ht⟩)).trans (by omega)
            have i2 := RegExec.load (inp := inp) hfd_le bi1 (sp_ok hmCur).1 (sp_ok hmCur).2
              (dst := 1) (table := 3) (addr := 13) (by decide) (by decide) hn3 (by rw [hread_bh]; exact hbh_bl)
            rw [hread_bh] at i2
            set gi2 := Function.update gi1 1 (v.built.aux.birthHandles ⟨b_min, hb_lt⟩ ⟨t, ht⟩ : ℤ)
            have bi2 := bi1.update (r := 1) (by decide) hbh_bl
            have i3 := RegExec.lit (inp := inp) hfd_le bi2 (sp_ok hmCur).1 (sp_ok hmCur).2
              (dst := 14) (c := 1) (by decide) hl1
            set gi3 := Function.update gi2 14 1; have bi3 := bi2.update (r := 14) (by decide) hl1
            have hgi3_add : gi3 13 + gi3 14 =
                nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b_min * s₀_d + (t + 1))) := by
              simp [gi3, gi2, gi1, nodeCellAddr]; push_cast; ring
            have i4 := RegExec.add (inp := inp) hfd_le bi3 (sp_ok hmCur).1 (sp_ok hmCur).2
              (dst := 13) (a := 13) (b := 14) (by decide) (by decide) (by decide)
              (by rw [hgi3_add]; exact haddr_t1_bl)
            set gi4 := Function.update gi3 13 (gi3 13 + gi3 14)
            have bi4 := bi3.update (r := 13) (v := gi3 13 + gi3 14) (by decide) (by rw [hgi3_add]; exact haddr_t1_bl)
            obtain ⟨i5, hmNext1, bi5⟩ := exec_litStoreHeap hfd_le hmCur hCeilC hCeilB bi4
              (table := 9) (valReg := 13) (c := 122) (by decide) (by decide) hn9 hl122
              (mem_posDimWriteLocs_tab9 (by decide)) (Nat.le_trans (by decide) hW32)
            set wCur1 := wCur.write (.heap 9 122) (gi4 13)
            set gi5 := Function.update gi4 10 122
            have hwCur1_121 : wCur1.read (.heap 9 121) = (y_h : ℤ) := by
              rw [wordStore_read_write_ne wCur (by decide)]; exact hr121Cur
            obtain ⟨i6, bi6⟩ := exec_litLoadHeap hfd_le hmNext1 hCeilC hCeilB bi5
              (dst := 2) (table := 9) (c := 121) (by decide) hn9 hl121 hwCur1_121 hy_bl
            set gi6 := Function.update (Function.update gi5 10 121) 2 (y_h : ℤ)
            have hcoords_Cur1 : ActiveCoordsStored d L B P.activeHandles qMap wCur1 :=
              hinv.coords_stored.unchanged (fun h' _ c _ f _ => by
                rw [wordStore_read_eq_vals hmNext1.wf, wordStore_read_eq_vals hinv.mod.wf]
                let loc1 : RAMCellLoc := .heap 1 (coordCellAddr d h' c f)
                have u0 : wCur1.vals loc1 = wCur.vals loc1 := by simp [wCur1, loc1, WordStore.write]
                have u1 := (hunchCur loc1 (by simp [loc1, isBestPairLoc]) (by simp [loc1])).2
                have u2 : w1.vals loc1 = ws.vals loc1 := by simp [w1, loc1, WordStore.write]
                have u3 := (hunchRef loc1 (by simp [loc1, isAnsHeaderLoc])
                  (not_in_treeSlice_of_table_ne (by decide) _) (by simp [loc1])).2
                exact u0.trans (u1.trans (u2.trans u3)))
            have hbest_Cur1 : BestPairStored B P (foldBestPairs P cur (((List.finRange s₀_d).take t).map candFn)) wCur1 :=
              hbestCur.of_unchanged_vals hmCur.wf hmNext1.wf (fun i _ _ => by simp [wCur1, WordStore.write])
            obtain ⟨wNext, rNext, i7, hmNext, brNext, hbestNext, hunchNext⟩ :=
              exec_considerCandRegs (cand := candFn ⟨t, ht⟩) hd1 hB1 hfd_le hmNext1 hCeilC hCeilB
                (by have hm : d * (4 * B + 12) ≤ d * (8 * B + 24) := Nat.mul_le_mul_left d (by clear * -; omega); clear * - hW hm; omega)
                hinv.wfP hinv.hlt_sync hcoords_Cur1
                (fun i _ hi5 => mem_posDimWriteLocs_tab0 (by omega))
                hbest_Cur1 (hbh_act ⟨t, ht⟩) hy_act bi6
                (by simp +zetaDelta [candFn, gi6, gi5, gi4, gi3, gi2]) (by simp +zetaDelta [candFn, gi6])
            have hdWW : 0 ≤ d * W * W := by positivity
            have iTot := (i1.seq (i2.seq (i3.seq (i4.seq (i5.seq (i6.seq i7)))))).weaken
              rfl rfl (u₂ := 220 * d + 200) (b₂ := (52 * d + 48) * W * W)
              (by omega) (by nlinarith only [hW32, hd1, hdWW])
            have hfold_eq : foldBestPairs P cur (((List.finRange s₀_d).take (t + 1)).map candFn) =
                stepBestPair P (foldBestPairs P cur (((List.finRange s₀_d).take t).map candFn)) (candFn ⟨t, ht⟩) := by
              rw [finRange_take_succ ht, List.map_append, List.map_singleton,
                  foldBestPairs_append, foldBestPairs_singleton]
            rw [← hfold_eq] at hbestNext
            refine ⟨wNext, rNext, iTot, Nat.succ_le_of_lt ht, hmNext, brNext, hbestNext, ?_, ?_, ?_⟩
            · rw [wordStore_read_eq_vals hmNext.wf,
                  (hunchNext (.heap 9 121) (by rintro (h | h | h | h) <;> cases h)).2,
                  ← wordStore_read_eq_vals hmNext1.wf]
              exact hwCur1_121
            · rw [wordStore_read_eq_vals hmNext.wf,
                  (hunchNext (.heap 9 122) (by rintro (h | h | h | h) <;> cases h)).2,
                  ← wordStore_read_eq_vals hmNext1.wf]
              simp [wCur1, gi4, hgi3_add, WordStore.read, WordStore.write]
            · intro loc hnb hne122
              have uN := hunchNext loc hnb
              have uC := hunchCur loc hnb hne122
              exact ⟨uN.1.trans (by simp [wCur1, WordStore.write, hne122, uC.1]),
                     uN.2.trans (by simp [wCur1, WordStore.write, Function.update_of_ne hne122, uC.2])⟩)
      rcases hInnerEnd with ⟨_, hmLoop, brLoop, hbestLoop, _, _, hunchLoop⟩
      rw [finRange_take_self, ← hlcands_eq] at hbestLoop
      obtain ⟨q17, hmFree1, brFree1⟩ := exec_litFreeHeap hfd_le hmLoop hCeilC hCeilB brLoop hn9 hl121
        (mem_posDimWriteLocs_tab9 (by decide))
      obtain ⟨q18, hmFree2, brFree2⟩ := exec_litFreeHeap hfd_le hmFree1 hCeilC hCeilB brFree1 hn9 hl122
        (mem_posDimWriteLocs_tab9 (by decide))
      set wsMid := (wLoop.free (.heap 9 121)).free (.heap 9 122)
      have hbestMid : BestPairStored B P (foldBestPairs P cur (levelScanCands L P nodes ⟨j, hj⟩)) wsMid :=
        hbestLoop.of_unchanged_vals hmLoop.wf hmFree2.wf (fun i _ _ => by simp [wsMid, WordStore.free])
      have hunchMid : ∀ loc : RAMCellLoc, ¬ isBestPairLoc loc →
          (loc ∈ wsMid.live ↔ loc ∈ ws.live) ∧ wsMid.vals loc = ws.vals loc := by
        intro loc hnb
        by_cases h121 : loc = .heap 9 121
        · subst h121
          exact ⟨by simp [wsMid, WordStore.free, hn121], by simp [wsMid, WordStore.free, hmod.wf _ hn121]⟩
        · by_cases h122 : loc = .heap 9 122
          · subst h122
            exact ⟨by simp [wsMid, WordStore.free, hn122], by simp [wsMid, WordStore.free, hmod.wf _ hn122]⟩
          · have uL := hunchLoop loc hnb h122
            exact ⟨by simp [wsMid, WordStore.free, h121, h122, uL.1, w1, WordStore.write],
                   by simp [wsMid, WordStore.free, Function.update_of_ne h121, Function.update_of_ne h122,
                        uL.2, w1, WordStore.write]⟩
      have hLWW : 0 ≤ L * W * W := by positivity
      have hsWW : 0 ≤ s₀_d * (52 * d + 48) * W * W := by positivity
      have qNonempty := (q1.seq (q2.seq (q3.seq (q4.seq (q5.seq (q6.seq (q7.seq (q8.seq (q9.seq
        (q10.seq (q11.seq (q12.seq (q13.seq (q14.seq (q15.seq (q16.seq (q17.seq q18))))))))))))))))).weaken
        rfl rfl (u₂ := s₀_d * (220 * d + 200) + 64 * L + 154)
        (b₂ := (s₀_d * (52 * d + 48) + 12 * L + 27) * W * W)
        (by omega) (by nlinarith only [hW32, hL1, hLWW, hsWW])
      have qIte := (RegExec.iteLt (tB := levelScanNonemptyRegs d s₀_d L) (fB := .skip) bg6 (a := 14) (b := 1)
        (by decide) (by decide) (by rw [if_pos hlt_reg]; exact qNonempty)).weaken
        rfl rfl (u₂ := s₀_d * (220 * d + 200) + 64 * L + 160)
        (b₂ := (s₀_d * (52 * d + 48) + 12 * L + 28) * W * W)
        (by omega) (by
          have hWW : 4 * W + 16 ≤ W * W := by nlinarith only [hW32]
          have heq : (s₀_d * (52 * d + 48) + 12 * L + 28) * W * W =
              (s₀_d * (52 * d + 48) + 12 * L + 27) * W * W + W * W := by ring
          rw [heq]; omega)
      refine ⟨wsMid, _, qIte, hmFree2, brFree2, hbestMid, ?_, ?_, ?_, hunchMid⟩
      · rw [wordStore_read_eq_vals hmFree2.wf,
            (hunchMid (.heap 9 120) (by rintro (h | h | h | h) <;> cases h)).2,
            ← wordStore_read_eq_vals hmod.wf]
        exact hr120
      · simp [wsMid, WordStore.free]
      · simp [wsMid, WordStore.free]
    · have hnlt_reg : ¬ (g6 14 < g6 1) := by
        rw [hg6_14, hg6_1]
        have hc0 : S_j_h.card = 0 := Finset.not_nonempty_iff_eq_empty.mp hSne ▸ rfl
        rw [hc0]; omega
      have hlcands_nil : levelScanCands L P nodes ⟨j, hj⟩ = [] := by
        simp +zetaDelta only [levelScanCands, hSne, ↓reduceIte]
      have hLWW : 0 ≤ L * W * W := by positivity
      have hsWW : 0 ≤ s₀_d * (52 * d + 48) * W * W := by positivity
      have qSkip := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) bg6).weaken
        rfl rfl (u₂ := s₀_d * (220 * d + 200) + 64 * L + 154)
        (b₂ := (s₀_d * (52 * d + 48) + 12 * L + 27) * W * W)
        (by omega) (by nlinarith only [hW32, hL1, hLWW, hsWW])
      have qIte := (RegExec.iteLt (tB := levelScanNonemptyRegs d s₀_d L) (fB := .skip) bg6 (a := 14) (b := 1)
        (by decide) (by decide) (by rw [if_neg hnlt_reg]; exact qSkip)).weaken
        rfl rfl (u₂ := s₀_d * (220 * d + 200) + 64 * L + 160)
        (b₂ := (s₀_d * (52 * d + 48) + 12 * L + 28) * W * W)
        (by omega) (by
          have hWW : 4 * W + 16 ≤ W * W := by nlinarith only [hW32]
          have heq : (s₀_d * (52 * d + 48) + 12 * L + 28) * W * W =
              (s₀_d * (52 * d + 48) + 12 * L + 27) * W * W + W * W := by ring
          rw [heq]; omega)
      rw [hlcands_nil]
      exact ⟨ws, g6, qIte, hmod, bg6, hbest, hr120, hn121, hn122, fun _ _ => ⟨Iff.rfl, rfl⟩⟩
  obtain ⟨wsMid, regsMid, p7, hmMid, bgMid, hbestMid, hr120Mid, hn121Mid, hn122Mid, hunchMid⟩ := hIte
  have hj1_cast : (j : ℤ) + 1 = ((j + 1 : ℕ) : ℤ) := by push_cast; rfl
  obtain ⟨regsEnd, p8, hmEnd, bgEnd⟩ :=
    exec_incrHeap9Regs hfd_le hmMid hCeilC hCeilB (by omega) hl120
      (Nat.le_trans (by decide) hW32) (mem_posDimWriteLocs_tab9 (by decide))
      hr120Mid hj_bl (by rw [hj1_cast]; exact hj1_bl) bgMid
  set wsEnd := wsMid.write (.heap 9 120) ((j : ℤ) + 1)
  have hbestEnd : BestPairStored B P (foldBestPairs P cur (levelScanCands L P nodes ⟨j, hj⟩)) wsEnd :=
    hbestMid.of_unchanged_vals hmMid.wf hmEnd.wf (fun i _ _ => by simp [wsEnd, WordStore.write])
  have hLWW : 0 ≤ L * W * W := by positivity
  have hsWW : 0 ≤ s₀_d * (52 * d + 48) * W * W := by positivity
  have pTot := (p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq (p7.seq p8))))))).weaken
    rfl rfl (u₂ := s₀_d * (220 * d + 200) + 64 * L + 340)
    (b₂ := (s₀_d * (52 * d + 48) + 12 * L + 60) * W * W)
    (by omega) (by nlinarith only [hW32, hL1, hLWW, hsWW])
  refine ⟨wsEnd, regsEnd, pTot, hmEnd, bgEnd, hbestEnd, ?_, ?_, ?_, ?_⟩
  · simp [wsEnd, WordStore.read, WordStore.write]
  · simp [wsEnd, WordStore.write, hn121Mid]
  · simp [wsEnd, WordStore.write, hn122Mid]
  · intro loc hnb hne120
    have uM := hunchMid loc hnb
    exact ⟨by simp [wsEnd, WordStore.write, hne120, uM.1],
           by simp [wsEnd, WordStore.write, Function.update_of_ne hne120, uM.2]⟩


end UL.C12LVE
