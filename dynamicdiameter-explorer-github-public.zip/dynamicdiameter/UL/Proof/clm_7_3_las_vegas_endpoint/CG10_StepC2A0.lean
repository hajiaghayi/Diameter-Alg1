import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b3_StepBFull
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Prefix Build Invariant (`ChainPrefixBuildInv`) & `chainInput` Append Lemmas -/

/-- Prefix-level RAM and mathematical invariant during synchronous suffix construction:
identical to `ChainStoredInv` on active prefix `nodes` (`nodes.length ≤ K_max + 1`), except
the terminal residual in `tree 1` need not yet satisfy `|S_k| ≤ 2 * L_leaf`, and caller scratch
cells in `heap 9` outside `[110, 120)` are permitted to remain live. -/
structure ChainPrefixBuildInv {d s₀_d : ℕ} (n L B B_cert K_max W : ℕ)
    (P : DynamicPointSet d)
    (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)))
    (qMap : ℕ → Fin d → ℚ)
    (ws : WordStore) : Prop where
  wfP : P.WellFormed n
  mod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws
  hk_le : nodes.length ≤ K_max + 1
  read_k : ws.read (.heap 0 10) = (nodes.length : ℤ)
  hlt_sync : ∀ id ∈ P.activeIds,
    ltCoords (P.lifetimeOfId id) = P.coords id ∧
    P.coords id = ratPointToEuclidean (qMap (P.handleOfId id))
  hlt_adm : ∀ lt < P.nextLifetime, ltCoords lt ∈ RatAdmissiblePointSet d B ∨ ltCoords lt = 0
  coords_stored : ActiveCoordsStored d L B P.activeHandles qMap ws
  tree_active : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) ws
  hbirth_avoid : ∀ (j : ℕ) (hj : j < nodes.length),
    ∀ lt ∈ (nodes.get ⟨j, hj⟩).birthPool,
      ∀ (i : ℕ) (hi : i < j),
        ltCoords lt ∉ coreBall (nodes.get ⟨i, Nat.lt_trans hi hj⟩).built.node.o
          (nodes.get ⟨i, Nat.lt_trans hi hj⟩).built.node.V
  levels : ∀ (j : ℕ) (hj : j < nodes.length),
    let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
    let S_lt := chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩
    LevelStoredInv n L B B_cert K_max P ltCoords qMap S_lt (nodes.get ⟨j, hj⟩) j ws
  empty_levels : ∀ j : ℕ, nodes.length ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j ws
  tree_leaf :
    let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
    let S_k_lt := chainInput ltCoords vecNodes (activeLifetimes P) (Fin.last nodes.length)
    TreeStoredAt L 1 (S_k_lt.image (handleOfLifetime P)) (fun _ => 0) (fun _ => 1) ws
  stage_clean : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7 ∨ t = 8) → ∀ z : ℤ,
    (.heap t z : RAMCellLoc) ∉ ws.live
  tab9_clean_c2 : ∀ i : ℕ, 110 ≤ i → i < 120 →
    (.heap 9 (i : ℤ) : RAMCellLoc) ∉ ws.live

theorem ChainStoredInv.toPrefixBuildInv {d s₀_d n L B B_cert K_max W : ℕ}
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    (h : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws) :
    ChainPrefixBuildInv n L B B_cert K_max W P ltCoords nodes qMap ws :=
  { wfP := h.wfP
    mod := h.mod
    hk_le := Nat.le_succ_of_le h.hk_le
    read_k := h.read_k
    hlt_sync := h.hlt_sync
    hlt_adm := h.hlt_adm
    coords_stored := h.coords_stored
    tree_active := h.tree_active
    hbirth_avoid := h.hbirth_avoid
    levels := h.levels
    empty_levels := h.empty_levels
    tree_leaf := h.tree_leaf.2
    stage_clean := fun t ht z => by
      rcases ht with rfl | rfl | rfl | rfl
      · exact h.stage_clean 5 (Or.inl rfl) z
      · exact h.stage_clean 6 (Or.inr (Or.inl rfl)) z
      · exact h.stage_clean 7 (Or.inr (Or.inr (Or.inl rfl))) z
      · exact h.stage_clean 8 (Or.inr (Or.inr (Or.inr (Or.inl rfl)))) z
    tab9_clean_c2 := fun i _ _ =>
      h.stage_clean 9 (Or.inr (Or.inr (Or.inr (Or.inr rfl)))) (i : ℤ) }

theorem ChainPrefixBuildInv.toChainStoredInv {d s₀_d n L B B_cert K_max W : ℕ}
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    (h : ChainPrefixBuildInv n L B B_cert K_max W P ltCoords nodes qMap ws)
    (hk_le : nodes.length ≤ K_max)
    (hleaf_le :
      (chainInput ltCoords (fun i : Fin nodes.length => (nodes.get i).built.node)
        (activeLifetimes P) (Fin.last nodes.length)).card ≤ 2 * (2 * s₀_d - 1))
    (h9_clean : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∉ ws.live) :
    ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws :=
  { wfP := h.wfP
    mod := h.mod
    hk_le := hk_le
    read_k := h.read_k
    hlt_sync := h.hlt_sync
    hlt_adm := h.hlt_adm
    coords_stored := h.coords_stored
    tree_active := h.tree_active
    hbirth_avoid := h.hbirth_avoid
    levels := h.levels
    empty_levels := h.empty_levels
    tree_leaf := ⟨hleaf_le, h.tree_leaf⟩
    stage_clean := fun t ht z => by
      rcases ht with rfl | rfl | rfl | rfl | rfl
      · exact h.stage_clean 5 (Or.inl rfl) z
      · exact h.stage_clean 6 (Or.inr (Or.inl rfl)) z
      · exact h.stage_clean 7 (Or.inr (Or.inr (Or.inl rfl))) z
      · exact h.stage_clean 8 (Or.inr (Or.inr (Or.inr rfl))) z
      · exact h9_clean z }

theorem isA2BaseStore_of_modPosDim {d L K_max W : ℕ} {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws) :
    IsA2BaseStore ws := by
  refine ⟨hmod.wf, fun loc hloc => ?_⟩
  have hsub := hmod.live_sub hloc
  simp only [WordStore.empty, Finset.empty_union] at hsub
  exact posDimWriteLocs_isA2Base loc hsub

theorem noLocal_of_modPosDim {d L K_max W : ℕ} {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws) :
    ∀ d' ≥ 1, ∀ v i, (.localFrame d' v i : RAMCellLoc) ∉ ws.live := by
  intro d' _ v i hm
  have hsub := hmod.live_sub hm
  simp only [WordStore.empty, Finset.empty_union] at hsub
  rcases posDimWriteLocs_isHeap _ hsub with ⟨t, _, z, hloc⟩
  cases hloc


theorem ltCoords_eq_qMap_of_active {d n : ℕ} {P : DynamicPointSet d}
    {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)} {qMap : ℕ → Fin d → ℚ}
    (hwf : P.WellFormed n)
    (hsync : ∀ id ∈ P.activeIds,
      ltCoords (P.lifetimeOfId id) = P.coords id ∧
      P.coords id = ratPointToEuclidean (qMap (P.handleOfId id)))
    {lt : ℕ} (hlt : lt ∈ activeLifetimes P) :
    lt < P.nextLifetime ∧
    handleOfLifetime P lt ∈ P.activeHandles ∧
    ltCoords lt = ratPointToEuclidean (qMap (handleOfLifetime P lt)) := by
  have hmem := Finset.mem_image.mp hlt
  rcases hmem with ⟨id, hid, rfl⟩
  have hlt_next : P.lifetimeOfId id < P.nextLifetime := hwf.2.2.2.1 id hid
  have hh_mem : P.handleOfId id ∈ P.activeHandles := (hwf.2.1 id hid).1
  have hh_eq : handleOfLifetime P (P.lifetimeOfId id) = P.handleOfId id :=
    handleOfLifetime_of_mem hwf hid
  obtain ⟨hc1, hc2⟩ := hsync id hid
  exact ⟨hlt_next, hh_eq ▸ hh_mem, by rw [hc1, hc2, hh_eq]⟩

/-! ### 2. `minPopElem` Strict Monotonicity, `handleSortedEnum`, & History Canonical Enum -/


/-! ### 3. Staging (`stageA2FromBufRegs`) and Unstaging (`unstageA2Regs`) Tables `5, 6, 7` -/

def stageA2InnerStepStmt : BitRAMStmt :=
  .seq (rAdd 8 7 6)
  (.seq (rAdd 8 8 8)
  (.seq (rLoad 9 1 8)
  (.seq (rAdd 8 8 3)
  (.seq (rLoad 10 1 8)
  (.seq (rSub 11 10 3)
  (.seq (rStore 6 2 9)
  (.seq (rStore 7 2 11)
  (.seq (rAdd 2 2 3)
         (rAdd 6 6 3)))))))))

def stageA2OuterStepStmt (d : ℕ) : BitRAMStmt :=
  .seq (rLoad 5 8 1)
  (.seq (rLit 6 0)
  (.seq (rMul 7 5 4)
  (.seq (.repeatN (.lit (d : ℤ)) stageA2InnerStepStmt)
         (rAdd 1 1 3))))

def stageA2FromBufRegs (d B : ℕ) : BitRAMStmt :=
  .seq (rLit 10 110)
  (.seq (rLoad 0 9 10)
  (.seq (rLit 10 0)
  (.seq (rStore 5 10 0)
  (.seq (rLit 10 1)
  (.seq (rLit 11 (B : ℤ))
  (.seq (rStore 5 10 11)
  (.seq (rLit 1 0)
  (.seq (rLit 2 1)
  (.seq (rLit 3 1)
  (.seq (rLit 4 (d : ℤ))
         (.repeatN (.readLocal 0 (.lit 0)) (stageA2OuterStepStmt d))))))))))))

theorem ratCoord_intBitLength_le {B : ℕ} {q : ℚ} (hq : RatCoordBitBounded B q) :
    intBitLength q.num ≤ B + 2 ∧
    intBitLength (q.den : ℤ) ≤ B + 2 ∧
    intBitLength ((q.den : ℤ) - 1) ≤ B + 2 := by
  rcases hq with ⟨hnum, hden⟩
  have h1 : intBitLength q.num ≤ B + 2 := by
    unfold intBitLength
    split_ifs <;> omega
  have h2 : intBitLength (q.den : ℤ) ≤ B + 2 := by
    have := intBitLength_ofNat_le q.den
    omega
  have h3 : intBitLength ((q.den : ℤ) - 1) ≤ B + 2 := by
    have hpos : 1 ≤ q.den := q.pos
    have heq : ((q.den : ℤ) - 1) = ((q.den - 1 : ℕ) : ℤ) := by omega
    rw [heq]
    have hm := intBitLength_ofNat_le (q.den - 1)
    have hmon := natBitLength_mono (Nat.sub_le q.den 1)
    omega
  exact ⟨h1, h2, h3⟩

theorem stageAddr_bitLength_le {d L k W : ℕ}
    (hd1 : 1 ≤ d) (hk : k < 2 * d * 2 ^ L + 16)
    (hW : natBitLength d + L + 16 ≤ W) :
    intBitLength (k : ℤ) ≤ W ∧
    (RAMCellLoc.heap 5 (k : ℤ)).bitLength ≤ W ∧
    (RAMCellLoc.heap 6 (k : ℤ)).bitLength ≤ W ∧
    (RAMCellLoc.heap 7 (k : ℤ)).bitLength ≤ W := by
  have hpow_pos : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
  have hbound : k < d * 2 ^ (L + 5) := by
    have hp : 2 ^ (L + 5) = 32 * 2 ^ L := by rw [pow_add]; norm_num; ring
    rw [hp]
    nlinarith only [hd1, hpow_pos, hk]
  have hbl_k : intBitLength (k : ℤ) ≤ natBitLength d + L + 9 := by
    have hd_lt : d < 2 ^ (Nat.log 2 d + 1) := Nat.lt_pow_succ_log_self (by decide) d
    have hp2 : 0 < 2 ^ (L + 5) := by positivity
    have hprod : k < 2 ^ (Nat.log 2 d + 1 + (L + 5)) := by
      calc k < d * 2 ^ (L + 5) := hbound
        _ < 2 ^ (Nat.log 2 d + 1) * 2 ^ (L + 5) := Nat.mul_lt_mul_of_pos_right hd_lt hp2
        _ = 2 ^ (Nat.log 2 d + 1 + (L + 5)) := (pow_add 2 _ _).symm
    have hbl1 := nat_lt_pow2_bitLength_le hprod
    have hd_nbl : Nat.log 2 d + 1 ≤ natBitLength d := by
      unfold natBitLength; omega
    omega
  have hn5 : natBitLength 5 = 3 := by decide
  have hn6 : natBitLength 6 = 3 := by decide
  have hn7 : natBitLength 7 = 3 := by decide
  exact ⟨by omega,
    by dsimp [RAMCellLoc.bitLength]; rw [hn5]; omega,
    by dsimp [RAMCellLoc.bitLength]; rw [hn6]; omega,
    by dsimp [RAMCellLoc.bitLength]; rw [hn7]; omega⟩


end UL.C12LVE
