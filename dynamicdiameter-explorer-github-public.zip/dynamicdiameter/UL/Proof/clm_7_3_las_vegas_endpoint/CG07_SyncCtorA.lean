import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorA0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open scoped ENNReal
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### 4. Handle-Ordered `SyncCertifiedNodeConstructor` for `PosDimNodeData` -/

noncomputable def c12MkA2Input {d : ℕ} (B : ℕ) (P_prev : DynamicPointSet d)
    (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ℕ) : BitRAMInput d :=
  let m := P₀.card
  let enum := c12EnumByKey (c12LtHandleAfter P_prev) P₀
  let ptsSub : ℕ → Fin d → ℚ := fun lt => c12EuclideanToRat (ltCoords lt)
  { intParams := [(m : ℤ), (B : ℤ)]
    activeHandles := Finset.range m
    activeRatCoords := fun h => if hh : h < m then ptsSub (enum ⟨h, hh⟩).1 else fun _ => 0
    extraRats := [] }

/-- Full deterministic specification of a node constructed by `c12BuildSyncCtor`, parameterized
by its halting `outA2 : BitRAMExecOutcome` and exposing all `PosDimNodeData` fields for Step C2. -/
structure C12CertifiedNodeSpec {d : ℕ} (s₀_d B : ℕ) (progA2 : BitRAMStmt)
    (spaceA2 bitLenA2 : ℕ → ℕ → ℝ)
    (P_prev : DynamicPointSet d)
    (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (P₀ : Finset ℕ) (bs : List Bool)
    (built : SyncBuiltNode d (PosDimNodeData d s₀_d))
    (outA2 : BitRAMExecOutcome) : Prop where
  m_ge : 2 * s₀_d ≤ P₀.card
  run_eq : runBitRAMWithBits progA2 (c12MkA2Input B P_prev ltCoords P₀) WordStore.empty bs = some outA2
  work_eq : built.work = outA2.bitCost + outA2.unitCost + P₀.card
  peak_cell : (outA2.peakCellSpace : ℝ) ≤ (P₀.card : ℝ) * spaceA2 d B
  peak_bit : (outA2.peakBitSpace : ℝ) ≤
    (P₀.card : ℝ) * (Nat.clog 2 (2 * P₀.card) : ℝ) * spaceA2 d B
  node_o : built.node.o = ratPointToEuclidean built.aux.oRat
  node_s : built.s = (built.aux.sRat : ℝ)
  node_V : built.node.V = liftVariance built.node.o built.s
  centerpoint : IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
    (paraboloidLiftSet (fun i : P₀ => ltCoords i.1))
    (liftedPoint built.node.o built.s)
  V_num_eq : built.aux.V_num = c12ExtractedVNum d outA2
  V_den_eq : built.aux.V_den = c12ExtractedVDen d outA2
  k_read : outA2.words.read (.heap 0 0) = (built.aux.k_blk : ℤ)
  k_bounds : 1 ≤ built.aux.k_blk ∧ built.aux.k_blk * s₀_d ≤ P₀.card
  k_ratio : (P₀.card : ℝ) / (4 * (s₀_d : ℝ)) ≤ (built.aux.k_blk : ℝ)
  o_spec : ∀ c : Fin d,
    let oN := outA2.words.read (.heap 1 (2 * (c.val : ℤ)))
    let oD := outA2.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
    0 < oD ∧ built.aux.oRat c = (oN : ℚ) / (oD : ℚ) ∧
    (intBitLength oN : ℝ) ≤ bitLenA2 d B ∧ (intBitLength oD : ℝ) ≤ bitLenA2 d B
  s_spec :
    let sN := outA2.words.read (.heap 1 (2 * (d : ℤ)))
    let sD := outA2.words.read (.heap 1 (2 * (d : ℤ) + 1))
    0 < sD ∧ built.aux.sRat = (sN : ℚ) / (sD : ℚ) ∧
    (intBitLength sN : ℝ) ≤ bitLenA2 d B ∧ (intBitLength sD : ℝ) ≤ bitLenA2 d B
  blk_spec : ∀ (b : Fin built.aux.k_blk) (t : Fin s₀_d),
    let flatIdx : ℤ := ((b.val * s₀_d + t.val : ℕ) : ℤ)
    ∃ idx : Fin P₀.card,
      outA2.words.read (.heap 2 flatIdx) = (idx.val : ℤ) ∧
      built.aux.birthLifetimes b t = (c12EnumByKey (c12LtHandleAfter P_prev) P₀ idx).1 ∧
      built.aux.birthLifetimes b t ∈ P₀ ∧
      built.aux.birthHandles b t = c12LtHandleAfter P_prev (built.aux.birthLifetimes b t)
  blt_inj : Function.Injective2 built.aux.birthLifetimes
  certs_spec : ∀ b : Fin built.aux.k_blk,
    IsBlockCertificate ltCoords P₀ (liftedPoint built.node.o built.s)
      (Finset.univ.image (built.aux.birthLifetimes b))
      (fun lt => ∑ t : Fin s₀_d,
        if built.aux.birthLifetimes b t = lt then (built.aux.lam b t : ℝ) else 0)

private structure C12A2CertPkg (d s₀_d : ℕ) : Type where
  k_blk : ℕ
  oRat : Fin d → ℚ
  sRat : ℚ
  blocks : Fin k_blk → Fin s₀_d → ℕ
  lam : Fin k_blk → Fin s₀_d → ℚ

private def C12A2PkgGood {d s₀_d B : ℕ} (spaceA2 bitLenA2 : ℕ → ℕ → ℝ)
    (ptsSub : ℕ → Fin d → ℚ) (P₀ : Finset ℕ) (enum : Fin P₀.card ≃ ↥P₀)
    (outA2 : BitRAMExecOutcome) (pkg : C12A2CertPkg d s₀_d) : Prop :=
  (outA2.peakCellSpace : ℝ) ≤ (P₀.card : ℝ) * spaceA2 d B ∧
  (outA2.peakBitSpace : ℝ) ≤ (P₀.card : ℝ) * (Nat.clog 2 (2 * P₀.card) : ℝ) * spaceA2 d B ∧
  outA2.words.read (.heap 0 0) = (pkg.k_blk : ℤ) ∧
  (∀ c : Fin d,
    let oN := outA2.words.read (.heap 1 (2 * (c.val : ℤ)))
    let oD := outA2.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
    0 < oD ∧ pkg.oRat c = (oN : ℚ) / (oD : ℚ) ∧
    (intBitLength oN : ℝ) ≤ bitLenA2 d B ∧ (intBitLength oD : ℝ) ≤ bitLenA2 d B) ∧
  (let sN := outA2.words.read (.heap 1 (2 * (d : ℤ)))
   let sD := outA2.words.read (.heap 1 (2 * (d : ℤ) + 1))
   0 < sD ∧ pkg.sRat = (sN : ℚ) / (sD : ℚ) ∧
   (intBitLength sN : ℝ) ≤ bitLenA2 d B ∧ (intBitLength sD : ℝ) ≤ bitLenA2 d B) ∧
  (∀ (b : Fin pkg.k_blk) (t : Fin s₀_d),
    let flatIdx : ℤ := ((b.val * s₀_d + t.val : ℕ) : ℤ)
    ∃ idx : Fin P₀.card,
      outA2.words.read (.heap 2 flatIdx) = (idx.val : ℤ) ∧
      pkg.blocks b t = (enum idx).1) ∧
  (P₀.card : ℝ) / (4 * (s₀_d : ℝ)) ≤ (pkg.k_blk : ℝ) ∧
  (∀ b : Fin pkg.k_blk, (Finset.univ.image (pkg.blocks b)).card = s₀_d) ∧
  (∀ b₁ b₂ : Fin pkg.k_blk, b₁ ≠ b₂ →
    Disjoint (Finset.univ.image (pkg.blocks b₁)) (Finset.univ.image (pkg.blocks b₂))) ∧
  (∀ b : Fin pkg.k_blk,
    IsBlockCertificate (fun i => ratPointToEuclidean (ptsSub i)) P₀
      (liftedPoint (ratPointToEuclidean pkg.oRat) (pkg.sRat : ℝ))
      (Finset.univ.image (pkg.blocks b))
      (fun i => ∑ j : Fin s₀_d, if pkg.blocks b j = i then (pkg.lam b j : ℝ) else 0))

private noncomputable def c12MkBuiltNodeFromHex {d s₀_d B : ℕ}
    (h_claim_A_2 : S_claim_A_2_deletion_witness) (hd1 : 1 ≤ d) (hs₀ : 1 ≤ s₀_d)
    (spaceA2 bitLenA2 : ℕ → ℕ → ℝ)
    (P_prev : DynamicPointSet d)
    (ptsSub : ℕ → Fin d → ℚ) (P₀ : Finset ℕ) (enum : Fin P₀.card ≃ ↥P₀)
    (outA2 : BitRAMExecOutcome) (hm_ge : 2 * s₀_d ≤ P₀.card)
    (hex : ∃ pkg : C12A2CertPkg d s₀_d, C12A2PkgGood (B := B) spaceA2 bitLenA2 ptsSub P₀ enum outA2 pkg) :
    SyncBuiltNode d (PosDimNodeData d s₀_d) :=
  open Classical in
  let pkg := Classical.choose hex
  have hsp : C12A2PkgGood (B := B) spaceA2 bitLenA2 ptsSub P₀ enum outA2 pkg := Classical.choose_spec hex
  let o := ratPointToEuclidean pkg.oRat
  let s : ℝ := (pkg.sRat : ℝ)
  let V := liftVariance o s
  let ptsEuc : ℕ → EuclideanSpace ℝ (Fin d) := fun i => ratPointToEuclidean (ptsSub i)
  let certsSub : Fin pkg.k_blk → BlockCertificate ptsEuc P₀ (liftedPoint o s) := fun b =>
    let hc := hsp.2.2.2.2.2.2.2.2.2 b
    { B := Finset.univ.image (pkg.blocks b)
      coeff := fun i => ∑ j : Fin s₀_d, if pkg.blocks b j = i then (pkg.lam b j : ℝ) else 0
      subset_birth := hc.1
      coeff_nonneg := hc.2.1
      sum_coeff := hc.2.2.1
      sum_lift := hc.2.2.2 }
  have hV_nn : 0 ≤ V :=
    (h_claim_A_2 d hd1 s₀_d hs₀ ℕ ptsEuc P₀ hm_ge
      (fun p _ => ⟨ptsSub p, rfl⟩) o s pkg.k_blk hsp.2.2.2.2.2.2.1 certsSub
      hsp.2.2.2.2.2.2.2.1 hsp.2.2.2.2.2.2.2.2.1).2.2.1
  { node := { o := o, V := V, V_nonneg := hV_nn }
    s := s
    aux :=
      { k_blk := pkg.k_blk
        oRat := pkg.oRat
        sRat := pkg.sRat
        V_num := c12ExtractedVNum d outA2
        V_den := c12ExtractedVDen d outA2
        birthHandles := fun b t => c12LtHandleAfter P_prev (pkg.blocks b t)
        birthLifetimes := pkg.blocks
        lam := pkg.lam }
    work := outA2.bitCost + outA2.unitCost + P₀.card }

private theorem c12MkBuiltNodeFromHex_spec {d s₀_d B : ℕ}
    (h_claim_A_2 : S_claim_A_2_deletion_witness) (hd1 : 1 ≤ d) (hs₀ : 1 ≤ s₀_d)
    (progA2 : BitRAMStmt) (spaceA2 bitLenA2 : ℕ → ℕ → ℝ)
    (P_prev : DynamicPointSet d) (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (P₀ : Finset ℕ) (bs : List Bool) (outA2 : BitRAMExecOutcome)
    (hm_ge : 2 * s₀_d ≤ P₀.card)
    (hrat_eq : ∀ i ∈ P₀, ratPointToEuclidean (c12EuclideanToRat (ltCoords i)) = ltCoords i)
    (hrun : runBitRAMWithBits progA2 (c12MkA2Input B P_prev ltCoords P₀) WordStore.empty bs = some outA2)
    (hex : ∃ pkg : C12A2CertPkg d s₀_d,
      C12A2PkgGood (B := B) spaceA2 bitLenA2
        (fun lt => c12EuclideanToRat (ltCoords lt)) P₀
        (c12EnumByKey (c12LtHandleAfter P_prev) P₀) outA2 pkg) :
    C12CertifiedNodeSpec s₀_d B progA2 spaceA2 bitLenA2 P_prev ltCoords P₀ bs
      (c12MkBuiltNodeFromHex h_claim_A_2 hd1 hs₀ spaceA2 bitLenA2 P_prev
        (fun lt => c12EuclideanToRat (ltCoords lt)) P₀
        (c12EnumByKey (c12LtHandleAfter P_prev) P₀) outA2 hm_ge hex) outA2 := by
  classical
  set enum := c12EnumByKey (c12LtHandleAfter P_prev) P₀
  set ptsSub : ℕ → Fin d → ℚ := fun lt => c12EuclideanToRat (ltCoords lt)
  set pkg := Classical.choose hex
  have hsp : C12A2PkgGood (B := B) spaceA2 bitLenA2 ptsSub P₀ enum outA2 pkg := Classical.choose_spec hex
  let ptsEuc : ℕ → EuclideanSpace ℝ (Fin d) := fun i => ratPointToEuclidean (ptsSub i)
  let certsSub : Fin pkg.k_blk → BlockCertificate ptsEuc P₀
      (liftedPoint (ratPointToEuclidean pkg.oRat) (pkg.sRat : ℝ)) := fun b =>
    let hc := hsp.2.2.2.2.2.2.2.2.2 b
    { B := Finset.univ.image (pkg.blocks b)
      coeff := fun i => ∑ j : Fin s₀_d, if pkg.blocks b j = i then (pkg.lam b j : ℝ) else 0
      subset_birth := hc.1
      coeff_nonneg := hc.2.1
      sum_coeff := hc.2.2.1
      sum_lift := hc.2.2.2 }
  have hdw := h_claim_A_2 d hd1 s₀_d hs₀ ℕ ptsEuc P₀ hm_ge
    (fun p _ => ⟨ptsSub p, rfl⟩) (ratPointToEuclidean pkg.oRat) (pkg.sRat : ℝ) pkg.k_blk
    hsp.2.2.2.2.2.2.1 certsSub hsp.2.2.2.2.2.2.2.1 hsp.2.2.2.2.2.2.2.2.1
  have hcp : IsCenterpoint (1 / (4 * (s₀_d : ℝ))) (paraboloidLiftSet (fun i : P₀ => ltCoords i.1))
      (liftedPoint (ratPointToEuclidean pkg.oRat) (pkg.sRat : ℝ)) := by
    unfold IsCenterpoint
    have hfn_eq : (fun i : P₀ => ltCoords i.1) = (fun i : P₀ => ptsEuc i.1) := by
      funext i; exact (hrat_eq i.1 i.2).symm
    rw [hfn_eq, Fintype.card_coe]
    exact hdw.1
  have hk_pos : 1 ≤ pkg.k_blk := by
    have hs₀_pos : (0 : ℝ) < (s₀_d : ℝ) := by exact_mod_cast hs₀
    have hm_R : (2 * (s₀_d : ℝ)) ≤ (P₀.card : ℝ) := by exact_mod_cast hm_ge
    have hrat := hsp.2.2.2.2.2.2.1
    have hhalf : (1 / 2 : ℝ) ≤ (P₀.card : ℝ) / (4 * (s₀_d : ℝ)) := by
      rw [div_le_div_iff₀ (by norm_num) (by positivity)]
      linarith
    have hk_gt0 : (0 : ℝ) < (pkg.k_blk : ℝ) := lt_of_lt_of_le (by norm_num) (hhalf.trans hrat)
    have hk_pos_nat : 0 < pkg.k_blk := by exact_mod_cast hk_gt0
    omega
  have hk_mul_le : pkg.k_blk * s₀_d ≤ P₀.card := by
    let B_set : Fin pkg.k_blk → Finset ℕ := fun b => Finset.univ.image (pkg.blocks b)
    have hdisj_pw : ((Finset.univ : Finset (Fin pkg.k_blk)) : Set (Fin pkg.k_blk)).PairwiseDisjoint B_set := by
      intro b₁ _ b₂ _ hne
      exact hsp.2.2.2.2.2.2.2.2.1 b₁ b₂ hne
    have hbi_sub : (Finset.univ : Finset (Fin pkg.k_blk)).biUnion B_set ⊆ P₀ := by
      intro lt hlt
      rcases Finset.mem_biUnion.mp hlt with ⟨b, _, hb_mem⟩
      exact (hsp.2.2.2.2.2.2.2.2.2 b).1 hb_mem
    calc pkg.k_blk * s₀_d
      _ = ∑ b : Fin pkg.k_blk, (B_set b).card := by
          simp [B_set, hsp.2.2.2.2.2.2.2.1]
      _ = ((Finset.univ : Finset (Fin pkg.k_blk)).biUnion B_set).card :=
          (Finset.card_biUnion hdisj_pw).symm
      _ ≤ P₀.card := Finset.card_le_card hbi_sub
  have hblt_inj : Function.Injective2 pkg.blocks := by
    intro b₁ b₂ t₁ t₂ heq
    by_cases hbb : b₁ = b₂
    · subst hbb
      refine ⟨rfl, ?_⟩
      have hcard_b : (Finset.univ.image (pkg.blocks b₁)).card = (Finset.univ : Finset (Fin s₀_d)).card := by
        simpa using hsp.2.2.2.2.2.2.2.1 b₁
      have hinj_b := Finset.card_image_iff.mp hcard_b
      exact hinj_b (Finset.mem_coe.mpr (Finset.mem_univ t₁)) (Finset.mem_coe.mpr (Finset.mem_univ t₂)) heq
    · exfalso
      have hdisj := hsp.2.2.2.2.2.2.2.2.1 b₁ b₂ hbb
      have hm1 : pkg.blocks b₁ t₁ ∈ Finset.univ.image (pkg.blocks b₁) := Finset.mem_image_of_mem _ (Finset.mem_univ _)
      have hm2 : pkg.blocks b₁ t₁ ∈ Finset.univ.image (pkg.blocks b₂) := by
        rw [heq]; exact Finset.mem_image_of_mem _ (Finset.mem_univ _)
      exact Finset.disjoint_left.mp hdisj hm1 hm2
  refine
    { m_ge := hm_ge
      run_eq := hrun
      work_eq := rfl
      peak_cell := hsp.1
      peak_bit := hsp.2.1
      node_o := rfl
      node_s := rfl
      node_V := rfl
      centerpoint := hcp
      V_num_eq := rfl
      V_den_eq := rfl
      k_read := hsp.2.2.1
      k_bounds := ⟨hk_pos, hk_mul_le⟩
      k_ratio := hsp.2.2.2.2.2.2.1
      o_spec := fun c => hsp.2.2.2.1 c
      s_spec := hsp.2.2.2.2.1
      blk_spec := fun b t => by
        obtain ⟨idx, hr2, hblk_eq⟩ := hsp.2.2.2.2.2.1 b t
        have hmem_P0 : pkg.blocks b t ∈ P₀ := hblk_eq ▸ (enum idx).2
        exact ⟨idx, hr2, hblk_eq, hmem_P0, rfl⟩
      blt_inj := hblt_inj
      certs_spec := fun b => by
        have hc := hsp.2.2.2.2.2.2.2.2.2 b
        refine ⟨hc.1, hc.2.1, hc.2.2.1, ?_⟩
        change (∑ lt ∈ Finset.univ.image (pkg.blocks b),
          (∑ t : Fin s₀_d, if pkg.blocks b t = lt then (pkg.lam b t : ℝ) else 0) •
            paraboloidLift (ltCoords lt)) =
          liftedPoint (ratPointToEuclidean pkg.oRat) (pkg.sRat : ℝ)
        rw [← hc.2.2.2]
        refine Finset.sum_congr rfl (fun lt hlt => ?_)
        dsimp only [ptsSub]
        rw [hrat_eq lt (hc.1 hlt)] }

private noncomputable def c12FallbackBuiltNode (d s₀_d : ℕ) (P₀ : Finset ℕ)
    (outA2 : BitRAMExecOutcome) : SyncBuiltNode d (PosDimNodeData d s₀_d) :=
  { node := { o := 0, V := 0, V_nonneg := le_rfl }
    s := 0
    aux :=
      { k_blk := 0
        oRat := fun _ => 0
        sRat := 0
        V_num := 0
        V_den := 1
        birthHandles := fun b => b.elim0
        birthLifetimes := fun b => b.elim0
        lam := fun b => b.elim0 }
    work := outA2.bitCost + outA2.unitCost + P₀.card }

/-- Master theorem constructing the handle-ordered `SyncCertifiedNodeConstructor` for `PosDimNodeData`
from `S_lem_A_2` and `S_claim_A_2_deletion_witness`, with `L_leaf = 2 * s₀ d - 1` and
`α = 1 / (4 * s₀ d)`. -/
theorem c12_build_syncCtorA2
    (h_lem_A_2 : S_lem_A_2)
    (h_claim_A_2 : S_claim_A_2_deletion_witness) :
    ∃ (s₀ : ℕ → ℕ) (progA2 : BitRAMStmt)
      (timeA2 spaceA2 bitLenA2 : ℕ → ℕ → ℝ),
      (∀ d : ℕ, 1 ≤ s₀ d) ∧
      IsBoundedByPoly1 (fun d => (s₀ d : ℝ)) ∧
      IsBoundedByPoly2 timeA2 ∧ (∀ d B : ℕ, 1 ≤ timeA2 d B) ∧
      IsBoundedByPoly2 spaceA2 ∧ (∀ d B : ℕ, 1 ≤ spaceA2 d B) ∧
      IsBoundedByPoly2 bitLenA2 ∧ (∀ d B : ℕ, 1 ≤ bitLenA2 d B) ∧
      let P_node : ℕ → ℕ → ℕ → ℝ :=
        fun d B L => 2 * (((L : ℝ) + 1) ^ 2) * timeA2 d B + 2
      IsBoundedByPoly3 P_node ∧
      (∀ d B L : ℕ, 0 ≤ P_node d B L) ∧
      ∀ (d B n : ℕ), 1 ≤ d → 1 ≤ B → 2 ≤ n →
        ∃ ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d (s₀ d)),
          IsValidSyncNodeConstructor n (2 * s₀ d - 1) (1 / (4 * (s₀ d : ℝ))) 1
            (P_node d B (Nat.clog 2 (2 * n))) (RatAdmissiblePointSet d B) ctor ∧
          (∀ (hist : ExecutionHistory d)
            (sufPref : List (SyncSuffixPrefixEntry d (PosDimNodeData d (s₀ d))))
            (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
            (P₀ : Finset ℕ) (bs : List Bool)
            (built : SyncBuiltNode d (PosDimNodeData d (s₀ d))),
            2 * s₀ d ≤ P₀.card →
            (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) →
            ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
              ∃ outA2 : BitRAMExecOutcome,
                C12CertifiedNodeSpec (s₀ d) B progA2 spaceA2 bitLenA2
                  (c12ReplayHistory d hist) ltCoords P₀ bs built outA2) := by
  classical
  obtain ⟨s₀, progA2, tA2_raw, spA2_raw, blA2_raw, hs₀_pos, hs₀_poly,
    ⟨Ct, degT, hCt, ht_bnd⟩, ⟨Cs, degS, hCs, hs_bnd⟩, ⟨Cb, degB, hCb, hb_bnd⟩, hA2⟩ := h_lem_A_2
  let timeA2 : ℕ → ℕ → ℝ := fun d B => Ct * ((d + 1 : ℝ) ^ degT) * ((B + 1 : ℝ) ^ degT) + 1
  let spaceA2 : ℕ → ℕ → ℝ := fun d B => Cs * ((d + 1 : ℝ) ^ degS) * ((B + 1 : ℝ) ^ degS) + 1
  let bitLenA2 : ℕ → ℕ → ℝ := fun d B => Cb * ((d + 1 : ℝ) ^ degB) * ((B + 1 : ℝ) ^ degB) + 1
  have htime_ge1 : ∀ d B, 1 ≤ timeA2 d B := fun d B => by
    have : 0 ≤ Ct * ((d + 1 : ℝ) ^ degT) * ((B + 1 : ℝ) ^ degT) := by positivity
    dsimp [timeA2]; linarith
  have hspace_ge1 : ∀ d B, 1 ≤ spaceA2 d B := fun d B => by
    have : 0 ≤ Cs * ((d + 1 : ℝ) ^ degS) * ((B + 1 : ℝ) ^ degS) := by positivity
    dsimp [spaceA2]; linarith
  have hbl_ge1 : ∀ d B, 1 ≤ bitLenA2 d B := fun d B => by
    have : 0 ≤ Cb * ((d + 1 : ℝ) ^ degB) * ((B + 1 : ℝ) ^ degB) := by positivity
    dsimp [bitLenA2]; linarith
  have htime_dom : ∀ d B, tA2_raw d B ≤ timeA2 d B := fun d B => (ht_bnd d B).trans (by dsimp [timeA2]; linarith)
  have hspace_dom : ∀ d B, spA2_raw d B ≤ spaceA2 d B := fun d B => (hs_bnd d B).trans (by dsimp [spaceA2]; linarith)
  have hbl_dom : ∀ d B, blA2_raw d B ≤ bitLenA2 d B := fun d B => (hb_bnd d B).trans (by dsimp [bitLenA2]; linarith)
  have hpoly2_add1 : ∀ (C : ℝ) (deg : ℕ), 0 ≤ C →
      IsBoundedByPoly2 (fun d B => C * ((d + 1 : ℝ) ^ deg) * ((B + 1 : ℝ) ^ deg) + 1) := by
    intro C deg hC
    refine ⟨C + 1, deg, by linarith, fun d B => ?_⟩
    have hd1 : (1 : ℝ) ≤ (d + 1 : ℝ) ^ deg := one_le_pow₀ (by linarith)
    have hB1 : (1 : ℝ) ≤ (B + 1 : ℝ) ^ deg := one_le_pow₀ (by linarith)
    have h1 : (1 : ℝ) ≤ ((d + 1 : ℝ) ^ deg) * ((B + 1 : ℝ) ^ deg) := by nlinarith
    nlinarith
  let P_node : ℕ → ℕ → ℕ → ℝ := fun d B L => 2 * (((L : ℝ) + 1) ^ 2) * timeA2 d B + 2
  have hP_node_poly : IsBoundedByPoly3 P_node := by
    refine ⟨2 * (Ct + 1) + 2, degT + 2, by positivity, fun d B L => ?_⟩
    have hd_pow : ((d + 1 : ℝ) ^ degT) ≤ ((d + 1 : ℝ) ^ (degT + 2)) :=
      pow_le_pow_right₀ (by linarith) (by omega)
    have hB_pow : ((B + 1 : ℝ) ^ degT) ≤ ((B + 1 : ℝ) ^ (degT + 2)) :=
      pow_le_pow_right₀ (by linarith) (by omega)
    have hL_pow : (((L : ℝ) + 1) ^ 2) ≤ (((L + 1 : ℝ) ^ (degT + 2))) := by
      push_cast; exact pow_le_pow_right₀ (by linarith) (by omega)
    have hd1 : (1 : ℝ) ≤ (d + 1 : ℝ) ^ (degT + 2) := one_le_pow₀ (by linarith)
    have hB1 : (1 : ℝ) ≤ (B + 1 : ℝ) ^ (degT + 2) := one_le_pow₀ (by linarith)
    have hL1 : (1 : ℝ) ≤ (L + 1 : ℝ) ^ (degT + 2) := one_le_pow₀ (by linarith)
    have ht_le : timeA2 d B ≤ (Ct + 1) * ((d + 1 : ℝ) ^ (degT + 2)) * ((B + 1 : ℝ) ^ (degT + 2)) := by
      dsimp [timeA2]
      have hprod1 : Ct * ((d + 1 : ℝ) ^ degT) * ((B + 1 : ℝ) ^ degT) ≤
          Ct * ((d + 1 : ℝ) ^ (degT + 2)) * ((B + 1 : ℝ) ^ (degT + 2)) := by
        have hm := mul_le_mul hd_pow hB_pow (by positivity) (by positivity)
        have := mul_le_mul_of_nonneg_left hm hCt
        linarith
      have hprod2 : (1 : ℝ) ≤ ((d + 1 : ℝ) ^ (degT + 2)) * ((B + 1 : ℝ) ^ (degT + 2)) := by nlinarith
      nlinarith
    dsimp [P_node]
    have hm1 := mul_le_mul hL_pow ht_le (by linarith [htime_ge1 d B]) (by positivity)
    have hm2 : (1 : ℝ) ≤ ((d + 1 : ℝ) ^ (degT + 2)) * ((B + 1 : ℝ) ^ (degT + 2)) * ((L + 1 : ℝ) ^ (degT + 2)) := by
      have : (1 : ℝ) ≤ ((d + 1 : ℝ) ^ (degT + 2)) * ((B + 1 : ℝ) ^ (degT + 2)) := by nlinarith
      nlinarith
    nlinarith
  have hP_node_nn : ∀ d B L : ℕ, 0 ≤ P_node d B L := fun d B L => by
    dsimp [P_node]; have := htime_ge1 d B; positivity
  refine ⟨s₀, progA2, timeA2, spaceA2, bitLenA2, hs₀_pos, hs₀_poly,
    hpoly2_add1 Ct degT hCt, htime_ge1,
    hpoly2_add1 Cs degS hCs, hspace_ge1,
    hpoly2_add1 Cb degB hCb, hbl_ge1,
    hP_node_poly, hP_node_nn, ?_⟩
  intro d B n hd1 hB1 hn
  have extractPkg : ∀ (P_prev : DynamicPointSet d)
      (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ℕ) (bs : List Bool)
      (outA2 : BitRAMExecOutcome),
      2 * s₀ d ≤ P₀.card →
      (∀ i ∈ P₀, RatPointBitBounded B (c12EuclideanToRat (ltCoords i))) →
      runBitRAMWithBits progA2 (c12MkA2Input B P_prev ltCoords P₀) WordStore.empty bs = some outA2 →
      ∃ pkg : C12A2CertPkg d (s₀ d),
        C12A2PkgGood (B := B) spaceA2 bitLenA2
          (fun lt => c12EuclideanToRat (ltCoords lt)) P₀
          (c12EnumByKey (c12LtHandleAfter P_prev) P₀) outA2 pkg := by
    intro P_prev ltCoords P₀ bs outA2 hm_ge hrat_bnd hrun
    have hspA2 := (hA2 d B hB1 ℕ (fun lt => c12EuclideanToRat (ltCoords lt)) P₀
      (c12EnumByKey (c12LtHandleAfter P_prev) P₀) hm_ge hrat_bnd).2.2.2.2.2 bs outA2 hrun
    obtain ⟨hpc, hpb, k_blk, oRat, sRat, blocks, lam, hk0, ho, hs, hblk, hk_lo, hcard_b, hdisj_b, hcerts⟩ := hspA2
    refine ⟨⟨k_blk, oRat, sRat, blocks, lam⟩, ?_, ?_, hk0, ?_, ?_, ?_, hk_lo, hcard_b, hdisj_b, fun b => (hcerts b).2⟩
    · exact hpc.trans (mul_le_mul_of_nonneg_left (hspace_dom d B) (Nat.cast_nonneg _))
    · exact hpb.trans (mul_le_mul_of_nonneg_left (hspace_dom d B) (by positivity))
    · intro c; obtain ⟨h1, h2, h3, h4, _⟩ := ho c
      exact ⟨h1, h2, h3.trans (hbl_dom d B), h4.trans (hbl_dom d B)⟩
    · obtain ⟨h1, h2, h3, h4, _⟩ := hs
      exact ⟨h1, h2, h3.trans (hbl_dom d B), h4.trans (hbl_dom d B)⟩
    · exact fun b t => (hblk b t).1
  let buildOne : ExecutionHistory d → (ℕ → EuclideanSpace ℝ (Fin d)) → Finset ℕ →
      List Bool → BitRAMExecOutcome → SyncBuiltNode d (PosDimNodeData d (s₀ d)) :=
    fun hist ltCoords P₀ bs outA2 =>
      let P_prev := c12ReplayHistory d hist
      if hgood :
          runBitRAMWithBits progA2 (c12MkA2Input B P_prev ltCoords P₀) WordStore.empty bs = some outA2 ∧
          2 * s₀ d ≤ P₀.card ∧
          (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) then
        have hrat_bnd : ∀ i ∈ P₀, RatPointBitBounded B (c12EuclideanToRat (ltCoords i)) :=
          fun i hi => (c12EuclideanToRat_spec (hgood.2.2 i hi)).2
        c12MkBuiltNodeFromHex h_claim_A_2 hd1 (hs₀_pos d) spaceA2 bitLenA2 P_prev
          (fun lt => c12EuclideanToRat (ltCoords lt)) P₀
          (c12EnumByKey (c12LtHandleAfter P_prev) P₀) outA2 hgood.2.1
          (extractPkg P_prev ltCoords P₀ bs outA2 hgood.2.1 hrat_bnd hgood.1)
      else
        c12FallbackBuiltNode d (s₀ d) P₀ outA2
  let ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d (s₀ d)) :=
    { buildWithBits := fun hist _sufPref ltCoords P₀ bs =>
        (runBitRAMWithBits progA2 (c12MkA2Input B (c12ReplayHistory d hist) ltCoords P₀) WordStore.empty bs).map
          (buildOne hist ltCoords P₀ bs) }
  have hcert_of_some : ∀ hist sufPref ltCoords P₀ bs built,
      2 * s₀ d ≤ P₀.card →
      (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
        ∃ outA2 : BitRAMExecOutcome,
          C12CertifiedNodeSpec (s₀ d) B progA2 spaceA2 bitLenA2
            (c12ReplayHistory d hist) ltCoords P₀ bs built outA2 := by
    intro hist sufPref ltCoords P₀ bs built hm_ge hadm hsome
    dsimp only [ctor] at hsome
    rcases Option.map_eq_some_iff.mp hsome with ⟨outA2, hrun, rfl⟩
    have hgood :
        runBitRAMWithBits progA2 (c12MkA2Input B (c12ReplayHistory d hist) ltCoords P₀) WordStore.empty bs = some outA2 ∧
        2 * s₀ d ≤ P₀.card ∧
        (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) := ⟨hrun, hm_ge, hadm⟩
    have hbuild_eq : buildOne hist ltCoords P₀ bs outA2 =
        c12MkBuiltNodeFromHex h_claim_A_2 hd1 (hs₀_pos d) spaceA2 bitLenA2
          (c12ReplayHistory d hist) (fun lt => c12EuclideanToRat (ltCoords lt)) P₀
          (c12EnumByKey (c12LtHandleAfter (c12ReplayHistory d hist)) P₀) outA2 hm_ge
          (extractPkg _ ltCoords P₀ bs outA2 hm_ge (fun i hi => (c12EuclideanToRat_spec (hadm i hi)).2) hrun) :=
      dif_pos hgood
    refine ⟨outA2, ?_⟩
    rw [hbuild_eq]
    exact c12MkBuiltNodeFromHex_spec h_claim_A_2 hd1 (hs₀_pos d) progA2 spaceA2 bitLenA2
      (c12ReplayHistory d hist) ltCoords P₀ bs outA2 hm_ge
      (fun i hi => (c12EuclideanToRat_spec (hadm i hi)).1) hrun _
  refine ⟨ctor, ?_, hcert_of_some⟩
  intro hist sufPref ltCoords P₀ hm_gt hm_le hadm
  have hs₀1 : 1 ≤ s₀ d := hs₀_pos d
  have hm_ge : 2 * s₀ d ≤ P₀.card := by omega
  have hrat_bnd : ∀ i ∈ P₀, RatPointBitBounded B (c12EuclideanToRat (ltCoords i)) :=
    fun i hi => (c12EuclideanToRat_spec (hadm i hi)).2
  let inpA2 := c12MkA2Input B (c12ReplayHistory d hist) ltCoords P₀
  obtain ⟨hhaltA2, hexpUA2_fin, hexpUA2_le, hexpBA2_fin, hexpBA2_le, _⟩ :=
    hA2 d B hB1 ℕ (fun lt => c12EuclideanToRat (ltCoords lt)) P₀
      (c12EnumByKey (c12LtHandleAfter (c12ReplayHistory d hist)) P₀) hm_ge hrat_bnd
  change (∑' bs : List Bool,
    if (runBitRAMWithBits progA2 inpA2 WordStore.empty bs).isSome then bitListProb bs else 0) = 1 at hhaltA2
  let fB : List Bool → ENNReal := fun bs =>
    match runBitRAMWithBits progA2 inpA2 WordStore.empty bs with
    | some outA2 => bitListProb bs * (outA2.bitCost : ENNReal)
    | none => 0
  let fU : List Bool → ENNReal := fun bs =>
    match runBitRAMWithBits progA2 inpA2 WordStore.empty bs with
    | some outA2 => bitListProb bs * (outA2.unitCost : ENNReal)
    | none => 0
  change (∑' bs : List Bool, fU bs) ≠ ⊤ at hexpUA2_fin
  change (∑' bs : List Bool, fU bs).toReal ≤
    (P₀.card : ℝ) * tA2_raw d B at hexpUA2_le
  change (∑' bs : List Bool, fB bs) ≠ ⊤ at hexpBA2_fin
  change (∑' bs : List Bool, fB bs).toReal ≤
    (P₀.card : ℝ) * ((Nat.clog 2 (2 * P₀.card) : ℝ) ^ 2) * tA2_raw d B at hexpBA2_le
  have hisSome_eq : ∀ bs,
      (ctor.buildWithBits hist sufPref ltCoords P₀ bs).isSome =
        (runBitRAMWithBits progA2 inpA2 WordStore.empty bs).isSome := by
    intro bs; dsimp only [ctor, inpA2]; simp
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
    dsimp only [ctor] at h₁ h₂
    rcases Option.map_eq_some_iff.mp h₁ with ⟨o₁, ho₁, _⟩
    rcases Option.map_eq_some_iff.mp h₂ with ⟨o₂, ho₂, _⟩
    exact runBitRAMWithBits_prefix_free progA2 _ WordStore.empty ho₁ ho₂ hpref
  · simp_rw [hisSome_eq]
    exact hhaltA2
  · intro bs out hsome
    obtain ⟨_, hcert⟩ := hcert_of_some hist sufPref ltCoords P₀ bs out hm_ge hadm hsome
    exact ⟨hcert.node_V, hcert.centerpoint⟩
  · dsimp only
    let m := P₀.card
    let L := Nat.clog 2 (2 * n)
    let fM : List Bool → ENNReal := fun bs =>
      if (runBitRAMWithBits progA2 inpA2 WordStore.empty bs).isSome then
        bitListProb bs * (m : ENNReal)
      else 0
    have hsM_eq : (∑' bs : List Bool, fM bs) = (m : ENNReal) := by
      have hpull : fM = fun bs =>
          (if (runBitRAMWithBits progA2 inpA2 WordStore.empty bs).isSome then bitListProb bs else 0) * (m : ENNReal) := by
        ext bs; dsimp only [fM]; split_ifs <;> simp
      rw [hpull, ENNReal.tsum_mul_right, hhaltA2, one_mul]
    set sBU : ENNReal := (∑' bs : List Bool, fB bs) + (∑' bs : List Bool, fU bs)
    set sM : ENNReal := ∑' bs : List Bool, fM bs
    suffices hgoal : (sBU + sM) ≠ ⊤ ∧
        (sBU + sM).toReal ≤ (P₀.card : ℝ) * 1 * P_node d B L by
      have heq_sum : ∀ (g : List Bool → ENNReal),
          (∀ bs, g bs = (fB bs + fU bs) + fM bs) →
          (∑' bs, g bs) = sBU + sM := by
        intro g hg
        simp_rw [hg]
        rw [ENNReal.tsum_add, ENNReal.tsum_add]
      refine Eq.ndrec
        (motive := fun x => x ≠ ⊤ ∧ x.toReal ≤ (P₀.card : ℝ) * 1 * P_node d B L)
        hgoal
        (heq_sum _ (fun bs => ?_)).symm
      dsimp only [ctor, fB, fU, fM, inpA2, m]
      cases hrun : runBitRAMWithBits progA2 (c12MkA2Input B (c12ReplayHistory d hist) ltCoords P₀) WordStore.empty bs with
      | none => simp
      | some outA2 =>
          have hwk : (buildOne hist ltCoords P₀ bs outA2).work = outA2.bitCost + outA2.unitCost + P₀.card := by
            dsimp only [buildOne]
            split_ifs <;> rfl
          simp only [Option.map_some, Option.isSome_some, ↓reduceIte, hwk, Nat.cast_add, mul_add]
    rw [hsM_eq]
    have hsBU_fin : sBU ≠ ⊤ := ENNReal.add_ne_top.mpr ⟨hexpBA2_fin, hexpUA2_fin⟩
    have hm_fin : (m : ENNReal) ≠ ⊤ := ENNReal.natCast_ne_top m
    refine ⟨ENNReal.add_ne_top.mpr ⟨hsBU_fin, hm_fin⟩, ?_⟩
    rw [ENNReal.toReal_add hsBU_fin hm_fin, ENNReal.toReal_add hexpBA2_fin hexpUA2_fin, ENNReal.toReal_natCast]
    have hw_le_L : (Nat.clog 2 (2 * m) : ℝ) ≤ (L : ℝ) + 1 := by
      have hclog_le : Nat.clog 2 (2 * m) ≤ L := Nat.clog_mono_right 2 (by omega)
      have : (Nat.clog 2 (2 * m) : ℝ) ≤ (L : ℝ) := by exact_mod_cast hclog_le
      linarith
    have hw_ge0 : (0 : ℝ) ≤ (Nat.clog 2 (2 * m) : ℝ) := Nat.cast_nonneg _
    have hL1_ge1 : (1 : ℝ) ≤ (L : ℝ) + 1 := by linarith [show (0 : ℝ) ≤ (L : ℝ) from Nat.cast_nonneg L]
    have hsq_le : ((Nat.clog 2 (2 * m) : ℝ) ^ 2) ≤ ((L : ℝ) + 1) ^ 2 :=
      pow_le_pow_left₀ hw_ge0 hw_le_L 2
    have hL1_sq_ge1 : (1 : ℝ) ≤ ((L : ℝ) + 1) ^ 2 := by nlinarith [hL1_ge1]
    have ht_dom := htime_dom d B
    have ht_nn : 0 ≤ timeA2 d B := by linarith [htime_ge1 d B]
    have hm_pos : (1 : ℝ) ≤ (m : ℝ) := by
      have : 1 ≤ m := by dsimp [m]; omega
      exact_mod_cast this
    have hb_bound : (∑' bs : List Bool, fB bs).toReal ≤ (m : ℝ) * (((L : ℝ) + 1) ^ 2) * timeA2 d B := by
      have h2 : (m : ℝ) * ((Nat.clog 2 (2 * m) : ℝ) ^ 2) * tA2_raw d B ≤
          (m : ℝ) * ((Nat.clog 2 (2 * m) : ℝ) ^ 2) * timeA2 d B :=
        mul_le_mul_of_nonneg_left ht_dom (by positivity)
      have h3 : (m : ℝ) * ((Nat.clog 2 (2 * m) : ℝ) ^ 2) * timeA2 d B ≤
          (m : ℝ) * (((L : ℝ) + 1) ^ 2) * timeA2 d B :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hsq_le (by positivity)) ht_nn
      linarith [hexpBA2_le]
    have hu_bound : (∑' bs : List Bool, fU bs).toReal ≤ (m : ℝ) * (((L : ℝ) + 1) ^ 2) * timeA2 d B := by
      have h2 : (m : ℝ) * tA2_raw d B ≤ (m : ℝ) * timeA2 d B :=
        mul_le_mul_of_nonneg_left ht_dom (by positivity)
      have h3 : (m : ℝ) * timeA2 d B ≤
          (m : ℝ) * (((L : ℝ) + 1) ^ 2) * timeA2 d B := by
        simpa using mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hL1_sq_ge1 (by positivity)) ht_nn
      linarith [hexpUA2_le]
    dsimp only [P_node, m, L] at hb_bound hu_bound ⊢
    nlinarith

end UL.C12LVE
