import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG08_StepDB2
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 4. Full Step D Program (`posDimStepD`) and `ChainStoredInv`-Preserving Execution -/

/-- Step D `BitRAM` statement for positive dimension `d ≥ 1`:
reads `|P.activeHandles|` from active-handle winner tree `tid = 0`; if `< 2`, clears the answer
header `heap 0 1..5`; otherwise initializes `heap 0 1..5` to `twoMinHandles P.activeHandles`,
scans all active chain levels (`scanAllLevelsRegs`), and scans all leaf pairs (`scanLeafPairsRegs`). -/
def posDimStepD (d s₀_d L : ℕ) : BitRAMStmt :=
  .seq (rLit 0 0)
  (.seq (treeReadRootRegs L)
  (.seq (rLit 14 2)
        (.ite (.intLt (.readLocal 1 (.lit 0)) (.readLocal 14 (.lit 0)))
          clearAnsHeaderRegs
          (.seq (initBestPairRegs d L)
          (.seq (scanAllLevelsRegs d s₀_d L)
                (scanLeafPairsRegs d L))))))

/-- Polynomial unit-cost bound for `posDimStepD d s₀_d L` at chain length `k = nodes.length`. -/
def stepDUnitCost (d s₀_d L k : ℕ) : ℕ :=
  (k + 1) * (s₀_d * (220 * d + 200) + 64 * L + 380) +
  (4 * s₀_d + 1) * (4 * s₀_d + 1) * (220 * d + 320) +
  (4 * s₀_d + 1) * (880 * L + 800) +
  900 * L + 250 * d + 900

/-- Polynomial bit-cost bound for `posDimStepD d s₀_d L` at word bound `W` and chain length `k`. -/
def stepDBitCost (d s₀_d L W k : ℕ) : ℕ :=
  ((k + 1) * (s₀_d * (52 * d + 48) + 12 * L + 68) +
   (4 * s₀_d + 1) * (4 * s₀_d + 1) * (52 * d + 64) +
   (4 * s₀_d + 1) * (140 * L + 240) +
   150 * L + 60 * d + 320) * W * W

private theorem not_isBestPairLoc_of_not_isAnsHeaderLoc {loc : RAMCellLoc}
    (h : ¬ isAnsHeaderLoc loc) : ¬ isBestPairLoc loc :=
  fun hbp => h (Or.inr hbp)

/-- Frame lemma: if `wsD` preserves `TreeStoredAt` on `tid = 0` and `tid = 1`, stays in
`ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W`, and agrees with `ws`
outside `isAnsHeaderLoc`, `treeSliceLocs L 0`, and `treeSliceLocs L 1`, then `wsD`
preserves the full `ChainStoredInv` and `wsD.read (.heap 0 0) = ws.read (.heap 0 0)`. -/
private theorem chainStoredInv_preserve_stepD {d s₀_d n L B B_cert K_max W : ℕ}
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {ws wsD : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws)
    (hmD : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsD)
    (htree0 : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) wsD)
    (htree1 :
      let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
      let S_k_lt := chainInput ltCoords vecNodes (activeLifetimes P) (Fin.last nodes.length)
      TreeStoredAt L 1 (S_k_lt.image (handleOfLifetime P)) (fun _ => 0) (fun _ => 1) wsD)
    (hunch : ∀ loc : RAMCellLoc,
      ¬ isAnsHeaderLoc loc → loc ∉ treeSliceLocs L 0 → loc ∉ treeSliceLocs L 1 →
        (loc ∈ wsD.live ↔ loc ∈ ws.live) ∧ wsD.vals loc = ws.vals loc) :
    ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap wsD ∧
    wsD.read (.heap 0 0) = ws.read (.heap 0 0) := by
  have hr0 : wsD.read (.heap 0 0) = ws.read (.heap 0 0) := by
    rw [wordStore_read_eq_vals hmD.wf,
        (hunch (.heap 0 0) (by rintro (h | h | h | h | h) <;> cases h)
          (not_in_treeSlice_of_table_ne (by decide) _)
          (not_in_treeSlice_of_table_ne (by decide) _)).2,
        ← wordStore_read_eq_vals hinv.mod.wf]
  refine ⟨?_, hr0⟩
  refine
    { wfP := hinv.wfP
      mod := hmD
      hk_le := hinv.hk_le
      read_k := ?_
      hlt_sync := hinv.hlt_sync
      hlt_adm := hinv.hlt_adm
      coords_stored := ?_
      tree_active := htree0
      hbirth_avoid := hinv.hbirth_avoid
      levels := ?_
      empty_levels := ?_
      tree_leaf := ⟨hinv.tree_leaf.1, htree1⟩
      stage_clean := ?_ }
  · rw [wordStore_read_eq_vals hmD.wf,
        (hunch (.heap 0 10) (by rintro (h | h | h | h | h) <;> cases h)
          (not_in_treeSlice_of_table_ne (by decide) _)
          (not_in_treeSlice_of_table_ne (by decide) _)).2,
        ← wordStore_read_eq_vals hinv.mod.wf]
    exact hinv.read_k
  · exact hinv.coords_stored.unchanged (fun h' _ c _ f _ => by
      rw [wordStore_read_eq_vals hmD.wf,
          (hunch (.heap 1 (coordCellAddr d h' c f)) (by rintro (h | h | h | h | h) <;> cases h)
            (not_in_treeSlice_of_table_ne (by decide) _)
            (not_in_treeSlice_of_table_ne (by decide) _)).2,
          ← wordStore_read_eq_vals hinv.mod.wf])
  · intro j hj
    exact (hinv.levels j hj).unchanged hinv.mod.wf hmD.wf
      (fun off _ => hunch _ (by rintro (h | h | h | h | h) <;> cases h)
        (not_in_treeSlice_of_table_ne (by decide) _)
        (not_in_treeSlice_of_table_ne (by decide) _))
      (fun h' _ => hunch _ (by rintro (h | h | h | h | h) <;> cases h)
        (not_in_treeSlice_of_table_ne (by decide) _)
        (not_in_treeSlice_of_table_ne (by decide) _))
      (fun u hu f hf => hunch _ (by rintro (h | h | h | h | h) <;> cases h)
        (not_in_treeSlice_of_tid_ne hu hf (by omega))
        (not_in_treeSlice_of_tid_ne hu hf (by omega)))
      (fun u hu f hf => hunch _ (by rintro (h | h | h | h | h) <;> cases h)
        (not_in_treeSlice_of_tid_ne hu hf (by omega))
        (not_in_treeSlice_of_tid_ne hu hf (by omega)))
  · intro j hj1 hj2
    exact (hinv.empty_levels j hj1 hj2).unchanged
      (fun off _ hm => (hunch (.heap 3 (nodeCellAddr (posNodeStride d L) j off))
        (by rintro (h | h | h | h | h) <;> cases h)
        (not_in_treeSlice_of_table_ne (by decide) _)
        (not_in_treeSlice_of_table_ne (by decide) _)).1.mp hm)
      (fun h' _ hm => (hunch (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)))
        (by rintro (h | h | h | h | h) <;> cases h)
        (not_in_treeSlice_of_table_ne (by decide) _)
        (not_in_treeSlice_of_table_ne (by decide) _)).1.mp hm)
      (fun u hu f hf hm => (hunch (.heap 2 (treeCellAddr L (2 * j + 2) u f))
        (by rintro (h | h | h | h | h) <;> cases h)
        (not_in_treeSlice_of_tid_ne hu hf (by omega))
        (not_in_treeSlice_of_tid_ne hu hf (by omega))).1.mp hm)
      (fun u hu f hf hm => (hunch (.heap 2 (treeCellAddr L (2 * j + 3) u f))
        (by rintro (h | h | h | h | h) <;> cases h)
        (not_in_treeSlice_of_tid_ne hu hf (by omega))
        (not_in_treeSlice_of_tid_ne hu hf (by omega))).1.mp hm)
  · intro t ht z hm
    have hna : ¬ isAnsHeaderLoc (.heap t z) := by
      rcases ht with rfl | rfl | rfl | rfl | rfl <;>
        rintro (h | h | h | h | h) <;> cases h
    have hnt : t ≠ 2 := by
      rcases ht with rfl | rfl | rfl | rfl | rfl <;> decide
    exact hinv.stage_clean t ht z
      ((hunch (.heap t z) hna
        (not_in_treeSlice_of_table_ne hnt z)
        (not_in_treeSlice_of_table_ne hnt z)).1.mp hm)

/-- Main `RegExec` correctness theorem for Step D (`posDimStepD`):
starting from any state satisfying `ChainStoredInv`, executes `posDimStepD d s₀_d L` in
polynomial unit and bit cost, preserves `ChainStoredInv` and `heap 0 0` (allocated handle slot),
and writes `((ramCheckedAnswer L P nodes).diameterHandles, (ramCheckedAnswer L P nodes).cachedDistSq)`
into the cached-answer cells `heap 0 1..5`. -/
theorem exec_posDimStepD {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n)) (hB1 : 1 ≤ B)
    (hW : 2 * sqRadBitBound d B B_cert + d * (8 * B + 24) +
          natBitLength ((K_max + 2) * posNodeStride d L) +
          natBitLength s₀_d + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsD regsD,
      RegExec inp fd W C_cell C_bit (posDimStepD d s₀_d L) ws regs wsD regsD
        (stepDUnitCost d s₀_d L nodes.length)
        (stepDBitCost d s₀_d L W nodes.length) ∧
      ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap wsD ∧
      RegBounded W regsD ∧
      BitRAMDynamicProgram.readCachedAnswer wsD =
        ((ramCheckedAnswer L P nodes).diameterHandles, (ramCheckedAnswer L P nodes).cachedDistSq) ∧
      wsD.read (.heap 0 0) = ws.read (.heap 0 0) := by
  have ⟨hL2, _, h2n_pow, _⟩ := clog_two_mul_bounds hn
  have hL1 : 1 ≤ L := by clear * - hL hL2; omega
  have h2n : 2 * n ≤ 2 ^ L := hL ▸ h2n_pow
  have hW32 : 32 ≤ W := by clear * - hW; omega
  have hCeilC : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hCeilB : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  obtain ⟨cs0, bs0⟩ := hinv.mod.space_le
  have spC0 : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell := by linarith only [cs0, hCeilC]
  have spB0 : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit := by linarith only [bs0, hCeilB]
  have hl0 : intBitLength (0 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl2 : intBitLength (2 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  -- Step 1: `rLit 0 0`
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd spC0 spB0 (dst := 0) (c := 0) (by decide) hl0
  set g1 := Function.update regs 0 0
  have bg1 := hbnd.update (r := 0) (by decide) hl0
  -- Step 2: `treeReadRootRegs L` on active-handle tree `tid = 0`
  have hW_root0 : 2 * 2 + natBitLength 0 + L + 16 ≤ W := by
    have hd0 : natBitLength 0 = 1 := by decide
    clear * - hW hd0; omega
  obtain ⟨g2, s2, bg2, _, hg2_1, _, _, _, _⟩ :=
    exec_treeReadRootRegs (inp := inp) (fd := fd) hfd_le spC0 spB0
      (B_r := 2) (by decide) hW_root0 hinv.tree_active
      (fun h hh => ⟨hinv.tree_active.hS h hh, by decide, by decide⟩)
      bg1 (by simp [g1])
  -- Step 3: `rLit 14 2`
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 spC0 spB0 (dst := 14) (c := 2) (by decide) hl2
  set g3 := Function.update g2 14 2
  have bg3 := bg2.update (r := 14) (by decide) hl2
  have hg3_1 : g3 1 = (P.activeHandles.card : ℤ) := by simp [g3, hg2_1]
  have hg3_14 : g3 14 = 2 := by simp [g3]
  -- Common branch cost targets before `iteLt`
  set U_br := (nodes.length + 1) * (s₀_d * (220 * d + 200) + 64 * L + 380) +
    (4 * s₀_d + 1) * (4 * s₀_d + 1) * (220 * d + 320) +
    (4 * s₀_d + 1) * (880 * L + 800) +
    (900 * L + 250 * d + 700)
  set B_br := ((nodes.length + 1) * (s₀_d * (52 * d + 48) + 12 * L + 68) +
    (4 * s₀_d + 1) * (4 * s₀_d + 1) * (52 * d + 64) +
    (4 * s₀_d + 1) * (140 * L + 240) +
    (150 * L + 60 * d + 280)) * W * W
  -- Step 4: Branch on `P.activeHandles.card < 2`
  by_cases hlt2 : P.activeHandles.card < 2
  · have hlt_reg : g3 1 < g3 14 := by rw [hg3_1, hg3_14]; exact_mod_cast hlt2
    obtain ⟨wsD, regsD, bClr, hmD, brD, hreadAns, hunchClr⟩ :=
      exec_clearAnsHeaderRegs_stepD (inp := inp) (fd := fd) hfd_le hinv.mod hCeilC hCeilB
        (by clear * - hW32; omega)
        (fun i _ hi5 => mem_posDimWriteLocs_tab0 (by clear * - hi5; omega))
        bg3
    have hU_clr : 60 ≤ U_br := by dsimp +zetaDelta only [U_br]; clear * -; omega
    have hB_clr : 60 * W ≤ B_br := by
      have h1 : 60 * W ≤ 280 * W * W := by nlinarith only [hW32]
      have h2 : 280 * W * W ≤ B_br := by
        dsimp +zetaDelta only [B_br]
        have hnn : 0 ≤ ((nodes.length + 1) * (s₀_d * (52 * d + 48) + 12 * L + 68) +
          (4 * s₀_d + 1) * (4 * s₀_d + 1) * (52 * d + 64) +
          (4 * s₀_d + 1) * (140 * L + 240) + 150 * L + 60 * d) * W * W := by positivity
        linarith only [hnn]
      exact h1.trans h2
    have bClrW := bClr.weaken rfl rfl hU_clr hB_clr
    have s4 := RegExec.iteLt (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      (wsHeap := ws) (wsOut := wsD) (regsOut := regsD) (U := U_br) (B := B_br)
      (tB := clearAnsHeaderRegs)
      (fB := .seq (initBestPairRegs d L) (.seq (scanAllLevelsRegs d s₀_d L) (scanLeafPairsRegs d L)))
      bg3 (a := 1) (b := 14) (by decide) (by decide) (by rw [if_pos hlt_reg]; exact bClrW)
    have hTot : RegExec inp fd W C_cell C_bit (posDimStepD d s₀_d L) ws regs wsD regsD
        (stepDUnitCost d s₀_d L nodes.length) (stepDBitCost d s₀_d L W nodes.length) := by
      refine (s1.seq (s2.seq (s3.seq s4))).weaken rfl rfl ?_ ?_
      · dsimp +zetaDelta only [U_br, stepDUnitCost]; clear * -; omega
      · have hWW : 16 * W * W + 8 * W + 48 ≤ 40 * W * W := by nlinarith only [hW32]
        have heq : stepDBitCost d s₀_d L W nodes.length = B_br + 40 * W * W := by
          dsimp +zetaDelta only [B_br, stepDBitCost]; ring
        rw [heq]; omega
    have htree0_D : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) wsD :=
      hinv.tree_active.unchanged (fun u _ f _ =>
        hunchClr _ (by rintro (h | h | h | h | h) <;> cases h))
    have htree1_D : TreeStoredAt L 1
        ((chainInput ltCoords (fun i => (nodes.get i).built.node) (activeLifetimes P) (Fin.last nodes.length)).image (handleOfLifetime P))
        (fun _ => 0) (fun _ => 1) wsD :=
      hinv.tree_leaf.2.unchanged (fun u _ f _ =>
        hunchClr _ (by rintro (h | h | h | h | h) <;> cases h))
    obtain ⟨hinvD, hr0D⟩ := chainStoredInv_preserve_stepD hinv hmD htree0_D htree1_D
      (fun loc hna _ _ => hunchClr loc hna)
    have hnot2 : ¬ 2 ≤ P.activeHandles.card := by clear * - hlt2; omega
    have hram_none : ramCheckedAnswer L P nodes = { diameterHandles := none, cachedDistSq := 0 } := by
      simp [ramCheckedAnswer, hnot2]
    exact ⟨wsD, regsD, hTot, hinvD, brD, by rw [hreadAns, hram_none], hr0D⟩
  · have h2 : 2 ≤ P.activeHandles.card := by clear * - hlt2; omega
    have hnlt_reg : ¬ (g3 1 < g3 14) := by rw [hg3_1, hg3_14]; exact_mod_cast hlt2
    have hW_init : d * (4 * B + 12) + natBitLength d + L + 28 ≤ W := by
      have hm : d * (4 * B + 12) ≤ d * (8 * B + 24) := Nat.mul_le_mul_left d (by clear * -; omega)
      clear * - hW hm; omega
    -- Substep 4a: `initBestPairRegs d L`
    obtain ⟨ws1, regs1, bInit, hm1, br1, htree0_1, hbest1, hunch1⟩ :=
      exec_initBestPairRegs hd1 hL1 hB1 hfd_le hinv.mod hCeilC hCeilB hW_init
        hinv.wfP hinv.hlt_sync hinv.coords_stored hinv.tree_active h2
        (fun i _ hi5 => mem_posDimWriteLocs_tab0 (by clear * - hi5; omega))
        (fun u hu f hf => mem_posDimWriteLocs_tree (by clear * -; omega) hu hf)
        (mem_posDimWriteLocs_tab9 (by decide))
        (mem_posDimWriteLocs_tab9 (by decide))
        (hinv.stage_clean 9 (by decide) 100)
        (hinv.stage_clean 9 (by decide) 101)
        bg3
    have hn120_1 : (.heap 9 120 : RAMCellLoc) ∉ ws1.live := by
      rw [(hunch1 (.heap 9 120) (not_in_treeSlice_of_table_ne (by decide) _)
            (by rintro (h | h | h | h | h) <;> cases h)).1]
      exact hinv.stage_clean 9 (by decide) 120
    have hn121_1 : (.heap 9 121 : RAMCellLoc) ∉ ws1.live := by
      rw [(hunch1 (.heap 9 121) (not_in_treeSlice_of_table_ne (by decide) _)
            (by rintro (h | h | h | h | h) <;> cases h)).1]
      exact hinv.stage_clean 9 (by decide) 121
    have hn122_1 : (.heap 9 122 : RAMCellLoc) ∉ ws1.live := by
      rw [(hunch1 (.heap 9 122) (not_in_treeSlice_of_table_ne (by decide) _)
            (by rintro (h | h | h | h | h) <;> cases h)).1]
      exact hinv.stage_clean 9 (by decide) 122
    -- Substep 4b: `scanAllLevelsRegs d s₀_d L`
    obtain ⟨ws2, regs2, bLevels, hm2, br2, hbest2, hunch2⟩ :=
      exec_scanAllLevelsRegs hd1 hL1 h2n hB1 hW hfd_le hinv hm1 hcCeil hbCeil
        hn120_1 hn121_1 hn122_1
        (fun loc hna hnt0 => hunch1 loc hnt0 hna)
        hbest1 br1
    have htree0_2 : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) ws2 :=
      htree0_1.unchanged (fun u _ f _ =>
        hunch2 _ (by rintro (h | h | h | h) <;> cases h))
    have hunchRef2 : ∀ loc : RAMCellLoc, ¬ isAnsHeaderLoc loc → loc ∉ treeSliceLocs L 0 →
        (loc ∈ ws2.live ↔ loc ∈ ws.live) ∧ ws2.vals loc = ws.vals loc := by
      intro loc hna hnt0
      have u2 := hunch2 loc (not_isBestPairLoc_of_not_isAnsHeaderLoc hna)
      have u1 := hunch1 loc hnt0 hna
      exact ⟨u2.1.trans u1.1, u2.2.trans u1.2⟩
    -- Substep 4c: `scanLeafPairsRegs d L`
    have hW_leaf : d * (8 * B + 24) + natBitLength d + L + 32 ≤ W := by clear * - hW; omega
    obtain ⟨wsD, regsD, bLeaf, hmD, brD, htree1_D, hbestD, hunch3⟩ :=
      exec_scanLeafPairsRegs hd1 hL1 hB1 hW_leaf hfd_le hinv hm2 hcCeil hbCeil
        hunchRef2 hbest2 br2
    have htree0_D : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) wsD :=
      htree0_2.unchanged (fun u hu f hf =>
        hunch3 _ (by rintro (h | h | h | h) <;> cases h)
          (not_in_treeSlice_of_tid_ne hu hf (by decide)))
    have hunchAll : ∀ loc : RAMCellLoc,
        ¬ isAnsHeaderLoc loc → loc ∉ treeSliceLocs L 0 → loc ∉ treeSliceLocs L 1 →
          (loc ∈ wsD.live ↔ loc ∈ ws.live) ∧ wsD.vals loc = ws.vals loc := by
      intro loc hna hnt0 hnt1
      have u3 := hunch3 loc (not_isBestPairLoc_of_not_isAnsHeaderLoc hna) hnt1
      have u2 := hunchRef2 loc hna hnt0
      exact ⟨u3.1.trans u2.1, u3.2.trans u2.2⟩
    obtain ⟨hinvD, hr0D⟩ := chainStoredInv_preserve_stepD hinv hmD htree0_D htree1_D hunchAll
    have hbestFull : BestPairStored B P
        (foldBestPairs P (twoMinHandles P.activeHandles h2) (ramScanCandidates L P nodes)) wsD := by
      unfold ramScanCandidates
      rw [foldBestPairs_append]
      exact hbestD
    have hreadAns := readCachedAnswer_of_bestPairStored h2 hbestFull
    have bElseW : RegExec inp fd W C_cell C_bit
        (.seq (initBestPairRegs d L) (.seq (scanAllLevelsRegs d s₀_d L) (scanLeafPairsRegs d L)))
        ws g3 wsD regsD U_br B_br := by
      refine (bInit.seq (bLevels.seq bLeaf)).weaken rfl rfl ?_ ?_
      · dsimp +zetaDelta only [U_br]; clear * -; omega
      · dsimp +zetaDelta only [B_br]; exact le_of_eq (by ring)
    have s4 := RegExec.iteLt (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      (wsHeap := ws) (wsOut := wsD) (regsOut := regsD) (U := U_br) (B := B_br)
      (tB := clearAnsHeaderRegs)
      (fB := .seq (initBestPairRegs d L) (.seq (scanAllLevelsRegs d s₀_d L) (scanLeafPairsRegs d L)))
      bg3 (a := 1) (b := 14) (by decide) (by decide) (by rw [if_neg hnlt_reg]; exact bElseW)
    have hTot : RegExec inp fd W C_cell C_bit (posDimStepD d s₀_d L) ws regs wsD regsD
        (stepDUnitCost d s₀_d L nodes.length) (stepDBitCost d s₀_d L W nodes.length) := by
      refine (s1.seq (s2.seq (s3.seq s4))).weaken rfl rfl ?_ ?_
      · dsimp +zetaDelta only [U_br, stepDUnitCost]; clear * -; omega
      · have hWW : 16 * W * W + 8 * W + 48 ≤ 40 * W * W := by nlinarith only [hW32]
        have heq : stepDBitCost d s₀_d L W nodes.length = B_br + 40 * W * W := by
          dsimp +zetaDelta only [B_br, stepDBitCost]; ring
        rw [heq]; omega
    exact ⟨wsD, regsD, hTot, hinvD, brD, hreadAns, hr0D⟩

/-- Combined Step D execution + √2-approximation validity + `ansPolPosDim` synchronization. -/
theorem exec_posDimStepD_valid
    (h_lem_5_2 : S_lem_5_2) (h_clm_5_1_block_witness : S_clm_5_1_block_witness)
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n)) (hB1 : 1 ≤ B)
    (hW : 2 * sqRadBitBound d B B_cert + d * (8 * B + 24) +
          natBitLength ((K_max + 2) * posNodeStride d L) +
          natBitLength s₀_d + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsD regsD,
      RegExec inp fd W C_cell C_bit (posDimStepD d s₀_d L) ws regs wsD regsD
        (stepDUnitCost d s₀_d L nodes.length)
        (stepDBitCost d s₀_d L W nodes.length) ∧
      ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap wsD ∧
      RegBounded W regsD ∧
      BitRAMDynamicProgram.readCachedAnswer wsD =
        ((ramCheckedAnswer L P nodes).diameterHandles, (ramCheckedAnswer L P nodes).cachedDistSq) ∧
      IsValidFactorCAnswer (Real.sqrt 2) P (ramCheckedAnswer L P nodes) ∧
      (ansPolPosDim d s₀_d L).checkedAnswer P nodes = ramCheckedAnswer L P nodes ∧
      wsD.read (.heap 0 0) = ws.read (.heap 0 0) := by
  obtain ⟨wsD, regsD, hexec, hinvD, hbndD, hread, hr0⟩ :=
    exec_posDimStepD hd1 hn hL hB1 hW hfd_le hinv hcCeil hbCeil hbnd
  obtain ⟨hval, hpol⟩ := ramCheckedAnswer_valid_of_chainStoredInv h_lem_5_2 h_clm_5_1_block_witness hinv
  exact ⟨wsD, regsD, hexec, hinvD, hbndD, hread, hval, hpol, hr0⟩

end UL.C12LVE
