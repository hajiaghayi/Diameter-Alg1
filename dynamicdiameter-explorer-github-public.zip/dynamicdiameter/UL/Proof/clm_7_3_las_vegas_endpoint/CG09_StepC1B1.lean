import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG09_StepC1B0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. `stagedA2Input`, `enumByHandleOrder` Identification, and `stageA2Locs` -/

/-- Subroutine `BitRAMInput d` corresponding to `m` active handles `hSeq 0 .. hSeq (m - 1)`. -/
def stagedA2Input {d : ℕ} (qMap : ℕ → Fin d → ℚ) (hSeq : ℕ → ℕ) (m B : ℕ) : BitRAMInput d :=
  { intParams := [(m : ℤ), (B : ℤ)]
    activeHandles := Finset.range m
    activeRatCoords := fun h => if h < m then qMap (hSeq h) else fun _ => 0
    extraRats := [] }

/-- Exact equality between `stagedA2Input` on `minPopElem (R.image (handleOfLifetime P))`
and the `BitRAMInput d` constructed in `S_lem_A_2` under `enumByHandleOrder P hwf R hR`. -/
theorem stagedA2Input_eq_lemA2Input {d n B : ℕ}
    (P : DynamicPointSet d) (hwf : P.WellFormed n)
    (R : Finset ℕ) (hR : R ⊆ activeLifetimes P)
    (qMap : ℕ → Fin d → ℚ) (pts : ℕ → Fin d → ℚ)
    (hpts : ∀ lt ∈ R, pts lt = qMap (handleOfLifetime P lt)) :
    let H := R.image (handleOfLifetime P)
    let enum := enumByHandleOrder P hwf R hR
    stagedA2Input qMap (minPopElem H) H.card B =
      { intParams := [(R.card : ℤ), (B : ℤ)]
        activeHandles := Finset.range R.card
        activeRatCoords := fun h =>
          if hh : h < R.card then pts (enum ⟨h, hh⟩).1 else fun _ => 0
        extraRats := [] } := by
  intro H enum
  have hcard : H.card = R.card := card_image_handleOfLifetime_eq hwf hR
  unfold stagedA2Input
  rw [hcard]
  congr 1
  funext h
  by_cases hh : h < R.card
  · rw [if_pos hh, dif_pos hh]
    have hlt_mem : (enum ⟨h, hh⟩).1 ∈ R := (enum ⟨h, hh⟩).2
    rw [hpts _ hlt_mem, enumByHandleOrder_handle P hwf R hR ⟨h, hh⟩]
  · rw [if_neg hh, dif_neg hh]

def stageA2Locs (d m : ℕ) : Finset RAMCellLoc :=
  {.heap 5 0, .heap 5 1} ∪
  (Finset.range (m * d)).image (fun k => .heap 6 (((k + 1 : ℕ) : ℤ))) ∪
  (Finset.range (m * d)).image (fun k => .heap 7 (((k + 1 : ℕ) : ℤ)))

theorem mem_stageA2Locs_50 (d m : ℕ) : (.heap 5 0 : RAMCellLoc) ∈ stageA2Locs d m := by
  simp [stageA2Locs]

theorem mem_stageA2Locs_51 (d m : ℕ) : (.heap 5 1 : RAMCellLoc) ∈ stageA2Locs d m := by
  simp [stageA2Locs]

theorem mem_stageA2Locs_6 {d m k : ℕ} (hk : k < m * d) :
    (.heap 6 (((k + 1 : ℕ) : ℤ)) : RAMCellLoc) ∈ stageA2Locs d m := by
  unfold stageA2Locs
  exact Finset.mem_union_left _ (Finset.mem_union_right _
    (Finset.mem_image.mpr ⟨k, Finset.mem_range.mpr hk, rfl⟩))

theorem mem_stageA2Locs_7 {d m k : ℕ} (hk : k < m * d) :
    (.heap 7 (((k + 1 : ℕ) : ℤ)) : RAMCellLoc) ∈ stageA2Locs d m := by
  unfold stageA2Locs
  exact Finset.mem_union_right _
    (Finset.mem_image.mpr ⟨k, Finset.mem_range.mpr hk, rfl⟩)

theorem stageA2Locs_sub_posDimWriteLocs {d L K_max m : ℕ}
    (_hd1 : 1 ≤ d) (hm_le : m ≤ 2 ^ L) :
    stageA2Locs d m ⊆ posDimWriteLocs d L K_max := by
  intro loc hloc
  unfold stageA2Locs at hloc
  simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image,
    Finset.mem_range] at hloc
  rcases hloc with ((rfl | rfl) | ⟨k, hk, rfl⟩) | ⟨k, hk, rfl⟩
  · exact mem_posDimWriteLocs_stage (t := 5) (i := 0) (Or.inl rfl) (by omega)
  · exact mem_posDimWriteLocs_stage (t := 5) (i := 1) (Or.inl rfl) (by omega)
  · have hmd : m * d ≤ d * 2 ^ L := by rw [Nat.mul_comm d]; exact Nat.mul_le_mul_right d hm_le
    have h2d : 2 * d * 2 ^ L = 2 * (d * 2 ^ L) := by ring
    exact mem_posDimWriteLocs_stage (t := 6) (i := k + 1) (Or.inr (Or.inl rfl)) (by omega)
  · have hmd : m * d ≤ d * 2 ^ L := by rw [Nat.mul_comm d]; exact Nat.mul_le_mul_right d hm_le
    have h2d : 2 * d * 2 ^ L = 2 * (d * 2 ^ L) := by ring
    exact mem_posDimWriteLocs_stage (t := 7) (i := k + 1) (Or.inr (Or.inr rfl)) (by omega)

/-! ### 2. Staging Handle Buffer `heap 8 [0 .. m - 1]` into `heap 5, 6, 7` (`stageBufForA2Regs`) -/

def stageBufCoordStepStmt : BitRAMStmt :=
  .seq (rMul 8 1 7)
  (.seq (rAdd 8 8 5)
  (.seq (rAdd 8 8 8)
  (.seq (rLoad 9 1 8)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
  (.seq (rLoad 10 1 8)
  (.seq (rSub 10 10 15)
  (.seq (rMul 11 4 7)
  (.seq (rAdd 11 11 5)
  (.seq (rAdd 11 11 15)
  (.seq (rStore 6 11 9)
  (.seq (rStore 7 11 10)
        (rAdd 5 5 15)))))))))))))

def stageBufPointBodyStmt (d : ℕ) : BitRAMStmt :=
  .seq (rLoad 1 8 4)
  (.seq (rLit 5 0)
  (.seq (rLit 7 (d : ℤ))
  (.seq (.repeatN (.lit (d : ℤ)) stageBufCoordStepStmt)
  (.seq (rLit 15 1)
        (rAdd 4 4 15)))))

def stageBufForA2Regs (d B : ℕ) : BitRAMStmt :=
  .seq (rLit 10 110)
  (.seq (rLoad 2 9 10)
  (.seq (rLit 8 0)
  (.seq (rStore 5 8 2)
  (.seq (rLit 3 (B : ℤ))
  (.seq (rLit 8 1)
  (.seq (rStore 5 8 3)
  (.seq (rLit 4 0)
        (.repeatN (.readLocal 2 (.lit 0)) (stageBufPointBodyStmt d)))))))))

private lemma stage_addr_inj {d i₁ c₁ i₂ c₂ : ℕ} (hc₁ : c₁ < d) (hc₂ : c₂ < d)
    (heq : (((i₁ * d + c₁ + 1 : ℕ) : ℤ)) = (((i₂ * d + c₂ + 1 : ℕ) : ℤ))) :
    i₁ = i₂ ∧ c₁ = c₂ := by
  have hnat : i₁ * d + c₁ + 1 = i₂ * d + c₂ + 1 := by exact_mod_cast heq
  rcases lt_trichotomy i₁ i₂ with hlt | rfl | hgt
  · have h1 : (i₁ + 1) * d ≤ i₂ * d := Nat.mul_le_mul_right d (by omega)
    have h2 : i₁ * d + c₁ < (i₁ + 1) * d := by rw [add_mul, one_mul]; omega
    omega
  · exact ⟨rfl, by omega⟩
  · have h1 : (i₂ + 1) * d ≤ i₁ * d := Nat.mul_le_mul_right d (by omega)
    have h2 : i₂ * d + c₂ < (i₂ + 1) * d := by rw [add_mul, one_mul]; omega
    omega

theorem exec_stageBufForA2Regs {d L B K_max W m : ℕ}
    (hd1 : 1 ≤ d) (hm1 : 1 ≤ m) (hB1 : 1 ≤ B) (hm_le : m ≤ 2 ^ L)
    (hW : B + natBitLength d + L + 28 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {S_act : Finset ℕ} {qMap : ℕ → Fin d → ℚ} {hSeq : ℕ → ℕ}
    {ws : WordStore} {regs : ℕ → ℤ}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hbnd : RegBounded W regs)
    (hcoords : ActiveCoordsStored d L B S_act qMap ws)
    (hr110 : ws.read (.heap 9 110) = (m : ℤ))
    (hbuf : ∀ i < m, ws.read (.heap 8 (i : ℤ)) = (hSeq i : ℤ))
    (hhSeq : ∀ i < m, hSeq i ∈ S_act)
    (hemp567 : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ ws.live) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (stageBufForA2Regs d B) ws regs wsEnd regsEnd
        ((m + 1) * (120 * d + 40)) ((m + 1) * (24 * d + 12) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      StagingA2Matches m B wsEnd (stagedA2Input qMap hSeq m B) ∧
      (∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ,
        (.heap t z : RAMCellLoc) ∈ wsEnd.live → (.heap t z : RAMCellLoc) ∈ stageA2Locs d m) ∧
      (∀ loc : RAMCellLoc, loc ∉ stageA2Locs d m →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW28 : 28 ≤ W := by clear * - hW; omega
  have hWW : 28 * W ≤ W * W := by nlinarith only [hW28]
  have hSubStage : stageA2Locs d m ⊆ posDimWriteLocs d L K_max :=
    stageA2Locs_sub_posDimWriteLocs hd1 hm_le
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hl110 : intBitLength (110 : ℤ) ≤ W := (show intBitLength (110 : ℤ) = 8 from by decide).trans_le (by omega)
  have hn1 : natBitLength 1 ≤ W := (show natBitLength 1 = 1 from by decide).trans_le (by omega)
  have hn5 : natBitLength 5 ≤ W := (show natBitLength 5 = 3 from by decide).trans_le (by omega)
  have hn6 : natBitLength 6 ≤ W := (show natBitLength 6 = 3 from by decide).trans_le (by omega)
  have hn7 : natBitLength 7 ≤ W := (show natBitLength 7 = 3 from by decide).trans_le (by omega)
  have hn8 : natBitLength 8 ≤ W := (show natBitLength 8 = 4 from by decide).trans_le (by omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by omega)
  have hd_bl : intBitLength (d : ℤ) ≤ W := (intBitLength_ofNat_le d).trans (by clear * - hW; omega)
  have hm_bl : intBitLength (m : ℤ) ≤ W :=
    (intBitLength_natCast_mono hm_le).trans ((nat_pow2_bitLength_le L).trans (by clear * - hW; omega))
  have hB_bl : intBitLength (B : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le B
    have h2 : natBitLength B ≤ B := by
      unfold natBitLength
      have := Nat.log_lt_self 2 (by omega : B ≠ 0)
      omega
    clear * - h1 h2 hW; omega
  have hloc50 : (RAMCellLoc.heap 5 0).bitLength ≤ W :=
    (show (RAMCellLoc.heap 5 0).bitLength = 4 from by decide).trans_le (by omega)
  have hloc51 : (RAMCellLoc.heap 5 1).bitLength ≤ W :=
    (show (RAMCellLoc.heap 5 1).bitLength = 5 from by decide).trans_le (by omega)
  have htop_bl : intBitLength (((m * d + 1 : ℕ) : ℤ)) ≤ natBitLength d + L + 14 := by
    have hm_lt1 : m < 2 ^ (L + 1) := by
      have hp : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
      rw [pow_succ]; omega
    have hc_top := (coordCellAddr_bl (L := L + 1) (W := natBitLength d + (L + 1) + 12)
      hm_lt1 hd1 (f := 1) (by decide) le_rfl).2
    unfold coordCellAddr at hc_top
    have hle : m * d + 1 ≤ (m * d + 0) * 2 + 1 := by omega
    exact (intBitLength_natCast_mono hle).trans (by clear * - hc_top; omega)
  have b_st_addr : ∀ k ≤ m * d,
      intBitLength (k : ℤ) ≤ W ∧
      intBitLength (((k + 1 : ℕ) : ℤ)) ≤ W ∧
      (RAMCellLoc.heap 6 (((k + 1 : ℕ) : ℤ))).bitLength ≤ W ∧
      (RAMCellLoc.heap 7 (((k + 1 : ℕ) : ℤ))).bitLength ≤ W := by
    intro k hk
    have hk1 : intBitLength (((k + 1 : ℕ) : ℤ)) ≤ natBitLength d + L + 14 :=
      (intBitLength_natCast_mono (by omega)).trans htop_bl
    have hk0 : intBitLength (k : ℤ) ≤ natBitLength d + L + 14 :=
      (intBitLength_natCast_mono (by omega)).trans htop_bl
    have hn6_eq : natBitLength 6 = 3 := by decide
    have hn7_eq : natBitLength 7 = 3 := by decide
    refine ⟨hk0.trans (by clear * - hW; omega), hk1.trans (by clear * - hW; omega),
      by change natBitLength 6 + _ ≤ W; rw [hn6_eq]; clear * - hk1 hW; omega,
      by change natBitLength 7 + _ ≤ W; rw [hn7_eq]; clear * - hk1 hW; omega⟩
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  -- Prologue: load m -> r2, write heap 5 0 := m, heap 5 1 := B, r4 := 0
  have p1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 110) (by decide) hl110
  set g1 := Function.update regs 10 110; have bg1 := hbnd.update (r := 10) (by decide) hl110
  have hg1_r : ws.read (.heap 9 (g1 10)) = (m : ℤ) := by simp [g1, hr110]
  have p2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 2) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact hm_bl)
  rw [hg1_r] at p2
  set g2 := Function.update g1 2 (m : ℤ); have bg2 := bg1.update (r := 2) (by decide) hm_bl
  have p3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := 0) (by decide) hl0
  set g3 := Function.update g2 8 0; have bg3 := bg2.update (r := 8) (by decide) hl0
  set wA := ws.write (.heap 5 0) (m : ℤ)
  have hmA : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wA :=
    hmod.write (hSubStage (mem_stageA2Locs_50 d m)) _ hloc50 hm_bl
  have hwA_eq : ws.write (.heap 5 (g3 8)) (g3 2) = wA := by simp [wA, g3, g2]
  have p4 := RegExec.store (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (wsHeap := ws) hfd_le bg3 (table := 5) (addr := 8) (val := 2) (by decide) (by decide) hn5
    (by rw [hwA_eq]; exact (sp_ok hmA).1) (by rw [hwA_eq]; exact (sp_ok hmA).2)
  rw [hwA_eq] at p4
  have p5 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hmA).1 (sp_ok hmA).2 (dst := 3) (c := (B : ℤ)) (by decide) hB_bl
  set g5 := Function.update g3 3 (B : ℤ); have bg5 := bg3.update (r := 3) (by decide) hB_bl
  have p6 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hmA).1 (sp_ok hmA).2 (dst := 8) (c := 1) (by decide) hl1
  set g6 := Function.update g5 8 1; have bg6 := bg5.update (r := 8) (by decide) hl1
  set wB := wA.write (.heap 5 1) (B : ℤ)
  have hmB : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wB :=
    hmA.write (hSubStage (mem_stageA2Locs_51 d m)) _ hloc51 hB_bl
  have hwB_eq : wA.write (.heap 5 (g6 8)) (g6 3) = wB := by simp [wB, g6, g5]
  have p7 := RegExec.store (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (wsHeap := wA) hfd_le bg6 (table := 5) (addr := 8) (val := 3) (by decide) (by decide) hn5
    (by rw [hwB_eq]; exact (sp_ok hmB).1) (by rw [hwB_eq]; exact (sp_ok hmB).2)
  rw [hwB_eq] at p7
  have p8 := RegExec.lit (inp := inp) hfd_le bg6 (sp_ok hmB).1 (sp_ok hmB).2 (dst := 4) (c := 0) (by decide) hl0
  set g8 := Function.update g6 4 0; have bg8 := bg6.update (r := 4) (by decide) hl0
  -- Single-point staging step helper for `i < m`
  have hPointStep : ∀ (i : ℕ) (hi : i < m) (wIn : WordStore) (rIn : ℕ → ℤ),
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wIn →
      RegBounded W rIn →
      rIn 4 = (i : ℤ) →
      (∀ loc : RAMCellLoc, loc ∉ stageA2Locs d m →
        (loc ∈ wIn.live ↔ loc ∈ ws.live) ∧ wIn.vals loc = ws.vals loc) →
      ∃ wOut rOut,
        RegExec inp fd W C_cell C_bit (stageBufPointBodyStmt d) wIn rIn wOut rOut
          (110 * d + 30) ((22 * d + 4) * W * W) ∧
        ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wOut ∧
        RegBounded W rOut ∧
        rOut 4 = ((i + 1 : ℕ) : ℤ) ∧
        (∀ c : Fin d,
          let addr : ℤ := (((i * d + c.val + 1 : ℕ) : ℤ))
          wOut.read (.heap 6 addr) = (qMap (hSeq i) c).num ∧
          wOut.read (.heap 7 addr) = ((qMap (hSeq i) c).den : ℤ) - 1) ∧
        (∀ loc : RAMCellLoc,
          (∀ c < d, loc ≠ .heap 6 (((i * d + c + 1 : ℕ) : ℤ)) ∧
                    loc ≠ .heap 7 (((i * d + c + 1 : ℕ) : ℤ))) →
          (loc ∈ wOut.live ↔ loc ∈ wIn.live) ∧ wOut.vals loc = wIn.vals loc) := by
    intro i hi wIn rIn hmIn brIn hrIn4 hfrIn_ws
    set hCur := hSeq i
    have hhCur_in : hCur ∈ S_act := hhSeq i hi
    obtain ⟨hhCur_lt, hqCur_bnd⟩ := hcoords.hS hCur hhCur_in
    have hhCur_bl : intBitLength (hCur : ℤ) ≤ W :=
      (nat_lt_pow2_bitLength_le hhCur_lt).trans (by clear * - hW; omega)
    have hr_buf_i : wIn.read (.heap 8 (rIn 4)) = (hCur : ℤ) := by
      rw [hrIn4]
      have hfr8 := hfrIn_ws (.heap 8 (i : ℤ)) (by
        unfold stageA2Locs
        simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image]
        rintro (((hc | hc) | ⟨_, _, hc⟩) | ⟨_, _, hc⟩) <;> cases hc)
      exact (wordStore_read_congr hfr8).trans (hbuf i hi)
    have b1 := RegExec.load (inp := inp) hfd_le brIn (sp_ok hmIn).1 (sp_ok hmIn).2 (dst := 1) (table := 8) (addr := 4)
      (by decide) (by decide) hn8 (by rw [hr_buf_i]; exact hhCur_bl)
    rw [hr_buf_i] at b1
    set s1 := Function.update rIn 1 (hCur : ℤ); have bs1 := brIn.update (r := 1) (by decide) hhCur_bl
    have b2 := RegExec.lit (inp := inp) hfd_le bs1 (sp_ok hmIn).1 (sp_ok hmIn).2 (dst := 5) (c := 0) (by decide) hl0
    set s2 := Function.update s1 5 0; have bs2 := bs1.update (r := 5) (by decide) hl0
    have b3 := RegExec.lit (inp := inp) hfd_le bs2 (sp_ok hmIn).1 (sp_ok hmIn).2 (dst := 7) (c := (d : ℤ)) (by decide) hd_bl
    set s3 := Function.update s2 7 (d : ℤ); have bs3 := bs2.update (r := 7) (by decide) hd_bl
    -- Inner coordinate loop `c = 0 .. d`
    let CoordInv (c : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
      RegBounded W g ∧
      g 1 = (hCur : ℤ) ∧ g 4 = (i : ℤ) ∧ g 5 = (c : ℤ) ∧ g 7 = (d : ℤ) ∧
      (∀ (c' : ℕ) (hc' : c' < d), c' < c →
        let addr : ℤ := (((i * d + c' + 1 : ℕ) : ℤ))
        w.read (.heap 6 addr) = (qMap hCur ⟨c', hc'⟩).num ∧
        w.read (.heap 7 addr) = ((qMap hCur ⟨c', hc'⟩).den : ℤ) - 1) ∧
      (∀ loc : RAMCellLoc,
        (∀ c' < c, loc ≠ .heap 6 (((i * d + c' + 1 : ℕ) : ℤ)) ∧
                   loc ≠ .heap 7 (((i * d + c' + 1 : ℕ) : ℤ))) →
        (loc ∈ w.live ↔ loc ∈ wIn.live) ∧ w.vals loc = wIn.vals loc)
    have hCoordLoop : ∀ c ≤ d, ∃ (wSeq : ℕ → WordStore) (gSeq : ℕ → ℕ → ℤ),
        wSeq 0 = wIn ∧ gSeq 0 = s3 ∧
        CoordInv c (wSeq c) (gSeq c) ∧
        (∀ c' < c, RegExec inp fd W C_cell C_bit stageBufCoordStepStmt
          (wSeq c') (gSeq c') (wSeq (c' + 1)) (gSeq (c' + 1))
          110 (22 * W * W)) := by
      intro c hc_le
      induction c with
      | zero =>
          refine ⟨fun _ => wIn, fun _ => s3, rfl, rfl, ?_, fun c' h => absurd h (Nat.not_lt_zero _)⟩
          exact ⟨hmIn, bs3, by simp [s3, s2, s1], by simp [s3, s2, s1, hrIn4],
            by simp [s3, s2], by simp [s3],
            fun _ _ h => absurd h (Nat.not_lt_zero _),
            fun _ _ => ⟨Iff.rfl, rfl⟩⟩
      | succ c ih =>
          have hc_lt : c < d := Nat.lt_of_succ_le hc_le
          obtain ⟨wS, gS, hw0, hg0,
            ⟨hm_c, bg_c, hg1, hg4, hg5, hg7, hprev_c, hfr_c⟩, hsteps_c⟩ := ih (Nat.le_of_succ_le hc_le)
          have hW_addr1 : natBitLength d + L + 12 ≤ W := by clear * - hW; omega
          obtain ⟨_, ha0_bl⟩ := coordCellAddr_bl hhCur_lt hc_lt (f := 0) (by decide) hW_addr1
          obtain ⟨_, ha1_bl⟩ := coordCellAddr_bl hhCur_lt hc_lt (f := 1) (by decide) hW_addr1
          have hhd_bl : intBitLength (((hCur * d : ℕ) : ℤ)) ≤ W :=
            (intBitLength_natCast_mono (b := (hCur * d + c) * 2 + 0) (by omega)).trans ha0_bl
          have hhdc_bl : intBitLength (((hCur * d + c : ℕ) : ℤ)) ≤ W :=
            (intBitLength_natCast_mono (b := (hCur * d + c) * 2 + 0) (by omega)).trans ha0_bl
          have hc1_bl : intBitLength (((c + 1 : ℕ) : ℤ)) ≤ W :=
            (intBitLength_natCast_mono (b := d) (by omega)).trans hd_bl
          obtain ⟨hqn_bl, hqd_bl, _, _⟩ := ratBitLength_le_of_bounded (hqCur_bnd ⟨c, hc_lt⟩)
          have hqn_W : intBitLength (qMap hCur ⟨c, hc_lt⟩).num ≤ W := hqn_bl.trans (by clear * - hW; omega)
          have hqd_W : intBitLength ((qMap hCur ⟨c, hc_lt⟩).den : ℤ) ≤ W := hqd_bl.trans (by clear * - hW; omega)
          have hden_pos : 1 ≤ (qMap hCur ⟨c, hc_lt⟩).den := Nat.succ_le_of_lt (qMap hCur ⟨c, hc_lt⟩).pos
          have hsub_den_eq : ((qMap hCur ⟨c, hc_lt⟩).den : ℤ) - 1 =
              ((((qMap hCur ⟨c, hc_lt⟩).den - 1 : ℕ) : ℤ)) := by omega
          have hqd1_W : intBitLength (((qMap hCur ⟨c, hc_lt⟩).den : ℤ) - 1) ≤ W := by
            rw [hsub_den_eq]
            exact (intBitLength_natCast_mono (Nat.sub_le _ 1)).trans hqd_W
          have hkc_lt : i * d + c < m * d := by
            have h1 : (i + 1) * d ≤ m * d := Nat.mul_le_mul_right d (by omega)
            have h2 : i * d + c < (i + 1) * d := by rw [add_mul, one_mul]; omega
            omega
          have hid_le : i * d ≤ m * d := le_of_lt (lt_of_le_of_lt (Nat.le_add_right _ _) hkc_lt)
          obtain ⟨hid_bl, _, _, _⟩ := b_st_addr (i * d) hid_le
          obtain ⟨hidc_bl, hidc1_bl, hloc6_bl, hloc7_bl⟩ := b_st_addr (i * d + c) (Nat.le_of_lt hkc_lt)
          -- Read num and den of hCur from heap 1 on wS c
          have hr1_num : (wS c).read (.heap 1 (coordCellAddr d hCur c 0)) = (qMap hCur ⟨c, hc_lt⟩).num := by
            have e1 := hfr_c (.heap 1 (coordCellAddr d hCur c 0)) (fun _ _ => ⟨(fun hc0 => by cases hc0), (fun hc0 => by cases hc0)⟩)
            have e2 := hfrIn_ws (.heap 1 (coordCellAddr d hCur c 0)) (by
              unfold stageA2Locs
              simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image]
              rintro (((hc0 | hc0) | ⟨_, _, hc0⟩) | ⟨_, _, hc0⟩) <;> cases hc0)
            exact (wordStore_read_congr e1).trans ((wordStore_read_congr e2).trans (hcoords.read_num hCur hhCur_in ⟨c, hc_lt⟩))
          have hr1_den : (wS c).read (.heap 1 (coordCellAddr d hCur c 1)) = ((qMap hCur ⟨c, hc_lt⟩).den : ℤ) := by
            have e1 := hfr_c (.heap 1 (coordCellAddr d hCur c 1)) (fun _ _ => ⟨(fun hc0 => by cases hc0), (fun hc0 => by cases hc0)⟩)
            have e2 := hfrIn_ws (.heap 1 (coordCellAddr d hCur c 1)) (by
              unfold stageA2Locs
              simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image]
              rintro (((hc0 | hc0) | ⟨_, _, hc0⟩) | ⟨_, _, hc0⟩) <;> cases hc0)
            exact (wordStore_read_congr e1).trans ((wordStore_read_congr e2).trans (hcoords.read_den hCur hhCur_in ⟨c, hc_lt⟩))
          -- Execute stageBufCoordStepStmt
          have hm1_8 : gS c 1 * gS c 7 = (((hCur * d : ℕ) : ℤ)) := by rw [hg1, hg7]; push_cast; ring
          have t1 := RegExec.mul (inp := inp) hfd_le bg_c (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 8) (a := 1) (b := 7)
            (by decide) (by decide) (by decide) (by rw [hm1_8]; exact hhd_bl)
          rw [hm1_8] at t1; set q1 := Function.update (gS c) 8 (((hCur * d : ℕ) : ℤ)); have bq1 := bg_c.update (r := 8) (by decide) hhd_bl
          have ha2_8 : q1 8 + q1 5 = (((hCur * d + c : ℕ) : ℤ)) := by simp [q1, hg5]
          have t2 := RegExec.add (inp := inp) hfd_le bq1 (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 8) (a := 8) (b := 5)
            (by decide) (by decide) (by decide) (by rw [ha2_8]; exact hhdc_bl)
          rw [ha2_8] at t2; set q2 := Function.update q1 8 (((hCur * d + c : ℕ) : ℤ)); have bq2 := bq1.update (r := 8) (by decide) hhdc_bl
          have ha3_8 : q2 8 + q2 8 = coordCellAddr d hCur c 0 := by
            simp only [q2, Function.update_self, coordCellAddr]; push_cast; ring
          have t3 := RegExec.add (inp := inp) hfd_le bq2 (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 8) (a := 8) (b := 8)
            (by decide) (by decide) (by decide) (by rw [ha3_8]; exact ha0_bl)
          rw [ha3_8] at t3; set q3 := Function.update q2 8 (coordCellAddr d hCur c 0); have bq3 := bq2.update (r := 8) (by decide) ha0_bl
          have hq3_r : (wS c).read (.heap 1 (q3 8)) = (qMap hCur ⟨c, hc_lt⟩).num := by simp [q3, hr1_num]
          have t4 := RegExec.load (inp := inp) hfd_le bq3 (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 9) (table := 1) (addr := 8)
            (by decide) (by decide) hn1 (by rw [hq3_r]; exact hqn_W)
          rw [hq3_r] at t4; set q4 := Function.update q3 9 (qMap hCur ⟨c, hc_lt⟩).num; have bq4 := bq3.update (r := 9) (by decide) hqn_W
          have t5 := RegExec.lit (inp := inp) hfd_le bq4 (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 15) (c := 1) (by decide) hl1
          set q5 := Function.update q4 15 1; have bq5 := bq4.update (r := 15) (by decide) hl1
          have ha6_8 : q5 8 + q5 15 = coordCellAddr d hCur c 1 := by
            simp only [q5, q4, q3, Function.update_self,
              Function.update_of_ne (by decide : (8 : ℕ) ≠ 15),
              Function.update_of_ne (by decide : (8 : ℕ) ≠ 9), coordCellAddr]
            push_cast; ring
          have t6 := RegExec.add (inp := inp) hfd_le bq5 (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 8) (a := 8) (b := 15)
            (by decide) (by decide) (by decide) (by rw [ha6_8]; exact ha1_bl)
          rw [ha6_8] at t6; set q6 := Function.update q5 8 (coordCellAddr d hCur c 1); have bq6 := bq5.update (r := 8) (by decide) ha1_bl
          have hq6_r : (wS c).read (.heap 1 (q6 8)) = ((qMap hCur ⟨c, hc_lt⟩).den : ℤ) := by simp [q6, hr1_den]
          have t7 := RegExec.load (inp := inp) hfd_le bq6 (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 10) (table := 1) (addr := 8)
            (by decide) (by decide) hn1 (by rw [hq6_r]; exact hqd_W)
          rw [hq6_r] at t7; set q7 := Function.update q6 10 ((qMap hCur ⟨c, hc_lt⟩).den : ℤ); have bq7 := bq6.update (r := 10) (by decide) hqd_W
          have hsub8_10 : q7 10 - q7 15 = ((qMap hCur ⟨c, hc_lt⟩).den : ℤ) - 1 := by simp [q7, q6, q5]
          have t8 := RegExec.sub (inp := inp) hfd_le bq7 (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 10) (a := 10) (b := 15)
            (by decide) (by decide) (by decide) (by rw [hsub8_10]; exact hqd1_W)
          rw [hsub8_10] at t8; set q8 := Function.update q7 10 (((qMap hCur ⟨c, hc_lt⟩).den : ℤ) - 1); have bq8 := bq7.update (r := 10) (by decide) hqd1_W
          have hm9_11 : q8 4 * q8 7 = (((i * d : ℕ) : ℤ)) := by
            simp [q8, q7, q6, q5, q4, q3, q2, q1, hg4, hg7]
          have t9 := RegExec.mul (inp := inp) hfd_le bq8 (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 11) (a := 4) (b := 7)
            (by decide) (by decide) (by decide) (by rw [hm9_11]; exact hid_bl)
          rw [hm9_11] at t9; set q9 := Function.update q8 11 (((i * d : ℕ) : ℤ)); have bq9 := bq8.update (r := 11) (by decide) hid_bl
          have ha10_11 : q9 11 + q9 5 = (((i * d + c : ℕ) : ℤ)) := by
            simp [q9, q8, q7, q6, q5, q4, q3, q2, q1, hg5]
          have t10 := RegExec.add (inp := inp) hfd_le bq9 (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 11) (a := 11) (b := 5)
            (by decide) (by decide) (by decide) (by rw [ha10_11]; exact hidc_bl)
          rw [ha10_11] at t10; set q10 := Function.update q9 11 (((i * d + c : ℕ) : ℤ)); have bq10 := bq9.update (r := 11) (by decide) hidc_bl
          have ha11_11 : q10 11 + q10 15 = (((i * d + c + 1 : ℕ) : ℤ)) := by
            simp [q10, q9, q8, q7, q6, q5]
          have t11 := RegExec.add (inp := inp) hfd_le bq10 (sp_ok hm_c).1 (sp_ok hm_c).2 (dst := 11) (a := 11) (b := 15)
            (by decide) (by decide) (by decide) (by rw [ha11_11]; exact hidc1_bl)
          rw [ha11_11] at t11
          set addrZ : ℤ := (((i * d + c + 1 : ℕ) : ℤ))
          set q11 := Function.update q10 11 addrZ; have bq11 := bq10.update (r := 11) (by decide) hidc1_bl
          set w1 := (wS c).write (.heap 6 addrZ) (qMap hCur ⟨c, hc_lt⟩).num
          have hm_w1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w1 :=
            hm_c.write (hSubStage (mem_stageA2Locs_6 hkc_lt)) _ hloc6_bl hqn_W
          have hw1_eq : (wS c).write (.heap 6 (q11 11)) (q11 9) = w1 := by
            simp [w1, q11, q10, q9, q8, q7, q6, q5, q4]
          have t12 := RegExec.store (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
            (wsHeap := wS c) hfd_le bq11 (table := 6) (addr := 11) (val := 9) (by decide) (by decide) hn6
            (by rw [hw1_eq]; exact (sp_ok hm_w1).1) (by rw [hw1_eq]; exact (sp_ok hm_w1).2)
          rw [hw1_eq] at t12
          set w2 := w1.write (.heap 7 addrZ) (((qMap hCur ⟨c, hc_lt⟩).den : ℤ) - 1)
          have hm_w2 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w2 :=
            hm_w1.write (hSubStage (mem_stageA2Locs_7 hkc_lt)) _ hloc7_bl hqd1_W
          have hw2_eq : w1.write (.heap 7 (q11 11)) (q11 10) = w2 := by
            simp [w2, q11, q10, q9, q8]
          have t13 := RegExec.store (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
            (wsHeap := w1) hfd_le bq11 (table := 7) (addr := 11) (val := 10) (by decide) (by decide) hn7
            (by rw [hw2_eq]; exact (sp_ok hm_w2).1) (by rw [hw2_eq]; exact (sp_ok hm_w2).2)
          rw [hw2_eq] at t13
          have ha14_5 : q11 5 + q11 15 = (((c + 1 : ℕ) : ℤ)) := by
            simp [q11, q10, q9, q8, q7, q6, q5, q4, q3, q2, q1, hg5]
          have t14 := RegExec.add (inp := inp) hfd_le bq11 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 5) (a := 5) (b := 15)
            (by decide) (by decide) (by decide) (by rw [ha14_5]; exact hc1_bl)
          rw [ha14_5] at t14
          set q14 := Function.update q11 5 (((c + 1 : ℕ) : ℤ)); have bq14 := bq11.update (r := 5) (by decide) hc1_bl
          have hstep_c : RegExec inp fd W C_cell C_bit stageBufCoordStepStmt
              (wS c) (gS c) w2 q14 110 (22 * W * W) :=
            (t1.seq (t2.seq (t3.seq (t4.seq (t5.seq (t6.seq (t7.seq (t8.seq
              (t9.seq (t10.seq (t11.seq (t12.seq (t13.seq t14))))))))))))).weaken rfl rfl
              (by omega) (by nlinarith only [hW28, hWW])
          refine ⟨fun k => if k ≤ c then wS k else w2,
                  fun k => if k ≤ c then gS k else q14,
                  by simp [hw0], by simp [hg0], ?_, ?_⟩
          · simp only [show ¬ (c + 1 ≤ c) by omega, ↓reduceIte]
            refine ⟨hm_w2, bq14,
              by simp [q14, q11, q10, q9, q8, q7, q6, q5, q4, q3, q2, q1, hg1],
              by simp [q14, q11, q10, q9, q8, q7, q6, q5, q4, q3, q2, q1, hg4],
              by simp [q14],
              by simp [q14, q11, q10, q9, q8, q7, q6, q5, q4, q3, q2, q1, hg7],
              fun c' hc'_d hc'_le => ?_,
              fun loc hne => ?_⟩
            · rcases Nat.lt_succ_iff_lt_or_eq.mp hc'_le with hlt | rfl
              · have hne_addr : (((i * d + c' + 1 : ℕ) : ℤ)) ≠ addrZ := by
                  dsimp [addrZ]; intro heq
                  exact Nat.ne_of_lt hlt (stage_addr_inj hc'_d hc_lt heq).2
                obtain ⟨hp6, hp7⟩ := hprev_c c' hc'_d hlt
                refine ⟨?_, ?_⟩
                · dsimp only [w2, w1]
                  rw [wordStore_read_write_ne _ (by intro h; cases h),
                      wordStore_read_write_ne _ (fun h => by injection h with _ ha; exact hne_addr ha)]
                  exact hp6
                · dsimp only [w2, w1]
                  rw [wordStore_read_write_ne _ (fun h => by injection h with _ ha; exact hne_addr ha),
                      wordStore_read_write_ne _ (by intro h; cases h)]
                  exact hp7
              · refine ⟨?_, ?_⟩
                · dsimp only [w2, w1, addrZ]
                  rw [wordStore_read_write_ne _ (by intro h; cases h), wordStore_read_write_self]
                · dsimp only [w2, addrZ]
                  rw [wordStore_read_write_self]
            · obtain ⟨hne6, hne7⟩ := hne c (Nat.lt_succ_self c)
              change loc ≠ .heap 6 addrZ at hne6
              change loc ≠ .heap 7 addrZ at hne7
              have hw2_fr : (loc ∈ w2.live ↔ loc ∈ (wS c).live) ∧ w2.vals loc = (wS c).vals loc := by
                simp [w2, w1, WordStore.write, hne6, hne7,
                  Function.update_of_ne hne6, Function.update_of_ne hne7]
              have hc_fr := hfr_c loc (fun c' hc' => hne c' (Nat.lt_succ_of_lt hc'))
              exact ⟨hw2_fr.1.trans hc_fr.1, hw2_fr.2.trans hc_fr.2⟩
          · intro c' hc'
            rcases Nat.lt_succ_iff_lt_or_eq.mp hc' with hlt | heq
            · simp only [show c' ≤ c by omega, show c' + 1 ≤ c by omega, ↓reduceIte]
              exact hsteps_c c' hlt
            · subst c'
              simp only [le_rfl, show ¬ (c + 1 ≤ c) by omega, ↓reduceIte]
              exact hstep_c
    obtain ⟨wSeq, gSeq, hw0, hg0,
      ⟨hm_d, bg_d, _, hg4_d, _, _, hcoords_d, hfr_d⟩, hsteps_d⟩ := hCoordLoop d le_rfl
    have b4 := RegExec.repeatLit (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      d hd_bl wSeq gSeq (by rw [hg0]; exact bs3) hsteps_d
    rw [hw0, hg0] at b4
    have b5 := RegExec.lit (inp := inp) hfd_le bg_d (sp_ok hm_d).1 (sp_ok hm_d).2 (dst := 15) (c := 1) (by decide) hl1
    set s5 := Function.update (gSeq d) 15 1; have bs5 := bg_d.update (r := 15) (by decide) hl1
    have hi1_bl : intBitLength (((i + 1 : ℕ) : ℤ)) ≤ W :=
      (intBitLength_natCast_mono (b := m) (by omega)).trans hm_bl
    have ha_s5 : s5 4 + s5 15 = (((i + 1 : ℕ) : ℤ)) := by simp [s5, hg4_d]
    have b6 := RegExec.add (inp := inp) hfd_le bs5 (sp_ok hm_d).1 (sp_ok hm_d).2 (dst := 4) (a := 4) (b := 15)
      (by decide) (by decide) (by decide) (by rw [ha_s5]; exact hi1_bl)
    rw [ha_s5] at b6
    set s6 := Function.update s5 4 (((i + 1 : ℕ) : ℤ)); have bs6 := bs5.update (r := 4) (by decide) hi1_bl
    have hbody : RegExec inp fd W C_cell C_bit (stageBufPointBodyStmt d) wIn rIn (wSeq d) s6
        (110 * d + 30) ((22 * d + 4) * W * W) :=
      (b1.seq (b2.seq (b3.seq (b4.seq (b5.seq b6))))).weaken rfl rfl
      (by omega)
      (by
        set WW := W * W
        have hov : (6 * W + 24) + (2 * W + 16) + (2 * W + 16) + W + (2 * W + 16) + (6 * W + 32) ≤ 4 * WW := by
          dsimp [WW]; nlinarith only [hW28, hWW]
        have h1 : d * (22 * W * W) + 4 * WW = (22 * d + 4) * W * W := by dsimp [WW]; ring
        linarith only [hov, h1])
    exact ⟨wSeq d, s6, hbody, hm_d, bs6, by simp [s6],
           fun c => hcoords_d c.val c.isLt c.isLt, hfr_d⟩
  -- Outer loop `i = 0 .. m`
  let OuterInv (i : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
    ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
    RegBounded W g ∧
    g 4 = (i : ℤ) ∧
    (∀ (i' : ℕ) (hi' : i' < m), i' < i → ∀ c : Fin d,
      let addr : ℤ := (((i' * d + c.val + 1 : ℕ) : ℤ))
      w.read (.heap 6 addr) = (qMap (hSeq i') c).num ∧
      w.read (.heap 7 addr) = ((qMap (hSeq i') c).den : ℤ) - 1) ∧
    (∀ loc : RAMCellLoc,
      (∀ i' < i, ∀ c < d, loc ≠ .heap 6 (((i' * d + c + 1 : ℕ) : ℤ)) ∧
                          loc ≠ .heap 7 (((i' * d + c + 1 : ℕ) : ℤ))) →
      (loc ∈ w.live ↔ loc ∈ wB.live) ∧ w.vals loc = wB.vals loc)
  have hOuter : ∀ i ≤ m, ∃ (wsSeq : ℕ → WordStore) (regSeq : ℕ → ℕ → ℤ),
      wsSeq 0 = wB ∧ regSeq 0 = g8 ∧
      OuterInv i (wsSeq i) (regSeq i) ∧
      (∀ i' < i, RegExec inp fd W C_cell C_bit (stageBufPointBodyStmt d)
        (wsSeq i') (regSeq i') (wsSeq (i' + 1)) (regSeq (i' + 1))
        (110 * d + 30) ((22 * d + 4) * W * W)) := by
    intro i hi_le
    induction i with
    | zero =>
        refine ⟨fun _ => wB, fun _ => g8, rfl, rfl, ?_, fun i' h => absurd h (Nat.not_lt_zero _)⟩
        exact ⟨hmB, bg8, by simp [g8], fun _ _ h => absurd h (Nat.not_lt_zero _), fun _ _ => ⟨Iff.rfl, rfl⟩⟩
    | succ i ih =>
        have hi_lt : i < m := Nat.lt_of_succ_le hi_le
        obtain ⟨wS, rS, hw0, hr0_eq, ⟨hm_i, br_i, hr4_i, hprev_i, hfr_i⟩, hsteps_i⟩ := ih (Nat.le_of_succ_le hi_le)
        have hfr_i_ws : ∀ loc : RAMCellLoc, loc ∉ stageA2Locs d m →
            (loc ∈ (wS i).live ↔ loc ∈ ws.live) ∧ (wS i).vals loc = ws.vals loc := by
          intro loc hn_st
          have e1 := hfr_i loc (fun i' hi' c hc => by
            have hk : i' * d + c < m * d := by
              have a : (i' + 1) * d ≤ m * d := Nat.mul_le_mul_right d (by omega)
              have b : i' * d + c < (i' + 1) * d := by rw [add_mul, one_mul]; omega
              omega
            exact ⟨fun h => hn_st (h ▸ mem_stageA2Locs_6 hk),
                   fun h => hn_st (h ▸ mem_stageA2Locs_7 hk)⟩)
          have h50 : loc ≠ .heap 5 0 := fun h => hn_st (h ▸ mem_stageA2Locs_50 d m)
          have h51 : loc ≠ .heap 5 1 := fun h => hn_st (h ▸ mem_stageA2Locs_51 d m)
          have e2 : (loc ∈ wB.live ↔ loc ∈ ws.live) ∧ wB.vals loc = ws.vals loc := by
            simp [wB, wA, WordStore.write, h50, h51, Function.update_of_ne h50, Function.update_of_ne h51]
          exact ⟨e1.1.trans e2.1, e1.2.trans e2.2⟩
        obtain ⟨wNext, rNext, hstep_i, hmN, brN, hr4N, hcurN, hfrN⟩ :=
          hPointStep i hi_lt (wS i) (rS i) hm_i br_i hr4_i hfr_i_ws
        refine ⟨fun k => if k ≤ i then wS k else wNext,
                fun k => if k ≤ i then rS k else rNext,
                by simp [hw0], by simp [hr0_eq], ?_, ?_⟩
        · simp only [show ¬ (i + 1 ≤ i) by omega, ↓reduceIte]
          refine ⟨hmN, brN, hr4N, fun i' hi'_m hi'_le c => ?_, fun loc hne => ?_⟩
          · rcases Nat.lt_succ_iff_lt_or_eq.mp hi'_le with hlt | rfl
            · have hne_pair : ∀ c₂ < d,
                  (((i' * d + c.val + 1 : ℕ) : ℤ)) ≠ (((i * d + c₂ + 1 : ℕ) : ℤ)) := by
                intro c₂ hc₂ heq
                exact Nat.ne_of_lt hlt (stage_addr_inj c.isLt hc₂ heq).1
              have e6 := hfrN (.heap 6 (((i' * d + c.val + 1 : ℕ) : ℤ))) (fun c₂ hc₂ => ⟨(fun h => hne_pair c₂ hc₂ (by injection h)), (fun h => by cases h)⟩)
              have e7 := hfrN (.heap 7 (((i' * d + c.val + 1 : ℕ) : ℤ))) (fun c₂ hc₂ => ⟨(fun h => by cases h), (fun h => hne_pair c₂ hc₂ (by injection h))⟩)
              obtain ⟨hp6, hp7⟩ := hprev_i i' hi'_m hlt c
              exact ⟨(wordStore_read_congr e6).trans hp6, (wordStore_read_congr e7).trans hp7⟩
            · exact hcurN c
          · have eN := hfrN loc (fun c hc => hne i (Nat.lt_succ_self i) c hc)
            have eI := hfr_i loc (fun i' hi' c hc => hne i' (Nat.lt_succ_of_lt hi') c hc)
            exact ⟨eN.1.trans eI.1, eN.2.trans eI.2⟩
        · intro i' hi'
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi' with hlt | heq
          · simp only [show i' ≤ i by omega, show i' + 1 ≤ i by omega, ↓reduceIte]
            exact hsteps_i i' hlt
          · subst i'
            simp only [le_rfl, show ¬ (i + 1 ≤ i) by omega, ↓reduceIte]
            exact hstep_i
  obtain ⟨wsSeq, regSeq, hw0, hr0_eq, ⟨hmEnd, brEnd, _, hcoordsEnd, hfrEnd⟩, hstepsEnd⟩ := hOuter m le_rfl
  have p9 := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (cntReg := 2) (by decide) m wsSeq regSeq
    (by rw [hr0_eq]; simp [g8, g6, g5, g3, g2])
    (by rw [hr0_eq]; exact bg8) hstepsEnd
  rw [hw0, hr0_eq] at p9
  set wsEnd := wsSeq m
  set regsEnd := regSeq m
  -- Frame outside stageA2Locs d m and containment in stageA2Locs d m
  have hfr_out : ∀ loc : RAMCellLoc, loc ∉ stageA2Locs d m →
      (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc := by
    intro loc hn_st
    have e1 := hfrEnd loc (fun i' hi' c hc => by
      have hk : i' * d + c < m * d := by
        have a : (i' + 1) * d ≤ m * d := Nat.mul_le_mul_right d (by omega)
        have b : i' * d + c < (i' + 1) * d := by rw [add_mul, one_mul]; omega
        omega
      exact ⟨fun h => hn_st (h ▸ mem_stageA2Locs_6 hk),
             fun h => hn_st (h ▸ mem_stageA2Locs_7 hk)⟩)
    have h50 : loc ≠ .heap 5 0 := fun h => hn_st (h ▸ mem_stageA2Locs_50 d m)
    have h51 : loc ≠ .heap 5 1 := fun h => hn_st (h ▸ mem_stageA2Locs_51 d m)
    have e2 : (loc ∈ wB.live ↔ loc ∈ ws.live) ∧ wB.vals loc = ws.vals loc := by
      simp [wB, wA, WordStore.write, h50, h51, Function.update_of_ne h50, Function.update_of_ne h51]
    exact ⟨e1.1.trans e2.1, e1.2.trans e2.2⟩
  have hlive_in : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ,
      (.heap t z : RAMCellLoc) ∈ wsEnd.live → (.heap t z : RAMCellLoc) ∈ stageA2Locs d m := by
    intro t ht z hlive
    by_contra hn_st
    exact hemp567 t ht z ((hfr_out _ hn_st).1.mp hlive)
  -- StagingA2Matches proof
  have hStage : StagingA2Matches m B wsEnd (stagedA2Input qMap hSeq m B) := by
    refine ⟨hd1, hm1, hB1, rfl, rfl, rfl, ?_, ?_, ?_, ?_⟩
    · intro idx
      by_cases h0 : idx = 0
      · subst h0
        have e1 := hfrEnd (.heap 5 0) (fun _ _ _ _ => ⟨(fun hc => by cases hc), (fun hc => by cases hc)⟩)
        have hr_wB : wB.read (.heap 5 0) = (m : ℤ) := by
          dsimp only [wB, wA]
          rw [wordStore_read_write_ne _ (by decide)]
          simp [WordStore.read, WordStore.write]
        rw [(wordStore_read_congr e1).trans hr_wB]; rfl
      · by_cases h1 : idx = 1
        · subst h1
          have e1 := hfrEnd (.heap 5 1) (fun _ _ _ _ => ⟨(fun hc => by cases hc), (fun hc => by cases hc)⟩)
          have hr_wB : wB.read (.heap 5 1) = (B : ℤ) := by
            simp [wB, WordStore.read, WordStore.write]
          rw [(wordStore_read_congr e1).trans hr_wB]; rfl
        · have hn_st : (.heap 5 idx : RAMCellLoc) ∉ stageA2Locs d m := by
            unfold stageA2Locs
            simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image]
            rintro (((hc | hc) | ⟨_, _, hc⟩) | ⟨_, _, hc⟩)
            · injection hc with _ e; exact h0 e
            · injection hc with _ e; exact h1 e
            · cases hc
            · cases hc
          have hn_live : (.heap 5 idx : RAMCellLoc) ∉ wsEnd.live :=
            fun hm_l => hemp567 5 (Or.inl rfl) idx ((hfr_out _ hn_st).1.mp hm_l)
          have hl_zero : listGetIntD [(m : ℤ), (B : ℤ)] idx 0 = 0 := by
            unfold listGetIntD
            split_ifs with hnn
            · rcases eq_or_lt_of_le (show 2 ≤ idx.toNat by omega) with h2 | hgt
              · simp [← h2]
              · simp [List.getD, List.getElem?_eq_none (show [(m : ℤ), (B : ℤ)].length ≤ idx.toNat by simpa using le_of_lt hgt)]
            · rfl
          rw [hl_zero]; simp [WordStore.read, hn_live]
    · have hn_st : (.heap 6 0 : RAMCellLoc) ∉ stageA2Locs d m := by
        unfold stageA2Locs
        simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image]
        rintro (((hc | hc) | ⟨k, _, hc⟩) | ⟨_, _, hc⟩)
        · cases hc
        · cases hc
        · injection hc with _ e; omega
        · cases hc
      have hn_live : (.heap 6 0 : RAMCellLoc) ∉ wsEnd.live :=
        fun hm_l => hemp567 6 (Or.inr (Or.inl rfl)) 0 ((hfr_out _ hn_st).1.mp hm_l)
      simp [WordStore.read, hn_live]
    · have hn_st : (.heap 7 0 : RAMCellLoc) ∉ stageA2Locs d m := by
        unfold stageA2Locs
        simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image]
        rintro (((hc | hc) | ⟨_, _, hc⟩) | ⟨k, _, hc⟩)
        · cases hc
        · cases hc
        · cases hc
        · injection hc with _ e; omega
      have hn_live : (.heap 7 0 : RAMCellLoc) ∉ wsEnd.live :=
        fun hm_l => hemp567 7 (Or.inr (Or.inr rfl)) 0 ((hfr_out _ hn_st).1.mp hm_l)
      simp [WordStore.read, hn_live]
    · intro i hi c
      obtain ⟨hr6, hr7⟩ := hcoordsEnd i hi hi c
      dsimp only [stagedA2Input]
      rw [if_pos hi]
      exact ⟨hr6, by linarith only [hr7]⟩
  refine ⟨wsEnd, regsEnd, ?_, hmEnd, brEnd, hStage, hlive_in, hfr_out⟩
  have htot := p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq (p7.seq (p8.seq p9)))))))
  refine htot.weaken rfl rfl ?_ ?_
  · nlinarith only [hd1]
  · set WW := W * W
    have hov : (2 * W + 16) + (6 * W + 24) + (2 * W + 16) + (5 * W + 24) +
        (2 * W + 16) + (2 * W + 16) + (5 * W + 24) + (2 * W + 16) + (W + 12) ≤ 4 * WW := by
      dsimp [WW]; nlinarith only [hW28, hWW]
    have hcoef : m * (22 * d + 4) + 4 ≤ (m + 1) * (24 * d + 12) := by nlinarith only [hd1]
    have hmul := Nat.mul_le_mul_right WW hcoef
    have h1 : (m * (22 * d + 4) + 4) * WW = 4 * WW + m * ((22 * d + 4) * W * W) := by dsimp [WW]; ring
    have h2 : ((m + 1) * (24 * d + 12)) * WW = (m + 1) * (24 * d + 12) * W * W := by dsimp [WW]; ring
    linarith only [hov, hmul, h1, h2]


end UL.C12LVE
