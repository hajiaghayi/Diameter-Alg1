import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2b_SubStore
set_option autoImplicit false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

private lemma a2_arith_lit {K b : ℕ} (hK : 8 ≤ K) (hb : 1 ≤ b) :
    1 ≤ 64 * 1 ∧ b ≤ 64 * K * b := by
  refine ⟨by omega, ?_⟩
  calc b = 1 * b := (one_mul b).symm
    _ ≤ (64 * K) * b := Nat.mul_le_mul_right b (by omega)

private lemma a2_arith_extra {F K u₀ b₀ subEx exU exB : ℕ}
    (hF : 64 ≤ F) (hK : 8 ≤ K) (hb0 : 1 ≤ b₀)
    (hexU : exU ≤ 8) (hexB : exB ≤ 8) :
    exU ≤ (64 * F) * (u₀ + 1) ∧
    exB ≤ (64 * F) * K * (b₀ + subEx) := by
  have h1 : 8 ≤ 64 * F := by omega
  have h2 : 8 ≤ (64 * F) * K := by nlinarith
  refine ⟨?_, ?_⟩
  · calc exU ≤ 8 * 1 := by omega
      _ ≤ (64 * F) * (u₀ + 1) := Nat.mul_le_mul h1 (by omega)
  · calc exB ≤ 8 * 1 := by omega
      _ ≤ ((64 * F) * K) * (b₀ + subEx) := Nat.mul_le_mul h2 (by omega)

private lemma a2_arith_not {F K u₀ u'₀ b₀ b'₀ : ℕ}
    (hF : 64 ≤ F) (hK : 8 ≤ K)
    (hu : u'₀ ≤ F * u₀) (hb : b'₀ ≤ F * K * b₀) :
    u'₀ + 1 ≤ (16 * F) * (u₀ + 1) ∧
    b'₀ + 1 ≤ (16 * F) * K * (b₀ + 1) := by
  have hFK : 512 ≤ F * K := by nlinarith
  refine ⟨by nlinarith, ?_⟩
  calc b'₀ + 1
      ≤ F * K * b₀ + (F * K) := by omega
    _ ≤ 16 * (F * K * b₀) + 16 * (F * K) := by omega
    _ = (16 * F) * K * (b₀ + 1) := by ring

private lemma a2_arith_unary {F K u₀ u'₀ b₀ b'₀ extraU extraB subExtra : ℕ}
    (hF : 64 ≤ F) (hK : 8 ≤ K) (hsub : 1 ≤ subExtra)
    (hu : u'₀ ≤ F * u₀) (hb : b'₀ ≤ F * K * b₀)
    (hexU : extraU ≤ 32) (hexB : extraB ≤ 16 * K * subExtra) :
    u'₀ + extraU ≤ (64 * F) * (u₀ + 1) ∧
    b'₀ + extraB ≤ (64 * F) * K * (b₀ + subExtra) := by
  have hK_sub : 16 * K * subExtra ≤ 16 * ((F * K) * subExtra) := by
    have h1 : K ≤ F * K := le_mul_of_one_le_left (Nat.zero_le K) (by omega)
    have h2 : 16 * K ≤ 16 * (F * K) := Nat.mul_le_mul_left 16 h1
    simpa [Nat.mul_assoc] using Nat.mul_le_mul_right subExtra h2
  constructor
  · nlinarith
  · calc b'₀ + extraB
        ≤ (F * K * b₀) + 16 * ((F * K) * subExtra) := Nat.add_le_add hb (le_trans hexB hK_sub)
      _ ≤ 64 * (F * K * b₀) + 64 * ((F * K) * subExtra) := by
          exact Nat.add_le_add
            (le_mul_of_one_le_left (Nat.zero_le _) (by omega))
            (Nat.mul_le_mul_right _ (by omega))
      _ = (64 * F) * K * (b₀ + subExtra) := by ring

private lemma a2_arith_binary {M F₁ F₂ K u₁ u'₁ u₂ u'₂ b₁ b'₁ b₂ b'₂ extraU extraB subExtra : ℕ}
    (hM : 16 ≤ M) (hF₁ : 64 ≤ F₁) (hF₂ : 64 ≤ F₂) (hK : 8 ≤ K)
    (hu₁ : u'₁ ≤ F₁ * u₁) (hu₂ : u'₂ ≤ F₂ * u₂)
    (hb₁ : b'₁ ≤ F₁ * K * b₁) (hb₂ : b'₂ ≤ F₂ * K * b₂)
    (hexU : extraU ≤ M) (hexB : extraB ≤ (M - 2) * (K * subExtra) + K)
    (hsub_pos : 1 ≤ b₁ + b₂ + subExtra) :
    u'₁ + u'₂ + extraU ≤ (M * (F₁ + F₂)) * (u₁ + u₂ + 1) ∧
    b'₁ + b'₂ + extraB ≤ (M * (F₁ + F₂)) * K * (b₁ + b₂ + subExtra) := by
  have hFF : 128 ≤ F₁ + F₂ := by omega
  constructor
  · have hu_a : F₁ * u₁ ≤ (F₁ + F₂) * u₁ := Nat.mul_le_mul_right u₁ (by omega)
    have hu_b : F₂ * u₂ ≤ (F₁ + F₂) * u₂ := Nat.mul_le_mul_right u₂ (by omega)
    calc u'₁ + u'₂ + extraU
        ≤ (F₁ + F₂) * u₁ + (F₁ + F₂) * u₂ + M := by omega
      _ = (F₁ + F₂) * (u₁ + u₂) + M * 1 := by ring
      _ ≤ (M * (F₁ + F₂)) * (u₁ + u₂) + M * (F₁ + F₂) := by
          refine Nat.add_le_add ?_ (Nat.mul_le_mul_left M (by omega))
          exact Nat.mul_le_mul_right (u₁ + u₂) (le_mul_of_one_le_left (Nat.zero_le _) (by omega))
      _ = (M * (F₁ + F₂)) * (u₁ + u₂ + 1) := by ring
  · have h1 : b'₁ ≤ (F₁ + F₂) * K * b₁ :=
      le_trans hb₁ (Nat.mul_le_mul_right b₁ (Nat.mul_le_mul_right K (by omega)))
    have h2 : b'₂ ≤ (F₁ + F₂) * K * b₂ :=
      le_trans hb₂ (Nat.mul_le_mul_right b₂ (Nat.mul_le_mul_right K (by omega)))
    have hK_le : K ≤ (F₁ + F₂) * K * (b₁ + b₂ + subExtra) := by
      calc K = 1 * K * 1 := by ring
        _ ≤ (F₁ + F₂) * K * (b₁ + b₂ + subExtra) :=
          Nat.mul_le_mul (Nat.mul_le_mul_right K (by omega)) hsub_pos
    have hsum_part : (F₁ + F₂) * K * b₁ + (F₁ + F₂) * K * b₂ + K ≤
        2 * ((F₁ + F₂) * K * (b₁ + b₂ + subExtra)) := by
      have hdistr : (F₁ + F₂) * K * (b₁ + b₂ + subExtra) =
          (F₁ + F₂) * K * b₁ + (F₁ + F₂) * K * b₂ + (F₁ + F₂) * K * subExtra := by ring
      omega
    have hrem_part : (M - 2) * (K * subExtra) ≤
        (M - 2) * ((F₁ + F₂) * K * (b₁ + b₂ + subExtra)) := by
      refine Nat.mul_le_mul_left (M - 2) ?_
      calc K * subExtra = 1 * K * subExtra := by ring
        _ ≤ (F₁ + F₂) * K * subExtra :=
            Nat.mul_le_mul_right subExtra (Nat.mul_le_mul_right K (by omega))
        _ ≤ (F₁ + F₂) * K * (b₁ + b₂ + subExtra) :=
            Nat.mul_le_mul_left ((F₁ + F₂) * K) (by omega)
    calc b'₁ + b'₂ + extraB
        ≤ (F₁ + F₂) * K * b₁ + (F₁ + F₂) * K * b₂ + (M - 2) * (K * subExtra) + K := by omega
      _ ≤ 2 * ((F₁ + F₂) * K * (b₁ + b₂ + subExtra)) +
            (M - 2) * ((F₁ + F₂) * K * (b₁ + b₂ + subExtra)) := by omega
      _ = (2 + (M - 2)) * ((F₁ + F₂) * K * (b₁ + b₂ + subExtra)) := by ring
      _ = (M * (F₁ + F₂)) * K * (b₁ + b₂ + subExtra) := by
          rw [show 2 + (M - 2) = M by omega]; ring

private lemma a2_arith_rat2d
    {F₁ F₂ K u₁ u'₁ u₂ u'₂ uA b₁ b'₁ b₂ b'₂ bA bh bc bo ba extraTailU extraTailB : ℕ}
    (hF₁ : 64 ≤ F₁) (hF₂ : 64 ≤ F₂) (hK : 8 ≤ K)
    (hbh : 1 ≤ bh) (hbc : 1 ≤ bc) (hbo : 1 ≤ bo) (hba : ba ≤ K)
    (hu₁ : u'₁ ≤ F₁ * u₁) (hu₂ : u'₂ ≤ F₂ * u₂)
    (hb₁ : b'₁ ≤ F₁ * K * b₁) (hb₂ : b'₂ ≤ F₂ * K * b₂)
    (huA : uA ≤ 2 * u'₁ + 2 * u'₂ + 26)
    (hbA : bA ≤ 2 * b'₁ + 2 * b'₂ + 16 * K * (bh + bc + 4))
    (hTailU : extraTailU ≤ 4)
    (hTailB : extraTailB ≤ 3 * bo + 12) :
    uA + extraTailU ≤ (1024 * (F₁ + F₂)) * (u₁ + u₂ + 1) ∧
    bA + ba + extraTailB ≤ (1024 * (F₁ + F₂)) * K * (b₁ + b₂ + bh + bc + bo) := by
  have hFF : 128 ≤ F₁ + F₂ := by omega
  constructor
  · have hu_a : F₁ * u₁ ≤ (F₁ + F₂) * u₁ := Nat.mul_le_mul_right u₁ (by omega)
    have hu_b : F₂ * u₂ ≤ (F₁ + F₂) * u₂ := Nat.mul_le_mul_right u₂ (by omega)
    calc uA + extraTailU
        ≤ 2 * ((F₁ + F₂) * u₁) + 2 * ((F₁ + F₂) * u₂) + 30 := by omega
      _ ≤ 2 * ((F₁ + F₂) * u₁) + 2 * ((F₁ + F₂) * u₂) + 1024 * (F₁ + F₂) := by omega
      _ ≤ 1024 * ((F₁ + F₂) * u₁) + 1024 * ((F₁ + F₂) * u₂) + 1024 * (F₁ + F₂) := by omega
      _ = (1024 * (F₁ + F₂)) * (u₁ + u₂ + 1) := by ring
  · have h1 : 2 * b'₁ ≤ 2 * ((F₁ + F₂) * K * b₁) := by
      have := le_trans hb₁ (Nat.mul_le_mul_right b₁ (Nat.mul_le_mul_right K (Nat.le_add_right F₁ F₂)))
      omega
    have h2 : 2 * b'₂ ≤ 2 * ((F₁ + F₂) * K * b₂) := by
      have := le_trans hb₂ (Nat.mul_le_mul_right b₂ (Nat.mul_le_mul_right K (Nat.le_add_left F₂ F₁)))
      omega
    have h3 : 16 * K * (bh + bc + 4) + ba + extraTailB ≤ 120 * K * (bh + bc + bo) := by nlinarith
    have h4 : 120 * K * (bh + bc + bo) ≤ 120 * ((F₁ + F₂) * K * (bh + bc + bo)) := by
      have hk : K ≤ (F₁ + F₂) * K := le_mul_of_one_le_left (Nat.zero_le _) (by omega)
      calc 120 * K * (bh + bc + bo) = 120 * (K * (bh + bc + bo)) := by ring
        _ ≤ 120 * (((F₁ + F₂) * K) * (bh + bc + bo)) :=
            Nat.mul_le_mul_left 120 (Nat.mul_le_mul_right _ hk)
    have hdistr : (F₁ + F₂) * K * (b₁ + b₂ + bh + bc + bo) =
        (F₁ + F₂) * K * b₁ + (F₁ + F₂) * K * b₂ + (F₁ + F₂) * K * (bh + bc + bo) := by ring
    calc bA + ba + extraTailB
        ≤ 2 * ((F₁ + F₂) * K * b₁) + 2 * ((F₁ + F₂) * K * b₂) +
            120 * ((F₁ + F₂) * K * (bh + bc + bo)) := by omega
      _ ≤ 1024 * ((F₁ + F₂) * K * (b₁ + b₂ + bh + bc + bo)) := by omega
      _ = (1024 * (F₁ + F₂)) * K * (b₁ + b₂ + bh + bc + bo) := by ring

private lemma sub_le_mul_param {K x : ℕ} (hK : 8 ≤ K) (M : ℕ) (hM : 14 ≤ M) :
    x ≤ M * (K * x) + K := by
  have h1 : 1 ≤ M * K := by nlinarith
  have h2 : x ≤ (M * K) * x := le_mul_of_one_le_left (Nat.zero_le x) h1
  rw [Nat.mul_assoc] at h2
  omega

theorem evalIntExpr_trA2Expr {d m B T_max : ℕ} {wsBase wsSub wsSim : WordStore}
    {inpSub : BitRAMInput d} {fdSub : ℕ}
    (inpSim : BitRAMInput d)
    (hstage : StagingA2Matches m B wsBase inpSub)
    (hT : 1 ≤ T_max)
    (hag : AgreesForA2Expr wsBase T_max wsSub fdSub wsSim) :
    ∀ e : IntExpr,
      maxTableExpr e ≤ T_max →
      let rSub := evalIntExpr inpSub fdSub wsSub e
      let rSim := evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e)
      rSim.1 = rSub.1 ∧
      rSim.2.1 ≤ a2ExprFactor e * rSub.2.1 ∧
      rSim.2.2 ≤ a2ExprFactor e * a2ParamBits m d T_max * rSub.2.2 := by
  have hKp8 : 8 ≤ a2ParamBits m d T_max := by unfold a2ParamBits; omega
  intro e htm
  dsimp only
  induction e with
  | lit c =>
      simp only [trA2Expr, evalIntExpr, a2ExprFactor]
      have hb := a2_arith_lit hKp8 (intBitLength_pos c)
      exact ⟨trivial, hb.1, hb.2⟩
  | dim =>
      simp only [trA2Expr, evalIntExpr, a2ExprFactor]
      have hb := a2_arith_lit hKp8 (intBitLength_pos (d : ℤ))
      exact ⟨trivial, hb.1, hb.2⟩
  | intParam idxE ih =>
      simp only [maxTableExpr] at htm
      have ih' := ih htm
      rcases h1 : evalIntExpr inpSub fdSub wsSub idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max idxE) with ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at ih'
      rcases ih' with ⟨heq, hu, hb⟩; subst idx'
      have hread : wsSim.read (.heap 5 idx) = listGetIntD inpSub.intParams idx 0 := by
        rw [hag.1 5 (by omega) idx, hstage.2.2.2.2.2.2.1 idx, hstage.2.2.2.1]
      simp only [trA2Expr, evalIntExpr, h1, h2, hread, a2ExprFactor]
      have hn5 : natBitLength 5 = 3 := by decide
      rw [hn5]
      have hb_idx := intBitLength_pos idx
      have hb_val := intBitLength_pos (listGetIntD inpSub.intParams idx 0)
      have hex_le : 3 + intBitLength idx + intBitLength (listGetIntD inpSub.intParams idx 0) ≤
          16 * a2ParamBits m d T_max *
            (intBitLength idx + intBitLength (listGetIntD inpSub.intParams idx 0)) := by
        have h1 : 4 ≤ 16 * a2ParamBits m d T_max := by omega
        calc 3 + intBitLength idx + intBitLength (listGetIntD inpSub.intParams idx 0)
            ≤ 4 * (intBitLength idx + intBitLength (listGetIntD inpSub.intParams idx 0)) := by omega
          _ ≤ (16 * a2ParamBits m d T_max) *
                (intBitLength idx + intBitLength (listGetIntD inpSub.intParams idx 0)) :=
              Nat.mul_le_mul_right _ h1
      have hbnd := a2_arith_unary (a2ExprFactor_ge_64 idxE) hKp8 (extraU := 1) (extraB := 3 + intBitLength idx + intBitLength (listGetIntD inpSub.intParams idx 0)) (subExtra := intBitLength idx + intBitLength (listGetIntD inpSub.intParams idx 0)) (by omega) hu hb (by omega) hex_le
      refine ⟨trivial, hbnd.1, ?_⟩
      simpa [Nat.add_assoc] using hbnd.2
  | readHeap table idxE ih =>
      simp only [maxTableExpr, max_le_iff] at htm
      have ih' := ih htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max idxE) with ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at ih'
      rcases ih' with ⟨heq, hu, hb⟩; subst idx'
      have hread : wsSim.read (.heap 10 (idx * (T_max : ℤ) + (table : ℤ))) =
          wsSub.read (.heap table idx) := hag.2.1 table htm.1 idx
      simp only [trA2Expr, evalIntExpr, h1, h2, hread, a2ExprFactor]
      have hn10 : natBitLength 10 = 4 := by decide
      rw [hn10]
      have hT_bl := intBitLength_ofNat_le T_max
      have ht_bl := intBitLength_ofNat_le table
      have ht_le := natBitLength_mono (Nat.le_of_lt htm.1)
      have henc_bl := intBitLength_encA2_le htm.1 idx
      have hmul_bl := intBitLength_mul_le idx (T_max : ℤ)
      have hb_idx := intBitLength_pos idx
      have hb_val := intBitLength_pos (wsSub.read (.heap table idx))
      have ht_pos := natBitLength_pos table
      have hT_K : natBitLength T_max + 4 ≤ a2ParamBits m d T_max := by unfold a2ParamBits; omega
      set subEx := natBitLength table + intBitLength idx + intBitLength (wsSub.read (.heap table idx))
      set exB := intBitLength (T_max : ℤ) + intBitLength idx * intBitLength (T_max : ℤ) +
          intBitLength (table : ℤ) + intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ) +
          4 + intBitLength (idx * (T_max : ℤ) + (table : ℤ)) + intBitLength (wsSub.read (.heap table idx))
      have hexB_le : exB ≤ 16 * a2ParamBits m d T_max * subEx := by
        dsimp [exB, subEx]
        clear h1 h2 hread hag hstage ih
        nlinarith
      have hbnd := a2_arith_unary (a2ExprFactor_ge_64 idxE) hKp8
        (subExtra := subEx) (extraU := 5) (extraB := exB)
        (by dsimp [subEx]; omega) hu hb (by omega) hexB_le
      refine ⟨trivial, ?_, ?_⟩
      · simpa [Nat.add_assoc] using hbnd.1
      · dsimp [exB, subEx] at hbnd
        simpa [Nat.add_assoc] using hbnd.2
  | readLocal var idxE ih =>
      simp only [maxTableExpr] at htm
      have ih' := ih htm
      rcases h1 : evalIntExpr inpSub fdSub wsSub idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max idxE) with ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at ih'
      rcases ih' with ⟨heq, hu, hb⟩; subst idx'
      have hread := hag.2.2 var idx
      simp only [trA2Expr, evalIntExpr, h1, h2, hread, a2ExprFactor]
      have hn_pos := natBitLength_pos var
      set subEx := natBitLength var + intBitLength idx + intBitLength (wsSub.read (.localFrame fdSub var idx))
      have hex_le : subEx ≤ 16 * a2ParamBits m d T_max * subEx :=
        le_mul_of_one_le_left (Nat.zero_le subEx) (by omega)
      have hbnd := a2_arith_unary (a2ExprFactor_ge_64 idxE) hKp8
        (subExtra := subEx) (extraU := 1) (extraB := subEx)
        (by dsimp [subEx]; omega) hu hb (by omega) hex_le
      refine ⟨trivial, hbnd.1, ?_⟩
      dsimp [subEx] at hbnd
      simpa [Nat.add_assoc] using hbnd.2
  | activeRatNum hE cE ih₁ ih₂ =>
      simp only [maxTableExpr, max_le_iff] at htm
      have ih1' := ih₁ htm.1; have ih2' := ih₂ htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub hE with ⟨hv, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max hE) with ⟨hv', u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpSub fdSub wsSub cE with ⟨cv, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max cE) with ⟨cv', u'₂, b'₂⟩
      simp only [h1, h2] at ih1'; rcases ih1' with ⟨heq1, hu₁, hb₁⟩; subst hv'
      simp only [h3, h4] at ih2'; rcases ih2' with ⟨heq2, hu₂, hb₂⟩; subst cv'
      obtain ⟨uA, bA, haddr, haddr_bl, huA, hbA⟩ :=
        eval_addr2DA2 hstage inpSim (2 + fdSub) wsSim (hag.1 5 (by omega)) h2 h4
      set addrVal : ℤ :=
        if 0 ≤ hv ∧ hv < (m : ℤ) ∧ 0 ≤ cv ∧ cv < (d : ℤ) then hv * (d : ℤ) + cv + 1 else 0
      set outVal : ℤ :=
        if _hh : 0 ≤ hv ∧ hv.toNat ∈ inpSub.activeHandles then
          if hc : 0 ≤ cv ∧ cv.toNat < d then
            (inpSub.activeRatCoords hv.toNat ⟨cv.toNat, hc.2⟩).num
          else 0
        else 0
      have hv_eq : wsSim.read (.heap 6 addrVal) = outVal := by
        dsimp [outVal]
        rw [hag.1 6 (by omega) addrVal]
        rcases hstage with ⟨_, _, _, _, hact, _, _, hr60, _, hcoords⟩
        rw [hact]
        by_cases hin : 0 ≤ hv ∧ hv < (m : ℤ) ∧ 0 ≤ cv ∧ cv < (d : ℤ)
        · rcases hin with ⟨hh0, hhm, hc0, hcd⟩
          have hh_mem : 0 ≤ hv ∧ hv.toNat ∈ Finset.range m := ⟨hh0, Finset.mem_range.mpr (by omega)⟩
          have hc_lt : 0 ≤ cv ∧ cv.toNat < d := ⟨hc0, by omega⟩
          have haddr_pos : addrVal = ((hv.toNat * d + cv.toNat + 1 : ℕ) : ℤ) := by
            dsimp [addrVal]
            rw [if_pos ⟨hh0, hhm, hc0, hcd⟩]
            have hh_c : (hv.toNat : ℤ) = hv := Int.toNat_of_nonneg hh0
            have hc_c : (cv.toNat : ℤ) = cv := Int.toNat_of_nonneg hc0
            push_cast; rw [hh_c, hc_c]
          rw [if_pos hh_mem, dif_pos hc_lt, haddr_pos]
          exact (hcoords hv.toNat (by omega) ⟨cv.toNat, hc_lt.2⟩).1
        · have hzero : addrVal = 0 := by dsimp [addrVal]; exact if_neg hin
          rw [hzero, hr60]
          split_ifs with hh_mem hc_lt
          · exfalso; apply hin
            have := Finset.mem_range.mp hh_mem.2
            exact ⟨hh_mem.1, by omega, hc_lt.1, by omega⟩
          · rfl
          · rfl
      simp only [trA2Expr, evalIntExpr, h1, h3, haddr, hv_eq, a2ExprFactor]
      have hn6 : natBitLength 6 = 3 := by decide
      rw [hn6]
      have hK_le : natBitLength m + natBitLength d + 8 ≤ a2ParamBits m d T_max := by
        unfold a2ParamBits; omega
      have haddr_K : intBitLength addrVal ≤ a2ParamBits m d T_max := le_trans haddr_bl hK_le
      have hbA_K : bA ≤ 2 * b'₁ + 2 * b'₂ + 16 * a2ParamBits m d T_max * (intBitLength hv + intBitLength cv + 4) := by
        have hmul_le := Nat.mul_le_mul_right (intBitLength hv + intBitLength cv + 4)
          (Nat.mul_le_mul_left 16 hK_le)
        omega
      have hbnd := a2_arith_rat2d (a2ExprFactor_ge_64 hE) (a2ExprFactor_ge_64 cE) hKp8
        (intBitLength_pos hv) (intBitLength_pos cv) (intBitLength_pos outVal) haddr_K
        hu₁ hu₂ hb₁ hb₂ huA hbA_K (extraTailU := 1) (extraTailB := 3 + intBitLength outVal)
        (by omega) (by omega)
      refine ⟨rfl, hbnd.1, ?_⟩
      have h_assoc : bA + 3 + intBitLength addrVal + intBitLength outVal =
          bA + intBitLength addrVal + (3 + intBitLength outVal) := by omega
      rw [h_assoc]
      exact hbnd.2
  | activeRatDen hE cE ih₁ ih₂ =>
      simp only [maxTableExpr, max_le_iff] at htm
      have ih1' := ih₁ htm.1; have ih2' := ih₂ htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub hE with ⟨hv, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max hE) with ⟨hv', u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpSub fdSub wsSub cE with ⟨cv, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max cE) with ⟨cv', u'₂, b'₂⟩
      simp only [h1, h2] at ih1'; rcases ih1' with ⟨heq1, hu₁, hb₁⟩; subst hv'
      simp only [h3, h4] at ih2'; rcases ih2' with ⟨heq2, hu₂, hb₂⟩; subst cv'
      obtain ⟨uA, bA, haddr, haddr_bl, huA, hbA⟩ :=
        eval_addr2DA2 hstage inpSim (2 + fdSub) wsSim (hag.1 5 (by omega)) h2 h4
      set addrVal : ℤ :=
        if 0 ≤ hv ∧ hv < (m : ℤ) ∧ 0 ≤ cv ∧ cv < (d : ℤ) then hv * (d : ℤ) + cv + 1 else 0
      set outVal : ℤ :=
        if _hh : 0 ≤ hv ∧ hv.toNat ∈ inpSub.activeHandles then
          if hc : 0 ≤ cv ∧ cv.toNat < d then
            ((inpSub.activeRatCoords hv.toNat ⟨cv.toNat, hc.2⟩).den : ℤ)
          else 1
        else 1
      have hv_eq : wsSim.read (.heap 7 addrVal) + 1 = outVal := by
        dsimp [outVal]
        rw [hag.1 7 (by omega) addrVal]
        rcases hstage with ⟨_, _, _, _, hact, _, _, _, hr70, hcoords⟩
        rw [hact]
        by_cases hin : 0 ≤ hv ∧ hv < (m : ℤ) ∧ 0 ≤ cv ∧ cv < (d : ℤ)
        · rcases hin with ⟨hh0, hhm, hc0, hcd⟩
          have hh_mem : 0 ≤ hv ∧ hv.toNat ∈ Finset.range m := ⟨hh0, Finset.mem_range.mpr (by omega)⟩
          have hc_lt : 0 ≤ cv ∧ cv.toNat < d := ⟨hc0, by omega⟩
          have haddr_pos : addrVal = ((hv.toNat * d + cv.toNat + 1 : ℕ) : ℤ) := by
            dsimp [addrVal]
            rw [if_pos ⟨hh0, hhm, hc0, hcd⟩]
            have hh_c : (hv.toNat : ℤ) = hv := Int.toNat_of_nonneg hh0
            have hc_c : (cv.toNat : ℤ) = cv := Int.toNat_of_nonneg hc0
            push_cast; rw [hh_c, hc_c]
          rw [if_pos hh_mem, dif_pos hc_lt, haddr_pos]
          exact (hcoords hv.toNat (by omega) ⟨cv.toNat, hc_lt.2⟩).2
        · have hzero : addrVal = 0 := by dsimp [addrVal]; exact if_neg hin
          rw [hzero, hr70]
          split_ifs with hh_mem hc_lt
          · exfalso; apply hin
            have := Finset.mem_range.mp hh_mem.2
            exact ⟨hh_mem.1, by omega, hc_lt.1, by omega⟩
          · norm_num
          · norm_num
      have hd_pos : 1 ≤ outVal := by
        dsimp [outVal]
        split_ifs with hh_mem hc_lt
        · exact_mod_cast (inpSub.activeRatCoords hv.toNat ⟨cv.toNat, hc_lt.2⟩).pos
        · omega
        · omega
      have hread7_bl : intBitLength (wsSim.read (.heap 7 addrVal)) ≤ intBitLength outVal + 1 := by
        have habs : (wsSim.read (.heap 7 addrVal)).natAbs ≤ outVal.natAbs := by omega
        exact intBitLength_mono_natAbs habs
      simp only [trA2Expr, evalIntExpr, h1, h3, haddr, a2ExprFactor]
      have hn7 : natBitLength 7 = 3 := by decide
      have hl1 : intBitLength 1 = 2 := by decide
      rw [hn7, hl1]
      have hK_le : natBitLength m + natBitLength d + 8 ≤ a2ParamBits m d T_max := by
        unfold a2ParamBits; omega
      have haddr_K : intBitLength addrVal ≤ a2ParamBits m d T_max := le_trans haddr_bl hK_le
      have hbA_K : bA ≤ 2 * b'₁ + 2 * b'₂ + 16 * a2ParamBits m d T_max * (intBitLength hv + intBitLength cv + 4) := by
        have hmul_le := Nat.mul_le_mul_right (intBitLength hv + intBitLength cv + 4)
          (Nat.mul_le_mul_left 16 hK_le)
        omega
      set br7 := intBitLength (wsSim.read (.heap 7 addrVal))
      have hbnd := a2_arith_rat2d (a2ExprFactor_ge_64 hE) (a2ExprFactor_ge_64 cE) hKp8
        (intBitLength_pos hv) (intBitLength_pos cv) (intBitLength_pos outVal) haddr_K
        hu₁ hu₂ hb₁ hb₂ huA hbA_K (extraTailU := 3) (extraTailB := 3 + br7 + 2 + br7 + 2)
        (by omega) (by dsimp [br7]; omega)
      refine ⟨hv_eq, ?_, ?_⟩
      · simpa [Nat.add_assoc] using hbnd.1
      · have h_assoc : bA + 3 + intBitLength addrVal + br7 + 2 + br7 + 2 =
            bA + intBitLength addrVal + (3 + br7 + 2 + br7 + 2) := by omega
        rw [h_assoc]
        exact hbnd.2
  | extraRatNum idxE _ =>
      have hex := hstage.2.2.2.2.2.1
      rcases h1 : evalIntExpr inpSub fdSub wsSub idxE with ⟨idx, u₀, b₀⟩
      have hv0 : listGetIntD inpSub.extraRats idx 0 = 0 := by
        rw [hex]; unfold listGetIntD; split_ifs <;> simp
      simp only [trA2Expr, evalIntExpr, h1, hv0, Rat.num_zero, a2ExprFactor]
      have hb0 := evalIntExpr_val_bitLen_le inpSub fdSub wsSub idxE
      rw [h1] at hb0
      have hl0 : intBitLength 0 = 1 := by decide
      rw [hl0]
      have hbnd := a2_arith_extra (a2ExprFactor_ge_64 idxE) hKp8 hb0.2.1
        (u₀ := u₀) (subEx := intBitLength idx + 1) (exU := 1) (exB := 1) (by omega) (by omega)
      refine ⟨trivial, hbnd.1, ?_⟩
      simpa [Nat.add_assoc] using hbnd.2
  | extraRatDen idxE _ =>
      have hex := hstage.2.2.2.2.2.1
      rcases h1 : evalIntExpr inpSub fdSub wsSub idxE with ⟨idx, u₀, b₀⟩
      have hv0 : listGetIntD inpSub.extraRats idx 0 = 0 := by
        rw [hex]; unfold listGetIntD; split_ifs <;> simp
      simp only [trA2Expr, evalIntExpr, h1, hv0, Rat.den_zero, Nat.cast_one, a2ExprFactor]
      have hb0 := evalIntExpr_val_bitLen_le inpSub fdSub wsSub idxE
      rw [h1] at hb0
      have hl1 : intBitLength 1 = 2 := by decide
      rw [hl1]
      have hbnd := a2_arith_extra (a2ExprFactor_ge_64 idxE) hKp8 hb0.2.1
        (u₀ := u₀) (subEx := intBitLength idx + 2) (exU := 1) (exB := 2) (by omega) (by omega)
      refine ⟨trivial, hbnd.1, ?_⟩
      simpa [Nat.add_assoc] using hbnd.2
  | neg e₀ ih =>
      simp only [maxTableExpr] at htm
      have ih' := ih htm
      rcases h1 : evalIntExpr inpSub fdSub wsSub e₀ with ⟨v, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₀) with ⟨v', u'₀, b'₀⟩
      simp only [h1, h2] at ih'; rcases ih' with ⟨heq, hu, hb⟩; subst v'
      simp only [trA2Expr, evalIntExpr, h1, h2, a2ExprFactor]
      have hbv := intBitLength_pos v
      have hbnd := a2_arith_unary (a2ExprFactor_ge_64 e₀) hKp8
        (extraU := 1) (extraB := intBitLength v) (subExtra := intBitLength v)
        hbv hu hb (by omega)
        (le_mul_of_one_le_left (Nat.zero_le _) (by omega))
      exact ⟨trivial, hbnd.1, hbnd.2⟩
  | add e₁ e₂ ih₁ ih₂ =>
      simp only [maxTableExpr, max_le_iff] at htm
      have ih1' := ih₁ htm.1; have ih2' := ih₂ htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpSub fdSub wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih1'; rcases ih1' with ⟨heq1, hu₁, hb₁⟩; subst v'₁
      simp only [h3, h4] at ih2'; rcases ih2' with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      simp only [trA2Expr, evalIntExpr, h1, h2, h3, h4, a2ExprFactor]
      have hbv1 := intBitLength_pos v₁
      have hbnd := a2_arith_binary (M := 64) (by omega) (a2ExprFactor_ge_64 e₁) (a2ExprFactor_ge_64 e₂)
        hKp8 hu₁ hu₂ hb₁ hb₂ (extraU := 1) (extraB := intBitLength v₁ + intBitLength v₂)
        (subExtra := intBitLength v₁ + intBitLength v₂) (by omega)
        (sub_le_mul_param hKp8 62 (by omega)) (by omega)
      exact ⟨trivial, hbnd.1, by simpa [Nat.add_assoc] using hbnd.2⟩
  | sub e₁ e₂ ih₁ ih₂ =>
      simp only [maxTableExpr, max_le_iff] at htm
      have ih1' := ih₁ htm.1; have ih2' := ih₂ htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpSub fdSub wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih1'; rcases ih1' with ⟨heq1, hu₁, hb₁⟩; subst v'₁
      simp only [h3, h4] at ih2'; rcases ih2' with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      simp only [trA2Expr, evalIntExpr, h1, h2, h3, h4, a2ExprFactor]
      have hbv1 := intBitLength_pos v₁
      have hbnd := a2_arith_binary (M := 64) (by omega) (a2ExprFactor_ge_64 e₁) (a2ExprFactor_ge_64 e₂)
        hKp8 hu₁ hu₂ hb₁ hb₂ (extraU := 1) (extraB := intBitLength v₁ + intBitLength v₂)
        (subExtra := intBitLength v₁ + intBitLength v₂) (by omega)
        (sub_le_mul_param hKp8 62 (by omega)) (by omega)
      exact ⟨trivial, hbnd.1, by simpa [Nat.add_assoc] using hbnd.2⟩
  | mul e₁ e₂ ih₁ ih₂ =>
      simp only [maxTableExpr, max_le_iff] at htm
      have ih1' := ih₁ htm.1; have ih2' := ih₂ htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpSub fdSub wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih1'; rcases ih1' with ⟨heq1, hu₁, hb₁⟩; subst v'₁
      simp only [h3, h4] at ih2'; rcases ih2' with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      simp only [trA2Expr, evalIntExpr, h1, h2, h3, h4, a2ExprFactor]
      have hbv1 := intBitLength_pos v₁
      have hbv2 := intBitLength_pos v₂
      have hpos_m : 1 ≤ intBitLength v₁ * intBitLength v₂ := Nat.mul_pos hbv1 hbv2
      have hbnd := a2_arith_binary (M := 64) (by omega) (a2ExprFactor_ge_64 e₁) (a2ExprFactor_ge_64 e₂)
        hKp8 hu₁ hu₂ hb₁ hb₂ (extraU := 1) (extraB := intBitLength v₁ * intBitLength v₂)
        (subExtra := intBitLength v₁ * intBitLength v₂) (by omega)
        (sub_le_mul_param hKp8 62 (by omega)) (by omega)
      exact ⟨trivial, hbnd.1, hbnd.2⟩
  | div e₁ e₂ ih₁ ih₂ =>
      simp only [maxTableExpr, max_le_iff] at htm
      have ih1' := ih₁ htm.1; have ih2' := ih₂ htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpSub fdSub wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih1'; rcases ih1' with ⟨heq1, hu₁, hb₁⟩; subst v'₁
      simp only [h3, h4] at ih2'; rcases ih2' with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      simp only [trA2Expr, evalIntExpr, h1, h2, h3, h4, a2ExprFactor]
      have hbv1 := intBitLength_pos v₁
      have hbv2 := intBitLength_pos v₂
      have hpos_m : 1 ≤ intBitLength v₁ * intBitLength v₂ := Nat.mul_pos hbv1 hbv2
      have hbnd := a2_arith_binary (M := 64) (by omega) (a2ExprFactor_ge_64 e₁) (a2ExprFactor_ge_64 e₂)
        hKp8 hu₁ hu₂ hb₁ hb₂ (extraU := 1) (extraB := intBitLength v₁ * intBitLength v₂)
        (subExtra := intBitLength v₁ * intBitLength v₂) (by omega)
        (sub_le_mul_param hKp8 62 (by omega)) (by omega)
      exact ⟨trivial, hbnd.1, hbnd.2⟩
  | mod e₁ e₂ ih₁ ih₂ =>
      simp only [maxTableExpr, max_le_iff] at htm
      have ih1' := ih₁ htm.1; have ih2' := ih₂ htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpSub fdSub wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih1'; rcases ih1' with ⟨heq1, hu₁, hb₁⟩; subst v'₁
      simp only [h3, h4] at ih2'; rcases ih2' with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      simp only [trA2Expr, evalIntExpr, h1, h2, h3, h4, a2ExprFactor]
      have hbv1 := intBitLength_pos v₁
      have hbv2 := intBitLength_pos v₂
      have hpos_m : 1 ≤ intBitLength v₁ * intBitLength v₂ := Nat.mul_pos hbv1 hbv2
      have hbnd := a2_arith_binary (M := 64) (by omega) (a2ExprFactor_ge_64 e₁) (a2ExprFactor_ge_64 e₂)
        hKp8 hu₁ hu₂ hb₁ hb₂ (extraU := 1) (extraB := intBitLength v₁ * intBitLength v₂)
        (subExtra := intBitLength v₁ * intBitLength v₂) (by omega)
        (sub_le_mul_param hKp8 62 (by omega)) (by omega)
      exact ⟨trivial, hbnd.1, hbnd.2⟩

theorem evalBitCond_trA2Cond {d m B T_max : ℕ} {wsBase wsSub wsSim : WordStore}
    {inpSub : BitRAMInput d} {fdSub : ℕ}
    (inpSim : BitRAMInput d)
    (hstage : StagingA2Matches m B wsBase inpSub)
    (hT : 1 ≤ T_max)
    (hag : AgreesForA2Expr wsBase T_max wsSub fdSub wsSim) :
    ∀ c : BitCondExpr,
      maxTableCond c ≤ T_max →
      let rSub := evalBitCond inpSub fdSub wsSub c
      let rSim := evalBitCond inpSim (2 + fdSub) wsSim (trA2Cond T_max c)
      rSim.1 = rSub.1 ∧
      rSim.2.1 ≤ a2CondFactor c * rSub.2.1 ∧
      rSim.2.2 ≤ a2CondFactor c * a2ParamBits m d T_max * rSub.2.2 := by
  have hKp8 : 8 ≤ a2ParamBits m d T_max := by unfold a2ParamBits; omega
  intro c htm
  dsimp only
  induction c with
  | intEq e₁ e₂ =>
      simp only [maxTableCond, max_le_iff] at htm
      have he1 := evalIntExpr_trA2Expr inpSim hstage hT hag e₁ htm.1
      have he2 := evalIntExpr_trA2Expr inpSim hstage hT hag e₂ htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpSub fdSub wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at he1; rcases he1 with ⟨heq1, hu₁, hb₁⟩; subst v'₁
      simp only [h3, h4] at he2; rcases he2 with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      simp only [trA2Cond, evalBitCond, h1, h2, h3, h4, a2CondFactor]
      have hbv1 := intBitLength_pos v₁
      have hbnd := a2_arith_binary (M := 16) (by omega) (a2ExprFactor_ge_64 e₁) (a2ExprFactor_ge_64 e₂)
        hKp8 hu₁ hu₂ hb₁ hb₂ (extraU := 1) (extraB := intBitLength v₁ + intBitLength v₂)
        (subExtra := intBitLength v₁ + intBitLength v₂) (by omega)
        (sub_le_mul_param hKp8 14 (by omega)) (by omega)
      exact ⟨trivial, hbnd.1, by simpa [Nat.add_assoc] using hbnd.2⟩
  | intLt e₁ e₂ =>
      simp only [maxTableCond, max_le_iff] at htm
      have he1 := evalIntExpr_trA2Expr inpSim hstage hT hag e₁ htm.1
      have he2 := evalIntExpr_trA2Expr inpSim hstage hT hag e₂ htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpSub fdSub wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at he1; rcases he1 with ⟨heq1, hu₁, hb₁⟩; subst v'₁
      simp only [h3, h4] at he2; rcases he2 with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      simp only [trA2Cond, evalBitCond, h1, h2, h3, h4, a2CondFactor]
      have hbv1 := intBitLength_pos v₁
      have hbnd := a2_arith_binary (M := 16) (by omega) (a2ExprFactor_ge_64 e₁) (a2ExprFactor_ge_64 e₂)
        hKp8 hu₁ hu₂ hb₁ hb₂ (extraU := 1) (extraB := intBitLength v₁ + intBitLength v₂)
        (subExtra := intBitLength v₁ + intBitLength v₂) (by omega)
        (sub_le_mul_param hKp8 14 (by omega)) (by omega)
      exact ⟨trivial, hbnd.1, by simpa [Nat.add_assoc] using hbnd.2⟩
  | intLe e₁ e₂ =>
      simp only [maxTableCond, max_le_iff] at htm
      have he1 := evalIntExpr_trA2Expr inpSim hstage hT hag e₁ htm.1
      have he2 := evalIntExpr_trA2Expr inpSim hstage hT hag e₂ htm.2
      rcases h1 : evalIntExpr inpSub fdSub wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpSub fdSub wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at he1; rcases he1 with ⟨heq1, hu₁, hb₁⟩; subst v'₁
      simp only [h3, h4] at he2; rcases he2 with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      simp only [trA2Cond, evalBitCond, h1, h2, h3, h4, a2CondFactor]
      have hbv1 := intBitLength_pos v₁
      have hbnd := a2_arith_binary (M := 16) (by omega) (a2ExprFactor_ge_64 e₁) (a2ExprFactor_ge_64 e₂)
        hKp8 hu₁ hu₂ hb₁ hb₂ (extraU := 1) (extraB := intBitLength v₁ + intBitLength v₂)
        (subExtra := intBitLength v₁ + intBitLength v₂) (by omega)
        (sub_le_mul_param hKp8 14 (by omega)) (by omega)
      exact ⟨trivial, hbnd.1, by simpa [Nat.add_assoc] using hbnd.2⟩
  | not c₀ ih =>
      simp only [maxTableCond] at htm
      have ih' := ih htm
      rcases h1 : evalBitCond inpSub fdSub wsSub c₀ with ⟨r, u₀, b₀⟩
      rcases h2 : evalBitCond inpSim (2 + fdSub) wsSim (trA2Cond T_max c₀) with ⟨r', u'₀, b'₀⟩
      simp only [h1, h2] at ih'; rcases ih' with ⟨heq, hu, hb⟩; subst r'
      simp only [trA2Cond, evalBitCond, h1, h2, a2CondFactor]
      have hbnd := a2_arith_not (a2CondFactor_pos c₀) hKp8 hu hb
      exact ⟨trivial, hbnd.1, hbnd.2⟩
  | and c₁ c₂ ih₁ ih₂ =>
      simp only [maxTableCond, max_le_iff] at htm
      have ih1' := ih₁ htm.1; have ih2' := ih₂ htm.2
      rcases h1 : evalBitCond inpSub fdSub wsSub c₁ with ⟨r₁, u₁, b₁⟩
      rcases h2 : evalBitCond inpSim (2 + fdSub) wsSim (trA2Cond T_max c₁) with ⟨r'₁, u'₁, b'₁⟩
      rcases h3 : evalBitCond inpSub fdSub wsSub c₂ with ⟨r₂, u₂, b₂⟩
      rcases h4 : evalBitCond inpSim (2 + fdSub) wsSim (trA2Cond T_max c₂) with ⟨r'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih1'; rcases ih1' with ⟨heq1, hu₁, hb₁⟩; subst r'₁
      simp only [h3, h4] at ih2'; rcases ih2' with ⟨heq2, hu₂, hb₂⟩; subst r'₂
      simp only [trA2Cond, evalBitCond, h1, h2, h3, h4, a2CondFactor]
      have hbnd := a2_arith_binary (M := 16) (by omega) (a2CondFactor_pos c₁) (a2CondFactor_pos c₂)
        hKp8 hu₁ hu₂ hb₁ hb₂ (extraU := 1) (extraB := 1) (subExtra := 1) (by omega) (by omega) (by omega)
      exact ⟨trivial, hbnd.1, hbnd.2⟩
  | or c₁ c₂ ih₁ ih₂ =>
      simp only [maxTableCond, max_le_iff] at htm
      have ih1' := ih₁ htm.1; have ih2' := ih₂ htm.2
      rcases h1 : evalBitCond inpSub fdSub wsSub c₁ with ⟨r₁, u₁, b₁⟩
      rcases h2 : evalBitCond inpSim (2 + fdSub) wsSim (trA2Cond T_max c₁) with ⟨r'₁, u'₁, b'₁⟩
      rcases h3 : evalBitCond inpSub fdSub wsSub c₂ with ⟨r₂, u₂, b₂⟩
      rcases h4 : evalBitCond inpSim (2 + fdSub) wsSim (trA2Cond T_max c₂) with ⟨r'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih1'; rcases ih1' with ⟨heq1, hu₁, hb₁⟩; subst r'₁
      simp only [h3, h4] at ih2'; rcases ih2' with ⟨heq2, hu₂, hb₂⟩; subst r'₂
      simp only [trA2Cond, evalBitCond, h1, h2, h3, h4, a2CondFactor]
      have hbnd := a2_arith_binary (M := 16) (by omega) (a2CondFactor_pos c₁) (a2CondFactor_pos c₂)
        hKp8 hu₁ hu₂ hb₁ hb₂ (extraU := 1) (extraB := 1) (subExtra := 1) (by omega) (by omega) (by omega)
      exact ⟨trivial, hbnd.1, hbnd.2⟩

end UL.C12LVE
