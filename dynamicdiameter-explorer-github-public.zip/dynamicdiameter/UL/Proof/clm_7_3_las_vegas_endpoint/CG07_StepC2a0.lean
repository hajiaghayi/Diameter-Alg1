import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2c3a_SubSteps
set_option autoImplicit false
set_option maxHeartbeats 800000

namespace UL.C12StepC2

open UL.C12LVE

open UL
open UL.Proof_lem_A_1

theorem c2sc_ws_write_live (w : WordStore) (l : RAMCellLoc) (v : ℤ) :
    (w.write l v).live = insert l w.live := rfl
theorem c2sc_ws_write_vals (w : WordStore) (l : RAMCellLoc) (v : ℤ) :
    (w.write l v).vals = Function.update w.vals l v := rfl
theorem c2sc_ws_free_live (w : WordStore) (l : RAMCellLoc) :
    (w.free l).live = w.live.erase l := rfl
theorem c2sc_ws_free_vals (w : WordStore) (l : RAMCellLoc) :
    (w.free l).vals = Function.update w.vals l 0 := rfl

theorem c2sc_ws_free4_live (w : WordStore) (l₁ l₂ l₃ l₄ x : RAMCellLoc) :
    x ∈ ((((w.free l₁).free l₂).free l₃).free l₄).live ↔
      x ≠ l₄ ∧ x ≠ l₃ ∧ x ≠ l₂ ∧ x ≠ l₁ ∧ x ∈ w.live := by
  simp only [c2sc_ws_free_live, Finset.mem_erase, and_assoc]

theorem c2sc_ws_free4_vals_ne (w : WordStore) {l₁ l₂ l₃ l₄ x : RAMCellLoc}
    (h₄ : x ≠ l₄) (h₃ : x ≠ l₃) (h₂ : x ≠ l₂) (h₁ : x ≠ l₁) :
    ((((w.free l₁).free l₂).free l₃).free l₄).vals x = w.vals x := by
  rw [c2sc_ws_free_vals, Function.update_of_ne h₄,
      c2sc_ws_free_vals, Function.update_of_ne h₃,
      c2sc_ws_free_vals, Function.update_of_ne h₂,
      c2sc_ws_free_vals, Function.update_of_ne h₁]

theorem c2sc_ws_wf_free_live (w : WordStore) (lw lf x : RAMCellLoc) (v : ℤ) :
    x ∈ ((w.free lf).write lw v).live ↔ x = lw ∨ (x ≠ lf ∧ x ∈ w.live) := by
  simp only [c2sc_ws_write_live, c2sc_ws_free_live, Finset.mem_insert, Finset.mem_erase]

theorem c2sc_ws_wf_free_vals_ne (w : WordStore) {lw lf x : RAMCellLoc} (v : ℤ)
    (hw : x ≠ lw) (hf : x ≠ lf) :
    ((w.free lf).write lw v).vals x = w.vals x := by
  rw [c2sc_ws_write_vals, Function.update_of_ne hw, c2sc_ws_free_vals, Function.update_of_ne hf]

theorem c2sc_ws_write_eq_free_write (w : WordStore) (l : RAMCellLoc) (v : ℤ) :
    w.write l v = (w.free l).write l v := by
  cases w with
  | mk lv vl =>
      unfold WordStore.write WordStore.free; dsimp only
      congr 1
      · ext x; simp only [Finset.mem_insert, Finset.mem_erase]
        constructor
        · rintro (rfl | h); · exact Or.inl rfl
          by_cases hx : x = l; · exact Or.inl hx
          · exact Or.inr ⟨hx, h⟩
        · rintro (rfl | ⟨_, h⟩); · exact Or.inl rfl
          · exact Or.inr h
      · funext x; by_cases hx : x = l
        · subst hx; simp only [Function.update_self]
        · simp only [Function.update_of_ne hx]

/-! ### Linear-time memory reclamation `exec_cleanupA2Stmt` via `bitSize` Lyapunov potential -/

structure C2CleanupLoopInv (wsStart : WordStore) (highSid : ℕ)
    (sidOfEnc : ℤ → Option ℕ) (s : ℕ) (ws : WordStore) : Prop where
  wf : WellFormedWS ws
  has12_1 : (.heap 12 1 : RAMCellLoc) ∈ ws.live ∧ ws.vals (.heap 12 1) = (s : ℤ)
  tab10_13 : ∀ (t : ℕ), (t = 10 ∨ t = 13) → ∀ e : ℤ,
    ((∃ s' < s, sidOfEnc e = some s') → (.heap t e : RAMCellLoc) ∉ ws.live) ∧
    ((¬ ∃ s' < s, sidOfEnc e = some s') →
      ((.heap t e : RAMCellLoc) ∈ ws.live ↔ (.heap t e : RAMCellLoc) ∈ wsStart.live) ∧
      ws.vals (.heap t e) = wsStart.vals (.heap t e))
  tab14_15_16 : ∀ (t : ℕ), (t = 14 ∨ t = 15 ∨ t = 16) → ∀ z : ℤ,
    (0 ≤ z ∧ z.toNat < s → (.heap t z : RAMCellLoc) ∉ ws.live) ∧
    (¬ (0 ≤ z ∧ z.toNat < s) →
      ((.heap t z : RAMCellLoc) ∈ ws.live ↔ (.heap t z : RAMCellLoc) ∈ wsStart.live) ∧
      ws.vals (.heap t z) = wsStart.vals (.heap t z))
  other_loc : ∀ loc : RAMCellLoc,
    loc ≠ .heap 12 1 →
    (∀ e, loc ≠ .heap 10 e ∧ loc ≠ .heap 13 e) →
    (∀ z, loc ≠ .heap 14 z ∧ loc ≠ .heap 15 z ∧ loc ≠ .heap 16 z) →
    (loc ∈ ws.live ↔ loc ∈ wsStart.live) ∧ ws.vals loc = wsStart.vals loc

def c2CleanupStepAStmt : BitRAMStmt :=
  .ite (.intEq (.readHeap 16 (.readHeap 12 (.lit 1))) (.lit 1))
    (.seq (.freeHeap 10 (.readHeap 15 (.readHeap 12 (.lit 1))))
    (.seq (.freeHeap 13 (.readHeap 15 (.readHeap 12 (.lit 1))))
    (.seq (.freeHeap 15 (.readHeap 12 (.lit 1)))
          (.freeHeap 16 (.readHeap 12 (.lit 1))))))
    .skip

def c2CleanupLoopBody : BitRAMStmt :=
  .seq c2CleanupStepAStmt
    (.seq (.freeHeap 14 (.readHeap 12 (.lit 1)))
          (.writeHeap 12 (.lit 1) (.add (.readHeap 12 (.lit 1)) (.lit 1))))

theorem c2_exec_cleanupStepA {d T_max S_max : ℕ}
    {wsBaseNew wsSubHeap wsStart : WordStore}
    {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (inpSim : BitRAMInput d)
    (hinv : A2SimInv wsBaseNew T_max S_max wsSubHeap wsStart highSid sidOfEnc encOfSid freeStack)
    {s S_bits C_cell C_bit : ℕ} (hs_lt : s < highSid)
    (hs_bl : intBitLength (s : ℤ) ≤ S_bits)
    (stCur : BitRAMExecState)
    (hInv : C2CleanupLoopInv wsStart highSid sidOfEnc s stCur.words)
    (hpCC : stCur.peakCellSpace ≤ C_cell)
    (hpBC : stCur.peakBitSpace ≤ C_bit) :
    ∃ stA : BitRAMExecState,
      RunsTo inpSim [.stmt c2CleanupStepAStmt] stCur stA ∧
      stA.words = (if s ∉ freeStack then
        (((stCur.words.free (.heap 10 (encOfSid s))).free (.heap 13 (encOfSid s))).free
          (.heap 15 (s : ℤ))).free (.heap 16 (s : ℤ))
        else stCur.words) ∧
      stA.words.cellCount ≤ stCur.words.cellCount ∧
      stA.words.bitSize ≤ stCur.words.bitSize ∧
      stA.frameDepth = stCur.frameDepth ∧
      stA.remainingBits = stCur.remainingBits ∧
      stA.unitCost ≤ stCur.unitCost + 20 ∧
      stA.bitCost + 8 * stA.words.bitSize ≤
        stCur.bitCost + 8 * stCur.words.bitSize + 14 * S_bits + 96 ∧
      stA.peakCellSpace ≤ C_cell ∧
      stA.peakBitSpace ≤ C_bit := by
  have h10 : natBitLength 10 = 4 := by decide
  have h12 : natBitLength 12 = 4 := by decide
  have h13 : natBitLength 13 = 4 := by decide
  have h15 : natBitLength 15 = 4 := by decide
  have h16 : natBitLength 16 = 5 := by decide
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  have hr_12_1 : stCur.words.read (.heap 12 1) = (s : ℤ) := by
    rw [wordStore_read_eq_vals hInv.wf]; exact hInv.has12_1.2
  have hn_lt_s : ¬ (0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < s) := by simp
  have h16_cur := (hInv.tab14_15_16 16 (Or.inr (Or.inr rfl)) (s : ℤ)).2 hn_lt_s
  have hr_16_s : stCur.words.read (.heap 16 (s : ℤ)) = wsStart.read (.heap 16 (s : ℤ)) := by
    rw [wordStore_read_eq_vals hInv.wf, wordStore_read_eq_vals hinv.wfSim]; exact h16_cur.2
  by_cases hnf : s ∉ freeStack
  · have hz_ok : 0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack := by
      simp [hs_lt, hnf]
    have h15_16 := (hinv.tab15_16_spec (s : ℤ)).1 hz_ok
    simp only [Int.toNat_natCast] at h15_16
    have hr16_eq1 : stCur.words.read (.heap 16 (s : ℤ)) = 1 := by
      rw [hr_16_s, wordStore_read_eq_vals hinv.wfSim]; exact h15_16.2.2.2
    have hcondA : evalBitCond inpSim stCur.frameDepth stCur.words
        (.intEq (.readHeap 16 (.readHeap 12 (.lit 1))) (.lit 1)) =
        (true, 5, 21 + 2 * intBitLength (s : ℤ)) := by
      simp only [evalBitCond, evalIntExpr, hr_12_1, hr16_eq1]
      simp only [h12, h16, hl1]
      exact Prod.ext rfl (Prod.ext rfl (by ring))
    set e := encOfSid s
    have h15_cur := (hInv.tab14_15_16 15 (Or.inr (Or.inl rfl)) (s : ℤ)).2 hn_lt_s
    have hm15_cur : (.heap 15 (s : ℤ) : RAMCellLoc) ∈ stCur.words.live :=
      h15_cur.1.mpr h15_16.1
    have hv15_cur : stCur.words.vals (.heap 15 (s : ℤ)) = e :=
      h15_cur.2.trans h15_16.2.1
    have hr15_cur : stCur.words.read (.heap 15 (s : ℤ)) = e := by
      rw [wordStore_read_eq_vals hInv.wf]; exact hv15_cur
    let stA0 : BitRAMExecState :=
      { stCur with unitCost := stCur.unitCost + 5, bitCost := stCur.bitCost + (21 + 2 * intBitLength (s : ℤ)) }
    obtain ⟨stA1, hf1, hwA1, hfdA1, hrbA1, hucA1, hbcA1, hpCA1, hpBA1⟩ :=
      exec_freeHeap_ceil inpSim 10 (.readHeap 15 (.readHeap 12 (.lit 1))) stA0 hpCC hpBC
        (idx := e) (u₁ := 3) (b₁ := 12 + 2 * intBitLength (s : ℤ) + intBitLength e)
        (evalIntLe_read_read12 inpSim stA0.frameDepth stA0.words 15 1 _ _
          (b := 12 + 2 * intBitLength (s : ℤ) + intBitLength e) hr_12_1 hr15_cur h15 hl1 (le_of_eq (by ring)))
    have hrA1_12_1 : stA1.words.read (.heap 12 1) = (s : ℤ) := by
      rw [hwA1, wordStore_read_free_ne _ (by simp)]; exact hr_12_1
    have hrA1_15_s : stA1.words.read (.heap 15 (s : ℤ)) = e := by
      rw [hwA1, wordStore_read_free_ne _ (by simp)]; exact hr15_cur
    obtain ⟨stA2, hf2, hwA2, hfdA2, hrbA2, hucA2, hbcA2, hpCA2, hpBA2⟩ :=
      exec_freeHeap_ceil inpSim 13 (.readHeap 15 (.readHeap 12 (.lit 1))) stA1 hpCA1 hpBA1
        (idx := e) (u₁ := 3) (b₁ := 12 + 2 * intBitLength (s : ℤ) + intBitLength e)
        (evalIntLe_read_read12 inpSim stA1.frameDepth stA1.words 15 1 _ _
          (b := 12 + 2 * intBitLength (s : ℤ) + intBitLength e) hrA1_12_1 hrA1_15_s h15 hl1 (le_of_eq (by ring)))
    have hrA2_12_1 : stA2.words.read (.heap 12 1) = (s : ℤ) := by
      rw [hwA2, wordStore_read_free_ne _ (by simp)]; exact hrA1_12_1
    obtain ⟨stA3, hf3, hwA3, hfdA3, hrbA3, hucA3, hbcA3, hpCA3, hpBA3⟩ :=
      exec_freeHeap_ceil inpSim 15 (.readHeap 12 (.lit 1)) stA2 hpCA2 hpBA2
        (idx := (s : ℤ)) (u₁ := 2) (b₁ := 8 + intBitLength (s : ℤ))
        (evalIntLe_readHeap_lit inpSim stA2.frameDepth stA2.words 12 1 _
          (b := 8 + intBitLength (s : ℤ)) hrA2_12_1 h12 hl1 (le_of_eq (by ring)))
    have hrA3_12_1 : stA3.words.read (.heap 12 1) = (s : ℤ) := by
      rw [hwA3, wordStore_read_free_ne _ (by simp)]; exact hrA2_12_1
    obtain ⟨stA4, hf4, hwA4, hfdA4, hrbA4, hucA4, hbcA4, hpCA4, hpBA4⟩ :=
      exec_freeHeap_ceil inpSim 16 (.readHeap 12 (.lit 1)) stA3 hpCA3 hpBA3
        (idx := (s : ℤ)) (u₁ := 2) (b₁ := 8 + intBitLength (s : ℤ))
        (evalIntLe_readHeap_lit inpSim stA3.frameDepth stA3.words 12 1 _
          (b := 8 + intBitLength (s : ℤ)) hrA3_12_1 h12 hl1 (le_of_eq (by ring)))
    have hiteA : RunsTo inpSim [.stmt c2CleanupStepAStmt] stCur stA4 := by
      unfold c2CleanupStepAStmt
      apply RunsTo.ite; rw [hcondA]; dsimp only; simp only [↓reduceIte]
      exact RunsTo.seq hf1 (RunsTo.seq hf2 (RunsTo.seq hf3 hf4))
    have hm15_A2 : (.heap 15 (s : ℤ) : RAMCellLoc) ∈ stA2.words.live := by
      rw [hwA2, hwA1]; dsimp [stA0]
      simp only [c2sc_ws_free_live, Finset.mem_erase]
      exact ⟨by simp, by simp, hm15_cur⟩
    have hv15_A2 : stA2.words.vals (.heap 15 (s : ℤ)) = e := by
      rw [hwA2, hwA1]; dsimp [stA0]
      rw [c2sc_ws_free_vals, Function.update_of_ne (by simp), c2sc_ws_free_vals, Function.update_of_ne (by simp)]
      exact hv15_cur
    have hdrop15 := bitSize_free_mem hm15_A2
    rw [hv15_A2] at hdrop15
    have hwA1' : stA1.words = stCur.words.free (.heap 10 e) := hwA1
    have hb_chain : stA4.words.bitSize + intBitLength e ≤ stCur.words.bitSize := by
      have b4 := bitSize_free_le stA3.words (.heap 16 (s : ℤ))
      have b2 := bitSize_free_le stA1.words (.heap 13 e)
      have b1 := bitSize_free_le stCur.words (.heap 10 e)
      rw [← hwA4] at b4; rw [← hwA3] at hdrop15; rw [← hwA2] at b2; rw [← hwA1'] at b1
      linarith only [b4, hdrop15, b2, b1]
    have hc_chain : stA4.words.cellCount ≤ stCur.words.cellCount := by
      have c4 := cellCount_free_le stA3.words (.heap 16 (s : ℤ))
      have c3 := cellCount_free_le stA2.words (.heap 15 (s : ℤ))
      have c2 := cellCount_free_le stA1.words (.heap 13 e)
      have c1 := cellCount_free_le stCur.words (.heap 10 e)
      rw [← hwA4] at c4; rw [← hwA3] at c3; rw [← hwA2] at c2; rw [← hwA1'] at c1
      linarith only [c4, c3, c2, c1]
    refine ⟨stA4, hiteA, by rw [if_pos hnf, hwA4, hwA3, hwA2, hwA1],
      hc_chain, by linarith only [hb_chain],
      by rw [hfdA4, hfdA3, hfdA2, hfdA1],
      by rw [hrbA4, hrbA3, hrbA2, hrbA1],
      ?_, ?_, hpCA4, hpBA4⟩
    · have h0_uc : stA0.unitCost = stCur.unitCost + 5 := rfl
      linarith only [h0_uc, hucA1, hucA2, hucA3, hucA4]
    · have h0_bc : stA0.bitCost = stCur.bitCost + (21 + 2 * intBitLength (s : ℤ)) := rfl
      rw [h10] at hbcA1; rw [h13] at hbcA2; rw [h15] at hbcA3; rw [h16] at hbcA4
      linarith only [h0_bc, hbcA1, hbcA2, hbcA3, hbcA4, hb_chain, hs_bl]
  · have hz_not : ¬ (0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack) := by
      simp [hnf]
    have hn16 := ((hinv.tab15_16_spec (s : ℤ)).2 hz_not).2
    have hr16_eq0 : stCur.words.read (.heap 16 (s : ℤ)) = 0 := by
      rw [hr_16_s]; simp [WordStore.read, hn16]
    have hcondA : evalBitCond inpSim stCur.frameDepth stCur.words
        (.intEq (.readHeap 16 (.readHeap 12 (.lit 1))) (.lit 1)) =
        (false, 5, 19 + 2 * intBitLength (s : ℤ)) := by
      simp only [evalBitCond, evalIntExpr, hr_12_1, hr16_eq0]
      simp only [h12, h16, hl0, hl1]
      exact Prod.ext rfl (Prod.ext rfl (by ring))
    let stA : BitRAMExecState :=
      { stCur with unitCost := stCur.unitCost + 5 + 1, bitCost := stCur.bitCost + (19 + 2 * intBitLength (s : ℤ)) + 1 }
    have hiteA : RunsTo inpSim [.stmt c2CleanupStepAStmt] stCur stA := by
      unfold c2CleanupStepAStmt
      apply RunsTo.ite; rw [hcondA]; dsimp only; simp only [Bool.false_eq_true, ↓reduceIte]
      exact RunsTo.skip inpSim _
    refine ⟨stA, hiteA, by rw [if_neg hnf], le_rfl, le_rfl, rfl, rfl, ?_, ?_, hpCC, hpBC⟩
    · dsimp [stA]; clear * -; omega
    · dsimp [stA]; linarith only [hs_bl]

theorem c2_cleanupInv_step {T_max S_max : ℕ}
    {wsBaseNew wsSubHeap wsStart wsCur wsA wsB1 wsB2 : WordStore}
    {highSid s : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBaseNew T_max S_max wsSubHeap wsStart highSid sidOfEnc encOfSid freeStack)
    (hs_lt : s < highSid)
    (hInv : C2CleanupLoopInv wsStart highSid sidOfEnc s wsCur)
    (hwA : wsA = (if s ∉ freeStack then
      (((wsCur.free (.heap 10 (encOfSid s))).free (.heap 13 (encOfSid s))).free
        (.heap 15 (s : ℤ))).free (.heap 16 (s : ℤ))
      else wsCur))
    (hwB1 : wsB1 = wsA.free (.heap 14 (s : ℤ)))
    (hwB2 : wsB2 = wsB1.write (.heap 12 1) ((s + 1 : ℕ) : ℤ)) :
    C2CleanupLoopInv wsStart highSid sidOfEnc (s + 1) wsB2 := by
  have hwfA : WellFormedWS wsA := by
    rw [hwA]; by_cases hnf_s : s ∉ freeStack
    · rw [if_pos hnf_s]
      exact wellFormedWS_free (wellFormedWS_free (wellFormedWS_free (wellFormedWS_free hInv.wf _) _) _) _
    · rw [if_neg hnf_s]; exact hInv.wf
  refine
    { wf := by rw [hwB2, hwB1]; exact wellFormedWS_write (wellFormedWS_free hwfA _) _ _
      has12_1 := by
        rw [hwB2]
        exact ⟨by simp only [c2sc_ws_write_live, Finset.mem_insert, true_or],
               by rw [c2sc_ws_write_vals, Function.update_self]⟩
      tab10_13 := fun t ht e' => by
        have hne12 : (.heap t e' : RAMCellLoc) ≠ .heap 12 1 := by rcases ht with rfl | rfl <;> simp
        have hne14 : (.heap t e' : RAMCellLoc) ≠ .heap 14 (s : ℤ) := by rcases ht with rfl | rfl <;> simp
        have hne15 : (.heap t e' : RAMCellLoc) ≠ .heap 15 (s : ℤ) := by rcases ht with rfl | rfl <;> simp
        have hne16 : (.heap t e' : RAMCellLoc) ≠ .heap 16 (s : ℤ) := by rcases ht with rfl | rfl <;> simp
        rw [hwB2, hwB1]
        refine ⟨fun ⟨s', hs'_lt, hsid'⟩ => ?_, fun hno => ?_⟩
        · rw [c2sc_ws_wf_free_live]
          rintro (heq | ⟨_, hmA⟩)
          · exact hne12 heq
          by_cases heq_s : s' = s
          · subst heq_s
            obtain ⟨_, hnf_s, henc_eq⟩ := hinv.sid_lt e' s' hsid'
            rw [hwA, if_pos hnf_s, c2sc_ws_free4_live, henc_eq] at hmA
            rcases ht with rfl | rfl
            · exact hmA.2.2.2.1 rfl
            · exact hmA.2.2.1 rfl
          · have hlt_old : s' < s := by clear * - hs'_lt heq_s; omega
            have hn_cur := (hInv.tab10_13 t ht e').1 ⟨s', hlt_old, hsid'⟩
            rw [hwA] at hmA
            by_cases hnf_s : s ∉ freeStack
            · rw [if_pos hnf_s, c2sc_ws_free4_live] at hmA; exact hn_cur hmA.2.2.2.2
            · rw [if_neg hnf_s] at hmA; exact hn_cur hmA
        · have hno_old : ¬ ∃ s' < s, sidOfEnc e' = some s' :=
            fun ⟨s', hlt, hs⟩ => hno ⟨s', Nat.lt_succ_of_lt hlt, hs⟩
          have h0 := (hInv.tab10_13 t ht e').2 hno_old
          rw [c2sc_ws_wf_free_live, c2sc_ws_wf_free_vals_ne _ _ hne12 hne14]
          rw [hwA]; by_cases hnf_s : s ∉ freeStack
          · rw [if_pos hnf_s]
            have hne_e : e' ≠ encOfSid s := by
              intro hh; subst hh
              exact hno ⟨s, Nat.lt_succ_self s, hinv.enc_sid s hs_lt hnf_s⟩
            have hne10 : (.heap t e' : RAMCellLoc) ≠ .heap 10 (encOfSid s) := by
              rcases ht with rfl | rfl <;> simp [hne_e]
            have hne13 : (.heap t e' : RAMCellLoc) ≠ .heap 13 (encOfSid s) := by
              rcases ht with rfl | rfl <;> simp [hne_e]
            rw [c2sc_ws_free4_live, c2sc_ws_free4_vals_ne _ hne16 hne15 hne13 hne10]
            exact ⟨by simp only [ne_eq, hne12, hne14, hne16, hne15, hne13, hne10, not_false_eq_true, true_and, false_or]; exact h0.1,
                   h0.2⟩
          · rw [if_neg hnf_s]
            exact ⟨by simp only [ne_eq, hne12, hne14, not_false_eq_true, true_and, false_or]; exact h0.1,
                   h0.2⟩
      tab14_15_16 := fun t ht z => by
        have hne12 : (.heap t z : RAMCellLoc) ≠ .heap 12 1 := by rcases ht with rfl | rfl | rfl <;> simp
        have hne10 : ∀ x, (.heap t z : RAMCellLoc) ≠ .heap 10 x := by intro x; rcases ht with rfl | rfl | rfl <;> simp
        have hne13 : ∀ x, (.heap t z : RAMCellLoc) ≠ .heap 13 x := by intro x; rcases ht with rfl | rfl | rfl <;> simp
        rw [hwB2, hwB1]
        refine ⟨fun ⟨hz0, hlt_s1⟩ => ?_, fun hno => ?_⟩
        · rw [c2sc_ws_wf_free_live]
          rintro (heq | ⟨hne14_cur, hmA⟩)
          · exact hne12 heq
          by_cases heq_z : z = (s : ℤ)
          · subst heq_z
            rcases ht with rfl | rfl | rfl
            · exact hne14_cur rfl
            · rw [hwA] at hmA; by_cases hnf_s : s ∉ freeStack
              · rw [if_pos hnf_s, c2sc_ws_free4_live] at hmA; exact hmA.2.1 rfl
              · rw [if_neg hnf_s] at hmA
                have hz_not : ¬ (0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack) := by simp [hnf_s]
                have hn15_st := ((hinv.tab15_16_spec (s : ℤ)).2 hz_not).1
                have hcur15 := (hInv.tab14_15_16 15 (Or.inr (Or.inl rfl)) (s : ℤ)).2 (by simp)
                exact hn15_st (hcur15.1.mp hmA)
            · rw [hwA] at hmA; by_cases hnf_s : s ∉ freeStack
              · rw [if_pos hnf_s, c2sc_ws_free4_live] at hmA; exact hmA.1 rfl
              · rw [if_neg hnf_s] at hmA
                have hz_not : ¬ (0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack) := by simp [hnf_s]
                have hn16_st := ((hinv.tab15_16_spec (s : ℤ)).2 hz_not).2
                have hcur16 := (hInv.tab14_15_16 16 (Or.inr (Or.inr rfl)) (s : ℤ)).2 (by simp)
                exact hn16_st (hcur16.1.mp hmA)
          · have hlt_s : z.toNat < s := by
              clear * - hz0 hlt_s1 heq_z
              have : z.toNat ≠ s := fun hh => heq_z (by omega)
              omega
            have hn_cur := (hInv.tab14_15_16 t ht z).1 ⟨hz0, hlt_s⟩
            rw [hwA] at hmA; by_cases hnf_s : s ∉ freeStack
            · rw [if_pos hnf_s, c2sc_ws_free4_live] at hmA; exact hn_cur hmA.2.2.2.2
            · rw [if_neg hnf_s] at hmA; exact hn_cur hmA
        · have hne_z : z ≠ (s : ℤ) := by intro hh; subst hh; exact hno ⟨Nat.cast_nonneg s, by simp⟩
          have hno_old : ¬ (0 ≤ z ∧ z.toNat < s) :=
            fun ⟨hz0, hlt⟩ => hno ⟨hz0, Nat.lt_succ_of_lt hlt⟩
          have h0 := (hInv.tab14_15_16 t ht z).2 hno_old
          have hne14_s : (.heap t z : RAMCellLoc) ≠ .heap 14 (s : ℤ) := by simp [hne_z]
          have hne15_s : (.heap t z : RAMCellLoc) ≠ .heap 15 (s : ℤ) := by simp [hne_z]
          have hne16_s : (.heap t z : RAMCellLoc) ≠ .heap 16 (s : ℤ) := by simp [hne_z]
          rw [c2sc_ws_wf_free_live, c2sc_ws_wf_free_vals_ne _ _ hne12 hne14_s]
          rw [hwA]; by_cases hnf_s : s ∉ freeStack
          · rw [if_pos hnf_s, c2sc_ws_free4_live, c2sc_ws_free4_vals_ne _ hne16_s hne15_s (hne13 _) (hne10 _)]
            exact ⟨by simp only [ne_eq, hne12, hne14_s, hne16_s, hne15_s, hne13 _, hne10 _, not_false_eq_true, true_and, false_or]; exact h0.1,
                   h0.2⟩
          · rw [if_neg hnf_s]
            exact ⟨by simp only [ne_eq, hne12, hne14_s, not_false_eq_true, true_and, false_or]; exact h0.1,
                   h0.2⟩
      other_loc := fun loc hne12 h10_13 h14_16 => by
        have h0 := hInv.other_loc loc hne12 h10_13 h14_16
        have hne14 := (h14_16 (s : ℤ)).1
        have hne15 := (h14_16 (s : ℤ)).2.1
        have hne16 := (h14_16 (s : ℤ)).2.2
        have hne10 := (h10_13 (encOfSid s)).1
        have hne13 := (h10_13 (encOfSid s)).2
        rw [hwB2, hwB1, c2sc_ws_wf_free_live, c2sc_ws_wf_free_vals_ne _ _ hne12 hne14]
        rw [hwA]; by_cases hnf_s : s ∉ freeStack
        · rw [if_pos hnf_s, c2sc_ws_free4_live, c2sc_ws_free4_vals_ne _ hne16 hne15 hne13 hne10]
          exact ⟨by simp only [ne_eq, hne12, hne14, hne16, hne15, hne13, hne10, not_false_eq_true, true_and, false_or]; exact h0.1,
                 h0.2⟩
        · rw [if_neg hnf_s]
          exact ⟨by simp only [ne_eq, hne12, hne14, not_false_eq_true, true_and, false_or]; exact h0.1,
                 h0.2⟩ }


end UL.C12StepC2
