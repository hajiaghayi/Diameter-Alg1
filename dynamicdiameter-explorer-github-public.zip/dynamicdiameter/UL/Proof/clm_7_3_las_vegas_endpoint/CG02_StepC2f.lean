import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG02_StepC2f0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.CG02StepC2

open UL.C12StepC2

open UL.C12LVE
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

theorem exec_c07StepC2Stmt_spec
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    {progA2 : BitRAMStmt} {spaceA2 bitLenA2 : ℕ → ℕ → ℝ}
    (hsp_ge1 : 1 ≤ spaceA2 d B)
    (hBc_ge : bitLenA2 d B ≤ (B_cert : ℝ))
    (hW : c07WordSizeReq d s₀_d B B_cert L K_max (max 4 (maxTableStmt progA2)) ≤ W)
    {ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d s₀_d)}
    (hctor_cert : ∀ hist sufPref ltCoords P₀ bs built,
      2 * s₀_d ≤ P₀.card →
      (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
        ∃ outA2 : BitRAMExecOutcome,
          C12CertifiedNodeSpec s₀_d B progA2 spaceA2 bitLenA2
            (c12ReplayHistory d hist) ltCoords P₀ bs built outA2)
    (jSrc : JSource) :
    let T_max := max 4 (maxTableStmt progA2)
    let F := max 64 (a2StmtFactor progA2)
    let spCeil := Nat.ceil (spaceA2 d B) + 1
    C11StepC2Spec n L B B_cert K_max W
      (n * c07A2CellPerN d spCeil)
      (n * c07A2BitPerN d L T_max spCeil W)
      (c07StepC2UnitFactorFull d L F spCeil)
      (c07StepC2BitFactor d L T_max F spCeil W)
      ctor (c07StepC2Stmt d s₀_d L B T_max progA2 jSrc) jSrc := by
  dsimp only
  set T_max := max 4 (maxTableStmt progA2)
  set F := max 64 (a2StmtFactor progA2)
  set spCeil := Nat.ceil (spaceA2 d B) + 1
  obtain ⟨hW_pre, hW_a2, hW_post⟩ := c07WordSizeReq_bounds hW
  obtain ⟨hL2, _, h2n_pow, hpow_4n⟩ := clog_two_mul_bounds hn
  rw [← hL] at hL2 h2n_pow hpow_4n
  unfold C11StepC2Spec
  intro inp C_cell C_bit hist P P' ltCoords' qMap' op retHVal
    hReplay hwfP hwfP' _hleg happ hcCeil_a2 hbCeil_a2
    prefNodes acc R wsHeap regs bs₁ tailBits out st
    curNodes j
    hj_lt hm_2s0 hm_n hR_sub hR_adm hbuild hmid hbuf hfd hrf hbnd hbits hpC hpB
  dsimp only
  set m := R.card
  set S_H := R.image (handleOfLifetime P')
  have hm1 : 1 ≤ m := by clear * - hs₀1 hm_2s0; omega
  have hm_pow : m ≤ 2 ^ L := by clear * - hm_n h2n_pow; omega
  have hj_val : JSourceValid jSrc := jSourceValid_of_holds hbuf.1
  have hcCeil_std : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    have : 0 ≤ n * c07A2CellPerN d spCeil := Nat.zero_le _
    linarith only [hcCeil_a2, this]
  have hbCeil_std : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    have : 0 ≤ n * c07A2BitPerN d L T_max spCeil W := Nat.zero_le _
    linarith only [hbCeil_a2, this]
  -- Extract A.2 certificate specification from `ctor.buildWithBits`
  obtain ⟨outA2, hcert⟩ :=
    hctor_cert hist acc ltCoords' R bs₁ out hm_2s0 (fun lt hlt => (hR_adm lt hlt).2) hbuild
  rw [hReplay] at hcert
  -- Stage 1: Pre-A.2 (`syncJToHeap0Regs ; sortBufViaUnitTree1Regs ; stageBufForA2Regs`)
  obtain ⟨wsPre, regsPre, sPre, hmPre, brPre, hstagePre, hr010_Pre, hr50_Pre, hr110_Pre,
    hbuf_Pre, hclean8_Pre, htree1_Pre, hlive567_Pre, hheap9_Pre, hunchPre⟩ :=
    exec_c07StepC2PreA2Regs hd1 hn hL hB1 hj_lt hW_pre hwfP hwfP' happ hmid.hlt_sync'
      hm1 hm_n hR_sub hmid.mod hcCeil_std hbCeil_std hbnd hmid.coords_stored
      hmid.stage567_clean hmid.heap9_bound hbuf
  obtain ⟨stPre, hrunPre, hrfPre, _, hfdPre, hrbPre, hucPre, hbcPre, hpCPre, hpBPre⟩ :=
    sPre st hfd hrf hpC hpB
  have hbitsPre : stPre.remainingBits = bs₁ ++ tailBits := hrbPre.trans hbits
  -- Ghost `S_max` & space/bit-length bounds via `c07_a2_space_ceil_bounds`
  have hsp_le_ceil : spaceA2 d B ≤ (spCeil : ℝ) := by
    have hc : spaceA2 d B ≤ (Nat.ceil (spaceA2 d B) : ℝ) := Nat.le_ceil _
    dsimp only [spCeil]; push_cast; linarith only [hc]
  have hpeakC_m : outA2.peakCellSpace ≤ m * spCeil := by
    have h1 : (outA2.peakCellSpace : ℝ) ≤ (m : ℝ) * (spCeil : ℝ) :=
      hcert.peak_cell.trans (mul_le_mul_of_nonneg_left hsp_le_ceil (Nat.cast_nonneg m))
    exact_mod_cast h1
  have hpeakB_m : outA2.peakBitSpace ≤ m * L * spCeil := by
    have hclog : Nat.clog 2 (2 * m) ≤ L := by
      rw [hL]; exact Nat.clog_mono_right 2 (by clear * - hm_n; omega)
    have hclog_r : (Nat.clog 2 (2 * m) : ℝ) ≤ (L : ℝ) := by exact_mod_cast hclog
    have hsp_nn : (0 : ℝ) ≤ spaceA2 d B := by linarith only [hsp_ge1]
    have hm_cl : (m : ℝ) * (Nat.clog 2 (2 * m) : ℝ) ≤ (m : ℝ) * (L : ℝ) :=
      mul_le_mul_of_nonneg_left hclog_r (Nat.cast_nonneg m)
    have h1 : (outA2.peakBitSpace : ℝ) ≤ ((m : ℝ) * (L : ℝ)) * (spCeil : ℝ) := by
      calc (outA2.peakBitSpace : ℝ)
        _ ≤ ((m : ℝ) * (Nat.clog 2 (2 * m) : ℝ)) * spaceA2 d B := hcert.peak_bit
        _ ≤ ((m : ℝ) * (L : ℝ)) * (spCeil : ℝ) :=
            mul_le_mul hm_cl hsp_le_ceil hsp_nn (by positivity)
    exact_mod_cast h1
  set S_max := max 1 outA2.peakCellSpace
  obtain ⟨hPeakS, hSmax_m1, hSbits_le, hcCeilA2, hbCeilA2⟩ :=
    c07_a2_space_ceil_bounds hn hL hm_n hpeakC_m hpeakB_m hcCeil_a2 hbCeil_a2
  -- Prepare `exec_a2RunExtractAndCleanup` arguments
  set k_blk := out.aux.k_blk
  obtain ⟨hk1, hk_le⟩ := hcert.k_bounds
  have hempSlot_j : EmptyLevelSlot d L j wsHeap :=
    hmid.empty_levels j le_rfl (by clear * - hj_lt; omega)
  have hemp3_Pre : ∀ off < posNodeStride d L,
      (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ wsPre.live := by
    intro off hoff
    rw [(hunchPre (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) (fun h => by cases h) (not_mem_treeSliceLocs_of_ne_tab (by decide))
      (fun _ h => by cases h) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)
      (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))).1]
    exact hempSlot_j.1 off hoff
  obtain ⟨hcard_SH, _, hh_after_enum, _⟩ :=
    c12EnumByKey_handle_and_coords hwfP hwfP' happ hmid.hlt_sync' hR_sub
  have hmin_lt_pow : ∀ r < m, minPopElem S_H r < 2 ^ L := by
    intro r hr
    have hmem : minPopElem S_H r ∈ S_H := (minPopElem_step (hcard_SH.symm ▸ hr)).2.2.2.1
    rcases Finset.mem_image.mp hmem with ⟨lt, hltR, heq_h⟩
    rw [← heq_h]
    exact (hmid.coords_stored.hS _ (ltCoords_eq_qMap_of_active hwfP' hmid.hlt_sync' (hR_sub hltR)).2.1).1
  let rawIdx : ℕ → ℕ := fun p =>
    if p < k_blk * s₀_d then (outA2.words.read (.heap 2 (p : ℤ))).toNat else 0
  have hblk_unp : ∀ (b : Fin k_blk) (t : Fin s₀_d),
      let p := b.val * s₀_d + t.val
      rawIdx p < m ∧
      outA2.words.read (.heap 2 (p : ℤ)) = (rawIdx p : ℤ) ∧
      minPopElem S_H (rawIdx p) = out.aux.birthHandles b t := by
    intro b t p
    have hp_lt : p < k_blk * s₀_d := by
      have h1 : b.val * s₀_d + t.val < (b.val + 1) * s₀_d := by rw [add_mul, one_mul]; exact Nat.add_lt_add_left t.isLt _
      exact lt_of_lt_of_le h1 (Nat.mul_le_mul_right s₀_d b.isLt)
    obtain ⟨idx, hrd2, hblt_eq, _, hbh_eq⟩ := hcert.blk_spec b t
    have hrd_p : outA2.words.read (.heap 2 (p : ℤ)) = (idx.val : ℤ) := hrd2
    have hraw_eq : rawIdx p = idx.val := by
      dsimp only [rawIdx]; rw [if_pos hp_lt, hrd_p]; simp
    refine ⟨hraw_eq ▸ idx.isLt, by rw [hrd_p, hraw_eq], ?_⟩
    rw [hraw_eq, hbh_eq, hblt_eq, hh_after_enum idx]
  have hraw_spec : ∀ p < k_blk * s₀_d,
      rawIdx p < m ∧ outA2.words.read (.heap 2 (p : ℤ)) = (rawIdx p : ℤ) := by
    intro p hp
    have hs0_pos : 0 < s₀_d := hs₀1
    let b : Fin k_blk := ⟨p / s₀_d, (Nat.div_lt_iff_lt_mul hs0_pos).mpr hp⟩
    let t : Fin s₀_d := ⟨p % s₀_d, Nat.mod_lt p hs0_pos⟩
    have hp_eq : b.val * s₀_d + t.val = p := by
      dsimp [b, t]; rw [Nat.mul_comm]; exact Nat.div_add_mod p s₀_d
    have hbt := hblk_unp b t
    dsimp only at hbt
    rw [hp_eq] at hbt
    exact ⟨hbt.1, hbt.2.1⟩
  have hV_nn_cert : 0 ≤ liftVariance (ratPointToEuclidean out.aux.oRat) (out.aux.sRat : ℝ) := by
    rw [← hcert.node_o, ← hcert.node_s, ← hcert.node_V]
    exact out.node.V_nonneg
  have hoA2_int : ∀ c : Fin d,
      let oN := outA2.words.read (.heap 1 (2 * (c.val : ℤ)))
      let oD := outA2.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
      1 ≤ oD ∧ out.aux.oRat c = (oN : ℚ) / (oD : ℚ) ∧
      intBitLength oN ≤ B_cert ∧ intBitLength oD ≤ B_cert := by
    intro c
    obtain ⟨hoD, hoEq, hoNb, hoDb⟩ := hcert.o_spec c
    exact ⟨by omega, hoEq, by exact_mod_cast hoNb.trans hBc_ge, by exact_mod_cast hoDb.trans hBc_ge⟩
  have hsA2_int :
      let sN := outA2.words.read (.heap 1 (2 * (d : ℤ)))
      let sD := outA2.words.read (.heap 1 (2 * (d : ℤ) + 1))
      1 ≤ sD ∧ out.aux.sRat = (sN : ℚ) / (sD : ℚ) ∧
      intBitLength sN ≤ B_cert ∧ intBitLength sD ≤ B_cert := by
    obtain ⟨hsD, hsEq, hsNb, hsDb⟩ := hcert.s_spec
    exact ⟨by omega, hsEq, by exact_mod_cast hsNb.trans hBc_ge, by exact_mod_cast hsDb.trans hBc_ge⟩
  -- Stage 2: A.2 Execution + Node Extraction + Tight Cleanup
  obtain ⟨stClean, wsExt, regsExt, hrunA2, hfdClean, hrfClean, brExt, hrbClean,
    hpCClean, hpBClean, hucClean, hbcClean, hmExt, hgeomExt_raw,
    hr_age_Ext, hr_mb_Ext, hr_kb_Ext, hread_bh_raw, hunused_Ext, hunchExt⟩ :=
    exec_a2RunExtractAndCleanup hd1 hs₀1 hBc1 (by dsimp [T_max]; omega) (Nat.le_of_lt hj_lt)
      hm_pow hk_le hW_a2 (le_max_right 4 _) hmPre brPre hstagePre hcert.run_eq hPeakS
      hcCeilA2 hbCeilA2 hemp3_Pre hr010_Pre hr110_Pre hcert.k_read hmin_lt_pow hbuf_Pre
      (fun p hp => (hraw_spec p hp).1) (fun p hp => (hraw_spec p hp).2)
      hV_nn_cert hoA2_int hsA2_int stPre hfdPre hrfPre hbitsPre hpCPre hpBPre
  have hgeom_Ext : NodeGeomStored d (posNodeStride d L) B_cert j
      out.aux.oRat out.aux.V_num out.aux.V_den out.node.V wsExt := by
    rw [hcert.V_num_eq, hcert.V_den_eq, hcert.node_V, hcert.node_o, hcert.node_s]
    exact hgeomExt_raw
  have hread_bh_Ext : ∀ (b : Fin k_blk) (t : Fin s₀_d),
      wsExt.read (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b.val * s₀_d + t.val)))) =
        (out.aux.birthHandles b t : ℤ) := by
    intro b t
    have hp_lt : b.val * s₀_d + t.val < k_blk * s₀_d := by
      have h1 : b.val * s₀_d + t.val < (b.val + 1) * s₀_d := by rw [add_mul, one_mul]; exact Nat.add_lt_add_left t.isLt _
      exact lt_of_lt_of_le h1 (Nat.mul_le_mul_right s₀_d b.isLt)
    rw [hread_bh_raw _ hp_lt, (hblk_unp b t).2.2]
  -- Transfer Pre -> Ext properties outside `heap 3`
  have hr010_Ext : wsExt.read (.heap 0 10) = (j : ℤ) :=
    (wordStore_read_eq_of_live_vals (hunchExt _ (not_mem_level3WriteLocs_of_ne_tab (by decide)))).trans hr010_Pre
  have hr50_Ext : wsExt.read (.heap 5 0) = (m : ℤ) :=
    (wordStore_read_eq_of_live_vals (hunchExt _ (not_mem_level3WriteLocs_of_ne_tab (by decide)))).trans hr50_Pre
  have hr110_Ext : wsExt.read (.heap 9 110) = (m : ℤ) :=
    (wordStore_read_eq_of_live_vals (hunchExt _ (not_mem_level3WriteLocs_of_ne_tab (by decide)))).trans hr110_Pre
  have hbuf_Ext : ∀ k < m, wsExt.read (.heap 8 (k : ℤ)) = (minPopElem S_H k : ℤ) := fun k hk =>
    (wordStore_read_eq_of_live_vals (hunchExt _ (not_mem_level3WriteLocs_of_ne_tab (by decide)))).trans (hbuf_Pre k hk)
  have hclean8_Ext : ∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsExt.live := fun z hz => by
    rw [(hunchExt _ (not_mem_level3WriteLocs_of_ne_tab (by decide))).1]; exact hclean8_Pre z hz
  have htree1_Ext : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsExt :=
    htree1_Pre.unchanged (fun u _ f _ => hunchExt (.heap 2 (treeCellAddr L 1 u f)) (not_mem_level3WriteLocs_of_ne_tab (by decide)))
  have hlive567_Ext : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ,
      (.heap t z : RAMCellLoc) ∈ wsExt.live → (.heap t z : RAMCellLoc) ∈ stageA2Locs d m := by
    intro t ht z hmE
    have hnt3 : t ≠ 3 := by rcases ht with rfl | rfl | rfl <;> decide
    exact hlive567_Pre t ht z ((hunchExt (.heap t z) (not_mem_level3WriteLocs_of_ne_tab hnt3)).1.mp hmE)
  have hheap9_Ext : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ wsExt.live → ∃ k : ℕ, k < 256 ∧ z = (k : ℤ) :=
    fun z hmE => hheap9_Pre z ((hunchExt (.heap 9 z) (not_mem_level3WriteLocs_of_ne_tab (by decide))).1.mp hmE)
  have hcoords_Ext : ActiveCoordsStored d L B P'.activeHandles qMap' wsExt :=
    hmid.coords_stored.unchanged (fun h' _ c _ f _ =>
      wordStore_read_eq_of_live_vals
        (let uE := hunchExt (.heap 1 (coordCellAddr d h' c f)) (not_mem_level3WriteLocs_of_ne_tab (by decide))
         let uP := hunchPre (.heap 1 (coordCellAddr d h' c f)) (fun h => by cases h) (not_mem_treeSliceLocs_of_ne_tab (by decide))
           (fun _ h => by cases h) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)
           (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
         ⟨uE.1.trans uP.1, uE.2.trans uP.2⟩))
  have hemp4_Ext : ∀ h < 2 ^ L, (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ wsExt.live := by
    intro h hh
    have uE := hunchExt (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) (not_mem_level3WriteLocs_of_ne_tab (by decide))
    have uP := hunchPre (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) (fun hc => by cases hc)
      (not_mem_treeSliceLocs_of_ne_tab (by decide)) (fun _ hc => by cases hc)
      (fun hc => by cases hc) (fun hc => by cases hc) (fun hc => by cases hc)
      (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
    rw [uE.1, uP.1]; exact hempSlot_j.2.1 h hh
  have htree2_Ext : TreeStoredAt L (2 * j + 2) ∅ (fun _ => 0) (fun _ => 1) wsExt :=
    TreeStoredAt.empty L (2 * j + 2) _ _ (fun u hu f hf => by
      have uE := hunchExt (.heap 2 (treeCellAddr L (2 * j + 2) u f)) (not_mem_level3WriteLocs_of_ne_tab (by decide))
      have uP := hunchPre (.heap 2 (treeCellAddr L (2 * j + 2) u f)) (fun hc => by cases hc)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf) (fun _ hc => by cases hc)
        (fun hc => by cases hc) (fun hc => by cases hc) (fun hc => by cases hc)
        (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
      rw [uE.1, uP.1]; exact hempSlot_j.2.2.1 u hu f hf)
  have htree3_Ext : TreeStoredAt L (2 * j + 3) ∅ (fun _ => 0) (fun _ => 1) wsExt :=
    TreeStoredAt.empty L (2 * j + 3) _ _ (fun u hu f hf => by
      have uE := hunchExt (.heap 2 (treeCellAddr L (2 * j + 3) u f)) (not_mem_level3WriteLocs_of_ne_tab (by decide))
      have uP := hunchPre (.heap 2 (treeCellAddr L (2 * j + 3) u f)) (fun hc => by cases hc)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf) (fun _ hc => by cases hc)
        (fun hc => by cases hc) (fun hc => by cases hc) (fun hc => by cases hc)
        (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
      rw [uE.1, uP.1]; exact hempSlot_j.2.2.2 u hu f hf)
  -- Birth-handle active sync, < 2^L, and injectivity
  have hblt_in_R : ∀ (b : Fin k_blk) (t : Fin s₀_d), out.aux.birthLifetimes b t ∈ R :=
    fun b t => (hcert.blk_spec b t).choose_spec.2.2.1
  have hbh_sync : ∀ (b : Fin k_blk) (t : Fin s₀_d),
      handleOfLifetime P' (out.aux.birthLifetimes b t) = out.aux.birthHandles b t := by
    intro b t
    rw [(hcert.blk_spec b t).choose_spec.2.2.2,
        c12LtHandleAfter_eq_handleOfLifetime hwfP hwfP' happ _ (hR_sub (hblt_in_R b t))]
  have hbh_lt_pow : ∀ (b : Fin k_blk) (t : Fin s₀_d), out.aux.birthHandles b t < 2 ^ L := by
    intro b t
    rw [← hbh_sync b t]
    exact (hmid.coords_stored.hS _ (ltCoords_eq_qMap_of_active hwfP' hmid.hlt_sync' (hR_sub (hblt_in_R b t))).2.1).1
  have hbh_inj : Function.Injective2 out.aux.birthHandles := by
    intro b₁ b₂ t₁ t₂ heq
    rw [← hbh_sync b₁ t₁, ← hbh_sync b₂ t₂] at heq
    have hlt_eq := handleOfLifetime_injOn hwfP' (hR_sub (hblt_in_R b₁ t₁)) (hR_sub (hblt_in_R b₂ t₂)) heq
    exact hcert.blt_inj hlt_eq
  have hmin_mem_act : ∀ k < m, minPopElem S_H k ∈ P'.activeHandles := by
    intro k hk
    have hmem : minPopElem S_H k ∈ S_H := (minPopElem_step (hcard_SH.symm ▸ hk)).2.2.2.1
    rcases Finset.mem_image.mp hmem with ⟨lt, hltR, heq_h⟩
    rw [← heq_h]
    exact (ltCoords_eq_qMap_of_active hwfP' hmid.hlt_sync' (hR_sub hltR)).2.1
  -- Stage 3: Post-A.2 (`clearStageA2Regs ; buildTab4Regs ; buildIntactTreeRegs ; buildSjTreeAndResidualBufRegs ; incJFromHeap0Regs`)
  obtain ⟨wsPost, regsPost, sPost, hmPost, brPost, hjHolds_Post, _hr010_Post, hr110_Post,
    hbuf_Post, hclean8_Post, htree1_Post, hclean567_Post, hheap9_Post,
    htab4_Post, htree3_Post, htreeSj_Post, hunchPost⟩ :=
    exec_c07StepC2PostA2Regs hd1 hs₀1 hn hL hB1 hBc1 hj_lt hm_n hk1 hk_le hW_post
      hbh_lt_pow hbh_inj hcard_SH hmin_mem_act hj_val hmExt hcCeil_std hbCeil_std brExt
      hr010_Ext hr50_Ext hr110_Ext hbuf_Ext hclean8_Ext htree1_Ext hlive567_Ext hheap9_Ext
      hcoords_Ext hgeom_Ext hr_kb_Ext hread_bh_Ext hemp4_Ext htree2_Ext htree3_Ext
  obtain ⟨st', hrunPost, hrfPost, _, hfdPost, hrbPost, hucPost, hbcPost, hpCPost, hpBPost⟩ :=
    sPost stClean hfdClean hrfClean hpCClean hpBClean
  -- Total cost bounds via `c07_stepC2_cost_bounds`
  obtain ⟨huc_tot, hbc_tot⟩ :=
    c07_stepC2_cost_bounds (by dsimp [spCeil]; omega) hm_pow hk_le hcert.work_eq
      hSmax_m1 hSbits_le hpeakB_m hucPre hucClean hucPost hbcPre hbcClean hbcPost
  -- Assemble `MidSuffixChainInv` and `StdBufLoopExtra` on `wsPost`
  set vNew : SyncLiveChainNode d (PosDimNodeData d s₀_d) :=
    { built := out, birthPool := R, ageUpdateSteps := ∅ }
  set R' := out.node.residual ltCoords' R
  set newNodes := curNodes ++ [vNew]
  -- Global untouched helper for tables 0(≠10), 1, 2(tid≠1,2j+2,2j+3), 3(i≠j), 4(i≠j)
  have unch_all_other : ∀ loc : RAMCellLoc,
      loc ≠ .heap 0 10 →
      loc ∉ stageA2Locs d m →
      loc ∉ level3WriteLocs (posNodeStride d L) j →
      (∀ h < 2 ^ L, loc ≠ .heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) →
      loc ∉ treeSliceLocs L (2 * j + 3) →
      loc ∉ treeSliceLocs L (2 * j + 2) →
      loc ∉ treeSliceLocs L 1 →
      (∀ z : ℤ, loc ≠ .heap 8 z) →
      (∀ z : ℤ, loc ≠ .heap 9 z) →
      (loc ∈ wsPost.live ↔ loc ∈ wsHeap.live) ∧ wsPost.vals loc = wsHeap.vals loc := by
    intro loc n010 nSt nL3 n4 ns3 ns2 ns1 n8 n9
    have u3 := hunchPost loc n010 nSt n4 ns3 ns2 ns1 n8 n9
    have u2 := hunchExt loc nL3
    have u1 := hunchPre loc n010 ns1 n8 (n9 110) (n9 111) (n9 112) nSt
    exact ⟨u3.1.trans (u2.1.trans u1.1), u3.2.trans (u2.2.trans u1.2)⟩
  have hr00_Post : wsPost.read (.heap 0 0) = retHVal := by
    have u := unch_all_other (.heap 0 0) (by decide)
      (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
      (not_mem_level3WriteLocs_of_ne_tab (by decide))
      (fun _ _ hc => by cases hc)
      (not_mem_treeSliceLocs_of_ne_tab (by decide))
      (not_mem_treeSliceLocs_of_ne_tab (by decide))
      (not_mem_treeSliceLocs_of_ne_tab (by decide))
      (fun _ hc => by cases hc) (fun _ hc => by cases hc)
    exact (wordStore_read_eq_of_live_vals u).trans hmid.read_00
  have hcoords_Post : ActiveCoordsStored d L B P'.activeHandles qMap' wsPost :=
    hmid.coords_stored.unchanged (fun h' _ c _ f _ =>
      wordStore_read_eq_of_live_vals
        (unch_all_other (.heap 1 (coordCellAddr d h' c f)) (fun hc => by cases hc)
          (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
          (not_mem_level3WriteLocs_of_ne_tab (by decide))
          (fun _ _ hc => by cases hc)
          (not_mem_treeSliceLocs_of_ne_tab (by decide))
          (not_mem_treeSliceLocs_of_ne_tab (by decide))
          (not_mem_treeSliceLocs_of_ne_tab (by decide))
          (fun _ hc => by cases hc) (fun _ hc => by cases hc)))
  have htree0_Post : TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsPost :=
    hmid.tree_active.unchanged (fun u hu f hf =>
      unch_all_other (.heap 2 (treeCellAddr L 0 u f)) (fun hc => by cases hc)
        (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
        (not_mem_level3WriteLocs_of_ne_tab (by decide))
        (fun _ _ hc => by cases hc)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf)
        (not_mem_treeSliceLocs_of_ne (by decide) hu hf)
        (fun _ hc => by cases hc) (fun _ hc => by cases hc))
  -- Other levels `i ≠ j` untouched between `wsHeap` and `wsPost`
  have other_level_unch : ∀ {i : ℕ} (hne : i ≠ j),
      (∀ off < posNodeStride d L,
        ((.heap 3 (nodeCellAddr (posNodeStride d L) i off) : RAMCellLoc) ∈ wsPost.live ↔
          (.heap 3 (nodeCellAddr (posNodeStride d L) i off) : RAMCellLoc) ∈ wsHeap.live) ∧
        wsPost.vals (.heap 3 (nodeCellAddr (posNodeStride d L) i off)) =
          wsHeap.vals (.heap 3 (nodeCellAddr (posNodeStride d L) i off))) ∧
      (∀ h' < 2 ^ L,
        ((.heap 4 (((i * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ wsPost.live ↔
          (.heap 4 (((i * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ wsHeap.live) ∧
        wsPost.vals (.heap 4 (((i * 2 ^ L + h' : ℕ) : ℤ))) =
          wsHeap.vals (.heap 4 (((i * 2 ^ L + h' : ℕ) : ℤ)))) ∧
      (∀ u < 2 ^ (L + 1), ∀ f < 4,
        ((.heap 2 (treeCellAddr L (2 * i + 2) u f) : RAMCellLoc) ∈ wsPost.live ↔
          (.heap 2 (treeCellAddr L (2 * i + 2) u f) : RAMCellLoc) ∈ wsHeap.live) ∧
        wsPost.vals (.heap 2 (treeCellAddr L (2 * i + 2) u f)) =
          wsHeap.vals (.heap 2 (treeCellAddr L (2 * i + 2) u f))) ∧
      (∀ u < 2 ^ (L + 1), ∀ f < 4,
        ((.heap 2 (treeCellAddr L (2 * i + 3) u f) : RAMCellLoc) ∈ wsPost.live ↔
          (.heap 2 (treeCellAddr L (2 * i + 3) u f) : RAMCellLoc) ∈ wsHeap.live) ∧
        wsPost.vals (.heap 2 (treeCellAddr L (2 * i + 3) u f)) =
          wsHeap.vals (.heap 2 (treeCellAddr L (2 * i + 3) u f))) := by
    intro i hne
    refine ⟨fun off hoff => ?_, fun h' hh' => ?_, fun u hu f hf => ?_, fun u hu f hf => ?_⟩
    · exact unch_all_other (.heap 3 (nodeCellAddr (posNodeStride d L) i off)) (fun hc => by cases hc)
        (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
        (not_mem_level3WriteLocs_of_ne hne hoff)
        (fun _ _ hc => by cases hc)
        (not_mem_treeSliceLocs_of_ne_tab (by decide))
        (not_mem_treeSliceLocs_of_ne_tab (by decide))
        (not_mem_treeSliceLocs_of_ne_tab (by decide))
        (fun _ hc => by cases hc) (fun _ hc => by cases hc)
    · exact unch_all_other (.heap 4 (((i * 2 ^ L + h' : ℕ) : ℤ))) (fun hc => by cases hc)
        (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
        (not_mem_level3WriteLocs_of_ne_tab (by decide))
        (fun h₂ hh₂ => ne_tab4_of_ne_level hne hh' hh₂)
        (not_mem_treeSliceLocs_of_ne_tab (by decide))
        (not_mem_treeSliceLocs_of_ne_tab (by decide))
        (not_mem_treeSliceLocs_of_ne_tab (by decide))
        (fun _ hc => by cases hc) (fun _ hc => by cases hc)
    · exact unch_all_other (.heap 2 (treeCellAddr L (2 * i + 2) u f)) (fun hc => by cases hc)
        (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
        (not_mem_level3WriteLocs_of_ne_tab (by decide))
        (fun _ _ hc => by cases hc)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf)
        (fun _ hc => by cases hc) (fun _ hc => by cases hc)
    · exact unch_all_other (.heap 2 (treeCellAddr L (2 * i + 3) u f)) (fun hc => by cases hc)
        (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
        (not_mem_level3WriteLocs_of_ne_tab (by decide))
        (fun _ _ hc => by cases hc)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf)
        (fun _ hc => by cases hc) (fun _ hc => by cases hc)
  -- Level `j` `LevelStoredInv` on `wsPost`
  have tab3_Ext_Post : ∀ off < posNodeStride d L,
      ((.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ wsPost.live ↔
        (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ wsExt.live) ∧
      wsPost.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
        wsExt.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) := fun off _ =>
    hunchPost (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) (fun hc => by cases hc)
      (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
      (fun _ _ hc => by cases hc)
      (not_mem_treeSliceLocs_of_ne_tab (by decide))
      (not_mem_treeSliceLocs_of_ne_tab (by decide))
      (not_mem_treeSliceLocs_of_ne_tab (by decide))
      (fun _ hc => by cases hc) (fun _ hc => by cases hc)
  have hstride_ge : 6 + 2 * d ≤ posNodeStride d L := by
    unfold posNodeStride; have := Nat.zero_le (2 ^ L); omega
  have hstride_p : ∀ p ≤ k_blk * s₀_d, 6 + 2 * d + p < posNodeStride d L := by
    intro p hp; unfold posNodeStride; dsimp only [m, k_blk] at hp hk_le hm_pow; omega
  have hlvl_j : LevelStoredInv n L B B_cert K_max P' ltCoords' qMap' R vNew j wsPost := by
    obtain ⟨rNum, rDen, htreeSj_P, hrBnds_P⟩ := htreeSj_Post
    refine
      { hj_le := Nat.le_of_lt hj_lt
        hm_bounds := ⟨hm_2s0, hm_n⟩
        hage_le := by dsimp [vNew]; push_cast; positivity
        hage_rel := ⟨fun _ => R, rfl, rfl, fun r => Fin.elim0 r⟩
        hnode_o := hcert.node_o
        hnode_s := hcert.node_s
        hnode_V := hcert.node_V
        hcp := hcert.centerpoint
        hk_bounds := ⟨hk1, hk_le⟩
        hk_ratio := hcert.k_ratio
        hbirth_adm := hR_adm
        hgeom := hgeom_Ext.unchanged (fun off hoff =>
          wordStore_read_eq_of_live_vals (tab3_Ext_Post off (lt_of_lt_of_le hoff hstride_ge)))
        read_age := (wordStore_read_eq_of_live_vals (tab3_Ext_Post 0 (lt_of_lt_of_le (by omega) hstride_ge))).trans hr_age_Ext
        read_mbirth := (wordStore_read_eq_of_live_vals (tab3_Ext_Post 1 (lt_of_lt_of_le (by omega) hstride_ge))).trans hr_mb_Ext
        read_kblk := (wordStore_read_eq_of_live_vals (tab3_Ext_Post 2 (lt_of_lt_of_le (by omega) hstride_ge))).trans hr_kb_Ext
        hbh_lt := hbh_lt_pow
        hbh_inj := hbh_inj
        hblt_mem := fun b t => ⟨hblt_in_R b t, (hR_adm _ (hblt_in_R b t)).1⟩
        hblt_inj := hcert.blt_inj
        hbh_active_sync := fun b t _ => hbh_sync b t
        read_bh := fun b t => by
          have hp_lt : b.val * s₀_d + t.val < k_blk * s₀_d := by
            have h1 : b.val * s₀_d + t.val < (b.val + 1) * s₀_d := by rw [add_mul, one_mul]; exact Nat.add_lt_add_left t.isLt _
            exact lt_of_lt_of_le h1 (Nat.mul_le_mul_right s₀_d b.isLt)
          exact (wordStore_read_eq_of_live_vals (tab3_Ext_Post _ (hstride_p _ (Nat.le_of_lt hp_lt)))).trans (hread_bh_Ext b t)
        unused_tab3 := fun off hlo hhi => by
          rw [(tab3_Ext_Post off hhi).1]; exact hunused_Ext off hlo hhi
        hcerts := hcert.certs_spec
        tree_Sj := ⟨rNum, rDen, htreeSj_P, fun h hh => by
          rw [hcert.node_o]; exact hrBnds_P h hh⟩
        tab4_spec := fun h hh => by
          rcases htab4_Post h hh with ⟨b, t, heq, hml, hvl⟩ | ⟨hne, hnl⟩
          · exact Or.inl ⟨b, t, hR_sub (hblt_in_R b t), heq, hml, hvl⟩
          · exact Or.inr ⟨fun b t heq => absurd heq (hne b t), hnl⟩
        tree_intact := by
          dsimp only [vNew]
          have hfilt_eq : Finset.univ.filter (fun b : Fin k_blk =>
              ∀ t : Fin s₀_d, out.aux.birthLifetimes b t ∈ activeLifetimes P') = Finset.univ :=
            Finset.filter_true_of_mem (fun b _ t => hR_sub (hblt_in_R b t))
          rw [hfilt_eq, fin_univ_image_val_eq_range k_blk]
          exact ⟨⟨0, Finset.mem_range.mpr hk1⟩, htree3_Post⟩ }
  have hnew_len : newNodes.length = j + 1 := by simp [newNodes, j]
  have hmid_next : MidSuffixChainInv n L B B_cert K_max W P' ltCoords' newNodes qMap' retHVal R' wsPost :=
    { wfP' := hwfP'
      mod := hmPost
      hk_le := by rw [hnew_len]; exact hj_lt
      read_00 := hr00_Post
      hlt_sync' := hmid.hlt_sync'
      hlt_adm' := hmid.hlt_adm'
      coords_stored := hcoords_Post
      tree_active := htree0_Post
      heap9_bound := hheap9_Post
      hbirth_avoid := fun i hi lt hlt r hr => by
        have hi' : i < j + 1 := hnew_len ▸ hi
        rcases Nat.lt_succ_iff_lt_or_eq.mp hi' with hi_lt | rfl
        · have hget_i : newNodes.get ⟨i, hi⟩ = curNodes.get ⟨i, hi_lt⟩ := by
            simp [newNodes, List.get_eq_getElem, List.getElem_append_left hi_lt]
          have hr_lt : r < j := lt_trans hr hi_lt
          have hget_r : newNodes.get ⟨r, lt_trans hr hi⟩ = curNodes.get ⟨r, hr_lt⟩ := by
            simp [newNodes, List.get_eq_getElem, List.getElem_append_left hr_lt]
          rw [hget_i] at hlt
          rw [hget_r]
          exact hmid.hbirth_avoid i hi_lt lt hlt r hr
        · have hget_j : newNodes.get ⟨j, hi⟩ = vNew := by
            simp [newNodes, j, List.get_eq_getElem]
          have hr_lt : r < j := hr
          have hget_r : newNodes.get ⟨r, lt_trans hr hi⟩ = curNodes.get ⟨r, hr_lt⟩ := by
            simp [newNodes, List.get_eq_getElem, List.getElem_append_left hr_lt]
          rw [hget_j] at hlt
          dsimp only [vNew] at hlt
          rw [hmid.hR_eq, mem_chainInput_iff] at hlt
          rw [hget_r]
          exact hlt.2 r hr_lt
      levels := fun i hi => by
        dsimp only
        have hi_le : i ≤ curNodes.length := by rw [hnew_len] at hi; exact Nat.le_of_lt_succ hi
        have hci := chainInput_append_left ltCoords' curNodes [vNew] (activeLifetimes P') hi_le
        dsimp only at hci
        rw [hci]
        rcases lt_or_eq_of_le hi_le with hi_lt | rfl
        · have hget_i : newNodes.get ⟨i, hi⟩ = curNodes.get ⟨i, hi_lt⟩ := by
            simp [newNodes, List.get_eq_getElem, List.getElem_append_left hi_lt]
          rw [hget_i]
          obtain ⟨u3, u4, ut2, ut3⟩ := other_level_unch (ne_of_lt hi_lt)
          exact (hmid.levels i hi_lt).unchanged hmid.mod.wf hmPost.wf u3 u4 ut2 ut3
        · have hget_j : newNodes.get ⟨curNodes.length, hi⟩ = vNew := by
            simp [newNodes, List.get_eq_getElem]
          have hfin_last : (⟨curNodes.length, Nat.lt_succ_of_le hi_le⟩ : Fin (curNodes.length + 1)) =
              Fin.last curNodes.length := rfl
          rw [hget_j, hfin_last, ← hmid.hR_eq]
          exact hlvl_j
      empty_levels := fun i hlo hhi => by
        rw [hnew_len] at hlo
        obtain ⟨u3, u4, ut2, ut3⟩ := other_level_unch (by omega : i ≠ j)
        exact (hmid.empty_levels i (by omega) hhi).unchanged
          (fun off hoff hm => (u3 off hoff).1.mp hm)
          (fun h' hh' hm => (u4 h' hh').1.mp hm)
          (fun u hu f hf hm => (ut2 u hu f hf).1.mp hm)
          (fun u hu f hf hm => (ut3 u hu f hf).1.mp hm)
      stage567_clean := hclean567_Post
      hR_eq := by
        have hci_last := chainInput_append_singleton_last ltCoords' curNodes vNew (activeLifetimes P')
        dsimp only at hci_last
        rw [hci_last, ← hmid.hR_eq] }
  obtain ⟨hres_img_eq, hres_card_eq⟩ :=
    residual_image_handle_eq_filter hwfP' hmid.hlt_sync' hR_sub out.node out.aux.oRat hcert.node_o
  have hbuf_next : StdBufLoopExtra jSrc L P' (j + 1) R' wsPost regsPost := by
    refine ⟨hjHolds_Post, htree1_Post, ?_, ?_, ?_⟩
    · rw [← hres_card_eq]; exact hr110_Post
    · obtain ⟨hSeq', hhSeq'_spec, hhSeq'_img⟩ := hbuf_Post
      refine ⟨hSeq', fun k hk => hhSeq'_spec k (hres_card_eq.symm ▸ hk), ?_⟩
      rw [← hres_card_eq, hhSeq'_img, hres_img_eq]
    · intro z hz
      exact hclean8_Post z (fun k hk => hz k (hres_card_eq ▸ hk))
  exact ⟨st', wsPost, regsPost,
    RunsTo.seq hrunPre (RunsTo.seq hrunA2 hrunPost),
    hfdPost, hrfPost, brPost, hrbPost.trans hrbClean,
    huc_tot, hbc_tot, hpCPost, hpBPost, hmid_next, hbuf_next⟩

end UL.CG02StepC2
