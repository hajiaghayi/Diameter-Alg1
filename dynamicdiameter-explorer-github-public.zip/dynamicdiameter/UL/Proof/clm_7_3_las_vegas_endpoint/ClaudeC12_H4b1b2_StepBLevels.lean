import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b_StepB
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Arithmetic & Bit-Length Helpers for Level `j ≤ K_max` -/

theorem age_card_lt_pow2 {s₀_d n L : ℕ} (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n)
    (h2n_pow : 2 * n ≤ 2 ^ L) {m age : ℕ} (hm_le : m ≤ n)
    (hage_le : (age : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (m : ℝ) / 16) :
    age < 2 ^ L := by
  have hs_ge1 : (1 : ℝ) ≤ 4 * (s₀_d : ℝ) := by
    have : (1 : ℝ) ≤ (s₀_d : ℝ) := by exact_mod_cast hs₀1
    linarith
  have h1 : (1 / (4 * (s₀_d : ℝ))) ≤ 1 := div_le_one_of_le₀ hs_ge1 (by positivity)
  have hm_nonneg : (0 : ℝ) ≤ (m : ℝ) := Nat.cast_nonneg m
  have hprod_le : (1 / (4 * (s₀_d : ℝ))) * (m : ℝ) ≤ 1 * (m : ℝ) :=
    mul_le_mul_of_nonneg_right h1 hm_nonneg
  have hage_r : (age : ℝ) ≤ (n : ℝ) := by
    have hmn : (m : ℝ) ≤ (n : ℝ) := by exact_mod_cast hm_le
    linarith
  have hage_n : age ≤ n := by exact_mod_cast hage_r
  clear * - hage_n hn h2n_pow; omega

theorem tid_bl_of_level {d L K_max tid : ℕ} (htid : tid ≤ 2 * K_max + 3) :
    natBitLength tid ≤ natBitLength ((K_max + 2) * posNodeStride d L) := by
  apply natBitLength_mono
  have hns : 8 ≤ posNodeStride d L := by unfold posNodeStride; exact le_trans (Nat.le_add_right 8 (2 * d)) (Nat.le_add_right _ (2 ^ L))
  nlinarith only [htid, hns]

theorem j_bl_of_level {d L K_max j W : ℕ} (hj : j ≤ K_max + 1)
    (hW : natBitLength ((K_max + 2) * posNodeStride d L) + 8 ≤ W) :
    intBitLength (j : ℤ) ≤ W := by
  have h1 := intBitLength_ofNat_le j
  have hns : 2 ≤ posNodeStride d L := by unfold posNodeStride; exact le_trans (by decide : 2 ≤ 8) (le_trans (Nat.le_add_right 8 (2 * d)) (Nat.le_add_right _ (2 ^ L)))
  have h2 := natBitLength_mono (show j ≤ (K_max + 2) * posNodeStride d L by nlinarith only [hj, hns])
  clear * - h1 h2 hW; omega

theorem treePath_sub_slice {L tid h₀ : ℕ} (_hL1 : 1 ≤ L) (hh₀ : h₀ < 2 ^ L) :
    treePathLocs L tid h₀ ⊆ treeSliceLocs L tid := by
  intro loc hloc
  simp only [treePathLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hloc
  rcases hloc with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
  have hoff_lt : h₀ / 2 ^ k < 2 ^ (L - k) := by
    rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add, Nat.sub_add_cancel (by clear * - hk; omega)]
    exact hh₀
  unfold treeSliceLocs
  exact Finset.mem_image.mpr ⟨(treeIdx L k (h₀ / 2 ^ k), f),
    Finset.mem_product.mpr ⟨Finset.mem_range.mpr (treeIdx_bounds (by clear * - hk; omega) hoff_lt).2,
      Finset.mem_range.mpr hf⟩, rfl⟩

theorem not_in_treeSlice_of_table_ne {L tid t : ℕ} (ht : t ≠ 2) (z : ℤ) :
    (.heap t z : RAMCellLoc) ∉ treeSliceLocs L tid := by
  intro hm
  simp only [treeSliceLocs, Finset.mem_image] at hm
  rcases hm with ⟨_, _, h⟩; cases h; exact ht rfl

theorem not_in_treeSlice_of_tid_ne {L tid₁ tid₂ u f : ℕ}
    (hu : u < 2 ^ (L + 1)) (hf : f < 4) (hne : tid₁ ≠ tid₂) :
    (.heap 2 (treeCellAddr L tid₁ u f) : RAMCellLoc) ∉ treeSliceLocs L tid₂ := by
  intro hm
  simp only [treeSliceLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hm
  rcases hm with ⟨⟨u₂, f₂⟩, ⟨hu₂, hf₂⟩, heq⟩
  injection heq with _ haddr
  exact hne (treeCellAddr_inj hu₂ hf₂ hu hf haddr).1.symm

/-! ### 2. Per-Level Insert Execution (`exec_posDimStepBInsLevel`) -/

theorem exec_posDimStepBInsLevel {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (h2n_pow : 2 * n ≤ 2 ^ L)
    (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P P' : DynamicPointSet d} (hwfP : P.WellFormed n) (hwfP' : P'.WellFormed n)
    {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {id : ℕ} {extName : List Bool} {pt : EuclideanSpace ℝ (Fin d)} {hNew : ℕ}
    (happ : applyDynamicUpdate P (.insert id extName pt) (some hNew) = some P')
    (hhNew_lt : hNew < 2 ^ L) (hhNew_not : hNew ∉ P.activeHandles)
    {qMap qMap' : ℕ → Fin d → ℚ}
    (hqNew : ratPointToEuclidean (qMap' hNew) = pt)
    (hqOld : ∀ h ∈ P.activeHandles, qMap' h = qMap h)
    {k : ℕ} (hk_le : k ≤ K_max) {vecNodes : Fin k → ChainNode d}
    {j : ℕ} (hj : j < k)
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)}
    {u : ℕ} (hu_not : u ∉ v.ageUpdateSteps)
    {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hcoords' : ActiveCoordsStored d L B P'.activeHandles qMap' ws)
    (hhNew_in' : hNew ∈ P'.activeHandles)
    (hlvl : LevelStoredInv n L B B_cert K_max P ltCoords qMap
              (chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩) v j ws)
    (hv_node : v.built.node = vecNodes ⟨j, hj⟩)
    (hr103 : ws.read (.heap 9 103) = (hNew : ℤ))
    (hr104 : ws.read (.heap 9 104) = (j : ℤ))
    (alive_j : Bool)
    (halive_iff : alive_j = true ↔
      ∀ (i : ℕ) (hi : i < j), pt ∉ coreBall (vecNodes ⟨i, Nat.lt_trans hi hj⟩).o (vecNodes ⟨i, Nat.lt_trans hi hj⟩).V)
    (hr105 : ws.read (.heap 9 105) = if alive_j then 1 else 0)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr6 : regs 6 = (hNew : ℤ)) (hr7 : regs 7 = (j : ℤ)) :
    let ltCoords' := Function.update ltCoords P.nextLifetime pt
    let S_old := chainInput ltCoords' vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩
    let S_new := chainInput ltCoords' vecNodes (activeLifetimes P') ⟨j, Nat.lt_succ_of_lt hj⟩
    let v' : SyncLiveChainNode d (PosDimNodeData d s₀_d) :=
      open Classical in
      { v with ageUpdateSteps := if S_new ≠ S_old then insert u v.ageUpdateSteps else v.ageUpdateSteps }
    let alive_next : Bool :=
      open Classical in
      alive_j && decide (pt ∉ coreBall (vecNodes ⟨j, hj⟩).o (vecNodes ⟨j, hj⟩).V)
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (posDimStepBIns d L) ws regs wsEnd regsEnd
        (450 * L + 280 * d + 400) ((80 * L + 64 * d + 120) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap' S_new v' j wsEnd ∧
      v'.ageUpdateSteps.card ≤ 2 ^ L ∧
      (alive_next = true ↔
        ∀ (i : ℕ) (hi : i < j + 1), pt ∉ coreBall (vecNodes ⟨i, lt_of_lt_of_le hi hj⟩).o (vecNodes ⟨i, lt_of_lt_of_le hi hj⟩).V) ∧
      wsEnd.read (.heap 9 105) = (if alive_next then 1 else 0) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .heap 9 105 →
        loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j 0) →
        loc ∉ treeSliceLocs L (2 * j + 2) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  intro ltCoords' S_old S_new v' alive_next
  have hL1 : 1 ≤ L := by
    by_cases h0 : L = 0
    · rw [h0, pow_zero] at h2n_pow; clear * - hn h2n_pow; omega
    · exact Nat.pos_of_ne_zero h0
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hj_K : j ≤ K_max := le_trans (Nat.le_of_lt hj) hk_le
  have hns_ge : 6 + 2 * d ≤ posNodeStride d L := by unfold posNodeStride; omega
  have hage_lt : v.ageUpdateSteps.card < 2 ^ L :=
    age_card_lt_pow2 hs₀1 hn h2n_pow hlvl.hm_bounds.2 hlvl.hage_le
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil0], by linarith only [bs, hbCeil0]⟩
  obtain ⟨hnot_lt, hact', hnext', hh_new, hh_old⟩ := activeLifetimes_insert_spec hwfP hwfP' happ
  have hS_old_eq : S_old = chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩ := by
    apply chainInput_congr_pts
    intro lt hlt
    simp only [activeLifetimes, Finset.mem_image] at hlt
    rcases hlt with ⟨id₀, hid₀, rfl⟩
    exact Function.update_of_ne (Nat.ne_of_lt (hwfP.2.2.2.1 id₀ hid₀)) pt ltCoords
  have hlt_new_pt : ltCoords' P.nextLifetime = pt := Function.update_self P.nextLifetime pt ltCoords
  have hS_new_ite : S_new = open Classical in
      if ∀ (i : ℕ) (hi : i < j), pt ∉ coreBall (vecNodes ⟨i, Nat.lt_trans hi hj⟩).o (vecNodes ⟨i, Nat.lt_trans hi hj⟩).V then
        insert P.nextLifetime S_old
      else
        S_old := by
    dsimp only [S_new, S_old]
    rw [hact', chainInput_insert_eq ltCoords' vecNodes (activeLifetimes P) hnot_lt]
    letI := Classical.propDecidable
    by_cases hc : ∀ (i : ℕ) (hi : i < j), pt ∉ coreBall (vecNodes ⟨i, Nat.lt_trans hi hj⟩).o (vecNodes ⟨i, Nat.lt_trans hi hj⟩).V
    · rw [if_pos (fun i hi => by rw [hlt_new_pt]; exact hc i hi), if_pos hc]
    · rw [if_neg (fun h => hc (fun i hi => by rw [← hlt_new_pt]; exact h i hi)), if_neg hc]
  have hnot_Sold : P.nextLifetime ∉ S_old :=
    fun hm => hnot_lt (chainInput_subset_base _ _ _ _ hm)
  have hbirth_unch : ∀ lt ∈ v.birthPool, ltCoords' lt = ltCoords lt := by
    intro lt hlt
    exact Function.update_of_ne (Nat.ne_of_lt (hlvl.hbirth_adm lt hlt).1) pt ltCoords
  have hcp' : IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
      (paraboloidLiftSet (fun x : v.birthPool => ltCoords' x.1))
      (liftedPoint v.built.node.o v.built.s) := by
    have heq_set : paraboloidLiftSet (fun x : v.birthPool => ltCoords' x.1) =
        paraboloidLiftSet (fun x : v.birthPool => ltCoords x.1) := by
      unfold paraboloidLiftSet; congr 1; funext x
      exact congrArg paraboloidLift (hbirth_unch x.1 x.2)
    rw [heq_set]; exact hlvl.hcp
  have hcerts' : ∀ b : Fin v.built.aux.k_blk,
      IsBlockCertificate ltCoords' v.birthPool (liftedPoint v.built.node.o v.built.s)
        (Finset.univ.image (v.built.aux.birthLifetimes b))
        (fun lt => ∑ t : Fin s₀_d, if v.built.aux.birthLifetimes b t = lt then (v.built.aux.lam b t : ℝ) else 0) := by
    intro b
    obtain ⟨hsub, hnn, hsum1, hsumz⟩ := hlvl.hcerts b
    refine ⟨hsub, hnn, hsum1, ?_⟩
    calc ∑ i ∈ Finset.univ.image (v.built.aux.birthLifetimes b),
          (∑ t : Fin s₀_d, if v.built.aux.birthLifetimes b t = i then (v.built.aux.lam b t : ℝ) else 0) •
            paraboloidLift (ltCoords' i)
      _ = ∑ i ∈ Finset.univ.image (v.built.aux.birthLifetimes b),
          (∑ t : Fin s₀_d, if v.built.aux.birthLifetimes b t = i then (v.built.aux.lam b t : ℝ) else 0) •
            paraboloidLift (ltCoords i) :=
          Finset.sum_congr rfl (fun i hi => by rw [hbirth_unch i (hsub hi)])
      _ = liftedPoint v.built.node.o v.built.s := hsumz
  have hbirth_adm' : ∀ lt ∈ v.birthPool, lt < P'.nextLifetime ∧ ltCoords' lt ∈ RatAdmissiblePointSet d B := by
    intro lt hlt
    obtain ⟨hlt_P, hadm_P⟩ := hlvl.hbirth_adm lt hlt
    exact ⟨by rw [hnext']; omega, by rw [hbirth_unch lt hlt]; exact hadm_P⟩
  have hblt_mem' : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
      v.built.aux.birthLifetimes b t ∈ v.birthPool ∧ v.built.aux.birthLifetimes b t < P'.nextLifetime := by
    intro b t; obtain ⟨hm, hlt_P⟩ := hlvl.hblt_mem b t
    exact ⟨hm, by rw [hnext']; omega⟩
  have hbh_sync' : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
      v.built.aux.birthLifetimes b t ∈ activeLifetimes P' →
        handleOfLifetime P' (v.built.aux.birthLifetimes b t) = v.built.aux.birthHandles b t := by
    intro b t hm'
    rw [hact', Finset.mem_insert] at hm'
    have hne : v.built.aux.birthLifetimes b t ≠ P.nextLifetime := Nat.ne_of_lt (hlvl.hblt_mem b t).2
    have hm : v.built.aux.birthLifetimes b t ∈ activeLifetimes P := hm'.resolve_left hne
    rw [hh_old _ hm]; exact hlvl.hbh_active_sync b t hm
  have htab4_base : ∀ w : WordStore,
      (∀ h < 2 ^ L,
        ((.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ w.live ↔
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ ws.live) ∧
        w.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) = ws.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)))) →
      ∀ h < 2 ^ L,
        (∃ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
          v.built.aux.birthLifetimes b t ∈ activeLifetimes P' ∧
          v.built.aux.birthHandles b t = h ∧
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ w.live ∧
          w.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) = ((b.val + 1 : ℕ) : ℤ)) ∨
        ((∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
            v.built.aux.birthHandles b t = h → v.built.aux.birthLifetimes b t ∉ activeLifetimes P') ∧
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ w.live) := by
    intro w hw h hh
    rcases hlvl.tab4_spec h hh with ⟨b, t, hm, hbh, hlv, hvl⟩ | ⟨hno, hnlv⟩
    · exact Or.inl ⟨b, t, by rw [hact']; exact Finset.mem_insert_of_mem hm, hbh,
        (hw h hh).1.mpr hlv, (hw h hh).2.trans hvl⟩
    · refine Or.inr ⟨fun b t hbh hm' => ?_, fun hm_w => hnlv ((hw h hh).1.mp hm_w)⟩
      rw [hact', Finset.mem_insert] at hm'
      have hne : v.built.aux.birthLifetimes b t ≠ P.nextLifetime := Nat.ne_of_lt (hlvl.hblt_mem b t).2
      exact hno b t hbh (hm'.resolve_left hne)
  have hintact_eq : intactBlocksOf v P' = intactBlocksOf v P :=
    intactBlocksOf_insert_eq hwfP hwfP' happ (fun b t => (hlvl.hblt_mem b t).2)
  have hSold_sub_act : (chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩).image (handleOfLifetime P) ⊆
      P.activeHandles := by
    rw [← image_handleOfLifetime_active hwfP]
    exact Finset.image_subset_image (chainInput_subset_base _ _ _ _)
  -- Header of posDimStepBIns
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl2 : intBitLength (2 : ℤ) ≤ W := by have : intBitLength (2 : ℤ) = 3 := (by decide); omega
  have hl103 : intBitLength (103 : ℤ) ≤ W := by have : intBitLength (103 : ℤ) = 8 := (by decide); omega
  have hl104 : intBitLength (104 : ℤ) ≤ W := by have : intBitLength (104 : ℤ) = 8 := (by decide); omega
  have hl105 : intBitLength (105 : ℤ) ≤ W := by have : intBitLength (105 : ℤ) = 8 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have hloc105 : (RAMCellLoc.heap 9 105).bitLength ≤ W := by have : (RAMCellLoc.heap 9 105).bitLength = 12 := (by decide); omega
  have halive_bl : intBitLength (if alive_j then (1 : ℤ) else 0) ≤ W := by split_ifs <;> assumption
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 105) (by decide) hl105
  set g1 := Function.update regs 10 105; have bg1 := hbnd.update (r := 10) (by decide) hl105
  have hg1_r : ws.read (.heap 9 (g1 10)) = if alive_j then 1 else 0 := by simp only [g1, Function.update_self]; exact hr105
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact halive_bl)
  rw [hg1_r] at s2; set g2 := Function.update g1 8 (if alive_j then 1 else 0); have bg2 := bg1.update (r := 8) (by decide) halive_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
  set g3 := Function.update g2 14 1; have bg3 := bg2.update (r := 14) (by decide) hl1
  rcases hlvl.tree_Sj with ⟨rNum, rDen, htreeSj, hSj_bnds⟩
  cases halive_eq : alive_j with
  | false =>
      have hn_all : ¬ ∀ (i : ℕ) (hi : i < j), pt ∉ coreBall (vecNodes ⟨i, Nat.lt_trans hi hj⟩).o (vecNodes ⟨i, Nat.lt_trans hi hj⟩).V := by
        intro h; have := halive_iff.mpr h; rw [halive_eq] at this; cases this
      have hS_new_eq : S_new = S_old := by rw [hS_new_ite, if_neg hn_all]
      have hv'_eq : v' = v := by dsimp [v']; rw [if_neg (by rw [hS_new_eq]; exact not_not.mpr rfl)]
      have halive_next_eq : alive_next = false := by simp [alive_next, halive_eq]
      have hg3_ne : g3 8 ≠ g3 14 := by simp [g3, g2, halive_eq]
      have sSk := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) bg3).weaken
        rfl rfl (u₂ := 440 * L + 280 * d + 360) (b₂ := (80 * L + 64 * d + 100) * W * W)
        (by clear * - hL1; omega) (by have hWpos : 0 < W := (by clear * - hW40; omega); exact Nat.succ_le_of_lt (by positivity))
      have sIte := RegExec.iteEq (tB := posDimStepBInsAlive d L) (fB := .skip) bg3 (a := 8) (b := 14) (by decide) (by decide)
        (by rw [if_neg hg3_ne]; exact sSk)
      have hLWW : 0 ≤ L * W * W := by positivity
      have hdWW : 0 ≤ d * W * W := by positivity
      have sTot := (s1.seq (s2.seq (s3.seq sIte))).weaken rfl rfl
        (u₂ := 450 * L + 280 * d + 400) (b₂ := (80 * L + 64 * d + 120) * W * W)
        (by clear * - hL1 hd1; omega) (by nlinarith only [hW40, hL1, hd1, hLWW, hdWW])
      have himg_eq : S_new.image (handleOfLifetime P') =
          (chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩).image (handleOfLifetime P) := by
        rw [hS_new_eq, hS_old_eq]
        apply Finset.image_congr
        intro lt hlt; exact hh_old lt (chainInput_subset_base _ _ _ _ hlt)
      have hSj_bnds' : ∀ h ∈ S_new.image (handleOfLifetime P'),
          1 ≤ rDen h ∧ ((rNum h : ℝ) / (rDen h : ℝ)) = ‖ratPointToEuclidean (qMap' h) - v'.built.node.o‖ ^ 2 ∧
          intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧ intBitLength (rDen h) ≤ sqRadBitBound d B B_cert := by
        intro h hh
        rw [himg_eq] at hh
        obtain ⟨hd1_h, heq_h, hb1_h, hb2_h⟩ := hSj_bnds h hh
        rw [hqOld h (hSold_sub_act hh), hv'_eq]
        exact ⟨hd1_h, heq_h, hb1_h, hb2_h⟩
      have hpre' : PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap' S_new v' j ws := by
        rw [hv'_eq]
        refine
          { hj_le := hlvl.hj_le
            hm_bounds := hlvl.hm_bounds
            hage_rel := by rw [hS_new_eq, hS_old_eq]; exact hlvl.hage_rel
            hnode_o := hlvl.hnode_o
            hnode_s := hlvl.hnode_s
            hnode_V := hlvl.hnode_V
            hcp := hcp'
            hk_bounds := hlvl.hk_bounds
            hk_ratio := hlvl.hk_ratio
            hbirth_adm := hbirth_adm'
            hgeom := hlvl.hgeom
            read_age := hlvl.read_age
            read_mbirth := hlvl.read_mbirth
            read_kblk := hlvl.read_kblk
            hbh_lt := hlvl.hbh_lt
            hbh_inj := hlvl.hbh_inj
            hblt_mem := hblt_mem'
            hblt_inj := hlvl.hblt_inj
            hbh_active_sync := hbh_sync'
            read_bh := hlvl.read_bh
            unused_tab3 := hlvl.unused_tab3
            hcerts := hcerts'
            tree_Sj := ⟨rNum, rDen, by rwa [himg_eq], by simpa [hv'_eq] using hSj_bnds'⟩
            tab4_spec := htab4_base ws (fun _ _ => ⟨Iff.rfl, rfl⟩)
            tree_intact_raw := by rw [hintact_eq]; exact hlvl.tree_intact.2 }
      refine ⟨ws, g3, sTot, hmod, bg3, hpre',
        by rw [hv'_eq]; exact Nat.le_of_lt hage_lt,
        ?_, by rw [halive_next_eq]; simp only [Bool.false_eq_true, ↓reduceIte]; rwa [halive_eq] at hr105,
        fun _ _ _ _ => ⟨Iff.rfl, rfl⟩⟩
      rw [halive_next_eq]
      simp only [Bool.false_eq_true, false_iff]
      intro hall
      exact hn_all (fun i hi => hall i (Nat.lt_succ_of_lt hi))
  | true =>
      have hall_prev : ∀ (i : ℕ) (hi : i < j), pt ∉ coreBall (vecNodes ⟨i, Nat.lt_trans hi hj⟩).o (vecNodes ⟨i, Nat.lt_trans hi hj⟩).V :=
        halive_iff.mp halive_eq
      have hS_new_eq : S_new = insert P.nextLifetime S_old := by rw [hS_new_ite, if_pos hall_prev]
      have hne_S : S_new ≠ S_old := by
        rw [hS_new_eq]
        intro heq
        exact hnot_Sold (heq ▸ Finset.mem_insert_self _ _)
      have hv'_age : v'.ageUpdateSteps = insert u v.ageUpdateSteps := by dsimp [v']; rw [if_pos hne_S]
      have hv'_card : v'.ageUpdateSteps.card = v.ageUpdateSteps.card + 1 := by
        rw [hv'_age, Finset.card_insert_of_notMem hu_not]
      -- Execute posDimStepBInsAlive
      have hg3_eq : g3 8 = g3 14 := by simp [g3, g2, halive_eq]
      have hj_bl : intBitLength (j : ℤ) ≤ W := j_bl_of_level (d := d) (L := L) (K_max := K_max) (Nat.le_succ_of_le hj_K) (by clear * - hW; omega)
      have hhNew_bl : intBitLength (hNew : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hhNew_lt).trans (by clear * - hW; omega)
      have hg3_7 : g3 7 = (j : ℤ) := by simp [g3, g2, g1, hr7]
      have p1 := RegExec.copy (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (src := 7) (by decide) (by decide)
      set q1 := Function.update g3 0 (g3 7); have bq1 := bg3.update (r := 0) (v := g3 7) (by decide) (by rw [hg3_7]; exact hj_bl)
      have hq1_6 : q1 6 = (hNew : ℤ) := by simp [q1, g3, g2, g1, hr6]
      have p2 := RegExec.copy (inp := inp) hfd_le bq1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 1) (src := 6) (by decide) (by decide)
      set q2 := Function.update q1 1 (q1 6); have bq2 := bq1.update (r := 1) (v := q1 6) (by decide) (by rw [hq1_6]; exact hhNew_bl)
      have hW_sqRad : (2 * d + 2) * (2 * B + 2 * B_cert + 8) + natBitLength ((K_max + 2) * posNodeStride d L) +
          natBitLength d + L + 32 ≤ W := by
        have hsq : (2 * d + 2) * (2 * B + 2 * B_cert + 8) ≤ 2 * sqRadBitBound d B B_cert := by
          unfold sqRadBitBound; nlinarith only [hd1, hB1, hBc1]
        clear * - hsq hW; omega
      obtain ⟨q3, p3, bq3, _, _, _, hr4_pos, _, hr_div, hr3_bl, hr4_bl, hr2_core⟩ :=
        exec_sqRadAndCoreRegs hd1 (inp := inp) (fd := fd) hfd_le (sp_ok hmod).1 (sp_ok hmod).2
          hB1 hBc1 (by omega : j ≤ K_max + 1) hns_ge hW_sqRad hcoords' hhNew_in' hlvl.hgeom
          bq2 (by simp [q2, q1, g3, g2, g1, hr7]) (by simp [q2, q1, g3, g2, g1, hr6])
      rw [hqNew, ← hlvl.hnode_o] at hr_div hr2_core
      have hr2_eq : q3 2 = (if alive_next then 1 else 0) := by
        rw [hr2_core, hv_node]
        dsimp [alive_next]
        rw [halive_eq, Bool.true_and]
        by_cases hmem_c : pt ∈ coreBall (vecNodes ⟨j, hj⟩).o (vecNodes ⟨j, hj⟩).V
        · simp [hmem_c]
        · simp [hmem_c]
      have hr2_bl : intBitLength (q3 2) ≤ W := by rw [hr2_eq]; split_ifs <;> assumption
      have p4 := RegExec.lit (inp := inp) hfd_le bq3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 105) (by decide) hl105
      set q4 := Function.update q3 10 105; have bq4 := bq3.update (r := 10) (by decide) hl105
      have hm_w1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (ws.write (.heap 9 (q4 10)) (q4 2)) := by
        simpa [q4] using hmod.write (mem_posDimWriteLocs_tab9 (by decide)) (q3 2) hloc105 hr2_bl
      have p5 := RegExec.store (inp := inp) hfd_le bq4 (table := 9) (addr := 10) (val := 2) (by decide) (by decide) hn9
        (sp_ok hm_w1).1 (sp_ok hm_w1).2
      set ws1 := ws.write (.heap 9 105) (if alive_next then 1 else 0)
      have hw1_eq : ws.write (.heap 9 (q4 10)) (q4 2) = ws1 := by simp [ws1, q4, hr2_eq]
      rw [hw1_eq] at p5 hm_w1
      -- Load j (104), hNew (103), compute tid = 2*j + 2, insert into treeSetLeafRegs L
      have p6 := RegExec.lit (inp := inp) hfd_le bq4 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 10) (c := 104) (by decide) hl104
      set q5 := Function.update q4 10 104; have bq5 := bq4.update (r := 10) (by decide) hl104
      have hq5_r : ws1.read (.heap 9 (q5 10)) = (j : ℤ) := by
        simp only [q5, Function.update_self, ws1]; rw [wordStore_read_write_ne _ (by decide)]; exact hr104
      have p7 := RegExec.load (inp := inp) hfd_le bq5 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 7) (table := 9) (addr := 10)
        (by decide) (by decide) hn9 (by rw [hq5_r]; exact hj_bl)
      rw [hq5_r] at p7; set q6 := Function.update q5 7 (j : ℤ); have bq6 := bq5.update (r := 7) (by decide) hj_bl
      have p8 := RegExec.lit (inp := inp) hfd_le bq6 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 10) (c := 103) (by decide) hl103
      set q7 := Function.update q6 10 103; have bq7 := bq6.update (r := 10) (by decide) hl103
      have hq7_r : ws1.read (.heap 9 (q7 10)) = (hNew : ℤ) := by
        simp only [q7, Function.update_self, ws1]; rw [wordStore_read_write_ne _ (by decide)]; exact hr103
      have p9 := RegExec.load (inp := inp) hfd_le bq7 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 6) (table := 9) (addr := 10)
        (by decide) (by decide) hn9 (by rw [hq7_r]; exact hhNew_bl)
      rw [hq7_r] at p9; set q8 := Function.update q7 6 (hNew : ℤ); have bq8 := bq7.update (r := 6) (by decide) hhNew_bl
      have h2j_bl : intBitLength (((2 * j : ℕ) : ℤ)) ≤ W := by
        have h1 := intBitLength_ofNat_le (2 * j)
        have h2 := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (show 2 * j ≤ 2 * K_max + 3 by omega)
        clear * - h1 h2 hW; omega
      have htid_bl : intBitLength (((2 * j + 2 : ℕ) : ℤ)) ≤ W := by
        have h1 := intBitLength_ofNat_le (2 * j + 2)
        have h2 := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (show 2 * j + 2 ≤ 2 * K_max + 3 by omega)
        clear * - h1 h2 hW; omega
      have p10 := RegExec.lit (inp := inp) hfd_le bq8 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 14) (c := 2) (by decide) hl2
      set q9 := Function.update q8 14 2; have bq9 := bq8.update (r := 14) (by decide) hl2
      have hm2j : q9 7 * q9 14 = ((2 * j : ℕ) : ℤ) := by simp [q9, q8, q7, q6]; ring
      have p11 := RegExec.mul (inp := inp) hfd_le bq9 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 0) (a := 7) (b := 14)
        (by decide) (by decide) (by decide) (by rw [hm2j]; exact h2j_bl)
      rw [hm2j] at p11; set q10 := Function.update q9 0 ((2 * j : ℕ) : ℤ); have bq10 := bq9.update (r := 0) (by decide) h2j_bl
      have ha2j : q10 0 + q10 14 = ((2 * j + 2 : ℕ) : ℤ) := by simp [q10, q9]
      have p12 := RegExec.add (inp := inp) hfd_le bq10 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 0) (a := 0) (b := 14)
        (by decide) (by decide) (by decide) (by rw [ha2j]; exact htid_bl)
      rw [ha2j] at p12; set q11 := Function.update q10 0 ((2 * j + 2 : ℕ) : ℤ); have bq11 := bq10.update (r := 0) (by decide) htid_bl
      have p13 := RegExec.copy (inp := inp) hfd_le bq11 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 1) (src := 6) (by decide) (by decide)
      set q12 := Function.update q11 1 (q11 6); have bq12 := bq11.update (r := 1) (by decide) (by simpa [q11, q10, q9, q8] using hhNew_bl)
      have p14 := RegExec.lit (inp := inp) hfd_le bq12 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 2) (c := 1) (by decide) hl1
      set q13 := Function.update q12 2 1; have bq13 := bq12.update (r := 2) (by decide) hl1
      let rNum' := Function.update rNum hNew (q3 3)
      let rDen' := Function.update rDen hNew (q3 4)
      have himg_new : S_new.image (handleOfLifetime P') =
          insert hNew ((chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩).image (handleOfLifetime P)) := by
        rw [hS_new_eq, Finset.image_insert, hh_new, hS_old_eq]
        congr 1; apply Finset.image_congr
        intro lt hlt; exact hh_old lt (chainInput_subset_base _ _ _ _ hlt)
      have hr3_sqb : intBitLength (q3 3) ≤ sqRadBitBound d B B_cert :=
        hr3_bl.trans (by unfold sqRadBitBound; nlinarith only [hd1, hB1, hBc1])
      have hr4_sqb : intBitLength (q3 4) ≤ sqRadBitBound d B B_cert :=
        hr4_bl.trans (by unfold sqRadBitBound; nlinarith only [hd1, hB1, hBc1])
      have hSj'_bnds_tree : ∀ h ∈ S_new.image (handleOfLifetime P'),
          h < 2 ^ L ∧ intBitLength (rNum' h) ≤ sqRadBitBound d B B_cert ∧ intBitLength (rDen' h) ≤ sqRadBitBound d B B_cert := by
        intro h hh; rw [himg_new] at hh
        rcases Finset.mem_insert.mp hh with rfl | hold
        · exact ⟨hhNew_lt, by simp [rNum', hr3_sqb], by simp [rDen', hr4_sqb]⟩
        · have hne : h ≠ hNew := fun heq => hhNew_not (heq ▸ hSold_sub_act hold)
          obtain ⟨_, _, hb1, hb2⟩ := hSj_bnds h hold
          exact ⟨htreeSj.hS h hold, by simp [rNum', Function.update_of_ne hne, hb1],
                 by simp [rDen', Function.update_of_ne hne, hb2]⟩
      have htreeSj_w1 : TreeStoredAt L (2 * j + 2)
          ((chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩).image (handleOfLifetime P))
          rNum rDen ws1 :=
        htreeSj.unchanged (fun u _ f _ => by simp [ws1, WordStore.write])
      have hW_treeSj : 2 * sqRadBitBound d B B_cert + natBitLength (2 * j + 2) + L + 16 ≤ W := by
        have ht := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (show 2 * j + 2 ≤ 2 * K_max + 3 by omega)
        clear * - ht hW; omega
      obtain ⟨ws2, q14, p15, hm_w2, bq14, htreeSj2, hunch2⟩ :=
        exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hm_w1 hcCeil0 hbCeil0 hL1 hhNew_lt
          (B_r := sqRadBitBound d B B_cert) (by unfold sqRadBitBound; omega) hW_treeSj
          (treePathLocs_sub_posDimWriteLocs (by omega) hhNew_lt)
          htreeSj_w1 hSj'_bnds_tree
          (fun h hne => by rw [himg_new, Finset.mem_insert]; simp [hne])
          (fun h hne => by simp [rNum', Function.update_of_ne hne])
          (fun h hne => by simp [rDen', Function.update_of_ne hne])
          true (by rw [himg_new]; simp) bq13
          (by simp [q13, q12, q11])
          (by simp [q13, q12, q11, q10, q9, q8])
          (by simp [q13])
          (fun _ => by simp [q13, q12, q11, q10, q9, q8, q7, q6, q5, q4, rNum'])
          (fun _ => by simp [q13, q12, q11, q10, q9, q8, q7, q6, q5, q4, rDen'])
      -- Increment age_j
      have hPathSub2 : treePathLocs L (2 * j + 2) hNew ⊆ treeSliceLocs L (2 * j + 2) :=
        treePath_sub_slice hL1 hhNew_lt
      have p16 := RegExec.lit (inp := inp) hfd_le bq14 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 10) (c := 104) (by decide) hl104
      set q15 := Function.update q14 10 104; have bq15 := bq14.update (r := 10) (by decide) hl104
      have hr2_104 : ws2.read (.heap 9 (q15 10)) = (j : ℤ) := by
        simp only [q15, Function.update_self]
        rw [wordStore_read_eq_vals hm_w2.wf,
            (hunch2 _ (fun hp => not_in_treeSlice_of_table_ne (by decide) _ (hPathSub2 hp))).2,
            ← wordStore_read_eq_vals hm_w1.wf]
        simp only [ws1]; rw [wordStore_read_write_ne _ (by intro h; cases h)]; exact hr104
      have p17 := RegExec.load (inp := inp) hfd_le bq15 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 7) (table := 9) (addr := 10)
        (by decide) (by decide) hn9 (by rw [hr2_104]; exact hj_bl)
      rw [hr2_104] at p17; set q16 := Function.update q15 7 (j : ℤ); have bq16 := bq15.update (r := 7) (by decide) hj_bl
      have hr2_age : ws2.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) = (v.ageUpdateSteps.card : ℤ) := by
        rw [wordStore_read_eq_vals hm_w2.wf,
            (hunch2 _ (fun hp => not_in_treeSlice_of_table_ne (by decide) _ (hPathSub2 hp))).2,
            ← wordStore_read_eq_vals hm_w1.wf]
        simp only [ws1]; rw [wordStore_read_write_ne _ (by intro h; cases h)]; exact hlvl.read_age
      obtain ⟨qEnd, p18, hmEnd, bqEnd⟩ :=
        exec_incrNodeAgeStmt (inp := inp) (fd := fd) hfd_le hm_w2 hcCeil0 hbCeil0 hj_K hage_lt
          (by clear * - hW; omega)
          (mem_posDimWriteLocs_tab3 (by omega) (by unfold posNodeStride; omega))
          hr2_age bq16 (by simp [q16])
      set wsEnd := ws2.write (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) ((v.ageUpdateSteps.card + 1 : ℕ) : ℤ)
      have pAlive := p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq (p7.seq (p8.seq (p9.seq
        (p10.seq (p11.seq (p12.seq (p13.seq (p14.seq (p15.seq (p16.seq (p17.seq p18))))))))))))))))
      have sIte := RegExec.iteEq (tB := posDimStepBInsAlive d L) (fB := .skip) bg3 (a := 8) (b := 14) (by decide) (by decide)
        (by rw [if_pos hg3_eq]; exact pAlive)
      have hLWW : 0 ≤ L * W * W := by positivity
      have hdWW : 0 ≤ d * W * W := by positivity
      have sTot := (s1.seq (s2.seq (s3.seq sIte))).weaken rfl rfl
        (u₂ := 450 * L + 280 * d + 400) (b₂ := (80 * L + 64 * d + 120) * W * W)
        (by clear * - hL1 hd1; omega)
        (by
          have h1 : (56 * d + 32) * W * W + (56 * L + 32) * W * W =
              56 * (d * W * W) + 56 * (L * W * W) + 64 * (W * W) := by ring
          nlinarith only [hW40, hL1, hd1, hLWW, hdWW, h1])
      -- Assemble PreTriggerLevelInv on wsEnd
      have hunch_non3_2 : ∀ t : ℕ, t ≠ 2 → t ≠ 3 → t ≠ 9 → ∀ z : ℤ,
          ((.heap t z : RAMCellLoc) ∈ wsEnd.live ↔ (.heap t z : RAMCellLoc) ∈ ws.live) ∧
          wsEnd.vals (.heap t z) = ws.vals (.heap t z) := by
        intro t ht2 ht3 ht9 z
        have u2 := hunch2 (.heap t z) (fun hp => not_in_treeSlice_of_table_ne ht2 z (hPathSub2 hp))
        have hne3 : (.heap t z : RAMCellLoc) ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j 0) := by
          intro h; cases h; exact ht3 rfl
        have hne9 : (.heap t z : RAMCellLoc) ≠ .heap 9 105 := by
          intro h; cases h; exact ht9 rfl
        exact ⟨by simp [wsEnd, WordStore.write, hne3, u2.1, ws1, hne9],
               by simp [wsEnd, WordStore.write, Function.update_of_ne hne3, u2.2, ws1, Function.update_of_ne hne9]⟩
      have hread3_pos : ∀ off : ℕ, 1 ≤ off → off < posNodeStride d L →
          wsEnd.read (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
            ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) := by
        intro off h1 hoff
        have hne0 : (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ≠
            .heap 3 (nodeCellAddr (posNodeStride d L) j 0) := by
          intro heq; injection heq with _ haddr
          have := (nodeCellAddr_inj hoff (by unfold posNodeStride; omega) haddr).2
          omega
        rw [wordStore_read_eq_vals hmEnd.wf,
            show wsEnd.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
              ws2.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) by
              simp [wsEnd, WordStore.write, Function.update_of_ne hne0],
            (hunch2 _ (fun hp => not_in_treeSlice_of_table_ne (by decide) _ (hPathSub2 hp))).2,
            ← wordStore_read_eq_vals hm_w1.wf]
        simp only [ws1]; rw [wordStore_read_write_ne _ (by intro h; cases h)]
      have hgeomEnd : NodeGeomStored d (posNodeStride d L) B_cert j
          v.built.aux.oRat v.built.aux.V_num v.built.aux.V_den v.built.node.V wsEnd :=
        { hV_nn := hlvl.hgeom.hV_nn
          hV_den := hlvl.hgeom.hV_den
          hV_eq := hlvl.hgeom.hV_eq
          hVN_bl := hlvl.hgeom.hVN_bl
          hVD_bl := hlvl.hgeom.hVD_bl
          read_VN := (hread3_pos 3 (by decide) (by unfold posNodeStride; omega)).trans hlvl.hgeom.read_VN
          read_VD := (hread3_pos 4 (by decide) (by unfold posNodeStride; omega)).trans hlvl.hgeom.read_VD
          read_o := fun c => by
            have h6c : 6 + 2 * c.val < posNodeStride d L := by unfold posNodeStride; omega
            have h6c1 : 6 + 2 * c.val + 1 < posNodeStride d L := by unfold posNodeStride; omega
            dsimp only
            rw [hread3_pos _ (by omega) h6c, hread3_pos _ (by omega) h6c1]
            exact hlvl.hgeom.read_o c }
      have hSj'_full : ∀ h ∈ S_new.image (handleOfLifetime P'),
          1 ≤ rDen' h ∧ ((rNum' h : ℝ) / (rDen' h : ℝ)) = ‖ratPointToEuclidean (qMap' h) - v.built.node.o‖ ^ 2 ∧
          intBitLength (rNum' h) ≤ sqRadBitBound d B B_cert ∧ intBitLength (rDen' h) ≤ sqRadBitBound d B B_cert := by
        intro h hh; rw [himg_new] at hh
        rcases Finset.mem_insert.mp hh with rfl | hold
        · exact ⟨by simp [rDen', hr4_pos], by simp [rNum', rDen', hr_div, hqNew],
                 by simp [rNum', hr3_sqb], by simp [rDen', hr4_sqb]⟩
        · have hne : h ≠ hNew := fun heq => hhNew_not (heq ▸ hSold_sub_act hold)
          obtain ⟨hd_h, heq_h, hb1, hb2⟩ := hSj_bnds h hold
          rw [hqOld h (hSold_sub_act hold)]
          exact ⟨by simp [rDen', Function.update_of_ne hne, hd_h],
                 by simp [rNum', rDen', Function.update_of_ne hne, heq_h],
                 by simp [rNum', Function.update_of_ne hne, hb1],
                 by simp [rDen', Function.update_of_ne hne, hb2]⟩
      have hpreEnd : PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap' S_new v' j wsEnd :=
        { hj_le := hlvl.hj_le
          hm_bounds := hlvl.hm_bounds
          hage_rel := by
            rw [hv'_card, hS_new_eq, hS_old_eq]
            exact hasNodeAge_insert hlvl.hage_rel (by rwa [← hS_old_eq])
          hnode_o := hlvl.hnode_o
          hnode_s := hlvl.hnode_s
          hnode_V := hlvl.hnode_V
          hcp := hcp'
          hk_bounds := hlvl.hk_bounds
          hk_ratio := hlvl.hk_ratio
          hbirth_adm := hbirth_adm'
          hgeom := hgeomEnd
          read_age := by rw [hv'_card]; simp [wsEnd, WordStore.read, WordStore.write]
          read_mbirth := (hread3_pos 1 (by decide) (by unfold posNodeStride; omega)).trans hlvl.read_mbirth
          read_kblk := (hread3_pos 2 (by decide) (by unfold posNodeStride; omega)).trans hlvl.read_kblk
          hbh_lt := hlvl.hbh_lt
          hbh_inj := hlvl.hbh_inj
          hblt_mem := hblt_mem'
          hblt_inj := hlvl.hblt_inj
          hbh_active_sync := hbh_sync'
          read_bh := fun b t => by
            have h1 : b.val * s₀_d + t.val < v.built.aux.k_blk * s₀_d := by
              have hm : (b.val + 1) * s₀_d ≤ v.built.aux.k_blk * s₀_d := Nat.mul_le_mul_right _ (Nat.succ_le_of_lt b.isLt)
              have ha : b.val * s₀_d + t.val < (b.val + 1) * s₀_d := by
                rw [add_mul, one_mul]; exact Nat.add_lt_add_left t.isLt _
              exact lt_of_lt_of_le ha hm
            have h2 := hlvl.hk_bounds.2
            have h3 := hlvl.hm_bounds.2
            have hoff : 6 + 2 * d + (b.val * s₀_d + t.val) < posNodeStride d L := by
              unfold posNodeStride; clear * - h1 h2 h3 h2n_pow hn; omega
            exact (hread3_pos _ (by omega) hoff).trans (hlvl.read_bh b t)
          unused_tab3 := fun off hlo hhi hmE => by
            have hne0 : (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ≠
                .heap 3 (nodeCellAddr (posNodeStride d L) j 0) := by
              intro heq; injection heq with _ haddr
              have := (nodeCellAddr_inj hhi (by unfold posNodeStride; omega) haddr).2; omega
            have hm2 : (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws2.live := by
              simpa [wsEnd, WordStore.write, hne0] using hmE
            have hm1 := (hunch2 _ (fun hp => not_in_treeSlice_of_table_ne (by decide) _ (hPathSub2 hp))).1.mp hm2
            exact hlvl.unused_tab3 off hlo hhi (by simpa [ws1, WordStore.write] using hm1)
          hcerts := hcerts'
          tree_Sj := ⟨rNum', rDen', htreeSj2.unchanged (fun u _ f _ => by simp [wsEnd, WordStore.write]), hSj'_full⟩
          tab4_spec := htab4_base wsEnd (fun h _ => hunch_non3_2 4 (by decide) (by decide) (by decide) _)
          tree_intact_raw := by
            rw [show intactBlocksOf v' P' = intactBlocksOf v P by exact hintact_eq]
            exact hlvl.tree_intact.2.unchanged (fun u hu f hf => by
              have u2 := hunch2 (.heap 2 (treeCellAddr L (2 * j + 3) u f))
                (fun hp => not_in_treeSlice_of_tid_ne hu hf (by omega) (hPathSub2 hp))
              exact ⟨by simp [wsEnd, WordStore.write, u2.1, ws1],
                     by simp [wsEnd, WordStore.write, u2.2, ws1]⟩) }
      have hrEnd_105 : wsEnd.read (.heap 9 105) = (if alive_next then 1 else 0) := by
        rw [wordStore_read_eq_vals hmEnd.wf,
            show wsEnd.vals (.heap 9 105) = ws2.vals (.heap 9 105) by simp [wsEnd, WordStore.write],
            (hunch2 _ (fun hp => not_in_treeSlice_of_table_ne (by decide) _ (hPathSub2 hp))).2,
            ← wordStore_read_eq_vals hm_w1.wf]
        simp [ws1, WordStore.read, WordStore.write]
      refine ⟨wsEnd, qEnd, sTot, hmEnd, bqEnd, hpreEnd,
        by rw [hv'_card]; clear * - hage_lt; omega,
        ?_, hrEnd_105, ?_⟩
      · dsimp [alive_next]
        rw [halive_eq, Bool.true_and]
        constructor
        · intro hd i hi
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
          · exact hall_prev i hlt
          · exact open Classical in of_decide_eq_true hd
        · intro hall
          exact open Classical in decide_eq_true (hall j (Nat.lt_succ_self j))
      · intro loc hne105 hne30 hns2
        have u2 := hunch2 loc (fun hp => hns2 (hPathSub2 hp))
        exact ⟨by simp [wsEnd, WordStore.write, hne30, u2.1, ws1, hne105],
               by simp [wsEnd, WordStore.write, Function.update_of_ne hne30, u2.2, ws1, Function.update_of_ne hne105]⟩

/-! ### 3. Per-Level Delete Substeps (`exec_posDimStepBDelTab4` & `exec_posDimStepBDelSj`) -/

theorem exec_posDimStepBDelTab4 {d s₀_d n L B B_cert K_max W : ℕ}
    (hn : 2 ≤ n) (h2n_pow : 2 * n ≤ 2 ^ L)
    (hW : natBitLength ((K_max + 2) * posNodeStride d L) + L + 32 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P P' : DynamicPointSet d} (hwfP : P.WellFormed n) (hwfP' : P'.WellFormed n)
    {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)} {qMap : ℕ → Fin d → ℚ}
    {id : ℕ} (happ : applyDynamicUpdate P (.delete id) none = some P')
    (hdelH_lt : P.handleOfId id < 2 ^ L)
    {j : ℕ} (hj_K : j ≤ K_max) {S_old : Finset ℕ}
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)}
    {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hlvl : LevelStoredInv n L B B_cert K_max P ltCoords qMap S_old v j ws)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr6 : regs 6 = (P.handleOfId id : ℤ)) (hr7 : regs 7 = (j : ℤ)) :
    ∃ wsMid regsMid,
      RegExec inp fd W C_cell C_bit (posDimStepBDelTab4 L) ws regs wsMid regsMid
        (380 * L + 300) ((64 * L + 60) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsMid ∧
      RegBounded W regsMid ∧
      TreeStoredAt L (2 * j + 3) (intactBlocksOf v P') (fun _ => 0) (fun _ => 1) wsMid ∧
      (∀ h < 2 ^ L,
        (∃ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
          v.built.aux.birthLifetimes b t ∈ activeLifetimes P' ∧
          v.built.aux.birthHandles b t = h ∧
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ wsMid.live ∧
          wsMid.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) = ((b.val + 1 : ℕ) : ℤ)) ∨
        ((∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
            v.built.aux.birthHandles b t = h → v.built.aux.birthLifetimes b t ∉ activeLifetimes P') ∧
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ wsMid.live)) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .heap 4 (((j * 2 ^ L + P.handleOfId id : ℕ) : ℤ)) →
        loc ∉ treeSliceLocs L (2 * j + 3) →
        (loc ∈ wsMid.live ↔ loc ∈ ws.live) ∧ wsMid.vals loc = ws.vals loc) := by
  have hL1 : 1 ≤ L := by
    by_cases h0 : L = 0
    · rw [h0, pow_zero] at h2n_pow; clear * - hn h2n_pow; omega
    · exact Nat.pos_of_ne_zero h0
  have hW32 : 32 ≤ W := by clear * - hW; omega
  set delH := P.handleOfId id
  have hp2_bl : intBitLength (((2 ^ L : ℕ) : ℤ)) ≤ W := (nat_pow2_bitLength_le L).trans (by clear * - hW; omega)
  have hprod4_lt : j * 2 ^ L + delH < (K_max + 2) * posNodeStride d L := by
    unfold posNodeStride
    have h1 : j * 2 ^ L + delH < (j + 1) * 2 ^ L := by rw [add_mul, one_mul]; exact Nat.add_lt_add_left hdelH_lt _
    have h2 : (j + 1) * 2 ^ L ≤ (K_max + 2) * 2 ^ L := Nat.mul_le_mul_right _ (by omega)
    nlinarith only [h1, h2]
  have hj2L_bl : intBitLength (((j * 2 ^ L : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (j * 2 ^ L)
    have h2 := natBitLength_mono (show j * 2 ^ L ≤ (K_max + 2) * posNodeStride d L by omega)
    clear * - h1 h2 hW; omega
  have haddr4_bl : intBitLength (((j * 2 ^ L + delH : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (j * 2 ^ L + delH)
    have h2 := natBitLength_mono (Nat.le_of_lt hprod4_lt)
    clear * - h1 h2 hW; omega
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl2 : intBitLength (2 : ℤ) ≤ W := by have : intBitLength (2 : ℤ) = 3 := (by decide); omega
  have hl3 : intBitLength (3 : ℤ) ≤ W := by have : intBitLength (3 : ℤ) = 3 := (by decide); omega
  have hn4 : natBitLength 4 ≤ W := by have : natBitLength 4 = 3 := (by decide); omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil0], by linarith only [bs, hbCeil0]⟩
  obtain ⟨_, hact', _, hh_del, _⟩ := activeLifetimes_delete_spec hwfP hwfP' happ
  -- Steps s1..s5: addr4 = j * 2^L + delH, ow = ws.read (.heap 4 addr4)
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := ((2 ^ L : ℕ) : ℤ)) (by decide) hp2_bl
  set g1 := Function.update regs 8 ((2 ^ L : ℕ) : ℤ); have bg1 := hbnd.update (r := 8) (by decide) hp2_bl
  have hm4 : g1 7 * g1 8 = ((j * 2 ^ L : ℕ) : ℤ) := by simp [g1, hr7]
  have s2 := RegExec.mul (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (a := 7) (b := 8)
    (by decide) (by decide) (by decide) (by rw [hm4]; exact hj2L_bl)
  rw [hm4] at s2; set g2 := Function.update g1 8 ((j * 2 ^ L : ℕ) : ℤ); have bg2 := bg1.update (r := 8) (by decide) hj2L_bl
  have ha4 : g2 8 + g2 6 = ((j * 2 ^ L + delH : ℕ) : ℤ) := by simp [g2, g1, hr6, delH]
  have s3 := RegExec.add (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (a := 8) (b := 6)
    (by decide) (by decide) (by decide) (by rw [ha4]; exact haddr4_bl)
  rw [ha4] at s3; set g3 := Function.update g2 8 ((j * 2 ^ L + delH : ℕ) : ℤ); have bg3 := bg2.update (r := 8) (by decide) haddr4_bl
  rcases hlvl.tab4_spec delH hdelH_lt with ⟨b₀, t₀, hact₀, hbh₀, hlive₀, hval₀⟩ | ⟨hno₀, hnlive₀⟩
  · -- Case 1: `delH` belongs to block `b₀`
    have hk_lt_pow : v.built.aux.k_blk ≤ 2 ^ L := by
      have hs0_pos : 1 ≤ s₀_d := Nat.succ_le_of_lt t₀.pos
      have h1 : v.built.aux.k_blk * 1 ≤ v.built.aux.k_blk * s₀_d :=
        Nat.mul_le_mul_left _ hs0_pos
      have h2 := hlvl.hk_bounds.2; have h3 := hlvl.hm_bounds.2
      clear * - h1 h2 h3 hn h2n_pow; omega
    have hb₀_lt : b₀.val < 2 ^ L := lt_of_lt_of_le b₀.isLt hk_lt_pow
    have how_bl : intBitLength (((b₀.val + 1 : ℕ) : ℤ)) ≤ W := by
      have hp : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
      have : b₀.val + 1 < 2 ^ (L + 1) := by rw [pow_succ]; clear * - hb₀_lt hp; omega
      exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
    have hb₀_bl : intBitLength (b₀.val : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hb₀_lt).trans (by clear * - hW; omega)
    have hg3_r : ws.read (.heap 4 (g3 8)) = ((b₀.val + 1 : ℕ) : ℤ) := by
      simp only [g3, Function.update_self]; rw [wordStore_read_eq_vals hmod.wf]; exact hval₀
    have s4 := RegExec.load (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 9) (table := 4) (addr := 8)
      (by decide) (by decide) hn4 (by rw [hg3_r]; exact how_bl)
    rw [hg3_r] at s4; set g4 := Function.update g3 9 ((b₀.val + 1 : ℕ) : ℤ); have bg4 := bg3.update (r := 9) (by decide) how_bl
    have s5 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
    set g5 := Function.update g4 14 1; have bg5 := bg4.update (r := 14) (by decide) hl1
    have hg5_le : g5 14 ≤ g5 9 := by simp [g5, g4]
    -- Execute posDimStepBDelOwTrue L
    have p1 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws)
      bg5 (table := 4) (addr := 8) (by decide) hn4
    set ws1 := ws.free (.heap 4 (((j * 2 ^ L + delH : ℕ) : ℤ)))
    have hw1_eq : ws.free (.heap 4 (g5 8)) = ws1 := by simp [ws1, g5, g4, g3]
    rw [hw1_eq] at p1
    have hm_w1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws1 :=
      hmod.free (mem_posDimWriteLocs_tab4 (by omega) hdelH_lt)
    have hsub_eq : g5 9 - g5 14 = (b₀.val : ℤ) := by simp [g5, g4]
    have p2 := RegExec.sub (inp := inp) hfd_le bg5 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 1) (a := 9) (b := 14)
      (by decide) (by decide) (by decide) (by rw [hsub_eq]; exact hb₀_bl)
    rw [hsub_eq] at p2; set q1 := Function.update g5 1 (b₀.val : ℤ); have bq1 := bg5.update (r := 1) (by decide) hb₀_bl
    have h2j_bl : intBitLength (((2 * j : ℕ) : ℤ)) ≤ W := by
      have h1 := intBitLength_ofNat_le (2 * j)
      have h2 := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (show 2 * j ≤ 2 * K_max + 3 by omega)
      clear * - h1 h2 hW; omega
    have htid3_bl : intBitLength (((2 * j + 3 : ℕ) : ℤ)) ≤ W := by
      have h1 := intBitLength_ofNat_le (2 * j + 3)
      have h2 := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (show 2 * j + 3 ≤ 2 * K_max + 3 by omega)
      clear * - h1 h2 hW; omega
    have p3 := RegExec.lit (inp := inp) hfd_le bq1 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 14) (c := 2) (by decide) hl2
    set q2 := Function.update q1 14 2; have bq2 := bq1.update (r := 14) (by decide) hl2
    have hm2j : q2 7 * q2 14 = ((2 * j : ℕ) : ℤ) := by simp [q2, q1, g5, g4, g3, g2, g1, hr7]; ring
    have p4 := RegExec.mul (inp := inp) hfd_le bq2 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 0) (a := 7) (b := 14)
      (by decide) (by decide) (by decide) (by rw [hm2j]; exact h2j_bl)
    rw [hm2j] at p4; set q3 := Function.update q2 0 ((2 * j : ℕ) : ℤ); have bq3 := bq2.update (r := 0) (by decide) h2j_bl
    have p5 := RegExec.lit (inp := inp) hfd_le bq3 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 14) (c := 3) (by decide) hl3
    set q4 := Function.update q3 14 3; have bq4 := bq3.update (r := 14) (by decide) hl3
    have ha3 : q4 0 + q4 14 = ((2 * j + 3 : ℕ) : ℤ) := by simp [q4, q3]
    have p6 := RegExec.add (inp := inp) hfd_le bq4 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 0) (a := 0) (b := 14)
      (by decide) (by decide) (by decide) (by rw [ha3]; exact htid3_bl)
    rw [ha3] at p6; set q5 := Function.update q4 0 ((2 * j + 3 : ℕ) : ℤ); have bq5 := bq4.update (r := 0) (by decide) htid3_bl
    have p7 := RegExec.lit (inp := inp) hfd_le bq5 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 2) (c := 0) (by decide) hl0
    set q6 := Function.update q5 2 0; have bq6 := bq5.update (r := 2) (by decide) hl0
    have p8 := RegExec.lit (inp := inp) hfd_le bq6 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 3) (c := 0) (by decide) hl0
    set q7 := Function.update q6 3 0; have bq7 := bq6.update (r := 3) (by decide) hl0
    have p9 := RegExec.lit (inp := inp) hfd_le bq7 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 4) (c := 0) (by decide) hl0
    set q8 := Function.update q7 4 0; have bq8 := bq7.update (r := 4) (by decide) hl0
    obtain ⟨hlt₀_eq, hintact'⟩ := intactBlocksOf_delete_owner hwfP hwfP' happ hlvl.hblt_inj hlvl.hbh_active_sync hact₀ hbh₀
    have htree_w1 : TreeStoredAt L (2 * j + 3) (intactBlocksOf v P) (fun _ => 0) (fun _ => 1) ws1 :=
      hlvl.tree_intact.2.unchanged (fun u _ f _ => by simp [ws1, WordStore.free])
    have hint'_bnds : ∀ b ∈ intactBlocksOf v P',
        b < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) b) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) b) ≤ 2 := by
      intro b hb; rw [hintact'] at hb
      exact ⟨hlvl.tree_intact.2.hS b (Finset.mem_of_mem_erase hb), by dsimp only; decide, by dsimp only; decide⟩
    have hW_tree3 : 2 * 2 + natBitLength (2 * j + 3) + L + 16 ≤ W := by
      have ht := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (show 2 * j + 3 ≤ 2 * K_max + 3 by omega)
      clear * - ht hW; omega
    obtain ⟨wsMid, regsMid, p10, hmMid, bqMid, htreeMid, hunchMid⟩ :=
      exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hm_w1 hcCeil0 hbCeil0 hL1 hb₀_lt (B_r := 2) (by decide)
        hW_tree3 (treePathLocs_sub_posDimWriteLocs (by omega) hb₀_lt)
        htree_w1 hint'_bnds
        (fun b hne => by rw [hintact', Finset.mem_erase]; simp [hne])
        (fun _ _ => rfl) (fun _ _ => rfl) false (by rw [hintact']; simp) bq8
        (by simp [q8, q7, q6, q5])
        (by simp [q8, q7, q6, q5, q4, q3, q2, q1])
        (by simp [q8, q7, q6])
        (by intro h; cases h) (by intro h; cases h)
    have pBr := p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq (p7.seq (p8.seq (p9.seq p10))))))))
    have sIte := RegExec.iteLe (tB := posDimStepBDelOwTrue L) (fB := .skip) bg5 (a := 14) (b := 9) (by decide) (by decide)
      (by rw [if_pos hg5_le]; exact pBr)
    have hLWW : 0 ≤ L * W * W := by positivity
    have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq sIte))))).weaken rfl rfl
      (u₂ := 380 * L + 300) (b₂ := (64 * L + 60) * W * W)
      (by clear * - hL1; omega) (by nlinarith only [hW32, hL1, hLWW])
    have hPathSub3 : treePathLocs L (2 * j + 3) b₀.val ⊆ treeSliceLocs L (2 * j + 3) :=
      treePath_sub_slice hL1 hb₀_lt
    refine ⟨wsMid, regsMid, sTot, hmMid, bqMid, htreeMid, ?_, ?_⟩
    · intro h hh
      have u4 := hunchMid (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)))
        (fun hp => not_in_treeSlice_of_table_ne (by decide) _ (hPathSub3 hp))
      by_cases heq_h : h = delH
      · subst heq_h
        refine Or.inr ⟨fun b t hbh hm' => ?_, ?_⟩
        · rcases hlvl.hbh_inj (hbh.trans hbh₀.symm) with ⟨rfl, rfl⟩
          rw [hact', hlt₀_eq] at hm'
          exact (Finset.mem_erase.mp hm').1 rfl
        · rw [u4.1]; simp [ws1, WordStore.free]
      · have hne_loc : (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ≠
            .heap 4 (((j * 2 ^ L + delH : ℕ) : ℤ)) := by
          intro hc; injection hc with _ hz; have : j * 2 ^ L + h = j * 2 ^ L + delH := by exact_mod_cast hz
          exact heq_h (by omega)
        rcases hlvl.tab4_spec h hh with ⟨b, t, hm, hbh, hlv, hvl⟩ | ⟨hno, hnlv⟩
        · have hlt_ne : v.built.aux.birthLifetimes b t ≠ P.lifetimeOfId id := by
            intro hlteq
            have := hlvl.hbh_active_sync b t hm
            rw [hlteq, hh_del, hbh] at this
            exact heq_h this.symm
          refine Or.inl ⟨b, t, by rw [hact']; exact Finset.mem_erase.mpr ⟨hlt_ne, hm⟩, hbh, ?_, ?_⟩
          · rw [u4.1]; exact Finset.mem_erase.mpr ⟨hne_loc, hlv⟩
          · rw [u4.2]; exact (Function.update_of_ne hne_loc 0 ws.vals).trans hvl
        · refine Or.inr ⟨fun b t hbh hm' => hno b t hbh (by rw [hact'] at hm'; exact Finset.mem_of_mem_erase hm'), ?_⟩
          rw [u4.1]; exact fun hm => hnlv (Finset.mem_of_mem_erase hm)
    · intro loc hne4 hns3
      have uM := hunchMid loc (fun hp => hns3 (hPathSub3 hp))
      exact ⟨uM.1.trans ⟨Finset.mem_of_mem_erase, fun hm => Finset.mem_erase.mpr ⟨hne4, hm⟩⟩,
             uM.2.trans (Function.update_of_ne hne4 0 ws.vals)⟩
  · -- Case 2: `ow = 0` (`delH` has no active birth-block owner at level `j`)
    have hg3_r : ws.read (.heap 4 (g3 8)) = 0 := by
      simp only [g3, Function.update_self]; rw [wordStore_read_eq_vals hmod.wf]; exact hmod.wf _ hnlive₀
    have s4 := RegExec.load (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 9) (table := 4) (addr := 8)
      (by decide) (by decide) hn4 (by rw [hg3_r]; exact hl0)
    rw [hg3_r] at s4; set g4 := Function.update g3 9 0; have bg4 := bg3.update (r := 9) (by decide) hl0
    have s5 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
    set g5 := Function.update g4 14 1; have bg5 := bg4.update (r := 14) (by decide) hl1
    have hnot_le : ¬ (g5 14 ≤ g5 9) := by simp [g5, g4]
    have sSk := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) bg5).weaken
      rfl rfl (u₂ := 360 * L + 220) (b₂ := (60 * L + 40) * W * W) (by clear * - hL1; omega) (by have hWpos : 0 < W := (by clear * - hW32; omega); exact Nat.succ_le_of_lt (by positivity))
    have sIte := RegExec.iteLe (tB := posDimStepBDelOwTrue L) (fB := .skip) bg5 (a := 14) (b := 9) (by decide) (by decide)
      (by rw [if_neg hnot_le]; exact sSk)
    have hLWW : 0 ≤ L * W * W := by positivity
    have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq sIte))))).weaken rfl rfl
      (u₂ := 380 * L + 300) (b₂ := (64 * L + 60) * W * W)
      (by clear * - hL1; omega) (by nlinarith only [hW32, hL1, hLWW])
    have hintact' := intactBlocksOf_delete_none hwfP hwfP' happ hlvl.hbh_active_sync hno₀
    refine ⟨ws, g5, sTot, hmod, bg5, by rw [hintact']; exact hlvl.tree_intact.2, ?_, fun _ _ _ => ⟨Iff.rfl, rfl⟩⟩
    intro h hh
    rcases hlvl.tab4_spec h hh with ⟨b, t, hm, hbh, hlv, hvl⟩ | ⟨hno, hnlv⟩
    · have hlt_ne : v.built.aux.birthLifetimes b t ≠ P.lifetimeOfId id := by
        intro hlteq
        have hbh_del : v.built.aux.birthHandles b t = delH := by
          rw [← hlvl.hbh_active_sync b t hm, hlteq, hh_del]
        exact hno₀ b t hbh_del hm
      exact Or.inl ⟨b, t, by rw [hact']; exact Finset.mem_erase.mpr ⟨hlt_ne, hm⟩, hbh, hlv, hvl⟩
    · exact Or.inr ⟨fun b t hbh hm' => hno b t hbh (by rw [hact'] at hm'; exact Finset.mem_of_mem_erase hm'), hnlv⟩

theorem exec_posDimStepBDelSj {d s₀_d n L B B_cert K_max W : ℕ}
    (_hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (h2n_pow : 2 * n ≤ 2 ^ L)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) + L + 32 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P P' : DynamicPointSet d} (hwfP : P.WellFormed n) (hwfP' : P'.WellFormed n)
    {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)} {qMap : ℕ → Fin d → ℚ}
    {id : ℕ} (happ : applyDynamicUpdate P (.delete id) none = some P')
    (hdelH_lt : P.handleOfId id < 2 ^ L)
    {k : ℕ} (hk_le : k ≤ K_max) {vecNodes : Fin k → ChainNode d}
    {j : ℕ} (hj : j < k)
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)}
    {u : ℕ} (hu_not : u ∉ v.ageUpdateSteps)
    {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hage_lt : v.ageUpdateSteps.card < 2 ^ L)
    (hr_age : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) = (v.ageUpdateSteps.card : ℤ))
    {rNum rDen : ℕ → ℤ}
    (htreeSj : TreeStoredAt L (2 * j + 2)
      ((chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩).image (handleOfLifetime P))
      rNum rDen ws)
    (hSj_bnds : ∀ h ∈ (chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩).image (handleOfLifetime P),
      1 ≤ rDen h ∧ ((rNum h : ℝ) / (rDen h : ℝ)) = ‖ratPointToEuclidean (qMap h) - v.built.node.o‖ ^ 2 ∧
      intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧ intBitLength (rDen h) ≤ sqRadBitBound d B B_cert)
    (hr103 : ws.read (.heap 9 103) = (P.handleOfId id : ℤ))
    (hr104 : ws.read (.heap 9 104) = (j : ℤ))
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    let S_old := chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩
    let S_new := chainInput ltCoords vecNodes (activeLifetimes P') ⟨j, Nat.lt_succ_of_lt hj⟩
    let v' : SyncLiveChainNode d (PosDimNodeData d s₀_d) :=
      open Classical in
      { v with ageUpdateSteps := if S_new ≠ S_old then insert u v.ageUpdateSteps else v.ageUpdateSteps }
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (posDimStepBDelSj d L) ws regs wsEnd regsEnd
        (450 * L + 340) ((72 * L + 80) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      (HasNodeAge v.birthPool S_old v.ageUpdateSteps.card →
        HasNodeAge v.birthPool S_new v'.ageUpdateSteps.card ∧
        v'.ageUpdateSteps.card ≤ 2 ^ L ∧
        wsEnd.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) = (v'.ageUpdateSteps.card : ℤ) ∧
        TreeStoredAt L (2 * j + 2) (S_new.image (handleOfLifetime P')) rNum rDen wsEnd ∧
        (∀ h ∈ S_new.image (handleOfLifetime P'),
          1 ≤ rDen h ∧ ((rNum h : ℝ) / (rDen h : ℝ)) = ‖ratPointToEuclidean (qMap h) - v'.built.node.o‖ ^ 2 ∧
          intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧ intBitLength (rDen h) ≤ sqRadBitBound d B B_cert) ∧
        (∀ loc : RAMCellLoc,
          loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j 0) →
          loc ∉ treeSliceLocs L (2 * j + 2) →
          (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc)) := by
  intro S_old S_new v'
  have hL1 : 1 ≤ L := by
    by_cases h0 : L = 0
    · rw [h0, pow_zero] at h2n_pow; clear * - hn h2n_pow; omega
    · exact Nat.pos_of_ne_zero h0
  have hW32 : 32 ≤ W := by clear * - hW; omega
  have hj_K : j ≤ K_max := le_trans (Nat.le_of_lt hj) hk_le
  set delH := P.handleOfId id
  set delLt := P.lifetimeOfId id
  obtain ⟨hdel_mem, hact', _, hh_del, hh_old⟩ := activeLifetimes_delete_spec hwfP hwfP' happ
  have hS_new_eq : S_new = S_old.erase delLt := by
    dsimp [S_new, S_old]; rw [hact', chainInput_erase_eq]
  have himg_new : S_new.image (handleOfLifetime P') = (S_old.image (handleOfLifetime P)).erase delH := by
    rw [hS_new_eq]
    ext h
    simp only [Finset.mem_image, Finset.mem_erase]
    constructor
    · rintro ⟨lt, ⟨hlt_ne, hlt_in⟩, rfl⟩
      have hlt_act' : lt ∈ activeLifetimes P' := by
        rw [hact']; exact Finset.mem_erase.mpr ⟨hlt_ne, chainInput_subset_base _ _ _ _ hlt_in⟩
      rw [hh_old lt hlt_act']
      refine ⟨?_, lt, hlt_in, rfl⟩
      intro heq
      have := handleOfLifetime_injOn hwfP (chainInput_subset_base _ _ _ _ hlt_in) hdel_mem (heq.trans hh_del.symm)
      exact hlt_ne this
    · rintro ⟨hh_ne, lt, hlt_in, rfl⟩
      have hlt_ne : lt ≠ delLt := fun heq => hh_ne (heq ▸ hh_del)
      have hlt_act' : lt ∈ activeLifetimes P' := by
        rw [hact']; exact Finset.mem_erase.mpr ⟨hlt_ne, chainInput_subset_base _ _ _ _ hlt_in⟩
      exact ⟨lt, ⟨hlt_ne, hlt_in⟩, hh_old lt hlt_act'⟩
  have hdel_iff : delH ∈ S_old.image (handleOfLifetime P) ↔ delLt ∈ S_old := by
    simp only [Finset.mem_image]
    constructor
    · rintro ⟨lt, hlt_in, heq⟩
      have hlt_eq : lt = delLt :=
        handleOfLifetime_injOn hwfP (chainInput_subset_base _ _ _ _ hlt_in) hdel_mem (heq.trans hh_del.symm)
      rwa [← hlt_eq]
    · intro hlt_in
      exact ⟨delLt, hlt_in, hh_del⟩
  -- Bit-length bounds for address arithmetic
  have hj_bl : intBitLength (j : ℤ) ≤ W := j_bl_of_level (d := d) (L := L) (K_max := K_max) (Nat.le_succ_of_le hj_K) (by clear * - hW; omega)
  have hdelH_bl : intBitLength (delH : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hdelH_lt).trans (by clear * - hW; omega)
  have h2j_bl : intBitLength (((2 * j : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (2 * j)
    have h2 := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (show 2 * j ≤ 2 * K_max + 3 by omega)
    clear * - h1 h2 hW; omega
  have htid2_bl : intBitLength (((2 * j + 2 : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (2 * j + 2)
    have h2 := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (show 2 * j + 2 ≤ 2 * K_max + 3 by omega)
    clear * - h1 h2 hW; omega
  have hp2L_bl : intBitLength (((2 ^ L : ℕ) : ℤ)) ≤ W := (nat_pow2_bitLength_le L).trans (by clear * - hW; omega)
  have hp2L1_bl : intBitLength (((2 ^ (L + 1) : ℕ) : ℤ)) ≤ W := (nat_pow2_bitLength_le (L + 1)).trans (by clear * - hW; omega)
  have huLeaf_lt : treeIdx L 0 delH < 2 ^ (L + 1) :=
    (treeIdx_bounds (Nat.zero_le L) (by simpa using hdelH_lt)).2
  have huLeaf_bl : intBitLength (treeIdx L 0 delH : ℤ) ≤ W :=
    (nat_lt_pow2_bitLength_le huLeaf_lt).trans (by clear * - hW; omega)
  have hW_taddr : natBitLength (2 * j + 2) + L + 12 ≤ W := by
    have ht := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (show 2 * j + 2 ≤ 2 * K_max + 3 by omega)
    clear * - ht hW; omega
  have ⟨_, htaddr_bl⟩ := treeCellAddr_bitLength_le (W := W) (L := L) (tid := 2 * j + 2) (u := treeIdx L 0 delH) (f := 0)
    huLeaf_lt (by decide) hW_taddr
  have hmul_tid_bl : intBitLength ((((2 * j + 2) * 2 ^ (L + 1) : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono (show (2 * j + 2) * 2 ^ (L + 1) ≤ ((2 * j + 2) * 2 ^ (L + 1) + treeIdx L 0 delH) * 4 + 0 by omega)).trans htaddr_bl
  have hsum_u_bl : intBitLength ((((2 * j + 2) * 2 ^ (L + 1) + treeIdx L 0 delH : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono (show (2 * j + 2) * 2 ^ (L + 1) + treeIdx L 0 delH ≤ ((2 * j + 2) * 2 ^ (L + 1) + treeIdx L 0 delH) * 4 + 0 by omega)).trans htaddr_bl
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl2 : intBitLength (2 : ℤ) ≤ W := by have : intBitLength (2 : ℤ) = 3 := (by decide); omega
  have hl4 : intBitLength (4 : ℤ) ≤ W := by have : intBitLength (4 : ℤ) = 4 := (by decide); omega
  have hl103 : intBitLength (103 : ℤ) ≤ W := by have : intBitLength (103 : ℤ) = 8 := (by decide); omega
  have hl104 : intBitLength (104 : ℤ) ≤ W := by have : intBitLength (104 : ℤ) = 8 := (by decide); omega
  have hn2 : natBitLength 2 ≤ W := by have : natBitLength 2 = 2 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil0], by linarith only [bs, hbCeil0]⟩
  -- Execute address calculation s1..s14
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 104) (by decide) hl104
  set g1 := Function.update regs 10 104; have bg1 := hbnd.update (r := 10) (by decide) hl104
  have hg1_r : ws.read (.heap 9 (g1 10)) = (j : ℤ) := by simp only [g1, Function.update_self]; exact hr104
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 7) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact hj_bl)
  rw [hg1_r] at s2; set g2 := Function.update g1 7 (j : ℤ); have bg2 := bg1.update (r := 7) (by decide) hj_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 103) (by decide) hl103
  set g3 := Function.update g2 10 103; have bg3 := bg2.update (r := 10) (by decide) hl103
  have hg3_r : ws.read (.heap 9 (g3 10)) = (delH : ℤ) := by simp only [g3, Function.update_self]; exact hr103
  have s4 := RegExec.load (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 6) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg3_r]; exact hdelH_bl)
  rw [hg3_r] at s4; set g4 := Function.update g3 6 (delH : ℤ); have bg4 := bg3.update (r := 6) (by decide) hdelH_bl
  have s5 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 2) (by decide) hl2
  set g5 := Function.update g4 14 2; have bg5 := bg4.update (r := 14) (by decide) hl2
  have hm2j : g5 7 * g5 14 = ((2 * j : ℕ) : ℤ) := by simp [g5, g4, g3, g2]; ring
  have s6 := RegExec.mul (inp := inp) hfd_le bg5 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (a := 7) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hm2j]; exact h2j_bl)
  rw [hm2j] at s6; set g6 := Function.update g5 0 ((2 * j : ℕ) : ℤ); have bg6 := bg5.update (r := 0) (by decide) h2j_bl
  have ha2j : g6 0 + g6 14 = ((2 * j + 2 : ℕ) : ℤ) := by simp [g6, g5]
  have s7 := RegExec.add (inp := inp) hfd_le bg6 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (a := 0) (b := 14)
    (by decide) (by decide) (by decide) (by rw [ha2j]; exact htid2_bl)
  rw [ha2j] at s7; set g7 := Function.update g6 0 ((2 * j + 2 : ℕ) : ℤ); have bg7 := bg6.update (r := 0) (by decide) htid2_bl
  have s8 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := ((2 ^ (L + 1) : ℕ) : ℤ)) (by decide) hp2L1_bl
  set g8 := Function.update g7 8 ((2 ^ (L + 1) : ℕ) : ℤ); have bg8 := bg7.update (r := 8) (by decide) hp2L1_bl
  have hmtid : g8 0 * g8 8 = (((2 * j + 2) * 2 ^ (L + 1) : ℕ) : ℤ) := by simp [g8, g7]
  have s9 := RegExec.mul (inp := inp) hfd_le bg8 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (a := 0) (b := 8)
    (by decide) (by decide) (by decide) (by rw [hmtid]; exact hmul_tid_bl)
  rw [hmtid] at s9; set g9 := Function.update g8 8 (((2 * j + 2) * 2 ^ (L + 1) : ℕ) : ℤ); have bg9 := bg8.update (r := 8) (by decide) hmul_tid_bl
  have s10 := RegExec.lit (inp := inp) hfd_le bg9 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 9) (c := ((2 ^ L : ℕ) : ℤ)) (by decide) hp2L_bl
  set g10 := Function.update g9 9 ((2 ^ L : ℕ) : ℤ); have bg10 := bg9.update (r := 9) (by decide) hp2L_bl
  have hau : g10 9 + g10 6 = (treeIdx L 0 delH : ℤ) := by simp [g10, g9, g8, g7, g6, g5, g4, treeIdx]
  have s11 := RegExec.add (inp := inp) hfd_le bg10 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 9) (a := 9) (b := 6)
    (by decide) (by decide) (by decide) (by rw [hau]; exact huLeaf_bl)
  rw [hau] at s11; set g11 := Function.update g10 9 (treeIdx L 0 delH : ℤ); have bg11 := bg10.update (r := 9) (by decide) huLeaf_bl
  have hasum : g11 8 + g11 9 = ((((2 * j + 2) * 2 ^ (L + 1) + treeIdx L 0 delH : ℕ) : ℤ)) := by simp [g11, g10, g9]
  have s12 := RegExec.add (inp := inp) hfd_le bg11 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (a := 8) (b := 9)
    (by decide) (by decide) (by decide) (by rw [hasum]; exact hsum_u_bl)
  rw [hasum] at s12; set g12 := Function.update g11 8 ((((2 * j + 2) * 2 ^ (L + 1) + treeIdx L 0 delH : ℕ) : ℤ))
  have bg12 := bg11.update (r := 8) (by decide) hsum_u_bl
  have s13 := RegExec.lit (inp := inp) hfd_le bg12 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 4) (by decide) hl4
  set g13 := Function.update g12 14 4; have bg13 := bg12.update (r := 14) (by decide) hl4
  have hmtaddr : g13 8 * g13 14 = treeCellAddr L (2 * j + 2) (treeIdx L 0 delH) 0 := by simp [g13, g12, treeCellAddr]
  have s14 := RegExec.mul (inp := inp) hfd_le bg13 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (a := 8) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hmtaddr]; exact htaddr_bl)
  rw [hmtaddr] at s14; set g14 := Function.update g13 8 (treeCellAddr L (2 * j + 2) (treeIdx L 0 delH) 0)
  have bg14 := bg13.update (r := 8) (by decide) htaddr_bl
  have hr_leaf := htreeSj.read_leaf_cnt hmod.wf hdelH_lt
  have hleaf_bl : intBitLength (if delH ∈ S_old.image (handleOfLifetime P) then (1 : ℤ) else 0) ≤ W := by
    split_ifs <;> assumption
  have hg14_r : ws.read (.heap 2 (g14 8)) = if delH ∈ S_old.image (handleOfLifetime P) then 1 else 0 := by
    simp only [g14, Function.update_self]; exact hr_leaf
  have s15 := RegExec.load (inp := inp) hfd_le bg14 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 9) (table := 2) (addr := 8)
    (by decide) (by decide) hn2 (by rw [hg14_r]; exact hleaf_bl)
  rw [hg14_r] at s15; set g15 := Function.update g14 9 (if delH ∈ S_old.image (handleOfLifetime P) then 1 else 0)
  have bg15 := bg14.update (r := 9) (by decide) hleaf_bl
  have s16 := RegExec.lit (inp := inp) hfd_le bg15 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
  set g16 := Function.update g15 14 1; have bg16 := bg15.update (r := 14) (by decide) hl1
  by_cases hmem_del : delLt ∈ S_old
  · have hmem_h : delH ∈ S_old.image (handleOfLifetime P) := hdel_iff.mpr hmem_del
    have hg16_eq : g16 9 = g16 14 := by simp [g16, g15, hmem_h]
    have hne_S : S_new ≠ S_old := by
      rw [hS_new_eq]; intro heq
      exact (Finset.notMem_erase delLt S_old) (heq.symm ▸ hmem_del)
    have hv'_age : v'.ageUpdateSteps = insert u v.ageUpdateSteps := by dsimp [v']; rw [if_pos hne_S]
    have hv'_card : v'.ageUpdateSteps.card = v.ageUpdateSteps.card + 1 := by
      rw [hv'_age, Finset.card_insert_of_notMem hu_not]
    -- Execute posDimStepBDelSjTrue d L
    have p1 := RegExec.copy (inp := inp) hfd_le bg16 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 1) (src := 6) (by decide) (by decide)
    set q1 := Function.update g16 1 (g16 6)
    have bq1 := bg16.update (r := 1) (by decide) (by simpa [g16, g15, g14, g13, g12, g11, g10, g9, g8, g7, g6, g5, g4] using hdelH_bl)
    have p2 := RegExec.lit (inp := inp) hfd_le bq1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 2) (c := 0) (by decide) hl0
    set q2 := Function.update q1 2 0; have bq2 := bq1.update (r := 2) (by decide) hl0
    have p3 := RegExec.lit (inp := inp) hfd_le bq2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 3) (c := 0) (by decide) hl0
    set q3 := Function.update q2 3 0; have bq3 := bq2.update (r := 3) (by decide) hl0
    have p4 := RegExec.lit (inp := inp) hfd_le bq3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 4) (c := 0) (by decide) hl0
    set q4 := Function.update q3 4 0; have bq4 := bq3.update (r := 4) (by decide) hl0
    have hSj'_bnds_tree : ∀ h ∈ S_new.image (handleOfLifetime P'),
        h < 2 ^ L ∧ intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧ intBitLength (rDen h) ≤ sqRadBitBound d B B_cert := by
      intro h hh; rw [himg_new] at hh
      have hold := Finset.mem_of_mem_erase hh
      exact ⟨htreeSj.hS h hold, (hSj_bnds h hold).2.2.1, (hSj_bnds h hold).2.2.2⟩
    have hW_treeSj : 2 * sqRadBitBound d B B_cert + natBitLength (2 * j + 2) + L + 16 ≤ W := by
      have ht := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (show 2 * j + 2 ≤ 2 * K_max + 3 by omega)
      clear * - ht hW; omega
    obtain ⟨ws1, q5, p5, hm_w1, bq5, htreeSj1, hunch1⟩ :=
      exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hmod hcCeil0 hbCeil0 hL1 hdelH_lt
        (B_r := sqRadBitBound d B B_cert) (by unfold sqRadBitBound; omega) hW_treeSj
        (treePathLocs_sub_posDimWriteLocs (by omega) hdelH_lt)
        htreeSj hSj'_bnds_tree
        (fun h hne => by rw [himg_new, Finset.mem_erase]; exact ⟨fun hm => ⟨hne, hm⟩, fun hm => hm.2⟩)
        (fun _ _ => rfl) (fun _ _ => rfl) false (by rw [himg_new]; exact ⟨fun hm => absurd hm (Finset.notMem_erase delH _), fun h => by cases h⟩) bq4
        (by simp [q4, q3, q2, q1, g16, g15, g14, g13, g12, g11, g10, g9, g8, g7])
        (by simp [q4, q3, q2, q1, g16, g15, g14, g13, g12, g11, g10, g9, g8, g7, g6, g5, g4])
        (by simp [q4, q3, q2])
        (by intro h; cases h) (by intro h; cases h)
    have hPathSub2 : treePathLocs L (2 * j + 2) delH ⊆ treeSliceLocs L (2 * j + 2) :=
      treePath_sub_slice hL1 hdelH_lt
    have p6 := RegExec.lit (inp := inp) hfd_le bq5 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 10) (c := 104) (by decide) hl104
    set q6 := Function.update q5 10 104; have bq6 := bq5.update (r := 10) (by decide) hl104
    have hr1_104 : ws1.read (.heap 9 (q6 10)) = (j : ℤ) := by
      simp only [q6, Function.update_self]
      rw [wordStore_read_eq_vals hm_w1.wf,
          (hunch1 _ (fun hp => not_in_treeSlice_of_table_ne (by decide) _ (hPathSub2 hp))).2,
          ← wordStore_read_eq_vals hmod.wf]
      exact hr104
    have p7 := RegExec.load (inp := inp) hfd_le bq6 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 7) (table := 9) (addr := 10)
      (by decide) (by decide) hn9 (by rw [hr1_104]; exact hj_bl)
    rw [hr1_104] at p7; set q7 := Function.update q6 7 (j : ℤ); have bq7 := bq6.update (r := 7) (by decide) hj_bl
    have hr1_age : ws1.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) = (v.ageUpdateSteps.card : ℤ) := by
      rw [wordStore_read_eq_vals hm_w1.wf,
          (hunch1 _ (fun hp => not_in_treeSlice_of_table_ne (by decide) _ (hPathSub2 hp))).2,
          ← wordStore_read_eq_vals hmod.wf]
      exact hr_age
    obtain ⟨qEnd, p8, hmEnd, bqEnd⟩ :=
      exec_incrNodeAgeStmt (inp := inp) (fd := fd) hfd_le hm_w1 hcCeil0 hbCeil0 hj_K hage_lt
        (by clear * - hW; omega)
        (mem_posDimWriteLocs_tab3 (by omega) (by unfold posNodeStride; omega))
        hr1_age bq7 (by simp [q7])
    set wsEnd := ws1.write (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) ((v.ageUpdateSteps.card + 1 : ℕ) : ℤ)
    have pBr := p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq (p7.seq p8))))))
    have sIte := RegExec.iteEq (tB := posDimStepBDelSjTrue d L) (fB := .skip) bg16 (a := 9) (b := 14) (by decide) (by decide)
      (by rw [if_pos hg16_eq]; exact pBr)
    have hLWW : 0 ≤ L * W * W := by positivity
    have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq
      (s10.seq (s11.seq (s12.seq (s13.seq (s14.seq (s15.seq (s16.seq sIte)))))))))))))))).weaken
      rfl rfl (u₂ := 450 * L + 340) (b₂ := (72 * L + 80) * W * W)
      (by clear * - hL1; omega) (by nlinarith only [hW32, hL1, hLWW])
    refine ⟨wsEnd, qEnd, sTot, hmEnd, bqEnd, fun hage_old => ⟨?_, ?_, ?_, ?_, ?_, ?_⟩⟩
    · rw [hv'_card, hS_new_eq]; exact hasNodeAge_erase hage_old hmem_del
    · rw [hv'_card]; clear * - hage_lt; omega
    · rw [hv'_card]; simp [wsEnd, WordStore.read, WordStore.write]
    · exact htreeSj1.unchanged (fun u _ f _ => by simp [wsEnd, WordStore.write])
    · intro h hh; rw [himg_new] at hh
      exact hSj_bnds h (Finset.mem_of_mem_erase hh)
    · intro loc hne30 hns2
      have u1 := hunch1 loc (fun hp => hns2 (hPathSub2 hp))
      exact ⟨by simp [wsEnd, WordStore.write, hne30, u1.1],
             by simp [wsEnd, WordStore.write, Function.update_of_ne hne30, u1.2]⟩
  · -- `delLt ∉ S_old` (`leafCnt = 0`)
    have hnmem_h : delH ∉ S_old.image (handleOfLifetime P) := fun hm => hmem_del (hdel_iff.mp hm)
    have hg16_ne : g16 9 ≠ g16 14 := by simp [g16, g15, hnmem_h]
    have hS_new_same : S_new = S_old := by rw [hS_new_eq, Finset.erase_eq_of_notMem hmem_del]
    have hv'_eq : v' = v := by dsimp [v']; rw [if_neg (by rw [hS_new_same]; exact not_not.mpr rfl)]
    have himg_same : S_new.image (handleOfLifetime P') = S_old.image (handleOfLifetime P) := by
      rw [himg_new, Finset.erase_eq_of_notMem hnmem_h]
    have sSk := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) bg16).weaken
      rfl rfl (u₂ := 420 * L + 220) (b₂ := (64 * L + 40) * W * W) (by clear * - hL1; omega) (by have hWpos : 0 < W := (by clear * - hW32; omega); exact Nat.succ_le_of_lt (by positivity))
    have sIte := RegExec.iteEq (tB := posDimStepBDelSjTrue d L) (fB := .skip) bg16 (a := 9) (b := 14) (by decide) (by decide)
      (by rw [if_neg hg16_ne]; exact sSk)
    have hLWW : 0 ≤ L * W * W := by positivity
    have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq
      (s10.seq (s11.seq (s12.seq (s13.seq (s14.seq (s15.seq (s16.seq sIte)))))))))))))))).weaken
      rfl rfl (u₂ := 450 * L + 340) (b₂ := (72 * L + 80) * W * W)
      (by clear * - hL1; omega) (by nlinarith only [hW32, hL1, hLWW])
    refine ⟨ws, g16, sTot, hmod, bg16, fun hage_old => ⟨?_, ?_, ?_, ?_, ?_, fun _ _ _ => ⟨Iff.rfl, rfl⟩⟩⟩
    · rw [hv'_eq, hS_new_same]; exact hage_old
    · rw [hv'_eq]; exact Nat.le_of_lt hage_lt
    · rw [hv'_eq]; exact hr_age
    · rwa [himg_same]
    · intro h hh; rw [himg_same] at hh; rw [hv'_eq]; exact hSj_bnds h hh

end UL.C12LVE
