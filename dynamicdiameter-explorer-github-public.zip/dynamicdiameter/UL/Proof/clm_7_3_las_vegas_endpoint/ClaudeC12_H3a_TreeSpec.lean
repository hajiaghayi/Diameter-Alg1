import Mathlib
set_option autoImplicit false

namespace UL.C12LVE

/-! ### 1. Pure mathematical `mexHandle` and `L = Nat.clog 2 (2 * n)` bounds -/

theorem exists_notMem_nat (S : Finset ℕ) : ∃ x : ℕ, x ∉ S :=
  ⟨S.sup id + 1, fun hm => by
    have hle := Finset.le_sup (f := id) hm
    dsimp only [id] at hle
    omega⟩

noncomputable def mexHandle (S : Finset ℕ) : ℕ :=
  open Classical in Nat.find (exists_notMem_nat S)

theorem mexHandle_notMem (S : Finset ℕ) : mexHandle S ∉ S := by
  classical
  exact Nat.find_spec (exists_notMem_nat S)

theorem mem_of_lt_mexHandle {S : Finset ℕ} {k : ℕ} (hk : k < mexHandle S) : k ∈ S := by
  classical
  have h := Nat.find_min (exists_notMem_nat S) hk
  exact Classical.not_not.mp h

theorem mexHandle_eq_of_notMem_and_forall_lt {S : Finset ℕ} {m : ℕ}
    (hnot : m ∉ S) (hlt : ∀ x < m, x ∈ S) :
    mexHandle S = m := by
  classical
  have hle : mexHandle S ≤ m := Nat.find_min' (exists_notMem_nat S) hnot
  rcases lt_or_eq_of_le hle with hlt_mex | heq
  · exact False.elim (mexHandle_notMem S (hlt _ hlt_mex))
  · exact heq

theorem mexHandle_lt_of_card_lt {S : Finset ℕ} {n : ℕ} (hc : S.card < n) :
    mexHandle S < n := by
  by_contra hge
  push_neg at hge
  have hsub : Finset.range n ⊆ S := by
    intro k hk
    exact mem_of_lt_mexHandle (lt_of_lt_of_le (Finset.mem_range.mp hk) hge)
  have hcard := Finset.card_le_card hsub
  rw [Finset.card_range] at hcard
  omega

theorem clog_two_mul_bounds {n : ℕ} (hn : 2 ≤ n) :
    let L := Nat.clog 2 (2 * n)
    2 ≤ L ∧ n < 2 * n ∧ 2 * n ≤ 2 ^ L ∧ 2 ^ L < 4 * n := by
  intro L
  have h4 : 4 ≤ 2 * n := by omega
  have hL2 : 2 ≤ L := by
    have hc4 : Nat.clog 2 4 = 2 := by decide
    rw [← hc4]
    exact Nat.clog_mono_right 2 h4
  have hle_pow : 2 * n ≤ 2 ^ L := Nat.le_pow_clog (by norm_num) (2 * n)
  have hlt_pow : 2 ^ L < 4 * n := by
    have hpos : 1 ≤ L := by omega
    have hlt1 : L - 1 < Nat.clog 2 (2 * n) := by change L - 1 < L; omega
    have hpow1 : 2 ^ (L - 1) < 2 * n := (Nat.lt_clog_iff_pow_lt (by norm_num)).mp hlt1
    have hpowL : 2 ^ L = 2 * 2 ^ (L - 1) := by
      conv_lhs => rw [show L = (L - 1) + 1 by omega, pow_succ']
    omega
  exact ⟨hL2, by omega, hle_pow, hlt_pow⟩

/-! ### 2. Implicit binary count + max-rational-winner tree `treeNodeVal` over `[0, 2^L)` -/

def treeSubSet (S : Finset ℕ) (k off : ℕ) : Finset ℕ :=
  S.filter (fun h => off * (2 ^ k) ≤ h ∧ h < (off + 1) * (2 ^ k))

theorem treeSubSet_zero (S : Finset ℕ) (h : ℕ) :
    treeSubSet S 0 h = if h ∈ S then {h} else ∅ := by
  ext x
  simp only [treeSubSet, pow_zero, mul_one, Finset.mem_filter]
  split_ifs with hh
  · simp only [Finset.mem_singleton]
    exact ⟨fun ⟨_, h1, h2⟩ => by omega, fun hxeq => by subst hxeq; exact ⟨hh, le_rfl, by omega⟩⟩
  · simp only [Finset.notMem_empty, iff_false, not_and]
    intro hx h1 h2
    have : x = h := by omega
    subst this; exact hh hx

theorem treeSubSet_succ_disjoint (S : Finset ℕ) (k off : ℕ) :
    Disjoint (treeSubSet S k (2 * off)) (treeSubSet S k (2 * off + 1)) ∧
    treeSubSet S (k + 1) off = treeSubSet S k (2 * off) ∪ treeSubSet S k (2 * off + 1) := by
  have hp1 : off * 2 ^ (k + 1) = (2 * off) * 2 ^ k := by rw [pow_succ]; ring
  have hp2 : (off + 1) * 2 ^ (k + 1) = (2 * off + 1 + 1) * 2 ^ k := by rw [pow_succ]; ring
  constructor
  · rw [Finset.disjoint_left]
    intro x hxL hxR
    simp only [treeSubSet, Finset.mem_filter] at hxL hxR
    omega
  · ext x
    simp only [treeSubSet, Finset.mem_filter, Finset.mem_union, hp1, hp2]
    constructor
    · rintro ⟨hx, h1, h2⟩
      by_cases hmid : x < (2 * off + 1) * 2 ^ k
      · exact Or.inl ⟨hx, h1, hmid⟩
      · exact Or.inr ⟨hx, by omega, h2⟩
    · rintro (⟨hx, h1, h2⟩ | ⟨hx, h1, h2⟩)
      · exact ⟨hx, h1, by nlinarith⟩
      · exact ⟨hx, by nlinarith, h2⟩

theorem treeSubSet_root {S : Finset ℕ} {L : ℕ} (hS : ∀ h ∈ S, h < 2 ^ L) :
    treeSubSet S L 0 = S := by
  ext h
  simp only [treeSubSet, zero_mul, zero_add, one_mul, Finset.mem_filter, zero_le, true_and,
    and_iff_left_iff_imp]
  exact hS h

def treeNodeVal (S : Finset ℕ) (rNum rDen : ℕ → ℤ) : ℕ → ℕ → ℕ × ℕ × ℤ × ℤ
  | 0, h => if h ∈ S then (1, h, rNum h, rDen h) else (0, 0, 0, 0)
  | k + 1, off =>
      let (cL, hL, nL, dL) := treeNodeVal S rNum rDen k (2 * off)
      let (cR, hR, nR, dR) := treeNodeVal S rNum rDen k (2 * off + 1)
      if cL = 0 then (cR, hR, nR, dR)
      else if cR = 0 then (cL, hL, nL, dL)
      else if nR * dL ≤ nL * dR then (cL + cR, hL, nL, dL)
      else (cL + cR, hR, nR, dR)

theorem treeNodeVal_cnt (S : Finset ℕ) (rNum rDen : ℕ → ℤ) :
    ∀ (k off : ℕ), (treeNodeVal S rNum rDen k off).1 = (treeSubSet S k off).card
  | 0, h => by
      simp only [treeNodeVal, treeSubSet_zero]
      split_ifs <;> simp
  | k + 1, off => by
      obtain ⟨hdisj, hunion⟩ := treeSubSet_succ_disjoint S k off
      have ihL := treeNodeVal_cnt S rNum rDen k (2 * off)
      have ihR := treeNodeVal_cnt S rNum rDen k (2 * off + 1)
      rcases hL : treeNodeVal S rNum rDen k (2 * off) with ⟨cL, hLv, nL, dL⟩
      rcases hR : treeNodeVal S rNum rDen k (2 * off + 1) with ⟨cR, hRv, nR, dR⟩
      rw [hL] at ihL; rw [hR] at ihR; dsimp only at ihL ihR
      rw [hunion, Finset.card_union_of_disjoint hdisj, ← ihL, ← ihR]
      simp only [treeNodeVal, hL, hR]
      split_ifs <;> omega

theorem treeNodeVal_zero_iff (S : Finset ℕ) (rNum rDen : ℕ → ℤ) (k off : ℕ) :
    (treeNodeVal S rNum rDen k off).1 = 0 ↔ treeNodeVal S rNum rDen k off = (0, 0, 0, 0) := by
  induction k generalizing off with
  | zero =>
      simp only [treeNodeVal]
      split_ifs <;> simp
  | succ k ih =>
      rcases hL : treeNodeVal S rNum rDen k (2 * off) with ⟨cL, hLv, nL, dL⟩
      rcases hR : treeNodeVal S rNum rDen k (2 * off + 1) with ⟨cR, hRv, nR, dR⟩
      have ihL := ih (2 * off); rw [hL] at ihL
      have ihR := ih (2 * off + 1); rw [hR] at ihR
      simp only [treeNodeVal, hL, hR]
      by_cases hcL : cL = 0
      · subst hcL
        simp only [↓reduceIte]
        exact ihR
      · simp only [hcL, ↓reduceIte]
        by_cases hcR : cR = 0
        · subst hcR; simp only [↓reduceIte]
          exact ⟨fun h => False.elim (hcL h), fun h => by injection h⟩
        · simp only [hcR, ↓reduceIte]
          split_ifs <;> exact ⟨fun h => by omega, fun h => by have hc := congrArg Prod.fst h; dsimp at hc; omega⟩

theorem treeNodeVal_winner {S : Finset ℕ} (rNum : ℕ → ℤ) {rDen : ℕ → ℤ}
    (hDen : ∀ h ∈ S, 1 ≤ rDen h) :
    ∀ (k off : ℕ),
      let (c, bh, bn, bd) := treeNodeVal S rNum rDen k off
      0 < c →
        bh ∈ treeSubSet S k off ∧
        bn = rNum bh ∧
        bd = rDen bh ∧
        ∀ h ∈ treeSubSet S k off,
          (rNum h : ℝ) / (rDen h : ℝ) ≤ (bn : ℝ) / (bd : ℝ)
  | 0, h => by
      simp only [treeNodeVal]
      split_ifs with hh
      · intro _
        refine ⟨by simp [treeSubSet_zero, hh], rfl, rfl, fun x hx => ?_⟩
        rw [treeSubSet_zero, if_pos hh, Finset.mem_singleton] at hx
        subst hx; exact le_rfl
      · intro hc; omega
  | k + 1, off => by
      have ihL := treeNodeVal_winner rNum hDen k (2 * off)
      have ihR := treeNodeVal_winner rNum hDen k (2 * off + 1)
      obtain ⟨_, hunion⟩ := treeSubSet_succ_disjoint S k off
      rcases hL : treeNodeVal S rNum rDen k (2 * off) with ⟨cL, hLv, nL, dL⟩
      rcases hR : treeNodeVal S rNum rDen k (2 * off + 1) with ⟨cR, hRv, nR, dR⟩
      simp only [hL] at ihL
      simp only [hR] at ihR
      have hcL_eq := treeNodeVal_cnt S rNum rDen k (2 * off); rw [hL] at hcL_eq
      have hcR_eq := treeNodeVal_cnt S rNum rDen k (2 * off + 1); rw [hR] at hcR_eq
      simp only [treeNodeVal, hL, hR]
      by_cases zL : cL = 0
      · subst zL
        simp only [↓reduceIte]
        have hempL : treeSubSet S k (2 * off) = ∅ := Finset.card_eq_zero.mp hcL_eq.symm
        intro hcR
        obtain ⟨hmR, hnR, hdR, hmaxR⟩ := ihR hcR
        refine ⟨by rw [hunion]; exact Finset.mem_union_right _ hmR, hnR, hdR, fun x hx => ?_⟩
        rw [hunion, hempL, Finset.empty_union] at hx
        exact hmaxR x hx
      · simp only [zL, ↓reduceIte]
        have hposL : 0 < cL := Nat.pos_of_ne_zero zL
        obtain ⟨hmL, hnL, hdL, hmaxL⟩ := ihL hposL
        by_cases zR : cR = 0
        · subst zR
          simp only [↓reduceIte]
          have hempR : treeSubSet S k (2 * off + 1) = ∅ := Finset.card_eq_zero.mp hcR_eq.symm
          intro _
          refine ⟨by rw [hunion]; exact Finset.mem_union_left _ hmL, hnL, hdL, fun x hx => ?_⟩
          rw [hunion, hempR, Finset.union_empty] at hx
          exact hmaxL x hx
        · simp only [zR, ↓reduceIte]
          have hposR : 0 < cR := Nat.pos_of_ne_zero zR
          obtain ⟨hmR, hnR, hdR, hmaxR⟩ := ihR hposR
          have hdL_pos : (0 : ℝ) < (dL : ℝ) := by
            rw [hdL]
            have : 1 ≤ rDen hLv := hDen hLv (Finset.mem_of_mem_filter _ hmL)
            exact_mod_cast (by omega : (0 : ℤ) < rDen hLv)
          have hdR_pos : (0 : ℝ) < (dR : ℝ) := by
            rw [hdR]
            have : 1 ≤ rDen hRv := hDen hRv (Finset.mem_of_mem_filter _ hmR)
            exact_mod_cast (by omega : (0 : ℤ) < rDen hRv)
          by_cases hcmp : nR * dL ≤ nL * dR
          · simp only [hcmp, ↓reduceIte]
            have hdiv_le : (nR : ℝ) / (dR : ℝ) ≤ (nL : ℝ) / (dL : ℝ) := by
              rw [div_le_div_iff₀ hdR_pos hdL_pos]
              exact_mod_cast hcmp
            intro _
            refine ⟨by rw [hunion]; exact Finset.mem_union_left _ hmL, hnL, hdL, fun x hx => ?_⟩
            rw [hunion, Finset.mem_union] at hx
            rcases hx with hxL | hxR
            · exact hmaxL x hxL
            · exact (hmaxR x hxR).trans hdiv_le
          · simp only [hcmp, ↓reduceIte]
            push_neg at hcmp
            have hdiv_le : (nL : ℝ) / (dL : ℝ) ≤ (nR : ℝ) / (dR : ℝ) := by
              rw [div_le_div_iff₀ hdL_pos hdR_pos]
              have hle_z : nL * dR ≤ nR * dL := le_of_lt hcmp
              exact_mod_cast hle_z
            intro _
            refine ⟨by rw [hunion]; exact Finset.mem_union_right _ hmR, hnR, hdR, fun x hx => ?_⟩
            rw [hunion, Finset.mem_union] at hx
            rcases hx with hxL | hxR
            · exact (hmaxL x hxL).trans hdiv_le
            · exact hmaxR x hxR

/-- Updating `S`, `rNum`, `rDen` only at `h₀` leaves `treeNodeVal k off` unchanged whenever
`h₀ ∉ [off * 2^k, (off + 1) * 2^k)`. -/
theorem treeNodeVal_unchanged_off_path {S₁ S₂ : Finset ℕ}
    {rNum₁ rDen₁ rNum₂ rDen₂ : ℕ → ℤ} {h₀ : ℕ}
    (hS : ∀ h ≠ h₀, (h ∈ S₁ ↔ h ∈ S₂))
    (hNum : ∀ h ≠ h₀, rNum₁ h = rNum₂ h)
    (hDen : ∀ h ≠ h₀, rDen₁ h = rDen₂ h) :
    ∀ (k off : ℕ),
      ¬ (off * (2 ^ k) ≤ h₀ ∧ h₀ < (off + 1) * (2 ^ k)) →
      treeNodeVal S₁ rNum₁ rDen₁ k off = treeNodeVal S₂ rNum₂ rDen₂ k off
  | 0, h, hnot => by
      have hne : h ≠ h₀ := by
        intro rfl; apply hnot; simp
      simp only [treeNodeVal, hS h hne, hNum h hne, hDen h hne]
  | k + 1, off, hnot => by
      have hp1 : off * 2 ^ (k + 1) = (2 * off) * 2 ^ k := by rw [pow_succ]; ring
      have hp2 : (off + 1) * 2 ^ (k + 1) = (2 * off + 1 + 1) * 2 ^ k := by rw [pow_succ]; ring
      have hnL : ¬ ((2 * off) * 2 ^ k ≤ h₀ ∧ h₀ < (2 * off + 1) * 2 ^ k) := by
        rintro ⟨h1, h2⟩; exact hnot ⟨by nlinarith, by nlinarith⟩
      have hnR : ¬ ((2 * off + 1) * 2 ^ k ≤ h₀ ∧ h₀ < (2 * off + 1 + 1) * 2 ^ k) := by
        rintro ⟨h1, h2⟩; exact hnot ⟨by nlinarith, by nlinarith⟩
      have ihL := treeNodeVal_unchanged_off_path hS hNum hDen k (2 * off) hnL
      have ihR := treeNodeVal_unchanged_off_path hS hNum hDen k (2 * off + 1) hnR
      simp only [treeNodeVal, ihL, ihR]

/-! ### 3. Top-down `minElem` and `mex` walks on `treeNodeVal` -/

def treeMinWalk (S : Finset ℕ) (rNum rDen : ℕ → ℤ) : ℕ → ℕ → ℕ
  | 0, off => off
  | k + 1, off =>
      if 0 < (treeNodeVal S rNum rDen k (2 * off)).1 then
        treeMinWalk S rNum rDen k (2 * off)
      else
        treeMinWalk S rNum rDen k (2 * off + 1)

theorem treeMinWalk_spec (S : Finset ℕ) (rNum rDen : ℕ → ℤ) :
    ∀ (k off : ℕ) (hne : (treeSubSet S k off).Nonempty),
      treeMinWalk S rNum rDen k off = (treeSubSet S k off).min' hne
  | 0, off, hne => by
      rcases hne with ⟨x, hx⟩
      have hx_sub := hx
      simp only [treeSubSet, pow_zero, mul_one, Finset.mem_filter] at hx_sub
      have h_eq : x = off := by omega
      subst h_eq
      have hsing : treeSubSet S 0 x = {x} := by rw [treeSubSet_zero, if_pos hx_sub.1]
      simp only [treeMinWalk]
      symm
      apply le_antisymm
      · exact Finset.min'_le _ x (by rw [hsing]; simp)
      · exact Finset.le_min' _ _ _ fun y hy => by rw [hsing, Finset.mem_singleton] at hy; omega
  | k + 1, off, hne => by
      obtain ⟨_, hunion⟩ := treeSubSet_succ_disjoint S k off
      have hcL := treeNodeVal_cnt S rNum rDen k (2 * off)
      simp only [treeMinWalk]
      split_ifs with hposL
      · rw [hcL] at hposL
        have hneL : (treeSubSet S k (2 * off)).Nonempty := Finset.card_pos.mp hposL
        rw [treeMinWalk_spec S rNum rDen k (2 * off) hneL]
        apply le_antisymm
        · refine Finset.le_min' _ _ _ fun y hy => ?_
          rw [hunion, Finset.mem_union] at hy
          rcases hy with hyL | hyR
          · exact Finset.min'_le _ y hyL
          · have hm_mem := Finset.min'_mem (treeSubSet S k (2 * off)) hneL
            simp only [treeSubSet, Finset.mem_filter] at hm_mem hyR
            exact le_of_lt (lt_of_lt_of_le hm_mem.2.2 hyR.2.1)
        · exact Finset.min'_le _ _ (by rw [hunion]; exact Finset.mem_union_left _ (Finset.min'_mem _ hneL))
      · rw [hcL] at hposL
        have hempL : treeSubSet S k (2 * off) = ∅ := Finset.card_eq_zero.mp (by omega)
        have heqR : treeSubSet S (k + 1) off = treeSubSet S k (2 * off + 1) := by
          rw [hunion, hempL, Finset.empty_union]
        have hneR : (treeSubSet S k (2 * off + 1)).Nonempty := heqR ▸ hne
        rw [treeMinWalk_spec S rNum rDen k (2 * off + 1) hneR]
        congr 1
        exact heqR.symm

def treeMexWalk (S : Finset ℕ) (rNum rDen : ℕ → ℤ) : ℕ → ℕ → ℕ
  | 0, off => off
  | k + 1, off =>
      if (treeNodeVal S rNum rDen k (2 * off)).1 < 2 ^ k then
        treeMexWalk S rNum rDen k (2 * off)
      else
        treeMexWalk S rNum rDen k (2 * off + 1)

private theorem subSet_subset_Ico (S : Finset ℕ) (k off : ℕ) :
    treeSubSet S k off ⊆ Finset.Ico (off * 2 ^ k) ((off + 1) * 2 ^ k) := by
  intro x hx
  simp only [treeSubSet, Finset.mem_filter, Finset.mem_Ico] at hx ⊢
  exact hx.2

private theorem card_Ico_pow (k off : ℕ) :
    (Finset.Ico (off * 2 ^ k) ((off + 1) * 2 ^ k)).card = 2 ^ k := by
  rw [Nat.card_Ico, show (off + 1) * 2 ^ k = off * 2 ^ k + 2 ^ k by ring, Nat.add_sub_cancel_left]

theorem treeMexWalk_spec (S : Finset ℕ) (rNum rDen : ℕ → ℤ) :
    ∀ (k off : ℕ),
      (treeSubSet S k off).card < 2 ^ k →
      let m := treeMexWalk S rNum rDen k off
      off * 2 ^ k ≤ m ∧ m < (off + 1) * 2 ^ k ∧ m ∉ S ∧
      ∀ x, off * 2 ^ k ≤ x → x < m → x ∈ S
  | 0, off, hlt => by
      rw [treeSubSet_zero] at hlt
      simp only [treeMexWalk, pow_zero, mul_one] at hlt ⊢
      have hnot : off ∉ S := by
        intro hm; rw [if_pos hm, Finset.card_singleton] at hlt; omega
      exact ⟨le_rfl, by omega, hnot, fun x h1 h2 => by omega⟩
  | k + 1, off, hlt => by
      obtain ⟨hdisj, hunion⟩ := treeSubSet_succ_disjoint S k off
      have hcL := treeNodeVal_cnt S rNum rDen k (2 * off)
      have hp1 : off * 2 ^ (k + 1) = (2 * off) * 2 ^ k := by rw [pow_succ]; ring
      have hp2 : (off + 1) * 2 ^ (k + 1) = (2 * off + 1 + 1) * 2 ^ k := by rw [pow_succ]; ring
      simp only [treeMexWalk]
      split_ifs with hltL
      · rw [hcL] at hltL
        obtain ⟨hm1, hm2, hm_not, hm_prev⟩ := treeMexWalk_spec S rNum rDen k (2 * off) hltL
        exact ⟨by nlinarith, by nlinarith, hm_not, fun x hx1 hx2 => hm_prev x (by nlinarith) hx2⟩
      · rw [hcL] at hltL
        push_neg at hltL
        -- `treeSubSet S k (2 * off)` has size `≥ 2^k` and is a subset of `Ico` of size `2^k`, so it equals `Ico`!
        have hsubL := subSet_subset_Ico S k (2 * off)
        have hcard_Ico := card_Ico_pow k (2 * off)
        have heq_Ico : treeSubSet S k (2 * off) = Finset.Ico ((2 * off) * 2 ^ k) ((2 * off + 1) * 2 ^ k) :=
          Finset.eq_of_subset_of_card_le hsubL (by omega)
        have hltR : (treeSubSet S k (2 * off + 1)).card < 2 ^ k := by
          rw [hunion, Finset.card_union_of_disjoint hdisj] at hlt
          have : 2 ^ (k + 1) = 2 ^ k + 2 ^ k := by rw [pow_succ]; ring
          omega
        obtain ⟨hm1, hm2, hm_not, hm_prev⟩ := treeMexWalk_spec S rNum rDen k (2 * off + 1) hltR
        refine ⟨by nlinarith, by nlinarith, hm_not, fun x hx1 hx2 => ?_⟩
        by_cases hmid : x < (2 * off + 1) * 2 ^ k
        · have hx_Ico : x ∈ Finset.Ico ((2 * off) * 2 ^ k) ((2 * off + 1) * 2 ^ k) :=
            Finset.mem_Ico.mpr ⟨by nlinarith, hmid⟩
          rw [← heq_Ico] at hx_Ico
          exact (Finset.mem_filter.mp hx_Ico).1
        · exact hm_prev x (by nlinarith) hx2

theorem treeMexWalk_root_eq_mexHandle {S : Finset ℕ} (rNum rDen : ℕ → ℤ) {L : ℕ}
    (hS : ∀ h ∈ S, h < 2 ^ L) (hc : S.card < 2 ^ L) :
    treeMexWalk S rNum rDen L 0 = mexHandle S := by
  have hsub : (treeSubSet S L 0).card < 2 ^ L := by rw [treeSubSet_root hS]; exact hc
  obtain ⟨_, _, hnot, hprev⟩ := treeMexWalk_spec S rNum rDen L 0 hsub
  exact (mexHandle_eq_of_notMem_and_forall_lt hnot (fun x hx => hprev x (by simp) hx)).symm

/-! ### 4. Sparsity bound on live nodes in `treeNodeVal` across `k ∈ [0, L]` -/

theorem activeOffsets_card_le (S : Finset ℕ) (rNum rDen : ℕ → ℤ) (L k : ℕ) :
    ((Finset.range (2 ^ (L - k))).filter
      (fun off => 0 < (treeNodeVal S rNum rDen k off).1)).card ≤ S.card := by
  have hsub : (Finset.range (2 ^ (L - k))).filter (fun off => 0 < (treeNodeVal S rNum rDen k off).1) ⊆
      Finset.image (fun h : ℕ => h / (2 ^ k)) S := by
    intro off hoff
    simp only [Finset.mem_filter, treeNodeVal_cnt] at hoff
    obtain ⟨h, hh⟩ := Finset.card_pos.mp hoff.2
    simp only [treeSubSet, Finset.mem_filter] at hh
    refine Finset.mem_image.mpr ⟨h, hh.1, ?_⟩
    have hdiv : h / 2 ^ k = off := by
      apply Nat.le_antisymm
      · exact (Nat.div_lt_iff_lt_mul (Nat.two_pow_pos k)).mpr hh.2.2 |> Nat.lt_succ_iff.mp
      · exact (Nat.le_div_iff_mul_le (Nat.two_pow_pos k)).mpr hh.2.1
    exact hdiv
  exact (Finset.card_le_card hsub).trans Finset.card_image_le

end UL.C12LVE
