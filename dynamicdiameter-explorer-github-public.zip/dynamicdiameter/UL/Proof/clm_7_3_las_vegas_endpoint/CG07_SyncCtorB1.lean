import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorB0
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3c3_Dim0
set_option autoImplicit false
set_option maxHeartbeats 400000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open scoped ENNReal
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### 1. `BitRAMDynamicProgram.evalUpdate` Unpacker Under `ChainStoredInv` -/

theorem c12_evalUpdate_unpack {d s₀_d n L B B_cert K_max W : ℕ}
    (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws)
    {op : DynamicUpdate d}
    (hleg : IsLegalUpdate n (RatAdmissiblePointSet d B) P op)
    (prog : BitRAMDynamicProgram) (initOut : BitRAMExecOutcome) (bs : List Bool) :
    ∃ inp : BitRAMInput d,
      inp.activeHandles = P.activeHandles ∧
      (∀ h ∈ P.activeHandles, inp.activeRatCoords h = qMap h) ∧
      (match op with
       | .insert _ _ pt =>
           ∃ qIns : Fin d → ℚ,
             RatPointBitBounded B qIns ∧
             ratPointToEuclidean qIns = pt ∧
             inp.intParams = [(n : ℤ), 1, 0] ∧
             inp.extraRats = List.ofFn qIns
       | .delete id =>
           inp.intParams = [(n : ℤ), 0, (P.handleOfId id : ℤ)] ∧
           inp.extraRats = []) ∧
      inp.inputCellSpace ≤ n * (2 * d + 1) + 2 * d + 3 ∧
      inp.inputBitSpace ≤ n * (L + 1 + d * (2 * B + 1)) + d * (2 * B + 1) + 2 * L + 8 ∧
      (∀ (rawOut : BitRAMExecOutcome) (P' : DynamicPointSet d),
        runBitRAMWithBits prog.updateStmt inp ws bs = some rawOut →
        applyDynamicUpdate P op (stepRetHandle mexHandle P.activeHandles op) = some P' →
        (match op with
         | .insert _ _ _ => rawOut.words.read (.heap 0 0) = (mexHandle P.activeHandles : ℤ)
         | .delete _ => True) →
        runSingleAdaptiveStep (bitRAMAlg n prog initOut) P ws op bs =
          some (P',
            { nextState := rawOut.words
              returnedHandle := stepRetHandle mexHandle P.activeHandles op
              storedAnswer :=
                let ca := BitRAMDynamicProgram.readCachedAnswer rawOut.words
                { diameterHandles := ca.1, cachedDistSq := ca.2 }
              work := rawOut.bitCost
              peakSpace := rawOut.peakBitSpace })) := by
  classical
  obtain ⟨hL2, _, h2n_pow, _⟩ := clog_two_mul_bounds hn
  rw [← hL] at hL2 h2n_pow
  have hn_lt_pow : n < 2 ^ L := by omega
  have hn_bl : intBitLength (n : ℤ) ≤ L + 2 := nat_lt_pow2_bitLength_le hn_lt_pow
  have hH_card_le : P.activeHandles.card ≤ n :=
    (activeHandles_card_eq hinv.wfP).trans_le hinv.wfP.1
  have hAct_eq_qMap : ∀ h ∈ P.activeHandles,
      euclideanToRatPoint? (P.handleCoords h) = some (qMap h) := by
    intro h hh
    have hid_in : P.idOfHandle h ∈ P.activeIds := (hinv.wfP.2.2.1 h hh).1
    have hh_of : P.handleOfId (P.idOfHandle h) = h := (hinv.wfP.2.2.1 h hh).2
    have hhc : P.handleCoords h = ratPointToEuclidean (qMap h) := by
      simp only [DynamicPointSet.handleCoords, hh, ↓reduceIte]
      rw [(hinv.hlt_sync _ hid_in).2, hh_of]
    obtain ⟨q', hq'_some, _, hq'_euc⟩ :=
      euclideanToRatPoint_of_admissible ⟨qMap h, (hinv.coords_stored.hS h hh).2, hhc.symm⟩
    have hq'_eq : q' = qMap h := ratPointToEuclidean_injective (hq'_euc.trans hhc)
    exact hq'_eq ▸ hq'_some
  have hActRat : ∀ h ∈ P.activeHandles, (euclideanToRatPoint? (P.handleCoords h)).isSome := by
    intro h hh; rw [hAct_eq_qMap h hh]; rfl
  let ratMap : ℕ → Fin d → ℚ := fun h =>
    if hh : h ∈ P.activeHandles then
      (euclideanToRatPoint? (P.handleCoords h)).get (hActRat h hh)
    else
      fun _ => 0
  have hratMap_eq : ∀ h ∈ P.activeHandles, ratMap h = qMap h := by
    intro h hh
    dsimp only [ratMap]
    rw [dif_pos hh]
    exact Option.some.inj ((Option.some_get _).trans (hAct_eq_qMap h hh))
  have hnat_bl_le : ∀ h < 2 ^ L, natBitLength h ≤ L + 1 := by
    intro h hh_lt
    have hb := nat_lt_pow2_bitLength_le hh_lt
    unfold intBitLength at hb
    rw [Int.natAbs_natCast] at hb
    by_cases hh0 : h = 0
    · subst hh0; exact (show natBitLength 0 = 1 from by decide).trans_le (by omega)
    · rw [if_neg (Nat.cast_ne_zero.mpr hh0)] at hb; omega
  have hsum_act_bits :
      (∑ h ∈ P.activeHandles, (natBitLength h + ∑ i : Fin d, ratBitLength (ratMap h i))) ≤
        n * (L + 1 + d * (2 * B + 1)) := by
    calc ∑ h ∈ P.activeHandles, (natBitLength h + ∑ i : Fin d, ratBitLength (ratMap h i))
      _ ≤ ∑ _h ∈ P.activeHandles, (L + 1 + d * (2 * B + 1)) := by
          refine Finset.sum_le_sum (fun h hh => ?_)
          obtain ⟨hh_pow, hq_bnd⟩ := hinv.coords_stored.hS h hh
          have h1 : natBitLength h ≤ L + 1 := hnat_bl_le h hh_pow
          have h2 : ∑ i : Fin d, ratBitLength (ratMap h i) ≤ d * (2 * B + 1) := by
            rw [hratMap_eq h hh]
            calc ∑ i : Fin d, ratBitLength (qMap h i)
              _ ≤ ∑ _i : Fin d, (2 * B + 1) :=
                  Finset.sum_le_sum (fun i _ => (ratBitLength_le_of_bounded (hq_bnd i)).2.2.2)
              _ = d * (2 * B + 1) := by simp
          omega
      _ = P.activeHandles.card * (L + 1 + d * (2 * B + 1)) := by simp
      _ ≤ n * (L + 1 + d * (2 * B + 1)) := Nat.mul_le_mul_right _ hH_card_le
  cases op with
  | insert id_ins ext_ins pt_ins =>
      obtain ⟨qIns, hqIns_some, hqIns_bnd, hqIns_euc⟩ :=
        euclideanToRatPoint_of_admissible hleg.2.2
      let inp : BitRAMInput d :=
        { intParams := [(n : ℤ), 1, 0]
          activeHandles := P.activeHandles
          activeRatCoords := ratMap
          extraRats := List.ofFn qIns }
      have hinp_c : inp.inputCellSpace ≤ n * (2 * d + 1) + 2 * d + 3 := by
        dsimp only [inp, BitRAMInput.inputCellSpace]
        rw [List.length_ofFn]
        have hm : P.activeHandles.card * (2 * d + 1) ≤ n * (2 * d + 1) :=
          Nat.mul_le_mul_right _ hH_card_le
        dsimp only [List.length]; omega
      have hinp_b : inp.inputBitSpace ≤
          n * (L + 1 + d * (2 * B + 1)) + d * (2 * B + 1) + 2 * L + 8 := by
        dsimp only [inp, BitRAMInput.inputBitSpace]
        have hl1 : intBitLength (1 : ℤ) = 2 := by decide
        have hl0 : intBitLength (0 : ℤ) = 1 := by decide
        have hp_sum : (([(n : ℤ), 1, 0].map intBitLength).sum) ≤ 2 * L + 8 := by
          simp only [List.map, List.sum_cons, List.sum_nil, hl1, hl0]
          omega
        have hex_sum : ((List.ofFn qIns).map ratBitLength).sum ≤ d * (2 * B + 1) := by
          rw [List.map_ofFn]
          have hfn_sum : (List.ofFn (ratBitLength ∘ qIns)).sum = ∑ i : Fin d, ratBitLength (qIns i) :=
            Fin.sum_ofFn _
          rw [hfn_sum]
          calc ∑ i : Fin d, ratBitLength (qIns i)
            _ ≤ ∑ _i : Fin d, (2 * B + 1) :=
                Finset.sum_le_sum (fun i _ => (ratBitLength_le_of_bounded (hqIns_bnd i)).2.2.2)
            _ = d * (2 * B + 1) := by simp
        omega
      refine ⟨inp, rfl, hratMap_eq, ⟨qIns, hqIns_bnd, hqIns_euc, rfl, rfl⟩, hinp_c, hinp_b, ?_⟩
      intro rawOut P' hrun happ hret0
      dsimp only at hret0
      have heval : prog.evalUpdate n P.activeHandles P.handleCoords ws true pt_ins 0 bs = some rawOut := by
        unfold BitRAMDynamicProgram.evalUpdate
        rw [dif_pos hActRat]
        simp only [↓reduceIte, hqIns_some]
        exact hrun
      have hret_opt : BitRAMDynamicProgram.readReturnedHandle rawOut.words =
          some (mexHandle P.activeHandles) := by
        unfold BitRAMDynamicProgram.readReturnedHandle
        rw [hret0]; simp
      unfold runSingleAdaptiveStep
      dsimp only [bitRAMAlg, toInternalUpdate, stepRetHandle] at happ ⊢
      rw [heval]
      dsimp only [Option.map]
      rw [hret_opt, happ]
  | delete id_del =>
      have hhDel_in : P.handleOfId id_del ∈ P.activeHandles := (hinv.wfP.2.1 id_del hleg).1
      have hhDel_lt : P.handleOfId id_del < 2 ^ L := (hinv.coords_stored.hS _ hhDel_in).1
      have hhDel_bl : intBitLength (P.handleOfId id_del : ℤ) ≤ L + 2 :=
        nat_lt_pow2_bitLength_le hhDel_lt
      let inp : BitRAMInput d :=
        { intParams := [(n : ℤ), 0, (P.handleOfId id_del : ℤ)]
          activeHandles := P.activeHandles
          activeRatCoords := ratMap
          extraRats := [] }
      have hinp_c : inp.inputCellSpace ≤ n * (2 * d + 1) + 2 * d + 3 := by
        dsimp only [inp, BitRAMInput.inputCellSpace, List.length]
        have hm : P.activeHandles.card * (2 * d + 1) ≤ n * (2 * d + 1) :=
          Nat.mul_le_mul_right _ hH_card_le
        omega
      have hinp_b : inp.inputBitSpace ≤
          n * (L + 1 + d * (2 * B + 1)) + d * (2 * B + 1) + 2 * L + 8 := by
        dsimp only [inp, BitRAMInput.inputBitSpace]
        have hl0 : intBitLength (0 : ℤ) = 1 := by decide
        have hp_sum : (([(n : ℤ), 0, (P.handleOfId id_del : ℤ)].map intBitLength).sum) ≤ 2 * L + 8 := by
          simp only [List.map, List.sum_cons, List.sum_nil, hl0]
          omega
        have hex_sum : (([] : List ℚ).map ratBitLength).sum = 0 := rfl
        omega
      refine ⟨inp, rfl, hratMap_eq, ⟨rfl, rfl⟩, hinp_c, hinp_b, ?_⟩
      intro rawOut P' hrun happ _
      have heval : prog.evalUpdate n P.activeHandles P.handleCoords ws false 0
          (P.handleOfId id_del) bs = some rawOut := by
        unfold BitRAMDynamicProgram.evalUpdate
        rw [dif_pos hActRat]
        simp only [Bool.false_eq_true, ↓reduceIte]
        exact hrun
      unfold runSingleAdaptiveStep
      dsimp only [bitRAMAlg, toInternalUpdate, stepRetHandle] at happ ⊢
      rw [heval]
      dsimp only [Option.map]
      rw [happ]

/-! ### 2. Kraft Lockstep & Prefix-Append Helpers -/

theorem c12_lockstep_of_forward_and_haltProb_one {α β : Type*}
    (f : List Bool → Option α) (g : List Bool → Option β) (R : α → β → Prop)
    (hhalt1 : haltProb f = 1)
    (hg_pf : ∀ b₁ b₂ a₁ a₂, g b₁ = some a₁ → g b₂ = some a₂ → b₁ <+: b₂ → b₁ = b₂)
    (hfwd : ∀ bs x, f bs = some x → ∃ y, g bs = some y ∧ R x y) :
    (∑' bs : List Bool, if (g bs).isSome then bitListProb bs else 0) = 1 ∧
    (∀ bs x, f bs = some x → ∃ y, g bs = some y ∧ R x y) ∧
    (∀ bs y, g bs = some y → ∃ x, f bs = some x ∧ R x y) := by
  have hSub : ∀ bs : List Bool, (f bs).isSome → (g bs).isSome := by
    intro bs hf
    rcases Option.isSome_iff_exists.mp hf with ⟨x, hx⟩
    obtain ⟨y, hy, _⟩ := hfwd bs x hx
    exact hy ▸ rfl
  have hPF : ∀ b₁ b₂ : List Bool, (g b₁).isSome → (g b₂).isSome → b₁ <+: b₂ → b₁ = b₂ := by
    intro b₁ b₂ h1 h2 hp
    rcases Option.isSome_iff_exists.mp h1 with ⟨y₁, hy₁⟩
    rcases Option.isSome_iff_exists.mp h2 with ⟨y₂, hy₂⟩
    exact hg_pf b₁ b₂ y₁ y₂ hy₁ hy₂ hp
  have hhalt1_cl :
      (∑' bs : List Bool,
        @ite ENNReal ((f bs).isSome = true) (Classical.propDecidable _) (bitListProb bs) 0) = 1 := by
    rw [← hhalt1]; unfold haltProb
    exact tsum_congr (fun bs => by split_ifs <;> rfl)
  obtain ⟨hiff, hsumG⟩ := halt_iff_of_forward_and_prob_one
    (fun bs => (f bs).isSome) (fun bs => (g bs).isSome) hSub hPF hhalt1_cl
  have hsumG' : (∑' bs : List Bool, if (g bs).isSome then bitListProb bs else 0) = 1 := by
    rw [← hsumG]
    exact tsum_congr (fun bs => by split_ifs <;> rfl)
  refine ⟨hsumG', hfwd, fun bs y hy => ?_⟩
  have hf_some : (f bs).isSome := (hiff bs).mp (hy ▸ rfl)
  rcases Option.isSome_iff_exists.mp hf_some with ⟨x, hx⟩
  obtain ⟨y', hy', hr⟩ := hfwd bs x hx
  have heq : y' = y := Option.some.inj (hy'.symm.trans hy)
  exact ⟨x, hx, heq ▸ hr⟩

theorem c12_runAdaptiveStepsFrom_append {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d)
    (cur : AdaptivePrefixState d State) (xs : List (List Bool)) (bs : List Bool) :
    runAdaptiveStepsFrom alg adv cur (xs ++ [bs]) =
      match runAdaptiveStepsFrom alg adv cur xs with
      | none => none
      | some mid => runAdaptiveStepsFrom alg adv mid [bs] := by
  induction xs generalizing cur with
  | nil => rfl
  | cons x tail ih =>
      simp only [List.cons_append, runAdaptiveStepsFrom]
      cases runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) x with
      | none => rfl
      | some po => exact ih _

/-! ### 3. Per-`(d, n, B)` Las Vegas & Unbounded Space Transfer (`1 ≤ d`) -/

theorem c12_lasVegas_dpos_of_step_sim
    {d B n s₀_d : ℕ} (hd1 : 1 ≤ d) (hn : 2 ≤ n) (hB1 : 1 ≤ B) (hs₀ : 1 ≤ s₀_d)
    (h_lem_5_2 : S_lem_5_2)
    (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction)
    (h_clm_5_1_block_witness : S_clm_5_1_block_witness)
    {P_node_val P_tot_val : ℝ} (hPn_nn : 0 ≤ P_node_val)
    {ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d s₀_d)}
    (hctor : IsValidSyncNodeConstructor n (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ))) 1
      P_node_val (RatAdmissiblePointSet d B) ctor)
    (hctor_wk : ∀ hist sufPref ltCoords P₀ bs built,
      2 * s₀_d ≤ P₀.card →
      (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
        P₀.card ≤ built.work)
    (hC3_tot : ∀ adv : AdaptiveAdversary d,
      IsValidSyncAdaptiveAdversary n (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ)))
        (RatAdmissiblePointSet d B) ctor (ansPolPosDim d s₀_d (Nat.clog 2 (2 * n))) adv →
      ∀ T : ℕ, 1 ≤ T →
        syncPrefixExpectedRebuildWork (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ))) ctor
          (ansPolPosDim d s₀_d (Nat.clog 2 (2 * n))) adv T ≠ ⊤ ∧
        (syncPrefixExpectedRebuildWork (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ))) ctor
          (ansPolPosDim d s₀_d (Nat.clog 2 (2 * n))) adv T).toReal ≤
          (T : ℝ) * 1 * P_tot_val)
    {B_cert K_max W K_cancel P_step K_sim Space_bound : ℕ}
    {updStmt : BitRAMStmt}
    (hsim : ∀ (c₁ C_nodes : ℝ), 0 < c₁ → 0 < C_nodes →
      (∀ (P : Finset ℕ), P.card ≤ n →
        ∀ (k : ℕ) (nodes : Fin k → ChainNode d)
          (P₀ : Fin k → Finset ℕ)
          (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
          (age : Fin k → ℕ)
          (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
              (paraboloidLiftSet (fun j : P₀ i => ltCoords j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput ltCoords nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * ((P₀ i).card : ℝ) / 16) →
          (k : ℝ) ≤ C_nodes * (1 / (4 * (s₀_d : ℝ)))⁻¹ * Real.log ((n : ℝ) + 1)) →
      ∀ (cur syncNext : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
        (qMap : ℕ → Fin d → ℚ) (ws : WordStore) (op : DynamicUpdate d) (bs : List Bool)
        (inp : BitRAMInput d),
        let L := Nat.clog 2 (2 * n)
        C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) cur →
        cur.nodes.length + 1 ≤ Nat.ceil ((C_nodes + 1) * 4) * s₀_d * L →
        C_nodes * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) ≤
          ((Nat.ceil ((C_nodes + 1) * 4) * s₀_d * L : ℕ) : ℝ) →
        ChainStoredInv n L B B_cert K_max W cur.pointSet cur.ltCoords cur.nodes qMap ws →
        IsLegalUpdate n (RatAdmissiblePointSet d B) cur.pointSet op →
        C12SyncStepDecomp s₀_d L ctor cur syncNext op bs →
        inp.activeHandles = cur.pointSet.activeHandles →
        (∀ h ∈ cur.pointSet.activeHandles, inp.activeRatCoords h = qMap h) →
        (match op with
         | .insert _ _ pt =>
             ∃ qIns : Fin d → ℚ,
               RatPointBitBounded B qIns ∧
               ratPointToEuclidean qIns = pt ∧
               inp.intParams = [(n : ℤ), 1, 0] ∧
               inp.extraRats = List.ofFn qIns
         | .delete id =>
             inp.intParams = [(n : ℤ), 0, (cur.pointSet.handleOfId id : ℤ)] ∧
             inp.extraRats = []) →
        inp.inputCellSpace ≤ n * (2 * d + 1) + 2 * d + 3 →
        inp.inputBitSpace ≤ n * (L + 1 + d * (2 * B + 1)) + d * (2 * B + 1) + 2 * L + 8 →
        ∃ (rawOut : BitRAMExecOutcome) (qMap' : ℕ → Fin d → ℚ),
          runBitRAMWithBits updStmt inp ws bs = some rawOut ∧
          ChainStoredInv n L B B_cert K_max W
            syncNext.pointSet syncNext.ltCoords syncNext.nodes qMap' rawOut.words ∧
          (match op with
           | .insert _ _ _ =>
               rawOut.words.read (.heap 0 0) = (mexHandle cur.pointSet.activeHandles : ℤ)
           | .delete _ => True) ∧
          (let ca := BitRAMDynamicProgram.readCachedAnswer rawOut.words
           ({ diameterHandles := ca.1, cachedDistSq := ca.2 } : StoredDiameterAnswer) =
             ramCheckedAnswer L syncNext.pointSet syncNext.nodes) ∧
          rawOut.bitCost + K_cancel * c12ChainBirthPot syncNext ≤
            P_step + K_cancel * c12ChainBirthPot cur +
              K_sim * (syncNext.totalRebuildWork - cur.totalRebuildWork) ∧
          rawOut.peakBitSpace ≤ Space_bound) :
    let L := Nat.clog 2 (2 * n)
    let prog : BitRAMDynamicProgram := { initStmt := .skip, updateStmt := updStmt }
    let initOut : BitRAMExecOutcome :=
      { words := WordStore.empty
        unitCost := 1
        bitCost := 1
        peakCellSpace := 1
        peakBitSpace := intBitLength (n : ℤ) }
    let alg := bitRAMAlg (d := d) n prog initOut
    prog.evalInit n d = some initOut ∧
    SatisfiesDynamicStorageAndQueryModel 5 1 alg ∧
    SatisfiesLasVegasGuarantee n (Real.sqrt 2)
      (1 + (P_step : ℝ) + (K_sim : ℝ) * P_tot_val)
      (RatAdmissiblePointSet d B) alg ∧
    SatisfiesUnboundedSpaceBound n (RatAdmissiblePointSet d B) alg
      (max (intBitLength (n : ℤ) : ℝ) (Space_bound : ℝ)) := by
  classical
  intro L prog initOut alg
  have heval_init : prog.evalInit n d = some initOut := evalInit_of_initSkip n d updStmt
  have hmodel : SatisfiesDynamicStorageAndQueryModel 5 1 alg :=
    satisfiesDynamicStorage_of_initEmpty n prog initOut rfl
  let L_leaf : ℕ := 2 * s₀_d - 1
  let α : ℝ := 1 / (4 * (s₀_d : ℝ))
  let ansPol := ansPolPosDim d s₀_d L
  let P_α_d : ℝ := 4 * (s₀_d : ℝ)
  have hs₀_R : (1 : ℝ) ≤ (s₀_d : ℝ) := by exact_mod_cast hs₀
  have hPα_ge1 : 1 ≤ P_α_d := by dsimp only [P_α_d]; linarith
  have hα_pos : 0 < α := by dsimp only [α]; positivity
  have hα_le1 : α ≤ 1 := by
    dsimp only [α]; rw [div_le_one (by positivity)]; linarith
  have hbound_α : 1 / P_α_d ≤ α := le_rfl
  have hans : IsValidSyncCheckedAnswerPolicy n (Real.sqrt 2) ansPol :=
    isValidSyncCheckedAnswerPolicy_ansPolPosDim
  obtain ⟨c₁, C_nodes, hc₁_pos, hCn_pos, h51⟩ := h_clm_5_1_chain_contraction
  have h51_len : ∀ (P : Finset ℕ), P.card ≤ n →
      ∀ (k : ℕ) (nodes : Fin k → ChainNode d)
        (P₀ : Fin k → Finset ℕ)
        (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
        (age : Fin k → ℕ)
        (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)),
        (∀ i : Fin k,
          (nodes i).o = o i ∧
          (nodes i).V = liftVariance (o i) (s i) ∧
          1 ≤ (P₀ i).card ∧
          IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
            (paraboloidLiftSet (fun j : P₀ i => ltCoords j.1)) (liftedPoint (o i) (s i)) ∧
          HasNodeAge (P₀ i) (chainInput ltCoords nodes P i.castSucc) (age i) ∧
          (age i : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * ((P₀ i).card : ℝ) / 16) →
        (k : ℝ) ≤ C_nodes * (1 / (4 * (s₀_d : ℝ)))⁻¹ * Real.log ((n : ℝ) + 1) := by
    intro P hP k nodes P₀ o s age ltCoords hchain
    exact ((h51 d ℕ ltCoords α hα_pos hα_le1).2 n P hP).1 k nodes P₀ o s age hchain |>.2.2
  have hstep_pf : ∀ (P : DynamicPointSet d) (ws : WordStore) (op : DynamicUpdate d)
      (b₁ b₂ : List Bool) (a₁ a₂ : DynamicPointSet d × DynamicStepOutcome WordStore),
      runSingleAdaptiveStep alg P ws op b₁ = some a₁ →
      runSingleAdaptiveStep alg P ws op b₂ = some a₂ →
      b₁ <+: b₂ → b₁ = b₂ := by
    intro P ws op b₁ b₂ a₁ a₂ h₁ h₂ hpref
    unfold runSingleAdaptiveStep at h₁ h₂
    cases hs₁ : alg.stepWithBits P.activeHandles P.handleCoords ws (toInternalUpdate P op) b₁ with
    | none => rw [hs₁] at h₁; cases h₁
    | some o₁ =>
        cases hs₂ : alg.stepWithBits P.activeHandles P.handleCoords ws (toInternalUpdate P op) b₂ with
        | none => rw [hs₂] at h₂; cases h₂
        | some o₂ => exact hmodel.2.2.1 _ _ _ _ b₁ b₂ o₁ o₂ hs₁ hs₂ hpref
  let StateRel (cur : SyncSchedulePrefixState d (PosDimNodeData d s₀_d)) (ws : WordStore) : Prop :=
    ∃ qMap : ℕ → Fin d → ℚ, ChainStoredInv n L B B_cert K_max W cur.pointSet cur.ltCoords cur.nodes qMap ws
  let StepMatch (cur syncNext : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
      (op : DynamicUpdate d)
      (res : DynamicPointSet d × DynamicStepOutcome WordStore) : Prop :=
    res.1 = syncNext.pointSet ∧
    C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) syncNext ∧
    StateRel syncNext res.2.nextState ∧
    res.2.returnedHandle = stepRetHandle mexHandle cur.pointSet.activeHandles op ∧
    res.2.storedAnswer = ansPol.checkedAnswer syncNext.pointSet syncNext.nodes ∧
    res.2.work + K_cancel * c12ChainBirthPot syncNext ≤
      P_step + K_cancel * c12ChainBirthPot cur +
        K_sim * (syncNext.totalRebuildWork - cur.totalRebuildWork) ∧
    res.2.peakSpace ≤ Space_bound
  have hstep_lock : ∀ (cur : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
      (ws : WordStore) (op : DynamicUpdate d),
      C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) cur →
      StateRel cur ws →
      IsLegalUpdate n (RatAdmissiblePointSet d B) cur.pointSet op →
      singleStepValidHaltProb alg cur.pointSet ws op = 1 ∧
      (∀ bs syncNext,
        runSingleSyncScheduleStep L_leaf α ctor ansPol cur op bs = some syncNext →
        ∃ res, runSingleAdaptiveStep alg cur.pointSet ws op bs = some res ∧
          StepMatch cur syncNext op res) ∧
      (∀ bs res,
        runSingleAdaptiveStep alg cur.pointSet ws op bs = some res →
        ∃ syncNext,
          runSingleSyncScheduleStep L_leaf α ctor ansPol cur op bs = some syncNext ∧
          StepMatch cur syncNext op res) := by
    intro cur ws op hinvS ⟨qMap, hinvR⟩ hleg
    have hprops := runSingleSyncScheduleStep_props hc₁_pos hCn_pos h51 hn hα_pos hα_le1
      hPα_ge1 hbound_α zero_le_one hPn_nn hctor hans hinvS.1 hleg
    have hhalt1 : haltProb (runSingleSyncScheduleStep L_leaf α ctor ansPol cur op) = 1 := hprops.1
    obtain ⟨hlog_le, hk_le, _⟩ := c12SyncInv_chain_len_bounds hn hs₀ hCn_pos h51 hinvS
    have hfwd : ∀ bs syncNext,
        runSingleSyncScheduleStep L_leaf α ctor ansPol cur op bs = some syncNext →
        ∃ res, runSingleAdaptiveStep alg cur.pointSet ws op bs = some res ∧
          StepMatch cur syncNext op res := by
      intro bs syncNext hfs
      obtain ⟨hinvS_next, hdec⟩ :=
        c12SyncStep_decomp hn hs₀ hc₁_pos hCn_pos h51 hPn_nn hctor hctor_wk hinvS hleg hfs
      obtain ⟨inp, hinp_H, hinp_q, hinp_sp, hinp_c, hinp_b, hunpack⟩ :=
        c12_evalUpdate_unpack hn rfl hinvR hleg prog initOut bs
      obtain ⟨rawOut, qMap', hrun, hinvR_next, hret0, hca_eq, hwk_le, hsp_le⟩ :=
        hsim c₁ C_nodes hc₁_pos hCn_pos h51_len cur syncNext qMap ws op bs inp
          hinvS hk_le hlog_le hinvR hleg hdec hinp_H hinp_q (by cases op <;> exact hinp_sp) hinp_c hinp_b
      have hadap := hunpack rawOut syncNext.pointSet hrun hdec.apply_eq (by cases op <;> exact hret0)
      have hans_eq : (ansPolPosDim d s₀_d L).checkedAnswer syncNext.pointSet syncNext.nodes =
          ramCheckedAnswer L syncNext.pointSet syncNext.nodes :=
        (ramCheckedAnswer_valid_of_chainStoredInv h_lem_5_2 h_clm_5_1_block_witness hinvR_next).2
      refine ⟨_, hadap, rfl, hinvS_next, ⟨qMap', hinvR_next⟩, rfl, ?_, hwk_le, hsp_le⟩
      dsimp only [ansPol]
      rw [hca_eq, hans_eq]
    have hlock := c12_lockstep_of_forward_and_haltProb_one
      (runSingleSyncScheduleStep L_leaf α ctor ansPol cur op)
      (runSingleAdaptiveStep alg cur.pointSet ws op)
      (fun syncNext res => StepMatch cur syncNext op res)
      hhalt1 (hstep_pf cur.pointSet ws op) hfwd
    exact ⟨hlock.1, hfwd, hlock.2.2⟩
  let PrefixMatch (bitTrace : List (List Bool))
      (syncSt : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
      (adapSt : AdaptivePrefixState d WordStore) : Prop :=
    C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) syncSt ∧
    StateRel syncSt adapSt.algState ∧
    adapSt.pointSet = syncSt.pointSet ∧
    adapSt.history = syncSt.history ∧
    adapSt.snapshots = syncSt.snapshots ∧
    adapSt.totalWork + K_cancel * c12ChainBirthPot syncSt ≤
      1 + bitTrace.length * P_step + K_sim * syncSt.totalRebuildWork ∧
    adapSt.maxSpace ≤ max (intBitLength (n : ℤ)) Space_bound
  have htrace_lock : ∀ (adv : AdaptiveAdversary d),
      IsValidAdaptiveAdversary n (RatAdmissiblePointSet d B) alg adv →
      ∀ (bitTrace : List (List Bool)),
        (∀ syncSt,
          runSyncScheduleSteps L_leaf α ctor ansPol adv bitTrace = some syncSt →
          ∃ adapSt, runAdaptiveSteps alg adv bitTrace = some adapSt ∧
            PrefixMatch bitTrace syncSt adapSt) ∧
        (∀ adapSt,
          runAdaptiveSteps alg adv bitTrace = some adapSt →
          ∃ syncSt, runSyncScheduleSteps L_leaf α ctor ansPol adv bitTrace = some syncSt ∧
            PrefixMatch bitTrace syncSt adapSt) := by
    intro adv hadv bitTrace
    induction bitTrace using List.reverseRecOn with
    | nil =>
        have hrel0 : StateRel (initSyncSchedulePrefixState d (PosDimNodeData d s₀_d)) initOut.words :=
          ⟨fun _ _ => 0, ChainStoredInv.init⟩
        have hpm0 : PrefixMatch [] (initSyncSchedulePrefixState d (PosDimNodeData d s₀_d))
            (initAdaptivePrefixState alg) := by
          refine ⟨c12SyncInv_init _ _ _ _ _ _, hrel0, rfl, rfl, rfl, ?_, le_max_left _ _⟩
          simp [initAdaptivePrefixState, initSyncSchedulePrefixState, c12ChainBirthPot, alg, bitRAMAlg, initOut]
        constructor
        · intro syncSt hs
          simp only [runSyncScheduleSteps, runSyncScheduleStepsFrom, Option.some.injEq] at hs
          subst hs
          exact ⟨initAdaptivePrefixState alg, rfl, hpm0⟩
        · intro adapSt ha
          simp only [runAdaptiveSteps, runAdaptiveStepsFrom, Option.some.injEq] at ha
          subst ha
          exact ⟨initSyncSchedulePrefixState d (PosDimNodeData d s₀_d), rfl, hpm0⟩
    | append_singleton xs bs ih =>
        have hstep_both :
            ∀ (midS : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
              (midA : AdaptivePrefixState d WordStore),
              runAdaptiveSteps alg adv xs = some midA →
              PrefixMatch xs midS midA →
              (∀ syncNext,
                runSingleSyncScheduleStep L_leaf α ctor ansPol midS (adv midS.history) bs = some syncNext →
                ∃ adapNext,
                  runAdaptiveStepsFrom alg adv midA [bs] = some adapNext ∧
                  PrefixMatch (xs ++ [bs]) syncNext adapNext) ∧
              (∀ adapNext,
                runAdaptiveStepsFrom alg adv midA [bs] = some adapNext →
                ∃ syncNext,
                  runSingleSyncScheduleStep L_leaf α ctor ansPol midS (adv midS.history) bs = some syncNext ∧
                  PrefixMatch (xs ++ [bs]) syncNext adapNext) := by
          intro midS midA hmidA ⟨hinvM, hrelM, hpEq, hhEq, hsnEq, hwM, hspM⟩
          have hlegA := hadv xs midA hmidA
          have hlegS : IsLegalUpdate n (RatAdmissiblePointSet d B) midS.pointSet (adv midS.history) := by
            rwa [hpEq, hhEq] at hlegA
          let op := adv midS.history
          have hsl := hstep_lock midS midA.algState op hinvM hrelM hlegS
          constructor
          · intro syncNext hfs
            obtain ⟨_, hdec⟩ :=
              c12SyncStep_decomp hn hs₀ hc₁_pos hCn_pos h51 hPn_nn hctor hctor_wk hinvM hlegS hfs
            obtain ⟨⟨P', outStep⟩, hgs, hp', hinv', hrel', hret', hans', hw', hsp'⟩ := hsl.2.1 bs syncNext hfs
            dsimp only at hp' hrel' hret' hans' hw' hsp'
            subst hp'
            have hadap_step :
                runAdaptiveStepsFrom alg adv midA [bs] =
                  some
                    { pointSet := syncNext.pointSet
                      algState := outStep.nextState
                      history := midA.history ++
                        [{ operation := adv midA.history
                           randomBits := bs
                           returnedHandle := outStep.returnedHandle
                           answer := outStep.storedAnswer
                           resolvedIds := resolveAnswerIdentities syncNext.pointSet outStep.storedAnswer }]
                      snapshots := midA.snapshots ++ [(syncNext.pointSet, outStep.storedAnswer)]
                      stepWorks := midA.stepWorks ++ [outStep.work]
                      totalWork := midA.totalWork + outStep.work
                      maxSpace := max midA.maxSpace outStep.peakSpace } := by
              simp only [runAdaptiveStepsFrom]
              have hgs' : runSingleAdaptiveStep alg midA.pointSet midA.algState (adv midA.history) bs =
                  some (syncNext.pointSet, outStep) := by
                rwa [hpEq, hhEq]
              rw [hgs']
            refine ⟨_, hadap_step, hinv', hrel', rfl, ?_, ?_, ?_, ?_⟩
            · dsimp only [ansPol] at hans'
              dsimp only
              rw [hhEq, hret', hans', hdec.history_eq]
            · dsimp only [ansPol] at hans'
              dsimp only
              rw [hsnEq, hans', hdec.snapshots_eq]
            · dsimp only
              simp only [List.length_append, List.length_singleton]
              have hmul : (xs.length + 1) * P_step = xs.length * P_step + P_step := by ring
              have htrw : K_sim * midS.totalRebuildWork +
                  K_sim * (syncNext.totalRebuildWork - midS.totalRebuildWork) =
                  K_sim * syncNext.totalRebuildWork := by
                rw [← Nat.mul_add, Nat.add_sub_of_le hdec.work_mono]
              have := hwM; have := hw'; omega
            · dsimp only
              exact max_le hspM (hsp'.trans (le_max_right _ _))
          · intro adapNext has
            simp only [runAdaptiveStepsFrom] at has
            cases hgsA : runSingleAdaptiveStep alg midA.pointSet midA.algState (adv midA.history) bs with
            | none => simp [hgsA] at has
            | some pair =>
                rcases pair with ⟨P', outStep⟩
                simp only [hgsA, Option.some.injEq] at has
                have hgsS : runSingleAdaptiveStep alg midS.pointSet midA.algState op bs =
                    some (P', outStep) := by
                  dsimp only [op]; rwa [hpEq, hhEq] at hgsA
                obtain ⟨syncNext, hfs, hp', hinv', hrel', hret', hans', hw', hsp'⟩ :=
                  hsl.2.2 bs (P', outStep) hgsS
                dsimp only at hp' hrel' hret' hans' hw' hsp'
                subst hp'; subst has
                obtain ⟨_, hdec⟩ :=
                  c12SyncStep_decomp hn hs₀ hc₁_pos hCn_pos h51 hPn_nn hctor hctor_wk hinvM hlegS hfs
                refine ⟨syncNext, hfs, hinv', hrel', rfl, ?_, ?_, ?_, ?_⟩
                · dsimp only [ansPol] at hans'
                  dsimp only
                  rw [hhEq, hret', hans', hdec.history_eq]
                · dsimp only [ansPol] at hans'
                  dsimp only
                  rw [hsnEq, hans', hdec.snapshots_eq]
                · dsimp only
                  simp only [List.length_append, List.length_singleton]
                  have hmul : (xs.length + 1) * P_step = xs.length * P_step + P_step := by ring
                  have htrw : K_sim * midS.totalRebuildWork +
                      K_sim * (syncNext.totalRebuildWork - midS.totalRebuildWork) =
                      K_sim * syncNext.totalRebuildWork := by
                    rw [← Nat.mul_add, Nat.add_sub_of_le hdec.work_mono]
                  have := hwM; have := hw'; omega
                · dsimp only
                  exact max_le hspM (hsp'.trans (le_max_right _ _))
        constructor
        · intro syncNext hrunS
          unfold runSyncScheduleSteps at hrunS
          rw [runSyncScheduleStepsFrom_append] at hrunS
          cases hmidS : runSyncScheduleStepsFrom L_leaf α ctor ansPol adv
              (initSyncSchedulePrefixState d (PosDimNodeData d s₀_d)) xs with
          | none => rw [hmidS] at hrunS; cases hrunS
          | some midS =>
              rw [hmidS] at hrunS; dsimp only at hrunS
              obtain ⟨midA, hmidA, hpm⟩ := ih.1 midS hmidS
              obtain ⟨adapNext, has, hpm'⟩ := (hstep_both midS midA hmidA hpm).1 syncNext hrunS
              refine ⟨adapNext, ?_, hpm'⟩
              unfold runAdaptiveSteps at hmidA ⊢
              rw [c12_runAdaptiveStepsFrom_append, hmidA]
              exact has
        · intro adapNext hrunA
          unfold runAdaptiveSteps at hrunA
          rw [c12_runAdaptiveStepsFrom_append] at hrunA
          cases hmidA : runAdaptiveStepsFrom alg adv (initAdaptivePrefixState alg) xs with
          | none => rw [hmidA] at hrunA; cases hrunA
          | some midA =>
              rw [hmidA] at hrunA; dsimp only at hrunA
              obtain ⟨midS, hmidS, hpm⟩ := ih.2 midA hmidA
              obtain ⟨syncNext, hfs, hpm'⟩ := (hstep_both midS midA hmidA hpm).2 adapNext hrunA
              refine ⟨syncNext, ?_, hpm'⟩
              unfold runSyncScheduleSteps at hmidS ⊢
              rw [runSyncScheduleStepsFrom_append, hmidS]
              exact hfs
  have hadv_sync : ∀ adv : AdaptiveAdversary d,
      IsValidAdaptiveAdversary n (RatAdmissiblePointSet d B) alg adv →
      IsValidSyncAdaptiveAdversary n L_leaf α (RatAdmissiblePointSet d B) ctor ansPol adv := by
    intro adv hadv bitTrace syncSt hrunS
    obtain ⟨adapSt, hrunA, hpm⟩ := (htrace_lock adv hadv bitTrace).1 syncSt hrunS
    have hlegA := hadv bitTrace adapSt hrunA
    rwa [hpm.2.2.1, hpm.2.2.2.1] at hlegA
  refine ⟨heval_init, hmodel, ⟨?_, ?_⟩, ⟨le_max_left _ _, ?_⟩⟩
  · intro adv hadv
    refine ⟨fun bitTrace prefSt hrunA => ?_, fun T trace out hrunA => ?_⟩
    · obtain ⟨syncSt, _, hpm⟩ := (htrace_lock adv hadv bitTrace).2 prefSt hrunA
      have hlegA := hadv bitTrace prefSt hrunA
      have hlegS : IsLegalUpdate n (RatAdmissiblePointSet d B) syncSt.pointSet (adv syncSt.history) := by
        rwa [hpm.2.2.1, hpm.2.2.2.1] at hlegA
      have hsl := hstep_lock syncSt prefSt.algState (adv syncSt.history) hpm.1 hpm.2.1 hlegS
      rw [hpm.2.2.1, hpm.2.2.2.1]
      exact hsl.1
    · unfold runAdaptivePrefix at hrunA
      obtain ⟨syncSt, _, hpm⟩ := (htrace_lock adv hadv (List.ofFn trace)).2 out hrunA
      unfold AllPrefixAnswersValid
      rw [hpm.2.2.2.2.1]
      rcases hpm.1 with ⟨⟨_, _, _, _, _, _, hsnaps_valid, _⟩, _⟩
      exact hsnaps_valid
  · intro adv hadv T hT
    have hsync_adv := hadv_sync adv hadv
    obtain ⟨htot_fin, htot_le⟩ := hC3_tot adv hsync_adv T hT
    have hprob_work := syncPrefix_prob_and_work hc₁_pos hCn_pos h51 hn hα_pos hα_le1
      hPα_ge1 hbound_α zero_le_one hPn_nn hctor hans hsync_adv T
    have hprob1 := hprob_work.1
    let C_base : ℕ := 1 + T * P_step
    have hwork_le_sum :
        adaptivePrefixExpectedWork alg adv T ≤
          (C_base : ENNReal) +
            (K_sim : ENNReal) * syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv T := by
      have hadap_elim :
          adaptivePrefixExpectedWork alg adv T =
            ∑' tr : Fin T → List Bool,
              Option.elim (runAdaptivePrefix alg adv T tr) 0
                (fun out => prefixTraceProb tr * (out.totalWork : ENNReal)) := by
        unfold adaptivePrefixExpectedWork; congr 1; ext tr
        cases runAdaptivePrefix alg adv T tr <;> rfl
      have hsync_elim :
          syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv T =
            ∑' tr : Fin T → List Bool,
              Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr) 0
                (fun syncOut => prefixTraceProb tr * (syncOut.totalRebuildWork : ENNReal)) := by
        unfold syncPrefixExpectedRebuildWork; congr 1; ext tr
        cases runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr <;> rfl
      rw [hadap_elim, hsync_elim]
      have hpointwise :
          ∀ tr : Fin T → List Bool,
            Option.elim (runAdaptivePrefix alg adv T tr) 0
              (fun out => prefixTraceProb tr * (out.totalWork : ENNReal)) ≤
            (if (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr).isSome then
               prefixTraceProb tr
             else 0) * (C_base : ENNReal) +
            (K_sim : ENNReal) *
              Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr) 0
                (fun syncOut => prefixTraceProb tr * (syncOut.totalRebuildWork : ENNReal)) := by
        intro tr
        cases ha : runAdaptivePrefix alg adv T tr with
        | none => simp
        | some adapOut =>
            obtain ⟨syncOut, hs, hpm⟩ := (htrace_lock adv hadv (List.ofFn tr)).2 adapOut ha
            have hs_pref : runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr = some syncOut := hs
            rw [hs_pref]
            simp only [Option.elim_some, Option.isSome_some, ↓reduceIte]
            have hw_nat : adapOut.totalWork ≤ C_base + K_sim * syncOut.totalRebuildWork := by
              have hlen_tr : (List.ofFn tr).length = T := List.length_ofFn
              have hpm_w := hpm.2.2.2.2.2.1
              rw [hlen_tr] at hpm_w
              dsimp only [C_base]
              omega
            calc
              prefixTraceProb tr * (adapOut.totalWork : ENNReal)
                  ≤ prefixTraceProb tr * ((C_base + K_sim * syncOut.totalRebuildWork : ℕ) : ENNReal) :=
                    mul_le_mul_of_nonneg_left (Nat.cast_le.mpr hw_nat) (zero_le _)
              _ = prefixTraceProb tr * (C_base : ENNReal) +
                    (K_sim : ENNReal) * (prefixTraceProb tr * (syncOut.totalRebuildWork : ENNReal)) := by
                    push_cast; ring
      calc
        (∑' tr : Fin T → List Bool,
          Option.elim (runAdaptivePrefix alg adv T tr) 0
            (fun out => prefixTraceProb tr * (out.totalWork : ENNReal)))
            ≤ ∑' tr : Fin T → List Bool,
                ((if (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr).isSome then
                    prefixTraceProb tr
                  else 0) * (C_base : ENNReal) +
                 (K_sim : ENNReal) *
                  Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr) 0
                    (fun syncOut => prefixTraceProb tr * (syncOut.totalRebuildWork : ENNReal))) :=
              ENNReal.tsum_le_tsum hpointwise
        _ = (C_base : ENNReal) +
              (K_sim : ENNReal) *
                ∑' tr : Fin T → List Bool,
                  Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr) 0
                    (fun syncOut => prefixTraceProb tr * (syncOut.totalRebuildWork : ENNReal)) := by
              rw [ENNReal.tsum_add, ENNReal.tsum_mul_right, hprob1, one_mul, ENNReal.tsum_mul_left]
    have hrhs_fin :
        (C_base : ENNReal) +
          (K_sim : ENNReal) * syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv T ≠ ⊤ :=
      ENNReal.add_ne_top.mpr
        ⟨ENNReal.natCast_ne_top _,
         ENNReal.mul_ne_top (ENNReal.natCast_ne_top _) htot_fin⟩
    have hexp_fin : adaptivePrefixExpectedWork alg adv T ≠ ⊤ :=
      ne_top_of_le_ne_top hrhs_fin hwork_le_sum
    refine ⟨hexp_fin, ?_⟩
    have htoReal_le := ENNReal.toReal_mono hrhs_fin hwork_le_sum
    rw [ENNReal.toReal_add (ENNReal.natCast_ne_top _)
          (ENNReal.mul_ne_top (ENNReal.natCast_ne_top _) htot_fin),
        ENNReal.toReal_natCast,
        ENNReal.toReal_mul,
        ENNReal.toReal_natCast] at htoReal_le
    rw [div_le_iff₀ (by exact_mod_cast (show 0 < T by omega))]
    have hT_ge1 : (1 : ℝ) ≤ (T : ℝ) := by exact_mod_cast hT
    have hC_base_R : (C_base : ℝ) = 1 + (T : ℝ) * (P_step : ℝ) := by
      dsimp only [C_base]; push_cast; ring
    rw [hC_base_R] at htoReal_le
    have hK_mul :
        (K_sim : ℝ) * (syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv T).toReal ≤
          (K_sim : ℝ) * ((T : ℝ) * P_tot_val) := by
      refine mul_le_mul_of_nonneg_left ?_ (Nat.cast_nonneg _)
      linarith only [htot_le]
    nlinarith only [htoReal_le, hT_ge1, hK_mul]
  · intro adv hadv T trace out hrunA
    unfold runAdaptivePrefix at hrunA
    obtain ⟨_, _, hpm⟩ := (htrace_lock adv hadv (List.ofFn trace)).2 out hrunA
    have hsp_nat := hpm.2.2.2.2.2.2
    have hcast : ((max (intBitLength (n : ℤ)) Space_bound : ℕ) : ℝ) =
        max (intBitLength (n : ℤ) : ℝ) (Space_bound : ℝ) := by
      push_cast; rfl
    rw [← hcast]
    exact_mod_cast hsp_nat

end UL.C12LVE
