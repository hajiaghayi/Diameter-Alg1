import Mathlib
import UL.Def.def_paraboloid_lift_variance
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3c4_RatOps
set_option autoImplicit false
set_option maxHeartbeats 800000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Heap Table `3` Addressing and `NodeGeomStored` -/

def nodeCellAddr (nodeStride j off : ℕ) : ℤ :=
  ((j * nodeStride + off : ℕ) : ℤ)

theorem nodeCellAddr_inj {nodeStride j₁ off₁ j₂ off₂ : ℕ}
    (h₁ : off₁ < nodeStride) (h₂ : off₂ < nodeStride)
    (heq : nodeCellAddr nodeStride j₁ off₁ = nodeCellAddr nodeStride j₂ off₂) :
    j₁ = j₂ ∧ off₁ = off₂ := by
  unfold nodeCellAddr at heq
  have hnat : j₁ * nodeStride + off₁ = j₂ * nodeStride + off₂ := by exact_mod_cast heq
  rcases lt_trichotomy j₁ j₂ with hlt | rfl | hgt
  · have hm : (j₁ + 1) * nodeStride ≤ j₂ * nodeStride := Nat.mul_le_mul_right nodeStride (by clear * - hlt; omega)
    have ha : j₁ * nodeStride + off₁ < (j₁ + 1) * nodeStride := by rw [add_mul, one_mul]; clear * - h₁; omega
    clear * - hnat hm ha; omega
  · exact ⟨rfl, by clear * - hnat; omega⟩
  · have hm : (j₂ + 1) * nodeStride ≤ j₁ * nodeStride := Nat.mul_le_mul_right nodeStride (by clear * - hgt; omega)
    have ha : j₂ * nodeStride + off₂ < (j₂ + 1) * nodeStride := by rw [add_mul, one_mul]; clear * - h₂; omega
    clear * - hnat hm ha; omega

theorem nodeCellAddr_bl {nodeStride K_max j off W : ℕ}
    (hj : j ≤ K_max + 1) (hoff : off < nodeStride)
    (hW : natBitLength ((K_max + 2) * nodeStride) + 8 ≤ W) :
    (RAMCellLoc.heap 3 (nodeCellAddr nodeStride j off)).bitLength ≤ W ∧
    intBitLength (nodeCellAddr nodeStride j off) ≤ W := by
  have hlt : j * nodeStride + off < (K_max + 2) * nodeStride := by
    have hm : (j + 1) * nodeStride ≤ (K_max + 2) * nodeStride :=
      Nat.mul_le_mul_right nodeStride (by clear * - hj; omega)
    have ha : j * nodeStride + off < (j + 1) * nodeStride := by
      rw [add_mul, one_mul]; clear * - hoff; omega
    exact lt_of_lt_of_le ha hm
  have h1 := intBitLength_ofNat_le (j * nodeStride + off)
  have h2 := natBitLength_mono (Nat.le_of_lt hlt)
  have hn3 : natBitLength 3 = 2 := by decide
  refine ⟨?_, ?_⟩
  · dsimp only [RAMCellLoc.bitLength, nodeCellAddr]; rw [hn3]; clear * - h1 h2 hW; omega
  · dsimp only [nodeCellAddr]; clear * - h1 h2 hW; omega

structure NodeGeomStored (d nodeStride B_cert j : ℕ)
    (oRat : Fin d → ℚ) (V_num V_den : ℤ) (V : ℝ) (ws : WordStore) : Prop where
  hV_nn : 0 ≤ V
  hV_den : 1 ≤ V_den
  hV_eq : ((V_num : ℝ) / (V_den : ℝ)) = V
  hVN_bl : intBitLength V_num ≤ (d + 1) * (2 * B_cert + 7) + 4
  hVD_bl : intBitLength V_den ≤ (d + 1) * (2 * B_cert + 7) + 4
  read_VN : ws.read (.heap 3 (nodeCellAddr nodeStride j 3)) = V_num
  read_VD : ws.read (.heap 3 (nodeCellAddr nodeStride j 4)) = V_den
  read_o : ∀ c : Fin d,
    let oN := ws.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val)))
    let oD := ws.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val + 1)))
    1 ≤ oD ∧ (oRat c : ℝ) = (oN : ℝ) / (oD : ℝ) ∧
    intBitLength oN ≤ B_cert ∧ intBitLength oD ≤ B_cert

theorem NodeGeomStored.unchanged {d nodeStride B_cert j : ℕ}
    {oRat : Fin d → ℚ} {V_num V_den : ℤ} {V : ℝ} {ws₁ ws₂ : WordStore}
    (h : NodeGeomStored d nodeStride B_cert j oRat V_num V_den V ws₁)
    (heq : ∀ off : ℕ, off < 6 + 2 * d →
      ws₂.read (.heap 3 (nodeCellAddr nodeStride j off)) =
        ws₁.read (.heap 3 (nodeCellAddr nodeStride j off))) :
    NodeGeomStored d nodeStride B_cert j oRat V_num V_den V ws₂ :=
  { hV_nn := h.hV_nn
    hV_den := h.hV_den
    hV_eq := h.hV_eq
    hVN_bl := h.hVN_bl
    hVD_bl := h.hVD_bl
    read_VN := (heq 3 (by clear * -; omega)).trans h.read_VN
    read_VD := (heq 4 (by clear * -; omega)).trans h.read_VD
    read_o := fun c => by
      have e0 := heq (6 + 2 * c.val) (by have hc := c.isLt; clear * - hc; omega)
      have e1 := heq (6 + 2 * c.val + 1) (by have hc := c.isLt; clear * - hc; omega)
      have ho := h.read_o c
      dsimp only at ho ⊢
      rwa [e0, e1] }

/-! ### 2. `sqRadAndCoreRegs`: Squared Radius to `o_j` and Exact Core Membership Test -/

def sqRadCoordStepStmt (nodeStride : ℕ) : BitRAMStmt :=
  .seq (rMul 8 1 7)
  (.seq (rAdd 8 8 6)
  (.seq (rAdd 8 8 8)
  (.seq (rLoad 9 1 8)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
  (.seq (rLoad 10 1 8)
  (.seq (rLit 8 (nodeStride : ℤ))
  (.seq (rMul 8 0 8)
  (.seq (rLit 15 6)
  (.seq (rAdd 8 8 15)
  (.seq (rAdd 8 8 6)
  (.seq (rAdd 8 8 6)
  (.seq (rLoad 11 3 8)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
  (.seq (rLoad 12 3 8)
  (.seq accumSqDiffRegs
  (.seq (rLit 15 1)
        (rAdd 6 6 15)))))))))))))))))))

def sqRadAndCoreRegs (d nodeStride : ℕ) : BitRAMStmt :=
  .seq (rLit 3 0)
  (.seq (rLit 4 1)
  (.seq (rLit 6 0)
  (.seq (rLit 7 (d : ℤ))
  (.seq (.repeatN (.lit (d : ℤ)) (sqRadCoordStepStmt nodeStride))
  (.seq (rLit 8 (nodeStride : ℤ))
  (.seq (rMul 8 0 8)
  (.seq (rLit 15 3)
  (.seq (rAdd 8 8 15)
  (.seq (rLoad 11 3 8)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
  (.seq (rLoad 12 3 8)
  (.seq (rMul 13 3 12)
  (.seq (rMul 14 11 4)
        (.ite (.intLe (.readLocal 13 (.lit 0)) (.readLocal 14 (.lit 0)))
          (rLit 2 0) (rLit 2 1))))))))))))))))

open Classical in
theorem exec_sqRadAndCoreRegs {d : ℕ} (_hd1 : 1 ≤ d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws : WordStore}
    (hcCeil : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit)
    {L B B_cert nodeStride K_max j h : ℕ}
    (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    (hj : j ≤ K_max + 1) (hstride : 6 + 2 * d ≤ nodeStride)
    (hW : (2 * d + 2) * (2 * B + 2 * B_cert + 8) + natBitLength ((K_max + 2) * nodeStride) +
            natBitLength d + L + 32 ≤ W)
    {S : Finset ℕ} {qMap : ℕ → Fin d → ℚ}
    (hcoords : ActiveCoordsStored d L B S qMap ws) (hh : h ∈ S)
    {oRat : Fin d → ℚ} {V_num V_den : ℤ} {V : ℝ}
    (hnode : NodeGeomStored d nodeStride B_cert j oRat V_num V_den V ws)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (j : ℤ)) (hr1 : regs 1 = (h : ℤ)) :
    ∃ regsEnd,
      RegExec inp fd W C_cell C_bit (sqRadAndCoreRegs d nodeStride) ws regs ws regsEnd
        (240 * d + 120) ((56 * d + 32) * W * W) ∧
      RegBounded W regsEnd ∧
      regsEnd 0 = (j : ℤ) ∧ regsEnd 1 = (h : ℤ) ∧ regsEnd 5 = regs 5 ∧
      1 ≤ regsEnd 4 ∧ 0 ≤ regsEnd 3 ∧
      ((regsEnd 3 : ℝ) / (regsEnd 4 : ℝ)) =
        ‖ratPointToEuclidean (qMap h) - ratPointToEuclidean oRat‖ ^ 2 ∧
      intBitLength (regsEnd 3) ≤ d * (2 * ((B + 2) + B_cert) + 3) + 2 ∧
      intBitLength (regsEnd 4) ≤ d * (2 * ((B + 2) + B_cert) + 2) + 2 ∧
      regsEnd 2 = (if ratPointToEuclidean (qMap h) ∈ coreBall (ratPointToEuclidean oRat) V then 0 else 1) := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hWW : 20 * W ≤ W * W := by nlinarith only [hW20]
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by clear * - hW20; omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by clear * - hW20; omega)
  have hl3 : intBitLength (3 : ℤ) ≤ W := (show intBitLength (3 : ℤ) = 3 from by decide).trans_le (by clear * - hW20; omega)
  have hl6 : intBitLength (6 : ℤ) ≤ W := (show intBitLength (6 : ℤ) = 4 from by decide).trans_le (by clear * - hW20; omega)
  have hn1 : natBitLength 1 ≤ W := (show natBitLength 1 = 1 from by decide).trans_le (by clear * - hW20; omega)
  have hn3 : natBitLength 3 ≤ W := (show natBitLength 3 = 2 from by decide).trans_le (by clear * - hW20; omega)
  have hd_bl : intBitLength (d : ℤ) ≤ W := (intBitLength_ofNat_le d).trans (by clear * - hW; omega)
  have hW_addr : natBitLength d + L + 12 ≤ W := by clear * - hW; omega
  have hW_node : natBitLength ((K_max + 2) * nodeStride) + 8 ≤ W := by clear * - hW; omega
  have hstride_bl : intBitLength (nodeStride : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le nodeStride
    have h2 : natBitLength nodeStride ≤ natBitLength ((K_max + 2) * nodeStride) :=
      natBitLength_mono (Nat.le_mul_of_pos_left nodeStride (by clear * -; omega))
    clear * - h1 h2 hW_node; omega
  obtain ⟨hh_lt, hq_bnd⟩ := hcoords.hS h hh
  let pNum : ℕ → ℤ := fun c => if hc : c < d then (qMap h ⟨c, hc⟩).num else 0
  let pDen : ℕ → ℤ := fun c => if hc : c < d then ((qMap h ⟨c, hc⟩).den : ℤ) else 1
  let oNum : ℕ → ℤ := fun c => if c < d then ws.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c))) else 0
  let oDen : ℕ → ℤ := fun c => if c < d then ws.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1))) else 1
  let sqNum := fun i => (pNum i * oDen i - oNum i * pDen i) * (pNum i * oDen i - oNum i * pDen i)
  let sqDen := fun i => (pDen i * oDen i) * (pDen i * oDen i)
  have hp1 := RegExec.lit (inp := inp) hfd_le hbnd hcCeil hbCeil (dst := 3) (c := 0) (by decide) hl0
  set g1 := Function.update regs 3 0; have bg1 : RegBounded W g1 := hbnd.update (r := 3) (by decide) hl0
  have hp2 := RegExec.lit (inp := inp) hfd_le bg1 hcCeil hbCeil (dst := 4) (c := 1) (by decide) hl1
  set g2 := Function.update g1 4 1; have bg2 : RegBounded W g2 := bg1.update (r := 4) (by decide) hl1
  have hp3 := RegExec.lit (inp := inp) hfd_le bg2 hcCeil hbCeil (dst := 6) (c := 0) (by decide) hl0
  set g3 := Function.update g2 6 0; have bg3 : RegBounded W g3 := bg2.update (r := 6) (by decide) hl0
  have hp4 := RegExec.lit (inp := inp) hfd_le bg3 hcCeil hbCeil (dst := 7) (c := (d : ℤ)) (by decide) hd_bl
  set g4 := Function.update g3 7 (d : ℤ); have bg4 : RegBounded W g4 := bg3.update (r := 7) (by decide) hd_bl
  let StepInv (c : ℕ) (g : ℕ → ℤ) : Prop :=
    RegBounded W g ∧
    g 0 = (j : ℤ) ∧ g 1 = (h : ℤ) ∧ g 5 = regs 5 ∧ g 7 = (d : ℤ) ∧
    (c ≤ d →
      g 6 = (c : ℤ) ∧
      g 3 = (ratSumPairs sqNum sqDen c).1 ∧
      g 4 = (ratSumPairs sqNum sqDen c).2 ∧
      intBitLength (g 3) ≤ c * (2 * ((B + 2) + B_cert) + 3) + 2 ∧
      intBitLength (g 4) ≤ c * (2 * ((B + 2) + B_cert) + 2) + 2)
  have hInv0 : StepInv 0 g4 := by
    refine ⟨bg4, by simp [g4, g3, g2, g1, hr0], by simp [g4, g3, g2, g1, hr1],
      by simp [g4, g3, g2, g1], by simp [g4], fun _ => ?_⟩
    have hl0_eq : intBitLength (0 : ℤ) = 1 := by decide
    have hl1_eq : intBitLength (1 : ℤ) = 2 := by decide
    exact ⟨by simp [g4, g3], by simp [g4, g3, g2, g1, ratSumPairs], by simp [g4, g3, g2, ratSumPairs],
      by simp [g4, g3, g2, g1, hl0_eq], by simp [g4, g3, g2, hl1_eq]⟩
  have hStep : ∀ c < d, ∀ g, StepInv c g →
      ∃ g', RegExec inp fd W C_cell C_bit (sqRadCoordStepStmt nodeStride) ws g ws g' 220 (52 * W * W) ∧
        StepInv (c + 1) g' := by
    intro c hc g ⟨bg, hg0, hg1, hg5, hg7, hcd⟩
    obtain ⟨hg6, hg3_eq, hg4_eq, hg3_bl, hg4_bl⟩ := hcd (Nat.le_of_lt hc)
    obtain ⟨_, ha10_bl⟩ := coordCellAddr_bl hh_lt hc (f := 0) (by decide) hW_addr
    obtain ⟨_, ha11_bl⟩ := coordCellAddr_bl hh_lt hc (f := 1) (by decide) hW_addr
    obtain ⟨_, hno0_bl⟩ := nodeCellAddr_bl hj (off := 6 + 2 * c) (by clear * - hc hstride; omega) hW_node
    obtain ⟨_, hno1_bl⟩ := nodeCellAddr_bl hj (off := 6 + 2 * c + 1) (by clear * - hc hstride; omega) hW_node
    have hm1_bl : intBitLength ((h * d : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (h * d + c) * 2 + 0) (by clear * -; omega)).trans ha10_bl
    have had1_bl : intBitLength ((h * d + c : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (h * d + c) * 2 + 0) (by clear * -; omega)).trans ha10_bl
    have hjs_bl : intBitLength ((j * nodeStride : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := j * nodeStride + (6 + 2 * c)) (by clear * -; omega)).trans hno0_bl
    have hjs6_bl : intBitLength ((j * nodeStride + 6 : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := j * nodeStride + (6 + 2 * c)) (by clear * -; omega)).trans hno0_bl
    have hjsc_bl : intBitLength ((j * nodeStride + 6 + c : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := j * nodeStride + (6 + 2 * c)) (by clear * -; omega)).trans hno0_bl
    have hc1_bl : intBitLength ((c + 1 : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := d) (by clear * - hc; omega)).trans hd_bl
    obtain ⟨hpN_bl, hpD_bl, _, _⟩ := ratBitLength_le_of_bounded (hq_bnd ⟨c, hc⟩)
    have ho_spec := hnode.read_o ⟨c, hc⟩
    dsimp only at ho_spec
    obtain ⟨_, _, hoN_bl, hoD_bl⟩ := ho_spec
    have hr_pN : ws.read (.heap 1 (coordCellAddr d h c 0)) = pNum c := by
      simp only [pNum, dif_pos hc]; exact hcoords.read_num h hh ⟨c, hc⟩
    have hr_pD : ws.read (.heap 1 (coordCellAddr d h c 1)) = pDen c := by
      simp only [pDen, dif_pos hc]; exact hcoords.read_den h hh ⟨c, hc⟩
    have hr_oN : ws.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c))) = oNum c := by
      simp only [oNum, if_pos hc]
    have hr_oD : ws.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1))) = oDen c := by
      simp only [oDen, if_pos hc]
    have hpN_c : intBitLength (pNum c) ≤ B + 2 := by simp only [pNum, dif_pos hc]; exact hpN_bl.trans (Nat.le_succ _)
    have hpD_c : intBitLength (pDen c) ≤ B + 2 := by simp only [pDen, dif_pos hc]; exact hpD_bl.trans (Nat.le_succ _)
    have hoN_c : intBitLength (oNum c) ≤ B_cert := by simp only [oNum, if_pos hc]; exact hoN_bl
    have hoD_c : intBitLength (oDen c) ≤ B_cert := by simp only [oDen, if_pos hc]; exact hoD_bl
    have hm_base_W : 1 * (2 * B + 2 * B_cert + 8) ≤ (2 * d + 2) * (2 * B + 2 * B_cert + 8) :=
      Nat.mul_le_mul_right _ (by clear * -; omega)
    have hp_W : B + 2 ≤ W := by clear * - hm_base_W hW; omega
    have ho_W : B_cert ≤ W := by clear * - hm_base_W hW; omega
    -- 1..7: Load `(pNum c, pDen c)` into `(r9, r10)`
    have m8_1 : g 1 * g 7 = ((h * d : ℕ) : ℤ) := by rw [hg1, hg7]; push_cast; ring
    have t1 := RegExec.mul (inp := inp) hfd_le bg hcCeil hbCeil (dst := 8) (a := 1) (b := 7) (by decide) (by decide) (by decide) (by rw [m8_1]; exact hm1_bl)
    rw [m8_1] at t1; set u1 := Function.update g 8 ((h * d : ℕ) : ℤ); have bu1 : RegBounded W u1 := bg.update (r := 8) (by decide) hm1_bl
    have a8_1 : u1 8 + u1 6 = ((h * d + c : ℕ) : ℤ) := by simp [u1, hg6]
    have t2 := RegExec.add (inp := inp) hfd_le bu1 hcCeil hbCeil (dst := 8) (a := 8) (b := 6) (by decide) (by decide) (by decide) (by rw [a8_1]; exact had1_bl)
    rw [a8_1] at t2; set u2 := Function.update u1 8 ((h * d + c : ℕ) : ℤ); have bu2 : RegBounded W u2 := bu1.update (r := 8) (by decide) had1_bl
    have a8_2 : u2 8 + u2 8 = coordCellAddr d h c 0 := by simp only [u2, Function.update_self, coordCellAddr]; push_cast; ring
    have t3 := RegExec.add (inp := inp) hfd_le bu2 hcCeil hbCeil (dst := 8) (a := 8) (b := 8) (by decide) (by decide) (by decide) (by rw [a8_2]; exact ha10_bl)
    rw [a8_2] at t3; set u3 := Function.update u2 8 (coordCellAddr d h c 0); have bu3 : RegBounded W u3 := bu2.update (r := 8) (by decide) ha10_bl
    have hu3_8 : ws.read (.heap 1 (u3 8)) = pNum c := by simp [u3, hr_pN]
    have t4 := RegExec.load (inp := inp) hfd_le bu3 hcCeil hbCeil (dst := 9) (table := 1) (addr := 8) (by decide) (by decide) hn1 (by rw [hu3_8]; exact hpN_c.trans hp_W)
    rw [hu3_8] at t4; set u4 := Function.update u3 9 (pNum c); have bu4 : RegBounded W u4 := bu3.update (r := 9) (by decide) (hpN_c.trans hp_W)
    have t5 := RegExec.lit (inp := inp) hfd_le bu4 hcCeil hbCeil (dst := 15) (c := 1) (by decide) hl1
    set u5 := Function.update u4 15 1; have bu5 : RegBounded W u5 := bu4.update (r := 15) (by decide) hl1
    have a8_3 : u5 8 + u5 15 = coordCellAddr d h c 1 := by
      simp only [u5, u4, u3, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), Function.update_of_ne (by decide : (8 : ℕ) ≠ 9), coordCellAddr]
      push_cast; ring
    have t6 := RegExec.add (inp := inp) hfd_le bu5 hcCeil hbCeil (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a8_3]; exact ha11_bl)
    rw [a8_3] at t6; set u6 := Function.update u5 8 (coordCellAddr d h c 1); have bu6 : RegBounded W u6 := bu5.update (r := 8) (by decide) ha11_bl
    have hu6_8 : ws.read (.heap 1 (u6 8)) = pDen c := by simp [u6, hr_pD]
    have t7 := RegExec.load (inp := inp) hfd_le bu6 hcCeil hbCeil (dst := 10) (table := 1) (addr := 8) (by decide) (by decide) hn1 (by rw [hu6_8]; exact hpD_c.trans hp_W)
    rw [hu6_8] at t7; set u7 := Function.update u6 10 (pDen c); have bu7 : RegBounded W u7 := bu6.update (r := 10) (by decide) (hpD_c.trans hp_W)
    -- 8..17: Load `(oNum c, oDen c)` into `(r11, r12)` from `heap 3`
    have t8 := RegExec.lit (inp := inp) hfd_le bu7 hcCeil hbCeil (dst := 8) (c := (nodeStride : ℤ)) (by decide) hstride_bl
    set u8 := Function.update u7 8 (nodeStride : ℤ); have bu8 : RegBounded W u8 := bu7.update (r := 8) (by decide) hstride_bl
    have m8_2 : u8 0 * u8 8 = ((j * nodeStride : ℕ) : ℤ) := by
      simp only [u8, u7, u6, u5, u4, u3, u2, u1, Function.update_self,
        Function.update_of_ne (by decide : (0 : ℕ) ≠ 8), Function.update_of_ne (by decide : (0 : ℕ) ≠ 10),
        Function.update_of_ne (by decide : (0 : ℕ) ≠ 15), Function.update_of_ne (by decide : (0 : ℕ) ≠ 9), hg0]
      push_cast; ring
    have t9 := RegExec.mul (inp := inp) hfd_le bu8 hcCeil hbCeil (dst := 8) (a := 0) (b := 8) (by decide) (by decide) (by decide) (by rw [m8_2]; exact hjs_bl)
    rw [m8_2] at t9; set u9 := Function.update u8 8 ((j * nodeStride : ℕ) : ℤ); have bu9 : RegBounded W u9 := bu8.update (r := 8) (by decide) hjs_bl
    have t10 := RegExec.lit (inp := inp) hfd_le bu9 hcCeil hbCeil (dst := 15) (c := 6) (by decide) hl6
    set u10 := Function.update u9 15 6; have bu10 : RegBounded W u10 := bu9.update (r := 15) (by decide) hl6
    have a8_4 : u10 8 + u10 15 = ((j * nodeStride + 6 : ℕ) : ℤ) := by
      simp only [u10, u9, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15)]; push_cast; ring
    have t11 := RegExec.add (inp := inp) hfd_le bu10 hcCeil hbCeil (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a8_4]; exact hjs6_bl)
    rw [a8_4] at t11; set u11 := Function.update u10 8 ((j * nodeStride + 6 : ℕ) : ℤ); have bu11 : RegBounded W u11 := bu10.update (r := 8) (by decide) hjs6_bl
    have hu11_6 : u11 6 = (c : ℤ) := by simp [u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg6]
    have a8_5 : u11 8 + u11 6 = ((j * nodeStride + 6 + c : ℕ) : ℤ) := by
      simp only [u11, Function.update_self, hu11_6]; push_cast; ring
    have t12 := RegExec.add (inp := inp) hfd_le bu11 hcCeil hbCeil (dst := 8) (a := 8) (b := 6) (by decide) (by decide) (by decide) (by rw [a8_5]; exact hjsc_bl)
    rw [a8_5] at t12; set u12 := Function.update u11 8 ((j * nodeStride + 6 + c : ℕ) : ℤ); have bu12 : RegBounded W u12 := bu11.update (r := 8) (by decide) hjsc_bl
    have a8_6 : u12 8 + u12 6 = nodeCellAddr nodeStride j (6 + 2 * c) := by
      simp only [u12, Function.update_self, Function.update_of_ne (by decide : (6 : ℕ) ≠ 8), hu11_6, nodeCellAddr]
      push_cast; ring
    have t13 := RegExec.add (inp := inp) hfd_le bu12 hcCeil hbCeil (dst := 8) (a := 8) (b := 6) (by decide) (by decide) (by decide) (by rw [a8_6]; exact hno0_bl)
    rw [a8_6] at t13; set u13 := Function.update u12 8 (nodeCellAddr nodeStride j (6 + 2 * c)); have bu13 : RegBounded W u13 := bu12.update (r := 8) (by decide) hno0_bl
    have hu13_8 : ws.read (.heap 3 (u13 8)) = oNum c := by simp [u13, hr_oN]
    have t14 := RegExec.load (inp := inp) hfd_le bu13 hcCeil hbCeil (dst := 11) (table := 3) (addr := 8) (by decide) (by decide) hn3 (by rw [hu13_8]; exact hoN_c.trans ho_W)
    rw [hu13_8] at t14; set u14 := Function.update u13 11 (oNum c); have bu14 : RegBounded W u14 := bu13.update (r := 11) (by decide) (hoN_c.trans ho_W)
    have t15 := RegExec.lit (inp := inp) hfd_le bu14 hcCeil hbCeil (dst := 15) (c := 1) (by decide) hl1
    set u15 := Function.update u14 15 1; have bu15 : RegBounded W u15 := bu14.update (r := 15) (by decide) hl1
    have a8_7 : u15 8 + u15 15 = nodeCellAddr nodeStride j (6 + 2 * c + 1) := by
      simp only [u15, u14, u13, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), Function.update_of_ne (by decide : (8 : ℕ) ≠ 11), nodeCellAddr]
      push_cast; ring
    have t16 := RegExec.add (inp := inp) hfd_le bu15 hcCeil hbCeil (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a8_7]; exact hno1_bl)
    rw [a8_7] at t16; set u16 := Function.update u15 8 (nodeCellAddr nodeStride j (6 + 2 * c + 1)); have bu16 : RegBounded W u16 := bu15.update (r := 8) (by decide) hno1_bl
    have hu16_8 : ws.read (.heap 3 (u16 8)) = oDen c := by simp [u16, hr_oD]
    have t17 := RegExec.load (inp := inp) hfd_le bu16 hcCeil hbCeil (dst := 12) (table := 3) (addr := 8) (by decide) (by decide) hn3 (by rw [hu16_8]; exact hoD_c.trans ho_W)
    rw [hu16_8] at t17; set u17 := Function.update u16 12 (oDen c); have bu17 : RegBounded W u17 := bu16.update (r := 12) (by decide) (hoD_c.trans ho_W)
    -- 18: `accumSqDiffRegs`
    have hW_acc : d * (2 * ((B + 2) + B_cert) + 3) + 20 ≤ W := by
      have hm1 : d * (2 * ((B + 2) + B_cert) + 3) ≤ d * (2 * B + 2 * B_cert + 8) :=
        Nat.mul_le_mul_left d (by clear * -; omega)
      have hm2 : d * (2 * B + 2 * B_cert + 8) ≤ (2 * d + 2) * (2 * B + 2 * B_cert + 8) :=
        Nat.mul_le_mul_right _ (by clear * -; omega)
      clear * - hm1 hm2 hW; omega
    have hu17_3 : u17 3 = g 3 := by simp [u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1]
    have hu17_4 : u17 4 = g 4 := by simp [u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1]
    obtain ⟨u18, t18, bu18, hu18_3, hu18_4, hb18_3, hb18_4, hpres18⟩ :=
      exec_accumSqDiffRegs (inp := inp) (fd := fd) hfd_le hcCeil hbCeil
        (pNum := pNum) (pDen := pDen) (qNum := oNum) (qDen := oDen)
        (B_p := B + 2) (B_q := B_cert) (c := c)
        (by clear * -; omega) hBc1 hc hW_acc
        hpN_c hpD_c hoN_c hoD_c bu17
        (by simp [u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4])
        (by simp [u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7])
        (by simp [u17, u16, u15, u14])
        (by simp [u17])
        (hu17_3.trans hg3_eq) (hu17_4.trans hg4_eq)
        (by rw [hu17_3]; exact hg3_bl) (by rw [hu17_4]; exact hg4_bl)
    -- 19..20: Increment `r6`
    have t19 := RegExec.lit (inp := inp) hfd_le bu18 hcCeil hbCeil (dst := 15) (c := 1) (by decide) hl1
    set u19 := Function.update u18 15 1; have bu19 : RegBounded W u19 := bu18.update (r := 15) (by decide) hl1
    have hu18_6 : u18 6 = (c : ℤ) := by
      rw [hpres18 6 (by decide) (by decide) (by decide)]
      simp [u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg6]
    have a6 : u19 6 + u19 15 = ((c + 1 : ℕ) : ℤ) := by
      simp only [u19, Function.update_self, Function.update_of_ne (by decide : (6 : ℕ) ≠ 15), hu18_6]
      push_cast; ring
    have t20 := RegExec.add (inp := inp) hfd_le bu19 hcCeil hbCeil (dst := 6) (a := 6) (b := 15)
      (by decide) (by decide) (by decide) (by rw [a6]; exact hc1_bl)
    rw [a6] at t20; set u20 := Function.update u19 6 ((c + 1 : ℕ) : ℤ); have bu20 : RegBounded W u20 := bu19.update (r := 6) (by decide) hc1_bl
    have sAll := (t1.seq (t2.seq (t3.seq (t4.seq (t5.seq (t6.seq (t7.seq (t8.seq (t9.seq (t10.seq
      (t11.seq (t12.seq (t13.seq (t14.seq (t15.seq (t16.seq (t17.seq (t18.seq (t19.seq t20))))))))))))))))))).weaken
      rfl rfl (u₂ := 220) (b₂ := 52 * W * W) (by clear * -; omega)
      (by calc _ = 44 * (W * W) + (82 * W + 432) := by ring
            _ ≤ 44 * (W * W) + 8 * (W * W) := Nat.add_le_add_left (by linarith only [hW20, hWW]) _
            _ = 52 * W * W := by ring)
    refine ⟨u20, sAll, bu20, ?_, ?_, ?_, ?_, ?_⟩
    · simp only [u20, u19, Function.update_of_ne (by decide : (0 : ℕ) ≠ 6), Function.update_of_ne (by decide : (0 : ℕ) ≠ 15)]
      rw [hpres18 0 (by decide) (by decide) (by decide)]
      simp [u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg0]
    · simp only [u20, u19, Function.update_of_ne (by decide : (1 : ℕ) ≠ 6), Function.update_of_ne (by decide : (1 : ℕ) ≠ 15)]
      rw [hpres18 1 (by decide) (by decide) (by decide)]
      simp [u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg1]
    · simp only [u20, u19, Function.update_of_ne (by decide : (5 : ℕ) ≠ 6), Function.update_of_ne (by decide : (5 : ℕ) ≠ 15)]
      rw [hpres18 5 (by decide) (by decide) (by decide)]
      simp [u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg5]
    · simp only [u20, u19, Function.update_of_ne (by decide : (7 : ℕ) ≠ 6), Function.update_of_ne (by decide : (7 : ℕ) ≠ 15)]
      rw [hpres18 7 (by decide) (by decide) (by decide)]
      simp [u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg7]
    · intro _
      have hu20_3 : u20 3 = u18 3 := by simp [u20, u19]
      have hu20_4 : u20 4 = u18 4 := by simp [u20, u19]
      exact ⟨by simp [u20], hu20_3.trans hu18_3, hu20_4.trans hu18_4,
        by rw [hu20_3]; exact hb18_3, by rw [hu20_4]; exact hb18_4⟩
  classical
  let seqP : ∀ n : ℕ, { g : ℕ → ℤ // StepInv n g } :=
    Nat.rec ⟨g4, hInv0⟩ (fun c prev =>
      if hc : c < d then
        let hEx := hStep c hc prev.1 prev.2
        ⟨Classical.choose hEx, (Classical.choose_spec hEx).2⟩
      else
        ⟨prev.1, ⟨prev.2.1, prev.2.2.1, prev.2.2.2.1, prev.2.2.2.2.1, prev.2.2.2.2.2.1,
          fun hle => absurd (by clear * - hc hle; omega : c < d) hc⟩⟩)
  have hRep := RegExec.repeatLit (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    d hd_bl (fun _ => ws) (fun i => (seqP i).1) bg4
    (body := sqRadCoordStepStmt nodeStride) (U := 220) (B := 52 * W * W)
    (fun i hi => by
      dsimp only [seqP]
      rw [dif_pos hi]
      exact (Classical.choose_spec (hStep i hi (seqP i).1 (seqP i).2)).1)
  let gL := (seqP d).1
  have hEndP : StepInv d gL := (seqP d).2
  obtain ⟨bgL, hgL0, hgL1, hgL5, _, hdL⟩ := hEndP
  obtain ⟨_, hgL3, hgL4, hbL3, hbL4⟩ := hdL le_rfl
  -- Post-loop: load `V_num, V_den`, cross-multiply, and compare!
  obtain ⟨_, hn3_bl⟩ := nodeCellAddr_bl hj (off := 3) (by clear * - hstride; omega) hW_node
  obtain ⟨_, hn4_bl⟩ := nodeCellAddr_bl hj (off := 4) (by clear * - hstride; omega) hW_node
  have hjs_bl0 : intBitLength ((j * nodeStride : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := j * nodeStride + 3) (by clear * -; omega)).trans hn3_bl
  have hVN_le : (d + 1) * (2 * B_cert + 7) ≤ (d + 1) * (2 * B + 2 * B_cert + 8) :=
    Nat.mul_le_mul_left (d + 1) (by clear * -; omega)
  have hd_sum3_le : d * (2 * ((B + 2) + B_cert) + 3) ≤ d * (2 * B + 2 * B_cert + 8) :=
    Nat.mul_le_mul_left d (by clear * -; omega)
  have hd_sum2_le : d * (2 * ((B + 2) + B_cert) + 2) ≤ d * (2 * B + 2 * B_cert + 8) :=
    Nat.mul_le_mul_left d (by clear * -; omega)
  have hcomb_W : (d + 1) * (2 * B + 2 * B_cert + 8) + d * (2 * B + 2 * B_cert + 8) + 8 ≤ W := by
    have heq : (d + 1) * (2 * B + 2 * B_cert + 8) + d * (2 * B + 2 * B_cert + 8) =
        (2 * d + 1) * (2 * B + 2 * B_cert + 8) := by ring
    have hm : (2 * d + 1) * (2 * B + 2 * B_cert + 8) ≤ (2 * d + 2) * (2 * B + 2 * B_cert + 8) :=
      Nat.mul_le_mul_right _ (by clear * -; omega)
    rw [heq]; clear * - hm hW; omega
  have hVN_W : intBitLength V_num ≤ W := hnode.hVN_bl.trans (by clear * - hVN_le hcomb_W; omega)
  have hVD_W : intBitLength V_den ≤ W := hnode.hVD_bl.trans (by clear * - hVN_le hcomb_W; omega)
  have hmul_13_W : intBitLength (gL 3 * V_den) ≤ W := by
    have hm := (intBitLength_mul_le (gL 3) V_den).trans (Nat.add_le_add hbL3 hnode.hVD_bl)
    exact hm.trans (by clear * - hVN_le hd_sum3_le hcomb_W; omega)
  have hmul_14_W : intBitLength (V_num * gL 4) ≤ W := by
    have hm := (intBitLength_mul_le V_num (gL 4)).trans (Nat.add_le_add hnode.hVN_bl hbL4)
    exact hm.trans (by clear * - hVN_le hd_sum2_le hcomb_W; omega)
  have q1 := RegExec.lit (inp := inp) hfd_le bgL hcCeil hbCeil (dst := 8) (c := (nodeStride : ℤ)) (by decide) hstride_bl
  set z1 := Function.update gL 8 (nodeStride : ℤ); have bz1 : RegBounded W z1 := bgL.update (r := 8) (by decide) hstride_bl
  have mz2 : z1 0 * z1 8 = ((j * nodeStride : ℕ) : ℤ) := by
    simp only [z1, Function.update_self, Function.update_of_ne (by decide : (0 : ℕ) ≠ 8), hgL0]; push_cast; ring
  have q2 := RegExec.mul (inp := inp) hfd_le bz1 hcCeil hbCeil (dst := 8) (a := 0) (b := 8) (by decide) (by decide) (by decide) (by rw [mz2]; exact hjs_bl0)
  rw [mz2] at q2; set z2 := Function.update z1 8 ((j * nodeStride : ℕ) : ℤ); have bz2 : RegBounded W z2 := bz1.update (r := 8) (by decide) hjs_bl0
  have q3 := RegExec.lit (inp := inp) hfd_le bz2 hcCeil hbCeil (dst := 15) (c := 3) (by decide) hl3
  set z3 := Function.update z2 15 3; have bz3 : RegBounded W z3 := bz2.update (r := 15) (by decide) hl3
  have az4 : z3 8 + z3 15 = nodeCellAddr nodeStride j 3 := by
    simp only [z3, z2, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), nodeCellAddr]; push_cast; ring
  have q4 := RegExec.add (inp := inp) hfd_le bz3 hcCeil hbCeil (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [az4]; exact hn3_bl)
  rw [az4] at q4; set z4 := Function.update z3 8 (nodeCellAddr nodeStride j 3); have bz4 : RegBounded W z4 := bz3.update (r := 8) (by decide) hn3_bl
  have hz4_8 : ws.read (.heap 3 (z4 8)) = V_num := by simp [z4, hnode.read_VN]
  have q5 := RegExec.load (inp := inp) hfd_le bz4 hcCeil hbCeil (dst := 11) (table := 3) (addr := 8) (by decide) (by decide) hn3 (by rw [hz4_8]; exact hVN_W)
  rw [hz4_8] at q5; set z5 := Function.update z4 11 V_num; have bz5 : RegBounded W z5 := bz4.update (r := 11) (by decide) hVN_W
  have q6 := RegExec.lit (inp := inp) hfd_le bz5 hcCeil hbCeil (dst := 15) (c := 1) (by decide) hl1
  set z6 := Function.update z5 15 1; have bz6 : RegBounded W z6 := bz5.update (r := 15) (by decide) hl1
  have az7 : z6 8 + z6 15 = nodeCellAddr nodeStride j 4 := by
    simp only [z6, z5, z4, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), Function.update_of_ne (by decide : (8 : ℕ) ≠ 11), nodeCellAddr]
    push_cast; ring
  have q7 := RegExec.add (inp := inp) hfd_le bz6 hcCeil hbCeil (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [az7]; exact hn4_bl)
  rw [az7] at q7; set z7 := Function.update z6 8 (nodeCellAddr nodeStride j 4); have bz7 : RegBounded W z7 := bz6.update (r := 8) (by decide) hn4_bl
  have hz7_8 : ws.read (.heap 3 (z7 8)) = V_den := by simp [z7, hnode.read_VD]
  have q8 := RegExec.load (inp := inp) hfd_le bz7 hcCeil hbCeil (dst := 12) (table := 3) (addr := 8) (by decide) (by decide) hn3 (by rw [hz7_8]; exact hVD_W)
  rw [hz7_8] at q8; set z8 := Function.update z7 12 V_den; have bz8 : RegBounded W z8 := bz7.update (r := 12) (by decide) hVD_W
  have mz9 : z8 3 * z8 12 = gL 3 * V_den := by simp [z8, z7, z6, z5, z4, z3, z2, z1]
  have q9 := RegExec.mul (inp := inp) hfd_le bz8 hcCeil hbCeil (dst := 13) (a := 3) (b := 12) (by decide) (by decide) (by decide) (by rw [mz9]; exact hmul_13_W)
  rw [mz9] at q9; set z9 := Function.update z8 13 (gL 3 * V_den); have bz9 : RegBounded W z9 := bz8.update (r := 13) (by decide) hmul_13_W
  have mz10 : z9 11 * z9 4 = V_num * gL 4 := by simp [z9, z8, z7, z6, z5, z4, z3, z2, z1]
  have q10 := RegExec.mul (inp := inp) hfd_le bz9 hcCeil hbCeil (dst := 14) (a := 11) (b := 4) (by decide) (by decide) (by decide) (by rw [mz10]; exact hmul_14_W)
  rw [mz10] at q10; set z10 := Function.update z9 14 (V_num * gL 4); have bz10 : RegBounded W z10 := bz9.update (r := 14) (by decide) hmul_14_W
  set outFlag : ℤ := if gL 3 * V_den ≤ V_num * gL 4 then 0 else 1
  set zEnd := Function.update z10 2 outFlag
  have bzEnd : RegBounded W zEnd := bz10.update (r := 2) (by decide) (by dsimp [outFlag]; split_ifs <;> assumption)
  have q11 : RegExec inp fd W C_cell C_bit
      (.ite (.intLe (.readLocal 13 (.lit 0)) (.readLocal 14 (.lit 0))) (rLit 2 0) (rLit 2 1))
      ws z10 ws zEnd 10 (6 * W + 32) := by
    refine (RegExec.iteLe (U := 4) (B := 2 * W + 16) bz10 (a := 13) (b := 14) (by decide) (by decide) ?_).weaken
      rfl rfl le_rfl (le_of_eq (by ring))
    have hz13 : z10 13 = gL 3 * V_den := by simp [z10, z9]
    have hz14 : z10 14 = V_num * gL 4 := by simp [z10]
    rw [hz13, hz14]
    by_cases hle : gL 3 * V_den ≤ V_num * gL 4
    · rw [if_pos hle]
      have : zEnd = Function.update z10 2 0 := by simp [zEnd, outFlag, hle]
      rw [this]
      exact RegExec.lit (inp := inp) hfd_le bz10 hcCeil hbCeil (dst := 2) (c := 0) (by decide) hl0
    · rw [if_neg hle]
      have : zEnd = Function.update z10 2 1 := by simp [zEnd, outFlag, hle]
      rw [this]
      exact RegExec.lit (inp := inp) hfd_le bz10 hcCeil hbCeil (dst := 2) (c := 1) (by decide) hl1
  -- Total cost bound
  have hb_tot : 2 * W + 16 + (2 * W + 16 + (2 * W + 16 + (2 * W + 16 + (d * (52 * W * W) + W +
      (2 * W + 16 + (4 * W * W + (2 * W + 16 + (6 * W + 32 + (6 * W + 24 + (2 * W + 16 +
      (6 * W + 32 + (6 * W + 24 + (4 * W * W + (4 * W * W + (6 * W + 32))))))))))))))) ≤
      (56 * d + 32) * W * W := by
    calc _
      _ = 52 * d * (W * W) + (12 * (W * W) + 45 * W + 256) := by ring
      _ ≤ 52 * d * (W * W) + 32 * (W * W) := Nat.add_le_add_left (by linarith only [hW20, hWW]) _
      _ = (52 * d + 32) * W * W := by ring
      _ ≤ (56 * d + 32) * W * W := Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by clear * -; omega))
  have sTot := (hp1.seq (hp2.seq (hp3.seq (hp4.seq (hRep.seq (q1.seq (q2.seq (q3.seq (q4.seq (q5.seq
    (q6.seq (q7.seq (q8.seq (q9.seq (q10.seq q11))))))))))))))).weaken rfl rfl
    (u₂ := 240 * d + 120) (b₂ := (56 * d + 32) * W * W) (by clear * -; omega) hb_tot
  -- Establish `ratSumPairs` positivity, distance identity, and `coreBall` equivalence!
  have hBt : 1 ≤ 2 * ((B + 2) + B_cert) + 2 := by clear * -; omega
  have hbnds_term : ∀ i < d,
      1 ≤ sqDen i ∧ intBitLength (sqNum i) ≤ 2 * ((B + 2) + B_cert) + 2 ∧
      intBitLength (sqDen i) ≤ 2 * ((B + 2) + B_cert) + 2 := by
    intro i hi
    obtain ⟨bpN, bpD, hpD1, _⟩ := ratBitLength_le_of_bounded (hq_bnd ⟨i, hi⟩)
    have ho_i := hnode.read_o ⟨i, hi⟩; dsimp only at ho_i
    obtain ⟨hoD1, _, boN, boD⟩ := ho_i
    have hpDi : 1 ≤ pDen i := by simp only [pDen, dif_pos hi]; exact_mod_cast hpD1
    have hoDi : 1 ≤ oDen i := by simp only [oDen, if_pos hi]; exact hoD1
    have h12 : 1 ≤ pDen i * oDen i := by nlinarith only [hpDi, hoDi]
    have h1 : 1 ≤ sqDen i := by dsimp [sqDen]; nlinarith only [h12]
    have bpNi : intBitLength (pNum i) ≤ B + 2 := by simp only [pNum, dif_pos hi]; exact bpN.trans (Nat.le_succ _)
    have bpDi : intBitLength (pDen i) ≤ B + 2 := by simp only [pDen, dif_pos hi]; exact bpD.trans (Nat.le_succ _)
    have boNi : intBitLength (oNum i) ≤ B_cert := by simp only [oNum, if_pos hi]; exact boN
    have boDi : intBitLength (oDen i) ≤ B_cert := by simp only [oDen, if_pos hi]; exact boD
    have bm1 : intBitLength (pNum i * oDen i) ≤ (B + 2) + B_cert :=
      (intBitLength_mul_le _ _).trans (Nat.add_le_add bpNi boDi)
    have bm2 : intBitLength (oNum i * pDen i) ≤ (B + 2) + B_cert := by
      have := (intBitLength_mul_le (oNum i) (pDen i)).trans (Nat.add_le_add boNi bpDi)
      clear * - this; omega
    have bdf : intBitLength (pNum i * oDen i - oNum i * pDen i) ≤ (B + 2) + B_cert + 1 := by
      have hs := intBitLength_sub_le_max (pNum i * oDen i) (oNum i * pDen i)
      have hm := max_le bm1 bm2
      clear * - hs hm; omega
    have bsN : intBitLength (sqNum i) ≤ 2 * ((B + 2) + B_cert) + 2 := by
      have := (intBitLength_mul_le _ _).trans (Nat.add_le_add bdf bdf)
      dsimp [sqNum]; clear * - this; omega
    have bpd : intBitLength (pDen i * oDen i) ≤ (B + 2) + B_cert :=
      (intBitLength_mul_le _ _).trans (Nat.add_le_add bpDi boDi)
    have bsD : intBitLength (sqDen i) ≤ 2 * ((B + 2) + B_cert) + 2 := by
      have := (intBitLength_mul_le _ _).trans (Nat.add_le_add bpd bpd)
      dsimp [sqDen]; clear * - this; omega
    exact ⟨h1, bsN, bsD⟩
  obtain ⟨hden_pos, _, _, _, hnn_num⟩ := ratSumPairs_spec hBt d hbnds_term
  have hnn : 0 ≤ (ratSumPairs sqNum sqDen d).1 :=
    hnn_num (fun i _ => by dsimp [sqNum]; exact mul_self_nonneg _)
  have hdist := ratPoint_distSq_eq (p := qMap h) (q := oRat)
    (pNum := pNum) (pDen := pDen) (qNum := oNum) (qDen := oDen)
    (fun c => by
      obtain ⟨_, _, hd_pos, _⟩ := ratBitLength_le_of_bounded (hq_bnd c)
      exact ⟨by simp only [pDen, dif_pos c.isLt]; exact_mod_cast hd_pos,
             by simp only [pNum, pDen, dif_pos c.isLt, Rat.cast_def, Int.cast_natCast]⟩)
    (fun c => by
      have ho_c := hnode.read_o c; dsimp only at ho_c
      exact ⟨by simp only [oDen, if_pos c.isLt]; exact ho_c.1,
             by simp only [oNum, oDen, if_pos c.isLt]; exact ho_c.2.1⟩)
  have hz3_eq : zEnd 3 = gL 3 := by simp [zEnd, z10, z9, z8, z7, z6, z5, z4, z3, z2, z1]
  have hz4_eq : zEnd 4 = gL 4 := by simp [zEnd, z10, z9, z8, z7, z6, z5, z4, z3, z2, z1]
  have hrD_1 : 1 ≤ gL 4 := by rw [hgL4]; exact hden_pos
  have hr_eq : ((gL 3 : ℝ) / (gL 4 : ℝ)) =
      ‖ratPointToEuclidean (qMap h) - ratPointToEuclidean oRat‖ ^ 2 := by
    rw [hgL3, hgL4]; exact hdist
  have hcore_iff := mem_coreBall_iff_crossMul hnode.hV_nn hrD_1 hnode.hV_den hr_eq hnode.hV_eq
  refine ⟨zEnd, sTot, bzEnd,
    by simp [zEnd, z10, z9, z8, z7, z6, z5, z4, z3, z2, z1, hgL0],
    by simp [zEnd, z10, z9, z8, z7, z6, z5, z4, z3, z2, z1, hgL1],
    by simp [zEnd, z10, z9, z8, z7, z6, z5, z4, z3, z2, z1, hgL5],
    by rw [hz4_eq]; exact hrD_1,
    by rw [hz3_eq, hgL3]; exact hnn,
    by rw [hz3_eq, hz4_eq]; exact hr_eq,
    by rw [hz3_eq]; exact hbL3,
    by rw [hz4_eq]; exact hbL4,
    ?_⟩
  simp only [zEnd, Function.update_self, outFlag]
  by_cases hm : ratPointToEuclidean (qMap h) ∈ coreBall (ratPointToEuclidean oRat) V
  · rw [if_pos hm, if_pos (hcore_iff.mp hm)]
  · rw [if_neg hm, if_neg (fun hle => hm (hcore_iff.mpr hle))]


/-! ### 3. `extractNodeCenterAndVarRegs`: Copy `(o_j, s_j)` from `heap 10` into `heap 3` and Compute `V_j` -/

def extractCenterCoordStepStmt (nodeStride T_max : ℕ) : BitRAMStmt :=
  .seq (rAdd 8 6 6)
  (.seq (rLit 15 (T_max : ℤ))
  (.seq (rMul 8 8 15)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
  (.seq (rLoad 9 10 8)
  (.seq (rLit 15 (T_max : ℤ))
  (.seq (rAdd 8 8 15)
  (.seq (rLoad 10 10 8)
  (.seq (rLit 8 (nodeStride : ℤ))
  (.seq (rMul 8 0 8)
  (.seq (rLit 15 6)
  (.seq (rAdd 8 8 15)
  (.seq (rAdd 8 8 6)
  (.seq (rAdd 8 8 6)
  (.seq (rStore 3 8 9)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
  (.seq (rStore 3 8 10)
  (.seq (rLit 11 0)
  (.seq (rLit 12 1)
  (.seq accumSqDiffRegs
  (.seq (rLit 15 1)
        (rAdd 6 6 15)))))))))))))))))))))))

def extractNodeCenterAndVarRegs (d nodeStride T_max : ℕ) : BitRAMStmt :=
  .seq (rLit 3 0)
  (.seq (rLit 4 1)
  (.seq (rLit 6 0)
  (.seq (.repeatN (.lit (d : ℤ)) (extractCenterCoordStepStmt nodeStride T_max))
  (.seq (rLit 8 (((2 * d) * T_max + 1 : ℕ) : ℤ))
  (.seq (rLoad 9 10 8)
  (.seq (rLit 8 (((2 * d + 1) * T_max + 1 : ℕ) : ℤ))
  (.seq (rLoad 10 10 8)
  (.seq (rMul 13 9 4)
  (.seq (rMul 14 3 10)
  (.seq (rSub 13 13 14)
  (.seq (rMul 14 10 4)
  (.seq (rLit 8 (nodeStride : ℤ))
  (.seq (rMul 8 0 8)
  (.seq (rLit 15 3)
  (.seq (rAdd 8 8 15)
  (.seq (rStore 3 8 13)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
        (rStore 3 8 14)))))))))))))))))))

theorem exec_extractNodeCenterAndVarRegs {d : ℕ} (_hd1 : 1 ≤ d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {B_cert nodeStride T_max K_max j : ℕ}
    (hBc1 : 1 ≤ B_cert) (hT1 : 2 ≤ T_max)
    (hj : j ≤ K_max + 1) (hstride : 6 + 2 * d ≤ nodeStride)
    (hW : (d + 1) * (2 * B_cert + 8) + natBitLength ((K_max + 2) * nodeStride) +
            natBitLength ((2 * d + 2) * T_max) + 32 ≤ W)
    {oRat : Fin d → ℚ} {sRat : ℚ}
    (hV_nn : 0 ≤ liftVariance (ratPointToEuclidean oRat) (sRat : ℝ))
    (ho10 : ∀ c : Fin d,
      let oN := ws.read (.heap 10 ((((2 * c.val) * T_max + 1 : ℕ) : ℤ)))
      let oD := ws.read (.heap 10 ((((2 * c.val + 1) * T_max + 1 : ℕ) : ℤ)))
      1 ≤ oD ∧ oRat c = (oN : ℚ) / (oD : ℚ) ∧
      intBitLength oN ≤ B_cert ∧ intBitLength oD ≤ B_cert)
    (hs10 :
      let sN := ws.read (.heap 10 ((((2 * d) * T_max + 1 : ℕ) : ℤ)))
      let sD := ws.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)))
      1 ≤ sD ∧ sRat = (sN : ℚ) / (sD : ℚ) ∧
      intBitLength sN ≤ B_cert ∧ intBitLength sD ≤ B_cert)
    (hSub3 : ∀ off < 6 + 2 * d, (.heap 3 (nodeCellAddr nodeStride j off) : RAMCellLoc) ∈ S_write)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (j : ℤ)) :
    ∃ wsEnd regsEnd V_num V_den,
      RegExec inp fd W C_cell C_bit (extractNodeCenterAndVarRegs d nodeStride T_max)
        ws regs wsEnd regsEnd (260 * d + 140) ((60 * d + 36) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      regsEnd 0 = (j : ℤ) ∧ regsEnd 5 = regs 5 ∧
      NodeGeomStored d nodeStride B_cert j oRat V_num V_den
        (liftVariance (ratPointToEuclidean oRat) (sRat : ℝ)) wsEnd ∧
      (∀ loc : RAMCellLoc,
        (∀ off : ℕ, off < 6 + 2 * d → loc ≠ .heap 3 (nodeCellAddr nodeStride j off)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hWW : 20 * W ≤ W * W := by nlinarith only [hW20]
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by clear * - hW20; omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by clear * - hW20; omega)
  have hl3 : intBitLength (3 : ℤ) ≤ W := (show intBitLength (3 : ℤ) = 3 from by decide).trans_le (by clear * - hW20; omega)
  have hl6 : intBitLength (6 : ℤ) ≤ W := (show intBitLength (6 : ℤ) = 4 from by decide).trans_le (by clear * - hW20; omega)
  have hn3 : natBitLength 3 ≤ W := (show natBitLength 3 = 2 from by decide).trans_le (by clear * - hW20; omega)
  have hn10 : natBitLength 10 ≤ W := (show natBitLength 10 = 4 from by decide).trans_le (by clear * - hW20; omega)
  have hW_node : natBitLength ((K_max + 2) * nodeStride) + 8 ≤ W := by clear * - hW; omega
  have h10_ceil_bl : intBitLength ((((2 * d + 2) * T_max : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le ((2 * d + 2) * T_max)
    clear * - h1 hW; omega
  have hd_le_ceil : d ≤ (2 * d + 2) * T_max := by
    calc d ≤ (2 * d + 2) * 1 := by clear * -; omega
      _ ≤ (2 * d + 2) * T_max := Nat.mul_le_mul_left _ (by clear * - hT1; omega)
  have hT_le_ceil : T_max ≤ (2 * d + 2) * T_max :=
    Nat.le_mul_of_pos_left T_max (by clear * -; omega)
  have hd_bl : intBitLength (d : ℤ) ≤ W :=
    (intBitLength_natCast_mono hd_le_ceil).trans h10_ceil_bl
  have hT_bl : intBitLength (T_max : ℤ) ≤ W :=
    (intBitLength_natCast_mono hT_le_ceil).trans h10_ceil_bl
  have hstride_bl : intBitLength (nodeStride : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le nodeStride
    have h2 : natBitLength nodeStride ≤ natBitLength ((K_max + 2) * nodeStride) :=
      natBitLength_mono (Nat.le_mul_of_pos_left nodeStride (by clear * -; omega))
    clear * - h1 h2 hW_node; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  let oNum : ℕ → ℤ := fun c => if c < d then ws.read (.heap 10 ((((2 * c) * T_max + 1 : ℕ) : ℤ))) else 0
  let oDen : ℕ → ℤ := fun c => if c < d then ws.read (.heap 10 ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ))) else 1
  let zNum : ℕ → ℤ := fun _ => 0
  let zDen : ℕ → ℤ := fun _ => 1
  let sqNum := fun i => (oNum i * zDen i - zNum i * oDen i) * (oNum i * zDen i - zNum i * oDen i)
  let sqDen := fun i => (oDen i * zDen i) * (oDen i * zDen i)
  have hp1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 3) (c := 0) (by decide) hl0
  set g1 := Function.update regs 3 0; have bg1 : RegBounded W g1 := hbnd.update (r := 3) (by decide) hl0
  have hp2 := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 4) (c := 1) (by decide) hl1
  set g2 := Function.update g1 4 1; have bg2 : RegBounded W g2 := bg1.update (r := 4) (by decide) hl1
  have hp3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 6) (c := 0) (by decide) hl0
  set g3 := Function.update g2 6 0; have bg3 : RegBounded W g3 := bg2.update (r := 6) (by decide) hl0
  let StepInv (c : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
    ModifiedOnBounded ws₀ S_write W w ∧
    RegBounded W g ∧
    g 0 = (j : ℤ) ∧ g 5 = regs 5 ∧
    (∀ loc : RAMCellLoc,
      (∀ off : ℕ, off < 6 + 2 * d → loc ≠ .heap 3 (nodeCellAddr nodeStride j off)) →
      (loc ∈ w.live ↔ loc ∈ ws.live) ∧ w.vals loc = ws.vals loc) ∧
    (c ≤ d →
      g 6 = (c : ℤ) ∧
      g 3 = (ratSumPairs sqNum sqDen c).1 ∧
      g 4 = (ratSumPairs sqNum sqDen c).2 ∧
      intBitLength (g 3) ≤ c * (2 * (B_cert + 2) + 3) + 2 ∧
      intBitLength (g 4) ≤ c * (2 * (B_cert + 2) + 2) + 2 ∧
      ∀ (c' : ℕ), c' < d → c' < c →
        w.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c'))) = oNum c' ∧
        w.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c' + 1))) = oDen c')
  have hInv0 : StepInv 0 ws g3 := by
    refine ⟨hmod, bg3, by simp [g3, g2, g1, hr0], by simp [g3, g2, g1],
      fun _ _ => ⟨Iff.rfl, rfl⟩, fun _ => ?_⟩
    have hl0_eq : intBitLength (0 : ℤ) = 1 := by decide
    have hl1_eq : intBitLength (1 : ℤ) = 2 := by decide
    exact ⟨by simp [g3], by simp [g3, g2, g1, ratSumPairs], by simp [g3, g2, ratSumPairs],
      by simp [g3, g2, g1, hl0_eq], by simp [g3, g2, hl1_eq],
      fun _ _ hlt => absurd hlt (Nat.not_lt_zero _)⟩
  have hStep : ∀ c < d, ∀ w g, StepInv c w g →
      ∃ w' g', RegExec inp fd W C_cell C_bit (extractCenterCoordStepStmt nodeStride T_max)
        w g w' g' 240 (56 * W * W) ∧ StepInv (c + 1) w' g' := by
    intro c hc w g ⟨hm, bg, hg0, hg5, hunch, hcd⟩
    obtain ⟨hg6, hg3_eq, hg4_eq, hg3_bl, hg4_bl, hprev⟩ := hcd (Nat.le_of_lt hc)
    obtain ⟨hno0_loc, hno0_bl⟩ := nodeCellAddr_bl hj (off := 6 + 2 * c) (by clear * - hc hstride; omega) hW_node
    obtain ⟨hno1_loc, hno1_bl⟩ := nodeCellAddr_bl hj (off := 6 + 2 * c + 1) (by clear * - hc hstride; omega) hW_node
    have h2c1_le_ceil : (2 * c + 1) * T_max + 1 ≤ (2 * d + 2) * T_max := by
      calc (2 * c + 1) * T_max + 1 ≤ (2 * c + 1) * T_max + T_max := Nat.add_le_add_left (by clear * - hT1; omega) _
        _ = (2 * c + 2) * T_max := by ring
        _ ≤ (2 * d + 2) * T_max := Nat.mul_le_mul_right T_max (by clear * - hc; omega)
    have h2c_le_2cT : 2 * c ≤ (2 * c) * T_max := by
      calc 2 * c = (2 * c) * 1 := by ring
        _ ≤ (2 * c) * T_max := Nat.mul_le_mul_left _ (by clear * - hT1; omega)
    have h2cT_le_2c1T : (2 * c) * T_max ≤ (2 * c + 1) * T_max :=
      Nat.mul_le_mul_right T_max (by clear * -; omega)
    have h2c_bl : intBitLength ((2 * c : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (h2c_le_2cT.trans (h2cT_le_2c1T.trans ((Nat.le_succ _).trans h2c1_le_ceil)))).trans h10_ceil_bl
    have h2cT_bl : intBitLength (((2 * c) * T_max : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (h2cT_le_2c1T.trans ((Nat.le_succ _).trans h2c1_le_ceil))).trans h10_ceil_bl
    have ha10_0_bl : intBitLength ((((2 * c) * T_max + 1 : ℕ) : ℤ)) ≤ W :=
      (intBitLength_natCast_mono ((Nat.add_le_add_right h2cT_le_2c1T 1).trans h2c1_le_ceil)).trans h10_ceil_bl
    have ha10_1_bl : intBitLength ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ)) ≤ W :=
      (intBitLength_natCast_mono h2c1_le_ceil).trans h10_ceil_bl
    have hjs_bl : intBitLength ((j * nodeStride : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := j * nodeStride + (6 + 2 * c)) (by clear * -; omega)).trans hno0_bl
    have hjs6_bl : intBitLength ((j * nodeStride + 6 : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := j * nodeStride + (6 + 2 * c)) (by clear * -; omega)).trans hno0_bl
    have hjsc_bl : intBitLength ((j * nodeStride + 6 + c : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := j * nodeStride + (6 + 2 * c)) (by clear * -; omega)).trans hno0_bl
    have hc1_bl : intBitLength ((c + 1 : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := d) (by clear * - hc; omega)).trans hd_bl
    have ho_c := ho10 ⟨c, hc⟩; dsimp only at ho_c
    obtain ⟨_, _, hoN_bl, hoD_bl⟩ := ho_c
    have hoN_c : intBitLength (oNum c) ≤ B_cert := by simp only [oNum, if_pos hc]; exact hoN_bl
    have hoD_c : intBitLength (oDen c) ≤ B_cert := by simp only [oDen, if_pos hc]; exact hoD_bl
    have ho_W : B_cert ≤ W := by
      have hm : 1 * (2 * B_cert + 8) ≤ (d + 1) * (2 * B_cert + 8) := Nat.mul_le_mul_right _ (by clear * -; omega)
      clear * - hm hW; omega
    -- Read `heap 10` on `w` equals `ws` via `hunch`!
    have hr10_eq : ∀ z : ℤ, w.read (.heap 10 z) = ws.read (.heap 10 z) := by
      intro z
      rw [wordStore_read_eq_vals hm.wf, (hunch (.heap 10 z) (fun _ _ h => by cases h)).2, ← wordStore_read_eq_vals hmod.wf]
    have hrw_oN : w.read (.heap 10 ((((2 * c) * T_max + 1 : ℕ) : ℤ))) = oNum c := by
      rw [hr10_eq]; simp [oNum, hc]
    have hrw_oD : w.read (.heap 10 ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ))) = oDen c := by
      rw [hr10_eq]; simp [oDen, hc]
    -- 1..9: Load `(oNum c, oDen c)` into `(r9, r10)` from `heap 10`
    have a1 : g 6 + g 6 = ((2 * c : ℕ) : ℤ) := by rw [hg6]; push_cast; ring
    have t1 := RegExec.add (inp := inp) hfd_le bg (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 6) (b := 6) (by decide) (by decide) (by decide) (by rw [a1]; exact h2c_bl)
    rw [a1] at t1; set u1 := Function.update g 8 ((2 * c : ℕ) : ℤ); have bu1 : RegBounded W u1 := bg.update (r := 8) (by decide) h2c_bl
    have t2 := RegExec.lit (inp := inp) hfd_le bu1 (sp_ok hm).1 (sp_ok hm).2 (dst := 15) (c := (T_max : ℤ)) (by decide) hT_bl
    set u2 := Function.update u1 15 (T_max : ℤ); have bu2 : RegBounded W u2 := bu1.update (r := 15) (by decide) hT_bl
    have m3 : u2 8 * u2 15 = (((2 * c) * T_max : ℕ) : ℤ) := by
      simp only [u2, u1, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15)]; push_cast; ring
    have t3 := RegExec.mul (inp := inp) hfd_le bu2 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [m3]; exact h2cT_bl)
    rw [m3] at t3; set u3 := Function.update u2 8 (((2 * c) * T_max : ℕ) : ℤ); have bu3 : RegBounded W u3 := bu2.update (r := 8) (by decide) h2cT_bl
    have t4 := RegExec.lit (inp := inp) hfd_le bu3 (sp_ok hm).1 (sp_ok hm).2 (dst := 15) (c := 1) (by decide) hl1
    set u4 := Function.update u3 15 1; have bu4 : RegBounded W u4 := bu3.update (r := 15) (by decide) hl1
    have a5 : u4 8 + u4 15 = ((((2 * c) * T_max + 1 : ℕ) : ℤ)) := by
      simp only [u4, u3, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15)]; push_cast; ring
    have t5 := RegExec.add (inp := inp) hfd_le bu4 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a5]; exact ha10_0_bl)
    rw [a5] at t5; set u5 := Function.update u4 8 ((((2 * c) * T_max + 1 : ℕ) : ℤ)); have bu5 : RegBounded W u5 := bu4.update (r := 8) (by decide) ha10_0_bl
    have hu5_8 : w.read (.heap 10 (u5 8)) = oNum c := by simp only [u5, Function.update_self]; exact hrw_oN
    have t6 := RegExec.load (inp := inp) hfd_le bu5 (sp_ok hm).1 (sp_ok hm).2 (dst := 9) (table := 10) (addr := 8) (by decide) (by decide) hn10 (by rw [hu5_8]; exact hoN_c.trans ho_W)
    rw [hu5_8] at t6; set u6 := Function.update u5 9 (oNum c); have bu6 : RegBounded W u6 := bu5.update (r := 9) (by decide) (hoN_c.trans ho_W)
    have t7 := RegExec.lit (inp := inp) hfd_le bu6 (sp_ok hm).1 (sp_ok hm).2 (dst := 15) (c := (T_max : ℤ)) (by decide) hT_bl
    set u7 := Function.update u6 15 (T_max : ℤ); have bu7 : RegBounded W u7 := bu6.update (r := 15) (by decide) hT_bl
    have a8 : u7 8 + u7 15 = ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ)) := by
      simp only [u7, u6, u5, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), Function.update_of_ne (by decide : (8 : ℕ) ≠ 9)]
      push_cast; ring
    have t8 := RegExec.add (inp := inp) hfd_le bu7 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a8]; exact ha10_1_bl)
    rw [a8] at t8; set u8 := Function.update u7 8 ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ)); have bu8 : RegBounded W u8 := bu7.update (r := 8) (by decide) ha10_1_bl
    have hu8_8 : w.read (.heap 10 (u8 8)) = oDen c := by simp only [u8, Function.update_self]; exact hrw_oD
    have t9 := RegExec.load (inp := inp) hfd_le bu8 (sp_ok hm).1 (sp_ok hm).2 (dst := 10) (table := 10) (addr := 8) (by decide) (by decide) hn10 (by rw [hu8_8]; exact hoD_c.trans ho_W)
    rw [hu8_8] at t9; set u9 := Function.update u8 10 (oDen c); have bu9 : RegBounded W u9 := bu8.update (r := 10) (by decide) (hoD_c.trans ho_W)
    -- 10..19: Store `(oNum c, oDen c)` into `heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 0/1))`
    have t10 := RegExec.lit (inp := inp) hfd_le bu9 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (c := (nodeStride : ℤ)) (by decide) hstride_bl
    set u10 := Function.update u9 8 (nodeStride : ℤ); have bu10 : RegBounded W u10 := bu9.update (r := 8) (by decide) hstride_bl
    have m11 : u10 0 * u10 8 = ((j * nodeStride : ℕ) : ℤ) := by
      simp only [u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, Function.update_self,
        Function.update_of_ne (by decide : (0 : ℕ) ≠ 8), Function.update_of_ne (by decide : (0 : ℕ) ≠ 10),
        Function.update_of_ne (by decide : (0 : ℕ) ≠ 15), Function.update_of_ne (by decide : (0 : ℕ) ≠ 9), hg0]
      push_cast; ring
    have t11 := RegExec.mul (inp := inp) hfd_le bu10 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 0) (b := 8) (by decide) (by decide) (by decide) (by rw [m11]; exact hjs_bl)
    rw [m11] at t11; set u11 := Function.update u10 8 ((j * nodeStride : ℕ) : ℤ); have bu11 : RegBounded W u11 := bu10.update (r := 8) (by decide) hjs_bl
    have t12 := RegExec.lit (inp := inp) hfd_le bu11 (sp_ok hm).1 (sp_ok hm).2 (dst := 15) (c := 6) (by decide) hl6
    set u12 := Function.update u11 15 6; have bu12 : RegBounded W u12 := bu11.update (r := 15) (by decide) hl6
    have a13 : u12 8 + u12 15 = ((j * nodeStride + 6 : ℕ) : ℤ) := by
      simp only [u12, u11, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15)]; push_cast; ring
    have t13 := RegExec.add (inp := inp) hfd_le bu12 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a13]; exact hjs6_bl)
    rw [a13] at t13; set u13 := Function.update u12 8 ((j * nodeStride + 6 : ℕ) : ℤ); have bu13 : RegBounded W u13 := bu12.update (r := 8) (by decide) hjs6_bl
    have hu13_6 : u13 6 = (c : ℤ) := by simp [u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg6]
    have a14 : u13 8 + u13 6 = ((j * nodeStride + 6 + c : ℕ) : ℤ) := by
      simp only [u13, Function.update_self, hu13_6]; push_cast; ring
    have t14 := RegExec.add (inp := inp) hfd_le bu13 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 6) (by decide) (by decide) (by decide) (by rw [a14]; exact hjsc_bl)
    rw [a14] at t14; set u14 := Function.update u13 8 ((j * nodeStride + 6 + c : ℕ) : ℤ); have bu14 : RegBounded W u14 := bu13.update (r := 8) (by decide) hjsc_bl
    have a15 : u14 8 + u14 6 = nodeCellAddr nodeStride j (6 + 2 * c) := by
      simp only [u14, Function.update_self, Function.update_of_ne (by decide : (6 : ℕ) ≠ 8), hu13_6, nodeCellAddr]; push_cast; ring
    have t15 := RegExec.add (inp := inp) hfd_le bu14 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 6) (by decide) (by decide) (by decide) (by rw [a15]; exact hno0_bl)
    rw [a15] at t15; set u15 := Function.update u14 8 (nodeCellAddr nodeStride j (6 + 2 * c)); have bu15 : RegBounded W u15 := bu14.update (r := 8) (by decide) hno0_bl
    have hm1 := hm.write (hSub3 (6 + 2 * c) (by clear * - hc; omega)) (oNum c) hno0_loc (hoN_c.trans ho_W)
    have hu15_9 : u15 9 = oNum c := by simp [u15, u14, u13, u12, u11, u10, u9, u8, u7, u6]
    have t16 := RegExec.store (inp := inp) hfd_le bu15 (table := 3) (addr := 8) (val := 9) (by decide) (by decide) hn3
      (by simpa [u15, hu15_9] using (sp_ok hm1).1) (by simpa [u15, hu15_9] using (sp_ok hm1).2)
    have hw1 : w.write (.heap 3 (u15 8)) (u15 9) = w.write (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c))) (oNum c) := by simp only [u15, Function.update_self, hu15_9]
    rw [hw1] at t16; set w1 := w.write (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c))) (oNum c)
    have t17 := RegExec.lit (inp := inp) hfd_le bu15 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 15) (c := 1) (by decide) hl1
    set u16 := Function.update u15 15 1; have bu16 : RegBounded W u16 := bu15.update (r := 15) (by decide) hl1
    have a18 : u16 8 + u16 15 = nodeCellAddr nodeStride j (6 + 2 * c + 1) := by
      simp only [u16, u15, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), nodeCellAddr]; push_cast; ring
    have t18 := RegExec.add (inp := inp) hfd_le bu16 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a18]; exact hno1_bl)
    rw [a18] at t18; set u17 := Function.update u16 8 (nodeCellAddr nodeStride j (6 + 2 * c + 1)); have bu17 : RegBounded W u17 := bu16.update (r := 8) (by decide) hno1_bl
    have hm2 := hm1.write (hSub3 (6 + 2 * c + 1) (by clear * - hc; omega)) (oDen c) hno1_loc (hoD_c.trans ho_W)
    have hu17_10 : u17 10 = oDen c := by simp [u17, u16, u15, u14, u13, u12, u11, u10, u9]
    have t19 := RegExec.store (inp := inp) hfd_le bu17 (table := 3) (addr := 8) (val := 10) (by decide) (by decide) hn3
      (by simpa [u17, hu17_10] using (sp_ok hm2).1) (by simpa [u17, hu17_10] using (sp_ok hm2).2)
    have hw2 : w1.write (.heap 3 (u17 8)) (u17 10) = w1.write (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1))) (oDen c) := by simp only [u17, Function.update_self, hu17_10]
    rw [hw2] at t19; set w2 := w1.write (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1))) (oDen c)
    -- 20..24: `(r11, r12) := (0, 1); accumSqDiffRegs; r6 := r6 + 1`
    have t20 := RegExec.lit (inp := inp) hfd_le bu17 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 11) (c := 0) (by decide) hl0
    set u18 := Function.update u17 11 0; have bu18 : RegBounded W u18 := bu17.update (r := 11) (by decide) hl0
    have t21 := RegExec.lit (inp := inp) hfd_le bu18 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 12) (c := 1) (by decide) hl1
    set u19 := Function.update u18 12 1; have bu19 : RegBounded W u19 := bu18.update (r := 12) (by decide) hl1
    have hW_acc : d * (2 * (B_cert + 2) + 3) + 20 ≤ W := by
      have hm : d * (2 * (B_cert + 2) + 3) ≤ (d + 1) * (2 * B_cert + 8) :=
        Nat.mul_le_mul (by clear * -; omega) (by clear * -; omega)
      clear * - hm hW; omega
    have hu19_3 : u19 3 = g 3 := by simp [u19, u18, u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1]
    have hu19_4 : u19 4 = g 4 := by simp [u19, u18, u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1]
    obtain ⟨u20, t22, bu20, hu20_3, hu20_4, hb20_3, hb20_4, hpres20⟩ :=
      exec_accumSqDiffRegs (inp := inp) (fd := fd) hfd_le (sp_ok hm2).1 (sp_ok hm2).2
        (pNum := oNum) (pDen := oDen) (qNum := zNum) (qDen := zDen)
        (B_p := B_cert) (B_q := 2) (c := c)
        hBc1 (by decide) hc hW_acc
        hoN_c hoD_c (by dsimp [zNum]; decide) (by dsimp [zDen]; decide) bu19
        (by simp [u19, u18, hu15_9, u17, u16])
        (by simp [u19, u18, hu17_10])
        (by simp [u19, u18, zNum])
        (by simp [u19, zDen])
        (hu19_3.trans hg3_eq) (hu19_4.trans hg4_eq)
        (by rw [hu19_3]; exact hg3_bl) (by rw [hu19_4]; exact hg4_bl)
    have t23 := RegExec.lit (inp := inp) hfd_le bu20 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 15) (c := 1) (by decide) hl1
    set u21 := Function.update u20 15 1; have bu21 : RegBounded W u21 := bu20.update (r := 15) (by decide) hl1
    have hu20_6 : u20 6 = (c : ℤ) := by
      rw [hpres20 6 (by decide) (by decide) (by decide)]
      simp [u19, u18, u17, u16, u15, u14, hu13_6]
    have a24 : u21 6 + u21 15 = ((c + 1 : ℕ) : ℤ) := by
      simp only [u21, Function.update_self, Function.update_of_ne (by decide : (6 : ℕ) ≠ 15), hu20_6]; push_cast; ring
    have t24 := RegExec.add (inp := inp) hfd_le bu21 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 6) (a := 6) (b := 15)
      (by decide) (by decide) (by decide) (by rw [a24]; exact hc1_bl)
    rw [a24] at t24; set u22 := Function.update u21 6 ((c + 1 : ℕ) : ℤ); have bu22 : RegBounded W u22 := bu21.update (r := 6) (by decide) hc1_bl
    have sAll := (t1.seq (t2.seq (t3.seq (t4.seq (t5.seq (t6.seq (t7.seq (t8.seq (t9.seq (t10.seq
      (t11.seq (t12.seq (t13.seq (t14.seq (t15.seq (t16.seq (t17.seq (t18.seq (t19.seq (t20.seq
      (t21.seq (t22.seq (t23.seq t24))))))))))))))))))))))).weaken
      rfl rfl (u₂ := 240) (b₂ := 56 * W * W) (by clear * -; omega)
      (by calc _ = 44 * (W * W) + (88 * W + 496) := by ring
            _ ≤ 44 * (W * W) + 12 * (W * W) := Nat.add_le_add_left (by linarith only [hW20, hWW]) _
            _ = 56 * W * W := by ring)
    refine ⟨w2, u22, sAll, hm2, bu22, ?_, ?_, ?_, ?_⟩
    · simp only [u22, u21, Function.update_of_ne (by decide : (0 : ℕ) ≠ 6), Function.update_of_ne (by decide : (0 : ℕ) ≠ 15)]
      rw [hpres20 0 (by decide) (by decide) (by decide)]
      simp [u19, u18, u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg0]
    · simp only [u22, u21, Function.update_of_ne (by decide : (5 : ℕ) ≠ 6), Function.update_of_ne (by decide : (5 : ℕ) ≠ 15)]
      rw [hpres20 5 (by decide) (by decide) (by decide)]
      simp [u19, u18, u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg5]
    · intro loc hne
      have n0 : loc ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c)) := hne (6 + 2 * c) (by clear * - hc; omega)
      have n1 : loc ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1)) := hne (6 + 2 * c + 1) (by clear * - hc; omega)
      have u0 := hunch loc hne
      exact ⟨by simp [w2, w1, WordStore.write, n0, n1, u0.1],
             by simp [w2, w1, WordStore.write, Function.update_of_ne n1, Function.update_of_ne n0, u0.2]⟩
    · intro _
      have hu22_3 : u22 3 = u20 3 := by simp [u22, u21]
      have hu22_4 : u22 4 = u20 4 := by simp [u22, u21]
      refine ⟨by simp [u22], hu22_3.trans hu20_3, hu22_4.trans hu20_4,
        by rw [hu22_3]; exact hb20_3, by rw [hu22_4]; exact hb20_4,
        fun c' hc' hlt_c1 => ?_⟩
      have hc'_le : c' ≤ c := by clear * - hlt_c1; omega
      rcases eq_or_lt_of_le hc'_le with rfl | hlt
      · have hne01 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c')) : RAMCellLoc) ≠
            .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c' + 1)) := by
          intro h; injection h with _ ha
          have h_eq := (nodeCellAddr_inj (by clear * - hc hstride; omega) (by clear * - hc hstride; omega) ha).2
          clear * - h_eq; omega
        exact ⟨by simp only [w2, w1]; rw [wordStore_read_write_ne _ hne01]; simp,
               by simp [w2]⟩
      · have hne0 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c')) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c)) := by
          intro h; injection h with _ ha
          have h_eq := (nodeCellAddr_inj (by clear * - hc' hstride; omega) (by clear * - hc hstride; omega) ha).2
          clear * - hlt h_eq; omega
        have hne1 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c')) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1)) := by
          intro h; injection h with _ ha
          have h_eq := (nodeCellAddr_inj (by clear * - hc' hstride; omega) (by clear * - hc hstride; omega) ha).2
          clear * - hlt h_eq; omega
        have hne2 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c' + 1)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c)) := by
          intro h; injection h with _ ha
          have h_eq := (nodeCellAddr_inj (by clear * - hc' hstride; omega) (by clear * - hc hstride; omega) ha).2
          clear * - hlt h_eq; omega
        have hne3 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c' + 1)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1)) := by
          intro h; injection h with _ ha
          have h_eq := (nodeCellAddr_inj (by clear * - hc' hstride; omega) (by clear * - hc hstride; omega) ha).2
          clear * - hlt h_eq; omega
        obtain ⟨hp0, hp1⟩ := hprev c' hc' hlt
        exact ⟨by simp only [w2, w1]; rw [wordStore_read_write_ne _ hne1, wordStore_read_write_ne _ hne0]; exact hp0,
               by simp only [w2, w1]; rw [wordStore_read_write_ne _ hne3, wordStore_read_write_ne _ hne2]; exact hp1⟩
  classical
  let seqP : ∀ n : ℕ, { p : WordStore × (ℕ → ℤ) // StepInv n p.1 p.2 } :=
    Nat.rec ⟨(ws, g3), hInv0⟩ (fun c prev =>
      if hc : c < d then
        let hEx := hStep c hc prev.1.1 prev.1.2 prev.2
        let w' := Classical.choose hEx
        let hEx2 := Classical.choose_spec hEx
        ⟨(w', Classical.choose hEx2), (Classical.choose_spec hEx2).2⟩
      else
        ⟨prev.1, ⟨prev.2.1, prev.2.2.1, prev.2.2.2.1, prev.2.2.2.2.1, prev.2.2.2.2.2.1,
          fun hle => absurd (by clear * - hc hle; omega : c < d) hc⟩⟩)
  have hRep := RegExec.repeatLit (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    d hd_bl (fun i => (seqP i).1.1) (fun i => (seqP i).1.2) bg3
    (body := extractCenterCoordStepStmt nodeStride T_max) (U := 240) (B := 56 * W * W)
    (fun i hi => by
      dsimp only [seqP]
      rw [dif_pos hi]
      exact (Classical.choose_spec (Classical.choose_spec (hStep i hi (seqP i).1.1 (seqP i).1.2 (seqP i).2))).1)
  let wL := (seqP d).1.1; let gL := (seqP d).1.2
  have hEndP : StepInv d wL gL := (seqP d).2
  obtain ⟨hmL, bgL, hgL0, hgL5, hunchL, hdL⟩ := hEndP
  obtain ⟨_, hgL3, hgL4, hbL3, hbL4, hreadO_L⟩ := hdL le_rfl
  -- Post-loop: read `(sN, sD)` from `heap 10`, compute `V_num, V_den`, write to `heap 3 (j * nodeStride + 3/4)`
  set sN := ws.read (.heap 10 ((((2 * d) * T_max + 1 : ℕ) : ℤ)))
  set sD := ws.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)))
  dsimp only at hs10
  obtain ⟨hsD1, hs_eq, hsN_bl, hsD_bl⟩ := hs10
  have h2d1_le_ceil : (2 * d + 1) * T_max + 1 ≤ (2 * d + 2) * T_max := by
    calc (2 * d + 1) * T_max + 1 ≤ (2 * d + 1) * T_max + T_max := Nat.add_le_add_left (by clear * - hT1; omega) _
      _ = (2 * d + 2) * T_max := by ring
  have h2d0_le_2d1 : (2 * d) * T_max + 1 ≤ (2 * d + 1) * T_max + 1 :=
    Nat.add_le_add_right (Nat.mul_le_mul_right T_max (by clear * -; omega)) 1
  have ha10_s0_bl : intBitLength ((((2 * d) * T_max + 1 : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono (h2d0_le_2d1.trans h2d1_le_ceil)).trans h10_ceil_bl
  have ha10_s1_bl : intBitLength ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono h2d1_le_ceil).trans h10_ceil_bl
  have hrwL_sN : wL.read (.heap 10 ((((2 * d) * T_max + 1 : ℕ) : ℤ))) = sN := by
    rw [wordStore_read_eq_vals hmL.wf, (hunchL _ (fun _ _ h => by cases h)).2, ← wordStore_read_eq_vals hmod.wf]
  have hrwL_sD : wL.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ))) = sD := by
    rw [wordStore_read_eq_vals hmL.wf, (hunchL _ (fun _ _ h => by cases h)).2, ← wordStore_read_eq_vals hmod.wf]
  have hs_W : B_cert ≤ W := by
    have hm : 1 * (2 * B_cert + 8) ≤ (d + 1) * (2 * B_cert + 8) := Nat.mul_le_mul_right _ (by clear * -; omega)
    clear * - hm hW; omega
  set V_num := sN * gL 4 - gL 3 * sD
  set V_den := sD * gL 4
  have bm_sN4 : intBitLength (sN * gL 4) ≤ B_cert + (d * (2 * (B_cert + 2) + 2) + 2) :=
    (intBitLength_mul_le _ _).trans (Nat.add_le_add hsN_bl hbL4)
  have bm_3sD : intBitLength (gL 3 * sD) ≤ (d * (2 * (B_cert + 2) + 3) + 2) + B_cert :=
    (intBitLength_mul_le _ _).trans (Nat.add_le_add hbL3 hsD_bl)
  have hd_c2 : d * (2 * (B_cert + 2) + 2) ≤ d * (2 * B_cert + 7) :=
    Nat.mul_le_mul_left d (by clear * -; omega)
  have hd_c3 : d * (2 * (B_cert + 2) + 3) = d * (2 * B_cert + 7) := by ring
  have hd_expand : (d + 1) * (2 * B_cert + 7) = d * (2 * B_cert + 7) + 2 * B_cert + 7 := by ring
  have hVN_bnd : intBitLength V_num ≤ (d + 1) * (2 * B_cert + 7) + 4 := by
    have hs := intBitLength_sub_le_max (sN * gL 4) (gL 3 * sD)
    have hmax : max (intBitLength (sN * gL 4)) (intBitLength (gL 3 * sD)) ≤
        (d * (2 * B_cert + 7) + 2) + B_cert := by
      apply max_le
      · exact bm_sN4.trans (by clear * - hd_c2; omega)
      · exact bm_3sD.trans (by rw [hd_c3])
    dsimp [V_num]; rw [hd_expand]; clear * - hs hmax; omega
  have hVD_bnd : intBitLength V_den ≤ (d + 1) * (2 * B_cert + 7) + 4 := by
    have hm := (intBitLength_mul_le sD (gL 4)).trans (Nat.add_le_add hsD_bl hbL4)
    dsimp [V_den]; rw [hd_expand]; clear * - hm hd_c2; omega
  have hV_W : (d + 1) * (2 * B_cert + 7) + 4 ≤ W := by
    have hm : (d + 1) * (2 * B_cert + 7) ≤ (d + 1) * (2 * B_cert + 8) :=
      Nat.mul_le_mul_left (d + 1) (by clear * -; omega)
    clear * - hm hW; omega
  obtain ⟨hn3_loc, hn3_bl⟩ := nodeCellAddr_bl hj (off := 3) (by clear * - hstride; omega) hW_node
  obtain ⟨hn4_loc, hn4_bl⟩ := nodeCellAddr_bl hj (off := 4) (by clear * - hstride; omega) hW_node
  have hjs_bl0 : intBitLength ((j * nodeStride : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := j * nodeStride + 3) (by clear * -; omega)).trans hn3_bl
  -- Execute post-loop instructions `q1..q16`
  have q1 := RegExec.lit (inp := inp) hfd_le bgL (sp_ok hmL).1 (sp_ok hmL).2 (dst := 8) (c := ((((2 * d) * T_max + 1 : ℕ) : ℤ))) (by decide) ha10_s0_bl
  set z1 := Function.update gL 8 ((((2 * d) * T_max + 1 : ℕ) : ℤ)); have bz1 : RegBounded W z1 := bgL.update (r := 8) (by decide) ha10_s0_bl
  have hz1_8 : wL.read (.heap 10 (z1 8)) = sN := by simp only [z1, Function.update_self]; exact hrwL_sN
  have q2 := RegExec.load (inp := inp) hfd_le bz1 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 9) (table := 10) (addr := 8) (by decide) (by decide) hn10 (by rw [hz1_8]; exact hsN_bl.trans hs_W)
  rw [hz1_8] at q2; set z2 := Function.update z1 9 sN; have bz2 : RegBounded W z2 := bz1.update (r := 9) (by decide) (hsN_bl.trans hs_W)
  have q3 := RegExec.lit (inp := inp) hfd_le bz2 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 8) (c := ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ))) (by decide) ha10_s1_bl
  set z3 := Function.update z2 8 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)); have bz3 : RegBounded W z3 := bz2.update (r := 8) (by decide) ha10_s1_bl
  have hz3_8 : wL.read (.heap 10 (z3 8)) = sD := by simp only [z3, Function.update_self]; exact hrwL_sD
  have q4 := RegExec.load (inp := inp) hfd_le bz3 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 10) (table := 10) (addr := 8) (by decide) (by decide) hn10 (by rw [hz3_8]; exact hsD_bl.trans hs_W)
  rw [hz3_8] at q4; set z4 := Function.update z3 10 sD; have bz4 : RegBounded W z4 := bz3.update (r := 10) (by decide) (hsD_bl.trans hs_W)
  have mz5 : z4 9 * z4 4 = sN * gL 4 := by simp [z4, z3, z2, z1]
  have q5 := RegExec.mul (inp := inp) hfd_le bz4 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 13) (a := 9) (b := 4) (by decide) (by decide) (by decide)
    (by rw [mz5]; exact bm_sN4.trans (by rw [hd_expand] at hV_W; clear * - hd_c2 hV_W; omega))
  rw [mz5] at q5; set z5 := Function.update z4 13 (sN * gL 4); have bz5 : RegBounded W z5 := bz4.update (r := 13) (by decide) (bm_sN4.trans (by rw [hd_expand] at hV_W; clear * - hd_c2 hV_W; omega))
  have mz6 : z5 3 * z5 10 = gL 3 * sD := by simp [z5, z4, z3, z2, z1]
  have q6 := RegExec.mul (inp := inp) hfd_le bz5 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 14) (a := 3) (b := 10) (by decide) (by decide) (by decide)
    (by rw [mz6]; exact bm_3sD.trans (by rw [hd_expand] at hV_W; rw [hd_c3]; clear * - hV_W; omega))
  rw [mz6] at q6; set z6 := Function.update z5 14 (gL 3 * sD); have bz6 : RegBounded W z6 := bz5.update (r := 14) (by decide) (bm_3sD.trans (by rw [hd_expand] at hV_W; rw [hd_c3]; clear * - hV_W; omega))
  have sz7 : z6 13 - z6 14 = V_num := by simp [z6, z5, V_num]
  have q7 := RegExec.sub (inp := inp) hfd_le bz6 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 13) (a := 13) (b := 14) (by decide) (by decide) (by decide)
    (by rw [sz7]; exact hVN_bnd.trans hV_W)
  rw [sz7] at q7; set z7 := Function.update z6 13 V_num; have bz7 : RegBounded W z7 := bz6.update (r := 13) (by decide) (hVN_bnd.trans hV_W)
  have mz8 : z7 10 * z7 4 = V_den := by simp [z7, z6, z5, z4, z3, z2, z1, V_den]
  have q8 := RegExec.mul (inp := inp) hfd_le bz7 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 14) (a := 10) (b := 4) (by decide) (by decide) (by decide)
    (by rw [mz8]; exact hVD_bnd.trans hV_W)
  rw [mz8] at q8; set z8 := Function.update z7 14 V_den; have bz8 : RegBounded W z8 := bz7.update (r := 14) (by decide) (hVD_bnd.trans hV_W)
  have q9 := RegExec.lit (inp := inp) hfd_le bz8 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 8) (c := (nodeStride : ℤ)) (by decide) hstride_bl
  set z9 := Function.update z8 8 (nodeStride : ℤ); have bz9 : RegBounded W z9 := bz8.update (r := 8) (by decide) hstride_bl
  have mz10 : z9 0 * z9 8 = ((j * nodeStride : ℕ) : ℤ) := by
    simp only [z9, z8, z7, z6, z5, z4, z3, z2, z1, Function.update_self,
      Function.update_of_ne (by decide : (0 : ℕ) ≠ 8), Function.update_of_ne (by decide : (0 : ℕ) ≠ 14),
      Function.update_of_ne (by decide : (0 : ℕ) ≠ 13), Function.update_of_ne (by decide : (0 : ℕ) ≠ 10),
      Function.update_of_ne (by decide : (0 : ℕ) ≠ 9), hgL0]
    push_cast; ring
  have q10 := RegExec.mul (inp := inp) hfd_le bz9 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 8) (a := 0) (b := 8) (by decide) (by decide) (by decide) (by rw [mz10]; exact hjs_bl0)
  rw [mz10] at q10; set z10 := Function.update z9 8 ((j * nodeStride : ℕ) : ℤ); have bz10 : RegBounded W z10 := bz9.update (r := 8) (by decide) hjs_bl0
  have q11 := RegExec.lit (inp := inp) hfd_le bz10 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 15) (c := 3) (by decide) hl3
  set z11 := Function.update z10 15 3; have bz11 : RegBounded W z11 := bz10.update (r := 15) (by decide) hl3
  have az12 : z11 8 + z11 15 = nodeCellAddr nodeStride j 3 := by
    simp only [z11, z10, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), nodeCellAddr]; push_cast; ring
  have q12 := RegExec.add (inp := inp) hfd_le bz11 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [az12]; exact hn3_bl)
  rw [az12] at q12; set z12 := Function.update z11 8 (nodeCellAddr nodeStride j 3); have bz12 : RegBounded W z12 := bz11.update (r := 8) (by decide) hn3_bl
  have hmV1 := hmL.write (hSub3 3 (by clear * -; omega)) V_num hn3_loc (hVN_bnd.trans hV_W)
  have hz12_13 : z12 13 = V_num := by simp [z12, z11, z10, z9, z8, z7]
  have q13 := RegExec.store (inp := inp) hfd_le bz12 (table := 3) (addr := 8) (val := 13) (by decide) (by decide) hn3
    (by simpa [z12, hz12_13] using (sp_ok hmV1).1) (by simpa [z12, hz12_13] using (sp_ok hmV1).2)
  have hwV1 : wL.write (.heap 3 (z12 8)) (z12 13) = wL.write (.heap 3 (nodeCellAddr nodeStride j 3)) V_num := by simp only [z12, Function.update_self, hz12_13]
  rw [hwV1] at q13; set wV1 := wL.write (.heap 3 (nodeCellAddr nodeStride j 3)) V_num
  have q14 := RegExec.lit (inp := inp) hfd_le bz12 (sp_ok hmV1).1 (sp_ok hmV1).2 (dst := 15) (c := 1) (by decide) hl1
  set z13 := Function.update z12 15 1; have bz13 : RegBounded W z13 := bz12.update (r := 15) (by decide) hl1
  have az15 : z13 8 + z13 15 = nodeCellAddr nodeStride j 4 := by
    simp only [z13, z12, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), nodeCellAddr]; push_cast; ring
  have q15 := RegExec.add (inp := inp) hfd_le bz13 (sp_ok hmV1).1 (sp_ok hmV1).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [az15]; exact hn4_bl)
  rw [az15] at q15; set z14 := Function.update z13 8 (nodeCellAddr nodeStride j 4); have bz14 : RegBounded W z14 := bz13.update (r := 8) (by decide) hn4_bl
  have hmEnd := hmV1.write (hSub3 4 (by clear * -; omega)) V_den hn4_loc (hVD_bnd.trans hV_W)
  have hz14_14 : z14 14 = V_den := by simp [z14, z13, z12, z11, z10, z9, z8]
  have q16 := RegExec.store (inp := inp) hfd_le bz14 (table := 3) (addr := 8) (val := 14) (by decide) (by decide) hn3
    (by simpa [z14, hz14_14] using (sp_ok hmEnd).1) (by simpa [z14, hz14_14] using (sp_ok hmEnd).2)
  have hwEnd : wV1.write (.heap 3 (z14 8)) (z14 14) = wV1.write (.heap 3 (nodeCellAddr nodeStride j 4)) V_den := by simp only [z14, Function.update_self, hz14_14]
  rw [hwEnd] at q16; set wsEnd := wV1.write (.heap 3 (nodeCellAddr nodeStride j 4)) V_den
  -- Total cost bound
  have hb_tot : 2 * W + 16 + (2 * W + 16 + (2 * W + 16 + (d * (56 * W * W) + W +
      (2 * W + 16 + (6 * W + 24 + (2 * W + 16 + (6 * W + 24 + (4 * W * W + (4 * W * W +
      (6 * W + 32 + (4 * W * W + (2 * W + 16 + (4 * W * W + (2 * W + 16 + (6 * W + 32 +
      (5 * W + 24 + (2 * W + 16 + (6 * W + 32 + (5 * W + 24))))))))))))))))))) ≤
      (60 * d + 36) * W * W := by
    calc _
      _ = 56 * d * (W * W) + (16 * (W * W) + 57 * W + 320) := by ring
      _ ≤ 56 * d * (W * W) + 36 * (W * W) := Nat.add_le_add_left (by linarith only [hW20, hWW]) _
      _ = (56 * d + 36) * W * W := by ring
      _ ≤ (60 * d + 36) * W * W := Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by clear * -; omega))
  have sTot := (hp1.seq (hp2.seq (hp3.seq (hRep.seq (q1.seq (q2.seq (q3.seq (q4.seq (q5.seq (q6.seq
    (q7.seq (q8.seq (q9.seq (q10.seq (q11.seq (q12.seq (q13.seq (q14.seq (q15.seq q16))))))))))))))))))).weaken rfl rfl
    (u₂ := 260 * d + 140) (b₂ := (60 * d + 36) * W * W) (by clear * -; omega) hb_tot
  -- Establish `NodeGeomStored` for `wsEnd`!
  have hBt : 1 ≤ 2 * (B_cert + 2) + 2 := by clear * -; omega
  have hbnds_term : ∀ i < d, 1 ≤ sqDen i ∧ intBitLength (sqNum i) ≤ 2 * (B_cert + 2) + 2 ∧ intBitLength (sqDen i) ≤ 2 * (B_cert + 2) + 2 := by
    intro i hi
    have ho_i := ho10 ⟨i, hi⟩; dsimp only at ho_i
    obtain ⟨hoD1, _, boN, boD⟩ := ho_i
    have hoDi : 1 ≤ oDen i := by simp [oDen, hi]; exact hoD1
    have h1 : 1 ≤ sqDen i := by dsimp [sqDen, zDen]; nlinarith only [hoDi]
    have bm1 : intBitLength (oNum i * zDen i) ≤ B_cert + 2 :=
      (intBitLength_mul_le _ _).trans (Nat.add_le_add (by simp only [oNum, if_pos hi]; exact boN) (by dsimp [zDen]; decide))
    have bm2 : intBitLength (zNum i * oDen i) ≤ B_cert + 2 := by
      have : zNum i * oDen i = 0 := by simp [zNum]
      rw [this]; exact (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by clear * -; omega)
    have bdf : intBitLength (oNum i * zDen i - zNum i * oDen i) ≤ B_cert + 3 := by
      have hs := intBitLength_sub_le_max (oNum i * zDen i) (zNum i * oDen i)
      have hm := max_le bm1 bm2
      clear * - hs hm; omega
    have bsN : intBitLength (sqNum i) ≤ 2 * (B_cert + 2) + 2 := by
      have := (intBitLength_mul_le _ _).trans (Nat.add_le_add bdf bdf)
      dsimp [sqNum]; clear * - this; omega
    have bpd : intBitLength (oDen i * zDen i) ≤ B_cert + 2 :=
      (intBitLength_mul_le _ _).trans (Nat.add_le_add (by simp only [oDen, if_pos hi]; exact boD) (by dsimp [zDen]; decide))
    have bsD : intBitLength (sqDen i) ≤ 2 * (B_cert + 2) + 2 := by
      have := (intBitLength_mul_le _ _).trans (Nat.add_le_add bpd bpd)
      dsimp [sqDen]; clear * - this; omega
    exact ⟨h1, bsN, bsD⟩
  obtain ⟨hden_pos, _, _, _, _⟩ := ratSumPairs_spec hBt d hbnds_term
  have hgL4_pos : 1 ≤ gL 4 := by rw [hgL4]; exact hden_pos
  have hVD_pos : 1 ≤ V_den := by dsimp [V_den]; nlinarith only [hsD1, hgL4_pos]
  have hnorm_o := ratPoint_distSq_eq (p := oRat) (q := fun _ => 0)
    (pNum := oNum) (pDen := oDen) (qNum := zNum) (qDen := zDen)
    (fun c => by
      have ho_c := ho10 c; dsimp only at ho_c
      exact ⟨by simp [oDen, c.isLt]; exact ho_c.1,
             by simp only [oNum, oDen, c.isLt, ↓reduceIte, ho_c.2.1]; push_cast; rfl⟩)
    (fun _ => ⟨by dsimp [zDen]; omega, by simp [zNum, zDen]⟩)
  have hzero_euc : ratPointToEuclidean (fun _ : Fin d => (0 : ℚ)) = 0 := by
    ext c; simp [ratPointToEuclidean]
  rw [hzero_euc, sub_zero] at hnorm_o
  have hV_eq : ((V_num : ℝ) / (V_den : ℝ)) = liftVariance (ratPointToEuclidean oRat) (sRat : ℝ) := by
    unfold liftVariance
    rw [← hnorm_o, ← hgL3, ← hgL4, hs_eq]
    have hsD_ne : (sD : ℝ) ≠ 0 := by exact_mod_cast (by clear * - hsD1; omega : sD ≠ 0)
    have hg4_ne : (gL 4 : ℝ) ≠ 0 := by exact_mod_cast (by clear * - hgL4_pos; omega : gL 4 ≠ 0)
    push_cast
    rw [div_sub_div _ _ hsD_ne hg4_ne]
    dsimp [V_num, V_den]; push_cast; ring
  refine ⟨wsEnd, z14, V_num, V_den, sTot, hmEnd, bz14,
    by simp [z14, z13, z12, z11, z10, z9, z8, z7, z6, z5, z4, z3, z2, z1, hgL0],
    by simp [z14, z13, z12, z11, z10, z9, z8, z7, z6, z5, z4, z3, z2, z1, hgL5],
    ?_, ?_⟩
  · have hne34 : (.heap 3 (nodeCellAddr nodeStride j 3) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j 4) := by
      intro h; injection h with _ ha
      have h_eq := (nodeCellAddr_inj (by clear * - hstride; omega) (by clear * - hstride; omega) ha).2
      clear * - h_eq; omega
    refine
      { hV_nn := hV_nn
        hV_den := hVD_pos
        hV_eq := hV_eq
        hVN_bl := hVN_bnd
        hVD_bl := hVD_bnd
        read_VN := by simp only [wsEnd, wV1]; rw [wordStore_read_write_ne _ hne34]; simp
        read_VD := by simp [wsEnd]
        read_o := fun c => ?_ }
    have ho_c := ho10 c; dsimp only at ho_c
    obtain ⟨hoD1, ho_eq, boN, boD⟩ := ho_c
    obtain ⟨hr_oN, hr_oD⟩ := hreadO_L c.val c.isLt c.isLt
    have ne0_4 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j 4) := by
      intro h; injection h with _ ha
      have hc := c.isLt
      have h_eq := (nodeCellAddr_inj (by clear * - hc hstride; omega) (by clear * - hstride; omega) ha).2
      clear * - h_eq; omega
    have ne0_3 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j 3) := by
      intro h; injection h with _ ha
      have hc := c.isLt
      have h_eq := (nodeCellAddr_inj (by clear * - hc hstride; omega) (by clear * - hstride; omega) ha).2
      clear * - h_eq; omega
    have ne1_4 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val + 1)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j 4) := by
      intro h; injection h with _ ha
      have hc := c.isLt
      have h_eq := (nodeCellAddr_inj (by clear * - hc hstride; omega) (by clear * - hstride; omega) ha).2
      clear * - h_eq; omega
    have ne1_3 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val + 1)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j 3) := by
      intro h; injection h with _ ha
      have hc := c.isLt
      have h_eq := (nodeCellAddr_inj (by clear * - hc hstride; omega) (by clear * - hstride; omega) ha).2
      clear * - h_eq; omega
    have eN : wsEnd.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val))) = oNum c.val := by
      simp only [wsEnd, wV1]
      rw [wordStore_read_write_ne _ ne0_4, wordStore_read_write_ne _ ne0_3]
      exact hr_oN
    have eD : wsEnd.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val + 1))) = oDen c.val := by
      simp only [wsEnd, wV1]
      rw [wordStore_read_write_ne _ ne1_4, wordStore_read_write_ne _ ne1_3]
      exact hr_oD
    dsimp only
    rw [eN, eD]
    simp only [oNum, oDen, c.isLt, ↓reduceIte]
    exact ⟨hoD1, by rw [ho_eq]; push_cast; rfl, boN, boD⟩
  · intro loc hne
    have n3 : loc ≠ .heap 3 (nodeCellAddr nodeStride j 3) := hne 3 (by clear * -; omega)
    have n4 : loc ≠ .heap 3 (nodeCellAddr nodeStride j 4) := hne 4 (by clear * -; omega)
    have uL := hunchL loc hne
    exact ⟨by simp only [wsEnd, wV1, WordStore.write, Finset.mem_insert, n3, n4, false_or]; exact uL.1,
           by simp only [wsEnd, wV1, WordStore.write, Function.update_of_ne n4, Function.update_of_ne n3]; exact uL.2⟩

end UL.C12LVE
