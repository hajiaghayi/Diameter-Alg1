import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2a_ProbAndSim
set_option autoImplicit false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Arithmetic bit-length bounds (`+`, `-`, `*`, `/`, `%`, encoding) -/

theorem natBitLength_add_le (a b : ℕ) :
    natBitLength (a + b) ≤ max (natBitLength a) (natBitLength b) + 1 := by
  let L := max (natBitLength a) (natBitLength b)
  have ha : a < 2 ^ L :=
    (Nat.lt_pow_succ_log_self (by norm_num) a).trans_le
      (Nat.pow_le_pow_right (by norm_num) (le_max_left _ _))
  have hb : b < 2 ^ L :=
    (Nat.lt_pow_succ_log_self (by norm_num) b).trans_le
      (Nat.pow_le_pow_right (by norm_num) (le_max_right _ _))
  have hab : a + b < 2 ^ (L + 1) := by rw [pow_succ]; omega
  rcases Nat.eq_zero_or_pos (a + b) with hz | hpos
  · rw [hz]
    have : natBitLength 0 = 1 := by decide
    omega
  · have hlog := (Nat.log_lt_iff_lt_pow (by norm_num) hpos.ne').mpr hab
    change Nat.log 2 (a + b) + 1 ≤ L + 1
    omega

theorem natBitLength_mul_le (a b : ℕ) :
    natBitLength (a * b) ≤ natBitLength a + natBitLength b := by
  have ha : a < 2 ^ (natBitLength a) := Nat.lt_pow_succ_log_self (by norm_num) a
  have hb : b < 2 ^ (natBitLength b) := Nat.lt_pow_succ_log_self (by norm_num) b
  have hab : a * b < 2 ^ (natBitLength a + natBitLength b) := by
    rw [pow_add]; exact Nat.mul_lt_mul'' ha hb
  rcases Nat.eq_zero_or_pos (a * b) with hz | hpos
  · rw [hz]
    have h0 : natBitLength 0 = 1 := by decide
    have h1 := natBitLength_pos a
    have h2 := natBitLength_pos b
    omega
  · have hlog := (Nat.log_lt_iff_lt_pow (by norm_num) hpos.ne').mpr hab
    change Nat.log 2 (a * b) + 1 ≤ natBitLength a + natBitLength b
    omega

theorem intBitLength_neg_eq (z : ℤ) : intBitLength (-z) = intBitLength z := by
  unfold intBitLength; simp

theorem intBitLength_ofNat_le (m : ℕ) : intBitLength (m : ℤ) ≤ natBitLength m + 1 := by
  unfold intBitLength
  split_ifs with h
  · have := natBitLength_pos m
    omega
  · simp only [Int.natAbs_natCast]
    omega

theorem intBitLength_add_le (a b : ℤ) :
    intBitLength (a + b) ≤ intBitLength a + intBitLength b + 1 := by
  by_cases ha : a = 0
  · subst ha
    simp only [zero_add]
    have h0 : intBitLength 0 = 1 := by decide
    omega
  · by_cases hb : b = 0
    · subst hb
      simp only [add_zero]
      have h0 : intBitLength 0 = 1 := by decide
      omega
    · by_cases hab : a + b = 0
      · rw [hab]
        have h0 : intBitLength 0 = 1 := by decide
        have h1 := intBitLength_pos a
        have h2 := intBitLength_pos b
        omega
      · have habs : (a + b).natAbs ≤ a.natAbs + b.natAbs := Int.natAbs_add_le a b
        have hmono := natBitLength_mono habs
        have hadd := natBitLength_add_le a.natAbs b.natAbs
        unfold intBitLength
        simp only [ha, hb, hab, ↓reduceIte]
        omega

theorem intBitLength_sub_le (a b : ℤ) :
    intBitLength (a - b) ≤ intBitLength a + intBitLength b + 1 := by
  rw [sub_eq_add_neg, ← intBitLength_neg_eq b]
  exact intBitLength_add_le a (-b)

theorem intBitLength_mul_le (a b : ℤ) :
    intBitLength (a * b) ≤ intBitLength a + intBitLength b := by
  by_cases ha : a = 0
  · subst ha
    simp only [zero_mul]
    have h0 : intBitLength 0 = 1 := by decide
    have h1 := intBitLength_pos b
    omega
  · by_cases hb : b = 0
    · subst hb
      simp only [mul_zero]
      have h0 : intBitLength 0 = 1 := by decide
      have h1 := intBitLength_pos a
      omega
    · have hmul : a * b ≠ 0 := mul_ne_zero ha hb
      unfold intBitLength
      simp only [ha, hb, hmul, ↓reduceIte, Int.natAbs_mul]
      have h1 := natBitLength_mul_le a.natAbs b.natAbs
      omega

theorem intBitLength_ediv_le (a b : ℤ) :
    intBitLength (a / b) ≤ intBitLength a + 1 := by
  by_cases hb : b = 0
  · subst hb
    simp only [Int.ediv_zero]
    have h0 : intBitLength 0 = 1 := by decide
    have h1 := intBitLength_pos a
    omega
  · have habs : (a / b).natAbs ≤ a.natAbs := by
      have hmod := Int.mul_ediv_add_emod a b
      have hm0 : 0 ≤ a % b := Int.emod_nonneg a hb
      have hm1 : a % b < (b.natAbs : ℤ) := Int.emod_lt a hb
      have hb_pos : 1 ≤ b.natAbs := Int.natAbs_pos.mpr hb
      by_cases hq0 : a / b = 0
      · simp [hq0]
      · rcases lt_or_gt_of_ne hq0 with hneg | hpos
        · rcases lt_or_gt_of_ne hb with hbneg | hbpos
          · have hb_eq : (b.natAbs : ℤ) = -b := by omega
            have hq_eq : ((a / b).natAbs : ℤ) = -(a / b) := by omega
            have hprod : b * (a / b) = (b.natAbs : ℤ) * ((a / b).natAbs : ℤ) := by nlinarith
            have ha_ge : (b.natAbs : ℤ) * ((a / b).natAbs : ℤ) ≤ a := by linarith
            have h1 : (1 : ℤ) ≤ (b.natAbs : ℤ) := by exact_mod_cast hb_pos
            have hge1 : ((a / b).natAbs : ℤ) ≤ (b.natAbs : ℤ) * ((a / b).natAbs : ℤ) := by nlinarith
            have : ((a / b).natAbs : ℤ) ≤ (a.natAbs : ℤ) := by omega
            exact_mod_cast this
          · have hb_eq : (b.natAbs : ℤ) = b := by omega
            have hq_eq : ((a / b).natAbs : ℤ) = -(a / b) := by omega
            have hprod : b * (a / b) = -(b.natAbs : ℤ) * ((a / b).natAbs : ℤ) := by nlinarith
            have h1 : (1 : ℤ) ≤ (b.natAbs : ℤ) := by exact_mod_cast hb_pos
            have hle_b : (b.natAbs : ℤ) * (((a / b).natAbs : ℤ) - 1) ≥ ((a / b).natAbs : ℤ) - 1 := by
              nlinarith
            have ha_le : a ≤ -((a / b).natAbs : ℤ) := by nlinarith
            have : ((a / b).natAbs : ℤ) ≤ (a.natAbs : ℤ) := by omega
            exact_mod_cast this
        · rcases lt_or_gt_of_ne hb with hbneg | hbpos
          · have hb_eq : (b.natAbs : ℤ) = -b := by omega
            have hq_eq : ((a / b).natAbs : ℤ) = a / b := by omega
            have h1 : (1 : ℤ) ≤ (b.natAbs : ℤ) := by exact_mod_cast hb_pos
            have hle_b : (b.natAbs : ℤ) * (((a / b).natAbs : ℤ) - 1) ≥ ((a / b).natAbs : ℤ) - 1 := by
              nlinarith
            have ha_le : a ≤ -((a / b).natAbs : ℤ) := by nlinarith
            have : ((a / b).natAbs : ℤ) ≤ (a.natAbs : ℤ) := by omega
            exact_mod_cast this
          · have hb_eq : (b.natAbs : ℤ) = b := by omega
            have hq_eq : ((a / b).natAbs : ℤ) = a / b := by omega
            have h1 : (1 : ℤ) ≤ (b.natAbs : ℤ) := by exact_mod_cast hb_pos
            have : ((a / b).natAbs : ℤ) ≤ (b.natAbs : ℤ) * ((a / b).natAbs : ℤ) := by nlinarith
            have : ((a / b).natAbs : ℤ) ≤ a := by nlinarith
            have : ((a / b).natAbs : ℤ) ≤ (a.natAbs : ℤ) := by omega
            exact_mod_cast this
    exact intBitLength_mono_natAbs habs

theorem evalIntExpr_val_bitLen_le {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore) :
    ∀ e : IntExpr,
      let r := evalIntExpr inp fd ws e
      1 ≤ r.2.1 ∧ 1 ≤ r.2.2 ∧ intBitLength r.1 ≤ r.2.2
  | .lit _ => ⟨le_rfl, intBitLength_pos _, le_rfl⟩
  | .dim => ⟨le_rfl, intBitLength_pos _, le_rfl⟩
  | .intParam e | .readHeap _ e | .readLocal _ e
  | .extraRatNum e | .extraRatDen e => by
      rcases h : evalIntExpr inp fd ws e with ⟨idx, u, b⟩
      simp only [evalIntExpr, h]
      have hb_idx := intBitLength_pos idx
      exact ⟨by omega, by omega, by omega⟩
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ => by
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [evalIntExpr, h1, h2]
      have hb1 := intBitLength_pos v₁
      exact ⟨by omega, by omega, by omega⟩
  | .neg e => by
      have ih := evalIntExpr_val_bitLen_le inp fd ws e
      rcases h : evalIntExpr inp fd ws e with ⟨v, u, b⟩
      simp only [h] at ih
      simp only [evalIntExpr, h, intBitLength_neg_eq]
      exact ⟨by omega, by omega, by omega⟩
  | .add e₁ e₂ => by
      have ih1 := evalIntExpr_val_bitLen_le inp fd ws e₁
      have ih2 := evalIntExpr_val_bitLen_le inp fd ws e₂
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [h1] at ih1; simp only [h2] at ih2
      simp only [evalIntExpr, h1, h2]
      have hadd := intBitLength_add_le v₁ v₂
      exact ⟨by omega, by omega, by omega⟩
  | .sub e₁ e₂ => by
      have ih1 := evalIntExpr_val_bitLen_le inp fd ws e₁
      have ih2 := evalIntExpr_val_bitLen_le inp fd ws e₂
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [h1] at ih1; simp only [h2] at ih2
      simp only [evalIntExpr, h1, h2]
      have hsub := intBitLength_sub_le v₁ v₂
      exact ⟨by omega, by omega, by omega⟩
  | .mul e₁ e₂ => by
      have ih1 := evalIntExpr_val_bitLen_le inp fd ws e₁
      have ih2 := evalIntExpr_val_bitLen_le inp fd ws e₂
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [h1] at ih1; simp only [h2] at ih2
      simp only [evalIntExpr, h1, h2]
      have hmul := intBitLength_mul_le v₁ v₂
      have hb1 := intBitLength_pos v₁
      have hb2 := intBitLength_pos v₂
      exact ⟨by omega, by nlinarith, by nlinarith⟩
  | .div e₁ e₂ => by
      have ih1 := evalIntExpr_val_bitLen_le inp fd ws e₁
      have ih2 := evalIntExpr_val_bitLen_le inp fd ws e₂
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [h1] at ih1; simp only [h2] at ih2
      simp only [evalIntExpr, h1, h2]
      have hdiv := intBitLength_ediv_le v₁ v₂
      have hb1 := intBitLength_pos v₁
      have hb2 := intBitLength_pos v₂
      exact ⟨by omega, by nlinarith, by nlinarith⟩
  | .mod e₁ e₂ => by
      have ih1 := evalIntExpr_val_bitLen_le inp fd ws e₁
      have ih2 := evalIntExpr_val_bitLen_le inp fd ws e₂
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [h1] at ih1; simp only [h2] at ih2
      simp only [evalIntExpr, h1, h2]
      have hb1 := intBitLength_pos v₁
      have hb2 := intBitLength_pos v₂
      have hmod_le : intBitLength (v₁ % v₂) ≤ intBitLength v₁ + intBitLength v₂ := by
        by_cases hv2 : v₂ = 0
        · subst hv2
          simp only [Int.emod_zero]
          have h0 : intBitLength 0 = 1 := by decide
          omega
        · have hm0 : 0 ≤ v₁ % v₂ := Int.emod_nonneg v₁ hv2
          have hm1 : v₁ % v₂ < (v₂.natAbs : ℤ) := Int.emod_lt v₁ hv2
          have habs : (v₁ % v₂).natAbs ≤ v₂.natAbs := by omega
          have hm := intBitLength_mono_natAbs habs
          omega
      exact ⟨by omega, by nlinarith, by nlinarith⟩

theorem encA2_inj {T_max : ℕ} {t₁ t₂ : ℕ} {idx₁ idx₂ : ℤ}
    (ht₁ : t₁ < T_max) (ht₂ : t₂ < T_max)
    (heq : idx₁ * (T_max : ℤ) + (t₁ : ℤ) = idx₂ * (T_max : ℤ) + (t₂ : ℤ)) :
    t₁ = t₂ ∧ idx₁ = idx₂ := by
  have ht₁z : (t₁ : ℤ) < (T_max : ℤ) := by exact_mod_cast ht₁
  have ht₂z : (t₂ : ℤ) < (T_max : ℤ) := by exact_mod_cast ht₂
  have hidx : idx₁ = idx₂ := by
    by_contra hne
    rcases lt_or_gt_of_ne hne with hlt | hgt
    · have hd1 : 1 ≤ idx₂ - idx₁ := by omega
      have : (T_max : ℤ) ≤ (idx₂ - idx₁) * (T_max : ℤ) := by nlinarith
      linarith
    · have hd1 : 1 ≤ idx₁ - idx₂ := by omega
      have : (T_max : ℤ) ≤ (idx₁ - idx₂) * (T_max : ℤ) := by nlinarith
      linarith
  subst hidx
  exact ⟨by omega, rfl⟩

theorem intBitLength_encA2_le {T_max t : ℕ} (ht : t < T_max) (idx : ℤ) :
    intBitLength (idx * (T_max : ℤ) + (t : ℤ)) ≤ intBitLength idx + natBitLength T_max + 4 := by
  have habs : (idx * (T_max : ℤ) + (t : ℤ)).natAbs ≤ (idx.natAbs + 1) * T_max := by
    have ha1 := Int.natAbs_add_le (idx * (T_max : ℤ)) (t : ℤ)
    rw [Int.natAbs_mul, Int.natAbs_natCast, Int.natAbs_natCast] at ha1
    nlinarith
  have hm := intBitLength_mono_natAbs (a := idx * (T_max : ℤ) + (t : ℤ))
    (b := (((idx.natAbs + 1) * T_max : ℕ) : ℤ)) (by rw [Int.natAbs_natCast]; exact habs)
  have ho := intBitLength_ofNat_le ((idx.natAbs + 1) * T_max)
  have hmul := natBitLength_mul_le (idx.natAbs + 1) T_max
  have hadd := natBitLength_add_le idx.natAbs 1
  have hn1 : natBitLength 1 = 1 := by decide
  rw [hn1] at hadd
  have hidx_ge : natBitLength idx.natAbs ≤ intBitLength idx := by
    unfold intBitLength
    split_ifs with hz
    · subst hz; decide
    · omega
  omega

/-! ### 2. Expression blowup factor and `trA2Expr` / `trA2Cond` evaluation -/

def a2ExprFactor : IntExpr → ℕ
  | .lit _ | .dim => 64
  | .intParam e | .readHeap _ e | .readLocal _ e
  | .extraRatNum e | .extraRatDen e | .neg e => 64 * a2ExprFactor e
  | .add e₁ e₂ | .sub e₁ e₂ | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ =>
      64 * (a2ExprFactor e₁ + a2ExprFactor e₂)
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ =>
      1024 * (a2ExprFactor e₁ + a2ExprFactor e₂)

def a2CondFactor : BitCondExpr → ℕ
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => 16 * (a2ExprFactor e₁ + a2ExprFactor e₂)
  | .not c => 16 * a2CondFactor c
  | .and c₁ c₂ | .or c₁ c₂ => 16 * (a2CondFactor c₁ + a2CondFactor c₂)

def a2StmtFactor : BitRAMStmt → ℕ
  | .skip => 64
  | .writeHeap _ e₁ e₂ | .writeLocal _ e₁ e₂ => 64 * (a2ExprFactor e₁ + a2ExprFactor e₂)
  | .freeHeap _ e | .freeLocal _ e | .randBitHeap _ e | .randBitLocal _ e => 64 * a2ExprFactor e
  | .repeatN e body => max (64 * a2ExprFactor e) (a2StmtFactor body)
  | .seq s₁ s₂ => max (a2StmtFactor s₁) (a2StmtFactor s₂)
  | .ite c s₁ s₂ => max (a2CondFactor c) (max (a2StmtFactor s₁) (a2StmtFactor s₂))
  | .whileLoop c body => max (a2CondFactor c) (a2StmtFactor body)
  | .localScope body => a2StmtFactor body

theorem a2ExprFactor_ge_64 : ∀ e : IntExpr, 64 ≤ a2ExprFactor e
  | .lit _ | .dim => le_rfl
  | .intParam e | .readHeap _ e | .readLocal _ e
  | .extraRatNum e | .extraRatDen e | .neg e => by
      have := a2ExprFactor_ge_64 e
      dsimp [a2ExprFactor]; omega
  | .add e₁ _ | .sub e₁ _ | .mul e₁ _ | .div e₁ _ | .mod e₁ _ => by
      have := a2ExprFactor_ge_64 e₁
      dsimp [a2ExprFactor]; omega
  | .activeRatNum e₁ _ | .activeRatDen e₁ _ => by
      have := a2ExprFactor_ge_64 e₁
      dsimp [a2ExprFactor]; omega

theorem a2CondFactor_pos : ∀ c : BitCondExpr, 64 ≤ a2CondFactor c
  | .intEq e₁ _ | .intLt e₁ _ | .intLe e₁ _ => by
      have := a2ExprFactor_ge_64 e₁
      dsimp [a2CondFactor]; omega
  | .not c => by
      have := a2CondFactor_pos c
      dsimp [a2CondFactor]; omega
  | .and c₁ _ | .or c₁ _ => by
      have := a2CondFactor_pos c₁
      dsimp [a2CondFactor]; omega

theorem a2StmtFactor_pos : ∀ s : BitRAMStmt, 64 ≤ a2StmtFactor s
  | .skip => le_rfl
  | .writeHeap _ e₁ _ | .writeLocal _ e₁ _ => by
      have := a2ExprFactor_ge_64 e₁
      dsimp [a2StmtFactor]; omega
  | .freeHeap _ e | .freeLocal _ e | .randBitHeap _ e | .randBitLocal _ e => by
      have := a2ExprFactor_ge_64 e
      dsimp [a2StmtFactor]; omega
  | .repeatN e _ => by
      have := a2ExprFactor_ge_64 e
      dsimp [a2StmtFactor]
      exact le_trans (by omega) (le_max_left _ _)
  | .seq s₁ _ => le_trans (a2StmtFactor_pos s₁) (le_max_left _ _)
  | .ite c _ _ => le_trans (a2CondFactor_pos c) (le_max_left _ _)
  | .whileLoop c _ => le_trans (a2CondFactor_pos c) (le_max_left _ _)
  | .localScope body => a2StmtFactor_pos body

def a2ParamBits (m d T_max : ℕ) : ℕ :=
  natBitLength m + natBitLength d + natBitLength T_max + 8

/-- Staging predicate for `inpSub` (`m` points in `ℚ^d` with parameter `B`) in `wsBase` tables `5, 6, 7`. -/
def StagingA2Matches {d : ℕ} (m B : ℕ) (wsBase : WordStore) (inpSub : BitRAMInput d) : Prop :=
  1 ≤ d ∧ 1 ≤ m ∧ 1 ≤ B ∧
  inpSub.intParams = [(m : ℤ), (B : ℤ)] ∧
  inpSub.activeHandles = Finset.range m ∧
  inpSub.extraRats = [] ∧
  (∀ idx : ℤ, wsBase.read (.heap 5 idx) = listGetIntD [(m : ℤ), (B : ℤ)] idx 0) ∧
  wsBase.read (.heap 6 0) = 0 ∧
  wsBase.read (.heap 7 0) = 0 ∧
  (∀ (h : ℕ) (hh : h < m) (c : Fin d),
    let addr : ℤ := ((h * d + c.val + 1 : ℕ) : ℤ)
    wsBase.read (.heap 6 addr) = (inpSub.activeRatCoords h c).num ∧
    wsBase.read (.heap 7 addr) + 1 = ((inpSub.activeRatCoords h c).den : ℤ))

/-- Read-agreement needed by `trA2Expr` and `trA2Cond`. -/
def AgreesForA2Expr (wsBase : WordStore) (T_max : ℕ)
    (wsSub : WordStore) (fdSub : ℕ) (wsSim : WordStore) : Prop :=
  (∀ t : ℕ, t < 10 → ∀ idx : ℤ, wsSim.read (.heap t idx) = wsBase.read (.heap t idx)) ∧
  (∀ t : ℕ, t < T_max → ∀ idx : ℤ,
    wsSim.read (.heap 10 (idx * (T_max : ℤ) + (t : ℤ))) = wsSub.read (.heap t idx)) ∧
  (∀ var : ℕ, ∀ idx : ℤ,
    wsSim.read (.localFrame (2 + fdSub) var idx) = wsSub.read (.localFrame fdSub var idx))

theorem eval_inRangeExpr {d : ℕ} (inpSim : BitRAMInput d) (fdSim : ℕ) (wsSim : WordStore)
    {xE NE : IntExpr} {x N : ℤ} {uX bX uN bN : ℕ}
    (hN : 1 ≤ N)
    (hx : evalIntExpr inpSim fdSim wsSim xE = (x, uX, bX))
    (hne : evalIntExpr inpSim fdSim wsSim NE = (N, uN, bN)) :
    ∃ uR bR : ℕ,
      evalIntExpr inpSim fdSim wsSim (inRangeExpr xE NE) =
        ((if 0 ≤ x ∧ x < N then 1 else 0), uR, bR) ∧
      uR = uX + uN + 7 ∧
      bR ≤ bX + bN + intBitLength x * intBitLength N + 12 * intBitLength x + 32 := by
  have hval := inRange_val_eq (x := x) hN
  have hq_bl : intBitLength (x / N) ≤ intBitLength x + 1 := intBitLength_ediv_le x N
  have h3 : intBitLength 3 = 3 := by decide
  have hl1 : intBitLength 1 = 2 := by decide
  have h3q_bl : intBitLength (3 * (x / N)) ≤ 3 + (intBitLength x + 1) := by
    have hm := intBitLength_mul_le 3 (x / N)
    omega
  have hadd_bl : intBitLength (3 * (x / N) + 1) ≤ intBitLength x + 8 := by
    have ha := intBitLength_add_le (3 * (x / N)) 1
    omega
  rcases hev : evalIntExpr inpSim fdSim wsSim (inRangeExpr xE NE) with ⟨vR, uR, bR⟩
  have hev' : (vR, uR, bR) =
      ((if 0 ≤ x ∧ x < N then 1 else 0),
       uX + uN + 1 + 1 + 1 + 1 + 1 + 1 + 1,
       intBitLength 1 +
         (intBitLength 3 + (bX + bN + intBitLength x * intBitLength N) +
           3 * intBitLength (x / N) + intBitLength 1 +
           intBitLength (3 * (x / N)) + intBitLength 1) +
         intBitLength 1 * intBitLength (3 * (x / N) + 1)) := by
    rw [← hev]
    simp only [inRangeExpr, evalIntExpr, hx, hne, hval, h3]
    ac_rfl
  rcases Prod.mk.inj hev' with ⟨hv, hub⟩
  rcases Prod.mk.inj hub with ⟨hu, hb⟩
  subst hv
  refine ⟨uR, bR, rfl, by omega, ?_⟩
  rw [hl1, h3] at hb
  omega

private lemma addr2d_bit_calc
    {bA bR1 bR2 bH bC bf1 bf2 bf12 bhd bhdc blin bm bd bhv bcv K : ℕ}
    (hK : 8 ≤ K) (hbH1 : 1 ≤ bhv) (hbC1 : 1 ≤ bcv)
    (hf1 : bf1 ≤ 2) (hf2 : bf2 ≤ 2) (hf12 : bf12 ≤ 2)
    (hmK : bm ≤ K) (hdK : bd ≤ K)
    (hhd : bhd ≤ bhv + K + 1)
    (hhdc : bhdc ≤ bhv + bcv + K + 2)
    (hlin : blin ≤ bhv + bcv + K + 5)
    (hbR1 : bR1 ≤ bH + (5 + bm) + bhv * bm + 12 * bhv + 32)
    (hbR2 : bR2 ≤ bC + bd + bcv * bd + 12 * bcv + 32)
    (hb : bR1 + bR2 + bf1 * bf2 + (bH + bd + bhv * bd + bC + bhd + bcv + 2 + bhdc + 2) + bf12 * blin = bA) :
    bA ≤ 2 * bH + 2 * bC + 16 * K * (bhv + bcv + 4) := by
  have h1 : bf1 * bf2 ≤ 4 := Nat.mul_le_mul hf1 hf2
  have h2 : bf12 * blin ≤ 2 * (bhv + bcv + K + 5) := Nat.mul_le_mul hf12 hlin
  have h3 : bhv * bm ≤ bhv * K := Nat.mul_le_mul_left bhv hmK
  have h4 : bcv * bd ≤ bcv * K := Nat.mul_le_mul_left bcv hdK
  have h5 : bhv * bd ≤ bhv * K := Nat.mul_le_mul_left bhv hdK
  have ha : 15 * bhv ≤ 2 * (bhv * K) := by
    calc 15 * bhv ≤ (2 * K) * bhv := Nat.mul_le_mul_right bhv (by linarith)
      _ = 2 * (bhv * K) := by ring
  have hb2 : 15 * bcv ≤ 2 * (bcv * K) := by
    calc 15 * bcv ≤ (2 * K) * bcv := Nat.mul_le_mul_right bcv (by linarith)
      _ = 2 * (bcv * K) := by ring
  have hdistr : 16 * K * (bhv + bcv + 4) = 16 * (bhv * K) + 16 * (bcv * K) + 64 * K := by ring
  linarith

theorem eval_addr2DA2 {d m B : ℕ} {wsBase : WordStore} {inpSub : BitRAMInput d}
    (hstage : StagingA2Matches m B wsBase inpSub)
    (inpSim : BitRAMInput d) (fdSim : ℕ) (wsSim : WordStore)
    (hag5 : ∀ idx : ℤ, wsSim.read (.heap 5 idx) = wsBase.read (.heap 5 idx))
    {hE cE : IntExpr} {hVal cVal : ℤ} {uH bH uC bC : ℕ}
    (hh : evalIntExpr inpSim fdSim wsSim hE = (hVal, uH, bH))
    (hc : evalIntExpr inpSim fdSim wsSim cE = (cVal, uC, bC)) :
    let addrVal : ℤ :=
      if 0 ≤ hVal ∧ hVal < (m : ℤ) ∧ 0 ≤ cVal ∧ cVal < (d : ℤ) then
        hVal * (d : ℤ) + cVal + 1
      else 0
    let K_p : ℕ := natBitLength m + natBitLength d + 8
    ∃ uA bA : ℕ,
      evalIntExpr inpSim fdSim wsSim (addr2DA2 hE cE) = (addrVal, uA, bA) ∧
      intBitLength addrVal ≤ K_p ∧
      uA ≤ 2 * uH + 2 * uC + 26 ∧
      bA ≤ 2 * bH + 2 * bC + 16 * K_p * (intBitLength hVal + intBitLength cVal + 4) := by
  intro addrVal K_p
  rcases hstage with ⟨hd1, hm1, _, _, _, _, hr5, _, _, _⟩
  have hmE : evalIntExpr inpSim fdSim wsSim (.readHeap 5 (.lit 0)) =
      ((m : ℤ), 2, intBitLength 0 + natBitLength 5 + intBitLength 0 + intBitLength (m : ℤ)) := by
    have hread : wsSim.read (.heap 5 0) = (m : ℤ) := by
      rw [hag5 0, hr5 0]; simp [listGetIntD]
    simp [evalIntExpr, hread]
  obtain ⟨uR1, bR1, hr1, huR1, hbR1⟩ :=
    eval_inRangeExpr inpSim fdSim wsSim (by omega : 1 ≤ (m : ℤ)) hh hmE
  have hdE : evalIntExpr inpSim fdSim wsSim .dim = ((d : ℤ), 1, intBitLength (d : ℤ)) := rfl
  obtain ⟨uR2, bR2, hr2, huR2, hbR2⟩ :=
    eval_inRangeExpr inpSim fdSim wsSim (by omega : 1 ≤ (d : ℤ)) hc hdE
  let f1 : ℤ := if 0 ≤ hVal ∧ hVal < (m : ℤ) then 1 else 0
  let f2 : ℤ := if 0 ≤ cVal ∧ cVal < (d : ℤ) then 1 else 0
  have hr1f : evalIntExpr inpSim fdSim wsSim (inRangeExpr hE (.readHeap 5 (.lit 0))) = (f1, uR1, bR1) := hr1
  have hr2f : evalIntExpr inpSim fdSim wsSim (inRangeExpr cE .dim) = (f2, uR2, bR2) := hr2
  have hf1_bl : intBitLength f1 ≤ 2 := by dsimp [f1]; split_ifs <;> decide
  have hf2_bl : intBitLength f2 ≤ 2 := by dsimp [f2]; split_ifs <;> decide
  have hf12_bl : intBitLength (f1 * f2) ≤ 2 := by
    dsimp [f1, f2]; split_ifs <;> decide
  have hm_bl : intBitLength (m : ℤ) ≤ natBitLength m + 1 := intBitLength_ofNat_le m
  have hd_bl : intBitLength (d : ℤ) ≤ natBitLength d + 1 := intBitLength_ofNat_le d
  have hhd_bl : intBitLength (hVal * (d : ℤ)) ≤ intBitLength hVal + natBitLength d + 1 := by
    have h1 := intBitLength_mul_le hVal (d : ℤ)
    omega
  have hhdc_bl : intBitLength (hVal * (d : ℤ) + cVal) ≤
      intBitLength hVal + intBitLength cVal + natBitLength d + 2 := by
    have h1 := intBitLength_add_le (hVal * (d : ℤ)) cVal
    omega
  have hlin_bl : intBitLength (hVal * (d : ℤ) + cVal + 1) ≤
      intBitLength hVal + intBitLength cVal + natBitLength d + 5 := by
    have h1 := intBitLength_add_le (hVal * (d : ℤ) + cVal) 1
    have hl1 : intBitLength 1 = 2 := by decide
    omega
  have hval_eq : (f1 * f2) * (hVal * (d : ℤ) + cVal + 1) = addrVal := by
    dsimp [f1, f2, addrVal]
    by_cases hh_in : 0 ≤ hVal ∧ hVal < (m : ℤ) <;> by_cases hc_in : 0 ≤ cVal ∧ cVal < (d : ℤ)
    · have hboth : 0 ≤ hVal ∧ hVal < (m : ℤ) ∧ 0 ≤ cVal ∧ cVal < (d : ℤ) :=
        ⟨hh_in.1, hh_in.2, hc_in.1, hc_in.2⟩
      simp [hh_in, hc_in]
    · have hnb : ¬ (0 ≤ hVal ∧ hVal < (m : ℤ) ∧ 0 ≤ cVal ∧ cVal < (d : ℤ)) := by tauto
      simp [hh_in, hc_in]
    · have hnb : ¬ (0 ≤ hVal ∧ hVal < (m : ℤ) ∧ 0 ≤ cVal ∧ cVal < (d : ℤ)) := by tauto
      simp [hh_in, hc_in]
    · have hnb : ¬ (0 ≤ hVal ∧ hVal < (m : ℤ) ∧ 0 ≤ cVal ∧ cVal < (d : ℤ)) := by tauto
      simp [hh_in, hc_in]
  have haddr_bl : intBitLength addrVal ≤ K_p := by
    dsimp [addrVal, K_p]
    split_ifs with hin
    · rcases hin with ⟨hh0, hhm, hc0, hcd⟩
      have hlt_m : hVal.toNat + 1 ≤ m := by omega
      have hlt_d : cVal.toNat + 1 ≤ d := by omega
      have hprod_lt : hVal.toNat * d + cVal.toNat + 1 ≤ m * d := by nlinarith
      have hh_cast : (hVal.toNat : ℤ) = hVal := Int.toNat_of_nonneg hh0
      have hc_cast : (cVal.toNat : ℤ) = cVal := Int.toNat_of_nonneg hc0
      have heq_nat : ((hVal.toNat * d + cVal.toNat + 1 : ℕ) : ℤ) = hVal * (d : ℤ) + cVal + 1 := by
        push_cast
        rw [hh_cast, hc_cast]
      rw [← heq_nat]
      have h1 := intBitLength_ofNat_le (hVal.toNat * d + cVal.toNat + 1)
      have h2 := natBitLength_mono hprod_lt
      have h3 := natBitLength_mul_le m d
      omega
    · have hl0 : intBitLength 0 = 1 := by decide
      omega
  have hl0 : intBitLength 0 = 1 := by decide
  have hl1 : intBitLength 1 = 2 := by decide
  have hn5 : natBitLength 5 = 3 := by decide
  rw [hl0, hn5] at hbR1
  have hK_ge : 8 ≤ K_p := by dsimp [K_p]; clear hh hc hr1 hr2 hr5 hag5 hval_eq hmE hdE; omega
  have hm_le_K : intBitLength (m : ℤ) ≤ K_p := by dsimp [K_p]; clear hh hc hr1 hr2 hr5 hag5 hval_eq hmE hdE; omega
  have hd_le_K : intBitLength (d : ℤ) ≤ K_p := by dsimp [K_p]; clear hh hc hr1 hr2 hr5 hag5 hval_eq hmE hdE; omega
  have hn_d_le_K : natBitLength d ≤ K_p := by dsimp [K_p]; clear hh hc hr1 hr2 hr5 hag5 hval_eq hmE hdE; omega
  have hbH1 : 1 ≤ intBitLength hVal := intBitLength_pos hVal
  have hbC1 : 1 ≤ intBitLength cVal := intBitLength_pos cVal
  have hhd_K : intBitLength (hVal * (d : ℤ)) ≤ intBitLength hVal + K_p + 1 :=
    le_trans hhd_bl (Nat.add_le_add_right (Nat.add_le_add_left hn_d_le_K _) 1)
  have hhdc_K : intBitLength (hVal * (d : ℤ) + cVal) ≤ intBitLength hVal + intBitLength cVal + K_p + 2 :=
    le_trans hhdc_bl (Nat.add_le_add_right (Nat.add_le_add_left hn_d_le_K _) 2)
  have hlin_K : intBitLength (hVal * (d : ℤ) + cVal + 1) ≤ intBitLength hVal + intBitLength cVal + K_p + 5 :=
    le_trans hlin_bl (Nat.add_le_add_right (Nat.add_le_add_left hn_d_le_K _) 5)
  have hbR1' : bR1 ≤ bH + (5 + intBitLength (m : ℤ)) + intBitLength hVal * intBitLength (m : ℤ) + 12 * intBitLength hVal + 32 := by
    simpa [Nat.add_assoc] using hbR1
  have heval_eq : evalIntExpr inpSim fdSim wsSim (addr2DA2 hE cE) =
      (addrVal,
       uR1 + uR2 + 1 + (uH + 1 + 1 + uC + 1 + 1 + 1) + 1,
       bR1 + bR2 + intBitLength f1 * intBitLength f2 +
         (bH + intBitLength (d : ℤ) + intBitLength hVal * intBitLength (d : ℤ) +
          bC + intBitLength (hVal * (d : ℤ)) + intBitLength cVal +
          2 + intBitLength (hVal * (d : ℤ) + cVal) + 2) +
         intBitLength (f1 * f2) * intBitLength (hVal * (d : ℤ) + cVal + 1)) := by
    unfold addr2DA2
    dsimp only
    generalize inRangeExpr hE (.readHeap 5 (.lit 0)) = ir1 at hr1f ⊢
    generalize inRangeExpr cE .dim = ir2 at hr2f ⊢
    simp only [evalIntExpr, hr1f, hr2f, hh, hc, hval_eq, hl1]
  have hu_le : uR1 + uR2 + 1 + (uH + 1 + 1 + uC + 1 + 1 + 1) + 1 ≤ 2 * uH + 2 * uC + 26 := by
    rw [huR1, huR2]
    linarith
  refine ⟨_, _, heval_eq, haddr_bl, hu_le,
    addr2d_bit_calc hK_ge hbH1 hbC1 hf1_bl hf2_bl hf12_bl hm_le_K hd_le_K
      hhd_K hhdc_K hlin_K hbR1' hbR2 rfl⟩


end UL.C12LVE
