import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2e0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL.C12LVE
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### 1. Post-A.2 Stage (`clearStageA2Regs ; buildTab4Regs ; buildIntactTreeRegs ; buildSjTreeAndResidualBufRegs ; incJFromHeap0Regs`) -/

def c07StepC2PostA2Regs (d s₀_d L : ℕ) (jSrc : JSource) : BitRAMStmt :=
  .seq (clearStageA2Regs d)
  (.seq (buildTab4Regs d s₀_d L)
  (.seq (buildIntactTreeRegs d L)
  (.seq (buildSjTreeAndResidualBufRegs d L)
        (incJFromHeap0Regs jSrc))))

theorem fin_univ_image_val_eq_range (k : ℕ) :
    (Finset.univ : Finset (Fin k)).image Fin.val = Finset.range k := by
  ext x
  simp only [Finset.mem_image, Finset.mem_univ, true_and, Finset.mem_range]
  exact ⟨fun ⟨i, hi⟩ => hi ▸ i.isLt, fun hx => ⟨⟨x, hx⟩, rfl⟩⟩

theorem exec_c07StepC2PostA2Regs {d s₀_d n L B B_cert K_max W j m k_blk : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    (hj_lt : j < K_max)
    (hm_n : m ≤ n) (hk1 : 1 ≤ k_blk) (hk_le : k_blk * s₀_d ≤ m)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength (s₀_d + 1) + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {C_cell C_bit : ℕ}
    {S_act S_H : Finset ℕ} {qMap' : ℕ → Fin d → ℚ}
    {oRat : Fin d → ℚ} {V_num V_den : ℤ} {V : ℝ}
    {bh : Fin k_blk → Fin s₀_d → ℕ}
    (hbh_lt : ∀ b t, bh b t < 2 ^ L)
    (hbh_inj : Function.Injective2 bh)
    (hcard_SH : S_H.card = m)
    (hmin_mem_act : ∀ k < m, minPopElem S_H k ∈ S_act)
    {wsExt : WordStore} {regsExt : ℕ → ℤ} {jSrc : JSource}
    (hj_val : JSourceValid jSrc)
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsExt)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hbnd : RegBounded W regsExt)
    (hr010 : wsExt.read (.heap 0 10) = (j : ℤ))
    (hr50 : wsExt.read (.heap 5 0) = (m : ℤ))
    (hr110 : wsExt.read (.heap 9 110) = (m : ℤ))
    (hbuf : ∀ k < m, wsExt.read (.heap 8 (k : ℤ)) = (minPopElem S_H k : ℤ))
    (hclean8 : ∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsExt.live)
    (htree1 : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsExt)
    (hlive567 : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ,
      (.heap t z : RAMCellLoc) ∈ wsExt.live → (.heap t z : RAMCellLoc) ∈ stageA2Locs d m)
    (hheap9_bnd : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ wsExt.live → ∃ k : ℕ, k < 256 ∧ z = (k : ℤ))
    (hcoords : ActiveCoordsStored d L B S_act qMap' wsExt)
    (hgeom : NodeGeomStored d (posNodeStride d L) B_cert j oRat V_num V_den V wsExt)
    (hr_kb : wsExt.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (k_blk : ℤ))
    (hread_bh : ∀ (b : Fin k_blk) (t : Fin s₀_d),
      wsExt.read (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b.val * s₀_d + t.val)))) =
        (bh b t : ℤ))
    (hemp4 : ∀ h < 2 ^ L, (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ wsExt.live)
    (htree2_emp : TreeStoredAt L (2 * j + 2) ∅ (fun _ => 0) (fun _ => 1) wsExt)
    (htree3_emp : TreeStoredAt L (2 * j + 3) ∅ (fun _ => 0) (fun _ => 1) wsExt) :
    let S_res_H := S_H.filter (fun h => isResHandlePred qMap' oRat V h = true)
    ∃ wsPost regsPost,
      RegExec inp 1 W C_cell C_bit (c07StepC2PostA2Regs d s₀_d L jSrc) wsExt regsExt wsPost regsPost
        ((m + 1) * (260 * d + 1540 * L + 1300) + 1000)
        (((m + 1) * (72 * d + 258 * L + 340) + 450) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsPost ∧
      RegBounded W regsPost ∧
      JSourceHolds jSrc (j + 1) wsPost regsPost ∧
      wsPost.read (.heap 0 10) = (((j + 1 : ℕ) : ℤ)) ∧
      wsPost.read (.heap 9 110) = (S_res_H.card : ℤ) ∧
      (∃ hSeq' : ℕ → ℕ,
        (∀ k < S_res_H.card, hSeq' k < 2 ^ L ∧ wsPost.read (.heap 8 (k : ℤ)) = (hSeq' k : ℤ)) ∧
        (Finset.range S_res_H.card).image hSeq' = S_res_H) ∧
      (∀ z : ℤ, (∀ k < S_res_H.card, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsPost.live) ∧
      TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsPost ∧
      (∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsPost.live) ∧
      (∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ wsPost.live → ∃ k : ℕ, k < 256 ∧ z = (k : ℤ)) ∧
      (∀ h < 2 ^ L,
        (∃ (b : Fin k_blk) (t : Fin s₀_d),
          bh b t = h ∧
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ wsPost.live ∧
          wsPost.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) = ((b.val + 1 : ℕ) : ℤ)) ∨
        ((∀ (b : Fin k_blk) (t : Fin s₀_d), bh b t ≠ h) ∧
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ wsPost.live)) ∧
      TreeStoredAt L (2 * j + 3) (Finset.range k_blk) (fun _ => 0) (fun _ => 1) wsPost ∧
      (∃ (rNum rDen : ℕ → ℤ),
        TreeStoredAt L (2 * j + 2) S_H rNum rDen wsPost ∧
        (∀ h ∈ S_H,
          1 ≤ rDen h ∧
          ((rNum h : ℝ) / (rDen h : ℝ)) =
            ‖ratPointToEuclidean (qMap' h) - ratPointToEuclidean oRat‖ ^ 2 ∧
          intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧
          intBitLength (rDen h) ≤ sqRadBitBound d B B_cert)) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .heap 0 10 →
        loc ∉ stageA2Locs d m →
        (∀ h < 2 ^ L, loc ≠ .heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) →
        loc ∉ treeSliceLocs L (2 * j + 3) →
        loc ∉ treeSliceLocs L (2 * j + 2) →
        loc ∉ treeSliceLocs L 1 →
        (∀ z : ℤ, loc ≠ .heap 8 z) →
        (∀ z : ℤ, loc ≠ .heap 9 z) →
        (loc ∈ wsPost.live ↔ loc ∈ wsExt.live) ∧ wsPost.vals loc = wsExt.vals loc) := by
  dsimp only
  set S_res_H := S_H.filter (fun h => isResHandlePred qMap' oRat V h = true)
  obtain ⟨hL2, _, h2n_pow, _⟩ := clog_two_mul_bounds hn
  rw [← hL] at hL2 h2n_pow
  have hL1 : 1 ≤ L := by omega
  have hm_pow : m ≤ 2 ^ L := by omega
  have hm_lt_pow : m < 2 ^ L := by omega
  have hk_le_m : k_blk ≤ m := le_trans (Nat.le_mul_of_pos_right k_blk hs₀1) hk_le
  have hk_lt_pow : k_blk < 2 ^ L := lt_of_le_of_lt hk_le_m hm_lt_pow
  have hk_s0_pow : k_blk * s₀_d ≤ 2 ^ L := le_trans hk_le hm_pow
  have hj_le : j ≤ K_max := Nat.le_of_lt hj_lt
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hWW : 40 * W ≤ W * W := by nlinarith only [hW40]
  -- 1. clearStageA2Regs
  obtain ⟨wsU, regsU, sU, hmU, brU, hclean567_U, hunchU⟩ :=
    exec_clearStageA2Regs hd1 hm_pow (by clear * - hW; omega) (by decide : 1 ≤ 4)
      hmod hcCeil hbCeil hbnd hr50 hlive567
  have hr010_U : wsU.read (.heap 0 10) = (j : ℤ) :=
    (wordStore_read_eq_of_live_vals (hunchU _ (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide)))).trans hr010
  have hr_kb_U : wsU.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (k_blk : ℤ) :=
    (wordStore_read_eq_of_live_vals (hunchU _ (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide)))).trans hr_kb
  have hread_bh_U : ∀ (b : Fin k_blk) (t : Fin s₀_d),
      wsU.read (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b.val * s₀_d + t.val)))) = (bh b t : ℤ) :=
    fun b t => (wordStore_read_eq_of_live_vals (hunchU _ (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide)))).trans (hread_bh b t)
  have hemp4_U : ∀ h < 2 ^ L, (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ wsU.live := fun h hh => by
    rw [(hunchU (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))).1]
    exact hemp4 h hh
  -- 2. buildTab4Regs
  obtain ⟨wsT4, regsT4, sT4, hmT4, brT4, htab4_T4, hunchT4⟩ :=
    exec_buildTab4Regs hd1 hs₀1 (by decide : 1 ≤ 4) hj_le hk_s0_pow (by clear * - hW; omega)
      hmU hcCeil hbCeil hemp4_U hr010_U hr_kb_U hbh_lt hbh_inj hread_bh_U brU
  have not_tab4 : ∀ {t : ℕ} (ht : t ≠ 4) (z : ℤ) (h : ℕ), h < 2 ^ L →
      (.heap t z : RAMCellLoc) ≠ .heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) := by
    intro t ht z _ _ hc; injection hc with e; exact ht e
  have hr010_T4 : wsT4.read (.heap 0 10) = (j : ℤ) :=
    (wordStore_read_eq_of_live_vals (hunchT4 _ (not_tab4 (by decide) _))).trans hr010_U
  have hr_kb_T4 : wsT4.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (k_blk : ℤ) :=
    (wordStore_read_eq_of_live_vals (hunchT4 _ (not_tab4 (by decide) _))).trans hr_kb_U
  have htree3_T4 : TreeStoredAt L (2 * j + 3) ∅ (fun _ => 0) (fun _ => 1) wsT4 :=
    htree3_emp.unchanged (fun u _ f _ =>
      let u1 := hunchT4 (.heap 2 (treeCellAddr L (2 * j + 3) u f)) (not_tab4 (by decide) _)
      let u0 := hunchU (.heap 2 (treeCellAddr L (2 * j + 3) u f)) (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
      ⟨u1.1.trans u0.1, u1.2.trans u0.2⟩)
  -- 3. buildIntactTreeRegs
  obtain ⟨wsInt, regsInt, sInt, hmInt, brInt, htree3_Int, hn113_Int, hn114_Int, hunchInt⟩ :=
    exec_buildIntactTreeRegs hd1 (by decide : 1 ≤ 4) hL1 hj_le hk_lt_pow (by clear * - hW; omega)
      hmT4 hcCeil hbCeil htree3_T4 hr010_T4 hr_kb_T4 brT4
  have unch_Ext_to_Int_non245679 : ∀ {t : ℕ} (z : ℤ),
      t ≠ 2 → t ≠ 4 → t ≠ 5 → t ≠ 6 → t ≠ 7 → t ≠ 9 →
      ((.heap t z : RAMCellLoc) ∈ wsInt.live ↔ (.heap t z : RAMCellLoc) ∈ wsExt.live) ∧
      wsInt.vals (.heap t z) = wsExt.vals (.heap t z) := by
    intro t z n2 n4 n5 n6 n7 n9
    have uI := hunchInt (.heap t z) (not_mem_treeSliceLocs_of_ne_tab n2)
      (fun h => by injection h with e; exact n9 e)
      (fun h => by injection h with e; exact n9 e)
    have uT := hunchT4 (.heap t z) (not_tab4 n4 z)
    have uU := hunchU (.heap t z) (not_mem_stageA2Locs_of_ne_tab n5 n6 n7)
    exact ⟨uI.1.trans (uT.1.trans uU.1), uI.2.trans (uT.2.trans uU.2)⟩
  have hr010_Int : wsInt.read (.heap 0 10) = (j : ℤ) :=
    (wordStore_read_eq_of_live_vals (unch_Ext_to_Int_non245679 10 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))).trans hr010
  have hr110_Int : wsInt.read (.heap 9 110) = (m : ℤ) := by
    have uI := hunchInt (.heap 9 110) (not_mem_treeSliceLocs_of_ne_tab (by decide)) (by decide) (by decide)
    have uT := hunchT4 (.heap 9 110) (not_tab4 (by decide) 110)
    have uU := hunchU (.heap 9 110) (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
    exact (wordStore_read_eq_of_live_vals ⟨uI.1.trans (uT.1.trans uU.1), uI.2.trans (uT.2.trans uU.2)⟩).trans hr110
  have hbuf_Int : ∀ k < m, wsInt.read (.heap 8 (k : ℤ)) = (minPopElem S_H k : ℤ) := fun k hk =>
    (wordStore_read_eq_of_live_vals (unch_Ext_to_Int_non245679 (k : ℤ) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))).trans (hbuf k hk)
  have hclean8_Int : ∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsInt.live := fun z hz => by
    rw [(unch_Ext_to_Int_non245679 z (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)).1]
    exact hclean8 z hz
  have hcoords_Int : ActiveCoordsStored d L B S_act qMap' wsInt :=
    hcoords.unchanged (fun _ _ _ _ _ _ =>
      wordStore_read_eq_of_live_vals (unch_Ext_to_Int_non245679 _ (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)))
  have hgeom_Int : NodeGeomStored d (posNodeStride d L) B_cert j oRat V_num V_den V wsInt :=
    hgeom.unchanged (fun _ _ =>
      wordStore_read_eq_of_live_vals (unch_Ext_to_Int_non245679 _ (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)))
  have htree2_Int : TreeStoredAt L (2 * j + 2) ∅ (fun _ => 0) (fun _ => 1) wsInt :=
    htree2_emp.unchanged (fun u hu f hf =>
      let uI := hunchInt (.heap 2 (treeCellAddr L (2 * j + 2) u f)) (not_mem_treeSliceLocs_of_ne (by omega) hu hf) (fun h => by cases h) (fun h => by cases h)
      let uT := hunchT4 (.heap 2 (treeCellAddr L (2 * j + 2) u f)) (not_tab4 (by decide) _)
      let uU := hunchU (.heap 2 (treeCellAddr L (2 * j + 2) u f)) (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
      ⟨uI.1.trans (uT.1.trans uU.1), uI.2.trans (uT.2.trans uU.2)⟩)
  have htree1_Int : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsInt :=
    htree1.unchanged (fun u hu f hf =>
      let uI := hunchInt (.heap 2 (treeCellAddr L 1 u f)) (not_mem_treeSliceLocs_of_ne (by omega) hu hf) (fun h => by cases h) (fun h => by cases h)
      let uT := hunchT4 (.heap 2 (treeCellAddr L 1 u f)) (not_tab4 (by decide) _)
      let uU := hunchU (.heap 2 (treeCellAddr L 1 u f)) (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
      ⟨uI.1.trans (uT.1.trans uU.1), uI.2.trans (uT.2.trans uU.2)⟩)
  -- 4. buildSjTreeAndResidualBufRegs
  obtain ⟨wsSj, regsSj, sSj, hmSj, brSj, htreeSj_Sj, htree1_Sj, hr010_Sj, hr110_Sj_raw,
    hbuf_Sj_raw, hclean8_Sj_raw, hheap9_Sj, hunchSj⟩ :=
    exec_buildSjTreeAndResidualBufRegs hd1 (by decide : 1 ≤ 4) hL1 hB1 hBc1 hj_le hm_pow
      (by clear * - hW; omega) hmInt hcCeil hbCeil htree2_Int htree1_Int hr010_Int hr110_Int
      hbuf_Int hclean8_Int hmin_mem_act hcoords_Int hgeom_Int brInt
  have himg_min : (Finset.range m).image (minPopElem S_H) = S_H := by
    rw [← hcard_SH]; exact image_minPopElem_eq S_H
  rw [himg_min] at htreeSj_Sj hr110_Sj_raw hbuf_Sj_raw hclean8_Sj_raw
  -- 5. incJFromHeap0Regs
  have hj_bl : intBitLength (j : ℤ) ≤ W := by
    have hns_pos : 0 < posNodeStride d L := by unfold posNodeStride; have := Nat.zero_le (2 ^ L); omega
    have hj1 : j ≤ K_max + 1 := by omega
    have hj_le_mul : j ≤ j * posNodeStride d L + 0 := by have := Nat.le_mul_of_pos_right j hns_pos; omega
    have hW_node : natBitLength ((K_max + 2) * posNodeStride d L) + 8 ≤ W := by clear * - hW; omega
    exact (intBitLength_natCast_mono hj_le_mul).trans (nodeCellAddr_bl (W := W) hj1 hns_pos hW_node).2
  have hj1_bl : intBitLength (((j + 1 : ℕ) : ℤ)) ≤ W := by
    have hns_pos : 0 < posNodeStride d L := by unfold posNodeStride; have := Nat.zero_le (2 ^ L); omega
    have hj1 : j + 1 ≤ K_max + 1 := by omega
    have hj1_le_mul : j + 1 ≤ (j + 1) * posNodeStride d L + 0 := by have := Nat.le_mul_of_pos_right (j + 1) hns_pos; omega
    have hW_node : natBitLength ((K_max + 2) * posNodeStride d L) + 8 ≤ W := by clear * - hW; omega
    exact (intBitLength_natCast_mono hj1_le_mul).trans (nodeCellAddr_bl (W := W) hj1 hns_pos hW_node).2
  obtain ⟨wsPost, regsPost, sInc, hmPost, brPost, hr010_Post, hjHolds_Post, hunchInc⟩ :=
    exec_incJFromHeap0Regs (by decide : 1 ≤ 4) (by omega) hj_bl hj1_bl hmSj hcCeil hbCeil
      hr010_Sj hj_val brSj
  have hr110_Post : wsPost.read (.heap 9 110) = (S_res_H.card : ℤ) := by
    have uInc := hunchInc (.heap 9 110) (by decide) (fun addr hSrc => by
      subst hSrc; rcases hj_val with ⟨_, hne110⟩
      intro hc; injection hc with _ ha; exact hne110 (Int.ofNat.inj ha).symm)
    exact (wordStore_read_eq_of_live_vals uInc).trans hr110_Sj_raw
  obtain ⟨hSeq', hhSeq'_spec, hhSeq'_img⟩ := hbuf_Sj_raw
  have hbuf_Post : ∀ k < S_res_H.card, hSeq' k < 2 ^ L ∧ wsPost.read (.heap 8 (k : ℤ)) = (hSeq' k : ℤ) := by
    intro k hk
    obtain ⟨hlt, hrd⟩ := hhSeq'_spec k hk
    have uInc := hunchInc (.heap 8 (k : ℤ)) (fun h => by cases h) (fun _ _ h => by cases h)
    exact ⟨hlt, (wordStore_read_eq_of_live_vals uInc).trans hrd⟩
  have hclean8_Post : ∀ z : ℤ, (∀ k < S_res_H.card, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsPost.live := by
    intro z hz
    rw [(hunchInc (.heap 8 z) (fun h => by cases h) (fun _ _ h => by cases h)).1]
    exact hclean8_Sj_raw z hz
  have htree1_Post : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsPost :=
    htree1_Sj.unchanged (fun u _ f _ => hunchInc (.heap 2 (treeCellAddr L 1 u f)) (fun h => by cases h) (fun _ _ h => by cases h))
  have hclean567_Post : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsPost.live := by
    intro t ht z
    have hnt0 : t ≠ 0 := by rcases ht with rfl | rfl | rfl <;> decide
    have hnt2 : t ≠ 2 := by rcases ht with rfl | rfl | rfl <;> decide
    have hnt4 : t ≠ 4 := by rcases ht with rfl | rfl | rfl <;> decide
    have hnt8 : t ≠ 8 := by rcases ht with rfl | rfl | rfl <;> decide
    have hnt9 : t ≠ 9 := by rcases ht with rfl | rfl | rfl <;> decide
    have uInc := hunchInc (.heap t z) (fun h => by injection h with e; exact hnt0 e)
      (fun _ _ h => by injection h with e; exact hnt9 e)
    have uSj := hunchSj (.heap t z) (fun h => by injection h with e; exact hnt0 e)
      (not_mem_treeSliceLocs_of_ne_tab hnt2) (not_mem_treeSliceLocs_of_ne_tab hnt2)
      (fun _ h => by injection h with e; exact hnt8 e)
      (fun h => by injection h with e; exact hnt9 e) (fun h => by injection h with e; exact hnt9 e)
      (fun h => by injection h with e; exact hnt9 e) (fun h => by injection h with e; exact hnt9 e)
      (fun h => by injection h with e; exact hnt9 e) (fun h => by injection h with e; exact hnt9 e)
      (fun h => by injection h with e; exact hnt9 e)
    have uI := hunchInt (.heap t z) (not_mem_treeSliceLocs_of_ne_tab hnt2)
      (fun h => by injection h with e; exact hnt9 e) (fun h => by injection h with e; exact hnt9 e)
    have uT := hunchT4 (.heap t z) (not_tab4 hnt4 z)
    rw [uInc.1, uSj.1, uI.1, uT.1]
    exact hclean567_U t ht z
  have hheap9_Post : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ wsPost.live → ∃ k : ℕ, k < 256 ∧ z = (k : ℤ) := by
    intro z hmP
    by_cases hJ9 : ∃ addr : ℕ, jSrc = .heap9 addr ∧ z = (addr : ℤ)
    · rcases hJ9 with ⟨addr, hSrc, rfl⟩
      subst hSrc; exact ⟨addr, hj_val.1, rfl⟩
    · push_neg at hJ9
      have hmSj_z := (hunchInc (.heap 9 z) (fun h => by cases h)
        (fun addr hSrc hc => hJ9 addr hSrc (by injection hc))).1.mp hmP
      rcases hheap9_Sj z hmSj_z with rfl | hmInt_z
      · exact ⟨110, by decide, rfl⟩
      · have n113 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 113 := fun h => hn113_Int (h ▸ hmInt_z)
        have n114 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 114 := fun h => hn114_Int (h ▸ hmInt_z)
        have hmT4_z := (hunchInt (.heap 9 z) (not_mem_treeSliceLocs_of_ne_tab (by decide)) n113 n114).1.mp hmInt_z
        have hmU_z := (hunchT4 (.heap 9 z) (not_tab4 (by decide) z)).1.mp hmT4_z
        have hmExt_z := (hunchU (.heap 9 z) (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))).1.mp hmU_z
        exact hheap9_bnd z hmExt_z
  have htab4_Post : ∀ h < 2 ^ L,
      (∃ (b : Fin k_blk) (t : Fin s₀_d),
        bh b t = h ∧
        (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ wsPost.live ∧
        wsPost.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) = ((b.val + 1 : ℕ) : ℤ)) ∨
      ((∀ (b : Fin k_blk) (t : Fin s₀_d), bh b t ≠ h) ∧
        (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ wsPost.live) := by
    intro h hh
    have uInc := hunchInc (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) (fun hc => by cases hc) (fun _ _ hc => by cases hc)
    have uSj := hunchSj (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) (fun hc => by cases hc)
      (not_mem_treeSliceLocs_of_ne_tab (by decide)) (not_mem_treeSliceLocs_of_ne_tab (by decide))
      (fun _ hc => by cases hc) (fun hc => by cases hc) (fun hc => by cases hc)
      (fun hc => by cases hc) (fun hc => by cases hc) (fun hc => by cases hc)
      (fun hc => by cases hc) (fun hc => by cases hc)
    have uI := hunchInt (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) (not_mem_treeSliceLocs_of_ne_tab (by decide))
      (fun hc => by cases hc) (fun hc => by cases hc)
    have ulive : (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ wsPost.live ↔ (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ wsT4.live := uInc.1.trans (uSj.1.trans uI.1)
    have uvals : wsPost.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) = wsT4.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) := uInc.2.trans (uSj.2.trans uI.2)
    rcases htab4_T4 h hh with ⟨b, t, heq, hml, hvl⟩ | ⟨hne, hnl⟩
    · exact Or.inl ⟨b, t, heq, ulive.mpr hml, uvals.trans hvl⟩
    · exact Or.inr ⟨hne, fun hmp => hnl (ulive.mp hmp)⟩
  have htree3_Post : TreeStoredAt L (2 * j + 3) (Finset.range k_blk) (fun _ => 0) (fun _ => 1) wsPost :=
    htree3_Int.unchanged (fun u hu f hf =>
      let uInc := hunchInc (.heap 2 (treeCellAddr L (2 * j + 3) u f)) (fun hc => by cases hc) (fun _ _ hc => by cases hc)
      let uSj := hunchSj (.heap 2 (treeCellAddr L (2 * j + 3) u f)) (fun hc => by cases hc)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf)
        (not_mem_treeSliceLocs_of_ne (by omega) hu hf)
        (fun _ hc => by cases hc) (fun hc => by cases hc) (fun hc => by cases hc)
        (fun hc => by cases hc) (fun hc => by cases hc) (fun hc => by cases hc)
        (fun hc => by cases hc) (fun hc => by cases hc)
      ⟨uInc.1.trans uSj.1, uInc.2.trans uSj.2⟩)
  obtain ⟨rNum, rDen, htreeSj_raw, hrBnds_Sj⟩ := htreeSj_Sj
  have htreeSj_Post : TreeStoredAt L (2 * j + 2) S_H rNum rDen wsPost :=
    htreeSj_raw.unchanged (fun u _ f _ =>
      hunchInc (.heap 2 (treeCellAddr L (2 * j + 2) u f)) (fun hc => by cases hc) (fun _ _ hc => by cases hc))
  have hExecPost : RegExec inp 1 W C_cell C_bit (c07StepC2PostA2Regs d s₀_d L jSrc) wsExt regsExt wsPost regsPost
      ((m + 1) * (260 * d + 1540 * L + 1300) + 1000)
      (((m + 1) * (72 * d + 258 * L + 340) + 450) * W * W) := by
    refine (sU.seq (sT4.seq (sInt.seq (sSj.seq sInc)))).weaken rfl rfl ?_ ?_
    · have ht4_u : k_blk * (32 * s₀_d + 16) ≤ 48 * m := by
        have h1 : k_blk * (32 * s₀_d + 16) = 32 * (k_blk * s₀_d) + 16 * k_blk := by ring
        clear * - h1 hk_le hk_le_m; omega
      have hint_u : (k_blk + 1) * (360 * L + 240) ≤ (m + 1) * (360 * L + 240) :=
        Nat.mul_le_mul_right _ (by omega)
      clear * - ht4_u hint_u; nlinarith
    · have ht4_c : k_blk * (28 * s₀_d + 12) ≤ 40 * m := by
        have h1 : k_blk * (28 * s₀_d + 12) = 28 * (k_blk * s₀_d) + 12 * k_blk := by ring
        clear * - h1 hk_le hk_le_m; omega
      have hinc_b : 40 * W + 160 ≤ 50 * W * W := by
        calc 40 * W + 160 ≤ 50 * (40 * W) := by clear * - hW40; omega
        _ ≤ 50 * (W * W) := Nat.mul_le_mul_left 50 hWW
        _ = 50 * W * W := by ring
      have hmain_b : (16 * m * d + 20) * W * W +
          (k_blk * (28 * s₀_d + 12) + 80) * W * W +
          ((k_blk + 1) * (58 * L + 60) * W * W + 100 * W * W) +
          ((m + 1) * (56 * d + 200 * L + 240) * W * W + 200 * W * W) +
          50 * W * W ≤
          ((m + 1) * (72 * d + 258 * L + 340) + 450) * W * W := by
        have hcoef : (16 * m * d + 20) + (k_blk * (28 * s₀_d + 12) + 80) +
            ((k_blk + 1) * (58 * L + 60) + 100) +
            ((m + 1) * (56 * d + 200 * L + 240) + 200) + 50 ≤
            (m + 1) * (72 * d + 258 * L + 340) + 450 := by
          have hint_c : (k_blk + 1) * (58 * L + 60) ≤ (m + 1) * (58 * L + 60) :=
            Nat.mul_le_mul_right _ (by omega)
          clear * - ht4_c hint_c; nlinarith
        calc (16 * m * d + 20) * W * W +
              (k_blk * (28 * s₀_d + 12) + 80) * W * W +
              ((k_blk + 1) * (58 * L + 60) * W * W + 100 * W * W) +
              ((m + 1) * (56 * d + 200 * L + 240) * W * W + 200 * W * W) +
              50 * W * W
          _ = ((16 * m * d + 20) + (k_blk * (28 * s₀_d + 12) + 80) +
                ((k_blk + 1) * (58 * L + 60) + 100) +
                ((m + 1) * (56 * d + 200 * L + 240) + 200) + 50) * (W * W) := by ring
          _ ≤ ((m + 1) * (72 * d + 258 * L + 340) + 450) * (W * W) :=
              Nat.mul_le_mul_right (W * W) hcoef
          _ = ((m + 1) * (72 * d + 258 * L + 340) + 450) * W * W := by ring
      linarith only [hinc_b, hmain_b]
  refine ⟨wsPost, regsPost, hExecPost, hmPost, brPost, hjHolds_Post, hr010_Post, hr110_Post,
    ⟨hSeq', hbuf_Post, hhSeq'_img⟩, hclean8_Post, htree1_Post, hclean567_Post, hheap9_Post,
    htab4_Post, htree3_Post, ⟨rNum, rDen, htreeSj_Post, hrBnds_Sj⟩,
    fun loc n010 nSt n4 ns3 ns2 ns1 n8 n9 => ?_⟩
  have uInc := hunchInc loc n010 (fun addr _ => n9 (addr : ℤ))
  have uSj := hunchSj loc n010 ns2 ns1 n8 (n9 110) (n9 111) (n9 112) (n9 113) (n9 114) (n9 115) (n9 116)
  have uI := hunchInt loc ns3 (n9 113) (n9 114)
  have uT := hunchT4 loc n4
  have uU := hunchU loc nSt
  exact ⟨uInc.1.trans (uSj.1.trans (uI.1.trans (uT.1.trans uU.1))),
         uInc.2.trans (uSj.2.trans (uI.2.trans (uT.2.trans uU.2)))⟩

/-! ### 2. Full `c07StepC2Stmt` Statement & Cost/Slack Bounds -/

def c07StepC2Stmt (d s₀_d L B T_max : ℕ) (progA2 : BitRAMStmt) (jSrc : JSource) : BitRAMStmt :=
  .seq (c07StepC2PreA2Regs d L B jSrc)
  (.seq (a2RunExtractCleanStmt d s₀_d (posNodeStride d L) T_max progA2)
        (c07StepC2PostA2Regs d s₀_d L jSrc))

def c07A2CellPerN (d spCeil : ℕ) : ℕ :=
  2 * d + 6 * (spCeil + 1) + 80

def c07A2BitPerN (d L T_max spCeil W : ℕ) : ℕ :=
  let S_bits_ub := spCeil + L + 6
  2 * W * (2 * d + 10) +
  16 * (W + 12) +
  (3 * T_max + 2 * S_bits_ub + 52) * L * spCeil +
  4 * (spCeil + 1) * (S_bits_ub + 12) +
  16 * T_max + 24 * S_bits_ub + 320

def c07StepC2UnitFactor (d L F spCeil : ℕ) : ℕ :=
  8 * F + 32 * spCeil + 680 * d + 2440 * L + 3600

def c07StepC2BitFactor (d L T_max F spCeil W : ℕ) : ℕ :=
  let S_bits_ub := spCeil + L + 6
  let K_ub := L + d + T_max + 16 + S_bits_ub
  8 * F * K_ub +
  (196 * d + 408 * L + 1400) * W * W +
  8 * (3 * T_max + 2 * S_bits_ub + 40) * L * spCeil +
  spCeil * (72 * S_bits_ub + 512) + 28 * S_bits_ub + 400

end UL.C12StepC2
