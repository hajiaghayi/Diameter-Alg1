import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2c
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL.C12LVE

open UL
open UL.Proof_lem_A_1

theorem not_mem_treeSliceLocs_of_ne {L tid₁ tid₂ u f : ℕ}
    (hne : tid₁ ≠ tid₂) (hu : u < 2 ^ (L + 1)) (hf : f < 4) :
    (.heap 2 (treeCellAddr L tid₁ u f) : RAMCellLoc) ∉ treeSliceLocs L tid₂ := by
  intro hmem
  unfold treeSliceLocs at hmem
  rcases Finset.mem_image.mp hmem with ⟨⟨u₂, f₂⟩, huf, heq⟩
  obtain ⟨hu₂, hf₂⟩ := Finset.mem_product.mp huf
  injection heq with _ haddr
  exact hne (treeCellAddr_inj hu hf (Finset.mem_range.mp hu₂) (Finset.mem_range.mp hf₂) haddr.symm).1

theorem path_sub_treeSliceLocs {L tid h : ℕ} (hh : h < 2 ^ L) :
    treePathLocs L tid h ⊆ treeSliceLocs L tid := by
  intro loc hloc
  unfold treePathLocs at hloc
  rcases Finset.mem_image.mp hloc with ⟨⟨k, f⟩, hkf, rfl⟩
  obtain ⟨hk, hf⟩ := Finset.mem_product.mp hkf
  have hk_le : k ≤ L := by have := Finset.mem_range.mp hk; omega
  have hoff : h / 2 ^ k < 2 ^ (L - k) := by
    rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add, Nat.sub_add_cancel hk_le]
    exact hh
  have hu := (treeIdx_bounds hk_le hoff).2
  unfold treeSliceLocs
  exact Finset.mem_image.mpr ⟨(treeIdx L k (h / 2 ^ k), f),
    Finset.mem_product.mpr ⟨Finset.mem_range.mpr hu, hf⟩, rfl⟩

def freeScratch111to116Regs : BitRAMStmt :=
  .seq (rLit 10 111) (.seq (rFree 9 10)
  (.seq (rLit 10 112) (.seq (rFree 9 10)
  (.seq (rLit 10 113) (.seq (rFree 9 10)
  (.seq (rLit 10 114) (.seq (rFree 9 10)
  (.seq (rLit 10 115) (.seq (rFree 9 10)
  (.seq (rLit 10 116) (rFree 9 10)))))))))))

theorem exec_freeScratch111to116Regs {d L K_max : ℕ}
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    (hW : 20 ≤ W)
    {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit freeScratch111to116Regs ws regs wsEnd regsEnd
        60 (40 * W + 240) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      (.heap 9 111 : RAMCellLoc) ∉ wsEnd.live ∧
      (.heap 9 112 : RAMCellLoc) ∉ wsEnd.live ∧
      (.heap 9 113 : RAMCellLoc) ∉ wsEnd.live ∧
      (.heap 9 114 : RAMCellLoc) ∉ wsEnd.live ∧
      (.heap 9 115 : RAMCellLoc) ∉ wsEnd.live ∧
      (.heap 9 116 : RAMCellLoc) ∉ wsEnd.live ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .heap 9 111 → loc ≠ .heap 9 112 → loc ≠ .heap 9 113 →
        loc ≠ .heap 9 114 → loc ≠ .heap 9 115 → loc ≠ .heap 9 116 →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by omega)
  have hb111 : intBitLength (111 : ℤ) ≤ W := (show intBitLength (111 : ℤ) = 8 from by decide).trans_le (by omega)
  have hb112 : intBitLength (112 : ℤ) ≤ W := (show intBitLength (112 : ℤ) = 8 from by decide).trans_le (by omega)
  have hb113 : intBitLength (113 : ℤ) ≤ W := (show intBitLength (113 : ℤ) = 8 from by decide).trans_le (by omega)
  have hb114 : intBitLength (114 : ℤ) ≤ W := (show intBitLength (114 : ℤ) = 8 from by decide).trans_le (by omega)
  have hb115 : intBitLength (115 : ℤ) ≤ W := (show intBitLength (115 : ℤ) = 8 from by decide).trans_le (by omega)
  have hb116 : intBitLength (116 : ℤ) ≤ W := (show intBitLength (116 : ℤ) = 8 from by decide).trans_le (by omega)
  have s1a := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 111) (by decide) hb111
  set g1 := Function.update regs 10 111; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hb111
  set w1 := ws.free (.heap 9 111); have hm1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w1 := hmod.free (mem_posDimWriteLocs_tab9 (by decide))
  have s1b := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws)
    bg1 (table := 9) (addr := 10) (by decide) hn9
  rw [show ws.free (.heap 9 (g1 10)) = w1 by simp [g1, w1]] at s1b
  have s2a := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 10) (c := 112) (by decide) hb112
  set g2 := Function.update g1 10 112; have bg2 : RegBounded W g2 := bg1.update (r := 10) (by decide) hb112
  set w2 := w1.free (.heap 9 112); have hm2 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w2 := hm1.free (mem_posDimWriteLocs_tab9 (by decide))
  have s2b := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := w1)
    bg2 (table := 9) (addr := 10) (by decide) hn9
  rw [show w1.free (.heap 9 (g2 10)) = w2 by simp [g2, w2]] at s2b
  have s3a := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 10) (c := 113) (by decide) hb113
  set g3 := Function.update g2 10 113; have bg3 : RegBounded W g3 := bg2.update (r := 10) (by decide) hb113
  set w3 := w2.free (.heap 9 113); have hm3 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w3 := hm2.free (mem_posDimWriteLocs_tab9 (by decide))
  have s3b := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := w2)
    bg3 (table := 9) (addr := 10) (by decide) hn9
  rw [show w2.free (.heap 9 (g3 10)) = w3 by simp [g3, w3]] at s3b
  have s4a := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hm3).1 (sp_ok hm3).2 (dst := 10) (c := 114) (by decide) hb114
  set g4 := Function.update g3 10 114; have bg4 : RegBounded W g4 := bg3.update (r := 10) (by decide) hb114
  set w4 := w3.free (.heap 9 114); have hm4 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w4 := hm3.free (mem_posDimWriteLocs_tab9 (by decide))
  have s4b := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := w3)
    bg4 (table := 9) (addr := 10) (by decide) hn9
  rw [show w3.free (.heap 9 (g4 10)) = w4 by simp [g4, w4]] at s4b
  have s5a := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm4).1 (sp_ok hm4).2 (dst := 10) (c := 115) (by decide) hb115
  set g5 := Function.update g4 10 115; have bg5 : RegBounded W g5 := bg4.update (r := 10) (by decide) hb115
  set w5 := w4.free (.heap 9 115); have hm5 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w5 := hm4.free (mem_posDimWriteLocs_tab9 (by decide))
  have s5b := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := w4)
    bg5 (table := 9) (addr := 10) (by decide) hn9
  rw [show w4.free (.heap 9 (g5 10)) = w5 by simp [g5, w5]] at s5b
  have s6a := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hm5).1 (sp_ok hm5).2 (dst := 10) (c := 116) (by decide) hb116
  set g6 := Function.update g5 10 116; have bg6 : RegBounded W g6 := bg5.update (r := 10) (by decide) hb116
  set w6 := w5.free (.heap 9 116); have hm6 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w6 := hm5.free (mem_posDimWriteLocs_tab9 (by decide))
  have s6b := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := w5)
    bg6 (table := 9) (addr := 10) (by decide) hn9
  rw [show w5.free (.heap 9 (g6 10)) = w6 by simp [g6, w6]] at s6b
  refine ⟨w6, g6, ?_, hm6, bg6, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · exact (s1a.seq (s1b.seq (s2a.seq (s2b.seq (s3a.seq (s3b.seq (s4a.seq (s4b.seq
      (s5a.seq (s5b.seq (s6a.seq s6b))))))))))).weaken rfl rfl (by omega) (by omega)
  · simp [w6, w5, w4, w3, w2, w1, WordStore.free]
  · simp [w6, w5, w4, w3, w2, WordStore.free]
  · simp [w6, w5, w4, w3, WordStore.free]
  · simp [w6, w5, w4, WordStore.free]
  · simp [w6, w5, WordStore.free]
  · simp [w6, WordStore.free]
  · intro loc h111 h112 h113 h114 h115 h116
    dsimp [w6, w5, w4, w3, w2, w1, WordStore.free]
    exact ⟨by simp [h116, h115, h114, h113, h112, h111],
      by simp [Function.update_of_ne h116, Function.update_of_ne h115, Function.update_of_ne h114,
               Function.update_of_ne h113, Function.update_of_ne h112, Function.update_of_ne h111]⟩

noncomputable def isResHandlePred {d : ℕ} (qMap : ℕ → Fin d → ℚ)
    (oRat : Fin d → ℚ) (V : ℝ) (h : ℕ) : Bool := by
  classical
  exact decide (ratPointToEuclidean (qMap h) ∉ coreBall (ratPointToEuclidean oRat) V)

open Classical in
theorem isResHandlePred_val {d : ℕ} (qMap : ℕ → Fin d → ℚ) (oRat : Fin d → ℚ) (V : ℝ) (h : ℕ) :
    (if isResHandlePred qMap oRat V h then (1 : ℤ) else 0) =
    (if ratPointToEuclidean (qMap h) ∈ coreBall (ratPointToEuclidean oRat) V then 0 else 1) := by
  unfold isResHandlePred
  by_cases hm : ratPointToEuclidean (qMap h) ∈ coreBall (ratPointToEuclidean oRat) V <;> simp [hm]

theorem isResHandlePred_eq_true_iff {d : ℕ} (qMap : ℕ → Fin d → ℚ) (oRat : Fin d → ℚ) (V : ℝ) (h : ℕ) :
    isResHandlePred qMap oRat V h = true ↔
      ratPointToEuclidean (qMap h) ∉ coreBall (ratPointToEuclidean oRat) V := by
  unfold isResHandlePred; simp

def buildSjResStepStmt (d L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 113)
  (.seq (rLoad 0 9 10)
  (.seq (rLit 10 115)
  (.seq (rLoad 13 9 10)
  (.seq (rLoad 1 8 13)
  (.seq (sqRadAndCoreRegs d (posNodeStride d L))
  (.seq (rLit 10 116)
  (.seq (rStore 9 10 2)
  (.seq (rLit 10 114)
  (.seq (rLoad 0 9 10)
  (.seq (rLit 2 1)
  (.seq (treeSetLeafRegs L)
  (.seq (rLit 10 115)
  (.seq (rLoad 13 9 10)
  (.seq (rLoad 1 8 13)
  (.seq (rLit 14 1)
  (.seq (rAdd 13 13 14)
  (.seq (rStore 9 10 13)
  (.seq (rLit 10 116)
  (.seq (rLoad 2 9 10)
  (.seq (rLit 0 1)
  (.seq (rLit 3 0)
  (.seq (rLit 4 1)
        (treeSetLeafRegs L)))))))))))))))))))))))

def SjLoopInv (d L B B_cert K_max j m : ℕ)
    (hSeq : ℕ → ℕ) (qMap : ℕ → Fin d → ℚ)
    (oRat : Fin d → ℚ) (V : ℝ)
    (wsInit : WordStore) (W : ℕ)
    (r : ℕ) (w : WordStore) (rg : ℕ → ℤ) : Prop :=
  r ≤ m ∧
  ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
  RegBounded W rg ∧
  (∃ (rNum rDen : ℕ → ℤ),
    TreeStoredAt L (2 * j + 2) ((Finset.range r).image hSeq) rNum rDen w ∧
    (∀ h ∈ (Finset.range r).image hSeq,
      1 ≤ rDen h ∧
      ((rNum h : ℝ) / (rDen h : ℝ)) =
        ‖ratPointToEuclidean (qMap h) - ratPointToEuclidean oRat‖ ^ 2 ∧
      intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧
      intBitLength (rDen h) ≤ sqRadBitBound d B B_cert)) ∧
  TreeStoredAt L 1 (((Finset.range r).image hSeq).filter (fun h => isResHandlePred qMap oRat V h = true))
    (fun _ => 0) (fun _ => 1) w ∧
  w.read (.heap 9 113) = (j : ℤ) ∧
  w.read (.heap 9 114) = (((2 * j + 2 : ℕ) : ℤ)) ∧
  w.read (.heap 9 115) = (r : ℤ) ∧
  (∀ loc : RAMCellLoc,
    loc ∉ treeSliceLocs L (2 * j + 2) →
    loc ∉ treeSliceLocs L 1 →
    loc ≠ .heap 9 113 → loc ≠ .heap 9 114 → loc ≠ .heap 9 115 → loc ≠ .heap 9 116 →
    (loc ∈ w.live ↔ loc ∈ wsInit.live) ∧ w.vals loc = wsInit.vals loc)

theorem exec_buildSjResStepStmt {d : ℕ} (hd1 : 1 ≤ d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {wsInit : WordStore}
    (hwfInit : WellFormedWS wsInit)
    {L B B_cert K_max j m : ℕ}
    (hL1 : 1 ≤ L) (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    (hj : j ≤ K_max) (hm_le : m ≤ 2 ^ L)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength d + L + 40 ≤ W)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    {hSeq : ℕ → ℕ} {S_act : Finset ℕ} {qMap : ℕ → Fin d → ℚ}
    (hbuf : ∀ k < m, wsInit.read (.heap 8 (k : ℤ)) = (hSeq k : ℤ))
    (hhSeq_mem : ∀ k < m, hSeq k ∈ S_act)
    (hcoords : ActiveCoordsStored d L B S_act qMap wsInit)
    {oRat : Fin d → ℚ} {V_num V_den : ℤ} {V : ℝ}
    (hgeom : NodeGeomStored d (posNodeStride d L) B_cert j oRat V_num V_den V wsInit)
    {r : ℕ} (hr : r < m) {w : WordStore} {rg : ℕ → ℤ}
    (hInv : SjLoopInv d L B B_cert K_max j m hSeq qMap oRat V wsInit W r w rg) :
    ∃ w' rg',
      RegExec inp fd W C_cell C_bit (buildSjResStepStmt d L) w rg w' rg'
        (240 * d + 700 * L + 600) ((56 * d + 112 * L + 110) * W * W) ∧
      SjLoopInv d L B B_cert K_max j m hSeq qMap oRat V wsInit W (r + 1) w' rg' := by
  obtain ⟨_, hmw, brg, ⟨rNum, rDen, htreeSj, hrBnds⟩, htree1, hr113, hr114, hr115, hunch⟩ := hInv
  set nodeStride := posNodeStride d L
  set tid := 2 * j + 2
  have htid_lt : tid < 2 * K_max + 6 := by dsimp [tid]; omega
  have ht1_lt : 1 < 2 * K_max + 6 := by omega
  have htid_ne1 : tid ≠ 1 := by dsimp [tid]; omega
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hWW : 40 * W ≤ W * W := by nlinarith only [hW40]
  have hj1 : j ≤ K_max + 1 := Nat.le_succ_of_le hj
  have hstride_ge : 6 + 2 * d ≤ nodeStride := by dsimp [nodeStride, posNodeStride]; have := Nat.zero_le (2 ^ L); omega
  have hns_ge2 : 2 ≤ nodeStride := by dsimp [nodeStride, posNodeStride]; have := Nat.zero_le (2 ^ L); omega
  have sp_ok : ∀ {wx : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wx →
      inp.inputCellSpace + wx.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + wx.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro wx hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hCeil0C : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hCeil0B : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  have not_slice : ∀ {t0 t : ℕ} {z : ℤ}, t ≠ 2 → (.heap t z : RAMCellLoc) ∉ treeSliceLocs L t0 := by
    intro t0 t z hne hm
    unfold treeSliceLocs at hm
    rcases Finset.mem_image.mp hm with ⟨_, _, hc⟩
    injection hc with ht _; exact hne ht.symm
  have not_path : ∀ {t0 h0 t : ℕ} {z : ℤ}, t ≠ 2 → (.heap t z : RAMCellLoc) ∉ treePathLocs L t0 h0 := by
    intro t0 h0 t z hne hm
    unfold treePathLocs at hm
    rcases Finset.mem_image.mp hm with ⟨_, _, hc⟩
    injection hc with ht _; exact hne ht.symm
  have htid_nbl : natBitLength tid ≤ natBitLength ((K_max + 2) * nodeStride) := by
    apply natBitLength_mono
    calc tid = 2 * j + 2 := rfl
      _ ≤ 2 * (K_max + 2) := by omega
      _ = (K_max + 2) * 2 := by ring
      _ ≤ (K_max + 2) * nodeStride := Nat.mul_le_mul_left _ hns_ge2
  have hj_bl : intBitLength (j : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le j
    have h2 : natBitLength j ≤ natBitLength tid := natBitLength_mono (by dsimp [tid]; omega)
    clear * - h1 h2 htid_nbl hW; omega
  have htid_bl : intBitLength (tid : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le tid
    clear * - h1 htid_nbl hW; omega
  have hr_lt2L : r < 2 ^ L := lt_of_lt_of_le hr hm_le
  have hr_bl : intBitLength (r : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hr_lt2L).trans (by clear * - hW; omega)
  have hr1_bl : intBitLength (((r + 1 : ℕ) : ℤ)) ≤ W := by
    have hlt : r + 1 < 2 ^ (L + 1) := by rw [pow_succ]; omega
    exact (nat_lt_pow2_bitLength_le hlt).trans (by clear * - hW; omega)
  set h₀ := hSeq r
  have hh₀_mem : h₀ ∈ S_act := hhSeq_mem r hr
  have hh₀_lt : h₀ < 2 ^ L := (hcoords.hS h₀ hh₀_mem).1
  have hh₀_bl : intBitLength (h₀ : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hh₀_lt).trans (by clear * - hW; omega)
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hl113 : intBitLength (113 : ℤ) ≤ W := (show intBitLength (113 : ℤ) = 8 from by decide).trans_le (by omega)
  have hl114 : intBitLength (114 : ℤ) ≤ W := (show intBitLength (114 : ℤ) = 8 from by decide).trans_le (by omega)
  have hl115 : intBitLength (115 : ℤ) ≤ W := (show intBitLength (115 : ℤ) = 8 from by decide).trans_le (by omega)
  have hl116 : intBitLength (116 : ℤ) ≤ W := (show intBitLength (116 : ℤ) = 8 from by decide).trans_le (by omega)
  have hn8 : natBitLength 8 ≤ W := (show natBitLength 8 = 4 from by decide).trans_le (by omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by omega)
  have hloc115 : (RAMCellLoc.heap 9 115).bitLength ≤ W := (show (RAMCellLoc.heap 9 115).bitLength = 12 from by decide).trans_le (by omega)
  have hloc116 : (RAMCellLoc.heap 9 116).bitLength ≤ W := (show (RAMCellLoc.heap 9 116).bitLength = 12 from by decide).trans_le (by omega)
  -- Preserve coords, geom, and buf on `w`
  have read_eq_of_unch : ∀ {wx : WordStore} {t : ℕ} {z : ℤ}, WellFormedWS wx →
      ((.heap t z : RAMCellLoc) ∈ wx.live ↔ (.heap t z : RAMCellLoc) ∈ wsInit.live) ∧
      wx.vals (.heap t z) = wsInit.vals (.heap t z) →
      wx.read (.heap t z) = wsInit.read (.heap t z) := by
    intro wx t z hwf hu
    unfold WordStore.read; rw [hu.2]
    by_cases hL : (.heap t z : RAMCellLoc) ∈ wsInit.live
    · rw [if_pos (hu.1.mpr hL), if_pos hL]
    · rw [if_neg (fun hm => hL (hu.1.mp hm)), if_neg hL]
  have hcoords_w : ActiveCoordsStored d L B S_act qMap w :=
    hcoords.unchanged (fun _ _ _ _ _ _ => read_eq_of_unch hmw.wf
      (hunch _ (not_slice (by decide)) (not_slice (by decide))
        (fun h => by cases h) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)))
  have hgeom_w : NodeGeomStored d nodeStride B_cert j oRat V_num V_den V w :=
    hgeom.unchanged (fun _ _ => read_eq_of_unch hmw.wf
      (hunch _ (not_slice (by decide)) (not_slice (by decide))
        (fun h => by cases h) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)))
  have hbuf_w : w.read (.heap 8 (r : ℤ)) = (h₀ : ℤ) :=
    (read_eq_of_unch hmw.wf (hunch _ (not_slice (by decide)) (not_slice (by decide))
      (fun h => by cases h) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h))).trans (hbuf r hr)
  -- Steps 1..5: load `j` into reg 0 and `h₀` into reg 1
  have s1 := RegExec.lit (inp := inp) hfd_le brg (sp_ok hmw).1 (sp_ok hmw).2 (dst := 10) (c := 113) (by decide) hl113
  set g1 := Function.update rg 10 113; have bg1 : RegBounded W g1 := brg.update (r := 10) (by decide) hl113
  have hr_g1 : w.read (.heap 9 (g1 10)) = (j : ℤ) := by simp [g1, hr113]
  have s2 := (RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmw).1 (sp_ok hmw).2
    (dst := 0) (table := 9) (addr := 10) (by decide) (by decide) hn9 (hr_g1 ▸ hj_bl)).weaken rfl (by rw [hr_g1]) le_rfl le_rfl
  set g2 := Function.update g1 0 (j : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 0) (by decide) hj_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 10) (c := 115) (by decide) hl115
  set g3 := Function.update g2 10 115; have bg3 : RegBounded W g3 := bg2.update (r := 10) (by decide) hl115
  have hr_g3 : w.read (.heap 9 (g3 10)) = (r : ℤ) := by simp [g3, hr115]
  have s4 := (RegExec.load (inp := inp) hfd_le bg3 (sp_ok hmw).1 (sp_ok hmw).2
    (dst := 13) (table := 9) (addr := 10) (by decide) (by decide) hn9 (hr_g3 ▸ hr_bl)).weaken rfl (by rw [hr_g3]) le_rfl le_rfl
  set g4 := Function.update g3 13 (r : ℤ); have bg4 : RegBounded W g4 := bg3.update (r := 13) (by decide) hr_bl
  have hr_g4 : w.read (.heap 8 (g4 13)) = (h₀ : ℤ) := by simp [g4, hbuf_w]
  have s5 := (RegExec.load (inp := inp) hfd_le bg4 (sp_ok hmw).1 (sp_ok hmw).2
    (dst := 1) (table := 8) (addr := 13) (by decide) (by decide) hn8 (hr_g4 ▸ hh₀_bl)).weaken rfl (by rw [hr_g4]) le_rfl le_rfl
  set g5 := Function.update g4 1 (h₀ : ℤ); have bg5 : RegBounded W g5 := bg4.update (r := 1) (by decide) hh₀_bl
  -- Step 6: `sqRadAndCoreRegs`
  have hW_sq : (2 * d + 2) * (2 * B + 2 * B_cert + 8) + natBitLength ((K_max + 2) * nodeStride) +
      natBitLength d + L + 32 ≤ W := by
    have hsq : (2 * d + 2) * (2 * B + 2 * B_cert + 8) ≤ 2 * sqRadBitBound d B B_cert := by
      unfold sqRadBitBound; clear * -; nlinarith
    clear * - hsq hW; omega
  obtain ⟨g6, s6, bg6, g6_0, g6_1, _, hden1, _, hrat_eq, hbl3_raw, hbl4_raw, g6_2⟩ :=
    exec_sqRadAndCoreRegs hd1 hfd_le (sp_ok hmw).1 (sp_ok hmw).2
      hB1 hBc1 hj1 hstride_ge hW_sq hcoords_w hh₀_mem hgeom_w bg5
      (by simp [g5, g4, g3, g2]) (by simp [g5])
  have hbl3 : intBitLength (g6 3) ≤ sqRadBitBound d B B_cert :=
    hbl3_raw.trans (by unfold sqRadBitBound; clear * -; nlinarith)
  have hbl4 : intBitLength (g6 4) ≤ sqRadBitBound d B B_cert :=
    hbl4_raw.trans (by unfold sqRadBitBound; clear * -; nlinarith)
  have hBr_sq1 : 1 ≤ sqRadBitBound d B B_cert := by unfold sqRadBitBound; omega
  -- Steps 7..8: store `g6 2` into `.heap 9 116`
  have s7 := RegExec.lit (inp := inp) hfd_le bg6 (sp_ok hmw).1 (sp_ok hmw).2 (dst := 10) (c := 116) (by decide) hl116
  set g7 := Function.update g6 10 116; have bg7 : RegBounded W g7 := bg6.update (r := 10) (by decide) hl116
  have hg6_2_bl : intBitLength (g6 2) ≤ W := bg6.2.1 2 (by decide)
  set w1 := w.write (.heap 9 116) (g6 2)
  have hmw1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w1 := hmw.write (mem_posDimWriteLocs_tab9 (by decide)) (g6 2) hloc116 hg6_2_bl
  have s8 : RegExec inp fd W C_cell C_bit (rStore 9 10 2) w g7 w1 g7 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le bg7 (table := 9) (addr := 10) (val := 2) (by decide) (by decide) hn9
      (by simpa [g7] using (sp_ok hmw1).1) (by simpa [g7] using (sp_ok hmw1).2)).weaken
      (by simp [g7, w1]) rfl le_rfl le_rfl
  -- Steps 9..12: insert `h₀` into `tree (2 * j + 2)`
  have s9 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hmw1).1 (sp_ok hmw1).2 (dst := 10) (c := 114) (by decide) hl114
  set g9 := Function.update g7 10 114; have bg9 : RegBounded W g9 := bg7.update (r := 10) (by decide) hl114
  have hr_g9 : w1.read (.heap 9 (g9 10)) = (tid : ℤ) := by
    simp only [g9, Function.update_self, w1]
    rw [wordStore_read_write_ne _ (by decide)]; exact hr114
  have s10 := (RegExec.load (inp := inp) hfd_le bg9 (sp_ok hmw1).1 (sp_ok hmw1).2
    (dst := 0) (table := 9) (addr := 10) (by decide) (by decide) hn9 (hr_g9 ▸ htid_bl)).weaken rfl (by rw [hr_g9]) le_rfl le_rfl
  set g10 := Function.update g9 0 (tid : ℤ); have bg10 : RegBounded W g10 := bg9.update (r := 0) (by decide) htid_bl
  have s11 := RegExec.lit (inp := inp) hfd_le bg10 (sp_ok hmw1).1 (sp_ok hmw1).2 (dst := 2) (c := 1) (by decide) hl1
  set g11 := Function.update g10 2 1; have bg11 : RegBounded W g11 := bg10.update (r := 2) (by decide) hl1
  have htreeSj_w1 : TreeStoredAt L tid ((Finset.range r).image hSeq) rNum rDen w1 :=
    htreeSj.unchanged (fun _ _ _ _ => by
      dsimp [w1, WordStore.write]
      exact ⟨by simp, by rw [Function.update_of_ne (fun h => by cases h)]⟩)
  set rNum' := Function.update rNum h₀ (g6 3)
  set rDen' := Function.update rDen h₀ (g6 4)
  have himg_succ : (Finset.range (r + 1)).image hSeq = insert h₀ ((Finset.range r).image hSeq) := by
    rw [Finset.range_add_one, Finset.image_insert]
  have hrBnds' : ∀ h ∈ (Finset.range (r + 1)).image hSeq,
      1 ≤ rDen' h ∧
      ((rNum' h : ℝ) / (rDen' h : ℝ)) =
        ‖ratPointToEuclidean (qMap h) - ratPointToEuclidean oRat‖ ^ 2 ∧
      intBitLength (rNum' h) ≤ sqRadBitBound d B B_cert ∧
      intBitLength (rDen' h) ≤ sqRadBitBound d B B_cert := by
    intro h hh
    by_cases h_eq : h = h₀
    · subst h_eq
      simp only [rNum', rDen', Function.update_self]
      exact ⟨hden1, hrat_eq, hbl3, hbl4⟩
    · rw [himg_succ, Finset.mem_insert] at hh
      rcases hh with rfl | hh_old
      · exact absurd rfl h_eq
      · simp only [rNum', rDen', Function.update_of_ne h_eq]
        exact hrBnds h hh_old
  have hS'_bnds : ∀ h ∈ (Finset.range (r + 1)).image hSeq,
      h < 2 ^ L ∧ intBitLength (rNum' h) ≤ sqRadBitBound d B B_cert ∧ intBitLength (rDen' h) ≤ sqRadBitBound d B B_cert := by
    intro h hh
    rcases Finset.mem_image.mp hh with ⟨k, hk, rfl⟩
    have hk_lt : k < m := lt_of_lt_of_le (Finset.mem_range.mp hk) hr
    exact ⟨(hcoords.hS (hSeq k) (hhSeq_mem k hk_lt)).1, (hrBnds' (hSeq k) hh).2.2.1, (hrBnds' (hSeq k) hh).2.2.2⟩
  obtain ⟨w2, g12, s12, hmw2, bg12, htreeSj_w2, hunchT2⟩ :=
    exec_treeSetLeafRegs hfd_le hmw1 hCeil0C hCeil0B hL1 hh₀_lt hBr_sq1
      (by clear * - htid_nbl hW; omega)
      (treePathLocs_sub_posDimWriteLocs htid_lt hh₀_lt)
      htreeSj_w1 hS'_bnds
      (fun h hne => by rw [himg_succ]; simp [hne])
      (fun h hne => by simp [rNum', Function.update_of_ne hne])
      (fun h hne => by simp [rDen', Function.update_of_ne hne])
      true (by rw [himg_succ]; simp)
      bg11 (by simp [g11, g10]) (by simp [g11, g10, g9, g7, g6_1])
      (by simp [g11]) (fun _ => by simp [g11, g10, g9, g7, rNum'])
      (fun _ => by simp [g11, g10, g9, g7, rDen'])
  -- Steps 13..24: reload `h₀`, increment `.heap 9 115`, reload `isRes`, update `tree 1`
  have s13 := RegExec.lit (inp := inp) hfd_le bg12 (sp_ok hmw2).1 (sp_ok hmw2).2 (dst := 10) (c := 115) (by decide) hl115
  set g13 := Function.update g12 10 115; have bg13 : RegBounded W g13 := bg12.update (r := 10) (by decide) hl115
  have hr115_w2 : w2.read (.heap 9 115) = (r : ℤ) := by
    rw [wordStore_read_eq_vals hmw2.wf, (hunchT2 _ (not_path (by decide))).2, ← wordStore_read_eq_vals hmw1.wf]
    dsimp [w1]; rw [wordStore_read_write_ne _ (by decide)]; exact hr115
  have hr_g13 : w2.read (.heap 9 (g13 10)) = (r : ℤ) := by simp [g13, hr115_w2]
  have s14 := (RegExec.load (inp := inp) hfd_le bg13 (sp_ok hmw2).1 (sp_ok hmw2).2
    (dst := 13) (table := 9) (addr := 10) (by decide) (by decide) hn9 (hr_g13 ▸ hr_bl)).weaken rfl (by rw [hr_g13]) le_rfl le_rfl
  set g14 := Function.update g13 13 (r : ℤ); have bg14 : RegBounded W g14 := bg13.update (r := 13) (by decide) hr_bl
  have hbuf_w2 : w2.read (.heap 8 (r : ℤ)) = (h₀ : ℤ) := by
    rw [wordStore_read_eq_vals hmw2.wf, (hunchT2 _ (not_path (by decide))).2, ← wordStore_read_eq_vals hmw1.wf]
    dsimp [w1]; rw [wordStore_read_write_ne _ (fun h => by cases h)]; exact hbuf_w
  have hr_g14 : w2.read (.heap 8 (g14 13)) = (h₀ : ℤ) := by simp [g14, hbuf_w2]
  have s15 := (RegExec.load (inp := inp) hfd_le bg14 (sp_ok hmw2).1 (sp_ok hmw2).2
    (dst := 1) (table := 8) (addr := 13) (by decide) (by decide) hn8 (hr_g14 ▸ hh₀_bl)).weaken rfl (by rw [hr_g14]) le_rfl le_rfl
  set g15 := Function.update g14 1 (h₀ : ℤ); have bg15 : RegBounded W g15 := bg14.update (r := 1) (by decide) hh₀_bl
  have s16 := RegExec.lit (inp := inp) hfd_le bg15 (sp_ok hmw2).1 (sp_ok hmw2).2 (dst := 14) (c := 1) (by decide) hl1
  set g16 := Function.update g15 14 1; have bg16 : RegBounded W g16 := bg15.update (r := 14) (by decide) hl1
  have ea17 : g16 13 + g16 14 = (((r + 1 : ℕ) : ℤ)) := by simp [g16, g15, g14]
  have s17 := (RegExec.add (inp := inp) hfd_le bg16 (sp_ok hmw2).1 (sp_ok hmw2).2
    (dst := 13) (a := 13) (b := 14) (by decide) (by decide) (by decide) (ea17 ▸ hr1_bl)).weaken rfl (by rw [ea17]) le_rfl le_rfl
  set g17 := Function.update g16 13 (((r + 1 : ℕ) : ℤ)); have bg17 : RegBounded W g17 := bg16.update (r := 13) (by decide) hr1_bl
  set w3 := w2.write (.heap 9 115) (((r + 1 : ℕ) : ℤ))
  have hmw3 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w3 := hmw2.write (mem_posDimWriteLocs_tab9 (by decide)) (((r + 1 : ℕ) : ℤ)) hloc115 hr1_bl
  have s18 : RegExec inp fd W C_cell C_bit (rStore 9 10 13) w2 g17 w3 g17 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le bg17 (table := 9) (addr := 10) (val := 13) (by decide) (by decide) hn9
      (by simpa [g17, g16, g15, g14, g13] using (sp_ok hmw3).1)
      (by simpa [g17, g16, g15, g14, g13] using (sp_ok hmw3).2)).weaken
      (by simp [g17, g16, g15, g14, g13, w3]) rfl le_rfl le_rfl
  have s19 := RegExec.lit (inp := inp) hfd_le bg17 (sp_ok hmw3).1 (sp_ok hmw3).2 (dst := 10) (c := 116) (by decide) hl116
  set g19 := Function.update g17 10 116; have bg19 : RegBounded W g19 := bg17.update (r := 10) (by decide) hl116
  have hr116_w3 : w3.read (.heap 9 116) = g6 2 := by
    dsimp [w3]; rw [wordStore_read_write_ne _ (by decide)]
    rw [wordStore_read_eq_vals hmw2.wf, (hunchT2 _ (not_path (by decide))).2, ← wordStore_read_eq_vals hmw1.wf]
    dsimp [w1]; rw [wordStore_read_write_self]
  have hr_g19 : w3.read (.heap 9 (g19 10)) = g6 2 := by simp [g19, hr116_w3]
  have s20 := (RegExec.load (inp := inp) hfd_le bg19 (sp_ok hmw3).1 (sp_ok hmw3).2
    (dst := 2) (table := 9) (addr := 10) (by decide) (by decide) hn9 (hr_g19 ▸ hg6_2_bl)).weaken rfl (by rw [hr_g19]) le_rfl le_rfl
  set g20 := Function.update g19 2 (g6 2); have bg20 : RegBounded W g20 := bg19.update (r := 2) (by decide) hg6_2_bl
  have s21 := RegExec.lit (inp := inp) hfd_le bg20 (sp_ok hmw3).1 (sp_ok hmw3).2 (dst := 0) (c := 1) (by decide) hl1
  set g21 := Function.update g20 0 1; have bg21 : RegBounded W g21 := bg20.update (r := 0) (by decide) hl1
  have s22 := RegExec.lit (inp := inp) hfd_le bg21 (sp_ok hmw3).1 (sp_ok hmw3).2 (dst := 3) (c := 0) (by decide) hl0
  set g22 := Function.update g21 3 0; have bg22 : RegBounded W g22 := bg21.update (r := 3) (by decide) hl0
  have s23 := RegExec.lit (inp := inp) hfd_le bg22 (sp_ok hmw3).1 (sp_ok hmw3).2 (dst := 4) (c := 1) (by decide) hl1
  set g23 := Function.update g22 4 1; have bg23 : RegBounded W g23 := bg22.update (r := 4) (by decide) hl1
  have htree1_w3 : TreeStoredAt L 1 (((Finset.range r).image hSeq).filter (fun h => isResHandlePred qMap oRat V h = true))
      (fun _ => 0) (fun _ => 1) w3 := by
    refine htree1.unchanged (fun u hu f hf => ?_)
    have not_t2 : (.heap 2 (treeCellAddr L 1 u f) : RAMCellLoc) ∉ treePathLocs L tid h₀ :=
      fun hm => not_mem_treeSliceLocs_of_ne htid_ne1.symm hu hf (path_sub_treeSliceLocs hh₀_lt hm)
    have u2 := hunchT2 _ not_t2
    have u3 : ((.heap 2 (treeCellAddr L 1 u f) : RAMCellLoc) ∈ w3.live ↔
               (.heap 2 (treeCellAddr L 1 u f) : RAMCellLoc) ∈ w2.live) ∧
              w3.vals (.heap 2 (treeCellAddr L 1 u f)) = w2.vals (.heap 2 (treeCellAddr L 1 u f)) := by
      dsimp [w3, WordStore.write]
      exact ⟨by simp, by rw [Function.update_of_ne (fun h => by cases h)]⟩
    have u1 : ((.heap 2 (treeCellAddr L 1 u f) : RAMCellLoc) ∈ w1.live ↔
               (.heap 2 (treeCellAddr L 1 u f) : RAMCellLoc) ∈ w.live) ∧
              w1.vals (.heap 2 (treeCellAddr L 1 u f)) = w.vals (.heap 2 (treeCellAddr L 1 u f)) := by
      dsimp [w1, WordStore.write]
      exact ⟨by simp, by rw [Function.update_of_ne (fun h => by cases h)]⟩
    exact ⟨u3.1.trans (u2.1.trans u1.1), u3.2.trans (u2.2.trans u1.2)⟩
  set S_res' := (((Finset.range (r + 1)).image hSeq).filter (fun h => isResHandlePred qMap oRat V h = true))
  have hS1_bnds : ∀ h ∈ S_res', h < 2 ^ L ∧ intBitLength ((0 : ℤ)) ≤ 2 ∧ intBitLength ((1 : ℤ)) ≤ 2 := by
    intro h hh
    rcases Finset.mem_image.mp (Finset.mem_filter.mp hh).1 with ⟨k, hk, rfl⟩
    have hk_lt : k < m := lt_of_lt_of_le (Finset.mem_range.mp hk) hr
    exact ⟨(hcoords.hS (hSeq k) (hhSeq_mem k hk_lt)).1, by decide, by decide⟩
  obtain ⟨w4, g24, s24, hmw4, bg24, htree1_w4, hunchT4⟩ :=
    exec_treeSetLeafRegs hfd_le hmw3 hCeil0C hCeil0B (tid := 1) hL1 hh₀_lt (B_r := 2) (by decide)
      (by have h1 : natBitLength 1 = 1 := (by decide); clear * - h1 hW; omega)
      (rNum' := fun _ => 0) (rDen' := fun _ => 1)
      (treePathLocs_sub_posDimWriteLocs ht1_lt hh₀_lt)
      htree1_w3 hS1_bnds
      (fun h hne => by
        simp only [S_res', Finset.mem_filter, himg_succ, Finset.mem_insert, hne, false_or])
      (fun _ _ => rfl) (fun _ _ => rfl)
      (isResHandlePred qMap oRat V h₀)
      (by simp only [S_res', Finset.mem_filter, himg_succ, Finset.mem_insert, true_or, true_and])
      bg23 (by simp [g23, g22, g21]) (by simp [g23, g22, g21, g20, g19, g17, g16, g15])
      (by simp only [g23, g22, g21, g20]; rw [Function.update_of_ne (by decide), Function.update_of_ne (by decide),
            Function.update_of_ne (by decide), Function.update_self, g6_2, isResHandlePred_val])
      (fun _ => by simp [g23, g22]) (fun _ => by simp [g23])
  have htreeSj_w4 : TreeStoredAt L tid ((Finset.range (r + 1)).image hSeq) rNum' rDen' w4 := by
    refine htreeSj_w2.unchanged (fun u hu f hf => ?_)
    have not_t4 : (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∉ treePathLocs L 1 h₀ :=
      fun hm => not_mem_treeSliceLocs_of_ne htid_ne1 hu hf (path_sub_treeSliceLocs hh₀_lt hm)
    have u4 := hunchT4 _ not_t4
    have u3 : ((.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ w3.live ↔
               (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ w2.live) ∧
              w3.vals (.heap 2 (treeCellAddr L tid u f)) = w2.vals (.heap 2 (treeCellAddr L tid u f)) := by
      dsimp [w3, WordStore.write]
      exact ⟨by simp, by rw [Function.update_of_ne (fun h => by cases h)]⟩
    exact ⟨u4.1.trans u3.1, u4.2.trans u3.2⟩
  have hr113_w4 : w4.read (.heap 9 113) = (j : ℤ) := by
    rw [wordStore_read_eq_vals hmw4.wf, (hunchT4 _ (not_path (by decide))).2, ← wordStore_read_eq_vals hmw3.wf]
    dsimp [w3]; rw [wordStore_read_write_ne _ (by decide)]
    rw [wordStore_read_eq_vals hmw2.wf, (hunchT2 _ (not_path (by decide))).2, ← wordStore_read_eq_vals hmw1.wf]
    dsimp [w1]; rw [wordStore_read_write_ne _ (by decide)]; exact hr113
  have hr114_w4 : w4.read (.heap 9 114) = (tid : ℤ) := by
    rw [wordStore_read_eq_vals hmw4.wf, (hunchT4 _ (not_path (by decide))).2, ← wordStore_read_eq_vals hmw3.wf]
    dsimp [w3]; rw [wordStore_read_write_ne _ (by decide)]
    rw [wordStore_read_eq_vals hmw2.wf, (hunchT2 _ (not_path (by decide))).2, ← wordStore_read_eq_vals hmw1.wf]
    dsimp [w1]; rw [wordStore_read_write_ne _ (by decide)]; exact hr114
  have hr115_w4 : w4.read (.heap 9 115) = (((r + 1 : ℕ) : ℤ)) := by
    rw [wordStore_read_eq_vals hmw4.wf, (hunchT4 _ (not_path (by decide))).2, ← wordStore_read_eq_vals hmw3.wf]
    dsimp [w3]; rw [wordStore_read_write_self]
  have hunch_w4 : ∀ loc : RAMCellLoc,
      loc ∉ treeSliceLocs L tid → loc ∉ treeSliceLocs L 1 →
      loc ≠ .heap 9 113 → loc ≠ .heap 9 114 → loc ≠ .heap 9 115 → loc ≠ .heap 9 116 →
      (loc ∈ w4.live ↔ loc ∈ wsInit.live) ∧ w4.vals loc = wsInit.vals loc := by
    intro loc nsSj ns1 n113 n114 n115 n116
    have npSj : loc ∉ treePathLocs L tid h₀ := fun hm => nsSj (path_sub_treeSliceLocs hh₀_lt hm)
    have np1 : loc ∉ treePathLocs L 1 h₀ := fun hm => ns1 (path_sub_treeSliceLocs hh₀_lt hm)
    have u4 := hunchT4 loc np1
    have u3 : (loc ∈ w3.live ↔ loc ∈ w2.live) ∧ w3.vals loc = w2.vals loc := by
      dsimp [w3, WordStore.write]; exact ⟨by simp [n115], by simp [Function.update_of_ne n115]⟩
    have u2 := hunchT2 loc npSj
    have u1 : (loc ∈ w1.live ↔ loc ∈ w.live) ∧ w1.vals loc = w.vals loc := by
      dsimp [w1, WordStore.write]; exact ⟨by simp [n116], by simp [Function.update_of_ne n116]⟩
    have u0 := hunch loc nsSj ns1 n113 n114 n115 n116
    exact ⟨u4.1.trans (u3.1.trans (u2.1.trans (u1.1.trans u0.1))),
           u4.2.trans (u3.2.trans (u2.2.trans (u1.2.trans u0.2)))⟩
  have sAll := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq
    (s9.seq (s10.seq (s11.seq (s12.seq (s13.seq (s14.seq (s15.seq (s16.seq
    (s17.seq (s18.seq (s19.seq (s20.seq (s21.seq (s22.seq (s23.seq s24))))))))))))))))))))))).weaken
    rfl rfl (u₂ := 240 * d + 700 * L + 600) (b₂ := (56 * d + 112 * L + 110) * W * W) (by clear * -; omega)
    (by
      have h1 : 80 * W + 424 ≤ 14 * W * W := by
        calc 80 * W + 424 ≤ 14 * (40 * W) := by clear * - hW40; omega
        _ ≤ 14 * (W * W) := Nat.mul_le_mul_left 14 hWW
        _ = 14 * W * W := by ring
      have h2 : 14 * W * W + (56 * d + 32) * W * W + (56 * L + 32) * W * W + (56 * L + 32) * W * W ≤
          (56 * d + 112 * L + 110) * W * W := by
        calc 14 * W * W + (56 * d + 32) * W * W + (56 * L + 32) * W * W + (56 * L + 32) * W * W
          _ = (56 * d + 112 * L + 110) * (W * W) := by ring
          _ ≤ (56 * d + 112 * L + 110) * (W * W) := le_rfl
          _ = (56 * d + 112 * L + 110) * W * W := by ring
      linarith only [h1, h2])
  exact ⟨w4, g24, sAll, hr, hmw4, bg24, ⟨rNum', rDen', htreeSj_w4, hrBnds'⟩,
    htree1_w4, hr113_w4, hr114_w4, hr115_w4, hunch_w4⟩

end UL.C12StepC2
