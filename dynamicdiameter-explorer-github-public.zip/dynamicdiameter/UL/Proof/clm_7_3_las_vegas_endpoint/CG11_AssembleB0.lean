import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtor
import UL.Proof.clm_7_3_las_vegas_endpoint.CG08_StepDB
import UL.Proof.clm_7_3_las_vegas_endpoint.CG09_StepC1B
import UL.Proof.clm_7_3_las_vegas_endpoint.CG11_AssembleA
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open scoped ENNReal
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### 1. Instantiating `C11StepC1Spec` from `CG09_StepC1B0.exec_posDimStepC1Gather` -/

def c11StepC1UnitFactor (d s₀_d L K_max : ℕ) : ℕ :=
  (K_max + 1) * (2 * s₀_d * (3200 * L + 3000) + 24 * d + 1200)

def c11StepC1BitFactor (d s₀_d L K_max W : ℕ) : ℕ :=
  (K_max + 1) * (2 * s₀_d * (500 * L + 700) + 20 * d + 1400) * W * W

private theorem c11_chainInput_take_eq {d s₀_d : ℕ}
    (ltCoords' : ℕ → EuclideanSpace ℝ (Fin d))
    (nodes updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)))
    (hupd_len : updatedNodes.length = nodes.length)
    (hupd_built : ∀ (m : ℕ) (hm : m < nodes.length),
      (updatedNodes.get ⟨m, hupd_len ▸ hm⟩).built = (nodes.get ⟨m, hm⟩).built)
    (A : Finset ℕ) {jStar : ℕ} (hjLe : jStar ≤ nodes.length)
    (j : ℕ) (hj : j ≤ (updatedNodes.take jStar).length) :
    let pref := updatedNodes.take jStar
    let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
    let vecPref : Fin pref.length → ChainNode d := fun i => (pref.get i).built.node
    have hj_n : j ≤ nodes.length := by
      have hlen : (updatedNodes.take jStar).length = jStar := List.length_take_of_le (hupd_len ▸ hjLe)
      omega
    chainInput ltCoords' vecPref A ⟨j, Nat.lt_succ_of_le hj⟩ =
      chainInput ltCoords' vecNodes A ⟨j, Nat.lt_succ_of_le hj_n⟩ := by
  intro pref vecNodes vecPref hj_n
  ext x
  rw [mem_chainInput_iff, mem_chainInput_iff]
  refine and_congr_right (fun _ => forall_congr' (fun m => forall_congr' (fun hm => ?_)))
  have hm_p : m < pref.length := lt_of_lt_of_le hm hj
  have hm_n : m < nodes.length := lt_of_lt_of_le hm hj_n
  have hget_p : pref.get ⟨m, hm_p⟩ = updatedNodes.get ⟨m, hupd_len ▸ hm_n⟩ := by
    simp [pref, List.get_eq_getElem, List.getElem_take]
  have hb : (pref.get ⟨m, hm_p⟩).built = (nodes.get ⟨m, hm_n⟩).built :=
    (congrArg SyncLiveChainNode.built hget_p).trans (hupd_built m hm_n)
  dsimp only [vecPref, vecNodes]
  rw [hb]

theorem c11_stepC1Spec
    (h_del_wit : S_claim_A_2_deletion_witness)
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W) :
    C11StepC1Spec (d := d) (s₀_d := s₀_d) n L B B_cert K_max W
      (c11StepC1UnitFactor d s₀_d L K_max)
      (c11StepC1BitFactor d s₀_d L K_max W)
      (posDimStepC1Gather d s₀_d L) .heap0_10 := by
  intro inp C_cell C_bit P P' ltCoords nodes updatedNodes qMap qMap' ws wsB regsB op hOp retHVal
    slotTriggers rebuildWork canceledBirthSum
    ltCoords' vecNodes
    hinv hwfP' hop_spec hlt_sync' hlt_adm' hupd_len hupd_node hno_trig_age
    hmB hcCeil hbCeil hbndB hrB_k hrB_00 hrB_106 hcoordsB htree0B htree1B
    hpreB hemptyB hclean58B hclean9B hTrig jStar hjLe S_trig hS_card hreb_le
  have hjFinal := (jStarStep_final nodes.length slotTriggers).1 hTrig
  have hno_before : ∀ j < jStar, ¬ slotTriggers j := hjFinal.2.2
  have hnoTrig_prefix : ∀ (j : ℕ) (hj : j < jStar),
      let v' := updatedNodes.get ⟨j, hupd_len ▸ lt_of_lt_of_le hj hjLe⟩
      (v'.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (v'.birthPool.card : ℝ) / 16 := by
    intro j hj
    exact hno_trig_age j (lt_of_lt_of_le hj hjLe) (hno_before j hj)
  have hmb_suffix : ∀ (j : ℕ) (hj : j < nodes.length), jStar ≤ j →
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).birthPool.card ≤
        2 * ((chainInput ltCoords' vecNodes (activeLifetimes P') ⟨jStar, Nat.lt_succ_of_le hjLe⟩).card + 1) := by
    intro j hj hjS
    rw [(hupd_node j hj).2]
    exact canceled_birthPool_card_le hs₀1 hinv hwfP' hop_spec hjLe hj hjS
  obtain ⟨wsC1, regsC1, hexec, hmC1, hbndC1, hM_eq, _, _,
    hr0_C1, hr10_C1, hr110_C1, hr8_C1, hH_elem, _, himg_C1,
    hcoordsC1, htree0C1, htree1C1, _, hlevelsC1, hemptyC1, hclean57C1, hclean8C1, hclean9C1⟩ :=
    exec_posDimStepC1Gather h_del_wit hd1 hs₀1 hn hL hB1 hBc1 hW (by decide : 1 ≤ 4)
      hwfP' hinv.hk_le hupd_len hjLe hnoTrig_prefix hmb_suffix
      hmB hcCeil hbCeil hbndB hrB_k hrB_106 hcoordsB htree0B htree1B
      hpreB hemptyB hclean58B hclean9B
  set H_jStar := S_trig.image (handleOfLifetime P')
  set M := H_jStar.card
  set pref := updatedNodes.take jStar
  have hlen_pref : pref.length = jStar := List.length_take_of_le (hupd_len ▸ hjLe)
  have hM1_le : M + 1 ≤ 2 * s₀_d * (canceledBirthSum + 1) := by
    rw [hM_eq]
    rcases hS_card with hleaf | hreb
    · have : S_trig.card + 1 ≤ 2 * s₀_d := by omega
      calc S_trig.card + 1 ≤ 2 * s₀_d * 1 := by omega
        _ ≤ 2 * s₀_d * (canceledBirthSum + 1) := Nat.mul_le_mul_left _ (by omega)
    · have : S_trig.card + 1 ≤ canceledBirthSum + 1 := by omega
      calc S_trig.card + 1 = 1 * (S_trig.card + 1) := (one_mul _).symm
        _ ≤ (2 * s₀_d) * (canceledBirthSum + 1) := Nat.mul_le_mul (by omega) this
  have hu_le :
      (nodes.length + 1) * ((M + 1) * (3200 * L + 3000) + 24 * d + 1200) ≤
        c11StepC1UnitFactor d s₀_d L K_max * (canceledBirthSum + 1) := by
    have hk1 : nodes.length + 1 ≤ K_max + 1 := Nat.add_le_add_right hinv.hk_le 1
    have hinner :
        (M + 1) * (3200 * L + 3000) + 24 * d + 1200 ≤
          (2 * s₀_d * (3200 * L + 3000) + 24 * d + 1200) * (canceledBirthSum + 1) := by
      have hm_part : (M + 1) * (3200 * L + 3000) ≤
          (2 * s₀_d * (3200 * L + 3000)) * (canceledBirthSum + 1) := by
        calc (M + 1) * (3200 * L + 3000)
          _ ≤ (2 * s₀_d * (canceledBirthSum + 1)) * (3200 * L + 3000) := Nat.mul_le_mul_right _ hM1_le
          _ = (2 * s₀_d * (3200 * L + 3000)) * (canceledBirthSum + 1) := by ring
      have hd_part : 24 * d + 1200 ≤ (24 * d + 1200) * (canceledBirthSum + 1) :=
        Nat.le_mul_of_pos_right _ (by omega)
      calc (M + 1) * (3200 * L + 3000) + 24 * d + 1200
        _ = (M + 1) * (3200 * L + 3000) + (24 * d + 1200) := by ring
        _ ≤ (2 * s₀_d * (3200 * L + 3000)) * (canceledBirthSum + 1) +
            (24 * d + 1200) * (canceledBirthSum + 1) := Nat.add_le_add hm_part hd_part
        _ = (2 * s₀_d * (3200 * L + 3000) + 24 * d + 1200) * (canceledBirthSum + 1) := by ring
    calc (nodes.length + 1) * ((M + 1) * (3200 * L + 3000) + 24 * d + 1200)
      _ ≤ (K_max + 1) * ((2 * s₀_d * (3200 * L + 3000) + 24 * d + 1200) * (canceledBirthSum + 1)) :=
          Nat.mul_le_mul hk1 hinner
      _ = c11StepC1UnitFactor d s₀_d L K_max * (canceledBirthSum + 1) := by
          unfold c11StepC1UnitFactor; ring
  have hb_le :
      (nodes.length + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) * W * W ≤
        c11StepC1BitFactor d s₀_d L K_max W * (canceledBirthSum + 1) := by
    have hk1 : nodes.length + 1 ≤ K_max + 1 := Nat.add_le_add_right hinv.hk_le 1
    have hinner :
        (M + 1) * (500 * L + 700) + 20 * d + 1400 ≤
          (2 * s₀_d * (500 * L + 700) + 20 * d + 1400) * (canceledBirthSum + 1) := by
      have hm_part : (M + 1) * (500 * L + 700) ≤
          (2 * s₀_d * (500 * L + 700)) * (canceledBirthSum + 1) := by
        calc (M + 1) * (500 * L + 700)
          _ ≤ (2 * s₀_d * (canceledBirthSum + 1)) * (500 * L + 700) := Nat.mul_le_mul_right _ hM1_le
          _ = (2 * s₀_d * (500 * L + 700)) * (canceledBirthSum + 1) := by ring
      have hd_part : 20 * d + 1400 ≤ (20 * d + 1400) * (canceledBirthSum + 1) :=
        Nat.le_mul_of_pos_right _ (by omega)
      calc (M + 1) * (500 * L + 700) + 20 * d + 1400
        _ = (M + 1) * (500 * L + 700) + (20 * d + 1400) := by ring
        _ ≤ (2 * s₀_d * (500 * L + 700)) * (canceledBirthSum + 1) +
            (20 * d + 1400) * (canceledBirthSum + 1) := Nat.add_le_add hm_part hd_part
        _ = (2 * s₀_d * (500 * L + 700) + 20 * d + 1400) * (canceledBirthSum + 1) := by ring
    have hbase :
        (nodes.length + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) ≤
          (K_max + 1) * (2 * s₀_d * (500 * L + 700) + 20 * d + 1400) * (canceledBirthSum + 1) := by
      calc (nodes.length + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400)
        _ ≤ (K_max + 1) * ((2 * s₀_d * (500 * L + 700) + 20 * d + 1400) * (canceledBirthSum + 1)) :=
            Nat.mul_le_mul hk1 hinner
        _ = (K_max + 1) * (2 * s₀_d * (500 * L + 700) + 20 * d + 1400) * (canceledBirthSum + 1) := by ring
    calc (nodes.length + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) * W * W
      _ = ((nodes.length + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400)) * (W * W) := by ring
      _ ≤ ((K_max + 1) * (2 * s₀_d * (500 * L + 700) + 20 * d + 1400) * (canceledBirthSum + 1)) * (W * W) :=
          Nat.mul_le_mul_right (W * W) hbase
      _ = c11StepC1BitFactor d s₀_d L K_max W * (canceledBirthSum + 1) := by
          unfold c11StepC1BitFactor; ring
  have hexecW := hexec.weaken rfl rfl hu_le hb_le
  have hmid : MidSuffixChainInv n L B B_cert K_max W P' ltCoords' pref qMap' retHVal S_trig wsC1 := by
    refine
      { wfP' := hwfP'
        mod := hmC1
        hk_le := by rw [hlen_pref]; exact hjLe.trans hinv.hk_le
        read_00 := hr0_C1.trans hrB_00
        hlt_sync' := hlt_sync'
        hlt_adm' := hlt_adm'
        coords_stored := hcoordsC1
        tree_active := htree0C1
        heap9_bound := fun z hm => by
          by_cases hz : z = 110
          · subst hz; exact ⟨110, by decide, rfl⟩
          · exact absurd hm (hclean9C1 z hz)
        hbirth_avoid := fun j hj lt hlt_in i hi => by
          have hj_s : j < jStar := by rwa [← hlen_pref]
          have hj_n : j < nodes.length := lt_of_lt_of_le hj_s hjLe
          have hi_p : i < pref.length := Nat.lt_trans hi hj
          have hi_n : i < nodes.length := Nat.lt_trans hi hj_n
          have hget_j : pref.get ⟨j, hj⟩ = updatedNodes.get ⟨j, hupd_len ▸ hj_n⟩ := by
            simp [pref, List.get_eq_getElem, List.getElem_take]
          have hget_i : pref.get ⟨i, hi_p⟩ = updatedNodes.get ⟨i, hupd_len ▸ hi_n⟩ := by
            simp [pref, List.get_eq_getElem, List.getElem_take]
          have hbp_j : (pref.get ⟨j, hj⟩).birthPool = (nodes.get ⟨j, hj_n⟩).birthPool :=
            (congrArg SyncLiveChainNode.birthPool hget_j).trans (hupd_node j hj_n).2
          have hblt_i : (pref.get ⟨i, hi_p⟩).built = (nodes.get ⟨i, hi_n⟩).built :=
            (congrArg SyncLiveChainNode.built hget_i).trans (hupd_node i hi_n).1
          rw [hbp_j] at hlt_in
          have hlt_next : lt < P.nextLifetime := ((hinv.levels j hj_n).hbirth_adm lt hlt_in).1
          have hlt_eq : ltCoords' lt = ltCoords lt := by
            cases op with
            | delete _ => rfl
            | insert _ _ _ =>
                simp [ltCoords', opNextLtCoords, Function.update_of_ne (Nat.ne_of_lt hlt_next)]
          rw [hlt_eq, hblt_i]
          exact hinv.hbirth_avoid j hj_n lt hlt_in i hi
        levels := fun j hj => by
          have hj_s : j < jStar := by rwa [← hlen_pref]
          have hci_eq := c11_chainInput_take_eq ltCoords' nodes updatedNodes hupd_len
            (fun m hm => (hupd_node m hm).1) (activeLifetimes P') hjLe j (Nat.le_of_lt hj)
          dsimp only at hci_eq ⊢
          rw [hci_eq]
          exact hlevelsC1 j hj_s
        empty_levels := fun j hj1 hj2 => hemptyC1 j (hlen_pref ▸ hj1) hj2
        stage567_clean := hclean57C1
        hR_eq := by
          have hci_eq := c11_chainInput_take_eq ltCoords' nodes updatedNodes hupd_len
            (fun m hm => (hupd_node m hm).1) (activeLifetimes P') hjLe pref.length le_rfl
          dsimp only at hci_eq
          have hfin_eq : (⟨pref.length, Nat.lt_succ_of_le (hlen_pref ▸ hjLe)⟩ : Fin (nodes.length + 1)) =
              ⟨jStar, Nat.lt_succ_of_le hjLe⟩ := Fin.ext hlen_pref
          rw [show (Fin.last pref.length : Fin (pref.length + 1)) = ⟨pref.length, Nat.lt_succ_of_le le_rfl⟩ from rfl,
              hci_eq, hfin_eq] }
  have hbuf : StdBufLoopExtra .heap0_10 L P' pref.length S_trig wsC1 regsC1 := by
    refine ⟨?_, htree1C1, ?_, ?_, ?_⟩
    · dsimp [JSourceHolds]
      rw [hlen_pref]
      exact hr10_C1
    · rw [← hM_eq]
      exact hr110_C1
    · refine ⟨minPopElem H_jStar, fun k hk => ?_, ?_⟩
      · have hkM : k < M := hM_eq ▸ hk
        exact ⟨(hH_elem k hkM).2, hr8_C1 k hkM⟩
      · rw [← hM_eq]
        exact himg_C1
    · intro z hz
      exact hclean8C1 z (fun idx hidx => hz idx (hM_eq ▸ hidx))
  exact ⟨wsC1, regsC1, hexecW, hbndC1, hmid, hbuf⟩

/-! ### 2. Instantiating `C11StepDSpec` from `CG08_StepDB.exec_posDimStepD` -/

theorem c11_stepDSpec
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n)) (hB1 : 1 ≤ B)
    (hW : 2 * sqRadBitBound d B B_cert + d * (8 * B + 24) +
          natBitLength ((K_max + 2) * posNodeStride d L) +
          natBitLength s₀_d + natBitLength d + L + 40 ≤ W) :
    C11StepDSpec (d := d) (s₀_d := s₀_d) n L B B_cert K_max W
      (stepDUnitCost d s₀_d L K_max)
      (stepDBitCost d s₀_d L W K_max)
      (posDimStepD d s₀_d L) := by
  intro inp C_cell C_bit P' ltCoords' finalNodes qMap' wsC regsC retHVal
    hinvC hcCeil hbCeil hbndC hr00
  obtain ⟨wsD, regsD, hexec, hinvD, _, hreadAns, hr0D⟩ :=
    exec_posDimStepD hd1 hn hL hB1 hW (by decide : 1 ≤ 4) hinvC hcCeil hbCeil hbndC
  have hk1 : finalNodes.length + 1 ≤ K_max + 1 := Nat.add_le_add_right hinvC.hk_le 1
  have hu_le : stepDUnitCost d s₀_d L finalNodes.length ≤ stepDUnitCost d s₀_d L K_max := by
    unfold stepDUnitCost
    have hm := Nat.mul_le_mul_right (s₀_d * (220 * d + 200) + 64 * L + 380) hk1
    omega
  have hb_le : stepDBitCost d s₀_d L W finalNodes.length ≤ stepDBitCost d s₀_d L W K_max := by
    unfold stepDBitCost
    have hm := Nat.mul_le_mul_right (s₀_d * (52 * d + 48) + 12 * L + 68) hk1
    exact Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by omega))
  refine ⟨wsD, regsD, hexec.weaken rfl rfl hu_le hb_le, hinvD, hr0D.trans hr00, ?_⟩
  dsimp only
  rw [hreadAns]

/-! ### 3. Fixed-`(c₁, C_nodes)` Positive-Dimension Las Vegas Wrapper over `CG07_SyncCtor` -/

noncomputable def c11ChooseC1 (h : S_clm_5_1_chain_contraction) : ℝ :=
  Classical.choose h

noncomputable def c11ChooseCNodes (h : S_clm_5_1_chain_contraction) : ℝ :=
  Classical.choose (Classical.choose_spec h)

theorem c11_lasVegas_dpos_fixed
    {d B n s₀_d : ℕ} (_hd1 : 1 ≤ d) (hn : 2 ≤ n) (_hB1 : 1 ≤ B) (hs₀ : 1 ≤ s₀_d)
    (h_lem_5_2 : S_lem_5_2)
    (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction)
    (h_clm_5_1_block_witness : S_clm_5_1_block_witness)
    {P_node_val P_tot_val : ℝ} (hPn_nn : 0 ≤ P_node_val)
    {ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d s₀_d)}
    (hctor : IsValidSyncNodeConstructor n (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ))) 1
      P_node_val (RatAdmissiblePointSet d B) ctor)
    (hctor_wk : ∀ hist sufPref ltCoords P₀ bs built,
      2 * s₀_d ≤ P₀.card →
      (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
        P₀.card ≤ built.work)
    (hC3_tot : ∀ adv : AdaptiveAdversary d,
      IsValidSyncAdaptiveAdversary n (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ)))
        (RatAdmissiblePointSet d B) ctor (ansPolPosDim d s₀_d (Nat.clog 2 (2 * n))) adv →
      ∀ T : ℕ, 1 ≤ T →
        syncPrefixExpectedRebuildWork (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ))) ctor
          (ansPolPosDim d s₀_d (Nat.clog 2 (2 * n))) adv T ≠ ⊤ ∧
        (syncPrefixExpectedRebuildWork (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ))) ctor
          (ansPolPosDim d s₀_d (Nat.clog 2 (2 * n))) adv T).toReal ≤
          (T : ℝ) * 1 * P_tot_val)
    {B_cert K_max W K_cancel P_step K_sim Space_bound : ℕ}
    {updStmt : BitRAMStmt}
    (hsim :
      let c₁ := c11ChooseC1 h_clm_5_1_chain_contraction
      let C_nodes := c11ChooseCNodes h_clm_5_1_chain_contraction
      let L := Nat.clog 2 (2 * n)
      (∀ (P : Finset ℕ), P.card ≤ n →
        ∀ (k : ℕ) (nodes : Fin k → ChainNode d)
          (P₀ : Fin k → Finset ℕ)
          (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
          (age : Fin k → ℕ)
          (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
              (paraboloidLiftSet (fun j : P₀ i => ltCoords j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput ltCoords nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * ((P₀ i).card : ℝ) / 16) →
          (k : ℝ) ≤ C_nodes * (1 / (4 * (s₀_d : ℝ)))⁻¹ * Real.log ((n : ℝ) + 1)) →
      ∀ (cur syncNext : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
        (qMap : ℕ → Fin d → ℚ) (ws : WordStore) (op : DynamicUpdate d) (bs : List Bool)
        (inp : BitRAMInput d),
        C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) cur →
        cur.nodes.length + 1 ≤ Nat.ceil ((C_nodes + 1) * 4) * s₀_d * L →
        C_nodes * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) ≤
          ((Nat.ceil ((C_nodes + 1) * 4) * s₀_d * L : ℕ) : ℝ) →
        ChainStoredInv n L B B_cert K_max W cur.pointSet cur.ltCoords cur.nodes qMap ws →
        IsLegalUpdate n (RatAdmissiblePointSet d B) cur.pointSet op →
        C12SyncStepDecomp s₀_d L ctor cur syncNext op bs →
        inp.activeHandles = cur.pointSet.activeHandles →
        (∀ h ∈ cur.pointSet.activeHandles, inp.activeRatCoords h = qMap h) →
        (match op with
         | .insert _ _ pt =>
             ∃ qIns : Fin d → ℚ,
               RatPointBitBounded B qIns ∧
               ratPointToEuclidean qIns = pt ∧
               inp.intParams = [(n : ℤ), 1, 0] ∧
               inp.extraRats = List.ofFn qIns
         | .delete id =>
             inp.intParams = [(n : ℤ), 0, (cur.pointSet.handleOfId id : ℤ)] ∧
             inp.extraRats = []) →
        inp.inputCellSpace ≤ n * (2 * d + 1) + 2 * d + 3 →
        inp.inputBitSpace ≤ n * (L + 1 + d * (2 * B + 1)) + d * (2 * B + 1) + 2 * L + 8 →
        ∃ (rawOut : BitRAMExecOutcome) (qMap' : ℕ → Fin d → ℚ),
          runBitRAMWithBits updStmt inp ws bs = some rawOut ∧
          ChainStoredInv n L B B_cert K_max W
            syncNext.pointSet syncNext.ltCoords syncNext.nodes qMap' rawOut.words ∧
          (match op with
           | .insert _ _ _ =>
               rawOut.words.read (.heap 0 0) = (mexHandle cur.pointSet.activeHandles : ℤ)
           | .delete _ => True) ∧
          (let ca := BitRAMDynamicProgram.readCachedAnswer rawOut.words
           ({ diameterHandles := ca.1, cachedDistSq := ca.2 } : StoredDiameterAnswer) =
             ramCheckedAnswer L syncNext.pointSet syncNext.nodes) ∧
          rawOut.bitCost + K_cancel * c12ChainBirthPot syncNext ≤
            P_step + K_cancel * c12ChainBirthPot cur +
              K_sim * (syncNext.totalRebuildWork - cur.totalRebuildWork) ∧
          rawOut.peakBitSpace ≤ Space_bound) :
    let prog : BitRAMDynamicProgram := { initStmt := .skip, updateStmt := updStmt }
    let initOut : BitRAMExecOutcome :=
      { words := WordStore.empty
        unitCost := 1
        bitCost := 1
        peakCellSpace := 1
        peakBitSpace := intBitLength (n : ℤ) }
    let alg := bitRAMAlg (d := d) n prog initOut
    prog.evalInit n d = some initOut ∧
    SatisfiesDynamicStorageAndQueryModel 5 1 alg ∧
    SatisfiesLasVegasGuarantee n (Real.sqrt 2)
      (1 + (P_step : ℝ) + (K_sim : ℝ) * P_tot_val)
      (RatAdmissiblePointSet d B) alg ∧
    SatisfiesUnboundedSpaceBound n (RatAdmissiblePointSet d B) alg
      (max (intBitLength (n : ℤ) : ℝ) (Space_bound : ℝ)) := by
  classical
  intro prog initOut alg
  let L := Nat.clog 2 (2 * n)
  have heval_init : prog.evalInit n d = some initOut := evalInit_of_initSkip n d updStmt
  have hmodel : SatisfiesDynamicStorageAndQueryModel 5 1 alg :=
    satisfiesDynamicStorage_of_initEmpty n prog initOut rfl
  let L_leaf : ℕ := 2 * s₀_d - 1
  let α : ℝ := 1 / (4 * (s₀_d : ℝ))
  let ansPol := ansPolPosDim d s₀_d L
  let P_α_d : ℝ := 4 * (s₀_d : ℝ)
  have hs₀_R : (1 : ℝ) ≤ (s₀_d : ℝ) := by exact_mod_cast hs₀
  have hPα_ge1 : 1 ≤ P_α_d := by dsimp only [P_α_d]; linarith
  have hα_pos : 0 < α := by dsimp only [α]; positivity
  have hα_le1 : α ≤ 1 := by
    dsimp only [α]; rw [div_le_one (by positivity)]; linarith
  have hbound_α : 1 / P_α_d ≤ α := le_rfl
  have hans : IsValidSyncCheckedAnswerPolicy n (Real.sqrt 2) ansPol :=
    isValidSyncCheckedAnswerPolicy_ansPolPosDim
  set c₁ := c11ChooseC1 h_clm_5_1_chain_contraction
  set C_nodes := c11ChooseCNodes h_clm_5_1_chain_contraction
  obtain ⟨hc₁_pos, hCn_pos, h51⟩ :=
    Classical.choose_spec (Classical.choose_spec h_clm_5_1_chain_contraction)
  have h51_len : ∀ (P : Finset ℕ), P.card ≤ n →
      ∀ (k : ℕ) (nodes : Fin k → ChainNode d)
        (P₀ : Fin k → Finset ℕ)
        (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
        (age : Fin k → ℕ)
        (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)),
        (∀ i : Fin k,
          (nodes i).o = o i ∧
          (nodes i).V = liftVariance (o i) (s i) ∧
          1 ≤ (P₀ i).card ∧
          IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
            (paraboloidLiftSet (fun j : P₀ i => ltCoords j.1)) (liftedPoint (o i) (s i)) ∧
          HasNodeAge (P₀ i) (chainInput ltCoords nodes P i.castSucc) (age i) ∧
          (age i : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * ((P₀ i).card : ℝ) / 16) →
        (k : ℝ) ≤ C_nodes * (1 / (4 * (s₀_d : ℝ)))⁻¹ * Real.log ((n : ℝ) + 1) := by
    intro P hP k nodes P₀ o s age ltCoords hchain
    exact ((h51 d ℕ ltCoords α hα_pos hα_le1).2 n P hP).1 k nodes P₀ o s age hchain |>.2.2
  have hstep_pf : ∀ (P : DynamicPointSet d) (ws : WordStore) (op : DynamicUpdate d)
      (b₁ b₂ : List Bool) (a₁ a₂ : DynamicPointSet d × DynamicStepOutcome WordStore),
      runSingleAdaptiveStep alg P ws op b₁ = some a₁ →
      runSingleAdaptiveStep alg P ws op b₂ = some a₂ →
      b₁ <+: b₂ → b₁ = b₂ := by
    intro P ws op b₁ b₂ a₁ a₂ h₁ h₂ hpref
    unfold runSingleAdaptiveStep at h₁ h₂
    cases hs₁ : alg.stepWithBits P.activeHandles P.handleCoords ws (toInternalUpdate P op) b₁ with
    | none => rw [hs₁] at h₁; cases h₁
    | some o₁ =>
        cases hs₂ : alg.stepWithBits P.activeHandles P.handleCoords ws (toInternalUpdate P op) b₂ with
        | none => rw [hs₂] at h₂; cases h₂
        | some o₂ => exact hmodel.2.2.1 _ _ _ _ b₁ b₂ o₁ o₂ hs₁ hs₂ hpref
  let StateRel (cur : SyncSchedulePrefixState d (PosDimNodeData d s₀_d)) (ws : WordStore) : Prop :=
    ∃ qMap : ℕ → Fin d → ℚ, ChainStoredInv n L B B_cert K_max W cur.pointSet cur.ltCoords cur.nodes qMap ws
  let StepMatch (cur syncNext : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
      (op : DynamicUpdate d)
      (res : DynamicPointSet d × DynamicStepOutcome WordStore) : Prop :=
    res.1 = syncNext.pointSet ∧
    C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) syncNext ∧
    StateRel syncNext res.2.nextState ∧
    res.2.returnedHandle = stepRetHandle mexHandle cur.pointSet.activeHandles op ∧
    res.2.storedAnswer = ansPol.checkedAnswer syncNext.pointSet syncNext.nodes ∧
    res.2.work + K_cancel * c12ChainBirthPot syncNext ≤
      P_step + K_cancel * c12ChainBirthPot cur +
        K_sim * (syncNext.totalRebuildWork - cur.totalRebuildWork) ∧
    res.2.peakSpace ≤ Space_bound
  have hstep_lock : ∀ (cur : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
      (ws : WordStore) (op : DynamicUpdate d),
      C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) cur →
      StateRel cur ws →
      IsLegalUpdate n (RatAdmissiblePointSet d B) cur.pointSet op →
      singleStepValidHaltProb alg cur.pointSet ws op = 1 ∧
      (∀ bs syncNext,
        runSingleSyncScheduleStep L_leaf α ctor ansPol cur op bs = some syncNext →
        ∃ res, runSingleAdaptiveStep alg cur.pointSet ws op bs = some res ∧
          StepMatch cur syncNext op res) ∧
      (∀ bs res,
        runSingleAdaptiveStep alg cur.pointSet ws op bs = some res →
        ∃ syncNext,
          runSingleSyncScheduleStep L_leaf α ctor ansPol cur op bs = some syncNext ∧
          StepMatch cur syncNext op res) := by
    intro cur ws op hinvS ⟨qMap, hinvR⟩ hleg
    have hprops := runSingleSyncScheduleStep_props hc₁_pos hCn_pos h51 hn hα_pos hα_le1
      hPα_ge1 hbound_α zero_le_one hPn_nn hctor hans hinvS.1 hleg
    have hhalt1 : haltProb (runSingleSyncScheduleStep L_leaf α ctor ansPol cur op) = 1 := hprops.1
    obtain ⟨hlog_le, hk_le, _⟩ := c12SyncInv_chain_len_bounds hn hs₀ hCn_pos h51 hinvS
    have hfwd : ∀ bs syncNext,
        runSingleSyncScheduleStep L_leaf α ctor ansPol cur op bs = some syncNext →
        ∃ res, runSingleAdaptiveStep alg cur.pointSet ws op bs = some res ∧
          StepMatch cur syncNext op res := by
      intro bs syncNext hfs
      obtain ⟨hinvS_next, hdec⟩ :=
        c12SyncStep_decomp hn hs₀ hc₁_pos hCn_pos h51 hPn_nn hctor hctor_wk hinvS hleg hfs
      obtain ⟨inp, hinp_H, hinp_q, hinp_sp, hinp_c, hinp_b, hunpack⟩ :=
        c12_evalUpdate_unpack hn rfl hinvR hleg prog initOut bs
      obtain ⟨rawOut, qMap', hrun, hinvR_next, hret0, hca_eq, hwk_le, hsp_le⟩ :=
        hsim h51_len cur syncNext qMap ws op bs inp
          hinvS hk_le hlog_le hinvR hleg hdec hinp_H hinp_q (by cases op <;> exact hinp_sp) hinp_c hinp_b
      have hadap := hunpack rawOut syncNext.pointSet hrun hdec.apply_eq (by cases op <;> exact hret0)
      have hans_eq : (ansPolPosDim d s₀_d L).checkedAnswer syncNext.pointSet syncNext.nodes =
          ramCheckedAnswer L syncNext.pointSet syncNext.nodes :=
        (ramCheckedAnswer_valid_of_chainStoredInv h_lem_5_2 h_clm_5_1_block_witness hinvR_next).2
      refine ⟨_, hadap, rfl, hinvS_next, ⟨qMap', hinvR_next⟩, rfl, ?_, hwk_le, hsp_le⟩
      dsimp only [ansPol]
      rw [hca_eq, hans_eq]
    have hlock := c12_lockstep_of_forward_and_haltProb_one
      (runSingleSyncScheduleStep L_leaf α ctor ansPol cur op)
      (runSingleAdaptiveStep alg cur.pointSet ws op)
      (fun syncNext res => StepMatch cur syncNext op res)
      hhalt1 (hstep_pf cur.pointSet ws op) hfwd
    exact ⟨hlock.1, hfwd, hlock.2.2⟩
  let PrefixMatch (bitTrace : List (List Bool))
      (syncSt : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
      (adapSt : AdaptivePrefixState d WordStore) : Prop :=
    C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) syncSt ∧
    StateRel syncSt adapSt.algState ∧
    adapSt.pointSet = syncSt.pointSet ∧
    adapSt.history = syncSt.history ∧
    adapSt.snapshots = syncSt.snapshots ∧
    adapSt.totalWork + K_cancel * c12ChainBirthPot syncSt ≤
      1 + bitTrace.length * P_step + K_sim * syncSt.totalRebuildWork ∧
    adapSt.maxSpace ≤ max (intBitLength (n : ℤ)) Space_bound
  have htrace_lock : ∀ (adv : AdaptiveAdversary d),
      IsValidAdaptiveAdversary n (RatAdmissiblePointSet d B) alg adv →
      ∀ (bitTrace : List (List Bool)),
        (∀ syncSt,
          runSyncScheduleSteps L_leaf α ctor ansPol adv bitTrace = some syncSt →
          ∃ adapSt, runAdaptiveSteps alg adv bitTrace = some adapSt ∧
            PrefixMatch bitTrace syncSt adapSt) ∧
        (∀ adapSt,
          runAdaptiveSteps alg adv bitTrace = some adapSt →
          ∃ syncSt, runSyncScheduleSteps L_leaf α ctor ansPol adv bitTrace = some syncSt ∧
            PrefixMatch bitTrace syncSt adapSt) := by
    intro adv hadv bitTrace
    induction bitTrace using List.reverseRecOn with
    | nil =>
        have hrel0 : StateRel (initSyncSchedulePrefixState d (PosDimNodeData d s₀_d)) initOut.words :=
          ⟨fun _ _ => 0, ChainStoredInv.init⟩
        have hpm0 : PrefixMatch [] (initSyncSchedulePrefixState d (PosDimNodeData d s₀_d))
            (initAdaptivePrefixState alg) := by
          refine ⟨c12SyncInv_init _ _ _ _ _ _, hrel0, rfl, rfl, rfl, ?_, le_max_left _ _⟩
          simp [initAdaptivePrefixState, initSyncSchedulePrefixState, c12ChainBirthPot, alg, bitRAMAlg, initOut]
        constructor
        · intro syncSt hs
          simp only [runSyncScheduleSteps, runSyncScheduleStepsFrom, Option.some.injEq] at hs
          subst hs
          exact ⟨initAdaptivePrefixState alg, rfl, hpm0⟩
        · intro adapSt ha
          simp only [runAdaptiveSteps, runAdaptiveStepsFrom, Option.some.injEq] at ha
          subst ha
          exact ⟨initSyncSchedulePrefixState d (PosDimNodeData d s₀_d), rfl, hpm0⟩
    | append_singleton xs bs ih =>
        have hstep_both :
            ∀ (midS : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
              (midA : AdaptivePrefixState d WordStore),
              runAdaptiveSteps alg adv xs = some midA →
              PrefixMatch xs midS midA →
              (∀ syncNext,
                runSingleSyncScheduleStep L_leaf α ctor ansPol midS (adv midS.history) bs = some syncNext →
                ∃ adapNext,
                  runAdaptiveStepsFrom alg adv midA [bs] = some adapNext ∧
                  PrefixMatch (xs ++ [bs]) syncNext adapNext) ∧
              (∀ adapNext,
                runAdaptiveStepsFrom alg adv midA [bs] = some adapNext →
                ∃ syncNext,
                  runSingleSyncScheduleStep L_leaf α ctor ansPol midS (adv midS.history) bs = some syncNext ∧
                  PrefixMatch (xs ++ [bs]) syncNext adapNext) := by
          intro midS midA hmidA ⟨hinvM, hrelM, hpEq, hhEq, hsnEq, hwM, hspM⟩
          have hlegA := hadv xs midA hmidA
          have hlegS : IsLegalUpdate n (RatAdmissiblePointSet d B) midS.pointSet (adv midS.history) := by
            rwa [hpEq, hhEq] at hlegA
          let op := adv midS.history
          have hsl := hstep_lock midS midA.algState op hinvM hrelM hlegS
          constructor
          · intro syncNext hfs
            obtain ⟨_, hdec⟩ :=
              c12SyncStep_decomp hn hs₀ hc₁_pos hCn_pos h51 hPn_nn hctor hctor_wk hinvM hlegS hfs
            obtain ⟨⟨P', outStep⟩, hgs, hp', hinv', hrel', hret', hans', hw', hsp'⟩ := hsl.2.1 bs syncNext hfs
            dsimp only at hp' hrel' hret' hans' hw' hsp'
            subst hp'
            have hadap_step :
                runAdaptiveStepsFrom alg adv midA [bs] =
                  some
                    { pointSet := syncNext.pointSet
                      algState := outStep.nextState
                      history := midA.history ++
                        [{ operation := adv midA.history
                           randomBits := bs
                           returnedHandle := outStep.returnedHandle
                           answer := outStep.storedAnswer
                           resolvedIds := resolveAnswerIdentities syncNext.pointSet outStep.storedAnswer }]
                      snapshots := midA.snapshots ++ [(syncNext.pointSet, outStep.storedAnswer)]
                      stepWorks := midA.stepWorks ++ [outStep.work]
                      totalWork := midA.totalWork + outStep.work
                      maxSpace := max midA.maxSpace outStep.peakSpace } := by
              simp only [runAdaptiveStepsFrom]
              have hgs' : runSingleAdaptiveStep alg midA.pointSet midA.algState (adv midA.history) bs =
                  some (syncNext.pointSet, outStep) := by
                rwa [hpEq, hhEq]
              rw [hgs']
            refine ⟨_, hadap_step, hinv', hrel', rfl, ?_, ?_, ?_, ?_⟩
            · dsimp only [ansPol] at hans'
              dsimp only
              rw [hhEq, hret', hans', hdec.history_eq]
            · dsimp only [ansPol] at hans'
              dsimp only
              rw [hsnEq, hans', hdec.snapshots_eq]
            · dsimp only
              simp only [List.length_append, List.length_singleton]
              have hmul : (xs.length + 1) * P_step = xs.length * P_step + P_step := by ring
              have htrw : K_sim * midS.totalRebuildWork +
                  K_sim * (syncNext.totalRebuildWork - midS.totalRebuildWork) =
                  K_sim * syncNext.totalRebuildWork := by
                rw [← Nat.mul_add, Nat.add_sub_of_le hdec.work_mono]
              have := hwM; have := hw'; omega
            · dsimp only
              exact max_le hspM (hsp'.trans (le_max_right _ _))
          · intro adapNext has
            simp only [runAdaptiveStepsFrom] at has
            cases hgsA : runSingleAdaptiveStep alg midA.pointSet midA.algState (adv midA.history) bs with
            | none => simp [hgsA] at has
            | some pair =>
                rcases pair with ⟨P', outStep⟩
                simp only [hgsA, Option.some.injEq] at has
                have hgsS : runSingleAdaptiveStep alg midS.pointSet midA.algState op bs =
                    some (P', outStep) := by
                  dsimp only [op]; rwa [hpEq, hhEq] at hgsA
                obtain ⟨syncNext, hfs, hp', hinv', hrel', hret', hans', hw', hsp'⟩ :=
                  hsl.2.2 bs (P', outStep) hgsS
                dsimp only at hp' hrel' hret' hans' hw' hsp'
                subst hp'; subst has
                obtain ⟨_, hdec⟩ :=
                  c12SyncStep_decomp hn hs₀ hc₁_pos hCn_pos h51 hPn_nn hctor hctor_wk hinvM hlegS hfs
                refine ⟨syncNext, hfs, hinv', hrel', rfl, ?_, ?_, ?_, ?_⟩
                · dsimp only [ansPol] at hans'
                  dsimp only
                  rw [hhEq, hret', hans', hdec.history_eq]
                · dsimp only [ansPol] at hans'
                  dsimp only
                  rw [hsnEq, hans', hdec.snapshots_eq]
                · dsimp only
                  simp only [List.length_append, List.length_singleton]
                  have hmul : (xs.length + 1) * P_step = xs.length * P_step + P_step := by ring
                  have htrw : K_sim * midS.totalRebuildWork +
                      K_sim * (syncNext.totalRebuildWork - midS.totalRebuildWork) =
                      K_sim * syncNext.totalRebuildWork := by
                    rw [← Nat.mul_add, Nat.add_sub_of_le hdec.work_mono]
                  have := hwM; have := hw'; omega
                · dsimp only
                  exact max_le hspM (hsp'.trans (le_max_right _ _))
        constructor
        · intro syncNext hrunS
          unfold runSyncScheduleSteps at hrunS
          rw [runSyncScheduleStepsFrom_append] at hrunS
          cases hmidS : runSyncScheduleStepsFrom L_leaf α ctor ansPol adv
              (initSyncSchedulePrefixState d (PosDimNodeData d s₀_d)) xs with
          | none => rw [hmidS] at hrunS; cases hrunS
          | some midS =>
              rw [hmidS] at hrunS; dsimp only at hrunS
              obtain ⟨midA, hmidA, hpm⟩ := ih.1 midS hmidS
              obtain ⟨adapNext, has, hpm'⟩ := (hstep_both midS midA hmidA hpm).1 syncNext hrunS
              refine ⟨adapNext, ?_, hpm'⟩
              unfold runAdaptiveSteps at hmidA ⊢
              rw [c12_runAdaptiveStepsFrom_append, hmidA]
              exact has
        · intro adapNext hrunA
          unfold runAdaptiveSteps at hrunA
          rw [c12_runAdaptiveStepsFrom_append] at hrunA
          cases hmidA : runAdaptiveStepsFrom alg adv (initAdaptivePrefixState alg) xs with
          | none => rw [hmidA] at hrunA; cases hrunA
          | some midA =>
              rw [hmidA] at hrunA; dsimp only at hrunA
              obtain ⟨midS, hmidS, hpm⟩ := ih.2 midA hmidA
              obtain ⟨syncNext, hfs, hpm'⟩ := (hstep_both midS midA hmidA hpm).2 adapNext hrunA
              refine ⟨syncNext, ?_, hpm'⟩
              unfold runSyncScheduleSteps at hmidS ⊢
              rw [runSyncScheduleStepsFrom_append, hmidS]
              exact hfs
  have hadv_sync : ∀ adv : AdaptiveAdversary d,
      IsValidAdaptiveAdversary n (RatAdmissiblePointSet d B) alg adv →
      IsValidSyncAdaptiveAdversary n L_leaf α (RatAdmissiblePointSet d B) ctor ansPol adv := by
    intro adv hadv bitTrace syncSt hrunS
    obtain ⟨adapSt, hrunA, hpm⟩ := (htrace_lock adv hadv bitTrace).1 syncSt hrunS
    have hlegA := hadv bitTrace adapSt hrunA
    rwa [hpm.2.2.1, hpm.2.2.2.1] at hlegA
  refine ⟨heval_init, hmodel, ⟨?_, ?_⟩, ⟨le_max_left _ _, ?_⟩⟩
  · intro adv hadv
    refine ⟨fun bitTrace prefSt hrunA => ?_, fun T trace out hrunA => ?_⟩
    · obtain ⟨syncSt, _, hpm⟩ := (htrace_lock adv hadv bitTrace).2 prefSt hrunA
      have hlegA := hadv bitTrace prefSt hrunA
      have hlegS : IsLegalUpdate n (RatAdmissiblePointSet d B) syncSt.pointSet (adv syncSt.history) := by
        rwa [hpm.2.2.1, hpm.2.2.2.1] at hlegA
      have hsl := hstep_lock syncSt prefSt.algState (adv syncSt.history) hpm.1 hpm.2.1 hlegS
      rw [hpm.2.2.1, hpm.2.2.2.1]
      exact hsl.1
    · unfold runAdaptivePrefix at hrunA
      obtain ⟨syncSt, _, hpm⟩ := (htrace_lock adv hadv (List.ofFn trace)).2 out hrunA
      unfold AllPrefixAnswersValid
      rw [hpm.2.2.2.2.1]
      rcases hpm.1 with ⟨⟨_, _, _, _, _, _, hsnaps_valid, _⟩, _⟩
      exact hsnaps_valid
  · intro adv hadv T hT
    have hsync_adv := hadv_sync adv hadv
    obtain ⟨htot_fin, htot_le⟩ := hC3_tot adv hsync_adv T hT
    have hprob_work := syncPrefix_prob_and_work hc₁_pos hCn_pos h51 hn hα_pos hα_le1
      hPα_ge1 hbound_α zero_le_one hPn_nn hctor hans hsync_adv T
    have hprob1 := hprob_work.1
    let C_base : ℕ := 1 + T * P_step
    have hwork_le_sum :
        adaptivePrefixExpectedWork alg adv T ≤
          (C_base : ENNReal) +
            (K_sim : ENNReal) * syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv T := by
      have hadap_elim :
          adaptivePrefixExpectedWork alg adv T =
            ∑' tr : Fin T → List Bool,
              Option.elim (runAdaptivePrefix alg adv T tr) 0
                (fun out => prefixTraceProb tr * (out.totalWork : ENNReal)) := by
        unfold adaptivePrefixExpectedWork; congr 1; ext tr
        cases runAdaptivePrefix alg adv T tr <;> rfl
      have hsync_elim :
          syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv T =
            ∑' tr : Fin T → List Bool,
              Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr) 0
                (fun syncOut => prefixTraceProb tr * (syncOut.totalRebuildWork : ENNReal)) := by
        unfold syncPrefixExpectedRebuildWork; congr 1; ext tr
        cases runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr <;> rfl
      rw [hadap_elim, hsync_elim]
      have hpointwise :
          ∀ tr : Fin T → List Bool,
            Option.elim (runAdaptivePrefix alg adv T tr) 0
              (fun out => prefixTraceProb tr * (out.totalWork : ENNReal)) ≤
            (if (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr).isSome then
               prefixTraceProb tr
             else 0) * (C_base : ENNReal) +
            (K_sim : ENNReal) *
              Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr) 0
                (fun syncOut => prefixTraceProb tr * (syncOut.totalRebuildWork : ENNReal)) := by
        intro tr
        cases ha : runAdaptivePrefix alg adv T tr with
        | none => simp
        | some adapOut =>
            obtain ⟨syncOut, hs, hpm⟩ := (htrace_lock adv hadv (List.ofFn tr)).2 adapOut ha
            have hs_pref : runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr = some syncOut := hs
            rw [hs_pref]
            simp only [Option.elim_some, Option.isSome_some, ↓reduceIte]
            have hw_nat : adapOut.totalWork ≤ C_base + K_sim * syncOut.totalRebuildWork := by
              have hlen_tr : (List.ofFn tr).length = T := List.length_ofFn
              have hpm_w := hpm.2.2.2.2.2.1
              rw [hlen_tr] at hpm_w
              dsimp only [C_base]
              omega
            calc
              prefixTraceProb tr * (adapOut.totalWork : ENNReal)
                  ≤ prefixTraceProb tr * ((C_base + K_sim * syncOut.totalRebuildWork : ℕ) : ENNReal) :=
                    mul_le_mul_of_nonneg_left (Nat.cast_le.mpr hw_nat) (zero_le _)
              _ = prefixTraceProb tr * (C_base : ENNReal) +
                    (K_sim : ENNReal) * (prefixTraceProb tr * (syncOut.totalRebuildWork : ENNReal)) := by
                    push_cast; ring
      calc
        (∑' tr : Fin T → List Bool,
          Option.elim (runAdaptivePrefix alg adv T tr) 0
            (fun out => prefixTraceProb tr * (out.totalWork : ENNReal)))
            ≤ ∑' tr : Fin T → List Bool,
                ((if (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr).isSome then
                    prefixTraceProb tr
                  else 0) * (C_base : ENNReal) +
                 (K_sim : ENNReal) *
                  Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr) 0
                    (fun syncOut => prefixTraceProb tr * (syncOut.totalRebuildWork : ENNReal))) :=
              ENNReal.tsum_le_tsum hpointwise
        _ = (C_base : ENNReal) +
              (K_sim : ENNReal) *
                ∑' tr : Fin T → List Bool,
                  Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv T tr) 0
                    (fun syncOut => prefixTraceProb tr * (syncOut.totalRebuildWork : ENNReal)) := by
              rw [ENNReal.tsum_add, ENNReal.tsum_mul_right, hprob1, one_mul, ENNReal.tsum_mul_left]
    have hrhs_fin :
        (C_base : ENNReal) +
          (K_sim : ENNReal) * syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv T ≠ ⊤ :=
      ENNReal.add_ne_top.mpr
        ⟨ENNReal.natCast_ne_top _,
         ENNReal.mul_ne_top (ENNReal.natCast_ne_top _) htot_fin⟩
    have hexp_fin : adaptivePrefixExpectedWork alg adv T ≠ ⊤ :=
      ne_top_of_le_ne_top hrhs_fin hwork_le_sum
    refine ⟨hexp_fin, ?_⟩
    have htoReal_le := ENNReal.toReal_mono hrhs_fin hwork_le_sum
    rw [ENNReal.toReal_add (ENNReal.natCast_ne_top _)
          (ENNReal.mul_ne_top (ENNReal.natCast_ne_top _) htot_fin),
        ENNReal.toReal_natCast,
        ENNReal.toReal_mul,
        ENNReal.toReal_natCast] at htoReal_le
    rw [div_le_iff₀ (by exact_mod_cast (show 0 < T by omega))]
    have hT_ge1 : (1 : ℝ) ≤ (T : ℝ) := by exact_mod_cast hT
    have hC_base_R : (C_base : ℝ) = 1 + (T : ℝ) * (P_step : ℝ) := by
      dsimp only [C_base]; push_cast; ring
    rw [hC_base_R] at htoReal_le
    have hK_mul :
        (K_sim : ℝ) * (syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv T).toReal ≤
          (K_sim : ℝ) * ((T : ℝ) * P_tot_val) := by
      refine mul_le_mul_of_nonneg_left ?_ (Nat.cast_nonneg _)
      linarith only [htot_le]
    nlinarith only [htoReal_le, hT_ge1, hK_mul]
  · intro adv hadv T trace out hrunA
    unfold runAdaptivePrefix at hrunA
    obtain ⟨_, _, hpm⟩ := (htrace_lock adv hadv (List.ofFn trace)).2 out hrunA
    have hsp_nat := hpm.2.2.2.2.2.2
    have hcast : ((max (intBitLength (n : ℤ)) Space_bound : ℕ) : ℝ) =
        max (intBitLength (n : ℤ) : ℝ) (Space_bound : ℝ) := by
      push_cast; rfl
    rw [← hcast]
    exact_mod_cast hsp_nat

end UL.C12LVE
