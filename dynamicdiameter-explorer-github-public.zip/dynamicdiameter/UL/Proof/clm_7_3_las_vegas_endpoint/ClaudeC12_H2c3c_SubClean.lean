import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2c3a_SubSteps
set_option autoImplicit false
set_option maxHeartbeats 800000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

private theorem ws_write_live (w : WordStore) (l : RAMCellLoc) (v : ℤ) :
    (w.write l v).live = insert l w.live := rfl
private theorem ws_write_vals (w : WordStore) (l : RAMCellLoc) (v : ℤ) :
    (w.write l v).vals = Function.update w.vals l v := rfl
private theorem ws_free_live (w : WordStore) (l : RAMCellLoc) :
    (w.free l).live = w.live.erase l := rfl
private theorem ws_free_vals (w : WordStore) (l : RAMCellLoc) :
    (w.free l).vals = Function.update w.vals l 0 := rfl

private theorem ws_free4_live (w : WordStore) (l₁ l₂ l₃ l₄ x : RAMCellLoc) :
    x ∈ ((((w.free l₁).free l₂).free l₃).free l₄).live ↔
      x ≠ l₄ ∧ x ≠ l₃ ∧ x ≠ l₂ ∧ x ≠ l₁ ∧ x ∈ w.live := by
  simp only [ws_free_live, Finset.mem_erase, and_assoc]

private theorem ws_free4_vals_ne (w : WordStore) {l₁ l₂ l₃ l₄ x : RAMCellLoc}
    (h₄ : x ≠ l₄) (h₃ : x ≠ l₃) (h₂ : x ≠ l₂) (h₁ : x ≠ l₁) :
    ((((w.free l₁).free l₂).free l₃).free l₄).vals x = w.vals x := by
  rw [ws_free_vals, Function.update_of_ne h₄,
      ws_free_vals, Function.update_of_ne h₃,
      ws_free_vals, Function.update_of_ne h₂,
      ws_free_vals, Function.update_of_ne h₁]

private theorem ws_wf_free_live (w : WordStore) (lw lf x : RAMCellLoc) (v : ℤ) :
    x ∈ ((w.free lf).write lw v).live ↔ x = lw ∨ (x ≠ lf ∧ x ∈ w.live) := by
  simp only [ws_write_live, ws_free_live, Finset.mem_insert, Finset.mem_erase]

private theorem ws_wf_free_vals_ne (w : WordStore) {lw lf x : RAMCellLoc} (v : ℤ)
    (hw : x ≠ lw) (hf : x ≠ lf) :
    ((w.free lf).write lw v).vals x = w.vals x := by
  rw [ws_write_vals, Function.update_of_ne hw, ws_free_vals, Function.update_of_ne hf]

private theorem ws_write_eq_free_write (w : WordStore) (l : RAMCellLoc) (v : ℤ) :
    w.write l v = (w.free l).write l v := by
  cases w with
  | mk lv vl =>
      unfold WordStore.write WordStore.free; dsimp only
      congr 1
      · ext x; simp only [Finset.mem_insert, Finset.mem_erase]
        constructor
        · rintro (rfl | h); · exact Or.inl rfl
          by_cases hx : x = l; · exact Or.inl hx
          · exact Or.inr ⟨hx, h⟩
        · rintro (rfl | ⟨_, h⟩); · exact Or.inl rfl
          · exact Or.inr h
      · funext x; by_cases hx : x = l
        · subst hx; simp only [Function.update_self]
        · simp only [Function.update_of_ne hx]

/-! ### Linear-time memory reclamation `exec_cleanupA2Stmt` via `bitSize` Lyapunov potential -/

private structure CleanupLoopInv (wsStart : WordStore) (highSid : ℕ)
    (sidOfEnc : ℤ → Option ℕ) (s : ℕ) (ws : WordStore) : Prop where
  wf : WellFormedWS ws
  has12_1 : (.heap 12 1 : RAMCellLoc) ∈ ws.live ∧ ws.vals (.heap 12 1) = (s : ℤ)
  tab10_13 : ∀ (t : ℕ), (t = 10 ∨ t = 13) → ∀ e : ℤ,
    ((∃ s' < s, sidOfEnc e = some s') → (.heap t e : RAMCellLoc) ∉ ws.live) ∧
    ((¬ ∃ s' < s, sidOfEnc e = some s') →
      ((.heap t e : RAMCellLoc) ∈ ws.live ↔ (.heap t e : RAMCellLoc) ∈ wsStart.live) ∧
      ws.vals (.heap t e) = wsStart.vals (.heap t e))
  tab14_15_16 : ∀ (t : ℕ), (t = 14 ∨ t = 15 ∨ t = 16) → ∀ z : ℤ,
    (0 ≤ z ∧ z.toNat < s → (.heap t z : RAMCellLoc) ∉ ws.live) ∧
    (¬ (0 ≤ z ∧ z.toNat < s) →
      ((.heap t z : RAMCellLoc) ∈ ws.live ↔ (.heap t z : RAMCellLoc) ∈ wsStart.live) ∧
      ws.vals (.heap t z) = wsStart.vals (.heap t z))
  other_loc : ∀ loc : RAMCellLoc,
    loc ≠ .heap 12 1 →
    (∀ e, loc ≠ .heap 10 e ∧ loc ≠ .heap 13 e) →
    (∀ z, loc ≠ .heap 14 z ∧ loc ≠ .heap 15 z ∧ loc ≠ .heap 16 z) →
    (loc ∈ ws.live ↔ loc ∈ wsStart.live) ∧ ws.vals loc = wsStart.vals loc

private def cleanupStepAStmt : BitRAMStmt :=
  .ite (.intEq (.readHeap 16 (.readHeap 12 (.lit 1))) (.lit 1))
    (.seq (.freeHeap 10 (.readHeap 15 (.readHeap 12 (.lit 1))))
    (.seq (.freeHeap 13 (.readHeap 15 (.readHeap 12 (.lit 1))))
    (.seq (.freeHeap 15 (.readHeap 12 (.lit 1)))
          (.freeHeap 16 (.readHeap 12 (.lit 1))))))
    .skip

private def cleanupLoopBody : BitRAMStmt :=
  .seq cleanupStepAStmt
    (.seq (.freeHeap 14 (.readHeap 12 (.lit 1)))
          (.writeHeap 12 (.lit 1) (.add (.readHeap 12 (.lit 1)) (.lit 1))))

private theorem exec_cleanupStepA {d T_max S_max : ℕ}
    {wsBaseNew wsSubHeap wsStart : WordStore}
    {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (inpSim : BitRAMInput d)
    (hinv : A2SimInv wsBaseNew T_max S_max wsSubHeap wsStart highSid sidOfEnc encOfSid freeStack)
    {s S_bits C_cell C_bit : ℕ} (hs_lt : s < highSid)
    (hs_bl : intBitLength (s : ℤ) ≤ S_bits)
    (stCur : BitRAMExecState)
    (hInv : CleanupLoopInv wsStart highSid sidOfEnc s stCur.words)
    (hpCC : stCur.peakCellSpace ≤ C_cell)
    (hpBC : stCur.peakBitSpace ≤ C_bit) :
    ∃ stA : BitRAMExecState,
      RunsTo inpSim [.stmt cleanupStepAStmt] stCur stA ∧
      stA.words = (if s ∉ freeStack then
        (((stCur.words.free (.heap 10 (encOfSid s))).free (.heap 13 (encOfSid s))).free
          (.heap 15 (s : ℤ))).free (.heap 16 (s : ℤ))
        else stCur.words) ∧
      stA.words.cellCount ≤ stCur.words.cellCount ∧
      stA.words.bitSize ≤ stCur.words.bitSize ∧
      stA.frameDepth = stCur.frameDepth ∧
      stA.remainingBits = stCur.remainingBits ∧
      stA.unitCost ≤ stCur.unitCost + 20 ∧
      stA.bitCost + 8 * stA.words.bitSize ≤
        stCur.bitCost + 8 * stCur.words.bitSize + 14 * S_bits + 96 ∧
      stA.peakCellSpace ≤ C_cell ∧
      stA.peakBitSpace ≤ C_bit := by
  have h10 : natBitLength 10 = 4 := by decide
  have h12 : natBitLength 12 = 4 := by decide
  have h13 : natBitLength 13 = 4 := by decide
  have h15 : natBitLength 15 = 4 := by decide
  have h16 : natBitLength 16 = 5 := by decide
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  have hr_12_1 : stCur.words.read (.heap 12 1) = (s : ℤ) := by
    rw [wordStore_read_eq_vals hInv.wf]; exact hInv.has12_1.2
  have hn_lt_s : ¬ (0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < s) := by simp
  have h16_cur := (hInv.tab14_15_16 16 (Or.inr (Or.inr rfl)) (s : ℤ)).2 hn_lt_s
  have hr_16_s : stCur.words.read (.heap 16 (s : ℤ)) = wsStart.read (.heap 16 (s : ℤ)) := by
    rw [wordStore_read_eq_vals hInv.wf, wordStore_read_eq_vals hinv.wfSim]; exact h16_cur.2
  by_cases hnf : s ∉ freeStack
  · have hz_ok : 0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack := by
      simp [hs_lt, hnf]
    have h15_16 := (hinv.tab15_16_spec (s : ℤ)).1 hz_ok
    simp only [Int.toNat_natCast] at h15_16
    have hr16_eq1 : stCur.words.read (.heap 16 (s : ℤ)) = 1 := by
      rw [hr_16_s, wordStore_read_eq_vals hinv.wfSim]; exact h15_16.2.2.2
    have hcondA : evalBitCond inpSim stCur.frameDepth stCur.words
        (.intEq (.readHeap 16 (.readHeap 12 (.lit 1))) (.lit 1)) =
        (true, 5, 21 + 2 * intBitLength (s : ℤ)) := by
      simp only [evalBitCond, evalIntExpr, hr_12_1, hr16_eq1]
      simp only [h12, h16, hl1]
      exact Prod.ext rfl (Prod.ext rfl (by ring))
    set e := encOfSid s
    have h15_cur := (hInv.tab14_15_16 15 (Or.inr (Or.inl rfl)) (s : ℤ)).2 hn_lt_s
    have hm15_cur : (.heap 15 (s : ℤ) : RAMCellLoc) ∈ stCur.words.live :=
      h15_cur.1.mpr h15_16.1
    have hv15_cur : stCur.words.vals (.heap 15 (s : ℤ)) = e :=
      h15_cur.2.trans h15_16.2.1
    have hr15_cur : stCur.words.read (.heap 15 (s : ℤ)) = e := by
      rw [wordStore_read_eq_vals hInv.wf]; exact hv15_cur
    let stA0 : BitRAMExecState :=
      { stCur with unitCost := stCur.unitCost + 5, bitCost := stCur.bitCost + (21 + 2 * intBitLength (s : ℤ)) }
    obtain ⟨stA1, hf1, hwA1, hfdA1, hrbA1, hucA1, hbcA1, hpCA1, hpBA1⟩ :=
      exec_freeHeap_ceil inpSim 10 (.readHeap 15 (.readHeap 12 (.lit 1))) stA0 hpCC hpBC
        (idx := e) (u₁ := 3) (b₁ := 12 + 2 * intBitLength (s : ℤ) + intBitLength e)
        (evalIntLe_read_read12 inpSim stA0.frameDepth stA0.words 15 1 _ _
          (b := 12 + 2 * intBitLength (s : ℤ) + intBitLength e) hr_12_1 hr15_cur h15 hl1 (le_of_eq (by ring)))
    have hrA1_12_1 : stA1.words.read (.heap 12 1) = (s : ℤ) := by
      rw [hwA1, wordStore_read_free_ne _ (by simp)]; exact hr_12_1
    have hrA1_15_s : stA1.words.read (.heap 15 (s : ℤ)) = e := by
      rw [hwA1, wordStore_read_free_ne _ (by simp)]; exact hr15_cur
    obtain ⟨stA2, hf2, hwA2, hfdA2, hrbA2, hucA2, hbcA2, hpCA2, hpBA2⟩ :=
      exec_freeHeap_ceil inpSim 13 (.readHeap 15 (.readHeap 12 (.lit 1))) stA1 hpCA1 hpBA1
        (idx := e) (u₁ := 3) (b₁ := 12 + 2 * intBitLength (s : ℤ) + intBitLength e)
        (evalIntLe_read_read12 inpSim stA1.frameDepth stA1.words 15 1 _ _
          (b := 12 + 2 * intBitLength (s : ℤ) + intBitLength e) hrA1_12_1 hrA1_15_s h15 hl1 (le_of_eq (by ring)))
    have hrA2_12_1 : stA2.words.read (.heap 12 1) = (s : ℤ) := by
      rw [hwA2, wordStore_read_free_ne _ (by simp)]; exact hrA1_12_1
    obtain ⟨stA3, hf3, hwA3, hfdA3, hrbA3, hucA3, hbcA3, hpCA3, hpBA3⟩ :=
      exec_freeHeap_ceil inpSim 15 (.readHeap 12 (.lit 1)) stA2 hpCA2 hpBA2
        (idx := (s : ℤ)) (u₁ := 2) (b₁ := 8 + intBitLength (s : ℤ))
        (evalIntLe_readHeap_lit inpSim stA2.frameDepth stA2.words 12 1 _
          (b := 8 + intBitLength (s : ℤ)) hrA2_12_1 h12 hl1 (le_of_eq (by ring)))
    have hrA3_12_1 : stA3.words.read (.heap 12 1) = (s : ℤ) := by
      rw [hwA3, wordStore_read_free_ne _ (by simp)]; exact hrA2_12_1
    obtain ⟨stA4, hf4, hwA4, hfdA4, hrbA4, hucA4, hbcA4, hpCA4, hpBA4⟩ :=
      exec_freeHeap_ceil inpSim 16 (.readHeap 12 (.lit 1)) stA3 hpCA3 hpBA3
        (idx := (s : ℤ)) (u₁ := 2) (b₁ := 8 + intBitLength (s : ℤ))
        (evalIntLe_readHeap_lit inpSim stA3.frameDepth stA3.words 12 1 _
          (b := 8 + intBitLength (s : ℤ)) hrA3_12_1 h12 hl1 (le_of_eq (by ring)))
    have hiteA : RunsTo inpSim [.stmt cleanupStepAStmt] stCur stA4 := by
      unfold cleanupStepAStmt
      apply RunsTo.ite; rw [hcondA]; dsimp only; simp only [↓reduceIte]
      exact RunsTo.seq hf1 (RunsTo.seq hf2 (RunsTo.seq hf3 hf4))
    have hm15_A2 : (.heap 15 (s : ℤ) : RAMCellLoc) ∈ stA2.words.live := by
      rw [hwA2, hwA1]; dsimp [stA0]
      simp only [ws_free_live, Finset.mem_erase]
      exact ⟨by simp, by simp, hm15_cur⟩
    have hv15_A2 : stA2.words.vals (.heap 15 (s : ℤ)) = e := by
      rw [hwA2, hwA1]; dsimp [stA0]
      rw [ws_free_vals, Function.update_of_ne (by simp), ws_free_vals, Function.update_of_ne (by simp)]
      exact hv15_cur
    have hdrop15 := bitSize_free_mem hm15_A2
    rw [hv15_A2] at hdrop15
    have hwA1' : stA1.words = stCur.words.free (.heap 10 e) := hwA1
    have hb_chain : stA4.words.bitSize + intBitLength e ≤ stCur.words.bitSize := by
      have b4 := bitSize_free_le stA3.words (.heap 16 (s : ℤ))
      have b2 := bitSize_free_le stA1.words (.heap 13 e)
      have b1 := bitSize_free_le stCur.words (.heap 10 e)
      rw [← hwA4] at b4; rw [← hwA3] at hdrop15; rw [← hwA2] at b2; rw [← hwA1'] at b1
      linarith only [b4, hdrop15, b2, b1]
    have hc_chain : stA4.words.cellCount ≤ stCur.words.cellCount := by
      have c4 := cellCount_free_le stA3.words (.heap 16 (s : ℤ))
      have c3 := cellCount_free_le stA2.words (.heap 15 (s : ℤ))
      have c2 := cellCount_free_le stA1.words (.heap 13 e)
      have c1 := cellCount_free_le stCur.words (.heap 10 e)
      rw [← hwA4] at c4; rw [← hwA3] at c3; rw [← hwA2] at c2; rw [← hwA1'] at c1
      linarith only [c4, c3, c2, c1]
    refine ⟨stA4, hiteA, by rw [if_pos hnf, hwA4, hwA3, hwA2, hwA1],
      hc_chain, by linarith only [hb_chain],
      by rw [hfdA4, hfdA3, hfdA2, hfdA1],
      by rw [hrbA4, hrbA3, hrbA2, hrbA1],
      ?_, ?_, hpCA4, hpBA4⟩
    · have h0_uc : stA0.unitCost = stCur.unitCost + 5 := rfl
      linarith only [h0_uc, hucA1, hucA2, hucA3, hucA4]
    · have h0_bc : stA0.bitCost = stCur.bitCost + (21 + 2 * intBitLength (s : ℤ)) := rfl
      rw [h10] at hbcA1; rw [h13] at hbcA2; rw [h15] at hbcA3; rw [h16] at hbcA4
      linarith only [h0_bc, hbcA1, hbcA2, hbcA3, hbcA4, hb_chain, hs_bl]
  · have hz_not : ¬ (0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack) := by
      simp [hnf]
    have hn16 := ((hinv.tab15_16_spec (s : ℤ)).2 hz_not).2
    have hr16_eq0 : stCur.words.read (.heap 16 (s : ℤ)) = 0 := by
      rw [hr_16_s]; simp [WordStore.read, hn16]
    have hcondA : evalBitCond inpSim stCur.frameDepth stCur.words
        (.intEq (.readHeap 16 (.readHeap 12 (.lit 1))) (.lit 1)) =
        (false, 5, 19 + 2 * intBitLength (s : ℤ)) := by
      simp only [evalBitCond, evalIntExpr, hr_12_1, hr16_eq0]
      simp only [h12, h16, hl0, hl1]
      exact Prod.ext rfl (Prod.ext rfl (by ring))
    let stA : BitRAMExecState :=
      { stCur with unitCost := stCur.unitCost + 5 + 1, bitCost := stCur.bitCost + (19 + 2 * intBitLength (s : ℤ)) + 1 }
    have hiteA : RunsTo inpSim [.stmt cleanupStepAStmt] stCur stA := by
      unfold cleanupStepAStmt
      apply RunsTo.ite; rw [hcondA]; dsimp only; simp only [Bool.false_eq_true, ↓reduceIte]
      exact RunsTo.skip inpSim _
    refine ⟨stA, hiteA, by rw [if_neg hnf], le_rfl, le_rfl, rfl, rfl, ?_, ?_, hpCC, hpBC⟩
    · dsimp [stA]; clear * -; omega
    · dsimp [stA]; linarith only [hs_bl]

private theorem cleanupInv_step {T_max S_max : ℕ}
    {wsBaseNew wsSubHeap wsStart wsCur wsA wsB1 wsB2 : WordStore}
    {highSid s : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBaseNew T_max S_max wsSubHeap wsStart highSid sidOfEnc encOfSid freeStack)
    (hs_lt : s < highSid)
    (hInv : CleanupLoopInv wsStart highSid sidOfEnc s wsCur)
    (hwA : wsA = (if s ∉ freeStack then
      (((wsCur.free (.heap 10 (encOfSid s))).free (.heap 13 (encOfSid s))).free
        (.heap 15 (s : ℤ))).free (.heap 16 (s : ℤ))
      else wsCur))
    (hwB1 : wsB1 = wsA.free (.heap 14 (s : ℤ)))
    (hwB2 : wsB2 = wsB1.write (.heap 12 1) ((s + 1 : ℕ) : ℤ)) :
    CleanupLoopInv wsStart highSid sidOfEnc (s + 1) wsB2 := by
  have hwfA : WellFormedWS wsA := by
    rw [hwA]; by_cases hnf_s : s ∉ freeStack
    · rw [if_pos hnf_s]
      exact wellFormedWS_free (wellFormedWS_free (wellFormedWS_free (wellFormedWS_free hInv.wf _) _) _) _
    · rw [if_neg hnf_s]; exact hInv.wf
  refine
    { wf := by rw [hwB2, hwB1]; exact wellFormedWS_write (wellFormedWS_free hwfA _) _ _
      has12_1 := by
        rw [hwB2]
        exact ⟨by simp only [ws_write_live, Finset.mem_insert, true_or],
               by rw [ws_write_vals, Function.update_self]⟩
      tab10_13 := fun t ht e' => by
        have hne12 : (.heap t e' : RAMCellLoc) ≠ .heap 12 1 := by rcases ht with rfl | rfl <;> simp
        have hne14 : (.heap t e' : RAMCellLoc) ≠ .heap 14 (s : ℤ) := by rcases ht with rfl | rfl <;> simp
        have hne15 : (.heap t e' : RAMCellLoc) ≠ .heap 15 (s : ℤ) := by rcases ht with rfl | rfl <;> simp
        have hne16 : (.heap t e' : RAMCellLoc) ≠ .heap 16 (s : ℤ) := by rcases ht with rfl | rfl <;> simp
        rw [hwB2, hwB1]
        refine ⟨fun ⟨s', hs'_lt, hsid'⟩ => ?_, fun hno => ?_⟩
        · rw [ws_wf_free_live]
          rintro (heq | ⟨_, hmA⟩)
          · exact hne12 heq
          by_cases heq_s : s' = s
          · subst heq_s
            obtain ⟨_, hnf_s, henc_eq⟩ := hinv.sid_lt e' s' hsid'
            rw [hwA, if_pos hnf_s, ws_free4_live, henc_eq] at hmA
            rcases ht with rfl | rfl
            · exact hmA.2.2.2.1 rfl
            · exact hmA.2.2.1 rfl
          · have hlt_old : s' < s := by clear * - hs'_lt heq_s; omega
            have hn_cur := (hInv.tab10_13 t ht e').1 ⟨s', hlt_old, hsid'⟩
            rw [hwA] at hmA
            by_cases hnf_s : s ∉ freeStack
            · rw [if_pos hnf_s, ws_free4_live] at hmA; exact hn_cur hmA.2.2.2.2
            · rw [if_neg hnf_s] at hmA; exact hn_cur hmA
        · have hno_old : ¬ ∃ s' < s, sidOfEnc e' = some s' :=
            fun ⟨s', hlt, hs⟩ => hno ⟨s', Nat.lt_succ_of_lt hlt, hs⟩
          have h0 := (hInv.tab10_13 t ht e').2 hno_old
          rw [ws_wf_free_live, ws_wf_free_vals_ne _ _ hne12 hne14]
          rw [hwA]; by_cases hnf_s : s ∉ freeStack
          · rw [if_pos hnf_s]
            have hne_e : e' ≠ encOfSid s := by
              intro hh; subst hh
              exact hno ⟨s, Nat.lt_succ_self s, hinv.enc_sid s hs_lt hnf_s⟩
            have hne10 : (.heap t e' : RAMCellLoc) ≠ .heap 10 (encOfSid s) := by
              rcases ht with rfl | rfl <;> simp [hne_e]
            have hne13 : (.heap t e' : RAMCellLoc) ≠ .heap 13 (encOfSid s) := by
              rcases ht with rfl | rfl <;> simp [hne_e]
            rw [ws_free4_live, ws_free4_vals_ne _ hne16 hne15 hne13 hne10]
            exact ⟨by simp only [ne_eq, hne12, hne14, hne16, hne15, hne13, hne10, not_false_eq_true, true_and, false_or]; exact h0.1,
                   h0.2⟩
          · rw [if_neg hnf_s]
            exact ⟨by simp only [ne_eq, hne12, hne14, not_false_eq_true, true_and, false_or]; exact h0.1,
                   h0.2⟩
      tab14_15_16 := fun t ht z => by
        have hne12 : (.heap t z : RAMCellLoc) ≠ .heap 12 1 := by rcases ht with rfl | rfl | rfl <;> simp
        have hne10 : ∀ x, (.heap t z : RAMCellLoc) ≠ .heap 10 x := by intro x; rcases ht with rfl | rfl | rfl <;> simp
        have hne13 : ∀ x, (.heap t z : RAMCellLoc) ≠ .heap 13 x := by intro x; rcases ht with rfl | rfl | rfl <;> simp
        rw [hwB2, hwB1]
        refine ⟨fun ⟨hz0, hlt_s1⟩ => ?_, fun hno => ?_⟩
        · rw [ws_wf_free_live]
          rintro (heq | ⟨hne14_cur, hmA⟩)
          · exact hne12 heq
          by_cases heq_z : z = (s : ℤ)
          · subst heq_z
            rcases ht with rfl | rfl | rfl
            · exact hne14_cur rfl
            · rw [hwA] at hmA; by_cases hnf_s : s ∉ freeStack
              · rw [if_pos hnf_s, ws_free4_live] at hmA; exact hmA.2.1 rfl
              · rw [if_neg hnf_s] at hmA
                have hz_not : ¬ (0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack) := by simp [hnf_s]
                have hn15_st := ((hinv.tab15_16_spec (s : ℤ)).2 hz_not).1
                have hcur15 := (hInv.tab14_15_16 15 (Or.inr (Or.inl rfl)) (s : ℤ)).2 (by simp)
                exact hn15_st (hcur15.1.mp hmA)
            · rw [hwA] at hmA; by_cases hnf_s : s ∉ freeStack
              · rw [if_pos hnf_s, ws_free4_live] at hmA; exact hmA.1 rfl
              · rw [if_neg hnf_s] at hmA
                have hz_not : ¬ (0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack) := by simp [hnf_s]
                have hn16_st := ((hinv.tab15_16_spec (s : ℤ)).2 hz_not).2
                have hcur16 := (hInv.tab14_15_16 16 (Or.inr (Or.inr rfl)) (s : ℤ)).2 (by simp)
                exact hn16_st (hcur16.1.mp hmA)
          · have hlt_s : z.toNat < s := by
              clear * - hz0 hlt_s1 heq_z
              have : z.toNat ≠ s := fun hh => heq_z (by omega)
              omega
            have hn_cur := (hInv.tab14_15_16 t ht z).1 ⟨hz0, hlt_s⟩
            rw [hwA] at hmA; by_cases hnf_s : s ∉ freeStack
            · rw [if_pos hnf_s, ws_free4_live] at hmA; exact hn_cur hmA.2.2.2.2
            · rw [if_neg hnf_s] at hmA; exact hn_cur hmA
        · have hne_z : z ≠ (s : ℤ) := by intro hh; subst hh; exact hno ⟨Nat.cast_nonneg s, by simp⟩
          have hno_old : ¬ (0 ≤ z ∧ z.toNat < s) :=
            fun ⟨hz0, hlt⟩ => hno ⟨hz0, Nat.lt_succ_of_lt hlt⟩
          have h0 := (hInv.tab14_15_16 t ht z).2 hno_old
          have hne14_s : (.heap t z : RAMCellLoc) ≠ .heap 14 (s : ℤ) := by simp [hne_z]
          have hne15_s : (.heap t z : RAMCellLoc) ≠ .heap 15 (s : ℤ) := by simp [hne_z]
          have hne16_s : (.heap t z : RAMCellLoc) ≠ .heap 16 (s : ℤ) := by simp [hne_z]
          rw [ws_wf_free_live, ws_wf_free_vals_ne _ _ hne12 hne14_s]
          rw [hwA]; by_cases hnf_s : s ∉ freeStack
          · rw [if_pos hnf_s, ws_free4_live, ws_free4_vals_ne _ hne16_s hne15_s (hne13 _) (hne10 _)]
            exact ⟨by simp only [ne_eq, hne12, hne14_s, hne16_s, hne15_s, hne13 _, hne10 _, not_false_eq_true, true_and, false_or]; exact h0.1,
                   h0.2⟩
          · rw [if_neg hnf_s]
            exact ⟨by simp only [ne_eq, hne12, hne14_s, not_false_eq_true, true_and, false_or]; exact h0.1,
                   h0.2⟩
      other_loc := fun loc hne12 h10_13 h14_16 => by
        have h0 := hInv.other_loc loc hne12 h10_13 h14_16
        have hne14 := (h14_16 (s : ℤ)).1
        have hne15 := (h14_16 (s : ℤ)).2.1
        have hne16 := (h14_16 (s : ℤ)).2.2
        have hne10 := (h10_13 (encOfSid s)).1
        have hne13 := (h10_13 (encOfSid s)).2
        rw [hwB2, hwB1, ws_wf_free_live, ws_wf_free_vals_ne _ _ hne12 hne14]
        rw [hwA]; by_cases hnf_s : s ∉ freeStack
        · rw [if_pos hnf_s, ws_free4_live, ws_free4_vals_ne _ hne16 hne15 hne13 hne10]
          exact ⟨by simp only [ne_eq, hne12, hne14, hne16, hne15, hne13, hne10, not_false_eq_true, true_and, false_or]; exact h0.1,
                 h0.2⟩
        · rw [if_neg hnf_s]
          exact ⟨by simp only [ne_eq, hne12, hne14, not_false_eq_true, true_and, false_or]; exact h0.1,
                 h0.2⟩ }

private theorem exec_cleanupLoop {d T_max S_max subPeakCell subPeakBit : ℕ}
    {wsBaseNew wsSubHeap wsStart : WordStore}
    {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (inpSim : BitRAMInput d)
    (hinv : A2SimInv wsBaseNew T_max S_max wsSubHeap wsStart highSid sidOfEnc encOfSid freeStack)
    (hcSub : wsSubHeap.cellCount ≤ subPeakCell)
    (hbSub : wsSubHeap.bitSize ≤ subPeakBit)
    {C_cell C_bit : ℕ}
    (hCeilC : a2CellBound wsBaseNew inpSim S_max subPeakCell ≤ C_cell)
    (hCeilB : a2BitBound wsBaseNew inpSim T_max S_max subPeakBit ≤ C_bit) :
    let S_bits := natBitLength S_max + 4
    ∀ (rem : ℕ) (s : ℕ), s + rem = highSid →
      ∀ stCur : BitRAMExecState,
        CleanupLoopInv wsStart highSid sidOfEnc s stCur.words →
        stCur.words.cellCount ≤ wsStart.cellCount + 2 →
        stCur.words.bitSize ≤ wsStart.bitSize + S_bits + 12 →
        stCur.peakCellSpace ≤ C_cell →
        stCur.peakBitSpace ≤ C_bit →
        ∃ stEnd : BitRAMExecState,
          RunsTo inpSim [.repeatLoop rem cleanupLoopBody] stCur stEnd ∧
          CleanupLoopInv wsStart highSid sidOfEnc highSid stEnd.words ∧
          stEnd.words.cellCount ≤ wsStart.cellCount + 2 ∧
          stEnd.words.bitSize ≤ wsStart.bitSize + S_bits + 12 ∧
          stEnd.frameDepth = stCur.frameDepth ∧
          stEnd.remainingBits = stCur.remainingBits ∧
          stEnd.unitCost ≤ stCur.unitCost + 32 * rem ∧
          stEnd.bitCost + 8 * stEnd.words.bitSize ≤
            stCur.bitCost + 8 * stCur.words.bitSize + rem * (40 * S_bits + 256) ∧
          stEnd.peakCellSpace ≤ C_cell ∧
          stEnd.peakBitSpace ≤ C_bit := by
  intro S_bits rem
  obtain ⟨hHeadCell, hHeadBit⟩ := hinv.within_bounds inpSim hcSub hbSub
  change inpSim.inputBitSpace + wsStart.bitSize + 12 * subPeakBit + 16 * natBitLength T_max + 20 * S_bits + 200 ≤
      a2BitBound wsBaseNew inpSim T_max S_max subPeakBit at hHeadBit
  have hhigh_S := hinv.high_le
  have hsid_bl : ∀ x : ℕ, x ≤ S_max → intBitLength (x : ℤ) ≤ S_bits := by
    intro x hx
    have h1 := intBitLength_ofNat_le x
    have h2 := natBitLength_mono hx
    dsimp [S_bits]; linarith only [h1, h2]
  have h12 : natBitLength 12 = 4 := by decide
  have h14 : natBitLength 14 = 4 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  induction rem with
  | zero =>
      intro s hsEq stCur hInv hcCur hbCur hpCC hpBC
      have hsH : s = highSid := by clear * - hsEq; omega
      subst hsH
      exact ⟨stCur, RunsTo.repeatLoop_zero cleanupLoopBody stCur, hInv, hcCur, hbCur,
        rfl, rfl, Nat.le_add_right _ _, by simp, hpCC, hpBC⟩
  | succ rem ih =>
      intro s hsEq stCur hInv hcCur hbCur hpCC hpBC
      have hs_lt : s < highSid := by clear * - hsEq; omega
      have hs_bl : intBitLength (s : ℤ) ≤ S_bits := hsid_bl s (by clear * - hs_lt hhigh_S; omega)
      have hs1_bl : intBitLength ((s + 1 : ℕ) : ℤ) ≤ S_bits := hsid_bl (s + 1) (by clear * - hs_lt hhigh_S; omega)
      have hr_12_1 : stCur.words.read (.heap 12 1) = (s : ℤ) := by
        rw [wordStore_read_eq_vals hInv.wf]; exact hInv.has12_1.2
      obtain ⟨stA, hrA, hwA, hcA, hbA, hfdA, hrbA, hucA, hbcA, hpCA, hpBA⟩ :=
        exec_cleanupStepA inpSim hinv hs_lt hs_bl stCur hInv hpCC hpBC
      have hrA_12_1 : stA.words.read (.heap 12 1) = (s : ℤ) := by
        rw [hwA]; by_cases hnf_s : s ∉ freeStack
        · rw [if_pos hnf_s, wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp),
              wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp)]
          exact hr_12_1
        · rw [if_neg hnf_s]; exact hr_12_1
      obtain ⟨stB1, hrB1, hwB1, hfdB1, hrbB1, hucB1, hbcB1, hpCB1, hpBB1⟩ :=
        exec_freeHeap_ceil inpSim 14 (.readHeap 12 (.lit 1)) stA hpCA hpBA
          (idx := (s : ℤ)) (u₁ := 2) (b₁ := 8 + intBitLength (s : ℤ))
          (evalIntLe_readHeap_lit inpSim stA.frameDepth stA.words 12 1 _
            (b := 8 + intBitLength (s : ℤ)) hrA_12_1 h12 hl1 (le_of_eq (by ring)))
      have hrB1_12_1 : stB1.words.read (.heap 12 1) = (s : ℤ) := by
        rw [hwB1, wordStore_read_free_ne _ (by simp)]; exact hrA_12_1
      have hSubStart : ∀ l ∈ (stB1.words.free (.heap 12 1)).live,
          l ∈ wsStart.live ∧ (stB1.words.free (.heap 12 1)).vals l = wsStart.vals l := by
        intro l hl
        simp only [ws_free_live, Finset.mem_erase] at hl
        rcases hl with ⟨hne12, hlB1⟩
        rw [ws_free_vals, Function.update_of_ne hne12]
        rw [hwB1] at hlB1 ⊢
        simp only [ws_free_live, Finset.mem_erase] at hlB1
        rcases hlB1 with ⟨hne14, hlA⟩
        rw [ws_free_vals, Function.update_of_ne hne14]
        have hlCur : l ∈ stCur.words.live ∧ stA.words.vals l = stCur.words.vals l := by
          rw [hwA] at hlA ⊢
          by_cases hnf_s : s ∉ freeStack
          · rw [if_pos hnf_s, ws_free4_live] at hlA
            rw [if_pos hnf_s]
            rcases hlA with ⟨h_16, h_15, h_13, h_10, hlC⟩
            exact ⟨hlC, ws_free4_vals_ne _ h_16 h_15 h_13 h_10⟩
          · rw [if_neg hnf_s] at hlA ⊢
            exact ⟨hlA, rfl⟩
        rw [hlCur.2]
        cases l with
        | localFrame d' v' i' =>
            have ho := hInv.other_loc _ hne12 (by simp) (by simp)
            exact ⟨ho.1.mp hlCur.1, ho.2⟩
        | heap t' i' =>
            by_cases ht10_13 : t' = 10 ∨ t' = 13
            · by_cases hex : ∃ s' < s, sidOfEnc i' = some s'
              · exact False.elim (((hInv.tab10_13 t' ht10_13 i').1 hex) hlCur.1)
              · have h0 := (hInv.tab10_13 t' ht10_13 i').2 hex
                exact ⟨h0.1.mp hlCur.1, h0.2⟩
            · by_cases ht14_16 : t' = 14 ∨ t' = 15 ∨ t' = 16
              · by_cases hz : 0 ≤ i' ∧ i'.toNat < s
                · exact False.elim (((hInv.tab14_15_16 t' ht14_16 i').1 hz) hlCur.1)
                · have h0 := (hInv.tab14_15_16 t' ht14_16 i').2 hz
                  exact ⟨h0.1.mp hlCur.1, h0.2⟩
              · push_neg at ht10_13 ht14_16
                have ho := hInv.other_loc (.heap t' i') hne12
                  (fun _ => ⟨by simp [ht10_13.1], by simp [ht10_13.2]⟩)
                  (fun _ => ⟨by simp [ht14_16.1], by simp [ht14_16.2.1], by simp [ht14_16.2.2]⟩)
                exact ⟨ho.1.mp hlCur.1, ho.2⟩
      have hWriteEq : stB1.words.write (.heap 12 1) ((s + 1 : ℕ) : ℤ) =
          (stB1.words.free (.heap 12 1)).write (.heap 12 1) ((s + 1 : ℕ) : ℤ) :=
        ws_write_eq_free_write stB1.words (.heap 12 1) ((s + 1 : ℕ) : ℤ)
      have hcNext_st : (stB1.words.write (.heap 12 1) ((s + 1 : ℕ) : ℤ)).cellCount ≤ wsStart.cellCount + 2 := by
        rw [hWriteEq]
        have hsub : (stB1.words.free (.heap 12 1)).live ⊆ wsStart.live := fun l hl => (hSubStart l hl).1
        have hc_f : (stB1.words.free (.heap 12 1)).cellCount ≤ wsStart.cellCount := Finset.card_le_card hsub
        have hc_w := cellCount_write_le (stB1.words.free (.heap 12 1)) (.heap 12 1) ((s + 1 : ℕ) : ℤ)
        linarith only [hc_f, hc_w]
      have hbNext_st : (stB1.words.write (.heap 12 1) ((s + 1 : ℕ) : ℤ)).bitSize ≤ wsStart.bitSize + S_bits + 12 := by
        rw [hWriteEq]
        have hb_f : (stB1.words.free (.heap 12 1)).bitSize ≤ wsStart.bitSize := by
          unfold WordStore.bitSize
          calc ∑ l ∈ (stB1.words.free (.heap 12 1)).live,
                  (l.bitLength + intBitLength ((stB1.words.free (.heap 12 1)).vals l))
              = ∑ l ∈ (stB1.words.free (.heap 12 1)).live,
                  (l.bitLength + intBitLength (wsStart.vals l)) := by
                refine Finset.sum_congr rfl fun l hl => ?_
                rw [(hSubStart l hl).2]
            _ ≤ ∑ l ∈ wsStart.live, (l.bitLength + intBitLength (wsStart.vals l)) :=
                Finset.sum_le_sum_of_subset (fun l hl => (hSubStart l hl).1)
        have hb_w := bitSize_write_le (stB1.words.free (.heap 12 1)) (.heap 12 1) ((s + 1 : ℕ) : ℤ)
        dsimp [RAMCellLoc.bitLength] at hb_w; rw [h12, hl1] at hb_w
        linarith only [hb_f, hb_w, hs1_bl]
      have hc_ceil : inpSim.inputCellSpace + (stB1.words.write (.heap 12 1) ((s + 1 : ℕ) : ℤ)).cellCount ≤ C_cell :=
        (by linarith only [hcNext_st, hHeadCell] : inpSim.inputCellSpace + (stB1.words.write (.heap 12 1) ((s + 1 : ℕ) : ℤ)).cellCount ≤
          a2CellBound wsBaseNew inpSim S_max subPeakCell).trans hCeilC
      have hb_ceil : inpSim.inputBitSpace + (stB1.words.write (.heap 12 1) ((s + 1 : ℕ) : ℤ)).bitSize ≤ C_bit :=
        (by linarith only [hbNext_st, hHeadBit] : inpSim.inputBitSpace + (stB1.words.write (.heap 12 1) ((s + 1 : ℕ) : ℤ)).bitSize ≤
          a2BitBound wsBaseNew inpSim T_max S_max subPeakBit).trans hCeilB
      obtain ⟨stB2, hrB2, hwB2, hfdB2, hrbB2, hucB2, hbcB2, hpCB2, hpBB2⟩ :=
        exec_writeHeap_ceil inpSim 12 (.lit 1) (.add (.readHeap 12 (.lit 1)) (.lit 1))
          stB1 hpCB1 hpBB1 (idx := 1) (val := ((s + 1 : ℕ) : ℤ))
          (u₁ := 1) (b₁ := 2) (u₂ := 4) (b₂ := 12 + 2 * intBitLength (s : ℤ))
          (evalIntLe_lit _ _ _ _ (by decide))
          (evalIntLe_add_read12_one inpSim stB1.frameDepth stB1.words 1 s
            (b := 12 + 2 * intBitLength (s : ℤ)) hrB1_12_1 hl1 (le_of_eq (by ring)))
          hc_ceil hb_ceil
      have hBody : RunsTo inpSim [.stmt cleanupLoopBody] stCur stB2 :=
        RunsTo.seq hrA (RunsTo.seq hrB1 hrB2)
      have hInvNext : CleanupLoopInv wsStart highSid sidOfEnc (s + 1) stB2.words :=
        cleanupInv_step hinv hs_lt hInv hwA hwB1 hwB2
      have hb_step_sz : stB2.words.bitSize ≤ stA.words.bitSize + S_bits + 8 := by
        have bw := bitSize_write_le stB1.words (.heap 12 1) ((s + 1 : ℕ) : ℤ)
        have bf := bitSize_free_le stA.words (.heap 14 (s : ℤ))
        rw [← hwB2] at bw; rw [← hwB1] at bf
        dsimp only [RAMCellLoc.bitLength] at bw; rw [h12, hl1] at bw
        linarith only [bw, bf, hs1_bl]
      have hlyap_step : stB2.bitCost + 8 * stB2.words.bitSize ≤
          stCur.bitCost + 8 * stCur.words.bitSize + (40 * S_bits + 256) := by
        rw [h14] at hbcB1; rw [h12, hl1] at hbcB2
        linarith only [hbcA, hbcB1, hbcB2, hb_step_sz, hs_bl, hs1_bl]
      obtain ⟨stEnd, hrRem, hInvEnd, hcEnd, hbEnd, hfdEnd, hrbEnd, hucEnd, hbcEnd, hpCEnd, hpBEnd⟩ :=
        ih (s + 1) (by clear * - hsEq; omega) stB2 hInvNext
          (by rw [hwB2]; exact hcNext_st)
          (by rw [hwB2]; exact hbNext_st)
          hpCB2 hpBB2
      refine ⟨stEnd, RunsTo.repeatLoop_succ hBody hrRem, hInvEnd, hcEnd, hbEnd,
        by rw [hfdEnd, hfdB2, hfdB1, hfdA],
        by rw [hrbEnd, hrbB2, hrbB1, hrbA],
        ?_, ?_, hpCEnd, hpBEnd⟩
      · have hrem_uc : 32 * (rem + 1) = 32 * rem + 32 := by ring
        linarith only [hrem_uc, hucA, hucB1, hucB2, hucEnd]
      · have hrem_bc : (rem + 1) * (40 * S_bits + 256) = rem * (40 * S_bits + 256) + (40 * S_bits + 256) := by ring
        linarith only [hrem_bc, hlyap_step, hbcEnd]

theorem exec_cleanupA2Stmt {d T_max S_max : ℕ}
    {wsBaseNew wsSubHeap : WordStore}
    {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (inpSim : BitRAMInput d)
    (st : BitRAMExecState)
    (hinv : A2SimInv wsBaseNew T_max S_max wsSubHeap st.words highSid sidOfEnc encOfSid freeStack)
    (hnoLocal : ∀ d' v' i', (.localFrame d' v' i' : RAMCellLoc) ∉ wsSubHeap.live)
    {subPeakCell subPeakBit : ℕ}
    (hcSub : wsSubHeap.cellCount ≤ subPeakCell)
    (hbSub : wsSubHeap.bitSize ≤ subPeakBit) :
    let S_bits := natBitLength S_max + 4
    let C_cell := max st.peakCellSpace (a2CellBound wsBaseNew inpSim S_max subPeakCell)
    let C_bit := max st.peakBitSpace (a2BitBound wsBaseNew inpSim T_max S_max subPeakBit)
    ∃ stClean : BitRAMExecState,
      RunsTo inpSim [.stmt cleanupA2Stmt] st stClean ∧
      stClean.words = wsBaseNew ∧
      stClean.frameDepth = st.frameDepth ∧
      stClean.remainingBits = st.remainingBits ∧
      stClean.unitCost ≤ st.unitCost + 32 * S_max + 32 ∧
      stClean.bitCost ≤ st.bitCost + 8 * (a2BitBound wsBaseNew inpSim T_max S_max subPeakBit) +
        S_max * (40 * S_bits + 256) + 64 ∧
      stClean.peakCellSpace ≤ C_cell ∧
      stClean.peakBitSpace ≤ C_bit := by
  intro S_bits C_cell C_bit
  obtain ⟨hHeadCell, hHeadBit⟩ := hinv.within_bounds inpSim hcSub hbSub
  change inpSim.inputBitSpace + st.words.bitSize + 12 * subPeakBit + 16 * natBitLength T_max + 20 * S_bits + 200 ≤
      a2BitBound wsBaseNew inpSim T_max S_max subPeakBit at hHeadBit
  have hhigh_S := hinv.high_le
  have hsid_bl : ∀ s : ℕ, s ≤ S_max → intBitLength (s : ℤ) ≤ S_bits := by
    intro s hs
    have h1 := intBitLength_ofNat_le s
    have h2 := natBitLength_mono hs
    dsimp [S_bits]; linarith only [h1, h2]
  have h12 : natBitLength 12 = 4 := by decide
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  have hl4 : intBitLength (4 : ℤ) = 4 := by decide
  have hl5 : intBitLength (5 : ℤ) = 4 := by decide
  have hpC0 : st.peakCellSpace ≤ C_cell := le_max_left _ _
  have hpB0 : st.peakBitSpace ≤ C_bit := le_max_left _ _
  have hc1 : inpSim.inputCellSpace + (st.words.write (.heap 12 1) 0).cellCount ≤ C_cell := by
    have h := cellCount_write_le st.words (.heap 12 1) 0
    exact (by linarith only [h, hHeadCell] : inpSim.inputCellSpace + (st.words.write (.heap 12 1) 0).cellCount ≤
      a2CellBound wsBaseNew inpSim S_max subPeakCell).trans (le_max_right _ _)
  have hb1 : inpSim.inputBitSpace + (st.words.write (.heap 12 1) 0).bitSize ≤ C_bit := by
    have h := bitSize_write_le st.words (.heap 12 1) 0
    dsimp [RAMCellLoc.bitLength] at h; rw [h12, hl1, hl0] at h
    exact (by linarith only [h, hHeadBit] : inpSim.inputBitSpace + (st.words.write (.heap 12 1) 0).bitSize ≤
      a2BitBound wsBaseNew inpSim T_max S_max subPeakBit).trans (le_max_right _ _)
  obtain ⟨st1, hr1, hw1, hfd1, hrb1, huc1, hbc1, hpC1, hpB1⟩ :=
    exec_writeHeap_ceil inpSim 12 (.lit 1) (.lit 0) st hpC0 hpB0
      (idx := 1) (val := 0) (u₁ := 1) (b₁ := 2) (u₂ := 1) (b₂ := 1)
      (evalIntLe_lit _ _ _ _ (by decide)) (evalIntLe_lit _ _ _ _ (by decide)) hc1 hb1
  have hr1_12_5 : st1.words.read (.heap 12 5) = (highSid : ℤ) := by
    rw [hw1, wordStore_read_write_ne _ (by decide)]; exact hinv.tab12_5.2
  have hev5 : evalIntExpr inpSim st1.frameDepth st1.words (.readHeap 12 (.lit 5)) =
      ((highSid : ℤ), 2, 12 + intBitLength (highSid : ℤ)) := by
    simp only [evalIntExpr, hr1_12_5, h12, hl5]
  let stLoop0 : BitRAMExecState :=
    { st1 with
      unitCost := st1.unitCost + 2
      bitCost := st1.bitCost + (12 + intBitLength (highSid : ℤ)) }
  have hInv0 : CleanupLoopInv st.words highSid sidOfEnc 0 stLoop0.words :=
    { wf := by dsimp [stLoop0]; rw [hw1]; exact wellFormedWS_write hinv.wfSim _ _
      has12_1 := by dsimp [stLoop0]; rw [hw1]; simp [ws_write_live, ws_write_vals]
      tab10_13 := fun t ht e => by
        dsimp [stLoop0]; rw [hw1]
        have hne : (.heap t e : RAMCellLoc) ≠ .heap 12 1 := by rcases ht with rfl | rfl <;> simp
        exact ⟨fun ⟨_, hlt, _⟩ => absurd hlt (Nat.not_lt_zero _),
               fun _ => ⟨by simp [ws_write_live, hne], by simp [ws_write_vals, Function.update_of_ne hne]⟩⟩
      tab14_15_16 := fun t ht z => by
        dsimp [stLoop0]; rw [hw1]
        have hne : (.heap t z : RAMCellLoc) ≠ .heap 12 1 := by rcases ht with rfl | rfl | rfl <;> simp
        exact ⟨fun ⟨_, hlt⟩ => absurd hlt (Nat.not_lt_zero _),
               fun _ => ⟨by simp [ws_write_live, hne], by simp [ws_write_vals, Function.update_of_ne hne]⟩⟩
      other_loc := fun loc hne12 _ _ => by
        dsimp [stLoop0]; rw [hw1]
        exact ⟨by simp [ws_write_live, hne12], by simp [ws_write_vals, Function.update_of_ne hne12]⟩ }
  have hcLoop0 : stLoop0.words.cellCount ≤ st.words.cellCount + 2 := by
    dsimp [stLoop0]; rw [hw1]; have hc_w0 := cellCount_write_le st.words (.heap 12 1) 0; linarith only [hc_w0]
  have hbLoop0 : stLoop0.words.bitSize ≤ st.words.bitSize + S_bits + 12 := by
    dsimp [stLoop0]; rw [hw1]
    have h := bitSize_write_le st.words (.heap 12 1) 0
    dsimp [RAMCellLoc.bitLength] at h; rw [h12, hl1, hl0] at h
    have hSb0 : 0 ≤ S_bits := Nat.zero_le _; linarith only [h, hSb0]
  obtain ⟨stL, hrLoop, hInvL, hcL, hbL, hfdL, hrbL, hucL, hbcL, hpCL, hpBL⟩ :=
    exec_cleanupLoop inpSim hinv hcSub hbSub (le_max_right _ _) (le_max_right _ _)
      highSid 0 (Nat.zero_add highSid) stLoop0 hInv0 hcLoop0 hbLoop0 hpC1 hpB1
  have hrRepeat : RunsTo inpSim [.stmt (.repeatN (.readHeap 12 (.lit 5)) cleanupLoopBody)] st1 stL := by
    apply RunsTo.repeatN
    rw [hev5]; dsimp only
    have hge0 : (0 : ℤ) ≤ (highSid : ℤ) := Nat.cast_nonneg highSid
    simp only [hge0, ↓reduceIte, Int.toNat_natCast]
    exact hrLoop
  obtain ⟨stF1, hf1, hwF1, hfdF1, hrbF1, hucF1, hbcF1, hpCF1, hpBF1⟩ :=
    exec_freeHeap_ceil inpSim 12 (.lit 1) stL hpCL hpBL (idx := 1) (u₁ := 1) (b₁ := 2)
      (evalIntLe_lit _ _ _ _ (by decide))
  obtain ⟨stF2, hf2, hwF2, hfdF2, hrbF2, hucF2, hbcF2, hpCF2, hpBF2⟩ :=
    exec_freeHeap_ceil inpSim 12 (.lit 4) stF1 hpCF1 hpBF1 (idx := 4) (u₁ := 1) (b₁ := 4)
      (evalIntLe_lit _ _ _ _ (by decide))
  obtain ⟨stF3, hf3, hwF3, hfdF3, hrbF3, hucF3, hbcF3, hpCF3, hpBF3⟩ :=
    exec_freeHeap_ceil inpSim 12 (.lit 5) stF2 hpCF2 hpBF2 (idx := 5) (u₁ := 1) (b₁ := 4)
      (evalIntLe_lit _ _ _ _ (by decide))
  have htot : RunsTo inpSim [.stmt cleanupA2Stmt] st stF3 :=
    RunsTo.seq hr1 (RunsTo.seq hrRepeat (RunsTo.seq hf1 (RunsTo.seq hf2 hf3)))
  have hwClean_eq : stF3.words = wsBaseNew := by
    have hwfF3 : WellFormedWS stF3.words := by
      rw [hwF3, hwF2, hwF1]
      exact wellFormedWS_free (wellFormedWS_free (wellFormedWS_free hInvL.wf _) _) _
    have hlive_eq : stF3.words.live = wsBaseNew.live := by
      ext loc
      rw [hwF3, hwF2, hwF1]
      simp only [ws_free_live, Finset.mem_erase]
      constructor
      · rintro ⟨hne5, hne4, hne1, hmL⟩
        cases loc with
        | localFrame d' v' i' =>
            have ho := hInvL.other_loc _ hne1 (by simp) (by simp)
            have hmSt := ho.1.mp hmL
            rcases hinv.live_cases _ hmSt with hb | ⟨d0, v0, i0, heq⟩ | ⟨_, _, _, heq⟩
            · exact (hinv.base_live _ hb).mp hmSt
            · injection heq with hd hv hi
              subst hv hi
              rw [hd] at hmSt
              exact False.elim (hnoLocal d0 v' i' ((hinv.local_live d0 v' i').mp hmSt))
            · cases heq
        | heap t' i' =>
            by_cases ht10 : t' < 10
            · have hb : IsA2BaseLoc (.heap t' i') := ht10
              have ho := hInvL.other_loc (.heap t' i') hne1
                (fun _ => ⟨by simp [show t' ≠ 10 by clear * - ht10; omega], by simp [show t' ≠ 13 by clear * - ht10; omega]⟩)
                (fun _ => ⟨by simp [show t' ≠ 14 by clear * - ht10; omega], by simp [show t' ≠ 15 by clear * - ht10; omega], by simp [show t' ≠ 16 by clear * - ht10; omega]⟩)
              exact (hinv.base_live _ hb).mp (ho.1.mp hmL)
            · exfalso
              have hnotBase : ¬ IsA2BaseLoc (.heap t' i') := by simp [IsA2BaseLoc]; clear * - ht10; omega
              by_cases ht10_13 : t' = 10 ∨ t' = 13
              · by_cases hex : ∃ s' < highSid, sidOfEnc i' = some s'
                · exact (hInvL.tab10_13 t' ht10_13 i').1 hex hmL
                · have hmSt := ((hInvL.tab10_13 t' ht10_13 i').2 hex).1.mp hmL
                  rcases ht10_13 with rfl | rfl
                  · cases hs : sidOfEnc i' with
                    | none => have := (hinv.active_iff i').mp hmSt; simp [hs] at this
                    | some s' => exact hex ⟨s', (hinv.sid_lt i' s' hs).1, hs⟩
                  · cases hs : sidOfEnc i' with
                    | none => exact (hinv.tab13_spec i').2 hs hmSt
                    | some s' => exact hex ⟨s', (hinv.sid_lt i' s' hs).1, hs⟩
              · by_cases ht14_16 : t' = 14 ∨ t' = 15 ∨ t' = 16
                · by_cases hz : 0 ≤ i' ∧ i'.toNat < highSid
                  · exact (hInvL.tab14_15_16 t' ht14_16 i').1 hz hmL
                  · have hmSt := ((hInvL.tab14_15_16 t' ht14_16 i').2 hz).1.mp hmL
                    obtain ⟨hfree_le, _⟩ := hinv.highSid_sub_free_le
                    rcases ht14_16 with rfl | rfl | rfl
                    · exact (hinv.tab14_spec i').2 (fun ⟨h0, hlt⟩ => hz ⟨h0, lt_of_lt_of_le hlt hfree_le⟩) hmSt
                    · exact ((hinv.tab15_16_spec i').2 (fun ⟨h0, hlt, _⟩ => hz ⟨h0, hlt⟩)).1 hmSt
                    · exact ((hinv.tab15_16_spec i').2 (fun ⟨h0, hlt, _⟩ => hz ⟨h0, hlt⟩)).2 hmSt
                · push_neg at ht10_13 ht14_16
                  have ho := hInvL.other_loc (.heap t' i') hne1
                    (fun _ => ⟨by simp [ht10_13.1], by simp [ht10_13.2]⟩)
                    (fun _ => ⟨by simp [ht14_16.1], by simp [ht14_16.2.1], by simp [ht14_16.2.2]⟩)
                  have hmSt := ho.1.mp hmL
                  rcases hinv.live_cases _ hmSt with hb | ⟨_, _, _, heq⟩ | ⟨t0, i0, ht_or, heq⟩
                  · exact hnotBase hb
                  · cases heq
                  · cases heq
                    rcases ht_or with rfl | rfl | rfl | rfl | rfl | rfl
                    · exact ht10_13.1 rfl
                    · have hi1 : i' ≠ 4 := fun h => hne4 (by simp [h])
                      have hi5 : i' ≠ 5 := fun h => hne5 (by simp [h])
                      exact hinv.tab12_other i' hi1 hi5 hmSt
                    · exact ht10_13.2 rfl
                    · exact ht14_16.1 rfl
                    · exact ht14_16.2.1 rfl
                    · exact ht14_16.2.2 rfl
      · intro hmBase
        have hb : IsA2BaseLoc loc := hinv.wfBase.2 loc hmBase
        have hmSt : loc ∈ st.words.live := (hinv.base_live loc hb).mpr hmBase
        have hne5 : loc ≠ .heap 12 5 := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne4 : loc ≠ .heap 12 4 := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne1 : loc ≠ .heap 12 1 := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have ho := hInvL.other_loc loc hne1
          (fun _ => ⟨by intro h; subst h; simp [IsA2BaseLoc] at hb,
                     by intro h; subst h; simp [IsA2BaseLoc] at hb⟩)
          (fun _ => ⟨by intro h; subst h; simp [IsA2BaseLoc] at hb,
                     by intro h; subst h; simp [IsA2BaseLoc] at hb,
                     by intro h; subst h; simp [IsA2BaseLoc] at hb⟩)
        exact ⟨hne5, hne4, hne1, ho.1.mpr hmSt⟩
    cases hEqF : stF3.words with
    | mk lvF vlF =>
      cases hEqB : wsBaseNew with
      | mk lvB vlB =>
        rw [hEqF, hEqB] at hlive_eq; dsimp only at hlive_eq; subst lvF
        congr 1; funext loc
        by_cases hm : loc ∈ lvB
        · have hb : IsA2BaseLoc loc := by
            have := hinv.wfBase.2 loc; rw [hEqB] at this; exact this hm
          have hne5 : loc ≠ .heap 12 5 := by intro h; subst h; simp [IsA2BaseLoc] at hb
          have hne4 : loc ≠ .heap 12 4 := by intro h; subst h; simp [IsA2BaseLoc] at hb
          have hne1 : loc ≠ .heap 12 1 := by intro h; subst h; simp [IsA2BaseLoc] at hb
          have ho := hInvL.other_loc loc hne1
            (fun _ => ⟨by intro h; subst h; simp [IsA2BaseLoc] at hb,
                       by intro h; subst h; simp [IsA2BaseLoc] at hb⟩)
            (fun _ => ⟨by intro h; subst h; simp [IsA2BaseLoc] at hb,
                       by intro h; subst h; simp [IsA2BaseLoc] at hb,
                       by intro h; subst h; simp [IsA2BaseLoc] at hb⟩)
          have hvF : stF3.words.vals loc = vlF loc := by rw [hEqF]
          have hvB : wsBaseNew.vals loc = vlB loc := by rw [hEqB]
          rw [← hvF, ← hvB, hwF3, hwF2, hwF1]
          rw [ws_free_vals, Function.update_of_ne hne5,
              ws_free_vals, Function.update_of_ne hne4,
              ws_free_vals, Function.update_of_ne hne1]
          exact ho.2.trans (hinv.base_vals loc hb)
        · have hvF : vlF loc = 0 := by
            have := hwfF3 loc; rw [hEqF] at this; exact this hm
          have hvB : vlB loc = 0 := by
            have := hinv.wfBase.1 loc; rw [hEqB] at this; exact this hm
          rw [hvF, hvB]
  refine ⟨stF3, htot, hwClean_eq,
    by rw [hfdF3, hfdF2, hfdF1, hfdL]; dsimp [stLoop0]; exact hfd1,
    by rw [hrbF3, hrbF2, hrbF1, hrbL]; dsimp [stLoop0]; exact hrb1,
    ?_, ?_, hpCF3, hpBF3⟩
  · have hL0_uc : stLoop0.unitCost = st1.unitCost + 2 := rfl
    have hmS : 32 * highSid ≤ 32 * S_max := Nat.mul_le_mul_left 32 hhigh_S
    linarith only [huc1, hL0_uc, hucL, hucF1, hucF2, hucF3, hmS]
  · have hh_bl : intBitLength (highSid : ℤ) ≤ S_bits := hsid_bl highSid hhigh_S
    have hL0_bc : stLoop0.bitCost = st1.bitCost + (12 + intBitLength (highSid : ℤ)) := rfl
    rw [h12, hl1, hl0] at hbc1
    rw [h12, hl1] at hbcF1; rw [h12, hl4] at hbcF2; rw [h12, hl5] at hbcF3
    change stL.bitCost + 8 * stL.words.bitSize ≤
      stLoop0.bitCost + 8 * stLoop0.words.bitSize + highSid * (40 * S_bits + 256) at hbcL
    have hmS : highSid * (40 * S_bits + 256) ≤ S_max * (40 * S_bits + 256) :=
      Nat.mul_le_mul_right _ hhigh_S
    have hbBound_ge : st.words.bitSize + 20 * S_bits + 200 ≤ a2BitBound wsBaseNew inpSim T_max S_max subPeakBit := by
      linarith only [hHeadBit]
    linarith only [hbc1, hL0_bc, hbLoop0, hbcL, hbcF1, hbcF2, hbcF3, hmS, hh_bl, hbBound_ge]

end UL.C12LVE
