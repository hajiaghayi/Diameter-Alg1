import Mathlib
import UL.Stmt.clm_7_3_las_vegas_endpoint
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H1_Easy
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3c3_Dim0
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1a_BufAndStepA
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b3_StepBFull
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1c1_StepDMath
import UL.Proof.clm_7_3_las_vegas_endpoint.CG11_AssembleA0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open scoped ENNReal
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### 1. Clean Step Specifications (`C11StepC1Spec`, `C11StepC2Spec`, `C11StepDSpec`) and `progPosDim` -/

def C11StepC1Spec {d s₀_d : ℕ} (n L B B_cert K_max W U_c1 B_c1 : ℕ)
    (c1Stmt : BitRAMStmt) (jSrc : JSource) : Prop :=
  ∀ {inp : BitRAMInput d} {C_cell C_bit : ℕ}
    {P P' : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap qMap' : ℕ → Fin d → ℚ} {ws wsB : WordStore} {regsB : ℕ → ℤ}
    {op : DynamicUpdate d} {hOp : ℕ} {retHVal : ℤ}
    {slotTriggers : ℕ → Prop} {rebuildWork canceledBirthSum : ℕ},
    let ltCoords' := opNextLtCoords P ltCoords op
    let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
    ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws →
    P'.WellFormed n →
    OpStepASpec P P' qMap qMap' hOp op →
    (∀ id ∈ P'.activeIds,
      ltCoords' (P'.lifetimeOfId id) = P'.coords id ∧
      P'.coords id = ratPointToEuclidean (qMap' (P'.handleOfId id))) →
    (∀ lt < P'.nextLifetime, ltCoords' lt ∈ RatAdmissiblePointSet d B ∨ ltCoords' lt = 0) →
    (hupd_len : updatedNodes.length = nodes.length) →
    (∀ (j : ℕ) (hj : j < nodes.length),
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).built = (nodes.get ⟨j, hj⟩).built ∧
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).birthPool = (nodes.get ⟨j, hj⟩).birthPool) →
    (∀ (j : ℕ) (hj : j < nodes.length),
      ¬ slotTriggers j →
        let vUpd := updatedNodes.get ⟨j, hupd_len ▸ hj⟩
        (vUpd.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (vUpd.birthPool.card : ℝ) / 16) →
    ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsB →
    inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell →
    inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit →
    RegBounded W regsB →
    wsB.read (.heap 0 10) = (nodes.length : ℤ) →
    wsB.read (.heap 0 0) = retHVal →
    wsB.read (.heap 9 106) = (jStarStep nodes.length slotTriggers (nodes.length + 1) : ℤ) →
    ActiveCoordsStored d L B P'.activeHandles qMap' wsB →
    TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsB →
    TreeStoredAt L 1
      ((chainInput ltCoords' vecNodes (activeLifetimes P') (Fin.last nodes.length)).image (handleOfLifetime P'))
      (fun _ => 0) (fun _ => 1) wsB →
    (∀ (j : ℕ) (hj : j < nodes.length),
      PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap'
        (chainInput ltCoords' vecNodes (activeLifetimes P') ⟨j, Nat.lt_succ_of_lt hj⟩)
        (updatedNodes.get ⟨j, hupd_len ▸ hj⟩) j wsB) →
    (∀ j : ℕ, nodes.length ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j wsB) →
    (∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7 ∨ t = 8) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsB.live) →
    (∀ z : ℤ, z ≠ 102 → z ≠ 103 → z ≠ 104 → z ≠ 105 → z ≠ 106 → (.heap 9 z : RAMCellLoc) ∉ wsB.live) →
    ∀ (hTrig : ∃ j ≤ nodes.length, slotTriggers j),
      let jStar := jStarStep nodes.length slotTriggers (nodes.length + 1)
      let hjLe : jStar ≤ nodes.length := ((jStarStep_final nodes.length slotTriggers).1 hTrig).2.1
      let S_trig := chainInput ltCoords' vecNodes (activeLifetimes P') ⟨jStar, Nat.lt_succ_of_le hjLe⟩
      (S_trig.card ≤ 2 * s₀_d - 1 ∨ S_trig.card ≤ rebuildWork) →
      rebuildWork ≤ canceledBirthSum →
      ∃ wsC1 regsC1,
        RegExec inp 1 W C_cell C_bit c1Stmt wsB regsB wsC1 regsC1
          (U_c1 * (canceledBirthSum + 1)) (B_c1 * (canceledBirthSum + 1)) ∧
        RegBounded W regsC1 ∧
        MidSuffixChainInv n L B B_cert K_max W P' ltCoords'
          (updatedNodes.take jStar) qMap' retHVal S_trig wsC1 ∧
        StdBufLoopExtra jSrc L P' (updatedNodes.take jStar).length S_trig wsC1 regsC1

def C11StepC2Spec {d s₀_d : ℕ}
    (n L B B_cert K_max W A2_cell_slack A2_bit_slack K_c2_u K_c2_b : ℕ)
    (ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d s₀_d))
    (c2Stmt : BitRAMStmt) (jSrc : JSource) : Prop :=
  ∀ {inp : BitRAMInput d} {C_cell C_bit : ℕ}
    {hist : ExecutionHistory d}
    {P P' : DynamicPointSet d} {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {qMap' : ℕ → Fin d → ℚ} {op : DynamicUpdate d} {retHVal : ℤ},
    c12ReplayHistory d hist = P →
    P.WellFormed n →
    P'.WellFormed n →
    IsLegalUpdate n (RatAdmissiblePointSet d B) P op →
    applyDynamicUpdate P op (stepRetHandle mexHandle P.activeHandles op) = some P' →
    inp.inputCellSpace + (posDimWriteLocs d L K_max).card + A2_cell_slack + 16 ≤ C_cell →
    inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + A2_bit_slack + 16 * (W + 12) ≤ C_bit →
    ∀ (prefNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)))
      (acc : List (SyncSuffixPrefixEntry d (PosDimNodeData d s₀_d)))
      (R : Finset ℕ) (wsHeap : WordStore) (regs : ℕ → ℤ)
      (bs₁ tailBits : List Bool) (out : SyncBuiltNode d (PosDimNodeData d s₀_d))
      (st : BitRAMExecState),
      let curNodes := prefNodes ++ entriesToLiveNodes acc
      let j := curNodes.length
      j < K_max →
      2 * s₀_d ≤ R.card → R.card ≤ n →
      R ⊆ activeLifetimes P' →
      (∀ lt ∈ R, lt < P'.nextLifetime ∧ ltCoords' lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist acc ltCoords' R bs₁ = some out →
      MidSuffixChainInv n L B B_cert K_max W P' ltCoords' curNodes qMap' retHVal R wsHeap →
      StdBufLoopExtra jSrc L P' j R wsHeap regs →
      st.frameDepth = 1 →
      HasRegFrame 1 wsHeap regs st.words →
      RegBounded W regs →
      st.remainingBits = bs₁ ++ tailBits →
      st.peakCellSpace ≤ C_cell →
      st.peakBitSpace ≤ C_bit →
      let vNew : SyncLiveChainNode d (PosDimNodeData d s₀_d) :=
        { built := out, birthPool := R, ageUpdateSteps := ∅ }
      let R' := out.node.residual ltCoords' R
      ∃ (st' : BitRAMExecState) (wsHeap' : WordStore) (regs' : ℕ → ℤ),
        RunsTo inp [.stmt c2Stmt] st st' ∧
        st'.frameDepth = 1 ∧
        HasRegFrame 1 wsHeap' regs' st'.words ∧
        RegBounded W regs' ∧
        st'.remainingBits = tailBits ∧
        st'.unitCost ≤ st.unitCost + K_c2_u * (out.work + 1) ∧
        st'.bitCost ≤ st.bitCost + K_c2_b * (out.work + 1) ∧
        st'.peakCellSpace ≤ C_cell ∧
        st'.peakBitSpace ≤ C_bit ∧
        MidSuffixChainInv n L B B_cert K_max W P' ltCoords' (curNodes ++ [vNew]) qMap' retHVal R' wsHeap' ∧
        StdBufLoopExtra jSrc L P' (j + 1) R' wsHeap' regs'

def C11StepDSpec {d s₀_d : ℕ} (n L B B_cert K_max W U_D B_D : ℕ)
    (stepDStmt : BitRAMStmt) : Prop :=
  ∀ {inp : BitRAMInput d} {C_cell C_bit : ℕ}
    {P' : DynamicPointSet d} {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {finalNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap' : ℕ → Fin d → ℚ} {wsC : WordStore} {regsC : ℕ → ℤ} {retHVal : ℤ},
    ChainStoredInv n L B B_cert K_max W P' ltCoords' finalNodes qMap' wsC →
    inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell →
    inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit →
    RegBounded W regsC →
    wsC.read (.heap 0 0) = retHVal →
    ∃ wsD regsD,
      RegExec inp 1 W C_cell C_bit stepDStmt wsC regsC wsD regsD U_D B_D ∧
      ChainStoredInv n L B B_cert K_max W P' ltCoords' finalNodes qMap' wsD ∧
      wsD.read (.heap 0 0) = retHVal ∧
      let ca := BitRAMDynamicProgram.readCachedAnswer wsD
      ({ diameterHandles := ca.1, cachedDistSq := ca.2 } : StoredDiameterAnswer) =
        ramCheckedAnswer L P' finalNodes

def progPosDim (d s₀_d L : ℕ) (c1Stmt c2Stmt : BitRAMStmt) (jSrc : JSource)
    (stepDStmt : BitRAMStmt) : BitRAMDynamicProgram :=
  { initStmt := .skip
    updateStmt :=
      .localScope
        (.seq (posDimStepA d L)
          (.seq (posDimStepB d s₀_d L)
            (.seq (posDimStepCStmt c1Stmt (defaultSuffixLoopCond s₀_d) c2Stmt
                    (storeTerminalLeafFromBufRegs L jSrc))
                  stepDStmt))) }

/-! ### 2. Single-Step `BitRAM` Simulation (`exec_progPosDim_singleStep`) -/

def c11StepBaseBitCost (d s₀_d L K_max W B_c1 K_c2_b B_D : ℕ) : ℕ :=
  ((80 * L + 220 * d + 120) +
    (K_max + 1) * (180 * L + 80 * d + 240) +
    (2 * s₀_d) * (66 * L + 96)) * W * W +
  B_c1 + (4 * W + 24 + K_c2_b) * K_max + 4300 * W + B_D

def c11StepRebBitFactor (W B_c1 K_c2_b : ℕ) : ℕ :=
  2 * B_c1 + 4 * W + 24 + K_c2_b

theorem exec_progPosDim_singleStep
    (h_del_wit : S_claim_A_2_deletion_witness)
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength K_max + natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W)
    {C_nodes : ℝ}
    (h51_len : ∀ (P : Finset ℕ), P.card ≤ n →
      ∀ (k : ℕ) (nodes : Fin k → ChainNode d)
        (P₀ : Fin k → Finset ℕ)
        (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
        (age : Fin k → ℕ)
        (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)),
        (∀ i : Fin k,
          (nodes i).o = o i ∧
          (nodes i).V = liftVariance (o i) (s i) ∧
          1 ≤ (P₀ i).card ∧
          IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
            (paraboloidLiftSet (fun j : P₀ i => ltCoords j.1)) (liftedPoint (o i) (s i)) ∧
          HasNodeAge (P₀ i) (chainInput ltCoords nodes P i.castSucc) (age i) ∧
          (age i : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * ((P₀ i).card : ℝ) / 16) →
        (k : ℝ) ≤ C_nodes * (1 / (4 * (s₀_d : ℝ)))⁻¹ * Real.log ((n : ℝ) + 1))
    (hK_bound : C_nodes * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) ≤ (K_max : ℝ))
    {ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d s₀_d)}
    {P_node_val : ℝ}
    (hctor : IsValidSyncNodeConstructor n (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ))) 1 P_node_val
      (RatAdmissiblePointSet d B) ctor)
    (hctor_wk : ∀ hist sufPref ltCoords P₀ bs built,
      2 * s₀_d ≤ P₀.card →
      (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
        P₀.card ≤ built.work)
    {c1Stmt c2Stmt stepDStmt : BitRAMStmt} {jSrc : JSource}
    {A2_cell_slack A2_bit_slack U_c1 B_c1 K_c2_u K_c2_b U_D B_D C_cell C_bit : ℕ}
    (hSpecC1 : C11StepC1Spec (d := d) (s₀_d := s₀_d) n L B B_cert K_max W U_c1 B_c1 c1Stmt jSrc)
    (hSpecC2 : C11StepC2Spec n L B B_cert K_max W A2_cell_slack A2_bit_slack K_c2_u K_c2_b ctor c2Stmt jSrc)
    (hSpecD : C11StepDSpec (d := d) (s₀_d := s₀_d) n L B B_cert K_max W U_D B_D stepDStmt)
    {cur syncNext : SyncSchedulePrefixState d (PosDimNodeData d s₀_d)}
    {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    {op : DynamicUpdate d} {bs : List Bool} {inp : BitRAMInput d}
    (hcCeil_a2 : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + A2_cell_slack + 16 ≤ C_cell)
    (hbCeil_a2 : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + A2_bit_slack + 16 * (W + 12) ≤ C_bit)
    (hReplay : c12ReplayHistory d cur.history = cur.pointSet)
    (hu_age : ∀ (j : Fin cur.nodes.length), ∀ s ∈ (cur.nodes.get j).ageUpdateSteps, s < cur.history.length)
    (hinv : ChainStoredInv n L B B_cert K_max W cur.pointSet cur.ltCoords cur.nodes qMap ws)
    (hleg : IsLegalUpdate n (RatAdmissiblePointSet d B) cur.pointSet op)
    (hdecomp : C12SyncStepDecomp s₀_d L ctor cur syncNext op bs)
    (hinp_spec : match op with
      | .insert _ _ pt =>
          ∃ qIns : Fin d → ℚ,
            RatPointBitBounded B qIns ∧
            ratPointToEuclidean qIns = pt ∧
            inp.intParams = [(n : ℤ), 1, 0] ∧
            inp.extraRats = List.ofFn qIns
      | .delete id =>
          inp.intParams = [(n : ℤ), 0, (cur.pointSet.handleOfId id : ℤ)] ∧
          inp.extraRats = []) :
    ∃ (rawOut : BitRAMExecOutcome) (qMapNext : ℕ → Fin d → ℚ),
      runBitRAMWithBits (progPosDim d s₀_d L c1Stmt c2Stmt jSrc stepDStmt).updateStmt inp ws bs = some rawOut ∧
      ChainStoredInv n L B B_cert K_max W syncNext.pointSet syncNext.ltCoords
        syncNext.nodes qMapNext rawOut.words ∧
      (match op with
       | .insert _ _ _ =>
           rawOut.words.read (.heap 0 0) = (mexHandle cur.pointSet.activeHandles : ℤ)
       | .delete _ => True) ∧
      (let ca := BitRAMDynamicProgram.readCachedAnswer rawOut.words
       ({ diameterHandles := ca.1, cachedDistSq := ca.2 } : StoredDiameterAnswer) =
         ramCheckedAnswer L syncNext.pointSet syncNext.nodes) ∧
      rawOut.bitCost + B_c1 * c12ChainBirthPot syncNext ≤
        c11StepBaseBitCost d s₀_d L K_max W B_c1 K_c2_b B_D +
        B_c1 * c12ChainBirthPot cur +
        c11StepRebBitFactor W B_c1 K_c2_b * (syncNext.totalRebuildWork - cur.totalRebuildWork) ∧
      rawOut.peakBitSpace ≤ C_bit := by
  set prog := progPosDim d s₀_d L c1Stmt c2Stmt jSrc stepDStmt
  set P := cur.pointSet
  set ltCoords := cur.ltCoords
  set nodes := cur.nodes
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by omega
  have hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by omega
  obtain ⟨hpop0, hrf0⟩ := HasRegFrame.enterScope (fd := 1) (by decide) hinv.mod.wf hinv.no_local
  have hbnd0 : RegBounded W (fun _ : ℕ => (0 : ℤ)) := RegBounded.init (by omega)
  obtain ⟨hcell_ws, hbit_ws⟩ := hinv.mod.space_le
  have hemp_c : WordStore.empty.cellCount = 0 := rfl
  have hemp_b : WordStore.empty.bitSize = 0 := rfl
  rw [hemp_c, zero_add] at hcell_ws
  rw [hemp_b, zero_add] at hbit_ws
  let st0 : BitRAMExecState :=
    { words := ws.popDepth 0
      frameDepth := 0
      remainingBits := bs
      unitCost := 0
      bitCost := 0
      peakCellSpace := inp.inputCellSpace + (ws.popDepth 0).cellCount
      peakBitSpace := inp.inputBitSpace + (ws.popDepth 0).bitSize }
  let stIn : BitRAMExecState :=
    { st0 with words := st0.words.popDepth st0.frameDepth, frameDepth := st0.frameDepth + 1 }
  have hrfIn : HasRegFrame 1 ws (fun _ => 0) stIn.words := by
    dsimp [stIn, st0]; rw [hpop0]; exact hrf0
  have hpC_in : stIn.peakCellSpace ≤ C_cell := by
    dsimp [stIn, st0]; rw [hpop0]; linarith only [hcell_ws, hcCeil]
  have hpB_in : stIn.peakBitSpace ≤ C_bit := by
    dsimp [stIn, st0]; rw [hpop0]; linarith only [hbit_ws, hbCeil]
  have hW_A : B + natBitLength d + L + 28 ≤ W := by
    have hB_sq : B ≤ sqRadBitBound d B B_cert := by unfold sqRadBitBound; nlinarith only [hd1]
    clear * - hW hB_sq; omega
  obtain ⟨P'₁, qMap'₁, hOp, wsA, regsA, happ₁, hwfP'₁, hexecA, hmA, hbndA,
    hcoordsA₁, htree0A, hlt_sync'₁, hlt_adm'₁, hq_unch, hr102A, hr103A,
    hhOp_lt, hhOp_case, hunchA⟩ :=
    exec_posDimStepA hd1 hn hL hB1 hW_A (inp := inp) (fd := 1) (C_cell := C_cell) (C_bit := C_bit)
      (by decide) hinv hcCeil hbCeil hleg (by cases op <;> exact hinp_spec) hbnd0
  have happ₁_std : applyDynamicUpdate P op (stepRetHandle mexHandle P.activeHandles op) = some P'₁ := by
    cases op <;> exact happ₁
  have hP'_eq : P'₁ = syncNext.pointSet := Option.some.inj (happ₁_std.symm.trans hdecomp.apply_eq)
  subst hP'_eq
  set P' := syncNext.pointSet
  set ltCoords' := opNextLtCoords P ltCoords op
  have hlt_sync'₁_std : ∀ id' ∈ P'.activeIds,
      ltCoords' (P'.lifetimeOfId id') = P'.coords id' ∧
      P'.coords id' = ratPointToEuclidean (qMap'₁ (P'.handleOfId id')) := by
    cases op <;> exact hlt_sync'₁
  have hlt_adm'₁_std : ∀ lt < P'.nextLifetime, ltCoords' lt ∈ RatAdmissiblePointSet d B ∨ ltCoords' lt = 0 := by
    cases op <;> exact hlt_adm'₁
  let qMapNext : ℕ → Fin d → ℚ :=
    match op with
    | .insert _ _ _ => qMap'₁
    | .delete _ => qMap
  have hqMapNext_active : ∀ h ∈ P'.activeHandles, qMapNext h = qMap'₁ h := by
    intro h hh
    cases op with
    | insert _ _ _ => rfl
    | delete id =>
        dsimp only [qMapNext]
        have happ_del : applyDynamicUpdate P (.delete id) none = some P' := happ₁_std
        unfold applyDynamicUpdate at happ_del
        dsimp only at happ_del
        split_ifs at happ_del with hid_mem
        injection happ_del with hP_del
        rw [← hP_del] at hh
        dsimp only at hh
        have hh_old : h ∈ P.activeHandles := Finset.mem_of_mem_erase hh
        have hh_ne : h ≠ P.handleOfId id := Finset.ne_of_mem_erase hh
        exact (hq_unch h hh_old hh_ne).symm
  have hcoordsA : ActiveCoordsStored d L B P'.activeHandles qMapNext wsA :=
    { hS := fun h hh => by rw [hqMapNext_active h hh]; exact hcoordsA₁.hS h hh
      read_num := fun h hh c => by rw [hqMapNext_active h hh]; exact hcoordsA₁.read_num h hh c
      read_den := fun h hh c => by rw [hqMapNext_active h hh]; exact hcoordsA₁.read_den h hh c }
  have hlt_sync' : ∀ id' ∈ P'.activeIds,
      ltCoords' (P'.lifetimeOfId id') = P'.coords id' ∧
      P'.coords id' = ratPointToEuclidean (qMapNext (P'.handleOfId id')) := by
    intro id' hid'
    have hh' : P'.handleOfId id' ∈ P'.activeHandles := (hwfP'₁.2.1 id' hid').1
    rw [hqMapNext_active _ hh']
    exact hlt_sync'₁_std id' hid'
  have hop_spec : OpStepASpec P P' qMap qMapNext hOp op := by
    cases op with
    | insert id extName pt =>
        obtain ⟨hhOp_mex, _⟩ := hhOp_case
        have happ_ins : applyDynamicUpdate P (.insert id extName pt) (some hOp) = some P' := by
          rw [hhOp_mex]; exact happ₁_std
        have hhOp_notMem : hOp ∉ P.activeHandles := by
          rw [hhOp_mex]; exact mexHandle_notMem P.activeHandles
        unfold applyDynamicUpdate at happ_ins
        dsimp only at happ_ins
        split_ifs at happ_ins with hcond_ins
        injection happ_ins with hP_ins
        have hid_in' : id ∈ P'.activeIds := by
          rw [← hP_ins]; exact Finset.mem_insert_self id _
        have hhOp_in' : hOp ∈ P'.activeHandles := by
          rw [← hP_ins]; exact Finset.mem_insert_self hOp _
        have hcoords_pt : P'.coords id = pt := by
          rw [← hP_ins]; dsimp only; exact Function.update_self id pt P.coords
        have hhandle_id : P'.handleOfId id = hOp := by
          rw [← hP_ins]; dsimp only; exact Function.update_self id hOp P.handleOfId
        have hq_pt : ratPointToEuclidean (qMap'₁ hOp) = pt := by
          have hs := (hlt_sync'₁_std id hid_in').2
          rw [hcoords_pt, hhandle_id] at hs
          exact hs.symm
        refine ⟨?_, hhOp_notMem, hhOp_in', hq_pt, fun h hh => hq_unch h hh trivial⟩
        unfold applyDynamicUpdate
        dsimp only
        rw [if_pos hcond_ins, hP_ins]
    | delete id =>
        exact ⟨happ₁_std, hhOp_case, rfl⟩
  have hlt_preserve : ∀ lt < P.nextLifetime, ltCoords' lt = ltCoords lt := by
    intro lt hlt
    cases op with
    | delete _ => rfl
    | insert _ _ pt =>
        dsimp only [ltCoords', opNextLtCoords]
        exact Function.update_of_ne (ne_of_lt hlt) pt ltCoords
  obtain ⟨stA, hrunsA, hrfA, _, hfdA, hrbA, hucA, hbcA, hpCA, hpBA⟩ :=
    hexecA stIn rfl hrfIn hpC_in hpB_in
  have hW_B : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
      natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W := by
    clear * - hW; omega
  obtain ⟨wsB, regsB, hexecB, hmB, hbndB, hrB_k, hrB_00, hrB_106,
    hcoordsB, htree0B, htree1B, hpreB, hemptyB, hclean58B, hclean9B⟩ :=
    exec_posDimStepB hd1 hs₀1 hn hL hB1 hBc1 hW_B (inp := inp) (fd := 1) (C_cell := C_cell) (C_bit := C_bit)
      (by decide) hinv hcCeil hbCeil hu_age hhOp_lt hwfP'₁ hmA hcoordsA htree0A (by cases op <;> exact hr102A : wsA.read (.heap 9 102) = opIsIns op) hr103A
      hop_spec hunchA hbndA
  obtain ⟨stB, hrunsB, hrfB, _, hfdB, hrbB, hucB, hbcB, hpCB, hpBB⟩ :=
    hexecB stA hfdA hrfA hpCA hpBA
  set k := nodes.length
  set vecNodes : Fin k → ChainNode d := fun i => (nodes.get i).built.node
  set S_old : Fin (k + 1) → Finset ℕ := chainInput ltCoords' vecNodes (activeLifetimes P)
  set S_new : Fin (k + 1) → Finset ℕ := chainInput ltCoords' vecNodes (activeLifetimes P')
  let updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)) :=
    open Classical in
    List.ofFn (fun i : Fin k =>
      let v := nodes.get i
      let age' := if S_new i.castSucc ≠ S_old i.castSucc then
        insert cur.history.length v.ageUpdateSteps else v.ageUpdateSteps
      { v with ageUpdateSteps := age' })
  let slotTriggers : ℕ → Prop := fun j =>
    open Classical in
    if hj : j < k then
      let vOld := nodes.get ⟨j, hj⟩
      let ageCard :=
        (if S_new ⟨j, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨j, Nat.lt_succ_of_lt hj⟩ then
          insert cur.history.length vOld.ageUpdateSteps
        else
          vOld.ageUpdateSteps).card
      (1 / (4 * (s₀_d : ℝ))) * (vOld.birthPool.card : ℝ) / 16 < (ageCard : ℝ)
    else
      j = k ∧ 2 * (2 * s₀_d - 1) < (S_new (Fin.last k)).card
  set jStar := jStarStep k slotTriggers (k + 1)
  set rebuildWork := syncNext.totalRebuildWork - cur.totalRebuildWork
  set canceledBirthSum := ((nodes.drop jStar).map (fun v => v.birthPool.card)).sum + rebuildWork
  have hupd_len : updatedNodes.length = k := List.length_ofFn
  have hupd_node : ∀ (j : ℕ) (hj : j < k),
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).built = (nodes.get ⟨j, hj⟩).built ∧
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).birthPool = (nodes.get ⟨j, hj⟩).birthPool := by
    intro j hj
    simp only [updatedNodes, List.get_ofFn]
    exact ⟨rfl, rfl⟩
  have hW_C : natBitLength K_max + natBitLength (2 * s₀_d) + L + 32 ≤ W := by
    have h2s : natBitLength (2 * s₀_d) ≤ natBitLength (64 * s₀_d + 1) :=
      natBitLength_mono (by omega)
    clear * - hW h2s; omega
  have hctor_valid : ∀ (ltC : ℕ → EuclideanSpace ℝ (Fin d))
      (acc : List (SyncSuffixPrefixEntry d (PosDimNodeData d s₀_d)))
      (R : Finset ℕ) (bs₁ : List Bool) (out : SyncBuiltNode d (PosDimNodeData d s₀_d)),
      2 * s₀_d - 1 < R.card → R.card ≤ n →
      (∀ lt ∈ R, ltC lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits cur.history acc ltC R bs₁ = some out →
        out.node.V = liftVariance out.node.o out.s ∧
        IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
          (paraboloidLiftSet (fun i : R => ltC i.1))
          (liftedPoint out.node.o out.s) := by
    intro ltC acc R bs₁ out hR_gt hR_le hR_adm hbuild
    exact (hctor cur.history acc ltC R hR_gt hR_le hR_adm).2.2.1 bs₁ out hbuild
  have hsync_branch_C :
      let jS := jStarStep nodes.length slotTriggers (nodes.length + 1)
      if hTrig : ∃ j ≤ nodes.length, slotTriggers j then
        ∃ sufOut : SyncSuffixOutcome d (PosDimNodeData d s₀_d),
          let S_trig := chainInput ltCoords' (fun i : Fin nodes.length => (nodes.get i).built.node)
            (activeLifetimes P') ⟨jS, Nat.lt_succ_of_le ((jStarStep_final nodes.length slotTriggers).1 hTrig).2.1⟩
          runSyncSuffixBuild ctor (2 * s₀_d - 1) cur.history ltCoords' S_trig bs = some sufOut ∧
          syncNext.nodes = updatedNodes.take jS ++ entriesToLiveNodes sufOut.entries ∧
          rebuildWork = sufOut.totalWork
      else
        bs = [] ∧ syncNext.nodes = updatedNodes ∧ rebuildWork = 0 := by
    intro jS
    have hsb := hdecomp.sync_branch
    by_cases hTrig : ∃ j ≤ nodes.length, slotTriggers j
    · have hTrig' : ∃ j ≤ cur.nodes.length, slotTriggers j := hTrig
      rw [dif_pos hTrig]
      rw [dif_pos hTrig'] at hsb
      obtain ⟨sufOut, hsuf, hnodes_eq, hreb_eq⟩ := hsb
      exact ⟨sufOut, hsuf, hnodes_eq, hreb_eq⟩
    · have hTrig' : ¬ ∃ j ≤ cur.nodes.length, slotTriggers j := hTrig
      rw [dif_neg hTrig]
      rw [dif_neg hTrig'] at hsb
      exact hsb
  have hStepC1_inst : ∀ (hTrig : ∃ j ≤ k, slotTriggers j),
      let hjLe : jStar ≤ k := ((jStarStep_final k slotTriggers).1 hTrig).2.1
      let S_trig := S_new ⟨jStar, Nat.lt_succ_of_le hjLe⟩
      ∃ wsC1 regsC1,
        RegExec inp 1 W C_cell C_bit c1Stmt wsB regsB wsC1 regsC1
          (U_c1 * (canceledBirthSum + 1)) (B_c1 * (canceledBirthSum + 1)) ∧
        RegBounded W regsC1 ∧
        MidSuffixChainInv n L B B_cert K_max W P' ltCoords'
          (updatedNodes.take jStar) qMapNext (wsA.read (.heap 0 0)) S_trig wsC1 ∧
        StdBufLoopExtra jSrc L P' (updatedNodes.take jStar).length S_trig wsC1 regsC1 := by
    intro hTrig hjLe S_trig
    have hcard_or_reb : S_trig.card ≤ 2 * s₀_d - 1 ∨ S_trig.card ≤ rebuildWork := by
      by_cases hle : S_trig.card ≤ 2 * s₀_d - 1
      · exact Or.inl hle
      · right
        have hsb : if hT : ∃ j ≤ nodes.length, slotTriggers j then _ else _ := hsync_branch_C
        rw [dif_pos hTrig] at hsb
        obtain ⟨sufOut, hsuf, _, hreb_eq⟩ := hsb
        have hS_sub : S_trig ⊆ activeLifetimes P' :=
          chainInput_subset_base ltCoords' vecNodes (activeLifetimes P') _
        have hS_adm : ∀ lt ∈ S_trig, ltCoords' lt ∈ RatAdmissiblePointSet d B :=
          fun lt hlt => (activeLifetimes_adm_and_lt hwfP'₁ hlt_sync' hcoordsA lt (hS_sub hlt)).2.1
        rw [hreb_eq]
        exact runSyncSuffixBuild_head_card_le_work (Nat.lt_of_not_ge hle)
          (fun bs₁ out hb => hctor_wk cur.history [] ltCoords' S_trig bs₁ out (by omega) hS_adm hb) hsuf
    exact hSpecC1 hinv hwfP'₁ hop_spec hlt_sync' hlt_adm'₁_std hupd_len hupd_node hdecomp.no_trig_age
      hmB hcCeil hbCeil hbndB hrB_k hrB_00 hrB_106 hcoordsB htree0B htree1B hpreB hemptyB
      hclean58B hclean9B hTrig hcard_or_reb (Nat.le_add_left _ _)
  have hStepC2_inst :=
    hSpecC2 (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
      (hist := cur.history) (P := P) (P' := P') (ltCoords' := ltCoords')
      (qMap' := qMapNext) (op := op) (retHVal := wsA.read (.heap 0 0))
      hReplay hinv.wfP hwfP'₁ hleg hdecomp.apply_eq hcCeil_a2 hbCeil_a2
  have hrbB_bs : stB.remainingBits = bs := by
    rw [hrbB, hrbA]
  obtain ⟨stC, wsC, regsC, hrunsC, hfdC, hrfC, hbndC, hrbC,
    hinvC, hr00_C, hpCC, hpBC, _hucC, hbcC⟩ :=
    exec_posDimStepC h_del_wit hd1 hs₀1 hn hL hW_C h51_len hK_bound (hist := cur.history) hctor_valid
      (inp := inp) (fd := 1) (C_cell := C_cell) (C_bit := C_bit) (by decide)
      (c1Stmt := c1Stmt) (c2Stmt := c2Stmt) (jSrc := jSrc)
      (U_c1 := U_c1) (B_c1 := B_c1) (K_c2_u := K_c2_u) (K_c2_b := K_c2_b)
      (P := P) (P' := P') (ltCoords := ltCoords) (ltCoords' := ltCoords')
      (nodes := nodes) (updatedNodes := updatedNodes)
      (qMap := qMap) (qMap' := qMapNext) (ws := ws) (wsB := wsB) (regsB := regsB)
      (retHVal := wsA.read (.heap 0 0)) (slotTriggers := slotTriggers) (bs := bs)
      (finalNodes := syncNext.nodes) (rebuildWork := rebuildWork)
      (canceledBirthSum := canceledBirthSum)
      hinv hwfP'₁ hlt_sync' hlt_adm'₁_std hlt_preserve hupd_len hupd_node
      hdecomp.no_trig_age hdecomp.no_trig_leaf hmB hcCeil hbCeil hbndB
      hrB_k hrB_00 hrB_106 hcoordsB htree0B htree1B hpreB hemptyB hclean58B hclean9B
      (by
        intro jS
        by_cases hTrig : ∃ j ≤ nodes.length, slotTriggers j
        · rw [dif_pos hTrig]
          have hsb : if hT : ∃ j ≤ nodes.length, slotTriggers j then _ else _ := hsync_branch_C
          rw [dif_pos hTrig] at hsb
          exact hsb
        · rw [dif_neg hTrig]
          have hsb : if hT : ∃ j ≤ nodes.length, slotTriggers j then _ else _ := hsync_branch_C
          rw [dif_neg hTrig] at hsb
          exact hsb)
      hStepC1_inst hStepC2_inst stB hfdB hrfB hrbB_bs hpCB hpBB
  obtain ⟨wsD, regsD, hexecD, hinvD, hr00_D, hca_D⟩ :=
    hSpecD (inp := inp) (C_cell := C_cell) (C_bit := C_bit)
      hinvC hcCeil hbCeil hbndC hr00_C
  obtain ⟨stD, hrunsD, hrfD, _, hfdD, hrbD, _hucD, hbcD, hpCD, hpBD⟩ :=
    hexecD stC hfdC hrfC hpCC hpBC
  have hrunsCD := RunsTo.seq hrunsC hrunsD
  have hrunsBCD := RunsTo.seq hrunsB hrunsCD
  have hrunsBody := RunsTo.seq hrunsA hrunsBCD
  let stOut : BitRAMExecState :=
    { stD with words := stD.words.popDepth st0.frameDepth, frameDepth := st0.frameDepth }
  have hrunsScope : RunsTo inp [.stmt prog.updateStmt] st0 stOut :=
    RunsTo.localScope (inp := inp) (st := st0) (stBody := stD) hrunsBody
  have hstOut_words : stOut.words = wsD := by
    dsimp [stOut, st0]; exact hrfD.exitScope (by decide : 1 ≤ 1)
  have hwsD_pop0 : wsD.popDepth 0 = wsD :=
    (HasRegFrame.enterScope (fd := 1) (by decide) hinvD.mod.wf hinvD.no_local).1
  have hrbOut : stOut.remainingBits = [] := by
    dsimp [stOut]; rw [hrbD, hrbC]
  have hhalted := RunsTo.toRunBitRAMWithBits (prog := prog.updateStmt) (inp := inp)
    (initWords := ws) (bs := bs) hrunsScope hrbOut
  have hout_words : stOut.words.popDepth 0 = wsD := by
    rw [hstOut_words, hwsD_pop0]
  let rawOut : BitRAMExecOutcome :=
    { words := stOut.words.popDepth 0
      unitCost := stOut.unitCost
      bitCost := stOut.bitCost
      peakCellSpace := stOut.peakCellSpace
      peakBitSpace := stOut.peakBitSpace }
  have hret_handle_out :
      match op with
      | .insert _ _ _ => rawOut.words.read (.heap 0 0) = (mexHandle P.activeHandles : ℤ)
      | .delete _ => True := by
    cases op with
    | delete _ => trivial
    | insert _ _ _ =>
        dsimp only [rawOut]
        rw [hout_words, hr00_D, hhOp_case.2, hhOp_case.1]
  have hinv_next : ChainStoredInv n L B B_cert K_max W syncNext.pointSet syncNext.ltCoords
      syncNext.nodes qMapNext rawOut.words := by
    dsimp only [rawOut]
    rw [hout_words, hdecomp.ltCoords_eq]
    exact hinvD
  have hans_eq :
      (let ca := BitRAMDynamicProgram.readCachedAnswer rawOut.words
       ({ diameterHandles := ca.1, cachedDistSq := ca.2 } : StoredDiameterAnswer) =
         ramCheckedAnswer L syncNext.pointSet syncNext.nodes) := by
    dsimp only [rawOut]
    rw [hout_words]
    exact hca_D
  have hpot := hdecomp.pot_bound
  have hpot_mul :
      B_c1 * ((nodes.drop jStar).map (fun v => v.birthPool.card)).sum +
        B_c1 * c12ChainBirthPot syncNext ≤
      B_c1 * c12ChainBirthPot cur + B_c1 * rebuildWork := by
    have hm := Nat.mul_le_mul_left B_c1 hpot
    simp only [Nat.mul_add] at hm
    exact hm
  have hk_le_K : k ≤ K_max := hinv.hk_le
  have hB_cost_le :
      (k + 1) * (180 * L + 80 * d + 240) * W * W ≤
        (K_max + 1) * (180 * L + 80 * d + 240) * W * W :=
    Nat.mul_le_mul_right W (Nat.mul_le_mul_right W
      (Nat.mul_le_mul_right _ (Nat.add_le_add_right hk_le_K 1)))
  have hwork_pot :
      rawOut.bitCost + B_c1 * c12ChainBirthPot syncNext ≤
        c11StepBaseBitCost d s₀_d L K_max W B_c1 K_c2_b B_D +
        B_c1 * c12ChainBirthPot cur +
        c11StepRebBitFactor W B_c1 K_c2_b * rebuildWork := by
    have htot_bc : rawOut.bitCost ≤
        (80 * L + 220 * d + 120) * W * W +
        (K_max + 1) * (180 * L + 80 * d + 240) * W * W +
        B_c1 * (((nodes.drop jStar).map (fun v => v.birthPool.card)).sum + rebuildWork + 1) +
        (4 * W + 24 + K_c2_b) * (rebuildWork + K_max) +
        (2 * s₀_d) * (66 * L + 96) * W * W + 4300 * W + B_D := by
      dsimp only [rawOut, stOut, stIn, st0, canceledBirthSum] at hucA hbcA hbcB hbcC hbcD ⊢
      linarith only [hbcA, hbcB, hbcC, hbcD, hB_cost_le]
    unfold c11StepBaseBitCost c11StepRebBitFactor
    nlinarith only [htot_bc, hpot_mul]
  exact ⟨rawOut, qMapNext, hhalted, hinv_next, (by cases op <;> exact hret_handle_out), hans_eq, hwork_pot, hpBD⟩

end UL.C12LVE
