import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2c2b_LogInsert
set_option autoImplicit false
set_option maxHeartbeats 1600000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Helper evaluation for `encE = trA2Expr T_max idxE * T_max + table` -/

theorem eval_encA2Expr {d m B T_max : ℕ} {wsBase wsSub wsSim : WordStore}
    {inpSub : BitRAMInput d} {fdSub : ℕ}
    (inpSim : BitRAMInput d)
    (hstage : StagingA2Matches m B wsBase inpSub)
    (hT : 1 ≤ T_max)
    (hag : AgreesForA2Expr wsBase T_max wsSub fdSub wsSim)
    {table : ℕ} (ht : table < T_max)
    (idxE : IntExpr) (htm : maxTableExpr idxE ≤ T_max) :
    let (idx, u₁, b₁) := evalIntExpr inpSub fdSub wsSub idxE
    let encE := IntExpr.add (.mul (trA2Expr T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ))
    let K_p := a2ParamBits m d T_max
    ∃ uE bE : ℕ,
      evalIntExpr inpSim (2 + fdSub) wsSim encE =
        (idx * (T_max : ℤ) + (table : ℤ), uE, bE) ∧
      uE ≤ 2 * a2ExprFactor idxE * u₁ + 4 ∧
      bE ≤ a2ExprFactor idxE * K_p * b₁ + 6 * K_p * intBitLength idx := by
  have he := evalIntExpr_trA2Expr inpSim hstage hT hag idxE htm
  rcases h1 : evalIntExpr inpSub fdSub wsSub idxE with ⟨idx, u₁, b₁⟩
  rcases h2 : evalIntExpr inpSim (2 + fdSub) wsSim (trA2Expr T_max idxE) with ⟨idx', u'₁, b'₁⟩
  simp only [h1, h2] at he
  rcases he with ⟨heq, hu, hb⟩; subst idx'
  dsimp only
  set K_p := a2ParamBits m d T_max
  have hK_ge : 8 ≤ K_p := by dsimp [K_p]; unfold a2ParamBits; omega
  have hT_K : intBitLength (T_max : ℤ) ≤ K_p := by
    have := intBitLength_ofNat_le T_max
    dsimp [K_p]; unfold a2ParamBits; omega
  have ht_K : intBitLength (table : ℤ) ≤ K_p := by
    have h1 := intBitLength_ofNat_le table
    have h2 := natBitLength_mono (Nat.le_of_lt ht)
    dsimp [K_p]; unfold a2ParamBits; omega
  have hmul_bl : intBitLength (idx * (T_max : ℤ)) ≤ intBitLength idx + K_p := by
    have := intBitLength_mul_le idx (T_max : ℤ)
    linarith
  have hidx_pos := intBitLength_pos idx
  have hF_ge := a2ExprFactor_ge_64 idxE
  refine ⟨u'₁ + 1 + 1 + 1 + 1,
    b'₁ + intBitLength (T_max : ℤ) + intBitLength idx * intBitLength (T_max : ℤ) +
      intBitLength (table : ℤ) + intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ),
    by simp [evalIntExpr, h2, Nat.add_assoc],
    ?_, ?_⟩
  · have hmul2 : a2ExprFactor idxE * u₁ ≤ 2 * a2ExprFactor idxE * u₁ := by
      have : a2ExprFactor idxE ≤ 2 * a2ExprFactor idxE := by omega
      exact Nat.mul_le_mul_right u₁ this
    linarith
  · have hprod : intBitLength idx * intBitLength (T_max : ℤ) ≤ K_p * intBitLength idx := by
      calc intBitLength idx * intBitLength (T_max : ℤ)
          ≤ intBitLength idx * K_p := Nat.mul_le_mul_left _ hT_K
        _ = K_p * intBitLength idx := Nat.mul_comm _ _
    have h1K : K_p ≤ K_p * intBitLength idx := le_mul_of_one_le_right (Nat.zero_le K_p) hidx_pos
    have hidx_le : intBitLength idx ≤ K_p * intBitLength idx :=
      le_mul_of_one_le_left (Nat.zero_le _) (by omega)
    linarith only [hb, hprod, h1K, hidx_le, hT_K, ht_K, hmul_bl]

/-! ### 2. `exec_trA2WriteHeap` and `exec_trA2RandBitHeap` -/

theorem exec_trA2WriteHeap {d m B T_max S_max : ℕ}
    {wsBase wsSub wsSim : WordStore} {inpSub : BitRAMInput d}
    {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (inpSim : BitRAMInput d)
    (hstage : StagingA2Matches m B wsBase inpSub)
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    {table : ℕ} {idxE valE : IntExpr}
    (htm : maxTableStmt (.writeHeap table idxE valE) ≤ T_max)
    {fdSub : ℕ} (stSim : BitRAMExecState)
    (hwSim : stSim.words = wsSim) (hfd : stSim.frameDepth = 2 + fdSub)
    {subPeakCell subPeakBit : ℕ}
    (hcPeak : wsSub.cellCount ≤ subPeakCell)
    (hbPeak : wsSub.bitSize ≤ subPeakBit)
    (hSubCell : let (idx, _, _) := evalIntExpr inpSub fdSub wsSub idxE
                let (val, _, _) := evalIntExpr inpSub fdSub wsSub valE
                (wsSub.write (.heap table idx) val).cellCount ≤ S_max ∧
                (wsSub.write (.heap table idx) val).bitSize ≤ subPeakBit)
    (hpC : stSim.peakCellSpace ≤ a2CellBound wsBase inpSim S_max subPeakCell)
    (hpB : stSim.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit) :
    let (idx, u₁, b₁) := evalIntExpr inpSub fdSub wsSub idxE
    let (val, u₂, b₂) := evalIntExpr inpSub fdSub wsSub valE
    let Δu := u₁ + u₂ + 1
    let Δb := b₁ + b₂ + (natBitLength table + intBitLength idx) + intBitLength val
    let F := a2StmtFactor (.writeHeap table idxE valE)
    let K := a2ParamBits m d T_max + (natBitLength S_max + 4)
    ∃ stEnd : BitRAMExecState, ∃ highSid' sidOfEnc' encOfSid' freeStack',
      RunsTo inpSim [.stmt (trA2Stmt T_max (.writeHeap table idxE valE))] stSim stEnd ∧
      A2SimInv wsBase T_max S_max (wsSub.write (.heap table idx) val) stEnd.words
        highSid' sidOfEnc' encOfSid' freeStack' ∧
      stEnd.frameDepth = 2 + fdSub ∧
      stEnd.remainingBits = stSim.remainingBits ∧
      stEnd.unitCost ≤ stSim.unitCost + 8 * F * Δu ∧
      stEnd.bitCost ≤ stSim.bitCost + 8 * F * K * Δb ∧
      stEnd.peakCellSpace ≤ a2CellBound wsBase inpSim S_max subPeakCell ∧
      stEnd.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit := by
  simp only [maxTableStmt, max_le_iff] at htm
  have ht : table < T_max := by omega
  rcases h1 : evalIntExpr inpSub fdSub wsSub idxE with ⟨idx, u₁, b₁⟩
  rcases h2 : evalIntExpr inpSub fdSub wsSub valE with ⟨val, u₂, b₂⟩
  simp only [h1, h2] at hSubCell ⊢
  rcases hSubCell with ⟨hSubC, hSubB⟩
  set e : ℤ := idx * (T_max : ℤ) + (table : ℤ)
  set S_bits := natBitLength S_max + 4
  set K_p := a2ParamBits m d T_max
  set K := K_p + S_bits
  set F := a2StmtFactor (.writeHeap table idxE valE)
  obtain ⟨hHeadCell, hHeadBit⟩ := hinv.within_bounds inpSim hcPeak hbPeak
  change inpSim.inputBitSpace + wsSim.bitSize + 12 * subPeakBit + 16 * natBitLength T_max + 20 * S_bits + 200 ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit at hHeadBit
  have hmem_sub' : (.heap table idx : RAMCellLoc) ∈ (wsSub.write (.heap table idx) val).live := by
    simp [WordStore.write]
  have hidx_val_bl : natBitLength table + intBitLength idx + intBitLength val ≤ subPeakBit := by
    have hm := mem_live_bitLength_le hmem_sub'
    simp only [WordStore.write, Function.update_self, RAMCellLoc.bitLength] at hm
    exact hm.trans hSubB
  have he_bl := intBitLength_encA2_le ht idx
  have h10 : natBitLength 10 = 4 := by decide
  have h12 : natBitLength 12 = 4 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  have hl2 : intBitLength (2 : ℤ) = 3 := by decide
  -- 1. Evaluate `encE` and `.writeHeap 12 (.lit 1) encE`
  obtain ⟨uE, bE, hevE, huE, hbE⟩ :=
    eval_encA2Expr inpSim hstage hinv.hT (hinv.agreesForExpr fdSub) ht idxE htm.2.1
  simp only [h1] at hevE huE hbE
  have hc1 : inpSim.inputCellSpace + (wsSim.write (.heap 12 1) e).cellCount ≤
      a2CellBound wsBase inpSim S_max subPeakCell := by
    have := cellCount_write_le wsSim (.heap 12 1) e; linarith
  have hb1 : inpSim.inputBitSpace + (wsSim.write (.heap 12 1) e).bitSize ≤
      a2BitBound wsBase inpSim T_max S_max subPeakBit := by
    have h := bitSize_write_le wsSim (.heap 12 1) e
    dsimp [RAMCellLoc.bitLength] at h; rw [h12, hl1] at h; linarith
  obtain ⟨st1, hr1, hw1, hfd1, hrb1, huc1, hbc1, hpC1, hpB1⟩ :=
    exec_writeHeap_ceil inpSim 12 (.lit 1)
      (.add (.mul (trA2Expr T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ)))
      stSim hpC hpB (idx := 1) (val := e) (u₁ := 1) (b₁ := 2) (u₂ := uE) (b₂ := bE)
      (evalIntLe_lit _ _ _ _ (by decide)) (by unfold EvalIntLe; rw [hfd, hwSim, hevE]; exact ⟨rfl, le_rfl, le_rfl⟩) (by rw [hwSim]; exact hc1) (by rw [hwSim]; exact hb1)
  -- 2. Notice `st1.words` still satisfies `AgreesForA2Expr`! Evaluate `trA2Expr T_max valE` and `.writeHeap 12 (.lit 2) ...`
  have hag1 : AgreesForA2Expr wsBase T_max wsSub fdSub st1.words := by
    have hag0 := hinv.agreesForExpr fdSub
    rw [hw1, hwSim]
    refine ⟨fun t ht10 i => ?_, fun t htT i => ?_, fun v i => ?_⟩
    · rw [wordStore_read_write_ne _ (by simp; omega)]; exact hag0.1 t ht10 i
    · rw [wordStore_read_write_ne _ (by simp)]; exact hag0.2.1 t htT i
    · rw [wordStore_read_write_ne _ (by simp)]; exact hag0.2.2 v i
  have hevV := evalIntExpr_trA2Expr inpSim hstage hinv.hT hag1 valE htm.2.2
  rcases hv2 : evalIntExpr inpSim (2 + fdSub) st1.words (trA2Expr T_max valE) with ⟨val', u'₂, b'₂⟩
  simp only [h2, hv2] at hevV
  rcases hevV with ⟨heqV, hu2, hb2⟩; subst val'
  have hc2 : inpSim.inputCellSpace + (st1.words.write (.heap 12 2) val).cellCount ≤
      a2CellBound wsBase inpSim S_max subPeakCell := by
    have h_a := cellCount_write_le st1.words (.heap 12 2) val
    have h_b := cellCount_write_le wsSim (.heap 12 1) e
    rw [hw1, hwSim] at h_a ⊢; linarith only [h_a, h_b, hHeadCell]
  have hb2_sp : inpSim.inputBitSpace + (st1.words.write (.heap 12 2) val).bitSize ≤
      a2BitBound wsBase inpSim T_max S_max subPeakBit := by
    have h_a := bitSize_write_le st1.words (.heap 12 2) val
    have h_b := bitSize_write_le wsSim (.heap 12 1) e
    dsimp [RAMCellLoc.bitLength] at h_a h_b; rw [h12, hl2] at h_a; rw [h12, hl1] at h_b
    rw [hw1, hwSim] at h_a ⊢; linarith only [h_a, h_b, he_bl, hidx_val_bl, hHeadBit]
  obtain ⟨st2, hr2, hw2, hfd2, hrb2, huc2, hbc2, hpC2, hpB2⟩ :=
    exec_writeHeap_ceil inpSim 12 (.lit 2) (trA2Expr T_max valE)
      st1 hpC1 hpB1 (idx := 2) (val := val) (u₁ := 1) (b₁ := 3) (u₂ := u'₂) (b₂ := b'₂)
      (evalIntLe_lit _ _ _ _ (by decide)) (by unfold EvalIntLe; rw [hfd1, hfd, hv2]; exact ⟨rfl, le_rfl, le_rfl⟩) hc2 hb2_sp
  -- 3. `.writeHeap 10 (.readHeap 12 (.lit 1)) (.readHeap 12 (.lit 2))`
  have hr2_12_1 : st2.words.read (.heap 12 1) = e := by
    rw [hw2, wordStore_read_write_ne _ (by decide), hw1]; simp
  have hr2_12_2 : st2.words.read (.heap 12 2) = val := by rw [hw2]; simp
  have hc3 : inpSim.inputCellSpace + (st2.words.write (.heap 10 e) val).cellCount ≤
      a2CellBound wsBase inpSim S_max subPeakCell := by
    have h_c := cellCount_write_le st2.words (.heap 10 e) val
    have h_a := cellCount_write_le st1.words (.heap 12 2) val
    have h_b := cellCount_write_le wsSim (.heap 12 1) e
    rw [hw2] at h_c ⊢; rw [hw1, hwSim] at h_c h_a ⊢; linarith only [h_c, h_a, h_b, hHeadCell]
  have hb3_sp : inpSim.inputBitSpace + (st2.words.write (.heap 10 e) val).bitSize ≤
      a2BitBound wsBase inpSim T_max S_max subPeakBit := by
    have h_c := bitSize_write_le st2.words (.heap 10 e) val
    have h_a := bitSize_write_le st1.words (.heap 12 2) val
    have h_b := bitSize_write_le wsSim (.heap 12 1) e
    dsimp [RAMCellLoc.bitLength] at h_c h_a h_b
    rw [h10] at h_c; rw [h12, hl2] at h_a; rw [h12, hl1] at h_b
    rw [hw2] at h_c ⊢; rw [hw1, hwSim] at h_c h_a ⊢; linarith only [h_c, h_a, h_b, he_bl, hidx_val_bl, hHeadBit]
  obtain ⟨st3, hr3, hw3, hfd3, hrb3, huc3, hbc3, hpC3, hpB3⟩ :=
    exec_writeHeap_ceil inpSim 10 (.readHeap 12 (.lit 1)) (.readHeap 12 (.lit 2))
      st2 hpC2 hpB2 (idx := e) (val := val)
      (u₁ := 2) (b₁ := 8 + intBitLength e) (u₂ := 2) (b₂ := 10 + intBitLength val)
      (evalIntLe_readHeap_lit inpSim st2.frameDepth st2.words 12 1 _ (b := 8 + intBitLength e) hr2_12_1 h12 hl1 (le_of_eq (by ring)))
      (evalIntLe_readHeap_lit inpSim st2.frameDepth st2.words 12 2 _ (b := 10 + intBitLength val) hr2_12_2 h12 hl2 (le_of_eq (by ring)))
      hc3 hb3_sp
  -- 4. `trA2LogInsertAfterWrite`
  have hw3_shape : st3.words =
      let w1 := wsSim.write (.heap 12 1) e
      let w2 := if true then w1.write (.heap 12 2) val else w1
      w2.write (.heap 10 e) val := by
    rw [hw3, hw2, hw1, hwSim]; rfl
  obtain ⟨st4, highSid', sidOfEnc', encOfSid', freeStack', hr4, hinv4, hfd4, hrb4, huc4, hbc4, hpC4, hpB4⟩ :=
    exec_trA2LogInsertAfterWrite inpSim hinv ht idx val true hSubC hcPeak hbPeak hSubB st3 hw3_shape hpC3 hpB3
  have htot : RunsTo inpSim [.stmt (trA2Stmt T_max (.writeHeap table idxE valE))] stSim st4 :=
    RunsTo.seq hr1 (RunsTo.seq hr2 (RunsTo.seq hr3 hr4))
  refine ⟨st4, highSid', sidOfEnc', encOfSid', freeStack', htot, hinv4,
    by rw [hfd4, hfd3, hfd2, hfd1, hfd],
    by rw [hrb4, hrb3, hrb2, hrb1],
    ?_, ?_, hpC4, hpB4⟩
  · -- Unit cost bound: `≤ stSim.unitCost + 8 * F * (u₁ + u₂ + 1)`
    have hF_def : F = 64 * (a2ExprFactor idxE + a2ExprFactor valE) := rfl
    have hF_ge := a2StmtFactor_pos (.writeHeap table idxE valE)
    have h1_u : a2ExprFactor idxE * u₁ ≤ (a2ExprFactor idxE + a2ExprFactor valE) * u₁ :=
      Nat.mul_le_mul_right u₁ (Nat.le_add_right _ _)
    have h2_u : a2ExprFactor valE * u₂ ≤ (a2ExprFactor idxE + a2ExprFactor valE) * u₂ :=
      Nat.mul_le_mul_right u₂ (Nat.le_add_left _ _)
    have hsum_u : 2 * a2ExprFactor idxE * u₁ + a2ExprFactor valE * u₂ + 80 ≤
        8 * F * (u₁ + u₂ + 1) := by
      rw [hF_def]
      set A := a2ExprFactor idxE + a2ExprFactor valE
      have hA : 128 ≤ A := by
        have := a2ExprFactor_ge_64 idxE; have := a2ExprFactor_ge_64 valE; omega
      have hAu1 : 0 ≤ A * u₁ := Nat.zero_le _
      have hAu2 : 0 ≤ A * u₂ := Nat.zero_le _
      nlinarith only [hA, h1_u, h2_u, hAu1, hAu2]
    linarith only [huc1, huc2, huc3, huc4, huE, hu2, hsum_u]
  · -- Bit cost bound: `≤ stSim.bitCost + 8 * F * K * Δb`
    set Δb := b₁ + b₂ + (natBitLength table + intBitLength idx) + intBitLength val
    have hF_def : F = 64 * (a2ExprFactor idxE + a2ExprFactor valE) := rfl
    have hA_ge : 128 ≤ a2ExprFactor idxE + a2ExprFactor valE := by
      have := a2ExprFactor_ge_64 idxE; have := a2ExprFactor_ge_64 valE; omega
    have hKp_ge : 8 ≤ K_p := by dsimp [K_p]; unfold a2ParamBits; omega
    have hSb_ge : 4 ≤ S_bits := by dsimp [S_bits]; omega
    have hK_ge : 12 ≤ K := by dsimp [K]; omega
    have hT_Kp : natBitLength T_max + 4 ≤ K_p := by dsimp [K_p]; unfold a2ParamBits; omega
    have he_K : intBitLength e ≤ intBitLength idx + K_p := by linarith
    have hidx_pos := intBitLength_pos idx
    have hval_pos := intBitLength_pos val
    have hΔ_pos : 2 ≤ Δb := by dsimp [Δb]; omega
    have hbE_K : bE ≤ a2ExprFactor idxE * K * b₁ + 6 * K * intBitLength idx := by
      have hKp_le : K_p ≤ K := by dsimp [K]; omega
      have m1 : a2ExprFactor idxE * K_p * b₁ ≤ a2ExprFactor idxE * K * b₁ :=
        Nat.mul_le_mul_right b₁ (Nat.mul_le_mul_left _ hKp_le)
      have m2 : 6 * K_p * intBitLength idx ≤ 6 * K * intBitLength idx :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 6 hKp_le)
      linarith
    have hb2_K : b'₂ ≤ a2ExprFactor valE * K * b₂ := by
      have hKp_le : K_p ≤ K := by dsimp [K]; omega
      exact hb2.trans (Nat.mul_le_mul_right b₂ (Nat.mul_le_mul_left _ hKp_le))
    -- Bound all non-expression overhead by `66 * K * Δb`
    have hov : (2 + bE + 6 + intBitLength e) + (3 + b'₂ + 7 + intBitLength val) +
        (8 + intBitLength e + 10 + intBitLength val + 4 + intBitLength e + intBitLength val) +
        (8 * intBitLength e + 24 * S_bits + 240) ≤
        bE + b'₂ + 66 * K * Δb := by
      have hSb_K : S_bits ≤ K := by dsimp [K]; omega
      have hKp_K : K_p ≤ K := by dsimp [K]; omega
      have h_idx_Δ : intBitLength idx ≤ Δb := by dsimp [Δb]; omega
      have h_val_Δ : intBitLength val ≤ Δb := by dsimp [Δb]; omega
      nlinarith only [hSb_K, hKp_K, h_idx_Δ, h_val_Δ, hK_ge, hΔ_pos, he_K]
    have htot_b : bE + b'₂ + 66 * K * Δb ≤ 8 * F * K * Δb := by
      rw [hF_def]
      set A := a2ExprFactor idxE + a2ExprFactor valE
      have m1 : a2ExprFactor idxE * K * b₁ ≤ A * K * b₁ :=
        Nat.mul_le_mul_right b₁ (Nat.mul_le_mul_right K (Nat.le_add_right _ _))
      have m2 : a2ExprFactor valE * K * b₂ ≤ A * K * b₂ :=
        Nat.mul_le_mul_right b₂ (Nat.mul_le_mul_right K (Nat.le_add_left _ _))
      have h_idx_Δ : intBitLength idx ≤ Δb := by dsimp [Δb]; omega
      have m3 : 6 * K * intBitLength idx ≤ 6 * K * Δb := Nat.mul_le_mul_left (6 * K) h_idx_Δ
      have m4 : A * K * b₁ + A * K * b₂ ≤ A * K * Δb := by
        have h12_le : b₁ + b₂ ≤ Δb := by dsimp [Δb]; omega
        calc A * K * b₁ + A * K * b₂ = A * K * (b₁ + b₂) := by ring
          _ ≤ A * K * Δb := Nat.mul_le_mul_left (A * K) h12_le
      have m5 : 70 * K * Δb ≤ A * K * Δb := by
        have : 70 ≤ A := by omega
        calc 70 * K * Δb = 70 * (K * Δb) := by ring
          _ ≤ A * (K * Δb) := Nat.mul_le_mul_right _ this
          _ = A * K * Δb := by ring
      have h2A : A * K * Δb + A * K * Δb ≤ 8 * (64 * A) * K * Δb := by
        have hpos : 0 ≤ A * K * Δb := Nat.zero_le _
        linarith only [hpos]
      linarith only [hbE_K, hb2_K, m1, m2, m3, m4, m5, h2A]
    change st4.bitCost ≤ st3.bitCost + 8 * intBitLength e + 24 * S_bits + 240 at hbc4
    rw [h12, hl1] at hbc1; rw [h12, hl2] at hbc2; rw [h10] at hbc3
    linarith only [hbc1, hbc2, hbc3, hbc4, hov, htot_b]

theorem exec_trA2RandBitHeap {d m B T_max S_max : ℕ}
    {wsBase wsSub wsSim : WordStore} {inpSub : BitRAMInput d}
    {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (inpSim : BitRAMInput d)
    (hstage : StagingA2Matches m B wsBase inpSub)
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    {table : ℕ} {idxE : IntExpr}
    (htm : maxTableStmt (.randBitHeap table idxE) ≤ T_max)
    {fdSub : ℕ} (bit : Bool) (bsRem : List Bool) (stSim : BitRAMExecState)
    (hwSim : stSim.words = wsSim) (hfd : stSim.frameDepth = 2 + fdSub)
    (hbits : stSim.remainingBits = bit :: bsRem)
    {subPeakCell subPeakBit : ℕ}
    (hcPeak : wsSub.cellCount ≤ subPeakCell)
    (hbPeak : wsSub.bitSize ≤ subPeakBit)
    (hSubCell : let (idx, _, _) := evalIntExpr inpSub fdSub wsSub idxE
                let val : ℤ := if bit then 1 else 0
                (wsSub.write (.heap table idx) val).cellCount ≤ S_max ∧
                (wsSub.write (.heap table idx) val).bitSize ≤ subPeakBit)
    (hpC : stSim.peakCellSpace ≤ a2CellBound wsBase inpSim S_max subPeakCell)
    (hpB : stSim.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit) :
    let (idx, u₁, b₁) := evalIntExpr inpSub fdSub wsSub idxE
    let val : ℤ := if bit then 1 else 0
    let Δu := u₁ + 1
    let Δb := b₁ + (natBitLength table + intBitLength idx) + 1
    let F := a2StmtFactor (.randBitHeap table idxE)
    let K := a2ParamBits m d T_max + (natBitLength S_max + 4)
    ∃ stEnd : BitRAMExecState, ∃ highSid' sidOfEnc' encOfSid' freeStack',
      RunsTo inpSim [.stmt (trA2Stmt T_max (.randBitHeap table idxE))] stSim stEnd ∧
      A2SimInv wsBase T_max S_max (wsSub.write (.heap table idx) val) stEnd.words
        highSid' sidOfEnc' encOfSid' freeStack' ∧
      stEnd.frameDepth = 2 + fdSub ∧
      stEnd.remainingBits = bsRem ∧
      stEnd.unitCost ≤ stSim.unitCost + 8 * F * Δu ∧
      stEnd.bitCost ≤ stSim.bitCost + 8 * F * K * Δb ∧
      stEnd.peakCellSpace ≤ a2CellBound wsBase inpSim S_max subPeakCell ∧
      stEnd.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit := by
  simp only [maxTableStmt, max_le_iff] at htm
  have ht : table < T_max := by omega
  rcases h1 : evalIntExpr inpSub fdSub wsSub idxE with ⟨idx, u₁, b₁⟩
  simp only [h1] at hSubCell ⊢
  rcases hSubCell with ⟨hSubC, hSubB⟩
  set val : ℤ := if bit then 1 else 0
  set e : ℤ := idx * (T_max : ℤ) + (table : ℤ)
  set S_bits := natBitLength S_max + 4
  set K_p := a2ParamBits m d T_max
  set K := K_p + S_bits
  set F := a2StmtFactor (.randBitHeap table idxE)
  obtain ⟨hHeadCell, hHeadBit⟩ := hinv.within_bounds inpSim hcPeak hbPeak
  change inpSim.inputBitSpace + wsSim.bitSize + 12 * subPeakBit + 16 * natBitLength T_max + 20 * S_bits + 200 ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit at hHeadBit
  have hmem_sub' : (.heap table idx : RAMCellLoc) ∈ (wsSub.write (.heap table idx) val).live := by
    simp [WordStore.write]
  have hidx_val_bl : natBitLength table + intBitLength idx + intBitLength val ≤ subPeakBit := by
    have hm := mem_live_bitLength_le hmem_sub'
    simp only [WordStore.write, Function.update_self, RAMCellLoc.bitLength] at hm
    exact hm.trans hSubB
  have he_bl := intBitLength_encA2_le ht idx
  have h10 : natBitLength 10 = 4 := by decide
  have h12 : natBitLength 12 = 4 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  -- 1. `.writeHeap 12 (.lit 1) encE`
  obtain ⟨uE, bE, hevE, huE, hbE⟩ :=
    eval_encA2Expr inpSim hstage hinv.hT (hinv.agreesForExpr fdSub) ht idxE htm.2
  simp only [h1] at hevE huE hbE
  have hc1 : inpSim.inputCellSpace + (wsSim.write (.heap 12 1) e).cellCount ≤
      a2CellBound wsBase inpSim S_max subPeakCell := by
    have := cellCount_write_le wsSim (.heap 12 1) e; linarith
  have hb1 : inpSim.inputBitSpace + (wsSim.write (.heap 12 1) e).bitSize ≤
      a2BitBound wsBase inpSim T_max S_max subPeakBit := by
    have h := bitSize_write_le wsSim (.heap 12 1) e
    dsimp [RAMCellLoc.bitLength] at h; rw [h12, hl1] at h; linarith
  obtain ⟨st1, hr1, hw1, hfd1, hrb1, huc1, hbc1, hpC1, hpB1⟩ :=
    exec_writeHeap_ceil inpSim 12 (.lit 1)
      (.add (.mul (trA2Expr T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ)))
      stSim hpC hpB (idx := 1) (val := e) (u₁ := 1) (b₁ := 2) (u₂ := uE) (b₂ := bE)
      (evalIntLe_lit _ _ _ _ (by decide)) (by unfold EvalIntLe; rw [hfd, hwSim, hevE]; exact ⟨rfl, le_rfl, le_rfl⟩) (by rw [hwSim]; exact hc1) (by rw [hwSim]; exact hb1)
  -- 2. `.randBitHeap 10 (.readHeap 12 (.lit 1))`
  have hr1_12_1 : st1.words.read (.heap 12 1) = e := by rw [hw1]; simp
  have hev_r1 : evalIntExpr inpSim st1.frameDepth st1.words (.readHeap 12 (.lit 1)) =
      (e, 2, 8 + intBitLength e) := by
    simp [evalIntExpr, hr1_12_1, h12, hl1]
  have hrb1_eq : st1.remainingBits = bit :: bsRem := hrb1.trans hbits
  have hrand := RunsTo.randBitHeap inpSim 10 (.readHeap 12 (.lit 1)) bit bsRem st1 hrb1_eq
  simp only [hev_r1, RAMCellLoc.bitLength, h10] at hrand
  set st2 : BitRAMExecState :=
    { st1 with
      words := st1.words.write (.heap 10 e) val
      remainingBits := bsRem
      unitCost := st1.unitCost + 2 + 1
      bitCost := st1.bitCost + (8 + intBitLength e) + (4 + intBitLength e) + 1
      peakCellSpace := max st1.peakCellSpace (inpSim.inputCellSpace + (st1.words.write (.heap 10 e) val).cellCount)
      peakBitSpace := max st1.peakBitSpace (inpSim.inputBitSpace + (st1.words.write (.heap 10 e) val).bitSize) }
  have hc2 : inpSim.inputCellSpace + (st1.words.write (.heap 10 e) val).cellCount ≤
      a2CellBound wsBase inpSim S_max subPeakCell := by
    have h_a := cellCount_write_le st1.words (.heap 10 e) val
    have h_b := cellCount_write_le wsSim (.heap 12 1) e
    rw [hw1, hwSim] at h_a ⊢; linarith only [h_a, h_b, hHeadCell]
  have hb2_sp : inpSim.inputBitSpace + (st1.words.write (.heap 10 e) val).bitSize ≤
      a2BitBound wsBase inpSim T_max S_max subPeakBit := by
    have h_a := bitSize_write_le st1.words (.heap 10 e) val
    have h_b := bitSize_write_le wsSim (.heap 12 1) e
    dsimp [RAMCellLoc.bitLength] at h_a h_b; rw [h10] at h_a; rw [h12, hl1] at h_b
    rw [hw1, hwSim] at h_a ⊢; linarith only [h_a, h_b, he_bl, hidx_val_bl, hHeadBit]
  have hpC2 : st2.peakCellSpace ≤ a2CellBound wsBase inpSim S_max subPeakCell := max_le hpC1 hc2
  have hpB2 : st2.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit := max_le hpB1 hb2_sp
  have hw2_shape : st2.words =
      let w1 := wsSim.write (.heap 12 1) e
      let w2 := if false then w1.write (.heap 12 2) val else w1
      w2.write (.heap 10 e) val := by
    dsimp [st2]; rw [hw1, hwSim]
  -- 3. `trA2LogInsertAfterWrite`
  obtain ⟨st3, highSid', sidOfEnc', encOfSid', freeStack', hr3, hinv3, hfd3, hrb3, huc3, hbc3, hpC3, hpB3⟩ :=
    exec_trA2LogInsertAfterWrite inpSim hinv ht idx val false hSubC hcPeak hbPeak hSubB st2 hw2_shape hpC2 hpB2
  have htot : RunsTo inpSim [.stmt (trA2Stmt T_max (.randBitHeap table idxE))] stSim st3 :=
    RunsTo.seq hr1 (RunsTo.seq hrand hr3)
  refine ⟨st3, highSid', sidOfEnc', encOfSid', freeStack', htot, hinv3,
    by rw [hfd3]; dsimp [st2]; rw [hfd1, hfd],
    hrb3,
    ?_, ?_, hpC3, hpB3⟩
  · have hF_def : F = 64 * a2ExprFactor idxE := rfl
    have hA_ge := a2ExprFactor_ge_64 idxE
    have huc2_eq : st2.unitCost = st1.unitCost + 3 := rfl
    nlinarith only [huc1, huc2_eq, huc3, huE, hF_def, hA_ge]
  · set Δb := b₁ + (natBitLength table + intBitLength idx) + 1
    have hF_def : F = 64 * a2ExprFactor idxE := rfl
    have hA_ge := a2ExprFactor_ge_64 idxE
    have hKp_ge : 8 ≤ K_p := by dsimp [K_p]; unfold a2ParamBits; omega
    have hSb_ge : 4 ≤ S_bits := by dsimp [S_bits]; omega
    have hT_Kp : natBitLength T_max + 4 ≤ K_p := by dsimp [K_p]; unfold a2ParamBits; omega
    have he_K : intBitLength e ≤ intBitLength idx + K_p := by linarith
    have hbE_K : bE ≤ a2ExprFactor idxE * K * b₁ + 6 * K * intBitLength idx := by
      have hKp_le : K_p ≤ K := by dsimp [K]; omega
      have m1 : a2ExprFactor idxE * K_p * b₁ ≤ a2ExprFactor idxE * K * b₁ :=
        Nat.mul_le_mul_right b₁ (Nat.mul_le_mul_left _ hKp_le)
      have m2 : 6 * K_p * intBitLength idx ≤ 6 * K * intBitLength idx :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 6 hKp_le)
      linarith
    have hbc2_eq : st2.bitCost = st1.bitCost + 2 * intBitLength e + 13 := by
      dsimp [st2]; omega
    rw [h12, hl1] at hbc1
    have hov : (2 + bE + 6 + intBitLength e) + (2 * intBitLength e + 13) +
        (8 * intBitLength e + 24 * S_bits + 240) ≤
        bE + 66 * K * Δb := by
      have hSb_K : S_bits ≤ K := by dsimp [K]; omega
      have hKp_K : K_p ≤ K := by dsimp [K]; omega
      have h_idx_Δ : intBitLength idx ≤ Δb := by dsimp [Δb]; omega
      have hΔ_pos : 2 ≤ Δb := by have := intBitLength_pos idx; dsimp [Δb]; omega
      have hK_ge : 12 ≤ K := by dsimp [K]; omega
      nlinarith only [hSb_K, hKp_K, h_idx_Δ, hK_ge, hΔ_pos, he_K]
    have htot_b : bE + 66 * K * Δb ≤ 8 * F * K * Δb := by
      rw [hF_def]
      set A := a2ExprFactor idxE
      have hb1_Δ : b₁ ≤ Δb := by dsimp [Δb]; omega
      have hidx_Δ : intBitLength idx ≤ Δb := by dsimp [Δb]; omega
      have m1 : A * K * b₁ ≤ A * K * Δb := Nat.mul_le_mul_left (A * K) hb1_Δ
      have m2 : 6 * K * intBitLength idx ≤ 6 * K * Δb := Nat.mul_le_mul_left (6 * K) hidx_Δ
      have m3 : 72 * K * Δb ≤ 7 * A * K * Δb := by
        have : 72 ≤ 7 * A := by omega
        calc 72 * K * Δb = 72 * (K * Δb) := by ring
          _ ≤ (7 * A) * (K * Δb) := Nat.mul_le_mul_right _ this
          _ = 7 * A * K * Δb := by ring
      have h8 : A * K * Δb + 7 * A * K * Δb ≤ 8 * (64 * A) * K * Δb := by
        have hp : 0 ≤ A * K * Δb := Nat.zero_le _
        linarith only [hp]
      linarith only [hbE_K, m1, m2, m3, h8]
    change st3.bitCost ≤ st2.bitCost + 8 * intBitLength e + 24 * S_bits + 240 at hbc3
    linarith only [hbc1, hbc2_eq, hbc3, hov, htot_b]

/-! ### 3. `exec_trA2FreeHeap` -/

theorem exec_trA2FreeHeap {d m B T_max S_max : ℕ}
    {wsBase wsSub wsSim : WordStore} {inpSub : BitRAMInput d}
    {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (inpSim : BitRAMInput d)
    (hstage : StagingA2Matches m B wsBase inpSub)
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    {table : ℕ} {idxE : IntExpr}
    (htm : maxTableStmt (.freeHeap table idxE) ≤ T_max)
    {fdSub : ℕ} (stSim : BitRAMExecState)
    (hwSim : stSim.words = wsSim) (hfd : stSim.frameDepth = 2 + fdSub)
    {subPeakCell subPeakBit : ℕ}
    (hcPeak : wsSub.cellCount ≤ subPeakCell)
    (hbPeak : wsSub.bitSize ≤ subPeakBit)
    (hpC : stSim.peakCellSpace ≤ a2CellBound wsBase inpSim S_max subPeakCell)
    (hpB : stSim.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit) :
    let (idx, u₁, b₁) := evalIntExpr inpSub fdSub wsSub idxE
    let Δu := u₁ + 1
    let Δb := b₁ + (natBitLength table + intBitLength idx)
    let F := a2StmtFactor (.freeHeap table idxE)
    let K := a2ParamBits m d T_max + (natBitLength S_max + 4)
    ∃ stEnd : BitRAMExecState, ∃ sidOfEnc' freeStack',
      RunsTo inpSim [.stmt (trA2Stmt T_max (.freeHeap table idxE))] stSim stEnd ∧
      A2SimInv wsBase T_max S_max (wsSub.free (.heap table idx)) stEnd.words
        highSid sidOfEnc' encOfSid freeStack' ∧
      stEnd.frameDepth = 2 + fdSub ∧
      stEnd.remainingBits = stSim.remainingBits ∧
      stEnd.unitCost ≤ stSim.unitCost + 8 * F * Δu ∧
      stEnd.bitCost ≤ stSim.bitCost + 8 * F * K * Δb ∧
      stEnd.peakCellSpace ≤ a2CellBound wsBase inpSim S_max subPeakCell ∧
      stEnd.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit := by
  simp only [maxTableStmt, max_le_iff] at htm
  have ht : table < T_max := by omega
  rcases h1 : evalIntExpr inpSub fdSub wsSub idxE with ⟨idx, u₁, b₁⟩
  dsimp only
  set e : ℤ := idx * (T_max : ℤ) + (table : ℤ)
  set S_bits := natBitLength S_max + 4
  set K_p := a2ParamBits m d T_max
  set K := K_p + S_bits
  set F := a2StmtFactor (.freeHeap table idxE)
  obtain ⟨hHeadCell, hHeadBit⟩ := hinv.within_bounds inpSim hcPeak hbPeak
  change inpSim.inputBitSpace + wsSim.bitSize + 12 * subPeakBit + 16 * natBitLength T_max + 20 * S_bits + 200 ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit at hHeadBit
  obtain ⟨uE, bE, hevE, huE, hbE⟩ :=
    eval_encA2Expr inpSim hstage hinv.hT (hinv.agreesForExpr fdSub) ht idxE htm.2
  simp only [h1] at hevE huE hbE
  have he_bl := intBitLength_encA2_le ht idx
  have hsid_bl : ∀ s : ℕ, s ≤ S_max → intBitLength (s : ℤ) ≤ S_bits := by
    intro s hs
    have h1_s := intBitLength_ofNat_le s
    have h2_s := natBitLength_mono hs
    dsimp [S_bits]; linarith
  have h10 : natBitLength 10 = 4 := by decide
  have h12 : natBitLength 12 = 4 := by decide
  have h13 : natBitLength 13 = 4 := by decide
  have h14 : natBitLength 14 = 4 := by decide
  have h15 : natBitLength 15 = 4 := by decide
  have h16 : natBitLength 16 = 5 := by decide
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  have hl3 : intBitLength (3 : ℤ) = 3 := by decide
  have hl4 : intBitLength (4 : ℤ) = 4 := by decide
  have hcond_eq : evalBitCond inpSim stSim.frameDepth stSim.words
      (.intLt (.lit 0) (.readHeap 13 (.add (.mul (trA2Expr T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ))))) =
      (decide ((0 : ℤ) < wsSim.read (.heap 13 e)), 1 + (uE + 1) + 1,
       1 + (bE + 4 + intBitLength e + intBitLength (wsSim.read (.heap 13 e))) + 1 +
         intBitLength (wsSim.read (.heap 13 e))) := by
    rw [hfd, hwSim]
    have hr13_ev : evalIntExpr inpSim (2 + fdSub) wsSim
        (.readHeap 13 (.add (.mul (trA2Expr T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ)))) =
        (wsSim.read (.heap 13 e), uE + 1, bE + 4 + intBitLength e + intBitLength (wsSim.read (.heap 13 e))) := by
      unfold evalIntExpr
      rw [hevE]
      dsimp only
      rw [h13]
    unfold evalBitCond
    rw [hr13_ev]
    simp only [evalIntExpr, hl0]
  cases hsid : sidOfEnc e with
  | none =>
      -- Inactive: `.readHeap 13 e = 0`, `.ite` takes `.skip`, and `wsSub.free (.heap table idx) = wsSub`!
      have hn13 : (.heap 13 e : RAMCellLoc) ∉ wsSim.live := (hinv.tab13_spec e).2 hsid
      have hr13_0 : wsSim.read (.heap 13 e) = 0 := by simp [WordStore.read, hn13]
      have hn10 : (.heap 10 e : RAMCellLoc) ∉ wsSim.live := by
        intro hm; have := (hinv.active_iff e).mp hm; simp [hsid] at this
      have hnSub : (.heap table idx : RAMCellLoc) ∉ wsSub.live := by
        intro hm; exact hn10 ((hinv.tab10_live e).mpr ⟨table, ht, idx, rfl, hm⟩)
      have hfree_sub : wsSub.free (.heap table idx) = wsSub :=
        wordStore_free_of_not_mem hinv.wfSub hnSub
      let stEnd : BitRAMExecState :=
        { stSim with
          unitCost := stSim.unitCost + (1 + (uE + 1) + 1) + 1
          bitCost := stSim.bitCost + (1 + (bE + 4 + intBitLength e + 1) + 1 + 1) + 1 }
      have hite : RunsTo inpSim [.stmt (trA2Stmt T_max (.freeHeap table idxE))] stSim stEnd := by
        apply RunsTo.ite
        rw [hcond_eq, hr13_0]
        simp only [lt_self_iff_false, decide_false, Bool.false_eq_true, ↓reduceIte, hl0]
        exact RunsTo.skip inpSim _
      refine ⟨stEnd, sidOfEnc, freeStack, hite, ?_, hfd, rfl, ?_, ?_, hpC, hpB⟩
      · dsimp [stEnd]; rw [hfree_sub, hwSim]; exact hinv
      · dsimp [stEnd]
        have hF_def : F = 64 * a2ExprFactor idxE := rfl
        have hA_ge := a2ExprFactor_ge_64 idxE
        nlinarith only [huE, hF_def, hA_ge]
      · dsimp [stEnd]
        set Δb := b₁ + (natBitLength table + intBitLength idx)
        have hF_def : F = 64 * a2ExprFactor idxE := rfl
        have hA_ge := a2ExprFactor_ge_64 idxE
        have hKp_ge : 8 ≤ K_p := by dsimp [K_p]; unfold a2ParamBits; omega
        have hT_Kp : natBitLength T_max + 4 ≤ K_p := by dsimp [K_p]; unfold a2ParamBits; omega
        have he_K : intBitLength e ≤ intBitLength idx + K_p := by linarith
        have hbE_K : bE ≤ a2ExprFactor idxE * K * b₁ + 6 * K * intBitLength idx := by
          have hKp_le : K_p ≤ K := by dsimp [K]; omega
          have m1 : a2ExprFactor idxE * K_p * b₁ ≤ a2ExprFactor idxE * K * b₁ :=
            Nat.mul_le_mul_right b₁ (Nat.mul_le_mul_left _ hKp_le)
          have m2 : 6 * K_p * intBitLength idx ≤ 6 * K * intBitLength idx :=
            Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 6 hKp_le)
          linarith
        have hidx_pos := intBitLength_pos idx
        have hb1_Δ : b₁ ≤ Δb := by dsimp [Δb]; omega
        have hidx_Δ : intBitLength idx ≤ Δb := by dsimp [Δb]; omega
        have hov : bE + intBitLength e + 10 ≤
            a2ExprFactor idxE * K * Δb + 16 * K * Δb := by
          have m1 : a2ExprFactor idxE * K * b₁ ≤ a2ExprFactor idxE * K * Δb :=
            Nat.mul_le_mul_left _ hb1_Δ
          have hKp_K : K_p ≤ K := by dsimp [K]; omega
          have hΔ_pos : 1 ≤ Δb := by dsimp [Δb]; omega
          nlinarith only [hbE_K, he_K, m1, hidx_Δ, hKp_K, hKp_ge, hΔ_pos]
        have htot_b : a2ExprFactor idxE * K * Δb + 16 * K * Δb ≤ 8 * F * K * Δb := by
          rw [hF_def]
          have h16 : 16 * (K * Δb) ≤ a2ExprFactor idxE * (K * Δb) :=
            Nat.mul_le_mul_right _ (by omega)
          nlinarith only [h16, hA_ge]
        linarith only [hov, htot_b]
  | some s =>
      -- Active: `.readHeap 13 e = s + 1 > 0`
      have h13_s := (hinv.tab13_spec e).1 s hsid
      have hr13_val : wsSim.read (.heap 13 e) = ((s + 1 : ℕ) : ℤ) := by
        rw [wordStore_read_eq_vals hinv.wfSim]; exact h13_s.2
      obtain ⟨hs_lt, hs_nf, henc_s⟩ := hinv.sid_lt e s hsid
      obtain ⟨hfree_le, _⟩ := hinv.highSid_sub_free_le
      have hhigh_S := hinv.high_le
      have hm10 : (.heap 10 e : RAMCellLoc) ∈ wsSim.live := by rw [hinv.active_iff, hsid]; rfl
      obtain ⟨t₀, ht₀, i₀, heq_enc, hmSub⟩ := (hinv.tab10_live e).mp hm10
      obtain ⟨ht0_eq, hi0_eq⟩ := encA2_inj ht₀ ht heq_enc.symm; subst t₀; subst i₀
      have hidx_sub : natBitLength table + intBitLength idx ≤ subPeakBit := by
        have hm := mem_live_bitLength_le hmSub
        dsimp [RAMCellLoc.bitLength] at hm
        have := intBitLength_pos (wsSub.vals (.heap table idx))
        linarith
      have he_sub : intBitLength e ≤ subPeakBit + natBitLength T_max + 4 := by linarith
      have hs_bl : intBitLength (s : ℤ) ≤ S_bits := hsid_bl s (by omega)
      have hs1_bl : intBitLength ((s + 1 : ℕ) : ℤ) ≤ S_bits := hsid_bl (s + 1) (by omega)
      have hfl_bl : intBitLength (freeStack.length : ℤ) ≤ S_bits := hsid_bl freeStack.length (by omega)
      have hfl1_le : freeStack.length + 1 ≤ highSid := by
        classical
        have hsub : insert s freeStack.toFinset ⊆ Finset.range highSid := by
          intro x hx
          rcases Finset.mem_insert.mp hx with rfl | hx'
          · exact Finset.mem_range.mpr hs_lt
          · exact Finset.mem_range.mpr (hinv.free_lt x (List.mem_toFinset.mp hx'))
        have hcard := Finset.card_le_card hsub
        rw [Finset.card_insert_of_notMem (by simpa using hs_nf),
            List.toFinset_card_of_nodup hinv.free_nodup, Finset.card_range] at hcard
        exact hcard
      have hfl1_bl : intBitLength ((freeStack.length + 1 : ℕ) : ℤ) ≤ S_bits :=
        hsid_bl (freeStack.length + 1) (hfl1_le.trans hhigh_S)
      have hn12_1 : (.heap 12 1 : RAMCellLoc) ∉ wsSim.live := hinv.tab12_other 1 (by decide) (by decide)
      have hn12_3 : (.heap 12 3 : RAMCellLoc) ∉ wsSim.live := hinv.tab12_other 3 (by decide) (by decide)
      let st0 : BitRAMExecState :=
        { stSim with
          unitCost := stSim.unitCost + (1 + (uE + 1) + 1)
          bitCost := stSim.bitCost +
            (1 + (bE + 4 + intBitLength e + intBitLength ((s + 1 : ℕ) : ℤ)) + 1 +
              intBitLength ((s + 1 : ℕ) : ℤ)) }
      set C_cell := a2CellBound wsBase inpSim S_max subPeakCell
      set C_bit := a2BitBound wsBase inpSim T_max S_max subPeakBit
      -- 1. `.writeHeap 12 (.lit 1) encE`
      have hc1 : inpSim.inputCellSpace + (wsSim.write (.heap 12 1) e).cellCount ≤ C_cell := by
        have := cellCount_write_le wsSim (.heap 12 1) e; linarith
      have hb1 : inpSim.inputBitSpace + (wsSim.write (.heap 12 1) e).bitSize ≤ C_bit := by
        have h := bitSize_write_le wsSim (.heap 12 1) e
        dsimp [RAMCellLoc.bitLength] at h; rw [h12, hl1] at h; linarith
      obtain ⟨st1, hr1, hw1, hfd1, hrb1, huc1, hbc1, hpC1, hpB1⟩ :=
        exec_writeHeap_ceil inpSim 12 (.lit 1)
          (.add (.mul (trA2Expr T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ)))
          st0 hpC hpB (idx := 1) (val := e) (u₁ := 1) (b₁ := 2) (u₂ := uE) (b₂ := bE)
          (evalIntLe_lit _ _ _ _ (by decide)) (by unfold EvalIntLe; dsimp [st0]; rw [hfd, hwSim, hevE]; exact ⟨rfl, le_rfl, le_rfl⟩)
          (by dsimp [st0]; rw [hwSim]; exact hc1) (by dsimp [st0]; rw [hwSim]; exact hb1)
      -- 2. `.writeHeap 12 (.lit 3) (.sub (.readHeap 13 (.readHeap 12 (.lit 1))) (.lit 1))`
      have hr1_12_1 : st1.words.read (.heap 12 1) = e := by rw [hw1]; simp
      have hr1_13_e : st1.words.read (.heap 13 e) = ((s + 1 : ℕ) : ℤ) := by
        rw [hw1, wordStore_read_write_ne _ (by simp)]; dsimp [st0]; rw [hwSim]; exact hr13_val
      have hs1_sub : ((s + 1 : ℕ) : ℤ) - 1 = (s : ℤ) := by push_cast; ring
      have hc2 : inpSim.inputCellSpace + (st1.words.write (.heap 12 3) (s : ℤ)).cellCount ≤ C_cell := by
        have h_a := cellCount_write_le st1.words (.heap 12 3) (s : ℤ)
        have h_b := cellCount_write_le wsSim (.heap 12 1) e
        rw [hw1] at h_a ⊢; dsimp [st0] at h_a ⊢; rw [hwSim] at h_a ⊢; linarith
      have hb2 : inpSim.inputBitSpace + (st1.words.write (.heap 12 3) (s : ℤ)).bitSize ≤ C_bit := by
        have h_a := bitSize_write_le st1.words (.heap 12 3) (s : ℤ)
        have h_b := bitSize_write_le wsSim (.heap 12 1) e
        dsimp [RAMCellLoc.bitLength] at h_a h_b; rw [h12, hl3] at h_a; rw [h12, hl1] at h_b
        rw [hw1] at h_a ⊢; dsimp [st0] at h_a ⊢; rw [hwSim] at h_a ⊢; linarith
      obtain ⟨st2, hr2, hw2, hfd2, hrb2, huc2, hbc2, hpC2, hpB2⟩ :=
        exec_writeHeap_ceil inpSim 12 (.lit 3)
          (.sub (.readHeap 13 (.readHeap 12 (.lit 1))) (.lit 1))
          st1 hpC1 hpB1 (idx := 3) (val := (s : ℤ)) (u₁ := 1) (b₁ := 3) (u₂ := 5)
          (b₂ := 16 + 2 * intBitLength e + 2 * intBitLength ((s + 1 : ℕ) : ℤ))
          (evalIntLe_lit _ _ _ _ (by decide))
          (evalIntLe_sub_read_read12_one inpSim st1.frameDepth st1.words 13 1 _ _ _ (b := 16 + 2 * intBitLength e + 2 * intBitLength ((s + 1 : ℕ) : ℤ)) hr1_12_1 hr1_13_e hs1_sub h13 hl1 (le_of_eq (by ring)))
          hc2 hb2
      -- 3..6: `.freeHeap 10`, `.freeHeap 13`, `.freeHeap 15`, `.freeHeap 16`
      have hr2_12_1 : st2.words.read (.heap 12 1) = e := by
        rw [hw2, wordStore_read_write_ne _ (by decide)]; exact hr1_12_1
      have hr2_12_3 : st2.words.read (.heap 12 3) = (s : ℤ) := by rw [hw2]; simp
      obtain ⟨st3, hr3, hw3, hfd3, hrb3, huc3, hbc3, hpC3, hpB3⟩ :=
        exec_freeHeap_ceil inpSim 10 (.readHeap 12 (.lit 1)) st2 hpC2 hpB2
          (idx := e) (u₁ := 2) (b₁ := 8 + intBitLength e)
          (evalIntLe_readHeap_lit inpSim st2.frameDepth st2.words 12 1 _ (b := 8 + intBitLength e) hr2_12_1 h12 hl1 (le_of_eq (by ring)))
      have hr3_12_1 : st3.words.read (.heap 12 1) = e := by
        rw [hw3, wordStore_read_free_ne _ (by simp)]; exact hr2_12_1
      have hr3_12_3 : st3.words.read (.heap 12 3) = (s : ℤ) := by
        rw [hw3, wordStore_read_free_ne _ (by simp)]; exact hr2_12_3
      obtain ⟨st4, hr4, hw4, hfd4, hrb4, huc4, hbc4, hpC4, hpB4⟩ :=
        exec_freeHeap_ceil inpSim 13 (.readHeap 12 (.lit 1)) st3 hpC3 hpB3
          (idx := e) (u₁ := 2) (b₁ := 8 + intBitLength e)
          (evalIntLe_readHeap_lit inpSim st3.frameDepth st3.words 12 1 _ (b := 8 + intBitLength e) hr3_12_1 h12 hl1 (le_of_eq (by ring)))
      have hr4_12_3 : st4.words.read (.heap 12 3) = (s : ℤ) := by
        rw [hw4, wordStore_read_free_ne _ (by simp)]; exact hr3_12_3
      obtain ⟨st5, hr5, hw5, hfd5, hrb5, huc5, hbc5, hpC5, hpB5⟩ :=
        exec_freeHeap_ceil inpSim 15 (.readHeap 12 (.lit 3)) st4 hpC4 hpB4
          (idx := (s : ℤ)) (u₁ := 2) (b₁ := 10 + intBitLength (s : ℤ))
          (evalIntLe_readHeap_lit inpSim st4.frameDepth st4.words 12 3 _ (b := 10 + intBitLength (s : ℤ)) hr4_12_3 h12 hl3 (le_of_eq (by ring)))
      have hr5_12_3 : st5.words.read (.heap 12 3) = (s : ℤ) := by
        rw [hw5, wordStore_read_free_ne _ (by simp)]; exact hr4_12_3
      obtain ⟨st6, hr6, hw6, hfd6, hrb6, huc6, hbc6, hpC6, hpB6⟩ :=
        exec_freeHeap_ceil inpSim 16 (.readHeap 12 (.lit 3)) st5 hpC5 hpB5
          (idx := (s : ℤ)) (u₁ := 2) (b₁ := 10 + intBitLength (s : ℤ))
          (evalIntLe_readHeap_lit inpSim st5.frameDepth st5.words 12 3 _ (b := 10 + intBitLength (s : ℤ)) hr5_12_3 h12 hl3 (le_of_eq (by ring)))
      -- Bound `st6.words` size before writing `.heap 14` and `.heap 12 4`
      have hc6_le : st6.words.cellCount ≤ wsSim.cellCount + 2 := by
        calc st6.words.cellCount
          _ ≤ st5.words.cellCount := by rw [hw6]; exact cellCount_free_le _ _
          _ ≤ st4.words.cellCount := by rw [hw5]; exact cellCount_free_le _ _
          _ ≤ st3.words.cellCount := by rw [hw4]; exact cellCount_free_le _ _
          _ ≤ st2.words.cellCount := by rw [hw3]; exact cellCount_free_le _ _
          _ ≤ st1.words.cellCount + 1 := by rw [hw2]; exact cellCount_write_le _ _ _
          _ ≤ wsSim.cellCount + 1 + 1 := by
              rw [hw1]; dsimp [st0]; rw [hwSim]
              exact Nat.add_le_add_right (cellCount_write_le _ _ _) 1
          _ = wsSim.cellCount + 2 := by ring
      have hb6_le : st6.words.bitSize ≤ wsSim.bitSize + subPeakBit + natBitLength T_max + S_bits + 20 := by
        have hstep12 : st2.words.bitSize ≤ wsSim.bitSize + (6 + intBitLength e) + (7 + intBitLength (s : ℤ)) := by
          have w2 := bitSize_write_le st1.words (.heap 12 3) (s : ℤ)
          have w1 := bitSize_write_le wsSim (.heap 12 1) e
          dsimp [RAMCellLoc.bitLength] at w1 w2; rw [h12, hl1] at w1; rw [h12, hl3] at w2
          rw [hw2]; rw [hw1] at w2 ⊢; dsimp [st0] at w2 ⊢; rw [hwSim] at w2 ⊢
          linarith only [w1, w2]
        have hstep26 : st6.words.bitSize ≤ st2.words.bitSize := by
          calc st6.words.bitSize
            _ ≤ st5.words.bitSize := by rw [hw6]; exact bitSize_free_le _ _
            _ ≤ st4.words.bitSize := by rw [hw5]; exact bitSize_free_le _ _
            _ ≤ st3.words.bitSize := by rw [hw4]; exact bitSize_free_le _ _
            _ ≤ st2.words.bitSize := by rw [hw3]; exact bitSize_free_le _ _
        linarith only [hstep26, hstep12, he_sub, hs_bl]
      -- 7. `.writeHeap 14 (.readHeap 12 (.lit 4)) (.readHeap 12 (.lit 3))`
      have hr6_12_3 : st6.words.read (.heap 12 3) = (s : ℤ) := by
        rw [hw6, wordStore_read_free_ne _ (by simp)]; exact hr5_12_3
      have hr6_12_4 : st6.words.read (.heap 12 4) = (freeStack.length : ℤ) := by
        rw [hw6, wordStore_read_free_ne _ (by simp),
            hw5, wordStore_read_free_ne _ (by simp),
            hw4, wordStore_read_free_ne _ (by simp),
            hw3, wordStore_read_free_ne _ (by simp),
            hw2, wordStore_read_write_ne _ (by decide),
            hw1, wordStore_read_write_ne _ (by decide)]
        dsimp [st0]; rw [hwSim]; exact hinv.tab12_4.2
      have hc7 : inpSim.inputCellSpace + (st6.words.write (.heap 14 (freeStack.length : ℤ)) (s : ℤ)).cellCount ≤ C_cell := by
        have := cellCount_write_le st6.words (.heap 14 (freeStack.length : ℤ)) (s : ℤ); linarith
      have hb7 : inpSim.inputBitSpace + (st6.words.write (.heap 14 (freeStack.length : ℤ)) (s : ℤ)).bitSize ≤ C_bit := by
        have h := bitSize_write_le st6.words (.heap 14 (freeStack.length : ℤ)) (s : ℤ)
        dsimp [RAMCellLoc.bitLength] at h; rw [h14] at h; linarith
      obtain ⟨st7, hr7, hw7, hfd7, hrb7, huc7, hbc7, hpC7, hpB7⟩ :=
        exec_writeHeap_ceil inpSim 14 (.readHeap 12 (.lit 4)) (.readHeap 12 (.lit 3))
          st6 hpC6 hpB6 (idx := (freeStack.length : ℤ)) (val := (s : ℤ))
          (u₁ := 2) (b₁ := 12 + intBitLength (freeStack.length : ℤ))
          (u₂ := 2) (b₂ := 10 + intBitLength (s : ℤ))
          (evalIntLe_readHeap_lit inpSim st6.frameDepth st6.words 12 4 _ (b := 12 + intBitLength (freeStack.length : ℤ)) hr6_12_4 h12 hl4 (le_of_eq (by ring)))
          (evalIntLe_readHeap_lit inpSim st6.frameDepth st6.words 12 3 _ (b := 10 + intBitLength (s : ℤ)) hr6_12_3 h12 hl3 (le_of_eq (by ring)))
          hc7 hb7
      -- 8. `.writeHeap 12 (.lit 4) (.add (.readHeap 12 (.lit 4)) (.lit 1))`
      have hr7_12_4 : st7.words.read (.heap 12 4) = (freeStack.length : ℤ) := by
        rw [hw7, wordStore_read_write_ne _ (by simp)]; exact hr6_12_4
      have hc8 : inpSim.inputCellSpace + (st7.words.write (.heap 12 4) ((freeStack.length + 1 : ℕ) : ℤ)).cellCount ≤ C_cell := by
        have w8 := cellCount_write_le st7.words (.heap 12 4) ((freeStack.length + 1 : ℕ) : ℤ)
        have w7 := cellCount_write_le st6.words (.heap 14 (freeStack.length : ℤ)) (s : ℤ)
        rw [← hw7] at w7; linarith
      have hb8 : inpSim.inputBitSpace + (st7.words.write (.heap 12 4) ((freeStack.length + 1 : ℕ) : ℤ)).bitSize ≤ C_bit := by
        have w8 := bitSize_write_le st7.words (.heap 12 4) ((freeStack.length + 1 : ℕ) : ℤ)
        have w7 := bitSize_write_le st6.words (.heap 14 (freeStack.length : ℤ)) (s : ℤ)
        dsimp [RAMCellLoc.bitLength] at w8 w7; rw [h12, hl4] at w8; rw [h14] at w7
        rw [← hw7] at w7; linarith
      obtain ⟨st8, hr8, hw8, hfd8, hrb8, huc8, hbc8, hpC8, hpB8⟩ :=
        exec_writeHeap_ceil inpSim 12 (.lit 4) (.add (.readHeap 12 (.lit 4)) (.lit 1))
          st7 hpC7 hpB7 (idx := 4) (val := ((freeStack.length + 1 : ℕ) : ℤ))
          (u₁ := 1) (b₁ := 4) (u₂ := 4)
          (b₂ := 16 + 2 * intBitLength (freeStack.length : ℤ))
          (evalIntLe_lit _ _ _ _ (by decide))
          (evalIntLe_add_read12_one inpSim st7.frameDepth st7.words 4 freeStack.length (b := 16 + 2 * intBitLength (freeStack.length : ℤ)) hr7_12_4 hl4 (le_of_eq (by ring)))
          hc8 hb8
      -- 9 & 10: `.freeHeap 12 (.lit 1)`, `.freeHeap 12 (.lit 3)`
      obtain ⟨st9, hr9, hw9, hfd9, hrb9, huc9, hbc9, hpC9, hpB9⟩ :=
        exec_freeHeap_ceil inpSim 12 (.lit 1) st8 hpC8 hpB8 (idx := 1) (u₁ := 1) (b₁ := 2) (evalIntLe_lit _ _ _ _ (by decide))
      obtain ⟨st10, hr10, hw10, hfd10, hrb10, huc10, hbc10, hpC10, hpB10⟩ :=
        exec_freeHeap_ceil inpSim 12 (.lit 3) st9 hpC9 hpB9 (idx := 3) (u₁ := 1) (b₁ := 3) (evalIntLe_lit _ _ _ _ (by decide))
      have htot : RunsTo inpSim [.stmt (trA2Stmt T_max (.freeHeap table idxE))] stSim st10 := by
        apply RunsTo.ite
        rw [hcond_eq, hr13_val]
        have hpos_s1 : (0 : ℤ) < ((s + 1 : ℕ) : ℤ) := by omega
        simp only [decide_eq_true hpos_s1, ↓reduceIte]
        exact RunsTo.seq hr1 (RunsTo.seq hr2 (RunsTo.seq hr3 (RunsTo.seq hr4
          (RunsTo.seq hr5 (RunsTo.seq hr6 (RunsTo.seq hr7 (RunsTo.seq hr8
            (RunsTo.seq hr9 hr10))))))))
      -- Cancel scratch `.heap 12 1` and `.heap 12 3` from `st10.words`!
      set wsFin := (((((wsSim.free (.heap 10 e)).free (.heap 13 e)).free (.heap 15 (s : ℤ))).free (.heap 16 (s : ℤ))).write
        (.heap 14 (freeStack.length : ℤ)) (s : ℤ)).write (.heap 12 4) ((freeStack.length + 1 : ℕ) : ℤ)
      have hwfFin : WellFormedWS wsFin :=
        wellFormedWS_write (wellFormedWS_write
          (wellFormedWS_free (wellFormedWS_free (wellFormedWS_free (wellFormedWS_free hinv.wfSim _) _) _) _) _ _) _ _
      have hw10_eq : st10.words = wsFin := by
        rw [hw10, hw9, hw8, hw7, hw6, hw5, hw4, hw3, hw2, hw1]
        dsimp only [st0, wsFin]; rw [hwSim]
        have hwf_lhs : WellFormedWS ((((((((((wsSim.write (.heap 12 1) e).write (.heap 12 3) (s : ℤ)).free
            (.heap 10 e)).free (.heap 13 e)).free (.heap 15 (s : ℤ))).free (.heap 16 (s : ℤ))).write
            (.heap 14 (freeStack.length : ℤ)) (s : ℤ)).write (.heap 12 4)
            ((freeStack.length + 1 : ℕ) : ℤ)).free (.heap 12 1)).free (.heap 12 3)) := by
          repeat first | apply wellFormedWS_free | apply wellFormedWS_write
          exact hinv.wfSim
        have hlive_eq : ∀ loc : RAMCellLoc,
            loc ∈ ((((((((((wsSim.write (.heap 12 1) e).write (.heap 12 3) (s : ℤ)).free
              (.heap 10 e)).free (.heap 13 e)).free (.heap 15 (s : ℤ))).free (.heap 16 (s : ℤ))).write
              (.heap 14 (freeStack.length : ℤ)) (s : ℤ)).write (.heap 12 4)
              ((freeStack.length + 1 : ℕ) : ℤ)).free (.heap 12 1)).free (.heap 12 3)).live ↔
            loc ∈ ((((((wsSim.free (.heap 10 e)).free (.heap 13 e)).free (.heap 15 (s : ℤ))).free
              (.heap 16 (s : ℤ))).write (.heap 14 (freeStack.length : ℤ)) (s : ℤ)).write
              (.heap 12 4) ((freeStack.length + 1 : ℕ) : ℤ)).live := by
          intro loc
          by_cases h1 : loc = .heap 12 1
          · subst h1; simp [WordStore.write, WordStore.free, hn12_1]
          · by_cases h3 : loc = .heap 12 3
            · subst h3; simp [WordStore.write, WordStore.free, hn12_3]
            · simp [WordStore.write, WordStore.free, h1, h3]
        have hvals_eq : ∀ loc : RAMCellLoc,
            ((((((((((wsSim.write (.heap 12 1) e).write (.heap 12 3) (s : ℤ)).free
              (.heap 10 e)).free (.heap 13 e)).free (.heap 15 (s : ℤ))).free (.heap 16 (s : ℤ))).write
              (.heap 14 (freeStack.length : ℤ)) (s : ℤ)).write (.heap 12 4)
              ((freeStack.length + 1 : ℕ) : ℤ)).free (.heap 12 1)).free (.heap 12 3)).vals loc =
            ((((((wsSim.free (.heap 10 e)).free (.heap 13 e)).free (.heap 15 (s : ℤ))).free
              (.heap 16 (s : ℤ))).write (.heap 14 (freeStack.length : ℤ)) (s : ℤ)).write
              (.heap 12 4) ((freeStack.length + 1 : ℕ) : ℤ)).vals loc := by
          intro loc
          simp only [WordStore.write, WordStore.free]
          by_cases h3 : loc = .heap 12 3
          · subst h3
            rw [Function.update_self]
            repeat rw [Function.update_of_ne (by simp)]
            exact (hinv.wfSim _ hn12_3).symm
          · rw [Function.update_of_ne h3]
            by_cases h1 : loc = .heap 12 1
            · subst h1
              rw [Function.update_self]
              repeat rw [Function.update_of_ne (by simp)]
              exact (hinv.wfSim _ hn12_1).symm
            · rw [Function.update_of_ne h1]
              by_cases ha : loc = .heap 12 4
              · subst ha; rw [Function.update_self, Function.update_self]
              · rw [Function.update_of_ne ha, Function.update_of_ne ha]
                by_cases hb : loc = .heap 14 (freeStack.length : ℤ)
                · subst hb; rw [Function.update_self, Function.update_self]
                · rw [Function.update_of_ne hb, Function.update_of_ne hb]
                  by_cases hc : loc = .heap 16 (s : ℤ)
                  · subst hc; rw [Function.update_self, Function.update_self]
                  · rw [Function.update_of_ne hc, Function.update_of_ne hc]
                    by_cases hd : loc = .heap 15 (s : ℤ)
                    · subst hd; rw [Function.update_self, Function.update_self]
                    · rw [Function.update_of_ne hd, Function.update_of_ne hd]
                      by_cases he' : loc = .heap 13 e
                      · subst he'; rw [Function.update_self, Function.update_self]
                      · rw [Function.update_of_ne he', Function.update_of_ne he']
                        by_cases hf : loc = .heap 10 e
                        · subst hf; rw [Function.update_self, Function.update_self]
                        · rw [Function.update_of_ne hf, Function.update_of_ne hf,
                              Function.update_of_ne h3, Function.update_of_ne h1]
        cases hL : ((((((((((wsSim.write (.heap 12 1) e).write (.heap 12 3) (s : ℤ)).free
            (.heap 10 e)).free (.heap 13 e)).free (.heap 15 (s : ℤ))).free (.heap 16 (s : ℤ))).write
            (.heap 14 (freeStack.length : ℤ)) (s : ℤ)).write (.heap 12 4)
            ((freeStack.length + 1 : ℕ) : ℤ)).free (.heap 12 1)).free (.heap 12 3)) with
        | mk lv1 vl1 =>
          cases hR : ((((((wsSim.free (.heap 10 e)).free (.heap 13 e)).free (.heap 15 (s : ℤ))).free
              (.heap 16 (s : ℤ))).write (.heap 14 (freeStack.length : ℤ)) (s : ℤ)).write
              (.heap 12 4) ((freeStack.length + 1 : ℕ) : ℤ)) with
          | mk lv2 vl2 =>
            congr 1
            · ext x; have hx := hlive_eq x; rw [hL, hR] at hx; exact hx
            · funext x; have hx := hvals_eq x; rw [hL, hR] at hx; exact hx
      -- Establish `A2SimInv` for `wsFin`!
      set sidOfEnc' := Function.update sidOfEnc e none
      set freeStack' := freeStack ++ [s]
      have hinvFin : A2SimInv wsBase T_max S_max (wsSub.free (.heap table idx)) wsFin
          highSid sidOfEnc' encOfSid freeStack' := by
        have hnd' : freeStack'.Nodup := by
          dsimp [freeStack']; rw [List.nodup_append]
          exact ⟨hinv.free_nodup, List.nodup_singleton s, fun x hx y hy hxy => by
            simp at hy; subst hy; subst hxy; exact hs_nf hx⟩
        refine
          { wfBase := hinv.wfBase
            wfSub := wellFormedWS_free hinv.wfSub _
            wfSim := hwfFin
            hT := hinv.hT
            high_le := hinv.high_le
            sub_tables := fun t' i' hm => by
              simp only [WordStore.free, Finset.mem_erase] at hm
              exact hinv.sub_tables t' i' hm.2
            base_live := fun loc hb => by
              have hne12 : loc ≠ .heap 12 4 := by intro h; subst h; simp [IsA2BaseLoc] at hb
              have hne14 : loc ≠ .heap 14 (freeStack.length : ℤ) := by intro h; subst h; simp [IsA2BaseLoc] at hb
              have hne16 : loc ≠ .heap 16 (s : ℤ) := by intro h; subst h; simp [IsA2BaseLoc] at hb
              have hne15 : loc ≠ .heap 15 (s : ℤ) := by intro h; subst h; simp [IsA2BaseLoc] at hb
              have hne13 : loc ≠ .heap 13 e := by intro h; subst h; simp [IsA2BaseLoc] at hb
              have hne10 : loc ≠ .heap 10 e := by intro h; subst h; simp [IsA2BaseLoc] at hb
              simp [wsFin, WordStore.write, WordStore.free, hne12, hne14, hne16, hne15, hne13, hne10, hinv.base_live loc hb]
            base_vals := fun loc hb => by
              have hne12 : loc ≠ .heap 12 4 := by intro h; subst h; simp [IsA2BaseLoc] at hb
              have hne14 : loc ≠ .heap 14 (freeStack.length : ℤ) := by intro h; subst h; simp [IsA2BaseLoc] at hb
              have hne16 : loc ≠ .heap 16 (s : ℤ) := by intro h; subst h; simp [IsA2BaseLoc] at hb
              have hne15 : loc ≠ .heap 15 (s : ℤ) := by intro h; subst h; simp [IsA2BaseLoc] at hb
              have hne13 : loc ≠ .heap 13 e := by intro h; subst h; simp [IsA2BaseLoc] at hb
              have hne10 : loc ≠ .heap 10 e := by intro h; subst h; simp [IsA2BaseLoc] at hb
              simp [wsFin, WordStore.write, WordStore.free,
                Function.update_of_ne hne12, Function.update_of_ne hne14,
                Function.update_of_ne hne16, Function.update_of_ne hne15,
                Function.update_of_ne hne13, Function.update_of_ne hne10, hinv.base_vals loc hb]
            local_live := fun d' v' i' => by
              simp [wsFin, WordStore.write, WordStore.free, hinv.local_live d' v' i']
            local_vals := fun d' v' i' => by
              simp [wsFin, WordStore.write, WordStore.free, hinv.local_vals d' v' i']
            tab10_live := fun e' => by
              simp only [wsFin, WordStore.write, WordStore.free, Finset.mem_insert,
                Finset.mem_erase, ne_eq, RAMCellLoc.heap.injEq, Nat.reduceEqDiff, false_and, false_or,
                not_false_eq_true, true_and]
              constructor
              · rintro ⟨hne_e, hm10'⟩
                obtain ⟨t', ht', i', rfl, hm_sub⟩ := (hinv.tab10_live e').mp hm10'
                have hne_sub : ¬ (t' = table ∧ i' = idx) := by
                  rintro ⟨rfl, rfl⟩; exact hne_e rfl
                exact ⟨t', ht', i', rfl, hne_sub, hm_sub⟩
              · rintro ⟨t', ht', i', rfl, hne_sub, hm_sub⟩
                have hne_e : i' * (T_max : ℤ) + (t' : ℤ) ≠ e := fun hh =>
                  hne_sub (encA2_inj ht' ht hh)
                exact ⟨hne_e, (hinv.tab10_live _).mpr ⟨t', ht', i', rfl, hm_sub⟩⟩
            tab10_read := fun t' ht' i' => by
              rw [wordStore_read_write_ne _ (by simp), wordStore_read_write_ne _ (by simp),
                  wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp),
                  wordStore_read_free_ne _ (by simp)]
              by_cases heq : t' = table ∧ i' = idx
              · rcases heq with ⟨rfl, rfl⟩; simp [e]
              · have hne_e : i' * (T_max : ℤ) + (t' : ℤ) ≠ e := fun hh =>
                  heq (encA2_inj ht' ht hh)
                rw [wordStore_read_free_ne _ (by simp [hne_e]),
                    wordStore_read_free_ne _ (by simp [heq])]
                exact hinv.tab10_read t' ht' i'
            free_nodup := hnd'
            free_lt := fun s' hs' => by
              dsimp [freeStack'] at hs'; rw [List.mem_append, List.mem_singleton] at hs'
              rcases hs' with hs_old | rfl
              · exact hinv.free_lt s' hs_old
              · exact hs_lt
            active_iff := fun e' => by
              simp [wsFin, WordStore.write, WordStore.free, sidOfEnc']
              by_cases heq : e' = e
              · subst heq; simp
              · simp [heq, hinv.active_iff e']
            sid_lt := fun e' s' hs' => by
              simp only [sidOfEnc'] at hs'
              by_cases heq : e' = e
              · subst heq; simp at hs'
              · rw [Function.update_of_ne heq] at hs'
                obtain ⟨h1_s, h2_s, h3_s⟩ := hinv.sid_lt e' s' hs'
                have hne_ss : s' ≠ s := by
                  intro hss; subst hss; exact heq (h3_s.symm.trans henc_s)
                exact ⟨h1_s, by simp [freeStack', h2_s, hne_ss], h3_s⟩
            enc_sid := fun s' hs1' hs2' => by
              dsimp [freeStack'] at hs2'
              rw [List.mem_append, List.mem_singleton, not_or] at hs2'
              have h0 := hinv.enc_sid s' hs1' hs2'.1
              have hne_e : encOfSid s' ≠ e := by
                intro hh; rw [hh, hsid] at h0; injection h0 with hss; exact hs2'.2 hss.symm
              simp [sidOfEnc', Function.update_of_ne hne_e, h0]
            tab12_4 := ⟨by simp [freeStack'], by simp [wsFin, freeStack']⟩
            tab12_5 := ⟨fun hh => by simp [wsFin, WordStore.write, WordStore.free, hinv.tab12_5.1 hh],
              by rw [wordStore_read_write_ne _ (by decide), wordStore_read_write_ne _ (by simp),
                     wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp),
                     wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp)]
                 exact hinv.tab12_5.2⟩
            tab12_other := fun i h4 h5 => by
              simp [wsFin, WordStore.write, WordStore.free, h4, hinv.tab12_other i h4 h5]
            tab13_spec := fun e' => by
              by_cases heq : e' = e
              · subst heq
                exact ⟨fun _ hs' => by simp [sidOfEnc'] at hs',
                       fun _ => by simp [wsFin, WordStore.write, WordStore.free]⟩
              · simp only [sidOfEnc', Function.update_of_ne heq]
                exact ⟨fun s' hs' =>
                  let h0 := (hinv.tab13_spec e').1 s' hs'
                  ⟨by simp [wsFin, WordStore.write, WordStore.free, heq, h0.1],
                   by rw [← wordStore_read_eq_vals hwfFin, wordStore_read_write_ne _ (by simp), wordStore_read_write_ne _ (by simp), wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp [heq]), wordStore_read_free_ne _ (by simp), wordStore_read_eq_vals hinv.wfSim]; exact h0.2⟩,
                 fun hn => by simp [wsFin, WordStore.write, WordStore.free, heq, (hinv.tab13_spec e').2 hn]⟩
            tab14_spec := fun z => by
              have hlen' : freeStack'.length = freeStack.length + 1 := by simp [freeStack']
              by_cases heq_z : z = (freeStack.length : ℤ)
              · subst heq_z
                have hz_ok : 0 ≤ (freeStack.length : ℤ) ∧ (freeStack.length : ℤ).toNat < freeStack'.length := by
                  simp [hlen']
                refine ⟨fun _ _ => ?_, fun hn => False.elim (hn hz_ok)⟩
                simp [wsFin, WordStore.write, freeStack']
              · refine ⟨fun hz0 hlt' => ?_, fun hn => ?_⟩
                · rw [hlen'] at hlt'
                  have hne_nat : z.toNat ≠ freeStack.length := fun hh => heq_z (by omega)
                  have hlt_old : z.toNat < freeStack.length := by omega
                  have h0 := (hinv.tab14_spec z).1 hz0 hlt_old
                  have hget : freeStack'[z.toNat] = freeStack[z.toNat] :=
                    List.getElem_append_left hlt_old
                  rw [hget]
                  exact ⟨by simp [wsFin, WordStore.write, WordStore.free, heq_z, h0.1],
                         by rw [← wordStore_read_eq_vals hwfFin, wordStore_read_write_ne _ (by simp), wordStore_read_write_ne _ (by simp [heq_z]), wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp), wordStore_read_eq_vals hinv.wfSim]; exact h0.2⟩
                · have hn_old : ¬ (0 ≤ z ∧ z.toNat < freeStack.length) := by
                    rintro ⟨hz0, hlt_old⟩; apply hn; rw [hlen']; exact ⟨hz0, by omega⟩
                  have h0 := (hinv.tab14_spec z).2 hn_old
                  simp [wsFin, WordStore.write, WordStore.free, heq_z, h0]
            tab15_16_spec := fun z => by
              by_cases heq_z : z = (s : ℤ)
              · subst heq_z
                have hnot : ¬ (0 ≤ (s : ℤ) ∧ (s : ℤ).toNat < highSid ∧ (s : ℤ).toNat ∉ freeStack') := by
                  simp [freeStack']
                exact ⟨fun h => False.elim (hnot h),
                       fun _ => ⟨by simp [wsFin, WordStore.write, WordStore.free],
                                 by simp [wsFin, WordStore.write, WordStore.free]⟩⟩
              · refine ⟨fun h => ?_, fun hn => ?_⟩
                · rcases h with ⟨hz0, hlt, hnf'⟩
                  dsimp [freeStack'] at hnf'
                  rw [List.mem_append, List.mem_singleton, not_or] at hnf'
                  have h0 := (hinv.tab15_16_spec z).1 ⟨hz0, hlt, hnf'.1⟩
                  exact ⟨by simp [wsFin, WordStore.write, WordStore.free, heq_z, h0.1],
                         by rw [← wordStore_read_eq_vals hwfFin, wordStore_read_write_ne _ (by simp), wordStore_read_write_ne _ (by simp), wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp [heq_z]), wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp), wordStore_read_eq_vals hinv.wfSim]; exact h0.2.1,
                         by simp [wsFin, WordStore.write, WordStore.free, heq_z, h0.2.2.1],
                         by rw [← wordStore_read_eq_vals hwfFin, wordStore_read_write_ne _ (by simp), wordStore_read_write_ne _ (by simp), wordStore_read_free_ne _ (by simp [heq_z]), wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp), wordStore_read_eq_vals hinv.wfSim]; exact h0.2.2.2⟩
                · have hn_old : ¬ (0 ≤ z ∧ z.toNat < highSid ∧ z.toNat ∉ freeStack) := by
                    rintro ⟨hz0, hlt, hnf⟩; apply hn
                    have hne_s : z.toNat ≠ s := fun hh => heq_z (by omega)
                    exact ⟨hz0, hlt, by simp [freeStack', hnf, hne_s]⟩
                  have h0 := (hinv.tab15_16_spec z).2 hn_old
                  exact ⟨by simp [wsFin, WordStore.write, WordStore.free, heq_z, h0.1],
                         by simp [wsFin, WordStore.write, WordStore.free, heq_z, h0.2]⟩
            live_cases := fun loc hm => by
              simp only [wsFin, WordStore.write, WordStore.free, Finset.mem_insert, Finset.mem_erase] at hm
              rcases hm with rfl | rfl | ⟨_, _, _, _, hmSim⟩
              · exact Or.inr (Or.inr ⟨12, 4, Or.inr (Or.inl rfl), rfl⟩)
              · exact Or.inr (Or.inr ⟨14, (freeStack.length : ℤ), Or.inr (Or.inr (Or.inr (Or.inl rfl))), rfl⟩)
              · exact hinv.live_cases loc hmSim }
      rw [← hw10_eq] at hinvFin
      refine ⟨st10, sidOfEnc', freeStack', htot, hinvFin,
        by rw [hfd10, hfd9, hfd8, hfd7, hfd6, hfd5, hfd4, hfd3, hfd2, hfd1]; exact hfd,
        by rw [hrb10, hrb9, hrb8, hrb7, hrb6, hrb5, hrb4, hrb3, hrb2, hrb1],
        ?_, ?_, hpC10, hpB10⟩
      · have h0_uc : st0.unitCost = stSim.unitCost + uE + 3 := by dsimp [st0]; omega
        have hF_def : F = 64 * a2ExprFactor idxE := rfl
        have hA_ge := a2ExprFactor_ge_64 idxE
        nlinarith only [h0_uc, huc1, huc2, huc3, huc4, huc5, huc6, huc7, huc8, huc9, huc10, huE, hF_def, hA_ge]
      · set Δb := b₁ + (natBitLength table + intBitLength idx)
        have hF_def : F = 64 * a2ExprFactor idxE := rfl
        have hA_ge := a2ExprFactor_ge_64 idxE
        have hKp_ge : 8 ≤ K_p := by dsimp [K_p]; unfold a2ParamBits; omega
        have hSb_ge : 4 ≤ S_bits := by dsimp [S_bits]; omega
        have hT_Kp : natBitLength T_max + 4 ≤ K_p := by dsimp [K_p]; unfold a2ParamBits; omega
        have he_K : intBitLength e ≤ intBitLength idx + K_p := by linarith
        have hbE_K : bE ≤ a2ExprFactor idxE * K * b₁ + 6 * K * intBitLength idx := by
          have hKp_le : K_p ≤ K := by dsimp [K]; omega
          have m1 : a2ExprFactor idxE * K_p * b₁ ≤ a2ExprFactor idxE * K * b₁ :=
            Nat.mul_le_mul_right b₁ (Nat.mul_le_mul_left _ hKp_le)
          have m2 : 6 * K_p * intBitLength idx ≤ 6 * K * intBitLength idx :=
            Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 6 hKp_le)
          linarith
        have h0_bc : st0.bitCost ≤ stSim.bitCost + bE + intBitLength e + 2 * S_bits + 8 := by
          dsimp [st0]; linarith
        rw [h12, hl1] at hbc1; rw [h12, hl3] at hbc2; rw [h10] at hbc3; rw [h13] at hbc4
        rw [h15] at hbc5; rw [h16] at hbc6; rw [h14] at hbc7; rw [h12, hl4] at hbc8
        rw [h12, hl1] at hbc9; rw [h12, hl3] at hbc10
        have hov : st10.bitCost ≤ stSim.bitCost + 2 * bE + 8 * intBitLength e + 20 * S_bits + 200 := by
          linarith only [h0_bc, hbc1, hbc2, hbc3, hbc4, hbc5, hbc6, hbc7, hbc8, hbc9, hbc10, hs_bl, hs1_bl, hfl_bl, hfl1_bl, hSb_ge]
        have htot_b : 2 * bE + 8 * intBitLength e + 20 * S_bits + 200 ≤ 8 * F * K * Δb := by
          set A := a2ExprFactor idxE
          change 2 * bE + 8 * intBitLength e + 20 * S_bits + 200 ≤ 8 * (64 * A) * K * Δb
          have hb1_Δ : b₁ ≤ Δb := by dsimp [Δb]; omega
          have hidx_Δ : intBitLength idx ≤ Δb := by dsimp [Δb]; omega
          have hΔ_pos : 2 ≤ Δb := by
            have := intBitLength_pos idx; have := natBitLength_pos table; dsimp [Δb]; omega
          have hSb_K : S_bits ≤ K := by dsimp [K]; omega
          have hKp_K : K_p ≤ K := by dsimp [K]; omega
          have hK_ge : 12 ≤ K := by dsimp [K]; omega
          have hov2 : 8 * intBitLength e + 20 * S_bits + 200 ≤ 64 * K * Δb := by
            nlinarith only [he_K, hidx_Δ, hΔ_pos, hSb_K, hKp_K, hK_ge]
          have m1 : A * K * b₁ ≤ A * K * Δb := Nat.mul_le_mul_left (A * K) hb1_Δ
          have m2 : 6 * K * intBitLength idx ≤ 6 * K * Δb := Nat.mul_le_mul_left (6 * K) hidx_Δ
          have m3 : 96 * K * Δb ≤ 4 * A * K * Δb := by
            have : 96 ≤ 4 * A := by omega
            calc 96 * K * Δb = 96 * (K * Δb) := by ring
              _ ≤ (4 * A) * (K * Δb) := Nat.mul_le_mul_right _ this
              _ = 4 * A * K * Δb := by ring
          have m4 : 2 * A * K * Δb + 4 * A * K * Δb ≤ 8 * (64 * A) * K * Δb := by
            have hp : 0 ≤ A * K * Δb := Nat.zero_le _
            linarith only [hp]
          linarith only [hbE_K, hov2, m1, m2, m3, m4]
        linarith only [hov, htot_b]

end UL.C12LVE
