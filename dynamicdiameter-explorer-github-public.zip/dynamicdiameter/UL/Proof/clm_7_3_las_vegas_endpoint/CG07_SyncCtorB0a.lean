import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorA
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b3_StepBFull
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1c1_StepDMath
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open scoped ENNReal
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### 1. Birth-Pool Cancellation Potential `c12ChainBirthPot` -/

noncomputable abbrev c12EntryToLiveNode {d : ℕ} {NodeAux : Type}
    (e : SyncSuffixPrefixEntry d NodeAux) : SyncLiveChainNode d NodeAux :=
  { built := e.built, birthPool := e.birthPool, ageUpdateSteps := ∅ }

noncomputable abbrev c12EntriesToLiveNodes {d : ℕ} {NodeAux : Type}
    (entries : List (SyncSuffixPrefixEntry d NodeAux)) : List (SyncLiveChainNode d NodeAux) :=
  entries.map c12EntryToLiveNode

def c12ChainBirthPot {d : ℕ} {NodeAux : Type}
    (cur : SyncSchedulePrefixState d NodeAux) : ℕ :=
  (cur.nodes.map (fun v => v.birthPool.card)).sum

theorem c12ChainBirthPot_take_append {d : ℕ} {NodeAux : Type}
    (curNodes updNodes : List (SyncLiveChainNode d NodeAux))
    (sufEntries : List (SyncSuffixPrefixEntry d NodeAux))
    (jStar : ℕ)
    (hmap_upd : updNodes.map (fun v => v.birthPool.card) =
      curNodes.map (fun v => v.birthPool.card)) :
    ((updNodes.take jStar ++ c12EntriesToLiveNodes sufEntries).map (fun v => v.birthPool.card)).sum +
      ((curNodes.drop jStar).map (fun v => v.birthPool.card)).sum =
    (curNodes.map (fun v => v.birthPool.card)).sum +
      (sufEntries.map (fun e => e.birthPool.card)).sum := by
  have htake_map : (updNodes.take jStar).map (fun v => v.birthPool.card) =
      (curNodes.take jStar).map (fun v => v.birthPool.card) := by
    rw [List.map_take, List.map_take, hmap_upd]
  have hsuf_map : (c12EntriesToLiveNodes sufEntries).map (fun v => v.birthPool.card) =
      sufEntries.map (fun e => e.birthPool.card) := by
    unfold c12EntriesToLiveNodes c12EntryToLiveNode
    rw [List.map_map]; rfl
  have hsplit : (curNodes.map (fun v => v.birthPool.card)).sum =
      ((curNodes.take jStar).map (fun v => v.birthPool.card)).sum +
      ((curNodes.drop jStar).map (fun v => v.birthPool.card)).sum := by
    conv_lhs => rw [← List.take_append_drop jStar curNodes]
    rw [List.map_append, List.sum_append]
  rw [List.map_append, List.sum_append, htake_map, hsuf_map, hsplit]
  omega

theorem runSyncSuffixFuel_birthCard_le_work {d L_leaf : ℕ} {NodeAux : Type}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    {hist : ExecutionHistory d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {S₀ : Finset ℕ}
    (hwk : ∀ acc R bs₁ out, L_leaf < R.card → R ⊆ S₀ →
      ctor.buildWithBits hist acc ltCoords R bs₁ = some out → R.card ≤ out.work) :
    ∀ (fuel : ℕ) (acc : List (SyncSuffixPrefixEntry d NodeAux))
      (R : Finset ℕ) (accWork : ℕ) (bs : List Bool)
      (sufOut : SyncSuffixOutcome d NodeAux),
      R ⊆ S₀ →
      runSyncSuffixFuel ctor L_leaf hist ltCoords fuel acc R accWork bs = some sufOut →
        (sufOut.entries.map (fun e => e.birthPool.card)).sum + accWork ≤
          (acc.map (fun e => e.birthPool.card)).sum + sufOut.totalWork := by
  intro fuel
  induction fuel with
  | zero =>
      intro acc R accWork bs sufOut _ hr
      dsimp only [runSyncSuffixFuel] at hr
      split_ifs at hr with hc
      injection hr with heq; subst heq
      exact le_rfl
  | succ fuel ih =>
      intro acc R accWork bs sufOut hR_sub hr
      dsimp only [runSyncSuffixFuel] at hr
      by_cases hle : R.card ≤ L_leaf
      · rw [if_pos hle] at hr
        split_ifs at hr with hemp
        injection hr with heq; subst heq
        exact le_rfl
      · rw [if_neg hle] at hr
        by_cases hStep : ∃ (bs₁ bs₂ : List Bool) (out : SyncBuiltNode d NodeAux),
            bs = bs₁ ++ bs₂ ∧ ctor.buildWithBits hist acc ltCoords R bs₁ = some out
        · rw [dif_pos hStep] at hr
          let bs₁ := Classical.choose hStep
          let h₂ := Classical.choose_spec hStep
          let bs₂ := Classical.choose h₂
          let h₃ := Classical.choose_spec h₂
          let out := Classical.choose h₃
          have hbuild : ctor.buildWithBits hist acc ltCoords R bs₁ = some out :=
            (Classical.choose_spec h₃).2
          have hR_le_wk : R.card ≤ out.work :=
            hwk acc R bs₁ out (Nat.lt_of_not_ge hle) hR_sub hbuild
          let entry : SyncSuffixPrefixEntry d NodeAux :=
            { birthPool := R, coins := bs₁, built := out }
          have hR'_sub : out.node.residual ltCoords R ⊆ S₀ :=
            (nodeResidual_subset_self out.node ltCoords R).trans hR_sub
          have hrec := ih (acc ++ [entry]) (out.node.residual ltCoords R)
            (accWork + out.work) bs₂ sufOut hR'_sub hr
          have hmap_app : ((acc ++ [entry]).map (fun e => e.birthPool.card)).sum =
              (acc.map (fun e => e.birthPool.card)).sum + R.card := by
            simp [entry]
          rw [hmap_app] at hrec
          omega
        · rw [dif_neg hStep] at hr
          cases hr

theorem runSyncSuffixBuild_birthCard_le_work {d L_leaf : ℕ} {NodeAux : Type}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    {hist : ExecutionHistory d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {bs : List Bool} {sufOut : SyncSuffixOutcome d NodeAux}
    (hwk : ∀ acc R bs₁ out, L_leaf < R.card → R ⊆ S →
      ctor.buildWithBits hist acc ltCoords R bs₁ = some out → R.card ≤ out.work)
    (hsuf : runSyncSuffixBuild ctor L_leaf hist ltCoords S bs = some sufOut) :
    (sufOut.entries.map (fun e => e.birthPool.card)).sum ≤ sufOut.totalWork := by
  have h := runSyncSuffixFuel_birthCard_le_work hwk S.card [] S 0 bs sufOut Finset.Subset.rfl hsuf
  simpa using h

/-! ### 2. Synchronous Invariant `C12SyncInv`, Chain-Length Ceiling, and Step Decomposition -/

def C12SyncInv {d : ℕ} (s₀_d B n : ℕ) (c_chg C_sum C_charge : ℝ)
    (cur : SyncSchedulePrefixState d (PosDimNodeData d s₀_d)) : Prop :=
  SyncStateInv n (2 * s₀_d - 1) c_chg C_sum C_charge (1 / (4 * (s₀_d : ℝ)))
    (Real.sqrt 2) (RatAdmissiblePointSet d B) cur ∧
  c12ReplayHistory d cur.history = cur.pointSet

theorem c12SyncInv_init {d : ℕ} (s₀_d B n : ℕ) (c_chg C_sum C_charge : ℝ) :
    C12SyncInv s₀_d B n c_chg C_sum C_charge
      (initSyncSchedulePrefixState d (PosDimNodeData d s₀_d)) :=
  ⟨syncStateInv_init, rfl⟩

theorem c12_log_two_mul_le_clog {n : ℕ} (hn : 2 ≤ n) :
    Real.log ((n : ℝ) + 1) ≤ Real.log (2 * (n : ℝ)) ∧
    Real.log (2 * (n : ℝ)) ≤ (Nat.clog 2 (2 * n) : ℝ) := by
  set L := Nat.clog 2 (2 * n)
  have hn_R : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have hlog1 : Real.log ((n : ℝ) + 1) ≤ Real.log (2 * (n : ℝ)) :=
    Real.log_le_log (by positivity) (by linarith)
  have hpow_nat : 2 * n ≤ 2 ^ L := Nat.le_pow_clog (by decide) (2 * n)
  have hpow_R : 2 * (n : ℝ) ≤ (2 : ℝ) ^ L := by exact_mod_cast hpow_nat
  have hlog2_le1 : Real.log 2 ≤ 1 := by
    have h := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 2)
    linarith
  have hlog_pow : Real.log (2 * (n : ℝ)) ≤ (L : ℝ) := by
    calc Real.log (2 * (n : ℝ))
      _ ≤ Real.log ((2 : ℝ) ^ L) := Real.log_le_log (by positivity) hpow_R
      _ = (L : ℝ) * Real.log 2 := Real.log_pow 2 L
      _ ≤ (L : ℝ) * 1 := mul_le_mul_of_nonneg_left hlog2_le1 (Nat.cast_nonneg L)
      _ = (L : ℝ) := mul_one _
  exact ⟨hlog1, hlog_pow⟩

theorem c12SyncInv_chain_len_bounds {d s₀_d B n : ℕ}
    (hn : 2 ≤ n) (hs₀ : 1 ≤ s₀_d)
    {c₁ C_nodes : ℝ} (hCn_pos : 0 < C_nodes)
    (h51 : ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ), 0 < α → α ≤ 1 →
      (∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
        ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
          ∀ (age : ℕ), HasNodeAge P₀ S age →
            (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
            let V := liftVariance o s
            let C := nodeCore pts o V S
            let child := nodeResidual pts o V S
            let m : ℝ := P₀.card
            15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
            (S.card : ℝ) ≤ (1 + α / 16) * m ∧
            (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ)) ∧
      (∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
        (∀ (k : ℕ) (nodes : Fin k → ChainNode d)
            (P₀ : Fin k → Finset ι)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
            (age : Fin k → ℕ),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
          (∀ j : Fin (k + 1),
            ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
          ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
          (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1)) ∧
        (∀ (L_leaf : ℕ),
          (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
            ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
              IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
          ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
            (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) ∧
            (∀ i : Fin k,
              L_leaf < (chainInput pts nodes P i.castSucc).card ∧
              (nodes i).o = o i ∧
              (nodes i).V = liftVariance (o i) (s i) ∧
              IsCenterpoint α
                (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
                (liftedPoint (o i) (s i))) ∧
            (chainTerminal pts nodes P).card ≤ L_leaf ∧
            (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2)))
    {cur : SyncSchedulePrefixState d (PosDimNodeData d s₀_d)}
    (hinv : C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) cur) :
    let L := Nat.clog 2 (2 * n)
    let K_min := Nat.ceil ((C_nodes + 1) * 4) * s₀_d * L
    C_nodes * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) ≤ (K_min : ℝ) ∧
    cur.nodes.length + 1 ≤ K_min ∧
    (∀ j : Fin cur.nodes.length, ∀ s ∈ (cur.nodes.get j).ageUpdateSteps, s < cur.history.length) := by
  intro L K_min
  let α : ℝ := 1 / (4 * (s₀_d : ℝ))
  have hs₀_R : (1 : ℝ) ≤ (s₀_d : ℝ) := by exact_mod_cast hs₀
  have hα_pos : 0 < α := by dsimp [α]; positivity
  have hα_le1 : α ≤ 1 := by dsimp [α]; rw [div_le_one (by positivity)]; linarith
  have hk_real := syncState_chain_len_bound h51 hCn_pos hn hα_pos hα_le1 hinv.1
  have hinv_α : α⁻¹ = 4 * (s₀_d : ℝ) := by
    dsimp [α]; rw [one_div, inv_inv]
  rw [hinv_α] at hk_real
  obtain ⟨hlog1, hlogL⟩ := c12_log_two_mul_le_clog hn
  have hceil : (C_nodes + 1) * 4 ≤ (Nat.ceil ((C_nodes + 1) * 4) : ℝ) := Nat.le_ceil _
  have hlog_nn : 0 ≤ Real.log ((n : ℝ) + 1) := Real.log_nonneg (by
    have : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
    linarith)
  have hprod_le : (C_nodes + 1) * (4 * (s₀_d : ℝ)) * Real.log (2 * (n : ℝ)) ≤ (K_min : ℝ) := by
    have h1 : (C_nodes + 1) * (4 * (s₀_d : ℝ)) * Real.log (2 * (n : ℝ)) ≤
        (C_nodes + 1) * (4 * (s₀_d : ℝ)) * (L : ℝ) :=
      mul_le_mul_of_nonneg_left hlogL (by positivity)
    have h2 : (C_nodes + 1) * (4 * (s₀_d : ℝ)) * (L : ℝ) ≤
        ((Nat.ceil ((C_nodes + 1) * 4) : ℝ) * (s₀_d : ℝ) * (L : ℝ)) := by
      have hm1 : (C_nodes + 1) * 4 ≤ (Nat.ceil ((C_nodes + 1) * 4) : ℝ) := hceil
      have hm2 := mul_le_mul_of_nonneg_right hm1 (show (0 : ℝ) ≤ (s₀_d : ℝ) * (L : ℝ) by positivity)
      linarith
    have hcast : ((K_min : ℕ) : ℝ) = (Nat.ceil ((C_nodes + 1) * 4) : ℝ) * (s₀_d : ℝ) * (L : ℝ) := by
      dsimp [K_min]; push_cast; ring
    rw [hcast]; exact h1.trans h2
  have hK_bound : C_nodes * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) ≤ (K_min : ℝ) := by
    have h1 : C_nodes * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) ≤
        (C_nodes + 1) * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) := by
      have : C_nodes ≤ C_nodes + 1 := by linarith
      exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right this (by positivity)) hlog_nn
    have h2 : (C_nodes + 1) * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) ≤
        (C_nodes + 1) * (4 * (s₀_d : ℝ)) * Real.log (2 * (n : ℝ)) :=
      mul_le_mul_of_nonneg_left hlog1 (by positivity)
    exact (h1.trans h2).trans hprod_le
  have hk_nat : cur.nodes.length + 1 ≤ K_min := by
    have hle_R : ((cur.nodes.length + 1 : ℕ) : ℝ) ≤ (K_min : ℝ) := hk_real.trans hprod_le
    exact_mod_cast hle_R
  exact ⟨hK_bound, hk_nat, fun j => (hinv.1.2.2.1 j).2.2.2.2.2.2⟩

/-- Complete step decomposition of `runSingleSyncScheduleStep` matching `exec_posDimStepB` and
`exec_posDimStepC` (`CG11_StepC3.lean`). -/
structure C12SyncStepDecomp {d : ℕ} (s₀_d L : ℕ)
    (ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d s₀_d))
    (cur syncNext : SyncSchedulePrefixState d (PosDimNodeData d s₀_d))
    (op : DynamicUpdate d) (bs : List Bool) : Prop where
  apply_eq : applyDynamicUpdate cur.pointSet op
    (stepRetHandle mexHandle cur.pointSet.activeHandles op) = some syncNext.pointSet
  ltCoords_eq : syncNext.ltCoords = opNextLtCoords cur.pointSet cur.ltCoords op
  work_mono : cur.totalRebuildWork ≤ syncNext.totalRebuildWork
  history_eq : syncNext.history = cur.history ++
    [{ operation := op
       randomBits := bs
       returnedHandle := stepRetHandle mexHandle cur.pointSet.activeHandles op
       answer := (ansPolPosDim d s₀_d L).checkedAnswer syncNext.pointSet syncNext.nodes
       resolvedIds := resolveAnswerIdentities syncNext.pointSet
         ((ansPolPosDim d s₀_d L).checkedAnswer syncNext.pointSet syncNext.nodes) }]
  snapshots_eq : syncNext.snapshots = cur.snapshots ++
    [(syncNext.pointSet, (ansPolPosDim d s₀_d L).checkedAnswer syncNext.pointSet syncNext.nodes)]
  no_trig_age :
    let k := cur.nodes.length
    let vecNodes : Fin k → ChainNode d := fun i => (cur.nodes.get i).built.node
    let ltCoords' := opNextLtCoords cur.pointSet cur.ltCoords op
    let S_old := chainInput ltCoords' vecNodes (activeLifetimes cur.pointSet)
    let S_new := chainInput ltCoords' vecNodes (activeLifetimes syncNext.pointSet)
    let updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)) :=
      open Classical in
      List.ofFn (fun i : Fin k =>
        let v := cur.nodes.get i
        let age' := if S_new i.castSucc ≠ S_old i.castSucc then
          insert cur.history.length v.ageUpdateSteps else v.ageUpdateSteps
        { v with ageUpdateSteps := age' })
    let slotTriggers : ℕ → Prop := fun j =>
      open Classical in
      if hj : j < k then
        let vOld := cur.nodes.get ⟨j, hj⟩
        let ageCard :=
          (if S_new ⟨j, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨j, Nat.lt_succ_of_lt hj⟩ then
            insert cur.history.length vOld.ageUpdateSteps
          else
            vOld.ageUpdateSteps).card
        (1 / (4 * (s₀_d : ℝ))) * (vOld.birthPool.card : ℝ) / 16 < (ageCard : ℝ)
      else
        j = k ∧ 2 * (2 * s₀_d - 1) < (S_new (Fin.last k)).card
    ∀ (j : ℕ) (hj : j < k),
      ¬ slotTriggers j →
        let vUpd := updatedNodes.get ⟨j, by simp [updatedNodes, k, hj]⟩
        (vUpd.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (vUpd.birthPool.card : ℝ) / 16
  no_trig_leaf :
    let k := cur.nodes.length
    let vecNodes : Fin k → ChainNode d := fun i => (cur.nodes.get i).built.node
    let ltCoords' := opNextLtCoords cur.pointSet cur.ltCoords op
    let S_old := chainInput ltCoords' vecNodes (activeLifetimes cur.pointSet)
    let S_new := chainInput ltCoords' vecNodes (activeLifetimes syncNext.pointSet)
    let slotTriggers : ℕ → Prop := fun j =>
      open Classical in
      if hj : j < k then
        let vOld := cur.nodes.get ⟨j, hj⟩
        let ageCard :=
          (if S_new ⟨j, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨j, Nat.lt_succ_of_lt hj⟩ then
            insert cur.history.length vOld.ageUpdateSteps
          else
            vOld.ageUpdateSteps).card
        (1 / (4 * (s₀_d : ℝ))) * (vOld.birthPool.card : ℝ) / 16 < (ageCard : ℝ)
      else
        j = k ∧ 2 * (2 * s₀_d - 1) < (S_new (Fin.last k)).card
    ¬ slotTriggers k →
      (S_new (Fin.last k)).card ≤ 2 * (2 * s₀_d - 1)
  sync_branch :
    open Classical in
    let k := cur.nodes.length
    let vecNodes : Fin k → ChainNode d := fun i => (cur.nodes.get i).built.node
    let ltCoords' := opNextLtCoords cur.pointSet cur.ltCoords op
    let S_old := chainInput ltCoords' vecNodes (activeLifetimes cur.pointSet)
    let S_new := chainInput ltCoords' vecNodes (activeLifetimes syncNext.pointSet)
    let updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)) :=
      List.ofFn (fun i : Fin k =>
        let v := cur.nodes.get i
        let age' := if S_new i.castSucc ≠ S_old i.castSucc then
          insert cur.history.length v.ageUpdateSteps else v.ageUpdateSteps
        { v with ageUpdateSteps := age' })
    let slotTriggers : ℕ → Prop := fun j =>
      if hj : j < k then
        let vOld := cur.nodes.get ⟨j, hj⟩
        let ageCard :=
          (if S_new ⟨j, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨j, Nat.lt_succ_of_lt hj⟩ then
            insert cur.history.length vOld.ageUpdateSteps
          else
            vOld.ageUpdateSteps).card
        (1 / (4 * (s₀_d : ℝ))) * (vOld.birthPool.card : ℝ) / 16 < (ageCard : ℝ)
      else
        j = k ∧ 2 * (2 * s₀_d - 1) < (S_new (Fin.last k)).card
    let jStar := jStarStep k slotTriggers (k + 1)
    if hTrig : ∃ j ≤ k, slotTriggers j then
      ∃ sufOut : SyncSuffixOutcome d (PosDimNodeData d s₀_d),
        let S_trig := S_new ⟨jStar, Nat.lt_succ_of_le ((jStarStep_final k slotTriggers).1 hTrig).2.1⟩
        runSyncSuffixBuild ctor (2 * s₀_d - 1) cur.history ltCoords' S_trig bs = some sufOut ∧
        syncNext.nodes = updatedNodes.take jStar ++ c12EntriesToLiveNodes sufOut.entries ∧
        syncNext.totalRebuildWork - cur.totalRebuildWork = sufOut.totalWork
    else
      bs = [] ∧ syncNext.nodes = updatedNodes ∧ syncNext.totalRebuildWork - cur.totalRebuildWork = 0
  pot_bound :
    open Classical in
    let k := cur.nodes.length
    let vecNodes : Fin k → ChainNode d := fun i => (cur.nodes.get i).built.node
    let ltCoords' := opNextLtCoords cur.pointSet cur.ltCoords op
    let S_old := chainInput ltCoords' vecNodes (activeLifetimes cur.pointSet)
    let S_new := chainInput ltCoords' vecNodes (activeLifetimes syncNext.pointSet)
    let slotTriggers : ℕ → Prop := fun j =>
      if hj : j < k then
        let vOld := cur.nodes.get ⟨j, hj⟩
        let ageCard :=
          (if S_new ⟨j, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨j, Nat.lt_succ_of_lt hj⟩ then
            insert cur.history.length vOld.ageUpdateSteps
          else
            vOld.ageUpdateSteps).card
        (1 / (4 * (s₀_d : ℝ))) * (vOld.birthPool.card : ℝ) / 16 < (ageCard : ℝ)
      else
        j = k ∧ 2 * (2 * s₀_d - 1) < (S_new (Fin.last k)).card
    let jStar := jStarStep k slotTriggers (k + 1)
    ((cur.nodes.drop jStar).map (fun v => v.birthPool.card)).sum + c12ChainBirthPot syncNext ≤
      c12ChainBirthPot cur + (syncNext.totalRebuildWork - cur.totalRebuildWork)


end UL.C12LVE
