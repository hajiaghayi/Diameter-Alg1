import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2b1
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b3_StepBFull
import UL.Proof.clm_7_3_las_vegas_endpoint.CG10_StepC2A0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL
open UL.Proof_lem_A_1
open UL.C12LVE

def level3WriteLocs (nodeStride j : ℕ) : Finset RAMCellLoc :=
  (Finset.range nodeStride).image (fun off => RAMCellLoc.heap 3 (nodeCellAddr nodeStride j off))

theorem card_level3WriteLocs_le (nodeStride j : ℕ) :
    (level3WriteLocs nodeStride j).card ≤ nodeStride := by
  unfold level3WriteLocs
  exact Finset.card_image_le.trans (by simp)

theorem mem_level3WriteLocs {nodeStride j off : ℕ} (hoff : off < nodeStride) :
    RAMCellLoc.heap 3 (nodeCellAddr nodeStride j off) ∈ level3WriteLocs nodeStride j :=
  Finset.mem_image.mpr ⟨off, Finset.mem_range.mpr hoff, rfl⟩

theorem level3WriteLocs_sub_posDimWriteLocs {d L K_max j : ℕ} (hj : j ≤ K_max + 1) :
    level3WriteLocs (posNodeStride d L) j ⊆ posDimWriteLocs d L K_max := by
  intro loc hloc
  unfold level3WriteLocs at hloc
  rcases Finset.mem_image.mp hloc with ⟨off, hoff, rfl⟩
  exact mem_posDimWriteLocs_tab3 hj (Finset.mem_range.mp hoff)

/-- Splice modifications made on `locs` in `wsSim₁` back onto `wsBase` for `A2SimInv.replaceBase`. -/
def copyRangeToBase (locs : Finset RAMCellLoc) (wsBase wsSim₁ : WordStore) : WordStore where
  live := (wsBase.live \ locs) ∪ (wsSim₁.live ∩ locs)
  vals := fun loc => if loc ∈ locs then wsSim₁.vals loc else wsBase.vals loc

theorem copyRangeToBase_replaceBase {d L K_max W T_max S_max : ℕ}
    {locs : Finset RAMCellLoc} (hlocs_sub : locs ⊆ posDimWriteLocs d L K_max)
    {wsBase wsSub wsSim₀ wsSim₁ : WordStore}
    {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hmodBase : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsBase)
    (hinv0 : A2SimInv wsBase T_max S_max wsSub wsSim₀ highSid sidOfEnc encOfSid freeStack)
    (hmodSim : ModifiedOnBounded wsSim₀ locs W wsSim₁)
    (hunchSim : ∀ loc : RAMCellLoc, loc ∉ locs →
      (loc ∈ wsSim₁.live ↔ loc ∈ wsSim₀.live) ∧ wsSim₁.vals loc = wsSim₀.vals loc) :
    let wsBaseNew := copyRangeToBase locs wsBase wsSim₁
    ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsBaseNew ∧
    A2SimInv wsBaseNew T_max S_max wsSub wsSim₁ highSid sidOfEnc encOfSid freeStack ∧
    (∀ loc ∈ locs,
      (loc ∈ wsBaseNew.live ↔ loc ∈ wsSim₁.live) ∧
      wsBaseNew.vals loc = wsSim₁.vals loc ∧
      wsBaseNew.read loc = wsSim₁.read loc) ∧
    (∀ loc ∉ locs,
      (loc ∈ wsBaseNew.live ↔ loc ∈ wsBase.live) ∧
      wsBaseNew.vals loc = wsBase.vals loc ∧
      wsBaseNew.read loc = wsBase.read loc) := by
  intro wsBaseNew
  have hwfNew : WellFormedWS wsBaseNew := by
    intro loc hnot
    dsimp [wsBaseNew, copyRangeToBase] at hnot ⊢
    by_cases hL : loc ∈ locs
    · rw [if_pos hL]
      have hn1 : loc ∉ wsSim₁.live := fun hm => hnot (Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨hm, hL⟩))
      exact hmodSim.wf loc hn1
    · rw [if_neg hL]
      have hn0 : loc ∉ wsBase.live := fun hm => hnot (Finset.mem_union_left _ (Finset.mem_sdiff.mpr ⟨hm, hL⟩))
      exact hmodBase.wf loc hn0
  have hmodNew : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsBaseNew := by
    refine
      { wf := hwfNew
        live_sub := fun loc hm => by
          simp only [WordStore.empty, Finset.empty_union]
          dsimp [wsBaseNew, copyRangeToBase] at hm
          rcases Finset.mem_union.mp hm with h1 | h2
          · have hb := hmodBase.live_sub (Finset.mem_sdiff.mp h1).1
            simpa [WordStore.empty] using hb
          · exact hlocs_sub (Finset.mem_inter.mp h2).2
        unchanged := fun loc hn => by
          have hnLive : loc ∉ wsBaseNew.live := fun hm => by
            dsimp [wsBaseNew, copyRangeToBase] at hm
            rcases Finset.mem_union.mp hm with h1 | h2
            · have hb := hmodBase.live_sub (Finset.mem_sdiff.mp h1).1
              simp only [WordStore.empty, Finset.empty_union] at hb
              exact hn hb
            · exact hn (hlocs_sub (Finset.mem_inter.mp h2).2)
          exact ⟨by simp [hnLive, WordStore.empty], by rw [hwfNew loc hnLive]; rfl⟩
        bounded_write := fun loc hm _ => by
          dsimp [wsBaseNew, copyRangeToBase] at hm ⊢
          rcases Finset.mem_union.mp hm with h1 | h2
          · obtain ⟨hmB, hnL⟩ := Finset.mem_sdiff.mp h1
            rw [if_neg hnL]
            have hp : loc ∈ posDimWriteLocs d L K_max := by
              have hb := hmodBase.live_sub hmB
              simpa [WordStore.empty] using hb
            exact hmodBase.bounded_write loc hmB hp
          · obtain ⟨hmS, hL⟩ := Finset.mem_inter.mp h2
            rw [if_pos hL]
            exact hmodSim.bounded_write loc hmS hL }
  have hinLocs : ∀ loc ∈ locs,
      (loc ∈ wsBaseNew.live ↔ loc ∈ wsSim₁.live) ∧
      wsBaseNew.vals loc = wsSim₁.vals loc ∧
      wsBaseNew.read loc = wsSim₁.read loc := by
    intro loc hL
    have hlive : loc ∈ wsBaseNew.live ↔ loc ∈ wsSim₁.live := by
      dsimp [wsBaseNew, copyRangeToBase]
      simp [hL]
    have hval : wsBaseNew.vals loc = wsSim₁.vals loc := by
      dsimp [wsBaseNew, copyRangeToBase]; rw [if_pos hL]
    have hrd : wsBaseNew.read loc = wsSim₁.read loc := by
      unfold WordStore.read; rw [hval]
      by_cases hm : loc ∈ wsSim₁.live
      · rw [if_pos (hlive.mpr hm), if_pos hm]
      · rw [if_neg (fun h => hm (hlive.mp h)), if_neg hm]
    exact ⟨hlive, hval, hrd⟩
  have houtLocs : ∀ loc ∉ locs,
      (loc ∈ wsBaseNew.live ↔ loc ∈ wsBase.live) ∧
      wsBaseNew.vals loc = wsBase.vals loc ∧
      wsBaseNew.read loc = wsBase.read loc := by
    intro loc hnL
    have hlive : loc ∈ wsBaseNew.live ↔ loc ∈ wsBase.live := by
      dsimp [wsBaseNew, copyRangeToBase]
      simp [hnL]
    have hval : wsBaseNew.vals loc = wsBase.vals loc := by
      dsimp [wsBaseNew, copyRangeToBase]; rw [if_neg hnL]
    have hrd : wsBaseNew.read loc = wsBase.read loc := by
      unfold WordStore.read; rw [hval]
      by_cases hm : loc ∈ wsBase.live
      · rw [if_pos (hlive.mpr hm), if_pos hm]
      · rw [if_neg (fun h => hm (hlive.mp h)), if_neg hm]
    exact ⟨hlive, hval, hrd⟩
  have hinvNew : A2SimInv wsBaseNew T_max S_max wsSub wsSim₁ highSid sidOfEnc encOfSid freeStack := by
    refine hinv0.replaceBase (isA2BaseStore_of_modPosDim hmodNew) hmodSim.wf ?_ ?_ ?_ ?_
    · intro loc hbase
      by_cases hL : loc ∈ locs
      · exact (hinLocs loc hL).1.symm
      · exact (hunchSim loc hL).1.trans ((hinv0.base_live loc hbase).trans (houtLocs loc hL).1.symm)
    · intro loc hbase
      by_cases hL : loc ∈ locs
      · exact (hinLocs loc hL).2.1.symm
      · exact (hunchSim loc hL).2.trans ((hinv0.base_vals loc hbase).trans (houtLocs loc hL).2.1.symm)
    · intro loc hnbase
      have hnL : loc ∉ locs := fun hL => hnbase (posDimWriteLocs_isA2Base loc (hlocs_sub hL))
      exact (hunchSim loc hnL).1
    · intro loc hnbase
      have hnL : loc ∉ locs := fun hL => hnbase (posDimWriteLocs_isA2Base loc (hlocs_sub hL))
      exact (hunchSim loc hnL).2
  exact ⟨hmodNew, hinvNew, hinLocs, houtLocs⟩


/-! ### 1. Sort `heap 8[0..m)` via Unit Tree `1` (`sortBufViaUnitTree1Regs`) -/

def sortBufViaUnitTree1Regs (L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 111)
  (.seq (rFree 9 10)
  (.seq (rLit 10 112)
  (.seq (rFree 9 10)
  (.seq (rLit 0 1)
  (.seq (insertBufToUnitTreeRegs L)
  (.seq freeBufRegs
  (.seq (rLit 0 1)
        (popTreeToBufRegs L))))))))

theorem exec_sortBufViaUnitTree1Regs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L m : ℕ} (hL1 : 1 ≤ L) (hm_le : m ≤ 2 ^ L) (hW : L + 28 ≤ W)
    (hSubTree1 : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L 1 u f) : RAMCellLoc) ∈ S_write)
    (hSub8 : ∀ (k : ℕ), k < 2 ^ L → (.heap 8 (k : ℤ) : RAMCellLoc) ∈ S_write)
    (hSub110 : (.heap 9 110 : RAMCellLoc) ∈ S_write)
    (hSub111 : (.heap 9 111 : RAMCellLoc) ∈ S_write)
    (hSub112 : (.heap 9 112 : RAMCellLoc) ∈ S_write)
    (htree1 : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) ws)
    (hr110 : ws.read (.heap 9 110) = (m : ℤ))
    {hSeq₀ : ℕ → ℕ} {S_H : Finset ℕ}
    (hhSeq_lt : ∀ k < m, hSeq₀ k < 2 ^ L)
    (hbuf : ∀ k < m, ws.read (.heap 8 (k : ℤ)) = (hSeq₀ k : ℤ))
    (himg : (Finset.range m).image hSeq₀ = S_H)
    (hcard : S_H.card = m)
    (hclean8 : ∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ ws.live)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (sortBufViaUnitTree1Regs L) ws regs wsEnd regsEnd
        ((m + 1) * (900 * L + 700) + 100)
        ((m + 1) * (150 * L + 200) * W * W + 100 * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsEnd ∧
      wsEnd.read (.heap 9 110) = (m : ℤ) ∧
      (∀ k < m, wsEnd.read (.heap 8 (k : ℤ)) = (minPopElem S_H k : ℤ)) ∧
      (∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsEnd.live) ∧
      (.heap 9 111 : RAMCellLoc) ∉ wsEnd.live ∧
      (.heap 9 112 : RAMCellLoc) ∉ wsEnd.live ∧
      (∀ loc : RAMCellLoc,
        loc ∉ treeSliceLocs L 1 →
        loc ≠ .heap 9 110 → loc ≠ .heap 9 111 → loc ≠ .heap 9 112 →
        (∀ z : ℤ, loc ≠ .heap 8 z) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW28 : 28 ≤ W := by clear * - hW; omega
  have hWW : 28 * W ≤ W * W := by nlinarith only [hW28]
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by clear * - hW28; omega)
  have hl111 : intBitLength (111 : ℤ) ≤ W := (show intBitLength (111 : ℤ) = 8 from by decide).trans_le (by clear * - hW28; omega)
  have hl112 : intBitLength (112 : ℤ) ≤ W := (show intBitLength (112 : ℤ) = 8 from by decide).trans_le (by clear * - hW28; omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by clear * - hW28; omega)
  have hn1_tid : natBitLength 1 = 1 := by decide
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 111) (by decide) hl111
  set g1 := Function.update regs 10 111; have bg1 := hbnd.update (r := 10) (by decide) hl111
  set ws1a := ws.free (.heap 9 111); have hm1a := hmod.free hSub111
  have s2 : RegExec inp fd W C_cell C_bit (rFree 9 10) ws g1 ws1a g1 4 (3 * W + 16) :=
    (RegExec.free (inp := inp) bg1 (table := 9) (addr := 10) (by decide) hn9).weaken
      (by simp [g1, ws1a]) rfl le_rfl le_rfl
  have s3 := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hm1a).1 (sp_ok hm1a).2 (dst := 10) (c := 112) (by decide) hl112
  set g3 := Function.update g1 10 112; have bg3 := bg1.update (r := 10) (by decide) hl112
  set ws1 := ws1a.free (.heap 9 112); have hm1 := hm1a.free hSub112
  have s4 : RegExec inp fd W C_cell C_bit (rFree 9 10) ws1a g3 ws1 g3 4 (3 * W + 16) :=
    (RegExec.free (inp := inp) bg3 (table := 9) (addr := 10) (by decide) hn9).weaken
      (by simp [g3, ws1]) rfl le_rfl le_rfl
  have s5 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 0) (c := 1) (by decide) hl1
  set g5 := Function.update g3 0 1; have bg5 := bg3.update (r := 0) (by decide) hl1
  have hunch1 : ∀ loc : RAMCellLoc, loc ≠ .heap 9 111 → loc ≠ .heap 9 112 →
      (loc ∈ ws1.live ↔ loc ∈ ws.live) ∧ ws1.vals loc = ws.vals loc := by
    intro loc h111 h112
    dsimp only [ws1, ws1a, WordStore.free]
    exact ⟨by simp [h112, h111], by simp [Function.update_of_ne h112, Function.update_of_ne h111]⟩
  have hn111_1 : (.heap 9 111 : RAMCellLoc) ∉ ws1.live := by simp [ws1, ws1a, WordStore.free]
  have hn112_1 : (.heap 9 112 : RAMCellLoc) ∉ ws1.live := by simp [ws1, WordStore.free]
  have hr110_1 : ws1.read (.heap 9 110) = (m : ℤ) := by
    rw [wordStore_read_eq_vals hm1.wf, (hunch1 _ (by decide) (by decide)).2, ← wordStore_read_eq_vals hmod.wf]
    exact hr110
  have hbuf_1 : ∀ k < m, ws1.read (.heap 8 (k : ℤ)) = (hSeq₀ k : ℤ) := by
    intro k hk
    rw [wordStore_read_eq_vals hm1.wf, (hunch1 _ (fun h => by cases h) (fun h => by cases h)).2,
        ← wordStore_read_eq_vals hmod.wf]
    exact hbuf k hk
  have htree1_1 : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) ws1 :=
    htree1.unchanged (fun _ _ _ _ => hunch1 _ (fun h => by cases h) (fun h => by cases h))
  obtain ⟨ws2, g6, s6, hm2, bg6, htree1_2, hunch2⟩ :=
    exec_insertBufToUnitTreeRegs hfd_le hm1 hcCeil hbCeil hL1 hm_le
      (by rw [hn1_tid]; clear * - hW; omega) hSubTree1 hSub111 hSub112 hn111_1 hn112_1
      hhSeq_lt hr110_1 hbuf_1 htree1_1 bg5 (by simp [g5])
  rw [himg] at htree1_2
  have not_tree1 : ∀ {t : ℕ} (ht : t ≠ 2) (z : ℤ), (.heap t z : RAMCellLoc) ∉ treeSliceLocs L 1 := by
    intro t ht z hm
    unfold treeSliceLocs at hm
    rcases Finset.mem_image.mp hm with ⟨⟨_, _⟩, _, hc⟩
    injection hc with e; exact ht e.symm
  have hr110_2 : ws2.read (.heap 9 110) = (m : ℤ) := by
    rw [wordStore_read_eq_vals hm2.wf, (hunch2 _ (not_tree1 (by decide) _)).2, ← wordStore_read_eq_vals hm1.wf]
    exact hr110_1
  obtain ⟨ws3, g7, s7, hm3, bg7, _, _, hunch3⟩ :=
    exec_freeBufRegs hfd_le hm2 hcCeil hbCeil hm_le (by clear * - hW; omega) hSub8 hSub110 hr110_2 bg6
  have hn111_3 : (.heap 9 111 : RAMCellLoc) ∉ ws3.live := by
    rw [(hunch3 _ (by decide) (fun _ _ h => by cases h)).1,
        (hunch2 _ (not_tree1 (by decide) _)).1]
    exact hn111_1
  have hn112_3 : (.heap 9 112 : RAMCellLoc) ∉ ws3.live := by
    rw [(hunch3 _ (by decide) (fun _ _ h => by cases h)).1,
        (hunch2 _ (not_tree1 (by decide) _)).1]
    exact hn112_1
  have htree1_3 : TreeStoredAt L 1 S_H (fun _ => 0) (fun _ => 1) ws3 :=
    htree1_2.unchanged (fun _ _ _ _ => hunch3 _ (fun h => by cases h) (fun _ _ h => by cases h))
  have s8 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hm3).1 (sp_ok hm3).2 (dst := 0) (c := 1) (by decide) hl1
  set g8 := Function.update g7 0 1; have bg8 := bg7.update (r := 0) (by decide) hl1
  have hSH_sub : ∀ h ∈ S_H, h < 2 ^ L ∧ intBitLength (0 : ℤ) ≤ 2 ∧ intBitLength (1 : ℤ) ≤ 2 := by
    intro h hh
    rw [← himg] at hh
    rcases Finset.mem_image.mp hh with ⟨k, hk, rfl⟩
    exact ⟨hhSeq_lt k (Finset.mem_range.mp hk), by decide, by decide⟩
  obtain ⟨wsEnd, regsEnd, s9, hmEnd, bgEnd, htree1_End, hr110_End, hbuf_End, hunch4⟩ :=
    exec_popTreeToBufRegs hfd_le hm3 hcCeil hbCeil hL1 (B_r := 2) (by decide)
      (by rw [hn1_tid]; clear * - hW; omega)
      hSubTree1 hSub8 hSub110 hSub111 hSub112 hn111_3 hn112_3 htree1_3 hSH_sub bg8 (by simp [g8])
  rw [hcard] at hr110_End hbuf_End hunch4
  have hclean8_End : ∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsEnd.live := by
    intro z hne
    rw [(hunch4 (.heap 8 z) (not_tree1 (by decide) z) (fun h => by cases h)
      (fun k hk h => hne k hk (by injection h))).1]
    by_cases hex : ∃ k < m, z = (k : ℤ)
    · rcases hex with ⟨k, hk, rfl⟩; exact absurd rfl (hne k hk)
    · push_neg at hex
      rw [(hunch3 (.heap 8 z) (fun h => by cases h) (fun k hk h => hex k hk (by injection h))).1,
          (hunch2 (.heap 8 z) (not_tree1 (by decide) z)).1,
          (hunch1 (.heap 8 z) (fun h => by cases h) (fun h => by cases h)).1]
      exact hclean8 z hex
  have hn111_End : (.heap 9 111 : RAMCellLoc) ∉ wsEnd.live := by
    rw [(hunch4 _ (not_tree1 (by decide) _) (by decide) (fun _ _ h => by cases h)).1]
    exact hn111_3
  have hn112_End : (.heap 9 112 : RAMCellLoc) ∉ wsEnd.live := by
    rw [(hunch4 _ (not_tree1 (by decide) _) (by decide) (fun _ _ h => by cases h)).1]
    exact hn112_3
  have hTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq s9)))))))).weaken rfl rfl
    (u₂ := (m + 1) * (900 * L + 700) + 100)
    (b₂ := (m + 1) * (150 * L + 200) * W * W + 100 * W * W)
    (by rw [hcard]; nlinarith only [hL1])
    (by
      rw [hcard]
      have hm12 : 12 * m + 24 ≤ (m + 1) * 10 * W := by
        calc 12 * m + 24 ≤ (m + 1) * 280 := by omega
        _ = (m + 1) * 10 * 28 := by ring
        _ ≤ (m + 1) * 10 * W := Nat.mul_le_mul_left _ hW28
      have hmW : (12 * m + 24) * W ≤ (m + 1) * 10 * W * W :=
        Nat.mul_le_mul_right W hm12
      have hmain : (m + 1) * (64 * L + 80) * W * W + (m + 1) * 10 * W * W +
          (m + 1) * (76 * L + 100) * W * W ≤ (m + 1) * (150 * L + 200) * W * W := by
        calc (m + 1) * (64 * L + 80) * W * W + (m + 1) * 10 * W * W +
              (m + 1) * (76 * L + 100) * W * W
          _ = ((m + 1) * (140 * L + 190)) * (W * W) := by ring
          _ ≤ ((m + 1) * (150 * L + 200)) * (W * W) :=
              Nat.mul_le_mul_right (W * W) (by nlinarith only [hL1])
          _ = (m + 1) * (150 * L + 200) * W * W := by ring
      have hconst : 14 * W + 96 ≤ 100 * W * W := by
        calc 14 * W + 96 ≤ 100 * 28 * W := by omega
        _ = 100 * (28 * W) := by ring
        _ ≤ 100 * (W * W) := Nat.mul_le_mul_left 100 hWW
        _ = 100 * W * W := by ring
      linarith only [hmW, hmain, hconst])
  refine ⟨wsEnd, regsEnd, hTot, hmEnd, bgEnd, htree1_End, hr110_End, hbuf_End, hclean8_End,
    hn111_End, hn112_End, fun loc hnt h110 h111 h112 h8 => ?_⟩
  have u4 := hunch4 loc hnt h110 (fun k _ => h8 (k : ℤ))
  have u3 := hunch3 loc h110 (fun k _ => h8 (k : ℤ))
  have u2 := hunch2 loc hnt
  have u1 := hunch1 loc h111 h112
  exact ⟨u4.1.trans (u3.1.trans (u2.1.trans u1.1)), u4.2.trans (u3.2.trans (u2.2.trans u1.2))⟩

/-! ### 2. `HasRegFrame 1` <-> `A2SimInv` Bridge Helpers -/

def isBaseLocBool : RAMCellLoc → Bool
  | .heap t _ => decide (t < 10)
  | .localFrame d' _ _ => decide (d' = 1)

theorem isBaseLocBool_iff (loc : RAMCellLoc) :
    isBaseLocBool loc = true ↔ IsA2BaseLoc loc := by
  cases loc <;> simp [isBaseLocBool, IsA2BaseLoc]

def baseOnlyWS (ws : WordStore) : WordStore where
  live := ws.live.filter (fun loc => isBaseLocBool loc = true)
  vals := fun loc => if isBaseLocBool loc = true then ws.vals loc else 0

theorem isA2BaseStore_baseOnly {ws : WordStore} (hwf : WellFormedWS ws) :
    IsA2BaseStore (baseOnlyWS ws) := by
  refine ⟨fun loc hn => ?_, fun loc hm => ?_⟩
  · dsimp [baseOnlyWS] at hn ⊢
    split_ifs with hb
    · exact hwf loc (fun hm => hn (Finset.mem_filter.mpr ⟨hm, hb⟩))
    · rfl
  · exact (isBaseLocBool_iff loc).mp (Finset.mem_filter.mp hm).2

theorem isA2BaseStore_of_regFrame1 {d L K_max W : ℕ} {wsHeap ws : WordStore} {regs : ℕ → ℤ}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsHeap)
    (hrf : HasRegFrame 1 wsHeap regs ws) :
    IsA2BaseStore ws := by
  refine ⟨hrf.wf, fun loc hm => ?_⟩
  cases loc with
  | heap t idx =>
      have hmH : (.heap t idx : RAMCellLoc) ∈ wsHeap.live := (hrf.below_live (.heap t idx) rfl).mp hm
      exact isA2BaseStore_of_modPosDim hmod |>.2 (.heap t idx) hmH
  | localFrame d' v i =>
      rcases lt_trichotomy d' 1 with hlt | rfl | hgt
      · have hmH : (.localFrame d' v i : RAMCellLoc) ∈ wsHeap.live :=
          (hrf.below_live _ (by simp [keepBelowDepth, hlt])).mp hm
        exact isA2BaseStore_of_modPosDim hmod |>.2 _ hmH
      · rfl
      · exact absurd hm (hrf.above_empty d' hgt v i)

theorem stagingA2Matches_of_regFrame1 {d m B : ℕ} {wsHeap ws : WordStore} {regs : ℕ → ℤ}
    {inpSub : BitRAMInput d}
    (hrf : HasRegFrame 1 wsHeap regs ws)
    (hstage : StagingA2Matches m B wsHeap inpSub) :
    StagingA2Matches m B ws inpSub := by
  rcases hstage with ⟨hd, hm, hB, hp, ha, he, hr5, hr60, hr70, hrc⟩
  refine ⟨hd, hm, hB, hp, ha, he, ?_, ?_, ?_, ?_⟩
  · intro idx; rw [hrf.read_heap]; exact hr5 idx
  · rw [hrf.read_heap]; exact hr60
  · rw [hrf.read_heap]; exact hr70
  · intro r hr c; dsimp only; rw [hrf.read_heap, hrf.read_heap]; exact hrc r hr c

theorem hasRegFrame_heapOnly_afterA2 {T_max S_max : ℕ}
    {wsHeap1 ws1 wsSub wsSim : WordStore} {regs1 : ℕ → ℤ}
    {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hrf1 : HasRegFrame 1 wsHeap1 regs1 ws1)
    (hinv : A2SimInv ws1 T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    (hnoLocal : ∀ d' v' i', (.localFrame d' v' i' : RAMCellLoc) ∉ wsSub.live) :
    HasRegFrame 1 (heapOnlyWS wsSim) regs1 wsSim := by
  have hno0_sim : ∀ v i, (.localFrame 0 v i : RAMCellLoc) ∉ wsSim.live := by
    intro v i hm
    rcases hinv.live_cases _ hm with hb | ⟨d0, _, _, heq⟩ | ⟨_, _, _, heq⟩
    · simp [IsA2BaseLoc] at hb
    · injection heq with hd; omega
    · cases heq
  refine
    { wfHeap := wellFormedWS_heapOnly hinv.wfSim
      wf := hinv.wfSim
      heapClean := fun _ _ _ _ hm => by simp [heapOnlyWS, isHeapLoc] at hm
      below_live := fun loc hk => by
        cases loc with
        | heap t idx => simp [heapOnlyWS, isHeapLoc]
        | localFrame d' v i =>
            simp only [keepBelowDepth, decide_eq_true_eq] at hk
            have hd0 : d' = 0 := by omega
            subst hd0
            simp [heapOnlyWS, isHeapLoc, hno0_sim v i]
      below_vals := fun loc hk => by
        cases loc with
        | heap t idx => simp [heapOnlyWS, isHeapLoc]
        | localFrame d' v i =>
            simp only [keepBelowDepth, decide_eq_true_eq] at hk
            have hd0 : d' = 0 := by omega
            subst hd0
            simp [heapOnlyWS, isHeapLoc, hinv.wfSim _ (hno0_sim v i)]
      above_empty := fun d' hd' v i hm => by
        have heq : d' = 2 + (d' - 2) := by omega
        rw [heq] at hm
        exact hnoLocal (d' - 2) v i ((hinv.local_live (d' - 2) v i).mp hm)
      frame_bound := fun v i hm =>
        hrf1.frame_bound v i ((hinv.base_live (.localFrame 1 v i) rfl).mp hm)
      reg_read := fun r hr => by
        rw [wordStore_read_eq_vals hinv.wfSim, hinv.base_vals (.localFrame 1 r 0) rfl,
            ← wordStore_read_eq_vals hrf1.wf]
        exact hrf1.reg_read r hr
      reg_zero := hrf1.reg_zero }

end UL.C12StepC2
