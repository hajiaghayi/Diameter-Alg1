import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2a
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3c5_NodeGeom
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL
open UL.Proof_lem_A_1
open UL.C12LVE

def ExtractCenterStepInv (d : ℕ) (ws₀ ws : WordStore) (S_write : Finset RAMCellLoc)
    (B_cert nodeStride T_max j W : ℕ) (r5_init : ℤ) (c : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
  let oNum : ℕ → ℤ := fun i => if i < d then ws.read (.heap 10 ((((2 * i) * T_max + 1 : ℕ) : ℤ))) else 0
  let oDen : ℕ → ℤ := fun i => if i < d then ws.read (.heap 10 ((((2 * i + 1) * T_max + 1 : ℕ) : ℤ))) else 1
  let zNum : ℕ → ℤ := fun _ => 0
  let zDen : ℕ → ℤ := fun _ => 1
  let sqNum : ℕ → ℤ := fun i => (oNum i * zDen i - zNum i * oDen i) * (oNum i * zDen i - zNum i * oDen i)
  let sqDen : ℕ → ℤ := fun i => (oDen i * zDen i) * (oDen i * zDen i)
  ModifiedOnBounded ws₀ S_write W w ∧
  RegBounded W g ∧
  g 0 = (j : ℤ) ∧ g 5 = r5_init ∧
  (∀ loc : RAMCellLoc,
    (∀ off : ℕ, off < 6 + 2 * d → loc ≠ .heap 3 (nodeCellAddr nodeStride j off)) →
    (loc ∈ w.live ↔ loc ∈ ws.live) ∧ w.vals loc = ws.vals loc) ∧
  (c ≤ d →
    g 6 = (c : ℤ) ∧
    g 3 = (ratSumPairs sqNum sqDen c).1 ∧
    g 4 = (ratSumPairs sqNum sqDen c).2 ∧
    intBitLength (g 3) ≤ c * (2 * (B_cert + 2) + 3) + 2 ∧
    intBitLength (g 4) ≤ c * (2 * (B_cert + 2) + 2) + 2 ∧
    ∀ (c' : ℕ), c' < d → c' < c →
      w.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c'))) = oNum c' ∧
      w.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c' + 1))) = oDen c')

theorem exec_extractCenterCoordStepStmt_inv {d : ℕ} (_hd1 : 1 ≤ d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {B_cert nodeStride T_max K_max j : ℕ}
    (hBc1 : 1 ≤ B_cert) (hT1 : 2 ≤ T_max)
    (hj : j ≤ K_max + 1) (hstride : 6 + 2 * d ≤ nodeStride)
    (hW : (d + 1) * (2 * B_cert + 8) + natBitLength ((K_max + 2) * nodeStride) +
            natBitLength ((2 * d + 2) * T_max) + 32 ≤ W)
    {oRat : Fin d → ℚ}
    (ho10 : ∀ c : Fin d,
      let oN := ws.read (.heap 10 ((((2 * c.val) * T_max + 1 : ℕ) : ℤ)))
      let oD := ws.read (.heap 10 ((((2 * c.val + 1) * T_max + 1 : ℕ) : ℤ)))
      1 ≤ oD ∧ oRat c = (oN : ℚ) / (oD : ℚ) ∧
      intBitLength oN ≤ B_cert ∧ intBitLength oD ≤ B_cert)
    (hSub3 : ∀ off < 6 + 2 * d, (.heap 3 (nodeCellAddr nodeStride j off) : RAMCellLoc) ∈ S_write)
    (r5_init : ℤ) :
    ∀ c < d, ∀ w g,
      ExtractCenterStepInv d ws₀ ws S_write B_cert nodeStride T_max j W r5_init c w g →
      ∃ w' g', RegExec inp fd W C_cell C_bit (extractCenterCoordStepStmt nodeStride T_max)
        w g w' g' 240 (56 * W * W) ∧
        ExtractCenterStepInv d ws₀ ws S_write B_cert nodeStride T_max j W r5_init (c + 1) w' g' := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hWW : 20 * W ≤ W * W := by nlinarith only [hW20]
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by clear * - hW20; omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by clear * - hW20; omega)
  have hl3 : intBitLength (3 : ℤ) ≤ W := (show intBitLength (3 : ℤ) = 3 from by decide).trans_le (by clear * - hW20; omega)
  have hl6 : intBitLength (6 : ℤ) ≤ W := (show intBitLength (6 : ℤ) = 4 from by decide).trans_le (by clear * - hW20; omega)
  have hn3 : natBitLength 3 ≤ W := (show natBitLength 3 = 2 from by decide).trans_le (by clear * - hW20; omega)
  have hn10 : natBitLength 10 ≤ W := (show natBitLength 10 = 4 from by decide).trans_le (by clear * - hW20; omega)
  have hW_node : natBitLength ((K_max + 2) * nodeStride) + 8 ≤ W := by clear * - hW; omega
  have h10_ceil_bl : intBitLength ((((2 * d + 2) * T_max : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le ((2 * d + 2) * T_max)
    clear * - h1 hW; omega
  have hd_le_ceil : d ≤ (2 * d + 2) * T_max := by
    calc d ≤ (2 * d + 2) * 1 := by clear * -; omega
      _ ≤ (2 * d + 2) * T_max := Nat.mul_le_mul_left _ (by clear * - hT1; omega)
  have hT_le_ceil : T_max ≤ (2 * d + 2) * T_max :=
    Nat.le_mul_of_pos_left T_max (by clear * -; omega)
  have hd_bl : intBitLength (d : ℤ) ≤ W :=
    (intBitLength_natCast_mono hd_le_ceil).trans h10_ceil_bl
  have hT_bl : intBitLength (T_max : ℤ) ≤ W :=
    (intBitLength_natCast_mono hT_le_ceil).trans h10_ceil_bl
  have hstride_bl : intBitLength (nodeStride : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le nodeStride
    have h2 : natBitLength nodeStride ≤ natBitLength ((K_max + 2) * nodeStride) :=
      natBitLength_mono (Nat.le_mul_of_pos_left nodeStride (by clear * -; omega))
    clear * - h1 h2 hW_node; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  let oNum : ℕ → ℤ := fun c => if c < d then ws.read (.heap 10 ((((2 * c) * T_max + 1 : ℕ) : ℤ))) else 0
  let oDen : ℕ → ℤ := fun c => if c < d then ws.read (.heap 10 ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ))) else 1
  let zNum : ℕ → ℤ := fun _ => 0
  let zDen : ℕ → ℤ := fun _ => 1
  let sqNum := fun i => (oNum i * zDen i - zNum i * oDen i) * (oNum i * zDen i - zNum i * oDen i)
  let sqDen := fun i => (oDen i * zDen i) * (oDen i * zDen i)
  intro c hc w g ⟨hm, bg, hg0, hg5, hunch, hcd⟩
  obtain ⟨hg6, hg3_eq, hg4_eq, hg3_bl, hg4_bl, hprev⟩ := hcd (Nat.le_of_lt hc)
  obtain ⟨hno0_loc, hno0_bl⟩ := nodeCellAddr_bl hj (off := 6 + 2 * c) (by clear * - hc hstride; omega) hW_node
  obtain ⟨hno1_loc, hno1_bl⟩ := nodeCellAddr_bl hj (off := 6 + 2 * c + 1) (by clear * - hc hstride; omega) hW_node
  have h2c1_le_ceil : (2 * c + 1) * T_max + 1 ≤ (2 * d + 2) * T_max := by
    calc (2 * c + 1) * T_max + 1 ≤ (2 * c + 1) * T_max + T_max := Nat.add_le_add_left (by clear * - hT1; omega) _
      _ = (2 * c + 2) * T_max := by ring
      _ ≤ (2 * d + 2) * T_max := Nat.mul_le_mul_right T_max (by clear * - hc; omega)
  have h2c_le_2cT : 2 * c ≤ (2 * c) * T_max := by
    calc 2 * c = (2 * c) * 1 := by ring
      _ ≤ (2 * c) * T_max := Nat.mul_le_mul_left _ (by clear * - hT1; omega)
  have h2cT_le_2c1T : (2 * c) * T_max ≤ (2 * c + 1) * T_max :=
    Nat.mul_le_mul_right T_max (by clear * -; omega)
  have h2c_bl : intBitLength ((2 * c : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (h2c_le_2cT.trans (h2cT_le_2c1T.trans ((Nat.le_succ _).trans h2c1_le_ceil)))).trans h10_ceil_bl
  have h2cT_bl : intBitLength (((2 * c) * T_max : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (h2cT_le_2c1T.trans ((Nat.le_succ _).trans h2c1_le_ceil))).trans h10_ceil_bl
  have ha10_0_bl : intBitLength ((((2 * c) * T_max + 1 : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono ((Nat.add_le_add_right h2cT_le_2c1T 1).trans h2c1_le_ceil)).trans h10_ceil_bl
  have ha10_1_bl : intBitLength ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono h2c1_le_ceil).trans h10_ceil_bl
  have hjs_bl : intBitLength ((j * nodeStride : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := j * nodeStride + (6 + 2 * c)) (by clear * -; omega)).trans hno0_bl
  have hjs6_bl : intBitLength ((j * nodeStride + 6 : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := j * nodeStride + (6 + 2 * c)) (by clear * -; omega)).trans hno0_bl
  have hjsc_bl : intBitLength ((j * nodeStride + 6 + c : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := j * nodeStride + (6 + 2 * c)) (by clear * -; omega)).trans hno0_bl
  have hc1_bl : intBitLength ((c + 1 : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := d) (by clear * - hc; omega)).trans hd_bl
  have ho_c := ho10 ⟨c, hc⟩; dsimp only at ho_c
  obtain ⟨_, _, hoN_bl, hoD_bl⟩ := ho_c
  have hoN_c : intBitLength (oNum c) ≤ B_cert := by simp only [oNum, if_pos hc]; exact hoN_bl
  have hoD_c : intBitLength (oDen c) ≤ B_cert := by simp only [oDen, if_pos hc]; exact hoD_bl
  have ho_W : B_cert ≤ W := by
    have hm : 1 * (2 * B_cert + 8) ≤ (d + 1) * (2 * B_cert + 8) := Nat.mul_le_mul_right _ (by clear * -; omega)
    clear * - hm hW; omega
  -- Read `heap 10` on `w` equals `ws` via `hunch`!
  have hr10_eq : ∀ z : ℤ, w.read (.heap 10 z) = ws.read (.heap 10 z) := by
    intro z
    rw [wordStore_read_eq_vals hm.wf, (hunch (.heap 10 z) (fun _ _ h => by cases h)).2, ← wordStore_read_eq_vals hmod.wf]
  have hrw_oN : w.read (.heap 10 ((((2 * c) * T_max + 1 : ℕ) : ℤ))) = oNum c := by
    rw [hr10_eq]; simp [oNum, hc]
  have hrw_oD : w.read (.heap 10 ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ))) = oDen c := by
    rw [hr10_eq]; simp [oDen, hc]
  -- 1..9: Load `(oNum c, oDen c)` into `(r9, r10)` from `heap 10`
  have a1 : g 6 + g 6 = ((2 * c : ℕ) : ℤ) := by rw [hg6]; push_cast; ring
  have t1 := RegExec.add (inp := inp) hfd_le bg (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 6) (b := 6) (by decide) (by decide) (by decide) (by rw [a1]; exact h2c_bl)
  rw [a1] at t1; set u1 := Function.update g 8 ((2 * c : ℕ) : ℤ); have bu1 : RegBounded W u1 := bg.update (r := 8) (by decide) h2c_bl
  have t2 := RegExec.lit (inp := inp) hfd_le bu1 (sp_ok hm).1 (sp_ok hm).2 (dst := 15) (c := (T_max : ℤ)) (by decide) hT_bl
  set u2 := Function.update u1 15 (T_max : ℤ); have bu2 : RegBounded W u2 := bu1.update (r := 15) (by decide) hT_bl
  have m3 : u2 8 * u2 15 = (((2 * c) * T_max : ℕ) : ℤ) := by
    simp only [u2, u1, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15)]; push_cast; ring
  have t3 := RegExec.mul (inp := inp) hfd_le bu2 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [m3]; exact h2cT_bl)
  rw [m3] at t3; set u3 := Function.update u2 8 (((2 * c) * T_max : ℕ) : ℤ); have bu3 : RegBounded W u3 := bu2.update (r := 8) (by decide) h2cT_bl
  have t4 := RegExec.lit (inp := inp) hfd_le bu3 (sp_ok hm).1 (sp_ok hm).2 (dst := 15) (c := 1) (by decide) hl1
  set u4 := Function.update u3 15 1; have bu4 : RegBounded W u4 := bu3.update (r := 15) (by decide) hl1
  have a5 : u4 8 + u4 15 = ((((2 * c) * T_max + 1 : ℕ) : ℤ)) := by
    simp only [u4, u3, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15)]; push_cast; ring
  have t5 := RegExec.add (inp := inp) hfd_le bu4 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a5]; exact ha10_0_bl)
  rw [a5] at t5; set u5 := Function.update u4 8 ((((2 * c) * T_max + 1 : ℕ) : ℤ)); have bu5 : RegBounded W u5 := bu4.update (r := 8) (by decide) ha10_0_bl
  have hu5_8 : w.read (.heap 10 (u5 8)) = oNum c := by simp only [u5, Function.update_self]; exact hrw_oN
  have t6 := RegExec.load (inp := inp) hfd_le bu5 (sp_ok hm).1 (sp_ok hm).2 (dst := 9) (table := 10) (addr := 8) (by decide) (by decide) hn10 (by rw [hu5_8]; exact hoN_c.trans ho_W)
  rw [hu5_8] at t6; set u6 := Function.update u5 9 (oNum c); have bu6 : RegBounded W u6 := bu5.update (r := 9) (by decide) (hoN_c.trans ho_W)
  have t7 := RegExec.lit (inp := inp) hfd_le bu6 (sp_ok hm).1 (sp_ok hm).2 (dst := 15) (c := (T_max : ℤ)) (by decide) hT_bl
  set u7 := Function.update u6 15 (T_max : ℤ); have bu7 : RegBounded W u7 := bu6.update (r := 15) (by decide) hT_bl
  have a8 : u7 8 + u7 15 = ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ)) := by
    simp only [u7, u6, u5, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), Function.update_of_ne (by decide : (8 : ℕ) ≠ 9)]
    push_cast; ring
  have t8 := RegExec.add (inp := inp) hfd_le bu7 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a8]; exact ha10_1_bl)
  rw [a8] at t8; set u8 := Function.update u7 8 ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ)); have bu8 : RegBounded W u8 := bu7.update (r := 8) (by decide) ha10_1_bl
  have hu8_8 : w.read (.heap 10 (u8 8)) = oDen c := by simp only [u8, Function.update_self]; exact hrw_oD
  have t9 := RegExec.load (inp := inp) hfd_le bu8 (sp_ok hm).1 (sp_ok hm).2 (dst := 10) (table := 10) (addr := 8) (by decide) (by decide) hn10 (by rw [hu8_8]; exact hoD_c.trans ho_W)
  rw [hu8_8] at t9; set u9 := Function.update u8 10 (oDen c); have bu9 : RegBounded W u9 := bu8.update (r := 10) (by decide) (hoD_c.trans ho_W)
  -- 10..19: Store `(oNum c, oDen c)` into `heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 0/1))`
  have t10 := RegExec.lit (inp := inp) hfd_le bu9 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (c := (nodeStride : ℤ)) (by decide) hstride_bl
  set u10 := Function.update u9 8 (nodeStride : ℤ); have bu10 : RegBounded W u10 := bu9.update (r := 8) (by decide) hstride_bl
  have m11 : u10 0 * u10 8 = ((j * nodeStride : ℕ) : ℤ) := by
    simp only [u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, Function.update_self,
      Function.update_of_ne (by decide : (0 : ℕ) ≠ 8), Function.update_of_ne (by decide : (0 : ℕ) ≠ 10),
      Function.update_of_ne (by decide : (0 : ℕ) ≠ 15), Function.update_of_ne (by decide : (0 : ℕ) ≠ 9), hg0]
    push_cast; ring
  have t11 := RegExec.mul (inp := inp) hfd_le bu10 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 0) (b := 8) (by decide) (by decide) (by decide) (by rw [m11]; exact hjs_bl)
  rw [m11] at t11; set u11 := Function.update u10 8 ((j * nodeStride : ℕ) : ℤ); have bu11 : RegBounded W u11 := bu10.update (r := 8) (by decide) hjs_bl
  have t12 := RegExec.lit (inp := inp) hfd_le bu11 (sp_ok hm).1 (sp_ok hm).2 (dst := 15) (c := 6) (by decide) hl6
  set u12 := Function.update u11 15 6; have bu12 : RegBounded W u12 := bu11.update (r := 15) (by decide) hl6
  have a13 : u12 8 + u12 15 = ((j * nodeStride + 6 : ℕ) : ℤ) := by
    simp only [u12, u11, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15)]; push_cast; ring
  have t13 := RegExec.add (inp := inp) hfd_le bu12 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a13]; exact hjs6_bl)
  rw [a13] at t13; set u13 := Function.update u12 8 ((j * nodeStride + 6 : ℕ) : ℤ); have bu13 : RegBounded W u13 := bu12.update (r := 8) (by decide) hjs6_bl
  have hu13_6 : u13 6 = (c : ℤ) := by simp [u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg6]
  have a14 : u13 8 + u13 6 = ((j * nodeStride + 6 + c : ℕ) : ℤ) := by
    simp only [u13, Function.update_self, hu13_6]; push_cast; ring
  have t14 := RegExec.add (inp := inp) hfd_le bu13 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 6) (by decide) (by decide) (by decide) (by rw [a14]; exact hjsc_bl)
  rw [a14] at t14; set u14 := Function.update u13 8 ((j * nodeStride + 6 + c : ℕ) : ℤ); have bu14 : RegBounded W u14 := bu13.update (r := 8) (by decide) hjsc_bl
  have a15 : u14 8 + u14 6 = nodeCellAddr nodeStride j (6 + 2 * c) := by
    simp only [u14, Function.update_self, Function.update_of_ne (by decide : (6 : ℕ) ≠ 8), hu13_6, nodeCellAddr]; push_cast; ring
  have t15 := RegExec.add (inp := inp) hfd_le bu14 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 6) (by decide) (by decide) (by decide) (by rw [a15]; exact hno0_bl)
  rw [a15] at t15; set u15 := Function.update u14 8 (nodeCellAddr nodeStride j (6 + 2 * c)); have bu15 : RegBounded W u15 := bu14.update (r := 8) (by decide) hno0_bl
  have hm1 := hm.write (hSub3 (6 + 2 * c) (by clear * - hc; omega)) (oNum c) hno0_loc (hoN_c.trans ho_W)
  have hu15_9 : u15 9 = oNum c := by simp [u15, u14, u13, u12, u11, u10, u9, u8, u7, u6]
  have t16 := RegExec.store (inp := inp) hfd_le bu15 (table := 3) (addr := 8) (val := 9) (by decide) (by decide) hn3
    (by simpa [u15, hu15_9] using (sp_ok hm1).1) (by simpa [u15, hu15_9] using (sp_ok hm1).2)
  have hw1 : w.write (.heap 3 (u15 8)) (u15 9) = w.write (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c))) (oNum c) := by simp only [u15, Function.update_self, hu15_9]
  rw [hw1] at t16; set w1 := w.write (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c))) (oNum c)
  have t17 := RegExec.lit (inp := inp) hfd_le bu15 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 15) (c := 1) (by decide) hl1
  set u16 := Function.update u15 15 1; have bu16 : RegBounded W u16 := bu15.update (r := 15) (by decide) hl1
  have a18 : u16 8 + u16 15 = nodeCellAddr nodeStride j (6 + 2 * c + 1) := by
    simp only [u16, u15, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), nodeCellAddr]; push_cast; ring
  have t18 := RegExec.add (inp := inp) hfd_le bu16 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a18]; exact hno1_bl)
  rw [a18] at t18; set u17 := Function.update u16 8 (nodeCellAddr nodeStride j (6 + 2 * c + 1)); have bu17 : RegBounded W u17 := bu16.update (r := 8) (by decide) hno1_bl
  have hm2 := hm1.write (hSub3 (6 + 2 * c + 1) (by clear * - hc; omega)) (oDen c) hno1_loc (hoD_c.trans ho_W)
  have hu17_10 : u17 10 = oDen c := by simp [u17, u16, u15, u14, u13, u12, u11, u10, u9]
  have t19 := RegExec.store (inp := inp) hfd_le bu17 (table := 3) (addr := 8) (val := 10) (by decide) (by decide) hn3
    (by simpa [u17, hu17_10] using (sp_ok hm2).1) (by simpa [u17, hu17_10] using (sp_ok hm2).2)
  have hw2 : w1.write (.heap 3 (u17 8)) (u17 10) = w1.write (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1))) (oDen c) := by simp only [u17, Function.update_self, hu17_10]
  rw [hw2] at t19; set w2 := w1.write (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1))) (oDen c)
  -- 20..24: `(r11, r12) := (0, 1); accumSqDiffRegs; r6 := r6 + 1`
  have t20 := RegExec.lit (inp := inp) hfd_le bu17 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 11) (c := 0) (by decide) hl0
  set u18 := Function.update u17 11 0; have bu18 : RegBounded W u18 := bu17.update (r := 11) (by decide) hl0
  have t21 := RegExec.lit (inp := inp) hfd_le bu18 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 12) (c := 1) (by decide) hl1
  set u19 := Function.update u18 12 1; have bu19 : RegBounded W u19 := bu18.update (r := 12) (by decide) hl1
  have hW_acc : d * (2 * (B_cert + 2) + 3) + 20 ≤ W := by
    have hm : d * (2 * (B_cert + 2) + 3) ≤ (d + 1) * (2 * B_cert + 8) :=
      Nat.mul_le_mul (by clear * -; omega) (by clear * -; omega)
    clear * - hm hW; omega
  have hu19_3 : u19 3 = g 3 := by simp [u19, u18, u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1]
  have hu19_4 : u19 4 = g 4 := by simp [u19, u18, u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1]
  obtain ⟨u20, t22, bu20, hu20_3, hu20_4, hb20_3, hb20_4, hpres20⟩ :=
    exec_accumSqDiffRegs (inp := inp) (fd := fd) hfd_le (sp_ok hm2).1 (sp_ok hm2).2
      (pNum := oNum) (pDen := oDen) (qNum := zNum) (qDen := zDen)
      (B_p := B_cert) (B_q := 2) (c := c)
      hBc1 (by decide) hc hW_acc
      hoN_c hoD_c (by dsimp [zNum]; decide) (by dsimp [zDen]; decide) bu19
      (by simp [u19, u18, hu15_9, u17, u16])
      (by simp [u19, u18, hu17_10])
      (by simp [u19, u18, zNum])
      (by simp [u19, zDen])
      (hu19_3.trans hg3_eq) (hu19_4.trans hg4_eq)
      (by rw [hu19_3]; exact hg3_bl) (by rw [hu19_4]; exact hg4_bl)
  have t23 := RegExec.lit (inp := inp) hfd_le bu20 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 15) (c := 1) (by decide) hl1
  set u21 := Function.update u20 15 1; have bu21 : RegBounded W u21 := bu20.update (r := 15) (by decide) hl1
  have hu20_6 : u20 6 = (c : ℤ) := by
    rw [hpres20 6 (by decide) (by decide) (by decide)]
    simp [u19, u18, u17, u16, u15, u14, hu13_6]
  have a24 : u21 6 + u21 15 = ((c + 1 : ℕ) : ℤ) := by
    simp only [u21, Function.update_self, Function.update_of_ne (by decide : (6 : ℕ) ≠ 15), hu20_6]; push_cast; ring
  have t24 := RegExec.add (inp := inp) hfd_le bu21 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 6) (a := 6) (b := 15)
    (by decide) (by decide) (by decide) (by rw [a24]; exact hc1_bl)
  rw [a24] at t24; set u22 := Function.update u21 6 ((c + 1 : ℕ) : ℤ); have bu22 : RegBounded W u22 := bu21.update (r := 6) (by decide) hc1_bl
  have sAll := (t1.seq (t2.seq (t3.seq (t4.seq (t5.seq (t6.seq (t7.seq (t8.seq (t9.seq (t10.seq
    (t11.seq (t12.seq (t13.seq (t14.seq (t15.seq (t16.seq (t17.seq (t18.seq (t19.seq (t20.seq
    (t21.seq (t22.seq (t23.seq t24))))))))))))))))))))))).weaken
    rfl rfl (u₂ := 240) (b₂ := 56 * W * W) (by clear * -; omega)
    (by calc _ = 44 * (W * W) + (88 * W + 496) := by ring
          _ ≤ 44 * (W * W) + 12 * (W * W) := Nat.add_le_add_left (by linarith only [hW20, hWW]) _
          _ = 56 * W * W := by ring)
  refine ⟨w2, u22, sAll, hm2, bu22, ?_, ?_, ?_, ?_⟩
  · simp only [u22, u21, Function.update_of_ne (by decide : (0 : ℕ) ≠ 6), Function.update_of_ne (by decide : (0 : ℕ) ≠ 15)]
    rw [hpres20 0 (by decide) (by decide) (by decide)]
    simp [u19, u18, u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg0]
  · simp only [u22, u21, Function.update_of_ne (by decide : (5 : ℕ) ≠ 6), Function.update_of_ne (by decide : (5 : ℕ) ≠ 15)]
    rw [hpres20 5 (by decide) (by decide) (by decide)]
    simp [u19, u18, u17, u16, u15, u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg5]
  · intro loc hne
    have n0 : loc ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c)) := hne (6 + 2 * c) (by clear * - hc; omega)
    have n1 : loc ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1)) := hne (6 + 2 * c + 1) (by clear * - hc; omega)
    have u0 := hunch loc hne
    exact ⟨by simp [w2, w1, WordStore.write, n0, n1, u0.1],
           by simp [w2, w1, WordStore.write, Function.update_of_ne n1, Function.update_of_ne n0, u0.2]⟩
  · intro _
    have hu22_3 : u22 3 = u20 3 := by simp [u22, u21]
    have hu22_4 : u22 4 = u20 4 := by simp [u22, u21]
    refine ⟨by simp [u22], hu22_3.trans hu20_3, hu22_4.trans hu20_4,
      by rw [hu22_3]; exact hb20_3, by rw [hu22_4]; exact hb20_4,
      fun c' hc' hlt_c1 => ?_⟩
    have hc'_le : c' ≤ c := by clear * - hlt_c1; omega
    rcases eq_or_lt_of_le hc'_le with rfl | hlt
    · have hne01 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c')) : RAMCellLoc) ≠
          .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c' + 1)) := by
        intro h; injection h with _ ha
        have h_eq := (nodeCellAddr_inj (by clear * - hc hstride; omega) (by clear * - hc hstride; omega) ha).2
        clear * - h_eq; omega
      exact ⟨by simp only [w2, w1]; rw [wordStore_read_write_ne _ hne01]; simp [oNum, hc],
             by simp [w2, oDen, hc]⟩
    · have hne0 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c')) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c)) := by
        intro h; injection h with _ ha
        have h_eq := (nodeCellAddr_inj (by clear * - hc' hstride; omega) (by clear * - hc hstride; omega) ha).2
        clear * - hlt h_eq; omega
      have hne1 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c')) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1)) := by
        intro h; injection h with _ ha
        have h_eq := (nodeCellAddr_inj (by clear * - hc' hstride; omega) (by clear * - hc hstride; omega) ha).2
        clear * - hlt h_eq; omega
      have hne2 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c' + 1)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c)) := by
        intro h; injection h with _ ha
        have h_eq := (nodeCellAddr_inj (by clear * - hc' hstride; omega) (by clear * - hc hstride; omega) ha).2
        clear * - hlt h_eq; omega
      have hne3 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c' + 1)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * c + 1)) := by
        intro h; injection h with _ ha
        have h_eq := (nodeCellAddr_inj (by clear * - hc' hstride; omega) (by clear * - hc hstride; omega) ha).2
        clear * - hlt h_eq; omega
      obtain ⟨hp0, hp1⟩ := hprev c' hc' hlt
      exact ⟨by simp only [w2, w1]; rw [wordStore_read_write_ne _ hne1, wordStore_read_write_ne _ hne0]; exact hp0,
             by simp only [w2, w1]; rw [wordStore_read_write_ne _ hne3, wordStore_read_write_ne _ hne2]; exact hp1⟩
end UL.C12StepC2
