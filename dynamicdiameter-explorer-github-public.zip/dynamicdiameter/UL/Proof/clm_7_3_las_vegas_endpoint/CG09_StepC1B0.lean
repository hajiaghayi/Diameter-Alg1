import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG09_StepC1B0a
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

def posDimStepC1Gather (d s₀_d L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 106)
  (.seq (rLoad 7 9 10)
  (.seq (rLit 10 10)
  (.seq (rLoad 5 0 10)
  (.seq (.ite (.intLt (.readLocal 7 (.lit 0)) (.readLocal 5 (.lit 0)))
          (posDimStepC1PopLtBranch L)
          (posDimStepC1PopEqBranch L))
  (.seq (rLit 10 106)
  (.seq (rLoad 7 9 10)
  (.seq (rLit 10 104)
  (.seq (rStore 9 10 7)
  (.seq (rLit 10 10)
  (.seq (rLoad 5 0 10)
  (.seq (rSub 5 5 7)
  (.seq (.repeatN (.readLocal 5 (.lit 0)) (teardownOneLevelRegs d s₀_d L))
        posDimStepC1CleanupScratchStmt))))))))))))

theorem exec_posDimStepC1Gather
    (h_del_wit : S_claim_A_2_deletion_witness)
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    (_hB1 : 1 ≤ B) (_hBc1 : 1 ≤ B_cert)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P' : DynamicPointSet d} (hwfP' : P'.WellFormed n)
    {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {qMap' : ℕ → Fin d → ℚ}
    {k : ℕ} (hk_le : k ≤ K_max)
    {vecNodes : Fin k → ChainNode d}
    {updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    (hupd_len : updatedNodes.length = k)
    {jStar : ℕ} (hjStar_le : jStar ≤ k)
    (hnoTrig_prefix : ∀ (j : ℕ) (hj : j < jStar),
      let v' := updatedNodes.get ⟨j, hupd_len ▸ lt_of_lt_of_le hj hjStar_le⟩
      (v'.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (v'.birthPool.card : ℝ) / 16)
    (hmb_suffix : ∀ (j : ℕ) (hj : j < k), jStar ≤ j →
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).birthPool.card ≤
        2 * ((chainInput ltCoords' vecNodes (activeLifetimes P')
              ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩).card + 1))
    {wsB : WordStore} {regsB : ℕ → ℤ}
    (hmodB : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsB)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hbndB : RegBounded W regsB)
    (hrk_B : wsB.read (.heap 0 10) = (k : ℤ))
    (hr106_B : wsB.read (.heap 9 106) = (jStar : ℤ))
    (hcoordsB : ActiveCoordsStored d L B P'.activeHandles qMap' wsB)
    (htree0B : TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsB)
    (htree1B : TreeStoredAt L 1
      ((chainInput ltCoords' vecNodes (activeLifetimes P') (Fin.last k)).image (handleOfLifetime P'))
      (fun _ => 0) (fun _ => 1) wsB)
    (hpreB : ∀ (j : ℕ) (hj : j < k),
      PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap'
        (chainInput ltCoords' vecNodes (activeLifetimes P') ⟨j, Nat.lt_succ_of_lt hj⟩)
        (updatedNodes.get ⟨j, hupd_len ▸ hj⟩) j wsB)
    (hemptyB : ∀ j : ℕ, k ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j wsB)
    (hclean58B : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7 ∨ t = 8) → ∀ z : ℤ,
      (.heap t z : RAMCellLoc) ∉ wsB.live)
    (hclean9B : ∀ z : ℤ, z ≠ 102 → z ≠ 103 → z ≠ 104 → z ≠ 105 → z ≠ 106 →
      (.heap 9 z : RAMCellLoc) ∉ wsB.live) :
    let S_new := chainInput ltCoords' vecNodes (activeLifetimes P')
    let R_jStar := S_new ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩
    let H_jStar := R_jStar.image (handleOfLifetime P')
    let M := H_jStar.card
    let prefixNodes := updatedNodes.take jStar
    ∃ wsC1 regsC1,
      RegExec inp fd W C_cell C_bit (posDimStepC1Gather d s₀_d L) wsB regsB wsC1 regsC1
        ((k + 1) * ((M + 1) * (3200 * L + 3000) + 24 * d + 1200))
        ((k + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsC1 ∧
      RegBounded W regsC1 ∧
      M = R_jStar.card ∧
      M ≤ n ∧ M < 2 ^ L ∧
      wsC1.read (.heap 0 0) = wsB.read (.heap 0 0) ∧
      wsC1.read (.heap 0 10) = (jStar : ℤ) ∧
      wsC1.read (.heap 9 110) = (M : ℤ) ∧
      (∀ idx < M, wsC1.read (.heap 8 (idx : ℤ)) = (minPopElem H_jStar idx : ℤ)) ∧
      (∀ idx < M, minPopElem H_jStar idx ∈ P'.activeHandles ∧ minPopElem H_jStar idx < 2 ^ L) ∧
      StrictMonoOn (minPopElem H_jStar) (Finset.range M : Set ℕ) ∧
      (Finset.range M).image (minPopElem H_jStar) = H_jStar ∧
      ActiveCoordsStored d L B P'.activeHandles qMap' wsC1 ∧
      TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsC1 ∧
      TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsC1 ∧
      (∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L 1 u f) : RAMCellLoc) ∉ wsC1.live) ∧
      (∀ (j : ℕ) (hj : j < jStar),
        LevelStoredInv n L B B_cert K_max P' ltCoords' qMap'
          (S_new ⟨j, Nat.lt_succ_of_lt (lt_of_lt_of_le hj hjStar_le)⟩)
          (prefixNodes.get ⟨j, by rw [List.length_take_of_le (hupd_len ▸ hjStar_le)]; exact hj⟩)
          j wsC1) ∧
      (∀ j : ℕ, jStar ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j wsC1) ∧
      (∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsC1.live) ∧
      (∀ z : ℤ, (∀ idx < M, z ≠ (idx : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsC1.live) ∧
      (∀ z : ℤ, z ≠ 110 → (.heap 9 z : RAMCellLoc) ∉ wsC1.live) := by
  intro S_new R_jStar H_jStar M prefixNodes
  obtain ⟨h2L, hn_2n, h2n_pow, _⟩ := clog_two_mul_bounds hn
  rw [← hL] at h2L h2n_pow
  have hL1 : 1 ≤ L := by clear * - h2L; omega
  have hn_lt_pow : n < 2 ^ L := lt_of_lt_of_le hn_2n h2n_pow
  have hn_pow : n ≤ 2 ^ L := Nat.le_of_lt hn_lt_pow
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hWW : 40 * W ≤ W * W := by nlinarith only [hW40]
  have hBr1 : 1 ≤ sqRadBitBound d B B_cert := by unfold sqRadBitBound; omega
  -- Cardinality and handle bounds for R_jStar / H_jStar
  have hR_sub : R_jStar ⊆ activeLifetimes P' := chainInput_subset_base _ _ _ _
  have hM_eq : M = R_jStar.card := card_image_handleOfLifetime_eq hwfP' hR_sub
  have hH_sub : H_jStar ⊆ P'.activeHandles := image_handleOfLifetime_subset_activeHandles hwfP' hR_sub
  have hact_card_le : (activeLifetimes P').card ≤ n :=
    Finset.card_image_le.trans hwfP'.1
  have hM_le_n : M ≤ n := by
    rw [hM_eq]
    exact (Finset.card_le_card hR_sub).trans hact_card_le
  have hM_lt_pow : M < 2 ^ L := lt_of_le_of_lt hM_le_n hn_lt_pow
  have hH_elem : ∀ idx < M, minPopElem H_jStar idx ∈ P'.activeHandles ∧ minPopElem H_jStar idx < 2 ^ L := by
    intro idx hidx
    have hm_H : minPopElem H_jStar idx ∈ H_jStar := (minPopElem_step hidx).2.2.2.1
    have hm_act : minPopElem H_jStar idx ∈ P'.activeHandles := hH_sub hm_H
    exact ⟨hm_act, (hcoordsB.hS _ hm_act).1⟩
  -- Initial TeardownableLevel for jStar ≤ j < k and LevelStoredInv for j < jStar
  have htdB : ∀ (j : ℕ) (hj : j < k), jStar ≤ j →
      TeardownableLevel d s₀_d L B B_cert j M wsB := by
    intro j hj hjS_j
    have hsub_j : S_new ⟨j, Nat.lt_succ_of_lt hj⟩ ⊆ R_jStar :=
      chainInput_anti_level ltCoords' vecNodes (activeLifetimes P') hjS_j
    have hSj_le : ((S_new ⟨j, Nat.lt_succ_of_lt hj⟩).image (handleOfLifetime P')).card ≤ M :=
      Finset.card_le_card (Finset.image_subset_image hsub_j)
    have hmb_j : (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).birthPool.card ≤ 2 * (M + 1) := by
      rw [hM_eq]; exact hmb_suffix j hj hjS_j
    exact (hpreB j hj).toTeardownableLevel hs₀1 hn_pow hSj_le hmb_j
  have hlvl_prefB : ∀ (j : ℕ) (hj : j < jStar),
      LevelStoredInv n L B B_cert K_max P' ltCoords' qMap'
        (S_new ⟨j, Nat.lt_succ_of_lt (lt_of_lt_of_le hj hjStar_le)⟩)
        (prefixNodes.get ⟨j, by rw [List.length_take_of_le (hupd_len ▸ hjStar_le)]; exact hj⟩)
        j wsB := by
    intro j hj
    have hj_k : j < k := lt_of_lt_of_le hj hjStar_le
    have hget_eq : prefixNodes.get ⟨j, by rw [List.length_take_of_le (hupd_len ▸ hjStar_le)]; exact hj⟩ =
        updatedNodes.get ⟨j, hupd_len ▸ hj_k⟩ := by
      simp [prefixNodes, List.get_eq_getElem, List.getElem_take]
    rw [hget_eq]
    exact (hpreB j hj_k).toLevelStoredInv h_del_wit hd1 hs₀1
      (chainInput_subset_base _ _ _ _) (hnoTrig_prefix j hj)
  -- Bit-length & space helpers
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hl2 : intBitLength (2 : ℤ) ≤ W := (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by omega)
  have hl10 : intBitLength (10 : ℤ) ≤ W := (show intBitLength (10 : ℤ) = 5 from by decide).trans_le (by omega)
  have hl102 : intBitLength (102 : ℤ) ≤ W := (show intBitLength (102 : ℤ) = 8 from by decide).trans_le (by omega)
  have hl103 : intBitLength (103 : ℤ) ≤ W := (show intBitLength (103 : ℤ) = 8 from by decide).trans_le (by omega)
  have hl104 : intBitLength (104 : ℤ) ≤ W := (show intBitLength (104 : ℤ) = 8 from by decide).trans_le (by omega)
  have hl105 : intBitLength (105 : ℤ) ≤ W := (show intBitLength (105 : ℤ) = 8 from by decide).trans_le (by omega)
  have hl106 : intBitLength (106 : ℤ) ≤ W := (show intBitLength (106 : ℤ) = 8 from by decide).trans_le (by omega)
  have hn0 : natBitLength 0 ≤ W := (show natBitLength 0 = 1 from by decide).trans_le (by omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by omega)
  have hloc0_10 : (RAMCellLoc.heap 0 10).bitLength ≤ W :=
    (show (RAMCellLoc.heap 0 10).bitLength = 6 from by decide).trans_le (by omega)
  have hloc9_104 : (RAMCellLoc.heap 9 104).bitLength ≤ W :=
    (show (RAMCellLoc.heap 9 104).bitLength = 12 from by decide).trans_le (by omega)
  have hk_bl : intBitLength (k : ℤ) ≤ W := j_bl_of_level (d := d) (L := L) (Nat.le_succ_of_le hk_le) (by clear * - hW; omega)
  have hjS_bl : intBitLength (jStar : ℤ) ≤ W :=
    j_bl_of_level (d := d) (L := L) (Nat.le_succ_of_le (le_trans hjStar_le hk_le)) (by clear * - hW; omega)
  have hdiff_bl : intBitLength (((k - jStar : ℕ) : ℤ)) ≤ W :=
    j_bl_of_level (d := d) (L := L) (Nat.le_succ_of_le (le_trans (Nat.sub_le k jStar) hk_le)) (by clear * - hW; omega)
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  -- Step G1 header: load jStar -> r7, k -> r5
  have g1_s1 := RegExec.lit (inp := inp) hfd_le hbndB (sp_ok hmodB).1 (sp_ok hmodB).2 (dst := 10) (c := 106) (by decide) hl106
  set u1 := Function.update regsB 10 106; have bu1 := hbndB.update (r := 10) (by decide) hl106
  have hu1_r : wsB.read (.heap 9 (u1 10)) = (jStar : ℤ) := by simp [u1, hr106_B]
  have g1_s2 := RegExec.load (inp := inp) hfd_le bu1 (sp_ok hmodB).1 (sp_ok hmodB).2 (dst := 7) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hu1_r]; exact hjS_bl)
  rw [hu1_r] at g1_s2
  set u2 := Function.update u1 7 (jStar : ℤ); have bu2 := bu1.update (r := 7) (by decide) hjS_bl
  have g1_s3 := RegExec.lit (inp := inp) hfd_le bu2 (sp_ok hmodB).1 (sp_ok hmodB).2 (dst := 10) (c := 10) (by decide) hl10
  set u3 := Function.update u2 10 10; have bu3 := bu2.update (r := 10) (by decide) hl10
  have hu3_r : wsB.read (.heap 0 (u3 10)) = (k : ℤ) := by simp [u3, hrk_B]
  have g1_s4 := RegExec.load (inp := inp) hfd_le bu3 (sp_ok hmodB).1 (sp_ok hmodB).2 (dst := 5) (table := 0) (addr := 10)
    (by decide) (by decide) hn0 (by rw [hu3_r]; exact hk_bl)
  rw [hu3_r] at g1_s4
  set u4 := Function.update u3 5 (k : ℤ); have bu4 := bu3.update (r := 5) (by decide) hk_bl
  -- Branch `.ite (.intLt r7 r5) ...`
  have hn111_B : (.heap 9 111 : RAMCellLoc) ∉ wsB.live :=
    hclean9B 111 (by decide) (by decide) (by decide) (by decide) (by decide)
  have hn112_B : (.heap 9 112 : RAMCellLoc) ∉ wsB.live :=
    hclean9B 112 (by decide) (by decide) (by decide) (by decide) (by decide)
  obtain ⟨wsG1, regsG1, g1_s5, hmodG1, bregsG1, hrG1_110, hbufG1, htr1_empG1, hemp1_G1, htdG1, hfrG1⟩ :=
    exec_posDimStepC1PopIte hL1 hW hfd_le hk_le hupd_len hjStar_le hmodB hcCeil hbCeil
      bu4 (by simp [u4, u3, u2]) (by simp [u4]) hn111_B hn112_B htree1B hpreB rfl htdB
  -- Step G2: store heap 9 104 := jStar, compute r5 := k - jStar, run teardown loop
  have hrG1_106 : wsG1.read (.heap 9 106) = (jStar : ℤ) :=
    (wordStore_read_congr (hfrG1 _ (not_in_treeSlice_of_table_ne (by decide) _)
      (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by decide) (fun _ _ h => by cases h))).trans hr106_B
  have hrG1_k : wsG1.read (.heap 0 10) = (k : ℤ) :=
    (wordStore_read_congr (hfrG1 _ (not_in_treeSlice_of_table_ne (by decide) _)
      (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by decide) (fun _ _ h => by cases h))).trans hrk_B
  have g2_s1 := RegExec.lit (inp := inp) hfd_le bregsG1 (sp_ok hmodG1).1 (sp_ok hmodG1).2 (dst := 10) (c := 106) (by decide) hl106
  set w1 := Function.update regsG1 10 106; have bw1 := bregsG1.update (r := 10) (by decide) hl106
  have hw1_r : wsG1.read (.heap 9 (w1 10)) = (jStar : ℤ) := by simp [w1, hrG1_106]
  have g2_s2 := RegExec.load (inp := inp) hfd_le bw1 (sp_ok hmodG1).1 (sp_ok hmodG1).2 (dst := 7) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hw1_r]; exact hjS_bl)
  rw [hw1_r] at g2_s2
  set w2 := Function.update w1 7 (jStar : ℤ); have bw2 := bw1.update (r := 7) (by decide) hjS_bl
  have g2_s3 := RegExec.lit (inp := inp) hfd_le bw2 (sp_ok hmodG1).1 (sp_ok hmodG1).2 (dst := 10) (c := 104) (by decide) hl104
  set w3 := Function.update w2 10 104; have bw3 := bw2.update (r := 10) (by decide) hl104
  set wsG2_0 := wsG1.write (.heap 9 104) (jStar : ℤ)
  have hmodG2_0 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsG2_0 :=
    hmodG1.write (mem_posDimWriteLocs_tab9 (i := 104) (by decide)) _ hloc9_104 hjS_bl
  have hwG2_0_eq : wsG1.write (.heap 9 (w3 10)) (w3 7) = wsG2_0 := by simp [wsG2_0, w3, w2]
  have g2_s4 := RegExec.store (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (wsHeap := wsG1) hfd_le bw3 (table := 9) (addr := 10) (val := 7) (by decide) (by decide) hn9
    (by rw [hwG2_0_eq]; exact (sp_ok hmodG2_0).1) (by rw [hwG2_0_eq]; exact (sp_ok hmodG2_0).2)
  rw [hwG2_0_eq] at g2_s4
  have hrG2_0_k : wsG2_0.read (.heap 0 10) = (k : ℤ) := by
    dsimp only [wsG2_0]
    rw [wordStore_read_write_ne _ (by decide)]
    exact hrG1_k
  have g2_s5 := RegExec.lit (inp := inp) hfd_le bw3 (sp_ok hmodG2_0).1 (sp_ok hmodG2_0).2 (dst := 10) (c := 10) (by decide) hl10
  set w5 := Function.update w3 10 10; have bw5 := bw3.update (r := 10) (by decide) hl10
  have hw5_r : wsG2_0.read (.heap 0 (w5 10)) = (k : ℤ) := by simp [w5, hrG2_0_k]
  have g2_s6 := RegExec.load (inp := inp) hfd_le bw5 (sp_ok hmodG2_0).1 (sp_ok hmodG2_0).2 (dst := 5) (table := 0) (addr := 10)
    (by decide) (by decide) hn0 (by rw [hw5_r]; exact hk_bl)
  rw [hw5_r] at g2_s6
  set w6 := Function.update w5 5 (k : ℤ); have bw6 := bw5.update (r := 5) (by decide) hk_bl
  have hsub_w6 : w6 5 - w6 7 = (((k - jStar : ℕ) : ℤ)) := by
    simp [w6, w5, w3, w2]; omega
  have g2_s7 := RegExec.sub (inp := inp) hfd_le bw6 (sp_ok hmodG2_0).1 (sp_ok hmodG2_0).2 (dst := 5) (a := 5) (b := 7)
    (by decide) (by decide) (by decide) (by rw [hsub_w6]; exact hdiff_bl)
  rw [hsub_w6] at g2_s7
  set w7 := Function.update w6 5 (((k - jStar : ℕ) : ℤ)); have bw7 := bw6.update (r := 5) (by decide) hdiff_bl
  -- Teardown loop induction for `m ≤ k - jStar`
  set N_td := k - jStar
  let TdLoopInv (m : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
    ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
    RegBounded W g ∧
    w.read (.heap 9 104) = (((jStar + m : ℕ) : ℤ)) ∧
    (.heap 9 111 : RAMCellLoc) ∉ w.live ∧
    (∀ i < m, EmptyLevelSlot d L (jStar + i) w) ∧
    (∀ (j : ℕ) (hj : j < k), jStar + m ≤ j → TeardownableLevel d s₀_d L B B_cert j M w) ∧
    (∀ loc : RAMCellLoc,
      loc ≠ .heap 9 104 →
      (∀ i < m,
        loc ∉ treeSliceLocs L (2 * (jStar + i) + 2) ∧
        loc ∉ treeSliceLocs L (2 * (jStar + i) + 3) ∧
        (∀ off < posNodeStride d L, loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) (jStar + i) off)) ∧
        (∀ h < 2 ^ L, loc ≠ .heap 4 ((((jStar + i) * 2 ^ L + h : ℕ) : ℤ)))) →
      (loc ∈ w.live ↔ loc ∈ wsG1.live) ∧ w.vals loc = wsG1.vals loc)
  have hTdLoop : ∀ m ≤ N_td, ∃ (wsSeq : ℕ → WordStore) (regSeq : ℕ → ℕ → ℤ),
      wsSeq 0 = wsG2_0 ∧ regSeq 0 = w7 ∧
      TdLoopInv m (wsSeq m) (regSeq m) ∧
      (∀ i < m, RegExec inp fd W C_cell C_bit (teardownOneLevelRegs d s₀_d L)
        (wsSeq i) (regSeq i) (wsSeq (i + 1)) (regSeq (i + 1))
        ((M + 1) * (2100 * L + 2000) + 24 * d + 800)
        (((M + 1) * (320 * L + 450) + 20 * d + 1000) * W * W)) := by
    intro m hm
    induction m with
    | zero =>
        refine ⟨fun _ => wsG2_0, fun _ => w7, rfl, rfl, ?_, fun i hi => absurd hi (Nat.not_lt_zero _)⟩
        have hn111_G20 : (.heap 9 111 : RAMCellLoc) ∉ wsG2_0.live := by
          simp only [wsG2_0, WordStore.write, Finset.mem_insert, show (RAMCellLoc.heap 9 111 ≠ .heap 9 104) by decide, false_or]
          rw [(hfrG1 (.heap 9 111) (not_in_treeSlice_of_table_ne (by decide) _)
            (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by decide) (fun _ _ h => by cases h)).1]
          exact hclean9B 111 (by decide) (by decide) (by decide) (by decide) (by decide)
        refine ⟨hmodG2_0, bw7,
          by simp [wsG2_0, WordStore.read, WordStore.write],
          hn111_G20,
          fun i hi => absurd hi (Nat.not_lt_zero _),
          fun j hj hjS_j => (htdG1 j hj (by omega)).unchanged
            (fun _ _ => by simp [wsG2_0, WordStore.write])
            (fun _ _ hm0 => by simpa [wsG2_0, WordStore.write] using hm0)
            (fun _ _ _ _ => by simp [wsG2_0, WordStore.write])
            (fun _ _ _ _ => by simp [wsG2_0, WordStore.write]),
          fun loc hn104 _ => by simp [wsG2_0, WordStore.write, hn104, Function.update_of_ne hn104]⟩
    | succ s ih =>
        have hs_lt : jStar + s < k := by clear * - hm hjStar_le; omega
        have hs_K : jStar + s ≤ K_max := le_trans (Nat.le_of_lt hs_lt) hk_le
        obtain ⟨wS, rS, hw0, hr0_eq, ⟨hm_s, bg_s, hr104_s, hn111_s, hemp_s, htd_s, hfr_s⟩, hsteps⟩ :=
          ih (Nat.le_of_succ_le hm)
        obtain ⟨wNext, gNext, hstep_s, hmN, bgN, hempN, hr104N, hn111N, hfrN⟩ :=
          exec_teardownOneLevelRegs hs₀1 hL1 hs_K hW hfd_le hm_s hcCeil hbCeil
            hr104_s hn111_s (htd_s (jStar + s) hs_lt le_rfl) bg_s
        refine ⟨fun i => if i ≤ s then wS i else wNext,
                fun i => if i ≤ s then rS i else gNext,
                by simp [hw0], by simp [hr0_eq], ?_, ?_⟩
        · simp only [show ¬ (s + 1 ≤ s) by omega, ↓reduceIte]
          have hns_pos : 0 < posNodeStride d L := by have := posNodeStride_ge_eight d L; omega
          refine ⟨hmN, bgN,
            by simpa [Nat.add_assoc] using hr104N,
            hn111N,
            fun i hi => ?_,
            fun j hj hj_lo => ?_,
            fun loc hn104 hall => ?_⟩
          · rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
            · have hne_j : jStar + i ≠ jStar + s := by omega
              exact (hemp_s i hlt).unchanged
                (fun off hoff hm_in => (hfrN _ (by intro hc; cases hc)
                  (not_in_treeSlice_of_table_ne (by decide) _)
                  (not_in_treeSlice_of_table_ne (by decide) _)
                  (fun off2 hoff2 hc => by injection hc with _ ha; exact hne_j (nodeCellAddr_inj hoff hoff2 ha).1)
                  ((fun _ _ hc => by cases hc))).1.mp hm_in)
                (fun h' hh' hm_in => (hfrN _ (by intro hc; cases hc)
                  (not_in_treeSlice_of_table_ne (by decide) _)
                  (not_in_treeSlice_of_table_ne (by decide) _)
                  ((fun _ _ hc => by cases hc))
                  (fun h2 hh2 hc => by
                    injection hc with _ ha
                    have hnat : (jStar + i) * 2 ^ L + h' = (jStar + s) * 2 ^ L + h2 := by exact_mod_cast ha
                    have h1 : (jStar + i + 1) * 2 ^ L ≤ (jStar + s) * 2 ^ L := Nat.mul_le_mul_right _ (by omega)
                    have h2 : (jStar + i) * 2 ^ L + h' < (jStar + i + 1) * 2 ^ L := by have : (jStar + i + 1) * 2 ^ L = (jStar + i) * 2 ^ L + 2 ^ L := (by ring); omega
                    omega)).1.mp hm_in)
                (fun u hu f hf hm_in => (hfrN _ (by intro hc; cases hc)
                  (not_in_treeSlice_of_tid_ne hu hf (by omega))
                  (not_in_treeSlice_of_tid_ne hu hf (by omega))
                  ((fun _ _ hc => by cases hc)) ((fun _ _ hc => by cases hc))).1.mp hm_in)
                (fun u hu f hf hm_in => (hfrN _ (by intro hc; cases hc)
                  (not_in_treeSlice_of_tid_ne hu hf (by omega))
                  (not_in_treeSlice_of_tid_ne hu hf (by omega))
                  ((fun _ _ hc => by cases hc)) ((fun _ _ hc => by cases hc))).1.mp hm_in)
            · exact hempN
          · have hne_j : j ≠ jStar + s := by omega
            exact (htd_s j hj (by omega)).unchanged
              (fun off hoff => hfrN _ (by intro hc; cases hc)
                (not_in_treeSlice_of_table_ne (by decide) _)
                (not_in_treeSlice_of_table_ne (by decide) _)
                (fun off2 hoff2 hc => by injection hc with _ ha; exact hne_j (nodeCellAddr_inj hoff hoff2 ha).1)
                ((fun _ _ hc => by cases hc)))
              (fun h' hh' hm_in => (hfrN _ (by intro hc; cases hc)
                (not_in_treeSlice_of_table_ne (by decide) _)
                (not_in_treeSlice_of_table_ne (by decide) _)
                ((fun _ _ hc => by cases hc))
                (fun h2 hh2 hc => by
                  injection hc with _ ha
                  have hnat : j * 2 ^ L + h' = (jStar + s) * 2 ^ L + h2 := by exact_mod_cast ha
                  have h1 : (jStar + s + 1) * 2 ^ L ≤ j * 2 ^ L := Nat.mul_le_mul_right _ (by omega)
                  have h2 : (jStar + s) * 2 ^ L + h2 < (jStar + s + 1) * 2 ^ L := by have : (jStar + s + 1) * 2 ^ L = (jStar + s) * 2 ^ L + 2 ^ L := (by ring); omega
                  omega)).1.mp hm_in)
              (fun u hu f hf => hfrN _ (by intro hc; cases hc)
                (not_in_treeSlice_of_tid_ne hu hf (by omega))
                (not_in_treeSlice_of_tid_ne hu hf (by omega))
                ((fun _ _ hc => by cases hc)) ((fun _ _ hc => by cases hc)))
              (fun u hu f hf => hfrN _ (by intro hc; cases hc)
                (not_in_treeSlice_of_tid_ne hu hf (by omega))
                (not_in_treeSlice_of_tid_ne hu hf (by omega))
                ((fun _ _ hc => by cases hc)) ((fun _ _ hc => by cases hc)))
          · obtain ⟨hn2_s, hn3_s, hnt3_s, hnt4_s⟩ := hall s (Nat.lt_succ_self s)
            have hN := hfrN loc hn104 hn2_s hn3_s hnt3_s hnt4_s
            have hS := hfr_s loc hn104 (fun i hi => hall i (Nat.lt_succ_of_lt hi))
            exact ⟨hN.1.trans hS.1, hN.2.trans hS.2⟩
        · intro i hi
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | heq
          · simp only [show i ≤ s by omega, show i + 1 ≤ s by omega, ↓reduceIte]
            exact hsteps i hlt
          · subst i
            simp only [le_rfl, show ¬ (s + 1 ≤ s) by omega, ↓reduceIte]
            exact hstep_s
  obtain ⟨wsSeq, regSeq, hws0, hreg0,
    ⟨hmodG2, bregsG2, _, _, hempG2_loop, _, hfrG2⟩, hstepsG2⟩ := hTdLoop N_td le_rfl
  have g2_s8 := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (cntReg := 5) (by decide) N_td wsSeq regSeq
    (by rw [hreg0]; simp [w7, N_td])
    (by rw [hreg0]; exact bw7) hstepsG2
  rw [hws0, hreg0] at g2_s8
  set wsG2 := wsSeq N_td
  set regsG2 := regSeq N_td
  -- Step G3: set heap 0 10 := jStar and free heap 9 102..106
  have hrG2_106 : wsG2.read (.heap 9 106) = (jStar : ℤ) :=
    (wordStore_read_congr (hfrG2 (.heap 9 106) (by decide)
      (fun _ _ => ⟨not_in_treeSlice_of_table_ne (by decide) _,
                   not_in_treeSlice_of_table_ne (by decide) _,
                   (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩))).trans hrG1_106
  have c1 := RegExec.lit (inp := inp) hfd_le bregsG2 (sp_ok hmodG2).1 (sp_ok hmodG2).2 (dst := 10) (c := 106) (by decide) hl106
  set z1 := Function.update regsG2 10 106; have bz1 := bregsG2.update (r := 10) (by decide) hl106
  have hz1_r : wsG2.read (.heap 9 (z1 10)) = (jStar : ℤ) := by simp [z1, hrG2_106]
  have c2 := RegExec.load (inp := inp) hfd_le bz1 (sp_ok hmodG2).1 (sp_ok hmodG2).2 (dst := 7) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hz1_r]; exact hjS_bl)
  rw [hz1_r] at c2
  set z2 := Function.update z1 7 (jStar : ℤ); have bz2 := bz1.update (r := 7) (by decide) hjS_bl
  have c3 := RegExec.lit (inp := inp) hfd_le bz2 (sp_ok hmodG2).1 (sp_ok hmodG2).2 (dst := 10) (c := 10) (by decide) hl10
  set z3 := Function.update z2 10 10; have bz3 := bz2.update (r := 10) (by decide) hl10
  set wsK := wsG2.write (.heap 0 10) (jStar : ℤ)
  have hmodK : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsK :=
    hmodG2.write (mem_posDimWriteLocs_tab0 (i := 10) (by decide)) _ hloc0_10 hjS_bl
  have hwK_eq : wsG2.write (.heap 0 (z3 10)) (z3 7) = wsK := by simp [wsK, z3, z2]
  have c4 := RegExec.store (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (wsHeap := wsG2) hfd_le bz3 (table := 0) (addr := 10) (val := 7) (by decide) (by decide) hn0
    (by rw [hwK_eq]; exact (sp_ok hmodK).1) (by rw [hwK_eq]; exact (sp_ok hmodK).2)
  rw [hwK_eq] at c4
  -- Free 102, 103, 104, 105, 106
  have c5 := RegExec.lit (inp := inp) hfd_le bz3 (sp_ok hmodK).1 (sp_ok hmodK).2 (dst := 10) (c := 102) (by decide) hl102
  set z5 := Function.update z3 10 102; have bz5 := bz3.update (r := 10) (by decide) hl102
  have c6 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsK) bz5 (table := 9) (addr := 10) (by decide) hn9
  set wsF1 := wsK.free (.heap 9 102)
  have hwF1 : wsK.free (.heap 9 (z5 10)) = wsF1 := by simp [wsF1, z5]
  rw [hwF1] at c6
  have hmodF1 := hmodK.free (mem_posDimWriteLocs_tab9 (i := 102) (by decide))
  have c7 := RegExec.lit (inp := inp) hfd_le bz5 (sp_ok hmodF1).1 (sp_ok hmodF1).2 (dst := 10) (c := 103) (by decide) hl103
  set z7 := Function.update z5 10 103; have bz7 := bz5.update (r := 10) (by decide) hl103
  have c8 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsF1) bz7 (table := 9) (addr := 10) (by decide) hn9
  set wsF2 := wsF1.free (.heap 9 103)
  have hwF2 : wsF1.free (.heap 9 (z7 10)) = wsF2 := by simp [wsF2, z7]
  rw [hwF2] at c8
  have hmodF2 := hmodF1.free (mem_posDimWriteLocs_tab9 (i := 103) (by decide))
  have c9 := RegExec.lit (inp := inp) hfd_le bz7 (sp_ok hmodF2).1 (sp_ok hmodF2).2 (dst := 10) (c := 104) (by decide) hl104
  set z9 := Function.update z7 10 104; have bz9 := bz7.update (r := 10) (by decide) hl104
  have c10 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsF2) bz9 (table := 9) (addr := 10) (by decide) hn9
  set wsF3 := wsF2.free (.heap 9 104)
  have hwF3 : wsF2.free (.heap 9 (z9 10)) = wsF3 := by simp [wsF3, z9]
  rw [hwF3] at c10
  have hmodF3 := hmodF2.free (mem_posDimWriteLocs_tab9 (i := 104) (by decide))
  have c11 := RegExec.lit (inp := inp) hfd_le bz9 (sp_ok hmodF3).1 (sp_ok hmodF3).2 (dst := 10) (c := 105) (by decide) hl105
  set z11 := Function.update z9 10 105; have bz11 := bz9.update (r := 10) (by decide) hl105
  have c12 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsF3) bz11 (table := 9) (addr := 10) (by decide) hn9
  set wsF4 := wsF3.free (.heap 9 105)
  have hwF4 : wsF3.free (.heap 9 (z11 10)) = wsF4 := by simp [wsF4, z11]
  rw [hwF4] at c12
  have hmodF4 := hmodF3.free (mem_posDimWriteLocs_tab9 (i := 105) (by decide))
  have c13 := RegExec.lit (inp := inp) hfd_le bz11 (sp_ok hmodF4).1 (sp_ok hmodF4).2 (dst := 10) (c := 106) (by decide) hl106
  set z13 := Function.update z11 10 106; have bz13 := bz11.update (r := 10) (by decide) hl106
  have c14 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsF4) bz13 (table := 9) (addr := 10) (by decide) hn9
  set wsC1 := wsF4.free (.heap 9 106)
  have hwC1 : wsF4.free (.heap 9 (z13 10)) = wsC1 := by simp [wsC1, z13]
  rw [hwC1] at c14
  have hmodC1 := hmodF4.free (mem_posDimWriteLocs_tab9 (i := 106) (by decide))
  -- Master frame lemma from wsG2 to wsC1
  have hfrC1_G2 : ∀ loc : RAMCellLoc,
      loc ≠ .heap 0 10 →
      loc ≠ .heap 9 102 → loc ≠ .heap 9 103 → loc ≠ .heap 9 104 → loc ≠ .heap 9 105 → loc ≠ .heap 9 106 →
      (loc ∈ wsC1.live ↔ loc ∈ wsG2.live) ∧ wsC1.vals loc = wsG2.vals loc := by
    intro loc h010 h102 h103 h104 h105 h106
    simp [wsC1, wsF4, wsF3, wsF2, wsF1, wsK, WordStore.free, WordStore.write,
      h010, h102, h103, h104, h105, h106,
      Function.update_of_ne h010, Function.update_of_ne h102, Function.update_of_ne h103,
      Function.update_of_ne h104, Function.update_of_ne h105, Function.update_of_ne h106]
  have hfrC1_t : ∀ (t : ℕ) (ht : t ≠ 0 ∧ t ≠ 9) (z : ℤ),
      ((.heap t z : RAMCellLoc) ∈ wsC1.live ↔ (.heap t z : RAMCellLoc) ∈ wsG2.live) ∧
      wsC1.vals (.heap t z) = wsG2.vals (.heap t z) := fun t ht z =>
    hfrC1_G2 _ (fun h => by injection h with e; exact ht.1 e)
      (fun h => by injection h with e; exact ht.2 e)
      (fun h => by injection h with e; exact ht.2 e)
      (fun h => by injection h with e; exact ht.2 e)
      (fun h => by injection h with e; exact ht.2 e)
      (fun h => by injection h with e; exact ht.2 e)
  -- Assemble all postconditions on wsC1
  have hrC1_00 : wsC1.read (.heap 0 0) = wsB.read (.heap 0 0) := by
    have eA := hfrC1_G2 (.heap 0 0) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    have eB := hfrG2 (.heap 0 0) (by decide) (fun _ _ => ⟨not_in_treeSlice_of_table_ne (by decide) _,
      not_in_treeSlice_of_table_ne (by decide) _, (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)
    have eC := hfrG1 (.heap 0 0) (not_in_treeSlice_of_table_ne (by decide) _)
      (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by decide) (fun _ _ hc => by cases hc)
    exact (wordStore_read_congr eA).trans ((wordStore_read_congr eB).trans (wordStore_read_congr eC))
  have hrC1_010 : wsC1.read (.heap 0 10) = (jStar : ℤ) := by
    dsimp only [wsC1, wsF4, wsF3, wsF2, wsF1, wsK]
    rw [wordStore_read_free_ne _ (by decide), wordStore_read_free_ne _ (by decide),
        wordStore_read_free_ne _ (by decide), wordStore_read_free_ne _ (by decide),
        wordStore_read_free_ne _ (by decide)]
    simp [WordStore.read, WordStore.write]
  have hrC1_110 : wsC1.read (.heap 9 110) = (M : ℤ) := by
    have eA := hfrC1_G2 (.heap 9 110) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    have eB := hfrG2 (.heap 9 110) (by decide) (fun _ _ => ⟨not_in_treeSlice_of_table_ne (by decide) _,
      not_in_treeSlice_of_table_ne (by decide) _, (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)
    exact (wordStore_read_congr eA).trans ((wordStore_read_congr eB).trans hrG1_110)
  have hbufC1 : ∀ idx < M, wsC1.read (.heap 8 (idx : ℤ)) = (minPopElem H_jStar idx : ℤ) := by
    intro idx hidx
    have eA := hfrC1_G2 (.heap 8 (idx : ℤ)) (by intro hc; cases hc) (by intro hc; cases hc)
      (by intro hc; cases hc) (by intro hc; cases hc) (by intro hc; cases hc) (by intro hc; cases hc)
    have eB := hfrG2 (.heap 8 (idx : ℤ)) (by intro hc; cases hc) (fun _ _ => ⟨not_in_treeSlice_of_table_ne (by decide) _,
      not_in_treeSlice_of_table_ne (by decide) _, (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)
    exact (wordStore_read_congr eA).trans ((wordStore_read_congr eB).trans (hbufG1 idx hidx))
  have hcoordsC1 : ActiveCoordsStored d L B P'.activeHandles qMap' wsC1 := by
    refine hcoordsB.unchanged (fun h' _ c _ f _ => ?_)
    have eA := hfrC1_t 1 ⟨by decide, by decide⟩ (coordCellAddr d h' c f)
    have eB := hfrG2 (.heap 1 (coordCellAddr d h' c f)) (by intro hc; cases hc)
      (fun _ _ => ⟨not_in_treeSlice_of_table_ne (by decide) _,
        not_in_treeSlice_of_table_ne (by decide) _, (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)
    have eC := hfrG1 (.heap 1 (coordCellAddr d h' c f)) (not_in_treeSlice_of_table_ne (by decide) _)
      (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by intro hc; cases hc) (fun _ _ hc => by cases hc)
    exact (wordStore_read_congr eA).trans ((wordStore_read_congr eB).trans (wordStore_read_congr eC))
  have htree0C1 : TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsC1 := by
    refine htree0B.unchanged (fun u hu f hf => ?_)
    have eA := hfrC1_t 2 ⟨by decide, by decide⟩ (treeCellAddr L 0 u f)
    have eB := hfrG2 (.heap 2 (treeCellAddr L 0 u f)) (by intro hc; cases hc)
      (fun _ _ => ⟨not_in_treeSlice_of_tid_ne hu hf (by omega),
        not_in_treeSlice_of_tid_ne hu hf (by omega), (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)
    have eC := hfrG1 (.heap 2 (treeCellAddr L 0 u f)) (not_in_treeSlice_of_tid_ne hu hf (by omega))
      (fun _ => not_in_treeSlice_of_tid_ne hu hf (by omega)) (by intro hc; cases hc) (fun _ _ hc => by cases hc)
    exact ⟨eA.1.trans (eB.1.trans eC.1), eA.2.trans (eB.2.trans eC.2)⟩
  have hemp1_C1 : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L 1 u f) : RAMCellLoc) ∉ wsC1.live := by
    intro u hu f hf
    have eA := hfrC1_t 2 ⟨by decide, by decide⟩ (treeCellAddr L 1 u f)
    have eB := hfrG2 (.heap 2 (treeCellAddr L 1 u f)) (by intro hc; cases hc)
      (fun _ _ => ⟨not_in_treeSlice_of_tid_ne hu hf (by omega),
        not_in_treeSlice_of_tid_ne hu hf (by omega), (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)
    rw [eA.1, eB.1]; exact hemp1_G1 u hu f hf
  have htree1C1 : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsC1 :=
    TreeStoredAt.empty L 1 _ _ hemp1_C1
  have hlvl_prefC1 : ∀ (j : ℕ) (hj : j < jStar),
      LevelStoredInv n L B B_cert K_max P' ltCoords' qMap'
        (S_new ⟨j, Nat.lt_succ_of_lt (lt_of_lt_of_le hj hjStar_le)⟩)
        (prefixNodes.get ⟨j, by rw [List.length_take_of_le (hupd_len ▸ hjStar_le)]; exact hj⟩)
        j wsC1 := by
    intro j hj
    have hns_pos : 0 < posNodeStride d L := by have := posNodeStride_ge_eight d L; omega
    refine (hlvl_prefB j hj).unchanged hmodB.wf hmodC1.wf (fun off hoff => ?_) (fun h' hh' => ?_)
      (fun u hu f hf => ?_) (fun u hu f hf => ?_)
    · have eA := hfrC1_t 3 ⟨by decide, by decide⟩ (nodeCellAddr (posNodeStride d L) j off)
      have eB := hfrG2 (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) (by intro hc; cases hc)
        (fun i _ => ⟨not_in_treeSlice_of_table_ne (by decide) _,
          not_in_treeSlice_of_table_ne (by decide) _,
          fun off2 hoff2 hc => by injection hc with _ ha; have heq := (nodeCellAddr_inj hoff hoff2 ha).1; omega,
          (fun _ _ hc => by cases hc)⟩)
      have eC := hfrG1 (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) (not_in_treeSlice_of_table_ne (by decide) _)
        (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by intro hc; cases hc) (fun _ _ hc => by cases hc)
      exact ⟨eA.1.trans (eB.1.trans eC.1), eA.2.trans (eB.2.trans eC.2)⟩
    · have eA := hfrC1_t 4 ⟨by decide, by decide⟩ (((j * 2 ^ L + h' : ℕ) : ℤ))
      have eB := hfrG2 (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ))) (by intro hc; cases hc)
        (fun i _ => ⟨not_in_treeSlice_of_table_ne (by decide) _,
          not_in_treeSlice_of_table_ne (by decide) _, (fun _ _ hc => by cases hc),
          fun h2 hh2 hc => by
            injection hc with _ ha
            have hnat : j * 2 ^ L + h' = (jStar + i) * 2 ^ L + h2 := by exact_mod_cast ha
            have h1 : (j + 1) * 2 ^ L ≤ (jStar + i) * 2 ^ L := Nat.mul_le_mul_right _ (by omega)
            have h2 : j * 2 ^ L + h' < (j + 1) * 2 ^ L := by have : (j + 1) * 2 ^ L = j * 2 ^ L + 2 ^ L := (by ring); omega
            omega⟩)
      have eC := hfrG1 (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ))) (not_in_treeSlice_of_table_ne (by decide) _)
        (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by intro hc; cases hc) (fun _ _ hc => by cases hc)
      exact ⟨eA.1.trans (eB.1.trans eC.1), eA.2.trans (eB.2.trans eC.2)⟩
    · have eA := hfrC1_t 2 ⟨by decide, by decide⟩ (treeCellAddr L (2 * j + 2) u f)
      have eB := hfrG2 (.heap 2 (treeCellAddr L (2 * j + 2) u f)) (by intro hc; cases hc)
        (fun i _ => ⟨not_in_treeSlice_of_tid_ne hu hf (by omega),
          not_in_treeSlice_of_tid_ne hu hf (by omega), (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)
      have eC := hfrG1 (.heap 2 (treeCellAddr L (2 * j + 2) u f)) (not_in_treeSlice_of_tid_ne hu hf (by omega))
        (fun _ => not_in_treeSlice_of_tid_ne hu hf (by omega)) (by intro hc; cases hc) (fun _ _ hc => by cases hc)
      exact ⟨eA.1.trans (eB.1.trans eC.1), eA.2.trans (eB.2.trans eC.2)⟩
    · have eA := hfrC1_t 2 ⟨by decide, by decide⟩ (treeCellAddr L (2 * j + 3) u f)
      have eB := hfrG2 (.heap 2 (treeCellAddr L (2 * j + 3) u f)) (by intro hc; cases hc)
        (fun i _ => ⟨not_in_treeSlice_of_tid_ne hu hf (by omega),
          not_in_treeSlice_of_tid_ne hu hf (by omega), (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)
      have eC := hfrG1 (.heap 2 (treeCellAddr L (2 * j + 3) u f)) (not_in_treeSlice_of_tid_ne hu hf (by omega))
        (fun _ => not_in_treeSlice_of_tid_ne hu hf (by omega)) (by intro hc; cases hc) (fun _ _ hc => by cases hc)
      exact ⟨eA.1.trans (eB.1.trans eC.1), eA.2.trans (eB.2.trans eC.2)⟩
  have hemptyC1 : ∀ j : ℕ, jStar ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j wsC1 := by
    intro j hjS_j hj_K1
    by_cases hj_lt_k : j < k
    · have hi_lt : j - jStar < N_td := by dsimp [N_td]; omega
      have hj_eq : jStar + (j - jStar) = j := by omega
      have hemp_G2 : EmptyLevelSlot d L j wsG2 := hj_eq ▸ hempG2_loop (j - jStar) hi_lt
      exact hemp_G2.unchanged
        (fun _ _ hm => (hfrC1_t 3 ⟨(by decide), (by decide)⟩ _).1.mp hm)
        (fun _ _ hm => (hfrC1_t 4 ⟨(by decide), (by decide)⟩ _).1.mp hm)
        (fun _ _ _ _ hm => (hfrC1_t 2 ⟨(by decide), (by decide)⟩ _).1.mp hm)
        (fun _ _ _ _ hm => (hfrC1_t 2 ⟨(by decide), (by decide)⟩ _).1.mp hm)
    · have hk_le_j : k ≤ j := by omega
      exact (hemptyB j hk_le_j hj_K1).unchanged
        (fun off hoff hm => by
          have m1 := (hfrC1_t 3 ⟨(by decide), (by decide)⟩ _).1.mp hm
          have m2 := (hfrG2 _ (by intro hc; cases hc) (fun i hi => ⟨not_in_treeSlice_of_table_ne (by decide) _,
            not_in_treeSlice_of_table_ne (by decide) _,
            fun off2 hoff2 hc => by injection hc with _ ha; have heq := (nodeCellAddr_inj hoff hoff2 ha).1; dsimp [N_td] at hi; omega,
            (fun _ _ hc => by cases hc)⟩)).1.mp m1
          exact (hfrG1 _ (not_in_treeSlice_of_table_ne (by decide) _)
            (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by intro hc; cases hc) (fun _ _ hc => by cases hc)).1.mp m2)
        (fun h' hh' hm => by
          have m1 := (hfrC1_t 4 ⟨(by decide), (by decide)⟩ _).1.mp hm
          have m2 := (hfrG2 _ (by intro hc; cases hc) (fun i hi => ⟨not_in_treeSlice_of_table_ne (by decide) _,
            not_in_treeSlice_of_table_ne (by decide) _, (fun _ _ hc => by cases hc),
            fun h2 hh2 hc => by
              injection hc with _ ha
              have hnat : j * 2 ^ L + h' = (jStar + i) * 2 ^ L + h2 := by exact_mod_cast ha
              have h1 : (jStar + i + 1) * 2 ^ L ≤ j * 2 ^ L := Nat.mul_le_mul_right _ (by dsimp [N_td] at hi; omega)
              have h2 : (jStar + i) * 2 ^ L + h2 < (jStar + i + 1) * 2 ^ L := by have : (jStar + i + 1) * 2 ^ L = (jStar + i) * 2 ^ L + 2 ^ L := (by ring); omega
              omega⟩)).1.mp m1
          exact (hfrG1 _ (not_in_treeSlice_of_table_ne (by decide) _)
            (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by intro hc; cases hc) (fun _ _ hc => by cases hc)).1.mp m2)
        (fun u hu f hf hm => by
          have m1 := (hfrC1_t 2 ⟨(by decide), (by decide)⟩ _).1.mp hm
          have m2 := (hfrG2 _ (by intro hc; cases hc) (fun i hi => ⟨not_in_treeSlice_of_tid_ne hu hf (by dsimp [N_td] at hi; omega),
            not_in_treeSlice_of_tid_ne hu hf (by dsimp [N_td] at hi; omega),
            (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)).1.mp m1
          exact (hfrG1 _ (not_in_treeSlice_of_tid_ne hu hf (by omega))
            (fun hlt => not_in_treeSlice_of_tid_ne hu hf (by omega)) (by intro hc; cases hc) (fun _ _ hc => by cases hc)).1.mp m2)
        (fun u hu f hf hm => by
          have m1 := (hfrC1_t 2 ⟨(by decide), (by decide)⟩ _).1.mp hm
          have m2 := (hfrG2 _ (by intro hc; cases hc) (fun i hi => ⟨not_in_treeSlice_of_tid_ne hu hf (by dsimp [N_td] at hi; omega),
            not_in_treeSlice_of_tid_ne hu hf (by dsimp [N_td] at hi; omega),
            (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)).1.mp m1
          exact (hfrG1 _ (not_in_treeSlice_of_tid_ne hu hf (by omega))
            (fun hlt => not_in_treeSlice_of_tid_ne hu hf (by omega)) (by intro hc; cases hc) (fun _ _ hc => by cases hc)).1.mp m2)
  have hclean57_C1 : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsC1.live := by
    intro t ht z hm
    have ht_ne : t ≠ 0 ∧ t ≠ 2 ∧ t ≠ 3 ∧ t ≠ 4 ∧ t ≠ 8 ∧ t ≠ 9 := by
      rcases ht with rfl | rfl | rfl <;> decide
    have m1 := (hfrC1_G2 _ (fun h => by injection h with e; exact ht_ne.1 e)
      (fun h => by injection h with e; exact ht_ne.2.2.2.2.2 e)
      (fun h => by injection h with e; exact ht_ne.2.2.2.2.2 e)
      (fun h => by injection h with e; exact ht_ne.2.2.2.2.2 e)
      (fun h => by injection h with e; exact ht_ne.2.2.2.2.2 e)
      (fun h => by injection h with e; exact ht_ne.2.2.2.2.2 e)).1.mp hm
    have m2 := (hfrG2 _ (fun h => by injection h with e; exact ht_ne.2.2.2.2.2 e)
      (fun _ _ => ⟨not_in_treeSlice_of_table_ne ht_ne.2.1 z, not_in_treeSlice_of_table_ne ht_ne.2.1 z,
        fun _ _ h => by injection h with e; exact ht_ne.2.2.1 e,
        fun _ _ h => by injection h with e; exact ht_ne.2.2.2.1 e⟩)).1.mp m1
    have m3 := (hfrG1 _ (not_in_treeSlice_of_table_ne ht_ne.2.1 z)
      (fun _ => not_in_treeSlice_of_table_ne ht_ne.2.1 z)
      (fun h => by injection h with e; exact ht_ne.2.2.2.2.2 e)
      (fun _ _ h => by injection h with e; exact ht_ne.2.2.2.2.1 e)).1.mp m2
    rcases ht with rfl | rfl | rfl
    · exact hclean58B 5 (Or.inl rfl) z m3
    · exact hclean58B 6 (Or.inr (Or.inl rfl)) z m3
    · exact hclean58B 7 (Or.inr (Or.inr (Or.inl rfl))) z m3
  have hclean8_C1 : ∀ z : ℤ, (∀ idx < M, z ≠ (idx : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsC1.live := by
    intro z hne hm
    have m1 := (hfrC1_G2 _ (by intro hc; cases hc) (by intro hc; cases hc) (by intro hc; cases hc)
      (by intro hc; cases hc) (by intro hc; cases hc) (by intro hc; cases hc)).1.mp hm
    have m2 := (hfrG2 _ (by intro hc; cases hc) (fun _ _ => ⟨not_in_treeSlice_of_table_ne (by decide) z,
      not_in_treeSlice_of_table_ne (by decide) z, (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)).1.mp m1
    have m3 := (hfrG1 _ (not_in_treeSlice_of_table_ne (by decide) z)
      (fun _ => not_in_treeSlice_of_table_ne (by decide) z) (by intro hc; cases hc)
      (fun idx hidx hc => by injection hc with _ ez; exact hne idx hidx ez)).1.mp m2
    exact hclean58B 8 (Or.inr (Or.inr (Or.inr rfl))) z m3
  have hclean9_C1 : ∀ z : ℤ, z ≠ 110 → (.heap 9 z : RAMCellLoc) ∉ wsC1.live := by
    intro z hz110
    by_cases hz106 : z = 106
    · subst hz106; simp [wsC1, WordStore.free]
    · by_cases hz105 : z = 105
      · subst hz105; simp [wsC1, wsF4, WordStore.free]
      · by_cases hz104 : z = 104
        · subst hz104; simp [wsC1, wsF4, wsF3, WordStore.free]
        · by_cases hz103 : z = 103
          · subst hz103; simp [wsC1, wsF4, wsF3, wsF2, WordStore.free]
          · by_cases hz102 : z = 102
            · subst hz102; simp [wsC1, wsF4, wsF3, wsF2, wsF1, WordStore.free]
            · intro hm
              have m1 := (hfrC1_G2 _ (by intro hc; cases hc)
                (fun hc => by injection hc with _ e; exact hz102 e)
                (fun hc => by injection hc with _ e; exact hz103 e)
                (fun hc => by injection hc with _ e; exact hz104 e)
                (fun hc => by injection hc with _ e; exact hz105 e)
                (fun hc => by injection hc with _ e; exact hz106 e)).1.mp hm
              have m2 := (hfrG2 _ (fun hc => by injection hc with _ e; exact hz104 e)
                (fun _ _ => ⟨not_in_treeSlice_of_table_ne (by decide) z,
                  not_in_treeSlice_of_table_ne (by decide) z,
                  (fun _ _ hc => by cases hc), (fun _ _ hc => by cases hc)⟩)).1.mp m1
              have m3 := (hfrG1 _ (not_in_treeSlice_of_table_ne (by decide) z)
                (fun _ => not_in_treeSlice_of_table_ne (by decide) z)
                (fun hc => by injection hc with _ e; exact hz110 e)
                (fun _ _ hc => by cases hc)).1.mp m2
              exact hclean9B z hz102 hz103 hz104 hz105 hz106 m3
  refine ⟨wsC1, z13, ?_, hmodC1, bz13, hM_eq, hM_le_n, hM_lt_pow,
    hrC1_00, hrC1_010, hrC1_110, hbufC1, hH_elem,
    minPopElem_strictMonoOn H_jStar, image_minPopElem_eq H_jStar,
    hcoordsC1, htree0C1, htree1C1, hemp1_C1, hlvl_prefC1, hemptyC1,
    hclean57_C1, hclean8_C1, hclean9_C1⟩
  have hcleanup := c1.seq (c2.seq (c3.seq (c4.seq (c5.seq (c6.seq (c7.seq (c8.seq (c9.seq (c10.seq (c11.seq (c12.seq (c13.seq c14))))))))))))
  have htot := g1_s1.seq (g1_s2.seq (g1_s3.seq (g1_s4.seq (g1_s5.seq
    (g2_s1.seq (g2_s2.seq (g2_s3.seq (g2_s4.seq (g2_s5.seq (g2_s6.seq (g2_s7.seq (g2_s8.seq hcleanup))))))))))))
  have hNtd_le : N_td ≤ k := Nat.sub_le k jStar
  refine htot.weaken rfl rfl ?_ ?_
  · have htd_u : N_td * ((M + 1) * (2100 * L + 2000) + 24 * d + 800) ≤
        k * ((M + 1) * (3200 * L + 3000) + 24 * d + 1200) :=
      (Nat.mul_le_mul_right _ hNtd_le).trans (Nat.mul_le_mul_left k (by nlinarith only [hL1]))
    have h1 : (M + 1) * (900 * L + 700) + 800 ≤ 1 * ((M + 1) * (3200 * L + 3000) + 24 * d + 1200) := by
      nlinarith only [hL1]
    have hk1 : (k + 1) * ((M + 1) * (3200 * L + 3000) + 24 * d + 1200) =
        k * ((M + 1) * (3200 * L + 3000) + 24 * d + 1200) +
        1 * ((M + 1) * (3200 * L + 3000) + 24 * d + 1200) := by ring
    linarith
  · set WW := W * W
    have hov : (2 * W + 16) + (6 * W + 24) + (2 * W + 16) + (6 * W + 24) +
        (2 * W + 16) + (6 * W + 24) + (2 * W + 16) + (5 * W + 24) + (2 * W + 16) + (6 * W + 24) + (6 * W + 32) +
        (W + 12) +
        ((2 * W + 16) + ((6 * W + 24) + ((2 * W + 16) + ((5 * W + 24) +
         ((2 * W + 16) + ((3 * W + 16) + ((2 * W + 16) + ((3 * W + 16) +
          ((2 * W + 16) + ((3 * W + 16) + ((2 * W + 16) + ((3 * W + 16) + ((2 * W + 16) + (3 * W + 16)))))))))))))) ≤
        8 * WW := by
      dsimp [WW]; nlinarith only [hW40, hWW]
    have htd_coef : N_td * ((M + 1) * (320 * L + 450) + 20 * d + 1000) ≤
        k * ((M + 1) * (500 * L + 700) + 20 * d + 1400) :=
      (Nat.mul_le_mul_right _ hNtd_le).trans (Nat.mul_le_mul_left k (by nlinarith only [hL1]))
    have h1_coef : (M + 1) * (150 * L + 180) + 8 ≤
        1 * ((M + 1) * (500 * L + 700) + 20 * d + 1400) := by nlinarith only [hL1]
    have hsum_coef : (M + 1) * (150 * L + 180) + N_td * ((M + 1) * (320 * L + 450) + 20 * d + 1000) + 8 ≤
        (k + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) := by
      have hk1 : (k + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) =
          k * ((M + 1) * (500 * L + 700) + 20 * d + 1400) + 1 * ((M + 1) * (500 * L + 700) + 20 * d + 1400) := by ring
      linarith only [htd_coef, h1_coef, hk1]
    have hmul := Nat.mul_le_mul_right WW hsum_coef
    have h1 : ((M + 1) * (150 * L + 180) + N_td * ((M + 1) * (320 * L + 450) + 20 * d + 1000) + 8) * WW =
        8 * WW + (M + 1) * (150 * L + 180) * W * W + N_td * (((M + 1) * (320 * L + 450) + 20 * d + 1000) * W * W) := by
      dsimp [WW]; ring
    have h2 : ((k + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400)) * WW =
        (k + 1) * ((M + 1) * (500 * L + 700) + 20 * d + 1400) * W * W := by dsimp [WW]; ring
    linarith only [hov, hmul, h1, h2]

end UL.C12LVE
