import Mathlib
import UL.Stmt.lem_A_2
import UL.Stmt.claim_A_2_deletion_witness
import UL.Stmt.claim_C_3_sync_suffix
import UL.Proof.claim_C_3_sync_suffix.RaceV31_H3
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b3_StepBFull
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1c1_StepDMath
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open scoped ENNReal
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### 1. Canonical Rational Coordinate Extraction & History Replay -/

noncomputable def c12EuclideanToRat {d : ℕ} (pt : EuclideanSpace ℝ (Fin d)) : Fin d → ℚ :=
  (euclideanToRatPoint? pt).getD (fun _ => 0)

theorem c12EuclideanToRat_spec {d B : ℕ} {pt : EuclideanSpace ℝ (Fin d)}
    (hpt : pt ∈ RatAdmissiblePointSet d B) :
    ratPointToEuclidean (c12EuclideanToRat pt) = pt ∧
    RatPointBitBounded B (c12EuclideanToRat pt) := by
  obtain ⟨q, hsome, hb, heq⟩ := euclideanToRatPoint_of_admissible hpt
  simp [c12EuclideanToRat, hsome, hb, heq]

theorem c12EuclideanToRat_eq_of_ratPointToEuclidean {d : ℕ} {q : Fin d → ℚ}
    {pt : EuclideanSpace ℝ (Fin d)} (hq : ratPointToEuclidean q = pt) :
    c12EuclideanToRat pt = q := by
  have hex : ∃ q' : Fin d → ℚ, ratPointToEuclidean q' = pt := ⟨q, hq⟩
  have hsome : euclideanToRatPoint? pt = some (Classical.choose hex) := by
    unfold euclideanToRatPoint?
    rw [dif_pos hex]
  have heq : Classical.choose hex = q :=
    ratPointToEuclidean_injective ((Classical.choose_spec hex).trans hq.symm)
  simp [c12EuclideanToRat, hsome, heq]

noncomputable def c12ReplayStep {d : ℕ} (P : DynamicPointSet d) (e : StepHistoryEntry d) :
    DynamicPointSet d :=
  (applyDynamicUpdate P e.operation e.returnedHandle).getD P

noncomputable def c12ReplayHistory (d : ℕ) (hist : ExecutionHistory d) : DynamicPointSet d :=
  hist.foldl c12ReplayStep (DynamicPointSet.empty d)

theorem c12ReplayHistory_append {d : ℕ} (hist : ExecutionHistory d) (e : StepHistoryEntry d) :
    c12ReplayHistory d (hist ++ [e]) = c12ReplayStep (c12ReplayHistory d hist) e := by
  simp [c12ReplayHistory, List.foldl_append]

theorem c12ReplayHistory_syncStepsFrom {d L_leaf : ℕ} {NodeAux : Type} {α : ℝ}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    {ansPol : SyncCheckedAnswerPolicy d NodeAux}
    {adv : AdaptiveAdversary d} :
    ∀ (bitTrace : List (List Bool)) (cur out : SyncSchedulePrefixState d NodeAux),
      c12ReplayHistory d cur.history = cur.pointSet →
      runSyncScheduleStepsFrom L_leaf α ctor ansPol adv cur bitTrace = some out →
        c12ReplayHistory d out.history = out.pointSet
  | [], cur, out, hcur, hrun => by
      simp only [runSyncScheduleStepsFrom, Option.some.injEq] at hrun
      subst hrun; exact hcur
  | bs :: tail, cur, out, hcur, hrun => by
      simp only [runSyncScheduleStepsFrom] at hrun
      cases hstep : runSingleSyncScheduleStep L_leaf α ctor ansPol cur (adv cur.history) bs with
      | none => simp [hstep] at hrun
      | some nxt =>
          rw [hstep] at hrun
          apply c12ReplayHistory_syncStepsFrom tail nxt out _ hrun
          clear tail out hrun
          revert hstep
          unfold runSingleSyncScheduleStep
          cases hop : adv cur.history with
          | insert id ext pt =>
              dsimp only
              cases happ : applyDynamicUpdate cur.pointSet (.insert id ext pt)
                  (some (ansPol.allocHandle cur.pointSet.activeHandles)) with
              | none => intro h; cases h
              | some P' =>
                  dsimp only
                  split
                  · split
                    · intro h; cases h
                    · intro h; injection h with h; subst h
                      dsimp only; rw [c12ReplayHistory_append]; unfold c12ReplayStep; dsimp only
                      rw [hcur, happ]; rfl
                  · split
                    · intro h; injection h with h; subst h
                      dsimp only; rw [c12ReplayHistory_append]; unfold c12ReplayStep; dsimp only
                      rw [hcur, happ]; rfl
                    · intro h; cases h
          | delete id =>
              dsimp only
              cases happ : applyDynamicUpdate cur.pointSet (.delete id) none with
              | none => intro h; cases h
              | some P' =>
                  dsimp only
                  split
                  · split
                    · intro h; cases h
                    · intro h; injection h with h; subst h
                      dsimp only; rw [c12ReplayHistory_append]; unfold c12ReplayStep; dsimp only
                      rw [hcur, happ]; rfl
                  · split
                    · intro h; injection h with h; subst h
                      dsimp only; rw [c12ReplayHistory_append]; unfold c12ReplayStep; dsimp only
                      rw [hcur, happ]; rfl
                    · intro h; cases h

theorem c12ReplayHistory_syncSteps {d L_leaf : ℕ} {NodeAux : Type} {α : ℝ}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    {ansPol : SyncCheckedAnswerPolicy d NodeAux}
    {adv : AdaptiveAdversary d}
    {bitTrace : List (List Bool)} {out : SyncSchedulePrefixState d NodeAux}
    (hrun : runSyncScheduleSteps L_leaf α ctor ansPol adv bitTrace = some out) :
    c12ReplayHistory d out.history = out.pointSet :=
  c12ReplayHistory_syncStepsFrom bitTrace (initSyncSchedulePrefixState d NodeAux) out rfl hrun

/-! ### 2. Post-Step-A Handle Map `c12LtHandleAfter`, `c12EnumByKey`, and `minPopElem` Bridge -/

noncomputable def c12LtHandleAfter {d : ℕ} (P_prev : DynamicPointSet d) (lt : ℕ) : ℕ :=
  open Classical in
  if h : ∃ id ∈ P_prev.activeIds, P_prev.lifetimeOfId id = lt then
    P_prev.handleOfId (Classical.choose h)
  else if lt = P_prev.nextLifetime then
    mexHandle P_prev.activeHandles
  else
    0

theorem c12LtHandleAfter_eq_handleOfId {d n : ℕ} {P_prev P' : DynamicPointSet d}
    {op : DynamicUpdate d}
    (hwf : P_prev.WellFormed n)
    (happ : applyDynamicUpdate P_prev op
      (stepRetHandle mexHandle P_prev.activeHandles op) = some P') :
    ∀ id ∈ P'.activeIds, c12LtHandleAfter P_prev (P'.lifetimeOfId id) = P'.handleOfId id := by
  cases op with
  | insert idIns extName pt =>
      dsimp only [stepRetHandle] at happ
      simp only [applyDynamicUpdate] at happ
      split_ifs at happ with hcond
      simp only [Option.some.injEq] at happ; subst happ
      intro id hid
      simp only [Finset.mem_insert] at hid
      rcases hid with rfl | hid_old
      · simp only [Function.update_self]
        unfold c12LtHandleAfter
        have hnot : ¬ ∃ id' ∈ P_prev.activeIds, P_prev.lifetimeOfId id' = P_prev.nextLifetime := by
          rintro ⟨id', hid', heq⟩
          exact Nat.ne_of_lt (hwf.2.2.2.1 id' hid') heq
        rw [dif_neg hnot, if_pos rfl]
      · have hne : id ≠ idIns := fun h => hcond.1 (h ▸ hid_old)
        simp only [Function.update_of_ne hne]
        unfold c12LtHandleAfter
        have hex : ∃ id' ∈ P_prev.activeIds, P_prev.lifetimeOfId id' = P_prev.lifetimeOfId id :=
          ⟨id, hid_old, rfl⟩
        rw [dif_pos hex]
        have hch := Classical.choose_spec hex
        have hid_eq : Classical.choose hex = id := hwf.2.2.2.2 _ hch.1 _ hid_old hch.2
        rw [hid_eq]
  | delete idDel =>
      dsimp only [stepRetHandle] at happ
      simp only [applyDynamicUpdate] at happ
      split_ifs at happ with hmem
      simp only [Option.some.injEq] at happ; subst happ
      intro id hid
      obtain ⟨hne, hid_old⟩ := Finset.mem_erase.mp hid
      simp only [Function.update_of_ne hne]
      unfold c12LtHandleAfter
      have hex : ∃ id' ∈ P_prev.activeIds, P_prev.lifetimeOfId id' = P_prev.lifetimeOfId id :=
        ⟨id, hid_old, rfl⟩
      rw [dif_pos hex]
      have hch := Classical.choose_spec hex
      have hid_eq : Classical.choose hex = id := hwf.2.2.2.2 _ hch.1 _ hid_old hch.2
      rw [hid_eq]

theorem c12LtHandleAfter_eq_handleOfLifetime {d n : ℕ} {P_prev P' : DynamicPointSet d}
    {op : DynamicUpdate d}
    (hwf : P_prev.WellFormed n) (hwf' : P'.WellFormed n)
    (happ : applyDynamicUpdate P_prev op
      (stepRetHandle mexHandle P_prev.activeHandles op) = some P') :
    ∀ lt ∈ activeLifetimes P', c12LtHandleAfter P_prev lt = handleOfLifetime P' lt := by
  intro lt hlt
  rcases Finset.mem_image.mp hlt with ⟨id, hid, rfl⟩
  rw [c12LtHandleAfter_eq_handleOfId hwf happ id hid, handleOfLifetime_of_mem hwf' hid]

theorem c12LtHandleAfter_injOn {d n : ℕ} {P_prev P' : DynamicPointSet d}
    {op : DynamicUpdate d}
    (hwf : P_prev.WellFormed n) (hwf' : P'.WellFormed n)
    (happ : applyDynamicUpdate P_prev op
      (stepRetHandle mexHandle P_prev.activeHandles op) = some P')
    {R : Finset ℕ} (hsub : R ⊆ activeLifetimes P') :
    Set.InjOn (c12LtHandleAfter P_prev) (R : Set ℕ) := by
  intro lt₁ h₁ lt₂ h₂ heq
  rw [c12LtHandleAfter_eq_handleOfLifetime hwf hwf' happ lt₁ (hsub h₁),
      c12LtHandleAfter_eq_handleOfLifetime hwf hwf' happ lt₂ (hsub h₂)] at heq
  exact handleOfLifetime_injOn hwf' (hsub h₁) (hsub h₂) heq

private lemma minPopState_anti (S : Finset ℕ) :
    ∀ {a b : ℕ}, a ≤ b → minPopState S b ⊆ minPopState S a := by
  intro a b hab
  induction b with
  | zero =>
      have ha0 : a = 0 := Nat.eq_zero_of_le_zero hab
      subst ha0; exact Finset.Subset.rfl
  | succ m ih =>
      rcases Nat.eq_or_lt_of_le hab with rfl | hlt
      · exact Finset.Subset.rfl
      · have hstep : minPopState S (m + 1) ⊆ minPopState S m := by
          dsimp only [minPopState]
          split_ifs with hne
          · exact Finset.erase_subset _ _
          · exact Finset.empty_subset _
        exact hstep.trans (ih (Nat.lt_succ_iff.mp hlt))

theorem minPopElem_strictMono (S : Finset ℕ) {i j : ℕ}
    (hij : i < j) (hj : j < S.card) :
    minPopElem S i < minPopElem S j := by
  have hi : i < S.card := lt_trans hij hj
  obtain ⟨_, heq_i, _, _, _⟩ := minPopElem_step hi
  obtain ⟨_, _, hmem_j, _, _⟩ := minPopElem_step hj
  have hmem_i : minPopElem S j ∈ minPopState S i :=
    minPopState_anti S (Nat.le_of_lt hij) hmem_j
  have hle : minPopElem S i ≤ minPopElem S j := by
    rw [heq_i]
    exact Finset.min'_le _ _ hmem_i
  have hne : minPopElem S i ≠ minPopElem S j := by
    intro heq
    exact minPopElem_not_mem_later hi hij (heq ▸ hmem_j)
  exact lt_of_le_of_ne hle hne

private lemma strictMono_fin_id {m : ℕ} (g : Fin m → Fin m) (hg : StrictMono g) :
    ∀ i : Fin m, g i = i := by
  have hge : ∀ (k : ℕ) (hk : k < m), k ≤ (g ⟨k, hk⟩).val := by
    intro k
    induction k with
    | zero => intro _; exact Nat.zero_le _
    | succ k ih =>
        intro hk
        have hk0 : k < m := Nat.lt_of_succ_lt hk
        have hlt : (g ⟨k, hk0⟩).val < (g ⟨k + 1, hk⟩).val := hg (by show k < k + 1; omega)
        have hle := ih hk0
        omega
  have hle : ∀ (rem : ℕ) (k : ℕ) (hk : k < m), m - 1 - k ≤ rem → (g ⟨k, hk⟩).val ≤ k := by
    intro rem
    induction rem with
    | zero =>
        intro k hk hrem
        have hlt := (g ⟨k, hk⟩).isLt
        omega
    | succ rem ih =>
        intro k hk hrem
        by_cases hk_last : k + 1 < m
        · have hlt : (g ⟨k, hk⟩).val < (g ⟨k + 1, hk_last⟩).val := hg (by show k < k + 1; omega)
          have hi := ih (k + 1) hk_last (by omega)
          omega
        · have hlt := (g ⟨k, hk⟩).isLt
          omega
  intro i
  ext
  exact le_antisymm (hle (m - 1 - i.val) i.val i.isLt le_rfl) (hge i.val i.isLt)

theorem orderIsoOfFin_eq_minPopElem (S : Finset ℕ) (idx : Fin S.card) :
    (S.orderIsoOfFin rfl idx).1 = minPopElem S idx.val := by
  let iso := S.orderIsoOfFin rfl
  let f : Fin S.card → ↥S := fun i => ⟨minPopElem S i.val, (minPopElem_step i.isLt).2.2.2.1⟩
  have hf_mono : StrictMono f := fun a b hab => minPopElem_strictMono S hab b.isLt
  let g : Fin S.card → Fin S.card := fun i => iso.symm (f i)
  have hg_id := strictMono_fin_id g (iso.symm.strictMono.comp hf_mono) idx
  have hiso : f idx = iso idx := by
    have := congrArg iso hg_id
    simpa [g] using this
  exact (congrArg Subtype.val hiso).symm

private noncomputable def finsetImageEquiv (key : ℕ → ℕ) (P₀ : Finset ℕ)
    (hinj : Set.InjOn key (P₀ : Set ℕ)) : ↥P₀ ≃ ↥(P₀.image key) where
  toFun x := ⟨key x.1, Finset.mem_image_of_mem key x.2⟩
  invFun y :=
    have hex : ∃ lt ∈ P₀, key lt = y.1 := Finset.mem_image.mp y.2
    ⟨Classical.choose hex, (Classical.choose_spec hex).1⟩
  left_inv x := by
    ext
    dsimp only
    have hex : ∃ lt ∈ P₀, key lt = key x.1 := Finset.mem_image.mp (Finset.mem_image_of_mem key x.2)
    have hsp := Classical.choose_spec hex
    exact hinj hsp.1 x.2 hsp.2
  right_inv y := by
    ext
    dsimp only
    have hex : ∃ lt ∈ P₀, key lt = y.1 := Finset.mem_image.mp y.2
    exact (Classical.choose_spec hex).2

noncomputable def c12EnumByKey (key : ℕ → ℕ) (P₀ : Finset ℕ) : Fin P₀.card ≃ ↥P₀ :=
  open Classical in
  if hinj : Set.InjOn key (P₀ : Set ℕ) then
    let H₀ : Finset ℕ := P₀.image key
    have hcard : P₀.card = H₀.card := (Finset.card_image_of_injOn hinj).symm
    (Equiv.cast (congrArg Fin hcard)).trans
      (((H₀.orderIsoOfFin rfl).toEquiv).trans (finsetImageEquiv key P₀ hinj).symm)
  else
    (P₀.orderIsoOfFin rfl).toEquiv

private lemma fin_cast_val {a b : ℕ} (h : a = b) (i : Fin a) :
    (Equiv.cast (congrArg Fin h) i).val = i.val := by
  subst h; rfl

theorem c12EnumByKey_key_eq_minPopElem {key : ℕ → ℕ} {P₀ : Finset ℕ}
    (hinj : Set.InjOn key (P₀ : Set ℕ)) (idx : Fin P₀.card) :
    key (c12EnumByKey key P₀ idx).1 = minPopElem (P₀.image key) idx.val := by
  unfold c12EnumByKey
  rw [dif_pos hinj]
  set H₀ := P₀.image key
  have hcard : P₀.card = H₀.card := (Finset.card_image_of_injOn hinj).symm
  dsimp only [Equiv.trans_apply]
  let idx' : Fin H₀.card := Equiv.cast (congrArg Fin hcard) idx
  let y : ↥H₀ := H₀.orderIsoOfFin rfl idx'
  have hkey : key ((finsetImageEquiv key P₀ hinj).symm y).1 = y.1 := by
    have := Equiv.apply_symm_apply (finsetImageEquiv key P₀ hinj) y
    exact congrArg Subtype.val this
  change key ((finsetImageEquiv key P₀ hinj).symm y).1 = minPopElem H₀ idx.val
  rw [hkey]
  dsimp only [y]
  rw [orderIsoOfFin_eq_minPopElem H₀ idx', fin_cast_val hcard idx]

theorem c12EnumByKey_handle_and_coords {d n : ℕ}
    {P_prev P' : DynamicPointSet d} {op : DynamicUpdate d}
    {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)} {qMap' : ℕ → Fin d → ℚ}
    (hwf : P_prev.WellFormed n) (hwf' : P'.WellFormed n)
    (happ : applyDynamicUpdate P_prev op
      (stepRetHandle mexHandle P_prev.activeHandles op) = some P')
    (hlt_sync' : ∀ id ∈ P'.activeIds,
      ltCoords' (P'.lifetimeOfId id) = P'.coords id ∧
      P'.coords id = ratPointToEuclidean (qMap' (P'.handleOfId id)))
    {P₀ : Finset ℕ} (hsub : P₀ ⊆ activeLifetimes P') :
    let S_h : Finset ℕ := P₀.image (handleOfLifetime P')
    let enum : Fin P₀.card ≃ ↥P₀ := c12EnumByKey (c12LtHandleAfter P_prev) P₀
    S_h.card = P₀.card ∧
    (∀ idx : Fin P₀.card, handleOfLifetime P' (enum idx).1 = minPopElem S_h idx.val) ∧
    (∀ idx : Fin P₀.card, c12LtHandleAfter P_prev (enum idx).1 = minPopElem S_h idx.val) ∧
    (∀ idx : Fin P₀.card,
      c12EuclideanToRat (ltCoords' (enum idx).1) = qMap' (minPopElem S_h idx.val)) := by
  intro S_h enum
  have hinj := c12LtHandleAfter_injOn hwf hwf' happ hsub
  have himg_eq : P₀.image (c12LtHandleAfter P_prev) = S_h := by
    refine Finset.image_congr (fun lt hlt => ?_)
    exact c12LtHandleAfter_eq_handleOfLifetime hwf hwf' happ lt (hsub hlt)
  have hcard : S_h.card = P₀.card := by
    rw [← himg_eq]
    exact Finset.card_image_of_injOn hinj
  have hh_after : ∀ idx : Fin P₀.card, c12LtHandleAfter P_prev (enum idx).1 = minPopElem S_h idx.val := by
    intro idx
    rw [← himg_eq]
    exact c12EnumByKey_key_eq_minPopElem hinj idx
  have hh_lt : ∀ idx : Fin P₀.card, handleOfLifetime P' (enum idx).1 = minPopElem S_h idx.val := by
    intro idx
    rw [← c12LtHandleAfter_eq_handleOfLifetime hwf hwf' happ (enum idx).1 (hsub (enum idx).2)]
    exact hh_after idx
  refine ⟨hcard, hh_lt, hh_after, fun idx => ?_⟩
  have hact_lt : (enum idx).1 ∈ activeLifetimes P' := hsub (enum idx).2
  rcases Finset.mem_image.mp hact_lt with ⟨id, hid, hid_lt⟩
  obtain ⟨hs1, hs2⟩ := hlt_sync' id hid
  have hh_id : P'.handleOfId id = minPopElem S_h idx.val := by
    rw [← handleOfLifetime_of_mem hwf' hid, hid_lt, hh_lt idx]
  have hrat_eq : ratPointToEuclidean (qMap' (minPopElem S_h idx.val)) = ltCoords' (enum idx).1 := by
    rw [← hh_id, ← hs2, ← hs1, hid_lt]
  exact c12EuclideanToRat_eq_of_ratPointToEuclidean hrat_eq

/-! ### 3. Exact `V_num, V_den` Readout Formulas -/

def c12ExtractedVNumFromRead (d : ℕ) (rd : ℤ → ℤ) : ℤ :=
  let oNum : ℕ → ℤ := fun c => if c < d then rd (2 * (c : ℤ)) else 0
  let oDen : ℕ → ℤ := fun c => if c < d then rd (2 * (c : ℤ) + 1) else 1
  let sqNum : ℕ → ℤ := fun i => (oNum i * 1 - 0 * oDen i) * (oNum i * 1 - 0 * oDen i)
  let sqDen : ℕ → ℤ := fun i => (oDen i * 1) * (oDen i * 1)
  let p := ratSumPairs sqNum sqDen d
  let sN := rd (2 * (d : ℤ))
  let sD := rd (2 * (d : ℤ) + 1)
  sN * p.2 - p.1 * sD

def c12ExtractedVDenFromRead (d : ℕ) (rd : ℤ → ℤ) : ℤ :=
  let oNum : ℕ → ℤ := fun c => if c < d then rd (2 * (c : ℤ)) else 0
  let oDen : ℕ → ℤ := fun c => if c < d then rd (2 * (c : ℤ) + 1) else 1
  let sqNum : ℕ → ℤ := fun i => (oNum i * 1 - 0 * oDen i) * (oNum i * 1 - 0 * oDen i)
  let sqDen : ℕ → ℤ := fun i => (oDen i * 1) * (oDen i * 1)
  let p := ratSumPairs sqNum sqDen d
  let sD := rd (2 * (d : ℤ) + 1)
  sD * p.2

def c12ExtractedVNum (d : ℕ) (outA2 : BitRAMExecOutcome) : ℤ :=
  c12ExtractedVNumFromRead d (fun idx => outA2.words.read (.heap 1 idx))

def c12ExtractedVDen (d : ℕ) (outA2 : BitRAMExecOutcome) : ℤ :=
  c12ExtractedVDenFromRead d (fun idx => outA2.words.read (.heap 1 idx))

theorem c12ExtractedVar_spec {d B_cert : ℕ} {rd : ℤ → ℤ}
    {oRat : Fin d → ℚ} {sRat : ℚ}
    (ho : ∀ c : Fin d,
      let oN := rd (2 * (c.val : ℤ))
      let oD := rd (2 * (c.val : ℤ) + 1)
      1 ≤ oD ∧ oRat c = (oN : ℚ) / (oD : ℚ) ∧
      intBitLength oN ≤ B_cert ∧ intBitLength oD ≤ B_cert)
    (hs :
      let sN := rd (2 * (d : ℤ))
      let sD := rd (2 * (d : ℤ) + 1)
      1 ≤ sD ∧ sRat = (sN : ℚ) / (sD : ℚ) ∧
      intBitLength sN ≤ B_cert ∧ intBitLength sD ≤ B_cert) :
    let V_num := c12ExtractedVNumFromRead d rd
    let V_den := c12ExtractedVDenFromRead d rd
    1 ≤ V_den ∧
    ((V_num : ℝ) / (V_den : ℝ)) = liftVariance (ratPointToEuclidean oRat) (sRat : ℝ) ∧
    intBitLength V_num ≤ (d + 1) * (2 * B_cert + 7) + 4 ∧
    intBitLength V_den ≤ (d + 1) * (2 * B_cert + 7) + 4 := by
  intro V_num V_den
  let oNum : ℕ → ℤ := fun c => if c < d then rd (2 * (c : ℤ)) else 0
  let oDen : ℕ → ℤ := fun c => if c < d then rd (2 * (c : ℤ) + 1) else 1
  let zNum : ℕ → ℤ := fun _ => 0
  let zDen : ℕ → ℤ := fun _ => 1
  let sqNum : ℕ → ℤ := fun i => (oNum i * zDen i - zNum i * oDen i) * (oNum i * zDen i - zNum i * oDen i)
  let sqDen : ℕ → ℤ := fun i => (oDen i * zDen i) * (oDen i * zDen i)
  have hBt : 1 ≤ 2 * (B_cert + 2) + 2 := by omega
  have hbnds_term : ∀ i < d,
      1 ≤ sqDen i ∧ intBitLength (sqNum i) ≤ 2 * (B_cert + 2) + 2 ∧
      intBitLength (sqDen i) ≤ 2 * (B_cert + 2) + 2 := by
    intro i hi
    have ho_i := ho ⟨i, hi⟩; dsimp only at ho_i
    obtain ⟨hoD1, _, boN, boD⟩ := ho_i
    have hoDi : 1 ≤ oDen i := by simp only [oDen, if_pos hi]; exact hoD1
    have h12 : 1 ≤ oDen i * zDen i := by dsimp [zDen]; omega
    have h1 : 1 ≤ sqDen i := by dsimp [sqDen]; nlinarith only [h12]
    have hoN_b : intBitLength (oNum i) ≤ B_cert + 2 := by
      simp only [oNum, if_pos hi]; exact boN.trans (by omega)
    have hoD_b : intBitLength (oDen i) ≤ B_cert + 2 := by
      simp only [oDen, if_pos hi]; exact boD.trans (by omega)
    have bm1 : intBitLength (oNum i * zDen i) ≤ B_cert + 2 := by
      dsimp [zDen]; simpa using hoN_b
    have bdf : intBitLength (oNum i * zDen i - zNum i * oDen i) ≤ B_cert + 3 := by
      dsimp [zNum]; simpa using bm1.trans (Nat.le_succ _)
    have bsN : intBitLength (sqNum i) ≤ 2 * (B_cert + 2) + 2 := by
      have := (intBitLength_mul_le _ _).trans (Nat.add_le_add bdf bdf)
      dsimp [sqNum]; omega
    have bpd : intBitLength (oDen i * zDen i) ≤ B_cert + 2 := by
      dsimp [zDen]; simpa using hoD_b
    have bsD : intBitLength (sqDen i) ≤ 2 * (B_cert + 2) + 2 := by
      have := (intBitLength_mul_le _ _).trans (Nat.add_le_add bpd bpd)
      dsimp [sqDen]; omega
    exact ⟨h1, bsN, bsD⟩
  obtain ⟨hden_pos, _, hb_p1, hb_p2, _⟩ := ratSumPairs_spec hBt d hbnds_term
  set p := ratSumPairs sqNum sqDen d
  dsimp only at hs
  obtain ⟨hsD1, hs_eq, hsN_bl, hsD_bl⟩ := hs
  set sN := rd (2 * (d : ℤ))
  set sD := rd (2 * (d : ℤ) + 1)
  have hVD_pos : 1 ≤ V_den := by
    change 1 ≤ sD * p.2
    nlinarith only [hsD1, hden_pos]
  have hnorm_o := ratPoint_distSq_eq (p := oRat) (q := fun _ => 0)
    (pNum := oNum) (pDen := oDen) (qNum := zNum) (qDen := zDen)
    (fun c => by
      have ho_c := ho c; dsimp only at ho_c
      exact ⟨by simp [oDen, c.isLt]; exact ho_c.1,
             by simp only [oNum, oDen, c.isLt, ↓reduceIte, ho_c.2.1]; push_cast; rfl⟩)
    (fun _ => ⟨by dsimp [zDen]; omega, by simp [zNum, zDen]⟩)
  have hzero_euc : ratPointToEuclidean (fun _ : Fin d => (0 : ℚ)) = 0 := by
    ext c; simp [ratPointToEuclidean]
  rw [hzero_euc, sub_zero] at hnorm_o
  have hV_eq : ((V_num : ℝ) / (V_den : ℝ)) = liftVariance (ratPointToEuclidean oRat) (sRat : ℝ) := by
    unfold liftVariance
    change (((sN * p.2 - p.1 * sD : ℤ) : ℝ) / ((sD * p.2 : ℤ) : ℝ)) = _
    rw [← hnorm_o, hs_eq]
    have hsD_ne : (sD : ℝ) ≠ 0 := by exact_mod_cast (by omega : sD ≠ 0)
    have hp2_ne : (p.2 : ℝ) ≠ 0 := by exact_mod_cast (by omega : p.2 ≠ 0)
    push_cast
    rw [div_sub_div _ _ hsD_ne hp2_ne]
    ring
  have bm_sN4 : intBitLength (sN * p.2) ≤ B_cert + (d * (2 * (B_cert + 2) + 2) + 2) :=
    (intBitLength_mul_le _ _).trans (Nat.add_le_add hsN_bl hb_p2)
  have bm_3sD : intBitLength (p.1 * sD) ≤ (d * (2 * (B_cert + 2) + 3) + 2) + B_cert :=
    (intBitLength_mul_le _ _).trans (Nat.add_le_add hb_p1 hsD_bl)
  have hd_c2 : d * (2 * (B_cert + 2) + 2) ≤ d * (2 * B_cert + 7) :=
    Nat.mul_le_mul_left d (by omega)
  have hd_c3 : d * (2 * (B_cert + 2) + 3) = d * (2 * B_cert + 7) := by ring
  have hd_expand : (d + 1) * (2 * B_cert + 7) = d * (2 * B_cert + 7) + 2 * B_cert + 7 := by ring
  have hVN_bnd : intBitLength V_num ≤ (d + 1) * (2 * B_cert + 7) + 4 := by
    change intBitLength (sN * p.2 - p.1 * sD) ≤ _
    have hsub := intBitLength_sub_le_max (sN * p.2) (p.1 * sD)
    have hmax : max (intBitLength (sN * p.2)) (intBitLength (p.1 * sD)) ≤
        (d * (2 * B_cert + 7) + 2) + B_cert := by
      apply max_le
      · exact bm_sN4.trans (by omega)
      · exact bm_3sD.trans (by rw [hd_c3])
    rw [hd_expand]; omega
  have hVD_bnd : intBitLength V_den ≤ (d + 1) * (2 * B_cert + 7) + 4 := by
    change intBitLength (sD * p.2) ≤ _
    have hm := (intBitLength_mul_le sD p.2).trans (Nat.add_le_add hsD_bl hb_p2)
    rw [hd_expand]; omega
  exact ⟨hVD_pos, hV_eq, hVN_bnd, hVD_bnd⟩

end UL.C12LVE
