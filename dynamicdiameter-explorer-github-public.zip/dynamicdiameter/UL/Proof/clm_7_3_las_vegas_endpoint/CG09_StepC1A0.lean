import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b3_StepBFull
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Residual Monotonicity, Birth-Pool Bounds, and Canonical Handle Enumeration -/

theorem chainInput_anti_level {d : ℕ} {ι : Type*} [DecidableEq ι] {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    {j₁ j₂ : Fin (k + 1)} (h : j₁.val ≤ j₂.val) :
    chainInput pts nodes P j₂ ⊆ chainInput pts nodes P j₁ := by
  intro x hx
  rw [mem_chainInput_iff] at hx ⊢
  exact ⟨hx.1, fun i hi => hx.2 i (lt_of_lt_of_le hi h)⟩

theorem chainInput_take_eq {d : ℕ} {Aux : Type} {ι : Type*} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (nodes : List (SyncLiveChainNode d Aux))
    (P : Finset ι) {jStar j : ℕ} (hjS : jStar ≤ nodes.length) (hj : j ≤ jStar) :
    let nodesTake := nodes.take jStar
    have hlen : nodesTake.length = jStar := List.length_take_of_le hjS
    chainInput pts (fun i : Fin nodesTake.length => (nodesTake.get i).built.node) P
      ⟨j, by rw [hlen]; exact Nat.lt_succ_of_le hj⟩ =
    chainInput pts (fun i : Fin nodes.length => (nodes.get i).built.node) P
      ⟨j, Nat.lt_succ_of_le (le_trans hj hjS)⟩ := by
  intro nodesTake hlen
  ext x
  rw [mem_chainInput_iff, mem_chainInput_iff]
  have hget : ∀ (i : ℕ) (hi : i < j),
      (nodesTake.get ⟨i, by rw [hlen]; exact lt_of_lt_of_le hi hj⟩) =
        nodes.get ⟨i, lt_of_lt_of_le hi (le_trans hj hjS)⟩ := by
    intro i hi
    simp [nodesTake, List.get_eq_getElem, List.getElem_take]
  constructor <;> rintro ⟨hxP, hall⟩ <;> refine ⟨hxP, fun i hi => ?_⟩
  · have h := hall i hi; rw [hget i hi] at h; exact h
  · rw [hget i hi]; exact hall i hi

open Classical in
theorem hasNodeAge_birth_le_card_add {ι : Type*} {P₀ S : Finset ι} {age : ℕ}
    (h : HasNodeAge P₀ S age) :
    P₀.card ≤ S.card + age := by
  rcases h with ⟨seq, h0, hlast, hchg⟩
  have hind : ∀ (tv : ℕ) (htv : tv < age + 1), (seq 0).card ≤ (seq ⟨tv, htv⟩).card + tv := by
    intro tv
    induction tv with
    | zero => intro _; simp
    | succ m ih =>
        intro htv
        have hm_lt : m < age := Nat.lt_of_succ_lt_succ htv
        have ih_m := ih (Nat.lt_of_succ_lt htv)
        rcases hchg ⟨m, hm_lt⟩ with ⟨x, _, heq⟩ | ⟨x, hx, heq⟩
        · have hle_ins : (seq ⟨m, Nat.lt_of_succ_lt htv⟩).card ≤ (seq ⟨m + 1, htv⟩).card := by
            change (seq (⟨m, hm_lt⟩ : Fin age).castSucc).card ≤ (seq (⟨m, hm_lt⟩ : Fin age).succ).card
            rw [heq]
            exact Finset.card_le_card (Finset.subset_insert _ _)
          clear * - ih_m hle_ins; omega
        · have hle_er : (seq ⟨m, Nat.lt_of_succ_lt htv⟩).card ≤ (seq ⟨m + 1, htv⟩).card + 1 := by
            change (seq (⟨m, hm_lt⟩ : Fin age).castSucc).card ≤ (seq (⟨m, hm_lt⟩ : Fin age).succ).card + 1
            rw [heq, Finset.card_erase_add_one hx]
          clear * - ih_m hle_er; omega
  have hend := hind age (Nat.lt_succ_self age)
  have heqL : (⟨age, Nat.lt_succ_self age⟩ : Fin (age + 1)) = Fin.last age := rfl
  rw [heqL, h0, hlast] at hend
  exact hend

theorem birthPool_card_le_two_mul_of_age_le {ι : Type*} {s₀_d age : ℕ}
    (hs₀1 : 1 ≤ s₀_d) {P₀ S : Finset ι}
    (hrel : HasNodeAge P₀ S age)
    (hle : (age : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (P₀.card : ℝ) / 16) :
    P₀.card ≤ 2 * S.card := by
  have h1 := hasNodeAge_birth_le_card_add hrel
  have hs_ge1 : (1 : ℝ) ≤ (s₀_d : ℝ) := by exact_mod_cast hs₀1
  have h4s : (4 : ℝ) ≤ 4 * (s₀_d : ℝ) := by linarith
  have hfrac : 1 / (4 * (s₀_d : ℝ)) ≤ 1 / 4 := one_div_le_one_div_of_le (by norm_num) h4s
  have hprod : (1 / (4 * (s₀_d : ℝ))) * (P₀.card : ℝ) ≤ (1 / 4) * (P₀.card : ℝ) :=
    mul_le_mul_of_nonneg_right hfrac (Nat.cast_nonneg _)
  have h2age_r : (2 : ℝ) * (age : ℝ) ≤ (P₀.card : ℝ) := by linarith
  have h2age_r' : ((2 * age : ℕ) : ℝ) ≤ (P₀.card : ℝ) := by push_cast; exact h2age_r
  have h2age : 2 * age ≤ P₀.card := by exact_mod_cast h2age_r'
  clear * - h1 h2age; omega

theorem minPopState_anti (S : Finset ℕ) :
    ∀ {a b : ℕ}, a ≤ b → minPopState S b ⊆ minPopState S a := by
  intro a b hab
  induction hab with
  | refl => exact Finset.Subset.rfl
  | @step m _ ih =>
      have hstep : minPopState S (m + 1) ⊆ minPopState S m := by
        dsimp only [minPopState]
        split_ifs with hne
        · exact Finset.erase_subset _ _
        · exact Finset.empty_subset _
      exact hstep.trans ih

theorem minPopElem_strictMonoOn (S : Finset ℕ) :
    StrictMonoOn (minPopElem S) (Finset.range S.card : Set ℕ) := by
  intro i hi j hj hij
  have hi_lt : i < S.card := Finset.mem_range.mp hi
  have hj_lt : j < S.card := Finset.mem_range.mp hj
  obtain ⟨_, hi_eq, _, _, hi_next⟩ := minPopElem_step hi_lt
  obtain ⟨_, _, hj_mem_j, _, _⟩ := minPopElem_step hj_lt
  have hj_mem_i1 : minPopElem S j ∈ minPopState S (i + 1) :=
    minPopState_anti S (Nat.succ_le_of_lt hij) hj_mem_j
  rw [hi_next, Finset.mem_erase] at hj_mem_i1
  have hle : minPopElem S i ≤ minPopElem S j := by
    rw [hi_eq]
    exact Finset.min'_le _ _ hj_mem_i1.2
  exact lt_of_le_of_ne hle hj_mem_i1.1.symm

theorem wordStore_read_congr {ws₁ ws₂ : WordStore} {loc : RAMCellLoc}
    (h : (loc ∈ ws₂.live ↔ loc ∈ ws₁.live) ∧ ws₂.vals loc = ws₁.vals loc) :
    ws₂.read loc = ws₁.read loc := by
  simp only [WordStore.read, h.1, h.2]

theorem posNodeStride_ge_eight (d L : ℕ) : 8 + 2 * d ≤ posNodeStride d L := by
  unfold posNodeStride
  exact Nat.le_add_right (8 + 2 * d) (2 ^ L)

theorem card_image_handleOfLifetime_eq {d n : ℕ} {P : DynamicPointSet d}
    (hwf : P.WellFormed n) {R : Finset ℕ} (hR : R ⊆ activeLifetimes P) :
    (R.image (handleOfLifetime P)).card = R.card :=
  Finset.card_image_of_injOn ((handleOfLifetime_injOn hwf).mono hR)

theorem image_handleOfLifetime_subset_activeHandles {d n : ℕ} {P : DynamicPointSet d}
    (hwf : P.WellFormed n) {R : Finset ℕ} (hR : R ⊆ activeLifetimes P) :
    R.image (handleOfLifetime P) ⊆ P.activeHandles := by
  calc R.image (handleOfLifetime P)
    _ ⊆ (activeLifetimes P).image (handleOfLifetime P) := Finset.image_subset_image hR
    _ = P.activeHandles := image_handleOfLifetime_active hwf

theorem lifetimeOfId_idOfHandle_handleOfLifetime {d n : ℕ} {P : DynamicPointSet d}
    (hwf : P.WellFormed n) {lt : ℕ} (hlt : lt ∈ activeLifetimes P) :
    P.lifetimeOfId (P.idOfHandle (handleOfLifetime P lt)) = lt := by
  simp only [activeLifetimes, Finset.mem_image] at hlt
  rcases hlt with ⟨id, hid, rfl⟩
  rw [handleOfLifetime_of_mem hwf hid, (hwf.2.1 id hid).2]

/-- Canonical handle-sorted bijection `Fin R.card ≃ ↥R` for any `R ⊆ activeLifetimes P`,
matching `minPopElem (R.image (handleOfLifetime P))` at each index `0 .. R.card - 1`. -/
noncomputable def enumByHandleOrder {d n : ℕ} (P : DynamicPointSet d) (hwf : P.WellFormed n)
    (R : Finset ℕ) (hR : R ⊆ activeLifetimes P) : Fin R.card ≃ ↥R :=
  let H := R.image (handleOfLifetime P)
  have hcard : H.card = R.card := card_image_handleOfLifetime_eq hwf hR
  let f : Fin R.card → ↥H := fun idx =>
    ⟨minPopElem H idx.val, (minPopElem_step (hcard.symm ▸ idx.isLt)).2.2.2.1⟩
  have hf_inj : Function.Injective f := by
    intro a b hab
    have hv : minPopElem H a.val = minPopElem H b.val := Subtype.ext_iff.mp hab
    have hinj := minPopElem_injOn H
      (Finset.mem_coe.mpr (Finset.mem_range.mpr (hcard.symm ▸ a.isLt)))
      (Finset.mem_coe.mpr (Finset.mem_range.mpr (hcard.symm ▸ b.isLt))) hv
    exact Fin.ext hinj
  have hf_bij : Function.Bijective f :=
    (Fintype.bijective_iff_injective_and_card f).mpr
      ⟨hf_inj, by simp [Fintype.card_coe, hcard]⟩
  let g : ↥R → ↥H := fun x => ⟨handleOfLifetime P x.1, Finset.mem_image_of_mem _ x.2⟩
  have hg_inj : Function.Injective g := by
    intro a b hab
    have hv : handleOfLifetime P a.1 = handleOfLifetime P b.1 := Subtype.ext_iff.mp hab
    exact Subtype.ext ((handleOfLifetime_injOn hwf) (hR a.2) (hR b.2) hv)
  have hg_bij : Function.Bijective g :=
    (Fintype.bijective_iff_injective_and_card g).mpr
      ⟨hg_inj, by simp [Fintype.card_coe, hcard]⟩
  (Equiv.ofBijective f hf_bij).trans (Equiv.ofBijective g hg_bij).symm

theorem enumByHandleOrder_handle {d n : ℕ} (P : DynamicPointSet d) (hwf : P.WellFormed n)
    (R : Finset ℕ) (hR : R ⊆ activeLifetimes P) (idx : Fin R.card) :
    handleOfLifetime P (enumByHandleOrder P hwf R hR idx).1 =
      minPopElem (R.image (handleOfLifetime P)) idx.val := by
  dsimp only [enumByHandleOrder]
  set H := R.image (handleOfLifetime P)
  have hcard : H.card = R.card := card_image_handleOfLifetime_eq hwf hR
  let g : ↥R → ↥H := fun x => ⟨handleOfLifetime P x.1, Finset.mem_image_of_mem _ x.2⟩
  have hg_inj : Function.Injective g := by
    intro a b hab
    exact Subtype.ext ((handleOfLifetime_injOn hwf) (hR a.2) (hR b.2) (Subtype.ext_iff.mp hab))
  have hg_bij : Function.Bijective g :=
    (Fintype.bijective_iff_injective_and_card g).mpr ⟨hg_inj, by simp [Fintype.card_coe, hcard]⟩
  let eg := Equiv.ofBijective g hg_bij
  let y : ↥H := ⟨minPopElem H idx.val, (minPopElem_step (hcard.symm ▸ idx.isLt)).2.2.2.1⟩
  have happ : eg (eg.symm y) = y := eg.apply_symm_apply y
  exact congrArg Subtype.val happ

theorem enumByHandleOrder_val {d n : ℕ} (P : DynamicPointSet d) (hwf : P.WellFormed n)
    (R : Finset ℕ) (hR : R ⊆ activeLifetimes P) (idx : Fin R.card) :
    (enumByHandleOrder P hwf R hR idx).1 =
      P.lifetimeOfId (P.idOfHandle (minPopElem (R.image (handleOfLifetime P)) idx.val)) := by
  have hh := enumByHandleOrder_handle P hwf R hR idx
  rw [← hh, lifetimeOfId_idOfHandle_handleOfLifetime hwf (hR (enumByHandleOrder P hwf R hR idx).2)]

/-! ### 2. `TeardownableLevel` & Per-Level Teardown (`freeLevelTab4Regs`, `freeLevelTab3Regs`, `teardownOneLevelRegs`) -/

/-- Structural level condition sufficient to reclaim all live heap cells of level `j` in `O(M + d)` steps. -/
structure TeardownableLevel (d s₀_d L B B_cert j M_ceil : ℕ) (ws : WordStore) : Prop where
  tree_Sj : ∃ (S_tree : Finset ℕ) (rNum rDen : ℕ → ℤ),
    S_tree.card ≤ M_ceil ∧
    TreeStoredAt L (2 * j + 2) S_tree rNum rDen ws ∧
    (∀ h ∈ S_tree, h < 2 ^ L ∧
      intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧
      intBitLength (rDen h) ≤ sqRadBitBound d B B_cert)
  tree_intact : ∃ (B_tree : Finset ℕ),
    B_tree.card ≤ 2 * (M_ceil + 1) ∧
    TreeStoredAt L (2 * j + 3) B_tree (fun _ => 0) (fun _ => 1) ws
  tab34 : ∃ (k_blk : ℕ) (bh : Fin k_blk → Fin s₀_d → ℕ),
    k_blk * s₀_d ≤ 2 ^ L ∧
    k_blk * s₀_d ≤ 2 * (M_ceil + 1) ∧
    ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (k_blk : ℤ) ∧
    (∀ (b : Fin k_blk) (t : Fin s₀_d),
      bh b t < 2 ^ L ∧
      ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b.val * s₀_d + t.val)))) =
        (bh b t : ℤ)) ∧
    (∀ off : ℕ, 6 + 2 * d + k_blk * s₀_d ≤ off → off < posNodeStride d L →
      (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ ws.live) ∧
    (∀ h < 2 ^ L,
      (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ ws.live →
      ∃ (b : Fin k_blk) (t : Fin s₀_d), bh b t = h)

theorem PreTriggerLevelInv.toTeardownableLevel {d s₀_d n L B B_cert K_max M_ceil : ℕ}
    (hs₀1 : 1 ≤ s₀_d) (hn_pow : n ≤ 2 ^ L)
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {qMap : ℕ → Fin d → ℚ} {S_lt : Finset ℕ}
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)} {j : ℕ} {ws : WordStore}
    (hpre : PreTriggerLevelInv n L B B_cert K_max P ltCoords qMap S_lt v j ws)
    (hS_le : (S_lt.image (handleOfLifetime P)).card ≤ M_ceil)
    (hmb_le : v.birthPool.card ≤ 2 * (M_ceil + 1)) :
    TeardownableLevel d s₀_d L B B_cert j M_ceil ws := by
  refine ⟨?_, ?_, ?_⟩
  · rcases hpre.tree_Sj with ⟨rN, rD, htr, hrb⟩
    exact ⟨S_lt.image (handleOfLifetime P), rN, rD, hS_le, htr,
      fun h hh => ⟨htr.hS h hh, (hrb h hh).2.2.1, (hrb h hh).2.2.2⟩⟩
  · refine ⟨intactBlocksOf v P, ?_, hpre.tree_intact_raw⟩
    have hcard_le : (intactBlocksOf v P).card ≤ v.built.aux.k_blk := by
      unfold intactBlocksOf
      calc ((Finset.univ.filter _).image Fin.val).card
        _ ≤ (Finset.univ.filter _ : Finset (Fin v.built.aux.k_blk)).card := Finset.card_image_le
        _ ≤ (Finset.univ : Finset (Fin v.built.aux.k_blk)).card := Finset.card_le_card (Finset.filter_subset _ _)
        _ = v.built.aux.k_blk := Finset.card_fin _
    have hk_le : v.built.aux.k_blk ≤ v.built.aux.k_blk * s₀_d :=
      Nat.le_mul_of_pos_right _ hs₀1
    exact hcard_le.trans (hk_le.trans (hpre.hk_bounds.2.trans hmb_le))
  · refine ⟨v.built.aux.k_blk, v.built.aux.birthHandles,
      hpre.hk_bounds.2.trans (hpre.hm_bounds.2.trans hn_pow),
      hpre.hk_bounds.2.trans hmb_le,
      hpre.read_kblk,
      fun b t => ⟨hpre.hbh_lt b t, hpre.read_bh b t⟩,
      hpre.unused_tab3,
      fun h hh hlive => ?_⟩
    rcases hpre.tab4_spec h hh with ⟨b, t, _, hbh, _, _⟩ | ⟨_, hnot⟩
    · exact ⟨b, t, hbh⟩
    · exact absurd hlive hnot

theorem TeardownableLevel.unchanged {d s₀_d L B B_cert j M_ceil : ℕ}
    {ws₁ ws₂ : WordStore}
    (h : TeardownableLevel d s₀_d L B B_cert j M_ceil ws₁)
    (htab3 : ∀ off < posNodeStride d L,
      ((.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
        ws₁.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)))
    (htab4 : ∀ h' < 2 ^ L,
      (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ ws₂.live →
        (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ ws₁.live)
    (htree2 : ∀ u < 2 ^ (L + 1), ∀ f < 4,
      ((.heap 2 (treeCellAddr L (2 * j + 2) u f) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 2 (treeCellAddr L (2 * j + 2) u f) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 2 (treeCellAddr L (2 * j + 2) u f)) =
        ws₁.vals (.heap 2 (treeCellAddr L (2 * j + 2) u f)))
    (htree3 : ∀ u < 2 ^ (L + 1), ∀ f < 4,
      ((.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 2 (treeCellAddr L (2 * j + 3) u f)) =
        ws₁.vals (.heap 2 (treeCellAddr L (2 * j + 3) u f))) :
    TeardownableLevel d s₀_d L B B_cert j M_ceil ws₂ := by
  have hread3 : ∀ off < posNodeStride d L,
      ws₂.read (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
        ws₁.read (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) :=
    fun off hoff => wordStore_read_congr (htab3 off hoff)
  have hns_pos : 2 < posNodeStride d L := by have := posNodeStride_ge_eight d L; omega
  rcases h.tree_Sj with ⟨S_tree, rN, rD, hcS, htrS, hbS⟩
  rcases h.tree_intact with ⟨B_tree, hcB, htrB⟩
  rcases h.tab34 with ⟨k_blk, bh, hk_pow, hk_M, hr_k, hbh, hun3, hsp4⟩
  refine ⟨⟨S_tree, rN, rD, hcS, htrS.unchanged htree2, hbS⟩,
          ⟨B_tree, hcB, htrB.unchanged htree3⟩,
          ⟨k_blk, bh, hk_pow, hk_M, (hread3 2 hns_pos).trans hr_k,
            fun b t => ?_,
            fun off hlo hhi hm => hun3 off hlo hhi ((htab3 off hhi).1.mp hm),
            fun h' hh' hm => hsp4 h' hh' (htab4 h' hh' hm)⟩⟩
  have hbt_lt : b.val * s₀_d + t.val < k_blk * s₀_d := by
    have h1 : (b.val + 1) * s₀_d ≤ k_blk * s₀_d := Nat.mul_le_mul_right s₀_d b.isLt
    have h2 : b.val * s₀_d + t.val < (b.val + 1) * s₀_d := by rw [add_mul, one_mul]; omega
    exact lt_of_lt_of_le h2 h1
  have hoff_lt : 6 + 2 * d + (b.val * s₀_d + t.val) < posNodeStride d L := by
    unfold posNodeStride; clear * - hbt_lt hk_pow; omega
  exact ⟨(hbh b t).1, (hread3 _ hoff_lt).trans (hbh b t).2⟩

theorem TeardownableLevel.withEmptyTreeSj {d s₀_d L B B_cert j M_ceil : ℕ}
    {ws₁ ws₂ : WordStore}
    (h : TeardownableLevel d s₀_d L B B_cert j M_ceil ws₁)
    (htrEmpty : TreeStoredAt L (2 * j + 2) ∅ (fun _ => 0) (fun _ => 1) ws₂)
    (htab3 : ∀ off < posNodeStride d L,
      ((.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
        ws₁.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)))
    (htab4 : ∀ h' < 2 ^ L,
      (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ ws₂.live →
        (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ ws₁.live)
    (htree3 : ∀ u < 2 ^ (L + 1), ∀ f < 4,
      ((.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 2 (treeCellAddr L (2 * j + 3) u f)) =
        ws₁.vals (.heap 2 (treeCellAddr L (2 * j + 3) u f))) :
    TeardownableLevel d s₀_d L B B_cert j M_ceil ws₂ := by
  have hread3 : ∀ off < posNodeStride d L,
      ws₂.read (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
        ws₁.read (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) :=
    fun off hoff => wordStore_read_congr (htab3 off hoff)
  have hns_pos : 2 < posNodeStride d L := by have := posNodeStride_ge_eight d L; omega
  rcases h.tree_intact with ⟨B_tree, hcB, htrB⟩
  rcases h.tab34 with ⟨k_blk, bh, hk_pow, hk_M, hr_k, hbh, hun3, hsp4⟩
  refine ⟨⟨∅, fun _ => 0, fun _ => 1, Nat.zero_le _, htrEmpty,
            fun x hx => absurd hx (Finset.notMem_empty x)⟩,
          ⟨B_tree, hcB, htrB.unchanged htree3⟩,
          ⟨k_blk, bh, hk_pow, hk_M, (hread3 2 hns_pos).trans hr_k,
            fun b t => ?_,
            fun off hlo hhi hm => hun3 off hlo hhi ((htab3 off hhi).1.mp hm),
            fun h' hh' hm => hsp4 h' hh' (htab4 h' hh' hm)⟩⟩
  have hbt_lt : b.val * s₀_d + t.val < k_blk * s₀_d := by
    have h1 : (b.val + 1) * s₀_d ≤ k_blk * s₀_d := Nat.mul_le_mul_right s₀_d b.isLt
    have h2 : b.val * s₀_d + t.val < (b.val + 1) * s₀_d := by rw [add_mul, one_mul]; omega
    exact lt_of_lt_of_le h2 h1
  have hoff_lt : 6 + 2 * d + (b.val * s₀_d + t.val) < posNodeStride d L := by
    unfold posNodeStride; clear * - hbt_lt hk_pow; omega
  exact ⟨(hbh b t).1, (hread3 _ hoff_lt).trans (hbh b t).2⟩

def freeLevelTab4StepStmt : BitRAMStmt :=
  .seq (rLoad 8 3 6)
  (.seq (rAdd 9 7 8)
  (.seq (rFree 4 9)
  (.seq (rLit 8 0)
  (.seq (rLit 9 0)
        (rAdd 6 6 14)))))

def freeLevelTab4Regs (d s₀_d L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 104)
  (.seq (rLoad 0 9 10)
  (.seq (rLit 8 ((posNodeStride d L) : ℤ))
  (.seq (rMul 6 0 8)
  (.seq (rLit 14 2)
  (.seq (rAdd 8 6 14)
  (.seq (rLoad 5 3 8)
  (.seq (rLit 14 (s₀_d : ℤ))
  (.seq (rMul 5 5 14)
  (.seq (rLit 14 (((6 + 2 * d : ℕ) : ℤ)))
  (.seq (rAdd 6 6 14)
  (.seq (rLit 8 ((2 ^ L : ℕ) : ℤ))
  (.seq (rMul 7 0 8)
  (.seq (rLit 8 0)
  (.seq (rLit 9 0)
  (.seq (rLit 14 1)
        (.repeatN (.readLocal 5 (.lit 0)) freeLevelTab4StepStmt))))))))))))))))

theorem exec_freeLevelTab4Regs {d s₀_d L K_max W M_ceil j : ℕ}
    (hs₀1 : 1 ≤ s₀_d) (hj : j ≤ K_max)
    (hW : natBitLength ((K_max + 2) * posNodeStride d L) + natBitLength (64 * s₀_d + 1) + L + 24 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws : WordStore}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hr104 : ws.read (.heap 9 104) = (j : ℤ))
    {k_blk : ℕ} {bh : Fin k_blk → Fin s₀_d → ℕ}
    (hk_pow : k_blk * s₀_d ≤ 2 ^ L)
    (hk_M : k_blk * s₀_d ≤ 2 * (M_ceil + 1))
    (hr_k : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (k_blk : ℤ))
    (hbh : ∀ (b : Fin k_blk) (t : Fin s₀_d),
      bh b t < 2 ^ L ∧
      ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b.val * s₀_d + t.val)))) =
        (bh b t : ℤ))
    (hsp4 : ∀ h < 2 ^ L,
      (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ ws.live →
      ∃ (b : Fin k_blk) (t : Fin s₀_d), bh b t = h)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (freeLevelTab4Regs d s₀_d L) ws regs wsEnd regsEnd
        (68 * M_ceil + 260) ((80 * M_ceil + 340) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      (∀ h < 2 ^ L, (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ wsEnd.live) ∧
      (∀ loc : RAMCellLoc,
        (∀ h < 2 ^ L, loc ≠ .heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW24 : 24 ≤ W := by clear * - hW; omega
  have hWW : 24 * W ≤ W * W := by nlinarith only [hW24]
  have hp2_pos : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
  have hns_ge : 8 + 2 * d + 2 ^ L = (posNodeStride d L) := rfl
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hl2 : intBitLength (2 : ℤ) ≤ W := (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by omega)
  have hl104 : intBitLength (104 : ℤ) ≤ W := (show intBitLength (104 : ℤ) = 8 from by decide).trans_le (by omega)
  have hn3 : natBitLength 3 ≤ W := (show natBitLength 3 = 2 from by decide).trans_le (by omega)
  have hn4 : natBitLength 4 ≤ W := (show natBitLength 4 = 3 from by decide).trans_le (by omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by omega)
  have hj_bl : intBitLength (j : ℤ) ≤ W := j_bl_of_level (d := d) (L := L) (Nat.le_succ_of_le hj) (by clear * - hW; omega)
  have hns_bl : intBitLength ((posNodeStride d L) : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le (posNodeStride d L)
    have h2 : natBitLength (posNodeStride d L) ≤ natBitLength ((K_max + 2) * (posNodeStride d L)) :=
      natBitLength_mono (Nat.le_mul_of_pos_left _ (by omega))
    clear * - h1 h2 hW; omega
  have h62d_bl : intBitLength (((6 + 2 * d : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono (show 6 + 2 * d ≤ (posNodeStride d L) by clear * - hp2_pos hns_ge; omega)).trans hns_bl
  have hs₀_bl : intBitLength (s₀_d : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le s₀_d
    have h2 : natBitLength s₀_d ≤ natBitLength (64 * s₀_d + 1) := natBitLength_mono (by omega)
    clear * - h1 h2 hW; omega
  have hpow_bl : intBitLength ((2 ^ L : ℕ) : ℤ) ≤ W :=
    (nat_pow2_bitLength_le L).trans (by clear * - hW; omega)
  have hk_le_pow : k_blk ≤ 2 ^ L := le_trans (Nat.le_mul_of_pos_right _ hs₀1) hk_pow
  have hk_bl : intBitLength (k_blk : ℤ) ≤ W :=
    (intBitLength_natCast_mono hk_le_pow).trans hpow_bl
  have hN_bl : intBitLength (((k_blk * s₀_d : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono hk_pow).trans hpow_bl
  have haddr3_bl : ∀ off < (posNodeStride d L), intBitLength (nodeCellAddr (posNodeStride d L) j off) ≤ W := by
    intro off hoff
    exact (nodeCellAddr_bl (Nat.le_succ_of_le hj) hoff (by clear * - hW; omega)).2
  have haddr4_bl : ∀ h' ≤ 2 ^ L, intBitLength (((j * 2 ^ L + h' : ℕ) : ℤ)) ≤ W := by
    intro h' hh'
    have hle : j * 2 ^ L + h' ≤ (K_max + 2) * (posNodeStride d L) := by
      have h1 : j * 2 ^ L ≤ j * (posNodeStride d L) := Nat.mul_le_mul_left j (by clear * - hns_ge; omega)
      have h2 : j * (posNodeStride d L) + h' ≤ j * (posNodeStride d L) + (posNodeStride d L) := Nat.add_le_add_left (by clear * - hh' hns_ge; omega) _
      have h3 : (j + 1) * (posNodeStride d L) ≤ (K_max + 2) * (posNodeStride d L) := Nat.mul_le_mul_right _ (by omega)
      rw [add_mul, one_mul] at h3
      omega
    have h1 := intBitLength_ofNat_le (j * 2 ^ L + h')
    have h2 := natBitLength_mono hle
    clear * - h1 h2 hW; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  -- Header setup
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 104) (by decide) hl104
  set g1 := Function.update regs 10 104; have bg1 := hbnd.update (r := 10) (by decide) hl104
  have hg1_r : ws.read (.heap 9 (g1 10)) = (j : ℤ) := by simp [g1, hr104]
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact hj_bl)
  rw [hg1_r] at s2
  set g2 := Function.update g1 0 (j : ℤ); have bg2 := bg1.update (r := 0) (by decide) hj_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := ((posNodeStride d L) : ℤ)) (by decide) hns_bl
  set g3 := Function.update g2 8 ((posNodeStride d L) : ℤ); have bg3 := bg2.update (r := 8) (by decide) hns_bl
  have hmul3 : g3 0 * g3 8 = nodeCellAddr (posNodeStride d L) j 0 := by simp [g3, g2, nodeCellAddr]
  have s4 := RegExec.mul (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 6) (a := 0) (b := 8)
    (by decide) (by decide) (by decide) (by rw [hmul3]; exact haddr3_bl 0 (by clear * - hp2_pos hns_ge; omega))
  rw [hmul3] at s4
  set g4 := Function.update g3 6 (nodeCellAddr (posNodeStride d L) j 0); have bg4 := bg3.update (r := 6) (by decide) (haddr3_bl 0 (by clear * - hp2_pos hns_ge; omega))
  have s5 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 2) (by decide) hl2
  set g5 := Function.update g4 14 2; have bg5 := bg4.update (r := 14) (by decide) hl2
  have hadd5 : g5 6 + g5 14 = nodeCellAddr (posNodeStride d L) j 2 := by simp [g5, g4, nodeCellAddr]
  have s6 := RegExec.add (inp := inp) hfd_le bg5 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (a := 6) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hadd5]; exact haddr3_bl 2 (by clear * - hp2_pos hns_ge; omega))
  rw [hadd5] at s6
  set g6 := Function.update g5 8 (nodeCellAddr (posNodeStride d L) j 2); have bg6 := bg5.update (r := 8) (by decide) (haddr3_bl 2 (by clear * - hp2_pos hns_ge; omega))
  have hg6_r : ws.read (.heap 3 (g6 8)) = (k_blk : ℤ) := by simp [g6, hr_k]
  have s7 := RegExec.load (inp := inp) hfd_le bg6 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 5) (table := 3) (addr := 8)
    (by decide) (by decide) hn3 (by rw [hg6_r]; exact hk_bl)
  rw [hg6_r] at s7
  set g7 := Function.update g6 5 (k_blk : ℤ); have bg7 := bg6.update (r := 5) (by decide) hk_bl
  have s8 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := (s₀_d : ℤ)) (by decide) hs₀_bl
  set g8 := Function.update g7 14 (s₀_d : ℤ); have bg8 := bg7.update (r := 14) (by decide) hs₀_bl
  have hmul8 : g8 5 * g8 14 = ((k_blk * s₀_d : ℕ) : ℤ) := by simp [g8, g7]
  have s9 := RegExec.mul (inp := inp) hfd_le bg8 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 5) (a := 5) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hmul8]; exact hN_bl)
  rw [hmul8] at s9
  set g9 := Function.update g8 5 ((k_blk * s₀_d : ℕ) : ℤ); have bg9 := bg8.update (r := 5) (by decide) hN_bl
  have s10 := RegExec.lit (inp := inp) hfd_le bg9 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := ((6 + 2 * d : ℕ) : ℤ)) (by decide) h62d_bl
  set g10 := Function.update g9 14 ((6 + 2 * d : ℕ) : ℤ); have bg10 := bg9.update (r := 14) (by decide) h62d_bl
  have hadd10 : g10 6 + g10 14 = nodeCellAddr (posNodeStride d L) j (6 + 2 * d) := by
    simp [g10, g9, g8, g7, g6, g5, g4, nodeCellAddr]
  have s11 := RegExec.add (inp := inp) hfd_le bg10 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 6) (a := 6) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hadd10]; exact haddr3_bl (6 + 2 * d) (by clear * - hp2_pos hns_ge; omega))
  rw [hadd10] at s11
  set g11 := Function.update g10 6 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d))
  have bg11 := bg10.update (r := 6) (by decide) (haddr3_bl (6 + 2 * d) (by clear * - hp2_pos hns_ge; omega))
  have s12 := RegExec.lit (inp := inp) hfd_le bg11 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := ((2 ^ L : ℕ) : ℤ)) (by decide) hpow_bl
  set g12 := Function.update g11 8 ((2 ^ L : ℕ) : ℤ); have bg12 := bg11.update (r := 8) (by decide) hpow_bl
  have hmul12 : g12 0 * g12 8 = ((j * 2 ^ L : ℕ) : ℤ) := by
    simp [g12, g11, g10, g9, g8, g7, g6, g5, g4, g3, g2]
  have s13 := RegExec.mul (inp := inp) hfd_le bg12 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 7) (a := 0) (b := 8)
    (by decide) (by decide) (by decide) (by rw [hmul12]; exact haddr4_bl 0 (Nat.zero_le _))
  rw [hmul12] at s13
  set g13 := Function.update g12 7 ((j * 2 ^ L : ℕ) : ℤ)
  have bg13 := bg12.update (r := 7) (by decide) (haddr4_bl 0 (Nat.zero_le _))
  have s14 := RegExec.lit (inp := inp) hfd_le bg13 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := 0) (by decide) hl0
  set g14 := Function.update g13 8 0; have bg14 := bg13.update (r := 8) (by decide) hl0
  have s15 := RegExec.lit (inp := inp) hfd_le bg14 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 9) (c := 0) (by decide) hl0
  set g15 := Function.update g14 9 0; have bg15 := bg14.update (r := 9) (by decide) hl0
  have s16 := RegExec.lit (inp := inp) hfd_le bg15 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
  set g16 := Function.update g15 14 1; have bg16 := bg15.update (r := 14) (by decide) hl1
  -- Loop sequence `m = 0 .. N` where `N = k_blk * s₀_d`
  set N := k_blk * s₀_d
  let bhFlat : ℕ → ℕ := fun idx =>
    if h : idx < N then
      bh ⟨idx / s₀_d, Nat.div_lt_of_lt_mul (by rw [mul_comm]; exact h)⟩ ⟨idx % s₀_d, Nat.mod_lt idx hs₀1⟩
    else 0
  have hbhFlat_spec : ∀ idx (h : idx < N),
      bhFlat idx < 2 ^ L ∧
      ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + idx))) = (bhFlat idx : ℤ) := by
    intro idx h
    dsimp only [bhFlat]
    rw [dif_pos h]
    let b : Fin k_blk := ⟨idx / s₀_d, Nat.div_lt_of_lt_mul (by rw [mul_comm]; exact h)⟩
    let t : Fin s₀_d := ⟨idx % s₀_d, Nat.mod_lt idx hs₀1⟩
    have hdiv : b.val * s₀_d + t.val = idx := by
      dsimp [b, t]; rw [Nat.mul_comm, Nat.div_add_mod]
    obtain ⟨hlt, hr⟩ := hbh b t
    rw [hdiv] at hr
    exact ⟨hlt, hr⟩
  let wsSeq : ℕ → WordStore := fun m =>
    Nat.rec ws (fun idx acc => acc.free (.heap 4 (((j * 2 ^ L + bhFlat idx : ℕ) : ℤ)))) m
  have hwsSeq_succ : ∀ idx,
      wsSeq (idx + 1) = (wsSeq idx).free (.heap 4 (((j * 2 ^ L + bhFlat idx : ℕ) : ℤ))) :=
    fun _ => rfl
  let regSeq : ℕ → ℕ → ℤ := fun m =>
    Function.update g16 6 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + m))
  have hSeq_frame : ∀ m ≤ N,
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (wsSeq m) ∧
      (∀ idx < m, (.heap 4 (((j * 2 ^ L + bhFlat idx : ℕ) : ℤ)) : RAMCellLoc) ∉ (wsSeq m).live) ∧
      (∀ loc : RAMCellLoc,
        (∀ h' < 2 ^ L, loc ≠ .heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ))) →
        (loc ∈ (wsSeq m).live ↔ loc ∈ ws.live) ∧ (wsSeq m).vals loc = ws.vals loc) := by
    intro m hm
    induction m with
    | zero =>
        exact ⟨hmod, fun idx h => absurd h (Nat.not_lt_zero _), fun _ _ => ⟨Iff.rfl, rfl⟩⟩
    | succ idx ih =>
        have hidx_lt : idx < N := Nat.lt_of_succ_le hm
        obtain ⟨hmod_i, hfreed_i, hfr_i⟩ := ih (Nat.le_of_succ_le hm)
        have hbh_lt := (hbhFlat_spec idx hidx_lt).1
        have hmem_loc : (.heap 4 (((j * 2 ^ L + bhFlat idx : ℕ) : ℤ)) : RAMCellLoc) ∈
            posDimWriteLocs d L K_max :=
          mem_posDimWriteLocs_tab4 (Nat.le_succ_of_le hj) hbh_lt
        refine ⟨hmod_i.free hmem_loc, fun r hr => ?_, fun loc hne => ?_⟩
        · rw [hwsSeq_succ]
          rcases Nat.lt_succ_iff_lt_or_eq.mp hr with hlt | rfl
          · exact fun hm_er => hfreed_i r hlt (Finset.mem_of_mem_erase hm_er)
          · simp [WordStore.free]
        · rw [hwsSeq_succ]
          have hne_cur : loc ≠ .heap 4 (((j * 2 ^ L + bhFlat idx : ℕ) : ℤ)) := hne _ hbh_lt
          simp only [WordStore.free, Finset.mem_erase, ne_eq, hne_cur, not_false_eq_true, true_and,
            Function.update_of_ne hne_cur]
          exact hfr_i loc hne
  have hbndSeq : ∀ m ≤ N, RegBounded W (regSeq m) := by
    intro m hm
    have hoff_lt : 6 + 2 * d + m < (posNodeStride d L) := by clear * - hm hk_pow hns_ge; omega
    exact bg16.update (r := 6) (by decide) (haddr3_bl _ hoff_lt)
  have hstep : ∀ idx < N,
      RegExec inp fd W C_cell C_bit freeLevelTab4StepStmt
        (wsSeq idx) (regSeq idx) (wsSeq (idx + 1)) (regSeq (idx + 1))
        34 (25 * W + 140) := by
    intro idx hidx
    obtain ⟨hmod_i, _, hfr_i⟩ := hSeq_frame idx (Nat.le_of_lt hidx)
    obtain ⟨hmod_i1, _, _⟩ := hSeq_frame (idx + 1) (Nat.succ_le_of_lt hidx)
    obtain ⟨hbh_lt, hr_bh_ws⟩ := hbhFlat_spec idx hidx
    have hr_bh_i : (wsSeq idx).read (.heap 3 (regSeq idx 6)) = (bhFlat idx : ℤ) := by
      have hreg6 : regSeq idx 6 = nodeCellAddr (posNodeStride d L) j (6 + 2 * d + idx) := by simp [regSeq]
      rw [hreg6]
      have h3 := hfr_i (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + idx))) (by intro _ _ h; cases h)
      exact (wordStore_read_congr h3).trans hr_bh_ws
    have hbh_bl : intBitLength (bhFlat idx : ℤ) ≤ W :=
      (intBitLength_natCast_mono (Nat.le_of_lt hbh_lt)).trans hpow_bl
    have p1 := RegExec.load (inp := inp) hfd_le (hbndSeq idx (Nat.le_of_lt hidx))
      (sp_ok hmod_i).1 (sp_ok hmod_i).2 (dst := 8) (table := 3) (addr := 6)
      (by decide) (by decide) hn3 (by rw [hr_bh_i]; exact hbh_bl)
    rw [hr_bh_i] at p1
    set q1 := Function.update (regSeq idx) 8 (bhFlat idx : ℤ)
    have bq1 := (hbndSeq idx (Nat.le_of_lt hidx)).update (r := 8) (by decide) hbh_bl
    have hadd_q1 : q1 7 + q1 8 = (((j * 2 ^ L + bhFlat idx : ℕ) : ℤ)) := by
      simp [q1, regSeq, g16, g15, g14, g13]
    have p2 := RegExec.add (inp := inp) hfd_le bq1 (sp_ok hmod_i).1 (sp_ok hmod_i).2
      (dst := 9) (a := 7) (b := 8) (by decide) (by decide) (by decide)
      (by rw [hadd_q1]; exact haddr4_bl _ (Nat.le_of_lt hbh_lt))
    rw [hadd_q1] at p2
    set q2 := Function.update q1 9 (((j * 2 ^ L + bhFlat idx : ℕ) : ℤ))
    have bq2 := bq1.update (r := 9) (by decide) (haddr4_bl _ (Nat.le_of_lt hbh_lt))
    have p3 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit)
      (wsHeap := wsSeq idx) bq2 (table := 4) (addr := 9) (by decide) hn4
    have hfree_eq : (wsSeq idx).free (.heap 4 (q2 9)) = wsSeq (idx + 1) := by
      rw [hwsSeq_succ]; simp [q2]
    rw [hfree_eq] at p3
    have p4 := RegExec.lit (inp := inp) hfd_le bq2 (sp_ok hmod_i1).1 (sp_ok hmod_i1).2
      (dst := 8) (c := 0) (by decide) hl0
    set q4 := Function.update q2 8 0; have bq4 := bq2.update (r := 8) (by decide) hl0
    have p5 := RegExec.lit (inp := inp) hfd_le bq4 (sp_ok hmod_i1).1 (sp_ok hmod_i1).2
      (dst := 9) (c := 0) (by decide) hl0
    set q5 := Function.update q4 9 0; have bq5 := bq4.update (r := 9) (by decide) hl0
    have hadd_q5 : q5 6 + q5 14 = nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (idx + 1)) := by
      simp [q5, q4, q2, q1, regSeq, g16, nodeCellAddr]; ring
    have hoff_i1 : 6 + 2 * d + (idx + 1) < (posNodeStride d L) := by clear * - hidx hk_pow hns_ge; omega
    have p6 := RegExec.add (inp := inp) hfd_le bq5 (sp_ok hmod_i1).1 (sp_ok hmod_i1).2
      (dst := 6) (a := 6) (b := 14) (by decide) (by decide) (by decide)
      (by rw [hadd_q5]; exact haddr3_bl _ hoff_i1)
    rw [hadd_q5] at p6
    have hreg_eq : Function.update q5 6 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (idx + 1))) =
        regSeq (idx + 1) := by
      ext r
      by_cases hr6 : r = 6
      · subst hr6; simp [regSeq]
      · by_cases hr8 : r = 8
        · subst hr8; simp [q5, q4, regSeq, g16, g15, g14]
        · by_cases hr9 : r = 9
          · subst hr9; simp [q5, regSeq, g16, g15]
          · simp [q5, q4, q2, q1, regSeq, hr6, hr8, hr9]
    exact (p1.seq (p2.seq (p3.seq (p4.seq (p5.seq p6))))).weaken rfl hreg_eq (by omega) (by omega)
  have hg16_eq : regSeq 0 = g16 := by
    ext r
    by_cases hr6 : r = 6
    · subst hr6; simp [regSeq, g16, g15, g14, g13, g12, g11]
    · simp [regSeq, hr6]
  have s17 := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (cntReg := 5) (by decide) N wsSeq regSeq
    (by rw [hg16_eq]; simp [g16, g15, g14, g13, g12, g11, g10, g9, N])
    (hbndSeq 0 (Nat.zero_le _)) hstep
  rw [hg16_eq] at s17
  obtain ⟨hmodN, hfreedN, hfrN⟩ := hSeq_frame N le_rfl
  refine ⟨wsSeq N, regSeq N, ?_, hmodN, hbndSeq N le_rfl, ?_, hfrN⟩
  · have htot := s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq
      (s9.seq (s10.seq (s11.seq (s12.seq (s13.seq (s14.seq (s15.seq (s16.seq s17)))))))))))))))
    refine htot.weaken rfl rfl ?_ ?_
    · clear * - hk_M; omega
    · have hN_le : N ≤ 2 * (M_ceil + 1) := hk_M
      nlinarith only [hN_le, hW24, hWW]
  · intro h hh hlive
    have hlive_ws : (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ ws.live := by
      have hind : ∀ m, (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ (wsSeq m).live →
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ ws.live := by
        intro m; induction m with
        | zero => exact id
        | succ idx ih =>
            rw [hwsSeq_succ]; intro hm; exact ih (Finset.mem_of_mem_erase hm)
      exact hind N hlive
    rcases hsp4 h hh hlive_ws with ⟨b, t, rfl⟩
    let idx := b.val * s₀_d + t.val
    have hidx_lt : idx < N := by
      have h1 : (b.val + 1) * s₀_d ≤ k_blk * s₀_d := Nat.mul_le_mul_right s₀_d b.isLt
      have h2 : b.val * s₀_d + t.val < (b.val + 1) * s₀_d := by rw [add_mul, one_mul]; omega
      exact lt_of_lt_of_le h2 h1
    have hbh_eq : bhFlat idx = bh b t := by
      dsimp only [bhFlat]
      rw [dif_pos hidx_lt]
      have hdiv : idx / s₀_d = b.val := by
        dsimp [idx]
        rw [Nat.mul_comm, Nat.mul_add_div hs₀1, Nat.div_eq_of_lt t.isLt, add_zero]
      have hmod_eq : idx % s₀_d = t.val := by
        dsimp [idx]
        rw [Nat.mul_comm, Nat.mul_add_mod, Nat.mod_eq_of_lt t.isLt]
      congr 1 <;> ext <;> assumption
    rw [← hbh_eq] at hlive
    exact hfreedN idx hidx_lt hlive


end UL.C12LVE
