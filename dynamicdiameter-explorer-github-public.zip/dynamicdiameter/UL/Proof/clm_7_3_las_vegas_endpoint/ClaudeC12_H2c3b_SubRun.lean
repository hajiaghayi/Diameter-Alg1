import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2c3a_SubSteps
set_option autoImplicit false
set_option maxHeartbeats 1600000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Continuation-stack translation and `simulate_trA2Stack` -/

def trA2Cont (T_max : ℕ) : BitRAMCont → BitRAMCont
  | .stmt s => .stmt (trA2Stmt T_max s)
  | .repeatLoop rem body => .repeatLoop rem (trA2Stmt T_max body)
  | .popScope prev => .popScope (2 + prev)

def maxTableStack : List BitRAMCont → ℕ
  | [] => 1
  | .stmt s :: rest => max (maxTableStmt s) (maxTableStack rest)
  | .repeatLoop _ body :: rest => max (maxTableStmt body) (maxTableStack rest)
  | .popScope _ :: rest => maxTableStack rest

def maxFactorStack : List BitRAMCont → ℕ
  | [] => 64
  | .stmt s :: rest => max (a2StmtFactor s) (maxFactorStack rest)
  | .repeatLoop _ body :: rest => max (a2StmtFactor body) (maxFactorStack rest)
  | .popScope _ :: rest => maxFactorStack rest

theorem endDepth_trA2Cont (T_max : ℕ) :
    ∀ (stack : List BitRAMCont) (fd : ℕ),
      endDepth (stack.map (trA2Cont T_max)) (2 + fd) = 2 + endDepth stack fd
  | [], _ => rfl
  | .stmt _ :: rest, fd => endDepth_trA2Cont T_max rest fd
  | .repeatLoop _ _ :: rest, fd => endDepth_trA2Cont T_max rest fd
  | .popScope prev :: rest, _ => endDepth_trA2Cont T_max rest prev

private theorem step_RunsTo_a2 {d : ℕ} {inp : BitRAMInput d}
    {item : BitRAMCont} {restItems nextStack : List BitRAMCont} {st st' stEnd : BitRAMExecState}
    (hstep : ∀ (rest : List BitRAMCont) (k : ℕ),
      runBitRAMFuel inp (k + 1) (item :: restItems ++ rest) st =
        runBitRAMFuel inp k (nextStack ++ rest) st')
    (hruns : RunsTo inp nextStack st' stEnd) :
    RunsTo inp (item :: restItems) st stEnd := by
  rcases hruns with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by clear * -; omega, hstep rest (f + k)]
  exact hf rest k

theorem evalBitCond_cost_pos {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore) :
    ∀ c : BitCondExpr,
      1 ≤ (evalBitCond inp fd ws c).2.1 ∧ 1 ≤ (evalBitCond inp fd ws c).2.2
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => by
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      have hp := intBitLength_pos v₁
      simp only [evalBitCond, h1, h2]
      clear * - hp; omega
  | .not c₀ => by
      rcases h0 : evalBitCond inp fd ws c₀ with ⟨r, u₀, b₀⟩
      simp only [evalBitCond, h0]; clear * -; omega
  | .and c₁ c₂ | .or c₁ c₂ => by
      rcases h1 : evalBitCond inp fd ws c₁ with ⟨r₁, u₁, b₁⟩
      rcases h2 : evalBitCond inp fd ws c₂ with ⟨r₂, u₂, b₂⟩
      simp only [evalBitCond, h1, h2]; clear * -; omega

theorem simulate_trA2Stack {d m B T_max S_max F : ℕ}
    {wsBase : WordStore} {inpSub : BitRAMInput d}
    (inpSim : BitRAMInput d)
    (hstage : StagingA2Matches m B wsBase inpSub)
    (hF64 : 64 ≤ F) :
    ∀ (fuel : ℕ) (stack : List BitRAMCont) (stSub stSim : BitRAMExecState)
      (outSub : BitRAMExecOutcome) (tailBits : List Bool)
      (highSid : ℕ) (sidOfEnc : ℤ → Option ℕ) (encOfSid : ℕ → ℤ) (freeStack : List ℕ),
      runBitRAMFuel inpSub fuel stack stSub = .halted outSub →
      outSub.peakCellSpace ≤ S_max →
      stSub.words.cellCount ≤ stSub.peakCellSpace →
      stSub.words.bitSize ≤ stSub.peakBitSpace →
      A2SimInv wsBase T_max S_max stSub.words stSim.words highSid sidOfEnc encOfSid freeStack →
      stSim.frameDepth = 2 + stSub.frameDepth →
      stSim.remainingBits = stSub.remainingBits ++ tailBits →
      stSim.peakCellSpace ≤ a2CellBound wsBase inpSim S_max outSub.peakCellSpace →
      stSim.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max outSub.peakBitSpace →
      maxTableStack stack ≤ T_max →
      maxFactorStack stack ≤ F →
      let K := a2ParamBits m d T_max + (natBitLength S_max + 4)
      ∃ (stEnd : BitRAMExecState) (wsSubEnd : WordStore)
        (highSid' : ℕ) (sidOfEnc' : ℤ → Option ℕ) (encOfSid' : ℕ → ℤ) (freeStack' : List ℕ),
        RunsTo inpSim (stack.map (trA2Cont T_max)) stSim stEnd ∧
        wsSubEnd.popDepth 0 = outSub.words ∧
        wsSubEnd.cellCount ≤ outSub.peakCellSpace ∧
        wsSubEnd.bitSize ≤ outSub.peakBitSpace ∧
        A2SimInv wsBase T_max S_max wsSubEnd stEnd.words highSid' sidOfEnc' encOfSid' freeStack' ∧
        stEnd.frameDepth = 2 + endDepth stack stSub.frameDepth ∧
        stEnd.remainingBits = tailBits ∧
        stEnd.unitCost ≤ stSim.unitCost + 8 * F * (outSub.unitCost - stSub.unitCost) ∧
        stEnd.bitCost ≤ stSim.bitCost + 8 * F * K * (outSub.bitCost - stSub.bitCost) ∧
        stEnd.peakCellSpace ≤ a2CellBound wsBase inpSim S_max outSub.peakCellSpace ∧
        stEnd.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max outSub.peakBitSpace := by
  intro fuel
  induction fuel with
  | zero =>
      intro stack stSub stSim outSub tailBits highSid sidOfEnc encOfSid freeStack
        hrun _ hSubC hSubB hinv hfd hbits hpC hpB _ _
      cases stack with
      | nil =>
          simp only [runBitRAMFuel] at hrun
          split_ifs at hrun with hemp
          cases hrun
          have hnil : stSub.remainingBits = [] := List.isEmpty_iff.mp hemp
          rw [hnil, List.nil_append] at hbits
          refine ⟨stSim, stSub.words, highSid, sidOfEnc, encOfSid, freeStack,
            RunsTo.nil stSim, rfl, hSubC, hSubB, hinv, hfd, hbits, Nat.le_add_right _ _, Nat.le_add_right _ _, hpC, hpB⟩
      | cons _ _ => simp [runBitRAMFuel] at hrun
  | succ fuel ih =>
      intro stack stSub stSim outSub tailBits highSid sidOfEnc encOfSid freeStack
        hrun hPeakS hSubC hSubB hinv hfd hbits hpC hpB htm hF
      set K_p := a2ParamBits m d T_max
      set S_bits := natBitLength S_max + 4
      set K := K_p + S_bits
      have hKp_ge : 8 ≤ K_p := by dsimp [K_p]; unfold a2ParamBits; clear * -; omega
      have hK_ge : 12 ≤ K := by dsimp [K, S_bits]; clear * - hKp_ge; omega
      have hKp_le : K_p ≤ K := by dsimp [K]; clear * -; omega
      obtain ⟨hMonoU, hMonoB, hMonoPC, hMonoPB⟩ := runBitRAMFuel_cost_mono (fuel + 1) stack stSub outSub hrun
      have hcPeak_cur : stSub.words.cellCount ≤ outSub.peakCellSpace := hSubC.trans hMonoPC
      have hbPeak_cur : stSub.words.bitSize ≤ outSub.peakBitSpace := hSubB.trans hMonoPB
      cases stack with
      | nil =>
          simp only [runBitRAMFuel] at hrun
          split_ifs at hrun with hemp
          cases hrun
          have hnil : stSub.remainingBits = [] := List.isEmpty_iff.mp hemp
          rw [hnil, List.nil_append] at hbits
          exact ⟨stSim, stSub.words, highSid, sidOfEnc, encOfSid, freeStack,
            RunsTo.nil stSim, rfl, hSubC, hSubB, hinv, hfd, hbits, Nat.le_add_right _ _, Nat.le_add_right _ _, hpC, hpB⟩
      | cons item rest =>
          cases item with
          | popScope prev =>
              simp only [runBitRAMFuel] at hrun
              simp only [maxTableStack, maxFactorStack] at htm hF
              let stSim' : BitRAMExecState :=
                { stSim with words := stSim.words.popDepth (2 + prev), frameDepth := 2 + prev }
              obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                ih rest
                  { stSub with words := stSub.words.popDepth prev, frameDepth := prev }
                  stSim' outSub tailBits highSid sidOfEnc encOfSid freeStack
                  hrun hPeakS
                  ((cellCount_popDepth_le _ _).trans hSubC)
                  ((bitSize_popDepth_le _ _).trans hSubB)
                  (hinv.popDepth prev) rfl hbits hpC hpB htm hF
              refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩
              exact step_RunsTo_a2 (fun _ _ => rfl) hruns
          | repeatLoop rem body =>
              simp only [maxTableStack, maxFactorStack, max_le_iff] at htm hF
              cases rem with
              | zero =>
                  simp only [runBitRAMFuel] at hrun
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih rest stSub stSim outSub tailBits highSid sidOfEnc encOfSid freeStack
                      hrun hPeakS hSubC hSubB hinv hfd hbits hpC hpB htm.2 hF.2
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩
                  exact step_RunsTo_a2 (fun _ _ => rfl) hruns
              | succ rem' =>
                  simp only [runBitRAMFuel] at hrun
                  have htm' : maxTableStack (.stmt body :: .repeatLoop rem' body :: rest) ≤ T_max := by
                    simp [maxTableStack, htm.1, htm.2]
                  have hF' : maxFactorStack (.stmt body :: .repeatLoop rem' body :: rest) ≤ F := by
                    simp [maxFactorStack, hF.1, hF.2]
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih (.stmt body :: .repeatLoop rem' body :: rest)
                      stSub stSim outSub tailBits highSid sidOfEnc encOfSid freeStack
                      hrun hPeakS hSubC hSubB hinv hfd hbits hpC hpB htm' hF'
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩
                  exact step_RunsTo_a2 (fun _ _ => rfl) hruns
          | stmt s =>
              simp only [maxTableStack, maxFactorStack, max_le_iff] at htm hF
              cases s with
              | skip =>
                  simp only [runBitRAMFuel] at hrun
                  have hm' := runBitRAMFuel_cost_mono fuel rest _ outSub hrun
                  let stSim' : BitRAMExecState :=
                    { stSim with unitCost := stSim.unitCost + 1, bitCost := stSim.bitCost + 1 }
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih rest { stSub with unitCost := stSub.unitCost + 1, bitCost := stSub.bitCost + 1 }
                      stSim' outSub tailBits highSid sidOfEnc encOfSid freeStack
                      hrun hPeakS hSubC hSubB hinv hfd hbits hpC hpB htm.2 hF.2
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs',
                    RunsTo.trans (RunsTo.skip inpSim stSim) hruns,
                    hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                  · dsimp [stSim'] at hucE
                    have hsub_ge : stSub.unitCost + 1 ≤ outSub.unitCost := hm'.1
                    have hms : 8 * F * (outSub.unitCost - (stSub.unitCost + 1)) + 8 * F =
                        8 * F * (outSub.unitCost - stSub.unitCost) := by
                      rw [← Nat.mul_add_one, show outSub.unitCost - (stSub.unitCost + 1) + 1 = outSub.unitCost - stSub.unitCost by clear * - hsub_ge; omega]
                    linarith only [hucE, hms, hF64]
                  · dsimp [stSim'] at hbcE
                    have hsub_ge : stSub.bitCost + 1 ≤ outSub.bitCost := hm'.2.1
                    have h1_le : 1 ≤ 8 * F * K := by nlinarith only [hF64, hK_ge]
                    have hms : 8 * F * K * (outSub.bitCost - (stSub.bitCost + 1)) + 8 * F * K =
                        8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                      rw [← Nat.mul_add_one, show outSub.bitCost - (stSub.bitCost + 1) + 1 = outSub.bitCost - stSub.bitCost by clear * - hsub_ge; omega]
                    linarith only [hbcE, h1_le, hms]
              | seq s₁ s₂ =>
                  simp only [runBitRAMFuel] at hrun
                  simp only [maxTableStmt, a2StmtFactor, max_le_iff] at htm hF
                  have htm' : maxTableStack (.stmt s₁ :: .stmt s₂ :: rest) ≤ T_max := by
                    simp [maxTableStack, htm.1.1, htm.1.2, htm.2]
                  have hF' : maxFactorStack (.stmt s₁ :: .stmt s₂ :: rest) ≤ F := by
                    simp [maxFactorStack, hF.1.1, hF.1.2, hF.2]
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih (.stmt s₁ :: .stmt s₂ :: rest) stSub stSim outSub tailBits
                      highSid sidOfEnc encOfSid freeStack
                      hrun hPeakS hSubC hSubB hinv hfd hbits hpC hpB htm' hF'
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩
                  exact step_RunsTo_a2 (fun _ _ => rfl) hruns
              | localScope body =>
                  simp only [runBitRAMFuel] at hrun
                  simp only [maxTableStmt, a2StmtFactor] at htm hF
                  let stSim' : BitRAMExecState :=
                    { stSim with
                      words := stSim.words.popDepth (2 + stSub.frameDepth)
                      frameDepth := (2 + stSub.frameDepth) + 1 }
                  have htm' : maxTableStack (.stmt body :: .popScope stSub.frameDepth :: rest) ≤ T_max := by
                    simp [maxTableStack, htm.1, htm.2]
                  have hF' : maxFactorStack (.stmt body :: .popScope stSub.frameDepth :: rest) ≤ F := by
                    simp [maxFactorStack, hF.1, hF.2]
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih (.stmt body :: .popScope stSub.frameDepth :: rest)
                      { stSub with words := stSub.words.popDepth stSub.frameDepth, frameDepth := stSub.frameDepth + 1 }
                      stSim' outSub tailBits highSid sidOfEnc encOfSid freeStack
                      hrun hPeakS
                      ((cellCount_popDepth_le _ _).trans hSubC)
                      ((bitSize_popDepth_le _ _).trans hSubB)
                      (hinv.popDepth stSub.frameDepth) (by dsimp [stSim']; clear * -; omega)
                      hbits hpC hpB htm' hF'
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩
                  exact step_RunsTo_a2 (fun _ _ => by simp [runBitRAMFuel, trA2Cont, trA2Stmt, hfd, stSim']) hruns
              | ite c tB fB =>
                  simp only [runBitRAMFuel] at hrun
                  have htm_c : maxTableCond c ≤ T_max := by simp only [maxTableStmt, max_le_iff] at htm; exact htm.1.1
                  have htm_tb : maxTableStmt tB ≤ T_max := by simp only [maxTableStmt, max_le_iff] at htm; exact htm.1.2.1
                  have htm_fb : maxTableStmt fB ≤ T_max := by simp only [maxTableStmt, max_le_iff] at htm; exact htm.1.2.2
                  have hF_c : a2CondFactor c ≤ F := by simp only [a2StmtFactor, max_le_iff] at hF; exact hF.1.1
                  have hF_tb : a2StmtFactor tB ≤ F := by simp only [a2StmtFactor, max_le_iff] at hF; exact hF.1.2.1
                  have hF_fb : a2StmtFactor fB ≤ F := by simp only [a2StmtFactor, max_le_iff] at hF; exact hF.1.2.2
                  have hevC := evalBitCond_trA2Cond inpSim hstage hinv.hT (hinv.agreesForExpr stSub.frameDepth) c htm_c
                  rcases hc1 : evalBitCond inpSub stSub.frameDepth stSub.words c with ⟨flag, uC, bC⟩
                  rcases hc2 : evalBitCond inpSim (2 + stSub.frameDepth) stSim.words (trA2Cond T_max c) with ⟨flag', u'C, b'C⟩
                  simp only [hc1, hc2] at hevC hrun
                  rcases hevC with ⟨hfl_eq, huC, hbC⟩; subst flag'
                  have hm' := runBitRAMFuel_cost_mono fuel (.stmt (if flag then tB else fB) :: rest) _ outSub hrun
                  let stSim' : BitRAMExecState :=
                    { stSim with unitCost := stSim.unitCost + u'C, bitCost := stSim.bitCost + b'C }
                  have htm' : maxTableStack (.stmt (if flag then tB else fB) :: rest) ≤ T_max := by
                    cases flag <;> simp [maxTableStack, htm_tb, htm_fb, htm.2]
                  have hF' : maxFactorStack (.stmt (if flag then tB else fB) :: rest) ≤ F := by
                    cases flag <;> simp [maxFactorStack, hF_tb, hF_fb, hF.2]
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih (.stmt (if flag then tB else fB) :: rest)
                      { stSub with unitCost := stSub.unitCost + uC, bitCost := stSub.bitCost + bC }
                      stSim' outSub tailBits highSid sidOfEnc encOfSid freeStack
                      hrun hPeakS hSubC hSubB hinv hfd hbits hpC hpB htm' hF'
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                  · refine step_RunsTo_a2 (fun r k => ?_) hruns
                    have hbr : trA2Cont T_max (.stmt (if flag then tB else fB)) =
                        .stmt (if flag then trA2Stmt T_max tB else trA2Stmt T_max fB) := by
                      cases flag <;> rfl
                    simp only [List.map_cons]; rw [hbr]
                    simp [runBitRAMFuel, trA2Cont, trA2Stmt, hfd, hc2, stSim']
                  · dsimp [stSim'] at hucE
                    have hu_F : u'C ≤ 8 * F * uC :=
                      huC.trans ((Nat.mul_le_mul_right uC hF_c).trans (by
                        calc F * uC = 1 * (F * uC) := by ring
                          _ ≤ 8 * (F * uC) := Nat.mul_le_mul_right _ (by decide)
                          _ = 8 * F * uC := by ring))
                    have hmul_split : 8 * F * (outSub.unitCost - (stSub.unitCost + uC)) + 8 * F * uC =
                        8 * F * (outSub.unitCost - stSub.unitCost) := by
                      rw [← Nat.mul_add]
                      congr 1; have hge := hm'.1; dsimp only at hge; clear * - hge; omega
                    linarith only [hucE, hu_F, hmul_split]
                  · dsimp [stSim'] at hbcE
                    have hb_FK : b'C ≤ 8 * F * K * bC :=
                      hbC.trans ((Nat.mul_le_mul_right bC (Nat.mul_le_mul hF_c hKp_le)).trans (by
                        calc F * K * bC = 1 * (F * K * bC) := by ring
                          _ ≤ 8 * (F * K * bC) := Nat.mul_le_mul_right _ (by decide)
                          _ = 8 * F * K * bC := by ring))
                    have hmul_split : 8 * F * K * (outSub.bitCost - (stSub.bitCost + bC)) + 8 * F * K * bC =
                        8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                      rw [← Nat.mul_add]
                      congr 1; have hge := hm'.2.1; dsimp only at hge; clear * - hge; omega
                    linarith only [hbcE, hb_FK, hmul_split]
              | whileLoop c body =>
                  simp only [runBitRAMFuel] at hrun
                  have htm_c : maxTableCond c ≤ T_max := by simp only [maxTableStmt, max_le_iff] at htm; exact htm.1.1
                  have htm_b : maxTableStmt body ≤ T_max := by simp only [maxTableStmt, max_le_iff] at htm; exact htm.1.2
                  have hF_c : a2CondFactor c ≤ F := by simp only [a2StmtFactor, max_le_iff] at hF; exact hF.1.1
                  have hF_b : a2StmtFactor body ≤ F := by simp only [a2StmtFactor, max_le_iff] at hF; exact hF.1.2
                  have hevC := evalBitCond_trA2Cond inpSim hstage hinv.hT (hinv.agreesForExpr stSub.frameDepth) c htm_c
                  rcases hc1 : evalBitCond inpSub stSub.frameDepth stSub.words c with ⟨flag, uC, bC⟩
                  rcases hc2 : evalBitCond inpSim (2 + stSub.frameDepth) stSim.words (trA2Cond T_max c) with ⟨flag', u'C, b'C⟩
                  simp only [hc1, hc2] at hevC hrun
                  rcases hevC with ⟨hfl_eq, huC, hbC⟩; subst flag'
                  let stSim' : BitRAMExecState :=
                    { stSim with unitCost := stSim.unitCost + u'C, bitCost := stSim.bitCost + b'C }
                  have hu_F : u'C ≤ 8 * F * uC :=
                    huC.trans ((Nat.mul_le_mul_right uC hF_c).trans (by
                      calc F * uC = 1 * (F * uC) := by ring
                        _ ≤ 8 * (F * uC) := Nat.mul_le_mul_right _ (by decide)
                        _ = 8 * F * uC := by ring))
                  have hb_FK : b'C ≤ 8 * F * K * bC :=
                    hbC.trans ((Nat.mul_le_mul_right bC (Nat.mul_le_mul hF_c hKp_le)).trans (by
                      calc F * K * bC = 1 * (F * K * bC) := by ring
                        _ ≤ 8 * (F * K * bC) := Nat.mul_le_mul_right _ (by decide)
                        _ = 8 * F * K * bC := by ring))
                  cases flag with
                  | false =>
                      simp only [Bool.false_eq_true, ↓reduceIte] at hrun
                      have hm' := runBitRAMFuel_cost_mono fuel rest _ outSub hrun
                      obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                        ih rest { stSub with unitCost := stSub.unitCost + uC, bitCost := stSub.bitCost + bC }
                          stSim' outSub tailBits highSid sidOfEnc encOfSid freeStack
                          hrun hPeakS hSubC hSubB hinv hfd hbits hpC hpB htm.2 hF.2
                      refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                      · exact step_RunsTo_a2 (fun _ _ => by simp [runBitRAMFuel, trA2Cont, trA2Stmt, hfd, hc2, stSim']) hruns
                      · dsimp [stSim'] at hucE
                        have hmul_split : 8 * F * (outSub.unitCost - (stSub.unitCost + uC)) + 8 * F * uC =
                            8 * F * (outSub.unitCost - stSub.unitCost) := by
                          rw [← Nat.mul_add]; congr 1; have hge := hm'.1; dsimp only at hge; clear * - hge; omega
                        linarith only [hucE, hu_F, hmul_split]
                      · dsimp [stSim'] at hbcE
                        have hmul_split : 8 * F * K * (outSub.bitCost - (stSub.bitCost + bC)) + 8 * F * K * bC =
                            8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                          rw [← Nat.mul_add]; congr 1; have hge := hm'.2.1; dsimp only at hge; clear * - hge; omega
                        linarith only [hbcE, hb_FK, hmul_split]
                  | true =>
                      simp only [↓reduceIte] at hrun
                      have hm' := runBitRAMFuel_cost_mono fuel (.stmt body :: .stmt (.whileLoop c body) :: rest) _ outSub hrun
                      have htm' : maxTableStack (.stmt body :: .stmt (.whileLoop c body) :: rest) ≤ T_max := by
                        simp [maxTableStack, maxTableStmt, htm_c, htm_b, htm.2]
                      have hF' : maxFactorStack (.stmt body :: .stmt (.whileLoop c body) :: rest) ≤ F := by
                        simp [maxFactorStack, a2StmtFactor, hF_c, hF_b, hF.2]
                      obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                        ih (.stmt body :: .stmt (.whileLoop c body) :: rest)
                          { stSub with unitCost := stSub.unitCost + uC, bitCost := stSub.bitCost + bC }
                          stSim' outSub tailBits highSid sidOfEnc encOfSid freeStack
                          hrun hPeakS hSubC hSubB hinv hfd hbits hpC hpB htm' hF'
                      refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                      · exact step_RunsTo_a2 (fun _ _ => by simp [runBitRAMFuel, trA2Cont, trA2Stmt, hfd, hc2, stSim']) hruns
                      · dsimp [stSim'] at hucE
                        have hmul_split : 8 * F * (outSub.unitCost - (stSub.unitCost + uC)) + 8 * F * uC =
                            8 * F * (outSub.unitCost - stSub.unitCost) := by
                          rw [← Nat.mul_add]; congr 1; have hge := hm'.1; dsimp only at hge; clear * - hge; omega
                        linarith only [hucE, hu_F, hmul_split]
                      · dsimp [stSim'] at hbcE
                        have hmul_split : 8 * F * K * (outSub.bitCost - (stSub.bitCost + bC)) + 8 * F * K * bC =
                            8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                          rw [← Nat.mul_add]; congr 1; have hge := hm'.2.1; dsimp only at hge; clear * - hge; omega
                        linarith only [hbcE, hb_FK, hmul_split]
              | repeatN countE body =>
                  simp only [runBitRAMFuel] at hrun
                  have htm_e : maxTableExpr countE ≤ T_max := by simp only [maxTableStmt, max_le_iff] at htm; exact htm.1.1
                  have htm_b : maxTableStmt body ≤ T_max := by simp only [maxTableStmt, max_le_iff] at htm; exact htm.1.2
                  have hF_e : a2ExprFactor countE ≤ F := by
                    simp only [a2StmtFactor, max_le_iff] at hF; have h1 := hF.1.1; clear * - h1; omega
                  have hF_b : a2StmtFactor body ≤ F := by simp only [a2StmtFactor, max_le_iff] at hF; exact hF.1.2
                  have hev := evalIntExpr_trA2Expr inpSim hstage hinv.hT (hinv.agreesForExpr stSub.frameDepth) countE htm_e
                  rcases he1 : evalIntExpr inpSub stSub.frameDepth stSub.words countE with ⟨cnt, uC, bC⟩
                  rcases he2 : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words (trA2Expr T_max countE) with ⟨cnt', u'C, b'C⟩
                  simp only [he1, he2] at hev hrun
                  rcases hev with ⟨hcnt_eq, huC, hbC⟩; subst cnt'
                  set nIter := if 0 ≤ cnt then cnt.toNat else 0
                  have hm' := runBitRAMFuel_cost_mono fuel (.repeatLoop nIter body :: rest) _ outSub hrun
                  let stSim' : BitRAMExecState :=
                    { stSim with unitCost := stSim.unitCost + u'C, bitCost := stSim.bitCost + b'C }
                  have htm' : maxTableStack (.repeatLoop nIter body :: rest) ≤ T_max := by
                    simp [maxTableStack, htm_b, htm.2]
                  have hF' : maxFactorStack (.repeatLoop nIter body :: rest) ≤ F := by
                    simp [maxFactorStack, hF_b, hF.2]
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih (.repeatLoop nIter body :: rest)
                      { stSub with unitCost := stSub.unitCost + uC, bitCost := stSub.bitCost + bC }
                      stSim' outSub tailBits highSid sidOfEnc encOfSid freeStack
                      hrun hPeakS hSubC hSubB hinv hfd hbits hpC hpB htm' hF'
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                  · exact step_RunsTo_a2 (fun _ _ => by simp [runBitRAMFuel, trA2Cont, trA2Stmt, hfd, he2, stSim', nIter]) hruns
                  · dsimp [stSim'] at hucE
                    have hu_F : u'C ≤ 8 * F * uC :=
                      huC.trans ((Nat.mul_le_mul_right uC hF_e).trans (by
                        calc F * uC = 1 * (F * uC) := by ring
                          _ ≤ 8 * (F * uC) := Nat.mul_le_mul_right _ (by decide)
                          _ = 8 * F * uC := by ring))
                    have hmul_split : 8 * F * (outSub.unitCost - (stSub.unitCost + uC)) + 8 * F * uC =
                        8 * F * (outSub.unitCost - stSub.unitCost) := by
                      rw [← Nat.mul_add]; congr 1; have hge := hm'.1; dsimp only at hge; clear * - hge; omega
                    linarith only [hucE, hu_F, hmul_split]
                  · dsimp [stSim'] at hbcE
                    have hb_FK : b'C ≤ 8 * F * K * bC :=
                      hbC.trans ((Nat.mul_le_mul_right bC (Nat.mul_le_mul hF_e hKp_le)).trans (by
                        calc F * K * bC = 1 * (F * K * bC) := by ring
                          _ ≤ 8 * (F * K * bC) := Nat.mul_le_mul_right _ (by decide)
                          _ = 8 * F * K * bC := by ring))
                    have hmul_split : 8 * F * K * (outSub.bitCost - (stSub.bitCost + bC)) + 8 * F * K * bC =
                        8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                      rw [← Nat.mul_add]; congr 1; have hge := hm'.2.1; dsimp only at hge; clear * - hge; omega
                    linarith only [hbcE, hb_FK, hmul_split]
              | writeLocal var idxE valE =>
                  simp only [runBitRAMFuel] at hrun
                  have htm_1 : maxTableExpr idxE ≤ T_max := by simp only [maxTableStmt, max_le_iff] at htm; exact htm.1.1
                  have htm_2 : maxTableExpr valE ≤ T_max := by simp only [maxTableStmt, max_le_iff] at htm; exact htm.1.2
                  have he1 := evalIntExpr_trA2Expr inpSim hstage hinv.hT (hinv.agreesForExpr stSub.frameDepth) idxE htm_1
                  have he2 := evalIntExpr_trA2Expr inpSim hstage hinv.hT (hinv.agreesForExpr stSub.frameDepth) valE htm_2
                  rcases hv1 : evalIntExpr inpSub stSub.frameDepth stSub.words idxE with ⟨idx, u₁, b₁⟩
                  rcases hv1' : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words (trA2Expr T_max idxE) with ⟨idx', u'₁, b'₁⟩
                  rcases hv2 : evalIntExpr inpSub stSub.frameDepth stSub.words valE with ⟨val, u₂, b₂⟩
                  rcases hv2' : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words (trA2Expr T_max valE) with ⟨val', u'₂, b'₂⟩
                  simp only [hv1, hv1'] at he1; rcases he1 with ⟨hidx_eq, hu1, hb1⟩; subst idx'
                  simp only [hv2, hv2'] at he2; rcases he2 with ⟨hval_eq, hu2, hb2⟩; subst val'
                  simp only [hv1, hv2] at hrun
                  have hm' := runBitRAMFuel_cost_mono fuel rest _ outSub hrun
                  set wsSub' := stSub.words.write (.localFrame stSub.frameDepth var idx) val
                  set wsSim' := stSim.words.write (.localFrame (2 + stSub.frameDepth) var idx) val
                  have hinv' := hinv.writeLocal stSub.frameDepth var idx val
                  have hcSub' : wsSub'.cellCount ≤ outSub.peakCellSpace := by
                    have : wsSub'.cellCount ≤ max stSub.peakCellSpace (inpSub.inputCellSpace + wsSub'.cellCount) :=
                      (Nat.le_add_left _ _).trans (le_max_right _ _)
                    exact this.trans hm'.2.2.1
                  have hbSub' : wsSub'.bitSize ≤ outSub.peakBitSpace := by
                    have : wsSub'.bitSize ≤ max stSub.peakBitSpace (inpSub.inputBitSpace + wsSub'.bitSize) :=
                      (Nat.le_add_left _ _).trans (le_max_right _ _)
                    exact this.trans hm'.2.2.2
                  obtain ⟨hcSimBnd, hbSimBnd⟩ := hinv'.within_bounds inpSim hcSub' hbSub'
                  let locSim := RAMCellLoc.localFrame (2 + stSub.frameDepth) var idx
                  let locSub := RAMCellLoc.localFrame stSub.frameDepth var idx
                  let stSim' : BitRAMExecState :=
                    { stSim with
                      words := wsSim'
                      unitCost := stSim.unitCost + u'₁ + u'₂ + 1
                      bitCost := stSim.bitCost + b'₁ + b'₂ + locSim.bitLength + intBitLength val
                      peakCellSpace := max stSim.peakCellSpace (inpSim.inputCellSpace + wsSim'.cellCount)
                      peakBitSpace := max stSim.peakBitSpace (inpSim.inputBitSpace + wsSim'.bitSize) }
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih rest
                      { stSub with
                        words := wsSub'
                        unitCost := stSub.unitCost + u₁ + u₂ + 1
                        bitCost := stSub.bitCost + b₁ + b₂ + locSub.bitLength + intBitLength val
                        peakCellSpace := max stSub.peakCellSpace (inpSub.inputCellSpace + wsSub'.cellCount)
                        peakBitSpace := max stSub.peakBitSpace (inpSub.inputBitSpace + wsSub'.bitSize) }
                      stSim' outSub tailBits highSid sidOfEnc encOfSid freeStack
                      hrun hPeakS
                      ((Nat.le_add_left _ _).trans (le_max_right _ _))
                      ((Nat.le_add_left _ _).trans (le_max_right _ _))
                      hinv' hfd hbits
                      (max_le hpC (by linarith only [hcSimBnd])) (max_le hpB (by linarith only [hbSimBnd]))
                      htm.2 hF.2
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                  · refine step_RunsTo_a2 (fun _ _ => ?_) hruns
                    simp [runBitRAMFuel, trA2Cont, trA2Stmt, hfd, hv1', hv2', stSim', wsSim', locSim]
                  · dsimp [stSim'] at hucE
                    set Δu := u₁ + u₂ + 1
                    have hF1 : 64 * (a2ExprFactor idxE + a2ExprFactor valE) ≤ F := hF.1
                    have hu_step : u'₁ + u'₂ + 1 ≤ 8 * F * Δu := by
                      set A := a2ExprFactor idxE + a2ExprFactor valE
                      have m1 : a2ExprFactor idxE * u₁ ≤ A * u₁ := Nat.mul_le_mul_right u₁ (Nat.le_add_right _ _)
                      have m2 : a2ExprFactor valE * u₂ ≤ A * u₂ := Nat.mul_le_mul_right u₂ (Nat.le_add_left _ _)
                      have h64A : 64 * A ≤ F := hF1
                      have hAF : A * u₁ + A * u₂ + 1 ≤ F * Δu := by
                        dsimp [Δu]; clear * - h64A hF64; nlinarith
                      have h8 : F * Δu ≤ 8 * F * Δu := by
                        calc F * Δu = 1 * (F * Δu) := by ring
                          _ ≤ 8 * (F * Δu) := Nat.mul_le_mul_right _ (by decide)
                          _ = 8 * F * Δu := by ring
                      linarith only [hu1, hu2, m1, m2, hAF, h8]
                    have hmul_split : 8 * F * (outSub.unitCost - (stSub.unitCost + u₁ + u₂ + 1)) + 8 * F * Δu =
                        8 * F * (outSub.unitCost - stSub.unitCost) := by
                      rw [← Nat.mul_add]; congr 1; dsimp [Δu]; have hge := hm'.1; dsimp only at hge; clear * - hge; omega
                    linarith only [hucE, hu_step, hmul_split]
                  · dsimp [stSim'] at hbcE
                    set Δb := b₁ + b₂ + locSub.bitLength + intBitLength val
                    have hloc_le : locSim.bitLength ≤ 3 * locSub.bitLength := by
                      dsimp [locSim, locSub, RAMCellLoc.bitLength]
                      have h1 := natBitLength_add_le 2 stSub.frameDepth
                      have hn2 : natBitLength 2 = 2 := by decide
                      have hpos := natBitLength_pos stSub.frameDepth
                      rw [hn2] at h1; clear * - h1 hpos; omega
                    have hF1 : 64 * (a2ExprFactor idxE + a2ExprFactor valE) ≤ F := hF.1
                    have hb_step : b'₁ + b'₂ + locSim.bitLength + intBitLength val ≤ 8 * F * K * Δb := by
                      set A := a2ExprFactor idxE + a2ExprFactor valE
                      have m1 : a2ExprFactor idxE * K_p * b₁ ≤ A * K * b₁ :=
                        Nat.mul_le_mul_right b₁ (Nat.mul_le_mul (Nat.le_add_right _ _) hKp_le)
                      have m2 : a2ExprFactor valE * K_p * b₂ ≤ A * K * b₂ :=
                        Nat.mul_le_mul_right b₂ (Nat.mul_le_mul (Nat.le_add_left _ _) hKp_le)
                      have m3 : A * K * b₁ + A * K * b₂ ≤ A * K * Δb := by
                        have hle : b₁ + b₂ ≤ Δb := by dsimp [Δb]; linarith only []
                        calc A * K * b₁ + A * K * b₂ = A * K * (b₁ + b₂) := by ring
                          _ ≤ A * K * Δb := Nat.mul_le_mul_left (A * K) hle
                      have m4 : A * K ≤ F * K := Nat.mul_le_mul_right K (by clear * - hF1; omega)
                      have m5 : A * K * Δb ≤ F * K * Δb := Nat.mul_le_mul_right Δb m4
                      have m6 : 3 * Δb ≤ F * K * Δb := by
                        have h3 : 3 ≤ F * K := by nlinarith only [hF64, hK_ge]
                        exact Nat.mul_le_mul_right Δb h3
                      have hloc_Δ : locSim.bitLength + intBitLength val ≤ 3 * Δb := by
                        dsimp [Δb]; linarith only [hloc_le]
                      have m7 : 2 * (F * K * Δb) ≤ 8 * F * K * Δb := by
                        calc 2 * (F * K * Δb) ≤ 8 * (F * K * Δb) := Nat.mul_le_mul_right _ (by decide)
                          _ = 8 * F * K * Δb := by ring
                      linarith only [hb1, hb2, m1, m2, m3, m5, m6, hloc_Δ, m7]
                    have hmul_split : 8 * F * K * (outSub.bitCost - (stSub.bitCost + b₁ + b₂ + locSub.bitLength + intBitLength val)) +
                        8 * F * K * Δb = 8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                      rw [← Nat.mul_add]; congr 1; have h0 := hm'.2.1; dsimp only [Δb, locSub] at h0 ⊢; clear * - h0; omega
                    linarith only [hbcE, hb_step, hmul_split]
              | freeLocal var idxE =>
                  simp only [runBitRAMFuel] at hrun
                  have htm_1 : maxTableExpr idxE ≤ T_max := by simp only [maxTableStmt] at htm; exact htm.1
                  have he1 := evalIntExpr_trA2Expr inpSim hstage hinv.hT (hinv.agreesForExpr stSub.frameDepth) idxE htm_1
                  rcases hv1 : evalIntExpr inpSub stSub.frameDepth stSub.words idxE with ⟨idx, u₁, b₁⟩
                  rcases hv1' : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words (trA2Expr T_max idxE) with ⟨idx', u'₁, b'₁⟩
                  simp only [hv1, hv1'] at he1; rcases he1 with ⟨hidx_eq, hu1, hb1⟩; subst idx'
                  simp only [hv1] at hrun
                  have hm' := runBitRAMFuel_cost_mono fuel rest _ outSub hrun
                  let locSim := RAMCellLoc.localFrame (2 + stSub.frameDepth) var idx
                  let locSub := RAMCellLoc.localFrame stSub.frameDepth var idx
                  let stSim' : BitRAMExecState :=
                    { stSim with
                      words := stSim.words.free locSim
                      unitCost := stSim.unitCost + u'₁ + 1
                      bitCost := stSim.bitCost + b'₁ + locSim.bitLength }
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih rest
                      { stSub with
                        words := stSub.words.free locSub
                        unitCost := stSub.unitCost + u₁ + 1
                        bitCost := stSub.bitCost + b₁ + locSub.bitLength }
                      stSim' outSub tailBits highSid sidOfEnc encOfSid freeStack
                      hrun hPeakS
                      ((cellCount_free_le _ _).trans hSubC)
                      ((bitSize_free_le _ _).trans hSubB)
                      (hinv.freeLocal stSub.frameDepth var idx) hfd hbits hpC hpB htm.2 hF.2
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                  · refine step_RunsTo_a2 (fun _ _ => ?_) hruns
                    simp [runBitRAMFuel, trA2Cont, trA2Stmt, hfd, hv1', stSim', locSim]
                  · dsimp [stSim'] at hucE
                    set Δu := u₁ + 1
                    have hF1 : 64 * a2ExprFactor idxE ≤ F := hF.1
                    have hu_step : u'₁ + 1 ≤ 8 * F * Δu := by
                      have hAF : a2ExprFactor idxE * u₁ + 1 ≤ F * Δu := by
                        dsimp [Δu]; clear * - hF1 hF64; nlinarith
                      have h8 : F * Δu ≤ 8 * F * Δu := by
                        calc F * Δu = 1 * (F * Δu) := by ring
                          _ ≤ 8 * (F * Δu) := Nat.mul_le_mul_right _ (by decide)
                          _ = 8 * F * Δu := by ring
                      linarith only [hu1, hAF, h8]
                    have hmul_split : 8 * F * (outSub.unitCost - (stSub.unitCost + u₁ + 1)) + 8 * F * Δu =
                        8 * F * (outSub.unitCost - stSub.unitCost) := by
                      rw [← Nat.mul_add]; congr 1; dsimp [Δu]; have hge := hm'.1; dsimp only at hge; clear * - hge; omega
                    linarith only [hucE, hu_step, hmul_split]
                  · dsimp [stSim'] at hbcE
                    set Δb := b₁ + locSub.bitLength
                    have hloc_le : locSim.bitLength ≤ 3 * locSub.bitLength := by
                      dsimp [locSim, locSub, RAMCellLoc.bitLength]
                      have h1 := natBitLength_add_le 2 stSub.frameDepth
                      have hn2 : natBitLength 2 = 2 := by decide
                      have hpos := natBitLength_pos stSub.frameDepth
                      rw [hn2] at h1; clear * - h1 hpos; omega
                    have hF1 : 64 * a2ExprFactor idxE ≤ F := hF.1
                    have hb_step : b'₁ + locSim.bitLength ≤ 8 * F * K * Δb := by
                      have m1 : a2ExprFactor idxE * K_p * b₁ ≤ F * K * b₁ :=
                        Nat.mul_le_mul_right b₁ (Nat.mul_le_mul (by clear * - hF1; omega) hKp_le)
                      have m2 : F * K * b₁ ≤ F * K * Δb := Nat.mul_le_mul_left (F * K) (by dsimp [Δb]; linarith only [])
                      have m3 : 3 * Δb ≤ F * K * Δb := Nat.mul_le_mul_right Δb (by nlinarith only [hF64, hK_ge])
                      have m4 : 2 * (F * K * Δb) ≤ 8 * F * K * Δb := by
                        calc 2 * (F * K * Δb) ≤ 8 * (F * K * Δb) := Nat.mul_le_mul_right _ (by decide)
                          _ = 8 * F * K * Δb := by ring
                      have hloc_Δ : locSim.bitLength ≤ 3 * Δb := by dsimp [Δb]; linarith only [hloc_le]
                      linarith only [hb1, m1, m2, m3, m4, hloc_Δ]
                    have hmul_split : 8 * F * K * (outSub.bitCost - (stSub.bitCost + b₁ + locSub.bitLength)) +
                        8 * F * K * Δb = 8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                      rw [← Nat.mul_add]; congr 1; have h0 := hm'.2.1; dsimp only [Δb, locSub] at h0 ⊢; clear * - h0; omega
                    linarith only [hbcE, hb_step, hmul_split]
              | randBitLocal var idxE =>
                  cases hrem : stSub.remainingBits with
                  | nil => simp [runBitRAMFuel, hrem] at hrun
                  | cons bit bs' =>
                      simp only [runBitRAMFuel, hrem] at hrun
                      have htm_1 : maxTableExpr idxE ≤ T_max := by simp only [maxTableStmt] at htm; exact htm.1
                      have he1 := evalIntExpr_trA2Expr inpSim hstage hinv.hT (hinv.agreesForExpr stSub.frameDepth) idxE htm_1
                      rcases hv1 : evalIntExpr inpSub stSub.frameDepth stSub.words idxE with ⟨idx, u₁, b₁⟩
                      rcases hv1' : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words (trA2Expr T_max idxE) with ⟨idx', u'₁, b'₁⟩
                      simp only [hv1, hv1'] at he1; rcases he1 with ⟨hidx_eq, hu1, hb1⟩; subst idx'
                      simp only [hv1] at hrun
                      have hm' := runBitRAMFuel_cost_mono fuel rest _ outSub hrun
                      set val : ℤ := if bit then 1 else 0
                      set wsSub' := stSub.words.write (.localFrame stSub.frameDepth var idx) val
                      set wsSim' := stSim.words.write (.localFrame (2 + stSub.frameDepth) var idx) val
                      have hinv' := hinv.writeLocal stSub.frameDepth var idx val
                      have hcSub' : wsSub'.cellCount ≤ outSub.peakCellSpace := by
                        have : wsSub'.cellCount ≤ max stSub.peakCellSpace (inpSub.inputCellSpace + wsSub'.cellCount) :=
                          (Nat.le_add_left _ _).trans (le_max_right _ _)
                        exact this.trans hm'.2.2.1
                      have hbSub' : wsSub'.bitSize ≤ outSub.peakBitSpace := by
                        have : wsSub'.bitSize ≤ max stSub.peakBitSpace (inpSub.inputBitSpace + wsSub'.bitSize) :=
                          (Nat.le_add_left _ _).trans (le_max_right _ _)
                        exact this.trans hm'.2.2.2
                      obtain ⟨hcSimBnd, hbSimBnd⟩ := hinv'.within_bounds inpSim hcSub' hbSub'
                      let locSim := RAMCellLoc.localFrame (2 + stSub.frameDepth) var idx
                      let locSub := RAMCellLoc.localFrame stSub.frameDepth var idx
                      let stSim' : BitRAMExecState :=
                        { stSim with
                          words := wsSim'
                          remainingBits := bs' ++ tailBits
                          unitCost := stSim.unitCost + u'₁ + 1
                          bitCost := stSim.bitCost + b'₁ + locSim.bitLength + 1
                          peakCellSpace := max stSim.peakCellSpace (inpSim.inputCellSpace + wsSim'.cellCount)
                          peakBitSpace := max stSim.peakBitSpace (inpSim.inputBitSpace + wsSim'.bitSize) }
                      have hbits_cons : stSim.remainingBits = bit :: (bs' ++ tailBits) := by
                        rw [hbits, hrem]; rfl
                      obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                        ih rest
                          { stSub with
                            words := wsSub'
                            remainingBits := bs'
                            unitCost := stSub.unitCost + u₁ + 1
                            bitCost := stSub.bitCost + b₁ + locSub.bitLength + 1
                            peakCellSpace := max stSub.peakCellSpace (inpSub.inputCellSpace + wsSub'.cellCount)
                            peakBitSpace := max stSub.peakBitSpace (inpSub.inputBitSpace + wsSub'.bitSize) }
                          stSim' outSub tailBits highSid sidOfEnc encOfSid freeStack
                          hrun hPeakS
                          ((Nat.le_add_left _ _).trans (le_max_right _ _))
                          ((Nat.le_add_left _ _).trans (le_max_right _ _))
                          hinv' hfd rfl
                          (max_le hpC (by linarith only [hcSimBnd])) (max_le hpB (by linarith only [hbSimBnd]))
                          htm.2 hF.2
                      refine ⟨stEnd, wsSubEnd, hs', so', eo', fs', ?_, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                      · refine step_RunsTo_a2 (fun _ _ => ?_) hruns
                        simp [runBitRAMFuel, trA2Cont, trA2Stmt, hfd, hv1', hbits_cons, stSim', wsSim', locSim, val]
                      · dsimp [stSim'] at hucE
                        set Δu := u₁ + 1
                        have hF1 : 64 * a2ExprFactor idxE ≤ F := hF.1
                        have hu_step : u'₁ + 1 ≤ 8 * F * Δu := by
                          have hAF : a2ExprFactor idxE * u₁ + 1 ≤ F * Δu := by
                            dsimp [Δu]; clear * - hF1 hF64; nlinarith
                          have h8 : F * Δu ≤ 8 * F * Δu := by
                            calc F * Δu = 1 * (F * Δu) := by ring
                              _ ≤ 8 * (F * Δu) := Nat.mul_le_mul_right _ (by decide)
                              _ = 8 * F * Δu := by ring
                          linarith only [hu1, hAF, h8]
                        have hmul_split : 8 * F * (outSub.unitCost - (stSub.unitCost + u₁ + 1)) + 8 * F * Δu =
                            8 * F * (outSub.unitCost - stSub.unitCost) := by
                          rw [← Nat.mul_add]; congr 1; dsimp [Δu]; have hge := hm'.1; dsimp only at hge; clear * - hge; omega
                        linarith only [hucE, hu_step, hmul_split]
                      · dsimp [stSim'] at hbcE
                        set Δb := b₁ + locSub.bitLength + 1
                        have hloc_le : locSim.bitLength ≤ 3 * locSub.bitLength := by
                          dsimp [locSim, locSub, RAMCellLoc.bitLength]
                          have h1 := natBitLength_add_le 2 stSub.frameDepth
                          have hn2 : natBitLength 2 = 2 := by decide
                          have hpos := natBitLength_pos stSub.frameDepth
                          rw [hn2] at h1; clear * - h1 hpos; omega
                        have hF1 : 64 * a2ExprFactor idxE ≤ F := hF.1
                        have hb_step : b'₁ + locSim.bitLength + 1 ≤ 8 * F * K * Δb := by
                          have m1 : a2ExprFactor idxE * K_p * b₁ ≤ F * K * b₁ :=
                            Nat.mul_le_mul_right b₁ (Nat.mul_le_mul (by clear * - hF1; omega) hKp_le)
                          have m2 : F * K * b₁ ≤ F * K * Δb := Nat.mul_le_mul_left (F * K) (by dsimp [Δb]; linarith only [])
                          have m3 : 3 * Δb ≤ F * K * Δb := Nat.mul_le_mul_right Δb (by nlinarith only [hF64, hK_ge])
                          have m4 : 2 * (F * K * Δb) ≤ 8 * F * K * Δb := by
                            calc 2 * (F * K * Δb) ≤ 8 * (F * K * Δb) := Nat.mul_le_mul_right _ (by decide)
                              _ = 8 * F * K * Δb := by ring
                          have hloc_Δ : locSim.bitLength + 1 ≤ 3 * Δb := by dsimp [Δb]; linarith only [hloc_le]
                          linarith only [hb1, m1, m2, m3, m4, hloc_Δ]
                        have hmul_split : 8 * F * K * (outSub.bitCost - (stSub.bitCost + b₁ + locSub.bitLength + 1)) +
                            8 * F * K * Δb = 8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                          rw [← Nat.mul_add]; congr 1; have h0 := hm'.2.1; dsimp only [Δb, locSub] at h0 ⊢; clear * - h0; omega
                        linarith only [hbcE, hb_step, hmul_split]
              | writeHeap table idxE valE =>
                  simp only [runBitRAMFuel] at hrun
                  rcases hv1 : evalIntExpr inpSub stSub.frameDepth stSub.words idxE with ⟨idx, u₁, b₁⟩
                  rcases hv2 : evalIntExpr inpSub stSub.frameDepth stSub.words valE with ⟨val, u₂, b₂⟩
                  simp only [hv1, hv2] at hrun
                  have hm' := runBitRAMFuel_cost_mono fuel rest _ outSub hrun
                  set wsSub' := stSub.words.write (.heap table idx) val
                  have hcSub'_out : wsSub'.cellCount ≤ outSub.peakCellSpace := by
                    have : wsSub'.cellCount ≤ max stSub.peakCellSpace (inpSub.inputCellSpace + wsSub'.cellCount) :=
                      (Nat.le_add_left _ _).trans (le_max_right _ _)
                    exact this.trans hm'.2.2.1
                  have hbSub'_out : wsSub'.bitSize ≤ outSub.peakBitSpace := by
                    have : wsSub'.bitSize ≤ max stSub.peakBitSpace (inpSub.inputBitSpace + wsSub'.bitSize) :=
                      (Nat.le_add_left _ _).trans (le_max_right _ _)
                    exact this.trans hm'.2.2.2
                  obtain ⟨stMid, hsM, soM, eoM, fsM, hrMid, hinvM, hfdM, hrbM, hucM, hbcM, hpCM, hpBM⟩ :=
                    exec_trA2WriteHeap inpSim hstage hinv htm.1 stSim rfl hfd hcPeak_cur hbPeak_cur
                      (by simp only [hv1, hv2]; exact ⟨hcSub'_out.trans hPeakS, hbSub'_out⟩)
                      hpC hpB
                  simp only [hv1, hv2] at hinvM hucM hbcM
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih rest
                      { stSub with
                        words := wsSub'
                        unitCost := stSub.unitCost + u₁ + u₂ + 1
                        bitCost := stSub.bitCost + b₁ + b₂ + (RAMCellLoc.heap table idx).bitLength + intBitLength val
                        peakCellSpace := max stSub.peakCellSpace (inpSub.inputCellSpace + wsSub'.cellCount)
                        peakBitSpace := max stSub.peakBitSpace (inpSub.inputBitSpace + wsSub'.bitSize) }
                      stMid outSub tailBits hsM soM eoM fsM
                      hrun hPeakS
                      ((Nat.le_add_left _ _).trans (le_max_right _ _))
                      ((Nat.le_add_left _ _).trans (le_max_right _ _))
                      hinvM hfdM (hrbM.trans hbits) hpCM hpBM htm.2 hF.2
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs',
                    RunsTo.trans hrMid hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                  · set Δu := u₁ + u₂ + 1
                    have hmF : 8 * a2StmtFactor (.writeHeap table idxE valE) * Δu ≤ 8 * F * Δu :=
                      Nat.mul_le_mul_right Δu (Nat.mul_le_mul_left 8 hF.1)
                    have hmul_split : 8 * F * (outSub.unitCost - (stSub.unitCost + u₁ + u₂ + 1)) + 8 * F * Δu =
                        8 * F * (outSub.unitCost - stSub.unitCost) := by
                      rw [← Nat.mul_add]; congr 1; dsimp [Δu]; have hge := hm'.1; dsimp only at hge; clear * - hge; omega
                    linarith only [hucE, hucM, hmF, hmul_split]
                  · set Δb := b₁ + b₂ + (natBitLength table + intBitLength idx) + intBitLength val
                    have hmF : 8 * a2StmtFactor (.writeHeap table idxE valE) * K * Δb ≤ 8 * F * K * Δb :=
                      Nat.mul_le_mul_right Δb (Nat.mul_le_mul_right K (Nat.mul_le_mul_left 8 hF.1))
                    have hmul_split : 8 * F * K * (outSub.bitCost - (stSub.bitCost + b₁ + b₂ + (RAMCellLoc.heap table idx).bitLength + intBitLength val)) +
                        8 * F * K * Δb = 8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                      rw [← Nat.mul_add]; congr 1; have hge := hm'.2.1; dsimp only [Δb, RAMCellLoc.bitLength] at hge ⊢; clear * - hge; omega
                    change stMid.bitCost ≤ stSim.bitCost + 8 * a2StmtFactor _ * K * Δb at hbcM
                    linarith only [hbcE, hbcM, hmF, hmul_split]
              | randBitHeap table idxE =>
                  cases hrem : stSub.remainingBits with
                  | nil => simp [runBitRAMFuel, hrem] at hrun
                  | cons bit bs' =>
                      simp only [runBitRAMFuel, hrem] at hrun
                      rcases hv1 : evalIntExpr inpSub stSub.frameDepth stSub.words idxE with ⟨idx, u₁, b₁⟩
                      simp only [hv1] at hrun
                      have hm' := runBitRAMFuel_cost_mono fuel rest _ outSub hrun
                      set val : ℤ := if bit then 1 else 0
                      set wsSub' := stSub.words.write (.heap table idx) val
                      have hcSub'_out : wsSub'.cellCount ≤ outSub.peakCellSpace := by
                        have : wsSub'.cellCount ≤ max stSub.peakCellSpace (inpSub.inputCellSpace + wsSub'.cellCount) :=
                          (Nat.le_add_left _ _).trans (le_max_right _ _)
                        exact this.trans hm'.2.2.1
                      have hbSub'_out : wsSub'.bitSize ≤ outSub.peakBitSpace := by
                        have : wsSub'.bitSize ≤ max stSub.peakBitSpace (inpSub.inputBitSpace + wsSub'.bitSize) :=
                          (Nat.le_add_left _ _).trans (le_max_right _ _)
                        exact this.trans hm'.2.2.2
                      have hbits_cons : stSim.remainingBits = bit :: (bs' ++ tailBits) := by
                        rw [hbits, hrem]; rfl
                      obtain ⟨stMid, hsM, soM, eoM, fsM, hrMid, hinvM, hfdM, hrbM, hucM, hbcM, hpCM, hpBM⟩ :=
                        exec_trA2RandBitHeap inpSim hstage hinv htm.1 bit (bs' ++ tailBits)
                          stSim rfl hfd hbits_cons hcPeak_cur hbPeak_cur
                          (by simp only [hv1]; exact ⟨hcSub'_out.trans hPeakS, hbSub'_out⟩)
                          hpC hpB
                      simp only [hv1] at hinvM hucM hbcM
                      obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                        ih rest
                          { stSub with
                            words := wsSub'
                            remainingBits := bs'
                            unitCost := stSub.unitCost + u₁ + 1
                            bitCost := stSub.bitCost + b₁ + (RAMCellLoc.heap table idx).bitLength + 1
                            peakCellSpace := max stSub.peakCellSpace (inpSub.inputCellSpace + wsSub'.cellCount)
                            peakBitSpace := max stSub.peakBitSpace (inpSub.inputBitSpace + wsSub'.bitSize) }
                          stMid outSub tailBits hsM soM eoM fsM
                          hrun hPeakS
                          ((Nat.le_add_left _ _).trans (le_max_right _ _))
                          ((Nat.le_add_left _ _).trans (le_max_right _ _))
                          hinvM hfdM hrbM hpCM hpBM htm.2 hF.2
                      refine ⟨stEnd, wsSubEnd, hs', so', eo', fs',
                        RunsTo.trans hrMid hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                      · set Δu := u₁ + 1
                        have hmF : 8 * a2StmtFactor (.randBitHeap table idxE) * Δu ≤ 8 * F * Δu :=
                          Nat.mul_le_mul_right Δu (Nat.mul_le_mul_left 8 hF.1)
                        have hmul_split : 8 * F * (outSub.unitCost - (stSub.unitCost + u₁ + 1)) + 8 * F * Δu =
                            8 * F * (outSub.unitCost - stSub.unitCost) := by
                          rw [← Nat.mul_add]; congr 1; dsimp [Δu]; have hge := hm'.1; dsimp only at hge; clear * - hge; omega
                        linarith only [hucE, hucM, hmF, hmul_split]
                      · set Δb := b₁ + (natBitLength table + intBitLength idx) + 1
                        have hmF : 8 * a2StmtFactor (.randBitHeap table idxE) * K * Δb ≤ 8 * F * K * Δb :=
                          Nat.mul_le_mul_right Δb (Nat.mul_le_mul_right K (Nat.mul_le_mul_left 8 hF.1))
                        have hmul_split : 8 * F * K * (outSub.bitCost - (stSub.bitCost + b₁ + (RAMCellLoc.heap table idx).bitLength + 1)) +
                            8 * F * K * Δb = 8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                          rw [← Nat.mul_add]; congr 1; have hge := hm'.2.1; dsimp only [Δb, RAMCellLoc.bitLength] at hge ⊢; clear * - hge; omega
                        change stMid.bitCost ≤ stSim.bitCost + 8 * a2StmtFactor _ * K * Δb at hbcM
                        linarith only [hbcE, hbcM, hmF, hmul_split]
              | freeHeap table idxE =>
                  simp only [runBitRAMFuel] at hrun
                  rcases hv1 : evalIntExpr inpSub stSub.frameDepth stSub.words idxE with ⟨idx, u₁, b₁⟩
                  simp only [hv1] at hrun
                  have hm' := runBitRAMFuel_cost_mono fuel rest _ outSub hrun
                  obtain ⟨stMid, soM, fsM, hrMid, hinvM, hfdM, hrbM, hucM, hbcM, hpCM, hpBM⟩ :=
                    exec_trA2FreeHeap inpSim hstage hinv htm.1 stSim rfl hfd hcPeak_cur hbPeak_cur hpC hpB
                  simp only [hv1] at hinvM hucM hbcM
                  obtain ⟨stEnd, wsSubEnd, hs', so', eo', fs', hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
                    ih rest
                      { stSub with
                        words := stSub.words.free (.heap table idx)
                        unitCost := stSub.unitCost + u₁ + 1
                        bitCost := stSub.bitCost + b₁ + (RAMCellLoc.heap table idx).bitLength }
                      stMid outSub tailBits highSid soM encOfSid fsM
                      hrun hPeakS
                      ((cellCount_free_le _ _).trans hSubC)
                      ((bitSize_free_le _ _).trans hSubB)
                      hinvM hfdM (hrbM.trans hbits) hpCM hpBM htm.2 hF.2
                  refine ⟨stEnd, wsSubEnd, hs', so', eo', fs',
                    RunsTo.trans hrMid hruns, hpop0, hcSubE, hbSubE, hinvE, hfdE, hrbE, ?_, ?_, hpCE, hpBE⟩
                  · set Δu := u₁ + 1
                    have hmF : 8 * a2StmtFactor (.freeHeap table idxE) * Δu ≤ 8 * F * Δu :=
                      Nat.mul_le_mul_right Δu (Nat.mul_le_mul_left 8 hF.1)
                    have hmul_split : 8 * F * (outSub.unitCost - (stSub.unitCost + u₁ + 1)) + 8 * F * Δu =
                        8 * F * (outSub.unitCost - stSub.unitCost) := by
                      rw [← Nat.mul_add]; congr 1; dsimp [Δu]; have hge := hm'.1; dsimp only at hge; clear * - hge; omega
                    linarith only [hucE, hucM, hmF, hmul_split]
                  · set Δb := b₁ + (natBitLength table + intBitLength idx)
                    have hmF : 8 * a2StmtFactor (.freeHeap table idxE) * K * Δb ≤ 8 * F * K * Δb :=
                      Nat.mul_le_mul_right Δb (Nat.mul_le_mul_right K (Nat.mul_le_mul_left 8 hF.1))
                    have hmul_split : 8 * F * K * (outSub.bitCost - (stSub.bitCost + b₁ + (RAMCellLoc.heap table idx).bitLength)) +
                        8 * F * K * Δb = 8 * F * K * (outSub.bitCost - stSub.bitCost) := by
                      rw [← Nat.mul_add]; congr 1; have hge := hm'.2.1; dsimp only [Δb, RAMCellLoc.bitLength] at hge ⊢; clear * - hge; omega
                    change stMid.bitCost ≤ stSim.bitCost + 8 * a2StmtFactor _ * K * Δb at hbcM
                    linarith only [hbcE, hbcM, hmF, hmul_split]

/-! ### 2. Top-level subroutine wrapper `exec_runA2Subroutine` at `frameDepth = 1` -/

theorem popDepth_one_of_isA2BaseStore {wsBase : WordStore} (hbase : IsA2BaseStore wsBase) :
    wsBase.popDepth 1 = wsBase := by
  cases wsBase with
  | mk live vals =>
      unfold WordStore.popDepth
      dsimp only
      have hkeep : ∀ loc ∈ live, loc.keepAtDepth 1 = true := by
        intro loc hm
        have hb := hbase.2 loc hm
        cases loc with
        | heap _ _ => rfl
        | localFrame d _ _ => dsimp [IsA2BaseLoc] at hb; subst hb; rfl
      congr 1
      · ext loc
        simp only [Finset.mem_filter, and_iff_left_iff_imp]
        exact hkeep loc
      · funext loc
        by_cases hm : loc ∈ live
        · rw [if_pos (hkeep loc hm)]
        · split_ifs
          · rfl
          · exact (hbase.1 loc hm).symm

theorem runBitRAMFuel_max_peak {d : ℕ} (inp : BitRAMInput d) (mc mb : ℕ) :
    ∀ (fuel : ℕ) (stack : List BitRAMCont) (st : BitRAMExecState),
      runBitRAMFuel inp fuel stack
        { st with peakCellSpace := max mc st.peakCellSpace, peakBitSpace := max mb st.peakBitSpace } =
      match runBitRAMFuel inp fuel stack st with
      | .halted out =>
          .halted { out with peakCellSpace := max mc out.peakCellSpace, peakBitSpace := max mb out.peakBitSpace }
      | .unusedBits => .unusedBits
      | .needMoreBits => .needMoreBits
      | .outOfFuel => .outOfFuel
  | 0, [], st => by
      simp only [runBitRAMFuel]
      split_ifs <;> rfl
  | 0, _ :: _, _ => rfl
  | fuel + 1, [], st => by
      simp only [runBitRAMFuel]
      split_ifs <;> rfl
  | fuel + 1, item :: rest, st => by
      cases item with
      | popScope prev =>
          dsimp only [runBitRAMFuel]
          rw [← runBitRAMFuel_max_peak inp mc mb fuel]
      | repeatLoop rem body =>
          cases rem <;> dsimp only [runBitRAMFuel] <;>
            rw [← runBitRAMFuel_max_peak inp mc mb fuel]
      | stmt s =>
          cases s with
          | skip | seq _ _ | localScope _ =>
              dsimp only [runBitRAMFuel]
              rw [← runBitRAMFuel_max_peak inp mc mb fuel]
          | writeHeap t e1 e2 =>
              dsimp only [runBitRAMFuel]
              rcases evalIntExpr inp st.frameDepth st.words e1 with ⟨idx, u₁, b₁⟩
              rcases evalIntExpr inp st.frameDepth st.words e2 with ⟨val, u₂, b₂⟩
              dsimp only
              rw [← runBitRAMFuel_max_peak inp mc mb fuel]
              simp only [max_assoc]
          | writeLocal v e1 e2 =>
              dsimp only [runBitRAMFuel]
              rcases evalIntExpr inp st.frameDepth st.words e1 with ⟨idx, u₁, b₁⟩
              rcases evalIntExpr inp st.frameDepth st.words e2 with ⟨val, u₂, b₂⟩
              dsimp only
              rw [← runBitRAMFuel_max_peak inp mc mb fuel]
              simp only [max_assoc]
          | freeHeap t e | freeLocal v e =>
              dsimp only [runBitRAMFuel]
              rcases evalIntExpr inp st.frameDepth st.words e with ⟨idx, u₁, b₁⟩
              dsimp only
              rw [← runBitRAMFuel_max_peak inp mc mb fuel]
          | randBitHeap t e =>
              cases hrem : st.remainingBits with
              | nil => simp [runBitRAMFuel, hrem]
              | cons _ _ =>
                  dsimp only [runBitRAMFuel]
                  simp only [hrem]
                  rcases evalIntExpr inp st.frameDepth st.words e with ⟨idx, u₁, b₁⟩
                  dsimp only
                  rw [← runBitRAMFuel_max_peak inp mc mb fuel]
                  simp only [max_assoc]
          | randBitLocal v e =>
              cases hrem : st.remainingBits with
              | nil => simp [runBitRAMFuel, hrem]
              | cons _ _ =>
                  dsimp only [runBitRAMFuel]
                  simp only [hrem]
                  rcases evalIntExpr inp st.frameDepth st.words e with ⟨idx, u₁, b₁⟩
                  dsimp only
                  rw [← runBitRAMFuel_max_peak inp mc mb fuel]
                  simp only [max_assoc]
          | ite c tB fB =>
              dsimp only [runBitRAMFuel]
              rcases evalBitCond inp st.frameDepth st.words c with ⟨flag, u, b⟩
              cases flag <;> dsimp only <;> rw [← runBitRAMFuel_max_peak inp mc mb fuel]
          | whileLoop c body =>
              dsimp only [runBitRAMFuel]
              rcases evalBitCond inp st.frameDepth st.words c with ⟨flag, u, b⟩
              cases flag <;> dsimp only <;> rw [← runBitRAMFuel_max_peak inp mc mb fuel]
          | repeatN countE body =>
              dsimp only [runBitRAMFuel]
              rcases evalIntExpr inp st.frameDepth st.words countE with ⟨cnt, u, b⟩
              dsimp only
              rw [← runBitRAMFuel_max_peak inp mc mb fuel]

theorem RunsTo.max_peak {d : ℕ} {inp : BitRAMInput d} {items : List BitRAMCont}
    {st₁ st₂ : BitRAMExecState} (mc mb : ℕ)
    (h : RunsTo inp items st₁ st₂) :
    RunsTo inp items
      { st₁ with peakCellSpace := max mc st₁.peakCellSpace, peakBitSpace := max mb st₁.peakBitSpace }
      { st₂ with peakCellSpace := max mc st₂.peakCellSpace, peakBitSpace := max mb st₂.peakBitSpace } := by
  rcases h with ⟨f, hf⟩
  refine ⟨f, fun rest k => ?_⟩
  rw [runBitRAMFuel_max_peak inp mc mb (f + k) (items ++ rest) st₁, hf rest k,
      runBitRAMFuel_max_peak inp mc mb k rest st₂]

theorem exec_runA2Subroutine {d m B T_max S_max : ℕ}
    {wsBase : WordStore} {inpSub : BitRAMInput d}
    (inpSim : BitRAMInput d)
    (progSub : BitRAMStmt)
    (hbase : IsA2BaseStore wsBase)
    (hstage : StagingA2Matches m B wsBase inpSub)
    (hT : 1 ≤ T_max)
    (htm : maxTableStmt progSub ≤ T_max)
    {bsSub : List Bool} {outSub : BitRAMExecOutcome}
    (hSubHalts : runBitRAMWithBits progSub inpSub WordStore.empty bsSub = some outSub)
    (hPeakS : outSub.peakCellSpace ≤ S_max)
    (tailBits : List Bool)
    (stSim : BitRAMExecState)
    (hwSim : stSim.words = wsBase)
    (hfdSim : stSim.frameDepth = 1)
    (hbitsSim : stSim.remainingBits = bsSub ++ tailBits) :
    let F := max 64 (a2StmtFactor progSub)
    let K := a2ParamBits m d T_max + (natBitLength S_max + 4)
    ∃ (stAfter : BitRAMExecState) (wsSubHeap : WordStore)
      (highSid : ℕ) (sidOfEnc : ℤ → Option ℕ) (encOfSid : ℕ → ℤ) (freeStack : List ℕ),
      RunsTo inpSim [.stmt (.localScope (trA2Stmt T_max progSub))] stSim stAfter ∧
      A2SimInv wsBase T_max S_max wsSubHeap stAfter.words highSid sidOfEnc encOfSid freeStack ∧
      (∀ d' v' i', (.localFrame d' v' i' : RAMCellLoc) ∉ wsSubHeap.live) ∧
      wsSubHeap.cellCount ≤ outSub.peakCellSpace ∧
      wsSubHeap.bitSize ≤ outSub.peakBitSpace ∧
      (∀ t < T_max, ∀ idx : ℤ,
        stAfter.words.read (.heap 10 (idx * (T_max : ℤ) + (t : ℤ))) = outSub.words.read (.heap t idx)) ∧
      stAfter.frameDepth = 1 ∧
      stAfter.remainingBits = tailBits ∧
      stAfter.unitCost ≤ stSim.unitCost + 8 * F * outSub.unitCost ∧
      stAfter.bitCost ≤ stSim.bitCost + 8 * F * K * outSub.bitCost ∧
      stAfter.peakCellSpace ≤ max stSim.peakCellSpace (a2CellBound wsBase inpSim S_max outSub.peakCellSpace) ∧
      stAfter.peakBitSpace ≤ max stSim.peakBitSpace (a2BitBound wsBase inpSim T_max S_max outSub.peakBitSpace) := by
  intro F K
  rw [runBitRAMWithBits_eq_some_iff] at hSubHalts
  rcases hSubHalts with ⟨fuel, hrun⟩
  have hemp_pop : WordStore.empty.popDepth 0 = WordStore.empty := by
    simp [WordStore.empty, WordStore.popDepth]
  rw [hemp_pop] at hrun
  let stSim0 : BitRAMExecState :=
    { stSim with peakCellSpace := 0, peakBitSpace := 0 }
  let stSimBody0 : BitRAMExecState :=
    { stSim0 with words := stSim0.words.popDepth 1, frameDepth := 2 }
  have hpop_base : stSim0.words.popDepth 1 = wsBase := by
    dsimp [stSim0]; rw [hwSim]; exact popDepth_one_of_isA2BaseStore hbase
  have hinv0 : A2SimInv wsBase T_max S_max WordStore.empty stSimBody0.words 0 (fun _ => none) (fun _ => 0) [] := by
    dsimp [stSimBody0]; rw [hpop_base]
    exact A2SimInv.init hbase hT hbase.2
  obtain ⟨stBodyEnd, wsSubEnd, hs', so', eo', fs', hrunsBody, hpop0, hcSubEnd, hbSubEnd,
    hinvEnd, hfdEnd, hrbEnd, hucEnd, hbcEnd, hpCEnd, hpBEnd⟩ :=
    simulate_trA2Stack (F := F) inpSim hstage (le_max_left 64 _)
      fuel [.stmt progSub]
      { words := WordStore.empty
        frameDepth := 0
        remainingBits := bsSub
        unitCost := 0
        bitCost := 0
        peakCellSpace := inpSub.inputCellSpace + WordStore.empty.cellCount
        peakBitSpace := inpSub.inputBitSpace + WordStore.empty.bitSize }
      stSimBody0 outSub tailBits 0 (fun _ => none) (fun _ => 0) []
      hrun hPeakS (Nat.le_add_left _ _) (Nat.le_add_left _ _)
      hinv0 rfl hbitsSim (Nat.zero_le _) (Nat.zero_le _)
      (by simp [maxTableStack, htm, hT])
      (by simp only [maxFactorStack, max_le_iff]; exact ⟨le_max_right 64 _, le_max_left 64 _⟩)
  have hscope0 : RunsTo inpSim [.stmt (.localScope (trA2Stmt T_max progSub))] stSim0
      { stBodyEnd with words := stBodyEnd.words.popDepth 1, frameDepth := 1 } := by
    have hs := RunsTo.localScope (inp := inpSim) (body := trA2Stmt T_max progSub) (st := stSim0) (stBody := stBodyEnd)
    have hfd0 : stSim0.frameDepth = 1 := hfdSim
    rw [hfd0] at hs
    exact hs hrunsBody
  have hscope := RunsTo.max_peak stSim.peakCellSpace stSim.peakBitSpace hscope0
  have hstSim_eq : { stSim0 with
      peakCellSpace := max stSim.peakCellSpace stSim0.peakCellSpace
      peakBitSpace := max stSim.peakBitSpace stSim0.peakBitSpace } = stSim := by
    cases stSim; simp [stSim0]
  rw [hstSim_eq] at hscope
  set stAfter : BitRAMExecState :=
    { stBodyEnd with
      words := stBodyEnd.words.popDepth 1
      frameDepth := 1
      peakCellSpace := max stSim.peakCellSpace stBodyEnd.peakCellSpace
      peakBitSpace := max stSim.peakBitSpace stBodyEnd.peakBitSpace }
  have hinvAfter : A2SimInv wsBase T_max S_max (heapOnlyWS wsSubEnd) stAfter.words hs' so' eo' fs' :=
    hinvEnd.popToDepth1
  refine ⟨stAfter, heapOnlyWS wsSubEnd, hs', so', eo', fs', hscope, hinvAfter,
    fun _ _ _ => by simp [heapOnlyWS, isHeapLoc],
    (cellCount_heapOnly_le _).trans hcSubEnd,
    (bitSize_heapOnly_le _).trans hbSubEnd,
    fun t ht idx => ?_,
    rfl, hrbEnd, ?_, ?_,
    max_le_max_left stSim.peakCellSpace hpCEnd,
    max_le_max_left stSim.peakBitSpace hpBEnd⟩
  · rw [hinvAfter.tab10_read t ht idx, heapOnly_read_heap, ← hpop0, wordStore_popDepth_read_heap]
  · dsimp [stAfter, stSimBody0, stSim0] at hucEnd ⊢; simpa using hucEnd
  · dsimp [stAfter, stSimBody0, stSim0] at hbcEnd ⊢; simpa using hbcEnd


end UL.C12LVE
