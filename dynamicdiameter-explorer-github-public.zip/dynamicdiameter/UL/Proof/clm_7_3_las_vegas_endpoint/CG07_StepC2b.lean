import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2b3
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL.C12LVE

open UL
open UL.Proof_lem_A_1

def a2RunExtractCleanStmt (d s₀_d nodeStride T_max : ℕ) (progA2 : BitRAMStmt) : BitRAMStmt :=
  .seq (.localScope (trA2Stmt T_max progA2))
  (.seq (extractFullNodeFromA2Regs d s₀_d nodeStride T_max)
        cleanupA2Stmt)

theorem exec_a2RunExtractAndCleanup {d s₀_d : ℕ} (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d)
    {inp inpSub : BitRAMInput d} {W C_cell C_bit : ℕ}
    {L B B_cert K_max T_max S_max j m k_blk : ℕ}
    (hBc1 : 1 ≤ B_cert) (hT3 : 3 ≤ T_max)
    (hj : j ≤ K_max) (hm_le : m ≤ 2 ^ L) (hk_le : k_blk * s₀_d ≤ m)
    (hW : (d + 1) * (2 * B_cert + 8) + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength ((2 ^ L + 2 * d + 4) * T_max) + natBitLength (s₀_d + 1) + L + 40 ≤ W)
    {progA2 : BitRAMStmt} (htm : maxTableStmt progA2 ≤ T_max)
    {wsHeap1 : WordStore} {regs1 : ℕ → ℤ}
    (hmod1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsHeap1)
    (hbnd1 : RegBounded W regs1)
    (hstage : StagingA2Matches m B wsHeap1 inpSub)
    {bs₁ tailBits : List Bool} {outA2 : BitRAMExecOutcome}
    (hA2_halts : runBitRAMWithBits progA2 inpSub WordStore.empty bs₁ = some outA2)
    (hPeakS : outA2.peakCellSpace ≤ S_max)
    (hcCeilA2 : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + posNodeStride d L +
        6 * S_max + 64 ≤ C_cell)
    (hbCeilA2 : inp.inputBitSpace + 2 * W * ((posDimWriteLocs d L K_max).card + posNodeStride d L) +
        32 * (W + 12) +
        (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 48) * outA2.peakBitSpace +
        4 * S_max * (natBitLength S_max + 12) +
        16 * natBitLength T_max + 24 * (natBitLength S_max + 4) + 300 ≤ C_bit)
    (hemp3 : ∀ off < posNodeStride d L,
      (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ wsHeap1.live)
    (hr_j : wsHeap1.read (.heap 0 10) = (j : ℤ))
    (hr_m : wsHeap1.read (.heap 9 110) = (m : ℤ))
    (hr_k : outA2.words.read (.heap 0 0) = (k_blk : ℤ))
    {hSeq : ℕ → ℕ} (hhSeq_lt : ∀ r < m, hSeq r < 2 ^ L)
    (hbuf : ∀ r < m, wsHeap1.read (.heap 8 (r : ℤ)) = (hSeq r : ℤ))
    {rawIdx : ℕ → ℕ} (hraw_lt : ∀ p < k_blk * s₀_d, rawIdx p < m)
    (hraw_read : ∀ p < k_blk * s₀_d, outA2.words.read (.heap 2 (p : ℤ)) = (rawIdx p : ℤ))
    {oRat : Fin d → ℚ} {sRat : ℚ}
    (hV_nn : 0 ≤ liftVariance (ratPointToEuclidean oRat) (sRat : ℝ))
    (hoA2 : ∀ c : Fin d,
      let oN := outA2.words.read (.heap 1 (2 * (c.val : ℤ)))
      let oD := outA2.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
      1 ≤ oD ∧ oRat c = (oN : ℚ) / (oD : ℚ) ∧
      intBitLength oN ≤ B_cert ∧ intBitLength oD ≤ B_cert)
    (hsA2 :
      let sN := outA2.words.read (.heap 1 (2 * (d : ℤ)))
      let sD := outA2.words.read (.heap 1 (2 * (d : ℤ) + 1))
      1 ≤ sD ∧ sRat = (sN : ℚ) / (sD : ℚ) ∧
      intBitLength sN ≤ B_cert ∧ intBitLength sD ≤ B_cert)
    (st1 : BitRAMExecState)
    (hfd1 : st1.frameDepth = 1)
    (hrf1 : HasRegFrame 1 wsHeap1 regs1 st1.words)
    (hbits1 : st1.remainingBits = bs₁ ++ tailBits)
    (hpC1 : st1.peakCellSpace ≤ C_cell)
    (hpB1 : st1.peakBitSpace ≤ C_bit) :
    let nodeStride := posNodeStride d L
    let locs := level3WriteLocs nodeStride j
    let F := max 64 (a2StmtFactor progA2)
    let K := a2ParamBits m d T_max + (natBitLength S_max + 4)
    let S_bits := natBitLength S_max + 4
    let rd1 : ℤ → ℤ := fun idx => outA2.words.read (.heap 1 idx)
    let oNum : ℕ → ℤ := fun c => if c < d then rd1 (2 * (c : ℤ)) else 0
    let oDen : ℕ → ℤ := fun c => if c < d then rd1 (2 * (c : ℤ) + 1) else 1
    let sqNum : ℕ → ℤ := fun i => (oNum i * 1 - 0 * oDen i) * (oNum i * 1 - 0 * oDen i)
    let sqDen : ℕ → ℤ := fun i => (oDen i * 1) * (oDen i * 1)
    let pSum := ratSumPairs sqNum sqDen d
    let V_num := rd1 (2 * (d : ℤ)) * pSum.2 - pSum.1 * rd1 (2 * (d : ℤ) + 1)
    let V_den := rd1 (2 * (d : ℤ) + 1) * pSum.2
    ∃ (stClean : BitRAMExecState) (wsHeapExt : WordStore) (regsExt : ℕ → ℤ),
      RunsTo inp [.stmt (a2RunExtractCleanStmt d s₀_d nodeStride T_max progA2)] st1 stClean ∧
      stClean.frameDepth = 1 ∧
      HasRegFrame 1 wsHeapExt regsExt stClean.words ∧
      RegBounded W regsExt ∧
      stClean.remainingBits = tailBits ∧
      stClean.peakCellSpace ≤ C_cell ∧
      stClean.peakBitSpace ≤ C_bit ∧
      stClean.unitCost ≤ st1.unitCost + 8 * F * outA2.unitCost +
        (260 * d + 40 * (k_blk * s₀_d) + 320) + (32 * S_max + 32) ∧
      stClean.bitCost ≤ st1.bitCost + 8 * F * K * outA2.bitCost +
        ((60 * d + 40 * (k_blk * s₀_d) + 180) * W * W) +
        (8 * (3 * natBitLength T_max + 2 * S_bits + 36) * outA2.peakBitSpace +
          S_max * (72 * S_bits + 512) + 28 * S_bits + 400) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsHeapExt ∧
      NodeGeomStored d nodeStride B_cert j oRat V_num V_den
        (liftVariance (ratPointToEuclidean oRat) (sRat : ℝ)) wsHeapExt ∧
      wsHeapExt.read (.heap 3 (nodeCellAddr nodeStride j 0)) = 0 ∧
      wsHeapExt.read (.heap 3 (nodeCellAddr nodeStride j 1)) = (m : ℤ) ∧
      wsHeapExt.read (.heap 3 (nodeCellAddr nodeStride j 2)) = (k_blk : ℤ) ∧
      (∀ p < k_blk * s₀_d,
        wsHeapExt.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * d + p))) =
          (hSeq (rawIdx p) : ℤ)) ∧
      (∀ off : ℕ, 6 + 2 * d + k_blk * s₀_d ≤ off → off < nodeStride →
        (.heap 3 (nodeCellAddr nodeStride j off) : RAMCellLoc) ∉ wsHeapExt.live) ∧
      (∀ loc : RAMCellLoc, loc ∉ locs →
        (loc ∈ wsHeapExt.live ↔ loc ∈ wsHeap1.live) ∧ wsHeapExt.vals loc = wsHeap1.vals loc) := by
  dsimp only
  set nodeStride := posNodeStride d L
  set locs := level3WriteLocs nodeStride j
  set F := max 64 (a2StmtFactor progA2)
  set K := a2ParamBits m d T_max + (natBitLength S_max + 4)
  set S_bits := natBitLength S_max + 4
  set rd1 : ℤ → ℤ := fun idx => outA2.words.read (.heap 1 idx)
  set oNum : ℕ → ℤ := fun c => if c < d then rd1 (2 * (c : ℤ)) else 0
  set oDen : ℕ → ℤ := fun c => if c < d then rd1 (2 * (c : ℤ) + 1) else 1
  set sqNum : ℕ → ℤ := fun i => (oNum i * 1 - 0 * oDen i) * (oNum i * 1 - 0 * oDen i)
  set sqDen : ℕ → ℤ := fun i => (oDen i * 1) * (oDen i * 1)
  set pSum := ratSumPairs sqNum sqDen d
  set V_num := rd1 (2 * (d : ℤ)) * pSum.2 - pSum.1 * rd1 (2 * (d : ℤ) + 1)
  set V_den := rd1 (2 * (d : ℤ) + 1) * pSum.2
  have hbase1 : IsA2BaseStore st1.words := isA2BaseStore_of_regFrame1 hmod1 hrf1
  have hstage1 : StagingA2Matches m B st1.words inpSub := stagingA2Matches_of_regFrame1 hrf1 hstage
  obtain ⟨stAfterA2, wsSubHeap, hs', so', eo', fs', hrunA2, hinvA2, hnoLocSub, hcSub, hbSub,
    hread10, hfdA2, hrbA2, hucA2, hbcA2, hpCA2_raw, hpBA2_raw⟩ :=
    exec_runA2Subroutine inp progA2 hbase1 hstage1 (by clear * - hT3; omega) htm hA2_halts hPeakS
      tailBits st1 rfl hfd1 hbits1
  obtain ⟨hcH1, hbH1⟩ := hmod1.space_le
  have h0c : WordStore.empty.cellCount = 0 := rfl
  have h0b : WordStore.empty.bitSize = 0 := rfl
  rw [h0c, zero_add] at hcH1; rw [h0b, zero_add] at hbH1
  obtain ⟨hcSt1, hbSt1⟩ := hrf1.space_le (by decide : 1 ≤ 4) hbnd1
  have ha2C_le : a2CellBound st1.words inp S_max outA2.peakCellSpace ≤ C_cell := by
    unfold a2CellBound
    have hm4 : 4 * outA2.peakCellSpace ≤ 4 * S_max := Nat.mul_le_mul_left 4 hPeakS
    linarith only [hcH1, hcSt1, hm4, hcCeilA2]
  have ha2B_le : a2BitBound st1.words inp T_max S_max outA2.peakBitSpace ≤ C_bit := by
    unfold a2BitBound; dsimp only [S_bits] at hbCeilA2 ⊢
    have hmS : 4 * S_max * ((natBitLength S_max + 4) + 8) = 4 * S_max * (natBitLength S_max + 12) := by ring
    have hw_add : 2 * W * ((posDimWriteLocs d L K_max).card + nodeStride) =
        2 * W * (posDimWriteLocs d L K_max).card + 2 * W * nodeStride := by ring
    have hns0 : 0 ≤ 2 * W * nodeStride := Nat.zero_le _
    linarith only [hbH1, hbSt1, hmS, hw_add, hns0, hbCeilA2]
  have hpCA2 : stAfterA2.peakCellSpace ≤ C_cell := hpCA2_raw.trans (max_le hpC1 ha2C_le)
  have hpBA2 : stAfterA2.peakBitSpace ≤ C_bit := hpBA2_raw.trans (max_le hpB1 ha2B_le)
  set wsSimHeap₀ := heapOnlyWS stAfterA2.words
  have hrfA2 : HasRegFrame 1 wsSimHeap₀ regs1 stAfterA2.words :=
    hasRegFrame_heapOnly_afterA2 hrf1 hinvA2 hnoLocSub
  obtain ⟨hcA2_sim, hbA2_sim⟩ := hinvA2.space_bounds
  have hcSim0 : inp.inputCellSpace + wsSimHeap₀.cellCount + nodeStride + 16 ≤ C_cell := by
    have h1 := cellCount_heapOnly_le stAfterA2.words
    have hm4 : 4 * wsSubHeap.cellCount ≤ 4 * S_max := Nat.mul_le_mul_left 4 (hcSub.trans hPeakS)
    linarith only [h1, hcA2_sim, hcH1, hcSt1, hm4, hcCeilA2]
  have hbSim0 : inp.inputBitSpace + wsSimHeap₀.bitSize + 2 * W * nodeStride + 16 * (W + 12) ≤ C_bit := by
    have h1 := bitSize_heapOnly_le stAfterA2.words
    have hmSub : (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 36) * wsSubHeap.bitSize ≤
        (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 48) * outA2.peakBitSpace :=
      Nat.mul_le_mul (by clear * -; omega) hbSub
    have hmS : 4 * S_max * ((natBitLength S_max + 4) + 8) = 4 * S_max * (natBitLength S_max + 12) := by ring
    have hw_add : 2 * W * ((posDimWriteLocs d L K_max).card + nodeStride) =
        2 * W * (posDimWriteLocs d L K_max).card + 2 * W * nodeStride := by ring
    dsimp only [S_bits] at hbA2_sim hbCeilA2
    have h0_a : 0 ≤ (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 48) * outA2.peakBitSpace := Nat.zero_le _
    have h0_b : 0 ≤ 4 * S_max * (natBitLength S_max + 12) := Nat.zero_le _
    linarith only [h1, hbA2_sim, hbH1, hbSt1, hmSub, hmS, hw_add, h0_a, h0_b, hbCeilA2]
  have hread_base0 : ∀ {t : ℕ} (_ht : t < 10) (idx : ℤ),
      wsSimHeap₀.read (.heap t idx) = wsHeap1.read (.heap t idx) := by
    intro t ht idx
    rw [heapOnly_read_heap, wordStore_read_eq_vals hinvA2.wfSim,
        hinvA2.base_vals (.heap t idx) ht, ← wordStore_read_eq_vals hrf1.wf, hrf1.read_heap]
  have hemp3_0 : ∀ off < nodeStride, (.heap 3 (nodeCellAddr nodeStride j off) : RAMCellLoc) ∉ wsSimHeap₀.live := by
    intro off hoff hm
    have hmSim : (.heap 3 (nodeCellAddr nodeStride j off) : RAMCellLoc) ∈ stAfterA2.words.live :=
      (Finset.mem_filter.mp hm).1
    have hm1 := (hinvA2.base_live (.heap 3 _) (by show 3 < 10; decide)).mp hmSim
    have hmH1 := (hrf1.below_live (.heap 3 _) rfl).mp hm1
    exact hemp3 off hoff hmH1
  have hr10_eq : ∀ {t : ℕ} (ht : t < T_max) (idx : ℤ),
      wsSimHeap₀.read (.heap 10 (idx * (T_max : ℤ) + (t : ℤ))) = outA2.words.read (.heap t idx) := by
    intro t ht idx; rw [heapOnly_read_heap]; exact hread10 t ht idx
  have hr_k0 : wsSimHeap₀.read (.heap 10 0) = (k_blk : ℤ) := by
    have h0 := hr10_eq (t := 0) (by clear * - hT3; omega) 0
    simpa using h0.trans hr_k
  have hraw_0 : ∀ p < k_blk * s₀_d,
      wsSimHeap₀.read (.heap 10 (((p * T_max + 2 : ℕ) : ℤ))) = (rawIdx p : ℤ) := by
    intro p hp
    have h2 := hr10_eq (t := 2) (by clear * - hT3; omega) (p : ℤ)
    have hcast : ((p : ℤ) * (T_max : ℤ) + ((2 : ℕ) : ℤ)) = (((p * T_max + 2 : ℕ) : ℤ)) := by push_cast; ring
    rw [← hcast, h2]; exact hraw_read p hp
  have h10_1_eq : ∀ u : ℕ,
      wsSimHeap₀.read (.heap 10 (((u * T_max + 1 : ℕ) : ℤ))) = outA2.words.read (.heap 1 (u : ℤ)) := by
    intro u
    have h1 := hr10_eq (t := 1) (by clear * - hT3; omega) (u : ℤ)
    have hcast : ((u : ℤ) * (T_max : ℤ) + ((1 : ℕ) : ℤ)) = (((u * T_max + 1 : ℕ) : ℤ)) := by push_cast; ring
    rw [← hcast]; exact h1
  have ho10 : ∀ c : Fin d,
      let oN := wsSimHeap₀.read (.heap 10 ((((2 * c.val) * T_max + 1 : ℕ) : ℤ)))
      let oD := wsSimHeap₀.read (.heap 10 ((((2 * c.val + 1) * T_max + 1 : ℕ) : ℤ)))
      1 ≤ oD ∧ oRat c = (oN : ℚ) / (oD : ℚ) ∧
      intBitLength oN ≤ B_cert ∧ intBitLength oD ≤ B_cert := by
    intro c; dsimp only
    rw [h10_1_eq (2 * c.val), h10_1_eq (2 * c.val + 1)]
    have hc1 : (((2 * c.val : ℕ) : ℤ)) = 2 * (c.val : ℤ) := by push_cast; ring
    have hc2 : (((2 * c.val + 1 : ℕ) : ℤ)) = 2 * (c.val : ℤ) + 1 := by push_cast; ring
    rw [hc1, hc2]; exact hoA2 c
  have hs10 :
      let sN := wsSimHeap₀.read (.heap 10 ((((2 * d) * T_max + 1 : ℕ) : ℤ)))
      let sD := wsSimHeap₀.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)))
      1 ≤ sD ∧ sRat = (sN : ℚ) / (sD : ℚ) ∧
      intBitLength sN ≤ B_cert ∧ intBitLength sD ≤ B_cert := by
    dsimp only
    rw [h10_1_eq (2 * d), h10_1_eq (2 * d + 1)]
    have hc1 : (((2 * d : ℕ) : ℤ)) = 2 * (d : ℤ) := by push_cast; ring
    have hc2 : (((2 * d + 1 : ℕ) : ℤ)) = 2 * (d : ℤ) + 1 := by push_cast; ring
    rw [hc1, hc2]; exact hsA2
  obtain ⟨wsSimHeap₁, regsExt, sExt, hmSim1, hbndExt, hgeomSim1, hrExt0, hrExt1, hrExt2,
    hread_bh_sim1, hunused_sim1, hunchSim1⟩ :=
    exec_extractFullNodeFromA2Regs hd1 hs₀1 (by decide : 1 ≤ 4) hBc1 hT3 hj hm_le hk_le hW
      hrfA2.wfHeap hcSim0 hbSim0 hemp3_0
      (hread_base0 (by decide) 10 |>.trans hr_j)
      (hread_base0 (by decide) 110 |>.trans hr_m)
      hr_k0 hhSeq_lt
      (fun r hr => hread_base0 (by decide) (r : ℤ) |>.trans (hbuf r hr))
      hraw_lt hraw_0 hV_nn ho10 hs10 hbnd1
  obtain ⟨stAfterExt, hrunExt, hrfExt, _, hfdExt, hrbExt, hucExt, hbcExt, hpCExt, hpBExt⟩ :=
    sExt stAfterA2 hfdA2 hrfA2 hpCA2 hpBA2
  have hoNum_eq : ∀ c, (if c < d then wsSimHeap₀.read (.heap 10 ((((2 * c) * T_max + 1 : ℕ) : ℤ))) else 0) = oNum c := by
    intro c; dsimp only [oNum, rd1]
    split_ifs with hc
    · rw [h10_1_eq (2 * c)]; push_cast; rfl
    · rfl
  have hoDen_eq : ∀ c, (if c < d then wsSimHeap₀.read (.heap 10 ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ))) else 1) = oDen c := by
    intro c; dsimp only [oDen, rd1]
    split_ifs with hc
    · rw [h10_1_eq (2 * c + 1)]; push_cast; rfl
    · rfl
  have hVN_id : extractedVNum10 d T_max wsSimHeap₀ = V_num := by
    unfold extractedVNum10; dsimp only
    simp only [hoNum_eq, hoDen_eq, h10_1_eq (2 * d), h10_1_eq (2 * d + 1)]
    have hc1 : (((2 * d : ℕ) : ℤ)) = 2 * (d : ℤ) := by push_cast; rfl
    have hc2 : (((2 * d + 1 : ℕ) : ℤ)) = 2 * (d : ℤ) + 1 := by push_cast; rfl
    rw [hc1, hc2]
  have hVD_id : extractedVDen10 d T_max wsSimHeap₀ = V_den := by
    unfold extractedVDen10; dsimp only
    simp only [hoNum_eq, hoDen_eq, h10_1_eq (2 * d + 1)]
    have hc2 : (((2 * d + 1 : ℕ) : ℤ)) = 2 * (d : ℤ) + 1 := by push_cast; rfl
    rw [hc2]
  rw [hVN_id, hVD_id] at hgeomSim1
  set wsHeapExt := copyRangeToBase locs wsHeap1 wsSimHeap₁
  set wsBaseNew := baseOnlyWS stAfterExt.words
  have hlocs_sub : locs ⊆ posDimWriteLocs d L K_max :=
    level3WriteLocs_sub_posDimWriteLocs (Nat.le_succ_of_le hj)
  have hwfHeapExt : WellFormedWS wsHeapExt := by
    intro loc hnot
    dsimp [wsHeapExt, copyRangeToBase] at hnot ⊢
    by_cases hL : loc ∈ locs
    · rw [if_pos hL]
      exact hmSim1.wf loc (fun hm => hnot (Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨hm, hL⟩)))
    · rw [if_neg hL]
      exact hmod1.wf loc (fun hm => hnot (Finset.mem_union_left _ (Finset.mem_sdiff.mpr ⟨hm, hL⟩)))
  have hmodHeapExt : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsHeapExt := by
    refine
      { wf := hwfHeapExt
        live_sub := fun loc hm => by
          simp only [WordStore.empty, Finset.empty_union]
          dsimp [wsHeapExt, copyRangeToBase] at hm
          rcases Finset.mem_union.mp hm with h1 | h2
          · have hb := hmod1.live_sub (Finset.mem_sdiff.mp h1).1
            simpa [WordStore.empty] using hb
          · exact hlocs_sub (Finset.mem_inter.mp h2).2
        unchanged := fun loc hn => by
          have hnLive : loc ∉ wsHeapExt.live := fun hm => by
            dsimp [wsHeapExt, copyRangeToBase] at hm
            rcases Finset.mem_union.mp hm with h1 | h2
            · have hb := hmod1.live_sub (Finset.mem_sdiff.mp h1).1
              simp only [WordStore.empty, Finset.empty_union] at hb
              exact hn hb
            · exact hn (hlocs_sub (Finset.mem_inter.mp h2).2)
          exact ⟨by simp [hnLive, WordStore.empty], by rw [hwfHeapExt loc hnLive]; rfl⟩
        bounded_write := fun loc hm _ => by
          dsimp [wsHeapExt, copyRangeToBase] at hm ⊢
          rcases Finset.mem_union.mp hm with h1 | h2
          · obtain ⟨hmB, hnL⟩ := Finset.mem_sdiff.mp h1
            rw [if_neg hnL]
            have hp : loc ∈ posDimWriteLocs d L K_max := by
              have hb := hmod1.live_sub hmB
              simpa [WordStore.empty] using hb
            exact hmod1.bounded_write loc hmB hp
          · obtain ⟨hmS, hL⟩ := Finset.mem_inter.mp h2
            rw [if_pos hL]
            exact hmSim1.bounded_write loc hmS hL }
  have hinLocs : ∀ loc ∈ locs,
      (loc ∈ wsHeapExt.live ↔ loc ∈ wsSimHeap₁.live) ∧
      wsHeapExt.vals loc = wsSimHeap₁.vals loc ∧
      wsHeapExt.read loc = wsSimHeap₁.read loc := by
    intro loc hL
    have hlv : loc ∈ wsHeapExt.live ↔ loc ∈ wsSimHeap₁.live := by
      dsimp [wsHeapExt, copyRangeToBase]; simp [hL]
    have hvl : wsHeapExt.vals loc = wsSimHeap₁.vals loc := by
      dsimp [wsHeapExt, copyRangeToBase]; rw [if_pos hL]
    exact ⟨hlv, hvl, by rw [wordStore_read_eq_vals hwfHeapExt, wordStore_read_eq_vals hmSim1.wf, hvl]⟩
  have houtLocs : ∀ loc ∉ locs,
      (loc ∈ wsHeapExt.live ↔ loc ∈ wsHeap1.live) ∧
      wsHeapExt.vals loc = wsHeap1.vals loc := by
    intro loc hnL
    exact ⟨by dsimp [wsHeapExt, copyRangeToBase]; simp [hnL],
           by dsimp [wsHeapExt, copyRangeToBase]; rw [if_neg hnL]⟩
  have hbaseNew_ok : IsA2BaseStore wsBaseNew := isA2BaseStore_baseOnly hrfExt.wf
  have hrfClean : HasRegFrame 1 wsHeapExt regsExt wsBaseNew := by
    refine
      { wfHeap := hwfHeapExt
        wf := hbaseNew_ok.1
        heapClean := noLocal_of_modPosDim hmodHeapExt
        below_live := fun loc hk => by
          cases loc with
          | heap t idx =>
              by_cases ht : t < 10
              · have hb : isBaseLocBool (.heap t idx) = true := by simp [isBaseLocBool, ht]
                have hmB : (.heap t idx : RAMCellLoc) ∈ wsBaseNew.live ↔ (.heap t idx : RAMCellLoc) ∈ wsSimHeap₁.live := by
                  dsimp [wsBaseNew, baseOnlyWS]
                  rw [Finset.mem_filter, and_iff_left hb]
                  exact hrfExt.below_live (.heap t idx) rfl
                rw [hmB]
                by_cases hL : (.heap t idx : RAMCellLoc) ∈ locs
                · exact (hinLocs _ hL).1.symm
                · have u1 := (hunchSim1 _ hL).1
                  have u0 : (.heap t idx : RAMCellLoc) ∈ wsSimHeap₀.live ↔ (.heap t idx : RAMCellLoc) ∈ stAfterA2.words.live := by
                    simp [wsSimHeap₀, heapOnlyWS, isHeapLoc]
                  have ub := hinvA2.base_live (.heap t idx) ht
                  have uh := hrf1.below_live (.heap t idx) rfl
                  exact u1.trans (u0.trans (ub.trans (uh.trans (houtLocs _ hL).1.symm)))
              · have hb : isBaseLocBool (.heap t idx) = false := by simp [isBaseLocBool, ht]
                have hnB : (.heap t idx : RAMCellLoc) ∉ wsBaseNew.live := by
                  dsimp [wsBaseNew, baseOnlyWS]; simp [hb]
                have hnH : (.heap t idx : RAMCellLoc) ∉ wsHeapExt.live := by
                  intro hm; exact ht (isA2BaseStore_of_modPosDim hmodHeapExt |>.2 _ hm)
                simp [hnB, hnH]
          | localFrame d' v i =>
              simp only [keepBelowDepth, decide_eq_true_eq] at hk
              have hd0 : d' = 0 := by omega
              subst hd0
              have hb : isBaseLocBool (.localFrame 0 v i) = false := rfl
              have hnB : (.localFrame 0 v i : RAMCellLoc) ∉ wsBaseNew.live := by
                dsimp [wsBaseNew, baseOnlyWS]; simp [hb]
              have hnH : (.localFrame 0 v i : RAMCellLoc) ∉ wsHeapExt.live := by
                intro hm
                have hd1_eq := isA2BaseStore_of_modPosDim hmodHeapExt |>.2 _ hm
                simp [IsA2BaseLoc] at hd1_eq
              simp [hnB, hnH]
        below_vals := fun loc hk => by
          cases loc with
          | heap t idx =>
              by_cases ht : t < 10
              · have hb : isBaseLocBool (.heap t idx) = true := by simp [isBaseLocBool, ht]
                have hvB : wsBaseNew.vals (.heap t idx) = wsSimHeap₁.vals (.heap t idx) := by
                  dsimp [wsBaseNew, baseOnlyWS]; rw [if_pos hb]
                  exact hrfExt.below_vals (.heap t idx) rfl
                rw [hvB]
                by_cases hL : (.heap t idx : RAMCellLoc) ∈ locs
                · exact (hinLocs _ hL).2.1.symm
                · have u1 := (hunchSim1 _ hL).2
                  have u0 : wsSimHeap₀.vals (.heap t idx) = stAfterA2.words.vals (.heap t idx) := rfl
                  have ub := hinvA2.base_vals (.heap t idx) ht
                  have uh := hrf1.below_vals (.heap t idx) rfl
                  exact u1.trans (u0.trans (ub.trans (uh.trans (houtLocs _ hL).2.symm)))
              · have hb : isBaseLocBool (.heap t idx) = false := by simp [isBaseLocBool, ht]
                have hv0 : wsBaseNew.vals (.heap t idx) = 0 := by dsimp [wsBaseNew, baseOnlyWS]; rw [if_neg (by simp [hb])]
                have hnH : (.heap t idx : RAMCellLoc) ∉ wsHeapExt.live := by
                  intro hm; exact ht (isA2BaseStore_of_modPosDim hmodHeapExt |>.2 _ hm)
                rw [hv0, hwfHeapExt _ hnH]
          | localFrame d' v i =>
              simp only [keepBelowDepth, decide_eq_true_eq] at hk
              have hd0 : d' = 0 := by omega
              subst hd0
              have hv0 : wsBaseNew.vals (.localFrame 0 v i) = 0 := rfl
              have hnH : (.localFrame 0 v i : RAMCellLoc) ∉ wsHeapExt.live := by
                intro hm
                have hd1_eq := isA2BaseStore_of_modPosDim hmodHeapExt |>.2 _ hm
                simp [IsA2BaseLoc] at hd1_eq
              rw [hv0, hwfHeapExt _ hnH]
        above_empty := fun d' hd' v i hm => by
          have hb := (Finset.mem_filter.mp hm).2
          simp [isBaseLocBool] at hb; omega
        frame_bound := fun v i hm => hrfExt.frame_bound v i (Finset.mem_filter.mp hm).1
        reg_read := fun r hr => by
          rw [wordStore_read_eq_vals hbaseNew_ok.1]
          have hb : isBaseLocBool (.localFrame 1 r 0) = true := rfl
          have hv : wsBaseNew.vals (.localFrame 1 r 0) = stAfterExt.words.vals (.localFrame 1 r 0) := by
            dsimp [wsBaseNew, baseOnlyWS]; rw [if_pos hb]
          rw [hv, ← wordStore_read_eq_vals hrfExt.wf]
          exact hrfExt.reg_read r hr
        reg_zero := hrfExt.reg_zero }
  have hinvExt : A2SimInv wsBaseNew T_max S_max wsSubHeap stAfterExt.words hs' so' eo' fs' := by
    refine hinvA2.replaceBase hbaseNew_ok hrfExt.wf ?_ ?_ ?_ ?_
    · intro loc hb
      have hbb : isBaseLocBool loc = true := (isBaseLocBool_iff loc).mpr hb
      dsimp [wsBaseNew, baseOnlyWS]; simp [hbb]
    · intro loc hb
      have hbb : isBaseLocBool loc = true := (isBaseLocBool_iff loc).mpr hb
      dsimp [wsBaseNew, baseOnlyWS]; rw [if_pos hbb]
    · intro loc hnb
      cases loc with
      | heap t idx =>
          have ht10 : ¬ t < 10 := hnb
          have hnL : (.heap t idx : RAMCellLoc) ∉ locs := fun hL =>
            ht10 (posDimWriteLocs_isA2Base _ (hlocs_sub hL))
          exact (hrfExt.below_live (.heap t idx) rfl).trans
            ((hunchSim1 _ hnL).1.trans (by simp [wsSimHeap₀, heapOnlyWS, isHeapLoc]))
      | localFrame d' v i =>
          have hd_ne1 : d' ≠ 1 := hnb
          rcases lt_trichotomy d' 1 with hlt | rfl | hgt
          · have hd0 : d' = 0 := by omega
            subst hd0
            have hnE : (.localFrame 0 v i : RAMCellLoc) ∉ stAfterExt.words.live := by
              rw [hrfExt.below_live _ (by simp [keepBelowDepth])]
              intro hm1
              have hnL : (.localFrame 0 v i : RAMCellLoc) ∉ locs := fun hL => by
                rcases posDimWriteLocs_isHeap _ (hlocs_sub hL) with ⟨_, _, _, hc⟩; cases hc
              have hm0 := (hunchSim1 _ hnL).1.mp hm1
              simp [wsSimHeap₀, heapOnlyWS, isHeapLoc] at hm0
            have hnA : (.localFrame 0 v i : RAMCellLoc) ∉ stAfterA2.words.live :=
              fun hm => by
                rcases hinvA2.live_cases _ hm with hb | ⟨_, _, _, hc⟩ | ⟨_, _, _, hc⟩
                · exact hnb hb
                · injection hc with hd; omega
                · cases hc
            simp [hnE, hnA]
          · exact absurd rfl hd_ne1
          · simp [hrfExt.above_empty d' hgt v i, hrfA2.above_empty d' hgt v i]
    · intro loc hnb
      cases loc with
      | heap t idx =>
          have ht10 : ¬ t < 10 := hnb
          have hnL : (.heap t idx : RAMCellLoc) ∉ locs := fun hL =>
            ht10 (posDimWriteLocs_isA2Base _ (hlocs_sub hL))
          exact (hrfExt.below_vals (.heap t idx) rfl).trans (hunchSim1 _ hnL).2
      | localFrame d' v i =>
          have hd_ne1 : d' ≠ 1 := hnb
          rcases lt_trichotomy d' 1 with hlt | rfl | hgt
          · have hd0 : d' = 0 := by omega
            subst hd0
            have hnE : (.localFrame 0 v i : RAMCellLoc) ∉ stAfterExt.words.live := by
              rw [hrfExt.below_live _ (by simp [keepBelowDepth])]
              intro hm1
              have hnL : (.localFrame 0 v i : RAMCellLoc) ∉ locs := fun hL => by
                rcases posDimWriteLocs_isHeap _ (hlocs_sub hL) with ⟨_, _, _, hc⟩; cases hc
              have hm0 := (hunchSim1 _ hnL).1.mp hm1
              simp [wsSimHeap₀, heapOnlyWS, isHeapLoc] at hm0
            have hnA : (.localFrame 0 v i : RAMCellLoc) ∉ stAfterA2.words.live :=
              fun hm => by
                rcases hinvA2.live_cases _ hm with hb | ⟨_, _, _, hc⟩ | ⟨_, _, _, hc⟩
                · exact hnb hb
                · injection hc with hd; omega
                · cases hc
            rw [hrfExt.wf _ hnE, hinvA2.wfSim _ hnA]
          · exact absurd rfl hd_ne1
          · rw [hrfExt.wf _ (hrfExt.above_empty d' hgt v i), hinvA2.wfSim _ (hrfA2.above_empty d' hgt v i)]
  obtain ⟨stClean, hrunClean, hwClean, hfdClean, hrbClean, hucClean, hbcClean, hpCClean_raw, hpBClean_raw⟩ :=
    exec_cleanupA2Stmt_tight inp stAfterExt hinvExt hnoLocSub hcSub hbSub
  obtain ⟨hcHExt, hbHExt⟩ := hmodHeapExt.space_le
  rw [h0c, zero_add] at hcHExt; rw [h0b, zero_add] at hbHExt
  obtain ⟨hcBN, hbBN⟩ := hrfClean.space_le (by decide : 1 ≤ 4) hbndExt
  have ha2C_clean : a2CellBound wsBaseNew inp S_max outA2.peakCellSpace ≤ C_cell := by
    unfold a2CellBound
    have hm4 : 4 * outA2.peakCellSpace ≤ 4 * S_max := Nat.mul_le_mul_left 4 hPeakS
    linarith only [hcHExt, hcBN, hm4, hcCeilA2]
  have ha2B_clean : a2BitBound wsBaseNew inp T_max S_max outA2.peakBitSpace ≤ C_bit := by
    unfold a2BitBound; dsimp only [S_bits] at hbCeilA2 ⊢
    have hmS : 4 * S_max * ((natBitLength S_max + 4) + 8) = 4 * S_max * (natBitLength S_max + 12) := by ring
    have hw_add : 2 * W * ((posDimWriteLocs d L K_max).card + nodeStride) =
        2 * W * (posDimWriteLocs d L K_max).card + 2 * W * nodeStride := by ring
    have hns0 : 0 ≤ 2 * W * nodeStride := Nat.zero_le _
    linarith only [hbHExt, hbBN, hmS, hw_add, hns0, hbCeilA2]
  have hpCClean : stClean.peakCellSpace ≤ C_cell := hpCClean_raw.trans (max_le hpCExt ha2C_clean)
  have hpBClean : stClean.peakBitSpace ≤ C_bit := hpBClean_raw.trans (max_le hpBExt ha2B_clean)
  have hstride_p : ∀ p ≤ k_blk * s₀_d, 6 + 2 * d + p < nodeStride := by
    intro p hp; dsimp [nodeStride, posNodeStride]; clear * - hp hk_le hm_le; omega
  have hstride : 6 + 2 * d ≤ nodeStride := Nat.le_of_lt (hstride_p 0 (Nat.zero_le _))
  have hgeomExt : NodeGeomStored d nodeStride B_cert j oRat V_num V_den
      (liftVariance (ratPointToEuclidean oRat) (sRat : ℝ)) wsHeapExt :=
    hgeomSim1.unchanged (fun off hoff =>
      (hinLocs _ (mem_level3WriteLocs (lt_of_lt_of_le hoff hstride))).2.2)
  refine ⟨stClean, wsHeapExt, regsExt,
    RunsTo.seq hrunA2 (RunsTo.seq hrunExt hrunClean),
    by rw [hfdClean, hfdExt],
    by rw [hwClean]; exact hrfClean,
    hbndExt,
    by rw [hrbClean, hrbExt, hrbA2],
    hpCClean, hpBClean,
    by dsimp only [F] at hucA2 ⊢; linarith only [hucA2, hucExt, hucClean],
    by dsimp only [F, K, S_bits] at hbcA2 hbcClean ⊢; linarith only [hbcA2, hbcExt, hbcClean],
    hmodHeapExt, hgeomExt,
    (hinLocs _ (mem_level3WriteLocs (lt_of_lt_of_le (by clear * -; omega : 0 < 6 + 2 * d) hstride))).2.2.trans hrExt0,
    (hinLocs _ (mem_level3WriteLocs (lt_of_lt_of_le (by clear * -; omega : 1 < 6 + 2 * d) hstride))).2.2.trans hrExt1,
    (hinLocs _ (mem_level3WriteLocs (lt_of_lt_of_le (by clear * -; omega : 2 < 6 + 2 * d) hstride))).2.2.trans hrExt2,
    fun p hp => (hinLocs _ (mem_level3WriteLocs (hstride_p p (Nat.le_of_lt hp)))).2.2.trans (hread_bh_sim1 p hp),
    fun off hlo hhi => by rw [(hinLocs _ (mem_level3WriteLocs hhi)).1]; exact hunused_sim1 off hlo hhi,
    houtLocs⟩

end UL.C12StepC2
