import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtor
import UL.Proof.clm_7_3_las_vegas_endpoint.CG09_StepC1B
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2d
import UL.Proof.clm_7_3_las_vegas_endpoint.CG11_AssembleB
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL.C12LVE
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### 1. Handle-Sorted A.2 Input & Residual Image Identifications -/

theorem stagedA2Input_eq_c12MkA2Input {d n B : ℕ}
    {P P' : DynamicPointSet d} {op : DynamicUpdate d}
    {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)} {qMap' : ℕ → Fin d → ℚ}
    (hwfP : P.WellFormed n) (hwfP' : P'.WellFormed n)
    (happ : applyDynamicUpdate P op (stepRetHandle mexHandle P.activeHandles op) = some P')
    (hlt_sync' : ∀ id ∈ P'.activeIds,
      ltCoords' (P'.lifetimeOfId id) = P'.coords id ∧
      P'.coords id = ratPointToEuclidean (qMap' (P'.handleOfId id)))
    {R : Finset ℕ} (hR_sub : R ⊆ activeLifetimes P') :
    stagedA2Input qMap' (minPopElem (R.image (handleOfLifetime P'))) R.card B =
      c12MkA2Input B P ltCoords' R := by
  obtain ⟨_, _, _, hcoords_eq⟩ := c12EnumByKey_handle_and_coords hwfP hwfP' happ hlt_sync' hR_sub
  unfold stagedA2Input c12MkA2Input
  dsimp only
  congr 1
  funext h
  by_cases hh : h < R.card
  · rw [if_pos hh, dif_pos hh]
    exact (hcoords_eq ⟨h, hh⟩).symm
  · rw [if_neg hh, dif_neg hh]

theorem residual_image_handle_eq_filter {d n : ℕ}
    {P' : DynamicPointSet d}
    {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)} {qMap' : ℕ → Fin d → ℚ}
    (hwfP' : P'.WellFormed n)
    (hlt_sync' : ∀ id ∈ P'.activeIds,
      ltCoords' (P'.lifetimeOfId id) = P'.coords id ∧
      P'.coords id = ratPointToEuclidean (qMap' (P'.handleOfId id)))
    {R : Finset ℕ} (hR_sub : R ⊆ activeLifetimes P')
    (node : ChainNode d) (oRat : Fin d → ℚ)
    (ho : node.o = ratPointToEuclidean oRat) :
    (node.residual ltCoords' R).image (handleOfLifetime P') =
      (R.image (handleOfLifetime P')).filter
        (fun h => isResHandlePred qMap' oRat node.V h = true) ∧
    ((R.image (handleOfLifetime P')).filter
        (fun h => isResHandlePred qMap' oRat node.V h = true)).card =
      (node.residual ltCoords' R).card := by
  have heq : (node.residual ltCoords' R).image (handleOfLifetime P') =
      (R.image (handleOfLifetime P')).filter
        (fun h => isResHandlePred qMap' oRat node.V h = true) := by
    ext h
    simp only [Finset.mem_image, Finset.mem_filter, ChainNode.residual, nodeResidual, nodeCore,
      Finset.mem_sdiff, isResHandlePred_eq_true_iff]
    constructor
    · rintro ⟨lt, ⟨hltR, hnotCore⟩, rfl⟩
      have hsync := (ltCoords_eq_qMap_of_active hwfP' hlt_sync' (hR_sub hltR)).2.2
      rw [hsync, ho] at hnotCore
      exact ⟨⟨lt, hltR, rfl⟩, fun hm => hnotCore ⟨hltR, hm⟩⟩
    · rintro ⟨⟨lt, hltR, rfl⟩, hnotCore⟩
      have hsync := (ltCoords_eq_qMap_of_active hwfP' hlt_sync' (hR_sub hltR)).2.2
      refine ⟨lt, ⟨hltR, ?_⟩, rfl⟩
      rw [hsync, ho]; exact fun ⟨_, hm⟩ => hnotCore hm
  have hsub_res : node.residual ltCoords' R ⊆ activeLifetimes P' := by
    intro lt hlt
    simp only [ChainNode.residual, nodeResidual, Finset.mem_sdiff] at hlt
    exact hR_sub hlt.1
  refine ⟨heq, ?_⟩
  rw [← heq]
  exact card_image_handleOfLifetime_eq hwfP' hsub_res

/-! ### 2. Table / Level Disjointness Helpers -/

theorem ne_tab3_of_ne_level {nodeStride i j off₁ off₂ : ℕ}
    (hne : i ≠ j) (h₁ : off₁ < nodeStride) (h₂ : off₂ < nodeStride) :
    (.heap 3 (nodeCellAddr nodeStride i off₁) : RAMCellLoc) ≠
      .heap 3 (nodeCellAddr nodeStride j off₂) := by
  intro hc; injection hc with _ ha
  exact hne (nodeCellAddr_inj h₁ h₂ ha).1

theorem not_mem_level3WriteLocs_of_ne {nodeStride i j off : ℕ}
    (hne : i ≠ j) (hoff : off < nodeStride) :
    (.heap 3 (nodeCellAddr nodeStride i off) : RAMCellLoc) ∉ level3WriteLocs nodeStride j := by
  intro hm
  unfold level3WriteLocs at hm
  rcases Finset.mem_image.mp hm with ⟨off₂, hoff₂, heq⟩
  exact ne_tab3_of_ne_level hne hoff (Finset.mem_range.mp hoff₂) heq.symm

theorem not_mem_level3WriteLocs_of_ne_tab {nodeStride j t : ℕ} {z : ℤ} (ht : t ≠ 3) :
    (.heap t z : RAMCellLoc) ∉ level3WriteLocs nodeStride j := by
  intro hm
  unfold level3WriteLocs at hm
  rcases Finset.mem_image.mp hm with ⟨_, _, heq⟩
  injection heq with e; exact ht e.symm

theorem ne_tab4_of_ne_level {L i j h₁ h₂ : ℕ}
    (hne : i ≠ j) (h₁_lt : h₁ < 2 ^ L) (h₂_lt : h₂ < 2 ^ L) :
    (.heap 4 (((i * 2 ^ L + h₁ : ℕ) : ℤ)) : RAMCellLoc) ≠
      .heap 4 (((j * 2 ^ L + h₂ : ℕ) : ℤ)) := by
  intro hc; injection hc with _ ha
  have hnat : i * 2 ^ L + h₁ = j * 2 ^ L + h₂ := Int.ofNat.inj ha
  rcases lt_trichotomy i j with hlt | rfl | hgt
  · have hstep : (i + 1) * 2 ^ L ≤ j * 2 ^ L := Nat.mul_le_mul_right _ hlt
    rw [add_mul, one_mul] at hstep
    omega
  · exact hne rfl
  · have hstep : (j + 1) * 2 ^ L ≤ i * 2 ^ L := Nat.mul_le_mul_right _ hgt
    rw [add_mul, one_mul] at hstep
    omega

theorem not_mem_stageA2Locs_of_ne_tab {d m t : ℕ} {z : ℤ}
    (h5 : t ≠ 5) (h6 : t ≠ 6) (h7 : t ≠ 7) :
    (.heap t z : RAMCellLoc) ∉ stageA2Locs d m := by
  intro hm
  unfold stageA2Locs at hm
  simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.mem_image] at hm
  rcases hm with (((hc | hc) | ⟨_, _, hc⟩) | ⟨_, _, hc⟩)
  · injection hc with e; exact h5 e
  · injection hc with e; exact h5 e
  · injection hc with e; exact h6 e.symm
  · injection hc with e; exact h7 e.symm

theorem not_mem_treeSliceLocs_of_ne_tab {L tid t : ℕ} {z : ℤ} (ht : t ≠ 2) :
    (.heap t z : RAMCellLoc) ∉ treeSliceLocs L tid := by
  intro hm
  unfold treeSliceLocs at hm
  rcases Finset.mem_image.mp hm with ⟨_, _, hc⟩
  injection hc with e; exact ht e.symm

theorem wordStore_read_eq_of_live_vals {w₁ w₂ : WordStore} {loc : RAMCellLoc}
    (h : (loc ∈ w₁.live ↔ loc ∈ w₂.live) ∧ w₁.vals loc = w₂.vals loc) :
    w₁.read loc = w₂.read loc := by
  unfold WordStore.read; rw [h.2]
  by_cases hm : loc ∈ w₂.live
  · rw [if_pos (h.1.mpr hm), if_pos hm]
  · rw [if_neg (fun h1 => hm (h.1.mp h1)), if_neg hm]

/-! ### 3. Pre-A.2 Stage (`syncJToHeap0Regs ; sortBufViaUnitTree1Regs ; stageBufForA2Regs`) -/

def c07StepC2PreA2Regs (d L B : ℕ) (jSrc : JSource) : BitRAMStmt :=
  .seq (syncJToHeap0Regs jSrc)
  (.seq (sortBufViaUnitTree1Regs L)
        (stageBufForA2Regs d B))

theorem exec_c07StepC2PreA2Regs {d n L B K_max W j : ℕ}
    (hd1 : 1 ≤ d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n)) (hB1 : 1 ≤ B)
    (hj_lt : j < K_max)
    (hW : B + natBitLength ((K_max + 2) * posNodeStride d L) + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {C_cell C_bit : ℕ}
    {P P' : DynamicPointSet d} {op : DynamicUpdate d}
    {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)} {qMap' : ℕ → Fin d → ℚ}
    (hwfP : P.WellFormed n) (hwfP' : P'.WellFormed n)
    (happ : applyDynamicUpdate P op (stepRetHandle mexHandle P.activeHandles op) = some P')
    (hlt_sync' : ∀ id ∈ P'.activeIds,
      ltCoords' (P'.lifetimeOfId id) = P'.coords id ∧
      P'.coords id = ratPointToEuclidean (qMap' (P'.handleOfId id)))
    {R : Finset ℕ} (hm1 : 1 ≤ R.card) (hm_n : R.card ≤ n) (hR_sub : R ⊆ activeLifetimes P')
    {wsHeap : WordStore} {regs : ℕ → ℤ} {jSrc : JSource}
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsHeap)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hbnd : RegBounded W regs)
    (hcoords : ActiveCoordsStored d L B P'.activeHandles qMap' wsHeap)
    (hemp567 : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsHeap.live)
    (hheap9_bnd : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ wsHeap.live → ∃ k : ℕ, k < 256 ∧ z = (k : ℤ))
    (hbuf : StdBufLoopExtra jSrc L P' j R wsHeap regs) :
    let m := R.card
    let S_H := R.image (handleOfLifetime P')
    ∃ wsPre regsPre,
      RegExec inp 1 W C_cell C_bit (c07StepC2PreA2Regs d L B jSrc) wsHeap regs wsPre regsPre
        ((m + 1) * (900 * L + 120 * d + 760) + 160)
        (((m + 1) * (150 * L + 24 * d + 220) + 140) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsPre ∧
      RegBounded W regsPre ∧
      StagingA2Matches m B wsPre (c12MkA2Input B P ltCoords' R) ∧
      wsPre.read (.heap 0 10) = (j : ℤ) ∧
      wsPre.read (.heap 5 0) = (m : ℤ) ∧
      wsPre.read (.heap 9 110) = (m : ℤ) ∧
      (∀ k < m, wsPre.read (.heap 8 (k : ℤ)) = (minPopElem S_H k : ℤ)) ∧
      (∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsPre.live) ∧
      TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsPre ∧
      (∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ,
        (.heap t z : RAMCellLoc) ∈ wsPre.live → (.heap t z : RAMCellLoc) ∈ stageA2Locs d m) ∧
      (∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ wsPre.live → ∃ k : ℕ, k < 256 ∧ z = (k : ℤ)) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .heap 0 10 →
        loc ∉ treeSliceLocs L 1 →
        (∀ z : ℤ, loc ≠ .heap 8 z) →
        loc ≠ .heap 9 110 → loc ≠ .heap 9 111 → loc ≠ .heap 9 112 →
        loc ∉ stageA2Locs d m →
        (loc ∈ wsPre.live ↔ loc ∈ wsHeap.live) ∧ wsPre.vals loc = wsHeap.vals loc) := by
  dsimp only
  set m := R.card
  set S_H := R.image (handleOfLifetime P')
  obtain ⟨hL2, _, h2n_pow, _⟩ := clog_two_mul_bounds hn
  rw [← hL] at hL2 h2n_pow
  have hL1 : 1 ≤ L := by omega
  have hm_pow : m ≤ 2 ^ L := by omega
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hWW : 40 * W ≤ W * W := by nlinarith only [hW40]
  have hCeil0C : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hCeil0B : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  have hj_bl : intBitLength (j : ℤ) ≤ W := by
    have hns_pos : 0 < posNodeStride d L := by unfold posNodeStride; have := Nat.zero_le (2 ^ L); omega
    have hj1 : j ≤ K_max + 1 := by omega
    have hj_le : j ≤ j * posNodeStride d L + 0 := by
      have := Nat.le_mul_of_pos_right j hns_pos; omega
    have hW_node : natBitLength ((K_max + 2) * posNodeStride d L) + 8 ≤ W := by clear * - hW; omega
    exact (intBitLength_natCast_mono hj_le).trans (nodeCellAddr_bl (W := W) hj1 hns_pos hW_node).2
  rcases hbuf with ⟨hj_holds, htree1_0, hr110_0, ⟨hSeq₀, hhSeq₀_spec, hhSeq₀_img⟩, hclean8_0⟩
  have hcard_SH : S_H.card = m := card_image_handleOfLifetime_eq hwfP' hR_sub
  -- 1. syncJToHeap0Regs
  obtain ⟨ws0, regs0, sSync, hm0, br0, hr0_j, hunch0⟩ :=
    exec_syncJToHeap0Regs (by decide : 1 ≤ 4) hmod hCeil0C hCeil0B (by omega) hj_bl
      (mem_posDimWriteLocs_tab0 (i := 10) (by decide)) hbnd hj_holds
  have htree1_ws0 : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) ws0 :=
    htree1_0.unchanged (fun u _ f _ => hunch0 (.heap 2 (treeCellAddr L 1 u f)) (fun h => by cases h))
  have hr110_ws0 : ws0.read (.heap 9 110) = (m : ℤ) :=
    (wordStore_read_eq_of_live_vals (hunch0 _ (by decide))).trans hr110_0
  have hbuf_ws0 : ∀ k < m, ws0.read (.heap 8 (k : ℤ)) = (hSeq₀ k : ℤ) := fun k hk =>
    (wordStore_read_eq_of_live_vals (hunch0 _ (fun h => by cases h))).trans (hhSeq₀_spec k hk).2
  have hclean8_ws0 : ∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ ws0.live := fun z hz => by
    rw [(hunch0 (.heap 8 z) (fun h => by cases h)).1]; exact hclean8_0 z hz
  -- 2. sortBufViaUnitTree1Regs
  obtain ⟨ws1, regs1, sSort, hm_ws1, br1, htree1_ws1, hr110_ws1, hbuf_ws1, hclean8_ws1,
    hn111_ws1, hn112_ws1, hunch1⟩ :=
    exec_sortBufViaUnitTree1Regs (by decide : 1 ≤ 4) hm0 hCeil0C hCeil0B hL1 hm_pow
      (by clear * - hW; omega)
      (fun u hu f hf => mem_posDimWriteLocs_tree (tid := 1) (by omega) hu hf)
      (fun (k : ℕ) hk => mem_posDimWriteLocs_tab8 (by omega))
      (mem_posDimWriteLocs_tab9 (i := 110) (by decide))
      (mem_posDimWriteLocs_tab9 (i := 111) (by decide))
      (mem_posDimWriteLocs_tab9 (i := 112) (by decide))
      htree1_ws0 hr110_ws0 (fun k hk => (hhSeq₀_spec k hk).1) hbuf_ws0 hhSeq₀_img hcard_SH hclean8_ws0 br0
  have hcoords_ws1 : ActiveCoordsStored d L B P'.activeHandles qMap' ws1 :=
    hcoords.unchanged (fun h' _ c _ f _ =>
      wordStore_read_eq_of_live_vals
        (let u1 := hunch1 (.heap 1 (coordCellAddr d h' c f)) (not_mem_treeSliceLocs_of_ne_tab (by decide))
           (fun h => by cases h) (fun h => by cases h) (fun h => by cases h) (fun _ h => by cases h)
         let u0 := hunch0 (.heap 1 (coordCellAddr d h' c f)) (fun h => by cases h)
         ⟨u1.1.trans u0.1, u1.2.trans u0.2⟩))
  have hemp567_ws1 : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ ws1.live := by
    intro t ht z
    have hnt2 : t ≠ 2 := by rcases ht with rfl | rfl | rfl <;> decide
    have hnt8 : t ≠ 8 := by rcases ht with rfl | rfl | rfl <;> decide
    have hnt9 : t ≠ 9 := by rcases ht with rfl | rfl | rfl <;> decide
    have hnt0 : t ≠ 0 := by rcases ht with rfl | rfl | rfl <;> decide
    have u1 := hunch1 (.heap t z) (not_mem_treeSliceLocs_of_ne_tab hnt2)
      (fun h => by injection h with e; exact hnt9 e)
      (fun h => by injection h with e; exact hnt9 e)
      (fun h => by injection h with e; exact hnt9 e)
      (fun _ h => by injection h with e; exact hnt8 e)
    have u0 := hunch0 (.heap t z) (fun h => by injection h with e; exact hnt0 e)
    rw [u1.1, u0.1]
    exact hemp567 t ht z
  have hmin_mem_act : ∀ i < m, minPopElem S_H i ∈ P'.activeHandles := by
    intro i hi
    have hmem_SH : minPopElem S_H i ∈ S_H := (minPopElem_step (hcard_SH.symm ▸ hi)).2.2.2.1
    rcases Finset.mem_image.mp hmem_SH with ⟨lt, hltR, heq⟩
    rw [← heq]
    exact (ltCoords_eq_qMap_of_active hwfP' hlt_sync' (hR_sub hltR)).2.1
  -- 3. stageBufForA2Regs
  obtain ⟨wsPre, regsPre, sStage, hmPre, brPre, hstage_raw, hlive567_Pre, hunch2⟩ :=
    exec_stageBufForA2Regs hd1 hm1 hB1 hm_pow (by clear * - hW; omega) (by decide : 1 ≤ 4)
      hm_ws1 hcCeil hbCeil br1 hcoords_ws1 hr110_ws1 hbuf_ws1 hmin_mem_act hemp567_ws1
  have hstage_eq : StagingA2Matches m B wsPre (c12MkA2Input B P ltCoords' R) := by
    rw [← stagedA2Input_eq_c12MkA2Input hwfP hwfP' happ hlt_sync' hR_sub]
    exact hstage_raw
  have hr50_Pre : wsPre.read (.heap 5 0) = (m : ℤ) := by
    have hr5 := hstage_raw.2.2.2.2.2.2.1 0
    simpa [listGetIntD] using hr5
  have hr010_Pre : wsPre.read (.heap 0 10) = (j : ℤ) := by
    have u2 := hunch2 (.heap 0 10) (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
    have u1 := hunch1 (.heap 0 10) (not_mem_treeSliceLocs_of_ne_tab (by decide))
      (by decide) (by decide) (by decide) (fun _ h => by cases h)
    exact (wordStore_read_eq_of_live_vals ⟨u2.1.trans u1.1, u2.2.trans u1.2⟩).trans hr0_j
  have hr110_Pre : wsPre.read (.heap 9 110) = (m : ℤ) := by
    have u2 := hunch2 (.heap 9 110) (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))
    exact (wordStore_read_eq_of_live_vals u2).trans hr110_ws1
  have hbuf_Pre : ∀ k < m, wsPre.read (.heap 8 (k : ℤ)) = (minPopElem S_H k : ℤ) := fun k hk =>
    (wordStore_read_eq_of_live_vals
      (hunch2 _ (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide)))).trans (hbuf_ws1 k hk)
  have hclean8_Pre : ∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsPre.live := fun z hz => by
    rw [(hunch2 (.heap 8 z) (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))).1]
    exact hclean8_ws1 z hz
  have htree1_Pre : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsPre :=
    htree1_ws1.unchanged (fun _ _ _ _ =>
      hunch2 _ (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide)))
  have hheap9_Pre : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ wsPre.live → ∃ k : ℕ, k < 256 ∧ z = (k : ℤ) := by
    intro z hmP
    have hm_1 := (hunch2 (.heap 9 z) (not_mem_stageA2Locs_of_ne_tab (by decide) (by decide) (by decide))).1.mp hmP
    by_cases hz110 : z = 110
    · exact ⟨110, by decide, hz110⟩
    · have n111 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 111 := fun h => hn111_ws1 (h ▸ hm_1)
      have n112 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 112 := fun h => hn112_ws1 (h ▸ hm_1)
      have n110 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 110 := fun h => hz110 (by injection h)
      have hm_0 := (hunch1 (.heap 9 z) (not_mem_treeSliceLocs_of_ne_tab (by decide))
        n110 n111 n112 (fun _ h => by cases h)).1.mp hm_1
      have hm_init := (hunch0 (.heap 9 z) (fun h => by cases h)).1.mp hm_0
      exact hheap9_bnd z hm_init
  have hExecPre : RegExec inp 1 W C_cell C_bit (c07StepC2PreA2Regs d L B jSrc) wsHeap regs wsPre regsPre
      ((m + 1) * (900 * L + 120 * d + 760) + 160)
      (((m + 1) * (150 * L + 24 * d + 220) + 140) * W * W) := by
    refine (sSync.seq (sSort.seq sStage)).weaken rfl rfl ?_ ?_
    · clear * -; nlinarith
    · have hsyncW : 30 * W ≤ 40 * W * W := by
        calc 30 * W ≤ 40 * (40 * W) := by clear * - hW40; omega
        _ ≤ 40 * (W * W) := Nat.mul_le_mul_left 40 hWW
        _ = 40 * W * W := by ring
      have hcomb : 40 * W * W + ((m + 1) * (150 * L + 200) * W * W + 100 * W * W) +
          (m + 1) * (24 * d + 12) * W * W ≤
          ((m + 1) * (150 * L + 24 * d + 220) + 140) * W * W := by
        calc 40 * W * W + ((m + 1) * (150 * L + 200) * W * W + 100 * W * W) +
              (m + 1) * (24 * d + 12) * W * W
          _ = ((m + 1) * (150 * L + 24 * d + 212) + 140) * (W * W) := by ring
          _ ≤ ((m + 1) * (150 * L + 24 * d + 220) + 140) * (W * W) :=
              Nat.mul_le_mul_right (W * W) (by clear * -; nlinarith)
          _ = ((m + 1) * (150 * L + 24 * d + 220) + 140) * W * W := by ring
      linarith only [hsyncW, hcomb]
  refine ⟨wsPre, regsPre, hExecPre, hmPre, brPre, hstage_eq, hr010_Pre, hr50_Pre, hr110_Pre,
    hbuf_Pre, hclean8_Pre, htree1_Pre, hlive567_Pre, hheap9_Pre,
    fun loc n010 ns1 n8 n110 n111 n112 nSt => ?_⟩
  have u2 := hunch2 loc nSt
  have u1 := hunch1 loc ns1 n110 n111 n112 n8
  have u0 := hunch0 loc n010
  exact ⟨u2.1.trans (u1.1.trans u0.1), u2.2.trans (u1.2.trans u0.2)⟩

end UL.C12StepC2
