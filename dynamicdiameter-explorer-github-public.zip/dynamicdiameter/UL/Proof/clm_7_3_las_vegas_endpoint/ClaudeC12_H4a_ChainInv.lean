import Mathlib
import UL.Stmt.lem_A_2
import UL.Stmt.claim_A_2_deletion_witness
import UL.Stmt.clm_5_1_chain_contraction
import UL.Stmt.claim_C_3_sync_suffix
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H1_Easy
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2c3b_SubRun
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2c3c_SubClean
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3c3_Dim0
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3c5_NodeGeom
set_option autoImplicit false
set_option maxHeartbeats 800000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Pointwise Characterization of `chainInput` and `HasNodeAge` Step Lemmas -/

theorem mem_chainInput_iff {d : ℕ} {ι : Type*} [DecidableEq ι] {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι) :
    ∀ (j : Fin (k + 1)) (x : ι),
      x ∈ chainInput pts nodes P j ↔
        x ∈ P ∧ ∀ (i : ℕ) (hi : i < j.val),
          pts x ∉ coreBall (nodes ⟨i, lt_of_lt_of_le hi (Nat.lt_succ_iff.mp j.isLt)⟩).o
            (nodes ⟨i, lt_of_lt_of_le hi (Nat.lt_succ_iff.mp j.isLt)⟩).V := by
  intro ⟨jv, hjv⟩ x
  have hgo : ∀ (m : ℕ) (hm : m ≤ k),
      x ∈ chainInput.go pts nodes P m hm ↔
        x ∈ P ∧ ∀ (i : ℕ) (hi : i < m),
          pts x ∉ coreBall (nodes ⟨i, lt_of_lt_of_le hi hm⟩).o
            (nodes ⟨i, lt_of_lt_of_le hi hm⟩).V := by
    intro m
    induction m with
    | zero =>
        intro hm
        simp [chainInput.go]
    | succ m ih =>
        intro hm
        simp only [chainInput.go, ChainNode.residual, nodeResidual, nodeCore,
          Finset.mem_sdiff, Finset.mem_filter]
        rw [ih (Nat.le_of_succ_le hm)]
        constructor
        · rintro ⟨⟨hxP, hprev⟩, hnot⟩
          refine ⟨hxP, fun i hi => ?_⟩
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
          · exact hprev i hlt
          · exact fun hmem => hnot ⟨⟨hxP, hprev⟩, hmem⟩
        · rintro ⟨hxP, hall⟩
          exact ⟨⟨hxP, fun i hi => hall i (Nat.lt_succ_of_lt hi)⟩,
                 fun ⟨_, hmem⟩ => hall m (Nat.lt_succ_self m) hmem⟩
  exact hgo jv (Nat.lt_succ_iff.mp hjv)

theorem chainInput_subset_base {d : ℕ} {ι : Type*} [DecidableEq ι] {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (j : Fin (k + 1)) :
    chainInput pts nodes P j ⊆ P :=
  fun _ hx => ((mem_chainInput_iff pts nodes P j _).mp hx).1

theorem chainInput_congr_pts {d : ℕ} {ι : Type*} [DecidableEq ι] {k : ℕ}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (nodes : Fin k → ChainNode d) (P : Finset ι)
    (hpts : ∀ x ∈ P, pts₁ x = pts₂ x) (j : Fin (k + 1)) :
    chainInput pts₁ nodes P j = chainInput pts₂ nodes P j := by
  ext x
  rw [mem_chainInput_iff, mem_chainInput_iff]
  constructor <;> rintro ⟨hxP, hall⟩
  · exact ⟨hxP, fun i hi => by rw [← hpts x hxP]; exact hall i hi⟩
  · exact ⟨hxP, fun i hi => by rw [hpts x hxP]; exact hall i hi⟩

open Classical in
theorem chainInput_insert_eq {d : ℕ} {ι : Type*} [DecidableEq ι] {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    {x : ι} (hx : x ∉ P) (j : Fin (k + 1)) :
    chainInput pts nodes (insert x P) j =
      if ∀ (i : ℕ) (hi : i < j.val),
          pts x ∉ coreBall (nodes ⟨i, lt_of_lt_of_le hi (Nat.lt_succ_iff.mp j.isLt)⟩).o
            (nodes ⟨i, lt_of_lt_of_le hi (Nat.lt_succ_iff.mp j.isLt)⟩).V then
        insert x (chainInput pts nodes P j)
      else
        chainInput pts nodes P j := by
  ext y
  rw [mem_chainInput_iff]
  by_cases hall_x : ∀ (i : ℕ) (hi : i < j.val),
      pts x ∉ coreBall (nodes ⟨i, lt_of_lt_of_le hi (Nat.lt_succ_iff.mp j.isLt)⟩).o
        (nodes ⟨i, lt_of_lt_of_le hi (Nat.lt_succ_iff.mp j.isLt)⟩).V
  · rw [if_pos hall_x, Finset.mem_insert, Finset.mem_insert, mem_chainInput_iff]
    constructor
    · rintro ⟨rfl | hyP, hyall⟩
      · exact Or.inl rfl
      · exact Or.inr ⟨hyP, hyall⟩
    · rintro (rfl | ⟨hyP, hyall⟩)
      · exact ⟨Or.inl rfl, hall_x⟩
      · exact ⟨Or.inr hyP, hyall⟩
  · rw [if_neg hall_x, mem_chainInput_iff, Finset.mem_insert]
    constructor
    · rintro ⟨rfl | hyP, hyall⟩
      · exact absurd hyall hall_x
      · exact ⟨hyP, hyall⟩
    · rintro ⟨hyP, hyall⟩
      exact ⟨Or.inr hyP, hyall⟩

theorem chainInput_erase_eq {d : ℕ} {ι : Type*} [DecidableEq ι] {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (x : ι) (j : Fin (k + 1)) :
    chainInput pts nodes (P.erase x) j = (chainInput pts nodes P j).erase x := by
  ext y
  rw [mem_chainInput_iff, Finset.mem_erase, Finset.mem_erase, mem_chainInput_iff]
  tauto

theorem hasNodeAge_insert {ι : Type*} [DecidableEq ι] {P₀ S : Finset ι} {age : ℕ}
    (h : HasNodeAge P₀ S age) {x : ι} (hx : x ∉ S) :
    HasNodeAge P₀ (insert x S) (age + 1) := by
  rcases h with ⟨seq, h0, hlast, hchg⟩
  let seq' : Fin (age + 2) → Finset ι :=
    fun t => if hlt : t.val < age + 1 then seq ⟨t.val, hlt⟩ else insert x S
  refine ⟨seq', ?_, ?_, ?_⟩
  · dsimp only [seq']
    rw [dif_pos (by simp : (0 : Fin (age + 2)).val < age + 1)]
    exact h0
  · dsimp only [seq']
    rw [dif_neg (by simp : ¬ (Fin.last (age + 1)).val < age + 1)]
  · intro ⟨rv, hrv⟩
    dsimp only [seq']
    rcases Nat.lt_succ_iff_lt_or_eq.mp hrv with hlt | heq
    · have h1 : (⟨rv, hrv⟩ : Fin (age + 1)).castSucc.val < age + 1 := hrv
      have h2 : (⟨rv, hrv⟩ : Fin (age + 1)).succ.val < age + 1 := Nat.succ_lt_succ hlt
      rw [dif_pos h1, dif_pos h2]
      exact hchg ⟨rv, hlt⟩
    · subst heq
      have h1 : (⟨rv, hrv⟩ : Fin (rv + 1)).castSucc.val < rv + 1 := hrv
      have h2 : ¬ (⟨rv, hrv⟩ : Fin (rv + 1)).succ.val < rv + 1 := Nat.lt_irrefl (rv + 1)
      rw [dif_pos h1, dif_neg h2]
      have heqL : (⟨(⟨rv, hrv⟩ : Fin (rv + 1)).castSucc.val, h1⟩ : Fin (rv + 1)) = Fin.last rv := rfl
      rw [heqL, hlast]
      exact Or.inl ⟨x, hx, by ext; simp⟩

theorem hasNodeAge_erase {ι : Type*} [DecidableEq ι] {P₀ S : Finset ι} {age : ℕ}
    (h : HasNodeAge P₀ S age) {x : ι} (hx : x ∈ S) :
    HasNodeAge P₀ (S.erase x) (age + 1) := by
  rcases h with ⟨seq, h0, hlast, hchg⟩
  let seq' : Fin (age + 2) → Finset ι :=
    fun t => if hlt : t.val < age + 1 then seq ⟨t.val, hlt⟩ else S.erase x
  refine ⟨seq', ?_, ?_, ?_⟩
  · dsimp only [seq']
    rw [dif_pos (by simp : (0 : Fin (age + 2)).val < age + 1)]
    exact h0
  · dsimp only [seq']
    rw [dif_neg (by simp : ¬ (Fin.last (age + 1)).val < age + 1)]
  · intro ⟨rv, hrv⟩
    dsimp only [seq']
    rcases Nat.lt_succ_iff_lt_or_eq.mp hrv with hlt | heq
    · have h1 : (⟨rv, hrv⟩ : Fin (age + 1)).castSucc.val < age + 1 := hrv
      have h2 : (⟨rv, hrv⟩ : Fin (age + 1)).succ.val < age + 1 := Nat.succ_lt_succ hlt
      rw [dif_pos h1, dif_pos h2]
      exact hchg ⟨rv, hlt⟩
    · subst heq
      have h1 : (⟨rv, hrv⟩ : Fin (rv + 1)).castSucc.val < rv + 1 := hrv
      have h2 : ¬ (⟨rv, hrv⟩ : Fin (rv + 1)).succ.val < rv + 1 := Nat.lt_irrefl (rv + 1)
      rw [dif_pos h1, dif_neg h2]
      have heqL : (⟨(⟨rv, hrv⟩ : Fin (rv + 1)).castSucc.val, h1⟩ : Fin (rv + 1)) = Fin.last rv := rfl
      rw [heqL, hlast]
      exact Or.inr ⟨x, hx, by ext; simp⟩

open Classical in
theorem card_le_add_of_hasNodeAge {ι : Type*} {P₀ S : Finset ι} {age : ℕ}
    (h : HasNodeAge P₀ S age) :
    S.card ≤ P₀.card + age := by
  rcases h with ⟨seq, h0, hlast, hchg⟩
  have hind : ∀ (tv : ℕ) (htv : tv < age + 1), (seq ⟨tv, htv⟩).card ≤ (seq 0).card + tv := by
    intro tv
    induction tv with
    | zero => intro htv; simp
    | succ m ih =>
        intro htv
        have hm_lt : m < age := Nat.lt_of_succ_lt_succ htv
        have ih_m := ih (Nat.lt_of_succ_lt htv)
        have hstep := hchg ⟨m, hm_lt⟩
        rcases hstep with ⟨x, _, heq⟩ | ⟨x, _, heq⟩
        · calc (seq ⟨m + 1, htv⟩).card
            _ = (seq (⟨m, hm_lt⟩ : Fin age).succ).card := rfl
            _ = (insert x (seq (⟨m, hm_lt⟩ : Fin age).castSucc)).card := congrArg Finset.card heq
            _ ≤ (seq (⟨m, hm_lt⟩ : Fin age).castSucc).card + 1 := Finset.card_insert_le _ _
            _ = (seq ⟨m, Nat.lt_of_succ_lt htv⟩).card + 1 := rfl
            _ ≤ ((seq 0).card + m) + 1 := Nat.add_le_add_right ih_m 1
            _ = (seq 0).card + (m + 1) := by clear * -; omega
        · calc (seq ⟨m + 1, htv⟩).card
            _ = (seq (⟨m, hm_lt⟩ : Fin age).succ).card := rfl
            _ = ((seq (⟨m, hm_lt⟩ : Fin age).castSucc).erase x).card := congrArg Finset.card heq
            _ ≤ (seq (⟨m, hm_lt⟩ : Fin age).castSucc).card := Finset.card_erase_le
            _ = (seq ⟨m, Nat.lt_of_succ_lt htv⟩).card := rfl
            _ ≤ (seq 0).card + m := ih_m
            _ ≤ (seq 0).card + (m + 1) := by clear * -; omega
  have hend := hind age (Nat.lt_succ_self age)
  have heqL : (⟨age, Nat.lt_succ_self age⟩ : Fin (age + 1)) = Fin.last age := rfl
  rw [heqL, h0, hlast] at hend
  exact hend

/-! ### 2. Static Master Write-Universe `posDimWriteLocs` (`t < 10`) and Cardinality Bound -/

def posNodeStride (d L : ℕ) : ℕ :=
  8 + 2 * d + 2 ^ L

private def heapRangeLocs (t N : ℕ) : Finset RAMCellLoc :=
  (Finset.range N).image (fun i : ℕ => RAMCellLoc.heap t (i : ℤ))

private theorem card_heapRangeLocs_le (t N : ℕ) :
    (heapRangeLocs t N).card ≤ N := by
  unfold heapRangeLocs
  exact Finset.card_image_le.trans (by simp)

private theorem mem_heapRangeLocs {t N i : ℕ} (hi : i < N) :
    RAMCellLoc.heap t (i : ℤ) ∈ heapRangeLocs t N := by
  unfold heapRangeLocs
  exact Finset.mem_image.mpr ⟨i, Finset.mem_range.mpr hi, rfl⟩

def posDimWriteLocs (d L K_max : ℕ) : Finset RAMCellLoc :=
  let nodeStride := posNodeStride d L
  heapRangeLocs 0 16 ∪
  heapRangeLocs 1 (2 * d * 2 ^ L) ∪
  ((Finset.range (2 * K_max + 6)).biUnion (fun tid => treeSliceLocs L tid)) ∪
  heapRangeLocs 3 ((K_max + 2) * nodeStride) ∪
  heapRangeLocs 4 ((K_max + 2) * 2 ^ L) ∪
  heapRangeLocs 5 (2 * d * 2 ^ L + 16) ∪
  heapRangeLocs 6 (2 * d * 2 ^ L + 16) ∪
  heapRangeLocs 7 (2 * d * 2 ^ L + 16) ∪
  heapRangeLocs 8 (2 ^ L + 256) ∪
  heapRangeLocs 9 256

theorem posDimWriteLocs_isHeap {d L K_max : ℕ} :
    ∀ loc ∈ posDimWriteLocs d L K_max, ∃ t < 10, ∃ z : ℤ, loc = .heap t z := by
  intro loc hmem
  unfold posDimWriteLocs heapRangeLocs treeSliceLocs at hmem
  simp only [Finset.mem_union, Finset.mem_biUnion, Finset.mem_image, Finset.mem_range,
    Finset.mem_product] at hmem
  rcases hmem with (((((((((h0 | h1) | h2) | h3) | h4) | h5) | h6) | h7) | h8) | h9)
  · rcases h0 with ⟨_, _, rfl⟩; exact ⟨0, by omega, _, rfl⟩
  · rcases h1 with ⟨_, _, rfl⟩; exact ⟨1, by omega, _, rfl⟩
  · rcases h2 with ⟨_, _, ⟨_, _⟩, _, rfl⟩; exact ⟨2, by omega, _, rfl⟩
  · rcases h3 with ⟨_, _, rfl⟩; exact ⟨3, by omega, _, rfl⟩
  · rcases h4 with ⟨_, _, rfl⟩; exact ⟨4, by omega, _, rfl⟩
  · rcases h5 with ⟨_, _, rfl⟩; exact ⟨5, by omega, _, rfl⟩
  · rcases h6 with ⟨_, _, rfl⟩; exact ⟨6, by omega, _, rfl⟩
  · rcases h7 with ⟨_, _, rfl⟩; exact ⟨7, by omega, _, rfl⟩
  · rcases h8 with ⟨_, _, rfl⟩; exact ⟨8, by omega, _, rfl⟩
  · rcases h9 with ⟨_, _, rfl⟩; exact ⟨9, by omega, _, rfl⟩

theorem posDimWriteLocs_isA2Base {d L K_max : ℕ} :
    ∀ loc ∈ posDimWriteLocs d L K_max, IsA2BaseLoc loc := by
  intro loc hmem
  rcases posDimWriteLocs_isHeap loc hmem with ⟨t, ht, z, rfl⟩
  exact ht

theorem mem_posDimWriteLocs_tab0 {d L K_max i : ℕ} (hi : i < 16) :
    RAMCellLoc.heap 0 (i : ℤ) ∈ posDimWriteLocs d L K_max := by
  unfold posDimWriteLocs
  exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
    (Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
      (Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
        (mem_heapRangeLocs hi)))))))))

theorem mem_posDimWriteLocs_coord {d L K_max h c f : ℕ}
    (hh : h < 2 ^ L) (hc : c < d) (hf : f < 2) :
    RAMCellLoc.heap 1 (coordCellAddr d h c f) ∈ posDimWriteLocs d L K_max := by
  have hlt : (h * d + c) * 2 + f < 2 * d * 2 ^ L := by
    have h1 : h * d + c < 2 ^ L * d := by
      have hm : (h + 1) * d ≤ 2 ^ L * d := Nat.mul_le_mul_right d (by clear * - hh; omega)
      have ha : h * d + c < (h + 1) * d := by rw [add_mul, one_mul]; clear * - hc; omega
      exact lt_of_lt_of_le ha hm
    have h2 : 2 * (2 ^ L * d) = 2 * d * 2 ^ L := by ring
    clear * - h1 h2 hf; omega
  unfold posDimWriteLocs coordCellAddr
  exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
    (Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
      (Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_right _
        (mem_heapRangeLocs hlt)))))))))

theorem mem_posDimWriteLocs_tree {d L K_max tid u f : ℕ}
    (htid : tid < 2 * K_max + 6) (hu : u < 2 ^ (L + 1)) (hf : f < 4) :
    RAMCellLoc.heap 2 (treeCellAddr L tid u f) ∈ posDimWriteLocs d L K_max := by
  have hm_slice : RAMCellLoc.heap 2 (treeCellAddr L tid u f) ∈ treeSliceLocs L tid := by
    unfold treeSliceLocs
    exact Finset.mem_image.mpr ⟨(u, f),
      Finset.mem_product.mpr ⟨Finset.mem_range.mpr hu, Finset.mem_range.mpr hf⟩, rfl⟩
  have hm_bi : RAMCellLoc.heap 2 (treeCellAddr L tid u f) ∈
      (Finset.range (2 * K_max + 6)).biUnion (fun t => treeSliceLocs L t) :=
    Finset.mem_biUnion.mpr ⟨tid, Finset.mem_range.mpr htid, hm_slice⟩
  unfold posDimWriteLocs
  exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
    (Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
      (Finset.mem_union_left _ (Finset.mem_union_right _ hm_bi)))))))

theorem treePathLocs_sub_posDimWriteLocs {d L K_max tid h₀ : ℕ}
    (htid : tid < 2 * K_max + 6) (hh₀ : h₀ < 2 ^ L) :
    treePathLocs L tid h₀ ⊆ posDimWriteLocs d L K_max := by
  intro loc hloc
  unfold treePathLocs at hloc
  simp only [Finset.mem_image, Finset.mem_product, Finset.mem_range] at hloc
  rcases hloc with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
  have hk_le : k ≤ L := by clear * - hk; omega
  have hoff : h₀ / 2 ^ k < 2 ^ (L - k) := by
    rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add, Nat.sub_add_cancel hk_le]
    exact hh₀
  have hu := (treeIdx_bounds hk_le hoff).2
  exact mem_posDimWriteLocs_tree htid hu hf

theorem mem_posDimWriteLocs_tab3 {d L K_max j off : ℕ}
    (hj : j ≤ K_max + 1) (hoff : off < posNodeStride d L) :
    RAMCellLoc.heap 3 (nodeCellAddr (posNodeStride d L) j off) ∈ posDimWriteLocs d L K_max := by
  have hlt : j * posNodeStride d L + off < (K_max + 2) * posNodeStride d L := by
    have hm : (j + 1) * posNodeStride d L ≤ (K_max + 2) * posNodeStride d L :=
      Nat.mul_le_mul_right _ (by clear * - hj; omega)
    have ha : j * posNodeStride d L + off < (j + 1) * posNodeStride d L := by
      rw [add_mul, one_mul]; clear * - hoff; omega
    exact lt_of_lt_of_le ha hm
  unfold posDimWriteLocs nodeCellAddr
  exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
    (Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
      (Finset.mem_union_right _ (mem_heapRangeLocs hlt)))))))

theorem mem_posDimWriteLocs_tab4 {d L K_max j h : ℕ}
    (hj : j ≤ K_max + 1) (hh : h < 2 ^ L) :
    RAMCellLoc.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) ∈ posDimWriteLocs d L K_max := by
  have hlt : j * 2 ^ L + h < (K_max + 2) * 2 ^ L := by
    have hm : (j + 1) * 2 ^ L ≤ (K_max + 2) * 2 ^ L :=
      Nat.mul_le_mul_right _ (by clear * - hj; omega)
    have ha : j * 2 ^ L + h < (j + 1) * 2 ^ L := by
      rw [add_mul, one_mul]; clear * - hh; omega
    exact lt_of_lt_of_le ha hm
  unfold posDimWriteLocs
  exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
    (Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_right _
      (mem_heapRangeLocs hlt))))))

theorem mem_posDimWriteLocs_stage {d L K_max t i : ℕ}
    (ht : t = 5 ∨ t = 6 ∨ t = 7) (hi : i < 2 * d * 2 ^ L + 16) :
    RAMCellLoc.heap t (i : ℤ) ∈ posDimWriteLocs d L K_max := by
  unfold posDimWriteLocs
  rcases ht with rfl | rfl | rfl
  · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
      (Finset.mem_union_left _ (Finset.mem_union_right _ (mem_heapRangeLocs hi)))))
  · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
      (Finset.mem_union_right _ (mem_heapRangeLocs hi))))
  · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_right _
      (mem_heapRangeLocs hi)))

theorem mem_posDimWriteLocs_tab8 {d L K_max i : ℕ} (hi : i < 2 ^ L + 256) :
    RAMCellLoc.heap 8 (i : ℤ) ∈ posDimWriteLocs d L K_max := by
  unfold posDimWriteLocs
  exact Finset.mem_union_left _ (Finset.mem_union_right _ (mem_heapRangeLocs hi))

theorem mem_posDimWriteLocs_tab9 {d L K_max i : ℕ} (hi : i < 256) :
    RAMCellLoc.heap 9 (i : ℤ) ∈ posDimWriteLocs d L K_max := by
  unfold posDimWriteLocs
  exact Finset.mem_union_right _ (mem_heapRangeLocs hi)

private theorem card_treeSliceLocs_le (L tid : ℕ) :
    (treeSliceLocs L tid).card ≤ 8 * 2 ^ L := by
  unfold treeSliceLocs
  have hc : ((Finset.range (2 ^ (L + 1)) ×ˢ Finset.range 4).image
      (fun p => RAMCellLoc.heap 2 (treeCellAddr L tid p.1 p.2))).card ≤
      (Finset.range (2 ^ (L + 1)) ×ˢ Finset.range 4).card := Finset.card_image_le
  simp only [Finset.card_product, Finset.card_range] at hc
  have hp : 2 ^ (L + 1) * 4 = 8 * 2 ^ L := by rw [pow_succ]; ring
  rw [hp] at hc
  exact hc

theorem posDimWriteLocs_card_le (d L K_max : ℕ) :
    (posDimWriteLocs d L K_max).card ≤ (24 * K_max + 8 * d + 72) * 2 ^ L + (K_max + 2) * (2 * d + 8) + 600 := by
  unfold posDimWriteLocs
  set nodeStride := posNodeStride d L
  have cu : ∀ {s t : Finset RAMCellLoc} {a b : ℕ}, s.card ≤ a → t.card ≤ b → (s ∪ t).card ≤ a + b :=
    fun hs ht => (Finset.card_union_le _ _).trans (Nat.add_le_add hs ht)
  have c2 : ((Finset.range (2 * K_max + 6)).biUnion (fun tid => treeSliceLocs L tid)).card ≤
      (2 * K_max + 6) * (8 * 2 ^ L) := by
    calc ((Finset.range (2 * K_max + 6)).biUnion (fun tid => treeSliceLocs L tid)).card
      _ ≤ ∑ tid ∈ Finset.range (2 * K_max + 6), (treeSliceLocs L tid).card := Finset.card_biUnion_le
      _ ≤ ∑ _tid ∈ Finset.range (2 * K_max + 6), (8 * 2 ^ L) :=
          Finset.sum_le_sum (fun tid _ => card_treeSliceLocs_le L tid)
      _ = (2 * K_max + 6) * (8 * 2 ^ L) := by simp
  have hsum : (heapRangeLocs 0 16 ∪ heapRangeLocs 1 (2 * d * 2 ^ L) ∪
      (Finset.range (2 * K_max + 6)).biUnion (fun tid => treeSliceLocs L tid) ∪
      heapRangeLocs 3 ((K_max + 2) * nodeStride) ∪
      heapRangeLocs 4 ((K_max + 2) * 2 ^ L) ∪
      heapRangeLocs 5 (2 * d * 2 ^ L + 16) ∪
      heapRangeLocs 6 (2 * d * 2 ^ L + 16) ∪
      heapRangeLocs 7 (2 * d * 2 ^ L + 16) ∪
      heapRangeLocs 8 (2 ^ L + 256) ∪
      heapRangeLocs 9 256).card ≤
      ((((((((16 + 2 * d * 2 ^ L) + (2 * K_max + 6) * (8 * 2 ^ L)) +
      (K_max + 2) * nodeStride) + (K_max + 2) * 2 ^ L) +
      (2 * d * 2 ^ L + 16)) + (2 * d * 2 ^ L + 16)) + (2 * d * 2 ^ L + 16)) + (2 ^ L + 256)) + 256 :=
    cu (cu (cu (cu (cu (cu (cu (cu (cu
      (card_heapRangeLocs_le 0 16)
      (card_heapRangeLocs_le 1 _))
      c2)
      (card_heapRangeLocs_le 3 _))
      (card_heapRangeLocs_le 4 _))
      (card_heapRangeLocs_le 5 _))
      (card_heapRangeLocs_le 6 _))
      (card_heapRangeLocs_le 7 _))
      (card_heapRangeLocs_le 8 _))
      (card_heapRangeLocs_le 9 256)
  have hring : ((((((((16 + 2 * d * 2 ^ L) + (2 * K_max + 6) * (8 * 2 ^ L)) +
      (K_max + 2) * nodeStride) + (K_max + 2) * 2 ^ L) +
      (2 * d * 2 ^ L + 16)) + (2 * d * 2 ^ L + 16)) + (2 * d * 2 ^ L + 16)) + (2 ^ L + 256)) + 256 =
      (18 * K_max + 8 * d + 53) * 2 ^ L + (K_max + 2) * (2 * d + 8) + 576 := by
    dsimp [nodeStride, posNodeStride]; ring
  rw [hring] at hsum
  have hm_pow : (18 * K_max + 8 * d + 53) * 2 ^ L ≤ (24 * K_max + 8 * d + 72) * 2 ^ L :=
    Nat.mul_le_mul_right _ (by clear * -; omega)
  linarith only [hsum, hm_pow]

/-! ### 3. Lifetime-Handle Bijection on `DynamicPointSet` and Rational Squared Radius Weights -/

noncomputable def activeLifetimes {d : ℕ} (P : DynamicPointSet d) : Finset ℕ :=
  P.activeIds.image P.lifetimeOfId

theorem lifetimeOfId_injOn {d n : ℕ} {P : DynamicPointSet d} (hwf : P.WellFormed n) :
    Set.InjOn P.lifetimeOfId (P.activeIds : Set ℕ) := by
  intro id₁ h₁ id₂ h₂ heq
  exact hwf.2.2.2.2 id₁ h₁ id₂ h₂ heq

theorem handleOfId_injOn {d n : ℕ} {P : DynamicPointSet d} (hwf : P.WellFormed n) :
    Set.InjOn P.handleOfId (P.activeIds : Set ℕ) := by
  intro id₁ h₁ id₂ h₂ heq
  have e1 := (hwf.2.1 id₁ h₁).2
  have e2 := (hwf.2.1 id₂ h₂).2
  rw [heq] at e1
  exact e1.symm.trans e2

/-- Map an active lifetime `lt ∈ activeLifetimes P` to its unique active handle in `P` (`0` off-domain). -/
noncomputable def handleOfLifetime {d : ℕ} (P : DynamicPointSet d) (lt : ℕ) : ℕ :=
  open Classical in
  if h : ∃ id ∈ P.activeIds, P.lifetimeOfId id = lt then
    P.handleOfId (Classical.choose h)
  else
    0

theorem handleOfLifetime_of_mem {d n : ℕ} {P : DynamicPointSet d} (hwf : P.WellFormed n)
    {id : ℕ} (hid : id ∈ P.activeIds) :
    handleOfLifetime P (P.lifetimeOfId id) = P.handleOfId id := by
  unfold handleOfLifetime
  have hex : ∃ id' ∈ P.activeIds, P.lifetimeOfId id' = P.lifetimeOfId id := ⟨id, hid, rfl⟩
  rw [dif_pos hex]
  have hspec := Classical.choose_spec hex
  have heq : Classical.choose hex = id := hwf.2.2.2.2 _ hspec.1 _ hid hspec.2
  rw [heq]

theorem image_handleOfLifetime_active {d n : ℕ} {P : DynamicPointSet d} (hwf : P.WellFormed n) :
    (activeLifetimes P).image (handleOfLifetime P) = P.activeHandles := by
  ext h
  simp only [activeLifetimes, Finset.mem_image]
  constructor
  · rintro ⟨lt, ⟨id, hid, rfl⟩, rfl⟩
    rw [handleOfLifetime_of_mem hwf hid]
    exact (hwf.2.1 id hid).1
  · intro hh
    refine ⟨P.lifetimeOfId (P.idOfHandle h), ⟨P.idOfHandle h, (hwf.2.2.1 h hh).1, rfl⟩, ?_⟩
    rw [handleOfLifetime_of_mem hwf (hwf.2.2.1 h hh).1, (hwf.2.2.1 h hh).2]

theorem handleOfLifetime_injOn {d n : ℕ} {P : DynamicPointSet d} (hwf : P.WellFormed n) :
    Set.InjOn (handleOfLifetime P) (activeLifetimes P : Set ℕ) := by
  intro lt₁ h₁ lt₂ h₂ heq
  simp only [Finset.mem_coe, activeLifetimes, Finset.mem_image] at h₁ h₂
  rcases h₁ with ⟨id₁, hid₁, rfl⟩
  rcases h₂ with ⟨id₂, hid₂, rfl⟩
  rw [handleOfLifetime_of_mem hwf hid₁, handleOfLifetime_of_mem hwf hid₂] at heq
  have hid_eq := handleOfId_injOn hwf hid₁ hid₂ heq
  rw [hid_eq]

theorem activeLifetimes_insert_spec {d n : ℕ} {P P' : DynamicPointSet d}
    (hwf : P.WellFormed n) (hwf' : P'.WellFormed n)
    {id : ℕ} {extName : List Bool} {pt : EuclideanSpace ℝ (Fin d)} {hNew : ℕ}
    (happ : applyDynamicUpdate P (.insert id extName pt) (some hNew) = some P') :
    P.nextLifetime ∉ activeLifetimes P ∧
    activeLifetimes P' = insert P.nextLifetime (activeLifetimes P) ∧
    P'.nextLifetime = P.nextLifetime + 1 ∧
    handleOfLifetime P' P.nextLifetime = hNew ∧
    (∀ lt ∈ activeLifetimes P, handleOfLifetime P' lt = handleOfLifetime P lt) := by
  dsimp only [applyDynamicUpdate] at happ
  split_ifs at happ with hcond
  injection happ with hP'
  rcases hcond with ⟨hid_not, hhNew_not⟩
  have hnot_lt : P.nextLifetime ∉ activeLifetimes P := by
    intro hm
    simp only [activeLifetimes, Finset.mem_image] at hm
    rcases hm with ⟨id₀, hid₀, heq⟩
    exact Nat.ne_of_lt (hwf.2.2.2.1 id₀ hid₀) heq
  have hact_eq : activeLifetimes P' = insert P.nextLifetime (activeLifetimes P) := by
    subst hP'
    ext lt
    simp only [activeLifetimes, Finset.mem_image, Finset.mem_insert]
    constructor
    · rintro ⟨id₀, rfl | hid₀, rfl⟩
      · simp
      · have hne : id₀ ≠ id := fun h => hid_not (h ▸ hid₀)
        simp [Function.update_of_ne hne]
        exact Or.inr ⟨id₀, hid₀, rfl⟩
    · rintro (rfl | ⟨id₀, hid₀, rfl⟩)
      · exact ⟨id, Or.inl rfl, by simp⟩
      · have hne : id₀ ≠ id := fun h => hid_not (h ▸ hid₀)
        exact ⟨id₀, Or.inr hid₀, by simp [Function.update_of_ne hne]⟩
  have hnext : P'.nextLifetime = P.nextLifetime + 1 := by subst hP'; rfl
  have hh_new : handleOfLifetime P' P.nextLifetime = hNew := by
    have hid_mem' : id ∈ P'.activeIds := by subst hP'; simp
    have hlt_id' : P'.lifetimeOfId id = P.nextLifetime := by subst hP'; simp
    have hhd_id' : P'.handleOfId id = hNew := by subst hP'; simp
    rw [← hlt_id', handleOfLifetime_of_mem hwf' hid_mem', hhd_id']
  have hh_old : ∀ lt ∈ activeLifetimes P, handleOfLifetime P' lt = handleOfLifetime P lt := by
    intro lt hlt
    simp only [activeLifetimes, Finset.mem_image] at hlt
    rcases hlt with ⟨id₀, hid₀, rfl⟩
    have hne : id₀ ≠ id := fun h => hid_not (h ▸ hid₀)
    have hid₀' : id₀ ∈ P'.activeIds := by subst hP'; exact Finset.mem_insert_of_mem hid₀
    have hlt₀' : P'.lifetimeOfId id₀ = P.lifetimeOfId id₀ := by
      subst hP'; simp [Function.update_of_ne hne]
    have hhd₀' : P'.handleOfId id₀ = P.handleOfId id₀ := by
      subst hP'; simp [Function.update_of_ne hne]
    rw [← hlt₀', handleOfLifetime_of_mem hwf' hid₀', hlt₀', hhd₀', handleOfLifetime_of_mem hwf hid₀]
  exact ⟨hnot_lt, hact_eq, hnext, hh_new, hh_old⟩

theorem activeLifetimes_delete_spec {d n : ℕ} {P P' : DynamicPointSet d}
    (hwf : P.WellFormed n) (hwf' : P'.WellFormed n)
    {id : ℕ}
    (happ : applyDynamicUpdate P (.delete id) none = some P') :
    let delLt := P.lifetimeOfId id
    delLt ∈ activeLifetimes P ∧
    activeLifetimes P' = (activeLifetimes P).erase delLt ∧
    P'.nextLifetime = P.nextLifetime ∧
    handleOfLifetime P delLt = P.handleOfId id ∧
    (∀ lt ∈ activeLifetimes P', handleOfLifetime P' lt = handleOfLifetime P lt) := by
  dsimp only [applyDynamicUpdate] at happ
  split_ifs at happ with hid_mem
  injection happ with hP'
  have hdel_mem : P.lifetimeOfId id ∈ activeLifetimes P :=
    Finset.mem_image.mpr ⟨id, hid_mem, rfl⟩
  have hact_eq : activeLifetimes P' = (activeLifetimes P).erase (P.lifetimeOfId id) := by
    subst hP'
    ext lt
    simp only [activeLifetimes, Finset.mem_image, Finset.mem_erase]
    constructor
    · rintro ⟨id₀, ⟨hne, hid₀⟩, rfl⟩
      simp only [Function.update_of_ne hne]
      refine ⟨fun heq => hne (hwf.2.2.2.2 id₀ hid₀ id hid_mem heq), id₀, hid₀, rfl⟩
    · rintro ⟨hlt_ne, id₀, hid₀, rfl⟩
      have hne : id₀ ≠ id := fun h => hlt_ne (h ▸ rfl)
      exact ⟨id₀, ⟨hne, hid₀⟩, by simp [Function.update_of_ne hne]⟩
  have hnext : P'.nextLifetime = P.nextLifetime := by subst hP'; rfl
  have hh_del : handleOfLifetime P (P.lifetimeOfId id) = P.handleOfId id :=
    handleOfLifetime_of_mem hwf hid_mem
  have hh_old : ∀ lt ∈ activeLifetimes P', handleOfLifetime P' lt = handleOfLifetime P lt := by
    intro lt hlt
    rw [hact_eq] at hlt
    rcases Finset.mem_erase.mp hlt with ⟨hlt_ne, hlt_old⟩
    simp only [activeLifetimes, Finset.mem_image] at hlt_old
    rcases hlt_old with ⟨id₀, hid₀, rfl⟩
    have hne : id₀ ≠ id := fun h => hlt_ne (h ▸ rfl)
    have hid₀' : id₀ ∈ P'.activeIds := by subst hP'; exact Finset.mem_erase.mpr ⟨hne, hid₀⟩
    have hlt₀' : P'.lifetimeOfId id₀ = P.lifetimeOfId id₀ := by
      subst hP'; simp [Function.update_of_ne hne]
    have hhd₀' : P'.handleOfId id₀ = P.handleOfId id₀ := by
      subst hP'; simp [Function.update_of_ne hne]
    rw [← hlt₀', handleOfLifetime_of_mem hwf' hid₀', hlt₀', hhd₀', handleOfLifetime_of_mem hwf hid₀]
  exact ⟨hdel_mem, hact_eq, hnext, hh_del, hh_old⟩

/-- Bit-length ceiling for squared-radius numerators/denominators produced by `sqRadAndCoreRegs`. -/
def sqRadBitBound (d B B_cert : ℕ) : ℕ :=
  (d + 1) * (2 * ((B + 2) + B_cert) + 4) + 4

/-! ### 4. `PosDimNodeData` and `ChainStoredInv` -/

/-- Auxiliary certified node data stored in `SyncBuiltNode d (PosDimNodeData d s₀_d)`. -/
structure PosDimNodeData (d s₀_d : ℕ) : Type where
  k_blk : ℕ
  oRat : Fin d → ℚ
  sRat : ℚ
  V_num : ℤ
  V_den : ℤ
  birthHandles : Fin k_blk → Fin s₀_d → ℕ
  birthLifetimes : Fin k_blk → Fin s₀_d → ℕ
  lam : Fin k_blk → Fin s₀_d → ℚ

/-- Per-level RAM and mathematical invariant at active chain index `j < k`. -/
structure LevelStoredInv {d s₀_d : ℕ} (n L B B_cert K_max : ℕ)
    (P : DynamicPointSet d) (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (qMap : ℕ → Fin d → ℚ)
    (S_lt : Finset ℕ)
    (v : SyncLiveChainNode d (PosDimNodeData d s₀_d))
    (j : ℕ) (ws : WordStore) : Prop where
  hj_le : j ≤ K_max
  hm_bounds : 2 * s₀_d ≤ v.birthPool.card ∧ v.birthPool.card ≤ n
  hage_le : (v.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (v.birthPool.card : ℝ) / 16
  hage_rel : HasNodeAge v.birthPool S_lt v.ageUpdateSteps.card
  hnode_o : v.built.node.o = ratPointToEuclidean v.built.aux.oRat
  hnode_s : v.built.s = (v.built.aux.sRat : ℝ)
  hnode_V : v.built.node.V = liftVariance v.built.node.o v.built.s
  hcp : IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
          (paraboloidLiftSet (fun x : v.birthPool => ltCoords x.1))
          (liftedPoint v.built.node.o v.built.s)
  hk_bounds : 1 ≤ v.built.aux.k_blk ∧ v.built.aux.k_blk * s₀_d ≤ v.birthPool.card
  hk_ratio : (v.birthPool.card : ℝ) / (4 * (s₀_d : ℝ)) ≤ (v.built.aux.k_blk : ℝ)
  hbirth_adm : ∀ lt ∈ v.birthPool, lt < P.nextLifetime ∧ ltCoords lt ∈ RatAdmissiblePointSet d B
  hgeom : NodeGeomStored d (posNodeStride d L) B_cert j
            v.built.aux.oRat v.built.aux.V_num v.built.aux.V_den v.built.node.V ws
  read_age : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) = (v.ageUpdateSteps.card : ℤ)
  read_mbirth : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 1)) = (v.birthPool.card : ℤ)
  read_kblk : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (v.built.aux.k_blk : ℤ)
  hbh_lt : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d), v.built.aux.birthHandles b t < 2 ^ L
  hbh_inj : Function.Injective2 v.built.aux.birthHandles
  hblt_mem : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
    v.built.aux.birthLifetimes b t ∈ v.birthPool ∧
    v.built.aux.birthLifetimes b t < P.nextLifetime
  hblt_inj : Function.Injective2 v.built.aux.birthLifetimes
  hbh_active_sync : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
    v.built.aux.birthLifetimes b t ∈ activeLifetimes P →
      handleOfLifetime P (v.built.aux.birthLifetimes b t) = v.built.aux.birthHandles b t
  read_bh : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
    ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b.val * s₀_d + t.val)))) =
      (v.built.aux.birthHandles b t : ℤ)
  unused_tab3 : ∀ off : ℕ, 6 + 2 * d + v.built.aux.k_blk * s₀_d ≤ off → off < posNodeStride d L →
    (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ ws.live
  hcerts : ∀ b : Fin v.built.aux.k_blk,
    IsBlockCertificate ltCoords v.birthPool (liftedPoint v.built.node.o v.built.s)
      (Finset.univ.image (v.built.aux.birthLifetimes b))
      (fun lt => ∑ t : Fin s₀_d, if v.built.aux.birthLifetimes b t = lt then (v.built.aux.lam b t : ℝ) else 0)
  tree_Sj : ∃ (rNum rDen : ℕ → ℤ),
    TreeStoredAt L (2 * j + 2) (S_lt.image (handleOfLifetime P)) rNum rDen ws ∧
    (∀ h ∈ S_lt.image (handleOfLifetime P),
      1 ≤ rDen h ∧
      ((rNum h : ℝ) / (rDen h : ℝ)) = ‖ratPointToEuclidean (qMap h) - v.built.node.o‖ ^ 2 ∧
      intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧
      intBitLength (rDen h) ≤ sqRadBitBound d B B_cert)
  tab4_spec : ∀ h < 2 ^ L,
    (∃ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
      v.built.aux.birthLifetimes b t ∈ activeLifetimes P ∧
      v.built.aux.birthHandles b t = h ∧
      (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ ws.live ∧
      ws.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) = ((b.val + 1 : ℕ) : ℤ)) ∨
    ((∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
        v.built.aux.birthHandles b t = h → v.built.aux.birthLifetimes b t ∉ activeLifetimes P) ∧
      (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ ws.live)
  tree_intact :
    let B_intact : Finset ℕ :=
      (Finset.univ.filter (fun b : Fin v.built.aux.k_blk =>
        ∀ t : Fin s₀_d, v.built.aux.birthLifetimes b t ∈ activeLifetimes P)).image Fin.val
    B_intact.Nonempty ∧
    TreeStoredAt L (2 * j + 3) B_intact (fun _ => 0) (fun _ => 1) ws

/-- Empty-slot condition for inactive level indices `j` (`k ≤ j ≤ K_max + 1`). -/
def EmptyLevelSlot (d L j : ℕ) (ws : WordStore) : Prop :=
  (∀ off < posNodeStride d L, (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ ws.live) ∧
  (∀ h < 2 ^ L, (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ ws.live) ∧
  (∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L (2 * j + 2) u f) : RAMCellLoc) ∉ ws.live) ∧
  (∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∉ ws.live)

/-- Full RAM state invariant relating `ws : WordStore` to `(P, ltCoords, nodes)` between steps. -/
structure ChainStoredInv {d s₀_d : ℕ} (n L B B_cert K_max W : ℕ)
    (P : DynamicPointSet d)
    (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)))
    (qMap : ℕ → Fin d → ℚ)
    (ws : WordStore) : Prop where
  wfP : P.WellFormed n
  mod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws
  hk_le : nodes.length ≤ K_max
  read_k : ws.read (.heap 0 10) = (nodes.length : ℤ)
  hlt_sync : ∀ id ∈ P.activeIds,
    ltCoords (P.lifetimeOfId id) = P.coords id ∧
    P.coords id = ratPointToEuclidean (qMap (P.handleOfId id))
  hlt_adm : ∀ lt < P.nextLifetime, ltCoords lt ∈ RatAdmissiblePointSet d B ∨ ltCoords lt = 0
  coords_stored : ActiveCoordsStored d L B P.activeHandles qMap ws
  tree_active : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) ws
  hbirth_avoid : ∀ (j : ℕ) (hj : j < nodes.length),
    ∀ lt ∈ (nodes.get ⟨j, hj⟩).birthPool,
      ∀ (i : ℕ) (hi : i < j),
        ltCoords lt ∉ coreBall (nodes.get ⟨i, Nat.lt_trans hi hj⟩).built.node.o
          (nodes.get ⟨i, Nat.lt_trans hi hj⟩).built.node.V
  levels : ∀ (j : ℕ) (hj : j < nodes.length),
    let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
    let S_lt := chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩
    LevelStoredInv n L B B_cert K_max P ltCoords qMap S_lt (nodes.get ⟨j, hj⟩) j ws
  empty_levels : ∀ j : ℕ, nodes.length ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j ws
  tree_leaf :
    let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
    let S_k_lt := chainInput ltCoords vecNodes (activeLifetimes P) (Fin.last nodes.length)
    S_k_lt.card ≤ 2 * (2 * s₀_d - 1) ∧
    TreeStoredAt L 1 (S_k_lt.image (handleOfLifetime P)) (fun _ => 0) (fun _ => 1) ws
  stage_clean : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7 ∨ t = 8 ∨ t = 9) → ∀ z : ℤ,
    (.heap t z : RAMCellLoc) ∉ ws.live

theorem ChainStoredInv.isA2Base {d s₀_d n L B B_cert K_max W : ℕ}
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    (h : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws) :
    IsA2BaseStore ws := by
  refine ⟨h.mod.wf, fun loc hloc => ?_⟩
  have hsub := h.mod.live_sub hloc
  simp only [WordStore.empty, Finset.empty_union] at hsub
  exact posDimWriteLocs_isA2Base loc hsub

theorem ChainStoredInv.no_local {d s₀_d n L B B_cert K_max W : ℕ}
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    (h : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws) :
    ∀ d' ≥ 1, ∀ v i, (.localFrame d' v i : RAMCellLoc) ∉ ws.live := by
  intro d' _ v i hm
  have hsub := h.mod.live_sub hm
  simp only [WordStore.empty, Finset.empty_union] at hsub
  rcases posDimWriteLocs_isHeap _ hsub with ⟨t, _, z, hloc⟩
  cases hloc

theorem ChainStoredInv.init {d s₀_d n B B_cert K_max W : ℕ} :
    let L := Nat.clog 2 (2 * n)
    ChainStoredInv (s₀_d := s₀_d) n L B B_cert K_max W
      (DynamicPointSet.empty d) (fun _ => 0) [] (fun _ _ => 0) WordStore.empty := by
  intro L
  have hwfP : (DynamicPointSet.empty d).WellFormed n := by
    simp [DynamicPointSet.WellFormed, DynamicPointSet.empty]
  have hwfEmpty : WellFormedWS WordStore.empty := fun _ _ => rfl
  refine
    { wfP := hwfP
      mod := ModifiedOnBounded.refl hwfEmpty _ W (fun _ hm => absurd hm (by simp [WordStore.empty]))
      hk_le := Nat.zero_le _
      read_k := by simp [WordStore.read, WordStore.empty]
      hlt_sync := by simp [DynamicPointSet.empty]
      hlt_adm := fun _ _ => Or.inr rfl
      coords_stored :=
        { hS := by simp [DynamicPointSet.empty]
          read_num := by simp [DynamicPointSet.empty]
          read_den := by simp [DynamicPointSet.empty] }
      tree_active := by
        have hact : (DynamicPointSet.empty d).activeHandles = ∅ := rfl
        rw [hact]
        exact TreeStoredAt.empty L 0 _ _ (by simp [WordStore.empty])
      hbirth_avoid := fun j hj => absurd hj (Nat.not_lt_zero _)
      levels := fun j hj => absurd hj (Nat.not_lt_zero _)
      empty_levels := fun _ _ _ =>
        ⟨by simp [WordStore.empty], by simp [WordStore.empty],
         by simp [WordStore.empty], by simp [WordStore.empty]⟩
      tree_leaf := by
        have hlt_emp : activeLifetimes (DynamicPointSet.empty d) = ∅ := by
          simp [activeLifetimes, DynamicPointSet.empty]
        have hci_emp : chainInput (fun _ => (0 : EuclideanSpace ℝ (Fin d)))
            (fun i : Fin 0 => ([] : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))).get i |>.built.node)
            (activeLifetimes (DynamicPointSet.empty d)) (Fin.last 0) = ∅ := by
          rw [hlt_emp]; rfl
        dsimp only [List.length_nil]
        rw [hci_emp, Finset.image_empty]
        exact ⟨Nat.zero_le _, TreeStoredAt.empty L 1 _ _ (by simp [WordStore.empty])⟩
      stage_clean := by simp [WordStore.empty] }

end UL.C12LVE
