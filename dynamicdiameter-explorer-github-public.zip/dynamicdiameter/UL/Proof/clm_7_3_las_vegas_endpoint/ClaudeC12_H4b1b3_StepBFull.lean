import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b3a_StepBLevel
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 3. Full Step B Execution (`exec_posDimStepB`): Chain Loop + Leaf Update + `jStar` -/

theorem exec_posDimStepB {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P P' : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap qMap' : ℕ → Fin d → ℚ} {ws wsA : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    {u : ℕ} (hu_age : ∀ (j : Fin nodes.length), ∀ s ∈ (nodes.get j).ageUpdateSteps, s < u)
    {op : DynamicUpdate d} {hOp : ℕ} (hhOp_lt : hOp < 2 ^ L)
    (hwfP' : P'.WellFormed n)
    (hmA : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsA)
    (hcoordsA : ActiveCoordsStored d L B P'.activeHandles qMap' wsA)
    (htree0A : TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsA)
    (hr102A : wsA.read (.heap 9 102) = opIsIns op)
    (hr103A : wsA.read (.heap 9 103) = (hOp : ℤ))
    (hop_spec : OpStepASpec P P' qMap qMap' hOp op)
    (hunchA : ∀ loc : RAMCellLoc,
      loc ≠ .heap 0 0 → loc ≠ .heap 9 102 → loc ≠ .heap 9 103 →
      loc ∉ treeSliceLocs L 0 →
      (∀ c < d, ∀ f < 2, loc ≠ .heap 1 (coordCellAddr d hOp c f)) →
      (loc ∈ wsA.live ↔ loc ∈ ws.live) ∧ wsA.vals loc = ws.vals loc)
    {regsA : ℕ → ℤ} (hbndA : RegBounded W regsA) :
    let k := nodes.length
    let vecNodes : Fin k → ChainNode d := fun i => (nodes.get i).built.node
    let ltCoords' : ℕ → EuclideanSpace ℝ (Fin d) := opNextLtCoords P ltCoords op
    let S_old : Fin (k + 1) → Finset ℕ := chainInput ltCoords' vecNodes (activeLifetimes P)
    let S_new : Fin (k + 1) → Finset ℕ := chainInput ltCoords' vecNodes (activeLifetimes P')
    let updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)) :=
      open Classical in
      List.ofFn (fun i : Fin k =>
        let v := nodes.get i
        let age' := if S_new i.castSucc ≠ S_old i.castSucc then insert u v.ageUpdateSteps else v.ageUpdateSteps
        { v with ageUpdateSteps := age' })
    let slotTriggers : ℕ → Prop := fun j =>
      open Classical in
      if hj : j < k then
        let vOld := nodes.get ⟨j, hj⟩
        let ageCard :=
          (if S_new ⟨j, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨j, Nat.lt_succ_of_lt hj⟩ then
            insert u vOld.ageUpdateSteps
          else
            vOld.ageUpdateSteps).card
        (1 / (4 * (s₀_d : ℝ))) * (vOld.birthPool.card : ℝ) / 16 < (ageCard : ℝ)
      else
        j = k ∧ 2 * (2 * s₀_d - 1) < (S_new (Fin.last k)).card
    let jStar := jStarStep k slotTriggers (k + 1)
    ∃ wsB regsB,
      RegExec inp fd W C_cell C_bit (posDimStepB d s₀_d L) wsA regsA wsB regsB
        ((k + 1) * (950 * L + 300 * d + 900)) ((k + 1) * (180 * L + 80 * d + 240) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsB ∧
      RegBounded W regsB ∧
      wsB.read (.heap 0 10) = (k : ℤ) ∧
      wsB.read (.heap 0 0) = wsA.read (.heap 0 0) ∧
      wsB.read (.heap 9 106) = (jStar : ℤ) ∧
      ActiveCoordsStored d L B P'.activeHandles qMap' wsB ∧
      TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsB ∧
      TreeStoredAt L 1 ((S_new (Fin.last k)).image (handleOfLifetime P')) (fun _ => 0) (fun _ => 1) wsB ∧
      (∀ (j : ℕ) (hj : j < k),
        PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap'
          (S_new ⟨j, Nat.lt_succ_of_lt hj⟩)
          (updatedNodes.get ⟨j, by simp [updatedNodes, k, hj]⟩) j wsB) ∧
      (∀ j : ℕ, k ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j wsB) ∧
      (∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7 ∨ t = 8) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsB.live) ∧
      (∀ z : ℤ, z ≠ 102 → z ≠ 103 → z ≠ 104 → z ≠ 105 → z ≠ 106 → (.heap 9 z : RAMCellLoc) ∉ wsB.live) := by
  intro k vecNodes ltCoords' S_old S_new updatedNodes slotTriggers jStar
  have ⟨hL2, _, h2n_pow, _⟩ := clog_two_mul_bounds hn
  rw [← hL] at hL2 h2n_pow
  have hL1 : 1 ≤ L := by clear * - hL2; omega
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hk_le : k ≤ K_max := hinv.hk_le
  have hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    have : WordStore.empty.cellCount = 0 := by simp [WordStore.cellCount, WordStore.empty]
    linarith only [hcCeil, this]
  have hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    have : WordStore.empty.bitSize = 0 := by simp [WordStore.bitSize, WordStore.empty]
    linarith only [hbCeil, this]
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil0], by linarith only [bs, hbCeil0]⟩
  -- Lift `levels`, `empty_levels`, `tree_leaf`, `read_k` from `ws` to `wsA`
  have hrA_k : wsA.read (.heap 0 10) = (k : ℤ) := by
    rw [wordStore_read_eq_vals hmA.wf,
        (hunchA _ (by decide) (by decide) (by decide) (not_in_treeSlice_of_table_ne (by decide) _)
          (fun _ _ _ _ h => by cases h)).2,
        ← wordStore_read_eq_vals hinv.mod.wf]
    exact hinv.read_k
  have hlevelsA : ∀ (j : ℕ) (hj : j < k),
      LevelStoredInv n L B B_cert K_max P ltCoords qMap
        (chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩)
        (nodes.get ⟨j, hj⟩) j wsA := by
    intro j hj
    exact (hinv.levels j hj).unchanged hinv.mod.wf hmA.wf
      (fun off _ => hunchA _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_table_ne (by decide) _) (fun _ _ _ _ h => by cases h))
      (fun h' _ => hunchA _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_table_ne (by decide) _) (fun _ _ _ _ h => by cases h))
      (fun u hu f hf => hunchA _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_tid_ne hu hf (by clear * -; omega)) (fun _ _ _ _ h => by cases h))
      (fun u hu f hf => hunchA _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_tid_ne hu hf (by clear * -; omega)) (fun _ _ _ _ h => by cases h))
  have hemptyA : ∀ j : ℕ, k ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j wsA := by
    intro j hlo hhi
    exact (hinv.empty_levels j hlo hhi).unchanged
      (fun off _ => (hunchA _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_table_ne (by decide) _) (fun _ _ _ _ h => by cases h)).1.mp)
      (fun h' _ => (hunchA _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_table_ne (by decide) _) (fun _ _ _ _ h => by cases h)).1.mp)
      (fun u hu f hf => (hunchA _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_tid_ne hu hf (by clear * -; omega)) (fun _ _ _ _ h => by cases h)).1.mp)
      (fun u hu f hf => (hunchA _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_tid_ne hu hf (by clear * -; omega)) (fun _ _ _ _ h => by cases h)).1.mp)
  have hleafA : TreeStoredAt L 1
      ((chainInput ltCoords vecNodes (activeLifetimes P) (Fin.last k)).image (handleOfLifetime P))
      (fun _ => 0) (fun _ => 1) wsA :=
    hinv.tree_leaf.2.unchanged (fun u hu f hf => hunchA _ (by intro h; cases h) (by intro h; cases h)
      (by intro h; cases h) (not_in_treeSlice_of_tid_ne hu hf (by decide)) (fun _ _ _ _ h => by cases h))
  -- Header setup: r5 := k, heap 9 104 := 0, heap 9 105 := 1, heap 9 106 := k + 1
  have hk_bl : intBitLength (k : ℤ) ≤ W :=
    j_bl_of_level (d := d) (L := L) (K_max := K_max) (Nat.le_succ_of_le hk_le) (by clear * - hW; omega)
  have hk1_bl : intBitLength ((k + 1 : ℕ) : ℤ) ≤ W :=
    j_bl_of_level (d := d) (L := L) (K_max := K_max) (Nat.succ_le_succ hk_le) (by clear * - hW; omega)
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have h : intBitLength (0 : ℤ) = 1 := (by decide); clear * - h hW40; omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have h : intBitLength (1 : ℤ) = 2 := (by decide); clear * - h hW40; omega
  have hl2 : intBitLength (2 : ℤ) ≤ W := by have h : intBitLength (2 : ℤ) = 3 := (by decide); clear * - h hW40; omega
  have hl10 : intBitLength (10 : ℤ) ≤ W := by have h : intBitLength (10 : ℤ) = 5 := (by decide); clear * - h hW40; omega
  have hl102 : intBitLength (102 : ℤ) ≤ W := by have h : intBitLength (102 : ℤ) = 8 := (by decide); clear * - h hW40; omega
  have hl103 : intBitLength (103 : ℤ) ≤ W := by have h : intBitLength (103 : ℤ) = 8 := (by decide); clear * - h hW40; omega
  have hl104 : intBitLength (104 : ℤ) ≤ W := by have h : intBitLength (104 : ℤ) = 8 := (by decide); clear * - h hW40; omega
  have hl105 : intBitLength (105 : ℤ) ≤ W := by have h : intBitLength (105 : ℤ) = 8 := (by decide); clear * - h hW40; omega
  have hl106 : intBitLength (106 : ℤ) ≤ W := by have h : intBitLength (106 : ℤ) = 8 := (by decide); clear * - h hW40; omega
  have hn0 : natBitLength 0 ≤ W := by have h : natBitLength 0 ≤ 4 := (by decide); clear * - h hW40; omega
  have hn9 : natBitLength 9 ≤ W := by have h : natBitLength 9 = 4 := (by decide); clear * - h hW40; omega
  have hloc104 : (RAMCellLoc.heap 9 104).bitLength ≤ W := by have h : (RAMCellLoc.heap 9 104).bitLength = 12 := (by decide); clear * - h hW40; omega
  have hloc105 : (RAMCellLoc.heap 9 105).bitLength ≤ W := by have h : (RAMCellLoc.heap 9 105).bitLength = 12 := (by decide); clear * - h hW40; omega
  have hloc106 : (RAMCellLoc.heap 9 106).bitLength ≤ W := by have h : (RAMCellLoc.heap 9 106).bitLength = 12 := (by decide); clear * - h hW40; omega
  have hhOp_bl : intBitLength (hOp : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hhOp_lt).trans (by clear * - hW; omega)
  have s1 := RegExec.lit (inp := inp) hfd_le hbndA (sp_ok hmA).1 (sp_ok hmA).2 (dst := 10) (c := 10) (by decide) hl10
  set g1 := Function.update regsA 10 10; have bg1 := hbndA.update (r := 10) (by decide) hl10
  have hg1_r : wsA.read (.heap 0 (g1 10)) = (k : ℤ) := by simp only [g1, Function.update_self]; exact hrA_k
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmA).1 (sp_ok hmA).2 (dst := 5) (table := 0) (addr := 10)
    (by decide) (by decide) hn0 (by rw [hg1_r]; exact hk_bl)
  rw [hg1_r] at s2; set g2 := Function.update g1 5 (k : ℤ); have bg2 := bg1.update (r := 5) (by decide) hk_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmA).1 (sp_ok hmA).2 (dst := 10) (c := 104) (by decide) hl104
  set g3 := Function.update g2 10 104; have bg3 := bg2.update (r := 10) (by decide) hl104
  have s4 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hmA).1 (sp_ok hmA).2 (dst := 13) (c := 0) (by decide) hl0
  set g4 := Function.update g3 13 0; have bg4 := bg3.update (r := 13) (by decide) hl0
  have hm_w1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (wsA.write (.heap 9 (g4 10)) (g4 13)) := by
    simpa [g4, g3] using hmA.write (mem_posDimWriteLocs_tab9 (by decide)) 0 hloc104 hl0
  have s5 := RegExec.store (inp := inp) hfd_le bg4 (table := 9) (addr := 10) (val := 13) (by decide) (by decide) hn9
    (sp_ok hm_w1).1 (sp_ok hm_w1).2
  set ws1 := wsA.write (.heap 9 104) 0
  have hw1_eq : wsA.write (.heap 9 (g4 10)) (g4 13) = ws1 := by simp [ws1, g4, g3]
  rw [hw1_eq] at s5 hm_w1
  have s6 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 10) (c := 105) (by decide) hl105
  set g5 := Function.update g4 10 105; have bg5 := bg4.update (r := 10) (by decide) hl105
  have s7 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 13) (c := 1) (by decide) hl1
  set g6 := Function.update g5 13 1; have bg6 := bg5.update (r := 13) (by decide) hl1
  have hm_w2 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (ws1.write (.heap 9 (g6 10)) (g6 13)) := by
    simpa [g6, g5] using hm_w1.write (mem_posDimWriteLocs_tab9 (by decide)) 1 hloc105 hl1
  have s8 := RegExec.store (inp := inp) hfd_le bg6 (table := 9) (addr := 10) (val := 13) (by decide) (by decide) hn9
    (sp_ok hm_w2).1 (sp_ok hm_w2).2
  set ws2 := ws1.write (.heap 9 105) 1
  have hw2_eq : ws1.write (.heap 9 (g6 10)) (g6 13) = ws2 := by simp [ws2, g6, g5]
  rw [hw2_eq] at s8 hm_w2
  have s9 := RegExec.lit (inp := inp) hfd_le bg6 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 14) (c := 1) (by decide) hl1
  set g7 := Function.update g6 14 1; have bg7 := bg6.update (r := 14) (by decide) hl1
  have hak1 : g7 5 + g7 14 = ((k + 1 : ℕ) : ℤ) := by simp [g7, g6, g5, g4, g3, g2]
  have s10 := RegExec.add (inp := inp) hfd_le bg7 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 13) (a := 5) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hak1]; exact hk1_bl)
  rw [hak1] at s10; set g8 := Function.update g7 13 ((k + 1 : ℕ) : ℤ); have bg8 := bg7.update (r := 13) (by decide) hk1_bl
  have s11 := RegExec.lit (inp := inp) hfd_le bg8 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 10) (c := 106) (by decide) hl106
  set g9 := Function.update g8 10 106; have bg9 := bg8.update (r := 10) (by decide) hl106
  have hm_w3 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W (ws2.write (.heap 9 (g9 10)) (g9 13)) := by
    simpa [g9, g8] using hm_w2.write (mem_posDimWriteLocs_tab9 (by decide)) ((k + 1 : ℕ) : ℤ) hloc106 hk1_bl
  have s12 := RegExec.store (inp := inp) hfd_le bg9 (table := 9) (addr := 10) (val := 13) (by decide) (by decide) hn9
    (sp_ok hm_w3).1 (sp_ok hm_w3).2
  set ws3 := ws2.write (.heap 9 106) ((k + 1 : ℕ) : ℤ)
  have hw3_eq : ws2.write (.heap 9 (g9 10)) (g9 13) = ws3 := by simp [ws3, g9, g8]
  rw [hw3_eq] at s12 hm_w3
  -- Build loop sequence `m = 0 .. k`
  let LoopInv (m : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
    ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
    RegBounded W g ∧
    w.read (.heap 9 102) = opIsIns op ∧
    w.read (.heap 9 103) = (hOp : ℤ) ∧
    w.read (.heap 9 104) = (m : ℤ) ∧
    w.read (.heap 9 106) = (jStarStep k slotTriggers m : ℤ) ∧
    (∃ alive_m : Bool, OpAliveSpec vecNodes m alive_m w op) ∧
    ActiveCoordsStored d L B P'.activeHandles qMap' w ∧
    (∀ (j : ℕ) (hj : j < m) (hjk : m ≤ k),
      PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap'
        (S_new ⟨j, Nat.lt_succ_of_lt (lt_of_lt_of_le hj hjk)⟩)
        (updatedNodes.get ⟨j, by simp [updatedNodes, k, lt_of_lt_of_le hj hjk]⟩) j w) ∧
    (∀ (j : ℕ), m ≤ j → (hj : j < k) →
      LevelStoredInv n L B B_cert K_max P ltCoords qMap
        (chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩)
        (nodes.get ⟨j, hj⟩) j w) ∧
    (∀ loc : RAMCellLoc,
      loc ≠ .heap 9 104 → loc ≠ .heap 9 105 → loc ≠ .heap 9 106 →
      (∀ j < m, loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j 0) ∧
        loc ≠ .heap 4 (((j * 2 ^ L + hOp : ℕ) : ℤ)) ∧
        loc ∉ treeSliceLocs L (2 * j + 2) ∧
        loc ∉ treeSliceLocs L (2 * j + 3)) →
      (loc ∈ w.live ↔ loc ∈ wsA.live) ∧ w.vals loc = wsA.vals loc)
  have hLoop : ∀ m ≤ k, ∃ (wsSeq : ℕ → WordStore) (regSeq : ℕ → ℕ → ℤ),
      wsSeq 0 = ws3 ∧ regSeq 0 = g9 ∧
      LoopInv m (wsSeq m) (regSeq m) ∧
      (∀ j < m, RegExec inp fd W C_cell C_bit (posDimStepBLevel d s₀_d L)
        (wsSeq j) (regSeq j) (wsSeq (j + 1)) (regSeq (j + 1))
        (900 * L + 300 * d + 800) ((160 * L + 80 * d + 200) * W * W)) := by
    intro m hm
    induction m with
    | zero =>
        refine ⟨fun _ => ws3, fun _ => g9, rfl, rfl, ?_, fun i hi => absurd hi (Nat.not_lt_zero _)⟩
        refine ⟨hm_w3, bg9,
          by simp only [ws3, ws2, ws1]; rw [wordStore_read_write_ne _ (by decide), wordStore_read_write_ne _ (by decide), wordStore_read_write_ne _ (by decide)]; exact hr102A,
          by simp only [ws3, ws2, ws1]; rw [wordStore_read_write_ne _ (by decide), wordStore_read_write_ne _ (by decide), wordStore_read_write_ne _ (by decide)]; exact hr103A,
          by simp [ws3, ws2, ws1, WordStore.read, WordStore.write],
          by simp [ws3, jStarStep, WordStore.read, WordStore.write],
          ⟨true, by
            cases op with
            | insert _ _ _ =>
                refine ⟨⟨fun _ i hi => absurd hi (Nat.not_lt_zero _), fun _ => rfl⟩, ?_⟩
                simp [ws3, ws2, WordStore.read, WordStore.write]
            | delete _ => trivial⟩,
          hcoordsA.unchanged (fun _ _ _ _ _ _ => by simp [ws3, ws2, ws1, WordStore.read, WordStore.write]),
          fun j hj => absurd hj (Nat.not_lt_zero _),
          fun j _ hj => (hlevelsA j hj).unchanged hmA.wf hm_w3.wf
            (fun _ _ => by simp [ws3, ws2, ws1, WordStore.write])
            (fun _ _ => by simp [ws3, ws2, ws1, WordStore.write])
            (fun _ _ _ _ => by simp [ws3, ws2, ws1, WordStore.write])
            (fun _ _ _ _ => by simp [ws3, ws2, ws1, WordStore.write]),
          fun loc h104 h105 h106 _ =>
            ⟨by simp [ws3, ws2, ws1, WordStore.write, h106, h105, h104],
             by simp [ws3, ws2, ws1, WordStore.write,
                  Function.update_of_ne h106, Function.update_of_ne h105, Function.update_of_ne h104]⟩⟩
    | succ j ih =>
        have hjk : j < k := Nat.lt_of_succ_le hm
        obtain ⟨wS, rS, hw0, hr0_eq,
          ⟨hm_j, bg_j, hr102_j, hr103_j, hr104_j, hr106_j, ⟨alive_j, halive_j⟩, hcoords_j, hpre_j, hlvl_j, hunch_j⟩,
          hsteps⟩ := ih (Nat.le_of_succ_le hm)
        have hjS_le : jStarStep k slotTriggers j ≤ K_max + 1 :=
          (jStarStep_spec k slotTriggers j (by clear * - hjk; omega)).1.trans (by clear * - hk_le; omega)
        have hu_not_j : u ∉ (nodes.get ⟨j, hjk⟩).ageUpdateSteps :=
          fun h_in => Nat.lt_irrefl u (hu_age ⟨j, hjk⟩ u h_in)
        obtain ⟨wNext, gNext, alive_next, hstep_j, hmN, bgN, hpreN, hr104_N, hr106_N, halive_N, hunch_N⟩ :=
          exec_posDimStepBLevel hd1 hs₀1 hn h2n_pow hB1 hBc1 hW hfd_le hinv.wfP hwfP' hhOp_lt
            hop_spec hk_le hjk hu_not_j hm_j hcCeil0 hbCeil0 hcoords_j
            (hlvl_j j le_rfl hjk) rfl hr102_j hr103_j hr104_j hjS_le hr106_j alive_j halive_j bg_j
        refine ⟨fun i => if i ≤ j then wS i else wNext,
                fun i => if i ≤ j then rS i else gNext,
                by simp [hw0], by simp [hr0_eq], ?_, ?_⟩
        · simp only [show ¬ (j + 1 ≤ j) by clear * -; omega, ↓reduceIte]
          have hr102_N : wNext.read (.heap 9 102) = opIsIns op := by
            rw [wordStore_read_eq_vals hmN.wf,
                (hunch_N _ (by decide) (by decide) (by decide) (by intro h; cases h) (by intro h; cases h)
                  (not_in_treeSlice_of_table_ne (by decide) _) (not_in_treeSlice_of_table_ne (by decide) _)).2,
                ← wordStore_read_eq_vals hm_j.wf]
            exact hr102_j
          have hr103_N : wNext.read (.heap 9 103) = (hOp : ℤ) := by
            rw [wordStore_read_eq_vals hmN.wf,
                (hunch_N _ (by decide) (by decide) (by decide) (by intro h; cases h) (by intro h; cases h)
                  (not_in_treeSlice_of_table_ne (by decide) _) (not_in_treeSlice_of_table_ne (by decide) _)).2,
                ← wordStore_read_eq_vals hm_j.wf]
            exact hr103_j
          have htrig_eq : ((1 / (4 * (s₀_d : ℝ))) * ((nodes.get ⟨j, hjk⟩).birthPool.card : ℝ) / 16 <
              ((open Classical in
                if S_new ⟨j, Nat.lt_succ_of_lt hjk⟩ ≠ S_old ⟨j, Nat.lt_succ_of_lt hjk⟩ then
                  insert u (nodes.get ⟨j, hjk⟩).ageUpdateSteps
                else (nodes.get ⟨j, hjk⟩).ageUpdateSteps).card : ℝ)) ↔ slotTriggers j := by
            dsimp only [slotTriggers]; rw [dif_pos hjk]
          have hr106_N' : wNext.read (.heap 9 106) = (jStarStep k slotTriggers (j + 1) : ℤ) := by
            rw [hr106_N]; dsimp only [jStarStep]
            congr 1
            by_cases h1 : slotTriggers j ∧ j < jStarStep k slotTriggers j
            · rw [if_pos ⟨htrig_eq.mpr h1.1, h1.2⟩, if_pos h1]
            · rw [if_neg (fun h => h1 ⟨htrig_eq.mp h.1, h.2⟩), if_neg h1]
          have halive_N' : OpAliveSpec vecNodes (j + 1) alive_next wNext op := halive_N
          have hcoords_N : ActiveCoordsStored d L B P'.activeHandles qMap' wNext :=
            hcoords_j.unchanged (fun _ _ _ _ _ _ => by
              rw [wordStore_read_eq_vals hmN.wf,
                  (hunch_N _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
                    (by intro h; cases h) (by intro h; cases h)
                    (not_in_treeSlice_of_table_ne (by decide) _) (not_in_treeSlice_of_table_ne (by decide) _)).2,
                  ← wordStore_read_eq_vals hm_j.wf])
          have hlevel_frame : ∀ (j' : ℕ), j' ≠ j →
              (∀ off < posNodeStride d L,
                ((.heap 3 (nodeCellAddr (posNodeStride d L) j' off) : RAMCellLoc) ∈ wNext.live ↔
                  (.heap 3 (nodeCellAddr (posNodeStride d L) j' off) : RAMCellLoc) ∈ (wS j).live) ∧
                wNext.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j' off)) =
                  (wS j).vals (.heap 3 (nodeCellAddr (posNodeStride d L) j' off))) ∧
              (∀ h' < 2 ^ L,
                ((.heap 4 (((j' * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ wNext.live ↔
                  (.heap 4 (((j' * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ (wS j).live) ∧
                wNext.vals (.heap 4 (((j' * 2 ^ L + h' : ℕ) : ℤ))) =
                  (wS j).vals (.heap 4 (((j' * 2 ^ L + h' : ℕ) : ℤ)))) ∧
              (∀ u₀ < 2 ^ (L + 1), ∀ f < 4,
                ((.heap 2 (treeCellAddr L (2 * j' + 2) u₀ f) : RAMCellLoc) ∈ wNext.live ↔
                  (.heap 2 (treeCellAddr L (2 * j' + 2) u₀ f) : RAMCellLoc) ∈ (wS j).live) ∧
                wNext.vals (.heap 2 (treeCellAddr L (2 * j' + 2) u₀ f)) =
                  (wS j).vals (.heap 2 (treeCellAddr L (2 * j' + 2) u₀ f))) ∧
              (∀ u₀ < 2 ^ (L + 1), ∀ f < 4,
                ((.heap 2 (treeCellAddr L (2 * j' + 3) u₀ f) : RAMCellLoc) ∈ wNext.live ↔
                  (.heap 2 (treeCellAddr L (2 * j' + 3) u₀ f) : RAMCellLoc) ∈ (wS j).live) ∧
                wNext.vals (.heap 2 (treeCellAddr L (2 * j' + 3) u₀ f)) =
                  (wS j).vals (.heap 2 (treeCellAddr L (2 * j' + 3) u₀ f))) := by
            intro j' hj_ne
            have hns_pos : 0 < posNodeStride d L := by unfold posNodeStride; exact lt_of_lt_of_le (by decide : 0 < 8) (le_trans (Nat.le_add_right 8 (2 * d)) (Nat.le_add_right _ (2 ^ L)))
            refine ⟨fun off hoff => hunch_N _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
              (fun hc => by injection hc with _ ha; exact hj_ne (nodeCellAddr_inj hoff hns_pos ha).1)
              (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _) (not_in_treeSlice_of_table_ne (by decide) _),
              fun h' hh' => hunch_N _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
              (by intro h; cases h)
              (fun hc => by
                injection hc with _ ha
                have hnat : j' * 2 ^ L + h' = j * 2 ^ L + hOp := by exact_mod_cast ha
                rcases lt_trichotomy j' j with hlt | rfl | hgt
                · have h1 : (j' + 1) * 2 ^ L ≤ j * 2 ^ L := Nat.mul_le_mul_right _ (Nat.succ_le_of_lt hlt)
                  have h2 : j' * 2 ^ L + h' < (j' + 1) * 2 ^ L := by rw [add_mul, one_mul]; exact Nat.add_lt_add_left hh' _
                  clear * - hnat h1 h2; omega
                · exact hj_ne rfl
                · have h1 : (j + 1) * 2 ^ L ≤ j' * 2 ^ L := Nat.mul_le_mul_right _ (Nat.succ_le_of_lt hgt)
                  have h2 : j * 2 ^ L + hOp < (j + 1) * 2 ^ L := by rw [add_mul, one_mul]; exact Nat.add_lt_add_left hhOp_lt _
                  clear * - hnat h1 h2; omega)
              (not_in_treeSlice_of_table_ne (by decide) _) (not_in_treeSlice_of_table_ne (by decide) _),
              fun u₀ hu₀ f hf => hunch_N _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
                (by intro h; cases h) (by intro h; cases h)
                (not_in_treeSlice_of_tid_ne hu₀ hf (by clear * - hj_ne; omega)) (not_in_treeSlice_of_tid_ne hu₀ hf (by clear * - hj_ne; omega)),
              fun u₀ hu₀ f hf => hunch_N _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
                (by intro h; cases h) (by intro h; cases h)
                (not_in_treeSlice_of_tid_ne hu₀ hf (by clear * - hj_ne; omega)) (not_in_treeSlice_of_tid_ne hu₀ hf (by clear * - hj_ne; omega))⟩
          refine ⟨hmN, bgN, hr102_N, hr103_N, hr104_N, hr106_N', ⟨alive_next, halive_N'⟩, hcoords_N,
            fun j' hj' hjk1 => ?_, fun j' hj'_lo hj'_hi => ?_, fun loc h104 h105 h106 hrest => ?_⟩
          · rcases Nat.lt_succ_iff_lt_or_eq.mp hj' with hlt | rfl
            · obtain ⟨f3, f4, ft2, ft3⟩ := hlevel_frame j' (Nat.ne_of_lt hlt)
              exact (hpre_j j' hlt (Nat.le_of_succ_le hjk1)).unchanged hm_j.wf hmN.wf f3 f4 ft2 ft3
            · simpa [updatedNodes, k] using hpreN
          · obtain ⟨f3, f4, ft2, ft3⟩ := hlevel_frame j' (by clear * - hj'_lo; omega)
            exact (hlvl_j j' (by clear * - hj'_lo; omega) hj'_hi).unchanged hm_j.wf hmN.wf f3 f4 ft2 ft3
          · obtain ⟨nj30, nj4, njt2, njt3⟩ := hrest j (Nat.lt_succ_self j)
            have uN := hunch_N loc h104 h105 h106 nj30 nj4 njt2 njt3
            have uJ := hunch_j loc h104 h105 h106 (fun i hi => hrest i (Nat.lt_succ_of_lt hi))
            exact ⟨uN.1.trans uJ.1, uN.2.trans uJ.2⟩
        · intro i hi
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
          · simp only [Nat.le_of_lt hlt, Nat.succ_le_of_lt hlt, ↓reduceIte]; exact hsteps i hlt
          · simp only [le_rfl, show ¬ (i + 1 ≤ i) by clear * -; omega, ↓reduceIte]; exact hstep_j
  obtain ⟨wsSeq, regSeq, hw0, hrg0,
    ⟨hmK, bgK, hr102_K, hr103_K, hr104_K, hr106_K, ⟨alive_k, halive_k⟩, hcoordsK, hpreK, _, hunchK⟩,
    hstepsK⟩ := hLoop k le_rfl
  have s13 := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    (cntReg := 5) (by decide) k wsSeq regSeq (by rw [hrg0]; simp [g9, g8, g7, g6, g5, g4, g3, g2])
    (by rw [hrg0]; exact bg9) hstepsK
  rw [hw0, hrg0] at s13
  -- Terminal leaf `tid = 1` update
  have hisIns_bl : intBitLength (opIsIns op) ≤ W := by
    cases op <;> dsimp [opIsIns] <;> assumption
  have s14 := RegExec.lit (inp := inp) hfd_le bgK (sp_ok hmK).1 (sp_ok hmK).2 (dst := 10) (c := 102) (by decide) hl102
  set q1 := Function.update (regSeq k) 10 102; have bq1 := bgK.update (r := 10) (by decide) hl102
  have hq1_r : (wsSeq k).read (.heap 9 (q1 10)) = opIsIns op := by
    simp only [q1, Function.update_self]; exact hr102_K
  have s15 := RegExec.load (inp := inp) hfd_le bq1 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 5) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hq1_r]; exact hisIns_bl)
  rw [hq1_r] at s15; set q2 := Function.update q1 5 (opIsIns op)
  have bq2 := bq1.update (r := 5) (by decide) hisIns_bl
  have s16 := RegExec.lit (inp := inp) hfd_le bq2 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 10) (c := 103) (by decide) hl103
  set q3 := Function.update q2 10 103; have bq3 := bq2.update (r := 10) (by decide) hl103
  have hq3_r : (wsSeq k).read (.heap 9 (q3 10)) = (hOp : ℤ) := by simp only [q3, Function.update_self]; exact hr103_K
  have s17 := RegExec.load (inp := inp) hfd_le bq3 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 6) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hq3_r]; exact hhOp_bl)
  rw [hq3_r] at s17; set q4 := Function.update q3 6 (hOp : ℤ); have bq4 := bq3.update (r := 6) (by decide) hhOp_bl
  have s18 := RegExec.lit (inp := inp) hfd_le bq4 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 14) (c := 1) (by decide) hl1
  set q5 := Function.update q4 14 1; have bq5 := bq4.update (r := 14) (by decide) hl1
  have hleafK : TreeStoredAt L 1
      ((chainInput ltCoords vecNodes (activeLifetimes P) (Fin.last k)).image (handleOfLifetime P))
      (fun _ => 0) (fun _ => 1) (wsSeq k) :=
    hleafA.unchanged (fun u₀ hu₀ f hf => hunchK _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
      (fun j _ => ⟨(by intro h; cases h), (by intro h; cases h),
                   not_in_treeSlice_of_tid_ne hu₀ hf (by clear * -; omega),
                   not_in_treeSlice_of_tid_ne hu₀ hf (by clear * -; omega)⟩))
  have hW_tree1 : 2 * 2 + natBitLength 1 + L + 16 ≤ W := by
    have : natBitLength 1 = 1 := by decide
    clear * - this hW; omega
  have hLeafUpd : ∃ wsL gL,
      RegExec inp fd W C_cell C_bit
        (.ite (.intEq (.readLocal 5 (.lit 0)) (.readLocal 14 (.lit 0))) (posDimStepBLeafIns L) (posDimStepBLeafDel L))
        (wsSeq k) q5 wsL gL (400 * L + 260) ((64 * L + 64) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsL ∧
      RegBounded W gL ∧
      TreeStoredAt L 1 ((S_new (Fin.last k)).image (handleOfLifetime P')) (fun _ => 0) (fun _ => 1) wsL ∧
      (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L 1 →
        (loc ∈ wsL.live ↔ loc ∈ (wsSeq k).live) ∧ wsL.vals loc = (wsSeq k).vals loc) := by
    cases op with
    | insert id extName pt =>
        rcases hop_spec with ⟨happ, hhNew_not, _, _, _⟩
        obtain ⟨hnot_lt, hact', _, hh_new, hh_old⟩ := activeLifetimes_insert_spec hinv.wfP hwfP' happ
        have hq5_eq : q5 5 = q5 14 := by simp [q5, q4, q3, q2, opIsIns]
        have halive_bl : intBitLength (if alive_k then (1 : ℤ) else 0) ≤ W := by split_ifs <;> assumption
        have p1 := RegExec.lit (inp := inp) hfd_le bq5 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 10) (c := 105) (by decide) hl105
        set r1 := Function.update q5 10 105; have br1 := bq5.update (r := 10) (by decide) hl105
        have hr1_r : (wsSeq k).read (.heap 9 (r1 10)) = if alive_k then 1 else 0 := by
          simp only [r1, Function.update_self]; exact halive_k.2
        have p2 := RegExec.load (inp := inp) hfd_le br1 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 8) (table := 9) (addr := 10)
          (by decide) (by decide) hn9 (by rw [hr1_r]; exact halive_bl)
        rw [hr1_r] at p2; set r2 := Function.update r1 8 (if alive_k then 1 else 0); have br2 := br1.update (r := 8) (by decide) halive_bl
        have p3 := RegExec.lit (inp := inp) hfd_le br2 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 14) (c := 1) (by decide) hl1
        set r3 := Function.update r2 14 1; have br3 := br2.update (r := 14) (by decide) hl1
        have hS_old_k : S_old (Fin.last k) = chainInput ltCoords vecNodes (activeLifetimes P) (Fin.last k) := by
          apply chainInput_congr_pts
          intro lt hlt; simp only [activeLifetimes, Finset.mem_image] at hlt
          rcases hlt with ⟨id₀, hid₀, rfl⟩
          dsimp [ltCoords', opNextLtCoords]; exact Function.update_of_ne (Nat.ne_of_lt (hinv.wfP.2.2.2.1 id₀ hid₀)) pt ltCoords
        have hS_new_k : S_new (Fin.last k) = open Classical in
            if ∀ (i : ℕ) (hi : i < k), pt ∉ coreBall (vecNodes ⟨i, hi⟩).o (vecNodes ⟨i, hi⟩).V then
              insert P.nextLifetime (S_old (Fin.last k))
            else S_old (Fin.last k) := by
          dsimp only [S_new, S_old]
          rw [hact', chainInput_insert_eq ltCoords' vecNodes (activeLifetimes P) hnot_lt]
          have hlt_new_pt : ltCoords' P.nextLifetime = pt := by dsimp [ltCoords', opNextLtCoords]; exact Function.update_self P.nextLifetime pt ltCoords
          letI := Classical.propDecidable
          by_cases hc : ∀ (i : ℕ) (hi : i < k), pt ∉ coreBall (vecNodes ⟨i, hi⟩).o (vecNodes ⟨i, hi⟩).V
          · rw [if_pos (fun i hi => by rw [hlt_new_pt]; exact hc i hi), if_pos hc]
          · rw [if_neg (fun h => hc (fun i hi => by rw [← hlt_new_pt]; exact h i hi)), if_neg hc]
        cases halive_eq : alive_k with
        | false =>
            have hn_all : ¬ ∀ (i : ℕ) (hi : i < k), pt ∉ coreBall (vecNodes ⟨i, hi⟩).o (vecNodes ⟨i, hi⟩).V := by
              intro hall; have := halive_k.1.mpr (fun i hi _ => hall i hi); rw [halive_eq] at this; cases this
            have himg_eq : (S_new (Fin.last k)).image (handleOfLifetime P') =
                ((chainInput ltCoords vecNodes (activeLifetimes P) (Fin.last k)).image (handleOfLifetime P)) := by
              rw [hS_new_k, if_neg hn_all, hS_old_k]
              apply Finset.image_congr; intro lt hlt; exact hh_old lt (chainInput_subset_base _ _ _ _ hlt)
            have hr3_ne : r3 8 ≠ r3 14 := by simp [r3, r2, halive_eq]
            have pSk := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsSeq k) br3).weaken
              rfl rfl (u₂ := 375 * L + 210) (b₂ := (58 * L + 40) * W * W)
              (by clear * - hL1; omega) (by have hWpos : 0 < W := (by clear * - hW40; omega); exact Nat.succ_le_of_lt (by positivity))
            have pIte := RegExec.iteEq (tB := posDimStepBLeafInsAlive L) (fB := .skip) br3 (a := 8) (b := 14) (by decide) (by decide)
              (by rw [if_neg hr3_ne]; exact pSk)
            have pIns := (p1.seq (p2.seq (p3.seq pIte))).weaken rfl rfl
              (u₂ := 390 * L + 240) (b₂ := (62 * L + 56) * W * W)
              (by clear * - hL1; omega) (by have h1 : 0 ≤ L * W * W := (by positivity); nlinarith only [hW40, hL1, h1])
            have sOuter := (RegExec.iteEq (tB := posDimStepBLeafIns L) (fB := posDimStepBLeafDel L)
              bq5 (a := 5) (b := 14) (by decide) (by decide) (by rw [if_pos hq5_eq]; exact pIns)).weaken
              rfl rfl (u₂ := 400 * L + 260) (b₂ := (64 * L + 64) * W * W)
              (by clear * - hL1; omega) (by have h1 : 0 ≤ L * W * W := (by positivity); nlinarith only [hW40, hL1, h1])
            exact ⟨wsSeq k, r3, sOuter, hmK, br3, by rwa [himg_eq], fun _ _ => ⟨Iff.rfl, rfl⟩⟩
        | true =>
            have hall_k : ∀ (i : ℕ) (hi : i < k), pt ∉ coreBall (vecNodes ⟨i, hi⟩).o (vecNodes ⟨i, hi⟩).V :=
              fun i hi => halive_k.1.mp halive_eq i hi le_rfl
            have himg_eq : (S_new (Fin.last k)).image (handleOfLifetime P') =
                insert hOp ((chainInput ltCoords vecNodes (activeLifetimes P) (Fin.last k)).image (handleOfLifetime P)) := by
              rw [hS_new_k, if_pos hall_k, Finset.image_insert, hh_new, hS_old_k]
              congr 1; apply Finset.image_congr; intro lt hlt; exact hh_old lt (chainInput_subset_base _ _ _ _ hlt)
            have hr3_eq : r3 8 = r3 14 := by simp [r3, r2, halive_eq]
            have a1 := RegExec.lit (inp := inp) hfd_le br3 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 0) (c := 1) (by decide) hl1
            set t1 := Function.update r3 0 1; have bt1 := br3.update (r := 0) (by decide) hl1
            have a2 := RegExec.copy (inp := inp) hfd_le bt1 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 1) (src := 6) (by decide) (by decide)
            set t2 := Function.update t1 1 (t1 6); have bt2 := bt1.update (r := 1) (v := t1 6) (by decide) (by simpa [t1, r3, r2, r1, q5, q4] using hhOp_bl)
            have a3 := RegExec.lit (inp := inp) hfd_le bt2 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 2) (c := 1) (by decide) hl1
            set t3 := Function.update t2 2 1; have bt3 := bt2.update (r := 2) (by decide) hl1
            have a4 := RegExec.lit (inp := inp) hfd_le bt3 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 3) (c := 0) (by decide) hl0
            set t4 := Function.update t3 3 0; have bt4 := bt3.update (r := 3) (by decide) hl0
            have a5 := RegExec.lit (inp := inp) hfd_le bt4 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 4) (c := 1) (by decide) hl1
            set t5 := Function.update t4 4 1; have bt5 := bt4.update (r := 4) (by decide) hl1
            have hLeaf'_bnds : ∀ h ∈ (S_new (Fin.last k)).image (handleOfLifetime P'),
                h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 := by
              intro h hh; rw [himg_eq] at hh
              rcases Finset.mem_insert.mp hh with rfl | hold
              · exact ⟨hhOp_lt, by dsimp only; decide, by dsimp only; decide⟩
              · exact ⟨hleafK.hS h hold, by dsimp only; decide, by dsimp only; decide⟩
            obtain ⟨wsL, gL, a6, hmL, bgL, htreeL, hunchL⟩ :=
              exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hmK hcCeil0 hbCeil0 hL1 hhOp_lt (B_r := 2) (by decide)
                hW_tree1 (treePathLocs_sub_posDimWriteLocs (by clear * -; omega) hhOp_lt)
                hleafK hLeaf'_bnds
                (fun h hne => by rw [himg_eq, Finset.mem_insert]; simp [hne])
                (fun _ _ => rfl) (fun _ _ => rfl) true (by rw [himg_eq]; simp) bt5
                (by simp [t5, t4, t3, t2, t1])
                (by simp [t5, t4, t3, t2, t1, r3, r2, r1, q5, q4])
                (by simp [t5, t4, t3])
                (fun _ => by simp [t5, t4]) (fun _ => by simp [t5])
            have aAll := (a1.seq (a2.seq (a3.seq (a4.seq (a5.seq a6))))).weaken rfl rfl
              (u₂ := 375 * L + 210) (b₂ := (58 * L + 40) * W * W)
              (by clear * - hL1; omega) (by have h1 : 0 ≤ L * W * W := (by positivity); nlinarith only [hW40, hL1, h1])
            have pIte := RegExec.iteEq (tB := posDimStepBLeafInsAlive L) (fB := .skip) br3 (a := 8) (b := 14) (by decide) (by decide)
              (by rw [if_pos hr3_eq]; exact aAll)
            have pIns := (p1.seq (p2.seq (p3.seq pIte))).weaken rfl rfl
              (u₂ := 390 * L + 240) (b₂ := (62 * L + 56) * W * W)
              (by clear * - hL1; omega) (by have h1 : 0 ≤ L * W * W := (by positivity); nlinarith only [hW40, hL1, h1])
            have sOuter := (RegExec.iteEq (tB := posDimStepBLeafIns L) (fB := posDimStepBLeafDel L)
              bq5 (a := 5) (b := 14) (by decide) (by decide) (by rw [if_pos hq5_eq]; exact pIns)).weaken
              rfl rfl (u₂ := 400 * L + 260) (b₂ := (64 * L + 64) * W * W)
              (by clear * - hL1; omega) (by have h1 : 0 ≤ L * W * W := (by positivity); nlinarith only [hW40, hL1, h1])
            exact ⟨wsL, gL, sOuter, hmL, bgL, htreeL,
              fun loc hns => hunchL loc (fun hp => hns (treePath_sub_slice hL1 hhOp_lt hp))⟩
    | delete id =>
        rcases hop_spec with ⟨happ, rfl, rfl⟩
        obtain ⟨hdel_mem, hact', _, hh_del, hh_old⟩ := activeLifetimes_delete_spec hinv.wfP hwfP' happ
        have himg_eq : (S_new (Fin.last k)).image (handleOfLifetime P') =
            ((chainInput ltCoords vecNodes (activeLifetimes P) (Fin.last k)).image (handleOfLifetime P)).erase (P.handleOfId id) := by
          dsimp only [S_new, ltCoords', opNextLtCoords]
          rw [hact', chainInput_erase_eq]
          ext h; simp only [Finset.mem_image, Finset.mem_erase]
          constructor
          · rintro ⟨lt, ⟨hlt_ne, hlt_in⟩, rfl⟩
            have hlt_act' : lt ∈ activeLifetimes P' := by
              rw [hact']; exact Finset.mem_erase.mpr ⟨hlt_ne, chainInput_subset_base _ _ _ _ hlt_in⟩
            rw [hh_old lt hlt_act']
            refine ⟨?_, lt, hlt_in, rfl⟩
            intro heq
            exact hlt_ne (handleOfLifetime_injOn hinv.wfP (chainInput_subset_base _ _ _ _ hlt_in) hdel_mem (heq.trans hh_del.symm))
          · rintro ⟨hh_ne, lt, hlt_in, rfl⟩
            have hlt_ne : lt ≠ P.lifetimeOfId id := fun heq => hh_ne (heq ▸ hh_del)
            have hlt_act' : lt ∈ activeLifetimes P' := by
              rw [hact']; exact Finset.mem_erase.mpr ⟨hlt_ne, chainInput_subset_base _ _ _ _ hlt_in⟩
            exact ⟨lt, ⟨hlt_ne, hlt_in⟩, hh_old lt hlt_act'⟩
        have hq5_ne : q5 5 ≠ q5 14 := by simp [q5, q4, q3, q2, opIsIns]
        have a1 := RegExec.lit (inp := inp) hfd_le bq5 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 0) (c := 1) (by decide) hl1
        set t1 := Function.update q5 0 1; have bt1 := bq5.update (r := 0) (by decide) hl1
        have a2 := RegExec.copy (inp := inp) hfd_le bt1 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 1) (src := 6) (by decide) (by decide)
        set t2 := Function.update t1 1 (t1 6); have bt2 := bt1.update (r := 1) (v := t1 6) (by decide) (by simpa [t1, q5, q4] using hhOp_bl)
        have a3 := RegExec.lit (inp := inp) hfd_le bt2 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 2) (c := 0) (by decide) hl0
        set t3 := Function.update t2 2 0; have bt3 := bt2.update (r := 2) (by decide) hl0
        have a4 := RegExec.lit (inp := inp) hfd_le bt3 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 3) (c := 0) (by decide) hl0
        set t4 := Function.update t3 3 0; have bt4 := bt3.update (r := 3) (by decide) hl0
        have a5 := RegExec.lit (inp := inp) hfd_le bt4 (sp_ok hmK).1 (sp_ok hmK).2 (dst := 4) (c := 0) (by decide) hl0
        set t5 := Function.update t4 4 0; have bt5 := bt4.update (r := 4) (by decide) hl0
        have hLeaf'_bnds : ∀ h ∈ (S_new (Fin.last k)).image (handleOfLifetime P'),
            h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 := by
          intro h hh; rw [himg_eq] at hh
          exact ⟨hleafK.hS h (Finset.mem_of_mem_erase hh), by dsimp only; decide, by dsimp only; decide⟩
        obtain ⟨wsL, gL, a6, hmL, bgL, htreeL, hunchL⟩ :=
          exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hmK hcCeil0 hbCeil0 hL1 hhOp_lt (B_r := 2) (by decide)
            hW_tree1 (treePathLocs_sub_posDimWriteLocs (by clear * -; omega) hhOp_lt)
            hleafK hLeaf'_bnds
            (fun h hne => by rw [himg_eq, Finset.mem_erase]; simp [hne])
            (fun _ _ => rfl) (fun _ _ => rfl) false (by rw [himg_eq]; simp) bt5
            (by simp [t5, t4, t3, t2, t1])
            (by simp [t5, t4, t3, t2, t1, q5, q4])
            (by simp [t5, t4, t3])
            (by intro h; cases h) (by intro h; cases h)
        have pDel := (a1.seq (a2.seq (a3.seq (a4.seq (a5.seq a6))))).weaken rfl rfl
          (u₂ := 390 * L + 240) (b₂ := (62 * L + 56) * W * W)
          (by clear * - hL1; omega) (by have h1 : 0 ≤ L * W * W := (by positivity); nlinarith only [hW40, hL1, h1])
        have sOuter := (RegExec.iteEq (tB := posDimStepBLeafIns L) (fB := posDimStepBLeafDel L)
          bq5 (a := 5) (b := 14) (by decide) (by decide) (by rw [if_neg hq5_ne]; exact pDel)).weaken
          rfl rfl (u₂ := 400 * L + 260) (b₂ := (64 * L + 64) * W * W)
          (by clear * - hL1; omega) (by have h1 : 0 ≤ L * W * W := (by positivity); nlinarith only [hW40, hL1, h1])
        exact ⟨wsL, gL, sOuter, hmL, bgL, htreeL,
          fun loc hns => hunchL loc (fun hp => hns (treePath_sub_slice hL1 hhOp_lt hp))⟩
  obtain ⟨wsL, gL, s19, hmL, bgL, htreeL, hunchL⟩ := hLeafUpd
  -- Leaf trigger check: rLit 0 1; treeReadRootRegs L; rLit 12 (2*(2*s0-1)); .ite ...
  have s20 := RegExec.lit (inp := inp) hfd_le bgL (sp_ok hmL).1 (sp_ok hmL).2 (dst := 0) (c := 1) (by decide) hl1
  set f1 := Function.update gL 0 1; have bf1 := bgL.update (r := 0) (by decide) hl1
  have hLeaf_bnds : ∀ h ∈ (S_new (Fin.last k)).image (handleOfLifetime P'),
      h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 :=
    fun h hh => ⟨htreeL.hS h hh, by dsimp only; decide, by dsimp only; decide⟩
  obtain ⟨f2, s21, bf2, _, f2_1, _⟩ :=
    exec_treeReadRootRegs (inp := inp) (fd := fd) hfd_le (sp_ok hmL).1 (sp_ok hmL).2 (B_r := 2) (by decide)
      (by have : natBitLength 1 = 1 := (by decide); clear * - this hW; omega)
      htreeL hLeaf_bnds bf1 (by simp [f1])
  have hcard_img_eq : ((S_new (Fin.last k)).image (handleOfLifetime P')).card = (S_new (Fin.last k)).card :=
    Finset.card_image_of_injOn ((handleOfLifetime_injOn hwfP').mono
      (Finset.coe_subset.mpr (chainInput_subset_base _ _ _ _)))
  rw [hcard_img_eq] at f2_1
  have hthresh_bl : intBitLength (((2 * (2 * s₀_d - 1) : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (2 * (2 * s₀_d - 1))
    have h2 := natBitLength_mono (show 2 * (2 * s₀_d - 1) ≤ 64 * s₀_d + 1 by clear * -; omega)
    clear * - h1 h2 hW; omega
  have s22 := RegExec.lit (inp := inp) hfd_le bf2 (sp_ok hmL).1 (sp_ok hmL).2
    (dst := 12) (c := ((2 * (2 * s₀_d - 1) : ℕ) : ℤ)) (by decide) hthresh_bl
  set f3 := Function.update f2 12 ((2 * (2 * s₀_d - 1) : ℕ) : ℤ)
  have bf3 := bf2.update (r := 12) (by decide) hthresh_bl
  have hrL_k : wsL.read (.heap 0 10) = (k : ℤ) := by
    rw [wordStore_read_eq_vals hmL.wf,
        (hunchL _ (not_in_treeSlice_of_table_ne (by decide) _)).2,
        (hunchK _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
          (fun _ _ => ⟨(by intro h; cases h), (by intro h; cases h),
                       not_in_treeSlice_of_table_ne (by decide) _,
                       not_in_treeSlice_of_table_ne (by decide) _⟩)).2,
        ← wordStore_read_eq_vals hmA.wf]
    exact hrA_k
  have hrL_106 : wsL.read (.heap 9 106) = (jStarStep k slotTriggers k : ℤ) := by
    rw [wordStore_read_eq_vals hmL.wf,
        (hunchL _ (not_in_treeSlice_of_table_ne (by decide) _)).2,
        ← wordStore_read_eq_vals hmK.wf]
    exact hr106_K
  have hjSk_le : jStarStep k slotTriggers k ≤ K_max + 1 :=
    (jStarStep_spec k slotTriggers k (Nat.le_succ k)).1.trans (Nat.succ_le_succ hk_le)
  have hjSk_bl : intBitLength (jStarStep k slotTriggers k : ℤ) ≤ W :=
    j_bl_of_level (d := d) (L := L) (K_max := K_max) hjSk_le (by clear * - hW; omega)
  have hLeafTrig : ∃ wsB regsB,
      RegExec inp fd W C_cell C_bit
        (.ite (.intLt (.readLocal 12 (.lit 0)) (.readLocal 1 (.lit 0))) posDimStepBLeafTrigTrue .skip)
        wsL f3 wsB regsB 56 (36 * W + 180) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsB ∧
      RegBounded W regsB ∧
      wsB.read (.heap 9 106) = (jStar : ℤ) ∧
      (∀ loc : RAMCellLoc, loc ≠ .heap 9 106 →
        (loc ∈ wsB.live ↔ loc ∈ wsL.live) ∧ wsB.vals loc = wsL.vals loc) := by
    have hf3_12 : f3 12 = ((2 * (2 * s₀_d - 1) : ℕ) : ℤ) := by simp [f3]
    have hf3_1 : f3 1 = ((S_new (Fin.last k)).card : ℤ) := by simp [f3, f2_1]
    have htrig_k_iff : slotTriggers k ↔ 2 * (2 * s₀_d - 1) < (S_new (Fin.last k)).card := by
      dsimp only [slotTriggers]; rw [dif_neg (Nat.lt_irrefl k)]; simp
    by_cases hlt_leaf : 2 * (2 * s₀_d - 1) < (S_new (Fin.last k)).card
    · have hlt_z : f3 12 < f3 1 := by rw [hf3_12, hf3_1]; exact_mod_cast hlt_leaf
      have d1 := RegExec.lit (inp := inp) hfd_le bf3 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 10) (c := 10) (by decide) hl10
      set e1 := Function.update f3 10 10; have be1 := bf3.update (r := 10) (by decide) hl10
      have he1_r : wsL.read (.heap 0 (e1 10)) = (k : ℤ) := by simp only [e1, Function.update_self]; exact hrL_k
      have d2 := RegExec.load (inp := inp) hfd_le be1 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 7) (table := 0) (addr := 10)
        (by decide) (by decide) hn0 (by rw [he1_r]; exact hk_bl)
      rw [he1_r] at d2; set e2 := Function.update e1 7 (k : ℤ); have be2 := be1.update (r := 7) (by decide) hk_bl
      obtain ⟨wsB, regsB, d3, hmB, bgB, _, hrB_106, hunchB⟩ :=
        exec_maybeUpdateJStarStmt (inp := inp) (fd := fd) hfd_le hmL hcCeil0 hbCeil0 (by clear * - hW40; omega)
          hk_bl hjSk_bl (mem_posDimWriteLocs_tab9 (by decide)) hrL_106 be2 (by simp [e2])
      have sBr := (d1.seq (d2.seq d3)).weaken rfl rfl (u₂ := 50) (b₂ := 32 * W + 160) (by decide) (by clear * -; omega)
      have sIte := RegExec.iteLt (tB := posDimStepBLeafTrigTrue) (fB := .skip) bf3 (a := 12) (b := 1) (by decide) (by decide)
        (by rw [if_pos hlt_z]; exact sBr)
      have hjStar_eq : (if k < jStarStep k slotTriggers k then k else jStarStep k slotTriggers k) = jStar := by
        dsimp only [jStar, jStarStep]; simp [htrig_k_iff.mpr hlt_leaf]
      rw [hjStar_eq] at hrB_106
      exact ⟨wsB, regsB, sIte.weaken rfl rfl (u₂ := 56) (b₂ := 36 * W + 180) (by decide) (by clear * -; omega), hmB, bgB, hrB_106, hunchB⟩
    · have hnlt_z : ¬ (f3 12 < f3 1) := by rw [hf3_12, hf3_1]; exact_mod_cast hlt_leaf
      have sSk := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsL) bf3).weaken
        rfl rfl (u₂ := 50) (b₂ := 32 * W + 160) (by decide) (by clear * -; omega)
      have sIte := RegExec.iteLt (tB := posDimStepBLeafTrigTrue) (fB := .skip) bf3 (a := 12) (b := 1) (by decide) (by decide)
        (by rw [if_neg hnlt_z]; exact sSk)
      have hjStar_eq : jStar = jStarStep k slotTriggers k := by
        dsimp only [jStar, jStarStep]; simp [show ¬ slotTriggers k from fun h => hlt_leaf (htrig_k_iff.mp h)]
      exact ⟨wsL, f3, sIte.weaken rfl rfl (u₂ := 56) (b₂ := 36 * W + 180) (by decide) (by clear * -; omega), hmL, bf3, by rw [hjStar_eq]; exact hrL_106, fun _ _ => ⟨Iff.rfl, rfl⟩⟩
  obtain ⟨wsB, regsB, s23, hmB, bgB, hrB_106, hunchB⟩ := hLeafTrig
  -- Combine full RegExec cost and verify all output invariants on wsB
  have hLWW : 0 ≤ L * W * W := by positivity
  have hdWW : 0 ≤ d * W * W := by positivity
  have hkLWW : 0 ≤ k * (L * W * W) := by positivity
  have hkdWW : 0 ≤ k * (d * W * W) := by positivity
  have hkWW : 0 ≤ k * (W * W) := by positivity
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq
    (s11.seq (s12.seq (s13.seq (s14.seq (s15.seq (s16.seq (s17.seq (s18.seq (s19.seq
    (s20.seq (s21.seq (s22.seq s23)))))))))))))))))))))).weaken
    rfl rfl
    (u₂ := (k + 1) * (950 * L + 300 * d + 900))
    (b₂ := (k + 1) * (180 * L + 80 * d + 240) * W * W)
    (by nlinarith only [hL1, hd1])
    (by
      have hk_split : k * ((160 * L + 80 * d + 200) * W * W) =
          160 * (k * (L * W * W)) + 80 * (k * (d * W * W)) + 200 * (k * (W * W)) := by ring
      have h_rhs : (k + 1) * (180 * L + 80 * d + 240) * W * W =
          180 * (k * (L * W * W)) + 80 * (k * (d * W * W)) + 240 * (k * (W * W)) +
          180 * (L * W * W) + 80 * (d * W * W) + 240 * (W * W) := by ring
      nlinarith only [hW40, hL1, hd1, hLWW, hdWW, hkLWW, hkdWW, hkWW, hk_split, h_rhs])
  have hunchB_K : ∀ loc : RAMCellLoc, loc ≠ .heap 9 106 → loc ∉ treeSliceLocs L 1 →
      (loc ∈ wsB.live ↔ loc ∈ (wsSeq k).live) ∧ wsB.vals loc = (wsSeq k).vals loc := by
    intro loc h106 hns1
    exact ⟨(hunchB loc h106).1.trans (hunchL loc hns1).1,
           (hunchB loc h106).2.trans (hunchL loc hns1).2⟩
  have hunchB_A : ∀ loc : RAMCellLoc,
      loc ≠ .heap 9 104 → loc ≠ .heap 9 105 → loc ≠ .heap 9 106 →
      loc ∉ treeSliceLocs L 1 →
      (∀ j < k, loc ≠ .heap 3 (nodeCellAddr (posNodeStride d L) j 0) ∧
        loc ≠ .heap 4 (((j * 2 ^ L + hOp : ℕ) : ℤ)) ∧
        loc ∉ treeSliceLocs L (2 * j + 2) ∧
        loc ∉ treeSliceLocs L (2 * j + 3)) →
      (loc ∈ wsB.live ↔ loc ∈ wsA.live) ∧ wsB.vals loc = wsA.vals loc := by
    intro loc h104 h105 h106 hns1 hrest
    have uBK := hunchB_K loc h106 hns1
    have uKA := hunchK loc h104 h105 h106 hrest
    exact ⟨uBK.1.trans uKA.1, uBK.2.trans uKA.2⟩
  refine ⟨wsB, regsB, sTot, hmB, bgB, ?_, ?_, hrB_106, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [wordStore_read_eq_vals hmB.wf, (hunchB _ (by decide)).2, ← wordStore_read_eq_vals hmL.wf]
    exact hrL_k
  · rw [wordStore_read_eq_vals hmB.wf,
        (hunchB_A _ (by decide) (by decide) (by decide) (not_in_treeSlice_of_table_ne (by decide) _)
          (fun _ _ => ⟨(by intro h; cases h), (by intro h; cases h),
                       not_in_treeSlice_of_table_ne (by decide) _,
                       not_in_treeSlice_of_table_ne (by decide) _⟩)).2,
        ← wordStore_read_eq_vals hmA.wf]
  · exact hcoordsK.unchanged (fun _ _ _ _ _ _ => by
      rw [wordStore_read_eq_vals hmB.wf,
          (hunchB_K _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
          ← wordStore_read_eq_vals hmK.wf])
  · exact htree0A.unchanged (fun u₀ hu₀ f hf => hunchB_A _ (by intro h; cases h) (by intro h; cases h)
      (by intro h; cases h) (not_in_treeSlice_of_tid_ne hu₀ hf (by decide))
      (fun _ _ => ⟨(by intro h; cases h), (by intro h; cases h),
                   not_in_treeSlice_of_tid_ne hu₀ hf (by clear * -; omega),
                   not_in_treeSlice_of_tid_ne hu₀ hf (by clear * -; omega)⟩))
  · exact htreeL.unchanged (fun u₀ _ f _ => hunchB _ (by intro h; cases h))
  · intro j hj
    exact (hpreK j hj le_rfl).unchanged hmK.wf hmB.wf
      (fun off _ => hunchB_K _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _))
      (fun h' _ => hunchB_K _ (by intro h; cases h) (not_in_treeSlice_of_table_ne (by decide) _))
      (fun u₀ hu₀ f hf => hunchB_K _ (by intro h; cases h) (not_in_treeSlice_of_tid_ne hu₀ hf (by clear * -; omega)))
      (fun u₀ hu₀ f hf => hunchB_K _ (by intro h; cases h) (not_in_treeSlice_of_tid_ne hu₀ hf (by clear * -; omega)))
  · intro j hlo hhi
    have hns_pos : 0 < posNodeStride d L := by unfold posNodeStride; exact lt_of_lt_of_le (by decide : 0 < 8) (le_trans (Nat.le_add_right 8 (2 * d)) (Nat.le_add_right _ (2 ^ L)))
    exact (hemptyA j hlo hhi).unchanged
      (fun off hoff => (hunchB_A _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_table_ne (by decide) _)
        (fun i hi => ⟨(fun hc => by injection hc with _ ha; have h_eq := (nodeCellAddr_inj hoff hns_pos ha).1; clear * - h_eq hlo hi; omega),
                      (by intro h; cases h),
                      not_in_treeSlice_of_table_ne (by decide) _,
                      not_in_treeSlice_of_table_ne (by decide) _⟩)).1.mp)
      (fun h' hh' => (hunchB_A _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_table_ne (by decide) _)
        (fun i hi => ⟨(by intro h; cases h),
                      (fun hc => by
                        injection hc with _ ha
                        have hnat : j * 2 ^ L + h' = i * 2 ^ L + hOp := by exact_mod_cast ha
                        have h1 : (i + 1) * 2 ^ L ≤ j * 2 ^ L := Nat.mul_le_mul_right _ (by clear * - hlo hi; omega)
                        have h2 : i * 2 ^ L + hOp < (i + 1) * 2 ^ L := by rw [add_mul, one_mul]; exact Nat.add_lt_add_left hhOp_lt _
                        clear * - hnat h1 h2; omega),
                      not_in_treeSlice_of_table_ne (by decide) _,
                      not_in_treeSlice_of_table_ne (by decide) _⟩)).1.mp)
      (fun u₀ hu₀ f hf => (hunchB_A _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_tid_ne hu₀ hf (by clear * -; omega))
        (fun i hi => ⟨(by intro h; cases h), (by intro h; cases h),
                      not_in_treeSlice_of_tid_ne hu₀ hf (by clear * - hlo hi; omega),
                      not_in_treeSlice_of_tid_ne hu₀ hf (by clear * - hlo hi; omega)⟩)).1.mp)
      (fun u₀ hu₀ f hf => (hunchB_A _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)
        (not_in_treeSlice_of_tid_ne hu₀ hf (by clear * -; omega))
        (fun i hi => ⟨(by intro h; cases h), (by intro h; cases h),
                      not_in_treeSlice_of_tid_ne hu₀ hf (by clear * - hlo hi; omega),
                      not_in_treeSlice_of_tid_ne hu₀ hf (by clear * - hlo hi; omega)⟩)).1.mp)
  · intro t ht z hm_in
    have ht_ne : t ≠ 0 ∧ t ≠ 1 ∧ t ≠ 2 ∧ t ≠ 3 ∧ t ≠ 4 ∧ t ≠ 9 := by
      rcases ht with rfl | rfl | rfl | rfl <;> decide
    have hmA_in := (hunchB_A _
      (fun h => by injection h with ht_eq; exact ht_ne.2.2.2.2.2 ht_eq)
      (fun h => by injection h with ht_eq; exact ht_ne.2.2.2.2.2 ht_eq)
      (fun h => by injection h with ht_eq; exact ht_ne.2.2.2.2.2 ht_eq)
      (not_in_treeSlice_of_table_ne ht_ne.2.2.1 z)
      (fun _ _ => ⟨fun h => by injection h with ht_eq; exact ht_ne.2.2.2.1 ht_eq,
                   fun h => by injection h with ht_eq; exact ht_ne.2.2.2.2.1 ht_eq,
                   not_in_treeSlice_of_table_ne ht_ne.2.2.1 z,
                   not_in_treeSlice_of_table_ne ht_ne.2.2.1 z⟩)).1.mp hm_in
    have hm_ws := (hunchA _
      (fun h => by injection h with ht_eq; exact ht_ne.1 ht_eq)
      (fun h => by injection h with ht_eq; exact ht_ne.2.2.2.2.2 ht_eq)
      (fun h => by injection h with ht_eq; exact ht_ne.2.2.2.2.2 ht_eq)
      (not_in_treeSlice_of_table_ne ht_ne.2.2.1 z)
      (fun _ _ _ _ h => by injection h with ht_eq; exact ht_ne.2.1 ht_eq)).1.mp hmA_in
    rcases ht with rfl | rfl | rfl | rfl
    · exact hinv.stage_clean 5 (Or.inl rfl) z hm_ws
    · exact hinv.stage_clean 6 (Or.inr (Or.inl rfl)) z hm_ws
    · exact hinv.stage_clean 7 (Or.inr (Or.inr (Or.inl rfl))) z hm_ws
    · exact hinv.stage_clean 8 (Or.inr (Or.inr (Or.inr (Or.inl rfl)))) z hm_ws
  · intro z hz102 hz103 hz104 hz105 hz106 hm_in
    have hmA_in := (hunchB_A _
      (fun h => by injection h with _ hz; exact hz104 hz)
      (fun h => by injection h with _ hz; exact hz105 hz)
      (fun h => by injection h with _ hz; exact hz106 hz)
      (not_in_treeSlice_of_table_ne (by decide) z)
      (fun _ _ => ⟨(by intro h; cases h), (by intro h; cases h),
                   not_in_treeSlice_of_table_ne (by decide) z,
                   not_in_treeSlice_of_table_ne (by decide) z⟩)).1.mp hm_in
    have hm_ws := (hunchA _
      (by intro h; cases h)
      (fun h => by injection h with _ hz; exact hz102 hz)
      (fun h => by injection h with _ hz; exact hz103 hz)
      (not_in_treeSlice_of_table_ne (by decide) z)
      (fun _ _ _ _ h => by cases h)).1.mp hmA_in
    exact hinv.stage_clean 9 (Or.inr (Or.inr (Or.inr (Or.inr rfl)))) z hm_ws

end UL.C12LVE
