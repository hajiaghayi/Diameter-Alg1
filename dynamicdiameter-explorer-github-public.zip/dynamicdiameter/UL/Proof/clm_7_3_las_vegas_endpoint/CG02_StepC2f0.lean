import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2e
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.CG02StepC2

open UL.C12StepC2

open UL.C12LVE
open UL
open UL.Proof_lem_A_1

/-! ### 1. Word-Size, Space-Slack, and Cost-Factor Arithmetic Lemmas for `c07StepC2Stmt` -/

def c07WordSizeReq (d s₀_d B B_cert L K_max T_max : ℕ) : ℕ :=
  2 * sqRadBitBound d B B_cert +
  ((K_max + 2) * (2 * d + 9) + L + 1) +
  ((2 * d + 5) * T_max + L + 1) +
  (s₀_d + 2) + (d + 1) + L + 64

def c07StepC2UnitFactorFull (d L F spCeil : ℕ) : ℕ :=
  c07StepC2UnitFactor d L F spCeil + 400

theorem c07WordSizeReq_bounds {d s₀_d B B_cert L K_max T_max W : ℕ}
    (hW : c07WordSizeReq d s₀_d B B_cert L K_max T_max ≤ W) :
    (B + natBitLength ((K_max + 2) * posNodeStride d L) + natBitLength d + L + 40 ≤ W) ∧
    ((d + 1) * (2 * B_cert + 8) + natBitLength ((K_max + 2) * posNodeStride d L) +
      natBitLength ((2 ^ L + 2 * d + 4) * T_max) + natBitLength (s₀_d + 1) + L + 40 ≤ W) ∧
    (2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
      natBitLength (s₀_d + 1) + natBitLength d + L + 40 ≤ W) := by
  have hns := natBitLength_nodeStride_bound d L K_max
  have ha2 := natBitLength_a2Enc_bound d L T_max
  have hs1 := natBitLength_le_add_one (s₀_d + 1)
  have hd_bl := natBitLength_le_add_one d
  have hsq1 : B ≤ sqRadBitBound d B B_cert := by
    unfold sqRadBitBound; clear * -; nlinarith
  have hsq2 : (d + 1) * (2 * B_cert + 8) ≤ sqRadBitBound d B B_cert := by
    unfold sqRadBitBound; clear * -; nlinarith
  dsimp only [c07WordSizeReq] at hW
  exact ⟨by clear * - hW hns hd_bl hsq1; omega,
         by clear * - hW hns ha2 hs1 hsq2; omega,
         by clear * - hW hns hs1 hd_bl; omega⟩

theorem c07_a2_space_ceil_bounds {d n L K_max W T_max spCeil m C_cell C_bit : ℕ}
    (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n)) (hm_n : m ≤ n)
    {inp : BitRAMInput d} {outA2 : BitRAMExecOutcome}
    (hpeakC_m : outA2.peakCellSpace ≤ m * spCeil)
    (hpeakB_m : outA2.peakBitSpace ≤ m * L * spCeil)
    (hcCeil_a2 : inp.inputCellSpace + (posDimWriteLocs d L K_max).card +
      n * c07A2CellPerN d spCeil + 16 ≤ C_cell)
    (hbCeil_a2 : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card +
      n * c07A2BitPerN d L T_max spCeil W + 16 * (W + 12) ≤ C_bit) :
    let S_max := max 1 outA2.peakCellSpace
    outA2.peakCellSpace ≤ S_max ∧
    S_max ≤ m * spCeil + 1 ∧
    natBitLength S_max + 4 ≤ spCeil + L + 6 ∧
    inp.inputCellSpace + (posDimWriteLocs d L K_max).card + posNodeStride d L +
      6 * S_max + 64 ≤ C_cell ∧
    inp.inputBitSpace + 2 * W * ((posDimWriteLocs d L K_max).card + posNodeStride d L) +
      32 * (W + 12) +
      (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 48) * outA2.peakBitSpace +
      4 * S_max * (natBitLength S_max + 12) +
      16 * natBitLength T_max + 24 * (natBitLength S_max + 4) + 300 ≤ C_bit := by
  dsimp only
  set S_max := max 1 outA2.peakCellSpace
  obtain ⟨_, _, h2n_pow, hpow_4n⟩ := clog_two_mul_bounds hn
  rw [← hL] at h2n_pow hpow_4n
  have hm_pow : m ≤ 2 ^ L := by clear * - hm_n h2n_pow; omega
  have hSmax_m1 : S_max ≤ m * spCeil + 1 :=
    max_le (by omega) (Nat.le_succ_of_le hpeakC_m)
  have hSmax_n : S_max ≤ n * (spCeil + 1) := by
    calc S_max ≤ m * spCeil + 1 := hSmax_m1
      _ ≤ n * spCeil + n := Nat.add_le_add (Nat.mul_le_mul_right spCeil hm_n) (by omega)
      _ = n * (spCeil + 1) := by ring
  have hSmax_pow : S_max ≤ (spCeil + 1) * 2 ^ L := by
    have hp1 : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
    calc S_max ≤ m * spCeil + 1 := hSmax_m1
      _ ≤ 2 ^ L * spCeil + 2 ^ L := Nat.add_le_add (Nat.mul_le_mul_right spCeil hm_pow) hp1
      _ = (spCeil + 1) * 2 ^ L := by ring
  set S_bits := natBitLength S_max + 4
  set S_bits_ub := spCeil + L + 6
  have hSbits_le : S_bits ≤ S_bits_ub := by
    have h1 := (natBitLength_mono hSmax_pow).trans (natBitLength_mul_pow2_le (spCeil + 1) L)
    dsimp only [S_bits, S_bits_ub]; clear * - h1; omega
  have hT_nbl : natBitLength T_max ≤ T_max + 1 := natBitLength_le_add_one T_max
  have hns_n : posNodeStride d L ≤ n * (2 * d + 10) := by
    unfold posNodeStride
    calc 8 + 2 * d + 2 ^ L ≤ 6 * n + 2 * d * n + 4 * n := by
          have h1 : 8 ≤ 6 * n := by clear * - hn; omega
          have h2 : 2 * d ≤ 2 * d * n := Nat.le_mul_of_pos_right _ (by clear * - hn; omega)
          linarith only [h1, h2, hpow_4n]
      _ = n * (2 * d + 10) := by ring
  have hcCeilA2 : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + posNodeStride d L +
      6 * S_max + 64 ≤ C_cell := by
    have h6S : 6 * S_max ≤ 6 * (n * (spCeil + 1)) := Nat.mul_le_mul_left 6 hSmax_n
    have h64 : 64 ≤ 64 * n := by clear * - hn; omega
    have hsum : n * (2 * d + 10) + 6 * (n * (spCeil + 1)) + 64 * n ≤ n * c07A2CellPerN d spCeil := by
      unfold c07A2CellPerN
      calc n * (2 * d + 10) + 6 * (n * (spCeil + 1)) + 64 * n
        _ = n * (2 * d + 6 * (spCeil + 1) + 74) := by ring
        _ ≤ n * (2 * d + 6 * (spCeil + 1) + 80) := Nat.mul_le_mul_left n (by omega)
    linarith only [hns_n, h6S, h64, hsum, hcCeil_a2]
  have hbCeilA2 : inp.inputBitSpace + 2 * W * ((posDimWriteLocs d L K_max).card + posNodeStride d L) +
      32 * (W + 12) +
      (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 48) * outA2.peakBitSpace +
      4 * S_max * (natBitLength S_max + 12) +
      16 * natBitLength T_max + 24 * (natBitLength S_max + 4) + 300 ≤ C_bit := by
    have hw_split : 2 * W * ((posDimWriteLocs d L K_max).card + posNodeStride d L) =
        2 * W * (posDimWriteLocs d L K_max).card + 2 * W * posNodeStride d L := by ring
    have t1 : 2 * W * posNodeStride d L ≤ n * (2 * W * (2 * d + 10)) := by
      calc 2 * W * posNodeStride d L ≤ 2 * W * (n * (2 * d + 10)) := Nat.mul_le_mul_left _ hns_n
        _ = n * (2 * W * (2 * d + 10)) := by ring
    have t2 : 16 * (W + 12) ≤ n * (16 * (W + 12)) :=
      Nat.le_mul_of_pos_left _ (by clear * - hn; omega)
    have hpeakB_n : outA2.peakBitSpace ≤ n * (L * spCeil) := by
      calc outA2.peakBitSpace ≤ m * L * spCeil := hpeakB_m
        _ ≤ n * L * spCeil := Nat.mul_le_mul_right spCeil (Nat.mul_le_mul_right L hm_n)
        _ = n * (L * spCeil) := by ring
    have t3 : (3 * natBitLength T_max + 2 * S_bits + 48) * outA2.peakBitSpace ≤
        n * ((3 * T_max + 2 * S_bits_ub + 52) * L * spCeil) := by
      have hc : 3 * natBitLength T_max + 2 * S_bits + 48 ≤ 3 * T_max + 2 * S_bits_ub + 52 := by
        clear * - hT_nbl hSbits_le; omega
      calc (3 * natBitLength T_max + 2 * S_bits + 48) * outA2.peakBitSpace
        _ ≤ (3 * T_max + 2 * S_bits_ub + 52) * (n * (L * spCeil)) := Nat.mul_le_mul hc hpeakB_n
        _ = n * ((3 * T_max + 2 * S_bits_ub + 52) * L * spCeil) := by ring
    have t4 : 4 * S_max * (natBitLength S_max + 12) ≤
        n * (4 * (spCeil + 1) * (S_bits_ub + 12)) := by
      have hc : natBitLength S_max + 12 ≤ S_bits_ub + 12 := by
        have : natBitLength S_max ≤ S_bits := by dsimp [S_bits]; omega
        clear * - this hSbits_le; omega
      calc 4 * S_max * (natBitLength S_max + 12)
        _ ≤ 4 * (n * (spCeil + 1)) * (S_bits_ub + 12) :=
            Nat.mul_le_mul (Nat.mul_le_mul_left 4 hSmax_n) hc
        _ = n * (4 * (spCeil + 1) * (S_bits_ub + 12)) := by ring
    have t5 : 16 * natBitLength T_max + 24 * S_bits + 300 ≤
        n * (16 * T_max + 24 * S_bits_ub + 320) := by
      have hc : 16 * natBitLength T_max + 24 * S_bits + 300 ≤ 16 * T_max + 24 * S_bits_ub + 320 := by
        clear * - hT_nbl hSbits_le; omega
      exact hc.trans (Nat.le_mul_of_pos_left _ (by clear * - hn; omega))
    have htot_n : n * (2 * W * (2 * d + 10)) + n * (16 * (W + 12)) +
        n * ((3 * T_max + 2 * S_bits_ub + 52) * L * spCeil) +
        n * (4 * (spCeil + 1) * (S_bits_ub + 12)) +
        n * (16 * T_max + 24 * S_bits_ub + 320) =
        n * c07A2BitPerN d L T_max spCeil W := by
      unfold c07A2BitPerN; dsimp only [S_bits_ub]; ring
    have h32 : 32 * (W + 12) = 16 * (W + 12) + 16 * (W + 12) := by ring
    dsimp only [S_bits, S_bits_ub] at t3 t4 t5 htot_n
    linarith only [hw_split, t1, t2, t3, t4, t5, htot_n, h32, hbCeil_a2]
  exact ⟨le_max_right 1 _, hSmax_m1, hSbits_le, hcCeilA2, hbCeilA2⟩

theorem c07_stepC2_cost_bounds {d s₀_d L W T_max F spCeil m k_blk S_max work : ℕ}
    (hsp1 : 1 ≤ spCeil) (hm_pow : m ≤ 2 ^ L) (hk_le : k_blk * s₀_d ≤ m)
    {outA2 : BitRAMExecOutcome}
    (hwk_eq : work = outA2.bitCost + outA2.unitCost + m)
    (hSmax_m1 : S_max ≤ m * spCeil + 1)
    (hSbits_le : natBitLength S_max + 4 ≤ spCeil + L + 6)
    (hpeakB_m : outA2.peakBitSpace ≤ m * L * spCeil)
    {u0 u1 u2 u3 b0 b1 b2 b3 : ℕ}
    (hucPre : u1 ≤ u0 + ((m + 1) * (900 * L + 120 * d + 760) + 160))
    (hucClean : u2 ≤ u1 + 8 * F * outA2.unitCost +
      (260 * d + 40 * (k_blk * s₀_d) + 320) + (32 * S_max + 32))
    (hucPost : u3 ≤ u2 + ((m + 1) * (260 * d + 1540 * L + 1300) + 1000))
    (hbcPre : b1 ≤ b0 + (((m + 1) * (150 * L + 24 * d + 220) + 140) * W * W))
    (hbcClean : b2 ≤ b1 + 8 * F * (a2ParamBits m d T_max + (natBitLength S_max + 4)) * outA2.bitCost +
      ((60 * d + 40 * (k_blk * s₀_d) + 180) * W * W) +
      (8 * (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 36) * outA2.peakBitSpace +
        S_max * (72 * (natBitLength S_max + 4) + 512) + 28 * (natBitLength S_max + 4) + 400))
    (hbcPost : b3 ≤ b2 + (((m + 1) * (72 * d + 258 * L + 340) + 450) * W * W)) :
    u3 ≤ u0 + c07StepC2UnitFactorFull d L F spCeil * (work + 1) ∧
    b3 ≤ b0 + c07StepC2BitFactor d L T_max F spCeil W * (work + 1) := by
  set Ω := work + 1
  set S_bits := natBitLength S_max + 4
  set S_bits_ub := spCeil + L + 6
  have hΩ_ge1 : 1 ≤ Ω := Nat.succ_pos _
  have hm1_Ω : m + 1 ≤ Ω := by omega
  have huA2_Ω : outA2.unitCost ≤ Ω := by omega
  have hbA2_Ω : outA2.bitCost ≤ Ω := by omega
  have hkbs_Ω : k_blk * s₀_d ≤ Ω := le_trans hk_le (by omega)
  have hT_nbl : natBitLength T_max ≤ T_max + 1 := natBitLength_le_add_one T_max
  have hSmax_Ω : S_max ≤ spCeil * Ω := by
    calc S_max ≤ m * spCeil + 1 := hSmax_m1
      _ ≤ m * spCeil + spCeil := Nat.add_le_add_left hsp1 _
      _ = spCeil * (m + 1) := by ring
      _ ≤ spCeil * Ω := Nat.mul_le_mul_left spCeil hm1_Ω
  have hpeakB_Ω : outA2.peakBitSpace ≤ (L * spCeil) * Ω := by
    calc outA2.peakBitSpace ≤ m * L * spCeil := hpeakB_m
      _ ≤ Ω * L * spCeil := Nat.mul_le_mul_right spCeil (Nat.mul_le_mul_right L (by omega))
      _ = (L * spCeil) * Ω := by ring
  constructor
  · have su1 : (m + 1) * (900 * L + 120 * d + 760) + 160 ≤ (900 * L + 120 * d + 920) * Ω := by
      have ha : (m + 1) * (900 * L + 120 * d + 760) ≤ Ω * (900 * L + 120 * d + 760) :=
        Nat.mul_le_mul_right _ hm1_Ω
      have hb : 160 ≤ 160 * Ω := Nat.le_mul_of_pos_right 160 hΩ_ge1
      have hc : Ω * (900 * L + 120 * d + 760) + 160 * Ω = (900 * L + 120 * d + 920) * Ω := by ring
      linarith only [ha, hb, hc]
    have su2 : 8 * F * outA2.unitCost + (260 * d + 40 * (k_blk * s₀_d) + 320) + (32 * S_max + 32) ≤
        (8 * F + 32 * spCeil + 260 * d + 400) * Ω := by
      have ha : 8 * F * outA2.unitCost ≤ (8 * F) * Ω := Nat.mul_le_mul_left _ huA2_Ω
      have hb : 260 * d + 352 ≤ (260 * d + 352) * Ω := Nat.le_mul_of_pos_right _ hΩ_ge1
      have hc : 40 * (k_blk * s₀_d) ≤ 40 * Ω := Nat.mul_le_mul_left 40 hkbs_Ω
      have hd : 32 * S_max ≤ (32 * spCeil) * Ω := by
        calc 32 * S_max ≤ 32 * (spCeil * Ω) := Nat.mul_le_mul_left 32 hSmax_Ω
          _ = (32 * spCeil) * Ω := by ring
      have he : (8 * F) * Ω + (260 * d + 352) * Ω + 40 * Ω + (32 * spCeil) * Ω ≤
          (8 * F + 32 * spCeil + 260 * d + 400) * Ω := by
        calc (8 * F) * Ω + (260 * d + 352) * Ω + 40 * Ω + (32 * spCeil) * Ω
          _ = (8 * F + 32 * spCeil + 260 * d + 392) * Ω := by ring
          _ ≤ (8 * F + 32 * spCeil + 260 * d + 400) * Ω := Nat.mul_le_mul_right Ω (by omega)
      linarith only [ha, hb, hc, hd, he]
    have su3 : (m + 1) * (260 * d + 1540 * L + 1300) + 1000 ≤ (260 * d + 1540 * L + 2300) * Ω := by
      have ha : (m + 1) * (260 * d + 1540 * L + 1300) ≤ Ω * (260 * d + 1540 * L + 1300) :=
        Nat.mul_le_mul_right _ hm1_Ω
      have hb : 1000 ≤ 1000 * Ω := Nat.le_mul_of_pos_right 1000 hΩ_ge1
      have hc : Ω * (260 * d + 1540 * L + 1300) + 1000 * Ω = (260 * d + 1540 * L + 2300) * Ω := by ring
      linarith only [ha, hb, hc]
    have usum : (900 * L + 120 * d + 920) * Ω + (8 * F + 32 * spCeil + 260 * d + 400) * Ω +
        (260 * d + 1540 * L + 2300) * Ω ≤ c07StepC2UnitFactorFull d L F spCeil * Ω := by
      unfold c07StepC2UnitFactorFull c07StepC2UnitFactor
      calc (900 * L + 120 * d + 920) * Ω + (8 * F + 32 * spCeil + 260 * d + 400) * Ω +
            (260 * d + 1540 * L + 2300) * Ω
        _ = (8 * F + 32 * spCeil + 640 * d + 2440 * L + 3620) * Ω := by ring
        _ ≤ (8 * F + 32 * spCeil + 680 * d + 2440 * L + 3600 + 400) * Ω :=
            Nat.mul_le_mul_right Ω (by omega)
    linarith only [hucPre, hucClean, hucPost, su1, su2, su3, usum]
  · set K_ub := L + d + T_max + 16 + S_bits_ub
    have hK_le : a2ParamBits m d T_max + S_bits ≤ K_ub := by
      have hm_nbl : natBitLength m ≤ L + 2 := by
        have h1 : m ≤ 1 * 2 ^ L := by simpa using hm_pow
        have h2 := (natBitLength_mono h1).trans (natBitLength_mul_pow2_le 1 L)
        clear * - h2; omega
      have hd_nbl := natBitLength_le_add_one d
      unfold a2ParamBits
      dsimp only [K_ub]
      clear * - hm_nbl hd_nbl hT_nbl hSbits_le; omega
    have sb1 : ((m + 1) * (150 * L + 24 * d + 220) + 140) * W * W ≤
        ((150 * L + 24 * d + 360) * W * W) * Ω := by
      have ha : (m + 1) * (150 * L + 24 * d + 220) + 140 ≤ (150 * L + 24 * d + 360) * Ω := by
        have h1 : (m + 1) * (150 * L + 24 * d + 220) ≤ Ω * (150 * L + 24 * d + 220) :=
          Nat.mul_le_mul_right _ hm1_Ω
        have h2 : 140 ≤ 140 * Ω := Nat.le_mul_of_pos_right 140 hΩ_ge1
        have h3 : Ω * (150 * L + 24 * d + 220) + 140 * Ω = (150 * L + 24 * d + 360) * Ω := by ring
        linarith only [h1, h2, h3]
      calc ((m + 1) * (150 * L + 24 * d + 220) + 140) * W * W
        _ = ((m + 1) * (150 * L + 24 * d + 220) + 140) * (W * W) := by ring
        _ ≤ ((150 * L + 24 * d + 360) * Ω) * (W * W) := Nat.mul_le_mul_right (W * W) ha
        _ = ((150 * L + 24 * d + 360) * W * W) * Ω := by ring
    have sb2_fk : 8 * F * (a2ParamBits m d T_max + S_bits) * outA2.bitCost ≤ (8 * F * K_ub) * Ω :=
      Nat.mul_le_mul (Nat.mul_le_mul_left (8 * F) hK_le) hbA2_Ω
    have sb2_ww : (60 * d + 40 * (k_blk * s₀_d) + 180) * W * W ≤ ((60 * d + 220) * W * W) * Ω := by
      have ha : 60 * d + 40 * (k_blk * s₀_d) + 180 ≤ (60 * d + 220) * Ω := by
        have h1 : 60 * d + 180 ≤ (60 * d + 180) * Ω := Nat.le_mul_of_pos_right _ hΩ_ge1
        have h2 : 40 * (k_blk * s₀_d) ≤ 40 * Ω := Nat.mul_le_mul_left 40 hkbs_Ω
        have h3 : (60 * d + 180) * Ω + 40 * Ω = (60 * d + 220) * Ω := by ring
        linarith only [h1, h2, h3]
      calc (60 * d + 40 * (k_blk * s₀_d) + 180) * W * W
        _ = (60 * d + 40 * (k_blk * s₀_d) + 180) * (W * W) := by ring
        _ ≤ ((60 * d + 220) * Ω) * (W * W) := Nat.mul_le_mul_right (W * W) ha
        _ = ((60 * d + 220) * W * W) * Ω := by ring
    have sb2_pk : 8 * (3 * natBitLength T_max + 2 * S_bits + 36) * outA2.peakBitSpace ≤
        (8 * (3 * T_max + 2 * S_bits_ub + 40) * L * spCeil) * Ω := by
      have hc : 8 * (3 * natBitLength T_max + 2 * S_bits + 36) ≤
          8 * (3 * T_max + 2 * S_bits_ub + 40) :=
        Nat.mul_le_mul_left 8 (by clear * - hT_nbl hSbits_le; omega)
      calc 8 * (3 * natBitLength T_max + 2 * S_bits + 36) * outA2.peakBitSpace
        _ ≤ (8 * (3 * T_max + 2 * S_bits_ub + 40)) * ((L * spCeil) * Ω) := Nat.mul_le_mul hc hpeakB_Ω
        _ = (8 * (3 * T_max + 2 * S_bits_ub + 40) * L * spCeil) * Ω := by ring
    have sb2_cl : S_max * (72 * S_bits + 512) + 28 * S_bits + 400 ≤
        (spCeil * (72 * S_bits_ub + 512) + 28 * S_bits_ub + 400) * Ω := by
      have hc1 : S_max * (72 * S_bits + 512) ≤ (spCeil * (72 * S_bits_ub + 512)) * Ω := by
        calc S_max * (72 * S_bits + 512)
          _ ≤ (spCeil * Ω) * (72 * S_bits_ub + 512) :=
              Nat.mul_le_mul hSmax_Ω (by clear * - hSbits_le; omega)
          _ = (spCeil * (72 * S_bits_ub + 512)) * Ω := by ring
      have hc2 : 28 * S_bits + 400 ≤ (28 * S_bits_ub + 400) * Ω :=
        (show 28 * S_bits + 400 ≤ 28 * S_bits_ub + 400 from by clear * - hSbits_le; omega).trans
          (Nat.le_mul_of_pos_right _ hΩ_ge1)
      have hc3 : (spCeil * (72 * S_bits_ub + 512)) * Ω + (28 * S_bits_ub + 400) * Ω =
          (spCeil * (72 * S_bits_ub + 512) + 28 * S_bits_ub + 400) * Ω := by ring
      linarith only [hc1, hc2, hc3]
    have sb3 : ((m + 1) * (72 * d + 258 * L + 340) + 450) * W * W ≤
        ((72 * d + 258 * L + 790) * W * W) * Ω := by
      have ha : (m + 1) * (72 * d + 258 * L + 340) + 450 ≤ (72 * d + 258 * L + 790) * Ω := by
        have h1 : (m + 1) * (72 * d + 258 * L + 340) ≤ Ω * (72 * d + 258 * L + 340) :=
          Nat.mul_le_mul_right _ hm1_Ω
        have h2 : 450 ≤ 450 * Ω := Nat.le_mul_of_pos_right 450 hΩ_ge1
        have h3 : Ω * (72 * d + 258 * L + 340) + 450 * Ω = (72 * d + 258 * L + 790) * Ω := by ring
        linarith only [h1, h2, h3]
      calc ((m + 1) * (72 * d + 258 * L + 340) + 450) * W * W
        _ = ((m + 1) * (72 * d + 258 * L + 340) + 450) * (W * W) := by ring
        _ ≤ ((72 * d + 258 * L + 790) * Ω) * (W * W) := Nat.mul_le_mul_right (W * W) ha
        _ = ((72 * d + 258 * L + 790) * W * W) * Ω := by ring
    have bsum : (8 * F * K_ub) * Ω + ((150 * L + 24 * d + 360) * W * W) * Ω +
        ((60 * d + 220) * W * W) * Ω + ((72 * d + 258 * L + 790) * W * W) * Ω +
        (8 * (3 * T_max + 2 * S_bits_ub + 40) * L * spCeil) * Ω +
        (spCeil * (72 * S_bits_ub + 512) + 28 * S_bits_ub + 400) * Ω ≤
        c07StepC2BitFactor d L T_max F spCeil W * Ω := by
      unfold c07StepC2BitFactor
      dsimp only [S_bits_ub, K_ub]
      have hww : ((150 * L + 24 * d + 360) * W * W) + ((60 * d + 220) * W * W) +
          ((72 * d + 258 * L + 790) * W * W) ≤ (196 * d + 408 * L + 1400) * W * W := by
        calc ((150 * L + 24 * d + 360) * W * W) + ((60 * d + 220) * W * W) +
              ((72 * d + 258 * L + 790) * W * W)
          _ = (156 * d + 408 * L + 1370) * (W * W) := by ring
          _ ≤ (196 * d + 408 * L + 1400) * (W * W) := Nat.mul_le_mul_right (W * W) (by omega)
          _ = (196 * d + 408 * L + 1400) * W * W := by ring
      have hwwΩ := Nat.mul_le_mul_right Ω hww
      have hring1 : ((150 * L + 24 * d + 360) * W * W) * Ω + ((60 * d + 220) * W * W) * Ω +
          ((72 * d + 258 * L + 790) * W * W) * Ω =
          (((150 * L + 24 * d + 360) * W * W) + ((60 * d + 220) * W * W) +
            ((72 * d + 258 * L + 790) * W * W)) * Ω := by ring
      have hring2 : (8 * F * (L + d + T_max + 16 + (spCeil + L + 6)) +
          (196 * d + 408 * L + 1400) * W * W +
          8 * (3 * T_max + 2 * (spCeil + L + 6) + 40) * L * spCeil +
          spCeil * (72 * (spCeil + L + 6) + 512) + 28 * (spCeil + L + 6) + 400) * Ω =
          (8 * F * (L + d + T_max + 16 + (spCeil + L + 6))) * Ω +
          ((196 * d + 408 * L + 1400) * W * W) * Ω +
          (8 * (3 * T_max + 2 * (spCeil + L + 6) + 40) * L * spCeil) * Ω +
          (spCeil * (72 * (spCeil + L + 6) + 512) + 28 * (spCeil + L + 6) + 400) * Ω := by ring
      linarith only [hwwΩ, hring1, hring2]
    dsimp only [S_bits] at sb2_fk sb2_pk sb2_cl hbcClean
    linarith only [hbcPre, hbcClean, hbcPost, sb1, sb2_fk, sb2_ww, sb2_pk, sb2_cl, sb3, bsum]

end UL.CG02StepC2
