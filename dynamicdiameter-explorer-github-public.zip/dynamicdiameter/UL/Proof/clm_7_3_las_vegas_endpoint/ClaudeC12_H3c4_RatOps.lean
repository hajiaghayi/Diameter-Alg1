import Mathlib
import UL.Def.def_core_witness_halfspaces
import UL.Def.def_node_chain_blocks
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2b_SubStore
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3c3_Dim0
set_option autoImplicit false
set_option maxHeartbeats 800000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Tight `intBitLength` Addition Bounds and `ratSumPairs` -/

theorem intBitLength_neg (a : ℤ) : intBitLength (-a) = intBitLength a := by
  unfold intBitLength
  have hz : (-a = 0) ↔ (a = 0) := neg_eq_zero
  simp [hz, Int.natAbs_neg]

theorem intBitLength_add_le_max (a b : ℤ) :
    intBitLength (a + b) ≤ max (intBitLength a) (intBitLength b) + 1 := by
  by_cases hsum : a + b = 0
  · rw [hsum]
    have : intBitLength (0 : ℤ) = 1 := by decide
    omega
  · set M := max a.natAbs b.natAbs
    have hM_pos : 0 < M := by
      dsimp [M]
      by_contra h0
      have ha0 : a = 0 := Int.natAbs_eq_zero.mp (by omega)
      have hb0 : b = 0 := Int.natAbs_eq_zero.mp (by omega)
      exact hsum (by simp [ha0, hb0])
    have habs_le : (a + b).natAbs ≤ 2 * M := by
      have htri := Int.natAbs_add_le a b
      have haM : a.natAbs ≤ M := le_max_left _ _
      have hbM : b.natAbs ≤ M := le_max_right _ _
      omega
    have hlog_le : Nat.log 2 (a + b).natAbs ≤ Nat.log 2 M + 1 := by
      calc Nat.log 2 (a + b).natAbs
        _ ≤ Nat.log 2 (2 * M) := Nat.log_mono_right habs_le
        _ = Nat.log 2 (M * 2) := by rw [Nat.mul_comm]
        _ = Nat.log 2 M + 1 := Nat.log_mul_base (by decide) (by omega)
    have hM_bl : 1 + (Nat.log 2 M + 1) ≤ max (intBitLength a) (intBitLength b) := by
      rcases max_choice a.natAbs b.natAbs with hma | hmb
      · have h_eq : M = a.natAbs := hma
        have ha_ne : a ≠ 0 := Int.natAbs_ne_zero.mp (by omega)
        have hbl_a : intBitLength a = 1 + (Nat.log 2 M + 1) := by
          unfold intBitLength natBitLength
          rw [if_neg ha_ne, h_eq]
        exact hbl_a ▸ le_max_left _ _
      · have h_eq : M = b.natAbs := hmb
        have hb_ne : b ≠ 0 := Int.natAbs_ne_zero.mp (by omega)
        have hbl_b : intBitLength b = 1 + (Nat.log 2 M + 1) := by
          unfold intBitLength natBitLength
          rw [if_neg hb_ne, h_eq]
        exact hbl_b ▸ le_max_right _ _
    conv_lhs => unfold intBitLength natBitLength
    rw [if_neg hsum]
    clear * - hlog_le hM_bl; omega

theorem intBitLength_sub_le_max (a b : ℤ) :
    intBitLength (a - b) ≤ max (intBitLength a) (intBitLength b) + 1 := by
  rw [sub_eq_add_neg, ← intBitLength_neg b]
  exact intBitLength_add_le_max a (-b)

/-- Unreduced rational accumulator summing `(tNum i) / (tDen i)` for `0 ≤ i < k`. -/
def ratSumPairs (tNum tDen : ℕ → ℤ) : ℕ → ℤ × ℤ
  | 0 => (0, 1)
  | k + 1 =>
      let p := ratSumPairs tNum tDen k
      (p.1 * tDen k + tNum k * p.2, p.2 * tDen k)

theorem ratSumPairs_spec {tNum tDen : ℕ → ℤ} {B_t : ℕ} (hBt : 1 ≤ B_t) :
    ∀ k : ℕ,
      (∀ i < k, 1 ≤ tDen i ∧ intBitLength (tNum i) ≤ B_t ∧ intBitLength (tDen i) ≤ B_t) →
      let p := ratSumPairs tNum tDen k
      1 ≤ p.2 ∧
      ((p.1 : ℝ) / (p.2 : ℝ) = ∑ i ∈ Finset.range k, ((tNum i : ℝ) / (tDen i : ℝ))) ∧
      intBitLength p.1 ≤ k * (B_t + 1) + 2 ∧
      intBitLength p.2 ≤ k * B_t + 2 ∧
      ((∀ i < k, 0 ≤ tNum i) → 0 ≤ p.1)
  | 0, _ => by
      have hl0 : intBitLength (0 : ℤ) = 1 := by decide
      have hl1 : intBitLength (1 : ℤ) = 2 := by decide
      refine ⟨le_rfl, by simp [ratSumPairs], by simp [ratSumPairs, hl0],
              by simp [ratSumPairs, hl1], fun _ => le_rfl⟩
  | k + 1, hbnds => by
      obtain ⟨hd_pos, hsum_eq, hn_bl, hd_bl, hnonneg⟩ :=
        ratSumPairs_spec hBt k (fun i hi => hbnds i (Nat.lt_succ_of_lt hi))
      set p := ratSumPairs tNum tDen k
      obtain ⟨hdk_pos, hnk_bl, hdk_bl⟩ := hbnds k (Nat.lt_succ_self k)
      dsimp only [ratSumPairs]
      refine ⟨?_, ?_, ?_, ?_, ?_⟩
      · nlinarith only [hd_pos, hdk_pos]
      · rw [Finset.sum_range_succ, ← hsum_eq]
        have hp2_ne : (p.2 : ℝ) ≠ 0 := by exact_mod_cast (by clear * - hd_pos; omega : p.2 ≠ 0)
        have hdk_ne : (tDen k : ℝ) ≠ 0 := by exact_mod_cast (by clear * - hdk_pos; omega : tDen k ≠ 0)
        rw [div_add_div _ _ hp2_ne hdk_ne]
        change (((p.1 * tDen k + tNum k * p.2 : ℤ) : ℝ) / ((p.2 * tDen k : ℤ) : ℝ)) = _
        push_cast; ring
      · have hm1 := (intBitLength_mul_le p.1 (tDen k)).trans (Nat.add_le_add hn_bl hdk_bl)
        have hm2 := (intBitLength_mul_le (tNum k) p.2).trans (Nat.add_le_add hnk_bl hd_bl)
        have hadd := intBitLength_add_le_max (p.1 * tDen k) (tNum k * p.2)
        have hmax : max (intBitLength (p.1 * tDen k)) (intBitLength (tNum k * p.2)) ≤
            k * (B_t + 1) + 2 + B_t := by
          apply max_le
          · exact hm1
          · calc intBitLength (tNum k * p.2) ≤ B_t + (k * B_t + 2) := hm2
              _ ≤ k * (B_t + 1) + 2 + B_t := by nlinarith
        calc intBitLength (p.1 * tDen k + tNum k * p.2)
          _ ≤ (k * (B_t + 1) + 2 + B_t) + 1 := Nat.le_trans hadd (Nat.add_le_add_right hmax 1)
          _ = (k + 1) * (B_t + 1) + 2 := by ring
      · calc intBitLength (p.2 * tDen k)
          _ ≤ intBitLength p.2 + intBitLength (tDen k) := intBitLength_mul_le _ _
          _ ≤ (k * B_t + 2) + B_t := Nat.add_le_add hd_bl hdk_bl
          _ = (k + 1) * B_t + 2 := by ring
      · intro hnn
        have hp1_nn := hnonneg (fun i hi => hnn i (Nat.lt_succ_of_lt hi))
        have htk_nn := hnn k (Nat.lt_succ_self k)
        nlinarith only [hp1_nn, htk_nn, hd_pos, hdk_pos]

/-- Euclidean norm squared of a difference of two rational points via integer numerators/denominators. -/
theorem ratPoint_distSq_eq {d : ℕ} {p q : Fin d → ℚ}
    {pNum pDen qNum qDen : ℕ → ℤ}
    (hp : ∀ c : Fin d, 1 ≤ pDen c.val ∧ (p c : ℝ) = (pNum c.val : ℝ) / (pDen c.val : ℝ))
    (hq : ∀ c : Fin d, 1 ≤ qDen c.val ∧ (q c : ℝ) = (qNum c.val : ℝ) / (qDen c.val : ℝ)) :
    let sqNum := fun i => (pNum i * qDen i - qNum i * pDen i) * (pNum i * qDen i - qNum i * pDen i)
    let sqDen := fun i => (pDen i * qDen i) * (pDen i * qDen i)
    let res := ratSumPairs sqNum sqDen d
    ((res.1 : ℝ) / (res.2 : ℝ)) = ‖ratPointToEuclidean p - ratPointToEuclidean q‖ ^ 2 := by
  intro sqNum sqDen res
  have hterm : ∀ i < d, 1 ≤ sqDen i := by
    intro i hi
    have hp1 := (hp ⟨i, hi⟩).1
    have hq1 := (hq ⟨i, hi⟩).1
    have h12 : 1 ≤ pDen i * qDen i := by nlinarith only [hp1, hq1]
    dsimp [sqDen]
    nlinarith only [h12]
  have hsum : ((res.1 : ℝ) / (res.2 : ℝ)) = ∑ i ∈ Finset.range d, ((sqNum i : ℝ) / (sqDen i : ℝ)) := by
    -- Prove directly by induction on `k ≤ d` without bit-length bound
    have hind : ∀ k ≤ d,
        1 ≤ (ratSumPairs sqNum sqDen k).2 ∧
        ((ratSumPairs sqNum sqDen k).1 : ℝ) / ((ratSumPairs sqNum sqDen k).2 : ℝ) =
          ∑ i ∈ Finset.range k, ((sqNum i : ℝ) / (sqDen i : ℝ)) := by
      intro k hk
      induction k with
      | zero => exact ⟨le_rfl, by simp [ratSumPairs]⟩
      | succ k ih =>
          obtain ⟨hd2, heq2⟩ := ih (Nat.le_of_succ_le hk)
          have hdk := hterm k (Nat.lt_of_succ_le hk)
          refine ⟨by dsimp [ratSumPairs]; nlinarith only [hd2, hdk], ?_⟩
          dsimp [ratSumPairs]
          rw [Finset.sum_range_succ, ← heq2]
          have h1 : ((ratSumPairs sqNum sqDen k).2 : ℝ) ≠ 0 := by exact_mod_cast (by omega)
          have h2 : (sqDen k : ℝ) ≠ 0 := by exact_mod_cast (by omega)
          push_cast; field_simp [h1, h2]
    exact (hind d le_rfl).2
  rw [hsum, EuclideanSpace.norm_sq_eq, Finset.sum_fin_eq_sum_range]
  refine Finset.sum_congr rfl (fun i hi => ?_)
  have hi_lt : i < d := Finset.mem_range.mp hi
  rw [dif_pos hi_lt]
  obtain ⟨hp1, hpeq⟩ := hp ⟨i, hi_lt⟩
  obtain ⟨hq1, hqeq⟩ := hq ⟨i, hi_lt⟩
  dsimp only at hp1 hq1 hpeq hqeq
  have hcoord : (ratPointToEuclidean p - ratPointToEuclidean q).ofLp ⟨i, hi_lt⟩ =
      (p ⟨i, hi_lt⟩ : ℝ) - (q ⟨i, hi_lt⟩ : ℝ) := rfl
  change ((sqNum i : ℝ) / (sqDen i : ℝ)) =
    ‖(ratPointToEuclidean p - ratPointToEuclidean q).ofLp ⟨i, hi_lt⟩‖ ^ 2
  rw [hcoord, Real.norm_eq_abs, sq_abs, hpeq, hqeq]
  have hp_ne : (pDen i : ℝ) ≠ 0 := by exact_mod_cast (by clear * - hp1; omega : pDen i ≠ 0)
  have hq_ne : (qDen i : ℝ) ≠ 0 := by exact_mod_cast (by clear * - hq1; omega : qDen i ≠ 0)
  dsimp [sqNum, sqDen]
  push_cast
  field_simp [hp_ne, hq_ne]

/-- Exact cross-multiplication test for `pt ∈ coreBall o V` when `0 ≤ V = V_num / V_den` and
`‖pt - o‖^2 = rNum / rDen`. -/
theorem mem_coreBall_iff_crossMul {d : ℕ} {pt o : EuclideanSpace ℝ (Fin d)}
    {V : ℝ} (hV0 : 0 ≤ V) {rNum rDen V_num V_den : ℤ}
    (hrD : 1 ≤ rDen) (hVD : 1 ≤ V_den)
    (hrEq : ((rNum : ℝ) / (rDen : ℝ)) = ‖pt - o‖ ^ 2)
    (hVEq : ((V_num : ℝ) / (V_den : ℝ)) = V) :
    (pt ∈ coreBall o V) ↔ rNum * V_den ≤ V_num * rDen := by
  unfold coreBall
  rw [Metric.mem_closedBall, dist_eq_norm]
  have hsq : ‖pt - o‖ ≤ Real.sqrt V ↔ ‖pt - o‖ ^ 2 ≤ (Real.sqrt V) ^ 2 := by
    constructor
    · intro h; exact pow_le_pow_left₀ (norm_nonneg _) h 2
    · intro h
      nlinarith [norm_nonneg (pt - o), Real.sqrt_nonneg V, h]
  rw [hsq, Real.sq_sqrt hV0, ← hrEq, ← hVEq]
  have hrD_pos : (0 : ℝ) < (rDen : ℝ) := by exact_mod_cast (by omega : 0 < rDen)
  have hVD_pos : (0 : ℝ) < (V_den : ℝ) := by exact_mod_cast (by omega : 0 < V_den)
  rw [div_le_div_iff₀ hrD_pos hVD_pos]
  exact_mod_cast Iff.rfl


/-! ### 2. Heap Table `1`: `ActiveCoordsStored`, `saveInsPointRegs`, `freeDelPointRegs` -/

def coordCellAddr (d h c f : ℕ) : ℤ :=
  (((h * d + c) * 2 + f : ℕ) : ℤ)

theorem coordCellAddr_inj {d h₁ c₁ f₁ h₂ c₂ f₂ : ℕ}
    (hc₁ : c₁ < d) (hf₁ : f₁ < 2) (hc₂ : c₂ < d) (hf₂ : f₂ < 2)
    (heq : coordCellAddr d h₁ c₁ f₁ = coordCellAddr d h₂ c₂ f₂) :
    h₁ = h₂ ∧ c₁ = c₂ ∧ f₁ = f₂ := by
  unfold coordCellAddr at heq
  have hnat : (h₁ * d + c₁) * 2 + f₁ = (h₂ * d + c₂) * 2 + f₂ := by exact_mod_cast heq
  have hf : f₁ = f₂ := by omega
  have hhd : h₁ * d + c₁ = h₂ * d + c₂ := by omega
  rcases lt_trichotomy h₁ h₂ with hlt | rfl | hgt
  · have : (h₁ + 1) * d ≤ h₂ * d := Nat.mul_le_mul_right d (by omega)
    have : h₁ * d + c₁ < (h₁ + 1) * d := by rw [add_mul, one_mul]; omega
    omega
  · exact ⟨rfl, by omega, hf⟩
  · have : (h₂ + 1) * d ≤ h₁ * d := Nat.mul_le_mul_right d (by omega)
    have : h₂ * d + c₂ < (h₂ + 1) * d := by rw [add_mul, one_mul]; omega
    omega

theorem coordCellAddr_bl {d L h c f W : ℕ}
    (hh : h < 2 ^ L) (hc : c < d) (hf : f < 2)
    (hW : natBitLength d + L + 12 ≤ W) :
    (RAMCellLoc.heap 1 (coordCellAddr d h c f)).bitLength ≤ W ∧
    intBitLength (coordCellAddr d h c f) ≤ W := by
  have hd1 : 1 ≤ d := by omega
  have hlt : (h * d + c) * 2 + f < 2 * d * 2 ^ L := by
    have h1 : h * d + c < (h + 1) * d := by rw [add_mul, one_mul]; omega
    have h2 : (h + 1) * d ≤ 2 ^ L * d := Nat.mul_le_mul_right d (by omega)
    nlinarith only [h1, h2, hf]
  have hle_addr : intBitLength (coordCellAddr d h c f) ≤ natBitLength d + L + 6 := by
    unfold coordCellAddr
    have h1 := intBitLength_ofNat_le ((h * d + c) * 2 + f)
    have h2 : natBitLength ((h * d + c) * 2 + f) ≤ natBitLength (2 * d * 2 ^ L) :=
      natBitLength_mono (by omega)
    have h3 : natBitLength (2 * d * 2 ^ L) ≤ natBitLength d + L + 4 := by
      unfold natBitLength
      have hpow : 2 * d * 2 ^ L = d * 2 ^ (L + 1) := by rw [pow_succ]; ring
      rw [hpow]
      have hpow_pos : 0 < 2 ^ (L + 1) := by positivity
      have hpos : d * 2 ^ (L + 1) ≠ 0 := Nat.mul_ne_zero (by clear * - hd1; omega) (by clear * - hpow_pos; omega)
      have hd_lt : d < 2 ^ (Nat.log 2 d + 1) := Nat.lt_pow_succ_log_self (by decide) d
      have hprod_lt : d * 2 ^ (L + 1) < 2 ^ (Nat.log 2 d + 1 + (L + 1)) := by
        calc d * 2 ^ (L + 1) < 2 ^ (Nat.log 2 d + 1) * 2 ^ (L + 1) := Nat.mul_lt_mul_of_pos_right hd_lt hpow_pos
          _ = 2 ^ (Nat.log 2 d + 1 + (L + 1)) := (pow_add 2 (Nat.log 2 d + 1) (L + 1)).symm
      have hlog := Nat.log_lt_of_lt_pow hpos hprod_lt
      clear * - hlog; omega
    omega
  have hn1 : natBitLength 1 = 1 := by decide
  exact ⟨by dsimp [RAMCellLoc.bitLength]; omega, by omega⟩

structure ActiveCoordsStored (d L B : ℕ) (S : Finset ℕ)
    (qMap : ℕ → Fin d → ℚ) (ws : WordStore) : Prop where
  hS : ∀ h ∈ S, h < 2 ^ L ∧ RatPointBitBounded B (qMap h)
  read_num : ∀ h ∈ S, ∀ c : Fin d,
    ws.read (.heap 1 (coordCellAddr d h c.val 0)) = (qMap h c).num
  read_den : ∀ h ∈ S, ∀ c : Fin d,
    ws.read (.heap 1 (coordCellAddr d h c.val 1)) = ((qMap h c).den : ℤ)

theorem ActiveCoordsStored.unchanged {d L B : ℕ} {S : Finset ℕ} {qMap : ℕ → Fin d → ℚ}
    {ws₁ ws₂ : WordStore} (h : ActiveCoordsStored d L B S qMap ws₁)
    (heq : ∀ h' ∈ S, ∀ c < d, ∀ f < 2,
      ws₂.read (.heap 1 (coordCellAddr d h' c f)) = ws₁.read (.heap 1 (coordCellAddr d h' c f))) :
    ActiveCoordsStored d L B S qMap ws₂ :=
  { hS := h.hS
    read_num := fun h' hh' c => (heq h' hh' c.val c.isLt 0 (by decide)).trans (h.read_num h' hh' c)
    read_den := fun h' hh' c => (heq h' hh' c.val c.isLt 1 (by decide)).trans (h.read_den h' hh' c) }

/-- Loop step copying `(extraRatNum c, extraRatDen c)` into `heap 1 (coordCellAddr d hNew c 0/1)`,
where `r1 = hNew`, `r6 = c`, `r7 = d`. -/
def saveInsCoordStepStmt : BitRAMStmt :=
  .seq (rMul 8 1 7)
  (.seq (rAdd 8 8 6)
  (.seq (rAdd 8 8 8)
  (.seq (rExtraRatNum 9 6)
  (.seq (rStore 1 8 9)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
  (.seq (rExtraRatDen 9 6)
  (.seq (rStore 1 8 9)
        (rAdd 6 6 15)))))))))

def saveInsPointRegs (d : ℕ) : BitRAMStmt :=
  .seq (rLit 6 0)
  (.seq (rLit 7 (d : ℤ))
        (.repeatN (.lit (d : ℤ)) saveInsCoordStepStmt))

theorem exec_saveInsPointRegs {d : ℕ} (_hd1 : 1 ≤ d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L B hNew : ℕ} (hB1 : 1 ≤ B) (hhNew_lt : hNew < 2 ^ L)
    (hW : B + natBitLength d + L + 20 ≤ W)
    {S : Finset ℕ} {qMap : ℕ → Fin d → ℚ} {qIns : Fin d → ℚ}
    (hhNew_not : hNew ∉ S)
    (hcoords : ActiveCoordsStored d L B S qMap ws)
    (hqIns_bnd : RatPointBitBounded B qIns)
    (hextra : inp.extraRats = List.ofFn qIns)
    (hSub1 : ∀ c < d, ∀ f < 2, (.heap 1 (coordCellAddr d hNew c f) : RAMCellLoc) ∈ S_write)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr1 : regs 1 = (hNew : ℤ)) :
    let qMap' : ℕ → Fin d → ℚ := fun h => if h = hNew then qIns else qMap h
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (saveInsPointRegs d) ws regs wsEnd regsEnd
        (80 * d + 20) ((12 * d + 8) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      ActiveCoordsStored d L B (insert hNew S) qMap' wsEnd ∧
      regsEnd 1 = (hNew : ℤ) ∧
      (∀ loc : RAMCellLoc, (∀ c < d, ∀ f < 2, loc ≠ .heap 1 (coordCellAddr d hNew c f)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  intro qMap'
  have hW20 : 20 ≤ W := by omega
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hn1 : natBitLength 1 ≤ W := (show natBitLength 1 = 1 from by decide).trans_le (by omega)
  have hd_bl : intBitLength (d : ℤ) ≤ W := (intBitLength_ofNat_le d).trans (by omega)
  have hW_addr : natBitLength d + L + 12 ≤ W := by omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have p1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 6) (c := 0) (by decide) hl0
  set g1 := Function.update regs 6 0; have bg1 : RegBounded W g1 := hbnd.update (r := 6) (by decide) hl0
  have p2 := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 7) (c := (d : ℤ)) (by decide) hd_bl
  set g2 := Function.update g1 7 (d : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 7) (by decide) hd_bl
  have hWW : 20 * W ≤ W * W := by nlinarith only [hW20]
  let StepInv (c : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
    ModifiedOnBounded ws₀ S_write W w ∧
    RegBounded W g ∧
    g 1 = (hNew : ℤ) ∧ g 7 = (d : ℤ) ∧
    (∀ loc : RAMCellLoc, (∀ c' < d, ∀ f < 2, loc ≠ .heap 1 (coordCellAddr d hNew c' f)) →
      (loc ∈ w.live ↔ loc ∈ ws.live) ∧ w.vals loc = ws.vals loc) ∧
    (c ≤ d →
      g 6 = (c : ℤ) ∧
      ∀ (c' : ℕ) (hc' : c' < d), c' < c →
        w.read (.heap 1 (coordCellAddr d hNew c' 0)) = (qIns ⟨c', hc'⟩).num ∧
        w.read (.heap 1 (coordCellAddr d hNew c' 1)) = ((qIns ⟨c', hc'⟩).den : ℤ))
  have hInv0 : StepInv 0 ws g2 :=
    ⟨hmod, bg2, by simp [g2, g1, hr1], by simp [g2],
     fun _ _ => ⟨Iff.rfl, rfl⟩,
     fun _ => ⟨by simp [g2, g1], fun _ _ hlt => absurd hlt (Nat.not_lt_zero _)⟩⟩
  have hStep : ∀ c < d, ∀ w g, StepInv c w g →
      ∃ w' g', RegExec inp fd W C_cell C_bit saveInsCoordStepStmt w g w' g' 80 (12 * W * W) ∧
        StepInv (c + 1) w' g' := by
    intro c hc w g ⟨hm, bg, hg1, hg7, hunch, hcd⟩
    obtain ⟨hg6, hprev⟩ := hcd (Nat.le_of_lt hc)
    obtain ⟨ha0_loc, ha0_bl⟩ := coordCellAddr_bl hhNew_lt hc (f := 0) (by decide) hW_addr
    obtain ⟨ha1_loc, ha1_bl⟩ := coordCellAddr_bl hhNew_lt hc (f := 1) (by decide) hW_addr
    have hmul_bl : intBitLength ((hNew * d : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (hNew * d + c) * 2 + 0) (by clear * -; omega)).trans ha0_bl
    have hadd_bl : intBitLength ((hNew * d + c : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (hNew * d + c) * 2 + 0) (by clear * -; omega)).trans ha0_bl
    have hc1_bl : intBitLength ((c + 1 : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := d) (by clear * - hc; omega)).trans hd_bl
    obtain ⟨hqn_bl, hqd_bl, _, _⟩ := ratBitLength_le_of_bounded (hqIns_bnd ⟨c, hc⟩)
    have hqn_W : intBitLength (qIns ⟨c, hc⟩).num ≤ W := hqn_bl.trans (by clear * - hW; omega)
    have hqd_W : intBitLength ((qIns ⟨c, hc⟩).den : ℤ) ≤ W := hqd_bl.trans (by clear * - hW; omega)
    have hget_c : listGetIntD inp.extraRats (c : ℤ) 0 = qIns ⟨c, hc⟩ := by
      simp [hextra, listGetIntD, hc]
    -- 1. `rMul 8 1 7`
    have hm8 : g 1 * g 7 = ((hNew * d : ℕ) : ℤ) := by rw [hg1, hg7]; push_cast; ring
    have t1 := RegExec.mul (inp := inp) hfd_le bg (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 1) (b := 7)
      (by decide) (by decide) (by decide) (by rw [hm8]; exact hmul_bl)
    rw [hm8] at t1; set q1 := Function.update g 8 ((hNew * d : ℕ) : ℤ); have bq1 : RegBounded W q1 := bg.update (r := 8) (by decide) hmul_bl
    -- 2. `rAdd 8 8 6`
    have ha8_1 : q1 8 + q1 6 = ((hNew * d + c : ℕ) : ℤ) := by simp [q1, hg6]
    have t2 := RegExec.add (inp := inp) hfd_le bq1 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 6)
      (by decide) (by decide) (by decide) (by rw [ha8_1]; exact hadd_bl)
    rw [ha8_1] at t2; set q2 := Function.update q1 8 ((hNew * d + c : ℕ) : ℤ); have bq2 : RegBounded W q2 := bq1.update (r := 8) (by decide) hadd_bl
    -- 3. `rAdd 8 8 8`
    have ha8_2 : q2 8 + q2 8 = coordCellAddr d hNew c 0 := by
      simp only [q2, Function.update_self, coordCellAddr]; push_cast; ring
    have t3 := RegExec.add (inp := inp) hfd_le bq2 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 8)
      (by decide) (by decide) (by decide) (by rw [ha8_2]; exact ha0_bl)
    rw [ha8_2] at t3; set q3 := Function.update q2 8 (coordCellAddr d hNew c 0); have bq3 : RegBounded W q3 := bq2.update (r := 8) (by decide) ha0_bl
    -- 4. `rExtraRatNum 9 6`
    have hq3_6 : q3 6 = (c : ℤ) := by simp [q3, q2, q1, hg6]
    have t4 := RegExec.extraRatNum (inp := inp) hfd_le bq3 (sp_ok hm).1 (sp_ok hm).2 (dst := 9) (addr := 6)
      (by decide) (by decide) (by rw [hq3_6, hget_c]; exact hqn_W)
    rw [hq3_6, hget_c] at t4
    set q4 := Function.update q3 9 (qIns ⟨c, hc⟩).num; have bq4 : RegBounded W q4 := bq3.update (r := 9) (by decide) hqn_W
    -- 5. `rStore 1 8 9`
    have hm1 := hm.write (hSub1 c hc 0 (by decide)) (qIns ⟨c, hc⟩).num ha0_loc hqn_W
    have t5 := RegExec.store (inp := inp) hfd_le bq4 (table := 1) (addr := 8) (val := 9) (by decide) (by decide) hn1
      (by simpa [q4, q3] using (sp_ok hm1).1) (by simpa [q4, q3] using (sp_ok hm1).2)
    have hw1 : w.write (.heap 1 (q4 8)) (q4 9) = w.write (.heap 1 (coordCellAddr d hNew c 0)) (qIns ⟨c, hc⟩).num := by simp [q4, q3]
    rw [hw1] at t5; set w1 := w.write (.heap 1 (coordCellAddr d hNew c 0)) (qIns ⟨c, hc⟩).num
    -- 6. `rLit 15 1; rAdd 8 8 15`
    have t6 := RegExec.lit (inp := inp) hfd_le bq4 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 15) (c := 1) (by decide) hl1
    set q5 := Function.update q4 15 1; have bq5 : RegBounded W q5 := bq4.update (r := 15) (by decide) hl1
    have ha8_3 : q5 8 + q5 15 = coordCellAddr d hNew c 1 := by
      simp only [q5, q4, q3, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15),
        Function.update_of_ne (by decide : (8 : ℕ) ≠ 9), coordCellAddr]
      push_cast; ring
    have t7 := RegExec.add (inp := inp) hfd_le bq5 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 8) (a := 8) (b := 15)
      (by decide) (by decide) (by decide) (by rw [ha8_3]; exact ha1_bl)
    rw [ha8_3] at t7; set q6 := Function.update q5 8 (coordCellAddr d hNew c 1); have bq6 : RegBounded W q6 := bq5.update (r := 8) (by decide) ha1_bl
    -- 7. `rExtraRatDen 9 6; rStore 1 8 9; rAdd 6 6 15`
    have hq6_6 : q6 6 = (c : ℤ) := by simp [q6, q5, q4, q3, q2, q1, hg6]
    have t8 := RegExec.extraRatDen (inp := inp) hfd_le bq6 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 9) (addr := 6)
      (by decide) (by decide) (by rw [hq6_6, hget_c]; exact hqd_W)
    rw [hq6_6, hget_c] at t8
    set q7 := Function.update q6 9 ((qIns ⟨c, hc⟩).den : ℤ); have bq7 : RegBounded W q7 := bq6.update (r := 9) (by decide) hqd_W
    have hm2 := hm1.write (hSub1 c hc 1 (by decide)) ((qIns ⟨c, hc⟩).den : ℤ) ha1_loc hqd_W
    have t9 := RegExec.store (inp := inp) hfd_le bq7 (table := 1) (addr := 8) (val := 9) (by decide) (by decide) hn1
      (by simpa [q7, q6] using (sp_ok hm2).1) (by simpa [q7, q6] using (sp_ok hm2).2)
    have hw2 : w1.write (.heap 1 (q7 8)) (q7 9) = w1.write (.heap 1 (coordCellAddr d hNew c 1)) ((qIns ⟨c, hc⟩).den : ℤ) := by simp [q7, q6]
    rw [hw2] at t9; set w2 := w1.write (.heap 1 (coordCellAddr d hNew c 1)) ((qIns ⟨c, hc⟩).den : ℤ)
    have ha6 : q7 6 + q7 15 = ((c + 1 : ℕ) : ℤ) := by
      simp only [q7, q6, q5, Function.update_self,
        Function.update_of_ne (by decide : (6 : ℕ) ≠ 9),
        Function.update_of_ne (by decide : (15 : ℕ) ≠ 9),
        Function.update_of_ne (by decide : (15 : ℕ) ≠ 8), hq6_6]
      push_cast; ring
    have t10 := RegExec.add (inp := inp) hfd_le bq7 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 6) (a := 6) (b := 15)
      (by decide) (by decide) (by decide) (by rw [ha6]; exact hc1_bl)
    rw [ha6] at t10; set q8 := Function.update q7 6 ((c + 1 : ℕ) : ℤ); have bq8 : RegBounded W q8 := bq7.update (r := 6) (by decide) hc1_bl
    have sAll := (t1.seq (t2.seq (t3.seq (t4.seq (t5.seq (t6.seq (t7.seq (t8.seq (t9.seq t10))))))))).weaken
      rfl rfl (u₂ := 80) (b₂ := 12 * W * W) (by clear * -; omega) (by linarith only [hW20, hWW])
    refine ⟨w2, q8, sAll, hm2, bq8, by simp [q8, q7, q6, q5, q4, q3, q2, q1, hg1],
      by simp [q8, q7, q6, q5, q4, q3, q2, q1, hg7], ?_, ?_⟩
    · intro loc hne
      have n0 : loc ≠ .heap 1 (coordCellAddr d hNew c 0) := hne c hc 0 (by decide)
      have n1 : loc ≠ .heap 1 (coordCellAddr d hNew c 1) := hne c hc 1 (by decide)
      have u0 := hunch loc hne
      exact ⟨by simp [w2, w1, WordStore.write, n0, n1, u0.1],
             by simp [w2, w1, WordStore.write, Function.update_of_ne n1, Function.update_of_ne n0, u0.2]⟩
    · intro _
      refine ⟨by simp [q8], fun c' hc' hlt_c1 => ?_⟩
      have hc'_le : c' ≤ c := by clear * - hlt_c1; omega
      rcases eq_or_lt_of_le hc'_le with rfl | hlt
      · have hne01 : (.heap 1 (coordCellAddr d hNew c' 0) : RAMCellLoc) ≠ .heap 1 (coordCellAddr d hNew c' 1) := by
          intro h; injection h with _ ha; exact absurd (coordCellAddr_inj hc (by decide) hc (by decide) ha).2.2 (by decide)
        exact ⟨by simp only [w2, w1]; rw [wordStore_read_write_ne _ hne01]; simp,
               by simp [w2]⟩
      · have hne0 : (.heap 1 (coordCellAddr d hNew c' 0) : RAMCellLoc) ≠ .heap 1 (coordCellAddr d hNew c 0) := by
          intro h; injection h with _ ha; have h_eq := (coordCellAddr_inj hc' (by decide) hc (by decide) ha).2.1; clear * - hlt h_eq; omega
        have hne1 : (.heap 1 (coordCellAddr d hNew c' 0) : RAMCellLoc) ≠ .heap 1 (coordCellAddr d hNew c 1) := by
          intro h; injection h with _ ha; have h_eq := (coordCellAddr_inj hc' (by decide) hc (by decide) ha).2.1; clear * - hlt h_eq; omega
        have hne2 : (.heap 1 (coordCellAddr d hNew c' 1) : RAMCellLoc) ≠ .heap 1 (coordCellAddr d hNew c 0) := by
          intro h; injection h with _ ha; have h_eq := (coordCellAddr_inj hc' (by decide) hc (by decide) ha).2.1; clear * - hlt h_eq; omega
        have hne3 : (.heap 1 (coordCellAddr d hNew c' 1) : RAMCellLoc) ≠ .heap 1 (coordCellAddr d hNew c 1) := by
          intro h; injection h with _ ha; have h_eq := (coordCellAddr_inj hc' (by decide) hc (by decide) ha).2.1; clear * - hlt h_eq; omega
        obtain ⟨hp0, hp1⟩ := hprev c' hc' hlt
        exact ⟨by simp only [w2, w1]; rw [wordStore_read_write_ne _ hne1, wordStore_read_write_ne _ hne0]; exact hp0,
               by simp only [w2, w1]; rw [wordStore_read_write_ne _ hne3, wordStore_read_write_ne _ hne2]; exact hp1⟩
  classical
  let seqP : ∀ n : ℕ, { p : WordStore × (ℕ → ℤ) // StepInv n p.1 p.2 } :=
    Nat.rec ⟨(ws, g2), hInv0⟩ (fun c prev =>
      if hc : c < d then
        let hEx := hStep c hc prev.1.1 prev.1.2 prev.2
        let w' := Classical.choose hEx
        let hEx2 := Classical.choose_spec hEx
        ⟨(w', Classical.choose hEx2), (Classical.choose_spec hEx2).2⟩
      else
        ⟨prev.1, ⟨prev.2.1, prev.2.2.1, prev.2.2.2.1, prev.2.2.2.2.1, prev.2.2.2.2.2.1,
          fun hle => absurd (by clear * - hc hle; omega : c < d) hc⟩⟩)
  have hRep := RegExec.repeatLit (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    d hd_bl (fun i => (seqP i).1.1) (fun i => (seqP i).1.2) bg2
    (body := saveInsCoordStepStmt) (U := 80) (B := 12 * W * W)
    (fun i hi => by
      dsimp only [seqP]
      rw [dif_pos hi]
      exact (Classical.choose_spec (Classical.choose_spec (hStep i hi (seqP i).1.1 (seqP i).1.2 (seqP i).2))).1)
  have hb_tot : 2 * W + 16 + (2 * W + 16 + (d * (12 * W * W) + W)) ≤ (12 * d + 8) * W * W := by
    calc 2 * W + 16 + (2 * W + 16 + (d * (12 * W * W) + W))
      _ = 12 * d * (W * W) + (5 * W + 32) := by ring
      _ ≤ 12 * d * (W * W) + 8 * (W * W) := Nat.add_le_add_left (by linarith only [hW20, hWW]) _
      _ = (12 * d + 8) * W * W := by ring
  have sTot := (p1.seq (p2.seq hRep)).weaken rfl rfl
    (u₂ := 80 * d + 20) (b₂ := (12 * d + 8) * W * W) (by clear * -; omega) hb_tot
  obtain ⟨hmEnd, bgEnd, hg1End, _, hunchEnd, hdEnd⟩ := (seqP d).2
  obtain ⟨_, hreadEnd⟩ := hdEnd le_rfl
  refine ⟨(seqP d).1.1, (seqP d).1.2, sTot, hmEnd, bgEnd, ?_, hg1End, hunchEnd⟩
  refine
    { hS := fun h hh => by
        rcases Finset.mem_insert.mp hh with rfl | hold
        · simp [qMap', hhNew_lt, hqIns_bnd]
        · have hne : h ≠ hNew := fun heq => hhNew_not (heq ▸ hold)
          simp [qMap', hne, hcoords.hS h hold]
      read_num := fun h hh c => by
        rcases Finset.mem_insert.mp hh with rfl | hold
        · simp only [qMap', ↓reduceIte]
          exact (hreadEnd c.val c.isLt c.isLt).1
        · have hne : h ≠ hNew := fun heq => hhNew_not (heq ▸ hold)
          simp only [qMap', if_neg hne]
          have hloc_ne : ∀ c' < d, ∀ f < 2,
              (.heap 1 (coordCellAddr d h c.val 0) : RAMCellLoc) ≠ .heap 1 (coordCellAddr d hNew c' f) := by
            intro c' hc' f hf h_eq
            injection h_eq with _ ha
            exact hne (coordCellAddr_inj c.isLt (by decide) hc' hf ha).1
          rw [wordStore_read_eq_vals hmEnd.wf, (hunchEnd _ hloc_ne).2, ← wordStore_read_eq_vals hmod.wf]
          exact hcoords.read_num h hold c
      read_den := fun h hh c => by
        rcases Finset.mem_insert.mp hh with rfl | hold
        · simp only [qMap', ↓reduceIte]
          exact (hreadEnd c.val c.isLt c.isLt).2
        · have hne : h ≠ hNew := fun heq => hhNew_not (heq ▸ hold)
          simp only [qMap', if_neg hne]
          have hloc_ne : ∀ c' < d, ∀ f < 2,
              (.heap 1 (coordCellAddr d h c.val 1) : RAMCellLoc) ≠ .heap 1 (coordCellAddr d hNew c' f) := by
            intro c' hc' f hf h_eq
            injection h_eq with _ ha
            exact hne (coordCellAddr_inj c.isLt (by decide) hc' hf ha).1
          rw [wordStore_read_eq_vals hmEnd.wf, (hunchEnd _ hloc_ne).2, ← wordStore_read_eq_vals hmod.wf]
          exact hcoords.read_den h hold c }

theorem ActiveCoordsStored.empty (d L B : ℕ) (qMap : ℕ → Fin d → ℚ) (ws : WordStore) :
    ActiveCoordsStored d L B ∅ qMap ws :=
  { hS := fun _ h => by simp at h
    read_num := fun _ h => by simp at h
    read_den := fun _ h => by simp at h }

/-- Loop step freeing `heap 1 (coordCellAddr d delH c 0/1)`, where `r1 = delH`, `r6 = c`, `r7 = d`. -/
def freeDelCoordStepStmt : BitRAMStmt :=
  .seq (rMul 8 1 7)
  (.seq (rAdd 8 8 6)
  (.seq (rAdd 8 8 8)
  (.seq (rFree 1 8)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
  (.seq (rFree 1 8)
        (rAdd 6 6 15)))))))

def freeDelPointRegs (d : ℕ) : BitRAMStmt :=
  .seq (rLit 6 0)
  (.seq (rLit 7 (d : ℤ))
        (.repeatN (.lit (d : ℤ)) freeDelCoordStepStmt))

theorem exec_freeDelPointRegs {d : ℕ} (_hd1 : 1 ≤ d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L B delH : ℕ} (hdelH_lt : delH < 2 ^ L)
    (hW : natBitLength d + L + 20 ≤ W)
    {S : Finset ℕ} {qMap : ℕ → Fin d → ℚ}
    (hcoords : ActiveCoordsStored d L B S qMap ws)
    (hSub1 : ∀ c < d, ∀ f < 2, (.heap 1 (coordCellAddr d delH c f) : RAMCellLoc) ∈ S_write)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr1 : regs 1 = (delH : ℤ)) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (freeDelPointRegs d) ws regs wsEnd regsEnd
        (64 * d + 20) ((8 * d + 8) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      ActiveCoordsStored d L B (S.erase delH) qMap wsEnd ∧
      regsEnd 1 = (delH : ℤ) ∧
      (∀ c < d, ∀ f < 2, (.heap 1 (coordCellAddr d delH c f) : RAMCellLoc) ∉ wsEnd.live) ∧
      (∀ loc : RAMCellLoc, (∀ c < d, ∀ f < 2, loc ≠ .heap 1 (coordCellAddr d delH c f)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hWW : 20 * W ≤ W * W := by nlinarith only [hW20]
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by clear * - hW20; omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by clear * - hW20; omega)
  have hn1 : natBitLength 1 ≤ W := (show natBitLength 1 = 1 from by decide).trans_le (by clear * - hW20; omega)
  have hd_bl : intBitLength (d : ℤ) ≤ W := (intBitLength_ofNat_le d).trans (by clear * - hW; omega)
  have hW_addr : natBitLength d + L + 12 ≤ W := by clear * - hW; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have p1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 6) (c := 0) (by decide) hl0
  set g1 := Function.update regs 6 0; have bg1 : RegBounded W g1 := hbnd.update (r := 6) (by decide) hl0
  have p2 := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 7) (c := (d : ℤ)) (by decide) hd_bl
  set g2 := Function.update g1 7 (d : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 7) (by decide) hd_bl
  let StepInv (c : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
    ModifiedOnBounded ws₀ S_write W w ∧
    RegBounded W g ∧
    g 1 = (delH : ℤ) ∧ g 7 = (d : ℤ) ∧
    (∀ loc : RAMCellLoc, (∀ c' < d, ∀ f < 2, loc ≠ .heap 1 (coordCellAddr d delH c' f)) →
      (loc ∈ w.live ↔ loc ∈ ws.live) ∧ w.vals loc = ws.vals loc) ∧
    (c ≤ d →
      g 6 = (c : ℤ) ∧
      ∀ (c' : ℕ), c' < d → c' < c → ∀ f < 2,
        (.heap 1 (coordCellAddr d delH c' f) : RAMCellLoc) ∉ w.live)
  have hInv0 : StepInv 0 ws g2 :=
    ⟨hmod, bg2, by simp [g2, g1, hr1], by simp [g2],
     fun _ _ => ⟨Iff.rfl, rfl⟩,
     fun _ => ⟨by simp [g2, g1], fun _ _ hlt _ _ => absurd hlt (Nat.not_lt_zero _)⟩⟩
  have hStep : ∀ c < d, ∀ w g, StepInv c w g →
      ∃ w' g', RegExec inp fd W C_cell C_bit freeDelCoordStepStmt w g w' g' 64 (8 * W * W) ∧
        StepInv (c + 1) w' g' := by
    intro c hc w g ⟨hm, bg, hg1, hg7, hunch, hcd⟩
    obtain ⟨hg6, hprev⟩ := hcd (Nat.le_of_lt hc)
    obtain ⟨_, ha0_bl⟩ := coordCellAddr_bl hdelH_lt hc (f := 0) (by decide) hW_addr
    obtain ⟨_, ha1_bl⟩ := coordCellAddr_bl hdelH_lt hc (f := 1) (by decide) hW_addr
    have hmul_bl : intBitLength ((delH * d : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (delH * d + c) * 2 + 0) (by clear * -; omega)).trans ha0_bl
    have hadd_bl : intBitLength ((delH * d + c : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (delH * d + c) * 2 + 0) (by clear * -; omega)).trans ha0_bl
    have hc1_bl : intBitLength ((c + 1 : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := d) (by clear * - hc; omega)).trans hd_bl
    have hm8 : g 1 * g 7 = ((delH * d : ℕ) : ℤ) := by rw [hg1, hg7]; push_cast; ring
    have t1 := RegExec.mul (inp := inp) hfd_le bg (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 1) (b := 7)
      (by decide) (by decide) (by decide) (by rw [hm8]; exact hmul_bl)
    rw [hm8] at t1; set q1 := Function.update g 8 ((delH * d : ℕ) : ℤ); have bq1 : RegBounded W q1 := bg.update (r := 8) (by decide) hmul_bl
    have ha8_1 : q1 8 + q1 6 = ((delH * d + c : ℕ) : ℤ) := by simp [q1, hg6]
    have t2 := RegExec.add (inp := inp) hfd_le bq1 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 6)
      (by decide) (by decide) (by decide) (by rw [ha8_1]; exact hadd_bl)
    rw [ha8_1] at t2; set q2 := Function.update q1 8 ((delH * d + c : ℕ) : ℤ); have bq2 : RegBounded W q2 := bq1.update (r := 8) (by decide) hadd_bl
    have ha8_2 : q2 8 + q2 8 = coordCellAddr d delH c 0 := by
      simp only [q2, Function.update_self, coordCellAddr]; push_cast; ring
    have t3 := RegExec.add (inp := inp) hfd_le bq2 (sp_ok hm).1 (sp_ok hm).2 (dst := 8) (a := 8) (b := 8)
      (by decide) (by decide) (by decide) (by rw [ha8_2]; exact ha0_bl)
    rw [ha8_2] at t3; set q3 := Function.update q2 8 (coordCellAddr d delH c 0); have bq3 : RegBounded W q3 := bq2.update (r := 8) (by decide) ha0_bl
    have t4 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := w) bq3 (table := 1) (addr := 8) (by decide) hn1
    have hw1 : w.free (.heap 1 (q3 8)) = w.free (.heap 1 (coordCellAddr d delH c 0)) := by simp [q3]
    rw [hw1] at t4; set w1 := w.free (.heap 1 (coordCellAddr d delH c 0))
    have hm1 := hm.free (hSub1 c hc 0 (by decide))
    have t5 := RegExec.lit (inp := inp) hfd_le bq3 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 15) (c := 1) (by decide) hl1
    set q4 := Function.update q3 15 1; have bq4 : RegBounded W q4 := bq3.update (r := 15) (by decide) hl1
    have ha8_3 : q4 8 + q4 15 = coordCellAddr d delH c 1 := by
      simp only [q4, q3, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), coordCellAddr]
      push_cast; ring
    have t6 := RegExec.add (inp := inp) hfd_le bq4 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 8) (a := 8) (b := 15)
      (by decide) (by decide) (by decide) (by rw [ha8_3]; exact ha1_bl)
    rw [ha8_3] at t6; set q5 := Function.update q4 8 (coordCellAddr d delH c 1); have bq5 : RegBounded W q5 := bq4.update (r := 8) (by decide) ha1_bl
    have t7 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := w1) bq5 (table := 1) (addr := 8) (by decide) hn1
    have hw2 : w1.free (.heap 1 (q5 8)) = w1.free (.heap 1 (coordCellAddr d delH c 1)) := by simp [q5]
    rw [hw2] at t7; set w2 := w1.free (.heap 1 (coordCellAddr d delH c 1))
    have hm2 := hm1.free (hSub1 c hc 1 (by decide))
    have hq5_6 : q5 6 = (c : ℤ) := by simp [q5, q4, q3, q2, q1, hg6]
    have ha6 : q5 6 + q5 15 = ((c + 1 : ℕ) : ℤ) := by
      simp only [q5, q4, Function.update_self, Function.update_of_ne (by decide : (15 : ℕ) ≠ 8), hq5_6]
      push_cast; ring
    have t8 := RegExec.add (inp := inp) hfd_le bq5 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 6) (a := 6) (b := 15)
      (by decide) (by decide) (by decide) (by rw [ha6]; exact hc1_bl)
    rw [ha6] at t8; set q6 := Function.update q5 6 ((c + 1 : ℕ) : ℤ); have bq6 : RegBounded W q6 := bq5.update (r := 6) (by decide) hc1_bl
    have sAll := (t1.seq (t2.seq (t3.seq (t4.seq (t5.seq (t6.seq (t7.seq t8))))))).weaken
      rfl rfl (u₂ := 64) (b₂ := 8 * W * W) (by clear * -; omega) (by linarith only [hW20, hWW])
    refine ⟨w2, q6, sAll, hm2, bq6, by simp [q6, q5, q4, q3, q2, q1, hg1],
      by simp [q6, q5, q4, q3, q2, q1, hg7], ?_, ?_⟩
    · intro loc hne
      have n0 : loc ≠ .heap 1 (coordCellAddr d delH c 0) := hne c hc 0 (by decide)
      have n1 : loc ≠ .heap 1 (coordCellAddr d delH c 1) := hne c hc 1 (by decide)
      have u0 := hunch loc hne
      exact ⟨by simp [w2, w1, WordStore.free, n0, n1, u0.1],
             by simp [w2, w1, WordStore.free, Function.update_of_ne n1, Function.update_of_ne n0, u0.2]⟩
    · intro _
      refine ⟨by simp [q6], fun c' hc' hlt_c1 f hf => ?_⟩
      have hc'_le : c' ≤ c := by clear * - hlt_c1; omega
      rcases eq_or_lt_of_le hc'_le with rfl | hlt
      · have hf_cases : f = 0 ∨ f = 1 := by clear * - hf; omega
        rcases hf_cases with rfl | rfl <;> simp [w2, w1, WordStore.free]
      · have hn_old := hprev c' hc' hlt f hf
        simp [w2, w1, WordStore.free, hn_old]
  classical
  let seqP : ∀ n : ℕ, { p : WordStore × (ℕ → ℤ) // StepInv n p.1 p.2 } :=
    Nat.rec ⟨(ws, g2), hInv0⟩ (fun c prev =>
      if hc : c < d then
        let hEx := hStep c hc prev.1.1 prev.1.2 prev.2
        let w' := Classical.choose hEx
        let hEx2 := Classical.choose_spec hEx
        ⟨(w', Classical.choose hEx2), (Classical.choose_spec hEx2).2⟩
      else
        ⟨prev.1, ⟨prev.2.1, prev.2.2.1, prev.2.2.2.1, prev.2.2.2.2.1, prev.2.2.2.2.2.1,
          fun hle => absurd (by clear * - hc hle; omega : c < d) hc⟩⟩)
  have hRep := RegExec.repeatLit (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    d hd_bl (fun i => (seqP i).1.1) (fun i => (seqP i).1.2) bg2
    (body := freeDelCoordStepStmt) (U := 64) (B := 8 * W * W)
    (fun i hi => by
      dsimp only [seqP]
      rw [dif_pos hi]
      exact (Classical.choose_spec (Classical.choose_spec (hStep i hi (seqP i).1.1 (seqP i).1.2 (seqP i).2))).1)
  have hb_tot : 2 * W + 16 + (2 * W + 16 + (d * (8 * W * W) + W)) ≤ (8 * d + 8) * W * W := by
    calc 2 * W + 16 + (2 * W + 16 + (d * (8 * W * W) + W))
      _ = 8 * d * (W * W) + (5 * W + 32) := by ring
      _ ≤ 8 * d * (W * W) + 8 * (W * W) := Nat.add_le_add_left (by linarith only [hW20, hWW]) _
      _ = (8 * d + 8) * W * W := by ring
  have sTot := (p1.seq (p2.seq hRep)).weaken rfl rfl
    (u₂ := 64 * d + 20) (b₂ := (8 * d + 8) * W * W) (by clear * -; omega) hb_tot
  obtain ⟨hmEnd, bgEnd, hg1End, _, hunchEnd, hdEnd⟩ := (seqP d).2
  obtain ⟨_, hfreeEnd⟩ := hdEnd le_rfl
  refine ⟨(seqP d).1.1, (seqP d).1.2, sTot, hmEnd, bgEnd, ?_, hg1End,
    fun c hc f hf => hfreeEnd c hc hc f hf, hunchEnd⟩
  refine
    { hS := fun h hh => hcoords.hS h (Finset.mem_of_mem_erase hh)
      read_num := fun h hh c => by
        rcases Finset.mem_erase.mp hh with ⟨hne, hold⟩
        have hloc_ne : ∀ c' < d, ∀ f < 2,
            (.heap 1 (coordCellAddr d h c.val 0) : RAMCellLoc) ≠ .heap 1 (coordCellAddr d delH c' f) := by
          intro c' hc' f hf h_eq
          injection h_eq with _ ha
          exact hne (coordCellAddr_inj c.isLt (by decide) hc' hf ha).1
        rw [wordStore_read_eq_vals hmEnd.wf, (hunchEnd _ hloc_ne).2, ← wordStore_read_eq_vals hmod.wf]
        exact hcoords.read_num h hold c
      read_den := fun h hh c => by
        rcases Finset.mem_erase.mp hh with ⟨hne, hold⟩
        have hloc_ne : ∀ c' < d, ∀ f < 2,
            (.heap 1 (coordCellAddr d h c.val 1) : RAMCellLoc) ≠ .heap 1 (coordCellAddr d delH c' f) := by
          intro c' hc' f hf h_eq
          injection h_eq with _ ha
          exact hne (coordCellAddr_inj c.isLt (by decide) hc' hf ha).1
        rw [wordStore_read_eq_vals hmEnd.wf, (hunchEnd _ hloc_ne).2, ← wordStore_read_eq_vals hmod.wf]
        exact hcoords.read_den h hold c }


/-! ### 3. Pure Register Squared-Difference Accumulator `accumSqDiffRegs` and `sqDistHandlesRegs` -/

/-- Updates `(r3, r4)` by one step of `ratSumPairs sqNum sqDen` given `(pNum, pDen) = (r9, r10)`
and `(qNum, qDen) = (r11, r12)`, using only scratch `r13, r14, r15` (preserving `r0..r8` except `r3, r4`). -/
def accumSqDiffRegs : BitRAMStmt :=
  .seq (rMul 13 9 12)
  (.seq (rMul 14 11 10)
  (.seq (rSub 13 13 14)
  (.seq (rMul 13 13 13)
  (.seq (rMul 14 10 12)
  (.seq (rMul 14 14 14)
  (.seq (rMul 15 3 14)
  (.seq (rMul 13 13 4)
  (.seq (rAdd 3 15 13)
        (rMul 4 4 14)))))))))

theorem exec_accumSqDiffRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws : WordStore}
    (hcCeil : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit)
    {pNum pDen qNum qDen : ℕ → ℤ} {B_p B_q c : ℕ}
    (hBp : 1 ≤ B_p) (hBq : 1 ≤ B_q) (hc : c < d)
    (hW : d * (2 * (B_p + B_q) + 3) + 20 ≤ W)
    (hpN : intBitLength (pNum c) ≤ B_p) (hpD : intBitLength (pDen c) ≤ B_p)
    (hqN : intBitLength (qNum c) ≤ B_q) (hqD : intBitLength (qDen c) ≤ B_q)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr9 : regs 9 = pNum c) (hr10 : regs 10 = pDen c)
    (hr11 : regs 11 = qNum c) (hr12 : regs 12 = qDen c)
    (hr3 : regs 3 = (ratSumPairs
      (fun i => (pNum i * qDen i - qNum i * pDen i) * (pNum i * qDen i - qNum i * pDen i))
      (fun i => (pDen i * qDen i) * (pDen i * qDen i)) c).1)
    (hr4 : regs 4 = (ratSumPairs
      (fun i => (pNum i * qDen i - qNum i * pDen i) * (pNum i * qDen i - qNum i * pDen i))
      (fun i => (pDen i * qDen i) * (pDen i * qDen i)) c).2)
    (hp1_bl : intBitLength (regs 3) ≤ c * (2 * (B_p + B_q) + 3) + 2)
    (hp2_bl : intBitLength (regs 4) ≤ c * (2 * (B_p + B_q) + 2) + 2) :
    let sqNum := fun i => (pNum i * qDen i - qNum i * pDen i) * (pNum i * qDen i - qNum i * pDen i)
    let sqDen := fun i => (pDen i * qDen i) * (pDen i * qDen i)
    ∃ regs',
      RegExec inp fd W C_cell C_bit accumSqDiffRegs ws regs ws regs' 80 (36 * W * W) ∧
      RegBounded W regs' ∧
      regs' 3 = (ratSumPairs sqNum sqDen (c + 1)).1 ∧
      regs' 4 = (ratSumPairs sqNum sqDen (c + 1)).2 ∧
      intBitLength (regs' 3) ≤ (c + 1) * (2 * (B_p + B_q) + 3) + 2 ∧
      intBitLength (regs' 4) ≤ (c + 1) * (2 * (B_p + B_q) + 2) + 2 ∧
      (∀ r < 9, r ≠ 3 → r ≠ 4 → regs' r = regs r) := by
  intro sqNum sqDen
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hWW : 20 * W ≤ W * W := by nlinarith only [hW20]
  set B_t := 2 * (B_p + B_q) + 2
  have hBt1_W : (c + 1) * (B_t + 1) + 2 ≤ W := by
    have hm : (c + 1) * (B_t + 1) ≤ d * (B_t + 1) := Nat.mul_le_mul_right _ (by clear * - hc; omega)
    have heq : B_t + 1 = 2 * (B_p + B_q) + 3 := rfl
    rw [heq] at hm ⊢
    clear * - hm hW; omega
  have hBt_W : B_t ≤ W := by
    have h1 : B_t ≤ 1 * (B_t + 1) + 2 := by clear * -; omega
    have h2 : 1 * (B_t + 1) + 2 ≤ (c + 1) * (B_t + 1) + 2 :=
      Nat.add_le_add_right (Nat.mul_le_mul_right _ (by clear * -; omega)) 2
    exact h1.trans (h2.trans hBt1_W)
  have hBpq_W : B_p + B_q + 2 ≤ W := by
    dsimp [B_t] at hBt_W
    clear * - hBt_W; omega
  -- 1. `rMul 13 9 12` (`pNum * qDen`)
  have b_v1 : intBitLength (pNum c * qDen c) ≤ B_p + B_q :=
    (intBitLength_mul_le _ _).trans (Nat.add_le_add hpN hqD)
  have s1 := RegExec.mul (inp := inp) hfd_le hbnd hcCeil hbCeil (dst := 13) (a := 9) (b := 12)
    (by decide) (by decide) (by decide) (by rw [hr9, hr12]; exact b_v1.trans (by clear * - hBpq_W; omega))
  rw [hr9, hr12] at s1
  set g1 := Function.update regs 13 (pNum c * qDen c)
  have bg1 : RegBounded W g1 := hbnd.update (r := 13) (by decide) (b_v1.trans (by clear * - hBpq_W; omega))
  -- 2. `rMul 14 11 10` (`qNum * pDen`)
  have b_v2 : intBitLength (qNum c * pDen c) ≤ B_p + B_q := by
    have h := (intBitLength_mul_le (qNum c) (pDen c)).trans (Nat.add_le_add hqN hpD)
    clear * - h; omega
  have hg1_11 : g1 11 = qNum c := by simp [g1, hr11]
  have hg1_10 : g1 10 = pDen c := by simp [g1, hr10]
  have s2 := RegExec.mul (inp := inp) hfd_le bg1 hcCeil hbCeil (dst := 14) (a := 11) (b := 10)
    (by decide) (by decide) (by decide) (by rw [hg1_11, hg1_10]; exact b_v2.trans (by clear * - hBpq_W; omega))
  rw [hg1_11, hg1_10] at s2
  set g2 := Function.update g1 14 (qNum c * pDen c)
  have bg2 : RegBounded W g2 := bg1.update (r := 14) (by decide) (b_v2.trans (by clear * - hBpq_W; omega))
  -- 3. `rSub 13 13 14` (`diff`)
  set diff := pNum c * qDen c - qNum c * pDen c
  have b_diff : intBitLength diff ≤ B_p + B_q + 1 := by
    have h := intBitLength_sub_le_max (pNum c * qDen c) (qNum c * pDen c)
    have hm : max (intBitLength (pNum c * qDen c)) (intBitLength (qNum c * pDen c)) ≤ B_p + B_q :=
      max_le b_v1 b_v2
    dsimp [diff]; clear * - h hm; omega
  have hg2_sub : g2 13 - g2 14 = diff := by simp [g2, g1, diff]
  have s3 := RegExec.sub (inp := inp) hfd_le bg2 hcCeil hbCeil (dst := 13) (a := 13) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hg2_sub]; exact b_diff.trans (by clear * - hBpq_W; omega))
  rw [hg2_sub] at s3
  set g3 := Function.update g2 13 diff
  have bg3 : RegBounded W g3 := bg2.update (r := 13) (by decide) (b_diff.trans (by clear * - hBpq_W; omega))
  -- 4. `rMul 13 13 13` (`sqNum c`)
  have b_sqN : intBitLength (sqNum c) ≤ B_t := by
    have h := (intBitLength_mul_le diff diff).trans (Nat.add_le_add b_diff b_diff)
    dsimp [sqNum, diff, B_t] at h ⊢; clear * - h; omega
  have hg3_mul : g3 13 * g3 13 = sqNum c := by simp [g3, sqNum, diff]
  have s4 := RegExec.mul (inp := inp) hfd_le bg3 hcCeil hbCeil (dst := 13) (a := 13) (b := 13)
    (by decide) (by decide) (by decide) (by rw [hg3_mul]; exact b_sqN.trans hBt_W)
  rw [hg3_mul] at s4
  set g4 := Function.update g3 13 (sqNum c)
  have bg4 : RegBounded W g4 := bg3.update (r := 13) (by decide) (b_sqN.trans hBt_W)
  -- 5. `rMul 14 10 12` (`pDen * qDen`)
  set prodD := pDen c * qDen c
  have b_pD : intBitLength prodD ≤ B_p + B_q :=
    (intBitLength_mul_le _ _).trans (Nat.add_le_add hpD hqD)
  have hg4_pd : g4 10 * g4 12 = prodD := by simp [g4, g3, g2, g1, hr10, hr12, prodD]
  have s5 := RegExec.mul (inp := inp) hfd_le bg4 hcCeil hbCeil (dst := 14) (a := 10) (b := 12)
    (by decide) (by decide) (by decide) (by rw [hg4_pd]; exact b_pD.trans (by clear * - hBpq_W; omega))
  rw [hg4_pd] at s5
  set g5 := Function.update g4 14 prodD
  have bg5 : RegBounded W g5 := bg4.update (r := 14) (by decide) (b_pD.trans (by clear * - hBpq_W; omega))
  -- 6. `rMul 14 14 14` (`sqDen c`)
  have b_sqD : intBitLength (sqDen c) ≤ B_t := by
    have h := (intBitLength_mul_le prodD prodD).trans (Nat.add_le_add b_pD b_pD)
    dsimp [sqDen, prodD, B_t] at h ⊢; clear * - h; omega
  have hg5_mul : g5 14 * g5 14 = sqDen c := by simp [g5, sqDen, prodD]
  have s6 := RegExec.mul (inp := inp) hfd_le bg5 hcCeil hbCeil (dst := 14) (a := 14) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hg5_mul]; exact b_sqD.trans hBt_W)
  rw [hg5_mul] at s6
  set g6 := Function.update g5 14 (sqDen c)
  have bg6 : RegBounded W g6 := bg5.update (r := 14) (by decide) (b_sqD.trans hBt_W)
  -- 7. `rMul 15 3 14` (`p.1 * sqDen c`)
  set p := ratSumPairs sqNum sqDen c
  have hp1_c : intBitLength p.1 ≤ c * (B_t + 1) + 2 := by rw [← hr3]; exact hp1_bl
  have hp2_c : intBitLength p.2 ≤ c * B_t + 2 := by rw [← hr4]; exact hp2_bl
  have b_m1 : intBitLength (p.1 * sqDen c) ≤ c * (B_t + 1) + 2 + B_t :=
    (intBitLength_mul_le _ _).trans (Nat.add_le_add hp1_c b_sqD)
  have hm1_W : intBitLength (p.1 * sqDen c) ≤ W := by
    have heq : (c + 1) * (B_t + 1) + 2 = c * (B_t + 1) + 2 + B_t + 1 := by ring
    clear * - b_m1 heq hBt1_W; omega
  have hg6_m1 : g6 3 * g6 14 = p.1 * sqDen c := by simp [g6, g5, g4, g3, g2, g1, hr3, p]
  have s7 := RegExec.mul (inp := inp) hfd_le bg6 hcCeil hbCeil (dst := 15) (a := 3) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hg6_m1]; exact hm1_W)
  rw [hg6_m1] at s7
  set g7 := Function.update g6 15 (p.1 * sqDen c)
  have bg7 : RegBounded W g7 := bg6.update (r := 15) (by decide) hm1_W
  -- 8. `rMul 13 13 4` (`sqNum c * p.2`)
  have b_m2 : intBitLength (sqNum c * p.2) ≤ c * (B_t + 1) + 2 + B_t := by
    have h := (intBitLength_mul_le (sqNum c) p.2).trans (Nat.add_le_add b_sqN hp2_c)
    have hle : B_t + (c * B_t + 2) ≤ c * (B_t + 1) + 2 + B_t := by
      have : c * B_t ≤ c * (B_t + 1) := Nat.mul_le_mul_left c (Nat.le_succ _)
      clear * - this; omega
    exact h.trans hle
  have hm2_W : intBitLength (sqNum c * p.2) ≤ W := by
    have heq : (c + 1) * (B_t + 1) + 2 = c * (B_t + 1) + 2 + B_t + 1 := by ring
    clear * - b_m2 heq hBt1_W; omega
  have hg7_m2 : g7 13 * g7 4 = sqNum c * p.2 := by simp [g7, g6, g5, g4, g3, g2, g1, hr4, p]
  have s8 := RegExec.mul (inp := inp) hfd_le bg7 hcCeil hbCeil (dst := 13) (a := 13) (b := 4)
    (by decide) (by decide) (by decide) (by rw [hg7_m2]; exact hm2_W)
  rw [hg7_m2] at s8
  set g8 := Function.update g7 13 (sqNum c * p.2)
  have bg8 : RegBounded W g8 := bg7.update (r := 13) (by decide) hm2_W
  -- 9. `rAdd 3 15 13` (`(ratSumPairs sqNum sqDen (c + 1)).1`)
  have b_new1 : intBitLength (p.1 * sqDen c + sqNum c * p.2) ≤ (c + 1) * (B_t + 1) + 2 := by
    have ha := intBitLength_add_le_max (p.1 * sqDen c) (sqNum c * p.2)
    have hm := max_le b_m1 b_m2
    have heq : (c + 1) * (B_t + 1) + 2 = c * (B_t + 1) + 2 + B_t + 1 := by ring
    clear * - ha hm heq; omega
  have hg8_add : g8 15 + g8 13 = (ratSumPairs sqNum sqDen (c + 1)).1 := by
    simp [g8, g7, ratSumPairs, p]
  have s9 := RegExec.add (inp := inp) hfd_le bg8 hcCeil hbCeil (dst := 3) (a := 15) (b := 13)
    (by decide) (by decide) (by decide) (by rw [hg8_add]; exact b_new1.trans hBt1_W)
  rw [hg8_add] at s9
  set g9 := Function.update g8 3 (ratSumPairs sqNum sqDen (c + 1)).1
  have bg9 : RegBounded W g9 := bg8.update (r := 3) (by decide) (b_new1.trans hBt1_W)
  -- 10. `rMul 4 4 14` (`(ratSumPairs sqNum sqDen (c + 1)).2`)
  have b_new2 : intBitLength (p.2 * sqDen c) ≤ (c + 1) * B_t + 2 := by
    have hm := (intBitLength_mul_le p.2 (sqDen c)).trans (Nat.add_le_add hp2_c b_sqD)
    have heq : (c + 1) * B_t + 2 = c * B_t + 2 + B_t := by ring
    clear * - hm heq; omega
  have hb_new2_W : intBitLength (p.2 * sqDen c) ≤ W := by
    have : (c + 1) * B_t + 2 ≤ (c + 1) * (B_t + 1) + 2 :=
      Nat.add_le_add_right (Nat.mul_le_mul_left _ (Nat.le_succ _)) 2
    exact b_new2.trans (this.trans hBt1_W)
  have hg9_m4 : g9 4 * g9 14 = (ratSumPairs sqNum sqDen (c + 1)).2 := by
    simp [g9, g8, g7, g6, g5, g4, g3, g2, g1, hr4, ratSumPairs, p]
  have s10 := RegExec.mul (inp := inp) hfd_le bg9 hcCeil hbCeil (dst := 4) (a := 4) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hg9_m4]; exact hb_new2_W)
  rw [hg9_m4] at s10
  set g10 := Function.update g9 4 (ratSumPairs sqNum sqDen (c + 1)).2
  have bg10 : RegBounded W g10 := bg9.update (r := 4) (by decide) hb_new2_W
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq s10))))))))).weaken
    rfl rfl (u₂ := 80) (b₂ := 36 * W * W) (by clear * -; omega) (by nlinarith only [hW20])
  refine ⟨g10, sTot, bg10, by simp [g10, g9], by simp [g10], ?_, ?_, ?_⟩
  · simp only [g10, g9, Function.update_of_ne (by decide : (3 : ℕ) ≠ 4), Function.update_self]
    exact b_new1
  · simp only [g10, Function.update_self]
    exact b_new2
  · intro r hr9_lt hne3 hne4
    have n13 : r ≠ 13 := by clear * - hr9_lt; omega
    have n14 : r ≠ 14 := by clear * - hr9_lt; omega
    have n15 : r ≠ 15 := by clear * - hr9_lt; omega
    simp [g10, g9, g8, g7, g6, g5, g4, g3, g2, g1, hne3, hne4, n13, n14, n15]

/-- Loop body for `sqDistHandlesRegs`: `r1 = h₁`, `r2 = h₂`, `r6 = c`, `r7 = d`, `(r3, r4)` accum. -/
def sqDistCoordStepStmt : BitRAMStmt :=
  .seq (rMul 8 1 7)
  (.seq (rAdd 8 8 6)
  (.seq (rAdd 8 8 8)
  (.seq (rLoad 9 1 8)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
  (.seq (rLoad 10 1 8)
  (.seq (rMul 8 2 7)
  (.seq (rAdd 8 8 6)
  (.seq (rAdd 8 8 8)
  (.seq (rLoad 11 1 8)
  (.seq (rLit 15 1)
  (.seq (rAdd 8 8 15)
  (.seq (rLoad 12 1 8)
  (.seq accumSqDiffRegs
  (.seq (rLit 15 1)
        (rAdd 6 6 15))))))))))))))))

def sqDistHandlesRegs (d : ℕ) : BitRAMStmt :=
  .seq (rLit 3 0)
  (.seq (rLit 4 1)
  (.seq (rLit 6 0)
  (.seq (rLit 7 (d : ℤ))
        (.repeatN (.lit (d : ℤ)) sqDistCoordStepStmt))))

theorem exec_sqDistHandlesRegs {d : ℕ} (hd1 : 1 ≤ d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws : WordStore}
    (hcCeil : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit)
    {L B h₁ h₂ : ℕ} (hB1 : 1 ≤ B)
    (hW : d * (4 * B + 12) + natBitLength d + L + 24 ≤ W)
    {S : Finset ℕ} {qMap : ℕ → Fin d → ℚ}
    (hcoords : ActiveCoordsStored d L B S qMap ws)
    (hh₁ : h₁ ∈ S) (hh₂ : h₂ ∈ S)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr1 : regs 1 = (h₁ : ℤ)) (hr2 : regs 2 = (h₂ : ℤ)) :
    ∃ regsEnd,
      RegExec inp fd W C_cell C_bit (sqDistHandlesRegs d) ws regs ws regsEnd
        (220 * d + 32) ((52 * d + 12) * W * W) ∧
      RegBounded W regsEnd ∧
      regsEnd 0 = regs 0 ∧ regsEnd 1 = (h₁ : ℤ) ∧ regsEnd 2 = (h₂ : ℤ) ∧ regsEnd 5 = regs 5 ∧
      1 ≤ regsEnd 4 ∧ 0 ≤ regsEnd 3 ∧
      ((regsEnd 3 : ℝ) / (regsEnd 4 : ℝ)) =
        ‖ratPointToEuclidean (qMap h₁) - ratPointToEuclidean (qMap h₂)‖ ^ 2 ∧
      intBitLength (regsEnd 3) ≤ d * (4 * B + 11) + 2 ∧
      intBitLength (regsEnd 4) ≤ d * (4 * B + 10) + 2 := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hWW : 20 * W ≤ W * W := by nlinarith only [hW20]
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by clear * - hW20; omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by clear * - hW20; omega)
  have hn1 : natBitLength 1 ≤ W := (show natBitLength 1 = 1 from by decide).trans_le (by clear * - hW20; omega)
  have hd_bl : intBitLength (d : ℤ) ≤ W := (intBitLength_ofNat_le d).trans (by clear * - hW; omega)
  have hW_addr : natBitLength d + L + 12 ≤ W := by clear * - hW; omega
  obtain ⟨hh₁_lt, hq₁_bnd⟩ := hcoords.hS h₁ hh₁
  obtain ⟨hh₂_lt, hq₂_bnd⟩ := hcoords.hS h₂ hh₂
  let pNum : ℕ → ℤ := fun c => if hc : c < d then (qMap h₁ ⟨c, hc⟩).num else 0
  let pDen : ℕ → ℤ := fun c => if hc : c < d then ((qMap h₁ ⟨c, hc⟩).den : ℤ) else 1
  let qNum : ℕ → ℤ := fun c => if hc : c < d then (qMap h₂ ⟨c, hc⟩).num else 0
  let qDen : ℕ → ℤ := fun c => if hc : c < d then ((qMap h₂ ⟨c, hc⟩).den : ℤ) else 1
  let sqNum := fun i => (pNum i * qDen i - qNum i * pDen i) * (pNum i * qDen i - qNum i * pDen i)
  let sqDen := fun i => (pDen i * qDen i) * (pDen i * qDen i)
  have hp1 := RegExec.lit (inp := inp) hfd_le hbnd hcCeil hbCeil (dst := 3) (c := 0) (by decide) hl0
  set g1 := Function.update regs 3 0; have bg1 : RegBounded W g1 := hbnd.update (r := 3) (by decide) hl0
  have hp2 := RegExec.lit (inp := inp) hfd_le bg1 hcCeil hbCeil (dst := 4) (c := 1) (by decide) hl1
  set g2 := Function.update g1 4 1; have bg2 : RegBounded W g2 := bg1.update (r := 4) (by decide) hl1
  have hp3 := RegExec.lit (inp := inp) hfd_le bg2 hcCeil hbCeil (dst := 6) (c := 0) (by decide) hl0
  set g3 := Function.update g2 6 0; have bg3 : RegBounded W g3 := bg2.update (r := 6) (by decide) hl0
  have hp4 := RegExec.lit (inp := inp) hfd_le bg3 hcCeil hbCeil (dst := 7) (c := (d : ℤ)) (by decide) hd_bl
  set g4 := Function.update g3 7 (d : ℤ); have bg4 : RegBounded W g4 := bg3.update (r := 7) (by decide) hd_bl
  let StepInv (c : ℕ) (g : ℕ → ℤ) : Prop :=
    RegBounded W g ∧
    g 0 = regs 0 ∧ g 1 = (h₁ : ℤ) ∧ g 2 = (h₂ : ℤ) ∧ g 5 = regs 5 ∧ g 7 = (d : ℤ) ∧
    (c ≤ d →
      g 6 = (c : ℤ) ∧
      g 3 = (ratSumPairs sqNum sqDen c).1 ∧
      g 4 = (ratSumPairs sqNum sqDen c).2 ∧
      intBitLength (g 3) ≤ c * (2 * ((B + 2) + (B + 2)) + 3) + 2 ∧
      intBitLength (g 4) ≤ c * (2 * ((B + 2) + (B + 2)) + 2) + 2)
  have hInv0 : StepInv 0 g4 := by
    refine ⟨bg4, by simp [g4, g3, g2, g1], by simp [g4, g3, g2, g1, hr1],
      by simp [g4, g3, g2, g1, hr2], by simp [g4, g3, g2, g1], by simp [g4], fun _ => ?_⟩
    have hl0_eq : intBitLength (0 : ℤ) = 1 := by decide
    have hl1_eq : intBitLength (1 : ℤ) = 2 := by decide
    exact ⟨by simp [g4, g3], by simp [g4, g3, g2, g1, ratSumPairs], by simp [g4, g3, g2, ratSumPairs],
      by simp [g4, g3, g2, g1, hl0_eq], by simp [g4, g3, g2, hl1_eq]⟩
  have hStep : ∀ c < d, ∀ g, StepInv c g →
      ∃ g', RegExec inp fd W C_cell C_bit sqDistCoordStepStmt ws g ws g' 200 (50 * W * W) ∧
        StepInv (c + 1) g' := by
    intro c hc g ⟨bg, hg0, hg1, hg2, hg5, hg7, hcd⟩
    obtain ⟨hg6, hg3_eq, hg4_eq, hg3_bl, hg4_bl⟩ := hcd (Nat.le_of_lt hc)
    obtain ⟨_, ha10_bl⟩ := coordCellAddr_bl hh₁_lt hc (f := 0) (by decide) hW_addr
    obtain ⟨_, ha11_bl⟩ := coordCellAddr_bl hh₁_lt hc (f := 1) (by decide) hW_addr
    obtain ⟨_, ha20_bl⟩ := coordCellAddr_bl hh₂_lt hc (f := 0) (by decide) hW_addr
    obtain ⟨_, ha21_bl⟩ := coordCellAddr_bl hh₂_lt hc (f := 1) (by decide) hW_addr
    have hm1_bl : intBitLength ((h₁ * d : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (h₁ * d + c) * 2 + 0) (by clear * -; omega)).trans ha10_bl
    have had1_bl : intBitLength ((h₁ * d + c : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (h₁ * d + c) * 2 + 0) (by clear * -; omega)).trans ha10_bl
    have hm2_bl : intBitLength ((h₂ * d : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (h₂ * d + c) * 2 + 0) (by clear * -; omega)).trans ha20_bl
    have had2_bl : intBitLength ((h₂ * d + c : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (h₂ * d + c) * 2 + 0) (by clear * -; omega)).trans ha20_bl
    have hc1_bl : intBitLength ((c + 1 : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := d) (by clear * - hc; omega)).trans hd_bl
    obtain ⟨hpN_bl, hpD_bl, _, _⟩ := ratBitLength_le_of_bounded (hq₁_bnd ⟨c, hc⟩)
    obtain ⟨hqN_bl, hqD_bl, _, _⟩ := ratBitLength_le_of_bounded (hq₂_bnd ⟨c, hc⟩)
    have hB_W : B + 2 ≤ W := by
      have hm : 1 * (4 * B + 12) ≤ d * (4 * B + 12) := Nat.mul_le_mul_right _ hd1
      clear * - hm hW; omega
    have hr_pN : ws.read (.heap 1 (coordCellAddr d h₁ c 0)) = pNum c := by
      simp only [pNum, dif_pos hc]; exact hcoords.read_num h₁ hh₁ ⟨c, hc⟩
    have hr_pD : ws.read (.heap 1 (coordCellAddr d h₁ c 1)) = pDen c := by
      simp only [pDen, dif_pos hc]; exact hcoords.read_den h₁ hh₁ ⟨c, hc⟩
    have hr_qN : ws.read (.heap 1 (coordCellAddr d h₂ c 0)) = qNum c := by
      simp only [qNum, dif_pos hc]; exact hcoords.read_num h₂ hh₂ ⟨c, hc⟩
    have hr_qD : ws.read (.heap 1 (coordCellAddr d h₂ c 1)) = qDen c := by
      simp only [qDen, dif_pos hc]; exact hcoords.read_den h₂ hh₂ ⟨c, hc⟩
    have hpN_c : intBitLength (pNum c) ≤ B + 2 := by simp only [pNum, dif_pos hc]; exact hpN_bl.trans (Nat.le_succ _)
    have hpD_c : intBitLength (pDen c) ≤ B + 2 := by simp only [pDen, dif_pos hc]; exact hpD_bl.trans (Nat.le_succ _)
    have hqN_c : intBitLength (qNum c) ≤ B + 2 := by simp only [qNum, dif_pos hc]; exact hqN_bl.trans (Nat.le_succ _)
    have hqD_c : intBitLength (qDen c) ≤ B + 2 := by simp only [qDen, dif_pos hc]; exact hqD_bl.trans (Nat.le_succ _)
    -- Load `(pNum c, pDen c)` into `(r9, r10)`
    have m8_1 : g 1 * g 7 = ((h₁ * d : ℕ) : ℤ) := by rw [hg1, hg7]; push_cast; ring
    have t1 := RegExec.mul (inp := inp) hfd_le bg hcCeil hbCeil (dst := 8) (a := 1) (b := 7) (by decide) (by decide) (by decide) (by rw [m8_1]; exact hm1_bl)
    rw [m8_1] at t1; set u1 := Function.update g 8 ((h₁ * d : ℕ) : ℤ); have bu1 : RegBounded W u1 := bg.update (r := 8) (by decide) hm1_bl
    have a8_1 : u1 8 + u1 6 = ((h₁ * d + c : ℕ) : ℤ) := by simp [u1, hg6]
    have t2 := RegExec.add (inp := inp) hfd_le bu1 hcCeil hbCeil (dst := 8) (a := 8) (b := 6) (by decide) (by decide) (by decide) (by rw [a8_1]; exact had1_bl)
    rw [a8_1] at t2; set u2 := Function.update u1 8 ((h₁ * d + c : ℕ) : ℤ); have bu2 : RegBounded W u2 := bu1.update (r := 8) (by decide) had1_bl
    have a8_2 : u2 8 + u2 8 = coordCellAddr d h₁ c 0 := by simp only [u2, Function.update_self, coordCellAddr]; push_cast; ring
    have t3 := RegExec.add (inp := inp) hfd_le bu2 hcCeil hbCeil (dst := 8) (a := 8) (b := 8) (by decide) (by decide) (by decide) (by rw [a8_2]; exact ha10_bl)
    rw [a8_2] at t3; set u3 := Function.update u2 8 (coordCellAddr d h₁ c 0); have bu3 : RegBounded W u3 := bu2.update (r := 8) (by decide) ha10_bl
    have hu3_8 : ws.read (.heap 1 (u3 8)) = pNum c := by simp [u3, hr_pN]
    have t4 := RegExec.load (inp := inp) hfd_le bu3 hcCeil hbCeil (dst := 9) (table := 1) (addr := 8) (by decide) (by decide) hn1
      (by rw [hu3_8]; exact hpN_c.trans hB_W)
    rw [hu3_8] at t4; set u4 := Function.update u3 9 (pNum c); have bu4 : RegBounded W u4 := bu3.update (r := 9) (by decide) (hpN_c.trans hB_W)
    have t5 := RegExec.lit (inp := inp) hfd_le bu4 hcCeil hbCeil (dst := 15) (c := 1) (by decide) hl1
    set u5 := Function.update u4 15 1; have bu5 : RegBounded W u5 := bu4.update (r := 15) (by decide) hl1
    have a8_3 : u5 8 + u5 15 = coordCellAddr d h₁ c 1 := by
      simp only [u5, u4, u3, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), Function.update_of_ne (by decide : (8 : ℕ) ≠ 9), coordCellAddr]
      push_cast; ring
    have t6 := RegExec.add (inp := inp) hfd_le bu5 hcCeil hbCeil (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a8_3]; exact ha11_bl)
    rw [a8_3] at t6; set u6 := Function.update u5 8 (coordCellAddr d h₁ c 1); have bu6 : RegBounded W u6 := bu5.update (r := 8) (by decide) ha11_bl
    have hu6_8 : ws.read (.heap 1 (u6 8)) = pDen c := by simp [u6, hr_pD]
    have t7 := RegExec.load (inp := inp) hfd_le bu6 hcCeil hbCeil (dst := 10) (table := 1) (addr := 8) (by decide) (by decide) hn1
      (by rw [hu6_8]; exact hpD_c.trans hB_W)
    rw [hu6_8] at t7; set u7 := Function.update u6 10 (pDen c); have bu7 : RegBounded W u7 := bu6.update (r := 10) (by decide) (hpD_c.trans hB_W)
    -- Load `(qNum c, qDen c)` into `(r11, r12)`
    have m8_2 : u7 2 * u7 7 = ((h₂ * d : ℕ) : ℤ) := by simp [u7, u6, u5, u4, u3, u2, u1, hg2, hg7]
    have t8 := RegExec.mul (inp := inp) hfd_le bu7 hcCeil hbCeil (dst := 8) (a := 2) (b := 7) (by decide) (by decide) (by decide) (by rw [m8_2]; exact hm2_bl)
    rw [m8_2] at t8; set u8 := Function.update u7 8 ((h₂ * d : ℕ) : ℤ); have bu8 : RegBounded W u8 := bu7.update (r := 8) (by decide) hm2_bl
    have a8_4 : u8 8 + u8 6 = ((h₂ * d + c : ℕ) : ℤ) := by simp [u8, u7, u6, u5, u4, u3, u2, u1, hg6]
    have t9 := RegExec.add (inp := inp) hfd_le bu8 hcCeil hbCeil (dst := 8) (a := 8) (b := 6) (by decide) (by decide) (by decide) (by rw [a8_4]; exact had2_bl)
    rw [a8_4] at t9; set u9 := Function.update u8 8 ((h₂ * d + c : ℕ) : ℤ); have bu9 : RegBounded W u9 := bu8.update (r := 8) (by decide) had2_bl
    have a8_5 : u9 8 + u9 8 = coordCellAddr d h₂ c 0 := by simp only [u9, Function.update_self, coordCellAddr]; push_cast; ring
    have t10 := RegExec.add (inp := inp) hfd_le bu9 hcCeil hbCeil (dst := 8) (a := 8) (b := 8) (by decide) (by decide) (by decide) (by rw [a8_5]; exact ha20_bl)
    rw [a8_5] at t10; set u10 := Function.update u9 8 (coordCellAddr d h₂ c 0); have bu10 : RegBounded W u10 := bu9.update (r := 8) (by decide) ha20_bl
    have hu10_8 : ws.read (.heap 1 (u10 8)) = qNum c := by simp [u10, hr_qN]
    have t11 := RegExec.load (inp := inp) hfd_le bu10 hcCeil hbCeil (dst := 11) (table := 1) (addr := 8) (by decide) (by decide) hn1
      (by rw [hu10_8]; exact hqN_c.trans hB_W)
    rw [hu10_8] at t11; set u11 := Function.update u10 11 (qNum c); have bu11 : RegBounded W u11 := bu10.update (r := 11) (by decide) (hqN_c.trans hB_W)
    have t12 := RegExec.lit (inp := inp) hfd_le bu11 hcCeil hbCeil (dst := 15) (c := 1) (by decide) hl1
    set u12 := Function.update u11 15 1; have bu12 : RegBounded W u12 := bu11.update (r := 15) (by decide) hl1
    have a8_6 : u12 8 + u12 15 = coordCellAddr d h₂ c 1 := by
      simp only [u12, u11, u10, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), Function.update_of_ne (by decide : (8 : ℕ) ≠ 11), coordCellAddr]
      push_cast; ring
    have t13 := RegExec.add (inp := inp) hfd_le bu12 hcCeil hbCeil (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [a8_6]; exact ha21_bl)
    rw [a8_6] at t13; set u13 := Function.update u12 8 (coordCellAddr d h₂ c 1); have bu13 : RegBounded W u13 := bu12.update (r := 8) (by decide) ha21_bl
    have hu13_8 : ws.read (.heap 1 (u13 8)) = qDen c := by simp [u13, hr_qD]
    have t14 := RegExec.load (inp := inp) hfd_le bu13 hcCeil hbCeil (dst := 12) (table := 1) (addr := 8) (by decide) (by decide) hn1
      (by rw [hu13_8]; exact hqD_c.trans hB_W)
    rw [hu13_8] at t14; set u14 := Function.update u13 12 (qDen c); have bu14 : RegBounded W u14 := bu13.update (r := 12) (by decide) (hqD_c.trans hB_W)
    -- Call `accumSqDiffRegs` (`B_p = B + 2`, `B_q = B + 2`)
    have hW_acc : d * (2 * ((B + 2) + (B + 2)) + 3) + 20 ≤ W := by
      have h_eq : 2 * ((B + 2) + (B + 2)) + 3 = 4 * B + 11 := by ring
      have hm : d * (4 * B + 11) ≤ d * (4 * B + 12) := Nat.mul_le_mul_left d (by clear * -; omega)
      rw [h_eq]; clear * - hm hW; omega
    have hu14_3 : u14 3 = g 3 := by simp [u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1]
    have hu14_4 : u14 4 = g 4 := by simp [u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1]
    obtain ⟨u15, t15, bu15, hu15_3, hu15_4, hb15_3, hb15_4, hpres15⟩ :=
      exec_accumSqDiffRegs (inp := inp) (fd := fd) hfd_le hcCeil hbCeil
        (pNum := pNum) (pDen := pDen) (qNum := qNum) (qDen := qDen)
        (B_p := B + 2) (B_q := B + 2) (c := c)
        (by clear * -; omega) (by clear * -; omega) hc hW_acc
        hpN_c hpD_c hqN_c hqD_c bu14
        (by simp [u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4])
        (by simp [u14, u13, u12, u11, u10, u9, u8, u7])
        (by simp [u14, u13, u12, u11])
        (by simp [u14])
        (hu14_3.trans hg3_eq) (hu14_4.trans hg4_eq)
        (by rw [hu14_3]; exact hg3_bl) (by rw [hu14_4]; exact hg4_bl)
    -- Increment `r6`
    have t16 := RegExec.lit (inp := inp) hfd_le bu15 hcCeil hbCeil (dst := 15) (c := 1) (by decide) hl1
    set u16 := Function.update u15 15 1; have bu16 : RegBounded W u16 := bu15.update (r := 15) (by decide) hl1
    have hu15_6 : u15 6 = (c : ℤ) := by
      rw [hpres15 6 (by decide) (by decide) (by decide)]
      simp [u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg6]
    have a6 : u16 6 + u16 15 = ((c + 1 : ℕ) : ℤ) := by
      simp only [u16, Function.update_self, Function.update_of_ne (by decide : (6 : ℕ) ≠ 15), hu15_6]
      push_cast; ring
    have t17 := RegExec.add (inp := inp) hfd_le bu16 hcCeil hbCeil (dst := 6) (a := 6) (b := 15)
      (by decide) (by decide) (by decide) (by rw [a6]; exact hc1_bl)
    rw [a6] at t17; set u17 := Function.update u16 6 ((c + 1 : ℕ) : ℤ); have bu17 : RegBounded W u17 := bu16.update (r := 6) (by decide) hc1_bl
    have sAll := (t1.seq (t2.seq (t3.seq (t4.seq (t5.seq (t6.seq (t7.seq (t8.seq (t9.seq (t10.seq
      (t11.seq (t12.seq (t13.seq (t14.seq (t15.seq (t16.seq t17)))))))))))))))).weaken
      rfl rfl (u₂ := 200) (b₂ := 50 * W * W) (by clear * -; omega)
      (by calc _ = 44 * (W * W) + (72 * W + 368) := by ring
            _ ≤ 44 * (W * W) + 6 * (W * W) := Nat.add_le_add_left (by linarith only [hW20, hWW]) _
            _ = 50 * W * W := by ring)
    refine ⟨u17, sAll, bu17, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · simp only [u17, u16, Function.update_of_ne (by decide : (0 : ℕ) ≠ 6), Function.update_of_ne (by decide : (0 : ℕ) ≠ 15)]
      rw [hpres15 0 (by decide) (by decide) (by decide)]
      simp [u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg0]
    · simp only [u17, u16, Function.update_of_ne (by decide : (1 : ℕ) ≠ 6), Function.update_of_ne (by decide : (1 : ℕ) ≠ 15)]
      rw [hpres15 1 (by decide) (by decide) (by decide)]
      simp [u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg1]
    · simp only [u17, u16, Function.update_of_ne (by decide : (2 : ℕ) ≠ 6), Function.update_of_ne (by decide : (2 : ℕ) ≠ 15)]
      rw [hpres15 2 (by decide) (by decide) (by decide)]
      simp [u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg2]
    · simp only [u17, u16, Function.update_of_ne (by decide : (5 : ℕ) ≠ 6), Function.update_of_ne (by decide : (5 : ℕ) ≠ 15)]
      rw [hpres15 5 (by decide) (by decide) (by decide)]
      simp [u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg5]
    · simp only [u17, u16, Function.update_of_ne (by decide : (7 : ℕ) ≠ 6), Function.update_of_ne (by decide : (7 : ℕ) ≠ 15)]
      rw [hpres15 7 (by decide) (by decide) (by decide)]
      simp [u14, u13, u12, u11, u10, u9, u8, u7, u6, u5, u4, u3, u2, u1, hg7]
    · intro _
      have hu17_3 : u17 3 = u15 3 := by simp [u17, u16]
      have hu17_4 : u17 4 = u15 4 := by simp [u17, u16]
      exact ⟨by simp [u17], hu17_3.trans hu15_3, hu17_4.trans hu15_4,
        by rw [hu17_3]; exact hb15_3, by rw [hu17_4]; exact hb15_4⟩
  classical
  let seqP : ∀ n : ℕ, { g : ℕ → ℤ // StepInv n g } :=
    Nat.rec ⟨g4, hInv0⟩ (fun c prev =>
      if hc : c < d then
        let hEx := hStep c hc prev.1 prev.2
        ⟨Classical.choose hEx, (Classical.choose_spec hEx).2⟩
      else
        ⟨prev.1, ⟨prev.2.1, prev.2.2.1, prev.2.2.2.1, prev.2.2.2.2.1, prev.2.2.2.2.2.1, prev.2.2.2.2.2.2.1,
          fun hle => absurd (by clear * - hc hle; omega : c < d) hc⟩⟩)
  have hRep := RegExec.repeatLit (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    d hd_bl (fun _ => ws) (fun i => (seqP i).1) bg4
    (body := sqDistCoordStepStmt) (U := 200) (B := 50 * W * W)
    (fun i hi => by
      dsimp only [seqP]
      rw [dif_pos hi]
      exact (Classical.choose_spec (hStep i hi (seqP i).1 (seqP i).2)).1)
  have hb_tot : 2 * W + 16 + (2 * W + 16 + (2 * W + 16 + (2 * W + 16 + (d * (50 * W * W) + W)))) ≤
      (52 * d + 12) * W * W := by
    calc 2 * W + 16 + (2 * W + 16 + (2 * W + 16 + (2 * W + 16 + (d * (50 * W * W) + W))))
      _ = 50 * d * (W * W) + (9 * W + 64) := by ring
      _ ≤ 50 * d * (W * W) + 12 * (W * W) := Nat.add_le_add_left (by linarith only [hW20, hWW]) _
      _ = (50 * d + 12) * W * W := by ring
      _ ≤ (52 * d + 12) * W * W := Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by clear * -; omega))
  have sTot := (hp1.seq (hp2.seq (hp3.seq (hp4.seq hRep)))).weaken rfl rfl
    (u₂ := 220 * d + 32) (b₂ := (52 * d + 12) * W * W) (by clear * -; omega) hb_tot
  obtain ⟨bgEnd, hg0End, hg1End, hg2End, hg5End, _, hdEnd⟩ := (seqP d).2
  obtain ⟨_, hg3End, hg4End, hb3End, hb4End⟩ := hdEnd le_rfl
  -- Apply `ratSumPairs_spec` and `ratPoint_distSq_eq`!
  have hBt : 1 ≤ 4 * B + 10 := by clear * -; omega
  have hbnds_term : ∀ i < d, 1 ≤ sqDen i ∧ intBitLength (sqNum i) ≤ 4 * B + 10 ∧ intBitLength (sqDen i) ≤ 4 * B + 10 := by
    intro i hi
    obtain ⟨bpN, bpD, hpD1, _⟩ := ratBitLength_le_of_bounded (hq₁_bnd ⟨i, hi⟩)
    obtain ⟨bqN, bqD, hqD1, _⟩ := ratBitLength_le_of_bounded (hq₂_bnd ⟨i, hi⟩)
    have hpDi : 1 ≤ pDen i := by simp only [pDen, dif_pos hi]; exact_mod_cast hpD1
    have hqDi : 1 ≤ qDen i := by simp only [qDen, dif_pos hi]; exact_mod_cast hqD1
    have h12 : 1 ≤ pDen i * qDen i := by nlinarith only [hpDi, hqDi]
    have h1 : 1 ≤ sqDen i := by dsimp [sqDen]; nlinarith only [h12]
    have bpNi : intBitLength (pNum i) ≤ B + 2 := by simp only [pNum, dif_pos hi]; exact bpN.trans (Nat.le_succ _)
    have bpDi : intBitLength (pDen i) ≤ B + 2 := by simp only [pDen, dif_pos hi]; exact bpD.trans (Nat.le_succ _)
    have bqNi : intBitLength (qNum i) ≤ B + 2 := by simp only [qNum, dif_pos hi]; exact bqN.trans (Nat.le_succ _)
    have bqDi : intBitLength (qDen i) ≤ B + 2 := by simp only [qDen, dif_pos hi]; exact bqD.trans (Nat.le_succ _)
    have bm1 : intBitLength (pNum i * qDen i) ≤ 2 * B + 4 := by
      have := (intBitLength_mul_le (pNum i) (qDen i)).trans (Nat.add_le_add bpNi bqDi)
      clear * - this; omega
    have bm2 : intBitLength (qNum i * pDen i) ≤ 2 * B + 4 := by
      have := (intBitLength_mul_le (qNum i) (pDen i)).trans (Nat.add_le_add bqNi bpDi)
      clear * - this; omega
    have bdf : intBitLength (pNum i * qDen i - qNum i * pDen i) ≤ 2 * B + 5 := by
      have hs := intBitLength_sub_le_max (pNum i * qDen i) (qNum i * pDen i)
      have hm := max_le bm1 bm2
      clear * - hs hm; omega
    have bsN : intBitLength (sqNum i) ≤ 4 * B + 10 := by
      have := (intBitLength_mul_le _ _).trans (Nat.add_le_add bdf bdf)
      dsimp [sqNum]; clear * - this; omega
    have bpd : intBitLength (pDen i * qDen i) ≤ 2 * B + 4 := by
      have := (intBitLength_mul_le (pDen i) (qDen i)).trans (Nat.add_le_add bpDi bqDi)
      clear * - this; omega
    have bsD : intBitLength (sqDen i) ≤ 4 * B + 10 := by
      have := (intBitLength_mul_le _ _).trans (Nat.add_le_add bpd bpd)
      dsimp [sqDen]; clear * - this; omega
    exact ⟨h1, bsN, bsD⟩
  obtain ⟨hden_pos, _, _, _, hnn_num⟩ := ratSumPairs_spec hBt d hbnds_term
  have hnn : 0 ≤ (ratSumPairs sqNum sqDen d).1 :=
    hnn_num (fun i _ => by dsimp [sqNum]; exact mul_self_nonneg _)
  have hdist := ratPoint_distSq_eq (p := qMap h₁) (q := qMap h₂)
    (pNum := pNum) (pDen := pDen) (qNum := qNum) (qDen := qDen)
    (fun c => by
      obtain ⟨_, _, hd_pos, _⟩ := ratBitLength_le_of_bounded (hq₁_bnd c)
      exact ⟨by simp only [pDen, dif_pos c.isLt]; exact_mod_cast hd_pos,
             by simp only [pNum, pDen, dif_pos c.isLt, Rat.cast_def, Int.cast_natCast]⟩)
    (fun c => by
      obtain ⟨_, _, hd_pos, _⟩ := ratBitLength_le_of_bounded (hq₂_bnd c)
      exact ⟨by simp only [qDen, dif_pos c.isLt]; exact_mod_cast hd_pos,
             by simp only [qNum, qDen, dif_pos c.isLt, Rat.cast_def, Int.cast_natCast]⟩)
  refine ⟨(seqP d).1, sTot, bgEnd, hg0End, hg1End, hg2End, hg5End,
    by rw [hg4End]; exact hden_pos,
    by rw [hg3End]; exact hnn,
    by rw [hg3End, hg4End]; exact hdist,
    ?_, ?_⟩
  · have h_eq : 2 * ((B + 2) + (B + 2)) + 3 = 4 * B + 11 := by ring
    rw [h_eq] at hb3End; exact hb3End
  · have h_eq : 2 * ((B + 2) + (B + 2)) + 2 = 4 * B + 10 := by ring
    rw [h_eq] at hb4End; exact hb4End

end UL.C12LVE
