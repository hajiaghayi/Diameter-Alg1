import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG11_StepC3a
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

def defaultSuffixLoopCond (s₀_d : ℕ) : BitCondExpr :=
  .intLt (.lit (((2 * s₀_d - 1 : ℕ) : ℤ))) (.readHeap 9 (.lit 110))

def posDimStepCStmt (c1Stmt : BitRAMStmt) (loopCond : BitCondExpr)
    (c2Stmt epilogueStmt : BitRAMStmt) : BitRAMStmt :=
  .ite (.intLe (.readHeap 9 (.lit 106)) (.readHeap 0 (.lit 10)))
    (.seq c1Stmt (.seq (.whileLoop loopCond c2Stmt) epilogueStmt))
    cleanHeap9Regs

theorem eval_defaultSuffixLoopCond {d : ℕ} (inp : BitRAMInput d) {fd W s₀_d M : ℕ}
    (hs₀1 : 1 ≤ s₀_d)
    (hl_leaf : intBitLength (((2 * s₀_d - 1 : ℕ) : ℤ)) ≤ W)
    (hl_M : intBitLength (M : ℤ) ≤ W)
    {wsHeap ws : WordStore} {regs : ℕ → ℤ}
    (hrf : HasRegFrame fd wsHeap regs ws)
    (hr110 : wsHeap.read (.heap 9 110) = (M : ℤ)) :
    ∃ uC bC : ℕ,
      evalBitCond inp fd ws (defaultSuffixLoopCond s₀_d) = (decide (2 * s₀_d - 1 < M), uC, bC) ∧
      uC ≤ 5 ∧ bC ≤ 4 * W + 24 := by
  have hl110 : intBitLength (110 : ℤ) = 8 := by decide
  have ht9 : natBitLength 9 = 4 := by decide
  rcases hev : evalBitCond inp fd ws (defaultSuffixLoopCond s₀_d) with ⟨fl, uC, bC⟩
  dsimp only [defaultSuffixLoopCond, evalBitCond, evalIntExpr] at hev
  rw [hrf.read_heap 9 110, hr110, hl110, ht9] at hev
  rcases Prod.mk.inj hev with ⟨hfl, hub⟩
  rcases Prod.mk.inj hub with ⟨rfl, rfl⟩
  have hiff : (((2 * s₀_d - 1 : ℕ) : ℤ) < (M : ℤ)) ↔ (2 * s₀_d - 1 < M) := by exact_mod_cast Iff.rfl
  have hdec : decide (((2 * s₀_d - 1 : ℕ) : ℤ) < (M : ℤ)) = decide (2 * s₀_d - 1 < M) :=
    decide_eq_decide.mpr hiff
  exact ⟨_, _, by rw [← hfl, hdec], by omega, by omega⟩

/-- Full outer suffix `whileLoop` induction matching `runSyncSuffixFuel`. -/
theorem exec_posDimStepC3_while
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hs₀1 : 1 ≤ s₀_d)
    {C_nodes : ℝ}
    (h51_len : ∀ (P : Finset ℕ), P.card ≤ n →
      ∀ (k : ℕ) (nodes : Fin k → ChainNode d)
        (P₀ : Fin k → Finset ℕ)
        (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
        (age : Fin k → ℕ)
        (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)),
        (∀ i : Fin k,
          (nodes i).o = o i ∧
          (nodes i).V = liftVariance (o i) (s i) ∧
          1 ≤ (P₀ i).card ∧
          IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
            (paraboloidLiftSet (fun j : P₀ i => ltCoords j.1)) (liftedPoint (o i) (s i)) ∧
          HasNodeAge (P₀ i) (chainInput ltCoords nodes P i.castSucc) (age i) ∧
          (age i : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * ((P₀ i).card : ℝ) / 16) →
        (k : ℝ) ≤ C_nodes * (1 / (4 * (s₀_d : ℝ)))⁻¹ * Real.log ((n : ℝ) + 1))
    (hK_bound : C_nodes * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) ≤ (K_max : ℝ))
    {ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d s₀_d)}
    {hist : ExecutionHistory d}
    {P' : DynamicPointSet d} {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {qMap' : ℕ → Fin d → ℚ} {retHVal : ℤ}
    (hctor_valid : ∀ (acc : List (SyncSuffixPrefixEntry d (PosDimNodeData d s₀_d)))
      (R : Finset ℕ) (bs₁ : List Bool) (out : SyncBuiltNode d (PosDimNodeData d s₀_d)),
      2 * s₀_d - 1 < R.card → R.card ≤ n →
      (∀ lt ∈ R, ltCoords' lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist acc ltCoords' R bs₁ = some out →
        out.node.V = liftVariance out.node.o out.s ∧
        IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
          (paraboloidLiftSet (fun i : R => ltCoords' i.1))
          (liftedPoint out.node.o out.s))
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ}
    {loopCond : BitCondExpr} {c2Stmt : BitRAMStmt}
    {LoopExtra : ℕ → Finset ℕ → WordStore → (ℕ → ℤ) → Prop}
    {U_cond B_cond K_c2_u K_c2_b : ℕ}
    (hCondEval : ∀ (j : ℕ) (R : Finset ℕ) (wsHeap ws : WordStore) (regs : ℕ → ℤ),
      j ≤ K_max → R.card ≤ n →
      HasRegFrame fd wsHeap regs ws → RegBounded W regs →
      LoopExtra j R wsHeap regs →
      ∃ uC bC : ℕ,
        evalBitCond inp fd ws loopCond = (decide (2 * s₀_d - 1 < R.card), uC, bC) ∧
        uC ≤ U_cond ∧ bC ≤ B_cond)
    (hStepC2 : ∀ (prefNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)))
      (acc : List (SyncSuffixPrefixEntry d (PosDimNodeData d s₀_d)))
      (R : Finset ℕ) (wsHeap : WordStore) (regs : ℕ → ℤ)
      (bs₁ tailBits : List Bool) (out : SyncBuiltNode d (PosDimNodeData d s₀_d))
      (st : BitRAMExecState),
      let curNodes := prefNodes ++ entriesToLiveNodes acc
      let j := curNodes.length
      j < K_max →
      2 * s₀_d ≤ R.card → R.card ≤ n →
      R ⊆ activeLifetimes P' →
      (∀ lt ∈ R, lt < P'.nextLifetime ∧ ltCoords' lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist acc ltCoords' R bs₁ = some out →
      MidSuffixChainInv n L B B_cert K_max W P' ltCoords' curNodes qMap' retHVal R wsHeap →
      LoopExtra j R wsHeap regs →
      st.frameDepth = fd →
      HasRegFrame fd wsHeap regs st.words →
      RegBounded W regs →
      st.remainingBits = bs₁ ++ tailBits →
      st.peakCellSpace ≤ C_cell →
      st.peakBitSpace ≤ C_bit →
      let vNew : SyncLiveChainNode d (PosDimNodeData d s₀_d) :=
        { built := out, birthPool := R, ageUpdateSteps := ∅ }
      let R' := out.node.residual ltCoords' R
      ∃ (st' : BitRAMExecState) (wsHeap' : WordStore) (regs' : ℕ → ℤ),
        RunsTo inp [.stmt c2Stmt] st st' ∧
        st'.frameDepth = fd ∧
        HasRegFrame fd wsHeap' regs' st'.words ∧
        RegBounded W regs' ∧
        st'.remainingBits = tailBits ∧
        st'.unitCost ≤ st.unitCost + K_c2_u * (out.work + 1) ∧
        st'.bitCost ≤ st.bitCost + K_c2_b * (out.work + 1) ∧
        st'.peakCellSpace ≤ C_cell ∧
        st'.peakBitSpace ≤ C_bit ∧
        MidSuffixChainInv n L B B_cert K_max W P' ltCoords' (curNodes ++ [vNew]) qMap' retHVal R' wsHeap' ∧
        LoopExtra (j + 1) R' wsHeap' regs')
    (prefNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))) :
    ∀ (fuel : ℕ) (acc : List (SyncSuffixPrefixEntry d (PosDimNodeData d s₀_d)))
      (R : Finset ℕ) (accWork : ℕ) (bs tailBits : List Bool)
      (sufOut : SyncSuffixOutcome d (PosDimNodeData d s₀_d))
      (wsHeap : WordStore) (regs : ℕ → ℤ) (st : BitRAMExecState),
      runSyncSuffixFuel ctor (2 * s₀_d - 1) hist ltCoords' fuel acc R accWork bs = some sufOut →
      MidSuffixChainInv n L B B_cert K_max W P' ltCoords'
        (prefNodes ++ entriesToLiveNodes acc) qMap' retHVal R wsHeap →
      LoopExtra (prefNodes ++ entriesToLiveNodes acc).length R wsHeap regs →
      st.frameDepth = fd →
      HasRegFrame fd wsHeap regs st.words →
      RegBounded W regs →
      st.remainingBits = bs ++ tailBits →
      st.peakCellSpace ≤ C_cell →
      st.peakBitSpace ≤ C_bit →
      ∃ (stEnd : BitRAMExecState) (wsEnd : WordStore) (regsEnd : ℕ → ℤ),
        RunsTo inp [.stmt (.whileLoop loopCond c2Stmt)] st stEnd ∧
        stEnd.frameDepth = fd ∧
        HasRegFrame fd wsEnd regsEnd stEnd.words ∧
        RegBounded W regsEnd ∧
        stEnd.remainingBits = tailBits ∧
        sufOut.terminalLeaf.card ≤ 2 * s₀_d - 1 ∧
        accWork ≤ sufOut.totalWork ∧
        stEnd.unitCost ≤ st.unitCost + U_cond + (U_cond + K_c2_u) * ((sufOut.totalWork - accWork) + (sufOut.entries.length - acc.length)) ∧
        stEnd.bitCost ≤ st.bitCost + B_cond + (B_cond + K_c2_b) * ((sufOut.totalWork - accWork) + (sufOut.entries.length - acc.length)) ∧
        stEnd.peakCellSpace ≤ C_cell ∧
        stEnd.peakBitSpace ≤ C_bit ∧
        MidSuffixChainInv n L B B_cert K_max W P' ltCoords'
          (prefNodes ++ entriesToLiveNodes sufOut.entries) qMap' retHVal sufOut.terminalLeaf wsEnd ∧
        LoopExtra (prefNodes ++ entriesToLiveNodes sufOut.entries).length sufOut.terminalLeaf wsEnd regsEnd := by
  intro fuel
  induction fuel with
  | zero =>
      intro acc R accWork bs tailBits sufOut wsHeap regs st hfuel hmid hextra hfd hrf hbnd hbits hpC hpB
      dsimp only [runSyncSuffixFuel] at hfuel
      split_ifs at hfuel with hdone
      rcases hdone with ⟨hR_le, hbs_emp⟩
      injection hfuel with hsuf; subst hsuf
      have hbs_nil : bs = [] := List.isEmpty_iff.mp hbs_emp
      subst hbs_nil
      have hR_sub : R ⊆ activeLifetimes P' := hmid.hR_eq ▸ chainInput_subset_base _ _ _ _
      have hR_n : R.card ≤ n := (Finset.card_le_card hR_sub).trans (activeLifetimes_card_le hmid.wfP')
      obtain ⟨uC, bC, hev, huC, hbC⟩ := hCondEval _ R wsHeap st.words regs hmid.hk_le hR_n hrf hbnd hextra
      have hdec_false : decide (2 * s₀_d - 1 < R.card) = false :=
        decide_eq_false (by omega)
      rw [hdec_false] at hev
      have hrw : st.frameDepth = fd := hfd
      have hrun := RunsTo.while_false loopCond c2Stmt st (hrw ▸ hev)
      simp only [List.nil_append] at hbits
      exact ⟨{ st with unitCost := st.unitCost + uC, bitCost := st.bitCost + bC },
        wsHeap, regs, hrun, hfd, hrf, hbnd, hbits, hR_le, le_rfl,
        by simp; omega, by simp; omega, hpC, hpB, hmid, hextra⟩
  | succ fuel ih =>
      intro acc R accWork bs tailBits sufOut wsHeap regs st hfuel hmid hextra hfd hrf hbnd hbits hpC hpB
      have hR_sub : R ⊆ activeLifetimes P' := hmid.hR_eq ▸ chainInput_subset_base _ _ _ _
      have hR_n : R.card ≤ n := (Finset.card_le_card hR_sub).trans (activeLifetimes_card_le hmid.wfP')
      obtain ⟨uC, bC, hev, huC, hbC⟩ := hCondEval _ R wsHeap st.words regs hmid.hk_le hR_n hrf hbnd hextra
      by_cases hR_le : R.card ≤ 2 * s₀_d - 1
      · -- Loop exits cleanly at `fuel + 1`
        dsimp only [runSyncSuffixFuel] at hfuel
        rw [if_pos hR_le] at hfuel
        split_ifs at hfuel with hbs_emp
        injection hfuel with hsuf; subst hsuf
        have hbs_nil : bs = [] := List.isEmpty_iff.mp hbs_emp
        subst hbs_nil
        have hdec_false : decide (2 * s₀_d - 1 < R.card) = false :=
          decide_eq_false (by omega)
        rw [hdec_false] at hev
        have hrun := RunsTo.while_false loopCond c2Stmt st (hfd ▸ hev)
        simp only [List.nil_append] at hbits
        exact ⟨{ st with unitCost := st.unitCost + uC, bitCost := st.bitCost + bC },
          wsHeap, regs, hrun, hfd, hrf, hbnd, hbits, hR_le, le_rfl,
          by simp; omega, by simp; omega, hpC, hpB, hmid, hextra⟩
      · -- `2 * s₀_d - 1 < R.card`: unfold one `runSyncSuffixFuel` step!
        have hR_gt : 2 * s₀_d - 1 < R.card := Nat.lt_of_not_ge hR_le
        have hR_ge : 2 * s₀_d ≤ R.card := by omega
        dsimp only [runSyncSuffixFuel] at hfuel
        rw [if_neg hR_le] at hfuel
        split_ifs at hfuel with hStep
        set bs₁ := Classical.choose hStep
        set h₂ := Classical.choose_spec hStep
        set bs₂ := Classical.choose h₂
        set h₃ := Classical.choose_spec h₂
        set out := Classical.choose h₃
        obtain ⟨hbs_split, hbuild⟩ := Classical.choose_spec h₃
        let entry : SyncSuffixPrefixEntry d (PosDimNodeData d s₀_d) :=
          { birthPool := R, coins := bs₁, built := out }
        let vNew : SyncLiveChainNode d (PosDimNodeData d s₀_d) := entryToLiveNode entry
        let R' := out.node.residual ltCoords' R
        have hfuel_rem :
            runSyncSuffixFuel ctor (2 * s₀_d - 1) hist ltCoords' fuel (acc ++ [entry]) R'
              (accWork + out.work) bs₂ = some sufOut := hfuel
        have hR_adm_lt : ∀ lt ∈ R, lt < P'.nextLifetime ∧ ltCoords' lt ∈ RatAdmissiblePointSet d B := by
          intro lt hlt
          obtain ⟨h1, h2, _⟩ := activeLifetimes_adm_and_lt hmid.wfP' hmid.hlt_sync' hmid.coords_stored lt (hR_sub hlt)
          exact ⟨h1, h2⟩
        obtain ⟨hout_V, hout_cp⟩ :=
          hctor_valid acc R bs₁ out hR_gt hR_n (fun lt hlt => (hR_adm_lt lt hlt).2) hbuild
        -- Prove `(prefNodes ++ entriesToLiveNodes acc).length < K_max` by applying `chain_length_le_of_contraction` to `curNodes ++ [vNew]`!
        let curNodes := prefNodes ++ entriesToLiveNodes acc
        let nextNodes := curNodes ++ [vNew]
        have hnext_le_K : nextNodes.length ≤ K_max := by
          refine chain_length_le_of_contraction (ltCoords := ltCoords') hs₀1 h51_len hK_bound hmid.wfP' nextNodes (fun i hi => ?_)
          have hlen_next : nextNodes.length = curNodes.length + 1 := by simp [nextNodes]
          rcases Nat.lt_succ_iff_lt_or_eq.mp (hlen_next ▸ hi) with hi_lt | rfl
          · have hget_eq : nextNodes.get ⟨i, hi⟩ = curNodes.get ⟨i, hi_lt⟩ := by
              simp [nextNodes, List.get_eq_getElem, List.getElem_append_left hi_lt]
            have hci_eq : chainInput ltCoords' (fun r : Fin nextNodes.length => (nextNodes.get r).built.node)
                (activeLifetimes P') ⟨i, Nat.lt_succ_of_lt hi⟩ =
              chainInput ltCoords' (fun r : Fin curNodes.length => (curNodes.get r).built.node)
                (activeLifetimes P') ⟨i, Nat.lt_succ_of_lt hi_lt⟩ :=
              chainInput_append_left ltCoords' curNodes [vNew] (activeLifetimes P') (Nat.le_of_lt hi_lt)
            have hlev := hmid.levels i hi_lt
            dsimp only at hlev ⊢
            have hbp1 : 1 ≤ (curNodes.get ⟨i, hi_lt⟩).birthPool.card :=
              Nat.le_trans (by clear * - hs₀1; omega : 1 ≤ 2 * s₀_d) hlev.hm_bounds.1
            rw [hget_eq, hci_eq]
            exact ⟨hbp1, hlev.hnode_V, hlev.hcp, hlev.hage_rel, hlev.hage_le⟩
          · have hget_last : nextNodes.get ⟨curNodes.length, hi⟩ = vNew := by
              simp [nextNodes, List.get_eq_getElem]
            have hci_last : chainInput ltCoords' (fun r : Fin nextNodes.length => (nextNodes.get r).built.node)
                (activeLifetimes P') ⟨curNodes.length, Nat.lt_succ_of_lt hi⟩ = R := by
              have h1 := chainInput_append_left ltCoords' curNodes [vNew] (activeLifetimes P') le_rfl
              exact h1.trans hmid.hR_eq.symm
            dsimp only [vNew, entryToLiveNode, entry] at hget_last ⊢
            rw [hget_last, hci_last]
            have hR1 : 1 ≤ R.card := by clear * - hR_ge hs₀1; omega
            have hα_nn : ((∅ : Finset ℕ).card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (R.card : ℝ) / 16 := by
              rw [Finset.card_empty, Nat.cast_zero]
              exact div_nonneg (mul_nonneg (div_nonneg zero_le_one (mul_nonneg (by norm_num) (Nat.cast_nonneg s₀_d))) (Nat.cast_nonneg _)) (by norm_num)
            exact ⟨hR1, hout_V, hout_cp, hasNodeAge_zero R, hα_nn⟩
        have hj_lt_K : curNodes.length < K_max := by
          have : nextNodes.length = curNodes.length + 1 := by dsimp [nextNodes]; rw [List.length_append, List.length_singleton]
          omega
        have hdec_true : decide (2 * s₀_d - 1 < R.card) = true := decide_eq_true hR_gt
        rw [hdec_true] at hev
        let stAfterCond : BitRAMExecState := { st with unitCost := st.unitCost + uC, bitCost := st.bitCost + bC }
        have hbits_split' : stAfterCond.remainingBits = bs₁ ++ (bs₂ ++ tailBits) := by
          dsimp [stAfterCond]
          rw [hbits, hbs_split, List.append_assoc]
        obtain ⟨stMid, wsMid, regsMid, hrunC2, hfdMid, hrfMid, hbndMid, hbitsMid,
          hucMid, hbcMid, hpCMid, hpBMid, hmidNext, hextraNext⟩ :=
          hStepC2 prefNodes acc R wsHeap regs bs₁ (bs₂ ++ tailBits) out stAfterCond
            hj_lt_K hR_ge hR_n hR_sub hR_adm_lt hbuild hmid hextra
            hfd hrf hbnd hbits_split' hpC hpB
        have hnodes_assoc : prefNodes ++ entriesToLiveNodes (acc ++ [entry]) =
            (prefNodes ++ entriesToLiveNodes acc) ++ [{ built := out, birthPool := R, ageUpdateSteps := ∅ }] := by
          simp [entriesToLiveNodes, entryToLiveNode, entry]
        have hlen_assoc : (prefNodes ++ entriesToLiveNodes (acc ++ [entry])).length =
            (prefNodes ++ entriesToLiveNodes acc).length + 1 := by
          rw [hnodes_assoc, List.length_append, List.length_singleton]
        rw [← hnodes_assoc] at hmidNext
        rw [← hlen_assoc] at hextraNext
        obtain ⟨stEnd, wsEnd, regsEnd, hrunRest, hfdEnd, hrfEnd, hbndEnd, hbitsEnd,
          hleaf_le, hwork_mono, hucEnd, hbcEnd, hpCEnd, hpBEnd, hmidEnd, hextraEnd⟩ :=
          ih (acc ++ [entry]) R' (accWork + out.work) bs₂ tailBits sufOut wsMid regsMid stMid
            hfuel_rem hmidNext hextraNext hfdMid hrfMid hbndMid hbitsMid hpCMid hpBMid
        -- Note `acc.length + 1 ≤ sufOut.entries.length` from `runSyncSuffixFuel` accumulator monotonicity
        have hacc_sub : ∀ (f : ℕ) (a : List (SyncSuffixPrefixEntry d (PosDimNodeData d s₀_d)))
            (rS : Finset ℕ) (aw : ℕ) (bS : List Bool),
            runSyncSuffixFuel ctor (2 * s₀_d - 1) hist ltCoords' f a rS aw bS = some sufOut →
            a.length ≤ sufOut.entries.length := by
          intro f
          induction f with
          | zero =>
              intro a rS aw bS hf
              dsimp [runSyncSuffixFuel] at hf
              split_ifs at hf with hd
              injection hf with hs; rw [← hs]
          | succ f ihf =>
              intro a rS aw bS hf
              dsimp [runSyncSuffixFuel] at hf
              split_ifs at hf with h1 h2 h3
              · injection hf with hs; rw [← hs]
              · exact (Nat.le_succ _).trans (by simpa using ihf _ _ _ _ hf)
        have hlen_le : acc.length + 1 ≤ sufOut.entries.length := by
          simpa using hacc_sub fuel (acc ++ [entry]) R' (accWork + out.work) bs₂ hfuel_rem
        have hrunTot := RunsTo.while_true loopCond c2Stmt (hfd ▸ hev) hrunC2 hrunRest
        refine ⟨stEnd, wsEnd, regsEnd, hrunTot, hfdEnd, hrfEnd, hbndEnd, hbitsEnd,
          hleaf_le, by omega, ?_, ?_, hpCEnd, hpBEnd, hmidEnd, hextraEnd⟩
        · dsimp [stAfterCond] at hucMid
          have hsplit_w : (sufOut.totalWork - accWork) + (sufOut.entries.length - acc.length) =
              (out.work + 1) + ((sufOut.totalWork - (accWork + out.work)) + (sufOut.entries.length - (acc.length + 1))) := by
            omega
          have halg : (U_cond + K_c2_u) * ((out.work + 1) + ((sufOut.totalWork - (accWork + out.work)) + (sufOut.entries.length - (acc.length + 1)))) =
              U_cond * (out.work + 1) + K_c2_u * (out.work + 1) +
              (U_cond + K_c2_u) * ((sufOut.totalWork - (accWork + out.work)) + (sufOut.entries.length - (acc.length + 1))) := by ring
          have hU1 : U_cond ≤ U_cond * (out.work + 1) := Nat.le_mul_of_pos_right _ (by omega)
          have hlen_acc : (acc ++ [entry]).length = acc.length + 1 := by simp
          rw [hlen_acc] at hucEnd
          rw [hsplit_w, halg]
          linarith only [huC, hucMid, hucEnd, hU1]
        · dsimp [stAfterCond] at hbcMid
          have hsplit_w : (sufOut.totalWork - accWork) + (sufOut.entries.length - acc.length) =
              (out.work + 1) + ((sufOut.totalWork - (accWork + out.work)) + (sufOut.entries.length - (acc.length + 1))) := by
            omega
          have halg : (B_cond + K_c2_b) * ((out.work + 1) + ((sufOut.totalWork - (accWork + out.work)) + (sufOut.entries.length - (acc.length + 1)))) =
              B_cond * (out.work + 1) + K_c2_b * (out.work + 1) +
              (B_cond + K_c2_b) * ((sufOut.totalWork - (accWork + out.work)) + (sufOut.entries.length - (acc.length + 1))) := by ring
          have hB1 : B_cond ≤ B_cond * (out.work + 1) := Nat.le_mul_of_pos_right _ (by omega)
          have hlen_acc : (acc ++ [entry]).length = acc.length + 1 := by simp
          rw [hlen_acc] at hbcEnd
          rw [hsplit_w, halg]
          linarith only [hbC, hbcMid, hbcEnd, hB1]

open Classical in
/-- Complete Step C execution theorem (`posDimStepCStmt`): handles both `jStar ≤ k` (teardown `c1Stmt`,
iterated `c2Stmt` matching `runSyncSuffixBuild`, and `storeTerminalLeafFromBufRegs`) and `jStar = k + 1`
(cleaning `.heap 9` and upgrading all `PreTriggerLevelInv` to `LevelStoredInv`). -/
theorem exec_posDimStepC
    (h_del_wit : S_claim_A_2_deletion_witness)
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    (hW : natBitLength K_max + natBitLength (2 * s₀_d) + L + 32 ≤ W)
    {C_nodes : ℝ}
    (h51_len : ∀ (P : Finset ℕ), P.card ≤ n →
      ∀ (k : ℕ) (nodes : Fin k → ChainNode d)
        (P₀ : Fin k → Finset ℕ)
        (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
        (age : Fin k → ℕ)
        (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)),
        (∀ i : Fin k,
          (nodes i).o = o i ∧
          (nodes i).V = liftVariance (o i) (s i) ∧
          1 ≤ (P₀ i).card ∧
          IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
            (paraboloidLiftSet (fun j : P₀ i => ltCoords j.1)) (liftedPoint (o i) (s i)) ∧
          HasNodeAge (P₀ i) (chainInput ltCoords nodes P i.castSucc) (age i) ∧
          (age i : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * ((P₀ i).card : ℝ) / 16) →
        (k : ℝ) ≤ C_nodes * (1 / (4 * (s₀_d : ℝ)))⁻¹ * Real.log ((n : ℝ) + 1))
    (hK_bound : C_nodes * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) ≤ (K_max : ℝ))
    {ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d s₀_d)}
    {hist : ExecutionHistory d}
    (hctor_valid : ∀ (ltC : ℕ → EuclideanSpace ℝ (Fin d))
      (acc : List (SyncSuffixPrefixEntry d (PosDimNodeData d s₀_d)))
      (R : Finset ℕ) (bs₁ : List Bool) (out : SyncBuiltNode d (PosDimNodeData d s₀_d)),
      2 * s₀_d - 1 < R.card → R.card ≤ n →
      (∀ lt ∈ R, ltC lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist acc ltC R bs₁ = some out →
        out.node.V = liftVariance out.node.o out.s ∧
        IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
          (paraboloidLiftSet (fun i : R => ltC i.1))
          (liftedPoint out.node.o out.s))
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {c1Stmt c2Stmt : BitRAMStmt} {jSrc : JSource}
    {U_c1 B_c1 K_c2_u K_c2_b : ℕ}
    {P P' : DynamicPointSet d} {ltCoords ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap qMap' : ℕ → Fin d → ℚ} {ws wsB : WordStore} {regsB : ℕ → ℤ}
    {retHVal : ℤ} {slotTriggers : ℕ → Prop} {bs : List Bool}
    {finalNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {rebuildWork : ℕ} {canceledBirthSum : ℕ}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws)
    (hwfP' : P'.WellFormed n)
    (hlt_sync' : ∀ id ∈ P'.activeIds,
      ltCoords' (P'.lifetimeOfId id) = P'.coords id ∧
      P'.coords id = ratPointToEuclidean (qMap' (P'.handleOfId id)))
    (hlt_adm' : ∀ lt < P'.nextLifetime, ltCoords' lt ∈ RatAdmissiblePointSet d B ∨ ltCoords' lt = 0)
    (hlt_preserve : ∀ lt < P.nextLifetime, ltCoords' lt = ltCoords lt)
    (hupd_len : updatedNodes.length = nodes.length)
    (hupd_node : ∀ (j : ℕ) (hj : j < nodes.length),
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).built = (nodes.get ⟨j, hj⟩).built ∧
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).birthPool = (nodes.get ⟨j, hj⟩).birthPool)
    (hno_trig_age : ∀ (j : ℕ) (hj : j < nodes.length),
      ¬ slotTriggers j →
        let vUpd := updatedNodes.get ⟨j, hupd_len ▸ hj⟩
        (vUpd.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (vUpd.birthPool.card : ℝ) / 16)
    (hno_trig_leaf : ¬ slotTriggers nodes.length →
      (chainInput ltCoords' (fun i : Fin nodes.length => (nodes.get i).built.node)
        (activeLifetimes P') (Fin.last nodes.length)).card ≤ 2 * (2 * s₀_d - 1))
    (hmB : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsB)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hbndB : RegBounded W regsB)
    (hrB_k : wsB.read (.heap 0 10) = (nodes.length : ℤ))
    (hrB_00 : wsB.read (.heap 0 0) = retHVal)
    (hrB_106 : wsB.read (.heap 9 106) = (jStarStep nodes.length slotTriggers (nodes.length + 1) : ℤ))
    (hcoordsB : ActiveCoordsStored d L B P'.activeHandles qMap' wsB)
    (htree0B : TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsB)
    (htree1B : TreeStoredAt L 1
      ((chainInput ltCoords' (fun i : Fin nodes.length => (nodes.get i).built.node)
        (activeLifetimes P') (Fin.last nodes.length)).image (handleOfLifetime P'))
      (fun _ => 0) (fun _ => 1) wsB)
    (hpreB : ∀ (j : ℕ) (hj : j < nodes.length),
      PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap'
        (chainInput ltCoords' (fun i : Fin nodes.length => (nodes.get i).built.node)
          (activeLifetimes P') ⟨j, Nat.lt_succ_of_lt hj⟩)
        (updatedNodes.get ⟨j, hupd_len ▸ hj⟩) j wsB)
    (hemptyB : ∀ j : ℕ, nodes.length ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j wsB)
    (hclean58B : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7 ∨ t = 8) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsB.live)
    (hclean9B : ∀ z : ℤ, z ≠ 102 → z ≠ 103 → z ≠ 104 → z ≠ 105 → z ≠ 106 → (.heap 9 z : RAMCellLoc) ∉ wsB.live)
    -- Sync step outcome correspondence:
    (hsync_branch :
      let jStar := jStarStep nodes.length slotTriggers (nodes.length + 1)
      if hTrig : ∃ j ≤ nodes.length, slotTriggers j then
        ∃ sufOut : SyncSuffixOutcome d (PosDimNodeData d s₀_d),
          let S_trig := chainInput ltCoords' (fun i : Fin nodes.length => (nodes.get i).built.node)
            (activeLifetimes P') ⟨jStar, Nat.lt_succ_of_le ((jStarStep_final nodes.length slotTriggers).1 hTrig).2.1⟩
          runSyncSuffixBuild ctor (2 * s₀_d - 1) hist ltCoords' S_trig bs = some sufOut ∧
          finalNodes = updatedNodes.take jStar ++ entriesToLiveNodes sufOut.entries ∧
          rebuildWork = sufOut.totalWork
      else
        bs = [] ∧ finalNodes = updatedNodes ∧ rebuildWork = 0)
    -- StepC1 specification (when `jStar ≤ nodes.length`):
    (hStepC1 : ∀ (hTrig : ∃ j ≤ nodes.length, slotTriggers j),
      let jStar := jStarStep nodes.length slotTriggers (nodes.length + 1)
      let hjLe : jStar ≤ nodes.length := ((jStarStep_final nodes.length slotTriggers).1 hTrig).2.1
      let S_trig := chainInput ltCoords' (fun i : Fin nodes.length => (nodes.get i).built.node)
        (activeLifetimes P') ⟨jStar, Nat.lt_succ_of_le hjLe⟩
      ∃ wsC1 regsC1,
        RegExec inp fd W C_cell C_bit c1Stmt wsB regsB wsC1 regsC1
          (U_c1 * (canceledBirthSum + 1)) (B_c1 * (canceledBirthSum + 1)) ∧
        RegBounded W regsC1 ∧
        MidSuffixChainInv n L B B_cert K_max W P' ltCoords'
          (updatedNodes.take jStar) qMap' retHVal S_trig wsC1 ∧
        StdBufLoopExtra jSrc L P' (updatedNodes.take jStar).length S_trig wsC1 regsC1)
    -- StepC2 specification (single outer-loop body step):
    (hStepC2 : ∀ (prefNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)))
      (acc : List (SyncSuffixPrefixEntry d (PosDimNodeData d s₀_d)))
      (R : Finset ℕ) (wsHeap : WordStore) (regs : ℕ → ℤ)
      (bs₁ tailBits : List Bool) (out : SyncBuiltNode d (PosDimNodeData d s₀_d))
      (st : BitRAMExecState),
      let curNodes := prefNodes ++ entriesToLiveNodes acc
      let j := curNodes.length
      j < K_max →
      2 * s₀_d ≤ R.card → R.card ≤ n →
      R ⊆ activeLifetimes P' →
      (∀ lt ∈ R, lt < P'.nextLifetime ∧ ltCoords' lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist acc ltCoords' R bs₁ = some out →
      MidSuffixChainInv n L B B_cert K_max W P' ltCoords' curNodes qMap' retHVal R wsHeap →
      StdBufLoopExtra jSrc L P' j R wsHeap regs →
      st.frameDepth = fd →
      HasRegFrame fd wsHeap regs st.words →
      RegBounded W regs →
      st.remainingBits = bs₁ ++ tailBits →
      st.peakCellSpace ≤ C_cell →
      st.peakBitSpace ≤ C_bit →
      let vNew : SyncLiveChainNode d (PosDimNodeData d s₀_d) :=
        { built := out, birthPool := R, ageUpdateSteps := ∅ }
      let R' := out.node.residual ltCoords' R
      ∃ (st' : BitRAMExecState) (wsHeap' : WordStore) (regs' : ℕ → ℤ),
        RunsTo inp [.stmt c2Stmt] st st' ∧
        st'.frameDepth = fd ∧
        HasRegFrame fd wsHeap' regs' st'.words ∧
        RegBounded W regs' ∧
        st'.remainingBits = tailBits ∧
        st'.unitCost ≤ st.unitCost + K_c2_u * (out.work + 1) ∧
        st'.bitCost ≤ st.bitCost + K_c2_b * (out.work + 1) ∧
        st'.peakCellSpace ≤ C_cell ∧
        st'.peakBitSpace ≤ C_bit ∧
        MidSuffixChainInv n L B B_cert K_max W P' ltCoords' (curNodes ++ [vNew]) qMap' retHVal R' wsHeap' ∧
        StdBufLoopExtra jSrc L P' (j + 1) R' wsHeap' regs')
    (stB : BitRAMExecState)
    (hfdB : stB.frameDepth = fd)
    (hrfB : HasRegFrame fd wsB regsB stB.words)
    (hbitsB : stB.remainingBits = bs)
    (hpCB : stB.peakCellSpace ≤ C_cell)
    (hpBB : stB.peakBitSpace ≤ C_bit) :
    ∃ (stC : BitRAMExecState) (wsC : WordStore) (regsC : ℕ → ℤ),
      RunsTo inp [.stmt (posDimStepCStmt c1Stmt (defaultSuffixLoopCond s₀_d) c2Stmt (storeTerminalLeafFromBufRegs L jSrc))]
        stB stC ∧
      stC.frameDepth = fd ∧
      HasRegFrame fd wsC regsC stC.words ∧
      RegBounded W regsC ∧
      stC.remainingBits = [] ∧
      ChainStoredInv n L B B_cert K_max W P' ltCoords' finalNodes qMap' wsC ∧
      wsC.read (.heap 0 0) = retHVal ∧
      stC.peakCellSpace ≤ C_cell ∧
      stC.peakBitSpace ≤ C_bit ∧
      stC.unitCost ≤ stB.unitCost + U_c1 * (canceledBirthSum + 1) + (5 + K_c2_u) * (rebuildWork + K_max) +
        (2 * s₀_d) * (420 * L + 340) + 3500 ∧
      stC.bitCost ≤ stB.bitCost + B_c1 * (canceledBirthSum + 1) + (4 * W + 24 + K_c2_b) * (rebuildWork + K_max) +
        (2 * s₀_d) * (66 * L + 96) * W * W + 4300 * W := by
  have ⟨hL2, _, h2n_pow, _⟩ := clog_two_mul_bounds hn
  rw [← hL] at hL2 h2n_pow
  have hW32 : 32 ≤ W := by omega
  set jStar := jStarStep nodes.length slotTriggers (nodes.length + 1)
  have hjS_le_k1 : jStar ≤ nodes.length + 1 := (jStarStep_spec nodes.length slotTriggers (nodes.length + 1) le_rfl).1
  -- Evaluate outer `.ite` condition `.intLe (.readHeap 9 (.lit 106)) (.readHeap 0 (.lit 10))`
  rcases hcond : evalBitCond inp stB.frameDepth stB.words (.intLe (.readHeap 9 (.lit 106)) (.readHeap 0 (.lit 10))) with ⟨flag, uI, bI⟩
  have hcond_spec : flag = decide (jStar ≤ nodes.length) ∧ uI ≤ 7 ∧ bI ≤ 4 * W + 32 := by
    rw [hfdB] at hcond
    simp only [evalBitCond, evalIntExpr, hrfB.read_heap 9 106, hrfB.read_heap 0 10, hrB_106, hrB_k] at hcond
    have hl106 : intBitLength (106 : ℤ) = 8 := by decide
    have hl10 : intBitLength (10 : ℤ) = 5 := by decide
    have ht9 : natBitLength 9 = 4 := by decide
    have ht0 : natBitLength 0 = 1 := by decide
    have hjS_bl : intBitLength (jStar : ℤ) ≤ W := by
      have h1 := intBitLength_ofNat_le jStar
      have h2 := natBitLength_mono (hjS_le_k1.trans (Nat.add_le_add_right hinv.hk_le 1))
      have h3 := natBitLength_add_le K_max 1
      have : natBitLength 1 = 1 := by decide
      omega
    have hk_bl : intBitLength (nodes.length : ℤ) ≤ W := by
      have h1 := intBitLength_ofNat_le nodes.length
      have h2 := natBitLength_mono hinv.hk_le
      omega
    rcases Prod.mk.inj hcond with ⟨hfl, hub⟩
    rcases Prod.mk.inj hub with ⟨rfl, rfl⟩
    have hiff : ((jStar : ℤ) ≤ (nodes.length : ℤ)) ↔ (jStar ≤ nodes.length) := by exact_mod_cast Iff.rfl
    exact ⟨hfl.symm.trans (decide_eq_decide.mpr hiff), by omega, by omega⟩
  let stMid0 : BitRAMExecState := { stB with unitCost := stB.unitCost + uI, bitCost := stB.bitCost + bI }
  by_cases hTrig : ∃ j ≤ nodes.length, slotTriggers j
  · -- Triggered branch (`jStar ≤ nodes.length`)
    have hjLe : jStar ≤ nodes.length := ((jStarStep_final nodes.length slotTriggers).1 hTrig).2.1
    rw [dif_pos hTrig] at hsync_branch
    rcases hsync_branch with ⟨sufOut, hbuild_suf, hfinal_eq, hreb_eq⟩
    obtain ⟨wsC1, regsC1, sC1, hbndC1, hmidC1, hextraC1⟩ := hStepC1 hTrig
    obtain ⟨stAfterC1, hrunC1, hrfC1, _, hfdC1, hbitsC1, hucC1, hbcC1, hpCC1, hpBC1⟩ :=
      sC1 stMid0 hfdB hrfB hpCB hpBB
    -- Run outer `whileLoop`
    have hl_leaf : intBitLength (((2 * s₀_d - 1 : ℕ) : ℤ)) ≤ W := by
      have h1 := intBitLength_ofNat_le (2 * s₀_d - 1)
      have h2 := natBitLength_mono (by omega : 2 * s₀_d - 1 ≤ 2 * s₀_d)
      omega
    have hbits_nil_app : stAfterC1.remainingBits = bs ++ [] := by
      rw [hbitsC1, hbitsB, List.append_nil]
    obtain ⟨stAfterLoop, wsLoop, regsLoop, hrunLoop, hfdLoop, hrfLoop, hbndLoop, hbitsLoop,
      hleaf_le, _, hucLoop, hbcLoop, hpCLoop, hpBLoop, hmidLoop, hextraLoop⟩ :=
      exec_posDimStepC3_while hs₀1 h51_len hK_bound (hctor_valid ltCoords')
        (U_cond := 5) (B_cond := 4 * W + 24)
        (fun j R wsHeap ws regs _ hRn hrf _ hextra => by
          have hM_bl : intBitLength (R.card : ℤ) ≤ W := by
            have h1 := intBitLength_ofNat_le R.card
            have h2 := natBitLength_mono (by omega : R.card ≤ 2 ^ L)
            have h3 : natBitLength (2 ^ L) ≤ L + 1 := by
              unfold natBitLength; rw [Nat.log_pow (by decide)]
            omega
          exact eval_defaultSuffixLoopCond inp hs₀1 hl_leaf hM_bl hrf hextra.2.2.1)
        hStepC2
        (updatedNodes.take jStar) _ [] _ 0 bs [] sufOut wsC1 regsC1 stAfterC1
        hbuild_suf
        (by simpa [entriesToLiveNodes] using hmidC1)
        (by simpa [entriesToLiveNodes] using hextraC1)
        hfdC1 hrfC1 hbndC1 hbits_nil_app hpCC1 hpBC1
    -- Run `storeTerminalLeafFromBufRegs L jSrc`
    obtain ⟨wsEnd, regsEnd, sEpi, hinvEnd, hbndEnd, hrEnd_00⟩ :=
      exec_storeTerminalLeafFromBufRegs hn hL (by omega) hfd_le hmidLoop hcCeil hbCeil hbndLoop hextraLoop hleaf_le
    obtain ⟨stEnd, hrunEpi, hrfEnd, _, hfdEnd, hbitsEnd, hucEpi, hbcEpi, hpCEnd, hpBEnd⟩ :=
      sEpi stAfterLoop hfdLoop hrfLoop hpCLoop hpBLoop
    have hrunBranch := RunsTo.seq hrunC1 (RunsTo.seq hrunLoop hrunEpi)
    have hrunIte : RunsTo inp [.stmt (posDimStepCStmt c1Stmt (defaultSuffixLoopCond s₀_d) c2Stmt (storeTerminalLeafFromBufRegs L jSrc))]
        stB stEnd := by
      apply RunsTo.ite
      rw [hcond, hcond_spec.1, decide_eq_true hjLe]
      exact hrunBranch
    rw [← hfinal_eq] at hinvEnd
    have hlen_suf_le : sufOut.entries.length ≤ K_max := by
      have hfk := hinvEnd.hk_le
      rw [hfinal_eq, List.length_append, entriesToLiveNodes, List.length_map] at hfk
      omega
    have hR1_le : sufOut.terminalLeaf.card + 1 ≤ 2 * s₀_d := by omega
    refine ⟨stEnd, wsEnd, regsEnd, hrunIte, hfdEnd, hrfEnd, hbndEnd, hbitsEnd.trans hbitsLoop,
      hinvEnd, hrEnd_00, hpCEnd, hpBEnd, ?_, ?_⟩
    · dsimp [stMid0] at hucC1
      simp only [Nat.sub_zero, List.length_nil] at hucLoop
      have hm1 : (sufOut.terminalLeaf.card + 1) * (420 * L + 340) ≤ (2 * s₀_d) * (420 * L + 340) :=
        Nat.mul_le_mul_right _ hR1_le
      have hm2 : (5 + K_c2_u) * (sufOut.totalWork + sufOut.entries.length) ≤
          (5 + K_c2_u) * (rebuildWork + K_max) :=
        Nat.mul_le_mul_left _ (by omega)
      linarith only [hcond_spec.2.1, hucC1, hucLoop, hucEpi, hm1, hm2]
    · dsimp [stMid0] at hbcC1
      simp only [Nat.sub_zero, List.length_nil] at hbcLoop
      have hm1 : (sufOut.terminalLeaf.card + 1) * (66 * L + 96) * W * W ≤ (2 * s₀_d) * (66 * L + 96) * W * W := by
        have : (sufOut.terminalLeaf.card + 1) * (66 * L + 96) ≤ (2 * s₀_d) * (66 * L + 96) :=
          Nat.mul_le_mul_right _ hR1_le
        exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ this)
      have hm2 : (4 * W + 24 + K_c2_b) * (sufOut.totalWork + sufOut.entries.length) ≤
          (4 * W + 24 + K_c2_b) * (rebuildWork + K_max) :=
        Nat.mul_le_mul_left _ (by omega)
      linarith only [hcond_spec.2.2, hbcC1, hbcLoop, hbcEpi, hm1, hm2, hW32]
  · -- No-trigger branch (`jStar = nodes.length + 1`)
    obtain ⟨hjS_eq, hnTrig⟩ := (jStarStep_final nodes.length slotTriggers).2 hTrig
    have hnLe : ¬ (jStar ≤ nodes.length) := by omega
    rw [dif_neg hTrig] at hsync_branch
    rcases hsync_branch with ⟨hbs_nil, hfinal_eq, hreb_eq⟩
    obtain ⟨wsC, regsC, sNoTrig, hinvC, hbndC, hrC_00⟩ :=
      exec_posDimStepC_noTrigger h_del_wit hd1 hs₀1 (by omega) hfd_le
        hinv hwfP' hlt_sync' hlt_adm' hlt_preserve hupd_len hupd_node
        hno_trig_age hno_trig_leaf hnTrig hmB hcCeil hbCeil hbndB
        hrB_k hrB_00 hcoordsB htree0B htree1B hpreB hemptyB hclean58B hclean9B
    obtain ⟨stEnd, hrunClean, hrfEnd, _, hfdEnd, hbitsEnd, hucEnd, hbcEnd, hpCEnd, hpBEnd⟩ :=
      sNoTrig stMid0 hfdB hrfB hpCB hpBB
    have hrunIte : RunsTo inp [.stmt (posDimStepCStmt c1Stmt (defaultSuffixLoopCond s₀_d) c2Stmt (storeTerminalLeafFromBufRegs L jSrc))]
        stB stEnd := by
      apply RunsTo.ite
      rw [hcond, hcond_spec.1, decide_eq_false hnLe]
      exact hrunClean
    rw [← hfinal_eq] at hinvC
    refine ⟨stEnd, wsC, regsC, hrunIte, hfdEnd, hrfEnd, hbndC,
      by rw [hbitsEnd]; dsimp [stMid0]; rw [hbitsB, hbs_nil],
      hinvC, hrC_00, hpCEnd, hpBEnd, ?_, ?_⟩
    · dsimp [stMid0] at hucEnd
      have h1 : stEnd.unitCost ≤ stB.unitCost + 3500 := by linarith only [hcond_spec.2.1, hucEnd]
      omega
    · dsimp [stMid0] at hbcEnd
      have h1 : stEnd.bitCost ≤ stB.bitCost + 4300 * W := by linarith only [hcond_spec.2.2, hbcEnd, hW32]
      omega

end UL.C12LVE
