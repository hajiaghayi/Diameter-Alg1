import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H1_Easy
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b_StepB
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

private lemma nonneg_le_of_sq_le_sq {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (h : a ^ 2 ≤ b ^ 2) :
    a ≤ b := by
  nlinarith only [ha, hb, h]

/-! ### 1. Representation-Independent Real Winner Tree `realTreeVal` -/

noncomputable def realTreeVal (S : Finset ℕ) (w : ℕ → ℝ) : ℕ → ℕ → ℕ × ℕ × ℝ
  | 0, h => if h ∈ S then (1, h, w h) else (0, 0, 0)
  | k + 1, off =>
      let (cL, hL, vL) := realTreeVal S w k (2 * off)
      let (cR, hR, vR) := realTreeVal S w k (2 * off + 1)
      if cL = 0 then (cR, hR, vR)
      else if cR = 0 then (cL, hL, vL)
      else if vR ≤ vL then (cL + cR, hL, vL)
      else (cL + cR, hR, vR)

theorem treeSubSet_subset (S : Finset ℕ) (k off : ℕ) :
    treeSubSet S k off ⊆ S :=
  Finset.filter_subset _ _

theorem treeNodeVal_eq_realTreeVal {S : Finset ℕ} {rNum rDen : ℕ → ℤ} {w : ℕ → ℝ}
    (hDen : ∀ h ∈ S, 1 ≤ rDen h)
    (hw : ∀ h ∈ S, ((rNum h : ℝ) / (rDen h : ℝ)) = w h) :
    ∀ (k off : ℕ),
      (treeNodeVal S rNum rDen k off).1 = (realTreeVal S w k off).1 ∧
      (treeNodeVal S rNum rDen k off).2.1 = (realTreeVal S w k off).2.1 ∧
      (0 < (treeNodeVal S rNum rDen k off).1 →
        ((treeNodeVal S rNum rDen k off).2.2.1 : ℝ) / ((treeNodeVal S rNum rDen k off).2.2.2 : ℝ) =
          (realTreeVal S w k off).2.2)
  | 0, h => by
      simp only [treeNodeVal, realTreeVal]
      split_ifs with hh
      · exact ⟨rfl, rfl, fun _ => hw h hh⟩
      · exact ⟨rfl, rfl, fun hc => absurd hc (Nat.lt_irrefl 0)⟩
  | k + 1, off => by
      obtain ⟨ihL1, ihL2, ihL3⟩ := treeNodeVal_eq_realTreeVal hDen hw k (2 * off)
      obtain ⟨ihR1, ihR2, ihR3⟩ := treeNodeVal_eq_realTreeVal hDen hw k (2 * off + 1)
      have hwL := treeNodeVal_winner rNum hDen k (2 * off)
      have hwR := treeNodeVal_winner rNum hDen k (2 * off + 1)
      rcases htnL : treeNodeVal S rNum rDen k (2 * off) with ⟨cL, hLv, nL, dL⟩
      rcases htnR : treeNodeVal S rNum rDen k (2 * off + 1) with ⟨cR, hRv, nR, dR⟩
      rcases hrtL : realTreeVal S w k (2 * off) with ⟨rcL, rhL, vL⟩
      rcases hrtR : realTreeVal S w k (2 * off + 1) with ⟨rcR, rhR, vR⟩
      simp only [htnL, hrtL] at ihL1 ihL2 ihL3 hwL
      simp only [htnR, hrtR] at ihR1 ihR2 ihR3 hwR
      subst ihL1; subst ihL2; subst ihR1; subst ihR2
      simp only [treeNodeVal, realTreeVal, htnL, htnR, hrtL, hrtR]
      by_cases hcL0 : cL = 0
      · rw [if_pos hcL0, if_pos hcL0]; exact ⟨rfl, rfl, ihR3⟩
      · rw [if_neg hcL0, if_neg hcL0]
        by_cases hcR0 : cR = 0
        · rw [if_pos hcR0, if_pos hcR0]; exact ⟨rfl, rfl, ihL3⟩
        · simp only [hcR0, ↓reduceIte]
          have hcL_pos : 0 < cL := Nat.pos_of_ne_zero hcL0
          have hcR_pos : 0 < cR := Nat.pos_of_ne_zero hcR0
          obtain ⟨hLv_in, rfl, rfl, _⟩ := hwL hcL_pos
          obtain ⟨hRv_in, rfl, rfl, _⟩ := hwR hcR_pos
          have hdL1 : 1 ≤ rDen hLv := hDen hLv (treeSubSet_subset S k (2 * off) hLv_in)
          have hdR1 : 1 ≤ rDen hRv := hDen hRv (treeSubSet_subset S k (2 * off + 1) hRv_in)
          have hdL_pos : (0 : ℝ) < (rDen hLv : ℝ) := by exact_mod_cast lt_of_lt_of_le zero_lt_one hdL1
          have hdR_pos : (0 : ℝ) < (rDen hRv : ℝ) := by exact_mod_cast lt_of_lt_of_le zero_lt_one hdR1
          have hvL_eq := ihL3 hcL_pos
          have hvR_eq := ihR3 hcR_pos
          have hcmp : (rNum hRv * rDen hLv ≤ rNum hLv * rDen hRv) ↔ (vR ≤ vL) := by
            rw [← hvR_eq, ← hvL_eq, div_le_div_iff₀ hdR_pos hdL_pos]
            exact_mod_cast Iff.rfl
          by_cases hle : vR ≤ vL
          · rw [if_pos (hcmp.mpr hle), if_pos hle]
            exact ⟨rfl, rfl, fun _ => hvL_eq⟩
          · rw [if_neg (fun h => hle (hcmp.mp h)), if_neg hle]
            exact ⟨rfl, rfl, fun _ => hvR_eq⟩

/-! ### 2. `chainInput` Bijection & `indexedEuclideanDiam` Invariance -/

theorem chainInput_image_eq {d : ℕ} {α β : Type*} [DecidableEq α] [DecidableEq β] {k : ℕ}
    (pts : α → EuclideanSpace ℝ (Fin d)) (g : β → EuclideanSpace ℝ (Fin d))
    (nodes : Fin k → ChainNode d) (A : Finset α) (f : α → β)
    (hfg : ∀ x ∈ A, g (f x) = pts x) (j : Fin (k + 1)) :
    (chainInput pts nodes A j).image f = chainInput g nodes (A.image f) j := by
  ext y
  simp only [Finset.mem_image, mem_chainInput_iff, Finset.mem_image]
  constructor
  · rintro ⟨x, ⟨hxA, hall⟩, rfl⟩
    exact ⟨⟨x, hxA, rfl⟩, fun i hi => by rw [hfg x hxA]; exact hall i hi⟩
  · rintro ⟨⟨x, hxA, rfl⟩, hall⟩
    exact ⟨x, ⟨hxA, fun i hi => by rw [← hfg x hxA]; exact hall i hi⟩, rfl⟩

theorem indexedEuclideanDiam_image_eq {d : ℕ} {α β : Type*} [DecidableEq β]
    (I : Finset α) (pts : α → EuclideanSpace ℝ (Fin d))
    (g : β → EuclideanSpace ℝ (Fin d)) (f : α → β)
    (hfg : ∀ x ∈ I, g (f x) = pts x) :
    indexedEuclideanDiam (I.image f) g = indexedEuclideanDiam I pts := by
  by_cases hne : I.Nonempty
  · have hne_img : (I.image f).Nonempty := hne.image f
    apply le_antisymm
    · conv_lhs => unfold indexedEuclideanDiam; rw [dif_pos hne_img]
      apply Finset.sup'_le
      rintro ⟨y, z⟩ hyz
      rcases Finset.mem_product.mp hyz with ⟨hy, hz⟩
      rcases Finset.mem_image.mp hy with ⟨x₁, hx₁, rfl⟩
      rcases Finset.mem_image.mp hz with ⟨x₂, hx₂, rfl⟩
      dsimp only
      rw [hfg x₁ hx₁, hfg x₂ hx₂]
      exact norm_le_indexedEuclideanDiam pts hx₁ hx₂
    · conv_lhs => unfold indexedEuclideanDiam; rw [dif_pos hne]
      apply Finset.sup'_le
      rintro ⟨x₁, x₂⟩ hxy
      rcases Finset.mem_product.mp hxy with ⟨hx₁, hx₂⟩
      dsimp only
      rw [← hfg x₁ hx₁, ← hfg x₂ hx₂]
      exact norm_le_indexedEuclideanDiam g
        (Finset.mem_image_of_mem f hx₁) (Finset.mem_image_of_mem f hx₂)
  · have hemp : I = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
    subst hemp
    simp [indexedEuclideanDiam]

/-! ### 3. Pure Candidate Folding (`stepBestPair`, `foldBestPairs`, `ramCheckedAnswer`) -/

noncomputable def handleDistSq {d : ℕ} (P : DynamicPointSet d) (p : ℕ × ℕ) : ℝ :=
  euclideanDistSq (P.coords (P.idOfHandle p.1)) (P.coords (P.idOfHandle p.2))

noncomputable def stepBestPair {d : ℕ} (P : DynamicPointSet d) (cur cand : ℕ × ℕ) : ℕ × ℕ :=
  open Classical in
  if cand.1 ∈ P.activeHandles ∧ cand.2 ∈ P.activeHandles ∧ cand.1 ≠ cand.2 ∧
      handleDistSq P cur < handleDistSq P cand then
    cand
  else
    cur

theorem stepBestPair_valid {d : ℕ} {P : DynamicPointSet d} {cur cand : ℕ × ℕ}
    (hcur : cur.1 ∈ P.activeHandles ∧ cur.2 ∈ P.activeHandles ∧ cur.1 ≠ cur.2) :
    let nxt := stepBestPair P cur cand
    nxt.1 ∈ P.activeHandles ∧ nxt.2 ∈ P.activeHandles ∧ nxt.1 ≠ nxt.2 := by
  dsimp [stepBestPair]
  split_ifs with h
  · exact ⟨h.1, h.2.1, h.2.2.1⟩
  · exact hcur

theorem stepBestPair_mono {d : ℕ} (P : DynamicPointSet d) (cur cand : ℕ × ℕ) :
    handleDistSq P cur ≤ handleDistSq P (stepBestPair P cur cand) := by
  dsimp [stepBestPair]
  split_ifs with h
  · exact le_of_lt h.2.2.2
  · exact le_rfl

theorem stepBestPair_ge_cand {d : ℕ} {P : DynamicPointSet d} (cur : ℕ × ℕ) {cand : ℕ × ℕ}
    (hcand : cand.1 ∈ P.activeHandles ∧ cand.2 ∈ P.activeHandles ∧ cand.1 ≠ cand.2) :
    handleDistSq P cand ≤ handleDistSq P (stepBestPair P cur cand) := by
  dsimp [stepBestPair]
  split_ifs with h
  · exact le_rfl
  · have hnlt : ¬ handleDistSq P cur < handleDistSq P cand :=
      fun hlt => h ⟨hcand.1, hcand.2.1, hcand.2.2, hlt⟩
    exact not_lt.mp hnlt

noncomputable def foldBestPairs {d : ℕ} (P : DynamicPointSet d)
    (init : ℕ × ℕ) (cands : List (ℕ × ℕ)) : ℕ × ℕ :=
  cands.foldl (stepBestPair P) init

theorem foldBestPairs_valid {d : ℕ} {P : DynamicPointSet d} {init : ℕ × ℕ}
    (cands : List (ℕ × ℕ))
    (hinit : init.1 ∈ P.activeHandles ∧ init.2 ∈ P.activeHandles ∧ init.1 ≠ init.2) :
    let res := foldBestPairs P init cands
    res.1 ∈ P.activeHandles ∧ res.2 ∈ P.activeHandles ∧ res.1 ≠ res.2 := by
  induction cands generalizing init with
  | nil => exact hinit
  | cons c cs ih => exact ih (stepBestPair_valid hinit)

theorem foldBestPairs_mono {d : ℕ} (P : DynamicPointSet d) (init : ℕ × ℕ) (cands : List (ℕ × ℕ)) :
    handleDistSq P init ≤ handleDistSq P (foldBestPairs P init cands) := by
  induction cands generalizing init with
  | nil => exact le_rfl
  | cons c cs ih => exact (stepBestPair_mono P init c).trans (ih (stepBestPair P init c))

theorem foldBestPairs_ge_mem {d : ℕ} {P : DynamicPointSet d} (init : ℕ × ℕ)
    {cands : List (ℕ × ℕ)} {c : ℕ × ℕ} (hmem : c ∈ cands)
    (hc : c.1 ∈ P.activeHandles ∧ c.2 ∈ P.activeHandles ∧ c.1 ≠ c.2) :
    handleDistSq P c ≤ handleDistSq P (foldBestPairs P init cands) := by
  induction cands generalizing init with
  | nil => cases hmem
  | cons x xs ih =>
      rcases List.mem_cons.mp hmem with rfl | htail
      · exact (stepBestPair_ge_cand init hc).trans (foldBestPairs_mono P (stepBestPair P init c) xs)
      · exact ih (stepBestPair P init x) htail

noncomputable def levelScanCands {d s₀_d : ℕ} (L : ℕ) (P : DynamicPointSet d)
    (nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))) (j : Fin nodes.length) :
    List (ℕ × ℕ) :=
  open Classical in
  let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
  let S_j_h := chainInput (fun h => P.coords (P.idOfHandle h)) vecNodes P.activeHandles j.castSucc
  let v := nodes.get j
  let B_int := intactBlocksOf v P
  if S_j_h.Nonempty then
    if hBi : B_int.Nonempty then
      let y_h := (realTreeVal S_j_h (fun h => ‖P.coords (P.idOfHandle h) - v.built.node.o‖ ^ 2) L 0).2.1
      let b_min := B_int.min' hBi
      if hb_lt : b_min < v.built.aux.k_blk then
        (List.finRange s₀_d).map (fun t => (v.built.aux.birthHandles ⟨b_min, hb_lt⟩ t, y_h))
      else
        []
    else
      []
  else
    []

noncomputable def leafScanCands {d s₀_d : ℕ} (P : DynamicPointSet d)
    (nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))) : List (ℕ × ℕ) :=
  let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
  let S_k_h := chainInput (fun h => P.coords (P.idOfHandle h)) vecNodes P.activeHandles (Fin.last nodes.length)
  (List.range S_k_h.card).flatMap (fun a =>
    (List.range S_k_h.card).map (fun b => (minPopElem S_k_h a, minPopElem S_k_h b)))

noncomputable def ramScanCandidates {d s₀_d : ℕ} (L : ℕ) (P : DynamicPointSet d)
    (nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))) : List (ℕ × ℕ) :=
  ((List.finRange nodes.length).flatMap (levelScanCands L P nodes)) ++ leafScanCands P nodes

noncomputable def twoMinHandles (S : Finset ℕ) (h2 : 2 ≤ S.card) : ℕ × ℕ :=
  have hne1 : S.Nonempty := Finset.card_pos.mp (by clear * - h2; omega)
  let h₁ := S.min' hne1
  have hne2 : (S.erase h₁).Nonempty := Finset.card_pos.mp (by
    rw [Finset.card_erase_of_mem (Finset.min'_mem S hne1)]; clear * - h2; omega)
  (h₁, (S.erase h₁).min' hne2)

theorem twoMinHandles_spec {S : Finset ℕ} (h2 : 2 ≤ S.card) :
    let p := twoMinHandles S h2
    p.1 ∈ S ∧ p.2 ∈ S ∧ p.1 ≠ p.2 := by
  dsimp [twoMinHandles]
  set hne1 : S.Nonempty := Finset.card_pos.mp (by clear * - h2; omega)
  set h₁ := S.min' hne1
  set hne2 : (S.erase h₁).Nonempty := Finset.card_pos.mp (by
    rw [Finset.card_erase_of_mem (Finset.min'_mem S hne1)]; clear * - h2; omega)
  have hm2 := Finset.min'_mem (S.erase h₁) hne2
  exact ⟨Finset.min'_mem S hne1, Finset.mem_of_mem_erase hm2, (Finset.mem_erase.mp hm2).1.symm⟩

noncomputable def ramCheckedAnswer {d s₀_d : ℕ} (L : ℕ) (P : DynamicPointSet d)
    (nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))) : StoredDiameterAnswer :=
  if h2 : 2 ≤ P.activeHandles.card then
    let best := foldBestPairs P (twoMinHandles P.activeHandles h2) (ramScanCandidates L P nodes)
    { diameterHandles := some best, cachedDistSq := handleDistSq P best }
  else
    { diameterHandles := none, cachedDistSq := 0 }

/-! ### 4. Fallback Answer & `ansPolPosDim` Policy Validity -/

noncomputable def fallbackValidAnswer {d : ℕ} (P : DynamicPointSet d) : StoredDiameterAnswer :=
  open Classical in
  if h : ∃ ans : StoredDiameterAnswer, IsValidFactorCAnswer (Real.sqrt 2) P ans then
    Classical.choose h
  else
    { diameterHandles := none, cachedDistSq := 0 }

theorem exists_validFactorCAnswer {d n : ℕ} (P : DynamicPointSet d) (hwf : P.WellFormed n) :
    ∃ ans : StoredDiameterAnswer, IsValidFactorCAnswer (Real.sqrt 2) P ans := by
  by_cases hle1 : P.activeIds.card ≤ 1
  · exact ⟨{ diameterHandles := none, cachedDistSq := 0 }, by simp [IsValidFactorCAnswer, hle1]⟩
  · have hne : P.activeIds.Nonempty := Finset.card_pos.mp (by clear * - hle1; omega)
    obtain ⟨xy, hxy, hsup⟩ :=
      Finset.exists_mem_eq_sup' (hne.product hne) (fun xy : ℕ × ℕ => ‖P.coords xy.1 - P.coords xy.2‖)
    rcases Finset.mem_product.mp hxy with ⟨hid₁, hid₂⟩
    have hdiam_eq : P.diam = ‖P.coords xy.1 - P.coords xy.2‖ := by
      unfold DynamicPointSet.diam indexedEuclideanDiam
      rw [dif_pos hne, hsup]
    by_cases hne_id : xy.1 ≠ xy.2
    · let h₁ := P.handleOfId xy.1
      let h₂ := P.handleOfId xy.2
      have hh₁ := hwf.2.1 xy.1 hid₁
      have hh₂ := hwf.2.1 xy.2 hid₂
      have hne_h : h₁ ≠ h₂ := fun heq => hne_id (by have hc := congrArg P.idOfHandle heq; dsimp [h₁, h₂] at hc; rw [hh₁.2, hh₂.2] at hc; exact hc)
      refine ⟨{ diameterHandles := some (h₁, h₂)
                cachedDistSq := euclideanDistSq (P.coords xy.1) (P.coords xy.2) }, ?_⟩
      unfold IsValidFactorCAnswer; rw [if_neg hle1]
      refine ⟨h₁, h₂, rfl, hh₁.1, hh₂.1, hne_h, by dsimp [h₁, h₂]; rw [hh₁.2, hh₂.2], ?_⟩
      rw [hh₁.2, hh₂.2]
      refine ⟨hid₁, hid₂, hne_id, ?_, norm_le_indexedEuclideanDiam P.coords hid₁ hid₂⟩
      change P.diam / Real.sqrt 2 ≤ ‖P.coords xy.1 - P.coords xy.2‖
      rw [← hdiam_eq]
      have hsq2_ge1 : (1 : ℝ) ≤ Real.sqrt 2 := by
        rw [← Real.sqrt_one]; exact Real.sqrt_le_sqrt (by norm_num)
      exact div_le_self (indexedEuclideanDiam_nonneg P.activeIds P.coords) hsq2_ge1
    · push_neg at hne_id
      have hdiam0 : P.diam = 0 := by rw [hdiam_eq, hne_id]; simp
      obtain ⟨id₁, hid₁', id₂, hid₂', hne12⟩ := Finset.one_lt_card.mp (Nat.lt_of_not_ge hle1)
      let h₁ := P.handleOfId id₁
      let h₂ := P.handleOfId id₂
      have hh₁ := hwf.2.1 id₁ hid₁'
      have hh₂ := hwf.2.1 id₂ hid₂'
      have hne_h : h₁ ≠ h₂ := fun heq => hne12 (by have hc := congrArg P.idOfHandle heq; dsimp [h₁, h₂] at hc; rw [hh₁.2, hh₂.2] at hc; exact hc)
      refine ⟨{ diameterHandles := some (h₁, h₂)
                cachedDistSq := euclideanDistSq (P.coords id₁) (P.coords id₂) }, ?_⟩
      unfold IsValidFactorCAnswer; rw [if_neg hle1]
      refine ⟨h₁, h₂, rfl, hh₁.1, hh₂.1, hne_h, by dsimp [h₁, h₂]; rw [hh₁.2, hh₂.2], ?_⟩
      rw [hh₁.2, hh₂.2]
      refine ⟨hid₁', hid₂', hne12, ?_, norm_le_indexedEuclideanDiam P.coords hid₁' hid₂'⟩
      change P.diam / Real.sqrt 2 ≤ ‖P.coords id₁ - P.coords id₂‖
      rw [hdiam0, zero_div]; exact norm_nonneg _

noncomputable def ansPolPosDim (d s₀_d L : ℕ) :
    SyncCheckedAnswerPolicy d (PosDimNodeData d s₀_d) where
  allocHandle := mexHandle
  checkedAnswer := fun P nodes =>
    open Classical in
    let rAns := ramCheckedAnswer L P nodes
    if IsValidFactorCAnswer (Real.sqrt 2) P rAns then rAns else fallbackValidAnswer P

theorem isValidSyncCheckedAnswerPolicy_ansPolPosDim {d s₀_d n L : ℕ} :
    IsValidSyncCheckedAnswerPolicy n (Real.sqrt 2) (ansPolPosDim d s₀_d L) := by
  refine ⟨mexHandle_notMem, fun P nodes hwf => ?_⟩
  dsimp [ansPolPosDim]
  split_ifs with h
  · exact h
  · unfold fallbackValidAnswer
    have hex := exists_validFactorCAnswer P hwf
    rw [dif_pos hex]
    exact Classical.choose_spec hex

/-! ### 5. `ramCheckedAnswer` Equals `ansPolPosDim` When `ChainStoredInv` Holds -/

theorem ramCheckedAnswer_valid_of_chainStoredInv
    (h_lem_5_2 : S_lem_5_2) (h_clm_5_1_block_witness : S_clm_5_1_block_witness)
    {d s₀_d n L B B_cert K_max W : ℕ}
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws) :
    IsValidFactorCAnswer (Real.sqrt 2) P (ramCheckedAnswer L P nodes) ∧
    (ansPolPosDim d s₀_d L).checkedAnswer P nodes = ramCheckedAnswer L P nodes := by
  have hvalid : IsValidFactorCAnswer (Real.sqrt 2) P (ramCheckedAnswer L P nodes) := by
    have hcard_eq := activeHandles_card_eq hinv.wfP
    by_cases hle1 : P.activeIds.card ≤ 1
    · have hnot2 : ¬ 2 ≤ P.activeHandles.card := by rw [hcard_eq]; clear * - hle1; omega
      simp [ramCheckedAnswer, hnot2, IsValidFactorCAnswer, hle1]
    · have h2 : 2 ≤ P.activeHandles.card := by rw [hcard_eq]; clear * - hle1; omega
      set best := foldBestPairs P (twoMinHandles P.activeHandles h2) (ramScanCandidates L P nodes)
      obtain ⟨hb1, hb2, hb_ne⟩ := foldBestPairs_valid (ramScanCandidates L P nodes) (twoMinHandles_spec h2)
      have hid1_in : P.idOfHandle best.1 ∈ P.activeIds := (hinv.wfP.2.2.1 best.1 hb1).1
      have hid2_in : P.idOfHandle best.2 ∈ P.activeIds := (hinv.wfP.2.2.1 best.2 hb2).1
      have hid_ne : P.idOfHandle best.1 ≠ P.idOfHandle best.2 := fun heq =>
        hb_ne (by rw [← (hinv.wfP.2.2.1 best.1 hb1).2, heq, (hinv.wfP.2.2.1 best.2 hb2).2])
      have hram_eq : ramCheckedAnswer L P nodes =
          { diameterHandles := some best, cachedDistSq := handleDistSq P best } := by
        simp [ramCheckedAnswer, h2, best]
      rw [hram_eq]
      unfold IsValidFactorCAnswer; rw [if_neg hle1]
      refine ⟨best.1, best.2, rfl, hb1, hb2, hb_ne, rfl, hid1_in, hid2_in, hid_ne, ?_,
        norm_le_indexedEuclideanDiam P.coords hid1_in hid2_in⟩
      change P.diam / Real.sqrt 2 ≤ ‖P.coords (P.idOfHandle best.1) - P.coords (P.idOfHandle best.2)‖
      by_cases hdiam_pos : 0 < P.diam
      · -- Map activeIds -> activeLifetimes -> activeHandles
        set k := nodes.length
        set vecNodes : Fin k → ChainNode d := fun i => (nodes.get i).built.node
        have hlt_to_h : ∀ lt ∈ activeLifetimes P,
            P.coords (P.idOfHandle (handleOfLifetime P lt)) = ltCoords lt := by
          intro lt hlt
          rcases Finset.mem_image.mp hlt with ⟨id₀, hid₀, rfl⟩
          rw [handleOfLifetime_of_mem hinv.wfP hid₀, (hinv.wfP.2.1 id₀ hid₀).2, (hinv.hlt_sync id₀ hid₀).1]
        have hSj_img : ∀ j : Fin (k + 1),
            (chainInput ltCoords vecNodes (activeLifetimes P) j).image (handleOfLifetime P) =
              chainInput (fun h => P.coords (P.idOfHandle h)) vecNodes P.activeHandles j := by
          intro j
          rw [chainInput_image_eq ltCoords (fun h => P.coords (P.idOfHandle h)) vecNodes
                (activeLifetimes P) (handleOfLifetime P) hlt_to_h j,
              image_handleOfLifetime_active hinv.wfP]
        -- Build witness baseline pairs & exact leaf pair on `activeLifetimes P`
        have hex_base : ∀ i : Fin k,
            ∃ bp : Option (ℕ × ℕ),
              (vecNodes i).SatisfiesBaselineCond ltCoords
                (chainInput ltCoords vecNodes (activeLifetimes P) i.castSucc) bp ∧
              (∀ lt₁ lt₂ : ℕ, bp = some (lt₁, lt₂) → lt₁ ≠ lt₂ →
                lt₁ ∈ activeLifetimes P ∧ lt₂ ∈ activeLifetimes P ∧
                (handleOfLifetime P lt₁, handleOfLifetime P lt₂) ∈ ramScanCandidates L P nodes) := by
          intro i
          set S_lt := chainInput ltCoords vecNodes (activeLifetimes P) i.castSucc
          set S_h := chainInput (fun h => P.coords (P.idOfHandle h)) vecNodes P.activeHandles i.castSucc
          have hS_eq : S_lt.image (handleOfLifetime P) = S_h := hSj_img i.castSucc
          by_cases hSne : S_lt.Nonempty
          · have hSh_ne : S_h.Nonempty := by rw [← hS_eq]; exact hSne.image _
            have hlvl := hinv.levels i.val i.isLt
            obtain ⟨rNum, rDen, htreeSj, hSj_bnds⟩ := hlvl.tree_Sj
            have hS_eq_raw : (chainInput ltCoords (fun i => (nodes.get i).built.node) (activeLifetimes P)
                ⟨i.val, Nat.lt_succ_of_lt i.isLt⟩).image (handleOfLifetime P) = S_h := hS_eq
            rw [hS_eq_raw] at htreeSj hSj_bnds
            have hDen_pos : ∀ h ∈ S_h, 1 ≤ rDen h := fun h hh => (hSj_bnds h hh).1
            have hw_eq : ∀ h ∈ S_h, ((rNum h : ℝ) / (rDen h : ℝ)) =
                ‖P.coords (P.idOfHandle h) - (nodes.get i).built.node.o‖ ^ 2 := by
              intro h hh
              have hsub_h : S_h ⊆ P.activeHandles := chainInput_subset_base _ _ _ _
              have hid_in := (hinv.wfP.2.2.1 h (hsub_h hh)).1
              have hq_eq := (hinv.hlt_sync _ hid_in).2
              rw [(hinv.wfP.2.2.1 h (hsub_h hh)).2] at hq_eq
              rw [(hSj_bnds h hh).2.1, ← hq_eq]
            have htv_eq := treeNodeVal_eq_realTreeVal hDen_pos hw_eq L 0
            set y_h := (realTreeVal S_h (fun h => ‖P.coords (P.idOfHandle h) - (nodes.get i).built.node.o‖ ^ 2) L 0).2.1
            have hc_pos : 0 < (treeNodeVal S_h rNum rDen L 0).1 := by
              rw [treeNodeVal_cnt, treeSubSet_root htreeSj.hS]; exact hSh_ne.card_pos
            obtain ⟨hy_in_sub, hn_eq, hd_eq, hy_max_rat⟩ := treeNodeVal_winner rNum hDen_pos L 0 hc_pos
            rw [htv_eq.2.1] at hy_in_sub hn_eq hd_eq
            have hy_in_Sh : y_h ∈ S_h := (treeSubSet_root htreeSj.hS) ▸ hy_in_sub
            rcases (hS_eq ▸ hy_in_Sh : y_h ∈ S_lt.image (handleOfLifetime P)) with hmem_img
            rcases Finset.mem_image.mp hmem_img with ⟨y_lt, hy_lt_in, hy_lt_h⟩
            have hy_max : IsNodeMaxRadiusPoint ltCoords (nodes.get i).built.node.o S_lt y_lt := by
              refine ⟨hy_lt_in, le_antisymm ?_ ?_⟩
              · unfold nodeMaxRadius; rw [dif_pos hSne]
                exact Finset.le_sup' (f := fun lt => ‖ltCoords lt - (nodes.get i).built.node.o‖) hy_lt_in
              · unfold nodeMaxRadius; rw [dif_pos hSne]
                apply Finset.sup'_le
                intro lt hlt
                have hh_in : handleOfLifetime P lt ∈ S_h := hS_eq ▸ Finset.mem_image_of_mem _ hlt
                have hle_sq : ‖ltCoords lt - (nodes.get i).built.node.o‖ ^ 2 ≤
                    ‖ltCoords y_lt - (nodes.get i).built.node.o‖ ^ 2 := by
                  have h1 := hy_max_rat (handleOfLifetime P lt) ((treeSubSet_root htreeSj.hS).symm ▸ hh_in)
                  rw [hn_eq, hd_eq, hw_eq _ hh_in, hw_eq _ hy_in_Sh,
                      hlt_to_h lt (chainInput_subset_base _ _ _ _ hlt),
                      ← hy_lt_h, hlt_to_h y_lt (chainInput_subset_base _ _ _ _ hy_lt_in)] at h1
                  exact h1
                exact nonneg_le_of_sq_le_sq
                  (norm_nonneg (ltCoords lt - (nodes.get i).built.node.o))
                  (norm_nonneg (ltCoords y_lt - (nodes.get i).built.node.o)) hle_sq
            -- Intact block `b_min`
            have hBi : (intactBlocksOf (nodes.get i) P).Nonempty := hlvl.tree_intact.1
            set b_min := (intactBlocksOf (nodes.get i) P).min' hBi
            have hb_mem := Finset.min'_mem _ hBi
            rcases Finset.mem_image.mp hb_mem with ⟨b_fin, hb_flt, hb_val⟩
            have hb_lt : b_min < (nodes.get i).built.aux.k_blk := by have := b_fin.isLt; omega
            have hb_fin_eq : (⟨b_min, hb_lt⟩ : Fin (nodes.get i).built.aux.k_blk) = b_fin := Fin.ext hb_val.symm
            have hb_act : ∀ t : Fin s₀_d, (nodes.get i).built.aux.birthLifetimes ⟨b_min, hb_lt⟩ t ∈ activeLifetimes P := by
              rw [hb_fin_eq]; exact (Finset.mem_filter.mp hb_flt).2
            obtain ⟨hsub_b, hnn_b, hsum1_b, hsumz_b⟩ := hlvl.hcerts ⟨b_min, hb_lt⟩
            let cert : BlockCertificate ltCoords (nodes.get i).birthPool
                (liftedPoint (nodes.get i).built.node.o (nodes.get i).built.s) :=
              { B := Finset.univ.image ((nodes.get i).built.aux.birthLifetimes ⟨b_min, hb_lt⟩)
                coeff := fun lt => ∑ t : Fin s₀_d,
                  if (nodes.get i).built.aux.birthLifetimes ⟨b_min, hb_lt⟩ t = lt then
                    ((nodes.get i).built.aux.lam ⟨b_min, hb_lt⟩ t : ℝ) else 0
                subset_birth := hsub_b
                coeff_nonneg := hnn_b
                sum_coeff := hsum1_b
                sum_lift := hsumz_b }
            have hIntact_S : cert.IsIntact S_lt := by
              intro lt hlt
              rcases Finset.mem_image.mp hlt with ⟨t, _, rfl⟩
              rw [mem_chainInput_iff]
              exact ⟨hb_act t, fun j₀ hj₀ =>
                hinv.hbirth_avoid i.val i.isLt _ ((hlvl.hblt_mem ⟨b_min, hb_lt⟩ t).1) j₀ hj₀⟩
            obtain ⟨p_lt, hp_in_B, _, hsat_p⟩ :=
              prove_part2 h_clm_5_1_block_witness d ℕ ltCoords (nodes.get i).birthPool S_lt
                (nodes.get i).built.node.o (nodes.get i).built.s cert y_lt hIntact_S hy_max
            rw [← hlvl.hnode_V] at hsat_p
            rcases Finset.mem_image.mp hp_in_B with ⟨t₀, _, rfl⟩
            refine ⟨some ((nodes.get i).built.aux.birthLifetimes ⟨b_min, hb_lt⟩ t₀, y_lt), hsat_p, ?_⟩
            intro lt₁ lt₂ hsome _
            injection hsome with hpair; injection hpair with heq1 heq2; subst heq1; subst heq2
            refine ⟨hb_act t₀, chainInput_subset_base _ _ _ _ hy_lt_in, ?_⟩
            apply List.mem_append_left
            rw [List.mem_flatMap]
            refine ⟨i, List.mem_finRange i, ?_⟩
            unfold levelScanCands
            rw [if_pos hSh_ne, dif_pos hBi, dif_pos hb_lt]
            rw [List.mem_map]
            refine ⟨t₀, List.mem_finRange t₀, ?_⟩
            rw [hlvl.hbh_active_sync ⟨b_min, hb_lt⟩ t₀ (hb_act t₀), hy_lt_h]
          · refine ⟨none, ?_, fun _ _ h _ => by cases h⟩
            have hemp : S_lt = ∅ := Finset.not_nonempty_iff_eq_empty.mp hSne
            exact ⟨by simp [IsActiveNodePair, hemp], fun hne => absurd hne hSne⟩
        choose basePairs hBaseCond hBaseMem using hex_base
        -- Leaf exact pair on `S_k_lt`
        set S_k_lt := chainTerminal ltCoords vecNodes (activeLifetimes P)
        set S_k_h := chainInput (fun h => P.coords (P.idOfHandle h)) vecNodes P.activeHandles (Fin.last k)
        have hSk_eq : S_k_lt.image (handleOfLifetime P) = S_k_h := hSj_img (Fin.last k)
        have hex_leaf : ∃ lp : Option (ℕ × ℕ),
            IsExactLeafAnswer ltCoords S_k_lt lp ∧
            (∀ lt₁ lt₂ : ℕ, lp = some (lt₁, lt₂) → lt₁ ≠ lt₂ →
              lt₁ ∈ activeLifetimes P ∧ lt₂ ∈ activeLifetimes P ∧
              (handleOfLifetime P lt₁, handleOfLifetime P lt₂) ∈ ramScanCandidates L P nodes) := by
          by_cases hSk1 : S_k_lt.card ≤ 1
          · exact ⟨none, by simp [IsExactLeafAnswer, hSk1], fun _ _ h _ => by cases h⟩
          · have hSk_ne : S_k_lt.Nonempty := Finset.card_pos.mp (by clear * - hSk1; omega)
            obtain ⟨uv, huv, hsup_k⟩ :=
              Finset.exists_mem_eq_sup' (hSk_ne.product hSk_ne) (fun xy : ℕ × ℕ => ‖ltCoords xy.1 - ltCoords xy.2‖)
            rcases Finset.mem_product.mp huv with ⟨hu_in, hv_in⟩
            have hdiam_k : indexedEuclideanDiam S_k_lt ltCoords = ‖ltCoords uv.1 - ltCoords uv.2‖ := by
              unfold indexedEuclideanDiam; rw [dif_pos hSk_ne, hsup_k]
            by_cases huv_ne : uv.1 ≠ uv.2
            · refine ⟨some (uv.1, uv.2), ?_, ?_⟩
              · unfold IsExactLeafAnswer; rw [if_neg hSk1]
                exact ⟨uv.1, uv.2, rfl, hu_in, hv_in, huv_ne, hdiam_k.symm⟩
              · intro lt₁ lt₂ hs _; injection hs with hp; injection hp with heq1 heq2; subst heq1; subst heq2
                have hu_h : handleOfLifetime P uv.1 ∈ S_k_h := hSk_eq ▸ Finset.mem_image_of_mem _ hu_in
                have hv_h : handleOfLifetime P uv.2 ∈ S_k_h := hSk_eq ▸ Finset.mem_image_of_mem _ hv_in
                obtain ⟨a, ha_mem, ha_eq⟩ := Finset.mem_image.mp (image_minPopElem_eq S_k_h ▸ hu_h)
                obtain ⟨b, hb_mem, hb_eq⟩ := Finset.mem_image.mp (image_minPopElem_eq S_k_h ▸ hv_h)
                refine ⟨chainTerminal_subset ltCoords vecNodes (activeLifetimes P) hu_in,
                        chainTerminal_subset ltCoords vecNodes (activeLifetimes P) hv_in, ?_⟩
                apply List.mem_append_right
                unfold leafScanCands
                rw [List.mem_flatMap]
                refine ⟨a, List.mem_range.mpr (Finset.mem_range.mp ha_mem), ?_⟩
                rw [List.mem_map]
                exact ⟨b, List.mem_range.mpr (Finset.mem_range.mp hb_mem), by rw [ha_eq, hb_eq]⟩
            · push_neg at huv_ne
              have hdiam_k0 : indexedEuclideanDiam S_k_lt ltCoords = 0 := by rw [hdiam_k, huv_ne]; simp
              obtain ⟨u₁, hu₁, u₂, hu₂, hne12⟩ := Finset.one_lt_card.mp (Nat.lt_of_not_ge hSk1)
              have hnorm0 : ‖ltCoords u₁ - ltCoords u₂‖ = 0 :=
                le_antisymm ((norm_le_indexedEuclideanDiam ltCoords hu₁ hu₂).trans_eq hdiam_k0) (norm_nonneg _)
              refine ⟨some (u₁, u₂), ?_, ?_⟩
              · unfold IsExactLeafAnswer; rw [if_neg hSk1]
                exact ⟨u₁, u₂, rfl, hu₁, hu₂, hne12, hnorm0.trans hdiam_k0.symm⟩
              · intro lt₁ lt₂ hs _; injection hs with hp; injection hp with heq1 heq2; subst heq1; subst heq2
                have hu_h : handleOfLifetime P u₁ ∈ S_k_h := hSk_eq ▸ Finset.mem_image_of_mem _ hu₁
                have hv_h : handleOfLifetime P u₂ ∈ S_k_h := hSk_eq ▸ Finset.mem_image_of_mem _ hu₂
                obtain ⟨a, ha_mem, ha_eq⟩ := Finset.mem_image.mp (image_minPopElem_eq S_k_h ▸ hu_h)
                obtain ⟨b, hb_mem, hb_eq⟩ := Finset.mem_image.mp (image_minPopElem_eq S_k_h ▸ hv_h)
                refine ⟨chainTerminal_subset ltCoords vecNodes (activeLifetimes P) hu₁,
                        chainTerminal_subset ltCoords vecNodes (activeLifetimes P) hu₂, ?_⟩
                apply List.mem_append_right
                unfold leafScanCands
                rw [List.mem_flatMap]
                refine ⟨a, List.mem_range.mpr (Finset.mem_range.mp ha_mem), ?_⟩
                rw [List.mem_map]
                exact ⟨b, List.mem_range.mpr (Finset.mem_range.mp hb_mem), by rw [ha_eq, hb_eq]⟩
        obtain ⟨leafPair, hLeafCond, hLeafMem⟩ := hex_leaf
        obtain ⟨leafPair', hAct', hDiam', hEqLen, hLeafMem'⟩ :=
          exactLeaf_to_active ltCoords S_k_lt leafPair hLeafCond
        have h52 := h_lem_5_2 d ℕ k ltCoords (activeLifetimes P) vecNodes basePairs leafPair' hBaseCond hAct' hDiam'
        rw [hEqLen] at h52
        have hdiam_lt_eq : indexedEuclideanDiam (activeLifetimes P) ltCoords = P.diam :=
          indexedEuclideanDiam_image_eq P.activeIds P.coords ltCoords P.lifetimeOfId
            (fun id hid => (hinv.hlt_sync id hid).1)
        rw [hdiam_lt_eq] at h52
        rcases Set.mem_Icc.mp h52 with ⟨h52_lo, _⟩
        obtain ⟨idx₀, _, hSupEq⟩ :=
          Finset.exists_mem_eq_sup' Finset.univ_nonempty
            (Fin.lastCases (baselinePairLength ltCoords leafPair)
              (fun i : Fin k => baselinePairLength ltCoords (basePairs i)))
        let cand : Option (ℕ × ℕ) := Fin.lastCases leafPair basePairs idx₀
        have hCandLen :
            baselinePairLength ltCoords cand =
              Fin.lastCases (baselinePairLength ltCoords leafPair)
                (fun i : Fin k => baselinePairLength ltCoords (basePairs i)) idx₀ := by
          dsimp [cand]
          rcases Fin.eq_castSucc_or_eq_last idx₀ with ⟨i, rfl⟩ | rfl <;> simp
        rw [hSupEq, ← hCandLen] at h52_lo
        have hCandPos : 0 < baselinePairLength ltCoords cand :=
          lt_of_lt_of_le (div_pos hdiam_pos (Real.sqrt_pos.mpr (by norm_num))) h52_lo
        cases hCand : cand with
        | none =>
            rw [hCand] at hCandPos; simp [baselinePairLength] at hCandPos
        | some uv =>
            rcases uv with ⟨lt₁, lt₂⟩
            have hNormPos : 0 < ‖ltCoords lt₁ - ltCoords lt₂‖ := by
              simpa [hCand, baselinePairLength] using hCandPos
            have hlt_ne : lt₁ ≠ lt₂ := fun heq => by subst heq; simp at hNormPos
            have hcand_in : lt₁ ∈ activeLifetimes P ∧ lt₂ ∈ activeLifetimes P ∧
                (handleOfLifetime P lt₁, handleOfLifetime P lt₂) ∈ ramScanCandidates L P nodes := by
              rcases Fin.eq_castSucc_or_eq_last idx₀ with ⟨i, rfl⟩ | rfl
              · exact hBaseMem i lt₁ lt₂ (by simpa [cand] using hCand) hlt_ne
              · have hlp_eq : leafPair = some (lt₁, lt₂) := by simpa [cand] using hCand
                exact hLeafMem lt₁ lt₂ hlp_eq hlt_ne
            obtain ⟨hlt₁_act, hlt₂_act, hmem_cands⟩ := hcand_in
            have hh₁_in : handleOfLifetime P lt₁ ∈ P.activeHandles :=
              image_handleOfLifetime_active hinv.wfP ▸ Finset.mem_image_of_mem _ hlt₁_act
            have hh₂_in : handleOfLifetime P lt₂ ∈ P.activeHandles :=
              image_handleOfLifetime_active hinv.wfP ▸ Finset.mem_image_of_mem _ hlt₂_act
            have hh_ne : handleOfLifetime P lt₁ ≠ handleOfLifetime P lt₂ :=
              fun heq => hlt_ne (handleOfLifetime_injOn hinv.wfP hlt₁_act hlt₂_act heq)
            have hge_sq := foldBestPairs_ge_mem (twoMinHandles P.activeHandles h2) hmem_cands ⟨hh₁_in, hh₂_in, hh_ne⟩
            change handleDistSq P (handleOfLifetime P lt₁, handleOfLifetime P lt₂) ≤ handleDistSq P best at hge_sq
            unfold handleDistSq euclideanDistSq at hge_sq
            rw [hlt_to_h lt₁ hlt₁_act, hlt_to_h lt₂ hlt₂_act] at hge_sq
            have hle_norm : ‖ltCoords lt₁ - ltCoords lt₂‖ ≤
                ‖P.coords (P.idOfHandle best.1) - P.coords (P.idOfHandle best.2)‖ :=
              nonneg_le_of_sq_le_sq
                (norm_nonneg (ltCoords lt₁ - ltCoords lt₂))
                (norm_nonneg (P.coords (P.idOfHandle best.1) - P.coords (P.idOfHandle best.2))) hge_sq
            have hbl_eq : baselinePairLength ltCoords cand = ‖ltCoords lt₁ - ltCoords lt₂‖ := by
              simp [hCand, baselinePairLength]
            linarith only [h52_lo, hbl_eq, hle_norm]
      · have hdiam0 : P.diam = 0 :=
          le_antisymm (not_lt.mp hdiam_pos) (indexedEuclideanDiam_nonneg P.activeIds P.coords)
        rw [hdiam0, zero_div]; exact norm_nonneg _
  exact ⟨hvalid, by dsimp [ansPolPosDim]; rw [if_pos hvalid]⟩

end UL.C12LVE
