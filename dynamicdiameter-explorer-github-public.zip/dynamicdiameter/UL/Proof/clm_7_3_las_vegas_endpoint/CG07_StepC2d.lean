import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2d0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL.C12LVE

open UL
open UL.Proof_lem_A_1

def buildSjTreeAndResidualBufRegs (d L : ℕ) : BitRAMStmt :=
  .seq freeScratch111to116Regs
  (.seq (rLit 10 10)
  (.seq (rLoad 0 0 10)
  (.seq (rLit 10 113)
  (.seq (rStore 9 10 0)
  (.seq (rAdd 6 0 0)
  (.seq (rLit 4 2)
  (.seq (rAdd 6 6 4)
  (.seq (rLit 10 114)
  (.seq (rStore 9 10 6)
  (.seq (rLit 10 115)
  (.seq (rLit 4 0)
  (.seq (rStore 9 10 4)
  (.seq (rLit 10 110)
  (.seq (rLoad 5 9 10)
  (.seq (.repeatN (.readLocal 5 (.lit 0)) (buildSjResStepStmt d L))
  (.seq freeScratch111to116Regs
  (.seq freeBufRegs
  (.seq (rLit 0 1)
        (popTreeToBufRegs L)))))))))))))))))))

theorem exec_buildSjTreeAndResidualBufRegs {d : ℕ} (hd1 : 1 ≤ d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws : WordStore}
    {L B B_cert K_max j m : ℕ}
    (hL1 : 1 ≤ L) (hB1 : 1 ≤ B) (hBc1 : 1 ≤ B_cert)
    (hj : j ≤ K_max) (hm_le : m ≤ 2 ^ L)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength d + L + 40 ≤ W)
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (htreeSj_emp : TreeStoredAt L (2 * j + 2) ∅ (fun _ => 0) (fun _ => 1) ws)
    (htree1_emp : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) ws)
    (hr_j : ws.read (.heap 0 10) = (j : ℤ))
    (hr110 : ws.read (.heap 9 110) = (m : ℤ))
    {hSeq : ℕ → ℕ} {S_act : Finset ℕ} {qMap : ℕ → Fin d → ℚ}
    (hbuf : ∀ k < m, ws.read (.heap 8 (k : ℤ)) = (hSeq k : ℤ))
    (hclean8 : ∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ ws.live)
    (hhSeq_mem : ∀ k < m, hSeq k ∈ S_act)
    (hcoords : ActiveCoordsStored d L B S_act qMap ws)
    {oRat : Fin d → ℚ} {V_num V_den : ℤ} {V : ℝ}
    (hgeom : NodeGeomStored d (posNodeStride d L) B_cert j oRat V_num V_den V ws)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    let S_H := (Finset.range m).image hSeq
    let S_res_H := S_H.filter (fun h => isResHandlePred qMap oRat V h = true)
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (buildSjTreeAndResidualBufRegs d L) ws regs wsEnd regsEnd
        ((m + 1) * (240 * d + 1180 * L + 1000) + 600)
        ((m + 1) * (56 * d + 200 * L + 240) * W * W + 200 * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      (∃ (rNum rDen : ℕ → ℤ),
        TreeStoredAt L (2 * j + 2) S_H rNum rDen wsEnd ∧
        (∀ h ∈ S_H,
          1 ≤ rDen h ∧
          ((rNum h : ℝ) / (rDen h : ℝ)) =
            ‖ratPointToEuclidean (qMap h) - ratPointToEuclidean oRat‖ ^ 2 ∧
          intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧
          intBitLength (rDen h) ≤ sqRadBitBound d B B_cert)) ∧
      TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsEnd ∧
      wsEnd.read (.heap 0 10) = (j : ℤ) ∧
      wsEnd.read (.heap 9 110) = (S_res_H.card : ℤ) ∧
      (∃ hSeq' : ℕ → ℕ,
        (∀ k < S_res_H.card, hSeq' k < 2 ^ L ∧ wsEnd.read (.heap 8 (k : ℤ)) = (hSeq' k : ℤ)) ∧
        (Finset.range S_res_H.card).image hSeq' = S_res_H) ∧
      (∀ z : ℤ, (∀ k < S_res_H.card, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsEnd.live) ∧
      (∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ wsEnd.live →
        z = 110 ∨ (.heap 9 z : RAMCellLoc) ∈ ws.live) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .heap 0 10 →
        loc ∉ treeSliceLocs L (2 * j + 2) →
        loc ∉ treeSliceLocs L 1 →
        (∀ z : ℤ, loc ≠ .heap 8 z) →
        loc ≠ .heap 9 110 → loc ≠ .heap 9 111 → loc ≠ .heap 9 112 →
        loc ≠ .heap 9 113 → loc ≠ .heap 9 114 → loc ≠ .heap 9 115 → loc ≠ .heap 9 116 →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  dsimp only
  set S_H := (Finset.range m).image hSeq
  set S_res_H := S_H.filter (fun h => isResHandlePred qMap oRat V h = true)
  set nodeStride := posNodeStride d L
  set tid := 2 * j + 2
  have ht1_lt : 1 < 2 * K_max + 6 := by omega
  have htid_ne1 : tid ≠ 1 := by dsimp [tid]; omega
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hWW : 40 * W ≤ W * W := by nlinarith only [hW40]
  have hns_ge2 : 2 ≤ nodeStride := by dsimp [nodeStride, posNodeStride]; have := Nat.zero_le (2 ^ L); omega
  have sp_ok : ∀ {wx : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wx →
      inp.inputCellSpace + wx.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + wx.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro wx hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hCeil0C : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hCeil0B : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  have not_slice : ∀ {t0 t : ℕ} {z : ℤ}, t ≠ 2 → (.heap t z : RAMCellLoc) ∉ treeSliceLocs L t0 := by
    intro t0 t z hne hm
    unfold treeSliceLocs at hm
    rcases Finset.mem_image.mp hm with ⟨_, _, hc⟩
    injection hc with ht _; exact hne ht.symm
  have read_eq_of_unch : ∀ {wA wB : WordStore} {t : ℕ} {z : ℤ},
      ((.heap t z : RAMCellLoc) ∈ wA.live ↔ (.heap t z : RAMCellLoc) ∈ wB.live) ∧
      wA.vals (.heap t z) = wB.vals (.heap t z) →
      wA.read (.heap t z) = wB.read (.heap t z) := by
    intro wA wB t z hu
    unfold WordStore.read; rw [hu.2]
    by_cases hL : (.heap t z : RAMCellLoc) ∈ wB.live
    · rw [if_pos (hu.1.mpr hL), if_pos hL]
    · rw [if_neg (fun hm => hL (hu.1.mp hm)), if_neg hL]
  have htid_nbl : natBitLength tid ≤ natBitLength ((K_max + 2) * nodeStride) := by
    apply natBitLength_mono
    calc tid = 2 * j + 2 := rfl
      _ ≤ 2 * (K_max + 2) := by omega
      _ = (K_max + 2) * 2 := by ring
      _ ≤ (K_max + 2) * nodeStride := Nat.mul_le_mul_left _ hns_ge2
  have hj_bl : intBitLength (j : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le j
    have h2 : natBitLength j ≤ natBitLength tid := natBitLength_mono (by dsimp [tid]; omega)
    clear * - h1 h2 htid_nbl hW; omega
  have hj1_bl : intBitLength (((j + 1 : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (j + 1)
    have h2 : natBitLength (j + 1) ≤ natBitLength tid := natBitLength_mono (by dsimp [tid]; omega)
    clear * - h1 h2 htid_nbl hW; omega
  have h2j_bl : intBitLength (((2 * j : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (2 * j)
    have h2 : natBitLength (2 * j) ≤ natBitLength tid := natBitLength_mono (by dsimp [tid]; omega)
    clear * - h1 h2 htid_nbl hW; omega
  have htid_bl : intBitLength (tid : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le tid
    clear * - h1 htid_nbl hW; omega
  have hm_bl : intBitLength (m : ℤ) ≤ W := by
    have hlt : m < 2 ^ (L + 1) := by have : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide); rw [pow_succ]; omega
    exact (nat_lt_pow2_bitLength_le hlt).trans (by clear * - hW; omega)
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hl2 : intBitLength (2 : ℤ) ≤ W := (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by omega)
  have hl10 : intBitLength (10 : ℤ) ≤ W := (show intBitLength (10 : ℤ) = 5 from by decide).trans_le (by omega)
  have hl110 : intBitLength (110 : ℤ) ≤ W := (show intBitLength (110 : ℤ) = 8 from by decide).trans_le (by omega)
  have hl113 : intBitLength (113 : ℤ) ≤ W := (show intBitLength (113 : ℤ) = 8 from by decide).trans_le (by omega)
  have hl114 : intBitLength (114 : ℤ) ≤ W := (show intBitLength (114 : ℤ) = 8 from by decide).trans_le (by omega)
  have hl115 : intBitLength (115 : ℤ) ≤ W := (show intBitLength (115 : ℤ) = 8 from by decide).trans_le (by omega)
  have hn0 : natBitLength 0 ≤ W := (show natBitLength 0 = 1 from by decide).trans_le (by omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by omega)
  have hloc010 : (RAMCellLoc.heap 0 10).bitLength ≤ W := (show (RAMCellLoc.heap 0 10).bitLength = 6 from by decide).trans_le (by omega)
  have hloc113 : (RAMCellLoc.heap 9 113).bitLength ≤ W := (show (RAMCellLoc.heap 9 113).bitLength = 12 from by decide).trans_le (by omega)
  have hloc114 : (RAMCellLoc.heap 9 114).bitLength ≤ W := (show (RAMCellLoc.heap 9 114).bitLength = 12 from by decide).trans_le (by omega)
  have hloc115 : (RAMCellLoc.heap 9 115).bitLength ≤ W := (show (RAMCellLoc.heap 9 115).bitLength = 12 from by decide).trans_le (by omega)
  -- Phase 0: `freeScratch111to116Regs`
  obtain ⟨ws0, g0, p0, hm0, bg0, hn111_0, hn112_0, hn113_0, hn114_0, hn115_0, hn116_0, hunch0⟩ :=
    exec_freeScratch111to116Regs hfd_le (by omega) hmod hcCeil hbCeil hbnd
  have hr_j0 : ws0.read (.heap 0 10) = (j : ℤ) :=
    (read_eq_of_unch (hunch0 _ (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))).trans hr_j
  have hr110_0 : ws0.read (.heap 9 110) = (m : ℤ) :=
    (read_eq_of_unch (hunch0 _ (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))).trans hr110
  have hbuf0 : ∀ k < m, ws0.read (.heap 8 (k : ℤ)) = (hSeq k : ℤ) := fun k hk =>
    (read_eq_of_unch (hunch0 _ (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)
      (fun h => by cases h) (fun h => by cases h) (fun h => by cases h))).trans (hbuf k hk)
  have hcoords0 : ActiveCoordsStored d L B S_act qMap ws0 :=
    hcoords.unchanged (fun _ _ _ _ _ _ => read_eq_of_unch (hunch0 _ (fun h => by cases h) (fun h => by cases h)
      (fun h => by cases h) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)))
  have hgeom0 : NodeGeomStored d nodeStride B_cert j oRat V_num V_den V ws0 :=
    hgeom.unchanged (fun _ _ => read_eq_of_unch (hunch0 _ (fun h => by cases h) (fun h => by cases h)
      (fun h => by cases h) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)))
  have htreeSj_0 : TreeStoredAt L tid ∅ (fun _ => 0) (fun _ => 1) ws0 :=
    htreeSj_emp.unchanged (fun _ _ _ _ => hunch0 _ (fun h => by cases h) (fun h => by cases h)
      (fun h => by cases h) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h))
  have htree1_0 : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) ws0 :=
    htree1_emp.unchanged (fun _ _ _ _ => hunch0 _ (fun h => by cases h) (fun h => by cases h)
      (fun h => by cases h) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h))
  -- Phase 1: Preamble setting `.heap 9 113 = j`, `.heap 9 114 = 2*j+2`, `.heap 9 115 = 0`, `reg 5 = m`
  have p1 := RegExec.lit (inp := inp) hfd_le bg0 (sp_ok hm0).1 (sp_ok hm0).2 (dst := 10) (c := 10) (by decide) hl10
  set g1 := Function.update g0 10 10; have bg1 : RegBounded W g1 := bg0.update (r := 10) (by decide) hl10
  have hr_g1 : ws0.read (.heap 0 (g1 10)) = (j : ℤ) := by simp [g1, hr_j0]
  have p2 := (RegExec.load (inp := inp) hfd_le bg1 (sp_ok hm0).1 (sp_ok hm0).2
    (dst := 0) (table := 0) (addr := 10) (by decide) (by decide) hn0 (hr_g1 ▸ hj_bl)).weaken rfl (by rw [hr_g1]) le_rfl le_rfl
  set g2 := Function.update g1 0 (j : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 0) (by decide) hj_bl
  have p3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hm0).1 (sp_ok hm0).2 (dst := 10) (c := 113) (by decide) hl113
  set g3 := Function.update g2 10 113; have bg3 : RegBounded W g3 := bg2.update (r := 10) (by decide) hl113
  set ws1 := ws0.write (.heap 9 113) (j : ℤ)
  have hm1 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws1 := hm0.write (mem_posDimWriteLocs_tab9 (by decide)) (j : ℤ) hloc113 hj_bl
  have p4 : RegExec inp fd W C_cell C_bit (rStore 9 10 0) ws0 g3 ws1 g3 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le bg3 (table := 9) (addr := 10) (val := 0) (by decide) (by decide) hn9
      (by simpa [g3, g2] using (sp_ok hm1).1) (by simpa [g3, g2] using (sp_ok hm1).2)).weaken
      (by simp [g3, g2, ws1]) rfl le_rfl le_rfl
  have ea5 : g3 0 + g3 0 = (((2 * j : ℕ) : ℤ)) := by simp [g3, g2]; omega
  have p5 := (RegExec.add (inp := inp) hfd_le bg3 (sp_ok hm1).1 (sp_ok hm1).2
    (dst := 6) (a := 0) (b := 0) (by decide) (by decide) (by decide) (ea5 ▸ h2j_bl)).weaken rfl (by rw [ea5]) le_rfl le_rfl
  set g5 := Function.update g3 6 (((2 * j : ℕ) : ℤ)); have bg5 : RegBounded W g5 := bg3.update (r := 6) (by decide) h2j_bl
  have p6 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 4) (c := 2) (by decide) hl2
  set g6 := Function.update g5 4 2; have bg6 : RegBounded W g6 := bg5.update (r := 4) (by decide) hl2
  have ea7 : g6 6 + g6 4 = (tid : ℤ) := by simp [g6, g5, tid]
  have p7 := (RegExec.add (inp := inp) hfd_le bg6 (sp_ok hm1).1 (sp_ok hm1).2
    (dst := 6) (a := 6) (b := 4) (by decide) (by decide) (by decide) (ea7 ▸ htid_bl)).weaken rfl (by rw [ea7]) le_rfl le_rfl
  set g7 := Function.update g6 6 (tid : ℤ); have bg7 : RegBounded W g7 := bg6.update (r := 6) (by decide) htid_bl
  have p8 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 10) (c := 114) (by decide) hl114
  set g8 := Function.update g7 10 114; have bg8 : RegBounded W g8 := bg7.update (r := 10) (by decide) hl114
  set ws2 := ws1.write (.heap 9 114) (tid : ℤ)
  have hm2 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws2 := hm1.write (mem_posDimWriteLocs_tab9 (by decide)) (tid : ℤ) hloc114 htid_bl
  have p9 : RegExec inp fd W C_cell C_bit (rStore 9 10 6) ws1 g8 ws2 g8 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le bg8 (table := 9) (addr := 10) (val := 6) (by decide) (by decide) hn9
      (by simpa [g8, g7] using (sp_ok hm2).1) (by simpa [g8, g7] using (sp_ok hm2).2)).weaken
      (by simp [g8, g7, ws2]) rfl le_rfl le_rfl
  have p10 := RegExec.lit (inp := inp) hfd_le bg8 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 10) (c := 115) (by decide) hl115
  set g10 := Function.update g8 10 115; have bg10 : RegBounded W g10 := bg8.update (r := 10) (by decide) hl115
  have p11 := RegExec.lit (inp := inp) hfd_le bg10 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 4) (c := 0) (by decide) hl0
  set g11 := Function.update g10 4 0; have bg11 : RegBounded W g11 := bg10.update (r := 4) (by decide) hl0
  set ws3 := ws2.write (.heap 9 115) 0
  have hm3 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws3 := hm2.write (mem_posDimWriteLocs_tab9 (by decide)) 0 hloc115 hl0
  have p12 : RegExec inp fd W C_cell C_bit (rStore 9 10 4) ws2 g11 ws3 g11 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le bg11 (table := 9) (addr := 10) (val := 4) (by decide) (by decide) hn9
      (by simpa [g11, g10] using (sp_ok hm3).1) (by simpa [g11, g10] using (sp_ok hm3).2)).weaken
      (by simp [g11, g10, ws3]) rfl le_rfl le_rfl
  have p13 := RegExec.lit (inp := inp) hfd_le bg11 (sp_ok hm3).1 (sp_ok hm3).2 (dst := 10) (c := 110) (by decide) hl110
  set g13 := Function.update g11 10 110; have bg13 : RegBounded W g13 := bg11.update (r := 10) (by decide) hl110
  have hr_g13 : ws3.read (.heap 9 (g13 10)) = (m : ℤ) := by
    simp only [g13, Function.update_self, ws3, ws2, ws1]
    rw [wordStore_read_write_ne _ (by decide), wordStore_read_write_ne _ (by decide),
        wordStore_read_write_ne _ (by decide)]
    exact hr110_0
  have p14 := (RegExec.load (inp := inp) hfd_le bg13 (sp_ok hm3).1 (sp_ok hm3).2
    (dst := 5) (table := 9) (addr := 10) (by decide) (by decide) hn9 (hr_g13 ▸ hm_bl)).weaken rfl (by rw [hr_g13]) le_rfl le_rfl
  set g14 := Function.update g13 5 (m : ℤ); have bg14 : RegBounded W g14 := bg13.update (r := 5) (by decide) hm_bl
  -- Phase 2: `m`-step loop populating `tree (2*j+2)` and `tree 1`
  have hSj0 : SjLoopInv d L B B_cert K_max j m hSeq qMap oRat V ws0 W 0 ws3 g14 := by
    refine ⟨Nat.zero_le _, hm3, bg14, ⟨fun _ => 0, fun _ => 1, ?_, fun _ hh => by simp at hh⟩, ?_, ?_, ?_, ?_, ?_⟩
    · simpa using (htreeSj_0.unchanged (fun _ _ _ _ => by
        dsimp [ws3, ws2, ws1, WordStore.write]
        exact ⟨by simp, by rw [Function.update_of_ne (fun h => by cases h), Function.update_of_ne (fun h => by cases h), Function.update_of_ne (fun h => by cases h)]⟩))
    · simpa using (htree1_0.unchanged (fun _ _ _ _ => by
        dsimp [ws3, ws2, ws1, WordStore.write]
        exact ⟨by simp, by rw [Function.update_of_ne (fun h => by cases h), Function.update_of_ne (fun h => by cases h), Function.update_of_ne (fun h => by cases h)]⟩))
    · dsimp [ws3, ws2, ws1]
      rw [wordStore_read_write_ne _ (by decide), wordStore_read_write_ne _ (by decide), wordStore_read_write_self]
    · dsimp [ws3, ws2, tid]
      rw [wordStore_read_write_ne _ (by decide), wordStore_read_write_self]
    · dsimp [ws3]; rw [wordStore_read_write_self]
    · intro loc _ _ n113 n114 n115 _
      dsimp [ws3, ws2, ws1, WordStore.write]
      exact ⟨by simp [n115, n114, n113],
        by simp [Function.update_of_ne n115, Function.update_of_ne n114, Function.update_of_ne n113]⟩
  obtain ⟨wsL, regsL, p15, ⟨_, hmL, bgL, ⟨rNum, rDen, htreeSj_L, hrBnds_L⟩, htree1_L, _, _, _, hunchL⟩⟩ :=
    c2_repeatReg_inv (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      (cntReg := 5) (by decide) m (by simp [g14])
      (SjLoopInv d L B B_cert K_max j m hSeq qMap oRat V ws0 W)
      hSj0 bg14
      (U := 240 * d + 700 * L + 600) (B := (56 * d + 112 * L + 110) * W * W)
      (fun r hr w rg hInv =>
        exec_buildSjResStepStmt hd1 hfd_le hm0.wf hL1 hB1 hBc1 hj hm_le hW hcCeil hbCeil
          hbuf0 hhSeq_mem hcoords0 hgeom0 hr hInv)
  -- Phase 3: `freeScratch111to116Regs`
  obtain ⟨wsC, regsC, p16, hmC, bgC, hn111_C, hn112_C, hn113_C, hn114_C, hn115_C, hn116_C, hunchC⟩ :=
    exec_freeScratch111to116Regs hfd_le (by omega) hmL hcCeil hbCeil bgL
  have hunch_C_ws0 : ∀ loc : RAMCellLoc,
      loc ∉ treeSliceLocs L tid → loc ∉ treeSliceLocs L 1 →
      loc ≠ .heap 9 111 → loc ≠ .heap 9 112 → loc ≠ .heap 9 113 →
      loc ≠ .heap 9 114 → loc ≠ .heap 9 115 → loc ≠ .heap 9 116 →
      (loc ∈ wsC.live ↔ loc ∈ ws0.live) ∧ wsC.vals loc = ws0.vals loc := by
    intro loc nsSj ns1 n111 n112 n113 n114 n115 n116
    have uC := hunchC loc n111 n112 n113 n114 n115 n116
    have uL := hunchL loc nsSj ns1 n113 n114 n115 n116
    exact ⟨uC.1.trans uL.1, uC.2.trans uL.2⟩
  have hr110_C : wsC.read (.heap 9 110) = (m : ℤ) :=
    (read_eq_of_unch (hunch_C_ws0 _ (not_slice (by decide)) (not_slice (by decide))
      (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))).trans hr110_0
  have hclean8_C : ∀ z : ℤ, (∀ k < m, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsC.live := by
    intro z hz hm
    have hm0_live := (hunch_C_ws0 _ (not_slice (by decide)) (not_slice (by decide))
      (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)
      (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)).1.mp hm
    have hws_live := (hunch0 _ (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)
      (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)).1.mp hm0_live
    exact hclean8 z hz hws_live
  -- Phase 4: `freeBufRegs`
  obtain ⟨wsF, regsF, p17, hmF, bgF, hfree8_F, hn110_F, hunchF⟩ :=
    exec_freeBufRegs hfd_le hmC hCeil0C hCeil0B hm_le (by clear * - hW; omega)
      (fun k hk => mem_posDimWriteLocs_tab8 (by omega))
      (mem_posDimWriteLocs_tab9 (by decide))
      hr110_C bgC
  have hall8_F : ∀ z : ℤ, (.heap 8 z : RAMCellLoc) ∉ wsF.live := by
    intro z
    by_cases hkz : ∃ k < m, z = (k : ℤ)
    · rcases hkz with ⟨k, hk, rfl⟩; exact hfree8_F k hk
    · push_neg at hkz
      intro hm
      exact hclean8_C z hkz ((hunchF _ (fun h => by cases h)
        (fun k hk heq => hkz k hk (by injection heq))).1.mp hm)
  have hn111_F : (.heap 9 111 : RAMCellLoc) ∉ wsF.live := fun hm =>
    hn111_C ((hunchF _ (by decide) (fun _ _ h => by cases h)).1.mp hm)
  have hn112_F : (.heap 9 112 : RAMCellLoc) ∉ wsF.live := fun hm =>
    hn112_C ((hunchF _ (by decide) (fun _ _ h => by cases h)).1.mp hm)
  have htree1_F : TreeStoredAt L 1 S_res_H (fun _ => 0) (fun _ => 1) wsF :=
    htree1_L.unchanged (fun u _ f _ => by
      have uF := hunchF (.heap 2 (treeCellAddr L 1 u f)) (fun h => by cases h) (fun _ _ h => by cases h)
      have uC := hunchC (.heap 2 (treeCellAddr L 1 u f)) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)
        (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)
      exact ⟨uF.1.trans uC.1, uF.2.trans uC.2⟩)
  -- Phase 5: `rLit 0 1; popTreeToBufRegs L`
  have p18 := RegExec.lit (inp := inp) hfd_le bgF (sp_ok hmF).1 (sp_ok hmF).2 (dst := 0) (c := 1) (by decide) hl1
  set g18 := Function.update regsF 0 1; have bg18 : RegBounded W g18 := bgF.update (r := 0) (by decide) hl1
  have hSres_bnds : ∀ h ∈ S_res_H, h < 2 ^ L ∧ intBitLength ((0 : ℤ)) ≤ 2 ∧ intBitLength ((1 : ℤ)) ≤ 2 := by
    intro h hh
    rcases Finset.mem_image.mp (Finset.mem_filter.mp hh).1 with ⟨k, hk, rfl⟩
    exact ⟨(hcoords.hS (hSeq k) (hhSeq_mem k (Finset.mem_range.mp hk))).1, by decide, by decide⟩
  obtain ⟨wsP, regsP, p19, hmP, bgP, htree1_P, hr110_P, hbuf_P, hunchP⟩ :=
    exec_popTreeToBufRegs hfd_le hmF hCeil0C hCeil0B hL1 (tid := 1) (B_r := 2) (by decide)
      (by have h1 : natBitLength 1 = 1 := (by decide); clear * - h1 hW; omega)
      (fun u hu f hf => mem_posDimWriteLocs_tree ht1_lt hu hf)
      (fun k hk => mem_posDimWriteLocs_tab8 (by omega))
      (mem_posDimWriteLocs_tab9 (by decide))
      (mem_posDimWriteLocs_tab9 (by decide))
      (mem_posDimWriteLocs_tab9 (by decide))
      hn111_F hn112_F htree1_F hSres_bnds bg18 (by simp [g18])
  have hr_jP : wsP.read (.heap 0 10) = (j : ℤ) := by
    have uP := hunchP (.heap 0 10) (not_slice (by decide)) (by decide) (fun _ _ h => by cases h)
    have uF := hunchF (.heap 0 10) (by decide) (fun _ _ h => by cases h)
    have uC := hunch_C_ws0 (.heap 0 10) (not_slice (by decide)) (not_slice (by decide))
      (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    exact (read_eq_of_unch ⟨uP.1.trans (uF.1.trans uC.1), uP.2.trans (uF.2.trans uC.2)⟩).trans hr_j0
  have hSres_le_m : S_res_H.card ≤ m := by
    calc S_res_H.card ≤ S_H.card := Finset.card_filter_le _ _
      _ ≤ (Finset.range m).card := Finset.card_image_le
      _ = m := Finset.card_range m
  have pAll : RegExec inp fd W C_cell C_bit (buildSjTreeAndResidualBufRegs d L) ws regs wsP regsP
      ((m + 1) * (240 * d + 1180 * L + 1000) + 600)
      ((m + 1) * (56 * d + 200 * L + 240) * W * W + 200 * W * W) := by
    refine (p0.seq (p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq (p7.seq (p8.seq
      (p9.seq (p10.seq (p11.seq (p12.seq (p13.seq (p14.seq (p15.seq (p16.seq
      (p17.seq (p18.seq p19))))))))))))))))))).weaken rfl rfl ?_ ?_
    · clear * - hSres_le_m; nlinarith
    · have hm12 : 12 * m + 24 ≤ (m + 1) * 12 * W := by
        calc 12 * m + 24 ≤ (m + 1) * 480 := by omega
        _ = (m + 1) * 12 * 40 := by ring
        _ ≤ (m + 1) * 12 * W := Nat.mul_le_mul_left _ hW40
      have hmW : (12 * m + 24) * W ≤ (m + 1) * 12 * W * W := Nat.mul_le_mul_right W hm12
      have hpop : (S_res_H.card + 1) * (76 * L + 100) * W * W ≤ (m + 1) * (76 * L + 100) * W * W :=
        Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (Nat.mul_le_mul_right _ (by omega)))
      have hloop : m * ((56 * d + 112 * L + 110) * W * W) + (m + 1) * 12 * W * W +
          (m + 1) * (76 * L + 100) * W * W ≤ (m + 1) * (56 * d + 200 * L + 240) * W * W := by
        calc m * ((56 * d + 112 * L + 110) * W * W) + (m + 1) * 12 * W * W +
              (m + 1) * (76 * L + 100) * W * W
          _ = (m * (56 * d + 112 * L + 110) + (m + 1) * (76 * L + 112)) * (W * W) := by ring
          _ ≤ ((m + 1) * (56 * d + 200 * L + 240)) * (W * W) :=
              Nat.mul_le_mul_right (W * W) (by clear * -; nlinarith)
          _ = (m + 1) * (56 * d + 200 * L + 240) * W * W := by ring
      have hconst : (40 * W + 240) + (53 * W + 304) + (W + 12) + (40 * W + 240) + (2 * W + 16) ≤
          200 * W * W := by
        calc (40 * W + 240) + (53 * W + 304) + (W + 12) + (40 * W + 240) + (2 * W + 16)
          _ ≤ 200 * (40 * W) := by clear * - hW40; omega
          _ ≤ 200 * (W * W) := Nat.mul_le_mul_left 200 hWW
          _ = 200 * W * W := by ring
      linarith only [hmW, hpop, hloop, hconst]
  have htreeSj_End : TreeStoredAt L tid S_H rNum rDen wsP := by
    refine htreeSj_L.unchanged (fun u hu f hf => ?_)
    have not_s1 : (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∉ treeSliceLocs L 1 :=
      not_mem_treeSliceLocs_of_ne htid_ne1 hu hf
    have uP := hunchP (.heap 2 (treeCellAddr L tid u f)) not_s1 (fun h => by cases h) (fun _ _ h => by cases h)
    have uF := hunchF (.heap 2 (treeCellAddr L tid u f)) (fun h => by cases h) (fun _ _ h => by cases h)
    have uC := hunchC (.heap 2 (treeCellAddr L tid u f)) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)
      (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)
    exact ⟨uP.1.trans (uF.1.trans uC.1), uP.2.trans (uF.2.trans uC.2)⟩
  have hbuf_End : ∃ hSeq' : ℕ → ℕ,
      (∀ k < S_res_H.card, hSeq' k < 2 ^ L ∧ wsP.read (.heap 8 (k : ℤ)) = (hSeq' k : ℤ)) ∧
      (Finset.range S_res_H.card).image hSeq' = S_res_H := by
    refine ⟨minPopElem S_res_H, fun k hk => ?_, image_minPopElem_eq S_res_H⟩
    have hmem : minPopElem S_res_H k ∈ S_res_H := (minPopElem_step hk).2.2.2.1
    exact ⟨(hSres_bnds _ hmem).1, hbuf_P k hk⟩
  have hclean8_End : ∀ z : ℤ, (∀ k < S_res_H.card, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ wsP.live := by
    intro z hz hmP
    have hmF := (hunchP (.heap 8 z) (not_slice (by decide)) (fun h => by cases h)
      (fun k hk heq => hz k hk (by injection heq))).1.mp hmP
    exact hall8_F z hmF
  have hheap9_End : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ wsP.live →
      z = 110 ∨ (.heap 9 z : RAMCellLoc) ∈ ws.live := by
    intro z hmP
    by_cases hz110 : z = 110; · exact Or.inl hz110
    right
    have hmF := (hunchP (.heap 9 z) (not_slice (by decide))
      (fun h => hz110 (by injection h)) (fun _ _ h => by cases h)).1.mp hmP
    have hmC := (hunchF (.heap 9 z) (fun h => hz110 (by injection h)) (fun _ _ h => by cases h)).1.mp hmF
    have n111 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 111 := fun h => hn111_C (h ▸ hmC)
    have n112 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 112 := fun h => hn112_C (h ▸ hmC)
    have n113 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 113 := fun h => hn113_C (h ▸ hmC)
    have n114 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 114 := fun h => hn114_C (h ▸ hmC)
    have n115 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 115 := fun h => hn115_C (h ▸ hmC)
    have n116 : (.heap 9 z : RAMCellLoc) ≠ .heap 9 116 := fun h => hn116_C (h ▸ hmC)
    have hm0 := (hunch_C_ws0 (.heap 9 z) (not_slice (by decide)) (not_slice (by decide))
      n111 n112 n113 n114 n115 n116).1.mp hmC
    exact (hunch0 (.heap 9 z) n111 n112 n113 n114 n115 n116).1.mp hm0
  have hunch_End : ∀ loc : RAMCellLoc,
      loc ≠ .heap 0 10 → loc ∉ treeSliceLocs L tid → loc ∉ treeSliceLocs L 1 →
      (∀ z : ℤ, loc ≠ .heap 8 z) →
      loc ≠ .heap 9 110 → loc ≠ .heap 9 111 → loc ≠ .heap 9 112 →
      loc ≠ .heap 9 113 → loc ≠ .heap 9 114 → loc ≠ .heap 9 115 → loc ≠ .heap 9 116 →
      (loc ∈ wsP.live ↔ loc ∈ ws.live) ∧ wsP.vals loc = ws.vals loc := by
    intro loc _ nsSj ns1 n8 n110 n111 n112 n113 n114 n115 n116
    have uP := hunchP loc ns1 n110 (fun k _ => n8 (k : ℤ))
    have uF := hunchF loc n110 (fun k _ => n8 (k : ℤ))
    have uC := hunch_C_ws0 loc nsSj ns1 n111 n112 n113 n114 n115 n116
    have u0 := hunch0 loc n111 n112 n113 n114 n115 n116
    exact ⟨uP.1.trans (uF.1.trans (uC.1.trans u0.1)),
           uP.2.trans (uF.2.trans (uC.2.trans u0.2))⟩
  exact ⟨wsP, regsP, pAll, hmP, bgP, ⟨rNum, rDen, htreeSj_End, hrBnds_L⟩,
    htree1_P, hr_jP, hr110_P, hbuf_End, hclean8_End, hheap9_End, hunch_End⟩

end UL.C12StepC2
