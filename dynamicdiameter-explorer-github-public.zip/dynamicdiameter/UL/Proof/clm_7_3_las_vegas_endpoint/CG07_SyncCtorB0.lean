import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorB0a
set_option autoImplicit false
set_option maxHeartbeats 400000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open scoped ENNReal
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

private lemma stepRetHandle_ansPolPosDim {d s₀_d L : ℕ} (H : Finset ℕ) (op : DynamicUpdate d) :
    stepRetHandle (ansPolPosDim d s₀_d L).allocHandle H op = stepRetHandle mexHandle H op := by
  cases op <;> rfl

private lemma nat_find_irrel {p : ℕ → Prop} (i₁ i₂ : DecidablePred p) (h₁ h₂ : ∃ n, p n) :
    @Nat.find p i₁ h₁ = @Nat.find p i₂ h₂ :=
  le_antisymm
    (@Nat.find_min' p i₁ h₁ _ (@Nat.find_spec p i₂ h₂))
    (@Nat.find_min' p i₂ h₂ _ (@Nat.find_spec p i₁ h₁))

theorem c12SyncStep_decomp
    {d s₀_d B n : ℕ} (hn : 2 ≤ n) (hs₀ : 1 ≤ s₀_d)
    {c₁ C_nodes : ℝ} (hc₁_pos : 0 < c₁) (hCn_pos : 0 < C_nodes)
    (h51 : ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ), 0 < α → α ≤ 1 →
      (∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
        ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
          ∀ (age : ℕ), HasNodeAge P₀ S age →
            (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
            let V := liftVariance o s
            let C := nodeCore pts o V S
            let child := nodeResidual pts o V S
            let m : ℝ := P₀.card
            15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
            (S.card : ℝ) ≤ (1 + α / 16) * m ∧
            (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ)) ∧
      (∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
        (∀ (k : ℕ) (nodes : Fin k → ChainNode d)
            (P₀ : Fin k → Finset ι)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
            (age : Fin k → ℕ),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
          (∀ j : Fin (k + 1),
            ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
          ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
          (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1)) ∧
        (∀ (L_leaf : ℕ),
          (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
            ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
              IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
          ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
            (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) ∧
            (∀ i : Fin k,
              L_leaf < (chainInput pts nodes P i.castSucc).card ∧
              (nodes i).o = o i ∧
              (nodes i).V = liftVariance (o i) (s i) ∧
              IsCenterpoint α
                (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
                (liftedPoint (o i) (s i))) ∧
            (chainTerminal pts nodes P).card ≤ L_leaf ∧
            (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2)))
    {P_node_val : ℝ} (hPn_nn : 0 ≤ P_node_val)
    {ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d s₀_d)}
    (hctor : IsValidSyncNodeConstructor n (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ))) 1 P_node_val
      (RatAdmissiblePointSet d B) ctor)
    (hctor_wk : ∀ hist sufPref ltCoords P₀ bs built,
      2 * s₀_d ≤ P₀.card →
      (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) →
      ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
        P₀.card ≤ built.work)
    {cur syncNext : SyncSchedulePrefixState d (PosDimNodeData d s₀_d)}
    {op : DynamicUpdate d} {bs : List Bool}
    (hinv : C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) cur)
    (hleg : IsLegalUpdate n (RatAdmissiblePointSet d B) cur.pointSet op)
    (hstep : runSingleSyncScheduleStep (2 * s₀_d - 1) (1 / (4 * (s₀_d : ℝ))) ctor
      (ansPolPosDim d s₀_d (Nat.clog 2 (2 * n))) cur op bs = some syncNext) :
    let L := Nat.clog 2 (2 * n)
    C12SyncInv s₀_d B n (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) syncNext ∧
    C12SyncStepDecomp s₀_d L ctor cur syncNext op bs := by
  classical
  intro L
  let L_leaf : ℕ := 2 * s₀_d - 1
  let α : ℝ := 1 / (4 * (s₀_d : ℝ))
  let ansPol := ansPolPosDim d s₀_d L
  let P_α_d : ℝ := 4 * (s₀_d : ℝ)
  have hs₀_R : (1 : ℝ) ≤ (s₀_d : ℝ) := by exact_mod_cast hs₀
  have hPα_ge1 : 1 ≤ P_α_d := by dsimp [P_α_d]; linarith
  have hα_pos : 0 < α := by dsimp [α]; positivity
  have hα_le1 : α ≤ 1 := by dsimp [α]; rw [div_le_one (by positivity)]; linarith
  have hans := isValidSyncCheckedAnswerPolicy_ansPolPosDim (d := d) (s₀_d := s₀_d) (n := n) (L := L)
  rcases hinv with ⟨hsync, hreplay⟩
  have hprops := runSingleSyncScheduleStep_props hc₁_pos hCn_pos h51 hn hα_pos hα_le1
    hPα_ge1 le_rfl zero_le_one hPn_nn hctor hans hsync hleg
  have hsync_next := (hprops.2.1 bs syncNext hstep).1
  obtain ⟨P', happly, hP'_wf, _, _, hP'_adm, _⟩ :=
    applyDynamicUpdate_legal hsync.1 hleg hans.1 hsync.2.1
  have happly_mex : applyDynamicUpdate cur.pointSet op
      (stepRetHandle mexHandle cur.pointSet.activeHandles op) = some P' := happly
  -- Unpack `runSingleSyncScheduleStep` cleanly across `op`
  let k := cur.nodes.length
  let vecNodes : Fin k → ChainNode d := fun i => (cur.nodes.get i).built.node
  let ltCoords' := opNextLtCoords cur.pointSet cur.ltCoords op
  let S_old := chainInput ltCoords' vecNodes (activeLifetimes cur.pointSet)
  let S_new := chainInput ltCoords' vecNodes (activeLifetimes P')
  let updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)) :=
    List.ofFn (fun i : Fin k =>
      let v := cur.nodes.get i
      let age' := if S_new i.castSucc ≠ S_old i.castSucc then
        insert cur.history.length v.ageUpdateSteps else v.ageUpdateSteps
      { v with ageUpdateSteps := age' })
  let slotTriggers : ℕ → Prop := fun j =>
    if hj : j < k then
      let vOld := cur.nodes.get ⟨j, hj⟩
      let ageCard :=
        (if S_new ⟨j, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨j, Nat.lt_succ_of_lt hj⟩ then
          insert cur.history.length vOld.ageUpdateSteps
        else
          vOld.ageUpdateSteps).card
      α * (vOld.birthPool.card : ℝ) / 16 < (ageCard : ℝ)
    else
      j = k ∧ 2 * L_leaf < (S_new (Fin.last k)).card
  have hraw :
      syncNext.pointSet = P' ∧
      syncNext.ltCoords = ltCoords' ∧
      cur.totalRebuildWork ≤ syncNext.totalRebuildWork ∧
      syncNext.history = cur.history ++
        [{ operation := op
           randomBits := bs
           returnedHandle := stepRetHandle ansPol.allocHandle cur.pointSet.activeHandles op
           answer := ansPol.checkedAnswer P' syncNext.nodes
           resolvedIds := resolveAnswerIdentities P' (ansPol.checkedAnswer P' syncNext.nodes) }] ∧
      syncNext.snapshots = cur.snapshots ++
        [(P', ansPol.checkedAnswer P' syncNext.nodes)] ∧
      (if hTrig : ∃ j ≤ k, slotTriggers j then
         let jStar := Nat.find hTrig
         have hjLe : jStar ≤ k := (Nat.find_spec hTrig).1
         ∃ sufOut : SyncSuffixOutcome d (PosDimNodeData d s₀_d),
           runSyncSuffixBuild ctor L_leaf cur.history ltCoords'
             (S_new ⟨jStar, Nat.lt_succ_of_le hjLe⟩) bs = some sufOut ∧
           syncNext.nodes = updatedNodes.take jStar ++ c12EntriesToLiveNodes sufOut.entries ∧
           syncNext.totalRebuildWork = cur.totalRebuildWork + sufOut.totalWork
       else
         bs = [] ∧ syncNext.nodes = updatedNodes ∧ syncNext.totalRebuildWork = cur.totalRebuildWork) := by
    clear hprops hsync_next
    unfold runSingleSyncScheduleStep at hstep
    cases hop : op with
    | insert id_i ext_i pt_i =>
        have happ' : applyDynamicUpdate cur.pointSet (.insert id_i ext_i pt_i)
            (some (ansPol.allocHandle cur.pointSet.activeHandles)) = some P' := by
          rw [hop] at happly; exact happly
        have hltc_eq : Function.update cur.ltCoords cur.pointSet.nextLifetime pt_i = ltCoords' := by
          simp [ltCoords', hop, opNextLtCoords]
        rw [hop] at hstep; dsimp only at hstep; rw [happ'] at hstep; dsimp only at hstep
        -- Match trigger predicate by `hltc_eq` and `activeLifetimes`
        let rawPred : ℕ → Prop := fun j =>
          if hj : j < cur.nodes.length then
            α * ((cur.nodes.get ⟨j, hj⟩).birthPool.card : ℝ) / 16 <
              ((if chainInput (Function.update cur.ltCoords cur.pointSet.nextLifetime pt_i)
                    vecNodes (P'.activeIds.image P'.lifetimeOfId) ⟨j, Nat.lt_succ_of_lt hj⟩ ≠
                  chainInput (Function.update cur.ltCoords cur.pointSet.nextLifetime pt_i)
                    vecNodes (cur.pointSet.activeIds.image cur.pointSet.lifetimeOfId) ⟨j, Nat.lt_succ_of_lt hj⟩
                then insert cur.history.length (cur.nodes.get ⟨j, hj⟩).ageUpdateSteps
                else (cur.nodes.get ⟨j, hj⟩).ageUpdateSteps).card : ℝ)
          else
            j = cur.nodes.length ∧
            2 * L_leaf < (chainInput (Function.update cur.ltCoords cur.pointSet.nextLifetime pt_i)
              vecNodes (P'.activeIds.image P'.lifetimeOfId) (Fin.last cur.nodes.length)).card
        have htrig_eq : rawPred = slotTriggers := by
          funext j; dsimp only [rawPred, slotTriggers, S_new, S_old, activeLifetimes, k]; rw [hltc_eq]
        have hupd_eq : (List.ofFn (fun i : Fin cur.nodes.length =>
            let v := cur.nodes.get i
            let age' := if chainInput (Function.update cur.ltCoords cur.pointSet.nextLifetime pt_i)
                  vecNodes (P'.activeIds.image P'.lifetimeOfId) i.castSucc ≠
                chainInput (Function.update cur.ltCoords cur.pointSet.nextLifetime pt_i)
                  vecNodes (cur.pointSet.activeIds.image cur.pointSet.lifetimeOfId) i.castSucc
              then insert cur.history.length v.ageUpdateSteps else v.ageUpdateSteps
            { v with ageUpdateSteps := age' })) = updatedNodes := by
          dsimp only [updatedNodes, S_new, S_old, activeLifetimes, k]; rw [hltc_eq]
        by_cases hTrig : ∃ j ≤ k, slotTriggers j
        · have hTrig_raw : ∃ j : ℕ, j ≤ cur.nodes.length ∧ rawPred j := by
            rcases hTrig with ⟨j, hj, htr⟩
            exact ⟨j, hj, by rwa [htrig_eq]⟩
          rw [dif_pos hTrig_raw] at hstep
          have hfind_eq : Nat.find hTrig_raw = Nat.find hTrig := by
            rw [Nat.find_eq_iff]
            refine ⟨?_, fun m hm ⟨hm_le, hm_tr⟩ => ?_⟩
            · obtain ⟨h1, h2⟩ := Nat.find_spec hTrig
              exact ⟨h1, by rwa [htrig_eq]⟩
            · exact Nat.find_min hTrig hm ⟨hm_le, by rwa [← htrig_eq]⟩
          let jStar := Nat.find hTrig
          have hjLe : jStar ≤ k := (Nat.find_spec hTrig).1
          cases hsuf : runSyncSuffixBuild ctor L_leaf cur.history ltCoords'
              (S_new ⟨jStar, Nat.lt_succ_of_le hjLe⟩) bs with
          | none =>
              have hsuf_raw : runSyncSuffixBuild ctor L_leaf cur.history
                  (Function.update cur.ltCoords cur.pointSet.nextLifetime pt_i)
                  (chainInput (Function.update cur.ltCoords cur.pointSet.nextLifetime pt_i)
                    vecNodes (P'.activeIds.image P'.lifetimeOfId)
                    ⟨Nat.find hTrig_raw, Nat.lt_succ_of_le (Nat.find_spec hTrig_raw).1⟩) bs = none := by
                have hfin_eq : (⟨Nat.find hTrig_raw, Nat.lt_succ_of_le (Nat.find_spec hTrig_raw).1⟩ : Fin (k + 1)) =
                    ⟨jStar, Nat.lt_succ_of_le hjLe⟩ := Fin.ext hfind_eq
                dsimp only [S_new, activeLifetimes] at hsuf
                rw [hfin_eq]; rw [hltc_eq]; exact hsuf
              rw [hsuf_raw] at hstep; cases hstep
          | some sufOut =>
              have hsuf_raw : runSyncSuffixBuild ctor L_leaf cur.history
                  (Function.update cur.ltCoords cur.pointSet.nextLifetime pt_i)
                  (chainInput (Function.update cur.ltCoords cur.pointSet.nextLifetime pt_i)
                    vecNodes (P'.activeIds.image P'.lifetimeOfId)
                    ⟨Nat.find hTrig_raw, Nat.lt_succ_of_le (Nat.find_spec hTrig_raw).1⟩) bs = some sufOut := by
                have hfin_eq : (⟨Nat.find hTrig_raw, Nat.lt_succ_of_le (Nat.find_spec hTrig_raw).1⟩ : Fin (k + 1)) =
                    ⟨jStar, Nat.lt_succ_of_le hjLe⟩ := Fin.ext hfind_eq
                dsimp only [S_new, activeLifetimes] at hsuf
                rw [hfin_eq]; rw [hltc_eq]; exact hsuf
              rw [hsuf_raw] at hstep; dsimp only at hstep
              injection hstep with hne; subst hne
              refine ⟨rfl, hltc_eq, Nat.le_add_right _ _, rfl, rfl, ?_⟩
              rw [dif_pos hTrig]
              refine ⟨sufOut, hsuf, ?_, rfl⟩
              dsimp only [c12EntriesToLiveNodes, c12EntryToLiveNode]
              rw [hupd_eq, hfind_eq]
        · have hnTrig_raw : ¬ ∃ j : ℕ, j ≤ cur.nodes.length ∧ rawPred j := by
            rintro ⟨j, hj, htr⟩
            exact hTrig ⟨j, hj, by rwa [← htrig_eq]⟩
          rw [dif_neg hnTrig_raw] at hstep
          by_cases hemp : bs.isEmpty = true
          · rw [if_pos hemp] at hstep
            injection hstep with hne; subst hne
            have hbs_nil : bs = [] := List.isEmpty_iff.mp hemp
            subst hbs_nil
            refine ⟨rfl, hltc_eq, le_rfl, rfl, rfl, ?_⟩
            rw [dif_neg hTrig]
            exact ⟨rfl, hupd_eq, rfl⟩
          · rw [if_neg hemp] at hstep; cases hstep
    | delete id_d =>
        have happ' : applyDynamicUpdate cur.pointSet (.delete id_d) none = some P' := by
          simpa [hop, stepRetHandle] using happly_mex
        have hltc_eq : cur.ltCoords = ltCoords' := by
          simp [ltCoords', hop, opNextLtCoords]
        rw [hop] at hstep; dsimp only at hstep; rw [happ'] at hstep; dsimp only at hstep
        let rawPred : ℕ → Prop := fun j =>
          if hj : j < cur.nodes.length then
            α * ((cur.nodes.get ⟨j, hj⟩).birthPool.card : ℝ) / 16 <
              ((if chainInput cur.ltCoords vecNodes (P'.activeIds.image P'.lifetimeOfId) ⟨j, Nat.lt_succ_of_lt hj⟩ ≠
                  chainInput cur.ltCoords vecNodes (cur.pointSet.activeIds.image cur.pointSet.lifetimeOfId) ⟨j, Nat.lt_succ_of_lt hj⟩
                then insert cur.history.length (cur.nodes.get ⟨j, hj⟩).ageUpdateSteps
                else (cur.nodes.get ⟨j, hj⟩).ageUpdateSteps).card : ℝ)
          else
            j = cur.nodes.length ∧
            2 * L_leaf < (chainInput cur.ltCoords vecNodes (P'.activeIds.image P'.lifetimeOfId)
              (Fin.last cur.nodes.length)).card
        have htrig_eq : rawPred = slotTriggers := by
          funext j; dsimp only [rawPred, slotTriggers, S_new, S_old, activeLifetimes, k]; rw [hltc_eq]
        have hupd_eq : (List.ofFn (fun i : Fin cur.nodes.length =>
            let v := cur.nodes.get i
            let age' := if chainInput cur.ltCoords vecNodes (P'.activeIds.image P'.lifetimeOfId) i.castSucc ≠
                chainInput cur.ltCoords vecNodes (cur.pointSet.activeIds.image cur.pointSet.lifetimeOfId) i.castSucc
              then insert cur.history.length v.ageUpdateSteps else v.ageUpdateSteps
            { v with ageUpdateSteps := age' })) = updatedNodes := by
          dsimp only [updatedNodes, S_new, S_old, activeLifetimes, k]; rw [hltc_eq]
        by_cases hTrig : ∃ j ≤ k, slotTriggers j
        · have hTrig_raw : ∃ j : ℕ, j ≤ cur.nodes.length ∧ rawPred j := by
            rcases hTrig with ⟨j, hj, htr⟩
            exact ⟨j, hj, by rwa [htrig_eq]⟩
          rw [dif_pos hTrig_raw] at hstep
          have hfind_eq : Nat.find hTrig_raw = Nat.find hTrig := by
            rw [Nat.find_eq_iff]
            refine ⟨?_, fun m hm ⟨hm_le, hm_tr⟩ => ?_⟩
            · obtain ⟨h1, h2⟩ := Nat.find_spec hTrig
              exact ⟨h1, by rwa [htrig_eq]⟩
            · exact Nat.find_min hTrig hm ⟨hm_le, by rwa [← htrig_eq]⟩
          let jStar := Nat.find hTrig
          have hjLe : jStar ≤ k := (Nat.find_spec hTrig).1
          cases hsuf : runSyncSuffixBuild ctor L_leaf cur.history ltCoords'
              (S_new ⟨jStar, Nat.lt_succ_of_le hjLe⟩) bs with
          | none =>
              have hsuf_raw : runSyncSuffixBuild ctor L_leaf cur.history cur.ltCoords
                  (chainInput cur.ltCoords vecNodes (P'.activeIds.image P'.lifetimeOfId)
                    ⟨Nat.find hTrig_raw, Nat.lt_succ_of_le (Nat.find_spec hTrig_raw).1⟩) bs = none := by
                have hfin_eq : (⟨Nat.find hTrig_raw, Nat.lt_succ_of_le (Nat.find_spec hTrig_raw).1⟩ : Fin (k + 1)) =
                    ⟨jStar, Nat.lt_succ_of_le hjLe⟩ := Fin.ext hfind_eq
                dsimp only [S_new, activeLifetimes] at hsuf
                rw [hfin_eq]; rw [hltc_eq]; exact hsuf
              rw [hsuf_raw] at hstep; cases hstep
          | some sufOut =>
              have hsuf_raw : runSyncSuffixBuild ctor L_leaf cur.history cur.ltCoords
                  (chainInput cur.ltCoords vecNodes (P'.activeIds.image P'.lifetimeOfId)
                    ⟨Nat.find hTrig_raw, Nat.lt_succ_of_le (Nat.find_spec hTrig_raw).1⟩) bs = some sufOut := by
                have hfin_eq : (⟨Nat.find hTrig_raw, Nat.lt_succ_of_le (Nat.find_spec hTrig_raw).1⟩ : Fin (k + 1)) =
                    ⟨jStar, Nat.lt_succ_of_le hjLe⟩ := Fin.ext hfind_eq
                dsimp only [S_new, activeLifetimes] at hsuf
                rw [hfin_eq]; rw [hltc_eq]; exact hsuf
              rw [hsuf_raw] at hstep; dsimp only at hstep
              injection hstep with hne; subst hne
              refine ⟨rfl, hltc_eq, Nat.le_add_right _ _, rfl, rfl, ?_⟩
              rw [dif_pos hTrig]
              refine ⟨sufOut, hsuf, ?_, rfl⟩
              dsimp only [c12EntriesToLiveNodes, c12EntryToLiveNode]
              rw [hupd_eq, hfind_eq]
        · have hnTrig_raw : ¬ ∃ j : ℕ, j ≤ cur.nodes.length ∧ rawPred j := by
            rintro ⟨j, hj, htr⟩
            exact hTrig ⟨j, hj, by rwa [← htrig_eq]⟩
          rw [dif_neg hnTrig_raw] at hstep
          by_cases hemp : bs.isEmpty = true
          · rw [if_pos hemp] at hstep
            injection hstep with hne; subst hne
            have hbs_nil : bs = [] := List.isEmpty_iff.mp hemp
            subst hbs_nil
            refine ⟨rfl, hltc_eq, le_rfl, rfl, rfl, ?_⟩
            rw [dif_neg hTrig]
            exact ⟨rfl, hupd_eq, rfl⟩
          · rw [if_neg hemp] at hstep; cases hstep
  obtain ⟨hp_eq, hlt_eq, hwk_mono, hhist_eq, hsnap_eq, hbr⟩ := hraw
  have hreplay_next : c12ReplayHistory d syncNext.history = syncNext.pointSet := by
    rw [hhist_eq, c12ReplayHistory_append]
    unfold c12ReplayStep; dsimp only
    rw [hreplay, happly, hp_eq]; rfl
  refine ⟨⟨hsync_next, hreplay_next⟩, ?_⟩
  -- Assemble `C12SyncStepDecomp` (substitute `P' = syncNext.pointSet`)
  have happly_sync : applyDynamicUpdate cur.pointSet op
      (stepRetHandle mexHandle cur.pointSet.activeHandles op) = some syncNext.pointSet :=
    hp_eq ▸ happly_mex
  have hhist_sync : syncNext.history = cur.history ++
      [{ operation := op
         randomBits := bs
         returnedHandle := stepRetHandle mexHandle cur.pointSet.activeHandles op
         answer := (ansPolPosDim d s₀_d L).checkedAnswer syncNext.pointSet syncNext.nodes
         resolvedIds := resolveAnswerIdentities syncNext.pointSet
           ((ansPolPosDim d s₀_d L).checkedAnswer syncNext.pointSet syncNext.nodes) }] := by
    dsimp only [ansPol] at hhist_eq
    rw [stepRetHandle_ansPolPosDim, ← hp_eq] at hhist_eq
    exact hhist_eq
  have hsnap_sync : syncNext.snapshots = cur.snapshots ++
      [(syncNext.pointSet, (ansPolPosDim d s₀_d L).checkedAnswer syncNext.pointSet syncNext.nodes)] := by
    dsimp only [ansPol] at hsnap_eq
    rw [← hp_eq] at hsnap_eq
    exact hsnap_eq
  refine
    { apply_eq := happly_sync
      ltCoords_eq := hlt_eq
      work_mono := hwk_mono
      history_eq := hhist_sync
      snapshots_eq := hsnap_sync
      no_trig_age := ?_
      no_trig_leaf := ?_
      sync_branch := ?_
      pot_bound := ?_ }
  · subst hp_eq
    dsimp only
    intro j hj hnt
    rw [dif_pos hj] at hnt
    have hle := not_lt.mp hnt
    rw [List.get_ofFn]; exact hle
  · subst hp_eq
    dsimp only
    intro hnt
    rw [dif_neg (Nat.lt_irrefl k)] at hnt
    have hle : ¬ (2 * L_leaf < (S_new (Fin.last k)).card) := fun hgt => hnt ⟨rfl, hgt⟩
    omega
  · -- `sync_branch`
    subst hp_eq
    dsimp only
    by_cases hTrig : ∃ j ≤ k, slotTriggers j
    · rw [dif_pos hTrig] at hbr ⊢
      obtain ⟨sufOut, hsuf, hnodes_eq, htot_eq⟩ := hbr
      obtain ⟨hjs_find, hjLe, _⟩ := (jStarStep_final k slotTriggers).1 hTrig
      have hjs_eq : jStarStep k slotTriggers (k + 1) = Nat.find hTrig :=
        hjs_find.trans (nat_find_irrel _ _ _ _)
      have hfin_eq : (⟨jStarStep k slotTriggers (k + 1), Nat.lt_succ_of_le hjLe⟩ : Fin (k + 1)) =
          ⟨Nat.find hTrig, Nat.lt_succ_of_le (Nat.find_spec hTrig).1⟩ := by
        apply Fin.ext; dsimp only; exact hjs_eq
      refine ⟨sufOut, ?_, ?_, by omega⟩
      · rw [hfin_eq]; exact hsuf
      · rw [hjs_eq]; exact hnodes_eq
    · rw [dif_neg hTrig] at hbr ⊢
      obtain ⟨hbs_nil, hnodes_eq, htot_eq⟩ := hbr
      exact ⟨hbs_nil, hnodes_eq, by omega⟩
  · -- `pot_bound`
    subst hp_eq
    dsimp only
    have hmap_upd : updatedNodes.map (fun v => v.birthPool.card) =
        cur.nodes.map (fun v => v.birthPool.card) := by
      refine map_ofFn_eq_map cur.nodes _ _ _ (fun i => rfl)
    by_cases hTrig : ∃ j ≤ k, slotTriggers j
    · rw [dif_pos hTrig] at hbr
      obtain ⟨sufOut, hsuf, hnodes_eq, htot_eq⟩ := hbr
      obtain ⟨hjs_find, _, _⟩ := (jStarStep_final k slotTriggers).1 hTrig
      have hjs_eq : jStarStep k slotTriggers (k + 1) = Nat.find hTrig :=
        hjs_find.trans (nat_find_irrel _ _ _ _)
      let jF : Fin (k + 1) := ⟨Nat.find hTrig, Nat.lt_succ_of_le (Nat.find_spec hTrig).1⟩
      have hS_sub : S_new jF ⊆ activeLifetimes syncNext.pointSet :=
        chainInput_subset_base ltCoords' vecNodes _ jF
      have hS_adm : ∀ lt ∈ S_new jF, ltCoords' lt ∈ RatAdmissiblePointSet d B :=
        fun lt hlt => (hP'_adm lt (hS_sub hlt)).2
      have hsum_le : (sufOut.entries.map (fun e => e.birthPool.card)).sum ≤ sufOut.totalWork :=
        runSyncSuffixBuild_birthCard_le_work
          (fun acc R bs₁ out hgt hR_sub hb =>
            hctor_wk cur.history acc ltCoords' R bs₁ out (by omega)
              (fun lt hlt => hS_adm lt (hR_sub hlt)) hb)
          hsuf
      have hpot_id := c12ChainBirthPot_take_append cur.nodes updatedNodes sufOut.entries (Nat.find hTrig) hmap_upd
      unfold c12ChainBirthPot
      rw [hjs_eq, hnodes_eq]
      omega
    · rw [dif_neg hTrig] at hbr
      obtain ⟨_, hnodes_eq, htot_eq⟩ := hbr
      obtain ⟨hjs_k1, _⟩ := (jStarStep_final k slotTriggers).2 hTrig
      have hdrop_nil : cur.nodes.drop (k + 1) = [] := List.drop_eq_nil_of_le (by dsimp [k]; omega)
      unfold c12ChainBirthPot
      rw [hjs_k1, hdrop_nil, hnodes_eq, hmap_upd, htot_eq]
      simp only [List.map_nil, List.sum_nil, zero_add, Nat.sub_self, add_zero, le_rfl]

end UL.C12LVE
