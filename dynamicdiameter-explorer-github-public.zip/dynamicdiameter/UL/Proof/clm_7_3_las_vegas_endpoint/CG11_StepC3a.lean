import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b3_StepBFull
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1


theorem activeLifetimes_card_le {d n : ℕ} {P : DynamicPointSet d} (hwf : P.WellFormed n) :
    (activeLifetimes P).card ≤ n :=
  Finset.card_image_le.trans hwf.1

theorem activeLifetimes_adm_and_lt {d n L B : ℕ} {P : DynamicPointSet d}
    {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)} {qMap : ℕ → Fin d → ℚ} {ws : WordStore}
    (hwf : P.WellFormed n)
    (hlt_sync : ∀ id ∈ P.activeIds,
      ltCoords (P.lifetimeOfId id) = P.coords id ∧
      P.coords id = ratPointToEuclidean (qMap (P.handleOfId id)))
    (hcoords : ActiveCoordsStored d L B P.activeHandles qMap ws) :
    ∀ lt ∈ activeLifetimes P,
      lt < P.nextLifetime ∧
      ltCoords lt ∈ RatAdmissiblePointSet d B ∧
      handleOfLifetime P lt < 2 ^ L := by
  intro lt hlt
  rcases Finset.mem_image.mp hlt with ⟨id, hid, rfl⟩
  have hlt_next : P.lifetimeOfId id < P.nextLifetime := hwf.2.2.2.1 id hid
  have hh_mem : P.handleOfId id ∈ P.activeHandles := (hwf.2.1 id hid).1
  obtain ⟨hh_pow, hq_bnd⟩ := hcoords.hS _ hh_mem
  obtain ⟨hs1, hs2⟩ := hlt_sync id hid
  have hh_eq : handleOfLifetime P (P.lifetimeOfId id) = P.handleOfId id :=
    handleOfLifetime_of_mem hwf hid
  refine ⟨hlt_next, ?_, hh_eq ▸ hh_pow⟩
  exact ⟨qMap (P.handleOfId id), hq_bnd, hs2.symm.trans hs1.symm⟩

theorem card_image_handleOfLifetime_of_sub {d n : ℕ} {P : DynamicPointSet d}
    (hwf : P.WellFormed n) {R : Finset ℕ} (hsub : R ⊆ activeLifetimes P) :
    (R.image (handleOfLifetime P)).card = R.card :=
  Finset.card_image_of_injOn ((handleOfLifetime_injOn hwf).mono hsub)

theorem hasNodeAge_zero {ι : Type*} (R : Finset ι) : HasNodeAge R R 0 :=
  ⟨fun _ => R, rfl, rfl, fun r => r.elim0⟩

noncomputable def entryToLiveNode {d : ℕ} {NodeAux : Type}
    (e : SyncSuffixPrefixEntry d NodeAux) : SyncLiveChainNode d NodeAux :=
  { built := e.built, birthPool := e.birthPool, ageUpdateSteps := ∅ }

noncomputable def entriesToLiveNodes {d : ℕ} {NodeAux : Type}
    (entries : List (SyncSuffixPrefixEntry d NodeAux)) : List (SyncLiveChainNode d NodeAux) :=
  entries.map entryToLiveNode

theorem chainInput_append_left {d : ℕ} {ι : Type*} [DecidableEq ι] {NodeAux : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (L₁ L₂ : List (SyncLiveChainNode d NodeAux))
    (A : Finset ι) {j : ℕ} (hj : j ≤ L₁.length) :
    let L₁₂ := L₁ ++ L₂
    chainInput pts (fun i : Fin L₁₂.length => (L₁₂.get i).built.node) A
      ⟨j, Nat.lt_succ_of_le (hj.trans (by simp [L₁₂]))⟩ =
    chainInput pts (fun i : Fin L₁.length => (L₁.get i).built.node) A
      ⟨j, Nat.lt_succ_of_le hj⟩ := by
  intro L₁₂
  ext x
  rw [mem_chainInput_iff, mem_chainInput_iff]
  refine and_congr_right (fun _ => forall_congr' (fun i => forall_congr' (fun hi => ?_)))
  have hi₁ : i < L₁.length := lt_of_lt_of_le hi hj
  have hget : L₁₂.get ⟨i, lt_of_lt_of_le hi (hj.trans (by simp [L₁₂]))⟩ = L₁.get ⟨i, hi₁⟩ := by
    simp [L₁₂, List.getElem_append_left hi₁]
  simp only [List.get_eq_getElem] at hget ⊢
  rw [List.getElem_append_left hi₁]

theorem chainInput_append_singleton_last {d : ℕ} {ι : Type*} [DecidableEq ι] {NodeAux : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (L₁ : List (SyncLiveChainNode d NodeAux))
    (v : SyncLiveChainNode d NodeAux)
    (A : Finset ι) :
    let L₂ := L₁ ++ [v]
    chainInput pts (fun i : Fin L₂.length => (L₂.get i).built.node) A (Fin.last L₂.length) =
      v.built.node.residual pts
        (chainInput pts (fun i : Fin L₁.length => (L₁.get i).built.node) A (Fin.last L₁.length)) := by
  intro L₂
  ext x
  simp only [ChainNode.residual, nodeResidual, nodeCore, Finset.mem_sdiff, Finset.mem_filter]
  rw [mem_chainInput_iff, mem_chainInput_iff]
  have hlen : L₂.length = L₁.length + 1 := by simp [L₂]
  constructor
  · rintro ⟨hxA, hall⟩
    have hprev : ∀ i (hi : i < L₁.length),
        pts x ∉ coreBall (L₁.get ⟨i, hi⟩).built.node.o (L₁.get ⟨i, hi⟩).built.node.V := by
      intro i hi
      have h := hall i (by simp [Fin.last, hlen]; omega)
      simpa [L₂, List.get_eq_getElem, List.getElem_append_left hi] using h
    have hlast : pts x ∉ coreBall v.built.node.o v.built.node.V := by
      have h := hall L₁.length (by simp [Fin.last, hlen])
      simpa [L₂, List.get_eq_getElem] using h
    exact ⟨⟨hxA, hprev⟩, fun ⟨_, hc⟩ => hlast hc⟩
  · rintro ⟨⟨hxA, hprev⟩, hnot⟩
    refine ⟨hxA, fun i hi => ?_⟩
    have hi' : i < L₁.length + 1 := by simpa [Fin.last, hlen] using hi
    rcases Nat.lt_succ_iff_lt_or_eq.mp hi' with hlt | rfl
    · simpa [L₂, List.get_eq_getElem, List.getElem_append_left hlt] using hprev i hlt
    · intro hc
      have hc' : pts x ∈ coreBall v.built.node.o v.built.node.V := by
        simpa [L₂, List.get_eq_getElem] using hc
      exact hnot ⟨⟨hxA, hprev⟩, hc'⟩

theorem chain_length_le_of_contraction
    {d s₀_d n K_max : ℕ} (hs₀1 : 1 ≤ s₀_d)
    {C_nodes : ℝ}
    (h51_len : ∀ (P : Finset ℕ), P.card ≤ n →
      ∀ (k : ℕ) (nodes : Fin k → ChainNode d)
        (P₀ : Fin k → Finset ℕ)
        (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
        (age : Fin k → ℕ)
        (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)),
        (∀ i : Fin k,
          (nodes i).o = o i ∧
          (nodes i).V = liftVariance (o i) (s i) ∧
          1 ≤ (P₀ i).card ∧
          IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
            (paraboloidLiftSet (fun j : P₀ i => ltCoords j.1)) (liftedPoint (o i) (s i)) ∧
          HasNodeAge (P₀ i) (chainInput ltCoords nodes P i.castSucc) (age i) ∧
          (age i : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * ((P₀ i).card : ℝ) / 16) →
        (k : ℝ) ≤ C_nodes * (1 / (4 * (s₀_d : ℝ)))⁻¹ * Real.log ((n : ℝ) + 1))
    (hK_bound : C_nodes * (4 * (s₀_d : ℝ)) * Real.log ((n : ℝ) + 1) ≤ (K_max : ℝ))
    {P : DynamicPointSet d} (hwfP : P.WellFormed n)
    {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    (L_nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)))
    (hnodes : ∀ (i : ℕ) (hi : i < L_nodes.length),
      let v := L_nodes.get ⟨i, hi⟩
      let vecNodes : Fin L_nodes.length → ChainNode d := fun r => (L_nodes.get r).built.node
      1 ≤ v.birthPool.card ∧
      v.built.node.V = liftVariance v.built.node.o v.built.s ∧
      IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
        (paraboloidLiftSet (fun x : v.birthPool => ltCoords x.1))
        (liftedPoint v.built.node.o v.built.s) ∧
      HasNodeAge v.birthPool
        (chainInput ltCoords vecNodes (activeLifetimes P) ⟨i, Nat.lt_succ_of_lt hi⟩)
        v.ageUpdateSteps.card ∧
      (v.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (v.birthPool.card : ℝ) / 16) :
    L_nodes.length ≤ K_max := by
  have hcard : (activeLifetimes P).card ≤ n := activeLifetimes_card_le hwfP
  let k := L_nodes.length
  let vecNodes : Fin k → ChainNode d := fun i => (L_nodes.get i).built.node
  have hk_real : (k : ℝ) ≤ C_nodes * (1 / (4 * (s₀_d : ℝ)))⁻¹ * Real.log ((n : ℝ) + 1) := by
    refine h51_len (activeLifetimes P) hcard k vecNodes
      (fun i => (L_nodes.get i).birthPool)
      (fun i => (L_nodes.get i).built.node.o)
      (fun i => (L_nodes.get i).built.s)
      (fun i => (L_nodes.get i).ageUpdateSteps.card)
      ltCoords (fun ⟨i, hi⟩ => ?_)
    obtain ⟨h1, hV, hcp, hage, hle⟩ := hnodes i hi
    exact ⟨rfl, hV, h1, hcp, hage, hle⟩
  have hinv_eq : (1 / (4 * (s₀_d : ℝ)))⁻¹ = 4 * (s₀_d : ℝ) := by
    have hs0_pos : (0 : ℝ) < (s₀_d : ℝ) := by exact_mod_cast hs₀1
    field_simp
  rw [hinv_eq] at hk_real
  have hk_le_K : (k : ℝ) ≤ (K_max : ℝ) := hk_real.trans hK_bound
  exact_mod_cast hk_le_K


def cleanHeap9StepStmt : BitRAMStmt :=
  .seq (rFree 9 10) (rAdd 10 10 14)

def cleanHeap9Regs : BitRAMStmt :=
  .seq (rLit 10 0)
  (.seq (rLit 14 1)
        (.repeatN (.lit 256) cleanHeap9StepStmt))

private def freeHeap9Prefix (ws : WordStore) : ℕ → WordStore
  | 0 => ws
  | i + 1 => (freeHeap9Prefix ws i).free (.heap 9 (i : ℤ))

private theorem freeHeap9Prefix_spec (ws : WordStore) :
    ∀ i : ℕ,
      (∀ (k : ℕ), k < i → (.heap 9 (k : ℤ) : RAMCellLoc) ∉ (freeHeap9Prefix ws i).live) ∧
      (∀ loc : RAMCellLoc, (∀ (k : ℕ), k < i → loc ≠ .heap 9 (k : ℤ)) →
        (loc ∈ (freeHeap9Prefix ws i).live ↔ loc ∈ ws.live) ∧
        (freeHeap9Prefix ws i).vals loc = ws.vals loc)
  | 0 => ⟨fun _ hk => absurd hk (Nat.not_lt_zero _), fun _ _ => ⟨Iff.rfl, rfl⟩⟩
  | i + 1 => by
      obtain ⟨ih_out, ih_unch⟩ := freeHeap9Prefix_spec ws i
      dsimp only [freeHeap9Prefix]
      refine ⟨fun k hk => ?_, fun loc hne => ?_⟩
      · rcases Nat.lt_succ_iff_lt_or_eq.mp hk with hlt | rfl
        · intro hm
          exact ih_out k hlt (Finset.mem_of_mem_erase hm)
        · simp [WordStore.free]
      · have hne_i : loc ≠ .heap 9 (i : ℤ) := hne i (Nat.lt_succ_self i)
        have prev := ih_unch loc (fun k hk => hne k (Nat.lt_succ_of_lt hk))
        exact ⟨by simp [WordStore.free, hne_i, prev.1],
               by simp [WordStore.free, Function.update_of_ne hne_i, prev.2]⟩

private theorem exec_cleanHeap9Prefix_aux {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    (hW : 20 ≤ W) (N : ℕ) (hN_le : N ≤ 256)
    (hSub9 : ∀ (k : ℕ), k < N → (.heap 9 (k : ℤ) : RAMCellLoc) ∈ S_write)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit
        (.seq (rLit 10 0) (.seq (rLit 14 1) (.repeatN (.lit (N : ℤ)) cleanHeap9StepStmt)))
        ws regs wsEnd regsEnd (12 * N + 10) ((9 * N + 5) * W + 48 * N + 32) ∧
      wsEnd = freeHeap9Prefix ws N ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd := by
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hl0 : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hlN : intBitLength (N : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le N
    have h2 := natBitLength_mono hN_le
    have h3 : natBitLength 256 = 9 := by decide
    omega
  have ht9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 0) (by decide) hl0
  set g1 := Function.update regs 10 0; have bg1 := hbnd.update (r := 10) (by decide) hl0
  have s2 := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
  set g2 := Function.update g1 14 1; have bg2 := bg1.update (r := 14) (by decide) hl1
  let wsSeq : ℕ → WordStore := freeHeap9Prefix ws
  let regSeq : ℕ → ℕ → ℤ := fun i => Function.update g2 10 (i : ℤ)
  have hmodSeq : ∀ (i : ℕ), i ≤ N → ModifiedOnBounded ws₀ S_write W (wsSeq i) := by
    intro i hi; induction i with
    | zero => exact hmod
    | succ i ih => exact (ih (Nat.le_of_succ_le hi)).free (hSub9 i (Nat.lt_of_succ_le hi))
  have hbndSeq : ∀ (i : ℕ), i ≤ N → RegBounded W (regSeq i) := by
    intro i hi
    have hli : intBitLength (i : ℤ) ≤ W := by
      have h1 := intBitLength_ofNat_le i
      have h2 := natBitLength_mono (Nat.le_trans hi hN_le)
      have h3 : natBitLength 256 = 9 := by decide
      omega
    exact bg2.update (r := 10) (by decide) hli
  have hr0_eq : regSeq 0 = g2 := by
    ext r
    by_cases hr : r = 10
    · subst hr; simp [regSeq, g2, g1]
    · simp [regSeq, hr]
  have hLoop := RegExec.repeatLit (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    N hlN wsSeq regSeq (hbndSeq 0 (Nat.zero_le N))
    (body := cleanHeap9StepStmt) (U := 12) (B := 9 * W + 48)
    (fun i hi => by
      have hb_i := hbndSeq i (Nat.le_of_lt hi)
      have hr10_i : regSeq i 10 = (i : ℤ) := by simp [regSeq]
      have hr14_i : regSeq i 14 = 1 := by simp [regSeq, g2]
      have sF := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := wsSeq i)
        hb_i (table := 9) (addr := 10) (by decide) ht9
      rw [hr10_i] at sF
      have hm_next : ModifiedOnBounded ws₀ S_write W (wsSeq (i + 1)) := hmodSeq (i + 1) hi
      have hsum_bl : intBitLength (regSeq i 10 + regSeq i 14) ≤ W := by
        rw [hr10_i, hr14_i]
        have : (i : ℤ) + 1 = ((i + 1 : ℕ) : ℤ) := by push_cast; ring
        rw [this]
        have h1 := intBitLength_ofNat_le (i + 1)
        have h2 := natBitLength_mono (by omega : i + 1 ≤ 256)
        have h3 : natBitLength 256 = 9 := by decide
        omega
      have sA := RegExec.add (inp := inp) hfd_le hb_i (sp_ok hm_next).1 (sp_ok hm_next).2
        (dst := 10) (a := 10) (b := 14) (by decide) (by decide) (by decide) hsum_bl
      have hreg_eq : Function.update (regSeq i) 10 (regSeq i 10 + regSeq i 14) = regSeq (i + 1) := by
        rw [hr10_i, hr14_i]
        ext r
        by_cases hr : r = 10
        · subst hr; simp [regSeq]
        · simp [regSeq, hr]
      exact (sF.seq sA).weaken rfl hreg_eq (u₂ := 12) (b₂ := 9 * W + 48) (by omega) (by omega))
  rw [hr0_eq] at hLoop
  have sTot := (s1.seq (s2.seq hLoop)).weaken rfl rfl
    (u₂ := 12 * N + 10) (b₂ := (9 * N + 5) * W + 48 * N + 32) (by omega) (by ring_nf; omega)
  exact ⟨wsSeq N, regSeq N, sTot, rfl, hmodSeq N le_rfl, hbndSeq N le_rfl⟩

theorem exec_cleanHeap9Regs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    (hW : 20 ≤ W)
    (hSub9 : ∀ (k : ℕ), k < 256 → (.heap 9 (k : ℤ) : RAMCellLoc) ∈ S_write)
    (h9_bound : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ ws.live → ∃ k : ℕ, k < 256 ∧ z = (k : ℤ))
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit cleanHeap9Regs ws regs wsEnd regsEnd
        3200 (4000 * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      (∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∉ wsEnd.live) ∧
      (∀ loc : RAMCellLoc, (∀ z : ℤ, loc ≠ .heap 9 z) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  obtain ⟨wsEnd, regsEnd, sAux, hws_eq, hmEnd, bgEnd⟩ :=
    exec_cleanHeap9Prefix_aux (inp := inp) hfd_le hmod hcCeil hbCeil hW 256 le_rfl hSub9 hbnd
  have sTot : RegExec inp fd W C_cell C_bit cleanHeap9Regs ws regs wsEnd regsEnd 3200 (4000 * W) :=
    sAux.weaken rfl rfl (by omega) (by omega)
  have hspecN : ∀ N : ℕ, wsEnd = freeHeap9Prefix ws N →
      (∀ (k : ℕ), k < N → (.heap 9 (k : ℤ) : RAMCellLoc) ∉ wsEnd.live) ∧
      (∀ loc : RAMCellLoc, (∀ (k : ℕ), k < N → loc ≠ .heap 9 (k : ℤ)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
    intro N heq; rw [heq]; exact freeHeap9Prefix_spec ws N
  obtain ⟨hout256, hunch256⟩ := hspecN 256 hws_eq
  refine ⟨wsEnd, regsEnd, sTot, hmEnd, bgEnd, ?_, ?_⟩
  · intro z hm
    have hm_ws : (.heap 9 z : RAMCellLoc) ∈ ws.live := by
      by_cases hex : ∃ k : ℕ, k < 256 ∧ z = (k : ℤ)
      · rcases hex with ⟨k, hk, rfl⟩
        exact absurd hm (hout256 k hk)
      · exact (hunch256 (.heap 9 z) (fun k hk h => hex ⟨k, hk, by injection h⟩)).1.mp hm
    rcases h9_bound z hm_ws with ⟨k, hk, rfl⟩
    exact hout256 k hk hm
  · intro loc hne
    exact hunch256 loc (fun k _ => hne (k : ℤ))

inductive JSource : Type
  | heap0_10
  | heap9 (addr : ℕ)
  | reg (r : ℕ)

def JSourceHolds (jSrc : JSource) (j : ℕ) (ws : WordStore) (regs : ℕ → ℤ) : Prop :=
  match jSrc with
  | .heap0_10 => ws.read (.heap 0 10) = (j : ℤ)
  | .heap9 addr => addr < 256 ∧ addr ≠ 110 ∧ ws.read (.heap 9 (addr : ℤ)) = (j : ℤ)
  | .reg r => r < 16 ∧ regs r = (j : ℤ)

def syncJToHeap0Regs : JSource → BitRAMStmt
  | .heap0_10 => .skip
  | .heap9 addr =>
      .seq (rLit 10 (addr : ℤ))
      (.seq (rLoad 7 9 10)
      (.seq (rLit 10 10)
            (rStore 0 10 7)))
  | .reg r =>
      .seq (rCopy 7 r)
      (.seq (rLit 10 10)
            (rStore 0 10 7))

def storeTerminalLeafFromBufRegs (L : ℕ) (jSrc : JSource) : BitRAMStmt :=
  .seq (syncJToHeap0Regs jSrc)
  (.seq (.seq (rLit 10 111) (.seq (rFree 9 10) (.seq (rLit 10 112) (rFree 9 10))))
  (.seq (rLit 0 1)
  (.seq (insertBufToUnitTreeRegs L)
  (.seq freeBufRegs
        cleanHeap9Regs))))

theorem exec_syncJToHeap0Regs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    (hW : 24 ≤ W) {j : ℕ} (hj_bl : intBitLength (j : ℤ) ≤ W)
    (hSub0_10 : (.heap 0 10 : RAMCellLoc) ∈ S_write)
    {jSrc : JSource} {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hj_holds : JSourceHolds jSrc j ws regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (syncJToHeap0Regs jSrc) ws regs wsEnd regsEnd
        40 (30 * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      wsEnd.read (.heap 0 10) = (j : ℤ) ∧
      (∀ loc : RAMCellLoc, loc ≠ .heap 0 10 →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hl10 : intBitLength (10 : ℤ) ≤ W := by have : intBitLength (10 : ℤ) = 5 := (by decide); omega
  have ht0 : natBitLength 0 ≤ W := by have : natBitLength 0 = 1 := (by decide); omega
  have ht9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  cases jSrc with
  | heap0_10 =>
      dsimp [JSourceHolds] at hj_holds
      exact ⟨ws, regs, (RegExec.skip hbnd).weaken rfl rfl (by omega) (by omega),
        hmod, hbnd, hj_holds, fun _ _ => ⟨Iff.rfl, rfl⟩⟩
  | heap9 addr =>
      rcases hj_holds with ⟨haddr_lt, _, hr_addr⟩
      have hl_addr : intBitLength (addr : ℤ) ≤ W := by
        have h1 := intBitLength_ofNat_le addr
        have h2 := natBitLength_mono (by omega : addr ≤ 255)
        have h3 : natBitLength 255 = 8 := by decide
        omega
      have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := (addr : ℤ)) (by decide) hl_addr
      set g1 := Function.update regs 10 (addr : ℤ); have bg1 := hbnd.update (r := 10) (by decide) hl_addr
      have hg1_r : ws.read (.heap 9 (g1 10)) = (j : ℤ) := by simp [g1, hr_addr]
      have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 7) (table := 9) (addr := 10)
        (by decide) (by decide) ht9 (hg1_r ▸ hj_bl)
      set g2 := Function.update g1 7 (ws.read (.heap 9 (g1 10)))
      have bg2 : RegBounded W g2 := bg1.update (r := 7) (by decide) (hg1_r ▸ hj_bl)
      have s3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 10) (by decide) hl10
      set g3 := Function.update g2 10 10; have bg3 := bg2.update (r := 10) (by decide) hl10
      have hg3_7 : g3 7 = (j : ℤ) := by simp [g3, g2, hg1_r]
      have hg3_10 : g3 10 = 10 := by simp [g3]
      have hm_end : ModifiedOnBounded ws₀ S_write W (ws.write (.heap 0 (g3 10)) (g3 7)) := by
        rw [hg3_10, hg3_7]
        exact hmod.write hSub0_10 (j : ℤ) (by have : (RAMCellLoc.heap 0 10).bitLength = 6 := (by decide); omega) hj_bl
      have s4 := RegExec.store (inp := inp) hfd_le bg3 (table := 0) (addr := 10) (val := 7)
        (by decide) (by decide) ht0 (sp_ok hm_end).1 (sp_ok hm_end).2
      set wsEnd := ws.write (.heap 0 10) (j : ℤ)
      have hw_eq : ws.write (.heap 0 (g3 10)) (g3 7) = wsEnd := by simp [wsEnd, hg3_10, hg3_7]
      rw [hw_eq] at s4 hm_end
      have sTot := (s1.seq (s2.seq (s3.seq s4))).weaken rfl rfl (u₂ := 40) (b₂ := 30 * W) (by omega) (by omega)
      refine ⟨wsEnd, g3, sTot, hm_end, bg3, by simp [wsEnd], fun loc hne => ?_⟩
      exact ⟨by simp [wsEnd, WordStore.write, hne],
             by simp [wsEnd, WordStore.write, Function.update_of_ne hne]⟩
  | reg r =>
      rcases hj_holds with ⟨hr_lt, hreg_r⟩
      have s1 := RegExec.copy (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 7) (src := r) (by decide) hr_lt
      set g1 := Function.update regs 7 (regs r); have bg1 := hbnd.update (r := 7) (by decide) (hreg_r ▸ hj_bl)
      have s2 := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 10) (by decide) hl10
      set g2 := Function.update g1 10 10; have bg2 := bg1.update (r := 10) (by decide) hl10
      have hg2_7 : g2 7 = (j : ℤ) := by simp [g2, g1, hreg_r]
      have hg2_10 : g2 10 = 10 := by simp [g2]
      have hm_end : ModifiedOnBounded ws₀ S_write W (ws.write (.heap 0 (g2 10)) (g2 7)) := by
        rw [hg2_10, hg2_7]
        exact hmod.write hSub0_10 (j : ℤ) (by have : (RAMCellLoc.heap 0 10).bitLength = 6 := (by decide); omega) hj_bl
      have s3 := RegExec.store (inp := inp) hfd_le bg2 (table := 0) (addr := 10) (val := 7)
        (by decide) (by decide) ht0 (sp_ok hm_end).1 (sp_ok hm_end).2
      set wsEnd := ws.write (.heap 0 10) (j : ℤ)
      have hw_eq : ws.write (.heap 0 (g2 10)) (g2 7) = wsEnd := by simp [wsEnd, hg2_10, hg2_7]
      rw [hw_eq] at s3 hm_end
      have sTot := (s1.seq (s2.seq s3)).weaken rfl rfl (u₂ := 40) (b₂ := 30 * W) (by omega) (by omega)
      refine ⟨wsEnd, g2, sTot, hm_end, bg2, by simp [wsEnd], fun loc hne => ?_⟩
      exact ⟨by simp [wsEnd, WordStore.write, hne],
             by simp [wsEnd, WordStore.write, Function.update_of_ne hne]⟩


structure MidSuffixChainInv {d s₀_d : ℕ} (n L B B_cert K_max W : ℕ)
    (P' : DynamicPointSet d) (ltCoords' : ℕ → EuclideanSpace ℝ (Fin d))
    (curNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d)))
    (qMap' : ℕ → Fin d → ℚ) (retHVal : ℤ) (R : Finset ℕ) (ws : WordStore) : Prop where
  wfP' : P'.WellFormed n
  mod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws
  hk_le : curNodes.length ≤ K_max
  read_00 : ws.read (.heap 0 0) = retHVal
  hlt_sync' : ∀ id ∈ P'.activeIds,
    ltCoords' (P'.lifetimeOfId id) = P'.coords id ∧
    P'.coords id = ratPointToEuclidean (qMap' (P'.handleOfId id))
  hlt_adm' : ∀ lt < P'.nextLifetime, ltCoords' lt ∈ RatAdmissiblePointSet d B ∨ ltCoords' lt = 0
  coords_stored : ActiveCoordsStored d L B P'.activeHandles qMap' ws
  tree_active : TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) ws
  heap9_bound : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∈ ws.live → ∃ k : ℕ, k < 256 ∧ z = (k : ℤ)
  hbirth_avoid : ∀ (j : ℕ) (hj : j < curNodes.length),
    ∀ lt ∈ (curNodes.get ⟨j, hj⟩).birthPool,
      ∀ (i : ℕ) (hi : i < j),
        ltCoords' lt ∉ coreBall (curNodes.get ⟨i, Nat.lt_trans hi hj⟩).built.node.o
          (curNodes.get ⟨i, Nat.lt_trans hi hj⟩).built.node.V
  levels : ∀ (j : ℕ) (hj : j < curNodes.length),
    let vecNodes : Fin curNodes.length → ChainNode d := fun i => (curNodes.get i).built.node
    let S_lt := chainInput ltCoords' vecNodes (activeLifetimes P') ⟨j, Nat.lt_succ_of_lt hj⟩
    LevelStoredInv n L B B_cert K_max P' ltCoords' qMap' S_lt (curNodes.get ⟨j, hj⟩) j ws
  empty_levels : ∀ j : ℕ, curNodes.length ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j ws
  stage567_clean : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ ws.live
  hR_eq : R = chainInput ltCoords' (fun i : Fin curNodes.length => (curNodes.get i).built.node)
                (activeLifetimes P') (Fin.last curNodes.length)

def StdBufLoopExtra {d : ℕ} (jSrc : JSource) (L : ℕ) (P' : DynamicPointSet d)
    (j : ℕ) (R : Finset ℕ) (ws : WordStore) (regs : ℕ → ℤ) : Prop :=
  JSourceHolds jSrc j ws regs ∧
  TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) ws ∧
  ws.read (.heap 9 110) = (R.card : ℤ) ∧
  (∃ hSeq : ℕ → ℕ,
    (∀ k < R.card, hSeq k < 2 ^ L ∧ ws.read (.heap 8 (k : ℤ)) = (hSeq k : ℤ)) ∧
    (Finset.range R.card).image hSeq = R.image (handleOfLifetime P')) ∧
  (∀ z : ℤ, (∀ k < R.card, z ≠ (k : ℤ)) → (.heap 8 z : RAMCellLoc) ∉ ws.live)

theorem exec_storeTerminalLeafFromBufRegs
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    (hW : natBitLength K_max + L + 28 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P' : DynamicPointSet d} {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {curNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap' : ℕ → Fin d → ℚ} {retHVal : ℤ} {R : Finset ℕ}
    {ws : WordStore} {regs : ℕ → ℤ} {jSrc : JSource}
    (hmid : MidSuffixChainInv n L B B_cert K_max W P' ltCoords' curNodes qMap' retHVal R ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hbnd : RegBounded W regs)
    (hbuf : StdBufLoopExtra jSrc L P' curNodes.length R ws regs)
    (hR_leaf : R.card ≤ 2 * s₀_d - 1) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (storeTerminalLeafFromBufRegs L jSrc) ws regs wsEnd regsEnd
        ((R.card + 1) * (420 * L + 340) + 3400) ((R.card + 1) * (66 * L + 96) * W * W + 4200 * W) ∧
      ChainStoredInv n L B B_cert K_max W P' ltCoords' curNodes qMap' wsEnd ∧
      RegBounded W regsEnd ∧
      wsEnd.read (.heap 0 0) = retHVal := by
  have ⟨hL2, _, h2n_pow, _⟩ := clog_two_mul_bounds hn
  rw [← hL] at hL2 h2n_pow
  have hL1 : 1 ≤ L := by omega
  have hW28 : 28 ≤ W := by omega
  have hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    have : WordStore.empty.cellCount = 0 := by simp [WordStore.cellCount, WordStore.empty]
    linarith only [hcCeil, this]
  have hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    have : WordStore.empty.bitSize = 0 := by simp [WordStore.bitSize, WordStore.empty]
    linarith only [hbCeil, this]
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil0], by linarith only [bs, hbCeil0]⟩
  rcases hbuf with ⟨hj_holds, htree_leaf_empty, hr110, ⟨hSeq, hhSeq_spec, hSeq_img⟩, htab8_clean⟩
  have hR_sub : R ⊆ activeLifetimes P' := hmid.hR_eq ▸ chainInput_subset_base _ _ _ _
  have hM_le_n : R.card ≤ n := (Finset.card_le_card hR_sub).trans (activeLifetimes_card_le hmid.wfP')
  have hM_le_pow : R.card ≤ 2 ^ L := by omega
  have hj_bl : intBitLength (curNodes.length : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le curNodes.length
    have h2 := natBitLength_mono hmid.hk_le
    omega
  obtain ⟨ws1, g1, s1, hm1, bg1, hr1_k, hunch1⟩ :=
    exec_syncJToHeap0Regs hfd_le hmid.mod hcCeil0 hbCeil0 (by omega) hj_bl
      (mem_posDimWriteLocs_tab0 (by decide)) hbnd hj_holds
  have hl111 : intBitLength (111 : ℤ) ≤ W := by have : intBitLength (111 : ℤ) = 8 := (by decide); omega
  have hl112 : intBitLength (112 : ℤ) ≤ W := by have : intBitLength (112 : ℤ) = 8 := (by decide); omega
  have ht9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have s2a := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 10) (c := 111) (by decide) hl111
  set g2a := Function.update g1 10 111; have bg2a : RegBounded W g2a := bg1.update (r := 10) (by decide) hl111
  have s2b := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws1) bg2a (table := 9) (addr := 10) (by decide) ht9
  have hg2a_10 : g2a 10 = 111 := by simp [g2a]
  rw [hg2a_10] at s2b
  set ws2a := ws1.free (.heap 9 111); have hm2a : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws2a := hm1.free (mem_posDimWriteLocs_tab9 (i := 111) (by decide))
  have s2c := RegExec.lit (inp := inp) hfd_le bg2a (sp_ok hm2a).1 (sp_ok hm2a).2 (dst := 10) (c := 112) (by decide) hl112
  set g2c := Function.update g2a 10 112; have bg2c : RegBounded W g2c := bg2a.update (r := 10) (by decide) hl112
  have s2d := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws2a) bg2c (table := 9) (addr := 10) (by decide) ht9
  have hg2c_10 : g2c 10 = 112 := by simp [g2c]
  rw [hg2c_10] at s2d
  set ws2 := ws2a.free (.heap 9 112); have hm2 : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws2 := hm2a.free (mem_posDimWriteLocs_tab9 (i := 112) (by decide))
  have s2 := s2a.seq (s2b.seq (s2c.seq s2d))
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have s3 := RegExec.lit (inp := inp) hfd_le bg2c (sp_ok hm2).1 (sp_ok hm2).2 (dst := 0) (c := 1) (by decide) hl1
  set g3 := Function.update g2c 0 1; have bg3 := bg2c.update (r := 0) (by decide) hl1
  have hunch2_1 : ∀ loc : RAMCellLoc, loc ≠ .heap 0 10 → loc ≠ .heap 9 111 → loc ≠ .heap 9 112 →
      (loc ∈ ws2.live ↔ loc ∈ ws.live) ∧ ws2.vals loc = ws.vals loc := by
    intro loc h0 h111 h112
    have u1 := hunch1 loc h0
    exact ⟨by simp [ws2, ws2a, WordStore.free, h111, h112, u1.1],
           by simp [ws2, ws2a, WordStore.free, Function.update_of_ne h112, Function.update_of_ne h111, u1.2]⟩
  have hn111_2 : (.heap 9 111 : RAMCellLoc) ∉ ws2.live := by
    simp [ws2, ws2a, WordStore.free]
  have hn112_2 : (.heap 9 112 : RAMCellLoc) ∉ ws2.live := by
    simp [ws2, WordStore.free]
  have hr2_110 : ws2.read (.heap 9 110) = (R.card : ℤ) := by
    rw [wordStore_read_eq_vals hm2.wf, (hunch2_1 _ (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)).2,
        ← wordStore_read_eq_vals hmid.mod.wf]
    exact hr110
  have hbuf2 : ∀ k < R.card, ws2.read (.heap 8 (k : ℤ)) = (hSeq k : ℤ) := by
    intro k hk
    rw [wordStore_read_eq_vals hm2.wf, (hunch2_1 _ (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)).2,
        ← wordStore_read_eq_vals hmid.mod.wf]
    exact (hhSeq_spec k hk).2
  have htree1_2 : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) ws2 :=
    htree_leaf_empty.unchanged (fun u hu f hf =>
      hunch2_1 _ (fun h => by cases h) (fun h => by cases h) (fun h => by cases h))
  obtain ⟨ws4, g4, s4, hm4, bg4, htree1_4, hunch4⟩ :=
    exec_insertBufToUnitTreeRegs hfd_le hm2 hcCeil0 hbCeil0 hL1 hM_le_pow
      (by have : natBitLength 1 = 1 := (by decide); omega)
      (fun u hu f hf => mem_posDimWriteLocs_tree (by omega) hu hf)
      (mem_posDimWriteLocs_tab9 (by decide))
      (mem_posDimWriteLocs_tab9 (by decide))
      hn111_2 hn112_2
      (fun k hk => (hhSeq_spec k hk).1) hr2_110 hbuf2 htree1_2 bg3 (by simp [g3])
  rw [hSeq_img] at htree1_4
  have hr4_110 : ws4.read (.heap 9 110) = (R.card : ℤ) := by
    rw [wordStore_read_eq_vals hm4.wf, (hunch4 _ (not_in_treeSlice_of_table_ne (by decide) _)).2,
        ← wordStore_read_eq_vals hm2.wf]
    exact hr2_110
  obtain ⟨ws5, g5, s5, hm5, bg5, h8_out5, _, hunch5⟩ :=
    exec_freeBufRegs hfd_le hm4 hcCeil0 hbCeil0 hM_le_pow (by omega)
      (fun k hk => mem_posDimWriteLocs_tab8 (by omega))
      (mem_posDimWriteLocs_tab9 (by decide))
      hr4_110 bg4
  obtain ⟨wsEnd, gEnd, s6, hmEnd, bgEnd, h9_clean, hunch6⟩ :=
    exec_cleanHeap9Regs hfd_le hm5 hcCeil0 hbCeil0 (by omega) (fun _ hk => mem_posDimWriteLocs_tab9 hk)
      (fun z hm => by
        by_cases hz : z = 110 ∨ z = 111 ∨ z = 112
        · rcases hz with rfl | rfl | rfl
          · exact ⟨110, by decide, rfl⟩
          · exact ⟨111, by decide, rfl⟩
          · exact ⟨112, by decide, rfl⟩
        · push_neg at hz
          have u5 := (hunch5 (.heap 9 z) (by simp [hz.1]) (fun _ _ h => by cases h)).1.mp hm
          have u4 := (hunch4 (.heap 9 z) (not_in_treeSlice_of_table_ne (by decide) _)).1.mp u5
          have u2 := (hunch2_1 (.heap 9 z) (fun h => by cases h) (by simp [hz.2.1]) (by simp [hz.2.2])).1.mp u4
          exact hmid.heap9_bound z u2) bg5
  have hWW1 : 1 ≤ W * W := by nlinarith only [hW28]
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq s6))))).weaken rfl rfl
    (u₂ := (R.card + 1) * (420 * L + 340) + 3400)
    (b₂ := (R.card + 1) * (66 * L + 96) * W * W + 4200 * W)
    (by nlinarith only [hL1])
    (by
      have h1 : (12 * R.card + 24) * W ≤ (R.card + 1) * 16 * W * W := by
        calc (12 * R.card + 24) * W ≤ (R.card + 1) * (24 * W) := by
              have : 12 * R.card + 24 ≤ (R.card + 1) * 24 := by omega
              calc (12 * R.card + 24) * W ≤ ((R.card + 1) * 24) * W := Nat.mul_le_mul_right W this
                _ = (R.card + 1) * (24 * W) := by ring
          _ ≤ (R.card + 1) * (16 * (W * W)) := Nat.mul_le_mul_left _ (by nlinarith only [hW28])
          _ = (R.card + 1) * 16 * W * W := by ring
      have h2 : (R.card + 1) * (64 * L + 80) * W * W + (R.card + 1) * 16 * W * W ≤
          (R.card + 1) * (66 * L + 96) * W * W := by
        have hL64 : (R.card + 1) * (64 * L + 96) ≤ (R.card + 1) * (66 * L + 96) :=
          Nat.mul_le_mul_left _ (by omega)
        calc (R.card + 1) * (64 * L + 80) * W * W + (R.card + 1) * 16 * W * W
            = ((R.card + 1) * (64 * L + 96)) * (W * W) := by ring
          _ ≤ ((R.card + 1) * (66 * L + 96)) * (W * W) := Nat.mul_le_mul_right _ hL64
          _ = (R.card + 1) * (66 * L + 96) * W * W := by ring
      linarith only [hW28, h1, h2])
  have hunch_core : ∀ loc : RAMCellLoc,
      loc ≠ .heap 0 10 →
      loc ∉ treeSliceLocs L 1 →
      (∀ z : ℤ, loc ≠ .heap 8 z) →
      (∀ z : ℤ, loc ≠ .heap 9 z) →
      (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc := by
    intro loc h0_10 hnt1 hn8 hn9
    have u6 := hunch6 loc hn9
    have u5 := hunch5 loc (hn9 110) (fun k _ => hn8 (k : ℤ))
    have u4 := hunch4 loc hnt1
    have u2 := hunch2_1 loc h0_10 (hn9 111) (hn9 112)
    exact ⟨u6.1.trans (u5.1.trans (u4.1.trans u2.1)),
           u6.2.trans (u5.2.trans (u4.2.trans u2.2))⟩
  have hrEnd_k : wsEnd.read (.heap 0 10) = (curNodes.length : ℤ) := by
    rw [wordStore_read_eq_vals hmEnd.wf,
        (hunch6 _ (by intro z h; cases h)).2,
        (hunch5 _ (by decide) (fun _ _ h => by cases h)).2,
        (hunch4 _ (not_in_treeSlice_of_table_ne (by decide) _)).2,
        (show ws2.vals (.heap 0 10) = ws1.vals (.heap 0 10) by simp [ws2, ws2a, WordStore.free]),
        ← wordStore_read_eq_vals hm1.wf]
    exact hr1_k
  have hrEnd_00 : wsEnd.read (.heap 0 0) = retHVal := by
    rw [wordStore_read_eq_vals hmEnd.wf,
        (hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_table_ne (by decide) _)
          (fun _ h => by cases h) (fun _ h => by cases h)).2,
        ← wordStore_read_eq_vals hmid.mod.wf]
    exact hmid.read_00
  refine ⟨wsEnd, gEnd, sTot, ?_, bgEnd, hrEnd_00⟩
  refine
    { wfP := hmid.wfP'
      mod := hmEnd
      hk_le := hmid.hk_le
      read_k := hrEnd_k
      hlt_sync := hmid.hlt_sync'
      hlt_adm := hmid.hlt_adm'
      coords_stored := hmid.coords_stored.unchanged (fun h' _ c _ f _ => by
        rw [wordStore_read_eq_vals hmEnd.wf,
            (hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_table_ne (by decide) _)
              (fun _ h => by cases h) (fun _ h => by cases h)).2,
            ← wordStore_read_eq_vals hmid.mod.wf])
      tree_active := hmid.tree_active.unchanged (fun u hu f hf =>
        hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_tid_ne hu hf (by decide))
          (fun _ h => by cases h) (fun _ h => by cases h))
      hbirth_avoid := hmid.hbirth_avoid
      levels := fun j hj => (hmid.levels j hj).unchanged hmid.mod.wf hmEnd.wf
        (fun off _ => hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_table_ne (by decide) _)
          (fun _ h => by cases h) (fun _ h => by cases h))
        (fun h' _ => hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_table_ne (by decide) _)
          (fun _ h => by cases h) (fun _ h => by cases h))
        (fun u hu f hf => hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_tid_ne hu hf (by omega))
          (fun _ h => by cases h) (fun _ h => by cases h))
        (fun u hu f hf => hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_tid_ne hu hf (by omega))
          (fun _ h => by cases h) (fun _ h => by cases h))
      empty_levels := fun j hlo hhi => (hmid.empty_levels j hlo hhi).unchanged
        (fun off _ => (hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_table_ne (by decide) _)
          (fun _ h => by cases h) (fun _ h => by cases h)).1.mp)
        (fun h' _ => (hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_table_ne (by decide) _)
          (fun _ h => by cases h) (fun _ h => by cases h)).1.mp)
        (fun u hu f hf => (hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_tid_ne hu hf (by omega))
          (fun _ h => by cases h) (fun _ h => by cases h)).1.mp)
        (fun u hu f hf => (hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_tid_ne hu hf (by omega))
          (fun _ h => by cases h) (fun _ h => by cases h)).1.mp)
      tree_leaf := by
        dsimp only
        rw [← hmid.hR_eq]
        refine ⟨by omega, htree1_4.unchanged (fun u _ f _ => ?_)⟩
        have u6 := hunch6 (.heap 2 (treeCellAddr L 1 u f)) (fun _ h => by cases h)
        have u5 := hunch5 (.heap 2 (treeCellAddr L 1 u f)) (fun h => by cases h) (fun _ _ h => by cases h)
        exact ⟨u6.1.trans u5.1, u6.2.trans u5.2⟩
      stage_clean := fun t ht z hm_live => by
        rcases ht with rfl | rfl | rfl | rfl | rfl
        · exact hmid.stage567_clean 5 (Or.inl rfl) z
            ((hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_table_ne (by decide) _)
              (fun _ h => by cases h) (fun _ h => by cases h)).1.mp hm_live)
        · exact hmid.stage567_clean 6 (Or.inr (Or.inl rfl)) z
            ((hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_table_ne (by decide) _)
              (fun _ h => by cases h) (fun _ h => by cases h)).1.mp hm_live)
        · exact hmid.stage567_clean 7 (Or.inr (Or.inr rfl)) z
            ((hunch_core _ (fun h => by cases h) (not_in_treeSlice_of_table_ne (by decide) _)
              (fun _ h => by cases h) (fun _ h => by cases h)).1.mp hm_live)
        · by_cases hlt : ∃ k < R.card, z = (k : ℤ)
          · rcases hlt with ⟨k, hk, rfl⟩
            exact h8_out5 k hk ((hunch6 _ (fun _ h => by cases h)).1.mp hm_live)
          · have hm_ws : (.heap 8 z : RAMCellLoc) ∈ ws.live := by
              have u6 := hunch6 (.heap 8 z) (fun _ h => by cases h)
              have u5 := hunch5 (.heap 8 z) (fun h => by cases h) (fun k hk h => hlt ⟨k, hk, by injection h⟩)
              have u4 := hunch4 (.heap 8 z) (not_in_treeSlice_of_table_ne (by decide) _)
              have u2 := hunch2_1 (.heap 8 z) (fun h => by cases h) (fun h => by cases h) (fun h => by cases h)
              exact (u6.1.trans (u5.1.trans (u4.1.trans u2.1))).mp hm_live
            exact htab8_clean z (fun k hk hz => hlt ⟨k, hk, hz⟩) hm_ws
        · exact h9_clean z hm_live }


theorem exec_posDimStepC_noTrigger
    (h_del_wit : S_claim_A_2_deletion_witness)
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d) (hW : 20 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P P' : DynamicPointSet d} {ltCoords ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap qMap' : ℕ → Fin d → ℚ} {ws wsB : WordStore} {regsB : ℕ → ℤ}
    {retHVal : ℤ} {slotTriggers : ℕ → Prop}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws)
    (hwfP' : P'.WellFormed n)
    (hlt_sync' : ∀ id ∈ P'.activeIds,
      ltCoords' (P'.lifetimeOfId id) = P'.coords id ∧
      P'.coords id = ratPointToEuclidean (qMap' (P'.handleOfId id)))
    (hlt_adm' : ∀ lt < P'.nextLifetime, ltCoords' lt ∈ RatAdmissiblePointSet d B ∨ ltCoords' lt = 0)
    (hlt_preserve : ∀ lt < P.nextLifetime, ltCoords' lt = ltCoords lt)
    (hupd_len : updatedNodes.length = nodes.length)
    (hupd_node : ∀ (j : ℕ) (hj : j < nodes.length),
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).built = (nodes.get ⟨j, hj⟩).built ∧
      (updatedNodes.get ⟨j, hupd_len ▸ hj⟩).birthPool = (nodes.get ⟨j, hj⟩).birthPool)
    (hno_trig_age : ∀ (j : ℕ) (hj : j < nodes.length),
      ¬ slotTriggers j →
        let vUpd := updatedNodes.get ⟨j, hupd_len ▸ hj⟩
        (vUpd.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (vUpd.birthPool.card : ℝ) / 16)
    (hno_trig_leaf : ¬ slotTriggers nodes.length →
      (chainInput ltCoords' (fun i : Fin nodes.length => (nodes.get i).built.node)
        (activeLifetimes P') (Fin.last nodes.length)).card ≤ 2 * (2 * s₀_d - 1))
    (hnTrig : ∀ j ≤ nodes.length, ¬ slotTriggers j)
    (hmB : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsB)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hbndB : RegBounded W regsB)
    (hrB_k : wsB.read (.heap 0 10) = (nodes.length : ℤ))
    (hrB_00 : wsB.read (.heap 0 0) = retHVal)
    (hcoordsB : ActiveCoordsStored d L B P'.activeHandles qMap' wsB)
    (htree0B : TreeStoredAt L 0 P'.activeHandles (fun _ => 0) (fun _ => 1) wsB)
    (htree1B : TreeStoredAt L 1
      ((chainInput ltCoords' (fun i : Fin nodes.length => (nodes.get i).built.node)
        (activeLifetimes P') (Fin.last nodes.length)).image (handleOfLifetime P'))
      (fun _ => 0) (fun _ => 1) wsB)
    (hpreB : ∀ (j : ℕ) (hj : j < nodes.length),
      PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap'
        (chainInput ltCoords' (fun i : Fin nodes.length => (nodes.get i).built.node)
          (activeLifetimes P') ⟨j, Nat.lt_succ_of_lt hj⟩)
        (updatedNodes.get ⟨j, hupd_len ▸ hj⟩) j wsB)
    (hemptyB : ∀ j : ℕ, nodes.length ≤ j → j ≤ K_max + 1 → EmptyLevelSlot d L j wsB)
    (hclean58B : ∀ t : ℕ, (t = 5 ∨ t = 6 ∨ t = 7 ∨ t = 8) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ wsB.live)
    (hclean9B : ∀ z : ℤ, z ≠ 102 → z ≠ 103 → z ≠ 104 → z ≠ 105 → z ≠ 106 → (.heap 9 z : RAMCellLoc) ∉ wsB.live) :
    ∃ wsC regsC,
      RegExec inp fd W C_cell C_bit cleanHeap9Regs wsB regsB wsC regsC 3200 (4000 * W) ∧
      ChainStoredInv n L B B_cert K_max W P' ltCoords' updatedNodes qMap' wsC ∧
      RegBounded W regsC ∧
      wsC.read (.heap 0 0) = retHVal := by
  have hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    have : WordStore.empty.cellCount = 0 := by simp [WordStore.cellCount, WordStore.empty]
    linarith only [hcCeil, this]
  have hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    have : WordStore.empty.bitSize = 0 := by simp [WordStore.bitSize, WordStore.empty]
    linarith only [hbCeil, this]
  obtain ⟨wsC, regsC, sClean, hmC, bgC, h9_clean, hunchC⟩ :=
    exec_cleanHeap9Regs hfd_le hmB hcCeil0 hbCeil0 hW (fun _ hk => mem_posDimWriteLocs_tab9 hk)
      (fun z hm => by
        by_cases h2 : z = 102; · subst h2; exact ⟨102, by decide, rfl⟩
        by_cases h3 : z = 103; · subst h3; exact ⟨103, by decide, rfl⟩
        by_cases h4 : z = 104; · subst h4; exact ⟨104, by decide, rfl⟩
        by_cases h5 : z = 105; · subst h5; exact ⟨105, by decide, rfl⟩
        by_cases h6 : z = 106; · subst h6; exact ⟨106, by decide, rfl⟩
        exact absurd hm (hclean9B z h2 h3 h4 h5 h6)) hbndB
  have hci_eq : ∀ (j : ℕ) (hj : j ≤ nodes.length),
      chainInput ltCoords' (fun i : Fin updatedNodes.length => (updatedNodes.get i).built.node)
        (activeLifetimes P') ⟨j, by omega⟩ =
      chainInput ltCoords' (fun i : Fin nodes.length => (nodes.get i).built.node)
        (activeLifetimes P') ⟨j, Nat.lt_succ_of_le hj⟩ := by
    intro j hj
    ext x
    rw [mem_chainInput_iff, mem_chainInput_iff]
    refine and_congr_right (fun _ => forall_congr' (fun i => forall_congr' (fun hi => ?_)))
    dsimp only at hi ⊢
    have hi_lt : i < nodes.length := lt_of_lt_of_le hi hj
    have heq_n : (updatedNodes.get ⟨i, _⟩).built = (nodes.get ⟨i, hi_lt⟩).built :=
      (congrArg (fun q => (updatedNodes.get q).built) (Fin.ext rfl)).trans (hupd_node i hi_lt).1
    rw [heq_n]
  refine ⟨wsC, regsC, sClean, ?_, bgC, ?_⟩
  · refine
      { wfP := hwfP'
        mod := hmC
        hk_le := by have := hinv.hk_le; omega
        read_k := by
          rw [hupd_len, wordStore_read_eq_vals hmC.wf, (hunchC _ (fun _ h => by cases h)).2,
              ← wordStore_read_eq_vals hmB.wf]
          exact hrB_k
        hlt_sync := hlt_sync'
        hlt_adm := hlt_adm'
        coords_stored := hcoordsB.unchanged (fun _ _ _ _ _ _ => by
          rw [wordStore_read_eq_vals hmC.wf, (hunchC _ (fun _ h => by cases h)).2,
              ← wordStore_read_eq_vals hmB.wf])
        tree_active := htree0B.unchanged (fun _ _ _ _ => hunchC _ (fun _ h => by cases h))
        hbirth_avoid := fun j hj lt hlt i hi => by
          have hj0 : j < nodes.length := by omega
          have hi0 : i < nodes.length := Nat.lt_trans hi hj0
          have heq_bp : (updatedNodes.get ⟨j, hj⟩).birthPool = (nodes.get ⟨j, hj0⟩).birthPool :=
            (congrArg (fun q => (updatedNodes.get q).birthPool) (Fin.ext rfl)).trans (hupd_node j hj0).2
          have heq_bi : (updatedNodes.get ⟨i, Nat.lt_trans hi hj⟩).built = (nodes.get ⟨i, hi0⟩).built :=
            (congrArg (fun q => (updatedNodes.get q).built) (Fin.ext rfl)).trans (hupd_node i hi0).1
          rw [heq_bp] at hlt
          rw [heq_bi]
          have hlt_old : lt < P.nextLifetime := ((hinv.levels j hj0).hbirth_adm lt hlt).1
          rw [hlt_preserve lt hlt_old]
          exact hinv.hbirth_avoid j hj0 lt hlt i hi
        levels := fun j hj => by
          have hj0 : j < nodes.length := by omega
          have hpre_j := (hpreB j hj0).unchanged hmB.wf hmC.wf
            (fun _ _ => hunchC _ (fun _ h => by cases h))
            (fun _ _ => hunchC _ (fun _ h => by cases h))
            (fun _ _ _ _ => hunchC _ (fun _ h => by cases h))
            (fun _ _ _ _ => hunchC _ (fun _ h => by cases h))
          have hage_j := hno_trig_age j hj0 (hnTrig j (Nat.le_of_lt hj0))
          have hci_j := hci_eq j (Nat.le_of_lt hj0)
          have hlvl0 := hpre_j.toLevelStoredInv h_del_wit hd1 hs₀1
            (chainInput_subset_base _ _ _ _) hage_j
          have hget_eq : updatedNodes.get ⟨j, hj⟩ = _ := congrArg updatedNodes.get (Fin.ext rfl)
          dsimp only
          rw [hci_j, hget_eq]
          exact hlvl0
        empty_levels := fun j hlo hhi => (hemptyB j (by omega) hhi).unchanged
          (fun _ _ => (hunchC _ (fun _ h => by cases h)).1.mp)
          (fun _ _ => (hunchC _ (fun _ h => by cases h)).1.mp)
          (fun _ _ _ _ => (hunchC _ (fun _ h => by cases h)).1.mp)
          (fun _ _ _ _ => (hunchC _ (fun _ h => by cases h)).1.mp)
        tree_leaf := by
          dsimp only
          have hlast_eq : (Fin.last updatedNodes.length) = ⟨nodes.length, by omega⟩ := by
            ext; exact hupd_len
          rw [hlast_eq, hci_eq nodes.length le_rfl]
          exact ⟨hno_trig_leaf (hnTrig nodes.length le_rfl),
                 htree1B.unchanged (fun _ _ _ _ => hunchC _ (fun _ h => by cases h))⟩
        stage_clean := fun t ht z hm_live => by
          rcases ht with rfl | rfl | rfl | rfl | rfl
          · exact hclean58B 5 (Or.inl rfl) z ((hunchC _ (fun _ h => by cases h)).1.mp hm_live)
          · exact hclean58B 6 (Or.inr (Or.inl rfl)) z ((hunchC _ (fun _ h => by cases h)).1.mp hm_live)
          · exact hclean58B 7 (Or.inr (Or.inr (Or.inl rfl))) z ((hunchC _ (fun _ h => by cases h)).1.mp hm_live)
          · exact hclean58B 8 (Or.inr (Or.inr (Or.inr rfl))) z ((hunchC _ (fun _ h => by cases h)).1.mp hm_live)
          · exact h9_clean z hm_live }
  · rw [wordStore_read_eq_vals hmC.wf, (hunchC _ (fun _ h => by cases h)).2,
        ← wordStore_read_eq_vals hmB.wf]
    exact hrB_00



end UL.C12LVE
