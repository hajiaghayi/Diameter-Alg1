import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1b3_StepBFull
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1c1_StepDMath
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Loop-Invariant `RegExec` Combinators, Heap Micro-DSL & List-Fold Helpers -/

private theorem buildLoopSeq {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (N : ℕ) {ws₀ : WordStore} {regs₀ : ℕ → ℤ}
    (Inv : ℕ → WordStore → (ℕ → ℤ) → Prop) (hInv0 : Inv 0 ws₀ regs₀)
    {body : BitRAMStmt} {U B : ℕ}
    (hstep : ∀ i < N, ∀ w r, Inv i w r →
      ∃ w' r', RegExec inp fd W C_cell C_bit body w r w' r' U B ∧ Inv (i + 1) w' r') :
    ∃ (wsSeq : ℕ → WordStore) (regSeq : ℕ → ℕ → ℤ),
      wsSeq 0 = ws₀ ∧ regSeq 0 = regs₀ ∧ Inv N (wsSeq N) (regSeq N) ∧
      (∀ i < N, RegExec inp fd W C_cell C_bit body (wsSeq i) (regSeq i) (wsSeq (i + 1)) (regSeq (i + 1)) U B) := by
  suffices ∀ m ≤ N, ∃ (wsSeq : ℕ → WordStore) (regSeq : ℕ → ℕ → ℤ),
      wsSeq 0 = ws₀ ∧ regSeq 0 = regs₀ ∧ Inv m (wsSeq m) (regSeq m) ∧
      (∀ i < m, RegExec inp fd W C_cell C_bit body (wsSeq i) (regSeq i) (wsSeq (i + 1)) (regSeq (i + 1)) U B) from
    this N le_rfl
  intro m hm
  induction m with
  | zero =>
      exact ⟨fun _ => ws₀, fun _ => regs₀, rfl, rfl, hInv0, fun i hi => absurd hi (Nat.not_lt_zero _)⟩
  | succ k ih =>
      obtain ⟨wS, rS, hw0, hr0, hInvk, hsteps⟩ := ih (Nat.le_of_succ_le hm)
      obtain ⟨wNext, rNext, hstep_k, hInvNext⟩ := hstep k (Nat.lt_of_succ_le hm) (wS k) (rS k) hInvk
      refine ⟨fun i => if i ≤ k then wS i else wNext,
              fun i => if i ≤ k then rS i else rNext,
              by simp [hw0], by simp [hr0],
              by simp only [show ¬ (k + 1 ≤ k) by omega, ↓reduceIte]; exact hInvNext, ?_⟩
      intro i hi
      rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
      · simp only [Nat.le_of_lt hlt, Nat.succ_le_of_lt hlt, ↓reduceIte]; exact hsteps i hlt
      · simp only [le_rfl, show ¬ (i + 1 ≤ i) by omega, ↓reduceIte]; exact hstep_k

theorem RegExec.repeatReg_inv {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    {cntReg : ℕ} (hcnt : cntReg < 16) (N : ℕ)
    {ws₀ : WordStore} {regs₀ : ℕ → ℤ}
    (hcnt_eq : regs₀ cntReg = (N : ℤ))
    (Inv : ℕ → WordStore → (ℕ → ℤ) → Prop) (hInv0 : Inv 0 ws₀ regs₀)
    (hbnd0 : RegBounded W regs₀)
    {body : BitRAMStmt} {U B : ℕ}
    (hstep : ∀ i < N, ∀ w r, Inv i w r →
      ∃ w' r', RegExec inp fd W C_cell C_bit body w r w' r' U B ∧ Inv (i + 1) w' r') :
    ∃ wsN regsN,
      RegExec inp fd W C_cell C_bit (.repeatN (.readLocal cntReg (.lit 0)) body)
        ws₀ regs₀ wsN regsN (N * U + 4) (N * B + W + 12) ∧
      Inv N wsN regsN := by
  obtain ⟨wsSeq, regSeq, hw0, hr0, hInvN, hstepsN⟩ := buildLoopSeq N Inv hInv0 hstep
  have hexec := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    hcnt N wsSeq regSeq (by rw [hr0]; exact hcnt_eq) (by rw [hr0]; exact hbnd0) hstepsN
  rw [hw0, hr0] at hexec
  exact ⟨wsSeq N, regSeq N, hexec, hInvN⟩

theorem RegExec.repeatLit_inv {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (N : ℕ) (hN_bl : intBitLength (N : ℤ) ≤ W)
    {ws₀ : WordStore} {regs₀ : ℕ → ℤ}
    (Inv : ℕ → WordStore → (ℕ → ℤ) → Prop) (hInv0 : Inv 0 ws₀ regs₀)
    (hbnd0 : RegBounded W regs₀)
    {body : BitRAMStmt} {U B : ℕ}
    (hstep : ∀ i < N, ∀ w r, Inv i w r →
      ∃ w' r', RegExec inp fd W C_cell C_bit body w r w' r' U B ∧ Inv (i + 1) w' r') :
    ∃ wsN regsN,
      RegExec inp fd W C_cell C_bit (.repeatN (.lit (N : ℤ)) body)
        ws₀ regs₀ wsN regsN (N * U + 2) (N * B + W) ∧
      Inv N wsN regsN := by
  obtain ⟨wsSeq, regSeq, hw0, hr0, hInvN, hstepsN⟩ := buildLoopSeq N Inv hInv0 hstep
  have hexec := RegExec.repeatLit (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    N hN_bl wsSeq regSeq (by rw [hr0]; exact hbnd0) hstepsN
  rw [hw0, hr0] at hexec
  exact ⟨wsSeq N, regSeq N, hexec, hInvN⟩

theorem exec_litLoadHeap {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    {dst table : ℕ} {c v : ℤ}
    (hdst : dst < 16) (ht_bl : natBitLength table ≤ W) (hc_bl : intBitLength c ≤ W)
    (hread : ws.read (.heap table c) = v) (hv_bl : intBitLength v ≤ W) :
    RegExec inp fd W C_cell C_bit (.seq (rLit 10 c) (rLoad dst table 10))
      ws regs ws (Function.update (Function.update regs 10 c) dst v) 10 (8 * W + 40) ∧
    RegBounded W (Function.update (Function.update regs 10 c) dst v) := by
  obtain ⟨cs, bs⟩ := hmod.space_le
  have spC : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell := by linarith only [cs, hcCeil]
  have spB : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit := by linarith only [bs, hbCeil]
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd spC spB (dst := 10) (c := c) (by decide) hc_bl
  set g1 := Function.update regs 10 c
  have bg1 := hbnd.update (r := 10) (by decide) hc_bl
  have hr1 : ws.read (.heap table (g1 10)) = v := by simp only [g1, Function.update_self]; exact hread
  have s2 := RegExec.load (inp := inp) hfd_le bg1 spC spB (dst := dst) (table := table) (addr := 10)
    hdst (by decide) ht_bl (by rw [hr1]; exact hv_bl)
  rw [hr1] at s2
  exact ⟨(s1.seq s2).weaken rfl rfl (by omega) (by omega), bg1.update hdst hv_bl⟩

theorem exec_litStoreHeap {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    {table valReg : ℕ} {c : ℤ}
    (hval : valReg < 16) (hne10 : valReg ≠ 10)
    (ht_bl : natBitLength table ≤ W) (hc_bl : intBitLength c ≤ W)
    (hsub : (.heap table c : RAMCellLoc) ∈ S_write)
    (hloc_bl : (RAMCellLoc.heap table c).bitLength ≤ W) :
    RegExec inp fd W C_cell C_bit (.seq (rLit 10 c) (rStore table 10 valReg))
      ws regs (ws.write (.heap table c) (regs valReg)) (Function.update regs 10 c) 10 (7 * W + 40) ∧
    ModifiedOnBounded ws₀ S_write W (ws.write (.heap table c) (regs valReg)) ∧
    RegBounded W (Function.update regs 10 c) := by
  obtain ⟨cs, bs⟩ := hmod.space_le
  have spC : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell := by linarith only [cs, hcCeil]
  have spB : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit := by linarith only [bs, hbCeil]
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd spC spB (dst := 10) (c := c) (by decide) hc_bl
  set g1 := Function.update regs 10 c
  have bg1 := hbnd.update (r := 10) (by decide) hc_bl
  have hm1 := hmod.write hsub (regs valReg) hloc_bl (hbnd.2.1 valReg hval)
  obtain ⟨cs1, bs1⟩ := hm1.space_le
  have hw : ws.write (.heap table (g1 10)) (g1 valReg) = ws.write (.heap table c) (regs valReg) := by
    simp [g1, Function.update_of_ne hne10]
  have s2 := RegExec.store (inp := inp) (C_cell := C_cell) (C_bit := C_bit) hfd_le bg1 (table := table) (addr := 10) (val := valReg)
    (by decide) hval ht_bl (by rw [hw]; linarith only [cs1, hcCeil]) (by rw [hw]; linarith only [bs1, hbCeil])
  rw [hw] at s2
  exact ⟨(s1.seq s2).weaken rfl rfl (by omega) (by omega), hm1, bg1⟩

theorem exec_litFreeHeap {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    {table : ℕ} {c : ℤ}
    (ht_bl : natBitLength table ≤ W) (hc_bl : intBitLength c ≤ W)
    (hsub : (.heap table c : RAMCellLoc) ∈ S_write) :
    RegExec inp fd W C_cell C_bit (.seq (rLit 10 c) (rFree table 10))
      ws regs (ws.free (.heap table c)) (Function.update regs 10 c) 8 (5 * W + 32) ∧
    ModifiedOnBounded ws₀ S_write W (ws.free (.heap table c)) ∧
    RegBounded W (Function.update regs 10 c) := by
  obtain ⟨cs, bs⟩ := hmod.space_le
  have spC : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell := by linarith only [cs, hcCeil]
  have spB : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit := by linarith only [bs, hbCeil]
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd spC spB (dst := 10) (c := c) (by decide) hc_bl
  set g1 := Function.update regs 10 c
  have bg1 := hbnd.update (r := 10) (by decide) hc_bl
  have hm1 := hmod.free hsub
  have hw : ws.free (.heap table (g1 10)) = ws.free (.heap table c) := by simp [g1]
  have s2 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit)
    (wsHeap := ws) bg1 (table := table) (addr := 10) (by decide) ht_bl
  rw [hw] at s2
  exact ⟨(s1.seq s2).weaken rfl rfl (by omega) (by omega), hm1, bg1⟩

theorem foldBestPairs_append {d : ℕ} (P : DynamicPointSet d) (init : ℕ × ℕ) (l₁ l₂ : List (ℕ × ℕ)) :
    foldBestPairs P init (l₁ ++ l₂) = foldBestPairs P (foldBestPairs P init l₁) l₂ :=
  List.foldl_append

theorem foldBestPairs_singleton {d : ℕ} (P : DynamicPointSet d) (init c : ℕ × ℕ) :
    foldBestPairs P init [c] = stepBestPair P init c :=
  rfl

theorem finRange_take_succ {n i : ℕ} (hi : i < n) :
    (List.finRange n).take (i + 1) = (List.finRange n).take i ++ [⟨i, hi⟩] := by
  have hlen : i < (List.finRange n).length := by simpa using hi
  rw [List.take_succ_eq_append_getElem hlen, List.getElem_finRange]
  simp

theorem finRange_take_self (n : ℕ) :
    (List.finRange n).take n = List.finRange n := by simp

theorem handleDistSq_eq_qMap {d n : ℕ} {P : DynamicPointSet d}
    {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)} {qMap : ℕ → Fin d → ℚ}
    (hwf : P.WellFormed n)
    (hsync : ∀ id ∈ P.activeIds,
      ltCoords (P.lifetimeOfId id) = P.coords id ∧
      P.coords id = ratPointToEuclidean (qMap (P.handleOfId id)))
    {h₁ h₂ : ℕ} (hh₁ : h₁ ∈ P.activeHandles) (hh₂ : h₂ ∈ P.activeHandles) :
    ‖ratPointToEuclidean (qMap h₁) - ratPointToEuclidean (qMap h₂)‖ ^ 2 =
      handleDistSq P (h₁, h₂) := by
  have hid₁ := hwf.2.2.1 h₁ hh₁
  have hid₂ := hwf.2.2.1 h₂ hh₂
  have hc₁ := (hsync (P.idOfHandle h₁) hid₁.1).2
  have hc₂ := (hsync (P.idOfHandle h₂) hid₂.1).2
  rw [hid₁.2] at hc₁; rw [hid₂.2] at hc₂
  unfold handleDistSq euclideanDistSq
  rw [hc₁, hc₂]

/-! ### 2. `BestPairStored` Header Invariant & `readCachedAnswer` Lemmas -/

def isAnsHeaderLoc (loc : RAMCellLoc) : Prop :=
  loc = .heap 0 1 ∨ loc = .heap 0 2 ∨ loc = .heap 0 3 ∨ loc = .heap 0 4 ∨ loc = .heap 0 5

def isBestPairLoc (loc : RAMCellLoc) : Prop :=
  loc = .heap 0 2 ∨ loc = .heap 0 3 ∨ loc = .heap 0 4 ∨ loc = .heap 0 5

def BestPairStored {d : ℕ} (B : ℕ) (P : DynamicPointSet d)
    (cur : ℕ × ℕ) (ws : WordStore) : Prop :=
  cur.1 ∈ P.activeHandles ∧
  cur.2 ∈ P.activeHandles ∧
  cur.1 ≠ cur.2 ∧
  ws.read (.heap 0 1) = 1 ∧
  ws.read (.heap 0 2) = (cur.1 : ℤ) ∧
  ws.read (.heap 0 3) = (cur.2 : ℤ) ∧
  ∃ (cNum cDen : ℤ),
    ws.read (.heap 0 4) = cNum ∧
    ws.read (.heap 0 5) = cDen ∧
    0 ≤ cNum ∧ 1 ≤ cDen ∧
    intBitLength cNum ≤ d * (4 * B + 11) + 2 ∧
    intBitLength cDen ≤ d * (4 * B + 10) + 2 ∧
    ((cNum : ℝ) / (cDen : ℝ)) = handleDistSq P cur

theorem BestPairStored.unchanged {d B : ℕ} {P : DynamicPointSet d} {cur : ℕ × ℕ}
    {ws₁ ws₂ : WordStore} (h : BestPairStored B P cur ws₁)
    (h1 : ws₂.read (.heap 0 1) = ws₁.read (.heap 0 1))
    (h2 : ws₂.read (.heap 0 2) = ws₁.read (.heap 0 2))
    (h3 : ws₂.read (.heap 0 3) = ws₁.read (.heap 0 3))
    (h4 : ws₂.read (.heap 0 4) = ws₁.read (.heap 0 4))
    (h5 : ws₂.read (.heap 0 5) = ws₁.read (.heap 0 5)) :
    BestPairStored B P cur ws₂ := by
  rcases h with ⟨hc1, hc2, hne, r1, r2, r3, cNum, cDen, r4, r5, hN0, hD1, hbN, hbD, hval⟩
  exact ⟨hc1, hc2, hne, h1.trans r1, h2.trans r2, h3.trans r3,
    cNum, cDen, h4.trans r4, h5.trans r5, hN0, hD1, hbN, hbD, hval⟩

theorem BestPairStored.of_unchanged_vals {d B : ℕ} {P : DynamicPointSet d} {cur : ℕ × ℕ}
    {ws₁ ws₂ : WordStore} (hwf₁ : WellFormedWS ws₁) (hwf₂ : WellFormedWS ws₂)
    (h : BestPairStored B P cur ws₁)
    (hvals : ∀ i : ℕ, 1 ≤ i → i ≤ 5 → ws₂.vals (.heap 0 (i : ℤ)) = ws₁.vals (.heap 0 (i : ℤ))) :
    BestPairStored B P cur ws₂ := by
  apply h.unchanged <;> rw [wordStore_read_eq_vals hwf₂, wordStore_read_eq_vals hwf₁]
  · exact hvals 1 (by decide) (by decide)
  · exact hvals 2 (by decide) (by decide)
  · exact hvals 3 (by decide) (by decide)
  · exact hvals 4 (by decide) (by decide)
  · exact hvals 5 (by decide) (by decide)

theorem readCachedAnswer_of_bestPairStored {d s₀_d L B : ℕ}
    {P : DynamicPointSet d}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {ws : WordStore}
    (h2 : 2 ≤ P.activeHandles.card)
    (hbest : BestPairStored B P
      (foldBestPairs P (twoMinHandles P.activeHandles h2) (ramScanCandidates L P nodes)) ws) :
    BitRAMDynamicProgram.readCachedAnswer ws =
      ((ramCheckedAnswer L P nodes).diameterHandles, (ramCheckedAnswer L P nodes).cachedDistSq) := by
  set best := foldBestPairs P (twoMinHandles P.activeHandles h2) (ramScanCandidates L P nodes)
  rcases hbest with ⟨_, _, _, hr1, hr2, hr3, cNum, cDen, hr4, hr5, _, hD1, _, _, hval⟩
  have hram : ramCheckedAnswer L P nodes =
      { diameterHandles := some best, cachedDistSq := handleDistSq P best } := by
    simp [ramCheckedAnswer, h2, best]
  rw [hram]
  unfold BitRAMDynamicProgram.readCachedAnswer
  rw [hr1, hr2, hr3, hr4, hr5]
  have h1_nn : (0 : ℤ) ≤ (best.1 : ℤ) := Nat.cast_nonneg best.1
  have h2_nn : (0 : ℤ) ≤ (best.2 : ℤ) := Nat.cast_nonneg best.2
  have hD_pos : (0 : ℤ) < cDen := lt_of_lt_of_le zero_lt_one hD1
  simp only [true_and, h1_nn, h2_nn, ↓reduceIte, Int.toNat_natCast, Prod.mk.eta, hD_pos]
  congr 1; rw [← hval]; push_cast; rfl

/-! ### 3. Header Clear & Update Helpers (`clearAnsHeaderRegs`, `updateBestPairRegs`) -/

theorem exec_clearAnsHeaderRegs_stepD {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    (hW20 : 20 ≤ W)
    (hSub0 : ∀ i : ℕ, 1 ≤ i → i ≤ 5 → (.heap 0 (i : ℤ) : RAMCellLoc) ∈ S_write)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit clearAnsHeaderRegs ws regs wsEnd regsEnd 60 (60 * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      BitRAMDynamicProgram.readCachedAnswer wsEnd = (none, 0) ∧
      (∀ loc : RAMCellLoc, ¬ isAnsHeaderLoc loc →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hn0 : natBitLength 0 ≤ W := Nat.le_trans (by decide) hW20
  obtain ⟨s1, hm1, bg1⟩ := exec_litFreeHeap hfd_le hmod hcCeil hbCeil hbnd hn0
    (Nat.le_trans (by decide) hW20) (hSub0 1 (by decide) (by decide))
  obtain ⟨s2, hm2, bg2⟩ := exec_litFreeHeap hfd_le hm1 hcCeil hbCeil bg1 hn0
    (Nat.le_trans (by decide) hW20) (hSub0 2 (by decide) (by decide))
  obtain ⟨s3, hm3, bg3⟩ := exec_litFreeHeap hfd_le hm2 hcCeil hbCeil bg2 hn0
    (Nat.le_trans (by decide) hW20) (hSub0 3 (by decide) (by decide))
  obtain ⟨s4, hm4, bg4⟩ := exec_litFreeHeap hfd_le hm3 hcCeil hbCeil bg3 hn0
    (Nat.le_trans (by decide) hW20) (hSub0 4 (by decide) (by decide))
  obtain ⟨s5, hm5, bg5⟩ := exec_litFreeHeap hfd_le hm4 hcCeil hbCeil bg4 hn0
    (Nat.le_trans (by decide) hW20) (hSub0 5 (by decide) (by decide))
  set w5 := ((((ws.free (.heap 0 1)).free (.heap 0 2)).free (.heap 0 3)).free (.heap 0 4)).free (.heap 0 5)
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq s5)))).weaken rfl rfl
    (u₂ := 60) (b₂ := 60 * W) (by omega) (by omega)
  refine ⟨w5, _, sTot, hm5, bg5, ?_, ?_⟩
  · have hr1 : w5.read (.heap 0 1) = 0 := by simp [w5, WordStore.read, WordStore.free]
    have hr5 : w5.read (.heap 0 5) = 0 := by simp [w5, WordStore.read, WordStore.free]
    unfold BitRAMDynamicProgram.readCachedAnswer; rw [hr1, hr5]; simp
  · intro loc hnot
    have hne1 : loc ≠ .heap 0 1 := fun h => hnot (Or.inl h)
    have hne2 : loc ≠ .heap 0 2 := fun h => hnot (Or.inr (Or.inl h))
    have hne3 : loc ≠ .heap 0 3 := fun h => hnot (Or.inr (Or.inr (Or.inl h)))
    have hne4 : loc ≠ .heap 0 4 := fun h => hnot (Or.inr (Or.inr (Or.inr (Or.inl h))))
    have hne5 : loc ≠ .heap 0 5 := fun h => hnot (Or.inr (Or.inr (Or.inr (Or.inr h))))
    exact ⟨by simp [w5, WordStore.free, hne1, hne2, hne3, hne4, hne5],
           by simp [w5, WordStore.free, Function.update_of_ne hne1, Function.update_of_ne hne2,
                Function.update_of_ne hne3, Function.update_of_ne hne4, Function.update_of_ne hne5]⟩

def updateBestPairRegs : BitRAMStmt :=
  .seq (.seq (rLit 10 2) (rStore 0 10 1))
  (.seq (.seq (rLit 10 3) (rStore 0 10 2))
  (.seq (.seq (rLit 10 4) (rStore 0 10 3))
        (.seq (rLit 10 5) (rStore 0 10 4))))

theorem exec_updateBestPairRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    (hW20 : 20 ≤ W)
    (hSub0 : ∀ i : ℕ, 1 ≤ i → i ≤ 5 → (.heap 0 (i : ℤ) : RAMCellLoc) ∈ S_write)
    (hr01 : ws.read (.heap 0 1) = 1)
    {B : ℕ} {P : DynamicPointSet d} {h₁ h₂ : ℕ}
    (hh₁ : h₁ ∈ P.activeHandles) (hh₂ : h₂ ∈ P.activeHandles) (hne : h₁ ≠ h₂)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr1 : regs 1 = (h₁ : ℤ)) (hr2 : regs 2 = (h₂ : ℤ))
    (h03 : 0 ≤ regs 3) (h14 : 1 ≤ regs 4)
    (hbl3 : intBitLength (regs 3) ≤ d * (4 * B + 11) + 2)
    (hbl4 : intBitLength (regs 4) ≤ d * (4 * B + 10) + 2)
    (hdist : ((regs 3 : ℝ) / (regs 4 : ℝ)) = handleDistSq P (h₁, h₂)) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit updateBestPairRegs ws regs wsEnd regsEnd 48 (36 * W + 160) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      BestPairStored B P (h₁, h₂) wsEnd ∧
      (∀ loc : RAMCellLoc, ¬ isBestPairLoc loc →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hn0 : natBitLength 0 ≤ W := Nat.le_trans (by decide) hW20
  obtain ⟨s2, hm2, bg2⟩ := exec_litStoreHeap hfd_le hmod hcCeil hbCeil hbnd (valReg := 1) (c := 2)
    (by decide) (by decide) hn0 (Nat.le_trans (by decide) hW20)
    (hSub0 2 (by decide) (by decide)) (Nat.le_trans (by decide) hW20)
  set g2 := Function.update regs 10 2
  obtain ⟨s3, hm3, bg3⟩ := exec_litStoreHeap hfd_le hm2 hcCeil hbCeil bg2 (valReg := 2) (c := 3)
    (by decide) (by decide) hn0 (Nat.le_trans (by decide) hW20)
    (hSub0 3 (by decide) (by decide)) (Nat.le_trans (by decide) hW20)
  set g3 := Function.update g2 10 3
  obtain ⟨s4, hm4, bg4⟩ := exec_litStoreHeap hfd_le hm3 hcCeil hbCeil bg3 (valReg := 3) (c := 4)
    (by decide) (by decide) hn0 (Nat.le_trans (by decide) hW20)
    (hSub0 4 (by decide) (by decide)) (Nat.le_trans (by decide) hW20)
  set g4 := Function.update g3 10 4
  obtain ⟨s5, hm5, bg5⟩ := exec_litStoreHeap hfd_le hm4 hcCeil hbCeil bg4 (valReg := 4) (c := 5)
    (by decide) (by decide) hn0 (Nat.le_trans (by decide) hW20)
    (hSub0 5 (by decide) (by decide)) (Nat.le_trans (by decide) hW20)
  set w2 := ws.write (.heap 0 2) (regs 1)
  set w3 := w2.write (.heap 0 3) (g2 2)
  set w4 := w3.write (.heap 0 4) (g3 3)
  set w5 := w4.write (.heap 0 5) (g4 4)
  have sTot := (s2.seq (s3.seq (s4.seq s5))).weaken rfl rfl (u₂ := 48) (b₂ := 36 * W + 160) (by omega) (by omega)
  refine ⟨w5, _, sTot, hm5, bg5, ?_, ?_⟩
  · refine ⟨hh₁, hh₂, hne, ?_, ?_, ?_, regs 3, regs 4, ?_, ?_, h03, h14, hbl3, hbl4, hdist⟩
    · rw [wordStore_read_write_ne w4 (by decide), wordStore_read_write_ne w3 (by decide), wordStore_read_write_ne w2 (by decide), wordStore_read_write_ne ws (by decide)]; exact hr01
    · simp [w5, w4, w3, w2, WordStore.read, WordStore.write, hr1]
    · simp [w5, w4, w3, g2, WordStore.read, WordStore.write, hr2]
    · simp [w5, w4, g3, g2, WordStore.read, WordStore.write]
    · simp [w5, g4, g3, g2, WordStore.read, WordStore.write]
  · intro loc hnot
    have hne2 : loc ≠ .heap 0 2 := fun h => hnot (Or.inl h)
    have hne3 : loc ≠ .heap 0 3 := fun h => hnot (Or.inr (Or.inl h))
    have hne4 : loc ≠ .heap 0 4 := fun h => hnot (Or.inr (Or.inr (Or.inl h)))
    have hne5 : loc ≠ .heap 0 5 := fun h => hnot (Or.inr (Or.inr (Or.inr h)))
    exact ⟨by simp [w5, w4, w3, w2, WordStore.write, hne2, hne3, hne4, hne5],
           by simp [w5, w4, w3, w2, WordStore.write, Function.update_of_ne hne2,
                Function.update_of_ne hne3, Function.update_of_ne hne4, Function.update_of_ne hne5]⟩

/-! ### 4. `initBestPairRegs` (Fallback `twoMinHandles`) & `exec_initBestPairRegs` -/

def writeBestHeaderRegs : BitRAMStmt :=
  .seq (rLit 13 1) (.seq (.seq (rLit 10 1) (rStore 0 10 13)) updateBestPairRegs)

def initBestPairRegs (d L : ℕ) : BitRAMStmt :=
  .seq (rLit 0 0)
  (.seq (treeMinElemRegs L)
  (.seq (.seq (rLit 10 100) (rStore 9 10 1))
  (.seq (rLit 0 0)
  (.seq (rLit 2 0)
  (.seq (rLit 3 0)
  (.seq (rLit 4 0)
  (.seq (treeSetLeafRegs L)
  (.seq (rLit 0 0)
  (.seq (treeMinElemRegs L)
  (.seq (.seq (rLit 10 101) (rStore 9 10 1))
  (.seq (.seq (rLit 10 100) (rLoad 1 9 10))
  (.seq (rLit 0 0)
  (.seq (rLit 2 1)
  (.seq (rLit 3 0)
  (.seq (rLit 4 1)
  (.seq (treeSetLeafRegs L)
  (.seq (.seq (rLit 10 100) (rLoad 1 9 10))
  (.seq (.seq (rLit 10 100) (rFree 9 10))
  (.seq (.seq (rLit 10 101) (rLoad 2 9 10))
  (.seq (.seq (rLit 10 101) (rFree 9 10))
  (.seq (sqDistHandlesRegs d)
        writeBestHeaderRegs)))))))))))))))))))))

theorem exec_initBestPairRegs {d n L B W : ℕ} (hd1 : 1 ≤ d) (hL1 : 1 ≤ L) (hB1 : 1 ≤ B)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    (hW : d * (4 * B + 12) + natBitLength d + L + 28 ≤ W)
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)} {qMap : ℕ → Fin d → ℚ}
    (hwfP : P.WellFormed n)
    (hsync : ∀ id ∈ P.activeIds,
      ltCoords (P.lifetimeOfId id) = P.coords id ∧
      P.coords id = ratPointToEuclidean (qMap (P.handleOfId id)))
    (hcoords : ActiveCoordsStored d L B P.activeHandles qMap ws)
    (htree0 : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) ws)
    (h2 : 2 ≤ P.activeHandles.card)
    (hSub0 : ∀ i : ℕ, 1 ≤ i → i ≤ 5 → (.heap 0 (i : ℤ) : RAMCellLoc) ∈ S_write)
    (hSubTree0 : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L 0 u f) : RAMCellLoc) ∈ S_write)
    (hSub100 : (.heap 9 100 : RAMCellLoc) ∈ S_write)
    (hSub101 : (.heap 9 101 : RAMCellLoc) ∈ S_write)
    (hn100 : (.heap 9 100 : RAMCellLoc) ∉ ws.live)
    (hn101 : (.heap 9 101 : RAMCellLoc) ∉ ws.live)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (initBestPairRegs d L) ws regs wsEnd regsEnd
        (900 * L + 250 * d + 700) ((150 * L + 60 * d + 280) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) wsEnd ∧
      BestPairStored B P (twoMinHandles P.activeHandles h2) wsEnd ∧
      (∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L 0 → ¬ isAnsHeaderLoc loc →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW24 : 24 ≤ W := by clear * - hW; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hl0 : intBitLength (0 : ℤ) ≤ W := Nat.le_trans (by decide) hW24
  have hl1 : intBitLength (1 : ℤ) ≤ W := Nat.le_trans (by decide) hW24
  have hl100 : intBitLength (100 : ℤ) ≤ W := Nat.le_trans (by decide) hW24
  have hl101 : intBitLength (101 : ℤ) ≤ W := Nat.le_trans (by decide) hW24
  have hn0 : natBitLength 0 ≤ W := Nat.le_trans (by decide) hW24
  have hn9 : natBitLength 9 ≤ W := Nat.le_trans (by decide) hW24
  have hW_tree : 2 * 2 + natBitLength 0 + L + 16 ≤ W := by
    have hdec0 : natBitLength 0 = 1 := by decide
    clear * - hW hdec0; omega
  set S := P.activeHandles
  have hS_bnds : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 :=
    fun h hm => ⟨htree0.hS h hm, by dsimp only; decide, by dsimp only; decide⟩
  have hne1 : S.Nonempty := Finset.card_pos.mp (by clear * - h2; omega)
  set h₁ := S.min' hne1
  have hh₁_in : h₁ ∈ S := Finset.min'_mem S hne1
  have hh₁_lt : h₁ < 2 ^ L := htree0.hS h₁ hh₁_in
  have hh₁_bl : intBitLength (h₁ : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hh₁_lt).trans (by clear * - hW; omega)
  have hne2 : (S.erase h₁).Nonempty := Finset.card_pos.mp (by
    rw [Finset.card_erase_of_mem hh₁_in]; clear * - h2; omega)
  set h₂ := (S.erase h₁).min' hne2
  have hh₂_er : h₂ ∈ S.erase h₁ := Finset.min'_mem _ hne2
  rcases Finset.mem_erase.mp hh₂_er with ⟨hne_21, hh₂_in⟩
  have hh₂_lt : h₂ < 2 ^ L := htree0.hS h₂ hh₂_in
  have hh₂_bl : intBitLength (h₂ : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hh₂_lt).trans (by clear * - hW; omega)
  have htm_eq : twoMinHandles P.activeHandles h2 = (h₁, h₂) := rfl
  have hPathSub : treePathLocs L 0 h₁ ⊆ S_write :=
    (treePath_sub_slice hL1 hh₁_lt).trans (fun loc hm => by
      simp only [treeSliceLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hm
      rcases hm with ⟨⟨u, f⟩, ⟨hu, hf⟩, rfl⟩
      exact hSubTree0 u hu f hf)
  have h9_notin_path : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∉ treePathLocs L 0 h₁ := fun z hm =>
    not_in_treeSlice_of_table_ne (by decide) z (treePath_sub_slice hL1 hh₁_lt hm)
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (c := 0) (by decide) hl0
  set g1 := Function.update regs 0 0; have bg1 := hbnd.update (r := 0) (by decide) hl0
  obtain ⟨g2, s2, bg2, _, g2_1, _⟩ :=
    exec_treeMinElemRegs (inp := inp) (fd := fd) hfd_le (sp_ok hmod).1 (sp_ok hmod).2 hL1 (B_r := 2) (by decide)
      hW_tree htree0 hS_bnds hne1 bg1 (by simp [g1])
  obtain ⟨s3, hm1, bg3⟩ := exec_litStoreHeap hfd_le hmod hcCeil hbCeil bg2 (table := 9) (valReg := 1) (c := 100)
    (by decide) (by decide) hn9 hl100 hSub100 (Nat.le_trans (by decide) hW24)
  set ws1 := ws.write (.heap 9 100) (g2 1)
  have hws1_eq : ws1 = ws.write (.heap 9 100) (h₁ : ℤ) := by simp [ws1, g2_1, h₁]
  have htree1 : TreeStoredAt L 0 S (fun _ => 0) (fun _ => 1) ws1 :=
    htree0.unchanged (fun u _ f _ => by simp [ws1, WordStore.write])
  set g3 := Function.update g2 10 100
  have s4 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 0) (c := 0) (by decide) hl0
  set g4 := Function.update g3 0 0; have bg4 := bg3.update (r := 0) (by decide) hl0
  have s5 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 2) (c := 0) (by decide) hl0
  set g5 := Function.update g4 2 0; have bg5 := bg4.update (r := 2) (by decide) hl0
  have s6 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 3) (c := 0) (by decide) hl0
  set g6 := Function.update g5 3 0; have bg6 := bg5.update (r := 3) (by decide) hl0
  have s7 := RegExec.lit (inp := inp) hfd_le bg6 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 4) (c := 0) (by decide) hl0
  set g7 := Function.update g6 4 0; have bg7 := bg6.update (r := 4) (by decide) hl0
  obtain ⟨ws2, g8, s8, hm2, bg8, htree2, hunch2⟩ :=
    exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hm1 hcCeil hbCeil hL1 hh₁_lt (B_r := 2) (by decide) hW_tree
      hPathSub htree1 (S' := S.erase h₁) (rNum' := fun _ => 0) (rDen' := fun _ => 1)
      (fun h hm => hS_bnds h (Finset.mem_of_mem_erase hm))
      (fun h hne => by simp [Finset.mem_erase, hne]) (fun _ _ => rfl) (fun _ _ => rfl)
      false (by simp) bg7 (by simp [g7, g6, g5, g4]) (by simp [g7, g6, g5, g4, g3, g2_1, h₁])
      (by simp [g7, g6, g5]) (fun h => by cases h) (fun h => by cases h)
  have s9 := RegExec.lit (inp := inp) hfd_le bg8 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 0) (c := 0) (by decide) hl0
  set g9 := Function.update g8 0 0; have bg9 := bg8.update (r := 0) (by decide) hl0
  obtain ⟨g10, s10, bg10, _, g10_1, _⟩ :=
    exec_treeMinElemRegs (inp := inp) (fd := fd) hfd_le (sp_ok hm2).1 (sp_ok hm2).2 hL1 (B_r := 2) (by decide)
      hW_tree htree2 (fun h hm => hS_bnds h (Finset.mem_of_mem_erase hm)) hne2 bg9 (by simp [g9])
  obtain ⟨s11, hm3, bg11⟩ := exec_litStoreHeap hfd_le hm2 hcCeil hbCeil bg10 (table := 9) (valReg := 1) (c := 101)
    (by decide) (by decide) hn9 hl101 hSub101 (Nat.le_trans (by decide) hW24)
  set ws3 := ws2.write (.heap 9 101) (g10 1)
  have hws3_eq : ws3 = ws2.write (.heap 9 101) (h₂ : ℤ) := by simp [ws3, g10_1, h₂]
  have htree3 : TreeStoredAt L 0 (S.erase h₁) (fun _ => 0) (fun _ => 1) ws3 :=
    htree2.unchanged (fun u _ f _ => by simp [ws3, WordStore.write])
  have hr3_100 : ws3.read (.heap 9 100) = (h₁ : ℤ) := by
    rw [hws3_eq, wordStore_read_write_ne ws2 (by decide) (h₂ : ℤ),
        wordStore_read_eq_vals hm2.wf, (hunch2 _ (h9_notin_path 100)).2, hws1_eq]
    simp [WordStore.write]
  obtain ⟨s12, bg12⟩ := exec_litLoadHeap hfd_le hm3 hcCeil hbCeil bg11 (dst := 1) (table := 9) (c := 100)
    (by decide) hn9 hl100 hr3_100 hh₁_bl
  set g12 := Function.update (Function.update (Function.update g10 10 101) 10 100) 1 (h₁ : ℤ)
  have s13 := RegExec.lit (inp := inp) hfd_le bg12 (sp_ok hm3).1 (sp_ok hm3).2 (dst := 0) (c := 0) (by decide) hl0
  set g13 := Function.update g12 0 0; have bg13 := bg12.update (r := 0) (by decide) hl0
  have s14 := RegExec.lit (inp := inp) hfd_le bg13 (sp_ok hm3).1 (sp_ok hm3).2 (dst := 2) (c := 1) (by decide) hl1
  set g14 := Function.update g13 2 1; have bg14 := bg13.update (r := 2) (by decide) hl1
  have s15 := RegExec.lit (inp := inp) hfd_le bg14 (sp_ok hm3).1 (sp_ok hm3).2 (dst := 3) (c := 0) (by decide) hl0
  set g15 := Function.update g14 3 0; have bg15 := bg14.update (r := 3) (by decide) hl0
  have s16 := RegExec.lit (inp := inp) hfd_le bg15 (sp_ok hm3).1 (sp_ok hm3).2 (dst := 4) (c := 1) (by decide) hl1
  set g16 := Function.update g15 4 1; have bg16 := bg15.update (r := 4) (by decide) hl1
  obtain ⟨ws4, g17, s17, hm4, bg17, htree4, hunch4⟩ :=
    exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hm3 hcCeil hbCeil hL1 hh₁_lt (B_r := 2) (by decide) hW_tree
      hPathSub htree3 (S' := S) (rNum' := fun _ => 0) (rDen' := fun _ => 1)
      hS_bnds (fun h hne => by simp [Finset.mem_erase, hne]) (fun _ _ => rfl) (fun _ _ => rfl)
      true (by simp [hh₁_in]) bg16
      (by simp [g16, g15, g14, g13]) (by simp [g16, g15, g14, g13, g12]) (by simp [g16, g15, g14])
      (fun _ => by simp [g16, g15]) (fun _ => by simp [g16])
  have hr4_100 : ws4.read (.heap 9 100) = (h₁ : ℤ) := by
    rw [wordStore_read_eq_vals hm4.wf, (hunch4 _ (h9_notin_path 100)).2, ← wordStore_read_eq_vals hm3.wf]
    exact hr3_100
  have hr4_101 : ws4.read (.heap 9 101) = (h₂ : ℤ) := by
    rw [wordStore_read_eq_vals hm4.wf, (hunch4 _ (h9_notin_path 101)).2, hws3_eq]
    simp [WordStore.write]
  obtain ⟨s18, bg18⟩ := exec_litLoadHeap hfd_le hm4 hcCeil hbCeil bg17 (dst := 1) (table := 9) (c := 100)
    (by decide) hn9 hl100 hr4_100 hh₁_bl
  obtain ⟨s19, hm5, bg19⟩ := exec_litFreeHeap hfd_le hm4 hcCeil hbCeil bg18 hn9 hl100 hSub100
  set ws5 := ws4.free (.heap 9 100)
  have hr5_101 : ws5.read (.heap 9 101) = (h₂ : ℤ) := by
    rw [wordStore_read_free_ne ws4 (by decide)]; exact hr4_101
  obtain ⟨s20, bg20⟩ := exec_litLoadHeap hfd_le hm5 hcCeil hbCeil bg19 (dst := 2) (table := 9) (c := 101)
    (by decide) hn9 hl101 hr5_101 hh₂_bl
  obtain ⟨s21, hm6, bg21⟩ := exec_litFreeHeap hfd_le hm5 hcCeil hbCeil bg20 hn9 hl101 hSub101
  set ws6 := ws5.free (.heap 9 101)
  have hunch6 : ∀ loc : RAMCellLoc, loc ∉ treeSliceLocs L 0 →
      (loc ∈ ws6.live ↔ loc ∈ ws.live) ∧ ws6.vals loc = ws.vals loc := by
    intro loc hns
    have hnpath : loc ∉ treePathLocs L 0 h₁ := fun hm => hns (treePath_sub_slice hL1 hh₁_lt hm)
    by_cases h100 : loc = .heap 9 100
    · subst h100
      exact ⟨by simp [ws6, ws5, WordStore.free, hn100], by simp [ws6, ws5, WordStore.free, hmod.wf _ hn100]⟩
    · by_cases h101 : loc = .heap 9 101
      · subst h101
        exact ⟨by simp [ws6, WordStore.free, hn101], by simp [ws6, WordStore.free, hmod.wf _ hn101]⟩
      · have u4 := hunch4 loc hnpath; have u2 := hunch2 loc hnpath
        exact ⟨by simp [ws6, ws5, WordStore.free, h100, h101, u4.1, ws3, WordStore.write, u2.1, ws1],
               by simp [ws6, ws5, WordStore.free, Function.update_of_ne h100, Function.update_of_ne h101,
                    u4.2, ws3, WordStore.write, u2.2, ws1]⟩
  have hcoords6 : ActiveCoordsStored d L B S qMap ws6 :=
    hcoords.unchanged (fun h' _ c _ f _ => by
      rw [wordStore_read_eq_vals hm6.wf, wordStore_read_eq_vals hmod.wf]
      exact (hunch6 _ (not_in_treeSlice_of_table_ne (by decide) _)).2)
  have htree6 : TreeStoredAt L 0 S (fun _ => 0) (fun _ => 1) ws6 :=
    htree4.unchanged (fun u _ f _ => by simp [ws6, ws5, WordStore.free])
  obtain ⟨g22, s22, bg22, _, g22_1, g22_2, _, h1_g22_4, h0_g22_3, hsq_eq, hbl_g22_3, hbl_g22_4⟩ :=
    exec_sqDistHandlesRegs hd1 hfd_le (sp_ok hm6).1 (sp_ok hm6).2 hB1 (by clear * - hW; omega)
      hcoords6 hh₁_in hh₂_in bg21 (by simp) (by simp)
  have hdist_eq : ((g22 3 : ℝ) / (g22 4 : ℝ)) = handleDistSq P (h₁, h₂) :=
    hsq_eq.trans (handleDistSq_eq_qMap hwfP hsync hh₁_in hh₂_in)
  have w1a := RegExec.lit (inp := inp) hfd_le bg22 (sp_ok hm6).1 (sp_ok hm6).2 (dst := 13) (c := 1) (by decide) hl1
  set g23 := Function.update g22 13 1; have bg23 := bg22.update (r := 13) (by decide) hl1
  obtain ⟨w1b, hm7, bg24⟩ := exec_litStoreHeap hfd_le hm6 hcCeil hbCeil bg23 (table := 0) (valReg := 13) (c := 1)
    (by decide) (by decide) hn0 hl1 (hSub0 1 (by decide) (by decide)) (Nat.le_trans (by decide) hW24)
  set ws7 := ws6.write (.heap 0 1) (g23 13)
  set g24 := Function.update g23 10 1
  obtain ⟨wsEnd, regsEnd, wUpd, hmEnd, bgEnd, hbestEnd, hunchUpd⟩ :=
    exec_updateBestPairRegs hfd_le hm7 hcCeil hbCeil (by clear * - hW24; omega) hSub0
      (by simp [ws7, g23, WordStore.read, WordStore.write])
      hh₁_in hh₂_in (Ne.symm hne_21) bg24
      (by simp [g24, g23, g22_1]) (by simp [g24, g23, g22_2])
      (by simpa [g24, g23] using h0_g22_3) (by simpa [g24, g23] using h1_g22_4)
      (by simpa [g24, g23] using hbl_g22_3) (by simpa [g24, g23] using hbl_g22_4)
      (by simpa [g24, g23] using hdist_eq)
  have s23 : RegExec inp fd W C_cell C_bit writeBestHeaderRegs ws6 g22 wsEnd regsEnd _ _ :=
    w1a.seq (w1b.seq wUpd)
  have hunchW : ∀ loc : RAMCellLoc, ¬ isAnsHeaderLoc loc →
      (loc ∈ wsEnd.live ↔ loc ∈ ws6.live) ∧ wsEnd.vals loc = ws6.vals loc := by
    intro loc hnot0
    have hne1 : loc ≠ .heap 0 1 := fun h => hnot0 (Or.inl h)
    have hnb : ¬ isBestPairLoc loc := fun hb => hnot0 (Or.inr hb)
    have u := hunchUpd loc hnb
    exact ⟨by simp [u.1, ws7, WordStore.write, hne1],
           by simp [u.2, ws7, WordStore.write, Function.update_of_ne hne1]⟩
  have htreeEnd : TreeStoredAt L 0 S (fun _ => 0) (fun _ => 1) wsEnd :=
    htree6.unchanged (fun u _ f _ => by apply hunchW; rintro (h | h | h | h | h) <;> cases h)
  have hLWW : 0 ≤ L * W * W := by positivity
  have hdWW : 0 ≤ d * W * W := by positivity
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq
    (s11.seq (s12.seq (s13.seq (s14.seq (s15.seq (s16.seq (s17.seq (s18.seq (s19.seq (s20.seq
    (s21.seq (s22.seq s23)))))))))))))))))))))).weaken
    rfl rfl (u₂ := 900 * L + 250 * d + 700) (b₂ := (150 * L + 60 * d + 280) * W * W)
    (by omega) (by nlinarith only [hW24, hL1, hd1, hLWW, hdWW])
  rw [← htm_eq] at hbestEnd
  refine ⟨wsEnd, regsEnd, sTot, hmEnd, bgEnd, htreeEnd, hbestEnd, ?_⟩
  intro loc hns hnot0
  exact ⟨(hunchW loc hnot0).1.trans (hunch6 loc hns).1,
         (hunchW loc hnot0).2.trans (hunch6 loc hns).2⟩

/-! ### 5. `considerCandRegs` (`stepBestPair` Rational Comparison) & `exec_considerCandRegs` -/

def considerCandNeqRegs (d : ℕ) : BitRAMStmt :=
  .seq (sqDistHandlesRegs d)
  (.seq (.seq (rLit 10 4) (rLoad 8 0 10))
  (.seq (.seq (rLit 10 5) (rLoad 9 0 10))
  (.seq (rMul 11 8 4)
  (.seq (rMul 12 3 9)
        (.ite (.intLt (.readLocal 11 (.lit 0)) (.readLocal 12 (.lit 0)))
          updateBestPairRegs
          .skip)))))

def considerCandRegs (d : ℕ) : BitRAMStmt :=
  .ite (.intEq (.readLocal 1 (.lit 0)) (.readLocal 2 (.lit 0)))
    .skip
    (considerCandNeqRegs d)

theorem exec_considerCandRegs {d n L B W : ℕ} (hd1 : 1 ≤ d) (hB1 : 1 ≤ B)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    (hW : d * (8 * B + 24) + natBitLength d + L + 28 ≤ W)
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)} {qMap : ℕ → Fin d → ℚ}
    (hwfP : P.WellFormed n)
    (hsync : ∀ id ∈ P.activeIds,
      ltCoords (P.lifetimeOfId id) = P.coords id ∧
      P.coords id = ratPointToEuclidean (qMap (P.handleOfId id)))
    (hcoords : ActiveCoordsStored d L B P.activeHandles qMap ws)
    (hSub0 : ∀ i : ℕ, 1 ≤ i → i ≤ 5 → (.heap 0 (i : ℤ) : RAMCellLoc) ∈ S_write)
    {cur cand : ℕ × ℕ}
    (hbest : BestPairStored B P cur ws)
    (hcand1 : cand.1 ∈ P.activeHandles) (hcand2 : cand.2 ∈ P.activeHandles)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr1 : regs 1 = (cand.1 : ℤ)) (hr2 : regs 2 = (cand.2 : ℤ)) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (considerCandRegs d) ws regs wsEnd regsEnd
        (220 * d + 140) ((52 * d + 40) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      BestPairStored B P (stepBestPair P cur cand) wsEnd ∧
      (∀ loc : RAMCellLoc, ¬ isBestPairLoc loc →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW28 : 28 ≤ W := by clear * - hW; omega
  have hdWW : 0 ≤ d * W * W := by positivity
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  by_cases heq_cand : cand.1 = cand.2
  · have hreg_eq : regs 1 = regs 2 := by rw [hr1, hr2, heq_cand]
    have hstep_eq : stepBestPair P cur cand = cur := by
      unfold stepBestPair; rw [if_neg]; rintro ⟨_, _, hne, _⟩; exact hne heq_cand
    have sSkip := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) hbnd).weaken
      rfl rfl (u₂ := 220 * d + 134) (b₂ := (52 * d + 39) * W * W) (by omega) (by nlinarith only [hW28, hd1, hdWW])
    have sIte := (RegExec.iteEq (tB := .skip) (fB := considerCandNeqRegs d) hbnd (a := 1) (b := 2)
      (by decide) (by decide) (by rw [if_pos hreg_eq]; exact sSkip)).weaken
      rfl rfl (u₂ := 220 * d + 140) (b₂ := (52 * d + 40) * W * W) (by omega) (by nlinarith only [hW28])
    rw [hstep_eq]
    exact ⟨ws, regs, sIte, hmod, hbnd, hbest, fun _ _ => ⟨Iff.rfl, rfl⟩⟩
  · have hreg_ne : regs 1 ≠ regs 2 := by rw [hr1, hr2]; exact_mod_cast heq_cand
    rcases hbest with ⟨hcur1, hcur2, hcur_ne, hread1, hread2, hread3, cNum, cDen, hread4, hread5, hcN0, hcD1, hcN_bl, hcD_bl, hc_val⟩
    obtain ⟨g1, sSq, bg1, _, g1_1, g1_2, _, hdDen1, hdNum0, hsq_eq, hdN_bl, hdD_bl⟩ :=
      exec_sqDistHandlesRegs hd1 hfd_le (sp_ok hmod).1 (sp_ok hmod).2 hB1 (by nlinarith only [hW])
        hcoords hcand1 hcand2 hbnd hr1 hr2
    have hd_val : ((g1 3 : ℝ) / (g1 4 : ℝ)) = handleDistSq P cand :=
      hsq_eq.trans (handleDistSq_eq_qMap hwfP hsync hcand1 hcand2)
    have hn0 : natBitLength 0 ≤ W := Nat.le_trans (by decide) hW28
    have hcN_W : intBitLength cNum ≤ W := hcN_bl.trans (by nlinarith only [hW])
    have hcD_W : intBitLength cDen ≤ W := hcD_bl.trans (by nlinarith only [hW])
    obtain ⟨sL4, bg3⟩ := exec_litLoadHeap hfd_le hmod hcCeil hbCeil bg1 (dst := 8) (table := 0) (c := 4)
      (by decide) hn0 (Nat.le_trans (by decide) hW28) hread4 hcN_W
    set g3 := Function.update (Function.update g1 10 4) 8 cNum
    obtain ⟨sL5, bg5⟩ := exec_litLoadHeap hfd_le hmod hcCeil hbCeil bg3 (dst := 9) (table := 0) (c := 5)
      (by decide) hn0 (Nat.le_trans (by decide) hW28) hread5 hcD_W
    set g5 := Function.update (Function.update g3 10 5) 9 cDen
    have hmul1_bl : intBitLength (g5 8 * g5 4) ≤ W := by
      have hg5_8 : g5 8 = cNum := by simp [g5, g3]
      have hg5_4 : g5 4 = g1 4 := by simp [g5, g3]
      rw [hg5_8, hg5_4]
      exact (intBitLength_mul_le cNum (g1 4)).trans (by linarith only [hcN_bl, hdD_bl, hW])
    have sM1 := RegExec.mul (inp := inp) hfd_le bg5 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 11) (a := 8) (b := 4)
      (by decide) (by decide) (by decide) hmul1_bl
    set g6 := Function.update g5 11 (g5 8 * g5 4); have bg6 := bg5.update (r := 11) (by decide) hmul1_bl
    have hmul2_bl : intBitLength (g6 3 * g6 9) ≤ W := by
      have hg6_3 : g6 3 = g1 3 := by simp [g6, g5, g3]
      have hg6_9 : g6 9 = cDen := by simp [g6, g5]
      rw [hg6_3, hg6_9]
      exact (intBitLength_mul_le (g1 3) cDen).trans (by linarith only [hdN_bl, hcD_bl, hW])
    have sM2 := RegExec.mul (inp := inp) hfd_le bg6 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 12) (a := 3) (b := 9)
      (by decide) (by decide) (by decide) hmul2_bl
    set g7 := Function.update g6 12 (g6 3 * g6 9); have bg7 := bg6.update (r := 12) (by decide) hmul2_bl
    have hg7_11 : g7 11 = cNum * g1 4 := by simp [g7, g6, g5, g3]
    have hg7_12 : g7 12 = g1 3 * cDen := by simp [g7, g6, g5, g3]
    have hcD_pos : (0 : ℝ) < (cDen : ℝ) := by exact_mod_cast lt_of_lt_of_le zero_lt_one hcD1
    have hdD_pos : (0 : ℝ) < (g1 4 : ℝ) := by exact_mod_cast lt_of_lt_of_le zero_lt_one hdDen1
    have hcmp_iff : (g7 11 < g7 12) ↔ (handleDistSq P cur < handleDistSq P cand) := by
      rw [hg7_11, hg7_12, ← hc_val, ← hd_val, div_lt_div_iff₀ hcD_pos hdD_pos]
      exact_mod_cast Iff.rfl
    by_cases hlt : g7 11 < g7 12
    · have hstep_eq : stepBestPair P cur cand = cand := by
        unfold stepBestPair; rw [if_pos ⟨hcand1, hcand2, heq_cand, hcmp_iff.mp hlt⟩]
      obtain ⟨wEnd, qEnd, sUpd, hmEnd, bqEnd, hbestEnd, hunchUpd⟩ :=
        exec_updateBestPairRegs hfd_le hmod hcCeil hbCeil (by clear * - hW28; omega) hSub0 hread1
          hcand1 hcand2 heq_cand bg7
          (by simp [g7, g6, g5, g3, g1_1]) (by simp [g7, g6, g5, g3, g1_2])
          (by simpa [g7, g6, g5, g3] using hdNum0)
          (by simpa [g7, g6, g5, g3] using hdDen1)
          (by simpa [g7, g6, g5, g3] using hdN_bl)
          (by simpa [g7, g6, g5, g3] using hdD_bl)
          (by simpa [g7, g6, g5, g3] using hd_val)
      have sInnerIte := RegExec.iteLt (tB := updateBestPairRegs) (fB := .skip) bg7 (a := 11) (b := 12)
        (by decide) (by decide) (by rw [if_pos hlt]; exact sUpd)
      have sNeq := (sSq.seq (sL4.seq (sL5.seq (sM1.seq (sM2.seq sInnerIte))))).weaken
        rfl rfl (u₂ := 220 * d + 134) (b₂ := (52 * d + 39) * W * W) (by omega) (by nlinarith only [hW28, hd1, hdWW])
      have sOuter := (RegExec.iteEq (tB := .skip) (fB := considerCandNeqRegs d) hbnd (a := 1) (b := 2)
        (by decide) (by decide) (by rw [if_neg hreg_ne]; exact sNeq)).weaken
        rfl rfl (u₂ := 220 * d + 140) (b₂ := (52 * d + 40) * W * W) (by omega) (by nlinarith only [hW28])
      rw [hstep_eq]
      exact ⟨wEnd, qEnd, sOuter, hmEnd, bqEnd, hbestEnd, hunchUpd⟩
    · have hstep_eq : stepBestPair P cur cand = cur := by
        unfold stepBestPair; rw [if_neg]; rintro ⟨_, _, _, hlt_d⟩; exact hlt (hcmp_iff.mpr hlt_d)
      have sSkip2 := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) bg7).weaken
        rfl rfl (u₂ := 48) (b₂ := 36 * W + 160) (by omega) (by omega)
      have sInnerIte := RegExec.iteLt (tB := updateBestPairRegs) (fB := .skip) bg7 (a := 11) (b := 12)
        (by decide) (by decide) (by rw [if_neg hlt]; exact sSkip2)
      have sNeq := (sSq.seq (sL4.seq (sL5.seq (sM1.seq (sM2.seq sInnerIte))))).weaken
        rfl rfl (u₂ := 220 * d + 134) (b₂ := (52 * d + 39) * W * W) (by omega) (by nlinarith only [hW28, hd1, hdWW])
      have sOuter := (RegExec.iteEq (tB := .skip) (fB := considerCandNeqRegs d) hbnd (a := 1) (b := 2)
        (by decide) (by decide) (by rw [if_neg hreg_ne]; exact sNeq)).weaken
        rfl rfl (u₂ := 220 * d + 140) (b₂ := (52 * d + 40) * W * W) (by omega) (by nlinarith only [hW28])
      rw [hstep_eq]
      exact ⟨ws, g7, sOuter, hmod, bg7,
        ⟨hcur1, hcur2, hcur_ne, hread1, hread2, hread3, cNum, cDen, hread4, hread5, hcN0, hcD1, hcN_bl, hcD_bl, hc_val⟩,
        fun _ _ => ⟨Iff.rfl, rfl⟩⟩

end UL.C12LVE
