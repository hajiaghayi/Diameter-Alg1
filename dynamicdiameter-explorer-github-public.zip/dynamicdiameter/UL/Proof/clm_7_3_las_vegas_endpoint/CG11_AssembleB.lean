import Mathlib
import UL.Stmt.lem_5_1
import UL.Stmt.lem_A_1
import UL.Stmt.clm_7_2_chain_schedule
import UL.Proof.clm_7_3_las_vegas_endpoint.CG11_AssembleB0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open scoped ENNReal
open UL
open UL.Proof_lem_A_1
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### 1. Explicit Term-Level `IsBoundedByPoly3` Proofs & Concrete Parameter Bundle -/

theorem poly3_nat_const (c : ℕ) : IsBoundedByPoly3 (fun _ _ _ => (c : ℝ)) :=
  poly3_const (c : ℝ) (Nat.cast_nonneg c)

theorem poly3_nat_add {f g : ℕ → ℕ → ℕ → ℕ}
    (hf : IsBoundedByPoly3 (fun d B L => (f d B L : ℝ)))
    (hg : IsBoundedByPoly3 (fun d B L => (g d B L : ℝ))) :
    IsBoundedByPoly3 (fun d B L => ((f d B L + g d B L : ℕ) : ℝ)) := by
  simpa only [Nat.cast_add] using poly3_add hf hg

theorem poly3_nat_mul {f g : ℕ → ℕ → ℕ → ℕ}
    (hf : IsBoundedByPoly3 (fun d B L => (f d B L : ℝ)))
    (hg : IsBoundedByPoly3 (fun d B L => (g d B L : ℝ))) :
    IsBoundedByPoly3 (fun d B L => ((f d B L * g d B L : ℕ) : ℝ)) := by
  simpa only [Nat.cast_mul] using
    poly3_mul hf hg (fun _ _ _ => Nat.cast_nonneg _) (fun _ _ _ => Nat.cast_nonneg _)

def c11BaseWordSize (d B B_cert s₀_d L K_max : ℕ) : ℕ :=
  2 * sqRadBitBound d B B_cert +
  d * (8 * B + 24) +
  ((K_max + 2) * (2 * d + 9) + L + 1) +
  (K_max + 1) +
  (64 * s₀_d + 2) +
  (s₀_d + 1) +
  (d + 1) +
  L + 64

def c11SpacePerN (d B L K_max W A2_bit_per_n : ℕ) : ℕ :=
  (3 * L + 2 * d * (2 * B + 1) + 9) +
  2 * W * (96 * K_max + 32 * d + (K_max + 2) * (2 * d + 8) + 900) +
  A2_bit_per_n +
  16 * (W + 12)

private theorem c11BaseWordSize_poly3
    {B_cert_fn s₀_fn K_max_fn : ℕ → ℕ → ℕ → ℕ}
    (hBc : IsBoundedByPoly3 (fun d B L => (B_cert_fn d B L : ℝ)))
    (hs₀ : IsBoundedByPoly3 (fun d B L => (s₀_fn d B L : ℝ)))
    (hK : IsBoundedByPoly3 (fun d B L => (K_max_fn d B L : ℝ))) :
    IsBoundedByPoly3 (fun d B L =>
      (c11BaseWordSize d B (B_cert_fn d B L) (s₀_fn d B L) L (K_max_fn d B L) : ℝ)) := by
  have hd : IsBoundedByPoly3 (fun d (_ : ℕ) (_ : ℕ) => (d : ℝ)) := poly3_var_d
  have hB : IsBoundedByPoly3 (fun (_ : ℕ) B (_ : ℕ) => (B : ℝ)) := poly3_var_B
  have hL : IsBoundedByPoly3 (fun (_ : ℕ) (_ : ℕ) L => (L : ℝ)) := poly3_var_L
  have hsq : IsBoundedByPoly3 (fun d B L => (sqRadBitBound d B (B_cert_fn d B L) : ℝ)) := by
    unfold sqRadBitBound
    exact poly3_nat_add
      (poly3_nat_mul (poly3_nat_add hd (poly3_nat_const 1))
        (poly3_nat_add
          (poly3_nat_mul (poly3_nat_const 2)
            (poly3_nat_add (poly3_nat_add hB (poly3_nat_const 2)) hBc))
          (poly3_nat_const 4)))
      (poly3_nat_const 4)
  have t1 := poly3_nat_mul (poly3_nat_const 2) hsq
  have t2 := poly3_nat_mul hd (poly3_nat_add (poly3_nat_mul (poly3_nat_const 8) hB) (poly3_nat_const 24))
  have t3 := poly3_nat_add
    (poly3_nat_add
      (poly3_nat_mul (poly3_nat_add hK (poly3_nat_const 2))
        (poly3_nat_add (poly3_nat_mul (poly3_nat_const 2) hd) (poly3_nat_const 9)))
      hL)
    (poly3_nat_const 1)
  have t4 := poly3_nat_add hK (poly3_nat_const 1)
  have t5 := poly3_nat_add (poly3_nat_mul (poly3_nat_const 64) hs₀) (poly3_nat_const 2)
  have t6 := poly3_nat_add hs₀ (poly3_nat_const 1)
  have t7 := poly3_nat_add hd (poly3_nat_const 1)
  unfold c11BaseWordSize
  exact poly3_nat_add
    (poly3_nat_add
      (poly3_nat_add
        (poly3_nat_add
          (poly3_nat_add
            (poly3_nat_add
              (poly3_nat_add (poly3_nat_add t1 t2) t3)
              t4)
            t5)
          t6)
        t7)
      hL)
    (poly3_nat_const 64)

private theorem c11StepC1BitFactor_poly3
    {s₀_fn K_max_fn W_fn : ℕ → ℕ → ℕ → ℕ}
    (hs₀ : IsBoundedByPoly3 (fun d B L => (s₀_fn d B L : ℝ)))
    (hK : IsBoundedByPoly3 (fun d B L => (K_max_fn d B L : ℝ)))
    (hW : IsBoundedByPoly3 (fun d B L => (W_fn d B L : ℝ))) :
    IsBoundedByPoly3 (fun d B L =>
      (c11StepC1BitFactor d (s₀_fn d B L) L (K_max_fn d B L) (W_fn d B L) : ℝ)) := by
  have hd : IsBoundedByPoly3 (fun d (_ : ℕ) (_ : ℕ) => (d : ℝ)) := poly3_var_d
  have hL : IsBoundedByPoly3 (fun (_ : ℕ) (_ : ℕ) L => (L : ℝ)) := poly3_var_L
  unfold c11StepC1BitFactor
  exact poly3_nat_mul
    (poly3_nat_mul
      (poly3_nat_mul
        (poly3_nat_add hK (poly3_nat_const 1))
        (poly3_nat_add
          (poly3_nat_add
            (poly3_nat_mul (poly3_nat_mul (poly3_nat_const 2) hs₀)
              (poly3_nat_add (poly3_nat_mul (poly3_nat_const 500) hL) (poly3_nat_const 700)))
            (poly3_nat_mul (poly3_nat_const 20) hd))
          (poly3_nat_const 1400)))
      hW)
    hW

private theorem stepDBitCost_poly3
    {s₀_fn K_max_fn W_fn : ℕ → ℕ → ℕ → ℕ}
    (hs₀ : IsBoundedByPoly3 (fun d B L => (s₀_fn d B L : ℝ)))
    (hK : IsBoundedByPoly3 (fun d B L => (K_max_fn d B L : ℝ)))
    (hW : IsBoundedByPoly3 (fun d B L => (W_fn d B L : ℝ))) :
    IsBoundedByPoly3 (fun d B L =>
      (stepDBitCost d (s₀_fn d B L) L (W_fn d B L) (K_max_fn d B L) : ℝ)) := by
  have hd : IsBoundedByPoly3 (fun d (_ : ℕ) (_ : ℕ) => (d : ℝ)) := poly3_var_d
  have hL : IsBoundedByPoly3 (fun (_ : ℕ) (_ : ℕ) L => (L : ℝ)) := poly3_var_L
  have h4s := poly3_nat_add (poly3_nat_mul (poly3_nat_const 4) hs₀) (poly3_nat_const 1)
  have s1 := poly3_nat_mul
    (poly3_nat_add hK (poly3_nat_const 1))
    (poly3_nat_add
      (poly3_nat_add
        (poly3_nat_mul hs₀ (poly3_nat_add (poly3_nat_mul (poly3_nat_const 52) hd) (poly3_nat_const 48)))
        (poly3_nat_mul (poly3_nat_const 12) hL))
      (poly3_nat_const 68))
  have s2 := poly3_nat_mul (poly3_nat_mul h4s h4s)
    (poly3_nat_add (poly3_nat_mul (poly3_nat_const 52) hd) (poly3_nat_const 64))
  have s3 := poly3_nat_mul h4s
    (poly3_nat_add (poly3_nat_mul (poly3_nat_const 140) hL) (poly3_nat_const 240))
  have s4 := poly3_nat_mul (poly3_nat_const 150) hL
  have s5 := poly3_nat_mul (poly3_nat_const 60) hd
  unfold stepDBitCost
  exact poly3_nat_mul
    (poly3_nat_mul
      (poly3_nat_add
        (poly3_nat_add (poly3_nat_add (poly3_nat_add (poly3_nat_add s1 s2) s3) s4) s5)
        (poly3_nat_const 320))
      hW)
    hW

private theorem c11StepBaseBitCost_poly3
    {s₀_fn K_max_fn W_fn B_c1_fn K_c2_b_fn B_D_fn : ℕ → ℕ → ℕ → ℕ}
    (hs₀ : IsBoundedByPoly3 (fun d B L => (s₀_fn d B L : ℝ)))
    (hK : IsBoundedByPoly3 (fun d B L => (K_max_fn d B L : ℝ)))
    (hW : IsBoundedByPoly3 (fun d B L => (W_fn d B L : ℝ)))
    (hBc1 : IsBoundedByPoly3 (fun d B L => (B_c1_fn d B L : ℝ)))
    (hKc2b : IsBoundedByPoly3 (fun d B L => (K_c2_b_fn d B L : ℝ)))
    (hBD : IsBoundedByPoly3 (fun d B L => (B_D_fn d B L : ℝ))) :
    IsBoundedByPoly3 (fun d B L =>
      (c11StepBaseBitCost d (s₀_fn d B L) L (K_max_fn d B L) (W_fn d B L)
        (B_c1_fn d B L) (K_c2_b_fn d B L) (B_D_fn d B L) : ℝ)) := by
  have hd : IsBoundedByPoly3 (fun d (_ : ℕ) (_ : ℕ) => (d : ℝ)) := poly3_var_d
  have hL : IsBoundedByPoly3 (fun (_ : ℕ) (_ : ℕ) L => (L : ℝ)) := poly3_var_L
  have a1 := poly3_nat_add
    (poly3_nat_add (poly3_nat_mul (poly3_nat_const 80) hL) (poly3_nat_mul (poly3_nat_const 220) hd))
    (poly3_nat_const 120)
  have a2 := poly3_nat_mul (poly3_nat_add hK (poly3_nat_const 1))
    (poly3_nat_add
      (poly3_nat_add (poly3_nat_mul (poly3_nat_const 180) hL) (poly3_nat_mul (poly3_nat_const 80) hd))
      (poly3_nat_const 240))
  have a3 := poly3_nat_mul (poly3_nat_mul (poly3_nat_const 2) hs₀)
    (poly3_nat_add (poly3_nat_mul (poly3_nat_const 66) hL) (poly3_nat_const 96))
  have tMain := poly3_nat_mul (poly3_nat_mul (poly3_nat_add (poly3_nat_add a1 a2) a3) hW) hW
  have tLoop := poly3_nat_mul
    (poly3_nat_add
      (poly3_nat_add (poly3_nat_mul (poly3_nat_const 4) hW) (poly3_nat_const 24))
      hKc2b)
    hK
  have tClean := poly3_nat_mul (poly3_nat_const 4300) hW
  unfold c11StepBaseBitCost
  exact poly3_nat_add
    (poly3_nat_add (poly3_nat_add (poly3_nat_add tMain hBc1) tLoop) tClean)
    hBD

private theorem c11StepRebBitFactor_poly3
    {W_fn B_c1_fn K_c2_b_fn : ℕ → ℕ → ℕ → ℕ}
    (hW : IsBoundedByPoly3 (fun d B L => (W_fn d B L : ℝ)))
    (hBc1 : IsBoundedByPoly3 (fun d B L => (B_c1_fn d B L : ℝ)))
    (hKc2b : IsBoundedByPoly3 (fun d B L => (K_c2_b_fn d B L : ℝ))) :
    IsBoundedByPoly3 (fun d B L =>
      (c11StepRebBitFactor (W_fn d B L) (B_c1_fn d B L) (K_c2_b_fn d B L) : ℝ)) := by
  unfold c11StepRebBitFactor
  exact poly3_nat_add
    (poly3_nat_add
      (poly3_nat_add
        (poly3_nat_mul (poly3_nat_const 2) hBc1)
        (poly3_nat_mul (poly3_nat_const 4) hW))
      (poly3_nat_const 24))
    hKc2b

private theorem c11SpacePerN_poly3
    {K_max_fn W_fn A2_bit_per_n_fn : ℕ → ℕ → ℕ → ℕ}
    (hK : IsBoundedByPoly3 (fun d B L => (K_max_fn d B L : ℝ)))
    (hW : IsBoundedByPoly3 (fun d B L => (W_fn d B L : ℝ)))
    (hA2b : IsBoundedByPoly3 (fun d B L => (A2_bit_per_n_fn d B L : ℝ))) :
    IsBoundedByPoly3 (fun d B L =>
      (c11SpacePerN d B L (K_max_fn d B L) (W_fn d B L) (A2_bit_per_n_fn d B L) : ℝ)) := by
  have hd : IsBoundedByPoly3 (fun d (_ : ℕ) (_ : ℕ) => (d : ℝ)) := poly3_var_d
  have hB : IsBoundedByPoly3 (fun (_ : ℕ) B (_ : ℕ) => (B : ℝ)) := poly3_var_B
  have hL : IsBoundedByPoly3 (fun (_ : ℕ) (_ : ℕ) L => (L : ℝ)) := poly3_var_L
  have p1 := poly3_nat_add
    (poly3_nat_add
      (poly3_nat_mul (poly3_nat_const 3) hL)
      (poly3_nat_mul (poly3_nat_mul (poly3_nat_const 2) hd)
        (poly3_nat_add (poly3_nat_mul (poly3_nat_const 2) hB) (poly3_nat_const 1))))
    (poly3_nat_const 9)
  have p2 := poly3_nat_mul
    (poly3_nat_mul (poly3_nat_const 2) hW)
    (poly3_nat_add
      (poly3_nat_add
        (poly3_nat_add
          (poly3_nat_mul (poly3_nat_const 96) hK)
          (poly3_nat_mul (poly3_nat_const 32) hd))
        (poly3_nat_mul (poly3_nat_add hK (poly3_nat_const 2))
          (poly3_nat_add (poly3_nat_mul (poly3_nat_const 2) hd) (poly3_nat_const 8))))
      (poly3_nat_const 900))
  have p4 := poly3_nat_mul (poly3_nat_const 16) (poly3_nat_add hW (poly3_nat_const 12))
  unfold c11SpacePerN
  exact poly3_nat_add (poly3_nat_add (poly3_nat_add p1 p2) hA2b) p4

theorem c11BaseWordSize_bounds {d B B_cert s₀_d L K_max W : ℕ}
    (hW : c11BaseWordSize d B B_cert s₀_d L K_max ≤ W) :
    (2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
      natBitLength K_max + natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W) ∧
    (2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
      natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W) ∧
    (2 * sqRadBitBound d B B_cert + d * (8 * B + 24) +
      natBitLength ((K_max + 2) * posNodeStride d L) +
      natBitLength s₀_d + natBitLength d + L + 40 ≤ W) := by
  have hns := natBitLength_nodeStride_bound d L K_max
  have hk_bl := natBitLength_le_add_one K_max
  have hs64_bl := natBitLength_le_add_one (64 * s₀_d + 1)
  have hs_bl := natBitLength_le_add_one s₀_d
  have hd_bl := natBitLength_le_add_one d
  dsimp only [c11BaseWordSize] at hW
  refine ⟨by omega, by omega, by omega⟩

theorem c11SpacePerN_bitCeil {d n B L K_max W A2_bit_per_n : ℕ}
    (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n))
    {inp : BitRAMInput d}
    (hinp_b : inp.inputBitSpace ≤ n * (L + 1 + d * (2 * B + 1)) + d * (2 * B + 1) + 2 * L + 8) :
    inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card +
      n * A2_bit_per_n + 16 * (W + 12) ≤
      n * c11SpacePerN d B L K_max W A2_bit_per_n := by
  have hn_pos : 0 < n := by omega
  have hp_inp : inp.inputBitSpace ≤ n * (3 * L + 2 * d * (2 * B + 1) + 9) := by
    have hextra : d * (2 * B + 1) + 2 * L + 8 ≤ n * (d * (2 * B + 1) + 2 * L + 8) :=
      Nat.le_mul_of_pos_left _ hn_pos
    have hsum : n * (L + 1 + d * (2 * B + 1)) + n * (d * (2 * B + 1) + 2 * L + 8) =
        n * (3 * L + 2 * d * (2 * B + 1) + 9) := by ring
    linarith only [hinp_b, hextra, hsum]
  have hcard := posDimWriteLocs_card_le_mul_n (d := d) (K_max := K_max) hn hL
  have hp_ws : 2 * W * (posDimWriteLocs d L K_max).card ≤
      n * (2 * W * (96 * K_max + 32 * d + (K_max + 2) * (2 * d + 8) + 900)) := by
    calc 2 * W * (posDimWriteLocs d L K_max).card
      _ ≤ 2 * W * (n * (96 * K_max + 32 * d + (K_max + 2) * (2 * d + 8) + 900)) :=
          Nat.mul_le_mul_left (2 * W) hcard
      _ = n * (2 * W * (96 * K_max + 32 * d + (K_max + 2) * (2 * d + 8) + 900)) := by ring
  have hp_16 : 16 * (W + 12) ≤ n * (16 * (W + 12)) :=
    Nat.le_mul_of_pos_left _ hn_pos
  have htot :
      n * (3 * L + 2 * d * (2 * B + 1) + 9) +
      n * (2 * W * (96 * K_max + 32 * d + (K_max + 2) * (2 * d + 8) + 900)) +
      n * A2_bit_per_n +
      n * (16 * (W + 12)) =
      n * c11SpacePerN d B L K_max W A2_bit_per_n := by
    unfold c11SpacePerN; ring
  linarith only [hp_inp, hp_ws, hp_16, htot]

/-! ### 2. Clean `C11StepC2Provider` Interface & Full `S_clm_7_3_las_vegas_endpoint` Assembly -/

def C11StepC2Provider : Prop :=
  S_lem_A_2 →
  S_claim_A_2_deletion_witness →
  ∀ (s₀ : ℕ → ℕ) (progA2 : BitRAMStmt) (timeA2 spaceA2 bitLenA2 : ℕ → ℕ → ℝ),
    (∀ d : ℕ, 1 ≤ s₀ d) →
    IsBoundedByPoly1 (fun d => (s₀ d : ℝ)) →
    IsBoundedByPoly2 timeA2 → (∀ d B, 1 ≤ timeA2 d B) →
    IsBoundedByPoly2 spaceA2 → (∀ d B, 1 ≤ spaceA2 d B) →
    IsBoundedByPoly2 bitLenA2 → (∀ d B, 1 ≤ bitLenA2 d B) →
    ∀ (C_K : ℕ), 1 ≤ C_K →
      ∃ (W_c2_fn : ℕ → ℕ → ℕ → ℕ),
        IsBoundedByPoly3 (fun d B L => (W_c2_fn d B L : ℝ)) ∧
        ∀ (W_fn : ℕ → ℕ → ℕ → ℕ),
          IsBoundedByPoly3 (fun d B L => (W_fn d B L : ℝ)) →
          (∀ d B L, W_c2_fn d B L ≤ W_fn d B L) →
          ∃ (A2_cell_per_n_fn A2_bit_per_n_fn K_c2_u_fn K_c2_b_fn : ℕ → ℕ → ℕ → ℕ),
            IsBoundedByPoly3 (fun d B L => (K_c2_b_fn d B L : ℝ)) ∧
            IsBoundedByPoly3 (fun d B L => (A2_bit_per_n_fn d B L : ℝ)) ∧
            ∀ (d n B : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ B →
              let L := Nat.clog 2 (2 * n)
              let B_cert := Nat.ceil (bitLenA2 d B) + 1
              let K_max := C_K * s₀ d * L
              let W := W_fn d B L
              ∀ (ctor : SyncCertifiedNodeConstructor d (PosDimNodeData d (s₀ d))),
                IsValidSyncNodeConstructor n (2 * s₀ d - 1) (1 / (4 * (s₀ d : ℝ))) 1
                  (2 * (((L : ℝ) + 1) ^ 2) * timeA2 d B + 2)
                  (RatAdmissiblePointSet d B) ctor →
                (∀ hist sufPref ltCoords P₀ bs built,
                  2 * s₀ d ≤ P₀.card →
                  (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d B) →
                  ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
                    ∃ outA2 : BitRAMExecOutcome,
                      C12CertifiedNodeSpec (s₀ d) B progA2 spaceA2 bitLenA2
                        (c12ReplayHistory d hist) ltCoords P₀ bs built outA2) →
                ∃ c2Stmt : BitRAMStmt,
                  C11StepC2Spec n L B B_cert K_max W
                    (n * A2_cell_per_n_fn d B L)
                    (n * A2_bit_per_n_fn d B L)
                    (K_c2_u_fn d B L)
                    (K_c2_b_fn d B L)
                    ctor c2Stmt .heap0_10

theorem prove_part4_of_stepC2
    (hStepC2 : C11StepC2Provider)
    (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction)
    (h_clm_5_1_block_witness : S_clm_5_1_block_witness)
    (h_lem_5_2 : S_lem_5_2)
    (h_lem_A_2 : S_lem_A_2)
    (h_claim_A_2_deletion_witness : S_claim_A_2_deletion_witness)
    (h_claim_C_3_sync_suffix : S_claim_C_3_sync_suffix) :
    ∃ (spacePoly timePoly : ℕ → ℕ → ℕ → ℝ) (queryConst writeFactor : ℕ),
      IsBoundedByPoly3 spacePoly ∧ IsBoundedByPoly3 timePoly ∧
      ∀ (d n B : ℕ), 2 ≤ n → 1 ≤ B →
        let L : ℕ := Nat.clog 2 (2 * n)
        ∃ (prog : BitRAMDynamicProgram) (initOut : BitRAMExecOutcome),
          prog.evalInit n d = some initOut ∧
          let alg : DynamicDiameterStructure d WordStore :=
            { initState := initOut.words
              initWork := initOut.bitCost
              initSpace := initOut.peakBitSpace
              cachedAnswer := fun ws =>
                let ca := BitRAMDynamicProgram.readCachedAnswer ws
                { diameterHandles := ca.1, cachedDistSq := ca.2 }
              retrieveIdsAndRefCost := 5
              writeOutputCost := fun len => len + 1
              stepWithBits := fun activeH hCoords ws uop bs =>
                let rawOut :=
                  match uop with
                  | .insert pt => prog.evalUpdate n activeH hCoords ws true pt 0 bs
                  | .delete h => prog.evalUpdate n activeH hCoords ws false 0 h bs
                rawOut.map (fun out =>
                  let ca := BitRAMDynamicProgram.readCachedAnswer out.words
                  { nextState := out.words
                    returnedHandle :=
                      match uop with
                      | .insert _ => BitRAMDynamicProgram.readReturnedHandle out.words
                      | .delete _ => none
                    storedAnswer := { diameterHandles := ca.1, cachedDistSq := ca.2 }
                    work := out.bitCost
                    peakSpace := out.peakBitSpace }) }
          SatisfiesDynamicStorageAndQueryModel queryConst writeFactor alg ∧
          SatisfiesLasVegasGuarantee n (Real.sqrt 2) (timePoly d B L)
            (RatAdmissiblePointSet d B) alg ∧
          SatisfiesUnboundedSpaceBound n (RatAdmissiblePointSet d B) alg
            ((n : ℝ) * spacePoly d B L) := by
  classical
  obtain ⟨s₀, progA2, timeA2, spaceA2, bitLenA2,
    hs₀_pos, hs₀_poly, htime_poly, htime_ge1, hspace_poly, hspace_ge1, hbl_poly, hbl_ge1,
    hPn_poly, hPn_nn, hctor_all⟩ :=
    c12_build_syncCtorA2 h_lem_A_2 h_claim_A_2_deletion_witness
  let P_node : ℕ → ℕ → ℕ → ℝ := fun d B L => 2 * (((L : ℝ) + 1) ^ 2) * timeA2 d B + 2
  let P_α : ℕ → ℝ := fun d => 4 * (s₀ d : ℝ)
  have hPα_poly : IsBoundedByPoly1 P_α :=
    c12_isBoundedByPoly1_mul_const hs₀_poly (by norm_num)
  have hPα_ge1 : ∀ d : ℕ, 1 ≤ P_α d := fun d => by
    have : (1 : ℝ) ≤ (s₀ d : ℝ) := by exact_mod_cast hs₀_pos d
    dsimp [P_α]; linarith
  obtain ⟨_c_chg, _C_sum, _C_charge, _P_suf, _B_card, P_tot,
    _, _, _, _, _, _, _, hPtot_poly, hPtot_nn, hC3_spec⟩ :=
    h_claim_C_3_sync_suffix P_α P_node hPα_poly hPα_ge1 hPn_poly hPn_nn
  set c₁ := c11ChooseC1 h_clm_5_1_chain_contraction
  set C_nodes := c11ChooseCNodes h_clm_5_1_chain_contraction
  obtain ⟨hc₁_pos, hCn_pos, h51⟩ :=
    Classical.choose_spec (Classical.choose_spec h_clm_5_1_chain_contraction)
  let C_K : ℕ := Nat.ceil ((C_nodes + 1) * 4)
  have hCK_ge1 : 1 ≤ C_K := by
    have hpos : (0 : ℝ) < (C_nodes + 1) * 4 := by dsimp only [C_nodes, c11ChooseCNodes]; linarith [hCn_pos]
    exact Nat.one_le_iff_ne_zero.mpr (Nat.ceil_pos.mpr hpos).ne'
  obtain ⟨W_c2_fn, hWc2_p3, hStepC2_W⟩ :=
    hStepC2 h_lem_A_2 h_claim_A_2_deletion_witness
      s₀ progA2 timeA2 spaceA2 bitLenA2
      hs₀_pos hs₀_poly htime_poly htime_ge1 hspace_poly hspace_ge1 hbl_poly hbl_ge1
      C_K hCK_ge1
  let B_cert_fn : ℕ → ℕ → ℕ → ℕ := fun d B _ => Nat.ceil (bitLenA2 d B) + 1
  let s₀_fn : ℕ → ℕ → ℕ → ℕ := fun d _ _ => s₀ d
  let K_max_fn : ℕ → ℕ → ℕ → ℕ := fun d _ L => C_K * s₀ d * L
  let W_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    c11BaseWordSize d B (B_cert_fn d B L) (s₀_fn d B L) L (K_max_fn d B L) + W_c2_fn d B L
  have hL_p3 : IsBoundedByPoly3 (fun _ _ L => (L : ℝ)) := poly3_var_L
  have hs₀_p3 : IsBoundedByPoly3 (fun d B L => (s₀_fn d B L : ℝ)) :=
    poly3_of_poly1_d hs₀_poly
  have hBc_p3 : IsBoundedByPoly3 (fun d B L => (B_cert_fn d B L : ℝ)) := by
    have hceil : IsBoundedByPoly3 (fun d B _ => (Nat.ceil (bitLenA2 d B) : ℝ)) :=
      poly3_natCeil (poly3_of_poly2_dB hbl_poly) (fun d B _ => by linarith [hbl_ge1 d B])
    exact poly3_nat_add (f := fun d B _ => Nat.ceil (bitLenA2 d B)) (g := fun _ _ _ => 1)
      hceil (poly3_nat_const 1)
  have hK_p3 : IsBoundedByPoly3 (fun d B L => (K_max_fn d B L : ℝ)) :=
    poly3_nat_mul (f := fun d B L => C_K * s₀_fn d B L) (g := fun _ _ L => L)
      (poly3_nat_mul (f := fun _ _ _ => C_K) (g := s₀_fn) (poly3_nat_const C_K) hs₀_p3)
      hL_p3
  have hW_p3 : IsBoundedByPoly3 (fun d B L => (W_fn d B L : ℝ)) :=
    poly3_nat_add (c11BaseWordSize_poly3 hBc_p3 hs₀_p3 hK_p3) hWc2_p3
  obtain ⟨A2_cell_per_n_fn, A2_bit_per_n_fn, K_c2_u_fn, K_c2_b_fn,
    hKc2b_p3, hA2b_p3, hStepC2_inst⟩ :=
    hStepC2_W W_fn hW_p3 (fun d B L => Nat.le_add_left _ _)
  let B_c1_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    c11StepC1BitFactor d (s₀_fn d B L) L (K_max_fn d B L) (W_fn d B L)
  let B_D_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    stepDBitCost d (s₀_fn d B L) L (W_fn d B L) (K_max_fn d B L)
  let P_step_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    c11StepBaseBitCost d (s₀_fn d B L) L (K_max_fn d B L) (W_fn d B L)
      (B_c1_fn d B L) (K_c2_b_fn d B L) (B_D_fn d B L)
  let K_sim_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    c11StepRebBitFactor (W_fn d B L) (B_c1_fn d B L) (K_c2_b_fn d B L)
  let Space_per_n_fn : ℕ → ℕ → ℕ → ℕ := fun d B L =>
    c11SpacePerN d B L (K_max_fn d B L) (W_fn d B L) (A2_bit_per_n_fn d B L)
  have hBc1_p3 := c11StepC1BitFactor_poly3 hs₀_p3 hK_p3 hW_p3
  have hBD_p3 := stepDBitCost_poly3 hs₀_p3 hK_p3 hW_p3
  have hPstep_poly := c11StepBaseBitCost_poly3 hs₀_p3 hK_p3 hW_p3 hBc1_p3 hKc2b_p3 hBD_p3
  have hKsim_poly := c11StepRebBitFactor_poly3 hW_p3 hBc1_p3 hKc2b_p3
  have hSp_poly := c11SpacePerN_poly3 hK_p3 hW_p3 hA2b_p3
  let timeDim0 : ℕ → ℕ → ℕ → ℝ :=
    fun _ _ L => (260 * (L : ℝ) + 321) * (((L : ℝ) + 24) * ((L : ℝ) + 24))
  let timeDpos : ℕ → ℕ → ℕ → ℝ :=
    fun d B L => 1 + (P_step_fn d B L : ℝ) + (K_sim_fn d B L : ℝ) * P_tot d B L
  let timePoly : ℕ → ℕ → ℕ → ℝ := fun d B L => timeDim0 d B L + timeDpos d B L
  let spacePoly : ℕ → ℕ → ℕ → ℝ :=
    fun d B L => 120 * ((L : ℝ) + 24) + ((L : ℝ) + 2 + (Space_per_n_fn d B L : ℝ))
  have hL24_p3 : IsBoundedByPoly3 (fun _ _ L => (L : ℝ) + 24) :=
    c12_isBoundedByPoly3_add hL_p3 (c12_isBoundedByPoly3_const 24)
  have h260L_p3 : IsBoundedByPoly3 (fun _ _ L => 260 * (L : ℝ) + 321) :=
    c12_isBoundedByPoly3_add
      (c12_isBoundedByPoly3_mul_nonneg (c12_isBoundedByPoly3_const 260) hL_p3
        (fun _ _ _ => by norm_num) (fun _ _ _ => Nat.cast_nonneg _))
      (c12_isBoundedByPoly3_const 321)
  have htimeDim0_p3 : IsBoundedByPoly3 timeDim0 :=
    c12_isBoundedByPoly3_mul_nonneg h260L_p3
      (c12_isBoundedByPoly3_mul_nonneg hL24_p3 hL24_p3
        (fun _ _ _ => by positivity) (fun _ _ _ => by positivity))
      (fun _ _ _ => by positivity) (fun _ _ _ => by positivity)
  have htimeDpos_p3 : IsBoundedByPoly3 timeDpos :=
    c12_isBoundedByPoly3_add
      (c12_isBoundedByPoly3_add (c12_isBoundedByPoly3_const 1) hPstep_poly)
      (c12_isBoundedByPoly3_mul_nonneg hKsim_poly hPtot_poly
        (fun _ _ _ => Nat.cast_nonneg _) hPtot_nn)
  have htime_p3 : IsBoundedByPoly3 timePoly :=
    c12_isBoundedByPoly3_add htimeDim0_p3 htimeDpos_p3
  have hspace_p3 : IsBoundedByPoly3 spacePoly :=
    c12_isBoundedByPoly3_add
      (c12_isBoundedByPoly3_mul_nonneg (c12_isBoundedByPoly3_const 120) hL24_p3
        (fun _ _ _ => by norm_num) (fun _ _ _ => by positivity))
      (c12_isBoundedByPoly3_add
        (c12_isBoundedByPoly3_add hL_p3 (c12_isBoundedByPoly3_const 2))
        hSp_poly)
  refine ⟨spacePoly, timePoly, 5, 1, hspace_p3, htime_p3, ?_⟩
  intro d n B hn hB L
  cases d with
  | zero =>
      obtain ⟨prog, initOut, heval, hStore, hLV, hSp⟩ := prove_part4_dim0 hn hB
      refine ⟨prog, initOut, heval, hStore, ?_, ?_⟩
      · refine c12_satisfiesLasVegasGuarantee_mono hLV ?_
        have hdpos_nn : 0 ≤ timeDpos 0 B L := by
          dsimp [timeDpos]
          have := hPtot_nn 0 B L
          positivity
        have ht0_eq : ((((260 * L + 321) * (L + 24) * (L + 24) : ℕ) : ℝ)) = timeDim0 0 B L := by
          dsimp [timeDim0]; push_cast; ring
        rw [ht0_eq]; dsimp [timePoly]; linarith
      · refine c12_satisfiesUnboundedSpaceBound_mono hSp ?_
        have hextra_nn : 0 ≤ (L : ℝ) + 2 + (Space_per_n_fn 0 B L : ℝ) := by positivity
        have hs0_eq : ((120 * (L + 24) : ℕ) : ℝ) = 120 * ((L : ℝ) + 24) := by push_cast; ring
        rw [hs0_eq]
        refine mul_le_mul_of_nonneg_left ?_ (Nat.cast_nonneg n)
        dsimp [spacePoly]; linarith
  | succ d' =>
      have hd1 : 1 ≤ d' + 1 := Nat.succ_pos d'
      set d_pos := d' + 1
      obtain ⟨ctor, hctor_valid, hctor_spec⟩ := hctor_all d_pos B n hd1 hB hn
      have hctor_wk : ∀ hist sufPref ltCoords P₀ bs built,
          2 * s₀ d_pos ≤ P₀.card →
          (∀ lt ∈ P₀, ltCoords lt ∈ RatAdmissiblePointSet d_pos B) →
          ctor.buildWithBits hist sufPref ltCoords P₀ bs = some built →
            P₀.card ≤ built.work := by
        intro hist sufPref ltCoords P₀ bs built hm hadm hb
        obtain ⟨outA2, hsp⟩ := hctor_spec hist sufPref ltCoords P₀ bs built hm hadm hb
        have hweq := hsp.work_eq
        omega
      have hs₀_R : (1 : ℝ) ≤ (s₀ d_pos : ℝ) := by exact_mod_cast hs₀_pos d_pos
      have hα_pos : 0 < (1 / (4 * (s₀ d_pos : ℝ))) := by positivity
      have hα_le1 : (1 / (4 * (s₀ d_pos : ℝ))) ≤ 1 := by
        rw [div_le_one (by positivity)]; linarith
      have hsqrt2_ge1 : (1 : ℝ) ≤ Real.sqrt 2 := by
        rw [← Real.sqrt_one]
        exact Real.sqrt_le_sqrt (by norm_num)
      have hC3_inst := hC3_spec d_pos B n (2 * s₀ d_pos - 1) (PosDimNodeData d_pos (s₀ d_pos))
        (1 / (4 * (s₀ d_pos : ℝ))) (Real.sqrt 2) 1 (RatAdmissiblePointSet d_pos B)
        ctor (ansPolPosDim d_pos (s₀ d_pos) L)
        hB hn hα_pos hα_le1 le_rfl hsqrt2_ge1 zero_le_one hctor_valid
        isValidSyncCheckedAnswerPolicy_ansPolPosDim
      have hC3_tot : ∀ adv : AdaptiveAdversary d_pos,
          IsValidSyncAdaptiveAdversary n (2 * s₀ d_pos - 1) (1 / (4 * (s₀ d_pos : ℝ)))
            (RatAdmissiblePointSet d_pos B) ctor (ansPolPosDim d_pos (s₀ d_pos) L) adv →
          ∀ T : ℕ, 1 ≤ T →
            syncPrefixExpectedRebuildWork (2 * s₀ d_pos - 1) (1 / (4 * (s₀ d_pos : ℝ))) ctor
              (ansPolPosDim d_pos (s₀ d_pos) L) adv T ≠ ⊤ ∧
            (syncPrefixExpectedRebuildWork (2 * s₀ d_pos - 1) (1 / (4 * (s₀ d_pos : ℝ))) ctor
              (ansPolPosDim d_pos (s₀ d_pos) L) adv T).toReal ≤
              (T : ℝ) * 1 * P_tot d_pos B L := by
        intro adv hadv T hT
        have h2 := (hC3_inst.2 adv hadv).2 T hT
        exact ⟨h2.2.1, h2.2.2⟩
      set B_cert := B_cert_fn d_pos B L
      set K_max := K_max_fn d_pos B L
      set W := W_fn d_pos B L
      obtain ⟨c2Stmt, hSpecC2⟩ :=
        hStepC2_inst d_pos n B hd1 hn hB ctor hctor_valid hctor_spec
      have hBc1 : 1 ≤ B_cert := Nat.le_add_left 1 _
      obtain ⟨hW_sim, hW_c1, hW_D⟩ :=
        c11BaseWordSize_bounds (d := d_pos) (B := B) (B_cert := B_cert)
          (s₀_d := s₀ d_pos) (L := L) (K_max := K_max) (W := W)
          (Nat.le_add_right _ _)
      have hSpecC1 : C11StepC1Spec (d := d_pos) (s₀_d := s₀ d_pos) n L B B_cert K_max W
          (c11StepC1UnitFactor d_pos (s₀ d_pos) L K_max)
          (B_c1_fn d_pos B L)
          (posDimStepC1Gather d_pos (s₀ d_pos) L) .heap0_10 :=
        c11_stepC1Spec h_claim_A_2_deletion_witness hd1 (hs₀_pos d_pos) hn rfl hB hBc1 hW_c1
      have hSpecD : C11StepDSpec (d := d_pos) (s₀_d := s₀ d_pos) n L B B_cert K_max W
          (stepDUnitCost d_pos (s₀ d_pos) L K_max)
          (B_D_fn d_pos B L)
          (posDimStepD d_pos (s₀ d_pos) L) :=
        c11_stepDSpec (s₀_d := s₀ d_pos) (B_cert := B_cert) (K_max := K_max)
          hd1 hn rfl hB hW_D
      let updStmt := (progPosDim d_pos (s₀ d_pos) L
        (posDimStepC1Gather d_pos (s₀ d_pos) L) c2Stmt .heap0_10
        (posDimStepD d_pos (s₀ d_pos) L)).updateStmt
      obtain ⟨heval, hStore, hLV, hSp⟩ :=
        c11_lasVegas_dpos_fixed hd1 hn hB (hs₀_pos d_pos)
          h_lem_5_2 h_clm_5_1_chain_contraction h_clm_5_1_block_witness
          (hPn_nn d_pos B L) hctor_valid hctor_wk hC3_tot
          (B_cert := B_cert) (K_max := K_max) (W := W)
          (K_cancel := B_c1_fn d_pos B L)
          (P_step := P_step_fn d_pos B L)
          (K_sim := K_sim_fn d_pos B L)
          (Space_bound := n * Space_per_n_fn d_pos B L)
          (updStmt := updStmt)
          (fun h51_len cur syncNext qMap ws op bs inp
               hinvS _hk_le hlog_le hinvR hleg hdec _hinp_H _hinp_q hinp_sp _hinp_c hinp_b => by
            have hu_age :=
              (c12SyncInv_chain_len_bounds hn (hs₀_pos d_pos) hCn_pos h51 hinvS).2.2
            have hbCeil_a2 :=
              c11SpacePerN_bitCeil (K_max := K_max) (W := W)
                (A2_bit_per_n := A2_bit_per_n_fn d_pos B L) hn rfl hinp_b
            obtain ⟨rawOut, qMap', hrun, hinvR', hret, hca, hwk, hsp⟩ :=
              exec_progPosDim_singleStep
                h_claim_A_2_deletion_witness
                hd1 (hs₀_pos d_pos) hn rfl hB hBc1 hW_sim
                h51_len hlog_le hctor_valid hctor_wk
                hSpecC1 hSpecC2 hSpecD
                (C_cell := inp.inputCellSpace + (posDimWriteLocs d_pos L K_max).card +
                  n * A2_cell_per_n_fn d_pos B L + 16)
                (C_bit := n * Space_per_n_fn d_pos B L)
                le_rfl hbCeil_a2
                hinvS.2 hu_age hinvR hleg hdec
                (by cases op <;> exact hinp_sp)
            exact ⟨rawOut, qMap', hrun, hinvR', (by cases op <;> exact hret), hca, hwk, hsp⟩)
      refine ⟨{ initStmt := .skip, updateStmt := updStmt }, _, heval, hStore, ?_, ?_⟩
      · refine c12_satisfiesLasVegasGuarantee_mono hLV ?_
        have hdim0_nn : 0 ≤ timeDim0 d_pos B L := by dsimp [timeDim0]; positivity
        dsimp [timePoly, timeDpos]
        linarith
      · refine c12_satisfiesUnboundedSpaceBound_mono hSp ?_
        obtain ⟨_, _, h2n_pow, _⟩ := clog_two_mul_bounds hn
        change 2 * n ≤ 2 ^ L at h2n_pow
        have hn_bl : intBitLength (n : ℤ) ≤ L + 2 :=
          nat_lt_pow2_bitLength_le (by omega : n < 2 ^ L)
        have hn_ge1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (show 1 ≤ n by omega)
        have hbl_le : (intBitLength (n : ℤ) : ℝ) ≤ (n : ℝ) * spacePoly d_pos B L := by
          have h1 : (intBitLength (n : ℤ) : ℝ) ≤ (L : ℝ) + 2 := by exact_mod_cast hn_bl
          have h2 : (L : ℝ) + 2 ≤ spacePoly d_pos B L := by
            dsimp [spacePoly]
            have : 0 ≤ 120 * ((L : ℝ) + 24) := by positivity
            have : 0 ≤ (Space_per_n_fn d_pos B L : ℝ) := Nat.cast_nonneg _
            linarith
          have hsp_nn : 0 ≤ spacePoly d_pos B L := by linarith
          calc (intBitLength (n : ℤ) : ℝ) ≤ 1 * spacePoly d_pos B L := by linarith
            _ ≤ (n : ℝ) * spacePoly d_pos B L := mul_le_mul_of_nonneg_right hn_ge1 hsp_nn
        have hsp_le : ((n * Space_per_n_fn d_pos B L : ℕ) : ℝ) ≤ (n : ℝ) * spacePoly d_pos B L := by
          push_cast
          refine mul_le_mul_of_nonneg_left ?_ (Nat.cast_nonneg n)
          dsimp [spacePoly]
          have : 0 ≤ 120 * ((L : ℝ) + 24) + ((L : ℝ) + 2) := by positivity
          linarith
        exact max_le hbl_le hsp_le

theorem prove_clm_7_3_of_stepC2
    (hStepC2 : C11StepC2Provider)
    (_h_lem_5_1 : S_lem_5_1)
    (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction)
    (h_clm_5_1_block_witness : S_clm_5_1_block_witness)
    (h_lem_5_2 : S_lem_5_2)
    (_h_lem_A_1 : S_lem_A_1)
    (h_lem_A_2 : S_lem_A_2)
    (h_claim_A_2_deletion_witness : S_claim_A_2_deletion_witness)
    (h_claim_C_3_sync_suffix : S_claim_C_3_sync_suffix)
    (_h_clm_7_2_chain_schedule : S_clm_7_2_chain_schedule)
    (h_lem_7_2 : S_lem_7_2) :
    S_clm_7_3_las_vegas_endpoint :=
  ⟨prove_part1 h_lem_5_2,
   prove_part2 h_clm_5_1_block_witness,
   prove_part3 h_lem_7_2,
   prove_part4_of_stepC2 hStepC2 h_clm_5_1_chain_contraction h_clm_5_1_block_witness
     h_lem_5_2 h_lem_A_2 h_claim_A_2_deletion_witness h_claim_C_3_sync_suffix⟩

end UL.C12LVE
