import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorA0
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorA
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorB0a
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorB0
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorB1
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorB
set_option autoImplicit false

/-!
# Slice 2A-1 (`CG07_SyncCtor`): Handle-Ordered `SyncCertifiedNodeConstructor` & Las Vegas Transfer

Exports in `namespace UL.C12LVE`:
- `c12EnumByKey`, `c12EnumByKey_handle_and_coords`, `c12ExtractedVar_spec` (`CG07_SyncCtorA0`)
- `C12CertifiedNodeSpec`, `c12_build_syncCtorA2` (`CG07_SyncCtorA`)
- `c12ChainBirthPot`, `C12SyncInv`, `c12SyncInv_chain_len_bounds`, `C12SyncStepDecomp` (`CG07_SyncCtorB0a`)
- `c12SyncStep_decomp` (`CG07_SyncCtorB0`)
- `c12_evalUpdate_unpack`, `c12_lasVegas_dpos_of_step_sim` (`CG07_SyncCtorB1`)
- `c12_lasVegas_of_step_sim` and `IsBoundedByPoly3` combinators (`CG07_SyncCtorB`)
-/
