import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H4b1a_BufAndStepA
set_option autoImplicit false
set_option maxHeartbeats 800000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Mathematical Lemmas for Step B: Leaf-Count Read, Intact Blocks, and Deletion Survival -/

theorem TreeStoredAt.read_leaf_cnt {L tid h : ℕ} {S : Finset ℕ} {rNum rDen : ℕ → ℤ} {ws : WordStore}
    (hwf : WellFormedWS ws) (ht : TreeStoredAt L tid S rNum rDen ws) (hh : h < 2 ^ L) :
    ws.read (.heap 2 (treeCellAddr L tid (treeIdx L 0 h) 0)) = if h ∈ S then 1 else 0 := by
  have hoff : h < 2 ^ (L - 0) := by simpa using hh
  have hn := ht.nodes 0 (Nat.zero_le L) h hoff
  by_cases hmem : h ∈ S
  · have hv : treeNodeVal S rNum rDen 0 h = (1, h, rNum h, rDen h) := by simp [treeNodeVal, hmem]
    rw [hv] at hn
    obtain ⟨_, hval, _⟩ := hn.2 (by simp)
    rw [if_pos hmem, wordStore_read_eq_vals hwf]; simpa using hval
  · have hv : treeNodeVal S rNum rDen 0 h = (0, 0, 0, 0) := by simp [treeNodeVal, hmem]
    rw [hv] at hn
    have hnl := hn.1 rfl 0 (by decide)
    rw [if_neg hmem, wordStore_read_eq_vals hwf, hwf _ hnl]

noncomputable def intactBlocksOf {d s₀_d : ℕ}
    (v : SyncLiveChainNode d (PosDimNodeData d s₀_d))
    (P : DynamicPointSet d) : Finset ℕ :=
  (Finset.univ.filter (fun b : Fin v.built.aux.k_blk =>
    ∀ t : Fin s₀_d, v.built.aux.birthLifetimes b t ∈ activeLifetimes P)).image Fin.val

theorem intactBlocksOf_insert_eq {d s₀_d n : ℕ}
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)}
    {P P' : DynamicPointSet d} (hwf : P.WellFormed n) (hwf' : P'.WellFormed n)
    {id : ℕ} {extName : List Bool} {pt : EuclideanSpace ℝ (Fin d)} {hNew : ℕ}
    (happ : applyDynamicUpdate P (.insert id extName pt) (some hNew) = some P')
    (hblt_lt : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
      v.built.aux.birthLifetimes b t < P.nextLifetime) :
    intactBlocksOf v P' = intactBlocksOf v P := by
  have hact := (activeLifetimes_insert_spec hwf hwf' happ).2.1
  unfold intactBlocksOf
  congr 1
  ext b
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, hact, Finset.mem_insert]
  refine forall_congr' (fun t => ?_)
  have hne : v.built.aux.birthLifetimes b t ≠ P.nextLifetime := Nat.ne_of_lt (hblt_lt b t)
  simp [hne]

theorem intactBlocksOf_delete_owner {d s₀_d n : ℕ}
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)}
    {P P' : DynamicPointSet d} (hwf : P.WellFormed n) (hwf' : P'.WellFormed n)
    {id : ℕ} (happ : applyDynamicUpdate P (.delete id) none = some P')
    (hblt_inj : Function.Injective2 v.built.aux.birthLifetimes)
    (hbh_sync : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
      v.built.aux.birthLifetimes b t ∈ activeLifetimes P →
        handleOfLifetime P (v.built.aux.birthLifetimes b t) = v.built.aux.birthHandles b t)
    {b₀ : Fin v.built.aux.k_blk} {t₀ : Fin s₀_d}
    (hact₀ : v.built.aux.birthLifetimes b₀ t₀ ∈ activeLifetimes P)
    (hbh₀ : v.built.aux.birthHandles b₀ t₀ = P.handleOfId id) :
    v.built.aux.birthLifetimes b₀ t₀ = P.lifetimeOfId id ∧
    intactBlocksOf v P' = (intactBlocksOf v P).erase b₀.val := by
  obtain ⟨hdel_mem, hact_eq, _, hh_del, _⟩ := activeLifetimes_delete_spec hwf hwf' happ
  have hlt_eq : v.built.aux.birthLifetimes b₀ t₀ = P.lifetimeOfId id := by
    apply handleOfLifetime_injOn hwf hact₀ hdel_mem
    rw [hbh_sync b₀ t₀ hact₀, hbh₀, hh_del]
  refine ⟨hlt_eq, ?_⟩
  ext bv
  simp only [intactBlocksOf, Finset.mem_erase, Finset.mem_image, Finset.mem_filter, Finset.mem_univ, true_and]
  constructor
  · rintro ⟨b, hall', rfl⟩
    refine ⟨?_, b, fun t => ?_, rfl⟩
    · intro hval_eq
      have hb_eq : b = b₀ := Fin.ext hval_eq
      subst hb_eq
      have hm := hall' t₀
      rw [hact_eq, hlt_eq] at hm
      exact (Finset.mem_erase.mp hm).1 rfl
    · have hm := hall' t
      rw [hact_eq] at hm
      exact Finset.mem_of_mem_erase hm
  · rintro ⟨hb_ne, b, hall, rfl⟩
    refine ⟨b, fun t => ?_, rfl⟩
    rw [hact_eq, Finset.mem_erase]
    refine ⟨?_, hall t⟩
    intro heq
    rw [← hlt_eq] at heq
    exact hb_ne (congrArg Fin.val (hblt_inj heq).1)

theorem intactBlocksOf_delete_none {d s₀_d n : ℕ}
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)}
    {P P' : DynamicPointSet d} (hwf : P.WellFormed n) (hwf' : P'.WellFormed n)
    {id : ℕ} (happ : applyDynamicUpdate P (.delete id) none = some P')
    (hbh_sync : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
      v.built.aux.birthLifetimes b t ∈ activeLifetimes P →
        handleOfLifetime P (v.built.aux.birthLifetimes b t) = v.built.aux.birthHandles b t)
    (hnone : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
      v.built.aux.birthHandles b t = P.handleOfId id →
        v.built.aux.birthLifetimes b t ∉ activeLifetimes P) :
    intactBlocksOf v P' = intactBlocksOf v P := by
  obtain ⟨_, hact_eq, _, hh_del, _⟩ := activeLifetimes_delete_spec hwf hwf' happ
  unfold intactBlocksOf
  congr 1
  ext b
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, hact_eq, Finset.mem_erase]
  refine forall_congr' (fun t => ?_)
  constructor
  · exact fun h => h.2
  · intro hact
    refine ⟨?_, hact⟩
    intro heq
    have hbh_eq : v.built.aux.birthHandles b t = P.handleOfId id := by
      rw [← hbh_sync b t hact, heq, hh_del]
    exact hnone b t hbh_eq hact

theorem intactBlocksOf_nonempty_of_age_le
    (h_del_wit : S_claim_A_2_deletion_witness)
    {d s₀_d B : ℕ} (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d)
    {P' : DynamicPointSet d} {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)}
    {S_new_j : Finset ℕ}
    (hSubAct : S_new_j ⊆ activeLifetimes P')
    (hm_lo : 2 * s₀_d ≤ v.birthPool.card)
    (hbirth_adm : ∀ lt ∈ v.birthPool, ltCoords' lt ∈ RatAdmissiblePointSet d B)
    (hk_ratio : (v.birthPool.card : ℝ) / (4 * (s₀_d : ℝ)) ≤ (v.built.aux.k_blk : ℝ))
    (hblt_inj : Function.Injective2 v.built.aux.birthLifetimes)
    (hcerts : ∀ b : Fin v.built.aux.k_blk,
      IsBlockCertificate ltCoords' v.birthPool (liftedPoint v.built.node.o v.built.s)
        (Finset.univ.image (v.built.aux.birthLifetimes b))
        (fun lt => ∑ t : Fin s₀_d, if v.built.aux.birthLifetimes b t = lt then (v.built.aux.lam b t : ℝ) else 0))
    (hage_rel : HasNodeAge v.birthPool S_new_j v.ageUpdateSteps.card)
    (hage_le : (v.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (v.birthPool.card : ℝ) / 16) :
    (intactBlocksOf v P').Nonempty := by
  classical
  have hrat : ∀ p ∈ v.birthPool, ∃ q : Fin d → ℚ, ratPointToEuclidean q = ltCoords' p := by
    intro p hp
    rcases hbirth_adm p hp with ⟨q, _, hq⟩
    exact ⟨q, hq⟩
  let certs : Fin v.built.aux.k_blk → BlockCertificate ltCoords' v.birthPool (liftedPoint v.built.node.o v.built.s) :=
    fun b =>
      { B := Finset.univ.image (v.built.aux.birthLifetimes b)
        coeff := fun lt => ∑ t : Fin s₀_d, if v.built.aux.birthLifetimes b t = lt then (v.built.aux.lam b t : ℝ) else 0
        subset_birth := (hcerts b).1
        coeff_nonneg := (hcerts b).2.1
        sum_coeff := (hcerts b).2.2.1
        sum_lift := (hcerts b).2.2.2 }
  have hcard_c : ∀ b : Fin v.built.aux.k_blk, (certs b).B.card = s₀_d := by
    intro b
    dsimp [certs]
    rw [Finset.card_image_of_injective Finset.univ (fun t₁ t₂ heq => (hblt_inj (a₁ := b) (a₂ := b) heq).2)]
    simp
  have hdisj_c : ∀ b₁ b₂ : Fin v.built.aux.k_blk, b₁ ≠ b₂ → Disjoint (certs b₁).B (certs b₂).B := by
    intro b₁ b₂ hne
    rw [Finset.disjoint_left]
    intro lt h1 h2
    simp only [certs, Finset.mem_image, Finset.mem_univ, true_and] at h1 h2
    rcases h1 with ⟨t₁, rfl⟩
    rcases h2 with ⟨t₂, heq⟩
    exact hne (hblt_inj heq.symm).1
  have hdw := h_del_wit d hd1 s₀_d hs₀1 ℕ ltCoords' v.birthPool hm_lo hrat
    v.built.node.o v.built.s v.built.aux.k_blk hk_ratio certs hcard_c hdisj_c
  rcases hage_rel with ⟨seq, h0, hlast, hchg⟩
  have hsurv := hdw.2.2.2.2.1 v.ageUpdateSteps.card seq hage_le h0 hchg
  have hpos_lhs : (0 : ℝ) < 15 * (1 / (4 * (s₀_d : ℝ))) * (v.birthPool.card : ℝ) / 16 := by
    have hs_pos : (0 : ℝ) < (s₀_d : ℝ) := by exact_mod_cast (by clear * - hs₀1; omega : 0 < s₀_d)
    have hm_pos : (0 : ℝ) < (v.birthPool.card : ℝ) := by exact_mod_cast (by clear * - hm_lo hs₀1; omega : 0 < v.birthPool.card)
    positivity
  have hcard_pos_r : (0 : ℝ) < ((Finset.univ.filter (fun b : Fin v.built.aux.k_blk =>
      ∀ t : Fin (v.ageUpdateSteps.card + 1), (certs b).IsIntact (seq t))).card : ℝ) :=
    lt_of_lt_of_le hpos_lhs hsurv
  have hcard_pos : 0 < (Finset.univ.filter (fun b : Fin v.built.aux.k_blk =>
      ∀ t : Fin (v.ageUpdateSteps.card + 1), (certs b).IsIntact (seq t))).card := by
    exact_mod_cast hcard_pos_r
  rcases Finset.card_pos.mp hcard_pos with ⟨b₀, hb₀⟩
  simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hb₀
  have hint_last := hb₀ (Fin.last v.ageUpdateSteps.card)
  rw [hlast] at hint_last
  refine ⟨b₀.val, Finset.mem_image.mpr ⟨b₀, ?_, rfl⟩⟩
  simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  intro t
  have hmemB : v.built.aux.birthLifetimes b₀ t ∈ (certs b₀).B :=
    Finset.mem_image.mpr ⟨t, Finset.mem_univ t, rfl⟩
  exact hSubAct (hint_last hmemB)

theorem age_trigger_iff_nat {s₀_d m age : ℕ} (hs₀1 : 1 ≤ s₀_d) :
    (1 / (4 * (s₀_d : ℝ))) * (m : ℝ) / 16 < (age : ℝ) ↔
      (m : ℤ) < ((64 * s₀_d : ℕ) : ℤ) * (age : ℤ) := by
  have hs_pos : (0 : ℝ) < (s₀_d : ℝ) := by exact_mod_cast (by clear * - hs₀1; omega : 0 < s₀_d)
  have h64_pos : (0 : ℝ) < 64 * (s₀_d : ℝ) := by positivity
  have hmul : (1 / (4 * (s₀_d : ℝ))) * (m : ℝ) / 16 = (m : ℝ) / (64 * (s₀_d : ℝ)) := by
    field_simp [ne_of_gt hs_pos]; ring
  rw [hmul, div_lt_iff₀ h64_pos]
  have hr : (age : ℝ) * (64 * (s₀_d : ℝ)) = ((((64 * s₀_d : ℕ) : ℤ) * (age : ℤ) : ℤ) : ℝ) := by
    push_cast; ring
  rw [hr]
  exact_mod_cast Iff.rfl

/-! ### 2. `PreTriggerLevelInv`: Per-Level Invariant Immediately After Step B -/

structure PreTriggerLevelInv {d s₀_d : ℕ} (n L B B_cert K_max : ℕ)
    (P : DynamicPointSet d) (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (qMap : ℕ → Fin d → ℚ)
    (S_lt : Finset ℕ)
    (v : SyncLiveChainNode d (PosDimNodeData d s₀_d))
    (j : ℕ) (ws : WordStore) : Prop where
  hj_le : j ≤ K_max
  hm_bounds : 2 * s₀_d ≤ v.birthPool.card ∧ v.birthPool.card ≤ n
  hage_rel : HasNodeAge v.birthPool S_lt v.ageUpdateSteps.card
  hnode_o : v.built.node.o = ratPointToEuclidean v.built.aux.oRat
  hnode_s : v.built.s = (v.built.aux.sRat : ℝ)
  hnode_V : v.built.node.V = liftVariance v.built.node.o v.built.s
  hcp : IsCenterpoint (1 / (4 * (s₀_d : ℝ)))
          (paraboloidLiftSet (fun x : v.birthPool => ltCoords x.1))
          (liftedPoint v.built.node.o v.built.s)
  hk_bounds : 1 ≤ v.built.aux.k_blk ∧ v.built.aux.k_blk * s₀_d ≤ v.birthPool.card
  hk_ratio : (v.birthPool.card : ℝ) / (4 * (s₀_d : ℝ)) ≤ (v.built.aux.k_blk : ℝ)
  hbirth_adm : ∀ lt ∈ v.birthPool, lt < P.nextLifetime ∧ ltCoords lt ∈ RatAdmissiblePointSet d B
  hgeom : NodeGeomStored d (posNodeStride d L) B_cert j
            v.built.aux.oRat v.built.aux.V_num v.built.aux.V_den v.built.node.V ws
  read_age : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) = (v.ageUpdateSteps.card : ℤ)
  read_mbirth : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 1)) = (v.birthPool.card : ℤ)
  read_kblk : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (v.built.aux.k_blk : ℤ)
  hbh_lt : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d), v.built.aux.birthHandles b t < 2 ^ L
  hbh_inj : Function.Injective2 v.built.aux.birthHandles
  hblt_mem : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
    v.built.aux.birthLifetimes b t ∈ v.birthPool ∧
    v.built.aux.birthLifetimes b t < P.nextLifetime
  hblt_inj : Function.Injective2 v.built.aux.birthLifetimes
  hbh_active_sync : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
    v.built.aux.birthLifetimes b t ∈ activeLifetimes P →
      handleOfLifetime P (v.built.aux.birthLifetimes b t) = v.built.aux.birthHandles b t
  read_bh : ∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
    ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b.val * s₀_d + t.val)))) =
      (v.built.aux.birthHandles b t : ℤ)
  unused_tab3 : ∀ off : ℕ, 6 + 2 * d + v.built.aux.k_blk * s₀_d ≤ off → off < posNodeStride d L →
    (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ ws.live
  hcerts : ∀ b : Fin v.built.aux.k_blk,
    IsBlockCertificate ltCoords v.birthPool (liftedPoint v.built.node.o v.built.s)
      (Finset.univ.image (v.built.aux.birthLifetimes b))
      (fun lt => ∑ t : Fin s₀_d, if v.built.aux.birthLifetimes b t = lt then (v.built.aux.lam b t : ℝ) else 0)
  tree_Sj : ∃ (rNum rDen : ℕ → ℤ),
    TreeStoredAt L (2 * j + 2) (S_lt.image (handleOfLifetime P)) rNum rDen ws ∧
    (∀ h ∈ S_lt.image (handleOfLifetime P),
      1 ≤ rDen h ∧
      ((rNum h : ℝ) / (rDen h : ℝ)) = ‖ratPointToEuclidean (qMap h) - v.built.node.o‖ ^ 2 ∧
      intBitLength (rNum h) ≤ sqRadBitBound d B B_cert ∧
      intBitLength (rDen h) ≤ sqRadBitBound d B B_cert)
  tab4_spec : ∀ h < 2 ^ L,
    (∃ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
      v.built.aux.birthLifetimes b t ∈ activeLifetimes P ∧
      v.built.aux.birthHandles b t = h ∧
      (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ ws.live ∧
      ws.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) = ((b.val + 1 : ℕ) : ℤ)) ∨
    ((∀ (b : Fin v.built.aux.k_blk) (t : Fin s₀_d),
        v.built.aux.birthHandles b t = h → v.built.aux.birthLifetimes b t ∉ activeLifetimes P) ∧
      (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ ws.live)
  tree_intact_raw : TreeStoredAt L (2 * j + 3) (intactBlocksOf v P) (fun _ => 0) (fun _ => 1) ws

theorem LevelStoredInv.toPreTrigger {d s₀_d n L B B_cert K_max : ℕ}
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {qMap : ℕ → Fin d → ℚ} {S_lt : Finset ℕ}
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)} {j : ℕ} {ws : WordStore}
    (h : LevelStoredInv n L B B_cert K_max P ltCoords qMap S_lt v j ws) :
    PreTriggerLevelInv n L B B_cert K_max P ltCoords qMap S_lt v j ws :=
  { hj_le := h.hj_le
    hm_bounds := h.hm_bounds
    hage_rel := h.hage_rel
    hnode_o := h.hnode_o
    hnode_s := h.hnode_s
    hnode_V := h.hnode_V
    hcp := h.hcp
    hk_bounds := h.hk_bounds
    hk_ratio := h.hk_ratio
    hbirth_adm := h.hbirth_adm
    hgeom := h.hgeom
    read_age := h.read_age
    read_mbirth := h.read_mbirth
    read_kblk := h.read_kblk
    hbh_lt := h.hbh_lt
    hbh_inj := h.hbh_inj
    hblt_mem := h.hblt_mem
    hblt_inj := h.hblt_inj
    hbh_active_sync := h.hbh_active_sync
    read_bh := h.read_bh
    unused_tab3 := h.unused_tab3
    hcerts := h.hcerts
    tree_Sj := h.tree_Sj
    tab4_spec := h.tab4_spec
    tree_intact_raw := h.tree_intact.2 }

theorem PreTriggerLevelInv.toLevelStoredInv
    (h_del_wit : S_claim_A_2_deletion_witness)
    {d s₀_d n L B B_cert K_max : ℕ} (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d)
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {qMap : ℕ → Fin d → ℚ} {S_lt : Finset ℕ}
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)} {j : ℕ} {ws : WordStore}
    (hpre : PreTriggerLevelInv n L B B_cert K_max P ltCoords qMap S_lt v j ws)
    (hSubAct : S_lt ⊆ activeLifetimes P)
    (hage_le : (v.ageUpdateSteps.card : ℝ) ≤ (1 / (4 * (s₀_d : ℝ))) * (v.birthPool.card : ℝ) / 16) :
    LevelStoredInv n L B B_cert K_max P ltCoords qMap S_lt v j ws :=
  { hj_le := hpre.hj_le
    hm_bounds := hpre.hm_bounds
    hage_le := hage_le
    hage_rel := hpre.hage_rel
    hnode_o := hpre.hnode_o
    hnode_s := hpre.hnode_s
    hnode_V := hpre.hnode_V
    hcp := hpre.hcp
    hk_bounds := hpre.hk_bounds
    hk_ratio := hpre.hk_ratio
    hbirth_adm := hpre.hbirth_adm
    hgeom := hpre.hgeom
    read_age := hpre.read_age
    read_mbirth := hpre.read_mbirth
    read_kblk := hpre.read_kblk
    hbh_lt := hpre.hbh_lt
    hbh_inj := hpre.hbh_inj
    hblt_mem := hpre.hblt_mem
    hblt_inj := hpre.hblt_inj
    hbh_active_sync := hpre.hbh_active_sync
    read_bh := hpre.read_bh
    unused_tab3 := hpre.unused_tab3
    hcerts := hpre.hcerts
    tree_Sj := hpre.tree_Sj
    tab4_spec := hpre.tab4_spec
    tree_intact := ⟨intactBlocksOf_nonempty_of_age_le h_del_wit hd1 hs₀1 hSubAct
                      hpre.hm_bounds.1 (fun lt hlt => (hpre.hbirth_adm lt hlt).2) hpre.hk_ratio hpre.hblt_inj
                      hpre.hcerts hpre.hage_rel hage_le,
                    hpre.tree_intact_raw⟩ }

theorem PreTriggerLevelInv.unchanged {d s₀_d n L B B_cert K_max : ℕ}
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {qMap : ℕ → Fin d → ℚ} {S_lt : Finset ℕ}
    {v : SyncLiveChainNode d (PosDimNodeData d s₀_d)} {j : ℕ} {ws₁ ws₂ : WordStore}
    (hwf₁ : WellFormedWS ws₁) (hwf₂ : WellFormedWS ws₂)
    (h : PreTriggerLevelInv n L B B_cert K_max P ltCoords qMap S_lt v j ws₁)
    (htab3 : ∀ off < posNodeStride d L,
      ((.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
        ws₁.vals (.heap 3 (nodeCellAddr (posNodeStride d L) j off)))
    (htab4 : ∀ h' < 2 ^ L,
      ((.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ)) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ))) =
        ws₁.vals (.heap 4 (((j * 2 ^ L + h' : ℕ) : ℤ))))
    (htree2 : ∀ u < 2 ^ (L + 1), ∀ f < 4,
      ((.heap 2 (treeCellAddr L (2 * j + 2) u f) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 2 (treeCellAddr L (2 * j + 2) u f) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 2 (treeCellAddr L (2 * j + 2) u f)) =
        ws₁.vals (.heap 2 (treeCellAddr L (2 * j + 2) u f)))
    (htree3 : ∀ u < 2 ^ (L + 1), ∀ f < 4,
      ((.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 2 (treeCellAddr L (2 * j + 3) u f) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 2 (treeCellAddr L (2 * j + 3) u f)) =
        ws₁.vals (.heap 2 (treeCellAddr L (2 * j + 3) u f))) :
    PreTriggerLevelInv n L B B_cert K_max P ltCoords qMap S_lt v j ws₂ := by
  have hread3 : ∀ off < posNodeStride d L,
      ws₂.read (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) =
        ws₁.read (.heap 3 (nodeCellAddr (posNodeStride d L) j off)) := by
    intro off hoff
    rw [wordStore_read_eq_vals hwf₂, (htab3 off hoff).2, ← wordStore_read_eq_vals hwf₁]
  have hstride_ge : 6 + 2 * d < posNodeStride d L := by
    unfold posNodeStride; have : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide); omega
  rcases h.tree_Sj with ⟨rNum, rDen, htSj, hbSj⟩
  refine
    { hj_le := h.hj_le
      hm_bounds := h.hm_bounds
      hage_rel := h.hage_rel
      hnode_o := h.hnode_o
      hnode_s := h.hnode_s
      hnode_V := h.hnode_V
      hcp := h.hcp
      hk_bounds := h.hk_bounds
      hk_ratio := h.hk_ratio
      hbirth_adm := h.hbirth_adm
      hgeom := h.hgeom.unchanged (fun off hoff => hread3 off (lt_trans hoff hstride_ge))
      read_age := (hread3 0 (by omega)).trans h.read_age
      read_mbirth := (hread3 1 (by omega)).trans h.read_mbirth
      read_kblk := (hread3 2 (by omega)).trans h.read_kblk
      hbh_lt := h.hbh_lt
      hbh_inj := h.hbh_inj
      hblt_mem := h.hblt_mem
      hblt_inj := h.hblt_inj
      hbh_active_sync := h.hbh_active_sync
      read_bh := fun b t => by
        have h1 : b.val * s₀_d + t.val < v.built.aux.k_blk * s₀_d := by
          have hm : (b.val + 1) * s₀_d ≤ v.built.aux.k_blk * s₀_d := Nat.mul_le_mul_right _ (by omega)
          have ha : b.val * s₀_d + t.val < (b.val + 1) * s₀_d := by
            rw [add_mul, one_mul]; exact Nat.add_lt_add_left t.isLt _
          exact lt_of_lt_of_le ha hm
        have hcard_bh : v.built.aux.k_blk * s₀_d ≤ 2 ^ L := by
          let f : Fin v.built.aux.k_blk × Fin s₀_d → Fin (2 ^ L) :=
            fun p => ⟨v.built.aux.birthHandles p.1 p.2, h.hbh_lt p.1 p.2⟩
          have hinj : Function.Injective f := by
            intro p₁ p₂ heq
            have hv : v.built.aux.birthHandles p₁.1 p₁.2 = v.built.aux.birthHandles p₂.1 p₂.2 :=
              congrArg Fin.val heq
            rcases h.hbh_inj hv with ⟨e1, e2⟩
            exact Prod.ext e1 e2
          have hc := Fintype.card_le_of_injective f hinj
          simpa using hc
        have hoff : 6 + 2 * d + (b.val * s₀_d + t.val) < posNodeStride d L := by
          unfold posNodeStride; clear * - h1 hcard_bh; omega
        exact (hread3 _ hoff).trans (h.read_bh b t)
      unused_tab3 := fun off hlo hhi hm => h.unused_tab3 off hlo hhi ((htab3 off hhi).1.mp hm)
      hcerts := h.hcerts
      tree_Sj := ⟨rNum, rDen, htSj.unchanged htree2, hbSj⟩
      tab4_spec := fun h' hh' => by
        rcases h.tab4_spec h' hh' with ⟨b, t, hact, hbh, hlive, hval⟩ | ⟨hno, hnlive⟩
        · exact Or.inl ⟨b, t, hact, hbh, (htab4 h' hh').1.mpr hlive, (htab4 h' hh').2.trans hval⟩
        · exact Or.inr ⟨hno, fun hm => hnlive ((htab4 h' hh').1.mp hm)⟩
      tree_intact_raw := h.tree_intact_raw.unchanged htree3 }

/-! ### 3. Named Sub-Statements and Modular Execution Proofs for Step B -/

def incrNodeAgeStmt (nodeStride : ℕ) : BitRAMStmt :=
  .seq (rLit 8 (nodeStride : ℤ))
  (.seq (rMul 8 7 8)
  (.seq (rLoad 9 3 8)
  (.seq (rLit 14 1)
  (.seq (rAdd 9 9 14)
        (rStore 3 8 9)))))

def updateJStarIfLtStmt : BitRAMStmt :=
  .ite (.intLt (.readLocal 7 (.lit 0)) (.readLocal 13 (.lit 0)))
    (rStore 9 10 7)
    .skip

def maybeUpdateJStarStmt : BitRAMStmt :=
  .seq (rLit 10 106)
  (.seq (rLoad 13 9 10)
        updateJStarIfLtStmt)

def checkLevelTriggerStmt (s₀_d nodeStride : ℕ) : BitRAMStmt :=
  .seq (rLit 8 (nodeStride : ℤ))
  (.seq (rMul 8 7 8)
  (.seq (rLoad 9 3 8)
  (.seq (rLit 14 1)
  (.seq (rAdd 8 8 14)
  (.seq (rLoad 11 3 8)
  (.seq (rLit 12 (((64 * s₀_d : ℕ) : ℤ)))
  (.seq (rMul 9 12 9)
  (.seq (.ite (.intLt (.readLocal 11 (.lit 0)) (.readLocal 9 (.lit 0)))
          maybeUpdateJStarStmt
          .skip)
  (.seq (rLit 10 104)
  (.seq (rLit 14 1)
  (.seq (rAdd 7 7 14)
        (rStore 9 10 7))))))))))))

def posDimStepBInsAlive (d L : ℕ) : BitRAMStmt :=
  let nodeStride := posNodeStride d L
  .seq (rCopy 0 7) (.seq (rCopy 1 6)
  (.seq (sqRadAndCoreRegs d nodeStride)
  (.seq (rLit 10 105) (.seq (rStore 9 10 2)
  (.seq (rLit 10 104) (.seq (rLoad 7 9 10)
  (.seq (rLit 10 103) (.seq (rLoad 6 9 10)
  (.seq (rLit 14 2) (.seq (rMul 0 7 14) (.seq (rAdd 0 0 14)
  (.seq (rCopy 1 6) (.seq (rLit 2 1)
  (.seq (treeSetLeafRegs L)
  (.seq (rLit 10 104) (.seq (rLoad 7 9 10)
        (incrNodeAgeStmt nodeStride)))))))))))))))))

def posDimStepBIns (d L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 105) (.seq (rLoad 8 9 10)
  (.seq (rLit 14 1)
        (.ite (.intEq (.readLocal 8 (.lit 0)) (.readLocal 14 (.lit 0)))
          (posDimStepBInsAlive d L)
          .skip)))

def posDimStepBDelOwTrue (L : ℕ) : BitRAMStmt :=
  .seq (rFree 4 8)
  (.seq (rSub 1 9 14)
  (.seq (rLit 14 2) (.seq (rMul 0 7 14) (.seq (rLit 14 3) (.seq (rAdd 0 0 14)
  (.seq (rLit 2 0) (.seq (rLit 3 0) (.seq (rLit 4 0)
        (treeSetLeafRegs L)))))))))

def posDimStepBDelTab4 (L : ℕ) : BitRAMStmt :=
  .seq (rLit 8 ((2 ^ L : ℕ) : ℤ))
  (.seq (rMul 8 7 8)
  (.seq (rAdd 8 8 6)
  (.seq (rLoad 9 4 8)
  (.seq (rLit 14 1)
        (.ite (.intLe (.readLocal 14 (.lit 0)) (.readLocal 9 (.lit 0)))
          (posDimStepBDelOwTrue L)
          .skip)))))

def posDimStepBDelSjTrue (d L : ℕ) : BitRAMStmt :=
  .seq (rCopy 1 6) (.seq (rLit 2 0) (.seq (rLit 3 0) (.seq (rLit 4 0)
  (.seq (treeSetLeafRegs L)
  (.seq (rLit 10 104) (.seq (rLoad 7 9 10)
        (incrNodeAgeStmt (posNodeStride d L))))))))

def posDimStepBDelSj (d L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 104) (.seq (rLoad 7 9 10)
  (.seq (rLit 10 103) (.seq (rLoad 6 9 10)
  (.seq (rLit 14 2) (.seq (rMul 0 7 14) (.seq (rAdd 0 0 14)
  (.seq (rLit 8 ((2 ^ (L + 1) : ℕ) : ℤ)) (.seq (rMul 8 0 8)
  (.seq (rLit 9 ((2 ^ L : ℕ) : ℤ)) (.seq (rAdd 9 9 6)
  (.seq (rAdd 8 8 9) (.seq (rLit 14 4) (.seq (rMul 8 8 14)
  (.seq (rLoad 9 2 8)
  (.seq (rLit 14 1)
        (.ite (.intEq (.readLocal 9 (.lit 0)) (.readLocal 14 (.lit 0)))
          (posDimStepBDelSjTrue d L)
          .skip))))))))))))))))

def posDimStepBDel (d L : ℕ) : BitRAMStmt :=
  .seq (posDimStepBDelTab4 L) (posDimStepBDelSj d L)

def posDimStepBLevel (d s₀_d L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 102) (.seq (rLoad 5 9 10)
  (.seq (rLit 10 103) (.seq (rLoad 6 9 10)
  (.seq (rLit 10 104) (.seq (rLoad 7 9 10)
  (.seq (rLit 14 1)
  (.seq (.ite (.intEq (.readLocal 5 (.lit 0)) (.readLocal 14 (.lit 0)))
          (posDimStepBIns d L)
          (posDimStepBDel d L))
  (.seq (rLit 10 104) (.seq (rLoad 7 9 10)
        (checkLevelTriggerStmt s₀_d (posNodeStride d L)))))))))))

def posDimStepBLeafInsAlive (L : ℕ) : BitRAMStmt :=
  .seq (rLit 0 1) (.seq (rCopy 1 6) (.seq (rLit 2 1)
  (.seq (rLit 3 0) (.seq (rLit 4 1) (treeSetLeafRegs L)))))

def posDimStepBLeafIns (L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 105) (.seq (rLoad 8 9 10)
  (.seq (rLit 14 1)
        (.ite (.intEq (.readLocal 8 (.lit 0)) (.readLocal 14 (.lit 0)))
          (posDimStepBLeafInsAlive L)
          .skip)))

def posDimStepBLeafDel (L : ℕ) : BitRAMStmt :=
  .seq (rLit 0 1) (.seq (rCopy 1 6) (.seq (rLit 2 0)
  (.seq (rLit 3 0) (.seq (rLit 4 0) (treeSetLeafRegs L)))))

def posDimStepBLeafTrigTrue : BitRAMStmt :=
  .seq (rLit 10 10) (.seq (rLoad 7 0 10)
        maybeUpdateJStarStmt)

def posDimStepB (d s₀_d L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 10) (.seq (rLoad 5 0 10)
  (.seq (rLit 10 104) (.seq (rLit 13 0) (.seq (rStore 9 10 13)
  (.seq (rLit 10 105) (.seq (rLit 13 1) (.seq (rStore 9 10 13)
  (.seq (rLit 14 1) (.seq (rAdd 13 5 14)
  (.seq (rLit 10 106) (.seq (rStore 9 10 13)
  (.seq (.repeatN (.readLocal 5 (.lit 0)) (posDimStepBLevel d s₀_d L))
  (.seq (rLit 10 102) (.seq (rLoad 5 9 10)
  (.seq (rLit 10 103) (.seq (rLoad 6 9 10)
  (.seq (rLit 14 1)
  (.seq (.ite (.intEq (.readLocal 5 (.lit 0)) (.readLocal 14 (.lit 0)))
          (posDimStepBLeafIns L)
          (posDimStepBLeafDel L))
  (.seq (rLit 0 1)
  (.seq (treeReadRootRegs L)
  (.seq (rLit 12 (((2 * (2 * s₀_d - 1) : ℕ) : ℤ)))
        (.ite (.intLt (.readLocal 12 (.lit 0)) (.readLocal 1 (.lit 0)))
          posDimStepBLeafTrigTrue
          .skip))))))))))))))))))))))

theorem exec_incrNodeAgeStmt {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L K_max j age : ℕ} (hj : j ≤ K_max) (hage_lt : age < 2 ^ L)
    (hW : natBitLength ((K_max + 2) * posNodeStride d L) + L + 20 ≤ W)
    (hSub0 : (.heap 3 (nodeCellAddr (posNodeStride d L) j 0) : RAMCellLoc) ∈ S_write)
    (hr_age : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) = (age : ℤ))
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) (hr7 : regs 7 = (j : ℤ)) :
    let wsEnd := ws.write (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) ((age + 1 : ℕ) : ℤ)
    ∃ regsEnd,
      RegExec inp fd W C_cell C_bit (incrNodeAgeStmt (posNodeStride d L)) ws regs wsEnd regsEnd
        60 (12 * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd := by
  intro wsEnd
  have hW20 : 20 ≤ W := by clear * - hW; omega
  set ns := posNodeStride d L
  have hns_pos : 1 ≤ ns := by unfold ns posNodeStride; omega
  have hns_le : ns ≤ (K_max + 2) * ns := Nat.le_mul_of_pos_left _ (by omega)
  have hns_bl : intBitLength (ns : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le ns
    have h2 := natBitLength_mono hns_le
    clear * - h1 h2 hW; omega
  have ⟨hloc0, haddr0_bl⟩ := nodeCellAddr_bl (W := W) (nodeStride := ns) (K_max := K_max) (j := j) (off := 0)
    (by omega) hns_pos (by clear * - hW; omega)
  have hage_bl : intBitLength (age : ℤ) ≤ W :=
    (nat_lt_pow2_bitLength_le hage_lt).trans (by clear * - hW; omega)
  have hage1_bl : intBitLength ((age + 1 : ℕ) : ℤ) ≤ W := by
    have hp : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
    have : age + 1 < 2 ^ (L + 1) := by rw [pow_succ]; clear * - hage_lt hp; omega
    exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hn3 : natBitLength 3 ≤ W := by have : natBitLength 3 = 2 := (by decide); omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := (ns : ℤ)) (by decide) hns_bl
  set g1 := Function.update regs 8 (ns : ℤ); have bg1 := hbnd.update (r := 8) (by decide) hns_bl
  have hmul_eq : g1 7 * g1 8 = nodeCellAddr ns j 0 := by simp [g1, hr7, nodeCellAddr]
  have s2 := RegExec.mul (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (a := 7) (b := 8)
    (by decide) (by decide) (by decide) (by rw [hmul_eq]; exact haddr0_bl)
  rw [hmul_eq] at s2; set g2 := Function.update g1 8 (nodeCellAddr ns j 0); have bg2 := bg1.update (r := 8) (by decide) haddr0_bl
  have hg2_r : ws.read (.heap 3 (g2 8)) = (age : ℤ) := by simp only [g2, Function.update_self]; exact hr_age
  have s3 := RegExec.load (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 9) (table := 3) (addr := 8)
    (by decide) (by decide) hn3 (by rw [hg2_r]; exact hage_bl)
  rw [hg2_r] at s3; set g3 := Function.update g2 9 (age : ℤ); have bg3 := bg2.update (r := 9) (by decide) hage_bl
  have s4 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
  set g4 := Function.update g3 14 1; have bg4 := bg3.update (r := 14) (by decide) hl1
  have hadd_eq : g4 9 + g4 14 = ((age + 1 : ℕ) : ℤ) := by simp [g4, g3]
  have s5 := RegExec.add (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 9) (a := 9) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hadd_eq]; exact hage1_bl)
  rw [hadd_eq] at s5; set g5 := Function.update g4 9 ((age + 1 : ℕ) : ℤ); have bg5 := bg4.update (r := 9) (by decide) hage1_bl
  have hm_End : ModifiedOnBounded ws₀ S_write W (ws.write (.heap 3 (g5 8)) (g5 9)) := by
    simpa [g5, g4, g3, g2] using hmod.write hSub0 ((age + 1 : ℕ) : ℤ) hloc0 hage1_bl
  have s6 := RegExec.store (inp := inp) hfd_le bg5 (table := 3) (addr := 8) (val := 9) (by decide) (by decide) hn3
    (sp_ok hm_End).1 (sp_ok hm_End).2
  have hwE : ws.write (.heap 3 (g5 8)) (g5 9) = wsEnd := by simp [wsEnd, ns, g5, g4, g3, g2]
  rw [hwE] at s6 hm_End
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq s6))))).weaken rfl rfl
    (u₂ := 60) (b₂ := 12 * W * W) (by decide) (by nlinarith only [hW20])
  exact ⟨g5, sTot, hm_End, bg5⟩

theorem exec_maybeUpdateJStarStmt {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {j jStar : ℕ} (hW20 : 20 ≤ W)
    (hj_bl : intBitLength (j : ℤ) ≤ W) (hjS_bl : intBitLength (jStar : ℤ) ≤ W)
    (hSub106 : (.heap 9 106 : RAMCellLoc) ∈ S_write)
    (hr106 : ws.read (.heap 9 106) = (jStar : ℤ))
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) (hr7 : regs 7 = (j : ℤ)) :
    let jStar' := if j < jStar then j else jStar
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit maybeUpdateJStarStmt ws regs wsEnd regsEnd
        32 (20 * W + 120) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      regsEnd 7 = (j : ℤ) ∧
      wsEnd.read (.heap 9 106) = (jStar' : ℤ) ∧
      (∀ loc : RAMCellLoc, loc ≠ .heap 9 106 →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  intro jStar'
  have hl106 : intBitLength (106 : ℤ) ≤ W := by have : intBitLength (106 : ℤ) = 8 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have hloc106 : (RAMCellLoc.heap 9 106).bitLength ≤ W := by have : (RAMCellLoc.heap 9 106).bitLength = 12 := (by decide); omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 106) (by decide) hl106
  set g1 := Function.update regs 10 106; have bg1 := hbnd.update (r := 10) (by decide) hl106
  have hg1_r : ws.read (.heap 9 (g1 10)) = (jStar : ℤ) := by simp only [g1, Function.update_self]; exact hr106
  have s2 := RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 13) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg1_r]; exact hjS_bl)
  rw [hg1_r] at s2; set g2 := Function.update g1 13 (jStar : ℤ); have bg2 := bg1.update (r := 13) (by decide) hjS_bl
  have hg2_7 : g2 7 = (j : ℤ) := by simp [g2, g1, hr7]
  have hg2_13 : g2 13 = (jStar : ℤ) := by simp [g2]
  by_cases hlt : j < jStar
  · have hlt_z : g2 7 < g2 13 := by rw [hg2_7, hg2_13]; exact_mod_cast hlt
    have hm_End : ModifiedOnBounded ws₀ S_write W (ws.write (.heap 9 (g2 10)) (g2 7)) := by
      simpa [g2, g1, hr7] using hmod.write hSub106 (j : ℤ) hloc106 hj_bl
    have sBr := RegExec.store (inp := inp) hfd_le bg2 (table := 9) (addr := 10) (val := 7) (by decide) (by decide) hn9
      (sp_ok hm_End).1 (sp_ok hm_End).2
    set wsEnd := ws.write (.heap 9 106) (j : ℤ)
    have hwE : ws.write (.heap 9 (g2 10)) (g2 7) = wsEnd := by simp [wsEnd, g2, g1, hr7]
    rw [hwE] at sBr hm_End
    have s3 := RegExec.iteLt (tB := rStore 9 10 7) (fB := .skip) bg2 (a := 7) (b := 13) (by decide) (by decide)
      (by rw [if_pos hlt_z]; exact sBr)
    have sTot := (s1.seq (s2.seq s3)).weaken rfl rfl (u₂ := 32) (b₂ := 20 * W + 120) (by decide) (by omega)
    refine ⟨wsEnd, g2, sTot, hm_End, bg2, hg2_7, ?_, fun loc hne => ?_⟩
    · dsimp [jStar']; rw [if_pos hlt]; simp [wsEnd, WordStore.read, WordStore.write]
    · exact ⟨by simp [wsEnd, WordStore.write, hne], by simp [wsEnd, WordStore.write, Function.update_of_ne hne]⟩
  · have hnlt_z : ¬ (g2 7 < g2 13) := by rw [hg2_7, hg2_13]; exact_mod_cast hlt
    have sBr := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) bg2).weaken
      rfl rfl (u₂ := 6) (b₂ := 5 * W + 24) (by decide) (by omega)
    have s3 := RegExec.iteLt (tB := rStore 9 10 7) (fB := .skip) bg2 (a := 7) (b := 13) (by decide) (by decide)
      (by rw [if_neg hnlt_z]; exact sBr)
    have sTot := (s1.seq (s2.seq s3)).weaken rfl rfl (u₂ := 32) (b₂ := 20 * W + 120) (by decide) (by omega)
    refine ⟨ws, g2, sTot, hmod, bg2, hg2_7, ?_, fun _ _ => ⟨Iff.rfl, rfl⟩⟩
    dsimp [jStar']; rw [if_neg hlt]; exact hr106

theorem exec_checkLevelTriggerStmt {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {s₀_d L K_max j jStar age m_birth : ℕ}
    (hs₀1 : 1 ≤ s₀_d) (hj : j ≤ K_max) (hjS_le : jStar ≤ K_max + 1)
    (hage_le : age ≤ 2 ^ L) (hm_le : m_birth ≤ 2 ^ L)
    (hW : natBitLength ((K_max + 2) * posNodeStride d L) + natBitLength (64 * s₀_d + 1) + L + 24 ≤ W)
    (hSub104 : (.heap 9 104 : RAMCellLoc) ∈ S_write)
    (hSub106 : (.heap 9 106 : RAMCellLoc) ∈ S_write)
    (hr_age : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 0)) = (age : ℤ))
    (hr_mb : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 1)) = (m_birth : ℤ))
    (hr106 : ws.read (.heap 9 106) = (jStar : ℤ))
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) (hr7 : regs 7 = (j : ℤ)) :
    let trig : Prop := (1 / (4 * (s₀_d : ℝ))) * (m_birth : ℝ) / 16 < (age : ℝ)
    let jStar' : ℕ := open Classical in if trig ∧ j < jStar then j else jStar
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (checkLevelTriggerStmt s₀_d (posNodeStride d L)) ws regs wsEnd regsEnd
        120 (16 * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      wsEnd.read (.heap 9 104) = ((j + 1 : ℕ) : ℤ) ∧
      wsEnd.read (.heap 9 106) = (jStar' : ℤ) ∧
      (∀ loc : RAMCellLoc, loc ≠ .heap 9 104 → loc ≠ .heap 9 106 →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  intro trig jStar'
  have hW24 : 24 ≤ W := by clear * - hW; omega
  set ns := posNodeStride d L
  have hns_pos2 : 2 ≤ ns := by unfold ns posNodeStride; omega
  have hns_bl : intBitLength (ns : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le ns
    have h2 := natBitLength_mono (Nat.le_mul_of_pos_left ns (by omega : 0 < K_max + 2))
    clear * - h1 h2 hW; omega
  have ⟨_, haddr0_bl⟩ := nodeCellAddr_bl (W := W) (nodeStride := ns) (K_max := K_max) (j := j) (off := 0)
    (by omega) (by omega) (by clear * - hW; omega)
  have ⟨_, haddr1_bl⟩ := nodeCellAddr_bl (W := W) (nodeStride := ns) (K_max := K_max) (j := j) (off := 1)
    (by omega) hns_pos2 (by clear * - hW; omega)
  have hp2L : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
  have hage_bl : intBitLength (age : ℤ) ≤ W := by
    have : age < 2 ^ (L + 1) := by rw [pow_succ]; clear * - hage_le hp2L; omega
    exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
  have hmb_bl : intBitLength (m_birth : ℤ) ≤ W := by
    have : m_birth < 2 ^ (L + 1) := by rw [pow_succ]; clear * - hm_le hp2L; omega
    exact (nat_lt_pow2_bitLength_le this).trans (by clear * - hW; omega)
  have h64_bl : intBitLength (((64 * s₀_d : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le (64 * s₀_d)
    have h2 := natBitLength_mono (by omega : 64 * s₀_d ≤ 64 * s₀_d + 1)
    clear * - h1 h2 hW; omega
  have hprod_bl : intBitLength ((((64 * s₀_d : ℕ) : ℤ) * (age : ℤ))) ≤ W := by
    have h1 := intBitLength_ofNat_le (64 * s₀_d * age)
    have hle1 : 64 * s₀_d * age < (64 * s₀_d + 1) * 2 ^ (L + 1) := by
      have ha : age < 2 ^ (L + 1) := by rw [pow_succ]; clear * - hage_le hp2L; omega
      have hb : 64 * s₀_d < 64 * s₀_d + 1 := by omega
      exact Nat.mul_lt_mul'' hb ha
    have hc_lt : 64 * s₀_d + 1 < 2 ^ (Nat.log 2 (64 * s₀_d + 1) + 1) :=
      Nat.lt_pow_succ_log_self (by decide) _
    have htot_lt : 64 * s₀_d * age < 2 ^ (Nat.log 2 (64 * s₀_d + 1) + 1 + (L + 1)) := by
      calc 64 * s₀_d * age < (64 * s₀_d + 1) * 2 ^ (L + 1) := hle1
        _ < 2 ^ (Nat.log 2 (64 * s₀_d + 1) + 1) * 2 ^ (L + 1) :=
            Nat.mul_lt_mul_of_pos_right hc_lt (by positivity)
        _ = 2 ^ (Nat.log 2 (64 * s₀_d + 1) + 1 + (L + 1)) := (pow_add 2 _ _).symm
    have hbl_prod := nat_lt_pow2_bitLength_le htot_lt
    have hnbl_c : Nat.log 2 (64 * s₀_d + 1) + 1 ≤ natBitLength (64 * s₀_d + 1) := by
      unfold natBitLength; omega
    have hcast : (((64 * s₀_d : ℕ) : ℤ) * (age : ℤ)) = ((64 * s₀_d * age : ℕ) : ℤ) := by push_cast; rfl
    rw [hcast]; exact hbl_prod.trans (by clear * - hnbl_c hW; omega)
  have hj_bl : intBitLength (j : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le j
    have h2 := natBitLength_mono (show j ≤ (K_max + 2) * ns by nlinarith only [hj, hns_pos2])
    clear * - h1 h2 hW; omega
  have hj1_bl : intBitLength ((j + 1 : ℕ) : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le (j + 1)
    have h2 := natBitLength_mono (show j + 1 ≤ (K_max + 2) * ns by nlinarith only [hj, hns_pos2])
    clear * - h1 h2 hW; omega
  have hjS_bl : intBitLength (jStar : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le jStar
    have h2 := natBitLength_mono (show jStar ≤ (K_max + 2) * ns by nlinarith only [hjS_le, hns_pos2])
    clear * - h1 h2 hW; omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl104 : intBitLength (104 : ℤ) ≤ W := by have : intBitLength (104 : ℤ) = 8 := (by decide); omega
  have hn3 : natBitLength 3 ≤ W := by have : natBitLength 3 = 2 := (by decide); omega
  have hn9 : natBitLength 9 ≤ W := by have : natBitLength 9 = 4 := (by decide); omega
  have hloc104 : (RAMCellLoc.heap 9 104).bitLength ≤ W := by have : (RAMCellLoc.heap 9 104).bitLength = 12 := (by decide); omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  -- Steps s1..s8: compute age'_j, m_birth_j, and 64*s0*age'_j
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (c := (ns : ℤ)) (by decide) hns_bl
  set g1 := Function.update regs 8 (ns : ℤ); have bg1 := hbnd.update (r := 8) (by decide) hns_bl
  have hm0 : g1 7 * g1 8 = nodeCellAddr ns j 0 := by simp [g1, hr7, nodeCellAddr]
  have s2 := RegExec.mul (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (a := 7) (b := 8)
    (by decide) (by decide) (by decide) (by rw [hm0]; exact haddr0_bl)
  rw [hm0] at s2; set g2 := Function.update g1 8 (nodeCellAddr ns j 0); have bg2 := bg1.update (r := 8) (by decide) haddr0_bl
  have hg2_r : ws.read (.heap 3 (g2 8)) = (age : ℤ) := by simp only [g2, Function.update_self]; exact hr_age
  have s3 := RegExec.load (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 9) (table := 3) (addr := 8)
    (by decide) (by decide) hn3 (by rw [hg2_r]; exact hage_bl)
  rw [hg2_r] at s3; set g3 := Function.update g2 9 (age : ℤ); have bg3 := bg2.update (r := 9) (by decide) hage_bl
  have s4 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 14) (c := 1) (by decide) hl1
  set g4 := Function.update g3 14 1; have bg4 := bg3.update (r := 14) (by decide) hl1
  have ha1 : g4 8 + g4 14 = nodeCellAddr ns j 1 := by simp [g4, g3, g2, nodeCellAddr]
  have s5 := RegExec.add (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 8) (a := 8) (b := 14)
    (by decide) (by decide) (by decide) (by rw [ha1]; exact haddr1_bl)
  rw [ha1] at s5; set g5 := Function.update g4 8 (nodeCellAddr ns j 1); have bg5 := bg4.update (r := 8) (by decide) haddr1_bl
  have hg5_r : ws.read (.heap 3 (g5 8)) = (m_birth : ℤ) := by simp only [g5, Function.update_self]; exact hr_mb
  have s6 := RegExec.load (inp := inp) hfd_le bg5 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 11) (table := 3) (addr := 8)
    (by decide) (by decide) hn3 (by rw [hg5_r]; exact hmb_bl)
  rw [hg5_r] at s6; set g6 := Function.update g5 11 (m_birth : ℤ); have bg6 := bg5.update (r := 11) (by decide) hmb_bl
  have s7 := RegExec.lit (inp := inp) hfd_le bg6 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 12) (c := ((64 * s₀_d : ℕ) : ℤ)) (by decide) h64_bl
  set g7 := Function.update g6 12 ((64 * s₀_d : ℕ) : ℤ); have bg7 := bg6.update (r := 12) (by decide) h64_bl
  have hm_prod : g7 12 * g7 9 = ((64 * s₀_d : ℕ) : ℤ) * (age : ℤ) := by simp [g7, g6, g5, g4, g3]
  have s8 := RegExec.mul (inp := inp) hfd_le bg7 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 9) (a := 12) (b := 9)
    (by decide) (by decide) (by decide) (by rw [hm_prod]; exact hprod_bl)
  rw [hm_prod] at s8; set g8 := Function.update g7 9 (((64 * s₀_d : ℕ) : ℤ) * (age : ℤ)); have bg8 := bg7.update (r := 9) (by decide) hprod_bl
  -- Conditional trigger branch
  have hg8_11 : g8 11 = (m_birth : ℤ) := by simp [g8, g7, g6]
  have hg8_9 : g8 9 = ((64 * s₀_d : ℕ) : ℤ) * (age : ℤ) := by simp [g8]
  have hg8_7 : g8 7 = (j : ℤ) := by simp [g8, g7, g6, g5, g4, g3, g2, g1, hr7]
  have hIte : ∃ wsMid gMid,
      RegExec inp fd W C_cell C_bit (.ite (.intLt (.readLocal 11 (.lit 0)) (.readLocal 9 (.lit 0))) maybeUpdateJStarStmt .skip)
        ws g8 wsMid gMid 38 (24 * W + 136) ∧
      ModifiedOnBounded ws₀ S_write W wsMid ∧ RegBounded W gMid ∧
      gMid 7 = (j : ℤ) ∧ wsMid.read (.heap 9 106) = (jStar' : ℤ) ∧
      (∀ loc : RAMCellLoc, loc ≠ .heap 9 106 → (loc ∈ wsMid.live ↔ loc ∈ ws.live) ∧ wsMid.vals loc = ws.vals loc) := by
    classical
    by_cases htr : trig
    · have hlt_z : g8 11 < g8 9 := by rw [hg8_11, hg8_9]; exact (age_trigger_iff_nat hs₀1).mp htr
      obtain ⟨wsM, gM, sSub, hmM, bgM, gM_7, hr106_M, hunchM⟩ :=
        exec_maybeUpdateJStarStmt (inp := inp) (fd := fd) hfd_le hmod hcCeil hbCeil (by omega)
          hj_bl hjS_bl hSub106 hr106 bg8 hg8_7
      have s9 := RegExec.iteLt (tB := maybeUpdateJStarStmt) (fB := .skip) bg8 (a := 11) (b := 9) (by decide) (by decide)
        (by rw [if_pos hlt_z]; exact sSub)
      have hjS'_eq : (if j < jStar then j else jStar) = jStar' := by dsimp [jStar']; simp [htr]
      rw [hjS'_eq] at hr106_M
      exact ⟨wsM, gM, s9.weaken rfl rfl (by omega) (by omega), hmM, bgM, gM_7, hr106_M, hunchM⟩
    · have hnlt_z : ¬ (g8 11 < g8 9) := by rw [hg8_11, hg8_9]; intro h; exact htr ((age_trigger_iff_nat hs₀1).mpr h)
      have sSk := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) bg8).weaken
        rfl rfl (u₂ := 32) (b₂ := 20 * W + 120) (by decide) (by omega)
      have s9 := RegExec.iteLt (tB := maybeUpdateJStarStmt) (fB := .skip) bg8 (a := 11) (b := 9) (by decide) (by decide)
        (by rw [if_neg hnlt_z]; exact sSk)
      have hjS'_eq : jStar' = jStar := by dsimp [jStar']; simp [htr]
      exact ⟨ws, g8, s9.weaken rfl rfl (by omega) (by omega), hmod, bg8, hg8_7, by rw [hjS'_eq]; exact hr106, fun _ _ => ⟨Iff.rfl, rfl⟩⟩
  obtain ⟨wsMid, gMid, s9, hmMid, bgMid, gMid_7, hr106_Mid, hunchMid⟩ := hIte
  -- Increment j in heap 9 104
  have s10 := RegExec.lit (inp := inp) hfd_le bgMid (sp_ok hmMid).1 (sp_ok hmMid).2 (dst := 10) (c := 104) (by decide) hl104
  set g9 := Function.update gMid 10 104; have bg9 := bgMid.update (r := 10) (by decide) hl104
  have s11 := RegExec.lit (inp := inp) hfd_le bg9 (sp_ok hmMid).1 (sp_ok hmMid).2 (dst := 14) (c := 1) (by decide) hl1
  set g10 := Function.update g9 14 1; have bg10 := bg9.update (r := 14) (by decide) hl1
  have hadd_j : g10 7 + g10 14 = ((j + 1 : ℕ) : ℤ) := by simp [g10, g9, gMid_7]
  have s12 := RegExec.add (inp := inp) hfd_le bg10 (sp_ok hmMid).1 (sp_ok hmMid).2 (dst := 7) (a := 7) (b := 14)
    (by decide) (by decide) (by decide) (by rw [hadd_j]; exact hj1_bl)
  rw [hadd_j] at s12; set gEnd := Function.update g10 7 ((j + 1 : ℕ) : ℤ); have bgEnd := bg10.update (r := 7) (by decide) hj1_bl
  have hmEnd : ModifiedOnBounded ws₀ S_write W (wsMid.write (.heap 9 (gEnd 10)) (gEnd 7)) := by
    simpa [gEnd, g10, g9] using hmMid.write hSub104 ((j + 1 : ℕ) : ℤ) hloc104 hj1_bl
  have s13 := RegExec.store (inp := inp) hfd_le bgEnd (table := 9) (addr := 10) (val := 7) (by decide) (by decide) hn9
    (sp_ok hmEnd).1 (sp_ok hmEnd).2
  set wsEnd := wsMid.write (.heap 9 104) ((j + 1 : ℕ) : ℤ)
  have hwE : wsMid.write (.heap 9 (gEnd 10)) (gEnd 7) = wsEnd := by simp [wsEnd, gEnd, g10, g9]
  rw [hwE] at s13 hmEnd
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq (s11.seq (s12.seq s13)))))))))))).weaken
    rfl rfl (u₂ := 120) (b₂ := 16 * W * W) (by decide) (by nlinarith only [hW24])
  refine ⟨wsEnd, gEnd, sTot, hmEnd, bgEnd,
    by simp [wsEnd, WordStore.read, WordStore.write],
    by rw [wordStore_read_write_ne _ (by decide)]; exact hr106_Mid, ?_⟩
  intro loc hne104 hne106
  have uM := hunchMid loc hne106
  exact ⟨by simp [wsEnd, WordStore.write, hne104, uM.1],
         by simp [wsEnd, WordStore.write, Function.update_of_ne hne104, uM.2]⟩

end UL.C12LVE
