import Mathlib
import UL.Stmt.clm_7_3_las_vegas_endpoint
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorB0a
import UL.Proof.clm_7_3_las_vegas_endpoint.CG11_StepC3
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open scoped ENNReal
open UL
open UL.Proof_lem_A_1

/-! ### 1. `IsBoundedByPoly3` Closure Combinators and Bit-Length Upper Bounds -/

theorem poly3_const (c : ℝ) (hc : 0 ≤ c) :
    IsBoundedByPoly3 (fun _ _ _ => c) := by
  refine ⟨c, 0, hc, fun d B L => ?_⟩
  simp

theorem poly3_var_d :
    IsBoundedByPoly3 (fun d _ _ => (d : ℝ)) := by
  refine ⟨1, 1, by norm_num, fun d B L => ?_⟩
  have hd0 : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
  have hB0 : (0 : ℝ) ≤ (B : ℝ) := Nat.cast_nonneg B
  have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
  have hp : (1 : ℝ) ≤ ((B + 1 : ℝ)) * ((L + 1 : ℝ)) := one_le_mul_of_one_le_of_one_le (by linarith) (by linarith)
  have hm := mul_le_mul_of_nonneg_left hp (show (0 : ℝ) ≤ (d + 1 : ℝ) by linarith)
  simp only [pow_one]
  nlinarith

theorem poly3_var_B :
    IsBoundedByPoly3 (fun _ B _ => (B : ℝ)) := by
  refine ⟨1, 1, by norm_num, fun d B L => ?_⟩
  have hd0 : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
  have hB0 : (0 : ℝ) ≤ (B : ℝ) := Nat.cast_nonneg B
  have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
  have hp : (1 : ℝ) ≤ ((d + 1 : ℝ)) * ((L + 1 : ℝ)) := one_le_mul_of_one_le_of_one_le (by linarith) (by linarith)
  have hm := mul_le_mul_of_nonneg_left hp (show (0 : ℝ) ≤ (B + 1 : ℝ) by linarith)
  simp only [pow_one]
  nlinarith

theorem poly3_var_L :
    IsBoundedByPoly3 (fun _ _ L => (L : ℝ)) := by
  refine ⟨1, 1, by norm_num, fun d B L => ?_⟩
  have hd0 : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
  have hB0 : (0 : ℝ) ≤ (B : ℝ) := Nat.cast_nonneg B
  have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
  have hp : (1 : ℝ) ≤ ((d + 1 : ℝ)) * ((B + 1 : ℝ)) := one_le_mul_of_one_le_of_one_le (by linarith) (by linarith)
  have hm := mul_le_mul_of_nonneg_left hp (show (0 : ℝ) ≤ (L + 1 : ℝ) by linarith)
  simp only [pow_one]
  nlinarith

theorem poly3_mono {f g : ℕ → ℕ → ℕ → ℝ}
    (hf : IsBoundedByPoly3 f) (hle : ∀ d B L, g d B L ≤ f d B L) :
    IsBoundedByPoly3 g := by
  obtain ⟨C, deg, hC, hfb⟩ := hf
  exact ⟨C, deg, hC, fun d B L => (hle d B L).trans (hfb d B L)⟩

theorem poly3_add {f g : ℕ → ℕ → ℕ → ℝ}
    (hf : IsBoundedByPoly3 f) (hg : IsBoundedByPoly3 g) :
    IsBoundedByPoly3 (fun d B L => f d B L + g d B L) := by
  obtain ⟨Cf, df, hCf, hfb⟩ := hf
  obtain ⟨Cg, dg, hCg, hgb⟩ := hg
  refine ⟨Cf + Cg, df + dg, add_nonneg hCf hCg, fun d B L => ?_⟩
  have hd0 : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
  have hB0 : (0 : ℝ) ≤ (B : ℝ) := Nat.cast_nonneg B
  have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
  have hdf1 : (d + 1 : ℝ) ^ df ≤ (d + 1 : ℝ) ^ (df + dg) := pow_le_pow_right₀ (by linarith) (by omega)
  have hBf1 : (B + 1 : ℝ) ^ df ≤ (B + 1 : ℝ) ^ (df + dg) := pow_le_pow_right₀ (by linarith) (by omega)
  have hLf1 : (L + 1 : ℝ) ^ df ≤ (L + 1 : ℝ) ^ (df + dg) := pow_le_pow_right₀ (by linarith) (by omega)
  have hdg1 : (d + 1 : ℝ) ^ dg ≤ (d + 1 : ℝ) ^ (df + dg) := pow_le_pow_right₀ (by linarith) (by omega)
  have hBg1 : (B + 1 : ℝ) ^ dg ≤ (B + 1 : ℝ) ^ (df + dg) := pow_le_pow_right₀ (by linarith) (by omega)
  have hLg1 : (L + 1 : ℝ) ^ dg ≤ (L + 1 : ℝ) ^ (df + dg) := pow_le_pow_right₀ (by linarith) (by omega)
  have hpf : ((d + 1 : ℝ) ^ df) * ((B + 1 : ℝ) ^ df) * ((L + 1 : ℝ) ^ df) ≤
      ((d + 1 : ℝ) ^ (df + dg)) * ((B + 1 : ℝ) ^ (df + dg)) * ((L + 1 : ℝ) ^ (df + dg)) :=
    mul_le_mul (mul_le_mul hdf1 hBf1 (by positivity) (by positivity)) hLf1 (by positivity) (by positivity)
  have hpg : ((d + 1 : ℝ) ^ dg) * ((B + 1 : ℝ) ^ dg) * ((L + 1 : ℝ) ^ dg) ≤
      ((d + 1 : ℝ) ^ (df + dg)) * ((B + 1 : ℝ) ^ (df + dg)) * ((L + 1 : ℝ) ^ (df + dg)) :=
    mul_le_mul (mul_le_mul hdg1 hBg1 (by positivity) (by positivity)) hLg1 (by positivity) (by positivity)
  calc f d B L + g d B L
    _ ≤ Cf * ((d + 1 : ℝ) ^ df) * ((B + 1 : ℝ) ^ df) * ((L + 1 : ℝ) ^ df) +
        Cg * ((d + 1 : ℝ) ^ dg) * ((B + 1 : ℝ) ^ dg) * ((L + 1 : ℝ) ^ dg) := add_le_add (hfb d B L) (hgb d B L)
    _ = Cf * (((d + 1 : ℝ) ^ df) * ((B + 1 : ℝ) ^ df) * ((L + 1 : ℝ) ^ df)) +
        Cg * (((d + 1 : ℝ) ^ dg) * ((B + 1 : ℝ) ^ dg) * ((L + 1 : ℝ) ^ dg)) := by ring
    _ ≤ Cf * (((d + 1 : ℝ) ^ (df + dg)) * ((B + 1 : ℝ) ^ (df + dg)) * ((L + 1 : ℝ) ^ (df + dg))) +
        Cg * (((d + 1 : ℝ) ^ (df + dg)) * ((B + 1 : ℝ) ^ (df + dg)) * ((L + 1 : ℝ) ^ (df + dg))) :=
      add_le_add (mul_le_mul_of_nonneg_left hpf hCf) (mul_le_mul_of_nonneg_left hpg hCg)
    _ = (Cf + Cg) * ((d + 1 : ℝ) ^ (df + dg)) * ((B + 1 : ℝ) ^ (df + dg)) * ((L + 1 : ℝ) ^ (df + dg)) := by ring

theorem poly3_mul {f g : ℕ → ℕ → ℕ → ℝ}
    (hf : IsBoundedByPoly3 f) (hg : IsBoundedByPoly3 g)
    (_hf_nn : ∀ d B L, 0 ≤ f d B L) (hg_nn : ∀ d B L, 0 ≤ g d B L) :
    IsBoundedByPoly3 (fun d B L => f d B L * g d B L) := by
  obtain ⟨Cf, df, hCf, hfb⟩ := hf
  obtain ⟨Cg, dg, hCg, hgb⟩ := hg
  refine ⟨Cf * Cg, df + dg, mul_nonneg hCf hCg, fun d B L => ?_⟩
  have hprod := mul_le_mul (hfb d B L) (hgb d B L) (hg_nn d B L)
    (mul_nonneg (mul_nonneg (mul_nonneg hCf (by positivity)) (by positivity)) (by positivity))
  have hring :
      (Cf * ((d + 1 : ℝ) ^ df) * ((B + 1 : ℝ) ^ df) * ((L + 1 : ℝ) ^ df)) *
      (Cg * ((d + 1 : ℝ) ^ dg) * ((B + 1 : ℝ) ^ dg) * ((L + 1 : ℝ) ^ dg)) =
      Cf * Cg * ((d + 1 : ℝ) ^ (df + dg)) * ((B + 1 : ℝ) ^ (df + dg)) * ((L + 1 : ℝ) ^ (df + dg)) := by
    rw [pow_add, pow_add, pow_add]
    ring
  exact hprod.trans_eq hring

theorem poly3_of_poly1_d {f : ℕ → ℝ} (hf : IsBoundedByPoly1 f) :
    IsBoundedByPoly3 (fun d _ _ => f d) := by
  obtain ⟨C, deg, hC, hfb⟩ := hf
  refine ⟨C, deg, hC, fun d B L => ?_⟩
  have hB0 : (0 : ℝ) ≤ (B : ℝ) := Nat.cast_nonneg B
  have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
  have hB : (1 : ℝ) ≤ (B + 1 : ℝ) ^ deg := one_le_pow₀ (by linarith)
  have hL : (1 : ℝ) ≤ (L + 1 : ℝ) ^ deg := one_le_pow₀ (by linarith)
  have h1 : (1 : ℝ) ≤ ((B + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg) := one_le_mul_of_one_le_of_one_le hB hL
  calc f d
    _ ≤ (C * ((d + 1 : ℝ) ^ deg)) * 1 := by linarith [hfb d]
    _ ≤ (C * ((d + 1 : ℝ) ^ deg)) * (((B + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg)) :=
      mul_le_mul_of_nonneg_left h1 (mul_nonneg hC (by positivity))
    _ = C * ((d + 1 : ℝ) ^ deg) * ((B + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg) := by ring

theorem poly3_of_poly2_dB {f : ℕ → ℕ → ℝ} (hf : IsBoundedByPoly2 f) :
    IsBoundedByPoly3 (fun d B _ => f d B) := by
  obtain ⟨C, deg, hC, hfb⟩ := hf
  refine ⟨C, deg, hC, fun d B L => ?_⟩
  have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
  have hL : (1 : ℝ) ≤ (L + 1 : ℝ) ^ deg := one_le_pow₀ (by linarith)
  calc f d B
    _ ≤ (C * ((d + 1 : ℝ) ^ deg) * ((B + 1 : ℝ) ^ deg)) * 1 := by linarith [hfb d B]
    _ ≤ (C * ((d + 1 : ℝ) ^ deg) * ((B + 1 : ℝ) ^ deg)) * ((L + 1 : ℝ) ^ deg) :=
      mul_le_mul_of_nonneg_left hL (mul_nonneg (mul_nonneg hC (by positivity)) (by positivity))

theorem poly3_natCeil {f : ℕ → ℕ → ℕ → ℝ}
    (hf : IsBoundedByPoly3 f) (hf_nn : ∀ d B L, 0 ≤ f d B L) :
    IsBoundedByPoly3 (fun d B L => (Nat.ceil (f d B L) : ℝ)) := by
  refine poly3_mono (poly3_add hf (poly3_const 1 (by norm_num))) (fun d B L => ?_)
  exact (Nat.ceil_lt_add_one (hf_nn d B L)).le

theorem natBitLength_le_add_one (x : ℕ) :
    natBitLength x ≤ x + 1 := by
  unfold natBitLength
  have hlog := Nat.log_le_self 2 x
  omega

theorem natBitLength_mul_pow2_le (a L : ℕ) :
    natBitLength (a * 2 ^ L) ≤ a + L + 1 := by
  unfold natBitLength
  by_cases hz : a * 2 ^ L = 0
  · rw [hz]; simp
  · have ha_lt : a < 2 ^ a := a.lt_two_pow_self
    have hpow_pos : 0 < 2 ^ L := Nat.two_pow_pos L
    have hlt : a * 2 ^ L < 2 ^ (a + L) := by
      calc a * 2 ^ L < 2 ^ a * 2 ^ L := Nat.mul_lt_mul_of_pos_right ha_lt hpow_pos
        _ = 2 ^ (a + L) := (pow_add 2 a L).symm
    have hlog := Nat.log_lt_of_lt_pow hz hlt
    omega

theorem natBitLength_nodeStride_bound (d L K_max : ℕ) :
    natBitLength ((K_max + 2) * posNodeStride d L) ≤ (K_max + 2) * (2 * d + 9) + L + 1 := by
  have h1 : 1 ≤ 2 ^ L := Nat.one_le_pow L 2 (by decide)
  have hinner : posNodeStride d L ≤ (2 * d + 9) * 2 ^ L := by
    unfold posNodeStride
    nlinarith only [h1]
  have hle : (K_max + 2) * posNodeStride d L ≤ ((K_max + 2) * (2 * d + 9)) * 2 ^ L := by
    calc (K_max + 2) * posNodeStride d L
      _ ≤ (K_max + 2) * ((2 * d + 9) * 2 ^ L) := Nat.mul_le_mul_left _ hinner
      _ = ((K_max + 2) * (2 * d + 9)) * 2 ^ L := by ring
  exact (natBitLength_mono hle).trans (natBitLength_mul_pow2_le _ L)

theorem natBitLength_a2Enc_bound (d L T_max : ℕ) :
    natBitLength ((2 ^ L + 2 * d + 4) * T_max) ≤ (2 * d + 5) * T_max + L + 1 := by
  have h1 : 1 ≤ 2 ^ L := Nat.one_le_pow L 2 (by decide)
  have hinner : 2 ^ L + 2 * d + 4 ≤ (2 * d + 5) * 2 ^ L := by
    nlinarith only [h1]
  have hle : (2 ^ L + 2 * d + 4) * T_max ≤ ((2 * d + 5) * T_max) * 2 ^ L := by
    calc (2 ^ L + 2 * d + 4) * T_max
      _ ≤ ((2 * d + 5) * 2 ^ L) * T_max := Nat.mul_le_mul_right _ hinner
      _ = ((2 * d + 5) * T_max) * 2 ^ L := by ring
  exact (natBitLength_mono hle).trans (natBitLength_mul_pow2_le _ L)

theorem runSyncSuffixFuel_accWork_le {d L_leaf : ℕ} {NodeAux : Type}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    {hist : ExecutionHistory d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)} :
    ∀ (fuel : ℕ) (acc : List (SyncSuffixPrefixEntry d NodeAux))
      (R : Finset ℕ) (accWork : ℕ) (bs : List Bool)
      (sufOut : SyncSuffixOutcome d NodeAux),
      runSyncSuffixFuel ctor L_leaf hist ltCoords fuel acc R accWork bs = some sufOut →
        accWork ≤ sufOut.totalWork := by
  intro fuel
  induction fuel with
  | zero =>
      intro acc R accWork bs sufOut hr
      dsimp only [runSyncSuffixFuel] at hr
      split_ifs at hr with hc
      injection hr with heq; subst heq
      exact le_rfl
  | succ fuel ih =>
      intro acc R accWork bs sufOut hr
      dsimp only [runSyncSuffixFuel] at hr
      by_cases hle : R.card ≤ L_leaf
      · rw [if_pos hle] at hr
        split_ifs at hr with hemp
        injection hr with heq; subst heq
        exact le_rfl
      · rw [if_neg hle] at hr
        by_cases hStep : ∃ (bs₁ bs₂ : List Bool) (out : SyncBuiltNode d NodeAux),
            bs = bs₁ ++ bs₂ ∧ ctor.buildWithBits hist acc ltCoords R bs₁ = some out
        · rw [dif_pos hStep] at hr
          exact (Nat.le_add_right accWork _).trans (ih _ _ _ _ _ hr)
        · rw [dif_neg hStep] at hr
          cases hr

theorem runSyncSuffixBuild_head_card_le_work {d L_leaf : ℕ} {NodeAux : Type}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    {hist : ExecutionHistory d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {bs : List Bool} {sufOut : SyncSuffixOutcome d NodeAux}
    (hgt : L_leaf < S.card)
    (hwk : ∀ bs₁ out, ctor.buildWithBits hist [] ltCoords S bs₁ = some out → S.card ≤ out.work)
    (hsuf : runSyncSuffixBuild ctor L_leaf hist ltCoords S bs = some sufOut) :
    S.card ≤ sufOut.totalWork := by
  unfold runSyncSuffixBuild at hsuf
  obtain ⟨fuel, hfuel⟩ : ∃ f, S.card = f + 1 := ⟨S.card - 1, by omega⟩
  rw [hfuel] at hsuf
  dsimp only [runSyncSuffixFuel] at hsuf
  rw [if_neg (by omega : ¬ (S.card ≤ L_leaf))] at hsuf
  by_cases hStep : ∃ (bs₁ bs₂ : List Bool) (out : SyncBuiltNode d NodeAux),
      bs = bs₁ ++ bs₂ ∧ ctor.buildWithBits hist [] ltCoords S bs₁ = some out
  · rw [dif_pos hStep] at hsuf
    let bs₁ := Classical.choose hStep
    let h₂ := Classical.choose_spec hStep
    let h₃ := Classical.choose_spec h₂
    let out := Classical.choose h₃
    have hbuild : ctor.buildWithBits hist [] ltCoords S bs₁ = some out :=
      (Classical.choose_spec h₃).2
    have hS_le : S.card ≤ out.work := by
      have := hwk bs₁ out hbuild
      omega
    have hacc_le : 0 + out.work ≤ sufOut.totalWork :=
      runSyncSuffixFuel_accWork_le fuel _ _ (0 + out.work) _ sufOut hsuf
    omega
  · rw [dif_neg hStep] at hsuf
    cases hsuf

theorem posDimWriteLocs_card_le_mul_n {n d L K_max : ℕ}
    (hn : 2 ≤ n) (hL : L = Nat.clog 2 (2 * n)) :
    (posDimWriteLocs d L K_max).card ≤
      n * (96 * K_max + 32 * d + (K_max + 2) * (2 * d + 8) + 900) := by
  obtain ⟨_, _, _, hpow_4n⟩ := clog_two_mul_bounds hn
  rw [← hL] at hpow_4n
  have hcard := posDimWriteLocs_card_le d L K_max
  have hp1 : (24 * K_max + 8 * d + 72) * 2 ^ L ≤ n * (96 * K_max + 32 * d + 288) := by
    calc (24 * K_max + 8 * d + 72) * 2 ^ L
      _ ≤ (24 * K_max + 8 * d + 72) * (4 * n) := Nat.mul_le_mul_left _ (by omega)
      _ = n * (96 * K_max + 32 * d + 288) := by ring
  have hp2 : (K_max + 2) * (2 * d + 8) ≤ n * ((K_max + 2) * (2 * d + 8)) :=
    Nat.le_mul_of_pos_left _ (by omega)
  have hp3 : 600 ≤ n * 612 := by omega
  have hsum : n * (96 * K_max + 32 * d + 288) + n * ((K_max + 2) * (2 * d + 8)) + n * 612 =
      n * (96 * K_max + 32 * d + (K_max + 2) * (2 * d + 8) + 900) := by ring
  linarith only [hcard, hp1, hp2, hp3, hsum]

end UL.C12LVE
