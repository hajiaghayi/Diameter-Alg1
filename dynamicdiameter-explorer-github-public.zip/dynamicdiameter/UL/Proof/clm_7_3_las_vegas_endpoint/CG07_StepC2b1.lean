import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2b0
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_SyncCtorA0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL
open UL.Proof_lem_A_1
open UL.C12LVE

def extractedVNum10 (d T_max : ℕ) (ws : WordStore) : ℤ :=
  let oNum : ℕ → ℤ := fun c => if c < d then ws.read (.heap 10 ((((2 * c) * T_max + 1 : ℕ) : ℤ))) else 0
  let oDen : ℕ → ℤ := fun c => if c < d then ws.read (.heap 10 ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ))) else 1
  let zNum : ℕ → ℤ := fun _ => 0
  let zDen : ℕ → ℤ := fun _ => 1
  let sqNum : ℕ → ℤ := fun i => (oNum i * zDen i - zNum i * oDen i) * (oNum i * zDen i - zNum i * oDen i)
  let sqDen : ℕ → ℤ := fun i => (oDen i * zDen i) * (oDen i * zDen i)
  let p := ratSumPairs sqNum sqDen d
  let sN := ws.read (.heap 10 ((((2 * d) * T_max + 1 : ℕ) : ℤ)))
  let sD := ws.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)))
  sN * p.2 - p.1 * sD

def extractedVDen10 (d T_max : ℕ) (ws : WordStore) : ℤ :=
  let oNum : ℕ → ℤ := fun c => if c < d then ws.read (.heap 10 ((((2 * c) * T_max + 1 : ℕ) : ℤ))) else 0
  let oDen : ℕ → ℤ := fun c => if c < d then ws.read (.heap 10 ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ))) else 1
  let zNum : ℕ → ℤ := fun _ => 0
  let zDen : ℕ → ℤ := fun _ => 1
  let sqNum : ℕ → ℤ := fun i => (oNum i * zDen i - zNum i * oDen i) * (oNum i * zDen i - zNum i * oDen i)
  let sqDen : ℕ → ℤ := fun i => (oDen i * zDen i) * (oDen i * zDen i)
  let p := ratSumPairs sqNum sqDen d
  let sD := ws.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)))
  sD * p.2

theorem exec_extractNodeCenterAndVarRegs_det {d : ℕ} (_hd1 : 1 ≤ d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {B_cert nodeStride T_max K_max j : ℕ}
    (hBc1 : 1 ≤ B_cert) (hT1 : 2 ≤ T_max)
    (hj : j ≤ K_max + 1) (hstride : 6 + 2 * d ≤ nodeStride)
    (hW : (d + 1) * (2 * B_cert + 8) + natBitLength ((K_max + 2) * nodeStride) +
            natBitLength ((2 * d + 2) * T_max) + 32 ≤ W)
    {oRat : Fin d → ℚ} {sRat : ℚ}
    (hV_nn : 0 ≤ liftVariance (ratPointToEuclidean oRat) (sRat : ℝ))
    (ho10 : ∀ c : Fin d,
      let oN := ws.read (.heap 10 ((((2 * c.val) * T_max + 1 : ℕ) : ℤ)))
      let oD := ws.read (.heap 10 ((((2 * c.val + 1) * T_max + 1 : ℕ) : ℤ)))
      1 ≤ oD ∧ oRat c = (oN : ℚ) / (oD : ℚ) ∧
      intBitLength oN ≤ B_cert ∧ intBitLength oD ≤ B_cert)
    (hs10 :
      let sN := ws.read (.heap 10 ((((2 * d) * T_max + 1 : ℕ) : ℤ)))
      let sD := ws.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)))
      1 ≤ sD ∧ sRat = (sN : ℚ) / (sD : ℚ) ∧
      intBitLength sN ≤ B_cert ∧ intBitLength sD ≤ B_cert)
    (hSub3 : ∀ off < 6 + 2 * d, (.heap 3 (nodeCellAddr nodeStride j off) : RAMCellLoc) ∈ S_write)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (j : ℤ)) :
    ∃ wsEnd regsEnd V_num V_den,
      RegExec inp fd W C_cell C_bit (extractNodeCenterAndVarRegs d nodeStride T_max)
        ws regs wsEnd regsEnd (260 * d + 140) ((60 * d + 36) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      regsEnd 0 = (j : ℤ) ∧ regsEnd 5 = regs 5 ∧
      V_num = extractedVNum10 d T_max ws ∧
      V_den = extractedVDen10 d T_max ws ∧
      NodeGeomStored d nodeStride B_cert j oRat V_num V_den
        (liftVariance (ratPointToEuclidean oRat) (sRat : ℝ)) wsEnd ∧
      (∀ loc : RAMCellLoc,
        (∀ off : ℕ, off < 6 + 2 * d → loc ≠ .heap 3 (nodeCellAddr nodeStride j off)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW20 : 20 ≤ W := by clear * - hW; omega
  have hWW : 20 * W ≤ W * W := by nlinarith only [hW20]
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by clear * - hW20; omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by clear * - hW20; omega)
  have hl3 : intBitLength (3 : ℤ) ≤ W := (show intBitLength (3 : ℤ) = 3 from by decide).trans_le (by clear * - hW20; omega)
  have hl6 : intBitLength (6 : ℤ) ≤ W := (show intBitLength (6 : ℤ) = 4 from by decide).trans_le (by clear * - hW20; omega)
  have hn3 : natBitLength 3 ≤ W := (show natBitLength 3 = 2 from by decide).trans_le (by clear * - hW20; omega)
  have hn10 : natBitLength 10 ≤ W := (show natBitLength 10 = 4 from by decide).trans_le (by clear * - hW20; omega)
  have hW_node : natBitLength ((K_max + 2) * nodeStride) + 8 ≤ W := by clear * - hW; omega
  have h10_ceil_bl : intBitLength ((((2 * d + 2) * T_max : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le ((2 * d + 2) * T_max)
    clear * - h1 hW; omega
  have hd_le_ceil : d ≤ (2 * d + 2) * T_max := by
    calc d ≤ (2 * d + 2) * 1 := by clear * -; omega
      _ ≤ (2 * d + 2) * T_max := Nat.mul_le_mul_left _ (by clear * - hT1; omega)
  have hT_le_ceil : T_max ≤ (2 * d + 2) * T_max :=
    Nat.le_mul_of_pos_left T_max (by clear * -; omega)
  have hd_bl : intBitLength (d : ℤ) ≤ W :=
    (intBitLength_natCast_mono hd_le_ceil).trans h10_ceil_bl
  have hT_bl : intBitLength (T_max : ℤ) ≤ W :=
    (intBitLength_natCast_mono hT_le_ceil).trans h10_ceil_bl
  have hstride_bl : intBitLength (nodeStride : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le nodeStride
    have h2 : natBitLength nodeStride ≤ natBitLength ((K_max + 2) * nodeStride) :=
      natBitLength_mono (Nat.le_mul_of_pos_left nodeStride (by clear * -; omega))
    clear * - h1 h2 hW_node; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  let oNum : ℕ → ℤ := fun c => if c < d then ws.read (.heap 10 ((((2 * c) * T_max + 1 : ℕ) : ℤ))) else 0
  let oDen : ℕ → ℤ := fun c => if c < d then ws.read (.heap 10 ((((2 * c + 1) * T_max + 1 : ℕ) : ℤ))) else 1
  let zNum : ℕ → ℤ := fun _ => 0
  let zDen : ℕ → ℤ := fun _ => 1
  let sqNum := fun i => (oNum i * zDen i - zNum i * oDen i) * (oNum i * zDen i - zNum i * oDen i)
  let sqDen := fun i => (oDen i * zDen i) * (oDen i * zDen i)
  have hp1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 3) (c := 0) (by decide) hl0
  set g1 := Function.update regs 3 0; have bg1 : RegBounded W g1 := hbnd.update (r := 3) (by decide) hl0
  have hp2 := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 4) (c := 1) (by decide) hl1
  set g2 := Function.update g1 4 1; have bg2 : RegBounded W g2 := bg1.update (r := 4) (by decide) hl1
  have hp3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 6) (c := 0) (by decide) hl0
  set g3 := Function.update g2 6 0; have bg3 : RegBounded W g3 := bg2.update (r := 6) (by decide) hl0
  let StepInv := ExtractCenterStepInv d ws₀ ws S_write B_cert nodeStride T_max j W (regs 5)
  have hInv0 : StepInv 0 ws g3 := by
    refine ⟨hmod, bg3, by simp [g3, g2, g1, hr0], by simp [g3, g2, g1],
      fun _ _ => ⟨Iff.rfl, rfl⟩, fun _ => ?_⟩
    have hl0_eq : intBitLength (0 : ℤ) = 1 := by decide
    have hl1_eq : intBitLength (1 : ℤ) = 2 := by decide
    exact ⟨by simp [g3], by simp [g3, g2, g1, ratSumPairs], by simp [g3, g2, ratSumPairs],
      by simp [g3, g2, g1, hl0_eq], by simp [g3, g2, hl1_eq],
      fun _ _ hlt => absurd hlt (Nat.not_lt_zero _)⟩
  have hStep := exec_extractCenterCoordStepStmt_inv (inp := inp) _hd1 hfd_le hmod hcCeil hbCeil
    hBc1 hT1 hj hstride hW ho10 hSub3 (regs 5)
  let seqP : ∀ n : ℕ, { p : WordStore × (ℕ → ℤ) // StepInv n p.1 p.2 } :=
    Nat.rec ⟨(ws, g3), hInv0⟩ (fun c prev =>
      if hc : c < d then
        let hEx := hStep c hc prev.1.1 prev.1.2 prev.2
        let w' := Classical.choose hEx
        let hEx2 := Classical.choose_spec hEx
        ⟨(w', Classical.choose hEx2), (Classical.choose_spec hEx2).2⟩
      else
        ⟨prev.1, ⟨prev.2.1, prev.2.2.1, prev.2.2.2.1, prev.2.2.2.2.1, prev.2.2.2.2.2.1,
          fun hle => absurd (by clear * - hc hle; omega : c < d) hc⟩⟩)
  have hRep := RegExec.repeatLit (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    d hd_bl (fun i => (seqP i).1.1) (fun i => (seqP i).1.2) bg3
    (body := extractCenterCoordStepStmt nodeStride T_max) (U := 240) (B := 56 * W * W)
    (fun i hi => by
      dsimp only [seqP]
      rw [dif_pos hi]
      exact (Classical.choose_spec (Classical.choose_spec (hStep i hi (seqP i).1.1 (seqP i).1.2 (seqP i).2))).1)
  let wL := (seqP d).1.1; let gL := (seqP d).1.2
  have hEndP : StepInv d wL gL := (seqP d).2
  obtain ⟨hmL, bgL, hgL0, hgL5, hunchL, hdL⟩ := hEndP
  obtain ⟨_, hgL3, hgL4, hbL3, hbL4, hreadO_L⟩ := hdL le_rfl
  -- Post-loop: read `(sN, sD)` from `heap 10`, compute `V_num, V_den`, write to `heap 3 (j * nodeStride + 3/4)`
  set sN := ws.read (.heap 10 ((((2 * d) * T_max + 1 : ℕ) : ℤ)))
  set sD := ws.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)))
  dsimp only at hs10
  obtain ⟨hsD1, hs_eq, hsN_bl, hsD_bl⟩ := hs10
  have h2d1_le_ceil : (2 * d + 1) * T_max + 1 ≤ (2 * d + 2) * T_max := by
    calc (2 * d + 1) * T_max + 1 ≤ (2 * d + 1) * T_max + T_max := Nat.add_le_add_left (by clear * - hT1; omega) _
      _ = (2 * d + 2) * T_max := by ring
  have h2d0_le_2d1 : (2 * d) * T_max + 1 ≤ (2 * d + 1) * T_max + 1 :=
    Nat.add_le_add_right (Nat.mul_le_mul_right T_max (by clear * -; omega)) 1
  have ha10_s0_bl : intBitLength ((((2 * d) * T_max + 1 : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono (h2d0_le_2d1.trans h2d1_le_ceil)).trans h10_ceil_bl
  have ha10_s1_bl : intBitLength ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono h2d1_le_ceil).trans h10_ceil_bl
  have hrwL_sN : wL.read (.heap 10 ((((2 * d) * T_max + 1 : ℕ) : ℤ))) = sN := by
    rw [wordStore_read_eq_vals hmL.wf, (hunchL _ (fun _ _ h => by cases h)).2, ← wordStore_read_eq_vals hmod.wf]
  have hrwL_sD : wL.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ))) = sD := by
    rw [wordStore_read_eq_vals hmL.wf, (hunchL _ (fun _ _ h => by cases h)).2, ← wordStore_read_eq_vals hmod.wf]
  have hs_W : B_cert ≤ W := by
    have hm : 1 * (2 * B_cert + 8) ≤ (d + 1) * (2 * B_cert + 8) := Nat.mul_le_mul_right _ (by clear * -; omega)
    clear * - hm hW; omega
  set V_num := sN * gL 4 - gL 3 * sD
  set V_den := sD * gL 4
  have bm_sN4 : intBitLength (sN * gL 4) ≤ B_cert + (d * (2 * (B_cert + 2) + 2) + 2) :=
    (intBitLength_mul_le _ _).trans (Nat.add_le_add hsN_bl hbL4)
  have bm_3sD : intBitLength (gL 3 * sD) ≤ (d * (2 * (B_cert + 2) + 3) + 2) + B_cert :=
    (intBitLength_mul_le _ _).trans (Nat.add_le_add hbL3 hsD_bl)
  have hd_c2 : d * (2 * (B_cert + 2) + 2) ≤ d * (2 * B_cert + 7) :=
    Nat.mul_le_mul_left d (by clear * -; omega)
  have hd_c3 : d * (2 * (B_cert + 2) + 3) = d * (2 * B_cert + 7) := by ring
  have hd_expand : (d + 1) * (2 * B_cert + 7) = d * (2 * B_cert + 7) + 2 * B_cert + 7 := by ring
  have hVN_bnd : intBitLength V_num ≤ (d + 1) * (2 * B_cert + 7) + 4 := by
    have hs := intBitLength_sub_le_max (sN * gL 4) (gL 3 * sD)
    have hmax : max (intBitLength (sN * gL 4)) (intBitLength (gL 3 * sD)) ≤
        (d * (2 * B_cert + 7) + 2) + B_cert := by
      apply max_le
      · exact bm_sN4.trans (by clear * - hd_c2; omega)
      · exact bm_3sD.trans (by rw [hd_c3])
    dsimp [V_num]; rw [hd_expand]; clear * - hs hmax; omega
  have hVD_bnd : intBitLength V_den ≤ (d + 1) * (2 * B_cert + 7) + 4 := by
    have hm := (intBitLength_mul_le sD (gL 4)).trans (Nat.add_le_add hsD_bl hbL4)
    dsimp [V_den]; rw [hd_expand]; clear * - hm hd_c2; omega
  have hV_W : (d + 1) * (2 * B_cert + 7) + 4 ≤ W := by
    have hm : (d + 1) * (2 * B_cert + 7) ≤ (d + 1) * (2 * B_cert + 8) :=
      Nat.mul_le_mul_left (d + 1) (by clear * -; omega)
    clear * - hm hW; omega
  obtain ⟨hn3_loc, hn3_bl⟩ := nodeCellAddr_bl hj (off := 3) (by clear * - hstride; omega) hW_node
  obtain ⟨hn4_loc, hn4_bl⟩ := nodeCellAddr_bl hj (off := 4) (by clear * - hstride; omega) hW_node
  have hjs_bl0 : intBitLength ((j * nodeStride : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := j * nodeStride + 3) (by clear * -; omega)).trans hn3_bl
  -- Execute post-loop instructions `q1..q16`
  have q1 := RegExec.lit (inp := inp) hfd_le bgL (sp_ok hmL).1 (sp_ok hmL).2 (dst := 8) (c := ((((2 * d) * T_max + 1 : ℕ) : ℤ))) (by decide) ha10_s0_bl
  set z1 := Function.update gL 8 ((((2 * d) * T_max + 1 : ℕ) : ℤ)); have bz1 : RegBounded W z1 := bgL.update (r := 8) (by decide) ha10_s0_bl
  have hz1_8 : wL.read (.heap 10 (z1 8)) = sN := by simp only [z1, Function.update_self]; exact hrwL_sN
  have q2 := RegExec.load (inp := inp) hfd_le bz1 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 9) (table := 10) (addr := 8) (by decide) (by decide) hn10 (by rw [hz1_8]; exact hsN_bl.trans hs_W)
  rw [hz1_8] at q2; set z2 := Function.update z1 9 sN; have bz2 : RegBounded W z2 := bz1.update (r := 9) (by decide) (hsN_bl.trans hs_W)
  have q3 := RegExec.lit (inp := inp) hfd_le bz2 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 8) (c := ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ))) (by decide) ha10_s1_bl
  set z3 := Function.update z2 8 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)); have bz3 : RegBounded W z3 := bz2.update (r := 8) (by decide) ha10_s1_bl
  have hz3_8 : wL.read (.heap 10 (z3 8)) = sD := by simp only [z3, Function.update_self]; exact hrwL_sD
  have q4 := RegExec.load (inp := inp) hfd_le bz3 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 10) (table := 10) (addr := 8) (by decide) (by decide) hn10 (by rw [hz3_8]; exact hsD_bl.trans hs_W)
  rw [hz3_8] at q4; set z4 := Function.update z3 10 sD; have bz4 : RegBounded W z4 := bz3.update (r := 10) (by decide) (hsD_bl.trans hs_W)
  have mz5 : z4 9 * z4 4 = sN * gL 4 := by simp [z4, z3, z2, z1]
  have q5 := RegExec.mul (inp := inp) hfd_le bz4 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 13) (a := 9) (b := 4) (by decide) (by decide) (by decide)
    (by rw [mz5]; exact bm_sN4.trans (by rw [hd_expand] at hV_W; clear * - hd_c2 hV_W; omega))
  rw [mz5] at q5; set z5 := Function.update z4 13 (sN * gL 4); have bz5 : RegBounded W z5 := bz4.update (r := 13) (by decide) (bm_sN4.trans (by rw [hd_expand] at hV_W; clear * - hd_c2 hV_W; omega))
  have mz6 : z5 3 * z5 10 = gL 3 * sD := by simp [z5, z4, z3, z2, z1]
  have q6 := RegExec.mul (inp := inp) hfd_le bz5 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 14) (a := 3) (b := 10) (by decide) (by decide) (by decide)
    (by rw [mz6]; exact bm_3sD.trans (by rw [hd_expand] at hV_W; rw [hd_c3]; clear * - hV_W; omega))
  rw [mz6] at q6; set z6 := Function.update z5 14 (gL 3 * sD); have bz6 : RegBounded W z6 := bz5.update (r := 14) (by decide) (bm_3sD.trans (by rw [hd_expand] at hV_W; rw [hd_c3]; clear * - hV_W; omega))
  have sz7 : z6 13 - z6 14 = V_num := by simp [z6, z5, V_num]
  have q7 := RegExec.sub (inp := inp) hfd_le bz6 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 13) (a := 13) (b := 14) (by decide) (by decide) (by decide)
    (by rw [sz7]; exact hVN_bnd.trans hV_W)
  rw [sz7] at q7; set z7 := Function.update z6 13 V_num; have bz7 : RegBounded W z7 := bz6.update (r := 13) (by decide) (hVN_bnd.trans hV_W)
  have mz8 : z7 10 * z7 4 = V_den := by simp [z7, z6, z5, z4, z3, z2, z1, V_den]
  have q8 := RegExec.mul (inp := inp) hfd_le bz7 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 14) (a := 10) (b := 4) (by decide) (by decide) (by decide)
    (by rw [mz8]; exact hVD_bnd.trans hV_W)
  rw [mz8] at q8; set z8 := Function.update z7 14 V_den; have bz8 : RegBounded W z8 := bz7.update (r := 14) (by decide) (hVD_bnd.trans hV_W)
  have q9 := RegExec.lit (inp := inp) hfd_le bz8 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 8) (c := (nodeStride : ℤ)) (by decide) hstride_bl
  set z9 := Function.update z8 8 (nodeStride : ℤ); have bz9 : RegBounded W z9 := bz8.update (r := 8) (by decide) hstride_bl
  have mz10 : z9 0 * z9 8 = ((j * nodeStride : ℕ) : ℤ) := by
    simp only [z9, z8, z7, z6, z5, z4, z3, z2, z1, Function.update_self,
      Function.update_of_ne (by decide : (0 : ℕ) ≠ 8), Function.update_of_ne (by decide : (0 : ℕ) ≠ 14),
      Function.update_of_ne (by decide : (0 : ℕ) ≠ 13), Function.update_of_ne (by decide : (0 : ℕ) ≠ 10),
      Function.update_of_ne (by decide : (0 : ℕ) ≠ 9), hgL0]
    push_cast; ring
  have q10 := RegExec.mul (inp := inp) hfd_le bz9 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 8) (a := 0) (b := 8) (by decide) (by decide) (by decide) (by rw [mz10]; exact hjs_bl0)
  rw [mz10] at q10; set z10 := Function.update z9 8 ((j * nodeStride : ℕ) : ℤ); have bz10 : RegBounded W z10 := bz9.update (r := 8) (by decide) hjs_bl0
  have q11 := RegExec.lit (inp := inp) hfd_le bz10 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 15) (c := 3) (by decide) hl3
  set z11 := Function.update z10 15 3; have bz11 : RegBounded W z11 := bz10.update (r := 15) (by decide) hl3
  have az12 : z11 8 + z11 15 = nodeCellAddr nodeStride j 3 := by
    simp only [z11, z10, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), nodeCellAddr]; push_cast; ring
  have q12 := RegExec.add (inp := inp) hfd_le bz11 (sp_ok hmL).1 (sp_ok hmL).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [az12]; exact hn3_bl)
  rw [az12] at q12; set z12 := Function.update z11 8 (nodeCellAddr nodeStride j 3); have bz12 : RegBounded W z12 := bz11.update (r := 8) (by decide) hn3_bl
  have hmV1 := hmL.write (hSub3 3 (by clear * -; omega)) V_num hn3_loc (hVN_bnd.trans hV_W)
  have hz12_13 : z12 13 = V_num := by simp [z12, z11, z10, z9, z8, z7]
  have q13 := RegExec.store (inp := inp) hfd_le bz12 (table := 3) (addr := 8) (val := 13) (by decide) (by decide) hn3
    (by simpa [z12, hz12_13] using (sp_ok hmV1).1) (by simpa [z12, hz12_13] using (sp_ok hmV1).2)
  have hwV1 : wL.write (.heap 3 (z12 8)) (z12 13) = wL.write (.heap 3 (nodeCellAddr nodeStride j 3)) V_num := by simp only [z12, Function.update_self, hz12_13]
  rw [hwV1] at q13; set wV1 := wL.write (.heap 3 (nodeCellAddr nodeStride j 3)) V_num
  have q14 := RegExec.lit (inp := inp) hfd_le bz12 (sp_ok hmV1).1 (sp_ok hmV1).2 (dst := 15) (c := 1) (by decide) hl1
  set z13 := Function.update z12 15 1; have bz13 : RegBounded W z13 := bz12.update (r := 15) (by decide) hl1
  have az15 : z13 8 + z13 15 = nodeCellAddr nodeStride j 4 := by
    simp only [z13, z12, Function.update_self, Function.update_of_ne (by decide : (8 : ℕ) ≠ 15), nodeCellAddr]; push_cast; ring
  have q15 := RegExec.add (inp := inp) hfd_le bz13 (sp_ok hmV1).1 (sp_ok hmV1).2 (dst := 8) (a := 8) (b := 15) (by decide) (by decide) (by decide) (by rw [az15]; exact hn4_bl)
  rw [az15] at q15; set z14 := Function.update z13 8 (nodeCellAddr nodeStride j 4); have bz14 : RegBounded W z14 := bz13.update (r := 8) (by decide) hn4_bl
  have hmEnd := hmV1.write (hSub3 4 (by clear * -; omega)) V_den hn4_loc (hVD_bnd.trans hV_W)
  have hz14_14 : z14 14 = V_den := by simp [z14, z13, z12, z11, z10, z9, z8]
  have q16 := RegExec.store (inp := inp) hfd_le bz14 (table := 3) (addr := 8) (val := 14) (by decide) (by decide) hn3
    (by simpa [z14, hz14_14] using (sp_ok hmEnd).1) (by simpa [z14, hz14_14] using (sp_ok hmEnd).2)
  have hwEnd : wV1.write (.heap 3 (z14 8)) (z14 14) = wV1.write (.heap 3 (nodeCellAddr nodeStride j 4)) V_den := by simp only [z14, Function.update_self, hz14_14]
  rw [hwEnd] at q16; set wsEnd := wV1.write (.heap 3 (nodeCellAddr nodeStride j 4)) V_den
  -- Total cost bound
  have hb_tot : 2 * W + 16 + (2 * W + 16 + (2 * W + 16 + (d * (56 * W * W) + W +
      (2 * W + 16 + (6 * W + 24 + (2 * W + 16 + (6 * W + 24 + (4 * W * W + (4 * W * W +
      (6 * W + 32 + (4 * W * W + (2 * W + 16 + (4 * W * W + (2 * W + 16 + (6 * W + 32 +
      (5 * W + 24 + (2 * W + 16 + (6 * W + 32 + (5 * W + 24))))))))))))))))))) ≤
      (60 * d + 36) * W * W := by
    calc _
      _ = 56 * d * (W * W) + (16 * (W * W) + 57 * W + 320) := by ring
      _ ≤ 56 * d * (W * W) + 36 * (W * W) := Nat.add_le_add_left (by linarith only [hW20, hWW]) _
      _ = (56 * d + 36) * W * W := by ring
      _ ≤ (60 * d + 36) * W * W := Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by clear * -; omega))
  have sTot := (hp1.seq (hp2.seq (hp3.seq (hRep.seq (q1.seq (q2.seq (q3.seq (q4.seq (q5.seq (q6.seq
    (q7.seq (q8.seq (q9.seq (q10.seq (q11.seq (q12.seq (q13.seq (q14.seq (q15.seq q16))))))))))))))))))).weaken rfl rfl
    (u₂ := 260 * d + 140) (b₂ := (60 * d + 36) * W * W) (by clear * -; omega) hb_tot
  -- Establish `NodeGeomStored` for `wsEnd`!
  have hBt : 1 ≤ 2 * (B_cert + 2) + 2 := by clear * -; omega
  have hbnds_term : ∀ i < d, 1 ≤ sqDen i ∧ intBitLength (sqNum i) ≤ 2 * (B_cert + 2) + 2 ∧ intBitLength (sqDen i) ≤ 2 * (B_cert + 2) + 2 := by
    intro i hi
    have ho_i := ho10 ⟨i, hi⟩; dsimp only at ho_i
    obtain ⟨hoD1, _, boN, boD⟩ := ho_i
    have hoDi : 1 ≤ oDen i := by simp [oDen, hi]; exact hoD1
    have h1 : 1 ≤ sqDen i := by dsimp [sqDen, zDen]; nlinarith only [hoDi]
    have bm1 : intBitLength (oNum i * zDen i) ≤ B_cert + 2 :=
      (intBitLength_mul_le _ _).trans (Nat.add_le_add (by simp only [oNum, if_pos hi]; exact boN) (by dsimp [zDen]; decide))
    have bm2 : intBitLength (zNum i * oDen i) ≤ B_cert + 2 := by
      have : zNum i * oDen i = 0 := by simp [zNum]
      rw [this]; exact (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by clear * -; omega)
    have bdf : intBitLength (oNum i * zDen i - zNum i * oDen i) ≤ B_cert + 3 := by
      have hs := intBitLength_sub_le_max (oNum i * zDen i) (zNum i * oDen i)
      have hm := max_le bm1 bm2
      clear * - hs hm; omega
    have bsN : intBitLength (sqNum i) ≤ 2 * (B_cert + 2) + 2 := by
      have := (intBitLength_mul_le _ _).trans (Nat.add_le_add bdf bdf)
      dsimp [sqNum]; clear * - this; omega
    have bpd : intBitLength (oDen i * zDen i) ≤ B_cert + 2 :=
      (intBitLength_mul_le _ _).trans (Nat.add_le_add (by simp only [oDen, if_pos hi]; exact boD) (by dsimp [zDen]; decide))
    have bsD : intBitLength (sqDen i) ≤ 2 * (B_cert + 2) + 2 := by
      have := (intBitLength_mul_le _ _).trans (Nat.add_le_add bpd bpd)
      dsimp [sqDen]; clear * - this; omega
    exact ⟨h1, bsN, bsD⟩
  obtain ⟨hden_pos, _, _, _, _⟩ := ratSumPairs_spec hBt d hbnds_term
  have hgL4_pos : 1 ≤ gL 4 := by rw [hgL4]; exact hden_pos
  have hVD_pos : 1 ≤ V_den := by dsimp [V_den]; nlinarith only [hsD1, hgL4_pos]
  have hnorm_o := ratPoint_distSq_eq (p := oRat) (q := fun _ => 0)
    (pNum := oNum) (pDen := oDen) (qNum := zNum) (qDen := zDen)
    (fun c => by
      have ho_c := ho10 c; dsimp only at ho_c
      exact ⟨by simp [oDen, c.isLt]; exact ho_c.1,
             by simp only [oNum, oDen, c.isLt, ↓reduceIte, ho_c.2.1]; push_cast; rfl⟩)
    (fun _ => ⟨by dsimp [zDen]; omega, by simp [zNum, zDen]⟩)
  have hzero_euc : ratPointToEuclidean (fun _ : Fin d => (0 : ℚ)) = 0 := by
    ext c; simp [ratPointToEuclidean]
  rw [hzero_euc, sub_zero] at hnorm_o
  have hV_eq : ((V_num : ℝ) / (V_den : ℝ)) = liftVariance (ratPointToEuclidean oRat) (sRat : ℝ) := by
    unfold liftVariance
    rw [← hnorm_o, ← hgL3, ← hgL4, hs_eq]
    have hsD_ne : (sD : ℝ) ≠ 0 := by exact_mod_cast (by clear * - hsD1; omega : sD ≠ 0)
    have hg4_ne : (gL 4 : ℝ) ≠ 0 := by exact_mod_cast (by clear * - hgL4_pos; omega : gL 4 ≠ 0)
    push_cast
    rw [div_sub_div _ _ hsD_ne hg4_ne]
    dsimp [V_num, V_den]; push_cast; ring
  have hVN_det : V_num = extractedVNum10 d T_max ws := by
    dsimp only [V_num, extractedVNum10, sN, sD, oNum, oDen, zNum, zDen, sqNum, sqDen] at hgL3 hgL4 ⊢
    rw [hgL3, hgL4]
  have hVD_det : V_den = extractedVDen10 d T_max ws := by
    dsimp only [V_den, extractedVDen10, sD, oNum, oDen, zNum, zDen, sqNum, sqDen] at hgL4 ⊢
    rw [hgL4]
  refine ⟨wsEnd, z14, V_num, V_den, sTot, hmEnd, bz14,
    by simp [z14, z13, z12, z11, z10, z9, z8, z7, z6, z5, z4, z3, z2, z1, hgL0],
    by simp [z14, z13, z12, z11, z10, z9, z8, z7, z6, z5, z4, z3, z2, z1, hgL5],
    hVN_det, hVD_det, ?_, ?_⟩
  · have hne34 : (.heap 3 (nodeCellAddr nodeStride j 3) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j 4) := by
      intro h; injection h with _ ha
      have h_eq := (nodeCellAddr_inj (by clear * - hstride; omega) (by clear * - hstride; omega) ha).2
      clear * - h_eq; omega
    refine
      { hV_nn := hV_nn
        hV_den := hVD_pos
        hV_eq := hV_eq
        hVN_bl := hVN_bnd
        hVD_bl := hVD_bnd
        read_VN := by simp only [wsEnd, wV1]; rw [wordStore_read_write_ne _ hne34]; simp
        read_VD := by simp [wsEnd]
        read_o := fun c => ?_ }
    have ho_c := ho10 c; dsimp only at ho_c
    obtain ⟨hoD1, ho_eq, boN, boD⟩ := ho_c
    obtain ⟨hr_oN, hr_oD⟩ := hreadO_L c.val c.isLt c.isLt
    have ne0_4 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j 4) := by
      intro h; injection h with _ ha
      have hc := c.isLt
      have h_eq := (nodeCellAddr_inj (by clear * - hc hstride; omega) (by clear * - hstride; omega) ha).2
      clear * - h_eq; omega
    have ne0_3 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j 3) := by
      intro h; injection h with _ ha
      have hc := c.isLt
      have h_eq := (nodeCellAddr_inj (by clear * - hc hstride; omega) (by clear * - hstride; omega) ha).2
      clear * - h_eq; omega
    have ne1_4 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val + 1)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j 4) := by
      intro h; injection h with _ ha
      have hc := c.isLt
      have h_eq := (nodeCellAddr_inj (by clear * - hc hstride; omega) (by clear * - hstride; omega) ha).2
      clear * - h_eq; omega
    have ne1_3 : (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val + 1)) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j 3) := by
      intro h; injection h with _ ha
      have hc := c.isLt
      have h_eq := (nodeCellAddr_inj (by clear * - hc hstride; omega) (by clear * - hstride; omega) ha).2
      clear * - h_eq; omega
    have eN : wsEnd.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val))) = oNum c.val := by
      simp only [wsEnd, wV1]
      rw [wordStore_read_write_ne _ ne0_4, wordStore_read_write_ne _ ne0_3]
      exact hr_oN
    have eD : wsEnd.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * c.val + 1))) = oDen c.val := by
      simp only [wsEnd, wV1]
      rw [wordStore_read_write_ne _ ne1_4, wordStore_read_write_ne _ ne1_3]
      exact hr_oD
    dsimp only
    rw [eN, eD]
    simp only [oNum, oDen, c.isLt, ↓reduceIte]
    exact ⟨hoD1, by rw [ho_eq]; push_cast; rfl, boN, boD⟩
  · intro loc hne
    have n3 : loc ≠ .heap 3 (nodeCellAddr nodeStride j 3) := hne 3 (by clear * -; omega)
    have n4 : loc ≠ .heap 3 (nodeCellAddr nodeStride j 4) := hne 4 (by clear * -; omega)
    have uL := hunchL loc hne
    exact ⟨by simp only [wsEnd, wV1, WordStore.write, Finset.mem_insert, n3, n4, false_or]; exact uL.1,
           by simp only [wsEnd, wV1, WordStore.write, Function.update_of_ne n4, Function.update_of_ne n3]; exact uL.2⟩


theorem extractedVar10_eq_c12ExtractedVar (d T_max : ℕ) (ws : WordStore)
    (outA2 : BitRAMExecOutcome)
    (htab1 : ∀ idx : ℤ, ws.read (.heap 10 (idx * (T_max : ℤ) + 1)) = outA2.words.read (.heap 1 idx)) :
    extractedVNum10 d T_max ws = c12ExtractedVNum d outA2 ∧
    extractedVDen10 d T_max ws = c12ExtractedVDen d outA2 := by
  have hoN : ∀ i : ℕ,
      (if i < d then ws.read (.heap 10 ((((2 * i) * T_max + 1 : ℕ) : ℤ))) else 0) =
      (if i < d then outA2.words.read (.heap 1 (2 * (i : ℤ))) else 0) := by
    intro i; split_ifs with hc
    · have ha : (((2 * i) * T_max + 1 : ℕ) : ℤ) = (2 * (i : ℤ)) * (T_max : ℤ) + 1 := by push_cast; ring
      rw [ha, htab1]
    · rfl
  have hoD : ∀ i : ℕ,
      (if i < d then ws.read (.heap 10 ((((2 * i + 1) * T_max + 1 : ℕ) : ℤ))) else 1) =
      (if i < d then outA2.words.read (.heap 1 (2 * (i : ℤ) + 1)) else 1) := by
    intro i; split_ifs with hc
    · have ha : (((2 * i + 1) * T_max + 1 : ℕ) : ℤ) = (2 * (i : ℤ) + 1) * (T_max : ℤ) + 1 := by push_cast; ring
      rw [ha, htab1]
    · rfl
  have hsN : ws.read (.heap 10 ((((2 * d) * T_max + 1 : ℕ) : ℤ))) = outA2.words.read (.heap 1 (2 * (d : ℤ))) := by
    have ha : (((2 * d) * T_max + 1 : ℕ) : ℤ) = (2 * (d : ℤ)) * (T_max : ℤ) + 1 := by push_cast; ring
    rw [ha, htab1]
  have hsD : ws.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ))) = outA2.words.read (.heap 1 (2 * (d : ℤ) + 1)) := by
    have ha : (((2 * d + 1) * T_max + 1 : ℕ) : ℤ) = (2 * (d : ℤ) + 1) * (T_max : ℤ) + 1 := by push_cast; ring
    rw [ha, htab1]
  unfold extractedVNum10 extractedVDen10 c12ExtractedVNum c12ExtractedVDen
  dsimp only
  simp_rw [hoN, hoD, hsN, hsD]
  exact ⟨rfl, rfl⟩

end UL.C12StepC2
