import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2b
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. `buildTab4Regs`: Populate `heap 4` Block-Ownership Map for Level `j` -/

def buildTab4InnerStepStmt : BitRAMStmt :=
  .seq (rLoad 6 3 2)
  (.seq (rAdd 7 1 6)
  (.seq (rStore 4 7 5)
        (rAdd 2 2 4)))

def buildTab4OuterStepStmt (s₀_d : ℕ) : BitRAMStmt :=
  .seq (.repeatN (.lit (s₀_d : ℤ)) buildTab4InnerStepStmt)
       (rAdd 5 5 4)

def buildTab4Regs (d s₀_d L : ℕ) : BitRAMStmt :=
  let nodeStride := posNodeStride d L
  .seq (rLit 10 10)
  (.seq (rLoad 0 0 10)
  (.seq (rLit 2 ((2 ^ L : ℕ) : ℤ))
  (.seq (rMul 1 0 2)
  (.seq (rLit 2 (nodeStride : ℤ))
  (.seq (rMul 2 0 2)
  (.seq (rLit 4 2)
  (.seq (rAdd 6 2 4)
  (.seq (rLoad 3 3 6)
  (.seq (rLit 4 ((6 + 2 * d : ℕ) : ℤ))
  (.seq (rAdd 2 2 4)
  (.seq (rLit 4 1)
  (.seq (rLit 5 1)
        (.repeatN (.readLocal 3 (.lit 0)) (buildTab4OuterStepStmt s₀_d))))))))))))))

theorem tab4_addr_bl {d L K_max j h W : ℕ}
    (hj : j ≤ K_max + 1) (hh : h ≤ 2 ^ L)
    (hW : natBitLength ((K_max + 2) * posNodeStride d L) + L + 16 ≤ W) :
    intBitLength (((j * 2 ^ L + h : ℕ) : ℤ)) ≤ W ∧
    (RAMCellLoc.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))).bitLength ≤ W := by
  have hle : j * 2 ^ L + h ≤ (K_max + 2) * posNodeStride d L := by
    have h1 : j * 2 ^ L + h ≤ (j + 1) * 2 ^ L := by rw [add_mul, one_mul]; omega
    have h2 : (j + 1) * 2 ^ L ≤ (K_max + 2) * 2 ^ L := Nat.mul_le_mul_right _ (by omega)
    have h3 : (K_max + 2) * 2 ^ L ≤ (K_max + 2) * posNodeStride d L :=
      Nat.mul_le_mul_left _ (by unfold posNodeStride; have := Nat.zero_le d; omega)
    exact le_trans h1 (le_trans h2 h3)
  have hbl : intBitLength (((j * 2 ^ L + h : ℕ) : ℤ)) ≤ natBitLength ((K_max + 2) * posNodeStride d L) + 2 := by
    have ha := intBitLength_ofNat_le (j * 2 ^ L + h)
    have hb := natBitLength_mono hle
    omega
  have hn4 : natBitLength 4 = 3 := by decide
  exact ⟨by omega, by dsimp only [RAMCellLoc.bitLength]; rw [hn4]; omega⟩

theorem exec_buildTab4Regs {d s₀_d : ℕ} (_hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws : WordStore}
    {L K_max j k_blk : ℕ}
    (hj : j ≤ K_max) (hk_le : k_blk * s₀_d ≤ 2 ^ L)
    (hW : natBitLength ((K_max + 2) * posNodeStride d L) + natBitLength (s₀_d + 1) + L + 32 ≤ W)
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hemp4 : ∀ h < 2 ^ L, (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ ws.live)
    (hr_j : ws.read (.heap 0 10) = (j : ℤ))
    (hr_k : ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j 2)) = (k_blk : ℤ))
    {bh : Fin k_blk → Fin s₀_d → ℕ}
    (hbh_lt : ∀ b t, bh b t < 2 ^ L)
    (hbh_inj : Function.Injective2 bh)
    (hread_bh : ∀ (b : Fin k_blk) (t : Fin s₀_d),
      ws.read (.heap 3 (nodeCellAddr (posNodeStride d L) j (6 + 2 * d + (b.val * s₀_d + t.val)))) =
        (bh b t : ℤ))
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (buildTab4Regs d s₀_d L) ws regs wsEnd regsEnd
        (k_blk * (32 * s₀_d + 16) + 120)
        ((k_blk * (28 * s₀_d + 12) + 80) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      (∀ h < 2 ^ L,
        (∃ (b : Fin k_blk) (t : Fin s₀_d),
          bh b t = h ∧
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ wsEnd.live ∧
          wsEnd.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) = ((b.val + 1 : ℕ) : ℤ)) ∨
        ((∀ (b : Fin k_blk) (t : Fin s₀_d), bh b t ≠ h) ∧
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ wsEnd.live)) ∧
      (∀ loc : RAMCellLoc, (∀ h < 2 ^ L, loc ≠ .heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  set nodeStride := posNodeStride d L
  have hW32 : 32 ≤ W := by clear * - hW; omega
  have hWW : 32 * W ≤ W * W := by nlinarith only [hW32]
  have hj1 : j ≤ K_max + 1 := Nat.le_succ_of_le hj
  have hW_node : natBitLength ((K_max + 2) * nodeStride) + 8 ≤ W := by clear * - hW; omega
  have hstride_p : ∀ p ≤ k_blk * s₀_d, 6 + 2 * d + p < nodeStride := by
    intro p hp; dsimp [nodeStride, posNodeStride]; clear * - hp hk_le; omega
  have hns_pos : 0 < nodeStride := Nat.lt_of_le_of_lt (Nat.zero_le _) (hstride_p 0 (Nat.zero_le _))
  have hW_t4 : natBitLength ((K_max + 2) * posNodeStride d L) + L + 16 ≤ W := by
    change natBitLength ((K_max + 2) * nodeStride) + L + 16 ≤ W; clear * - hW; omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by clear * - hW32; omega)
  have hl2 : intBitLength (2 : ℤ) ≤ W := (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by clear * - hW32; omega)
  have hl10 : intBitLength (10 : ℤ) ≤ W := (show intBitLength (10 : ℤ) = 5 from by decide).trans_le (by clear * - hW32; omega)
  have hn0 : natBitLength 0 ≤ W := (show natBitLength 0 = 1 from by decide).trans_le (by clear * - hW32; omega)
  have hn3 : natBitLength 3 ≤ W := (show natBitLength 3 = 2 from by decide).trans_le (by clear * - hW32; omega)
  have hn4 : natBitLength 4 ≤ W := (show natBitLength 4 = 3 from by decide).trans_le (by clear * - hW32; omega)
  have hp2L_bl : intBitLength ((2 ^ L : ℕ) : ℤ) ≤ W := (nat_pow2_bitLength_le L).trans (by clear * - hW; omega)
  have hj2L_bl : intBitLength (((j * 2 ^ L : ℕ) : ℤ)) ≤ W :=
    (tab4_addr_bl (W := W) hj1 (h := 0) (Nat.zero_le _) hW_t4).1
  have hstride_bl : intBitLength (nodeStride : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le nodeStride
    have h2 := natBitLength_mono (Nat.le_mul_of_pos_left nodeStride (show 0 < K_max + 2 from by clear * -; omega))
    clear * - h1 h2 hW; omega
  have h62d_bl : intBitLength (((6 + 2 * d : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono (Nat.le_of_lt (hstride_p 0 (Nat.zero_le _)))).trans hstride_bl
  obtain ⟨_, hn0_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 0) hns_pos hW_node
  obtain ⟨_, hn2_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 2) (by have := hstride_p 0 (Nat.zero_le _); clear * - this; omega) hW_node
  obtain ⟨_, hn62d_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 6 + 2 * d) (hstride_p 0 (Nat.zero_le _)) hW_node
  have hj_bl : intBitLength (j : ℤ) ≤ W := by
    have hj_le : j ≤ j * nodeStride + 0 := by have := Nat.le_mul_of_pos_right j hns_pos; clear * - this; omega
    exact (intBitLength_natCast_mono hj_le).trans hn0_bl
  have hk_le_p2 : k_blk ≤ 2 ^ L := le_trans (Nat.le_mul_of_pos_right k_blk hs₀1) hk_le
  have hk_bl : intBitLength (k_blk : ℤ) ≤ W := (intBitLength_natCast_mono hk_le_p2).trans hp2L_bl
  have hk1_bl : ∀ b ≤ k_blk, intBitLength (((b + 1 : ℕ) : ℤ)) ≤ W := by
    intro b hb
    have hlt : b + 1 < 2 ^ (L + 2) := by
      have hp : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
      have hp4 : 2 ^ (L + 2) = 4 * 2 ^ L := by rw [pow_add]; ring
      rw [hp4]; clear * - hb hk_le_p2 hp; omega
    exact (nat_lt_pow2_bitLength_le hlt).trans (by clear * - hW; omega)
  have hs0_bl : intBitLength (s₀_d : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le s₀_d
    have h2 := natBitLength_mono (Nat.le_add_right s₀_d 1)
    clear * - h1 h2 hW; omega
  have p1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 10) (by decide) hl10
  set g1 := Function.update regs 10 10; have bg1 := hbnd.update (r := 10) (by decide) hl10
  have hr_g1 : ws.read (.heap 0 (g1 10)) = (j : ℤ) := by simp [g1, hr_j]
  have p2 := (RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 0) (table := 0) (addr := 10) (by decide) (by decide) hn0 (hr_g1 ▸ hj_bl)).weaken rfl (by rw [hr_g1]) le_rfl le_rfl
  set g2 := Function.update g1 0 (j : ℤ); have bg2 := bg1.update (r := 0) (by decide) hj_bl
  have p3 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 2) (c := ((2 ^ L : ℕ) : ℤ)) (by decide) hp2L_bl
  set g3 := Function.update g2 2 ((2 ^ L : ℕ) : ℤ); have bg3 := bg2.update (r := 2) (by decide) hp2L_bl
  have em4 : g3 0 * g3 2 = (((j * 2 ^ L : ℕ) : ℤ)) := by simp [g3, g2]
  have p4 := (RegExec.mul (inp := inp) hfd_le bg3 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 1) (a := 0) (b := 2) (by decide) (by decide) (by decide) (em4 ▸ hj2L_bl)).weaken rfl (by rw [em4]) le_rfl le_rfl
  set g4 := Function.update g3 1 (((j * 2 ^ L : ℕ) : ℤ)); have bg4 := bg3.update (r := 1) (by decide) hj2L_bl
  have p5 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 2) (c := (nodeStride : ℤ)) (by decide) hstride_bl
  set g5 := Function.update g4 2 (nodeStride : ℤ); have bg5 := bg4.update (r := 2) (by decide) hstride_bl
  have em6 : g5 0 * g5 2 = nodeCellAddr nodeStride j 0 := by simp [g5, g4, g3, g2, nodeCellAddr]
  have p6 := (RegExec.mul (inp := inp) hfd_le bg5 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 2) (a := 0) (b := 2) (by decide) (by decide) (by decide) (em6 ▸ hn0_bl)).weaken rfl (by rw [em6]) le_rfl le_rfl
  set g6 := Function.update g5 2 (nodeCellAddr nodeStride j 0); have bg6 := bg5.update (r := 2) (by decide) hn0_bl
  have p7 := RegExec.lit (inp := inp) hfd_le bg6 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 4) (c := 2) (by decide) hl2
  set g7 := Function.update g6 4 2; have bg7 := bg6.update (r := 4) (by decide) hl2
  have ea8 : g7 2 + g7 4 = nodeCellAddr nodeStride j 2 := by simp [g7, g6, nodeCellAddr]
  have p8 := (RegExec.add (inp := inp) hfd_le bg7 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 6) (a := 2) (b := 4) (by decide) (by decide) (by decide) (ea8 ▸ hn2_bl)).weaken rfl (by rw [ea8]) le_rfl le_rfl
  set g8 := Function.update g7 6 (nodeCellAddr nodeStride j 2); have bg8 := bg7.update (r := 6) (by decide) hn2_bl
  have hr_g8 : ws.read (.heap 3 (g8 6)) = (k_blk : ℤ) := by simp [g8, hr_k]
  have p9 := (RegExec.load (inp := inp) hfd_le bg8 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 3) (table := 3) (addr := 6) (by decide) (by decide) hn3 (hr_g8 ▸ hk_bl)).weaken rfl (by rw [hr_g8]) le_rfl le_rfl
  set g9 := Function.update g8 3 (k_blk : ℤ); have bg9 := bg8.update (r := 3) (by decide) hk_bl
  have p10 := RegExec.lit (inp := inp) hfd_le bg9 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 4) (c := ((6 + 2 * d : ℕ) : ℤ)) (by decide) h62d_bl
  set g10 := Function.update g9 4 ((6 + 2 * d : ℕ) : ℤ); have bg10 := bg9.update (r := 4) (by decide) h62d_bl
  have ea11 : g10 2 + g10 4 = nodeCellAddr nodeStride j (6 + 2 * d) := by
    simp [g10, g9, g8, g7, g6, nodeCellAddr]
  have p11 := (RegExec.add (inp := inp) hfd_le bg10 (sp_ok hmod).1 (sp_ok hmod).2
    (dst := 2) (a := 2) (b := 4) (by decide) (by decide) (by decide) (ea11 ▸ hn62d_bl)).weaken rfl (by rw [ea11]) le_rfl le_rfl
  set g11 := Function.update g10 2 (nodeCellAddr nodeStride j (6 + 2 * d)); have bg11 := bg10.update (r := 2) (by decide) hn62d_bl
  have p12 := RegExec.lit (inp := inp) hfd_le bg11 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 4) (c := 1) (by decide) hl1
  set g12 := Function.update g11 4 1; have bg12 := bg11.update (r := 4) (by decide) hl1
  have p13 := RegExec.lit (inp := inp) hfd_le bg12 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 5) (c := 1) (by decide) hl1
  set g13 := Function.update g12 5 1; have bg13 := bg12.update (r := 5) (by decide) hl1
  let PrefixSpec (b t : ℕ) (w : WordStore) : Prop :=
    (∀ h < 2 ^ L,
      (∀ (b' : Fin k_blk) (t' : Fin s₀_d),
        (b'.val < b ∨ (b'.val = b ∧ t'.val < t)) → bh b' t' = h →
          (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∈ w.live ∧
          w.vals (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) = ((b'.val + 1 : ℕ) : ℤ)) ∧
      ((∀ (b' : Fin k_blk) (t' : Fin s₀_d),
          (b'.val < b ∨ (b'.val = b ∧ t'.val < t)) → bh b' t' ≠ h) →
        (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ∉ w.live)) ∧
    (∀ loc : RAMCellLoc, (∀ h < 2 ^ L, loc ≠ .heap 4 (((j * 2 ^ L + h : ℕ) : ℤ))) →
      (loc ∈ w.live ↔ loc ∈ ws.live) ∧ w.vals loc = ws.vals loc)
  let OuterInv : ℕ → WordStore → (ℕ → ℤ) → Prop := fun b w r =>
    b ≤ k_blk ∧
    ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
    RegBounded W r ∧
    r 1 = (((j * 2 ^ L : ℕ) : ℤ)) ∧
    r 2 = nodeCellAddr nodeStride j (6 + 2 * d + b * s₀_d) ∧
    r 4 = 1 ∧
    r 5 = (((b + 1 : ℕ) : ℤ)) ∧
    PrefixSpec b 0 w
  have hOuter0 : OuterInv 0 ws g13 := by
    refine ⟨Nat.zero_le _, hmod, bg13,
      by simp [g13, g12, g11, g10, g9, g8, g7, g6, g5, g4],
      by simp [g13, g12, g11],
      by simp [g13, g12],
      by simp [g13],
      ⟨fun h hh => ⟨fun _ _ hlt => by omega, fun _ => hemp4 h hh⟩,
       fun _ _ => ⟨Iff.rfl, rfl⟩⟩⟩
  obtain ⟨wsEnd, regsEnd, sLoop, hOuterEnd⟩ :=
    c2_repeatReg_inv (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      (cntReg := 3) (by decide) k_blk
      (by simp [g13, g12, g11, g10, g9])
      OuterInv hOuter0 bg13
      (U := 32 * s₀_d + 10) (B := (28 * s₀_d + 10) * W * W)
      (fun b hb w0 r0 ⟨_, hmw0, br0, hr0_1, hr0_2, hr0_4, hr0_5, hps0⟩ => by
        let InnerInv : ℕ → WordStore → (ℕ → ℤ) → Prop := fun t w r =>
          t ≤ s₀_d ∧
          ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
          RegBounded W r ∧
          r 1 = (((j * 2 ^ L : ℕ) : ℤ)) ∧
          r 2 = nodeCellAddr nodeStride j (6 + 2 * d + (b * s₀_d + t)) ∧
          r 4 = 1 ∧
          r 5 = (((b + 1 : ℕ) : ℤ)) ∧
          PrefixSpec b t w
        have hInner0 : InnerInv 0 w0 r0 :=
          ⟨Nat.zero_le _, hmw0, br0, hr0_1, by simpa using hr0_2, hr0_4, hr0_5, hps0⟩
        obtain ⟨wI, rI, sIn, ⟨_, hmwI, brI, hrI_1, hrI_2, hrI_4, hrI_5, hpsI⟩⟩ :=
          RegExec.c2_repeatLit_inv (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
            s₀_d hs0_bl InnerInv hInner0 br0 (U := 28) (B := 26 * W * W)
            (fun t ht w r ⟨_, hmw, br, hr1, hr2, hr4, hr5, ⟨hspec_h, hunch_w⟩⟩ => by
              let bf : Fin k_blk := ⟨b, hb⟩
              let tf : Fin s₀_d := ⟨t, ht⟩
              let h₀ := bh bf tf
              have hh₀_lt : h₀ < 2 ^ L := hbh_lt bf tf
              have hh₀_bl : intBitLength (h₀ : ℤ) ≤ W :=
                (nat_lt_pow2_bitLength_le hh₀_lt).trans (by clear * - hW; omega)
              obtain ⟨ha4_bl, hl4_bl⟩ := tab4_addr_bl (W := W) hj1 (Nat.le_of_lt hh₀_lt) hW_t4
              have hp_lt : b * s₀_d + t < k_blk * s₀_d := by
                have h1 : b * s₀_d + t < (b + 1) * s₀_d := by rw [add_mul, one_mul]; omega
                have h2 : (b + 1) * s₀_d ≤ k_blk * s₀_d := Nat.mul_le_mul_right s₀_d hb
                omega
              obtain ⟨_, hnp1_bl⟩ := nodeCellAddr_bl (W := W) hj1
                (off := 6 + 2 * d + (b * s₀_d + (t + 1))) (hstride_p _ hp_lt) hW_node
              have hrw_3 : w.read (.heap 3 (r 2)) = (h₀ : ℤ) := by
                rw [hr2, wordStore_read_eq_vals hmw.wf,
                    (hunch_w _ (fun _ _ h => by cases h)).2,
                    ← wordStore_read_eq_vals hmod.wf]
                exact hread_bh bf tf
              have q1 := (RegExec.load (inp := inp) hfd_le br (sp_ok hmw).1 (sp_ok hmw).2
                (dst := 6) (table := 3) (addr := 2) (by decide) (by decide) hn3 (hrw_3 ▸ hh₀_bl)).weaken
                rfl (by rw [hrw_3]) le_rfl le_rfl
              set u1 := Function.update r 6 (h₀ : ℤ); have bu1 := br.update (r := 6) (by decide) hh₀_bl
              have ea2 : u1 1 + u1 6 = (((j * 2 ^ L + h₀ : ℕ) : ℤ)) := by
                simp [u1, hr1]
              have q2 := (RegExec.add (inp := inp) hfd_le bu1 (sp_ok hmw).1 (sp_ok hmw).2
                (dst := 7) (a := 1) (b := 6) (by decide) (by decide) (by decide) (ea2 ▸ ha4_bl)).weaken
                rfl (by rw [ea2]) le_rfl le_rfl
              set u2 := Function.update u1 7 (((j * 2 ^ L + h₀ : ℕ) : ℤ))
              have bu2 := bu1.update (r := 7) (by decide) ha4_bl
              set w' := w.write (.heap 4 (((j * 2 ^ L + h₀ : ℕ) : ℤ))) (((b + 1 : ℕ) : ℤ))
              have hmw' : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w' :=
                hmw.write (mem_posDimWriteLocs_tab4 hj1 hh₀_lt) (((b + 1 : ℕ) : ℤ)) hl4_bl (hk1_bl b (Nat.le_of_lt hb))
              have hu2_7 : u2 7 = (((j * 2 ^ L + h₀ : ℕ) : ℤ)) := by simp [u2]
              have hu2_5 : u2 5 = (((b + 1 : ℕ) : ℤ)) := by simp [u2, u1, hr5]
              have q3 : RegExec inp fd W C_cell C_bit (rStore 4 7 5) w u2 w' u2 6 (5 * W + 24) :=
                (RegExec.store (inp := inp) hfd_le bu2 (table := 4) (addr := 7) (val := 5) (by decide) (by decide) hn4
                  (by simpa [u2, u1, hr5, w'] using (sp_ok hmw').1)
                  (by simpa [u2, u1, hr5, w'] using (sp_ok hmw').2)).weaken
                  (by simp [u2, u1, hr5, w']) rfl le_rfl le_rfl
              have ea4 : u2 2 + u2 4 = nodeCellAddr nodeStride j (6 + 2 * d + (b * s₀_d + (t + 1))) := by
                simp [u2, u1, hr2, hr4, nodeCellAddr]; ring
              have q4 := (RegExec.add (inp := inp) hfd_le bu2 (sp_ok hmw').1 (sp_ok hmw').2
                (dst := 2) (a := 2) (b := 4) (by decide) (by decide) (by decide) (ea4 ▸ hnp1_bl)).weaken
                rfl (by rw [ea4]) le_rfl le_rfl
              set u4 := Function.update u2 2 (nodeCellAddr nodeStride j (6 + 2 * d + (b * s₀_d + (t + 1))))
              have bu4 := bu2.update (r := 2) (by decide) hnp1_bl
              have qStep := (q1.seq (q2.seq (q3.seq q4))).weaken rfl rfl
                (u₂ := 28) (b₂ := 26 * W * W)
                (by clear * -; omega)
                (by
                  calc 6 * W + 24 + (6 * W + 32 + (5 * W + 24 + (6 * W + 32)))
                    _ ≤ 26 * (32 * W) := by clear * - hW32; omega
                    _ ≤ 26 * (W * W) := Nat.mul_le_mul_left 26 hWW
                    _ = 26 * W * W := by ring)
              refine ⟨w', u4, qStep, ht, hmw', bu4,
                by simp [u4, u2, u1, hr1],
                by simp [u4],
                by simp [u4, u2, u1, hr4],
                by simp [u4, u2, u1, hr5],
                ⟨fun h hh => ?_, fun loc hne => ?_⟩⟩
              · by_cases heq_h : h = h₀
                · subst heq_h
                  refine ⟨fun b' t' _ hbh_eq => ?_, fun hall => ?_⟩
                  · obtain ⟨rfl, _⟩ := hbh_inj hbh_eq
                    dsimp only [w', WordStore.write, bf]
                    exact ⟨Finset.mem_insert_self _ _, Function.update_self _ _ _⟩
                  · exfalso
                    exact hall bf tf (Or.inr ⟨rfl, Nat.lt_succ_self t⟩) rfl
                · have hne_loc : (.heap 4 (((j * 2 ^ L + h : ℕ) : ℤ)) : RAMCellLoc) ≠
                      .heap 4 (((j * 2 ^ L + h₀ : ℕ) : ℤ)) := by
                    intro hc; injection hc with _ ha
                    have hnat : j * 2 ^ L + h = j * 2 ^ L + h₀ := Int.ofNat.inj ha
                    exact heq_h (by omega)
                  obtain ⟨hp_in, hp_out⟩ := hspec_h h hh
                  refine ⟨fun b' t' hlt hbh_eq => ?_, fun hall => ?_⟩
                  · have hprev_lt : b'.val < b ∨ (b'.val = b ∧ t'.val < t) := by
                      rcases hlt with hb_lt | ⟨hb_eq, ht_lt⟩
                      · exact Or.inl hb_lt
                      · rcases Nat.lt_succ_iff_lt_or_eq.mp ht_lt with ht_lt' | ht_eq
                        · exact Or.inr ⟨hb_eq, ht_lt'⟩
                        · exfalso
                          have hbt : b' = bf ∧ t' = tf := ⟨Fin.ext hb_eq, Fin.ext ht_eq⟩
                          rw [hbt.1, hbt.2] at hbh_eq
                          exact heq_h hbh_eq.symm
                    obtain ⟨hm_w, hv_w⟩ := hp_in b' t' hprev_lt hbh_eq
                    dsimp only [w', WordStore.write]
                    exact ⟨Finset.mem_insert_of_mem hm_w, by rw [Function.update_of_ne hne_loc]; exact hv_w⟩
                  · have hprev_all : ∀ (b' : Fin k_blk) (t' : Fin s₀_d),
                        (b'.val < b ∨ (b'.val = b ∧ t'.val < t)) → bh b' t' ≠ h :=
                      fun b' t' hlt => hall b' t' (hlt.imp id (fun ⟨e, lt⟩ => ⟨e, Nat.lt_succ_of_lt lt⟩))
                    have hn_w := hp_out hprev_all
                    dsimp only [w', WordStore.write]
                    simp only [Finset.mem_insert, hne_loc, false_or]
                    exact hn_w
              · have hne0 := hne h₀ hh₀_lt
                have prev_u := hunch_w loc hne
                dsimp only [w', WordStore.write]
                exact ⟨by simp only [Finset.mem_insert, hne0, false_or]; exact prev_u.1,
                       by rw [Function.update_of_ne hne0]; exact prev_u.2⟩)
        have ea5 : rI 5 + rI 4 = (((b + 1 + 1 : ℕ) : ℤ)) := by rw [hrI_5, hrI_4]; push_cast; ring
        have sAdd5 := (RegExec.add (inp := inp) hfd_le brI (sp_ok hmwI).1 (sp_ok hmwI).2
          (dst := 5) (a := 5) (b := 4) (by decide) (by decide) (by decide)
          (ea5 ▸ hk1_bl (b + 1) hb)).weaken rfl (by rw [ea5]) le_rfl le_rfl
        set rNext := Function.update rI 5 (((b + 1 + 1 : ℕ) : ℤ))
        have brNext := brI.update (r := 5) (by decide) (hk1_bl (b + 1) hb)
        have hOutStep := (sIn.seq sAdd5).weaken rfl rfl
          (u₂ := 32 * s₀_d + 10) (b₂ := (28 * s₀_d + 10) * W * W)
          (by clear * -; omega)
          (by
            have h1 : s₀_d * (26 * W * W) ≤ 28 * s₀_d * W * W := by
              calc s₀_d * (26 * W * W) = (26 * s₀_d) * (W * W) := by ring
              _ ≤ (28 * s₀_d) * (W * W) := Nat.mul_le_mul_right (W * W) (by omega)
              _ = 28 * s₀_d * W * W := by ring
            have h2 : W + (6 * W + 32) ≤ 10 * W * W := by
              calc W + (6 * W + 32) ≤ 10 * (32 * W) := by clear * - hW32; omega
              _ ≤ 10 * (W * W) := Nat.mul_le_mul_left 10 hWW
              _ = 10 * W * W := by ring
            have h4 : (28 * s₀_d + 10) * W * W = 28 * s₀_d * W * W + 10 * W * W := by ring
            linarith only [h1, h2, h4])
        have haddr_eq : 6 + 2 * d + (b * s₀_d + s₀_d) = 6 + 2 * d + (b + 1) * s₀_d := by ring
        have hpsNext : PrefixSpec (b + 1) 0 wI := by
          refine ⟨fun h hh => ?_, hpsI.2⟩
          obtain ⟨hp_in, hp_out⟩ := hpsI.1 h hh
          have hiff : ∀ (b' : Fin k_blk) (t' : Fin s₀_d),
              (b'.val < b + 1 ∨ (b'.val = b + 1 ∧ t'.val < 0)) ↔
                (b'.val < b ∨ (b'.val = b ∧ t'.val < s₀_d)) := by
            intro b' t'
            have ht' := t'.isLt
            omega
          exact ⟨fun b' t' hlt => hp_in b' t' ((hiff b' t').mp hlt),
                 fun hall => hp_out (fun b' t' hlt => hall b' t' ((hiff b' t').mpr hlt))⟩
        exact ⟨wI, rNext, hOutStep, hb, hmwI, brNext,
          by simp [rNext, hrI_1],
          by simp [rNext, hrI_2, haddr_eq],
          by simp [rNext, hrI_4],
          by simp [rNext],
          hpsNext⟩)
  rcases hOuterEnd with ⟨_, hmEnd, brEnd, _, _, _, _, ⟨hspecEnd, hunchEnd⟩⟩
  have hTot := (p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq (p7.seq (p8.seq (p9.seq (p10.seq
    (p11.seq (p12.seq (p13.seq sLoop))))))))))))).weaken rfl rfl
    (u₂ := k_blk * (32 * s₀_d + 16) + 120)
    (b₂ := (k_blk * (28 * s₀_d + 12) + 80) * W * W)
    (by clear * -; nlinarith)
    (by
      have h1 : k_blk * ((28 * s₀_d + 10) * W * W) ≤ k_blk * (28 * s₀_d + 12) * W * W := by
        calc k_blk * ((28 * s₀_d + 10) * W * W) = (k_blk * (28 * s₀_d + 10)) * (W * W) := by ring
        _ ≤ (k_blk * (28 * s₀_d + 12)) * (W * W) := Nat.mul_le_mul_right (W * W) (Nat.mul_le_mul_left _ (by omega))
        _ = k_blk * (28 * s₀_d + 12) * W * W := by ring
      have h2 : 45 * W + 240 ≤ 72 * W * W := by
        calc 45 * W + 240 ≤ 72 * (32 * W) := by clear * - hW32; omega
        _ ≤ 72 * (W * W) := Nat.mul_le_mul_left 72 hWW
        _ = 72 * W * W := by ring
      have h3 : (k_blk * (28 * s₀_d + 12) + 80) * W * W =
          k_blk * (28 * s₀_d + 12) * W * W + 8 * W * W + 72 * W * W := by ring
      linarith only [h1, h2, h3])
  refine ⟨wsEnd, regsEnd, hTot, hmEnd, brEnd, fun h hh => ?_, hunchEnd⟩
  obtain ⟨hp_in, hp_out⟩ := hspecEnd h hh
  by_cases hex : ∃ (b : Fin k_blk) (t : Fin s₀_d), bh b t = h
  · rcases hex with ⟨b, t, hbh_eq⟩
    obtain ⟨hm_live, hv_eq⟩ := hp_in b t (Or.inl b.isLt) hbh_eq
    exact Or.inl ⟨b, t, hbh_eq, hm_live, hv_eq⟩
  · push_neg at hex
    exact Or.inr ⟨hex, hp_out (fun b t _ => hex b t)⟩

end UL.C12StepC2
