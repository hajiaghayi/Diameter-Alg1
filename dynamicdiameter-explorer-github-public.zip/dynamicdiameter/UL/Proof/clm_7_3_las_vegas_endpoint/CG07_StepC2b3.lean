import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG07_StepC2b2
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12StepC2

open UL.C12LVE

open UL
open UL.Proof_lem_A_1

theorem c2NodeGeomStored_unchanged_core {d nodeStride B_cert j : ℕ}
    {oRat : Fin d → ℚ} {V_num V_den : ℤ} {V : ℝ} {ws₁ ws₂ : WordStore}
    (h : NodeGeomStored d nodeStride B_cert j oRat V_num V_den V ws₁)
    (heq : ∀ off : ℕ, (off = 3 ∨ off = 4 ∨ (6 ≤ off ∧ off < 6 + 2 * d)) →
      ws₂.read (.heap 3 (nodeCellAddr nodeStride j off)) =
        ws₁.read (.heap 3 (nodeCellAddr nodeStride j off))) :
    NodeGeomStored d nodeStride B_cert j oRat V_num V_den V ws₂ :=
  { hV_nn := h.hV_nn
    hV_den := h.hV_den
    hV_eq := h.hV_eq
    hVN_bl := h.hVN_bl
    hVD_bl := h.hVD_bl
    read_VN := (heq 3 (Or.inl rfl)).trans h.read_VN
    read_VD := (heq 4 (Or.inr (Or.inl rfl))).trans h.read_VD
    read_o := fun c => by
      have hc := c.isLt
      have e0 := heq (6 + 2 * c.val) (Or.inr (Or.inr ⟨by omega, by omega⟩))
      have e1 := heq (6 + 2 * c.val + 1) (Or.inr (Or.inr ⟨by omega, by omega⟩))
      have ho := h.read_o c
      dsimp only at ho ⊢
      rwa [e0, e1] }

theorem c2_repeatReg_inv {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    {cntReg : ℕ} (hcnt : cntReg < 16) (N : ℕ)
    {ws₀ : WordStore} {regs₀ : ℕ → ℤ}
    (hcnt_eq : regs₀ cntReg = (N : ℤ))
    (Inv : ℕ → WordStore → (ℕ → ℤ) → Prop)
    (hInv0 : Inv 0 ws₀ regs₀)
    (hbnd0 : RegBounded W regs₀)
    {body : BitRAMStmt} {U B : ℕ}
    (hstep : ∀ i < N, ∀ w r, Inv i w r →
      ∃ w' r', RegExec inp fd W C_cell C_bit body w r w' r' U B ∧ Inv (i + 1) w' r') :
    ∃ wsN regsN,
      RegExec inp fd W C_cell C_bit (.repeatN (.readLocal cntReg (.lit 0)) body)
        ws₀ regs₀ wsN regsN (N * U + 4) (N * B + W + 12) ∧
      Inv N wsN regsN := by
  classical
  let seqP : ∀ i : ℕ, (i ≤ N → { p : WordStore × (ℕ → ℤ) // Inv i p.1 p.2 }) :=
    Nat.rec (fun _ => ⟨(ws₀, regs₀), hInv0⟩) (fun i prev hi =>
      let cur := prev (Nat.le_of_succ_le hi)
      let hEx := hstep i (Nat.lt_of_succ_le hi) cur.1.1 cur.1.2 cur.2
      let w' := Classical.choose hEx
      let hEx2 := Classical.choose_spec hEx
      ⟨(w', Classical.choose hEx2), (Classical.choose_spec hEx2).2⟩)
  let wsSeq : ℕ → WordStore := fun i => if hi : i ≤ N then (seqP i hi).1.1 else ws₀
  let regSeq : ℕ → ℕ → ℤ := fun i => if hi : i ≤ N then (seqP i hi).1.2 else regs₀
  have hw0 : wsSeq 0 = ws₀ := dif_pos (Nat.zero_le N)
  have hr0 : regSeq 0 = regs₀ := dif_pos (Nat.zero_le N)
  have hRep := RegExec.repeatReg (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    hcnt N wsSeq regSeq (by rw [hr0]; exact hcnt_eq) (by rw [hr0]; exact hbnd0)
    (fun i hi => by
      have hi_le : i ≤ N := Nat.le_of_lt hi
      have hi1_le : i + 1 ≤ N := hi
      have hws_i : wsSeq i = (seqP i hi_le).1.1 := dif_pos hi_le
      have hrg_i : regSeq i = (seqP i hi_le).1.2 := dif_pos hi_le
      have hws_i1 : wsSeq (i + 1) = (seqP (i + 1) hi1_le).1.1 := dif_pos hi1_le
      have hrg_i1 : regSeq (i + 1) = (seqP (i + 1) hi1_le).1.2 := dif_pos hi1_le
      rw [hws_i, hrg_i, hws_i1, hrg_i1]
      dsimp only [seqP]
      exact (Classical.choose_spec (Classical.choose_spec
        (hstep i hi (seqP i hi_le).1.1 (seqP i hi_le).1.2 (seqP i hi_le).2))).1)
  rw [hw0, hr0] at hRep
  have hwN : wsSeq N = (seqP N le_rfl).1.1 := dif_pos le_rfl
  have hrN : regSeq N = (seqP N le_rfl).1.2 := dif_pos le_rfl
  rw [hwN, hrN] at hRep
  exact ⟨(seqP N le_rfl).1.1, (seqP N le_rfl).1.2, hRep, (seqP N le_rfl).2⟩

theorem RegExec.c2_repeatLit_inv {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (N : ℕ) (hN_bl : intBitLength (N : ℤ) ≤ W)
    {ws₀ : WordStore} {regs₀ : ℕ → ℤ}
    (Inv : ℕ → WordStore → (ℕ → ℤ) → Prop)
    (hInv0 : Inv 0 ws₀ regs₀)
    (hbnd0 : RegBounded W regs₀)
    {body : BitRAMStmt} {U B : ℕ}
    (hstep : ∀ i < N, ∀ w r, Inv i w r →
      ∃ w' r', RegExec inp fd W C_cell C_bit body w r w' r' U B ∧ Inv (i + 1) w' r') :
    ∃ wsN regsN,
      RegExec inp fd W C_cell C_bit (.repeatN (.lit (N : ℤ)) body)
        ws₀ regs₀ wsN regsN (N * U + 2) (N * B + W) ∧
      Inv N wsN regsN := by
  classical
  let seqP : ∀ i : ℕ, (i ≤ N → { p : WordStore × (ℕ → ℤ) // Inv i p.1 p.2 }) :=
    Nat.rec (fun _ => ⟨(ws₀, regs₀), hInv0⟩) (fun i prev hi =>
      let cur := prev (Nat.le_of_succ_le hi)
      let hEx := hstep i (Nat.lt_of_succ_le hi) cur.1.1 cur.1.2 cur.2
      let w' := Classical.choose hEx
      let hEx2 := Classical.choose_spec hEx
      ⟨(w', Classical.choose hEx2), (Classical.choose_spec hEx2).2⟩)
  let wsSeq : ℕ → WordStore := fun i => if hi : i ≤ N then (seqP i hi).1.1 else ws₀
  let regSeq : ℕ → ℕ → ℤ := fun i => if hi : i ≤ N then (seqP i hi).1.2 else regs₀
  have hw0 : wsSeq 0 = ws₀ := dif_pos (Nat.zero_le N)
  have hr0 : regSeq 0 = regs₀ := dif_pos (Nat.zero_le N)
  have hRep := RegExec.repeatLit (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
    N hN_bl wsSeq regSeq (by rw [hr0]; exact hbnd0)
    (fun i hi => by
      have hi_le : i ≤ N := Nat.le_of_lt hi
      have hi1_le : i + 1 ≤ N := hi
      have hws_i : wsSeq i = (seqP i hi_le).1.1 := dif_pos hi_le
      have hrg_i : regSeq i = (seqP i hi_le).1.2 := dif_pos hi_le
      have hws_i1 : wsSeq (i + 1) = (seqP (i + 1) hi1_le).1.1 := dif_pos hi1_le
      have hrg_i1 : regSeq (i + 1) = (seqP (i + 1) hi1_le).1.2 := dif_pos hi1_le
      rw [hws_i, hrg_i, hws_i1, hrg_i1]
      dsimp only [seqP]
      exact (Classical.choose_spec (Classical.choose_spec
        (hstep i hi (seqP i hi_le).1.1 (seqP i hi_le).1.2 (seqP i hi_le).2))).1)
  rw [hw0, hr0] at hRep
  have hwN : wsSeq N = (seqP N le_rfl).1.1 := dif_pos le_rfl
  have hrN : regSeq N = (seqP N le_rfl).1.2 := dif_pos le_rfl
  rw [hwN, hrN] at hRep
  exact ⟨(seqP N le_rfl).1.1, (seqP N le_rfl).1.2, hRep, (seqP N le_rfl).2⟩

def copyBlockHandleStepStmt : BitRAMStmt :=
  .seq (rLoad 12 10 10)
  (.seq (rLoad 13 8 12)
  (.seq (rStore 3 6 13)
  (.seq (rAdd 6 6 5)
         (rAdd 10 10 11))))

def extractFullNodeFromA2Regs (d s₀_d nodeStride T_max : ℕ) : BitRAMStmt :=
  .seq (rLit 10 10)
  (.seq (rLoad 0 0 10)
  (.seq (extractNodeCenterAndVarRegs d nodeStride T_max)
  (.seq (rLit 2 (nodeStride : ℤ))
  (.seq (rMul 1 0 2)
  (.seq (rLit 3 0)
  (.seq (rStore 3 1 3)
  (.seq (rLit 10 110)
  (.seq (rLoad 4 9 10)
  (.seq (rLit 5 1)
  (.seq (rAdd 6 1 5)
  (.seq (rStore 3 6 4)
  (.seq (rLoad 7 10 3)
  (.seq (rAdd 6 6 5)
  (.seq (rStore 3 6 7)
  (.seq (rLit 9 (s₀_d : ℤ))
  (.seq (rMul 8 7 9)
  (.seq (rLit 9 ((6 + 2 * d : ℕ) : ℤ))
  (.seq (rAdd 6 1 9)
  (.seq (rLit 10 2)
  (.seq (rLit 11 (T_max : ℤ))
         (.repeatN (.readLocal 8 (.lit 0)) copyBlockHandleStepStmt)))))))))))))))))))))

theorem exec_extractFullNodeFromA2Regs {d s₀_d : ℕ} (hd1 : 1 ≤ d) (hs₀1 : 1 ≤ s₀_d)
    {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {ws : WordStore}
    {L B_cert K_max T_max j m k_blk : ℕ}
    (hBc1 : 1 ≤ B_cert) (hT3 : 3 ≤ T_max)
    (hj : j ≤ K_max) (hm_le : m ≤ 2 ^ L) (hk_le : k_blk * s₀_d ≤ m)
    (hW : (d + 1) * (2 * B_cert + 8) + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength ((2 ^ L + 2 * d + 4) * T_max) + natBitLength (s₀_d + 1) + L + 40 ≤ W)
    (hwf : WellFormedWS ws)
    (hcCeil : inp.inputCellSpace + ws.cellCount + posNodeStride d L + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws.bitSize + 2 * W * posNodeStride d L + 16 * (W + 12) ≤ C_bit)
    (hemp3 : ∀ off < posNodeStride d L,
      (.heap 3 (nodeCellAddr (posNodeStride d L) j off) : RAMCellLoc) ∉ ws.live)
    (hr_j : ws.read (.heap 0 10) = (j : ℤ))
    (hr_m : ws.read (.heap 9 110) = (m : ℤ))
    (hr_k : ws.read (.heap 10 0) = (k_blk : ℤ))
    {hSeq : ℕ → ℕ} (hhSeq_lt : ∀ r < m, hSeq r < 2 ^ L)
    (hbuf : ∀ r < m, ws.read (.heap 8 (r : ℤ)) = (hSeq r : ℤ))
    {rawIdx : ℕ → ℕ} (hraw_lt : ∀ p < k_blk * s₀_d, rawIdx p < m)
    (hraw_read : ∀ p < k_blk * s₀_d,
      ws.read (.heap 10 (((p * T_max + 2 : ℕ) : ℤ))) = (rawIdx p : ℤ))
    {oRat : Fin d → ℚ} {sRat : ℚ}
    (hV_nn : 0 ≤ liftVariance (ratPointToEuclidean oRat) (sRat : ℝ))
    (ho10 : ∀ c : Fin d,
      let oN := ws.read (.heap 10 ((((2 * c.val) * T_max + 1 : ℕ) : ℤ)))
      let oD := ws.read (.heap 10 ((((2 * c.val + 1) * T_max + 1 : ℕ) : ℤ)))
      1 ≤ oD ∧ oRat c = (oN : ℚ) / (oD : ℚ) ∧
      intBitLength oN ≤ B_cert ∧ intBitLength oD ≤ B_cert)
    (hs10 :
      let sN := ws.read (.heap 10 ((((2 * d) * T_max + 1 : ℕ) : ℤ)))
      let sD := ws.read (.heap 10 ((((2 * d + 1) * T_max + 1 : ℕ) : ℤ)))
      1 ≤ sD ∧ sRat = (sN : ℚ) / (sD : ℚ) ∧
      intBitLength sN ≤ B_cert ∧ intBitLength sD ≤ B_cert)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    let nodeStride := posNodeStride d L
    let locs := level3WriteLocs nodeStride j
    let V_num := extractedVNum10 d T_max ws
    let V_den := extractedVDen10 d T_max ws
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (extractFullNodeFromA2Regs d s₀_d nodeStride T_max)
        ws regs wsEnd regsEnd
        (260 * d + 40 * (k_blk * s₀_d) + 320)
        ((60 * d + 40 * (k_blk * s₀_d) + 180) * W * W) ∧
      ModifiedOnBounded ws locs W wsEnd ∧
      RegBounded W regsEnd ∧
      NodeGeomStored d nodeStride B_cert j oRat V_num V_den
        (liftVariance (ratPointToEuclidean oRat) (sRat : ℝ)) wsEnd ∧
      wsEnd.read (.heap 3 (nodeCellAddr nodeStride j 0)) = 0 ∧
      wsEnd.read (.heap 3 (nodeCellAddr nodeStride j 1)) = (m : ℤ) ∧
      wsEnd.read (.heap 3 (nodeCellAddr nodeStride j 2)) = (k_blk : ℤ) ∧
      (∀ p < k_blk * s₀_d,
        wsEnd.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * d + p))) =
          (hSeq (rawIdx p) : ℤ)) ∧
      (∀ off : ℕ, 6 + 2 * d + k_blk * s₀_d ≤ off → off < nodeStride →
        (.heap 3 (nodeCellAddr nodeStride j off) : RAMCellLoc) ∉ wsEnd.live) ∧
      (∀ loc : RAMCellLoc, loc ∉ locs →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  dsimp only
  set nodeStride := posNodeStride d L
  set locs := level3WriteLocs nodeStride j
  set V_num := extractedVNum10 d T_max ws
  set V_den := extractedVDen10 d T_max ws
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hWW : 40 * W ≤ W * W := by nlinarith only [hW40]
  have hj1 : j ≤ K_max + 1 := Nat.le_succ_of_le hj
  have hstride : 6 + 2 * d ≤ nodeStride := by
    have : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
    dsimp [nodeStride, posNodeStride]; clear * - this; omega
  have hstride_p : ∀ p ≤ k_blk * s₀_d, 6 + 2 * d + p < nodeStride := by
    intro p hp; dsimp [nodeStride, posNodeStride]; clear * - hp hk_le hm_le; omega
  have hns_pos : 0 < nodeStride := Nat.lt_of_le_of_lt (Nat.zero_le _) (hstride_p 0 (Nat.zero_le _))
  have hW_node : natBitLength ((K_max + 2) * nodeStride) + 8 ≤ W := by clear * - hW; omega
  have hcardL : locs.card ≤ nodeStride := card_level3WriteLocs_le nodeStride j
  have hcCeilL : inp.inputCellSpace + ws.cellCount + locs.card + 16 ≤ C_cell := by
    linarith only [hcardL, hcCeil]
  have hbCeilL : inp.inputBitSpace + ws.bitSize + 2 * W * locs.card + 16 * (W + 12) ≤ C_bit := by
    have : 2 * W * locs.card ≤ 2 * W * nodeStride := Nat.mul_le_mul_left _ hcardL
    linarith only [this, hbCeil]
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws locs W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeilL], by linarith only [bs, hbCeilL]⟩
  have hmod0 : ModifiedOnBounded ws locs W ws :=
    ModifiedOnBounded.refl hwf locs W (fun loc hlive hmem => by
      dsimp only [locs] at hmem; unfold level3WriteLocs at hmem
      rcases Finset.mem_image.mp hmem with ⟨off, hoff, rfl⟩
      exact absurd hlive (hemp3 off (Finset.mem_range.mp hoff)))
  have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by clear * - hW40; omega)
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by clear * - hW40; omega)
  have hl2 : intBitLength (2 : ℤ) ≤ W := (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by clear * - hW40; omega)
  have hl10 : intBitLength (10 : ℤ) ≤ W := (show intBitLength (10 : ℤ) = 5 from by decide).trans_le (by clear * - hW40; omega)
  have hl110 : intBitLength (110 : ℤ) ≤ W := (show intBitLength (110 : ℤ) = 8 from by decide).trans_le (by clear * - hW40; omega)
  have hn0 : natBitLength 0 ≤ W := (show natBitLength 0 = 1 from by decide).trans_le (by clear * - hW40; omega)
  have hn3 : natBitLength 3 ≤ W := (show natBitLength 3 = 2 from by decide).trans_le (by clear * - hW40; omega)
  have hn8 : natBitLength 8 ≤ W := (show natBitLength 8 = 4 from by decide).trans_le (by clear * - hW40; omega)
  have hn9 : natBitLength 9 ≤ W := (show natBitLength 9 = 4 from by decide).trans_le (by clear * - hW40; omega)
  have hn10 : natBitLength 10 ≤ W := (show natBitLength 10 = 4 from by decide).trans_le (by clear * - hW40; omega)
  have hj_bl : intBitLength (j : ℤ) ≤ W := by
    have hj_le : j ≤ j * nodeStride + 0 := by
      have := Nat.le_mul_of_pos_right j hns_pos; clear * - this; omega
    exact (intBitLength_natCast_mono hj_le).trans (nodeCellAddr_bl (W := W) hj1 hns_pos hW_node).2
  have hstride_bl : intBitLength (nodeStride : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le nodeStride
    have h2 := natBitLength_mono (Nat.le_mul_of_pos_left nodeStride (show 0 < K_max + 2 from by clear * -; omega))
    clear * - h1 h2 hW; omega
  have h62d_bl : intBitLength (((6 + 2 * d : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono hstride).trans hstride_bl
  have hm_bl : intBitLength (m : ℤ) ≤ W := by
    have hm_lt : m < 2 ^ (L + 1) := by
      have hp : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
      rw [pow_succ]; clear * - hm_le hp; omega
    exact (nat_lt_pow2_bitLength_le hm_lt).trans (by clear * - hW; omega)
  have htotal_bl : intBitLength (((k_blk * s₀_d : ℕ) : ℤ)) ≤ W :=
    (intBitLength_natCast_mono hk_le).trans hm_bl
  have hk_bl : intBitLength (k_blk : ℤ) ≤ W :=
    (intBitLength_natCast_mono (Nat.le_mul_of_pos_right k_blk hs₀1)).trans htotal_bl
  have hs0_bl : intBitLength (s₀_d : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le s₀_d
    have h2 := natBitLength_mono (Nat.le_add_right s₀_d 1)
    clear * - h1 h2 hW; omega
  have h10_ceil_bl : intBitLength ((((2 ^ L + 2 * d + 4) * T_max : ℕ) : ℤ)) ≤ W := by
    have h1 := intBitLength_ofNat_le ((2 ^ L + 2 * d + 4) * T_max)
    clear * - h1 hW; omega
  have hT_bl : intBitLength (T_max : ℤ) ≤ W :=
    (intBitLength_natCast_mono (Nat.le_mul_of_pos_left T_max (by positivity))).trans h10_ceil_bl
  -- 1..2: rLit 10 10; rLoad 0 0 10
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod0).1 (sp_ok hmod0).2 (dst := 10) (c := 10) (by decide) hl10
  set g1 := Function.update regs 10 10; have bg1 := hbnd.update (r := 10) (by decide) hl10
  have hr_g1 : ws.read (.heap 0 (g1 10)) = (j : ℤ) := by simp [g1, hr_j]
  have s2 := (RegExec.load (inp := inp) hfd_le bg1 (sp_ok hmod0).1 (sp_ok hmod0).2
    (dst := 0) (table := 0) (addr := 10) (by decide) (by decide) hn0 (hr_g1 ▸ hj_bl)).weaken
    rfl (by rw [hr_g1]) le_rfl le_rfl
  set g2 := Function.update g1 0 (j : ℤ); have bg2 := bg1.update (r := 0) (by decide) hj_bl
  -- 3: extractNodeCenterAndVarRegs d nodeStride T_max
  have hW_geom : (d + 1) * (2 * B_cert + 8) + natBitLength ((K_max + 2) * nodeStride) +
      natBitLength ((2 * d + 2) * T_max) + 32 ≤ W := by
    have hm : natBitLength ((2 * d + 2) * T_max) ≤ natBitLength ((2 ^ L + 2 * d + 4) * T_max) :=
      natBitLength_mono (Nat.mul_le_mul_right T_max (by have := Nat.zero_le (2 ^ L); omega))
    clear * - hm hW; omega
  obtain ⟨wB, gB, VN, VD, s3, hmB, bgB, hgB0, _, hVN_eq, hVD_eq, hgeomB, hunchB⟩ :=
    exec_extractNodeCenterAndVarRegs_det hd1 hfd_le hmod0 hcCeilL hbCeilL hBc1 (by clear * - hT3; omega) hj1 hstride
      hW_geom hV_nn ho10 hs10
      (fun off hoff => mem_level3WriteLocs (lt_of_lt_of_le hoff hstride)) bg2 (by simp [g2])
  rw [show VN = V_num from hVN_eq, show VD = V_den from hVD_eq] at hgeomB
  -- 4..21: write metadata (off 0, 1, 2) and prepare loop registers
  obtain ⟨hn0_loc, hn0_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 0) hns_pos hW_node
  obtain ⟨hn1_loc, hn1_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 1) (by have := hstride_p 0 (Nat.zero_le _); clear * - this; omega) hW_node
  obtain ⟨hn2_loc, hn2_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 2) (by have := hstride_p 0 (Nat.zero_le _); clear * - this; omega) hW_node
  obtain ⟨_, hn62d_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 6 + 2 * d) (hstride_p 0 (Nat.zero_le _)) hW_node
  have s4 := RegExec.lit (inp := inp) hfd_le bgB (sp_ok hmB).1 (sp_ok hmB).2 (dst := 2) (c := (nodeStride : ℤ)) (by decide) hstride_bl
  set r4 := Function.update gB 2 (nodeStride : ℤ); have br4 := bgB.update (r := 2) (by decide) hstride_bl
  have em5 : r4 0 * r4 2 = nodeCellAddr nodeStride j 0 := by
    simp [r4, hgB0, nodeCellAddr]
  have s5 := (RegExec.mul (inp := inp) hfd_le br4 (sp_ok hmB).1 (sp_ok hmB).2
    (dst := 1) (a := 0) (b := 2) (by decide) (by decide) (by decide) (em5 ▸ hn0_bl)).weaken
    rfl (by rw [em5]) le_rfl le_rfl
  set r5 := Function.update r4 1 (nodeCellAddr nodeStride j 0); have br5 := br4.update (r := 1) (by decide) hn0_bl
  have s6 := RegExec.lit (inp := inp) hfd_le br5 (sp_ok hmB).1 (sp_ok hmB).2 (dst := 3) (c := 0) (by decide) hl0
  set r6 := Function.update r5 3 0; have br6 := br5.update (r := 3) (by decide) hl0
  set wC1 := wB.write (.heap 3 (nodeCellAddr nodeStride j 0)) 0
  have hmC1 : ModifiedOnBounded ws locs W wC1 :=
    hmB.write (mem_level3WriteLocs hns_pos) 0 hn0_loc hl0
  have s7 : RegExec inp fd W C_cell C_bit (rStore 3 1 3) wB r6 wC1 r6 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le br6 (table := 3) (addr := 1) (val := 3) (by decide) (by decide) hn3
      (by simpa [r6, r5] using (sp_ok hmC1).1) (by simpa [r6, r5] using (sp_ok hmC1).2)).weaken
      (by simp [r6, r5, wC1]) rfl le_rfl le_rfl
  have s8 := RegExec.lit (inp := inp) hfd_le br6 (sp_ok hmC1).1 (sp_ok hmC1).2 (dst := 10) (c := 110) (by decide) hl110
  set r8 := Function.update r6 10 110; have br8 := br6.update (r := 10) (by decide) hl110
  have hrC1_m : wC1.read (.heap 9 (r8 10)) = (m : ℤ) := by
    simp only [r8, Function.update_self, wC1]
    rw [wordStore_read_write_ne _ (fun h => by cases h), wordStore_read_eq_vals hmB.wf,
        (hunchB _ (fun _ _ h => by cases h)).2, ← wordStore_read_eq_vals hwf]
    exact hr_m
  have s9 := (RegExec.load (inp := inp) hfd_le br8 (sp_ok hmC1).1 (sp_ok hmC1).2
    (dst := 4) (table := 9) (addr := 10) (by decide) (by decide) hn9 (hrC1_m ▸ hm_bl)).weaken
    rfl (by rw [hrC1_m]) le_rfl le_rfl
  set r9 := Function.update r8 4 (m : ℤ); have br9 := br8.update (r := 4) (by decide) hm_bl
  have s10 := RegExec.lit (inp := inp) hfd_le br9 (sp_ok hmC1).1 (sp_ok hmC1).2 (dst := 5) (c := 1) (by decide) hl1
  set r10 := Function.update r9 5 1; have br10 := br9.update (r := 5) (by decide) hl1
  have ea11 : r10 1 + r10 5 = nodeCellAddr nodeStride j 1 := by
    simp [r10, r9, r8, r6, r5, nodeCellAddr]
  have s11 := (RegExec.add (inp := inp) hfd_le br10 (sp_ok hmC1).1 (sp_ok hmC1).2
    (dst := 6) (a := 1) (b := 5) (by decide) (by decide) (by decide) (ea11 ▸ hn1_bl)).weaken
    rfl (by rw [ea11]) le_rfl le_rfl
  set r11 := Function.update r10 6 (nodeCellAddr nodeStride j 1); have br11 := br10.update (r := 6) (by decide) hn1_bl
  set wC2 := wC1.write (.heap 3 (nodeCellAddr nodeStride j 1)) (m : ℤ)
  have hmC2 : ModifiedOnBounded ws locs W wC2 :=
    hmC1.write (mem_level3WriteLocs (by have := hstride_p 0 (Nat.zero_le _); clear * - this; omega)) (m : ℤ) hn1_loc hm_bl
  have s12 : RegExec inp fd W C_cell C_bit (rStore 3 6 4) wC1 r11 wC2 r11 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le br11 (table := 3) (addr := 6) (val := 4) (by decide) (by decide) hn3
      (by simpa [r11, r10, r9] using (sp_ok hmC2).1) (by simpa [r11, r10, r9] using (sp_ok hmC2).2)).weaken
      (by simp [r11, r10, r9, wC2]) rfl le_rfl le_rfl
  have hrC2_k : wC2.read (.heap 10 (r11 3)) = (k_blk : ℤ) := by
    have hr3 : r11 3 = 0 := by simp [r11, r10, r9, r8, r6]
    rw [hr3]
    dsimp [wC2, wC1]
    rw [wordStore_read_write_ne _ (fun h => by cases h), wordStore_read_write_ne _ (fun h => by cases h),
        wordStore_read_eq_vals hmB.wf, (hunchB _ (fun _ _ h => by cases h)).2,
        ← wordStore_read_eq_vals hwf]
    exact hr_k
  have s13 := (RegExec.load (inp := inp) hfd_le br11 (sp_ok hmC2).1 (sp_ok hmC2).2
    (dst := 7) (table := 10) (addr := 3) (by decide) (by decide) hn10 (hrC2_k ▸ hk_bl)).weaken
    rfl (by rw [hrC2_k]) le_rfl le_rfl
  set r13 := Function.update r11 7 (k_blk : ℤ); have br13 := br11.update (r := 7) (by decide) hk_bl
  have ea14 : r13 6 + r13 5 = nodeCellAddr nodeStride j 2 := by
    simp [r13, r11, r10, nodeCellAddr]; ring
  have s14 := (RegExec.add (inp := inp) hfd_le br13 (sp_ok hmC2).1 (sp_ok hmC2).2
    (dst := 6) (a := 6) (b := 5) (by decide) (by decide) (by decide) (ea14 ▸ hn2_bl)).weaken
    rfl (by rw [ea14]) le_rfl le_rfl
  set r14 := Function.update r13 6 (nodeCellAddr nodeStride j 2); have br14 := br13.update (r := 6) (by decide) hn2_bl
  set wC3 := wC2.write (.heap 3 (nodeCellAddr nodeStride j 2)) (k_blk : ℤ)
  have hmC3 : ModifiedOnBounded ws locs W wC3 :=
    hmC2.write (mem_level3WriteLocs (by have := hstride_p 0 (Nat.zero_le _); clear * - this; omega)) (k_blk : ℤ) hn2_loc hk_bl
  have s15 : RegExec inp fd W C_cell C_bit (rStore 3 6 7) wC2 r14 wC3 r14 6 (5 * W + 24) :=
    (RegExec.store (inp := inp) hfd_le br14 (table := 3) (addr := 6) (val := 7) (by decide) (by decide) hn3
      (by simpa [r14, r13] using (sp_ok hmC3).1) (by simpa [r14, r13] using (sp_ok hmC3).2)).weaken
      (by simp [r14, r13, wC3]) rfl le_rfl le_rfl
  have s16 := RegExec.lit (inp := inp) hfd_le br14 (sp_ok hmC3).1 (sp_ok hmC3).2 (dst := 9) (c := (s₀_d : ℤ)) (by decide) hs0_bl
  set r16 := Function.update r14 9 (s₀_d : ℤ); have br16 := br14.update (r := 9) (by decide) hs0_bl
  have em17 : r16 7 * r16 9 = ((k_blk * s₀_d : ℕ) : ℤ) := by
    simp [r16, r14, r13]
  have s17 := (RegExec.mul (inp := inp) hfd_le br16 (sp_ok hmC3).1 (sp_ok hmC3).2
    (dst := 8) (a := 7) (b := 9) (by decide) (by decide) (by decide) (em17 ▸ htotal_bl)).weaken
    rfl (by rw [em17]) le_rfl le_rfl
  set r17 := Function.update r16 8 ((k_blk * s₀_d : ℕ) : ℤ); have br17 := br16.update (r := 8) (by decide) htotal_bl
  have s18 := RegExec.lit (inp := inp) hfd_le br17 (sp_ok hmC3).1 (sp_ok hmC3).2 (dst := 9) (c := ((6 + 2 * d : ℕ) : ℤ)) (by decide) h62d_bl
  set r18 := Function.update r17 9 ((6 + 2 * d : ℕ) : ℤ); have br18 := br17.update (r := 9) (by decide) h62d_bl
  have ea19 : r18 1 + r18 9 = nodeCellAddr nodeStride j (6 + 2 * d) := by
    simp [r18, r17, r16, r14, r13, r11, r10, r9, r8, r6, r5, nodeCellAddr]
  have s19 := (RegExec.add (inp := inp) hfd_le br18 (sp_ok hmC3).1 (sp_ok hmC3).2
    (dst := 6) (a := 1) (b := 9) (by decide) (by decide) (by decide) (ea19 ▸ hn62d_bl)).weaken
    rfl (by rw [ea19]) le_rfl le_rfl
  set r19 := Function.update r18 6 (nodeCellAddr nodeStride j (6 + 2 * d)); have br19 := br18.update (r := 6) (by decide) hn62d_bl
  have s20 := RegExec.lit (inp := inp) hfd_le br19 (sp_ok hmC3).1 (sp_ok hmC3).2 (dst := 10) (c := 2) (by decide) hl2
  set r20 := Function.update r19 10 2; have br20 := br19.update (r := 10) (by decide) hl2
  have s21 := RegExec.lit (inp := inp) hfd_le br20 (sp_ok hmC3).1 (sp_ok hmC3).2 (dst := 11) (c := (T_max : ℤ)) (by decide) hT_bl
  set r21 := Function.update r20 11 (T_max : ℤ); have br21 := br20.update (r := 11) (by decide) hT_bl
  have ne_addr : ∀ {a b : ℕ}, a < nodeStride → b < nodeStride → a ≠ b →
      (.heap 3 (nodeCellAddr nodeStride j a) : RAMCellLoc) ≠ .heap 3 (nodeCellAddr nodeStride j b) := by
    intro a b ha hb hne h; injection h with _ ha_eq
    exact hne (nodeCellAddr_inj ha hb ha_eq).2
  have hunchC3_hi : ∀ loc : RAMCellLoc,
      (∀ off < 6 + 2 * d, loc ≠ .heap 3 (nodeCellAddr nodeStride j off)) →
      (loc ∈ wC3.live ↔ loc ∈ ws.live) ∧ wC3.vals loc = ws.vals loc := by
    intro loc hne
    have n0 := hne 0 (by clear * -; omega)
    have n1 := hne 1 (by clear * -; omega)
    have n2 := hne 2 (by clear * -; omega)
    have uB := hunchB loc hne
    exact ⟨by simp only [wC3, wC2, wC1, WordStore.write, Finset.mem_insert, n2, n1, n0, false_or]; exact uB.1,
           by simp only [wC3, wC2, wC1, WordStore.write, Function.update_of_ne n2, Function.update_of_ne n1, Function.update_of_ne n0]; exact uB.2⟩
  have hgeomC3 : NodeGeomStored d nodeStride B_cert j oRat V_num V_den
      (liftVariance (ratPointToEuclidean oRat) (sRat : ℝ)) wC3 := by
    refine c2NodeGeomStored_unchanged_core hgeomB (fun off hoff => ?_)
    have hoff_lt : off < nodeStride := by
      have h0 := hstride_p 0 (Nat.zero_le _)
      clear * - hoff h0; omega
    have n2 := ne_addr hoff_lt (by have := hstride_p 0 (Nat.zero_le _); clear * - this; omega) (by clear * - hoff; omega : off ≠ 2)
    have n1 := ne_addr hoff_lt (by have := hstride_p 0 (Nat.zero_le _); clear * - this; omega) (by clear * - hoff; omega : off ≠ 1)
    have n0 := ne_addr hoff_lt hns_pos (by clear * - hoff; omega : off ≠ 0)
    dsimp only [wC3, wC2, wC1]
    rw [wordStore_read_write_ne _ n2, wordStore_read_write_ne _ n1, wordStore_read_write_ne _ n0]
  have hrC3_0 : wC3.read (.heap 3 (nodeCellAddr nodeStride j 0)) = 0 := by
    have h0 := hstride_p 0 (Nat.zero_le _)
    dsimp only [wC3, wC2, wC1]
    rw [wordStore_read_write_ne _ (ne_addr hns_pos (by clear * - h0; omega) (by decide)),
        wordStore_read_write_ne _ (ne_addr hns_pos (by clear * - h0; omega) (by decide)),
        wordStore_read_write_self]
  have hrC3_1 : wC3.read (.heap 3 (nodeCellAddr nodeStride j 1)) = (m : ℤ) := by
    have h0 := hstride_p 0 (Nat.zero_le _)
    dsimp only [wC3, wC2]
    rw [wordStore_read_write_ne _ (ne_addr (by clear * - h0; omega) (by clear * - h0; omega) (by decide)),
        wordStore_read_write_self]
  have hrC3_2 : wC3.read (.heap 3 (nodeCellAddr nodeStride j 2)) = (k_blk : ℤ) := by
    dsimp only [wC3]; rw [wordStore_read_write_self]
  -- 22: repeatN (k_blk * s₀_d) copyBlockHandleStepStmt
  let N_blk := k_blk * s₀_d
  let BlkInv : ℕ → WordStore → (ℕ → ℤ) → Prop := fun p w r =>
    p ≤ N_blk ∧
    ModifiedOnBounded ws locs W w ∧
    RegBounded W r ∧
    r 5 = 1 ∧ r 11 = (T_max : ℤ) ∧
    r 6 = nodeCellAddr nodeStride j (6 + 2 * d + p) ∧
    r 10 = (((p * T_max + 2 : ℕ) : ℤ)) ∧
    (∀ q < p, w.read (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * d + q))) = (hSeq (rawIdx q) : ℤ)) ∧
    (∀ off : ℕ, 6 + 2 * d + p ≤ off → off < nodeStride → (.heap 3 (nodeCellAddr nodeStride j off) : RAMCellLoc) ∉ w.live) ∧
    (∀ loc : RAMCellLoc, (∀ q < p, loc ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * d + q))) →
      (loc ∈ w.live ↔ loc ∈ wC3.live) ∧ w.vals loc = wC3.vals loc)
  have hBlk0 : BlkInv 0 wC3 r21 := by
    refine ⟨Nat.zero_le _, hmC3, br21,
      by simp [r21, r20, r19, r18, r17, r16, r14, r13, r11, r10],
      by simp [r21],
      by simp [r21, r20, r19],
      by simp [r21, r20],
      fun _ hq => absurd hq (Nat.not_lt_zero _),
      fun off hlo hhi => ?_,
      fun _ _ => ⟨Iff.rfl, rfl⟩⟩
    rw [(hunchC3_hi _ (fun off' hoff' => ne_addr hhi (lt_of_lt_of_le hoff' hstride) (by clear * - hlo hoff'; omega))).1]
    exact hemp3 off hhi
  obtain ⟨wsEnd, regsEnd, sLoop, hBlkEnd⟩ :=
    c2_repeatReg_inv (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      (cntReg := 8) (by decide) N_blk
      (by simp [r21, r20, r19, r18, r17, N_blk])
      BlkInv hBlk0 br21
      (U := 36) (B := 32 * W * W)
      (fun p hp w r ⟨_, hmw, br, hr5, hr11, hr6, hr10, hprev, hemp_hi, hunch_w⟩ => by
        have hraw_p_lt : rawIdx p < m := hraw_lt p hp
        have hraw_bl : intBitLength (rawIdx p : ℤ) ≤ W :=
          (intBitLength_natCast_mono (Nat.le_of_lt hraw_p_lt)).trans hm_bl
        have hh_p_lt : hSeq (rawIdx p) < 2 ^ L := hhSeq_lt (rawIdx p) hraw_p_lt
        have hh_p_bl : intBitLength (hSeq (rawIdx p) : ℤ) ≤ W :=
          (nat_lt_pow2_bitLength_le hh_p_lt).trans (by clear * - hW; omega)
        obtain ⟨hnp_loc, hnp_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 6 + 2 * d + p) (hstride_p p (Nat.le_of_lt hp)) hW_node
        obtain ⟨_, hnp1_bl⟩ := nodeCellAddr_bl (W := W) hj1 (off := 6 + 2 * d + (p + 1)) (hstride_p (p + 1) hp) hW_node
        have hp1_T_le : (p + 1) * T_max + 2 ≤ (2 ^ L + 2 * d + 4) * T_max := by
          have hp1_le : p + 1 ≤ 2 ^ L := le_trans hp (le_trans hk_le hm_le)
          calc (p + 1) * T_max + 2
              ≤ 2 ^ L * T_max + T_max := Nat.add_le_add (Nat.mul_le_mul_right T_max hp1_le) (by clear * - hT3; omega)
            _ ≤ (2 ^ L + 2 * d + 4) * T_max := by
                have : 2 ^ L * T_max + T_max = (2 ^ L + 1) * T_max := by ring
                rw [this]; exact Nat.mul_le_mul_right T_max (by have := Nat.zero_le (2 ^ L); omega)
        have hp1_T_bl : intBitLength ((((p + 1) * T_max + 2 : ℕ) : ℤ)) ≤ W :=
          (intBitLength_natCast_mono hp1_T_le).trans h10_ceil_bl
        have hrw_10 : w.read (.heap 10 (r 10)) = (rawIdx p : ℤ) := by
          rw [hr10, wordStore_read_eq_vals hmw.wf,
              (hunch_w _ (fun _ _ h => by cases h)).2,
              (hunchC3_hi _ (fun _ _ h => by cases h)).2,
              ← wordStore_read_eq_vals hwf]
          exact hraw_read p hp
        have b1 := (RegExec.load (inp := inp) hfd_le br (sp_ok hmw).1 (sp_ok hmw).2
          (dst := 12) (table := 10) (addr := 10) (by decide) (by decide) hn10 (hrw_10 ▸ hraw_bl)).weaken
          rfl (by rw [hrw_10]) le_rfl le_rfl
        set u1 := Function.update r 12 (rawIdx p : ℤ); have bu1 := br.update (r := 12) (by decide) hraw_bl
        have hrw_8 : w.read (.heap 8 (u1 12)) = (hSeq (rawIdx p) : ℤ) := by
          simp only [u1, Function.update_self]
          rw [wordStore_read_eq_vals hmw.wf,
              (hunch_w _ (fun _ _ h => by cases h)).2,
              (hunchC3_hi _ (fun _ _ h => by cases h)).2,
              ← wordStore_read_eq_vals hwf]
          exact hbuf (rawIdx p) hraw_p_lt
        have b2 := (RegExec.load (inp := inp) hfd_le bu1 (sp_ok hmw).1 (sp_ok hmw).2
          (dst := 13) (table := 8) (addr := 12) (by decide) (by decide) hn8 (hrw_8 ▸ hh_p_bl)).weaken
          rfl (by rw [hrw_8]) le_rfl le_rfl
        set u2 := Function.update u1 13 (hSeq (rawIdx p) : ℤ); have bu2 := bu1.update (r := 13) (by decide) hh_p_bl
        set w' := w.write (.heap 3 (nodeCellAddr nodeStride j (6 + 2 * d + p))) (hSeq (rawIdx p) : ℤ)
        have hmw' : ModifiedOnBounded ws locs W w' :=
          hmw.write (mem_level3WriteLocs (hstride_p p (Nat.le_of_lt hp))) (hSeq (rawIdx p) : ℤ) hnp_loc hh_p_bl
        have hu2_6 : u2 6 = nodeCellAddr nodeStride j (6 + 2 * d + p) := by simp [u2, u1, hr6]
        have hu2_13 : u2 13 = (hSeq (rawIdx p) : ℤ) := by simp [u2]
        have b3 : RegExec inp fd W C_cell C_bit (rStore 3 6 13) w u2 w' u2 6 (5 * W + 24) :=
          (RegExec.store (inp := inp) hfd_le bu2 (table := 3) (addr := 6) (val := 13) (by decide) (by decide) hn3
            (by simpa [u2, u1, hr6, w'] using (sp_ok hmw').1) (by simpa [u2, u1, hr6, w'] using (sp_ok hmw').2)).weaken
            (by simp [u2, u1, hr6, w']) rfl le_rfl le_rfl
        have ea4 : u2 6 + u2 5 = nodeCellAddr nodeStride j (6 + 2 * d + (p + 1)) := by
          rw [hu2_6]; simp [u2, u1, hr5, nodeCellAddr]; ring
        have b4 := (RegExec.add (inp := inp) hfd_le bu2 (sp_ok hmw').1 (sp_ok hmw').2
          (dst := 6) (a := 6) (b := 5) (by decide) (by decide) (by decide) (ea4 ▸ hnp1_bl)).weaken
          rfl (by rw [ea4]) le_rfl le_rfl
        set u4 := Function.update u2 6 (nodeCellAddr nodeStride j (6 + 2 * d + (p + 1)))
        have bu4 := bu2.update (r := 6) (by decide) hnp1_bl
        have ea5 : u4 10 + u4 11 = ((((p + 1) * T_max + 2 : ℕ) : ℤ)) := by
          simp [u4, u2, u1, hr10, hr11]; ring
        have b5 := (RegExec.add (inp := inp) hfd_le bu4 (sp_ok hmw').1 (sp_ok hmw').2
          (dst := 10) (a := 10) (b := 11) (by decide) (by decide) (by decide) (ea5 ▸ hp1_T_bl)).weaken
          rfl (by rw [ea5]) le_rfl le_rfl
        set u5 := Function.update u4 10 ((((p + 1) * T_max + 2 : ℕ) : ℤ))
        have bu5 := bu4.update (r := 10) (by decide) hp1_T_bl
        have bStep := (b1.seq (b2.seq (b3.seq (b4.seq b5)))).weaken rfl rfl
          (u₂ := 36) (b₂ := 32 * W * W)
          (by clear * -; omega)
          (by
            calc 6 * W + 24 + (6 * W + 24 + (5 * W + 24 + (6 * W + 32 + (6 * W + 32))))
              _ ≤ 32 * (40 * W) := by clear * - hW40; omega
              _ ≤ 32 * (W * W) := Nat.mul_le_mul_left 32 hWW
              _ = 32 * W * W := by ring)
        refine ⟨w', u5, bStep, hp, hmw', bu5,
          by simp [u5, u4, u2, u1, hr5],
          by simp [u5, u4, u2, u1, hr11],
          by simp [u5, u4],
          by simp [u5],
          fun q hq => ?_,
          fun off hlo hhi => ?_,
          fun loc hne => ?_⟩
        · rcases Nat.lt_succ_iff_lt_or_eq.mp hq with hlt | rfl
          · have hne_qp := ne_addr (hstride_p q (Nat.le_of_lt (lt_trans hlt hp)))
              (hstride_p p (Nat.le_of_lt hp)) (by clear * - hlt; omega)
            dsimp only [w']; rw [wordStore_read_write_ne _ hne_qp]; exact hprev q hlt
          · dsimp only [w']; rw [wordStore_read_write_self]
        · have hne_off := ne_addr hhi (hstride_p p (Nat.le_of_lt hp)) (by clear * - hlo; omega)
          dsimp only [w', WordStore.write]
          simp only [Finset.mem_insert, hne_off, false_or]
          exact hemp_hi off (by clear * - hlo; omega) hhi
        · have hne_p : loc ≠ .heap 3 (nodeCellAddr nodeStride j (6 + 2 * d + p)) :=
            hne p (Nat.lt_succ_self p)
          have prev_u := hunch_w loc (fun q hq => hne q (Nat.lt_succ_of_lt hq))
          dsimp only [w', WordStore.write]
          exact ⟨by simp [hne_p, prev_u.1], by simp [Function.update_of_ne hne_p, prev_u.2]⟩)
  rcases hBlkEnd with ⟨_, hmEnd, brEnd, _, _, _, _, hread_bh, hunused_end, hunch_end⟩
  have hAll := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq
    (s11.seq (s12.seq (s13.seq (s14.seq (s15.seq (s16.seq (s17.seq (s18.seq (s19.seq (s20.seq
    (s21.seq sLoop))))))))))))))))))))).weaken rfl rfl
    (u₂ := 260 * d + 40 * (k_blk * s₀_d) + 320)
    (b₂ := (60 * d + 40 * (k_blk * s₀_d) + 180) * W * W)
    (by dsimp only [N_blk]; clear * -; nlinarith)
    (by
      dsimp only [N_blk]
      have h1 : (60 * d + 36) * W * W + (k_blk * s₀_d) * (32 * W * W) + 8 * W * W ≤
          (60 * d + 40 * (k_blk * s₀_d) + 44) * W * W := by
        calc (60 * d + 36) * W * W + (k_blk * s₀_d) * (32 * W * W) + 8 * W * W
          _ = (60 * d + 32 * (k_blk * s₀_d) + 44) * (W * W) := by ring
          _ ≤ (60 * d + 40 * (k_blk * s₀_d) + 44) * (W * W) :=
              Nat.mul_le_mul_right (W * W) (by omega)
          _ = (60 * d + 40 * (k_blk * s₀_d) + 44) * W * W := by ring
      have h2 : 73 * W + 396 ≤ 136 * W * W := by
        calc 73 * W + 396 ≤ 136 * 40 * W := by omega
        _ = 136 * (40 * W) := by ring
        _ ≤ 136 * (W * W) := Nat.mul_le_mul_left 136 hWW
        _ = 136 * W * W := by ring
      have h3 : (60 * d + 40 * (k_blk * s₀_d) + 44) * W * W + 136 * W * W =
          (60 * d + 40 * (k_blk * s₀_d) + 180) * W * W := by ring
      linarith only [h1, h2, h3])
  have hread_low : ∀ off < 6 + 2 * d,
      wsEnd.read (.heap 3 (nodeCellAddr nodeStride j off)) =
        wC3.read (.heap 3 (nodeCellAddr nodeStride j off)) := by
    intro off hoff
    rw [wordStore_read_eq_vals hmEnd.wf,
        (hunch_end _ (fun q hq => ne_addr (lt_of_lt_of_le hoff hstride)
          (hstride_p q (Nat.le_of_lt hq)) (by clear * - hoff; omega))).2,
        ← wordStore_read_eq_vals hmC3.wf]
  have hgeomEnd : NodeGeomStored d nodeStride B_cert j oRat V_num V_den
      (liftVariance (ratPointToEuclidean oRat) (sRat : ℝ)) wsEnd :=
    hgeomC3.unchanged hread_low
  refine ⟨wsEnd, regsEnd, hAll, hmEnd, brEnd, hgeomEnd,
    (hread_low 0 (by clear * -; omega)).trans hrC3_0,
    (hread_low 1 (by clear * -; omega)).trans hrC3_1,
    (hread_low 2 (by clear * -; omega)).trans hrC3_2,
    hread_bh, hunused_end, fun loc hnotL => ?_⟩
  have hnot_any : ∀ off < nodeStride, loc ≠ .heap 3 (nodeCellAddr nodeStride j off) :=
    fun off hoff heq => hnotL (heq ▸ mem_level3WriteLocs hoff)
  have u1 := hunch_end loc (fun q hq => hnot_any _ (hstride_p q (Nat.le_of_lt hq)))
  have u2 := hunchC3_hi loc (fun off hoff => hnot_any off (lt_of_lt_of_le hoff hstride))
  exact ⟨u1.1.trans u2.1, u1.2.trans u2.2⟩

end UL.C12StepC2
