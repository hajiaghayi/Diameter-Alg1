import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG09_StepC1A
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Canceled-Suffix Birth-Pool Bound & Gather Branch (`posDimStepC1PopLtBranch` / `EqBranch`) -/

theorem canceled_birthPool_card_le {d s₀_d n L B B_cert K_max W : ℕ}
    (hs₀1 : 1 ≤ s₀_d)
    {P P' : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap qMap' : ℕ → Fin d → ℚ} {ws : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap ws)
    (hwfP' : P'.WellFormed n)
    {op : DynamicUpdate d} {hOp : ℕ}
    (hop_spec : OpStepASpec P P' qMap qMap' hOp op)
    {jStar j : ℕ} (hjStar_le : jStar ≤ nodes.length) (hj : j < nodes.length)
    (hjS_j : jStar ≤ j) :
    let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
    let ltCoords' := opNextLtCoords P ltCoords op
    let S_new := chainInput ltCoords' vecNodes (activeLifetimes P')
    (nodes.get ⟨j, hj⟩).birthPool.card ≤
      2 * ((S_new ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩).card + 1) := by
  intro vecNodes ltCoords' S_new
  have hlvl := hinv.levels j hj
  set S_pre_j := chainInput ltCoords vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩
  have hmb_pre : (nodes.get ⟨j, hj⟩).birthPool.card ≤ 2 * S_pre_j.card :=
    birthPool_card_le_two_mul_of_age_le hs₀1 hlvl.hage_rel hlvl.hage_le
  have hpts_eq : ∀ lt ∈ activeLifetimes P, ltCoords lt = ltCoords' lt := by
    intro lt hlt
    cases op with
    | delete _ => rfl
    | insert id extName pt =>
        obtain ⟨hnot_next, _, _, _, _⟩ := activeLifetimes_insert_spec hinv.wfP hwfP' hop_spec.1
        have hne : lt ≠ P.nextLifetime := fun heq => hnot_next (heq ▸ hlt)
        simp [ltCoords', opNextLtCoords, Function.update_of_ne hne]
  have hSpre_eq : S_pre_j =
      chainInput ltCoords' vecNodes (activeLifetimes P) ⟨j, Nat.lt_succ_of_lt hj⟩ :=
    chainInput_congr_pts vecNodes (activeLifetimes P) hpts_eq _
  set S_old_jStar :=
    chainInput ltCoords' vecNodes (activeLifetimes P) ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩
  have hsub_jS : S_pre_j ⊆ S_old_jStar := by
    rw [hSpre_eq]
    exact chainInput_anti_level ltCoords' vecNodes (activeLifetimes P) hjS_j
  have hcard_le1 : S_pre_j.card ≤ S_old_jStar.card := Finset.card_le_card hsub_jS
  have hcard_le2 : S_old_jStar.card ≤ (S_new ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩).card + 1 := by
    cases op with
    | insert id extName pt =>
        obtain ⟨_, hact_eq, _, _, _⟩ := activeLifetimes_insert_spec hinv.wfP hwfP' hop_spec.1
        have hsub : S_old_jStar ⊆ S_new ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩ := by
          intro x hx
          rw [mem_chainInput_iff] at hx
          rw [mem_chainInput_iff]
          exact ⟨by rw [hact_eq]; exact Finset.mem_insert_of_mem hx.1, hx.2⟩
        exact (Finset.card_le_card hsub).trans (Nat.le_succ _)
    | delete id =>
        obtain ⟨_, hact_eq, _, _, _⟩ := activeLifetimes_delete_spec hinv.wfP hwfP' hop_spec.1
        have her_eq : S_new ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩ =
            S_old_jStar.erase (P.lifetimeOfId id) := by
          dsimp [S_new, S_old_jStar]
          rw [hact_eq, chainInput_erase_eq]
        rw [her_eq]
        by_cases hx : P.lifetimeOfId id ∈ S_old_jStar
        · rw [Finset.card_erase_add_one hx]
        · rw [Finset.erase_eq_of_notMem hx]; exact Nat.le_succ _
  clear * - hmb_pre hcard_le1 hcard_le2; omega

def posDimStepC1PopLtBranch (L : ℕ) : BitRAMStmt :=
  .seq (rLit 14 2)
  (.seq (rMul 0 7 14)
  (.seq (rAdd 0 0 14)
  (.seq (popTreeToBufRegs L)
  (.seq (rLit 0 1)
        (clearTreeRegs L)))))

def posDimStepC1PopEqBranch (L : ℕ) : BitRAMStmt :=
  .seq (rLit 0 1)
        (popTreeToBufRegs L)

theorem exec_posDimStepC1PopIte
    {d s₀_d n L B B_cert K_max W : ℕ}
    (hL1 : 1 ≤ L)
    (hW : 2 * sqRadBitBound d B B_cert + natBitLength ((K_max + 2) * posNodeStride d L) +
            natBitLength (64 * s₀_d + 1) + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P' : DynamicPointSet d}
    {ltCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {qMap' : ℕ → Fin d → ℚ}
    {k : ℕ} (hk_le : k ≤ K_max)
    {vecNodes : Fin k → ChainNode d}
    {updatedNodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    (hupd_len : updatedNodes.length = k)
    {jStar : ℕ} (hjStar_le : jStar ≤ k)
    {wsB : WordStore} {regs : ℕ → ℤ}
    (hmodB : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsB)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hbnd : RegBounded W regs)
    (hr7 : regs 7 = (jStar : ℤ))
    (hr5 : regs 5 = (k : ℤ))
    (hn111_B : (.heap 9 111 : RAMCellLoc) ∉ wsB.live)
    (hn112_B : (.heap 9 112 : RAMCellLoc) ∉ wsB.live)
    (htree1B : TreeStoredAt L 1
      ((chainInput ltCoords' vecNodes (activeLifetimes P') (Fin.last k)).image (handleOfLifetime P'))
      (fun _ => 0) (fun _ => 1) wsB)
    (hpreB : ∀ (j : ℕ) (hj : j < k),
      PreTriggerLevelInv n L B B_cert K_max P' ltCoords' qMap'
        (chainInput ltCoords' vecNodes (activeLifetimes P') ⟨j, Nat.lt_succ_of_lt hj⟩)
        (updatedNodes.get ⟨j, hupd_len ▸ hj⟩) j wsB)
    {M : ℕ}
    (hM_eq : ((chainInput ltCoords' vecNodes (activeLifetimes P')
                ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩).image (handleOfLifetime P')).card = M)
    (htdB : ∀ (j : ℕ) (hj : j < k), jStar ≤ j → TeardownableLevel d s₀_d L B B_cert j M wsB) :
    let H_jStar := (chainInput ltCoords' vecNodes (activeLifetimes P')
                    ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩).image (handleOfLifetime P')
    ∃ wsG1 regsG1,
      RegExec inp fd W C_cell C_bit
        (.ite (.intLt (.readLocal 7 (.lit 0)) (.readLocal 5 (.lit 0)))
          (posDimStepC1PopLtBranch L) (posDimStepC1PopEqBranch L))
        wsB regs wsG1 regsG1
        ((M + 1) * (900 * L + 700)) ((M + 1) * (150 * L + 180) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsG1 ∧
      RegBounded W regsG1 ∧
      wsG1.read (.heap 9 110) = (M : ℤ) ∧
      (∀ idx < M, wsG1.read (.heap 8 (idx : ℤ)) = (minPopElem H_jStar idx : ℤ)) ∧
      TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsG1 ∧
      (∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L 1 u f) : RAMCellLoc) ∉ wsG1.live) ∧
      (∀ (j : ℕ) (hj : j < k), jStar ≤ j → TeardownableLevel d s₀_d L B B_cert j M wsG1) ∧
      (∀ loc : RAMCellLoc,
        loc ∉ treeSliceLocs L 1 →
        (jStar < k → loc ∉ treeSliceLocs L (2 * jStar + 2)) →
        loc ≠ .heap 9 110 →
        (∀ idx < M, loc ≠ .heap 8 (idx : ℤ)) →
        (loc ∈ wsG1.live ↔ loc ∈ wsB.live) ∧ wsG1.vals loc = wsB.vals loc) := by
  intro H_jStar
  have hW40 : 40 ≤ W := by clear * - hW; omega
  have hWW : 40 * W ≤ W * W := by nlinarith only [hW40]
  have hBr1 : 1 ≤ sqRadBitBound d B B_cert := by unfold sqRadBitBound; omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
  have hl2 : intBitLength (2 : ℤ) ≤ W := (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by omega)
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    have h0c : WordStore.empty.cellCount = 0 := rfl
    have h0b : WordStore.empty.bitSize = 0 := rfl
    rw [h0c, zero_add] at cs; rw [h0b, zero_add] at bs
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have hcCeil0 : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hbCeil0 : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  by_cases hjS_lt : jStar < k
  · have hcond : regs 7 < regs 5 := by rw [hr7, hr5]; exact_mod_cast hjS_lt
    have h2jS_bl : intBitLength (((2 * jStar : ℕ) : ℤ)) ≤ W := by
      have h1 := intBitLength_ofNat_le (2 * jStar)
      have hns := posNodeStride_ge_eight d L
      have h2 := natBitLength_mono (show 2 * jStar ≤ (K_max + 2) * posNodeStride d L by nlinarith only [hjS_lt, hk_le, hns])
      clear * - h1 h2 hW; omega
    have htid_jS_bl : intBitLength (((2 * jStar + 2 : ℕ) : ℤ)) ≤ W := by
      have h1 := intBitLength_ofNat_le (2 * jStar + 2)
      have h2 := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (tid := 2 * jStar + 2) (by omega)
      clear * - h1 h2 hW; omega
    have t1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmodB).1 (sp_ok hmodB).2 (dst := 14) (c := 2) (by decide) hl2
    set v1 := Function.update regs 14 2; have bv1 := hbnd.update (r := 14) (by decide) hl2
    have hmv1 : v1 7 * v1 14 = (((2 * jStar : ℕ) : ℤ)) := by simp [v1, hr7]; ring
    have t2 := RegExec.mul (inp := inp) hfd_le bv1 (sp_ok hmodB).1 (sp_ok hmodB).2 (dst := 0) (a := 7) (b := 14)
      (by decide) (by decide) (by decide) (by rw [hmv1]; exact h2jS_bl)
    rw [hmv1] at t2
    set v2 := Function.update v1 0 (((2 * jStar : ℕ) : ℤ)); have bv2 := bv1.update (r := 0) (by decide) h2jS_bl
    have hav2 : v2 0 + v2 14 = (((2 * jStar + 2 : ℕ) : ℤ)) := by simp [v2, v1]
    have t3 := RegExec.add (inp := inp) hfd_le bv2 (sp_ok hmodB).1 (sp_ok hmodB).2 (dst := 0) (a := 0) (b := 14)
      (by decide) (by decide) (by decide) (by rw [hav2]; exact htid_jS_bl)
    rw [hav2] at t3
    set v3 := Function.update v2 0 (((2 * jStar + 2 : ℕ) : ℤ)); have bv3 := bv2.update (r := 0) (by decide) htid_jS_bl
    rcases (hpreB jStar hjS_lt).tree_Sj with ⟨rN_jS, rD_jS, htr_jS, hrb_jS⟩
    have htr_jS' : TreeStoredAt L (2 * jStar + 2) H_jStar rN_jS rD_jS wsB := htr_jS
    have hb_jS : ∀ h ∈ H_jStar, h < 2 ^ L ∧
        intBitLength (rN_jS h) ≤ sqRadBitBound d B B_cert ∧
        intBitLength (rD_jS h) ≤ sqRadBitBound d B B_cert :=
      fun h hh => ⟨htr_jS'.hS h hh, (hrb_jS h hh).2.2.1, (hrb_jS h hh).2.2.2⟩
    have hW_pop : 2 * sqRadBitBound d B B_cert + natBitLength (2 * jStar + 2) + L + 20 ≤ W := by
      have ht := tid_bl_of_level (d := d) (L := L) (K_max := K_max) (tid := 2 * jStar + 2) (by omega)
      clear * - ht hW; omega
    obtain ⟨wsP, regsP, t4, hmodP, bregsP, htrP_emp, hrP_110, hbufP, hfrP⟩ :=
      exec_popTreeToBufRegs hfd_le hmodB hcCeil0 hbCeil0 hL1 hBr1 hW_pop
        (fun u hu f hf => mem_posDimWriteLocs_tree (by omega) hu hf)
        (fun idx hidx => mem_posDimWriteLocs_tab8 (by omega))
        (mem_posDimWriteLocs_tab9 (i := 110) (by decide))
        (mem_posDimWriteLocs_tab9 (i := 111) (by decide))
        (mem_posDimWriteLocs_tab9 (i := 112) (by decide))
        hn111_B hn112_B htr_jS' hb_jS bv3 (by simp [v3])
    rw [hM_eq] at t4 hrP_110 hbufP hfrP
    have t5 := RegExec.lit (inp := inp) hfd_le bregsP (sp_ok hmodP).1 (sp_ok hmodP).2 (dst := 0) (c := 1) (by decide) hl1
    set v5 := Function.update regsP 0 1; have bv5 := bregsP.update (r := 0) (by decide) hl1
    have hnP_111 : (.heap 9 111 : RAMCellLoc) ∉ wsP.live := by
      rw [(hfrP (.heap 9 111) (not_in_treeSlice_of_table_ne (by decide) _)
        (by intro hc; cases hc) (fun _ _ h => by cases h)).1]
      exact hn111_B
    set H_leaf := (chainInput ltCoords' vecNodes (activeLifetimes P') (Fin.last k)).image (handleOfLifetime P')
    have htr1P : TreeStoredAt L 1 H_leaf (fun _ => 0) (fun _ => 1) wsP :=
      htree1B.unchanged (fun u hu f hf => hfrP _
        (not_in_treeSlice_of_tid_ne hu hf (by omega))
        (by intro hc; cases hc) (fun _ _ h => by cases h))
    have hb1P : ∀ h ∈ H_leaf, h < 2 ^ L ∧ intBitLength (0 : ℤ) ≤ 2 ∧ intBitLength (1 : ℤ) ≤ 2 :=
      fun h hh => ⟨htr1P.hS h hh, by decide, by decide⟩
    have hcard_leaf_le : H_leaf.card ≤ M := by
      rw [← hM_eq]
      have hsubL : chainInput ltCoords' vecNodes (activeLifetimes P') (Fin.last k) ⊆
          chainInput ltCoords' vecNodes (activeLifetimes P') ⟨jStar, Nat.lt_succ_of_le hjStar_le⟩ :=
        chainInput_anti_level ltCoords' vecNodes (activeLifetimes P') hjStar_le
      exact Finset.card_le_card (Finset.image_subset_image hsubL)
    have hW_t1 : 2 * 2 + natBitLength 1 + L + 20 ≤ W := by
      have : natBitLength 1 = 1 := by decide
      clear * - this hW; omega
    obtain ⟨wsG1, regsG1, t6, hmodG1, bregsG1, htr1_emp, hemp1_G1, hfrG1⟩ :=
      exec_clearTreeRegs hfd_le hmodP hcCeil0 hbCeil0 hL1 (by decide : 1 ≤ 2) hW_t1
        (fun u hu f hf => mem_posDimWriteLocs_tree (by omega) hu hf)
        (mem_posDimWriteLocs_tab9 (i := 111) (by decide)) hnP_111
        htr1P hb1P bv5 (by simp [v5])
    have hfr_comb : ∀ loc : RAMCellLoc,
        loc ∉ treeSliceLocs L 1 →
        (jStar < k → loc ∉ treeSliceLocs L (2 * jStar + 2)) →
        loc ≠ .heap 9 110 →
        (∀ idx < M, loc ≠ .heap 8 (idx : ℤ)) →
        (loc ∈ wsG1.live ↔ loc ∈ wsB.live) ∧ wsG1.vals loc = wsB.vals loc := by
      intro loc hn1 hn2 hn110 hn8
      have hG := hfrG1 loc hn1
      have hP := hfrP loc (hn2 hjS_lt) hn110 hn8
      exact ⟨hG.1.trans hP.1, hG.2.trans hP.2⟩
    have hrG1_110 : wsG1.read (.heap 9 110) = (M : ℤ) :=
      (wordStore_read_congr (hfrG1 _ (not_in_treeSlice_of_table_ne (by decide) _))).trans hrP_110
    have hbufG1 : ∀ idx < M, wsG1.read (.heap 8 (idx : ℤ)) = (minPopElem H_jStar idx : ℤ) :=
      fun idx hidx =>
        (wordStore_read_congr (hfrG1 _ (not_in_treeSlice_of_table_ne (by decide) _))).trans (hbufP idx hidx)
    have htdG1 : ∀ (j : ℕ) (hj : j < k), jStar ≤ j → TeardownableLevel d s₀_d L B B_cert j M wsG1 := by
      intro j hj hjS_j
      rcases eq_or_lt_of_le hjS_j with rfl | hgt
      · have htr_emp_G1 : TreeStoredAt L (2 * jStar + 2) ∅ (fun _ => 0) (fun _ => 1) wsG1 :=
          htrP_emp.unchanged (fun u hu f hf => hfrG1 _ (not_in_treeSlice_of_tid_ne hu hf (by omega)))
        exact (htdB jStar hj le_rfl).withEmptyTreeSj htr_emp_G1
          (fun off _ => hfr_comb _ (not_in_treeSlice_of_table_ne (by decide) _)
            (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by intro hc; cases hc) (fun _ _ h => by cases h))
          (fun h' _ hm => (hfr_comb _ (not_in_treeSlice_of_table_ne (by decide) _)
            (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by intro hc; cases hc) (fun _ _ h => by cases h)).1.mp hm)
          (fun u hu f hf => hfr_comb _ (not_in_treeSlice_of_tid_ne hu hf (by omega))
            (fun _ => not_in_treeSlice_of_tid_ne hu hf (by omega)) (by intro hc; cases hc) (fun _ _ h => by cases h))
      · exact (htdB j hj hjS_j).unchanged
          (fun off _ => hfr_comb _ (not_in_treeSlice_of_table_ne (by decide) _)
            (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by intro hc; cases hc) (fun _ _ h => by cases h))
          (fun h' _ hm => (hfr_comb _ (not_in_treeSlice_of_table_ne (by decide) _)
            (fun _ => not_in_treeSlice_of_table_ne (by decide) _) (by intro hc; cases hc) (fun _ _ h => by cases h)).1.mp hm)
          (fun u hu f hf => hfr_comb _ (not_in_treeSlice_of_tid_ne hu hf (by omega))
            (fun _ => not_in_treeSlice_of_tid_ne hu hf (by omega)) (by intro hc; cases hc) (fun _ _ h => by cases h))
          (fun u hu f hf => hfr_comb _ (not_in_treeSlice_of_tid_ne hu hf (by omega))
            (fun _ => not_in_treeSlice_of_tid_ne hu hf (by omega)) (by intro hc; cases hc) (fun _ _ h => by cases h))
    have hbr_raw := t1.seq (t2.seq (t3.seq (t4.seq (t5.seq t6))))
    have hbr_exec : RegExec inp fd W C_cell C_bit (posDimStepC1PopLtBranch L) wsB regs wsG1 regsG1
        ((M + 1) * (900 * L + 650)) ((M + 1) * (150 * L + 170) * W * W) := by
      refine hbr_raw.weaken rfl rfl (by nlinarith only [hcard_leaf_le, hL1]) ?_
      have hov : (2 * W + 16) + 4 * W * W + (6 * W + 32) + (2 * W + 16) ≤ 6 * (W * W) := by
        nlinarith only [hW40, hWW]
      have hmL : (H_leaf.card + 1) * (70 * L + 60) * W * W ≤
          ((M + 1) * (70 * L + 60)) * W * W :=
        Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by nlinarith only [hcard_leaf_le, hL1]))
      have hsum : (M + 1) * (76 * L + 100) * W * W +
          ((M + 1) * (70 * L + 60)) * W * W + 6 * (W * W) ≤
          (M + 1) * (150 * L + 170) * W * W := by
        have heq : (M + 1) * (76 * L + 100) * W * W +
            ((M + 1) * (70 * L + 60)) * W * W + 6 * (W * W) =
            ((M + 1) * (76 * L + 100) + (M + 1) * (70 * L + 60) + 6) * W * W := by ring
        rw [heq]
        exact Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by nlinarith only [hL1]))
      linarith only [hov, hmL, hsum]
    have hite : RegExec inp fd W C_cell C_bit
        (.ite (.intLt (.readLocal 7 (.lit 0)) (.readLocal 5 (.lit 0)))
          (posDimStepC1PopLtBranch L) (posDimStepC1PopEqBranch L))
        wsB regs wsG1 regsG1
        ((M + 1) * (900 * L + 700)) ((M + 1) * (150 * L + 180) * W * W) :=
      (RegExec.iteLt (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      hbnd (a := 7) (b := 5) (by decide) (by decide)
      (tB := posDimStepC1PopLtBranch L) (fB := posDimStepC1PopEqBranch L)
      (by rw [if_pos hcond]; exact hbr_exec)).weaken rfl rfl (by nlinarith only [hL1]) (by
        set WW := W * W
        have hov : 4 * W + 16 ≤ WW := by dsimp [WW]; nlinarith only [hW40, hWW]
        have hcoef : (M + 1) * (150 * L + 170) + 1 ≤ (M + 1) * (150 * L + 180) := by nlinarith only [hL1]
        have hmul := Nat.mul_le_mul_right WW hcoef
        have h1 : ((M + 1) * (150 * L + 170) + 1) * WW = (M + 1) * (150 * L + 170) * W * W + WW := by dsimp [WW]; ring
        have h2 : ((M + 1) * (150 * L + 180)) * WW = (M + 1) * (150 * L + 180) * W * W := by dsimp [WW]; ring
        linarith only [hov, hmul, h1, h2])
    exact ⟨wsG1, regsG1, hite, hmodG1, bregsG1, hrG1_110, hbufG1, htr1_emp, hemp1_G1, htdG1, hfr_comb⟩
  · have hcond : ¬ (regs 7 < regs 5) := by rw [hr7, hr5]; exact_mod_cast hjS_lt
    have hjS_eq : jStar = k := by omega
    have hfin_eq : (⟨jStar, Nat.lt_succ_of_le hjStar_le⟩ : Fin (k + 1)) = Fin.last k :=
      Fin.ext hjS_eq
    have hH_eq : (chainInput ltCoords' vecNodes (activeLifetimes P') (Fin.last k)).image (handleOfLifetime P') = H_jStar := by
      dsimp [H_jStar]; rw [hfin_eq]
    have htr1_H : TreeStoredAt L 1 H_jStar (fun _ => 0) (fun _ => 1) wsB := by
      rwa [← hH_eq]
    have hb1_H : ∀ h ∈ H_jStar, h < 2 ^ L ∧ intBitLength (0 : ℤ) ≤ 2 ∧ intBitLength (1 : ℤ) ≤ 2 :=
      fun h hh => ⟨htr1_H.hS h hh, by decide, by decide⟩
    have e1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmodB).1 (sp_ok hmodB).2 (dst := 0) (c := 1) (by decide) hl1
    set v1 := Function.update regs 0 1; have bv1 := hbnd.update (r := 0) (by decide) hl1
    have hW_pop1 : 2 * 2 + natBitLength 1 + L + 20 ≤ W := by
      have : natBitLength 1 = 1 := by decide
      clear * - this hW; omega
    obtain ⟨wsG1, regsG1, e2, hmodG1, bregsG1, htr1_emp, hrG1_110, hbufG1, hfrG1⟩ :=
      exec_popTreeToBufRegs hfd_le hmodB hcCeil0 hbCeil0 hL1 (by decide : 1 ≤ 2) hW_pop1
        (fun u hu f hf => mem_posDimWriteLocs_tree (by omega) hu hf)
        (fun idx hidx => mem_posDimWriteLocs_tab8 (by omega))
        (mem_posDimWriteLocs_tab9 (i := 110) (by decide))
        (mem_posDimWriteLocs_tab9 (i := 111) (by decide))
        (mem_posDimWriteLocs_tab9 (i := 112) (by decide))
        hn111_B hn112_B htr1_H hb1_H bv1 (by simp [v1])
    rw [hM_eq] at e2 hrG1_110 hbufG1 hfrG1
    have hbr_exec : RegExec inp fd W C_cell C_bit (posDimStepC1PopEqBranch L) wsB regs wsG1 regsG1
        ((M + 1) * (900 * L + 650)) ((M + 1) * (150 * L + 170) * W * W) := by
      refine (e1.seq e2).weaken rfl rfl (by nlinarith only [hL1]) ?_
      set WW := W * W
      have hov : 2 * W + 16 ≤ WW := by dsimp [WW]; nlinarith only [hW40, hWW]
      have hcoef : (M + 1) * (76 * L + 100) + 1 ≤ (M + 1) * (150 * L + 170) := by nlinarith only [hL1]
      have hmul := Nat.mul_le_mul_right WW hcoef
      have h1 : ((M + 1) * (76 * L + 100) + 1) * WW = WW + (M + 1) * (76 * L + 100) * W * W := by dsimp [WW]; ring
      have h2 : ((M + 1) * (150 * L + 170)) * WW = (M + 1) * (150 * L + 170) * W * W := by dsimp [WW]; ring
      linarith only [hov, hmul, h1, h2]
    have hite : RegExec inp fd W C_cell C_bit
        (.ite (.intLt (.readLocal 7 (.lit 0)) (.readLocal 5 (.lit 0)))
          (posDimStepC1PopLtBranch L) (posDimStepC1PopEqBranch L))
        wsB regs wsG1 regsG1
        ((M + 1) * (900 * L + 700)) ((M + 1) * (150 * L + 180) * W * W) :=
      (RegExec.iteLt (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      hbnd (a := 7) (b := 5) (by decide) (by decide)
      (tB := posDimStepC1PopLtBranch L) (fB := posDimStepC1PopEqBranch L)
      (by rw [if_neg hcond]; exact hbr_exec)).weaken rfl rfl (by nlinarith only [hL1]) (by
        set WW := W * W
        have hov : 4 * W + 16 ≤ WW := by dsimp [WW]; nlinarith only [hW40, hWW]
        have hcoef : (M + 1) * (150 * L + 170) + 1 ≤ (M + 1) * (150 * L + 180) := by nlinarith only [hL1]
        have hmul := Nat.mul_le_mul_right WW hcoef
        have h1 : ((M + 1) * (150 * L + 170) + 1) * WW = (M + 1) * (150 * L + 170) * W * W + WW := by dsimp [WW]; ring
        have h2 : ((M + 1) * (150 * L + 180)) * WW = (M + 1) * (150 * L + 180) * W * W := by dsimp [WW]; ring
        linarith only [hov, hmul, h1, h2])
    exact ⟨wsG1, regsG1, hite, hmodG1, bregsG1, hrG1_110, hbufG1, htr1_emp, htr1_emp.empty_no_live,
            fun j hj hjS_j => absurd (lt_of_le_of_lt hjS_j hj) (by omega),
            fun loc hn1 _ hn110 hn8 => hfrG1 loc hn1 hn110 hn8⟩

def posDimStepC1CleanupScratchStmt : BitRAMStmt :=
  .seq (rLit 10 106)
  (.seq (rLoad 7 9 10)
  (.seq (rLit 10 10)
  (.seq (rStore 0 10 7)
  (.seq (rLit 10 102)
  (.seq (rFree 9 10)
  (.seq (rLit 10 103)
  (.seq (rFree 9 10)
  (.seq (rLit 10 104)
  (.seq (rFree 9 10)
  (.seq (rLit 10 105)
  (.seq (rFree 9 10)
  (.seq (rLit 10 106)
        (rFree 9 10)))))))))))))


end UL.C12LVE
