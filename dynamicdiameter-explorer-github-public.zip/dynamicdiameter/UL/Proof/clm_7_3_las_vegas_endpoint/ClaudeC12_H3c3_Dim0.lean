import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H1_Easy
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2a_ProbAndSim
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3c2_TreeQueries
set_option autoImplicit false
set_option maxHeartbeats 800000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Shared `BitRAMDynamicProgram` & `DynamicPointSet` Helpers -/

/-- Exact `DynamicDiameterStructure` wrapper around a `BitRAMDynamicProgram` matching
`S_clm_7_3_las_vegas_endpoint`. -/
noncomputable def bitRAMAlg {d : ℕ} (n : ℕ) (prog : BitRAMDynamicProgram)
    (initOut : BitRAMExecOutcome) : DynamicDiameterStructure d WordStore :=
  { initState := initOut.words
    initWork := initOut.bitCost
    initSpace := initOut.peakBitSpace
    cachedAnswer := fun ws =>
      let ca := BitRAMDynamicProgram.readCachedAnswer ws
      { diameterHandles := ca.1, cachedDistSq := ca.2 }
    retrieveIdsAndRefCost := 5
    writeOutputCost := fun len => len + 1
    stepWithBits := fun activeH hCoords ws uop bs =>
      let rawOut :=
        match uop with
        | .insert pt => prog.evalUpdate n activeH hCoords ws true pt 0 bs
        | .delete h => prog.evalUpdate n activeH hCoords ws false 0 h bs
      rawOut.map (fun out =>
        let ca := BitRAMDynamicProgram.readCachedAnswer out.words
        { nextState := out.words
          returnedHandle :=
            match uop with
            | .insert _ => BitRAMDynamicProgram.readReturnedHandle out.words
            | .delete _ => none
          storedAnswer := { diameterHandles := ca.1, cachedDistSq := ca.2 }
          work := out.bitCost
          peakSpace := out.peakBitSpace }) }

theorem evalInit_of_initSkip (n d : ℕ) (upd : BitRAMStmt) :
    ({ initStmt := .skip, updateStmt := upd } : BitRAMDynamicProgram).evalInit n d =
      some
        { words := WordStore.empty
          unitCost := 1
          bitCost := 1
          peakCellSpace := 1
          peakBitSpace := intBitLength (n : ℤ) } := by
  unfold BitRAMDynamicProgram.evalInit
  dsimp only
  let inp : BitRAMInput d :=
    { intParams := [(n : ℤ)]
      activeHandles := ∅
      activeRatCoords := fun _ _ => 0
      extraRats := [] }
  have hpop : WordStore.empty.popDepth 0 = WordStore.empty := by
    unfold WordStore.popDepth WordStore.empty
    dsimp only
    congr 1; simp
  have hc0 : WordStore.empty.cellCount = 0 := by simp [WordStore.cellCount, WordStore.empty]
  have hb0 : WordStore.empty.bitSize = 0 := by simp [WordStore.bitSize, WordStore.empty]
  have hic : inp.inputCellSpace = 1 := by simp [inp, BitRAMInput.inputCellSpace]
  have hib : inp.inputBitSpace = intBitLength (n : ℤ) := by simp [inp, BitRAMInput.inputBitSpace]
  let initSt : BitRAMExecState :=
    { words := WordStore.empty.popDepth 0
      frameDepth := 0
      remainingBits := []
      unitCost := 0
      bitCost := 0
      peakCellSpace := inp.inputCellSpace + (WordStore.empty.popDepth 0).cellCount
      peakBitSpace := inp.inputBitSpace + (WordStore.empty.popDepth 0).bitSize }
  have hrun := RunsTo.skip inp initSt
  have h_halting := RunsTo.toRunBitRAMWithBits (prog := .skip) (inp := inp)
    (initWords := WordStore.empty) (bs := []) hrun rfl
  simpa [initSt, hpop, hc0, hb0, hic, hib] using h_halting

theorem satisfiesDynamicStorage_of_initEmpty {d : ℕ} (n : ℕ)
    (prog : BitRAMDynamicProgram) (initOut : BitRAMExecOutcome)
    (hw0 : initOut.words = WordStore.empty) :
    SatisfiesDynamicStorageAndQueryModel 5 1 (bitRAMAlg (d := d) n prog initOut) := by
  refine ⟨?_, ?_, ?_, le_rfl, fun L => by dsimp [bitRAMAlg]; omega⟩
  · simp [bitRAMAlg, hw0, BitRAMDynamicProgram.readCachedAnswer, WordStore.read, WordStore.empty]
  · intro activeH hCoords st uop bs out hstep
    simp only [bitRAMAlg, Option.map_eq_some_iff] at hstep
    rcases hstep with ⟨raw, _, rfl⟩
    rfl
  · intro activeH hCoords st uop bs₁ bs₂ out₁ out₂ h1 h2 hpref
    simp only [bitRAMAlg, Option.map_eq_some_iff] at h1 h2
    rcases h1 with ⟨r1, hr1, _⟩
    rcases h2 with ⟨r2, hr2, _⟩
    cases uop with
    | insert pt =>
        dsimp only at hr1 hr2
        unfold BitRAMDynamicProgram.evalUpdate at hr1 hr2
        by_cases hAct : ∀ h ∈ activeH, (euclideanToRatPoint? (hCoords h)).isSome
        · rw [dif_pos hAct] at hr1 hr2
          simp only [↓reduceIte] at hr1 hr2
          cases hq : euclideanToRatPoint? pt with
          | none => simp [hq] at hr1
          | some qIns =>
              simp only [hq] at hr1 hr2
              exact runBitRAMWithBits_prefix_free prog.updateStmt _ st hr1 hr2 hpref
        · rw [dif_neg hAct] at hr1; simp at hr1
    | delete h =>
        dsimp only at hr1 hr2
        unfold BitRAMDynamicProgram.evalUpdate at hr1 hr2
        by_cases hAct : ∀ h ∈ activeH, (euclideanToRatPoint? (hCoords h)).isSome
        · rw [dif_pos hAct] at hr1 hr2
          simp only [Bool.false_eq_true, ↓reduceIte] at hr1 hr2
          exact runBitRAMWithBits_prefix_free prog.updateStmt _ st hr1 hr2 hpref
        · rw [dif_neg hAct] at hr1; simp at hr1

theorem ratPointToEuclidean_injective {d : ℕ} :
    Function.Injective (ratPointToEuclidean (d := d)) := by
  intro q₁ q₂ heq
  funext i
  have h1 := congrFun (congrArg (WithLp.equiv 2 (Fin d → ℝ)) heq) i
  simp only [ratPointToEuclidean, Equiv.apply_symm_apply] at h1
  exact Rat.cast_injective h1

theorem euclideanToRatPoint_of_admissible {d B : ℕ} {pt : EuclideanSpace ℝ (Fin d)}
    (hpt : pt ∈ RatAdmissiblePointSet d B) :
    ∃ q : Fin d → ℚ,
      euclideanToRatPoint? pt = some q ∧
      RatPointBitBounded B q ∧
      ratPointToEuclidean q = pt := by
  rcases hpt with ⟨q, hqb, hqeq⟩
  have hex : ∃ q' : Fin d → ℚ, ratPointToEuclidean q' = pt := ⟨q, hqeq⟩
  have heval : euclideanToRatPoint? pt = some (Classical.choose hex) := by
    unfold euclideanToRatPoint?
    rw [dif_pos hex]
  have hceq : Classical.choose hex = q :=
    ratPointToEuclidean_injective ((Classical.choose_spec hex).trans hqeq.symm)
  exact ⟨q, heval.trans (congrArg some hceq), hqb, hqeq⟩

theorem ratBitLength_le_of_bounded {B : ℕ} {q : ℚ} (hq : RatCoordBitBounded B q) :
    intBitLength q.num ≤ B + 1 ∧
    intBitLength (q.den : ℤ) ≤ B + 1 ∧
    1 ≤ (q.den : ℤ) ∧
    ratBitLength q ≤ 2 * B + 1 := by
  rcases hq with ⟨hnum, hden⟩
  have hpos_den : 1 ≤ (q.den : ℤ) := by exact_mod_cast q.pos
  have hn_bl : intBitLength q.num ≤ B + 1 := by
    unfold intBitLength
    split_ifs <;> omega
  have hd_bl : intBitLength (q.den : ℤ) ≤ B + 1 := by
    have := intBitLength_ofNat_le q.den
    omega
  have hr_bl : ratBitLength q ≤ 2 * B + 1 := by
    unfold ratBitLength
    omega
  exact ⟨hn_bl, hd_bl, hpos_den, hr_bl⟩

theorem activeHandles_card_eq {d n : ℕ} {P : DynamicPointSet d} (hwf : P.WellFormed n) :
    P.activeHandles.card = P.activeIds.card := by
  rcases hwf with ⟨_, hidH, hhId, _, _⟩
  symm
  apply Finset.card_bij (fun id _ => P.handleOfId id)
  · intro id hid; exact (hidH id hid).1
  · intro i₁ hi₁ i₂ hi₂ heq
    have := congrArg P.idOfHandle heq
    rwa [(hidH i₁ hi₁).2, (hidH i₂ hi₂).2] at this
  · intro h hh
    exact ⟨P.idOfHandle h, (hhId h hh).1, (hhId h hh).2⟩

theorem applyDynamicUpdate_insert_spec {d n : ℕ} {admissible : Set (EuclideanSpace ℝ (Fin d))}
    {P : DynamicPointSet d} (hwf : P.WellFormed n)
    (hAdm : ∀ id ∈ P.activeIds, P.coords id ∈ admissible)
    {id : ℕ} {extName : List Bool} {pt : EuclideanSpace ℝ (Fin d)}
    (hleg : IsLegalUpdate n admissible P (.insert id extName pt))
    {hNew : ℕ} (hhNew : hNew ∉ P.activeHandles) :
    ∃ P' : DynamicPointSet d,
      applyDynamicUpdate P (.insert id extName pt) (some hNew) = some P' ∧
      P'.WellFormed n ∧
      (∀ id' ∈ P'.activeIds, P'.coords id' ∈ admissible) ∧
      P'.activeIds = insert id P.activeIds ∧
      P'.activeHandles = insert hNew P.activeHandles ∧
      (∀ h ∈ P'.activeHandles,
        P'.handleCoords h = if h = hNew then pt else P.handleCoords h) := by
  rcases hleg with ⟨hid_not, hcard_le, hpt_adm⟩
  rcases hwf with ⟨_, hidH, hhId, hlt_lt, hlt_inj⟩
  unfold applyDynamicUpdate; dsimp only
  rw [if_pos ⟨hid_not, hhNew⟩]
  refine ⟨_, rfl, ?_, ?_, rfl, rfl, ?_⟩
  · refine ⟨?_, ?_, ?_, ?_, ?_⟩
    · rw [Finset.card_insert_of_notMem hid_not]; exact hcard_le
    · intro id' hid'
      by_cases heq_id : id' = id
      · subst heq_id
        dsimp only
        rw [Function.update_self, Function.update_self]
        exact ⟨Finset.mem_insert_self _ _, rfl⟩
      · have hid_old : id' ∈ P.activeIds := (Finset.mem_insert.mp hid').resolve_left heq_id
        have hne_h : P.handleOfId id' ≠ hNew := fun heq => hhNew (heq ▸ (hidH id' hid_old).1)
        dsimp only
        rw [Function.update_of_ne heq_id, Function.update_of_ne hne_h]
        exact ⟨Finset.mem_insert_of_mem (hidH id' hid_old).1, (hidH id' hid_old).2⟩
    · intro h' hh'
      by_cases heq_h : h' = hNew
      · subst heq_h
        dsimp only
        rw [Function.update_self, Function.update_self]
        exact ⟨Finset.mem_insert_self _ _, rfl⟩
      · have hh_old : h' ∈ P.activeHandles := (Finset.mem_insert.mp hh').resolve_left heq_h
        have hne_id : P.idOfHandle h' ≠ id := fun heq => hid_not (heq ▸ (hhId h' hh_old).1)
        dsimp only
        rw [Function.update_of_ne heq_h, Function.update_of_ne hne_id]
        exact ⟨Finset.mem_insert_of_mem (hhId h' hh_old).1, (hhId h' hh_old).2⟩
    · intro id' hid'
      by_cases heq_id : id' = id
      · subst heq_id; dsimp only; rw [Function.update_self]; exact Nat.lt_succ_self _
      · have hid_old : id' ∈ P.activeIds := (Finset.mem_insert.mp hid').resolve_left heq_id
        dsimp only
        rw [Function.update_of_ne heq_id]
        exact Nat.lt_succ_of_lt (hlt_lt id' hid_old)
    · intro i₁ hi₁ i₂ hi₂ heq_lt
      dsimp only at heq_lt
      by_cases h1 : i₁ = id <;> by_cases h2 : i₂ = id
      · exact h1.trans h2.symm
      · subst h1
        have hi₂_old : i₂ ∈ P.activeIds := (Finset.mem_insert.mp hi₂).resolve_left h2
        rw [Function.update_self, Function.update_of_ne h2] at heq_lt
        exact absurd heq_lt (ne_of_gt (hlt_lt i₂ hi₂_old))
      · subst h2
        have hi₁_old : i₁ ∈ P.activeIds := (Finset.mem_insert.mp hi₁).resolve_left h1
        rw [Function.update_self, Function.update_of_ne h1] at heq_lt
        exact absurd heq_lt (ne_of_lt (hlt_lt i₁ hi₁_old))
      · have hi₁_old : i₁ ∈ P.activeIds := (Finset.mem_insert.mp hi₁).resolve_left h1
        have hi₂_old : i₂ ∈ P.activeIds := (Finset.mem_insert.mp hi₂).resolve_left h2
        rw [Function.update_of_ne h1, Function.update_of_ne h2] at heq_lt
        exact hlt_inj i₁ hi₁_old i₂ hi₂_old heq_lt
  · intro id' hid'
    by_cases heq_id : id' = id
    · subst heq_id; dsimp only; rw [Function.update_self]; exact hpt_adm
    · have hid_old : id' ∈ P.activeIds := (Finset.mem_insert.mp hid').resolve_left heq_id
      dsimp only; rw [Function.update_of_ne heq_id]
      exact hAdm id' hid_old
  · intro h hh'
    by_cases heq : h = hNew
    · subst heq
      unfold DynamicPointSet.handleCoords; dsimp only
      rw [if_pos (Finset.mem_insert_self _ _), Function.update_self, Function.update_self, if_pos rfl]
    · have hh_old : h ∈ P.activeHandles := (Finset.mem_insert.mp hh').resolve_left heq
      have hne_id : P.idOfHandle h ≠ id := fun h_eq => hid_not (h_eq ▸ (hhId h hh_old).1)
      unfold DynamicPointSet.handleCoords; dsimp only
      rw [if_pos hh', if_neg heq, if_pos hh_old, Function.update_of_ne heq, Function.update_of_ne hne_id]

theorem applyDynamicUpdate_delete_spec {d n : ℕ} {admissible : Set (EuclideanSpace ℝ (Fin d))}
    {P : DynamicPointSet d} (hwf : P.WellFormed n)
    (hAdm : ∀ id ∈ P.activeIds, P.coords id ∈ admissible)
    {id : ℕ} (hleg : IsLegalUpdate n admissible P (.delete id)) :
    let hDel := P.handleOfId id
    ∃ P' : DynamicPointSet d,
      hDel ∈ P.activeHandles ∧
      applyDynamicUpdate P (.delete id) none = some P' ∧
      P'.WellFormed n ∧
      (∀ id' ∈ P'.activeIds, P'.coords id' ∈ admissible) ∧
      P'.activeIds = P.activeIds.erase id ∧
      P'.activeHandles = P.activeHandles.erase hDel ∧
      (∀ h ∈ P'.activeHandles, P'.handleCoords h = P.handleCoords h) := by
  intro hDel
  have hid_in : id ∈ P.activeIds := hleg
  rcases hwf with ⟨hcard_le, hidH, hhId, hlt_lt, hlt_inj⟩
  have hhDel_in : hDel ∈ P.activeHandles := (hidH id hid_in).1
  unfold applyDynamicUpdate; dsimp only
  rw [if_pos hid_in]
  refine ⟨_, hhDel_in, rfl, ?_, ?_, rfl, rfl, ?_⟩
  · refine ⟨(Finset.card_erase_le (s := P.activeIds) (a := id)).trans hcard_le, ?_, ?_, ?_, ?_⟩
    · intro id' hid'
      rcases Finset.mem_erase.mp hid' with ⟨hne_id, hid_old⟩
      have hne_h : P.handleOfId id' ≠ hDel := by
        intro heq
        have := congrArg P.idOfHandle heq
        rw [(hidH id' hid_old).2, (hidH id hid_in).2] at this
        exact hne_id this
      dsimp only
      rw [Function.update_of_ne hne_id, Function.update_of_ne hne_h]
      exact ⟨Finset.mem_erase.mpr ⟨hne_h, (hidH id' hid_old).1⟩, (hidH id' hid_old).2⟩
    · intro h' hh'
      rcases Finset.mem_erase.mp hh' with ⟨hne_h, hh_old⟩
      have hne_id : P.idOfHandle h' ≠ id := by
        intro heq
        have := congrArg P.handleOfId heq
        rw [(hhId h' hh_old).2] at this
        exact hne_h this
      dsimp only
      rw [Function.update_of_ne hne_h, Function.update_of_ne hne_id]
      exact ⟨Finset.mem_erase.mpr ⟨hne_id, (hhId h' hh_old).1⟩, (hhId h' hh_old).2⟩
    · intro id' hid'
      rcases Finset.mem_erase.mp hid' with ⟨hne_id, hid_old⟩
      dsimp only; rw [Function.update_of_ne hne_id]
      exact hlt_lt id' hid_old
    · intro i₁ hi₁ i₂ hi₂ heq_lt
      rcases Finset.mem_erase.mp hi₁ with ⟨hne₁, hi₁_old⟩
      rcases Finset.mem_erase.mp hi₂ with ⟨hne₂, hi₂_old⟩
      dsimp only at heq_lt
      rw [Function.update_of_ne hne₁, Function.update_of_ne hne₂] at heq_lt
      exact hlt_inj i₁ hi₁_old i₂ hi₂_old heq_lt
  · intro id' hid'
    rcases Finset.mem_erase.mp hid' with ⟨hne_id, hid_old⟩
    dsimp only; rw [Function.update_of_ne hne_id]
    exact hAdm id' hid_old
  · intro h hh'
    rcases Finset.mem_erase.mp hh' with ⟨hne_h, hh_old⟩
    have hne_id : P.idOfHandle h ≠ id := by
      intro heq
      have := congrArg P.handleOfId heq
      rw [(hhId h hh_old).2] at this
      exact hne_h this
    dsimp only [DynamicPointSet.handleCoords]
    rw [if_pos hh', if_pos hh_old, Function.update_of_ne hne_h, Function.update_of_ne hne_id]

/-! ### 2. `getTwoMinHandlesRegs`: Find Two Distinct Handles in `S` (`2 ≤ S.card`) -/

def getTwoMinHandlesRegs (L : ℕ) : BitRAMStmt :=
  .seq (rLit 10 100)
  (.seq (rStore 9 10 0)
  (.seq (treeMinElemRegs L)
  (.seq (rLit 10 101)
  (.seq (rStore 9 10 1)
  (.seq (rLit 2 0)
  (.seq (rLit 3 0)
  (.seq (rLit 4 0)
  (.seq (treeSetLeafRegs L)
  (.seq (rLit 10 100)
  (.seq (rLoad 0 9 10)
  (.seq (treeMinElemRegs L)
  (.seq (rLit 10 100)
  (.seq (rStore 9 10 1)
  (.seq (rLit 10 101)
  (.seq (rLoad 1 9 10)
  (.seq (rLit 2 1)
  (.seq (rLit 3 0)
  (.seq (rLit 4 1)
  (.seq (treeSetLeafRegs L)
  (.seq (rLit 10 101)
  (.seq (rLoad 11 9 10)
  (.seq (rFree 9 10)
  (.seq (rLit 10 100)
  (.seq (rLoad 12 9 10)
        (rFree 9 10)))))))))))))))))))))))))

theorem exec_getTwoMinHandlesRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid : ℕ} (hL1 : 1 ≤ L)
    (hW : natBitLength tid + L + 20 ≤ W)
    {S : Finset ℕ}
    (htree : TreeStoredAt L tid S (fun _ => 0) (fun _ => 1) ws)
    (hcard2 : 2 ≤ S.card)
    (hSubTree : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ S_write)
    (hSub100 : (.heap 9 100 : RAMCellLoc) ∈ S_write)
    (hSub101 : (.heap 9 101 : RAMCellLoc) ∈ S_write)
    (hn100 : (.heap 9 100 : RAMCellLoc) ∉ ws.live)
    (hn101 : (.heap 9 101 : RAMCellLoc) ∉ ws.live)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (tid : ℤ)) :
    ∃ (wsEnd : WordStore) (regsEnd : ℕ → ℤ) (h₁ h₂ : ℕ),
      h₁ ∈ S ∧ h₂ ∈ S ∧ h₁ ≠ h₂ ∧
      RegExec inp fd W C_cell C_bit (getTwoMinHandlesRegs L) ws regs wsEnd regsEnd
        (900 * L + 600) ((150 * L + 160) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L tid S (fun _ => 0) (fun _ => 1) wsEnd ∧
      regsEnd 11 = (h₁ : ℤ) ∧
      regsEnd 12 = (h₂ : ℤ) ∧
      (∀ loc : RAMCellLoc, (∀ u < 2 ^ (L + 1), ∀ f < 4, loc ≠ .heap 2 (treeCellAddr L tid u f)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW20 : 20 ≤ W := by omega
  have hl0 : intBitLength (0 : ℤ) ≤ W := by
    have hdec : intBitLength (0 : ℤ) = 1 := by decide
    omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by
    have hdec : intBitLength (1 : ℤ) = 2 := by decide
    omega
  have hl100 : intBitLength (100 : ℤ) ≤ W := by
    have hdec : intBitLength (100 : ℤ) = 8 := by decide
    omega
  have hl101 : intBitLength (101 : ℤ) ≤ W := by
    have hdec : intBitLength (101 : ℤ) = 8 := by decide
    omega
  have hn9 : natBitLength 9 ≤ W := by
    have hdec : natBitLength 9 = 4 := by decide
    omega
  have hloc100 : (RAMCellLoc.heap 9 100).bitLength ≤ W := by
    have : (RAMCellLoc.heap 9 100).bitLength = 12 := by decide
    omega
  have hloc101 : (RAMCellLoc.heap 9 101).bitLength ≤ W := by
    have : (RAMCellLoc.heap 9 101).bitLength = 12 := by decide
    omega
  have htid_bl : intBitLength (tid : ℤ) ≤ W := by
    have := intBitLength_ofNat_le tid; omega
  have hW_tree : 2 * 2 + natBitLength tid + L + 16 ≤ W := by omega
  have hS_bnds : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 :=
    fun h hm => ⟨htree.hS h hm, by dsimp only; decide, by dsimp only; decide⟩
  have hne1 : S.Nonempty := Finset.card_pos.mp (by omega)
  set h₁ := S.min' hne1
  have hh₁_in : h₁ ∈ S := Finset.min'_mem S hne1
  have hh₁_lt : h₁ < 2 ^ L := htree.hS h₁ hh₁_in
  have hh₁_bl : intBitLength (h₁ : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hh₁_lt).trans (by omega)
  have hne2 : (S.erase h₁).Nonempty := by
    apply Finset.card_pos.mp
    rw [Finset.card_erase_of_mem hh₁_in]; omega
  set h₂ := (S.erase h₁).min' hne2
  have hh₂_er : h₂ ∈ S.erase h₁ := Finset.min'_mem _ hne2
  rcases Finset.mem_erase.mp hh₂_er with ⟨hne_21, hh₂_in⟩
  have hh₂_lt : h₂ < 2 ^ L := htree.hS h₂ hh₂_in
  have hh₂_bl : intBitLength (h₂ : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hh₂_lt).trans (by omega)
  have hPathSub : treePathLocs L tid h₁ ⊆ S_write := by
    intro loc hloc
    simp only [treePathLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hloc
    rcases hloc with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
    have hoff_lt : h₁ / 2 ^ k < 2 ^ (L - k) := by
      rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add]
      have : L - k + k = L := by omega
      rw [this]; exact hh₁_lt
    exact hSubTree _ (treeIdx_bounds (by omega) hoff_lt).2 f hf
  -- Helper to extract space_ok from any ModifiedOnBounded state
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ S_write W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm
    obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  -- 1. `rLit 10 100; rStore 9 10 0` (`heap 9 100 := tid`)
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 100) (by decide) hl100
  set g1 := Function.update regs 10 100; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hl100
  have hm_w1 : ModifiedOnBounded ws₀ S_write W (ws.write (.heap 9 (g1 10)) (g1 0)) := by
    simpa [g1, hr0] using hmod.write hSub100 (tid : ℤ) hloc100 htid_bl
  have s2 := RegExec.store (inp := inp) hfd_le bg1 (table := 9) (addr := 10) (val := 0) (by decide) (by decide) hn9
    (sp_ok hm_w1).1 (sp_ok hm_w1).2
  set ws1 := ws.write (.heap 9 100) (tid : ℤ)
  have hw1_eq : ws.write (.heap 9 (g1 10)) (g1 0) = ws1 := by simp [ws1, g1, hr0]
  rw [hw1_eq] at s2 hm_w1
  have htree1 : TreeStoredAt L tid S (fun _ => 0) (fun _ => 1) ws1 :=
    htree.unchanged (fun u _ f _ => by simp [ws1, WordStore.write])
  -- 2. `treeMinElemRegs L` -> `g2 1 = h₁`
  obtain ⟨g2, s3, bg2, g2_0, g2_1, _⟩ :=
    exec_treeMinElemRegs (inp := inp) (fd := fd) hfd_le (sp_ok hm_w1).1 (sp_ok hm_w1).2 hL1 (by decide : 1 ≤ 2) hW_tree
      htree1 hS_bnds hne1 bg1 (by simp [g1, hr0])
  -- 3. `rLit 10 101; rStore 9 10 1` (`heap 9 101 := h₁`)
  have s4 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hm_w1).1 (sp_ok hm_w1).2 (dst := 10) (c := 101) (by decide) hl101
  set g3 := Function.update g2 10 101; have bg3 : RegBounded W g3 := bg2.update (r := 10) (by decide) hl101
  have hm_w2 : ModifiedOnBounded ws₀ S_write W (ws1.write (.heap 9 (g3 10)) (g3 1)) := by
    simpa [g3, g2_1, h₁] using hm_w1.write hSub101 (h₁ : ℤ) hloc101 hh₁_bl
  have s5 := RegExec.store (inp := inp) hfd_le bg3 (table := 9) (addr := 10) (val := 1) (by decide) (by decide) hn9
    (sp_ok hm_w2).1 (sp_ok hm_w2).2
  set ws2 := ws1.write (.heap 9 101) (h₁ : ℤ)
  have hw2_eq : ws1.write (.heap 9 (g3 10)) (g3 1) = ws2 := by simp [ws2, g3, g2_1, h₁]
  rw [hw2_eq] at s5 hm_w2
  have htree2 : TreeStoredAt L tid S (fun _ => 0) (fun _ => 1) ws2 :=
    htree1.unchanged (fun u _ f _ => by simp [ws2, WordStore.write])
  -- 4. `rLit 2 0; rLit 3 0; rLit 4 0; treeSetLeafRegs L` (`S -> S.erase h₁`)
  have s6 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 2) (c := 0) (by decide) hl0
  set g4 := Function.update g3 2 0; have bg4 : RegBounded W g4 := bg3.update (r := 2) (by decide) hl0
  have s7 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 3) (c := 0) (by decide) hl0
  set g5 := Function.update g4 3 0; have bg5 : RegBounded W g5 := bg4.update (r := 3) (by decide) hl0
  have s8 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hm_w2).1 (sp_ok hm_w2).2 (dst := 4) (c := 0) (by decide) hl0
  set g6 := Function.update g5 4 0; have bg6 : RegBounded W g6 := bg5.update (r := 4) (by decide) hl0
  have hS_er_bnds : ∀ h ∈ S.erase h₁, h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 :=
    fun h hm => hS_bnds h (Finset.mem_of_mem_erase hm)
  obtain ⟨ws3, g7, s9, hm_w3, bg7, htree3, hunch3⟩ :=
    exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hm_w2 hcCeil hbCeil hL1 hh₁_lt (B_r := 2) (by decide) hW_tree
      hPathSub htree2 (S' := S.erase h₁) (rNum' := fun _ => 0) (rDen' := fun _ => 1)
      hS_er_bnds (fun h hne => by simp [Finset.mem_erase, hne]) (fun _ _ => rfl) (fun _ _ => rfl)
      false (by simp) bg6
      (by simp [g6, g5, g4, g3, g2_0])
      (by simp [g6, g5, g4, g3, g2_1, h₁])
      (by simp [g6, g5, g4])
      (by intro h; cases h)
      (by intro h; cases h)
  have h9_notin_path : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∉ treePathLocs L tid h₁ := by
    intro z hm; simp only [treePathLocs, Finset.mem_image] at hm; rcases hm with ⟨_, _, h⟩; cases h
  have hr3_100 : ws3.read (.heap 9 100) = (tid : ℤ) := by
    rw [wordStore_read_eq_vals hm_w3.wf, (hunch3 _ (h9_notin_path 100)).2]
    simp [ws2, ws1, WordStore.write]
  have hr3_101 : ws3.read (.heap 9 101) = (h₁ : ℤ) := by
    rw [wordStore_read_eq_vals hm_w3.wf, (hunch3 _ (h9_notin_path 101)).2]
    simp [ws2, WordStore.write]
  -- 5. `rLit 10 100; rLoad 0 9 10; treeMinElemRegs L` (`g10 1 = h₂`)
  have s10 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hm_w3).1 (sp_ok hm_w3).2 (dst := 10) (c := 100) (by decide) hl100
  set g8 := Function.update g7 10 100; have bg8 : RegBounded W g8 := bg7.update (r := 10) (by decide) hl100
  have hg8_r100 : ws3.read (.heap 9 (g8 10)) = (tid : ℤ) := by simp only [g8, Function.update_self]; exact hr3_100
  have s11 := RegExec.load (inp := inp) hfd_le bg8 (sp_ok hm_w3).1 (sp_ok hm_w3).2 (dst := 0) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg8_r100]; exact htid_bl)
  rw [hg8_r100] at s11
  set g9 := Function.update g8 0 (tid : ℤ); have bg9 : RegBounded W g9 := bg8.update (r := 0) (by decide) htid_bl
  obtain ⟨g10, s12, bg10, g10_0, g10_1, _⟩ :=
    exec_treeMinElemRegs (inp := inp) (fd := fd) hfd_le (sp_ok hm_w3).1 (sp_ok hm_w3).2 hL1 (by decide : 1 ≤ 2) hW_tree
      htree3 hS_er_bnds hne2 bg9 (by simp [g9])
  -- 6. `rLit 10 100; rStore 9 10 1` (`heap 9 100 := h₂`)
  have s13 := RegExec.lit (inp := inp) hfd_le bg10 (sp_ok hm_w3).1 (sp_ok hm_w3).2 (dst := 10) (c := 100) (by decide) hl100
  set g11 := Function.update g10 10 100; have bg11 : RegBounded W g11 := bg10.update (r := 10) (by decide) hl100
  have hm_w4 : ModifiedOnBounded ws₀ S_write W (ws3.write (.heap 9 (g11 10)) (g11 1)) := by
    simpa [g11, g10_1, h₂] using hm_w3.write hSub100 (h₂ : ℤ) hloc100 hh₂_bl
  have s14 := RegExec.store (inp := inp) hfd_le bg11 (table := 9) (addr := 10) (val := 1) (by decide) (by decide) hn9
    (sp_ok hm_w4).1 (sp_ok hm_w4).2
  set ws4 := ws3.write (.heap 9 100) (h₂ : ℤ)
  have hw4_eq : ws3.write (.heap 9 (g11 10)) (g11 1) = ws4 := by simp [ws4, g11, g10_1, h₂]
  rw [hw4_eq] at s14 hm_w4
  have htree4 : TreeStoredAt L tid (S.erase h₁) (fun _ => 0) (fun _ => 1) ws4 :=
    htree3.unchanged (fun u _ f _ => by simp [ws4, WordStore.write])
  -- 7. `rLit 10 101; rLoad 1 9 10; rLit 2 1; rLit 3 0; rLit 4 1; treeSetLeafRegs L` (`S.erase h₁ -> S`)
  have s15 := RegExec.lit (inp := inp) hfd_le bg11 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 10) (c := 101) (by decide) hl101
  set g12 := Function.update g11 10 101; have bg12 : RegBounded W g12 := bg11.update (r := 10) (by decide) hl101
  have hr4_101 : ws4.read (.heap 9 (g12 10)) = (h₁ : ℤ) := by
    simp only [g12, Function.update_self, ws4]
    rw [wordStore_read_write_ne ws3 (by decide) (h₂ : ℤ)]
    exact hr3_101
  have s16 := RegExec.load (inp := inp) hfd_le bg12 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 1) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hr4_101]; exact hh₁_bl)
  rw [hr4_101] at s16
  set g13 := Function.update g12 1 (h₁ : ℤ); have bg13 : RegBounded W g13 := bg12.update (r := 1) (by decide) hh₁_bl
  have s17 := RegExec.lit (inp := inp) hfd_le bg13 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 2) (c := 1) (by decide) hl1
  set g14 := Function.update g13 2 1; have bg14 : RegBounded W g14 := bg13.update (r := 2) (by decide) hl1
  have s18 := RegExec.lit (inp := inp) hfd_le bg14 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 3) (c := 0) (by decide) hl0
  set g15 := Function.update g14 3 0; have bg15 : RegBounded W g15 := bg14.update (r := 3) (by decide) hl0
  have s19 := RegExec.lit (inp := inp) hfd_le bg15 (sp_ok hm_w4).1 (sp_ok hm_w4).2 (dst := 4) (c := 1) (by decide) hl1
  set g16 := Function.update g15 4 1; have bg16 : RegBounded W g16 := bg15.update (r := 4) (by decide) hl1
  obtain ⟨ws5, g17, s20, hm_w5, bg17, htree5, hunch5⟩ :=
    exec_treeSetLeafRegs (inp := inp) (fd := fd) hfd_le hm_w4 hcCeil hbCeil hL1 hh₁_lt (B_r := 2) (by decide) hW_tree
      hPathSub htree4 (S' := S) (rNum' := fun _ => 0) (rDen' := fun _ => 1)
      hS_bnds (fun h hne => by simp [Finset.mem_erase, hne]) (fun _ _ => rfl) (fun _ _ => rfl)
      true (by simp [hh₁_in]) bg16
      (by simp [g16, g15, g14, g13, g12, g11, g10_0])
      (by simp [g16, g15, g14, g13])
      (by simp [g16, g15, g14])
      (fun _ => by simp [g16, g15])
      (fun _ => by simp [g16])
  have hr5_101 : ws5.read (.heap 9 101) = (h₁ : ℤ) := by
    rw [wordStore_read_eq_vals hm_w5.wf, (hunch5 _ (h9_notin_path 101)).2,
        ← wordStore_read_eq_vals hm_w4.wf, wordStore_read_write_ne _ (by decide)]
    exact hr3_101
  have hr5_100 : ws5.read (.heap 9 100) = (h₂ : ℤ) := by
    rw [wordStore_read_eq_vals hm_w5.wf, (hunch5 _ (h9_notin_path 100)).2]
    simp [ws4, WordStore.write]
  -- 8. Load `(h₁, h₂)` into `(r11, r12)` and free `heap 9 101, heap 9 100`!
  have s21 := RegExec.lit (inp := inp) hfd_le bg17 (sp_ok hm_w5).1 (sp_ok hm_w5).2 (dst := 10) (c := 101) (by decide) hl101
  set g18 := Function.update g17 10 101; have bg18 : RegBounded W g18 := bg17.update (r := 10) (by decide) hl101
  have hg18_r : ws5.read (.heap 9 (g18 10)) = (h₁ : ℤ) := by simp only [g18, Function.update_self]; exact hr5_101
  have s22 := RegExec.load (inp := inp) hfd_le bg18 (sp_ok hm_w5).1 (sp_ok hm_w5).2 (dst := 11) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg18_r]; exact hh₁_bl)
  rw [hg18_r] at s22
  set g19 := Function.update g18 11 (h₁ : ℤ); have bg19 : RegBounded W g19 := bg18.update (r := 11) (by decide) hh₁_bl
  have s23 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws5) bg19 (table := 9) (addr := 10) (by decide) hn9
  set ws6 := ws5.free (.heap 9 101)
  have hw6_eq : ws5.free (.heap 9 (g19 10)) = ws6 := by simp [ws6, g19, g18]
  rw [hw6_eq] at s23
  have hm_w6 : ModifiedOnBounded ws₀ S_write W ws6 := hm_w5.free hSub101
  have s24 := RegExec.lit (inp := inp) hfd_le bg19 (sp_ok hm_w6).1 (sp_ok hm_w6).2 (dst := 10) (c := 100) (by decide) hl100
  set g20 := Function.update g19 10 100; have bg20 : RegBounded W g20 := bg19.update (r := 10) (by decide) hl100
  have hg20_r : ws6.read (.heap 9 (g20 10)) = (h₂ : ℤ) := by
    simp only [g20, Function.update_self, ws6]
    rw [wordStore_read_free_ne ws5 (by decide)]
    exact hr5_100
  have s25 := RegExec.load (inp := inp) hfd_le bg20 (sp_ok hm_w6).1 (sp_ok hm_w6).2 (dst := 12) (table := 9) (addr := 10)
    (by decide) (by decide) hn9 (by rw [hg20_r]; exact hh₂_bl)
  rw [hg20_r] at s25
  set g21 := Function.update g20 12 (h₂ : ℤ); have bg21 : RegBounded W g21 := bg20.update (r := 12) (by decide) hh₂_bl
  have s26 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws6) bg21 (table := 9) (addr := 10) (by decide) hn9
  set wsEnd := ws6.free (.heap 9 100)
  have hwEnd_eq : ws6.free (.heap 9 (g21 10)) = wsEnd := by simp [wsEnd, g21, g20]
  rw [hwEnd_eq] at s26
  have hm_End : ModifiedOnBounded ws₀ S_write W wsEnd := hm_w6.free hSub100
  have htreeEnd : TreeStoredAt L tid S (fun _ => 0) (fun _ => 1) wsEnd :=
    htree5.unchanged (fun u _ f _ => by simp [wsEnd, ws6, WordStore.free])
  have hLWW : 0 ≤ L * W * W := by positivity
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq
    (s11.seq (s12.seq (s13.seq (s14.seq (s15.seq (s16.seq (s17.seq (s18.seq (s19.seq (s20.seq
    (s21.seq (s22.seq (s23.seq (s24.seq (s25.seq s26))))))))))))))))))))))))).weaken rfl rfl
    (u₂ := 900 * L + 600) (b₂ := (150 * L + 160) * W * W) (by omega)
    (by nlinarith only [hW20, hL1, hLWW])
  refine ⟨wsEnd, g21, h₁, h₂, hh₁_in, hh₂_in, Ne.symm hne_21, sTot, hm_End, bg21, htreeEnd,
    by simp [g21, g20, g19], by simp [g21], ?_⟩
  intro loc hnot2
  have hnpath : loc ∉ treePathLocs L tid h₁ := by
    intro hm
    simp only [treePathLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hm
    rcases hm with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
    have hoff_lt : h₁ / 2 ^ k < 2 ^ (L - k) := by
      rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add]
      have : L - k + k = L := by omega
      rw [this]; exact hh₁_lt
    exact (hnot2 _ (treeIdx_bounds (by omega) hoff_lt).2 f hf) rfl
  by_cases h100 : loc = .heap 9 100
  · subst h100
    exact ⟨by simp [wsEnd, WordStore.free, hn100],
           by simp [wsEnd, WordStore.free, hmod.wf _ hn100]⟩
  · by_cases h101 : loc = .heap 9 101
    · subst h101
      exact ⟨by simp [wsEnd, ws6, WordStore.free, hn101],
             by simp [wsEnd, ws6, WordStore.free, hmod.wf _ hn101]⟩
    · have u5 := hunch5 loc hnpath
      have u3 := hunch3 loc hnpath
      exact ⟨by simp [wsEnd, ws6, WordStore.free, h100, h101, u5.1, ws4, WordStore.write, u3.1, ws2, ws1],
             by simp [wsEnd, ws6, WordStore.free, Function.update_of_ne h100, Function.update_of_ne h101,
                  u5.2, ws4, WordStore.write, u3.2, ws2, ws1]⟩


/-! ### 3. Deterministic `d = 0` Program `progDim0` and `prove_part4_dim0` -/

def dim0WriteLocs (L : ℕ) : Finset RAMCellLoc :=
  ((Finset.range 6).image (fun i : ℕ => RAMCellLoc.heap 0 (i : ℤ))) ∪
    treeSliceLocs L 0 ∪ {.heap 9 100, .heap 9 101}

theorem dim0WriteLocs_card_le (L : ℕ) :
    (dim0WriteLocs L).card ≤ 8 * 2 ^ L + 8 := by
  unfold dim0WriteLocs
  have hc1 : (((Finset.range 6).image (fun i : ℕ => RAMCellLoc.heap 0 (i : ℤ)))).card ≤ 6 :=
    Finset.card_image_le.trans (by simp)
  have hc2 : (treeSliceLocs L 0).card ≤ 4 * 2 ^ (L + 1) := by
    unfold treeSliceLocs
    exact Finset.card_image_le.trans (by simp [Nat.mul_comm])
  have hc3 : ({RAMCellLoc.heap 9 100, RAMCellLoc.heap 9 101} : Finset RAMCellLoc).card ≤ 2 :=
    (Finset.card_insert_le _ _).trans (by simp)
  have hu1 := Finset.card_union_le
    (((Finset.range 6).image (fun i : ℕ => RAMCellLoc.heap 0 (i : ℤ))) ∪ treeSliceLocs L 0)
    {.heap 9 100, .heap 9 101}
  have hu2 := Finset.card_union_le
    ((Finset.range 6).image (fun i : ℕ => RAMCellLoc.heap 0 (i : ℤ)))
    (treeSliceLocs L 0)
  have hp : 4 * 2 ^ (L + 1) = 8 * 2 ^ L := by rw [pow_succ]; ring
  omega

theorem mem_dim0WriteLocs_tab0 {L i : ℕ} (hi : i < 6) :
    (.heap 0 (i : ℤ) : RAMCellLoc) ∈ dim0WriteLocs L := by
  unfold dim0WriteLocs
  exact Finset.mem_union_left _ (Finset.mem_union_left _
    (Finset.mem_image.mpr ⟨i, Finset.mem_range.mpr hi, rfl⟩))

theorem mem_dim0WriteLocs_tree {L u f : ℕ} (hu : u < 2 ^ (L + 1)) (hf : f < 4) :
    (.heap 2 (treeCellAddr L 0 u f) : RAMCellLoc) ∈ dim0WriteLocs L := by
  unfold dim0WriteLocs treeSliceLocs
  refine Finset.mem_union_left _ (Finset.mem_union_right _ ?_)
  exact Finset.mem_image.mpr ⟨(u, f), Finset.mem_product.mpr ⟨Finset.mem_range.mpr hu, Finset.mem_range.mpr hf⟩, rfl⟩

def clearAnsHeaderRegs : BitRAMStmt :=
  .seq (.seq (rLit 10 1) (rFree 0 10))
  (.seq (.seq (rLit 10 2) (rFree 0 10))
  (.seq (.seq (rLit 10 3) (rFree 0 10))
  (.seq (.seq (rLit 10 4) (rFree 0 10))
        (.seq (rLit 10 5) (rFree 0 10)))))

def writeDim0AnsRegs : BitRAMStmt :=
  .seq (rLit 10 1) (.seq (rLit 13 1) (.seq (rStore 0 10 13)
  (.seq (rLit 10 2) (.seq (rStore 0 10 11)
  (.seq (rLit 10 3) (.seq (rStore 0 10 12)
  (.seq (rLit 10 4) (.seq (rLit 13 0) (.seq (rStore 0 10 13)
  (.seq (rLit 10 5) (.seq (rLit 13 1) (rStore 0 10 13))))))))))))

def dim0UpdateBody (L : ℕ) : BitRAMStmt :=
  .seq (rIntParam 5 1)
  (.seq (rIntParam 6 2)
  (.seq (rLit 0 0)
  (.seq (rLit 14 1)
  (.seq (.ite (.intEq (.readLocal 5 (.lit 0)) (.readLocal 14 (.lit 0)))
          (.seq (treeMexRegs L)
          (.seq (rLit 10 0)
          (.seq (rStore 0 10 1)
          (.seq (rLit 2 1)
          (.seq (rLit 3 0)
          (.seq (rLit 4 1)
                (treeSetLeafRegs L)))))))
          (.seq (rCopy 1 6)
          (.seq (rLit 2 0)
          (.seq (rLit 3 0)
          (.seq (rLit 4 0)
                (treeSetLeafRegs L))))))
  (.seq (rLit 0 0)
  (.seq (treeReadRootRegs L)
  (.seq (rLit 14 2)
        (.ite (.intLt (.readLocal 1 (.lit 0)) (.readLocal 14 (.lit 0)))
          clearAnsHeaderRegs
          (.seq (getTwoMinHandlesRegs L) writeDim0AnsRegs)))))))))

def progDim0 (L : ℕ) : BitRAMDynamicProgram :=
  { initStmt := .skip
    updateStmt := .localScope (dim0UpdateBody L) }

structure Dim0Inv (n L : ℕ) (P : DynamicPointSet 0) (ws : WordStore) : Prop where
  wfP : P.WellFormed n
  mod : ModifiedOnBounded WordStore.empty (dim0WriteLocs L) (L + 24) ws
  tree : TreeStoredAt L 0 P.activeHandles (fun _ => 0) (fun _ => 1) ws
  no100 : (.heap 9 100 : RAMCellLoc) ∉ ws.live
  no101 : (.heap 9 101 : RAMCellLoc) ∉ ws.live

theorem Dim0Inv.init {n : ℕ} (hn : 2 ≤ n) :
    let L := Nat.clog 2 (2 * n)
    Dim0Inv n L (DynamicPointSet.empty 0) WordStore.empty := by
  intro L
  refine
    { wfP := ⟨by simp [DynamicPointSet.empty],
              by simp [DynamicPointSet.empty],
              by simp [DynamicPointSet.empty],
              by simp [DynamicPointSet.empty],
              by simp [DynamicPointSet.empty]⟩
      mod := ModifiedOnBounded.refl wellFormedWS_empty _ _ (by simp [WordStore.empty])
      tree := TreeStoredAt.empty L 0 _ _ (by simp [WordStore.empty])
      no100 := by simp [WordStore.empty]
      no101 := by simp [WordStore.empty] }

theorem Dim0Inv.no_local {n L : ℕ} {P : DynamicPointSet 0} {ws : WordStore}
    (h : Dim0Inv n L P ws) :
    ∀ d' ≥ 1, ∀ v i, (.localFrame d' v i : RAMCellLoc) ∉ ws.live := by
  intro d' _ v i hm
  have hsub := h.mod.live_sub hm
  simp only [WordStore.empty, Finset.empty_union, dim0WriteLocs, treeSliceLocs,
    Finset.mem_union, Finset.mem_image, Finset.mem_insert, Finset.mem_singleton,
    reduceCtorEq, and_false, exists_false, or_self] at hsub

private lemma dim0_valid_answer {n : ℕ} {P : DynamicPointSet 0} (hwf : P.WellFormed n)
    {ans : StoredDiameterAnswer}
    (hspec : if P.activeIds.card ≤ 1 then
               ans.diameterHandles = none ∧ ans.cachedDistSq = 0
             else
               ∃ h₁ h₂ : ℕ, h₁ ∈ P.activeHandles ∧ h₂ ∈ P.activeHandles ∧ h₁ ≠ h₂ ∧
                 ans.diameterHandles = some (h₁, h₂) ∧ ans.cachedDistSq = 0) :
    IsValidFactorCAnswer (Real.sqrt 2) P ans := by
  unfold IsValidFactorCAnswer
  by_cases hle : P.activeIds.card ≤ 1
  · rw [if_pos hle] at hspec ⊢; exact hspec
  · rw [if_neg hle] at hspec ⊢
    rcases hspec with ⟨h₁, h₂, hh₁, hh₂, hne, hdh, hsq⟩
    rcases hwf with ⟨_, _, hhId, _, _⟩
    have hid₁_in : P.idOfHandle h₁ ∈ P.activeIds := (hhId h₁ hh₁).1
    have hid₂_in : P.idOfHandle h₂ ∈ P.activeIds := (hhId h₂ hh₂).1
    have hid_ne : P.idOfHandle h₁ ≠ P.idOfHandle h₂ := by
      intro heq
      have := congrArg P.handleOfId heq
      rw [(hhId h₁ hh₁).2, (hhId h₂ hh₂).2] at this
      exact hne this
    have hzero_pt : ∀ x y : EuclideanSpace ℝ (Fin 0), x = y := fun x y => Subsingleton.elim x y
    have hdiam0 : indexedEuclideanDiam P.activeIds P.coords = 0 := by
      unfold indexedEuclideanDiam
      split_ifs with hneP
      · apply le_antisymm
        · apply Finset.sup'_le
          intro xy _
          rw [hzero_pt (P.coords xy.1) (P.coords xy.2), sub_self, norm_zero]
        · rcases hneP with ⟨a, ha⟩
          have hmem : (a, a) ∈ P.activeIds ×ˢ P.activeIds := Finset.mem_product.mpr ⟨ha, ha⟩
          have := Finset.le_sup' (f := fun xy : ℕ × ℕ => ‖P.coords xy.1 - P.coords xy.2‖) hmem
          simpa using this
      · rfl
    refine ⟨h₁, h₂, hdh, hh₁, hh₂, hne, ?_, hid₁_in, hid₂_in, hid_ne, ?_, ?_⟩
    · rw [hsq, euclideanDistSq, hzero_pt (P.coords _) (P.coords _), sub_self, norm_zero]; ring
    · rw [hdiam0, zero_div, hzero_pt (P.coords _) (P.coords _), sub_self, norm_zero]
    · rw [hdiam0, hzero_pt (P.coords _) (P.coords _), sub_self, norm_zero]

private theorem exec_clearAnsHeaderRegs {inp : BitRAMInput 0} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {L : ℕ}
    (hmod : ModifiedOnBounded ws₀ (dim0WriteLocs L) W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + (dim0WriteLocs L).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * (dim0WriteLocs L).card + 16 * (W + 12) ≤ C_bit)
    (hW20 : 20 ≤ W) {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit clearAnsHeaderRegs ws regs wsEnd regsEnd 40 (30 * W + 160) ∧
      ModifiedOnBounded ws₀ (dim0WriteLocs L) W wsEnd ∧
      RegBounded W regsEnd ∧
      BitRAMDynamicProgram.readCachedAnswer wsEnd = (none, 0) ∧
      wsEnd.read (.heap 0 0) = ws.read (.heap 0 0) ∧
      (∀ loc : RAMCellLoc, (∀ i : ℕ, 1 ≤ i → i ≤ 5 → loc ≠ .heap 0 (i : ℤ)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hn0 : natBitLength 0 ≤ W := by
    have hdec : natBitLength 0 = 1 := by decide
    omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ (dim0WriteLocs L) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have stepFree : ∀ (i : ℕ) (hi : i < 6) (w : WordStore) (g : ℕ → ℤ),
      ModifiedOnBounded ws₀ (dim0WriteLocs L) W w → RegBounded W g →
      intBitLength (i : ℤ) ≤ W →
      RegExec inp fd W C_cell C_bit (.seq (rLit 10 (i : ℤ)) (rFree 0 10))
        w g (w.free (.heap 0 (i : ℤ))) (Function.update g 10 (i : ℤ)) 8 (5 * W + 32) ∧
      ModifiedOnBounded ws₀ (dim0WriteLocs L) W (w.free (.heap 0 (i : ℤ))) ∧
      RegBounded W (Function.update g 10 (i : ℤ)) := by
    intro i hi w g hm bg hibl
    have a1 := RegExec.lit (inp := inp) hfd_le bg (sp_ok hm).1 (sp_ok hm).2 (dst := 10) (c := (i : ℤ)) (by decide) hibl
    have bg' : RegBounded W (Function.update g 10 (i : ℤ)) := bg.update (r := 10) (by decide) hibl
    have a2 := RegExec.free (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := w) bg' (table := 0) (addr := 10) (by decide) hn0
    simp only [Function.update_self] at a2
    exact ⟨(a1.seq a2).weaken rfl rfl (u₂ := 8) (b₂ := 5 * W + 32) (by omega) (by omega),
      hm.free (mem_dim0WriteLocs_tab0 hi), bg'⟩
  obtain ⟨s1, hm1, bg1⟩ := stepFree 1 (by decide) ws regs hmod hbnd (by exact (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega))
  obtain ⟨s2, hm2, bg2⟩ := stepFree 2 (by decide) _ _ hm1 bg1 (by exact (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by omega))
  obtain ⟨s3, hm3, bg3⟩ := stepFree 3 (by decide) _ _ hm2 bg2 (by exact (show intBitLength (3 : ℤ) = 3 from by decide).trans_le (by omega))
  obtain ⟨s4, hm4, bg4⟩ := stepFree 4 (by decide) _ _ hm3 bg3 (by exact (show intBitLength (4 : ℤ) = 4 from by decide).trans_le (by omega))
  obtain ⟨s5, hm5, bg5⟩ := stepFree 5 (by decide) _ _ hm4 bg4 (by exact (show intBitLength (5 : ℤ) = 4 from by decide).trans_le (by omega))
  set wsEnd := ((((ws.free (.heap 0 1)).free (.heap 0 2)).free (.heap 0 3)).free (.heap 0 4)).free (.heap 0 5)
  have sAll := (s1.seq (s2.seq (s3.seq (s4.seq s5)))).weaken rfl rfl (u₂ := 40) (b₂ := 30 * W + 160) (by omega) (by omega)
  refine ⟨wsEnd, _, sAll, hm5, bg5, ?_, ?_, ?_⟩
  · unfold BitRAMDynamicProgram.readCachedAnswer
    have hr1 : wsEnd.read (.heap 0 1) = 0 := by simp [wsEnd, WordStore.read, WordStore.free]
    have hr5 : wsEnd.read (.heap 0 5) = 0 := by simp [wsEnd, WordStore.read, WordStore.free]
    simp [hr1, hr5]
  · simp [wsEnd, WordStore.read, WordStore.free]
  · intro loc hne
    have n1 : loc ≠ .heap 0 1 := hne 1 (by decide) (by decide)
    have n2 : loc ≠ .heap 0 2 := hne 2 (by decide) (by decide)
    have n3 : loc ≠ .heap 0 3 := hne 3 (by decide) (by decide)
    have n4 : loc ≠ .heap 0 4 := hne 4 (by decide) (by decide)
    have n5 : loc ≠ .heap 0 5 := hne 5 (by decide) (by decide)
    exact ⟨by simp [wsEnd, WordStore.free, n1, n2, n3, n4, n5],
           by simp [wsEnd, WordStore.free, Function.update_of_ne n1, Function.update_of_ne n2,
                Function.update_of_ne n3, Function.update_of_ne n4, Function.update_of_ne n5]⟩

private theorem exec_writeDim0AnsRegs {inp : BitRAMInput 0} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {L h₁ h₂ : ℕ}
    (hmod : ModifiedOnBounded ws₀ (dim0WriteLocs L) W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + (dim0WriteLocs L).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * (dim0WriteLocs L).card + 16 * (W + 12) ≤ C_bit)
    (hW20 : 20 ≤ W) (hh₁ : intBitLength (h₁ : ℤ) ≤ W) (hh₂ : intBitLength (h₂ : ℤ) ≤ W)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr11 : regs 11 = (h₁ : ℤ)) (hr12 : regs 12 = (h₂ : ℤ)) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit writeDim0AnsRegs ws regs wsEnd regsEnd 70 (46 * W + 260) ∧
      ModifiedOnBounded ws₀ (dim0WriteLocs L) W wsEnd ∧
      RegBounded W regsEnd ∧
      BitRAMDynamicProgram.readCachedAnswer wsEnd = (some (h₁, h₂), 0) ∧
      wsEnd.read (.heap 0 0) = ws.read (.heap 0 0) ∧
      (∀ loc : RAMCellLoc, (∀ i : ℕ, 1 ≤ i → i ≤ 5 → loc ≠ .heap 0 (i : ℤ)) →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hn0 : natBitLength 0 ≤ W := by
    have hdec : natBitLength 0 = 1 := by decide
    omega
  have hl0 : intBitLength (0 : ℤ) ≤ W := by
    have hdec : intBitLength (0 : ℤ) = 1 := by decide
    omega
  have hl1 : intBitLength (1 : ℤ) ≤ W := by
    have hdec : intBitLength (1 : ℤ) = 2 := by decide
    omega
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded ws₀ (dim0WriteLocs L) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
  have loc_bl : ∀ i : ℕ, i < 6 → (RAMCellLoc.heap 0 (i : ℤ)).bitLength ≤ W := by
    intro i hi
    have h1 := intBitLength_ofNat_le i
    have h2 := natBitLength_mono (by omega : i ≤ 5)
    have hn5 : natBitLength 5 = 3 := by decide
    have hn0_eq : natBitLength 0 = 1 := by decide
    dsimp [RAMCellLoc.bitLength]; omega
  -- 1. write (0, 1) := 1
  have a1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 10) (c := 1) (by decide) hl1
  set g1 := Function.update regs 10 1; have bg1 : RegBounded W g1 := hbnd.update (r := 10) (by decide) hl1
  have a2 := RegExec.lit (inp := inp) hfd_le bg1 (sp_ok hmod).1 (sp_ok hmod).2 (dst := 13) (c := 1) (by decide) hl1
  set g2 := Function.update g1 13 1; have bg2 : RegBounded W g2 := bg1.update (r := 13) (by decide) hl1
  have hm1 : ModifiedOnBounded ws₀ (dim0WriteLocs L) W (ws.write (.heap 0 1) 1) :=
    hmod.write (mem_dim0WriteLocs_tab0 (by decide)) 1 (loc_bl 1 (by decide)) hl1
  have a3 := RegExec.store (inp := inp) hfd_le bg2 (table := 0) (addr := 10) (val := 13) (by decide) (by decide) hn0
    (by simpa [g2, g1] using (sp_ok hm1).1) (by simpa [g2, g1] using (sp_ok hm1).2)
  have hw1 : ws.write (.heap 0 (g2 10)) (g2 13) = ws.write (.heap 0 1) 1 := by simp [g2, g1]
  rw [hw1] at a3
  set w1 := ws.write (.heap 0 1) 1
  -- 2. write (0, 2) := h₁
  have a4 := RegExec.lit (inp := inp) hfd_le bg2 (sp_ok hm1).1 (sp_ok hm1).2 (dst := 10) (c := 2) (by decide) (by exact (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by omega))
  set g3 := Function.update g2 10 2; have bg3 : RegBounded W g3 := bg2.update (r := 10) (by decide) (by exact (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by omega))
  have hm2 : ModifiedOnBounded ws₀ (dim0WriteLocs L) W (w1.write (.heap 0 2) (h₁ : ℤ)) :=
    hm1.write (mem_dim0WriteLocs_tab0 (by decide)) (h₁ : ℤ) (loc_bl 2 (by decide)) hh₁
  have a5 := RegExec.store (inp := inp) hfd_le bg3 (table := 0) (addr := 10) (val := 11) (by decide) (by decide) hn0
    (by simpa [g3, g2, g1, hr11] using (sp_ok hm2).1) (by simpa [g3, g2, g1, hr11] using (sp_ok hm2).2)
  have hw2 : w1.write (.heap 0 (g3 10)) (g3 11) = w1.write (.heap 0 2) (h₁ : ℤ) := by simp [g3, g2, g1, hr11]
  rw [hw2] at a5
  set w2 := w1.write (.heap 0 2) (h₁ : ℤ)
  -- 3. write (0, 3) := h₂
  have a6 := RegExec.lit (inp := inp) hfd_le bg3 (sp_ok hm2).1 (sp_ok hm2).2 (dst := 10) (c := 3) (by decide) (by exact (show intBitLength (3 : ℤ) = 3 from by decide).trans_le (by omega))
  set g4 := Function.update g3 10 3; have bg4 : RegBounded W g4 := bg3.update (r := 10) (by decide) (by exact (show intBitLength (3 : ℤ) = 3 from by decide).trans_le (by omega))
  have hm3 : ModifiedOnBounded ws₀ (dim0WriteLocs L) W (w2.write (.heap 0 3) (h₂ : ℤ)) :=
    hm2.write (mem_dim0WriteLocs_tab0 (by decide)) (h₂ : ℤ) (loc_bl 3 (by decide)) hh₂
  have a7 := RegExec.store (inp := inp) hfd_le bg4 (table := 0) (addr := 10) (val := 12) (by decide) (by decide) hn0
    (by simpa [g4, g3, g2, g1, hr12] using (sp_ok hm3).1) (by simpa [g4, g3, g2, g1, hr12] using (sp_ok hm3).2)
  have hw3 : w2.write (.heap 0 (g4 10)) (g4 12) = w2.write (.heap 0 3) (h₂ : ℤ) := by simp [g4, g3, g2, g1, hr12]
  rw [hw3] at a7
  set w3 := w2.write (.heap 0 3) (h₂ : ℤ)
  -- 4. write (0, 4) := 0
  have a8 := RegExec.lit (inp := inp) hfd_le bg4 (sp_ok hm3).1 (sp_ok hm3).2 (dst := 10) (c := 4) (by decide) (by exact (show intBitLength (4 : ℤ) = 4 from by decide).trans_le (by omega))
  set g5 := Function.update g4 10 4; have bg5 : RegBounded W g5 := bg4.update (r := 10) (by decide) (by exact (show intBitLength (4 : ℤ) = 4 from by decide).trans_le (by omega))
  have a9 := RegExec.lit (inp := inp) hfd_le bg5 (sp_ok hm3).1 (sp_ok hm3).2 (dst := 13) (c := 0) (by decide) hl0
  set g6 := Function.update g5 13 0; have bg6 : RegBounded W g6 := bg5.update (r := 13) (by decide) hl0
  have hm4 : ModifiedOnBounded ws₀ (dim0WriteLocs L) W (w3.write (.heap 0 4) 0) :=
    hm3.write (mem_dim0WriteLocs_tab0 (by decide)) 0 (loc_bl 4 (by decide)) hl0
  have a10 := RegExec.store (inp := inp) hfd_le bg6 (table := 0) (addr := 10) (val := 13) (by decide) (by decide) hn0
    (by simpa [g6, g5] using (sp_ok hm4).1) (by simpa [g6, g5] using (sp_ok hm4).2)
  have hw4 : w3.write (.heap 0 (g6 10)) (g6 13) = w3.write (.heap 0 4) 0 := by simp [g6, g5]
  rw [hw4] at a10
  set w4 := w3.write (.heap 0 4) 0
  -- 5. write (0, 5) := 1
  have a11 := RegExec.lit (inp := inp) hfd_le bg6 (sp_ok hm4).1 (sp_ok hm4).2 (dst := 10) (c := 5) (by decide) (by exact (show intBitLength (5 : ℤ) = 4 from by decide).trans_le (by omega))
  set g7 := Function.update g6 10 5; have bg7 : RegBounded W g7 := bg6.update (r := 10) (by decide) (by exact (show intBitLength (5 : ℤ) = 4 from by decide).trans_le (by omega))
  have a12 := RegExec.lit (inp := inp) hfd_le bg7 (sp_ok hm4).1 (sp_ok hm4).2 (dst := 13) (c := 1) (by decide) hl1
  set g8 := Function.update g7 13 1; have bg8 : RegBounded W g8 := bg7.update (r := 13) (by decide) hl1
  have hm5 : ModifiedOnBounded ws₀ (dim0WriteLocs L) W (w4.write (.heap 0 5) 1) :=
    hm4.write (mem_dim0WriteLocs_tab0 (by decide)) 1 (loc_bl 5 (by decide)) hl1
  have a13 := RegExec.store (inp := inp) hfd_le bg8 (table := 0) (addr := 10) (val := 13) (by decide) (by decide) hn0
    (by simpa [g8, g7] using (sp_ok hm5).1) (by simpa [g8, g7] using (sp_ok hm5).2)
  have hw5 : w4.write (.heap 0 (g8 10)) (g8 13) = w4.write (.heap 0 5) 1 := by simp [g8, g7]
  rw [hw5] at a13
  set wsEnd := w4.write (.heap 0 5) 1
  have sAll := (a1.seq (a2.seq (a3.seq (a4.seq (a5.seq (a6.seq (a7.seq (a8.seq (a9.seq (a10.seq (a11.seq (a12.seq a13)))))))))))).weaken
    rfl rfl (u₂ := 70) (b₂ := 46 * W + 260) (by omega) (by omega)
  refine ⟨wsEnd, g8, sAll, hm5, bg8, ?_, ?_, ?_⟩
  · unfold BitRAMDynamicProgram.readCachedAnswer
    have r1 : wsEnd.read (.heap 0 1) = 1 := by simp [wsEnd, w4, w3, w2, w1, WordStore.read, WordStore.write]
    have r2 : wsEnd.read (.heap 0 2) = (h₁ : ℤ) := by simp [wsEnd, w4, w3, w2, WordStore.read, WordStore.write]
    have r3 : wsEnd.read (.heap 0 3) = (h₂ : ℤ) := by simp [wsEnd, w4, w3, WordStore.read, WordStore.write]
    have r4 : wsEnd.read (.heap 0 4) = 0 := by simp [wsEnd, w4, WordStore.read, WordStore.write]
    have r5 : wsEnd.read (.heap 0 5) = 1 := by simp [wsEnd, WordStore.read, WordStore.write]
    simp [r1, r2, r3, r4, r5]
  · simp [wsEnd, w4, w3, w2, w1, WordStore.read, WordStore.write]
  · intro loc hne
    have n1 : loc ≠ .heap 0 1 := hne 1 (by decide) (by decide)
    have n2 : loc ≠ .heap 0 2 := hne 2 (by decide) (by decide)
    have n3 : loc ≠ .heap 0 3 := hne 3 (by decide) (by decide)
    have n4 : loc ≠ .heap 0 4 := hne 4 (by decide) (by decide)
    have n5 : loc ≠ .heap 0 5 := hne 5 (by decide) (by decide)
    exact ⟨by simp [wsEnd, w4, w3, w2, w1, WordStore.write, n1, n2, n3, n4, n5],
           by simp [wsEnd, w4, w3, w2, w1, WordStore.write, Function.update_of_ne n1,
                Function.update_of_ne n2, Function.update_of_ne n3, Function.update_of_ne n4,
                Function.update_of_ne n5]⟩

theorem exec_progDim0_step {n B : ℕ} (hn : 2 ≤ n) (_hB : 1 ≤ B)
    {P : DynamicPointSet 0} {ws : WordStore}
    (hinv : Dim0Inv n (Nat.clog 2 (2 * n)) P ws)
    (hAdm : ∀ id ∈ P.activeIds, P.coords id ∈ RatAdmissiblePointSet 0 B)
    {op : DynamicUpdate 0}
    (hleg : IsLegalUpdate n (RatAdmissiblePointSet 0 B) P op)
    {initOut : BitRAMExecOutcome} :
    let L := Nat.clog 2 (2 * n)
    let W := L + 24
    let alg := bitRAMAlg (d := 0) n (progDim0 L) initOut
    ∃ (P' : DynamicPointSet 0) (out : DynamicStepOutcome WordStore),
      runSingleAdaptiveStep alg P ws op [] = some (P', out) ∧
      Dim0Inv n L P' out.nextState ∧
      (∀ id' ∈ P'.activeIds, P'.coords id' ∈ RatAdmissiblePointSet 0 B) ∧
      IsValidFactorCAnswer (Real.sqrt 2) P' out.storedAnswer ∧
      out.work ≤ (260 * L + 320) * W * W ∧
      out.peakSpace ≤ 120 * n * W := by
  intro L W alg
  have hW_def : W = L + 24 := rfl
  obtain ⟨hL2, _, h2n_pow, hpow_4n⟩ := clog_two_mul_bounds hn
  change 2 ≤ L at hL2; change 2 * n ≤ 2 ^ L at h2n_pow; change 2 ^ L < 4 * n at hpow_4n
  have hL1 : 1 ≤ L := by omega
  have hW20 : 20 ≤ W := by omega
  have hWW : 20 * W ≤ W * W := by nlinarith only [hW20]
  have hH_card_le : P.activeHandles.card ≤ n := (activeHandles_card_eq hinv.wfP).trans_le hinv.wfP.1
  have hn_bl : intBitLength (n : ℤ) ≤ W :=
    (nat_lt_pow2_bitLength_le (by omega : n < 2 ^ L)).trans (by dsimp [W]; omega)
  have hActRat : ∀ h ∈ P.activeHandles, (euclideanToRatPoint? (P.handleCoords h)).isSome := by
    intro h hh
    rcases hinv.wfP with ⟨_, _, hhId, _, _⟩
    have hid_in : P.idOfHandle h ∈ P.activeIds := (hhId h hh).1
    have hc_eq : P.handleCoords h = P.coords (P.idOfHandle h) := by simp [DynamicPointSet.handleCoords, hh]
    rw [hc_eq]
    obtain ⟨q, hq, _, _⟩ := euclideanToRatPoint_of_admissible (hAdm _ hid_in)
    simp [hq]
  -- Construct input `inp` and step transition depending on `op`
  set S := P.activeHandles
  have hS_card_eq : S.card = P.activeIds.card := activeHandles_card_eq hinv.wfP
  let C_cell : ℕ := 48 * n + 32
  let C_bit : ℕ := 120 * n * W
  have hcard_write : (dim0WriteLocs L).card ≤ 32 * n + 8 := by
    have := dim0WriteLocs_card_le L; omega
  have hSubTree : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L 0 u f) : RAMCellLoc) ∈ dim0WriteLocs L :=
    fun u hu f hf => mem_dim0WriteLocs_tree hu hf
  have hSub100 : (.heap 9 100 : RAMCellLoc) ∈ dim0WriteLocs L := by
    unfold dim0WriteLocs; exact Finset.mem_union_right _ (by simp)
  have hSub101 : (.heap 9 101 : RAMCellLoc) ∈ dim0WriteLocs L := by
    unfold dim0WriteLocs; exact Finset.mem_union_right _ (by simp)
  -- Unified helper on `(inp, isInsFlag, delH)`
  have hLWW : 0 ≤ L * W * W := by positivity
  have runBody : ∀ (inp : BitRAMInput 0) (isIns : Bool) (delH : ℕ),
      inp.intParams = [(n : ℤ), if isIns then 1 else 0, if isIns then 0 else (delH : ℤ)] →
      inp.inputCellSpace ≤ 3 + n + 2 →
      inp.inputBitSpace ≤ 2 * W + n * (L + 2) + 8 →
      (isIns = true → S.card < n) →
      (isIns = false → delH ∈ S) →
      ∃ wsEnd : WordStore,
        ∃ out : BitRAMExecOutcome,
          runBitRAMWithBits (progDim0 L).updateStmt inp ws [] = some out ∧
          out.words = wsEnd ∧
          out.bitCost ≤ (260 * L + 320) * W * W ∧
          out.peakBitSpace ≤ C_bit ∧
          let S' := if isIns then insert (mexHandle S) S else S.erase delH
          ModifiedOnBounded WordStore.empty (dim0WriteLocs L) W wsEnd ∧
          TreeStoredAt L 0 S' (fun _ => 0) (fun _ => 1) wsEnd ∧
          (.heap 9 100 : RAMCellLoc) ∉ wsEnd.live ∧
          (.heap 9 101 : RAMCellLoc) ∉ wsEnd.live ∧
          (isIns = true → wsEnd.read (.heap 0 0) = (mexHandle S : ℤ)) ∧
          (if S'.card ≤ 1 then
             BitRAMDynamicProgram.readCachedAnswer wsEnd = (none, 0)
           else
             ∃ h₁ h₂ : ℕ, h₁ ∈ S' ∧ h₂ ∈ S' ∧ h₁ ≠ h₂ ∧
               BitRAMDynamicProgram.readCachedAnswer wsEnd = (some (h₁, h₂), 0)) := by
    intro inp isIns delH hinp_p hinp_c hinp_b hins_lt hdel_in
    set S' := if isIns then insert (mexHandle S) S else S.erase delH
    have hcCeil : inp.inputCellSpace + WordStore.empty.cellCount + (dim0WriteLocs L).card + 16 ≤ C_cell := by
      have : WordStore.empty.cellCount = 0 := by simp [WordStore.cellCount, WordStore.empty]
      dsimp [C_cell]; omega
    have hbCeil : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (dim0WriteLocs L).card + 16 * (W + 12) ≤ C_bit := by
      have he0 : WordStore.empty.bitSize = 0 := by simp [WordStore.bitSize, WordStore.empty]
      have hWL : L + 2 ≤ W := by dsimp [W]; omega
      have hnL : n * (L + 2) ≤ n * W := Nat.mul_le_mul_left n hWL
      have h2W : 2 * W * (dim0WriteLocs L).card ≤ 64 * n * W + 16 * W := by nlinarith only [hcard_write]
      dsimp [C_bit]; nlinarith only [hinp_b, he0, hnL, h2W, hn, hW20]
    have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (dim0WriteLocs L) W w →
        inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
        inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
      intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
      exact ⟨by linarith only [cs, hcCeil], by linarith only [bs, hbCeil]⟩
    have bg0 : RegBounded W (fun _ => 0) := RegBounded.init (by omega)
    have hl0 : intBitLength (0 : ℤ) ≤ W := (show intBitLength (0 : ℤ) = 1 from by decide).trans_le (by omega)
    have hl1 : intBitLength (1 : ℤ) ≤ W := (show intBitLength (1 : ℤ) = 2 from by decide).trans_le (by omega)
    have hl2 : intBitLength (2 : ℤ) ≤ W := (show intBitLength (2 : ℤ) = 3 from by decide).trans_le (by omega)
    have hp1_bl : intBitLength (listGetIntD inp.intParams 1 0) ≤ W := by
      rw [hinp_p]; cases isIns <;> simp [listGetIntD, hl0, hl1]
    have hp2_bl : intBitLength (listGetIntD inp.intParams 2 0) ≤ W := by
      rw [hinp_p]
      by_cases hI : isIns = true
      · simp [hI, listGetIntD, hl0]
      · have hIf : isIns = false := Bool.eq_false_iff.mpr hI
        simp [hIf, listGetIntD]
        have hlt : delH < 2 ^ L := hinv.tree.hS _ (hdel_in hIf)
        exact (nat_lt_pow2_bitLength_le hlt).trans (by dsimp [W]; omega)
    have p1 := RegExec.intParam (inp := inp) (fd := 1) (by decide) bg0 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
      (dst := 5) (by decide) 1 hl1 hp1_bl
    set g1 := Function.update (fun _ => (0 : ℤ)) 5 (listGetIntD inp.intParams 1 0)
    have bg1 : RegBounded W g1 := bg0.update (r := 5) (by decide) hp1_bl
    have p2 := RegExec.intParam (inp := inp) (fd := 1) (by decide) bg1 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
      (dst := 6) (by decide) 2 hl2 hp2_bl
    set g2 := Function.update g1 6 (listGetIntD inp.intParams 2 0)
    have bg2 : RegBounded W g2 := bg1.update (r := 6) (by decide) hp2_bl
    have p3 := RegExec.lit (inp := inp) (fd := 1) (by decide) bg2 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
      (dst := 0) (c := 0) (by decide) hl0
    set g3 := Function.update g2 0 0; have bg3 : RegBounded W g3 := bg2.update (r := 0) (by decide) hl0
    have p4 := RegExec.lit (inp := inp) (fd := 1) (by decide) bg3 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
      (dst := 14) (c := 1) (by decide) hl1
    set g4 := Function.update g3 14 1; have bg4 : RegBounded W g4 := bg3.update (r := 14) (by decide) hl1
    have hW_tree : 2 * 2 + natBitLength 0 + L + 16 ≤ W := by
      have : natBitLength 0 = 1 := by decide
      dsimp [W]; omega
    have hS_bnds : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 :=
      fun h hm => ⟨hinv.tree.hS h hm, by dsimp only; decide, by dsimp only; decide⟩
    -- Branch 1: insert vs delete on `tid = 0`
    have hUpdBranch : ∃ wsMid gMid,
        RegExec inp 1 W C_cell C_bit
          (.ite (.intEq (.readLocal 5 (.lit 0)) (.readLocal 14 (.lit 0)))
            (.seq (treeMexRegs L)
            (.seq (rLit 10 0)
            (.seq (rStore 0 10 1)
            (.seq (rLit 2 1)
            (.seq (rLit 3 0)
            (.seq (rLit 4 1)
                  (treeSetLeafRegs L)))))))
            (.seq (rCopy 1 6)
            (.seq (rLit 2 0)
            (.seq (rLit 3 0)
            (.seq (rLit 4 0)
                  (treeSetLeafRegs L))))))
          ws g4 wsMid gMid (450 * L + 280) ((76 * L + 48) * W * W) ∧
        ModifiedOnBounded WordStore.empty (dim0WriteLocs L) W wsMid ∧
        RegBounded W gMid ∧
        TreeStoredAt L 0 S' (fun _ => 0) (fun _ => 1) wsMid ∧
        (.heap 9 100 : RAMCellLoc) ∉ wsMid.live ∧
        (.heap 9 101 : RAMCellLoc) ∉ wsMid.live ∧
        (isIns = true → wsMid.read (.heap 0 0) = (mexHandle S : ℤ)) := by
      cases hI : isIns
      · -- Delete branch (`isIns = false`)
        have hne5 : g4 5 ≠ g4 14 := by simp [g4, g3, g2, g1, hinp_p, hI, listGetIntD]
        have hd_in : delH ∈ S := hdel_in hI
        have hd_lt : delH < 2 ^ L := hinv.tree.hS delH hd_in
        have hd_eq : g4 6 = (delH : ℤ) := by simp [g4, g3, g2, hinp_p, hI, listGetIntD]
        have b1 := RegExec.copy (inp := inp) (fd := 1) (by decide) bg4 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2 (dst := 1) (src := 6) (by decide) (by decide)
        set q1 := Function.update g4 1 (g4 6); have bq1 : RegBounded W q1 := bg4.update (r := 1) (by decide) (bg4.2.1 6 (by decide))
        have b2 := RegExec.lit (inp := inp) (fd := 1) (by decide) bq1 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2 (dst := 2) (c := 0) (by decide) hl0
        set q2 := Function.update q1 2 0; have bq2 : RegBounded W q2 := bq1.update (r := 2) (by decide) hl0
        have b3 := RegExec.lit (inp := inp) (fd := 1) (by decide) bq2 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2 (dst := 3) (c := 0) (by decide) hl0
        set q3 := Function.update q2 3 0; have bq3 : RegBounded W q3 := bq2.update (r := 3) (by decide) hl0
        have b4 := RegExec.lit (inp := inp) (fd := 1) (by decide) bq3 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2 (dst := 4) (c := 0) (by decide) hl0
        set q4 := Function.update q3 4 0; have bq4 : RegBounded W q4 := bq3.update (r := 4) (by decide) hl0
        have hPathSub : treePathLocs L 0 delH ⊆ dim0WriteLocs L := by
          intro loc hl
          simp only [treePathLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hl
          rcases hl with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
          have hoff_lt : delH / 2 ^ k < 2 ^ (L - k) := by
            rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add]
            have : L - k + k = L := by omega
            rw [this]; exact hd_lt
          exact hSubTree _ (treeIdx_bounds (by omega) hoff_lt).2 f hf
        obtain ⟨wsMid, q5, b5, hmMid, bq5, htreeMid, hunchMid⟩ :=
          exec_treeSetLeafRegs (inp := inp) (fd := 1) (by decide) hinv.mod hcCeil hbCeil hL1 hd_lt (B_r := 2) (by decide) hW_tree
            hPathSub (S := S) (S' := S.erase delH) hinv.tree (rNum' := fun _ => 0) (rDen' := fun _ => 1)
            (fun h hm => hS_bnds h (Finset.mem_of_mem_erase hm))
            (fun h hne => by simp [Finset.mem_erase, hne]) (fun _ _ => rfl) (fun _ _ => rfl)
            false (by simp) bq4
            (by simp [q4, q3, q2, q1, g4, g3])
            (by simp [q4, q3, q2, q1, hd_eq])
            (by simp [q4, q3, q2])
            (by intro hh; cases hh) (by intro hh; cases hh)
        have hb_del : 2 * W + 24 + (2 * W + 16 + (2 * W + 16 + (2 * W + 16 + (56 * L + 32) * W * W))) ≤ (76 * L + 44) * W * W := by
          calc 2 * W + 24 + (2 * W + 16 + (2 * W + 16 + (2 * W + 16 + (56 * L + 32) * W * W)))
            _ = (8 * W + 72) + (56 * L + 32) * W * W := by ring
            _ ≤ 12 * (W * W) + (56 * L + 32) * W * W := Nat.add_le_add_right (by linarith only [hW20, hWW]) _
            _ = (56 * L + 44) * W * W := by ring
            _ ≤ (76 * L + 44) * W * W := Nat.mul_le_mul_right W (Nat.mul_le_mul_right W (by omega))
        have sDel := (b1.seq (b2.seq (b3.seq (b4.seq b5)))).weaken rfl rfl
          (u₂ := 440 * L + 260) (b₂ := (76 * L + 44) * W * W) (by omega) hb_del
        have sIte := (RegExec.iteEq bg4 (a := 5) (b := 14) (by decide) (by decide)
          (tB := .seq (treeMexRegs L) (.seq (rLit 10 0) (.seq (rStore 0 10 1) (.seq (rLit 2 1) (.seq (rLit 3 0) (.seq (rLit 4 1) (treeSetLeafRegs L)))))))
          (by rw [if_neg hne5]; exact sDel)).weaken rfl rfl
          (u₂ := 450 * L + 280) (b₂ := (76 * L + 48) * W * W) (by omega) (by nlinarith only [hW20, hL1, hLWW])
        have h9_notin : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∉ treePathLocs L 0 delH := by
          intro z hm; simp only [treePathLocs, Finset.mem_image] at hm; rcases hm with ⟨_, _, h⟩; cases h
        exact ⟨wsMid, q5, sIte, hmMid, bq5, by simpa [S', hI] using htreeMid,
          by rw [(hunchMid _ (h9_notin 100)).1]; exact hinv.no100,
          by rw [(hunchMid _ (h9_notin 101)).1]; exact hinv.no101,
          fun hh => by cases hh⟩
      · -- Insert branch (`isIns = true`)
        have heq5 : g4 5 = g4 14 := by simp [g4, g3, g2, g1, hinp_p, hI, listGetIntD]
        have hc_lt : S.card < 2 ^ L := by have := hins_lt hI; omega
        set hNew := mexHandle S
        have hhNew_lt : hNew < 2 ^ L := mexHandle_lt_of_card_lt hc_lt
        have hhNew_bl : intBitLength (hNew : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hhNew_lt).trans (by dsimp [W]; omega)
        obtain ⟨q1, b1, bq1, q1_0, q1_1, _⟩ :=
          exec_treeMexRegs (inp := inp) (fd := 1) (by decide) (sp_ok hinv.mod).1 (sp_ok hinv.mod).2
            hL1 (by decide : 1 ≤ 2) hW_tree (S := S) hinv.tree hS_bnds hc_lt bg4 (by simp [g4, g3])
        have b2 := RegExec.lit (inp := inp) (fd := 1) (by decide) bq1 (sp_ok hinv.mod).1 (sp_ok hinv.mod).2 (dst := 10) (c := 0) (by decide) hl0
        set q2 := Function.update q1 10 0; have bq2 : RegBounded W q2 := bq1.update (r := 10) (by decide) hl0
        have hn0 : natBitLength 0 ≤ W := by
          have hdec : natBitLength 0 = 1 := by decide
          omega
        have hloc00 : (RAMCellLoc.heap 0 0).bitLength ≤ W := by
          have : (RAMCellLoc.heap 0 0).bitLength = 2 := by decide
          omega
        have hm_w0 : ModifiedOnBounded WordStore.empty (dim0WriteLocs L) W (ws.write (.heap 0 0) (hNew : ℤ)) :=
          hinv.mod.write (mem_dim0WriteLocs_tab0 (by decide)) (hNew : ℤ) hloc00 hhNew_bl
        have b3 := RegExec.store (inp := inp) (fd := 1) (by decide) bq2 (table := 0) (addr := 10) (val := 1)
          (by decide) (by decide) hn0
          (by simpa [q2, q1_1, hNew] using (sp_ok hm_w0).1) (by simpa [q2, q1_1, hNew] using (sp_ok hm_w0).2)
        have hw0 : ws.write (.heap 0 (q2 10)) (q2 1) = ws.write (.heap 0 0) (hNew : ℤ) := by simp [q2, q1_1, hNew]
        rw [hw0] at b3
        set ws0 := ws.write (.heap 0 0) (hNew : ℤ)
        have htree0 : TreeStoredAt L 0 S (fun _ => 0) (fun _ => 1) ws0 :=
          hinv.tree.unchanged (fun u _ f _ => by simp [ws0, WordStore.write])
        have b4 := RegExec.lit (inp := inp) (fd := 1) (by decide) bq2 (sp_ok hm_w0).1 (sp_ok hm_w0).2 (dst := 2) (c := 1) (by decide) hl1
        set q3 := Function.update q2 2 1; have bq3 : RegBounded W q3 := bq2.update (r := 2) (by decide) hl1
        have b5 := RegExec.lit (inp := inp) (fd := 1) (by decide) bq3 (sp_ok hm_w0).1 (sp_ok hm_w0).2 (dst := 3) (c := 0) (by decide) hl0
        set q4 := Function.update q3 3 0; have bq4 : RegBounded W q4 := bq3.update (r := 3) (by decide) hl0
        have b6 := RegExec.lit (inp := inp) (fd := 1) (by decide) bq4 (sp_ok hm_w0).1 (sp_ok hm_w0).2 (dst := 4) (c := 1) (by decide) hl1
        set q5 := Function.update q4 4 1; have bq5 : RegBounded W q5 := bq4.update (r := 4) (by decide) hl1
        have hPathSub : treePathLocs L 0 hNew ⊆ dim0WriteLocs L := by
          intro loc hl
          simp only [treePathLocs, Finset.mem_image, Finset.mem_product, Finset.mem_range] at hl
          rcases hl with ⟨⟨k, f⟩, ⟨hk, hf⟩, rfl⟩
          have hoff_lt : hNew / 2 ^ k < 2 ^ (L - k) := by
            rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add]
            have : L - k + k = L := by omega
            rw [this]; exact hhNew_lt
          exact hSubTree _ (treeIdx_bounds (by omega) hoff_lt).2 f hf
        obtain ⟨wsMid, q6, b7, hmMid, bq6, htreeMid, hunchMid⟩ :=
          exec_treeSetLeafRegs (inp := inp) (fd := 1) (by decide) hm_w0 hcCeil hbCeil hL1 hhNew_lt (B_r := 2) (by decide) hW_tree
            hPathSub (S := S) (S' := insert hNew S) htree0 (rNum' := fun _ => 0) (rDen' := fun _ => 1)
            (fun h hm => by
              rcases Finset.mem_insert.mp hm with rfl | hold
              · exact ⟨hhNew_lt, by dsimp only; decide, by dsimp only; decide⟩
              · exact hS_bnds h hold)
            (fun h hne => by simp [Finset.mem_insert, hne]) (fun _ _ => rfl) (fun _ _ => rfl)
            true (by simp) bq5
            (by simp [q5, q4, q3, q2, q1_0])
            (by simp [q5, q4, q3, q2, q1_1, hNew])
            (by simp [q5, q4, q3])
            (fun _ => by simp [q5, q4])
            (fun _ => by simp [q5])
        have sIns := (b1.seq (b2.seq (b3.seq (b4.seq (b5.seq (b6.seq b7)))))).weaken rfl rfl
          (u₂ := 440 * L + 260) (b₂ := (76 * L + 44) * W * W) (by omega) (by nlinarith only [hW20, hL1, hLWW])
        have sIte := (RegExec.iteEq bg4 (a := 5) (b := 14) (by decide) (by decide)
          (fB := .seq (rCopy 1 6) (.seq (rLit 2 0) (.seq (rLit 3 0) (.seq (rLit 4 0) (treeSetLeafRegs L)))))
          (by rw [if_pos heq5]; exact sIns)).weaken rfl rfl
          (u₂ := 450 * L + 280) (b₂ := (76 * L + 48) * W * W) (by omega) (by nlinarith only [hW20, hL1, hLWW])
        have h9_notin : ∀ z : ℤ, (.heap 9 z : RAMCellLoc) ∉ treePathLocs L 0 hNew := by
          intro z hm; simp only [treePathLocs, Finset.mem_image] at hm; rcases hm with ⟨_, _, h⟩; cases h
        have h0_notin : (.heap 0 0 : RAMCellLoc) ∉ treePathLocs L 0 hNew := by
          intro hm; simp only [treePathLocs, Finset.mem_image] at hm; rcases hm with ⟨_, _, h⟩; cases h
        refine ⟨wsMid, q6, sIte, hmMid, bq6, by simpa [S', hI] using htreeMid,
          by rw [(hunchMid _ (h9_notin 100)).1]; simp [ws0, WordStore.write, hinv.no100],
          by rw [(hunchMid _ (h9_notin 101)).1]; simp [ws0, WordStore.write, hinv.no101],
          fun _ => ?_⟩
        rw [wordStore_read_eq_vals hmMid.wf, (hunchMid _ h0_notin).2]
        simp [ws0, WordStore.write, hNew]
    obtain ⟨wsMid, gMid, sUpd, hmMid, bgMid, htreeMid, hn100Mid, hn101Mid, hretMid⟩ := hUpdBranch
    -- Read root count of `tid = 0`
    have p5 := RegExec.lit (inp := inp) (fd := 1) (by decide) bgMid (sp_ok hmMid).1 (sp_ok hmMid).2 (dst := 0) (c := 0) (by decide) hl0
    set g5 := Function.update gMid 0 0; have bg5 : RegBounded W g5 := bgMid.update (r := 0) (by decide) hl0
    have hS'_bnds : ∀ h ∈ S', h < 2 ^ L ∧ intBitLength ((fun _ => (0 : ℤ)) h) ≤ 2 ∧ intBitLength ((fun _ => (1 : ℤ)) h) ≤ 2 :=
      fun h hm => ⟨htreeMid.hS h hm, by dsimp only; decide, by dsimp only; decide⟩
    obtain ⟨g6, p6, bg6, g6_0, g6_1, _, _, _, _⟩ :=
      exec_treeReadRootRegs (inp := inp) (fd := 1) (by decide) (sp_ok hmMid).1 (sp_ok hmMid).2
        (by decide : 1 ≤ 2) hW_tree htreeMid hS'_bnds bg5 (by simp [g5])
    have p7 := RegExec.lit (inp := inp) (fd := 1) (by decide) bg6 (sp_ok hmMid).1 (sp_ok hmMid).2 (dst := 14) (c := 2) (by decide) hl2
    set g7 := Function.update g6 14 2; have bg7 : RegBounded W g7 := bg6.update (r := 14) (by decide) hl2
    -- Branch 2: `S'.card < 2` vs `2 ≤ S'.card`
    have hAnsBranch : ∃ wsEnd gEnd,
        RegExec inp 1 W C_cell C_bit
          (.ite (.intLt (.readLocal 1 (.lit 0)) (.readLocal 14 (.lit 0)))
            clearAnsHeaderRegs
            (.seq (getTwoMinHandlesRegs L) writeDim0AnsRegs))
          wsMid g7 wsEnd gEnd (1000 * L + 720) ((150 * L + 240) * W * W) ∧
        ModifiedOnBounded WordStore.empty (dim0WriteLocs L) W wsEnd ∧
        TreeStoredAt L 0 S' (fun _ => 0) (fun _ => 1) wsEnd ∧
        (.heap 9 100 : RAMCellLoc) ∉ wsEnd.live ∧
        (.heap 9 101 : RAMCellLoc) ∉ wsEnd.live ∧
        wsEnd.read (.heap 0 0) = wsMid.read (.heap 0 0) ∧
        (if S'.card ≤ 1 then
           BitRAMDynamicProgram.readCachedAnswer wsEnd = (none, 0)
         else
           ∃ h₁ h₂ : ℕ, h₁ ∈ S' ∧ h₂ ∈ S' ∧ h₁ ≠ h₂ ∧
             BitRAMDynamicProgram.readCachedAnswer wsEnd = (some (h₁, h₂), 0)) := by
      by_cases hle1 : S'.card ≤ 1
      · have hlt_reg : g7 1 < g7 14 := by simp [g7, g6_1]; omega
        obtain ⟨wsEnd, gEnd, sClr, hmEnd, _, hca, hr0_eq, hunch⟩ :=
          exec_clearAnsHeaderRegs (inp := inp) (fd := 1) (by decide) hmMid hcCeil hbCeil hW20 bg7
        have sIte := (RegExec.iteLt bg7 (a := 1) (b := 14) (by decide) (by decide)
          (fB := .seq (getTwoMinHandlesRegs L) writeDim0AnsRegs)
          (by rw [if_pos hlt_reg]; exact sClr)).weaken rfl rfl
          (u₂ := 1000 * L + 720) (b₂ := (150 * L + 240) * W * W) (by omega) (by nlinarith only [hW20, hL1, hLWW])
        have htreeEnd : TreeStoredAt L 0 S' (fun _ => 0) (fun _ => 1) wsEnd :=
          htreeMid.unchanged (fun u _ f _ => hunch _ (fun _ _ _ => by simp))
        exact ⟨wsEnd, gEnd, sIte, hmEnd, htreeEnd,
          by rw [(hunch _ (fun _ _ _ => by simp)).1]; exact hn100Mid,
          by rw [(hunch _ (fun _ _ _ => by simp)).1]; exact hn101Mid,
          hr0_eq, by rw [if_pos hle1]; exact hca⟩
      · have hnot_lt : ¬ (g7 1 < g7 14) := by simp [g7, g6_1]; omega
        have hcard2 : 2 ≤ S'.card := by omega
        have hW_tm : natBitLength 0 + L + 20 ≤ W := by
          have : natBitLength 0 = 1 := by decide
          dsimp [W]; omega
        obtain ⟨wsTwo, gTwo, h₁, h₂, hh₁_in, hh₂_in, hne12, sTwo, hmTwo, bgTwo, htreeTwo, r11_eq, r12_eq, hunchTwo⟩ :=
          exec_getTwoMinHandlesRegs (inp := inp) (fd := 1) (by decide) hmMid hcCeil hbCeil hL1 hW_tm
            htreeMid hcard2 hSubTree hSub100 hSub101 hn100Mid hn101Mid bg7 (by simp [g7, g6_0])
        have hh₁_bl : intBitLength (h₁ : ℤ) ≤ W :=
          (nat_lt_pow2_bitLength_le (htreeTwo.hS h₁ hh₁_in)).trans (by dsimp [W]; omega)
        have hh₂_bl : intBitLength (h₂ : ℤ) ≤ W :=
          (nat_lt_pow2_bitLength_le (htreeTwo.hS h₂ hh₂_in)).trans (by dsimp [W]; omega)
        obtain ⟨wsEnd, gEnd, sWr, hmEnd, _, hca, hr0_eq, hunchWr⟩ :=
          exec_writeDim0AnsRegs (inp := inp) (fd := 1) (by decide) hmTwo hcCeil hbCeil hW20 hh₁_bl hh₂_bl bgTwo r11_eq r12_eq
        have sSeq := (sTwo.seq sWr).weaken rfl rfl (u₂ := 980 * L + 700) (b₂ := (150 * L + 220) * W * W)
          (by omega) (by nlinarith only [hW20, hL1, hLWW])
        have sIte := (RegExec.iteLt bg7 (a := 1) (b := 14) (by decide) (by decide)
          (tB := clearAnsHeaderRegs)
          (by rw [if_neg hnot_lt]; exact sSeq)).weaken rfl rfl
          (u₂ := 1000 * L + 720) (b₂ := (150 * L + 240) * W * W) (by omega) (by nlinarith only [hW20, hL1, hLWW])
        have htreeEnd : TreeStoredAt L 0 S' (fun _ => 0) (fun _ => 1) wsEnd :=
          htreeTwo.unchanged (fun u _ f _ => hunchWr _ (fun _ _ _ => by simp))
        have hr0_tot : wsEnd.read (.heap 0 0) = wsMid.read (.heap 0 0) := by
          rw [hr0_eq, wordStore_read_eq_vals hmTwo.wf, wordStore_read_eq_vals hmMid.wf]
          exact (hunchTwo _ (fun _ _ _ => by simp)).2
        exact ⟨wsEnd, gEnd, sIte, hmEnd, htreeEnd,
          by rw [(hunchWr _ (fun _ _ _ => by simp)).1, (hunchTwo _ (fun _ _ _ => by simp)).1]; exact hn100Mid,
          by rw [(hunchWr _ (fun _ _ _ => by simp)).1, (hunchTwo _ (fun _ _ _ => by simp)).1]; exact hn101Mid,
          hr0_tot, by rw [if_neg hle1]; exact ⟨h₁, h₂, hh₁_in, hh₂_in, hne12, hca⟩⟩
    obtain ⟨wsEnd, gEnd, sAns, hmEnd, htreeEnd, hn100End, hn101End, hr0_ans, hcaEnd⟩ := hAnsBranch
    have sBody := (p1.seq (p2.seq (p3.seq (p4.seq (sUpd.seq (p5.seq (p6.seq (p7.seq sAns)))))))).weaken
      rfl rfl (u₂ := 1500 * L + 1200) (b₂ := (260 * L + 320) * W * W)
      (by omega) (by nlinarith only [hW20, hL1, hLWW])
    -- Wrap in `.localScope` from initial `BitRAMExecState` (`frameDepth = 0`)!
    have hpop0 : ws.popDepth 0 = ws := by
      cases ws with
      | mk lv vl =>
        unfold WordStore.popDepth; dsimp only
        have hk : ∀ loc ∈ lv, loc.keepAtDepth 0 = true := by
          intro loc hm
          cases loc with
          | heap _ _ => rfl
          | localFrame d' v i =>
              cases d' with
              | zero =>
                  have hsub := hinv.mod.live_sub hm
                  simp only [WordStore.empty, Finset.empty_union, dim0WriteLocs, treeSliceLocs,
                    Finset.mem_union, Finset.mem_image, Finset.mem_insert, Finset.mem_singleton,
                    reduceCtorEq, and_false, exists_false, or_self] at hsub
              | succ d'' => exact absurd hm (hinv.no_local (d'' + 1) (by omega) v i)
        congr 1
        · ext loc; simp only [Finset.mem_filter, and_iff_left_iff_imp]; exact hk loc
        · funext loc
          by_cases hm : loc ∈ lv
          · rw [if_pos (hk loc hm)]
          · split_ifs
            · rfl
            · exact (hinv.mod.wf loc hm).symm
    let initSt : BitRAMExecState :=
      { words := ws.popDepth 0
        frameDepth := 0
        remainingBits := []
        unitCost := 0
        bitCost := 0
        peakCellSpace := inp.inputCellSpace + (ws.popDepth 0).cellCount
        peakBitSpace := inp.inputBitSpace + (ws.popDepth 0).bitSize }
    have hpC0 : initSt.peakCellSpace ≤ C_cell := by
      dsimp [initSt]; rw [hpop0]; have h := (sp_ok hinv.mod).1; omega
    have hpB0 : initSt.peakBitSpace ≤ C_bit := by
      dsimp [initSt]; rw [hpop0]; have := (sp_ok hinv.mod).2; omega
    obtain ⟨stEnd, hrSc, hwEnd, _, hrbEnd, _, hbcEnd, _, hpBEnd⟩ :=
      RegExec.runScope (fd := 1) (by decide) (by omega) hinv.mod.wf hinv.no_local sBody initSt rfl hpop0 hpC0 hpB0
    have hpopEnd : stEnd.words.popDepth 0 = wsEnd := by
      rw [hwEnd]
      cases wsEnd with
      | mk lv vl =>
        unfold WordStore.popDepth; dsimp only
        have hk : ∀ loc ∈ lv, loc.keepAtDepth 0 = true := by
          intro loc hm
          cases loc with
          | heap _ _ => rfl
          | localFrame d' v i =>
              have hsub := hmEnd.live_sub hm
              simp only [WordStore.empty, Finset.empty_union, dim0WriteLocs, treeSliceLocs,
                Finset.mem_union, Finset.mem_image, Finset.mem_insert, Finset.mem_singleton,
                reduceCtorEq, and_false, exists_false, or_self] at hsub
        congr 1
        · ext loc; simp only [Finset.mem_filter, and_iff_left_iff_imp]; exact hk loc
        · funext loc
          by_cases hm : loc ∈ lv
          · rw [if_pos (hk loc hm)]
          · split_ifs
            · rfl
            · exact (hmEnd.wf loc hm).symm
    have hhalt := RunsTo.toRunBitRAMWithBits (prog := (progDim0 L).updateStmt)
      (inp := inp) (initWords := ws) (bs := []) hrSc hrbEnd
    refine ⟨wsEnd, _, hhalt, hpopEnd, by dsimp [initSt] at hbcEnd; rw [Nat.zero_add] at hbcEnd; exact hbcEnd, hpBEnd,
      hmEnd, htreeEnd, hn100End, hn101End,
      fun hI => by rw [hr0_ans]; exact hretMid hI, hcaEnd⟩
  -- Dispatch `op = .insert` vs `.delete`
  cases op with
  | insert id extName pt =>
      rcases hleg with ⟨hid_not, hcard_le, hpt_adm⟩
      obtain ⟨qIns, hqIns, _, _⟩ := euclideanToRatPoint_of_admissible hpt_adm
      have hcardS_lt : S.card < n := by omega
      let ratMap : ℕ → Fin 0 → ℚ := fun h =>
        if hh : h ∈ P.activeHandles then (euclideanToRatPoint? (P.handleCoords h)).get (hActRat h hh)
        else fun _ => 0
      let inp : BitRAMInput 0 :=
        { intParams := [(n : ℤ), 1, 0]
          activeHandles := P.activeHandles
          activeRatCoords := ratMap
          extraRats := List.ofFn qIns }
      have hinp_c : inp.inputCellSpace ≤ 3 + n + 2 := by
        dsimp [inp, BitRAMInput.inputCellSpace]
        rw [List.length_ofFn]
        linarith only [hH_card_le]
      have hinp_b : inp.inputBitSpace ≤ 2 * W + n * (L + 2) + 8 := by
        simp only [inp, BitRAMInput.inputBitSpace, List.map, List.sum_cons, List.sum_nil, List.ofFn_zero]
        have hl1_eq : intBitLength (1 : ℤ) = 2 := by decide
        have hl0_eq : intBitLength (0 : ℤ) = 1 := by decide
        have hsum_h : ∑ h ∈ P.activeHandles, (natBitLength h + ∑ i : Fin 0, ratBitLength (ratMap h i)) ≤ n * (L + 2) := by
          calc ∑ h ∈ P.activeHandles, (natBitLength h + ∑ i : Fin 0, ratBitLength (ratMap h i))
            _ ≤ ∑ _h ∈ P.activeHandles, (L + 2) := by
                refine Finset.sum_le_sum (fun h hh => ?_)
                simp only [Finset.univ_eq_empty, Finset.sum_empty, add_zero]
                have hlt := hinv.tree.hS h hh
                have hb := nat_lt_pow2_bitLength_le hlt
                unfold intBitLength at hb
                rw [Int.natAbs_natCast] at hb
                by_cases hh0 : h = 0
                · subst hh0; exact (show natBitLength 0 = 1 from by decide).trans_le (by omega)
                · have hzne : (h : ℤ) ≠ 0 := Nat.cast_ne_zero.mpr hh0
                  rw [if_neg hzne] at hb; omega
            _ = P.activeHandles.card * (L + 2) := by simp
            _ ≤ n * (L + 2) := Nat.mul_le_mul_right _ (by omega)
        linarith only [hn_bl, hl1_eq, hl0_eq, hsum_h, hW20]
      obtain ⟨wsEnd, out, hrun, hwEnd, hbc, hpB, hmEnd, htreeEnd, hn100, hn101, hret0, hca⟩ :=
        runBody inp true 0 rfl hinp_c hinp_b (fun _ => hcardS_lt) (fun h => by cases h)
      have heval : (progDim0 L).evalUpdate n P.activeHandles P.handleCoords ws true pt 0 [] = some out := by
        unfold BitRAMDynamicProgram.evalUpdate
        rw [dif_pos hActRat]; simp only [↓reduceIte, hqIns]
        exact hrun
      have hret_opt : BitRAMDynamicProgram.readReturnedHandle out.words = some (mexHandle S) := by
        unfold BitRAMDynamicProgram.readReturnedHandle
        rw [hwEnd, hret0 rfl]
        simp
      obtain ⟨P', happl, hwfP', hAdm', hIds', hHnds', _⟩ :=
        applyDynamicUpdate_insert_spec hinv.wfP hAdm ⟨hid_not, hcard_le, hpt_adm⟩ (mexHandle_notMem S)
      have hstep : runSingleAdaptiveStep alg P ws (.insert id extName pt) [] =
          some (P', { nextState := out.words
                      returnedHandle := some (mexHandle S)
                      storedAnswer := { diameterHandles := (BitRAMDynamicProgram.readCachedAnswer out.words).1
                                        cachedDistSq := (BitRAMDynamicProgram.readCachedAnswer out.words).2 }
                      work := out.bitCost
                      peakSpace := out.peakBitSpace }) := by
        unfold runSingleAdaptiveStep
        dsimp only [alg, bitRAMAlg, toInternalUpdate]
        rw [heval]
        dsimp only [Option.map]
        rw [hret_opt, happl]
      refine ⟨P', _, hstep, ?_, hAdm', ?_, hbc, hpB⟩
      · rw [hwEnd]
        exact ⟨hwfP', hmEnd, by simpa [hHnds', S] using htreeEnd, hn100, hn101⟩
      · rw [hwEnd]
        apply dim0_valid_answer hwfP'
        have hcard_eq' : (insert (mexHandle S) S).card = P'.activeIds.card := by
          rw [← hHnds']; exact activeHandles_card_eq hwfP'
        change (if (insert (mexHandle S) S).card ≤ 1 then
                  BitRAMDynamicProgram.readCachedAnswer wsEnd = (none, 0)
                else
                  ∃ h₁ h₂ : ℕ, h₁ ∈ insert (mexHandle S) S ∧ h₂ ∈ insert (mexHandle S) S ∧ h₁ ≠ h₂ ∧
                    BitRAMDynamicProgram.readCachedAnswer wsEnd = (some (h₁, h₂), 0)) at hca
        rw [hcard_eq'] at hca
        by_cases hle : P'.activeIds.card ≤ 1
        · rw [if_pos hle] at hca ⊢; simp [hca]
        · rw [if_neg hle] at hca ⊢
          rcases hca with ⟨h₁, h₂, hh₁, hh₂, hne, hca_eq⟩
          rw [hHnds']
          exact ⟨h₁, h₂, hh₁, hh₂, hne, by simp [hca_eq], by simp [hca_eq]⟩
  | delete id =>
      obtain ⟨P', hhDel_in, happl, hwfP', hAdm', hIds', hHnds', _⟩ :=
        applyDynamicUpdate_delete_spec hinv.wfP hAdm hleg
      let ratMap : ℕ → Fin 0 → ℚ := fun h =>
        if hh : h ∈ P.activeHandles then (euclideanToRatPoint? (P.handleCoords h)).get (hActRat h hh)
        else fun _ => 0
      let inp : BitRAMInput 0 :=
        { intParams := [(n : ℤ), 0, (P.handleOfId id : ℤ)]
          activeHandles := P.activeHandles
          activeRatCoords := ratMap
          extraRats := [] }
      have hinp_c : inp.inputCellSpace ≤ 3 + n + 2 := by
        dsimp [inp, BitRAMInput.inputCellSpace]
        linarith only [hH_card_le]
      have hinp_b : inp.inputBitSpace ≤ 2 * W + n * (L + 2) + 8 := by
        simp only [inp, BitRAMInput.inputBitSpace, List.map, List.sum_cons, List.sum_nil]
        have hl0_eq : intBitLength (0 : ℤ) = 1 := by decide
        have hhDel_lt : P.handleOfId id < 2 ^ L := hinv.tree.hS _ hhDel_in
        have hhDel_bl : intBitLength (P.handleOfId id : ℤ) ≤ W :=
          (nat_lt_pow2_bitLength_le hhDel_lt).trans (by dsimp [W]; omega)
        have hsum_h : ∑ h ∈ P.activeHandles, (natBitLength h + ∑ i : Fin 0, ratBitLength (ratMap h i)) ≤ n * (L + 2) := by
          calc ∑ h ∈ P.activeHandles, (natBitLength h + ∑ i : Fin 0, ratBitLength (ratMap h i))
            _ ≤ ∑ _h ∈ P.activeHandles, (L + 2) := by
                refine Finset.sum_le_sum (fun h hh => ?_)
                simp only [Finset.univ_eq_empty, Finset.sum_empty, add_zero]
                have hlt := hinv.tree.hS h hh
                have hb := nat_lt_pow2_bitLength_le hlt
                unfold intBitLength at hb
                rw [Int.natAbs_natCast] at hb
                by_cases hh0 : h = 0
                · subst hh0; exact (show natBitLength 0 = 1 from by decide).trans_le (by omega)
                · have hzne : (h : ℤ) ≠ 0 := Nat.cast_ne_zero.mpr hh0
                  rw [if_neg hzne] at hb; omega
            _ = P.activeHandles.card * (L + 2) := by simp
            _ ≤ n * (L + 2) := Nat.mul_le_mul_right _ (by omega)
        linarith only [hl0_eq, hhDel_bl, hn_bl, hsum_h, hW20]
      obtain ⟨wsEnd, out, hrun, hwEnd, hbc, hpB, hmEnd, htreeEnd, hn100, hn101, _, hca⟩ :=
        runBody inp false (P.handleOfId id) rfl hinp_c hinp_b (fun h => by cases h) (fun _ => hhDel_in)
      have heval : (progDim0 L).evalUpdate n P.activeHandles P.handleCoords ws false 0 (P.handleOfId id) [] = some out := by
        unfold BitRAMDynamicProgram.evalUpdate
        rw [dif_pos hActRat]; simp only [Bool.false_eq_true, ↓reduceIte]
        exact hrun
      have hstep : runSingleAdaptiveStep alg P ws (.delete id) [] =
          some (P', { nextState := out.words
                      returnedHandle := none
                      storedAnswer := { diameterHandles := (BitRAMDynamicProgram.readCachedAnswer out.words).1
                                        cachedDistSq := (BitRAMDynamicProgram.readCachedAnswer out.words).2 }
                      work := out.bitCost
                      peakSpace := out.peakBitSpace }) := by
        unfold runSingleAdaptiveStep
        simp only [alg, bitRAMAlg, toInternalUpdate, heval, Option.map_some, happl]
      refine ⟨P', _, hstep, ?_, hAdm', ?_, hbc, hpB⟩
      · rw [hwEnd]
        exact ⟨hwfP', hmEnd, by simpa [hHnds', S] using htreeEnd, hn100, hn101⟩
      · rw [hwEnd]
        apply dim0_valid_answer hwfP'
        have hcard_eq' : (S.erase (P.handleOfId id)).card = P'.activeIds.card := by
          rw [← hHnds']; exact activeHandles_card_eq hwfP'
        change (if (S.erase (P.handleOfId id)).card ≤ 1 then
                  BitRAMDynamicProgram.readCachedAnswer wsEnd = (none, 0)
                else
                  ∃ h₁ h₂ : ℕ, h₁ ∈ S.erase (P.handleOfId id) ∧ h₂ ∈ S.erase (P.handleOfId id) ∧ h₁ ≠ h₂ ∧
                    BitRAMDynamicProgram.readCachedAnswer wsEnd = (some (h₁, h₂), 0)) at hca
        rw [hcard_eq'] at hca
        by_cases hle : P'.activeIds.card ≤ 1
        · rw [if_pos hle] at hca ⊢; simp [hca]
        · rw [if_neg hle] at hca ⊢
          rcases hca with ⟨h₁, h₂, hh₁, hh₂, hne, hca_eq⟩
          rw [hHnds']
          exact ⟨h₁, h₂, hh₁, hh₂, hne, by simp [hca_eq], by simp [hca_eq]⟩

theorem prove_part4_dim0 {n B : ℕ} (hn : 2 ≤ n) (hB : 1 ≤ B) :
    let L : ℕ := Nat.clog 2 (2 * n)
    let W : ℕ := L + 24
    ∃ (prog : BitRAMDynamicProgram) (initOut : BitRAMExecOutcome),
      prog.evalInit n 0 = some initOut ∧
      let alg := bitRAMAlg (d := 0) n prog initOut
      SatisfiesDynamicStorageAndQueryModel 5 1 alg ∧
      SatisfiesLasVegasGuarantee n (Real.sqrt 2) (((260 * L + 321) * W * W : ℕ) : ℝ)
        (RatAdmissiblePointSet 0 B) alg ∧
      SatisfiesUnboundedSpaceBound n (RatAdmissiblePointSet 0 B) alg
        ((n : ℝ) * ((120 * W : ℕ) : ℝ)) := by
  intro L W
  let initOut : BitRAMExecOutcome :=
    { words := WordStore.empty
      unitCost := 1
      bitCost := 1
      peakCellSpace := 1
      peakBitSpace := intBitLength (n : ℤ) }
  refine ⟨progDim0 L, initOut, evalInit_of_initSkip n 0 (progDim0 L).updateStmt, ?_⟩
  intro alg
  have hStore : SatisfiesDynamicStorageAndQueryModel 5 1 alg :=
    satisfiesDynamicStorage_of_initEmpty n (progDim0 L) initOut rfl
  obtain ⟨hL2, _, h2n_pow, hpow_4n⟩ := clog_two_mul_bounds hn
  change 2 ≤ L at hL2; change 2 * n ≤ 2 ^ L at h2n_pow; change 2 ^ L < 4 * n at hpow_4n
  have hW20 : 20 ≤ W := by dsimp [W]; omega
  -- Single-step prefix-freeness of `runSingleAdaptiveStep`
  have hStepPF : ∀ (P : DynamicPointSet 0) (st : WordStore) (op : DynamicUpdate 0)
      (b₁ b₂ : List Bool) (o₁ o₂ : DynamicPointSet 0 × DynamicStepOutcome WordStore),
      runSingleAdaptiveStep alg P st op b₁ = some o₁ →
      runSingleAdaptiveStep alg P st op b₂ = some o₂ →
      b₁ <+: b₂ → b₁ = b₂ := by
    intro P st op b₁ b₂ o₁ o₂ h1 h2 hp
    unfold runSingleAdaptiveStep at h1 h2
    cases hs1 : alg.stepWithBits P.activeHandles P.handleCoords st (toInternalUpdate P op) b₁ with
    | none => simp [hs1] at h1
    | some s1 =>
        cases hs2 : alg.stepWithBits P.activeHandles P.handleCoords st (toInternalUpdate P op) b₂ with
        | none => simp [hs2] at h2
        | some s2 =>
            exact hStore.2.2.1 _ _ _ _ b₁ b₂ s1 s2 hs1 hs2 hp
  -- Prefix induction over `runAdaptiveSteps`
  have hRunInv : ∀ (adv : AdaptiveAdversary 0),
      IsValidAdaptiveAdversary n (RatAdmissiblePointSet 0 B) alg adv →
      ∀ (k : ℕ) (bitTrace : List (List Bool)), bitTrace.length = k →
        ∀ (prefSt : AdaptivePrefixState 0 WordStore),
          runAdaptiveSteps alg adv bitTrace = some prefSt →
            (∀ b ∈ bitTrace, b = []) ∧
            Dim0Inv n L prefSt.pointSet prefSt.algState ∧
            (∀ id ∈ prefSt.pointSet.activeIds, prefSt.pointSet.coords id ∈ RatAdmissiblePointSet 0 B) ∧
            AllPrefixAnswersValid (Real.sqrt 2) prefSt ∧
            prefSt.totalWork ≤ 1 + k * ((260 * L + 320) * W * W) ∧
            prefSt.maxSpace ≤ 120 * n * W := by
    intro adv hadv k
    induction k with
    | zero =>
        intro bitTrace hlen prefSt hrun
        have hnil : bitTrace = [] := List.eq_nil_of_length_eq_zero hlen
        subst hnil
        simp only [runAdaptiveSteps, runAdaptiveStepsFrom, Option.some.injEq] at hrun
        subst hrun
        have hn_bl : intBitLength (n : ℤ) ≤ 120 * n * W := by
          have := nat_lt_pow2_bitLength_le (by omega : n < 2 ^ L)
          dsimp [W]; nlinarith only [this, hn, hL2]
        exact ⟨by simp, Dim0Inv.init hn, fun id hid => False.elim (Finset.notMem_empty id hid),
               by simp [AllPrefixAnswersValid, initAdaptivePrefixState],
               by simp [initAdaptivePrefixState, alg, bitRAMAlg, initOut],
               by simpa [initAdaptivePrefixState, alg, bitRAMAlg, initOut] using hn_bl⟩
    | succ k ih =>
        intro bitTrace hlen prefSt hrun
        have hdrop_len : bitTrace.dropLast.length = k := by simp [hlen]
        have hne_bt : bitTrace ≠ [] := by intro h; simp [h] at hlen
        have happ : bitTrace.dropLast ++ [bitTrace.getLast hne_bt] = bitTrace :=
          List.dropLast_append_getLast hne_bt
        rw [← happ] at hrun
        -- Helper to split `runAdaptiveStepsFrom` across `xs ++ [b]`
        have hSplit : ∀ (xs : List (List Bool)) (b : List Bool) (cur : AdaptivePrefixState 0 WordStore),
            runAdaptiveStepsFrom alg adv cur (xs ++ [b]) = some prefSt →
            ∃ mid : AdaptivePrefixState 0 WordStore,
              runAdaptiveStepsFrom alg adv cur xs = some mid ∧
              runAdaptiveStepsFrom alg adv mid [b] = some prefSt := by
          intro xs
          induction xs with
          | nil => intro b cur hr; exact ⟨cur, rfl, hr⟩
          | cons x tail ihx =>
              intro b cur hr
              simp only [List.cons_append, runAdaptiveStepsFrom] at hr
              cases hs : runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) x with
              | none => simp [hs] at hr
              | some po =>
                  simp only [hs] at hr
                  obtain ⟨mid, hm1, hm2⟩ := ihx b _ hr
                  refine ⟨mid, ?_, hm2⟩
                  simp [runAdaptiveStepsFrom, hs, hm1]
        obtain ⟨mid, hmid_run, hlast_run⟩ := hSplit bitTrace.dropLast (bitTrace.getLast hne_bt) _ hrun
        obtain ⟨hmid_nil, hmid_inv, hmid_adm, hmid_val, hmid_wk, hmid_sp⟩ :=
          ih bitTrace.dropLast hdrop_len mid hmid_run
        have hleg := hadv bitTrace.dropLast mid hmid_run
        obtain ⟨P₀', out₀, hstep0, hinv0, hadm0, hval0, hwk0, hsp0⟩ :=
          exec_progDim0_step hn hB hmid_inv hmid_adm hleg (initOut := initOut)
        set bLast := bitTrace.getLast hne_bt
        simp only [runAdaptiveStepsFrom] at hlast_run
        cases hsL : runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bLast with
        | none => simp [hsL] at hlast_run
        | some po =>
            have hb_eq : bLast = [] :=
              (hStepPF _ _ _ [] bLast _ po hstep0 hsL (List.nil_prefix)).symm
            rw [hb_eq] at hsL hlast_run
            rw [hsL] at hstep0; injection hstep0 with hpo_eq; subst hpo_eq
            simp only [hsL, Option.some.injEq] at hlast_run
            subst hlast_run
            refine ⟨?_, hinv0, hadm0, ?_, ?_, max_le hmid_sp hsp0⟩
            · intro b hb
              rw [← happ, List.mem_append, List.mem_singleton] at hb
              rcases hb with hb1 | rfl
              · exact hmid_nil b hb1
              · exact hb_eq
            · intro snap hsnap
              simp only [List.mem_append, List.mem_singleton] at hsnap
              rcases hsnap with hs_old | rfl
              · exact hmid_val snap hs_old
              · exact hval0
            · dsimp only
              calc mid.totalWork + out₀.work
                _ ≤ (1 + k * ((260 * L + 320) * W * W)) + ((260 * L + 320) * W * W) :=
                    Nat.add_le_add hmid_wk hwk0
                _ = 1 + (k + 1) * ((260 * L + 320) * W * W) := by ring
  -- Also prove reachable forward existence for `trace₀ = fun _ => []`!
  have hDetRun : ∀ (adv : AdaptiveAdversary 0),
      IsValidAdaptiveAdversary n (RatAdmissiblePointSet 0 B) alg adv →
      ∀ k : ℕ, ∃ out : AdaptivePrefixState 0 WordStore,
        runAdaptiveSteps alg adv (List.replicate k []) = some out := by
    intro adv hadv k
    induction k with
    | zero => exact ⟨initAdaptivePrefixState alg, rfl⟩
    | succ k ih =>
        obtain ⟨mid, hmid⟩ := ih
        obtain ⟨_, hmid_inv, hmid_adm, _, _, _⟩ :=
          hRunInv adv hadv k (List.replicate k []) (List.length_replicate) mid hmid
        have hleg := hadv (List.replicate k []) mid hmid
        obtain ⟨P', out', hstep, _, _, _, _, _⟩ :=
          exec_progDim0_step hn hB hmid_inv hmid_adm hleg (initOut := initOut)
        have hstep_m : runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) [] = some (P', out') := hstep
        rw [List.replicate_succ']
        have hApp : ∀ (xs : List (List Bool)) (cur : AdaptivePrefixState 0 WordStore),
            runAdaptiveStepsFrom alg adv cur xs = some mid →
            ∃ endSt, runAdaptiveStepsFrom alg adv cur (xs ++ [[]]) = some endSt := by
          intro xs
          induction xs with
          | nil =>
              intro cur hr
              simp only [runAdaptiveStepsFrom, Option.some.injEq] at hr
              cases hr
              let entry : StepHistoryEntry 0 :=
                { operation := adv mid.history
                  randomBits := []
                  returnedHandle := out'.returnedHandle
                  answer := out'.storedAnswer
                  resolvedIds := resolveAnswerIdentities P' out'.storedAnswer }
              let nextSt : AdaptivePrefixState 0 WordStore :=
                { pointSet := P'
                  algState := out'.nextState
                  history := mid.history ++ [entry]
                  snapshots := mid.snapshots ++ [(P', out'.storedAnswer)]
                  stepWorks := mid.stepWorks ++ [out'.work]
                  totalWork := mid.totalWork + out'.work
                  maxSpace := max mid.maxSpace out'.peakSpace }
              exact ⟨nextSt, by simp [runAdaptiveStepsFrom, hstep_m, entry, nextSt]⟩
          | cons x tail ihx =>
              intro cur hr
              simp only [runAdaptiveStepsFrom] at hr
              cases hs : runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) x with
              | none => simp [hs] at hr
              | some po =>
                  simp only [hs] at hr
                  obtain ⟨endSt, hend⟩ := ihx _ hr
                  exact ⟨endSt, by simp [runAdaptiveStepsFrom, hs, hend]⟩
        exact hApp (List.replicate k []) (initAdaptivePrefixState alg) hmid
  refine ⟨hStore, ⟨?_, ?_⟩, ?_⟩
  · -- `SatisfiesLasVegasCorrectness`
    intro adv hadv
    refine ⟨?_, ?_⟩
    · intro bitTrace prefSt hrun
      obtain ⟨_, hinv, hadm, _, _, _⟩ := hRunInv adv hadv bitTrace.length bitTrace rfl prefSt hrun
      have hleg := hadv bitTrace prefSt hrun
      obtain ⟨P', out', hstep, _, _, _, _, _⟩ :=
        exec_progDim0_step hn hB hinv hadm hleg (initOut := initOut)
      unfold singleStepValidHaltProb
      have hstep' : runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState (adv prefSt.history) [] = some (P', out') := hstep
      have hiff' : ∀ bs : List Bool,
          (if (runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState (adv prefSt.history) bs).isSome then bitListProb bs else 0) =
          (if bs = [] then bitListProb bs else 0) := by
        intro bs
        by_cases hbs : bs = []
        · subst hbs; rw [hstep']; simp
        · have hns : (runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState (adv prefSt.history) bs).isSome = false := by
            by_contra htr
            simp only [Bool.not_eq_false] at htr
            rcases Option.isSome_iff_exists.mp htr with ⟨po, hpo⟩
            exact hbs (hStepPF _ _ _ [] bs _ po hstep' hpo (List.nil_prefix)).symm
          simp [hns, hbs]
      simp_rw [hiff']
      rw [tsum_ite_eq]
      simp [bitListProb]
    · intro T trace out hrun
      exact (hRunInv adv hadv T (List.ofFn trace) (List.length_ofFn) out hrun).2.2.2.1
  · -- `SatisfiesExpectedAmortizedWorkBound`
    intro adv hadv T hT1
    obtain ⟨out₀, hout₀⟩ := hDetRun adv hadv T
    let trace₀ : Fin T → List Bool := fun _ => []
    have hofFn₀ : List.ofFn trace₀ = List.replicate T [] := by simp [trace₀]
    have hpref₀ : runAdaptivePrefix alg adv T trace₀ = some out₀ := by
      unfold runAdaptivePrefix; rwa [hofFn₀]
    have honly₀ : ∀ tr : Fin T → List Bool, tr ≠ trace₀ → runAdaptivePrefix alg adv T tr = none := by
      intro tr hne
      by_contra hsome
      rcases Option.ne_none_iff_exists'.mp hsome with ⟨out', hout'⟩
      obtain ⟨hnil_all, _, _, _, _, _⟩ := hRunInv adv hadv T (List.ofFn tr) (List.length_ofFn) out' hout'
      apply hne; funext i
      exact hnil_all (tr i) (List.mem_ofFn.mpr ⟨i, rfl⟩)
    have hprob₀ : prefixTraceProb trace₀ = 1 := by
      simp [prefixTraceProb, trace₀, bitListProb]
    have hexp_eq : adaptivePrefixExpectedWork alg adv T = (out₀.totalWork : ENNReal) := by
      unfold adaptivePrefixExpectedWork
      rw [tsum_eq_single trace₀]
      · simp [hpref₀, hprob₀]
      · intro tr hne; simp [honly₀ tr hne]
    obtain ⟨_, _, _, _, hwk₀, _⟩ := hRunInv adv hadv T (List.replicate T []) (List.length_replicate) out₀ hout₀
    rw [hexp_eq]
    refine ⟨ENNReal.natCast_ne_top _, ?_⟩
    rw [ENNReal.toReal_natCast, div_le_iff₀ (by exact_mod_cast (by omega : 0 < T))]
    have hwk_bound : out₀.totalWork ≤ T * ((260 * L + 321) * W * W) := by
      have hW1 : 1 ≤ W * W := by nlinarith only [hW20]
      nlinarith only [hwk₀, hT1, hW1]
    have hcast : (out₀.totalWork : ℝ) ≤ ((T * ((260 * L + 321) * W * W) : ℕ) : ℝ) := by
      exact_mod_cast hwk_bound
    push_cast at hcast ⊢
    linarith only [hcast]
  · -- `SatisfiesUnboundedSpaceBound`
    refine ⟨?_, ?_⟩
    · have hn_bl : intBitLength (n : ℤ) ≤ 120 * n * W := by
        have := nat_lt_pow2_bitLength_le (by omega : n < 2 ^ L)
        dsimp [W]; nlinarith only [this, hn, hL2]
      have hcast : (initOut.peakBitSpace : ℝ) ≤ ((n * (120 * W) : ℕ) : ℝ) := by
        dsimp [initOut]; exact_mod_cast (by ring_nf at hn_bl ⊢; exact hn_bl)
      simpa [alg, bitRAMAlg, Nat.cast_mul] using hcast
    · intro adv hadv T trace out hrun
      obtain ⟨_, _, _, _, _, hsp⟩ := hRunInv adv hadv T (List.ofFn trace) (List.length_ofFn) out hrun
      have hcast : (out.maxSpace : ℝ) ≤ ((n * (120 * W) : ℕ) : ℝ) := by
        exact_mod_cast (by ring_nf at hsp ⊢; exact hsp)
      simpa [Nat.cast_mul] using hcast

end UL.C12LVE
