import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3c1_TreeOps
set_option autoImplicit false
set_option maxHeartbeats 800000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. `treeReadRootRegs`: O(1) root query `(cnt, bestH, bestNum, bestDen)` -/

/-- Given `r0 = tid`, load root `(k = L, off = 0, u = 1)` of tree `tid` into `(r1, r2, r3, r4)`,
preserving `r0` and modifying no heap cells. -/
def treeReadRootRegs (L : ℕ) : BitRAMStmt :=
  .seq (rLit 8 ((2 ^ (L + 1) : ℕ) : ℤ))
  (.seq (rMul 7 0 8)
  (.seq (rLit 15 1)
  (.seq (rAdd 10 7 15)
  (.seq (rLit 15 4)
  (.seq (rMul 10 10 15)
  (.seq (rLoad 1 2 10)
  (.seq (rLit 15 1)
  (.seq (rAdd 10 10 15)
  (.seq (rLoad 2 2 10)
  (.seq (rAdd 10 10 15)
  (.seq (rLoad 3 2 10)
  (.seq (rAdd 10 10 15)
        (rLoad 4 2 10)))))))))))))

theorem exec_treeReadRootRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws : WordStore}
    (hc_ok : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell)
    (hb_ok : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit)
    {L tid B_r : ℕ} (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 16 ≤ W)
    {S : Finset ℕ} {rNum rDen : ℕ → ℤ}
    (htree : TreeStoredAt L tid S rNum rDen ws)
    (hS_bnds : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (tid : ℤ)) :
    let vRoot := treeNodeVal S rNum rDen L 0
    ∃ regs',
      RegExec inp fd W C_cell C_bit (treeReadRootRegs L) ws regs ws regs' 96 (16 * W * W) ∧
      RegBounded W regs' ∧
      regs' 0 = (tid : ℤ) ∧
      regs' 1 = (S.card : ℤ) ∧
      regs' 2 = (vRoot.2.1 : ℤ) ∧
      regs' 3 = vRoot.2.2.1 ∧
      regs' 4 = vRoot.2.2.2 ∧
      (∀ r < 16, r ≠ 1 → r ≠ 2 → r ≠ 3 → r ≠ 4 → r ≠ 7 → r ≠ 8 → r ≠ 10 → r ≠ 15 → regs' r = regs r) := by
  intro vRoot
  have hW8 : 18 ≤ W := by omega
  have hW_addr : natBitLength tid + L + 12 ≤ W := by omega
  have hn2_bl : natBitLength 2 ≤ W := by have : natBitLength 2 = 2 := (by decide); omega
  have hpL1_bl : intBitLength ((2 ^ (L + 1) : ℕ) : ℤ) ≤ W := (nat_pow2_bitLength_le (L + 1)).trans (by omega)
  have hl1_bl : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl4_bl : intBitLength (4 : ℤ) ≤ W := by have : intBitLength (4 : ℤ) = 4 := (by decide); omega
  have hu1_lt : 1 < 2 ^ (L + 1) := by
    have : 2 ^ 1 ≤ 2 ^ (L + 1) := Nat.pow_le_pow_right (by decide) (by omega)
    omega
  have hu1_eq : treeIdx L L 0 = 1 := by unfold treeIdx; simp
  have ha_bl : ∀ f < 4, intBitLength (treeCellAddr L tid 1 f) ≤ W :=
    fun f hf => (treeCellAddr_bitLength_le hu1_lt hf hW_addr).2
  have htid_pow_bl : intBitLength ((tid * 2 ^ (L + 1) : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := (tid * 2 ^ (L + 1) + 1) * 4 + 0) (by omega)).trans ((treeCellAddr_bitLength_le hu1_lt (f := 0) (by decide) hW_addr).2)
  have hbase_bl : intBitLength ((tid * 2 ^ (L + 1) + 1 : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := (tid * 2 ^ (L + 1) + 1) * 4 + 0) (by omega)).trans (ha_bl 0 (by decide))
  have hnRoot := htree.nodes L le_rfl 0 (by simp)
  obtain ⟨r0_f, r1_f, r2_f, r3_f⟩ := hnRoot.read_fields
  rw [hu1_eq] at r0_f r1_f r2_f r3_f
  have hcnt_eq : vRoot.1 = S.card := by
    dsimp [vRoot]; rw [treeNodeVal_cnt, treeSubSet_root htree.hS]
  obtain ⟨_, _, c_bl, h_bl, n_bl, d_bl⟩ := treeNodeVal_bounds hBr1 hS_bnds L le_rfl 0
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd hc_ok hb_ok (dst := 8) (c := ((2 ^ (L + 1) : ℕ) : ℤ)) (by decide) hpL1_bl
  set g1 := Function.update regs 8 (((2 ^ (L + 1) : ℕ) : ℤ) : ℤ); have bg1 : RegBounded W g1 := hbnd.update (r := 8) (by decide) hpL1_bl
  have hm7 : g1 0 * g1 8 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) := by simp [g1, hr0]
  have s2 := RegExec.mul (inp := inp) hfd_le bg1 hc_ok hb_ok (dst := 7) (a := 0) (b := 8) (by decide) (by decide) (by decide) (by rw [hm7]; exact htid_pow_bl)
  rw [hm7] at s2
  set g2 := Function.update g1 7 (((tid * 2 ^ (L + 1) : ℕ) : ℤ) : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 7) (by decide) htid_pow_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 hc_ok hb_ok (dst := 15) (c := 1) (by decide) hl1_bl
  set g3 := Function.update g2 15 (1 : ℤ); have bg3 : RegBounded W g3 := bg2.update (r := 15) (by decide) hl1_bl
  have ha10 : g3 7 + g3 15 = ((tid * 2 ^ (L + 1) + 1 : ℕ) : ℤ) := by simp [g3, g2]
  have s4 := RegExec.add (inp := inp) hfd_le bg3 hc_ok hb_ok (dst := 10) (a := 7) (b := 15) (by decide) (by decide) (by decide) (by rw [ha10]; exact hbase_bl)
  rw [ha10] at s4
  set g4 := Function.update g3 10 (((tid * 2 ^ (L + 1) + 1 : ℕ) : ℤ) : ℤ); have bg4 : RegBounded W g4 := bg3.update (r := 10) (by decide) hbase_bl
  have s5 := RegExec.lit (inp := inp) hfd_le bg4 hc_ok hb_ok (dst := 15) (c := 4) (by decide) hl4_bl
  set g5 := Function.update g4 15 (4 : ℤ); have bg5 : RegBounded W g5 := bg4.update (r := 15) (by decide) hl4_bl
  have hm10 : g5 10 * g5 15 = treeCellAddr L tid 1 0 := by simp [g5, g4, treeCellAddr]
  have s6 := RegExec.mul (inp := inp) hfd_le bg5 hc_ok hb_ok (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [hm10]; exact ha_bl 0 (by decide))
  rw [hm10] at s6
  set g6 := Function.update g5 10 ((treeCellAddr L tid 1 0) : ℤ); have bg6 : RegBounded W g6 := bg5.update (r := 10) (by decide) (ha_bl 0 (by decide))
  have hg6_10 : ws.read (.heap 2 (g6 10)) = (vRoot.1 : ℤ) := by simpa [g6] using r0_f
  have s7 := RegExec.load (inp := inp) hfd_le bg6 hc_ok hb_ok (dst := 1) (table := 2) (addr := 10) (by decide) (by decide) hn2_bl (by rw [hg6_10]; exact c_bl.trans (by omega))
  rw [hg6_10] at s7
  set g7 := Function.update g6 1 ((vRoot.1 : ℤ) : ℤ); have bg7 : RegBounded W g7 := bg6.update (r := 1) (by decide) (c_bl.trans (by omega))
  have s8 := RegExec.lit (inp := inp) hfd_le bg7 hc_ok hb_ok (dst := 15) (c := 1) (by decide) hl1_bl
  set g8 := Function.update g7 15 (1 : ℤ); have bg8 : RegBounded W g8 := bg7.update (r := 15) (by decide) hl1_bl
  have ha01 : g8 10 + g8 15 = treeCellAddr L tid 1 1 := by simp [g8, g7, g6, treeCellAddr]
  have s9 := RegExec.add (inp := inp) hfd_le bg8 hc_ok hb_ok (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [ha01]; exact ha_bl 1 (by decide))
  rw [ha01] at s9
  set g9 := Function.update g8 10 ((treeCellAddr L tid 1 1) : ℤ); have bg9 : RegBounded W g9 := bg8.update (r := 10) (by decide) (ha_bl 1 (by decide))
  have hg9_10 : ws.read (.heap 2 (g9 10)) = (vRoot.2.1 : ℤ) := by simpa [g9] using r1_f
  have s10 := RegExec.load (inp := inp) hfd_le bg9 hc_ok hb_ok (dst := 2) (table := 2) (addr := 10) (by decide) (by decide) hn2_bl (by rw [hg9_10]; exact h_bl.trans (by omega))
  rw [hg9_10] at s10
  set g10 := Function.update g9 2 ((vRoot.2.1 : ℤ) : ℤ); have bg10 : RegBounded W g10 := bg9.update (r := 2) (by decide) (h_bl.trans (by omega))
  have ha12 : g10 10 + g10 15 = treeCellAddr L tid 1 2 := by simp [g10, g9, g8, treeCellAddr]; ring
  have s11 := RegExec.add (inp := inp) hfd_le bg10 hc_ok hb_ok (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [ha12]; exact ha_bl 2 (by decide))
  rw [ha12] at s11
  set g11 := Function.update g10 10 ((treeCellAddr L tid 1 2) : ℤ); have bg11 : RegBounded W g11 := bg10.update (r := 10) (by decide) (ha_bl 2 (by decide))
  have hg11_10 : ws.read (.heap 2 (g11 10)) = vRoot.2.2.1 := by simpa [g11] using r2_f
  have s12 := RegExec.load (inp := inp) hfd_le bg11 hc_ok hb_ok (dst := 3) (table := 2) (addr := 10) (by decide) (by decide) hn2_bl (by rw [hg11_10]; exact n_bl.trans (by omega))
  rw [hg11_10] at s12
  set g12 := Function.update g11 3 (vRoot.2.2.1 : ℤ); have bg12 : RegBounded W g12 := bg11.update (r := 3) (by decide) (n_bl.trans (by omega))
  have ha23 : g12 10 + g12 15 = treeCellAddr L tid 1 3 := by simp [g12, g11, g10, g9, g8, treeCellAddr]; ring
  have s13 := RegExec.add (inp := inp) hfd_le bg12 hc_ok hb_ok (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [ha23]; exact ha_bl 3 (by decide))
  rw [ha23] at s13
  set g13 := Function.update g12 10 ((treeCellAddr L tid 1 3) : ℤ); have bg13 : RegBounded W g13 := bg12.update (r := 10) (by decide) (ha_bl 3 (by decide))
  have hg13_10 : ws.read (.heap 2 (g13 10)) = vRoot.2.2.2 := by simpa [g13] using r3_f
  have s14 := RegExec.load (inp := inp) hfd_le bg13 hc_ok hb_ok (dst := 4) (table := 2) (addr := 10) (by decide) (by decide) hn2_bl (by rw [hg13_10]; exact d_bl.trans (by omega))
  rw [hg13_10] at s14
  set g14 := Function.update g13 4 (vRoot.2.2.2 : ℤ); have bg14 : RegBounded W g14 := bg13.update (r := 4) (by decide) (d_bl.trans (by omega))
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq (s11.seq (s12.seq (s13.seq s14))))))))))))).weaken
    rfl rfl (u₂ := 96) (b₂ := 16 * W * W) (by omega)
    (by nlinarith only [hW8] : 2 * W + 16 + (4 * W * W + (2 * W + 16 + (6 * W + 32 + (2 * W + 16 + (4 * W * W + (6 * W + 24 + (2 * W + 16 + (6 * W + 32 + (6 * W + 24 + (6 * W + 32 + (6 * W + 24 + (6 * W + 32 + (6 * W + 24))))))))))))) ≤ 16 * W * W)
  refine ⟨g14, sTot, bg14, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simp [g14, g13, g12, g11, g10, g9, g8, g7, g6, g5, g4, g3, g2, g1, hr0]
  · simp [g14, g13, g12, g11, g10, g9, g8, g7, hcnt_eq]
  · simp [g14, g13, g12, g11, g10]
  · simp [g14, g13, g12]
  · simp [g14]
  · intro r _ h1 h2 h3 h4 h7 h8 h10 h15
    simp [g14, g13, g12, g11, g10, g9, g8, g7, g6, g5, g4, g3, g2, g1,
      Function.update_of_ne h1, Function.update_of_ne h2, Function.update_of_ne h3, Function.update_of_ne h4,
      Function.update_of_ne h7, Function.update_of_ne h8, Function.update_of_ne h10, Function.update_of_ne h15]

/-! ### 2. `treeMinElemRegs`: top-down minimum handle walk `S.min' hne` -/

def minWalkStepStmt : BitRAMStmt :=
  .seq (rAdd 2 1 1)
  (.seq (rAdd 10 7 2)
  (.seq (rLit 15 4)
  (.seq (rMul 10 10 15)
  (.seq (rLoad 3 2 10)
  (.seq (rLit 6 0)
  (.ite (.intLt (.readLocal 6 (.lit 0)) (.readLocal 3 (.lit 0)))
    (rCopy 1 2)
    (.seq (rLit 15 1) (rAdd 1 2 15))))))))

def treeMinElemRegs (L : ℕ) : BitRAMStmt :=
  .seq (rLit 8 ((2 ^ (L + 1) : ℕ) : ℤ))
  (.seq (rMul 7 0 8)
  (.seq (rLit 1 1)
  (.seq (.repeatN (.lit (L : ℤ)) minWalkStepStmt)
  (.seq (rLit 5 ((2 ^ L : ℕ) : ℤ))
        (rSub 1 1 5)))))

theorem exec_treeMinElemRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws : WordStore}
    (hc_ok : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell)
    (hb_ok : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit)
    {L tid B_r : ℕ} (hL1 : 1 ≤ L) (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 16 ≤ W)
    {S : Finset ℕ} {rNum rDen : ℕ → ℤ}
    (htree : TreeStoredAt L tid S rNum rDen ws)
    (hS_bnds : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r)
    (hne : S.Nonempty)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (tid : ℤ)) :
    ∃ regs',
      RegExec inp fd W C_cell C_bit (treeMinElemRegs L) ws regs ws regs'
        (64 * L + 32) ((12 * L + 8) * W * W) ∧
      RegBounded W regs' ∧
      regs' 0 = (tid : ℤ) ∧
      regs' 1 = (S.min' hne : ℤ) ∧
      (∀ r < 16, r ≠ 1 → r ≠ 2 → r ≠ 3 → r ≠ 5 → r ≠ 6 → r ≠ 7 → r ≠ 8 → r ≠ 10 → r ≠ 15 → regs' r = regs r) := by
  have hW8 : 18 ≤ W := by omega
  have hW_addr : natBitLength tid + L + 12 ≤ W := by omega
  have hn2_bl : natBitLength 2 ≤ W := by have : natBitLength 2 = 2 := (by decide); omega
  have hpL1_bl : intBitLength ((2 ^ (L + 1) : ℕ) : ℤ) ≤ W := (nat_pow2_bitLength_le (L + 1)).trans (by omega)
  have hpL_bl : intBitLength ((2 ^ L : ℕ) : ℤ) ≤ W := (nat_pow2_bitLength_le L).trans (by omega)
  have hl0_bl : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1_bl : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl4_bl : intBitLength (4 : ℤ) ≤ W := by have : intBitLength (4 : ℤ) = 4 := (by decide); omega
  have hu1_lt : 1 < 2 ^ (L + 1) := by
    have : 2 ^ 1 ≤ 2 ^ (L + 1) := Nat.pow_le_pow_right (by decide) (by omega)
    omega
  have htid_pow_bl : intBitLength ((tid * 2 ^ (L + 1) : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := (tid * 2 ^ (L + 1) + 1) * 4 + 0) (by omega)).trans ((treeCellAddr_bitLength_le hu1_lt (f := 0) (by decide) hW_addr).2)
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd hc_ok hb_ok (dst := 8) (c := ((2 ^ (L + 1) : ℕ) : ℤ)) (by decide) hpL1_bl
  set g1 := Function.update regs 8 (((2 ^ (L + 1) : ℕ) : ℤ) : ℤ); have bg1 : RegBounded W g1 := hbnd.update (r := 8) (by decide) hpL1_bl
  have hm7 : g1 0 * g1 8 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) := by simp [g1, hr0]
  have s2 := RegExec.mul (inp := inp) hfd_le bg1 hc_ok hb_ok (dst := 7) (a := 0) (b := 8) (by decide) (by decide) (by decide) (by rw [hm7]; exact htid_pow_bl)
  rw [hm7] at s2
  set g2 := Function.update g1 7 (((tid * 2 ^ (L + 1) : ℕ) : ℤ) : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 7) (by decide) htid_pow_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 hc_ok hb_ok (dst := 1) (c := 1) (by decide) hl1_bl
  set g3 := Function.update g2 1 (1 : ℤ); have bg3 : RegBounded W g3 := bg2.update (r := 1) (by decide) hl1_bl
  -- Loop invariant across `j = 0 .. L`
  let KeepRegs (g : ℕ → ℤ) : Prop :=
    g 0 = (tid : ℤ) ∧ g 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) ∧
    ∀ r < 16, r ≠ 1 → r ≠ 2 → r ≠ 3 → r ≠ 6 → r ≠ 7 → r ≠ 8 → r ≠ 10 → r ≠ 15 → g r = regs r
  let WalkInv (j : ℕ) (g : ℕ → ℤ) : Prop :=
    RegBounded W g ∧ KeepRegs g ∧
    (j ≤ L → ∃ off < 2 ^ j,
      (treeSubSet S (L - j) off).Nonempty ∧
      treeMinWalk S rNum rDen (L - j) off = treeMinWalk S rNum rDen L 0 ∧
      g 1 = (treeIdx L (L - j) off : ℤ))
  have hInv0 : WalkInv 0 g3 := by
    refine ⟨bg3, ⟨by simp [g3, g2, g1, hr0], by simp [g3, g2], fun r _ h1 _ _ _ h7 h8 _ _ => by
      simp [g3, g2, g1, Function.update_of_ne h1, Function.update_of_ne h7, Function.update_of_ne h8]⟩,
      fun _ => ⟨0, by simp, ?_, by simp, by simp [g3, treeIdx]⟩⟩
    rw [Nat.sub_zero, treeSubSet_root htree.hS]; exact hne
  have hStep : ∀ j < L, ∀ g, WalkInv j g →
      ∃ g', RegExec inp fd W C_cell C_bit minWalkStepStmt ws g ws g' 64 (12 * W * W) ∧ WalkInv (j + 1) g' := by
    intro j hj g ⟨hbg, hkeep, hex⟩
    obtain ⟨off, hoff_lt, hsub_ne, hwalk_eq, hg1⟩ := hex (by omega)
    let k := L - (j + 1)
    have hLj : L - j = k + 1 := by omega
    have hoff_k : off < 2 ^ (L - (k + 1)) := by
      have : L - (k + 1) = j := by omega
      rwa [this]
    have hoffL_lt : 2 * off < 2 ^ (L - k) := by
      have : L - k = j + 1 := by omega
      rw [this, pow_succ]; omega
    have hoffR_lt : 2 * off + 1 < 2 ^ (L - k) := by
      have : L - k = j + 1 := by omega
      rw [this, pow_succ]; omega
    set uL := treeIdx L k (2 * off)
    set uR := treeIdx L k (2 * off + 1)
    have huL_b := treeIdx_bounds (by omega : k ≤ L) hoffL_lt
    have huR_b := treeIdx_bounds (by omega : k ≤ L) hoffR_lt
    have h2u : 2 * treeIdx L (L - j) off = uL := by
      rw [hLj]; dsimp [uL, treeIdx]
      have : L - k = (L - (k + 1)) + 1 := by omega
      rw [this, pow_succ]; ring
    have ha2 : g 1 + g 1 = (uL : ℤ) := by rw [hg1]; exact_mod_cast (by omega : treeIdx L (L - j) off + treeIdx L (L - j) off = uL)
    have huL_bl : intBitLength (uL : ℤ) ≤ W := (nat_lt_pow2_bitLength_le huL_b.2).trans (by omega)
    have haL0_bl := (treeCellAddr_bitLength_le huL_b.2 (f := 0) (by decide) hW_addr).2
    have hbaseL_bl : intBitLength ((tid * 2 ^ (L + 1) + uL : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (tid * 2 ^ (L + 1) + uL) * 4 + 0) (by omega)).trans haL0_bl
    have t1 := RegExec.add (inp := inp) hfd_le hbg hc_ok hb_ok (dst := 2) (a := 1) (b := 1) (by decide) (by decide) (by decide) (by rw [ha2]; exact huL_bl)
    rw [ha2] at t1; set q1 := Function.update g 2 ((uL : ℤ) : ℤ); have bq1 : RegBounded W q1 := hbg.update (r := 2) (by decide) huL_bl
    have ha10 : q1 7 + q1 2 = ((tid * 2 ^ (L + 1) + uL : ℕ) : ℤ) := by simp [q1, hkeep.2.1]
    have t2 := RegExec.add (inp := inp) hfd_le bq1 hc_ok hb_ok (dst := 10) (a := 7) (b := 2) (by decide) (by decide) (by decide) (by rw [ha10]; exact hbaseL_bl)
    rw [ha10] at t2; set q2 := Function.update q1 10 (((tid * 2 ^ (L + 1) + uL : ℕ) : ℤ) : ℤ); have bq2 : RegBounded W q2 := bq1.update (r := 10) (by decide) hbaseL_bl
    have t3 := RegExec.lit (inp := inp) hfd_le bq2 hc_ok hb_ok (dst := 15) (c := 4) (by decide) hl4_bl
    set q3 := Function.update q2 15 (4 : ℤ); have bq3 : RegBounded W q3 := bq2.update (r := 15) (by decide) hl4_bl
    have hm10 : q3 10 * q3 15 = treeCellAddr L tid uL 0 := by simp [q3, q2, treeCellAddr]
    have t4 := RegExec.mul (inp := inp) hfd_le bq3 hc_ok hb_ok (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [hm10]; exact haL0_bl)
    rw [hm10] at t4; set q4 := Function.update q3 10 ((treeCellAddr L tid uL 0) : ℤ); have bq4 : RegBounded W q4 := bq3.update (r := 10) (by decide) haL0_bl
    set cL := (treeNodeVal S rNum rDen k (2 * off)).1
    have hr_cL : ws.read (.heap 2 (q4 10)) = (cL : ℤ) := by
      simpa [q4, uL, cL] using (htree.nodes k (by omega) (2 * off) hoffL_lt).read_fields.1
    obtain ⟨_, _, cL_bl, _, _, _⟩ := treeNodeVal_bounds hBr1 hS_bnds k (by omega) (2 * off)
    have t5 := RegExec.load (inp := inp) hfd_le bq4 hc_ok hb_ok (dst := 3) (table := 2) (addr := 10) (by decide) (by decide) hn2_bl (by rw [hr_cL]; exact cL_bl.trans (by omega))
    rw [hr_cL] at t5; set q5 := Function.update q4 3 ((cL : ℤ) : ℤ); have bq5 : RegBounded W q5 := bq4.update (r := 3) (by decide) (cL_bl.trans (by omega))
    have t6 := RegExec.lit (inp := inp) hfd_le bq5 hc_ok hb_ok (dst := 6) (c := 0) (by decide) hl0_bl
    set q6 := Function.update q5 6 (0 : ℤ); have bq6 : RegBounded W q6 := bq5.update (r := 6) (by decide) hl0_bl
    by_cases hcL_pos : 0 < cL
    · have hlt_reg : q6 6 < q6 3 := by simp [q6, q5]; omega
      have tCopy := RegExec.copy (inp := inp) hfd_le bq6 hc_ok hb_ok (dst := 1) (src := 2) (by decide) (by decide)
      set q7 := Function.update q6 1 ((q6 2) : ℤ); have bq7 : RegBounded W q7 := bq6.update (r := 1) (by decide) (bq6.2.1 2 (by decide))
      have tIte := RegExec.iteLt bq6 (a := 6) (b := 3) (by decide) (by decide)
        (fB := .seq (rLit 15 1) (rAdd 1 2 15))
        (by rw [if_pos hlt_reg]; exact tCopy)
      have sAll := (t1.seq (t2.seq (t3.seq (t4.seq (t5.seq (t6.seq tIte)))))).weaken rfl rfl (u₂ := 64) (b₂ := 12 * W * W) (by omega)
        (by nlinarith only [hW8] : 6 * W + 32 + (6 * W + 32 + (2 * W + 16 + (4 * W * W + (6 * W + 24 + (2 * W + 16 + (2 * W + 24 + (4 * W + 16))))))) ≤ 12 * W * W)
      refine ⟨q7, sAll, bq7, ⟨by simp [q7, q6, q5, q4, q3, q2, q1, hkeep.1], by simp [q7, q6, q5, q4, q3, q2, q1, hkeep.2.1], ?_⟩, ?_⟩
      · intro r hr h1 h2 h3 h6 h7 h8 h10 h15
        simp [q7, q6, q5, q4, q3, q2, q1, Function.update_of_ne h1, Function.update_of_ne h2,
          Function.update_of_ne h3, Function.update_of_ne h6, Function.update_of_ne h10, Function.update_of_ne h15]
        exact hkeep.2.2 r hr h1 h2 h3 h6 h7 h8 h10 h15
      · intro _
        refine ⟨2 * off, by rw [pow_succ]; omega, ?_, ?_, ?_⟩
        · have hcard : 0 < (treeSubSet S k (2 * off)).card := by rwa [← treeNodeVal_cnt S rNum rDen]
          exact Finset.card_pos.mp hcard
        · rw [← hwalk_eq, hLj]; simp [treeMinWalk, cL, hcL_pos, k]
        · simp [q7, q6, q5, q4, q3, q2, q1, uL, k]
    · have hnot_lt : ¬ (q6 6 < q6 3) := by simp [q6, q5]; omega
      have hcL_z : cL = 0 := by omega
      have t7a := RegExec.lit (inp := inp) hfd_le bq6 hc_ok hb_ok (dst := 15) (c := 1) (by decide) hl1_bl
      set q7a := Function.update q6 15 (1 : ℤ); have bq7a : RegBounded W q7a := bq6.update (r := 15) (by decide) hl1_bl
      have ha_uR : q7a 2 + q7a 15 = (uR : ℤ) := by
        simp only [q7a, q6, q5, q4, q3, q2, q1, Function.update_self,
          Function.update_of_ne (by decide : (2 : ℕ) ≠ 15), Function.update_of_ne (by decide : (2 : ℕ) ≠ 6),
          Function.update_of_ne (by decide : (2 : ℕ) ≠ 3), Function.update_of_ne (by decide : (2 : ℕ) ≠ 10)]
        exact_mod_cast (by dsimp [uL, uR, treeIdx]; omega : uL + 1 = uR)
      have huR_bl : intBitLength (uR : ℤ) ≤ W := (nat_lt_pow2_bitLength_le huR_b.2).trans (by omega)
      have t7b := RegExec.add (inp := inp) hfd_le bq7a hc_ok hb_ok (dst := 1) (a := 2) (b := 15) (by decide) (by decide) (by decide) (by rw [ha_uR]; exact huR_bl)
      rw [ha_uR] at t7b; set q7 := Function.update q7a 1 ((uR : ℤ) : ℤ); have bq7 : RegBounded W q7 := bq7a.update (r := 1) (by decide) huR_bl
      have tIte := RegExec.iteLt bq6 (a := 6) (b := 3) (by decide) (by decide) (tB := rCopy 1 2)
        (by rw [if_neg hnot_lt]; exact t7a.seq t7b)
      have sAll := (t1.seq (t2.seq (t3.seq (t4.seq (t5.seq (t6.seq tIte)))))).weaken rfl rfl (u₂ := 64) (b₂ := 12 * W * W) (by omega)
        (by nlinarith only [hW8] : 6 * W + 32 + (6 * W + 32 + (2 * W + 16 + (4 * W * W + (6 * W + 24 + (2 * W + 16 + (2 * W + 16 + (6 * W + 32) + (4 * W + 16))))))) ≤ 12 * W * W)
      refine ⟨q7, sAll, bq7, ⟨by simp [q7, q7a, q6, q5, q4, q3, q2, q1, hkeep.1], by simp [q7, q7a, q6, q5, q4, q3, q2, q1, hkeep.2.1], ?_⟩, ?_⟩
      · intro r hr h1 h2 h3 h6 h7 h8 h10 h15
        simp [q7, q7a, q6, q5, q4, q3, q2, q1, Function.update_of_ne h1, Function.update_of_ne h2,
          Function.update_of_ne h3, Function.update_of_ne h6, Function.update_of_ne h10, Function.update_of_ne h15]
        exact hkeep.2.2 r hr h1 h2 h3 h6 h7 h8 h10 h15
      · intro _
        refine ⟨2 * off + 1, by rw [pow_succ]; omega, ?_, ?_, ?_⟩
        · have hempL : treeSubSet S k (2 * off) = ∅ := by
            apply Finset.card_eq_zero.mp; rw [← treeNodeVal_cnt S rNum rDen]; exact hcL_z
          have hun := (treeSubSet_succ_disjoint S k off).2
          rw [← hLj, hempL, Finset.empty_union] at hun
          rwa [← hun]
        · rw [← hwalk_eq, hLj]; simp [treeMinWalk, cL, hcL_pos, k]
        · simp [q7, q7a, uR, k]
  classical
  let seqG : ∀ n : ℕ, { g : ℕ → ℤ // WalkInv n g } :=
    Nat.rec ⟨g3, hInv0⟩ (fun j prev =>
      if hj : j < L then
        let hEx := hStep j hj prev.1 prev.2
        ⟨Classical.choose hEx, (Classical.choose_spec hEx).2⟩
      else
        ⟨prev.1, ⟨prev.2.1, prev.2.2.1, fun hle => by omega⟩⟩)
  let regSeq : ℕ → ℕ → ℤ := fun n => (seqG n).1
  have hL_bl : intBitLength (L : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le L
    have hlog : Nat.log 2 L < L := Nat.log_lt_of_lt_pow (by omega) Nat.lt_two_pow_self
    unfold natBitLength at h1; omega
  have s4 := RegExec.repeatLit L hL_bl (fun _ => ws) regSeq bg3 (fun j hj => by
    have hseq_eq : seqG (j + 1) =
        ⟨Classical.choose (hStep j hj (seqG j).1 (seqG j).2),
         (Classical.choose_spec (hStep j hj (seqG j).1 (seqG j).2)).2⟩ := by
      dsimp only [seqG]
      exact dif_pos hj
    dsimp only [regSeq]
    rw [hseq_eq]
    exact (Classical.choose_spec (hStep j hj (seqG j).1 (seqG j).2)).1)
  obtain ⟨hbL, hkeepL, hexL⟩ := (seqG L).2
  obtain ⟨offL, _, _, hwalkL, hgL1⟩ := hexL le_rfl
  simp only [Nat.sub_self, treeMinWalk] at hwalkL hgL1
  have hne_root : (treeSubSet S L 0).Nonempty := by rw [treeSubSet_root htree.hS]; exact hne
  have hmin_eq : offL = S.min' hne := by
    rw [hwalkL, treeMinWalk_spec S rNum rDen L 0 hne_root]
    congr 1; exact treeSubSet_root htree.hS
  have s5 := RegExec.lit (inp := inp) hfd_le hbL hc_ok hb_ok (dst := 5) (c := ((2 ^ L : ℕ) : ℤ)) (by decide) hpL_bl
  set gEnd0 := Function.update (regSeq L) 5 (((2 ^ L : ℕ) : ℤ) : ℤ); have bgEnd0 : RegBounded W gEnd0 := hbL.update (r := 5) (by decide) hpL_bl
  have hsub_eq : gEnd0 1 - gEnd0 5 = (S.min' hne : ℤ) := by
    dsimp only [regSeq] at hgL1 ⊢
    simp only [gEnd0, Function.update_self, Function.update_of_ne (by decide : (1 : ℕ) ≠ 5), regSeq, hgL1, treeIdx, Nat.sub_zero]
    rw [hmin_eq]; push_cast; ring
  have hmin_lt : S.min' hne < 2 ^ L := htree.hS _ (Finset.min'_mem S hne)
  have hmin_bl : intBitLength (S.min' hne : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hmin_lt).trans (by omega)
  have s6 := RegExec.sub (inp := inp) hfd_le bgEnd0 hc_ok hb_ok (dst := 1) (a := 1) (b := 5) (by decide) (by decide) (by decide) (by rw [hsub_eq]; exact hmin_bl)
  rw [hsub_eq] at s6
  set gEnd := Function.update gEnd0 1 ((S.min' hne : ℤ) : ℤ); have bgEnd : RegBounded W gEnd := bgEnd0.update (r := 1) (by decide) hmin_bl
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq s6))))).weaken rfl rfl (u₂ := 64 * L + 32) (b₂ := (12 * L + 8) * W * W) (by omega)
    (by nlinarith only [hW8, hL1] : 2 * W + 16 + (4 * W * W + (2 * W + 16 + ((L * (12 * W * W) + W) + (2 * W + 16 + (6 * W + 32))))) ≤ (12 * L + 8) * W * W)
  refine ⟨gEnd, sTot, bgEnd, ?_, by simp [gEnd], ?_⟩
  · simp [gEnd, gEnd0, regSeq, hkeepL.1]
  · intro r hr h1 h2 h3 h5 h6 h7 h8 h10 h15
    simp only [gEnd, gEnd0, Function.update_of_ne h1, Function.update_of_ne h5]
    exact hkeepL.2.2 r hr h1 h2 h3 h6 h7 h8 h10 h15

/-! ### 3. `treeMexRegs`: top-down minimum excluded handle walk `mexHandle S` -/

def mexWalkStepStmt : BitRAMStmt :=
  .seq (rAdd 2 1 1)
  (.seq (rAdd 10 7 2)
  (.seq (rLit 15 4)
  (.seq (rMul 10 10 15)
  (.seq (rLoad 3 2 10)
  (.seq
    (.ite (.intLt (.readLocal 3 (.lit 0)) (.readLocal 4 (.lit 0)))
      (rCopy 1 2)
      (.seq (rLit 15 1) (rAdd 1 2 15)))
    (.seq (rLit 15 2) (rDiv 4 4 15)))))))

def treeMexRegs (L : ℕ) : BitRAMStmt :=
  .seq (rLit 8 ((2 ^ (L + 1) : ℕ) : ℤ))
  (.seq (rMul 7 0 8)
  (.seq (rLit 1 1)
  (.seq (rLit 4 ((2 ^ (L - 1) : ℕ) : ℤ))
  (.seq (.repeatN (.lit (L : ℤ)) mexWalkStepStmt)
  (.seq (rLit 5 ((2 ^ L : ℕ) : ℤ))
        (rSub 1 1 5))))))

theorem exec_treeMexRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws : WordStore}
    (hc_ok : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell)
    (hb_ok : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit)
    {L tid B_r : ℕ} (hL1 : 1 ≤ L) (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 16 ≤ W)
    {S : Finset ℕ} {rNum rDen : ℕ → ℤ}
    (htree : TreeStoredAt L tid S rNum rDen ws)
    (hS_bnds : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r)
    (hc_lt : S.card < 2 ^ L)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (tid : ℤ)) :
    ∃ regs',
      RegExec inp fd W C_cell C_bit (treeMexRegs L) ws regs ws regs'
        (80 * L + 40) ((16 * L + 8) * W * W) ∧
      RegBounded W regs' ∧
      regs' 0 = (tid : ℤ) ∧
      regs' 1 = (mexHandle S : ℤ) ∧
      (∀ r < 16, r ≠ 1 → r ≠ 2 → r ≠ 3 → r ≠ 4 → r ≠ 5 → r ≠ 7 → r ≠ 8 → r ≠ 10 → r ≠ 15 → regs' r = regs r) := by
  have hW8 : 18 ≤ W := by omega
  have hW_addr : natBitLength tid + L + 12 ≤ W := by omega
  have hn2_bl : natBitLength 2 ≤ W := by have : natBitLength 2 = 2 := (by decide); omega
  have hpL1_bl : intBitLength ((2 ^ (L + 1) : ℕ) : ℤ) ≤ W := (nat_pow2_bitLength_le (L + 1)).trans (by omega)
  have hpL_bl : intBitLength ((2 ^ L : ℕ) : ℤ) ≤ W := (nat_pow2_bitLength_le L).trans (by omega)
  have hpLm1_bl : intBitLength ((2 ^ (L - 1) : ℕ) : ℤ) ≤ W := (nat_pow2_bitLength_le (L - 1)).trans (by omega)
  have hl1_bl : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl2_bl : intBitLength (2 : ℤ) ≤ W := by have : intBitLength (2 : ℤ) = 3 := (by decide); omega
  have hl4_bl : intBitLength (4 : ℤ) ≤ W := by have : intBitLength (4 : ℤ) = 4 := (by decide); omega
  have hu1_lt : 1 < 2 ^ (L + 1) := by
    have : 2 ^ 1 ≤ 2 ^ (L + 1) := Nat.pow_le_pow_right (by decide) (by omega)
    omega
  have htid_pow_bl : intBitLength ((tid * 2 ^ (L + 1) : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := (tid * 2 ^ (L + 1) + 1) * 4 + 0) (by omega)).trans ((treeCellAddr_bitLength_le hu1_lt (f := 0) (by decide) hW_addr).2)
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd hc_ok hb_ok (dst := 8) (c := ((2 ^ (L + 1) : ℕ) : ℤ)) (by decide) hpL1_bl
  set g1 := Function.update regs 8 (((2 ^ (L + 1) : ℕ) : ℤ) : ℤ); have bg1 : RegBounded W g1 := hbnd.update (r := 8) (by decide) hpL1_bl
  have hm7 : g1 0 * g1 8 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) := by simp [g1, hr0]
  have s2 := RegExec.mul (inp := inp) hfd_le bg1 hc_ok hb_ok (dst := 7) (a := 0) (b := 8) (by decide) (by decide) (by decide) (by rw [hm7]; exact htid_pow_bl)
  rw [hm7] at s2
  set g2 := Function.update g1 7 (((tid * 2 ^ (L + 1) : ℕ) : ℤ) : ℤ); have bg2 : RegBounded W g2 := bg1.update (r := 7) (by decide) htid_pow_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 hc_ok hb_ok (dst := 1) (c := 1) (by decide) hl1_bl
  set g3 := Function.update g2 1 (1 : ℤ); have bg3 : RegBounded W g3 := bg2.update (r := 1) (by decide) hl1_bl
  have s4 := RegExec.lit (inp := inp) hfd_le bg3 hc_ok hb_ok (dst := 4) (c := ((2 ^ (L - 1) : ℕ) : ℤ)) (by decide) hpLm1_bl
  set g4 := Function.update g3 4 (((2 ^ (L - 1) : ℕ) : ℤ) : ℤ); have bg4 : RegBounded W g4 := bg3.update (r := 4) (by decide) hpLm1_bl
  let KeepRegs (g : ℕ → ℤ) : Prop :=
    g 0 = (tid : ℤ) ∧ g 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) ∧
    ∀ r < 16, r ≠ 1 → r ≠ 2 → r ≠ 3 → r ≠ 4 → r ≠ 7 → r ≠ 8 → r ≠ 10 → r ≠ 15 → g r = regs r
  let MexInv (j : ℕ) (g : ℕ → ℤ) : Prop :=
    RegBounded W g ∧ KeepRegs g ∧ 0 ≤ g 4 ∧
    (j < L → g 4 = ((2 ^ (L - 1 - j) : ℕ) : ℤ)) ∧
    (j ≤ L → ∃ off < 2 ^ j,
      (treeSubSet S (L - j) off).card < 2 ^ (L - j) ∧
      treeMexWalk S rNum rDen (L - j) off = treeMexWalk S rNum rDen L 0 ∧
      g 1 = (treeIdx L (L - j) off : ℤ))
  have hInv0 : MexInv 0 g4 := by
    refine ⟨bg4, ⟨by simp [g4, g3, g2, g1, hr0], by simp [g4, g3, g2], fun r _ h1 _ _ h4 h7 h8 _ _ => by
      simp [g4, g3, g2, g1, Function.update_of_ne h1, Function.update_of_ne h4, Function.update_of_ne h7, Function.update_of_ne h8]⟩,
      by simp [g4], fun _ => by simp [g4], fun _ => ⟨0, by simp, ?_, by simp, by simp [g4, g3, treeIdx]⟩⟩
    rw [Nat.sub_zero, treeSubSet_root htree.hS]; exact hc_lt
  have hStep : ∀ j < L, ∀ g, MexInv j g →
      ∃ g', RegExec inp fd W C_cell C_bit mexWalkStepStmt ws g ws g' 80 (16 * W * W) ∧ MexInv (j + 1) g' := by
    intro j hj g ⟨hbg, hkeep, hg4_0, hg4_pow, hex⟩
    obtain ⟨off, hoff_lt, hcard_sub, hwalk_eq, hg1⟩ := hex (by omega)
    have hg4_val := hg4_pow hj
    let k := L - 1 - j
    have hLj : L - j = k + 1 := by omega
    have hoffL_lt : 2 * off < 2 ^ (L - k) := by
      have : L - k = j + 1 := by omega
      rw [this, pow_succ]; omega
    have hoffR_lt : 2 * off + 1 < 2 ^ (L - k) := by
      have : L - k = j + 1 := by omega
      rw [this, pow_succ]; omega
    set uL := treeIdx L k (2 * off)
    set uR := treeIdx L k (2 * off + 1)
    have huL_b := treeIdx_bounds (by omega : k ≤ L) hoffL_lt
    have huR_b := treeIdx_bounds (by omega : k ≤ L) hoffR_lt
    have ha2 : g 1 + g 1 = (uL : ℤ) := by
      rw [hg1, hLj]
      have : 2 * treeIdx L (k + 1) off = uL := by
        dsimp [uL, treeIdx]
        have h1 : L - k = (L - (k + 1)) + 1 := by omega
        rw [h1, pow_succ]; ring
      exact_mod_cast (by omega : treeIdx L (k + 1) off + treeIdx L (k + 1) off = uL)
    have huL_bl : intBitLength (uL : ℤ) ≤ W := (nat_lt_pow2_bitLength_le huL_b.2).trans (by omega)
    have haL0_bl := (treeCellAddr_bitLength_le huL_b.2 (f := 0) (by decide) hW_addr).2
    have hbaseL_bl : intBitLength ((tid * 2 ^ (L + 1) + uL : ℕ) : ℤ) ≤ W :=
      (intBitLength_natCast_mono (b := (tid * 2 ^ (L + 1) + uL) * 4 + 0) (by omega)).trans haL0_bl
    have t1 := RegExec.add (inp := inp) hfd_le hbg hc_ok hb_ok (dst := 2) (a := 1) (b := 1) (by decide) (by decide) (by decide) (by rw [ha2]; exact huL_bl)
    rw [ha2] at t1; set q1 := Function.update g 2 ((uL : ℤ) : ℤ); have bq1 : RegBounded W q1 := hbg.update (r := 2) (by decide) huL_bl
    have ha10 : q1 7 + q1 2 = ((tid * 2 ^ (L + 1) + uL : ℕ) : ℤ) := by simp [q1, hkeep.2.1]
    have t2 := RegExec.add (inp := inp) hfd_le bq1 hc_ok hb_ok (dst := 10) (a := 7) (b := 2) (by decide) (by decide) (by decide) (by rw [ha10]; exact hbaseL_bl)
    rw [ha10] at t2; set q2 := Function.update q1 10 (((tid * 2 ^ (L + 1) + uL : ℕ) : ℤ) : ℤ); have bq2 : RegBounded W q2 := bq1.update (r := 10) (by decide) hbaseL_bl
    have t3 := RegExec.lit (inp := inp) hfd_le bq2 hc_ok hb_ok (dst := 15) (c := 4) (by decide) hl4_bl
    set q3 := Function.update q2 15 (4 : ℤ); have bq3 : RegBounded W q3 := bq2.update (r := 15) (by decide) hl4_bl
    have hm10 : q3 10 * q3 15 = treeCellAddr L tid uL 0 := by simp [q3, q2, treeCellAddr]
    have t4 := RegExec.mul (inp := inp) hfd_le bq3 hc_ok hb_ok (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [hm10]; exact haL0_bl)
    rw [hm10] at t4; set q4 := Function.update q3 10 ((treeCellAddr L tid uL 0) : ℤ); have bq4 : RegBounded W q4 := bq3.update (r := 10) (by decide) haL0_bl
    set cL := (treeNodeVal S rNum rDen k (2 * off)).1
    have hr_cL : ws.read (.heap 2 (q4 10)) = (cL : ℤ) := by
      simpa [q4, uL, cL] using (htree.nodes k (by omega) (2 * off) hoffL_lt).read_fields.1
    obtain ⟨_, _, cL_bl, _, _, _⟩ := treeNodeVal_bounds hBr1 hS_bnds k (by omega) (2 * off)
    have t5 := RegExec.load (inp := inp) hfd_le bq4 hc_ok hb_ok (dst := 3) (table := 2) (addr := 10) (by decide) (by decide) hn2_bl (by rw [hr_cL]; exact cL_bl.trans (by omega))
    rw [hr_cL] at t5; set q5 := Function.update q4 3 ((cL : ℤ) : ℤ); have bq5 : RegBounded W q5 := bq4.update (r := 3) (by decide) (cL_bl.trans (by omega))
    -- Branch on `cL < 2^k`
    have hBranch : ∃ q6,
        RegExec inp fd W C_cell C_bit
          (.ite (.intLt (.readLocal 3 (.lit 0)) (.readLocal 4 (.lit 0)))
            (rCopy 1 2)
            (.seq (rLit 15 1) (rAdd 1 2 15)))
          ws q5 ws q6 18 (14 * W + 64) ∧
        RegBounded W q6 ∧ KeepRegs q6 ∧ q6 4 = ((2 ^ k : ℕ) : ℤ) ∧
        ∃ offNext < 2 ^ (j + 1),
          (treeSubSet S k offNext).card < 2 ^ k ∧
          treeMexWalk S rNum rDen k offNext = treeMexWalk S rNum rDen L 0 ∧
          q6 1 = (treeIdx L k offNext : ℤ) := by
      by_cases hlt_c : cL < 2 ^ k
      · have hlt_reg : q5 3 < q5 4 := by
          simp only [q5, q4, q3, q2, q1, Function.update_self,
            Function.update_of_ne (by decide : (4 : ℕ) ≠ 3),
            Function.update_of_ne (by decide : (4 : ℕ) ≠ 10),
            Function.update_of_ne (by decide : (4 : ℕ) ≠ 15),
            Function.update_of_ne (by decide : (4 : ℕ) ≠ 2), hg4_val]
          exact_mod_cast hlt_c
        have tc := RegExec.copy (inp := inp) hfd_le bq5 hc_ok hb_ok (dst := 1) (src := 2) (by decide) (by decide)
        set q6 := Function.update q5 1 ((q5 2) : ℤ); have bq6 : RegBounded W q6 := bq5.update (r := 1) (by decide) (bq5.2.1 2 (by decide))
        have tIte := (RegExec.iteLt bq5 (a := 3) (b := 4) (by decide) (by decide)
          (fB := .seq (rLit 15 1) (rAdd 1 2 15))
          (by rw [if_pos hlt_reg]; exact tc.weaken rfl rfl (u₂ := 12) (b₂ := 10 * W + 48) (by omega) (by omega))).weaken rfl rfl (u₂ := 18) (b₂ := 14 * W + 64) (by omega) (by omega)
        refine ⟨q6, tIte, bq6, ⟨by simp [q6, q5, q4, q3, q2, q1, hkeep.1], by simp [q6, q5, q4, q3, q2, q1, hkeep.2.1], ?_⟩,
          by simp [q6, q5, q4, q3, q2, q1, hg4_val, k], 2 * off, by rw [pow_succ]; omega, ?_, ?_, ?_⟩
        · intro r hr h1 h2 h3 h4 h7 h8 h10 h15
          simp [q6, q5, q4, q3, q2, q1, Function.update_of_ne h1, Function.update_of_ne h2,
            Function.update_of_ne h3, Function.update_of_ne h10, Function.update_of_ne h15]
          exact hkeep.2.2 r hr h1 h2 h3 h4 h7 h8 h10 h15
        · rwa [← treeNodeVal_cnt S rNum rDen]
        · rw [← hwalk_eq, hLj]; simp [treeMexWalk, cL, hlt_c]
        · simp [q6, q5, q4, q3, q2, q1, uL]
      · have hnot_reg : ¬ (q5 3 < q5 4) := by
          simp only [q5, q4, q3, q2, q1, Function.update_self,
            Function.update_of_ne (by decide : (4 : ℕ) ≠ 3),
            Function.update_of_ne (by decide : (4 : ℕ) ≠ 10),
            Function.update_of_ne (by decide : (4 : ℕ) ≠ 15),
            Function.update_of_ne (by decide : (4 : ℕ) ≠ 2), hg4_val]
          exact_mod_cast hlt_c
        have tb1 := RegExec.lit (inp := inp) hfd_le bq5 hc_ok hb_ok (dst := 15) (c := 1) (by decide) hl1_bl
        set q6a := Function.update q5 15 (1 : ℤ); have bq6a : RegBounded W q6a := bq5.update (r := 15) (by decide) hl1_bl
        have ha_uR : q6a 2 + q6a 15 = (uR : ℤ) := by
          simp only [q6a, q5, q4, q3, q2, q1, Function.update_self,
            Function.update_of_ne (by decide : (2 : ℕ) ≠ 15),
            Function.update_of_ne (by decide : (2 : ℕ) ≠ 3),
            Function.update_of_ne (by decide : (2 : ℕ) ≠ 10)]
          exact_mod_cast (by dsimp [uL, uR, treeIdx]; omega : uL + 1 = uR)
        have huR_bl : intBitLength (uR : ℤ) ≤ W := (nat_lt_pow2_bitLength_le huR_b.2).trans (by omega)
        have tb2 := RegExec.add (inp := inp) hfd_le bq6a hc_ok hb_ok (dst := 1) (a := 2) (b := 15) (by decide) (by decide) (by decide) (by rw [ha_uR]; exact huR_bl)
        rw [ha_uR] at tb2; set q6 := Function.update q6a 1 ((uR : ℤ) : ℤ); have bq6 : RegBounded W q6 := bq6a.update (r := 1) (by decide) huR_bl
        have tIte := (RegExec.iteLt bq5 (a := 3) (b := 4) (by decide) (by decide) (tB := rCopy 1 2)
          (by rw [if_neg hnot_reg]; exact (tb1.seq tb2).weaken rfl rfl (u₂ := 12) (b₂ := 10 * W + 48) (by omega) (by omega))).weaken rfl rfl (u₂ := 18) (b₂ := 14 * W + 64) (by omega) (by omega)
        refine ⟨q6, tIte, bq6, ⟨by simp [q6, q6a, q5, q4, q3, q2, q1, hkeep.1], by simp [q6, q6a, q5, q4, q3, q2, q1, hkeep.2.1], ?_⟩,
          by simp [q6, q6a, q5, q4, q3, q2, q1, hg4_val, k], 2 * off + 1, by rw [pow_succ]; omega, ?_, ?_, ?_⟩
        · intro r hr h1 h2 h3 h4 h7 h8 h10 h15
          simp [q6, q6a, q5, q4, q3, q2, q1, Function.update_of_ne h1, Function.update_of_ne h2,
            Function.update_of_ne h3, Function.update_of_ne h10, Function.update_of_ne h15]
          exact hkeep.2.2 r hr h1 h2 h3 h4 h7 h8 h10 h15
        · obtain ⟨hdisj, hun⟩ := treeSubSet_succ_disjoint S k off
          rw [hLj, hun, Finset.card_union_of_disjoint hdisj, pow_succ] at hcard_sub
          have hcL_eq : (treeSubSet S k (2 * off)).card = cL := (treeNodeVal_cnt S rNum rDen k (2 * off)).symm
          omega
        · rw [← hwalk_eq, hLj]; simp [treeMexWalk, cL, hlt_c]
        · simp [q6, uR]
    obtain ⟨q6, tBr, bq6, hkeep6, hq6_4, offNext, hoffN, hcardN, hwalkN, hq6_1⟩ := hBranch
    have t7 := RegExec.lit (inp := inp) hfd_le bq6 hc_ok hb_ok (dst := 15) (c := 2) (by decide) hl2_bl
    set q7 := Function.update q6 15 (2 : ℤ); have bq7 : RegBounded W q7 := bq6.update (r := 15) (by decide) hl2_bl
    have t8 := RegExec.div (inp := inp) hfd_le bq7 hc_ok hb_ok (dst := 4) (a := 4) (b := 15) (by decide) (by decide) (by decide)
      (by simp [q7, hq6_4]) (by simp [q7])
    set q8 := Function.update q7 4 (q7 4 / q7 15)
    have bq8 : RegBounded W q8 := by
      have hdiv_le : intBitLength (q7 4 / q7 15) ≤ W := by
        have h0a : 0 ≤ q7 4 := by simp [q7, hq6_4]
        have h0b : 0 ≤ q7 15 := by simp [q7]
        have hq0 : 0 ≤ q7 4 / q7 15 := Int.ediv_nonneg h0a h0b
        have hq_le : q7 4 / q7 15 ≤ q7 4 := by
          have hb1 : 1 ≤ q7 15 := by simp [q7]
          calc q7 4 / q7 15 = (q7 4 / q7 15) * 1 := (mul_one _).symm
            _ ≤ (q7 4 / q7 15) * q7 15 := Int.mul_le_mul_of_nonneg_left hb1 hq0
            _ ≤ q7 4 := Int.ediv_mul_le (q7 4) (by simp [q7])
        have habs : (q7 4 / q7 15).natAbs ≤ (q7 4).natAbs := by omega
        have hbl : intBitLength (q7 4 / q7 15) ≤ intBitLength (q7 4) := by
          unfold intBitLength natBitLength
          by_cases hz : q7 4 / q7 15 = 0
          · rw [if_pos hz]; split_ifs <;> omega
          · have haz : q7 4 ≠ 0 := by omega
            rw [if_neg hz, if_neg haz]
            have := Nat.log_mono_right (b := 2) habs
            omega
        exact hbl.trans (bq7.2.1 4 (by decide))
      exact bq7.update (r := 4) (by decide) hdiv_le
    have sAll := (t1.seq (t2.seq (t3.seq (t4.seq (t5.seq (tBr.seq (t7.seq t8))))))).weaken rfl rfl (u₂ := 80) (b₂ := 16 * W * W) (by omega)
      (by nlinarith only [hW8] : 6 * W + 32 + (6 * W + 32 + (2 * W + 16 + (4 * W * W + (6 * W + 24 + (14 * W + 64 + (2 * W + 16 + 4 * W * W)))))) ≤ 16 * W * W)
    refine ⟨q8, sAll, bq8, ⟨by simp [q8, q7, hkeep6.1], by simp [q8, q7, hkeep6.2.1], ?_⟩, ?_, ?_, ?_⟩
    · intro r hr h1 h2 h3 h4 h7 h8 h10 h15
      simp [q8, q7, Function.update_of_ne h4, Function.update_of_ne h15]
      exact hkeep6.2.2 r hr h1 h2 h3 h4 h7 h8 h10 h15
    · simp only [q8, q7, Function.update_self, Function.update_of_ne (by decide : (4 : ℕ) ≠ 15), hq6_4]
      exact Int.ediv_nonneg (by positivity) (by decide)
    · intro hj1
      simp only [q8, q7, Function.update_self, Function.update_of_ne (by decide : (4 : ℕ) ≠ 15), hq6_4]
      have hk_eq : k = (L - 1 - (j + 1)) + 1 := by omega
      rw [hk_eq, pow_succ]
      have hdiv : ((2 ^ (L - 1 - (j + 1)) * 2 : ℕ) : ℤ) / 2 = ((2 ^ (L - 1 - (j + 1)) : ℕ) : ℤ) := by
        exact_mod_cast Nat.mul_div_cancel (2 ^ (L - 1 - (j + 1))) (by decide : 0 < 2)
      exact hdiv
    · intro _
      have hk_eq : L - (j + 1) = k := by omega
      rw [hk_eq]
      exact ⟨offNext, hoffN, hcardN, hwalkN, by simp [q8, q7, hq6_1]⟩
  classical
  let seqG : ∀ n : ℕ, { g : ℕ → ℤ // MexInv n g } :=
    Nat.rec ⟨g4, hInv0⟩ (fun j prev =>
      if hj : j < L then
        let hEx := hStep j hj prev.1 prev.2
        ⟨Classical.choose hEx, (Classical.choose_spec hEx).2⟩
      else
        ⟨prev.1, ⟨prev.2.1, prev.2.2.1, prev.2.2.2.1, fun hlt => by omega, fun hle => by omega⟩⟩)
  let regSeq : ℕ → ℕ → ℤ := fun n => (seqG n).1
  have hL_bl : intBitLength (L : ℤ) ≤ W := by
    have h1 := intBitLength_ofNat_le L
    have hlog : Nat.log 2 L < L := Nat.log_lt_of_lt_pow (by omega) Nat.lt_two_pow_self
    unfold natBitLength at h1; omega
  have s5 := RegExec.repeatLit L hL_bl (fun _ => ws) regSeq bg4 (fun j hj => by
    have hseq_eq : seqG (j + 1) =
        ⟨Classical.choose (hStep j hj (seqG j).1 (seqG j).2),
         (Classical.choose_spec (hStep j hj (seqG j).1 (seqG j).2)).2⟩ := by
      dsimp only [seqG]
      exact dif_pos hj
    dsimp only [regSeq]
    rw [hseq_eq]
    exact (Classical.choose_spec (hStep j hj (seqG j).1 (seqG j).2)).1)
  obtain ⟨hbL, hkeepL, _, _, hexL⟩ := (seqG L).2
  obtain ⟨offL, _, _, hwalkL, hgL1⟩ := hexL le_rfl
  simp only [Nat.sub_self, treeMexWalk] at hwalkL hgL1
  have hmex_eq : offL = mexHandle S := by
    rw [hwalkL, treeMexWalk_root_eq_mexHandle rNum rDen htree.hS hc_lt]
  have s6 := RegExec.lit (inp := inp) hfd_le hbL hc_ok hb_ok (dst := 5) (c := ((2 ^ L : ℕ) : ℤ)) (by decide) hpL_bl
  set gEnd0 := Function.update (regSeq L) 5 (((2 ^ L : ℕ) : ℤ) : ℤ); have bgEnd0 : RegBounded W gEnd0 := hbL.update (r := 5) (by decide) hpL_bl
  have hsub_eq : gEnd0 1 - gEnd0 5 = (mexHandle S : ℤ) := by
    dsimp only [regSeq] at hgL1 ⊢
    simp only [gEnd0, Function.update_self, Function.update_of_ne (by decide : (1 : ℕ) ≠ 5), regSeq, hgL1, treeIdx, Nat.sub_zero]
    rw [hmex_eq]; push_cast; ring
  have hmex_lt : mexHandle S < 2 ^ L := mexHandle_lt_of_card_lt hc_lt
  have hmex_bl : intBitLength (mexHandle S : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hmex_lt).trans (by omega)
  have s7 := RegExec.sub (inp := inp) hfd_le bgEnd0 hc_ok hb_ok (dst := 1) (a := 1) (b := 5) (by decide) (by decide) (by decide) (by rw [hsub_eq]; exact hmex_bl)
  rw [hsub_eq] at s7
  set gEnd := Function.update gEnd0 1 ((mexHandle S : ℤ) : ℤ); have bgEnd : RegBounded W gEnd := bgEnd0.update (r := 1) (by decide) hmex_bl
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq s7)))))).weaken rfl rfl (u₂ := 80 * L + 40) (b₂ := (16 * L + 8) * W * W) (by omega)
    (by nlinarith only [hW8, hL1] : 2 * W + 16 + (4 * W * W + (2 * W + 16 + (2 * W + 16 + ((L * (16 * W * W) + W) + (2 * W + 16 + (6 * W + 32)))))) ≤ (16 * L + 8) * W * W)
  refine ⟨gEnd, sTot, bgEnd, ?_, by simp [gEnd], ?_⟩
  · simp [gEnd, gEnd0, regSeq, hkeepL.1]
  · intro r hr h1 h2 h3 h4 h5 h7 h8 h10 h15
    simp only [gEnd, gEnd0, Function.update_of_ne h1, Function.update_of_ne h5]
    exact hkeepL.2.2 r hr h1 h2 h3 h4 h7 h8 h10 h15

end UL.C12LVE
