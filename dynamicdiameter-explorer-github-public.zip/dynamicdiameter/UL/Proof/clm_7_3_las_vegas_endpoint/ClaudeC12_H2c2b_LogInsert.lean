import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2c2a_StoreBase
set_option autoImplicit false
set_option maxHeartbeats 500000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 4. Execution of `trA2LogInsertAfterWrite` (factored into 4 fast top-level theorems) -/

private def wrapScratchA2 (hasScratch2 : Bool) (e val : ℤ) (w : WordStore) : WordStore :=
  if hasScratch2 then (w.write (.heap 12 1) e).write (.heap 12 2) val else w.write (.heap 12 1) e

private theorem a2SimInv_after_hit
    {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    {table : ℕ} (ht : table < T_max) (idx val : ℤ)
    {s : ℕ} (hsid : sidOfEnc (idx * (T_max : ℤ) + (table : ℤ)) = some s) :
    A2SimInv wsBase T_max S_max (wsSub.write (.heap table idx) val)
      (wsSim.write (.heap 10 (idx * (T_max : ℤ) + (table : ℤ))) val)
      highSid sidOfEnc encOfSid freeStack := by
  set e := idx * (T_max : ℤ) + (table : ℤ)
  set ws10 := wsSim.write (.heap 10 e) val
  have hwf10 : WellFormedWS ws10 := wellFormedWS_write hinv.wfSim _ _
  exact
  { wfBase := hinv.wfBase
    wfSub := wellFormedWS_write hinv.wfSub _ _
    wfSim := hwf10
    hT := hinv.hT
    high_le := hinv.high_le
    sub_tables := fun t' i' hm => by
      simp only [WordStore.write, Finset.mem_insert, RAMCellLoc.heap.injEq] at hm
      rcases hm with ⟨rfl, rfl⟩ | hm'
      · exact ht
      · exact hinv.sub_tables t' i' hm'
    base_live := fun loc hb => by
      have hne : loc ≠ .heap 10 e := by intro h; subst h; simp [IsA2BaseLoc] at hb
      simp [ws10, WordStore.write, hne, hinv.base_live loc hb]
    base_vals := fun loc hb => by
      have hne : loc ≠ .heap 10 e := by intro h; subst h; simp [IsA2BaseLoc] at hb
      simp [ws10, WordStore.write, Function.update_of_ne hne, hinv.base_vals loc hb]
    local_live := fun d' v' i' => by simp [ws10, WordStore.write, hinv.local_live d' v' i']
    local_vals := fun d' v' i' => by simp [ws10, WordStore.write, hinv.local_vals d' v' i']
    tab10_live := fun e' => by
      simp only [ws10, WordStore.write, Finset.mem_insert, RAMCellLoc.heap.injEq, true_and]
      constructor
      · rintro (rfl | hm')
        · exact ⟨table, ht, idx, rfl, Or.inl ⟨rfl, rfl⟩⟩
        · obtain ⟨t', ht', i', rfl, hm_sub⟩ := (hinv.tab10_live e').mp hm'
          exact ⟨t', ht', i', rfl, Or.inr hm_sub⟩
      · rintro ⟨t', ht', i', rfl, ⟨rfl, rfl⟩ | hm_sub⟩
        · exact Or.inl rfl
        · exact Or.inr ((hinv.tab10_live _).mpr ⟨t', ht', i', rfl, hm_sub⟩)
    tab10_read := fun t' ht' i' => by
      by_cases heq : t' = table ∧ i' = idx
      · rcases heq with ⟨rfl, rfl⟩; simp [ws10, e]
      · have hne_e : i' * (T_max : ℤ) + (t' : ℤ) ≠ e := fun hh =>
          heq (encA2_inj ht' ht hh)
        have hne_sub : (.heap t' i' : RAMCellLoc) ≠ .heap table idx := by simp [heq]
        rw [wordStore_read_write_ne _ (by simp [hne_e]) val,
            wordStore_read_write_ne _ hne_sub val]
        exact hinv.tab10_read t' ht' i'
    free_nodup := hinv.free_nodup
    free_lt := hinv.free_lt
    active_iff := fun e' => by
      simp only [ws10, WordStore.write, Finset.mem_insert, RAMCellLoc.heap.injEq, true_and]
      by_cases heq : e' = e
      · subst heq; simp [hsid]
      · simp [heq, hinv.active_iff e']
    sid_lt := hinv.sid_lt
    enc_sid := hinv.enc_sid
    tab12_4 := ⟨fun hf => by simp [ws10, WordStore.write, hinv.tab12_4.1 hf],
      by rw [wordStore_read_write_ne _ (by simp)]; exact hinv.tab12_4.2⟩
    tab12_5 := ⟨fun hh => by simp [ws10, WordStore.write, hinv.tab12_5.1 hh],
      by rw [wordStore_read_write_ne _ (by simp)]; exact hinv.tab12_5.2⟩
    tab12_other := fun i h4 h5 => by simp [ws10, WordStore.write, hinv.tab12_other i h4 h5]
    tab13_spec := fun e' =>
      ⟨fun s' hs' =>
        let h0 := (hinv.tab13_spec e').1 s' hs'
        ⟨by simp [ws10, WordStore.write, h0.1], by simp [ws10, WordStore.write, h0.2]⟩,
       fun hn => by simp [ws10, WordStore.write, (hinv.tab13_spec e').2 hn]⟩
    tab14_spec := fun z =>
      ⟨fun hz hlt =>
        let h0 := (hinv.tab14_spec z).1 hz hlt
        ⟨by simp [ws10, WordStore.write, h0.1], by simp [ws10, WordStore.write, h0.2]⟩,
       fun hn => by simp [ws10, WordStore.write, (hinv.tab14_spec z).2 hn]⟩
    tab15_16_spec := fun z =>
      ⟨fun h =>
        let h0 := (hinv.tab15_16_spec z).1 h
        ⟨by simp [ws10, WordStore.write, h0.1], by simp [ws10, WordStore.write, h0.2.1],
         by simp [ws10, WordStore.write, h0.2.2.1], by simp [ws10, WordStore.write, h0.2.2.2]⟩,
       fun hn =>
        let h0 := (hinv.tab15_16_spec z).2 hn
        ⟨by simp [ws10, WordStore.write, h0.1], by simp [ws10, WordStore.write, h0.2]⟩⟩
    live_cases := fun loc hm => by
      simp only [ws10, WordStore.write, Finset.mem_insert] at hm
      rcases hm with rfl | hm'
      · exact Or.inr (Or.inr ⟨10, e, Or.inl rfl, rfl⟩)
      · exact hinv.live_cases loc hm' }


private theorem exec_trA2AllocSid {d : ℕ} (inpSim : BitRAMInput d)
    {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    {table : ℕ} (idx val : ℤ) (hasScratch2 : Bool)
    (hSubCell : (wsSub.write (.heap table idx) val).cellCount ≤ S_max)
    (hnSub_old : (.heap table idx : RAMCellLoc) ∉ wsSub.live)
    {subPeakBit C_cell C_bit : ℕ}
    (hHeadCell : inpSim.inputCellSpace + wsSim.cellCount + 12 ≤ C_cell)
    (hHeadBit : inpSim.inputBitSpace + wsSim.bitSize + 12 * subPeakBit + 16 * natBitLength T_max +
      20 * (natBitLength S_max + 4) + 200 ≤ C_bit)
    (he_val_sub : intBitLength (idx * (T_max : ℤ) + (table : ℤ)) + intBitLength val ≤ subPeakBit + natBitLength T_max + 4)
    (hval_bl : intBitLength val ≤ subPeakBit)
    (stMid st0 : BitRAMExecState)
    (hwMid_eq : stMid.words = wrapScratchA2 hasScratch2 (idx * (T_max : ℤ) + (table : ℤ)) val
      (wsSim.write (.heap 10 (idx * (T_max : ℤ) + (table : ℤ))) val))
    (hst0_words : st0.words = stMid.words)
    (hst0_fd : st0.frameDepth = stMid.frameDepth)
    (hst0_rb : st0.remainingBits = stMid.remainingBits)
    (hst0_pc : st0.peakCellSpace = stMid.peakCellSpace)
    (hst0_pb : st0.peakBitSpace = stMid.peakBitSpace)
    (hpC : stMid.peakCellSpace ≤ C_cell)
    (hpB : stMid.peakBitSpace ≤ C_bit) :
    let e := idx * (T_max : ℤ) + (table : ℤ)
    let S_bits := natBitLength S_max + 4
    let ws10 := wsSim.write (.heap 10 e) val
    ∃ (stA : BitRAMExecState) (wsCore : WordStore)
      (highSid' : ℕ) (freeStack' : List ℕ) (sNew : ℕ),
      RunsTo inpSim [.stmt (.ite (.intLt (.lit 0) (.readHeap 12 (.lit 4)))
        (.seq (.writeHeap 12 (.lit 3) (.readHeap 14 (.sub (.readHeap 12 (.lit 4)) (.lit 1))))
        (.seq (.freeHeap 14 (.sub (.readHeap 12 (.lit 4)) (.lit 1)))
              (.ite (.intEq (.readHeap 12 (.lit 4)) (.lit 1))
                (.freeHeap 12 (.lit 4))
                (.writeHeap 12 (.lit 4) (.sub (.readHeap 12 (.lit 4)) (.lit 1))))))
        (.seq (.writeHeap 12 (.lit 3) (.readHeap 12 (.lit 5)))
              (.writeHeap 12 (.lit 5) (.add (.readHeap 12 (.lit 5)) (.lit 1)))))] st0 stA ∧
      WellFormedWS wsCore ∧
      stA.words = (wrapScratchA2 hasScratch2 e val wsCore).write (.heap 12 3) (sNew : ℤ) ∧
      stA.frameDepth = stMid.frameDepth ∧
      stA.remainingBits = stMid.remainingBits ∧
      stA.unitCost ≤ st0.unitCost + 26 ∧
      stA.bitCost ≤ st0.bitCost + 16 * S_bits + 112 ∧
      stA.peakCellSpace ≤ C_cell ∧
      stA.peakBitSpace ≤ C_bit ∧
      wsCore.cellCount ≤ wsSim.cellCount + 2 ∧
      wsCore.bitSize ≤ wsSim.bitSize + subPeakBit + natBitLength T_max + 2 * S_bits + 24 ∧
      highSid' ≤ S_max ∧ sNew < highSid' ∧ sNew ∉ freeStack' ∧ ¬ (sNew < highSid ∧ sNew ∉ freeStack) ∧
      freeStack'.Nodup ∧ (∀ s' ∈ freeStack', s' < highSid') ∧
      (∀ s' : ℕ, (s' < highSid' ∧ s' ∉ freeStack') ↔ (s' = sNew ∨ (s' < highSid ∧ s' ∉ freeStack))) ∧
      (∀ loc, loc ≠ .heap 12 4 → loc ≠ .heap 12 5 → ( ∀ z, loc ≠ .heap 14 z ) →
        (loc ∈ wsCore.live ↔ loc ∈ ws10.live) ∧ wsCore.vals loc = ws10.vals loc) ∧
      ((freeStack' = [] → (.heap 12 4 : RAMCellLoc) ∉ wsCore.live) ∧
        wsCore.read (.heap 12 4) = (freeStack'.length : ℤ)) ∧
      ((highSid' = 0 → (.heap 12 5 : RAMCellLoc) ∉ wsCore.live) ∧
        wsCore.read (.heap 12 5) = (highSid' : ℤ)) ∧
      (∀ z : ℤ,
        (∀ (_hz : 0 ≤ z) (hlt : z.toNat < freeStack'.length),
          (.heap 14 z : RAMCellLoc) ∈ wsCore.live ∧
          wsCore.vals (.heap 14 z) = (freeStack'[z.toNat] : ℤ)) ∧
        (¬ (0 ≤ z ∧ z.toNat < freeStack'.length) → (.heap 14 z : RAMCellLoc) ∉ wsCore.live)) ∧
      (∀ loc ∈ wsCore.live, loc ∈ ws10.live ∨ loc = .heap 12 4 ∨ loc = .heap 12 5) := by
  intro e S_bits ws10
  change intBitLength e + intBitLength val ≤ subPeakBit + natBitLength T_max + 4 at he_val_sub
  have he_sub : intBitLength e ≤ subPeakBit + natBitLength T_max + 4 := by omega
  change inpSim.inputBitSpace + wsSim.bitSize + 12 * subPeakBit + 16 * natBitLength T_max + 20 * S_bits + 200 ≤ C_bit at hHeadBit
  change stMid.words = wrapScratchA2 hasScratch2 e val ws10 at hwMid_eq
  let wrapScratch := wrapScratchA2 hasScratch2 e val
  have hwf10 : WellFormedWS ws10 := wellFormedWS_write hinv.wfSim _ _
  have hSb4 : 4 ≤ S_bits := by dsimp [S_bits]; omega
  have hsid_bl : ∀ s : ℕ, s ≤ S_max → intBitLength (s : ℤ) ≤ S_bits := by
    intro s hs; have h1 := intBitLength_ofNat_le s; have h2 := natBitLength_mono hs; dsimp [S_bits]; linarith
  have hc10 : ws10.cellCount ≤ wsSim.cellCount + 1 := cellCount_write_le _ _ _
  have hb10 : ws10.bitSize ≤ wsSim.bitSize + subPeakBit + natBitLength T_max + 10 := by
    have h := bitSize_write_le wsSim (.heap 10 e) val
    have hn10 : natBitLength 10 = 4 := by decide
    dsimp [RAMCellLoc.bitLength] at h; rw [hn10] at h; linarith
  have hwrap_read_ne : ∀ (w : WordStore) (loc : RAMCellLoc),
      loc ≠ .heap 12 1 → loc ≠ .heap 12 2 → (wrapScratch w).read loc = w.read loc := by
    intro w loc h1 h2; dsimp [wrapScratch, wrapScratchA2]
    cases hasScratch2
    · simp only [Bool.false_eq_true, ↓reduceIte]; exact wordStore_read_write_ne w h1 e
    · simp only [↓reduceIte]; rw [wordStore_read_write_ne _ h2 val, wordStore_read_write_ne _ h1 e]
  have hwrap_size : ∀ w : WordStore,
      (wrapScratch w).cellCount ≤ w.cellCount + 2 ∧
      (wrapScratch w).bitSize ≤ w.bitSize + 2 * subPeakBit + natBitLength T_max + 20 := by
    intro w; dsimp [wrapScratch, wrapScratchA2]
    have hn12 : natBitLength 12 = 4 := by decide
    have hl1 : intBitLength (1 : ℤ) = 2 := by decide
    have hl2 : intBitLength (2 : ℤ) = 3 := by decide
    have hc1 := cellCount_write_le w (.heap 12 1) e
    have hb1 := bitSize_write_le w (.heap 12 1) e
    dsimp [RAMCellLoc.bitLength] at hb1; rw [hn12, hl1] at hb1
    cases hasScratch2
    · simp only [Bool.false_eq_true, ↓reduceIte]; exact ⟨by linarith, by linarith⟩
    · simp only [↓reduceIte]
      have hc2 := cellCount_write_le (w.write (.heap 12 1) e) (.heap 12 2) val
      have hb2 := bitSize_write_le (w.write (.heap 12 1) e) (.heap 12 2) val
      dsimp [RAMCellLoc.bitLength] at hb2; rw [hn12, hl2] at hb2
      exact ⟨by linarith, by linarith⟩
  have hr12_4_mid : stMid.words.read (.heap 12 4) = (freeStack.length : ℤ) := by
    rw [hwMid_eq, hwrap_read_ne ws10 _ (by decide) (by decide)]
    rw [wordStore_read_write_ne _ (by simp) val]; exact hinv.tab12_4.2
  have hr12_5_mid : stMid.words.read (.heap 12 5) = (highSid : ℤ) := by
    rw [hwMid_eq, hwrap_read_ne ws10 _ (by decide) (by decide)]
    rw [wordStore_read_write_ne _ (by simp) val]; exact hinv.tab12_5.2
  obtain ⟨hfree_le, hact_le⟩ := hinv.highSid_sub_free_le
  have hhigh_S := hinv.high_le
  have h12 : natBitLength 12 = 4 := by decide
  have h14 : natBitLength 14 = 4 := by decide
  have hl0 : intBitLength (0 : ℤ) = 1 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  have hl3 : intBitLength (3 : ℤ) = 3 := by decide
  have hl4 : intBitLength (4 : ℤ) = 4 := by decide
  have hl5 : intBitLength (5 : ℤ) = 4 := by decide
  by_cases hne_fs : freeStack = []
  · -- `freeStack = []`: allocate fresh `sNew = highSid`, `highSid' = highSid + 1`
    have hcond_in : evalBitCond inpSim st0.frameDepth st0.words
        (.intLt (.lit 0) (.readHeap 12 (.lit 4))) = (false, 4, 16) := by
      rw [hst0_words]; simp [evalBitCond, evalIntExpr, hr12_4_mid, hne_fs, h12, hl0, hl4]
    have hsub_cnt : (wsSub.write (.heap table idx) val).cellCount = wsSub.cellCount + 1 :=
      cellCount_write_not_mem hnSub_old val
    have hhigh1_le : highSid + 1 ≤ S_max := by
      simp only [hne_fs, List.length_nil, Nat.sub_zero] at hact_le
      rw [hsub_cnt] at hSubCell
      linarith
    have hh_bl : intBitLength (highSid : ℤ) ≤ S_bits := hsid_bl highSid hhigh_S
    have hh1_bl : intBitLength ((highSid + 1 : ℕ) : ℤ) ≤ S_bits := hsid_bl (highSid + 1) hhigh1_le
    let st0' : BitRAMExecState :=
      { st0 with unitCost := st0.unitCost + 4, bitCost := st0.bitCost + 16 }
    -- `.writeHeap 12 (.lit 3) (.readHeap 12 (.lit 5))`
    obtain ⟨hw_scC, hw_scB⟩ := hwrap_size ws10
    have hc_w3 : inpSim.inputCellSpace + (st0'.words.write (.heap 12 3) (highSid : ℤ)).cellCount ≤ C_cell := by
      have hc3 := cellCount_write_le st0'.words (.heap 12 3) (highSid : ℤ)
      dsimp [st0'] at hc3 ⊢; rw [hst0_words, hwMid_eq] at hc3 ⊢; linarith
    have hb_w3 : inpSim.inputBitSpace + (st0'.words.write (.heap 12 3) (highSid : ℤ)).bitSize ≤ C_bit := by
      have hb3 := bitSize_write_le st0'.words (.heap 12 3) (highSid : ℤ)
      dsimp [RAMCellLoc.bitLength] at hb3; rw [h12, hl3] at hb3
      dsimp [st0'] at hb3 ⊢; rw [hst0_words, hwMid_eq] at hb3 ⊢; linarith
    obtain ⟨stA1, hrA1, hwA1, hfdA1, hrbA1, hucA1, hbcA1, hpCA1, hpBA1⟩ :=
      exec_writeHeap_ceil inpSim 12 (.lit 3) (.readHeap 12 (.lit 5)) st0' (by dsimp [st0']; rw [hst0_pc]; exact hpC) (by dsimp [st0']; rw [hst0_pb]; exact hpB)
        (idx := 3) (val := (highSid : ℤ)) (u₁ := 1) (b₁ := 3) (u₂ := 2)
        (b₂ := 12 + intBitLength (highSid : ℤ))
        (evalIntLe_lit _ _ _ _ (by decide))
        (evalIntLe_readHeap_lit inpSim st0'.frameDepth st0'.words 12 5 _ (b := 12 + intBitLength (highSid : ℤ)) (by dsimp [st0']; rw [hst0_words]; exact hr12_5_mid) h12 hl5 (le_of_eq (by ring)))
        hc_w3 hb_w3
    -- `.writeHeap 12 (.lit 5) (.add (.readHeap 12 (.lit 5)) (.lit 1))`
    have hr12_5_A1 : stA1.words.read (.heap 12 5) = (highSid : ℤ) := by
      rw [hwA1, wordStore_read_write_ne _ (by decide)]; dsimp [st0']; rw [hst0_words]; exact hr12_5_mid
    have hc_w5 : inpSim.inputCellSpace + (stA1.words.write (.heap 12 5) ((highSid + 1 : ℕ) : ℤ)).cellCount ≤ C_cell := by
      have hc5 := cellCount_write_le stA1.words (.heap 12 5) ((highSid + 1 : ℕ) : ℤ)
      have hc3 := cellCount_write_le st0'.words (.heap 12 3) (highSid : ℤ)
      rw [← hwA1] at hc3; dsimp [st0'] at hc3; rw [hst0_words, hwMid_eq] at hc3; linarith
    have hb_w5 : inpSim.inputBitSpace + (stA1.words.write (.heap 12 5) ((highSid + 1 : ℕ) : ℤ)).bitSize ≤ C_bit := by
      have hb5 := bitSize_write_le stA1.words (.heap 12 5) ((highSid + 1 : ℕ) : ℤ)
      have hb3 := bitSize_write_le st0'.words (.heap 12 3) (highSid : ℤ)
      dsimp [RAMCellLoc.bitLength] at hb3 hb5; rw [h12, hl3] at hb3; rw [h12, hl5] at hb5
      rw [← hwA1] at hb3; dsimp [st0'] at hb3; rw [hst0_words, hwMid_eq] at hb3; linarith
    obtain ⟨stA2, hrA2, hwA2, hfdA2, hrbA2, hucA2, hbcA2, hpCA2, hpBA2⟩ :=
      exec_writeHeap_ceil inpSim 12 (.lit 5) (.add (.readHeap 12 (.lit 5)) (.lit 1)) stA1 hpCA1 hpBA1
        (idx := 5) (val := ((highSid + 1 : ℕ) : ℤ)) (u₁ := 1) (b₁ := 4) (u₂ := 4)
        (b₂ := 16 + 2 * intBitLength (highSid : ℤ))
        (evalIntLe_lit _ _ _ _ (by decide))
        (evalIntLe_add_read12_one inpSim stA1.frameDepth stA1.words 5 highSid (b := 16 + 2 * intBitLength (highSid : ℤ)) hr12_5_A1 hl5 (le_of_eq (by ring)))
        hc_w5 hb_w5
    set wsCore := ws10.write (.heap 12 5) ((highSid + 1 : ℕ) : ℤ)
    have hwA2_eq : stA2.words = (wrapScratch wsCore).write (.heap 12 3) (highSid : ℤ) := by
      rw [hwA2, hwA1]
      dsimp [st0', wsCore, wrapScratch, wrapScratchA2]
      rw [hst0_words, hwMid_eq]
      dsimp [wrapScratch, wrapScratchA2]
      cases hasScratch2
      · simp only [Bool.false_eq_true, ↓reduceIte]
        rw [wordStore_write_comm (by decide) (highSid : ℤ) _,
            wordStore_write_comm (ws := ws10) (by decide) e _]
      · simp only [↓reduceIte]
        rw [wordStore_write_comm (by decide) (highSid : ℤ) _,
            wordStore_write_comm (by decide) val _,
            wordStore_write_comm (ws := ws10) (by decide) e _]
    refine ⟨stA2, wsCore, highSid + 1, [], highSid, ?_,

      wellFormedWS_write hwf10 _ _, hwA2_eq, by rw [hfdA2, hfdA1]; dsimp [st0']; exact hst0_fd, by rw [hrbA2, hrbA1]; dsimp [st0']; exact hst0_rb,
      ?_, ?_, hpCA2, hpBA2, ?_, ?_, hhigh1_le, Nat.lt_succ_self _, by simp, by omega,
      List.nodup_nil, by simp, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · apply RunsTo.ite
      rw [hcond_in]; dsimp only; simp only [Bool.false_eq_true, ↓reduceIte]
      exact RunsTo.seq hrA1 hrA2
    · have : st0'.unitCost = st0.unitCost + 4 := rfl; linarith [hucA2, hucA1]
    · have : st0'.bitCost = st0.bitCost + 16 := rfl
      rw [h12, hl3] at hbcA1; rw [h12, hl5] at hbcA2
      linarith [hbcA2, hbcA1]
    · have hc5 := cellCount_write_le ws10 (.heap 12 5) ((highSid + 1 : ℕ) : ℤ)
      dsimp only [wsCore]; linarith only [hc5, hc10]
    · have hb5 := bitSize_write_le ws10 (.heap 12 5) ((highSid + 1 : ℕ) : ℤ)
      dsimp only [RAMCellLoc.bitLength] at hb5; rw [h12, hl5] at hb5
      dsimp only [wsCore]; linarith only [hb5, hb10, hh1_bl, hSb4]
    · intro s'; simp only [hne_fs, List.not_mem_nil, not_false_eq_true, and_true]; omega
    · intro loc h4 h5 _
      exact ⟨by simp [wsCore, WordStore.write, h5],
             by simp [wsCore, WordStore.write, Function.update_of_ne h5]⟩
    · refine ⟨fun _ => by simp [wsCore, ws10, WordStore.write, hinv.tab12_4.1 hne_fs], ?_⟩
      rw [wordStore_read_write_ne _ (by decide), wordStore_read_write_ne _ (by simp)]
      simpa [hne_fs] using hinv.tab12_4.2
    · refine ⟨by omega, ?_⟩
      simp [wsCore]
    · intro z
      refine ⟨fun _ hlt => by simp at hlt, fun _ => ?_⟩
      have hn14 := (hinv.tab14_spec z).2 (by simp [hne_fs])
      simp [wsCore, ws10, WordStore.write, hn14]
    · intro loc hm
      simp only [wsCore, WordStore.write, Finset.mem_insert] at hm
      rcases hm with rfl | hm'
      · exact Or.inr (Or.inr rfl)
      · exact Or.inl hm'
  · -- `freeStack ≠ []`: pop `sNew = freeStack[freeStack.length - 1]`, `freeStack' = freeStack.dropLast`
    have hlen_pos : 1 ≤ freeStack.length := List.length_pos_of_ne_nil hne_fs
    set topIdx : ℕ := freeStack.length - 1
    have htop_lt : topIdx < freeStack.length := by dsimp [topIdx]; omega
    set sNew : ℕ := freeStack[topIdx]
    have hsNew_lt : sNew < highSid := hinv.free_lt sNew (List.getElem_mem htop_lt)
    have hfs_append : freeStack.dropLast ++ [sNew] = freeStack := by
      have hget : freeStack.getLast hne_fs = sNew := by
        rw [List.getLast_eq_getElem]
      rw [← hget]
      exact List.dropLast_append_getLast hne_fs
    have hnd_fs := hinv.free_nodup
    rw [← hfs_append, List.nodup_append] at hnd_fs
    have hnd_drop : freeStack.dropLast.Nodup := hnd_fs.1
    have hsNew_notin : sNew ∉ freeStack.dropLast := fun hm => hnd_fs.2.2 sNew hm sNew (by simp) rfl
    have hdrop_len : freeStack.dropLast.length = topIdx := List.length_dropLast
    have hfl_bl : intBitLength (freeStack.length : ℤ) ≤ S_bits :=
      hsid_bl freeStack.length (by linarith)
    have htop_bl : intBitLength (topIdx : ℤ) ≤ S_bits :=
      hsid_bl topIdx (by linarith)
    have hsNew_bl : intBitLength (sNew : ℤ) ≤ S_bits :=
      hsid_bl sNew (by linarith)
    have hlen_bl : intBitLength (freeStack.length : ℤ) ≤ S_bits :=
      hsid_bl freeStack.length (hfree_le.trans hhigh_S)
    have htop_bl : intBitLength (topIdx : ℤ) ≤ S_bits :=
      hsid_bl topIdx (by dsimp [topIdx]; omega)
    have htop_z : (freeStack.length : ℤ) - 1 = (topIdx : ℤ) := by dsimp [topIdx]; omega
    have hr14_top : stMid.words.read (.heap 14 (topIdx : ℤ)) = (sNew : ℤ) := by
      rw [hwMid_eq, hwrap_read_ne ws10 _ (by simp) (by simp),
        wordStore_read_write_ne _ (by simp), wordStore_read_eq_vals hinv.wfSim]
      have h14t := (hinv.tab14_spec (topIdx : ℤ)).1 (by omega) (by simpa using htop_lt)
      simpa [sNew] using h14t.2
    have hcond_in : evalBitCond inpSim st0.frameDepth st0.words
        (.intLt (.lit 0) (.readHeap 12 (.lit 4))) =
        (true, 4, 14 + 2 * intBitLength (freeStack.length : ℤ)) := by
      have hpos_z : (0 : ℤ) < (freeStack.length : ℤ) := by omega
      rw [hst0_words]
      simp only [evalBitCond, evalIntExpr, hr12_4_mid, decide_eq_true hpos_z]
      simp only [h12, hl0, hl4]
      exact Prod.ext rfl (Prod.ext rfl (by ring))
    let st0' : BitRAMExecState :=
      { st0 with
        unitCost := st0.unitCost + 4
        bitCost := st0.bitCost + (14 + 2 * intBitLength (freeStack.length : ℤ)) }
    obtain ⟨hw_scC, hw_scB⟩ := hwrap_size ws10
    -- 1. `.writeHeap 12 (.lit 3) (.readHeap 14 (.sub (.readHeap 12 (.lit 4)) (.lit 1)))`
    have hc_w3 : inpSim.inputCellSpace + (st0'.words.write (.heap 12 3) (sNew : ℤ)).cellCount ≤ C_cell := by
      have hc3 := cellCount_write_le st0'.words (.heap 12 3) (sNew : ℤ)
      dsimp [st0'] at hc3 ⊢; rw [hst0_words, hwMid_eq] at hc3 ⊢; linarith
    have hb_w3 : inpSim.inputBitSpace + (st0'.words.write (.heap 12 3) (sNew : ℤ)).bitSize ≤ C_bit := by
      have hb3 := bitSize_write_le st0'.words (.heap 12 3) (sNew : ℤ)
      dsimp [RAMCellLoc.bitLength] at hb3; rw [h12, hl3] at hb3
      dsimp [st0'] at hb3 ⊢; rw [hst0_words, hwMid_eq] at hb3 ⊢; linarith
    obtain ⟨stB1, hrB1, hwB1, hfdB1, hrbB1, hucB1, hbcB1, hpCB1, hpBB1⟩ :=
      exec_writeHeap_ceil inpSim 12 (.lit 3)
        (.readHeap 14 (.sub (.readHeap 12 (.lit 4)) (.lit 1))) st0' (by dsimp [st0']; rw [hst0_pc]; exact hpC) (by dsimp [st0']; rw [hst0_pb]; exact hpB)
        (idx := 3) (val := (sNew : ℤ)) (u₁ := 1) (b₁ := 3) (u₂ := 5)
        (b₂ := 20 + 2 * intBitLength (freeStack.length : ℤ) + intBitLength (topIdx : ℤ) + intBitLength (sNew : ℤ))
        (evalIntLe_lit _ _ _ _ (by decide))
        (evalIntLe_read_sub_read12_one inpSim st0'.frameDepth st0'.words 14 4 _ _ _ (b := 20 + 2 * intBitLength (freeStack.length : ℤ) + intBitLength (topIdx : ℤ) + intBitLength (sNew : ℤ)) (by dsimp [st0']; rw [hst0_words]; exact hr12_4_mid) htop_z (by dsimp [st0']; rw [hst0_words]; exact hr14_top) h14 hl4 (le_of_eq (by ring)))
        hc_w3 hb_w3
    -- 2. `.freeHeap 14 (.sub (.readHeap 12 (.lit 4)) (.lit 1))`
    have hr12_4_B1 : stB1.words.read (.heap 12 4) = (freeStack.length : ℤ) := by
      rw [hwB1, wordStore_read_write_ne _ (by decide)]; dsimp [st0']; rw [hst0_words]; exact hr12_4_mid
    obtain ⟨stB2, hrB2, hwB2, hfdB2, hrbB2, hucB2, hbcB2, hpCB2, hpBB2⟩ :=
      exec_freeHeap_ceil inpSim 14 (.sub (.readHeap 12 (.lit 4)) (.lit 1)) stB1 hpCB1 hpBB1
        (idx := (topIdx : ℤ)) (u₁ := 4)
        (b₁ := 16 + 2 * intBitLength (freeStack.length : ℤ))
        (evalIntLe_sub_read12_one inpSim stB1.frameDepth stB1.words 4 _ _ (b := 16 + 2 * intBitLength (freeStack.length : ℤ)) hr12_4_B1 htop_z hl4 (le_of_eq (by ring)))
    -- 3. `.ite (.intEq (.readHeap 12 (.lit 4)) (.lit 1)) (.freeHeap 12 4) (.writeHeap 12 4 ...)`
    have hr12_4_B2 : stB2.words.read (.heap 12 4) = (freeStack.length : ℤ) := by
      rw [hwB2, wordStore_read_free_ne _ (by simp)]; exact hr12_4_B1
    set ws14 := ws10.free (.heap 14 (topIdx : ℤ))
    have hwB2_clean : stB2.words = (wrapScratch ws14).write (.heap 12 3) (sNew : ℤ) := by
      rw [hwB2, hwB1]; dsimp [st0', ws14, wrapScratch, wrapScratchA2]
      rw [hst0_words, hwMid_eq]; dsimp [wrapScratch, wrapScratchA2]
      cases hasScratch2
      · simp only [Bool.false_eq_true, ↓reduceIte]
        rw [wordStore_free_write_comm (by simp) (sNew : ℤ),
            wordStore_free_write_comm (by simp) e]
      · simp only [↓reduceIte]
        rw [wordStore_free_write_comm (by simp) (sNew : ℤ),
            wordStore_free_write_comm (by simp) val,
            wordStore_free_write_comm (by simp) e]
    have hc14 : ws14.cellCount ≤ ws10.cellCount := cellCount_free_le _ _
    have hb14 : ws14.bitSize ≤ ws10.bitSize := bitSize_free_le _ _
    have hcond_eq1 : evalBitCond inpSim stB2.frameDepth stB2.words
        (.intEq (.readHeap 12 (.lit 4)) (.lit 1)) =
        (decide (freeStack.length = 1), 4,
         16 + 2 * intBitLength (freeStack.length : ℤ)) := by
      have hdec : decide ((freeStack.length : ℤ) = 1) = decide (freeStack.length = 1) := by
        by_cases h1 : freeStack.length = 1 <;> simp [h1]
      simp only [evalBitCond, evalIntExpr, hr12_4_B2, hdec]
      simp only [h12, hl4, hl1]
      exact Prod.ext rfl (Prod.ext rfl (by ring))
    -- Unify the two sub-cases (`freeStack.length = 1` vs `freeStack.length > 1`)
    set wsCore : WordStore :=
      if freeStack.length = 1 then ws14.free (.heap 12 4)
      else ws14.write (.heap 12 4) (topIdx : ℤ)
    have hB3_step : ∃ stB3 : BitRAMExecState,
        RunsTo inpSim [.stmt (.ite (.intEq (.readHeap 12 (.lit 4)) (.lit 1))
          (.freeHeap 12 (.lit 4))
          (.writeHeap 12 (.lit 4) (.sub (.readHeap 12 (.lit 4)) (.lit 1))))] stB2 stB3 ∧
        stB3.words = (wrapScratch wsCore).write (.heap 12 3) (sNew : ℤ) ∧
        stB3.frameDepth = stB2.frameDepth ∧
        stB3.remainingBits = stB2.remainingBits ∧
        stB3.unitCost ≤ stB2.unitCost + 10 ∧
        stB3.bitCost ≤ stB2.bitCost + 6 * S_bits + 44 ∧
        stB3.peakCellSpace ≤ C_cell ∧
        stB3.peakBitSpace ≤ C_bit := by
      let stB2' : BitRAMExecState :=
        { stB2 with
          unitCost := stB2.unitCost + 4
          bitCost := stB2.bitCost + (16 + 2 * intBitLength (freeStack.length : ℤ)) }
      by_cases hlen1 : freeStack.length = 1
      · obtain ⟨stB3, hr3, hw3, hfd3, hrb3, huc3, hbc3, hpC3, hpB3⟩ :=
          exec_freeHeap_ceil inpSim 12 (.lit 4) stB2' hpCB2 hpBB2 (idx := 4) (u₁ := 1) (b₁ := 4) (evalIntLe_lit _ _ _ _ (by decide))
        have hite3 : RunsTo inpSim [.stmt (.ite (.intEq (.readHeap 12 (.lit 4)) (.lit 1))
            (.freeHeap 12 (.lit 4))
            (.writeHeap 12 (.lit 4) (.sub (.readHeap 12 (.lit 4)) (.lit 1))))] stB2 stB3 := by
          apply RunsTo.ite; rw [hcond_eq1]; simp only [decide_eq_true hlen1, ↓reduceIte]; exact hr3
        have hw3_eq : stB3.words = (wrapScratch wsCore).write (.heap 12 3) (sNew : ℤ) := by
          rw [hw3]; dsimp [stB2', wsCore]; rw [if_pos hlen1, hwB2_clean]
          dsimp [wrapScratch, wrapScratchA2]
          cases hasScratch2
          · simp only [Bool.false_eq_true, ↓reduceIte]
            rw [wordStore_free_write_comm (by decide) (sNew : ℤ),
                wordStore_free_write_comm (by decide) e]
          · simp only [↓reduceIte]
            rw [wordStore_free_write_comm (by decide) (sNew : ℤ),
                wordStore_free_write_comm (by decide) val,
                wordStore_free_write_comm (by decide) e]
        refine ⟨stB3, hite3, hw3_eq, hfd3, hrb3, ?_, ?_, hpC3, hpB3⟩
        · have : stB2'.unitCost = stB2.unitCost + 4 := rfl; linarith [huc3]
        · have : stB2'.bitCost = stB2.bitCost + (16 + 2 * intBitLength (freeStack.length : ℤ)) := rfl
          rw [h12, hl4] at hbc3; linarith [hbc3]
      · obtain ⟨hw_sc14C, hw_sc14B⟩ := hwrap_size ws14
        have hc_w4 : inpSim.inputCellSpace + (stB2'.words.write (.heap 12 4) (topIdx : ℤ)).cellCount ≤ C_cell := by
          have hc4 := cellCount_write_le stB2'.words (.heap 12 4) (topIdx : ℤ)
          have hc3 := cellCount_write_le (wrapScratch ws14) (.heap 12 3) (sNew : ℤ)
          dsimp [stB2'] at hc4 ⊢; rw [hwB2_clean] at hc4 ⊢; linarith
        have hb_w4 : inpSim.inputBitSpace + (stB2'.words.write (.heap 12 4) (topIdx : ℤ)).bitSize ≤ C_bit := by
          have hb4 := bitSize_write_le stB2'.words (.heap 12 4) (topIdx : ℤ)
          have hb3 := bitSize_write_le (wrapScratch ws14) (.heap 12 3) (sNew : ℤ)
          dsimp [RAMCellLoc.bitLength] at hb3 hb4; rw [h12, hl3] at hb3; rw [h12, hl4] at hb4
          dsimp [stB2'] at hb4 ⊢; rw [hwB2_clean] at hb4 ⊢; linarith
        obtain ⟨stB3, hr3, hw3, hfd3, hrb3, huc3, hbc3, hpC3, hpB3⟩ :=
          exec_writeHeap_ceil inpSim 12 (.lit 4) (.sub (.readHeap 12 (.lit 4)) (.lit 1)) stB2' hpCB2 hpBB2
            (idx := 4) (val := (topIdx : ℤ)) (u₁ := 1) (b₁ := 4) (u₂ := 4)
            (b₂ := 16 + 2 * intBitLength (freeStack.length : ℤ))
            (evalIntLe_lit _ _ _ _ (by decide))
            (evalIntLe_sub_read12_one inpSim stB2'.frameDepth stB2'.words 4 _ _ (b := 16 + 2 * intBitLength (freeStack.length : ℤ)) hr12_4_B2 htop_z hl4 (le_of_eq (by ring)))
            hc_w4 hb_w4
        have hite3 : RunsTo inpSim [.stmt (.ite (.intEq (.readHeap 12 (.lit 4)) (.lit 1))
            (.freeHeap 12 (.lit 4))
            (.writeHeap 12 (.lit 4) (.sub (.readHeap 12 (.lit 4)) (.lit 1))))] stB2 stB3 := by
          apply RunsTo.ite; rw [hcond_eq1]; simp only [decide_eq_false hlen1, Bool.false_eq_true, ↓reduceIte]; exact hr3
        have hw3_eq : stB3.words = (wrapScratch wsCore).write (.heap 12 3) (sNew : ℤ) := by
          rw [hw3]; dsimp [stB2', wsCore]; rw [if_neg hlen1, hwB2_clean]
          dsimp [wrapScratch, wrapScratchA2]
          cases hasScratch2
          · simp only [Bool.false_eq_true, ↓reduceIte]
            rw [wordStore_write_comm (by decide) (sNew : ℤ) _,
                wordStore_write_comm (by decide) e _]
          · simp only [↓reduceIte]
            rw [wordStore_write_comm (by decide) (sNew : ℤ) _,
                wordStore_write_comm (by decide) val _,
                wordStore_write_comm (by decide) e _]
        refine ⟨stB3, hite3, hw3_eq, hfd3, hrb3, ?_, ?_, hpC3, hpB3⟩
        · have : stB2'.unitCost = stB2.unitCost + 4 := rfl; linarith [huc3]
        · have : stB2'.bitCost = stB2.bitCost + (16 + 2 * intBitLength (freeStack.length : ℤ)) := rfl
          rw [h12, hl4] at hbc3; linarith [hbc3]
    obtain ⟨stB3, hrB3, hwB3, hfdB3, hrbB3, hucB3, hbcB3, hpCB3, hpBB3⟩ := hB3_step
    have hwfCore : WellFormedWS wsCore := by
      dsimp [wsCore]; split_ifs
      · exact wellFormedWS_free (wellFormedWS_free hwf10 _) _
      · exact wellFormedWS_write (wellFormedWS_free hwf10 _) _ _
    refine ⟨stB3, wsCore, highSid, freeStack.dropLast, sNew,
      by apply RunsTo.ite; rw [hcond_in]; dsimp only; simp only [↓reduceIte]; exact RunsTo.seq hrB1 (RunsTo.seq hrB2 hrB3),
      hwfCore, hwB3,
      by rw [hfdB3, hfdB2, hfdB1]; dsimp [st0']; exact hst0_fd, by rw [hrbB3, hrbB2, hrbB1]; dsimp [st0']; exact hst0_rb,
      ?_, ?_, hpCB3, hpBB3, ?_, ?_, hhigh_S, hsNew_lt, hsNew_notin, fun h => h.2 (List.getElem_mem htop_lt), hnd_drop,
      fun s' hs' => hinv.free_lt s' (by rw [← hfs_append]; exact List.mem_append_left _ hs'),
      ?_, ?_, ?_, ?_, ?_, ?_⟩
    · have : st0'.unitCost = st0.unitCost + 4 := rfl; linarith [hucB1, hucB2, hucB3]
    · have : st0'.bitCost = st0.bitCost + (14 + 2 * intBitLength (freeStack.length : ℤ)) := rfl
      rw [h12, hl3] at hbcB1; rw [h14] at hbcB2
      linarith [hbcB1, hbcB2, hbcB3, hsNew_bl, hlen_bl, htop_bl]
    · dsimp [wsCore]; split_ifs
      · exact (cellCount_free_le _ _).trans (hc14.trans (by linarith))
      · exact (cellCount_write_le _ _ _).trans (Nat.add_le_add_right hc14 1 |>.trans (by linarith))
    · dsimp [wsCore]; split_ifs
      · exact (bitSize_free_le _ _).trans (hb14.trans (by linarith))
      · have hb4 := bitSize_write_le ws14 (.heap 12 4) (topIdx : ℤ)
        dsimp [RAMCellLoc.bitLength] at hb4; rw [h12, hl4] at hb4; linarith
    · intro s'
      constructor
      · rintro ⟨hlt', hnf'⟩
        by_cases heq : s' = sNew
        · exact Or.inl heq
        · refine Or.inr ⟨hlt', ?_⟩
          rw [← hfs_append, List.mem_append, List.mem_singleton]; simp [hnf', heq]
      · rintro (rfl | ⟨hlt', hnf'⟩)
        · exact ⟨hsNew_lt, hsNew_notin⟩
        · refine ⟨hlt', fun hm => hnf' ?_⟩
          rw [← hfs_append]; exact List.mem_append_left _ hm
    · intro loc h4 h5 h14_ne
      have hne14 : loc ≠ .heap 14 (topIdx : ℤ) := h14_ne (topIdx : ℤ)
      dsimp [wsCore, ws14]
      split_ifs
      · exact ⟨by simp [WordStore.free, h4, hne14],
               by simp [WordStore.free, Function.update_of_ne h4, Function.update_of_ne hne14]⟩
      · exact ⟨by simp [WordStore.write, WordStore.free, h4, hne14],
               by simp [WordStore.write, WordStore.free, Function.update_of_ne h4, Function.update_of_ne hne14]⟩
    · dsimp [wsCore]
      split_ifs with hlen1
      · refine ⟨fun _ => by simp [WordStore.free], ?_⟩
        have hdrop_nil : freeStack.dropLast = [] :=
          List.eq_nil_of_length_eq_zero (by rw [hdrop_len]; dsimp [topIdx]; omega)
        simp [hdrop_nil]
      · have hdrop_ne : freeStack.dropLast ≠ [] := by
          intro hnil
          have := congrArg List.length hnil
          rw [hdrop_len] at this; dsimp [topIdx] at this; omega
        exact ⟨fun h => False.elim (hdrop_ne h), by simp [hdrop_len]⟩
    · dsimp [wsCore]
      split_ifs
      · refine ⟨fun hh => by simp [WordStore.free, ws14, ws10, WordStore.write, hinv.tab12_5.1 hh], ?_⟩
        rw [wordStore_read_free_ne _ (by decide), wordStore_read_free_ne _ (by simp),
            wordStore_read_write_ne _ (by simp)]; exact hinv.tab12_5.2
      · refine ⟨fun hh => by simp [WordStore.write, ws14, WordStore.free, ws10, hinv.tab12_5.1 hh], ?_⟩
        rw [wordStore_read_write_ne _ (by decide), wordStore_read_free_ne _ (by simp),
            wordStore_read_write_ne _ (by simp)]; exact hinv.tab12_5.2
    · intro z
      have hget_drop : ∀ (k : ℕ) (hk : k < freeStack.dropLast.length),
          freeStack.dropLast[k] = freeStack[k]'(by rw [hdrop_len] at hk; dsimp [topIdx] at hk; omega) :=
        fun k hk => List.getElem_dropLast hk
      dsimp [wsCore]
      split_ifs
      · refine ⟨fun hz hlt => ?_, fun hn => ?_⟩
        · rw [hdrop_len] at hlt
          have hne_t : z ≠ (topIdx : ℤ) := by intro h; subst h; simp at hlt
          have h0 := (hinv.tab14_spec z).1 hz (by dsimp [topIdx] at hlt; omega)
          rw [hget_drop z.toNat (by simpa [hdrop_len] using hlt)]
          have hne14 : (.heap 14 z : RAMCellLoc) ≠ .heap 14 (topIdx : ℤ) := by simp [hne_t]
          exact ⟨by simp [WordStore.free, ws14, ws10, WordStore.write, hne_t, h0.1],
                 by simp [WordStore.free, ws14, ws10, WordStore.write, Function.update_of_ne hne14, h0.2]⟩
        · rw [hdrop_len] at hn
          by_cases heq_t : z = (topIdx : ℤ)
          · subst heq_t; simp [WordStore.free, ws14]
          · have hn_old : ¬ (0 ≤ z ∧ z.toNat < freeStack.length) := by
              rintro ⟨hz0, hlt_f⟩; apply hn; refine ⟨hz0, ?_⟩
              dsimp [topIdx]; have : z.toNat ≠ topIdx := fun h => heq_t (by omega)
              omega
            have h0 := (hinv.tab14_spec z).2 hn_old
            simp [WordStore.free, ws14, ws10, WordStore.write, h0]
      · refine ⟨fun hz hlt => ?_, fun hn => ?_⟩
        · rw [hdrop_len] at hlt
          have hne_t : z ≠ (topIdx : ℤ) := by intro h; subst h; simp at hlt
          have h0 := (hinv.tab14_spec z).1 hz (by dsimp [topIdx] at hlt; omega)
          rw [hget_drop z.toNat (by simpa [hdrop_len] using hlt)]
          have hne14 : (.heap 14 z : RAMCellLoc) ≠ .heap 14 (topIdx : ℤ) := by simp [hne_t]
          exact ⟨by simp [WordStore.write, ws14, WordStore.free, ws10, hne_t, h0.1],
                 by simp [WordStore.write, ws14, WordStore.free, ws10, Function.update_of_ne hne14, h0.2]⟩
        · rw [hdrop_len] at hn
          by_cases heq_t : z = (topIdx : ℤ)
          · subst heq_t; simp [WordStore.write, ws14, WordStore.free]
          · have hn_old : ¬ (0 ≤ z ∧ z.toNat < freeStack.length) := by
              rintro ⟨hz0, hlt_f⟩; apply hn; refine ⟨hz0, ?_⟩
              dsimp [topIdx]; have : z.toNat ≠ topIdx := fun h => heq_t (by omega)
              omega
            have h0 := (hinv.tab14_spec z).2 hn_old
            simp [WordStore.write, ws14, WordStore.free, ws10, h0]
    · intro loc hm
      dsimp [wsCore] at hm
      split_ifs at hm
      · simp only [WordStore.free, ws14, Finset.mem_erase] at hm
        exact Or.inl hm.2.2
      · simp only [WordStore.write, ws14, WordStore.free, Finset.mem_insert, Finset.mem_erase] at hm
        rcases hm with rfl | ⟨_, hm'⟩
        · exact Or.inr (Or.inl rfl)
        · exact Or.inl hm'


private theorem a2SimInv_after_miss
    {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim wsCore : WordStore} {highSid highSid' sNew : ℕ}
    {sidOfEnc : ℤ → Option ℕ} {encOfSid : ℕ → ℤ} {freeStack freeStack' : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    {table : ℕ} (ht : table < T_max) (idx val : ℤ)
    (hsid : sidOfEnc (idx * (T_max : ℤ) + (table : ℤ)) = none)
    (hwfCore : WellFormedWS wsCore)
    (hhigh_le' : highSid' ≤ S_max)
    (hsNew_lt' : sNew < highSid')
    (hsNew_nf' : sNew ∉ freeStack')
    (hsNew_not_old : ¬ (sNew < highSid ∧ sNew ∉ freeStack))
    (hnd' : freeStack'.Nodup)
    (hfree_lt' : ∀ s' ∈ freeStack', s' < highSid')
    (hact_equiv : ∀ s' : ℕ, (s' < highSid' ∧ s' ∉ freeStack') ↔ (s' = sNew ∨ (s' < highSid ∧ s' ∉ freeStack)))
    (hCoreOther : ∀ loc, loc ≠ .heap 12 4 → loc ≠ .heap 12 5 → (∀ z, loc ≠ .heap 14 z) →
      (loc ∈ wsCore.live ↔ loc ∈ (wsSim.write (.heap 10 (idx * (T_max : ℤ) + (table : ℤ))) val).live) ∧
      wsCore.vals loc = (wsSim.write (.heap 10 (idx * (T_max : ℤ) + (table : ℤ))) val).vals loc)
    (hCore12_4 : (freeStack' = [] → (.heap 12 4 : RAMCellLoc) ∉ wsCore.live) ∧
      wsCore.read (.heap 12 4) = (freeStack'.length : ℤ))
    (hCore12_5 : (highSid' = 0 → (.heap 12 5 : RAMCellLoc) ∉ wsCore.live) ∧
      wsCore.read (.heap 12 5) = (highSid' : ℤ))
    (hCore14 : ∀ z : ℤ,
      (∀ (_hz : 0 ≤ z) (hlt : z.toNat < freeStack'.length),
        (.heap 14 z : RAMCellLoc) ∈ wsCore.live ∧
        wsCore.vals (.heap 14 z) = (freeStack'[z.toNat] : ℤ)) ∧
      (¬ (0 ≤ z ∧ z.toNat < freeStack'.length) → (.heap 14 z : RAMCellLoc) ∉ wsCore.live))
    (hCoreCases : ∀ loc ∈ wsCore.live,
      loc ∈ (wsSim.write (.heap 10 (idx * (T_max : ℤ) + (table : ℤ))) val).live ∨
      loc = .heap 12 4 ∨ loc = .heap 12 5) :
    let e := idx * (T_max : ℤ) + (table : ℤ)
    let wsFin := ((wsCore.write (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)).write (.heap 15 (sNew : ℤ)) e).write (.heap 16 (sNew : ℤ)) 1
    A2SimInv wsBase T_max S_max (wsSub.write (.heap table idx) val) wsFin
      highSid' (Function.update sidOfEnc e (some sNew)) (Function.update encOfSid sNew e) freeStack' := by
  intro e wsFin
  set ws10 := wsSim.write (.heap 10 e) val
  change sidOfEnc e = none at hsid
  change ∀ loc, loc ≠ .heap 12 4 → loc ≠ .heap 12 5 → (∀ z, loc ≠ .heap 14 z) →
    (loc ∈ wsCore.live ↔ loc ∈ ws10.live) ∧ wsCore.vals loc = ws10.vals loc at hCoreOther
  change ∀ loc ∈ wsCore.live, loc ∈ ws10.live ∨ loc = .heap 12 4 ∨ loc = .heap 12 5 at hCoreCases
  have hwf10 : WellFormedWS ws10 := wellFormedWS_write hinv.wfSim _ _
  have hwfFin : WellFormedWS wsFin :=
    wellFormedWS_write (wellFormedWS_write (wellFormedWS_write hwfCore _ _) _ _) _ _
  set sidOfEnc' := Function.update sidOfEnc e (some sNew)
  set encOfSid' := Function.update encOfSid sNew e
  have hCore_non12_14_read : ∀ (t' : ℕ) (i' : ℤ), t' ≠ 12 → t' ≠ 14 →
      wsCore.read (.heap t' i') = ws10.read (.heap t' i') := by
    intro t' i' ht12 ht14
    rw [wordStore_read_eq_vals hwfCore, wordStore_read_eq_vals hwf10]
    exact (hCoreOther (.heap t' i') (by simp [ht12]) (by simp [ht12]) (by simp [ht14])).2
  refine
    { wfBase := hinv.wfBase
      wfSub := wellFormedWS_write hinv.wfSub _ _
      wfSim := hwfFin
      hT := hinv.hT
      high_le := hhigh_le'
      sub_tables := fun t' i' hm => by
        simp only [WordStore.write, Finset.mem_insert, RAMCellLoc.heap.injEq] at hm
        rcases hm with ⟨rfl, rfl⟩ | hm'
        · exact ht
        · exact hinv.sub_tables t' i' hm'
      base_live := fun loc hb => by
        have hne13 : loc ≠ .heap 13 e := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne15 : loc ≠ .heap 15 (sNew : ℤ) := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne16 : loc ≠ .heap 16 (sNew : ℤ) := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne10 : loc ≠ .heap 10 e := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne12_4 : loc ≠ .heap 12 4 := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne12_5 : loc ≠ .heap 12 5 := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne14 : ∀ z, loc ≠ .heap 14 z := by intro z h; subst h; simp [IsA2BaseLoc] at hb
        simp only [wsFin, WordStore.write, Finset.mem_insert, hne16, hne15, hne13, false_or]
        rw [(hCoreOther loc hne12_4 hne12_5 hne14).1]
        simp [ws10, WordStore.write, hne10, hinv.base_live loc hb]
      base_vals := fun loc hb => by
        have hne13 : loc ≠ .heap 13 e := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne15 : loc ≠ .heap 15 (sNew : ℤ) := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne16 : loc ≠ .heap 16 (sNew : ℤ) := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne10 : loc ≠ .heap 10 e := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne12_4 : loc ≠ .heap 12 4 := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne12_5 : loc ≠ .heap 12 5 := by intro h; subst h; simp [IsA2BaseLoc] at hb
        have hne14 : ∀ z, loc ≠ .heap 14 z := by intro z h; subst h; simp [IsA2BaseLoc] at hb
        simp only [wsFin, WordStore.write, Function.update_of_ne hne16,
          Function.update_of_ne hne15, Function.update_of_ne hne13]
        rw [(hCoreOther loc hne12_4 hne12_5 hne14).2]
        simp [ws10, WordStore.write, Function.update_of_ne hne10, hinv.base_vals loc hb]
      local_live := fun d' v' i' => by
        simp only [wsFin, WordStore.write, Finset.mem_insert, reduceCtorEq, false_or]
        rw [(hCoreOther _ (by simp) (by simp) (by simp)).1]
        simp [ws10, WordStore.write, hinv.local_live d' v' i']
      local_vals := fun d' v' i' => by
        have hne16 : (.localFrame (2 + d') v' i' : RAMCellLoc) ≠ .heap 16 (sNew : ℤ) := by simp
        have hne15 : (.localFrame (2 + d') v' i' : RAMCellLoc) ≠ .heap 15 (sNew : ℤ) := by simp
        have hne13 : (.localFrame (2 + d') v' i' : RAMCellLoc) ≠ .heap 13 e := by simp
        simp only [wsFin, WordStore.write, Function.update_of_ne hne16, Function.update_of_ne hne15, Function.update_of_ne hne13]
        rw [(hCoreOther _ (by simp) (by simp) (by simp)).2]
        simp [ws10, WordStore.write, hinv.local_vals d' v' i']
      tab10_live := fun e' => by
        simp only [wsFin, WordStore.write, Finset.mem_insert, RAMCellLoc.heap.injEq, (by decide : (10 : ℕ) ≠ 16), (by decide : (10 : ℕ) ≠ 15), (by decide : (10 : ℕ) ≠ 13), false_and, false_or]
        rw [(hCoreOther (.heap 10 e') (by simp) (by simp) (by simp)).1]
        simp only [ws10, WordStore.write, Finset.mem_insert, RAMCellLoc.heap.injEq, true_and]
        constructor
        · rintro (rfl | hm')
          · exact ⟨table, ht, idx, rfl, Or.inl ⟨rfl, rfl⟩⟩
          · obtain ⟨t', ht', i', rfl, hm_sub⟩ := (hinv.tab10_live e').mp hm'
            exact ⟨t', ht', i', rfl, Or.inr hm_sub⟩
        · rintro ⟨t', ht', i', rfl, ⟨rfl, rfl⟩ | hm_sub⟩
          · exact Or.inl rfl
          · exact Or.inr ((hinv.tab10_live _).mpr ⟨t', ht', i', rfl, hm_sub⟩)
      tab10_read := fun t' ht' i' => by
        rw [wordStore_read_write_ne _ (by simp), wordStore_read_write_ne _ (by simp),
            wordStore_read_write_ne _ (by simp),
            hCore_non12_14_read 10 _ (by decide) (by decide)]
        by_cases heq : t' = table ∧ i' = idx
        · rcases heq with ⟨rfl, rfl⟩; simp [ws10, e]
        · have hne_e : i' * (T_max : ℤ) + (t' : ℤ) ≠ e := fun hh => heq (encA2_inj ht' ht hh)
          rw [wordStore_read_write_ne _ (by simp [hne_e]),
              wordStore_read_write_ne _ (by simp [heq])]
          exact hinv.tab10_read t' ht' i'
      free_nodup := hnd'
      free_lt := hfree_lt'
      active_iff := fun e' => by
        simp only [wsFin, WordStore.write, Finset.mem_insert, RAMCellLoc.heap.injEq, (by decide : (10 : ℕ) ≠ 16), (by decide : (10 : ℕ) ≠ 15), (by decide : (10 : ℕ) ≠ 13), false_and, false_or]
        rw [(hCoreOther (.heap 10 e') (by simp) (by simp) (by simp)).1]
        simp only [ws10, WordStore.write, Finset.mem_insert, RAMCellLoc.heap.injEq, true_and, sidOfEnc']
        by_cases heq : e' = e
        · subst heq; simp
        · dsimp only [sidOfEnc']; simp [heq, hinv.active_iff e']
      sid_lt := fun e' s' hs' => by
        dsimp only [sidOfEnc'] at hs'
        by_cases heq : e' = e
        · subst heq; simp only [Function.update_self, Option.some.injEq] at hs'
          subst hs'
          exact ⟨hsNew_lt', hsNew_nf', by simp [encOfSid']⟩
        · rw [Function.update_of_ne heq] at hs'
          obtain ⟨hs1, hs2, hs3⟩ := hinv.sid_lt e' s' hs'
          have hne_s : s' ≠ sNew := fun hss => hsNew_not_old (hss ▸ ⟨hs1, hs2⟩)
          obtain ⟨hs1', hs2'⟩ := (hact_equiv s').mpr (Or.inr ⟨hs1, hs2⟩)
          exact ⟨hs1', hs2', by simp [encOfSid', Function.update_of_ne hne_s, hs3]⟩
      enc_sid := fun s' hs1' hs2' => by
        rcases (hact_equiv s').mp ⟨hs1', hs2'⟩ with heq_s | ⟨hs1, hs2⟩
        · subst heq_s
          show Function.update sidOfEnc e (some s') (Function.update encOfSid s' e s') = some s'
          rw [Function.update_self, Function.update_self]
        · have hne_s : s' ≠ sNew := fun hss => hsNew_not_old (hss ▸ ⟨hs1, hs2⟩)
          have h0 := hinv.enc_sid s' hs1 hs2
          have hne_e : encOfSid s' ≠ e := fun hh => by rw [hh, hsid] at h0; cases h0
          show Function.update sidOfEnc e (some sNew) (Function.update encOfSid sNew e s') = some s'
          rw [Function.update_of_ne hne_s, Function.update_of_ne hne_e, h0]
      tab12_4 := ⟨fun hf => by simp [wsFin, WordStore.write, hCore12_4.1 hf],
        by rw [wordStore_read_write_ne _ (by simp), wordStore_read_write_ne _ (by simp),
               wordStore_read_write_ne _ (by simp)]; exact hCore12_4.2⟩
      tab12_5 := ⟨fun hh => by simp [wsFin, WordStore.write, hCore12_5.1 hh],
        by rw [wordStore_read_write_ne _ (by simp), wordStore_read_write_ne _ (by simp),
               wordStore_read_write_ne _ (by simp)]; exact hCore12_5.2⟩
      tab12_other := fun i h4 h5 => by
        have hc_not : (.heap 12 i : RAMCellLoc) ∉ wsCore.live := by
          rw [(hCoreOther (.heap 12 i) (by simp [h4]) (by simp [h5]) (by simp)).1]
          simp [ws10, WordStore.write, hinv.tab12_other i h4 h5]
        simp [wsFin, WordStore.write, hc_not]
      tab13_spec := fun e' => by
        by_cases heq : e' = e
        · subst heq
          refine ⟨fun s' hs' => ?_, fun hn => by simp [sidOfEnc'] at hn⟩
          simp only [sidOfEnc', Function.update_self, Option.some.injEq] at hs'
          subst hs'
          exact ⟨by simp [wsFin, WordStore.write],
                 by simp [wsFin, WordStore.write]⟩
        · simp only [sidOfEnc', Function.update_of_ne heq]
          have hc13 := hCoreOther (.heap 13 e') (by simp) (by simp) (by simp)
          refine ⟨fun s' hs' => ?_, fun hn => ?_⟩
          · have h0 := (hinv.tab13_spec e').1 s' hs'
            have hm_c : (.heap 13 e' : RAMCellLoc) ∈ wsCore.live := by
              rw [hc13.1]; simp [ws10, WordStore.write, h0.1]
            have hv_c : wsCore.vals (.heap 13 e') = ((s' + 1 : ℕ) : ℤ) := by
              rw [hc13.2]; simp [ws10, WordStore.write, h0.2]
            exact ⟨by simp [wsFin, WordStore.write, heq, hm_c],
                   by simp [wsFin, WordStore.write, heq, hv_c]⟩
          · have h0 := (hinv.tab13_spec e').2 hn
            have hm_c : (.heap 13 e' : RAMCellLoc) ∉ wsCore.live := by
              rw [hc13.1]; simp [ws10, WordStore.write, h0]
            simp [wsFin, WordStore.write, heq, hm_c]
      tab14_spec := fun z =>
        ⟨fun hz hlt =>
          let h0 := (hCore14 z).1 hz hlt
          ⟨by simp [wsFin, WordStore.write, h0.1],
           by simp [wsFin, WordStore.write, h0.2]⟩,
         fun hn => by simp [wsFin, WordStore.write, (hCore14 z).2 hn]⟩
      tab15_16_spec := fun z => by
        have hc15 := hCoreOther (.heap 15 z) (by simp) (by simp) (by simp)
        have hc16 := hCoreOther (.heap 16 z) (by simp) (by simp) (by simp)
        by_cases heq_z : z = (sNew : ℤ)
        · subst heq_z
          have hz_ok : 0 ≤ (sNew : ℤ) ∧ (sNew : ℤ).toNat < highSid' ∧ (sNew : ℤ).toNat ∉ freeStack' := by
            simp [hsNew_lt', hsNew_nf']
          refine ⟨fun _ => ?_, fun hn => False.elim (hn hz_ok)⟩
          simp [wsFin, WordStore.write, encOfSid']
        · refine ⟨fun h => ?_, fun hn => ?_⟩
          · rcases h with ⟨hz0, hlt', hnf'⟩
            have hne_sn : z.toNat ≠ sNew := fun hh => heq_z (by omega)
            rcases (hact_equiv z.toNat).mp ⟨hlt', hnf'⟩ with h_eq | ⟨hlt, hnf⟩
            · exact False.elim (hne_sn h_eq)
            · have h0 := (hinv.tab15_16_spec z).1 ⟨hz0, hlt, hnf⟩
              have hm15 : (.heap 15 z : RAMCellLoc) ∈ wsCore.live := by
                rw [hc15.1]; simp [ws10, WordStore.write, h0.1]
              have hv15 : wsCore.vals (.heap 15 z) = encOfSid' z.toNat := by
                rw [hc15.2]; simp [ws10, WordStore.write, encOfSid', Function.update_of_ne hne_sn, h0.2.1]
              have hm16 : (.heap 16 z : RAMCellLoc) ∈ wsCore.live := by
                rw [hc16.1]; simp [ws10, WordStore.write, h0.2.2.1]
              have hv16 : wsCore.vals (.heap 16 z) = 1 := by
                rw [hc16.2]; simp [ws10, WordStore.write, h0.2.2.2]
              exact ⟨by simp [wsFin, WordStore.write, heq_z, hm15],
                     by simp [wsFin, WordStore.write, heq_z, hv15],
                     by simp [wsFin, WordStore.write, heq_z, hm16],
                     by simp [wsFin, WordStore.write, heq_z, hv16]⟩
          · have hn_old : ¬ (0 ≤ z ∧ z.toNat < highSid ∧ z.toNat ∉ freeStack) := by
              rintro ⟨hz0, hlt, hnf⟩
              apply hn
              obtain ⟨hlt', hnf'⟩ := (hact_equiv z.toNat).mpr (Or.inr ⟨hlt, hnf⟩)
              exact ⟨hz0, hlt', hnf'⟩
            have h0 := (hinv.tab15_16_spec z).2 hn_old
            have hm15 : (.heap 15 z : RAMCellLoc) ∉ wsCore.live := by
              rw [hc15.1]; simp [ws10, WordStore.write, h0.1]
            have hm16 : (.heap 16 z : RAMCellLoc) ∉ wsCore.live := by
              rw [hc16.1]; simp [ws10, WordStore.write, h0.2]
            exact ⟨by simp [wsFin, WordStore.write, heq_z, hm15],
                   by simp [wsFin, WordStore.write, heq_z, hm16]⟩
      live_cases := fun loc hm => by
        simp only [wsFin, WordStore.write, Finset.mem_insert] at hm
        rcases hm with rfl | rfl | rfl | hmCore
        · exact Or.inr (Or.inr ⟨16, (sNew : ℤ), Or.inr (Or.inr (Or.inr (Or.inr (Or.inr rfl)))), rfl⟩)
        · exact Or.inr (Or.inr ⟨15, (sNew : ℤ), Or.inr (Or.inr (Or.inr (Or.inr (Or.inl rfl)))), rfl⟩)
        · exact Or.inr (Or.inr ⟨13, e, Or.inr (Or.inr (Or.inl rfl)), rfl⟩)
        · rcases hCoreCases loc hmCore with hm10 | rfl | rfl
          · simp only [ws10, WordStore.write, Finset.mem_insert] at hm10
            rcases hm10 with rfl | hmSim
            · exact Or.inr (Or.inr ⟨10, e, Or.inl rfl, rfl⟩)
            · exact hinv.live_cases loc hmSim
          · exact Or.inr (Or.inr ⟨12, 4, Or.inr (Or.inl rfl), rfl⟩)
          · exact Or.inr (Or.inr ⟨12, 5, Or.inr (Or.inl rfl), rfl⟩) }

theorem exec_trA2LogInsertAfterWrite {d : ℕ} (inpSim : BitRAMInput d)
    {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    {table : ℕ} (ht : table < T_max) (idx val : ℤ)
    (hasScratch2 : Bool)
    (hSubCell : (wsSub.write (.heap table idx) val).cellCount ≤ S_max)
    {subPeakCell subPeakBit : ℕ}
    (hcPeak : wsSub.cellCount ≤ subPeakCell)
    (hbPeak : wsSub.bitSize ≤ subPeakBit)
    (hbPeak' : (wsSub.write (.heap table idx) val).bitSize ≤ subPeakBit)
    (stMid : BitRAMExecState)
    (hwMid : stMid.words =
      let w1 := wsSim.write (.heap 12 1) (idx * (T_max : ℤ) + (table : ℤ))
      let w2 := if hasScratch2 then w1.write (.heap 12 2) val else w1
      w2.write (.heap 10 (idx * (T_max : ℤ) + (table : ℤ))) val)
    (hpC : stMid.peakCellSpace ≤ a2CellBound wsBase inpSim S_max subPeakCell)
    (hpB : stMid.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit) :
    let e := idx * (T_max : ℤ) + (table : ℤ)
    let S_bits := natBitLength S_max + 4
    ∃ stEnd : BitRAMExecState, ∃ highSid' sidOfEnc' encOfSid' freeStack',
      RunsTo inpSim [.stmt trA2LogInsertAfterWrite] stMid stEnd ∧
      A2SimInv wsBase T_max S_max (wsSub.write (.heap table idx) val) stEnd.words
        highSid' sidOfEnc' encOfSid' freeStack' ∧
      stEnd.frameDepth = stMid.frameDepth ∧
      stEnd.remainingBits = stMid.remainingBits ∧
      stEnd.unitCost ≤ stMid.unitCost + 56 ∧
      stEnd.bitCost ≤ stMid.bitCost + 8 * intBitLength e + 24 * S_bits + 240 ∧
      stEnd.peakCellSpace ≤ a2CellBound wsBase inpSim S_max subPeakCell ∧
      stEnd.peakBitSpace ≤ a2BitBound wsBase inpSim T_max S_max subPeakBit := by
  intro e S_bits
  set C_cell := a2CellBound wsBase inpSim S_max subPeakCell
  set C_bit := a2BitBound wsBase inpSim T_max S_max subPeakBit
  obtain ⟨hHeadCell, hHeadBit⟩ := hinv.within_bounds inpSim hcPeak hbPeak
  change inpSim.inputCellSpace + wsSim.cellCount + 12 ≤ C_cell at hHeadCell
  change inpSim.inputBitSpace + wsSim.bitSize + 12 * subPeakBit + 16 * natBitLength T_max + 20 * S_bits + 200 ≤ C_bit at hHeadBit
  have hSb4 : 4 ≤ S_bits := by dsimp [S_bits]; omega
  have he_bl : intBitLength e ≤ intBitLength idx + natBitLength T_max + 4 :=
    intBitLength_encA2_le ht idx
  have hmem_sub' : (.heap table idx : RAMCellLoc) ∈ (wsSub.write (.heap table idx) val).live := by
    simp [WordStore.write]
  have hidx_val_bl : natBitLength table + intBitLength idx + intBitLength val ≤ subPeakBit := by
    have hm := mem_live_bitLength_le hmem_sub'
    simp only [WordStore.write, Function.update_self, RAMCellLoc.bitLength] at hm
    exact hm.trans hbPeak'
  have he_sub : intBitLength e ≤ subPeakBit + natBitLength T_max + 4 := by linarith
  have hsid_bl : ∀ s : ℕ, s ≤ S_max → intBitLength (s : ℤ) ≤ S_bits := by
    intro s hs
    have h1 := intBitLength_ofNat_le s
    have h2 := natBitLength_mono hs
    dsimp [S_bits]; linarith
  have hn12_1 : (.heap 12 1 : RAMCellLoc) ∉ wsSim.live := hinv.tab12_other 1 (by decide) (by decide)
  have hn12_2 : (.heap 12 2 : RAMCellLoc) ∉ wsSim.live := hinv.tab12_other 2 (by decide) (by decide)
  have hn12_3 : (.heap 12 3 : RAMCellLoc) ∉ wsSim.live := hinv.tab12_other 3 (by decide) (by decide)
  set ws10 := wsSim.write (.heap 10 e) val
  have hwf10 : WellFormedWS ws10 := wellFormedWS_write hinv.wfSim _ _
  let wrapScratch := wrapScratchA2 hasScratch2 e val
  have hwMid_eq : stMid.words = wrapScratch ws10 := by
    rw [hwMid]
    dsimp only [wrapScratch, wrapScratchA2, ws10, e]
    cases hasScratch2
    · simp only [Bool.false_eq_true, ↓reduceIte]; exact wordStore_write_comm (by simp) e val
    · simp only [↓reduceIte]
      rw [wordStore_write_comm (ws := wsSim.write (.heap 12 1) e) (by simp) val val,
          wordStore_write_comm (ws := wsSim) (by simp) e val]
  have hwrap_read_ne : ∀ (w : WordStore) (loc : RAMCellLoc),
      loc ≠ .heap 12 1 → loc ≠ .heap 12 2 → (wrapScratch w).read loc = w.read loc := by
    intro w loc h1 h2
    dsimp [wrapScratch, wrapScratchA2]
    cases hasScratch2
    · simp only [Bool.false_eq_true, ↓reduceIte]; exact wordStore_read_write_ne w h1 e
    · simp only [↓reduceIte]
      rw [wordStore_read_write_ne _ h2 val, wordStore_read_write_ne _ h1 e]
  have hwrap_read_12_1 : ∀ w : WordStore, (wrapScratch w).read (.heap 12 1) = e := by
    intro w
    dsimp [wrapScratch, wrapScratchA2]
    cases hasScratch2
    · simp
    · simp only [↓reduceIte]; rw [wordStore_read_write_ne _ (by decide) val]; simp
  have hwrap_size : ∀ w : WordStore,
      (wrapScratch w).cellCount ≤ w.cellCount + 2 ∧
      (wrapScratch w).bitSize ≤ w.bitSize + 2 * subPeakBit + natBitLength T_max + 20 := by
    intro w
    dsimp [wrapScratch, wrapScratchA2]
    have hn12 : natBitLength 12 = 4 := by decide
    have hl1 : intBitLength (1 : ℤ) = 2 := by decide
    have hl2 : intBitLength (2 : ℤ) = 3 := by decide
    have hc1 := cellCount_write_le w (.heap 12 1) e
    have hb1 := bitSize_write_le w (.heap 12 1) e
    dsimp [RAMCellLoc.bitLength] at hb1; rw [hn12, hl1] at hb1
    cases hasScratch2
    · simp only [Bool.false_eq_true, ↓reduceIte]
      exact ⟨by linarith, by linarith⟩
    · simp only [↓reduceIte]
      have hc2 := cellCount_write_le (w.write (.heap 12 1) e) (.heap 12 2) val
      have hb2 := bitSize_write_le (w.write (.heap 12 1) e) (.heap 12 2) val
      dsimp [RAMCellLoc.bitLength] at hb2; rw [hn12, hl2] at hb2
      exact ⟨by linarith, by linarith⟩
  have hwrap_free : ∀ (w : WordStore), WellFormedWS w →
      (.heap 12 1 : RAMCellLoc) ∉ w.live → (.heap 12 2 : RAMCellLoc) ∉ w.live →
      ((wrapScratch w).free (.heap 12 1)).free (.heap 12 2) = w := by
    intro w hwf hn1 hn2
    dsimp [wrapScratch, wrapScratchA2]
    cases hasScratch2
    · simp only [Bool.false_eq_true, ↓reduceIte]
      rw [wordStore_free_write_self hwf hn1, wordStore_free_of_not_mem hwf hn2]
    · simp only [↓reduceIte]
      rw [wordStore_free_write_comm (by decide) val,
          wordStore_free_write_self hwf hn1,
          wordStore_free_write_self hwf hn2]
  have hr12_1 : stMid.words.read (.heap 12 1) = e := by rw [hwMid_eq]; exact hwrap_read_12_1 ws10
  have hr13_mid : stMid.words.read (.heap 13 e) = wsSim.read (.heap 13 e) := by
    rw [hwMid_eq, hwrap_read_ne ws10 _ (by simp) (by simp)]
    exact wordStore_read_write_ne wsSim (by simp) val
  have hcond_eq : evalBitCond inpSim stMid.frameDepth stMid.words
      (.intEq (.readHeap 13 (.readHeap 12 (.lit 1))) (.lit 0)) =
      (decide (wsSim.read (.heap 13 e) = 0), 5,
       2 + 4 + 2 + intBitLength e + 4 + intBitLength e + intBitLength (wsSim.read (.heap 13 e)) + 1 +
         intBitLength (wsSim.read (.heap 13 e)) + 1) := by
    have hl0 : intBitLength (0 : ℤ) = 1 := by decide
    have hl1 : intBitLength (1 : ℤ) = 2 := by decide
    have hn12 : natBitLength 12 = 4 := by decide
    have hn13 : natBitLength 13 = 4 := by decide
    simp only [evalBitCond, evalIntExpr, hr12_1, hr13_mid, hl0, hl1, hn12, hn13]
  cases hsid : sidOfEnc e with
  | some s =>
      have h13_s := (hinv.tab13_spec e).1 s hsid
      have hr13_val : wsSim.read (.heap 13 e) = ((s + 1 : ℕ) : ℤ) := by
        rw [wordStore_read_eq_vals hinv.wfSim]; exact h13_s.2
      have hne0 : wsSim.read (.heap 13 e) ≠ 0 := by rw [hr13_val]; omega
      have hs_lt : s < highSid := (hinv.sid_lt e s hsid).1
      have hr13_bl : intBitLength (wsSim.read (.heap 13 e)) ≤ S_bits := by
        rw [hr13_val]; exact hsid_bl (s + 1) (by have := hinv.high_le; omega)
      let st1 : BitRAMExecState :=
        { stMid with
          unitCost := stMid.unitCost + 5 + 1
          bitCost := stMid.bitCost +
            (2 + 4 + 2 + intBitLength e + 4 + intBitLength e + intBitLength (wsSim.read (.heap 13 e)) + 1 +
              intBitLength (wsSim.read (.heap 13 e)) + 1) + 1 }
      obtain ⟨st2, hf1, hw2, hfd2, hrb2, huc2, hbc2, hpC2, hpB2⟩ :=
        exec_freeHeap_ceil inpSim 12 (.lit 1) st1 hpC hpB (idx := 1) (u₁ := 1) (b₁ := 2) (evalIntLe_lit _ _ _ _ (by decide))
      obtain ⟨st3, hf2, hw3, hfd3, hrb3, huc3, hbc3, hpC3, hpB3⟩ :=
        exec_freeHeap_ceil inpSim 12 (.lit 2) st2 hpC2 hpB2 (idx := 2) (u₁ := 1) (b₁ := 3) (evalIntLe_lit _ _ _ _ (by decide))
      have htot : RunsTo inpSim [.stmt trA2LogInsertAfterWrite] stMid st3 := by
        refine RunsTo.seq ?_ (RunsTo.seq hf1 hf2)
        apply RunsTo.ite
        rw [hcond_eq]
        simp only [decide_eq_false hne0, Bool.false_eq_true, ↓reduceIte]
        exact RunsTo.skip inpSim _
      have hw3_eq : st3.words = ws10 := by
        rw [hw3, hw2]; change (stMid.words.free (.heap 12 1)).free (.heap 12 2) = ws10
        rw [hwMid_eq]
        exact hwrap_free ws10 hwf10
          (by simp [ws10, WordStore.write, hn12_1])
          (by simp [ws10, WordStore.write, hn12_2])
      have hinv' : A2SimInv wsBase T_max S_max (wsSub.write (.heap table idx) val) ws10
          highSid sidOfEnc encOfSid freeStack :=
        a2SimInv_after_hit hinv ht idx val hsid
      rw [← hw3_eq] at hinv'
      refine ⟨st3, highSid, sidOfEnc, encOfSid, freeStack, htot, hinv',
        hfd3.trans hfd2, hrb3.trans hrb2, ?_, ?_, hpC3, hpB3⟩
      · have : st1.unitCost = stMid.unitCost + 6 := rfl
        linarith [huc3, huc2]
      · have h1_bc : st1.bitCost = stMid.bitCost +
            (2 + 4 + 2 + intBitLength e + 4 + intBitLength e + intBitLength (wsSim.read (.heap 13 e)) + 1 +
              intBitLength (wsSim.read (.heap 13 e)) + 1) + 1 := rfl
        have hn12 : natBitLength 12 = 4 := by decide
        have hl1 : intBitLength (1 : ℤ) = 2 := by decide
        have hl2 : intBitLength (2 : ℤ) = 3 := by decide
        rw [hn12, hl1] at hbc2; rw [hn12, hl2] at hbc3
        linarith [hbc3, hbc2, h1_bc, hr13_bl]
  | none =>
      have hn13_e : (.heap 13 e : RAMCellLoc) ∉ wsSim.live := (hinv.tab13_spec e).2 hsid
      have hr13_val : wsSim.read (.heap 13 e) = 0 := by simp [WordStore.read, hn13_e]
      have hn10_old : (.heap 10 e : RAMCellLoc) ∉ wsSim.live := by
        intro hm; have := (hinv.active_iff e).mp hm; simp [hsid] at this
      have hnSub_old : (.heap table idx : RAMCellLoc) ∉ wsSub.live := by
        intro hm; exact hn10_old ((hinv.tab10_live e).mpr ⟨table, ht, idx, rfl, hm⟩)
      have hc10 : ws10.cellCount ≤ wsSim.cellCount + 1 := cellCount_write_le _ _ _
      have hb10 : ws10.bitSize ≤ wsSim.bitSize + subPeakBit + natBitLength T_max + 10 := by
        have h := bitSize_write_le wsSim (.heap 10 e) val
        have hn10 : natBitLength 10 = 4 := by decide
        dsimp [RAMCellLoc.bitLength] at h; rw [hn10] at h; linarith
      -- State right after outer `.ite` evaluates `.readHeap 13 ... == 0` to `true`
      let st0 : BitRAMExecState :=
        { stMid with
          unitCost := stMid.unitCost + 5
          bitCost := stMid.bitCost + (2 + 4 + 2 + intBitLength e + 4 + intBitLength e + 1 + 1 + 1 + 1) }
      have hr12_4_mid : stMid.words.read (.heap 12 4) = (freeStack.length : ℤ) := by
        rw [hwMid_eq, hwrap_read_ne ws10 _ (by decide) (by decide)]
        rw [wordStore_read_write_ne _ (by simp) val]; exact hinv.tab12_4.2
      have hr12_5_mid : stMid.words.read (.heap 12 5) = (highSid : ℤ) := by
        rw [hwMid_eq, hwrap_read_ne ws10 _ (by decide) (by decide)]
        rw [wordStore_read_write_ne _ (by simp) val]; exact hinv.tab12_5.2
      have he_val_sub : intBitLength e + intBitLength val ≤ subPeakBit + natBitLength T_max + 4 := by linarith only [he_bl, hidx_val_bl]
      have hval_bl : intBitLength val ≤ subPeakBit := by linarith only [hidx_val_bl]
      obtain ⟨stA, wsCore, highSid', freeStack', sNew, hrAlloc, hwfCore, hwA, hfdA, hrbA,
        hucA, hbcA, hpCA, hpBA, hcCore, hbCore, hhigh_le', hsNew_lt', hsNew_nf', hsNew_not_old,
        hnd', hfree_lt', hact_equiv, hCoreOther, hCore12_4, hCore12_5, hCore14, hCoreCases⟩ :=
        exec_trA2AllocSid inpSim hinv idx val hasScratch2 hSubCell hnSub_old
          hHeadCell hHeadBit he_val_sub hval_bl stMid st0 hwMid_eq rfl rfl rfl rfl rfl hpC hpB
      change stA.words = (wrapScratch wsCore).write (.heap 12 3) (sNew : ℤ) at hwA
      change stA.bitCost ≤ st0.bitCost + 16 * S_bits + 112 at hbcA
      change wsCore.bitSize ≤ wsSim.bitSize + subPeakBit + natBitLength T_max + 2 * S_bits + 24 at hbCore
      have hsNew_bl : intBitLength (sNew : ℤ) ≤ S_bits := hsid_bl sNew (by linarith)
      have hsNew1_bl : intBitLength ((sNew + 1 : ℕ) : ℤ) ≤ S_bits := hsid_bl (sNew + 1) (by linarith)
      have h12 : natBitLength 12 = 4 := by decide
      have h13 : natBitLength 13 = 4 := by decide
      have h15 : natBitLength 15 = 4 := by decide
      have h16 : natBitLength 16 = 5 := by decide
      have hl1 : intBitLength (1 : ℤ) = 2 := by decide
      have hl2 : intBitLength (2 : ℤ) = 3 := by decide
      have hl3 : intBitLength (3 : ℤ) = 3 := by decide
      obtain ⟨hw_scCoreC, hw_scCoreB⟩ := hwrap_size wsCore
      -- Step T1: `.writeHeap 13 (.readHeap 12 (.lit 1)) (.add (.readHeap 12 (.lit 3)) (.lit 1))`
      have hrA_12_1 : stA.words.read (.heap 12 1) = e := by
        rw [hwA, wordStore_read_write_ne _ (by decide)]; exact hwrap_read_12_1 wsCore
      have hrA_12_3 : stA.words.read (.heap 12 3) = (sNew : ℤ) := by rw [hwA]; simp
      have hcT1 : inpSim.inputCellSpace + (stA.words.write (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)).cellCount ≤ C_cell := by
        have h1 := cellCount_write_le stA.words (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)
        have h2 := cellCount_write_le (wrapScratch wsCore) (.heap 12 3) (sNew : ℤ)
        dsimp only [wrapScratch] at h2; rw [hwA] at h1 ⊢; linarith
      have hbT1 : inpSim.inputBitSpace + (stA.words.write (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)).bitSize ≤ C_bit := by
        have h1 := bitSize_write_le stA.words (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)
        have h2 := bitSize_write_le (wrapScratch wsCore) (.heap 12 3) (sNew : ℤ)
        dsimp only [RAMCellLoc.bitLength] at h1 h2; rw [h13] at h1; rw [h12, hl3] at h2
        rw [hwA] at h1 ⊢; linarith
      obtain ⟨stT1, hrT1, hwT1, hfdT1, hrbT1, hucT1, hbcT1, hpCT1, hpBT1⟩ :=
        exec_writeHeap_ceil inpSim 13 (.readHeap 12 (.lit 1)) (.add (.readHeap 12 (.lit 3)) (.lit 1))
          stA hpCA hpBA (idx := e) (val := ((sNew + 1 : ℕ) : ℤ))
          (u₁ := 2) (b₁ := 8 + intBitLength e) (u₂ := 4)
          (b₂ := 14 + 2 * intBitLength (sNew : ℤ))
          (evalIntLe_readHeap_lit inpSim stA.frameDepth stA.words 12 1 _ (b := 8 + intBitLength e) hrA_12_1 h12 hl1 (le_of_eq (by ring)))
          (evalIntLe_add_read12_one inpSim stA.frameDepth stA.words 3 sNew (b := 14 + 2 * intBitLength (sNew : ℤ)) hrA_12_3 hl3 (le_of_eq (by ring)))
          hcT1 hbT1
      -- Step T2: `.writeHeap 15 (.readHeap 12 (.lit 3)) (.readHeap 12 (.lit 1))`
      have hrT1_12_1 : stT1.words.read (.heap 12 1) = e := by
        rw [hwT1, wordStore_read_write_ne _ (by simp)]; exact hrA_12_1
      have hrT1_12_3 : stT1.words.read (.heap 12 3) = (sNew : ℤ) := by
        rw [hwT1, wordStore_read_write_ne _ (by simp)]; exact hrA_12_3
      have hcT2 : inpSim.inputCellSpace + (stT1.words.write (.heap 15 (sNew : ℤ)) e).cellCount ≤ C_cell := by
        have h0 := cellCount_write_le stT1.words (.heap 15 (sNew : ℤ)) e
        have h1 := cellCount_write_le stA.words (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)
        have h2 := cellCount_write_le (wrapScratch wsCore) (.heap 12 3) (sNew : ℤ)
        rw [← hwT1] at h1; rw [← hwA] at h2; linarith
      have hbT2 : inpSim.inputBitSpace + (stT1.words.write (.heap 15 (sNew : ℤ)) e).bitSize ≤ C_bit := by
        have h0 := bitSize_write_le stT1.words (.heap 15 (sNew : ℤ)) e
        have h1 := bitSize_write_le stA.words (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)
        have h2 := bitSize_write_le (wrapScratch wsCore) (.heap 12 3) (sNew : ℤ)
        dsimp only [RAMCellLoc.bitLength] at h0 h1 h2; rw [h15] at h0; rw [h13] at h1; rw [h12, hl3] at h2
        rw [← hwT1] at h1; rw [← hwA] at h2; linarith
      obtain ⟨stT2, hrT2, hwT2, hfdT2, hrbT2, hucT2, hbcT2, hpCT2, hpBT2⟩ :=
        exec_writeHeap_ceil inpSim 15 (.readHeap 12 (.lit 3)) (.readHeap 12 (.lit 1))
          stT1 hpCT1 hpBT1 (idx := (sNew : ℤ)) (val := e)
          (u₁ := 2) (b₁ := 10 + intBitLength (sNew : ℤ))
          (u₂ := 2) (b₂ := 8 + intBitLength e)
          (evalIntLe_readHeap_lit inpSim stT1.frameDepth stT1.words 12 3 _ (b := 10 + intBitLength (sNew : ℤ)) hrT1_12_3 h12 hl3 (le_of_eq (by ring)))
          (evalIntLe_readHeap_lit inpSim stT1.frameDepth stT1.words 12 1 _ (b := 8 + intBitLength e) hrT1_12_1 h12 hl1 (le_of_eq (by ring)))
          hcT2 hbT2
      -- Step T3: `.writeHeap 16 (.readHeap 12 (.lit 3)) (.lit 1)`
      have hrT2_12_3 : stT2.words.read (.heap 12 3) = (sNew : ℤ) := by
        rw [hwT2, wordStore_read_write_ne _ (by simp)]; exact hrT1_12_3
      have hcT3 : inpSim.inputCellSpace + (stT2.words.write (.heap 16 (sNew : ℤ)) 1).cellCount ≤ C_cell := by
        have h_1 := cellCount_write_le stT2.words (.heap 16 (sNew : ℤ)) 1
        have h0 := cellCount_write_le stT1.words (.heap 15 (sNew : ℤ)) e
        have h1 := cellCount_write_le stA.words (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)
        have h2 := cellCount_write_le (wrapScratch wsCore) (.heap 12 3) (sNew : ℤ)
        rw [← hwT2] at h0; rw [← hwT1] at h1; rw [← hwA] at h2; linarith
      have hbT3 : inpSim.inputBitSpace + (stT2.words.write (.heap 16 (sNew : ℤ)) 1).bitSize ≤ C_bit := by
        have h_1 := bitSize_write_le stT2.words (.heap 16 (sNew : ℤ)) 1
        have h0 := bitSize_write_le stT1.words (.heap 15 (sNew : ℤ)) e
        have h1 := bitSize_write_le stA.words (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)
        have h2 := bitSize_write_le (wrapScratch wsCore) (.heap 12 3) (sNew : ℤ)
        dsimp only [RAMCellLoc.bitLength] at h_1 h0 h1 h2
        rw [h16, hl1] at h_1; rw [h15] at h0; rw [h13] at h1; rw [h12, hl3] at h2
        rw [← hwT2] at h0; rw [← hwT1] at h1; rw [← hwA] at h2; linarith
      obtain ⟨stT3, hrT3, hwT3, hfdT3, hrbT3, hucT3, hbcT3, hpCT3, hpBT3⟩ :=
        exec_writeHeap_ceil inpSim 16 (.readHeap 12 (.lit 3)) (.lit 1)
          stT2 hpCT2 hpBT2 (idx := (sNew : ℤ)) (val := 1)
          (u₁ := 2) (b₁ := 10 + intBitLength (sNew : ℤ)) (u₂ := 1) (b₂ := 2)
          (evalIntLe_readHeap_lit inpSim stT2.frameDepth stT2.words 12 3 _ (b := 10 + intBitLength (sNew : ℤ)) hrT2_12_3 h12 hl3 (le_of_eq (by ring)))
          (evalIntLe_lit _ _ _ _ (by decide)) hcT3 hbT3
      -- Step T4: `.freeHeap 12 (.lit 3)`, `.freeHeap 12 (.lit 1)`, `.freeHeap 12 (.lit 2)`
      obtain ⟨stT4, hrT4, hwT4, hfdT4, hrbT4, hucT4, hbcT4, hpCT4, hpBT4⟩ :=
        exec_freeHeap_ceil inpSim 12 (.lit 3) stT3 hpCT3 hpBT3 (idx := 3) (u₁ := 1) (b₁ := 3) (evalIntLe_lit _ _ _ _ (by decide))
      obtain ⟨stT5, hrT5, hwT5, hfdT5, hrbT5, hucT5, hbcT5, hpCT5, hpBT5⟩ :=
        exec_freeHeap_ceil inpSim 12 (.lit 1) stT4 hpCT4 hpBT4 (idx := 1) (u₁ := 1) (b₁ := 2) (evalIntLe_lit _ _ _ _ (by decide))
      obtain ⟨stT6, hrT6, hwT6, hfdT6, hrbT6, hucT6, hbcT6, hpCT6, hpBT6⟩ :=
        exec_freeHeap_ceil inpSim 12 (.lit 2) stT5 hpCT5 hpBT5 (idx := 2) (u₁ := 1) (b₁ := 3) (evalIntLe_lit _ _ _ _ (by decide))
      have htot : RunsTo inpSim [.stmt trA2LogInsertAfterWrite] stMid stT6 := by
        refine RunsTo.seq ?_ (RunsTo.seq hrT5 hrT6)
        apply RunsTo.ite
        rw [hcond_eq]
        simp only [hr13_val, decide_true, ↓reduceIte]
        have hbody := RunsTo.seq hrAlloc (RunsTo.seq hrT1 (RunsTo.seq hrT2 (RunsTo.seq hrT3 hrT4)))
        have hl0 : intBitLength (0 : ℤ) = 1 := by decide
        simpa [st0, hl0] using hbody
      -- Simplify `stT6.words` by canceling scratch cells `.heap 12 3, 1, 2`!
      set wsFin := ((wsCore.write (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)).write (.heap 15 (sNew : ℤ)) e).write (.heap 16 (sNew : ℤ)) 1
      have hwfFin : WellFormedWS wsFin :=
        wellFormedWS_write (wellFormedWS_write (wellFormedWS_write hwfCore _ _) _ _) _ _
      have hnCore_12_1 : (.heap 12 1 : RAMCellLoc) ∉ wsCore.live := by
        rw [(hCoreOther _ (by decide) (by decide) (by simp)).1]
        simp [WordStore.write, hn12_1]
      have hnCore_12_2 : (.heap 12 2 : RAMCellLoc) ∉ wsCore.live := by
        rw [(hCoreOther _ (by decide) (by decide) (by simp)).1]
        simp [WordStore.write, hn12_2]
      have hnCore_12_3 : (.heap 12 3 : RAMCellLoc) ∉ wsCore.live := by
        rw [(hCoreOther _ (by decide) (by decide) (by simp)).1]
        simp [WordStore.write, hn12_3]
      have hwT4_eq : stT4.words = wrapScratch wsFin := by
        rw [hwT4, hwT3, hwT2, hwT1, hwA]
        -- Move `.write (.heap 12 3) sNew` to the top and cancel with `.free (.heap 12 3)`
        rw [wordStore_write_comm (by simp) (sNew : ℤ) ((sNew + 1 : ℕ) : ℤ),
            wordStore_write_comm (by simp) (sNew : ℤ) e,
            wordStore_write_comm (by simp) (sNew : ℤ) 1]
        have hwfWrapFin : WellFormedWS (wrapScratch wsFin) := by
          dsimp [wrapScratch, wrapScratchA2]; cases hasScratch2
          · simp only [Bool.false_eq_true, ↓reduceIte]; exact wellFormedWS_write hwfFin _ _
          · simp only [↓reduceIte]; exact wellFormedWS_write (wellFormedWS_write hwfFin _ _) _ _
        have hnWrap_12_3 : (.heap 12 3 : RAMCellLoc) ∉ (wrapScratch wsFin).live := by
          dsimp [wrapScratch, wrapScratchA2, wsFin]
          cases hasScratch2 <;> simp [WordStore.write, hnCore_12_3]
        -- Commute `wrapScratch` with `.write 13, 15, 16`
        have hcomm_wrap : (((wrapScratch wsCore).write (.heap 13 e) ((sNew + 1 : ℕ) : ℤ)).write (.heap 15 (sNew : ℤ)) e).write (.heap 16 (sNew : ℤ)) 1 = wrapScratch wsFin := by
          dsimp only [wrapScratch, wrapScratchA2, wsFin]
          cases hasScratch2
          · simp only [Bool.false_eq_true, ↓reduceIte]
            rw [wordStore_write_comm (by simp) e ((sNew + 1 : ℕ) : ℤ),
                wordStore_write_comm (by simp) e e,
                wordStore_write_comm (by simp) e 1]
          · simp only [↓reduceIte]
            rw [wordStore_write_comm (by simp) val ((sNew + 1 : ℕ) : ℤ),
                wordStore_write_comm (by simp) val e,
                wordStore_write_comm (by simp) val 1,
                wordStore_write_comm (by simp) e ((sNew + 1 : ℕ) : ℤ),
                wordStore_write_comm (by simp) e e,
                wordStore_write_comm (by simp) e 1]
        rw [hcomm_wrap]
        exact wordStore_free_write_self hwfWrapFin hnWrap_12_3 (sNew : ℤ)
      have hwT6_eq : stT6.words = wsFin := by
        rw [hwT6, hwT5, hwT4_eq]
        exact hwrap_free wsFin hwfFin
          (by simp [wsFin, WordStore.write, hnCore_12_1])
          (by simp [wsFin, WordStore.write, hnCore_12_2])
      set sidOfEnc' := Function.update sidOfEnc e (some sNew)
      set encOfSid' := Function.update encOfSid sNew e
      have hinvFin : A2SimInv wsBase T_max S_max (wsSub.write (.heap table idx) val) wsFin
          highSid' sidOfEnc' encOfSid' freeStack' :=
        a2SimInv_after_miss hinv ht idx val hsid hwfCore hhigh_le' hsNew_lt' hsNew_nf' hsNew_not_old
          hnd' hfree_lt' hact_equiv hCoreOther hCore12_4 hCore12_5 hCore14 hCoreCases
      rw [← hwT6_eq] at hinvFin
      refine ⟨stT6, highSid', sidOfEnc', encOfSid', freeStack', htot, hinvFin,
        hfdT6.trans (hfdT5.trans (hfdT4.trans (hfdT3.trans (hfdT2.trans (hfdT1.trans hfdA))))),
        hrbT6.trans (hrbT5.trans (hrbT4.trans (hrbT3.trans (hrbT2.trans (hrbT1.trans hrbA))))),
        ?_, ?_, hpCT6, hpBT6⟩
      · have h0_uc : st0.unitCost = stMid.unitCost + 5 := rfl
        linarith only [h0_uc, hucA, hucT1, hucT2, hucT3, hucT4, hucT5, hucT6]
      · have h0_bc : st0.bitCost = stMid.bitCost + (2 + 4 + 2 + intBitLength e + 4 + intBitLength e + 1 + 1 + 1 + 1) := rfl
        rw [h13] at hbcT1; rw [h15] at hbcT2; rw [h16, hl1] at hbcT3
        rw [h12, hl3] at hbcT4; rw [h12, hl1] at hbcT5; rw [h12, hl2] at hbcT6
        linarith only [h0_bc, hbcA, hbcT1, hbcT2, hbcT3, hbcT4, hbcT5, hbcT6, hsNew_bl, hsNew1_bl, hSb4]

end UL.C12LVE
