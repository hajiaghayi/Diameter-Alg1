import Mathlib
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Proof.lem_A_1.H1_Params
import UL.Proof.lem_A_1.H3a_Sim
set_option autoImplicit false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Additional `RunsTo` rules (`freeHeap`, `freeLocal`, `randBitHeap`, `randBitLocal`, `whileLoop`) -/

theorem RunsTo.skip {d : ℕ} (inp : BitRAMInput d) (st : BitRAMExecState) :
    RunsTo inp [.stmt .skip] st
      { st with unitCost := st.unitCost + 1, bitCost := st.bitCost + 1 } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.freeHeap {d : ℕ} (inp : BitRAMInput d) (table : ℕ) (idxE : IntExpr)
    (st : BitRAMExecState) :
    let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
    let loc := RAMCellLoc.heap table idx
    RunsTo inp [.stmt (.freeHeap table idxE)] st
      { st with
        words := st.words.free loc
        unitCost := st.unitCost + u + 1
        bitCost := st.bitCost + b + loc.bitLength } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.freeLocal {d : ℕ} (inp : BitRAMInput d) (var : ℕ) (idxE : IntExpr)
    (st : BitRAMExecState) :
    let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
    let loc := RAMCellLoc.localFrame st.frameDepth var idx
    RunsTo inp [.stmt (.freeLocal var idxE)] st
      { st with
        words := st.words.free loc
        unitCost := st.unitCost + u + 1
        bitCost := st.bitCost + b + loc.bitLength } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.randBitHeap {d : ℕ} (inp : BitRAMInput d) (table : ℕ) (idxE : IntExpr)
    (bit : Bool) (bs' : List Bool) (st : BitRAMExecState)
    (hbits : st.remainingBits = bit :: bs') :
    let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
    let loc := RAMCellLoc.heap table idx
    let ws' := st.words.write loc (if bit then 1 else 0)
    RunsTo inp [.stmt (.randBitHeap table idxE)] st
      { st with
        words := ws'
        remainingBits := bs'
        unitCost := st.unitCost + u + 1
        bitCost := st.bitCost + b + loc.bitLength + 1
        peakCellSpace := max st.peakCellSpace (inp.inputCellSpace + ws'.cellCount)
        peakBitSpace := max st.peakBitSpace (inp.inputBitSpace + ws'.bitSize) } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  simp [runBitRAMFuel, hbits]

theorem RunsTo.randBitLocal {d : ℕ} (inp : BitRAMInput d) (var : ℕ) (idxE : IntExpr)
    (bit : Bool) (bs' : List Bool) (st : BitRAMExecState)
    (hbits : st.remainingBits = bit :: bs') :
    let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
    let loc := RAMCellLoc.localFrame st.frameDepth var idx
    let ws' := st.words.write loc (if bit then 1 else 0)
    RunsTo inp [.stmt (.randBitLocal var idxE)] st
      { st with
        words := ws'
        remainingBits := bs'
        unitCost := st.unitCost + u + 1
        bitCost := st.bitCost + b + loc.bitLength + 1
        peakCellSpace := max st.peakCellSpace (inp.inputCellSpace + ws'.cellCount)
        peakBitSpace := max st.peakBitSpace (inp.inputBitSpace + ws'.bitSize) } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  simp [runBitRAMFuel, hbits]

theorem RunsTo.while_false {d : ℕ} {inp : BitRAMInput d} (cond : BitCondExpr) (body : BitRAMStmt)
    (st : BitRAMExecState) {u b : ℕ}
    (hcond : evalBitCond inp st.frameDepth st.words cond = (false, u, b)) :
    RunsTo inp [.stmt (.whileLoop cond body)] st
      { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  simp [runBitRAMFuel, hcond]

theorem RunsTo.while_true {d : ℕ} {inp : BitRAMInput d} (cond : BitCondExpr) (body : BitRAMStmt)
    {st stMid stEnd : BitRAMExecState} {u b : ℕ}
    (hcond : evalBitCond inp st.frameDepth st.words cond = (true, u, b))
    (hbody : RunsTo inp [.stmt body]
      { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b } stMid)
    (hrest : RunsTo inp [.stmt (.whileLoop cond body)] stMid stEnd) :
    RunsTo inp [.stmt (.whileLoop cond body)] st stEnd := by
  have h12 : RunsTo inp [.stmt body, .stmt (.whileLoop cond body)]
      { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b } stEnd :=
    RunsTo.trans hbody hrest
  rcases h12 with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  simpa [runBitRAMFuel, hcond] using hf rest k

theorem wordStore_free_of_not_mem {ws : WordStore} (hwf : WellFormedWS ws)
    {loc : RAMCellLoc} (hnot : loc ∉ ws.live) :
    ws.free loc = ws := by
  cases ws with
  | mk live vals =>
      dsimp [WellFormedWS] at hwf
      unfold WordStore.free
      dsimp only
      congr 1
      · exact Finset.erase_eq_of_notMem hnot
      · funext l
        by_cases heq : l = loc
        · subst heq
          simpa using (hwf l hnot).symm
        · exact Function.update_of_ne heq 0 vals

/-! ### 2. Bit-append, prefix-freeness of `runBitRAMWithBits`, and Kraft's inequality -/

theorem runBitRAMFuel_to_RunsTo {d : ℕ} {inp : BitRAMInput d} :
    ∀ (fuel : ℕ) (stack : List BitRAMCont) (st : BitRAMExecState) (out : BitRAMExecOutcome)
      (tailBits : List Bool),
      runBitRAMFuel inp fuel stack st = .halted out →
      ∃ stEnd : BitRAMExecState,
        RunsTo inp stack { st with remainingBits := st.remainingBits ++ tailBits } stEnd ∧
        stEnd.words.popDepth 0 = out.words ∧
        stEnd.frameDepth = endDepth stack st.frameDepth ∧
        stEnd.remainingBits = tailBits ∧
        stEnd.unitCost = out.unitCost ∧
        stEnd.bitCost = out.bitCost ∧
        stEnd.peakCellSpace = out.peakCellSpace ∧
        stEnd.peakBitSpace = out.peakBitSpace := by
  intro fuel
  induction fuel with
  | zero =>
      intro stack st out tailBits hrun
      cases stack with
      | nil =>
          simp only [runBitRAMFuel] at hrun
          split_ifs at hrun with hemp
          cases hrun
          have hnil : st.remainingBits = [] := List.isEmpty_iff.mp hemp
          refine ⟨{ st with remainingBits := tailBits }, ?_, rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩
          rw [hnil, List.nil_append]
          exact RunsTo.nil _
      | cons _ _ =>
          simp [runBitRAMFuel] at hrun
  | succ fuel ih =>
      rintro stack ⟨w, fd, rem, uc, bc, pc, pb⟩ out tailBits hrun
      let st : BitRAMExecState := ⟨w, fd, rem, uc, bc, pc, pb⟩
      cases stack with
      | nil =>
          simp only [runBitRAMFuel] at hrun
          split_ifs at hrun with hemp
          cases hrun
          have hnil : rem = [] := List.isEmpty_iff.mp hemp
          subst hnil
          exact ⟨⟨w, fd, tailBits, uc, bc, pc, pb⟩, RunsTo.nil _, rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩
      | cons item rest =>
          have step_helper : ∀ {nextStack : List BitRAMCont} {st' : BitRAMExecState},
              runBitRAMFuel inp fuel nextStack st' = .halted out →
              (∀ (r : List BitRAMCont) (k : ℕ),
                runBitRAMFuel inp (k + 1) (item :: rest ++ r)
                  { st with remainingBits := st.remainingBits ++ tailBits } =
                runBitRAMFuel inp k (nextStack ++ r)
                  { st' with remainingBits := st'.remainingBits ++ tailBits }) →
              endDepth nextStack st'.frameDepth = endDepth (item :: rest) st.frameDepth →
              ∃ stEnd : BitRAMExecState,
                RunsTo inp (item :: rest)
                  { st with remainingBits := st.remainingBits ++ tailBits } stEnd ∧
                stEnd.words.popDepth 0 = out.words ∧
                stEnd.frameDepth = endDepth (item :: rest) st.frameDepth ∧
                stEnd.remainingBits = tailBits ∧
                stEnd.unitCost = out.unitCost ∧
                stEnd.bitCost = out.bitCost ∧
                stEnd.peakCellSpace = out.peakCellSpace ∧
                stEnd.peakBitSpace = out.peakBitSpace := by
            intro nextStack st' hrun' hstep hfd
            obtain ⟨stEnd, ⟨f, hf⟩, h1, h2, h3, h4, h5, h6, h7⟩ :=
              ih nextStack st' out tailBits hrun'
            refine ⟨stEnd, ⟨1 + f, fun r k => ?_⟩, h1, h2.trans hfd, h3, h4, h5, h6, h7⟩
            rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
            exact (hstep r (f + k)).trans (hf r k)
          cases item with
          | popScope prev =>
              simp only [runBitRAMFuel] at hrun
              exact step_helper hrun (fun _ _ => rfl) rfl
          | repeatLoop rem body =>
              cases rem with
              | zero =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl
              | succ rem' =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl
          | stmt s =>
              cases s with
              | skip =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl
              | writeHeap table idxE valE =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl
              | writeLocal var idxE valE =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl
              | freeHeap table idxE =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl
              | freeLocal var idxE =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl
              | randBitHeap table idxE =>
                  cases rem with
                  | nil => simp [runBitRAMFuel] at hrun
                  | cons bit bs' =>
                      simp only [runBitRAMFuel] at hrun
                      exact step_helper hrun (fun _ _ => rfl) rfl
              | randBitLocal var idxE =>
                  cases rem with
                  | nil => simp [runBitRAMFuel] at hrun
                  | cons bit bs' =>
                      simp only [runBitRAMFuel] at hrun
                      exact step_helper hrun (fun _ _ => rfl) rfl
              | seq s₁ s₂ =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl
              | ite cond tB fB =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl
              | whileLoop cond body =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => by simp only [st, List.cons_append, runBitRAMFuel]; split_ifs <;> rfl) (by split_ifs <;> rfl)
              | repeatN countE body =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl
              | localScope body =>
                  simp only [runBitRAMFuel] at hrun
                  exact step_helper hrun (fun _ _ => rfl) rfl

theorem runBitRAMWithBits_prefix_free {d : ℕ} (prog : BitRAMStmt) (inp : BitRAMInput d)
    (initWords : WordStore) {bs₁ bs₂ : List Bool} {out₁ out₂ : BitRAMExecOutcome}
    (h₁ : runBitRAMWithBits prog inp initWords bs₁ = some out₁)
    (h₂ : runBitRAMWithBits prog inp initWords bs₂ = some out₂)
    (hpref : bs₁ <+: bs₂) :
    bs₁ = bs₂ := by
  rcases hpref with ⟨extra, rfl⟩
  rw [runBitRAMWithBits_eq_some_iff] at h₁ h₂
  rcases h₁ with ⟨f₁, hf₁⟩
  rcases h₂ with ⟨f₂, hf₂⟩
  obtain ⟨stEnd, ⟨f', hf'⟩, _, _, hrem, _, _, _, _⟩ :=
    runBitRAMFuel_to_RunsTo f₁ [.stmt prog] _ out₁ extra hf₁
  let F := max f' f₂
  have hrun2 := runBitRAMFuel_mono hf₂ (Nat.le_max_right f' f₂)
  have hrun1 := hf' [] (F - f')
  rw [show f' + (F - f') = F by omega, List.append_nil] at hrun1
  rw [hrun2] at hrun1
  simp only [runBitRAMFuel, hrem] at hrun1
  split_ifs at hrun1 with hemp
  have hex : extra = [] := List.isEmpty_iff.mp hemp
  simp [hex]

/-! ### 3. Kraft's inequality and measure-1 forward equivalence -/

private def matchesPrefix (N : ℕ) (bs : List Bool) (f : Fin N → Bool) : Prop :=
  ∀ (i : ℕ) (hi : i < bs.length) (hN : i < N), f ⟨i, hN⟩ = bs[i]

private noncomputable def cylFinset (N : ℕ) (bs : List Bool) : Finset (Fin N → Bool) :=
  open Classical in
  Finset.univ.filter (matchesPrefix N bs)

private lemma disjoint_cylFinset {N : ℕ} {bs₁ bs₂ : List Bool}
    (h1 : bs₁.length ≤ N) (h2 : bs₂.length ≤ N)
    (hnp1 : ¬ (bs₁ <+: bs₂)) (hnp2 : ¬ (bs₂ <+: bs₁)) :
    Disjoint (cylFinset N bs₁) (cylFinset N bs₂) := by
  classical
  rw [Finset.disjoint_left]
  intro f hf1 hf2
  simp only [cylFinset, Finset.mem_filter, Finset.mem_univ, true_and] at hf1 hf2
  rcases le_total bs₁.length bs₂.length with hle | hle
  · apply hnp1
    rw [List.prefix_iff_eq_take]
    apply List.ext_getElem
    · simp [Nat.min_eq_left hle]
    · intro i hi1 hi2
      have hiN : i < N := lt_of_lt_of_le hi1 h1
      have hi_b2 : i < bs₂.length := lt_of_lt_of_le hi1 hle
      rw [List.getElem_take, ← hf1 i hi1 hiN, hf2 i hi_b2 hiN]
  · apply hnp2
    rw [List.prefix_iff_eq_take]
    apply List.ext_getElem
    · simp [Nat.min_eq_left hle]
    · intro i hi1 hi2
      have hiN : i < N := lt_of_lt_of_le hi1 h2
      have hi_b1 : i < bs₁.length := lt_of_lt_of_le hi1 hle
      rw [List.getElem_take, ← hf2 i hi1 hiN, hf1 i hi_b1 hiN]

private lemma card_cylFinset :
    ∀ (N : ℕ) (bs : List Bool), bs.length ≤ N → (cylFinset N bs).card = 2 ^ (N - bs.length)
  | 0, bs, hlen => by
      classical
      have hnil : bs = [] := List.eq_nil_of_length_eq_zero (Nat.le_zero.mp hlen)
      subst hnil
      have heq : cylFinset 0 [] = Finset.univ := by
        ext f; simp [cylFinset, matchesPrefix]
      rw [heq]
      simp
  | N + 1, [], _ => by
      classical
      have heq : cylFinset (N + 1) [] = Finset.univ := by
        ext f; simp [cylFinset, matchesPrefix]
      rw [heq]
      simp [Fintype.card_bool]
  | N + 1, b :: tail, hlen => by
      classical
      have htail : tail.length ≤ N := by simpa using hlen
      have himg : cylFinset (N + 1) (b :: tail) =
          (cylFinset N tail).image (Fin.cons b) := by
        ext f
        simp only [cylFinset, Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_image]
        constructor
        · intro hf
          have hf0 : f 0 = b := hf 0 (by simp) (by omega)
          refine ⟨Fin.tail f, ?_, ?_⟩
          · intro i hi hiN
            have hsucc := hf (i + 1) (by simpa using Nat.succ_lt_succ hi) (by omega)
            simpa [Fin.tail] using hsucc
          · ext idx
            refine Fin.cases ?_ ?_ idx
            · simp [hf0]
            · intro j; simp [Fin.tail]
        · rintro ⟨g, hg, rfl⟩ i hi hiN
          cases i with
          | zero => simp
          | succ j =>
              have hj : j < tail.length := Nat.lt_of_succ_lt_succ hi
              have hjN : j < N := by omega
              simpa using hg j hj hjN
      have hinj : Function.Injective (fun g : Fin N → Bool => (Fin.cons b g : Fin (N + 1) → Bool)) := by
        intro g₁ g₂ h
        funext j
        simpa using congr_fun h j.succ
      rw [himg, Finset.card_image_of_injective _ hinj,
        card_cylFinset N tail htail]
      simp [Nat.succ_sub_succ_eq_sub]

theorem tsum_bitListProb_le_one_of_prefix_free (P : List Bool → Prop)
    (hPF : ∀ b₁ b₂ : List Bool, P b₁ → P b₂ → b₁ <+: b₂ → b₁ = b₂) :
    (open Classical in ∑' bs : List Bool, if P bs then bitListProb bs else 0) ≤ 1 := by
  classical
  rw [ENNReal.tsum_eq_iSup_sum]
  refine iSup_le fun F => ?_
  let F' : Finset (List Bool) := F.filter P
  let N : ℕ := F'.sup List.length
  have hPairDisj : (F' : Set (List Bool)).PairwiseDisjoint (cylFinset N) := by
    intro b₁ hb₁ b₂ hb₂ hne
    have hb₁' := Finset.mem_filter.mp hb₁
    have hb₂' := Finset.mem_filter.mp hb₂
    exact disjoint_cylFinset
      (Finset.le_sup (f := List.length) hb₁)
      (Finset.le_sup (f := List.length) hb₂)
      (fun hp => hne (hPF b₁ b₂ hb₁'.2 hb₂'.2 hp))
      (fun hp => hne (hPF b₂ b₁ hb₂'.2 hb₁'.2 hp).symm)
  have hCardSum : ∑ b ∈ F', 2 ^ (N - b.length) ≤ 2 ^ N := by
    have hEq : ∑ b ∈ F', 2 ^ (N - b.length) = (F'.biUnion (cylFinset N)).card := by
      rw [Finset.card_biUnion hPairDisj]
      refine Finset.sum_congr rfl fun b hb => ?_
      exact (card_cylFinset N b (Finset.le_sup (f := List.length) hb)).symm
    rw [hEq]
    calc (F'.biUnion (cylFinset N)).card
        ≤ (Finset.univ : Finset (Fin N → Bool)).card :=
          Finset.card_le_card (Finset.subset_univ _)
      _ = 2 ^ N := by simp [Fintype.card_bool]
  have hHalfNe0 : (2 : ENNReal) ≠ 0 := by norm_num
  have hHalfNeTop : (2 : ENNReal) ≠ ⊤ := ENNReal.ofNat_ne_top
  have hMulInv : (2 : ENNReal) * (2 : ENNReal)⁻¹ = 1 := ENNReal.mul_inv_cancel hHalfNe0 hHalfNeTop
  have hTermEq : ∀ k : ℕ, k ≤ N →
      ((2 ^ (N - k) : ℕ) : ENNReal) * (((2 : ENNReal)⁻¹) ^ N) = ((2 : ENNReal)⁻¹) ^ k := by
    intro k hk
    rw [Nat.cast_pow, Nat.cast_ofNat]
    rw [show (((2 : ENNReal)⁻¹) ^ N) = (((2 : ENNReal)⁻¹) ^ ((N - k) + k)) by congr 1; omega]
    rw [pow_add (((2 : ENNReal)⁻¹)), ← mul_assoc, ← mul_pow, hMulInv, one_pow, one_mul]
  have hSumEq : (∑ b ∈ F, if P b then bitListProb b else 0) =
      ∑ b ∈ F', bitListProb b := by
    rw [Finset.sum_filter]
  rw [hSumEq]
  have hRew : ∑ b ∈ F', bitListProb b =
      (∑ b ∈ F', ((2 ^ (N - b.length) : ℕ) : ENNReal)) * (((2 : ENNReal)⁻¹) ^ N) := by
    rw [Finset.sum_mul]
    refine Finset.sum_congr rfl fun b hb => ?_
    unfold bitListProb
    exact (hTermEq b.length (Finset.le_sup (f := List.length) hb)).symm
  rw [hRew]
  calc (∑ b ∈ F', ((2 ^ (N - b.length) : ℕ) : ENNReal)) * (((2 : ENNReal)⁻¹) ^ N)
      ≤ ((2 ^ N : ℕ) : ENNReal) * (((2 : ENNReal)⁻¹) ^ N) := by
        have hCast : (∑ b ∈ F', ((2 ^ (N - b.length) : ℕ) : ENNReal)) ≤ ((2 ^ N : ℕ) : ENNReal) := by
          exact_mod_cast hCardSum
        exact mul_le_mul_of_nonneg_right hCast (zero_le _)
    _ = 1 := by
        simpa using hTermEq 0 (Nat.zero_le N)

theorem halt_iff_of_forward_and_prob_one (H₁ H₂ : List Bool → Prop)
    (hSub : ∀ bs : List Bool, H₁ bs → H₂ bs)
    (hPF : ∀ b₁ b₂ : List Bool, H₂ b₁ → H₂ b₂ → b₁ <+: b₂ → b₁ = b₂)
    (hOne : (open Classical in ∑' bs : List Bool, if H₁ bs then bitListProb bs else 0) = 1) :
    (∀ bs : List Bool, H₂ bs ↔ H₁ bs) ∧
    (open Classical in ∑' bs : List Bool, if H₂ bs then bitListProb bs else 0) = 1 := by
  classical
  have hEquiv : ∀ bs : List Bool, H₂ bs ↔ H₁ bs := by
    intro bs₀
    refine ⟨?_, hSub bs₀⟩
    intro h2
    by_contra hnot1
    have hPoint : ∀ bs : List Bool,
        (if bs = bs₀ then bitListProb bs₀ else 0) + (if H₁ bs then bitListProb bs else 0) ≤
          (if H₂ bs then bitListProb bs else 0) := by
      intro bs
      by_cases heq : bs = bs₀
      · subst heq
        simp [hnot1, h2]
      · simp only [heq, ↓reduceIte, zero_add]
        by_cases h1 : H₁ bs
        · simp [h1, hSub bs h1]
        · simp [h1]
    have hSumLe : bitListProb bs₀ + 1 ≤ 1 := by
      calc bitListProb bs₀ + 1
          = (∑' bs : List Bool, if bs = bs₀ then bitListProb bs₀ else 0) +
              (∑' bs : List Bool, if H₁ bs then bitListProb bs else 0) := by
            rw [tsum_ite_eq, hOne]
        _ = ∑' bs : List Bool,
              ((if bs = bs₀ then bitListProb bs₀ else 0) +
                (if H₁ bs then bitListProb bs else 0)) := (ENNReal.tsum_add).symm
        _ ≤ ∑' bs : List Bool, if H₂ bs then bitListProb bs else 0 := ENNReal.tsum_le_tsum hPoint
        _ ≤ 1 := tsum_bitListProb_le_one_of_prefix_free H₂ hPF
    have hPos : bitListProb bs₀ ≠ 0 := by
      unfold bitListProb
      refine pow_ne_zero _ ?_
      exact ENNReal.inv_ne_zero.mpr ENNReal.ofNat_ne_top
    have hLtTop : bitListProb bs₀ + 1 ≠ ⊤ := lt_top_iff_ne_top.mp (lt_of_le_of_lt hSumLe ENNReal.one_lt_top)
    have hBneTop : bitListProb bs₀ ≠ ⊤ := fun htop => by simp [htop] at hLtTop
    have hRealLe : (bitListProb bs₀ + 1).toReal ≤ (1 : ENNReal).toReal :=
      ENNReal.toReal_mono ENNReal.one_ne_top hSumLe
    rw [ENNReal.toReal_add hBneTop ENNReal.one_ne_top, ENNReal.toReal_one] at hRealLe
    have hRealPos : 0 < (bitListProb bs₀).toReal :=
      ENNReal.toReal_pos hPos hBneTop
    linarith
  refine ⟨hEquiv, ?_⟩
  rw [← hOne]
  exact tsum_congr fun bs => by simp [hEquiv bs]

/-! ### 4. Linear-bit-cost arithmetic range indicator and `progA2` translation -/

/-- Evaluates to `1` if `0 ≤ x < N` (for `1 ≤ N`) and `0` otherwise, using only linear-bit-cost
operations (`1 / (3 * (x / N) + 1)`, avoiding squaring `x / N`). -/
def inRangeExpr (xE NE : IntExpr) : IntExpr :=
  let qE := IntExpr.div xE NE
  IntExpr.div (.lit 1) (.add (.mul (.lit 3) qE) (.lit 1))

theorem one_ediv_three_mul_add_one (q : ℤ) :
    (1 : ℤ) / (3 * q + 1) = if q = 0 then 1 else 0 := by
  split_ifs with hq
  · subst hq; norm_num
  · rcases lt_or_gt_of_ne hq with hneg | hpos
    · have hd_neg : 3 * q + 1 ≤ -2 := by omega
      have hd_ne : 3 * q + 1 ≠ 0 := by omega
      have hmod := Int.mul_ediv_add_emod 1 (3 * q + 1)
      have hm0 : 0 ≤ (1 : ℤ) % (3 * q + 1) := Int.emod_nonneg 1 hd_ne
      have hm1 : (1 : ℤ) % (3 * q + 1) < -(3 * q + 1) := by
        have hlt := Int.emod_lt 1 hd_ne
        have habs : ((3 * q + 1).natAbs : ℤ) = -(3 * q + 1) := by omega
        omega
      by_contra hq_ediv
      rcases lt_or_gt_of_ne hq_ediv with hlt0 | hgt0
      · have hk : 1 / (3 * q + 1) ≤ -1 := by omega
        nlinarith
      · have hk : 1 ≤ 1 / (3 * q + 1) := by omega
        nlinarith
    · exact Int.ediv_eq_zero_of_lt (by omega) (by omega)

theorem inRange_val_eq {x N : ℤ} (hN : 1 ≤ N) :
    (1 : ℤ) / (3 * (x / N) + 1) = if 0 ≤ x ∧ x < N then 1 else 0 := by
  rw [one_ediv_three_mul_add_one]
  by_cases h2 : 0 ≤ x ∧ x < N
  · have h1 : x / N = 0 := Int.ediv_eq_zero_of_lt h2.1 h2.2
    simp [h1, h2]
  · have h1 : x / N ≠ 0 := by
      intro hq0
      apply h2
      have hmod := Int.mul_ediv_add_emod x N
      rw [hq0, mul_zero, zero_add] at hmod
      have hm0 : 0 ≤ x % N := Int.emod_nonneg x (by omega)
      have hm1 : x % N < N := Int.emod_lt_of_pos x (by omega)
      exact ⟨by omega, by omega⟩
    simp [h1, h2]

def maxTableExpr : IntExpr → ℕ
  | .lit _ | .dim => 1
  | .intParam e | .extraRatNum e | .extraRatDen e | .neg e => maxTableExpr e
  | .readHeap t e => max (t + 1) (maxTableExpr e)
  | .readLocal _ e => maxTableExpr e
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂
  | .add e₁ e₂ | .sub e₁ e₂ | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ =>
      max (maxTableExpr e₁) (maxTableExpr e₂)

def maxTableCond : BitCondExpr → ℕ
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => max (maxTableExpr e₁) (maxTableExpr e₂)
  | .not c => maxTableCond c
  | .and c₁ c₂ | .or c₁ c₂ => max (maxTableCond c₁) (maxTableCond c₂)

def maxTableStmt : BitRAMStmt → ℕ
  | .skip => 1
  | .writeHeap t e₁ e₂ => max (t + 1) (max (maxTableExpr e₁) (maxTableExpr e₂))
  | .writeLocal _ e₁ e₂ => max (maxTableExpr e₁) (maxTableExpr e₂)
  | .freeHeap t e | .randBitHeap t e => max (t + 1) (maxTableExpr e)
  | .freeLocal _ e | .randBitLocal _ e => maxTableExpr e
  | .seq s₁ s₂ => max (maxTableStmt s₁) (maxTableStmt s₂)
  | .ite c s₁ s₂ => max (maxTableCond c) (max (maxTableStmt s₁) (maxTableStmt s₂))
  | .whileLoop c body => max (maxTableCond c) (maxTableStmt body)
  | .repeatN e body => max (maxTableExpr e) (maxTableStmt body)
  | .localScope body => maxTableStmt body

theorem maxTableExpr_pos : ∀ e : IntExpr, 1 ≤ maxTableExpr e
  | .lit _ | .dim => le_rfl
  | .intParam e | .extraRatNum e | .extraRatDen e | .neg e | .readLocal _ e => maxTableExpr_pos e
  | .readHeap _ _ => le_trans (by omega) (le_max_left _ _)
  | .activeRatNum e₁ _ | .activeRatDen e₁ _
  | .add e₁ _ | .sub e₁ _ | .mul e₁ _ | .div e₁ _ | .mod e₁ _ =>
      le_trans (maxTableExpr_pos e₁) (le_max_left _ _)

theorem maxTableCond_pos : ∀ c : BitCondExpr, 1 ≤ maxTableCond c
  | .intEq e₁ _ | .intLt e₁ _ | .intLe e₁ _ =>
      le_trans (maxTableExpr_pos e₁) (le_max_left _ _)
  | .not c => maxTableCond_pos c
  | .and c₁ _ | .or c₁ _ => le_trans (maxTableCond_pos c₁) (le_max_left _ _)

theorem maxTableStmt_pos : ∀ s : BitRAMStmt, 1 ≤ maxTableStmt s
  | .skip => le_rfl
  | .writeHeap _ _ _ | .freeHeap _ _ | .randBitHeap _ _ =>
      le_trans (by omega) (le_max_left _ _)
  | .writeLocal _ e₁ _ => le_trans (maxTableExpr_pos e₁) (le_max_left _ _)
  | .freeLocal _ e | .randBitLocal _ e => maxTableExpr_pos e
  | .seq s₁ _ => le_trans (maxTableStmt_pos s₁) (le_max_left _ _)
  | .ite c _ _ => le_trans (maxTableCond_pos c) (le_max_left _ _)
  | .whileLoop c _ => le_trans (maxTableCond_pos c) (le_max_left _ _)
  | .repeatN e _ => le_trans (maxTableExpr_pos e) (le_max_left _ _)
  | .localScope body => maxTableStmt_pos body

/-- 2D coordinate staging index in `[1 .. m * d]` when `0 ≤ h < m ∧ 0 ≤ c < d`, else `0`
(`m` is staged in `.heap 5 0`). -/
def addr2DA2 (hTr cTr : IntExpr) : IntExpr :=
  let mE := IntExpr.readHeap 5 (.lit 0)
  let inBnd := IntExpr.mul (inRangeExpr hTr mE) (inRangeExpr cTr .dim)
  IntExpr.mul inBnd (.add (.add (.mul hTr .dim) cTr) (.lit 1))

def trA2Expr (T_max : ℕ) : IntExpr → IntExpr
  | .lit c => .lit c
  | .dim => .dim
  | .intParam idxE => .readHeap 5 (trA2Expr T_max idxE)
  | .readHeap table idxE =>
      .readHeap 10 (.add (.mul (trA2Expr T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ)))
  | .readLocal var idxE => .readLocal var (trA2Expr T_max idxE)
  | .activeRatNum hE cE =>
      .readHeap 6 (addr2DA2 (trA2Expr T_max hE) (trA2Expr T_max cE))
  | .activeRatDen hE cE =>
      .add (.readHeap 7 (addr2DA2 (trA2Expr T_max hE) (trA2Expr T_max cE))) (.lit 1)
  | .extraRatNum _ => .lit 0
  | .extraRatDen _ => .lit 1
  | .neg e => .neg (trA2Expr T_max e)
  | .add e₁ e₂ => .add (trA2Expr T_max e₁) (trA2Expr T_max e₂)
  | .sub e₁ e₂ => .sub (trA2Expr T_max e₁) (trA2Expr T_max e₂)
  | .mul e₁ e₂ => .mul (trA2Expr T_max e₁) (trA2Expr T_max e₂)
  | .div e₁ e₂ => .div (trA2Expr T_max e₁) (trA2Expr T_max e₂)
  | .mod e₁ e₂ => .mod (trA2Expr T_max e₁) (trA2Expr T_max e₂)

def trA2Cond (T_max : ℕ) : BitCondExpr → BitCondExpr
  | .intEq e₁ e₂ => .intEq (trA2Expr T_max e₁) (trA2Expr T_max e₂)
  | .intLt e₁ e₂ => .intLt (trA2Expr T_max e₁) (trA2Expr T_max e₂)
  | .intLe e₁ e₂ => .intLe (trA2Expr T_max e₁) (trA2Expr T_max e₂)
  | .not c => .not (trA2Cond T_max c)
  | .and c₁ c₂ => .and (trA2Cond T_max c₁) (trA2Cond T_max c₂)
  | .or c₁ c₂ => .or (trA2Cond T_max c₁) (trA2Cond T_max c₂)

/-- Free-stack slot-ID (`sid ∈ [0, highSid)`) live-heap tracker for `progA2`:
- `.heap 10[enc]` stores live subroutine heap cell `(table, idx)` at `enc = idx * T_max + table`.
- `.heap 12[4]` stores `freeTop` (unallocated when `0`); `.heap 12[5]` stores `highSid` (unallocated when `0`).
- `.heap 14[0 .. freeTop - 1]` stores recycled `sid`s in `[0, highSid)`.
- Active `sid`s have `.heap 16[sid] = 1`, `.heap 15[sid] = enc`, and `.heap 13[enc] = sid + 1`.
- `.heap 12[1..3]` are ephemeral scratch cells freed at the end of each macro step. -/
def trA2LogInsertAfterWrite : BitRAMStmt :=
  -- Precondition: `.heap 12[1]` holds `enc`, `.heap 12[2]` may be live, and `.heap 10[enc]` is live.
  .seq
    (.ite (.intEq (.readHeap 13 (.readHeap 12 (.lit 1))) (.lit 0))
      (.seq
        (.ite (.intLt (.lit 0) (.readHeap 12 (.lit 4)))
          -- Pop sid from free stack `.heap 14[freeTop - 1]` into `.heap 12[3]`
          (.seq (.writeHeap 12 (.lit 3) (.readHeap 14 (.sub (.readHeap 12 (.lit 4)) (.lit 1))))
          (.seq (.freeHeap 14 (.sub (.readHeap 12 (.lit 4)) (.lit 1)))
                (.ite (.intEq (.readHeap 12 (.lit 4)) (.lit 1))
                  (.freeHeap 12 (.lit 4))
                  (.writeHeap 12 (.lit 4) (.sub (.readHeap 12 (.lit 4)) (.lit 1))))))
          -- Allocate fresh `sid = highSid` into `.heap 12[3]` and increment `highSid`
          (.seq (.writeHeap 12 (.lit 3) (.readHeap 12 (.lit 5)))
                (.writeHeap 12 (.lit 5) (.add (.readHeap 12 (.lit 5)) (.lit 1)))))
      (.seq (.writeHeap 13 (.readHeap 12 (.lit 1)) (.add (.readHeap 12 (.lit 3)) (.lit 1)))
      (.seq (.writeHeap 15 (.readHeap 12 (.lit 3)) (.readHeap 12 (.lit 1)))
      (.seq (.writeHeap 16 (.readHeap 12 (.lit 3)) (.lit 1))
            (.freeHeap 12 (.lit 3))))))
      .skip)
    (.seq (.freeHeap 12 (.lit 1)) (.freeHeap 12 (.lit 2)))

def trA2Stmt (T_max : ℕ) : BitRAMStmt → BitRAMStmt
  | .skip => .skip
  | .writeHeap table idxE valE =>
      let encE := IntExpr.add (.mul (trA2Expr T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ))
      .seq (.writeHeap 12 (.lit 1) encE)
      (.seq (.writeHeap 12 (.lit 2) (trA2Expr T_max valE))
      (.seq (.writeHeap 10 (.readHeap 12 (.lit 1)) (.readHeap 12 (.lit 2)))
            trA2LogInsertAfterWrite))
  | .writeLocal var idxE valE =>
      .writeLocal var (trA2Expr T_max idxE) (trA2Expr T_max valE)
  | .freeHeap table idxE =>
      let encE := IntExpr.add (.mul (trA2Expr T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ))
      .ite (.intLt (.lit 0) (.readHeap 13 encE))
        (.seq (.writeHeap 12 (.lit 1) encE)
        (.seq (.writeHeap 12 (.lit 3) (.sub (.readHeap 13 (.readHeap 12 (.lit 1))) (.lit 1)))
        (.seq (.freeHeap 10 (.readHeap 12 (.lit 1)))
        (.seq (.freeHeap 13 (.readHeap 12 (.lit 1)))
        (.seq (.freeHeap 15 (.readHeap 12 (.lit 3)))
        (.seq (.freeHeap 16 (.readHeap 12 (.lit 3)))
        (.seq (.writeHeap 14 (.readHeap 12 (.lit 4)) (.readHeap 12 (.lit 3)))
        (.seq (.writeHeap 12 (.lit 4) (.add (.readHeap 12 (.lit 4)) (.lit 1)))
        (.seq (.freeHeap 12 (.lit 1))
              (.freeHeap 12 (.lit 3)))))))))))
        .skip
  | .freeLocal var idxE =>
      .freeLocal var (trA2Expr T_max idxE)
  | .randBitHeap table idxE =>
      let encE := IntExpr.add (.mul (trA2Expr T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ))
      .seq (.writeHeap 12 (.lit 1) encE)
      (.seq (.randBitHeap 10 (.readHeap 12 (.lit 1)))
            trA2LogInsertAfterWrite)
  | .randBitLocal var idxE =>
      .randBitLocal var (trA2Expr T_max idxE)
  | .seq s₁ s₂ => .seq (trA2Stmt T_max s₁) (trA2Stmt T_max s₂)
  | .ite c tB fB => .ite (trA2Cond T_max c) (trA2Stmt T_max tB) (trA2Stmt T_max fB)
  | .whileLoop c body => .whileLoop (trA2Cond T_max c) (trA2Stmt T_max body)
  | .repeatN countE body => .repeatN (trA2Expr T_max countE) (trA2Stmt T_max body)
  | .localScope body => .localScope (trA2Stmt T_max body)

/-- Reclaims all cells in `.heap 10, 12, 13, 14, 15, 16` after extracting `progA2` outputs. -/
def cleanupA2Stmt : BitRAMStmt :=
  .seq (.writeHeap 12 (.lit 1) (.lit 0))
  (.seq
    (.repeatN (.readHeap 12 (.lit 5))
      (.seq
        (.ite (.intEq (.readHeap 16 (.readHeap 12 (.lit 1))) (.lit 1))
          (.seq (.freeHeap 10 (.readHeap 15 (.readHeap 12 (.lit 1))))
          (.seq (.freeHeap 13 (.readHeap 15 (.readHeap 12 (.lit 1))))
          (.seq (.freeHeap 15 (.readHeap 12 (.lit 1)))
                (.freeHeap 16 (.readHeap 12 (.lit 1))))))
          .skip)
      (.seq (.freeHeap 14 (.readHeap 12 (.lit 1)))
            (.writeHeap 12 (.lit 1) (.add (.readHeap 12 (.lit 1)) (.lit 1))))))
  (.seq (.freeHeap 12 (.lit 1))
  (.seq (.freeHeap 12 (.lit 4))
        (.freeHeap 12 (.lit 5)))))

end UL.C12LVE
