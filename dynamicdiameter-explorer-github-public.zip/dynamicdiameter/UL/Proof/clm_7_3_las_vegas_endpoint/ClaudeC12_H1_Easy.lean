import UL.Stmt.clm_7_3_las_vegas_endpoint
import UL.Stmt.clm_5_1_block_witness
import UL.Stmt.lem_5_2
import UL.Stmt.lem_7_2
set_option autoImplicit false

namespace UL.C12LVE

open UL

/-! ### Helper lemmas on `chainInput`, `indexedEuclideanDiam`, and `IsExactLeafAnswer` -/

lemma nodeResidual_subset_self {d : ℕ} {ι : Type*}
    (N : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) :
    N.residual pts S ⊆ S := by
  classical
  unfold ChainNode.residual nodeResidual
  exact Finset.sdiff_subset

lemma chainInput_go_subset {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (I : Finset ι) :
    ∀ (m : ℕ) (hm : m ≤ k), chainInput.go pts nodes I m hm ⊆ I
  | 0, _ => Finset.Subset.rfl
  | m + 1, hm => by
      dsimp only [chainInput.go]
      exact (nodeResidual_subset_self _ pts _).trans
        (chainInput_go_subset pts nodes I m (Nat.le_of_succ_le hm))

lemma chainInput_subset {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (I : Finset ι)
    (j : Fin (k + 1)) :
    chainInput pts nodes I j ⊆ I :=
  chainInput_go_subset pts nodes I j.val (Nat.lt_succ_iff.mp j.isLt)

lemma chainTerminal_subset {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (I : Finset ι) :
    chainTerminal pts nodes I ⊆ I :=
  chainInput_subset pts nodes I (Fin.last k)

lemma indexedEuclideanDiam_nonneg {ι : Type*} {d : ℕ}
    (I : Finset ι) (pts : ι → EuclideanSpace ℝ (Fin d)) :
    0 ≤ indexedEuclideanDiam I pts := by
  unfold indexedEuclideanDiam
  split_ifs with h
  · obtain ⟨x, hx⟩ := h
    have hmem : (x, x) ∈ I ×ˢ I := Finset.mem_product.mpr ⟨hx, hx⟩
    have hle := Finset.le_sup' (f := fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) hmem
    simpa using hle
  · exact le_rfl

lemma norm_le_indexedEuclideanDiam {ι : Type*} {d : ℕ}
    {I : Finset ι} (pts : ι → EuclideanSpace ℝ (Fin d)) {x y : ι}
    (hx : x ∈ I) (hy : y ∈ I) :
    ‖pts x - pts y‖ ≤ indexedEuclideanDiam I pts := by
  have hne : I.Nonempty := ⟨x, hx⟩
  unfold indexedEuclideanDiam
  rw [dif_pos hne]
  have hmem : (x, y) ∈ I ×ˢ I := Finset.mem_product.mpr ⟨hx, hy⟩
  exact Finset.le_sup' (f := fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) hmem

lemma indexedEuclideanDiam_eq_zero_of_card_le_one {ι : Type*} {d : ℕ}
    {I : Finset ι} (pts : ι → EuclideanSpace ℝ (Fin d)) (hcard : I.card ≤ 1) :
    indexedEuclideanDiam I pts = 0 := by
  unfold indexedEuclideanDiam
  split_ifs with hne
  · apply le_antisymm
    · refine Finset.sup'_le _ _ ?_
      intro xy hxy
      rcases Finset.mem_product.mp hxy with ⟨hx1, hx2⟩
      have heq : xy.1 = xy.2 := Finset.card_le_one.mp hcard xy.1 hx1 xy.2 hx2
      simp [heq]
    · obtain ⟨x, hx⟩ := hne
      have hmem : (x, x) ∈ I ×ˢ I := Finset.mem_product.mpr ⟨hx, hx⟩
      have hle := Finset.le_sup' (f := fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) hmem
      simpa using hle
  · rfl

lemma exactLeaf_to_active {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) (leafPair : Option (ι × ι))
    (hLeaf : IsExactLeafAnswer pts S leafPair) :
    ∃ leafPair' : Option (ι × ι),
      IsActiveNodePair S leafPair' ∧
      baselinePairLength pts leafPair' = indexedEuclideanDiam S pts ∧
      baselinePairLength pts leafPair' = baselinePairLength pts leafPair ∧
      (∀ u v : ι, leafPair = some (u, v) → u ∈ S ∧ v ∈ S ∧ u ≠ v) := by
  unfold IsExactLeafAnswer at hLeaf
  split_ifs at hLeaf with hcard
  · subst hLeaf
    have hdiam : indexedEuclideanDiam S pts = 0 :=
      indexedEuclideanDiam_eq_zero_of_card_le_one pts hcard
    by_cases hne : S.Nonempty
    · obtain ⟨x, hx⟩ := hne
      refine ⟨some (x, x), ⟨hx, hx⟩, ?_, ?_, ?_⟩
      · simp [baselinePairLength, hdiam]
      · simp [baselinePairLength]
      · intro u v h; cases h
    · have hemp : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
      refine ⟨none, hemp, ?_, rfl, ?_⟩
      · simp [baselinePairLength, hdiam]
      · intro u v h; cases h
  · rcases hLeaf with ⟨u, v, hEq, hu, hv, huv, hlen⟩
    refine ⟨leafPair, ?_, ?_, rfl, ?_⟩
    · rw [hEq]; exact ⟨hu, hv⟩
    · rw [hEq]; simpa [baselinePairLength] using hlen
    · intro u' v' hEq'
      rw [hEq] at hEq'
      injection hEq' with hpair
      rcases Prod.mk.inj hpair with ⟨rfl, rfl⟩
      exact ⟨hu, hv, huv⟩

/-! ### Reusable core lemma for Conjunct 1 (and Part 4's checked answer policy) -/

theorem endpoint_answer_of_chain_and_leaf
    (h_lem_5_2 : S_lem_5_2)
    {d n k : ℕ}
    (P : DynamicPointSet d) (hWF : P.WellFormed n)
    (nodes : Fin k → ChainNode d)
    (basePairs : Fin k → Option (ℕ × ℕ))
    (leafPair : Option (ℕ × ℕ))
    (hBase : ∀ i : Fin k,
      (nodes i).SatisfiesBaselineCond P.coords
        (chainInput P.coords nodes P.activeIds i.castSucc) (basePairs i))
    (hLeaf : IsExactLeafAnswer P.coords (chainTerminal P.coords nodes P.activeIds) leafPair) :
    ∃ ans : StoredDiameterAnswer,
      IsValidFactorCAnswer (Real.sqrt 2) P ans ∧
      (0 < P.diam →
        ∃ (cand : Option (ℕ × ℕ)) (id₁ id₂ : ℕ),
          (cand = leafPair ∨ ∃ i : Fin k, cand = basePairs i) ∧
          cand = some (id₁, id₂) ∧
          ans.diameterHandles = some (P.handleOfId id₁, P.handleOfId id₂) ∧
          ans.cachedDistSq = euclideanDistSq (P.coords id₁) (P.coords id₂)) := by
  by_cases hP1 : P.activeIds.card ≤ 1
  · refine ⟨{ diameterHandles := none, cachedDistSq := 0 }, ?_, ?_⟩
    · simp [IsValidFactorCAnswer, hP1]
    · intro hpos
      have hzero : P.diam = 0 :=
        indexedEuclideanDiam_eq_zero_of_card_le_one P.coords hP1
      linarith
  · obtain ⟨leafPair', hAct', hDiam', hEqLen, hLeafMem⟩ :=
      exactLeaf_to_active P.coords (chainTerminal P.coords nodes P.activeIds) leafPair hLeaf
    have h52 := h_lem_5_2 d ℕ k P.coords P.activeIds nodes basePairs leafPair' hBase hAct' hDiam'
    rw [hEqLen] at h52
    rcases Set.mem_Icc.mp h52 with ⟨h52_lo, h52_hi⟩
    by_cases hDiamPos : 0 < P.diam
    · obtain ⟨idx₀, _, hSupEq⟩ :=
        Finset.exists_mem_eq_sup' Finset.univ_nonempty
          (Fin.lastCases (baselinePairLength P.coords leafPair)
            (fun i : Fin k => baselinePairLength P.coords (basePairs i)))
      let cand : Option (ℕ × ℕ) := Fin.lastCases leafPair basePairs idx₀
      have hCandLen :
          baselinePairLength P.coords cand =
            Fin.lastCases (baselinePairLength P.coords leafPair)
              (fun i : Fin k => baselinePairLength P.coords (basePairs i)) idx₀ := by
        dsimp [cand]
        rcases Fin.eq_castSucc_or_eq_last idx₀ with ⟨i, rfl⟩ | rfl
        · simp
        · simp
      rw [hSupEq, ← hCandLen] at h52_lo h52_hi
      have hLower : P.diam / Real.sqrt 2 ≤ baselinePairLength P.coords cand := h52_lo
      have hUpper : baselinePairLength P.coords cand ≤ P.diam := h52_hi
      have hCandPos : 0 < baselinePairLength P.coords cand := by
        have hsq2 : 0 < Real.sqrt 2 := Real.sqrt_pos.mpr (by norm_num)
        exact lt_of_lt_of_le (div_pos hDiamPos hsq2) hLower
      cases hCand : cand with
      | none =>
          rw [hCand] at hCandPos
          simp [baselinePairLength] at hCandPos
      | some uv =>
          rcases uv with ⟨id₁, id₂⟩
          have hNormPos : 0 < ‖P.coords id₁ - P.coords id₂‖ := by
            simpa [hCand, baselinePairLength] using hCandPos
          have hNeId : id₁ ≠ id₂ := by
            intro heq
            subst heq
            simp at hNormPos
          have hMemAndChoice :
              (cand = leafPair ∨ ∃ i : Fin k, cand = basePairs i) ∧
              id₁ ∈ P.activeIds ∧ id₂ ∈ P.activeIds := by
            rcases Fin.eq_castSucc_or_eq_last idx₀ with ⟨i, rfl⟩ | rfl
            · have hCandI : basePairs i = some (id₁, id₂) := by
                simpa [cand] using hCand
              have hActI := (hBase i).1
              rw [hCandI] at hActI
              rcases hActI with ⟨hu, hv⟩
              have hsub := chainInput_subset P.coords nodes P.activeIds i.castSucc
              exact ⟨Or.inr ⟨i, by simp [cand]⟩, hsub hu, hsub hv⟩
            · have hCandL : leafPair = some (id₁, id₂) := by
                simpa [cand] using hCand
              obtain ⟨hu, hv, _⟩ := hLeafMem id₁ id₂ hCandL
              have hsub := chainTerminal_subset P.coords nodes P.activeIds
              exact ⟨Or.inl (by simp [cand]), hsub hu, hsub hv⟩
          rcases hMemAndChoice with ⟨hChoice, hid₁, hid₂⟩
          let h₁ := P.handleOfId id₁
          let h₂ := P.handleOfId id₂
          have hh₁ := hWF.2.1 id₁ hid₁
          have hh₂ := hWF.2.1 id₂ hid₂
          have hNeH : h₁ ≠ h₂ := by
            intro heq
            apply hNeId
            calc id₁ = P.idOfHandle h₁ := hh₁.2.symm
              _ = P.idOfHandle h₂ := by rw [heq]
              _ = id₂ := hh₂.2
          let ans : StoredDiameterAnswer :=
            { diameterHandles := some (h₁, h₂)
              cachedDistSq := euclideanDistSq (P.coords id₁) (P.coords id₂) }
          refine ⟨ans, ?_, ?_⟩
          · unfold IsValidFactorCAnswer
            rw [if_neg hP1]
            refine ⟨h₁, h₂, rfl, hh₁.1, hh₂.1, hNeH, ?_, ?_⟩
            · dsimp only [ans, h₁, h₂]; rw [hh₁.2, hh₂.2]
            · dsimp only [h₁, h₂]; rw [hh₁.2, hh₂.2]
              refine ⟨hid₁, hid₂, hNeId, ?_, ?_⟩
              · simpa [DynamicPointSet.diam, hCand, baselinePairLength] using hLower
              · simpa [DynamicPointSet.diam, hCand, baselinePairLength] using hUpper
          · intro _
            exact ⟨cand, id₁, id₂, hChoice, hCand, rfl, rfl⟩
    · have hDiamNonneg : 0 ≤ P.diam := indexedEuclideanDiam_nonneg P.activeIds P.coords
      have hDiamZero : P.diam = 0 := le_antisymm (not_lt.mp hDiamPos) hDiamNonneg
      have hCardGt1 : 1 < P.activeIds.card := Nat.lt_of_not_ge hP1
      obtain ⟨id₁, hid₁, id₂, hid₂, hNeId⟩ := Finset.one_lt_card.mp hCardGt1
      let h₁ := P.handleOfId id₁
      let h₂ := P.handleOfId id₂
      have hh₁ := hWF.2.1 id₁ hid₁
      have hh₂ := hWF.2.1 id₂ hid₂
      have hNeH : h₁ ≠ h₂ := by
        intro heq
        apply hNeId
        calc id₁ = P.idOfHandle h₁ := hh₁.2.symm
          _ = P.idOfHandle h₂ := by rw [heq]
          _ = id₂ := hh₂.2
      have hDistLe : ‖P.coords id₁ - P.coords id₂‖ ≤ P.diam :=
        norm_le_indexedEuclideanDiam P.coords hid₁ hid₂
      have hDistZero : ‖P.coords id₁ - P.coords id₂‖ = 0 :=
        le_antisymm (hDistLe.trans_eq hDiamZero) (norm_nonneg _)
      let ans : StoredDiameterAnswer :=
        { diameterHandles := some (h₁, h₂)
          cachedDistSq := euclideanDistSq (P.coords id₁) (P.coords id₂) }
      refine ⟨ans, ?_, ?_⟩
      · unfold IsValidFactorCAnswer
        rw [if_neg hP1]
        refine ⟨h₁, h₂, rfl, hh₁.1, hh₂.1, hNeH, ?_, ?_⟩
        · dsimp only [ans, h₁, h₂]; rw [hh₁.2, hh₂.2]
        · dsimp only [h₁, h₂]; rw [hh₁.2, hh₂.2]
          refine ⟨hid₁, hid₂, hNeId, ?_, ?_⟩
          · change P.diam / Real.sqrt 2 ≤ ‖P.coords id₁ - P.coords id₂‖
            rw [hDiamZero, hDistZero]; simp
          · exact hDistLe
      · intro hpos
        exact absurd hpos hDiamPos

/-! ### Proof of Conjunct 1 -/

theorem prove_part1 (h_lem_5_2 : S_lem_5_2) :
    backgroundIndexModeForFactor (Real.sqrt 2) = .radiusDictOnly ∧
    ∀ (d n k : ℕ), 2 ≤ n →
      ∀ (P : DynamicPointSet d), P.WellFormed n →
        ∀ (nodes : Fin k → ChainNode d)
          (maxPts : Fin k → Option ℕ)
          (basePairs : Fin k → Option (ℕ × ℕ))
          (leafPair : Option (ℕ × ℕ)),
          (∀ i : Fin k,
            let S_i := chainInput P.coords nodes P.activeIds i.castSucc
            (S_i = ∅ → maxPts i = none) ∧
            (S_i.Nonempty → ∃ y : ℕ, maxPts i = some y ∧ (nodes i).IsMaxRadiusPoint P.coords S_i y)) →
          (∀ i : Fin k,
            (nodes i).SatisfiesBaselineCond P.coords
              (chainInput P.coords nodes P.activeIds i.castSucc) (basePairs i)) →
          IsExactLeafAnswer P.coords (chainTerminal P.coords nodes P.activeIds) leafPair →
            ∃ ans : StoredDiameterAnswer,
              IsValidFactorCAnswer (Real.sqrt 2) P ans ∧
              (0 < P.diam →
                ∃ (cand : Option (ℕ × ℕ)) (id₁ id₂ : ℕ),
                  (cand = leafPair ∨ ∃ i : Fin k, cand = basePairs i) ∧
                  cand = some (id₁, id₂) ∧
                  ans.diameterHandles = some (P.handleOfId id₁, P.handleOfId id₂) ∧
                  ans.cachedDistSq = euclideanDistSq (P.coords id₁) (P.coords id₂)) := by
  refine ⟨?_, ?_⟩
  · unfold backgroundIndexModeForFactor
    simp
  · intro d n k _ P hWF nodes _ basePairs leafPair _ hBase hLeaf
    exact endpoint_answer_of_chain_and_leaf h_lem_5_2 P hWF nodes basePairs leafPair hBase hLeaf

/-! ### Proof of Conjunct 2 -/

theorem prove_part2 (h_clm_5_1_block_witness : S_clm_5_1_block_witness) :
    ∀ (d : ℕ) (ι : Type) (pts : ι → EuclideanSpace ℝ (Fin d))
      (P₀ S : Finset ι) (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
      (cert : BlockCertificate pts P₀ (liftedPoint o s)) (y : ι),
      cert.IsIntact S →
      IsNodeMaxRadiusPoint pts o S y →
        ∃ p ∈ cert.B,
          IsNodeBaselinePair pts o (liftVariance o s) S p y ∧
          SatisfiesNodeBaselineCond pts o (liftVariance o s) S (some (p, y)) := by
  intro d ι pts P₀ S o s cert y hIntact hy
  letI : DecidableEq ι := Classical.decEq ι
  have hBne : cert.B.Nonempty := by
    by_contra hemp
    rw [Finset.not_nonempty_iff_eq_empty] at hemp
    have hsum := cert.sum_coeff
    rw [hemp, Finset.sum_empty] at hsum
    norm_num at hsum
  have hP0ne : P₀.Nonempty := hBne.mono cert.subset_birth
  have hP0pos : (0 : ℝ) < (P₀.card : ℝ) := Nat.cast_pos.mpr hP0ne.card_pos
  let β : ℝ := 1 / (2 * (P₀.card : ℝ))
  have hβm_eq : β * (P₀.card : ℝ) = 1 / 2 := by
    dsimp [β]
    field_simp [hP0pos.ne']
  have hβm_pos : 0 < β * (P₀.card : ℝ) := by linarith
  have hr0 : β * (P₀.card : ℝ) ≤ ((1 : ℕ) : ℝ) := by
    rw [hβm_eq]; norm_num
  have hdisj : Pairwise (fun j₁ j₂ : Fin 1 => Disjoint ((fun _ => cert) j₁).B ((fun _ => cert) j₂).B) := by
    intro j₁ j₂ hne
    exact absurd (Subsingleton.elim j₁ j₂) hne
  have hBW := (h_clm_5_1_block_witness d ι pts P₀ o s β 1 (fun _ => cert) hβm_pos hr0 hdisj).1
    S 0 hIntact
  obtain ⟨p, hpB, hyp⟩ := hBW.2.2 y hy
  rcases hyp with ⟨hyS, hpS, hDist⟩
  have hp_y : IsNodeBaselinePair pts o (liftVariance o s) S p y := by
    refine ⟨hpS, hyS, ?_⟩
    rw [norm_sub_rev (pts p) (pts y)]
    exact hDist
  refine ⟨p, hpB, hp_y, ?_⟩
  refine ⟨⟨hpS, hyS⟩, ?_⟩
  intro _
  simpa [baselinePairLength] using hp_y.2.2

/-! ### Proof of Conjunct 3 -/

private lemma add_three_le_two_pow_add_two : ∀ d : ℕ, d + 3 ≤ 2 ^ (d + 2)
  | 0 => by decide
  | d + 1 => by
      have ih := add_three_le_two_pow_add_two d
      rw [show d + 1 + 2 = (d + 2) + 1 by omega, pow_succ]
      omega

private noncomputable def part3Factor : ℝ := ((3 : ℝ) ^ 19) * ((4 : ℝ) ^ 18)

private lemma part3Factor_nonneg : 0 ≤ part3Factor := by
  unfold part3Factor
  positivity

private lemma part3_monotone_factor
    (d n t : ℕ) (hn : 2 ≤ n) (ht : 1 ≤ t) (δ : ℝ) (hδ0 : 0 < δ) :
    (((d + 3 : ℕ) : ℝ) ^ 19) *
      ((Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ)) : ℝ) ^ 18) ≤
    part3Factor * ((d + 1 : ℝ) ^ 37) *
      (((Nat.ceil (Real.logb 2 ((2 * (n : ℝ) * (t : ℝ)) / δ)) : ℝ) + 1) ^ 37) := by
  set D : ℕ := d + 3
  set L : ℕ := Nat.ceil (Real.logb 2 ((2 * (n : ℝ) * (t : ℝ)) / δ))
  set H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
  have hD_le : (D : ℝ) ≤ 3 * ((d + 1 : ℝ)) := by
    change ((d + 3 : ℕ) : ℝ) ≤ 3 * ((d + 1 : ℝ))
    push_cast; linarith
  have hX_pos : 0 < (2 * (n : ℝ) * (t : ℝ)) / δ := by
    have hn0 : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (by omega : 0 < n)
    have ht0 : (0 : ℝ) < (t : ℝ) := by exact_mod_cast (by omega : 0 < t)
    positivity
  have hD_pos : (0 : ℝ) < (D : ℝ) := by
    change (0 : ℝ) < ((d + 3 : ℕ) : ℝ)
    positivity
  have hEqArg : (2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ =
      (D : ℝ) * ((2 * (n : ℝ) * (t : ℝ)) / δ) := by ring
  have hLogD : Real.logb 2 (D : ℝ) ≤ ((d + 2 : ℕ) : ℝ) := by
    have hPow : (D : ℝ) ≤ (2 : ℝ) ^ (d + 2) := by
      change ((d + 3 : ℕ) : ℝ) ≤ (2 : ℝ) ^ (d + 2)
      exact_mod_cast add_three_le_two_pow_add_two d
    calc Real.logb 2 (D : ℝ)
        ≤ Real.logb 2 ((2 : ℝ) ^ (d + 2)) :=
          Real.logb_le_logb_of_le (by norm_num) hD_pos hPow
      _ = ((d + 2 : ℕ) : ℝ) := by
          rw [Real.logb_pow, Real.logb_self_eq_one (by norm_num)]
          ring
  have hLogProd : Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ) ≤
      ((d + 2 + L : ℕ) : ℝ) := by
    rw [hEqArg, Real.logb_mul hD_pos.ne' hX_pos.ne']
    have hCeil : Real.logb 2 ((2 * (n : ℝ) * (t : ℝ)) / δ) ≤ (L : ℝ) := Nat.le_ceil _
    push_cast at hLogD ⊢
    linarith
  have hH_nat : H ≤ d + 2 + L := Nat.ceil_le.mpr hLogProd
  have hH_le : (H : ℝ) ≤ 4 * ((d + 1 : ℝ)) * ((L : ℝ) + 1) := by
    have hH_cast : (H : ℝ) ≤ ((d + 2 + L : ℕ) : ℝ) := by exact_mod_cast hH_nat
    push_cast at hH_cast
    nlinarith
  have hPow19 : (D : ℝ) ^ 19 ≤ (3 * ((d + 1 : ℝ))) ^ 19 :=
    pow_le_pow_left₀ (by positivity) hD_le 19
  have hPow18 : (H : ℝ) ^ 18 ≤ (4 * ((d + 1 : ℝ)) * ((L : ℝ) + 1)) ^ 18 :=
    pow_le_pow_left₀ (by positivity) hH_le 18
  have hL_pow : ((L : ℝ) + 1) ^ 18 ≤ ((L : ℝ) + 1) ^ 37 :=
    pow_le_pow_right₀ (by have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith) (by omega)
  have hStep1 : ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18) ≤
      ((3 * ((d + 1 : ℝ))) ^ 19) * ((4 * ((d + 1 : ℝ)) * ((L : ℝ) + 1)) ^ 18) :=
    mul_le_mul hPow19 hPow18 (by positivity) (by positivity)
  have hStep2 : ((3 * ((d + 1 : ℝ))) ^ 19) * ((4 * ((d + 1 : ℝ)) * ((L : ℝ) + 1)) ^ 18) =
      part3Factor * ((d + 1 : ℝ) ^ 37) * (((L : ℝ) + 1) ^ 18) := by
    unfold part3Factor
    rw [mul_pow, mul_pow, mul_pow]
    generalize (3 : ℝ) ^ 19 = A
    generalize (4 : ℝ) ^ 18 = B
    generalize (d + 1 : ℝ) = X
    generalize (L : ℝ) + 1 = Y
    ring
  have hStep3 : part3Factor * ((d + 1 : ℝ) ^ 37) * (((L : ℝ) + 1) ^ 18) ≤
      part3Factor * ((d + 1 : ℝ) ^ 37) * (((L : ℝ) + 1) ^ 37) := by
    have hPF : 0 ≤ part3Factor * ((d + 1 : ℝ) ^ 37) :=
      mul_nonneg part3Factor_nonneg (by positivity)
    exact mul_le_mul_of_nonneg_left hL_pow hPF
  exact (hStep1.trans_eq hStep2).trans hStep3

theorem prove_part3 (h_lem_7_2 : S_lem_7_2) :
    ∃ (polyTime polySpace : ℕ → ℕ → ℝ) (queryConst writeFactor : ℕ),
      IsBoundedByPoly2 polyTime ∧
      IsBoundedByPoly2 polySpace ∧
      ∀ (d n t : ℕ), 2 ≤ n → 1 ≤ t →
        ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
          let logTerm : ℕ := Nat.ceil (Real.logb 2 ((2 * (n : ℝ) * (t : ℝ)) / δ))
          ∃ (prog : ArithRAMDynamicProgram) (initOut : ArithRAMExecOutcome),
            prog.evalInit n d = some initOut ∧
            let alg : DynamicDiameterStructure d ArithRAMMemory :=
              { initState := initOut.mem
                initWork := initOut.unitCost
                initSpace := initOut.peakCellSpace
                cachedAnswer := fun mem =>
                  let ca := ArithRAMDynamicProgram.readCachedAnswer mem
                  { diameterHandles := ca.1, cachedDistSq := ca.2 }
                retrieveIdsAndRefCost := 4
                writeOutputCost := fun len => len + 1
                stepWithBits := fun activeH hCoords mem uop bs =>
                  let rawOut :=
                    match uop with
                    | .insert pt => prog.evalUpdate n activeH hCoords mem true pt 0 bs
                    | .delete h => prog.evalUpdate n activeH hCoords mem false 0 h bs
                  rawOut.map (fun out =>
                    let ca := ArithRAMDynamicProgram.readCachedAnswer out.mem
                    { nextState := out.mem
                      returnedHandle :=
                        match uop with
                        | .insert _ => ArithRAMDynamicProgram.readReturnedHandle out.mem
                        | .delete _ => none
                      storedAnswer := { diameterHandles := ca.1, cachedDistSq := ca.2 }
                      work := out.unitCost
                      peakSpace := out.peakCellSpace }) }
            SatisfiesDynamicStorageAndQueryModel queryConst writeFactor alg ∧
            SatisfiesMonteCarloGuarantee n t δ (Real.sqrt 2) Set.univ alg ∧
            SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg
              (polyTime d logTerm) ∧
            SatisfiesBoundedSpaceBound n t Set.univ alg
              ((n : ℝ) * polySpace d logTerm) := by
  obtain ⟨C_time, C_space, queryConst, writeFactor, hCt_pos, hCs_pos, h72⟩ := h_lem_7_2
  refine ⟨fun d L => C_time * part3Factor * ((d + 1 : ℝ) ^ 37) * ((L + 1 : ℝ) ^ 37),
          fun d L => C_space * part3Factor * ((d + 1 : ℝ) ^ 37) * ((L + 1 : ℝ) ^ 37),
          queryConst, writeFactor,
          ⟨C_time * part3Factor, 37, mul_nonneg hCt_pos.le part3Factor_nonneg, fun _ _ => le_rfl⟩,
          ⟨C_space * part3Factor, 37, mul_nonneg hCs_pos.le part3Factor_nonneg, fun _ _ => le_rfl⟩,
          ?_⟩
  intro d n t hn ht δ hδ0 hδ1 logTerm
  obtain ⟨prog, initOut, hInit, hModel, hMC, hWork, hSpace⟩ := h72 d n t hn ht δ hδ0 hδ1
  have hFac := part3_monotone_factor d n t hn ht δ hδ0
  have hMonW : C_time * (((d + 3 : ℕ) : ℝ) ^ 19) *
      ((Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ)) : ℝ) ^ 18) ≤
      C_time * part3Factor * ((d + 1 : ℝ) ^ 37) * ((logTerm + 1 : ℝ) ^ 37) := by
    have h1 := mul_le_mul_of_nonneg_left hFac hCt_pos.le
    dsimp only [logTerm] at h1 ⊢
    linarith
  have hMonS : C_space * (n : ℝ) * (((d + 3 : ℕ) : ℝ) ^ 19) *
      ((Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ)) : ℝ) ^ 18) ≤
      (n : ℝ) * (C_space * part3Factor * ((d + 1 : ℝ) ^ 37) * ((logTerm + 1 : ℝ) ^ 37)) := by
    have hCn : 0 ≤ C_space * (n : ℝ) := by positivity
    have h1 := mul_le_mul_of_nonneg_left hFac hCn
    dsimp only [logTerm] at h1 ⊢
    linarith
  exact ⟨prog, initOut, hInit, hModel, hMC,
    ⟨hWork.1.trans hMonW, fun adv hadv T hT trace out hout w hw =>
      (hWork.2 adv hadv T hT trace out hout w hw).trans hMonW⟩,
    ⟨hSpace.1.trans hMonS, fun adv hadv T hT trace out hout =>
      (hSpace.2 adv hadv T hT trace out hout).trans hMonS⟩⟩

end UL.C12LVE
