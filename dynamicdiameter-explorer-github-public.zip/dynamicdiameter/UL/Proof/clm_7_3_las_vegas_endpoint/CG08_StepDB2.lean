import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.CG08_StepDB1
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

theorem exec_scanAllLevelsRegs {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hL1 : 1 ≤ L) (h2n : 2 * n ≤ 2 ^ L) (hB1 : 1 ≤ B)
    (hW : 2 * sqRadBitBound d B B_cert + d * (8 * B + 24) +
          natBitLength ((K_max + 2) * posNodeStride d L) + natBitLength s₀_d + natBitLength d + L + 40 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {wsRef ws : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap wsRef)
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hn120 : (.heap 9 120 : RAMCellLoc) ∉ ws.live)
    (hn121 : (.heap 9 121 : RAMCellLoc) ∉ ws.live)
    (hn122 : (.heap 9 122 : RAMCellLoc) ∉ ws.live)
    (hunchRef : ∀ loc : RAMCellLoc, ¬ isAnsHeaderLoc loc → loc ∉ treeSliceLocs L 0 →
      (loc ∈ ws.live ↔ loc ∈ wsRef.live) ∧ ws.vals loc = wsRef.vals loc)
    {init : ℕ × ℕ} (hbest : BestPairStored B P init ws)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (scanAllLevelsRegs d s₀_d L) ws regs wsEnd regsEnd
        ((nodes.length + 1) * (s₀_d * (220 * d + 200) + 64 * L + 380))
        ((nodes.length + 1) * (s₀_d * (52 * d + 48) + 12 * L + 68) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      BestPairStored B P
        (foldBestPairs P init ((List.finRange nodes.length).flatMap (levelScanCands L P nodes))) wsEnd ∧
      (∀ loc : RAMCellLoc, ¬ isBestPairLoc loc →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  have hW32 : 32 ≤ W := by omega
  have hCeilC : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hCeilB : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  obtain ⟨cs0, bs0⟩ := hmod.space_le
  have hl0 : intBitLength (0 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl10 : intBitLength (10 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl120 : intBitLength (120 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hn0 : natBitLength 0 ≤ W := Nat.le_trans (by decide) hW32
  have hn9 : natBitLength 9 ≤ W := Nat.le_trans (by decide) hW32
  have hk_le_N : nodes.length ≤ (K_max + 2) * posNodeStride d L := by
    have : posNodeStride d L ≥ 1 := by unfold posNodeStride; omega
    exact (Nat.le_trans hinv.hk_le (by omega)).trans (Nat.le_mul_of_pos_right _ this)
  have hk_bl : intBitLength (nodes.length : ℤ) ≤ W :=
    natCast_bitLength_le_of_le hk_le_N (by omega)
  have spC0 : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell := by linarith only [cs0, hCeilC]
  have spB0 : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit := by linarith only [bs0, hCeilB]
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd spC0 spB0
    (dst := 13) (c := 0) (by decide) hl0
  set g1 := Function.update regs 13 0; have bg1 := hbnd.update (r := 13) (by decide) hl0
  obtain ⟨s2, hm1, bg2⟩ := exec_litStoreHeap hfd_le hmod hCeilC hCeilB bg1
    (table := 9) (valReg := 13) (c := 120) (by decide) (by decide) hn9 hl120
    (mem_posDimWriteLocs_tab9 (by decide)) (Nat.le_trans (by decide) hW32)
  set ws1 := ws.write (.heap 9 120) (g1 13)
  set g2 := Function.update g1 10 120
  have hread_k1 : ws1.read (.heap 0 10) = (nodes.length : ℤ) := by
    rw [wordStore_read_write_ne ws (by decide), wordStore_read_eq_vals hmod.wf,
        (hunchRef (.heap 0 10) (by rintro (h | h | h | h | h) <;> cases h) (not_in_treeSlice_of_table_ne (by decide) _)).2,
        ← wordStore_read_eq_vals hinv.mod.wf]
    exact hinv.read_k
  obtain ⟨s3, bg3⟩ := exec_litLoadHeap hfd_le hm1 hCeilC hCeilB bg2 (dst := 5) (table := 0) (c := 10)
    (by decide) hn0 hl10 hread_k1 hk_bl
  set g3 := Function.update (Function.update g2 10 10) 5 (nodes.length : ℤ)
  let OuterInv : ℕ → WordStore → (ℕ → ℤ) → Prop := fun j w r =>
    j ≤ nodes.length ∧
    ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
    RegBounded W r ∧
    BestPairStored B P
      (foldBestPairs P init (((List.finRange nodes.length).take j).flatMap (levelScanCands L P nodes))) w ∧
    w.read (.heap 9 120) = (j : ℤ) ∧
    (.heap 9 121 : RAMCellLoc) ∉ w.live ∧
    (.heap 9 122 : RAMCellLoc) ∉ w.live ∧
    (∀ loc : RAMCellLoc, ¬ isBestPairLoc loc → loc ≠ .heap 9 120 →
      (loc ∈ w.live ↔ loc ∈ ws.live) ∧ w.vals loc = ws.vals loc)
  have hOuter0 : OuterInv 0 ws1 g3 := by
    refine ⟨Nat.zero_le _, hm1, bg3, ?_, ?_, ?_, ?_, ?_⟩
    · simpa using (hbest.of_unchanged_vals hmod.wf hm1.wf (fun i _ _ => by simp [ws1, WordStore.write]))
    · simp [ws1, g1, WordStore.read, WordStore.write]
    · simp [ws1, WordStore.write, hn121]
    · simp [ws1, WordStore.write, hn122]
    · intro loc _ hne120
      exact ⟨by simp [ws1, WordStore.write, hne120], by simp [ws1, WordStore.write, Function.update_of_ne hne120]⟩
  obtain ⟨wsLoop, regsLoop, s4, hOuterEnd⟩ :=
    RegExec.repeatReg_inv (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      (cntReg := 5) (by decide) nodes.length (by simp [g3]) OuterInv hOuter0 bg3
      (U := s₀_d * (220 * d + 200) + 64 * L + 340)
      (B := (s₀_d * (52 * d + 48) + 12 * L + 60) * W * W)
      (fun j hj wCur rCur ⟨_, hmCur, brCur, hbestCur, hr120Cur, hn121Cur, hn122Cur, hunchCur⟩ => by
        have hunchCurRef : ∀ loc : RAMCellLoc, ¬ isAnsHeaderLoc loc → loc ∉ treeSliceLocs L 0 → loc ≠ .heap 9 120 →
            (loc ∈ wCur.live ↔ loc ∈ wsRef.live) ∧ wCur.vals loc = wsRef.vals loc := by
          intro loc hna hns hne120
          have hnb : ¬ isBestPairLoc loc := fun hb => hna (Or.inr hb)
          have u1 := hunchCur loc hnb hne120
          have u2 := hunchRef loc hna hns
          exact ⟨u1.1.trans u2.1, u1.2.trans u2.2⟩
        obtain ⟨wNext, rNext, sStep, hmNext, brNext, hbestNext, hr120Next, hn121Next, hn122Next, hunchStep⟩ :=
          exec_levelScanStepRegs hd1 hL1 h2n hB1 hW hfd_le hinv hmCur hcCeil hbCeil hj
            hr120Cur hn121Cur hn122Cur hunchCurRef hbestCur brCur
        have hbestNext' : BestPairStored B P
            (foldBestPairs P init (((List.finRange nodes.length).take (j + 1)).flatMap (levelScanCands L P nodes))) wNext := by
          rw [finRange_take_succ hj, List.flatMap_append, List.flatMap_singleton, foldBestPairs_append]
          exact hbestNext
        refine ⟨wNext, rNext, sStep, Nat.succ_le_of_lt hj, hmNext, brNext, hbestNext', hr120Next, hn121Next, hn122Next, ?_⟩
        intro loc hnb hne120
        exact ⟨(hunchStep loc hnb hne120).1.trans (hunchCur loc hnb hne120).1,
               (hunchStep loc hnb hne120).2.trans (hunchCur loc hnb hne120).2⟩)
  rcases hOuterEnd with ⟨_, hmLoop, brLoop, hbestLoop, _, _, _, hunchLoop⟩
  rw [finRange_take_self] at hbestLoop
  obtain ⟨s5, hmEnd, brEnd⟩ := exec_litFreeHeap hfd_le hmLoop hCeilC hCeilB brLoop hn9 hl120
    (mem_posDimWriteLocs_tab9 (by decide))
  set wsEnd := wsLoop.free (.heap 9 120)
  have hbestEnd : BestPairStored B P
      (foldBestPairs P init ((List.finRange nodes.length).flatMap (levelScanCands L P nodes))) wsEnd :=
    hbestLoop.of_unchanged_vals hmLoop.wf hmEnd.wf (fun i _ _ => by simp [wsEnd, WordStore.free])
  have sTot := (s1.seq (s2.seq (s3.seq (s4.seq s5)))).weaken
    rfl rfl (u₂ := (nodes.length + 1) * (s₀_d * (220 * d + 200) + 64 * L + 380))
    (b₂ := (nodes.length + 1) * (s₀_d * (52 * d + 48) + 12 * L + 68) * W * W)
    (by clear * -; nlinarith) (by
      have hWW : 60 * W + 300 ≤ 68 * W * W := by nlinarith only [hW32]
      have hnn : 0 ≤ (nodes.length * 8 + s₀_d * (52 * d + 48) + 12 * L) * W * W := by positivity
      have heq : (nodes.length + 1) * (s₀_d * (52 * d + 48) + 12 * L + 68) * W * W =
          nodes.length * ((s₀_d * (52 * d + 48) + 12 * L + 60) * W * W) +
          (nodes.length * 8 + s₀_d * (52 * d + 48) + 12 * L) * W * W + 68 * W * W := by ring
      rw [heq]; linarith only [hWW, hnn, hW32])
  refine ⟨wsEnd, _, sTot, hmEnd, brEnd, hbestEnd, ?_⟩
  intro loc hnb
  by_cases h120 : loc = .heap 9 120
  · subst h120
    exact ⟨by simp [wsEnd, WordStore.free, hn120], by simp [wsEnd, WordStore.free, hmod.wf _ hn120]⟩
  · have uL := hunchLoop loc hnb h120
    exact ⟨by simp [wsEnd, WordStore.free, h120, uL.1],
           by simp [wsEnd, WordStore.free, Function.update_of_ne h120, uL.2]⟩

/-! ### 3. Leaf All-Pairs Scan (`scanLeafPairsRegs`) -/

def leafInnerStepRegs (d : ℕ) : BitRAMStmt :=
  .seq (.seq (rLit 10 120) (rLoad 13 9 10))
  (.seq (rLoad 1 8 13)
  (.seq (.seq (rLit 10 121) (rLoad 13 9 10))
  (.seq (rLoad 2 8 13)
  (.seq (considerCandRegs d)
        (incrHeap9Regs 121)))))

def leafOuterStepRegs (d : ℕ) : BitRAMStmt :=
  .seq (rLit 13 0)
  (.seq (.seq (rLit 10 121) (rStore 9 10 13))
  (.seq (.seq (rLit 10 110) (rLoad 5 9 10))
  (.seq (.repeatN (.readLocal 5 (.lit 0)) (leafInnerStepRegs d))
  (.seq (.seq (rLit 10 121) (rFree 9 10))
        (incrHeap9Regs 120)))))

def leafPairLoopRegs (d : ℕ) : BitRAMStmt :=
  .seq (rLit 13 0)
  (.seq (.seq (rLit 10 120) (rStore 9 10 13))
  (.seq (.seq (rLit 10 110) (rLoad 5 9 10))
  (.seq (.repeatN (.readLocal 5 (.lit 0)) (leafOuterStepRegs d))
        (.seq (rLit 10 120) (rFree 9 10)))))

def scanLeafPairsRegs (d L : ℕ) : BitRAMStmt :=
  .seq (rLit 0 1)
  (.seq (popTreeToBufRegs L)
  (.seq (leafPairLoopRegs d)
  (.seq (rLit 0 1)
  (.seq (insertBufToUnitTreeRegs L)
        freeBufRegs))))

theorem exec_scanLeafPairsRegs {d s₀_d n L B B_cert K_max W : ℕ}
    (hd1 : 1 ≤ d) (hL1 : 1 ≤ L) (hB1 : 1 ≤ B)
    (hW : d * (8 * B + 24) + natBitLength d + L + 32 ≤ W)
    {inp : BitRAMInput d} {fd C_cell C_bit : ℕ} (hfd_le : fd ≤ 4)
    {P : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {nodes : List (SyncLiveChainNode d (PosDimNodeData d s₀_d))}
    {qMap : ℕ → Fin d → ℚ} {wsRef ws : WordStore}
    (hinv : ChainStoredInv n L B B_cert K_max W P ltCoords nodes qMap wsRef)
    (hmod : ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W ws)
    (hcCeil : inp.inputCellSpace + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit)
    (hunchRef : ∀ loc : RAMCellLoc, ¬ isAnsHeaderLoc loc → loc ∉ treeSliceLocs L 0 →
      (loc ∈ ws.live ↔ loc ∈ wsRef.live) ∧ ws.vals loc = wsRef.vals loc)
    {init : ℕ × ℕ} (hbest : BestPairStored B P init ws)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs) :
    let vecNodes : Fin nodes.length → ChainNode d := fun i => (nodes.get i).built.node
    let S_k_lt := chainInput ltCoords vecNodes (activeLifetimes P) (Fin.last nodes.length)
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (scanLeafPairsRegs d L) ws regs wsEnd regsEnd
        ((4 * s₀_d + 1) * (4 * s₀_d + 1) * (220 * d + 320) + (4 * s₀_d + 1) * (880 * L + 800))
        (((4 * s₀_d + 1) * (4 * s₀_d + 1) * (52 * d + 64) + (4 * s₀_d + 1) * (140 * L + 240)) * W * W) ∧
      ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L 1 (S_k_lt.image (handleOfLifetime P)) (fun _ => 0) (fun _ => 1) wsEnd ∧
      BestPairStored B P (foldBestPairs P init (leafScanCands P nodes)) wsEnd ∧
      (∀ loc : RAMCellLoc, ¬ isBestPairLoc loc → loc ∉ treeSliceLocs L 1 →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  intro vecNodes S_k_lt
  have hW32 : 32 ≤ W := by omega
  have hCeilC : inp.inputCellSpace + WordStore.empty.cellCount + (posDimWriteLocs d L K_max).card + 16 ≤ C_cell := by
    simpa [WordStore.cellCount, WordStore.empty] using hcCeil
  have hCeilB : inp.inputBitSpace + WordStore.empty.bitSize + 2 * W * (posDimWriteLocs d L K_max).card + 16 * (W + 12) ≤ C_bit := by
    simpa [WordStore.bitSize, WordStore.empty] using hbCeil
  have sp_ok : ∀ {w : WordStore}, ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w →
      inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
      inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
    intro w hm; obtain ⟨cs, bs⟩ := hm.space_le
    exact ⟨by linarith only [cs, hCeilC], by linarith only [bs, hCeilB]⟩
  set S_k_h := chainInput (fun h => P.coords (P.idOfHandle h)) vecNodes P.activeHandles (Fin.last nodes.length)
  have hlt_to_h : ∀ lt ∈ activeLifetimes P,
      P.coords (P.idOfHandle (handleOfLifetime P lt)) = ltCoords lt := by
    intro lt hlt
    rcases Finset.mem_image.mp hlt with ⟨id₀, hid₀, rfl⟩
    rw [handleOfLifetime_of_mem hinv.wfP hid₀, (hinv.wfP.2.1 id₀ hid₀).2, (hinv.hlt_sync id₀ hid₀).1]
  have hSk_eq : S_k_lt.image (handleOfLifetime P) = S_k_h := by
    rw [chainInput_image_eq ltCoords (fun h => P.coords (P.idOfHandle h)) vecNodes
          (activeLifetimes P) (handleOfLifetime P) hlt_to_h (Fin.last nodes.length),
        image_handleOfLifetime_active hinv.wfP]
  set M := S_k_h.card
  have hM_le_4s : M ≤ 4 * s₀_d := by
    have hc_img : S_k_h.card ≤ S_k_lt.card := hSk_eq ▸ Finset.card_image_le
    have hc_lt : S_k_lt.card ≤ 2 * (2 * s₀_d - 1) := hinv.tree_leaf.1
    have hM_eq : M = S_k_h.card := rfl
    clear * - hM_eq hc_img hc_lt; omega
  have htree1 : TreeStoredAt L 1 S_k_h (fun _ => 0) (fun _ => 1) ws := by
    have ht_ref := hinv.tree_leaf.2
    rw [hSk_eq] at ht_ref
    exact ht_ref.unchanged (fun u hu f hf =>
      hunchRef _ (by rintro (h | h | h | h | h) <;> cases h)
        (not_in_treeSlice_of_tid_ne hu hf (by decide)))
  have hM_le_pow : M ≤ 2 ^ L := by
    calc S_k_h.card ≤ (Finset.range (2 ^ L)).card :=
          Finset.card_le_card (fun h hh => Finset.mem_range.mpr (htree1.hS h hh))
      _ = 2 ^ L := Finset.card_range _
  have hpow1_pos : 1 ≤ 2 ^ L := Nat.one_le_pow _ _ (by decide)
  have hM_bl : ∀ x : ℕ, x ≤ M → intBitLength (x : ℤ) ≤ W := by
    intro x hx
    have hx_lt : x < 2 ^ (L + 1) := by rw [pow_succ]; omega
    exact (nat_lt_pow2_bitLength_le hx_lt).trans (by omega)
  have hn8 : natBitLength 8 ≤ W := Nat.le_trans (by decide) hW32
  have hn9 : natBitLength 9 ≤ W := Nat.le_trans (by decide) hW32
  have hl0 : intBitLength (0 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl1 : intBitLength (1 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl110 : intBitLength (110 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl120 : intBitLength (120 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hl121 : intBitLength (121 : ℤ) ≤ W := Nat.le_trans (by decide) hW32
  have hno_stage_ws : ∀ t : ℕ, (t = 8 ∨ t = 9) → ∀ z : ℤ, (.heap t z : RAMCellLoc) ∉ ws.live := by
    intro t ht z
    have hna : ¬ isAnsHeaderLoc (.heap t z) := by
      rcases ht with rfl | rfl <;> (rintro (h | h | h | h | h) <;> cases h)
    rw [(hunchRef (.heap t z) hna (not_in_treeSlice_of_table_ne (by rcases ht with rfl | rfl <;> decide) z)).1]
    exact hinv.stage_clean t (by rcases ht with rfl | rfl <;> simp) z
  -- Step 1: `rLit 0 1; popTreeToBufRegs L`
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd (sp_ok hmod).1 (sp_ok hmod).2 (dst := 0) (c := 1) (by decide) hl1
  set g1 := Function.update regs 0 1; have bg1 := hbnd.update (r := 0) (by decide) hl1
  have hW_pop : 2 * 2 + natBitLength 1 + L + 20 ≤ W := by
    have hdec1 : natBitLength 1 = 1 := by decide
    omega
  obtain ⟨wsPop, gPop, s2, hmPop, bgPop, htreePop0, hr110Pop, hbufPop, hunchPop⟩ :=
    exec_popTreeToBufRegs (inp := inp) (fd := fd) hfd_le hmod hCeilC hCeilB hL1 (B_r := 2) (by decide) hW_pop
      (fun u hu f hf => mem_posDimWriteLocs_tree (by omega) hu hf)
      (fun k hk => mem_posDimWriteLocs_tab8 (by omega))
      (mem_posDimWriteLocs_tab9 (by decide))
      (mem_posDimWriteLocs_tab9 (by decide))
      (mem_posDimWriteLocs_tab9 (by decide))
      (hno_stage_ws 9 (Or.inr rfl) 111) (hno_stage_ws 9 (Or.inr rfl) 112)
      htree1 (fun h hh => ⟨htree1.hS h hh, by decide, by decide⟩)
      bg1 (by simp [g1])
  have hbestPop : BestPairStored B P init wsPop :=
    hbest.of_unchanged_vals hmod.wf hmPop.wf (fun i _ _ =>
      (hunchPop _ (not_in_treeSlice_of_table_ne (by decide) _) (by simp) (fun _ _ h => by cases h)).2)
  have hn120Pop : (.heap 9 120 : RAMCellLoc) ∉ wsPop.live := by
    rw [(hunchPop (.heap 9 120) (not_in_treeSlice_of_table_ne (by decide) _) (by simp) (fun _ _ h => by cases h)).1]
    exact hno_stage_ws 9 (Or.inr rfl) 120
  have hn121Pop : (.heap 9 121 : RAMCellLoc) ∉ wsPop.live := by
    rw [(hunchPop (.heap 9 121) (not_in_treeSlice_of_table_ne (by decide) _) (by simp) (fun _ _ h => by cases h)).1]
    exact hno_stage_ws 9 (Or.inr rfl) 121
  -- Step 2: `leafPairLoopRegs d`
  have lp1 := RegExec.lit (inp := inp) hfd_le bgPop (sp_ok hmPop).1 (sp_ok hmPop).2 (dst := 13) (c := 0) (by decide) hl0
  set gl1 := Function.update gPop 13 0; have bgl1 := bgPop.update (r := 13) (by decide) hl0
  obtain ⟨lp2, hmLp1, bgl2⟩ := exec_litStoreHeap hfd_le hmPop hCeilC hCeilB bgl1
    (table := 9) (valReg := 13) (c := 120) (by decide) (by decide) hn9 hl120
    (mem_posDimWriteLocs_tab9 (by decide)) (Nat.le_trans (by decide) hW32)
  set wsLp1 := wsPop.write (.heap 9 120) (gl1 13)
  set gl2 := Function.update gl1 10 120
  have hr110_Lp1 : wsLp1.read (.heap 9 110) = (M : ℤ) := by
    rw [wordStore_read_write_ne wsPop (by decide)]; exact hr110Pop
  obtain ⟨lp3, bgl3⟩ := exec_litLoadHeap hfd_le hmLp1 hCeilC hCeilB bgl2
    (dst := 5) (table := 9) (c := 110) (by decide) hn9 hl110 hr110_Lp1 (hM_bl M le_rfl)
  set gl3 := Function.update (Function.update gl2 10 110) 5 (M : ℤ)
  let rowCands : ℕ → List (ℕ × ℕ) := fun a =>
    (List.range M).map (fun b => (minPopElem S_k_h a, minPopElem S_k_h b))
  let LeafOuterInv : ℕ → WordStore → (ℕ → ℤ) → Prop := fun a w r =>
    a ≤ M ∧
    ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
    RegBounded W r ∧
    BestPairStored B P (foldBestPairs P init ((List.range a).flatMap rowCands)) w ∧
    w.read (.heap 9 120) = (a : ℤ) ∧
    (.heap 9 121 : RAMCellLoc) ∉ w.live ∧
    (∀ loc : RAMCellLoc, ¬ isBestPairLoc loc → loc ≠ .heap 9 120 →
      (loc ∈ w.live ↔ loc ∈ wsPop.live) ∧ w.vals loc = wsPop.vals loc)
  have hLeafOuter0 : LeafOuterInv 0 wsLp1 gl3 := by
    refine ⟨Nat.zero_le _, hmLp1, bgl3, ?_, ?_, ?_, ?_⟩
    · simpa using (hbestPop.of_unchanged_vals hmPop.wf hmLp1.wf (fun i _ _ => by simp [wsLp1, WordStore.write]))
    · simp [wsLp1, gl1, WordStore.read, WordStore.write]
    · simp [wsLp1, WordStore.write, hn121Pop]
    · intro loc _ hne120
      exact ⟨by simp [wsLp1, WordStore.write, hne120],
             by simp [wsLp1, WordStore.write, Function.update_of_ne hne120]⟩
  obtain ⟨wsLpLoop, regsLpLoop, lp4, hLeafOuterEnd⟩ :=
    RegExec.repeatReg_inv (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
      (cntReg := 5) (by decide) M (by simp [gl3]) LeafOuterInv hLeafOuter0 bgl3
      (U := (M + 1) * (220 * d + 220) + 80)
      (B := ((M + 1) * (52 * d + 52) + 8) * W * W)
      (fun a ha wA rA ⟨_, hmA, brA, hbestA, hr120A, hn121A, hunchA⟩ => by
        have o1 := RegExec.lit (inp := inp) hfd_le brA (sp_ok hmA).1 (sp_ok hmA).2 (dst := 13) (c := 0) (by decide) hl0
        set ro1 := Function.update rA 13 0; have bro1 := brA.update (r := 13) (by decide) hl0
        obtain ⟨o2, hmA1, bro2⟩ := exec_litStoreHeap hfd_le hmA hCeilC hCeilB bro1
          (table := 9) (valReg := 13) (c := 121) (by decide) (by decide) hn9 hl121
          (mem_posDimWriteLocs_tab9 (by decide)) (Nat.le_trans (by decide) hW32)
        set wA1 := wA.write (.heap 9 121) (ro1 13)
        set ro2 := Function.update ro1 10 121
        have hr110_A1 : wA1.read (.heap 9 110) = (M : ℤ) := by
          rw [wordStore_read_write_ne wA (by decide), wordStore_read_eq_vals hmA.wf,
              (hunchA (.heap 9 110) (by rintro (h | h | h | h) <;> cases h) (by simp)).2,
              ← wordStore_read_eq_vals hmPop.wf]
          exact hr110Pop
        obtain ⟨o3, bro3⟩ := exec_litLoadHeap hfd_le hmA1 hCeilC hCeilB bro2
          (dst := 5) (table := 9) (c := 110) (by decide) hn9 hl110 hr110_A1 (hM_bl M le_rfl)
        set ro3 := Function.update (Function.update ro2 10 110) 5 (M : ℤ)
        let curRowInit := foldBestPairs P init ((List.range a).flatMap rowCands)
        let LeafInnerInv : ℕ → WordStore → (ℕ → ℤ) → Prop := fun b w r =>
          b ≤ M ∧
          ModifiedOnBounded WordStore.empty (posDimWriteLocs d L K_max) W w ∧
          RegBounded W r ∧
          BestPairStored B P
            (foldBestPairs P curRowInit ((List.range b).map (fun x => (minPopElem S_k_h a, minPopElem S_k_h x)))) w ∧
          w.read (.heap 9 120) = (a : ℤ) ∧
          w.read (.heap 9 121) = (b : ℤ) ∧
          (∀ loc : RAMCellLoc, ¬ isBestPairLoc loc → loc ≠ .heap 9 121 →
            (loc ∈ w.live ↔ loc ∈ wA.live) ∧ w.vals loc = wA.vals loc)
        have hInner0 : LeafInnerInv 0 wA1 ro3 := by
          refine ⟨Nat.zero_le _, hmA1, bro3, ?_, ?_, ?_, ?_⟩
          · simpa using (hbestA.of_unchanged_vals hmA.wf hmA1.wf (fun i _ _ => by simp [wA1, WordStore.write]))
          · rw [wordStore_read_write_ne wA (by decide)]; exact hr120A
          · simp [wA1, ro1, WordStore.read, WordStore.write]
          · intro loc _ hne121
            exact ⟨by simp [wA1, WordStore.write, hne121],
                   by simp [wA1, WordStore.write, Function.update_of_ne hne121]⟩
        obtain ⟨wInEnd, rInEnd, o4, hInnerEnd⟩ :=
          RegExec.repeatReg_inv (inp := inp) (fd := fd) (W := W) (C_cell := C_cell) (C_bit := C_bit)
            (cntReg := 5) (by decide) M (by simp [ro3]) LeafInnerInv hInner0 bro3
            (U := 220 * d + 220) (B := (52 * d + 52) * W * W)
            (fun b hb wB rB ⟨_, hmB, brB, hbestB, hr120B, hr121B, hunchB⟩ => by
              have hha_in : minPopElem S_k_h a ∈ S_k_h := (minPopElem_step ha).2.2.2.1
              have hhb_in : minPopElem S_k_h b ∈ S_k_h := (minPopElem_step hb).2.2.2.1
              have hha_act : minPopElem S_k_h a ∈ P.activeHandles := chainInput_subset_base _ _ _ _ hha_in
              have hhb_act : minPopElem S_k_h b ∈ P.activeHandles := chainInput_subset_base _ _ _ _ hhb_in
              have hha_bl : intBitLength (minPopElem S_k_h a : ℤ) ≤ W :=
                (nat_lt_pow2_bitLength_le (htree1.hS _ hha_in)).trans (by omega)
              have hhb_bl : intBitLength (minPopElem S_k_h b : ℤ) ≤ W :=
                (nat_lt_pow2_bitLength_le (htree1.hS _ hhb_in)).trans (by omega)
              have hbuf_B : ∀ k < M, wB.read (.heap 8 (k : ℤ)) = (minPopElem S_k_h k : ℤ) := by
                intro k hk
                rw [wordStore_read_eq_vals hmB.wf,
                    (hunchB (.heap 8 (k : ℤ)) (by rintro (h | h | h | h) <;> cases h) (by simp)).2,
                    (hunchA (.heap 8 (k : ℤ)) (by rintro (h | h | h | h) <;> cases h) (by simp)).2,
                    ← wordStore_read_eq_vals hmPop.wf]
                exact hbufPop k hk
              obtain ⟨k1, bk1⟩ := exec_litLoadHeap hfd_le hmB hCeilC hCeilB brB
                (dst := 13) (table := 9) (c := 120) (by decide) hn9 hl120 hr120B (hM_bl a (Nat.le_of_lt ha))
              set gk1 := Function.update (Function.update rB 10 120) 13 (a : ℤ)
              have hr_a : wB.read (.heap 8 (gk1 13)) = (minPopElem S_k_h a : ℤ) := by
                simp only [gk1, Function.update_self]; exact hbuf_B a ha
              have k2 := RegExec.load (inp := inp) hfd_le bk1 (sp_ok hmB).1 (sp_ok hmB).2
                (dst := 1) (table := 8) (addr := 13) (by decide) (by decide) hn8 (by rw [hr_a]; exact hha_bl)
              rw [hr_a] at k2
              set gk2 := Function.update gk1 1 (minPopElem S_k_h a : ℤ); have bk2 := bk1.update (r := 1) (by decide) hha_bl
              obtain ⟨k3, bk3⟩ := exec_litLoadHeap hfd_le hmB hCeilC hCeilB bk2
                (dst := 13) (table := 9) (c := 121) (by decide) hn9 hl121 hr121B (hM_bl b (Nat.le_of_lt hb))
              set gk3 := Function.update (Function.update gk2 10 121) 13 (b : ℤ)
              have hr_b : wB.read (.heap 8 (gk3 13)) = (minPopElem S_k_h b : ℤ) := by
                simp only [gk3, Function.update_self]; exact hbuf_B b hb
              have k4 := RegExec.load (inp := inp) hfd_le bk3 (sp_ok hmB).1 (sp_ok hmB).2
                (dst := 2) (table := 8) (addr := 13) (by decide) (by decide) hn8 (by rw [hr_b]; exact hhb_bl)
              rw [hr_b] at k4
              set gk4 := Function.update gk3 2 (minPopElem S_k_h b : ℤ); have bk4 := bk3.update (r := 2) (by decide) hhb_bl
              have hcoords_B : ActiveCoordsStored d L B P.activeHandles qMap wB :=
                hinv.coords_stored.unchanged (fun h' _ c _ f _ => by
                  rw [wordStore_read_eq_vals hmB.wf, wordStore_read_eq_vals hinv.mod.wf]
                  let loc1 : RAMCellLoc := .heap 1 (coordCellAddr d h' c f)
                  have u1 := (hunchB loc1 (by simp [loc1, isBestPairLoc]) (by simp [loc1])).2
                  have u2 := (hunchA loc1 (by simp [loc1, isBestPairLoc]) (by simp [loc1])).2
                  have u3 := (hunchPop loc1 (not_in_treeSlice_of_table_ne (by decide) _)
                    (by simp [loc1]) (fun _ _ => by simp [loc1])).2
                  have u4 := (hunchRef loc1 (by simp [loc1, isAnsHeaderLoc])
                    (not_in_treeSlice_of_table_ne (by decide) _)).2
                  exact u1.trans (u2.trans (u3.trans u4)))
              obtain ⟨wB1, gk5, k5, hmB1, bk5, hbestB1, hunchCand⟩ :=
                exec_considerCandRegs (cand := (minPopElem S_k_h a, minPopElem S_k_h b)) hd1 hB1 hfd_le hmB hCeilC hCeilB (by have hm : d * (4 * B + 12) ≤ d * (8 * B + 24) := Nat.mul_le_mul_left d (by clear * -; omega); clear * - hW hm; omega)
                  hinv.wfP hinv.hlt_sync hcoords_B
                  (fun i _ hi5 => mem_posDimWriteLocs_tab0 (by omega))
                  hbestB hha_act hhb_act bk4
                  (by simp +zetaDelta [gk4, gk3, gk2]) (by simp +zetaDelta [gk4])
              have hr121_B1 : wB1.read (.heap 9 121) = (b : ℤ) := by
                rw [wordStore_read_eq_vals hmB1.wf,
                    (hunchCand (.heap 9 121) (by rintro (h | h | h | h) <;> cases h)).2,
                    ← wordStore_read_eq_vals hmB.wf]
                exact hr121B
              have hb1_cast : (b : ℤ) + 1 = ((b + 1 : ℕ) : ℤ) := by push_cast; rfl
              obtain ⟨gk6, k6, hmB2, bk6⟩ :=
                exec_incrHeap9Regs hfd_le hmB1 hCeilC hCeilB (by omega) hl121
                  (Nat.le_trans (by decide) hW32) (mem_posDimWriteLocs_tab9 (by decide))
                  hr121_B1 (hM_bl b (Nat.le_of_lt hb)) (by rw [hb1_cast]; exact hM_bl (b + 1) hb) bk5
              set wB2 := wB1.write (.heap 9 121) ((b : ℤ) + 1)
              have kTot := (k1.seq (k2.seq (k3.seq (k4.seq (k5.seq k6))))).weaken
                rfl rfl (u₂ := 220 * d + 220) (b₂ := (52 * d + 52) * W * W)
                (by omega) (by
                  have hWW : 80 * W + 300 ≤ 12 * W * W := by nlinarith only [hW32]
                  have heq : (52 * d + 52) * W * W = (52 * d + 40) * W * W + 12 * W * W := by ring
                  rw [heq]; linarith only [hWW, hW32])
              have hfold_b : foldBestPairs P curRowInit
                  ((List.range (b + 1)).map (fun x => (minPopElem S_k_h a, minPopElem S_k_h x))) =
                stepBestPair P (foldBestPairs P curRowInit
                  ((List.range b).map (fun x => (minPopElem S_k_h a, minPopElem S_k_h x))))
                  (minPopElem S_k_h a, minPopElem S_k_h b) := by
                rw [List.range_succ, List.map_append, List.map_singleton,
                    foldBestPairs_append, foldBestPairs_singleton]
              have hbestB2 : BestPairStored B P
                  (foldBestPairs P curRowInit ((List.range (b + 1)).map (fun x => (minPopElem S_k_h a, minPopElem S_k_h x)))) wB2 := by
                rw [hfold_b]
                exact hbestB1.of_unchanged_vals hmB1.wf hmB2.wf (fun i _ _ => by simp [wB2, WordStore.write])
              refine ⟨wB2, gk6, kTot, Nat.succ_le_of_lt hb, hmB2, bk6, hbestB2, ?_, ?_, ?_⟩
              · rw [wordStore_read_write_ne wB1 (by decide), wordStore_read_eq_vals hmB1.wf,
                    (hunchCand (.heap 9 120) (by rintro (h | h | h | h) <;> cases h)).2,
                    ← wordStore_read_eq_vals hmB.wf]
                exact hr120B
              · simp [wB2, WordStore.read, WordStore.write]
              · intro loc hnb hne121
                have uC := hunchCand loc hnb
                have uB := hunchB loc hnb hne121
                exact ⟨by simp [wB2, WordStore.write, hne121, uC.1, uB.1],
                       by simp [wB2, WordStore.write, Function.update_of_ne hne121, uC.2, uB.2]⟩)
        rcases hInnerEnd with ⟨_, hmInEnd, brInEnd, hbestInEnd, hr120InEnd, _, hunchInEnd⟩
        obtain ⟨o5, hmA2, bro5⟩ := exec_litFreeHeap hfd_le hmInEnd hCeilC hCeilB brInEnd hn9 hl121
          (mem_posDimWriteLocs_tab9 (by decide))
        set wA2 := wInEnd.free (.heap 9 121)
        have hr120_A2 : wA2.read (.heap 9 120) = (a : ℤ) := by
          rw [wordStore_read_free_ne wInEnd (by decide)]; exact hr120InEnd
        have ha1_cast : (a : ℤ) + 1 = ((a + 1 : ℕ) : ℤ) := by push_cast; rfl
        obtain ⟨ro6, o6, hmA3, bro6⟩ :=
          exec_incrHeap9Regs hfd_le hmA2 hCeilC hCeilB (by omega) hl120
            (Nat.le_trans (by decide) hW32) (mem_posDimWriteLocs_tab9 (by decide))
            hr120_A2 (hM_bl a (Nat.le_of_lt ha)) (by rw [ha1_cast]; exact hM_bl (a + 1) ha) bro5
        set wA3 := wA2.write (.heap 9 120) ((a : ℤ) + 1)
        have oTot := (o1.seq (o2.seq (o3.seq (o4.seq (o5.seq o6))))).weaken
          rfl rfl (u₂ := (M + 1) * (220 * d + 220) + 80)
          (b₂ := ((M + 1) * (52 * d + 52) + 8) * W * W)
          (by clear * -; nlinarith) (by
            have hWW : 80 * W + 400 ≤ 60 * W * W := by nlinarith only [hW32]
            have hnn : 0 ≤ 52 * d * W * W := by positivity
            have heq : ((M + 1) * (52 * d + 52) + 8) * W * W =
                M * ((52 * d + 52) * W * W) + 52 * d * W * W + 60 * W * W := by ring
            rw [heq]; linarith only [hWW, hnn, hW32])
        have hflat_a : (List.range (a + 1)).flatMap rowCands =
            (List.range a).flatMap rowCands ++ rowCands a := by
          rw [List.range_succ, List.flatMap_append, List.flatMap_singleton]
        have hbestA3 : BestPairStored B P (foldBestPairs P init ((List.range (a + 1)).flatMap rowCands)) wA3 := by
          rw [hflat_a, foldBestPairs_append]
          exact hbestInEnd.of_unchanged_vals hmInEnd.wf hmA3.wf
            (fun i _ _ => by simp [wA3, wA2, WordStore.write, WordStore.free])
        refine ⟨wA3, ro6, oTot, Nat.succ_le_of_lt ha, hmA3, bro6, hbestA3, ?_, ?_, ?_⟩
        · simp [wA3, WordStore.read, WordStore.write]
        · simp [wA3, wA2, WordStore.write, WordStore.free]
        · intro loc hnb hne120
          by_cases h121 : loc = .heap 9 121
          · subst h121
            have hn121_pop : (.heap 9 121 : RAMCellLoc) ∉ wsPop.live := hn121Pop
            exact ⟨by simp [wA3, wA2, WordStore.write, WordStore.free, hn121_pop],
                   by simp [wA3, wA2, WordStore.write, WordStore.free, hmPop.wf _ hn121_pop]⟩
          · have uI := hunchInEnd loc hnb h121
            have uA := hunchA loc hnb hne120
            exact ⟨by simp [wA3, wA2, WordStore.write, WordStore.free, hne120, h121, uI.1, uA.1],
                   by simp [wA3, wA2, WordStore.write, WordStore.free, Function.update_of_ne hne120,
                        Function.update_of_ne h121, uI.2, uA.2]⟩)
  rcases hLeafOuterEnd with ⟨_, hmLpLoop, brLpLoop, hbestLpLoop, _, _, hunchLpLoop⟩
  obtain ⟨lp5, hmLpEnd, brLpEnd⟩ := exec_litFreeHeap hfd_le hmLpLoop hCeilC hCeilB brLpLoop hn9 hl120
    (mem_posDimWriteLocs_tab9 (by decide))
  set wsLpEnd := wsLpLoop.free (.heap 9 120)
  have hbestLpEnd : BestPairStored B P (foldBestPairs P init (leafScanCands P nodes)) wsLpEnd :=
    hbestLpLoop.of_unchanged_vals hmLpLoop.wf hmLpEnd.wf (fun i _ _ => by simp [wsLpEnd, WordStore.free])
  have hunchLp : ∀ loc : RAMCellLoc, ¬ isBestPairLoc loc →
      (loc ∈ wsLpEnd.live ↔ loc ∈ wsPop.live) ∧ wsLpEnd.vals loc = wsPop.vals loc := by
    intro loc hnb
    by_cases h120 : loc = .heap 9 120
    · subst h120
      exact ⟨by simp [wsLpEnd, WordStore.free, hn120Pop],
             by simp [wsLpEnd, WordStore.free, hmPop.wf _ hn120Pop]⟩
    · have u := hunchLpLoop loc hnb h120
      exact ⟨by simp [wsLpEnd, WordStore.free, h120, u.1],
             by simp [wsLpEnd, WordStore.free, Function.update_of_ne h120, u.2]⟩
  have hLpExec : RegExec inp fd W C_cell C_bit (leafPairLoopRegs d) wsPop gPop wsLpEnd (Function.update regsLpLoop 10 120)
      ((M + 1) * (M + 1) * (220 * d + 220) + (M + 1) * 100)
      (((M + 1) * (M + 1) * (52 * d + 52) + (M + 1) * 12) * W * W) := by
    exact (lp1.seq (lp2.seq (lp3.seq (lp4.seq lp5)))).weaken
      rfl rfl
      (by
        have hnn : 0 ≤ (M + 1) * (220 * d + 220) + M * 20 := by positivity
        have heq : (M + 1) * (M + 1) * (220 * d + 220) + (M + 1) * 100 =
            M * ((M + 1) * (220 * d + 220) + 80) + ((M + 1) * (220 * d + 220) + M * 20) + 100 := by ring
        rw [heq]; omega)
      (by
        have hWW : 60 * W + 300 ≤ 64 * W * W := by nlinarith only [hW32]
        have hnn : 0 ≤ (M * (52 * d + 56) + 52 * d) * W * W := by positivity
        have heq : ((M + 1) * (M + 1) * (52 * d + 52) + (M + 1) * 12) * W * W =
            M * (((M + 1) * (52 * d + 52) + 8) * W * W) +
            (M * (52 * d + 56) + 52 * d) * W * W + 64 * W * W := by ring
        rw [heq]; linarith only [hWW, hnn, hW32])
  -- Step 3: `rLit 0 1; insertBufToUnitTreeRegs L`
  have s3 := RegExec.lit (inp := inp) hfd_le brLpEnd (sp_ok hmLpEnd).1 (sp_ok hmLpEnd).2 (dst := 0) (c := 1) (by decide) hl1
  set gi0 := Function.update (Function.update regsLpLoop 10 120) 0 1
  have bgi0 := brLpEnd.update (r := 0) (by decide) hl1
  have hW_ins : natBitLength 1 + L + 24 ≤ W := by
    have hdec1 : natBitLength 1 = 1 := by decide
    omega
  have hn111_Lp : (.heap 9 111 : RAMCellLoc) ∉ wsLpEnd.live := by
    rw [(hunchLp (.heap 9 111) (by rintro (h | h | h | h) <;> cases h)).1,
        (hunchPop (.heap 9 111) (not_in_treeSlice_of_table_ne (by decide) _) (by simp) (fun _ _ h => by cases h)).1]
    exact hno_stage_ws 9 (Or.inr rfl) 111
  have hn112_Lp : (.heap 9 112 : RAMCellLoc) ∉ wsLpEnd.live := by
    rw [(hunchLp (.heap 9 112) (by rintro (h | h | h | h) <;> cases h)).1,
        (hunchPop (.heap 9 112) (not_in_treeSlice_of_table_ne (by decide) _) (by simp) (fun _ _ h => by cases h)).1]
    exact hno_stage_ws 9 (Or.inr rfl) 112
  have hr110_LpEnd : wsLpEnd.read (.heap 9 110) = (M : ℤ) := by
    rw [wordStore_read_eq_vals hmLpEnd.wf,
        (hunchLp (.heap 9 110) (by rintro (h | h | h | h) <;> cases h)).2,
        ← wordStore_read_eq_vals hmPop.wf]
    exact hr110Pop
  have hbuf_LpEnd : ∀ k < M, wsLpEnd.read (.heap 8 (k : ℤ)) = (minPopElem S_k_h k : ℤ) := by
    intro k hk
    rw [wordStore_read_eq_vals hmLpEnd.wf,
        (hunchLp (.heap 8 (k : ℤ)) (by rintro (h | h | h | h) <;> cases h)).2,
        ← wordStore_read_eq_vals hmPop.wf]
    exact hbufPop k hk
  have htree0_LpEnd : TreeStoredAt L 1 ∅ (fun _ => 0) (fun _ => 1) wsLpEnd :=
    htreePop0.unchanged (fun u _ f _ => hunchLp _ (by rintro (h | h | h | h) <;> cases h))
  obtain ⟨wsIns, gIns, s4, hmIns, bgIns, htreeIns, hunchIns⟩ :=
    exec_insertBufToUnitTreeRegs (inp := inp) (fd := fd) hfd_le hmLpEnd hCeilC hCeilB hL1 hM_le_pow hW_ins
      (fun u hu f hf => mem_posDimWriteLocs_tree (by omega) hu hf)
      (mem_posDimWriteLocs_tab9 (by decide))
      (mem_posDimWriteLocs_tab9 (by decide))
      hn111_Lp hn112_Lp
      (fun k hk => htree1.hS _ (minPopElem_step hk).2.2.2.1)
      hr110_LpEnd hbuf_LpEnd htree0_LpEnd bgi0 (by simp [gi0])
  rw [image_minPopElem_eq S_k_h, ← hSk_eq] at htreeIns
  -- Step 4: `freeBufRegs`
  have hr110_Ins : wsIns.read (.heap 9 110) = (M : ℤ) := by
    rw [wordStore_read_eq_vals hmIns.wf,
        (hunchIns (.heap 9 110) (not_in_treeSlice_of_table_ne (by decide) _)).2,
        ← wordStore_read_eq_vals hmLpEnd.wf]
    exact hr110_LpEnd
  obtain ⟨wsEnd, gEnd, s5, hmEnd, bgEnd, hn8End, hn110End, hunchFree⟩ :=
    exec_freeBufRegs (inp := inp) (fd := fd) hfd_le hmIns hCeilC hCeilB hM_le_pow (by omega)
      (fun k hk => mem_posDimWriteLocs_tab8 (by omega))
      (mem_posDimWriteLocs_tab9 (by decide))
      hr110_Ins bgIns
  have htreeEnd : TreeStoredAt L 1 (S_k_lt.image (handleOfLifetime P)) (fun _ => 0) (fun _ => 1) wsEnd :=
    htreeIns.unchanged (fun u _ f _ =>
      hunchFree _ (by simp) (fun _ _ h => by cases h))
  have hbestEnd : BestPairStored B P (foldBestPairs P init (leafScanCands P nodes)) wsEnd :=
    hbestLpEnd.of_unchanged_vals hmLpEnd.wf hmEnd.wf (fun i _ _ => by
      let loc0 : RAMCellLoc := .heap 0 (i : ℤ)
      have u1 := (hunchFree loc0 (by simp [loc0]) (fun _ _ => by simp [loc0])).2
      have u2 := (hunchIns loc0 (not_in_treeSlice_of_table_ne (by decide) _)).2
      exact u1.trans u2)
  -- Bound total cost using `M + 1 ≤ 4 * s₀_d + 1`
  have hM1_le : M + 1 ≤ 4 * s₀_d + 1 := by omega
  have hM2_le : (M + 1) * (M + 1) ≤ (4 * s₀_d + 1) * (4 * s₀_d + 1) := Nat.mul_le_mul hM1_le hM1_le
  have hU_bound :
      4 + ((M + 1) * (460 * L + 340) +
        (((M + 1) * (M + 1) * (220 * d + 220) + (M + 1) * 100) +
          (4 + ((M + 1) * (400 * L + 300) + (16 * M + 40))))) ≤
        (4 * s₀_d + 1) * (4 * s₀_d + 1) * (220 * d + 320) + (4 * s₀_d + 1) * (880 * L + 800) := by
    have hu1 : (M + 1) * (M + 1) * (220 * d + 220) ≤ (4 * s₀_d + 1) * (4 * s₀_d + 1) * (220 * d + 220) :=
      Nat.mul_le_mul_right _ hM2_le
    have hu2 : (M + 1) * (860 * L + 740) ≤ (4 * s₀_d + 1) * (860 * L + 740) :=
      Nat.mul_le_mul_right _ hM1_le
    have hu3 : 16 * M + 48 ≤ (4 * s₀_d + 1) * 60 := by omega
    nlinarith only [hu1, hu2, hu3, hM2_le]
  have hB_bound :
      (2 * W + 16) + (((M + 1) * (76 * L + 100) * W * W) +
        ((((M + 1) * (M + 1) * (52 * d + 52) + (M + 1) * 12) * W * W) +
          ((2 * W + 16) + (((M + 1) * (64 * L + 80) * W * W) + ((12 * M + 24) * W))))) ≤
        ((4 * s₀_d + 1) * (4 * s₀_d + 1) * (52 * d + 64) + (4 * s₀_d + 1) * (140 * L + 240)) * W * W := by
    have hb0 : (2 * W + 16) + (2 * W + 16) + (12 * M + 24) * W ≤ (M + 1) * 28 * W * W := by
      calc (2 * W + 16) + (2 * W + 16) + (12 * M + 24) * W
          ≤ (M + 1) * (28 * W + 32) := by clear * -; nlinarith
        _ ≤ (M + 1) * (28 * W * W) := Nat.mul_le_mul_left (M + 1) (by nlinarith only [hW32])
        _ = (M + 1) * 28 * W * W := by ring
    have hb1 : ((M + 1) * (M + 1) * (52 * d + 52) + (M + 1) * (140 * L + 220)) * W * W ≤
        ((4 * s₀_d + 1) * (4 * s₀_d + 1) * (52 * d + 64) + (4 * s₀_d + 1) * (140 * L + 240)) * W * W := by
      apply Nat.mul_le_mul_right
      apply Nat.mul_le_mul_right
      have hm_sq : (M + 1) * (M + 1) * (52 * d + 52) ≤ (4 * s₀_d + 1) * (4 * s₀_d + 1) * (52 * d + 64) :=
        Nat.mul_le_mul hM2_le (by clear * -; omega)
      have hm_lin : (M + 1) * (140 * L + 220) ≤ (4 * s₀_d + 1) * (140 * L + 240) :=
        Nat.mul_le_mul hM1_le (by clear * -; omega)
      omega
    have hring1 :
        (2 * W + 16) + (((M + 1) * (76 * L + 100) * W * W) +
          ((((M + 1) * (M + 1) * (52 * d + 52) + (M + 1) * 12) * W * W) +
            ((2 * W + 16) + (((M + 1) * (64 * L + 80) * W * W) + ((12 * M + 24) * W))))) =
        ((2 * W + 16) + (2 * W + 16) + (12 * M + 24) * W) +
        ((M + 1) * (M + 1) * (52 * d + 52) + (M + 1) * (140 * L + 192)) * W * W := by ring
    have hring2 :
        ((M + 1) * (M + 1) * (52 * d + 52) + (M + 1) * (140 * L + 220)) * W * W =
        (M + 1) * 28 * W * W +
        ((M + 1) * (M + 1) * (52 * d + 52) + (M + 1) * (140 * L + 192)) * W * W := by ring
    rw [hring1]; rw [hring2] at hb1; omega
  have sTot := (s1.seq (s2.seq (hLpExec.seq (s3.seq (s4.seq s5))))).weaken
    rfl rfl
    (u₂ := (4 * s₀_d + 1) * (4 * s₀_d + 1) * (220 * d + 320) + (4 * s₀_d + 1) * (880 * L + 800))
    (b₂ := (((4 * s₀_d + 1) * (4 * s₀_d + 1) * (52 * d + 64) + (4 * s₀_d + 1) * (140 * L + 240)) * W * W))
    hU_bound hB_bound
  refine ⟨wsEnd, gEnd, sTot, hmEnd, bgEnd, htreeEnd, hbestEnd, ?_⟩
  intro loc hnb hns1
  by_cases h110 : loc = .heap 9 110
  · subst h110
    have hn0 : (.heap 9 110 : RAMCellLoc) ∉ ws.live := hno_stage_ws 9 (Or.inr rfl) 110
    exact ⟨by simp [hn110End, hn0], by rw [hmEnd.wf _ hn110End, hmod.wf _ hn0]⟩
  · by_cases hbufk : ∃ k < M, loc = .heap 8 (k : ℤ)
    · rcases hbufk with ⟨k, hk, rfl⟩
      have hn0 : (.heap 8 (k : ℤ) : RAMCellLoc) ∉ ws.live := hno_stage_ws 8 (Or.inl rfl) k
      exact ⟨by simp [hn8End k hk, hn0], by rw [hmEnd.wf _ (hn8End k hk), hmod.wf _ hn0]⟩
    · push_neg at hbufk
      have u5 := hunchFree loc h110 hbufk
      have u4 := hunchIns loc hns1
      have u3 := hunchLp loc hnb
      have u2 := hunchPop loc hns1 h110 hbufk
      exact ⟨u5.1.trans (u4.1.trans (u3.1.trans u2.1)),
             u5.2.trans (u4.2.trans (u3.2.trans u2.2))⟩

end UL.C12LVE
