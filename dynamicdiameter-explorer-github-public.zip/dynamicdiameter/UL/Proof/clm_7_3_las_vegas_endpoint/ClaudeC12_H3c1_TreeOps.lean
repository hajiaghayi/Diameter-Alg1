import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3a_TreeSpec
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H3b_RegDSL
set_option autoImplicit false
set_option maxHeartbeats 800000

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. Bounded write-footprint invariant `ModifiedOnBounded` -/

structure ModifiedOnBounded (ws₀ : WordStore) (S_write : Finset RAMCellLoc)
    (W : ℕ) (ws : WordStore) : Prop where
  wf : WellFormedWS ws
  live_sub : ws.live ⊆ ws₀.live ∪ S_write
  unchanged : ∀ loc : RAMCellLoc, loc ∉ S_write →
    (loc ∈ ws.live ↔ loc ∈ ws₀.live) ∧ ws.vals loc = ws₀.vals loc
  bounded_write : ∀ loc ∈ ws.live, loc ∈ S_write →
    loc.bitLength ≤ W ∧ intBitLength (ws.vals loc) ≤ W

theorem ModifiedOnBounded.refl {ws₀ : WordStore} (hwf : WellFormedWS ws₀)
    (S_write : Finset RAMCellLoc) (W : ℕ)
    (hb₀ : ∀ loc ∈ ws₀.live, loc ∈ S_write → loc.bitLength ≤ W ∧ intBitLength (ws₀.vals loc) ≤ W) :
    ModifiedOnBounded ws₀ S_write W ws₀ :=
  { wf := hwf
    live_sub := Finset.subset_union_left
    unchanged := fun _ _ => ⟨Iff.rfl, rfl⟩
    bounded_write := hb₀ }

theorem ModifiedOnBounded.write {ws₀ : WordStore} {S_write : Finset RAMCellLoc}
    {W : ℕ} {ws : WordStore} (h : ModifiedOnBounded ws₀ S_write W ws)
    {loc : RAMCellLoc} (hmem : loc ∈ S_write) (val : ℤ)
    (hloc_bl : loc.bitLength ≤ W) (hval_bl : intBitLength val ≤ W) :
    ModifiedOnBounded ws₀ S_write W (ws.write loc val) := by
  refine
    { wf := wellFormedWS_write h.wf loc val
      live_sub := ?_
      unchanged := ?_
      bounded_write := ?_ }
  · intro x hx
    simp only [WordStore.write, Finset.mem_insert] at hx
    rcases hx with rfl | hx'
    · exact Finset.mem_union_right _ hmem
    · exact h.live_sub hx'
  · intro x hxnot
    have hne : x ≠ loc := fun heq => hxnot (heq ▸ hmem)
    simp only [WordStore.write, Finset.mem_insert, hne, false_or, Function.update_of_ne hne]
    exact h.unchanged x hxnot
  · intro x hx hxS
    simp only [WordStore.write, Finset.mem_insert] at hx
    by_cases hxeq : x = loc
    · subst hxeq
      simp only [WordStore.write, Function.update_self]
      exact ⟨hloc_bl, hval_bl⟩
    · rcases hx with rfl | hx'
      · exact False.elim (hxeq rfl)
      · simp only [WordStore.write, Function.update_of_ne hxeq]
        exact h.bounded_write x hx' hxS

theorem ModifiedOnBounded.free {ws₀ : WordStore} {S_write : Finset RAMCellLoc}
    {W : ℕ} {ws : WordStore} (h : ModifiedOnBounded ws₀ S_write W ws)
    {loc : RAMCellLoc} (hmem : loc ∈ S_write) :
    ModifiedOnBounded ws₀ S_write W (ws.free loc) := by
  refine
    { wf := wellFormedWS_free h.wf loc
      live_sub := ?_
      unchanged := ?_
      bounded_write := ?_ }
  · intro x hx
    simp only [WordStore.free, Finset.mem_erase] at hx
    exact h.live_sub hx.2
  · intro x hxnot
    have hne : x ≠ loc := fun heq => hxnot (heq ▸ hmem)
    simp only [WordStore.free, Finset.mem_erase, ne_eq, hne, not_false_eq_true, true_and,
      Function.update_of_ne hne]
    exact h.unchanged x hxnot
  · intro x hx hxS
    simp only [WordStore.free, Finset.mem_erase] at hx
    simp only [WordStore.free, Function.update_of_ne hx.1]
    exact h.bounded_write x hx.2 hxS

theorem ModifiedOnBounded.space_le {ws₀ : WordStore} {S_write : Finset RAMCellLoc}
    {W : ℕ} {ws : WordStore} (h : ModifiedOnBounded ws₀ S_write W ws) :
    ws.cellCount ≤ ws₀.cellCount + S_write.card ∧
    ws.bitSize ≤ ws₀.bitSize + 2 * W * S_write.card := by
  constructor
  · unfold WordStore.cellCount
    calc ws.live.card ≤ (ws₀.live ∪ S_write).card := Finset.card_le_card h.live_sub
      _ ≤ ws₀.live.card + S_write.card := Finset.card_union_le _ _
  · unfold WordStore.bitSize
    have hpart : ws.live = (ws.live \ S_write) ∪ (ws.live ∩ S_write) := by
      ext x; simp only [Finset.mem_union, Finset.mem_sdiff, Finset.mem_inter]
      tauto
    have hdisj : Disjoint (ws.live \ S_write) (ws.live ∩ S_write) := by
      rw [Finset.disjoint_left]
      intro x hx1 hx2
      exact (Finset.mem_sdiff.mp hx1).2 (Finset.mem_inter.mp hx2).2
    rw [hpart, Finset.sum_union hdisj]
    have h1 : ∑ loc ∈ ws.live \ S_write, (loc.bitLength + intBitLength (ws.vals loc)) ≤
        ∑ loc ∈ ws₀.live, (loc.bitLength + intBitLength (ws₀.vals loc)) := by
      have hsub0 : ws.live \ S_write ⊆ ws₀.live := by
        intro x hx
        rcases Finset.mem_sdiff.mp hx with ⟨hxL, hxN⟩
        exact (h.unchanged x hxN).1.mp hxL
      calc ∑ loc ∈ ws.live \ S_write, (loc.bitLength + intBitLength (ws.vals loc))
        _ = ∑ loc ∈ ws.live \ S_write, (loc.bitLength + intBitLength (ws₀.vals loc)) := by
            refine Finset.sum_congr rfl (fun x hx => ?_)
            rw [(h.unchanged x (Finset.mem_sdiff.mp hx).2).2]
        _ ≤ ∑ loc ∈ ws₀.live, (loc.bitLength + intBitLength (ws₀.vals loc)) :=
            Finset.sum_le_sum_of_subset hsub0
    have h2 : ∑ loc ∈ ws.live ∩ S_write, (loc.bitLength + intBitLength (ws.vals loc)) ≤
        2 * W * S_write.card := by
      calc ∑ loc ∈ ws.live ∩ S_write, (loc.bitLength + intBitLength (ws.vals loc))
        _ ≤ ∑ _loc ∈ ws.live ∩ S_write, (2 * W) := by
            refine Finset.sum_le_sum (fun x hx => ?_)
            rcases Finset.mem_inter.mp hx with ⟨hxL, hxS⟩
            obtain ⟨hb1, hb2⟩ := h.bounded_write x hxL hxS
            omega
        _ = (ws.live ∩ S_write).card * (2 * W) := by simp
        _ ≤ S_write.card * (2 * W) :=
            Nat.mul_le_mul_right _ (Finset.card_le_card Finset.inter_subset_right)
        _ = 2 * W * S_write.card := by ring
    linarith

/-! ### 2. Implicit binary tree memory representation `TreeStoredAt` in heap table `2` -/

def treeIdx (L k off : ℕ) : ℕ :=
  2 ^ (L - k) + off

def treeCellAddr (L tid u f : ℕ) : ℤ :=
  (((tid * 2 ^ (L + 1) + u) * 4 + f : ℕ) : ℤ)

theorem treeIdx_bounds {L k off : ℕ} (_hk : k ≤ L) (hoff : off < 2 ^ (L - k)) :
    1 ≤ treeIdx L k off ∧ treeIdx L k off < 2 ^ (L + 1) := by
  unfold treeIdx
  have hp1 : 1 ≤ 2 ^ (L - k) := Nat.one_le_pow _ _ (by decide)
  have hp2 : 2 ^ (L - k + 1) ≤ 2 ^ (L + 1) :=
    Nat.pow_le_pow_right (by decide) (by omega)
  have hlt : 2 ^ (L - k) + off < 2 ^ (L - k + 1) := by
    rw [pow_succ]; omega
  exact ⟨by omega, lt_of_lt_of_le hlt hp2⟩

theorem treeIdx_inj {L k₁ off₁ k₂ off₂ : ℕ}
    (hk₁ : k₁ ≤ L) (hoff₁ : off₁ < 2 ^ (L - k₁))
    (hk₂ : k₂ ≤ L) (hoff₂ : off₂ < 2 ^ (L - k₂))
    (heq : treeIdx L k₁ off₁ = treeIdx L k₂ off₂) :
    k₁ = k₂ ∧ off₁ = off₂ := by
  unfold treeIdx at heq
  rcases lt_trichotomy k₁ k₂ with hlt | rfl | hgt
  · have hle : L - k₂ + 1 ≤ L - k₁ := by omega
    have hp : 2 ^ (L - k₂ + 1) ≤ 2 ^ (L - k₁) := Nat.pow_le_pow_right (by decide) hle
    have hlt2 : 2 ^ (L - k₂) + off₂ < 2 ^ (L - k₂ + 1) := by rw [pow_succ]; omega
    omega
  · exact ⟨rfl, by omega⟩
  · have hle : L - k₁ + 1 ≤ L - k₂ := by omega
    have hp : 2 ^ (L - k₁ + 1) ≤ 2 ^ (L - k₂) := Nat.pow_le_pow_right (by decide) hle
    have hlt1 : 2 ^ (L - k₁) + off₁ < 2 ^ (L - k₁ + 1) := by rw [pow_succ]; omega
    omega

theorem treeCellAddr_inj {L tid₁ u₁ f₁ tid₂ u₂ f₂ : ℕ}
    (hu₁ : u₁ < 2 ^ (L + 1)) (hf₁ : f₁ < 4)
    (hu₂ : u₂ < 2 ^ (L + 1)) (hf₂ : f₂ < 4)
    (heq : treeCellAddr L tid₁ u₁ f₁ = treeCellAddr L tid₂ u₂ f₂) :
    tid₁ = tid₂ ∧ u₁ = u₂ ∧ f₁ = f₂ := by
  unfold treeCellAddr at heq
  have hnat : (tid₁ * 2 ^ (L + 1) + u₁) * 4 + f₁ = (tid₂ * 2 ^ (L + 1) + u₂) * 4 + f₂ := by
    exact_mod_cast heq
  have hf_eq : f₁ = f₂ := by omega
  have hq_eq : tid₁ * 2 ^ (L + 1) + u₁ = tid₂ * 2 ^ (L + 1) + u₂ := by omega
  rcases lt_trichotomy tid₁ tid₂ with hlt | rfl | hgt
  · have : (tid₁ + 1) * 2 ^ (L + 1) ≤ tid₂ * 2 ^ (L + 1) := Nat.mul_le_mul_right _ (by omega)
    have : tid₁ * 2 ^ (L + 1) + u₁ < (tid₁ + 1) * 2 ^ (L + 1) := by rw [ add_mul, one_mul ]; omega
    omega
  · exact ⟨rfl, by omega, hf_eq⟩
  · have : (tid₂ + 1) * 2 ^ (L + 1) ≤ tid₁ * 2 ^ (L + 1) := Nat.mul_le_mul_right _ (by omega)
    have : tid₂ * 2 ^ (L + 1) + u₂ < (tid₂ + 1) * 2 ^ (L + 1) := by rw [ add_mul, one_mul ]; omega
    omega

def NodeStoredAt (L tid u : ℕ) (v : ℕ × ℕ × ℤ × ℤ) (ws : WordStore) : Prop :=
  (v.1 = 0 → ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∉ ws.live) ∧
  (0 < v.1 →
    (.heap 2 (treeCellAddr L tid u 0) : RAMCellLoc) ∈ ws.live ∧
      ws.vals (.heap 2 (treeCellAddr L tid u 0)) = (v.1 : ℤ) ∧
    (.heap 2 (treeCellAddr L tid u 1) : RAMCellLoc) ∈ ws.live ∧
      ws.vals (.heap 2 (treeCellAddr L tid u 1)) = (v.2.1 : ℤ) ∧
    (.heap 2 (treeCellAddr L tid u 2) : RAMCellLoc) ∈ ws.live ∧
      ws.vals (.heap 2 (treeCellAddr L tid u 2)) = v.2.2.1 ∧
    (.heap 2 (treeCellAddr L tid u 3) : RAMCellLoc) ∈ ws.live ∧
      ws.vals (.heap 2 (treeCellAddr L tid u 3)) = v.2.2.2)

structure TreeStoredAt (L tid : ℕ) (S : Finset ℕ) (rNum rDen : ℕ → ℤ) (ws : WordStore) : Prop where
  hS : ∀ h ∈ S, h < 2 ^ L
  u0_empty : ∀ f < 4, (.heap 2 (treeCellAddr L tid 0 f) : RAMCellLoc) ∉ ws.live
  nodes : ∀ k ≤ L, ∀ off < 2 ^ (L - k),
    NodeStoredAt L tid (treeIdx L k off) (treeNodeVal S rNum rDen k off) ws

theorem NodeStoredAt.unchanged {L tid u : ℕ} {v : ℕ × ℕ × ℤ × ℤ} {ws₁ ws₂ : WordStore}
    (h : NodeStoredAt L tid u v ws₁)
    (heq : ∀ f < 4,
      ((.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 2 (treeCellAddr L tid u f)) = ws₁.vals (.heap 2 (treeCellAddr L tid u f))) :
    NodeStoredAt L tid u v ws₂ := by
  refine ⟨fun hz f hf => ?_, fun hpos => ?_⟩
  · rw [(heq f hf).1]; exact h.1 hz f hf
  · obtain ⟨m0, v0, m1, v1, m2, v2, m3, v3⟩ := h.2 hpos
    exact ⟨(heq 0 (by decide)).1.mpr m0, (heq 0 (by decide)).2.trans v0,
           (heq 1 (by decide)).1.mpr m1, (heq 1 (by decide)).2.trans v1,
           (heq 2 (by decide)).1.mpr m2, (heq 2 (by decide)).2.trans v2,
           (heq 3 (by decide)).1.mpr m3, (heq 3 (by decide)).2.trans v3⟩

theorem TreeStoredAt.unchanged {L tid : ℕ} {S : Finset ℕ} {rNum rDen : ℕ → ℤ}
    {ws₁ ws₂ : WordStore} (h : TreeStoredAt L tid S rNum rDen ws₁)
    (heq : ∀ u < 2 ^ (L + 1), ∀ f < 4,
      ((.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ ws₂.live ↔
        (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ ws₁.live) ∧
      ws₂.vals (.heap 2 (treeCellAddr L tid u f)) = ws₁.vals (.heap 2 (treeCellAddr L tid u f))) :
    TreeStoredAt L tid S rNum rDen ws₂ :=
  { hS := h.hS
    u0_empty := fun f hf => by rw [(heq 0 (by positivity) f hf).1]; exact h.u0_empty f hf
    nodes := fun k hk off hoff =>
      (h.nodes k hk off hoff).unchanged (fun f hf => heq _ (treeIdx_bounds hk hoff).2 f hf) }

theorem TreeStoredAt.empty (L tid : ℕ) (rNum rDen : ℕ → ℤ) {ws : WordStore}
    (hemp : ∀ u < 2 ^ (L + 1), ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∉ ws.live) :
    TreeStoredAt L tid ∅ rNum rDen ws :=
  { hS := fun _ hm => False.elim (Finset.notMem_empty _ hm)
    u0_empty := fun f hf => hemp 0 (by positivity) f hf
    nodes := fun k hk off hoff => by
      have hcnt : (treeNodeVal ∅ rNum rDen k off).1 = 0 := by
        rw [treeNodeVal_cnt]; simp [treeSubSet]
      exact ⟨fun _ f hf => hemp _ (treeIdx_bounds hk hoff).2 f hf, fun hp => by omega⟩ }

theorem NodeStoredAt.read_fields {L tid : ℕ} {S : Finset ℕ} {rNum rDen : ℕ → ℤ}
    {k off : ℕ} {ws : WordStore}
    (hn : NodeStoredAt L tid (treeIdx L k off) (treeNodeVal S rNum rDen k off) ws) :
    let v := treeNodeVal S rNum rDen k off
    let u := treeIdx L k off
    ws.read (.heap 2 (treeCellAddr L tid u 0)) = (v.1 : ℤ) ∧
    ws.read (.heap 2 (treeCellAddr L tid u 1)) = (v.2.1 : ℤ) ∧
    ws.read (.heap 2 (treeCellAddr L tid u 2)) = v.2.2.1 ∧
    ws.read (.heap 2 (treeCellAddr L tid u 3)) = v.2.2.2 := by
  set v := treeNodeVal S rNum rDen k off
  set u := treeIdx L k off
  by_cases hc : v.1 = 0
  · have hz : v = (0, 0, 0, 0) := (treeNodeVal_zero_iff S rNum rDen k off).mp hc
    have m0 := hn.1 hc 0 (by decide)
    have m1 := hn.1 hc 1 (by decide)
    have m2 := hn.1 hc 2 (by decide)
    have m3 := hn.1 hc 3 (by decide)
    rw [hz]
    simp [WordStore.read, m0, m1, m2, m3]
  · have hpos : 0 < v.1 := Nat.pos_of_ne_zero hc
    obtain ⟨m0, v0, m1, v1, m2, v2, m3, v3⟩ := hn.2 hpos
    simp [WordStore.read, m0, v0, m1, v1, m2, v2, m3, v3]

/-! ### 3. Sparsity bound on live cells of a `TreeStoredAt` slice -/

def treeSliceLocs (L tid : ℕ) : Finset RAMCellLoc :=
  (Finset.range (2 ^ (L + 1)) ×ˢ Finset.range 4).image
    (fun uf => .heap 2 (treeCellAddr L tid uf.1 uf.2))

theorem treeStoredAt_slice_card_le {L tid : ℕ} {S : Finset ℕ} {rNum rDen : ℕ → ℤ} {ws : WordStore}
    (ht : TreeStoredAt L tid S rNum rDen ws) :
    (ws.live ∩ treeSliceLocs L tid).card ≤ 4 * (L + 1) * S.card := by
  let activePairs : Finset (ℕ × ℕ) :=
    (Finset.range (L + 1)).biUnion (fun k =>
      ((Finset.range (2 ^ (L - k))).filter
        (fun off => 0 < (treeNodeVal S rNum rDen k off).1)).image (fun off => (k, off)))
  have hcard_pairs : activePairs.card ≤ (L + 1) * S.card := by
    calc activePairs.card
      _ ≤ ∑ k ∈ Finset.range (L + 1),
            (((Finset.range (2 ^ (L - k))).filter
              (fun off => 0 < (treeNodeVal S rNum rDen k off).1)).image (fun off => (k, off))).card :=
          Finset.card_biUnion_le
      _ ≤ ∑ _k ∈ Finset.range (L + 1), S.card := by
          refine Finset.sum_le_sum (fun k _ => ?_)
          exact Finset.card_image_le.trans (activeOffsets_card_le S rNum rDen L k)
      _ = (L + 1) * S.card := by simp
  have hsub : ws.live ∩ treeSliceLocs L tid ⊆
      (activePairs ×ˢ Finset.range 4).image
        (fun p => .heap 2 (treeCellAddr L tid (treeIdx L p.1.1 p.1.2) p.2)) := by
    intro loc hloc
    rcases Finset.mem_inter.mp hloc with ⟨hLive, hSlice⟩
    rcases Finset.mem_image.mp hSlice with ⟨⟨u, f⟩, huf, rfl⟩
    rcases Finset.mem_product.mp huf with ⟨hu_r, hf_r⟩
    have hu : u < 2 ^ (L + 1) := Finset.mem_range.mp hu_r
    have hf : f < 4 := Finset.mem_range.mp hf_r
    by_cases hu0 : u = 0
    · subst hu0; exact False.elim (ht.u0_empty f hf hLive)
    · have hu1 : 1 ≤ u := Nat.pos_of_ne_zero hu0
      let d := Nat.log 2 u
      have hd_pow : 2 ^ d ≤ u := Nat.pow_log_le_self 2 hu0
      have hd_lt : u < 2 ^ (d + 1) := Nat.lt_pow_succ_log_self (by decide) u
      have hd_le_L : d ≤ L := by
        by_contra hgt
        have hp : 2 ^ (L + 1) ≤ 2 ^ d := Nat.pow_le_pow_right (by decide) (by omega)
        omega
      let k := L - d
      let off := u - 2 ^ d
      have hk_le : k ≤ L := Nat.sub_le L d
      have hLk : L - k = d := by omega
      have hoff_lt : off < 2 ^ (L - k) := by rw [hLk]; rw [pow_succ] at hd_lt; omega
      have hu_eq : treeIdx L k off = u := by unfold treeIdx; rw [hLk]; omega
      have hnode := ht.nodes k hk_le off hoff_lt
      have hc_pos : 0 < (treeNodeVal S rNum rDen k off).1 := by
        by_contra hc0
        have hcz : (treeNodeVal S rNum rDen k off).1 = 0 := by omega
        rw [← hu_eq] at hLive
        exact hnode.1 hcz f hf hLive
      refine Finset.mem_image.mpr ⟨((k, off), f), ?_, by simp [hu_eq]⟩
      refine Finset.mem_product.mpr ⟨?_, hf_r⟩
      refine Finset.mem_biUnion.mpr ⟨k, Finset.mem_range.mpr (by omega), ?_⟩
      refine Finset.mem_image.mpr ⟨off, ?_, rfl⟩
      exact Finset.mem_filter.mpr ⟨Finset.mem_range.mpr hoff_lt, hc_pos⟩
  calc (ws.live ∩ treeSliceLocs L tid).card
    _ ≤ ((activePairs ×ˢ Finset.range 4).image
          (fun p => .heap 2 (treeCellAddr L tid (treeIdx L p.1.1 p.1.2) p.2))).card :=
        Finset.card_le_card hsub
    _ ≤ (activePairs ×ˢ Finset.range 4).card := Finset.card_image_le
    _ = activePairs.card * 4 := by simp
    _ ≤ ((L + 1) * S.card) * 4 := Nat.mul_le_mul_right 4 hcard_pairs
    _ = 4 * (L + 1) * S.card := by ring

/-! ### 4. Node 4-field write/free helpers and `treeSetLeafStmt`, `treeMinElemStmt`, `treeMexStmt` -/

def treePathLocs (L tid h₀ : ℕ) : Finset RAMCellLoc :=
  (Finset.range (L + 1) ×ˢ Finset.range 4).image
    (fun kf => .heap 2 (treeCellAddr L tid (treeIdx L kf.1 (h₀ / 2 ^ kf.1)) kf.2))

theorem treePathLocs_card_le (L tid h₀ : ℕ) :
    (treePathLocs L tid h₀).card ≤ 4 * (L + 1) := by
  unfold treePathLocs
  calc ((Finset.range (L + 1) ×ˢ Finset.range 4).image _).card
    _ ≤ (Finset.range (L + 1) ×ˢ Finset.range 4).card := Finset.card_image_le
    _ = 4 * (L + 1) := by simp; ring

theorem treeCellAddr_bitLength_le {L tid u f W : ℕ}
    (hu : u < 2 ^ (L + 1)) (hf : f < 4)
    (hW : natBitLength tid + L + 12 ≤ W) :
    (RAMCellLoc.heap 2 (treeCellAddr L tid u f)).bitLength ≤ W ∧
    intBitLength (treeCellAddr L tid u f) ≤ W := by
  have hval_lt : (tid * 2 ^ (L + 1) + u) * 4 + f < (tid + 1) * 2 ^ (L + 3) := by
    have h1 : tid * 2 ^ (L + 1) + u < (tid + 1) * 2 ^ (L + 1) := by rw [add_mul, one_mul]; omega
    have hm : (tid * 2 ^ (L + 1) + u) * 4 < (tid + 1) * 2 ^ (L + 1) * 4 :=
      Nat.mul_lt_mul_of_pos_right h1 (by decide)
    have h2 : (tid + 1) * 2 ^ (L + 3) = (tid + 1) * 2 ^ (L + 1) * 4 := by ring
    omega
  have hlog : natBitLength ((tid * 2 ^ (L + 1) + u) * 4 + f) ≤ natBitLength tid + L + 5 := by
    by_cases hz : (tid * 2 ^ (L + 1) + u) * 4 + f = 0
    · rw [hz]; unfold natBitLength
      have hlog0 : Nat.log 2 0 = 0 := by decide
      rw [hlog0]; omega
    · unfold natBitLength
      have hle1 : (tid * 2 ^ (L + 1) + u) * 4 + f < 2 ^ (Nat.log 2 tid + 1 + (L + 3)) := by
        have htid_lt : tid + 1 ≤ 2 ^ (Nat.log 2 tid + 1) := Nat.lt_pow_succ_log_self (by decide) tid
        calc (tid * 2 ^ (L + 1) + u) * 4 + f
          _ < (tid + 1) * 2 ^ (L + 3) := hval_lt
          _ ≤ 2 ^ (Nat.log 2 tid + 1) * 2 ^ (L + 3) := Nat.mul_le_mul_right (2 ^ (L + 3)) htid_lt
          _ = 2 ^ (Nat.log 2 tid + 1 + (L + 3)) := (pow_add 2 (Nat.log 2 tid + 1) (L + 3)).symm
      have hlog_lt : Nat.log 2 ((tid * 2 ^ (L + 1) + u) * 4 + f) < Nat.log 2 tid + 1 + (L + 3) :=
        Nat.log_lt_of_lt_pow hz hle1
      omega
  have hib : intBitLength (treeCellAddr L tid u f) ≤ natBitLength tid + L + 6 := by
    unfold treeCellAddr
    have h0 := intBitLength_ofNat_le ((tid * 2 ^ (L + 1) + u) * 4 + f)
    omega
  have hn2 : natBitLength 2 = 2 := by decide
  constructor
  · dsimp [RAMCellLoc.bitLength]; rw [hn2]; omega
  · omega

theorem intBitLength_natCast_mono {a b : ℕ} (h : a ≤ b) :
    intBitLength (a : ℤ) ≤ intBitLength (b : ℤ) := by
  unfold intBitLength natBitLength
  by_cases ha : a = 0
  · subst ha; simp only [Nat.cast_zero, ↓reduceIte]; split_ifs <;> omega
  · have hb : b ≠ 0 := by omega
    have haz : (a : ℤ) ≠ 0 := by omega
    have hbz : (b : ℤ) ≠ 0 := by omega
    rw [if_neg haz, if_neg hbz]
    simp only [Int.natAbs_natCast]
    have hlog := Nat.log_mono_right (b := 2) h
    omega

/-- Write `(regs 1, regs 2, regs 3, regs 4)` to `base = regs 9` (`base + 0..3` in table `2`) if `regs 1 ≠ 0`,
else free `base + 0..3` in table `2`, using `r10, r15` as scratch. -/
def writeOrFreeNode4Stmt : BitRAMStmt :=
  .ite (.intEq (.readLocal 1 (.lit 0)) (.lit 0))
    -- Free `r9 + 0..3`
    (.seq (rCopy 10 9)
    (.seq (rFree 2 10)
    (.seq (rLit 15 1)
    (.seq (rAdd 10 10 15)
    (.seq (rFree 2 10)
    (.seq (rAdd 10 10 15)
    (.seq (rFree 2 10)
    (.seq (rAdd 10 10 15)
          (rFree 2 10)))))))))
    -- Store `r1, r2, r3, r4` at `r9 + 0..3`
    (.seq (rCopy 10 9)
    (.seq (rStore 2 10 1)
    (.seq (rLit 15 1)
    (.seq (rAdd 10 10 15)
    (.seq (rStore 2 10 2)
    (.seq (rAdd 10 10 15)
    (.seq (rStore 2 10 3)
    (.seq (rAdd 10 10 15)
          (rStore 2 10 4)))))))))

theorem exec_writeOrFreeNode4Stmt {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid u : ℕ} (hu : u < 2 ^ (L + 1))
    (hW_addr : natBitLength tid + L + 12 ≤ W)
    (hSubWrite : ∀ f < 4, (.heap 2 (treeCellAddr L tid u f) : RAMCellLoc) ∈ S_write)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    {v : ℕ × ℕ × ℤ × ℤ}
    (hr1 : regs 1 = (v.1 : ℤ))
    (hr2 : regs 2 = (v.2.1 : ℤ))
    (hr3 : regs 3 = v.2.2.1)
    (hr4 : regs 4 = v.2.2.2)
    (hr9 : regs 9 = treeCellAddr L tid u 0) :
    ∃ ws' regs',
      RegExec inp fd W C_cell C_bit writeOrFreeNode4Stmt ws regs ws' regs' 80 (80 * W + 400) ∧
      ModifiedOnBounded ws₀ S_write W ws' ∧
      RegBounded W regs' ∧
      NodeStoredAt L tid u v ws' ∧
      (∀ loc : RAMCellLoc, (∀ f < 4, loc ≠ .heap 2 (treeCellAddr L tid u f)) →
        (loc ∈ ws'.live ↔ loc ∈ ws.live) ∧ ws'.vals loc = ws.vals loc) ∧
      (∀ r < 16, r ≠ 10 → r ≠ 15 → regs' r = regs r) := by
  have hW8 := hbnd.1
  have hn2_bl : natBitLength 2 ≤ W := by have : natBitLength 2 = 2 := (by decide); omega
  have hl1_bl : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl0_bl : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have haddr_eq : ∀ f : ℕ, treeCellAddr L tid u 0 + (f : ℤ) = treeCellAddr L tid u f := by
    intro f; unfold treeCellAddr; push_cast; ring
  have haddr_step : ∀ f : ℕ, treeCellAddr L tid u f + 1 = treeCellAddr L tid u (f + 1) := by
    intro f; unfold treeCellAddr; push_cast; ring
  have haddr_bl : ∀ f < 4,
      (RAMCellLoc.heap 2 (treeCellAddr L tid u f)).bitLength ≤ W ∧
      intBitLength (treeCellAddr L tid u f) ≤ W :=
    fun f hf => treeCellAddr_bitLength_le hu hf hW_addr
  -- Put `0` in `r15`? Wait: `.ite (.intEq (.readLocal 1 (.lit 0)) (.lit 0))` compares `r1` to `.lit 0` directly!
  -- Let's prove the `.ite` directly on `st` so we don't even need a register holding `0`!
  by_cases hv0 : v.1 = 0
  · -- Branch `v.1 = 0`: free all 4 fields!
    let a0 := treeCellAddr L tid u 0
    let a1 := treeCellAddr L tid u 1
    let a2 := treeCellAddr L tid u 2
    let a3 := treeCellAddr L tid u 3
    let ws1 := ws.free (.heap 2 a0)
    let ws2 := ws1.free (.heap 2 a1)
    let ws3 := ws2.free (.heap 2 a2)
    let ws4 := ws3.free (.heap 2 a3)
    have hm0 := hmod
    have hm1 := hm0.free (hSubWrite 0 (by decide))
    have hm2 := hm1.free (hSubWrite 1 (by decide))
    have hm3 := hm2.free (hSubWrite 2 (by decide))
    have hm4 := hm3.free (hSubWrite 3 (by decide))
    have hc_sp : ∀ w : WordStore, ModifiedOnBounded ws₀ S_write W w →
        inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
        inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
      intro w hmw; obtain ⟨hc, hb⟩ := hmw.space_le; exact ⟨by linarith, by linarith⟩
    have s1 := RegExec.copy (inp := inp) hfd_le hbnd (hc_sp ws hm0).1 (hc_sp ws hm0).2 (dst := 10) (src := 9) (by decide) (by decide)
    set rg1 := Function.update regs 10 (regs 9)
    have hb1 : RegBounded W rg1 := hbnd.update (by decide) (hbnd.2.1 9 (by decide))
    have hrg1_10 : rg1 10 = a0 := by simp [rg1, hr9, a0]
    have s2 := RegExec.free (inp := inp) (C_cell := C_cell) (C_bit := C_bit) (fd := fd) (wsHeap := ws) hb1 (table := 2) (addr := 10) (by decide) hn2_bl
    rw [hrg1_10] at s2
    have s3 := RegExec.lit (inp := inp) hfd_le hb1 (hc_sp ws1 hm1).1 (hc_sp ws1 hm1).2 (dst := 15) (by decide) hl1_bl
    set rg3 := Function.update rg1 15 1
    have hb3 : RegBounded W rg3 := hb1.update (by decide) hl1_bl
    have hadd1 : rg3 10 + rg3 15 = a1 := by
      simp only [rg3, Function.update_of_ne (by decide : (10 : ℕ) ≠ 15), Function.update_self, hrg1_10, a0, a1]
      exact haddr_step 0
    have s4 := RegExec.add (inp := inp) hfd_le hb3 (hc_sp ws1 hm1).1 (hc_sp ws1 hm1).2 (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [hadd1]; exact (haddr_bl 1 (by decide)).2)
    rw [hadd1] at s4
    set rg4 := Function.update rg3 10 a1
    have hb4 : RegBounded W rg4 := hb3.update (by decide) (haddr_bl 1 (by decide)).2
    have s5 := RegExec.free (inp := inp) (C_cell := C_cell) (C_bit := C_bit) (fd := fd) (wsHeap := ws1) hb4 (table := 2) (addr := 10) (by decide) hn2_bl
    simp only [rg4, Function.update_self] at s5
    have hadd2 : rg4 10 + rg4 15 = a2 := by
      simp only [rg4, rg3, Function.update_of_ne (by decide : (15 : ℕ) ≠ 10), Function.update_self, a1, a2]
      exact haddr_step 1
    have s6 := RegExec.add (inp := inp) hfd_le hb4 (hc_sp ws2 hm2).1 (hc_sp ws2 hm2).2 (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [hadd2]; exact (haddr_bl 2 (by decide)).2)
    rw [hadd2] at s6
    set rg6 := Function.update rg4 10 a2
    have hb6 : RegBounded W rg6 := hb4.update (by decide) (haddr_bl 2 (by decide)).2
    have s7 := RegExec.free (inp := inp) (C_cell := C_cell) (C_bit := C_bit) (fd := fd) (wsHeap := ws2) hb6 (table := 2) (addr := 10) (by decide) hn2_bl
    simp only [rg6, Function.update_self] at s7
    have hadd3 : rg6 10 + rg6 15 = a3 := by
      simp only [rg6, rg4, rg3, Function.update_of_ne (by decide : (15 : ℕ) ≠ 10), Function.update_self, a2, a3]
      exact haddr_step 2
    have s8 := RegExec.add (inp := inp) hfd_le hb6 (hc_sp ws3 hm3).1 (hc_sp ws3 hm3).2 (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [hadd3]; exact (haddr_bl 3 (by decide)).2)
    rw [hadd3] at s8
    set rg8 := Function.update rg6 10 a3
    have hb8 : RegBounded W rg8 := hb6.update (by decide) (haddr_bl 3 (by decide)).2
    have s9 := RegExec.free (inp := inp) (C_cell := C_cell) (C_bit := C_bit) (fd := fd) (wsHeap := ws3) hb8 (table := 2) (addr := 10) (by decide) hn2_bl
    simp only [rg8, Function.update_self] at s9
    have sChain := s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq s9)))))))
    refine ⟨ws4, rg8, ?_, hm4, hb8, ?_, ?_, ?_⟩
    · intro st hfd hrf hpC hpB
      have hl0_d : intBitLength (0 : ℤ) = 1 := by decide
      have hv1_d : natBitLength 1 = 1 := by decide
      have hr1_z : regs 1 = 0 := by rw [hr1, hv0]; rfl
      have hcond : evalBitCond inp st.frameDepth st.words (.intEq (.readLocal 1 (.lit 0)) (.lit 0)) =
          (true, 4, 7) := by
        rw [hfd]
        simp [evalBitCond, evalIntExpr, hrf.reg_read 1 (by decide), hr1_z, hl0_d, hv1_d]
      let st0 : BitRAMExecState := { st with unitCost := st.unitCost + 4, bitCost := st.bitCost + 7 }
      obtain ⟨stEnd, hrE, hrfE, hbndE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
        sChain st0 hfd hrf hpC hpB
      have hite : RunsTo inp [.stmt writeOrFreeNode4Stmt] st stEnd := by
        unfold writeOrFreeNode4Stmt
        apply RunsTo.ite; rw [hcond]; simp only [↓reduceIte]; exact hrE
      exact ⟨stEnd, hite, hrfE, hbndE, hfdE, hrbE,
        by dsimp [st0] at hucE; omega,
        by dsimp [st0] at hbcE; omega,
        hpCE, hpBE⟩
    · refine ⟨fun _ f hf => ?_, fun hp => by omega⟩
      have hne01 : a0 ≠ a1 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      have hne02 : a0 ≠ a2 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      have hne03 : a0 ≠ a3 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      have hne12 : a1 ≠ a2 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      have hne13 : a1 ≠ a3 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      have hne23 : a2 ≠ a3 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      interval_cases f
      · simp [ws4, ws3, ws2, ws1, WordStore.free, a0]
      · simp [ws4, ws3, ws2, ws1, WordStore.free, a1]
      · simp [ws4, ws3, ws2, WordStore.free, a2]
      · simp [ws4, WordStore.free, a3]
    · intro loc hne
      have h0 := hne 0 (by decide); have h1 := hne 1 (by decide)
      have h2 := hne 2 (by decide); have h3 := hne 3 (by decide)
      simp [ws4, ws3, ws2, ws1, WordStore.free, a0, a1, a2, a3, h0, h1, h2, h3]
    · intro r _ hr10 hr15
      simp [rg8, rg6, rg4, rg3, rg1, Function.update_of_ne hr10, Function.update_of_ne hr15]
  · -- Branch `0 < v.1`: store all 4 fields!
    have hv_pos : 0 < v.1 := Nat.pos_of_ne_zero hv0
    let a0 := treeCellAddr L tid u 0
    let a1 := treeCellAddr L tid u 1
    let a2 := treeCellAddr L tid u 2
    let a3 := treeCellAddr L tid u 3
    let ws1 := ws.write (.heap 2 a0) (regs 1)
    let ws2 := ws1.write (.heap 2 a1) (regs 2)
    let ws3 := ws2.write (.heap 2 a2) (regs 3)
    let ws4 := ws3.write (.heap 2 a3) (regs 4)
    have hm0 := hmod
    have hm1 := hm0.write (hSubWrite 0 (by decide)) (regs 1) (haddr_bl 0 (by decide)).1 (hbnd.2.1 1 (by decide))
    have hm2 := hm1.write (hSubWrite 1 (by decide)) (regs 2) (haddr_bl 1 (by decide)).1 (hbnd.2.1 2 (by decide))
    have hm3 := hm2.write (hSubWrite 2 (by decide)) (regs 3) (haddr_bl 2 (by decide)).1 (hbnd.2.1 3 (by decide))
    have hm4 := hm3.write (hSubWrite 3 (by decide)) (regs 4) (haddr_bl 3 (by decide)).1 (hbnd.2.1 4 (by decide))
    have hc_sp : ∀ w : WordStore, ModifiedOnBounded ws₀ S_write W w →
        inp.inputCellSpace + w.cellCount + 16 ≤ C_cell ∧
        inp.inputBitSpace + w.bitSize + 16 * (W + 12) ≤ C_bit := by
      intro w hmw; obtain ⟨hc, hb⟩ := hmw.space_le; exact ⟨by linarith, by linarith⟩
    have s1 := RegExec.copy (inp := inp) hfd_le hbnd (hc_sp ws hm0).1 (hc_sp ws hm0).2 (dst := 10) (src := 9) (by decide) (by decide)
    set rg1 := Function.update regs 10 (regs 9)
    have hb1 : RegBounded W rg1 := hbnd.update (by decide) (hbnd.2.1 9 (by decide))
    have hrg1_10 : rg1 10 = a0 := by simp [rg1, hr9, a0]
    have hrg1_1 : rg1 1 = regs 1 := by simp [rg1]
    have s2 := RegExec.store (inp := inp) (C_cell := C_cell) (C_bit := C_bit) hfd_le hb1 (table := 2) (addr := 10) (val := 1) (by decide) (by decide) hn2_bl
      (by rw [hrg1_10, hrg1_1]; exact (hc_sp ws1 hm1).1)
      (by rw [hrg1_10, hrg1_1]; exact (hc_sp ws1 hm1).2)
    rw [hrg1_10, hrg1_1] at s2
    have s3 := RegExec.lit (inp := inp) hfd_le hb1 (hc_sp ws1 hm1).1 (hc_sp ws1 hm1).2 (dst := 15) (by decide) hl1_bl
    set rg3 := Function.update rg1 15 1
    have hb3 : RegBounded W rg3 := hb1.update (by decide) hl1_bl
    have hadd1 : rg3 10 + rg3 15 = a1 := by
      simp only [rg3, Function.update_of_ne (by decide : (10 : ℕ) ≠ 15), Function.update_self, hrg1_10, a0, a1]
      exact haddr_step 0
    have s4 := RegExec.add (inp := inp) hfd_le hb3 (hc_sp ws1 hm1).1 (hc_sp ws1 hm1).2 (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [hadd1]; exact (haddr_bl 1 (by decide)).2)
    rw [hadd1] at s4
    set rg4 := Function.update rg3 10 a1
    have hb4 : RegBounded W rg4 := hb3.update (by decide) (haddr_bl 1 (by decide)).2
    have hrg4_10 : rg4 10 = a1 := by simp [rg4]
    have hrg4_2 : rg4 2 = regs 2 := by simp [rg4, rg3, rg1]
    have s5 := RegExec.store (inp := inp) (C_cell := C_cell) (C_bit := C_bit) hfd_le hb4 (table := 2) (addr := 10) (val := 2) (by decide) (by decide) hn2_bl
      (by rw [hrg4_10, hrg4_2]; exact (hc_sp ws2 hm2).1)
      (by rw [hrg4_10, hrg4_2]; exact (hc_sp ws2 hm2).2)
    rw [hrg4_10, hrg4_2] at s5
    have hadd2 : rg4 10 + rg4 15 = a2 := by
      simp only [rg4, rg3, Function.update_of_ne (by decide : (15 : ℕ) ≠ 10), Function.update_self, a1, a2]
      exact haddr_step 1
    have s6 := RegExec.add (inp := inp) hfd_le hb4 (hc_sp ws2 hm2).1 (hc_sp ws2 hm2).2 (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [hadd2]; exact (haddr_bl 2 (by decide)).2)
    rw [hadd2] at s6
    set rg6 := Function.update rg4 10 a2
    have hb6 : RegBounded W rg6 := hb4.update (by decide) (haddr_bl 2 (by decide)).2
    have hrg6_10 : rg6 10 = a2 := by simp [rg6]
    have hrg6_3 : rg6 3 = regs 3 := by simp [rg6, rg4, rg3, rg1]
    have s7 := RegExec.store (inp := inp) (C_cell := C_cell) (C_bit := C_bit) hfd_le hb6 (table := 2) (addr := 10) (val := 3) (by decide) (by decide) hn2_bl
      (by rw [hrg6_10, hrg6_3]; exact (hc_sp ws3 hm3).1)
      (by rw [hrg6_10, hrg6_3]; exact (hc_sp ws3 hm3).2)
    rw [hrg6_10, hrg6_3] at s7
    have hadd3 : rg6 10 + rg6 15 = a3 := by
      simp only [rg6, rg4, rg3, Function.update_of_ne (by decide : (15 : ℕ) ≠ 10), Function.update_self, a2, a3]
      exact haddr_step 2
    have s8 := RegExec.add (inp := inp) hfd_le hb6 (hc_sp ws3 hm3).1 (hc_sp ws3 hm3).2 (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide) (by rw [hadd3]; exact (haddr_bl 3 (by decide)).2)
    rw [hadd3] at s8
    set rg8 := Function.update rg6 10 a3
    have hb8 : RegBounded W rg8 := hb6.update (by decide) (haddr_bl 3 (by decide)).2
    have hrg8_10 : rg8 10 = a3 := by simp [rg8]
    have hrg8_4 : rg8 4 = regs 4 := by simp [rg8, rg6, rg4, rg3, rg1]
    have s9 := RegExec.store (inp := inp) (C_cell := C_cell) (C_bit := C_bit) hfd_le hb8 (table := 2) (addr := 10) (val := 4) (by decide) (by decide) hn2_bl
      (by rw [hrg8_10, hrg8_4]; exact (hc_sp ws4 hm4).1)
      (by rw [hrg8_10, hrg8_4]; exact (hc_sp ws4 hm4).2)
    rw [hrg8_10, hrg8_4] at s9
    have sChain := s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq s9)))))))
    refine ⟨ws4, rg8, ?_, hm4, hb8, ?_, ?_, ?_⟩
    · intro st hfd hrf hpC hpB
      have hl0_d : intBitLength (0 : ℤ) = 1 := by decide
      have hv1_d : natBitLength 1 = 1 := by decide
      have hr1_nz : regs 1 ≠ 0 := by rw [hr1]; omega
      have hr1_bl : intBitLength (regs 1) ≤ W := hbnd.2.1 1 (by decide)
      have hcond : evalBitCond inp st.frameDepth st.words (.intEq (.readLocal 1 (.lit 0)) (.lit 0)) =
          (false, 4, 1 + 1 + 1 + intBitLength (regs 1) + 1 + intBitLength (regs 1) + 1) := by
        rw [hfd]
        simp [evalBitCond, evalIntExpr, hrf.reg_read 1 (by decide), hr1_nz, hl0_d, hv1_d]
      let st0 : BitRAMExecState :=
        { st with
          unitCost := st.unitCost + 4
          bitCost := st.bitCost + (1 + 1 + 1 + intBitLength (regs 1) + 1 + intBitLength (regs 1) + 1) }
      obtain ⟨stEnd, hrE, hrfE, hbndE, hfdE, hrbE, hucE, hbcE, hpCE, hpBE⟩ :=
        sChain st0 hfd hrf hpC hpB
      have hite : RunsTo inp [.stmt writeOrFreeNode4Stmt] st stEnd := by
        unfold writeOrFreeNode4Stmt
        apply RunsTo.ite; rw [hcond]; simp only [Bool.false_eq_true, ↓reduceIte]; exact hrE
      exact ⟨stEnd, hite, hrfE, hbndE, hfdE, hrbE,
        by dsimp [st0] at hucE; omega,
        by dsimp [st0] at hbcE; omega,
        hpCE, hpBE⟩
    · refine ⟨fun hz => by omega, fun _ => ?_⟩
      have hne01 : a0 ≠ a1 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      have hne02 : a0 ≠ a2 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      have hne03 : a0 ≠ a3 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      have hne12 : a1 ≠ a2 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      have hne13 : a1 ≠ a3 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      have hne23 : a2 ≠ a3 := fun h => by have := treeCellAddr_inj hu (by decide) hu (by decide) h; omega
      refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · dsimp only [ws4, ws3, ws2, ws1, a0, a1, a2, a3]; simp [WordStore.write]
      · change (ws3.write (.heap 2 a3) (regs 4)).vals (.heap 2 a0) = (v.1 : ℤ)
        dsimp only [ws3, ws2, ws1]
        simp [WordStore.write, hne03, hne02, hne01, hr1]
      · dsimp only [ws4, ws3, ws2, ws1, a0, a1, a2, a3]; simp [WordStore.write]
      · change (ws3.write (.heap 2 a3) (regs 4)).vals (.heap 2 a1) = (v.2.1 : ℤ)
        dsimp only [ws3, ws2, ws1]
        simp [WordStore.write, hne13, hne12, hr2]
      · dsimp only [ws4, ws3, ws2, ws1, a0, a1, a2, a3]; simp [WordStore.write]
      · change (ws3.write (.heap 2 a3) (regs 4)).vals (.heap 2 a2) = v.2.2.1
        dsimp only [ws3]
        simp [WordStore.write, hne23, hr3]
      · dsimp only [ws4, a3]; simp [WordStore.write]
      · change (ws3.write (.heap 2 a3) (regs 4)).vals (.heap 2 a3) = v.2.2.2
        simp [WordStore.write, hr4]
    · intro loc hne
      have h0 := hne 0 (by decide); have h1 := hne 1 (by decide)
      have h2 := hne 2 (by decide); have h3 := hne 3 (by decide)
      simp [ws4, ws3, ws2, ws1, WordStore.write, a0, a1, a2, a3, h0, h1, h2, h3]
    · intro r _ hr10 hr15
      simp [rg8, rg6, rg4, rg3, rg1, Function.update_of_ne hr10, Function.update_of_ne hr15]


/-! ### 5. Bit-length bounds on `treeNodeVal` and bottom-up `treeSetLeafRegs` -/

theorem nat_pow2_bitLength_le (m : ℕ) : intBitLength ((2 ^ m : ℕ) : ℤ) ≤ m + 3 := by
  have _hpos : (2 ^ m : ℕ) ≠ 0 := pow_ne_zero m (by decide)
  have hlog : Nat.log 2 (2 ^ m) = m := Nat.log_pow (by decide) m
  have h1 := intBitLength_ofNat_le (2 ^ m)
  unfold natBitLength at h1
  omega

theorem nat_lt_pow2_bitLength_le {x m : ℕ} (hx : x < 2 ^ m) :
    intBitLength (x : ℤ) ≤ m + 2 := by
  by_cases hx0 : x = 0
  · subst hx0
    have h0 : intBitLength (0 : ℤ) = 1 := by decide
    rw [Nat.cast_zero, h0]; omega
  · have hlog : Nat.log 2 x < m := Nat.log_lt_of_lt_pow hx0 hx
    have h1 := intBitLength_ofNat_le x
    unfold natBitLength at h1
    omega

theorem treeNodeVal_bounds {S : Finset ℕ} {rNum rDen : ℕ → ℤ} {L B_r : ℕ}
    (hB1 : 1 ≤ B_r)
    (hS : ∀ h ∈ S, h < 2 ^ L ∧ intBitLength (rNum h) ≤ B_r ∧ intBitLength (rDen h) ≤ B_r) :
    ∀ (k : ℕ), k ≤ L → ∀ (off : ℕ),
      let v := treeNodeVal S rNum rDen k off
      v.1 ≤ 2 ^ k ∧
      (v.2.1 < 2 ^ L ∨ v.2.1 = 0) ∧
      intBitLength (v.1 : ℤ) ≤ L + 3 ∧
      intBitLength (v.2.1 : ℤ) ≤ L + 2 ∧
      intBitLength v.2.2.1 ≤ B_r ∧
      intBitLength v.2.2.2 ≤ B_r := by
  intro k
  induction k with
  | zero =>
      intro hk off
      simp only [treeNodeVal]
      have hl0 : intBitLength (0 : ℤ) = 1 := by decide
      have hl1 : intBitLength (1 : ℤ) = 2 := by decide
      split_ifs with hm
      · obtain ⟨hh, hn, hd⟩ := hS off hm
        dsimp only
        exact ⟨by simp, Or.inl hh, by rw [Nat.cast_one, hl1]; omega, nat_lt_pow2_bitLength_le hh, hn, hd⟩
      · dsimp only
        exact ⟨by simp, Or.inr rfl, by rw [Nat.cast_zero, hl0]; omega, by rw [Nat.cast_zero, hl0]; omega, by rw [hl0]; omega, by rw [hl0]; omega⟩
  | succ k ih =>
      intro hk off
      obtain ⟨cL_le, hL_lt, _, hL_bl, nL_bl, dL_bl⟩ := ih (by omega) (2 * off)
      obtain ⟨cR_le, hR_lt, _, hR_bl, nR_bl, dR_bl⟩ := ih (by omega) (2 * off + 1)
      rcases eL : treeNodeVal S rNum rDen k (2 * off) with ⟨cL, hLv, nL, dL⟩
      rcases eR : treeNodeVal S rNum rDen k (2 * off + 1) with ⟨cR, hRv, nR, dR⟩
      rw [eL] at cL_le hL_lt hL_bl nL_bl dL_bl
      rw [eR] at cR_le hR_lt hR_bl nR_bl dR_bl
      dsimp only at *
      have hc_sum : cL + cR ≤ 2 ^ (k + 1) := by rw [pow_succ]; omega
      have hc_sum_bl : intBitLength ((cL + cR : ℕ) : ℤ) ≤ L + 3 := by
        have hle_L : cL + cR ≤ 2 ^ L := hc_sum.trans (Nat.pow_le_pow_right (by decide) hk)
        rcases lt_or_eq_of_le hle_L with hlt | heq
        · exact (nat_lt_pow2_bitLength_le hlt).trans (by omega)
        · rw [heq]; exact nat_pow2_bitLength_le L
      simp only [treeNodeVal, eL, eR]
      by_cases hcL : cL = 0
      · rw [if_pos hcL]
        have hcR_le2 : cR ≤ 2 ^ (k + 1) := by rw [pow_succ]; omega
        have hcR_bl : intBitLength (cR : ℤ) ≤ L + 3 := by
          subst hcL; simpa using hc_sum_bl
        exact ⟨hcR_le2, hR_lt, hcR_bl, hR_bl, nR_bl, dR_bl⟩
      · rw [if_neg hcL]
        by_cases hcR : cR = 0
        · rw [if_pos hcR]
          have hcL_le2 : cL ≤ 2 ^ (k + 1) := by rw [pow_succ]; omega
          have hcL_bl : intBitLength (cL : ℤ) ≤ L + 3 := by
            subst hcR; simpa using hc_sum_bl
          exact ⟨hcL_le2, hL_lt, hcL_bl, hL_bl, nL_bl, dL_bl⟩
        · rw [if_neg hcR]
          split_ifs
          · exact ⟨hc_sum, hL_lt, hc_sum_bl, hL_bl, nL_bl, dL_bl⟩
          · exact ⟨hc_sum, hR_lt, hc_sum_bl, hR_bl, nR_bl, dR_bl⟩


/-- Load 8 consecutive fields from `baseL = (r7 + 2 * uPar) * 4` (`r6` holds `uChild`, sets `r6 := r6 / 2 = uPar`):
`(cL, hL, nL, dL)` into `(r1, r2, r3, r4)` and `(cR, hR, nR, dR)` into `(r8, r11, r12, r13)`. -/
def loadTwoChildrenStmt : BitRAMStmt :=
  .seq (rLit 10 2)
  (.seq (rDiv 6 6 10)
  (.seq (rAdd 10 6 6)
  (.seq (rAdd 10 7 10)
  (.seq (rLit 15 4)
  (.seq (rMul 10 10 15)
  (.seq (rLoad 1 2 10)
  (.seq (rLit 15 1)
  (.seq (.seq (rAdd 10 10 15) (rLoad 2 2 10))
  (.seq (.seq (rAdd 10 10 15) (rLoad 3 2 10))
  (.seq (.seq (rAdd 10 10 15) (rLoad 4 2 10))
  (.seq (.seq (rAdd 10 10 15) (rLoad 8 2 10))
  (.seq (.seq (rAdd 10 10 15) (rLoad 11 2 10))
  (.seq (.seq (rAdd 10 10 15) (rLoad 12 2 10))
        (.seq (rAdd 10 10 15) (rLoad 13 2 10)))))))))))))))

/-- Merge `(r1, r2, r3, r4)` and `(r8, r11, r12, r13)` into `(r1, r2, r3, r4)` following `treeNodeVal`,
compute `r9 := (r7 + r6) * 4`, and call `writeOrFreeNode4Stmt`. -/
def mergeAndStoreParentStmt : BitRAMStmt :=
  .seq (rLit 15 0)
  (.seq
    (.ite (.intEq (.readLocal 1 (.lit 0)) (.readLocal 15 (.lit 0)))
      (.seq (rCopy 1 8) (.seq (rCopy 2 11) (.seq (rCopy 3 12) (rCopy 4 13))))
      (.ite (.intEq (.readLocal 8 (.lit 0)) (.readLocal 15 (.lit 0)))
        .skip
        (.seq (rAdd 1 1 8)
        (.seq (rMul 14 12 4)
        (.seq (rMul 15 3 13)
        (.ite (.intLe (.readLocal 14 (.lit 0)) (.readLocal 15 (.lit 0)))
          .skip
          (.seq (rCopy 2 11) (.seq (rCopy 3 12) (rCopy 4 13)))))))))
    (.seq (rAdd 9 7 6)
    (.seq (rLit 15 4)
    (.seq (rMul 9 9 15)
          writeOrFreeNode4Stmt))))

def parentStepStmt : BitRAMStmt :=
  .seq loadTwoChildrenStmt mergeAndStoreParentStmt

private theorem exec_loadTwoChildrenStmt {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid i h₀ B_r : ℕ} (hi : i < L) (hh₀ : h₀ < 2 ^ L) (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 16 ≤ W)
    {S' : Finset ℕ} {rNum' rDen' : ℕ → ℤ}
    (hS' : ∀ h ∈ S', h < 2 ^ L ∧ intBitLength (rNum' h) ≤ B_r ∧ intBitLength (rDen' h) ≤ B_r)
    (hnL : NodeStoredAt L tid (treeIdx L i (2 * (h₀ / 2 ^ (i + 1))))
      (treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)))) ws)
    (hnR : NodeStoredAt L tid (treeIdx L i (2 * (h₀ / 2 ^ (i + 1)) + 1))
      (treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)) + 1)) ws)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr6 : regs 6 = (treeIdx L i (h₀ / 2 ^ i) : ℤ))
    (hr7 : regs 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ)) :
    let offPar := h₀ / 2 ^ (i + 1)
    let vL := treeNodeVal S' rNum' rDen' i (2 * offPar)
    let vR := treeNodeVal S' rNum' rDen' i (2 * offPar + 1)
    ∃ regs',
      RegExec inp fd W C_cell C_bit loadTwoChildrenStmt ws regs ws regs' 160 (24 * W * W) ∧
      RegBounded W regs' ∧
      regs' 6 = (treeIdx L (i + 1) offPar : ℤ) ∧
      regs' 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) ∧
      regs' 1 = (vL.1 : ℤ) ∧ regs' 2 = (vL.2.1 : ℤ) ∧ regs' 3 = vL.2.2.1 ∧ regs' 4 = vL.2.2.2 ∧
      regs' 8 = (vR.1 : ℤ) ∧ regs' 11 = (vR.2.1 : ℤ) ∧ regs' 12 = vR.2.2.1 ∧ regs' 13 = vR.2.2.2 := by
  intro offPar vL vR
  obtain ⟨hc_s, hb_s⟩ := hmod.space_le
  have hc_ok : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell := by linarith only [hc_s, hcCeil]
  have hb_ok : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit := by linarith only [hb_s, hbCeil]
  have hW8 : 18 ≤ W := by omega
  have hn2_bl : natBitLength 2 ≤ W := by have : natBitLength 2 = 2 := (by decide); omega
  have hl1_bl : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl2_bl : intBitLength (2 : ℤ) ≤ W := by have : intBitLength (2 : ℤ) = 3 := (by decide); omega
  have hl4_bl : intBitLength (4 : ℤ) ≤ W := by have : intBitLength (4 : ℤ) = 4 := (by decide); omega
  have hoff_lt : offPar < 2 ^ (L - (i + 1)) := by
    dsimp [offPar]
    rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add]
    have : L - (i + 1) + (i + 1) = L := by omega
    rw [this]; exact hh₀
  have hoffL_lt : 2 * offPar < 2 ^ (L - i) := by
    have : L - i = (L - (i + 1)) + 1 := by omega
    rw [this, pow_succ]; omega
  have hoffR_lt : 2 * offPar + 1 < 2 ^ (L - i) := by
    have : L - i = (L - (i + 1)) + 1 := by omega
    rw [this, pow_succ]; omega
  have huPar_eq : (treeIdx L i (h₀ / 2 ^ i) : ℤ) / 2 = (treeIdx L (i + 1) offPar : ℤ) := by
    have hnat : treeIdx L i (h₀ / 2 ^ i) / 2 = treeIdx L (i + 1) offPar := by
      unfold treeIdx
      have hLi : L - i = (L - (i + 1)) + 1 := by omega
      rw [hLi, pow_succ]
      have hdiv : (2 ^ (L - (i + 1)) * 2 + h₀ / 2 ^ i) / 2 = 2 ^ (L - (i + 1)) + (h₀ / 2 ^ i) / 2 := by
        omega
      rw [hdiv, Nat.div_div_eq_div_mul, ← pow_succ]
    exact_mod_cast hnat
  set uPar := treeIdx L (i + 1) offPar
  set uL := treeIdx L i (2 * offPar)
  set uR := treeIdx L i (2 * offPar + 1)
  have huL_eq : 2 * uPar = uL := by
    dsimp [uPar, uL, treeIdx]
    have hLi : L - i = (L - (i + 1)) + 1 := by omega
    rw [hLi, pow_succ]; ring
  have huR_eq : uL + 1 = uR := by dsimp [uL, uR, treeIdx]; omega
  have huPar_b := treeIdx_bounds (by omega : i + 1 ≤ L) hoff_lt
  have huL_b := treeIdx_bounds (by omega : i ≤ L) hoffL_lt
  have huR_b := treeIdx_bounds (by omega : i ≤ L) hoffR_lt
  obtain ⟨_, _, cL_bl, hL_bl, nL_bl, dL_bl⟩ := treeNodeVal_bounds hBr1 hS' i (by omega) (2 * offPar)
  obtain ⟨_, _, cR_bl, hR_bl, nR_bl, dR_bl⟩ := treeNodeVal_bounds hBr1 hS' i (by omega) (2 * offPar + 1)
  obtain ⟨rL0, rL1, rL2, rL3⟩ := hnL.read_fields
  obtain ⟨rR0, rR1, rR2, rR3⟩ := hnR.read_fields
  have hW_addr : natBitLength tid + L + 12 ≤ W := by omega
  have haL_bl : ∀ f < 4, intBitLength (treeCellAddr L tid uL f) ≤ W :=
    fun f hf => (treeCellAddr_bitLength_le huL_b.2 hf hW_addr).2
  have haR_bl : ∀ f < 4, intBitLength (treeCellAddr L tid uR f) ≤ W :=
    fun f hf => (treeCellAddr_bitLength_le huR_b.2 hf hW_addr).2
  have hbase_bl : intBitLength (((tid * 2 ^ (L + 1) + uL) : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := (tid * 2 ^ (L + 1) + uL) * 4 + 0) (by omega)).trans (haL_bl 0 (by decide))
  have huL_z_bl : intBitLength (uL : ℤ) ≤ W := (nat_lt_pow2_bitLength_le huL_b.2).trans (by omega)
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd hc_ok hb_ok (dst := 10) (c := 2) (by decide) hl2_bl
  set rg1 := Function.update regs 10 2
  have hb1 : RegBounded W rg1 := hbnd.update (by decide) hl2_bl
  have s2 := RegExec.div (inp := inp) hfd_le hb1 hc_ok hb_ok (dst := 6) (a := 6) (b := 10) (by decide) (by decide) (by decide)
    (by simp [rg1, hr6]) (by simp [rg1])
  have hdiv6 : rg1 6 / rg1 10 = (uPar : ℤ) := by simp [rg1, hr6, huPar_eq]
  rw [hdiv6] at s2
  set rg2 := Function.update rg1 6 (uPar : ℤ)
  have hb2 : RegBounded W rg2 := hb1.update (by decide) ((nat_lt_pow2_bitLength_le huPar_b.2).trans (by omega))
  have hadd_uL : rg2 6 + rg2 6 = (uL : ℤ) := by
    simp only [rg2, Function.update_self]
    exact_mod_cast (by omega : uPar + uPar = uL)
  have s3 := RegExec.add (inp := inp) hfd_le hb2 hc_ok hb_ok (dst := 10) (a := 6) (b := 6) (by decide) (by decide) (by decide)
    (by rw [hadd_uL]; exact huL_z_bl)
  rw [hadd_uL] at s3
  set rg3 := Function.update rg2 10 (uL : ℤ)
  have hb3 : RegBounded W rg3 := hb2.update (by decide) huL_z_bl
  have hadd_base : rg3 7 + rg3 10 = ((tid * 2 ^ (L + 1) + uL : ℕ) : ℤ) := by
    simp [rg3, rg2, rg1, hr7]
  have s4 := RegExec.add (inp := inp) hfd_le hb3 hc_ok hb_ok (dst := 10) (a := 7) (b := 10) (by decide) (by decide) (by decide)
    (by rw [hadd_base]; exact hbase_bl)
  rw [hadd_base] at s4
  set rg4 := Function.update rg3 10 ((tid * 2 ^ (L + 1) + uL : ℕ) : ℤ)
  have hb4 : RegBounded W rg4 := hb3.update (by decide) hbase_bl
  have s5 := RegExec.lit (inp := inp) hfd_le hb4 hc_ok hb_ok (dst := 15) (c := 4) (by decide) hl4_bl
  set rg5 := Function.update rg4 15 4
  have hb5 : RegBounded W rg5 := hb4.update (by decide) hl4_bl
  have hmul_a0 : rg5 10 * rg5 15 = treeCellAddr L tid uL 0 := by
    simp [rg5, rg4, treeCellAddr]
  have s6 := RegExec.mul (inp := inp) hfd_le hb5 hc_ok hb_ok (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide)
    (by rw [hmul_a0]; exact haL_bl 0 (by decide))
  rw [hmul_a0] at s6
  set rg6 := Function.update rg5 10 (treeCellAddr L tid uL 0)
  have hb6 : RegBounded W rg6 := hb5.update (by decide) (haL_bl 0 (by decide))
  have hr_g6_10 : ws.read (.heap 2 (rg6 10)) = (vL.1 : ℤ) := by simpa [rg6] using rL0
  have s7 := RegExec.load (inp := inp) hfd_le hb6 hc_ok hb_ok (dst := 1) (table := 2) (addr := 10) (by decide) (by decide) hn2_bl
    (by rw [hr_g6_10]; exact cL_bl.trans (by omega))
  rw [hr_g6_10] at s7
  set rg7 := Function.update rg6 1 (vL.1 : ℤ)
  have hb7 : RegBounded W rg7 := hb6.update (by decide) (cL_bl.trans (by omega))
  have s8 := RegExec.lit (inp := inp) hfd_le hb7 hc_ok hb_ok (dst := 15) (c := 1) (by decide) hl1_bl
  set rg8 := Function.update rg7 15 1
  have hb8 : RegBounded W rg8 := hb7.update (by decide) hl1_bl
  have stepLoad : ∀ (rg : ℕ → ℤ) (aCur aNext : ℤ) (dst : ℕ) (val : ℤ),
      RegBounded W rg → dst < 16 → dst ≠ 10 → dst ≠ 15 →
      rg 10 = aCur → rg 15 = 1 → aCur + 1 = aNext →
      intBitLength aNext ≤ W → ws.read (.heap 2 aNext) = val → intBitLength val ≤ W →
      let rg' := Function.update (Function.update rg 10 aNext) dst val
      RegExec inp fd W C_cell C_bit (.seq (rAdd 10 10 15) (rLoad dst 2 10)) ws rg ws rg' 14 (12 * W + 56) ∧
      RegBounded W rg' ∧ rg' 10 = aNext ∧ rg' 15 = 1 := by
    intro rg aCur aNext dst val hbr hd hd10 hd15 h10 h15 hstep ha_bl hrd hv_bl
    have hadd_eq : rg 10 + rg 15 = aNext := by rw [h10, h15, hstep]
    have sa := RegExec.add (inp := inp) hfd_le hbr hc_ok hb_ok (dst := 10) (a := 10) (b := 15) (by decide) (by decide) (by decide)
      (by rw [hadd_eq]; exact ha_bl)
    rw [hadd_eq] at sa
    let rgM := Function.update rg 10 aNext
    have hbM : RegBounded W rgM := hbr.update (by decide) ha_bl
    have hm10 : rgM 10 = aNext := by simp [rgM]
    have sl := RegExec.load (inp := inp) hfd_le hbM hc_ok hb_ok (dst := dst) (table := 2) (addr := 10) hd (by decide) hn2_bl
      (by rw [hm10, hrd]; exact hv_bl)
    rw [hm10, hrd] at sl
    exact ⟨(sa.seq sl).weaken rfl rfl (by omega) (by omega), hbM.update hd hv_bl,
      by simp [rgM, Function.update_of_ne hd10.symm],
      by simp [rgM, Function.update_of_ne hd15.symm, h15]⟩
  have hstep01 : treeCellAddr L tid uL 0 + 1 = treeCellAddr L tid uL 1 := by unfold treeCellAddr; push_cast; ring
  have hstep12 : treeCellAddr L tid uL 1 + 1 = treeCellAddr L tid uL 2 := by unfold treeCellAddr; push_cast; ring
  have hstep23 : treeCellAddr L tid uL 2 + 1 = treeCellAddr L tid uL 3 := by unfold treeCellAddr; push_cast; ring
  have hstep34 : treeCellAddr L tid uL 3 + 1 = treeCellAddr L tid uR 0 := by
    unfold treeCellAddr; rw [← huR_eq]; push_cast; ring
  have hstep45 : treeCellAddr L tid uR 0 + 1 = treeCellAddr L tid uR 1 := by unfold treeCellAddr; push_cast; ring
  have hstep56 : treeCellAddr L tid uR 1 + 1 = treeCellAddr L tid uR 2 := by unfold treeCellAddr; push_cast; ring
  have hstep67 : treeCellAddr L tid uR 2 + 1 = treeCellAddr L tid uR 3 := by unfold treeCellAddr; push_cast; ring
  obtain ⟨p1, hbp1, hp1_10, hp1_15⟩ := stepLoad rg8 _ _ 2 (vL.2.1 : ℤ) hb8 (by decide) (by decide) (by decide)
    (by simp [rg8, rg7, rg6]) (by simp [rg8]) hstep01 (haL_bl 1 (by decide)) rL1 (hL_bl.trans (by omega))
  set rgp1 := Function.update (Function.update rg8 10 (treeCellAddr L tid uL 1)) 2 (vL.2.1 : ℤ)
  obtain ⟨p2, hbp2, hp2_10, hp2_15⟩ := stepLoad rgp1 _ _ 3 vL.2.2.1 hbp1 (by decide) (by decide) (by decide)
    hp1_10 hp1_15 hstep12 (haL_bl 2 (by decide)) rL2 (nL_bl.trans (by omega))
  set rgp2 := Function.update (Function.update rgp1 10 (treeCellAddr L tid uL 2)) 3 vL.2.2.1
  obtain ⟨p3, hbp3, hp3_10, hp3_15⟩ := stepLoad rgp2 _ _ 4 vL.2.2.2 hbp2 (by decide) (by decide) (by decide)
    hp2_10 hp2_15 hstep23 (haL_bl 3 (by decide)) rL3 (dL_bl.trans (by omega))
  set rgp3 := Function.update (Function.update rgp2 10 (treeCellAddr L tid uL 3)) 4 vL.2.2.2
  obtain ⟨p4, hbp4, hp4_10, hp4_15⟩ := stepLoad rgp3 _ _ 8 (vR.1 : ℤ) hbp3 (by decide) (by decide) (by decide)
    hp3_10 hp3_15 hstep34 (haR_bl 0 (by decide)) rR0 (cR_bl.trans (by omega))
  set rgp4 := Function.update (Function.update rgp3 10 (treeCellAddr L tid uR 0)) 8 (vR.1 : ℤ)
  obtain ⟨p5, hbp5, hp5_10, hp5_15⟩ := stepLoad rgp4 _ _ 11 (vR.2.1 : ℤ) hbp4 (by decide) (by decide) (by decide)
    hp4_10 hp4_15 hstep45 (haR_bl 1 (by decide)) rR1 (hR_bl.trans (by omega))
  set rgp5 := Function.update (Function.update rgp4 10 (treeCellAddr L tid uR 1)) 11 (vR.2.1 : ℤ)
  obtain ⟨p6, hbp6, hp6_10, hp6_15⟩ := stepLoad rgp5 _ _ 12 vR.2.2.1 hbp5 (by decide) (by decide) (by decide)
    hp5_10 hp5_15 hstep56 (haR_bl 2 (by decide)) rR2 (nR_bl.trans (by omega))
  set rgp6 := Function.update (Function.update rgp5 10 (treeCellAddr L tid uR 2)) 12 vR.2.2.1
  obtain ⟨p7, hbp7, _, _⟩ := stepLoad rgp6 _ _ 13 vR.2.2.2 hbp6 (by decide) (by decide) (by decide)
    hp6_10 hp6_15 hstep67 (haR_bl 3 (by decide)) rR3 (dR_bl.trans (by omega))
  set rgp7 := Function.update (Function.update rgp6 10 (treeCellAddr L tid uR 3)) 13 vR.2.2.2
  have sAll := s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq
    (p1.seq (p2.seq (p3.seq (p4.seq (p5.seq (p6.seq p7)))))))))))))
  have hbc_bound : 2 * W + 16 + (4 * W * W + (6 * W + 32 + (6 * W + 32 + (2 * W + 16 +
      (4 * W * W + (6 * W + 24 + (2 * W + 16 +
      (12 * W + 56 + (12 * W + 56 + (12 * W + 56 + (12 * W + 56 +
      (12 * W + 56 + (12 * W + 56 + (12 * W + 56)))))))))))))) ≤ 24 * W * W := by
    nlinarith only [hW8]
  refine ⟨rgp7, sAll.weaken rfl rfl (by omega) hbc_bound, hbp7, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simp [rgp7, rgp6, rgp5, rgp4, rgp3, rgp2, rgp1, rg8, rg7, rg6, rg5, rg4, rg3, rg2]
  · simp [rgp7, rgp6, rgp5, rgp4, rgp3, rgp2, rgp1, rg8, rg7, rg6, rg5, rg4, rg3, rg2, rg1, hr7]
  · simp [rgp7, rgp6, rgp5, rgp4, rgp3, rgp2, rgp1, rg8, rg7]
  · simp [rgp7, rgp6, rgp5, rgp4, rgp3, rgp2, rgp1]
  · simp [rgp7, rgp6, rgp5, rgp4, rgp3, rgp2]
  · simp [rgp7, rgp6, rgp5, rgp4, rgp3]
  · simp [rgp7, rgp6, rgp5, rgp4]
  · simp [rgp7, rgp6, rgp5]
  · simp [rgp7, rgp6]
  · simp [rgp7]

private theorem exec_mergeAndStoreParentStmt {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid i h₀ B_r : ℕ} (hi : i < L) (hh₀ : h₀ < 2 ^ L) (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 16 ≤ W)
    {S' : Finset ℕ} {rNum' rDen' : ℕ → ℤ}
    (hS' : ∀ h ∈ S', h < 2 ^ L ∧ intBitLength (rNum' h) ≤ B_r ∧ intBitLength (rDen' h) ≤ B_r)
    (hSubWrite : ∀ f < 4,
      (.heap 2 (treeCellAddr L tid (treeIdx L (i + 1) (h₀ / 2 ^ (i + 1))) f) : RAMCellLoc) ∈ S_write)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr6 : regs 6 = (treeIdx L (i + 1) (h₀ / 2 ^ (i + 1)) : ℤ))
    (hr7 : regs 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ))
    (hr1 : regs 1 = ((treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)))).1 : ℤ))
    (hr2 : regs 2 = ((treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)))).2.1 : ℤ))
    (hr3 : regs 3 = (treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)))).2.2.1)
    (hr4 : regs 4 = (treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)))).2.2.2)
    (hr8 : regs 8 = ((treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)) + 1)).1 : ℤ))
    (hr11 : regs 11 = ((treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)) + 1)).2.1 : ℤ))
    (hr12 : regs 12 = (treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)) + 1)).2.2.1)
    (hr13 : regs 13 = (treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)) + 1)).2.2.2) :
    let offPar := h₀ / 2 ^ (i + 1)
    let uPar := treeIdx L (i + 1) offPar
    let vPar := treeNodeVal S' rNum' rDen' (i + 1) offPar
    ∃ ws' regs',
      RegExec inp fd W C_cell C_bit mergeAndStoreParentStmt ws regs ws' regs' 188 (32 * W * W) ∧
      ModifiedOnBounded ws₀ S_write W ws' ∧
      RegBounded W regs' ∧
      NodeStoredAt L tid uPar vPar ws' ∧
      (∀ loc : RAMCellLoc, (∀ f < 4, loc ≠ .heap 2 (treeCellAddr L tid uPar f)) →
        (loc ∈ ws'.live ↔ loc ∈ ws.live) ∧ ws'.vals loc = ws.vals loc) ∧
      regs' 6 = (uPar : ℤ) ∧
      regs' 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) := by
  intro offPar uPar vPar
  change regs 6 = (uPar : ℤ) at hr6
  obtain ⟨hc_s, hb_s⟩ := hmod.space_le
  have hc_ok : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell := by linarith only [hc_s, hcCeil]
  have hb_ok : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit := by linarith only [hb_s, hbCeil]
  have hW8 : 18 ≤ W := by omega
  have hl0_bl : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl4_bl : intBitLength (4 : ℤ) ≤ W := by have : intBitLength (4 : ℤ) = 4 := (by decide); omega
  have hoff_lt : offPar < 2 ^ (L - (i + 1)) := by
    dsimp [offPar]
    rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add]
    have : L - (i + 1) + (i + 1) = L := by omega
    rw [this]; exact hh₀
  have huPar_b := treeIdx_bounds (by omega : i + 1 ≤ L) hoff_lt
  have hW_addr : natBitLength tid + L + 12 ≤ W := by omega
  obtain ⟨cL_le, _, _, _, nL_bl, dL_bl⟩ := treeNodeVal_bounds hBr1 hS' i (by omega) (2 * offPar)
  obtain ⟨cR_le, _, _, _, nR_bl, dR_bl⟩ := treeNodeVal_bounds hBr1 hS' i (by omega) (2 * offPar + 1)
  rcases eL : treeNodeVal S' rNum' rDen' i (2 * offPar) with ⟨cL, hL, nL, dL⟩
  rcases eR : treeNodeVal S' rNum' rDen' i (2 * offPar + 1) with ⟨cR, hR, nR, dR⟩
  rw [eL] at hr1 hr2 hr3 hr4 cL_le nL_bl dL_bl
  rw [eR] at hr8 hr11 hr12 hr13 cR_le nR_bl dR_bl
  dsimp only at hr1 hr2 hr3 hr4 hr8 hr11 hr12 hr13 cL_le nL_bl dL_bl cR_le nR_bl dR_bl
  have hvPar_eq : vPar =
      (if cL = 0 then (cR, hR, nR, dR)
       else if cR = 0 then (cL, hL, nL, dL)
       else if nR * dL ≤ nL * dR then (cL + cR, hL, nL, dL)
       else (cL + cR, hR, nR, dR)) := by
    dsimp [vPar]; simp only [treeNodeVal, eL, eR]
  -- 1. `rLit 15 0`
  have s0 := RegExec.lit (inp := inp) hfd_le hbnd hc_ok hb_ok (dst := 15) (c := 0) (by decide) hl0_bl
  set rg0 := Function.update regs 15 0
  have hb0 : RegBounded W rg0 := hbnd.update (by decide) hl0_bl
  -- 2. Merge `ite` tree producing `rgM` with `(rgM 1, rgM 2, rgM 3, rgM 4) = vPar` and `rgM 6, rgM 7` unchanged!
  have hMerge : ∃ rgM,
      RegExec inp fd W C_cell C_bit
        (.ite (.intEq (.readLocal 1 (.lit 0)) (.readLocal 15 (.lit 0)))
          (.seq (rCopy 1 8) (.seq (rCopy 2 11) (.seq (rCopy 3 12) (rCopy 4 13))))
          (.ite (.intEq (.readLocal 8 (.lit 0)) (.readLocal 15 (.lit 0)))
            .skip
            (.seq (rAdd 1 1 8)
            (.seq (rMul 14 12 4)
            (.seq (rMul 15 3 13)
            (.ite (.intLe (.readLocal 14 (.lit 0)) (.readLocal 15 (.lit 0)))
              .skip
              (.seq (rCopy 2 11) (.seq (rCopy 3 12) (rCopy 4 13)))))))))
        ws rg0 ws rgM 60 (12 * W * W) ∧
      RegBounded W rgM ∧
      rgM 1 = (vPar.1 : ℤ) ∧ rgM 2 = (vPar.2.1 : ℤ) ∧ rgM 3 = vPar.2.2.1 ∧ rgM 4 = vPar.2.2.2 ∧
      rgM 6 = (uPar : ℤ) ∧ rgM 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) := by
    by_cases hcL : cL = 0
    · have heq1 : rg0 1 = rg0 15 := by simp [rg0, hr1, hcL]
      have c1 := RegExec.copy (inp := inp) hfd_le hb0 hc_ok hb_ok (dst := 1) (src := 8) (by decide) (by decide)
      set g1 := Function.update rg0 1 (rg0 8)
      have bg1 : RegBounded W g1 := hb0.update (by decide) (hb0.2.1 8 (by decide))
      have c2 := RegExec.copy (inp := inp) hfd_le bg1 hc_ok hb_ok (dst := 2) (src := 11) (by decide) (by decide)
      set g2 := Function.update g1 2 (g1 11)
      have bg2 : RegBounded W g2 := bg1.update (by decide) (bg1.2.1 11 (by decide))
      have c3 := RegExec.copy (inp := inp) hfd_le bg2 hc_ok hb_ok (dst := 3) (src := 12) (by decide) (by decide)
      set g3 := Function.update g2 3 (g2 12)
      have bg3 : RegBounded W g3 := bg2.update (by decide) (bg2.2.1 12 (by decide))
      have c4 := RegExec.copy (inp := inp) hfd_le bg3 hc_ok hb_ok (dst := 4) (src := 13) (by decide) (by decide)
      set g4 := Function.update g3 4 (g3 13)
      have bg4 : RegBounded W g4 := bg3.update (by decide) (bg3.2.1 13 (by decide))
      have sBr := (c1.seq (c2.seq (c3.seq c4))).weaken rfl rfl (u₂ := 54) (b₂ := 11 * W * W) (by omega)
        (by nlinarith only [hW8] : 2 * W + 24 + (2 * W + 24 + (2 * W + 24 + (2 * W + 24))) ≤ 11 * W * W)
      have sIte := (RegExec.iteEq hb0 (a := 1) (b := 15) (by decide) (by decide)
        (fB := .ite (.intEq (.readLocal 8 (.lit 0)) (.readLocal 15 (.lit 0))) .skip
          (.seq (rAdd 1 1 8) (.seq (rMul 14 12 4) (.seq (rMul 15 3 13)
            (.ite (.intLe (.readLocal 14 (.lit 0)) (.readLocal 15 (.lit 0))) .skip
              (.seq (rCopy 2 11) (.seq (rCopy 3 12) (rCopy 4 13))))))))
        (by rw [if_pos heq1]; exact sBr)).weaken rfl rfl (u₂ := 60) (b₂ := 12 * W * W) (by omega) (by nlinarith only [hW8] : 11 * W * W + 4 * W + 16 ≤ 12 * W * W)
      rw [hvPar_eq, if_pos hcL]
      exact ⟨g4, sIte, bg4,
        by simp [g4, g3, g2, g1, rg0, hr8],
        by simp [g4, g3, g2, g1, rg0, hr11],
        by simp [g4, g3, g2, g1, rg0, hr12],
        by simp [g4, g3, g2, g1, rg0, hr13],
        by simp [g4, g3, g2, g1, rg0, hr6],
        by simp [g4, g3, g2, g1, rg0, hr7]⟩
    · have hne1 : rg0 1 ≠ rg0 15 := by simp [rg0, hr1, hcL]
      by_cases hcR : cR = 0
      · have heq8 : rg0 8 = rg0 15 := by simp [rg0, hr8, hcR]
        have sSkip := (RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) hb0).weaken
          rfl rfl (u₂ := 48) (b₂ := 10 * W * W) (by omega) (by nlinarith only [hW8] : 1 ≤ 10 * W * W)
        have sIn := (RegExec.iteEq hb0 (a := 8) (b := 15) (by decide) (by decide)
          (fB := .seq (rAdd 1 1 8) (.seq (rMul 14 12 4) (.seq (rMul 15 3 13)
            (.ite (.intLe (.readLocal 14 (.lit 0)) (.readLocal 15 (.lit 0))) .skip
              (.seq (rCopy 2 11) (.seq (rCopy 3 12) (rCopy 4 13)))))))
          (by rw [if_pos heq8]; exact sSkip)).weaken
          rfl rfl (u₂ := 54) (b₂ := 11 * W * W) (by omega) (by nlinarith only [hW8] : 10 * W * W + 4 * W + 16 ≤ 11 * W * W)
        have sOut := (RegExec.iteEq hb0 (a := 1) (b := 15) (by decide) (by decide)
          (tB := .seq (rCopy 1 8) (.seq (rCopy 2 11) (.seq (rCopy 3 12) (rCopy 4 13))))
          (by rw [if_neg hne1]; exact sIn)).weaken
          rfl rfl (u₂ := 60) (b₂ := 12 * W * W) (by omega) (by nlinarith only [hW8] : 11 * W * W + 4 * W + 16 ≤ 12 * W * W)
        rw [hvPar_eq, if_neg hcL, if_pos hcR]
        exact ⟨rg0, sOut, hb0,
          by simp [rg0, hr1], by simp [rg0, hr2], by simp [rg0, hr3], by simp [rg0, hr4],
          by simp [rg0, hr6], by simp [rg0, hr7]⟩
      · have hne8 : rg0 8 ≠ rg0 15 := by simp [rg0, hr8, hcR]
        have hc_sum_bl : intBitLength (rg0 1 + rg0 8) ≤ W := by
          have hsum_eq : rg0 1 + rg0 8 = ((cL + cR : ℕ) : ℤ) := by simp [rg0, hr1, hr8]
          rw [hsum_eq]
          have hle_L : cL + cR ≤ 2 ^ L := by
            have : cL + cR ≤ 2 ^ (i + 1) := by rw [pow_succ]; omega
            exact this.trans (Nat.pow_le_pow_right (by decide) (by omega))
          rcases lt_or_eq_of_le hle_L with hlt | heq
          · exact (nat_lt_pow2_bitLength_le hlt).trans (by omega)
          · rw [heq]; exact (nat_pow2_bitLength_le L).trans (by omega)
        have sAdd := RegExec.add (inp := inp) hfd_le hb0 hc_ok hb_ok (dst := 1) (a := 1) (b := 8)
          (by decide) (by decide) (by decide) hc_sum_bl
        set g1 := Function.update rg0 1 (rg0 1 + rg0 8)
        have bg1 : RegBounded W g1 := hb0.update (by decide) hc_sum_bl
        have hm14_eq : g1 12 * g1 4 = nR * dL := by simp [g1, rg0, hr12, hr4]
        have hm14_bl : intBitLength (g1 12 * g1 4) ≤ W := by
          rw [hm14_eq]; exact (intBitLength_mul_le nR dL).trans (by omega)
        have sMul1 := RegExec.mul (inp := inp) hfd_le bg1 hc_ok hb_ok (dst := 14) (a := 12) (b := 4)
          (by decide) (by decide) (by decide) hm14_bl
        rw [hm14_eq] at sMul1
        set g2 := Function.update g1 14 (nR * dL)
        have bg2 : RegBounded W g2 := bg1.update (by decide) (by rw [← hm14_eq]; exact hm14_bl)
        have hm15_eq : g2 3 * g2 13 = nL * dR := by simp [g2, g1, rg0, hr3, hr13]
        have hm15_bl : intBitLength (g2 3 * g2 13) ≤ W := by
          rw [hm15_eq]; exact (intBitLength_mul_le nL dR).trans (by omega)
        have sMul2 := RegExec.mul (inp := inp) hfd_le bg2 hc_ok hb_ok (dst := 15) (a := 3) (b := 13)
          (by decide) (by decide) (by decide) hm15_bl
        rw [hm15_eq] at sMul2
        set g3 := Function.update g2 15 (nL * dR)
        have bg3 : RegBounded W g3 := bg2.update (by decide) (by rw [← hm15_eq]; exact hm15_bl)
        have hg3_14 : g3 14 = nR * dL := by simp [g3, g2]
        have hg3_15 : g3 15 = nL * dR := by simp [g3]
        by_cases hle_cmp : nR * dL ≤ nL * dR
        · have sCmp := RegExec.iteLe bg3 (a := 14) (b := 15) (by decide) (by decide)
            (fB := .seq (rCopy 2 11) (.seq (rCopy 3 12) (rCopy 4 13)))
            (by rw [if_pos (by rw [hg3_14, hg3_15]; exact hle_cmp)]; exact RegExec.skip (inp := inp) (fd := fd) (C_cell := C_cell) (C_bit := C_bit) (wsHeap := ws) bg3)
          have sBody := (sAdd.seq (sMul1.seq (sMul2.seq sCmp))).weaken rfl rfl (u₂ := 48) (b₂ := 10 * W * W) (by omega)
            (by nlinarith only [hW8] : 6 * W + 32 + (4 * W * W + (4 * W * W + (1 + 4 * W + 16))) ≤ 10 * W * W)
          have sIn := (RegExec.iteEq hb0 (a := 8) (b := 15) (by decide) (by decide) (tB := .skip)
            (by rw [if_neg hne8]; exact sBody)).weaken rfl rfl (u₂ := 54) (b₂ := 11 * W * W) (by omega)
            (by nlinarith only [hW8] : 10 * W * W + 4 * W + 16 ≤ 11 * W * W)
          have sOut := (RegExec.iteEq hb0 (a := 1) (b := 15) (by decide) (by decide)
            (tB := .seq (rCopy 1 8) (.seq (rCopy 2 11) (.seq (rCopy 3 12) (rCopy 4 13))))
            (by rw [if_neg hne1]; exact sIn)).weaken rfl rfl (u₂ := 60) (b₂ := 12 * W * W) (by omega)
            (by nlinarith only [hW8] : 11 * W * W + 4 * W + 16 ≤ 12 * W * W)
          rw [hvPar_eq, if_neg hcL, if_neg hcR, if_pos hle_cmp]
          exact ⟨g3, sOut, bg3,
            by simp [g3, g2, g1, rg0, hr1, hr8],
            by simp [g3, g2, g1, rg0, hr2],
            by simp [g3, g2, g1, rg0, hr3],
            by simp [g3, g2, g1, rg0, hr4],
            by simp [g3, g2, g1, rg0, hr6],
            by simp [g3, g2, g1, rg0, hr7]⟩
        · have cp1 := RegExec.copy (inp := inp) hfd_le bg3 hc_ok hb_ok (dst := 2) (src := 11) (by decide) (by decide)
          set q1 := Function.update g3 2 (g3 11)
          have bq1 : RegBounded W q1 := bg3.update (by decide) (bg3.2.1 11 (by decide))
          have cp2 := RegExec.copy (inp := inp) hfd_le bq1 hc_ok hb_ok (dst := 3) (src := 12) (by decide) (by decide)
          set q2 := Function.update q1 3 (q1 12)
          have bq2 : RegBounded W q2 := bq1.update (by decide) (bq1.2.1 12 (by decide))
          have cp3 := RegExec.copy (inp := inp) hfd_le bq2 hc_ok hb_ok (dst := 4) (src := 13) (by decide) (by decide)
          set q3 := Function.update q2 4 (q2 13)
          have bq3 : RegBounded W q3 := bq2.update (by decide) (bq2.2.1 13 (by decide))
          have sCmp := RegExec.iteLe bg3 (a := 14) (b := 15) (by decide) (by decide) (tB := .skip)
            (by rw [if_neg (by rw [hg3_14, hg3_15]; exact hle_cmp)]; exact cp1.seq (cp2.seq cp3))
          have sBody := (sAdd.seq (sMul1.seq (sMul2.seq sCmp))).weaken rfl rfl (u₂ := 48) (b₂ := 10 * W * W) (by omega)
            (by nlinarith only [hW8] : 6 * W + 32 + (4 * W * W + (4 * W * W + ((2 * W + 24 + (2 * W + 24 + (2 * W + 24))) + 4 * W + 16))) ≤ 10 * W * W)
          have sIn := (RegExec.iteEq hb0 (a := 8) (b := 15) (by decide) (by decide) (tB := .skip)
            (by rw [if_neg hne8]; exact sBody)).weaken rfl rfl (u₂ := 54) (b₂ := 11 * W * W) (by omega)
            (by nlinarith only [hW8] : 10 * W * W + 4 * W + 16 ≤ 11 * W * W)
          have sOut := (RegExec.iteEq hb0 (a := 1) (b := 15) (by decide) (by decide)
            (tB := .seq (rCopy 1 8) (.seq (rCopy 2 11) (.seq (rCopy 3 12) (rCopy 4 13))))
            (by rw [if_neg hne1]; exact sIn)).weaken rfl rfl (u₂ := 60) (b₂ := 12 * W * W) (by omega)
            (by nlinarith only [hW8] : 11 * W * W + 4 * W + 16 ≤ 12 * W * W)
          rw [hvPar_eq, if_neg hcL, if_neg hcR, if_neg hle_cmp]
          exact ⟨q3, sOut, bq3,
            by simp [q3, q2, q1, g3, g2, g1, rg0, hr1, hr8],
            by simp [q3, q2, q1, g3, g2, g1, rg0, hr11],
            by simp [q3, q2, q1, g3, g2, g1, rg0, hr12],
            by simp [q3, q2, q1, g3, g2, g1, rg0, hr13],
            by simp [q3, q2, q1, g3, g2, g1, rg0, hr6],
            by simp [q3, q2, q1, g3, g2, g1, rg0, hr7]⟩
  obtain ⟨rgM, sMerge, hbM, hm1, hm2, hm3, hm4, hm6, hm7⟩ := hMerge
  -- 3. Compute `r9 := (r7 + r6) * 4` and call `writeOrFreeNode4Stmt`!
  have haPar0_bl := (treeCellAddr_bitLength_le huPar_b.2 (f := 0) (by decide) hW_addr).2
  have hbasePar_bl : intBitLength (((tid * 2 ^ (L + 1) + uPar) : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := (tid * 2 ^ (L + 1) + uPar) * 4 + 0) (by omega)).trans haPar0_bl
  have hadd9_eq : rgM 7 + rgM 6 = ((tid * 2 ^ (L + 1) + uPar : ℕ) : ℤ) := by
    rw [hm7, hm6]; push_cast; ring
  have t1 := RegExec.add (inp := inp) hfd_le hbM hc_ok hb_ok (dst := 9) (a := 7) (b := 6) (by decide) (by decide) (by decide)
    (by rw [hadd9_eq]; exact hbasePar_bl)
  rw [hadd9_eq] at t1
  set rgT1 := Function.update rgM 9 ((tid * 2 ^ (L + 1) + uPar : ℕ) : ℤ)
  have hbT1 : RegBounded W rgT1 := hbM.update (by decide) hbasePar_bl
  have t2 := RegExec.lit (inp := inp) hfd_le hbT1 hc_ok hb_ok (dst := 15) (c := 4) (by decide) hl4_bl
  set rgT2 := Function.update rgT1 15 4
  have hbT2 : RegBounded W rgT2 := hbT1.update (by decide) hl4_bl
  have hmul9_eq : rgT2 9 * rgT2 15 = treeCellAddr L tid uPar 0 := by
    simp [rgT2, rgT1, treeCellAddr]
  have t3 := RegExec.mul (inp := inp) hfd_le hbT2 hc_ok hb_ok (dst := 9) (a := 9) (b := 15) (by decide) (by decide) (by decide)
    (by rw [hmul9_eq]; exact haPar0_bl)
  rw [hmul9_eq] at t3
  set rgT3 := Function.update rgT2 9 (treeCellAddr L tid uPar 0)
  have hbT3 : RegBounded W rgT3 := hbT2.update (by decide) haPar0_bl
  obtain ⟨ws', regs', t4, hmod', hbOut, hnode', hunch', hregs'⟩ :=
    exec_writeOrFreeNode4Stmt (inp := inp) (fd := fd) hfd_le hmod hcCeil hbCeil huPar_b.2 hW_addr hSubWrite hbT3
      (v := vPar)
      (by simp [rgT3, rgT2, rgT1, hm1])
      (by simp [rgT3, rgT2, rgT1, hm2])
      (by simp [rgT3, rgT2, rgT1, hm3])
      (by simp [rgT3, rgT2, rgT1, hm4])
      (by dsimp only [rgT3]; exact Function.update_self _ _ _)
  have sTot := (s0.seq (sMerge.seq (t1.seq (t2.seq (t3.seq t4))))).weaken rfl rfl (u₂ := 188) (b₂ := 32 * W * W) (by omega)
    (by nlinarith only [hW8] : 2 * W + 16 + (12 * W * W + (6 * W + 32 + (2 * W + 16 + (4 * W * W + (80 * W + 400))))) ≤ 32 * W * W)
  exact ⟨ws', regs', sTot, hmod', hbOut, hnode', hunch',
    by rw [hregs' 6 (by decide) (by decide) (by decide)]; simp [rgT3, rgT2, rgT1, hm6],
    by rw [hregs' 7 (by decide) (by decide) (by decide)]; simp [rgT3, rgT2, rgT1, hm7]⟩

theorem exec_parentStepStmt {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid i h₀ B_r : ℕ} (hi : i < L) (hh₀ : h₀ < 2 ^ L) (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 16 ≤ W)
    {S' : Finset ℕ} {rNum' rDen' : ℕ → ℤ}
    (hS' : ∀ h ∈ S', h < 2 ^ L ∧ intBitLength (rNum' h) ≤ B_r ∧ intBitLength (rDen' h) ≤ B_r)
    (hSubWrite : ∀ f < 4,
      (.heap 2 (treeCellAddr L tid (treeIdx L (i + 1) (h₀ / 2 ^ (i + 1))) f) : RAMCellLoc) ∈ S_write)
    (hnL : NodeStoredAt L tid (treeIdx L i (2 * (h₀ / 2 ^ (i + 1))))
      (treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)))) ws)
    (hnR : NodeStoredAt L tid (treeIdx L i (2 * (h₀ / 2 ^ (i + 1)) + 1))
      (treeNodeVal S' rNum' rDen' i (2 * (h₀ / 2 ^ (i + 1)) + 1)) ws)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr6 : regs 6 = (treeIdx L i (h₀ / 2 ^ i) : ℤ))
    (hr7 : regs 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ)) :
    let offPar := h₀ / 2 ^ (i + 1)
    let uPar := treeIdx L (i + 1) offPar
    let vPar := treeNodeVal S' rNum' rDen' (i + 1) offPar
    ∃ ws' regs',
      RegExec inp fd W C_cell C_bit parentStepStmt ws regs ws' regs' 350 (56 * W * W) ∧
      ModifiedOnBounded ws₀ S_write W ws' ∧
      RegBounded W regs' ∧
      NodeStoredAt L tid uPar vPar ws' ∧
      (∀ loc : RAMCellLoc, (∀ f < 4, loc ≠ .heap 2 (treeCellAddr L tid uPar f)) →
        (loc ∈ ws'.live ↔ loc ∈ ws.live) ∧ ws'.vals loc = ws.vals loc) ∧
      regs' 6 = (uPar : ℤ) ∧
      regs' 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) := by
  intro offPar uPar vPar
  obtain ⟨rg1, sL, hb1, g6, g7, g1, g2, g3, g4, g8, g11, g12, g13⟩ :=
    exec_loadTwoChildrenStmt (inp := inp) (fd := fd) hfd_le hmod hcCeil hbCeil hi hh₀ hBr1 hW hS' hnL hnR hbnd hr6 hr7
  obtain ⟨ws', regs', sM, hmod', hb2, hnode', hunch', o6, o7⟩ :=
    exec_mergeAndStoreParentStmt (inp := inp) (fd := fd) hfd_le hmod hcCeil hbCeil hi hh₀ hBr1 hW hS' hSubWrite hb1
      g6 g7 g1 g2 g3 g4 g8 g11 g12 g13
  exact ⟨ws', regs', (sL.seq sM).weaken rfl rfl (u₂ := 350) (b₂ := 56 * W * W) (by omega) (le_of_eq (by ring)), hmod', hb2, hnode', hunch', o6, o7⟩

/-- Update leaf `h₀` in tree `tid` of depth `L` (`r0 = tid`, `r1 = h₀`, `r2 = isPresent (1/0)`, `r3 = rNum₀`, `r4 = rDen₀`),
recomputing all `L` ancestors up to the root (`u = 1`) and reclaiming any node whose subtree count reaches `0`. -/
def treeSetLeafRegs (L : ℕ) : BitRAMStmt :=
  .seq (rLit 8 ((2 ^ (L + 1) : ℕ) : ℤ))
  (.seq (rMul 7 0 8)
  (.seq (rLit 5 ((2 ^ L : ℕ) : ℤ))
  (.seq (rAdd 6 5 1)
  (.seq (rAdd 9 7 6)
  (.seq (rLit 15 4)
  (.seq (rMul 9 9 15)
  (.seq (rLit 15 0)
  (.seq (.ite (.intEq (.readLocal 2 (.lit 0)) (.readLocal 15 (.lit 0)))
          (.seq (rLit 1 0) (.seq (rLit 2 0) (.seq (rLit 3 0) (rLit 4 0))))
          (.seq (rCopy 2 1) (rLit 1 1)))
  (.seq writeOrFreeNode4Stmt
        (.repeatN (.lit (L : ℤ)) parentStepStmt))))))))))

theorem mem_treePathLocs (L tid h₀ k f : ℕ) (hk : k ≤ L) (hf : f < 4) :
    (.heap 2 (treeCellAddr L tid (treeIdx L k (h₀ / 2 ^ k)) f) : RAMCellLoc) ∈ treePathLocs L tid h₀ := by
  unfold treePathLocs
  refine Finset.mem_image.mpr ⟨(k, f), ?_, rfl⟩
  exact Finset.mem_product.mpr ⟨Finset.mem_range.mpr (by omega), Finset.mem_range.mpr hf⟩

theorem exec_treeSetLeafRegs {d : ℕ} {inp : BitRAMInput d} {fd W C_cell C_bit : ℕ}
    (hfd_le : fd ≤ 4) {ws₀ ws : WordStore} {S_write : Finset RAMCellLoc}
    (hmod : ModifiedOnBounded ws₀ S_write W ws)
    (hcCeil : inp.inputCellSpace + ws₀.cellCount + S_write.card + 16 ≤ C_cell)
    (hbCeil : inp.inputBitSpace + ws₀.bitSize + 2 * W * S_write.card + 16 * (W + 12) ≤ C_bit)
    {L tid h₀ B_r : ℕ} (hL1 : 1 ≤ L) (hh₀ : h₀ < 2 ^ L) (hBr1 : 1 ≤ B_r)
    (hW : 2 * B_r + natBitLength tid + L + 16 ≤ W)
    (hPathSub : treePathLocs L tid h₀ ⊆ S_write)
    {S S' : Finset ℕ} {rNum rDen rNum' rDen' : ℕ → ℤ}
    (htree : TreeStoredAt L tid S rNum rDen ws)
    (hS'_bnds : ∀ h ∈ S', h < 2 ^ L ∧ intBitLength (rNum' h) ≤ B_r ∧ intBitLength (rDen' h) ≤ B_r)
    (hS_off : ∀ h ≠ h₀, (h ∈ S ↔ h ∈ S'))
    (hNum_off : ∀ h ≠ h₀, rNum h = rNum' h)
    (hDen_off : ∀ h ≠ h₀, rDen h = rDen' h)
    (isPresent : Bool)
    (hPres : h₀ ∈ S' ↔ isPresent = true)
    {regs : ℕ → ℤ} (hbnd : RegBounded W regs)
    (hr0 : regs 0 = (tid : ℤ))
    (hr1 : regs 1 = (h₀ : ℤ))
    (hr2 : regs 2 = if isPresent then 1 else 0)
    (hr3 : isPresent = true → regs 3 = rNum' h₀)
    (hr4 : isPresent = true → regs 4 = rDen' h₀) :
    ∃ wsEnd regsEnd,
      RegExec inp fd W C_cell C_bit (treeSetLeafRegs L) ws regs wsEnd regsEnd
        (350 * L + 180) ((56 * L + 32) * W * W) ∧
      ModifiedOnBounded ws₀ S_write W wsEnd ∧
      RegBounded W regsEnd ∧
      TreeStoredAt L tid S' rNum' rDen' wsEnd ∧
      (∀ loc : RAMCellLoc, loc ∉ treePathLocs L tid h₀ →
        (loc ∈ wsEnd.live ↔ loc ∈ ws.live) ∧ wsEnd.vals loc = ws.vals loc) := by
  obtain ⟨hc_s, hb_s⟩ := hmod.space_le
  have hc_ok : inp.inputCellSpace + ws.cellCount + 16 ≤ C_cell := by linarith only [hc_s, hcCeil]
  have hb_ok : inp.inputBitSpace + ws.bitSize + 16 * (W + 12) ≤ C_bit := by linarith only [hb_s, hbCeil]
  have hW8 : 18 ≤ W := by omega
  have hW_addr : natBitLength tid + L + 12 ≤ W := by omega
  have hpL1_bl : intBitLength ((2 ^ (L + 1) : ℕ) : ℤ) ≤ W := (nat_pow2_bitLength_le (L + 1)).trans (by omega)
  have hpL_bl : intBitLength ((2 ^ L : ℕ) : ℤ) ≤ W := (nat_pow2_bitLength_le L).trans (by omega)
  have hl0_bl : intBitLength (0 : ℤ) ≤ W := by have : intBitLength (0 : ℤ) = 1 := (by decide); omega
  have hl1_bl : intBitLength (1 : ℤ) ≤ W := by have : intBitLength (1 : ℤ) = 2 := (by decide); omega
  have hl4_bl : intBitLength (4 : ℤ) ≤ W := by have : intBitLength (4 : ℤ) = 4 := (by decide); omega
  set u0 := treeIdx L 0 h₀
  have hu0_eq : (2 ^ L : ℕ) + h₀ = u0 := by unfold u0 treeIdx; simp
  have hu0_b := treeIdx_bounds (Nat.zero_le L) (by simpa using hh₀)
  have ha0_bl := (treeCellAddr_bitLength_le hu0_b.2 (f := 0) (by decide) hW_addr).2
  have htid_pow_bl : intBitLength ((tid * 2 ^ (L + 1) : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := (tid * 2 ^ (L + 1) + u0) * 4 + 0) (by omega)).trans ha0_bl
  have hbase0_bl : intBitLength (((tid * 2 ^ (L + 1) + u0) : ℕ) : ℤ) ≤ W :=
    (intBitLength_natCast_mono (b := (tid * 2 ^ (L + 1) + u0) * 4 + 0) (by omega)).trans ha0_bl
  -- Prologue steps before leaf write
  have s1 := RegExec.lit (inp := inp) hfd_le hbnd hc_ok hb_ok (dst := 8) (c := ((2 ^ (L + 1) : ℕ) : ℤ)) (by decide) hpL1_bl
  set g1 := Function.update regs 8 ((2 ^ (L + 1) : ℕ) : ℤ)
  have bg1 : RegBounded W g1 := hbnd.update (by decide) hpL1_bl
  have hm7 : g1 0 * g1 8 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) := by simp [g1, hr0]
  have s2 := RegExec.mul (inp := inp) hfd_le bg1 hc_ok hb_ok (dst := 7) (a := 0) (b := 8) (by decide) (by decide) (by decide)
    (by rw [hm7]; exact htid_pow_bl)
  rw [hm7] at s2
  set g2 := Function.update g1 7 ((tid * 2 ^ (L + 1) : ℕ) : ℤ)
  have bg2 : RegBounded W g2 := bg1.update (by decide) htid_pow_bl
  have s3 := RegExec.lit (inp := inp) hfd_le bg2 hc_ok hb_ok (dst := 5) (c := ((2 ^ L : ℕ) : ℤ)) (by decide) hpL_bl
  set g3 := Function.update g2 5 ((2 ^ L : ℕ) : ℤ)
  have bg3 : RegBounded W g3 := bg2.update (by decide) hpL_bl
  have ha6 : g3 5 + g3 1 = (u0 : ℤ) := by
    simp only [g3, g2, g1, Function.update_self, Function.update_of_ne (by decide : (1 : ℕ) ≠ 5),
      Function.update_of_ne (by decide : (1 : ℕ) ≠ 7), Function.update_of_ne (by decide : (1 : ℕ) ≠ 8), hr1]
    exact_mod_cast hu0_eq
  have hu0_bl : intBitLength (u0 : ℤ) ≤ W := (nat_lt_pow2_bitLength_le hu0_b.2).trans (by omega)
  have s4 := RegExec.add (inp := inp) hfd_le bg3 hc_ok hb_ok (dst := 6) (a := 5) (b := 1) (by decide) (by decide) (by decide)
    (by rw [ha6]; exact hu0_bl)
  rw [ha6] at s4
  set g4 := Function.update g3 6 (u0 : ℤ)
  have bg4 : RegBounded W g4 := bg3.update (by decide) hu0_bl
  have ha9 : g4 7 + g4 6 = ((tid * 2 ^ (L + 1) + u0 : ℕ) : ℤ) := by simp [g4, g3, g2]
  have s5 := RegExec.add (inp := inp) hfd_le bg4 hc_ok hb_ok (dst := 9) (a := 7) (b := 6) (by decide) (by decide) (by decide)
    (by rw [ha9]; exact hbase0_bl)
  rw [ha9] at s5
  set g5 := Function.update g4 9 ((tid * 2 ^ (L + 1) + u0 : ℕ) : ℤ)
  have bg5 : RegBounded W g5 := bg4.update (by decide) hbase0_bl
  have s6 := RegExec.lit (inp := inp) hfd_le bg5 hc_ok hb_ok (dst := 15) (c := 4) (by decide) hl4_bl
  set g6 := Function.update g5 15 4
  have bg6 : RegBounded W g6 := bg5.update (by decide) hl4_bl
  have hm9 : g6 9 * g6 15 = treeCellAddr L tid u0 0 := by simp [g6, g5, treeCellAddr]
  have s7 := RegExec.mul (inp := inp) hfd_le bg6 hc_ok hb_ok (dst := 9) (a := 9) (b := 15) (by decide) (by decide) (by decide)
    (by rw [hm9]; exact ha0_bl)
  rw [hm9] at s7
  set g7 := Function.update g6 9 (treeCellAddr L tid u0 0)
  have bg7 : RegBounded W g7 := bg6.update (by decide) ha0_bl
  have s8 := RegExec.lit (inp := inp) hfd_le bg7 hc_ok hb_ok (dst := 15) (c := 0) (by decide) hl0_bl
  set g8 := Function.update g7 15 0
  have bg8 : RegBounded W g8 := bg7.update (by decide) hl0_bl
  -- Prepare leaf registers `(r1, r2, r3, r4) = treeNodeVal S' rNum' rDen' 0 h₀`
  set vLeaf := treeNodeVal S' rNum' rDen' 0 h₀
  have hPrepLeaf : ∃ g9,
      RegExec inp fd W C_cell C_bit
        (.ite (.intEq (.readLocal 2 (.lit 0)) (.readLocal 15 (.lit 0)))
          (.seq (rLit 1 0) (.seq (rLit 2 0) (.seq (rLit 3 0) (rLit 4 0))))
          (.seq (rCopy 2 1) (rLit 1 1)))
        ws g8 ws g9 24 (16 * W + 96) ∧
      RegBounded W g9 ∧
      g9 1 = (vLeaf.1 : ℤ) ∧ g9 2 = (vLeaf.2.1 : ℤ) ∧ g9 3 = vLeaf.2.2.1 ∧ g9 4 = vLeaf.2.2.2 ∧
      g9 6 = (u0 : ℤ) ∧ g9 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) ∧ g9 9 = treeCellAddr L tid u0 0 := by
    cases isPresent
    · have hnotS' : h₀ ∉ S' := fun hm => Bool.noConfusion (hPres.mp hm)
      have hv0_eq : vLeaf = (0, 0, 0, 0) := by simp [vLeaf, treeNodeVal, hnotS']
      have heq2 : g8 2 = g8 15 := by simp [g8, g7, g6, g5, g4, g3, g2, g1, hr2]
      have z1 := RegExec.lit (inp := inp) hfd_le bg8 hc_ok hb_ok (dst := 1) (c := 0) (by decide) hl0_bl
      set q1 := Function.update g8 1 (0 : ℤ); have bq1 : RegBounded W q1 := bg8.update (by decide) hl0_bl
      have z2 := RegExec.lit (inp := inp) hfd_le bq1 hc_ok hb_ok (dst := 2) (c := 0) (by decide) hl0_bl
      set q2 := Function.update q1 2 (0 : ℤ); have bq2 : RegBounded W q2 := bq1.update (by decide) hl0_bl
      have z3 := RegExec.lit (inp := inp) hfd_le bq2 hc_ok hb_ok (dst := 3) (c := 0) (by decide) hl0_bl
      set q3 := Function.update q2 3 (0 : ℤ); have bq3 : RegBounded W q3 := bq2.update (by decide) hl0_bl
      have z4 := RegExec.lit (inp := inp) hfd_le bq3 hc_ok hb_ok (dst := 4) (c := 0) (by decide) hl0_bl
      set q4 := Function.update q3 4 (0 : ℤ); have bq4 : RegBounded W q4 := bq3.update (by decide) hl0_bl
      have sBr := (z1.seq (z2.seq (z3.seq z4))).weaken rfl rfl (u₂ := 18) (b₂ := 12 * W + 80) (by omega) (by omega)
      have sIte := (RegExec.iteEq bg8 (a := 2) (b := 15) (by decide) (by decide)
        (fB := .seq (rCopy 2 1) (rLit 1 1))
        (by rw [if_pos heq2]; exact sBr)).weaken rfl rfl (u₂ := 24) (b₂ := 16 * W + 96) (by omega) (by omega)
      rw [hv0_eq]
      exact ⟨q4, sIte, bq4, by simp [q4, q3, q2, q1], by simp [q4, q3, q2], by simp [q4, q3], by simp [q4],
        by simp [q4, q3, q2, q1, g8, g7, g6, g5, g4],
        by simp [q4, q3, q2, q1, g8, g7, g6, g5, g4, g3, g2],
        by simp [q4, q3, q2, q1, g8, g7]⟩
    · have hmemS' : h₀ ∈ S' := hPres.mpr rfl
      have hv1_eq : vLeaf = (1, h₀, rNum' h₀, rDen' h₀) := by simp [vLeaf, treeNodeVal, hmemS']
      have hne2 : g8 2 ≠ g8 15 := by simp [g8, g7, g6, g5, g4, g3, g2, g1, hr2]
      have w1 := RegExec.copy (inp := inp) hfd_le bg8 hc_ok hb_ok (dst := 2) (src := 1) (by decide) (by decide)
      set q1 := Function.update g8 2 (g8 1); have bq1 : RegBounded W q1 := bg8.update (by decide) (bg8.2.1 1 (by decide))
      have w2 := RegExec.lit (inp := inp) hfd_le bq1 hc_ok hb_ok (dst := 1) (c := 1) (by decide) hl1_bl
      set q2 := Function.update q1 1 (1 : ℤ); have bq2 : RegBounded W q2 := bq1.update (by decide) hl1_bl
      have sBr := (w1.seq w2).weaken rfl rfl (u₂ := 18) (b₂ := 12 * W + 80) (by omega) (by omega)
      have sIte := (RegExec.iteEq bg8 (a := 2) (b := 15) (by decide) (by decide)
        (tB := .seq (rLit 1 0) (.seq (rLit 2 0) (.seq (rLit 3 0) (rLit 4 0))))
        (by rw [if_neg hne2]; exact sBr)).weaken rfl rfl (u₂ := 24) (b₂ := 16 * W + 96) (by omega) (by omega)
      rw [hv1_eq]
      exact ⟨q2, sIte, bq2,
        by simp [q2],
        by simp [q2, q1, g8, g7, g6, g5, g4, g3, g2, g1, hr1],
        by simp [q2, q1, g8, g7, g6, g5, g4, g3, g2, g1, hr3 rfl],
        by simp [q2, q1, g8, g7, g6, g5, g4, g3, g2, g1, hr4 rfl],
        by simp [q2, q1, g8, g7, g6, g5, g4],
        by simp [q2, q1, g8, g7, g6, g5, g4, g3, g2],
        by simp [q2, q1, g8, g7]⟩
  obtain ⟨g9, s9, bg9, l1, l2, l3, l4, l6, l7, l9⟩ := hPrepLeaf
  have hLeafSubWrite : ∀ f < 4, (.heap 2 (treeCellAddr L tid u0 f) : RAMCellLoc) ∈ S_write := by
    intro f hf
    exact hPathSub (by simpa [u0] using mem_treePathLocs L tid h₀ 0 f (Nat.zero_le L) hf)
  obtain ⟨wsLeaf, rgLeaf, s10, hmodLeaf, hbLeaf, hnodeLeaf, hunchLeaf, hregsLeaf⟩ :=
    exec_writeOrFreeNode4Stmt (inp := inp) (fd := fd) hfd_le hmod hcCeil hbCeil hu0_b.2 hW_addr hLeafSubWrite bg9
      (v := vLeaf) l1 l2 l3 l4 l9
  -- Off-path equality helper
  have hoff_unchanged : ∀ k ≤ L, ∀ off < 2 ^ (L - k), off ≠ h₀ / 2 ^ k →
      treeNodeVal S rNum rDen k off = treeNodeVal S' rNum' rDen' k off := by
    intro k _ off _ hne
    apply treeNodeVal_unchanged_off_path hS_off hNum_off hDen_off
    rintro ⟨hle1, hlt2⟩
    apply hne
    have hq1 : off ≤ h₀ / 2 ^ k := (Nat.le_div_iff_mul_le (by positivity)).mpr hle1
    have hq2 : h₀ / 2 ^ k < off + 1 := (Nat.div_lt_iff_lt_mul (by positivity)).mpr hlt2
    omega
  -- Construct the `L`-step loop trajectory by induction on `i : ℕ` using `Classical`!
  let LoopInv (i : ℕ) (w : WordStore) (g : ℕ → ℤ) : Prop :=
    ModifiedOnBounded ws₀ S_write W w ∧
    RegBounded W g ∧
    (∀ loc : RAMCellLoc, loc ∉ treePathLocs L tid h₀ → (loc ∈ w.live ↔ loc ∈ ws.live) ∧ w.vals loc = ws.vals loc) ∧
    (∀ f < 4, (.heap 2 (treeCellAddr L tid 0 f) : RAMCellLoc) ∉ w.live) ∧
    (i ≤ L →
      g 6 = (treeIdx L i (h₀ / 2 ^ i) : ℤ) ∧
      g 7 = ((tid * 2 ^ (L + 1) : ℕ) : ℤ) ∧
      ∀ k ≤ L, ∀ off < 2 ^ (L - k),
        (k ≤ i → NodeStoredAt L tid (treeIdx L k off) (treeNodeVal S' rNum' rDen' k off) w) ∧
        (i < k → NodeStoredAt L tid (treeIdx L k off) (treeNodeVal S rNum rDen k off) w))
  have hInv0 : LoopInv 0 wsLeaf rgLeaf := by
    refine ⟨hmodLeaf, hbLeaf, ?_, ?_, fun _ => ⟨?_, ?_, ?_⟩⟩
    · intro loc hnot
      refine hunchLeaf loc (fun f hf heq => hnot ?_)
      rw [heq]; simpa [u0] using mem_treePathLocs L tid h₀ 0 f (Nat.zero_le L) hf
    · intro f hf
      have hne : ∀ f' < 4, (.heap 2 (treeCellAddr L tid 0 f) : RAMCellLoc) ≠ .heap 2 (treeCellAddr L tid u0 f') := by
        intro f' hf' hh
        have hinj := treeCellAddr_inj (by positivity) hf hu0_b.2 hf' (RAMCellLoc.heap.inj hh).2
        have := hu0_b.1; omega
      rw [(hunchLeaf _ hne).1]; exact htree.u0_empty f hf
    · rw [hregsLeaf 6 (by decide) (by decide) (by decide), l6]; simp [u0]
    · rw [hregsLeaf 7 (by decide) (by decide) (by decide), l7]
    · intro k hk off hoff
      have hne_node : (k = 0 ∧ off = h₀) ∨ treeIdx L k off ≠ u0 := by
        by_cases heq : treeIdx L k off = u0
        · have hinj := treeIdx_inj hk hoff (Nat.zero_le L) (by simpa using hh₀) heq
          exact Or.inl hinj
        · exact Or.inr heq
      constructor
      · intro hk0
        have hk_z : k = 0 := by omega
        subst hk_z
        by_cases hoff_eq : off = h₀
        · subst hoff_eq; exact hnodeLeaf
        · rcases hne_node with ⟨_, rfl⟩ | hne_u
          · exact False.elim (hoff_eq rfl)
          · have hcell_ne : ∀ f < 4, ∀ f' < 4,
                (.heap 2 (treeCellAddr L tid (treeIdx L 0 off) f) : RAMCellLoc) ≠ .heap 2 (treeCellAddr L tid u0 f') := by
              intro f hf f' hf' hh
              have hinj := treeCellAddr_inj (treeIdx_bounds (Nat.zero_le L) hoff).2 hf hu0_b.2 hf' (RAMCellLoc.heap.inj hh).2
              exact hne_u hinj.2.1
            have hn_old := (htree.nodes 0 (Nat.zero_le L) off hoff).unchanged (fun f hf => hunchLeaf _ (hcell_ne f hf))
            rwa [hoff_unchanged 0 (Nat.zero_le L) off hoff (by simpa using hoff_eq)] at hn_old
      · intro hk_pos
        rcases hne_node with ⟨rfl, _⟩ | hne_u
        · omega
        · have hcell_ne : ∀ f < 4, ∀ f' < 4,
              (.heap 2 (treeCellAddr L tid (treeIdx L k off) f) : RAMCellLoc) ≠ .heap 2 (treeCellAddr L tid u0 f') := by
            intro f hf f' hf' hh
            have hinj := treeCellAddr_inj (treeIdx_bounds hk hoff).2 hf hu0_b.2 hf' (RAMCellLoc.heap.inj hh).2
            exact hne_u hinj.2.1
          exact (htree.nodes k hk off hoff).unchanged (fun f hf => hunchLeaf _ (hcell_ne f hf))
  -- Step lemma advancing `LoopInv i` to `LoopInv (i + 1)` when `i < L`!
  have hStepInv : ∀ i < L, ∀ w g, LoopInv i w g →
      ∃ w' g',
        RegExec inp fd W C_cell C_bit parentStepStmt w g w' g' 350 (56 * W * W) ∧
        LoopInv (i + 1) w' g' := by
    intro i hi w g ⟨hmod_i, hb_i, hunch_i, hu0_i, hrest_i⟩
    obtain ⟨g6_i, g7_i, hnodes_i⟩ := hrest_i (by omega)
    set offPar := h₀ / 2 ^ (i + 1)
    have hoffPar_lt : offPar < 2 ^ (L - (i + 1)) := by
      dsimp [offPar]; rw [Nat.div_lt_iff_lt_mul (by positivity), ← pow_add]
      have : L - (i + 1) + (i + 1) = L := by omega
      rw [this]; exact hh₀
    have hoffL_lt : 2 * offPar < 2 ^ (L - i) := by
      have : L - i = (L - (i + 1)) + 1 := by omega
      rw [this, pow_succ]; omega
    have hoffR_lt : 2 * offPar + 1 < 2 ^ (L - i) := by
      have : L - i = (L - (i + 1)) + 1 := by omega
      rw [this, pow_succ]; omega
    have hnL := (hnodes_i i (by omega) (2 * offPar) hoffL_lt).1 le_rfl
    have hnR := (hnodes_i i (by omega) (2 * offPar + 1) hoffR_lt).1 le_rfl
    have hSubPar : ∀ f < 4,
        (.heap 2 (treeCellAddr L tid (treeIdx L (i + 1) offPar) f) : RAMCellLoc) ∈ S_write :=
      fun f hf => hPathSub (mem_treePathLocs L tid h₀ (i + 1) f (by omega) hf)
    obtain ⟨w', g', sStep, hmod', hb', hnodePar, hunchPar, g6', g7'⟩ :=
      exec_parentStepStmt (inp := inp) (fd := fd) hfd_le hmod_i hcCeil hbCeil hi hh₀ hBr1 hW hS'_bnds hSubPar
        hnL hnR hb_i g6_i g7_i
    have huPar_b := treeIdx_bounds (by omega : i + 1 ≤ L) hoffPar_lt
    refine ⟨w', g', sStep, hmod', hb', ?_, ?_, fun _ => ⟨g6', g7', ?_⟩⟩
    · intro loc hnot
      have h1 := hunchPar loc (fun f hf heq => hnot (by rw [heq]; exact mem_treePathLocs L tid h₀ (i + 1) f (by omega) hf))
      have h2 := hunch_i loc hnot
      exact ⟨h1.1.trans h2.1, h1.2.trans h2.2⟩
    · intro f hf
      have hne : ∀ f' < 4,
          (.heap 2 (treeCellAddr L tid 0 f) : RAMCellLoc) ≠ .heap 2 (treeCellAddr L tid (treeIdx L (i + 1) offPar) f') := by
        intro f' hf' hh
        have hinj := treeCellAddr_inj (by positivity) hf huPar_b.2 hf' (RAMCellLoc.heap.inj hh).2
        have := huPar_b.1; omega
      rw [(hunchPar _ hne).1]; exact hu0_i f hf
    · intro k hk off hoff
      by_cases hpar : k = i + 1 ∧ off = offPar
      · rcases hpar with ⟨rfl, rfl⟩
        exact ⟨fun _ => hnodePar, fun hlt => by omega⟩
      · have hne_u : treeIdx L k off ≠ treeIdx L (i + 1) offPar := fun heq =>
          hpar (treeIdx_inj hk hoff (by omega) hoffPar_lt heq)
        have hcell_ne : ∀ f < 4, ∀ f' < 4,
            (.heap 2 (treeCellAddr L tid (treeIdx L k off) f) : RAMCellLoc) ≠
              .heap 2 (treeCellAddr L tid (treeIdx L (i + 1) offPar) f') := by
          intro f hf f' hf' hh
          have hinj := treeCellAddr_inj (treeIdx_bounds hk hoff).2 hf huPar_b.2 hf' (RAMCellLoc.heap.inj hh).2
          exact hne_u hinj.2.1
        constructor
        · intro hk_le
          rcases lt_or_eq_of_le hk_le with hk_lt | rfl
          · exact ((hnodes_i k hk off hoff).1 (by omega)).unchanged (fun f hf => hunchPar _ (hcell_ne f hf))
          · have hoff_ne : off ≠ offPar := fun h => hpar ⟨rfl, h⟩
            have hn_old := ((hnodes_i (i + 1) hk off hoff).2 (by omega)).unchanged (fun f hf => hunchPar _ (hcell_ne f hf))
            rwa [hoff_unchanged (i + 1) hk off hoff hoff_ne] at hn_old
        · intro hk_gt
          exact ((hnodes_i k hk off hoff).2 (by omega)).unchanged (fun f hf => hunchPar _ (hcell_ne f hf))
  -- Build the sequence `seqPair : (n : ℕ) → { p : WordStore × (ℕ → ℤ) // LoopInv n p.1 p.2 }`
  classical
  let seqPair : ∀ n : ℕ, { p : WordStore × (ℕ → ℤ) // LoopInv n p.1 p.2 } :=
    Nat.rec ⟨(wsLeaf, rgLeaf), hInv0⟩ (fun i prev =>
      if hi : i < L then
        let hEx := hStepInv i hi prev.1.1 prev.1.2 prev.2
        let w' := Classical.choose hEx
        let hEx2 := Classical.choose_spec hEx
        let g' := Classical.choose hEx2
        let hSpec := Classical.choose_spec hEx2
        ⟨(w', g'), hSpec.2⟩
      else
        ⟨prev.1, ⟨prev.2.1, prev.2.2.1, prev.2.2.2.1, prev.2.2.2.2.1, fun hle => by omega⟩⟩)
  let wsSeq : ℕ → WordStore := fun n => (seqPair n).1.1
  let regSeq : ℕ → ℕ → ℤ := fun n => (seqPair n).1.2
  have hLoopExec : RegExec inp fd W C_cell C_bit (.repeatN (.lit (L : ℤ)) parentStepStmt)
      wsLeaf rgLeaf (wsSeq L) (regSeq L) (L * 350 + 2) (L * (56 * W * W) + W) := by
    have hL_bl : intBitLength (L : ℤ) ≤ W := by
      have h1 := intBitLength_ofNat_le L
      have hlt : L < 2 ^ L := Nat.lt_two_pow_self
      have hlog : Nat.log 2 L < L := Nat.log_lt_of_lt_pow (by omega) hlt
      unfold natBitLength at h1; omega
    refine RegExec.repeatLit L hL_bl wsSeq regSeq hbLeaf (fun i hi => ?_)
    have hseq_eq : seqPair (i + 1) =
        (let prev := seqPair i
         let hEx := hStepInv i hi prev.1.1 prev.1.2 prev.2
         let w' := Classical.choose hEx
         let hEx2 := Classical.choose_spec hEx
         let g' := Classical.choose hEx2
         let hSpec := Classical.choose_spec hEx2
         ⟨(w', g'), hSpec.2⟩) := by
      dsimp only [seqPair]
      exact dif_pos hi
    dsimp only [wsSeq, regSeq]
    rw [hseq_eq]
    let prev := seqPair i
    let hEx := hStepInv i hi prev.1.1 prev.1.2 prev.2
    let hEx2 := Classical.choose_spec hEx
    exact (Classical.choose_spec hEx2).1
  have hInvL : LoopInv L (wsSeq L) (regSeq L) := (seqPair L).2
  obtain ⟨hmodEnd, hbEnd, hunchEnd, hu0End, hrestEnd⟩ := hInvL
  obtain ⟨_, _, hnodesEnd⟩ := hrestEnd le_rfl
  have htreeEnd : TreeStoredAt L tid S' rNum' rDen' (wsSeq L) :=
    { hS := fun h hm => (hS'_bnds h hm).1
      u0_empty := hu0End
      nodes := fun k hk off hoff => (hnodesEnd k hk off hoff).1 hk }
  have sFull := s1.seq (s2.seq (s3.seq (s4.seq (s5.seq (s6.seq (s7.seq (s8.seq (s9.seq (s10.seq hLoopExec)))))))))
  have huc_tot : 4 + (8 + (4 + (8 + (8 + (4 + (8 + (4 + (24 + (80 + (L * 350 + 2)))))))))) ≤ 350 * L + 180 := by omega
  have hbc_tot : 2 * W + 16 + (4 * W * W + (2 * W + 16 + (6 * W + 32 + (6 * W + 32 +
      (2 * W + 16 + (4 * W * W + (2 * W + 16 + (16 * W + 96 + (80 * W + 400 +
      (L * (56 * W * W) + W)))))))))) ≤ (56 * L + 32) * W * W := by
    nlinarith only [hW8]
  exact ⟨wsSeq L, regSeq L, sFull.weaken rfl rfl huc_tot hbc_tot, hmodEnd, hbEnd, htreeEnd, hunchEnd⟩

end UL.C12LVE
