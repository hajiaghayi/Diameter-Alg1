import Mathlib
import UL.Proof.clm_7_3_las_vegas_endpoint.ClaudeC12_H2c1_SubInv
set_option autoImplicit false

namespace UL.C12LVE

open UL
open UL.Proof_lem_A_1

/-! ### 1. `WordStore` write/free algebraic and size lemmas -/

theorem cellCount_write_le (ws : WordStore) (loc : RAMCellLoc) (val : ℤ) :
    (ws.write loc val).cellCount ≤ ws.cellCount + 1 :=
  Finset.card_insert_le loc ws.live

theorem cellCount_write_not_mem {ws : WordStore} {loc : RAMCellLoc}
    (hnot : loc ∉ ws.live) (val : ℤ) :
    (ws.write loc val).cellCount = ws.cellCount + 1 :=
  Finset.card_insert_of_notMem hnot

theorem bitSize_write_le (ws : WordStore) (loc : RAMCellLoc) (val : ℤ) :
    (ws.write loc val).bitSize ≤ ws.bitSize + loc.bitLength + intBitLength val := by
  unfold WordStore.bitSize WordStore.write
  by_cases hmem : loc ∈ ws.live
  · rw [Finset.insert_eq_of_mem hmem]
    have hsplit : ∑ l ∈ ws.live, (l.bitLength + intBitLength (Function.update ws.vals loc val l)) =
        (loc.bitLength + intBitLength val) +
          ∑ l ∈ ws.live.erase loc, (l.bitLength + intBitLength (ws.vals l)) := by
      conv_lhs => rw [← Finset.insert_erase hmem]
      rw [Finset.sum_insert (Finset.notMem_erase loc ws.live)]
      simp only [Function.update_self]
      congr 1
      refine Finset.sum_congr rfl fun l hl => ?_
      rw [Function.update_of_ne (Finset.ne_of_mem_erase hl)]
    have herase : ∑ l ∈ ws.live.erase loc, (l.bitLength + intBitLength (ws.vals l)) ≤
        ∑ l ∈ ws.live, (l.bitLength + intBitLength (ws.vals l)) :=
      Finset.sum_le_sum_of_subset (Finset.erase_subset loc ws.live)
    linarith
  · rw [Finset.sum_insert hmem]
    simp only [Function.update_self]
    have heq : ∑ l ∈ ws.live, (l.bitLength + intBitLength (Function.update ws.vals loc val l)) =
        ∑ l ∈ ws.live, (l.bitLength + intBitLength (ws.vals l)) := by
      refine Finset.sum_congr rfl fun l hl => ?_
      have hne : l ≠ loc := fun h => hmem (h ▸ hl)
      rw [Function.update_of_ne hne]
    linarith

theorem bitSize_free_mem {ws : WordStore} {loc : RAMCellLoc} (hmem : loc ∈ ws.live) :
    (ws.free loc).bitSize + loc.bitLength + intBitLength (ws.vals loc) = ws.bitSize := by
  unfold WordStore.bitSize WordStore.free
  have heq : ∑ l ∈ ws.live.erase loc, (l.bitLength + intBitLength (Function.update ws.vals loc 0 l)) =
      ∑ l ∈ ws.live.erase loc, (l.bitLength + intBitLength (ws.vals l)) := by
    refine Finset.sum_congr rfl fun l hl => ?_
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hl)]
  rw [heq]
  have hins := Finset.sum_insert (f := fun l : RAMCellLoc => l.bitLength + intBitLength (ws.vals l))
    (Finset.notMem_erase loc ws.live)
  rw [Finset.insert_erase hmem] at hins
  linarith

theorem mem_live_bitLength_le {ws : WordStore} {loc : RAMCellLoc} (hmem : loc ∈ ws.live) :
    loc.bitLength + intBitLength (ws.vals loc) ≤ ws.bitSize := by
  unfold WordStore.bitSize
  exact Finset.single_le_sum (f := fun l : RAMCellLoc => l.bitLength + intBitLength (ws.vals l)) (fun _ _ => Nat.zero_le _) hmem

theorem wordStore_write_comm {ws : WordStore} {l₁ l₂ : RAMCellLoc}
    (hne : l₁ ≠ l₂) (v₁ v₂ : ℤ) :
    (ws.write l₁ v₁).write l₂ v₂ = (ws.write l₂ v₂).write l₁ v₁ := by
  cases ws with
  | mk live vals =>
      unfold WordStore.write
      congr 1
      · ext x; simp [or_left_comm]
      · exact Function.update_comm hne v₁ v₂ vals

theorem wordStore_free_write_comm {ws : WordStore} {l₁ l₂ : RAMCellLoc}
    (hne : l₁ ≠ l₂) (v₁ : ℤ) :
    (ws.write l₁ v₁).free l₂ = (ws.free l₂).write l₁ v₁ := by
  cases ws with
  | mk live vals =>
      unfold WordStore.write WordStore.free
      congr 1
      · ext x
        simp only [Finset.mem_erase, Finset.mem_insert]
        constructor
        · rintro ⟨hx2, rfl | hx⟩
          · exact Or.inl rfl
          · exact Or.inr ⟨hx2, hx⟩
        · rintro (rfl | ⟨hx2, hx⟩)
          · exact ⟨hne, Or.inl rfl⟩
          · exact ⟨hx2, Or.inr hx⟩
      · exact Function.update_comm hne v₁ 0 vals

theorem wordStore_free_write_self {ws : WordStore} (hwf : WellFormedWS ws)
    {loc : RAMCellLoc} (hnot : loc ∉ ws.live) (v : ℤ) :
    (ws.write loc v).free loc = ws := by
  cases ws with
  | mk live vals =>
      dsimp [WellFormedWS] at hwf
      unfold WordStore.write WordStore.free
      dsimp only
      congr 1
      · exact Finset.erase_insert hnot
      · funext l
        simp only [Function.update_idem]
        by_cases heq : l = loc
        · subst heq
          simpa using (hwf l hnot).symm
        · exact Function.update_of_ne heq 0 vals

@[simp] theorem wordStore_read_write_self (ws : WordStore) (loc : RAMCellLoc) (v : ℤ) :
    (ws.write loc v).read loc = v := by
  simp [WordStore.read, WordStore.write]

theorem wordStore_read_write_ne (ws : WordStore) {l₁ l₂ : RAMCellLoc}
    (hne : l₁ ≠ l₂) (v : ℤ) :
    (ws.write l₂ v).read l₁ = ws.read l₁ := by
  simp [WordStore.read, WordStore.write, hne]

@[simp] theorem wordStore_read_free_self (ws : WordStore) (loc : RAMCellLoc) :
    (ws.free loc).read loc = 0 := by
  simp [WordStore.read, WordStore.free]

theorem wordStore_read_free_ne (ws : WordStore) {l₁ l₂ : RAMCellLoc}
    (hne : l₁ ≠ l₂) :
    (ws.free l₂).read l₁ = ws.read l₁ := by
  simp [WordStore.read, WordStore.free, hne]

/-! ### 2. `A2SimInv` preservation on `popDepth`, `writeLocal`, `freeLocal`, and base updates -/

theorem A2SimInv.popDepth {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    (prev : ℕ) :
    A2SimInv wsBase T_max S_max (wsSub.popDepth prev) (wsSim.popDepth (2 + prev))
      highSid sidOfEnc encOfSid freeStack := by
  have hbase_keep : ∀ loc, IsA2BaseLoc loc → loc.keepAtDepth (2 + prev) = true := by
    intro loc hb
    cases loc with
    | heap _ _ => rfl
    | localFrame d _ _ =>
        dsimp [IsA2BaseLoc] at hb
        subst hb
        simp [RAMCellLoc.keepAtDepth]; omega
  refine
    { wfBase := hinv.wfBase
      wfSub := wellFormedWS_popDepth hinv.wfSub prev
      wfSim := wellFormedWS_popDepth hinv.wfSim (2 + prev)
      hT := hinv.hT
      high_le := hinv.high_le
      sub_tables := fun t idx h =>
        hinv.sub_tables t idx (Finset.mem_of_mem_filter _ h)
      base_live := fun loc hb => by
        simp [WordStore.popDepth, hbase_keep loc hb, hinv.base_live loc hb]
      base_vals := fun loc hb => by
        simp [WordStore.popDepth, hbase_keep loc hb, hinv.base_vals loc hb]
      local_live := fun d var idx => by
        simp only [WordStore.popDepth, Finset.mem_filter, RAMCellLoc.keepAtDepth,
          decide_eq_true_eq, Nat.add_le_add_iff_left]
        exact and_congr_left (fun _ => hinv.local_live d var idx)
      local_vals := fun d var idx => by
        simp only [WordStore.popDepth, RAMCellLoc.keepAtDepth, decide_eq_true_eq,
          Nat.add_le_add_iff_left]
        split_ifs
        · exact hinv.local_vals d var idx
        · rfl
      tab10_live := fun e => by
        simp [WordStore.popDepth, RAMCellLoc.keepAtDepth, hinv.tab10_live e]
      tab10_read := fun t ht idx => by
        rw [wordStore_popDepth_read_heap, wordStore_popDepth_read_heap]
        exact hinv.tab10_read t ht idx
      free_nodup := hinv.free_nodup
      free_lt := hinv.free_lt
      active_iff := fun e => by
        simp [WordStore.popDepth, RAMCellLoc.keepAtDepth, hinv.active_iff e]
      sid_lt := hinv.sid_lt
      enc_sid := hinv.enc_sid
      tab12_4 := ⟨fun hf hm => hinv.tab12_4.1 hf (Finset.mem_of_mem_filter _ hm),
        by rw [wordStore_popDepth_read_heap]; exact hinv.tab12_4.2⟩
      tab12_5 := ⟨fun hh hm => hinv.tab12_5.1 hh (Finset.mem_of_mem_filter _ hm),
        by rw [wordStore_popDepth_read_heap]; exact hinv.tab12_5.2⟩
      tab12_other := fun idx h4 h5 hm =>
        hinv.tab12_other idx h4 h5 (Finset.mem_of_mem_filter _ hm)
      tab13_spec := fun e =>
        ⟨fun s hs => ⟨Finset.mem_filter.mpr ⟨((hinv.tab13_spec e).1 s hs).1, rfl⟩,
          ((hinv.tab13_spec e).1 s hs).2⟩,
         fun hn hm => (hinv.tab13_spec e).2 hn (Finset.mem_of_mem_filter _ hm)⟩
      tab14_spec := fun z =>
        ⟨fun hz hlt => ⟨Finset.mem_filter.mpr ⟨((hinv.tab14_spec z).1 hz hlt).1, rfl⟩,
          ((hinv.tab14_spec z).1 hz hlt).2⟩,
         fun hn hm => (hinv.tab14_spec z).2 hn (Finset.mem_of_mem_filter _ hm)⟩
      tab15_16_spec := fun z =>
        ⟨fun h =>
          let h0 := (hinv.tab15_16_spec z).1 h
          ⟨Finset.mem_filter.mpr ⟨h0.1, rfl⟩, h0.2.1,
           Finset.mem_filter.mpr ⟨h0.2.2.1, rfl⟩, h0.2.2.2⟩,
         fun hn =>
          ⟨fun hm => ((hinv.tab15_16_spec z).2 hn).1 (Finset.mem_of_mem_filter _ hm),
           fun hm => ((hinv.tab15_16_spec z).2 hn).2 (Finset.mem_of_mem_filter _ hm)⟩⟩
      live_cases := fun loc hm => hinv.live_cases loc (Finset.mem_of_mem_filter _ hm) }

def isHeapLoc : RAMCellLoc → Bool
  | .heap _ _ => true
  | .localFrame _ _ _ => false

/-- Keep only heap cells in a `WordStore` (used upon exiting the `localScope` around `trA2Stmt`). -/
def heapOnlyWS (ws : WordStore) : WordStore where
  live := ws.live.filter (fun loc => isHeapLoc loc = true)
  vals := fun loc => if isHeapLoc loc then ws.vals loc else 0

theorem wellFormedWS_heapOnly {ws : WordStore} (hwf : WellFormedWS ws) :
    WellFormedWS (heapOnlyWS ws) := by
  intro loc hnot
  cases loc with
  | heap t idx =>
      simp only [heapOnlyWS, isHeapLoc, Finset.mem_filter, and_true, ↓reduceIte] at hnot ⊢
      exact hwf _ hnot
  | localFrame _ _ _ => rfl

theorem heapOnly_read_heap (ws : WordStore) (t : ℕ) (idx : ℤ) :
    (heapOnlyWS ws).read (.heap t idx) = ws.read (.heap t idx) := by
  simp [heapOnlyWS, isHeapLoc, WordStore.read]

theorem cellCount_heapOnly_le (ws : WordStore) :
    (heapOnlyWS ws).cellCount ≤ ws.cellCount :=
  Finset.card_filter_le _ _

theorem bitSize_heapOnly_le (ws : WordStore) :
    (heapOnlyWS ws).bitSize ≤ ws.bitSize := by
  unfold WordStore.bitSize heapOnlyWS
  calc ∑ l ∈ ws.live.filter (fun loc => isHeapLoc loc = true),
          (l.bitLength + intBitLength (if isHeapLoc l then ws.vals l else 0))
      = ∑ l ∈ ws.live.filter (fun loc => isHeapLoc loc = true),
          (l.bitLength + intBitLength (ws.vals l)) := by
        refine Finset.sum_congr rfl fun l hl => ?_
        simp [(Finset.mem_filter.mp hl).2]
    _ ≤ ∑ l ∈ ws.live, (l.bitLength + intBitLength (ws.vals l)) :=
        Finset.sum_le_sum_of_subset (Finset.filter_subset _ _)

theorem A2SimInv.popToDepth1 {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack) :
    A2SimInv wsBase T_max S_max (heapOnlyWS wsSub) (wsSim.popDepth 1)
      highSid sidOfEnc encOfSid freeStack := by
  have hbase_keep : ∀ loc, IsA2BaseLoc loc → loc.keepAtDepth 1 = true := by
    intro loc hb
    cases loc with
    | heap _ _ => rfl
    | localFrame d _ _ =>
        dsimp [IsA2BaseLoc] at hb
        subst hb
        simp [RAMCellLoc.keepAtDepth]
  refine
    { wfBase := hinv.wfBase
      wfSub := wellFormedWS_heapOnly hinv.wfSub
      wfSim := wellFormedWS_popDepth hinv.wfSim 1
      hT := hinv.hT
      high_le := hinv.high_le
      sub_tables := fun t idx h =>
        hinv.sub_tables t idx (Finset.mem_of_mem_filter _ h)
      base_live := fun loc hb => by
        simp [WordStore.popDepth, hbase_keep loc hb, hinv.base_live loc hb]
      base_vals := fun loc hb => by
        simp [WordStore.popDepth, hbase_keep loc hb, hinv.base_vals loc hb]
      local_live := fun d var idx => by
        simp [WordStore.popDepth, heapOnlyWS, isHeapLoc, RAMCellLoc.keepAtDepth]; omega
      local_vals := fun d var idx => by
        simp [WordStore.popDepth, heapOnlyWS, isHeapLoc, RAMCellLoc.keepAtDepth]; omega
      tab10_live := fun e => by
        simp [WordStore.popDepth, heapOnlyWS, isHeapLoc, RAMCellLoc.keepAtDepth, hinv.tab10_live e]
      tab10_read := fun t ht idx => by
        rw [wordStore_popDepth_read_heap, heapOnly_read_heap]
        exact hinv.tab10_read t ht idx
      free_nodup := hinv.free_nodup
      free_lt := hinv.free_lt
      active_iff := fun e => by
        simp [WordStore.popDepth, RAMCellLoc.keepAtDepth, hinv.active_iff e]
      sid_lt := hinv.sid_lt
      enc_sid := hinv.enc_sid
      tab12_4 := ⟨fun hf hm => hinv.tab12_4.1 hf (Finset.mem_of_mem_filter _ hm),
        by rw [wordStore_popDepth_read_heap]; exact hinv.tab12_4.2⟩
      tab12_5 := ⟨fun hh hm => hinv.tab12_5.1 hh (Finset.mem_of_mem_filter _ hm),
        by rw [wordStore_popDepth_read_heap]; exact hinv.tab12_5.2⟩
      tab12_other := fun idx h4 h5 hm =>
        hinv.tab12_other idx h4 h5 (Finset.mem_of_mem_filter _ hm)
      tab13_spec := fun e =>
        ⟨fun s hs => ⟨Finset.mem_filter.mpr ⟨((hinv.tab13_spec e).1 s hs).1, rfl⟩,
          ((hinv.tab13_spec e).1 s hs).2⟩,
         fun hn hm => (hinv.tab13_spec e).2 hn (Finset.mem_of_mem_filter _ hm)⟩
      tab14_spec := fun z =>
        ⟨fun hz hlt => ⟨Finset.mem_filter.mpr ⟨((hinv.tab14_spec z).1 hz hlt).1, rfl⟩,
          ((hinv.tab14_spec z).1 hz hlt).2⟩,
         fun hn hm => (hinv.tab14_spec z).2 hn (Finset.mem_of_mem_filter _ hm)⟩
      tab15_16_spec := fun z =>
        ⟨fun h =>
          let h0 := (hinv.tab15_16_spec z).1 h
          ⟨Finset.mem_filter.mpr ⟨h0.1, rfl⟩, h0.2.1,
           Finset.mem_filter.mpr ⟨h0.2.2.1, rfl⟩, h0.2.2.2⟩,
         fun hn =>
          ⟨fun hm => ((hinv.tab15_16_spec z).2 hn).1 (Finset.mem_of_mem_filter _ hm),
           fun hm => ((hinv.tab15_16_spec z).2 hn).2 (Finset.mem_of_mem_filter _ hm)⟩⟩
      live_cases := fun loc hm => hinv.live_cases loc (Finset.mem_of_mem_filter _ hm) }

theorem A2SimInv.writeLocal {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    (fdSub var : ℕ) (idx val : ℤ) :
    A2SimInv wsBase T_max S_max
      (wsSub.write (.localFrame fdSub var idx) val)
      (wsSim.write (.localFrame (2 + fdSub) var idx) val)
      highSid sidOfEnc encOfSid freeStack := by
  have hnb : ∀ loc, IsA2BaseLoc loc → loc ≠ .localFrame (2 + fdSub) var idx := by
    intro loc hb h
    subst h; dsimp [IsA2BaseLoc] at hb; omega
  refine
    { wfBase := hinv.wfBase
      wfSub := wellFormedWS_write hinv.wfSub _ _
      wfSim := wellFormedWS_write hinv.wfSim _ _
      hT := hinv.hT
      high_le := hinv.high_le
      sub_tables := fun t i h => by
        simp only [WordStore.write, Finset.mem_insert, reduceCtorEq, false_or] at h
        exact hinv.sub_tables t i h
      base_live := fun loc hb => by
        simp [WordStore.write, hnb loc hb, hinv.base_live loc hb]
      base_vals := fun loc hb => by
        simp [WordStore.write, Function.update_of_ne (hnb loc hb), hinv.base_vals loc hb]
      local_live := fun d v i => by
        simp only [WordStore.write, Finset.mem_insert, RAMCellLoc.localFrame.injEq,
          Nat.add_left_cancel_iff]
        exact or_congr_right (hinv.local_live d v i)
      local_vals := fun d v i => by
        simp only [WordStore.write]
        by_cases heq : d = fdSub ∧ v = var ∧ i = idx
        · rcases heq with ⟨rfl, rfl, rfl⟩; simp
        · have hne1 : (.localFrame (2 + d) v i : RAMCellLoc) ≠ .localFrame (2 + fdSub) var idx := by
            simp [heq]
          have hne2 : (.localFrame d v i : RAMCellLoc) ≠ .localFrame fdSub var idx := by
            simp [heq]
          rw [Function.update_of_ne hne1, Function.update_of_ne hne2]
          exact hinv.local_vals d v i
      tab10_live := fun e => by
        simp [WordStore.write, hinv.tab10_live e]
      tab10_read := fun t ht i => by
        rw [wordStore_read_write_ne _ (by simp) _, wordStore_read_write_ne _ (by simp) _]
        exact hinv.tab10_read t ht i
      free_nodup := hinv.free_nodup
      free_lt := hinv.free_lt
      active_iff := fun e => by simp [WordStore.write, hinv.active_iff e]
      sid_lt := hinv.sid_lt
      enc_sid := hinv.enc_sid
      tab12_4 := ⟨fun hf => by simp [WordStore.write, hinv.tab12_4.1 hf],
        by rw [wordStore_read_write_ne _ (by simp)]; exact hinv.tab12_4.2⟩
      tab12_5 := ⟨fun hh => by simp [WordStore.write, hinv.tab12_5.1 hh],
        by rw [wordStore_read_write_ne _ (by simp)]; exact hinv.tab12_5.2⟩
      tab12_other := fun i h4 h5 => by simp [WordStore.write, hinv.tab12_other i h4 h5]
      tab13_spec := fun e =>
        ⟨fun s hs => by
          have h0 := (hinv.tab13_spec e).1 s hs
          refine ⟨by simp [WordStore.write, h0.1], ?_⟩
          simp [WordStore.write, h0.2],
         fun hn => by simp [WordStore.write, (hinv.tab13_spec e).2 hn]⟩
      tab14_spec := fun z =>
        ⟨fun hz hlt => by
          have h0 := (hinv.tab14_spec z).1 hz hlt
          refine ⟨by simp [WordStore.write, h0.1], ?_⟩
          simp [WordStore.write, h0.2],
         fun hn => by simp [WordStore.write, (hinv.tab14_spec z).2 hn]⟩
      tab15_16_spec := fun z =>
        ⟨fun h => by
          have h0 := (hinv.tab15_16_spec z).1 h
          refine ⟨by simp [WordStore.write, h0.1], by simp [WordStore.write, h0.2.1],
                  by simp [WordStore.write, h0.2.2.1], by simp [WordStore.write, h0.2.2.2]⟩,
         fun hn => by
          have h0 := (hinv.tab15_16_spec z).2 hn
          exact ⟨by simp [WordStore.write, h0.1], by simp [WordStore.write, h0.2]⟩⟩
      live_cases := fun loc hm => by
        simp only [WordStore.write, Finset.mem_insert] at hm
        rcases hm with rfl | hm'
        · exact Or.inr (Or.inl ⟨fdSub, var, idx, rfl⟩)
        · exact hinv.live_cases loc hm' }

theorem A2SimInv.freeLocal {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    (fdSub var : ℕ) (idx : ℤ) :
    A2SimInv wsBase T_max S_max
      (wsSub.free (.localFrame fdSub var idx))
      (wsSim.free (.localFrame (2 + fdSub) var idx))
      highSid sidOfEnc encOfSid freeStack := by
  have hnb : ∀ loc, IsA2BaseLoc loc → loc ≠ .localFrame (2 + fdSub) var idx := by
    intro loc hb h
    subst h; dsimp [IsA2BaseLoc] at hb; omega
  refine
    { wfBase := hinv.wfBase
      wfSub := wellFormedWS_free hinv.wfSub _
      wfSim := wellFormedWS_free hinv.wfSim _
      hT := hinv.hT
      high_le := hinv.high_le
      sub_tables := fun t i h => by
        simp only [WordStore.free, Finset.mem_erase] at h
        exact hinv.sub_tables t i h.2
      base_live := fun loc hb => by
        simp [WordStore.free, hnb loc hb, hinv.base_live loc hb]
      base_vals := fun loc hb => by
        simp [WordStore.free, Function.update_of_ne (hnb loc hb), hinv.base_vals loc hb]
      local_live := fun d v i => by
        simp only [WordStore.free, Finset.mem_erase, ne_eq, RAMCellLoc.localFrame.injEq,
          Nat.add_left_cancel_iff]
        exact and_congr_right (fun _ => hinv.local_live d v i)
      local_vals := fun d v i => by
        simp only [WordStore.free]
        by_cases heq : d = fdSub ∧ v = var ∧ i = idx
        · rcases heq with ⟨rfl, rfl, rfl⟩; simp
        · have hne1 : (.localFrame (2 + d) v i : RAMCellLoc) ≠ .localFrame (2 + fdSub) var idx := by
            simp [heq]
          have hne2 : (.localFrame d v i : RAMCellLoc) ≠ .localFrame fdSub var idx := by
            simp [heq]
          rw [Function.update_of_ne hne1, Function.update_of_ne hne2]
          exact hinv.local_vals d v i
      tab10_live := fun e => by
        simp [WordStore.free, hinv.tab10_live e]
      tab10_read := fun t ht i => by
        rw [wordStore_read_free_ne _ (by simp), wordStore_read_free_ne _ (by simp)]
        exact hinv.tab10_read t ht i
      free_nodup := hinv.free_nodup
      free_lt := hinv.free_lt
      active_iff := fun e => by simp [WordStore.free, hinv.active_iff e]
      sid_lt := hinv.sid_lt
      enc_sid := hinv.enc_sid
      tab12_4 := ⟨fun hf => by simp [WordStore.free, hinv.tab12_4.1 hf],
        by rw [wordStore_read_free_ne _ (by simp)]; exact hinv.tab12_4.2⟩
      tab12_5 := ⟨fun hh => by simp [WordStore.free, hinv.tab12_5.1 hh],
        by rw [wordStore_read_free_ne _ (by simp)]; exact hinv.tab12_5.2⟩
      tab12_other := fun i h4 h5 => by simp [WordStore.free, hinv.tab12_other i h4 h5]
      tab13_spec := fun e =>
        ⟨fun s hs => by
          have h0 := (hinv.tab13_spec e).1 s hs
          exact ⟨by simp [WordStore.free, h0.1], by simp [WordStore.free, h0.2]⟩,
         fun hn => by simp [WordStore.free, (hinv.tab13_spec e).2 hn]⟩
      tab14_spec := fun z =>
        ⟨fun hz hlt => by
          have h0 := (hinv.tab14_spec z).1 hz hlt
          exact ⟨by simp [WordStore.free, h0.1], by simp [WordStore.free, h0.2]⟩,
         fun hn => by simp [WordStore.free, (hinv.tab14_spec z).2 hn]⟩
      tab15_16_spec := fun z =>
        ⟨fun h => by
          have h0 := (hinv.tab15_16_spec z).1 h
          exact ⟨by simp [WordStore.free, h0.1], by simp [WordStore.free, h0.2.1],
                 by simp [WordStore.free, h0.2.2.1], by simp [WordStore.free, h0.2.2.2]⟩,
         fun hn => by
          have h0 := (hinv.tab15_16_spec z).2 hn
          exact ⟨by simp [WordStore.free, h0.1], by simp [WordStore.free, h0.2]⟩⟩
      live_cases := fun loc hm => by
        simp only [WordStore.free, Finset.mem_erase] at hm
        exact hinv.live_cases loc hm.2 }

theorem A2SimInv.replaceBase {wsBase wsBaseNew : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim wsSimNew : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    (hbNew : IsA2BaseStore wsBaseNew)
    (hwfNew : WellFormedWS wsSimNew)
    (hBaseLive : ∀ loc, IsA2BaseLoc loc → (loc ∈ wsSimNew.live ↔ loc ∈ wsBaseNew.live))
    (hBaseVals : ∀ loc, IsA2BaseLoc loc → wsSimNew.vals loc = wsBaseNew.vals loc)
    (hNonBaseLive : ∀ loc, ¬ IsA2BaseLoc loc → (loc ∈ wsSimNew.live ↔ loc ∈ wsSim.live))
    (hNonBaseVals : ∀ loc, ¬ IsA2BaseLoc loc → wsSimNew.vals loc = wsSim.vals loc) :
    A2SimInv wsBaseNew T_max S_max wsSub wsSimNew highSid sidOfEnc encOfSid freeStack := by
  have hnbRead : ∀ loc, ¬ IsA2BaseLoc loc → wsSimNew.read loc = wsSim.read loc := by
    intro loc hnb
    rw [wordStore_read_eq_vals hwfNew, wordStore_read_eq_vals hinv.wfSim]
    exact hNonBaseVals loc hnb
  refine
    { wfBase := hbNew
      wfSub := hinv.wfSub
      wfSim := hwfNew
      hT := hinv.hT
      high_le := hinv.high_le
      sub_tables := hinv.sub_tables
      base_live := hBaseLive
      base_vals := hBaseVals
      local_live := fun d v i =>
        (hNonBaseLive _ (by simp [IsA2BaseLoc]; omega)).trans (hinv.local_live d v i)
      local_vals := fun d v i =>
        (hNonBaseVals _ (by simp [IsA2BaseLoc]; omega)).trans (hinv.local_vals d v i)
      tab10_live := fun e =>
        (hNonBaseLive _ (by simp [IsA2BaseLoc])).trans (hinv.tab10_live e)
      tab10_read := fun t ht i =>
        (hnbRead _ (by simp [IsA2BaseLoc])).trans (hinv.tab10_read t ht i)
      free_nodup := hinv.free_nodup
      free_lt := hinv.free_lt
      active_iff := fun e =>
        (hNonBaseLive (.heap 10 e) (by simp [IsA2BaseLoc])).trans (hinv.active_iff e)
      sid_lt := hinv.sid_lt
      enc_sid := hinv.enc_sid
      tab12_4 := ⟨fun hf hm => hinv.tab12_4.1 hf ((hNonBaseLive _ (by simp [IsA2BaseLoc])).mp hm),
        (hnbRead _ (by simp [IsA2BaseLoc])).trans hinv.tab12_4.2⟩
      tab12_5 := ⟨fun hh hm => hinv.tab12_5.1 hh ((hNonBaseLive _ (by simp [IsA2BaseLoc])).mp hm),
        (hnbRead _ (by simp [IsA2BaseLoc])).trans hinv.tab12_5.2⟩
      tab12_other := fun i h4 h5 hm =>
        hinv.tab12_other i h4 h5 ((hNonBaseLive _ (by simp [IsA2BaseLoc])).mp hm)
      tab13_spec := fun e =>
        ⟨fun s hs =>
          let h0 := (hinv.tab13_spec e).1 s hs
          ⟨(hNonBaseLive _ (by simp [IsA2BaseLoc])).mpr h0.1,
           (hNonBaseVals _ (by simp [IsA2BaseLoc])).trans h0.2⟩,
         fun hn hm => (hinv.tab13_spec e).2 hn ((hNonBaseLive _ (by simp [IsA2BaseLoc])).mp hm)⟩
      tab14_spec := fun z =>
        ⟨fun hz hlt =>
          let h0 := (hinv.tab14_spec z).1 hz hlt
          ⟨(hNonBaseLive _ (by simp [IsA2BaseLoc])).mpr h0.1,
           (hNonBaseVals _ (by simp [IsA2BaseLoc])).trans h0.2⟩,
         fun hn hm => (hinv.tab14_spec z).2 hn ((hNonBaseLive _ (by simp [IsA2BaseLoc])).mp hm)⟩
      tab15_16_spec := fun z =>
        ⟨fun h =>
          let h0 := (hinv.tab15_16_spec z).1 h
          ⟨(hNonBaseLive _ (by simp [IsA2BaseLoc])).mpr h0.1,
           (hNonBaseVals _ (by simp [IsA2BaseLoc])).trans h0.2.1,
           (hNonBaseLive _ (by simp [IsA2BaseLoc])).mpr h0.2.2.1,
           (hNonBaseVals _ (by simp [IsA2BaseLoc])).trans h0.2.2.2⟩,
         fun hn =>
          ⟨fun hm => ((hinv.tab15_16_spec z).2 hn).1 ((hNonBaseLive _ (by simp [IsA2BaseLoc])).mp hm),
           fun hm => ((hinv.tab15_16_spec z).2 hn).2 ((hNonBaseLive _ (by simp [IsA2BaseLoc])).mp hm)⟩⟩
      live_cases := fun loc hm => by
        by_cases hb : IsA2BaseLoc loc
        · exact Or.inl hb
        · exact hinv.live_cases loc ((hNonBaseLive loc hb).mp hm) }

/-! ### 3. Space envelope and bounded-overhead combinators for macro steps -/

def a2CellBound {d : ℕ} (wsBase : WordStore) (inpSim : BitRAMInput d)
    (S_max subPeakCell : ℕ) : ℕ :=
  inpSim.inputCellSpace + wsBase.cellCount + 4 * subPeakCell + 2 * S_max + 16

def a2BitBound {d : ℕ} (wsBase : WordStore) (inpSim : BitRAMInput d)
    (T_max S_max subPeakBit : ℕ) : ℕ :=
  let S_bits := natBitLength S_max + 4
  inpSim.inputBitSpace + wsBase.bitSize +
    (3 * natBitLength T_max + 2 * S_bits + 48) * subPeakBit +
    4 * S_max * (S_bits + 8) + 16 * natBitLength T_max + 24 * S_bits + 256

theorem A2SimInv.within_bounds {d : ℕ} {wsBase : WordStore} {T_max S_max : ℕ}
    {wsSub wsSim : WordStore} {highSid : ℕ} {sidOfEnc : ℤ → Option ℕ}
    {encOfSid : ℕ → ℤ} {freeStack : List ℕ}
    (inpSim : BitRAMInput d)
    (hinv : A2SimInv wsBase T_max S_max wsSub wsSim highSid sidOfEnc encOfSid freeStack)
    {subPeakCell subPeakBit : ℕ}
    (hc : wsSub.cellCount ≤ subPeakCell)
    (hb : wsSub.bitSize ≤ subPeakBit) :
    inpSim.inputCellSpace + wsSim.cellCount + 12 ≤ a2CellBound wsBase inpSim S_max subPeakCell ∧
    inpSim.inputBitSpace + wsSim.bitSize +
        12 * subPeakBit + 16 * natBitLength T_max + 20 * (natBitLength S_max + 4) + 200 ≤
      a2BitBound wsBase inpSim T_max S_max subPeakBit := by
  have hsp := hinv.space_bounds
  dsimp only at hsp
  rcases hsp with ⟨hcSim, hbSim⟩
  constructor
  · unfold a2CellBound
    have hmul := Nat.mul_le_mul_left 4 hc
    linarith
  · unfold a2BitBound
    dsimp only
    have h1 : (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 36) * wsSub.bitSize ≤
        (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 36) * subPeakBit :=
      Nat.mul_le_mul_left _ hb
    have h2 : (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 36) * subPeakBit + 12 * subPeakBit =
        (3 * natBitLength T_max + 2 * (natBitLength S_max + 4) + 48) * subPeakBit := by ring
    linarith

def EvalIntLe {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    (e : IntExpr) (val : ℤ) (u b : ℕ) : Prop :=
  (evalIntExpr inp fd ws e).1 = val ∧
  (evalIntExpr inp fd ws e).2.1 ≤ u ∧
  (evalIntExpr inp fd ws e).2.2 ≤ b

theorem evalIntLe_lit {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    (c : ℤ) {b : ℕ} (hb : intBitLength c = b) :
    EvalIntLe inp fd ws (.lit c) c 1 b :=
  ⟨rfl, le_rfl, hb.le⟩

theorem exec_writeHeap_ceil {d : ℕ} (inp : BitRAMInput d) (table : ℕ) (idxE valE : IntExpr)
    (st : BitRAMExecState) {C_cell C_bit : ℕ}
    (hpC : st.peakCellSpace ≤ C_cell) (hpB : st.peakBitSpace ≤ C_bit)
    {idx val : ℤ} {u₁ b₁ u₂ b₂ : ℕ}
    (he1 : EvalIntLe inp st.frameDepth st.words idxE idx u₁ b₁)
    (he2 : EvalIntLe inp st.frameDepth st.words valE val u₂ b₂)
    (hcNew : inp.inputCellSpace + (st.words.write (.heap table idx) val).cellCount ≤ C_cell)
    (hbNew : inp.inputBitSpace + (st.words.write (.heap table idx) val).bitSize ≤ C_bit) :
    ∃ st' : BitRAMExecState,
      RunsTo inp [.stmt (.writeHeap table idxE valE)] st st' ∧
      st'.words = st.words.write (.heap table idx) val ∧
      st'.frameDepth = st.frameDepth ∧
      st'.remainingBits = st.remainingBits ∧
      st'.unitCost ≤ st.unitCost + u₁ + u₂ + 1 ∧
      st'.bitCost ≤ st.bitCost + b₁ + b₂ + (natBitLength table + intBitLength idx) + intBitLength val ∧
      st'.peakCellSpace ≤ C_cell ∧
      st'.peakBitSpace ≤ C_bit := by
  have hrun := RunsTo.writeHeap inp table idxE valE st
  unfold EvalIntLe at he1 he2
  rcases hr1 : evalIntExpr inp st.frameDepth st.words idxE with ⟨i', u1', b1'⟩
  rcases hr2 : evalIntExpr inp st.frameDepth st.words valE with ⟨v', u2', b2'⟩
  rw [hr1] at he1; dsimp only at he1; rcases he1 with ⟨rfl, hu1, hb1⟩
  rw [hr2] at he2; dsimp only at he2; rcases he2 with ⟨rfl, hu2, hb2⟩
  let loc := RAMCellLoc.heap table i'
  let ws' := st.words.write loc v'
  let st' : BitRAMExecState :=
    { st with
      words := ws'
      unitCost := st.unitCost + u1' + u2' + 1
      bitCost := st.bitCost + b1' + b2' + loc.bitLength + intBitLength v'
      peakCellSpace := max st.peakCellSpace (inp.inputCellSpace + ws'.cellCount)
      peakBitSpace := max st.peakBitSpace (inp.inputBitSpace + ws'.bitSize) }
  have hrun' : RunsTo inp [.stmt (.writeHeap table idxE valE)] st st' := by
    simpa only [hr1, hr2] using hrun
  refine ⟨st', hrun', rfl, rfl, rfl, ?_, ?_, max_le hpC hcNew, max_le hpB hbNew⟩
  · dsimp only [st']; omega
  · dsimp only [st', loc, RAMCellLoc.bitLength]; omega

theorem exec_freeHeap_ceil {d : ℕ} (inp : BitRAMInput d) (table : ℕ) (idxE : IntExpr)
    (st : BitRAMExecState) {C_cell C_bit : ℕ}
    (hpC : st.peakCellSpace ≤ C_cell) (hpB : st.peakBitSpace ≤ C_bit)
    {idx : ℤ} {u₁ b₁ : ℕ}
    (he1 : EvalIntLe inp st.frameDepth st.words idxE idx u₁ b₁) :
    ∃ st' : BitRAMExecState,
      RunsTo inp [.stmt (.freeHeap table idxE)] st st' ∧
      st'.words = st.words.free (.heap table idx) ∧
      st'.frameDepth = st.frameDepth ∧
      st'.remainingBits = st.remainingBits ∧
      st'.unitCost ≤ st.unitCost + u₁ + 1 ∧
      st'.bitCost ≤ st.bitCost + b₁ + (natBitLength table + intBitLength idx) ∧
      st'.peakCellSpace ≤ C_cell ∧
      st'.peakBitSpace ≤ C_bit := by
  have hrun := RunsTo.freeHeap inp table idxE st
  unfold EvalIntLe at he1
  rcases hr1 : evalIntExpr inp st.frameDepth st.words idxE with ⟨i', u1', b1'⟩
  rw [hr1] at he1; dsimp only at he1; rcases he1 with ⟨rfl, hu1, hb1⟩
  let loc := RAMCellLoc.heap table i'
  let st' : BitRAMExecState :=
    { st with
      words := st.words.free loc
      unitCost := st.unitCost + u1' + 1
      bitCost := st.bitCost + b1' + loc.bitLength }
  have hrun' : RunsTo inp [.stmt (.freeHeap table idxE)] st st' := by
    simpa only [hr1] using hrun
  refine ⟨st', hrun', rfl, rfl, rfl, ?_, ?_, hpC, hpB⟩
  · dsimp only [st']; omega
  · dsimp only [st', loc, RAMCellLoc.bitLength]; omega


theorem evalIntLe_readHeap_lit {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    (t : ℕ) (c v : ℤ) {bt bc b : ℕ}
    (hr : ws.read (.heap t c) = v)
    (hbt : natBitLength t = bt) (hbc : intBitLength c = bc)
    (hb : bc + bt + bc + intBitLength v ≤ b) :
    EvalIntLe inp fd ws (.readHeap t (.lit c)) v 2 b := by
  unfold EvalIntLe
  simp only [evalIntExpr, hr, hbt, hbc]
  exact ⟨trivial, le_rfl, hb⟩

theorem evalIntLe_add_read12_one {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    (c : ℤ) (n : ℕ) {bc b : ℕ}
    (hr : ws.read (.heap 12 c) = (n : ℤ))
    (hbc : intBitLength c = bc)
    (hb : (bc + 4 + bc + intBitLength (n : ℤ)) + 2 + intBitLength (n : ℤ) + 2 ≤ b) :
    EvalIntLe inp fd ws (.add (.readHeap 12 (.lit c)) (.lit 1)) (((n + 1 : ℕ) : ℤ)) 4 b := by
  unfold EvalIntLe
  have h12 : natBitLength 12 = 4 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  simp only [evalIntExpr, hr, h12, hbc, hl1]
  exact ⟨by push_cast; ring, le_rfl, hb⟩

theorem evalIntLe_sub_read12_one {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    (c v res : ℤ) {bc b : ℕ}
    (hr : ws.read (.heap 12 c) = v)
    (hsub : v - 1 = res)
    (hbc : intBitLength c = bc)
    (hb : (bc + 4 + bc + intBitLength v) + 2 + intBitLength v + 2 ≤ b) :
    EvalIntLe inp fd ws (.sub (.readHeap 12 (.lit c)) (.lit 1)) res 4 b := by
  unfold EvalIntLe
  have h12 : natBitLength 12 = 4 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  simp only [evalIntExpr, hr, hsub, h12, hbc, hl1]
  exact ⟨trivial, le_rfl, hb⟩

theorem evalIntLe_read_sub_read12_one {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    (t : ℕ) (c v idx res : ℤ) {bt bc b : ℕ}
    (hr1 : ws.read (.heap 12 c) = v)
    (hsub : v - 1 = idx)
    (hr2 : ws.read (.heap t idx) = res)
    (hbt : natBitLength t = bt) (hbc : intBitLength c = bc)
    (hb : ((bc + 4 + bc + intBitLength v) + 2 + intBitLength v + 2) + bt + intBitLength idx + intBitLength res ≤ b) :
    EvalIntLe inp fd ws (.readHeap t (.sub (.readHeap 12 (.lit c)) (.lit 1))) res 5 b := by
  unfold EvalIntLe
  have h12 : natBitLength 12 = 4 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  simp only [evalIntExpr, hr1, hsub, hr2, h12, hbt, hbc, hl1]
  exact ⟨trivial, le_rfl, hb⟩

theorem evalIntLe_sub_read_read12_one {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    (t : ℕ) (c e v res : ℤ) {bt bc b : ℕ}
    (hr1 : ws.read (.heap 12 c) = e)
    (hr2 : ws.read (.heap t e) = v)
    (hsub : v - 1 = res)
    (hbt : natBitLength t = bt) (hbc : intBitLength c = bc)
    (hb : ((bc + 4 + bc + intBitLength e) + bt + intBitLength e + intBitLength v) + 2 + intBitLength v + 2 ≤ b) :
    EvalIntLe inp fd ws (.sub (.readHeap t (.readHeap 12 (.lit c))) (.lit 1)) res 5 b := by
  unfold EvalIntLe
  have h12 : natBitLength 12 = 4 := by decide
  have hl1 : intBitLength (1 : ℤ) = 2 := by decide
  simp only [evalIntExpr, hr1, hr2, hsub, h12, hbt, hbc, hl1]
  exact ⟨trivial, le_rfl, hb⟩

theorem evalIntLe_read_read12 {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    (t : ℕ) (c idx res : ℤ) {bt bc b : ℕ}
    (hr1 : ws.read (.heap 12 c) = idx)
    (hr2 : ws.read (.heap t idx) = res)
    (hbt : natBitLength t = bt) (hbc : intBitLength c = bc)
    (hb : (bc + 4 + bc + intBitLength idx) + bt + intBitLength idx + intBitLength res ≤ b) :
    EvalIntLe inp fd ws (.readHeap t (.readHeap 12 (.lit c))) res 3 b := by
  unfold EvalIntLe
  have h12 : natBitLength 12 = 4 := by decide
  simp only [evalIntExpr, hr1, hr2, h12, hbt, hbc]
  exact ⟨trivial, le_rfl, hb⟩

end UL.C12LVE
