import Mathlib
import UL.Stmt.cit_gls88_rational_lp
import UL.Proof.cit_gls88_rational_lp.RacerCG_H4
set_option autoImplicit false

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

theorem P_cit_gls88_rational_lp : UL.S_cit_gls88_rational_lp :=
  ⟨part1_progLP, part2_progHull, part3_progCert⟩

end UL.Proof.cit_gls88_rational_lp.RacerCG

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_cit_gls88_rational_lp : S_cit_gls88_rational_lp :=
  UL.Proof.cit_gls88_rational_lp.RacerCG.P_cit_gls88_rational_lp

end UL
