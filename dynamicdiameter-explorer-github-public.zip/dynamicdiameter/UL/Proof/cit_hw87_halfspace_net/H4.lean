import Mathlib
set_option autoImplicit false

namespace UL.Proof_cit_hw87_halfspace_net

theorem hw87_analytic_bound
    (D : ℕ) (hD : 1 ≤ D)
    (α : ℝ) (hα0 : 0 < α) (hα1 : α ≤ 1)
    (δ : ℝ) (hδ0 : 0 < δ) (hδ1 : δ < 1)
    (s : ℕ)
    (hs : Nat.ceil ((64 : ℝ) * α⁻¹ * (((D : ℝ) + 1) * Real.log (2 / α) + Real.log (2 / δ))) ≤ s) :
    8 ≤ α * (s : ℝ) ∧
    D + 1 ≤ 2 * s ∧
    2 * ((Real.exp 1 * (2 * (s : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1)) /
      ((2 : ℝ) ^ Nat.ceil (α * (s : ℝ) / 2)) ≤ δ := by
  let d : ℕ := D + 1
  have hd_ge : 2 ≤ d := by omega
  have hd_cast : (d : ℝ) = (D : ℝ) + 1 := by simp [d]
  have hd_pos : (0 : ℝ) < (d : ℝ) := by positivity
  have hd_ge_real : (2 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd_ge
  have hlog2_gt : (1 / 2 : ℝ) < Real.log 2 := by
    have h := Real.log_two_gt_d9
    linarith
  have hlog2_pos : (0 : ℝ) < Real.log 2 := by linarith
  have h2α_ge : (2 : ℝ) ≤ 2 / α := by
    rw [le_div_iff₀ hα0]
    linarith
  have h2α_pos : (0 : ℝ) < 2 / α := by positivity
  have hlog2α : Real.log 2 ≤ Real.log (2 / α) :=
    Real.log_le_log (by norm_num) h2α_ge
  have h2δ_gt : (2 : ℝ) < 2 / δ := by
    rw [lt_div_iff₀ hδ0]
    linarith
  have h2δ_pos : (0 : ℝ) < 2 / δ := by positivity
  have hlog2δ : Real.log 2 < Real.log (2 / δ) :=
    Real.log_lt_log (by norm_num) h2δ_gt
  let L : ℝ := (d : ℝ) * Real.log (2 / α) + Real.log (2 / δ)
  have hL_ge : (d : ℝ) * Real.log 2 + Real.log 2 ≤ L := by
    have h1 : (d : ℝ) * Real.log 2 ≤ (d : ℝ) * Real.log (2 / α) :=
      mul_le_mul_of_nonneg_left hlog2α hd_pos.le
    linarith
  have hL_gt_num : (3 / 2 : ℝ) < L := by
    have h1 : (2 : ℝ) * (1 / 2 : ℝ) ≤ (d : ℝ) * Real.log 2 := by nlinarith
    linarith
  have hs_real : (64 : ℝ) * α⁻¹ * L ≤ (s : ℝ) := by
    have hceil : (64 : ℝ) * α⁻¹ * (((D : ℝ) + 1) * Real.log (2 / α) + Real.log (2 / δ)) ≤ (s : ℝ) :=
      (Nat.le_ceil _).trans (by exact_mod_cast hs)
    simpa [L, hd_cast] using hceil
  let u : ℝ := α * (s : ℝ)
  have hu_ge : (64 : ℝ) * L ≤ u := by
    have hmul := mul_le_mul_of_nonneg_left hs_real hα0.le
    have hsimp : α * ((64 : ℝ) * α⁻¹ * L) = (64 : ℝ) * L := by
      field_simp [hα0.ne']
    linarith
  have hαs_ge8 : 8 ≤ α * (s : ℝ) := by
    change 8 ≤ u
    linarith
  have hDs_le : D + 1 ≤ 2 * s := by
    have hu_le_s : u ≤ (s : ℝ) := by
      have hs_nonneg : (0 : ℝ) ≤ (s : ℝ) := Nat.cast_nonneg s
      nlinarith
    have hd_le_2s_real : (d : ℝ) ≤ 2 * (s : ℝ) := by
      have h1 : (d : ℝ) * (1 / 2 : ℝ) ≤ (d : ℝ) * Real.log 2 := by nlinarith
      linarith
    have hd_le_2s_cast : ((D + 1 : ℕ) : ℝ) ≤ ((2 * s : ℕ) : ℝ) := by
      simpa [d, Nat.cast_add, Nat.cast_mul] using hd_le_2s_real
    exact Nat.cast_le.mp hd_le_2s_cast
  refine ⟨hαs_ge8, hDs_le, ?_⟩
  let k : ℕ := Nat.ceil (u / 2)
  have hk_ge : u / 2 ≤ (k : ℝ) := Nat.le_ceil (u / 2)
  have hu_pos : (0 : ℝ) < u := by linarith
  have hs_pos : (0 : ℝ) < (s : ℝ) := by
    by_contra h_not
    have hs0 : (s : ℝ) ≤ 0 := not_lt.mp h_not
    have : u ≤ 0 := mul_nonpos_of_nonneg_of_nonpos hα0.le hs0
    linarith
  -- Bound u / d via add_one_le_exp applied to u / (8 * d) - 1:
  have hexp_ud : u / (d : ℝ) ≤ 8 * Real.exp (u / (8 * (d : ℝ)) - 1) := by
    have h1 : u / (8 * (d : ℝ)) ≤ Real.exp (u / (8 * (d : ℝ)) - 1) := by
      have h := Real.add_one_le_exp (u / (8 * (d : ℝ)) - 1)
      linarith
    have h8 : u / (d : ℝ) = 8 * (u / (8 * (d : ℝ))) := by ring
    linarith
  have h8_exp : (8 : ℝ) = Real.exp (3 * Real.log 2) := by
    have h2 : Real.exp (Real.log 2) = 2 := Real.exp_log (by norm_num)
    calc (8 : ℝ) = (2 : ℝ) ^ (3 : ℕ) := by norm_num
      _ = (Real.exp (Real.log 2)) ^ (3 : ℕ) := by rw [h2]
      _ = Real.exp ((3 : ℕ) * Real.log 2) := (Real.exp_nat_mul (Real.log 2) 3).symm
      _ = Real.exp (3 * Real.log 2) := by norm_num
  have h_base_le :
      Real.exp 1 * (2 * (s : ℝ)) / (d : ℝ) ≤
        Real.exp (Real.log (2 / α) + 3 * Real.log 2 + u / (8 * (d : ℝ))) := by
    have h_rewrite :
        Real.exp 1 * (2 * (s : ℝ)) / (d : ℝ) =
          (2 / α) * (Real.exp 1 * (u / (d : ℝ))) := by
      simp only [u]
      field_simp [hα0.ne', hd_pos.ne']
    rw [h_rewrite]
    have h_step1 :
        (2 / α) * (Real.exp 1 * (u / (d : ℝ))) ≤
          (2 / α) * (Real.exp 1 * (8 * Real.exp (u / (8 * (d : ℝ)) - 1))) := by
      gcongr
    have h_step2 :
        (2 / α) * (Real.exp 1 * (8 * Real.exp (u / (8 * (d : ℝ)) - 1))) =
          Real.exp (Real.log (2 / α) + 3 * Real.log 2 + u / (8 * (d : ℝ))) := by
      calc (2 / α) * (Real.exp 1 * (8 * Real.exp (u / (8 * (d : ℝ)) - 1)))
          = Real.exp (Real.log (2 / α)) *
              (Real.exp 1 * (Real.exp (3 * Real.log 2) * Real.exp (u / (8 * (d : ℝ)) - 1))) := by
            rw [Real.exp_log h2α_pos, ← h8_exp]
        _ = Real.exp (Real.log (2 / α) + (1 + (3 * Real.log 2 + (u / (8 * (d : ℝ)) - 1)))) := by
            simp only [Real.exp_add]
        _ = Real.exp (Real.log (2 / α) + 3 * Real.log 2 + u / (8 * (d : ℝ))) := by
            congr 1; ring
    exact h_step1.trans_eq h_step2
  have h_pow_le :
      (Real.exp 1 * (2 * (s : ℝ)) / (d : ℝ)) ^ d ≤
        Real.exp ((d : ℝ) * Real.log (2 / α) + 3 * (d : ℝ) * Real.log 2 + u / 8) := by
    have h_nonneg : (0 : ℝ) ≤ Real.exp 1 * (2 * (s : ℝ)) / (d : ℝ) := by positivity
    calc (Real.exp 1 * (2 * (s : ℝ)) / (d : ℝ)) ^ d
        ≤ (Real.exp (Real.log (2 / α) + 3 * Real.log 2 + u / (8 * (d : ℝ)))) ^ d :=
          pow_le_pow_left₀ h_nonneg h_base_le d
      _ = Real.exp ((d : ℝ) * (Real.log (2 / α) + 3 * Real.log 2 + u / (8 * (d : ℝ)))) :=
          (Real.exp_nat_mul _ d).symm
      _ = Real.exp ((d : ℝ) * Real.log (2 / α) + 3 * (d : ℝ) * Real.log 2 + u / 8) := by
          congr 1
          field_simp [hd_pos.ne']
  have h_exp_ineq :
      Real.log (2 / δ) + ((d : ℝ) * Real.log (2 / α) + 3 * (d : ℝ) * Real.log 2 + u / 8) ≤
        (k : ℝ) * Real.log 2 := by
    have h_lhs_le :
        Real.log (2 / δ) + ((d : ℝ) * Real.log (2 / α) + 3 * (d : ℝ) * Real.log 2 + u / 8) ≤
          4 * L + u / 8 := by
      have h1 : (d : ℝ) * Real.log 2 ≤ (d : ℝ) * Real.log (2 / α) :=
        mul_le_mul_of_nonneg_left hlog2α hd_pos.le
      have hlog2δ_pos : 0 < Real.log (2 / δ) := lt_trans hlog2_pos hlog2δ
      simp only [L]
      linarith
    have h_rhs_ge : u / 4 ≤ (k : ℝ) * Real.log 2 := by
      have hk_pos : (0 : ℝ) ≤ (k : ℝ) := Nat.cast_nonneg k
      nlinarith
    linarith
  have h_prod_le :
      (2 / δ) * ((Real.exp 1 * (2 * (s : ℝ)) / (d : ℝ)) ^ d) ≤ (2 : ℝ) ^ k := by
    calc (2 / δ) * ((Real.exp 1 * (2 * (s : ℝ)) / (d : ℝ)) ^ d)
        ≤ (2 / δ) * Real.exp ((d : ℝ) * Real.log (2 / α) + 3 * (d : ℝ) * Real.log 2 + u / 8) :=
          mul_le_mul_of_nonneg_left h_pow_le h2δ_pos.le
      _ = Real.exp (Real.log (2 / δ)) *
            Real.exp ((d : ℝ) * Real.log (2 / α) + 3 * (d : ℝ) * Real.log 2 + u / 8) := by
          rw [Real.exp_log h2δ_pos]
      _ = Real.exp (Real.log (2 / δ) +
            ((d : ℝ) * Real.log (2 / α) + 3 * (d : ℝ) * Real.log 2 + u / 8)) :=
          (Real.exp_add _ _).symm
      _ ≤ Real.exp ((k : ℝ) * Real.log 2) := Real.exp_le_exp.mpr h_exp_ineq
      _ = (Real.exp (Real.log 2)) ^ k := Real.exp_nat_mul (Real.log 2) k
      _ = (2 : ℝ) ^ k := by rw [Real.exp_log (by norm_num)]
  have h2k_pos : (0 : ℝ) < (2 : ℝ) ^ k := by positivity
  rw [div_le_iff₀ h2k_pos]
  have h_mul := mul_le_mul_of_nonneg_left h_prod_le hδ0.le
  have h_lhs_eq :
      δ * ((2 / δ) * (Real.exp 1 * (2 * (s : ℝ)) / (d : ℝ)) ^ d) =
        2 * (Real.exp 1 * (2 * (s : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) := by
    rw [hd_cast]
    change δ * ((2 / δ) * (Real.exp 1 * (2 * (s : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1)) = _
    field_simp [hδ0.ne']
  change 2 * (Real.exp 1 * (2 * (s : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) ≤ δ * (2 : ℝ) ^ k
  linarith

end UL.Proof_cit_hw87_halfspace_net
