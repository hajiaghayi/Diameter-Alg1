import Mathlib
import UL.Def.def_A_halfspace_net
set_option autoImplicit false

namespace UL.Proof_cit_hw87_halfspace_net

private theorem convex_of_isClosedHalfspace {D : ℕ}
    {H : Set (EuclideanSpace ℝ (Fin D))} (hH : UL.IsClosedHalfspace H) :
    Convex ℝ H := by
  rcases hH with ⟨v, _, β, rfl⟩
  intro x hx y hy a b ha hb hab
  simp only [Set.mem_setOf_eq] at hx hy ⊢
  rw [inner_add_right, inner_smul_right, inner_smul_right]
  have hax : a * inner ℝ v x ≤ a * β := mul_le_mul_of_nonneg_left hx ha
  have hby : b * inner ℝ v y ≤ b * β := mul_le_mul_of_nonneg_left hy hb
  have habβ : a * β + b * β = β := by rw [← add_mul, hab, one_mul]
  linarith

private theorem convex_compl_of_isClosedHalfspace {D : ℕ}
    {H : Set (EuclideanSpace ℝ (Fin D))} (hH : UL.IsClosedHalfspace H) :
    Convex ℝ Hᶜ := by
  rcases hH with ⟨v, _, β, rfl⟩
  intro x hx y hy a b ha hb hab
  simp only [Set.mem_compl_iff, Set.mem_setOf_eq, not_le] at hx hy ⊢
  rw [inner_add_right, inner_smul_right, inner_smul_right]
  rcases ha.eq_or_lt with rfl | ha_pos
  · simp only [zero_add] at hab
    subst hab
    linarith
  · have hax : a * β < a * inner ℝ v x := mul_lt_mul_of_pos_left hx ha_pos
    have hby : b * β ≤ b * inner ℝ v y := mul_le_mul_of_nonneg_left hy.le hb
    have habβ : a * β + b * β = β := by rw [← add_mul, hab, one_mul]
    linarith

private theorem sum_choose_Iic_le {d m : ℕ} (hd : 1 ≤ d) (hdm : d ≤ m) :
    (∑ i ∈ Finset.Iic d, (m.choose i : ℝ)) ≤
      (Real.exp 1 * (m : ℝ) / (d : ℝ)) ^ d := by
  have hd_pos : (0 : ℝ) < (d : ℝ) := by exact_mod_cast (show 0 < d by omega)
  have hm_pos : (0 : ℝ) < (m : ℝ) := by exact_mod_cast (show 0 < m by omega)
  have hdm_real : (d : ℝ) ≤ (m : ℝ) := by exact_mod_cast hdm
  let x : ℝ := (d : ℝ) / (m : ℝ)
  have hx_pos : 0 < x := div_pos hd_pos hm_pos
  have hx_nonneg : 0 ≤ x := hx_pos.le
  have hx_le_one : x ≤ 1 := div_le_one_of_le₀ hdm_real hm_pos.le
  have hpow : ∀ {i k : ℕ}, i ≤ k → x ^ k ≤ x ^ i := by
    intro i k hik
    induction k, hik using Nat.le_induction with
    | base => exact le_rfl
    | succ k _ ih =>
      rw [pow_succ]
      calc
        x ^ k * x ≤ x ^ k * 1 := mul_le_mul_of_nonneg_left hx_le_one (pow_nonneg hx_nonneg k)
        _ = x ^ k := mul_one _
        _ ≤ x ^ i := ih
  have hxd_pos : 0 < x ^ d := pow_pos hx_pos d
  have h_sub : Finset.Iic d ⊆ Finset.range (m + 1) := by
    intro i hi
    simp only [Finset.mem_Iic, Finset.mem_range] at hi ⊢
    omega
  have h_mul :
      (∑ i ∈ Finset.Iic d, (m.choose i : ℝ)) * x ^ d ≤ (Real.exp 1) ^ d := by
    calc
      (∑ i ∈ Finset.Iic d, (m.choose i : ℝ)) * x ^ d
          = ∑ i ∈ Finset.Iic d, x ^ d * (m.choose i : ℝ) := by
            rw [Finset.sum_mul]
            refine Finset.sum_congr rfl fun i _ => ?_
            ring
      _ ≤ ∑ i ∈ Finset.Iic d, x ^ i * (m.choose i : ℝ) := by
            refine Finset.sum_le_sum fun i hi => ?_
            exact mul_le_mul_of_nonneg_right (hpow (Finset.mem_Iic.mp hi)) (Nat.cast_nonneg _)
      _ ≤ ∑ i ∈ Finset.range (m + 1), x ^ i * (m.choose i : ℝ) := by
            exact Finset.sum_mono_set_of_nonneg
              (fun i => mul_nonneg (pow_nonneg hx_nonneg i) (Nat.cast_nonneg _)) h_sub
      _ = (x + 1) ^ m := by
            rw [add_pow x 1 m]
            refine Finset.sum_congr rfl fun i _ => ?_
            simp
      _ ≤ (Real.exp x) ^ m := by
            gcongr
            exact Real.add_one_le_exp x
      _ = Real.exp ((m : ℝ) * x) := (Real.exp_nat_mul x m).symm
      _ = Real.exp ((d : ℝ) * 1) := by
            congr 1
            dsimp [x]
            field_simp [hm_pos.ne']
      _ = (Real.exp 1) ^ d := Real.exp_nat_mul 1 d
  have h_div : (∑ i ∈ Finset.Iic d, (m.choose i : ℝ)) ≤ (Real.exp 1) ^ d / x ^ d :=
    (le_div_iff₀ hxd_pos).mpr h_mul
  refine h_div.trans_eq ?_
  rw [← div_pow]
  congr 1
  dsimp [x]
  rw [div_div_eq_mul_div]

open Classical in
theorem card_halfspace_traces_le
    {D : ℕ} {U : Type*} [Fintype U]
    (Q : U → EuclideanSpace ℝ (Fin D))
    (ℬ : Finset (Finset U))
    (hℬ : ∀ B ∈ ℬ, ∃ H : Set (EuclideanSpace ℝ (Fin D)),
      UL.IsClosedHalfspace H ∧ B = Finset.univ.filter (fun u : U => Q u ∈ H))
    (hm : D + 1 ≤ Fintype.card U) :
    (ℬ.card : ℝ) ≤ (Real.exp 1 * (Fintype.card U : ℝ) / ((D : ℝ) + 1)) ^ (D + 1) := by
  have h_shatter : ∀ S : Finset U, ℬ.Shatters S → S.card ≤ D + 1 := by
    intro S hS
    let f : S → EuclideanSpace ℝ (Fin D) := fun x => Q x.1
    by_cases hf : AffineIndependent ℝ f
    · have hcard : Fintype.card S ≤ Module.finrank ℝ (vectorSpan ℝ (Set.range f)) + 1 :=
        hf.card_le_finrank_succ
      have hsub : Module.finrank ℝ (vectorSpan ℝ (Set.range f)) ≤
          Module.finrank ℝ (EuclideanSpace ℝ (Fin D)) :=
        Submodule.finrank_le _
      have hdim : Module.finrank ℝ (EuclideanSpace ℝ (Fin D)) = D :=
        finrank_euclideanSpace_fin
      rw [Fintype.card_coe] at hcard
      omega
    · exfalso
      obtain ⟨I, z, hzI, hzIc⟩ := Convex.radon_partition hf
      let T : Finset U := S.filter (fun u => ∃ hu : u ∈ S, (⟨u, hu⟩ : S) ∈ I)
      obtain ⟨B, hB_mem, hSB⟩ := hS (Finset.filter_subset _ S : T ⊆ S)
      obtain ⟨H, hH_closed, hB_eq⟩ := hℬ B hB_mem
      have hx_iff : ∀ x : S, f x ∈ H ↔ x ∈ I := by
        intro x
        have hx_mem_S : x.1 ∈ S := x.2
        have h1 : f x ∈ H ↔ x.1 ∈ B := by
          rw [hB_eq]
          simp [f]
        have h2 : x.1 ∈ B ↔ x.1 ∈ S ∩ B := by
          simp [hx_mem_S]
        have h3 : x.1 ∈ S ∩ B ↔ x ∈ I := by
          rw [hSB]
          simp [hx_mem_S]
        exact h1.trans (h2.trans h3)
      have hzH : z ∈ H := by
        refine convexHull_min ?_ (convex_of_isClosedHalfspace hH_closed) hzI
        rintro y ⟨x, hxI, rfl⟩
        exact (hx_iff x).mpr hxI
      have hzHc : z ∈ Hᶜ := by
        refine convexHull_min ?_ (convex_compl_of_isClosedHalfspace hH_closed) hzIc
        rintro y ⟨x, hxIc, rfl⟩
        change f x ∉ H
        exact mt (hx_iff x).mp hxIc
      exact hzHc hzH
  have h_vcdim : ℬ.vcDim ≤ D + 1 := by
    unfold Finset.vcDim
    refine Finset.sup_le fun S hS => ?_
    exact h_shatter S (Finset.mem_shatterer.mp hS)
  have h_card_nat : ℬ.card ≤ ∑ i ∈ Finset.Iic (D + 1), (Fintype.card U).choose i := by
    calc
      ℬ.card ≤ ℬ.shatterer.card := Finset.card_le_card_shatterer ℬ
      _ ≤ ∑ i ∈ Finset.Iic ℬ.vcDim, (Fintype.card U).choose i :=
          Finset.card_shatterer_le_sum_vcDim
      _ ≤ ∑ i ∈ Finset.Iic (D + 1), (Fintype.card U).choose i :=
          Finset.sum_mono_set_of_nonneg (fun _ => Nat.zero_le _)
            (Finset.Iic_subset_Iic.mpr h_vcdim)
  have h_card_real : (ℬ.card : ℝ) ≤ ∑ i ∈ Finset.Iic (D + 1), ((Fintype.card U).choose i : ℝ) := by
    exact_mod_cast h_card_nat
  refine h_card_real.trans ?_
  simpa [Nat.cast_add, Nat.cast_one] using
    sum_choose_Iic_le (d := D + 1) (m := Fintype.card U) (by omega) hm

end UL.Proof_cit_hw87_halfspace_net
