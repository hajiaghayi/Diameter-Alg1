import Mathlib
set_option autoImplicit false

namespace UL.Proof_cit_hw87_halfspace_net

private def consEquivConst (ι : Type*) (s : ℕ) : (ι × (Fin s → ι)) ≃ (Fin (s + 1) → ι) where
  toFun p := Fin.cons p.1 p.2
  invFun f := (f 0, fun j => f j.succ)
  left_inv p := by
    rcases p with ⟨a, y⟩
    simp
  right_inv f := by
    funext j
    refine Fin.cases ?_ ?_ j
    · simp
    · intro i
      simp

open Classical in
private noncomputable def hitCount {ι : Type*} (A : Finset ι) (s : ℕ) (y : Fin s → ι) : ℕ :=
  (Finset.univ.filter (fun j : Fin s => y j ∈ A)).card

open Classical in
private lemma hitCount_cons {ι : Type*} (A : Finset ι) (s : ℕ) (a : ι) (y : Fin s → ι) :
    (hitCount A (s + 1) (Fin.cons a y) : ℝ) =
      (if a ∈ A then (1 : ℝ) else 0) + (hitCount A s y : ℝ) := by
  have hnat : hitCount A (s + 1) (Fin.cons a y) =
      (if a ∈ A then 1 else 0) + hitCount A s y := by
    rw [hitCount, hitCount, Finset.card_filter, Finset.card_filter, Fin.sum_univ_succ]
    simp
  rw [hnat]
  split_ifs <;> push_cast <;> ring

open Classical in
private lemma sum_univ_ite_mem {ι : Type*} [Fintype ι] (A : Finset ι) :
    (∑ a : ι, (if a ∈ A then (1 : ℝ) else 0)) = (A.card : ℝ) := by
  have hfilter : Finset.univ.filter (fun a : ι => a ∈ A) = A := by
    ext a
    simp
  have hnat : (∑ a : ι, (if a ∈ A then (1 : ℕ) else 0)) = A.card := by
    rw [← Finset.card_filter, hfilter]
  have hcast : (∑ a : ι, (if a ∈ A then (1 : ℝ) else 0)) =
      ((∑ a : ι, (if a ∈ A then (1 : ℕ) else 0) : ℕ) : ℝ) := by
    push_cast
    refine Finset.sum_congr rfl fun a _ => ?_
    split_ifs <;> rfl
  rw [hcast, hnat]

open Classical in
private lemma sum_indicator_sub {ι : Type*} [Fintype ι] [Nonempty ι] (A : Finset ι) :
    (∑ a : ι, ((if a ∈ A then (1 : ℝ) else 0) - (A.card : ℝ) / (Fintype.card ι : ℝ))) = 0 := by
  have hn : (Fintype.card ι : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  rw [Finset.sum_sub_distrib, sum_univ_ite_mem, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  field_simp [hn]
  ring

open Classical in
private lemma sum_indicator_sub_sq {ι : Type*} [Fintype ι] [Nonempty ι] (A : Finset ι) :
    let p : ℝ := (A.card : ℝ) / (Fintype.card ι : ℝ)
    (∑ a : ι, ((if a ∈ A then (1 : ℝ) else 0) - p) ^ 2) =
      (Fintype.card ι : ℝ) * p * (1 - p) := by
  intro p
  have hn : (Fintype.card ι : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have hpt : ∀ a : ι, ((if a ∈ A then (1 : ℝ) else 0) - p) ^ 2 =
      (if a ∈ A then (1 : ℝ) else 0) * (1 - 2 * p) + p ^ 2 := by
    intro a
    split_ifs <;> ring
  simp_rw [hpt]
  rw [Finset.sum_add_distrib, ← Finset.sum_mul, sum_univ_ite_mem,
      Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  have hAp : (A.card : ℝ) = (Fintype.card ι : ℝ) * p := by
    dsimp [p]
    field_simp [hn]
  rw [hAp]
  ring

open Classical in
private lemma hitCount_mean {ι : Type*} [Fintype ι] [Nonempty ι] (A : Finset ι) :
    ∀ s : ℕ,
      let p : ℝ := (A.card : ℝ) / (Fintype.card ι : ℝ)
      (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p)) = 0
  | 0 => by
      intro p
      simp [hitCount]
  | s + 1 => by
      intro p
      have ih : (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p)) = 0 := hitCount_mean A s
      rw [← Equiv.sum_comp (consEquivConst ι s)]
      rw [Fintype.sum_prod_type]
      have hstep : ∀ a : ι, ∀ y : Fin s → ι,
          (hitCount A (s + 1) (consEquivConst ι s (a, y)) : ℝ) - ((s + 1 : ℕ) : ℝ) * p =
            ((if a ∈ A then (1 : ℝ) else 0) - p) + ((hitCount A s y : ℝ) - (s : ℝ) * p) := by
        intro a y
        change (hitCount A (s + 1) (Fin.cons a y) : ℝ) - ((s + 1 : ℕ) : ℝ) * p = _
        rw [hitCount_cons]
        push_cast
        ring
      have hinner : ∀ a : ι,
          (∑ y : Fin s → ι,
            ((hitCount A (s + 1) (consEquivConst ι s (a, y)) : ℝ) - ((s + 1 : ℕ) : ℝ) * p)) =
            (Fintype.card (Fin s → ι) : ℝ) * ((if a ∈ A then (1 : ℝ) else 0) - p) := by
        intro a
        simp_rw [hstep a]
        rw [Finset.sum_add_distrib, ih, add_zero, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
      simp_rw [hinner]
      rw [← Finset.mul_sum]
      have h0 : (∑ x : ι, ((if x ∈ A then (1 : ℝ) else 0) - p)) = 0 := sum_indicator_sub A
      rw [h0, mul_zero]

open Classical in
private lemma hitCount_variance {ι : Type*} [Fintype ι] [Nonempty ι] (A : Finset ι) :
    ∀ s : ℕ,
      let p : ℝ := (A.card : ℝ) / (Fintype.card ι : ℝ)
      (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p) ^ 2) =
        ((Fintype.card ι : ℝ) ^ s) * ((s : ℝ) * p * (1 - p))
  | 0 => by
      intro p
      simp [hitCount]
  | s + 1 => by
      intro p
      have ih : (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p) ^ 2) =
          ((Fintype.card ι : ℝ) ^ s) * ((s : ℝ) * p * (1 - p)) := hitCount_variance A s
      have hmean : (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p)) = 0 := hitCount_mean A s
      rw [← Equiv.sum_comp (consEquivConst ι s)]
      rw [Fintype.sum_prod_type]
      have hcard_fun : (Fintype.card (Fin s → ι) : ℝ) = (Fintype.card ι : ℝ) ^ s := by
        have hc : Fintype.card (Fin s → ι) = (Fintype.card ι) ^ s := by
          rw [Fintype.card_fun, Fintype.card_fin]
        exact_mod_cast hc
      have hinner : ∀ a : ι,
          (∑ y : Fin s → ι,
            ((hitCount A (s + 1) (consEquivConst ι s (a, y)) : ℝ) - ((s + 1 : ℕ) : ℝ) * p) ^ 2) =
            ((Fintype.card ι : ℝ) ^ s) * (((if a ∈ A then (1 : ℝ) else 0) - p) ^ 2) +
              ((Fintype.card ι : ℝ) ^ s) * ((s : ℝ) * p * (1 - p)) := by
        intro a
        set Ia : ℝ := (if a ∈ A then (1 : ℝ) else 0) - p
        have hsq : ∀ y : Fin s → ι,
            ((hitCount A (s + 1) (consEquivConst ι s (a, y)) : ℝ) - ((s + 1 : ℕ) : ℝ) * p) ^ 2 =
              Ia ^ 2 + 2 * Ia * ((hitCount A s y : ℝ) - (s : ℝ) * p) +
                ((hitCount A s y : ℝ) - (s : ℝ) * p) ^ 2 := by
          intro y
          change ((hitCount A (s + 1) (Fin.cons a y) : ℝ) - ((s + 1 : ℕ) : ℝ) * p) ^ 2 = _
          rw [hitCount_cons]
          dsimp [Ia]
          push_cast
          ring
        simp_rw [hsq]
        rw [Finset.sum_add_distrib, Finset.sum_add_distrib, ← Finset.mul_sum, hmean,
            mul_zero, add_zero, Finset.sum_const, Finset.card_univ, nsmul_eq_mul,
            hcard_fun, ih]
      simp_rw [hinner]
      rw [Finset.sum_add_distrib, ← Finset.mul_sum, Finset.sum_const,
          Finset.card_univ, nsmul_eq_mul]
      have hsq_a : (∑ i : ι, ((if i ∈ A then (1 : ℝ) else 0) - p) ^ 2) =
          (Fintype.card ι : ℝ) * p * (1 - p) := sum_indicator_sub_sq A
      rw [hsq_a]
      push_cast
      ring

open Classical in
private lemma ghost_high_bound
    {ι : Type*} [Fintype ι] [Nonempty ι]
    (A : Finset ι) (α : ℝ) (s : ℕ)
    (hαs : 8 ≤ α * (s : ℝ))
    (hA : α * (Fintype.card ι : ℝ) ≤ (A.card : ℝ)) :
    (Fintype.card (Fin s → ι) : ℝ) / 2 ≤
      ((Finset.univ.filter (fun y : Fin s → ι =>
        Nat.ceil (α * (s : ℝ) / 2) ≤ hitCount A s y)).card : ℝ) := by
  set n : ℕ := Fintype.card ι
  set N : ℕ := Fintype.card (Fin s → ι)
  set p : ℝ := (A.card : ℝ) / (n : ℝ)
  set k : ℕ := Nat.ceil (α * (s : ℝ) / 2)
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have hA_le : (A.card : ℝ) ≤ (n : ℝ) := by exact_mod_cast Finset.card_le_univ A
  have hp_nonneg : 0 ≤ p := div_nonneg (Nat.cast_nonneg _) (le_of_lt hn_pos)
  have hp_le_one : p ≤ 1 := (div_le_one hn_pos).mpr hA_le
  have hα_le_p : α ≤ p := (le_div_iff₀ hn_pos).mpr hA
  have hαs_le_sp : α * (s : ℝ) ≤ (s : ℝ) * p := by
    have h1 := mul_le_mul_of_nonneg_right hα_le_p (Nat.cast_nonneg s)
    linarith
  have hsp8 : 8 ≤ (s : ℝ) * p := le_trans hαs hαs_le_sp
  have hsp_pos : 0 < (s : ℝ) * p := by linarith
  have hN_eq : (N : ℝ) = (n : ℝ) ^ s := by
    have hc : N = n ^ s := by
      dsimp [N, n]
      rw [Fintype.card_fun, Fintype.card_fin]
    exact_mod_cast hc
  have hvar_le : (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p) ^ 2) ≤
      (N : ℝ) * ((s : ℝ) * p) := by
    rw [hitCount_variance A s]
    change ((n : ℝ) ^ s) * ((s : ℝ) * p * (1 - p)) ≤ (N : ℝ) * ((s : ℝ) * p)
    rw [← hN_eq]
    have hN_nonneg : 0 ≤ (N : ℝ) := Nat.cast_nonneg N
    have h1p : 1 - p ≤ 1 := by linarith
    calc (N : ℝ) * ((s : ℝ) * p * (1 - p))
        = ((N : ℝ) * ((s : ℝ) * p)) * (1 - p) := by ring
      _ ≤ ((N : ℝ) * ((s : ℝ) * p)) * 1 :=
          mul_le_mul_of_nonneg_left h1p (mul_nonneg hN_nonneg (le_of_lt hsp_pos))
      _ = (N : ℝ) * ((s : ℝ) * p) := mul_one _
  set High : Finset (Fin s → ι) := Finset.univ.filter (fun y : Fin s → ι => k ≤ hitCount A s y)
  set Low : Finset (Fin s → ι) := Finset.univ.filter (fun y : Fin s → ι => ¬ (k ≤ hitCount A s y))
  have hcard_sum : (High.card : ℝ) + (Low.card : ℝ) = (N : ℝ) := by
    have hnat : High.card + Low.card = N := by
      dsimp [High, Low, N]
      rw [Finset.card_filter_add_card_filter_not, Finset.card_univ]
    exact_mod_cast hnat
  have hlow_pt : ∀ y ∈ Low, (((s : ℝ) * p) ^ 2 / 4) ≤ ((hitCount A s y : ℝ) - (s : ℝ) * p) ^ 2 := by
    intro y hy
    have hnot : ¬ (k ≤ hitCount A s y) := (Finset.mem_filter.mp hy).2
    have hlt : (hitCount A s y : ℝ) < α * (s : ℝ) / 2 := by
      rw [Nat.ceil_le] at hnot
      linarith
    nlinarith
  have hlow_sum : (Low.card : ℝ) * (((s : ℝ) * p) ^ 2 / 4) ≤ (N : ℝ) * ((s : ℝ) * p) := by
    calc (Low.card : ℝ) * (((s : ℝ) * p) ^ 2 / 4)
        = ∑ _y ∈ Low, (((s : ℝ) * p) ^ 2 / 4) := by
          rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ ∑ y ∈ Low, ((hitCount A s y : ℝ) - (s : ℝ) * p) ^ 2 := Finset.sum_le_sum hlow_pt
      _ ≤ ∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p) ^ 2 :=
          Finset.sum_le_univ_sum_of_nonneg (fun _ => sq_nonneg _)
      _ ≤ (N : ℝ) * ((s : ℝ) * p) := hvar_le
  have hlow_quarter : (Low.card : ℝ) * (((s : ℝ) * p) / 4) ≤ (N : ℝ) := by
    refine le_of_mul_le_mul_right ?_ hsp_pos
    calc ((Low.card : ℝ) * (((s : ℝ) * p) / 4)) * ((s : ℝ) * p)
        = (Low.card : ℝ) * (((s : ℝ) * p) ^ 2 / 4) := by ring
      _ ≤ (N : ℝ) * ((s : ℝ) * p) := hlow_sum
  have hlow_le : 2 * (Low.card : ℝ) ≤ (N : ℝ) := by
    have hL_nonneg : 0 ≤ (Low.card : ℝ) := Nat.cast_nonneg _
    nlinarith
  linarith

open Classical in
private noncomputable def goodSwap (s k : ℕ) (B : Finset (Fin s ⊕ Fin s)) : Finset (Fin s → Bool) :=
  Finset.univ.filter (fun σ : Fin s → Bool =>
    (∀ j : Fin s, (if σ j then Sum.inr j else Sum.inl j) ∉ B) ∧
    k ≤ (Finset.univ.filter (fun j : Fin s => (if σ j then Sum.inl j else Sum.inr j) ∈ B)).card)

open Classical in
private lemma goodSwap_card_bound (s k : ℕ) (B : Finset (Fin s ⊕ Fin s)) :
    (goodSwap s k B).card * 2 ^ k ≤ 2 ^ s := by
  rcases (goodSwap s k B).eq_empty_or_nonempty with h_empty | ⟨σ₀, hσ₀⟩
  · simp [h_empty]
  · rcases (Finset.mem_filter.mp hσ₀).2 with ⟨_, h0_in⟩
    set J : Finset (Fin s) :=
      Finset.univ.filter (fun j : Fin s => (if σ₀ j then Sum.inl j else Sum.inr j) ∈ B)
    have h_agree : ∀ σ ∈ goodSwap s k B, ∀ j ∈ J, σ j = σ₀ j := by
      intro σ hσ j hj
      have hσ_out := (Finset.mem_filter.mp hσ).2.1 j
      have hjB := (Finset.mem_filter.mp hj).2
      cases h0 : σ₀ j <;> cases h1 : σ j <;> simp_all
    let restrict : (Fin s → Bool) → (↥(Finset.univ \ J) → Bool) := fun σ j => σ j.1
    have h_inj : Set.InjOn restrict (goodSwap s k B) := by
      intro σ₁ hσ₁ σ₂ hσ₂ h_eq
      funext j
      by_cases hj : j ∈ J
      · rw [h_agree σ₁ hσ₁ j hj, h_agree σ₂ hσ₂ j hj]
      · exact congr_fun h_eq ⟨j, Finset.mem_sdiff.mpr ⟨Finset.mem_univ j, hj⟩⟩
    have hcard_le : (goodSwap s k B).card ≤ 2 ^ (Finset.univ \ J).card := by
      calc (goodSwap s k B).card
          = ((goodSwap s k B).image restrict).card := (Finset.card_image_of_injOn h_inj).symm
        _ ≤ (Finset.univ : Finset (↥(Finset.univ \ J) → Bool)).card := Finset.card_le_univ _
        _ = 2 ^ (Finset.univ \ J).card := by
            rw [Finset.card_univ, Fintype.card_fun, Fintype.card_bool, Fintype.card_coe]
    have hmJ : (Finset.univ \ J).card + J.card = s := by
      have h := Finset.card_sdiff_add_card_eq_card (Finset.subset_univ J)
      rw [Finset.card_univ, Fintype.card_fin] at h
      exact h
    have hmk : (Finset.univ \ J).card + k ≤ s := by omega
    calc (goodSwap s k B).card * 2 ^ k
        ≤ 2 ^ (Finset.univ \ J).card * 2 ^ k := Nat.mul_le_mul_right _ hcard_le
      _ = 2 ^ ((Finset.univ \ J).card + k) := (Nat.pow_add 2 _ _).symm
      _ ≤ 2 ^ s := Nat.pow_le_pow_right (by norm_num) hmk

private def swapPair {ι : Type*} {s : ℕ} (σ : Fin s → Bool)
    (xy : (Fin s → ι) × (Fin s → ι)) : (Fin s → ι) × (Fin s → ι) :=
  (fun j => if σ j then xy.2 j else xy.1 j,
   fun j => if σ j then xy.1 j else xy.2 j)

private def swapPairEquiv {ι : Type*} {s : ℕ} (σ : Fin s → Bool) :
    ((Fin s → ι) × (Fin s → ι)) ≃ ((Fin s → ι) × (Fin s → ι)) where
  toFun := swapPair σ
  invFun := swapPair σ
  left_inv xy := by
    rcases xy with ⟨x, y⟩
    exact Prod.ext (funext fun j => by dsimp [swapPair]; cases σ j <;> rfl)
      (funext fun j => by dsimp [swapPair]; cases σ j <;> rfl)
  right_inv xy := by
    rcases xy with ⟨x, y⟩
    exact Prod.ext (funext fun j => by dsimp [swapPair]; cases σ j <;> rfl)
      (funext fun j => by dsimp [swapPair]; cases σ j <;> rfl)

open Classical in
theorem double_sampling_bad_bound
    {ι : Type*} [Fintype ι] [Nonempty ι]
    (𝒜 : Finset (Finset ι)) (α : ℝ) (s : ℕ) (M : ℝ)
    (hαs : 8 ≤ α * (s : ℝ))
    (hM : ∀ xy : (Fin s → ι) × (Fin s → ι),
      ((𝒜.image (fun A : Finset ι =>
        Finset.univ.filter (fun u : Fin s ⊕ Fin s => Sum.elim xy.1 xy.2 u ∈ A))).card : ℝ) ≤ M) :
    ((Finset.univ.filter (fun x : Fin s → ι =>
        ∃ A ∈ 𝒜, α * (Fintype.card ι : ℝ) ≤ (A.card : ℝ) ∧ ∀ j : Fin s, x j ∉ A)).card : ℝ) /
      (Fintype.card (Fin s → ι) : ℝ)
      ≤ 2 * M / ((2 : ℝ) ^ Nat.ceil (α * (s : ℝ) / 2)) := by
  set N : ℕ := Fintype.card (Fin s → ι)
  set k : ℕ := Nat.ceil (α * (s : ℝ) / 2)
  set Bad₁ : Finset (Fin s → ι) := Finset.univ.filter (fun x : Fin s → ι =>
    ∃ A ∈ 𝒜, α * (Fintype.card ι : ℝ) ≤ (A.card : ℝ) ∧ ∀ j : Fin s, x j ∉ A)
  set Bad₂ : Finset ((Fin s → ι) × (Fin s → ι)) :=
    Finset.univ.filter (fun xy : (Fin s → ι) × (Fin s → ι) =>
      ∃ A ∈ 𝒜, (∀ j : Fin s, xy.1 j ∉ A) ∧ k ≤ hitCount A s xy.2)
  -- Step 3: Relate Bad₁ to Bad₂
  have hBad1_le_Bad2 : (Bad₁.card : ℝ) * (N : ℝ) ≤ 2 * (Bad₂.card : ℝ) := by
    have hBad2_fubini : (Bad₂.card : ℝ) =
        ∑ x : Fin s → ι, ((Finset.univ.filter (fun y : Fin s → ι => (x, y) ∈ Bad₂)).card : ℝ) := by
      have hnat : Bad₂.card =
          ∑ x : Fin s → ι, (Finset.univ.filter (fun y : Fin s → ι => (x, y) ∈ Bad₂)).card := by
        have h1 : Bad₂.card = ∑ xy : (Fin s → ι) × (Fin s → ι), (if xy ∈ Bad₂ then 1 else 0) := by
          have hf : Finset.univ.filter (fun xy => xy ∈ Bad₂) = Bad₂ := by
            ext xy
            simp
          rw [← Finset.card_filter, hf]
        rw [h1, Fintype.sum_prod_type]
        refine Finset.sum_congr rfl fun x _ => ?_
        rw [Finset.card_filter]
      exact_mod_cast hnat
    have hfiber : ∀ x ∈ Bad₁,
        (N : ℝ) / 2 ≤ ((Finset.univ.filter (fun y : Fin s → ι => (x, y) ∈ Bad₂)).card : ℝ) := by
      intro x hx
      rcases (Finset.mem_filter.mp hx).2 with ⟨A, hA_mem, hA_card, hA_disj⟩
      have hhigh := ghost_high_bound A α s hαs hA_card
      have hsub : Finset.univ.filter (fun y : Fin s → ι => k ≤ hitCount A s y) ⊆
          Finset.univ.filter (fun y : Fin s → ι => (x, y) ∈ Bad₂) := by
        intro y hy
        have hyk : k ≤ hitCount A s y := (Finset.mem_filter.mp hy).2
        refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
        exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, ⟨A, hA_mem, hA_disj, hyk⟩⟩
      have hle : ((Finset.univ.filter (fun y : Fin s → ι => k ≤ hitCount A s y)).card : ℝ) ≤
          ((Finset.univ.filter (fun y : Fin s → ι => (x, y) ∈ Bad₂)).card : ℝ) := by
        exact_mod_cast Finset.card_le_card hsub
      exact le_trans hhigh hle
    have hsum_le : (Bad₁.card : ℝ) * ((N : ℝ) / 2) ≤ (Bad₂.card : ℝ) := by
      rw [hBad2_fubini]
      calc (Bad₁.card : ℝ) * ((N : ℝ) / 2)
          = ∑ _x ∈ Bad₁, ((N : ℝ) / 2) := by rw [Finset.sum_const, nsmul_eq_mul]
        _ ≤ ∑ x ∈ Bad₁, ((Finset.univ.filter (fun y : Fin s → ι => (x, y) ∈ Bad₂)).card : ℝ) :=
            Finset.sum_le_sum hfiber
        _ ≤ ∑ x : Fin s → ι,
              ((Finset.univ.filter (fun y : Fin s → ι => (x, y) ∈ Bad₂)).card : ℝ) :=
            Finset.sum_le_univ_sum_of_nonneg (fun _ => Nat.cast_nonneg _)
    linarith
  -- Step 4 & 5: Symmetrization and trace bound for Bad₂
  let traceFamily (xy : (Fin s → ι) × (Fin s → ι)) : Finset (Finset (Fin s ⊕ Fin s)) :=
    𝒜.image (fun A : Finset ι =>
      Finset.univ.filter (fun u : Fin s ⊕ Fin s => Sum.elim xy.1 xy.2 u ∈ A))
  have h_symm : 2 ^ s * Bad₂.card =
      ∑ xy : (Fin s → ι) × (Fin s → ι),
        (Finset.univ.filter (fun σ : Fin s → Bool => swapPair σ xy ∈ Bad₂)).card := by
    have h1 : ∀ σ : Fin s → Bool,
        (∑ xy : (Fin s → ι) × (Fin s → ι), (if swapPair σ xy ∈ Bad₂ then 1 else 0)) =
          Bad₂.card := by
      intro σ
      have heq := Equiv.sum_comp (swapPairEquiv σ) (fun xy => if xy ∈ Bad₂ then (1 : ℕ) else 0)
      have hcard : (∑ xy : (Fin s → ι) × (Fin s → ι), (if xy ∈ Bad₂ then (1 : ℕ) else 0)) =
          Bad₂.card := by
        have hf : Finset.univ.filter (fun xy => xy ∈ Bad₂) = Bad₂ := by
          ext xy
          simp
        rw [← Finset.card_filter, hf]
      exact heq.trans hcard
    calc 2 ^ s * Bad₂.card
        = ∑ _σ : Fin s → Bool, Bad₂.card := by
            rw [Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_bool,
                Fintype.card_fin, smul_eq_mul]
      _ = ∑ σ : Fin s → Bool, ∑ xy : (Fin s → ι) × (Fin s → ι),
            (if swapPair σ xy ∈ Bad₂ then 1 else 0) :=
          Finset.sum_congr rfl fun σ _ => (h1 σ).symm
      _ = ∑ xy : (Fin s → ι) × (Fin s → ι), ∑ σ : Fin s → Bool,
            (if swapPair σ xy ∈ Bad₂ then 1 else 0) := Finset.sum_comm
      _ = ∑ xy : (Fin s → ι) × (Fin s → ι),
            (Finset.univ.filter (fun σ : Fin s → Bool => swapPair σ xy ∈ Bad₂)).card := by
          refine Finset.sum_congr rfl fun xy _ => ?_
          rw [Finset.card_filter]
  have h_xy_bound : ∀ xy : (Fin s → ι) × (Fin s → ι),
      (Finset.univ.filter (fun σ : Fin s → Bool => swapPair σ xy ∈ Bad₂)).card * 2 ^ k ≤
        (traceFamily xy).card * 2 ^ s := by
    intro xy
    have hsub : Finset.univ.filter (fun σ : Fin s → Bool => swapPair σ xy ∈ Bad₂) ⊆
        (traceFamily xy).biUnion (goodSwap s k) := by
      intro σ hσ
      rcases (Finset.mem_filter.mp (Finset.mem_filter.mp hσ).2).2 with ⟨A, hA_mem, h1, h2⟩
      set B : Finset (Fin s ⊕ Fin s) :=
        Finset.univ.filter (fun u : Fin s ⊕ Fin s => Sum.elim xy.1 xy.2 u ∈ A)
      have hB_mem : B ∈ traceFamily xy := Finset.mem_image_of_mem _ hA_mem
      refine Finset.mem_biUnion.mpr ⟨B, hB_mem, ?_⟩
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ⟨?_, ?_⟩⟩
      · intro j hjB
        have hjA : Sum.elim xy.1 xy.2 (if σ j then Sum.inr j else Sum.inl j) ∈ A :=
          (Finset.mem_filter.mp hjB).2
        have heq : Sum.elim xy.1 xy.2 (if σ j then Sum.inr j else Sum.inl j) =
            (swapPair σ xy).1 j := by
          dsimp [swapPair]
          cases σ j <;> rfl
        rw [heq] at hjA
        exact h1 j hjA
      · have hfeq : Finset.univ.filter (fun j : Fin s =>
            (if σ j then Sum.inl j else Sum.inr j) ∈ B) =
            Finset.univ.filter (fun j : Fin s => (swapPair σ xy).2 j ∈ A) := by
          ext j
          simp only [Finset.mem_filter, Finset.mem_univ, true_and, B]
          have heq : Sum.elim xy.1 xy.2 (if σ j then Sum.inl j else Sum.inr j) =
              (swapPair σ xy).2 j := by
            dsimp [swapPair]
            cases σ j <;> rfl
          rw [heq]
        rw [hfeq]
        exact h2
    have hbi : (Finset.univ.filter (fun σ : Fin s → Bool => swapPair σ xy ∈ Bad₂)).card ≤
        ∑ B ∈ traceFamily xy, (goodSwap s k B).card :=
      le_trans (Finset.card_le_card hsub) Finset.card_biUnion_le
    calc (Finset.univ.filter (fun σ : Fin s → Bool => swapPair σ xy ∈ Bad₂)).card * 2 ^ k
        ≤ (∑ B ∈ traceFamily xy, (goodSwap s k B).card) * 2 ^ k :=
          Nat.mul_le_mul_right _ hbi
      _ = ∑ B ∈ traceFamily xy, (goodSwap s k B).card * 2 ^ k := Finset.sum_mul _ _ _
      _ ≤ ∑ _B ∈ traceFamily xy, 2 ^ s :=
          Finset.sum_le_sum fun B _ => goodSwap_card_bound s k B
      _ = (traceFamily xy).card * 2 ^ s := by
          rw [Finset.sum_const, smul_eq_mul]
  have hBad2_nat : Bad₂.card * 2 ^ k ≤
      ∑ xy : (Fin s → ι) × (Fin s → ι), (traceFamily xy).card := by
    have h2s_pos : 0 < 2 ^ s := Nat.pow_pos (by norm_num)
    refine Nat.le_of_mul_le_mul_right ?_ h2s_pos
    calc (Bad₂.card * 2 ^ k) * 2 ^ s
        = (2 ^ s * Bad₂.card) * 2 ^ k := by ring
      _ = (∑ xy : (Fin s → ι) × (Fin s → ι),
            (Finset.univ.filter (fun σ : Fin s → Bool => swapPair σ xy ∈ Bad₂)).card) * 2 ^ k := by
          rw [h_symm]
      _ = ∑ xy : (Fin s → ι) × (Fin s → ι),
            (Finset.univ.filter (fun σ : Fin s → Bool => swapPair σ xy ∈ Bad₂)).card * 2 ^ k :=
          Finset.sum_mul _ _ _
      _ ≤ ∑ xy : (Fin s → ι) × (Fin s → ι), (traceFamily xy).card * 2 ^ s :=
          Finset.sum_le_sum fun xy _ => h_xy_bound xy
      _ = (∑ xy : (Fin s → ι) × (Fin s → ι), (traceFamily xy).card) * 2 ^ s :=
          (Finset.sum_mul _ _ _).symm
  have hBad2_real : (Bad₂.card : ℝ) * (2 : ℝ) ^ k ≤ (N : ℝ) * (N : ℝ) * M := by
    have hcast : (Bad₂.card : ℝ) * (2 : ℝ) ^ k ≤
        ∑ xy : (Fin s → ι) × (Fin s → ι), ((traceFamily xy).card : ℝ) := by
      exact_mod_cast hBad2_nat
    have hcard_prod : (Fintype.card ((Fin s → ι) × (Fin s → ι)) : ℝ) = (N : ℝ) * (N : ℝ) := by
      have hc : Fintype.card ((Fin s → ι) × (Fin s → ι)) = N * N := by
        dsimp [N]
        rw [Fintype.card_prod]
      exact_mod_cast hc
    calc (Bad₂.card : ℝ) * (2 : ℝ) ^ k
        ≤ ∑ xy : (Fin s → ι) × (Fin s → ι), ((traceFamily xy).card : ℝ) := hcast
      _ ≤ ∑ _xy : (Fin s → ι) × (Fin s → ι), M := Finset.sum_le_sum fun xy _ => hM xy
      _ = (Fintype.card ((Fin s → ι) × (Fin s → ι)) : ℝ) * M := by
          rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
      _ = (N : ℝ) * (N : ℝ) * M := by rw [hcard_prod]
  -- Combine Step 3 and Bad₂ bound
  have hN_pos : (0 : ℝ) < (N : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have h2k_pos : (0 : ℝ) < (2 : ℝ) ^ k := pow_pos (by norm_num) k
  rw [div_le_div_iff₀ hN_pos h2k_pos]
  refine le_of_mul_le_mul_right ?_ hN_pos
  calc ((Bad₁.card : ℝ) * (2 : ℝ) ^ k) * (N : ℝ)
      = ((Bad₁.card : ℝ) * (N : ℝ)) * (2 : ℝ) ^ k := by ring
    _ ≤ (2 * (Bad₂.card : ℝ)) * (2 : ℝ) ^ k :=
        mul_le_mul_of_nonneg_right hBad1_le_Bad2 (le_of_lt h2k_pos)
    _ = 2 * ((Bad₂.card : ℝ) * (2 : ℝ) ^ k) := by ring
    _ ≤ 2 * ((N : ℝ) * (N : ℝ) * M) := by linarith
    _ = (2 * M * (N : ℝ)) * (N : ℝ) := by ring

end UL.Proof_cit_hw87_halfspace_net
