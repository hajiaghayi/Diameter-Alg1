import Mathlib
import UL.Def.def_A_halfspace_net
set_option autoImplicit false

namespace UL.Proof_cit_hw87_halfspace_net

open Classical in
private noncomputable def edgeWeight {ι : Type*} [Fintype ι] {s : ℕ}
    (sample : Fin s → ι) : ℝ :=
  (((Fintype.card ι - (Finset.univ.image sample).card).choose
    (s - (Finset.univ.image sample).card) : ℕ) : ℝ)⁻¹

open Classical in
private noncomputable def colConst (n s : ℕ) : ℝ :=
  ∑ g : Fin s → Fin s,
    (((n - (Finset.univ.image g).card).choose
      (s - (Finset.univ.image g).card) : ℕ) : ℝ)⁻¹

open Classical in
private lemma card_powersetCard_filter_subset
    {ι : Type*} [Fintype ι] (s : ℕ) (A : Finset ι) (hAs : A.card ≤ s) :
    (((Finset.univ : Finset ι).powersetCard s).filter (fun S => A ⊆ S)).card =
      (Fintype.card ι - A.card).choose (s - A.card) := by
  let L := ((Finset.univ : Finset ι).powersetCard s).filter (fun S => A ⊆ S)
  let R := ((Finset.univ : Finset ι) \ A).powersetCard (s - A.card)
  have hLR : L.card = R.card := by
    rw [← Fintype.card_coe L, ← Fintype.card_coe R]
    refine Fintype.card_congr
      { toFun := fun S => ⟨S.1 \ A, ?_⟩
        invFun := fun T => ⟨A ∪ T.1, ?_⟩
        left_inv := fun S => ?_
        right_inv := fun T => ?_ }
    · have hS := S.2
      simp only [L, Finset.mem_filter, Finset.mem_powersetCard] at hS
      rcases hS with ⟨⟨_, hScard⟩, hAS⟩
      simp only [R, Finset.mem_powersetCard]
      refine ⟨?_, ?_⟩
      · intro x hx
        simp only [Finset.mem_sdiff, Finset.mem_univ, true_and] at hx ⊢
        exact hx.2
      · have hunion : (S.1 \ A) ∪ A = S.1 := Finset.sdiff_union_of_subset hAS
        have hdisj : Disjoint (S.1 \ A) A := Finset.sdiff_disjoint
        have hcard : ((S.1 \ A) ∪ A).card = (S.1 \ A).card + A.card :=
          Finset.card_union_of_disjoint hdisj
        rw [hunion, hScard] at hcard
        omega
    · have hT := T.2
      simp only [R, Finset.mem_powersetCard] at hT
      rcases hT with ⟨hTsub, hTcard⟩
      have hdisj : Disjoint A T.1 := by
        rw [Finset.disjoint_left]
        intro x hxA hxT
        have hx := hTsub hxT
        simp only [Finset.mem_sdiff] at hx
        exact hx.2 hxA
      simp only [L, Finset.mem_filter, Finset.mem_powersetCard]
      refine ⟨⟨Finset.subset_univ _, ?_⟩, Finset.subset_union_left⟩
      rw [Finset.card_union_of_disjoint hdisj, hTcard]
      omega
    · have hS := S.2
      simp only [L, Finset.mem_filter] at hS
      ext x
      by_cases hx : x ∈ A
      · simp [hx, hS.2 hx]
      · simp [hx]
    · have hT := T.2
      simp only [R, Finset.mem_powersetCard] at hT
      ext x
      by_cases hx : x ∈ A
      · have hxnot : x ∉ T.1 := by
          intro hxT
          have hmem := hT.1 hxT
          simp only [Finset.mem_sdiff] at hmem
          exact hmem.2 hx
        simp [hx, hxnot]
      · simp [hx]
  rw [hLR]
  simp only [R, Finset.card_powersetCard]
  have hunion : ((Finset.univ : Finset ι) \ A) ∪ A = Finset.univ :=
    Finset.sdiff_union_of_subset (Finset.subset_univ A)
  have hcard : (((Finset.univ : Finset ι) \ A) ∪ A).card =
      ((Finset.univ : Finset ι) \ A).card + A.card :=
    Finset.card_union_of_disjoint Finset.sdiff_disjoint
  rw [hunion, Finset.card_univ] at hcard
  have hsdiff : ((Finset.univ : Finset ι) \ A).card = Fintype.card ι - A.card := by omega
  rw [hsdiff]

open Classical in
private lemma row_sum_eq_one
    {ι : Type*} [Fintype ι] {s : ℕ} (hs : s ≤ Fintype.card ι)
    (sample : Fin s → ι) :
    ∑ S ∈ (Finset.univ : Finset ι).powersetCard s,
      (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0) = 1 := by
  rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul]
  have himg : (Finset.univ.image sample).card ≤ s :=
    Finset.card_image_le.trans (by simp)
  rw [card_powersetCard_filter_subset s (Finset.univ.image sample) himg]
  unfold edgeWeight
  have hpos : 0 < (Fintype.card ι - (Finset.univ.image sample).card).choose
      (s - (Finset.univ.image sample).card) :=
    Nat.choose_pos (by omega)
  have hne : (((Fintype.card ι - (Finset.univ.image sample).card).choose
      (s - (Finset.univ.image sample).card) : ℕ) : ℝ) ≠ 0 := by positivity
  exact mul_inv_cancel₀ hne

open Classical in
private lemma col_sum_eq_const
    {ι : Type*} [Fintype ι] {s : ℕ}
    {S : Finset ι} (hS : S ∈ (Finset.univ : Finset ι).powersetCard s) :
    ∑ sample : Fin s → ι,
      (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0) =
      colConst (Fintype.card ι) s := by
  let Sub := (Finset.univ : Finset (Fin s → ι)).filter
    (fun sample => Finset.univ.image sample ⊆ S)
  have hScard : Fintype.card S = s := by
    rw [Fintype.card_coe]
    exact (Finset.mem_powersetCard.mp hS).2
  let e : S ≃ Fin s := Fintype.equivFinOfCardEq hScard
  let φ : Fin s → ι := fun x => (e.symm x).1
  have hφ_inj : Function.Injective φ := by
    intro x y hxy
    apply e.symm.injective
    exact Subtype.ext hxy
  have hmemSub : ∀ sample : Sub, ∀ j : Fin s, sample.1 j ∈ S := by
    intro sample j
    have hsub : Finset.univ.image sample.1 ⊆ S := (Finset.mem_filter.mp sample.2).2
    exact hsub (Finset.mem_image_of_mem sample.1 (Finset.mem_univ j))
  let equivSub : (Fin s → Fin s) ≃ Sub :=
    { toFun := fun g => ⟨fun j => φ (g j), by
        simp only [Sub, Finset.mem_filter, Finset.mem_univ, true_and]
        intro y hy
        rcases Finset.mem_image.mp hy with ⟨j, -, rfl⟩
        exact (e.symm (g j)).2⟩
      invFun := fun sample => fun j => e ⟨sample.1 j, hmemSub sample j⟩
      left_inv := fun g => by
        funext j
        simp [φ]
      right_inv := fun sample => by
        ext j
        simp [φ] }
  rw [← Finset.sum_filter]
  change ∑ sample ∈ Sub, edgeWeight sample = colConst (Fintype.card ι) s
  rw [← Finset.sum_coe_sort Sub]
  symm
  unfold colConst
  refine Fintype.sum_equiv equivSub
    (fun g => (((Fintype.card ι - (Finset.univ.image g).card).choose
      (s - (Finset.univ.image g).card) : ℕ) : ℝ)⁻¹)
    (fun sample : Sub => edgeWeight sample.1) ?_
  intro g
  unfold edgeWeight
  have himg_eq : (Finset.univ.image (fun j => φ (g j))).card =
      (Finset.univ.image g).card := by
    have hcomp : Finset.univ.image (fun j => φ (g j)) =
        (Finset.univ.image g).image φ := by
      ext y
      simp
    rw [hcomp, Finset.card_image_of_injective _ hφ_inj]
  dsimp only
  have hval : (equivSub g).1 = (fun j => φ (g j)) := rfl
  rw [hval, himg_eq]

open Classical in
private lemma isHalfspaceNet_of_indexed_of_subset
    {D : ℕ} {ι : Type*} [Fintype ι]
    {α : ℝ} {P : ι → EuclideanSpace ℝ (Fin D)} {s : ℕ}
    {sample : Fin s → ι} {S : Finset ι}
    (hnet : UL.IsIndexedHalfspaceNet α P sample)
    (hsub : Finset.univ.image sample ⊆ S) :
    UL.IsHalfspaceNet α P S := by
  intro H hH hcount
  rcases hnet H hH hcount with ⟨j, hj⟩
  exact ⟨sample j, hsub (Finset.mem_image_of_mem sample (Finset.mem_univ j)), hj⟩

open Classical in
theorem halfspaceNet_powersetCard_prob_ge_indexed
    {D : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (α : ℝ) (P : ι → EuclideanSpace ℝ (Fin D))
    (s : ℕ) (hs : s ≤ Fintype.card ι) :
    ((Finset.univ.filter (fun sample : Fin s → ι =>
        UL.IsIndexedHalfspaceNet α P sample)).card : ℝ) /
      (Fintype.card (Fin s → ι) : ℝ)
    ≤ ((((Finset.univ : Finset ι).powersetCard s).filter (fun S : Finset ι =>
        UL.IsHalfspaceNet α P S)).card : ℝ) /
      (((Finset.univ : Finset ι).powersetCard s).card : ℝ) := by
  let U : Finset ι := Finset.univ
  let GoodIdx := (Finset.univ : Finset (Fin s → ι)).filter
    (fun sample => UL.IsIndexedHalfspaceNet α P sample)
  let GoodSet := (U.powersetCard s).filter (fun S => UL.IsHalfspaceNet α P S)
  let C₀ := colConst (Fintype.card ι) s
  have hw_nonneg : ∀ sample : Fin s → ι, 0 ≤ edgeWeight sample := by
    intro sample
    unfold edgeWeight
    positivity
  -- Total mass identity: Fintype.card (Fin s → ι) = (U.powersetCard s).card * C₀
  have htotal : (Fintype.card (Fin s → ι) : ℝ) = ((U.powersetCard s).card : ℝ) * C₀ := by
    calc
      (Fintype.card (Fin s → ι) : ℝ)
          = ∑ _sample : Fin s → ι, (1 : ℝ) := by simp
      _ = ∑ sample : Fin s → ι, ∑ S ∈ U.powersetCard s,
            (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0) := by
            refine Finset.sum_congr rfl ?_
            intro sample _
            exact (row_sum_eq_one hs sample).symm
      _ = ∑ S ∈ U.powersetCard s, ∑ sample : Fin s → ι,
            (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0) :=
            Finset.sum_comm
      _ = ∑ _S ∈ U.powersetCard s, C₀ := by
            refine Finset.sum_congr rfl ?_
            intro S hS
            exact col_sum_eq_const hS
      _ = ((U.powersetCard s).card : ℝ) * C₀ := by
            rw [Finset.sum_const, nsmul_eq_mul]
  -- Good pairs inequality: GoodIdx.card ≤ GoodSet.card * C₀
  have hgood : (GoodIdx.card : ℝ) ≤ (GoodSet.card : ℝ) * C₀ := by
    have hgood_eq : (GoodIdx.card : ℝ) =
        ∑ S ∈ GoodSet, ∑ sample ∈ GoodIdx,
          (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0) := by
      calc
        (GoodIdx.card : ℝ)
            = ∑ _sample ∈ GoodIdx, (1 : ℝ) := by simp
        _ = ∑ sample ∈ GoodIdx, ∑ S ∈ U.powersetCard s,
              (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0) := by
              refine Finset.sum_congr rfl ?_
              intro sample _
              exact (row_sum_eq_one hs sample).symm
        _ = ∑ sample ∈ GoodIdx, ∑ S ∈ GoodSet,
              (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0) := by
              refine Finset.sum_congr rfl ?_
              intro sample hsample
              have hnet : UL.IsIndexedHalfspaceNet α P sample :=
                (Finset.mem_filter.mp hsample).2
              symm
              rw [Finset.sum_filter]
              refine Finset.sum_congr rfl ?_
              intro S _
              by_cases hsub : Finset.univ.image sample ⊆ S
              · have hSnet : UL.IsHalfspaceNet α P S :=
                  isHalfspaceNet_of_indexed_of_subset hnet hsub
                simp [hsub, hSnet]
              · simp [hsub]
        _ = ∑ S ∈ GoodSet, ∑ sample ∈ GoodIdx,
              (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0) :=
              Finset.sum_comm
    rw [hgood_eq]
    calc
      ∑ S ∈ GoodSet, ∑ sample ∈ GoodIdx,
          (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0)
          ≤ ∑ _S ∈ GoodSet, C₀ := by
            refine Finset.sum_le_sum ?_
            intro S hS
            have hSU : S ∈ U.powersetCard s := (Finset.mem_filter.mp hS).1
            calc
              ∑ sample ∈ GoodIdx,
                  (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0)
                  ≤ ∑ sample ∈ (Finset.univ : Finset (Fin s → ι)),
                      (if Finset.univ.image sample ⊆ S then edgeWeight sample else 0) := by
                    refine Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) ?_
                    intro sample _ _
                    split_ifs
                    · exact hw_nonneg sample
                    · exact le_rfl
              _ = C₀ := col_sum_eq_const hSU
      _ = (GoodSet.card : ℝ) * C₀ := by
            rw [Finset.sum_const, nsmul_eq_mul]
  -- Positivity of denominators
  have hb_pos : (0 : ℝ) < (Fintype.card (Fin s → ι) : ℝ) := by
    exact Nat.cast_pos.mpr Fintype.card_pos
  have hd_pos : (0 : ℝ) < ((U.powersetCard s).card : ℝ) := by
    have hcard_pos : 0 < (U.powersetCard s).card := by
      simp only [U, Finset.card_powersetCard, Finset.card_univ]
      exact Nat.choose_pos hs
    exact Nat.cast_pos.mpr hcard_pos
  change (GoodIdx.card : ℝ) / (Fintype.card (Fin s → ι) : ℝ) ≤
      (GoodSet.card : ℝ) / ((U.powersetCard s).card : ℝ)
  rw [div_le_div_iff₀ hb_pos hd_pos]
  calc
    (GoodIdx.card : ℝ) * ((U.powersetCard s).card : ℝ)
        ≤ ((GoodSet.card : ℝ) * C₀) * ((U.powersetCard s).card : ℝ) :=
          mul_le_mul_of_nonneg_right hgood hd_pos.le
    _ = (GoodSet.card : ℝ) * (((U.powersetCard s).card : ℝ) * C₀) := by ring
    _ = (GoodSet.card : ℝ) * (Fintype.card (Fin s → ι) : ℝ) := by rw [← htotal]

end UL.Proof_cit_hw87_halfspace_net
