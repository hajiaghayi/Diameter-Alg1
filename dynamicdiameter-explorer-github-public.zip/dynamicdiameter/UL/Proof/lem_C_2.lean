import UL.Stmt.lem_C_2
import UL.Stmt.lem_5_1
import UL.Stmt.claim_C_2_scans
import UL.Proof.lem_C_2.H1
set_option autoImplicit false

namespace UL

namespace Proof_lem_C_2

open UL.Proof.lem_C_2.H1

private theorem getElem_append_singleton_eq {α : Type*} (l : List α) (x : α)
    {i : ℕ} (hi : i < (l ++ [x]).length) (heq : i = l.length) :
    (l ++ [x])[i]'hi = x := by
  subst heq
  rw [List.getElem_append_right le_rfl]
  simp

/-! ### 1. Per-level opening metadata and monotonicity -/

def PrefixLevelMeta {d : ℕ} {ι : Type} {T : ℕ}
    (α : ℝ) (L : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S_root : Fin (T + 1) → Finset ι)
    (job : Fin (T + 1) → PendingReplacementJob d ι)
    (pfx : List (OpenedJobLevel d ι)) (s_bound : Fin (T + 1))
    (idx : ℕ) (hidx : idx < pfx.length) : Prop :=
  let lv := pfx[idx]'hidx
  IsLargeResidualLevel L lv.birthSnapshot.card ∧
  PassesBirthCoreCheck α pts lv.ball lv.birthSnapshot ∧
  (∀ (i : ℕ) (hi : i < pfx.length), idx = i + 1 →
    (lv.birthSnapshot.card : ℝ) ≤
      (1 - α / 4) * ((pfx[i]'hi).birthSnapshot.card : ℝ)) ∧
  ∃ (t_open : Fin (T + 1)) (lv_open : OpenedJobLevel d ι),
    t_open ≤ s_bound ∧
    (∀ u : Fin (T + 1), u < t_open → (job u).completedPrefix.length ≤ idx) ∧
    (job t_open).completedPrefix[idx]? = some lv_open ∧
    lv_open.birthSnapshot = lv.birthSnapshot ∧
    lv.birthSnapshot = prefixResidual pts (pfx.take idx) (S_root t_open) ∧
    α * (lv.birthSnapshot.card : ℝ) / (scheduleCStar : ℝ) - 2 <
      ((job t_open).remainingTicks : ℝ) ∧
    ((job t_open).remainingTicks : ℝ) ≤
      α * (lv.birthSnapshot.card : ℝ) / (scheduleCStar : ℝ)

theorem prefixLevelMeta_mono {d : ℕ} {ι : Type} {T : ℕ}
    {α : ℝ} {L : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d)}
    {S_root : Fin (T + 1) → Finset ι}
    {job : Fin (T + 1) → PendingReplacementJob d ι}
    {p₁ p₂ : List (OpenedJobLevel d ι)}
    {s₁ s₂ : Fin (T + 1)}
    (hevol : PrefixEvolves p₁ p₂) (hs : s₁ ≤ s₂)
    {idx : ℕ} (h₁ : idx < p₁.length) (h₂ : idx < p₂.length)
    (hmeta : PrefixLevelMeta α L pts S_root job p₁ s₁ idx h₁) :
    PrefixLevelMeta α L pts S_root job p₂ s₂ idx h₂ := by
  have hlv := hevol.2 idx h₁ h₂
  rcases hmeta with ⟨hlarge, hcore, hcontr, t_open, lv_open, hto_le, hmin, hsome, hbs_open, hbs_res, hlb, hub⟩
  dsimp only [PrefixLevelMeta]
  rw [hlv.1, hlv.2.1]
  refine ⟨hlarge, hcore, ?_, t_open, lv_open, le_trans hto_le hs, hmin, hsome, hbs_open, ?_, hlb, hub⟩
  · intro i hi₂ hidx_eq
    have hi₁ : i < p₁.length := by omega
    have hlv_i := hevol.2 i hi₁ hi₂
    rw [hlv_i.1]
    exact hcontr i hi₁ hidx_eq
  · rw [← prefixResidual_take_eq_of_prefixEvolves pts (S_root t_open) hevol idx (le_of_lt h₁)]
    exact hbs_res

def JobInv {d : ℕ} {ι : Type} {T : ℕ}
    (α : ℝ) (L : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S_root : Fin (T + 1) → Finset ι)
    (job : Fin (T + 1) → PendingReplacementJob d ι)
    (s : Fin (T + 1)) : Prop :=
  (job s).currentResidual = prefixResidual pts (job s).completedPrefix (S_root s) ∧
  (∀ (idx : ℕ) (hidx : idx < (job s).completedPrefix.length),
    PrefixLevelMeta α L pts S_root job (job s).completedPrefix s idx hidx) ∧
  (∀ (idx : ℕ) (hidx : idx + 1 < (job s).completedPrefix.length),
    ((job s).completedPrefix[idx]'(Nat.lt_of_succ_lt hidx)).backgroundReady = true) ∧
  (if (job s).closedAsLeaf = true then
    (∀ lv ∈ (job s).completedPrefix, lv.backgroundReady = true) ∧
    (job s).currentResidual.card + (job s).remainingTicks ≤ 3 * L + 2
  else
    ¬ CanOpenResidualLevel α (job s).remainingTicks (job s).currentResidual.card)

/-! ### 2. Trajectory clock and prefix monotonicity -/

theorem trajectory_clocks_and_prefix {d : ℕ} {ι : Type} {T : ℕ}
    {pts : ι → EuclideanSpace ℝ (Fin d)}
    {α : ℝ} {L : ℕ}
    {S_root : Fin (T + 1) → Finset ι}
    {ev : Fin T → PoolUpdateEvent ι}
    {job : Fin (T + 1) → PendingReplacementJob d ι}
    (h_deadline : poolClockTickCount (List.ofFn ev) = jobDeadlineTicks α (S_root 0).card)
    (h_init : ScheduleTickPass α L pts (initPendingJob α (S_root 0)) (job 0))
    (h_step : ∀ t : Fin T,
      if (ev t).isClockTick then
        ScheduleTickPass α L pts
          (updatePendingJobRootPool pts (job t.castSucc) (ev t) (S_root t.succ)) (job t.succ)
      else
        job t.succ = job t.castSucc) :
    (∀ s : Fin (T + 1),
      (job s).deadlineTicks = jobDeadlineTicks α (S_root 0).card ∧
      (job s).remainingTicks = poolClockTickCount ((List.ofFn ev).drop s.val) ∧
      (job s).remainingTicks + poolClockTickCount ((List.ofFn ev).take s.val) =
        jobDeadlineTicks α (S_root 0).card) ∧
    (∀ (s₁ s₂ : Fin (T + 1)), s₁ ≤ s₂ →
      PrefixEvolves (job s₁).completedPrefix (job s₂).completedPrefix) := by
  set H : ℕ := jobDeadlineTicks α (S_root 0).card
  have h_step_props : ∀ t : Fin T,
      (job t.succ).deadlineTicks = (job t.castSucc).deadlineTicks ∧
      (job t.succ).remainingTicks = (job t.castSucc).remainingTicks - (ev t).ticks ∧
      PrefixEvolves (job t.castSucc).completedPrefix (job t.succ).completedPrefix := by
    intro t
    have hst := h_step t
    by_cases htk : (ev t).isClockTick = true
    · simp only [htk, ↓reduceIte] at hst
      rcases chain_preserves_clocks_and_prefix hst.1 with ⟨hd, hr, hp⟩
      exact ⟨hd, hr, hp⟩
    · have htk_f : (ev t).isClockTick = false := Bool.eq_false_iff.mpr htk
      simp only [htk_f, Bool.false_eq_true, ↓reduceIte] at hst
      have hticks0 : (ev t).ticks = 0 := by
        unfold PoolUpdateEvent.ticks
        simp [htk_f]
      rw [hst, hticks0, Nat.sub_zero]
      exact ⟨rfl, rfl, PrefixEvolves.refl _⟩
  have h_clocks_sub : ∀ s : Fin (T + 1),
      (job s).deadlineTicks = H ∧
      (job s).remainingTicks = H - poolClockTickCount ((List.ofFn ev).take s.val) := by
    rintro ⟨k, hk⟩
    induction k with
    | zero =>
      rcases chain_preserves_clocks_and_prefix h_init.1 with ⟨hd, hr, _⟩
      have htake0 : poolClockTickCount ((List.ofFn ev).take 0) = 0 := rfl
      change (job 0).deadlineTicks = H ∧ (job 0).remainingTicks = H - poolClockTickCount ((List.ofFn ev).take 0)
      rw [htake0, Nat.sub_zero]
      exact ⟨hd, hr⟩
    | succ k ih =>
      have hk_lt : k < T := Nat.lt_of_succ_lt_succ hk
      let t : Fin T := ⟨k, hk_lt⟩
      rcases ih (Nat.lt_succ_of_lt hk_lt) with ⟨hd_k, hr_k⟩
      rcases h_step_props t with ⟨hd_s, hr_s, _⟩
      have h_tk := poolClockTickCount_ofFn_take_succ ev t
      have h_cs : t.castSucc = ⟨k, Nat.lt_succ_of_lt hk_lt⟩ := rfl
      have h_sc : t.succ = ⟨k + 1, hk⟩ := rfl
      rw [h_cs] at hd_s hr_s h_tk
      rw [h_sc] at hd_s hr_s h_tk
      refine ⟨hd_s.trans hd_k, ?_⟩
      rw [hr_s, hr_k, h_tk, Nat.sub_sub]
  refine ⟨?_, ?_⟩
  · intro s
    rcases h_clocks_sub s with ⟨hd, hr⟩
    have hsum := poolClockTickCount_take_add_drop (List.ofFn ev) s.val
    rw [h_deadline] at hsum
    exact ⟨hd, by omega, by omega⟩
  · intro s₁ s₂ hs
    rcases s₂ with ⟨k, hk⟩
    change s₁.val ≤ k at hs
    induction k with
    | zero =>
      have hs0 : s₁ = ⟨0, hk⟩ := by
        ext
        exact Nat.eq_zero_of_le_zero hs
      subst hs0
      exact PrefixEvolves.refl _
    | succ k ih =>
      by_cases h_eq : s₁.val = k + 1
      · have hs_eq : s₁ = ⟨k + 1, hk⟩ := by
          ext
          exact h_eq
        subst hs_eq
        exact PrefixEvolves.refl _
      · have hs_le : s₁.val ≤ k := by omega
        have hk_lt : k < T := Nat.lt_of_succ_lt_succ hk
        let t : Fin T := ⟨k, hk_lt⟩
        have h1 := ih (Nat.lt_succ_of_lt hk_lt) hs_le
        have h2 := (h_step_props t).2.2
        exact PrefixEvolves.trans h1 h2

/-! ### 3. Unified schedule-pass step on an open job -/

open Classical in
theorem schedule_pass_open_step {d n : ℕ} {ι : Type} {T : ℕ}
    {pts : ι → EuclideanSpace ℝ (Fin d)}
    {α C : ℝ} {K₀ L : ℕ}
    {S_root : Fin (T + 1) → Finset ι}
    {ev : Fin T → PoolUpdateEvent ι}
    {job : Fin (T + 1) → PendingReplacementJob d ι}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (h_ev : ∀ t : Fin T, IsValidPoolUpdateEvent (S_root t.castSucc) (S_root t.succ) (ev t))
    (h_build : ∀ (idx : ℕ) (t_open : Fin (T + 1)) (lv : OpenedJobLevel d ι),
      (∀ s : Fin (T + 1), s < t_open → (job s).completedPrefix[idx]? = none) →
      (job t_open).completedPrefix[idx]? = some lv →
      ∃ b : ℕ,
        (b : ℝ) ≤ α ^ 2 * (lv.birthSnapshot.card : ℝ) / (64 * (scheduleCStar : ℝ)) ∧
        ∀ s : Fin (T + 1),
          t_open ≤ s →
          b ≤ (job t_open).remainingTicks - (job s).remainingTicks →
          ∃ lv_s : OpenedJobLevel d ι,
            (job s).completedPrefix[idx]? = some lv_s ∧ lv_s.backgroundReady = true)
    (h_clocks : ∀ s : Fin (T + 1),
      (job s).remainingTicks + poolClockTickCount ((List.ofFn ev).take s.val) =
        jobDeadlineTicks α (S_root 0).card)
    (s_cur : Fin (T + 1))
    (j_pre : PendingReplacementJob d ι)
    (hpass : ScheduleTickPass α L pts j_pre (job s_cur))
    (h_pre_closed : j_pre.closedAsLeaf = false)
    (h_pre_res : j_pre.currentResidual = prefixResidual pts j_pre.completedPrefix (S_root s_cur))
    (h_pre_lb : α * (j_pre.currentResidual.card : ℝ) / (scheduleCStar : ℝ) - 2 <
      (j_pre.remainingTicks : ℝ))
    (h_pre_ready : ∀ (idx : ℕ) (hidx : idx + 1 < j_pre.completedPrefix.length),
      (j_pre.completedPrefix[idx]'(Nat.lt_of_succ_lt hidx)).backgroundReady = true)
    (h_pre_min : ∀ u : Fin (T + 1), u < s_cur →
      (job u).completedPrefix.length ≤ j_pre.completedPrefix.length)
    (h_pre_meta : ∀ (idx : ℕ) (hidx : idx < j_pre.completedPrefix.length),
      PrefixLevelMeta α L pts S_root job j_pre.completedPrefix s_cur idx hidx) :
    JobInv α L pts S_root job s_cur ∧
    (job s_cur).completedPrefix.length ≤ j_pre.completedPrefix.length + 1 := by
  rcases hpass with ⟨hchain, hquiesc⟩
  rcases chain_split_first_gate hchain with hsum0 | ⟨j₁, j₂, hsum1, hgate, hrest⟩
  · -- Case 0: Zero `JobGateStep`s occurred in this tick
    rcases hsum0 with ⟨_, hr0, hc0, hcl0, hlen0, hevol0⟩
    have hcl_cur : (job s_cur).closedAsLeaf = false := hcl0.trans h_pre_closed
    have hres_cur : (job s_cur).currentResidual =
        prefixResidual pts (job s_cur).completedPrefix (S_root s_cur) := by
      rw [hc0, h_pre_res]
      exact prefixResidual_eq_of_balls_eq pts j_pre.completedPrefix (job s_cur).completedPrefix
        (S_root s_cur) hlen0.symm (fun i hi₁ hi₂ => (hevol0.2 i hi₁ hi₂).2.1)
    have hmeta_cur : ∀ (idx : ℕ) (hidx : idx < (job s_cur).completedPrefix.length),
        PrefixLevelMeta α L pts S_root job (job s_cur).completedPrefix s_cur idx hidx := by
      intro idx hidx
      have hidx_pre : idx < j_pre.completedPrefix.length := by omega
      exact prefixLevelMeta_mono hevol0 le_rfl hidx_pre hidx (h_pre_meta idx hidx_pre)
    have hready_cur : ∀ (idx : ℕ) (hidx : idx + 1 < (job s_cur).completedPrefix.length),
        ((job s_cur).completedPrefix[idx]'(Nat.lt_of_succ_lt hidx)).backgroundReady = true := by
      intro idx hidx
      have hidx_pre1 : idx + 1 < j_pre.completedPrefix.length := by omega
      have hidx_pre : idx < j_pre.completedPrefix.length := Nat.lt_of_succ_lt hidx_pre1
      exact (hevol0.2 idx hidx_pre (Nat.lt_of_succ_lt hidx)).2.2.2 (h_pre_ready idx hidx_pre1)
    have hnot_open : ¬ CanOpenResidualLevel α (job s_cur).remainingTicks
        (job s_cur).currentResidual.card := by
      rcases hquiesc with hq_cl | hq_unready | hq_ng
      · rw [hcl_cur] at hq_cl
        cases hq_cl
      · rcases List.mem_iff_getElem.mp hq_unready.choose_spec.1 with ⟨idx, hidx, hlv_eq⟩
        have hunr : ((job s_cur).completedPrefix[idx]'hidx).backgroundReady = false := by
          rw [hlv_eq]
          exact hq_unready.choose_spec.2
        have hidx_last : idx + 1 = (job s_cur).completedPrefix.length := by
          by_contra hne
          have hlt : idx + 1 < (job s_cur).completedPrefix.length := by omega
          have hr_true := hready_cur idx hlt
          rw [hr_true] at hunr
          cases hunr
        rcases hmeta_cur idx hidx with
          ⟨hlarge, hcore, _, t_open, lv_open, hto_le, hmin_u, hsome_open, hbs_open, hbs_res, hlb_open, _⟩
        have hnone_before : ∀ s : Fin (T + 1), s < t_open → (job s).completedPrefix[idx]? = none := by
          intro s hs_lt
          exact List.getElem?_eq_none (hmin_u s hs_lt)
        rcases h_build idx t_open lv_open hnone_before hsome_open with ⟨b, hb_ub, hb_ready⟩
        have hΔ_lt_b : (job t_open).remainingTicks - (job s_cur).remainingTicks < b := by
          by_contra hge
          have hb_le : b ≤ (job t_open).remainingTicks - (job s_cur).remainingTicks := by omega
          rcases hb_ready s_cur hto_le hb_le with ⟨lv_s, hsome_s, hready_s⟩
          rw [List.getElem?_eq_getElem hidx] at hsome_s
          injection hsome_s with h_eq_lv
          rw [← h_eq_lv] at hready_s
          rw [hready_s] at hunr
          cases hunr
        have h_rem_le : (job s_cur).remainingTicks ≤ (job t_open).remainingTicks := by
          have hc1 := h_clocks t_open
          have hc2 := h_clocks s_cur
          have hmono := poolClockTickCount_take_mono (List.ofFn ev) hto_le
          omega
        have h_rem_diff :
            (job t_open).remainingTicks - (job s_cur).remainingTicks =
              poolClockTickCount ((List.ofFn ev).take s_cur.val) -
                poolClockTickCount ((List.ofFn ev).take t_open.val) := by
          have hc1 := h_clocks t_open
          have hc2 := h_clocks s_cur
          have hmono := poolClockTickCount_take_mono (List.ofFn ev) hto_le
          omega
        set pfx_take := (job s_cur).completedPrefix.take idx
        rcases hasNodeAge_filter_trajectory S_root ev h_ev (inPrefixRes pts pfx_take)
            t_open s_cur hto_le with ⟨trueAge, hage_le, hage_filt⟩
        rw [← prefixResidual_eq_filter pts pfx_take (S_root t_open),
            ← prefixResidual_eq_filter pts pfx_take (S_root s_cur),
            ← hbs_res] at hage_filt
        have hage_le_Δ : trueAge ≤ (job t_open).remainingTicks - (job s_cur).remainingTicks := by
          omega
        have hres_decomp : (job s_cur).currentResidual =
            ((job s_cur).completedPrefix[idx]'hidx).ball.residual pts
              (prefixResidual pts pfx_take (S_root s_cur)) := by
          have hpfx_eq : (job s_cur).completedPrefix =
              pfx_take ++ [(job s_cur).completedPrefix[idx]'hidx] := by
            have h1 : (job s_cur).completedPrefix =
                (job s_cur).completedPrefix.take (idx + 1) := by
              rw [hidx_last, List.take_length]
            exact h1.trans (list_take_succ (job s_cur).completedPrefix idx hidx)
          rw [hres_cur]
          conv_lhs => rw [hpfx_eq]
          rw [prefixResidual_append, prefixResidual_singleton]
        rw [hres_decomp]
        have hΔ_le_real :
            (((job t_open).remainingTicks - (job s_cur).remainingTicks : ℕ) : ℝ) ≤
              α ^ 2 * (((job s_cur).completedPrefix[idx]'hidx).birthSnapshot.card : ℝ) /
                (64 * (scheduleCStar : ℝ)) := by
          have h_nat : (job t_open).remainingTicks - (job s_cur).remainingTicks ≤ b := by omega
          have h_cast : (((job t_open).remainingTicks - (job s_cur).remainingTicks : ℕ) : ℝ) ≤ (b : ℝ) := by
            exact_mod_cast h_nat
          rw [hbs_open] at hb_ub
          linarith
        exact gate_closed_during_build hα_pos hα_le hL pts
          ((job s_cur).completedPrefix[idx]'hidx).ball
          ((job s_cur).completedPrefix[idx]'hidx).birthSnapshot
          (prefixResidual pts pfx_take (S_root s_cur))
          hlarge hcore hlb_open h_rem_le hΔ_le_real hage_le_Δ hage_filt
      · exact hq_ng
    refine ⟨⟨hres_cur, hmeta_cur, hready_cur, ?_⟩, by omega⟩
    change if (job s_cur).closedAsLeaf = true then _ else _
    rw [if_neg (by rw [hcl_cur]; decide)]
    exact hnot_open
  · -- Case 1: At least one `JobGateStep` occurred; split at the first one `hgate : JobGateStep j₁ j₂`
    rcases hsum1 with ⟨_, hr1, hc1, _, hlen1, hevol1⟩
    rcases hgate with ⟨hcl1, hready1, hcan1, hact⟩
    rcases hact with ⟨hleaf1, rfl⟩ | ⟨hlarge1, res, ball, mode, hvalid_ball, rfl⟩
    · -- Branch 1a: Leaf closure (`j₂ = closeResidualAsLeafInJob j₁`)
      have hcl2 : (closeResidualAsLeafInJob j₁).closedAsLeaf = true := rfl
      rcases chain_of_closed hrest hcl2 with ⟨_, hr2, hc2, hcl_end, hlen2, hevol2⟩
      have hevol_total : PrefixEvolves j_pre.completedPrefix (job s_cur).completedPrefix :=
        PrefixEvolves.trans hevol1 hevol2
      have hlen_total : (job s_cur).completedPrefix.length = j_pre.completedPrefix.length :=
        hlen2.trans hlen1
      have hcl_cur : (job s_cur).closedAsLeaf = true := hcl_end
      have hres_cur : (job s_cur).currentResidual =
          prefixResidual pts (job s_cur).completedPrefix (S_root s_cur) := by
        have hc_eq : (job s_cur).currentResidual = j_pre.currentResidual := hc2.trans hc1
        rw [hc_eq, h_pre_res]
        exact prefixResidual_eq_of_balls_eq pts j_pre.completedPrefix (job s_cur).completedPrefix
          (S_root s_cur) hlen_total.symm (fun i hi₁ hi₂ => (hevol_total.2 i hi₁ hi₂).2.1)
      have hmeta_cur : ∀ (idx : ℕ) (hidx : idx < (job s_cur).completedPrefix.length),
          PrefixLevelMeta α L pts S_root job (job s_cur).completedPrefix s_cur idx hidx := by
        intro idx hidx
        have hidx_pre : idx < j_pre.completedPrefix.length := by omega
        exact prefixLevelMeta_mono hevol_total le_rfl hidx_pre hidx (h_pre_meta idx hidx_pre)
      have hall_ready : ∀ lv ∈ (job s_cur).completedPrefix, lv.backgroundReady = true := by
        intro lv hlv
        rcases List.mem_iff_getElem.mp hlv with ⟨idx, hidx, rfl⟩
        have hidx1 : idx < j₁.completedPrefix.length := by omega
        have hr_j1 : (j₁.completedPrefix[idx]'hidx1).backgroundReady = true :=
          hready1 _ (List.getElem_mem hidx1)
        exact (hevol2.2 idx hidx1 hidx).2.2.2 hr_j1
      have hready_nonlast : ∀ (idx : ℕ) (hidx : idx + 1 < (job s_cur).completedPrefix.length),
          ((job s_cur).completedPrefix[idx]'(Nat.lt_of_succ_lt hidx)).backgroundReady = true := by
        intro idx hidx
        exact hall_ready _ (List.getElem_mem (Nat.lt_of_succ_lt hidx))
      have hlyap : (job s_cur).currentResidual.card + (job s_cur).remainingTicks ≤ 3 * L + 2 := by
        have hc_eq : (job s_cur).currentResidual = j₁.currentResidual := hc2
        have hr_eq : (job s_cur).remainingTicks = j₁.remainingTicks := hr2
        rw [hc_eq, hr_eq]
        exact leaf_close_lyapunov hα_le hleaf1 hcan1
      refine ⟨⟨hres_cur, hmeta_cur, hready_nonlast, ?_⟩, by omega⟩
      change if (job s_cur).closedAsLeaf = true then _ else _
      rw [if_pos hcl_cur]
      exact ⟨hall_ready, hlyap⟩
    · -- Branch 1b: Large level opening (`j₂ = openLargeLevelInJob pts j₁ ball mode`)
      set j₂ := openLargeLevelInJob pts j₁ ball mode
      have hcore_ball : PassesBirthCoreCheck α pts ball j₁.currentResidual :=
        applyBirthCoreFallback_passes hα_le pts j₁.currentResidual res ball hvalid_ball
      have hlb_j1 : α * (j₁.currentResidual.card : ℝ) / (scheduleCStar : ℝ) - 2 <
          (j₁.remainingTicks : ℝ) := by
        rw [hr1, hc1]
        exact h_pre_lb
      have hΔ0 : (((j₁.remainingTicks - j₁.remainingTicks : ℕ) : ℝ)) ≤
          α ^ 2 * (j₁.currentResidual.card : ℝ) / (64 * (scheduleCStar : ℝ)) := by
        simp only [Nat.sub_self, Nat.cast_zero]
        unfold scheduleCStar
        positivity
      have hnot_open_j2 : ¬ CanOpenResidualLevel α j₂.remainingTicks j₂.currentResidual.card := by
        change ¬ CanOpenResidualLevel α j₁.remainingTicks (ball.residual pts j₁.currentResidual).card
        exact gate_closed_during_build hα_pos hα_le hL pts ball
          j₁.currentResidual j₁.currentResidual hlarge1 hcore_ball hlb_j1
          le_rfl hΔ0 (by simp) (hasNodeAge_refl _)
      rcases chain_of_gate_closed hrest hnot_open_j2 with ⟨_, hr2, hc2, hcl2, hlen2, hevol2⟩
      have hcl_cur : (job s_cur).closedAsLeaf = false := hcl2.trans hcl1
      have hnot_open_cur :
          ¬ CanOpenResidualLevel α (job s_cur).remainingTicks (job s_cur).currentResidual.card := by
        rw [hr2, hc2]
        exact hnot_open_j2
      have hlen_j2 : j₂.completedPrefix.length = j₁.completedPrefix.length + 1 := by
        simp [j₂, openLargeLevelInJob]
      have hlen_cur : (job s_cur).completedPrefix.length = j_pre.completedPrefix.length + 1 := by
        omega
      have hevol_j1_j2 : PrefixEvolves j₁.completedPrefix j₂.completedPrefix := by
        refine ⟨by omega, fun i hi₁ hi₂ => ?_⟩
        dsimp only [j₂, openLargeLevelInJob]
        rw [List.getElem_append_left hi₁]
        exact LevelEvolves.refl _
      have hevol_pre_cur : PrefixEvolves j_pre.completedPrefix (job s_cur).completedPrefix :=
        PrefixEvolves.trans hevol1 (PrefixEvolves.trans hevol_j1_j2 hevol2)
      let lv_init : OpenedJobLevel d ι :=
        { birthSnapshot := j₁.currentResidual
          ball := ball
          indexMode := mode
          backgroundReady := false }
      have hres_cur : (job s_cur).currentResidual =
          prefixResidual pts (job s_cur).completedPrefix (S_root s_cur) := by
        have hc_eq : (job s_cur).currentResidual = ball.residual pts j₁.currentResidual := hc2
        rw [hc_eq, hc1, h_pre_res]
        have h_app : ball.residual pts (prefixResidual pts j_pre.completedPrefix (S_root s_cur)) =
            prefixResidual pts (j_pre.completedPrefix ++ [lv_init]) (S_root s_cur) := by
          rw [prefixResidual_append, prefixResidual_singleton]
        rw [h_app]
        apply prefixResidual_eq_of_balls_eq pts (j_pre.completedPrefix ++ [lv_init])
          (job s_cur).completedPrefix (S_root s_cur)
        · simp [hlen_cur]
        · intro i hi₁ hi₂
          by_cases hi_lt : i < j_pre.completedPrefix.length
          · rw [List.getElem_append_left hi_lt]
            exact (hevol_pre_cur.2 i hi_lt hi₂).2.1
          · have hi_eq : i = j_pre.completedPrefix.length := by
              simp at hi₁
              omega
            subst hi_eq
            have hi_j1 : j_pre.completedPrefix.length = j₁.completedPrefix.length := hlen1.symm
            have h_app_r :
                ((j_pre.completedPrefix ++ [lv_init])[j_pre.completedPrefix.length]'hi₁) = lv_init :=
              getElem_append_singleton_eq j_pre.completedPrefix lv_init hi₁ rfl
            have hi_j2 : j_pre.completedPrefix.length < j₂.completedPrefix.length := by omega
            have h_j2_r : (j₂.completedPrefix[j_pre.completedPrefix.length]'hi_j2) = lv_init :=
              getElem_append_singleton_eq j₁.completedPrefix lv_init hi_j2 hi_j1
            rw [h_app_r]
            have h_ev2 := (hevol2.2 j_pre.completedPrefix.length hi_j2 hi₂).2.1
            rw [h_j2_r] at h_ev2
            exact h_ev2
      have hready_cur : ∀ (idx : ℕ) (hidx : idx + 1 < (job s_cur).completedPrefix.length),
          ((job s_cur).completedPrefix[idx]'(Nat.lt_of_succ_lt hidx)).backgroundReady = true := by
        intro idx hidx
        have hidx_j1 : idx < j₁.completedPrefix.length := by omega
        have hidx_j2 : idx < j₂.completedPrefix.length := by omega
        have hr_j1 : (j₁.completedPrefix[idx]'hidx_j1).backgroundReady = true :=
          hready1 _ (List.getElem_mem hidx_j1)
        have h_eq_j2 : (j₂.completedPrefix[idx]'hidx_j2) = (j₁.completedPrefix[idx]'hidx_j1) := by
          dsimp only [j₂, openLargeLevelInJob]
          exact List.getElem_append_left hidx_j1
        have hr_j2 : (j₂.completedPrefix[idx]'hidx_j2).backgroundReady = true := by
          rw [h_eq_j2]
          exact hr_j1
        exact (hevol2.2 idx hidx_j2 (Nat.lt_of_succ_lt hidx)).2.2.2 hr_j2
      have hmeta_cur : ∀ (idx : ℕ) (hidx : idx < (job s_cur).completedPrefix.length),
          PrefixLevelMeta α L pts S_root job (job s_cur).completedPrefix s_cur idx hidx := by
        intro idx hidx
        by_cases hidx_old : idx < j_pre.completedPrefix.length
        · exact prefixLevelMeta_mono hevol_pre_cur le_rfl hidx_old hidx (h_pre_meta idx hidx_old)
        · have hidx_eq : idx = j_pre.completedPrefix.length := by omega
          subst hidx_eq
          set K_old := j_pre.completedPrefix.length
          have hK_j2 : K_old < j₂.completedPrefix.length := by omega
          have h_j2_K : (j₂.completedPrefix[K_old]'hK_j2) = lv_init :=
            getElem_append_singleton_eq j₁.completedPrefix lv_init hK_j2 hlen1.symm
          have hlv_evol := hevol2.2 K_old hK_j2 hidx
          rw [h_j2_K] at hlv_evol
          have hbs_eq : ((job s_cur).completedPrefix[K_old]'hidx).birthSnapshot = j₁.currentResidual :=
            hlv_evol.1
          have hball_eq : ((job s_cur).completedPrefix[K_old]'hidx).ball = ball :=
            hlv_evol.2.1
          have hrem_cur_eq : (job s_cur).remainingTicks = j₁.remainingTicks := by
            rw [hr2]
            rfl
          dsimp only [PrefixLevelMeta]
          rw [hbs_eq, hball_eq]
          refine ⟨hlarge1, hcore_ball, ?_, s_cur, (job s_cur).completedPrefix[K_old]'hidx,
            le_rfl, h_pre_min, List.getElem?_eq_getElem hidx, hbs_eq, ?_, ?_, ?_⟩
          · intro i hi hK_succ
            have hi_old : i < K_old := by omega
            rcases h_pre_meta i hi_old with
              ⟨_, hcore_i, _, t_i, _, hti_le, _, _, _, hbs_i_res, _, hub_i⟩
            have h_rem_diff :
                (job t_i).remainingTicks - (job s_cur).remainingTicks =
                  poolClockTickCount ((List.ofFn ev).take s_cur.val) -
                    poolClockTickCount ((List.ofFn ev).take t_i.val) := by
              have hc_ti := h_clocks t_i
              have hc_sc := h_clocks s_cur
              have hmono := poolClockTickCount_take_mono (List.ofFn ev) hti_le
              omega
            rcases hasNodeAge_filter_trajectory S_root ev h_ev
                (inPrefixRes pts (j_pre.completedPrefix.take i)) t_i s_cur hti_le with
              ⟨a_i, ha_i_le, hage_i⟩
            rw [← prefixResidual_eq_filter pts (j_pre.completedPrefix.take i) (S_root t_i),
                ← prefixResidual_eq_filter pts (j_pre.completedPrefix.take i) (S_root s_cur),
                ← hbs_i_res] at hage_i
            have ha_i_rem : a_i ≤ (job t_i).remainingTicks := by omega
            have ha_i_real :
                (a_i : ℝ) ≤
                  α * ((j_pre.completedPrefix[i]'hi_old).birthSnapshot.card : ℝ) /
                    (scheduleCStar : ℝ) := by
              have hcast : (a_i : ℝ) ≤ ((job t_i).remainingTicks : ℝ) := by exact_mod_cast ha_i_rem
              linarith
            have hres_i : j₁.currentResidual =
                (j_pre.completedPrefix[i]'hi_old).ball.residual pts
                  (prefixResidual pts (j_pre.completedPrefix.take i) (S_root s_cur)) := by
              have hpfx_pre : j_pre.completedPrefix =
                  j_pre.completedPrefix.take i ++ [j_pre.completedPrefix[i]'hi_old] := by
                have h1 : j_pre.completedPrefix = j_pre.completedPrefix.take (i + 1) := by
                  rw [← hK_succ, List.take_length]
                exact h1.trans (list_take_succ j_pre.completedPrefix i hi_old)
              rw [hc1, h_pre_res]
              conv_lhs => rw [hpfx_pre]
              rw [prefixResidual_append, prefixResidual_singleton]
            have hevol_i := (hevol_pre_cur.2 i hi_old hi).1
            rw [hevol_i, hres_i]
            exact birth_to_birth_contraction hα_pos pts
              (j_pre.completedPrefix[i]'hi_old).ball
              (j_pre.completedPrefix[i]'hi_old).birthSnapshot
              (prefixResidual pts (j_pre.completedPrefix.take i) (S_root s_cur))
              hcore_i hage_i ha_i_real
          · rw [hc1, h_pre_res]
            have htake_eq := prefixResidual_take_eq_of_prefixEvolves pts (S_root s_cur)
              hevol_pre_cur K_old le_rfl
            rw [List.take_length] at htake_eq
            exact htake_eq
          · rw [hrem_cur_eq]
            exact hlb_j1
          · rw [hrem_cur_eq]
            exact hcan1
      refine ⟨⟨hres_cur, hmeta_cur, hready_cur, ?_⟩, by omega⟩
      change if (job s_cur).closedAsLeaf = true then _ else _
      rw [if_neg (by rw [hcl_cur]; decide)]
      exact hnot_open_cur

/-! ### 4. Main proof of `S_lem_C_2` -/

open Classical in
theorem main : S_lem_C_2 := by
  unfold S_lem_C_2
  intro d n ι pts α C K₀ L T S_root ev job
    hα_pos hα_le hL _h_cap _h_m₀ h_ev h_deadline h_init h_step h_build
  dsimp only
  rcases trajectory_clocks_and_prefix h_deadline h_init h_step with ⟨h_clocks_all, h_pfx_mono⟩
  have h_clocks_sum : ∀ s : Fin (T + 1),
      (job s).remainingTicks + poolClockTickCount ((List.ofFn ev).take s.val) =
        jobDeadlineTicks α (S_root 0).card :=
    fun s => (h_clocks_all s).2.2

  -- Base case `s = 0` and `(C7)`
  have h_inv_0_and_len : JobInv α L pts S_root job 0 ∧ (job 0).completedPrefix.length ≤ 1 := by
    have hstep0 := schedule_pass_open_step hα_pos hα_le hL h_ev h_build h_clocks_sum
      0 (initPendingJob α (S_root 0)) h_init rfl rfl
      (deadline_gate_bounds hα_pos (S_root 0).card).2
      (fun idx hidx => by simp [initPendingJob] at hidx)
      (fun u hu => by exfalso; exact Nat.not_lt_zero u.val hu)
      (fun idx hidx => by simp [initPendingJob] at hidx)
    exact ⟨hstep0.1, hstep0.2⟩

  -- Step lemma `t.castSucc → t.succ` giving `JobInv t.succ` and `(C8)`
  have h_step_inv : ∀ t : Fin T,
      JobInv α L pts S_root job t.castSucc →
      JobInv α L pts S_root job t.succ ∧
      (job t.succ).completedPrefix.length ≤ (job t.castSucc).completedPrefix.length + (ev t).ticks := by
    intro t hinv
    have hst := h_step t
    by_cases htk : (ev t).isClockTick = true
    · simp only [htk, ↓reduceIte] at hst
      have hticks1 : (ev t).ticks = 1 := by
        unfold PoolUpdateEvent.ticks
        simp [htk]
      rw [hticks1]
      unfold JobInv at hinv
      set j_old := job t.castSucc
      set j_pre := updatePendingJobRootPool pts j_old (ev t) (S_root t.succ)
      rcases hinv with ⟨hres_old, hmeta_old, hready_old, hstate_old⟩
      have hmin_succ : ∀ u : Fin (T + 1), u < t.succ →
          (job u).completedPrefix.length ≤ j_pre.completedPrefix.length := by
        intro u hu
        have hu_le : u ≤ t.castSucc := by
          simp only [Fin.le_iff_val_le_val, Fin.lt_iff_val_lt_val, Fin.val_succ,
            Fin.val_castSucc] at hu ⊢
          omega
        exact (h_pfx_mono u t.castSucc hu_le).1
      have hmeta_pre : ∀ (idx : ℕ) (hidx : idx < j_pre.completedPrefix.length),
          PrefixLevelMeta α L pts S_root job j_pre.completedPrefix t.succ idx hidx := by
        intro idx hidx
        exact prefixLevelMeta_mono (PrefixEvolves.refl _) (le_of_lt Fin.castSucc_lt_succ)
          hidx hidx (hmeta_old idx hidx)
      have hrem_old_eq : j_old.remainingTicks = j_pre.remainingTicks + 1 := by
        have hc_cs := h_clocks_sum t.castSucc
        change j_old.remainingTicks + _ = _ at hc_cs
        have hc_sc := h_clocks_sum t.succ
        have h_tk := poolClockTickCount_ofFn_take_succ ev t
        rw [hticks1] at h_tk
        have hr_sc : (job t.succ).remainingTicks = j_pre.remainingTicks :=
          (chain_preserves_clocks_and_prefix hst.1).2.1
        omega
      have hcard_step :
          j_pre.currentResidual.card ≤ j_old.currentResidual.card + 1 := by
        have h1 : j_pre.currentResidual = prefixResidual pts j_old.completedPrefix (S_root t.succ) := rfl
        rw [h1, hres_old, prefixResidual_eq_filter, prefixResidual_eq_filter]
        have hf := (filter_validPoolUpdateEvent (inPrefixRes pts j_old.completedPrefix) (h_ev t)).2.1
        rw [hticks1] at hf
        exact hf
      by_cases hcl_old : j_old.closedAsLeaf = true
      · -- Closed leaf remains closed
        rw [if_pos hcl_old] at hstate_old
        rcases hstate_old with ⟨hall_ready_old, hlyap_old⟩
        have hcl_pre : j_pre.closedAsLeaf = true := hcl_old
        rcases chain_of_closed hst.1 hcl_pre with ⟨_, hr_c, hc_c, hcl_c, hlen_c, hevol_c⟩
        have hcl_new : (job t.succ).closedAsLeaf = true := hcl_c.trans hcl_pre
        have hres_new : (job t.succ).currentResidual =
            prefixResidual pts (job t.succ).completedPrefix (S_root t.succ) := by
          rw [hc_c]
          change prefixResidual pts j_old.completedPrefix (S_root t.succ) = _
          exact prefixResidual_eq_of_balls_eq pts j_old.completedPrefix
            (job t.succ).completedPrefix (S_root t.succ) hlen_c.symm
            (fun i hi₁ hi₂ => (hevol_c.2 i hi₁ hi₂).2.1)
        have hmeta_new : ∀ (idx : ℕ) (hidx : idx < (job t.succ).completedPrefix.length),
            PrefixLevelMeta α L pts S_root job (job t.succ).completedPrefix t.succ idx hidx := by
          intro idx hidx
          have hidx_pre : idx < j_pre.completedPrefix.length := by omega
          exact prefixLevelMeta_mono hevol_c le_rfl hidx_pre hidx (hmeta_pre idx hidx_pre)
        have hlen_pre_old : j_pre.completedPrefix.length = j_old.completedPrefix.length := rfl
        have hlen_cs_old : (job t.castSucc).completedPrefix.length = j_old.completedPrefix.length := rfl
        have hall_ready_new : ∀ lv ∈ (job t.succ).completedPrefix, lv.backgroundReady = true := by
          intro lv hlv
          rcases List.mem_iff_getElem.mp hlv with ⟨idx, hidx, rfl⟩
          have hidx_pre : idx < j_old.completedPrefix.length := by omega
          exact (hevol_c.2 idx hidx_pre hidx).2.2.2
            (hall_ready_old _ (List.getElem_mem hidx_pre))
        have hready_nonlast : ∀ (idx : ℕ) (hidx : idx + 1 < (job t.succ).completedPrefix.length),
            ((job t.succ).completedPrefix[idx]'(Nat.lt_of_succ_lt hidx)).backgroundReady = true := by
          intro idx hidx
          exact hall_ready_new _ (List.getElem_mem (Nat.lt_of_succ_lt hidx))
        have hlyap_jold : j_old.currentResidual.card + j_old.remainingTicks ≤ 3 * L + 2 := hlyap_old
        have hlyap_new :
            (job t.succ).currentResidual.card + (job t.succ).remainingTicks ≤ 3 * L + 2 := by
          rw [hc_c, hr_c]
          omega
        refine ⟨⟨hres_new, hmeta_new, hready_nonlast, ?_⟩, by omega⟩
        change if (job t.succ).closedAsLeaf = true then _ else _
        rw [if_pos hcl_new]
        exact ⟨hall_ready_new, hlyap_new⟩
      · -- Open job step via `schedule_pass_open_step`
        have hcl_old_f : j_old.closedAsLeaf = false := Bool.eq_false_iff.mpr hcl_old
        rw [if_neg hcl_old] at hstate_old
        have hlb_pre :
            α * (j_pre.currentResidual.card : ℝ) / (scheduleCStar : ℝ) - 2 <
              (j_pre.remainingTicks : ℝ) :=
          pre_tick_gate_lb hα_pos hα_le hrem_old_eq hcard_step hstate_old
        exact schedule_pass_open_step hα_pos hα_le hL h_ev h_build h_clocks_sum
          t.succ j_pre hst hcl_old_f rfl hlb_pre hready_old hmin_succ hmeta_pre
    · -- Non-clock-tick event (`job t.succ = job t.castSucc`, `(ev t).ticks = 0`)
      have htk_f : (ev t).isClockTick = false := Bool.eq_false_iff.mpr htk
      simp only [htk_f, Bool.false_eq_true, ↓reduceIte] at hst
      have hticks0 : (ev t).ticks = 0 := by
        unfold PoolUpdateEvent.ticks
        simp [htk_f]
      have hS_eq : S_root t.succ = S_root t.castSucc := by
        have he := h_ev t
        cases h_e : ev t <;> rw [h_e] at htk_f he
        · simp [PoolUpdateEvent.isClockTick] at htk_f
        · simp [PoolUpdateEvent.isClockTick] at htk_f
        · exact he
        · exact he
      unfold JobInv at hinv
      rcases hinv with ⟨hres_old, hmeta_old, hready_old, hstate_old⟩
      refine ⟨⟨?_, ?_, ?_, ?_⟩, by simp [hst, hticks0]⟩
      · rw [hst, hS_eq, hres_old]
      · intro idx hidx
        have hidx_cs : idx < (job t.castSucc).completedPrefix.length := by rw [← hst]; exact hidx
        have hevol_eq : PrefixEvolves (job t.castSucc).completedPrefix (job t.succ).completedPrefix := by
          rw [hst]
          exact PrefixEvolves.refl _
        exact prefixLevelMeta_mono hevol_eq (le_of_lt Fin.castSucc_lt_succ)
          hidx_cs hidx (hmeta_old idx hidx_cs)
      · change ∀ (idx : ℕ) (hidx : idx + 1 < (job t.succ).completedPrefix.length),
            ((job t.succ).completedPrefix[idx]'(Nat.lt_of_succ_lt hidx)).backgroundReady = true
        rw [hst]
        exact hready_old
      · change if (job t.succ).closedAsLeaf = true then _ else _
        rw [hst]
        exact hstate_old

  -- Inductively obtain `JobInv s` for all `s : Fin (T + 1)`
  have h_inv_all : ∀ s : Fin (T + 1), JobInv α L pts S_root job s := by
    rintro ⟨k, hk⟩
    induction k with
    | zero => exact h_inv_0_and_len.1
    | succ k ih =>
      have hk_lt : k < T := Nat.lt_of_succ_lt_succ hk
      let t : Fin T := ⟨k, hk_lt⟩
      exact (h_step_inv t (ih (Nat.lt_succ_of_lt hk_lt))).1

  -- Extract terminal facts at `Fin.last T`
  have hinv_last := h_inv_all (Fin.last T)
  unfold JobInv at hinv_last
  have hr_last := (h_clocks_all (Fin.last T)).2.1
  set job_end := job (Fin.last T)
  set S_end := S_root (Fin.last T)
  set K := job_end.completedPrefix.length
  set nodes : Fin K → ChainNode d := fun i => (job_end.completedPrefix[i.val]'i.isLt).ball

  have hrem_end : job_end.remainingTicks = 0 := by
    have hdrop : (List.ofFn ev).drop (Fin.last T).val = [] := by
      rw [Fin.val_last]
      exact List.drop_eq_nil_of_le (by simp)
    rw [hr_last, hdrop]
    rfl

  rcases hinv_last with ⟨hres_end, hmeta_end, _, hstate_end⟩
  have hcl_end : job_end.closedAsLeaf = true := by
    by_contra hnot
    rw [if_neg hnot] at hstate_end
    apply hstate_end
    rw [hrem_end]
    unfold CanOpenResidualLevel scheduleCStar
    simp only [Nat.cast_zero]
    positivity

  rw [if_pos hcl_end] at hstate_end
  rcases hstate_end with ⟨hall_ready_end, hlyap_end⟩

  -- Prove `(C6)` first so `(C3)` can reuse it directly
  have h_C6 : ∀ idx : Fin K,
      ∃ t_open : Fin (T + 1),
        (∀ s : Fin (T + 1), s < t_open → (job s).completedPrefix.length ≤ idx.val) ∧
        idx.val < (job t_open).completedPrefix.length ∧
        let lv := job_end.completedPrefix[idx.val]'idx.isLt
        let m := lv.birthSnapshot.card
        let elapsedTicks := poolClockTickCount ((List.ofFn ev).drop t_open.val)
        (elapsedTicks : ℝ) ≤ α * (m : ℝ) / (scheduleCStar : ℝ) ∧
        ∃ trueAge : ℕ,
          trueAge ≤ elapsedTicks ∧
          HasNodeAge lv.birthSnapshot
            (prefixResidual pts (job_end.completedPrefix.take idx.val) S_end) trueAge := by
    intro idx
    rcases hmeta_end idx.val idx.isLt with
      ⟨_, _, _, t_open, lv_open, _, hmin_u, hsome_open, _, hbs_res, _, hub_open⟩
    have hlt_open : idx.val < (job t_open).completedPrefix.length := by
      by_contra hge
      rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hsome_open
      cases hsome_open
    have helapsed_eq :
        poolClockTickCount ((List.ofFn ev).drop t_open.val) = (job t_open).remainingTicks :=
      (h_clocks_all t_open).2.1.symm
    rcases hasNodeAge_filter_trajectory S_root ev h_ev
        (inPrefixRes pts (job_end.completedPrefix.take idx.val))
        t_open (Fin.last T) (Fin.le_last t_open) with ⟨trueAge, hage_le, hage⟩
    rw [← prefixResidual_eq_filter pts (job_end.completedPrefix.take idx.val) (S_root t_open),
        ← prefixResidual_eq_filter pts (job_end.completedPrefix.take idx.val) S_end,
        ← hbs_res] at hage
    have htake_end : (List.ofFn ev).take (Fin.last T).val = List.ofFn ev := by
      rw [Fin.val_last]
      exact List.take_of_length_le (by simp)
    rw [htake_end] at hage_le
    have hsum_open := poolClockTickCount_take_add_drop (List.ofFn ev) t_open.val
    have htrue_le_el : trueAge ≤ poolClockTickCount ((List.ofFn ev).drop t_open.val) := by
      omega
    refine ⟨t_open, hmin_u, hlt_open, ?_, trueAge, htrue_le_el, hage⟩
    dsimp only
    rw [helapsed_eq]
    exact hub_open

  refine ⟨?_, ?_, ?_, ?_, ?_, h_C6, h_inv_0_and_len.2, ?_⟩
  · -- (C1) `job_end.IsReadyToInstall`
    exact ⟨hrem_end, hcl_end, hall_ready_end⟩
  · -- (C2) `job_end.WellFormed α L pts S_end`
    refine ⟨?_, hres_end, ?_⟩
    · rw [hrem_end]
      exact Nat.zero_le _
    · intro lv hlv
      rcases List.mem_iff_getElem.mp hlv with ⟨idx, hidx, rfl⟩
      rcases hmeta_end idx hidx with ⟨hlarge, hcore, _⟩
      exact ⟨hlarge, hcore⟩
  · -- (C3) Current-input chain contraction
    intro i
    rcases h_C6 i with ⟨t_open, _, _, hel_ub, trueAge, htrue_le, hage_i⟩
    rcases hmeta_end i.val i.isLt with ⟨_, hcore_i, _⟩
    have hci_cs : chainInput pts nodes S_end i.castSucc =
        prefixResidual pts (job_end.completedPrefix.take i.val) S_end :=
      chainInput_eq_prefixResidual_take pts job_end.completedPrefix S_end i.castSucc
    have hci_sc : chainInput pts nodes S_end i.succ =
        (nodes i).residual pts (chainInput pts nodes S_end i.castSucc) := by
      unfold chainInput
      simp only [Fin.val_succ, Fin.val_castSucc]
      rfl
    rw [hci_sc, hci_cs]
    have htrue_real :
        (trueAge : ℝ) ≤
          α * ((job_end.completedPrefix[i.val]'i.isLt).birthSnapshot.card : ℝ) /
            (scheduleCStar : ℝ) := by
      have hcast : (trueAge : ℝ) ≤ (poolClockTickCount ((List.ofFn ev).drop t_open.val) : ℝ) := by
        exact_mod_cast htrue_le
      linarith
    exact current_input_contraction hα_pos hα_le pts (nodes i)
      (job_end.completedPrefix[i.val]'i.isLt).birthSnapshot
      (prefixResidual pts (job_end.completedPrefix.take i.val) S_end)
      hcore_i hage_i htrue_real
  · -- (C4) Birth-snapshot contraction
    intro i hi
    rcases hmeta_end (i + 1) hi with ⟨_, _, hcontr, _⟩
    exact hcontr i (Nat.lt_of_succ_lt hi) rfl
  · -- (C5) Terminal leaf residual size `≤ 3 * L + 2`
    have hlyap_je : job_end.currentResidual.card + job_end.remainingTicks ≤ 3 * L + 2 := hlyap_end
    show job_end.currentResidual.card ≤ 3 * L + 2
    omega
  · -- (C8) Per-step prefix length growth `≤ (ev t).ticks`
    intro t
    exact (h_step_inv t (h_inv_all t.castSucc)).2

end Proof_lem_C_2

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_C_2 (h_lem_5_1 : S_lem_5_1) (h_claim_C_2_scans : S_claim_C_2_scans) : S_lem_C_2 := by
  have _ := h_lem_5_1
  have _ := h_claim_C_2_scans
  exact Proof_lem_C_2.main

end UL
