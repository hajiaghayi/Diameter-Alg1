import Mathlib
import UL.Stmt.lem_5_5
set_option autoImplicit false

namespace UL.Proof_lem_5_5

lemma params_c_pos (params : LocalScaleParams) : 0 < params.c := by
  linarith [params.one_lt_c]

lemma params_K_pos (params : LocalScaleParams) : 0 < params.K := by
  have hc1 : 0 < params.c - 1 := sub_pos.mpr params.one_lt_c
  have hdiv : 0 < 2 / (params.c - 1) := div_pos zero_lt_two hc1
  have hKr : (0 : ℝ) < (params.K : ℝ) := lt_of_lt_of_le hdiv params.K_ge
  exact Int.cast_pos.mp hKr

lemma params_m0_pos (params : LocalScaleParams) : 0 < params.m0 := by
  unfold LocalScaleParams.m0 shellSubdiv
  exact Nat.ceil_pos.mpr (one_div_pos.mpr params.e_pos)

lemma one_div_m0_le_e (params : LocalScaleParams) :
    1 / (params.m0 : ℝ) ≤ (params.e : ℝ) := by
  have hm0_pos : (0 : ℝ) < (params.m0 : ℝ) := Nat.cast_pos.mpr (params_m0_pos params)
  have he_pos : (0 : ℝ) < (params.e : ℝ) := Rat.cast_pos.mpr params.e_pos
  have hceil_q : (1 / params.e : ℚ) ≤ (params.m0 : ℚ) := by
    unfold LocalScaleParams.m0 shellSubdiv
    exact Nat.le_ceil (1 / params.e)
  have hceil_r : 1 / (params.e : ℝ) ≤ (params.m0 : ℝ) := by
    have h1 : ((1 / params.e : ℚ) : ℝ) ≤ ((params.m0 : ℚ) : ℝ) := Rat.cast_le.mpr hceil_q
    simpa using h1
  have hmul : 1 ≤ (params.m0 : ℝ) * (params.e : ℝ) := (div_le_iff₀ he_pos).mp hceil_r
  exact (div_le_iff₀ hm0_pos).mpr (by linarith)

lemma pair_norm_le_indexedEuclideanDiam {d : ℕ} {ι : Type*}
    (S : Finset ι) (pts : ι → EuclideanSpace ℝ (Fin d))
    {u v : ι} (hu : u ∈ S) (hv : v ∈ S) :
    ‖pts u - pts v‖ ≤ indexedEuclideanDiam S pts := by
  have hS : S.Nonempty := ⟨u, hu⟩
  have huv : (u, v) ∈ S ×ˢ S := Finset.mem_product.mpr ⟨hu, hv⟩
  unfold indexedEuclideanDiam
  rw [dif_pos hS]
  exact Finset.le_sup' (f := fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) huv

lemma indexedEuclideanDiam_nonneg {d : ℕ} {ι : Type*}
    (S : Finset ι) (pts : ι → EuclideanSpace ℝ (Fin d)) :
    0 ≤ indexedEuclideanDiam S pts := by
  by_cases hS : S.Nonempty
  · obtain ⟨u, hu⟩ := hS
    exact le_trans (norm_nonneg (pts u - pts u)) (pair_norm_le_indexedEuclideanDiam S pts hu hu)
  · simp [indexedEuclideanDiam, hS]

lemma baseline_props {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (V : ℝ) (S : Finset ι) (basePair : Option (ι × ι))
    (h_base : SatisfiesNodeBaselineCond pts o V S basePair) :
    0 ≤ baselinePairLength pts basePair ∧
    SatisfiesBaselineLengthCond pts o V S (baselinePairLength pts basePair) ∧
    baselinePairLength pts basePair ≤ indexedEuclideanDiam S pts := by
  have h0 : 0 ≤ baselinePairLength pts basePair := by
    cases basePair with
    | none => exact le_rfl
    | some uv =>
        rcases uv with ⟨u, v⟩
        exact norm_nonneg _
  refine ⟨h0, ?_, ?_⟩
  · unfold SatisfiesBaselineLengthCond
    split_ifs with hS
    · exact ⟨h0, h_base.2 hS⟩
    · have hS_empty : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hS
      cases basePair with
      | none => rfl
      | some uv =>
          have huv : uv.1 ∈ S := h_base.1.1
          rw [hS_empty] at huv
          exact False.elim (Finset.notMem_empty _ huv)
  · cases basePair with
    | none =>
        simpa [baselinePairLength] using indexedEuclideanDiam_nonneg S pts
    | some uv =>
        rcases uv with ⟨u, v⟩
        rcases h_base.1 with ⟨hu, hv⟩
        simpa [baselinePairLength] using pair_norm_le_indexedEuclideanDiam S pts hu hv

lemma baseline_le_retainedEstimate {d : ℕ} {ι : Type*}
    (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (V L : ℝ)
    (stored : ShellConfig → Option (ι × ι)) :
    L ≤ params.nodeRetainedEstimate pts V L stored := by
  simp only [LocalScaleParams.nodeRetainedEstimate, nodeRetainedEstimate]
  split_ifs with hVpos
  · unfold matchingEstimateOn
    split_ifs with hNE
    · obtain ⟨cfg, hcfg⟩ := hNE
      have hcand : L ≤ storedEdgeCandidate pts L (stored cfg) := by
        cases stored cfg with
        | none => exact le_rfl
        | some xy => exact le_max_left L _
      exact le_trans hcand
        (Finset.le_sup' (fun c => storedEdgeCandidate pts L (stored c)) hcfg)
    · exact le_rfl
  · exact le_rfl

lemma retainedEstimate_le_diam {d : ℕ} {ι : Type*}
    (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (V L : ℝ) (S : Finset ι)
    (M : ShellConfig → Finset (ι × ι))
    (stored : ShellConfig → Option (ι × ι))
    (hL_diam : L ≤ indexedEuclideanDiam S pts)
    (h_match : 0 < V →
      ∀ cfg ∈ params.retainedConfigs V,
        params.SatisfiesMatchingInvariant pts o V S cfg.j cfg.k cfg.ℓ (M cfg) ∧
        IsStoredMatchingEdge (M cfg) (stored cfg)) :
    params.nodeRetainedEstimate pts V L stored ≤ indexedEuclideanDiam S pts := by
  classical
  simp only [LocalScaleParams.nodeRetainedEstimate, nodeRetainedEstimate]
  split_ifs with hVpos
  · unfold matchingEstimateOn
    split_ifs with hNE
    · apply Finset.sup'_le hNE
      intro cfg hcfg
      cases hst : stored cfg with
      | none =>
          simpa [storedEdgeCandidate] using hL_diam
      | some xy =>
          rcases xy with ⟨x, y⟩
          simp only [storedEdgeCandidate, max_le_iff]
          refine ⟨hL_diam, ?_⟩
          have hm := h_match hVpos cfg hcfg
          have hxyM : (x, y) ∈ M cfg := by
            simpa [IsStoredMatchingEdge, hst] using hm.2
          have hxyW : (x, y) ∈ configWeakEdges pts params.m0 params.lam o V params.K S cfg.j cfg.k cfg.ℓ :=
            hm.1.1 hxyM
          have hxyProd : (x, y) ∈ configLeftVertices pts params.m0 o V S cfg.j ×ˢ
              configRightVertices pts params.m0 o V params.K S cfg.k := by
            unfold configWeakEdges weakEdgesOn at hxyW
            exact (Finset.mem_filter.mp hxyW).1
          rcases Finset.mem_product.mp hxyProd with ⟨hxL, hyR⟩
          have hxCore : x ∈ nodeCore pts o V S := by
            unfold configLeftVertices shellSubset at hxL
            exact (Finset.mem_filter.mp hxL).1
          have hxS : x ∈ S := by
            unfold nodeCore at hxCore
            exact (Finset.mem_filter.mp hxCore).1
          have hyElig : y ∈ nodeEligible pts o V params.K S := by
            unfold configRightVertices shellSubset at hyR
            exact (Finset.mem_filter.mp hyR).1
          have hyS : y ∈ S := by
            unfold nodeEligible at hyElig
            exact (Finset.mem_filter.mp hyElig).1
          exact pair_norm_le_indexedEuclideanDiam S pts hxS hyS
    · exact hL_diam
  · exact hL_diam

lemma inwardRound_props {d : ℕ} (m0 : ℕ) (hm0 : 0 < m0)
    (o p : EuclideanSpace ℝ (Fin d)) (V : ℝ) (hV : 0 < V) :
    let j := shellIndex m0 o V p
    let rj := shellRadius m0 V j
    0 ≤ rj ∧
    rj ≤ ‖p - o‖ ∧
    ‖inwardRound m0 o V p - o‖ = rj ∧
    ‖p - inwardRound m0 o V p‖ = ‖p - o‖ - rj ∧
    ‖p - inwardRound m0 o V p‖ < Real.sqrt V / (m0 : ℝ) := by
  intro j rj
  have hm0r : (0 : ℝ) < (m0 : ℝ) := Nat.cast_pos.mpr hm0
  have hsqrt : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV
  have hrj_nonneg : 0 ≤ rj := by
    change 0 ≤ ((j : ℝ) / (m0 : ℝ)) * Real.sqrt V
    positivity
  have hj_le : (j : ℝ) ≤ (m0 : ℝ) * ‖p - o‖ / Real.sqrt V := by
    change (Nat.floor ((m0 : ℝ) * ‖p - o‖ / Real.sqrt V) : ℝ) ≤ _
    exact Nat.floor_le (by positivity)
  have hrj_le : rj ≤ ‖p - o‖ := by
    change ((j : ℝ) / (m0 : ℝ)) * Real.sqrt V ≤ ‖p - o‖
    have h1 : (j : ℝ) * Real.sqrt V ≤ (m0 : ℝ) * ‖p - o‖ :=
      (le_div_iff₀ hsqrt).mp hj_le
    rw [div_mul_eq_mul_div]
    exact (div_le_iff₀ hm0r).mpr (by linarith)
  have hj_gt : (m0 : ℝ) * ‖p - o‖ / Real.sqrt V < (j : ℝ) + 1 := by
    change (m0 : ℝ) * ‖p - o‖ / Real.sqrt V <
      (Nat.floor ((m0 : ℝ) * ‖p - o‖ / Real.sqrt V) : ℝ) + 1
    exact Nat.lt_floor_add_one _
  have hdiff_lt : ‖p - o‖ - rj < Real.sqrt V / (m0 : ℝ) := by
    have h1 : (m0 : ℝ) * ‖p - o‖ < ((j : ℝ) + 1) * Real.sqrt V :=
      (div_lt_iff₀ hsqrt).mp hj_gt
    have h2 : ‖p - o‖ < (((j : ℝ) + 1) * Real.sqrt V) / (m0 : ℝ) := by
      have h1' : ‖p - o‖ * (m0 : ℝ) < ((j : ℝ) + 1) * Real.sqrt V := by linarith
      exact (lt_div_iff₀ hm0r).mpr h1'
    have h3 : (((j : ℝ) + 1) * Real.sqrt V) / (m0 : ℝ) = rj + Real.sqrt V / (m0 : ℝ) := by
      change (((j : ℝ) + 1) * Real.sqrt V) / (m0 : ℝ) =
        ((j : ℝ) / (m0 : ℝ)) * Real.sqrt V + Real.sqrt V / (m0 : ℝ)
      ring
    linarith
  have hnorms : ‖inwardRound m0 o V p - o‖ = rj ∧
      ‖p - inwardRound m0 o V p‖ = ‖p - o‖ - rj := by
    by_cases hp : p = o
    · subst hp
      have hj0 : j = 0 := by simp [j, shellIndex]
      have hrj0 : rj = 0 := by simp [rj, hj0, shellRadius]
      simp [inwardRound, radialDirection, hrj0]
    · have hnorm : 0 < ‖p - o‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hp)
      have hurad : ‖radialDirection o p‖ = 1 := by
        unfold radialDirection
        rw [norm_smul, Real.norm_of_nonneg (inv_nonneg.mpr hnorm.le), inv_mul_cancel₀ hnorm.ne']
      constructor
      · unfold inwardRound
        change ‖(o + rj • radialDirection o p) - o‖ = rj
        rw [add_sub_cancel_left, norm_smul, Real.norm_of_nonneg hrj_nonneg, hurad, mul_one]
      · have hsub : p - inwardRound m0 o V p = (‖p - o‖ - rj) • radialDirection o p := by
          unfold inwardRound radialDirection
          change p - (o + rj • (‖p - o‖⁻¹ • (p - o))) =
            (‖p - o‖ - rj) • (‖p - o‖⁻¹ • (p - o))
          rw [sub_add_eq_sub_sub, smul_smul, smul_smul]
          have h1 : (‖p - o‖ - rj) * ‖p - o‖⁻¹ = 1 - rj * ‖p - o‖⁻¹ := by
            rw [sub_mul, mul_inv_cancel₀ hnorm.ne']
          rw [h1, sub_smul, one_smul]
        rw [hsub, norm_smul, Real.norm_of_nonneg (sub_nonneg.mpr hrj_le), hurad, mul_one]
  exact ⟨hrj_nonneg, hrj_le, hnorms.1, hnorms.2, by linarith [hnorms.2, hdiff_lt]⟩

lemma shellIndex_le_mul {d : ℕ} (m0 N : ℕ)
    (o p : EuclideanSpace ℝ (Fin d)) (V : ℝ) (hV : 0 < V)
    (hp : ‖p - o‖ ≤ (N : ℝ) * Real.sqrt V) :
    shellIndex m0 o V p ≤ N * m0 := by
  unfold shellIndex
  apply Nat.floor_le_of_le
  have hsqrt : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV
  have hm0 : (0 : ℝ) ≤ (m0 : ℝ) := Nat.cast_nonneg m0
  have h1 : (m0 : ℝ) * ‖p - o‖ ≤ (m0 : ℝ) * ((N : ℝ) * Real.sqrt V) :=
    mul_le_mul_of_nonneg_left hp hm0
  have h2 : (m0 : ℝ) * ‖p - o‖ / Real.sqrt V ≤
      (m0 : ℝ) * ((N : ℝ) * Real.sqrt V) / Real.sqrt V :=
    div_le_div_of_nonneg_right h1 hsqrt.le
  have h3 : (m0 : ℝ) * ((N : ℝ) * Real.sqrt V) / Real.sqrt V = ((N * m0 : ℕ) : ℝ) := by
    push_cast
    field_simp [hsqrt.ne']

  linarith

open Classical in
lemma exists_scale_index (params : LocalScaleParams) (V D_C : ℝ)
    (hV : 0 < V) (hDC_pos : 0 < D_C)
    (hR0 : distScale params.lam V 0 < D_C / (params.κ : ℝ))
    (hDC_ub : D_C ≤ ((params.K : ℝ) + 1) * Real.sqrt V) :
    ∃ ℓ : ℕ,
      ℓ ≤ scaleCutoffIndex params.lam params.K ∧
      distScale params.lam V ℓ < D_C / (params.κ : ℝ) ∧
      D_C / ((params.κ : ℝ) * (params.lam : ℝ)) ≤ distScale params.lam V ℓ := by
  have hlam1 : (1 : ℝ) < (params.lam : ℝ) := by exact_mod_cast params.one_lt_lam
  have hlam_pos : (0 : ℝ) < (params.lam : ℝ) := by linarith
  have hγ1 : (1 : ℝ) < (params.γ : ℝ) := by exact_mod_cast params.one_lt_γ
  have he0 : (0 : ℝ) < (params.e : ℝ) := by exact_mod_cast params.e_pos
  have hκ_eq : (params.κ : ℝ) = (params.γ : ℝ) + 2 * (params.e : ℝ) := by
    simp [LocalScaleParams.κ, localScaleKappa]
  have hκ1 : (1 : ℝ) < (params.κ : ℝ) := by linarith
  have hsqrt : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV
  let S_cut : Set ℕ := {n : ℕ | (params.K : ℝ) + 1 ≤ (params.lam : ℝ) ^ n / 2}
  have hS_ne : S_cut.Nonempty := by
    obtain ⟨n, hn⟩ := pow_unbounded_of_one_lt (2 * ((params.K : ℝ) + 1)) hlam1
    exact ⟨n, by change (params.K : ℝ) + 1 ≤ (params.lam : ℝ) ^ n / 2; linarith⟩
  let J := scaleCutoffIndex params.lam params.K
  have hJ_mem : (params.K : ℝ) + 1 ≤ (params.lam : ℝ) ^ J / 2 := by
    have hm : J ∈ S_cut := Nat.sInf_mem hS_ne
    exact hm
  have hRJ_ge : ((params.K : ℝ) + 1) * Real.sqrt V ≤ distScale params.lam V J := by
    unfold distScale
    have hmul : ((params.K : ℝ) + 1) * Real.sqrt V ≤ ((params.lam : ℝ) ^ J / 2) * Real.sqrt V :=
      mul_le_mul_of_nonneg_right hJ_mem hsqrt.le
    linarith
  have hDC_kappa_lt : D_C / (params.κ : ℝ) < distScale params.lam V J := by
    have hdiv : D_C / (params.κ : ℝ) < D_C := div_lt_self hDC_pos hκ1
    exact lt_of_lt_of_le hdiv (le_trans hDC_ub hRJ_ge)
  let F : Finset ℕ := (Finset.Icc 0 J).filter (fun n => distScale params.lam V n < D_C / (params.κ : ℝ))
  have h0F : 0 ∈ F := by
    refine Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨le_rfl, Nat.zero_le J⟩, hR0⟩
  have hF_ne : F.Nonempty := ⟨0, h0F⟩
  let ℓ := F.max' hF_ne
  have hℓF : ℓ ∈ F := Finset.max'_mem F hF_ne
  have hℓ_le_J : ℓ ≤ J := (Finset.mem_Icc.mp (Finset.mem_of_mem_filter ℓ hℓF)).2
  have hℓ_lt_ub : distScale params.lam V ℓ < D_C / (params.κ : ℝ) := (Finset.mem_filter.mp hℓF).2
  have hℓ_ne_J : ℓ ≠ J := by
    intro heq
    rw [heq] at hℓ_lt_ub
    linarith
  have hℓ1_le_J : ℓ + 1 ≤ J := Nat.succ_le_of_lt (lt_of_le_of_ne hℓ_le_J hℓ_ne_J)
  have hℓ1_not_F : ℓ + 1 ∉ F := by
    intro hmem
    have hle : ℓ + 1 ≤ ℓ := Finset.le_max' F (ℓ + 1) hmem
    omega
  have hℓ1_ge : D_C / (params.κ : ℝ) ≤ distScale params.lam V (ℓ + 1) := by
    by_contra hlt
    push_neg at hlt
    exact hℓ1_not_F (Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨Nat.zero_le _, hℓ1_le_J⟩, hlt⟩)
  have hscale_succ : distScale params.lam V (ℓ + 1) = (params.lam : ℝ) * distScale params.lam V ℓ := by
    unfold distScale
    rw [pow_succ']
    ring
  have hlb : D_C / ((params.κ : ℝ) * (params.lam : ℝ)) ≤ distScale params.lam V ℓ := by
    rw [← div_div]
    exact (div_le_iff₀ hlam_pos).mpr (by linarith [hℓ1_ge, hscale_succ])
  exact ⟨ℓ, hℓ_le_J, hℓ_lt_ub, hlb⟩

open Classical in
lemma mem_retainedConfigs_mk (params : LocalScaleParams) (V : ℝ) (j k ℓ : ℕ)
    (hj1 : 1 ≤ j) (hj2 : j ≤ params.m0)
    (hk1 : 1 ≤ k) (hk2 : k ≤ maxShellIndex params.m0 params.K)
    (hℓ : ℓ ≤ scaleCutoffIndex params.lam params.K)
    (hret : SatisfiesRetentionCond params.m0 params.γ params.lam V j k ℓ) :
    (⟨j, k, ℓ⟩ : ShellConfig) ∈ params.retainedConfigs V := by
  unfold LocalScaleParams.retainedConfigs retainedConfigs
  refine Finset.mem_filter.mpr ⟨?_, hret⟩
  unfold allShellConfigs allShellConfigTriples
  refine Finset.mem_map.mpr ⟨(j, (k, ℓ)), ?_, rfl⟩
  refine Finset.mem_product.mpr ⟨Finset.mem_Icc.mpr ⟨hj1, hj2⟩, ?_⟩
  exact Finset.mem_product.mpr ⟨Finset.mem_Icc.mpr ⟨hk1, hk2⟩, Finset.mem_Icc.mpr ⟨Nat.zero_le ℓ, hℓ⟩⟩

end UL.Proof_lem_5_5
