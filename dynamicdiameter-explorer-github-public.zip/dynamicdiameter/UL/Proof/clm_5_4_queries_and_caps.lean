import UL.Stmt.clm_5_4_queries_and_caps
import UL.Stmt.lem_5_6
set_option autoImplicit false

namespace UL

private theorem c54_liftedPoint_apply_castSucc {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (i : Fin d) :
    (liftedPoint o s) i.castSucc = o i := by
  simp [liftedPoint]

private theorem c54_liftedPoint_apply_last {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    (liftedPoint o s) (Fin.last d) = s := by
  simp [liftedPoint]

private theorem c54_liftedBase_apply {d : ℕ}
    (w : EuclideanSpace ℝ (Fin (d + 1))) (i : Fin d) :
    (liftedBase w) i = w i.castSucc := by
  simp [liftedBase, Fin.init]

private theorem c54_inner_liftedPoint_left {d : ℕ}
    (u : EuclideanSpace ℝ (Fin d)) (c : ℝ) (w : EuclideanSpace ℝ (Fin (d + 1))) :
    inner ℝ (liftedPoint u c) w = inner ℝ u (liftedBase w) + c * liftedHeight w := by
  rw [PiLp.inner_apply, Fin.sum_univ_castSucc, PiLp.inner_apply]
  congr 1
  · refine Finset.sum_congr rfl (fun i _ => ?_)
    rw [c54_liftedPoint_apply_castSucc, c54_liftedBase_apply]
  · rw [c54_liftedPoint_apply_last]
    unfold liftedHeight
    simp [mul_comm]

private theorem c54_inner_liftedPoint {d : ℕ}
    (u v : EuclideanSpace ℝ (Fin d)) (s t : ℝ) :
    inner ℝ (liftedPoint u s) (liftedPoint v t) = inner ℝ u v + s * t := by
  rw [c54_inner_liftedPoint_left]
  have hb : liftedBase (liftedPoint v t) = v := by
    ext i
    rw [c54_liftedBase_apply, c54_liftedPoint_apply_castSucc]
  have hh : liftedHeight (liftedPoint v t) = t := by
    unfold liftedHeight
    exact c54_liftedPoint_apply_last v t
  rw [hb, hh]

private theorem c54_norm_sq_eq_sum {d : ℕ} (v : EuclideanSpace ℝ (Fin d)) :
    ‖v‖ ^ 2 = ∑ i : Fin d, (v i) ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  simp [sq]

private theorem c54_ratPointToEuclidean_apply {d : ℕ} (q : Fin d → ℚ) (i : Fin d) :
    ratPointToEuclidean q i = (q i : ℝ) := by
  simp [ratPointToEuclidean]

private theorem c54_isUnitVec_norm_inv_smul {d : ℕ} {v : EuclideanSpace ℝ (Fin d)} (hv : v ≠ 0) :
    IsUnitVec (‖v‖⁻¹ • v) := by
  unfold IsUnitVec
  rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm,
    inv_mul_cancel₀ (norm_ne_zero_iff.mpr hv)]

private theorem c54_isUnitVec_lifted {d : ℕ} {A B : ℚ} (hAB : A ^ 2 + B ^ 2 = 1)
    {u : EuclideanSpace ℝ (Fin d)} (hu : IsUnitVec u) (s : ℝ) (hs : s ^ 2 = (B : ℝ) ^ 2) :
    IsUnitVec (liftedPoint ((A : ℝ) • u) s) := by
  unfold IsUnitVec at hu ⊢
  have hsq : ‖liftedPoint ((A : ℝ) • u) s‖ ^ 2 = 1 := by
    rw [← real_inner_self_eq_norm_sq, c54_inner_liftedPoint, real_inner_self_eq_norm_sq,
      norm_smul, Real.norm_eq_abs, hu, mul_one, sq_abs, ← sq s, hs]
    exact_mod_cast hAB
  have hnn : 0 ≤ ‖liftedPoint ((A : ℝ) • u) s‖ := norm_nonneg _
  nlinarith

private theorem c54_pos_smul_normalize {d : ℕ} {c : ℝ} (hc : 0 < c)
    (v : EuclideanSpace ℝ (Fin d)) :
    ‖c • v‖⁻¹ • (c • v) = ‖v‖⁻¹ • v := by
  have hsc : c⁻¹ * ‖v‖⁻¹ * c = ‖v‖⁻¹ := by
    field_simp [hc.ne']
  rw [norm_smul, Real.norm_eq_abs, abs_of_pos hc, mul_inv, smul_smul, hsc]

private theorem c54_normalize_dist_le {d : ℕ} {w z : EuclideanSpace ℝ (Fin d)} {r : ℝ}
    (hz : IsUnitVec z) (hwz : ‖w - z‖ ≤ r) (hr1 : r < 1) :
    w ≠ 0 ∧ ‖‖w‖⁻¹ • w - z‖ ≤ 2 * r := by
  unfold IsUnitVec at hz
  have hw_pos : 0 < ‖w‖ := by
    have htri : ‖z‖ ≤ ‖w‖ + ‖w - z‖ := norm_le_insert w z
    rw [hz] at htri
    linarith
  have hw_ne : w ≠ 0 := norm_pos_iff.mp hw_pos
  refine ⟨hw_ne, ?_⟩
  have h1 : ‖‖w‖⁻¹ • w - w‖ = |1 - ‖w‖| := by
    have hsub : ‖w‖⁻¹ • w - w = (‖w‖⁻¹ - 1) • w := by
      rw [sub_smul, one_smul]
    have hmul : |(‖w‖⁻¹ - 1)| * ‖w‖ = |1 - ‖w‖| := by
      calc
        |(‖w‖⁻¹ - 1)| * ‖w‖ = |(‖w‖⁻¹ - 1)| * |‖w‖| := by rw [abs_of_pos hw_pos]
        _ = |(‖w‖⁻¹ - 1) * ‖w‖| := (abs_mul _ _).symm
        _ = |1 - ‖w‖| := by
            congr 1
            field_simp [hw_pos.ne']
    rw [hsub, norm_smul, Real.norm_eq_abs, hmul]
  have h2 : |1 - ‖w‖| ≤ ‖w - z‖ := by
    rw [← hz, abs_sub_comm]
    exact abs_norm_sub_norm_le w z
  have htri2 : ‖‖w‖⁻¹ • w - z‖ ≤ ‖‖w‖⁻¹ • w - w‖ + ‖w - z‖ :=
    norm_sub_le_norm_sub_add_norm_sub _ w _
  linarith

private theorem c54_coord_abs_le_one {d : ℕ} {z : EuclideanSpace ℝ (Fin d)}
    (hz : IsUnitVec z) (i : Fin d) :
    -1 ≤ z i ∧ z i ≤ 1 := by
  unfold IsUnitVec at hz
  have hsum : ∑ j : Fin d, (z j) ^ 2 = 1 := by
    rw [← c54_norm_sq_eq_sum, hz, one_pow]
  have hle : (z i) ^ 2 ≤ ∑ j : Fin d, (z j) ^ 2 :=
    Finset.single_le_sum (fun j _ => sq_nonneg (z j)) (Finset.mem_univ i)
  rw [hsum] at hle
  constructor <;> nlinarith

private theorem c54_mem_sphere_iff {d : ℕ} (v : EuclideanSpace ℝ (Fin d)) :
    v ∈ Metric.sphere (0 : EuclideanSpace ℝ (Fin d)) 1 ↔ IsUnitVec v := by
  rw [Metric.mem_sphere, dist_zero_right]
  rfl

private theorem c54_exists_neg_margin {d : ℕ} (b e A B : ℚ)
    (h_neg : ∀ u z z_hat : EuclideanSpace ℝ (Fin d),
      IsUnitVec u → IsUnitVec z → IsUnitVec z_hat →
      ‖z_hat - z‖ ≤ (e : ℝ) / 8 →
      inner ℝ z u ≤ (b : ℝ) →
      inner ℝ (liftedPoint ((A : ℝ) • z_hat) (-(B : ℝ)))
        (liftedPoint ((A : ℝ) • u) (B : ℝ)) < 0) :
    ∃ δ : ℝ, 0 < δ ∧
      ∀ u z z_hat : EuclideanSpace ℝ (Fin d),
        IsUnitVec u → IsUnitVec z → IsUnitVec z_hat →
        ‖z_hat - z‖ ≤ (e : ℝ) / 8 →
        inner ℝ z u ≤ (b : ℝ) →
        inner ℝ (liftedPoint ((A : ℝ) • z_hat) (-(B : ℝ)))
          (liftedPoint ((A : ℝ) • u) (B : ℝ)) ≤ -δ := by
  let E := EuclideanSpace ℝ (Fin d)
  let S : Set E := Metric.sphere (0 : E) 1
  have hS : IsCompact S := isCompact_sphere (0 : E) 1
  let P3 : Set (E × E × E) := S ×ˢ (S ×ˢ S)
  have hP3 : IsCompact P3 := hS.prod (hS.prod hS)
  let C1 : Set (E × E × E) := {p | ‖p.2.2 - p.2.1‖ ≤ (e : ℝ) / 8}
  let C2 : Set (E × E × E) := {p | inner ℝ p.2.1 p.1 ≤ (b : ℝ)}
  have hC1 : IsClosed C1 :=
    isClosed_le ((continuous_snd.comp continuous_snd).sub
      (continuous_fst.comp continuous_snd)).norm continuous_const
  have hC2 : IsClosed C2 :=
    isClosed_le (Continuous.inner (continuous_fst.comp continuous_snd) continuous_fst)
      continuous_const
  let K : Set (E × E × E) := P3 ∩ (C1 ∩ C2)
  have hK_compact : IsCompact K := hP3.inter_right (hC1.inter hC2)
  let f : E × E × E → ℝ := fun p =>
    inner ℝ (liftedPoint ((A : ℝ) • p.2.2) (-(B : ℝ))) (liftedPoint ((A : ℝ) • p.1) (B : ℝ))
  have hf_eq : ∀ p : E × E × E,
      f p = (A : ℝ) ^ 2 * inner ℝ p.2.2 p.1 - (B : ℝ) ^ 2 := by
    intro p
    dsimp [f]
    rw [c54_inner_liftedPoint, inner_smul_left, inner_smul_right, RCLike.conj_to_real]
    ring
  have hf_cont : Continuous f := by
    rw [funext hf_eq]
    exact ((continuous_const.mul
      (Continuous.inner (continuous_snd.comp continuous_snd) continuous_fst)).sub
      continuous_const)
  by_cases hKne : K.Nonempty
  · obtain ⟨p₀, hp₀K, hp₀max⟩ := hK_compact.exists_isMaxOn hKne hf_cont.continuousOn
    have hp3 : p₀ ∈ P3 := hp₀K.1
    have hdist0 : ‖p₀.2.2 - p₀.2.1‖ ≤ (e : ℝ) / 8 := hp₀K.2.1
    have hle0 : inner ℝ p₀.2.1 p₀.1 ≤ (b : ℝ) := hp₀K.2.2
    have hu0' : IsUnitVec p₀.1 := (c54_mem_sphere_iff p₀.1).mp hp3.1
    have hz0' : IsUnitVec p₀.2.1 := (c54_mem_sphere_iff p₀.2.1).mp hp3.2.1
    have hzh0' : IsUnitVec p₀.2.2 := (c54_mem_sphere_iff p₀.2.2).mp hp3.2.2
    have hf_lt : f p₀ < 0 := h_neg p₀.1 p₀.2.1 p₀.2.2 hu0' hz0' hzh0' hdist0 hle0
    refine ⟨-f p₀, by linarith, fun u z z_hat hu hz hzh hdist hle => ?_⟩
    have hmem : (u, z, z_hat) ∈ K :=
      ⟨⟨(c54_mem_sphere_iff u).mpr hu,
        (c54_mem_sphere_iff z).mpr hz,
        (c54_mem_sphere_iff z_hat).mpr hzh⟩, hdist, hle⟩
    have hmax : f (u, z, z_hat) ≤ f p₀ := hp₀max hmem
    linarith
  · refine ⟨1, zero_lt_one, fun u z z_hat hu hz hzh hdist hle => ?_⟩
    exfalso
    apply hKne
    exact ⟨(u, z, z_hat),
      ⟨⟨(c54_mem_sphere_iff u).mpr hu,
        (c54_mem_sphere_iff z).mpr hz,
        (c54_mem_sphere_iff z_hat).mpr hzh⟩, hdist, hle⟩⟩

private theorem c54_net_raw {d : ℕ} (hd : 1 ≤ d) {e : ℚ} (he0 : 0 < e)
    (he_le_16 : (e : ℝ) ≤ 1 / 16) :
    ∃ (N_net : Finset (EuclideanSpace ℝ (Fin d)))
      (roundLat : EuclideanSpace ℝ (Fin d) → (Fin d → ℤ)),
      let roundDir : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
        fun z =>
          let v := ratPointToEuclidean (fun i => (roundLat z i : ℚ))
          ‖v‖⁻¹ • v
      N_net.Nonempty ∧
      (∀ z_hat ∈ N_net, IsUnitVec z_hat ∧
        ∃ m : Fin d → ℤ, m ≠ 0 ∧
          let v := ratPointToEuclidean (fun i => (m i : ℚ))
          z_hat = ‖v‖⁻¹ • v) ∧
      Real.log (N_net.card : ℝ) ≤ 3 * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) ∧
      (∀ z : EuclideanSpace ℝ (Fin d), IsUnitVec z →
        roundLat z ≠ 0 ∧
        roundDir z ∈ N_net ∧
        IsUnitVec (roundDir z) ∧
        ‖roundDir z - z‖ ≤ (e : ℝ) / 8) := by
  classical
  have he0_r : (0 : ℝ) < (e : ℝ) := by exact_mod_cast he0
  have hd_r : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  let x : ℝ := (d : ℝ) / (e : ℝ)
  have hx16 : 16 ≤ x := by
    dsimp [x]
    rw [le_div_iff₀ he0_r]
    linarith
  let M : ℕ := Nat.ceil (16 * x)
  have hM_ge_real : 16 * x ≤ (M : ℝ) := Nat.le_ceil _
  have hM_pos_real : (0 : ℝ) < (M : ℝ) := by linarith
  have hM_lt_real : (M : ℝ) < 16 * x + 1 := Nat.ceil_lt_add_one (by positivity)
  let roundLat : EuclideanSpace ℝ (Fin d) → (Fin d → ℤ) :=
    fun z i => Int.floor ((M : ℝ) * z i + 1 / 2)
  let roundDir : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
    fun z =>
      let v := ratPointToEuclidean (fun i => (roundLat z i : ℚ))
      ‖v‖⁻¹ • v
  let I_box : Finset ℤ := Finset.Icc (-(M : ℤ)) (M : ℤ)
  let Box : Finset (Fin d → ℤ) :=
    (Fintype.piFinset (fun _ : Fin d => I_box)).filter (fun m => m ≠ 0)
  let toDir : (Fin d → ℤ) → EuclideanSpace ℝ (Fin d) :=
    fun m =>
      let v := ratPointToEuclidean (fun i => (m i : ℚ))
      ‖v‖⁻¹ • v
  let N_net : Finset (EuclideanSpace ℝ (Fin d)) := Box.image toDir
  have h_round_props : ∀ z : EuclideanSpace ℝ (Fin d), IsUnitVec z →
      roundLat z ≠ 0 ∧
      roundDir z ∈ N_net ∧
      IsUnitVec (roundDir z) ∧
      ‖roundDir z - z‖ ≤ (e : ℝ) / 8 := by
    intro z hz
    have h_mem_I : ∀ i : Fin d, roundLat z i ∈ I_box := by
      intro i
      obtain ⟨hzi_lo, hzi_hi⟩ := c54_coord_abs_le_one hz i
      have hfl_le : (roundLat z i : ℝ) ≤ (M : ℝ) * z i + 1 / 2 := Int.floor_le _
      have hfl_gt : (M : ℝ) * z i + 1 / 2 - 1 < (roundLat z i : ℝ) := by
        have := Int.lt_floor_add_one ((M : ℝ) * z i + 1 / 2)
        linarith
      have h_lo_r : (-(M : ℤ) - 1 : ℝ) < (roundLat z i : ℝ) := by
        have h1 : -(M : ℝ) ≤ (M : ℝ) * z i := by nlinarith
        push_cast
        linarith
      have h_hi_r : (roundLat z i : ℝ) < ((M : ℤ) + 1 : ℝ) := by
        have h1 : (M : ℝ) * z i ≤ (M : ℝ) := by nlinarith
        push_cast
        linarith
      have h_lo_z : -(M : ℤ) - 1 < roundLat z i := by exact_mod_cast h_lo_r
      have h_hi_z : roundLat z i < (M : ℤ) + 1 := by exact_mod_cast h_hi_r
      exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
    let v : EuclideanSpace ℝ (Fin d) := ratPointToEuclidean (fun i => (roundLat z i : ℚ))
    let w : EuclideanSpace ℝ (Fin d) := (M : ℝ)⁻¹ • v
    have hw_dist_sq : ‖w - z‖ ^ 2 ≤ ((d : ℝ) / (2 * (M : ℝ))) ^ 2 := by
      rw [c54_norm_sq_eq_sum]
      have hcoord : ∀ i : Fin d, ((w - z) i) ^ 2 ≤ (1 / (2 * (M : ℝ))) ^ 2 := by
        intro i
        have hfl_le : (roundLat z i : ℝ) ≤ (M : ℝ) * z i + 1 / 2 := Int.floor_le _
        have hfl_gt : (M : ℝ) * z i - 1 / 2 ≤ (roundLat z i : ℝ) := by
          have := Int.lt_floor_add_one ((M : ℝ) * z i + 1 / 2)
          linarith
        have hwi : (w - z) i = ((roundLat z i : ℝ) - (M : ℝ) * z i) / (M : ℝ) := by
          simp only [w, v, PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul,
            c54_ratPointToEuclidean_apply, Rat.cast_intCast]
          field_simp [hM_pos_real.ne']
        have hnum : ((roundLat z i : ℝ) - (M : ℝ) * z i) ^ 2 ≤ (1 / 2 : ℝ) ^ 2 := by nlinarith
        rw [hwi, div_pow]
        calc
          ((roundLat z i : ℝ) - (M : ℝ) * z i) ^ 2 / (M : ℝ) ^ 2
              ≤ (1 / 2 : ℝ) ^ 2 / (M : ℝ) ^ 2 := div_le_div_of_nonneg_right hnum (sq_nonneg _)
          _ = (1 / (2 * (M : ℝ))) ^ 2 := by ring
      calc
        ∑ i : Fin d, ((w - z) i) ^ 2
            ≤ ∑ _i : Fin d, (1 / (2 * (M : ℝ))) ^ 2 := Finset.sum_le_sum (fun i _ => hcoord i)
        _ = (d : ℝ) * (1 / (2 * (M : ℝ))) ^ 2 := by simp
        _ ≤ (d : ℝ) ^ 2 * (1 / (2 * (M : ℝ))) ^ 2 := by
            refine mul_le_mul_of_nonneg_right ?_ (sq_nonneg _)
            nlinarith
        _ = ((d : ℝ) / (2 * (M : ℝ))) ^ 2 := by ring
    have hw_dist : ‖w - z‖ ≤ (e : ℝ) / 32 := by
      have h1 : ‖w - z‖ ≤ (d : ℝ) / (2 * (M : ℝ)) := by
        have hnn1 : 0 ≤ ‖w - z‖ := norm_nonneg _
        have hnn2 : 0 ≤ (d : ℝ) / (2 * (M : ℝ)) := by positivity
        nlinarith
      have h2 : (d : ℝ) / (2 * (M : ℝ)) ≤ (e : ℝ) / 32 := by
        rw [div_le_div_iff₀ (by positivity) (by norm_num)]
        have h16x : 16 * (d : ℝ) / (e : ℝ) ≤ (M : ℝ) := by
          simpa [x, mul_div_assoc] using hM_ge_real
        have hmul : 16 * (d : ℝ) ≤ (M : ℝ) * (e : ℝ) := (div_le_iff₀ he0_r).mp h16x
        linarith
      exact h1.trans h2
    have he32_lt1 : (e : ℝ) / 32 < 1 := by linarith
    obtain ⟨hw_ne, hnorm_dist⟩ := c54_normalize_dist_le hz hw_dist he32_lt1
    have hv_ne : v ≠ 0 := by
      intro hv0
      apply hw_ne
      simp [w, hv0]
    have hm_ne : roundLat z ≠ 0 := by
      intro hm0
      apply hv_ne
      ext i
      simp [v, c54_ratPointToEuclidean_apply, hm0]
    have hm_box : roundLat z ∈ Box := by
      refine Finset.mem_filter.mpr ⟨?_, hm_ne⟩
      exact Fintype.mem_piFinset.mpr h_mem_I
    have hrd_eq : roundDir z = ‖w‖⁻¹ • w := by
      dsimp [roundDir, w, v]
      exact (c54_pos_smul_normalize (inv_pos.mpr hM_pos_real) v).symm
    have hrd_mem : roundDir z ∈ N_net :=
      Finset.mem_image.mpr ⟨roundLat z, hm_box, rfl⟩
    have hrd_unit : IsUnitVec (roundDir z) := c54_isUnitVec_norm_inv_smul hv_ne
    have hrd_dist : ‖roundDir z - z‖ ≤ (e : ℝ) / 8 := by
      rw [hrd_eq]
      linarith
    exact ⟨hm_ne, hrd_mem, hrd_unit, hrd_dist⟩
  let z0 : EuclideanSpace ℝ (Fin d) := EuclideanSpace.single (⟨0, by omega⟩ : Fin d) (1 : ℝ)
  have hz0_unit : IsUnitVec z0 := by
    unfold IsUnitVec z0
    simp
  have hN_nonempty : N_net.Nonempty :=
    ⟨roundDir z0, (h_round_props z0 hz0_unit).2.1⟩
  have hN_elems : ∀ z_hat ∈ N_net, IsUnitVec z_hat ∧
      ∃ m : Fin d → ℤ, m ≠ 0 ∧
        let v := ratPointToEuclidean (fun i => (m i : ℚ))
        z_hat = ‖v‖⁻¹ • v := by
    intro z_hat hzh
    rcases Finset.mem_image.mp hzh with ⟨m, hmBox, rfl⟩
    have hm_ne : m ≠ 0 := (Finset.mem_filter.mp hmBox).2
    have hv_ne : ratPointToEuclidean (fun i => (m i : ℚ)) ≠ 0 := by
      intro hv0
      apply hm_ne
      funext i
      have hi := congrArg (fun u : EuclideanSpace ℝ (Fin d) => u i) hv0
      simp only [c54_ratPointToEuclidean_apply, PiLp.zero_apply, Rat.cast_intCast,
        Int.cast_eq_zero] at hi
      exact hi
    exact ⟨c54_isUnitVec_norm_inv_smul hv_ne, m, hm_ne, rfl⟩
  have hN_card_log : Real.log (N_net.card : ℝ) ≤ 3 * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) := by
    have hcard_I : I_box.card = 2 * M + 1 := by
      simp only [I_box, Int.card_Icc]
      omega
    have hcard_le_nat : N_net.card ≤ (2 * M + 1) ^ d := by
      calc
        N_net.card ≤ Box.card := Finset.card_image_le
        _ ≤ (Fintype.piFinset (fun _ : Fin d => I_box)).card := Finset.card_filter_le _ _
        _ = ∏ _i : Fin d, I_box.card := Fintype.card_piFinset _
        _ = (2 * M + 1) ^ d := by simp [hcard_I]
    have hcard_pos : (0 : ℝ) < (N_net.card : ℝ) := by
      exact_mod_cast hN_nonempty.card_pos
    have h2M1_le : ((2 * M + 1 : ℕ) : ℝ) ≤ x ^ 3 := by
      have h1 : ((2 * M + 1 : ℕ) : ℝ) < 32 * x + 3 := by
        push_cast
        linarith
      have hx2 : 256 ≤ x ^ 2 := by nlinarith
      have hx3 : 256 * x ≤ x ^ 3 := by nlinarith
      linarith
    have hcard_le_pow : (N_net.card : ℝ) ≤ (x ^ 3) ^ d := by
      have h1 : (N_net.card : ℝ) ≤ ((2 * M + 1 : ℕ) : ℝ) ^ d := by exact_mod_cast hcard_le_nat
      exact h1.trans (pow_le_pow_left₀ (by positivity) h2M1_le d)
    calc
      Real.log (N_net.card : ℝ) ≤ Real.log ((x ^ 3) ^ d) :=
        Real.log_le_log hcard_pos hcard_le_pow
      _ = (d : ℝ) * Real.log (x ^ 3) := Real.log_pow _ _
      _ = (d : ℝ) * ((3 : ℕ) * Real.log x) := by rw [Real.log_pow]
      _ = 3 * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) := by push_cast; ring
  exact ⟨N_net, roundLat, hN_nonempty, hN_elems, hN_card_log, h_round_props⟩

private theorem c54_search_interface_part {d : ℕ}
    (a b : ℚ) (h δ : ℝ) (hδ_pos : 0 < δ)
    (padData padQuery : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)))
    (roundDir : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d))
    (h_pad_pair : ∀ (u z : EuclideanSpace ℝ (Fin d)), IsUnitVec u → IsUnitVec z →
      IsUnitVec (padData u) ∧
      IsUnitVec (padQuery (roundDir z)) ∧
      ((a : ℝ) ≤ inner ℝ z u →
        h ≤ inner ℝ (padQuery (roundDir z)) (padData u) ∧ (b : ℝ) < inner ℝ z u) ∧
      (¬ ((b : ℝ) < inner ℝ z u) →
        inner ℝ (padQuery (roundDir z)) (padData u) ≤ -δ ∧
        inner ℝ (padQuery (roundDir z)) (padData u) < 0))
    (ι : Type) (u_pts : ι → EuclideanSpace ℝ (Fin d)) (P : Finset ι)
    (hP_unit : ∀ i ∈ P, IsUnitVec (u_pts i))
    (z : EuclideanSpace ℝ (Fin d)) (hz : IsUnitVec z) :
    let pts_pad : ι → EuclideanSpace ℝ (Fin (d + 1)) := fun i => padData (u_pts i)
    let z_pad : EuclideanSpace ℝ (Fin (d + 1)) := padQuery (roundDir z)
    let accept : ι → Prop := fun i => (b : ℝ) < inner ℝ z (u_pts i)
    (∀ i ∈ P, (a : ℝ) ≤ inner ℝ z (u_pts i) →
      IsSearchTarget pts_pad P h z_pad i ∧ accept i) ∧
    IsCompatibleTest pts_pad P z_pad accept ∧
    IsMarginCompatibleTest pts_pad P δ z_pad accept := by
  intro pts_pad z_pad accept
  refine ⟨?_, ?_, ?_⟩
  · intro i hiP ha_le
    have hpair := (h_pad_pair (u_pts i) z (hP_unit i hiP) hz).2.2.1 ha_le
    refine ⟨⟨hiP, ?_⟩, hpair.2⟩
    change h ≤ inner ℝ (padData (u_pts i)) (padQuery (roundDir z))
    rw [real_inner_comm]
    exact hpair.1
  · intro i hiP hrej
    have hpair := (h_pad_pair (u_pts i) z (hP_unit i hiP) hz).2.2.2 hrej
    change inner ℝ (padData (u_pts i)) (padQuery (roundDir z)) ≤ 0
    rw [real_inner_comm]
    exact hpair.2.le
  · refine ⟨hδ_pos, fun i hiP hrej => ?_⟩
    have hpair := (h_pad_pair (u_pts i) z (hP_unit i hiP) hz).2.2.2 hrej
    change inner ℝ (padData (u_pts i)) (padQuery (roundDir z)) ≤ -δ
    rw [real_inner_comm]
    exact hpair.1

private theorem c54_real_cap_equiv {R L s : ℝ} (hs : 0 < s) :
    R * s ≤ L ↔
      ((0 ≤ R ∧ 0 ≤ L ∧ R ^ 2 * s ^ 2 ≤ L ^ 2) ∨
       (R < 0 ∧ (0 ≤ L ∨ L ^ 2 ≤ R ^ 2 * s ^ 2))) := by
  constructor
  · intro h
    by_cases hR : 0 ≤ R
    · left
      have hRs : 0 ≤ R * s := mul_nonneg hR hs.le
      have hL : 0 ≤ L := le_trans hRs h
      refine ⟨hR, hL, ?_⟩
      nlinarith
    · right
      push_neg at hR
      refine ⟨hR, ?_⟩
      by_cases hL : 0 ≤ L
      · exact Or.inl hL
      · push_neg at hL
        right
        nlinarith
  · rintro (⟨hR, hL, hsq⟩ | ⟨hR, hL | hsq⟩)
    · have hRs : 0 ≤ R * s := mul_nonneg hR hs.le
      nlinarith
    · have hRs : R * s < 0 := mul_neg_of_neg_of_pos hR hs
      linarith
    · have hRs : R * s < 0 := mul_neg_of_neg_of_pos hR hs
      by_cases hL0 : 0 ≤ L
      · linarith
      · push_neg at hL0
        nlinarith

private theorem c54_rat_sq_mul_le_iff (r n l : ℚ) :
    (r : ℝ) ^ 2 * (n : ℝ) ≤ (l : ℝ) ^ 2 ↔ r ^ 2 * n ≤ l ^ 2 := by
  norm_cast

private theorem c54_rat_sq_le_mul_iff (l r n : ℚ) :
    (l : ℝ) ^ 2 ≤ (r : ℝ) ^ 2 * (n : ℝ) ↔ l ^ 2 ≤ r ^ 2 * n := by
  norm_cast

private theorem c54_cap_part {d : ℕ} {A B : ℚ} (hAB : A ^ 2 + B ^ 2 = 1)
    (w : Fin d → ℚ) (hw : w ≠ 0) (G : Fin (d + 1) → ℚ) (a₀ : ℚ) :
    let padData : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
      fun u => liftedPoint ((A : ℝ) • u) (B : ℝ)
    let w_E : EuclideanSpace ℝ (Fin d) := ratPointToEuclidean w
    let u_w : EuclideanSpace ℝ (Fin d) := ‖w_E‖⁻¹ • w_E
    let G_E : EuclideanSpace ℝ (Fin (d + 1)) := ratPointToEuclidean G
    let G_base : EuclideanSpace ℝ (Fin d) := liftedBase G_E
    let G_last : ℚ := G (Fin.last d)
    let L_val : ℚ := A * ∑ i : Fin d, G (Fin.castSucc i) * w i
    let R_coef : ℚ := a₀ - B * G_last
    let normSq : ℚ := ∑ i : Fin d, (w i) ^ 2
    IsUnitVec u_w ∧
    IsUnitVec (padData u_w) ∧
    ((a₀ : ℝ) ≤ inner ℝ G_E (padData u_w) ↔
      ((a₀ : ℝ) - (B : ℝ) * (G_last : ℝ)) * ‖w_E‖ ≤ (A : ℝ) * inner ℝ G_base w_E) ∧
    (((a₀ : ℝ) - (B : ℝ) * (G_last : ℝ)) * ‖w_E‖ ≤ (A : ℝ) * inner ℝ G_base w_E ↔
      ((0 ≤ R_coef ∧ 0 ≤ L_val ∧ R_coef ^ 2 * normSq ≤ L_val ^ 2) ∨
       (R_coef < 0 ∧ (0 ≤ L_val ∨ L_val ^ 2 ≤ R_coef ^ 2 * normSq)))) := by
  intro padData w_E u_w G_E G_base G_last L_val R_coef normSq
  have hw_E_ne : w_E ≠ 0 := by
    intro h0
    apply hw
    funext i
    have hi := congrArg (fun u : EuclideanSpace ℝ (Fin d) => u i) h0
    simp only [w_E, c54_ratPointToEuclidean_apply, PiLp.zero_apply, Rat.cast_eq_zero] at hi
    exact hi
  have hw_pos : 0 < ‖w_E‖ := norm_pos_iff.mpr hw_E_ne
  have hu_w_unit : IsUnitVec u_w := c54_isUnitVec_norm_inv_smul hw_E_ne
  have hpad_unit : IsUnitVec (padData u_w) :=
    c54_isUnitVec_lifted hAB hu_w_unit (B : ℝ) rfl
  have h_inner_exp : inner ℝ G_E (padData u_w) =
      (A : ℝ) * ‖w_E‖⁻¹ * inner ℝ G_base w_E + (B : ℝ) * (G_last : ℝ) := by
    dsimp only [padData, u_w]
    rw [real_inner_comm, c54_inner_liftedPoint_left]
    have hh : liftedHeight G_E = (G_last : ℝ) := by
      unfold liftedHeight
      simp [G_E, G_last, c54_ratPointToEuclidean_apply]
    rw [hh, inner_smul_left, inner_smul_left, RCLike.conj_to_real, RCLike.conj_to_real,
      real_inner_comm w_E G_base]
    ring
  have h_cap_iff1 : (a₀ : ℝ) ≤ inner ℝ G_E (padData u_w) ↔
      ((a₀ : ℝ) - (B : ℝ) * (G_last : ℝ)) * ‖w_E‖ ≤ (A : ℝ) * inner ℝ G_base w_E := by
    rw [h_inner_exp]
    have hdiv : (A : ℝ) * ‖w_E‖⁻¹ * inner ℝ G_base w_E =
        ((A : ℝ) * inner ℝ G_base w_E) / ‖w_E‖ := by
      rw [div_eq_mul_inv]
      ring
    rw [hdiv]
    constructor
    · intro h1
      have h2 : (a₀ : ℝ) - (B : ℝ) * (G_last : ℝ) ≤ ((A : ℝ) * inner ℝ G_base w_E) / ‖w_E‖ := by
        linarith
      exact (le_div_iff₀ hw_pos).mp h2
    · intro h1
      have h2 : (a₀ : ℝ) - (B : ℝ) * (G_last : ℝ) ≤ ((A : ℝ) * inner ℝ G_base w_E) / ‖w_E‖ :=
        (le_div_iff₀ hw_pos).mpr h1
      linarith
  have hL_cast : (L_val : ℝ) = (A : ℝ) * inner ℝ G_base w_E := by
    simp only [L_val, Rat.cast_mul, Rat.cast_sum]
    congr 1
    rw [PiLp.inner_apply]
    refine Finset.sum_congr rfl (fun i _ => ?_)
    simp only [G_base, G_E, w_E, c54_liftedBase_apply, c54_ratPointToEuclidean_apply,
      RCLike.inner_apply, conj_trivial]
    ring
  have hR_cast : (R_coef : ℝ) = (a₀ : ℝ) - (B : ℝ) * (G_last : ℝ) := by
    simp [R_coef]
  have hN_cast : (normSq : ℝ) = ‖w_E‖ ^ 2 := by
    rw [c54_norm_sq_eq_sum]
    simp only [normSq, w_E, Rat.cast_sum, Rat.cast_pow, c54_ratPointToEuclidean_apply]
  have h_cap_iff2 :
      ((a₀ : ℝ) - (B : ℝ) * (G_last : ℝ)) * ‖w_E‖ ≤ (A : ℝ) * inner ℝ G_base w_E ↔
        ((0 ≤ R_coef ∧ 0 ≤ L_val ∧ R_coef ^ 2 * normSq ≤ L_val ^ 2) ∨
         (R_coef < 0 ∧ (0 ≤ L_val ∨ L_val ^ 2 ≤ R_coef ^ 2 * normSq))) := by
    rw [← hR_cast, ← hL_cast, c54_real_cap_equiv hw_pos, ← hN_cast,
      Rat.cast_nonneg, Rat.cast_nonneg, Rat.cast_lt_zero,
      c54_rat_sq_mul_le_iff R_coef normSq L_val,
      c54_rat_sq_le_mul_iff L_val R_coef normSq]
  exact ⟨hu_w_unit, hpad_unit, h_cap_iff1, h_cap_iff2⟩

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_5_4_queries_and_caps (h_lem_5_6 : S_lem_5_6) : S_clm_5_4_queries_and_caps := by
  have _ := h_lem_5_6
  unfold S_clm_5_4_queries_and_caps
  refine ⟨3, by norm_num, ?_⟩
  intro d hd a b g e A B hb0 hba ha1 hg0 hg_gap he0 he_le hA0 hB0 hAB h padData padQuery h_pad
  have hb0_r : (0 : ℝ) ≤ (b : ℝ) := by exact_mod_cast hb0
  have hba_r : (b : ℝ) < (a : ℝ) := by exact_mod_cast hba
  have ha1_r : (a : ℝ) ≤ 1 := by exact_mod_cast ha1
  have hg1 : g ≤ 1 := by
    have hprod_nn : 0 ≤ (1 + g) * (b : ℝ) := mul_nonneg (by linarith) hb0_r
    linarith
  have he_le_16 : (e : ℝ) ≤ 1 / 16 := by linarith
  obtain ⟨N_net, roundLat, hN_nonempty, hN_elems, hN_card_log, h_round_props⟩ :=
    c54_net_raw hd he0 he_le_16
  obtain ⟨δ, hδ_pos, hδ_bound⟩ :=
    c54_exists_neg_margin b e A B (fun u z z_hat hu hz hzh hdist hle =>
      (h_pad u z z_hat hu hz hzh hdist).2 hle)
  let roundDir : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
    fun z =>
      let v := ratPointToEuclidean (fun i => (roundLat z i : ℚ))
      ‖v‖⁻¹ • v
  have h_pad_pair : ∀ (u z : EuclideanSpace ℝ (Fin d)), IsUnitVec u → IsUnitVec z →
      IsUnitVec (padData u) ∧
      IsUnitVec (padQuery (roundDir z)) ∧
      ((a : ℝ) ≤ inner ℝ z u →
        h ≤ inner ℝ (padQuery (roundDir z)) (padData u) ∧ (b : ℝ) < inner ℝ z u) ∧
      (¬ ((b : ℝ) < inner ℝ z u) →
        inner ℝ (padQuery (roundDir z)) (padData u) ≤ -δ ∧
        inner ℝ (padQuery (roundDir z)) (padData u) < 0) := by
    intro u z hu hz
    obtain ⟨_, _, hrd_unit, hrd_dist⟩ := h_round_props z hz
    have hpd_unit : IsUnitVec (padData u) :=
      c54_isUnitVec_lifted hAB hu (B : ℝ) rfl
    have hpq_unit : IsUnitVec (padQuery (roundDir z)) :=
      c54_isUnitVec_lifted hAB hrd_unit (-(B : ℝ)) (neg_sq (B : ℝ))
    refine ⟨hpd_unit, hpq_unit, ?_, ?_⟩
    · intro ha_le
      exact ⟨(h_pad u z (roundDir z) hu hz hrd_unit hrd_dist).1 ha_le,
        lt_of_lt_of_le hba_r ha_le⟩
    · intro hnot_gt
      have hle_b : inner ℝ z u ≤ (b : ℝ) := le_of_not_gt hnot_gt
      have hle_neg : inner ℝ (padQuery (roundDir z)) (padData u) ≤ -δ :=
        hδ_bound u z (roundDir z) hu hz hrd_unit hrd_dist hle_b
      exact ⟨hle_neg, by linarith⟩
  exact ⟨⟨N_net, roundLat, δ, hN_nonempty, hN_elems, hN_card_log, h_round_props,
    hδ_pos, h_pad_pair,
    c54_search_interface_part a b h δ hδ_pos padData padQuery roundDir h_pad_pair⟩,
    fun w hw G a₀ => c54_cap_part hAB w hw G a₀⟩

end UL
