import UL.Stmt.clm_7_3_global_approx
import UL.Stmt.lem_5_5
import UL.Stmt.clm_5_3_global_factor_c
import UL.Proof.lem_5_5.H1
set_option autoImplicit false

namespace UL.Proof_clm_7_3_global_approx

open UL

private lemma baselinePairLength_nonneg {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (pair : Option (ι × ι)) :
    0 ≤ baselinePairLength pts pair := by
  cases pair with
  | none => simp [baselinePairLength]
  | some _ => simp [baselinePairLength]

private lemma euclideanDistSq_eq_norm_sq {d : ℕ}
    (x y : EuclideanSpace ℝ (Fin d)) :
    euclideanDistSq x y = ‖x - y‖ ^ 2 := by
  rfl

private lemma indexedEuclideanDiam_eq_zero_of_card_le_one {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) {S : Finset ι} (hcard : S.card ≤ 1) :
    indexedEuclideanDiam S pts = 0 := by
  by_cases hS : S.Nonempty
  · have hEq : indexedEuclideanDiam S pts =
        (S ×ˢ S).sup' (hS.product hS) (fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) := by
      unfold indexedEuclideanDiam
      rw [dif_pos hS]
    apply le_antisymm
    · rw [hEq]
      apply Finset.sup'_le
      intro xy hxy
      rcases Finset.mem_product.mp hxy with ⟨hx, hy⟩
      have hxy_eq : xy.1 = xy.2 := Finset.card_le_one.mp hcard xy.1 hx xy.2 hy
      simp [hxy_eq]
    · exact UL.Proof_lem_5_5.indexedEuclideanDiam_nonneg S pts
  · unfold indexedEuclideanDiam
    rw [dif_neg hS]

open Classical in
private lemma exactLeaf_padded {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {T : Finset ι} {leafPair : Option (ι × ι)}
    (hleaf : IsExactLeafAnswer pts T leafPair) :
    (∀ u v : ι, leafPair = some (u, v) → u ∈ T ∧ v ∈ T) ∧
    baselinePairLength pts leafPair = indexedEuclideanDiam T pts ∧
    ∃ leafPair' : Option (ι × ι),
      IsActiveNodePair T leafPair' ∧
      baselinePairLength pts leafPair' = baselinePairLength pts leafPair ∧
      (∀ u v : ι, 0 < ‖pts u - pts v‖ → leafPair' = some (u, v) → leafPair = some (u, v)) := by
  unfold IsExactLeafAnswer at hleaf
  by_cases hle : T.card ≤ 1
  · rw [if_pos hle] at hleaf
    subst hleaf
    refine ⟨(fun _ _ h => by cases h),
      (indexedEuclideanDiam_eq_zero_of_card_le_one pts hle).symm, ?_⟩
    by_cases hNE : T.Nonempty
    · refine ⟨some (hNE.choose, hNE.choose), ⟨hNE.choose_spec, hNE.choose_spec⟩,
        by simp [baselinePairLength], ?_⟩
      intro u v hpos hEq
      cases hEq
      simp at hpos
    · refine ⟨none, Finset.not_nonempty_iff_eq_empty.mp hNE, rfl, ?_⟩
      intro _ _ _ hEq
      cases hEq
  · rw [if_neg hle] at hleaf
    rcases hleaf with ⟨u, v, rfl, hu, hv, _, hnorm⟩
    exact ⟨fun a b h => by cases h; exact ⟨hu, hv⟩, hnorm,
      some (u, v), ⟨hu, hv⟩, rfl, fun _ _ _ h => h⟩

open Classical in
private lemma chainInput_subset {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (j : Fin (k + 1)) :
    chainInput pts nodes P j ⊆ P := by
  induction j using Fin.induction with
  | zero =>
    rfl
  | succ i ih =>
    change (nodes i).residual pts (chainInput pts nodes P i.castSucc) ⊆ P
    unfold ChainNode.residual nodeResidual
    exact Finset.sdiff_subset.trans ih

open Classical in
private lemma chainInput_mem_of_not_in_cores {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    {x : ι} (hx : x ∈ P) :
    ∀ (m : Fin (k + 1)),
      (∀ j : Fin k, j.castSucc < m → x ∉ chainCore pts nodes P j) →
      x ∈ chainInput pts nodes P m := by
  intro m
  induction m using Fin.induction with
  | zero =>
    intro _
    exact hx
  | succ i ih =>
    intro hno
    have hx_prev : x ∈ chainInput pts nodes P i.castSucc := by
      apply ih
      intro j hj
      exact hno j (lt_trans hj Fin.castSucc_lt_succ)
    have hx_notC : x ∉ chainCore pts nodes P i :=
      hno i Fin.castSucc_lt_succ
    change x ∈ (nodes i).residual pts (chainInput pts nodes P i.castSucc)
    unfold ChainNode.residual nodeResidual
    exact Finset.mem_sdiff.mpr ⟨hx_prev, hx_notC⟩

open Classical in
private lemma norm_le_nodeCoreInputDiam {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    {S : Finset ι} {u v : ι}
    (huC : u ∈ nodeCore pts o V S) (hvS : v ∈ S) :
    ‖pts u - pts v‖ ≤ nodeCoreInputDiam pts o V S := by
  have hcond : (nodeCore pts o V S).Nonempty ∧ S.Nonempty := ⟨⟨u, huC⟩, ⟨v, hvS⟩⟩
  have hmem : (u, v) ∈ nodeCore pts o V S ×ˢ S := Finset.mem_product.mpr ⟨huC, hvS⟩
  unfold nodeCoreInputDiam indexedCoreInputDiam
  rw [dif_pos hcond]
  exact Finset.le_sup' (f := fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) hmem

private lemma node_lem_5_5_bound {d : ℕ} {ι : Type} [DecidableEq ι]
    (h_lem_5_5 : S_lem_5_5)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams)
    (N : ChainNode d) (S : Finset ι)
    (basePair : Option (ι × ι))
    (M_i : ShellConfig → Finset (ι × ι))
    (stored_i : ShellConfig → Option (ι × ι))
    (hbase : N.SatisfiesBaselineCond pts S basePair)
    (hmatch : 0 < N.V → ∀ cfg ∈ params.retainedConfigs N.V,
      params.SatisfiesMatchingInvariant pts N.o N.V S cfg.j cfg.k cfg.ℓ (M_i cfg) ∧
      IsStoredMatchingEdge (M_i cfg) (stored_i cfg)) :
    N.coreInputDiam pts S / params.c ≤
      params.nodeRetainedEstimate pts N.V (baselinePairLength pts basePair) stored_i ∧
    params.nodeRetainedEstimate pts N.V (baselinePairLength pts basePair) stored_i ≤
      indexedEuclideanDiam S pts := by
  exact h_lem_5_5 d ι pts N.o N.V S params basePair M_i stored_i N.V_nonneg hbase hmatch

private lemma storedEdge_isStoredMatchingEdge {ι : Type*} (st : LocalMatchingState ι) :
    IsStoredMatchingEdge st.matching st.storedEdge := by
  cases h : st.matchingList with
  | nil =>
    simp [LocalMatchingState.storedEdge, LocalMatchingState.matching, IsStoredMatchingEdge, h]
  | cons e es =>
    simp [LocalMatchingState.storedEdge, LocalMatchingState.matching, IsStoredMatchingEdge, h]

private lemma servingInputAt_eq_chainInput {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (nodesList : List (Alg4ServingNode d ι)) (P : Finset ι) :
    ∀ (r : ℕ) (hr : r ≤ nodesList.length),
      servingChainInputAt pts (nodesList.map Alg4ServingNode.toServingNodeState) P r =
        chainInput pts (fun i : Fin nodesList.length => (nodesList[i]).node) P
          ⟨r, Nat.lt_succ_of_le hr⟩
  | 0, _ => rfl
  | r + 1, hr => by
      have hrk : r < nodesList.length := Nat.lt_of_succ_le hr
      have ih := servingInputAt_eq_chainInput pts nodesList P r (le_of_lt hrk)
      unfold servingChainInputAt
      have hlen_map : r < (nodesList.map Alg4ServingNode.toServingNodeState).length := by
        simpa using hrk
      rw [List.take_add_one, List.getElem?_eq_getElem hlen_map, Option.toList_some,
        List.foldl_append]
      simp only [List.foldl_cons, List.foldl_nil, List.getElem_map,
        Alg4ServingNode.toServingNodeState]
      unfold servingChainInputAt at ih
      rw [ih]
      rfl

private lemma pickMaxByReal_spec {α : Type*} (f : α → ℝ) :
    ∀ (best : α) (xs : List α),
      pickMaxByReal f best xs ∈ best :: xs ∧
      ∀ z ∈ best :: xs, f z ≤ f (pickMaxByReal f best xs)
  | best, [] => by
      simp [pickMaxByReal]
  | best, x :: xs => by
      unfold pickMaxByReal
      by_cases hlt : f best < f x
      · rw [if_pos hlt]
        have ih := pickMaxByReal_spec f x xs
        refine ⟨List.mem_cons_of_mem best ih.1, ?_⟩
        intro z hz
        rcases List.mem_cons.mp hz with hzEq | hzx
        · rw [hzEq]
          exact (le_of_lt hlt).trans (ih.2 x List.mem_cons_self)
        · exact ih.2 z hzx
      · rw [if_neg hlt]
        have hle : f x ≤ f best := le_of_not_gt hlt
        have ih := pickMaxByReal_spec f best xs
        refine ⟨?_, ?_⟩
        · rcases List.mem_cons.mp ih.1 with hEq | hmem
          · rw [hEq]
            exact List.mem_cons_self
          · exact List.mem_cons_of_mem best (List.mem_cons_of_mem x hmem)
        · intro z hz
          rcases List.mem_cons.mp hz with hzEq | hzx
          · rw [hzEq]
            exact ih.2 best List.mem_cons_self
          · rcases List.mem_cons.mp hzx with hzEq | hzxs
            · rw [hzEq]
              exact hle.trans (ih.2 best List.mem_cons_self)
            · exact ih.2 z (List.mem_cons_of_mem best hzxs)

private lemma sn_estimate_eq {d L : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (α : ℝ)
    (sn : Alg4ServingNode d ι) (S_i : Finset ι)
    (hwf : sn.WellFormed (.subSqrt2 params) α L pts S_i) :
    max (baselinePairLength pts sn.baselinePair) (Real.sqrt sn.maxMatchingDistSq) =
      params.nodeRetainedEstimate pts sn.node.V
        (baselinePairLength pts sn.baselinePair)
        (fun cfg => (sn.localMatchings cfg).storedEdge) := by
  let L_base := baselinePairLength pts sn.baselinePair
  have hL_nn : 0 ≤ L_base := baselinePairLength_nonneg pts sn.baselinePair
  have hm := hwf.2.2.2.2.2.2.2.1
  cases hmp : sn.maxMatchingPair with
  | none =>
    rw [hmp] at hm
    rcases hm with ⟨hsq0, hall_none⟩
    have hlhs : max L_base (Real.sqrt sn.maxMatchingDistSq) = L_base := by
      rw [hsq0, Real.sqrt_zero]
      exact max_eq_left hL_nn
    rw [hlhs]
    unfold LocalScaleParams.nodeRetainedEstimate nodeRetainedEstimate
    by_cases hV : 0 < sn.node.V
    · rw [if_pos hV]
      have hret_eq : (Alg4Mode.subSqrt2 params).retainedConfigs sn.node.V =
          retainedConfigs params.e params.γ params.lam params.K sn.node.V := by
        simp [Alg4Mode.retainedConfigs, hV, LocalScaleParams.retainedConfigs]
      unfold matchingEstimateOn
      by_cases hNE : (retainedConfigs params.e params.γ params.lam params.K sn.node.V).Nonempty
      · rw [dif_pos hNE]
        apply le_antisymm
        · have hc0 := hNE.choose_spec
          have hnone0 : (sn.localMatchings hNE.choose).storedEdge = none :=
            hall_none hNE.choose (by rwa [hret_eq])
          have hcand0 : storedEdgeCandidate pts L_base
              (sn.localMatchings hNE.choose).storedEdge = L_base := by
            simp [hnone0, storedEdgeCandidate]
          rw [← hcand0]
          exact Finset.le_sup'
            (f := fun cfg => storedEdgeCandidate pts L_base (sn.localMatchings cfg).storedEdge) hc0
        · apply Finset.sup'_le
          intro cfg hcfg
          dsimp only
          have hnone : (sn.localMatchings cfg).storedEdge = none :=
            hall_none cfg (by rwa [hret_eq])
          rw [hnone]
          exact le_rfl
      · rw [dif_neg hNE]
    · rw [if_neg hV]
  | some xy =>
    rcases xy with ⟨x, y⟩
    rw [hmp] at hm
    rcases hm with ⟨_, _, _, hsq_eq, ⟨cfg0, hcfg0_mem, hcfg0_edge⟩, hall_le⟩
    have hV : 0 < sn.node.V := by
      by_contra hnotV
      simp [Alg4Mode.retainedConfigs, hnotV] at hcfg0_mem
    have hret_eq : (Alg4Mode.subSqrt2 params).retainedConfigs sn.node.V =
        retainedConfigs params.e params.γ params.lam params.K sn.node.V := by
      simp [Alg4Mode.retainedConfigs, hV, LocalScaleParams.retainedConfigs]
    have hcfg0_ret : cfg0 ∈ retainedConfigs params.e params.γ params.lam params.K sn.node.V :=
      hret_eq ▸ hcfg0_mem
    have hNE : (retainedConfigs params.e params.γ params.lam params.K sn.node.V).Nonempty :=
      ⟨cfg0, hcfg0_ret⟩
    have hsqrt_eq : Real.sqrt sn.maxMatchingDistSq = ‖pts x - pts y‖ := by
      rw [hsq_eq, euclideanDistSq_eq_norm_sq, Real.sqrt_sq (norm_nonneg _)]
    unfold LocalScaleParams.nodeRetainedEstimate nodeRetainedEstimate matchingEstimateOn
    rw [if_pos hV, dif_pos hNE]
    apply le_antisymm
    · rw [hsqrt_eq]
      have hcand0 : storedEdgeCandidate pts L_base (sn.localMatchings cfg0).storedEdge =
          max L_base ‖pts x - pts y‖ := by
        simp [hcfg0_edge, storedEdgeCandidate]
      rw [← hcand0]
      exact Finset.le_sup'
        (f := fun cfg => storedEdgeCandidate pts L_base (sn.localMatchings cfg).storedEdge)
        hcfg0_ret
    · apply Finset.sup'_le
      intro cfg hcfg
      dsimp only
      cases hedge : (sn.localMatchings cfg).storedEdge with
      | none =>
        dsimp only [storedEdgeCandidate]
        exact le_max_left _ _
      | some uv =>
        rcases uv with ⟨u, v⟩
        dsimp only [storedEdgeCandidate]
        apply max_le (le_max_left _ _)
        have hle_sq : euclideanDistSq (pts u) (pts v) ≤ sn.maxMatchingDistSq :=
          hall_le cfg (hret_eq.symm ▸ hcfg) u v hedge
        have huv_le : ‖pts u - pts v‖ ≤ Real.sqrt sn.maxMatchingDistSq := by
          rw [← Real.sqrt_sq (norm_nonneg (pts u - pts v)), ← euclideanDistSq_eq_norm_sq]
          exact Real.sqrt_le_sqrt hle_sq
        exact huv_le.trans (le_max_right _ _)

private lemma prove_part3a
    (h_lem_5_5 : S_lem_5_5)
    (h_global_c : S_clm_5_3_global_factor_c) :
    ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (params : LocalScaleParams)
      (P : Finset ι)
      (k : ℕ) (nodes : Fin k → ChainNode d)
      (basePairs : Fin k → Option (ι × ι))
      (M : Fin k → ShellConfig → Finset (ι × ι))
      (stored : Fin k → ShellConfig → Option (ι × ι))
      (leafPair : Option (ι × ι)),
      (∀ i : Fin k,
        (nodes i).SatisfiesBaselineCond pts (chainInput pts nodes P i.castSucc) (basePairs i)) →
      (∀ i : Fin k,
        0 < (nodes i).V →
        ∀ cfg ∈ params.retainedConfigs (nodes i).V,
          params.SatisfiesMatchingInvariant pts (nodes i).o (nodes i).V
            (chainInput pts nodes P i.castSucc) cfg.j cfg.k cfg.ℓ (M i cfg) ∧
          IsStoredMatchingEdge (M i cfg) (stored i cfg)) →
      IsExactLeafAnswer pts (chainTerminal pts nodes P) leafPair →
      let nodeW : Fin k → ℝ := fun i =>
        params.nodeRetainedEstimate pts (nodes i).V
          (baselinePairLength pts (basePairs i)) (stored i)
      let W_max : ℝ :=
        (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty
          (Fin.lastCases (baselinePairLength pts leafPair) nodeW)
      (∀ i : Fin k,
        chainCoreInputDiam pts nodes P i / params.c ≤ nodeW i ∧
        nodeW i ≤ indexedEuclideanDiam (chainInput pts nodes P i.castSucc) pts) ∧
      (∀ x y : ι, x ∈ P → y ∈ P →
        (x ∈ chainTerminal pts nodes P ∧ y ∈ chainTerminal pts nodes P ∧
          ‖pts x - pts y‖ ≤ baselinePairLength pts leafPair) ∨
        (∃ i₀ : Fin k,
          (x ∈ chainCore pts nodes P i₀ ∨ y ∈ chainCore pts nodes P i₀) ∧
          (∀ j : Fin k, j < i₀ →
            x ∉ chainCore pts nodes P j ∧ y ∉ chainCore pts nodes P j) ∧
          x ∈ chainInput pts nodes P i₀.castSucc ∧
          y ∈ chainInput pts nodes P i₀.castSucc ∧
          ‖pts x - pts y‖ / params.c ≤ chainCoreInputDiam pts nodes P i₀ / params.c ∧
          chainCoreInputDiam pts nodes P i₀ / params.c ≤ nodeW i₀)) ∧
      W_max ∈ Set.Icc (indexedEuclideanDiam P pts / params.c) (indexedEuclideanDiam P pts) ∧
      (P.card ≤ 1 → leafPair = none ∧ W_max = 0) ∧
      (2 ≤ P.card →
        ∃ u v : ι,
          IsIndexedFactorCDiameterPair params.c P pts u v ∧
          (0 < W_max →
            ‖pts u - pts v‖ = W_max ∧
            (leafPair = some (u, v) ∨
              (∃ i : Fin k, basePairs i = some (u, v)) ∨
              (∃ i : Fin k, 0 < (nodes i).V ∧
                ∃ cfg ∈ params.retainedConfigs (nodes i).V,
                  stored i cfg = some (u, v))))) := by
  intro d ι _ pts params P k nodes basePairs M stored leafPair hbase hmatch hleaf
  dsimp only
  have hc_pos : 0 < params.c := lt_trans zero_lt_one params.one_lt_c
  obtain ⟨_, hleaf_diam, leafPair', hleaf_act', hleaf_len_eq, hleaf_back⟩ :=
    exactLeaf_padded hleaf
  have h53 := h_global_c.1 d ι k pts P params nodes basePairs M stored leafPair'
    hbase hmatch hleaf_act' (hleaf_len_eq.trans hleaf_diam)
  rw [hleaf_len_eq] at h53
  have hnode : ∀ i : Fin k,
      chainCoreInputDiam pts nodes P i / params.c ≤
        params.nodeRetainedEstimate pts (nodes i).V
          (baselinePairLength pts (basePairs i)) (stored i) ∧
      params.nodeRetainedEstimate pts (nodes i).V
          (baselinePairLength pts (basePairs i)) (stored i) ≤
        indexedEuclideanDiam (chainInput pts nodes P i.castSucc) pts :=
    fun i => node_lem_5_5_bound h_lem_5_5 pts params (nodes i)
      (chainInput pts nodes P i.castSucc) (basePairs i) (M i) (stored i) (hbase i) (hmatch i)
  refine ⟨hnode, ?_, h53.1, ?_, ?_⟩
  · intro x y hxP hyP
    classical
    let hitSet : Finset (Fin k) :=
      Finset.univ.filter (fun j : Fin k =>
        x ∈ chainCore pts nodes P j ∨ y ∈ chainCore pts nodes P j)
    by_cases hNE : hitSet.Nonempty
    · right
      let i₀ : Fin k := hitSet.min' hNE
      have hi₀_mem : i₀ ∈ hitSet := Finset.min'_mem hitSet hNE
      have hi₀_hit : x ∈ chainCore pts nodes P i₀ ∨ y ∈ chainCore pts nodes P i₀ :=
        (Finset.mem_filter.mp hi₀_mem).2
      have hbefore : ∀ j : Fin k, j < i₀ →
          x ∉ chainCore pts nodes P j ∧ y ∉ chainCore pts nodes P j := by
        intro j hj
        have hj_not : j ∉ hitSet := by
          intro hj_in
          exact not_le_of_gt hj (Finset.min'_le hitSet j hj_in)
        simp only [hitSet, Finset.mem_filter, Finset.mem_univ, true_and, not_or] at hj_not
        exact hj_not
      have hxS : x ∈ chainInput pts nodes P i₀.castSucc :=
        chainInput_mem_of_not_in_cores pts nodes P hxP i₀.castSucc
          (fun j hj => (hbefore j (Fin.castSucc_lt_castSucc_iff.mp hj)).1)
      have hyS : y ∈ chainInput pts nodes P i₀.castSucc :=
        chainInput_mem_of_not_in_cores pts nodes P hyP i₀.castSucc
          (fun j hj => (hbefore j (Fin.castSucc_lt_castSucc_iff.mp hj)).2)
      have hnorm_le : ‖pts x - pts y‖ ≤ chainCoreInputDiam pts nodes P i₀ := by
        rcases hi₀_hit with hxC | hyC
        · exact norm_le_nodeCoreInputDiam pts (nodes i₀).o (nodes i₀).V hxC hyS
        · rw [norm_sub_rev (pts x) (pts y)]
          exact norm_le_nodeCoreInputDiam pts (nodes i₀).o (nodes i₀).V hyC hxS
      refine ⟨i₀, hi₀_hit, hbefore, hxS, hyS,
        div_le_div_of_nonneg_right hnorm_le hc_pos.le, (hnode i₀).1⟩
    · left
      have hno_all : ∀ j : Fin k, x ∉ chainCore pts nodes P j ∧ y ∉ chainCore pts nodes P j := by
        intro j
        have hj_not : j ∉ hitSet := fun hm => hNE ⟨j, hm⟩
        simp only [hitSet, Finset.mem_filter, Finset.mem_univ, true_and, not_or] at hj_not
        exact hj_not
      have hxT : x ∈ chainTerminal pts nodes P :=
        chainInput_mem_of_not_in_cores pts nodes P hxP (Fin.last k)
          (fun j _ => (hno_all j).1)
      have hyT : y ∈ chainTerminal pts nodes P :=
        chainInput_mem_of_not_in_cores pts nodes P hyP (Fin.last k)
          (fun j _ => (hno_all j).2)
      have hnorm_le : ‖pts x - pts y‖ ≤ baselinePairLength pts leafPair := by
        rw [hleaf_diam]
        exact UL.Proof_lem_5_5.pair_norm_le_indexedEuclideanDiam _ pts hxT hyT
      exact ⟨hxT, hyT, hnorm_le⟩
  · intro hcard
    have hT_sub : chainTerminal pts nodes P ⊆ P :=
      chainInput_subset pts nodes P (Fin.last k)
    have hT_le : (chainTerminal pts nodes P).card ≤ 1 :=
      (Finset.card_le_card hT_sub).trans hcard
    have hlp_none : leafPair = none := by
      unfold IsExactLeafAnswer at hleaf
      rwa [if_pos hT_le] at hleaf
    have hdiam0 : indexedEuclideanDiam P pts = 0 :=
      indexedEuclideanDiam_eq_zero_of_card_le_one pts hcard
    have hIcc := h53.1
    rw [Set.mem_Icc, hdiam0, zero_div] at hIcc
    exact ⟨hlp_none, le_antisymm hIcc.2 hIcc.1⟩
  · intro hcard2
    obtain ⟨u, v, hpair, hpos_imp⟩ := h53.2 hcard2
    refine ⟨u, v, hpair, fun hWpos => ?_⟩
    obtain ⟨hnorm_eq, hprov⟩ := hpos_imp hWpos
    refine ⟨hnorm_eq, ?_⟩
    rcases hprov with hlp' | hrest
    · exact Or.inl (hleaf_back u v (hnorm_eq.symm ▸ hWpos) hlp')
    · exact Or.inr hrest

theorem prove_part3
    (h_lem_5_5 : S_lem_5_5)
    (h_global_c : S_clm_5_3_global_factor_c) :
    (∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (params : LocalScaleParams)
      (P : Finset ι)
      (k : ℕ) (nodes : Fin k → ChainNode d)
      (basePairs : Fin k → Option (ι × ι))
      (M : Fin k → ShellConfig → Finset (ι × ι))
      (stored : Fin k → ShellConfig → Option (ι × ι))
      (leafPair : Option (ι × ι)),
      (∀ i : Fin k,
        (nodes i).SatisfiesBaselineCond pts (chainInput pts nodes P i.castSucc) (basePairs i)) →
      (∀ i : Fin k,
        0 < (nodes i).V →
        ∀ cfg ∈ params.retainedConfigs (nodes i).V,
          params.SatisfiesMatchingInvariant pts (nodes i).o (nodes i).V
            (chainInput pts nodes P i.castSucc) cfg.j cfg.k cfg.ℓ (M i cfg) ∧
          IsStoredMatchingEdge (M i cfg) (stored i cfg)) →
      IsExactLeafAnswer pts (chainTerminal pts nodes P) leafPair →
      let nodeW : Fin k → ℝ := fun i =>
        params.nodeRetainedEstimate pts (nodes i).V
          (baselinePairLength pts (basePairs i)) (stored i)
      let W_max : ℝ :=
        (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty
          (Fin.lastCases (baselinePairLength pts leafPair) nodeW)
      (∀ i : Fin k,
        chainCoreInputDiam pts nodes P i / params.c ≤ nodeW i ∧
        nodeW i ≤ indexedEuclideanDiam (chainInput pts nodes P i.castSucc) pts) ∧
      (∀ x y : ι, x ∈ P → y ∈ P →
        (x ∈ chainTerminal pts nodes P ∧ y ∈ chainTerminal pts nodes P ∧
          ‖pts x - pts y‖ ≤ baselinePairLength pts leafPair) ∨
        (∃ i₀ : Fin k,
          (x ∈ chainCore pts nodes P i₀ ∨ y ∈ chainCore pts nodes P i₀) ∧
          (∀ j : Fin k, j < i₀ →
            x ∉ chainCore pts nodes P j ∧ y ∉ chainCore pts nodes P j) ∧
          x ∈ chainInput pts nodes P i₀.castSucc ∧
          y ∈ chainInput pts nodes P i₀.castSucc ∧
          ‖pts x - pts y‖ / params.c ≤ chainCoreInputDiam pts nodes P i₀ / params.c ∧
          chainCoreInputDiam pts nodes P i₀ / params.c ≤ nodeW i₀)) ∧
      W_max ∈ Set.Icc (indexedEuclideanDiam P pts / params.c) (indexedEuclideanDiam P pts) ∧
      (P.card ≤ 1 → leafPair = none ∧ W_max = 0) ∧
      (2 ≤ P.card →
        ∃ u v : ι,
          IsIndexedFactorCDiameterPair params.c P pts u v ∧
          (0 < W_max →
            ‖pts u - pts v‖ = W_max ∧
            (leafPair = some (u, v) ∨
              (∃ i : Fin k, basePairs i = some (u, v)) ∨
              (∃ i : Fin k, 0 < (nodes i).V ∧
                ∃ cfg ∈ params.retainedConfigs (nodes i).V,
                  stored i cfg = some (u, v)))))) ∧
    (∀ (d n L D_out : ℕ) (α : ℝ) (params : LocalScaleParams)
      (st : Alg4State d ℕ) (P : DynamicPointSet d),
      P.WellFormed n →
      P.activeHandles = st.activeSet →
      (∀ h ∈ P.activeHandles, P.handleCoords h = st.coords h) →
      st.WellFormed n (.subSqrt2 params) α L D_out →
      st.SatisfiesGoodEvent (.subSqrt2 params) →
        (∀ idx : Fin st.servingNodes.length,
          let sn := st.servingNodes[idx]
          let S_i := st.servingInputAt idx.val
          let W_i := max (baselinePairLength st.coords sn.baselinePair)
            (Real.sqrt sn.maxMatchingDistSq)
          W_i = params.nodeRetainedEstimate st.coords sn.node.V
            (baselinePairLength st.coords sn.baselinePair)
            (fun cfg => (sn.localMatchings cfg).storedEdge) ∧
          sn.node.coreInputDiam st.coords S_i / params.c ≤ W_i ∧
          W_i ≤ indexedEuclideanDiam S_i st.coords) ∧
        IsValidFactorCAnswer params.c P (toStoredDiameterAnswer st.cachedAnswer)) := by
  refine ⟨prove_part3a h_lem_5_5 h_global_c, ?_⟩
  intro d n L D_out α params st P hP hHandles hCoords hst hgood
  rcases hst with ⟨_, hchain_wf, _, hleafSq, hsn_wf, hfb, _, hcached_eq⟩
  let k := st.servingNodes.length
  let nodes : Fin k → ChainNode d := fun i => (st.servingNodes[i]).node
  let basePairs : Fin k → Option (ℕ × ℕ) := fun i => (st.servingNodes[i]).baselinePair
  let M : Fin k → ShellConfig → Finset (ℕ × ℕ) :=
    fun i cfg => ((st.servingNodes[i]).localMatchings cfg).matching
  let stored : Fin k → ShellConfig → Option (ℕ × ℕ) :=
    fun i cfg => ((st.servingNodes[i]).localMatchings cfg).storedEdge
  let leafPair : Option (ℕ × ℕ) := st.terminalLeafAnswer
  have hS_eq : ∀ i : Fin k,
      st.servingInputAt i.val = chainInput st.coords nodes st.activeSet i.castSucc :=
    fun i => servingInputAt_eq_chainInput st.coords st.servingNodes st.activeSet
      i.val (le_of_lt i.isLt)
  have hterm_eq : st.terminalLeaf = chainTerminal st.coords nodes st.activeSet := by
    have h1 := hchain_wf.2.1
    dsimp [Alg4State.toScheduledServingChain] at h1
    rw [List.length_map] at h1
    rw [h1]
    exact servingInputAt_eq_chainInput st.coords st.servingNodes st.activeSet k le_rfl
  have hleaf_exact : IsExactLeafAnswer st.coords
      (chainTerminal st.coords nodes st.activeSet) leafPair := by
    rw [← hterm_eq]
    exact hchain_wf.2.2
  have hbase_all : ∀ i : Fin k,
      (nodes i).SatisfiesBaselineCond st.coords
        (chainInput st.coords nodes st.activeSet i.castSucc) (basePairs i) := by
    intro i
    rw [← hS_eq i]
    exact (hgood i).1
  have hmatch_all : ∀ i : Fin k,
      0 < (nodes i).V →
      ∀ cfg ∈ params.retainedConfigs (nodes i).V,
        params.SatisfiesMatchingInvariant st.coords (nodes i).o (nodes i).V
          (chainInput st.coords nodes st.activeSet i.castSucc) cfg.j cfg.k cfg.ℓ (M i cfg) ∧
        IsStoredMatchingEdge (M i cfg) (stored i cfg) := by
    intro i hVi cfg hcfg
    have hcfg_mode : cfg ∈ (Alg4Mode.subSqrt2 params).retainedConfigs (nodes i).V := by
      simpa [Alg4Mode.retainedConfigs, hVi] using hcfg
    have hgm := (hgood i).2.2 cfg hcfg_mode
    rw [hS_eq i] at hgm
    exact ⟨hgm.2, storedEdge_isStoredMatchingEdge _⟩
  have h3a := prove_part3a h_lem_5_5 h_global_c d ℕ st.coords params st.activeSet
    k nodes basePairs M stored leafPair hbase_all hmatch_all hleaf_exact
  rcases h3a with ⟨hnode_bounds, _, hW_Icc, _, _⟩
  have hfirst : ∀ idx : Fin k,
      let sn := st.servingNodes[idx]
      let S_i := st.servingInputAt idx.val
      let W_i := max (baselinePairLength st.coords sn.baselinePair)
        (Real.sqrt sn.maxMatchingDistSq)
      W_i = params.nodeRetainedEstimate st.coords sn.node.V
        (baselinePairLength st.coords sn.baselinePair)
        (fun cfg => (sn.localMatchings cfg).storedEdge) ∧
      sn.node.coreInputDiam st.coords S_i / params.c ≤ W_i ∧
      W_i ≤ indexedEuclideanDiam S_i st.coords := by
    intro idx
    dsimp only
    have hWi_eq := sn_estimate_eq st.coords params α (st.servingNodes[idx])
      (st.servingInputAt idx.val) (hsn_wf idx)
    have hb := hnode_bounds idx
    unfold chainCoreInputDiam at hb
    dsimp only [nodes, basePairs, stored] at hb
    rw [← hS_eq idx] at hb
    exact ⟨hWi_eq, by linarith [hb.1], by linarith [hb.2]⟩
  refine ⟨hfirst, ?_⟩
  -- Transport between P.activeIds and st.activeSet = P.activeHandles
  have hid_coords : ∀ h ∈ st.activeSet, P.coords (P.idOfHandle h) = st.coords h := by
    intro h hh_st
    have hh : h ∈ P.activeHandles := hHandles.symm ▸ hh_st
    have h1 : P.handleCoords h = st.coords h := hCoords h hh
    unfold DynamicPointSet.handleCoords at h1
    rw [if_pos hh] at h1
    exact h1
  have hcard_eq : P.activeIds.card = st.activeSet.card := by
    rw [← hHandles]
    refine Finset.card_bij (fun id _ => P.handleOfId id) ?_ ?_ ?_
    · intro id hid
      exact (hP.2.1 id hid).1
    · intro id1 hid1 id2 hid2 hEq
      dsimp only at hEq
      have h1 := (hP.2.1 id1 hid1).2
      have h2 := (hP.2.1 id2 hid2).2
      rw [← h1, ← h2, hEq]
    · intro h hh
      exact ⟨P.idOfHandle h, (hP.2.2.1 h hh).1, (hP.2.2.1 h hh).2⟩
  have hdiam_eq : indexedEuclideanDiam P.activeIds P.coords =
      indexedEuclideanDiam st.activeSet st.coords := by
    by_cases hNE_id : P.activeIds.Nonempty
    · have hNE_st : st.activeSet.Nonempty := by
        rcases hNE_id with ⟨id0, hid0⟩
        exact ⟨P.handleOfId id0, hHandles ▸ (hP.2.1 id0 hid0).1⟩
      apply le_antisymm
      · unfold indexedEuclideanDiam
        rw [dif_pos hNE_id]
        apply Finset.sup'_le
        intro xy hxy
        rcases Finset.mem_product.mp hxy with ⟨hx, hy⟩
        have hxH : P.handleOfId xy.1 ∈ st.activeSet := hHandles ▸ (hP.2.1 xy.1 hx).1
        have hyH : P.handleOfId xy.2 ∈ st.activeSet := hHandles ▸ (hP.2.1 xy.2 hy).1
        have hcx : P.coords xy.1 = st.coords (P.handleOfId xy.1) := by
          have := hid_coords (P.handleOfId xy.1) hxH
          rwa [(hP.2.1 xy.1 hx).2] at this
        have hcy : P.coords xy.2 = st.coords (P.handleOfId xy.2) := by
          have := hid_coords (P.handleOfId xy.2) hyH
          rwa [(hP.2.1 xy.2 hy).2] at this
        rw [hcx, hcy]
        exact UL.Proof_lem_5_5.pair_norm_le_indexedEuclideanDiam st.activeSet st.coords hxH hyH
      · unfold indexedEuclideanDiam
        rw [dif_pos hNE_st]
        apply Finset.sup'_le
        intro xy hxy
        rcases Finset.mem_product.mp hxy with ⟨hx, hy⟩
        have hxI : P.idOfHandle xy.1 ∈ P.activeIds := (hP.2.2.1 xy.1 (hHandles.symm ▸ hx)).1
        have hyI : P.idOfHandle xy.2 ∈ P.activeIds := (hP.2.2.1 xy.2 (hHandles.symm ▸ hy)).1
        rw [← hid_coords xy.1 hx, ← hid_coords xy.2 hy]
        exact UL.Proof_lem_5_5.pair_norm_le_indexedEuclideanDiam P.activeIds P.coords hxI hyI
    · have hcard0 : st.activeSet.card = 0 := by
        have h0 : P.activeIds.card = 0 := Finset.not_nonempty_iff_eq_empty.mp hNE_id ▸ rfl
        omega
      rw [indexedEuclideanDiam_eq_zero_of_card_le_one P.coords (by omega),
        indexedEuclideanDiam_eq_zero_of_card_le_one st.coords (by omega)]
  unfold IsValidFactorCAnswer
  rw [hcached_eq]
  by_cases hle1 : st.activeSet.card ≤ 1
  · have hle1_id : P.activeIds.card ≤ 1 := by omega
    rw [if_pos hle1_id]
    simp [alg4Line12SelectCachedAnswer, hle1, toStoredDiameterAnswer]
  · have hle1_id : ¬ P.activeIds.card ≤ 1 := by omega
    rw [if_neg hle1_id]
    rw [if_neg hle1] at hfb
    rcases hfb with ⟨d1, d2, hfb_eq, hd1_mem, hd2_mem, hd_ne⟩
    let cands := collectCachedCandidatePairs st.servingNodes st.terminalLeafAnswer st.terminalLeafDistSq
    -- Every candidate in cands is an active handle pair with exact squared distance
    have hcands_valid : ∀ p ∈ cands,
        p.1.1 ∈ st.activeSet ∧ p.1.2 ∈ st.activeSet ∧
        p.2 = euclideanDistSq (st.coords p.1.1) (st.coords p.1.2) := by
      intro p hp
      unfold cands collectCachedCandidatePairs at hp
      rw [List.mem_append] at hp
      rcases hp with hnodes | hleaf_mem
      · rw [List.mem_flatMap] at hnodes
        rcases hnodes with ⟨sn, hsn_mem, hfrom⟩
        obtain ⟨r, hr, rfl⟩ := List.mem_iff_getElem.mp hsn_mem
        let idx : Fin k := ⟨r, hr⟩
        have hget_idx : st.servingNodes[idx] = st.servingNodes[r] :=
          Fin.getElem_fin st.servingNodes idx hr
        have hw_idx := hsn_wf idx
        have hsub_idx : st.servingInputAt idx.val ⊆ st.activeSet := by
          rw [hS_eq idx]
          exact chainInput_subset st.coords nodes st.activeSet idx.castSucc
        rw [← hget_idx, List.mem_append] at hfrom
        rcases hfrom with hbp | hmp
        · cases hbp_val : (st.servingNodes[idx]).baselinePair with
          | none =>
            rw [hbp_val] at hbp
            cases hbp
          | some uv =>
            simp only [hbp_val, List.mem_singleton] at hbp
            subst hbp
            have hact_bp := hw_idx.2.2.2.2.2.1
            rw [hbp_val] at hact_bp
            have hsq_bp := hw_idx.2.2.2.2.2.2.1
            rw [hbp_val] at hsq_bp
            exact ⟨hsub_idx hact_bp.1, hsub_idx hact_bp.2,
              hsq_bp.trans (euclideanDistSq_eq_norm_sq _ _).symm⟩
        · cases hmp_val : (st.servingNodes[idx]).maxMatchingPair with
          | none =>
            rw [hmp_val] at hmp
            cases hmp
          | some uv =>
            simp only [hmp_val, List.mem_singleton] at hmp
            subst hmp
            have hact_mp := hw_idx.2.2.2.2.2.2.2.1
            rw [hmp_val] at hact_mp
            exact ⟨hsub_idx hact_mp.1, hsub_idx hact_mp.2.1, hact_mp.2.2.2.1⟩
      · cases hlp_val : st.terminalLeafAnswer with
        | none => simp [hlp_val] at hleaf_mem
        | some uv =>
          simp only [hlp_val, List.mem_singleton] at hleaf_mem
          subst hleaf_mem
          obtain ⟨hleaf_act, _, _⟩ := exactLeaf_padded hchain_wf.2.2
          have huv_T := hleaf_act uv.1 uv.2 hlp_val
          rw [hlp_val] at hleafSq
          have hsub_T : st.terminalLeaf ⊆ st.activeSet := by
            rw [hterm_eq]
            exact chainInput_subset st.coords nodes st.activeSet (Fin.last k)
          exact ⟨hsub_T huv_T.1, hsub_T huv_T.2,
            hleafSq.trans (euclideanDistSq_eq_norm_sq _ _).symm⟩
    let nodeW : Fin k → ℝ := fun i =>
      params.nodeRetainedEstimate st.coords (nodes i).V
        (baselinePairLength st.coords (basePairs i)) (stored i)
    let W_max : ℝ :=
      (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty
        (Fin.lastCases (baselinePairLength st.coords leafPair) nodeW)
    -- Any nonneg B with p.2 ≤ B^2 for all p ∈ cands bounds W_max
    have hW_le_of_cands : ∀ B : ℝ, 0 ≤ B → (∀ p ∈ cands, p.2 ≤ B ^ 2) → W_max ≤ B := by
      intro B hB_nn hB_cands
      apply Finset.sup'_le
      intro j _
      refine Fin.lastCases ?_ ?_ j
      · simp only [Fin.lastCases_last]
        cases hlp_val : st.terminalLeafAnswer with
        | none =>
          change baselinePairLength st.coords st.terminalLeafAnswer ≤ B
          rw [hlp_val]
          simp [baselinePairLength, hB_nn]
        | some uv =>
          have hmem_c : (uv, st.terminalLeafDistSq) ∈ cands := by
            unfold cands collectCachedCandidatePairs
            exact List.mem_append_right _ (by simp [hlp_val])
          have hsq_le := hB_cands _ hmem_c
          rw [hleafSq, hlp_val] at hsq_le
          change baselinePairLength st.coords st.terminalLeafAnswer ≤ B
          rw [hlp_val]
          have hnn : 0 ≤ baselinePairLength st.coords (some uv) :=
            baselinePairLength_nonneg _ _
          nlinarith
      · intro i
        simp only [Fin.lastCases_castSucc]
        have hWi_eq := (hfirst i).1
        dsimp only [nodeW, nodes, basePairs, stored]
        rw [← hWi_eq]
        have hsn_mem : st.servingNodes[i] ∈ st.servingNodes := List.getElem_mem i.isLt
        apply max_le
        · cases hbp_val : (st.servingNodes[i]).baselinePair with
          | none => simp [baselinePairLength, hB_nn]
          | some uv =>
            have hmem_c : (uv, (st.servingNodes[i]).baselineDistSq) ∈ cands := by
              unfold cands collectCachedCandidatePairs
              apply List.mem_append_left
              rw [List.mem_flatMap]
              refine ⟨st.servingNodes[i], hsn_mem, ?_⟩
              rw [hbp_val]
              simp
            have hsq_le := hB_cands _ hmem_c
            have hsq_eq := (hsn_wf i).2.2.2.2.2.2.1
            rw [hsq_eq, hbp_val] at hsq_le
            have hnn : 0 ≤ baselinePairLength st.coords (some uv) :=
              baselinePairLength_nonneg _ _
            nlinarith
        · cases hmp_val : (st.servingNodes[i]).maxMatchingPair with
          | none =>
            have hsq0 := (hmp_val ▸ (hsn_wf i).2.2.2.2.2.2.2.1).1
            rw [hsq0, Real.sqrt_zero]
            exact hB_nn
          | some uv =>
            have hmem_c : (uv, (st.servingNodes[i]).maxMatchingDistSq) ∈ cands := by
              unfold cands collectCachedCandidatePairs
              apply List.mem_append_left
              rw [List.mem_flatMap]
              refine ⟨st.servingNodes[i], hsn_mem, ?_⟩
              rw [hmp_val]
              simp
            have hsq_le := hB_cands _ hmem_c
            calc Real.sqrt (st.servingNodes[i]).maxMatchingDistSq
                ≤ Real.sqrt (B ^ 2) := Real.sqrt_le_sqrt hsq_le
              _ = B := Real.sqrt_sq hB_nn
    -- Helper to finish IsValidFactorCAnswer from a valid handle pair (h1, h2)
    have hfinish_pair : ∀ (h1 h2 : ℕ),
        h1 ∈ st.activeSet → h2 ∈ st.activeSet → h1 ≠ h2 →
        W_max ≤ ‖st.coords h1 - st.coords h2‖ →
        ∃ a1 a2 : ℕ,
          (toStoredDiameterAnswer (some (h1, h2), euclideanDistSq (st.coords h1) (st.coords h2))).diameterHandles =
            some (a1, a2) ∧
          a1 ∈ P.activeHandles ∧ a2 ∈ P.activeHandles ∧ a1 ≠ a2 ∧
          (toStoredDiameterAnswer (some (h1, h2), euclideanDistSq (st.coords h1) (st.coords h2))).cachedDistSq =
            euclideanDistSq (P.coords (P.idOfHandle a1)) (P.coords (P.idOfHandle a2)) ∧
          IsIndexedFactorCDiameterPair params.c P.activeIds P.coords
            (P.idOfHandle a1) (P.idOfHandle a2) := by
      intro h1 h2 hh1 hh2 hh_ne hW_le_norm
      have ha1 : h1 ∈ P.activeHandles := hHandles.symm ▸ hh1
      have ha2 : h2 ∈ P.activeHandles := hHandles.symm ▸ hh2
      have hid1 : P.idOfHandle h1 ∈ P.activeIds := (hP.2.2.1 h1 ha1).1
      have hid2 : P.idOfHandle h2 ∈ P.activeIds := (hP.2.2.1 h2 ha2).1
      have hid_ne : P.idOfHandle h1 ≠ P.idOfHandle h2 := by
        intro hEq
        have := congrArg P.handleOfId hEq
        rw [(hP.2.2.1 h1 ha1).2, (hP.2.2.1 h2 ha2).2] at this
        exact hh_ne this
      have hc1 := hid_coords h1 hh1
      have hc2 := hid_coords h2 hh2
      refine ⟨h1, h2, rfl, ha1, ha2, hh_ne, ?_, hid1, hid2, hid_ne, ?_, ?_⟩
      · simp [toStoredDiameterAnswer, hc1, hc2]
      · rw [hdiam_eq, hc1, hc2]
        exact hW_Icc.1.trans hW_le_norm
      · exact UL.Proof_lem_5_5.pair_norm_le_indexedEuclideanDiam P.activeIds P.coords hid1 hid2
    -- Evaluate alg4Line12SelectCachedAnswer cleanly via an equality for ans12
    let ans12 := alg4Line12SelectCachedAnswer st.coords st.activeSet st.servingNodes
      st.terminalLeafAnswer st.terminalLeafDistSq st.distinctFallbackPair
    change ∃ h1 h2 : ℕ,
      (toStoredDiameterAnswer ans12).diameterHandles = some (h1, h2) ∧
      h1 ∈ P.activeHandles ∧ h2 ∈ P.activeHandles ∧ h1 ≠ h2 ∧
      (toStoredDiameterAnswer ans12).cachedDistSq =
        euclideanDistSq (P.coords (P.idOfHandle h1)) (P.coords (P.idOfHandle h2)) ∧
      IsIndexedFactorCDiameterPair params.c P.activeIds P.coords
        (P.idOfHandle h1) (P.idOfHandle h2)
    cases hcands_eq : cands with
    | nil =>
      have hans_eq : ans12 = (some (d1, d2), euclideanDistSq (st.coords d1) (st.coords d2)) := by
        unfold ans12 alg4Line12SelectCachedAnswer
        rw [if_neg hle1]
        dsimp only
        rw [show collectCachedCandidatePairs st.servingNodes st.terminalLeafAnswer
          st.terminalLeafDistSq = [] from hcands_eq, hfb_eq]
      rw [hans_eq]
      have hW0 : W_max ≤ 0 := by
        apply hW_le_of_cands 0 le_rfl
        intro p hp
        rw [hcands_eq] at hp
        cases hp
      exact hfinish_pair d1 d2 hd1_mem hd2_mem hd_ne (hW0.trans (norm_nonneg _))
    | cons c cs =>
      have hpmax := pickMaxByReal_spec Prod.snd c cs
      rcases hbest_eq : pickMaxByReal Prod.snd c cs with ⟨⟨u, v⟩, bestSq⟩
      have hbest_mem : ((u, v), bestSq) ∈ cands := by
        rw [hcands_eq, ← hbest_eq]
        exact hpmax.1
      obtain ⟨hu_st, hv_st, hbest_sq⟩ := hcands_valid _ hbest_mem
      by_cases hpos : 0 < bestSq
      · have hans_eq : ans12 = (some (u, v), euclideanDistSq (st.coords u) (st.coords v)) := by
          unfold ans12 alg4Line12SelectCachedAnswer
          rw [if_neg hle1]
          dsimp only
          rw [show collectCachedCandidatePairs st.servingNodes st.terminalLeafAnswer
            st.terminalLeafDistSq = c :: cs from hcands_eq]
          dsimp only
          rw [hbest_eq, if_pos hpos, hbest_sq]
        rw [hans_eq]
        have huv_ne : u ≠ v := by
          intro hEq
          rw [hEq, euclideanDistSq_eq_norm_sq, sub_self, norm_zero] at hbest_sq
          linarith
        have hW_le : W_max ≤ ‖st.coords u - st.coords v‖ := by
          apply hW_le_of_cands ‖st.coords u - st.coords v‖ (norm_nonneg _)
          intro p hp
          rw [hcands_eq] at hp
          have hp_le := hpmax.2 p hp
          rw [hbest_eq, hbest_sq, euclideanDistSq_eq_norm_sq] at hp_le
          exact hp_le
        exact hfinish_pair u v hu_st hv_st huv_ne hW_le
      · have hans_eq : ans12 = (some (d1, d2), euclideanDistSq (st.coords d1) (st.coords d2)) := by
          unfold ans12 alg4Line12SelectCachedAnswer
          rw [if_neg hle1]
          dsimp only
          rw [show collectCachedCandidatePairs st.servingNodes st.terminalLeafAnswer
            st.terminalLeafDistSq = c :: cs from hcands_eq]
          dsimp only
          rw [hbest_eq, if_neg hpos, hfb_eq]
        rw [hans_eq]
        have hW0 : W_max ≤ 0 := by
          apply hW_le_of_cands 0 le_rfl
          intro p hp
          rw [hcands_eq] at hp
          have hp_le := hpmax.2 p hp
          rw [hbest_eq] at hp_le
          linarith
        exact hfinish_pair d1 d2 hd1_mem hd2_mem hd_ne (hW0.trans (norm_nonneg _))

end UL.Proof_clm_7_3_global_approx
