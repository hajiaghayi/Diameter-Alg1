import UL.Stmt.clm_7_3_global_approx
set_option autoImplicit false

namespace UL.Proof_clm_7_3_global_approx

open UL

private lemma isBoundedByPoly2_mul {f g : ℕ → ℕ → ℝ}
    (hf : IsBoundedByPoly2 f) (hg : IsBoundedByPoly2 g)
    (hf0 : ∀ d L : ℕ, 0 ≤ f d L) (hg0 : ∀ d L : ℕ, 0 ≤ g d L) :
    IsBoundedByPoly2 (fun d L => f d L * g d L) := by
  rcases hf with ⟨C1, p1, hC1, hfb⟩
  rcases hg with ⟨C2, p2, hC2, hgb⟩
  refine ⟨C1 * C2, p1 + p2, mul_nonneg hC1 hC2, ?_⟩
  intro d L
  have hb1 := hfb d L
  have hb2 := hgb d L
  have h1_nn : 0 ≤ C1 * ((d + 1 : ℝ) ^ p1) * ((L + 1 : ℝ) ^ p1) := by positivity
  calc f d L * g d L
      ≤ (C1 * ((d + 1 : ℝ) ^ p1) * ((L + 1 : ℝ) ^ p1)) *
          (C2 * ((d + 1 : ℝ) ^ p2) * ((L + 1 : ℝ) ^ p2)) :=
        mul_le_mul hb1 hb2 (hg0 d L) h1_nn
    _ = (C1 * C2) * (((d + 1 : ℝ) ^ p1) * ((d + 1 : ℝ) ^ p2)) *
          (((L + 1 : ℝ) ^ p1) * ((L + 1 : ℝ) ^ p2)) := by ring
    _ = (C1 * C2) * ((d + 1 : ℝ) ^ (p1 + p2)) * ((L + 1 : ℝ) ^ (p1 + p2)) := by
        rw [← pow_add, ← pow_add]

private lemma nat_rpow_one_add_le {m n : ℕ} {σ : ℝ}
    (hmn : m ≤ n) (hσ : 0 ≤ σ) :
    (m : ℝ) ^ (1 + σ) ≤ (m : ℝ) * ((n : ℝ) ^ σ) := by
  cases m with
  | zero =>
    have hne : (1 : ℝ) + σ ≠ 0 := by linarith
    simp [Real.zero_rpow hne]
  | succ k =>
    have hm_pos : (0 : ℝ) < ((k + 1 : ℕ) : ℝ) := by positivity
    rw [Real.rpow_add hm_pos, Real.rpow_one]
    have hle : ((k + 1 : ℕ) : ℝ) ≤ (n : ℝ) := by exact_mod_cast hmn
    have hrpow : (((k + 1 : ℕ) : ℝ) ^ σ) ≤ (n : ℝ) ^ σ :=
      Real.rpow_le_rpow hm_pos.le hle hσ
    exact mul_le_mul_of_nonneg_left hrpow hm_pos.le

private lemma chainInput_exp_bound {d k : ℕ} {ι : Type} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (P : Finset ι) (β : ℝ) (nodes : Fin k → ChainNode d)
    (hβ1 : β ≤ 1)
    (hstep : ∀ i : Fin k,
      1 ≤ (chainInput pts nodes P i.castSucc).card ∧
      ((chainInput pts nodes P i.succ).card : ℝ) ≤
        (1 - β) * ((chainInput pts nodes P i.castSucc).card : ℝ)) :
    ∀ (r : ℕ) (hr : r ≤ k),
      ((chainInput pts nodes P ⟨r, Nat.lt_succ_of_le hr⟩).card : ℝ) ≤
        (Real.exp (-β)) ^ r * (P.card : ℝ)
  | 0, hr => by
      have h0 : chainInput pts nodes P ⟨0, Nat.lt_succ_of_le hr⟩ = P := rfl
      rw [h0]
      simp
  | r + 1, hr => by
      have hrk : r < k := Nat.lt_of_succ_le hr
      have ih := chainInput_exp_bound pts P β nodes hβ1 hstep r (le_of_lt hrk)
      let idx : Fin k := ⟨r, hrk⟩
      have hstep_r := (hstep idx).2
      have h1mβ_le : 1 - β ≤ Real.exp (-β) := by
        linarith [Real.add_one_le_exp (-β)]
      have hcard_nn : (0 : ℝ) ≤ ((chainInput pts nodes P idx.castSucc).card : ℝ) := by positivity
      have hcast_eq : idx.castSucc = ⟨r, Nat.lt_succ_of_le (le_of_lt hrk)⟩ := rfl
      have hsucc_eq : idx.succ = ⟨r + 1, Nat.lt_succ_of_le hr⟩ := rfl
      rw [← hsucc_eq]
      calc ((chainInput pts nodes P idx.succ).card : ℝ)
          ≤ (1 - β) * ((chainInput pts nodes P idx.castSucc).card : ℝ) := hstep_r
        _ ≤ Real.exp (-β) * ((chainInput pts nodes P idx.castSucc).card : ℝ) :=
            mul_le_mul_of_nonneg_right h1mβ_le hcard_nn
        _ ≤ Real.exp (-β) * ((Real.exp (-β)) ^ r * (P.card : ℝ)) := by
            rw [hcast_eq]
            exact mul_le_mul_of_nonneg_left ih (Real.exp_nonneg _)
        _ = (Real.exp (-β)) ^ (r + 1) * (P.card : ℝ) := by
            rw [pow_succ']
            ring

theorem prove_part2 :
    open Classical in
    (∃ (C_cfg : ℝ) (deg_cfg : ℕ), 0 < C_cfg ∧
      ∀ (params : LocalScaleParams) (V : ℝ),
        (params.retainedConfigs V).card ≤ (allShellConfigs params.m0 params.K params.J).card ∧
        (allShellConfigs params.m0 params.K params.J).card =
          params.m0 * params.maxShellIndex * (params.J + 1) ∧
        ((allShellConfigs params.m0 params.K params.J).card : ℝ) ≤
          C_cfg * (((params.e : ℝ)⁻¹ + 1) ^ deg_cfg) *
            (((params.K : ℝ) + 1) ^ deg_cfg) *
            ((((params.lam : ℝ) - 1)⁻¹ + 1) ^ deg_cfg)) ∧
    (∀ (d n k : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (P : Finset ι) (β : ℝ) (nodes : Fin k → ChainNode d),
      2 ≤ n → P.card ≤ n → 0 < β → β ≤ 1 →
      (∀ i : Fin k,
        1 ≤ (chainInput pts nodes P i.castSucc).card ∧
        ((chainInput pts nodes P i.succ).card : ℝ) ≤
          (1 - β) * ((chainInput pts nodes P i.castSucc).card : ℝ)) →
        (k : ℝ) ≤ β⁻¹ * (Real.log (n : ℝ) + 1)) ∧
    (∀ (σ θ : ℝ)
      (polySchedTime polySchedSpace polyConfigs polyLevels : ℕ → ℕ → ℝ),
      0 ≤ σ → σ ≤ θ →
      IsBoundedByPoly2 polySchedTime →
      IsBoundedByPoly2 polySchedSpace →
      IsBoundedByPoly2 polyConfigs →
      IsBoundedByPoly2 polyLevels →
      (∀ d L : ℕ,
        0 ≤ polySchedTime d L ∧ 0 ≤ polySchedSpace d L ∧
        0 ≤ polyConfigs d L ∧ 0 ≤ polyLevels d L) →
      ∃ (polyTotalTime polyTotalSpace : ℕ → ℕ → ℝ),
        IsBoundedByPoly2 polyTotalTime ∧
        IsBoundedByPoly2 polyTotalSpace ∧
        ∀ (d n L N_cfg N_lvl : ℕ),
          ValidBirthPoolExponents n σ θ →
          (N_cfg : ℝ) ≤ polyConfigs d L →
          (N_lvl : ℝ) ≤ polyLevels d L →
            (N_cfg : ℝ) * (N_lvl : ℝ) * birthPoolTargetTime n θ (polySchedTime d L) ≤
              ((n : ℝ) ^ θ) * polyTotalTime d L ∧
            ∀ (M : ℕ) (m : Fin M → ℕ),
              (∀ r : Fin M, m r ≤ n) →
              (∑ r : Fin M, (m r : ℝ)) ≤ (n : ℝ) * (N_cfg : ℝ) * (N_lvl : ℝ) →
                (∑ r : Fin M, birthPoolSpaceBound (m r) σ (polySchedSpace d L)) ≤
                  ((n : ℝ) ^ (1 + σ)) * polyTotalSpace d L) := by
  classical
  refine ⟨?_, ?_, ?_⟩
  · refine ⟨2, 2, zero_lt_two, ?_⟩
    intro params V
    have hret_le : (params.retainedConfigs V).card ≤
        (allShellConfigs params.m0 params.K params.J).card :=
      Finset.card_filter_le _ _
    have hcard_eq : (allShellConfigs params.m0 params.K params.J).card =
        params.m0 * params.maxShellIndex * (params.J + 1) := by
      unfold allShellConfigs allShellConfigTriples LocalScaleParams.maxShellIndex
      rw [Finset.card_map, Finset.card_product, Finset.card_product]
      simp [Nat.card_Icc, Nat.mul_assoc]
    refine ⟨hret_le, hcard_eq, ?_⟩
    rw [hcard_eq]
    push_cast
    have he_pos_r : (0 : ℝ) < (params.e : ℝ) := by exact_mod_cast params.e_pos
    have hm0_le : (params.m0 : ℝ) ≤ (params.e : ℝ)⁻¹ + 1 := by
      unfold LocalScaleParams.m0 shellSubdiv
      have hq : (Nat.ceil (1 / params.e) : ℚ) < 1 / params.e + 1 :=
        Nat.ceil_lt_add_one (one_div_nonneg.mpr (le_of_lt params.e_pos))
      have hr : ((Nat.ceil (1 / params.e) : ℚ) : ℝ) ≤ ((1 / params.e + 1 : ℚ) : ℝ) :=
        le_of_lt (by exact_mod_cast hq)
      simpa [one_div] using hr
    have hK_pos_r : (0 : ℝ) < (params.K : ℝ) :=
      lt_of_lt_of_le (div_pos zero_lt_two (sub_pos.mpr params.one_lt_c)) params.K_ge
    have hK_pos : 0 < params.K := by exact_mod_cast hK_pos_r
    have hmax_le : (params.maxShellIndex : ℝ) ≤
        ((params.K : ℝ) + 1) * ((params.e : ℝ)⁻¹ + 1) := by
      unfold LocalScaleParams.maxShellIndex maxShellIndex
      have htoNat : ((params.K.toNat : ℕ) : ℝ) = (params.K : ℝ) := by
        have h1 : (params.K.toNat : ℤ) = params.K := Int.toNat_of_nonneg (le_of_lt hK_pos)
        exact_mod_cast h1
      rw [Nat.cast_mul, htoNat]
      exact mul_le_mul (by linarith) hm0_le (by positivity) (by positivity)
    let d_lam : ℝ := (params.lam : ℝ) - 1
    have hd_pos : 0 < d_lam := by
      have hlam1 : (1 : ℝ) < (params.lam : ℝ) := by exact_mod_cast params.one_lt_lam
      linarith
    let ℓ0 : ℕ := Nat.ceil (2 * ((params.K : ℝ) + 1) * d_lam⁻¹)
    have hJ_le_ℓ0 : params.J ≤ ℓ0 := by
      unfold LocalScaleParams.J scaleCutoffIndex
      refine Nat.sInf_le ?_
      simp only [Set.mem_setOf_eq]
      have hbern : 1 + (ℓ0 : ℝ) * d_lam ≤ (params.lam : ℝ) ^ ℓ0 := by
        have hEq : (params.lam : ℝ) = 1 + d_lam := by dsimp [d_lam]; ring
        rw [hEq]
        simpa [mul_comm] using one_add_mul_le_pow (by linarith : (-2 : ℝ) ≤ d_lam) ℓ0
      have hceil_ge : 2 * ((params.K : ℝ) + 1) * d_lam⁻¹ ≤ (ℓ0 : ℝ) := Nat.le_ceil _
      have hmul_ge : 2 * ((params.K : ℝ) + 1) ≤ (ℓ0 : ℝ) * d_lam := by
        have h := mul_le_mul_of_nonneg_right hceil_ge hd_pos.le
        rwa [mul_assoc, inv_mul_cancel₀ hd_pos.ne', mul_one] at h
      linarith
    have hJ1_le : (params.J : ℝ) + 1 ≤
        2 * ((params.K : ℝ) + 1) * (d_lam⁻¹ + 1) := by
      have hJ_r : (params.J : ℝ) ≤ (ℓ0 : ℝ) := by exact_mod_cast hJ_le_ℓ0
      have hℓ0_lt : (ℓ0 : ℝ) < 2 * ((params.K : ℝ) + 1) * d_lam⁻¹ + 1 :=
        Nat.ceil_lt_add_one (by positivity)
      have hK1 : 1 ≤ (params.K : ℝ) + 1 := by linarith
      nlinarith
    have hd_ge1 : 1 ≤ d_lam⁻¹ + 1 := by
      have : 0 < d_lam⁻¹ := inv_pos.mpr hd_pos
      linarith
    have hd_sq : d_lam⁻¹ + 1 ≤ (d_lam⁻¹ + 1) ^ 2 := by nlinarith
    have hprod12 : (params.m0 : ℝ) * (params.maxShellIndex : ℝ) ≤
        ((params.e : ℝ)⁻¹ + 1) * (((params.K : ℝ) + 1) * ((params.e : ℝ)⁻¹ + 1)) :=
      mul_le_mul hm0_le hmax_le (by positivity) (by positivity)
    have hprod123 : (params.m0 : ℝ) * (params.maxShellIndex : ℝ) * ((params.J : ℝ) + 1) ≤
        (((params.e : ℝ)⁻¹ + 1) * (((params.K : ℝ) + 1) * ((params.e : ℝ)⁻¹ + 1))) *
          (2 * ((params.K : ℝ) + 1) * (d_lam⁻¹ + 1)) :=
      mul_le_mul hprod12 hJ1_le (by positivity) (by positivity)
    have hprod_sq :
        (((params.e : ℝ)⁻¹ + 1) * (((params.K : ℝ) + 1) * ((params.e : ℝ)⁻¹ + 1))) *
          (2 * ((params.K : ℝ) + 1) * (d_lam⁻¹ + 1)) ≤
        2 * (((params.e : ℝ)⁻¹ + 1) ^ 2) * (((params.K : ℝ) + 1) ^ 2) * ((d_lam⁻¹ + 1) ^ 2) := by
      have hnonneg : 0 ≤ 2 * (((params.e : ℝ)⁻¹ + 1) ^ 2) * (((params.K : ℝ) + 1) ^ 2) := by
        positivity
      calc (((params.e : ℝ)⁻¹ + 1) * (((params.K : ℝ) + 1) * ((params.e : ℝ)⁻¹ + 1))) *
            (2 * ((params.K : ℝ) + 1) * (d_lam⁻¹ + 1))
          = (2 * (((params.e : ℝ)⁻¹ + 1) ^ 2) * (((params.K : ℝ) + 1) ^ 2)) * (d_lam⁻¹ + 1) := by
              ring
        _ ≤ (2 * (((params.e : ℝ)⁻¹ + 1) ^ 2) * (((params.K : ℝ) + 1) ^ 2)) *
              ((d_lam⁻¹ + 1) ^ 2) :=
              mul_le_mul_of_nonneg_left hd_sq hnonneg
    exact hprod123.trans hprod_sq
  · intro d n k ι _ pts P β nodes hn2 hP_le hβ0 hβ1 hstep
    have hn1_r : (1 : ℝ) ≤ (n : ℝ) := by
      have : 1 ≤ n := by omega
      exact_mod_cast this
    have hlog_nn : 0 ≤ Real.log (n : ℝ) := Real.log_nonneg hn1_r
    cases k with
    | zero =>
      simp only [Nat.cast_zero]
      exact mul_nonneg (inv_nonneg.mpr hβ0.le) (by linarith)
    | succ m =>
      let i_last : Fin (m + 1) := ⟨m, Nat.lt_succ_self m⟩
      have h1_le_nat : 1 ≤ (chainInput pts nodes P i_last.castSucc).card := (hstep i_last).1
      have h1_le : (1 : ℝ) ≤ ((chainInput pts nodes P i_last.castSucc).card : ℝ) := by
        exact_mod_cast h1_le_nat
      have hexp_b := chainInput_exp_bound pts P β nodes hβ1 hstep m (Nat.le_succ m)
      have hcast_eq : i_last.castSucc = ⟨m, Nat.lt_succ_of_le (Nat.le_succ m)⟩ := rfl
      rw [← hcast_eq] at hexp_b
      have hP_le_r : (P.card : ℝ) ≤ (n : ℝ) := by exact_mod_cast hP_le
      have hpow_exp : (Real.exp (-β)) ^ m = Real.exp (-(β * (m : ℝ))) := by
        rw [← Real.exp_nat_mul]
        congr 1
        ring
      have h1_le_exp_n : 1 ≤ Real.exp (-(β * (m : ℝ))) * (n : ℝ) := by
        calc (1 : ℝ)
            ≤ ((chainInput pts nodes P i_last.castSucc).card : ℝ) := h1_le
          _ ≤ (Real.exp (-β)) ^ m * (P.card : ℝ) := hexp_b
          _ ≤ (Real.exp (-β)) ^ m * (n : ℝ) :=
              mul_le_mul_of_nonneg_left hP_le_r (by positivity)
          _ = Real.exp (-(β * (m : ℝ))) * (n : ℝ) := by rw [hpow_exp]
      have hexp_le_n : Real.exp (β * (m : ℝ)) ≤ (n : ℝ) := by
        have hmul := mul_le_mul_of_nonneg_left h1_le_exp_n (Real.exp_nonneg (β * (m : ℝ)))
        have hcancel : Real.exp (β * (m : ℝ)) * (Real.exp (-(β * (m : ℝ))) * (n : ℝ)) =
            (n : ℝ) := by
          rw [← mul_assoc, ← Real.exp_add]
          simp
        linarith
      have hlog_le : β * (m : ℝ) ≤ Real.log (n : ℝ) := by
        have h := Real.log_le_log (Real.exp_pos (β * (m : ℝ))) hexp_le_n
        rwa [Real.log_exp] at h
      have hβk_le : β * ((m + 1 : ℕ) : ℝ) ≤ Real.log (n : ℝ) + 1 := by
        push_cast
        nlinarith
      have hres := mul_le_mul_of_nonneg_left hβk_le (inv_nonneg.mpr hβ0.le)
      rwa [← mul_assoc, inv_mul_cancel₀ hβ0.ne', one_mul] at hres
  · intro σ θ polySchedTime polySchedSpace polyConfigs polyLevels hσ0 _
      hpT hpS hpC hpL hnn
    have hnnT : ∀ d L, 0 ≤ polySchedTime d L := fun d L => (hnn d L).1
    have hnnS : ∀ d L, 0 ≤ polySchedSpace d L := fun d L => (hnn d L).2.1
    have hnnC : ∀ d L, 0 ≤ polyConfigs d L := fun d L => (hnn d L).2.2.1
    have hnnL : ∀ d L, 0 ≤ polyLevels d L := fun d L => (hnn d L).2.2.2
    let polyCL : ℕ → ℕ → ℝ := fun d L => polyConfigs d L * polyLevels d L
    have hpCL : IsBoundedByPoly2 polyCL := isBoundedByPoly2_mul hpC hpL hnnC hnnL
    have hnnCL : ∀ d L, 0 ≤ polyCL d L := fun d L => mul_nonneg (hnnC d L) (hnnL d L)
    let polyTotalTime : ℕ → ℕ → ℝ := fun d L => polyCL d L * polySchedTime d L
    let polyTotalSpace : ℕ → ℕ → ℝ := fun d L => polyCL d L * polySchedSpace d L
    refine ⟨polyTotalTime, polyTotalSpace,
      isBoundedByPoly2_mul hpCL hpT hnnCL hnnT,
      isBoundedByPoly2_mul hpCL hpS hnnCL hnnS, ?_⟩
    intro d n L N_cfg N_lvl hexp hNcfg hNlvl
    have hprod_CL : (N_cfg : ℝ) * (N_lvl : ℝ) ≤ polyCL d L :=
      mul_le_mul hNcfg hNlvl (by positivity) (hnnC d L)
    refine ⟨?_, ?_⟩
    · unfold birthPoolTargetTime polyTotalTime
      have hnθ_nn : 0 ≤ (n : ℝ) ^ θ := Real.rpow_nonneg (by positivity) θ
      have h1 : (N_cfg : ℝ) * (N_lvl : ℝ) * ((n : ℝ) ^ θ * polySchedTime d L) ≤
          polyCL d L * ((n : ℝ) ^ θ * polySchedTime d L) :=
        mul_le_mul_of_nonneg_right hprod_CL (mul_nonneg hnθ_nn (hnnT d L))
      linarith
    · intro M m hm_le hsum_le
      have hn2 : 2 ≤ n := hexp.1
      have hn_pos : (0 : ℝ) < (n : ℝ) := by
        have : 0 < n := by omega
        exact_mod_cast this
      have hterm : ∀ r : Fin M,
          birthPoolSpaceBound (m r) σ (polySchedSpace d L) ≤
            (m r : ℝ) * (((n : ℝ) ^ σ) * polySchedSpace d L) := by
        intro r
        unfold birthPoolSpaceBound
        have hrpow := nat_rpow_one_add_le (hm_le r) hσ0
        have hmul := mul_le_mul_of_nonneg_right hrpow (hnnS d L)
        linarith
      have hsum1 : ∑ r : Fin M, birthPoolSpaceBound (m r) σ (polySchedSpace d L) ≤
          (∑ r : Fin M, (m r : ℝ)) * (((n : ℝ) ^ σ) * polySchedSpace d L) := by
        calc ∑ r : Fin M, birthPoolSpaceBound (m r) σ (polySchedSpace d L)
            ≤ ∑ r : Fin M, (m r : ℝ) * (((n : ℝ) ^ σ) * polySchedSpace d L) :=
              Finset.sum_le_sum (fun r _ => hterm r)
          _ = (∑ r : Fin M, (m r : ℝ)) * (((n : ℝ) ^ σ) * polySchedSpace d L) := by
              rw [Finset.sum_mul]
      have hnσS_nn : 0 ≤ ((n : ℝ) ^ σ) * polySchedSpace d L :=
        mul_nonneg (Real.rpow_nonneg hn_pos.le σ) (hnnS d L)
      have hsum2 : (∑ r : Fin M, (m r : ℝ)) * (((n : ℝ) ^ σ) * polySchedSpace d L) ≤
          ((n : ℝ) * polyCL d L) * (((n : ℝ) ^ σ) * polySchedSpace d L) := by
        have hbound : (∑ r : Fin M, (m r : ℝ)) ≤ (n : ℝ) * polyCL d L :=
          (hsum_le.trans_eq (mul_assoc _ _ _)).trans (mul_le_mul_of_nonneg_left hprod_CL hn_pos.le)
        exact mul_le_mul_of_nonneg_right hbound hnσS_nn
      have hn_rpow : (n : ℝ) * ((n : ℝ) ^ σ) = (n : ℝ) ^ (1 + σ) := by
        rw [Real.rpow_add hn_pos, Real.rpow_one]
      calc ∑ r : Fin M, birthPoolSpaceBound (m r) σ (polySchedSpace d L)
          ≤ ((n : ℝ) * polyCL d L) * (((n : ℝ) ^ σ) * polySchedSpace d L) :=
            hsum1.trans hsum2
        _ = ((n : ℝ) * ((n : ℝ) ^ σ)) * polyTotalSpace d L := by
            unfold polyTotalSpace; ring
        _ = ((n : ℝ) ^ (1 + σ)) * polyTotalSpace d L := by
            rw [hn_rpow]

end UL.Proof_clm_7_3_global_approx
