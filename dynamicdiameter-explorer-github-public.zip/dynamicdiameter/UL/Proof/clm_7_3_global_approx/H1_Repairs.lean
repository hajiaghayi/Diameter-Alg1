import UL.Stmt.clm_7_3_global_approx
import UL.Stmt.clm_5_3_matching_invariant
import UL.Proof.clm_5_3_matching_invariant.H1
set_option autoImplicit false

namespace UL.Proof_clm_7_3_global_approx

open UL
open UL.Proof_clm_5_3_matching_invariant

private lemma params_K_pos (params : LocalScaleParams) : 0 < params.K := by
  have hc : 0 < 2 / (params.c - 1) := div_pos zero_lt_two (sub_pos.mpr params.one_lt_c)
  have hKr : (0 : ℝ) < (params.K : ℝ) := lt_of_lt_of_le hc params.K_ge
  exact_mod_cast hKr

private lemma retainedConfigs_valid (params : LocalScaleParams) {V : ℝ} {cfg : ShellConfig}
    (hcfg : cfg ∈ params.retainedConfigs V) :
    IsRetainedConfig params.e params.γ params.lam params.K V cfg.j cfg.k cfg.ℓ ∧
    1 ≤ cfg.j ∧ 1 ≤ cfg.k := by
  classical
  unfold LocalScaleParams.retainedConfigs retainedConfigs at hcfg
  rw [Finset.mem_filter] at hcfg
  rcases hcfg with ⟨hall, hret⟩
  unfold allShellConfigs allShellConfigTriples at hall
  rw [Finset.mem_map] at hall
  rcases hall with ⟨⟨j, k, ℓ⟩, hmem, hEq⟩
  simp only [Function.Embedding.coeFn_mk] at hEq
  subst hEq
  simp only [Finset.mem_product, Finset.mem_Icc, zero_le, true_and] at hmem
  rcases hmem with ⟨⟨hj1, hjm⟩, ⟨hk1, hkm⟩, hℓJ⟩
  have hKpos : 0 ≤ params.K := le_of_lt (params_K_pos params)
  have hk_int : (k : ℤ) ≤ params.K * (shellSubdiv params.e : ℤ) := by
    unfold maxShellIndex at hkm
    have h1 : (k : ℤ) ≤ ((params.K.toNat * shellSubdiv params.e : ℕ) : ℤ) := by
      exact_mod_cast hkm
    simpa [Int.toNat_of_nonneg hKpos] using h1
  exact ⟨⟨⟨hj1, hjm, hk1, hk_int, hℓJ⟩, hret⟩, hj1, hk1⟩

private lemma inner_liftedPoint {d : ℕ}
    (u v : EuclideanSpace ℝ (Fin d)) (s t : ℝ) :
    inner ℝ (liftedPoint u s) (liftedPoint v t) = inner ℝ u v + s * t := by
  rw [PiLp.inner_apply, Fin.sum_univ_castSucc, PiLp.inner_apply]
  congr 1
  · refine Finset.sum_congr rfl (fun i _ => ?_)
    simp [liftedPoint]
  · simp [liftedPoint, mul_comm]

private lemma pad_isUnitVec {d : ℕ} {A_pad s : ℝ}
    (v : EuclideanSpace ℝ (Fin d)) (hv : ‖v‖ = 1) (hAs : A_pad ^ 2 + s ^ 2 = 1) :
    IsUnitVec (liftedPoint (A_pad • v) s) := by
  unfold IsUnitVec
  have hsq : ‖liftedPoint (A_pad • v) s‖ ^ 2 = 1 := by
    rw [← real_inner_self_eq_norm_sq, inner_liftedPoint, real_inner_self_eq_norm_sq,
      norm_smul, Real.norm_eq_abs, hv, mul_one, sq_abs]
    linear_combination hAs
  have hnn : 0 ≤ ‖liftedPoint (A_pad • v) s‖ := norm_nonneg _
  nlinarith

private lemma radialDirection_norm_one {d : ℕ}
    {o p : EuclideanSpace ℝ (Fin d)} (hne : p ≠ o) :
    ‖radialDirection o p‖ = 1 := by
  have hpos : 0 < ‖p - o‖ := norm_sub_pos_iff.mpr hne
  unfold radialDirection
  rw [norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hpos), inv_mul_cancel₀ hpos.ne']

private lemma ne_center_of_shellIndex_pos {d : ℕ} {m0 : ℕ}
    {o p : EuclideanSpace ℝ (Fin d)} {V : ℝ} {s : ℕ}
    (hs : 1 ≤ s) (hidx : shellIndex m0 o V p = s) :
    p ≠ o := by
  intro hEq
  rw [hEq] at hidx
  unfold shellIndex at hidx
  simp at hidx
  omega

private noncomputable def indexSymmDiffCost {ι : Type*} [DecidableEq ι]
    (st st' : LocalMatchingState ι) : ℕ :=
  (symmDiff st.leftIndexSet st'.leftIndexSet).card +
    (symmDiff st.rightIndexSet st'.rightIndexSet).card

private lemma symmDiff_card_triangle {α : Type*} [DecidableEq α] (A B C : Finset α) :
    (symmDiff A C).card ≤ (symmDiff A B).card + (symmDiff B C).card := by
  have hsub : symmDiff A C ⊆ symmDiff A B ∪ symmDiff B C := by
    intro x hx
    unfold symmDiff at hx ⊢
    simp only [Finset.sup_eq_union, Finset.mem_union, Finset.mem_sdiff] at hx ⊢
    tauto
  exact le_trans (Finset.card_le_card hsub) (Finset.card_union_le _ _)

private lemma symmDiff_self_card {α : Type*} [DecidableEq α] (A : Finset α) :
    (symmDiff A A).card = 0 := by
  have h : symmDiff A A = ∅ := by
    ext x
    unfold symmDiff
    simp
  rw [h, Finset.card_empty]

private lemma symmDiff_insert_card_le_one {α : Type*} [DecidableEq α] (A : Finset α) (x : α) :
    (symmDiff A (insert x A)).card ≤ 1 := by
  have hsub : symmDiff A (insert x A) ⊆ {x} := by
    intro z hz
    unfold symmDiff at hz
    simp only [Finset.sup_eq_union, Finset.mem_union, Finset.mem_sdiff, Finset.mem_insert,
      Finset.mem_singleton] at hz ⊢
    tauto
  exact le_trans (Finset.card_le_card hsub) (by simp)

private lemma symmDiff_erase_card_le_one {α : Type*} [DecidableEq α] (A : Finset α) (x : α) :
    (symmDiff A (A.erase x)).card ≤ 1 := by
  have hsub : symmDiff A (A.erase x) ⊆ {x} := by
    intro z hz
    unfold symmDiff at hz
    simp only [Finset.sup_eq_union, Finset.mem_union, Finset.mem_sdiff, Finset.mem_erase,
      Finset.mem_singleton] at hz ⊢
    tauto
  exact le_trans (Finset.card_le_card hsub) (by simp)

private lemma indexSymmDiffCost_triangle {ι : Type*} [DecidableEq ι]
    (s1 s2 s3 : LocalMatchingState ι) :
    indexSymmDiffCost s1 s3 ≤ indexSymmDiffCost s1 s2 + indexSymmDiffCost s2 s3 := by
  have hL := symmDiff_card_triangle s1.leftIndexSet s2.leftIndexSet s3.leftIndexSet
  have hR := symmDiff_card_triangle s1.rightIndexSet s2.rightIndexSet s3.rightIndexSet
  unfold indexSymmDiffCost
  omega

private lemma attachStep_costs_le_one {d : ℕ} {ι : Type*} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (st : LocalMatchingState ι) (v : CopyVertex ι) (ans : Option ι) :
    indexSymmDiffCost st (attachStep pts st v ans) ≤ 1 ∧
    (symmDiff st.matching (attachStep pts st v ans).matching).card ≤ 1 := by
  rcases v with ⟨side, vid⟩
  cases side with
  | left =>
    cases ans with
    | none =>
      have hL : (attachStep pts st ⟨.left, vid⟩ none).leftIndexSet =
          insert vid st.leftIndexSet := by
        ext z
        simp [attachStep, LocalMatchingState.leftIndexSet, List.mem_toFinset, List.mem_map,
          Finset.mem_insert, eq_comm]
      have hR : (attachStep pts st ⟨.left, vid⟩ none).rightIndexSet = st.rightIndexSet := rfl
      have hM : (attachStep pts st ⟨.left, vid⟩ none).matching = st.matching := rfl
      unfold indexSymmDiffCost
      simp only [hL, hR, hM, symmDiff_self_card]
      have h1 := symmDiff_insert_card_le_one st.leftIndexSet vid
      omega
    | some w =>
      have hL : (attachStep pts st ⟨.left, vid⟩ (some w)).leftIndexSet = st.leftIndexSet := rfl
      have hR : (attachStep pts st ⟨.left, vid⟩ (some w)).rightIndexSet =
          st.rightIndexSet.erase w := by
        ext z
        simp only [attachStep, LocalMatchingState.rightIndexSet, List.mem_toFinset, List.mem_map,
          List.mem_filter, decide_eq_true_eq, Finset.mem_erase]
        constructor
        · rintro ⟨e, ⟨he, hne⟩, rfl⟩
          exact ⟨hne, e, he, rfl⟩
        · rintro ⟨hne, e, he, rfl⟩
          exact ⟨e, ⟨he, hne⟩, rfl⟩
      have hM : (attachStep pts st ⟨.left, vid⟩ (some w)).matching =
          insert (vid, w) st.matching := by
        ext xy
        simp [attachStep, LocalMatchingState.matching, MatchingEdge.pair, List.mem_toFinset,
          List.mem_map, Finset.mem_insert]
      unfold indexSymmDiffCost
      simp only [hL, hR, hM, symmDiff_self_card]
      exact ⟨by simpa using symmDiff_erase_card_le_one st.rightIndexSet w,
        symmDiff_insert_card_le_one st.matching (vid, w)⟩
  | right =>
    cases ans with
    | none =>
      have hL : (attachStep pts st ⟨.right, vid⟩ none).leftIndexSet = st.leftIndexSet := rfl
      have hR : (attachStep pts st ⟨.right, vid⟩ none).rightIndexSet =
          insert vid st.rightIndexSet := by
        ext z
        simp [attachStep, LocalMatchingState.rightIndexSet, List.mem_toFinset, List.mem_map,
          Finset.mem_insert, eq_comm]
      have hM : (attachStep pts st ⟨.right, vid⟩ none).matching = st.matching := rfl
      unfold indexSymmDiffCost
      simp only [hL, hR, hM, symmDiff_self_card]
      have h1 := symmDiff_insert_card_le_one st.rightIndexSet vid
      omega
    | some w =>
      have hL : (attachStep pts st ⟨.right, vid⟩ (some w)).leftIndexSet =
          st.leftIndexSet.erase w := by
        ext z
        simp only [attachStep, LocalMatchingState.leftIndexSet, List.mem_toFinset, List.mem_map,
          List.mem_filter, decide_eq_true_eq, Finset.mem_erase]
        constructor
        · rintro ⟨e, ⟨he, hne⟩, rfl⟩
          exact ⟨hne, e, he, rfl⟩
        · rintro ⟨hne, e, he, rfl⟩
          exact ⟨e, ⟨he, hne⟩, rfl⟩
      have hR : (attachStep pts st ⟨.right, vid⟩ (some w)).rightIndexSet = st.rightIndexSet := rfl
      have hM : (attachStep pts st ⟨.right, vid⟩ (some w)).matching =
          insert (w, vid) st.matching := by
        ext xy
        simp [attachStep, LocalMatchingState.matching, MatchingEdge.pair, List.mem_toFinset,
          List.mem_map, Finset.mem_insert]
      unfold indexSymmDiffCost
      simp only [hL, hR, hM, symmDiff_self_card]
      exact ⟨by simpa using symmDiff_erase_card_le_one st.leftIndexSet w,
        symmDiff_insert_card_le_one st.matching (w, vid)⟩

private lemma removeCopies_costs_le_two {ι : Type*} [DecidableEq ι] {V_L V_R : Finset ι}
    (st : LocalMatchingState ι) (p : ι)
    (hbip : IsBipartiteMatching V_L V_R st.matching) :
    indexSymmDiffCost st (removeCopiesFromState st p) ≤ 2 ∧
    (symmDiff st.matching (removeCopiesFromState st p).matching).card ≤ 2 := by
  have hL : (removeCopiesFromState st p).leftIndexSet = st.leftIndexSet.erase p := by
    ext z
    simp only [removeCopiesFromState, LocalMatchingState.leftIndexSet, List.mem_toFinset,
      List.mem_map, List.mem_filter, decide_eq_true_eq, Finset.mem_erase]
    constructor
    · rintro ⟨e, ⟨he, hne⟩, rfl⟩
      exact ⟨hne, e, he, rfl⟩
    · rintro ⟨hne, e, he, rfl⟩
      exact ⟨e, ⟨he, hne⟩, rfl⟩
  have hR : (removeCopiesFromState st p).rightIndexSet = st.rightIndexSet.erase p := by
    ext z
    simp only [removeCopiesFromState, LocalMatchingState.rightIndexSet, List.mem_toFinset,
      List.mem_map, List.mem_filter, decide_eq_true_eq, Finset.mem_erase]
    constructor
    · rintro ⟨e, ⟨he, hne⟩, rfl⟩
      exact ⟨hne, e, he, rfl⟩
    · rintro ⟨hne, e, he, rfl⟩
      exact ⟨e, ⟨he, hne⟩, rfl⟩
  have hM : (removeCopiesFromState st p).matching =
      st.matching.filter (fun xy => xy.1 ≠ p ∧ xy.2 ≠ p) := by
    ext xy
    simp only [removeCopiesFromState, LocalMatchingState.matching, MatchingEdge.pair,
      List.mem_toFinset, List.mem_map, List.mem_filter, decide_eq_true_eq, Finset.mem_filter]
    constructor
    · rintro ⟨e, ⟨he, hne1, hne2⟩, rfl⟩
      exact ⟨⟨e, he, rfl⟩, hne1, hne2⟩
    · rintro ⟨⟨e, he, rfl⟩, hne1, hne2⟩
      exact ⟨e, ⟨he, hne1, hne2⟩, rfl⟩
  have hidx : indexSymmDiffCost st (removeCopiesFromState st p) ≤ 2 := by
    unfold indexSymmDiffCost
    rw [hL, hR]
    have h1 := symmDiff_erase_card_le_one st.leftIndexSet p
    have h2 := symmDiff_erase_card_le_one st.rightIndexSet p
    omega
  have hsubM : symmDiff st.matching (removeCopiesFromState st p).matching ⊆
      st.matching.filter (fun xy => xy.1 = p) ∪ st.matching.filter (fun xy => xy.2 = p) := by
    intro xy hxy
    rw [hM] at hxy
    unfold symmDiff at hxy
    simp only [Finset.sup_eq_union, Finset.mem_union, Finset.mem_sdiff, Finset.mem_filter] at hxy ⊢
    tauto
  have hc1 : (st.matching.filter (fun xy => xy.1 = p)).card ≤ 1 := by
    rw [Finset.card_le_one_iff]
    intro a b ha hb
    rcases a with ⟨a1, a2⟩
    rcases b with ⟨b1, b2⟩
    simp only [Finset.mem_filter] at ha hb
    rcases ha with ⟨hma, haEq⟩
    rcases hb with ⟨hmb, hbEq⟩
    exact Prod.ext (haEq.trans hbEq.symm) (hbip.2.1 p a2 b2 (haEq ▸ hma) (hbEq ▸ hmb))
  have hc2 : (st.matching.filter (fun xy => xy.2 = p)).card ≤ 1 := by
    rw [Finset.card_le_one_iff]
    intro a b ha hb
    rcases a with ⟨a1, a2⟩
    rcases b with ⟨b1, b2⟩
    simp only [Finset.mem_filter] at ha hb
    rcases ha with ⟨hma, haEq⟩
    rcases hb with ⟨hmb, hbEq⟩
    exact Prod.ext (hbip.2.2 a1 b1 p (haEq ▸ hma) (hbEq ▸ hmb)) (haEq.trans hbEq.symm)
  have hMcard : (symmDiff st.matching (removeCopiesFromState st p).matching).card ≤ 2 := by
    have hu := (Finset.card_le_card hsubM).trans (Finset.card_union_le _ _)
    omega
  exact ⟨hidx, hMcard⟩

open Classical in
private lemma sanitize_satisfies_promise {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) (st : LocalMatchingState ι) (v : CopyVertex ι)
    (rawAns : Option ι)
    (hprom : SatisfiesConfigSearchPromise pts params.m0 params.γ params.lam o V
      cfg.j cfg.k cfg.ℓ (st.oppositeIndexSet v.side) v.id rawAns) :
    SatisfiesAngularSearchPromise pts o
      (params.thresholdA V cfg.j cfg.k cfg.ℓ)
      (params.thresholdB V cfg.j cfg.k cfg.ℓ)
      (st.oppositeIndexSet v.side) v.id
      (sanitizeConfigAttachAnswer pts params o V cfg st v rawAns) := by
  cases rawAns with
  | none =>
    simpa [sanitizeConfigAttachAnswer, SatisfiesConfigSearchPromise,
      LocalScaleParams.thresholdA, LocalScaleParams.thresholdB] using hprom
  | some w =>
    unfold SatisfiesConfigSearchPromise SatisfiesAngularSearchPromise at hprom
    have hcond : w ∈ st.oppositeIndexSet v.side ∧
        attachAcceptsCorrelation o (pts v.id) (pts w) (params.thresholdB V cfg.j cfg.k cfg.ℓ) :=
      ⟨hprom.1, hprom.2⟩
    unfold sanitizeConfigAttachAnswer
    dsimp only
    rw [if_pos hcond]
    exact hprom

open Classical in
private lemma checkedRepairFormerPartners_take {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) :
    ∀ (F : List (CopyVertex ι)) (n : ℕ) (st : LocalMatchingState ι)
      (rawAnswers : List (Option ι)),
      F.length ≤ n →
      checkedRepairFormerPartners pts params o V cfg st F rawAnswers =
        checkedRepairFormerPartners pts params o V cfg st F (rawAnswers.take n)
  | [], _, st, _ => fun _ => rfl
  | u :: us, n, st, rawAnswers => fun hlen => by
      cases n with
      | zero => simp at hlen
      | succ m =>
        simp only [List.length_cons] at hlen
        unfold checkedRepairFormerPartners
        split_ifs with hcond
        · exact checkedRepairFormerPartners_take pts params o V cfg us (m + 1) st rawAnswers
            (by omega)
        · have hhead : (rawAnswers.take (m + 1)).head? = rawAnswers.head? := by
            cases rawAnswers <;> rfl
          have hdrop : (rawAnswers.take (m + 1)).drop 1 = (rawAnswers.drop 1).take m := by
            cases rawAnswers <;> simp
          dsimp only
          rw [hhead, hdrop]
          exact checkedRepairFormerPartners_take pts params o V cfg us m _ (rawAnswers.drop 1)
            (by omega)

private lemma checkedRepair_spec {d : ℕ} {ι : Type} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) (V_L' V_R' : Finset ι) :
    ∀ (F : List (CopyVertex ι)) (st : LocalMatchingState ι) (rawAnswers : List (Option ι)),
      (∀ u ∈ F, isCopyActive V_L' V_R' u) →
      ValidCheckedDeletePromises pts params o V cfg st F rawAnswers →
      let st' := checkedRepairFormerPartners pts params o V cfg st F rawAnswers
      ValidRepairAngularSteps pts o
        (params.thresholdA V cfg.j cfg.k cfg.ℓ)
        (params.thresholdB V cfg.j cfg.k cfg.ℓ)
        V_L' V_R' st F st' ∧
      indexSymmDiffCost st st' ≤ F.length ∧
      (symmDiff st.matching st'.matching).card ≤ F.length
  | [], st, _ => fun _ _ => by
      refine ⟨rfl, ?_, ?_⟩
      · simp [checkedRepairFormerPartners, indexSymmDiffCost]
      · simp [checkedRepairFormerPartners]
  | u :: us, st, rawAnswers => fun hact hprom => by
      unfold ValidCheckedDeletePromises at hprom
      unfold checkedRepairFormerPartners
      by_cases hcond : st.isCopyMatched u ∨ st.isCopyInIndex u
      · rw [if_pos hcond] at hprom ⊢
        have ih := checkedRepair_spec pts params o V cfg V_L' V_R' us st rawAnswers
          (fun x hx => hact x (List.mem_cons_of_mem u hx)) hprom
        refine ⟨Or.inl ⟨hcond, ih.1⟩, ?_, ?_⟩
        · exact ih.2.1.trans (Nat.le_succ _)
        · exact ih.2.2.trans (Nat.le_succ _)
      · rw [if_neg hcond] at hprom ⊢
        dsimp only at hprom ⊢
        rcases hprom with ⟨hp1, hp2⟩
        let cAns := sanitizeConfigAttachAnswer pts params o V cfg st u rawAnswers.head?.join
        let st₁ := attachStep pts st u cAns
        have ih := checkedRepair_spec pts params o V cfg V_L' V_R' us st₁ (rawAnswers.drop 1)
          (fun x hx => hact x (List.mem_cons_of_mem u hx)) hp2
        have hnot : ¬ st.isCopyMatched u ∧ ¬ st.isCopyInIndex u := not_or.mp hcond
        have hatt : ValidAttachAngularStep pts o
            (params.thresholdA V cfg.j cfg.k cfg.ℓ)
            (params.thresholdB V cfg.j cfg.k cfg.ℓ)
            V_L' V_R' st u st₁ :=
          ⟨⟨hact u List.mem_cons_self, hnot.1, hnot.2⟩,
            cAns, sanitize_satisfies_promise pts params o V cfg st u _ hp1, rfl⟩
        have hc1 := attachStep_costs_le_one pts st u cAns
        have htri_idx := indexSymmDiffCost_triangle st st₁
          (checkedRepairFormerPartners pts params o V cfg st₁ us (rawAnswers.drop 1))
        have htri_m := symmDiff_card_triangle st.matching st₁.matching
          (checkedRepairFormerPartners pts params o V cfg st₁ us (rawAnswers.drop 1)).matching
        refine ⟨Or.inr ⟨hcond, st₁, hatt, ih.1⟩, ?_, ?_⟩
        · simp only [List.length_cons]
          exact (htri_idx.trans (Nat.add_le_add hc1.1 ih.2.1)).trans (by omega)
        · simp only [List.length_cons]
          exact (htri_m.trans (Nat.add_le_add hc1.2 ih.2.2)).trans (by omega)

private lemma insert_eq_classical {ι : Type} [DecidableEq ι] (p : ι) (S : Finset ι) :
    @insert ι (Finset ι) (@Finset.instInsert ι (Classical.decEq ι)) p S = insert p S := by
  ext z; simp

private lemma erase_eq_classical {ι : Type} [DecidableEq ι] (p : ι) (S : Finset ι) :
    @Finset.erase ι (Classical.decEq ι) S p = S.erase p := by
  ext z; simp

theorem prove_part1 (h_inv_thm : S_clm_5_3_matching_invariant) :
    open Classical in
    (∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (params : LocalScaleParams)
      (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
      (S : Finset ι) (cfg : ShellConfig) (st : LocalMatchingState ι)
      (A_pad B_pad : ℝ),
      0 < V →
      cfg ∈ params.retainedConfigs V →
      A_pad ^ 2 + B_pad ^ 2 = 1 →
      st.WellFormed pts
        (params.leftVertices pts o V S cfg.j)
        (params.rightVertices pts o V S cfg.k) →
        (∀ x ∈ st.leftIndexSet,
          pts x ≠ o ∧
          ‖radialDirection o (pts x)‖ = 1 ∧
          IsUnitVec (liftedPoint (A_pad • radialDirection o (pts x)) B_pad)) ∧
        (∀ y ∈ st.rightIndexSet,
          pts y ≠ o ∧
          ‖radialDirection o (pts y)‖ = 1 ∧
          IsUnitVec (liftedPoint (A_pad • radialDirection o (pts y)) B_pad)) ∧
        (∀ z_hat : EuclideanSpace ℝ (Fin d),
          ‖z_hat‖ = 1 → IsUnitVec (liftedPoint (A_pad • z_hat) (-B_pad)))) ∧
    (∃ C_repairs : ℕ, 1 ≤ C_repairs ∧
      ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
        (pts : ι → EuclideanSpace ℝ (Fin d))
        (params : LocalScaleParams)
        (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
        (S : Finset ι) (cfg : ShellConfig) (st : LocalMatchingState ι),
        0 < V →
        cfg ∈ params.retainedConfigs V →
        st.SatisfiesInvariant pts
          (params.leftVertices pts o V S cfg.j)
          (params.rightVertices pts o V S cfg.k)
          (params.weakEdges pts o V S cfg.j cfg.k cfg.ℓ)
          (params.strongEdges pts o V S cfg.j cfg.k cfg.ℓ) →
        (∀ (p : ι) (rawLeft rawRight : Option ι),
          p ∉ S →
          ValidCheckedInsertPromises pts params o V cfg st p rawLeft rawRight →
            let st' := checkedConfigInsertOriginal pts params o V cfg st p rawLeft rawRight
            st'.SatisfiesInvariant pts
              (params.leftVertices pts o V (insert p S) cfg.j)
              (params.rightVertices pts o V (insert p S) cfg.k)
              (params.weakEdges pts o V (insert p S) cfg.j cfg.k cfg.ℓ)
              (params.strongEdges pts o V (insert p S) cfg.j cfg.k cfg.ℓ) ∧
            (symmDiff st.leftIndexSet st'.leftIndexSet).card +
              (symmDiff st.rightIndexSet st'.rightIndexSet).card ≤ C_repairs ∧
            (symmDiff st.matching st'.matching).card ≤ C_repairs) ∧
        (∀ (p : ι) (rawAnswers : List (Option ι)),
          p ∈ S →
          (survivingFormerPartners st p).length ≤ C_repairs ∧
          checkedConfigDeleteOriginal pts params o V cfg st p rawAnswers =
            checkedConfigDeleteOriginal pts params o V cfg st p (rawAnswers.take C_repairs) ∧
          (ValidCheckedDeletePromises pts params o V cfg
              (removeCopiesFromState st p) (survivingFormerPartners st p) rawAnswers →
            let st' := checkedConfigDeleteOriginal pts params o V cfg st p rawAnswers
            st'.SatisfiesInvariant pts
              (params.leftVertices pts o V (S.erase p) cfg.j)
              (params.rightVertices pts o V (S.erase p) cfg.k)
              (params.weakEdges pts o V (S.erase p) cfg.j cfg.k cfg.ℓ)
              (params.strongEdges pts o V (S.erase p) cfg.j cfg.k cfg.ℓ) ∧
            (symmDiff st.leftIndexSet st'.leftIndexSet).card +
              (symmDiff st.rightIndexSet st'.rightIndexSet).card ≤ C_repairs ∧
            (symmDiff st.matching st'.matching).card ≤ C_repairs))) := by
  refine ⟨?_, 4, by decide, ?_⟩
  · classical
    intro d ι _ pts params o V S cfg st A_pad B_pad _ hcfg hAB hwf
    obtain ⟨_, hj1, hk1⟩ := retainedConfigs_valid params hcfg
    rcases hwf with ⟨_, _, _, _, hLset, _, hRset, _⟩
    refine ⟨?_, ?_, ?_⟩
    · intro x hx
      rw [hLset] at hx
      have hxVL : x ∈ params.leftVertices pts o V S cfg.j := (Finset.mem_filter.mp hx).1
      unfold LocalScaleParams.leftVertices configLeftVertices shellSubset at hxVL
      have hsh : shellIndex params.m0 o V (pts x) = cfg.j := (Finset.mem_filter.mp hxVL).2
      have hne : pts x ≠ o := ne_center_of_shellIndex_pos hj1 hsh
      have hnorm : ‖radialDirection o (pts x)‖ = 1 := radialDirection_norm_one hne
      exact ⟨hne, hnorm, pad_isUnitVec _ hnorm hAB⟩
    · intro y hy
      rw [hRset] at hy
      have hyVR : y ∈ params.rightVertices pts o V S cfg.k := (Finset.mem_filter.mp hy).1
      unfold LocalScaleParams.rightVertices configRightVertices shellSubset at hyVR
      have hsh : shellIndex params.m0 o V (pts y) = cfg.k := (Finset.mem_filter.mp hyVR).2
      have hne : pts y ≠ o := ne_center_of_shellIndex_pos hk1 hsh
      have hnorm : ‖radialDirection o (pts y)‖ = 1 := radialDirection_norm_one hne
      exact ⟨hne, hnorm, pad_isUnitVec _ hnorm hAB⟩
    · intro z_hat hz
      have hAB_neg : A_pad ^ 2 + (-B_pad) ^ 2 = 1 := by linear_combination hAB
      exact pad_isUnitVec z_hat hz hAB_neg
  · intro d ι _ pts params o V S cfg st hV hcfg hinv
    dsimp only
    obtain ⟨hret_cfg, _, _⟩ := retainedConfigs_valid params hcfg
    have hthm := h_inv_thm d ι pts o V params.e params.γ params.lam params.K
      cfg.j cfg.k cfg.ℓ hV params.e_pos params.one_lt_γ params.one_lt_lam hret_cfg
    rcases hthm with ⟨_, _, hins_thm, hdel_thm, _⟩
    have hp_not_VL : ∀ p : ι, p ∉ S → p ∉ params.leftVertices pts o V S cfg.j := by
      classical
      intro p hpS hpL
      unfold LocalScaleParams.leftVertices configLeftVertices shellSubset nodeCore at hpL
      exact hpS ((Finset.mem_filter.mp (Finset.mem_filter.mp hpL).1).1)
    have hp_not_VR : ∀ p : ι, p ∉ S → p ∉ params.rightVertices pts o V S cfg.k := by
      classical
      intro p hpS hpR
      unfold LocalScaleParams.rightVertices configRightVertices shellSubset nodeEligible at hpR
      exact hpS ((Finset.mem_filter.mp (Finset.mem_filter.mp hpR).1).1)
    refine ⟨?_, ?_⟩
    · intro p rawLeft rawRight hpS hprom
      let V_L' := params.leftVertices pts o V (insert p S) cfg.j
      let V_R' := params.rightVertices pts o V (insert p S) cfg.k
      have hp_iff_L : p ∈ V_L' ↔ hasApplicableLeftCopy params.m0 o V cfg.j (pts p) := by
        simp [V_L', LocalScaleParams.leftVertices, configLeftVertices, shellSubset, nodeCore,
          hasApplicableLeftCopy]
      have hp_iff_R : p ∈ V_R' ↔ hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p) := by
        simp [V_R', LocalScaleParams.rightVertices, configRightVertices, shellSubset, nodeEligible,
          hasApplicableRightCopy]
      rcases hinv with ⟨hwf_orig, hloc_orig⟩
      have hinv_full : st.SatisfiesInvariant pts
          (params.leftVertices pts o V S cfg.j)
          (params.rightVertices pts o V S cfg.k)
          (params.weakEdges pts o V S cfg.j cfg.k cfg.ℓ)
          (params.strongEdges pts o V S cfg.j cfg.k cfg.ℓ) := ⟨hwf_orig, hloc_orig⟩
      have hp_no_matchL : ¬ st.isCopyMatched ⟨.left, p⟩ := by
        rintro ⟨e, he, hEq⟩
        dsimp only at hEq
        exact hp_not_VL p hpS (hEq ▸ (hwf_orig.2.2.1 e he).1)
      have hp_no_idxL : ¬ st.isCopyInIndex ⟨.left, p⟩ := by
        classical
        rintro ⟨e, he, hEq⟩
        have hmem : p ∈ st.leftIndexSet := by
          simp only [LocalMatchingState.leftIndexSet, List.mem_toFinset, List.mem_map]
          exact ⟨e, he, hEq⟩
        rw [hwf_orig.2.2.2.2.1] at hmem
        exact hp_not_VL p hpS (Finset.mem_filter.mp hmem).1
      have hp_no_matchR : ¬ st.isCopyMatched ⟨.right, p⟩ := by
        rintro ⟨e, he, hEq⟩
        dsimp only at hEq
        exact hp_not_VR p hpS (hEq ▸ (hwf_orig.2.2.1 e he).2.1)
      have hp_no_idxR : ¬ st.isCopyInIndex ⟨.right, p⟩ := by
        classical
        rintro ⟨e, he, hEq⟩
        have hmem : p ∈ st.rightIndexSet := by
          simp only [LocalMatchingState.rightIndexSet, List.mem_toFinset, List.mem_map]
          exact ⟨e, he, hEq⟩
        rw [hwf_orig.2.2.2.2.2.2.1] at hmem
        exact hp_not_VR p hpS (Finset.mem_filter.mp hmem).1
      unfold ValidCheckedInsertPromises at hprom
      rcases hprom with ⟨hpromL, hpromR⟩
      let st₁ :=
        open Classical in
        if hasApplicableLeftCopy params.m0 o V cfg.j (pts p) then
          attachStep pts st ⟨.left, p⟩
            (sanitizeConfigAttachAnswer pts params o V cfg st ⟨.left, p⟩ rawLeft)
        else
          st
      have hstep1 :
          ((p ∈ V_L' ∧ ValidAttachAngularStep pts o
              (params.thresholdA V cfg.j cfg.k cfg.ℓ)
              (params.thresholdB V cfg.j cfg.k cfg.ℓ)
              V_L' V_R' st ⟨.left, p⟩ st₁) ∨
            (p ∉ V_L' ∧ st₁ = st)) ∧
          indexSymmDiffCost st st₁ ≤ 1 ∧
          (symmDiff st.matching st₁.matching).card ≤ 1 ∧
          ¬ st₁.isCopyMatched ⟨.right, p⟩ ∧
          ¬ st₁.isCopyInIndex ⟨.right, p⟩ := by
        by_cases hLapp : hasApplicableLeftCopy params.m0 o V cfg.j (pts p)
        · have hpVL' : p ∈ V_L' := hp_iff_L.mpr hLapp
          set cL := sanitizeConfigAttachAnswer pts params o V cfg st ⟨.left, p⟩ rawLeft with hcL_def
          have hst1_eq : st₁ = attachStep pts st ⟨.left, p⟩ cL := if_pos hLapp
          have hsanL : SatisfiesAngularSearchPromise pts o
              (params.thresholdA V cfg.j cfg.k cfg.ℓ)
              (params.thresholdB V cfg.j cfg.k cfg.ℓ)
              (st.oppositeIndexSet (⟨.left, p⟩ : CopyVertex ι).side)
              (⟨.left, p⟩ : CopyVertex ι).id cL :=
            sanitize_satisfies_promise pts params o V cfg st ⟨.left, p⟩ rawLeft (hpromL hLapp)
          have hattL : ValidAttachAngularStep pts o
              (params.thresholdA V cfg.j cfg.k cfg.ℓ)
              (params.thresholdB V cfg.j cfg.k cfg.ℓ)
              V_L' V_R' st ⟨.left, p⟩ st₁ :=
            ⟨⟨hpVL', hp_no_matchL, hp_no_idxL⟩, cL, hsanL, hst1_eq⟩
          have hcL := attachStep_costs_le_one pts st ⟨.left, p⟩ cL
          have hno_mR1 : ¬ st₁.isCopyMatched ⟨.right, p⟩ := by
            rw [hst1_eq]
            rcases hcL_val : cL with _ | w
            · exact hp_no_matchR
            · rw [hcL_val] at hsanL
              have hw_inR : w ∈ st.rightIndexSet := hsanL.1
              rw [hwf_orig.2.2.2.2.2.2.1] at hw_inR
              have hw_ne_p : w ≠ p := by
                classical
                intro hEq
                exact hp_not_VR p hpS (hEq ▸ (Finset.mem_filter.mp hw_inR).1)
              rintro ⟨e, he, heR⟩
              simp only [attachStep, List.mem_append, List.mem_singleton] at he
              rcases he with he_old | rfl
              · exact hp_no_matchR ⟨e, he_old, heR⟩
              · exact hw_ne_p heR
          have hno_iR1 : ¬ st₁.isCopyInIndex ⟨.right, p⟩ := by
            rw [hst1_eq]
            rcases cL with _ | w
            · exact hp_no_idxR
            · rintro ⟨e, he, heId⟩
              simp only [attachStep, List.mem_filter] at he
              exact hp_no_idxR ⟨e, he.1, heId⟩
          rw [← hst1_eq] at hcL
          exact ⟨Or.inl ⟨hpVL', hattL⟩, hcL.1, hcL.2, hno_mR1, hno_iR1⟩
        · have hp_notVL' : p ∉ V_L' := fun h => hLapp (hp_iff_L.mp h)
          have hst1_eq : st₁ = st := if_neg hLapp
          rw [hst1_eq]
          exact ⟨Or.inr ⟨hp_notVL', rfl⟩,
            by simp [indexSymmDiffCost, symmDiff_self_card],
            by simp [symmDiff_self_card],
            hp_no_matchR, hp_no_idxR⟩
      rcases hstep1 with ⟨hor1, hcost1_idx, hcost1_m, hno_mR1, hno_iR1⟩
      let st' := checkedConfigInsertOriginal pts params o V cfg st p rawLeft rawRight
      have hstep2 :
          ((p ∈ V_R' ∧ ValidAttachAngularStep pts o
              (params.thresholdA V cfg.j cfg.k cfg.ℓ)
              (params.thresholdB V cfg.j cfg.k cfg.ℓ)
              V_L' V_R' st₁ ⟨.right, p⟩ st') ∨
            (p ∉ V_R' ∧ st' = st₁)) ∧
          indexSymmDiffCost st₁ st' ≤ 1 ∧
          (symmDiff st₁.matching st'.matching).card ≤ 1 := by
        by_cases hRapp : hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p)
        · have hpVR' : p ∈ V_R' := hp_iff_R.mpr hRapp
          let cR := sanitizeConfigAttachAnswer pts params o V cfg st₁ ⟨.right, p⟩ rawRight
          have hst'_eq : st' = attachStep pts st₁ ⟨.right, p⟩ cR := by
            unfold st' checkedConfigInsertOriginal
            exact if_pos hRapp
          have hsanR := sanitize_satisfies_promise pts params o V cfg st₁ ⟨.right, p⟩ rawRight
            (hpromR hRapp)
          have hattR : ValidAttachAngularStep pts o
              (params.thresholdA V cfg.j cfg.k cfg.ℓ)
              (params.thresholdB V cfg.j cfg.k cfg.ℓ)
              V_L' V_R' st₁ ⟨.right, p⟩ st' :=
            ⟨⟨hpVR', hno_mR1, hno_iR1⟩, cR, hsanR, hst'_eq⟩
          have hcR := attachStep_costs_le_one pts st₁ ⟨.right, p⟩ cR
          rw [← hst'_eq] at hcR
          exact ⟨Or.inl ⟨hpVR', hattR⟩, hcR.1, hcR.2⟩
        · have hp_notVR' : p ∉ V_R' := fun h => hRapp (hp_iff_R.mp h)
          have hst'_eq : st' = st₁ := by
            unfold st' checkedConfigInsertOriginal
            exact if_neg hRapp
          rw [hst'_eq]
          exact ⟨Or.inr ⟨hp_notVR', rfl⟩,
            by simp [indexSymmDiffCost, symmDiff_self_card],
            by simp [symmDiff_self_card]⟩
      rcases hstep2 with ⟨hor2, hcost2_idx, hcost2_m⟩
      have hvalid_ins : ValidInsertOriginalAngularStep pts o
          (params.thresholdA V cfg.j cfg.k cfg.ℓ)
          (params.thresholdB V cfg.j cfg.k cfg.ℓ)
          V_L' V_R' st p st' := ⟨st₁, hor1, hor2⟩
      have hins_step := hins_thm S p st st' hpS hinv_full
      rw [insert_eq_classical p S] at hins_step
      have hinv' : st'.SatisfiesInvariant pts
          (params.leftVertices pts o V (insert p S) cfg.j)
          (params.rightVertices pts o V (insert p S) cfg.k)
          (params.weakEdges pts o V (insert p S) cfg.j cfg.k cfg.ℓ)
          (params.strongEdges pts o V (insert p S) cfg.j cfg.k cfg.ℓ) :=
        hins_step hvalid_ins
      have htri_idx := indexSymmDiffCost_triangle st st₁ st'
      have htri_m := symmDiff_card_triangle st.matching st₁.matching st'.matching
      exact ⟨hinv',
        (htri_idx.trans (Nat.add_le_add hcost1_idx hcost2_idx)).trans (by decide),
        (htri_m.trans (Nat.add_le_add hcost1_m hcost2_m)).trans (by decide)⟩
    · intro p rawAnswers hpS
      have hdel_spec := hdel_thm S p st hpS hinv
      rcases hdel_spec with ⟨_, hlen2, _, hdel_valid_inv⟩
      refine ⟨by omega, ?_, ?_⟩
      · unfold checkedConfigDeleteOriginal
        exact checkedRepairFormerPartners_take pts params o V cfg
          (survivingFormerPartners st p) 4 (removeCopiesFromState st p) rawAnswers (by omega)
      · intro hprom_del
        let V_L' := params.leftVertices pts o V (S.erase p) cfg.j
        let V_R' := params.rightVertices pts o V (S.erase p) cfg.k
        have hVL_erase : (params.leftVertices pts o V S cfg.j).erase p = V_L' := by
          ext z
          simp only [V_L', LocalScaleParams.leftVertices, configLeftVertices, shellSubset,
            nodeCore, Finset.mem_erase, Finset.mem_filter]
          tauto
        have hVR_erase : (params.rightVertices pts o V S cfg.k).erase p = V_R' := by
          ext z
          simp only [V_R', LocalScaleParams.rightVertices, configRightVertices, shellSubset,
            nodeEligible, Finset.mem_erase, Finset.mem_filter]
          tauto
        have hactF : ∀ u ∈ survivingFormerPartners st p, isCopyActive V_L' V_R' u := by
          intro u hu
          have ha := surviving_partners_active hinv.1 p hu
          rw [erase_eq_classical p (params.leftVertices pts o V S cfg.j),
              erase_eq_classical p (params.rightVertices pts o V S cfg.k),
              hVL_erase, hVR_erase] at ha
          exact ha
        have hrep := checkedRepair_spec pts params o V cfg V_L' V_R'
          (survivingFormerPartners st p) (removeCopiesFromState st p) rawAnswers hactF hprom_del
        let st' := checkedConfigDeleteOriginal pts params o V cfg st p rawAnswers
        have hvalid_del : ValidDeleteOriginalAngularStep pts o
            (params.thresholdA V cfg.j cfg.k cfg.ℓ)
            (params.thresholdB V cfg.j cfg.k cfg.ℓ)
            V_L' V_R' st p st' :=
          ⟨survivingFormerPartners st p, List.Perm.refl _, hrep.1⟩
        have hdel_step := hdel_valid_inv st'
        rw [erase_eq_classical p S] at hdel_step
        have hinv' : st'.SatisfiesInvariant pts
            (params.leftVertices pts o V (S.erase p) cfg.j)
            (params.rightVertices pts o V (S.erase p) cfg.k)
            (params.weakEdges pts o V (S.erase p) cfg.j cfg.k cfg.ℓ)
            (params.strongEdges pts o V (S.erase p) cfg.j cfg.k cfg.ℓ) :=
          hdel_step hvalid_del
        have hrem_costs := removeCopies_costs_le_two st p hinv.2.2.1
        have htri_idx := indexSymmDiffCost_triangle st (removeCopiesFromState st p) st'
        have htri_m := symmDiff_card_triangle st.matching
          (removeCopiesFromState st p).matching st'.matching
        have hrep_idx : indexSymmDiffCost (removeCopiesFromState st p) st' ≤
            (survivingFormerPartners st p).length := hrep.2.1
        have hrep_m : (symmDiff (removeCopiesFromState st p).matching st'.matching).card ≤
            (survivingFormerPartners st p).length := hrep.2.2
        have hrem_idx := hrem_costs.1
        have hrem_m := hrem_costs.2
        exact ⟨hinv',
          (htri_idx.trans (Nat.add_le_add hrem_idx hrep_idx)).trans (by omega),
          (htri_m.trans (Nat.add_le_add hrem_m hrep_m)).trans (by omega)⟩

end UL.Proof_clm_7_3_global_approx
