import UL.Stmt.clm_6_1_adaptive
import UL.Stmt.lem_5_6
import UL.Stmt.clm_5_4_queries_and_caps
import UL.Stmt.lem_6_3
import UL.Proof.lem_6_2
import UL.Proof.clm_6_1_adaptive.RaceP32_H4c
set_option autoImplicit false

open MeasureTheory ProbabilityTheory

namespace UL.Proof_clm_6_1_adaptive_RaceP32

open UL UL.Proof_clm_6_1_adaptive_RaceV30 UL.Proof_lem_6_3 UL.Proof.lem_6_3.RacerV30
open UL.Proof_clm_6_1_adaptive

/-! ### 1. Top-level polynomial, work, and space accounting helpers -/

noncomputable def adaptivePolyConst (c_h : ℝ) (ℓ : ℕ) : ℝ :=
  10000000 * ((ℓ : ℝ) + 1) ^ 3 * cParamConst c_h ℓ

def adaptiveDeg (ℓ : ℕ) : ℕ := 2 * ℓ + 6

theorem cParamConst_ge_800 {c_h : ℝ} (hc_h : 0 < c_h) {ℓ : ℕ} (hℓ : 1 ≤ ℓ) :
    800 ≤ cParamConst c_h ℓ := by
  unfold cParamConst
  dsimp only
  have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := Nat.one_le_cast.mpr hℓ
  have hlog : 0 ≤ Real.log (100 * (ℓ : ℝ)) := Real.log_nonneg (by linarith)
  have hc0 : 0 ≤ (Real.log (100 * (ℓ : ℝ)) / c_h + 2) * 64 := by positivity
  have hcE : 0 ≤ max (1 : ℝ) (cExpBound ℓ) := le_trans zero_le_one (le_max_left _ _)
  have hprod : 0 ≤ 800 * ((Real.log (100 * (ℓ : ℝ)) / c_h + 2) * 64) ^ ℓ *
      (max 1 (cExpBound ℓ)) ^ 2 := by positivity
  linarith

theorem adaptivePolyConst_pos {c_h : ℝ} (hc_h : 0 < c_h) {ℓ : ℕ} (hℓ : 1 ≤ ℓ) :
    0 < adaptivePolyConst c_h ℓ := by
  unfold adaptivePolyConst
  have h800 := cParamConst_ge_800 hc_h hℓ
  positivity

theorem RParam_bounds {d m : ℕ} (hd : 1 ≤ d) (hm : 1 ≤ m)
    {η : ℚ} (h2_log : 2 ≤ Real.log ((d : ℝ) / (η : ℝ)))
    {ε₀ : ℝ} (hε0 : 0 < ε₀) (hε_half : ε₀ < 1 / 2) :
    let R := RParam d m η ε₀
    1 ≤ R ∧
    (R : ℝ) ≤ 5 * (Real.log ((m : ℝ) / ε₀) + (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) ∧
    4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ≤ (R : ℝ) := by
  dsimp only
  have h1 : 1 ≤ RParam d m η ε₀ := by unfold RParam; omega
  have hm1 : (1 : ℝ) ≤ (m : ℝ) := Nat.one_le_cast.mpr hm
  have hd1 : (1 : ℝ) ≤ (d : ℝ) := Nat.one_le_cast.mpr hd
  have hm_eps : 2 ≤ (m : ℝ) / ε₀ := by
    rw [le_div_iff₀ hε0]
    linarith
  have hlog_me : 0 ≤ Real.log ((m : ℝ) / ε₀) := Real.log_nonneg (by linarith)
  have hd_log : 2 ≤ (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) := by
    calc (2 : ℝ) = 1 * 2 := by ring
      _ ≤ (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) :=
          mul_le_mul hd1 h2_log (by norm_num) (by positivity)
  set S_R : ℝ := Real.log ((m : ℝ) / ε₀) + 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))
  have hSR_nn : 0 ≤ S_R := by dsimp [S_R]; linarith
  have hceil_ge : S_R ≤ (Nat.ceil S_R : ℝ) := Nat.le_ceil S_R
  have hceil_lt : (Nat.ceil S_R : ℝ) < S_R + 1 := Nat.ceil_lt_add_one hSR_nn
  have hR_eq : (RParam d m η ε₀ : ℝ) = (Nat.ceil S_R : ℝ) + 1 := by
    unfold RParam
    push_cast
    rfl
  refine ⟨h1, ?_, ?_⟩
  · rw [hR_eq]
    dsimp [S_R] at hceil_lt
    linarith
  · rw [hR_eq]
    dsimp [S_R] at hceil_ge
    linarith

theorem listGetIntD_ofFn {α : Type} {n : ℕ} (f : Fin n → α) (c : Fin n) (fallback : α) :
    listGetIntD (List.ofFn f) (c.val : ℤ) fallback = f c := by
  simp only [listGetIntD, Nat.cast_nonneg, ↓reduceIte, Int.toNat_natCast]
  rw [list_getD_eq_getElem _ c.val (by simp [c.isLt]) fallback]
  simp

theorem exec_roundProg_bound {d : ℕ} (hd : 1 ≤ d)
    {η : ℚ} (hη0 : 0 < η) (hη16 : (η : ℝ) ≤ 1 / 16)
    (h2_log : 2 ≤ Real.log ((d : ℝ) / (η : ℝ)))
    {z : EuclideanSpace ℝ (Fin d)} (hz : IsUnitVec z) :
    let roundProg : ArithRAMStmt := roundSubroutine (.intParam (.lit 0)) (.intParam (.lit 1)) 0 11 17
    let inp_round : ArithRAMInput d :=
      { intParams := [η.num, (η.den : ℤ)]
        activeHandles := ∅
        activeCoords := fun _ => 0
        extraReals := List.ofFn (fun c : Fin d => euclideanCoord z c) }
    ∃ out_r : ArithRAMExecOutcome,
      runArithRAMWithBits roundProg inp_round ArithRAMMemory.empty [] = some out_r ∧
      (∀ c : Fin d, out_r.mem.words.read (.heap 0 (c.val : ℤ)) = roundLatFn d η z c) ∧
      (out_r.unitCost : ℝ) ≤ 600 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ∧
      (out_r.peakCellSpace : ℝ) ≤ 600 * (d : ℝ) := by
  intro roundProg inp_round
  rcases exec_roundSubroutine hd hη0 hη16 hz inp_round
    (fun c => listGetIntD_ofFn _ c 0)
    (.intParam (.lit 0)) (.intParam (.lit 1)) 0 11 17 (by decide)
    ArithRAMMemory.empty cleanMem_empty
    (fun _ _ _ => trivial)
    (fun ws _ =>
      let e0 := evalIntExpr inp_round.toWordView 0 ws (.intParam (.lit 0))
      ⟨e0.2.1, e0.2.2,
        Prod.ext (by simp [inp_round, ArithRAMInput.toWordView, evalIntExpr, listGetIntD]) rfl,
        by simp [e0, evalIntExpr]⟩)
    (fun ws _ =>
      let e1 := evalIntExpr inp_round.toWordView 0 ws (.intParam (.lit 1))
      ⟨e1.2.1, e1.2.2,
        Prod.ext (by simp [inp_round, ArithRAMInput.toWordView, evalIntExpr, listGetIntD]) rfl,
        by simp [e1, evalIntExpr]⟩)
    with ⟨mem₁, C_cost, hs_r, hC_ub, hw_out, _, _, _, _, _, hlw, hlr⟩
  rcases hs_r.to_run with ⟨out_r, hrun_r, hmem_r, hunit_r, hpeak_r⟩
  have _ := h2_log
  refine ⟨out_r, hrun_r, ?_, ?_, ?_⟩
  · intro c
    rw [hmem_r]
    exact hw_out c
  · have hu_r : (out_r.unitCost : ℝ) ≤ (C_cost : ℝ) := Nat.cast_le.mpr hunit_r
    linarith
  · have hinp_sp : inp_round.inputCellSpace = d + 2 := by
      simp [inp_round, ArithRAMInput.inputCellSpace]
      omega
    have hlive_w_emp : ArithRAMMemory.empty.words.live = ∅ := rfl
    have hlive_r_emp : ArithRAMMemory.empty.reals.live = ∅ := rfl
    rw [hlive_w_emp, Finset.empty_union] at hlw
    rw [hlive_r_emp, Finset.empty_union] at hlr
    have hcw : mem₁.words.live.card ≤ d + 6 := by
      calc mem₁.words.live.card
          ≤ (heapRange 0 d ∪ heapRange 11 6).card := Finset.card_le_card hlw
        _ ≤ (heapRange 0 d).card + (heapRange 11 6).card := Finset.card_union_le _ _
        _ ≤ d + 6 := Nat.add_le_add (card_heapRange_le 0 d) (card_heapRange_le 11 6)
    have hcr : mem₁.reals.live.card ≤ 3 :=
      (Finset.card_le_card hlr).trans (card_heapRange_le 17 3)
    have hpeak_nat : out_r.peakCellSpace ≤ 600 * d := by
      rw [hpeak_r, hinp_sp]
      unfold ArithRAMMemory.cellCount WordStore.cellCount RealStore.cellCount
      omega
    exact_mod_cast hpeak_nat

set_option maxHeartbeats 800000 in
theorem init_work_le_dataWorkBound
    {c_h : ℝ} (hc_h : 0 < c_h) {d ℓ m R M₀ : ℕ}
    (hd : 1 ≤ d) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (hR : 1 ≤ R)
    {η : ℚ} (h2_log : 2 ≤ Real.log ((d : ℝ) / (η : ℝ)))
    (hR_log : 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ≤ (R : ℝ))
    {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1)
    (hM0_ub : (M₀ : ℝ) ≤ cParamConst c_h ℓ * (Real.log (2 * (m : ℝ))) ^ 2 *
      (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))
    (hdu_ub : (doubleSteps (targetUVal c_h ℓ m hℓ hm h x) : ℝ) ≤
      cParamConst c_h ℓ * (Real.log (2 * (m : ℝ)) + 1))
    (hdq_ub : (doubleSteps (max (targetQ1Val c_h ℓ m hℓ hm h x)
      (targetQ2Val c_h ℓ m hℓ hm h x)) : ℝ) ≤
      cParamConst c_h ℓ * (Real.log (2 * (m : ℝ)) + 1))
    {C_init : ℕ}
    (hC : (C_init : ℝ) ≤
      2000 + 40 * (L_m m : ℝ) +
      (((kStar ℓ m hℓ hm + 6 : ℕ) : ℝ) * (70 + 20 * (N_pow ℓ m : ℝ))) +
      25 * (doubleSteps (targetUVal c_h ℓ m hℓ hm h x) : ℝ) +
      25 * (doubleSteps (max (targetQ1Val c_h ℓ m hℓ hm h x) (targetQ2Val c_h ℓ m hℓ hm h x)) : ℝ) +
      900 * Real.log ((d : ℝ) / (η : ℝ)) +
      30 * ((R * (ℓ * M₀) * (d + 1) : ℕ) : ℝ)) :
    (C_init : ℝ) ≤
      (R : ℝ) * ((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        (adaptivePolyConst c_h ℓ * ((d : ℝ) + Real.log (2 * (m : ℝ))) ^ (adaptiveDeg ℓ)) := by
  rcases L_m_bounds hm with ⟨_, _, _, _, hLlog_half, hLm_ub⟩
  rcases UL.Proof_clm_6_1_adaptive_RaceV30.I_h_bounds hh0 hh1 hx0 hx1 with ⟨_, _, hu0, _, _, _, _⟩
  have hk_ub_nat : kStar ℓ m hℓ hm ≤ ℓ * L_m m * (L_m m + 2) := (tParam_bounds hℓ hm).1
  set Llog := Real.log (2 * (m : ℝ))
  set X := (d : ℝ) + Llog
  set C_p := cParamConst c_h ℓ
  set S_m := (m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))
  have hCp800 : 800 ≤ C_p := cParamConst_ge_800 hc_h hℓ
  have hd1 : (1 : ℝ) ≤ (d : ℝ) := Nat.one_le_cast.mpr hd
  have hm1 : (1 : ℝ) ≤ (m : ℝ) := Nat.one_le_cast.mpr hm
  have hR1 : (1 : ℝ) ≤ (R : ℝ) := Nat.one_le_cast.mpr hR
  have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := Nat.one_le_cast.mpr hℓ
  have hX1 : 1 ≤ X := by dsimp [X]; linarith
  have hmu1 : 1 ≤ (m : ℝ) ^ (u_search h x) := Real.one_le_rpow hm1 hu0
  have hmb0 : 0 ≤ (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by positivity
  have hSm1 : 1 ≤ S_m := by dsimp [S_m]; linarith
  have hRSm1 : 1 ≤ (R : ℝ) * S_m := by
    calc (1 : ℝ) = 1 * 1 := by ring
      _ ≤ (R : ℝ) * S_m := mul_le_mul hR1 hSm1 zero_le_one (by positivity)
  have hLm_X : (L_m m : ℝ) ≤ 2 * X := by dsimp [X]; linarith
  -- Bound kStar + 6 ≤ 14 * (ℓ + 1) * X ^ 2
  have hk_X : ((kStar ℓ m hℓ hm + 6 : ℕ) : ℝ) ≤ 14 * ((ℓ : ℝ) + 1) * X ^ 2 := by
    have hk_r : (kStar ℓ m hℓ hm : ℝ) ≤ (ℓ : ℝ) * (L_m m : ℝ) * ((L_m m : ℝ) + 2) := by
      exact_mod_cast hk_ub_nat
    have hL2 : (L_m m : ℝ) + 2 ≤ 4 * X := by linarith
    have hprod1 : (L_m m : ℝ) * ((L_m m : ℝ) + 2) ≤ (2 * X) * (4 * X) :=
      mul_le_mul hLm_X hL2 (by positivity) (by positivity)
    have hprod2 : (ℓ : ℝ) * ((L_m m : ℝ) * ((L_m m : ℝ) + 2)) ≤ (ℓ : ℝ) * (8 * X ^ 2) :=
      mul_le_mul_of_nonneg_left (by linarith [show (2 * X) * (4 * X) = 8 * X ^ 2 by ring]) (by positivity)
    have h6_X2 : (6 : ℝ) ≤ 6 * ((ℓ : ℝ) + 1) * X ^ 2 := by
      have hX2 : 1 ≤ X ^ 2 := one_le_pow₀ hX1
      nlinarith
    push_cast
    nlinarith
  -- Bound 70 + 20 * N_pow ≤ 320100 * (ℓ + 1) ^ 2 * X ^ 4
  have hN_X : 70 + 20 * (N_pow ℓ m : ℝ) ≤ 320100 * ((ℓ : ℝ) + 1) ^ 2 * X ^ 4 := by
    have hN_eq : (N_pow ℓ m : ℝ) = 1000 * (ℓ : ℝ) ^ 2 * (L_m m : ℝ) ^ 4 + 1 := by
      unfold N_pow; push_cast; ring
    have hL4 : (L_m m : ℝ) ^ 4 ≤ (2 * X) ^ 4 :=
      pow_le_pow_left₀ (Nat.cast_nonneg _) hLm_X 4
    have h2X4 : (2 * X) ^ 4 = 16 * X ^ 4 := by ring
    have hX4 : 1 ≤ X ^ 4 := one_le_pow₀ hX1
    have hℓ_sq : (ℓ : ℝ) ^ 2 ≤ ((ℓ : ℝ) + 1) ^ 2 :=
      pow_le_pow_left₀ (by positivity) (by linarith) 2
    have h1_le : 1 ≤ ((ℓ : ℝ) + 1) ^ 2 * X ^ 4 := by
      calc (1 : ℝ) = 1 * 1 := by ring
        _ ≤ ((ℓ : ℝ) + 1) ^ 2 * X ^ 4 := mul_le_mul (one_le_pow₀ (by linarith)) hX4 zero_le_one (by positivity)
    have hprod : (ℓ : ℝ) ^ 2 * (L_m m : ℝ) ^ 4 ≤ 16 * ((ℓ : ℝ) + 1) ^ 2 * X ^ 4 := by
      calc (ℓ : ℝ) ^ 2 * (L_m m : ℝ) ^ 4
          ≤ ((ℓ : ℝ) + 1) ^ 2 * (16 * X ^ 4) :=
            mul_le_mul hℓ_sq (by linarith) (by positivity) (by positivity)
        _ = 16 * ((ℓ : ℝ) + 1) ^ 2 * X ^ 4 := by ring
    rw [hN_eq]
    linarith
  -- Combine kStar * N_pow term
  have h_kN : (((kStar ℓ m hℓ hm + 6 : ℕ) : ℝ) * (70 + 20 * (N_pow ℓ m : ℝ))) ≤
      4481400 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by
    have hp1 := mul_le_mul hk_X hN_X (by positivity) (by positivity)
    have hp1_eq : (14 * ((ℓ : ℝ) + 1) * X ^ 2) * (320100 * ((ℓ : ℝ) + 1) ^ 2 * X ^ 4) =
        4481400 * ((ℓ : ℝ) + 1) ^ 3 * X ^ 6 := by ring
    have hX6_deg : X ^ 6 ≤ X ^ (adaptiveDeg ℓ) :=
      pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega)
    calc _ ≤ 4481400 * ((ℓ : ℝ) + 1) ^ 3 * X ^ 6 := by linarith
      _ = 4481400 * ((ℓ : ℝ) + 1) ^ 3 * 1 * X ^ 6 * 1 := by ring
      _ ≤ 4481400 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by
          have hc1 : (1 : ℝ) ≤ C_p := by linarith
          refine mul_le_mul (mul_le_mul (mul_le_mul_of_nonneg_left hc1 (by positivity))
            hX6_deg (by positivity) (by positivity)) hRSm1 zero_le_one (by positivity)
  -- Bound remaining 4 groups
  have h_base : 2000 + 40 * (L_m m : ℝ) ≤
      2080 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by
    have h1 : 2000 + 40 * (L_m m : ℝ) ≤ 2080 * X := by linarith
    have hX_deg : X ≤ X ^ (adaptiveDeg ℓ) := by
      simpa using pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega : 1 ≤ adaptiveDeg ℓ)
    have hge1 : 1 ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p := by
      calc (1 : ℝ) = 1 * 1 := by ring
        _ ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p :=
          mul_le_mul (one_le_pow₀ (by linarith)) (by linarith) zero_le_one (by positivity)
    calc 2000 + 40 * (L_m m : ℝ) ≤ 2080 * 1 * X * 1 := by linarith
      _ ≤ 2080 * (((ℓ : ℝ) + 1) ^ 3 * C_p) * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by
          refine mul_le_mul (mul_le_mul (mul_le_mul_of_nonneg_left hge1 (by norm_num))
            hX_deg (by positivity) (by positivity)) hRSm1 zero_le_one (by positivity)
      _ = 2080 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by ring
  have h_dbl : 25 * (doubleSteps (targetUVal c_h ℓ m hℓ hm h x) : ℝ) +
      25 * (doubleSteps (max (targetQ1Val c_h ℓ m hℓ hm h x) (targetQ2Val c_h ℓ m hℓ hm h x)) : ℝ) ≤
      100 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by
    have hL1_2X : Llog + 1 ≤ 2 * X := by dsimp [X]; linarith
    have hd1' : 25 * (doubleSteps (targetUVal c_h ℓ m hℓ hm h x) : ℝ) +
        25 * (doubleSteps (max (targetQ1Val c_h ℓ m hℓ hm h x) (targetQ2Val c_h ℓ m hℓ hm h x)) : ℝ) ≤
        50 * C_p * (Llog + 1) := by linarith
    have hd2' : 50 * C_p * (Llog + 1) ≤ 100 * C_p * X := by
      calc 50 * C_p * (Llog + 1) ≤ 50 * C_p * (2 * X) :=
            mul_le_mul_of_nonneg_left hL1_2X (by positivity)
        _ = 100 * C_p * X := by ring
    have hX_deg : X ≤ X ^ (adaptiveDeg ℓ) := by
      simpa using pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega : 1 ≤ adaptiveDeg ℓ)
    have hℓ3 : 1 ≤ ((ℓ : ℝ) + 1) ^ 3 := one_le_pow₀ (by linarith)
    calc _ ≤ 100 * 1 * C_p * X * 1 := by linarith
      _ ≤ 100 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by
          refine mul_le_mul (mul_le_mul (mul_le_mul_of_nonneg_right
            (mul_le_mul_of_nonneg_left hℓ3 (by norm_num)) (by positivity))
            hX_deg (by positivity) (by positivity)) hRSm1 zero_le_one (by positivity)
  have h_logR : 900 * Real.log ((d : ℝ) / (η : ℝ)) ≤
      225 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by
    have hlog_pos : 0 ≤ Real.log ((d : ℝ) / (η : ℝ)) := by linarith
    have h1 : Real.log ((d : ℝ) / (η : ℝ)) ≤ (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) :=
      le_mul_of_one_le_left hlog_pos hd1
    have h2 : 900 * Real.log ((d : ℝ) / (η : ℝ)) ≤ 225 * (R : ℝ) := by linarith
    have hrest : 1 ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * S_m := by
      have h1a : 1 ≤ ((ℓ : ℝ) + 1) ^ 3 := one_le_pow₀ (by linarith)
      have h1b : 1 ≤ X ^ (adaptiveDeg ℓ) := one_le_pow₀ hX1
      calc (1 : ℝ) = 1 * 1 * 1 * 1 := by ring
        _ ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * S_m := by
          refine mul_le_mul (mul_le_mul (mul_le_mul h1a (by linarith) zero_le_one (by positivity))
            h1b zero_le_one (by positivity)) hSm1 zero_le_one (by positivity)
    calc 900 * Real.log ((d : ℝ) / (η : ℝ)) ≤ 225 * (R : ℝ) * 1 := by linarith
      _ ≤ 225 * (R : ℝ) * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * S_m) :=
          mul_le_mul_of_nonneg_left hrest (by positivity)
      _ = 225 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by ring
  have h_gauss : 30 * ((R * (ℓ * M₀) * (d + 1) : ℕ) : ℝ) ≤
      60 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by
    have hd1_2X : (d : ℝ) + 1 ≤ 2 * X := by dsimp [X]; linarith
    have hL2_X2 : Llog ^ 2 ≤ X ^ 2 :=
      pow_le_pow_left₀ (by linarith) (by dsimp [X]; linarith) 2
    have hM0_X : (M₀ : ℝ) ≤ C_p * X ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
      calc (M₀ : ℝ) ≤ C_p * Llog ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := hM0_ub
        _ ≤ C_p * X ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hL2_X2 (by positivity)) hmb0
    have hmb_Sm : (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) ≤ S_m := by dsimp [S_m]; linarith
    have hℓ_le3 : (ℓ : ℝ) ≤ ((ℓ : ℝ) + 1) ^ 3 := by
      have : (ℓ : ℝ) + 1 ≤ ((ℓ : ℝ) + 1) ^ 3 := by
        simpa using pow_le_pow_right₀ (by linarith : 1 ≤ (ℓ : ℝ) + 1) (by decide : 1 ≤ 3)
      linarith
    have hX3_deg : X ^ 3 ≤ X ^ (adaptiveDeg ℓ) :=
      pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega)
    push_cast
    calc 30 * ((R : ℝ) * ((ℓ : ℝ) * (M₀ : ℝ)) * ((d : ℝ) + 1))
        = 30 * (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((d : ℝ) + 1) := by ring
      _ ≤ 30 * (R : ℝ) * ((ℓ : ℝ) + 1) ^ 3 * (C_p * X ^ 2 * S_m) * (2 * X) := by
          have hM0_Sm : (M₀ : ℝ) ≤ C_p * X ^ 2 * S_m :=
            hM0_X.trans (mul_le_mul_of_nonneg_left hmb_Sm (by positivity))
          refine mul_le_mul (mul_le_mul
            (mul_le_mul_of_nonneg_left hℓ_le3 (by positivity))
            hM0_Sm (Nat.cast_nonneg _) (by positivity))
            hd1_2X (by positivity) (by positivity)
      _ = 60 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ 3 * ((R : ℝ) * S_m) := by ring
      _ ≤ 60 * ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by
          exact mul_le_mul_of_nonneg_right
            (mul_le_mul_of_nonneg_left hX3_deg (by positivity)) (by positivity)
  have hsum_ge : 0 ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by positivity
  have hrhs_eq :
      (R : ℝ) * S_m * (adaptivePolyConst c_h ℓ * X ^ (adaptiveDeg ℓ)) =
        10000000 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m)) := by
    unfold adaptivePolyConst
    dsimp [C_p]
    ring
  rw [hrhs_eq]
  linarith only [hC, h_base, h_kN, h_dbl, h_logR, h_gauss, hsum_ge]

set_option maxHeartbeats 800000 in
theorem ins_del_work_le_dataWorkBound
    {c_h : ℝ} (hc_h : 0 < c_h) {d ℓ m R M₀ Cap_u : ℕ}
    (hd : 1 ≤ d) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (hR : 1 ≤ R)
    {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1)
    (hM0_ub : (M₀ : ℝ) ≤ cParamConst c_h ℓ * (Real.log (2 * (m : ℝ))) ^ 2 *
      (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))
    (hCapu_ub : (Cap_u : ℝ) ≤ cParamConst c_h ℓ * (Real.log (2 * (m : ℝ))) ^ (2 * ℓ) *
      (m : ℝ) ^ (u_search h x))
    {cost : ℕ}
    (hcost : cost ≤ 60 + d * 35 +
      R * (100 + ℓ * 80 + ℓ * M₀ * (150 + (d + 1) * 30) + Cap_u * (165 + ℓ * 60))) :
    (cost : ℝ) ≤
      (R : ℝ) * ((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        (adaptivePolyConst c_h ℓ * ((d : ℝ) + Real.log (2 * (m : ℝ))) ^ (adaptiveDeg ℓ)) := by
  rcases L_m_bounds hm with ⟨_, _, _, _, hLlog_half, _⟩
  rcases UL.Proof_clm_6_1_adaptive_RaceV30.I_h_bounds hh0 hh1 hx0 hx1 with ⟨_, _, hu0, _, _, _, _⟩
  set Llog := Real.log (2 * (m : ℝ))
  set X := (d : ℝ) + Llog
  set C_p := cParamConst c_h ℓ
  set S_m := (m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))
  have hCp800 : 800 ≤ C_p := cParamConst_ge_800 hc_h hℓ
  have hd1 : (1 : ℝ) ≤ (d : ℝ) := Nat.one_le_cast.mpr hd
  have hm1 : (1 : ℝ) ≤ (m : ℝ) := Nat.one_le_cast.mpr hm
  have hR1 : (1 : ℝ) ≤ (R : ℝ) := Nat.one_le_cast.mpr hR
  have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := Nat.one_le_cast.mpr hℓ
  have hX1 : 1 ≤ X := by dsimp [X]; linarith
  have hmu1 : 1 ≤ (m : ℝ) ^ (u_search h x) := Real.one_le_rpow hm1 hu0
  have hmb0 : 0 ≤ (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by positivity
  have hSm1 : 1 ≤ S_m := by dsimp [S_m]; linarith
  have hRSm1 : 1 ≤ (R : ℝ) * S_m := by calc (1 : ℝ) = 1 * 1 := by ring
    _ ≤ (R : ℝ) * S_m := mul_le_mul hR1 hSm1 zero_le_one (by positivity)
  have hcost_r : (cost : ℝ) ≤ 60 + (d : ℝ) * 35 +
      (R : ℝ) * (100 + (ℓ : ℝ) * 80 + (ℓ : ℝ) * (M₀ : ℝ) * (150 + ((d : ℝ) + 1) * 30) +
        (Cap_u : ℝ) * (165 + (ℓ : ℝ) * 60)) := by
    exact_mod_cast hcost
  let U := ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m)
  have hU_nn : 0 ≤ U := by dsimp [U]; positivity
  have hp1 : 60 + (d : ℝ) * 35 ≤ 95 * U := by
    have h1 : 60 + (d : ℝ) * 35 ≤ 95 * X := by dsimp [X]; linarith
    have hX_deg : X ≤ X ^ (adaptiveDeg ℓ) := by
      simpa using pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega : 1 ≤ adaptiveDeg ℓ)
    have hge1 : 1 ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p := by
      calc (1 : ℝ) = 1 * 1 := by ring
        _ ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p :=
          mul_le_mul (one_le_pow₀ (by linarith)) (by linarith) zero_le_one (by positivity)
    dsimp [U]
    calc 60 + (d : ℝ) * 35 ≤ 95 * 1 * X * 1 := by linarith
      _ ≤ 95 * (((ℓ : ℝ) + 1) ^ 3 * C_p) * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m) := by
          refine mul_le_mul (mul_le_mul (mul_le_mul_of_nonneg_left hge1 (by norm_num))
            hX_deg (by positivity) (by positivity)) hRSm1 zero_le_one (by positivity)
      _ = 95 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m)) := by ring
  have hp2 : (R : ℝ) * (100 + (ℓ : ℝ) * 80) ≤ 100 * U := by
    have h1 : 100 + (ℓ : ℝ) * 80 ≤ 100 * ((ℓ : ℝ) + 1) ^ 3 := by
      have : (ℓ : ℝ) + 1 ≤ ((ℓ : ℝ) + 1) ^ 3 := by
        simpa using pow_le_pow_right₀ (by linarith : 1 ≤ (ℓ : ℝ) + 1) (by decide : 1 ≤ 3)
      linarith
    have hrest : 1 ≤ C_p * X ^ (adaptiveDeg ℓ) * S_m := by
      calc (1 : ℝ) = 1 * 1 * 1 := by ring
        _ ≤ C_p * X ^ (adaptiveDeg ℓ) * S_m :=
          mul_le_mul (mul_le_mul (by linarith) (one_le_pow₀ hX1) zero_le_one (by positivity))
            hSm1 zero_le_one (by positivity)
    dsimp [U]
    calc (R : ℝ) * (100 + (ℓ : ℝ) * 80)
        ≤ (R : ℝ) * (100 * ((ℓ : ℝ) + 1) ^ 3) * 1 := by
          simpa using mul_le_mul_of_nonneg_left h1 (by positivity)
      _ ≤ (R : ℝ) * (100 * ((ℓ : ℝ) + 1) ^ 3) * (C_p * X ^ (adaptiveDeg ℓ) * S_m) :=
          mul_le_mul_of_nonneg_left hrest (by positivity)
      _ = 100 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m)) := by ring
  have hp3 : (R : ℝ) * ((ℓ : ℝ) * (M₀ : ℝ) * (150 + ((d : ℝ) + 1) * 30)) ≤ 210 * U := by
    have hd_lin : 150 + ((d : ℝ) + 1) * 30 ≤ 210 * X := by dsimp [X]; linarith
    have hL2 : Llog ^ 2 ≤ X ^ 2 := pow_le_pow_left₀ (by linarith) (by dsimp [X]; linarith) 2
    have hM0_Sm : (M₀ : ℝ) ≤ C_p * X ^ 2 * S_m := by
      calc (M₀ : ℝ) ≤ C_p * Llog ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := hM0_ub
        _ ≤ C_p * X ^ 2 * S_m :=
          mul_le_mul (mul_le_mul_of_nonneg_left hL2 (by positivity))
            (by dsimp [S_m]; linarith) hmb0 (by positivity)
    have hℓ3 : (ℓ : ℝ) ≤ ((ℓ : ℝ) + 1) ^ 3 := by
      have : (ℓ : ℝ) + 1 ≤ ((ℓ : ℝ) + 1) ^ 3 := by
        simpa using pow_le_pow_right₀ (by linarith : 1 ≤ (ℓ : ℝ) + 1) (by decide : 1 ≤ 3)
      linarith
    have hX3 : X ^ 3 ≤ X ^ (adaptiveDeg ℓ) := pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega)
    dsimp [U]
    calc (R : ℝ) * ((ℓ : ℝ) * (M₀ : ℝ) * (150 + ((d : ℝ) + 1) * 30))
        ≤ (R : ℝ) * (((ℓ : ℝ) + 1) ^ 3 * (C_p * X ^ 2 * S_m) * (210 * X)) := by
          refine mul_le_mul_of_nonneg_left (mul_le_mul
            (mul_le_mul hℓ3 hM0_Sm (Nat.cast_nonneg _) (by positivity))
            hd_lin (by positivity) (by positivity)) (by positivity)
      _ = 210 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ 3 * ((R : ℝ) * S_m)) := by ring
      _ ≤ 210 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m)) := by
          exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right
            (mul_le_mul_of_nonneg_left hX3 (by positivity)) (by positivity)) (by norm_num)
  have hp4 : (R : ℝ) * ((Cap_u : ℝ) * (165 + (ℓ : ℝ) * 60)) ≤ 165 * U := by
    have hℓ_lin : 165 + (ℓ : ℝ) * 60 ≤ 165 * ((ℓ : ℝ) + 1) ^ 3 := by
      have : (ℓ : ℝ) + 1 ≤ ((ℓ : ℝ) + 1) ^ 3 := by
        simpa using pow_le_pow_right₀ (by linarith : 1 ≤ (ℓ : ℝ) + 1) (by decide : 1 ≤ 3)
      linarith
    have hL2l : Llog ^ (2 * ℓ) ≤ X ^ (adaptiveDeg ℓ) := by
      calc Llog ^ (2 * ℓ) ≤ X ^ (2 * ℓ) :=
            pow_le_pow_left₀ (by linarith) (by dsimp [X]; linarith) (2 * ℓ)
        _ ≤ X ^ (adaptiveDeg ℓ) := pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega)
    have hCapu_Sm : (Cap_u : ℝ) ≤ C_p * X ^ (adaptiveDeg ℓ) * S_m := by
      calc (Cap_u : ℝ) ≤ C_p * Llog ^ (2 * ℓ) * (m : ℝ) ^ (u_search h x) := hCapu_ub
        _ ≤ C_p * X ^ (adaptiveDeg ℓ) * S_m :=
          mul_le_mul (mul_le_mul_of_nonneg_left hL2l (by positivity))
            (by dsimp [S_m]; linarith) (by positivity) (by positivity)
    dsimp [U]
    calc (R : ℝ) * ((Cap_u : ℝ) * (165 + (ℓ : ℝ) * 60))
        ≤ (R : ℝ) * ((C_p * X ^ (adaptiveDeg ℓ) * S_m) * (165 * ((ℓ : ℝ) + 1) ^ 3)) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul hCapu_Sm hℓ_lin (by positivity) (by positivity)) (by positivity)
      _ = 165 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_m)) := by ring
  have hexpand :
      (R : ℝ) * (100 + (ℓ : ℝ) * 80 + (ℓ : ℝ) * (M₀ : ℝ) * (150 + ((d : ℝ) + 1) * 30) +
        (Cap_u : ℝ) * (165 + (ℓ : ℝ) * 60)) =
      (R : ℝ) * (100 + (ℓ : ℝ) * 80) +
      (R : ℝ) * ((ℓ : ℝ) * (M₀ : ℝ) * (150 + ((d : ℝ) + 1) * 30)) +
      (R : ℝ) * ((Cap_u : ℝ) * (165 + (ℓ : ℝ) * 60)) := by ring
  have hrhs_eq :
      (R : ℝ) * S_m * (adaptivePolyConst c_h ℓ * X ^ (adaptiveDeg ℓ)) = 10000000 * U := by
    unfold adaptivePolyConst
    dsimp [U, C_p]
    ring
  rw [hrhs_eq]
  linarith only [hcost_r, hexpand, hp1, hp2, hp3, hp4, hU_nn]

set_option maxHeartbeats 800000 in
theorem query_work_le_queryWorkBound
    {c_h : ℝ} (hc_h : 0 < c_h) {d ℓ m R M₀ Cap_q : ℕ}
    (hd : 1 ≤ d) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (hR : 1 ≤ R)
    {η : ℚ} (hR_log : 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ≤ (R : ℝ))
    {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1)
    (hM0_ub : (M₀ : ℝ) ≤ cParamConst c_h ℓ * (Real.log (2 * (m : ℝ))) ^ 2 *
      (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))
    (hCapq_ub : (Cap_q : ℝ) ≤ cParamConst c_h ℓ * (Real.log (2 * (m : ℝ))) ^ (2 * ℓ) *
      (m : ℝ) ^ (q_search h x))
    {C_q : ℕ}
    (hCq : (C_q : ℝ) ≤ 600 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) + 80 + 40 * (d : ℝ) +
      (R : ℝ) * (200 + 80 * (ℓ : ℝ) + (ℓ : ℝ) * (M₀ : ℝ) * (180 + 30 * (d : ℝ)) +
        (Cap_q : ℝ) * (165 + 60 * (ℓ : ℝ)))) :
    (C_q : ℝ) ≤
      (R : ℝ) * ((m : ℝ) ^ (q_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        (adaptivePolyConst c_h ℓ * ((d : ℝ) + Real.log (2 * (m : ℝ))) ^ (adaptiveDeg ℓ)) := by
  rcases L_m_bounds hm with ⟨_, _, _, _, hLlog_half, _⟩
  rcases UL.Proof_clm_6_1_adaptive_RaceV30.I_h_bounds hh0 hh1 hx0 hx1 with ⟨_, _, _, _, hq0, _, _⟩
  set Llog := Real.log (2 * (m : ℝ))
  set X := (d : ℝ) + Llog
  set C_p := cParamConst c_h ℓ
  set S_q := (m : ℝ) ^ (q_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))
  have hCp800 : 800 ≤ C_p := cParamConst_ge_800 hc_h hℓ
  have hd1 : (1 : ℝ) ≤ (d : ℝ) := Nat.one_le_cast.mpr hd
  have hm1 : (1 : ℝ) ≤ (m : ℝ) := Nat.one_le_cast.mpr hm
  have hR1 : (1 : ℝ) ≤ (R : ℝ) := Nat.one_le_cast.mpr hR
  have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := Nat.one_le_cast.mpr hℓ
  have hX1 : 1 ≤ X := by dsimp [X]; linarith
  have hmq1 : 1 ≤ (m : ℝ) ^ (q_search h x) := Real.one_le_rpow hm1 hq0
  have hmb0 : 0 ≤ (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by positivity
  have hSq1 : 1 ≤ S_q := by dsimp [S_q]; linarith
  have hRSq1 : 1 ≤ (R : ℝ) * S_q := by calc (1 : ℝ) = 1 * 1 := by ring
    _ ≤ (R : ℝ) * S_q := mul_le_mul hR1 hSq1 zero_le_one (by positivity)
  let U := ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_q)
  have hU_nn : 0 ≤ U := by dsimp [U]; positivity
  have hp0 : 600 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ≤ 150 * U := by
    have h1 : 600 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ≤ 150 * (R : ℝ) := by linarith
    have hrest : 1 ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * S_q := by
      calc (1 : ℝ) = 1 * 1 * 1 * 1 := by ring
        _ ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * S_q := by
          refine mul_le_mul (mul_le_mul (mul_le_mul (one_le_pow₀ (by linarith)) (by linarith)
            zero_le_one (by positivity)) (one_le_pow₀ hX1) zero_le_one (by positivity))
            hSq1 zero_le_one (by positivity)
    dsimp [U]
    calc 600 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))
        ≤ 150 * (R : ℝ) * 1 := by linarith
      _ ≤ 150 * (R : ℝ) * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * S_q) :=
          mul_le_mul_of_nonneg_left hrest (by positivity)
      _ = 150 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_q)) := by ring
  have hp1 : 80 + 40 * (d : ℝ) ≤ 120 * U := by
    have h1 : 80 + 40 * (d : ℝ) ≤ 120 * X := by dsimp [X]; linarith
    have hX_deg : X ≤ X ^ (adaptiveDeg ℓ) := by
      simpa using pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega : 1 ≤ adaptiveDeg ℓ)
    have hge1 : 1 ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p := by
      calc (1 : ℝ) = 1 * 1 := by ring
        _ ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p :=
          mul_le_mul (one_le_pow₀ (by linarith)) (by linarith) zero_le_one (by positivity)
    dsimp [U]
    calc 80 + 40 * (d : ℝ) ≤ 120 * 1 * X * 1 := by linarith
      _ ≤ 120 * (((ℓ : ℝ) + 1) ^ 3 * C_p) * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_q) := by
          refine mul_le_mul (mul_le_mul (mul_le_mul_of_nonneg_left hge1 (by norm_num))
            hX_deg (by positivity) (by positivity)) hRSq1 zero_le_one (by positivity)
      _ = 120 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_q)) := by ring
  have hp2 : (R : ℝ) * (200 + 80 * (ℓ : ℝ)) ≤ 200 * U := by
    have h1 : 200 + 80 * (ℓ : ℝ) ≤ 200 * ((ℓ : ℝ) + 1) ^ 3 := by
      have : (ℓ : ℝ) + 1 ≤ ((ℓ : ℝ) + 1) ^ 3 := by
        simpa using pow_le_pow_right₀ (by linarith : 1 ≤ (ℓ : ℝ) + 1) (by decide : 1 ≤ 3)
      linarith
    have hrest : 1 ≤ C_p * X ^ (adaptiveDeg ℓ) * S_q := by
      calc (1 : ℝ) = 1 * 1 * 1 := by ring
        _ ≤ C_p * X ^ (adaptiveDeg ℓ) * S_q :=
          mul_le_mul (mul_le_mul (by linarith) (one_le_pow₀ hX1) zero_le_one (by positivity))
            hSq1 zero_le_one (by positivity)
    dsimp [U]
    calc (R : ℝ) * (200 + 80 * (ℓ : ℝ))
        ≤ (R : ℝ) * (200 * ((ℓ : ℝ) + 1) ^ 3) * 1 := by
          simpa using mul_le_mul_of_nonneg_left h1 (by positivity)
      _ ≤ (R : ℝ) * (200 * ((ℓ : ℝ) + 1) ^ 3) * (C_p * X ^ (adaptiveDeg ℓ) * S_q) :=
          mul_le_mul_of_nonneg_left hrest (by positivity)
      _ = 200 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_q)) := by ring
  have hp3 : (R : ℝ) * ((ℓ : ℝ) * (M₀ : ℝ) * (180 + 30 * (d : ℝ))) ≤ 210 * U := by
    have hd_lin : 180 + 30 * (d : ℝ) ≤ 210 * X := by dsimp [X]; linarith
    have hL2 : Llog ^ 2 ≤ X ^ 2 := pow_le_pow_left₀ (by linarith) (by dsimp [X]; linarith) 2
    have hM0_Sq : (M₀ : ℝ) ≤ C_p * X ^ 2 * S_q := by
      calc (M₀ : ℝ) ≤ C_p * Llog ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := hM0_ub
        _ ≤ C_p * X ^ 2 * S_q :=
          mul_le_mul (mul_le_mul_of_nonneg_left hL2 (by positivity))
            (by dsimp [S_q]; linarith) hmb0 (by positivity)
    have hℓ3 : (ℓ : ℝ) ≤ ((ℓ : ℝ) + 1) ^ 3 := by
      have : (ℓ : ℝ) + 1 ≤ ((ℓ : ℝ) + 1) ^ 3 := by
        simpa using pow_le_pow_right₀ (by linarith : 1 ≤ (ℓ : ℝ) + 1) (by decide : 1 ≤ 3)
      linarith
    have hX3 : X ^ 3 ≤ X ^ (adaptiveDeg ℓ) := pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega)
    dsimp [U]
    calc (R : ℝ) * ((ℓ : ℝ) * (M₀ : ℝ) * (180 + 30 * (d : ℝ)))
        ≤ (R : ℝ) * (((ℓ : ℝ) + 1) ^ 3 * (C_p * X ^ 2 * S_q) * (210 * X)) := by
          refine mul_le_mul_of_nonneg_left (mul_le_mul
            (mul_le_mul hℓ3 hM0_Sq (Nat.cast_nonneg _) (by positivity))
            hd_lin (by positivity) (by positivity)) (by positivity)
      _ = 210 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ 3 * ((R : ℝ) * S_q)) := by ring
      _ ≤ 210 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_q)) := by
          exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right
            (mul_le_mul_of_nonneg_left hX3 (by positivity)) (by positivity)) (by norm_num)
  have hp4 : (R : ℝ) * ((Cap_q : ℝ) * (165 + 60 * (ℓ : ℝ))) ≤ 165 * U := by
    have hℓ_lin : 165 + 60 * (ℓ : ℝ) ≤ 165 * ((ℓ : ℝ) + 1) ^ 3 := by
      have : (ℓ : ℝ) + 1 ≤ ((ℓ : ℝ) + 1) ^ 3 := by
        simpa using pow_le_pow_right₀ (by linarith : 1 ≤ (ℓ : ℝ) + 1) (by decide : 1 ≤ 3)
      linarith
    have hL2l : Llog ^ (2 * ℓ) ≤ X ^ (adaptiveDeg ℓ) := by
      calc Llog ^ (2 * ℓ) ≤ X ^ (2 * ℓ) :=
            pow_le_pow_left₀ (by linarith) (by dsimp [X]; linarith) (2 * ℓ)
        _ ≤ X ^ (adaptiveDeg ℓ) := pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega)
    have hCapq_Sq : (Cap_q : ℝ) ≤ C_p * X ^ (adaptiveDeg ℓ) * S_q := by
      calc (Cap_q : ℝ) ≤ C_p * Llog ^ (2 * ℓ) * (m : ℝ) ^ (q_search h x) := hCapq_ub
        _ ≤ C_p * X ^ (adaptiveDeg ℓ) * S_q :=
          mul_le_mul (mul_le_mul_of_nonneg_left hL2l (by positivity))
            (by dsimp [S_q]; linarith) (by positivity) (by positivity)
    dsimp [U]
    calc (R : ℝ) * ((Cap_q : ℝ) * (165 + 60 * (ℓ : ℝ)))
        ≤ (R : ℝ) * ((C_p * X ^ (adaptiveDeg ℓ) * S_q) * (165 * ((ℓ : ℝ) + 1) ^ 3)) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul hCapq_Sq hℓ_lin (by positivity) (by positivity)) (by positivity)
      _ = 165 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_q)) := by ring
  have hexpand :
      (R : ℝ) * (200 + 80 * (ℓ : ℝ) + (ℓ : ℝ) * (M₀ : ℝ) * (180 + 30 * (d : ℝ)) +
        (Cap_q : ℝ) * (165 + 60 * (ℓ : ℝ))) =
      (R : ℝ) * (200 + 80 * (ℓ : ℝ)) +
      (R : ℝ) * ((ℓ : ℝ) * (M₀ : ℝ) * (180 + 30 * (d : ℝ))) +
      (R : ℝ) * ((Cap_q : ℝ) * (165 + 60 * (ℓ : ℝ))) := by ring
  have hrhs_eq :
      (R : ℝ) * S_q * (adaptivePolyConst c_h ℓ * X ^ (adaptiveDeg ℓ)) = 10000000 * U := by
    unfold adaptivePolyConst
    dsimp [U, C_p]
    ring
  rw [hrhs_eq]
  linarith only [hCq, hexpand, hp0, hp1, hp2, hp3, hp4, hU_nn]

set_option maxHeartbeats 800000 in
theorem peak_and_cells_le_spaceBound
    {c_h : ℝ} (hc_h : 0 < c_h) {d ℓ m R M₀ Cap_u Cap_q : ℕ}
    (hd : 1 ≤ d) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (hR : 1 ≤ R) (hCap_u : 1 ≤ Cap_u)
    {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1)
    (hM0_ub : (M₀ : ℝ) ≤ cParamConst c_h ℓ * (Real.log (2 * (m : ℝ))) ^ 2 *
      (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))
    (hCapu_ub : (Cap_u : ℝ) ≤ cParamConst c_h ℓ * (Real.log (2 * (m : ℝ))) ^ (2 * ℓ) *
      (m : ℝ) ^ (u_search h x))
    (hCapq_ub : (Cap_q : ℝ) ≤ cParamConst c_h ℓ * (Real.log (2 * (m : ℝ))) ^ (2 * ℓ) *
      (m : ℝ) ^ (q_search h x))
    {inp : ArithRAMInput d} {mem : ArithRAMMemory} {peak : ℕ}
    (hpeak : peak = inp.inputCellSpace + mem.cellCount)
    (hinp : inp.inputCellSpace ≤ 12 + d + 2 * m * (d + 1) + R * (ℓ * M₀) * (d + 1))
    (hex : extraCells (AdaptiveSW R ℓ M₀ Cap_q d) (AdaptiveSR d R ℓ M₀) mem ≤
      m * R * (9 * Cap_u + 1)) :
    (peak : ℝ) ≤
      (R : ℝ) * ((m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        (adaptivePolyConst c_h ℓ * ((d : ℝ) + Real.log (2 * (m : ℝ))) ^ (adaptiveDeg ℓ)) ∧
    (mem.cellCount : ℝ) ≤
      (R : ℝ) * ((m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        (adaptivePolyConst c_h ℓ * ((d : ℝ) + Real.log (2 * (m : ℝ))) ^ (adaptiveDeg ℓ)) := by
  have hpeak_le :
      (peak : ℝ) ≤
        (R : ℝ) * ((m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
          (adaptivePolyConst c_h ℓ * ((d : ℝ) + Real.log (2 * (m : ℝ))) ^ (adaptiveDeg ℓ)) := by
    rcases L_m_bounds hm with ⟨_, _, _, _, hLlog_half, _⟩
    rcases UL.Proof_clm_6_1_adaptive_RaceV30.I_h_bounds hh0 hh1 hx0 hx1 with ⟨_, _, hu0, _, _, _, _⟩
    have hcell_nat : mem.cellCount ≤
        (Cap_q + d) + (2 * R * ℓ) * M₀ * (d + 1) + d + (2 * R * ℓ) + 70 +
          m * R * (9 * Cap_u + 1) := by
      have hc1 := cellCount_le_card_add_extraCells
        (AdaptiveSW R ℓ M₀ Cap_q d) (AdaptiveSR d R ℓ M₀) mem
      have hc2 := card_scratch_le d (2 * R * ℓ) M₀ (Cap_q + d)
      unfold AdaptiveSW AdaptiveSR at hc1 hex
      omega
    have h9 : m * R * (9 * Cap_u + 1) ≤ 10 * R * m * Cap_u := by
      have hcap10 : 9 * Cap_u + 1 ≤ 10 * Cap_u := by omega
      calc m * R * (9 * Cap_u + 1) ≤ m * R * (10 * Cap_u) := Nat.mul_le_mul_left _ hcap10
        _ = 10 * R * m * Cap_u := by ring
    have htot_nat : peak ≤
        82 + 3 * d + 2 * R * ℓ + 2 * m * (d + 1) + Cap_q +
          3 * R * ℓ * M₀ * (d + 1) + 10 * R * m * Cap_u := by
      have hrm : R * (ℓ * M₀) * (d + 1) + (2 * R * ℓ) * M₀ * (d + 1) =
          3 * R * ℓ * M₀ * (d + 1) := by ring
      omega
    have htot_r : (peak : ℝ) ≤
        82 + 3 * (d : ℝ) + 2 * (R : ℝ) * (ℓ : ℝ) + 2 * (m : ℝ) * ((d : ℝ) + 1) + (Cap_q : ℝ) +
          3 * (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((d : ℝ) + 1) + 10 * (R : ℝ) * (m : ℝ) * (Cap_u : ℝ) := by
      exact_mod_cast htot_nat
    set Llog := Real.log (2 * (m : ℝ))
    set X := (d : ℝ) + Llog
    set C_p := cParamConst c_h ℓ
    set S_s := (m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))
    have hCp800 : 800 ≤ C_p := cParamConst_ge_800 hc_h hℓ
    have hd1 : (1 : ℝ) ≤ (d : ℝ) := Nat.one_le_cast.mpr hd
    have hm1 : (1 : ℝ) ≤ (m : ℝ) := Nat.one_le_cast.mpr hm
    have hm_pos : (0 : ℝ) < (m : ℝ) := by positivity
    have hR1 : (1 : ℝ) ≤ (R : ℝ) := Nat.one_le_cast.mpr hR
    have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := Nat.one_le_cast.mpr hℓ
    have hX1 : 1 ≤ X := by dsimp [X]; linarith
    have hm_le_sp : (m : ℝ) ≤ (m : ℝ) ^ (1 + u_search h x) := by
      calc (m : ℝ) = (m : ℝ) ^ (1 : ℝ) := (Real.rpow_one (m : ℝ)).symm
        _ ≤ (m : ℝ) ^ (1 + u_search h x) :=
            Real.rpow_le_rpow_of_exponent_le hm1 (by linarith)
    have hm_mul_u : (m : ℝ) * (m : ℝ) ^ (u_search h x) = (m : ℝ) ^ (1 + u_search h x) := by
      rw [Real.rpow_add hm_pos 1 (u_search h x), Real.rpow_one]
    have hq_le_sp : q_search h x ≤ 1 + u_search h x := by
      unfold q_search u_search
      nlinarith [sq_nonneg x]
    have hmq_le_sp : (m : ℝ) ^ (q_search h x) ≤ (m : ℝ) ^ (1 + u_search h x) :=
      Real.rpow_le_rpow_of_exponent_le hm1 hq_le_sp
    have hmb0 : 0 ≤ (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by positivity
    have hSs1 : 1 ≤ S_s := by dsimp [S_s]; linarith
    let U := ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_s)
    have hU_nn : 0 ≤ U := by dsimp [U]; positivity
    have hX_deg : X ≤ X ^ (adaptiveDeg ℓ) := by
      simpa using pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega : 1 ≤ adaptiveDeg ℓ)
    have hℓ3 : (ℓ : ℝ) + 1 ≤ ((ℓ : ℝ) + 1) ^ 3 := by
      simpa using pow_le_pow_right₀ (by linarith : 1 ≤ (ℓ : ℝ) + 1) (by decide : 1 ≤ 3)
    have hL2l : Llog ^ (2 * ℓ) ≤ X ^ (adaptiveDeg ℓ) := by
      calc Llog ^ (2 * ℓ) ≤ X ^ (2 * ℓ) :=
            pow_le_pow_left₀ (by linarith) (by dsimp [X]; linarith) (2 * ℓ)
        _ ≤ X ^ (adaptiveDeg ℓ) := pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega)
    have hs1 : 82 + 3 * (d : ℝ) + 2 * (R : ℝ) * (ℓ : ℝ) ≤ 87 * U := by
      have ha : 82 + 3 * (d : ℝ) ≤ 85 * X * ((R : ℝ) * S_s) := by
        have hRSs1 : 1 ≤ (R : ℝ) * S_s := by calc (1 : ℝ) = 1 * 1 := by ring
          _ ≤ (R : ℝ) * S_s := mul_le_mul hR1 hSs1 zero_le_one (by positivity)
        have : 82 + 3 * (d : ℝ) ≤ 85 * X * 1 := by dsimp [X]; linarith
        exact this.trans (mul_le_mul_of_nonneg_left hRSs1 (by positivity))
      have hb : 2 * (R : ℝ) * (ℓ : ℝ) ≤ 2 * ((ℓ : ℝ) + 1) ^ 3 * ((R : ℝ) * S_s) := by
        calc 2 * (R : ℝ) * (ℓ : ℝ) ≤ 2 * ((ℓ : ℝ) + 1) ^ 3 * (R : ℝ) * 1 := by
              have : (ℓ : ℝ) ≤ ((ℓ : ℝ) + 1) ^ 3 := by linarith
              have hm_r := mul_le_mul_of_nonneg_left this (by positivity : 0 ≤ 2 * (R : ℝ))
              linarith [show 2 * (R : ℝ) * ((ℓ : ℝ) + 1) ^ 3 = 2 * ((ℓ : ℝ) + 1) ^ 3 * (R : ℝ) * 1 by ring]
          _ ≤ 2 * ((ℓ : ℝ) + 1) ^ 3 * (R : ℝ) * S_s :=
              mul_le_mul_of_nonneg_left hSs1 (by positivity)
          _ = 2 * ((ℓ : ℝ) + 1) ^ 3 * ((R : ℝ) * S_s) := by ring
      have haU : 85 * X * ((R : ℝ) * S_s) ≤ 85 * U := by
        have h1 : 1 ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p := by
          calc (1 : ℝ) = 1 * 1 := by ring
            _ ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p :=
              mul_le_mul (one_le_pow₀ (by linarith)) (by linarith) zero_le_one (by positivity)
        dsimp [U]
        calc 85 * X * ((R : ℝ) * S_s) = 85 * (1 * X) * ((R : ℝ) * S_s) := by ring
          _ ≤ 85 * ((((ℓ : ℝ) + 1) ^ 3 * C_p) * X ^ (adaptiveDeg ℓ)) * ((R : ℝ) * S_s) := by
              refine mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left
                (mul_le_mul h1 hX_deg (by positivity) (by positivity)) (by norm_num)) (by positivity)
          _ = 85 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_s)) := by ring
      have hbU : 2 * ((ℓ : ℝ) + 1) ^ 3 * ((R : ℝ) * S_s) ≤ 2 * U := by
        have h1 : 1 ≤ C_p * X ^ (adaptiveDeg ℓ) := by
          calc (1 : ℝ) = 1 * 1 := by ring
            _ ≤ C_p * X ^ (adaptiveDeg ℓ) :=
              mul_le_mul (by linarith) (one_le_pow₀ hX1) zero_le_one (by positivity)
        dsimp [U]
        calc 2 * ((ℓ : ℝ) + 1) ^ 3 * ((R : ℝ) * S_s)
            = 2 * ((ℓ : ℝ) + 1) ^ 3 * 1 * ((R : ℝ) * S_s) := by ring
          _ ≤ 2 * ((ℓ : ℝ) + 1) ^ 3 * (C_p * X ^ (adaptiveDeg ℓ)) * ((R : ℝ) * S_s) := by
              exact mul_le_mul_of_nonneg_right
                (mul_le_mul_of_nonneg_left h1 (by positivity)) (by positivity)
          _ = 2 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_s)) := by ring
      linarith
    have hs2 : 2 * (m : ℝ) * ((d : ℝ) + 1) ≤ 4 * U := by
      have hd_2X : (d : ℝ) + 1 ≤ 2 * X := by dsimp [X]; linarith
      have hm_Ss : (m : ℝ) ≤ (R : ℝ) * S_s := by
        calc (m : ℝ) = 1 * (m : ℝ) := by ring
          _ ≤ (R : ℝ) * S_s := mul_le_mul hR1 (by dsimp [S_s]; linarith) (by positivity) (by positivity)
      have h1 : 1 ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p := by
        calc (1 : ℝ) = 1 * 1 := by ring
          _ ≤ ((ℓ : ℝ) + 1) ^ 3 * C_p :=
            mul_le_mul (one_le_pow₀ (by linarith)) (by linarith) zero_le_one (by positivity)
      dsimp [U]
      calc 2 * (m : ℝ) * ((d : ℝ) + 1)
          ≤ 2 * ((R : ℝ) * S_s) * (2 * X) :=
            mul_le_mul (mul_le_mul_of_nonneg_left hm_Ss (by norm_num)) hd_2X (by positivity) (by positivity)
        _ = 4 * (1 * X) * ((R : ℝ) * S_s) := by ring
        _ ≤ 4 * ((((ℓ : ℝ) + 1) ^ 3 * C_p) * X ^ (adaptiveDeg ℓ)) * ((R : ℝ) * S_s) := by
            exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left
              (mul_le_mul h1 hX_deg (by positivity) (by positivity)) (by norm_num)) (by positivity)
        _ = 4 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_s)) := by ring
    have hs3 : (Cap_q : ℝ) ≤ U := by
      have hCq1 : (Cap_q : ℝ) ≤ C_p * X ^ (adaptiveDeg ℓ) * S_s := by
        calc (Cap_q : ℝ) ≤ C_p * Llog ^ (2 * ℓ) * (m : ℝ) ^ (q_search h x) := hCapq_ub
          _ ≤ C_p * X ^ (adaptiveDeg ℓ) * (m : ℝ) ^ (1 + u_search h x) :=
            mul_le_mul (mul_le_mul_of_nonneg_left hL2l (by positivity))
              hmq_le_sp (by positivity) (by positivity)
          _ ≤ C_p * X ^ (adaptiveDeg ℓ) * S_s :=
            mul_le_mul_of_nonneg_left (by dsimp [S_s]; linarith) (by positivity)
      dsimp [U]
      calc (Cap_q : ℝ) ≤ 1 * (C_p * X ^ (adaptiveDeg ℓ) * S_s) * 1 := by linarith
        _ ≤ ((ℓ : ℝ) + 1) ^ 3 * (C_p * X ^ (adaptiveDeg ℓ) * S_s) * (R : ℝ) :=
            mul_le_mul (mul_le_mul (one_le_pow₀ (by linarith)) le_rfl (by positivity) (by positivity))
              hR1 zero_le_one (by positivity)
        _ = ((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_s) := by ring
    have hs4 : 3 * (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((d : ℝ) + 1) ≤ 6 * U := by
      have hd_2X : (d : ℝ) + 1 ≤ 2 * X := by dsimp [X]; linarith
      have hL2 : Llog ^ 2 ≤ X ^ 2 := pow_le_pow_left₀ (by linarith) (by dsimp [X]; linarith) 2
      have hM0_Ss : (M₀ : ℝ) ≤ C_p * X ^ 2 * S_s := by
        calc (M₀ : ℝ) ≤ C_p * Llog ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := hM0_ub
          _ ≤ C_p * X ^ 2 * S_s :=
            mul_le_mul (mul_le_mul_of_nonneg_left hL2 (by positivity))
              (by dsimp [S_s]; linarith) hmb0 (by positivity)
      have hX3 : X ^ 3 ≤ X ^ (adaptiveDeg ℓ) := pow_le_pow_right₀ hX1 (by unfold adaptiveDeg; omega)
      dsimp [U]
      calc 3 * (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((d : ℝ) + 1)
          ≤ 3 * (R : ℝ) * ((ℓ : ℝ) + 1) ^ 3 * (C_p * X ^ 2 * S_s) * (2 * X) := by
            refine mul_le_mul (mul_le_mul
              (mul_le_mul_of_nonneg_left (by linarith : (ℓ : ℝ) ≤ ((ℓ : ℝ) + 1) ^ 3) (by positivity))
              hM0_Ss (Nat.cast_nonneg _) (by positivity)) hd_2X (by positivity) (by positivity)
        _ = 6 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ 3 * ((R : ℝ) * S_s)) := by ring
        _ ≤ 6 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_s)) := by
            exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right
              (mul_le_mul_of_nonneg_left hX3 (by positivity)) (by positivity)) (by norm_num)
    have hs5 : 10 * (R : ℝ) * (m : ℝ) * (Cap_u : ℝ) ≤ 10 * U := by
      have hmCu : (m : ℝ) * (Cap_u : ℝ) ≤ C_p * X ^ (adaptiveDeg ℓ) * S_s := by
        calc (m : ℝ) * (Cap_u : ℝ)
            ≤ (m : ℝ) * (C_p * Llog ^ (2 * ℓ) * (m : ℝ) ^ (u_search h x)) :=
              mul_le_mul_of_nonneg_left hCapu_ub (by positivity)
          _ = C_p * Llog ^ (2 * ℓ) * ((m : ℝ) * (m : ℝ) ^ (u_search h x)) := by ring
          _ = C_p * Llog ^ (2 * ℓ) * (m : ℝ) ^ (1 + u_search h x) := by rw [hm_mul_u]
          _ ≤ C_p * X ^ (adaptiveDeg ℓ) * S_s :=
              mul_le_mul (mul_le_mul_of_nonneg_left hL2l (by positivity))
                (by dsimp [S_s]; linarith) (by positivity) (by positivity)
      dsimp [U]
      calc 10 * (R : ℝ) * (m : ℝ) * (Cap_u : ℝ)
          = 10 * 1 * (R : ℝ) * ((m : ℝ) * (Cap_u : ℝ)) := by ring
        _ ≤ 10 * ((ℓ : ℝ) + 1) ^ 3 * (R : ℝ) * (C_p * X ^ (adaptiveDeg ℓ) * S_s) := by
            refine mul_le_mul (mul_le_mul_of_nonneg_right
              (mul_le_mul_of_nonneg_left (one_le_pow₀ (by linarith)) (by norm_num)) (by positivity))
              hmCu (by positivity) (by positivity)
        _ = 10 * (((ℓ : ℝ) + 1) ^ 3 * C_p * X ^ (adaptiveDeg ℓ) * ((R : ℝ) * S_s)) := by ring
    have hrhs_eq :
        (R : ℝ) * S_s * (adaptivePolyConst c_h ℓ * X ^ (adaptiveDeg ℓ)) = 10000000 * U := by
      unfold adaptivePolyConst
      dsimp [U, C_p]
      ring
    rw [hrhs_eq]
    linarith only [htot_r, hs1, hs2, hs3, hs4, hs5, hU_nn]
  refine ⟨hpeak_le, ?_⟩
  have hcell_le_peak : (mem.cellCount : ℝ) ≤ (peak : ℝ) := by
    rw [hpeak]
    exact_mod_cast Nat.le_add_left mem.cellCount inp.inputCellSpace
  exact hcell_le_peak.trans hpeak_le

/-! ### 2. List / Finset utilities for the dynamic deletion-and-query trace -/

def delOp {m : ℕ} {α : Type} : Fin m ⊕ α → Option (Fin m)
  | Sum.inl j => some j
  | Sum.inr _ => none

theorem list_take_succ {α : Type} (xs : List α) {k : ℕ} (hk : k < xs.length) :
    xs.take (k + 1) = xs.take k ++ [xs[k]] := by
  apply List.ext_getElem
  · simp [Nat.succ_le_of_lt hk]
  · intro i hi1 hi2
    rw [List.getElem_take]
    by_cases hik : i < k
    · rw [List.getElem_append_left (by simp [Nat.le_of_lt hk, hik]), List.getElem_take]
    · have hieq : i = k := by
        simp [Nat.succ_le_of_lt hk] at hi1
        omega
      subst hieq
      rw [List.getElem_append_right (by simp [Nat.le_of_lt hk])]
      simp [Nat.le_of_lt hk]

theorem nodup_of_append_left {α : Type} {L₁ L₂ : List α} (h : (L₁ ++ L₂).Nodup) : L₁.Nodup := by
  induction L₁ with
  | nil => simp
  | cons a as ih =>
    simp only [List.cons_append, List.nodup_cons, List.mem_append] at h ⊢
    exact ⟨fun ha => h.1 (Or.inl ha), ih h.2⟩

theorem not_mem_of_nodup_append_singleton {α : Type} {L : List α} {x : α}
    (h : (L ++ [x]).Nodup) : x ∉ L := by
  induction L with
  | nil => simp
  | cons a as ih =>
    simp only [List.cons_append, List.nodup_cons, List.mem_append,
      List.mem_cons] at h ⊢
    rintro (rfl | hmem)
    · exact h.1 (Or.inr (Or.inl rfl))
    · exact ih h.2 hmem

theorem nodup_fin_length_le {m : ℕ} {L : List (Fin m)} (h : L.Nodup) : L.length ≤ m := by
  classical
  calc L.length = L.toFinset.card := (List.toFinset_card_of_nodup h).symm
    _ ≤ (Finset.univ : Finset (Fin m)).card := Finset.card_le_card (Finset.subset_univ _)
    _ = m := by simp

theorem flatMap_seed_length {d R N_caps : ℕ}
    (ω : Fin R → Fin N_caps → EuclideanSpace ℝ (Fin (d + 1))) :
    ((List.finRange R).flatMap (fun r =>
      (List.finRange N_caps).flatMap (fun c =>
        List.ofFn (fun coord : Fin (d + 1) => euclideanCoord (ω r c) coord)))).length =
      R * (N_caps * (d + 1)) := by
  have h_in : ∀ r : Fin R,
      ((List.finRange N_caps).flatMap (fun c =>
        List.ofFn (fun coord : Fin (d + 1) => euclideanCoord (ω r c) coord))).length =
      N_caps * (d + 1) := by
    intro r
    rw [List.length_flatMap]
    simp [List.map_const', List.sum_replicate]
  rw [List.length_flatMap]
  have hmap : List.map (fun r => ((List.finRange N_caps).flatMap (fun c =>
      List.ofFn (fun coord : Fin (d + 1) => euclideanCoord (ω r c) coord))).length)
      (List.finRange R) = List.replicate R (N_caps * (d + 1)) := by
    ext1
    simp
  simp

end UL.Proof_clm_6_1_adaptive_RaceP32

namespace UL

open UL.Proof_clm_6_1_adaptive_RaceP32
open UL.Proof_clm_6_1_adaptive_RaceV30
open UL.Proof_clm_6_1_adaptive
open UL.Proof_lem_6_3

set_option maxHeartbeats 1600000 in
-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_6_1_adaptive (h_lem_5_6 : S_lem_5_6) (h_clm_5_4_queries_and_caps : S_clm_5_4_queries_and_caps) (h_lem_6_3 : S_lem_6_3) : S_clm_6_1_adaptive := by
  let _ := h_lem_5_6
  let _ := h_clm_5_4_queries_and_caps
  let _ := h_lem_6_3
  classical
  unfold S_clm_6_1_adaptive
  intro h_min h_max hh_min hh_le hh_max ℓ hℓ
  rcases P_lem_6_2 h_min h_max hh_min hh_le hh_max with ⟨c_h, hc_h, h_probs_gen⟩
  let roundProg : ArithRAMStmt := roundSubroutine (.intParam (.lit 0)) (.intParam (.lit 1)) 0 11 17
  refine ⟨600, 5, adaptivePolyConst c_h ℓ, 9 / 10, adaptiveDeg ℓ,
    roundProg, initSeedProg ℓ, insertBirthPtProg ℓ, deletePtProg, queryProg ℓ,
    by norm_num, by norm_num, adaptivePolyConst_pos hc_h hℓ, by norm_num, by norm_num, ?_⟩
  intro d hd a b g η hb0 hba ha1 hg0 hgap hη0 hηg
  dsimp only
  intro hh_lo hh_hi
  set h : ℝ := g - 11 * (η : ℝ)
  have hh0 : 0 < h := lt_of_lt_of_le hh_min hh_lo
  have hh1 : h < 1 := lt_of_le_of_lt hh_hi hh_max
  rcases param_basic_bounds hd hb0 hba ha1 hg0 hgap hη0 hηg with
    ⟨_, _, _, hη16, _, h2_log⟩
  rcases roundDirFn_props hd hη0 hη16 with ⟨hnet_ne, hnet_mem, hnet_log4, hround_all⟩
  rcases chooseAB_padding_props hd hb0 hba ha1 hg0 hgap hη0 hηg with
    ⟨hA_pos, hB_nn, hAB_sq, hpad_all⟩
  let A : ℚ := (chooseAB b η).1
  let B : ℚ := (chooseAB b η).2
  refine ⟨dirNet d η, roundLatFn d η, A, B, hnet_ne, hnet_mem, ?_, ?_, hA_pos, hB_nn, hAB_sq,
    hpad_all, ?_⟩
  · have hd_nn : 0 ≤ (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) := by positivity
    linarith
  · intro z hz
    rcases hround_all z hz with ⟨hk_ne, hz_net, _, hz_dist⟩
    exact ⟨hk_ne, hz_net, hz_dist, exec_roundProg_bound hd hη0 hη16 h2_log hz⟩
  · intro x hx0 hx1 ε₀ hε0 hε_half m hm
    try dsimp only
    let M₀ : ℕ := M0Param c_h ℓ m hℓ hm h x
    let Cap_u : ℕ := capUParam c_h ℓ m hℓ hm h x
    let Cap_q : ℕ := capQParam c_h ℓ m hℓ hm h x
    let t : ℝ := tParam ℓ m hℓ hm
    let R : ℕ := RParam d m η ε₀
    let N_caps : ℕ := ℓ * M₀
    rcases param_all_bounds hc_h hℓ hm hh0 hh1 hx0 hx1 with
      ⟨hM₀, hCap_u, hCap_q, _, _, _, _, hM0_ub, hCapu_ub, hCapq_ub, hdu_ub, hdq_ub⟩
    rcases RParam_bounds hd hm h2_log hε0 hε_half with ⟨hR, hR_ub, hR_log⟩
    have hN_caps : 1 ≤ N_caps := Nat.mul_le_mul hℓ hM₀
    refine ⟨R, N_caps, hR, hR_ub, hN_caps, ?_⟩
    try dsimp only
    intro ι _ P₀ hP₀_card u_pts hu_unit
    try dsimp only
    let padData : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
      fun u => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u)) (B : ℝ))
    let padQuery : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
      fun z_hat => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • z_hat)) (-(B : ℝ)))
    let padPts : ι → EuclideanSpace ℝ (Fin (d + 1)) := fun i => padData (u_pts i)
    let eqv : Fin m ≃ P₀ := (finCongr hP₀_card.symm).trans P₀.equivFin.symm
    let dec : Fin m → ι := fun j => (eqv j).val
    have hdec_mem : ∀ j : Fin m, dec j ∈ P₀ := fun j => (eqv j).property
    have hdec_inj : Function.Injective dec := Subtype.val_injective.comp eqv.injective
    let ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1)) := fun j => padPts (dec j)
    let gs := goodSingleSet (ℓ := ℓ) (M₀ := M₀) h x t Cap_u Cap_q P₀ dec padPts padQuery
    let E : Set (Fin R → Fin N_caps → EuclideanSpace ℝ (Fin (d + 1))) :=
      {ω | ∀ z_hat ∈ dirNet d η, ∀ i_star ∈ P₀, ∃ r : Fin R, ω r ∈ gs z_hat i_star}
    let activeCoords : ℕ → EuclideanSpace ℝ (Fin d) :=
      fun h_idx => if hh : h_idx < m then u_pts (dec ⟨h_idx, hh⟩) else 0
    have hpadPts_unit : ∀ i ∈ P₀, IsUnitVec (padPts i) := by
      intro i hi
      rcases roundDirFn_props hd hη0 hη16 with ⟨⟨z0, hz0⟩, _, _, _⟩
      have hz0_u : IsUnitVec z0 := (hnet_mem z0 hz0).1
      exact (hpad_all (u_pts i) z0 z0 (hu_unit i hi) hz0_u hz0_u (by simp; positivity)).1
    have hpadQuery_unit : ∀ z_hat, IsUnitVec z_hat → IsUnitVec (padQuery z_hat) := by
      intro z_hat hz_hat
      exact (hpad_all z_hat z_hat z_hat hz_hat hz_hat hz_hat (by simp; positivity)).2.1
    rcases goodSingle_and_amplification hd hℓ hm hη0 hη16 hh_min hh_max hc_h h_probs_gen
        hh_lo hh_hi hx0 hx1 hε0 hε_half
        (fun z_hat hz_hat => (hnet_mem z_hat hz_hat).1) hnet_log4
        P₀ hP₀_card dec hdec_mem padPts hpadPts_unit padQuery hpadQuery_unit with
      ⟨_, _, _, hgs_all, hE_meas, hE_prob⟩
    let dataWorkBound : ℝ :=
      (R : ℝ) * ((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        (adaptivePolyConst c_h ℓ * ((d : ℝ) + Real.log (2 * (m : ℝ))) ^ (adaptiveDeg ℓ))
    let queryWorkBound : ℝ :=
      (R : ℝ) * ((m : ℝ) ^ (q_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        (adaptivePolyConst c_h ℓ * ((d : ℝ) + Real.log (2 * (m : ℝ))) ^ (adaptiveDeg ℓ))
    let spaceBound : ℝ :=
      (R : ℝ) * ((m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        (adaptivePolyConst c_h ℓ * ((d : ℝ) + Real.log (2 * (m : ℝ))) ^ (adaptiveDeg ℓ))
    let inp_seed : (Fin R → Fin N_caps → EuclideanSpace ℝ (Fin (d + 1))) → ArithRAMInput d :=
      fun ω =>
        { intParams :=
            [(m : ℤ), (ℓ : ℤ), (R : ℤ), (N_caps : ℤ),
             a.num, (a.den : ℤ), b.num, (b.den : ℤ), η.num, (η.den : ℤ)]
          activeHandles := ∅
          activeCoords := fun _ => 0
          extraReals :=
            [g, x] ++
              (List.finRange R).flatMap (fun r =>
                (List.finRange N_caps).flatMap (fun c =>
                  List.ofFn (fun coord : Fin (d + 1) => euclideanCoord (ω r c) coord))) }
    -- Construct the birth build chain for every seed `ω`
    have hBuildAll : ∀ ω : Fin R → Fin N_caps → EuclideanSpace ℝ (Fin (d + 1)),
        ∃ mem_final : ArithRAMMemory,
          DataStructInv hm Cap_u Cap_q A B η x t ω ptsK Finset.univ Finset.univ
            (m * (R * (5 * Cap_u + 1))) mem_final ∧
          (∃ (out₀ : ArithRAMExecOutcome) (buildMems : Fin (m + 1) → ArithRAMMemory),
            runArithRAMWithBits (initSeedProg ℓ) (inp_seed ω) ArithRAMMemory.empty [] = some out₀ ∧
            (out₀.unitCost : ℝ) ≤ dataWorkBound ∧
            (out₀.peakCellSpace : ℝ) ≤ spaceBound ∧
            (out₀.mem.cellCount : ℝ) ≤ spaceBound ∧
            buildMems 0 = out₀.mem ∧
            buildMems (Fin.last m) = mem_final ∧
            ∀ j : Fin m,
              let inp_ins : ArithRAMInput d :=
                { intParams := [(j.val : ℤ)]
                  activeHandles := Finset.range (j.val + 1)
                  activeCoords := activeCoords
                  extraReals := [] }
              ∃ out_ins : ArithRAMExecOutcome,
                runArithRAMWithBits (insertBirthPtProg ℓ) inp_ins (buildMems j.castSucc) [] =
                  some out_ins ∧
                out_ins.mem = buildMems j.succ ∧
                (out_ins.unitCost : ℝ) ≤ dataWorkBound ∧
                (out_ins.peakCellSpace : ℝ) ≤ spaceBound ∧
                (out_ins.mem.cellCount : ℝ) ≤ spaceBound) := by
      intro ω
      rcases exec_initSeedProg hd hℓ hm hR hM₀ (a := a) (b := b) hη0 hη16 (g := g) hc_h
          hh0 hh1 hx0 hx1 rfl ω ptsK with
        ⟨mem₀, C_init, hs_init, hinv₀, hC_init_ub⟩
      rcases hs_init.to_run with ⟨out₀, hrun₀, hmem₀, hunit₀, hpeak₀⟩
      rw [← hmem₀] at hinv₀ hpeak₀
      have hout₀_work : (out₀.unitCost : ℝ) ≤ dataWorkBound := by
        have h1 : (out₀.unitCost : ℝ) ≤ (C_init : ℝ) := Nat.cast_le.mpr hunit₀
        exact h1.trans (init_work_le_dataWorkBound hc_h hd hℓ hm hR h2_log hR_log hh0 hh1 hx0 hx1
          hM0_ub hdu_ub hdq_ub hC_init_ub)
      have hinp_seed_sp : (inp_seed ω).inputCellSpace ≤
          12 + d + 2 * m * (d + 1) + R * (ℓ * M₀) * (d + 1) := by
        simp only [inp_seed, ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil,
          Finset.card_empty, zero_mul, List.length_append, flatMap_seed_length]
        have heq_mul : R * (N_caps * (d + 1)) = R * (ℓ * M₀) * (d + 1) := by
          dsimp only [N_caps]; ring
        rw [heq_mul]
        omega
      rcases peak_and_cells_le_spaceBound hc_h hd hℓ hm hR hCap_u hh0 hh1 hx0 hx1
          hM0_ub hCapu_ub hCapq_ub hpeak₀ hinp_seed_sp
          (hinv₀.extra_le.trans (Nat.zero_le _)) with ⟨hout₀_peak, hout₀_cells⟩
      -- Induct on prefix `k ≤ m`
      have hChain : ∀ (k : ℕ) (hk : k ≤ m),
          let prefSet : Finset (Fin m) := Finset.univ.filter (fun j : Fin m => j.val < k)
          ∃ f : Fin (k + 1) → ArithRAMMemory,
            f 0 = out₀.mem ∧
            DataStructInv hm Cap_u Cap_q A B η x t ω ptsK prefSet prefSet
              (k * (R * (5 * Cap_u + 1))) (f (Fin.last k)) ∧
            ∀ j₀ : Fin k,
              let j : Fin m := ⟨j₀.val, lt_of_lt_of_le j₀.isLt hk⟩
              let inp_ins : ArithRAMInput d :=
                { intParams := [(j.val : ℤ)]
                  activeHandles := Finset.range (j.val + 1)
                  activeCoords := activeCoords
                  extraReals := [] }
              ∃ out_ins : ArithRAMExecOutcome,
                runArithRAMWithBits (insertBirthPtProg ℓ) inp_ins (f j₀.castSucc) [] =
                  some out_ins ∧
                out_ins.mem = f j₀.succ ∧
                (out_ins.unitCost : ℝ) ≤ dataWorkBound ∧
                (out_ins.peakCellSpace : ℝ) ≤ spaceBound ∧
                (out_ins.mem.cellCount : ℝ) ≤ spaceBound := by
        intro k
        induction k with
        | zero =>
          intro _
          refine ⟨fun _ => out₀.mem, rfl, ?_, fun j₀ => Fin.elim0 j₀⟩
          have hemp : (Finset.univ.filter (fun j : Fin m => j.val < 0)) = ∅ := by simp
          rw [hemp, Nat.zero_mul]
          exact hinv₀
        | succ k ih =>
          intro hk_le
          have hk_lt : k < m := hk_le
          rcases ih (Nat.le_of_lt hk_lt) with ⟨f, hf0, hinv_k, hf_steps⟩
          let j_cur : Fin m := ⟨k, hk_lt⟩
          let pref_k : Finset (Fin m) := Finset.univ.filter (fun j : Fin m => j.val < k)
          have hj_not_in : j_cur ∉ pref_k := by simp [pref_k, j_cur]
          let inp_cur : ArithRAMInput d :=
            { intParams := [(j_cur.val : ℤ)]
              activeHandles := Finset.range (j_cur.val + 1)
              activeCoords := activeCoords
              extraReals := [] }
          have hinp_h : j_cur.val ∈ inp_cur.activeHandles := by simp [inp_cur]
          have hinp_c : inp_cur.activeCoords j_cur.val = u_pts (dec j_cur) := by
            dsimp [inp_cur, activeCoords, j_cur]
            rw [dif_pos hk_lt]
          rcases exec_insertBirthPtProg hR hM₀ hm hCap_u ω (fun j' => u_pts (dec j')) j_cur
              hj_not_in hinv_k inp_cur rfl hinp_h hinp_c with
            ⟨mem_next, hs_ins, hinv_next⟩
          rcases hs_ins.to_run with ⟨out_cur, hrun_cur, hmem_cur, hunit_cur, hpeak_cur⟩
          rw [← hmem_cur] at hinv_next hpeak_cur
          have hpref_succ : insert j_cur pref_k = Finset.univ.filter (fun j : Fin m => j.val < k + 1) := by
            ext x
            simp only [Finset.mem_insert, pref_k, Finset.mem_filter, Finset.mem_univ, true_and,
              Fin.ext_iff, j_cur]
            omega
          have heb_succ : k * (R * (5 * Cap_u + 1)) + R * (5 * Cap_u + 1) =
              (k + 1) * (R * (5 * Cap_u + 1)) := by ring
          rw [hpref_succ, heb_succ] at hinv_next
          have heb_bound : (k + 1) * (R * (5 * Cap_u + 1)) ≤ m * R * (9 * Cap_u + 1) := by
            have h1 : (k + 1) * (R * (5 * Cap_u + 1)) ≤ m * (R * (5 * Cap_u + 1)) :=
              Nat.mul_le_mul_right _ hk_le
            have h2 : m * (R * (5 * Cap_u + 1)) ≤ m * (R * (9 * Cap_u + 1)) :=
              Nat.mul_le_mul_left m (Nat.mul_le_mul_left R (by omega))
            calc (k + 1) * (R * (5 * Cap_u + 1)) ≤ m * (R * (9 * Cap_u + 1)) := h1.trans h2
              _ = m * R * (9 * Cap_u + 1) := by ring
          have hinp_cur_sp : inp_cur.inputCellSpace ≤
              12 + d + 2 * m * (d + 1) + R * (ℓ * M₀) * (d + 1) := by
            simp only [inp_cur, ArithRAMInput.inputCellSpace, List.length_singleton, List.length_nil,
              Finset.card_range]
            have h1 : (j_cur.val + 1) * (d + 1) ≤ m * (d + 1) :=
              Nat.mul_le_mul_right (d + 1) hk_le
            have h2 : m * (d + 1) ≤ 2 * m * (d + 1) := by
              calc m * (d + 1) ≤ 2 * (m * (d + 1)) := Nat.le_mul_of_pos_left _ (by omega)
                _ = 2 * m * (d + 1) := by ring
            have h12 := h1.trans h2
            omega
          rcases peak_and_cells_le_spaceBound hc_h hd hℓ hm hR hCap_u hh0 hh1 hx0 hx1
              hM0_ub hCapu_ub hCapq_ub hpeak_cur hinp_cur_sp
              (hinv_next.extra_le.trans heb_bound) with ⟨hcur_peak, hcur_cells⟩
          have hcur_work : (out_cur.unitCost : ℝ) ≤ dataWorkBound := by
            have hcap_le : Cap_u * (160 + ℓ * 60) ≤ Cap_u * (165 + ℓ * 60) :=
              Nat.mul_le_mul_left Cap_u (by omega)
            have hR_mul : R * (100 + ℓ * 80 + ℓ * M₀ * (150 + (d + 1) * 30) + Cap_u * (160 + ℓ * 60)) ≤
                R * (100 + ℓ * 80 + ℓ * M₀ * (150 + (d + 1) * 30) + Cap_u * (165 + ℓ * 60)) :=
              Nat.mul_le_mul_left R (by omega)
            exact ins_del_work_le_dataWorkBound (R := R) (M₀ := M₀) (Cap_u := Cap_u)
              hc_h hd hℓ hm hR hh0 hh1 hx0 hx1 hM0_ub hCapu_ub
              (hunit_cur.trans (Nat.add_le_add_left hR_mul (60 + d * 35)))
          let f' : Fin (k + 2) → ArithRAMMemory :=
            fun idx => if h : idx.val < k + 1 then f ⟨idx.val, h⟩ else out_cur.mem
          refine ⟨f', ?_, ?_, ?_⟩
          · dsimp [f']
            exact hf0
          · dsimp [f']
            rw [dif_neg (by simp)]
            exact hinv_next
          · intro j₁
            try dsimp only
            have hj1_cs : f' j₁.castSucc = f j₁ := by
              dsimp [f']
              exact if_pos j₁.isLt
            rw [hj1_cs]
            by_cases hj_lt : j₁.val < k
            · let j₀ : Fin k := ⟨j₁.val, hj_lt⟩
              have hj1_eq : j₁ = j₀.castSucc := Fin.ext rfl
              have hj1_su : f' j₁.succ = f j₀.succ := by
                dsimp [f']
                rw [dif_pos (Nat.succ_lt_succ hj_lt)]
                rfl
              rw [hj1_su, hj1_eq]
              exact hf_steps j₀
            · have hj1_eq_k : j₁.val = k := by omega
              have hj1_last : j₁ = Fin.last k := Fin.ext hj1_eq_k
              have hj1_su : f' j₁.succ = out_cur.mem := by
                dsimp [f']
                rw [dif_neg (by simp [hj1_eq_k])]
              rw [hj1_su, hj1_last]
              exact ⟨out_cur, hrun_cur, rfl, hcur_work, hcur_peak, hcur_cells⟩
      rcases hChain m le_rfl with ⟨buildMems, hb0_eq, hinv_m, hb_steps⟩
      have huniv : (Finset.univ.filter (fun j : Fin m => j.val < m)) = Finset.univ := by
        ext j; simp
      rw [huniv] at hinv_m
      exact ⟨buildMems (Fin.last m), hinv_m, out₀, buildMems, hrun₀, hout₀_work, hout₀_peak,
        hout₀_cells, hb0_eq, rfl, fun j => hb_steps j⟩
    let builtMem : (Fin R → Fin N_caps → EuclideanSpace ℝ (Fin (d + 1))) → ArithRAMMemory :=
      fun ω => Classical.choose (hBuildAll ω)
    refine ⟨dec, builtMem, gs, hdec_mem, hdec_inj,
      fun z_hat hz_hat i_star hi_star =>
        ⟨(hgs_all z_hat hz_hat i_star hi_star).1, fun _ => (hgs_all z_hat hz_hat i_star hi_star).2⟩,
      hE_meas, hE_prob, ?_⟩
    intro ω
    rcases Classical.choose_spec (hBuildAll ω) with ⟨hinv_built, hBuild_spec⟩
    refine ⟨hBuild_spec, ?_⟩
    -- Dynamic operations induction over `ops`
    intro ops hNodup hUnitZ
    have hfilter_eq : ∀ L : List (Fin m ⊕ (EuclideanSpace ℝ (Fin d) × (ι → Prop))),
        L.filterMap (fun op =>
          match op with
          | Sum.inl j => some j
          | Sum.inr _ => none) = L.filterMap delOp := by
      intro L
      induction L with
      | nil => rfl
      | cons x xs ih => cases x <;> simp [delOp, ih]
    have hNodupDel : (ops.filterMap delOp).Nodup := by
      rwa [← hfilter_eq ops]
    let delPref (k : ℕ) : List (Fin m) := (ops.take k).filterMap delOp
    let actPref (k : ℕ) : Finset (Fin m) := Finset.univ.filter (fun j => j ∉ delPref k)
    have hDelPrefNodup : ∀ k : ℕ, (delPref k).Nodup := by
      intro k
      have hsplit : ops.filterMap delOp = delPref k ++ (ops.drop k).filterMap delOp := by
        dsimp [delPref]
        rw [← List.filterMap_append, List.take_append_drop]
      rw [hsplit] at hNodupDel
      exact nodup_of_append_left hNodupDel
    have hOpsChain : ∀ (k : ℕ) (hk : k ≤ ops.length),
        ∃ execMems : Fin (k + 1) → ArithRAMMemory,
          execMems 0 = builtMem ω ∧
          DataStructInv hm Cap_u Cap_q A B η x t ω ptsK Finset.univ (actPref k)
            (m * (R * (5 * Cap_u + 1)) + (delPref k).length * (4 * R * Cap_u))
            (execMems (Fin.last k)) ∧
          ∀ s₀ : Fin k,
            let s : Fin ops.length := ⟨s₀.val, lt_of_lt_of_le s₀.isLt hk⟩
            let deletedBefore : List (Fin m) := delPref s.val
            let curFinHandles : Finset (Fin m) := Finset.univ.filter (fun j => j ∉ deletedBefore)
            let curHandles : Finset ℕ := curFinHandles.image Fin.val
            let P : Finset ι := curFinHandles.image dec
            match ops[s] with
            | Sum.inl j =>
                let inp_del : ArithRAMInput d :=
                  { intParams := [(j.val : ℤ)]
                    activeHandles := curHandles.erase j.val
                    activeCoords := activeCoords
                    extraReals := [] }
                ∃ out_del : ArithRAMExecOutcome,
                  runArithRAMWithBits deletePtProg inp_del (execMems s₀.castSucc) [] =
                    some out_del ∧
                  out_del.mem = execMems s₀.succ ∧
                  (out_del.unitCost : ℝ) ≤ dataWorkBound ∧
                  (out_del.peakCellSpace : ℝ) ≤ spaceBound ∧
                  (out_del.mem.cellCount : ℝ) ≤ spaceBound
            | Sum.inr (z, accept) =>
                let inp_q : ArithRAMInput d :=
                  { intParams := List.ofFn (fun j : Fin m =>
                      if accept (dec j) then (1 : ℤ) else 0)
                    activeHandles := curHandles
                    activeCoords := activeCoords
                    extraReals := List.ofFn (fun c : Fin d => euclideanCoord z c) }
                ∃ out_q : ArithRAMExecOutcome,
                  runArithRAMWithBits (queryProg ℓ) inp_q (execMems s₀.castSucc) [] =
                    some out_q ∧
                  out_q.mem = execMems s₀.succ ∧
                  (out_q.unitCost : ℝ) ≤ queryWorkBound ∧
                  (out_q.peakCellSpace : ℝ) ≤ spaceBound ∧
                  (out_q.mem.cellCount : ℝ) ≤ spaceBound ∧
                  let rawAns : ℤ := out_q.mem.words.read (.heap 0 0)
                  let ans : Option ι :=
                    if h_ans : 0 ≤ rawAns ∧ rawAns.toNat < m then
                      some (dec ⟨rawAns.toNat, h_ans.2⟩)
                    else
                      none
                  IsValidSearchAnswer P accept ans ∧
                  (ω ∈ E →
                    IsCompatibleTest padPts P (padQuery (roundDirFn d η z)) accept →
                    IsCorrectSearchAnswer padPts P h (padQuery (roundDirFn d η z)) accept ans) ∧
                  (ω ∈ E →
                    (∀ i ∈ P, ¬ accept i → inner ℝ z (u_pts i) ≤ (b : ℝ)) →
                    ans = none →
                    ∀ i ∈ P, inner ℝ z (u_pts i) < (a : ℝ)) := by
      intro k
      induction k with
      | zero =>
        intro _
        refine ⟨fun _ => builtMem ω, rfl, ?_, fun s₀ => Fin.elim0 s₀⟩
        have hact0 : actPref 0 = Finset.univ := by ext j; simp [actPref, delPref]
        have hlen0 : (delPref 0).length = 0 := by simp [delPref]
        rw [hact0, hlen0, Nat.zero_mul, Nat.add_zero]
        exact hinv_built
      | succ k ih =>
        intro hk
        have hk_lt : k < ops.length := hk
        rcases ih (Nat.le_of_lt hk_lt) with ⟨f, hf0, hinv_k, hf_steps⟩
        let s_cur : Fin ops.length := ⟨k, hk_lt⟩
        have htake_s : ops.take (k + 1) = ops.take k ++ [ops[s_cur]] :=
          list_take_succ ops hk_lt
        have hcard_handles : ((actPref k).image Fin.val).card ≤ m := by
          calc ((actPref k).image Fin.val).card
              ≤ (actPref k).card := Finset.card_image_le
            _ ≤ (Finset.univ : Finset (Fin m)).card := Finset.card_le_card (Finset.subset_univ _)
            _ = m := by simp
        -- Step from `f (Fin.last k)` according to `ops[s_cur]`
        have hStepCur :
            ∃ mem_next : ArithRAMMemory,
              DataStructInv hm Cap_u Cap_q A B η x t ω ptsK Finset.univ (actPref (k + 1))
                (m * (R * (5 * Cap_u + 1)) + (delPref (k + 1)).length * (4 * R * Cap_u))
                mem_next ∧
              (let curFinHandles : Finset (Fin m) := actPref k
               let curHandles : Finset ℕ := curFinHandles.image Fin.val
               let P : Finset ι := curFinHandles.image dec
               match ops[s_cur] with
               | Sum.inl j =>
                   let inp_del : ArithRAMInput d :=
                     { intParams := [(j.val : ℤ)]
                       activeHandles := curHandles.erase j.val
                       activeCoords := activeCoords
                       extraReals := [] }
                   ∃ out_del : ArithRAMExecOutcome,
                     runArithRAMWithBits deletePtProg inp_del (f (Fin.last k)) [] =
                       some out_del ∧
                     out_del.mem = mem_next ∧
                     (out_del.unitCost : ℝ) ≤ dataWorkBound ∧
                     (out_del.peakCellSpace : ℝ) ≤ spaceBound ∧
                     (out_del.mem.cellCount : ℝ) ≤ spaceBound
               | Sum.inr (z, accept) =>
                   let inp_q : ArithRAMInput d :=
                     { intParams := List.ofFn (fun j : Fin m =>
                         if accept (dec j) then (1 : ℤ) else 0)
                       activeHandles := curHandles
                       activeCoords := activeCoords
                       extraReals := List.ofFn (fun c : Fin d => euclideanCoord z c) }
                   ∃ out_q : ArithRAMExecOutcome,
                     runArithRAMWithBits (queryProg ℓ) inp_q (f (Fin.last k)) [] =
                       some out_q ∧
                     out_q.mem = mem_next ∧
                     (out_q.unitCost : ℝ) ≤ queryWorkBound ∧
                     (out_q.peakCellSpace : ℝ) ≤ spaceBound ∧
                     (out_q.mem.cellCount : ℝ) ≤ spaceBound ∧
                     let rawAns : ℤ := out_q.mem.words.read (.heap 0 0)
                     let ans : Option ι :=
                       if h_ans : 0 ≤ rawAns ∧ rawAns.toNat < m then
                         some (dec ⟨rawAns.toNat, h_ans.2⟩)
                       else
                         none
                     IsValidSearchAnswer P accept ans ∧
                     (ω ∈ E →
                       IsCompatibleTest padPts P (padQuery (roundDirFn d η z)) accept →
                       IsCorrectSearchAnswer padPts P h (padQuery (roundDirFn d η z)) accept ans) ∧
                     (ω ∈ E →
                       (∀ i ∈ P, ¬ accept i → inner ℝ z (u_pts i) ≤ (b : ℝ)) →
                       ans = none →
                       ∀ i ∈ P, inner ℝ z (u_pts i) < (a : ℝ))) := by
          cases hop : ops[s_cur] with
          | inl j =>
            have hdel_succ : delPref (k + 1) = delPref k ++ [j] := by
              dsimp [delPref]
              rw [htake_s, hop, List.filterMap_append]
              simp [delOp]
            have hj_not_del : j ∉ delPref k := by
              have hnd := hDelPrefNodup (k + 1)
              rw [hdel_succ] at hnd
              exact not_mem_of_nodup_append_singleton hnd
            have hj_act : j ∈ actPref k := by
              simp [actPref, hj_not_del]
            let curHandles : Finset ℕ := (actPref k).image Fin.val
            let inp_del : ArithRAMInput d :=
              { intParams := [(j.val : ℤ)]
                activeHandles := curHandles.erase j.val
                activeCoords := activeCoords
                extraReals := [] }
            rcases exec_deletePtProg hm ω ptsK j hj_act hinv_k inp_del rfl with
              ⟨mem_next, hs_del, hinv_next⟩
            rcases hs_del.to_run with ⟨out_del, hrun_del, hmem_del, hunit_del, hpeak_del⟩
            rw [← hmem_del] at hinv_next hpeak_del
            have hact_succ : (actPref k).erase j = actPref (k + 1) := by
              ext x
              simp only [actPref, Finset.mem_erase, Finset.mem_filter, Finset.mem_univ, true_and,
                hdel_succ, List.mem_append, List.mem_singleton]
              tauto
            have hlen_succ : (delPref (k + 1)).length = (delPref k).length + 1 := by
              rw [hdel_succ, List.length_append, List.length_singleton]
            have heb_eq : (m * (R * (5 * Cap_u + 1)) + (delPref k).length * (4 * R * Cap_u)) +
                4 * R * Cap_u =
                m * (R * (5 * Cap_u + 1)) + (delPref (k + 1)).length * (4 * R * Cap_u) := by
              rw [hlen_succ]; ring
            rw [hact_succ, heb_eq] at hinv_next
            have hlen_le_m : (delPref (k + 1)).length ≤ m :=
              nodup_fin_length_le (hDelPrefNodup (k + 1))
            have heb_bound : m * (R * (5 * Cap_u + 1)) + (delPref (k + 1)).length * (4 * R * Cap_u) ≤
                m * R * (9 * Cap_u + 1) := by
              have h1 : (delPref (k + 1)).length * (4 * R * Cap_u) ≤ m * (4 * R * Cap_u) :=
                Nat.mul_le_mul_right _ hlen_le_m
              calc m * (R * (5 * Cap_u + 1)) + (delPref (k + 1)).length * (4 * R * Cap_u)
                  ≤ m * (R * (5 * Cap_u + 1)) + m * (4 * R * Cap_u) := Nat.add_le_add_left h1 _
                _ = m * R * (9 * Cap_u + 1) := by ring
            have hinp_del_sp : inp_del.inputCellSpace ≤
                12 + d + 2 * m * (d + 1) + R * (ℓ * M₀) * (d + 1) := by
              simp only [inp_del, ArithRAMInput.inputCellSpace, List.length_singleton,
                List.length_nil]
              have her : (curHandles.erase j.val).card ≤ m :=
                (Finset.card_erase_le).trans hcard_handles
              have hm_mul : (curHandles.erase j.val).card * (d + 1) ≤ m * (d + 1) :=
                Nat.mul_le_mul_right (d + 1) her
              have hm2 : m * (d + 1) ≤ 2 * m * (d + 1) := by
                calc m * (d + 1) ≤ 2 * (m * (d + 1)) := Nat.le_mul_of_pos_left _ (by omega)
                  _ = 2 * m * (d + 1) := by ring
              have hm12 := hm_mul.trans hm2
              omega
            rcases peak_and_cells_le_spaceBound hc_h hd hℓ hm hR hCap_u hh0 hh1 hx0 hx1
                hM0_ub hCapu_ub hCapq_ub hpeak_del hinp_del_sp
                (hinv_next.extra_le.trans heb_bound) with ⟨hdel_peak, hdel_cells⟩
            have hdel_work : (out_del.unitCost : ℝ) ≤ dataWorkBound :=
              ins_del_work_le_dataWorkBound (R := R) (M₀ := M₀) (Cap_u := Cap_u)
                hc_h hd hℓ hm hR hh0 hh1 hx0 hx1 hM0_ub hCapu_ub
                (hunit_del.trans (by
                  have : 45 + Cap_u * 165 ≤ 100 + ℓ * 80 + ℓ * M₀ * (150 + (d + 1) * 30) + Cap_u * (165 + ℓ * 60) := by
                    have : Cap_u * 165 ≤ Cap_u * (165 + ℓ * 60) := Nat.mul_le_mul_left Cap_u (by omega)
                    omega
                  have hR_mul := Nat.mul_le_mul_left R this
                  omega))
            exact ⟨out_del.mem, hinv_next, out_del, hrun_del, rfl, hdel_work, hdel_peak, hdel_cells⟩
          | inr za =>
            rcases za with ⟨z, accept⟩
            have hz : IsUnitVec z := hUnitZ (Sum.inr (z, accept)) (by rw [← hop]; exact List.getElem_mem _) z accept rfl
            have hdel_succ : delPref (k + 1) = delPref k := by
              dsimp [delPref]
              rw [htake_s, hop, List.filterMap_append]
              simp [delOp]
            have hact_succ : actPref (k + 1) = actPref k := by
              simp [actPref, hdel_succ]
            let curHandles : Finset ℕ := (actPref k).image Fin.val
            let inp_q : ArithRAMInput d :=
              { intParams := List.ofFn (fun j : Fin m =>
                  if accept (dec j) then (1 : ℤ) else 0)
                activeHandles := curHandles
                activeCoords := activeCoords
                extraReals := List.ofFn (fun c : Fin d => euclideanCoord z c) }
            have hAB_props : ∀ u z' z_hat : EuclideanSpace ℝ (Fin d),
                IsUnitVec u → IsUnitVec z' → IsUnitVec z_hat → ‖z_hat - z'‖ ≤ (η : ℝ) / 8 →
                  ((a : ℝ) ≤ inner ℝ z' u → h ≤ inner ℝ (padQuery z_hat) (padData u)) ∧
                  (inner ℝ z' u ≤ (b : ℝ) → inner ℝ (padQuery z_hat) (padData u) < 0) :=
              fun u z' z_hat hu hz' hzh hdist =>
                ⟨(hpad_all u z' z_hat hu hz' hzh hdist).2.2.1,
                 (hpad_all u z' z_hat hu hz' hzh hdist).2.2.2⟩
            rcases exec_queryProg hd hR hM₀ hm hCap_q (a := (a : ℝ)) (b := (b : ℝ)) (g := g)
                hη0 hη16 hh0 P₀ dec hdec_mem hdec_inj u_pts hu_unit hAB_props ω hinv_k
                z hz accept inp_q
                (fun j => listGetIntD_ofFn _ j 0)
                (fun c => listGetIntD_ofFn _ c 0) with
              ⟨mem_next, C_q, hs_q, hCq_ub, hinv_next, hans_props⟩
            rcases hs_q.to_run with ⟨out_q, hrun_q, hmem_q, hunit_q, hpeak_q⟩
            rw [← hmem_q] at hinv_next hpeak_q hans_props
            have hinv_next' : DataStructInv hm Cap_u Cap_q A B η x t ω ptsK Finset.univ
                (actPref (k + 1))
                (m * (R * (5 * Cap_u + 1)) + (delPref (k + 1)).length * (4 * R * Cap_u))
                out_q.mem := by
              rw [hact_succ, hdel_succ]
              exact hinv_next
            have hlen_le_m : (delPref k).length ≤ m :=
              nodup_fin_length_le (hDelPrefNodup k)
            have heb_bound : m * (R * (5 * Cap_u + 1)) + (delPref k).length * (4 * R * Cap_u) ≤
                m * R * (9 * Cap_u + 1) := by
              have h1 : (delPref k).length * (4 * R * Cap_u) ≤ m * (4 * R * Cap_u) :=
                Nat.mul_le_mul_right _ hlen_le_m
              calc m * (R * (5 * Cap_u + 1)) + (delPref k).length * (4 * R * Cap_u)
                  ≤ m * (R * (5 * Cap_u + 1)) + m * (4 * R * Cap_u) := Nat.add_le_add_left h1 _
                _ = m * R * (9 * Cap_u + 1) := by ring
            have hinp_q_sp : inp_q.inputCellSpace ≤
                12 + d + 2 * m * (d + 1) + R * (ℓ * M₀) * (d + 1) := by
              simp only [inp_q, ArithRAMInput.inputCellSpace, List.length_ofFn]
              have hm_mul : curHandles.card * (d + 1) ≤ m * (d + 1) :=
                Nat.mul_le_mul_right (d + 1) hcard_handles
              have hm_le_md : m ≤ m * (d + 1) := Nat.le_mul_of_pos_right m (by omega)
              have hm2 : m + curHandles.card * (d + 1) ≤ 2 * m * (d + 1) := by
                calc m + curHandles.card * (d + 1)
                    ≤ m * (d + 1) + m * (d + 1) := Nat.add_le_add hm_le_md hm_mul
                  _ = 2 * m * (d + 1) := by ring
              omega
            rcases peak_and_cells_le_spaceBound hc_h hd hℓ hm hR hCap_u hh0 hh1 hx0 hx1
                hM0_ub hCapu_ub hCapq_ub hpeak_q hinp_q_sp
                (hinv_next.extra_le.trans heb_bound) with ⟨hq_peak, hq_cells⟩
            have hq_work : (out_q.unitCost : ℝ) ≤ queryWorkBound := by
              have h1 : (out_q.unitCost : ℝ) ≤ (C_q : ℝ) := Nat.cast_le.mpr hunit_q
              exact query_work_le_queryWorkBound hc_h hd hℓ hm hR hR_log hh0 hh1 hx0 hx1
                hM0_ub hCapq_ub (h1.trans hCq_ub)
            exact ⟨out_q.mem, hinv_next', out_q, hrun_q, rfl, hq_work, hq_peak, hq_cells, hans_props⟩
        rcases hStepCur with ⟨mem_next, hinv_next, hstep_cur⟩
        let f' : Fin (k + 2) → ArithRAMMemory :=
          fun idx => if h : idx.val < k + 1 then f ⟨idx.val, h⟩ else mem_next
        refine ⟨f', ?_, ?_, ?_⟩
        · dsimp [f']
          exact hf0
        · dsimp [f']
          rw [dif_neg (by simp)]
          exact hinv_next
        · intro s₁
          try dsimp only
          have hs1_cs : f' s₁.castSucc = f s₁ := by
            dsimp [f']
            exact if_pos s₁.isLt
          rw [hs1_cs]
          by_cases hs_lt : s₁.val < k
          · let s₀ : Fin k := ⟨s₁.val, hs_lt⟩
            have hs1_eq : s₁ = s₀.castSucc := Fin.ext rfl
            have hs1_su : f' s₁.succ = f s₀.succ := by
              dsimp [f']
              rw [dif_pos (Nat.succ_lt_succ hs_lt)]
              rfl
            have hf_s0 := hf_steps s₀
            try dsimp only at hf_s0
            rw [hs1_su, hs1_eq]
            exact hf_s0
          · have hs1_eq_k : s₁.val = k := by omega
            have hs1_last : s₁ = Fin.last k := Fin.ext hs1_eq_k
            have hs1_su : f' s₁.succ = mem_next := by
              dsimp [f']
              rw [dif_neg (by simp [hs1_eq_k])]
            have hs_fin_eq : (⟨s₁.val, lt_of_lt_of_le s₁.isLt hk⟩ : Fin ops.length) = s_cur :=
              Fin.ext hs1_eq_k
            have hop_cur : ops[(⟨s₁.val, lt_of_lt_of_le s₁.isLt hk⟩ : Fin ops.length)] = ops[s_cur] :=
              congrArg (fun idx : Fin ops.length => ops[idx]) hs_fin_eq
            try dsimp only at hstep_cur
            rw [hs1_su, hop_cur, hs1_last]
            exact hstep_cur
    rcases hOpsChain ops.length le_rfl with ⟨execMems, hex0, _, hex_steps⟩
    refine ⟨execMems, hex0, fun s => ?_⟩
    have hs_step := hex_steps s
    try dsimp only at hs_step ⊢
    have hs_eq : (⟨s.val, lt_of_lt_of_le s.isLt le_rfl⟩ : Fin ops.length) = s := Fin.ext rfl
    have hop_s : ops[(⟨s.val, lt_of_lt_of_le s.isLt le_rfl⟩ : Fin ops.length)] = ops[s] :=
      congrArg (fun idx : Fin ops.length => ops[idx]) hs_eq
    rw [hop_s] at hs_step
    cases hop : ops[s] with
    | inl j =>
      rw [hop] at hs_step
      dsimp only [delPref] at hs_step
      rw [← hfilter_eq (ops.take s.val)] at hs_step
      exact hs_step
    | inr za =>
      rcases za with ⟨z, accept⟩
      rw [hop] at hs_step
      dsimp only [delPref] at hs_step
      rw [← hfilter_eq (ops.take s.val)] at hs_step
      exact hs_step

end UL
