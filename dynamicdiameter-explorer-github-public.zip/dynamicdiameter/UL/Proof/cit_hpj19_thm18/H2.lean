import UL.Proof.cit_hpj19_thm18.H0
import UL.Proof.cit_hw87_halfspace_net.H1
set_option autoImplicit false

namespace UL.Proof_cit_hpj19_thm18

private def splitFinFunEquiv {M N : ℕ} (hmN : M ≤ N) (ι : Type*) :
    (Fin N → ι) ≃ (Fin M → ι) × (Fin (N - M) → ι) where
  toFun ω :=
    (fun j : Fin M => ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩,
     fun k : Fin (N - M) => ω ⟨M + k.val, by omega⟩)
  invFun p i :=
    if h : i.val < M then p.1 ⟨i.val, h⟩ else p.2 ⟨i.val - M, by omega⟩
  left_inv ω := by
    funext i
    dsimp
    split_ifs with h
    · rfl
    · congr 1
      exact Fin.ext (by dsimp; omega)
  right_inv p := by
    rcases p with ⟨ω₁, ω₂⟩
    ext j
    · dsimp
      rw [dif_pos j.isLt]
    · dsimp
      have h : ¬ (M + j.val < M) := by omega
      rw [dif_neg h]
      congr 1
      exact Fin.ext (by dsimp; omega)

open Classical in
private lemma card_filter_prefix_eq {M N : ℕ} (hmN : M ≤ N) {ι : Type*} [Fintype ι]
    (Pred : (Fin M → ι) → Prop) :
    (Finset.univ.filter (fun ω : Fin N → ι =>
      Pred (fun j : Fin M => ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩))).card =
      (Finset.univ.filter Pred).card * Fintype.card (Fin (N - M) → ι) := by
  let e := splitFinFunEquiv hmN ι
  let S₁ : Finset (Fin M → ι) := Finset.univ.filter Pred
  let S₂ : Finset (Fin (N - M) → ι) := Finset.univ
  have hbij :
      (Finset.univ.filter (fun ω : Fin N → ι => Pred (e ω).1)).card =
        (S₁ ×ˢ S₂).card := by
    refine Finset.card_bij (fun ω _ => e ω) ?_ ?_ ?_
    · intro ω hω
      exact Finset.mem_product.mpr
        ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hω).2⟩,
         Finset.mem_univ _⟩
    · intro ω₁ _ ω₂ _ h
      exact e.injective h
    · intro p hp
      refine ⟨e.symm p, ?_, e.apply_symm_apply p⟩
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
      rw [e.apply_symm_apply]
      exact (Finset.mem_filter.mp (Finset.mem_product.mp hp).1).2
  have hprod : (S₁ ×ˢ S₂).card = S₁.card * Fintype.card (Fin (N - M) → ι) := by
    rw [Finset.card_product, Finset.card_univ]
  exact hbij.trans hprod

private def consEquivConst (ι : Type*) (s : ℕ) : (ι × (Fin s → ι)) ≃ (Fin (s + 1) → ι) where
  toFun p := Fin.cons p.1 p.2
  invFun f := (f 0, fun j => f j.succ)
  left_inv p := by
    rcases p with ⟨a, y⟩
    simp
  right_inv f := by
    funext j
    refine Fin.cases ?_ ?_ j
    · simp
    · intro i
      simp

open Classical in
private noncomputable def hitCount {ι : Type*} (A : Finset ι) (s : ℕ) (y : Fin s → ι) : ℕ :=
  (Finset.univ.filter (fun j : Fin s => y j ∈ A)).card

open Classical in
private lemma hitCount_cons {ι : Type*} (A : Finset ι) (s : ℕ) (a : ι) (y : Fin s → ι) :
    (hitCount A (s + 1) (Fin.cons a y) : ℝ) =
      (if a ∈ A then (1 : ℝ) else 0) + (hitCount A s y : ℝ) := by
  have hnat : hitCount A (s + 1) (Fin.cons a y) =
      (if a ∈ A then 1 else 0) + hitCount A s y := by
    rw [hitCount, hitCount, Finset.card_filter, Finset.card_filter, Fin.sum_univ_succ]
    simp
  rw [hnat]
  split_ifs <;> push_cast <;> ring

open Classical in
private lemma sum_univ_ite_mem {ι : Type*} [Fintype ι] (A : Finset ι) :
    (∑ a : ι, (if a ∈ A then (1 : ℝ) else 0)) = (A.card : ℝ) := by
  have hfilter : Finset.univ.filter (fun a : ι => a ∈ A) = A := by
    ext a
    simp
  have hnat : (∑ a : ι, (if a ∈ A then (1 : ℕ) else 0)) = A.card := by
    rw [← Finset.card_filter, hfilter]
  have hcast : (∑ a : ι, (if a ∈ A then (1 : ℝ) else 0)) =
      ((∑ a : ι, (if a ∈ A then (1 : ℕ) else 0) : ℕ) : ℝ) := by
    push_cast
    refine Finset.sum_congr rfl fun a _ => ?_
    split_ifs <;> rfl
  rw [hcast, hnat]

open Classical in
private lemma sum_indicator_sub {ι : Type*} [Fintype ι] [Nonempty ι] (A : Finset ι) :
    (∑ a : ι, ((if a ∈ A then (1 : ℝ) else 0) - (A.card : ℝ) / (Fintype.card ι : ℝ))) = 0 := by
  have hn : (Fintype.card ι : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  rw [Finset.sum_sub_distrib, sum_univ_ite_mem, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  field_simp [hn]
  ring

open Classical in
private lemma sum_indicator_sub_sq {ι : Type*} [Fintype ι] [Nonempty ι] (A : Finset ι) :
    let p : ℝ := (A.card : ℝ) / (Fintype.card ι : ℝ)
    (∑ a : ι, ((if a ∈ A then (1 : ℝ) else 0) - p) ^ 2) =
      (Fintype.card ι : ℝ) * p * (1 - p) := by
  intro p
  have hn : (Fintype.card ι : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have hpt : ∀ a : ι, ((if a ∈ A then (1 : ℝ) else 0) - p) ^ 2 =
      (if a ∈ A then (1 : ℝ) else 0) * (1 - 2 * p) + p ^ 2 := by
    intro a
    split_ifs <;> ring
  simp_rw [hpt]
  rw [Finset.sum_add_distrib, ← Finset.sum_mul, sum_univ_ite_mem,
      Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  have hAp : (A.card : ℝ) = (Fintype.card ι : ℝ) * p := by
    dsimp [p]
    field_simp [hn]
  rw [hAp]
  ring

open Classical in
private lemma hitCount_mean {ι : Type*} [Fintype ι] [Nonempty ι] (A : Finset ι) :
    ∀ s : ℕ,
      let p : ℝ := (A.card : ℝ) / (Fintype.card ι : ℝ)
      (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p)) = 0
  | 0 => by
      intro p
      simp [hitCount]
  | s + 1 => by
      intro p
      have ih : (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p)) = 0 := hitCount_mean A s
      rw [← Equiv.sum_comp (consEquivConst ι s)]
      rw [Fintype.sum_prod_type]
      have hstep : ∀ a : ι, ∀ y : Fin s → ι,
          (hitCount A (s + 1) (consEquivConst ι s (a, y)) : ℝ) - ((s + 1 : ℕ) : ℝ) * p =
            ((if a ∈ A then (1 : ℝ) else 0) - p) + ((hitCount A s y : ℝ) - (s : ℝ) * p) := by
        intro a y
        change (hitCount A (s + 1) (Fin.cons a y) : ℝ) - ((s + 1 : ℕ) : ℝ) * p = _
        rw [hitCount_cons]
        push_cast
        ring
      have hinner : ∀ a : ι,
          (∑ y : Fin s → ι,
            ((hitCount A (s + 1) (consEquivConst ι s (a, y)) : ℝ) - ((s + 1 : ℕ) : ℝ) * p)) =
            (Fintype.card (Fin s → ι) : ℝ) * ((if a ∈ A then (1 : ℝ) else 0) - p) := by
        intro a
        simp_rw [hstep a]
        rw [Finset.sum_add_distrib, ih, add_zero, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
      simp_rw [hinner]
      rw [← Finset.mul_sum]
      have h0 : (∑ x : ι, ((if x ∈ A then (1 : ℝ) else 0) - p)) = 0 := sum_indicator_sub A
      rw [h0, mul_zero]

open Classical in
private lemma hitCount_variance {ι : Type*} [Fintype ι] [Nonempty ι] (A : Finset ι) :
    ∀ s : ℕ,
      let p : ℝ := (A.card : ℝ) / (Fintype.card ι : ℝ)
      (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p) ^ 2) =
        ((Fintype.card ι : ℝ) ^ s) * ((s : ℝ) * p * (1 - p))
  | 0 => by
      intro p
      simp [hitCount]
  | s + 1 => by
      intro p
      have ih : (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p) ^ 2) =
          ((Fintype.card ι : ℝ) ^ s) * ((s : ℝ) * p * (1 - p)) := hitCount_variance A s
      have hmean : (∑ y : Fin s → ι, ((hitCount A s y : ℝ) - (s : ℝ) * p)) = 0 := hitCount_mean A s
      rw [← Equiv.sum_comp (consEquivConst ι s)]
      rw [Fintype.sum_prod_type]
      have hcard_fun : (Fintype.card (Fin s → ι) : ℝ) = (Fintype.card ι : ℝ) ^ s := by
        have hc : Fintype.card (Fin s → ι) = (Fintype.card ι) ^ s := by
          rw [Fintype.card_fun, Fintype.card_fin]
        exact_mod_cast hc
      have hinner : ∀ a : ι,
          (∑ y : Fin s → ι,
            ((hitCount A (s + 1) (consEquivConst ι s (a, y)) : ℝ) - ((s + 1 : ℕ) : ℝ) * p) ^ 2) =
            ((Fintype.card ι : ℝ) ^ s) * (((if a ∈ A then (1 : ℝ) else 0) - p) ^ 2) +
              ((Fintype.card ι : ℝ) ^ s) * ((s : ℝ) * p * (1 - p)) := by
        intro a
        set Ia : ℝ := (if a ∈ A then (1 : ℝ) else 0) - p
        have hsq : ∀ y : Fin s → ι,
            ((hitCount A (s + 1) (consEquivConst ι s (a, y)) : ℝ) - ((s + 1 : ℕ) : ℝ) * p) ^ 2 =
              Ia ^ 2 + 2 * Ia * ((hitCount A s y : ℝ) - (s : ℝ) * p) +
                ((hitCount A s y : ℝ) - (s : ℝ) * p) ^ 2 := by
          intro y
          change ((hitCount A (s + 1) (Fin.cons a y) : ℝ) - ((s + 1 : ℕ) : ℝ) * p) ^ 2 = _
          rw [hitCount_cons]
          dsimp [Ia]
          push_cast
          ring
        simp_rw [hsq]
        rw [Finset.sum_add_distrib, Finset.sum_add_distrib, ← Finset.mul_sum, hmean,
            mul_zero, add_zero, Finset.sum_const, Finset.card_univ, nsmul_eq_mul,
            hcard_fun, ih]
      simp_rw [hinner]
      rw [Finset.sum_add_distrib, ← Finset.mul_sum, Finset.sum_const,
          Finset.card_univ, nsmul_eq_mul]
      have hsq_a : (∑ i : ι, ((if i ∈ A then (1 : ℝ) else 0) - p) ^ 2) =
          (Fintype.card ι : ℝ) * p * (1 - p) := sum_indicator_sub_sq A
      rw [hsq_a]
      push_cast
      ring

open Classical in
private lemma ghost_low_bound
    {D M : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (Q : ι → EuclideanSpace ℝ (Fin D))
    (H : Set (EuclideanSpace ℝ (Fin D)))
    {α : ℝ} (hMα : 32 ≤ (M : ℝ) * α)
    (hH_pop : (UL.pointCount Q H : ℝ) < α * (Fintype.card ι : ℝ)) :
    (Fintype.card (Fin M → ι) : ℝ) ≤
      2 * ((Finset.univ.filter (fun ω₂ : Fin M → ι =>
        (UL.pointCount (fun j : Fin M => Q (ω₂ j)) H : ℝ) <
          (5 / 4) * α * (M : ℝ))).card : ℝ) := by
  let A : Finset ι := Finset.univ.filter (fun i : ι => Q i ∈ H)
  have hhit_eq : ∀ ω₂ : Fin M → ι,
      hitCount A M ω₂ = UL.pointCount (fun j : Fin M => Q (ω₂ j)) H := by
    intro ω₂
    unfold hitCount UL.pointCount
    congr 1
    ext j
    simp [A]
  set n : ℕ := Fintype.card ι
  set K : ℕ := Fintype.card (Fin M → ι)
  set p : ℝ := (A.card : ℝ) / (n : ℝ)
  have hn_pos : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have hp_lt_α : p < α := (div_lt_iff₀ hn_pos).mpr hH_pop
  have hK_eq : (K : ℝ) = (n : ℝ) ^ M := by
    have hc : K = n ^ M := by
      dsimp [K, n]
      rw [Fintype.card_fun, Fintype.card_fin]
    exact_mod_cast hc
  have hK_nonneg : (0 : ℝ) ≤ (K : ℝ) := Nat.cast_nonneg K
  have hM_nonneg : (0 : ℝ) ≤ (M : ℝ) := Nat.cast_nonneg M
  have hp1p : p * (1 - p) ≤ α := by nlinarith [sq_nonneg p]
  have hvar_le :
      (∑ ω₂ : Fin M → ι, ((hitCount A M ω₂ : ℝ) - (M : ℝ) * p) ^ 2) ≤
        (K : ℝ) * ((M : ℝ) * α) := by
    rw [hitCount_variance A M]
    change ((n : ℝ) ^ M) * ((M : ℝ) * p * (1 - p)) ≤ (K : ℝ) * ((M : ℝ) * α)
    rw [← hK_eq]
    have hMp : (M : ℝ) * p * (1 - p) ≤ (M : ℝ) * α := by nlinarith
    exact mul_le_mul_of_nonneg_left hMp hK_nonneg
  set Good : Finset (Fin M → ι) :=
    Finset.univ.filter (fun ω₂ : Fin M → ι =>
      (UL.pointCount (fun j : Fin M => Q (ω₂ j)) H : ℝ) < (5 / 4) * α * (M : ℝ))
  set BadG : Finset (Fin M → ι) :=
    Finset.univ.filter (fun ω₂ : Fin M → ι =>
      ¬ ((UL.pointCount (fun j : Fin M => Q (ω₂ j)) H : ℝ) < (5 / 4) * α * (M : ℝ)))
  have hpart : (Good.card : ℝ) + (BadG.card : ℝ) = (K : ℝ) := by
    have hnat : Good.card + BadG.card = K := by
      dsimp [Good, BadG, K]
      rw [Finset.card_filter_add_card_filter_not, Finset.card_univ]
    exact_mod_cast hnat
  have hbad_pt : ∀ ω₂ ∈ BadG,
      ((α * (M : ℝ)) / 4) ^ 2 ≤ ((hitCount A M ω₂ : ℝ) - (M : ℝ) * p) ^ 2 := by
    intro ω₂ hω₂
    have hge : (5 / 4) * α * (M : ℝ) ≤ (hitCount A M ω₂ : ℝ) := by
      rw [hhit_eq]
      exact le_of_not_gt (Finset.mem_filter.mp hω₂).2
    have hMp_le : (M : ℝ) * p ≤ α * (M : ℝ) := by nlinarith
    nlinarith
  have hbad_sum : (BadG.card : ℝ) * ((α * (M : ℝ)) / 4) ^ 2 ≤ (K : ℝ) * ((M : ℝ) * α) := by
    calc
      (BadG.card : ℝ) * ((α * (M : ℝ)) / 4) ^ 2
          = ∑ _ω₂ ∈ BadG, ((α * (M : ℝ)) / 4) ^ 2 := by rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ ∑ ω₂ ∈ BadG, ((hitCount A M ω₂ : ℝ) - (M : ℝ) * p) ^ 2 := Finset.sum_le_sum hbad_pt
      _ ≤ ∑ ω₂ : Fin M → ι, ((hitCount A M ω₂ : ℝ) - (M : ℝ) * p) ^ 2 :=
          Finset.sum_le_univ_sum_of_nonneg (fun _ => sq_nonneg _)
      _ ≤ (K : ℝ) * ((M : ℝ) * α) := hvar_le
  have hv2 : 2 * ((M : ℝ) * α) ≤ ((α * (M : ℝ)) / 4) ^ 2 := by nlinarith
  have hbad_nonneg : (0 : ℝ) ≤ (BadG.card : ℝ) := Nat.cast_nonneg _
  have h1 : (BadG.card : ℝ) * (2 * ((M : ℝ) * α)) ≤ (BadG.card : ℝ) * ((α * (M : ℝ)) / 4) ^ 2 :=
    mul_le_mul_of_nonneg_left hv2 hbad_nonneg
  have h2 : (BadG.card : ℝ) * (2 * ((M : ℝ) * α)) ≤ (K : ℝ) * ((M : ℝ) * α) :=
    h1.trans hbad_sum
  have hv_pos : 0 < (M : ℝ) * α := by linarith
  have hbad_le : 2 * (BadG.card : ℝ) ≤ (K : ℝ) := by
    refine le_of_mul_le_mul_right ?_ hv_pos
    linarith
  linarith

open Classical in
private noncomputable def badInitialFinset {D M : ℕ} {ι : Type*} [Fintype ι]
    (Q : ι → EuclideanSpace ℝ (Fin D)) (α : ℝ) : Finset (Fin M → ι) :=
  Finset.univ.filter (fun ω₁ : Fin M → ι => ¬ GoodInitialSample Q α ω₁)

open Classical in
private noncomputable def doubleBadInitialFinset {D M : ℕ} {ι : Type*} [Fintype ι]
    (Q : ι → EuclideanSpace ℝ (Fin D)) (α : ℝ) :
    Finset ((Fin M → ι) × (Fin M → ι)) :=
  Finset.univ.filter (fun p : (Fin M → ι) × (Fin M → ι) =>
    ∃ H : Set (EuclideanSpace ℝ (Fin D)),
      UL.IsClosedHalfspace H ∧
      2 * α * (M : ℝ) ≤ (UL.pointCount (fun j : Fin M => Q (p.1 j)) H : ℝ) ∧
      (UL.pointCount (fun j : Fin M => Q (p.2 j)) H : ℝ) < (5 / 4) * α * (M : ℝ))

open Classical in
private lemma badInitial_le_two_doubleBad
    {D M : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (Q : ι → EuclideanSpace ℝ (Fin D)) {α : ℝ}
    (hMα : 32 ≤ (M : ℝ) * α) :
    ((badInitialFinset (M := M) Q α).card : ℝ) * (Fintype.card (Fin M → ι) : ℝ) ≤
      2 * ((doubleBadInitialFinset (M := M) Q α).card : ℝ) := by
  set K : ℕ := Fintype.card (Fin M → ι)
  set Bad₁ := badInitialFinset (M := M) Q α
  set Bad₂ := doubleBadInitialFinset (M := M) Q α
  have hBad2_fubini : (Bad₂.card : ℝ) =
      ∑ ω₁ : Fin M → ι,
        ((Finset.univ.filter (fun ω₂ : Fin M → ι => (ω₁, ω₂) ∈ Bad₂)).card : ℝ) := by
    have hnat : Bad₂.card =
        ∑ ω₁ : Fin M → ι,
          (Finset.univ.filter (fun ω₂ : Fin M → ι => (ω₁, ω₂) ∈ Bad₂)).card := by
      have h1 : Bad₂.card =
          ∑ p : (Fin M → ι) × (Fin M → ι), (if p ∈ Bad₂ then 1 else 0) := by
        have hf : Finset.univ.filter (fun p => p ∈ Bad₂) = Bad₂ := by
          ext p
          simp
        rw [← Finset.card_filter, hf]
      rw [h1, Fintype.sum_prod_type]
      refine Finset.sum_congr rfl fun ω₁ _ => ?_
      rw [Finset.card_filter]
    exact_mod_cast hnat
  have hfiber : ∀ ω₁ ∈ Bad₁,
      (K : ℝ) ≤ 2 * ((Finset.univ.filter (fun ω₂ : Fin M → ι => (ω₁, ω₂) ∈ Bad₂)).card : ℝ) := by
    intro ω₁ hω₁
    have hnot : ¬ GoodInitialSample Q α ω₁ := (Finset.mem_filter.mp hω₁).2
    unfold GoodInitialSample at hnot
    push_neg at hnot
    rcases hnot with ⟨H, hH_closed, hH_pop, hH_emp1⟩
    have hlow := ghost_low_bound (M := M) Q H hMα hH_pop
    have hsub :
        Finset.univ.filter (fun ω₂ : Fin M → ι =>
          (UL.pointCount (fun j : Fin M => Q (ω₂ j)) H : ℝ) < (5 / 4) * α * (M : ℝ)) ⊆
        Finset.univ.filter (fun ω₂ : Fin M → ι => (ω₁, ω₂) ∈ Bad₂) := by
      intro ω₂ hω₂
      have hlt : (UL.pointCount (fun j : Fin M => Q (ω₂ j)) H : ℝ) < (5 / 4) * α * (M : ℝ) :=
        (Finset.mem_filter.mp hω₂).2
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, ⟨H, hH_closed, hH_emp1, hlt⟩⟩
    have hcard_le :
        ((Finset.univ.filter (fun ω₂ : Fin M → ι =>
          (UL.pointCount (fun j : Fin M => Q (ω₂ j)) H : ℝ) < (5 / 4) * α * (M : ℝ))).card : ℝ) ≤
        ((Finset.univ.filter (fun ω₂ : Fin M → ι => (ω₁, ω₂) ∈ Bad₂)).card : ℝ) := by
      exact_mod_cast Finset.card_le_card hsub
    linarith
  calc
    (Bad₁.card : ℝ) * (K : ℝ)
        = ∑ _ω₁ ∈ Bad₁, (K : ℝ) := by rw [Finset.sum_const, nsmul_eq_mul]
    _ ≤ ∑ ω₁ ∈ Bad₁,
          2 * ((Finset.univ.filter (fun ω₂ : Fin M → ι => (ω₁, ω₂) ∈ Bad₂)).card : ℝ) :=
        Finset.sum_le_sum hfiber
    _ ≤ ∑ ω₁ : Fin M → ι,
          2 * ((Finset.univ.filter (fun ω₂ : Fin M → ι => (ω₁, ω₂) ∈ Bad₂)).card : ℝ) :=
        Finset.sum_le_univ_sum_of_nonneg (fun _ => by positivity)
    _ = 2 * ∑ ω₁ : Fin M → ι,
          ((Finset.univ.filter (fun ω₂ : Fin M → ι => (ω₁, ω₂) ∈ Bad₂)).card : ℝ) := by
        rw [← Finset.mul_sum]
    _ = 2 * (Bad₂.card : ℝ) := by rw [hBad2_fubini]

private lemma exp_add_exp_neg_le_two_exp_sq_div_two_nonneg {u : ℝ} (hu : 0 ≤ u) :
    Real.exp u + Real.exp (-u) ≤ 2 * Real.exp (u ^ 2 / 2) := by
  let g : ℝ → ℝ := fun x => (Real.exp x - Real.exp (-x)) - x * (Real.exp x + Real.exp (-x))
  have hg_deriv : ∀ x : ℝ, HasDerivAt g (-x * (Real.exp x - Real.exp (-x))) x := by
    intro x
    have hexp : HasDerivAt Real.exp (Real.exp x) x := Real.hasDerivAt_exp x
    have hexp_neg : HasDerivAt (fun y : ℝ => Real.exp (-y)) (Real.exp (-x) * (-1)) x := by
      simpa [Function.comp_def] using (Real.hasDerivAt_exp (-x)).comp x (hasDerivAt_id x).neg
    have h1 : HasDerivAt (fun y : ℝ => Real.exp y - Real.exp (-y))
        (Real.exp x - Real.exp (-x) * (-1)) x := hexp.sub hexp_neg
    have h2 : HasDerivAt (fun y : ℝ => Real.exp y + Real.exp (-y))
        (Real.exp x + Real.exp (-x) * (-1)) x := hexp.add hexp_neg
    have h3 : HasDerivAt (fun y : ℝ => y * (Real.exp y + Real.exp (-y)))
        (1 * (Real.exp x + Real.exp (-x)) + x * (Real.exp x + Real.exp (-x) * (-1))) x :=
      (hasDerivAt_id x).mul h2
    convert h1.sub h3 using 1
    ring
  have hg_anti : AntitoneOn g (Set.Ici (0 : ℝ)) := by
    refine antitoneOn_of_hasDerivWithinAt_nonpos (convex_Ici 0)
      (fun x _ => (hg_deriv x).continuousAt.continuousWithinAt)
      (fun x _ => (hg_deriv x).hasDerivWithinAt) ?_
    intro x hx
    have hx0 : (0 : ℝ) ≤ x := interior_subset hx
    have hexp_le : Real.exp (-x) ≤ Real.exp x := Real.exp_le_exp.mpr (by linarith)
    nlinarith
  have hg_nonpos : ∀ x : ℝ, 0 ≤ x → g x ≤ 0 := by
    intro x hx
    have hle : g x ≤ g 0 := hg_anti Set.self_mem_Ici hx hx
    have hg0 : g 0 = 0 := by simp [g]
    linarith
  let h : ℝ → ℝ := fun x => Real.exp (-x ^ 2 / 2) * (Real.exp x + Real.exp (-x))
  have hh_deriv : ∀ x : ℝ, HasDerivAt h (Real.exp (-x ^ 2 / 2) * g x) x := by
    intro x
    have hsq : HasDerivAt (fun y : ℝ => -y ^ 2 / 2) (-x) x := by
      have hp : HasDerivAt (fun y : ℝ => y * y) (1 * x + x * 1) x :=
        (hasDerivAt_id x).mul (hasDerivAt_id x)
      have hp2 : HasDerivAt (fun y : ℝ => -y ^ 2 / 2) (-(1 * x + x * 1) / 2) x := by
        simpa [sq] using hp.neg.div_const (2 : ℝ)
      convert hp2 using 1
      ring
    have hexp_sq : HasDerivAt (fun y : ℝ => Real.exp (-y ^ 2 / 2))
        (Real.exp (-x ^ 2 / 2) * (-x)) x := by
      simpa [Function.comp_def] using (Real.hasDerivAt_exp (-x ^ 2 / 2)).comp x hsq
    have hexp_neg : HasDerivAt (fun y : ℝ => Real.exp (-y)) (Real.exp (-x) * (-1)) x := by
      simpa [Function.comp_def] using (Real.hasDerivAt_exp (-x)).comp x (hasDerivAt_id x).neg
    have hexp_sum : HasDerivAt (fun y : ℝ => Real.exp y + Real.exp (-y))
        (Real.exp x + Real.exp (-x) * (-1)) x :=
      (Real.hasDerivAt_exp x).add hexp_neg
    convert hexp_sq.mul hexp_sum using 1
    simp only [g]
    ring
  have hh_anti : AntitoneOn h (Set.Ici (0 : ℝ)) := by
    refine antitoneOn_of_hasDerivWithinAt_nonpos (convex_Ici 0)
      (fun x _ => (hh_deriv x).continuousAt.continuousWithinAt)
      (fun x _ => (hh_deriv x).hasDerivWithinAt) ?_
    intro x hx
    exact mul_nonpos_of_nonneg_of_nonpos (Real.exp_nonneg _) (hg_nonpos x (interior_subset hx))
  have hhu : h u ≤ h 0 := hh_anti Set.self_mem_Ici hu hu
  have hh0 : h 0 = 2 := by norm_num [h]
  have hmul : Real.exp (u ^ 2 / 2) * h u ≤ Real.exp (u ^ 2 / 2) * 2 :=
    mul_le_mul_of_nonneg_left (hhu.trans_eq hh0) (Real.exp_nonneg _)
  have hcancel : Real.exp (u ^ 2 / 2) * h u = Real.exp u + Real.exp (-u) := by
    dsimp [h]
    rw [← mul_assoc, ← Real.exp_add]
    have hz : u ^ 2 / 2 + -u ^ 2 / 2 = 0 := by ring
    rw [hz, Real.exp_zero, one_mul]
  linarith

private lemma exp_add_exp_neg_le_two_exp_sq_div_two (u : ℝ) :
    Real.exp u + Real.exp (-u) ≤ 2 * Real.exp (u ^ 2 / 2) := by
  rcases le_total 0 u with hu | hu
  · exact exp_add_exp_neg_le_two_exp_sq_div_two_nonneg hu
  · have hneg : 0 ≤ -u := by linarith
    have h := exp_add_exp_neg_le_two_exp_sq_div_two_nonneg hneg
    rw [neg_neg, neg_sq, add_comm] at h
    exact h

private def radSign (b : Bool) : ℝ :=
  if b then -1 else 1

private lemma rademacher_mgf_variance_le :
    ∀ (m : ℕ) (δ : Fin m → ℝ) (η : ℝ),
      (∑ σ : Fin m → Bool, Real.exp (η * ∑ t : Fin m, radSign (σ t) * δ t)) ≤
        (2 : ℝ) ^ m * Real.exp (η ^ 2 * (∑ t : Fin m, (δ t) ^ 2) / 2)
  | 0, δ, η => by
      simp
  | m + 1, δ, η => by
      have heq :
          (∑ σ : Fin (m + 1) → Bool, Real.exp (η * ∑ t : Fin (m + 1), radSign (σ t) * δ t)) =
            (Real.exp (η * δ 0) + Real.exp (-(η * δ 0))) *
              (∑ τ : Fin m → Bool, Real.exp (η * ∑ t : Fin m, radSign (τ t) * δ t.succ)) := by
        have hequiv :
            (∑ σ : Fin (m + 1) → Bool, Real.exp (η * ∑ t : Fin (m + 1), radSign (σ t) * δ t)) =
              ∑ p : Bool × (Fin m → Bool),
                Real.exp (η * ∑ t : Fin (m + 1),
                  radSign (Fin.cons (α := fun _ => Bool) p.1 p.2 t) * δ t) := by
          refine Fintype.sum_equiv (Fin.consEquiv (fun _ : Fin (m + 1) => Bool)).symm _ _
            (fun σ => ?_)
          simp only [Fin.consEquiv_symm_apply, Fin.cons_self_tail]
        rw [hequiv, Fintype.sum_prod_type]
        simp_rw [Fin.sum_univ_succ, Fin.cons_zero, Fin.cons_succ, mul_add, Real.exp_add,
          ← Finset.mul_sum]
        rw [Fintype.sum_bool]
        have ht : η * (radSign true * δ 0) = -(η * δ 0) := by simp [radSign]
        have hf : η * (radSign false * δ 0) = η * δ 0 := by simp [radSign]
        rw [ht, hf]
        ring
      rw [heq]
      have hcos : Real.exp (η * δ 0) + Real.exp (-(η * δ 0)) ≤
          2 * Real.exp ((η * δ 0) ^ 2 / 2) :=
        exp_add_exp_neg_le_two_exp_sq_div_two (η * δ 0)
      have hih : (∑ τ : Fin m → Bool, Real.exp (η * ∑ t : Fin m, radSign (τ t) * δ t.succ)) ≤
          (2 : ℝ) ^ m * Real.exp (η ^ 2 * (∑ t : Fin m, (δ t.succ) ^ 2) / 2) :=
        rademacher_mgf_variance_le m (fun t => δ t.succ) η
      have hS_nonneg :
          0 ≤ ∑ τ : Fin m → Bool, Real.exp (η * ∑ t : Fin m, radSign (τ t) * δ t.succ) :=
        Finset.sum_nonneg (fun _ _ => Real.exp_nonneg _)
      calc
        (Real.exp (η * δ 0) + Real.exp (-(η * δ 0))) *
            (∑ τ : Fin m → Bool, Real.exp (η * ∑ t : Fin m, radSign (τ t) * δ t.succ))
          ≤ (2 * Real.exp ((η * δ 0) ^ 2 / 2)) *
              ((2 : ℝ) ^ m * Real.exp (η ^ 2 * (∑ t : Fin m, (δ t.succ) ^ 2) / 2)) :=
            mul_le_mul hcos hih hS_nonneg (by positivity)
        _ = (2 : ℝ) ^ (m + 1) *
              (Real.exp ((η * δ 0) ^ 2 / 2) *
                Real.exp (η ^ 2 * (∑ t : Fin m, (δ t.succ) ^ 2) / 2)) := by ring
        _ = (2 : ℝ) ^ (m + 1) *
              Real.exp ((η * δ 0) ^ 2 / 2 + η ^ 2 * (∑ t : Fin m, (δ t.succ) ^ 2) / 2) := by
            rw [← Real.exp_add]
        _ = (2 : ℝ) ^ (m + 1) *
              Real.exp (η ^ 2 * ((δ 0) ^ 2 + ∑ t : Fin m, (δ t.succ) ^ 2) / 2) := by
            congr 2
            ring
        _ = (2 : ℝ) ^ (m + 1) *
              Real.exp (η ^ 2 * (∑ t : Fin (m + 1), (δ t) ^ 2) / 2) := by
            rw [Fin.sum_univ_succ (fun t : Fin (m + 1) => (δ t) ^ 2)]

open Classical in
private lemma rademacher_variance_tail_one_sided {M : ℕ} (δ : Fin M → ℝ)
    (hr : 0 < ∑ t : Fin M, (δ t) ^ 2) {θ : ℝ} (hθ : 0 ≤ θ) :
    ((Finset.univ.filter (fun σ : Fin M → Bool =>
        θ < ∑ t : Fin M, radSign (σ t) * δ t)).card : ℝ) ≤
      (2 : ℝ) ^ M * Real.exp (-θ ^ 2 / (2 * (∑ t : Fin M, (δ t) ^ 2))) := by
  let r : ℝ := ∑ t : Fin M, (δ t) ^ 2
  let S := Finset.univ.filter (fun σ : Fin M → Bool => θ < ∑ t : Fin M, radSign (σ t) * δ t)
  let η : ℝ := θ / r
  have hη : 0 ≤ η := div_nonneg hθ hr.le
  have hmarkov : (S.card : ℝ) * Real.exp (η * θ) ≤
      ∑ σ : Fin M → Bool, Real.exp (η * ∑ t : Fin M, radSign (σ t) * δ t) := by
    calc
      (S.card : ℝ) * Real.exp (η * θ)
        = ∑ _σ ∈ S, Real.exp (η * θ) := by rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ ∑ σ ∈ S, Real.exp (η * ∑ t : Fin M, radSign (σ t) * δ t) := by
          refine Finset.sum_le_sum (fun σ hσ => ?_)
          have hlt : θ < ∑ t : Fin M, radSign (σ t) * δ t := (Finset.mem_filter.mp hσ).2
          exact Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left hlt.le hη)
      _ ≤ ∑ σ : Fin M → Bool, Real.exp (η * ∑ t : Fin M, radSign (σ t) * δ t) :=
          Finset.sum_le_univ_sum_of_nonneg (fun _ => Real.exp_nonneg _)
  have hmgf :
      (∑ σ : Fin M → Bool, Real.exp (η * ∑ t : Fin M, radSign (σ t) * δ t)) ≤
        (2 : ℝ) ^ M * Real.exp (η ^ 2 * r / 2) :=
    rademacher_mgf_variance_le M δ η
  have hcomb : (S.card : ℝ) * Real.exp (η * θ) ≤ (2 : ℝ) ^ M * Real.exp (η ^ 2 * r / 2) :=
    hmarkov.trans hmgf
  have hmul := mul_le_mul_of_nonneg_right hcomb (Real.exp_nonneg (-(η * θ)))
  have hleft : (S.card : ℝ) * Real.exp (η * θ) * Real.exp (-(η * θ)) = (S.card : ℝ) := by
    rw [mul_assoc, ← Real.exp_add, add_neg_cancel, Real.exp_zero, mul_one]
  have hright : (2 : ℝ) ^ M * Real.exp (η ^ 2 * r / 2) * Real.exp (-(η * θ)) =
      (2 : ℝ) ^ M * Real.exp (-θ ^ 2 / (2 * r)) := by
    rw [mul_assoc, ← Real.exp_add]
    congr 2
    have hr_ne : r ≠ 0 := hr.ne'
    dsimp [η]
    field_simp [hr_ne]
    ring
  rw [hleft, hright] at hmul
  exact hmul

open Classical in
private noncomputable def traceCount1 {M : ℕ} (A : Finset (Fin M ⊕ Fin M))
    (σ : Fin M → Bool) : ℝ :=
  ∑ t : Fin M, (if (if σ t then Sum.inr t else Sum.inl t) ∈ A then (1 : ℝ) else 0)

open Classical in
private noncomputable def traceCount2 {M : ℕ} (A : Finset (Fin M ⊕ Fin M))
    (σ : Fin M → Bool) : ℝ :=
  ∑ t : Fin M, (if (if σ t then Sum.inl t else Sum.inr t) ∈ A then (1 : ℝ) else 0)

open Classical in
private noncomputable def traceDelta {M : ℕ} (A : Finset (Fin M ⊕ Fin M)) (t : Fin M) : ℝ :=
  (if Sum.inl t ∈ A then (1 : ℝ) else 0) - (if Sum.inr t ∈ A then (1 : ℝ) else 0)

open Classical in
private noncomputable def badSwapForTrace {M : ℕ} (A : Finset (Fin M ⊕ Fin M))
    (v : ℝ) : Finset (Fin M → Bool) :=
  Finset.univ.filter (fun σ : Fin M → Bool =>
    2 * v ≤ traceCount1 A σ ∧ traceCount2 A σ < (5 / 4) * v)

open Classical in
private lemma traceCount_diff_eq {M : ℕ} (A : Finset (Fin M ⊕ Fin M)) (σ : Fin M → Bool) :
    traceCount1 A σ - traceCount2 A σ = ∑ t : Fin M, radSign (σ t) * traceDelta A t := by
  dsimp [traceCount1, traceCount2, traceDelta]
  rw [← Finset.sum_sub_distrib]
  refine Finset.sum_congr rfl fun t _ => ?_
  cases σ t <;> by_cases h1 : Sum.inl t ∈ A <;> by_cases h2 : Sum.inr t ∈ A <;>
    simp [radSign, h1, h2]

open Classical in
private lemma traceDelta_sq_sum_le {M : ℕ} (A : Finset (Fin M ⊕ Fin M)) (σ : Fin M → Bool) :
    (∑ t : Fin M, (traceDelta A t) ^ 2) ≤ traceCount1 A σ + traceCount2 A σ := by
  dsimp [traceCount1, traceCount2, traceDelta]
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_le_sum fun t _ => ?_
  cases σ t <;> by_cases h1 : Sum.inl t ∈ A <;> by_cases h2 : Sum.inr t ∈ A <;>
    simp [h1, h2]

open Classical in
private lemma radSign_traceDelta_sum_le_sq {M : ℕ} (A : Finset (Fin M ⊕ Fin M))
    (σ : Fin M → Bool) :
    (∑ t : Fin M, radSign (σ t) * traceDelta A t) ≤ ∑ t : Fin M, (traceDelta A t) ^ 2 := by
  refine Finset.sum_le_sum fun t _ => ?_
  dsimp [traceDelta]
  cases σ t <;> by_cases h1 : Sum.inl t ∈ A <;> by_cases h2 : Sum.inr t ∈ A <;>
    simp [radSign, h1, h2]

open Classical in
private lemma badSwapForTrace_card_le {M : ℕ} (A : Finset (Fin M ⊕ Fin M))
    {v : ℝ} (hv : 0 < v) :
    ((badSwapForTrace A v).card : ℝ) ≤ (2 : ℝ) ^ M * Real.exp (-v / 12) := by
  rcases (badSwapForTrace A v).eq_empty_or_nonempty with hempty | ⟨σ₀, hσ₀⟩
  · rw [hempty]
    simp
    positivity
  · let r : ℝ := ∑ t : Fin M, (traceDelta A t) ^ 2
    rcases (Finset.mem_filter.mp hσ₀).2 with ⟨hk1_0, hk2_0⟩
    have hdiff0 : (3 / 4) * v < traceCount1 A σ₀ - traceCount2 A σ₀ := by linarith
    rw [traceCount_diff_eq] at hdiff0
    have hr_ge : ∑ t : Fin M, radSign (σ₀ t) * traceDelta A t ≤ r :=
      radSign_traceDelta_sum_le_sq A σ₀
    have hr_pos : 0 < r := by linarith
    let θ : ℝ := Real.sqrt ((1 / 6) * v * r)
    have hvr_nonneg : 0 ≤ (1 / 6) * v * r := by positivity
    have hθ_nonneg : 0 ≤ θ := Real.sqrt_nonneg _
    have hθ_sq : θ ^ 2 = (1 / 6) * v * r := Real.sq_sqrt hvr_nonneg
    have hsub :
        badSwapForTrace A v ⊆
          Finset.univ.filter (fun σ : Fin M → Bool =>
            θ < ∑ t : Fin M, radSign (σ t) * traceDelta A t) := by
      intro σ hσ
      rcases (Finset.mem_filter.mp hσ).2 with ⟨hk1, hk2⟩
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
      set Δ : ℝ := ∑ t : Fin M, radSign (σ t) * traceDelta A t
      have hΔ_eq : traceCount1 A σ - traceCount2 A σ = Δ := traceCount_diff_eq A σ
      have hΔ_gt : (3 / 4) * v < Δ := by linarith
      have hr_le : r ≤ traceCount1 A σ + traceCount2 A σ := traceDelta_sq_sum_le A σ
      have hr_lt : r < Δ + (5 / 2) * v := by linarith
      have hsq_lt : θ ^ 2 < Δ ^ 2 := by
        rw [hθ_sq]
        have h1 : v * r < v * (Δ + (5 / 2) * v) := mul_lt_mul_of_pos_left hr_lt hv
        have h2 : 0 ≤ (Δ - (3 / 4) * v) ^ 2 := sq_nonneg _
        have h3 : 0 < v * (Δ - (3 / 4) * v) := mul_pos hv (by linarith)
        have h4 : 0 < v ^ 2 := sq_pos_of_pos hv
        nlinarith
      nlinarith
    have hcard_le :
        ((badSwapForTrace A v).card : ℝ) ≤
          ((Finset.univ.filter (fun σ : Fin M → Bool =>
            θ < ∑ t : Fin M, radSign (σ t) * traceDelta A t)).card : ℝ) := by
      exact_mod_cast Finset.card_le_card hsub
    have htail := rademacher_variance_tail_one_sided (traceDelta A) hr_pos hθ_nonneg
    have hexp_eq : -θ ^ 2 / (2 * r) = -v / 12 := by
      rw [hθ_sq]
      have hr_ne : r ≠ 0 := hr_pos.ne'
      field_simp [hr_ne]
      ring
    rw [hexp_eq] at htail
    exact hcard_le.trans htail

private def swapPair {M : ℕ} {ι : Type*} (σ : Fin M → Bool)
    (p : (Fin M → ι) × (Fin M → ι)) : (Fin M → ι) × (Fin M → ι) :=
  (fun t => if σ t then p.2 t else p.1 t,
   fun t => if σ t then p.1 t else p.2 t)

private lemma swapPair_involutive {M : ℕ} {ι : Type*} (σ : Fin M → Bool) :
    Function.Involutive (swapPair (ι := ι) σ) := by
  intro p
  exact Prod.ext
    (funext fun t => by dsimp [swapPair]; cases σ t <;> rfl)
    (funext fun t => by dsimp [swapPair]; cases σ t <;> rfl)

open Classical in
private noncomputable def traceFamilySum {D M : ℕ}
    (z : Fin M ⊕ Fin M → EuclideanSpace ℝ (Fin D)) :
    Finset (Finset (Fin M ⊕ Fin M)) :=
  Finset.univ.filter (fun B : Finset (Fin M ⊕ Fin M) =>
    ∃ H : Set (EuclideanSpace ℝ (Fin D)),
      UL.IsClosedHalfspace H ∧ B = Finset.univ.filter (fun u => z u ∈ H))

open Classical in
private lemma doubleBadInitial_card_le
    {D M : ℕ} {ι : Type*} [Fintype ι]
    (Q : ι → EuclideanSpace ℝ (Fin D)) {α : ℝ}
    (hα : 0 < α) (hM : 1 ≤ M) (hDM : D + 1 ≤ 2 * M) :
    ((doubleBadInitialFinset (M := M) Q α).card : ℝ) ≤
      (Fintype.card ((Fin M → ι) × (Fin M → ι)) : ℝ) *
        (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
        Real.exp (-(α * (M : ℝ)) / 12) := by
  let B := doubleBadInitialFinset (M := M) Q α
  let v : ℝ := α * (M : ℝ)
  have hM_pos : (0 : ℝ) < (M : ℝ) := Nat.cast_pos.mpr (by omega)
  have hv_pos : 0 < v := mul_pos hα hM_pos
  have hcard_swap : ∀ σ : Fin M → Bool,
      B.card =
        (Finset.univ.filter (fun p : (Fin M → ι) × (Fin M → ι) =>
          swapPair σ p ∈ B)).card := by
    intro σ
    symm
    refine Finset.card_bij (fun p _ => swapPair σ p) ?_ ?_ ?_
    · intro p hp
      exact (Finset.mem_filter.mp hp).2
    · intro p₁ _ p₂ _ h
      exact (swapPair_involutive σ).injective h
    · intro q hq
      refine ⟨swapPair σ q, ?_, swapPair_involutive σ q⟩
      rw [Finset.mem_filter]
      exact ⟨Finset.mem_univ _, by rwa [swapPair_involutive σ q]⟩
  have hsum_swap :
      (2 : ℝ) ^ M * (B.card : ℝ) =
        ∑ p : (Fin M → ι) × (Fin M → ι),
          ((Finset.univ.filter (fun σ : Fin M → Bool =>
            swapPair σ p ∈ B)).card : ℝ) := by
    calc
      (2 : ℝ) ^ M * (B.card : ℝ)
        = ∑ _σ : Fin M → Bool, (B.card : ℝ) := by
            simp [Finset.sum_const, nsmul_eq_mul]
      _ = ∑ σ : Fin M → Bool,
            ((Finset.univ.filter (fun p : (Fin M → ι) × (Fin M → ι) =>
              swapPair σ p ∈ B)).card : ℝ) := by
            refine Finset.sum_congr rfl (fun σ _ => ?_)
            exact_mod_cast hcard_swap σ
      _ = ∑ σ : Fin M → Bool, ∑ p : (Fin M → ι) × (Fin M → ι),
            (if swapPair σ p ∈ B then (1 : ℝ) else 0) := by
            refine Finset.sum_congr rfl (fun σ _ => ?_)
            simp [Finset.sum_boole]
      _ = ∑ p : (Fin M → ι) × (Fin M → ι), ∑ σ : Fin M → Bool,
            (if swapPair σ p ∈ B then (1 : ℝ) else 0) :=
            Finset.sum_comm
      _ = ∑ p : (Fin M → ι) × (Fin M → ι),
            ((Finset.univ.filter (fun σ : Fin M → Bool =>
              swapPair σ p ∈ B)).card : ℝ) := by
            refine Finset.sum_congr rfl (fun p _ => ?_)
            simp [Finset.sum_boole]
  have hp_bound : ∀ p : (Fin M → ι) × (Fin M → ι),
      ((Finset.univ.filter (fun σ : Fin M → Bool =>
          swapPair σ p ∈ B)).card : ℝ) ≤
        (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
          ((2 : ℝ) ^ M * Real.exp (-v / 12)) := by
    intro p
    let z : Fin M ⊕ Fin M → EuclideanSpace ℝ (Fin D) :=
      Sum.elim (fun t => Q (p.1 t)) (fun t => Q (p.2 t))
    have hsub :
        Finset.univ.filter (fun σ : Fin M → Bool => swapPair σ p ∈ B) ⊆
          (traceFamilySum z).biUnion (fun A => badSwapForTrace A v) := by
      intro σ hσ
      have hmem : swapPair σ p ∈ B := (Finset.mem_filter.mp hσ).2
      dsimp [B, doubleBadInitialFinset] at hmem
      rcases (Finset.mem_filter.mp hmem).2 with ⟨H, hH, hge1, hlt2⟩
      let A_H : Finset (Fin M ⊕ Fin M) := Finset.univ.filter (fun u => z u ∈ H)
      have hA_mem : A_H ∈ traceFamilySum z := by
        simp only [traceFamilySum, Finset.mem_filter, Finset.mem_univ, true_and]
        exact ⟨H, hH, rfl⟩
      refine Finset.mem_biUnion.mpr ⟨A_H, hA_mem, ?_⟩
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ⟨?_, ?_⟩⟩
      · have hfeq1 :
            Finset.univ.filter (fun j : Fin M => Q ((swapPair σ p).1 j) ∈ H) =
              Finset.univ.filter (fun t : Fin M =>
                (if σ t then Sum.inr t else Sum.inl t) ∈ A_H) := by
          ext t
          simp only [Finset.mem_filter, Finset.mem_univ, true_and, A_H, z, swapPair]
          cases σ t <;> simp
        have hc1 : (UL.pointCount (fun j : Fin M => Q ((swapPair σ p).1 j)) H : ℝ) =
            traceCount1 A_H σ := by
          rw [UL.pointCount, traceCount1, Finset.sum_boole, hfeq1]
        dsimp [v]
        linarith
      · have hfeq2 :
            Finset.univ.filter (fun j : Fin M => Q ((swapPair σ p).2 j) ∈ H) =
              Finset.univ.filter (fun t : Fin M =>
                (if σ t then Sum.inl t else Sum.inr t) ∈ A_H) := by
          ext t
          simp only [Finset.mem_filter, Finset.mem_univ, true_and, A_H, z, swapPair]
          cases σ t <;> simp
        have hc2 : (UL.pointCount (fun j : Fin M => Q ((swapPair σ p).2 j)) H : ℝ) =
            traceCount2 A_H σ := by
          rw [UL.pointCount, traceCount2, Finset.sum_boole, hfeq2]
        dsimp [v]
        linarith
    have hbi_nat :
        (Finset.univ.filter (fun σ : Fin M → Bool => swapPair σ p ∈ B)).card ≤
          ∑ A ∈ traceFamilySum z, (badSwapForTrace A v).card :=
      (Finset.card_le_card hsub).trans Finset.card_biUnion_le
    have hbi :
        ((Finset.univ.filter (fun σ : Fin M → Bool => swapPair σ p ∈ B)).card : ℝ) ≤
          ∑ A ∈ traceFamilySum z, ((badSwapForTrace A v).card : ℝ) := by
      exact_mod_cast hbi_nat
    have hsum_le :
        (∑ A ∈ traceFamilySum z, ((badSwapForTrace A v).card : ℝ)) ≤
          ((traceFamilySum z).card : ℝ) * ((2 : ℝ) ^ M * Real.exp (-v / 12)) := by
      calc
        (∑ A ∈ traceFamilySum z, ((badSwapForTrace A v).card : ℝ))
          ≤ ∑ _A ∈ traceFamilySum z, ((2 : ℝ) ^ M * Real.exp (-v / 12)) :=
            Finset.sum_le_sum (fun A _ => badSwapForTrace_card_le A hv_pos)
        _ = ((traceFamilySum z).card : ℝ) * ((2 : ℝ) ^ M * Real.exp (-v / 12)) := by
            rw [Finset.sum_const, nsmul_eq_mul]
    have hcardU_nat : Fintype.card (Fin M ⊕ Fin M) = 2 * M := by
      rw [Fintype.card_sum, Fintype.card_fin, two_mul]
    have hcardU_real : (Fintype.card (Fin M ⊕ Fin M) : ℝ) = 2 * (M : ℝ) := by
      exact_mod_cast hcardU_nat
    have hm_card : D + 1 ≤ Fintype.card (Fin M ⊕ Fin M) := by omega
    have htrace :
        ((traceFamilySum z).card : ℝ) ≤
          (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) := by
      have ht := UL.Proof_cit_hw87_halfspace_net.card_halfspace_traces_le z (traceFamilySum z)
        (fun A hA => (Finset.mem_filter.mp hA).2) hm_card
      rwa [hcardU_real] at ht
    have hmul_trace :
        ((traceFamilySum z).card : ℝ) * ((2 : ℝ) ^ M * Real.exp (-v / 12)) ≤
          (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
            ((2 : ℝ) ^ M * Real.exp (-v / 12)) :=
      mul_le_mul_of_nonneg_right htrace (by positivity)
    exact hbi.trans (hsum_le.trans hmul_trace)
  have htotal :
      (2 : ℝ) ^ M * (B.card : ℝ) ≤
        (Fintype.card ((Fin M → ι) × (Fin M → ι)) : ℝ) *
          ((Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
            ((2 : ℝ) ^ M * Real.exp (-v / 12))) := by
    rw [hsum_swap]
    calc
      (∑ p : (Fin M → ι) × (Fin M → ι),
          ((Finset.univ.filter (fun σ : Fin M → Bool => swapPair σ p ∈ B)).card : ℝ))
        ≤ ∑ _p : (Fin M → ι) × (Fin M → ι),
            ((Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
              ((2 : ℝ) ^ M * Real.exp (-v / 12))) :=
          Finset.sum_le_sum (fun p _ => hp_bound p)
      _ = (Fintype.card ((Fin M → ι) × (Fin M → ι)) : ℝ) *
            ((Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
              ((2 : ℝ) ^ M * Real.exp (-v / 12))) := by
          rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  have h2M_pos : (0 : ℝ) < (2 : ℝ) ^ M := by positivity
  refine le_of_mul_le_mul_left ?_ h2M_pos
  calc
    (2 : ℝ) ^ M * (B.card : ℝ)
      ≤ (Fintype.card ((Fin M → ι) × (Fin M → ι)) : ℝ) *
          ((Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
            ((2 : ℝ) ^ M * Real.exp (-v / 12))) := htotal
    _ = (2 : ℝ) ^ M *
          ((Fintype.card ((Fin M → ι) × (Fin M → ι)) : ℝ) *
            (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
            Real.exp (-(α * (M : ℝ)) / 12)) := by
          dsimp [v]
          ring

private lemma hpj_tail_le_half_phi
    {d : ℕ} {φ : ℝ} (hφ0 : 0 < φ)
    (P : HPJParams) (hP : HPJParamProps d φ P) :
    2 * (Real.exp 1 * (2 * ((2 ^ P.q : ℕ) : ℝ)) / (((d + 1 : ℕ) : ℝ) + 1)) ^ ((d + 1) + 1) *
      Real.exp (-(hpjAlpha d * ((2 ^ P.q : ℕ) : ℝ)) / 12) ≤ φ / 2 ∧
    32 ≤ ((2 ^ P.q : ℕ) : ℝ) * hpjAlpha d ∧
    (d + 1) + 1 ≤ 2 * (2 ^ P.q) := by
  rcases hP with ⟨hD, -, hk_phi, hq, -, -, -, hm, -, -, hphi_pow, hm_ge, -, -⟩
  let M : ℕ := 2 ^ P.q
  let D : ℕ := d + 1
  have hm_eq : P.m = M := hm
  have hPD2 : P.D + 2 = d + 3 := by omega
  have hm_ge' : 1300 * ((d + 3) * P.q + P.k_phi) * (d + 3) ^ 2 ≤ M := by
    rw [← hPD2, ← hm_eq]
    exact hm_ge
  have hDM : D + 1 ≤ 2 * M := by
    have h1 : 1 ≤ (d + 3) ^ 2 := Nat.one_le_pow 2 (d + 3) (by omega)
    have h2 : (d + 3) * 1 ≤ (d + 3) * P.q := Nat.mul_le_mul_left (d + 3) (by omega)
    have h3 : d + 2 ≤ (d + 3) * P.q + P.k_phi := by omega
    have h4 : (d + 3) * P.q + P.k_phi ≤ 1300 * ((d + 3) * P.q + P.k_phi) :=
      Nat.le_mul_of_pos_left _ (by norm_num)
    have h5 : 1300 * ((d + 3) * P.q + P.k_phi) ≤
        1300 * ((d + 3) * P.q + P.k_phi) * (d + 3) ^ 2 :=
      Nat.le_mul_of_pos_right _ h1
    dsimp [D]
    omega
  have hm_ge_real :
      (1300 : ℝ) * (((d : ℝ) + 3) * (P.q : ℝ) + (P.k_phi : ℝ)) * ((d : ℝ) + 3) ^ 2 ≤
        (M : ℝ) := by
    have hcast :
        ((1300 * ((d + 3) * P.q + P.k_phi) * (d + 3) ^ 2 : ℕ) : ℝ) ≤ (M : ℝ) := by
      exact_mod_cast hm_ge'
    push_cast at hcast
    linarith
  have hden_pos : (0 : ℝ) < 4 * ((d : ℝ) + 3) ^ 2 := by positivity
  have hv_ge :
      325 * (((d : ℝ) + 3) * (P.q : ℝ) + (P.k_phi : ℝ)) ≤ (M : ℝ) * hpjAlpha d := by
    have heq_div : (M : ℝ) * hpjAlpha d = (M : ℝ) / (4 * ((d : ℝ) + 3) ^ 2) := by
      unfold hpjAlpha
      ring
    rw [heq_div, le_div_iff₀ hden_pos]
    linarith
  have hd_nn : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
  have hq_real : (16 : ℝ) ≤ (P.q : ℝ) := by exact_mod_cast hq
  have hk_real : (3 : ℝ) ≤ (P.k_phi : ℝ) := by exact_mod_cast hk_phi
  have hdq_nn : 0 ≤ (d : ℝ) * (P.q : ℝ) := by positivity
  have hv_expand :
      ((d : ℝ) + 3) * (P.q : ℝ) + (P.k_phi : ℝ) =
        (d : ℝ) * (P.q : ℝ) + 3 * (P.q : ℝ) + (P.k_phi : ℝ) := by ring
  have hMα : 32 ≤ (M : ℝ) * hpjAlpha d := by linarith
  have h2_le_e : (2 : ℝ) ≤ Real.exp 1 := by linarith [Real.add_one_le_exp (1 : ℝ)]
  have hpow2_le_exp : ∀ k : ℕ, (2 : ℝ) ^ k ≤ Real.exp (k : ℝ) := by
    intro k
    calc
      (2 : ℝ) ^ k ≤ (Real.exp 1) ^ k := pow_le_pow_left₀ (by norm_num) h2_le_e k
      _ = Real.exp ((k : ℝ) * 1) := (Real.exp_nat_mul 1 k).symm
      _ = Real.exp (k : ℝ) := by ring
  have h2_div_phi_le : 2 / φ ≤ Real.exp (P.k_phi : ℝ) :=
    hphi_pow.trans (hpow2_le_exp P.k_phi)
  have h2_le_phi_exp : 2 ≤ Real.exp (P.k_phi : ℝ) * φ :=
    (div_le_iff₀ hφ0).mp h2_div_phi_le
  have hexp_neg_kphi : Real.exp (-(P.k_phi : ℝ)) ≤ φ / 2 := by
    have hm1 := mul_le_mul_of_nonneg_right h2_le_phi_exp (Real.exp_nonneg (-(P.k_phi : ℝ)))
    have hcancel : Real.exp (P.k_phi : ℝ) * φ * Real.exp (-(P.k_phi : ℝ)) = φ := by
      calc
        Real.exp (P.k_phi : ℝ) * φ * Real.exp (-(P.k_phi : ℝ))
            = φ * (Real.exp (P.k_phi : ℝ) * Real.exp (-(P.k_phi : ℝ))) := by ring
        _ = φ * Real.exp ((P.k_phi : ℝ) + -(P.k_phi : ℝ)) := by rw [← Real.exp_add]
        _ = φ := by simp
    linarith
  have hD1_pos : (0 : ℝ) < (D : ℝ) + 1 := by positivity
  have hD1_ge2 : (2 : ℝ) ≤ (D : ℝ) + 1 := by
    dsimp [D]
    push_cast
    linarith
  have hdiv_le_M : (2 * (M : ℝ)) / ((D : ℝ) + 1) ≤ (M : ℝ) := by
    rw [div_le_iff₀ hD1_pos, mul_comm (M : ℝ)]
    exact mul_le_mul_of_nonneg_right hD1_ge2 (Nat.cast_nonneg M)
  have hM_eq_pow : (M : ℝ) = (2 : ℝ) ^ P.q := by
    dsimp [M]
    push_cast
    rfl
  have hM_le_exp : (M : ℝ) ≤ Real.exp (P.q : ℝ) := by
    rw [hM_eq_pow]
    exact hpow2_le_exp P.q
  have hbase_le :
      Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1) ≤ Real.exp (1 + (P.q : ℝ)) := by
    calc
      Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)
          = Real.exp 1 * ((2 * (M : ℝ)) / ((D : ℝ) + 1)) := by ring
      _ ≤ Real.exp 1 * (M : ℝ) :=
          mul_le_mul_of_nonneg_left hdiv_le_M (Real.exp_nonneg 1)
      _ ≤ Real.exp 1 * Real.exp (P.q : ℝ) :=
          mul_le_mul_of_nonneg_left hM_le_exp (Real.exp_nonneg 1)
      _ = Real.exp (1 + (P.q : ℝ)) := (Real.exp_add 1 (P.q : ℝ)).symm
  have hpow_base_le :
      (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) ≤
        Real.exp (((D + 1 : ℕ) : ℝ) * (1 + (P.q : ℝ))) := by
    calc
      (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1)
          ≤ (Real.exp (1 + (P.q : ℝ))) ^ (D + 1) :=
          pow_le_pow_left₀ (by positivity) hbase_le (D + 1)
      _ = Real.exp (((D + 1 : ℕ) : ℝ) * (1 + (P.q : ℝ))) :=
          (Real.exp_nat_mul (1 + (P.q : ℝ)) (D + 1)).symm
  have hprod_le :
      2 * (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
          Real.exp (-(hpjAlpha d * (M : ℝ)) / 12) ≤
        Real.exp (1 + ((D + 1 : ℕ) : ℝ) * (1 + (P.q : ℝ)) +
          (-(hpjAlpha d * (M : ℝ)) / 12)) := by
    have h12 :
        2 * (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) ≤
          Real.exp 1 * Real.exp (((D + 1 : ℕ) : ℝ) * (1 + (P.q : ℝ))) :=
      mul_le_mul h2_le_e hpow_base_le (by positivity) (Real.exp_nonneg 1)
    calc
      2 * (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
          Real.exp (-(hpjAlpha d * (M : ℝ)) / 12)
          ≤ (Real.exp 1 * Real.exp (((D + 1 : ℕ) : ℝ) * (1 + (P.q : ℝ)))) *
              Real.exp (-(hpjAlpha d * (M : ℝ)) / 12) :=
          mul_le_mul_of_nonneg_right h12 (Real.exp_nonneg _)
      _ = Real.exp (1 + ((D + 1 : ℕ) : ℝ) * (1 + (P.q : ℝ)) +
            (-(hpjAlpha d * (M : ℝ)) / 12)) := by
          rw [← Real.exp_add, ← Real.exp_add]
  have hexp_arg_le :
      1 + ((D + 1 : ℕ) : ℝ) * (1 + (P.q : ℝ)) + (-(hpjAlpha d * (M : ℝ)) / 12) ≤
        -(P.k_phi : ℝ) := by
    have hD_cast : ((D + 1 : ℕ) : ℝ) = (d : ℝ) + 2 := by
      dsimp [D]
      push_cast
      ring
    rw [hD_cast]
    have h_expand1 :
        ((d : ℝ) + 2) * (1 + (P.q : ℝ)) =
          (d : ℝ) + 2 + (d : ℝ) * (P.q : ℝ) + 2 * (P.q : ℝ) := by ring
    have hd_le_dq : (d : ℝ) ≤ (d : ℝ) * (P.q : ℝ) := by
      calc
        (d : ℝ) = (d : ℝ) * 1 := (mul_one _).symm
        _ ≤ (d : ℝ) * (P.q : ℝ) := mul_le_mul_of_nonneg_left (by linarith) hd_nn
    have hcomm_v : hpjAlpha d * (M : ℝ) = (M : ℝ) * hpjAlpha d := mul_comm _ _
    linarith
  have htail :
      2 * (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
          Real.exp (-(hpjAlpha d * (M : ℝ)) / 12) ≤ φ / 2 :=
    hprod_le.trans ((Real.exp_le_exp.mpr hexp_arg_le).trans hexp_neg_kphi)
  exact ⟨htail, hMα, hDM⟩

open Classical in
theorem card_goodInitialSample_prefix_ge
    {d : ℕ} {φ : ℝ} (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2)
    (P : HPJParams) (hP : HPJParamProps d φ P)
    (ι : Type) [Fintype ι] [Nonempty ι]
    (Q : ι → EuclideanSpace ℝ (Fin (d + 1)))
    (N : ℕ) (hmN : 2 ^ P.q ≤ N) :
    (1 - φ / 2) * (Fintype.card (Fin N → ι) : ℝ) ≤
      ((Finset.univ.filter (fun ω : Fin N → ι =>
        GoodInitialSample Q (hpjAlpha d)
          (fun j : Fin (2 ^ P.q) => ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩))).card : ℝ) := by
  have _ := hφ1
  let M : ℕ := 2 ^ P.q
  let D : ℕ := d + 1
  let α : ℝ := hpjAlpha d
  obtain ⟨htail, hMα, hDM⟩ := hpj_tail_le_half_phi hφ0 P hP
  have hα_pos : 0 < α := by
    dsimp [α]
    unfold hpjAlpha
    positivity
  have hM_ge1 : 1 ≤ M := Nat.one_le_pow P.q 2 (by norm_num)
  let K : ℕ := Fintype.card (Fin M → ι)
  have hK_pos : (0 : ℝ) < (K : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have hBad1_le_Bad2 :
      ((badInitialFinset (M := M) Q α).card : ℝ) * (K : ℝ) ≤
        2 * ((doubleBadInitialFinset (M := M) Q α).card : ℝ) :=
    badInitial_le_two_doubleBad (M := M) Q hMα
  have hBad2_le :
      ((doubleBadInitialFinset (M := M) Q α).card : ℝ) ≤
        (Fintype.card ((Fin M → ι) × (Fin M → ι)) : ℝ) *
          (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
          Real.exp (-(α * (M : ℝ)) / 12) :=
    doubleBadInitial_card_le (M := M) Q hα_pos hM_ge1 hDM
  have hprod_card :
      (Fintype.card ((Fin M → ι) × (Fin M → ι)) : ℝ) = (K : ℝ) * (K : ℝ) := by
    exact_mod_cast Fintype.card_prod (Fin M → ι) (Fin M → ι)
  rw [hprod_card] at hBad2_le
  have hBad1_mul :
      ((badInitialFinset (M := M) Q α).card : ℝ) * (K : ℝ) ≤
        (2 * (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
          Real.exp (-(α * (M : ℝ)) / 12) * (K : ℝ)) * (K : ℝ) := by
    calc
      ((badInitialFinset (M := M) Q α).card : ℝ) * (K : ℝ)
          ≤ 2 * ((doubleBadInitialFinset (M := M) Q α).card : ℝ) := hBad1_le_Bad2
      _ ≤ 2 * (((K : ℝ) * (K : ℝ)) *
            (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
            Real.exp (-(α * (M : ℝ)) / 12)) :=
          mul_le_mul_of_nonneg_left hBad2_le (by norm_num)
      _ = (2 * (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
            Real.exp (-(α * (M : ℝ)) / 12) * (K : ℝ)) * (K : ℝ) := by ring
  have hBad1_bound :
      ((badInitialFinset (M := M) Q α).card : ℝ) ≤ (φ / 2) * (K : ℝ) := by
    have hstep1 :
        ((badInitialFinset (M := M) Q α).card : ℝ) ≤
          (2 * (Real.exp 1 * (2 * (M : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1) *
            Real.exp (-(α * (M : ℝ)) / 12)) * (K : ℝ) :=
      le_of_mul_le_mul_right hBad1_mul hK_pos
    exact hstep1.trans (mul_le_mul_of_nonneg_right htail hK_pos.le)
  let GoodM : Finset (Fin M → ι) :=
    Finset.univ.filter (fun ω₀ : Fin M → ι => GoodInitialSample Q α ω₀)
  have hpartM : (GoodM.card : ℝ) + ((badInitialFinset (M := M) Q α).card : ℝ) = (K : ℝ) := by
    have hnat : GoodM.card + (badInitialFinset (M := M) Q α).card = K := by
      dsimp [GoodM, badInitialFinset, K]
      rw [Finset.card_filter_add_card_filter_not, Finset.card_univ]
    exact_mod_cast hnat
  have hGoodM_ge : (1 - φ / 2) * (K : ℝ) ≤ (GoodM.card : ℝ) := by linarith
  have hGoodN_eq :
      ((Finset.univ.filter (fun ω : Fin N → ι =>
        GoodInitialSample Q (hpjAlpha d)
          (fun j : Fin (2 ^ P.q) => ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩))).card : ℝ) =
        (GoodM.card : ℝ) * (Fintype.card (Fin (N - M) → ι) : ℝ) := by
    have hnat := card_filter_prefix_eq hmN (GoodInitialSample Q (hpjAlpha d))
    exact_mod_cast hnat
  have hcardN_eq :
      (Fintype.card (Fin N → ι) : ℝ) =
        (K : ℝ) * (Fintype.card (Fin (N - M) → ι) : ℝ) := by
    have hnat : Fintype.card (Fin N → ι) = K * Fintype.card (Fin (N - M) → ι) := by
      rw [Fintype.card_congr (splitFinFunEquiv hmN ι), Fintype.card_prod]
    exact_mod_cast hnat
  rw [hcardN_eq, hGoodN_eq, ← mul_assoc]
  exact mul_le_mul_of_nonneg_right hGoodM_ge (Nat.cast_nonneg _)

end UL.Proof_cit_hpj19_thm18
