import UL.Proof.cit_hpj19_thm18.H0
set_option autoImplicit false

namespace UL.Proof_cit_hpj19_thm18

/-! ### Part 1: Parameter bounds (`hpjParams_props`) -/

private lemma ceilPow2From_spec (e p target : ℕ) (hp : p = 2 ^ e) :
    let res := ceilPow2From e p target
    res.2 = 2 ^ res.1 ∧
    e ≤ res.1 ∧
    target ≤ res.2 ∧
    (p < target → res.2 < 2 * target) := by
  have hp_pos : 0 < p := by
    rw [hp]
    exact Nat.two_pow_pos e
  unfold ceilPow2From
  split_ifs with h
  · have hp2 : 2 * p = 2 ^ (e + 1) := by
      rw [hp, pow_succ']
    have ih := ceilPow2From_spec (e + 1) (2 * p) target hp2
    dsimp only at ih ⊢
    refine ⟨ih.1, by omega, ih.2.2.1, fun _ => ?_⟩
    by_cases h2 : 2 * p < target
    · exact ih.2.2.2 h2
    · have heq : ceilPow2From (e + 1) (2 * p) target = (e + 1, 2 * p) := by
        unfold ceilPow2From
        rw [dif_neg (by omega)]
      rw [heq]
      dsimp only
      omega
  · dsimp only
    refine ⟨hp, le_rfl, by omega, fun hlt => absurd ⟨hlt, hp_pos⟩ h⟩
termination_by target - p
decreasing_by omega

private lemma ceilPow2From_le_two_mul (e p target : ℕ) (hp : p = 2 ^ e) (hle : p ≤ 2 * target) :
    (ceilPow2From e p target).2 ≤ 2 * target := by
  have hspec := ceilPow2From_spec e p target hp
  by_cases hlt : p < target
  · exact (hspec.2.2.2 hlt).le
  · unfold ceilPow2From
    rw [dif_neg (by omega)]
    exact hle

private lemma ceilPow2From_exp_le_self (target : ℕ) (ht : 1 ≤ target) :
    (ceilPow2From 0 1 target).1 ≤ target := by
  have hspec := ceilPow2From_spec 0 1 target rfl
  set u := (ceilPow2From 0 1 target).1
  set pk := (ceilPow2From 0 1 target).2
  by_cases hu : u = 0
  · omega
  · have hlt : 1 < target := by
      by_contra hnot
      have heq : ceilPow2From 0 1 target = (0, 1) := by
        unfold ceilPow2From
        rw [dif_neg (by omega)]
      have : u = 0 := congrArg Prod.fst heq
      exact hu this
    have hpk_lt : pk < 2 * target := hspec.2.2.2 hlt
    have hpow_eq : pk = 2 * 2 ^ (u - 1) := by
      have hpk_pow : pk = 2 ^ u := hspec.1
      rw [hpk_pow]
      conv_lhs => rw [show u = (u - 1) + 1 by omega, pow_succ']
    have hpow_lt : 2 ^ (u - 1) < target := by omega
    have hself : u - 1 < 2 ^ (u - 1) := Nat.lt_two_pow_self
    omega

private lemma ceilLog2TwoDiv_spec {φ : ℝ} (hφ0 : 0 < φ) :
    1 ≤ ceilLog2TwoDiv φ ∧
    2 ≤ (2 : ℝ) ^ (ceilLog2TwoDiv φ) * φ ∧
    ∀ j : ℕ, j < ceilLog2TwoDiv φ → ¬ (1 ≤ j ∧ 2 ≤ (2 : ℝ) ^ j * φ) := by
  classical
  unfold ceilLog2TwoDiv
  rw [dif_pos hφ0]
  generalize_proofs hex
  exact ⟨(Nat.find_spec hex).1, (Nat.find_spec hex).2, fun j hj => Nat.find_min hex hj⟩

private lemma half_le_log_two : (1 / 2 : ℝ) ≤ Real.log 2 := by
  have h1 : (1 / 2 : ℝ) ≤ Real.exp (-(1 / 2 : ℝ)) := by
    have := Real.add_one_le_exp (-(1 / 2 : ℝ))
    linarith
  have h2 : Real.exp (1 / 2 : ℝ) ≤ 2 := by
    have hmul : (1 / 2 : ℝ) * (2 * Real.exp (1 / 2 : ℝ)) ≤
        Real.exp (-(1 / 2 : ℝ)) * (2 * Real.exp (1 / 2 : ℝ)) :=
      mul_le_mul_of_nonneg_right h1 (by positivity)
    have hprod : Real.exp (-(1 / 2 : ℝ)) * Real.exp (1 / 2 : ℝ) = 1 := by
      rw [← Real.exp_add]
      norm_num
    linarith
  rw [Real.le_log_iff_exp_le (by norm_num)]
  exact h2

/-- Pure arithmetic parameter proof with abstract variables (avoiding symbolic unfolding of `ceilPow2From`). -/
private lemma hpjParams_cost_core
    (d kd pd kphi pkd pkphi q m L D : ℕ) {φ X LD LP : ℝ}
    (hm_def : m = 65536 * pd * pd * pd * pkd * pkphi)
    (hL_def : L = 3 * m * (4 * (D + 2) * q + 4 * kphi + 16))
    (hX_def : X = (d : ℝ) + 1)
    (hLD_def : LD = Real.log ((d : ℝ) + 2))
    (hLP_def : LP = Real.log (2 / φ))
    (hX_ge : 1 ≤ X) (hLD_ge : (1 / 2 : ℝ) ≤ LD) (hLP_ge : 1 ≤ LP)
    (hkd_real : (kd : ℝ) ≤ 4 * LD) (hkphi_real : (kphi : ℝ) ≤ 4 * LP)
    (hpd_real : (pd : ℝ) ≤ 4 * X) (hpkd_real : (pkd : ℝ) ≤ 8 * LD) (hpkphi_real : (pkphi : ℝ) ≤ 8 * LP)
    (hq_real : (q : ℝ) ≤ 128 * (LD * LP))
    (hD2_real : ((D + 2 : ℕ) : ℝ) ≤ 3 * X)
    (hD3_real : ((D + 3 : ℕ) : ℝ) ≤ 4 * X)
    (hLDLP_ge : (1 / 2 : ℝ) ≤ LD * LP)
    (hXLD_ge : (1 / 2 : ℝ) ≤ X * LD)
    (hXLDLP_ge : (1 / 2 : ℝ) ≤ X * (LD * LP)) :
    (m : ℝ) ≤ hpjOpBound d φ ∧
    100000 * ((kd + kphi + m * (D + 2) +
      L * ((D + 3) * (q + 1) + (D + 3) ^ 3) : ℕ) : ℝ) ≤ hpjOpBound d φ := by
  have hm_real_ub : (m : ℝ) ≤ ((2 : ℝ) ^ 28) * (X ^ 3 * (LD * LP)) := by
    have hm_cast : (m : ℝ) = ((2 : ℝ) ^ 16) * ((pd : ℝ) ^ 3 * ((pkd : ℝ) * (pkphi : ℝ))) := by
      rw [hm_def]
      simp only [Nat.cast_mul, show ((65536 : ℕ) : ℝ) = (2 : ℝ) ^ 16 by norm_num]
      generalize ((2 : ℝ) ^ 16) = c16
      ring
    have hpd3 : (pd : ℝ) ^ 3 ≤ 64 * X ^ 3 := by
      calc
        (pd : ℝ) ^ 3 ≤ (4 * X) ^ 3 := pow_le_pow_left₀ (by positivity) hpd_real 3
        _ = 64 * X ^ 3 := by ring
    have hpk_mul : (pkd : ℝ) * (pkphi : ℝ) ≤ 64 * (LD * LP) := by
      calc
        (pkd : ℝ) * (pkphi : ℝ) ≤ (8 * LD) * (8 * LP) :=
          mul_le_mul hpkd_real hpkphi_real (by positivity) (by positivity)
        _ = 64 * (LD * LP) := by ring
    have hcomb : (pd : ℝ) ^ 3 * ((pkd : ℝ) * (pkphi : ℝ)) ≤
        ((2 : ℝ) ^ 12) * (X ^ 3 * (LD * LP)) := by
      calc
        (pd : ℝ) ^ 3 * ((pkd : ℝ) * (pkphi : ℝ))
            ≤ (64 * X ^ 3) * (64 * (LD * LP)) :=
          mul_le_mul hpd3 hpk_mul (by positivity) (by positivity)
        _ = 4096 * (X ^ 3 * (LD * LP)) := by ring
        _ = ((2 : ℝ) ^ 12) * (X ^ 3 * (LD * LP)) := by
          rw [show (4096 : ℝ) = (2 : ℝ) ^ 12 by norm_num]
    rw [hm_cast]
    calc
      ((2 : ℝ) ^ 16) * ((pd : ℝ) ^ 3 * ((pkd : ℝ) * (pkphi : ℝ)))
          ≤ ((2 : ℝ) ^ 16) * (((2 : ℝ) ^ 12) * (X ^ 3 * (LD * LP))) :=
        mul_le_mul_of_nonneg_left hcomb (pow_nonneg (by norm_num) _)
      _ = ((2 : ℝ) ^ 16 * (2 : ℝ) ^ 12) * (X ^ 3 * (LD * LP)) := (mul_assoc _ _ _).symm
      _ = ((2 : ℝ) ^ 28) * (X ^ 3 * (LD * LP)) := by rw [← pow_add]

  have hfactor_L : ((4 * (D + 2) * q + 4 * kphi + 16 : ℕ) : ℝ) ≤ ((2 : ℝ) ^ 11) * (X * (LD * LP)) := by
    have hcast : ((4 * (D + 2) * q + 4 * kphi + 16 : ℕ) : ℝ) =
        4 * (((D + 2 : ℕ) : ℝ) * (q : ℝ)) + 4 * (kphi : ℝ) + 16 := by
      simp only [Nat.cast_add, Nat.cast_mul, Nat.cast_ofNat]
      ring
    rw [hcast]
    have h1 : ((D + 2 : ℕ) : ℝ) * (q : ℝ) ≤ 384 * (X * (LD * LP)) := by
      calc
        ((D + 2 : ℕ) : ℝ) * (q : ℝ) ≤ (3 * X) * (128 * (LD * LP)) :=
          mul_le_mul hD2_real hq_real (by positivity) (by positivity)
        _ = 384 * (X * (LD * LP)) := by ring
    have h2 : (kphi : ℝ) ≤ 8 * (X * (LD * LP)) := by
      nlinarith only [hkphi_real, hXLD_ge, hLP_ge]
    have h3 : (16 : ℝ) ≤ 32 * (X * (LD * LP)) := by
      linarith only [hXLDLP_ge]
    rw [show (2 : ℝ) ^ 11 = 2048 by norm_num]
    linarith only [h1, h2, h3, hXLDLP_ge]

  have hL_real_ub : (L : ℝ) ≤ ((2 : ℝ) ^ 41) * (X ^ 4 * (LD * LP) ^ 2) := by
    have hL_cast : (L : ℝ) = 3 * ((m : ℝ) * ((4 * (D + 2) * q + 4 * kphi + 16 : ℕ) : ℝ)) := by
      rw [hL_def]
      simp only [Nat.cast_mul, Nat.cast_ofNat]
      ring
    have hmul : (m : ℝ) * ((4 * (D + 2) * q + 4 * kphi + 16 : ℕ) : ℝ) ≤
        (((2 : ℝ) ^ 28) * (X ^ 3 * (LD * LP))) * (((2 : ℝ) ^ 11) * (X * (LD * LP))) :=
      mul_le_mul hm_real_ub hfactor_L (by positivity) (mul_nonneg (pow_nonneg (by norm_num) _) (by positivity))
    rw [hL_cast]
    calc
      3 * ((m : ℝ) * ((4 * (D + 2) * q + 4 * kphi + 16 : ℕ) : ℝ))
          ≤ 3 * ((((2 : ℝ) ^ 28) * (X ^ 3 * (LD * LP))) * (((2 : ℝ) ^ 11) * (X * (LD * LP)))) :=
        mul_le_mul_of_nonneg_left hmul (by norm_num)
      _ ≤ ((2 : ℝ) ^ 2) * ((((2 : ℝ) ^ 28) * (X ^ 3 * (LD * LP))) * (((2 : ℝ) ^ 11) * (X * (LD * LP)))) := by
        gcongr
        norm_num
      _ = ((2 : ℝ) ^ 2 * (2 : ℝ) ^ 28 * (2 : ℝ) ^ 11) * (X ^ 4 * (LD * LP) ^ 2) := by
        generalize ((2 : ℝ) ^ 2) = a2, ((2 : ℝ) ^ 28) = a28, ((2 : ℝ) ^ 11) = a11
        ring
      _ = ((2 : ℝ) ^ 41) * (X ^ 4 * (LD * LP) ^ 2) := by
        simp only [← pow_add]

  have hstep_cost_ub :
      (((D + 3) * (q + 1) + (D + 3) ^ 3 : ℕ) : ℝ) ≤ ((2 : ℝ) ^ 10) * (X ^ 3 * (LD * LP)) := by
    have hcast : (((D + 3) * (q + 1) + (D + 3) ^ 3 : ℕ) : ℝ) =
        ((D + 3 : ℕ) : ℝ) * ((q : ℝ) + 1) + ((D + 3 : ℕ) : ℝ) ^ 3 := by
      simp only [Nat.cast_add, Nat.cast_mul, Nat.cast_pow, Nat.cast_one]
    rw [hcast]
    have hX_le_X3 : X ≤ X ^ 3 := by
      have hX2 : 1 ≤ X ^ 2 := one_le_pow₀ hX_ge
      nlinarith only [hX_ge, hX2]
    have hq1 : (q : ℝ) + 1 ≤ 130 * (LD * LP) := by linarith only [hq_real, hLDLP_ge]
    have hterm1 : ((D + 3 : ℕ) : ℝ) * ((q : ℝ) + 1) ≤ 520 * (X ^ 3 * (LD * LP)) := by
      calc
        ((D + 3 : ℕ) : ℝ) * ((q : ℝ) + 1) ≤ (4 * X) * (130 * (LD * LP)) :=
          mul_le_mul hD3_real hq1 (by positivity) (by positivity)
        _ = 520 * (X * (LD * LP)) := by ring
        _ ≤ 520 * (X ^ 3 * (LD * LP)) := by gcongr
    have hterm2 : ((D + 3 : ℕ) : ℝ) ^ 3 ≤ 128 * (X ^ 3 * (LD * LP)) := by
      have h1_le_2LDLP : 1 ≤ 2 * (LD * LP) := by linarith only [hLDLP_ge]
      calc
        ((D + 3 : ℕ) : ℝ) ^ 3 ≤ (4 * X) ^ 3 := pow_le_pow_left₀ (by positivity) hD3_real 3
        _ = 64 * X ^ 3 * 1 := by ring
        _ ≤ 64 * X ^ 3 * (2 * (LD * LP)) := by gcongr
        _ = 128 * (X ^ 3 * (LD * LP)) := by ring
    have hX3_LDLP_nn : 0 ≤ X ^ 3 * (LD * LP) := by positivity
    rw [show (2 : ℝ) ^ 10 = 1024 by norm_num]
    linarith only [hterm1, hterm2, hX3_LDLP_nn]

  let Base : ℝ := X ^ 7 * (LD * LP) ^ 3
  have hBase_nonneg : 0 ≤ Base := by dsimp [Base]; positivity
  have htotal_work_ub :
      100000 * ((kd + kphi + m * (D + 2) +
        L * ((D + 3) * (q + 1) + (D + 3) ^ 3) : ℕ) : ℝ) ≤ hpjOpBound d φ := by
    have hop_eq : hpjOpBound d φ = ((2 : ℝ) ^ 80) * Base := by
      unfold hpjOpBound hpjOpConst
      rw [← hX_def, ← hLD_def, ← hLP_def]
      dsimp [Base]
      generalize ((2 : ℝ) ^ 80) = c80
      ring
    rw [hop_eq]
    have hcast_tot :
        ((kd + kphi + m * (D + 2) + L * ((D + 3) * (q + 1) + (D + 3) ^ 3) : ℕ) : ℝ) =
          (kd : ℝ) + (kphi : ℝ) + (m : ℝ) * ((D + 2 : ℕ) : ℝ) +
            (L : ℝ) * (((D + 3) * (q + 1) + (D + 3) ^ 3 : ℕ) : ℝ) := by
      simp only [Nat.cast_add, Nat.cast_mul]
    rw [hcast_tot]
    have hX4_le_X7 : X ^ 4 ≤ X ^ 7 := by
      have hX3 : 1 ≤ X ^ 3 := one_le_pow₀ hX_ge
      have hX4_nn : 0 ≤ X ^ 4 := by positivity
      calc
        X ^ 4 = X ^ 4 * 1 := (mul_one _).symm
        _ ≤ X ^ 4 * X ^ 3 := mul_le_mul_of_nonneg_left hX3 hX4_nn
        _ = X ^ 7 := by ring
    have hLDLP_1_le_3 : LD * LP ≤ 4 * (LD * LP) ^ 3 := by
      have hsq : (1 / 4 : ℝ) ≤ (LD * LP) ^ 2 := by nlinarith only [hLDLP_ge]
      calc
        LD * LP = (LD * LP) * (4 * (1 / 4 : ℝ)) := by ring
        _ ≤ (LD * LP) * (4 * (LD * LP) ^ 2) :=
          mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hsq (by norm_num)) (by positivity)
        _ = 4 * (LD * LP) ^ 3 := by ring
    have h_kd_kphi : (kd : ℝ) + (kphi : ℝ) ≤ ((2 : ℝ) ^ 6) * Base := by
      have h1 : (kd : ℝ) + (kphi : ℝ) ≤ 16 * (LD * LP) := by
        nlinarith only [hkd_real, hkphi_real, hLD_ge, hLP_ge]
      have h2 : (kd : ℝ) + (kphi : ℝ) ≤ 64 * 1 * (LD * LP) ^ 3 := by
        linarith only [h1, hLDLP_1_le_3]
      have hX7 : 1 ≤ X ^ 7 := one_le_pow₀ hX_ge
      calc
        (kd : ℝ) + (kphi : ℝ) ≤ 64 * 1 * (LD * LP) ^ 3 := h2
        _ ≤ 64 * X ^ 7 * (LD * LP) ^ 3 := by gcongr
        _ = ((2 : ℝ) ^ 6) * Base := by
          rw [show (64 : ℝ) = (2 : ℝ) ^ 6 by norm_num]
          dsimp [Base]
          generalize ((2 : ℝ) ^ 6) = c6
          ring
    have h_mD2 : (m : ℝ) * ((D + 2 : ℕ) : ℝ) ≤ ((2 : ℝ) ^ 32) * Base := by
      calc
        (m : ℝ) * ((D + 2 : ℕ) : ℝ)
            ≤ (((2 : ℝ) ^ 28) * (X ^ 3 * (LD * LP))) * (3 * X) :=
          mul_le_mul hm_real_ub hD2_real (by positivity) (mul_nonneg (pow_nonneg (by norm_num) _) (by positivity))
        _ ≤ (((2 : ℝ) ^ 28) * (X ^ 3 * (LD * LP))) * (((2 : ℝ) ^ 2) * X) := by
          gcongr
          norm_num
        _ = ((2 : ℝ) ^ 28 * (2 : ℝ) ^ 2) * (X ^ 4 * (LD * LP)) := by
          generalize ((2 : ℝ) ^ 28) = c28, ((2 : ℝ) ^ 2) = c2
          ring
        _ ≤ ((2 : ℝ) ^ 30) * (X ^ 7 * (4 * (LD * LP) ^ 3)) := by
          rw [← pow_add]
          gcongr
        _ = ((2 : ℝ) ^ 30 * (2 : ℝ) ^ 2) * Base := by
          rw [show (4 : ℝ) = (2 : ℝ) ^ 2 by norm_num]
          dsimp [Base]
          generalize ((2 : ℝ) ^ 30) = c30, ((2 : ℝ) ^ 2) = c2
          ring
        _ = ((2 : ℝ) ^ 32) * Base := by rw [← pow_add]
    have h_Lstep :
        (L : ℝ) * (((D + 3) * (q + 1) + (D + 3) ^ 3 : ℕ) : ℝ) ≤ ((2 : ℝ) ^ 51) * Base := by
      calc
        (L : ℝ) * (((D + 3) * (q + 1) + (D + 3) ^ 3 : ℕ) : ℝ)
            ≤ (((2 : ℝ) ^ 41) * (X ^ 4 * (LD * LP) ^ 2)) * (((2 : ℝ) ^ 10) * (X ^ 3 * (LD * LP))) :=
          mul_le_mul hL_real_ub hstep_cost_ub (by positivity) (mul_nonneg (pow_nonneg (by norm_num) _) (by positivity))
        _ = ((2 : ℝ) ^ 41 * (2 : ℝ) ^ 10) * Base := by
          dsimp [Base]
          generalize ((2 : ℝ) ^ 41) = c41, ((2 : ℝ) ^ 10) = c10
          ring
        _ = ((2 : ℝ) ^ 51) * Base := by rw [← pow_add]
    have h_sum3 :
        (kd : ℝ) + (kphi : ℝ) + (m : ℝ) * ((D + 2 : ℕ) : ℝ) +
          (L : ℝ) * (((D + 3) * (q + 1) + (D + 3) ^ 3 : ℕ) : ℝ) ≤ ((2 : ℝ) ^ 53) * Base := by
      have h6_51 : (2 : ℝ) ^ 6 ≤ (2 : ℝ) ^ 51 := pow_le_pow_right₀ (by norm_num) (by decide)
      have h32_51 : (2 : ℝ) ^ 32 ≤ (2 : ℝ) ^ 51 := pow_le_pow_right₀ (by norm_num) (by decide)
      have hsum_coeff : (2 : ℝ) ^ 6 + (2 : ℝ) ^ 32 + (2 : ℝ) ^ 51 ≤ (2 : ℝ) ^ 53 := by
        calc
          (2 : ℝ) ^ 6 + (2 : ℝ) ^ 32 + (2 : ℝ) ^ 51
              ≤ (2 : ℝ) ^ 51 + (2 : ℝ) ^ 51 + (2 : ℝ) ^ 51 := add_le_add (add_le_add h6_51 h32_51) le_rfl
          _ = 3 * (2 : ℝ) ^ 51 := by
            generalize ((2 : ℝ) ^ 51) = c51
            ring
          _ ≤ ((2 : ℝ) ^ 2) * (2 : ℝ) ^ 51 := by gcongr; norm_num
          _ = (2 : ℝ) ^ 53 := by rw [← pow_add]
      calc
        (kd : ℝ) + (kphi : ℝ) + (m : ℝ) * ((D + 2 : ℕ) : ℝ) +
            (L : ℝ) * (((D + 3) * (q + 1) + (D + 3) ^ 3 : ℕ) : ℝ)
            ≤ ((2 : ℝ) ^ 6) * Base + ((2 : ℝ) ^ 32) * Base + ((2 : ℝ) ^ 51) * Base :=
          add_le_add (add_le_add h_kd_kphi h_mD2) h_Lstep
        _ = ((2 : ℝ) ^ 6 + (2 : ℝ) ^ 32 + (2 : ℝ) ^ 51) * Base := by
          rw [add_mul, add_mul]
        _ ≤ ((2 : ℝ) ^ 53) * Base := mul_le_mul_of_nonneg_right hsum_coeff hBase_nonneg
    have h100k : (100000 : ℝ) ≤ (2 : ℝ) ^ 17 := by norm_num
    have h70_80 : (2 : ℝ) ^ 70 ≤ (2 : ℝ) ^ 80 := pow_le_pow_right₀ (by norm_num) (by decide)
    calc
      100000 * ((kd : ℝ) + (kphi : ℝ) + (m : ℝ) * ((D + 2 : ℕ) : ℝ) +
          (L : ℝ) * (((D + 3) * (q + 1) + (D + 3) ^ 3 : ℕ) : ℝ))
          ≤ ((2 : ℝ) ^ 17) * (((2 : ℝ) ^ 53) * Base) :=
        mul_le_mul h100k h_sum3 (add_nonneg (add_nonneg (add_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _)) (mul_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _))) (mul_nonneg (Nat.cast_nonneg _) (by positivity))) (pow_nonneg (by norm_num) _)
      _ = ((2 : ℝ) ^ 17 * (2 : ℝ) ^ 53) * Base := (mul_assoc _ _ _).symm
      _ = ((2 : ℝ) ^ 70) * Base := by rw [← pow_add]
      _ ≤ ((2 : ℝ) ^ 80) * Base := mul_le_mul_of_nonneg_right h70_80 hBase_nonneg

  have hm_le_op : (m : ℝ) ≤ hpjOpBound d φ := by
    have hm_le_prod : (m : ℝ) ≤ (m : ℝ) * ((D + 2 : ℕ) : ℝ) := by
      have h1 : (1 : ℝ) ≤ ((D + 2 : ℕ) : ℝ) := by
        exact_mod_cast (show 1 ≤ D + 2 from Nat.succ_le_succ (Nat.zero_le _))
      simpa using mul_le_mul_of_nonneg_left h1 (Nat.cast_nonneg m)
    let Tot : ℝ := ((kd + kphi + m * (D + 2) + L * ((D + 3) * (q + 1) + (D + 3) ^ 3) : ℕ) : ℝ)
    have hTot_nn : 0 ≤ Tot := Nat.cast_nonneg _
    have hm_le_Tot : (m : ℝ) ≤ Tot := by
      have hm_nat : m * (D + 2) ≤ kd + kphi + m * (D + 2) + L * ((D + 3) * (q + 1) + (D + 3) ^ 3) :=
        (Nat.le_add_left _ _).trans (Nat.le_add_right _ _)
      have hm_cast_le : (((m * (D + 2) : ℕ) : ℝ)) ≤ Tot := Nat.cast_le.mpr hm_nat
      rw [Nat.cast_mul] at hm_cast_le
      exact hm_le_prod.trans hm_cast_le
    have hTot_100k : Tot ≤ 100000 * Tot := by linarith only [hTot_nn]
    exact (hm_le_Tot.trans hTot_100k).trans htotal_work_ub

  exact ⟨hm_le_op, htotal_work_ub⟩

private lemma hpjParams_arith_core
    (d kd pd kphi ud pkd uphi pkphi : ℕ) {φ : ℝ}
    (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2)
    (hkd_ge : 1 ≤ kd) (hpd_pow : pd = 2 ^ kd) (hpd_ge : d + 2 ≤ pd) (hpd_le : pd ≤ 2 * (d + 2))
    (hkd_prev_le : 2 ^ (kd - 1) ≤ d + 2)
    (hpkd_pow : pkd = 2 ^ ud) (hpkd_ge : kd ≤ pkd) (hpkd_le : pkd ≤ 2 * kd) (hud_le : ud ≤ kd)
    (hkphi_ge1 : 1 ≤ kphi) (hkphi_mul : 2 ≤ (2 : ℝ) ^ kphi * φ)
    (hkphi_min : ∀ j : ℕ, j < kphi → ¬ (1 ≤ j ∧ 2 ≤ (2 : ℝ) ^ j * φ))
    (hpkphi_pow : pkphi = 2 ^ uphi) (hpkphi_ge : kphi ≤ pkphi) (hpkphi_le : pkphi ≤ 2 * kphi)
    (huphi_le : uphi ≤ kphi) :
    let D := d + 1
    let q := 16 + 3 * kd + ud + uphi
    let m := 65536 * pd * pd * pd * pkd * pkphi
    let L := 3 * m * (4 * (D + 2) * q + 4 * kphi + 16)
    3 ≤ kphi ∧
    16 ≤ q ∧
    m = 2 ^ q ∧
    2 / φ ≤ (2 : ℝ) ^ kphi ∧
    1300 * ((D + 2) * q + kphi) * (D + 2) ^ 2 ≤ m ∧
    (m : ℝ) ≤ hpjOpBound d φ ∧
    100000 * ((kd + kphi + m * (D + 2) +
      L * ((D + 3) * (q + 1) + (D + 3) ^ 3) : ℕ) : ℝ) ≤ hpjOpBound d φ := by
  intro D q m L
  have h2div_le : 2 / φ ≤ (2 : ℝ) ^ kphi := by
    rw [div_le_iff₀ hφ0]
    exact hkphi_mul
  have hkphi_ge3 : 3 ≤ kphi := by
    by_contra hlt
    have hk_cases : kphi = 1 ∨ kphi = 2 := by omega
    rcases hk_cases with rfl | rfl
    · norm_num at hkphi_mul
      linarith
    · norm_num at hkphi_mul
      linarith
  have hkphi_prev_lt : (2 : ℝ) ^ (kphi - 1) < 2 / φ := by
    have hnot := hkphi_min (kphi - 1) (by omega)
    have hge1 : 1 ≤ kphi - 1 := by omega
    have hlt_mul : (2 : ℝ) ^ (kphi - 1) * φ < 2 := by
      by_contra hge
      push_neg at hge
      exact hnot ⟨hge1, hge⟩
    rwa [lt_div_iff₀ hφ0]

  have hq_ge : 16 ≤ q := by omega
  have hm_pow : m = 2 ^ q := by
    dsimp [m, q]
    rw [show (65536 : ℕ) = 2 ^ 16 by norm_num, hpd_pow, hpkd_pow, hpkphi_pow]
    simp only [← pow_add]
    congr 1
    omega

  have hq_le_prod : q ≤ 8 * kd * kphi := by
    have hq_ub : q ≤ 16 + 4 * kd + kphi := by omega
    nlinarith

  have hm_lb : 1300 * ((D + 2) * q + kphi) * (D + 2) ^ 2 ≤ m := by
    have hD2_pd : 2 * (D + 2) ≤ 3 * pd := by omega
    have h8_D2_cube : 8 * (D + 2) ^ 3 ≤ 27 * pd ^ 3 := by
      calc
        8 * (D + 2) ^ 3 = (2 * (D + 2)) ^ 3 := by ring
        _ ≤ (3 * pd) ^ 3 := Nat.pow_le_pow_left hD2_pd 3
        _ = 27 * pd ^ 3 := by ring
    have hterm_ub : (D + 2) * q + kphi ≤ 9 * (D + 2) * (kd * kphi) := by
      have h1 : (D + 2) * q ≤ (D + 2) * (8 * kd * kphi) := Nat.mul_le_mul_left (D + 2) hq_le_prod
      have h2 : kphi ≤ (D + 2) * (kd * kphi) := by
        have : 1 ≤ (D + 2) * kd := Nat.mul_pos (by omega) (by omega)
        calc
          kphi = 1 * kphi := (one_mul kphi).symm
          _ ≤ ((D + 2) * kd) * kphi := Nat.mul_le_mul_right kphi this
          _ = (D + 2) * (kd * kphi) := by ring
      linarith
    have h8_lhs : 8 * (1300 * ((D + 2) * q + kphi) * (D + 2) ^ 2) ≤ 8 * m := by
      calc
        8 * (1300 * ((D + 2) * q + kphi) * (D + 2) ^ 2)
            ≤ 8 * (1300 * (9 * (D + 2) * (kd * kphi)) * (D + 2) ^ 2) := by gcongr
        _ = 11700 * (8 * (D + 2) ^ 3) * (kd * kphi) := by ring
        _ ≤ 11700 * (27 * pd ^ 3) * (pkd * pkphi) := by gcongr
        _ = 315900 * (pd * pd * pd * pkd * pkphi) := by ring
        _ ≤ 524288 * (pd * pd * pd * pkd * pkphi) :=
            Nat.mul_le_mul_right _ (by decide)
        _ = 8 * m := by
            dsimp [m]
            ring
    omega

  let X : ℝ := (d : ℝ) + 1
  let LD : ℝ := Real.log ((d : ℝ) + 2)
  let LP : ℝ := Real.log (2 / φ)
  have hd_nn : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
  have hX_ge : 1 ≤ X := by dsimp [X]; linarith only [hd_nn]
  have hlog2_ge : (1 / 2 : ℝ) ≤ Real.log 2 := half_le_log_two
  have hLD_ge : (1 / 2 : ℝ) ≤ LD := by
    have hle : Real.log 2 ≤ Real.log ((d : ℝ) + 2) :=
      Real.log_le_log (by norm_num) (by linarith only [hd_nn])
    linarith only [hlog2_ge, hle]
  have hLP_ge : 1 ≤ LP := by
    have h4_lt : (4 : ℝ) < 2 / φ := by
      rw [lt_div_iff₀ hφ0]
      linarith only [hφ1]
    have hlog4 : 2 * Real.log 2 = Real.log 4 := by
      rw [show (4 : ℝ) = (2 : ℝ) ^ 2 by norm_num, Real.log_pow]
      norm_num
    have hle : Real.log 4 ≤ Real.log (2 / φ) :=
      Real.log_le_log (by norm_num) h4_lt.le
    linarith only [hlog2_ge, hlog4, hle]

  have hkd_real : (kd : ℝ) ≤ 4 * LD := by
    have hpow_real : (2 : ℝ) ^ (kd - 1) ≤ (d : ℝ) + 2 := by exact_mod_cast hkd_prev_le
    have hlog_le : Real.log ((2 : ℝ) ^ (kd - 1)) ≤ LD :=
      Real.log_le_log (by positivity) hpow_real
    rw [Real.log_pow] at hlog_le
    have hnn1 : (0 : ℝ) ≤ ((kd - 1 : ℕ) : ℝ) := Nat.cast_nonneg _
    have hsub_le : ((kd - 1 : ℕ) : ℝ) ≤ 2 * LD := by nlinarith only [hlog_le, hlog2_ge, hnn1]
    have hkd_eq : (kd : ℝ) = ((kd - 1 : ℕ) : ℝ) + 1 := by
      have : (kd - 1) + 1 = kd := by omega
      exact_mod_cast this.symm
    linarith only [hsub_le, hkd_eq, hLD_ge]

  have hkphi_real : (kphi : ℝ) ≤ 4 * LP := by
    have hlog_le : Real.log ((2 : ℝ) ^ (kphi - 1)) ≤ LP :=
      Real.log_le_log (by positivity) hkphi_prev_lt.le
    rw [Real.log_pow] at hlog_le
    have hnn2 : (0 : ℝ) ≤ ((kphi - 1 : ℕ) : ℝ) := Nat.cast_nonneg _
    have hsub_le : ((kphi - 1 : ℕ) : ℝ) ≤ 2 * LP := by nlinarith only [hlog_le, hlog2_ge, hnn2]
    have hkphi_eq : (kphi : ℝ) = ((kphi - 1 : ℕ) : ℝ) + 1 := by
      have : (kphi - 1) + 1 = kphi := by omega
      exact_mod_cast this.symm
    linarith only [hsub_le, hkphi_eq, hLP_ge]

  have hpd_real : (pd : ℝ) ≤ 4 * X := by
    have h1 : (pd : ℝ) ≤ 2 * ((d : ℝ) + 2) := by exact_mod_cast hpd_le
    change (pd : ℝ) ≤ 4 * ((d : ℝ) + 1)
    linarith only [h1, hd_nn]
  have hpkd_real : (pkd : ℝ) ≤ 8 * LD := by
    have h1 : (pkd : ℝ) ≤ 2 * (kd : ℝ) := by exact_mod_cast hpkd_le
    linarith only [h1, hkd_real]
  have hpkphi_real : (pkphi : ℝ) ≤ 8 * LP := by
    have h1 : (pkphi : ℝ) ≤ 2 * (kphi : ℝ) := by exact_mod_cast hpkphi_le
    linarith only [h1, hkphi_real]
  have hq_real : (q : ℝ) ≤ 128 * (LD * LP) := by
    have h1 : (q : ℝ) ≤ 8 * ((kd : ℝ) * (kphi : ℝ)) := by
      have : q ≤ 8 * (kd * kphi) := by linarith only [hq_le_prod]
      exact_mod_cast this
    have hmul : (kd : ℝ) * (kphi : ℝ) ≤ 16 * (LD * LP) := by
      calc
        (kd : ℝ) * (kphi : ℝ) ≤ (4 * LD) * (4 * LP) :=
          mul_le_mul hkd_real hkphi_real (by positivity) (by positivity)
        _ = 16 * (LD * LP) := by ring
    linarith only [h1, hmul]

  have hLDLP_ge : (1 / 2 : ℝ) ≤ LD * LP := by nlinarith only [hLD_ge, hLP_ge]
  have hXLD_ge : (1 / 2 : ℝ) ≤ X * LD := by nlinarith only [hX_ge, hLD_ge]
  have hXLDLP_ge : (1 / 2 : ℝ) ≤ X * (LD * LP) := by nlinarith only [hX_ge, hLDLP_ge]
  have hD2_real : ((D + 2 : ℕ) : ℝ) ≤ 3 * X := by
    change (((d + 1 + 2 : ℕ) : ℝ)) ≤ 3 * ((d : ℝ) + 1)
    push_cast
    linarith only [hd_nn]
  have hD3_real : ((D + 3 : ℕ) : ℝ) ≤ 4 * X := by
    change (((d + 1 + 3 : ℕ) : ℝ)) ≤ 4 * ((d : ℝ) + 1)
    push_cast
    linarith only [hd_nn]

  obtain ⟨hm_le_op, htotal_work_ub⟩ :=
    hpjParams_cost_core d kd pd kphi pkd pkphi q m L D
      rfl rfl rfl rfl rfl
      hX_ge hLD_ge hLP_ge hkd_real hkphi_real hpd_real hpkd_real hpkphi_real
      hq_real hD2_real hD3_real hLDLP_ge hXLD_ge hXLDLP_ge

  exact ⟨hkphi_ge3, hq_ge, hm_pow, h2div_le, hm_lb, hm_le_op, htotal_work_ub⟩

theorem hpjParams_props (d : ℕ) {φ : ℝ} (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2) :
    HPJParamProps d φ (hpjParams d φ) := by
  unfold HPJParamProps hpjParams
  dsimp only
  have hd_spec := ceilPow2From_spec 1 2 (d + 2) (by norm_num)
  have hpd_le : (ceilPow2From 1 2 (d + 2)).2 ≤ 2 * (d + 2) :=
    ceilPow2From_le_two_mul 1 2 (d + 2) (by norm_num) (by omega)
  have hkd_prev_le : 2 ^ ((ceilPow2From 1 2 (d + 2)).1 - 1) ≤ d + 2 := by
    set kd := (ceilPow2From 1 2 (d + 2)).1
    set pd := (ceilPow2From 1 2 (d + 2)).2
    by_cases hgt : 2 < d + 2
    · have hlt : pd < 2 * (d + 2) := hd_spec.2.2.2 hgt
      have hkd_ge : 1 ≤ kd := hd_spec.2.1
      have hpeq : pd = 2 * 2 ^ (kd - 1) := by
        have hpd_pow : pd = 2 ^ kd := hd_spec.1
        rw [hpd_pow]
        conv_lhs => rw [show kd = (kd - 1) + 1 by omega, pow_succ']
      omega
    · have heq : ceilPow2From 1 2 (d + 2) = (1, 2) := by
        unfold ceilPow2From
        rw [dif_neg (by omega)]
      have hkd1 : kd = 1 := congrArg Prod.fst heq
      rw [hkd1]
      norm_num
  have hud_spec := ceilPow2From_spec 0 1 (ceilPow2From 1 2 (d + 2)).1 rfl
  have hpkd_le := ceilPow2From_le_two_mul 0 1 (ceilPow2From 1 2 (d + 2)).1 rfl
    (by have := hd_spec.2.1; omega)
  have hud_le := ceilPow2From_exp_le_self (ceilPow2From 1 2 (d + 2)).1 hd_spec.2.1
  have hkphi_spec := ceilLog2TwoDiv_spec hφ0
  have huphi_spec := ceilPow2From_spec 0 1 (ceilLog2TwoDiv φ) rfl
  have hpkphi_le := ceilPow2From_le_two_mul 0 1 (ceilLog2TwoDiv φ) rfl
    (by have := hkphi_spec.1; omega)
  have huphi_le := ceilPow2From_exp_le_self (ceilLog2TwoDiv φ) hkphi_spec.1
  obtain ⟨hkphi_ge3, hq_ge, hm_pow, h2div_le, hm_lb, hm_le_op, htotal_work_ub⟩ :=
    hpjParams_arith_core d
      (ceilPow2From 1 2 (d + 2)).1 (ceilPow2From 1 2 (d + 2)).2
      (ceilLog2TwoDiv φ)
      (ceilPow2From 0 1 (ceilPow2From 1 2 (d + 2)).1).1
      (ceilPow2From 0 1 (ceilPow2From 1 2 (d + 2)).1).2
      (ceilPow2From 0 1 (ceilLog2TwoDiv φ)).1
      (ceilPow2From 0 1 (ceilLog2TwoDiv φ)).2
      hφ0 hφ1
      hd_spec.2.1 hd_spec.1 hd_spec.2.2.1 hpd_le hkd_prev_le
      hud_spec.1 hud_spec.2.2.1 hpkd_le hud_le
      hkphi_spec.1 hkphi_spec.2.1 hkphi_spec.2.2
      huphi_spec.1 huphi_spec.2.2.1 hpkphi_le huphi_le
  exact ⟨rfl, hd_spec.2.1, hkphi_ge3, hq_ge, hd_spec.1, hud_spec.1, huphi_spec.1, hm_pow,
    rfl, rfl, h2div_le, hm_lb, hm_le_op, htotal_work_ub⟩

/-! ### Part 2: Column Gaussian elimination & Radon convex-hull avoidance -/

private noncomputable def affCol {D : ℕ} (pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D))
    (r : Fin (D + 2)) (i : Fin (D + 1)) : ℝ :=
  if h : i.val < D then UL.euclideanCoord (pts r) ⟨i.val, h⟩ else 1

private def GaussInv {D : ℕ} (pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D))
    (n : ℕ) (st : GaussState D) : Prop :=
  (∀ (k : Fin (D + 2)) (i : Fin (D + 1)),
    st.v k i = ∑ r : Fin (D + 2), affCol pts r i * st.c k r) ∧
  (∀ (k r : Fin (D + 2)),
    st.used r = false → st.c k r = (if k = r then 1 else 0)) ∧
  (∀ (k : Fin (D + 2)) (i : Fin (D + 1)),
    st.used k = false → i.val < n → st.v k i = 0) ∧
  (Finset.univ.filter (fun k : Fin (D + 2) => st.used k = true)).card ≤ n

private lemma findFirstFin_none {n : ℕ} {P : Fin n → Prop}
    (h : findFirstFin P = none) : ∀ k : Fin n, ¬ P k := by
  classical
  unfold findFirstFin at h
  dsimp only at h
  split_ifs at h with hne
  have hemp : Finset.univ.filter P = ∅ := Finset.not_nonempty_iff_eq_empty.mp hne
  intro k hk
  have : k ∈ (Finset.univ.filter P) := Finset.mem_filter.mpr ⟨Finset.mem_univ k, hk⟩
  rw [hemp] at this
  exact Finset.notMem_empty k this

private lemma findFirstFin_some {n : ℕ} {P : Fin n → Prop} {p : Fin n}
    (h : findFirstFin P = some p) : P p := by
  classical
  unfold findFirstFin at h
  dsimp only at h
  split_ifs at h with hne
  injection h with hp
  rw [← hp]
  exact (Finset.mem_filter.mp (Finset.min'_mem _ hne)).2

private lemma gaussRunRows_inv {D : ℕ} (pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D)) :
    ∀ (n : ℕ) (hn : n ≤ D + 1), GaussInv pts n (gaussRunRows pts n hn)
  | 0, _ => by
      unfold gaussRunRows GaussInv initGaussState affCol
      dsimp only
      refine ⟨?_, ?_, ?_, ?_⟩
      · intro k i
        simp [mul_ite, mul_one, mul_zero]
      · intro k r _
        rfl
      · intro k i _ hi
        omega
      · simp
  | n + 1, hn => by
      classical
      have ih := gaussRunRows_inv pts n (by omega)
      set st := gaussRunRows pts n (by omega)
      let i₀ : Fin (D + 1) := ⟨n, hn⟩
      change GaussInv pts (n + 1) (gaussRowStep st i₀)
      unfold gaussRowStep
      rcases hfind : findFirstFin (fun k : Fin (D + 2) => st.used k = false ∧ st.v k i₀ ≠ 0) with _ | p
      · have hno := findFirstFin_none hfind
        refine ⟨ih.1, ih.2.1, ?_, ih.2.2.2.trans (Nat.le_succ n)⟩
        intro k i hk hi_lt
        rcases Nat.lt_succ_iff_lt_or_eq.mp hi_lt with hlt | heq
        · exact ih.2.2.1 k i hk hlt
        · have hi_eq : i = i₀ := Fin.ext heq
          rw [hi_eq]
          by_contra hne
          exact hno k ⟨hk, hne⟩
      · obtain ⟨hp_unused, hp_nz⟩ := findFirstFin_some hfind
        unfold GaussInv
        dsimp only
        set used' : Fin (D + 2) → Bool := Function.update st.used p true
        refine ⟨?_, ?_, ?_, ?_⟩
        · intro j i
          by_cases hj : used' j = false
          · simp only [hj, ite_true]
            rw [ih.1 j i, ih.1 p i, Finset.mul_sum, ← Finset.sum_sub_distrib]
            refine Finset.sum_congr rfl fun r _ => ?_
            ring
          · simp only [hj]
            exact ih.1 j i
        · intro k r hr_unused'
          have hr_ne_p : r ≠ p := by
            intro h_eq
            subst h_eq
            simp [used'] at hr_unused'
          have hr_unused : st.used r = false := by
            simpa [used', hr_ne_p] using hr_unused'
          have hcp_r : st.c p r = 0 := by
            rw [ih.2.1 p r hr_unused, if_neg hr_ne_p.symm]
          by_cases hk : used' k = false
          · simp only [hk, ↓reduceIte, hcp_r, mul_zero, sub_zero]
            exact ih.2.1 k r hr_unused
          · simp only [hk]
            exact ih.2.1 k r hr_unused
        · intro k i hk_unused' hi_lt
          have hk_ne_p : k ≠ p := by
            intro h_eq
            subst h_eq
            simp [used'] at hk_unused'
          have hk_unused : st.used k = false := by
            simpa [used', hk_ne_p] using hk_unused'
          simp only [hk_unused', ↓reduceIte]
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi_lt with hlt | heq
          · rw [ih.2.2.1 k i hk_unused hlt, ih.2.2.1 p i hp_unused hlt]
            ring
          · have hi_eq : i = i₀ := Fin.ext heq
            rw [hi_eq, div_mul_cancel₀ _ hp_nz, sub_self]
        · have hsub :
              Finset.univ.filter (fun k : Fin (D + 2) => used' k = true) ⊆
                insert p (Finset.univ.filter (fun k : Fin (D + 2) => st.used k = true)) := by
            intro k hk
            rw [Finset.mem_filter] at hk
            rw [Finset.mem_insert, Finset.mem_filter]
            by_cases hkp : k = p
            · exact Or.inl hkp
            · right
              refine ⟨Finset.mem_univ k, ?_⟩
              simpa [used', hkp] using hk.2
          calc
            (Finset.univ.filter (fun k : Fin (D + 2) => used' k = true)).card
                ≤ (insert p (Finset.univ.filter (fun k : Fin (D + 2) => st.used k = true))).card :=
              Finset.card_le_card hsub
            _ ≤ (Finset.univ.filter (fun k : Fin (D + 2) => st.used k = true)).card + 1 :=
              Finset.card_insert_le _ _
            _ ≤ n + 1 := Nat.add_le_add_right ih.2.2.2 1

theorem gaussRadonPoint_avoid_of_convex {D : ℕ}
    (pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D))
    (K : Set (EuclideanSpace ℝ (Fin D)))
    (hK : Convex ℝ K)
    (hr : gaussRadonPoint pts ∉ K) :
    ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∉ K ∧ pts b ∉ K := by
  classical
  set st := gaussFinalState pts
  have hinv : GaussInv pts (D + 1) st := gaussRunRows_inv pts (D + 1) le_rfl
  have hex_unused : ∃ k : Fin (D + 2), st.used k = false := by
    by_contra hall
    push_neg at hall
    have heq_univ :
        Finset.univ.filter (fun k : Fin (D + 2) => st.used k = true) = Finset.univ := by
      ext k
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      cases h : st.used k
      · exact False.elim (hall k h)
      · simp
    have hcard := hinv.2.2.2
    rw [heq_univ, Finset.card_univ, Fintype.card_fin] at hcard
    omega
  rcases hfind : findFirstFin (fun k : Fin (D + 2) => st.used k = false) with _ | k_star
  · exfalso
    obtain ⟨k, hk⟩ := hex_unused
    exact findFirstFin_none hfind k hk
  · have hk_unused : st.used k_star = false := findFirstFin_some hfind
    let lam : Fin (D + 2) → ℝ := fun r => st.c k_star r
    have hlam_kstar : lam k_star = 1 := by
      dsimp [lam]
      rw [hinv.2.1 k_star k_star hk_unused, if_pos rfl]
    have hv_zero : ∀ i : Fin (D + 1), st.v k_star i = 0 :=
      fun i => hinv.2.2.1 k_star i hk_unused i.isLt
    have hsum_lam : ∑ r : Fin (D + 2), lam r = 0 := by
      let i_last : Fin (D + 1) := ⟨D, by omega⟩
      have h0 := hv_zero i_last
      rw [hinv.1 k_star i_last] at h0
      have haff : ∀ r : Fin (D + 2), affCol pts r i_last = 1 := by
        intro r
        simp [affCol, i_last]
      simpa [lam, haff] using h0
    have hsum_pts : ∀ coord : Fin D,
        ∑ r : Fin (D + 2), UL.euclideanCoord (pts r) coord * lam r = 0 := by
      intro coord
      let i_c : Fin (D + 1) := ⟨coord.val, by omega⟩
      have h0 := hv_zero i_c
      rw [hinv.1 k_star i_c] at h0
      have haff : ∀ r : Fin (D + 2), affCol pts r i_c = UL.euclideanCoord (pts r) coord := by
        intro r
        simp [affCol, i_c, coord.isLt]
      simpa [lam, haff] using h0

    let S_pos : Finset (Fin (D + 2)) := Finset.univ.filter (fun r => 0 < lam r)
    let S_neg : Finset (Fin (D + 2)) := Finset.univ.filter (fun r => lam r < 0)
    have hk_in_pos : k_star ∈ S_pos := by
      simp [S_pos, hlam_kstar]
    have hS_pos_ne : S_pos.Nonempty := ⟨k_star, hk_in_pos⟩
    let posSum : ℝ := ∑ r : Fin (D + 2), if 0 < lam r then lam r else 0
    have hposSum_eq : posSum = ∑ r ∈ S_pos, lam r := by
      dsimp [posSum, S_pos]
      rw [Finset.sum_filter]
    have hposSum_pos : 0 < posSum := by
      rw [hposSum_eq]
      exact Finset.sum_pos (fun r hr => (Finset.mem_filter.mp hr).2) hS_pos_ne
    have hsplit_val : ∀ f : Fin (D + 2) → ℝ,
        ∑ r : Fin (D + 2), lam r * f r =
          (∑ r ∈ S_pos, lam r * f r) + (∑ r ∈ S_neg, lam r * f r) := by
      intro f
      have hpt : ∀ r : Fin (D + 2),
          lam r * f r =
            (if 0 < lam r then lam r * f r else 0) +
            (if lam r < 0 then lam r * f r else 0) := by
        intro r
        by_cases h1 : 0 < lam r
        · have h2 : ¬ lam r < 0 := by linarith
          simp [h1, h2]
        · by_cases h2 : lam r < 0
          · simp [h1, h2]
          · have h0 : lam r = 0 := by linarith
            simp [h0]
      rw [Finset.sum_congr rfl (fun r _ => hpt r), Finset.sum_add_distrib, ← Finset.sum_filter, ← Finset.sum_filter]
    have hnegSum_eq : ∑ r ∈ S_neg, (-lam r) = posSum := by
      have h := hsplit_val (fun _ => 1)
      simp only [mul_one] at h
      rw [hsum_lam, ← hposSum_eq] at h
      have : ∑ r ∈ S_neg, (-lam r) = - ∑ r ∈ S_neg, lam r := by rw [Finset.sum_neg_distrib]
      linarith
    have hS_neg_ne : S_neg.Nonempty := by
      by_contra hemp
      rw [Finset.not_nonempty_iff_eq_empty.mp hemp, Finset.sum_empty] at hnegSum_eq
      linarith

    have hrad_eq_pos :
        gaussRadonPoint pts = ∑ r ∈ S_pos, (lam r / posSum) • pts r := by
      unfold gaussRadonPoint
      change WithLp.toLp 2 _ = _
      rw [hfind]
      dsimp only
      apply (WithLp.linearEquiv 2 ℝ (Fin D → ℝ)).injective
      ext coord
      rw [map_sum]
      simp only [Finset.sum_apply, map_smul, Pi.smul_apply, smul_eq_mul]
      change (∑ r : Fin (D + 2),
          if 0 < lam r then (lam r / posSum) * UL.euclideanCoord (pts r) coord else 0) =
        ∑ r ∈ S_pos, (lam r / posSum) * UL.euclideanCoord (pts r) coord
      rw [← Finset.sum_filter]

    have hrad_eq_neg :
        gaussRadonPoint pts = ∑ r ∈ S_neg, ((-lam r) / posSum) • pts r := by
      rw [hrad_eq_pos]
      apply (WithLp.linearEquiv 2 ℝ (Fin D → ℝ)).injective
      ext coord
      rw [map_sum, map_sum]
      simp only [Finset.sum_apply, map_smul, Pi.smul_apply, smul_eq_mul]
      change (∑ r ∈ S_pos, (lam r / posSum) * UL.euclideanCoord (pts r) coord) =
        ∑ r ∈ S_neg, ((-lam r) / posSum) * UL.euclideanCoord (pts r) coord
      have h0 := hsplit_val (fun r => UL.euclideanCoord (pts r) coord)
      have hcomm : ∑ r : Fin (D + 2), lam r * UL.euclideanCoord (pts r) coord = 0 := by
        simpa [mul_comm] using hsum_pts coord
      rw [hcomm] at h0
      have hdiv :
          (∑ r ∈ S_pos, (lam r * UL.euclideanCoord (pts r) coord)) / posSum =
            (∑ r ∈ S_neg, ((-lam r) * UL.euclideanCoord (pts r) coord)) / posSum := by
        congr 1
        have hneg :
            ∑ r ∈ S_neg, ((-lam r) * UL.euclideanCoord (pts r) coord) =
              - ∑ r ∈ S_neg, (lam r * UL.euclideanCoord (pts r) coord) := by
          simp_rw [neg_mul]
          rw [Finset.sum_neg_distrib]
        linarith
      simpa only [Finset.sum_div, div_mul_eq_mul_div] using hdiv

    have hex_pos : ∃ a ∈ S_pos, pts a ∉ K := by
      by_contra hall
      push_neg at hall
      apply hr
      rw [hrad_eq_pos]
      refine hK.sum_mem (fun r hr_mem => ?_) ?_ (fun r hr_mem => hall r hr_mem)
      · exact div_nonneg (Finset.mem_filter.mp hr_mem).2.le hposSum_pos.le
      · rw [← Finset.sum_div, ← hposSum_eq, div_self hposSum_pos.ne']

    have hex_neg : ∃ b ∈ S_neg, pts b ∉ K := by
      by_contra hall
      push_neg at hall
      apply hr
      rw [hrad_eq_neg]
      refine hK.sum_mem (fun r hr_mem => ?_) ?_ (fun r hr_mem => hall r hr_mem)
      · have hlt : lam r < 0 := (Finset.mem_filter.mp hr_mem).2
        exact div_nonneg (by linarith) hposSum_pos.le
      · rw [← Finset.sum_div, hnegSum_eq, div_self hposSum_pos.ne']

    obtain ⟨a, ha_pos, ha_notK⟩ := hex_pos
    obtain ⟨b, hb_neg, hb_notK⟩ := hex_neg
    refine ⟨a, b, ?_, ha_notK, hb_notK⟩
    intro hab
    subst hab
    have h1 : 0 < lam a := (Finset.mem_filter.mp ha_pos).2
    have h2 : lam a < 0 := (Finset.mem_filter.mp hb_neg).2
    linarith

end UL.Proof_cit_hpj19_thm18
