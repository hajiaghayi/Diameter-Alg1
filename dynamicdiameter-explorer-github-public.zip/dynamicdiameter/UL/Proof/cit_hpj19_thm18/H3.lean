import UL.Proof.cit_hpj19_thm18.H0
import UL.Proof.cit_hw87_halfspace_net.H1
import UL.Proof.cit_vc71_halfspace_uc.H1
set_option autoImplicit false

namespace UL.Proof_cit_hpj19_thm18

/-! ### Step 1: Bijection between flat bit arrays and Radon walk choice sequences -/

private theorem bitsFnToNat_injective : ∀ (q : ℕ), Function.Injective (bitsFnToNat q)
  | 0, f₁, f₂, _ => by
      funext i
      exact Fin.elim0 i
  | q + 1, f₁, f₂, h => by
      simp only [bitsFnToNat] at h
      have hlast : f₁ (Fin.last q) = f₂ (Fin.last q) := by
        cases h1 : f₁ (Fin.last q) <;> cases h2 : f₂ (Fin.last q)
        · rfl
        · simp [h1, h2] at h; omega
        · simp [h1, h2] at h; omega
        · rfl
      have hinit_nat :
          bitsFnToNat q (fun i => f₁ i.castSucc) = bitsFnToNat q (fun i => f₂ i.castSucc) := by
        rw [hlast] at h
        omega
      have hinit := bitsFnToNat_injective q hinit_nat
      funext j
      refine Fin.lastCases ?_ (fun i => ?_) j
      · exact hlast
      · exact congr_fun hinit i

private theorem bitsFnToFin_injective (q : ℕ) : Function.Injective (bitsFnToFin q) := by
  intro f₁ f₂ h
  exact bitsFnToNat_injective q (congr_arg Fin.val h)

private abbrev StepChoice (D M : ℕ) : Type :=
  (Fin (D + 2) → Fin M) × Fin M

private theorem extractWalkChoices_injective (D q L : ℕ) :
    Function.Injective (extractWalkChoices D q L) := by
  intro b₁ b₂ h
  funext idx
  have hmul_pos : 0 < L * (D + 3) * q := Nat.zero_lt_of_lt idx.isLt
  have hq_pos : 0 < q := by
    by_contra hq
    have hq0 : q = 0 := by omega
    simp [hq0] at hmul_pos
  let stride : ℕ := (D + 3) * q
  have hstride_pos : 0 < stride := Nat.mul_pos (by omega) hq_pos
  let s_val : ℕ := idx.val / stride
  let rem : ℕ := idx.val % stride
  let slot_val : ℕ := rem / q
  let bit_val : ℕ := rem % q
  have hs_lt : s_val < L := by
    have hlt : idx.val < L * stride := by
      have hidx := idx.isLt
      dsimp [stride]
      linarith
    exact (Nat.div_lt_iff_lt_mul hstride_pos).mpr hlt
  have hrem_lt : rem < (D + 3) * q := Nat.mod_lt idx.val hstride_pos
  have hslot_lt : slot_val < D + 3 := (Nat.div_lt_iff_lt_mul hq_pos).mpr hrem_lt
  have hbit_lt : bit_val < q := Nat.mod_lt rem hq_pos
  have hdecomp1 : s_val * stride + rem = idx.val := by
    dsimp only [s_val, rem]
    rw [mul_comm, Nat.div_add_mod]
  have hdecomp2 : slot_val * q + bit_val = rem := by
    dsimp only [slot_val, bit_val]
    rw [mul_comm, Nat.div_add_mod]
  have hdecomp : s_val * ((D + 3) * q) + slot_val * q + bit_val = idx.val := by
    calc
      s_val * ((D + 3) * q) + slot_val * q + bit_val
          = s_val * stride + (slot_val * q + bit_val) := by dsimp [stride]; ring
      _ = s_val * stride + rem := by rw [hdecomp2]
      _ = idx.val := hdecomp1
  let step : Fin L := ⟨s_val, hs_lt⟩
  let bit : Fin q := ⟨bit_val, hbit_lt⟩
  have hstep := congr_fun h step
  by_cases hslot : slot_val < D + 2
  · let a : Fin (D + 2) := ⟨slot_val, hslot⟩
    have ha := congr_fun (congr_arg Prod.fst hstep) a
    simp only [extractWalkChoices] at ha
    have hf := bitsFnToFin_injective q ha
    have hb := congr_fun hf bit
    have hfin : (⟨step.val * ((D + 3) * q) + a.val * q + bit.val,
        bitFlatIndex_lt step ⟨a.val, by omega⟩ bit⟩ : Fin (L * (D + 3) * q)) = idx := by
      ext
      exact hdecomp
    simpa [hfin] using hb
  · have hslot_eq : slot_val = D + 2 := by omega
    have ha := congr_arg Prod.snd hstep
    simp only [extractWalkChoices] at ha
    have hf := bitsFnToFin_injective q ha
    have hb := congr_fun hf bit
    have hfin : (⟨step.val * ((D + 3) * q) + (D + 2) * q + bit.val,
        bitFlatIndex_lt step ⟨D + 2, by omega⟩ bit⟩ : Fin (L * (D + 3) * q)) = idx := by
      ext
      simp only [step, bit]
      rw [← hslot_eq]
      exact hdecomp
    simpa [hfin] using hb

private theorem card_stepChoice (D M : ℕ) :
    Fintype.card (StepChoice D M) = M ^ (D + 3) := by
  simp only [StepChoice, Fintype.card_prod, Fintype.card_fun, Fintype.card_fin]
  rw [← pow_succ]

private theorem card_walkChoices (D q L : ℕ) :
    Fintype.card (Fin L → StepChoice D (2 ^ q)) = 2 ^ (L * (D + 3) * q) := by
  rw [Fintype.card_fun, card_stepChoice, Fintype.card_fin]
  rw [← pow_mul, ← pow_mul]
  congr 1
  ring

private noncomputable def extractWalkChoicesEquiv (D q L : ℕ) :
    (Fin (L * (D + 3) * q) → Bool) ≃ (Fin L → StepChoice D (2 ^ q)) :=
  Equiv.ofBijective (extractWalkChoices D q L)
    ((Fintype.bijective_iff_injective_and_card _).mpr
      ⟨extractWalkChoices_injective D q L, by
        rw [Fintype.card_fun, Fintype.card_bool, Fintype.card_fin, card_walkChoices]⟩)

open Classical in
private theorem card_goodWalkBits_eq_choices (D q L : ℕ)
    (T₀ : Fin (2 ^ q) → EuclideanSpace ℝ (Fin D))
    (Pred : EuclideanSpace ℝ (Fin D) → Prop) :
    (Finset.univ.filter (fun bits : Fin (L * (D + 3) * q) → Bool =>
      Pred (radonWalkOutput D q L T₀ bits))).card =
    (Finset.univ.filter (fun ch : Fin L → StepChoice D (2 ^ q) =>
      Pred (radonWalkChoices gaussRadonPoint T₀ L ch ⟨0, Nat.two_pow_pos q⟩))).card := by
  let e := extractWalkChoicesEquiv D q L
  refine Finset.card_bij (fun bits _ => e bits) ?_ ?_ ?_
  · intro bits hbits
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, radonWalkOutput,
      e, extractWalkChoicesEquiv, Equiv.ofBijective_apply] at hbits ⊢
    exact hbits
  · intro b₁ _ b₂ _ heq
    exact e.injective heq
  · intro ch hch
    refine ⟨e.symm ch, ?_, e.apply_symm_apply ch⟩
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, radonWalkOutput] at hch ⊢
    have h_app : extractWalkChoices D q L (e.symm ch) = ch := e.apply_symm_apply ch
    simpa [h_app] using hch

/-! ### Step 2: Canonical finite bad-halfspace trace family and centerpoint criterion -/

private theorem convex_compl_of_isClosedHalfspace {D : ℕ}
    {H : Set (EuclideanSpace ℝ (Fin D))} (hH : UL.IsClosedHalfspace H) :
    Convex ℝ Hᶜ := by
  rcases hH with ⟨v, _, β, rfl⟩
  intro x hx y hy a b ha hb hab
  simp only [Set.mem_compl_iff, Set.mem_setOf_eq, not_le] at hx hy ⊢
  rw [inner_add_right, inner_smul_right, inner_smul_right]
  rcases ha.eq_or_lt with rfl | ha_pos
  · simp only [zero_add] at hab
    subst hab
    linarith
  · have hax : a * β < a * inner ℝ v x := mul_lt_mul_of_pos_left hx ha_pos
    have hby : b * β ≤ b * inner ℝ v y := mul_le_mul_of_nonneg_left hy.le hb
    have habβ : a * β + b * β = β := by rw [← add_mul, hab, one_mul]
    linarith

private theorem exists_closedHalfspace_mem {D : ℕ} (hD : 1 ≤ D)
    (z : EuclideanSpace ℝ (Fin D)) :
    ∃ H : Set (EuclideanSpace ℝ (Fin D)), UL.IsClosedHalfspace H ∧ z ∈ H := by
  let i₀ : Fin D := ⟨0, by omega⟩
  let v₀ : EuclideanSpace ℝ (Fin D) := EuclideanSpace.single i₀ (1 : ℝ)
  have hv₀ : v₀ ≠ 0 := by simp [v₀]
  exact ⟨{x | inner ℝ v₀ x ≤ inner ℝ v₀ z}, ⟨v₀, hv₀, inner ℝ v₀ z, rfl⟩,
    Set.mem_setOf.mpr le_rfl⟩

open Classical in
private noncomputable def countU {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (T : Fin M → EuclideanSpace ℝ (Fin D)) : ℕ :=
  (Finset.univ.filter (fun j : Fin M => T j ∈ U)).card

open Classical in
private theorem not_mem_of_countU_eq_zero {D M : ℕ}
    {U : Set (EuclideanSpace ℝ (Fin D))}
    {T : Fin M → EuclideanSpace ℝ (Fin D)}
    (h0 : countU U T = 0) (j : Fin M) : T j ∉ U := by
  unfold countU at h0
  rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff] at h0
  exact h0 (Finset.mem_univ j)

open Classical in
private noncomputable def badTraces {D M : ℕ}
    (T₀ : Fin M → EuclideanSpace ℝ (Fin D)) (α : ℝ) : Finset (Finset (Fin M)) :=
  Finset.univ.filter (fun B : Finset (Fin M) =>
    (B.card : ℝ) < 2 * α * (M : ℝ) ∧
    ∃ H : Set (EuclideanSpace ℝ (Fin D)),
      UL.IsClosedHalfspace H ∧ B = Finset.univ.filter (fun j : Fin M => T₀ j ∈ H))

private noncomputable def traceHull {D M : ℕ}
    (T₀ : Fin M → EuclideanSpace ℝ (Fin D)) (B : Finset (Fin M)) :
    Set (EuclideanSpace ℝ (Fin D)) :=
  convexHull ℝ (T₀ '' ((Finset.univ \ B : Finset (Fin M)) : Set (Fin M)))

open Classical in
private theorem countU_compl_traceHull_le {D M : ℕ}
    (T₀ : Fin M → EuclideanSpace ℝ (Fin D)) (B : Finset (Fin M)) :
    countU (traceHull T₀ B)ᶜ T₀ ≤ B.card := by
  unfold countU
  refine Finset.card_le_card (fun j hj => ?_)
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, Set.mem_compl_iff] at hj
  by_contra hjB
  apply hj
  exact subset_convexHull ℝ _ ⟨j, Finset.mem_sdiff.mpr ⟨Finset.mem_univ j, hjB⟩, rfl⟩

open Classical in
private theorem isCenterpoint_of_forall_badTraces {D M : ℕ} (hD : 1 ≤ D)
    {ι : Type*} [Fintype ι]
    (Q : ι → EuclideanSpace ℝ (Fin D))
    (α : ℝ) (ω₀ : Fin M → ι)
    (hGood : GoodInitialSample Q α ω₀)
    {z : EuclideanSpace ℝ (Fin D)}
    (hz : ∀ B ∈ badTraces (fun j => Q (ω₀ j)) α,
      z ∈ traceHull (fun j => Q (ω₀ j)) B) :
    UL.IsCenterpoint α Q z := by
  let T₀ : Fin M → EuclideanSpace ℝ (Fin D) := fun j => Q (ω₀ j)
  have h_half : ∀ H : Set (EuclideanSpace ℝ (Fin D)),
      UL.IsClosedHalfspace H → z ∈ H →
      α * (Fintype.card ι : ℝ) ≤ (UL.pointCount Q H : ℝ) := by
    intro H hH hzH
    by_contra! h_lt
    have h_emp : (UL.pointCount T₀ H : ℝ) < 2 * α * (M : ℝ) := hGood H hH h_lt
    let B : Finset (Fin M) := Finset.univ.filter (fun j : Fin M => T₀ j ∈ H)
    have hB_card : B.card = UL.pointCount T₀ H := rfl
    have hB_mem : B ∈ badTraces T₀ α := by
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ B, ?_, H, hH, rfl⟩
      rwa [hB_card]
    have hzK : z ∈ traceHull T₀ B := hz B hB_mem
    have hK_sub : traceHull T₀ B ⊆ Hᶜ := by
      refine convexHull_min ?_ (convex_compl_of_isClosedHalfspace hH)
      rintro x ⟨j, hj, rfl⟩
      have hj_not_B : j ∉ B := (Finset.mem_sdiff.mp (Finset.mem_coe.mp hj)).2
      have hj_not_H : T₀ j ∉ H := by
        simpa [B] using hj_not_B
      exact hj_not_H
    exact hK_sub hzK hzH
  obtain ⟨H₀, hH₀_closed, hzH₀⟩ := exists_closedHalfspace_mem hD z
  let A : Set ℕ := {n : ℕ | ∃ H : Set (EuclideanSpace ℝ (Fin D)),
    UL.IsClosedHalfspace H ∧ z ∈ H ∧ n = UL.pointCount Q H}
  have hA_ne : A.Nonempty := ⟨UL.pointCount Q H₀, H₀, hH₀_closed, hzH₀, rfl⟩
  have hsInf_mem : UL.halfspaceDepth Q z ∈ A := Nat.sInf_mem hA_ne
  rcases hsInf_mem with ⟨H₁, hH₁_closed, hzH₁, h_eq⟩
  unfold UL.IsCenterpoint
  rw [h_eq]
  exact h_half H₁ hH₁_closed hzH₁

/-! ### Step 3: 1D Random walk potentials for a fixed convex set complement `U` -/

open Classical in
private noncomputable def badIdx {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (T : Fin M → EuclideanSpace ℝ (Fin D)) : Finset (Fin (D + 2) → Fin M) :=
  Finset.univ.filter (fun idx => gaussRadonPoint (fun a => T (idx a)) ∈ U)

private theorem two_mul_card_pairs_lt_le (n : ℕ) :
    2 * (Finset.univ.filter (fun ab : Fin n × Fin n => ab.1 < ab.2)).card ≤ n ^ 2 := by
  let P_lt : Finset (Fin n × Fin n) := Finset.univ.filter (fun ab => ab.1 < ab.2)
  let P_gt : Finset (Fin n × Fin n) := Finset.univ.filter (fun ab => ab.2 < ab.1)
  have hdisj : Disjoint P_lt P_gt := by
    rw [Finset.disjoint_left]
    intro ab h1 h2
    simp only [P_lt, P_gt, Finset.mem_filter, Finset.mem_univ, true_and] at h1 h2
    exact lt_asymm h1 h2
  have hcard_eq : P_lt.card = P_gt.card := by
    refine Finset.card_bij (fun ab _ => (ab.2, ab.1)) ?_ ?_ ?_
    · intro ab hab
      simp only [P_lt, P_gt, Finset.mem_filter, Finset.mem_univ, true_and] at hab ⊢
      exact hab
    · intro ab₁ _ ab₂ _ h
      ext <;> simp_all
    · intro ab hab
      refine ⟨(ab.2, ab.1), ?_, by simp⟩
      simp only [P_lt, P_gt, Finset.mem_filter, Finset.mem_univ, true_and] at hab ⊢
      exact hab
  have hunion_le : (P_lt ∪ P_gt).card ≤ n ^ 2 := by
    calc
      (P_lt ∪ P_gt).card ≤ (Finset.univ : Finset (Fin n × Fin n)).card :=
        Finset.card_le_card (Finset.subset_univ _)
      _ = n * n := by simp
      _ = n ^ 2 := (sq n).symm
  rw [Finset.card_union_of_disjoint hdisj, ← hcard_eq] at hunion_le
  change 2 * P_lt.card ≤ n ^ 2
  omega

open Classical in
private theorem card_pairHits_le {D M : ℕ}
    (S_U : Finset (Fin M)) (a b : Fin (D + 2)) (hab : a ≠ b) :
    (Finset.univ.filter (fun idx : Fin (D + 2) → Fin M =>
      idx a ∈ S_U ∧ idx b ∈ S_U)).card ≤ S_U.card ^ 2 * M ^ D := by
  let F_ab := Finset.univ.filter (fun idx : Fin (D + 2) → Fin M => idx a ∈ S_U ∧ idx b ∈ S_U)
  let R_set : Finset (Fin (D + 2)) :=
    Finset.univ.filter (fun c : Fin (D + 2) => c ≠ a ∧ c ≠ b)
  have hR_card : R_set.card = D := by
    have hdisj : Disjoint R_set ({a, b} : Finset (Fin (D + 2))) := by
      rw [Finset.disjoint_left]
      intro c hc hcab
      simp only [R_set, Finset.mem_filter, Finset.mem_univ, true_and,
        Finset.mem_insert, Finset.mem_singleton] at hc hcab
      rcases hcab with rfl | rfl <;> tauto
    have hunion : R_set ∪ ({a, b} : Finset (Fin (D + 2))) = Finset.univ := by
      ext c
      simp only [R_set, Finset.mem_union, Finset.mem_filter, Finset.mem_univ, true_and,
        Finset.mem_insert, Finset.mem_singleton]
      tauto
    have h1 := Finset.card_union_of_disjoint hdisj
    rw [hunion, Finset.card_univ, Fintype.card_fin, Finset.card_pair hab] at h1
    omega
  let φ_inj : {idx : Fin (D + 2) → Fin M // idx ∈ F_ab} →
      S_U × S_U × (R_set → Fin M) :=
    fun ⟨idx, hidx⟩ =>
      have hmem := (Finset.mem_filter.mp hidx).2
      (⟨idx a, hmem.1⟩, ⟨idx b, hmem.2⟩, fun c => idx c.1)
  have hinj : Function.Injective φ_inj := by
    rintro ⟨idx₁, h₁⟩ ⟨idx₂, h₂⟩ heq
    simp only [φ_inj, Prod.mk.injEq, Subtype.mk.injEq] at heq
    rcases heq with ⟨ha_eq, hb_eq, hrest⟩
    refine Subtype.ext (funext fun c => ?_)
    by_cases hca : c = a
    · subst hca; exact ha_eq
    · by_cases hcb : c = b
      · subst hcb; exact hb_eq
      · have hcR : c ∈ R_set := Finset.mem_filter.mpr ⟨Finset.mem_univ c, hca, hcb⟩
        exact congr_fun hrest ⟨c, hcR⟩
  have hle := Fintype.card_le_of_injective φ_inj hinj
  simp only [Fintype.card_coe, Fintype.card_prod, Fintype.card_fun, Fintype.card_fin,
    hR_card] at hle
  calc
    F_ab.card ≤ S_U.card * (S_U.card * M ^ D) := hle
    _ = S_U.card ^ 2 * M ^ D := by ring

open Classical in
private theorem two_mul_card_badIdx_le {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (hradU : ∀ pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D),
      gaussRadonPoint pts ∈ U → ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∈ U ∧ pts b ∈ U)
    (T : Fin M → EuclideanSpace ℝ (Fin D)) :
    2 * (badIdx U T).card ≤ (D + 2) ^ 2 * (countU U T) ^ 2 * M ^ D := by
  let S_U : Finset (Fin M) := Finset.univ.filter (fun j : Fin M => T j ∈ U)
  let P_lt : Finset (Fin (D + 2) × Fin (D + 2)) :=
    Finset.univ.filter (fun ab => ab.1 < ab.2)
  have hsub : badIdx U T ⊆ P_lt.biUnion (fun ab =>
      Finset.univ.filter (fun idx : Fin (D + 2) → Fin M => idx ab.1 ∈ S_U ∧ idx ab.2 ∈ S_U)) := by
    intro idx hidx
    simp only [badIdx, Finset.mem_filter, Finset.mem_univ, true_and] at hidx
    obtain ⟨a, b, hab, haU, hbU⟩ := hradU (fun x => T (idx x)) hidx
    rcases lt_or_gt_of_ne hab with hlt | hgt
    · refine Finset.mem_biUnion.mpr ⟨(a, b), ?_, ?_⟩
      · simp [P_lt, hlt]
      · simp [S_U, haU, hbU]
    · refine Finset.mem_biUnion.mpr ⟨(b, a), ?_, ?_⟩
      · simp [P_lt, hgt]
      · simp [S_U, hbU, haU]
  have h1 : (badIdx U T).card ≤ P_lt.card * (S_U.card ^ 2 * M ^ D) := by
    calc
      (badIdx U T).card ≤ (P_lt.biUnion (fun ab =>
          Finset.univ.filter (fun idx : Fin (D + 2) → Fin M =>
            idx ab.1 ∈ S_U ∧ idx ab.2 ∈ S_U))).card := Finset.card_le_card hsub
      _ ≤ ∑ ab ∈ P_lt, (Finset.univ.filter (fun idx : Fin (D + 2) → Fin M =>
            idx ab.1 ∈ S_U ∧ idx ab.2 ∈ S_U)).card := Finset.card_biUnion_le
      _ ≤ ∑ _ab ∈ P_lt, (S_U.card ^ 2 * M ^ D) := by
          refine Finset.sum_le_sum fun ab hab => ?_
          have hlt : ab.1 < ab.2 := (Finset.mem_filter.mp hab).2
          exact card_pairHits_le S_U ab.1 ab.2 (ne_of_lt hlt)
      _ = P_lt.card * (S_U.card ^ 2 * M ^ D) := by simp
  have h2 : 2 * P_lt.card ≤ (D + 2) ^ 2 := two_mul_card_pairs_lt_le (D + 2)
  change 2 * (badIdx U T).card ≤ (D + 2) ^ 2 * S_U.card ^ 2 * M ^ D
  calc
    2 * (badIdx U T).card ≤ 2 * (P_lt.card * (S_U.card ^ 2 * M ^ D)) :=
      Nat.mul_le_mul_left 2 h1
    _ = (2 * P_lt.card) * (S_U.card ^ 2 * M ^ D) := by ring
    _ ≤ (D + 2) ^ 2 * (S_U.card ^ 2 * M ^ D) := Nat.mul_le_mul_right _ h2
    _ = (D + 2) ^ 2 * S_U.card ^ 2 * M ^ D := by ring

open Classical in
private theorem countU_radonWalkStep_eq_zero_of_zero {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (hradU : ∀ pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D),
      gaussRadonPoint pts ∈ U → ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∈ U ∧ pts b ∈ U)
    (T : Fin M → EuclideanSpace ℝ (Fin D))
    (hk0 : countU U T = 0)
    (c : StepChoice D M) :
    countU U (radonWalkStep gaussRadonPoint T c) = 0 := by
  have hT_not_U : ∀ j : Fin M, T j ∉ U := by
    intro j hjU
    have hj_mem : j ∈ Finset.univ.filter (fun i : Fin M => T i ∈ U) := by simp [hjU]
    have hpos : 0 < countU U T := Finset.card_pos.mpr ⟨j, hj_mem⟩
    omega
  have hr_not_U : gaussRadonPoint (fun a => T (c.1 a)) ∉ U := by
    intro hrU
    obtain ⟨a, _, _, haU, _⟩ := hradU _ hrU
    exact hT_not_U (c.1 a) haU
  unfold countU radonWalkStep
  rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
  intro j _
  by_cases hj : j = c.2
  · subst hj; simpa using hr_not_U
  · simpa [Function.update_of_ne hj] using hT_not_U j

open Classical in
private theorem sum_update_countU {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (T : Fin M → EuclideanSpace ℝ (Fin D))
    (r : EuclideanSpace ℝ (Fin D))
    (g : ℕ → ℝ) :
    ∑ rep : Fin M, g (countU U (Function.update T rep r)) =
      if r ∈ U then
        (countU U T : ℝ) * g (countU U T) + ((M - countU U T : ℕ) : ℝ) * g (countU U T + 1)
      else
        (countU U T : ℝ) * g (countU U T - 1) + ((M - countU U T : ℕ) : ℝ) * g (countU U T) := by
  let S : Finset (Fin M) := Finset.univ.filter (fun j : Fin M => T j ∈ U)
  let Sc : Finset (Fin M) := Finset.univ.filter (fun j : Fin M => T j ∉ U)
  have hdisj : Disjoint S Sc := by
    rw [Finset.disjoint_left]
    intro j h1 h2
    simp only [S, Sc, Finset.mem_filter, Finset.mem_univ, true_and] at h1 h2
    exact h2 h1
  have hunion : S ∪ Sc = Finset.univ := by
    ext j
    simp only [S, Sc, Finset.mem_union, Finset.mem_filter, Finset.mem_univ, true_and]
    tauto
  have hSc_card : Sc.card = M - S.card := by
    have h := Finset.card_union_of_disjoint hdisj
    rw [hunion, Finset.card_univ, Fintype.card_fin] at h
    omega
  rw [← hunion, Finset.sum_union hdisj]
  by_cases hr : r ∈ U
  · rw [if_pos hr]
    have h1 : ∀ rep ∈ S, countU U (Function.update T rep r) = S.card := by
      intro rep hrep
      have hrepU : T rep ∈ U := (Finset.mem_filter.mp hrep).2
      unfold countU
      congr 1
      ext j
      by_cases hj : j = rep
      · subst hj; simp [S, hr, hrepU]
      · simp [S, Function.update_of_ne hj]
    have h2 : ∀ rep ∈ Sc, countU U (Function.update T rep r) = S.card + 1 := by
      intro rep hrep
      have hrep_not_S : rep ∉ S := Finset.disjoint_right.mp hdisj hrep
      let S' := Finset.univ.filter (fun j : Fin M => Function.update T rep r j ∈ U)
      have hS'_eq : S' = S ∪ {rep} := by
        ext j
        by_cases hj : j = rep
        · subst hj; simp [S', S, hr]
        · simp [S', S, hj]
      have hdisj' : Disjoint S ({rep} : Finset (Fin M)) :=
        Finset.disjoint_singleton_right.mpr hrep_not_S
      change S'.card = S.card + 1
      rw [hS'_eq, Finset.card_union_of_disjoint hdisj', Finset.card_singleton]
    rw [Finset.sum_congr rfl (fun rep hrep => congr_arg g (h1 rep hrep)),
        Finset.sum_congr rfl (fun rep hrep => congr_arg g (h2 rep hrep))]
    simp only [Finset.sum_const, nsmul_eq_mul, hSc_card]
    rfl
  · rw [if_neg hr]
    have h1 : ∀ rep ∈ S, countU U (Function.update T rep r) = S.card - 1 := by
      intro rep hrep
      have hrepU : T rep ∈ U := (Finset.mem_filter.mp hrep).2
      let S' := Finset.univ.filter (fun j : Fin M => Function.update T rep r j ∈ U)
      have hrep_not_S' : rep ∉ S' := by simp [S', hr]
      have hS'_union : S' ∪ ({rep} : Finset (Fin M)) = S := by
        ext j
        by_cases hj : j = rep
        · subst hj; simp [S', S, hr, hrepU]
        · simp [S', S, hj]
      have hdisj' : Disjoint S' ({rep} : Finset (Fin M)) :=
        Finset.disjoint_singleton_right.mpr hrep_not_S'
      have hcard := Finset.card_union_of_disjoint hdisj'
      rw [hS'_union, Finset.card_singleton] at hcard
      change S'.card = S.card - 1
      omega
    have h2 : ∀ rep ∈ Sc, countU U (Function.update T rep r) = S.card := by
      intro rep hrep
      have hrep_notU : T rep ∉ U := (Finset.mem_filter.mp hrep).2
      unfold countU
      congr 1
      ext j
      by_cases hj : j = rep
      · subst hj; simp [S, hr, hrep_notU]
      · simp [S, Function.update_of_ne hj]
    rw [Finset.sum_congr rfl (fun rep hrep => congr_arg g (h1 rep hrep)),
        Finset.sum_congr rfl (fun rep hrep => congr_arg g (h2 rep hrep))]
    simp only [Finset.sum_const, nsmul_eq_mul, hSc_card]
    rfl

open Classical in
private theorem sum_stepChoice_countU {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (T : Fin M → EuclideanSpace ℝ (Fin D))
    (g : ℕ → ℝ) :
    ∑ c : StepChoice D M, g (countU U (radonWalkStep gaussRadonPoint T c)) =
      (M : ℝ) ^ (D + 3) * g (countU U T) +
      ((badIdx U T).card : ℝ) * ((M : ℝ) - (countU U T : ℝ)) *
        (g (countU U T + 1) - g (countU U T)) -
      ((M : ℝ) ^ (D + 2) - ((badIdx U T).card : ℝ)) * (countU U T : ℝ) *
        (g (countU U T) - g (countU U T - 1)) := by
  let B_set := badIdx U T
  let Bc_set := Finset.univ.filter (fun idx : Fin (D + 2) → Fin M =>
    gaussRadonPoint (fun a => T (idx a)) ∉ U)
  have hdisj : Disjoint B_set Bc_set := by
    rw [Finset.disjoint_left]
    intro idx h1 h2
    simp only [B_set, Bc_set, badIdx, Finset.mem_filter, Finset.mem_univ, true_and] at h1 h2
    exact h2 h1
  have hunion : B_set ∪ Bc_set = Finset.univ := by
    ext idx
    simp only [B_set, Bc_set, badIdx, Finset.mem_union, Finset.mem_filter, Finset.mem_univ,
      true_and]
    tauto
  have hB_le : B_set.card ≤ M ^ (D + 2) := by
    calc
      B_set.card ≤ (Finset.univ : Finset (Fin (D + 2) → Fin M)).card :=
        Finset.card_le_card (Finset.subset_univ _)
      _ = M ^ (D + 2) := by simp
  have hBc_card : Bc_set.card = M ^ (D + 2) - B_set.card := by
    have h := Finset.card_union_of_disjoint hdisj
    rw [hunion, Finset.card_univ, Fintype.card_fun, Fintype.card_fin, Fintype.card_fin] at h
    omega
  have hk_le : countU U T ≤ M := by
    unfold countU
    calc
      (Finset.univ.filter (fun j : Fin M => T j ∈ U)).card ≤
          (Finset.univ : Finset (Fin M)).card := Finset.card_le_card (Finset.subset_univ _)
      _ = M := by simp
  rw [Fintype.sum_prod_type]
  simp_rw [radonWalkStep, sum_update_countU]
  rw [← hunion, Finset.sum_union hdisj]
  have hsumB : ∀ idx ∈ B_set,
      (if gaussRadonPoint (fun a => T (idx a)) ∈ U then
        (countU U T : ℝ) * g (countU U T) + ((M - countU U T : ℕ) : ℝ) * g (countU U T + 1)
      else
        (countU U T : ℝ) * g (countU U T - 1) + ((M - countU U T : ℕ) : ℝ) * g (countU U T)) =
      (countU U T : ℝ) * g (countU U T) + ((M - countU U T : ℕ) : ℝ) * g (countU U T + 1) := by
    intro idx hidx
    have hU : gaussRadonPoint (fun a => T (idx a)) ∈ U := (Finset.mem_filter.mp hidx).2
    rw [if_pos hU]
  have hsumBc : ∀ idx ∈ Bc_set,
      (if gaussRadonPoint (fun a => T (idx a)) ∈ U then
        (countU U T : ℝ) * g (countU U T) + ((M - countU U T : ℕ) : ℝ) * g (countU U T + 1)
      else
        (countU U T : ℝ) * g (countU U T - 1) + ((M - countU U T : ℕ) : ℝ) * g (countU U T)) =
      (countU U T : ℝ) * g (countU U T - 1) + ((M - countU U T : ℕ) : ℝ) * g (countU U T) := by
    intro idx hidx
    have hnotU : gaussRadonPoint (fun a => T (idx a)) ∉ U := (Finset.mem_filter.mp hidx).2
    rw [if_neg hnotU]
  rw [Finset.sum_congr rfl hsumB, Finset.sum_congr rfl hsumBc]
  simp only [Finset.sum_const, nsmul_eq_mul, hBc_card]
  rw [Nat.cast_sub hk_le, Nat.cast_sub hB_le, Nat.cast_pow]
  dsimp [B_set]
  rw [pow_succ]
  ring

private theorem drift_bounds_of_le_Mbar {D M : ℕ} (hD : 1 ≤ D)
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (hradU : ∀ pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D),
      gaussRadonPoint pts ∈ U → ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∈ U ∧ pts b ∈ U)
    (T : Fin M → EuclideanSpace ℝ (Fin D))
    (hk : countU U T ≤ M / (D + 2) ^ 2) :
    ((badIdx U T).card : ℝ) * ((M : ℝ) - (countU U T : ℝ)) ≤
        (1 / 2 : ℝ) * (countU U T : ℝ) * (M : ℝ) ^ (D + 2) ∧
      (5 / 6 : ℝ) * (countU U T : ℝ) * (M : ℝ) ^ (D + 2) ≤
        ((M : ℝ) ^ (D + 2) - ((badIdx U T).card : ℝ)) * (countU U T : ℝ) := by
  let k := countU U T
  have hk_mul : k * (D + 2) ^ 2 ≤ M :=
    (Nat.mul_le_mul_right _ hk).trans (Nat.div_mul_le_self M ((D + 2) ^ 2))
  have hk_mul_real : ((D : ℝ) + 2) ^ 2 * (k : ℝ) ≤ (M : ℝ) := by
    have : ((k * (D + 2) ^ 2 : ℕ) : ℝ) ≤ (M : ℝ) := by exact_mod_cast hk_mul
    push_cast at this
    linarith
  have h9k_le : 9 * (k : ℝ) ≤ (M : ℝ) := by
    have hD2 : (3 : ℝ) ≤ (D : ℝ) + 2 := by
      have : (1 : ℝ) ≤ (D : ℝ) := by exact_mod_cast hD
      linarith
    have h9 : (9 : ℝ) ≤ ((D : ℝ) + 2) ^ 2 := by nlinarith
    have hk_nn : (0 : ℝ) ≤ (k : ℝ) := Nat.cast_nonneg k
    nlinarith
  have hrad_nat := two_mul_card_badIdx_le U hradU T
  have hrad_real : 2 * ((badIdx U T).card : ℝ) ≤
      ((D : ℝ) + 2) ^ 2 * (k : ℝ) ^ 2 * (M : ℝ) ^ D := by
    have : ((2 * (badIdx U T).card : ℕ) : ℝ) ≤
        (((D + 2) ^ 2 * k ^ 2 * M ^ D : ℕ) : ℝ) := by exact_mod_cast hrad_nat
    push_cast at this
    exact this
  have h2B_le : 2 * ((badIdx U T).card : ℝ) ≤ (k : ℝ) * (M : ℝ) ^ (D + 1) := by
    have hkMD_nn : (0 : ℝ) ≤ (k : ℝ) * (M : ℝ) ^ D := by positivity
    calc
      2 * ((badIdx U T).card : ℝ)
          ≤ (((D : ℝ) + 2) ^ 2 * (k : ℝ)) * ((k : ℝ) * (M : ℝ) ^ D) := by linarith
      _ ≤ (M : ℝ) * ((k : ℝ) * (M : ℝ) ^ D) := mul_le_mul_of_nonneg_right hk_mul_real hkMD_nn
      _ = (k : ℝ) * (M : ℝ) ^ (D + 1) := by rw [pow_succ]; ring
  constructor
  · have hB_nn : (0 : ℝ) ≤ ((badIdx U T).card : ℝ) := Nat.cast_nonneg _
    have hk_nn : (0 : ℝ) ≤ (k : ℝ) := Nat.cast_nonneg k
    have hMk_le : (M : ℝ) - (k : ℝ) ≤ (M : ℝ) := by linarith
    calc
      ((badIdx U T).card : ℝ) * ((M : ℝ) - (k : ℝ))
          ≤ ((badIdx U T).card : ℝ) * (M : ℝ) := mul_le_mul_of_nonneg_left hMk_le hB_nn
      _ = (1 / 2 : ℝ) * (2 * ((badIdx U T).card : ℝ)) * (M : ℝ) := by ring
      _ ≤ (1 / 2 : ℝ) * ((k : ℝ) * (M : ℝ) ^ (D + 1)) * (M : ℝ) := by gcongr
      _ = (1 / 2 : ℝ) * (k : ℝ) * (M : ℝ) ^ (D + 2) := by rw [pow_succ]; ring
  · have h18B : 18 * ((badIdx U T).card : ℝ) ≤ (M : ℝ) ^ (D + 2) := by
      have hMD1_nn : (0 : ℝ) ≤ (M : ℝ) ^ (D + 1) := by positivity
      calc
        18 * ((badIdx U T).card : ℝ) = 9 * (2 * ((badIdx U T).card : ℝ)) := by ring
        _ ≤ 9 * ((k : ℝ) * (M : ℝ) ^ (D + 1)) := by linarith
        _ = (9 * (k : ℝ)) * (M : ℝ) ^ (D + 1) := by ring
        _ ≤ (M : ℝ) * (M : ℝ) ^ (D + 1) := mul_le_mul_of_nonneg_right h9k_le hMD1_nn
        _ = (M : ℝ) ^ (D + 2) := by rw [pow_succ]; ring
    have hk_nn : (0 : ℝ) ≤ (k : ℝ) := Nat.cast_nonneg k
    have h_sub :
        (5 / 6 : ℝ) * (M : ℝ) ^ (D + 2) ≤ (M : ℝ) ^ (D + 2) - ((badIdx U T).card : ℝ) := by
      have hMD2_nn : (0 : ℝ) ≤ (M : ℝ) ^ (D + 2) := by positivity
      linarith
    calc
      (5 / 6 : ℝ) * (k : ℝ) * (M : ℝ) ^ (D + 2)
          = ((5 / 6 : ℝ) * (M : ℝ) ^ (D + 2)) * (k : ℝ) := by ring
      _ ≤ ((M : ℝ) ^ (D + 2) - ((badIdx U T).card : ℝ)) * (k : ℝ) :=
            mul_le_mul_of_nonneg_right h_sub hk_nn

private theorem countU_radonWalkStep_le_succ {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (T : Fin M → EuclideanSpace ℝ (Fin D))
    (c : StepChoice D M) :
    countU U (radonWalkStep gaussRadonPoint T c) ≤ countU U T + 1 := by
  classical
  let S := Finset.univ.filter (fun j : Fin M => T j ∈ U)
  let S' := Finset.univ.filter (fun j : Fin M => radonWalkStep gaussRadonPoint T c j ∈ U)
  have hsub : S' ⊆ S ∪ {c.2} := by
    intro j hj
    simp only [S', radonWalkStep, Finset.mem_filter, Finset.mem_univ, true_and] at hj
    by_cases hjc : j = c.2
    · simp [hjc]
    · rw [Function.update_of_ne hjc] at hj
      simp [S, hjc, hj]
  calc
    S'.card ≤ (S ∪ {c.2}).card := Finset.card_le_card hsub
    _ ≤ S.card + ({c.2} : Finset (Fin M)).card := Finset.card_union_le _ _
    _ = S.card + 1 := by simp

private noncomputable def phi1 {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D))) (M_bar : ℕ)
    (T : Fin M → EuclideanSpace ℝ (Fin D)) (ov : Bool) : ℝ :=
  if ov then (3 / 2 : ℝ) ^ (M_bar + 1) else (3 / 2 : ℝ) ^ (countU U T)

private noncomputable def phi2 {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (T : Fin M → EuclideanSpace ℝ (Fin D)) (ov : Bool) : ℝ :=
  if ov then 0 else (countU U T : ℝ)

open Classical in
private theorem sum_step_phi1_le {D M : ℕ} (hD : 1 ≤ D)
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (hradU : ∀ pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D),
      gaussRadonPoint pts ∈ U → ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∈ U ∧ pts b ∈ U)
    (T : Fin M → EuclideanSpace ℝ (Fin D)) (ov : Bool)
    (hinv : ov = false → countU U T ≤ M / (D + 2) ^ 2) :
    ∑ c : StepChoice D M,
        phi1 U (M / (D + 2) ^ 2) (radonWalkStep gaussRadonPoint T c)
          (ov || decide (M / (D + 2) ^ 2 < countU U (radonWalkStep gaussRadonPoint T c))) ≤
      (M : ℝ) ^ (D + 3) * phi1 U (M / (D + 2) ^ 2) T ov := by
  cases ov with
  | true =>
      simp only [Bool.true_or, phi1, ite_true, Finset.sum_const, Finset.card_univ,
        card_stepChoice, nsmul_eq_mul, Nat.cast_pow, le_rfl]
  | false =>
      have hk_le : countU U T ≤ M / (D + 2) ^ 2 := hinv rfl
      simp only [Bool.false_or]
      rcases Nat.eq_zero_or_pos (countU U T) with hk0 | hk_pos
      · have hzero : ∀ c : StepChoice D M,
            phi1 U (M / (D + 2) ^ 2) (radonWalkStep gaussRadonPoint T c)
              (decide (M / (D + 2) ^ 2 < countU U (radonWalkStep gaussRadonPoint T c))) = 1 := by
          intro c
          have hc0 := countU_radonWalkStep_eq_zero_of_zero U hradU T hk0 c
          simp [phi1, hc0]
        simp_rw [hzero]
        simp only [Finset.sum_const, Finset.card_univ, card_stepChoice, nsmul_eq_mul,
          Nat.cast_pow, mul_one, phi1, Bool.false_eq_true, ↓reduceIte, hk0, pow_zero, le_rfl]
      · have hval_eq : ∀ c : StepChoice D M,
            phi1 U (M / (D + 2) ^ 2) (radonWalkStep gaussRadonPoint T c)
              (decide (M / (D + 2) ^ 2 < countU U (radonWalkStep gaussRadonPoint T c))) =
            (3 / 2 : ℝ) ^ (countU U (radonWalkStep gaussRadonPoint T c)) := by
          intro c
          unfold phi1
          split_ifs with hdec
          · have hgt : M / (D + 2) ^ 2 < countU U (radonWalkStep gaussRadonPoint T c) :=
              of_decide_eq_true hdec
            have hk'_le := countU_radonWalkStep_le_succ U T c
            have hk'_eq : countU U (radonWalkStep gaussRadonPoint T c) = M / (D + 2) ^ 2 + 1 := by
              omega
            rw [hk'_eq]
          · rfl
        simp_rw [hval_eq]
        rw [sum_stepChoice_countU U T (fun n => (3 / 2 : ℝ) ^ n)]
        obtain ⟨hA_plus, hA_minus⟩ := drift_bounds_of_le_Mbar hD U hradU T hk_le
        let k := countU U T
        have hk1 : k - 1 + 1 = k := by omega
        have hg_up :
            (3 / 2 : ℝ) ^ (k + 1) - (3 / 2 : ℝ) ^ k = (1 / 2 : ℝ) * (3 / 2 : ℝ) ^ k := by
          rw [pow_succ]; ring
        have hg_dn :
            (3 / 2 : ℝ) ^ k - (3 / 2 : ℝ) ^ (k - 1) = (1 / 3 : ℝ) * (3 / 2 : ℝ) ^ k := by
          obtain ⟨m, hm⟩ : ∃ m, k = m + 1 := ⟨k - 1, by omega⟩
          rw [hm, Nat.add_sub_cancel, pow_succ]
          ring
        change (M : ℝ) ^ (D + 3) * (3 / 2 : ℝ) ^ k +
            ((badIdx U T).card : ℝ) * ((M : ℝ) - (k : ℝ)) *
              ((3 / 2 : ℝ) ^ (k + 1) - (3 / 2 : ℝ) ^ k) -
            ((M : ℝ) ^ (D + 2) - ((badIdx U T).card : ℝ)) * (k : ℝ) *
              ((3 / 2 : ℝ) ^ k - (3 / 2 : ℝ) ^ (k - 1)) ≤
          (M : ℝ) ^ (D + 3) * phi1 U (M / (D + 2) ^ 2) T false
        simp only [phi1, Bool.false_eq_true, ↓reduceIte]
        change _ ≤ (M : ℝ) ^ (D + 3) * (3 / 2 : ℝ) ^ k
        rw [hg_up, hg_dn]
        have hpow_pos : (0 : ℝ) < (3 / 2 : ℝ) ^ k := by positivity
        have hkMD2_nn : (0 : ℝ) ≤ (k : ℝ) * (M : ℝ) ^ (D + 2) := by positivity
        have h_comb :
            ((badIdx U T).card : ℝ) * ((M : ℝ) - (k : ℝ)) * (1 / 2 : ℝ) -
              ((M : ℝ) ^ (D + 2) - ((badIdx U T).card : ℝ)) * (k : ℝ) * (1 / 3 : ℝ) ≤ 0 := by
          linarith
        nlinarith

open Classical in
private theorem sum_step_phi2_le {D M : ℕ} (hD : 1 ≤ D)
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (hradU : ∀ pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D),
      gaussRadonPoint pts ∈ U → ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∈ U ∧ pts b ∈ U)
    (T : Fin M → EuclideanSpace ℝ (Fin D)) (ov : Bool)
    (hinv : ov = false → countU U T ≤ M / (D + 2) ^ 2) :
    ∑ c : StepChoice D M,
        phi2 U (radonWalkStep gaussRadonPoint T c)
          (ov || decide (M / (D + 2) ^ 2 < countU U (radonWalkStep gaussRadonPoint T c))) ≤
      (M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ))) * phi2 U T ov := by
  cases ov with
  | true =>
      simp [phi2]
  | false =>
      have hk_le : countU U T ≤ M / (D + 2) ^ 2 := hinv rfl
      simp only [Bool.false_or]
      rcases Nat.eq_zero_or_pos (countU U T) with hk0 | hk_pos
      · have hzero : ∀ c : StepChoice D M,
            phi2 U (radonWalkStep gaussRadonPoint T c)
              (decide (M / (D + 2) ^ 2 < countU U (radonWalkStep gaussRadonPoint T c))) = 0 := by
          intro c
          have hc0 := countU_radonWalkStep_eq_zero_of_zero U hradU T hk0 c
          simp [phi2, hc0]
        simp_rw [hzero]
        simp [phi2, hk0]
      · have hle_cnt : ∀ c : StepChoice D M,
            phi2 U (radonWalkStep gaussRadonPoint T c)
              (decide (M / (D + 2) ^ 2 < countU U (radonWalkStep gaussRadonPoint T c))) ≤
            (countU U (radonWalkStep gaussRadonPoint T c) : ℝ) := by
          intro c
          unfold phi2
          split_ifs
          · exact Nat.cast_nonneg _
          · exact le_rfl
        have hM_pos : (0 : ℝ) < (M : ℝ) := by
          have hk_le_M : countU U T ≤ M := by
            unfold countU
            exact (Finset.card_le_card (Finset.subset_univ _)).trans_eq (by simp)
          have : 0 < M := lt_of_lt_of_le hk_pos hk_le_M
          exact_mod_cast this
        refine (Finset.sum_le_sum fun c _ => hle_cnt c).trans ?_
        rw [sum_stepChoice_countU U T (fun n => (n : ℝ))]
        obtain ⟨hA_plus, hA_minus⟩ := drift_bounds_of_le_Mbar hD U hradU T hk_le
        let k := countU U T
        have hg_up : ((k + 1 : ℕ) : ℝ) - (k : ℝ) = 1 := by push_cast; ring
        have hg_dn : (k : ℝ) - ((k - 1 : ℕ) : ℝ) = 1 := by
          have hk1 : (1 : ℕ) ≤ k := hk_pos
          rw [Nat.cast_sub hk1]
          ring
        change (M : ℝ) ^ (D + 3) * (k : ℝ) +
            ((badIdx U T).card : ℝ) * ((M : ℝ) - (k : ℝ)) * (((k + 1 : ℕ) : ℝ) - (k : ℝ)) -
            ((M : ℝ) ^ (D + 2) - ((badIdx U T).card : ℝ)) * (k : ℝ) *
              ((k : ℝ) - ((k - 1 : ℕ) : ℝ)) ≤
          (M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ))) * phi2 U T false
        simp only [phi2, Bool.false_eq_true, ↓reduceIte]
        change _ ≤ (M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ))) * (k : ℝ)
        rw [hg_up, hg_dn, mul_one, mul_one]
        have hrhs : (M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ))) * (k : ℝ) =
            (M : ℝ) ^ (D + 3) * (k : ℝ) - (1 / 3 : ℝ) * (k : ℝ) * (M : ℝ) ^ (D + 2) := by
          rw [pow_succ]
          field_simp [hM_pos.ne']
        rw [hrhs]
        linarith

private def finSnoc {α : Type*} {n : ℕ} (init : Fin n → α) (last : α) (j : Fin (n + 1)) : α :=
  if h : j.val < n then init ⟨j.val, h⟩ else last

private theorem finSnoc_castSucc {α : Type*} {n : ℕ}
    (init : Fin n → α) (last : α) (s : Fin n) :
    finSnoc init last s.castSucc = init s := by
  simp [finSnoc, s.isLt]

private theorem finSnoc_last {α : Type*} {n : ℕ}
    (init : Fin n → α) (last : α) :
    finSnoc init last (Fin.last n) = last := by
  simp [finSnoc]

private def finSnocEquiv (α : Type*) (n : ℕ) : (Fin n → α) × α ≃ (Fin (n + 1) → α) where
  toFun p := finSnoc p.1 p.2
  invFun ch := (fun s => ch s.castSucc, ch (Fin.last n))
  left_inv p := by
    rcases p with ⟨init, x⟩
    refine Prod.ext (funext fun s => ?_) ?_
    · exact finSnoc_castSucc init x s
    · exact finSnoc_last init x
  right_inv ch := by
    funext j
    refine Fin.lastCases ?_ (fun s => ?_) j
    · exact finSnoc_last _ _
    · exact finSnoc_castSucc _ _ s

open Classical in
private noncomputable def walkOv {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D))) (M_bar : ℕ)
    (T₀ : Fin M → EuclideanSpace ℝ (Fin D)) :
    (n : ℕ) → (Fin n → StepChoice D M) → Bool
  | 0, _ => decide (M_bar < countU U T₀)
  | n + 1, ch =>
      walkOv U M_bar T₀ n (fun s => ch s.castSucc) ||
        decide (M_bar < countU U (radonWalkChoices gaussRadonPoint T₀ (n + 1) ch))

open Classical in
private theorem walkOv_false_imp_le {D M : ℕ}
    (U : Set (EuclideanSpace ℝ (Fin D))) (M_bar : ℕ)
    (T₀ : Fin M → EuclideanSpace ℝ (Fin D)) :
    ∀ (n : ℕ) (ch : Fin n → StepChoice D M),
      walkOv U M_bar T₀ n ch = false →
      countU U (radonWalkChoices gaussRadonPoint T₀ n ch) ≤ M_bar
  | 0, _, hov => by
      simp only [walkOv, decide_eq_false_iff_not, not_lt] at hov
      exact hov
  | n + 1, ch, hov => by
      simp only [walkOv, Bool.or_eq_false_iff, decide_eq_false_iff_not, not_lt] at hov
      exact hov.2

open Classical in
private theorem sum_walk_phi1_le {D M : ℕ} (hD : 1 ≤ D)
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (hradU : ∀ pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D),
      gaussRadonPoint pts ∈ U → ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∈ U ∧ pts b ∈ U)
    (T₀ : Fin M → EuclideanSpace ℝ (Fin D)) :
    ∀ (n : ℕ),
      ∑ ch : Fin n → StepChoice D M,
          phi1 U (M / (D + 2) ^ 2) (radonWalkChoices gaussRadonPoint T₀ n ch)
            (walkOv U (M / (D + 2) ^ 2) T₀ n ch) ≤
        ((M : ℝ) ^ (D + 3)) ^ n *
          phi1 U (M / (D + 2) ^ 2) T₀ (decide (M / (D + 2) ^ 2 < countU U T₀))
  | 0 => by
      let f0 : Fin 0 → StepChoice D M := fun i => Fin.elim0 i
      have huniv : (Finset.univ : Finset (Fin 0 → StepChoice D M)) = {f0} := by
        ext f
        simp only [Finset.mem_univ, Finset.mem_singleton, true_iff]
        funext i
        exact Fin.elim0 i
      rw [huniv, Finset.sum_singleton, pow_zero, one_mul]
      rfl
  | n + 1 => by
      let M_bar := M / (D + 2) ^ 2
      rw [← Equiv.sum_comp (finSnocEquiv (StepChoice D M) n), Fintype.sum_prod_type]
      have hstep : ∀ (init : Fin n → StepChoice D M) (c : StepChoice D M),
          phi1 U M_bar
            (radonWalkChoices gaussRadonPoint T₀ (n + 1) (finSnocEquiv (StepChoice D M) n (init, c)))
            (walkOv U M_bar T₀ (n + 1) (finSnocEquiv (StepChoice D M) n (init, c))) =
          phi1 U M_bar
            (radonWalkStep gaussRadonPoint (radonWalkChoices gaussRadonPoint T₀ n init) c)
            (walkOv U M_bar T₀ n init ||
              decide (M_bar < countU U
                (radonWalkStep gaussRadonPoint (radonWalkChoices gaussRadonPoint T₀ n init) c))) := by
        intro init c
        have hinit_eq :
            (fun s : Fin n => (finSnocEquiv (StepChoice D M) n (init, c)) s.castSucc) = init := by
          funext s
          exact finSnoc_castSucc init c s
        have hlast_eq : (finSnocEquiv (StepChoice D M) n (init, c)) (Fin.last n) = c :=
          finSnoc_last init c
        simp only [radonWalkChoices, walkOv, hinit_eq, hlast_eq]
      have hinner : ∀ init : Fin n → StepChoice D M,
          ∑ c : StepChoice D M,
              phi1 U M_bar
                (radonWalkChoices gaussRadonPoint T₀ (n + 1)
                  (finSnocEquiv (StepChoice D M) n (init, c)))
                (walkOv U M_bar T₀ (n + 1)
                  (finSnocEquiv (StepChoice D M) n (init, c))) ≤
            (M : ℝ) ^ (D + 3) *
              phi1 U M_bar (radonWalkChoices gaussRadonPoint T₀ n init)
                (walkOv U M_bar T₀ n init) := by
        intro init
        rw [Finset.sum_congr rfl (fun c _ => hstep init c)]
        exact sum_step_phi1_le hD U hradU _ _ (walkOv_false_imp_le U M_bar T₀ n init)
      calc
        ∑ init : Fin n → StepChoice D M, ∑ c : StepChoice D M, _
            ≤ ∑ init : Fin n → StepChoice D M,
                (M : ℝ) ^ (D + 3) *
                  phi1 U M_bar (radonWalkChoices gaussRadonPoint T₀ n init)
                    (walkOv U M_bar T₀ n init) := Finset.sum_le_sum fun init _ => hinner init
        _ = (M : ℝ) ^ (D + 3) *
              ∑ init : Fin n → StepChoice D M,
                phi1 U M_bar (radonWalkChoices gaussRadonPoint T₀ n init)
                  (walkOv U M_bar T₀ n init) := (Finset.mul_sum _ _ _).symm
        _ ≤ (M : ℝ) ^ (D + 3) *
              (((M : ℝ) ^ (D + 3)) ^ n * phi1 U M_bar T₀ (decide (M_bar < countU U T₀))) :=
            mul_le_mul_of_nonneg_left (sum_walk_phi1_le hD U hradU T₀ n) (by positivity)
        _ = ((M : ℝ) ^ (D + 3)) ^ (n + 1) * phi1 U M_bar T₀ (decide (M_bar < countU U T₀)) := by
            rw [pow_succ]; ring

open Classical in
private theorem sum_walk_phi2_le {D M : ℕ} (hD : 1 ≤ D) (hM : 1 ≤ M)
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (hradU : ∀ pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D),
      gaussRadonPoint pts ∈ U → ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∈ U ∧ pts b ∈ U)
    (T₀ : Fin M → EuclideanSpace ℝ (Fin D)) :
    ∀ (n : ℕ),
      ∑ ch : Fin n → StepChoice D M,
          phi2 U (radonWalkChoices gaussRadonPoint T₀ n ch)
            (walkOv U (M / (D + 2) ^ 2) T₀ n ch) ≤
        ((M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ)))) ^ n *
          phi2 U T₀ (decide (M / (D + 2) ^ 2 < countU U T₀))
  | 0 => by
      let f0 : Fin 0 → StepChoice D M := fun i => Fin.elim0 i
      have huniv : (Finset.univ : Finset (Fin 0 → StepChoice D M)) = {f0} := by
        ext f
        simp only [Finset.mem_univ, Finset.mem_singleton, true_iff]
        funext i
        exact Fin.elim0 i
      rw [huniv, Finset.sum_singleton, pow_zero, one_mul]
      rfl
  | n + 1 => by
      let M_bar := M / (D + 2) ^ 2
      have hfac_nn : (0 : ℝ) ≤ (M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ))) := by
        have hM1 : (1 : ℝ) ≤ (M : ℝ) := by exact_mod_cast hM
        have hgam_nn : (0 : ℝ) ≤ 1 - 1 / (3 * (M : ℝ)) := by
          have : 1 / (3 * (M : ℝ)) ≤ 1 := by
            rw [div_le_iff₀ (by linarith)]
            linarith
          linarith
        exact mul_nonneg (by positivity) hgam_nn
      rw [← Equiv.sum_comp (finSnocEquiv (StepChoice D M) n), Fintype.sum_prod_type]
      have hstep : ∀ (init : Fin n → StepChoice D M) (c : StepChoice D M),
          phi2 U
            (radonWalkChoices gaussRadonPoint T₀ (n + 1) (finSnocEquiv (StepChoice D M) n (init, c)))
            (walkOv U M_bar T₀ (n + 1) (finSnocEquiv (StepChoice D M) n (init, c))) =
          phi2 U
            (radonWalkStep gaussRadonPoint (radonWalkChoices gaussRadonPoint T₀ n init) c)
            (walkOv U M_bar T₀ n init ||
              decide (M_bar < countU U
                (radonWalkStep gaussRadonPoint (radonWalkChoices gaussRadonPoint T₀ n init) c))) := by
        intro init c
        have hinit_eq :
            (fun s : Fin n => (finSnocEquiv (StepChoice D M) n (init, c)) s.castSucc) = init := by
          funext s
          exact finSnoc_castSucc init c s
        have hlast_eq : (finSnocEquiv (StepChoice D M) n (init, c)) (Fin.last n) = c :=
          finSnoc_last init c
        simp only [radonWalkChoices, walkOv, hinit_eq, hlast_eq]
      have hinner : ∀ init : Fin n → StepChoice D M,
          ∑ c : StepChoice D M,
              phi2 U
                (radonWalkChoices gaussRadonPoint T₀ (n + 1)
                  (finSnocEquiv (StepChoice D M) n (init, c)))
                (walkOv U M_bar T₀ (n + 1)
                  (finSnocEquiv (StepChoice D M) n (init, c))) ≤
            ((M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ)))) *
              phi2 U (radonWalkChoices gaussRadonPoint T₀ n init)
                (walkOv U M_bar T₀ n init) := by
        intro init
        rw [Finset.sum_congr rfl (fun c _ => hstep init c)]
        exact sum_step_phi2_le hD U hradU _ _ (walkOv_false_imp_le U M_bar T₀ n init)
      calc
        ∑ init : Fin n → StepChoice D M, ∑ c : StepChoice D M, _
            ≤ ∑ init : Fin n → StepChoice D M,
                ((M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ)))) *
                  phi2 U (radonWalkChoices gaussRadonPoint T₀ n init)
                    (walkOv U M_bar T₀ n init) := Finset.sum_le_sum fun init _ => hinner init
        _ = ((M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ)))) *
              ∑ init : Fin n → StepChoice D M,
                phi2 U (radonWalkChoices gaussRadonPoint T₀ n init)
                  (walkOv U M_bar T₀ n init) := (Finset.mul_sum _ _ _).symm
        _ ≤ ((M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ)))) *
              (((M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ)))) ^ n *
                phi2 U T₀ (decide (M_bar < countU U T₀))) :=
            mul_le_mul_of_nonneg_left (sum_walk_phi2_le hD hM U hradU T₀ n) hfac_nn
        _ = ((M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ)))) ^ (n + 1) *
              phi2 U T₀ (decide (M_bar < countU U T₀)) := by
            rw [pow_succ]; ring

private theorem div_two_mul_le_div (M N : ℕ) (hN : 0 < N) :
    M / (2 * N) ≤ M / N := by
  have h1 : (M / (2 * N)) * (2 * N) ≤ M := Nat.div_mul_le_self M (2 * N)
  have hdiv_mod := Nat.div_add_mod M N
  have hmod_lt : M % N < N := Nat.mod_lt M hN
  have hM_lt : M < (M / N + 1) * N := by
    calc
      M = N * (M / N) + M % N := hdiv_mod.symm
      _ < N * (M / N) + N := by omega
      _ = (M / N + 1) * N := by ring
  have h2 : (2 * (M / (2 * N))) * N < (M / N + 1) * N := by
    calc
      (2 * (M / (2 * N))) * N = (M / (2 * N)) * (2 * N) := by ring
      _ ≤ M := h1
      _ < (M / N + 1) * N := hM_lt
  have h3 : 2 * (M / (2 * N)) < M / N + 1 := Nat.lt_of_mul_lt_mul_right h2
  omega

open Classical in
private theorem card_badChoices_le {D M L : ℕ} (hD : 1 ≤ D) (hM : 1 ≤ M)
    (U : Set (EuclideanSpace ℝ (Fin D)))
    (hradU : ∀ pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D),
      gaussRadonPoint pts ∈ U → ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∈ U ∧ pts b ∈ U)
    (T₀ : Fin M → EuclideanSpace ℝ (Fin D))
    (hT₀ : countU U T₀ ≤ M / (2 * (D + 2) ^ 2)) :
    ((Finset.univ.filter (fun ch : Fin L → StepChoice D M =>
        1 ≤ countU U (radonWalkChoices gaussRadonPoint T₀ L ch))).card : ℝ) ≤
      ((M : ℝ) ^ (D + 3)) ^ L *
        ((2 / 3 : ℝ) ^ (M / (D + 2) ^ 2 + 1 - M / (2 * (D + 2) ^ 2)) +
          (M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) := by
  let M₀ := M / (2 * (D + 2) ^ 2)
  let M_bar := M / (D + 2) ^ 2
  have hM0_le_Mbar : M₀ ≤ M_bar := div_two_mul_le_div M ((D + 2) ^ 2) (by positivity)
  have hov0 : decide (M_bar < countU U T₀) = false := by
    simp only [decide_eq_false_iff_not, not_lt]
    exact hT₀.trans hM0_le_Mbar
  let E_bad := Finset.univ.filter (fun ch : Fin L → StepChoice D M =>
    1 ≤ countU U (radonWalkChoices gaussRadonPoint T₀ L ch))
  let E1 := Finset.univ.filter (fun ch : Fin L → StepChoice D M =>
    walkOv U M_bar T₀ L ch = true)
  let E2 := Finset.univ.filter (fun ch : Fin L → StepChoice D M =>
    walkOv U M_bar T₀ L ch = false ∧ 1 ≤ countU U (radonWalkChoices gaussRadonPoint T₀ L ch))
  have hsub : E_bad ⊆ E1 ∪ E2 := by
    intro ch hch
    simp only [E_bad, E1, E2, Finset.mem_union, Finset.mem_filter, Finset.mem_univ,
      true_and] at hch ⊢
    cases walkOv U M_bar T₀ L ch <;> simp [hch]
  have hE1 : (E1.card : ℝ) ≤ ((M : ℝ) ^ (D + 3)) ^ L * (2 / 3 : ℝ) ^ (M_bar + 1 - M₀) := by
    have hphi1_nn : ∀ ch : Fin L → StepChoice D M,
        0 ≤ phi1 U M_bar (radonWalkChoices gaussRadonPoint T₀ L ch) (walkOv U M_bar T₀ L ch) := by
      intro ch
      unfold phi1
      split_ifs <;> positivity
    have hmarkov : (E1.card : ℝ) * (3 / 2 : ℝ) ^ (M_bar + 1) ≤
        ((M : ℝ) ^ (D + 3)) ^ L * (3 / 2 : ℝ) ^ M₀ := by
      calc
        (E1.card : ℝ) * (3 / 2 : ℝ) ^ (M_bar + 1)
            = ∑ ch ∈ E1, (3 / 2 : ℝ) ^ (M_bar + 1) := by simp
        _ = ∑ ch ∈ E1,
              phi1 U M_bar (radonWalkChoices gaussRadonPoint T₀ L ch)
                (walkOv U M_bar T₀ L ch) := by
              refine Finset.sum_congr rfl fun ch hch => ?_
              have hov : walkOv U M_bar T₀ L ch = true := (Finset.mem_filter.mp hch).2
              simp [phi1, hov]
        _ ≤ ∑ ch ∈ Finset.univ,
              phi1 U M_bar (radonWalkChoices gaussRadonPoint T₀ L ch)
                (walkOv U M_bar T₀ L ch) :=
              Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
                (fun ch _ _ => hphi1_nn ch)
        _ ≤ ((M : ℝ) ^ (D + 3)) ^ L * phi1 U M_bar T₀ (decide (M_bar < countU U T₀)) :=
              sum_walk_phi1_le hD U hradU T₀ L
        _ = ((M : ℝ) ^ (D + 3)) ^ L * (3 / 2 : ℝ) ^ (countU U T₀) := by
              simp [phi1, hov0]
        _ ≤ ((M : ℝ) ^ (D + 3)) ^ L * (3 / 2 : ℝ) ^ M₀ := by
              refine mul_le_mul_of_nonneg_left ?_ (by positivity)
              exact pow_le_pow_right₀ (by norm_num) hT₀
    have hpow_split : (3 / 2 : ℝ) ^ (M_bar + 1) =
        (3 / 2 : ℝ) ^ M₀ * (3 / 2 : ℝ) ^ (M_bar + 1 - M₀) := by
      rw [← pow_add]
      congr 1
      omega
    have hinv_pow : (2 / 3 : ℝ) ^ (M_bar + 1 - M₀) * (3 / 2 : ℝ) ^ (M_bar + 1 - M₀) = 1 := by
      rw [← mul_pow]
      norm_num
    have hpos : (0 : ℝ) < (3 / 2 : ℝ) ^ (M_bar + 1) := by positivity
    rw [← mul_le_mul_iff_left₀ hpos]
    calc
      (E1.card : ℝ) * (3 / 2 : ℝ) ^ (M_bar + 1)
          ≤ ((M : ℝ) ^ (D + 3)) ^ L * (3 / 2 : ℝ) ^ M₀ := hmarkov
      _ = ((M : ℝ) ^ (D + 3)) ^ L * (2 / 3 : ℝ) ^ (M_bar + 1 - M₀) *
            (3 / 2 : ℝ) ^ (M_bar + 1) := by
            rw [hpow_split]
            calc
              ((M : ℝ) ^ (D + 3)) ^ L * (3 / 2 : ℝ) ^ M₀
                  = ((M : ℝ) ^ (D + 3)) ^ L * (3 / 2 : ℝ) ^ M₀ *
                      ((2 / 3 : ℝ) ^ (M_bar + 1 - M₀) * (3 / 2 : ℝ) ^ (M_bar + 1 - M₀)) := by
                      rw [hinv_pow, mul_one]
              _ = ((M : ℝ) ^ (D + 3)) ^ L * (2 / 3 : ℝ) ^ (M_bar + 1 - M₀) *
                    ((3 / 2 : ℝ) ^ M₀ * (3 / 2 : ℝ) ^ (M_bar + 1 - M₀)) := by ring
  have hE2 : (E2.card : ℝ) ≤
      ((M : ℝ) ^ (D + 3)) ^ L * ((M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) := by
    have hphi2_nn : ∀ ch : Fin L → StepChoice D M,
        0 ≤ phi2 U (radonWalkChoices gaussRadonPoint T₀ L ch) (walkOv U M_bar T₀ L ch) := by
      intro ch
      unfold phi2
      split_ifs
      · exact le_rfl
      · exact Nat.cast_nonneg _
    have hk0_le_M : (countU U T₀ : ℝ) ≤ (M : ℝ) := by
      have : countU U T₀ ≤ M := by
        unfold countU
        exact (Finset.card_le_card (Finset.subset_univ _)).trans_eq (by simp)
      exact_mod_cast this
    have hM1 : (1 : ℝ) ≤ (M : ℝ) := by exact_mod_cast hM
    have hgam_nn : (0 : ℝ) ≤ 1 - 1 / (3 * (M : ℝ)) := by
      have : 1 / (3 * (M : ℝ)) ≤ 1 := by
        rw [div_le_iff₀ (by linarith)]
        linarith
      linarith
    have hgam_exp : (1 - 1 / (3 * (M : ℝ))) ^ L ≤ Real.exp (- (L : ℝ) / (3 * (M : ℝ))) := by
      have h1 : 1 - 1 / (3 * (M : ℝ)) ≤ Real.exp (- (1 / (3 * (M : ℝ)))) := by
        linarith [Real.add_one_le_exp (- (1 / (3 * (M : ℝ))))]
      calc
        (1 - 1 / (3 * (M : ℝ))) ^ L ≤ (Real.exp (- (1 / (3 * (M : ℝ))))) ^ L :=
          pow_le_pow_left₀ hgam_nn h1 L
        _ = Real.exp ((L : ℝ) * (- (1 / (3 * (M : ℝ))))) :=
          (Real.exp_nat_mul (- (1 / (3 * (M : ℝ)))) L).symm
        _ = Real.exp (- (L : ℝ) / (3 * (M : ℝ))) := by ring_nf
    calc
      (E2.card : ℝ) = ∑ ch ∈ E2, (1 : ℝ) := by simp
      _ ≤ ∑ ch ∈ E2,
            phi2 U (radonWalkChoices gaussRadonPoint T₀ L ch) (walkOv U M_bar T₀ L ch) := by
            refine Finset.sum_le_sum fun ch hch => ?_
            obtain ⟨hov, hcnt⟩ := (Finset.mem_filter.mp hch).2
            simp only [phi2, hov, Bool.false_eq_true, ↓reduceIte]
            exact_mod_cast hcnt
      _ ≤ ∑ ch ∈ Finset.univ,
            phi2 U (radonWalkChoices gaussRadonPoint T₀ L ch) (walkOv U M_bar T₀ L ch) :=
            Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
              (fun ch _ _ => hphi2_nn ch)
      _ ≤ ((M : ℝ) ^ (D + 3) * (1 - 1 / (3 * (M : ℝ)))) ^ L *
            phi2 U T₀ (decide (M_bar < countU U T₀)) := sum_walk_phi2_le hD hM U hradU T₀ L
      _ = ((M : ℝ) ^ (D + 3)) ^ L * ((1 - 1 / (3 * (M : ℝ))) ^ L * (countU U T₀ : ℝ)) := by
            simp only [phi2, hov0, Bool.false_eq_true, ↓reduceIte, mul_pow]
            ring
      _ ≤ ((M : ℝ) ^ (D + 3)) ^ L * (Real.exp (- (L : ℝ) / (3 * (M : ℝ))) * (M : ℝ)) := by
            refine mul_le_mul_of_nonneg_left ?_ (by positivity)
            exact mul_le_mul hgam_exp hk0_le_M (Nat.cast_nonneg _) (Real.exp_nonneg _)
      _ = ((M : ℝ) ^ (D + 3)) ^ L * ((M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) := by ring
  have hcard_union : (E_bad.card : ℝ) ≤ (E1.card : ℝ) + (E2.card : ℝ) := by
    have : E_bad.card ≤ E1.card + E2.card :=
      (Finset.card_le_card hsub).trans (Finset.card_union_le E1 E2)
    exact_mod_cast this
  calc
    (E_bad.card : ℝ) ≤ (E1.card : ℝ) + (E2.card : ℝ) := hcard_union
    _ ≤ ((M : ℝ) ^ (D + 3)) ^ L * (2 / 3 : ℝ) ^ (M_bar + 1 - M₀) +
          ((M : ℝ) ^ (D + 3)) ^ L * ((M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) :=
        add_le_add hE1 hE2
    _ = ((M : ℝ) ^ (D + 3)) ^ L *
          ((2 / 3 : ℝ) ^ (M_bar + 1 - M₀) + (M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) := by
        ring

/-! ### Step 4: Numerical union bound and main theorem -/

private theorem two_pow_le_exp_nat (n : ℕ) : (2 : ℝ) ^ n ≤ Real.exp (n : ℝ) := by
  have h2 : (2 : ℝ) ≤ Real.exp 1 := by linarith [Real.add_one_le_exp (1 : ℝ)]
  calc
    (2 : ℝ) ^ n ≤ (Real.exp 1) ^ n := pow_le_pow_left₀ (by norm_num) h2 n
    _ = Real.exp ((n : ℝ) * 1) := (Real.exp_nat_mul 1 n).symm
    _ = Real.exp (n : ℝ) := by ring

private theorem exp_neg_one_le_half : Real.exp (-1 : ℝ) ≤ 1 / 2 := by
  have h2 : (2 : ℝ) ≤ Real.exp 1 := by linarith [Real.add_one_le_exp (1 : ℝ)]
  rw [Real.exp_neg]
  calc
    (Real.exp 1)⁻¹ ≤ (2 : ℝ)⁻¹ := inv_anti₀ (by norm_num) h2
    _ = 1 / 2 := by norm_num

private theorem failProb_le_half_phi
    {D q M k_phi L B_card : ℕ} {φ : ℝ}
    (hφ0 : 0 < φ) (hq16 : 16 ≤ q) (hM_pos : 0 < M)
    (hM_exp : (M : ℝ) ≤ Real.exp (q : ℝ))
    (hL_eq : L = 3 * M * (4 * (D + 2) * q + 4 * k_phi + 16))
    (hphi_pow : 2 / φ ≤ (2 : ℝ) ^ k_phi)
    (hM_large : 1300 * ((D + 2) * q + k_phi) * (D + 2) ^ 2 ≤ M)
    (hTraces_le : (B_card : ℝ) ≤ Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ))) :
    (B_card : ℝ) *
      ((2 / 3 : ℝ) ^ (M / (D + 2) ^ 2 + 1 - M / (2 * (D + 2) ^ 2)) +
        (M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) ≤ φ / 2 := by
  let M₀ : ℕ := M / (2 * (D + 2) ^ 2)
  let M_bar : ℕ := M / (D + 2) ^ 2
  let R : ℕ := M_bar + 1 - M₀
  have hR_ge : 650 * ((D + 2) * q + k_phi) ≤ R := by
    let N := (D + 2) ^ 2
    have hN_pos : 0 < N := by positivity
    have hM_lt : M < (M_bar + 1) * N := by
      have hdiv_mod := Nat.div_add_mod M N
      have hmod_lt : M % N < N := Nat.mod_lt M hN_pos
      dsimp [M_bar]
      calc
        M = N * (M / N) + M % N := hdiv_mod.symm
        _ < N * (M / N) + N := by omega
        _ = (M / N + 1) * N := by ring
    have hMbar_ge : 1300 * ((D + 2) * q + k_phi) ≤ M_bar := by
      have hlt : 1300 * ((D + 2) * q + k_phi) * N < (M_bar + 1) * N :=
        lt_of_le_of_lt hM_large hM_lt
      have hlt' : 1300 * ((D + 2) * q + k_phi) < M_bar + 1 :=
        Nat.lt_of_mul_lt_mul_right hlt
      omega
    have h2M0_le : 2 * M₀ ≤ M_bar := by
      have h1 : M₀ * (2 * N) ≤ M := Nat.div_mul_le_self M (2 * N)
      have h2 : (2 * M₀) * N < (M_bar + 1) * N := by
        calc
          (2 * M₀) * N = M₀ * (2 * N) := by ring
          _ ≤ M := h1
          _ < (M_bar + 1) * N := hM_lt
      have h3 : 2 * M₀ < M_bar + 1 := Nat.lt_of_mul_lt_mul_right h2
      omega
    dsimp [R]
    omega
  have hTermA : (B_card : ℝ) * (2 : ℝ) ^ k_phi * (2 / 3 : ℝ) ^ R ≤ 1 / 2 := by
    have h23 : (2 / 3 : ℝ) ^ R ≤ Real.exp (- (R : ℝ) / 3) := by
      have h1 : (2 / 3 : ℝ) ≤ Real.exp (- (1 / 3 : ℝ)) := by
        have h_exp := Real.add_one_le_exp (- (1 / 3 : ℝ))
        linarith
      calc
        (2 / 3 : ℝ) ^ R ≤ (Real.exp (- (1 / 3 : ℝ))) ^ R :=
          pow_le_pow_left₀ (by norm_num) h1 R
        _ = Real.exp ((R : ℝ) * (- (1 / 3 : ℝ))) := (Real.exp_nat_mul _ R).symm
        _ = Real.exp (- (R : ℝ) / 3) := by ring_nf
    have hprod :
        (B_card : ℝ) * (2 : ℝ) ^ k_phi * (2 / 3 : ℝ) ^ R ≤
          Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ) + (k_phi : ℝ) - (R : ℝ) / 3) := by
      have h1 : (B_card : ℝ) * (2 : ℝ) ^ k_phi ≤
          Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ)) * Real.exp (k_phi : ℝ) :=
        mul_le_mul hTraces_le (two_pow_le_exp_nat k_phi) (by positivity) (Real.exp_nonneg _)
      calc
        (B_card : ℝ) * (2 : ℝ) ^ k_phi * (2 / 3 : ℝ) ^ R
            ≤ (Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ)) * Real.exp (k_phi : ℝ)) *
                Real.exp (- (R : ℝ) / 3) :=
              mul_le_mul h1 h23 (by positivity) (by positivity)
        _ = Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ) + (k_phi : ℝ) - (R : ℝ) / 3) := by
              rw [← Real.exp_add, ← Real.exp_add]
              ring_nf
    have hexp_le :
        ((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ) + (k_phi : ℝ) - (R : ℝ) / 3 ≤ -1 := by
      have hR_real : (650 : ℝ) * (((D : ℝ) + 2) * (q : ℝ) + (k_phi : ℝ)) ≤ (R : ℝ) := by
        have : ((650 * ((D + 2) * q + k_phi) : ℕ) : ℝ) ≤ (R : ℝ) := by exact_mod_cast hR_ge
        push_cast at this
        exact this
      have hq_real : (16 : ℝ) ≤ (q : ℝ) := by exact_mod_cast hq16
      have hD_nn : (0 : ℝ) ≤ (D : ℝ) := Nat.cast_nonneg D
      have hk_nn : (0 : ℝ) ≤ (k_phi : ℝ) := Nat.cast_nonneg k_phi
      push_cast
      nlinarith
    exact hprod.trans ((Real.exp_le_exp.mpr hexp_le).trans exp_neg_one_le_half)
  have hTermB :
      (B_card : ℝ) * (2 : ℝ) ^ k_phi * ((M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) ≤ 1 / 2 := by
    have hL_div : - (L : ℝ) / (3 * (M : ℝ)) =
        - (4 * ((D : ℝ) + 2) * (q : ℝ) + 4 * (k_phi : ℝ) + 16) := by
      have hL_real : (L : ℝ) =
          3 * (M : ℝ) * (4 * ((D : ℝ) + 2) * (q : ℝ) + 4 * (k_phi : ℝ) + 16) := by
        have : (L : ℝ) = ((3 * M * (4 * (D + 2) * q + 4 * k_phi + 16) : ℕ) : ℝ) := by
          exact_mod_cast hL_eq
        push_cast at this
        exact this
      have hM_pos_real : (0 : ℝ) < (M : ℝ) := by exact_mod_cast hM_pos
      rw [hL_real]
      field_simp [hM_pos_real.ne']
    have hprod :
        (B_card : ℝ) * (2 : ℝ) ^ k_phi * ((M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) ≤
          Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ) + (k_phi : ℝ) + (q : ℝ) -
            (4 * ((D : ℝ) + 2) * (q : ℝ) + 4 * (k_phi : ℝ) + 16)) := by
      have h1 : (B_card : ℝ) * (2 : ℝ) ^ k_phi ≤
          Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ)) * Real.exp (k_phi : ℝ) :=
        mul_le_mul hTraces_le (two_pow_le_exp_nat k_phi) (by positivity) (Real.exp_nonneg _)
      have h2 : (M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ))) ≤
          Real.exp (q : ℝ) *
            Real.exp (- (4 * ((D : ℝ) + 2) * (q : ℝ) + 4 * (k_phi : ℝ) + 16)) := by
        rw [hL_div]
        exact mul_le_mul_of_nonneg_right hM_exp (Real.exp_nonneg _)
      calc
        (B_card : ℝ) * (2 : ℝ) ^ k_phi * ((M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ))))
            ≤ (Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ)) * Real.exp (k_phi : ℝ)) *
                (Real.exp (q : ℝ) *
                  Real.exp (- (4 * ((D : ℝ) + 2) * (q : ℝ) + 4 * (k_phi : ℝ) + 16))) :=
              mul_le_mul h1 h2 (by positivity) (by positivity)
        _ = Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ) + (k_phi : ℝ) + (q : ℝ) -
              (4 * ((D : ℝ) + 2) * (q : ℝ) + 4 * (k_phi : ℝ) + 16)) := by
              rw [← Real.exp_add, ← Real.exp_add, ← Real.exp_add]
              ring_nf
    have hexp_le :
        ((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ) + (k_phi : ℝ) + (q : ℝ) -
          (4 * ((D : ℝ) + 2) * (q : ℝ) + 4 * (k_phi : ℝ) + 16) ≤ -1 := by
      have hq_real : (16 : ℝ) ≤ (q : ℝ) := by exact_mod_cast hq16
      have hD_nn : (0 : ℝ) ≤ (D : ℝ) := Nat.cast_nonneg D
      have hk_nn : (0 : ℝ) ≤ (k_phi : ℝ) := Nat.cast_nonneg k_phi
      push_cast
      nlinarith
    exact hprod.trans ((Real.exp_le_exp.mpr hexp_le).trans exp_neg_one_le_half)
  have h1 : 1 ≤ (φ / 2) * (2 : ℝ) ^ k_phi := by
    have h2 := (div_le_iff₀ hφ0).mp hphi_pow
    linarith
  have hsum :
      (B_card : ℝ) *
        ((2 / 3 : ℝ) ^ R + (M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) *
        (2 : ℝ) ^ k_phi ≤ 1 := by
    calc
      (B_card : ℝ) *
          ((2 / 3 : ℝ) ^ R + (M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) *
          (2 : ℝ) ^ k_phi
          = (B_card : ℝ) * (2 : ℝ) ^ k_phi * (2 / 3 : ℝ) ^ R +
              (B_card : ℝ) * (2 : ℝ) ^ k_phi *
                ((M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) := by ring
      _ ≤ 1 / 2 + 1 / 2 := add_le_add hTermA hTermB
      _ = 1 := by norm_num
  have hpow_pos : (0 : ℝ) < (2 : ℝ) ^ k_phi := by positivity
  exact (mul_le_mul_iff_left₀ hpow_pos).mp (hsum.trans h1)

open Classical in
private theorem badTraces_card_le_exp {D q : ℕ}
    (hD1_le : D + 1 ≤ 2 ^ q)
    (T₀ : Fin (2 ^ q) → EuclideanSpace ℝ (Fin D))
    (α : ℝ) :
    ((badTraces T₀ α).card : ℝ) ≤ Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ)) := by
  have h_hw := UL.Proof_cit_hw87_halfspace_net.card_halfspace_traces_le T₀ (badTraces T₀ α)
    (fun B hB => (Finset.mem_filter.mp hB).2.2)
    (by simpa using hD1_le)
  simp only [Fintype.card_fin] at h_hw
  have hbase : Real.exp 1 * ((2 ^ q : ℕ) : ℝ) / ((D : ℝ) + 1) ≤ Real.exp ((q + 1 : ℕ) : ℝ) := by
    have hD_den : (1 : ℝ) ≤ (D : ℝ) + 1 := by
      have hD_nn : (0 : ℝ) ≤ (D : ℝ) := Nat.cast_nonneg D
      linarith
    calc
      Real.exp 1 * ((2 ^ q : ℕ) : ℝ) / ((D : ℝ) + 1)
          ≤ Real.exp 1 * ((2 ^ q : ℕ) : ℝ) := div_le_self (by positivity) hD_den
      _ = Real.exp 1 * (2 : ℝ) ^ q := by push_cast; rfl
      _ ≤ Real.exp 1 * Real.exp (q : ℝ) :=
            mul_le_mul_of_nonneg_left (two_pow_le_exp_nat q) (Real.exp_nonneg 1)
      _ = Real.exp (1 + (q : ℝ)) := (Real.exp_add 1 (q : ℝ)).symm
      _ = Real.exp ((q + 1 : ℕ) : ℝ) := by push_cast; ring_nf
  calc
    ((badTraces T₀ α).card : ℝ)
        ≤ (Real.exp 1 * ((2 ^ q : ℕ) : ℝ) / ((D : ℝ) + 1)) ^ (D + 1) := h_hw
    _ ≤ (Real.exp ((q + 1 : ℕ) : ℝ)) ^ (D + 1) :=
          pow_le_pow_left₀ (by positivity) hbase (D + 1)
    _ = Real.exp (((D + 1 : ℕ) : ℝ) * ((q + 1 : ℕ) : ℝ)) :=
          (Real.exp_nat_mul _ (D + 1)).symm

open Classical in
private theorem card_goodWalkChoices_ge {D M L : ℕ} (hD1 : 1 ≤ D) (hM_pos : 0 < M)
    {φ α : ℝ}
    (hα : 2 * α * (M : ℝ) = (M : ℝ) / (2 * ((D : ℝ) + 2) ^ 2))
    (hrad : ∀ (pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D))
        (K : Set (EuclideanSpace ℝ (Fin D))),
      Convex ℝ K → gaussRadonPoint pts ∉ K →
        ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∉ K ∧ pts b ∉ K)
    {ι : Type*} [Fintype ι]
    (Q : ι → EuclideanSpace ℝ (Fin D))
    (ω₀ : Fin M → ι)
    (hGood : GoodInitialSample Q α ω₀)
    (hFailProb :
      ((badTraces (fun j => Q (ω₀ j)) α).card : ℝ) *
        ((2 / 3 : ℝ) ^ (M / (D + 2) ^ 2 + 1 - M / (2 * (D + 2) ^ 2)) +
          (M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) ≤ φ / 2) :
    (1 - φ / 2) * (((M : ℝ) ^ (D + 3)) ^ L) ≤
      ((Finset.univ.filter (fun ch : Fin L → StepChoice D M =>
        UL.IsCenterpoint α Q
          (radonWalkChoices gaussRadonPoint (fun j => Q (ω₀ j)) L ch ⟨0, hM_pos⟩))).card : ℝ) := by
  let T₀ : Fin M → EuclideanSpace ℝ (Fin D) := fun j => Q (ω₀ j)
  let M₀ : ℕ := M / (2 * (D + 2) ^ 2)
  let R : ℕ := M / (D + 2) ^ 2 + 1 - M₀
  let BadChoiceOf : Finset (Fin M) → Finset (Fin L → StepChoice D M) := fun B =>
    Finset.univ.filter (fun ch =>
      1 ≤ countU (traceHull T₀ B)ᶜ (radonWalkChoices gaussRadonPoint T₀ L ch))
  have hBadEach : ∀ B ∈ badTraces T₀ α,
      ((BadChoiceOf B).card : ℝ) ≤
        ((M : ℝ) ^ (D + 3)) ^ L *
          ((2 / 3 : ℝ) ^ R + (M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) := by
    intro B hB
    have hB_lt : (B.card : ℝ) < 2 * α * (M : ℝ) := (Finset.mem_filter.mp hB).2.1
    have hcnt_lt_real : (countU (traceHull T₀ B)ᶜ T₀ : ℝ) <
        (M : ℝ) / (2 * ((D : ℝ) + 2) ^ 2) := by
      have hle : (countU (traceHull T₀ B)ᶜ T₀ : ℝ) ≤ (B.card : ℝ) := by
        exact_mod_cast countU_compl_traceHull_le T₀ B
      exact hle.trans_lt (hB_lt.trans_eq hα)
    have hcnt_le_M0 : countU (traceHull T₀ B)ᶜ T₀ ≤ M₀ := by
      let N := 2 * (D + 2) ^ 2
      have hmul_lt_real : (countU (traceHull T₀ B)ᶜ T₀ : ℝ) * (N : ℝ) < (M : ℝ) := by
        have hN_cast : (N : ℝ) = 2 * ((D : ℝ) + 2) ^ 2 := by dsimp [N]; push_cast; ring
        rw [hN_cast]
        exact (lt_div_iff₀ (by positivity)).mp hcnt_lt_real
      have hmul_lt_nat : countU (traceHull T₀ B)ᶜ T₀ * N < M := by
        exact_mod_cast hmul_lt_real
      have hdiv_mod := Nat.div_add_mod M N
      have hmod_lt : M % N < N := Nat.mod_lt M (by positivity)
      change countU (traceHull T₀ B)ᶜ T₀ ≤ M / N
      by_contra! hgt
      have hge : M / N + 1 ≤ countU (traceHull T₀ B)ᶜ T₀ := hgt
      have h1 : (M / N + 1) * N ≤ countU (traceHull T₀ B)ᶜ T₀ * N := Nat.mul_le_mul_right N hge
      have h2 : M < (M / N + 1) * N := by
        calc
          M = N * (M / N) + M % N := hdiv_mod.symm
          _ < N * (M / N) + N := by omega
          _ = (M / N + 1) * N := by ring
      omega
    have hradB : ∀ pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D),
        gaussRadonPoint pts ∈ (traceHull T₀ B)ᶜ →
        ∃ a b : Fin (D + 2), a ≠ b ∧ pts a ∈ (traceHull T₀ B)ᶜ ∧ pts b ∈ (traceHull T₀ B)ᶜ := by
      intro pts hpts
      exact hrad pts (traceHull T₀ B) (convex_convexHull ℝ _) hpts
    exact card_badChoices_le hD1 hM_pos (traceHull T₀ B)ᶜ hradB T₀ hcnt_le_M0
  let UnionBad : Finset (Fin L → StepChoice D M) := (badTraces T₀ α).biUnion BadChoiceOf
  have hUnionBad_le : (UnionBad.card : ℝ) ≤ (φ / 2) * (((M : ℝ) ^ (D + 3)) ^ L) := by
    have hnat : UnionBad.card ≤ ∑ B ∈ badTraces T₀ α, (BadChoiceOf B).card :=
      Finset.card_biUnion_le
    have hreal : (UnionBad.card : ℝ) ≤ ∑ B ∈ badTraces T₀ α, ((BadChoiceOf B).card : ℝ) := by
      exact_mod_cast hnat
    calc
      (UnionBad.card : ℝ)
          ≤ ∑ B ∈ badTraces T₀ α, ((BadChoiceOf B).card : ℝ) := hreal
      _ ≤ ∑ _B ∈ badTraces T₀ α,
            ((M : ℝ) ^ (D + 3)) ^ L *
              ((2 / 3 : ℝ) ^ R + (M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ)))) :=
            Finset.sum_le_sum fun B hB => hBadEach B hB
      _ = (((badTraces T₀ α).card : ℝ) *
            ((2 / 3 : ℝ) ^ R + (M : ℝ) * Real.exp (- (L : ℝ) / (3 * (M : ℝ))))) *
            ((M : ℝ) ^ (D + 3)) ^ L := by
            simp only [Finset.sum_const, nsmul_eq_mul]
            ring
      _ ≤ (φ / 2) * (((M : ℝ) ^ (D + 3)) ^ L) :=
            mul_le_mul_of_nonneg_right hFailProb (by positivity)
  let GoodChoices := Finset.univ.filter (fun ch : Fin L → StepChoice D M =>
    UL.IsCenterpoint α Q (radonWalkChoices gaussRadonPoint T₀ L ch ⟨0, hM_pos⟩))
  have huniv_sub : (Finset.univ : Finset (Fin L → StepChoice D M)) ⊆ GoodChoices ∪ UnionBad := by
    intro ch _
    by_cases hbad : ch ∈ UnionBad
    · exact Finset.mem_union_right _ hbad
    · refine Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨Finset.mem_univ ch, ?_⟩)
      refine isCenterpoint_of_forall_badTraces hD1 Q α ω₀ hGood (fun B hB => ?_)
      have hnot_bad : ch ∉ BadChoiceOf B := fun hc =>
        hbad (Finset.mem_biUnion.mpr ⟨B, hB, hc⟩)
      have hcnt0 : countU (traceHull T₀ B)ᶜ (radonWalkChoices gaussRadonPoint T₀ L ch) = 0 := by
        simp only [BadChoiceOf, Finset.mem_filter, Finset.mem_univ, true_and, not_le] at hnot_bad
        omega
      by_contra hz_not
      exact not_mem_of_countU_eq_zero hcnt0 ⟨0, hM_pos⟩ hz_not
  have huniv_card_nat :
      (M ^ (D + 3)) ^ L ≤ GoodChoices.card + UnionBad.card := by
    calc
      (M ^ (D + 3)) ^ L
          = (Finset.univ : Finset (Fin L → StepChoice D M)).card := by
              rw [Finset.card_univ, Fintype.card_fun, card_stepChoice, Fintype.card_fin]
      _ ≤ (GoodChoices ∪ UnionBad).card := Finset.card_le_card huniv_sub
      _ ≤ GoodChoices.card + UnionBad.card := Finset.card_union_le _ _
  have huniv_card_real :
      (((M : ℝ) ^ (D + 3)) ^ L) ≤ (GoodChoices.card : ℝ) + (UnionBad.card : ℝ) := by
    have : (((M ^ (D + 3)) ^ L : ℕ) : ℝ) ≤ ((GoodChoices.card + UnionBad.card : ℕ) : ℝ) := by
      exact_mod_cast huniv_card_nat
    push_cast at this
    exact this
  calc
    (1 - φ / 2) * (((M : ℝ) ^ (D + 3)) ^ L)
        = (((M : ℝ) ^ (D + 3)) ^ L) - (φ / 2) * (((M : ℝ) ^ (D + 3)) ^ L) := by ring
    _ ≤ ((GoodChoices.card : ℝ) + (UnionBad.card : ℝ)) - (UnionBad.card : ℝ) :=
          sub_le_sub huniv_card_real hUnionBad_le
    _ = (GoodChoices.card : ℝ) := add_sub_cancel_right _ _

open Classical in
theorem card_goodWalkBits_centerpoint_ge
    {d : ℕ} {φ : ℝ} (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2)
    (P : HPJParams) (hP : HPJParamProps d φ P)
    (hrad : ∀ (pts : Fin (d + 1 + 2) → EuclideanSpace ℝ (Fin (d + 1)))
        (K : Set (EuclideanSpace ℝ (Fin (d + 1)))),
      Convex ℝ K → gaussRadonPoint pts ∉ K →
        ∃ a b : Fin (d + 1 + 2), a ≠ b ∧ pts a ∉ K ∧ pts b ∉ K)
    (ι : Type) [Fintype ι] [Nonempty ι]
    (Q : ι → EuclideanSpace ℝ (Fin (d + 1)))
    (ω₀ : Fin (2 ^ P.q) → ι)
    (hGood : GoodInitialSample Q (hpjAlpha d) ω₀) :
    (1 - φ / 2) * ((2 : ℝ) ^ (P.L * (d + 1 + 3) * P.q)) ≤
      ((Finset.univ.filter (fun bits : Fin (P.L * (d + 1 + 3) * P.q) → Bool =>
        UL.IsCenterpoint (hpjAlpha d) Q
          (radonWalkOutput (d + 1) P.q P.L (fun j => Q (ω₀ j)) bits))).card : ℝ) := by
  let _ := hφ1
  rcases hP with ⟨hPD, -, -, hq16, -, -, -, hm_eq, hL_eq, -, hphi_pow, hM_large, -, -⟩
  rw [hPD, hm_eq] at hL_eq hM_large
  rw [card_goodWalkBits_eq_choices (d + 1) P.q P.L (fun j => Q (ω₀ j))
    (UL.IsCenterpoint (hpjAlpha d) Q)]
  have hD1_le_M : (d + 1) + 1 ≤ 2 ^ P.q := by
    have h1 : 1 ≤ ((d + 1) + 2) * P.q + P.k_phi := by nlinarith
    have h2 : (d + 1) + 1 ≤ ((d + 1) + 2) ^ 2 := by nlinarith
    have h3 : (d + 1) + 1 ≤ 1300 * (((d + 1) + 2) * P.q + P.k_phi) * ((d + 1) + 2) ^ 2 := by
      nlinarith
    exact h3.trans hM_large
  have hTraces_le := badTraces_card_le_exp hD1_le_M (fun j => Q (ω₀ j)) (hpjAlpha d)
  have hM_exp : ((2 ^ P.q : ℕ) : ℝ) ≤ Real.exp (P.q : ℝ) := by
    simpa using two_pow_le_exp_nat P.q
  have hFailProb := failProb_le_half_phi hφ0 hq16 (Nat.two_pow_pos P.q)
    hM_exp hL_eq hphi_pow hM_large hTraces_le
  have hα_eq : 2 * hpjAlpha d * ((2 ^ P.q : ℕ) : ℝ) =
      ((2 ^ P.q : ℕ) : ℝ) / (2 * (((d + 1 : ℕ) : ℝ) + 2) ^ 2) := by
    unfold hpjAlpha
    have hpos : (0 : ℝ) < ((d : ℝ) + 3) ^ 2 := by positivity
    have hcast : (((d + 1 : ℕ) : ℝ) + 2) = (d : ℝ) + 3 := by push_cast; ring
    rw [hcast]
    field_simp [hpos.ne']
    ring
  have hChoices := card_goodWalkChoices_ge (by omega : 1 ≤ d + 1) (Nat.two_pow_pos P.q)
    hα_eq hrad Q ω₀ hGood hFailProb
  have hWL : ((((2 ^ P.q : ℕ) : ℝ) ^ (d + 1 + 3)) ^ P.L) =
      (2 : ℝ) ^ (P.L * (d + 1 + 3) * P.q) := by
    push_cast
    rw [← pow_mul, ← pow_mul]
    congr 1
    ring
  rwa [hWL] at hChoices

end UL.Proof_cit_hpj19_thm18
