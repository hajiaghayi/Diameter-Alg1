import UL.Proof.cit_hpj19_thm18.H0
set_option autoImplicit false

namespace UL.Proof_cit_hpj19_thm18

/-! ### 1. Heap read/write helpers, expression costs, and fuel monotonicity -/

private def wRead (mem : UL.ArithRAMMemory) (t : ℕ) (i : ℤ) : ℤ :=
  mem.words.read (.heap t i)

private def wWrite (mem : UL.ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℤ) : UL.ArithRAMMemory :=
  { mem with words := mem.words.write (.heap t i) v }

private noncomputable def rRead (mem : UL.ArithRAMMemory) (t : ℕ) (i : ℤ) : ℝ :=
  mem.reals.read (.heap t i)

private noncomputable def rWrite (mem : UL.ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℝ) :
    UL.ArithRAMMemory :=
  { mem with reals := mem.reals.write (.heap t i) v }

@[simp]
private theorem wRead_wWrite_self (mem : UL.ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℤ) :
    wRead (wWrite mem t i v) t i = v := by
  simp [wRead, wWrite, UL.WordStore.read, UL.WordStore.write]

private theorem wRead_wWrite_of_ne (mem : UL.ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℤ)
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    wRead (wWrite mem t₂ i₂ v) t₁ i₁ = wRead mem t₁ i₁ := by
  have hloc : (UL.RAMCellLoc.heap t₁ i₁) ≠ (UL.RAMCellLoc.heap t₂ i₂) := by
    intro h
    cases h
    rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [wRead, wWrite, UL.WordStore.read, UL.WordStore.write, hloc]

@[simp]
private theorem wRead_rWrite (mem : UL.ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) (v : ℝ) :
    wRead (rWrite mem t₂ i₂ v) t₁ i₁ = wRead mem t₁ i₁ := rfl

@[simp]
private theorem rRead_wWrite (mem : UL.ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) (v : ℤ) :
    rRead (wWrite mem t₂ i₂ v) t₁ i₁ = rRead mem t₁ i₁ := rfl

@[simp]
private theorem rRead_rWrite_self (mem : UL.ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℝ) :
    rRead (rWrite mem t i v) t i = v := by
  simp [rRead, rWrite, UL.RealStore.read, UL.RealStore.write]

private theorem rRead_rWrite_of_ne (mem : UL.ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℝ)
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    rRead (rWrite mem t₂ i₂ v) t₁ i₁ = rRead mem t₁ i₁ := by
  have hloc : (UL.RAMCellLoc.heap t₁ i₁) ≠ (UL.RAMCellLoc.heap t₂ i₂) := by
    intro h
    cases h
    rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [rRead, rWrite, UL.RealStore.read, UL.RealStore.write, hloc]

private theorem rRead_popDepth_heap (mem : UL.ArithRAMMemory) (k t : ℕ) (i : ℤ) :
    (mem.popDepth k).reals.read (.heap t i) = rRead mem t i := by
  simp [UL.ArithRAMMemory.popDepth, UL.RealStore.popDepth, UL.RealStore.read,
    UL.RAMCellLoc.keepAtDepth, rRead]

private def intExprOps : UL.IntExpr → ℕ
  | .lit _ => 1
  | .dim => 1
  | .intParam e | .readHeap _ e | .readLocal _ e | .extraRatNum e | .extraRatDen e | .neg e =>
      intExprOps e + 1
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ | .add e₁ e₂ | .sub e₁ e₂
  | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ =>
      intExprOps e₁ + intExprOps e₂ + 1

private def realExprOps : UL.RealExpr → ℕ
  | .ofInt e | .readRealHeap _ e | .readRealLocal _ e | .extraReal e => intExprOps e + 1
  | .activePtCoord e₁ e₂ => intExprOps e₁ + intExprOps e₂ + 1
  | .neg r => realExprOps r + 1
  | .add r₁ r₂ | .sub r₁ r₂ | .mul r₁ r₂ | .div r₁ r₂ => realExprOps r₁ + realExprOps r₂ + 1

private def condExprOps : UL.ArithCondExpr → ℕ
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => intExprOps e₁ + intExprOps e₂ + 1
  | .realEq r₁ r₂ | .realLt r₁ r₂ | .realLe r₁ r₂ => realExprOps r₁ + realExprOps r₂ + 1
  | .not c => condExprOps c + 1
  | .and c₁ c₂ | .or c₁ c₂ => condExprOps c₁ + condExprOps c₂ + 1

private theorem evalIntExpr_ops {d : ℕ} (bw : UL.BitRAMInput d) (fd : ℕ) (ws : UL.WordStore) :
    ∀ e : UL.IntExpr, (UL.evalIntExpr bw fd ws e).2.1 = intExprOps e
  | .lit _ | .dim => rfl
  | .intParam e | .readHeap _ e | .readLocal _ e | .extraRatNum e | .extraRatDen e | .neg e => by
      simp [UL.evalIntExpr, intExprOps, evalIntExpr_ops bw fd ws e]
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ | .add e₁ e₂ | .sub e₁ e₂
  | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ => by
      simp [UL.evalIntExpr, intExprOps, evalIntExpr_ops bw fd ws e₁, evalIntExpr_ops bw fd ws e₂]

private theorem evalRealExpr_ops {d : ℕ} (inp : UL.ArithRAMInput d) (fd : ℕ)
    (mem : UL.ArithRAMMemory) :
    ∀ r : UL.RealExpr, (UL.evalRealExpr inp fd mem r).2 = realExprOps r
  | .ofInt e | .readRealHeap _ e | .readRealLocal _ e | .extraReal e => by
      simp [UL.evalRealExpr, realExprOps, evalIntExpr_ops]
  | .activePtCoord e₁ e₂ => by
      simp [UL.evalRealExpr, realExprOps, evalIntExpr_ops]
  | .neg r => by
      simp [UL.evalRealExpr, realExprOps, evalRealExpr_ops inp fd mem r]
  | .add r₁ r₂ | .sub r₁ r₂ | .mul r₁ r₂ | .div r₁ r₂ => by
      simp [UL.evalRealExpr, realExprOps, evalRealExpr_ops inp fd mem r₁,
        evalRealExpr_ops inp fd mem r₂]

private theorem evalArithCond_ops {d : ℕ} (inp : UL.ArithRAMInput d) (fd : ℕ)
    (mem : UL.ArithRAMMemory) :
    ∀ c : UL.ArithCondExpr, (UL.evalArithCond inp fd mem c).2 = condExprOps c
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => by
      simp [UL.evalArithCond, condExprOps, evalIntExpr_ops]
  | .realEq r₁ r₂ | .realLt r₁ r₂ | .realLe r₁ r₂ => by
      simp [UL.evalArithCond, condExprOps, evalRealExpr_ops]
  | .not c => by
      simp [UL.evalArithCond, condExprOps, evalArithCond_ops inp fd mem c]
  | .and c₁ c₂ | .or c₁ c₂ => by
      simp [UL.evalArithCond, condExprOps, evalArithCond_ops inp fd mem c₁,
        evalArithCond_ops inp fd mem c₂]

private def iVal {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (e : UL.IntExpr) : ℤ :=
  (UL.evalIntExpr inp.toWordView 0 mem.words e).1

private noncomputable def rVal {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (r : UL.RealExpr) : ℝ :=
  (UL.evalRealExpr inp 0 mem r).1

private noncomputable def cVal {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (c : UL.ArithCondExpr) : Bool :=
  (UL.evalArithCond inp 0 mem c).1

@[simp] private theorem iVal_lit {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (c : ℤ) : iVal inp mem (.lit c) = c := rfl
@[simp] private theorem iVal_dim {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory) :
    iVal inp mem .dim = (d : ℤ) := rfl
@[simp] private theorem iVal_readHeap {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (t : ℕ) (e : UL.IntExpr) : iVal inp mem (.readHeap t e) = wRead mem t (iVal inp mem e) := rfl
@[simp] private theorem iVal_intParam {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (e : UL.IntExpr) :
    iVal inp mem (.intParam e) = UL.listGetIntD inp.intParams (iVal inp mem e) 0 := rfl
@[simp] private theorem iVal_add {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (e₁ e₂ : UL.IntExpr) : iVal inp mem (.add e₁ e₂) = iVal inp mem e₁ + iVal inp mem e₂ := rfl
@[simp] private theorem iVal_sub {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (e₁ e₂ : UL.IntExpr) : iVal inp mem (.sub e₁ e₂) = iVal inp mem e₁ - iVal inp mem e₂ := rfl
@[simp] private theorem iVal_mul {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (e₁ e₂ : UL.IntExpr) : iVal inp mem (.mul e₁ e₂) = iVal inp mem e₁ * iVal inp mem e₂ := rfl

@[simp] private theorem rVal_ofInt {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (e : UL.IntExpr) : rVal inp mem (.ofInt e) = (iVal inp mem e : ℝ) := rfl
@[simp] private theorem rVal_readRealHeap {d : ℕ} (inp : UL.ArithRAMInput d)
    (mem : UL.ArithRAMMemory) (t : ℕ) (e : UL.IntExpr) :
    rVal inp mem (.readRealHeap t e) = rRead mem t (iVal inp mem e) := rfl
@[simp] private theorem rVal_extraReal {d : ℕ} (inp : UL.ArithRAMInput d)
    (mem : UL.ArithRAMMemory) (e : UL.IntExpr) :
    rVal inp mem (.extraReal e) = UL.listGetIntD inp.extraReals (iVal inp mem e) 0 := rfl
@[simp] private theorem rVal_add {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (r₁ r₂ : UL.RealExpr) : rVal inp mem (.add r₁ r₂) = rVal inp mem r₁ + rVal inp mem r₂ := rfl
@[simp] private theorem rVal_sub {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (r₁ r₂ : UL.RealExpr) : rVal inp mem (.sub r₁ r₂) = rVal inp mem r₁ - rVal inp mem r₂ := rfl
@[simp] private theorem rVal_mul {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (r₁ r₂ : UL.RealExpr) : rVal inp mem (.mul r₁ r₂) = rVal inp mem r₁ * rVal inp mem r₂ := rfl
@[simp] private theorem rVal_div {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (r₁ r₂ : UL.RealExpr) : rVal inp mem (.div r₁ r₂) = rVal inp mem r₁ / rVal inp mem r₂ := rfl

@[simp] private theorem cVal_intEq {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (e₁ e₂ : UL.IntExpr) :
    cVal inp mem (.intEq e₁ e₂) = decide (iVal inp mem e₁ = iVal inp mem e₂) := rfl
@[simp] private theorem cVal_intLt {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (e₁ e₂ : UL.IntExpr) :
    cVal inp mem (.intLt e₁ e₂) = decide (iVal inp mem e₁ < iVal inp mem e₂) := rfl
@[simp] private theorem cVal_realEq {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (r₁ r₂ : UL.RealExpr) :
    cVal inp mem (.realEq r₁ r₂) =
      (open Classical in decide (rVal inp mem r₁ = rVal inp mem r₂)) := rfl
@[simp] private theorem cVal_realLt {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (r₁ r₂ : UL.RealExpr) :
    cVal inp mem (.realLt r₁ r₂) =
      (open Classical in decide (rVal inp mem r₁ < rVal inp mem r₂)) := rfl
@[simp] private theorem cVal_not {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (c : UL.ArithCondExpr) : cVal inp mem (.not c) = !(cVal inp mem c) := rfl
@[simp] private theorem cVal_and {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (c₁ c₂ : UL.ArithCondExpr) :
    cVal inp mem (.and c₁ c₂) = (cVal inp mem c₁ && cVal inp mem c₂) := rfl

private theorem runArithRAMFuel_mono {d : ℕ} (inp : UL.ArithRAMInput d) :
    ∀ {fuel₁ fuel₂ : ℕ} {stack : List UL.ArithRAMCont} {st : UL.ArithRAMExecState}
      {res : UL.ArithRAMRunStatus},
      res ≠ .outOfFuel →
      fuel₁ ≤ fuel₂ →
      UL.runArithRAMFuel inp fuel₁ stack st = res →
      UL.runArithRAMFuel inp fuel₂ stack st = res
  | f₁, f₂, [], st, res, _, _, hrun => by
      cases f₁ <;> cases f₂ <;> simpa [UL.runArithRAMFuel] using hrun
  | 0, _, _ :: _, _, res, hne, _, hrun => by
      simp [UL.runArithRAMFuel] at hrun
      exact absurd hrun.symm hne
  | f₁ + 1, 0, _ :: _, _, _, _, hle, _ => by omega
  | f₁ + 1, f₂ + 1, item :: rest, st, res, hne, hle, hrun => by
      have hle' : f₁ ≤ f₂ := by omega
      cases item with
      | popScope prev =>
          simp only [UL.runArithRAMFuel] at hrun ⊢
          exact runArithRAMFuel_mono inp hne hle' hrun
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [UL.runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | succ r =>
              simp only [UL.runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
      | stmt s =>
          cases s with
          | skip | writeWordHeap _ _ _ | writeWordLocal _ _ _ | freeWordHeap _ _
          | freeWordLocal _ _ | writeRealHeap _ _ _ | writeRealLocal _ _ _
          | freeRealHeap _ _ | freeRealLocal _ _ | seq _ _ | ite _ _ _
          | whileLoop _ _ | repeatN _ _ | localScope _ =>
              simp only [UL.runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | randBitHeap table idxE =>
              cases hbits : st.remainingBits with
              | nil => simpa [UL.runArithRAMFuel, hbits] using hrun
              | cons bit bs' =>
                  simp only [UL.runArithRAMFuel, hbits] at hrun ⊢
                  exact runArithRAMFuel_mono inp hne hle' hrun
          | randBitLocal var idxE =>
              cases hbits : st.remainingBits with
              | nil => simpa [UL.runArithRAMFuel, hbits] using hrun
              | cons bit bs' =>
                  simp only [UL.runArithRAMFuel, hbits] at hrun ⊢
                  exact runArithRAMFuel_mono inp hne hle' hrun

private theorem runArithRAMWithBits_eq_some_of_fuel {d : ℕ} (prog : UL.ArithRAMStmt)
    (inp : UL.ArithRAMInput d) (initMem : UL.ArithRAMMemory) (bs : List Bool)
    (fuel : ℕ) (out : UL.ArithRAMExecOutcome)
    (hrun : UL.runArithRAMFuel inp fuel [.stmt prog]
      { mem := initMem.popDepth 0
        frameDepth := 0
        remainingBits := bs
        unitCost := 0
        peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } = .halted out) :
    UL.runArithRAMWithBits prog inp initMem bs = some out := by
  classical
  unfold UL.runArithRAMWithBits
  dsimp only
  have hex : ∃ f : ℕ, ∃ o : UL.ArithRAMExecOutcome,
      UL.runArithRAMFuel inp f [.stmt prog]
        { mem := initMem.popDepth 0, frameDepth := 0, remainingBits := bs,
          unitCost := 0, peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } =
        .halted o := ⟨fuel, out, hrun⟩
  rw [dif_pos hex]
  have hle : Nat.find hex ≤ fuel := Nat.find_min' hex ⟨out, hrun⟩
  rcases Nat.find_spec hex with ⟨o₀, ho₀⟩
  have heq : UL.ArithRAMRunStatus.halted o₀ = .halted out := by
    have hm := runArithRAMFuel_mono inp (by simp) hle ho₀
    rw [hrun] at hm
    exact hm.symm
  cases heq
  simp [ho₀]

private theorem runArithRAMWithBits_eq_none_of_status {d : ℕ} (prog : UL.ArithRAMStmt)
    (inp : UL.ArithRAMInput d) (initMem : UL.ArithRAMMemory) (bs : List Bool)
    (fuel : ℕ) (res : UL.ArithRAMRunStatus)
    (hnot_fuel : res ≠ .outOfFuel)
    (hnot_halt : ∀ o, res ≠ .halted o)
    (hrun : UL.runArithRAMFuel inp fuel [.stmt prog]
      { mem := initMem.popDepth 0
        frameDepth := 0
        remainingBits := bs
        unitCost := 0
        peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } = res) :
    UL.runArithRAMWithBits prog inp initMem bs = none := by
  classical
  unfold UL.runArithRAMWithBits
  dsimp only
  split_ifs with hex
  · exfalso
    rcases hex with ⟨f₁, out, hf₁⟩
    have hm₁ := runArithRAMFuel_mono inp (by simp) (Nat.le_max_left f₁ fuel) hf₁
    have hm₂ := runArithRAMFuel_mono inp hnot_fuel (Nat.le_max_right f₁ fuel) hrun
    rw [hm₁] at hm₂
    exact hnot_halt out hm₂.symm
  · rfl

/-! ### 2. Compositional `DetExec` and `RandExec` combinators -/

private def DetExec {d : ℕ} (inp : UL.ArithRAMInput d) (s : UL.ArithRAMStmt)
    (mem₀ mem₁ : UL.ArithRAMMemory) (costBound : ℕ) : Prop :=
  ∀ (bs : List Bool) (u₀ peak₀ : ℕ) (rest : List UL.ArithRAMCont),
    ∃ (fuel u₁ peak₁ : ℕ),
      u₁ ≤ u₀ + costBound ∧
      ∀ f_rem : ℕ,
        UL.runArithRAMFuel inp (fuel + f_rem) (.stmt s :: rest)
          { mem := mem₀, frameDepth := 0, remainingBits := bs,
            unitCost := u₀, peakCellSpace := peak₀ } =
        UL.runArithRAMFuel inp f_rem rest
          { mem := mem₁, frameDepth := 0, remainingBits := bs,
            unitCost := u₁, peakCellSpace := peak₁ }

private theorem DetExec.mono_cost {d : ℕ} {inp : UL.ArithRAMInput d} {s : UL.ArithRAMStmt}
    {mem₀ mem₁ : UL.ArithRAMMemory} {c₁ c₂ : ℕ}
    (h : DetExec inp s mem₀ mem₁ c₁) (hle : c₁ ≤ c₂) :
    DetExec inp s mem₀ mem₁ c₂ := by
  intro bs u₀ peak₀ rest
  rcases h bs u₀ peak₀ rest with ⟨fuel, u₁, peak₁, hu₁, hstep⟩
  exact ⟨fuel, u₁, peak₁, by omega, hstep⟩

private theorem DetExec.skip {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory) :
    DetExec inp .skip mem mem 1 := by
  intro bs u₀ peak₀ rest
  refine ⟨1, u₀ + 1, peak₀, le_rfl, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  rfl

private theorem DetExec.writeWord {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (t : ℕ) (idxE valE : UL.IntExpr) {idx val : ℤ} {C : ℕ}
    (hidx : iVal inp mem idxE = idx)
    (hval : iVal inp mem valE = val)
    (hcost : intExprOps idxE + intExprOps valE + 1 ≤ C) :
    DetExec inp (.writeWordHeap t idxE valE) mem (wWrite mem t idx val) C := by
  intro bs u₀ peak₀ rest
  rcases he₁ : UL.evalIntExpr inp.toWordView 0 mem.words idxE with ⟨idx', u₁, b₁⟩
  rcases he₂ : UL.evalIntExpr inp.toWordView 0 mem.words valE with ⟨val', u₂, b₂⟩
  have hi : idx' = idx := by rw [← hidx, iVal, he₁]
  have hv : val' = val := by rw [← hval, iVal, he₂]
  have hu₁ : u₁ = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView 0 mem.words idxE
    rw [he₁] at this; exact this
  have hu₂ : u₂ = intExprOps valE := by
    have := evalIntExpr_ops inp.toWordView 0 mem.words valE
    rw [he₂] at this; exact this
  subst hi; subst hv
  refine ⟨1, u₀ + u₁ + u₂ + 1,
    max peak₀ (inp.inputCellSpace + (wWrite mem t idx' val').cellCount), by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  dsimp only [UL.runArithRAMFuel]
  rw [he₁, he₂]
  rfl

private theorem DetExec.writeReal {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (t : ℕ) (idxE : UL.IntExpr) (valE : UL.RealExpr) {idx : ℤ} {val : ℝ} {C : ℕ}
    (hidx : iVal inp mem idxE = idx)
    (hval : rVal inp mem valE = val)
    (hcost : intExprOps idxE + realExprOps valE + 1 ≤ C) :
    DetExec inp (.writeRealHeap t idxE valE) mem (rWrite mem t idx val) C := by
  intro bs u₀ peak₀ rest
  rcases he₁ : UL.evalIntExpr inp.toWordView 0 mem.words idxE with ⟨idx', u₁, b₁⟩
  rcases he₂ : UL.evalRealExpr inp 0 mem valE with ⟨val', u₂⟩
  have hi : idx' = idx := by rw [← hidx, iVal, he₁]
  have hv : val' = val := by rw [← hval, rVal, he₂]
  have hu₁ : u₁ = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView 0 mem.words idxE
    rw [he₁] at this; exact this
  have hu₂ : u₂ = realExprOps valE := by
    have := evalRealExpr_ops inp 0 mem valE
    rw [he₂] at this; exact this
  subst hi; subst hv
  refine ⟨1, u₀ + u₁ + u₂ + 1,
    max peak₀ (inp.inputCellSpace + (rWrite mem t idx' val').cellCount), by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  dsimp only [UL.runArithRAMFuel]
  rw [he₁, he₂]
  rfl

private theorem DetExec.seq {d : ℕ} {inp : UL.ArithRAMInput d} {s₁ s₂ : UL.ArithRAMStmt}
    {mem₀ mem₁ mem₂ : UL.ArithRAMMemory} {C₁ C₂ : ℕ}
    (h₁ : DetExec inp s₁ mem₀ mem₁ C₁)
    (h₂ : DetExec inp s₂ mem₁ mem₂ C₂) :
    DetExec inp (.seq s₁ s₂) mem₀ mem₂ (C₁ + C₂) := by
  intro bs u₀ peak₀ rest
  rcases h₁ bs u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
  rcases h₂ bs u₁ peak₁ rest with ⟨f₂, u₂, peak₂, hu₂, hs₂⟩
  refine ⟨1 + f₁ + f₂, u₂, peak₂, by omega, fun f_rem => ?_⟩
  have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
  rw [hf]
  dsimp only [UL.runArithRAMFuel]
  rw [hs₁ (f₂ + f_rem), hs₂ f_rem]

private theorem DetExec.ite_true {d : ℕ} {inp : UL.ArithRAMInput d} {cond : UL.ArithCondExpr}
    {tB fB : UL.ArithRAMStmt} {mem₀ mem₁ : UL.ArithRAMMemory} {C_c C_b : ℕ}
    (hcond : cVal inp mem₀ cond = true)
    (hcc : condExprOps cond ≤ C_c)
    (ht : DetExec inp tB mem₀ mem₁ C_b) :
    DetExec inp (.ite cond tB fB) mem₀ mem₁ (C_c + C_b) := by
  intro bs u₀ peak₀ rest
  rcases hc : UL.evalArithCond inp 0 mem₀ cond with ⟨flag, u_c⟩
  have hflag : flag = true := by rw [← hcond, cVal, hc]
  have huc : u_c = condExprOps cond := by
    have := evalArithCond_ops inp 0 mem₀ cond; rw [hc] at this; exact this
  subst hflag
  rcases ht bs (u₀ + u_c) peak₀ rest with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
  refine ⟨1 + f₁, u₁, peak₁, by omega, fun f_rem => ?_⟩
  have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
  rw [hf]
  simp only [UL.runArithRAMFuel, hc, ↓reduceIte]
  exact hs₁ f_rem

private theorem DetExec.ite_false {d : ℕ} {inp : UL.ArithRAMInput d} {cond : UL.ArithCondExpr}
    {tB fB : UL.ArithRAMStmt} {mem₀ mem₁ : UL.ArithRAMMemory} {C_c C_b : ℕ}
    (hcond : cVal inp mem₀ cond = false)
    (hcc : condExprOps cond ≤ C_c)
    (hfB : DetExec inp fB mem₀ mem₁ C_b) :
    DetExec inp (.ite cond tB fB) mem₀ mem₁ (C_c + C_b) := by
  intro bs u₀ peak₀ rest
  rcases hc : UL.evalArithCond inp 0 mem₀ cond with ⟨flag, u_c⟩
  have hflag : flag = false := by rw [← hcond, cVal, hc]
  have huc : u_c = condExprOps cond := by
    have := evalArithCond_ops inp 0 mem₀ cond; rw [hc] at this; exact this
  subst hflag
  rcases hfB bs (u₀ + u_c) peak₀ rest with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
  refine ⟨1 + f₁, u₁, peak₁, by omega, fun f_rem => ?_⟩
  have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
  rw [hf]
  simp only [UL.runArithRAMFuel, hc, Bool.false_eq_true, ↓reduceIte]
  exact hs₁ f_rem

private theorem DetExec.whileLoop_false {d : ℕ} {inp : UL.ArithRAMInput d}
    {cond : UL.ArithCondExpr} {body : UL.ArithRAMStmt} {mem : UL.ArithRAMMemory} {C_c : ℕ}
    (hcond : cVal inp mem cond = false)
    (hcc : condExprOps cond ≤ C_c) :
    DetExec inp (.whileLoop cond body) mem mem C_c := by
  intro bs u₀ peak₀ rest
  rcases hc : UL.evalArithCond inp 0 mem cond with ⟨flag, u_c⟩
  have hflag : flag = false := by rw [← hcond, cVal, hc]
  have huc : u_c = condExprOps cond := by
    have := evalArithCond_ops inp 0 mem cond; rw [hc] at this; exact this
  subst hflag
  refine ⟨1, u₀ + u_c, peak₀, by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  simp only [UL.runArithRAMFuel, hc, Bool.false_eq_true, ↓reduceIte]

private theorem DetExec.whileLoop_true {d : ℕ} {inp : UL.ArithRAMInput d}
    {cond : UL.ArithCondExpr} {body : UL.ArithRAMStmt} {mem₀ mem₁ mem₂ : UL.ArithRAMMemory}
    {C_c C_b C_rest : ℕ}
    (hcond : cVal inp mem₀ cond = true)
    (hcc : condExprOps cond ≤ C_c)
    (hbody : DetExec inp body mem₀ mem₁ C_b)
    (hrest : DetExec inp (.whileLoop cond body) mem₁ mem₂ C_rest) :
    DetExec inp (.whileLoop cond body) mem₀ mem₂ (C_c + C_b + C_rest) := by
  intro bs u₀ peak₀ rest
  rcases hc : UL.evalArithCond inp 0 mem₀ cond with ⟨flag, u_c⟩
  have hflag : flag = true := by rw [← hcond, cVal, hc]
  have huc : u_c = condExprOps cond := by
    have := evalArithCond_ops inp 0 mem₀ cond; rw [hc] at this; exact this
  subst hflag
  rcases hbody bs (u₀ + u_c) peak₀ (.stmt (.whileLoop cond body) :: rest) with
    ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
  rcases hrest bs u₁ peak₁ rest with ⟨f₂, u₂, peak₂, hu₂, hs₂⟩
  refine ⟨1 + f₁ + f₂, u₂, peak₂, by omega, fun f_rem => ?_⟩
  have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
  rw [hf]
  simp only [UL.runArithRAMFuel, hc, ↓reduceIte]
  rw [hs₁ (f₂ + f_rem), hs₂ f_rem]

private theorem DetExec.whileLoop_nat {d : ℕ} {inp : UL.ArithRAMInput d}
    (cond : UL.ArithCondExpr) (body : UL.ArithRAMStmt) (N C_c C_b : ℕ)
    (Inv : ℕ → UL.ArithRAMMemory → Prop)
    (hcc : condExprOps cond ≤ C_c)
    {mem₀ : UL.ArithRAMMemory} (hInv₀ : Inv 0 mem₀)
    (hstep : ∀ i < N, ∀ m, Inv i m →
      cVal inp m cond = true ∧ ∃ m', DetExec inp body m m' C_b ∧ Inv (i + 1) m')
    (hexit : ∀ m, Inv N m → cVal inp m cond = false) :
    ∃ mem_N, Inv N mem_N ∧
      DetExec inp (.whileLoop cond body) mem₀ mem_N ((N + 1) * C_c + N * C_b) := by
  suffices hrem : ∀ k : ℕ, k ≤ N → ∀ m, Inv (N - k) m →
      ∃ m_N, Inv N m_N ∧
        DetExec inp (.whileLoop cond body) m m_N ((k + 1) * C_c + k * C_b) by
    simpa using hrem N le_rfl mem₀ (by simpa using hInv₀)
  intro k
  induction k with
  | zero =>
      intro _ m hIm
      rw [Nat.sub_zero] at hIm
      refine ⟨m, hIm, ?_⟩
      simpa using DetExec.whileLoop_false (hexit m hIm) hcc
  | succ k ih =>
      intro hk m hIm
      have hi_lt : N - (k + 1) < N := by omega
      have hsucc : N - (k + 1) + 1 = N - k := by omega
      rcases hstep (N - (k + 1)) hi_lt m hIm with ⟨hcond, m', hbody, hIm'⟩
      rw [hsucc] at hIm'
      rcases ih (by omega) m' hIm' with ⟨m_N, hIm_N, hrest⟩
      refine ⟨m_N, hIm_N, ?_⟩
      refine (DetExec.whileLoop_true hcond hcc hbody hrest).mono_cost ?_
      linarith

private theorem DetExec.repeatN_nat {d : ℕ} {inp : UL.ArithRAMInput d}
    (countE : UL.IntExpr) (body : UL.ArithRAMStmt) (N C_cnt C_b : ℕ) (Inv : ℕ → UL.ArithRAMMemory → Prop)
    {mem₀ : UL.ArithRAMMemory} (hInv₀ : Inv 0 mem₀)
    (hcnt : iVal inp mem₀ countE = (N : ℤ))
    (hccnt : intExprOps countE ≤ C_cnt)
    (hstep : ∀ i < N, ∀ m, Inv i m → ∃ m', DetExec inp body m m' C_b ∧ Inv (i + 1) m') :
    ∃ mem_N, Inv N mem_N ∧
      DetExec inp (.repeatN countE body) mem₀ mem_N (C_cnt + N * C_b) := by
  have hloop : ∀ k : ℕ, k ≤ N → ∀ m, Inv (N - k) m →
      ∃ m_N, Inv N m_N ∧
        ∀ (bs : List Bool) (u₀ peak₀ : ℕ) (rest : List UL.ArithRAMCont),
          ∃ (fuel u₁ peak₁ : ℕ),
            u₁ ≤ u₀ + k * C_b ∧
            ∀ f_rem : ℕ,
              UL.runArithRAMFuel inp (fuel + f_rem) (.repeatLoop k body :: rest)
                { mem := m, frameDepth := 0, remainingBits := bs,
                  unitCost := u₀, peakCellSpace := peak₀ } =
              UL.runArithRAMFuel inp f_rem rest
                { mem := m_N, frameDepth := 0, remainingBits := bs,
                  unitCost := u₁, peakCellSpace := peak₁ } := by
    intro k
    induction k with
    | zero =>
        intro _ m hIm
        rw [Nat.sub_zero] at hIm
        refine ⟨m, hIm, fun bs u₀ peak₀ rest => ⟨1, u₀, peak₀, by simp, fun f_rem => ?_⟩⟩
        rw [Nat.add_comm 1 f_rem]
        rfl
    | succ k ih =>
        intro hk m hIm
        have hi_lt : N - (k + 1) < N := by omega
        have hsucc : N - (k + 1) + 1 = N - k := by omega
        rcases hstep (N - (k + 1)) hi_lt m hIm with ⟨m', hbody, hIm'⟩
        rw [hsucc] at hIm'
        rcases ih (by omega) m' hIm' with ⟨m_N, hIm_N, hrest⟩
        refine ⟨m_N, hIm_N, fun bs u₀ peak₀ rest => ?_⟩
        rcases hbody bs u₀ peak₀ (.repeatLoop k body :: rest) with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
        rcases hrest bs u₁ peak₁ rest with ⟨f₂, u₂, peak₂, hu₂, hs₂⟩
        refine ⟨1 + f₁ + f₂, u₂, peak₂, ?_, fun f_rem => ?_⟩
        · have : u₂ ≤ u₀ + C_b + k * C_b := by omega
          calc u₂ ≤ u₀ + C_b + k * C_b := this
            _ = u₀ + (k + 1) * C_b := by ring
        · have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
          rw [hf]
          dsimp only [UL.runArithRAMFuel]
          rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
  rcases hloop N le_rfl mem₀ (by simpa using hInv₀) with ⟨m_N, hIm_N, hrun⟩
  refine ⟨m_N, hIm_N, fun bs u₀ peak₀ rest => ?_⟩
  rcases he : UL.evalIntExpr inp.toWordView 0 mem₀.words countE with ⟨cnt, u_cnt, b_cnt⟩
  have hcnt' : cnt = (N : ℤ) := by rw [← hcnt, iVal, he]
  have hucnt : u_cnt = intExprOps countE := by
    have := evalIntExpr_ops inp.toWordView 0 mem₀.words countE; rw [he] at this; exact this
  subst hcnt'
  rcases hrun bs (u₀ + u_cnt) peak₀ rest with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
  refine ⟨1 + f₁, u₁, peak₁, by omega, fun f_rem => ?_⟩
  have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
  rw [hf]
  have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
  simp only [UL.runArithRAMFuel, he, hnIter]
  exact hs₁ f_rem

private def RandExec {d : ℕ} (inp : UL.ArithRAMInput d) (s : UL.ArithRAMStmt)
    (numBits : ℕ) (mem₀ : UL.ArithRAMMemory)
    (Post : (Fin numBits → Bool) → UL.ArithRAMMemory → Prop) (costBound : ℕ) : Prop :=
  (∀ (bs : List Bool), bs.length < numBits →
    ∀ (u₀ peak₀ : ℕ) (rest : List UL.ArithRAMCont),
      ∃ fuel : ℕ, ∀ f_rem : ℕ,
        UL.runArithRAMFuel inp (fuel + f_rem) (.stmt s :: rest)
          { mem := mem₀, frameDepth := 0, remainingBits := bs,
            unitCost := u₀, peakCellSpace := peak₀ } = .needMoreBits) ∧
  (∀ (bs : List Bool) (hbs : numBits ≤ bs.length) (u₀ peak₀ : ℕ) (rest : List UL.ArithRAMCont),
    ∃ (fuel u₁ peak₁ : ℕ) (mem₁ : UL.ArithRAMMemory),
      u₁ ≤ u₀ + costBound ∧
      Post (fun j : Fin numBits => bs[j.val]'(lt_of_lt_of_le j.isLt hbs)) mem₁ ∧
      ∀ f_rem : ℕ,
        UL.runArithRAMFuel inp (fuel + f_rem) (.stmt s :: rest)
          { mem := mem₀, frameDepth := 0, remainingBits := bs,
            unitCost := u₀, peakCellSpace := peak₀ } =
        UL.runArithRAMFuel inp f_rem rest
          { mem := mem₁, frameDepth := 0, remainingBits := bs.drop numBits,
            unitCost := u₁, peakCellSpace := peak₁ })

private theorem RandExec.mono {d : ℕ} {inp : UL.ArithRAMInput d} {s : UL.ArithRAMStmt}
    {B : ℕ} {mem₀ : UL.ArithRAMMemory}
    {Post₁ Post₂ : (Fin B → Bool) → UL.ArithRAMMemory → Prop} {c₁ c₂ : ℕ}
    (h : RandExec inp s B mem₀ Post₁ c₁)
    (hPost : ∀ f m, Post₁ f m → Post₂ f m)
    (hc : c₁ ≤ c₂) :
    RandExec inp s B mem₀ Post₂ c₂ := by
  refine ⟨h.1, fun bs hbs u₀ peak₀ rest => ?_⟩
  rcases h.2 bs hbs u₀ peak₀ rest with ⟨fuel, u₁, peak₁, mem₁, hu₁, hp₁, hstep⟩
  exact ⟨fuel, u₁, peak₁, mem₁, by omega, hPost _ _ hp₁, hstep⟩

private theorem RandExec.cast_bits {d : ℕ} {inp : UL.ArithRAMInput d} {s : UL.ArithRAMStmt}
    {B₁ B₂ : ℕ} (heq : B₁ = B₂) {mem₀ : UL.ArithRAMMemory}
    {Post₁ : (Fin B₁ → Bool) → UL.ArithRAMMemory → Prop}
    {Post₂ : (Fin B₂ → Bool) → UL.ArithRAMMemory → Prop} {C : ℕ}
    (h : RandExec inp s B₁ mem₀ Post₁ C)
    (hPost : ∀ (f : Fin B₂ → Bool) (m : UL.ArithRAMMemory),
      Post₁ (fun i : Fin B₁ => f ⟨i.val, heq ▸ i.isLt⟩) m → Post₂ f m) :
    RandExec inp s B₂ mem₀ Post₂ C := by
  subst heq
  exact h.mono hPost le_rfl

private theorem RandExec.randBit {d : ℕ} (inp : UL.ArithRAMInput d) (mem : UL.ArithRAMMemory)
    (t : ℕ) (idxE : UL.IntExpr) {idx : ℤ} {C : ℕ}
    (hidx : iVal inp mem idxE = idx)
    (hcost : intExprOps idxE + 1 ≤ C) :
    RandExec inp (.randBitHeap t idxE) 1 mem
      (fun f m' => m' = wWrite mem t idx (if f ⟨0, Nat.zero_lt_one⟩ then 1 else 0)) C := by
  constructor
  · intro bs hbs u₀ peak₀ rest
    cases bs with
    | nil =>
        refine ⟨1, fun f_rem => ?_⟩
        rw [Nat.add_comm 1 f_rem]
        rfl
    | cons _ _ => simp at hbs
  · intro bs hbs u₀ peak₀ rest
    cases bs with
    | nil => simp at hbs
    | cons bit bs' =>
        rcases he : UL.evalIntExpr inp.toWordView 0 mem.words idxE with ⟨idx', u₁, b₁⟩
        have hi : idx' = idx := by rw [← hidx, iVal, he]
        have hu₁ : u₁ = intExprOps idxE := by
          have := evalIntExpr_ops inp.toWordView 0 mem.words idxE; rw [he] at this; exact this
        subst hi
        let m' := wWrite mem t idx' (if bit then 1 else 0)
        refine ⟨1, u₀ + u₁ + 1, max peak₀ (inp.inputCellSpace + m'.cellCount), m',
          by omega, rfl, fun f_rem => ?_⟩
        rw [Nat.add_comm 1 f_rem]
        dsimp only [UL.runArithRAMFuel, List.drop]
        rw [he]
        rfl

private theorem RandExec.seq_det_left {d : ℕ} {inp : UL.ArithRAMInput d}
    {s₁ s₂ : UL.ArithRAMStmt} {B : ℕ} {mem₀ mem₁ : UL.ArithRAMMemory}
    {Post : (Fin B → Bool) → UL.ArithRAMMemory → Prop} {C₁ C₂ : ℕ}
    (h₁ : DetExec inp s₁ mem₀ mem₁ C₁)
    (h₂ : RandExec inp s₂ B mem₁ Post C₂) :
    RandExec inp (.seq s₁ s₂) B mem₀ Post (C₁ + C₂) := by
  constructor
  · intro bs hbs u₀ peak₀ rest
    rcases h₁ bs u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, peak₁, _, hs₁⟩
    rcases h₂.1 bs hbs u₁ peak₁ rest with ⟨f₂, hs₂⟩
    refine ⟨1 + f₁ + f₂, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
    rw [hf]
    dsimp only [UL.runArithRAMFuel]
    rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
  · intro bs hbs u₀ peak₀ rest
    rcases h₁ bs u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
    rcases h₂.2 bs hbs u₁ peak₁ rest with ⟨f₂, u₂, peak₂, mem₂, hu₂, hp₂, hs₂⟩
    refine ⟨1 + f₁ + f₂, u₂, peak₂, mem₂, by omega, hp₂, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
    rw [hf]
    dsimp only [UL.runArithRAMFuel]
    rw [hs₁ (f₂ + f_rem), hs₂ f_rem]

private theorem RandExec.seq_det_right {d : ℕ} {inp : UL.ArithRAMInput d}
    {s₁ s₂ : UL.ArithRAMStmt} {B : ℕ} {mem₀ : UL.ArithRAMMemory}
    {Post₁ Post₂ : (Fin B → Bool) → UL.ArithRAMMemory → Prop} {C₁ C₂ : ℕ}
    (h₁ : RandExec inp s₁ B mem₀ Post₁ C₁)
    (h₂ : ∀ f m₁, Post₁ f m₁ → ∃ m₂, DetExec inp s₂ m₁ m₂ C₂ ∧ Post₂ f m₂) :
    RandExec inp (.seq s₁ s₂) B mem₀ Post₂ (C₁ + C₂) := by
  constructor
  · intro bs hbs u₀ peak₀ rest
    rcases h₁.1 bs hbs u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, hs₁⟩
    refine ⟨1 + f₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    rw [hf]
    dsimp only [UL.runArithRAMFuel]
    exact hs₁ f_rem
  · intro bs hbs u₀ peak₀ rest
    rcases h₁.2 bs hbs u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, peak₁, mem₁, hu₁, hp₁, hs₁⟩
    rcases h₂ _ mem₁ hp₁ with ⟨mem₂, hd₂, hp₂⟩
    rcases hd₂ (bs.drop B) u₁ peak₁ rest with ⟨f₂, u₂, peak₂, hu₂, hs₂⟩
    refine ⟨1 + f₁ + f₂, u₂, peak₂, mem₂, by omega, hp₂, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
    rw [hf]
    dsimp only [UL.runArithRAMFuel]
    rw [hs₁ (f₂ + f_rem), hs₂ f_rem]

private theorem RandExec.repeatN_nat {d : ℕ} {inp : UL.ArithRAMInput d}
    (countE : UL.IntExpr) (body : UL.ArithRAMStmt) (N K C_cnt C_b : ℕ)
    (Inv : (i : ℕ) → (Fin (i * K) → Bool) → UL.ArithRAMMemory → Prop)
    {mem₀ : UL.ArithRAMMemory}
    (hInv₀ : ∀ f₀ : Fin (0 * K) → Bool, Inv 0 f₀ mem₀)
    (hcnt : iVal inp mem₀ countE = (N : ℤ))
    (hccnt : intExprOps countE ≤ C_cnt)
    (hstep : ∀ (i : ℕ), i < N → ∀ (f_prev : Fin (i * K) → Bool) (m : UL.ArithRAMMemory),
      Inv i f_prev m →
      RandExec inp body K m
        (fun (f_cur : Fin K → Bool) m' =>
          ∀ f_next : Fin ((i + 1) * K) → Bool,
            (∀ x : Fin (i * K),
              f_next ⟨x.val, lt_of_lt_of_le x.isLt (Nat.mul_le_mul_right K (Nat.le_succ i))⟩ =
                f_prev x) →
            (∀ y : Fin K,
              f_next ⟨i * K + y.val, by rw [Nat.succ_mul]; exact Nat.add_lt_add_left y.isLt _⟩ =
                f_cur y) →
            Inv (i + 1) f_next m')
        C_b) :
    RandExec inp (.repeatN countE body) (N * K) mem₀ (Inv N) (C_cnt + N * C_b) := by
  have hshort : ∀ (bs₀ : List Bool), bs₀.length < N * K →
      ∀ (rem i : ℕ), i + rem = N → ∀ (m : UL.ArithRAMMemory) (hi : i * K ≤ bs₀.length),
        Inv i (fun x : Fin (i * K) => bs₀[x.val]'(lt_of_lt_of_le x.isLt hi)) m →
        ∀ (u₀ peak₀ : ℕ) (rest : List UL.ArithRAMCont),
          ∃ fuel : ℕ, ∀ f_rem : ℕ,
            UL.runArithRAMFuel inp (fuel + f_rem) (.repeatLoop rem body :: rest)
              { mem := m, frameDepth := 0, remainingBits := bs₀.drop (i * K),
                unitCost := u₀, peakCellSpace := peak₀ } = .needMoreBits := by
    intro bs₀ hbs₀ rem
    induction rem with
    | zero =>
        intro i hsum _ hi
        have hiN : i = N := by omega
        subst hiN
        omega
    | succ rem ih =>
        intro i hsum m hi hIm u₀ peak₀ rest
        have hi_lt : i < N := by omega
        have hspec := hstep i hi_lt _ m hIm
        by_cases hrem_lt : (bs₀.drop (i * K)).length < K
        · rcases hspec.1 (bs₀.drop (i * K)) hrem_lt u₀ peak₀ (.repeatLoop rem body :: rest) with
            ⟨f₁, hs₁⟩
          refine ⟨1 + f₁, fun f_rem => ?_⟩
          have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
          rw [hf]
          dsimp only [UL.runArithRAMFuel]
          exact hs₁ f_rem
        · have hrem_ge : K ≤ (bs₀.drop (i * K)).length := by omega
          have hi_next : (i + 1) * K ≤ bs₀.length := by
            rw [List.length_drop] at hrem_ge
            rw [Nat.succ_mul]
            omega
          rcases hspec.2 (bs₀.drop (i * K)) hrem_ge u₀ peak₀ (.repeatLoop rem body :: rest) with
            ⟨f₁, u₁, peak₁, m', _, hpost, hs₁⟩
          have hIm' : Inv (i + 1)
              (fun z : Fin ((i + 1) * K) => bs₀[z.val]'(lt_of_lt_of_le z.isLt hi_next)) m' :=
            hpost _ (fun _ => rfl) (fun y => by simp [List.getElem_drop])
          have hdrop_eq : (bs₀.drop (i * K)).drop K = bs₀.drop ((i + 1) * K) := by
            rw [List.drop_drop]
            congr 1
            ring
          rcases ih (i + 1) (by omega) m' hi_next hIm' u₁ peak₁ rest with ⟨f₂, hs₂⟩
          refine ⟨1 + f₁ + f₂, fun f_rem => ?_⟩
          have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
          rw [hf]
          dsimp only [UL.runArithRAMFuel]
          rw [hs₁ (f₂ + f_rem), hdrop_eq, hs₂ f_rem]
  have hfull : ∀ (bs₀ : List Bool) (hbs₀ : N * K ≤ bs₀.length) (rem i : ℕ), i + rem = N →
      ∀ (m : UL.ArithRAMMemory) (hi : i * K ≤ bs₀.length),
        Inv i (fun x : Fin (i * K) => bs₀[x.val]'(lt_of_lt_of_le x.isLt hi)) m →
        ∀ (u₀ peak₀ : ℕ) (rest : List UL.ArithRAMCont),
          ∃ (fuel u₁ peak₁ : ℕ) (m_N : UL.ArithRAMMemory),
            u₁ ≤ u₀ + rem * C_b ∧
            Inv N (fun x : Fin (N * K) => bs₀[x.val]'(lt_of_lt_of_le x.isLt hbs₀)) m_N ∧
            ∀ f_rem : ℕ,
              UL.runArithRAMFuel inp (fuel + f_rem) (.repeatLoop rem body :: rest)
                { mem := m, frameDepth := 0, remainingBits := bs₀.drop (i * K),
                  unitCost := u₀, peakCellSpace := peak₀ } =
              UL.runArithRAMFuel inp f_rem rest
                { mem := m_N, frameDepth := 0, remainingBits := bs₀.drop (N * K),
                  unitCost := u₁, peakCellSpace := peak₁ } := by
    intro bs₀ hbs₀ rem
    induction rem with
    | zero =>
        intro i hsum m hi hIm u₀ peak₀ rest
        have hiN : i = N := by omega
        subst hiN
        refine ⟨1, u₀, peak₀, m, by simp, hIm, fun f_rem => ?_⟩
        rw [Nat.add_comm 1 f_rem]
        rfl
    | succ rem ih =>
        intro i hsum m hi hIm u₀ peak₀ rest
        have hi_lt : i < N := by omega
        have hi_next : (i + 1) * K ≤ bs₀.length :=
          le_trans (Nat.mul_le_mul_right K (by omega)) hbs₀
        have hrem_ge : K ≤ (bs₀.drop (i * K)).length := by
          rw [List.length_drop]
          have : (i + 1) * K = i * K + K := Nat.succ_mul i K
          omega
        have hspec := hstep i hi_lt _ m hIm
        rcases hspec.2 (bs₀.drop (i * K)) hrem_ge u₀ peak₀ (.repeatLoop rem body :: rest) with
          ⟨f₁, u₁, peak₁, m', hu₁, hpost, hs₁⟩
        have hIm' : Inv (i + 1)
            (fun z : Fin ((i + 1) * K) => bs₀[z.val]'(lt_of_lt_of_le z.isLt hi_next)) m' :=
          hpost _ (fun _ => rfl) (fun y => by simp [List.getElem_drop])
        have hdrop_eq : (bs₀.drop (i * K)).drop K = bs₀.drop ((i + 1) * K) := by
          rw [List.drop_drop]
          congr 1
          ring
        rcases ih (i + 1) (by omega) m' hi_next hIm' u₁ peak₁ rest with
          ⟨f₂, u₂, peak₂, m_N, hu₂, hImN, hs₂⟩
        refine ⟨1 + f₁ + f₂, u₂, peak₂, m_N, ?_, hImN, fun f_rem => ?_⟩
        · have : u₂ ≤ u₀ + C_b + rem * C_b := by omega
          calc u₂ ≤ u₀ + C_b + rem * C_b := this
            _ = u₀ + (rem + 1) * C_b := by ring
        · have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
          rw [hf]
          dsimp only [UL.runArithRAMFuel]
          rw [hs₁ (f₂ + f_rem), hdrop_eq, hs₂ f_rem]
  rcases he : UL.evalIntExpr inp.toWordView 0 mem₀.words countE with ⟨cnt, u_cnt, b_cnt⟩
  have hcnt' : cnt = (N : ℤ) := by rw [← hcnt, iVal, he]
  have hucnt : u_cnt = intExprOps countE := by
    have := evalIntExpr_ops inp.toWordView 0 mem₀.words countE; rw [he] at this; exact this
  subst hcnt'
  have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
  constructor
  · intro bs hbs u₀ peak₀ rest
    rcases hshort bs hbs N 0 (by omega) mem₀ (by simp) (hInv₀ _) (u₀ + u_cnt) peak₀ rest
      with ⟨f₁, hs₁⟩
    refine ⟨1 + f₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    rw [hf]
    simp only [UL.runArithRAMFuel, he, hnIter]
    simpa using hs₁ f_rem
  · intro bs hbs u₀ peak₀ rest
    rcases hfull bs hbs N 0 (by omega) mem₀ (by simp) (hInv₀ _) (u₀ + u_cnt) peak₀ rest
      with ⟨f₁, u₁, peak₁, m_N, hu₁, hImN, hs₁⟩
    refine ⟨1 + f₁, u₁, peak₁, m_N, by omega, hImN, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    rw [hf]
    simp only [UL.runArithRAMFuel, he, hnIter]
    simpa using hs₁ f_rem

private theorem RandExec.to_spec {d : ℕ} {inp : UL.ArithRAMInput d} {prog : UL.ArithRAMStmt}
    {B C : ℕ} {Post : (Fin B → Bool) → UL.ArithRAMMemory → Prop}
    (h : RandExec inp prog B (UL.ArithRAMMemory.empty.popDepth 0) Post C) :
    (∀ bs : List Bool, bs.length ≠ B →
      UL.runArithRAMWithBits prog inp UL.ArithRAMMemory.empty bs = none) ∧
    (∀ bits : Fin B → Bool,
      ∃ out : UL.ArithRAMExecOutcome,
        UL.runArithRAMWithBits prog inp UL.ArithRAMMemory.empty (List.ofFn bits) = some out ∧
        out.unitCost ≤ C ∧
        ∃ mem₁ : UL.ArithRAMMemory, Post bits mem₁ ∧ out.mem = mem₁.popDepth 0) := by
  let initMem := UL.ArithRAMMemory.empty.popDepth 0
  let initPeak := inp.inputCellSpace + initMem.cellCount
  constructor
  · intro bs hbs_ne
    by_cases hlt : bs.length < B
    · rcases h.1 bs hlt 0 initPeak [] with ⟨fuel, hstep⟩
      exact runArithRAMWithBits_eq_none_of_status prog inp UL.ArithRAMMemory.empty bs
        (fuel + 0) .needMoreBits (by simp) (by simp) (hstep 0)
    · have hgt : B < bs.length := by omega
      have hge : B ≤ bs.length := by omega
      rcases h.2 bs hge 0 initPeak [] with ⟨fuel, u₁, peak₁, mem₁, _, _, hstep⟩
      have hne_nil : (bs.drop B).isEmpty = false := by
        cases hdrop : bs.drop B with
        | nil =>
            have hlen := congrArg List.length hdrop
            rw [List.length_drop, List.length_nil] at hlen
            omega
        | cons _ _ => rfl
      have hrun : UL.runArithRAMFuel inp (fuel + 1) [.stmt prog]
          { mem := initMem, frameDepth := 0, remainingBits := bs,
            unitCost := 0, peakCellSpace := initPeak } = .unusedBits := by
        rw [hstep 1]
        simp [UL.runArithRAMFuel, hne_nil]
      exact runArithRAMWithBits_eq_none_of_status prog inp UL.ArithRAMMemory.empty bs
        (fuel + 1) .unusedBits (by simp) (by simp) hrun
  · intro bits
    have hlen : (List.ofFn bits).length = B := List.length_ofFn
    have hge : B ≤ (List.ofFn bits).length := by omega
    rcases h.2 (List.ofFn bits) hge 0 initPeak [] with ⟨fuel, u₁, peak₁, mem₁, hu₁, hpost, hstep⟩
    have hbits_eq : (fun j : Fin B => (List.ofFn bits)[j.val]'(lt_of_lt_of_le j.isLt hge)) = bits := by
      funext j
      simp
    rw [hbits_eq] at hpost
    have hdrop_nil : (List.ofFn bits).drop B = [] := by
      rw [List.drop_eq_nil_iff, hlen]
    let out : UL.ArithRAMExecOutcome :=
      { mem := mem₁.popDepth 0, unitCost := u₁, peakCellSpace := peak₁ }
    have hrun : UL.runArithRAMFuel inp (fuel + 1) [.stmt prog]
        { mem := initMem, frameDepth := 0, remainingBits := List.ofFn bits,
          unitCost := 0, peakCellSpace := initPeak } = .halted out := by
      rw [hstep 1]
      simp [UL.runArithRAMFuel, hdrop_nil, out]
    refine ⟨out, runArithRAMWithBits_eq_some_of_fuel prog inp UL.ArithRAMMemory.empty
      (List.ofFn bits) (fuel + 1) out hrun, by dsimp [out]; omega, mem₁, hpost, rfl⟩

/-! ### 3. Definition of `hpjProg : UL.ArithRAMStmt` -/

private def iLit (c : ℤ) : UL.IntExpr := .lit c
private def wReg (t : ℕ) (idx : ℤ) : UL.IntExpr := .readHeap t (.lit idx)
private def wArr (t : ℕ) (idxE : UL.IntExpr) : UL.IntExpr := .readHeap t idxE
private def rLit (c : ℤ) : UL.RealExpr := .ofInt (.lit c)
private def rReg (t : ℕ) (idx : ℤ) : UL.RealExpr := .readRealHeap t (.lit idx)
private def rArr (t : ℕ) (idxE : UL.IntExpr) : UL.RealExpr := .readRealHeap t idxE

private def wSet (t : ℕ) (idx : ℤ) (valE : UL.IntExpr) : UL.ArithRAMStmt :=
  .writeWordHeap t (.lit idx) valE
private def wSetArr (t : ℕ) (idxE valE : UL.IntExpr) : UL.ArithRAMStmt :=
  .writeWordHeap t idxE valE
private def rSet (t : ℕ) (idx : ℤ) (valE : UL.RealExpr) : UL.ArithRAMStmt :=
  .writeRealHeap t (.lit idx) valE
private def rSetArr (t : ℕ) (idxE : UL.IntExpr) (valE : UL.RealExpr) : UL.ArithRAMStmt :=
  .writeRealHeap t idxE valE

private def seqList : List UL.ArithRAMStmt → UL.ArithRAMStmt
  | [] => .skip
  | [s] => s
  | s :: ss => .seq s (seqList ss)

private def ceilPow2LoopStmt (reg_e reg_p : ℤ) (targetE : UL.IntExpr) : UL.ArithRAMStmt :=
  .whileLoop (.intLt (wReg 1 reg_p) targetE)
    (.seq
      (wSet 1 reg_e (.add (wReg 1 reg_e) (iLit 1)))
      (wSet 1 reg_p (.mul (iLit 2) (wReg 1 reg_p))))

private def kPhiStmt : UL.ArithRAMStmt :=
  seqList
    [ wSet 1 3 (iLit 1),
      rSet 1 0 (.add (.extraReal (iLit 0)) (.extraReal (iLit 0))),
      .whileLoop (.realLt (rReg 1 0) (rLit 2))
        (.seq
          (wSet 1 3 (.add (wReg 1 3) (iLit 1)))
          (rSet 1 0 (.add (rReg 1 0) (rReg 1 0)))) ]

private def phase1Stmt : UL.ArithRAMStmt :=
  seqList
    [ wSet 1 0 (.add .dim (iLit 1)),
      wSet 1 1 (iLit 1),
      wSet 1 2 (iLit 2),
      ceilPow2LoopStmt 1 2 (.add .dim (iLit 2)),
      kPhiStmt,
      wSet 1 4 (iLit 0),
      wSet 1 5 (iLit 1),
      ceilPow2LoopStmt 4 5 (wReg 1 1),
      wSet 1 6 (iLit 0),
      wSet 1 7 (iLit 1),
      ceilPow2LoopStmt 6 7 (wReg 1 3),
      wSet 1 8 (.add (.add (.add (iLit 16) (.mul (iLit 3) (wReg 1 1))) (wReg 1 4)) (wReg 1 6)),
      wSet 1 9 (.mul (.mul (.mul (.mul (.mul (iLit 65536) (wReg 1 2)) (wReg 1 2)) (wReg 1 2))
        (wReg 1 5)) (wReg 1 7)),
      wSet 1 11 (.add (wReg 1 0) (iLit 1)),
      wSet 1 12 (.add (wReg 1 0) (iLit 2)),
      wSet 1 13 (.add (wReg 1 0) (iLit 3)),
      wSet 1 10 (.mul (.mul (iLit 3) (wReg 1 9))
        (.add (.add (.mul (.mul (iLit 4) (wReg 1 12)) (wReg 1 8))
          (.mul (iLit 4) (wReg 1 3))) (iLit 16))) ]

private def phase2PointBody : UL.ArithRAMStmt :=
  seqList
    [ wSet 4 1 (.intParam (wReg 4 0)),
      rSet 1 1 (rLit 0),
      wSet 4 2 (iLit 0),
      .repeatN .dim
        (seqList
          [ rSet 1 2 (.activePtCoord (wReg 4 1) (wReg 4 2)),
            rSetArr 2 (.add (.mul (wReg 4 0) (wReg 1 0)) (wReg 4 2)) (rReg 1 2),
            rSet 1 1 (.add (rReg 1 1) (.mul (rReg 1 2) (rReg 1 2))),
            wSet 4 2 (.add (wReg 4 2) (iLit 1)) ]),
      rSetArr 2 (.add (.mul (wReg 4 0) (wReg 1 0)) .dim) (rReg 1 1),
      wSet 4 0 (.add (wReg 4 0) (iLit 1)) ]

private def phase2Stmt : UL.ArithRAMStmt :=
  .seq (wSet 4 0 (iLit 0)) (.repeatN (wReg 1 9) phase2PointBody)

private def readQBitsStmt : UL.ArithRAMStmt :=
  .seq (wSet 4 4 (iLit 0))
    (.repeatN (wReg 1 8)
      (.seq (.randBitHeap 4 (iLit 5))
        (wSet 4 4 (.add (.mul (iLit 2) (wReg 4 4)) (wReg 4 5)))))

private def sampleSlotsStmt : UL.ArithRAMStmt :=
  .seq (wSet 4 3 (iLit 0))
    (.repeatN (wReg 1 13)
      (.seq readQBitsStmt
        (.seq (wSetArr 2 (wReg 4 3) (wReg 4 4))
          (wSet 4 3 (.add (wReg 4 3) (iLit 1))))))

private def initGaussColBody : UL.ArithRAMStmt :=
  seqList
    [ wSetArr 3 (wReg 4 6) (iLit 0),
      wSet 4 12 (wArr 2 (wReg 4 6)),
      wSet 4 2 (iLit 0),
      .repeatN (wReg 1 0)
        (.seq
          (rSetArr 3 (.add (.mul (wReg 4 6) (wReg 1 11)) (wReg 4 2))
            (rArr 2 (.add (.mul (wReg 4 12) (wReg 1 0)) (wReg 4 2))))
          (wSet 4 2 (.add (wReg 4 2) (iLit 1)))),
      rSetArr 3 (.add (.mul (wReg 4 6) (wReg 1 11)) (wReg 1 0)) (rLit 1),
      wSet 4 7 (iLit 0),
      .repeatN (wReg 1 12)
        (.seq
          (.ite (.intEq (wReg 4 6) (wReg 4 7))
            (rSetArr 4 (.add (.mul (wReg 4 6) (wReg 1 12)) (wReg 4 7)) (rLit 1))
            (rSetArr 4 (.add (.mul (wReg 4 6) (wReg 1 12)) (wReg 4 7)) (rLit 0)))
          (wSet 4 7 (.add (wReg 4 7) (iLit 1)))),
      wSet 4 6 (.add (wReg 4 6) (iLit 1)) ]

private def initGaussStmt : UL.ArithRAMStmt :=
  .seq (wSet 4 6 (iLit 0)) (.repeatN (wReg 1 12) initGaussColBody)

private def findPivotStmt : UL.ArithRAMStmt :=
  seqList
    [ wSet 4 9 (iLit 0),
      wSet 4 10 (iLit 0),
      wSet 4 6 (iLit 0),
      .repeatN (wReg 1 12)
        (.seq
          (.ite
            (.and
              (.and (.intEq (wReg 4 9) (iLit 0)) (.intEq (wArr 3 (wReg 4 6)) (iLit 0)))
              (.not (.realEq (rArr 3 (.add (.mul (wReg 4 6) (wReg 1 11)) (wReg 4 8))) (rLit 0))))
            (.seq (wSet 4 9 (iLit 1)) (wSet 4 10 (wReg 4 6)))
            .skip)
          (wSet 4 6 (.add (wReg 4 6) (iLit 1)))) ]

private def elimColBody : UL.ArithRAMStmt :=
  .seq
    (.ite (.intEq (wArr 3 (wReg 4 7)) (iLit 0))
      (seqList
        [ rSet 1 3 (.div
            (rArr 3 (.add (.mul (wReg 4 7) (wReg 1 11)) (wReg 4 8)))
            (rArr 3 (.add (.mul (wReg 4 10) (wReg 1 11)) (wReg 4 8)))),
          wSet 4 11 (iLit 0),
          .repeatN (wReg 1 11)
            (.seq
              (rSetArr 3 (.add (.mul (wReg 4 7) (wReg 1 11)) (wReg 4 11))
                (.sub (rArr 3 (.add (.mul (wReg 4 7) (wReg 1 11)) (wReg 4 11)))
                  (.mul (rReg 1 3) (rArr 3 (.add (.mul (wReg 4 10) (wReg 1 11)) (wReg 4 11))))))
              (wSet 4 11 (.add (wReg 4 11) (iLit 1)))),
          wSet 4 11 (iLit 0),
          .repeatN (wReg 1 12)
            (.seq
              (rSetArr 4 (.add (.mul (wReg 4 7) (wReg 1 12)) (wReg 4 11))
                (.sub (rArr 4 (.add (.mul (wReg 4 7) (wReg 1 12)) (wReg 4 11)))
                  (.mul (rReg 1 3) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))))))
              (wSet 4 11 (.add (wReg 4 11) (iLit 1)))) ])
      .skip)
    (wSet 4 7 (.add (wReg 4 7) (iLit 1)))

private def gaussRowBody : UL.ArithRAMStmt :=
  seqList
    [ findPivotStmt,
      .ite (.intEq (wReg 4 9) (iLit 1))
        (seqList
          [ wSetArr 3 (wReg 4 10) (iLit 1),
            wSet 4 7 (iLit 0),
            .repeatN (wReg 1 12) elimColBody ])
        .skip,
      wSet 4 8 (.add (wReg 4 8) (iLit 1)) ]

private def gaussRowsStmt : UL.ArithRAMStmt :=
  .seq (wSet 4 8 (iLit 0)) (.repeatN (wReg 1 11) gaussRowBody)

private def findKStarStmt : UL.ArithRAMStmt :=
  seqList
    [ wSet 4 9 (iLit 0),
      wSet 4 10 (iLit 0),
      wSet 4 6 (iLit 0),
      .repeatN (wReg 1 12)
        (.seq
          (.ite (.and (.intEq (wReg 4 9) (iLit 0)) (.intEq (wArr 3 (wReg 4 6)) (iLit 0)))
            (.seq (wSet 4 9 (iLit 1)) (wSet 4 10 (wReg 4 6)))
            .skip)
          (wSet 4 6 (.add (wReg 4 6) (iLit 1)))) ]

private def computePosSumStmt : UL.ArithRAMStmt :=
  seqList
    [ rSet 1 4 (rLit 0),
      wSet 4 11 (iLit 0),
      .repeatN (wReg 1 12)
        (.seq
          (.ite (.realLt (rLit 0) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))))
            (rSet 1 4 (.add (rReg 1 4) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11)))))
            .skip)
          (wSet 4 11 (.add (wReg 4 11) (iLit 1)))) ]

private def computeRadPtStmt : UL.ArithRAMStmt :=
  seqList
    [ findKStarStmt,
      computePosSumStmt,
      wSet 4 2 (iLit 0),
      .repeatN (wReg 1 0)
        (seqList
          [ rSet 1 5 (rLit 0),
            wSet 4 11 (iLit 0),
            .repeatN (wReg 1 12)
              (.seq
                (.ite (.realLt (rLit 0) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))))
                  (rSet 1 5 (.add (rReg 1 5)
                    (.mul
                      (.div (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))) (rReg 1 4))
                      (rArr 2 (.add (.mul (wArr 2 (wReg 4 11)) (wReg 1 0)) (wReg 4 2))))))
                  .skip)
                (wSet 4 11 (.add (wReg 4 11) (iLit 1)))),
            rSetArr 5 (wReg 4 2) (rReg 1 5),
            wSet 4 2 (.add (wReg 4 2) (iLit 1)) ]) ]

private def copyRadPtToPoolStmt : UL.ArithRAMStmt :=
  seqList
    [ wSet 4 12 (wArr 2 (wReg 1 12)),
      wSet 4 2 (iLit 0),
      .repeatN (wReg 1 0)
        (.seq
          (rSetArr 2 (.add (.mul (wReg 4 12) (wReg 1 0)) (wReg 4 2)) (rArr 5 (wReg 4 2)))
          (wSet 4 2 (.add (wReg 4 2) (iLit 1)))) ]

private def detWalkStepStmt : UL.ArithRAMStmt :=
  seqList [initGaussStmt, gaussRowsStmt, computeRadPtStmt, copyRadPtToPoolStmt]

private def phase3Stmt : UL.ArithRAMStmt :=
  .repeatN (wReg 1 10) (.seq sampleSlotsStmt detWalkStepStmt)

private def phase4Stmt : UL.ArithRAMStmt :=
  seqList
    [ wSet 4 2 (iLit 0),
      .repeatN (wReg 1 0)
        (.seq
          (rSetArr 0 (wReg 4 2) (rArr 2 (wReg 4 2)))
          (wSet 4 2 (.add (wReg 4 2) (iLit 1)))) ]

def hpjProg : UL.ArithRAMStmt :=
  seqList [phase1Stmt, phase2Stmt, phase3Stmt, phase4Stmt]

/-! ### 4. Memory state predicates and Phase 1–2 verification -/

private def ParamsStored (P : HPJParams) (mem : UL.ArithRAMMemory) : Prop :=
  wRead mem 1 0 = (P.D : ℤ) ∧
  wRead mem 1 1 = (P.k_d : ℤ) ∧
  wRead mem 1 2 = (P.p_d : ℤ) ∧
  wRead mem 1 3 = (P.k_phi : ℤ) ∧
  wRead mem 1 4 = (P.u_d : ℤ) ∧
  wRead mem 1 5 = (P.pk_d : ℤ) ∧
  wRead mem 1 6 = (P.u_phi : ℤ) ∧
  wRead mem 1 7 = (P.pk_phi : ℤ) ∧
  wRead mem 1 8 = (P.q : ℤ) ∧
  wRead mem 1 9 = (P.m : ℤ) ∧
  wRead mem 1 10 = (P.L : ℤ) ∧
  wRead mem 1 11 = ((P.D + 1 : ℕ) : ℤ) ∧
  wRead mem 1 12 = ((P.D + 2 : ℕ) : ℤ) ∧
  wRead mem 1 13 = ((P.D + 3 : ℕ) : ℤ)

private theorem ParamsStored.hD {P : HPJParams} {mem : UL.ArithRAMMemory}
    (h : ParamsStored P mem) : wRead mem 1 0 = (P.D : ℤ) := h.1
private theorem ParamsStored.hq {P : HPJParams} {mem : UL.ArithRAMMemory}
    (h : ParamsStored P mem) : wRead mem 1 8 = (P.q : ℤ) := h.2.2.2.2.2.2.2.2.1
private theorem ParamsStored.hm {P : HPJParams} {mem : UL.ArithRAMMemory}
    (h : ParamsStored P mem) : wRead mem 1 9 = (P.m : ℤ) := h.2.2.2.2.2.2.2.2.2.1
private theorem ParamsStored.hL {P : HPJParams} {mem : UL.ArithRAMMemory}
    (h : ParamsStored P mem) : wRead mem 1 10 = (P.L : ℤ) := h.2.2.2.2.2.2.2.2.2.2.1
private theorem ParamsStored.hD1 {P : HPJParams} {mem : UL.ArithRAMMemory}
    (h : ParamsStored P mem) : wRead mem 1 11 = ((P.D + 1 : ℕ) : ℤ) :=
  h.2.2.2.2.2.2.2.2.2.2.2.1
private theorem ParamsStored.hD2 {P : HPJParams} {mem : UL.ArithRAMMemory}
    (h : ParamsStored P mem) : wRead mem 1 12 = ((P.D + 2 : ℕ) : ℤ) :=
  h.2.2.2.2.2.2.2.2.2.2.2.2.1
private theorem ParamsStored.hD3 {P : HPJParams} {mem : UL.ArithRAMMemory}
    (h : ParamsStored P mem) : wRead mem 1 13 = ((P.D + 3 : ℕ) : ℤ) :=
  h.2.2.2.2.2.2.2.2.2.2.2.2.2

private theorem paramsStored_wWrite_ne {P : HPJParams} {mem : UL.ArithRAMMemory}
    (h : ParamsStored P mem) (t : ℕ) (idx v : ℤ) (ht : t ≠ 1 := by decide) :
    ParamsStored P (wWrite mem t idx v) := by
  have hw : ∀ i : ℤ, wRead (wWrite mem t idx v) 1 i = wRead mem 1 i :=
    fun i => wRead_wWrite_of_ne mem v (Or.inl ht.symm)
  unfold ParamsStored at h ⊢
  simp only [hw]
  exact h

private theorem paramsStored_rWrite {P : HPJParams} {mem : UL.ArithRAMMemory}
    (h : ParamsStored P mem) (t : ℕ) (idx : ℤ) (v : ℝ) :
    ParamsStored P (rWrite mem t idx v) := h

private def PoolStored {D m : ℕ} (T : Fin m → EuclideanSpace ℝ (Fin D))
    (mem : UL.ArithRAMMemory) : Prop :=
  ∀ (p : Fin m) (c : Fin D),
    rRead mem 2 ((p.val * D + c.val : ℕ) : ℤ) = UL.euclideanCoord (T p) c

private theorem poolStored_wWrite {D m : ℕ} {T : Fin m → EuclideanSpace ℝ (Fin D)}
    {mem : UL.ArithRAMMemory} (h : PoolStored T mem) (t : ℕ) (idx v : ℤ) :
    PoolStored T (wWrite mem t idx v) := h

private theorem poolStored_rWrite_ne {D m : ℕ} {T : Fin m → EuclideanSpace ℝ (Fin D)}
    {mem : UL.ArithRAMMemory} (h : PoolStored T mem) (t : ℕ) (idx : ℤ) (v : ℝ)
    (ht : t ≠ 2 := by decide) :
    PoolStored T (rWrite mem t idx v) := by
  intro p c
  rw [rRead_rWrite_of_ne mem v (Or.inl ht.symm)]
  exact h p c

private theorem ceilPow2From_of_ge {e p target : ℕ} (h : target ≤ p) :
    ceilPow2From e p target = (e, p) := by
  rw [ceilPow2From]
  split_ifs with hc
  · omega
  · rfl

private theorem ceilPow2From_of_lt {e p target : ℕ} (hlt : p < target) (hp : 0 < p) :
    ceilPow2From e p target = ceilPow2From (e + 1) (2 * p) target := by
  rw [ceilPow2From]
  exact dif_pos ⟨hlt, hp⟩

private theorem ceilPow2From_bound :
    ∀ (rem e p target : ℕ), target - p ≤ rem → 0 < p →
      e ≤ (ceilPow2From e p target).1 ∧ (ceilPow2From e p target).1 - e ≤ rem
  | 0, e, p, target, hrem, _ => by
      rw [ceilPow2From_of_ge (by omega)]
      omega
  | rem + 1, e, p, target, hrem, hp => by
      by_cases hlt : p < target
      · rw [ceilPow2From_of_lt hlt hp]
        have ih := ceilPow2From_bound rem (e + 1) (2 * p) target (by omega) (by omega)
        omega
      · rw [ceilPow2From_of_ge (by omega)]
        omega

private theorem exec_ceilPow2Loop {d : ℕ} {m₀ : UL.ArithRAMMemory} (inp : UL.ArithRAMInput d)
    (reg_e reg_p : ℤ) (hne_ep : reg_e ≠ reg_p)
    (targetE : UL.IntExpr) (ht_ops : intExprOps targetE ≤ 5) (target : ℕ)
    (ht_inv : ∀ m : UL.ArithRAMMemory,
      (∀ t i, (t ≠ 1 ∨ (i ≠ reg_e ∧ i ≠ reg_p)) → wRead m t i = wRead m₀ t i) →
      iVal inp m targetE = (target : ℤ)) :
    ∀ (rem e p : ℕ) (m : UL.ArithRAMMemory),
      target - p ≤ rem → 0 < p →
      wRead m 1 reg_e = (e : ℤ) →
      wRead m 1 reg_p = (p : ℤ) →
      (∀ t i, (t ≠ 1 ∨ (i ≠ reg_e ∧ i ≠ reg_p)) → wRead m t i = wRead m₀ t i) →
      ∃ m',
        DetExec inp (ceilPow2LoopStmt reg_e reg_p targetE) m m'
          (((ceilPow2From e p target).1 - e) * 30 + 10) ∧
        wRead m' 1 reg_e = ((ceilPow2From e p target).1 : ℤ) ∧
        wRead m' 1 reg_p = ((ceilPow2From e p target).2 : ℤ) ∧
        (∀ t i, (t ≠ 1 ∨ (i ≠ reg_e ∧ i ≠ reg_p)) → wRead m' t i = wRead m₀ t i) ∧
        (∀ t i, rRead m' t i = rRead m t i) := by
  intro rem
  induction rem with
  | zero =>
      intro e p m hrem _ he hp hframe
      have hge : target ≤ p := by omega
      rw [ceilPow2From_of_ge hge]
      have hcond : cVal inp m (.intLt (wReg 1 reg_p) targetE) = false := by
        simp only [cVal_intLt, wReg, iVal_readHeap, iVal_lit, hp, ht_inv m hframe,
          decide_eq_false_iff_not]
        omega
      refine ⟨m, ?_, he, hp, hframe, fun _ _ => rfl⟩
      simpa using DetExec.whileLoop_false (C_c := 10) hcond
        (by change 2 + intExprOps targetE + 1 ≤ 10; omega)
  | succ rem ih =>
      intro e p m hrem hppos he hp hframe
      by_cases hlt : p < target
      · rw [ceilPow2From_of_lt hlt hppos]
        have hcond : cVal inp m (.intLt (wReg 1 reg_p) targetE) = true := by
          simp only [cVal_intLt, wReg, iVal_readHeap, iVal_lit, hp, ht_inv m hframe,
            decide_eq_true_eq]
          omega
        let m₁ := wWrite m 1 reg_e ((e + 1 : ℕ) : ℤ)
        have hs₁ : DetExec inp (wSet 1 reg_e (.add (wReg 1 reg_e) (iLit 1))) m m₁ 10 := by
          refine DetExec.writeWord inp m 1 (.lit reg_e) (.add (wReg 1 reg_e) (iLit 1)) rfl ?_
            (by dsimp [intExprOps, wReg, iLit]; omega)
          simp [wReg, iLit, he]
        have hp_m₁ : wRead m₁ 1 reg_p = (p : ℤ) := by
          rw [wRead_wWrite_of_ne m _ (Or.inr hne_ep.symm), hp]
        let m₂ := wWrite m₁ 1 reg_p ((2 * p : ℕ) : ℤ)
        have hs₂ : DetExec inp (wSet 1 reg_p (.mul (iLit 2) (wReg 1 reg_p))) m₁ m₂ 10 := by
          refine DetExec.writeWord inp m₁ 1 (.lit reg_p) (.mul (iLit 2) (wReg 1 reg_p)) rfl ?_
            (by dsimp [intExprOps, wReg, iLit]; omega)
          simp [wReg, iLit, hp_m₁]
        have he_m₂ : wRead m₂ 1 reg_e = ((e + 1 : ℕ) : ℤ) := by
          rw [wRead_wWrite_of_ne m₁ _ (Or.inr hne_ep)]
          simp [m₁]
        have hp_m₂ : wRead m₂ 1 reg_p = ((2 * p : ℕ) : ℤ) := by simp [m₂]
        have hframe₂ : ∀ t i, (t ≠ 1 ∨ (i ≠ reg_e ∧ i ≠ reg_p)) →
            wRead m₂ t i = wRead m₀ t i := by
          intro t i hne
          have hne₂ : t ≠ 1 ∨ i ≠ reg_p := hne.imp_right And.right
          have hne₁ : t ≠ 1 ∨ i ≠ reg_e := hne.imp_right And.left
          rw [wRead_wWrite_of_ne m₁ _ hne₂, wRead_wWrite_of_ne m _ hne₁, hframe t i hne]
        rcases ih (e + 1) (2 * p) m₂ (by omega) (by omega) he_m₂ hp_m₂ hframe₂ with
          ⟨m', hexec', he', hp', hframe', hr'⟩
        have hbnd := ceilPow2From_bound rem (e + 1) (2 * p) target (by omega) (by omega)
        refine ⟨m', ?_, he', hp', hframe', fun t i => by rw [hr']; rfl⟩
        refine (DetExec.whileLoop_true hcond
          (by change 2 + intExprOps targetE + 1 ≤ 10; omega)
          (hs₁.seq hs₂) hexec').mono_cost ?_
        omega
      · have hge : target ≤ p := by omega
        rw [ceilPow2From_of_ge hge]
        have hcond : cVal inp m (.intLt (wReg 1 reg_p) targetE) = false := by
          simp only [cVal_intLt, wReg, iVal_readHeap, iVal_lit, hp, ht_inv m hframe,
            decide_eq_false_iff_not]
          omega
        refine ⟨m, ?_, he, hp, hframe, fun _ _ => rfl⟩
        simpa using DetExec.whileLoop_false (C_c := 10) hcond
          (by change 2 + intExprOps targetE + 1 ≤ 10; omega)

private theorem ceilLog2TwoDiv_spec {φ : ℝ} (hφ0 : 0 < φ) :
    1 ≤ ceilLog2TwoDiv φ ∧
    2 ≤ (2 : ℝ) ^ (ceilLog2TwoDiv φ) * φ ∧
    (∀ k : ℕ, 1 ≤ k → k < ceilLog2TwoDiv φ → (2 : ℝ) ^ k * φ < 2) := by
  classical
  unfold ceilLog2TwoDiv
  rw [dif_pos hφ0]
  generalize_proofs hex
  rcases Nat.find_spec hex with ⟨hk1, hge⟩
  refine ⟨hk1, hge, fun k h1 hlt => ?_⟩
  have hmin := Nat.find_min hex hlt
  push_neg at hmin
  exact hmin h1

private theorem exec_kPhiStmt {d : ℕ} {φ : ℝ} (hφ0 : 0 < φ)
    (inp : UL.ArithRAMInput d) (hextra : inp.extraReals = [φ])
    (mem₀ : UL.ArithRAMMemory) :
    ∃ mem₁,
      DetExec inp kPhiStmt mem₀ mem₁ (40 * ceilLog2TwoDiv φ + 40) ∧
      wRead mem₁ 1 3 = (ceilLog2TwoDiv φ : ℤ) ∧
      (∀ t i, (t ≠ 1 ∨ i ≠ 3) → wRead mem₁ t i = wRead mem₀ t i) := by
  rcases ceilLog2TwoDiv_spec hφ0 with ⟨hk1, hge2, hlt2⟩
  let k_phi := ceilLog2TwoDiv φ
  let m₁ := wWrite mem₀ 1 3 1
  have hs₁ : DetExec inp (wSet 1 3 (iLit 1)) mem₀ m₁ 10 :=
    DetExec.writeWord inp mem₀ 1 (.lit 3) (iLit 1) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let m₂ := rWrite m₁ 1 0 ((2 : ℝ) ^ 1 * φ)
  have hs₂ : DetExec inp (rSet 1 0 (.add (.extraReal (iLit 0)) (.extraReal (iLit 0)))) m₁ m₂ 10 := by
    refine DetExec.writeReal inp m₁ 1 (.lit 0)
      (.add (.extraReal (iLit 0)) (.extraReal (iLit 0))) rfl ?_
      (by dsimp [intExprOps, realExprOps, iLit]; omega)
    simp [iLit, hextra, UL.listGetIntD]
    ring
  let N := k_phi - 1
  let Inv : ℕ → UL.ArithRAMMemory → Prop := fun i m =>
    wRead m 1 3 = ((1 + i : ℕ) : ℤ) ∧
    rRead m 1 0 = (2 : ℝ) ^ (1 + i) * φ ∧
    (∀ t idx, (t ≠ 1 ∨ idx ≠ 3) → wRead m t idx = wRead mem₀ t idx)
  have hInv₀ : Inv 0 m₂ := by
    refine ⟨by simp [m₂, m₁], by simp [m₂], fun t idx hne => ?_⟩
    simpa [m₂, m₁] using wRead_wWrite_of_ne mem₀ 1 hne
  rcases DetExec.whileLoop_nat (.realLt (rReg 1 0) (rLit 2))
    (.seq (wSet 1 3 (.add (wReg 1 3) (iLit 1))) (rSet 1 0 (.add (rReg 1 0) (rReg 1 0))))
    N 10 20 Inv
    (by dsimp [condExprOps, realExprOps, intExprOps, rReg, rLit]; omega) hInv₀
    (fun i hi m ⟨hw3, hr0, hfr⟩ => by
      have hlt_k : 1 + i < k_phi := by omega
      have hlt_r : (2 : ℝ) ^ (1 + i) * φ < 2 := hlt2 (1 + i) (by omega) hlt_k
      have hcond : cVal inp m (.realLt (rReg 1 0) (rLit 2)) = true := by
        simp [rReg, rLit, hr0, hlt_r]
      refine ⟨hcond, ?_⟩
      let ma := wWrite m 1 3 ((1 + (i + 1) : ℕ) : ℤ)
      have hsa : DetExec inp (wSet 1 3 (.add (wReg 1 3) (iLit 1))) m ma 10 := by
        refine DetExec.writeWord inp m 1 (.lit 3) (.add (wReg 1 3) (iLit 1)) rfl ?_
          (by dsimp [intExprOps, wReg, iLit]; omega)
        simp [wReg, iLit, hw3]
        omega
      let mb := rWrite ma 1 0 ((2 : ℝ) ^ (1 + (i + 1)) * φ)
      have hsb : DetExec inp (rSet 1 0 (.add (rReg 1 0) (rReg 1 0))) ma mb 10 := by
        refine DetExec.writeReal inp ma 1 (.lit 0) (.add (rReg 1 0) (rReg 1 0)) rfl ?_
          (by dsimp [intExprOps, realExprOps, rReg]; omega)
        simp [rReg, ma, hr0]
        ring
      refine ⟨mb, hsa.seq hsb, by simp [mb, ma], by simp [mb], fun t idx hne => ?_⟩
      simpa [mb, ma] using (wRead_wWrite_of_ne m _ hne).trans (hfr t idx hne))
    (fun m ⟨_, hr0, _⟩ => by
      have hk_eq : 1 + N = ceilLog2TwoDiv φ := by dsimp [N, k_phi]; omega
      rw [hk_eq] at hr0
      simp only [cVal_realLt, rReg, rLit, rVal_readRealHeap, rVal_ofInt, iVal_lit,
        Int.cast_ofNat, hr0]
      rw [decide_eq_false_iff_not]
      linarith)
    with ⟨mem_N, ⟨hw3_N, _, hfr_N⟩, hloop⟩
  have hk_eq : 1 + N = k_phi := by omega
  rw [hk_eq] at hw3_N
  refine ⟨mem_N, ?_, hw3_N, hfr_N⟩
  unfold kPhiStmt seqList
  refine (hs₁.seq (hs₂.seq hloop)).mono_cost ?_
  omega

private theorem exec_phase1 {d : ℕ} {φ : ℝ} (hφ0 : 0 < φ)
    (P : HPJParams) (hP_eq : P = hpjParams d φ) (hP : HPJParamProps d φ P)
    (inp : UL.ArithRAMInput d) (hextra : inp.extraReals = [φ])
    (mem₀ : UL.ArithRAMMemory) :
    ∃ mem₁,
      DetExec inp phase1Stmt mem₀ mem₁ (200 * (P.k_d + P.k_phi)) ∧
      ParamsStored P mem₁ := by
  have h1kd : 1 ≤ P.k_d := hP.2.1
  have h3kphi : 3 ≤ P.k_phi := hP.2.2.1
  have hPD : P.D = d + 1 := by rw [hP_eq]; rfl
  have hkd_eq : (P.k_d, P.p_d) = ceilPow2From 1 2 (d + 2) := by
    rw [hP_eq]; unfold hpjParams; rfl
  have hkphi_eq : P.k_phi = ceilLog2TwoDiv φ := by
    rw [hP_eq]; unfold hpjParams; rfl
  have hud_eq : (P.u_d, P.pk_d) = ceilPow2From 0 1 P.k_d := by
    rw [hP_eq]; unfold hpjParams; rfl
  have huphi_eq : (P.u_phi, P.pk_phi) = ceilPow2From 0 1 P.k_phi := by
    rw [hP_eq]; unfold hpjParams; rfl
  have hq_eq : P.q = 16 + 3 * P.k_d + P.u_d + P.u_phi := by
    rw [hP_eq]; unfold hpjParams; rfl
  have hm_eq : P.m = 65536 * P.p_d * P.p_d * P.p_d * P.pk_d * P.pk_phi := by
    rw [hP_eq]; unfold hpjParams; rfl
  have hL_eq : P.L = 3 * P.m * (4 * (P.D + 2) * P.q + 4 * P.k_phi + 16) := hP.2.2.2.2.2.2.2.2.1
  have hud_le : P.u_d ≤ P.k_d := by
    have hb := (ceilPow2From_bound P.k_d 0 1 P.k_d (by omega) (by omega)).2
    have : (ceilPow2From 0 1 P.k_d).1 = P.u_d := congrArg Prod.fst hud_eq.symm
    omega
  have huphi_le : P.u_phi ≤ P.k_phi := by
    have hb := (ceilPow2From_bound P.k_phi 0 1 P.k_phi (by omega) (by omega)).2
    have : (ceilPow2From 0 1 P.k_phi).1 = P.u_phi := congrArg Prod.fst huphi_eq.symm
    omega
  let m1 := wWrite mem₀ 1 0 (P.D : ℤ)
  have hs1 : DetExec inp (wSet 1 0 (.add .dim (iLit 1))) mem₀ m1 10 := by
    refine DetExec.writeWord inp mem₀ 1 (.lit 0) (.add .dim (iLit 1)) rfl ?_
      (by dsimp [intExprOps, iLit]; omega)
    simp [iLit, hPD]
  let m2 := wWrite m1 1 1 1
  have hs2 : DetExec inp (wSet 1 1 (iLit 1)) m1 m2 10 :=
    DetExec.writeWord inp m1 1 (.lit 1) (iLit 1) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let m3 := wWrite m2 1 2 2
  have hs3 : DetExec inp (wSet 1 2 (iLit 2)) m2 m3 10 :=
    DetExec.writeWord inp m2 1 (.lit 2) (iLit 2) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  rcases exec_ceilPow2Loop (m₀ := m3) inp 1 2 (by decide) (.add .dim (iLit 2))
    (by dsimp [intExprOps, iLit]; omega) (d + 2)
    (fun m _ => by simp [iLit])
    (d + 2) 1 2 m3 (by omega) (by omega)
    (by rw [wRead_wWrite_of_ne m2 _ (Or.inr (by decide))]; simp [m2])
    (by simp [m3]) (fun _ _ _ => rfl) with
    ⟨m4, hs4, hkd_m4, hpd_m4, hfr4, _⟩
  have hkd1 : (ceilPow2From 1 2 (d + 2)).1 = P.k_d := congrArg Prod.fst hkd_eq.symm
  have hpd1 : (ceilPow2From 1 2 (d + 2)).2 = P.p_d := congrArg Prod.snd hkd_eq.symm
  rw [hkd1] at hs4 hkd_m4
  rw [hpd1] at hpd_m4
  have hD_m4 : wRead m4 1 0 = (P.D : ℤ) := by
    rw [hfr4 1 0 (Or.inr ⟨by decide, by decide⟩),
      wRead_wWrite_of_ne m2 _ (Or.inr (by decide)),
      wRead_wWrite_of_ne m1 _ (Or.inr (by decide))]
    simp [m1]
  rcases exec_kPhiStmt hφ0 inp hextra m4 with ⟨m5, hs5, hkphi_m5, hfr5⟩
  rw [← hkphi_eq] at hs5 hkphi_m5
  have hD_m5 : wRead m5 1 0 = (P.D : ℤ) := by rw [hfr5 1 0 (Or.inr (by decide)), hD_m4]
  have hkd_m5 : wRead m5 1 1 = (P.k_d : ℤ) := by rw [hfr5 1 1 (Or.inr (by decide)), hkd_m4]
  have hpd_m5 : wRead m5 1 2 = (P.p_d : ℤ) := by rw [hfr5 1 2 (Or.inr (by decide)), hpd_m4]
  let m6 := wWrite m5 1 4 0
  have hs6 : DetExec inp (wSet 1 4 (iLit 0)) m5 m6 10 :=
    DetExec.writeWord inp m5 1 (.lit 4) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let m7 := wWrite m6 1 5 1
  have hs7 : DetExec inp (wSet 1 5 (iLit 1)) m6 m7 10 :=
    DetExec.writeWord inp m6 1 (.lit 5) (iLit 1) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  have hkd_m7 : wRead m7 1 1 = (P.k_d : ℤ) := by
    rw [wRead_wWrite_of_ne m6 _ (Or.inr (by decide)),
      wRead_wWrite_of_ne m5 _ (Or.inr (by decide)), hkd_m5]
  rcases exec_ceilPow2Loop (m₀ := m7) inp 4 5 (by decide) (wReg 1 1)
    (by dsimp [intExprOps, wReg]; omega) P.k_d
    (fun m hfm => by change wRead m 1 1 = _; rw [hfm 1 1 (Or.inr ⟨by decide, by decide⟩), hkd_m7])
    P.k_d 0 1 m7 (by omega) (by omega)
    (by rw [wRead_wWrite_of_ne m6 _ (Or.inr (by decide))]; simp [m6])
    (by simp [m7]) (fun _ _ _ => rfl) with
    ⟨m8, hs8, hud_m8, hpkd_m8, hfr8, _⟩
  have hud1 : (ceilPow2From 0 1 P.k_d).1 = P.u_d := congrArg Prod.fst hud_eq.symm
  have hpkd1 : (ceilPow2From 0 1 P.k_d).2 = P.pk_d := congrArg Prod.snd hud_eq.symm
  rw [hud1] at hs8 hud_m8
  rw [hpkd1] at hpkd_m8
  have hfr8_5 : ∀ i : ℤ, i ≠ 4 → i ≠ 5 → wRead m8 1 i = wRead m5 1 i := by
    intro i h4 h5
    rw [hfr8 1 i (Or.inr ⟨h4, h5⟩),
      wRead_wWrite_of_ne m6 _ (Or.inr h5),
      wRead_wWrite_of_ne m5 _ (Or.inr h4)]
  let m9 := wWrite m8 1 6 0
  have hs9 : DetExec inp (wSet 1 6 (iLit 0)) m8 m9 10 :=
    DetExec.writeWord inp m8 1 (.lit 6) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let m10 := wWrite m9 1 7 1
  have hs10 : DetExec inp (wSet 1 7 (iLit 1)) m9 m10 10 :=
    DetExec.writeWord inp m9 1 (.lit 7) (iLit 1) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  have hkphi_m10 : wRead m10 1 3 = (P.k_phi : ℤ) := by
    rw [wRead_wWrite_of_ne m9 _ (Or.inr (by decide)),
      wRead_wWrite_of_ne m8 _ (Or.inr (by decide)),
      hfr8_5 3 (by decide) (by decide), hkphi_m5]
  rcases exec_ceilPow2Loop (m₀ := m10) inp 6 7 (by decide) (wReg 1 3)
    (by dsimp [intExprOps, wReg]; omega) P.k_phi
    (fun m hfm => by change wRead m 1 3 = _; rw [hfm 1 3 (Or.inr ⟨by decide, by decide⟩), hkphi_m10])
    P.k_phi 0 1 m10 (by omega) (by omega)
    (by rw [wRead_wWrite_of_ne m9 _ (Or.inr (by decide))]; simp [m9])
    (by simp [m10]) (fun _ _ _ => rfl) with
    ⟨m11, hs11, huphi_m11, hpkphi_m11, hfr11, _⟩
  have huphi1 : (ceilPow2From 0 1 P.k_phi).1 = P.u_phi := congrArg Prod.fst huphi_eq.symm
  have hpkphi1 : (ceilPow2From 0 1 P.k_phi).2 = P.pk_phi := congrArg Prod.snd huphi_eq.symm
  rw [huphi1] at hs11 huphi_m11
  rw [hpkphi1] at hpkphi_m11
  have hfr11_8 : ∀ i : ℤ, i ≠ 6 → i ≠ 7 → wRead m11 1 i = wRead m8 1 i := by
    intro i h6 h7
    rw [hfr11 1 i (Or.inr ⟨h6, h7⟩),
      wRead_wWrite_of_ne m9 _ (Or.inr h7),
      wRead_wWrite_of_ne m8 _ (Or.inr h6)]
  have hD_m11 : wRead m11 1 0 = (P.D : ℤ) := by
    rw [hfr11_8 0 (by decide) (by decide), hfr8_5 0 (by decide) (by decide), hD_m5]
  have hkd_m11 : wRead m11 1 1 = (P.k_d : ℤ) := by
    rw [hfr11_8 1 (by decide) (by decide), hfr8_5 1 (by decide) (by decide), hkd_m5]
  have hpd_m11 : wRead m11 1 2 = (P.p_d : ℤ) := by
    rw [hfr11_8 2 (by decide) (by decide), hfr8_5 2 (by decide) (by decide), hpd_m5]
  have hkphi_m11 : wRead m11 1 3 = (P.k_phi : ℤ) := by
    rw [hfr11_8 3 (by decide) (by decide), hfr8_5 3 (by decide) (by decide), hkphi_m5]
  have hud_m11 : wRead m11 1 4 = (P.u_d : ℤ) := by
    rw [hfr11_8 4 (by decide) (by decide), hud_m8]
  have hpkd_m11 : wRead m11 1 5 = (P.pk_d : ℤ) := by
    rw [hfr11_8 5 (by decide) (by decide), hpkd_m8]
  let m12 := wWrite m11 1 8 (P.q : ℤ)
  have hs12 : DetExec inp
      (wSet 1 8 (.add (.add (.add (iLit 16) (.mul (iLit 3) (wReg 1 1))) (wReg 1 4)) (wReg 1 6)))
      m11 m12 25 := by
    refine DetExec.writeWord inp m11 1 (.lit 8) _ rfl ?_
      (by dsimp [intExprOps, wReg, iLit]; omega)
    simp -zeta [wReg, iLit, hkd_m11, hud_m11, huphi_m11, hq_eq]
  let m13 := wWrite m12 1 9 (P.m : ℤ)
  have hs13 : DetExec inp
      (wSet 1 9 (.mul (.mul (.mul (.mul (.mul (iLit 65536) (wReg 1 2)) (wReg 1 2)) (wReg 1 2))
        (wReg 1 5)) (wReg 1 7)))
      m12 m13 30 := by
    refine DetExec.writeWord inp m12 1 (.lit 9) _ rfl ?_
      (by dsimp [intExprOps, wReg, iLit]; omega)
    have hp2 : wRead m12 1 2 = (P.p_d : ℤ) := by
      rw [wRead_wWrite_of_ne m11 _ (Or.inr (by decide)), hpd_m11]
    have hp5 : wRead m12 1 5 = (P.pk_d : ℤ) := by
      rw [wRead_wWrite_of_ne m11 _ (Or.inr (by decide)), hpkd_m11]
    have hp7 : wRead m12 1 7 = (P.pk_phi : ℤ) := by
      rw [wRead_wWrite_of_ne m11 _ (Or.inr (by decide)), hpkphi_m11]
    simp -zeta [wReg, iLit, hp2, hp5, hp7, hm_eq]
  let m14 := wWrite m13 1 11 ((P.D + 1 : ℕ) : ℤ)
  have hs14 : DetExec inp (wSet 1 11 (.add (wReg 1 0) (iLit 1))) m13 m14 10 := by
    refine DetExec.writeWord inp m13 1 (.lit 11) _ rfl ?_
      (by dsimp [intExprOps, wReg, iLit]; omega)
    have hp0 : wRead m13 1 0 = (P.D : ℤ) := by
      rw [wRead_wWrite_of_ne m12 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m11 _ (Or.inr (by decide)), hD_m11]
    simp -zeta [wReg, iLit, hp0]
  let m15 := wWrite m14 1 12 ((P.D + 2 : ℕ) : ℤ)
  have hs15 : DetExec inp (wSet 1 12 (.add (wReg 1 0) (iLit 2))) m14 m15 10 := by
    refine DetExec.writeWord inp m14 1 (.lit 12) _ rfl ?_
      (by dsimp [intExprOps, wReg, iLit]; omega)
    have hp0 : wRead m14 1 0 = (P.D : ℤ) := by
      rw [wRead_wWrite_of_ne m13 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m12 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m11 _ (Or.inr (by decide)), hD_m11]
    simp -zeta [wReg, iLit, hp0]
  let m16 := wWrite m15 1 13 ((P.D + 3 : ℕ) : ℤ)
  have hs16 : DetExec inp (wSet 1 13 (.add (wReg 1 0) (iLit 3))) m15 m16 10 := by
    refine DetExec.writeWord inp m15 1 (.lit 13) _ rfl ?_
      (by dsimp [intExprOps, wReg, iLit]; omega)
    have hp0 : wRead m15 1 0 = (P.D : ℤ) := by
      rw [wRead_wWrite_of_ne m14 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m13 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m12 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m11 _ (Or.inr (by decide)), hD_m11]
    simp -zeta [wReg, iLit, hp0]
  let m17 := wWrite m16 1 10 (P.L : ℤ)
  have hs17 : DetExec inp
      (wSet 1 10 (.mul (.mul (iLit 3) (wReg 1 9))
        (.add (.add (.mul (.mul (iLit 4) (wReg 1 12)) (wReg 1 8))
          (.mul (iLit 4) (wReg 1 3))) (iLit 16))))
      m16 m17 35 := by
    refine DetExec.writeWord inp m16 1 (.lit 10) _ rfl ?_
      (by dsimp [intExprOps, wReg, iLit]; omega)
    have hp9 : wRead m16 1 9 = (P.m : ℤ) := by
      rw [wRead_wWrite_of_ne m15 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m14 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m13 _ (Or.inr (by decide))]
      simp [m13]
    have hp12 : wRead m16 1 12 = ((P.D + 2 : ℕ) : ℤ) := by
      rw [wRead_wWrite_of_ne m15 _ (Or.inr (by decide))]
      simp [m15]
    have hp8 : wRead m16 1 8 = (P.q : ℤ) := by
      rw [wRead_wWrite_of_ne m15 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m14 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m13 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m12 _ (Or.inr (by decide))]
      simp [m12]
    have hp3 : wRead m16 1 3 = (P.k_phi : ℤ) := by
      rw [wRead_wWrite_of_ne m15 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m14 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m13 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m12 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m11 _ (Or.inr (by decide)), hkphi_m11]
    simp -zeta [wReg, iLit, hp9, hp12, hp8, hp3, hL_eq]
  have hfr17 : ∀ i : ℤ, i ≠ 8 → i ≠ 9 → i ≠ 11 → i ≠ 12 → i ≠ 13 → i ≠ 10 →
      wRead m17 1 i = wRead m11 1 i := by
    intro i h8 h9 h11 h12 h13 h10
    rw [wRead_wWrite_of_ne m16 _ (Or.inr h10),
      wRead_wWrite_of_ne m15 _ (Or.inr h13),
      wRead_wWrite_of_ne m14 _ (Or.inr h12),
      wRead_wWrite_of_ne m13 _ (Or.inr h11),
      wRead_wWrite_of_ne m12 _ (Or.inr h9),
      wRead_wWrite_of_ne m11 _ (Or.inr h8)]
  have hParams : ParamsStored P m17 := by
    refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · rw [hfr17 0 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hD_m11]
    · rw [hfr17 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hkd_m11]
    · rw [hfr17 2 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hpd_m11]
    · rw [hfr17 3 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hkphi_m11]
    · rw [hfr17 4 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hud_m11]
    · rw [hfr17 5 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hpkd_m11]
    · rw [hfr17 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), huphi_m11]
    · rw [hfr17 7 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hpkphi_m11]
    · rw [wRead_wWrite_of_ne m16 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m15 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m14 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m13 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m12 _ (Or.inr (by decide))]; simp [m12]
    · rw [wRead_wWrite_of_ne m16 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m15 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m14 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m13 _ (Or.inr (by decide))]; simp [m13]
    · simp [m17]
    · rw [wRead_wWrite_of_ne m16 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m15 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m14 _ (Or.inr (by decide))]; simp [m14]
    · rw [wRead_wWrite_of_ne m16 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m15 _ (Or.inr (by decide))]; simp [m15]
    · rw [wRead_wWrite_of_ne m16 _ (Or.inr (by decide))]; simp [m16]
  refine ⟨m17, ?_, hParams⟩
  unfold phase1Stmt seqList
  refine (hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq (hs6.seq (hs7.seq (hs8.seq (hs9.seq
    (hs10.seq (hs11.seq (hs12.seq (hs13.seq (hs14.seq (hs15.seq (hs16.seq hs17)))))))))))))))).mono_cost ?_
  omega

private theorem rVal_activePtCoord_of_mem {d : ℕ} (inp : UL.ArithRAMInput d)
    (mem : UL.ArithRAMMemory) (hE cE : UL.IntExpr) {h_nat c_nat : ℕ}
    (hh_val : iVal inp mem hE = (h_nat : ℤ))
    (hh_mem : h_nat ∈ inp.activeHandles)
    (hc_val : iVal inp mem cE = (c_nat : ℤ))
    (hc_lt : c_nat < d) :
    rVal inp mem (.activePtCoord hE cE) =
      UL.euclideanCoord (inp.activeCoords h_nat) ⟨c_nat, hc_lt⟩ := by
  unfold rVal UL.evalRealExpr
  rcases he₁ : UL.evalIntExpr inp.toWordView 0 mem.words hE with ⟨hv, u₁, b₁⟩
  rcases he₂ : UL.evalIntExpr inp.toWordView 0 mem.words cE with ⟨cv, u₂, b₂⟩
  have hhv : hv = (h_nat : ℤ) := by rw [← hh_val, iVal, he₁]
  have hcv : cv = (c_nat : ℤ) := by rw [← hc_val, iVal, he₂]
  subst hhv; subst hcv
  simp [hh_mem, hc_lt]

private theorem euclidean_sum_sq_eq_norm_sq {d : ℕ} (x : EuclideanSpace ℝ (Fin d)) :
    (∑ c : Fin d, UL.euclideanCoord x c * UL.euclideanCoord x c) = ‖x‖ ^ 2 := by
  rw [EuclideanSpace.norm_sq_eq]
  refine Finset.sum_congr rfl fun c _ => ?_
  rw [Real.norm_eq_abs, sq_abs, sq]
  rfl

private theorem euclideanCoord_paraboloidLift {d : ℕ} (x : EuclideanSpace ℝ (Fin d))
    (c : Fin (d + 1)) :
    UL.euclideanCoord (UL.paraboloidLift x) c =
      if hc : c.val < d then UL.euclideanCoord x ⟨c.val, hc⟩ else ‖x‖ ^ 2 := by
  unfold UL.paraboloidLift UL.liftedPoint UL.euclideanCoord
  refine Fin.lastCases ?_ ?_ c
  · simp
  · intro j
    simp [Fin.snoc_castSucc]

private theorem flat2d_inj {D p₁ p₂ c₁ c₂ : ℕ} (hc₁ : c₁ < D) (hc₂ : c₂ < D)
    (heq : ((p₁ * D + c₁ : ℕ) : ℤ) = ((p₂ * D + c₂ : ℕ) : ℤ)) :
    p₁ = p₂ ∧ c₁ = c₂ := by
  have hnat : p₁ * D + c₁ = p₂ * D + c₂ := Int.ofNat.inj heq
  have hp : p₁ = p₂ := by
    have hdiv₁ : (p₁ * D + c₁) / D = p₁ := by
      rw [Nat.mul_comm, Nat.mul_add_div (by omega), Nat.div_eq_of_lt hc₁, add_zero]
    have hdiv₂ : (p₂ * D + c₂) / D = p₂ := by
      rw [Nat.mul_comm, Nat.mul_add_div (by omega), Nat.div_eq_of_lt hc₂, add_zero]
    rw [← hdiv₁, hnat, hdiv₂]
  subst hp
  exact ⟨rfl, by omega⟩

private theorem exec_phase2 {d : ℕ} {P : HPJParams}
    (hPD : P.D = d + 1) (hm_eq : P.m = 2 ^ P.q)
    {ι : Type} [Fintype ι] [Nonempty ι]
    (P₀ : ι → EuclideanSpace ℝ (Fin d)) (handle : ι ↪ ℕ)
    (N : ℕ) (hmN : 2 ^ P.q ≤ N) (ω : Fin N → ι) {φ : ℝ}
    (mem₀ : UL.ArithRAMMemory) (hParams₀ : ParamsStored P mem₀) :
    let inp : UL.ArithRAMInput d :=
      { intParams := List.ofFn (fun k : Fin N => (handle (ω k) : ℤ))
        activeHandles := (Finset.univ : Finset ι).map handle
        activeCoords := fun h =>
          if hh : ∃ i : ι, handle i = h then P₀ (Classical.choose hh) else 0
        extraReals := [φ] }
    let T₀ : Fin (2 ^ P.q) → EuclideanSpace ℝ (Fin (d + 1)) := fun j =>
      UL.paraboloidLift (P₀ (ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩))
    ∃ mem₁,
      DetExec inp phase2Stmt mem₀ mem₁ (10 + P.m * (100 * (P.D + 2))) ∧
      ParamsStored P mem₁ ∧
      PoolStored T₀ mem₁ := by
  intro inp T₀
  let m_init := wWrite mem₀ 4 0 0
  have hs_init : DetExec inp (wSet 4 0 (iLit 0)) mem₀ m_init 5 :=
    DetExec.writeWord inp mem₀ 4 (.lit 0) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let InvP : ℕ → UL.ArithRAMMemory → Prop := fun p m =>
    ParamsStored P m ∧
    wRead m 4 0 = (p : ℤ) ∧
    (∀ (p' : ℕ) (hp' : p' < p) (hp'm : p' < 2 ^ P.q) (c : Fin (d + 1)),
      rRead m 2 ((p' * (d + 1) + c.val : ℕ) : ℤ) = UL.euclideanCoord (T₀ ⟨p', hp'm⟩) c)
  have hPar_init : ParamsStored P m_init := paramsStored_wWrite_ne hParams₀ 4 0 0
  have hInvP₀ : InvP 0 m_init := ⟨hPar_init, by simp [m_init], fun _ hp' => by omega⟩
  have hm_cnt : iVal inp m_init (wReg 1 9) = ((2 ^ P.q : ℕ) : ℤ) := by
    change wRead m_init 1 9 = _; rw [hPar_init.hm, hm_eq]
  let coordBody : UL.ArithRAMStmt :=
    seqList
      [ rSet 1 2 (.activePtCoord (wReg 4 1) (wReg 4 2)),
        rSetArr 2 (.add (.mul (wReg 4 0) (wReg 1 0)) (wReg 4 2)) (rReg 1 2),
        rSet 1 1 (.add (rReg 1 1) (.mul (rReg 1 2) (rReg 1 2))),
        wSet 4 2 (.add (wReg 4 2) (iLit 1)) ]
  rcases DetExec.repeatN_nat (wReg 1 9) phase2PointBody (2 ^ P.q) 5 (100 * ((d + 1) + 2))
    InvP hInvP₀ hm_cnt (by dsimp [intExprOps, wReg]; omega)
    (fun p hp_lt m ⟨hPar, hp_reg, hprev⟩ => by
      have hpN : p < N := lt_of_lt_of_le hp_lt hmN
      let x_p := P₀ (ω ⟨p, hpN⟩)
      let h_nat := handle (ω ⟨p, hpN⟩)
      let m1 := wWrite m 4 1 (h_nat : ℤ)
      have hs1 : DetExec inp (wSet 4 1 (.intParam (wReg 4 0))) m m1 10 := by
        refine DetExec.writeWord inp m 4 (.lit 1) (.intParam (wReg 4 0)) rfl ?_
          (by dsimp [intExprOps, wReg]; omega)
        simp only [iVal_intParam, wReg, iVal_readHeap, iVal_lit, hp_reg, UL.listGetIntD,
          Int.natCast_nonneg, ↓reduceIte, Int.toNat_natCast]
        have hlen : p < (List.ofFn (fun k : Fin N => (handle (ω k) : ℤ))).length := by
          simp [hpN]
        rw [List.getD_eq_getElem _ 0 hlen, List.getElem_ofFn]
      let m2 := rWrite m1 1 1 0
      have hs2 : DetExec inp (rSet 1 1 (rLit 0)) m1 m2 10 := by
        refine DetExec.writeReal inp m1 1 (.lit 1) (rLit 0) rfl ?_
          (by dsimp [intExprOps, realExprOps, rLit]; omega)
        simp [rLit]
      let m3 := wWrite m2 4 2 0
      have hs3 : DetExec inp (wSet 4 2 (iLit 0)) m2 m3 10 :=
        DetExec.writeWord inp m2 4 (.lit 2) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
      let InvC : ℕ → UL.ArithRAMMemory → Prop := fun c mc =>
        ParamsStored P mc ∧
        wRead mc 4 0 = (p : ℤ) ∧
        wRead mc 4 1 = (h_nat : ℤ) ∧
        wRead mc 4 2 = (c : ℤ) ∧
        (∃ hc_le : c ≤ d,
          rRead mc 1 1 =
            (∑ j : Fin c,
              UL.euclideanCoord x_p ⟨j.val, lt_of_lt_of_le j.isLt hc_le⟩ *
                UL.euclideanCoord x_p ⟨j.val, lt_of_lt_of_le j.isLt hc_le⟩) ∧
          (∀ (j : ℕ) (hj : j < c),
            rRead mc 2 ((p * (d + 1) + j : ℕ) : ℤ) =
              UL.euclideanCoord x_p ⟨j, lt_of_lt_of_le hj hc_le⟩)) ∧
        (∀ (p' : ℕ) (hp' : p' < p) (hp'm : p' < 2 ^ P.q) (coord : Fin (d + 1)),
          rRead mc 2 ((p' * (d + 1) + coord.val : ℕ) : ℤ) = UL.euclideanCoord (T₀ ⟨p', hp'm⟩) coord)
      have hInvC₀ : InvC 0 m3 := by
        refine ⟨paramsStored_wWrite_ne (paramsStored_rWrite
            (paramsStored_wWrite_ne hPar 4 1 _) 1 1 0) 4 2 0,
          ?_, ?_, by simp [m3],
          ⟨Nat.zero_le d, by simp [m3, m2], fun _ hj => by omega⟩,
          fun p' hp' hp'm coord => ?_⟩
        · rw [wRead_wWrite_of_ne m2 _ (Or.inr (by decide)), wRead_rWrite,
            wRead_wWrite_of_ne m _ (Or.inr (by decide)), hp_reg]
        · rw [wRead_wWrite_of_ne m2 _ (Or.inr (by decide))]; simp [m2, m1]
        · simp only [m3, rRead_wWrite, m2]
          rw [rRead_rWrite_of_ne m1 0 (Or.inl (by decide))]
          exact hprev p' hp' hp'm coord
      rcases DetExec.repeatN_nat .dim coordBody d 5 60 InvC hInvC₀ rfl
        (by dsimp [intExprOps]; omega)
        (fun c hc_lt mc ⟨hParC, hpC, hhC, hcC, ⟨_, hsumC, hjC⟩, hprevC⟩ => by
          have hh_mem : h_nat ∈ inp.activeHandles :=
            Finset.mem_map.mpr ⟨ω ⟨p, hpN⟩, Finset.mem_univ _, rfl⟩
          have hact_eq : inp.activeCoords h_nat = x_p := by
            dsimp only [inp]
            have hex : ∃ i : ι, handle i = h_nat := ⟨ω ⟨p, hpN⟩, rfl⟩
            rw [dif_pos hex]
            congr 1
            exact handle.injective (Classical.choose_spec hex)
          let val_c := UL.euclideanCoord x_p ⟨c, hc_lt⟩
          let mc1 := rWrite mc 1 2 val_c
          have hsc1 : DetExec inp (rSet 1 2 (.activePtCoord (wReg 4 1) (wReg 4 2))) mc mc1 15 := by
            refine DetExec.writeReal inp mc 1 (.lit 2) (.activePtCoord (wReg 4 1) (wReg 4 2)) rfl ?_
              (by dsimp [intExprOps, realExprOps, wReg]; omega)
            rw [rVal_activePtCoord_of_mem inp mc (wReg 4 1) (wReg 4 2)
              hhC hh_mem hcC hc_lt, hact_eq]
          let mc2 := rWrite mc1 2 ((p * (d + 1) + c : ℕ) : ℤ) val_c
          have hsc2 : DetExec inp
              (rSetArr 2 (.add (.mul (wReg 4 0) (wReg 1 0)) (wReg 4 2)) (rReg 1 2)) mc1 mc2 15 := by
            refine DetExec.writeReal inp mc1 2 _ (rReg 1 2) ?_ (by simp [rReg, mc1])
              (by dsimp [intExprOps, realExprOps, wReg, rReg]; omega)
            have h0C : wRead mc1 1 0 = ((d + 1 : ℕ) : ℤ) := by
              change wRead mc 1 0 = _; rw [hParC.hD, hPD]
            have hpC' : wRead mc1 4 0 = (p : ℤ) := hpC
            have hcC' : wRead mc1 4 2 = (c : ℤ) := hcC
            simp -zeta [wReg, hpC', h0C, hcC']
          let mc3 := rWrite mc2 1 1 (rRead mc 1 1 + val_c * val_c)
          have hsc3 : DetExec inp
              (rSet 1 1 (.add (rReg 1 1) (.mul (rReg 1 2) (rReg 1 2)))) mc2 mc3 15 := by
            refine DetExec.writeReal inp mc2 1 (.lit 1) _ rfl ?_
              (by dsimp [intExprOps, realExprOps, rReg]; omega)
            have hr11 : rRead mc2 1 1 = rRead mc 1 1 := by
              rw [rRead_rWrite_of_ne mc1 _ (Or.inl (by decide)),
                rRead_rWrite_of_ne mc _ (Or.inr (by decide))]
            have hr12 : rRead mc2 1 2 = val_c := by
              rw [rRead_rWrite_of_ne mc1 _ (Or.inl (by decide))]; simp [mc1]
            simp -zeta [rReg, hr11, hr12]
          let mc4 := wWrite mc3 4 2 ((c + 1 : ℕ) : ℤ)
          have hsc4 : DetExec inp (wSet 4 2 (.add (wReg 4 2) (iLit 1))) mc3 mc4 15 := by
            refine DetExec.writeWord inp mc3 4 (.lit 2) _ rfl ?_
              (by dsimp [intExprOps, wReg, iLit]; omega)
            simp [wReg, iLit, mc3, mc2, mc1, hcC]
          refine ⟨mc4, ?_, ?_⟩
          · unfold coordBody seqList
            exact (hsc1.seq (hsc2.seq (hsc3.seq hsc4))).mono_cost (by omega)
          · refine ⟨paramsStored_wWrite_ne hParC 4 2 _,
              by rw [wRead_wWrite_of_ne mc3 _ (Or.inr (by decide))]; exact hpC,
              by rw [wRead_wWrite_of_ne mc3 _ (Or.inr (by decide))]; exact hhC,
              by simp [mc4], ⟨by omega, ?_, ?_⟩, ?_⟩
            · simp only [mc4, rRead_wWrite, mc3, rRead_rWrite_self, hsumC]
              rw [Fin.sum_univ_castSucc]
              rfl
            · intro j hj
              simp only [mc4, rRead_wWrite, mc3]
              rw [rRead_rWrite_of_ne mc2 _ (Or.inl (by decide))]
              by_cases hjc : j = c
              · subst hjc; simp [mc2, val_c]
              · have hne_idx : ((p * (d + 1) + j : ℕ) : ℤ) ≠ ((p * (d + 1) + c : ℕ) : ℤ) := by
                  intro heq
                  exact hjc (flat2d_inj (by omega) (by omega) heq).2
                rw [rRead_rWrite_of_ne mc1 _ (Or.inr hne_idx),
                  rRead_rWrite_of_ne mc _ (Or.inl (by decide))]
                exact hjC j (by omega)
            · intro p' hp' hp'm coord
              simp only [mc4, rRead_wWrite, mc3]
              rw [rRead_rWrite_of_ne mc2 _ (Or.inl (by decide))]
              have hne_idx : ((p' * (d + 1) + coord.val : ℕ) : ℤ) ≠
                  ((p * (d + 1) + c : ℕ) : ℤ) := by
                intro heq
                have hp_eq := (flat2d_inj coord.isLt (by omega) heq).1
                omega
              rw [rRead_rWrite_of_ne mc1 _ (Or.inr hne_idx),
                rRead_rWrite_of_ne mc _ (Or.inl (by decide))]
              exact hprevC p' hp' hp'm coord)
        with ⟨m4, ⟨hPar4, hp4, _, _, ⟨_, hsum4, hj4⟩, hprev4⟩, hs4⟩
      let m5 := rWrite m4 2 ((p * (d + 1) + d : ℕ) : ℤ) (‖x_p‖ ^ 2)
      have hs5 : DetExec inp
          (rSetArr 2 (.add (.mul (wReg 4 0) (wReg 1 0)) .dim) (rReg 1 1)) m4 m5 20 := by
        refine DetExec.writeReal inp m4 2 _ (rReg 1 1) ?_ ?_
          (by dsimp [intExprOps, realExprOps, wReg, rReg]; omega)
        · have h0_4 : wRead m4 1 0 = ((d + 1 : ℕ) : ℤ) := by rw [hPar4.hD, hPD]
          simp -zeta [wReg, hp4, h0_4]
        · change rRead m4 1 1 = ‖x_p‖ ^ 2
          rw [hsum4, ← euclidean_sum_sq_eq_norm_sq x_p]
      let m6 := wWrite m5 4 0 ((p + 1 : ℕ) : ℤ)
      have hs6 : DetExec inp (wSet 4 0 (.add (wReg 4 0) (iLit 1))) m5 m6 15 := by
        refine DetExec.writeWord inp m5 4 (.lit 0) _ rfl ?_
          (by dsimp [intExprOps, wReg, iLit]; omega)
        simp -zeta [wReg, iLit, m5, hp4]
      refine ⟨m6, ?_, paramsStored_wWrite_ne hPar4 4 0 _, by simp [m6], ?_⟩
      · unfold phase2PointBody seqList
        exact (hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq hs6))))).mono_cost (by omega)
      · intro p' hp' hp'm coord
        simp only [m6, rRead_wWrite]
        by_cases hpp : p' = p
        · subst hpp
          have hT₀_eq : T₀ ⟨p', hp'm⟩ = UL.paraboloidLift x_p := rfl
          rw [hT₀_eq, euclideanCoord_paraboloidLift]
          split_ifs with hcd
          · have hne_idx : ((p' * (d + 1) + coord.val : ℕ) : ℤ) ≠
                ((p' * (d + 1) + d : ℕ) : ℤ) := by
              intro heq
              have := (flat2d_inj coord.isLt (by omega) heq).2
              omega
            rw [rRead_rWrite_of_ne m4 _ (Or.inr hne_idx)]
            exact hj4 coord.val hcd
          · have hcd_eq : coord.val = d := by omega
            rw [hcd_eq]
            simp [m5]
        · have hne_idx : ((p' * (d + 1) + coord.val : ℕ) : ℤ) ≠
              ((p * (d + 1) + d : ℕ) : ℤ) := by
            intro heq
            exact hpp (flat2d_inj coord.isLt (by omega) heq).1
          rw [rRead_rWrite_of_ne m4 _ (Or.inr hne_idx)]
          exact hprev4 p' (by omega) hp'm coord)
    with ⟨mem₁, ⟨hPar₁, _, hpool₁⟩, hloop⟩
  have hcost_eq : 5 + (5 + 2 ^ P.q * (100 * (d + 1 + 2))) ≤ 10 + P.m * (100 * (P.D + 2)) := by
    rw [← hm_eq, ← hPD]; omega
  refine ⟨mem₁, (hs_init.seq hloop).mono_cost hcost_eq, hPar₁, fun p c => ?_⟩
  exact hpool₁ p.val p.isLt p.isLt c

/-! ### 5. Subphase 3.1 verification: random bit sampling (`sampleSlotsStmt`) -/

private def IdxArrStored {D m : ℕ} (choice : (Fin (D + 2) → Fin m) × Fin m)
    (mem : UL.ArithRAMMemory) : Prop :=
  (∀ a : Fin (D + 2), wRead mem 2 (a.val : ℤ) = ((choice.1 a).val : ℤ)) ∧
  wRead mem 2 ((D + 2 : ℕ) : ℤ) = (choice.2.val : ℤ)

private theorem idxArrStored_wWrite_ne {D m : ℕ} {choice : (Fin (D + 2) → Fin m) × Fin m}
    {mem : UL.ArithRAMMemory} (h : IdxArrStored choice mem) (t : ℕ) (idx v : ℤ)
    (ht : t ≠ 2 := by decide) :
    IdxArrStored choice (wWrite mem t idx v) := by
  refine ⟨fun a => ?_, ?_⟩
  · rw [wRead_wWrite_of_ne mem v (Or.inl ht.symm)]; exact h.1 a
  · rw [wRead_wWrite_of_ne mem v (Or.inl ht.symm)]; exact h.2

private theorem idxArrStored_rWrite {D m : ℕ} {choice : (Fin (D + 2) → Fin m) × Fin m}
    {mem : UL.ArithRAMMemory} (h : IdxArrStored choice mem) (t : ℕ) (idx : ℤ) (v : ℝ) :
    IdxArrStored choice (rWrite mem t idx v) := h

private def stepChoiceOfBits (D q : ℕ) (f : Fin ((D + 3) * q) → Bool) :
    (Fin (D + 2) → Fin (2 ^ q)) × Fin (2 ^ q) :=
  (fun a : Fin (D + 2) =>
     bitsFnToFin q (fun b : Fin q => f ⟨a.val * q + b.val, by
       have ha : a.val + 1 ≤ D + 3 := by omega
       calc a.val * q + b.val < a.val * q + q := by omega
         _ = (a.val + 1) * q := by ring
         _ ≤ (D + 3) * q := Nat.mul_le_mul_right q ha⟩),
   bitsFnToFin q (fun b : Fin q => f ⟨(D + 2) * q + b.val, by
     calc (D + 2) * q + b.val < (D + 2) * q + q := by omega
       _ = (D + 3) * q := by ring⟩))

private theorem exec_readQBits {d D m : ℕ} (inp : UL.ArithRAMInput d)
    {P : HPJParams} {T : Fin m → EuclideanSpace ℝ (Fin D)}
    (mem₀ : UL.ArithRAMMemory) (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T mem₀) :
    RandExec inp readQBitsStmt P.q mem₀
      (fun f m₁ =>
        ParamsStored P m₁ ∧
        PoolStored T m₁ ∧
        wRead m₁ 4 3 = wRead mem₀ 4 3 ∧
        (∀ s : ℤ, wRead m₁ 2 s = wRead mem₀ 2 s) ∧
        wRead m₁ 4 4 = (bitsFnToNat P.q f : ℤ))
      (10 + P.q * 20) := by
  let m_init := wWrite mem₀ 4 4 0
  have hs_init : DetExec inp (wSet 4 4 (iLit 0)) mem₀ m_init 5 :=
    DetExec.writeWord inp mem₀ 4 (.lit 4) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let Inv : (i : ℕ) → (Fin (i * 1) → Bool) → UL.ArithRAMMemory → Prop := fun i f m =>
    ParamsStored P m ∧
    PoolStored T m ∧
    wRead m 4 3 = wRead mem₀ 4 3 ∧
    (∀ s : ℤ, wRead m 2 s = wRead mem₀ 2 s) ∧
    wRead m 4 4 = (bitsFnToNat i (fun b : Fin i => f ⟨b.val, by omega⟩) : ℤ)
  have hPar_init : ParamsStored P m_init := paramsStored_wWrite_ne hPar₀ 4 4 0
  have hInv₀ : ∀ f₀ : Fin (0 * 1) → Bool, Inv 0 f₀ m_init := by
    intro _
    refine ⟨hPar_init, poolStored_wWrite hPool₀ 4 4 0,
      wRead_wWrite_of_ne mem₀ 0 (Or.inr (by decide)),
      fun s => wRead_wWrite_of_ne mem₀ 0 (Or.inl (by decide)), by simp [m_init, bitsFnToNat]⟩
  have hcnt : iVal inp m_init (wReg 1 8) = (P.q : ℤ) := hPar_init.hq
  let bitBody : UL.ArithRAMStmt :=
    .seq (.randBitHeap 4 (iLit 5)) (wSet 4 4 (.add (.mul (iLit 2) (wReg 4 4)) (wReg 4 5)))
  have hloop := RandExec.repeatN_nat (wReg 1 8) bitBody P.q 1 5 20 Inv hInv₀ hcnt
    (by dsimp [intExprOps, wReg]; omega)
    (fun i _ f_prev m ⟨hPar, hPool, h43, h2, h44⟩ => by
      have hr : RandExec inp (.randBitHeap 4 (iLit 5)) 1 m _ 5 :=
        RandExec.randBit inp m 4 (iLit 5) rfl (by dsimp [intExprOps, iLit]; omega)
      refine RandExec.seq_det_right
        (s₂ := wSet 4 4 (.add (.mul (iLit 2) (wReg 4 4)) (wReg 4 5))) (C₂ := 15) hr ?_
      intro f_cur m_bit hm_bit
      subst hm_bit
      let bit_val : ℤ := if f_cur ⟨0, Nat.zero_lt_one⟩ then 1 else 0
      let m_acc := wWrite (wWrite m 4 5 bit_val) 4 4
        (2 * (bitsFnToNat i (fun b : Fin i => f_prev ⟨b.val, by omega⟩) : ℤ) + bit_val)
      have hs_acc : DetExec inp (wSet 4 4 (.add (.mul (iLit 2) (wReg 4 4)) (wReg 4 5)))
          (wWrite m 4 5 bit_val) m_acc 15 := by
        refine DetExec.writeWord inp (wWrite m 4 5 bit_val) 4 (.lit 4)
          (.add (.mul (iLit 2) (wReg 4 4)) (wReg 4 5)) rfl ?_
          (by dsimp [intExprOps, wReg, iLit]; omega)
        have h44' : wRead (wWrite m 4 5 bit_val) 4 4 = wRead m 4 4 :=
          wRead_wWrite_of_ne m _ (Or.inr (by decide))
        change (2 : ℤ) * wRead (wWrite m 4 5 bit_val) 4 4 + wRead (wWrite m 4 5 bit_val) 4 5 = _
        rw [h44', h44, wRead_wWrite_self]
      refine ⟨m_acc, hs_acc, fun f_next hprev hcur => ?_⟩
      refine ⟨paramsStored_wWrite_ne (paramsStored_wWrite_ne hPar 4 5 _) 4 4 _,
        poolStored_wWrite (poolStored_wWrite hPool 4 5 _) 4 4 _,
        ?_, ?_, ?_⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inr (by decide)), h43]
      · intro s
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inl (by decide)), h2 s]
      · simp only [m_acc, wRead_wWrite_self, bitsFnToNat]
        have hf_init : (fun b : Fin i => f_next ⟨b.castSucc.val, by omega⟩) =
            (fun b : Fin i => f_prev ⟨b.val, by omega⟩) := by
          funext b
          exact hprev ⟨b.val, by omega⟩
        have hf_last : f_next ⟨(Fin.last i).val, by omega⟩ = f_cur ⟨0, Nat.zero_lt_one⟩ := by
          simpa [Fin.last] using hcur ⟨0, Nat.zero_lt_one⟩
        simp only [hf_init, hf_last]
        dsimp [bit_val]
        split_ifs <;> omega)
  refine (RandExec.seq_det_left hs_init (RandExec.cast_bits (Nat.mul_one P.q) hloop ?_)).mono
    (fun _ _ h => h) (by omega)
  intro f m₁ ⟨hPar, hPool, h43, h2, h44⟩
  exact ⟨hPar, hPool, h43, h2, h44⟩

private theorem exec_sampleSlots {d D : ℕ} (inp : UL.ArithRAMInput d)
    {P : HPJParams} (hPD : P.D = D)
    {T : Fin (2 ^ P.q) → EuclideanSpace ℝ (Fin D)}
    (mem₀ : UL.ArithRAMMemory) (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T mem₀) :
    RandExec inp sampleSlotsStmt ((D + 3) * P.q) mem₀
      (fun f m₁ =>
        ParamsStored P m₁ ∧
        PoolStored T m₁ ∧
        IdxArrStored (stepChoiceOfBits D P.q f) m₁)
      (50 * (D + 3) * (P.q + 1)) := by
  let m_init := wWrite mem₀ 4 3 0
  have hs_init : DetExec inp (wSet 4 3 (iLit 0)) mem₀ m_init 5 :=
    DetExec.writeWord inp mem₀ 4 (.lit 3) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let Inv : (s : ℕ) → (Fin (s * P.q) → Bool) → UL.ArithRAMMemory → Prop := fun s f m =>
    ParamsStored P m ∧
    PoolStored T m ∧
    wRead m 4 3 = (s : ℤ) ∧
    (∀ (a : ℕ) (ha : a < s),
      wRead m 2 (a : ℤ) =
        (bitsFnToNat P.q (fun b : Fin P.q => f ⟨a * P.q + b.val, by
          calc a * P.q + b.val < a * P.q + P.q := by omega
            _ = (a + 1) * P.q := by ring
            _ ≤ s * P.q := Nat.mul_le_mul_right P.q ha⟩) : ℤ))
  have hPar_init : ParamsStored P m_init := paramsStored_wWrite_ne hPar₀ 4 3 0
  have hInv₀ : ∀ f₀ : Fin (0 * P.q) → Bool, Inv 0 f₀ m_init := by
    intro _
    exact ⟨hPar_init, poolStored_wWrite hPool₀ 4 3 0, by simp [m_init], fun _ ha => by omega⟩
  have hcnt : iVal inp m_init (wReg 1 13) = ((D + 3 : ℕ) : ℤ) := by
    change wRead m_init 1 13 = _; rw [hPar_init.hD3, hPD]
  let slotBody : UL.ArithRAMStmt :=
    .seq readQBitsStmt
      (.seq (wSetArr 2 (wReg 4 3) (wReg 4 4)) (wSet 4 3 (.add (wReg 4 3) (iLit 1))))
  have hloop := RandExec.repeatN_nat (wReg 1 13) slotBody (D + 3) P.q 5 (35 + P.q * 20)
    Inv hInv₀ hcnt (by dsimp [intExprOps, wReg]; omega)
    (fun s _ f_prev m ⟨hPar, hPool, h43, hslots⟩ => by
      have hread := exec_readQBits inp m hPar hPool
      refine (RandExec.seq_det_right
        (s₂ := .seq (wSetArr 2 (wReg 4 3) (wReg 4 4)) (wSet 4 3 (.add (wReg 4 3) (iLit 1))))
        (C₂ := 25) hread ?_).mono (fun _ _ h => h) (by omega)
      intro f_cur m_q ⟨hPar_q, hPool_q, h43_q, h2_q, h44_q⟩
      let m_w := wWrite m_q 2 (s : ℤ) (bitsFnToNat P.q f_cur : ℤ)
      have hs_w : DetExec inp (wSetArr 2 (wReg 4 3) (wReg 4 4)) m_q m_w 10 := by
        refine DetExec.writeWord inp m_q 2 (wReg 4 3) (wReg 4 4) ?_ h44_q
          (by dsimp [intExprOps, wReg]; omega)
        change wRead m_q 4 3 = _; rw [h43_q, h43]
      let m_next := wWrite m_w 4 3 ((s + 1 : ℕ) : ℤ)
      have hs_inc : DetExec inp (wSet 4 3 (.add (wReg 4 3) (iLit 1))) m_w m_next 15 := by
        refine DetExec.writeWord inp m_w 4 (.lit 3) _ rfl ?_
          (by dsimp [intExprOps, wReg, iLit]; omega)
        have h43_w : wRead m_w 4 3 = (s : ℤ) := by
          rw [wRead_wWrite_of_ne m_q _ (Or.inl (by decide)), h43_q, h43]
        simp -zeta [wReg, iLit, h43_w]
      refine ⟨m_next, hs_w.seq hs_inc, fun f_next hprev hcur => ?_⟩
      refine ⟨paramsStored_wWrite_ne (paramsStored_wWrite_ne hPar_q 2 _ _) 4 _ _,
        poolStored_wWrite (poolStored_wWrite hPool_q 2 _ _) 4 _ _,
        by simp [m_next], fun a ha => ?_⟩
      rw [wRead_wWrite_of_ne m_w _ (Or.inl (by decide))]
      by_cases has : a = s
      · subst has
        simp only [m_w, wRead_wWrite_self]
        congr 2
        funext b
        exact (hcur b).symm
      · have has_lt : a < s := by omega
        have hne_s : (a : ℤ) ≠ (s : ℤ) := by omega
        rw [wRead_wWrite_of_ne m_q _ (Or.inr hne_s), h2_q (a : ℤ), hslots a has_lt]
        congr 2
        funext b
        have hlt_prev : a * P.q + b.val < s * P.q := by
          calc a * P.q + b.val < a * P.q + P.q := by omega
            _ = (a + 1) * P.q := by ring
            _ ≤ s * P.q := Nat.mul_le_mul_right P.q has_lt
        exact (hprev ⟨a * P.q + b.val, hlt_prev⟩).symm)
  have hcost_ss : 5 + (5 + (D + 3) * (35 + P.q * 20)) ≤ 50 * (D + 3) * (P.q + 1) := by nlinarith
  refine (RandExec.seq_det_left hs_init hloop).mono ?_ hcost_ss
  intro f m₁ ⟨hPar, hPool, _, hslots⟩
  exact ⟨hPar, hPool, fun a => hslots a.val (by omega), hslots (D + 2) (by omega)⟩

/-! ### 6. Subphase 3.2 & Phase 3 verification: Gaussian Radon walk -/

private def GaussStored {D : ℕ} (st : GaussState D) (mem : UL.ArithRAMMemory) : Prop :=
  (∀ k : Fin (D + 2), wRead mem 3 (k.val : ℤ) = (if st.used k then 1 else 0)) ∧
  (∀ (k : Fin (D + 2)) (r : Fin (D + 1)),
    rRead mem 3 ((k.val * (D + 1) + r.val : ℕ) : ℤ) = st.v k r) ∧
  (∀ (k : Fin (D + 2)) (r : Fin (D + 2)),
    rRead mem 4 ((k.val * (D + 2) + r.val : ℕ) : ℤ) = st.c k r)

private theorem gaussStored_wWrite_ne {D : ℕ} {st : GaussState D} {mem : UL.ArithRAMMemory}
    (h : GaussStored st mem) (t : ℕ) (idx v : ℤ) (ht : t ≠ 3 := by decide) :
    GaussStored st (wWrite mem t idx v) := by
  refine ⟨fun k => ?_, h.2.1, h.2.2⟩
  rw [wRead_wWrite_of_ne mem v (Or.inl ht.symm)]
  exact h.1 k

private theorem gaussStored_rWrite_ne {D : ℕ} {st : GaussState D} {mem : UL.ArithRAMMemory}
    (h : GaussStored st mem) (t : ℕ) (idx : ℤ) (v : ℝ)
    (ht3 : t ≠ 3 := by decide) (ht4 : t ≠ 4 := by decide) :
    GaussStored st (rWrite mem t idx v) := by
  refine ⟨h.1, fun k r => ?_, fun k r => ?_⟩
  · rw [rRead_rWrite_of_ne mem v (Or.inl ht3.symm)]; exact h.2.1 k r
  · rw [rRead_rWrite_of_ne mem v (Or.inl ht4.symm)]; exact h.2.2 k r

private def RadPtStored {D : ℕ} (pt : EuclideanSpace ℝ (Fin D)) (mem : UL.ArithRAMMemory) : Prop :=
  ∀ c : Fin D, rRead mem 5 (c.val : ℤ) = UL.euclideanCoord pt c

private theorem cost_initGauss_col (D : ℕ) :
    10 + (10 + (5 + ((5 + D * 35) + (15 + (5 + ((5 + (D + 2) * 35) + 10)))))) ≤ 100 * (D + 3) := by
  omega

private theorem cost_initGauss_outer (D : ℕ) :
    5 + (5 + (D + 2) * (100 * (D + 3))) ≤ 120 * (D + 3) ^ 2 := by
  nlinarith

private theorem cost_elim_col_outer (D : ℕ) :
    10 + (10 + (5 + (5 + (D + 2) * (110 * (D + 3))))) ≤ 130 * (D + 3) ^ 2 := by
  nlinarith

private theorem cost_gauss_row (D : ℕ) :
    60 * (D + 3) + (130 * (D + 3) ^ 2 + 10) ≤ 195 * (D + 3) ^ 2 := by
  nlinarith

private theorem cost_gauss_outer (D : ℕ) :
    5 + (5 + (D + 1) * (195 * (D + 3) ^ 2)) ≤ 200 * (D + 3) ^ 3 := by
  nlinarith

private theorem cost_radpt_outer (D : ℕ) :
    40 * (D + 3) + ((15 + (D + 2) * 40) + (5 + (5 + D * (35 + (D + 2) * 60)))) ≤
      120 * (D + 3) ^ 2 := by
  nlinarith

private theorem cost_det_step (D : ℕ) :
    120 * (D + 3) ^ 2 + (200 * (D + 3) ^ 3 + (120 * (D + 3) ^ 2 + 40 * (D + 3))) ≤
      500 * (D + 3) ^ 3 := by
  nlinarith

private theorem exec_initGauss {d D m : ℕ} (inp : UL.ArithRAMInput d)
    {P : HPJParams} (hPD : P.D = D)
    {T : Fin m → EuclideanSpace ℝ (Fin D)}
    {choice : (Fin (D + 2) → Fin m) × Fin m}
    (mem₀ : UL.ArithRAMMemory)
    (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T mem₀)
    (hIdx₀ : IdxArrStored choice mem₀) :
    let pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D) := fun k => T (choice.1 k)
    ∃ mem₁,
      DetExec inp initGaussStmt mem₀ mem₁ (120 * (D + 3) ^ 2) ∧
      ParamsStored P mem₁ ∧
      PoolStored T mem₁ ∧
      IdxArrStored choice mem₁ ∧
      GaussStored (initGaussState pts) mem₁ := by
  intro pts
  let m_init := wWrite mem₀ 4 6 0
  have hs_init : DetExec inp (wSet 4 6 (iLit 0)) mem₀ m_init 5 :=
    DetExec.writeWord inp mem₀ 4 (.lit 6) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let st₀ := initGaussState pts
  let InvK : ℕ → UL.ArithRAMMemory → Prop := fun k mk =>
    ParamsStored P mk ∧ PoolStored T mk ∧ IdxArrStored choice mk ∧
    wRead mk 4 6 = (k : ℤ) ∧
    (∀ k' : Fin (D + 2), k'.val < k → wRead mk 3 (k'.val : ℤ) = 0) ∧
    (∀ (k' : Fin (D + 2)) (r : Fin (D + 1)), k'.val < k →
      rRead mk 3 ((k'.val * (D + 1) + r.val : ℕ) : ℤ) = st₀.v k' r) ∧
    (∀ (k' : Fin (D + 2)) (r : Fin (D + 2)), k'.val < k →
      rRead mk 4 ((k'.val * (D + 2) + r.val : ℕ) : ℤ) = st₀.c k' r)
  have hPar_init : ParamsStored P m_init := paramsStored_wWrite_ne hPar₀ 4 6 0
  have hInvK₀ : InvK 0 m_init :=
    ⟨hPar_init, poolStored_wWrite hPool₀ 4 6 0, idxArrStored_wWrite_ne hIdx₀ 4 6 0,
     by simp [m_init], fun _ h => by omega, fun _ _ h => by omega, fun _ _ h => by omega⟩
  have hcnt : iVal inp m_init (wReg 1 12) = ((D + 2 : ℕ) : ℤ) := by
    change wRead m_init 1 12 = _; rw [hPar_init.hD2, hPD]
  let copyVBody : UL.ArithRAMStmt :=
    .seq
      (rSetArr 3 (.add (.mul (wReg 4 6) (wReg 1 11)) (wReg 4 2))
        (rArr 2 (.add (.mul (wReg 4 12) (wReg 1 0)) (wReg 4 2))))
      (wSet 4 2 (.add (wReg 4 2) (iLit 1)))
  let initCBody : UL.ArithRAMStmt :=
    .seq
      (.ite (.intEq (wReg 4 6) (wReg 4 7))
        (rSetArr 4 (.add (.mul (wReg 4 6) (wReg 1 12)) (wReg 4 7)) (rLit 1))
        (rSetArr 4 (.add (.mul (wReg 4 6) (wReg 1 12)) (wReg 4 7)) (rLit 0)))
      (wSet 4 7 (.add (wReg 4 7) (iLit 1)))
  rcases DetExec.repeatN_nat (wReg 1 12) initGaussColBody (D + 2) 5 (100 * (D + 3))
    InvK hInvK₀ hcnt (by dsimp [intExprOps, wReg]; omega)
    (fun k hk_lt mk ⟨hPar, hPool, hIdx, hk_reg, hu_prev, hv_prev, hc_prev⟩ => by
      let kf : Fin (D + 2) := ⟨k, hk_lt⟩
      let m1 := wWrite mk 3 (k : ℤ) 0
      have hs1 : DetExec inp (wSetArr 3 (wReg 4 6) (iLit 0)) mk m1 10 :=
        DetExec.writeWord inp mk 3 (wReg 4 6) (iLit 0) hk_reg rfl
          (by dsimp [intExprOps, wReg, iLit]; omega)
      let p_val := (choice.1 kf).val
      let m2 := wWrite m1 4 12 (p_val : ℤ)
      have hs2 : DetExec inp (wSet 4 12 (wArr 2 (wReg 4 6))) m1 m2 10 := by
        refine DetExec.writeWord inp m1 4 (.lit 12) (wArr 2 (wReg 4 6)) rfl ?_
          (by dsimp [intExprOps, wArr, wReg]; omega)
        have h46 : wRead m1 4 6 = (k : ℤ) := by
          rw [wRead_wWrite_of_ne mk _ (Or.inl (by decide)), hk_reg]
        have h2k : wRead m1 2 (k : ℤ) = (p_val : ℤ) := by
          rw [wRead_wWrite_of_ne mk _ (Or.inl (by decide))]; exact hIdx.1 kf
        simp -zeta [wArr, wReg, h46, h2k]
      let m3 := wWrite m2 4 2 0
      have hs3 : DetExec inp (wSet 4 2 (iLit 0)) m2 m3 5 :=
        DetExec.writeWord inp m2 4 (.lit 2) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
      let InvC : ℕ → UL.ArithRAMMemory → Prop := fun c mc =>
        ParamsStored P mc ∧ PoolStored T mc ∧ IdxArrStored choice mc ∧
        wRead mc 4 6 = (k : ℤ) ∧ wRead mc 4 12 = (p_val : ℤ) ∧ wRead mc 4 2 = (c : ℤ) ∧
        (∀ k' : Fin (D + 2), k'.val ≤ k → wRead mc 3 (k'.val : ℤ) = 0) ∧
        (∃ hc_le : c ≤ D, ∀ r : ℕ, (hr : r < c) →
          rRead mc 3 ((k * (D + 1) + r : ℕ) : ℤ) =
            UL.euclideanCoord (pts kf) ⟨r, lt_of_lt_of_le hr hc_le⟩) ∧
        (∀ (k' : Fin (D + 2)) (r : Fin (D + 1)), k'.val < k →
          rRead mc 3 ((k'.val * (D + 1) + r.val : ℕ) : ℤ) = st₀.v k' r) ∧
        (∀ (k' : Fin (D + 2)) (r : Fin (D + 2)), k'.val < k →
          rRead mc 4 ((k'.val * (D + 2) + r.val : ℕ) : ℤ) = st₀.c k' r)
      have hPar3 : ParamsStored P m3 :=
        paramsStored_wWrite_ne (paramsStored_wWrite_ne (paramsStored_wWrite_ne hPar 3 _ _) 4 _ _) 4 _ _
      have hInvC₀ : InvC 0 m3 := by
        refine ⟨hPar3,
          poolStored_wWrite (poolStored_wWrite (poolStored_wWrite hPool 3 _ _) 4 _ _) 4 _ _,
          idxArrStored_wWrite_ne (idxArrStored_wWrite_ne (idxArrStored_wWrite_ne hIdx 3 _ _) 4 _ _) 4 _ _,
          ?_, ?_, by simp [m3], ?_, ⟨Nat.zero_le D, fun _ hr => by omega⟩, hv_prev, hc_prev⟩
        · rw [wRead_wWrite_of_ne m2 _ (Or.inr (by decide)),
            wRead_wWrite_of_ne m1 _ (Or.inr (by decide)),
            wRead_wWrite_of_ne mk _ (Or.inl (by decide)), hk_reg]
        · rw [wRead_wWrite_of_ne m2 _ (Or.inr (by decide))]; simp [m2]
        · intro k' hk'
          rw [wRead_wWrite_of_ne m2 _ (Or.inl (by decide)),
            wRead_wWrite_of_ne m1 _ (Or.inl (by decide))]
          by_cases hkk : k'.val = k
          · simp [m1, hkk]
          · rw [wRead_wWrite_of_ne mk _ (Or.inr (by omega))]
            exact hu_prev k' (by omega)
      have hcntD : iVal inp m3 (wReg 1 0) = (D : ℤ) := by
        change wRead m3 1 0 = _; rw [hPar3.hD, hPD]
      rcases DetExec.repeatN_nat (wReg 1 0) copyVBody D 5 35 InvC hInvC₀ hcntD
        (by dsimp [intExprOps, wReg]; omega)
        (fun c hc_lt mc ⟨hParC, hPoolC, hIdxC, hkC, hpC, hcC, huC, ⟨_, hcurC⟩, hvC, hc_prevC⟩ => by
          let val_c := UL.euclideanCoord (pts kf) ⟨c, hc_lt⟩
          let mc1 := rWrite mc 3 ((k * (D + 1) + c : ℕ) : ℤ) val_c
          have hsc1 : DetExec inp
              (rSetArr 3 (.add (.mul (wReg 4 6) (wReg 1 11)) (wReg 4 2))
                (rArr 2 (.add (.mul (wReg 4 12) (wReg 1 0)) (wReg 4 2)))) mc mc1 25 := by
            refine DetExec.writeReal inp mc 3 _ _ ?_ ?_
              (by dsimp [intExprOps, realExprOps, wReg, rArr]; omega)
            · have h11 : wRead mc 1 11 = ((D + 1 : ℕ) : ℤ) := by rw [hParC.hD1, hPD]
              simp -zeta [wReg, hkC, h11, hcC]
            · have h0 : wRead mc 1 0 = (D : ℤ) := by rw [hParC.hD, hPD]
              simp only [rArr, rVal_readRealHeap, iVal_add, iVal_mul, wReg, iVal_readHeap,
                iVal_lit, hpC, h0, hcC]
              have hidx : (p_val : ℤ) * (D : ℤ) + (c : ℤ) = ((p_val * D + c : ℕ) : ℤ) := by
                push_cast; ring
              rw [hidx]; exact hPoolC (choice.1 kf) ⟨c, hc_lt⟩
          let mc2 := wWrite mc1 4 2 ((c + 1 : ℕ) : ℤ)
          have hsc2 : DetExec inp (wSet 4 2 (.add (wReg 4 2) (iLit 1))) mc1 mc2 10 := by
            refine DetExec.writeWord inp mc1 4 (.lit 2) _ rfl ?_
              (by dsimp [intExprOps, wReg, iLit]; omega)
            simp -zeta [wReg, iLit, mc1, hcC]
          refine ⟨mc2, hsc1.seq hsc2,
            paramsStored_wWrite_ne hParC 4 _ _,
            poolStored_wWrite (poolStored_rWrite_ne hPoolC 3 _ _) 4 _ _,
            idxArrStored_wWrite_ne hIdxC 4 _ _,
            by rw [wRead_wWrite_of_ne mc1 _ (Or.inr (by decide))]; exact hkC,
            by rw [wRead_wWrite_of_ne mc1 _ (Or.inr (by decide))]; exact hpC,
            by simp [mc2],
            fun k' hk' => by rw [wRead_wWrite_of_ne mc1 _ (Or.inl (by decide))]; exact huC k' hk',
            ⟨by omega, fun r hr => ?_⟩, fun k' r hk' => ?_,
            fun k' r hk' => by
              simp only [mc2, rRead_wWrite]
              rw [rRead_rWrite_of_ne mc _ (Or.inl (by decide))]
              exact hc_prevC k' r hk'⟩
          · simp only [mc2, rRead_wWrite]
            by_cases hrc : r = c
            · subst hrc; simp [mc1, val_c]
            · have hne : ((k * (D + 1) + r : ℕ) : ℤ) ≠ ((k * (D + 1) + c : ℕ) : ℤ) :=
                fun heq => hrc (flat2d_inj (by omega) (by omega) heq).2
              rw [rRead_rWrite_of_ne mc _ (Or.inr hne)]
              exact hcurC r (by omega)
          · simp only [mc2, rRead_wWrite]
            have hne : ((k'.val * (D + 1) + r.val : ℕ) : ℤ) ≠ ((k * (D + 1) + c : ℕ) : ℤ) := by
              intro heq
              have := (flat2d_inj r.isLt (by omega) heq).1
              omega
            rw [rRead_rWrite_of_ne mc _ (Or.inr hne)]
            exact hvC k' r hk')
        with ⟨m4, ⟨hPar4, hPool4, hIdx4, hk4, _, _, hu4, ⟨_, hcur4⟩, hv4, hc4⟩, hs4⟩
      let m5 := rWrite m4 3 ((k * (D + 1) + D : ℕ) : ℤ) 1
      have hs5 : DetExec inp (rSetArr 3 (.add (.mul (wReg 4 6) (wReg 1 11)) (wReg 1 0)) (rLit 1))
          m4 m5 15 := by
        refine DetExec.writeReal inp m4 3 _ (rLit 1) ?_ (by simp [rLit])
          (by dsimp [intExprOps, realExprOps, wReg, rLit]; omega)
        have h11 : wRead m4 1 11 = ((D + 1 : ℕ) : ℤ) := by rw [hPar4.hD1, hPD]
        have h0 : wRead m4 1 0 = (D : ℤ) := by rw [hPar4.hD, hPD]
        simp -zeta [wReg, hk4, h11, h0]
      have hv5 : ∀ (k' : Fin (D + 2)) (r : Fin (D + 1)), k'.val ≤ k →
          rRead m5 3 ((k'.val * (D + 1) + r.val : ℕ) : ℤ) = st₀.v k' r := by
        intro k' r hk'
        by_cases hkk : k'.val = k
        · have hk'eq : k' = kf := Fin.ext hkk
          subst hk'eq
          have hkf_val : kf.val = k := rfl
          dsimp only [st₀, initGaussState]
          split_ifs with hrD
          · have hne : ((kf.val * (D + 1) + r.val : ℕ) : ℤ) ≠ ((k * (D + 1) + D : ℕ) : ℤ) := by
              rw [hkf_val]
              intro heq; have := (flat2d_inj r.isLt (by omega) heq).2; omega
            rw [rRead_rWrite_of_ne m4 _ (Or.inr hne), hkf_val]
            exact hcur4 r.val hrD
          · have hr_eq : r.val = D := by omega
            rw [hkf_val, hr_eq]; simp [m5]
        · have hne : ((k'.val * (D + 1) + r.val : ℕ) : ℤ) ≠ ((k * (D + 1) + D : ℕ) : ℤ) := by
            intro heq; exact hkk (flat2d_inj r.isLt (by omega) heq).1
          rw [rRead_rWrite_of_ne m4 _ (Or.inr hne)]
          exact hv4 k' r (by omega)
      let m6 := wWrite m5 4 7 0
      have hs6 : DetExec inp (wSet 4 7 (iLit 0)) m5 m6 5 :=
        DetExec.writeWord inp m5 4 (.lit 7) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
      let InvJ : ℕ → UL.ArithRAMMemory → Prop := fun j mj =>
        ParamsStored P mj ∧ PoolStored T mj ∧ IdxArrStored choice mj ∧
        wRead mj 4 6 = (k : ℤ) ∧ wRead mj 4 7 = (j : ℤ) ∧
        (∀ k' : Fin (D + 2), k'.val ≤ k → wRead mj 3 (k'.val : ℤ) = 0) ∧
        (∀ (k' : Fin (D + 2)) (r : Fin (D + 1)), k'.val ≤ k →
          rRead mj 3 ((k'.val * (D + 1) + r.val : ℕ) : ℤ) = st₀.v k' r) ∧
        (∃ hj_le : j ≤ D + 2, ∀ j' : ℕ, (hj' : j' < j) →
          rRead mj 4 ((k * (D + 2) + j' : ℕ) : ℤ) =
            st₀.c kf ⟨j', lt_of_lt_of_le hj' hj_le⟩) ∧
        (∀ (k' : Fin (D + 2)) (r : Fin (D + 2)), k'.val < k →
          rRead mj 4 ((k'.val * (D + 2) + r.val : ℕ) : ℤ) = st₀.c k' r)
      have hPar6 : ParamsStored P m6 := paramsStored_wWrite_ne hPar4 4 _ _
      have hInvJ₀ : InvJ 0 m6 := by
        refine ⟨hPar6,
          poolStored_wWrite (poolStored_rWrite_ne hPool4 3 _ _) 4 _ _,
          idxArrStored_wWrite_ne hIdx4 4 _ _,
          by rw [wRead_wWrite_of_ne m5 _ (Or.inr (by decide))]; exact hk4,
          by simp [m6],
          fun k' hk' => by rw [wRead_wWrite_of_ne m5 _ (Or.inl (by decide))]; exact hu4 k' hk',
          hv5, ⟨Nat.zero_le _, fun _ hj' => by omega⟩,
          fun k' r hk' => by
            simp only [m6, rRead_wWrite, m5]
            rw [rRead_rWrite_of_ne m4 _ (Or.inl (by decide))]
            exact hc4 k' r hk'⟩
      have hcntD2 : iVal inp m6 (wReg 1 12) = ((D + 2 : ℕ) : ℤ) := by
        change wRead m6 1 12 = _; rw [hPar6.hD2, hPD]
      rcases DetExec.repeatN_nat (wReg 1 12) initCBody (D + 2) 5 35 InvJ hInvJ₀ hcntD2
        (by dsimp [intExprOps, wReg]; omega)
        (fun j hj_lt mj ⟨hParJ, hPoolJ, hIdxJ, hkJ, hjJ, huJ, hvJ, ⟨_, hcurJ⟩, hcJ⟩ => by
          let val_j : ℝ := if k = j then 1 else 0
          let mj1 := rWrite mj 4 ((k * (D + 2) + j : ℕ) : ℤ) val_j
          have hsj1 : DetExec inp
              (.ite (.intEq (wReg 4 6) (wReg 4 7))
                (rSetArr 4 (.add (.mul (wReg 4 6) (wReg 1 12)) (wReg 4 7)) (rLit 1))
                (rSetArr 4 (.add (.mul (wReg 4 6) (wReg 1 12)) (wReg 4 7)) (rLit 0))) mj mj1 25 := by
            have h12 : wRead mj 1 12 = ((D + 2 : ℕ) : ℤ) := by rw [hParJ.hD2, hPD]
            have hidx_j : iVal inp mj (.add (.mul (wReg 4 6) (wReg 1 12)) (wReg 4 7)) =
                ((k * (D + 2) + j : ℕ) : ℤ) := by
              simp -zeta [wReg, hkJ, h12, hjJ]
            by_cases hkj : k = j
            · have hcond : cVal inp mj (.intEq (wReg 4 6) (wReg 4 7)) = true := by
                simp -zeta [wReg, hkJ, hjJ, hkj]
              have hbr : DetExec inp
                  (rSetArr 4 (.add (.mul (wReg 4 6) (wReg 1 12)) (wReg 4 7)) (rLit 1)) mj mj1 15 := by
                simpa -zeta [mj1, val_j, hkj] using DetExec.writeReal inp mj 4 _ (rLit 1)
                  hidx_j (by simp [rLit]) (by dsimp [intExprOps, realExprOps, wReg, rLit]; omega)
              exact DetExec.ite_true (C_c := 10) hcond
                (by dsimp [condExprOps, intExprOps, wReg]; omega) hbr
            · have hcond : cVal inp mj (.intEq (wReg 4 6) (wReg 4 7)) = false := by
                simp -zeta only [cVal_intEq, wReg, iVal_readHeap, iVal_lit, hkJ, hjJ,
                  decide_eq_false_iff_not]; omega
              have hbr : DetExec inp
                  (rSetArr 4 (.add (.mul (wReg 4 6) (wReg 1 12)) (wReg 4 7)) (rLit 0)) mj mj1 15 := by
                simpa -zeta [mj1, val_j, hkj] using DetExec.writeReal inp mj 4 _ (rLit 0)
                  hidx_j (by simp [rLit]) (by dsimp [intExprOps, realExprOps, wReg, rLit]; omega)
              exact DetExec.ite_false (C_c := 10) hcond
                (by dsimp [condExprOps, intExprOps, wReg]; omega) hbr
          let mj2 := wWrite mj1 4 7 ((j + 1 : ℕ) : ℤ)
          have hsj2 : DetExec inp (wSet 4 7 (.add (wReg 4 7) (iLit 1))) mj1 mj2 10 :=
            DetExec.writeWord inp mj1 4 (.lit 7) _ rfl (by simp -zeta [wReg, iLit, mj1, hjJ])
              (by dsimp [intExprOps, wReg, iLit]; omega)
          refine ⟨mj2, hsj1.seq hsj2,
            paramsStored_wWrite_ne hParJ 4 _ _,
            poolStored_wWrite (poolStored_rWrite_ne hPoolJ 4 _ _) 4 _ _,
            idxArrStored_wWrite_ne hIdxJ 4 _ _,
            by rw [wRead_wWrite_of_ne mj1 _ (Or.inr (by decide))]; exact hkJ,
            by simp [mj2],
            fun k' hk' => by rw [wRead_wWrite_of_ne mj1 _ (Or.inl (by decide))]; exact huJ k' hk',
            fun k' r hk' => by
              simp only [mj2, rRead_wWrite, mj1]
              rw [rRead_rWrite_of_ne mj _ (Or.inl (by decide))]
              exact hvJ k' r hk',
            ⟨by omega, fun j' hj' => ?_⟩, fun k' r hk' => ?_⟩
          · simp only [mj2, rRead_wWrite]
            by_cases hjj : j' = j
            · subst hjj
              simp only [mj1, rRead_rWrite_self, val_j, st₀, initGaussState, Fin.ext_iff, kf]
            · have hne : ((k * (D + 2) + j' : ℕ) : ℤ) ≠ ((k * (D + 2) + j : ℕ) : ℤ) :=
                fun heq => hjj (flat2d_inj (by omega) (by omega) heq).2
              rw [rRead_rWrite_of_ne mj _ (Or.inr hne)]
              exact hcurJ j' (by omega)
          · simp only [mj2, rRead_wWrite]
            have hne : ((k'.val * (D + 2) + r.val : ℕ) : ℤ) ≠ ((k * (D + 2) + j : ℕ) : ℤ) := by
              intro heq; have := (flat2d_inj r.isLt (by omega) heq).1; omega
            rw [rRead_rWrite_of_ne mj _ (Or.inr hne)]
            exact hcJ k' r hk')
        with ⟨m7, ⟨hPar7, hPool7, hIdx7, hk7, _, hu7, hv7, ⟨_, hcur7⟩, hc7⟩, hs7⟩
      let m8 := wWrite m7 4 6 ((k + 1 : ℕ) : ℤ)
      have hs8 : DetExec inp (wSet 4 6 (.add (wReg 4 6) (iLit 1))) m7 m8 10 :=
        DetExec.writeWord inp m7 4 (.lit 6) _ rfl (by simp -zeta [wReg, iLit, hk7])
          (by dsimp [intExprOps, wReg, iLit]; omega)
      refine ⟨m8, ?_, paramsStored_wWrite_ne hPar7 4 _ _,
        poolStored_wWrite hPool7 4 _ _, idxArrStored_wWrite_ne hIdx7 4 _ _,
        by simp [m8],
        fun k' hk' => by
          rw [wRead_wWrite_of_ne m7 _ (Or.inl (by decide))]; exact hu7 k' (by omega),
        fun k' r hk' => hv7 k' r (by omega),
        fun k' r hk' => ?_⟩
      · unfold initGaussColBody seqList
        exact (hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq (hs6.seq (hs7.seq hs8))))))).mono_cost
          (cost_initGauss_col D)
      · simp only [m8, rRead_wWrite]
        by_cases hkk : k'.val = k
        · have hk'eq : k' = kf := Fin.ext hkk
          subst hk'eq
          simpa using hcur7 r.val r.isLt
        · exact hc7 k' r (by omega))
    with ⟨mem₁, ⟨hPar₁, hPool₁, hIdx₁, _, hu₁, hv₁, hc₁⟩, hloop⟩
  refine ⟨mem₁, (hs_init.seq hloop).mono_cost (cost_initGauss_outer D), hPar₁, hPool₁, hIdx₁, ?_⟩
  refine ⟨fun k => ?_, fun k r => hv₁ k r k.isLt, fun k r => hc₁ k r k.isLt⟩
  simpa [st₀, initGaussState] using hu₁ k k.isLt

private theorem findFirstFin_eq_none_of_forall_not {n : ℕ} {Q : Fin n → Prop}
    (h : ∀ k : Fin n, ¬ Q k) : findFirstFin Q = none := by
  classical
  unfold findFirstFin
  dsimp only
  split_ifs with hne
  · rcases hne with ⟨x, hx⟩
    exact absurd (Finset.mem_filter.mp hx).2 (h x)
  · rfl

private theorem findFirstFin_eq_some_of_first {n : ℕ} {Q : Fin n → Prop} (p : Fin n)
    (hp : Q p) (hmin : ∀ k : Fin n, k.val < p.val → ¬ Q k) :
    findFirstFin Q = some p := by
  classical
  unfold findFirstFin
  dsimp only
  have hp_mem : p ∈ Finset.univ.filter Q := Finset.mem_filter.mpr ⟨Finset.mem_univ p, hp⟩
  have hne : (Finset.univ.filter Q).Nonempty := ⟨p, hp_mem⟩
  rw [dif_pos hne]
  congr 1
  let m := (Finset.univ.filter Q).min' hne
  have hm_le : m ≤ p := Finset.min'_le _ p hp_mem
  have hm_Q : Q m := (Finset.mem_filter.mp (Finset.min'_mem _ hne)).2
  by_contra hne_mp
  have hlt : m.val < p.val := lt_of_le_of_ne hm_le (fun heq => hne_mp (Fin.ext heq))
  exact hmin m hlt hm_Q

private theorem exec_findPivot {d D m : ℕ} (inp : UL.ArithRAMInput d)
    {P : HPJParams} (hPD : P.D = D)
    {T : Fin m → EuclideanSpace ℝ (Fin D)}
    {choice : (Fin (D + 2) → Fin m) × Fin m}
    {st : GaussState D} (ri : Fin (D + 1))
    (mem₀ : UL.ArithRAMMemory)
    (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T mem₀)
    (hIdx₀ : IdxArrStored choice mem₀) (hGauss₀ : GaussStored st mem₀)
    (hrow_reg : wRead mem₀ 4 8 = (ri.val : ℤ)) :
    ∃ mem₁,
      DetExec inp findPivotStmt mem₀ mem₁ (60 * (D + 3)) ∧
      ParamsStored P mem₁ ∧ PoolStored T mem₁ ∧ IdxArrStored choice mem₁ ∧ GaussStored st mem₁ ∧
      wRead mem₁ 4 8 = (ri.val : ℤ) ∧
      match findFirstFin (fun k : Fin (D + 2) => st.used k = false ∧ st.v k ri ≠ 0) with
      | none => wRead mem₁ 4 9 = 0
      | some p => wRead mem₁ 4 9 = 1 ∧ wRead mem₁ 4 10 = (p.val : ℤ) := by
  let Q : Fin (D + 2) → Prop := fun k => st.used k = false ∧ st.v k ri ≠ 0
  let m1 := wWrite mem₀ 4 9 0
  have hs1 : DetExec inp (wSet 4 9 (iLit 0)) mem₀ m1 5 :=
    DetExec.writeWord inp mem₀ 4 (.lit 9) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let m2 := wWrite m1 4 10 0
  have hs2 : DetExec inp (wSet 4 10 (iLit 0)) m1 m2 5 :=
    DetExec.writeWord inp m1 4 (.lit 10) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let m3 := wWrite m2 4 6 0
  have hs3 : DetExec inp (wSet 4 6 (iLit 0)) m2 m3 5 :=
    DetExec.writeWord inp m2 4 (.lit 6) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let Inv : ℕ → UL.ArithRAMMemory → Prop := fun t mt =>
    ParamsStored P mt ∧ PoolStored T mt ∧ IdxArrStored choice mt ∧ GaussStored st mt ∧
    wRead mt 4 8 = (ri.val : ℤ) ∧ wRead mt 4 6 = (t : ℤ) ∧
    ((wRead mt 4 9 = 0 ∧ ∀ k : Fin (D + 2), k.val < t → ¬ Q k) ∨
     (∃ p : Fin (D + 2), p.val < t ∧ wRead mt 4 9 = 1 ∧ wRead mt 4 10 = (p.val : ℤ) ∧
       Q p ∧ ∀ k : Fin (D + 2), k.val < p.val → ¬ Q k))
  have hPar3 : ParamsStored P m3 :=
    paramsStored_wWrite_ne (paramsStored_wWrite_ne (paramsStored_wWrite_ne hPar₀ 4 _ _) 4 _ _) 4 _ _
  have hInv₀ : Inv 0 m3 := by
    refine ⟨hPar3,
      poolStored_wWrite (poolStored_wWrite (poolStored_wWrite hPool₀ 4 _ _) 4 _ _) 4 _ _,
      idxArrStored_wWrite_ne (idxArrStored_wWrite_ne (idxArrStored_wWrite_ne hIdx₀ 4 _ _) 4 _ _) 4 _ _,
      gaussStored_wWrite_ne (gaussStored_wWrite_ne (gaussStored_wWrite_ne hGauss₀ 4 _ _) 4 _ _) 4 _ _,
      ?_, by simp [m3], Or.inl ⟨?_, fun _ hk => by omega⟩⟩
    · rw [wRead_wWrite_of_ne m2 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m1 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne mem₀ _ (Or.inr (by decide)), hrow_reg]
    · rw [wRead_wWrite_of_ne m2 _ (Or.inr (by decide)),
        wRead_wWrite_of_ne m1 _ (Or.inr (by decide))]; simp [m1]
  have hcnt : iVal inp m3 (wReg 1 12) = ((D + 2 : ℕ) : ℤ) := by
    change wRead m3 1 12 = _; rw [hPar3.hD2, hPD]
  let condP : UL.ArithCondExpr :=
    .and (.and (.intEq (wReg 4 9) (iLit 0)) (.intEq (wArr 3 (wReg 4 6)) (iLit 0)))
      (.not (.realEq (rArr 3 (.add (.mul (wReg 4 6) (wReg 1 11)) (wReg 4 8))) (rLit 0)))
  let pivBody : UL.ArithRAMStmt :=
    .seq (.ite condP (.seq (wSet 4 9 (iLit 1)) (wSet 4 10 (wReg 4 6))) .skip)
      (wSet 4 6 (.add (wReg 4 6) (iLit 1)))
  have hcc_piv : condExprOps condP ≤ 30 := by
    dsimp [condP, condExprOps, realExprOps, intExprOps, wReg, wArr, rArr, iLit, rLit]; omega
  rcases DetExec.repeatN_nat (wReg 1 12) pivBody (D + 2) 5 55 Inv hInv₀ hcnt
    (by dsimp [intExprOps, wReg]; omega)
    (fun t ht_lt mt ⟨hPar, hPool, hIdx, hGauss, h48, h46, hscan⟩ => by
      let kt : Fin (D + 2) := ⟨t, ht_lt⟩
      have hkt_val : kt.val = t := rfl
      have h11 : wRead mt 1 11 = ((D + 1 : ℕ) : ℤ) := by rw [hPar.hD1, hPD]
      have hu_kt : wRead mt 3 (t : ℤ) = (if st.used kt then 1 else 0) := hGauss.1 kt
      have hv_kt : rRead mt 3 ((t * (D + 1) + ri.val : ℕ) : ℤ) = st.v kt ri := hGauss.2.1 kt ri
      rcases hscan with ⟨h49_0, hnone_prev⟩ | ⟨p, hp_lt, h49_1, h410_p, hpQ, hmin_p⟩
      · by_cases hQkt : Q kt
        · have hcond : cVal inp mt condP = true := by
            rcases hQkt with ⟨hused_f, hv_ne⟩
            simp -zeta only [condP, cVal_and, cVal_intEq, cVal_not, cVal_realEq, wReg, wArr, rArr,
              iLit, rLit, iVal_readHeap, iVal_lit, iVal_add, iVal_mul, rVal_readRealHeap,
              rVal_ofInt, h49_0, h46, hu_kt, hused_f, h11, h48]
            have hidx_eq : (t : ℤ) * ((D + 1 : ℕ) : ℤ) + (ri.val : ℤ) =
                ((t * (D + 1) + ri.val : ℕ) : ℤ) := by push_cast; ring
            rw [hidx_eq, hv_kt]
            simp [hv_ne]
          let ma := wWrite mt 4 9 1
          have hsa : DetExec inp (wSet 4 9 (iLit 1)) mt ma 5 :=
            DetExec.writeWord inp mt 4 (.lit 9) (iLit 1) rfl rfl (by dsimp [intExprOps, iLit]; omega)
          let mb := wWrite ma 4 10 (t : ℤ)
          have hsb : DetExec inp (wSet 4 10 (wReg 4 6)) ma mb 10 := by
            refine DetExec.writeWord inp ma 4 (.lit 10) (wReg 4 6) rfl ?_
              (by dsimp [intExprOps, wReg]; omega)
            change wRead ma 4 6 = _
            rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h46]
          have hite := DetExec.ite_true (fB := .skip) (C_c := 30) hcond hcc_piv (hsa.seq hsb)
          let mc := wWrite mb 4 6 ((t + 1 : ℕ) : ℤ)
          have hsc : DetExec inp (wSet 4 6 (.add (wReg 4 6) (iLit 1))) mb mc 10 := by
            refine DetExec.writeWord inp mb 4 (.lit 6) _ rfl ?_
              (by dsimp [intExprOps, wReg, iLit]; omega)
            have h46' : wRead mb 4 6 = (t : ℤ) := by
              rw [wRead_wWrite_of_ne ma _ (Or.inr (by decide)),
                wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h46]
            simp -zeta [wReg, iLit, h46']
          refine ⟨mc, (hite.seq hsc).mono_cost (by omega),
            paramsStored_wWrite_ne (paramsStored_wWrite_ne (paramsStored_wWrite_ne hPar 4 _ _) 4 _ _) 4 _ _,
            poolStored_wWrite (poolStored_wWrite (poolStored_wWrite hPool 4 _ _) 4 _ _) 4 _ _,
            idxArrStored_wWrite_ne (idxArrStored_wWrite_ne (idxArrStored_wWrite_ne hIdx 4 _ _) 4 _ _) 4 _ _,
            gaussStored_wWrite_ne (gaussStored_wWrite_ne (gaussStored_wWrite_ne hGauss 4 _ _) 4 _ _) 4 _ _,
            by rw [wRead_wWrite_of_ne mb _ (Or.inr (by decide)),
                wRead_wWrite_of_ne ma _ (Or.inr (by decide)),
                wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h48],
            by simp [mc],
            Or.inr ⟨kt, by rw [hkt_val]; omega,
              by rw [wRead_wWrite_of_ne mb _ (Or.inr (by decide)),
                  wRead_wWrite_of_ne ma _ (Or.inr (by decide))]; simp [ma],
              by rw [wRead_wWrite_of_ne mb _ (Or.inr (by decide))]; simp [mb, kt],
              hQkt, hnone_prev⟩⟩
        · have hcond : cVal inp mt condP = false := by
            simp -zeta only [condP, cVal_and, cVal_intEq, cVal_not, cVal_realEq, wReg, wArr, rArr,
              iLit, rLit, iVal_readHeap, iVal_lit, iVal_add, iVal_mul, rVal_readRealHeap,
              rVal_ofInt, h49_0, h46, hu_kt, h11, h48]
            have hidx_eq : (t : ℤ) * ((D + 1 : ℕ) : ℤ) + (ri.val : ℤ) =
                ((t * (D + 1) + ri.val : ℕ) : ℤ) := by push_cast; ring
            rw [hidx_eq, hv_kt]
            cases hused : st.used kt
            · have hv0 : st.v kt ri = 0 := by
                by_contra hne; exact hQkt ⟨hused, hne⟩
              simp [hv0]
            · simp
          have hite := DetExec.ite_false (tB := .seq (wSet 4 9 (iLit 1)) (wSet 4 10 (wReg 4 6)))
            (C_c := 30) hcond hcc_piv (DetExec.skip inp mt)
          let mc := wWrite mt 4 6 ((t + 1 : ℕ) : ℤ)
          have hsc : DetExec inp (wSet 4 6 (.add (wReg 4 6) (iLit 1))) mt mc 10 :=
            DetExec.writeWord inp mt 4 (.lit 6) _ rfl (by simp -zeta [wReg, iLit, h46])
              (by dsimp [intExprOps, wReg, iLit]; omega)
          refine ⟨mc, (hite.seq hsc).mono_cost (by omega),
            paramsStored_wWrite_ne hPar 4 _ _,
            poolStored_wWrite hPool 4 _ _,
            idxArrStored_wWrite_ne hIdx 4 _ _,
            gaussStored_wWrite_ne hGauss 4 _ _,
            by rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h48],
            by simp [mc],
            Or.inl ⟨by rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h49_0],
              fun k hk => by
                by_cases hkt : k.val = t
                · have hkeq : k = kt := Fin.ext hkt; subst hkeq; exact hQkt
                · exact hnone_prev k (by omega)⟩⟩
      · have hcond : cVal inp mt condP = false := by
          simp -zeta [condP, wReg, iLit, h49_1]
        have hite := DetExec.ite_false (tB := .seq (wSet 4 9 (iLit 1)) (wSet 4 10 (wReg 4 6)))
          (C_c := 30) hcond hcc_piv (DetExec.skip inp mt)
        let mc := wWrite mt 4 6 ((t + 1 : ℕ) : ℤ)
        have hsc : DetExec inp (wSet 4 6 (.add (wReg 4 6) (iLit 1))) mt mc 10 :=
          DetExec.writeWord inp mt 4 (.lit 6) _ rfl (by simp -zeta [wReg, iLit, h46])
            (by dsimp [intExprOps, wReg, iLit]; omega)
        refine ⟨mc, (hite.seq hsc).mono_cost (by omega),
          paramsStored_wWrite_ne hPar 4 _ _,
          poolStored_wWrite hPool 4 _ _,
          idxArrStored_wWrite_ne hIdx 4 _ _,
          gaussStored_wWrite_ne hGauss 4 _ _,
          by rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h48],
          by simp [mc],
          Or.inr ⟨p, by have := hp_lt; omega,
            by rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h49_1],
            by rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h410_p],
            hpQ, hmin_p⟩⟩)
    with ⟨mem₁, ⟨hPar₁, hPool₁, hIdx₁, hGauss₁, h48₁, _, hscan₁⟩, hloop⟩
  refine ⟨mem₁, ?_, hPar₁, hPool₁, hIdx₁, hGauss₁, h48₁, ?_⟩
  · unfold findPivotStmt seqList
    exact (hs1.seq (hs2.seq (hs3.seq hloop))).mono_cost (by omega)
  · rcases hscan₁ with ⟨h49_0, hnone⟩ | ⟨p, _, h49_1, h410_p, hpQ, hmin_p⟩
    · rw [findFirstFin_eq_none_of_forall_not (fun k => hnone k k.isLt)]
      exact h49_0
    · rw [findFirstFin_eq_some_of_first p hpQ hmin_p]
      exact ⟨h49_1, h410_p⟩

private theorem exec_gaussRows {d D m : ℕ} (inp : UL.ArithRAMInput d)
    {P : HPJParams} (hPD : P.D = D)
    {T : Fin m → EuclideanSpace ℝ (Fin D)}
    {choice : (Fin (D + 2) → Fin m) × Fin m}
    (mem₀ : UL.ArithRAMMemory)
    (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T mem₀)
    (hIdx₀ : IdxArrStored choice mem₀)
    (hGauss₀ : GaussStored (initGaussState (fun k => T (choice.1 k))) mem₀) :
    let pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D) := fun k => T (choice.1 k)
    ∃ mem₁,
      DetExec inp gaussRowsStmt mem₀ mem₁ (200 * (D + 3) ^ 3) ∧
      ParamsStored P mem₁ ∧
      PoolStored T mem₁ ∧
      IdxArrStored choice mem₁ ∧
      GaussStored (gaussFinalState pts) mem₁ := by
  intro pts
  let m_init := wWrite mem₀ 4 8 0
  have hs_init : DetExec inp (wSet 4 8 (iLit 0)) mem₀ m_init 5 :=
    DetExec.writeWord inp mem₀ 4 (.lit 8) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let InvRow : ℕ → UL.ArithRAMMemory → Prop := fun i mi =>
    ParamsStored P mi ∧ PoolStored T mi ∧ IdxArrStored choice mi ∧
    wRead mi 4 8 = (i : ℤ) ∧
    (∃ hi : i ≤ D + 1, GaussStored (gaussRunRows pts i hi) mi)
  have hPar_init : ParamsStored P m_init := paramsStored_wWrite_ne hPar₀ 4 8 0
  have hInvR₀ : InvRow 0 m_init :=
    ⟨hPar_init, poolStored_wWrite hPool₀ 4 8 0, idxArrStored_wWrite_ne hIdx₀ 4 8 0,
     by simp [m_init], ⟨Nat.zero_le _, gaussStored_wWrite_ne hGauss₀ 4 8 0⟩⟩
  have hcnt : iVal inp m_init (wReg 1 11) = ((D + 1 : ℕ) : ℤ) := by
    change wRead m_init 1 11 = _; rw [hPar_init.hD1, hPD]
  let elimVBody : UL.ArithRAMStmt :=
    .seq
      (rSetArr 3 (.add (.mul (wReg 4 7) (wReg 1 11)) (wReg 4 11))
        (.sub (rArr 3 (.add (.mul (wReg 4 7) (wReg 1 11)) (wReg 4 11)))
          (.mul (rReg 1 3) (rArr 3 (.add (.mul (wReg 4 10) (wReg 1 11)) (wReg 4 11))))))
      (wSet 4 11 (.add (wReg 4 11) (iLit 1)))
  let elimCBody : UL.ArithRAMStmt :=
    .seq
      (rSetArr 4 (.add (.mul (wReg 4 7) (wReg 1 12)) (wReg 4 11))
        (.sub (rArr 4 (.add (.mul (wReg 4 7) (wReg 1 12)) (wReg 4 11)))
          (.mul (rReg 1 3) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))))))
      (wSet 4 11 (.add (wReg 4 11) (iLit 1)))
  rcases DetExec.repeatN_nat (wReg 1 11) gaussRowBody (D + 1) 5 (195 * (D + 3) ^ 2)
    InvRow hInvR₀ hcnt (by dsimp [intExprOps, wReg]; omega)
    (fun i hi_lt mi ⟨hPar, hPool, hIdx, hi_reg, ⟨hi_le, hGauss⟩⟩ => by
      let st := gaussRunRows pts i hi_le
      let ri : Fin (D + 1) := ⟨i, hi_lt⟩
      rcases exec_findPivot inp hPD ri mi hPar hPool hIdx hGauss hi_reg with
        ⟨mf, hsf, hParF, hPoolF, hIdxF, hGaussF, hiF, hpiv⟩
      have helim : ∃ me,
          DetExec inp
            (.ite (.intEq (wReg 4 9) (iLit 1))
              (seqList [wSetArr 3 (wReg 4 10) (iLit 1), wSet 4 7 (iLit 0),
                .repeatN (wReg 1 12) elimColBody])
              .skip)
            mf me (130 * (D + 3) ^ 2) ∧
          ParamsStored P me ∧ PoolStored T me ∧ IdxArrStored choice me ∧
          wRead me 4 8 = (i : ℤ) ∧
          GaussStored (gaussRowStep st ri) me := by
        unfold gaussRowStep
        cases hfind : findFirstFin (fun k : Fin (D + 2) => st.used k = false ∧ st.v k ri ≠ 0) with
        | none =>
            rw [hfind] at hpiv
            have hcond : cVal inp mf (.intEq (wReg 4 9) (iLit 1)) = false := by
              simp -zeta [wReg, iLit, hpiv]
            have hnone_cost : 10 + 1 ≤ 130 * (D + 3) ^ 2 := by
              have : 1 ≤ (D + 3) ^ 2 := Nat.one_le_pow 2 (D + 3) (by omega)
              omega
            refine ⟨mf, (DetExec.ite_false (C_c := 10) hcond
              (by dsimp [condExprOps, intExprOps, wReg, iLit]; omega)
              (DetExec.skip inp mf)).mono_cost hnone_cost,
              hParF, hPoolF, hIdxF, hiF, hGaussF⟩
        | some p =>
            rw [hfind] at hpiv
            rcases hpiv with ⟨h49_1, h410_p⟩
            have hcond : cVal inp mf (.intEq (wReg 4 9) (iLit 1)) = true := by
              simp -zeta [wReg, iLit, h49_1]
            let used' := Function.update st.used p true
            let alpha : Fin (D + 2) → ℝ := fun j => st.v j ri / st.v p ri
            let st' : GaussState D :=
              { used := used'
                v := fun j r => if used' j = false then st.v j r - alpha j * st.v p r else st.v j r
                c := fun j r => if used' j = false then st.c j r - alpha j * st.c p r else st.c j r }
            have hst'_p_v : ∀ r, st'.v p r = st.v p r := fun r => by simp [st', used']
            have hst'_p_c : ∀ r, st'.c p r = st.c p r := fun r => by simp [st', used']
            let m_u := wWrite mf 3 (p.val : ℤ) 1
            have hs_u : DetExec inp (wSetArr 3 (wReg 4 10) (iLit 1)) mf m_u 10 :=
              DetExec.writeWord inp mf 3 (wReg 4 10) (iLit 1) h410_p rfl
                (by dsimp [intExprOps, wReg, iLit]; omega)
            let m_j0 := wWrite m_u 4 7 0
            have hs_j0 : DetExec inp (wSet 4 7 (iLit 0)) m_u m_j0 5 :=
              DetExec.writeWord inp m_u 4 (.lit 7) (iLit 0) rfl rfl
                (by dsimp [intExprOps, iLit]; omega)
            let InvCol : ℕ → UL.ArithRAMMemory → Prop := fun j mj =>
              ParamsStored P mj ∧ PoolStored T mj ∧ IdxArrStored choice mj ∧
              wRead mj 4 8 = (i : ℤ) ∧ wRead mj 4 10 = (p.val : ℤ) ∧ wRead mj 4 7 = (j : ℤ) ∧
              (∀ k : Fin (D + 2), wRead mj 3 (k.val : ℤ) = (if used' k then 1 else 0)) ∧
              (∀ (k : Fin (D + 2)) (r : Fin (D + 1)),
                rRead mj 3 ((k.val * (D + 1) + r.val : ℕ) : ℤ) =
                  if k.val < j then st'.v k r else st.v k r) ∧
              (∀ (k : Fin (D + 2)) (r : Fin (D + 2)),
                rRead mj 4 ((k.val * (D + 2) + r.val : ℕ) : ℤ) =
                  if k.val < j then st'.c k r else st.c k r)
            have hPar_j0 : ParamsStored P m_j0 :=
              paramsStored_wWrite_ne (paramsStored_wWrite_ne hParF 3 _ _) 4 _ _
            have hInvC₀ : InvCol 0 m_j0 := by
              refine ⟨hPar_j0,
                poolStored_wWrite (poolStored_wWrite hPoolF 3 _ _) 4 _ _,
                idxArrStored_wWrite_ne (idxArrStored_wWrite_ne hIdxF 3 _ _) 4 _ _,
                by rw [wRead_wWrite_of_ne m_u _ (Or.inr (by decide)),
                    wRead_wWrite_of_ne mf _ (Or.inl (by decide)), hiF],
                by rw [wRead_wWrite_of_ne m_u _ (Or.inr (by decide)),
                    wRead_wWrite_of_ne mf _ (Or.inl (by decide)), h410_p],
                by simp [m_j0],
                fun k => ?_,
                fun k r => by simpa [m_j0, m_u] using hGaussF.2.1 k r,
                fun k r => by simpa [m_j0, m_u] using hGaussF.2.2 k r⟩
              rw [wRead_wWrite_of_ne m_u _ (Or.inl (by decide))]
              by_cases hkp : k = p
              · subst hkp; simp [m_u, used']
              · have hne : (k.val : ℤ) ≠ (p.val : ℤ) := fun h => hkp (Fin.ext (Int.ofNat.inj h))
                rw [wRead_wWrite_of_ne mf _ (Or.inr hne), hGaussF.1 k]
                dsimp only [used']
                rw [Function.update_of_ne hkp]
            have hcntD2 : iVal inp m_j0 (wReg 1 12) = ((D + 2 : ℕ) : ℤ) := by
              change wRead m_j0 1 12 = _; rw [hPar_j0.hD2, hPD]
            rcases DetExec.repeatN_nat (wReg 1 12) elimColBody (D + 2) 5 (110 * (D + 3))
              InvCol hInvC₀ hcntD2 (by dsimp [intExprOps, wReg]; omega)
              (fun j hj_lt mj ⟨hParJ, hPoolJ, hIdxJ, hiJ, hpJ, hjJ, huJ, hvJ, hcJ⟩ => by
                let jf : Fin (D + 2) := ⟨j, hj_lt⟩
                have hjf_val : jf.val = j := rfl
                have h11 : wRead mj 1 11 = ((D + 1 : ℕ) : ℤ) := by rw [hParJ.hD1, hPD]
                have hvp : ∀ r : Fin (D + 1),
                    rRead mj 3 ((p.val * (D + 1) + r.val : ℕ) : ℤ) = st.v p r := by
                  intro r; rw [hvJ p r]; split_ifs <;> simp [hst'_p_v]
                by_cases hused_jf : used' jf = false
                · have hj_ne_p : jf ≠ p := by
                    intro heq; subst heq; simp [used'] at hused_jf
                  have hcond_j : cVal inp mj (.intEq (wArr 3 (wReg 4 7)) (iLit 0)) = true := by
                    have hu_jf := huJ jf
                    rw [hjf_val] at hu_jf
                    simp -zeta [wArr, wReg, iLit, hjJ, hu_jf, hused_jf]
                  let ma1 := rWrite mj 1 3 (alpha jf)
                  have hsa1 : DetExec inp
                      (rSet 1 3 (.div
                        (rArr 3 (.add (.mul (wReg 4 7) (wReg 1 11)) (wReg 4 8)))
                        (rArr 3 (.add (.mul (wReg 4 10) (wReg 1 11)) (wReg 4 8))))) mj ma1 30 := by
                    refine DetExec.writeReal inp mj 1 (.lit 3) _ rfl ?_
                      (by dsimp [intExprOps, realExprOps, rArr, wReg]; omega)
                    have hv_jf : rRead mj 3 ((j * (D + 1) + i : ℕ) : ℤ) = st.v jf ri := by
                      have := hvJ jf ri
                      rw [hjf_val] at this
                      simpa [ri] using this
                    have hv_p_ri : rRead mj 3 ((p.val * (D + 1) + i : ℕ) : ℤ) = st.v p ri :=
                      hvp ri
                    simp -zeta only [rVal_div, rArr, rVal_readRealHeap, iVal_add, iVal_mul, wReg,
                      iVal_readHeap, iVal_lit, hjJ, h11, hiJ, hpJ]
                    have hidx1 : (j : ℤ) * ((D + 1 : ℕ) : ℤ) + (i : ℤ) =
                        ((j * (D + 1) + i : ℕ) : ℤ) := by push_cast; ring
                    have hidx2 : (p.val : ℤ) * ((D + 1 : ℕ) : ℤ) + (i : ℤ) =
                        ((p.val * (D + 1) + i : ℕ) : ℤ) := by push_cast; ring
                    rw [hidx1, hidx2, hv_jf, hv_p_ri]
                  let ma2 := wWrite ma1 4 11 0
                  have hsa2 : DetExec inp (wSet 4 11 (iLit 0)) ma1 ma2 5 :=
                    DetExec.writeWord inp ma1 4 (.lit 11) (iLit 0) rfl rfl
                      (by dsimp [intExprOps, iLit]; omega)
                  let InvRV : ℕ → UL.ArithRAMMemory → Prop := fun t mt =>
                    ParamsStored P mt ∧ PoolStored T mt ∧ IdxArrStored choice mt ∧
                    wRead mt 4 8 = (i : ℤ) ∧ wRead mt 4 10 = (p.val : ℤ) ∧
                    wRead mt 4 7 = (j : ℤ) ∧ wRead mt 4 11 = (t : ℤ) ∧
                    rRead mt 1 3 = alpha jf ∧
                    (∀ k : Fin (D + 2), wRead mt 3 (k.val : ℤ) = (if used' k then 1 else 0)) ∧
                    (∀ r : Fin (D + 1),
                      rRead mt 3 ((j * (D + 1) + r.val : ℕ) : ℤ) =
                        if r.val < t then st'.v jf r else st.v jf r) ∧
                    (∀ (k : Fin (D + 2)) (r : Fin (D + 1)), k ≠ jf →
                      rRead mt 3 ((k.val * (D + 1) + r.val : ℕ) : ℤ) =
                        if k.val < j then st'.v k r else st.v k r) ∧
                    (∀ (k : Fin (D + 2)) (r : Fin (D + 2)),
                      rRead mt 4 ((k.val * (D + 2) + r.val : ℕ) : ℤ) =
                        if k.val < j then st'.c k r else st.c k r)
                  have hPar_ma2 : ParamsStored P ma2 := paramsStored_wWrite_ne hParJ 4 _ _
                  have hInvRV₀ : InvRV 0 ma2 := by
                    refine ⟨hPar_ma2,
                      poolStored_wWrite (poolStored_rWrite_ne hPoolJ 1 _ _) 4 _ _,
                      idxArrStored_wWrite_ne hIdxJ 4 _ _,
                      by rw [wRead_wWrite_of_ne ma1 _ (Or.inr (by decide))]; exact hiJ,
                      by rw [wRead_wWrite_of_ne ma1 _ (Or.inr (by decide))]; exact hpJ,
                      by rw [wRead_wWrite_of_ne ma1 _ (Or.inr (by decide))]; exact hjJ,
                      by simp [ma2], by simp [ma2, ma1],
                      fun k => by rw [wRead_wWrite_of_ne ma1 _ (Or.inl (by decide))]; exact huJ k,
                      fun r => ?_, fun k r hne => ?_, fun k r => ?_⟩
                    · simp only [ma2, rRead_wWrite, ma1, Nat.not_lt_zero, ↓reduceIte]
                      rw [rRead_rWrite_of_ne mj _ (Or.inl (by decide))]
                      have := hvJ jf r; rw [hjf_val] at this; simpa using this
                    · simp only [ma2, rRead_wWrite, ma1]
                      rw [rRead_rWrite_of_ne mj _ (Or.inl (by decide))]; exact hvJ k r
                    · simp only [ma2, rRead_wWrite, ma1]
                      rw [rRead_rWrite_of_ne mj _ (Or.inl (by decide))]; exact hcJ k r
                  have hcntD1 : iVal inp ma2 (wReg 1 11) = ((D + 1 : ℕ) : ℤ) := by
                    change wRead ma2 1 11 = _; rw [hPar_ma2.hD1, hPD]
                  rcases DetExec.repeatN_nat (wReg 1 11) elimVBody (D + 1) 5 45
                    InvRV hInvRV₀ hcntD1 (by dsimp [intExprOps, wReg]; omega)
                    (fun t ht_lt mt ⟨hParT, hPoolT, hIdxT, hiT, hpT, hjT, htT, halT, huT, hjvT, hkvT, hcT⟩ => by
                      let tf : Fin (D + 1) := ⟨t, ht_lt⟩
                      have htf_val : tf.val = t := rfl
                      have h11T : wRead mt 1 11 = ((D + 1 : ℕ) : ℤ) := by rw [hParT.hD1, hPD]
                      let mt1 := rWrite mt 3 ((j * (D + 1) + t : ℕ) : ℤ) (st'.v jf tf)
                      have hst1 : DetExec inp
                          (rSetArr 3 (.add (.mul (wReg 4 7) (wReg 1 11)) (wReg 4 11))
                            (.sub (rArr 3 (.add (.mul (wReg 4 7) (wReg 1 11)) (wReg 4 11)))
                              (.mul (rReg 1 3)
                                (rArr 3 (.add (.mul (wReg 4 10) (wReg 1 11)) (wReg 4 11))))))
                          mt mt1 35 := by
                        refine DetExec.writeReal inp mt 3 _ _ ?_ ?_
                          (by dsimp [intExprOps, realExprOps, rArr, wReg, rReg]; omega)
                        · simp -zeta [wReg, hjT, h11T, htT]
                        · have hv_j_t : rRead mt 3 ((j * (D + 1) + t : ℕ) : ℤ) = st.v jf tf := by
                            have := hjvT tf; rw [htf_val] at this; simpa using this
                          have hv_p_t : rRead mt 3 ((p.val * (D + 1) + t : ℕ) : ℤ) = st.v p tf := by
                            have := hkvT p tf hj_ne_p.symm
                            rw [htf_val] at this
                            rw [this]; split_ifs <;> simp [hst'_p_v]
                          simp -zeta only [rVal_sub, rVal_mul, rArr, rReg, rVal_readRealHeap,
                            iVal_add, iVal_mul, wReg, iVal_readHeap, iVal_lit, hjT, h11T, htT,
                            hpT, halT]
                          have hidx1 : (j : ℤ) * ((D + 1 : ℕ) : ℤ) + (t : ℤ) =
                              ((j * (D + 1) + t : ℕ) : ℤ) := by push_cast; ring
                          have hidx2 : (p.val : ℤ) * ((D + 1 : ℕ) : ℤ) + (t : ℤ) =
                              ((p.val * (D + 1) + t : ℕ) : ℤ) := by push_cast; ring
                          rw [hidx1, hidx2, hv_j_t, hv_p_t]
                          simp [st', hused_jf]
                      let mt2 := wWrite mt1 4 11 ((t + 1 : ℕ) : ℤ)
                      have hst2 : DetExec inp (wSet 4 11 (.add (wReg 4 11) (iLit 1))) mt1 mt2 10 :=
                        DetExec.writeWord inp mt1 4 (.lit 11) _ rfl
                          (by simp -zeta [wReg, iLit, mt1, htT])
                          (by dsimp [intExprOps, wReg, iLit]; omega)
                      refine ⟨mt2, hst1.seq hst2,
                        paramsStored_wWrite_ne hParT 4 _ _,
                        poolStored_wWrite (poolStored_rWrite_ne hPoolT 3 _ _) 4 _ _,
                        idxArrStored_wWrite_ne hIdxT 4 _ _,
                        by rw [wRead_wWrite_of_ne mt1 _ (Or.inr (by decide))]; exact hiT,
                        by rw [wRead_wWrite_of_ne mt1 _ (Or.inr (by decide))]; exact hpT,
                        by rw [wRead_wWrite_of_ne mt1 _ (Or.inr (by decide))]; exact hjT,
                        by simp [mt2],
                        by simp only [mt2, rRead_wWrite, mt1];
                           rw [rRead_rWrite_of_ne mt _ (Or.inl (by decide))]; exact halT,
                        fun k => by rw [wRead_wWrite_of_ne mt1 _ (Or.inl (by decide))]; exact huT k,
                        fun r => ?_, fun k r hne => ?_,
                        fun k r => by
                          simp only [mt2, rRead_wWrite, mt1]
                          rw [rRead_rWrite_of_ne mt _ (Or.inl (by decide))]; exact hcT k r⟩
                      · simp only [mt2, rRead_wWrite]
                        by_cases hrt : r.val = t
                        · have hreq : r = tf := Fin.ext hrt; subst hreq
                          rw [htf_val]; simp [mt1]
                        · have hne_idx : ((j * (D + 1) + r.val : ℕ) : ℤ) ≠
                              ((j * (D + 1) + t : ℕ) : ℤ) :=
                            fun heq => hrt (flat2d_inj r.isLt ht_lt heq).2
                          rw [rRead_rWrite_of_ne mt _ (Or.inr hne_idx), hjvT r]
                          split_ifs <;> first | rfl | omega
                      · simp only [mt2, rRead_wWrite]
                        have hne_idx : ((k.val * (D + 1) + r.val : ℕ) : ℤ) ≠
                            ((j * (D + 1) + t : ℕ) : ℤ) := by
                          intro heq
                          exact hne (Fin.ext (flat2d_inj r.isLt ht_lt heq).1)
                        rw [rRead_rWrite_of_ne mt _ (Or.inr hne_idx)]
                        exact hkvT k r hne)
                    with ⟨ma3, ⟨hPar3, hPool3, hIdx3, hi3, hp3, hj3, _, hal3, hu3, hjv3, hkv3, hc3⟩, hsa3⟩
                  let ma4 := wWrite ma3 4 11 0
                  have hsa4 : DetExec inp (wSet 4 11 (iLit 0)) ma3 ma4 5 :=
                    DetExec.writeWord inp ma3 4 (.lit 11) (iLit 0) rfl rfl
                      (by dsimp [intExprOps, iLit]; omega)
                  let InvRC : ℕ → UL.ArithRAMMemory → Prop := fun t mt =>
                    ParamsStored P mt ∧ PoolStored T mt ∧ IdxArrStored choice mt ∧
                    wRead mt 4 8 = (i : ℤ) ∧ wRead mt 4 10 = (p.val : ℤ) ∧
                    wRead mt 4 7 = (j : ℤ) ∧ wRead mt 4 11 = (t : ℤ) ∧
                    rRead mt 1 3 = alpha jf ∧
                    (∀ k : Fin (D + 2), wRead mt 3 (k.val : ℤ) = (if used' k then 1 else 0)) ∧
                    (∀ (k : Fin (D + 2)) (r : Fin (D + 1)),
                      rRead mt 3 ((k.val * (D + 1) + r.val : ℕ) : ℤ) =
                        if k.val < j + 1 then st'.v k r else st.v k r) ∧
                    (∀ r : Fin (D + 2),
                      rRead mt 4 ((j * (D + 2) + r.val : ℕ) : ℤ) =
                        if r.val < t then st'.c jf r else st.c jf r) ∧
                    (∀ (k : Fin (D + 2)) (r : Fin (D + 2)), k ≠ jf →
                      rRead mt 4 ((k.val * (D + 2) + r.val : ℕ) : ℤ) =
                        if k.val < j then st'.c k r else st.c k r)
                  have hPar_ma4 : ParamsStored P ma4 := paramsStored_wWrite_ne hPar3 4 _ _
                  have hInvRC₀ : InvRC 0 ma4 := by
                    refine ⟨hPar_ma4,
                      poolStored_wWrite hPool3 4 _ _,
                      idxArrStored_wWrite_ne hIdx3 4 _ _,
                      by rw [wRead_wWrite_of_ne ma3 _ (Or.inr (by decide))]; exact hi3,
                      by rw [wRead_wWrite_of_ne ma3 _ (Or.inr (by decide))]; exact hp3,
                      by rw [wRead_wWrite_of_ne ma3 _ (Or.inr (by decide))]; exact hj3,
                      by simp [ma4], hal3,
                      fun k => by rw [wRead_wWrite_of_ne ma3 _ (Or.inl (by decide))]; exact hu3 k,
                      fun k r => ?_, fun r => ?_, fun k r hne => hc3 k r⟩
                    · simp only [ma4, rRead_wWrite]
                      by_cases hkj : k = jf
                      · subst hkj; rw [hjf_val]; simpa [r.isLt] using hjv3 r
                      · rw [hkv3 k r hkj]
                        have hne_val : k.val ≠ j := fun h => hkj (Fin.ext h)
                        split_ifs <;> first | rfl | omega
                    · have := hc3 jf r; rw [hjf_val] at this; simpa [ma4] using this
                  have hcntD2' : iVal inp ma4 (wReg 1 12) = ((D + 2 : ℕ) : ℤ) := by
                    change wRead ma4 1 12 = _; rw [hPar_ma4.hD2, hPD]
                  rcases DetExec.repeatN_nat (wReg 1 12) elimCBody (D + 2) 5 45
                    InvRC hInvRC₀ hcntD2' (by dsimp [intExprOps, wReg]; omega)
                    (fun t ht_lt mt ⟨hParT, hPoolT, hIdxT, hiT, hpT, hjT, htT, halT, huT, hvT, hjcT, hkcT⟩ => by
                      let tf : Fin (D + 2) := ⟨t, ht_lt⟩
                      have htf_val : tf.val = t := rfl
                      have h12T : wRead mt 1 12 = ((D + 2 : ℕ) : ℤ) := by rw [hParT.hD2, hPD]
                      let mt1 := rWrite mt 4 ((j * (D + 2) + t : ℕ) : ℤ) (st'.c jf tf)
                      have hst1 : DetExec inp
                          (rSetArr 4 (.add (.mul (wReg 4 7) (wReg 1 12)) (wReg 4 11))
                            (.sub (rArr 4 (.add (.mul (wReg 4 7) (wReg 1 12)) (wReg 4 11)))
                              (.mul (rReg 1 3)
                                (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))))))
                          mt mt1 35 := by
                        refine DetExec.writeReal inp mt 4 _ _ ?_ ?_
                          (by dsimp [intExprOps, realExprOps, rArr, wReg, rReg]; omega)
                        · simp -zeta [wReg, hjT, h12T, htT]
                        · have hc_j_t : rRead mt 4 ((j * (D + 2) + t : ℕ) : ℤ) = st.c jf tf := by
                            have := hjcT tf; rw [htf_val] at this; simpa using this
                          have hc_p_t : rRead mt 4 ((p.val * (D + 2) + t : ℕ) : ℤ) = st.c p tf := by
                            have := hkcT p tf hj_ne_p.symm
                            rw [htf_val] at this
                            rw [this]; split_ifs <;> simp [hst'_p_c]
                          simp -zeta only [rVal_sub, rVal_mul, rArr, rReg, rVal_readRealHeap,
                            iVal_add, iVal_mul, wReg, iVal_readHeap, iVal_lit, hjT, h12T, htT,
                            hpT, halT]
                          have hidx1 : (j : ℤ) * ((D + 2 : ℕ) : ℤ) + (t : ℤ) =
                              ((j * (D + 2) + t : ℕ) : ℤ) := by push_cast; ring
                          have hidx2 : (p.val : ℤ) * ((D + 2 : ℕ) : ℤ) + (t : ℤ) =
                              ((p.val * (D + 2) + t : ℕ) : ℤ) := by push_cast; ring
                          rw [hidx1, hidx2, hc_j_t, hc_p_t]
                          simp [st', hused_jf]
                      let mt2 := wWrite mt1 4 11 ((t + 1 : ℕ) : ℤ)
                      have hst2 : DetExec inp (wSet 4 11 (.add (wReg 4 11) (iLit 1))) mt1 mt2 10 :=
                        DetExec.writeWord inp mt1 4 (.lit 11) _ rfl
                          (by simp -zeta [wReg, iLit, mt1, htT])
                          (by dsimp [intExprOps, wReg, iLit]; omega)
                      refine ⟨mt2, hst1.seq hst2,
                        paramsStored_wWrite_ne hParT 4 _ _,
                        poolStored_wWrite (poolStored_rWrite_ne hPoolT 4 _ _) 4 _ _,
                        idxArrStored_wWrite_ne hIdxT 4 _ _,
                        by rw [wRead_wWrite_of_ne mt1 _ (Or.inr (by decide))]; exact hiT,
                        by rw [wRead_wWrite_of_ne mt1 _ (Or.inr (by decide))]; exact hpT,
                        by rw [wRead_wWrite_of_ne mt1 _ (Or.inr (by decide))]; exact hjT,
                        by simp [mt2],
                        by simp only [mt2, rRead_wWrite, mt1];
                           rw [rRead_rWrite_of_ne mt _ (Or.inl (by decide))]; exact halT,
                        fun k => by rw [wRead_wWrite_of_ne mt1 _ (Or.inl (by decide))]; exact huT k,
                        fun k r => by
                          simp only [mt2, rRead_wWrite, mt1]
                          rw [rRead_rWrite_of_ne mt _ (Or.inl (by decide))]; exact hvT k r,
                        fun r => ?_, fun k r hne => ?_⟩
                      · simp only [mt2, rRead_wWrite]
                        by_cases hrt : r.val = t
                        · have hreq : r = tf := Fin.ext hrt; subst hreq
                          rw [htf_val]; simp [mt1]
                        · have hne_idx : ((j * (D + 2) + r.val : ℕ) : ℤ) ≠
                              ((j * (D + 2) + t : ℕ) : ℤ) :=
                            fun heq => hrt (flat2d_inj r.isLt ht_lt heq).2
                          rw [rRead_rWrite_of_ne mt _ (Or.inr hne_idx), hjcT r]
                          split_ifs <;> first | rfl | omega
                      · simp only [mt2, rRead_wWrite]
                        have hne_idx : ((k.val * (D + 2) + r.val : ℕ) : ℤ) ≠
                            ((j * (D + 2) + t : ℕ) : ℤ) := by
                          intro heq
                          exact hne (Fin.ext (flat2d_inj r.isLt ht_lt heq).1)
                        rw [rRead_rWrite_of_ne mt _ (Or.inr hne_idx)]
                        exact hkcT k r hne)
                    with ⟨ma5, ⟨hPar5, hPool5, hIdx5, hi5, hp5, hj5, _, _, hu5, hv5, hjc5, hkc5⟩, hsa5⟩
                  let ma6 := wWrite ma5 4 7 ((j + 1 : ℕ) : ℤ)
                  have hsa6 : DetExec inp (wSet 4 7 (.add (wReg 4 7) (iLit 1))) ma5 ma6 10 :=
                    DetExec.writeWord inp ma5 4 (.lit 7) _ rfl (by simp -zeta [wReg, iLit, hj5])
                      (by dsimp [intExprOps, wReg, iLit]; omega)
                  have hite_j := DetExec.ite_true (fB := .skip) (C_c := 10) hcond_j
                    (by dsimp [condExprOps, intExprOps, wArr, wReg, iLit]; omega)
                    (hsa1.seq (hsa2.seq (hsa3.seq (hsa4.seq hsa5))))
                  refine ⟨ma6, ?_,
                    paramsStored_wWrite_ne hPar5 4 _ _,
                    poolStored_wWrite hPool5 4 _ _,
                    idxArrStored_wWrite_ne hIdx5 4 _ _,
                    by rw [wRead_wWrite_of_ne ma5 _ (Or.inr (by decide))]; exact hi5,
                    by rw [wRead_wWrite_of_ne ma5 _ (Or.inr (by decide))]; exact hp5,
                    by simp [ma6],
                    fun k => by rw [wRead_wWrite_of_ne ma5 _ (Or.inl (by decide))]; exact hu5 k,
                    hv5, fun k r => ?_⟩
                  · unfold elimColBody seqList
                    exact (hite_j.seq hsa6).mono_cost (by omega)
                  · simp only [ma6, rRead_wWrite]
                    by_cases hkj : k = jf
                    · subst hkj; rw [hjf_val]; simpa [r.isLt] using hjc5 r
                    · rw [hkc5 k r hkj]
                      have hne_val : k.val ≠ j := fun h => hkj (Fin.ext h)
                      split_ifs <;> first | rfl | omega
                · have hused_t : used' jf = true := by
                    cases h : used' jf <;> simp_all
                  have hcond_j : cVal inp mj (.intEq (wArr 3 (wReg 4 7)) (iLit 0)) = false := by
                    have hu_jf := huJ jf
                    rw [hjf_val] at hu_jf
                    simp -zeta [wArr, wReg, iLit, hjJ, hu_jf, hused_t]
                  let mj2 := wWrite mj 4 7 ((j + 1 : ℕ) : ℤ)
                  have hsj2 : DetExec inp (wSet 4 7 (.add (wReg 4 7) (iLit 1))) mj mj2 10 :=
                    DetExec.writeWord inp mj 4 (.lit 7) _ rfl (by simp -zeta [wReg, iLit, hjJ])
                      (by dsimp [intExprOps, wReg, iLit]; omega)
                  refine ⟨mj2, ?_,
                    paramsStored_wWrite_ne hParJ 4 _ _,
                    poolStored_wWrite hPoolJ 4 _ _,
                    idxArrStored_wWrite_ne hIdxJ 4 _ _,
                    by rw [wRead_wWrite_of_ne mj _ (Or.inr (by decide))]; exact hiJ,
                    by rw [wRead_wWrite_of_ne mj _ (Or.inr (by decide))]; exact hpJ,
                    by simp [mj2],
                    fun k => by rw [wRead_wWrite_of_ne mj _ (Or.inl (by decide))]; exact huJ k,
                    fun k r => ?_, fun k r => ?_⟩
                  · unfold elimColBody
                    exact ((DetExec.ite_false (C_c := 10) hcond_j
                      (by dsimp [condExprOps, intExprOps, wArr, wReg, iLit]; omega)
                      (DetExec.skip inp mj)).seq hsj2).mono_cost (by omega)
                  · simp only [mj2, rRead_wWrite, hvJ k r]
                    by_cases hkj : k.val = j
                    · have hkeq : k = jf := Fin.ext hkj; subst hkeq
                      rw [hjf_val]; simp [st', hused_t]
                    · split_ifs <;> first | rfl | omega
                  · simp only [mj2, rRead_wWrite, hcJ k r]
                    by_cases hkj : k.val = j
                    · have hkeq : k = jf := Fin.ext hkj; subst hkeq
                      rw [hjf_val]; simp [st', hused_t]
                    · split_ifs <;> first | rfl | omega)
              with ⟨me, ⟨hParE, hPoolE, hIdxE, hiE, _, _, huE, hvE, hcE⟩, hloopE⟩
            refine ⟨me, ?_, hParE, hPoolE, hIdxE, hiE,
              ⟨huE, fun k r => by simpa [k.isLt] using hvE k r,
                fun k r => by simpa [k.isLt] using hcE k r⟩⟩
            unfold seqList
            exact (DetExec.ite_true (C_c := 10) hcond
              (by dsimp [condExprOps, intExprOps, wReg, iLit]; omega)
              (hs_u.seq (hs_j0.seq hloopE))).mono_cost (cost_elim_col_outer D)
      rcases helim with ⟨me, hse, hParE, hPoolE, hIdxE, hiE, hGaussE⟩
      let m_next := wWrite me 4 8 ((i + 1 : ℕ) : ℤ)
      have hs_inc : DetExec inp (wSet 4 8 (.add (wReg 4 8) (iLit 1))) me m_next 10 :=
        DetExec.writeWord inp me 4 (.lit 8) _ rfl (by simp -zeta [wReg, iLit, hiE])
          (by dsimp [intExprOps, wReg, iLit]; omega)
      refine ⟨m_next, ?_,
        paramsStored_wWrite_ne hParE 4 _ _,
        poolStored_wWrite hPoolE 4 _ _,
        idxArrStored_wWrite_ne hIdxE 4 _ _,
        by simp [m_next],
        ⟨by omega, gaussStored_wWrite_ne hGaussE 4 _ _⟩⟩
      unfold gaussRowBody seqList
      exact (hsf.seq (hse.seq hs_inc)).mono_cost (cost_gauss_row D))
    with ⟨mem₁, ⟨hPar₁, hPool₁, hIdx₁, _, ⟨_, hGauss₁⟩⟩, hloop⟩
  exact ⟨mem₁, (hs_init.seq hloop).mono_cost (cost_gauss_outer D), hPar₁, hPool₁, hIdx₁, hGauss₁⟩

private theorem exec_findKStar {d D m : ℕ} (inp : UL.ArithRAMInput d)
    {P : HPJParams} (hPD : P.D = D)
    {T : Fin m → EuclideanSpace ℝ (Fin D)}
    {choice : (Fin (D + 2) → Fin m) × Fin m}
    {st : GaussState D}
    (mem₀ : UL.ArithRAMMemory)
    (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T mem₀)
    (hIdx₀ : IdxArrStored choice mem₀) (hGauss₀ : GaussStored st mem₀) :
    let k_star : Fin (D + 2) :=
      match findFirstFin (fun k : Fin (D + 2) => st.used k = false) with
      | some k => k
      | none => ⟨0, by omega⟩
    ∃ mem₁,
      DetExec inp findKStarStmt mem₀ mem₁ (40 * (D + 3)) ∧
      ParamsStored P mem₁ ∧ PoolStored T mem₁ ∧ IdxArrStored choice mem₁ ∧ GaussStored st mem₁ ∧
      wRead mem₁ 4 10 = (k_star.val : ℤ) := by
  intro k_star
  let Q : Fin (D + 2) → Prop := fun k => st.used k = false
  let m1 := wWrite mem₀ 4 9 0
  have hs1 : DetExec inp (wSet 4 9 (iLit 0)) mem₀ m1 5 :=
    DetExec.writeWord inp mem₀ 4 (.lit 9) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let m2 := wWrite m1 4 10 0
  have hs2 : DetExec inp (wSet 4 10 (iLit 0)) m1 m2 5 :=
    DetExec.writeWord inp m1 4 (.lit 10) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let m3 := wWrite m2 4 6 0
  have hs3 : DetExec inp (wSet 4 6 (iLit 0)) m2 m3 5 :=
    DetExec.writeWord inp m2 4 (.lit 6) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let Inv : ℕ → UL.ArithRAMMemory → Prop := fun t mt =>
    ParamsStored P mt ∧ PoolStored T mt ∧ IdxArrStored choice mt ∧ GaussStored st mt ∧
    wRead mt 4 6 = (t : ℤ) ∧
    ((wRead mt 4 9 = 0 ∧ wRead mt 4 10 = 0 ∧ ∀ k : Fin (D + 2), k.val < t → ¬ Q k) ∨
     (∃ p : Fin (D + 2), p.val < t ∧ wRead mt 4 9 = 1 ∧ wRead mt 4 10 = (p.val : ℤ) ∧
       Q p ∧ ∀ k : Fin (D + 2), k.val < p.val → ¬ Q k))
  have hPar3 : ParamsStored P m3 :=
    paramsStored_wWrite_ne (paramsStored_wWrite_ne (paramsStored_wWrite_ne hPar₀ 4 _ _) 4 _ _) 4 _ _
  have hInv₀ : Inv 0 m3 := by
    refine ⟨hPar3,
      poolStored_wWrite (poolStored_wWrite (poolStored_wWrite hPool₀ 4 _ _) 4 _ _) 4 _ _,
      idxArrStored_wWrite_ne (idxArrStored_wWrite_ne (idxArrStored_wWrite_ne hIdx₀ 4 _ _) 4 _ _) 4 _ _,
      gaussStored_wWrite_ne (gaussStored_wWrite_ne (gaussStored_wWrite_ne hGauss₀ 4 _ _) 4 _ _) 4 _ _,
      by simp [m3],
      Or.inl ⟨by rw [wRead_wWrite_of_ne m2 _ (Or.inr (by decide)),
          wRead_wWrite_of_ne m1 _ (Or.inr (by decide))]; simp [m1],
        by rw [wRead_wWrite_of_ne m2 _ (Or.inr (by decide))]; simp [m2],
        fun _ hk => by omega⟩⟩
  have hcnt : iVal inp m3 (wReg 1 12) = ((D + 2 : ℕ) : ℤ) := by
    change wRead m3 1 12 = _; rw [hPar3.hD2, hPD]
  let condK : UL.ArithCondExpr :=
    .and (.intEq (wReg 4 9) (iLit 0)) (.intEq (wArr 3 (wReg 4 6)) (iLit 0))
  let ksBody : UL.ArithRAMStmt :=
    .seq (.ite condK (.seq (wSet 4 9 (iLit 1)) (wSet 4 10 (wReg 4 6))) .skip)
      (wSet 4 6 (.add (wReg 4 6) (iLit 1)))
  rcases DetExec.repeatN_nat (wReg 1 12) ksBody (D + 2) 5 35 Inv hInv₀ hcnt
    (by dsimp [intExprOps, wReg]; omega)
    (fun t ht_lt mt ⟨hPar, hPool, hIdx, hGauss, h46, hscan⟩ => by
      let kt : Fin (D + 2) := ⟨t, ht_lt⟩
      have hkt_val : kt.val = t := rfl
      have hu_kt : wRead mt 3 (t : ℤ) = (if st.used kt then 1 else 0) := hGauss.1 kt
      rcases hscan with ⟨h49_0, h410_0, hnone_prev⟩ | ⟨p, hp_lt, h49_1, h410_p, hpQ, hmin_p⟩
      · by_cases hQkt : Q kt
        · have hcond : cVal inp mt condK = true := by
            have huf : st.used kt = false := hQkt
            simp -zeta [condK, wReg, wArr, iLit, h49_0, h46, hu_kt, huf]
          let ma := wWrite mt 4 9 1
          have hsa : DetExec inp (wSet 4 9 (iLit 1)) mt ma 5 :=
            DetExec.writeWord inp mt 4 (.lit 9) (iLit 1) rfl rfl (by dsimp [intExprOps, iLit]; omega)
          let mb := wWrite ma 4 10 (t : ℤ)
          have hsb : DetExec inp (wSet 4 10 (wReg 4 6)) ma mb 10 := by
            refine DetExec.writeWord inp ma 4 (.lit 10) (wReg 4 6) rfl ?_
              (by dsimp [intExprOps, wReg]; omega)
            change wRead ma 4 6 = _
            rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h46]
          have hite := DetExec.ite_true (fB := .skip) (C_c := 10) hcond
            (by dsimp [condK, condExprOps, intExprOps, wReg, wArr, iLit]; omega)
            (hsa.seq hsb)
          let mc := wWrite mb 4 6 ((t + 1 : ℕ) : ℤ)
          have hsc : DetExec inp (wSet 4 6 (.add (wReg 4 6) (iLit 1))) mb mc 10 := by
            refine DetExec.writeWord inp mb 4 (.lit 6) _ rfl ?_
              (by dsimp [intExprOps, wReg, iLit]; omega)
            have h46' : wRead mb 4 6 = (t : ℤ) := by
              rw [wRead_wWrite_of_ne ma _ (Or.inr (by decide)),
                wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h46]
            simp -zeta [wReg, iLit, h46']
          refine ⟨mc, (hite.seq hsc).mono_cost (by omega),
            paramsStored_wWrite_ne (paramsStored_wWrite_ne (paramsStored_wWrite_ne hPar 4 _ _) 4 _ _) 4 _ _,
            poolStored_wWrite (poolStored_wWrite (poolStored_wWrite hPool 4 _ _) 4 _ _) 4 _ _,
            idxArrStored_wWrite_ne (idxArrStored_wWrite_ne (idxArrStored_wWrite_ne hIdx 4 _ _) 4 _ _) 4 _ _,
            gaussStored_wWrite_ne (gaussStored_wWrite_ne (gaussStored_wWrite_ne hGauss 4 _ _) 4 _ _) 4 _ _,
            by simp [mc],
            Or.inr ⟨kt, by rw [hkt_val]; omega,
              by rw [wRead_wWrite_of_ne mb _ (Or.inr (by decide)),
                  wRead_wWrite_of_ne ma _ (Or.inr (by decide))]; simp [ma],
              by rw [wRead_wWrite_of_ne mb _ (Or.inr (by decide))]; simp [mb, kt],
              hQkt, hnone_prev⟩⟩
        · have hused_t : st.used kt = true := by
            cases h : st.used kt
            · exact absurd h hQkt
            · rfl
          have hcond : cVal inp mt condK = false := by
            simp -zeta [condK, wReg, wArr, iLit, h49_0, h46, hu_kt, hused_t]
          have hite := DetExec.ite_false (tB := .seq (wSet 4 9 (iLit 1)) (wSet 4 10 (wReg 4 6)))
            (C_c := 10) hcond
            (by dsimp [condK, condExprOps, intExprOps, wReg, wArr, iLit]; omega)
            (DetExec.skip inp mt)
          let mc := wWrite mt 4 6 ((t + 1 : ℕ) : ℤ)
          have hsc : DetExec inp (wSet 4 6 (.add (wReg 4 6) (iLit 1))) mt mc 10 :=
            DetExec.writeWord inp mt 4 (.lit 6) _ rfl (by simp -zeta [wReg, iLit, h46])
              (by dsimp [intExprOps, wReg, iLit]; omega)
          refine ⟨mc, (hite.seq hsc).mono_cost (by omega),
            paramsStored_wWrite_ne hPar 4 _ _,
            poolStored_wWrite hPool 4 _ _,
            idxArrStored_wWrite_ne hIdx 4 _ _,
            gaussStored_wWrite_ne hGauss 4 _ _,
            by simp [mc],
            Or.inl ⟨by rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h49_0],
              by rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h410_0],
              fun k hk => by
                by_cases hkt : k.val = t
                · have hkeq : k = kt := Fin.ext hkt; subst hkeq; exact hQkt
                · exact hnone_prev k (by omega)⟩⟩
      · have hcond : cVal inp mt condK = false := by
          simp -zeta [condK, wReg, iLit, h49_1]
        have hite := DetExec.ite_false (tB := .seq (wSet 4 9 (iLit 1)) (wSet 4 10 (wReg 4 6)))
          (C_c := 10) hcond
          (by dsimp [condK, condExprOps, intExprOps, wReg, wArr, iLit]; omega)
          (DetExec.skip inp mt)
        let mc := wWrite mt 4 6 ((t + 1 : ℕ) : ℤ)
        have hsc : DetExec inp (wSet 4 6 (.add (wReg 4 6) (iLit 1))) mt mc 10 :=
          DetExec.writeWord inp mt 4 (.lit 6) _ rfl (by simp -zeta [wReg, iLit, h46])
            (by dsimp [intExprOps, wReg, iLit]; omega)
        refine ⟨mc, (hite.seq hsc).mono_cost (by omega),
          paramsStored_wWrite_ne hPar 4 _ _,
          poolStored_wWrite hPool 4 _ _,
          idxArrStored_wWrite_ne hIdx 4 _ _,
          gaussStored_wWrite_ne hGauss 4 _ _,
          by simp [mc],
          Or.inr ⟨p, by have := hp_lt; omega,
            by rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h49_1],
            by rw [wRead_wWrite_of_ne mt _ (Or.inr (by decide)), h410_p],
            hpQ, hmin_p⟩⟩)
    with ⟨mem₁, ⟨hPar₁, hPool₁, hIdx₁, hGauss₁, _, hscan₁⟩, hloop⟩
  refine ⟨mem₁, ?_, hPar₁, hPool₁, hIdx₁, hGauss₁, ?_⟩
  · unfold findKStarStmt seqList
    exact (hs1.seq (hs2.seq (hs3.seq hloop))).mono_cost (by omega)
  · dsimp only [k_star]
    rcases hscan₁ with ⟨_, h410_0, hnone⟩ | ⟨p, _, _, h410_p, hpQ, hmin_p⟩
    · rw [findFirstFin_eq_none_of_forall_not (fun k => hnone k k.isLt)]
      exact h410_0
    · rw [findFirstFin_eq_some_of_first p hpQ hmin_p]
      exact h410_p

private theorem exec_computeRadPt {d D m : ℕ} (inp : UL.ArithRAMInput d)
    {P : HPJParams} (hPD : P.D = D)
    {T : Fin m → EuclideanSpace ℝ (Fin D)}
    {choice : (Fin (D + 2) → Fin m) × Fin m}
    (mem₀ : UL.ArithRAMMemory)
    (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T mem₀)
    (hIdx₀ : IdxArrStored choice mem₀)
    (hGauss₀ : GaussStored (gaussFinalState (fun k => T (choice.1 k))) mem₀) :
    let pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D) := fun k => T (choice.1 k)
    ∃ mem₁,
      DetExec inp computeRadPtStmt mem₀ mem₁ (120 * (D + 3) ^ 2) ∧
      ParamsStored P mem₁ ∧
      PoolStored T mem₁ ∧
      IdxArrStored choice mem₁ ∧
      RadPtStored (gaussRadonPoint pts) mem₁ := by
  intro pts
  let st := gaussFinalState pts
  let k_star : Fin (D + 2) :=
    match findFirstFin (fun k : Fin (D + 2) => st.used k = false) with
    | some k => k
    | none => ⟨0, by omega⟩
  let lam : Fin (D + 2) → ℝ := fun r => st.c k_star r
  let posSum : ℝ := ∑ r : Fin (D + 2), if 0 < lam r then lam r else 0
  rcases exec_findKStar inp hPD mem₀ hPar₀ hPool₀ hIdx₀ hGauss₀ with
    ⟨m1, hs1, hPar1, hPool1, hIdx1, hGauss1, hkstar1⟩
  let m2 := rWrite m1 1 4 0
  have hs2a : DetExec inp (rSet 1 4 (rLit 0)) m1 m2 5 :=
    DetExec.writeReal inp m1 1 (.lit 4) (rLit 0) rfl (by simp [rLit])
      (by dsimp [intExprOps, realExprOps, rLit]; omega)
  let m3 := wWrite m2 4 11 0
  have hs2b : DetExec inp (wSet 4 11 (iLit 0)) m2 m3 5 :=
    DetExec.writeWord inp m2 4 (.lit 11) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let InvPS : ℕ → UL.ArithRAMMemory → Prop := fun t mt =>
    ParamsStored P mt ∧ PoolStored T mt ∧ IdxArrStored choice mt ∧ GaussStored st mt ∧
    wRead mt 4 10 = (k_star.val : ℤ) ∧ wRead mt 4 11 = (t : ℤ) ∧
    (∃ ht : t ≤ D + 2,
      rRead mt 1 4 = ∑ r : Fin t,
        if 0 < lam ⟨r.val, lt_of_lt_of_le r.isLt ht⟩ then
          lam ⟨r.val, lt_of_lt_of_le r.isLt ht⟩
        else 0)
  have hPar3 : ParamsStored P m3 := paramsStored_wWrite_ne hPar1 4 _ _
  have hInvPS₀ : InvPS 0 m3 :=
    ⟨hPar3,
     poolStored_wWrite (poolStored_rWrite_ne hPool1 1 _ _) 4 _ _,
     idxArrStored_wWrite_ne hIdx1 4 _ _,
     gaussStored_wWrite_ne (gaussStored_rWrite_ne hGauss1 1 _ _) 4 _ _,
     by rw [wRead_wWrite_of_ne m2 _ (Or.inr (by decide))]; exact hkstar1,
     by simp [m3], ⟨Nat.zero_le _, by simp [m3, m2]⟩⟩
  have hcntD2 : iVal inp m3 (wReg 1 12) = ((D + 2 : ℕ) : ℤ) := by
    change wRead m3 1 12 = _; rw [hPar3.hD2, hPD]
  let psBody : UL.ArithRAMStmt :=
    .seq
      (.ite (.realLt (rLit 0) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))))
        (rSet 1 4 (.add (rReg 1 4) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11)))))
        .skip)
      (wSet 4 11 (.add (wReg 4 11) (iLit 1)))
  rcases DetExec.repeatN_nat (wReg 1 12) psBody (D + 2) 5 40 InvPS hInvPS₀ hcntD2
    (by dsimp [intExprOps, wReg]; omega)
    (fun t ht_lt mt ⟨hParT, hPoolT, hIdxT, hGaussT, hksT, htT, ⟨_, hpsT⟩⟩ => by
      let tf : Fin (D + 2) := ⟨t, ht_lt⟩
      have h12T : wRead mt 1 12 = ((D + 2 : ℕ) : ℤ) := by rw [hParT.hD2, hPD]
      have hlam_val : rVal inp mt (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))) =
          lam tf := by
        simp -zeta only [rArr, rVal_readRealHeap, iVal_add, iVal_mul, wReg, iVal_readHeap,
          iVal_lit, hksT, h12T, htT]
        have hidx : (k_star.val : ℤ) * ((D + 2 : ℕ) : ℤ) + (t : ℤ) =
            ((k_star.val * (D + 2) + t : ℕ) : ℤ) := by push_cast; ring
        rw [hidx]; exact hGaussT.2.2 k_star tf
      let next_sum := rRead mt 1 4 + (if 0 < lam tf then lam tf else 0)
      have hite : ∃ mt1,
          DetExec inp
            (.ite (.realLt (rLit 0) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))))
              (rSet 1 4 (.add (rReg 1 4)
                (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11)))))
              .skip) mt mt1 30 ∧
          ParamsStored P mt1 ∧ PoolStored T mt1 ∧ IdxArrStored choice mt1 ∧ GaussStored st mt1 ∧
          wRead mt1 4 10 = (k_star.val : ℤ) ∧ wRead mt1 4 11 = (t : ℤ) ∧
          rRead mt1 1 4 = next_sum := by
        by_cases hpos : 0 < lam tf
        · have hcond : cVal inp mt
              (.realLt (rLit 0) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11)))) = true := by
            simp -zeta [rLit, hlam_val, hpos]
          let mt1 := rWrite mt 1 4 next_sum
          have hbr : DetExec inp
              (rSet 1 4 (.add (rReg 1 4)
                (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))))) mt mt1 15 := by
            refine DetExec.writeReal inp mt 1 (.lit 4) _ rfl ?_
              (by dsimp [intExprOps, realExprOps, rReg, rArr, wReg]; omega)
            simp -zeta [rReg, hlam_val, next_sum, hpos]
          refine ⟨mt1, DetExec.ite_true (C_c := 15) hcond
            (by dsimp [condExprOps, realExprOps, intExprOps, rLit, rArr, wReg]; omega) hbr,
            hParT, poolStored_rWrite_ne hPoolT 1 _ _, hIdxT,
            gaussStored_rWrite_ne hGaussT 1 _ _, hksT, htT, by simp [mt1]⟩
        · have hcond : cVal inp mt
              (.realLt (rLit 0) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11)))) = false := by
            simp -zeta [rLit, hlam_val, hpos]
          refine ⟨mt, (DetExec.ite_false (C_c := 15) hcond
            (by dsimp [condExprOps, realExprOps, intExprOps, rLit, rArr, wReg]; omega)
            (DetExec.skip inp mt)).mono_cost (by omega),
            hParT, hPoolT, hIdxT, hGaussT, hksT, htT, by simp [next_sum, hpos]⟩
      rcases hite with ⟨mt1, hst1, hParT1, hPoolT1, hIdxT1, hGaussT1, hksT1, htT1, hpsT1⟩
      let mt2 := wWrite mt1 4 11 ((t + 1 : ℕ) : ℤ)
      have hst2 : DetExec inp (wSet 4 11 (.add (wReg 4 11) (iLit 1))) mt1 mt2 10 :=
        DetExec.writeWord inp mt1 4 (.lit 11) _ rfl (by simp -zeta [wReg, iLit, htT1])
          (by dsimp [intExprOps, wReg, iLit]; omega)
      refine ⟨mt2, hst1.seq hst2,
        paramsStored_wWrite_ne hParT1 4 _ _,
        poolStored_wWrite hPoolT1 4 _ _,
        idxArrStored_wWrite_ne hIdxT1 4 _ _,
        gaussStored_wWrite_ne hGaussT1 4 _ _,
        by rw [wRead_wWrite_of_ne mt1 _ (Or.inr (by decide))]; exact hksT1,
        by simp [mt2], ⟨by omega, ?_⟩⟩
      simp only [mt2, rRead_wWrite, hpsT1, next_sum, hpsT]
      rw [Fin.sum_univ_castSucc]
      rfl)
    with ⟨m4, ⟨hPar4, hPool4, hIdx4, hGauss4, hks4, _, ⟨_, hps4⟩⟩, hs2c⟩
  have hps4_eq : rRead m4 1 4 = posSum := by simpa [posSum] using hps4
  have hs2 : DetExec inp computePosSumStmt m1 m4 (15 + (D + 2) * 40) := by
    unfold computePosSumStmt seqList
    exact (hs2a.seq (hs2b.seq hs2c)).mono_cost (by omega)
  let m5 := wWrite m4 4 2 0
  have hs3a : DetExec inp (wSet 4 2 (iLit 0)) m4 m5 5 :=
    DetExec.writeWord inp m4 4 (.lit 2) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let InvCoord : ℕ → UL.ArithRAMMemory → Prop := fun c mc =>
    ParamsStored P mc ∧ PoolStored T mc ∧ IdxArrStored choice mc ∧ GaussStored st mc ∧
    wRead mc 4 10 = (k_star.val : ℤ) ∧ wRead mc 4 2 = (c : ℤ) ∧
    rRead mc 1 4 = posSum ∧
    (∀ c' : Fin D, c'.val < c →
      rRead mc 5 (c'.val : ℤ) = UL.euclideanCoord (gaussRadonPoint pts) c')
  have hPar5 : ParamsStored P m5 := paramsStored_wWrite_ne hPar4 4 _ _
  have hInvC₀ : InvCoord 0 m5 :=
    ⟨hPar5, poolStored_wWrite hPool4 4 _ _, idxArrStored_wWrite_ne hIdx4 4 _ _,
     gaussStored_wWrite_ne hGauss4 4 _ _,
     by rw [wRead_wWrite_of_ne m4 _ (Or.inr (by decide))]; exact hks4,
     by simp [m5], hps4_eq, fun _ h => by omega⟩
  have hcntD : iVal inp m5 (wReg 1 0) = (D : ℤ) := by
    change wRead m5 1 0 = _; rw [hPar5.hD, hPD]
  let radAccBody : UL.ArithRAMStmt :=
    .seq
      (.ite (.realLt (rLit 0) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))))
        (rSet 1 5 (.add (rReg 1 5)
          (.mul
            (.div (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))) (rReg 1 4))
            (rArr 2 (.add (.mul (wArr 2 (wReg 4 11)) (wReg 1 0)) (wReg 4 2))))))
        .skip)
      (wSet 4 11 (.add (wReg 4 11) (iLit 1)))
  let radCoordBody : UL.ArithRAMStmt :=
    seqList
      [ rSet 1 5 (rLit 0),
        wSet 4 11 (iLit 0),
        .repeatN (wReg 1 12) radAccBody,
        rSetArr 5 (wReg 4 2) (rReg 1 5),
        wSet 4 2 (.add (wReg 4 2) (iLit 1)) ]
  rcases DetExec.repeatN_nat (wReg 1 0) radCoordBody D 5 (35 + (D + 2) * 60) InvCoord hInvC₀ hcntD
    (by dsimp [intExprOps, wReg]; omega)
    (fun c hc_lt mc ⟨hParC, hPoolC, hIdxC, hGaussC, hksC, hcC, hpsC, hprevC⟩ => by
      let cf : Fin D := ⟨c, hc_lt⟩
      let mc1 := rWrite mc 1 5 0
      have hsc1 : DetExec inp (rSet 1 5 (rLit 0)) mc mc1 5 :=
        DetExec.writeReal inp mc 1 (.lit 5) (rLit 0) rfl (by simp [rLit])
          (by dsimp [intExprOps, realExprOps, rLit]; omega)
      let mc2 := wWrite mc1 4 11 0
      have hsc2 : DetExec inp (wSet 4 11 (iLit 0)) mc1 mc2 5 :=
        DetExec.writeWord inp mc1 4 (.lit 11) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
      let termFn : Fin (D + 2) → ℝ := fun r =>
        if 0 < lam r then (lam r / posSum) * UL.euclideanCoord (pts r) cf else 0
      let InvAcc : ℕ → UL.ArithRAMMemory → Prop := fun t mt =>
        ParamsStored P mt ∧ PoolStored T mt ∧ IdxArrStored choice mt ∧ GaussStored st mt ∧
        wRead mt 4 10 = (k_star.val : ℤ) ∧ wRead mt 4 2 = (c : ℤ) ∧ wRead mt 4 11 = (t : ℤ) ∧
        rRead mt 1 4 = posSum ∧
        (∀ c' : Fin D, c'.val < c →
          rRead mt 5 (c'.val : ℤ) = UL.euclideanCoord (gaussRadonPoint pts) c') ∧
        (∃ ht : t ≤ D + 2,
          rRead mt 1 5 = ∑ r : Fin t, termFn ⟨r.val, lt_of_lt_of_le r.isLt ht⟩)
      have hPar_mc2 : ParamsStored P mc2 := paramsStored_wWrite_ne hParC 4 _ _
      have hInvA₀ : InvAcc 0 mc2 :=
        ⟨hPar_mc2,
         poolStored_wWrite (poolStored_rWrite_ne hPoolC 1 _ _) 4 _ _,
         idxArrStored_wWrite_ne hIdxC 4 _ _,
         gaussStored_wWrite_ne (gaussStored_rWrite_ne hGaussC 1 _ _) 4 _ _,
         by rw [wRead_wWrite_of_ne mc1 _ (Or.inr (by decide))]; exact hksC,
         by rw [wRead_wWrite_of_ne mc1 _ (Or.inr (by decide))]; exact hcC,
         by simp [mc2],
         by simp only [mc2, rRead_wWrite, mc1];
            rw [rRead_rWrite_of_ne mc _ (Or.inr (by decide))]; exact hpsC,
         fun c' hc' => by
           simp only [mc2, rRead_wWrite, mc1]
           rw [rRead_rWrite_of_ne mc _ (Or.inl (by decide))]
           exact hprevC c' hc',
         ⟨Nat.zero_le _, by simp [mc2, mc1]⟩⟩
      have hcntD2C : iVal inp mc2 (wReg 1 12) = ((D + 2 : ℕ) : ℤ) := by
        change wRead mc2 1 12 = _; rw [hPar_mc2.hD2, hPD]
      rcases DetExec.repeatN_nat (wReg 1 12) radAccBody (D + 2) 5 60 InvAcc hInvA₀ hcntD2C
        (by dsimp [intExprOps, wReg]; omega)
        (fun t ht_lt mt ⟨hParT, hPoolT, hIdxT, hGaussT, hksT, hcT, htT, hpsT, hprevT, ⟨_, haccT⟩⟩ => by
          let tf : Fin (D + 2) := ⟨t, ht_lt⟩
          have h0T : wRead mt 1 0 = (D : ℤ) := by rw [hParT.hD, hPD]
          have h12T : wRead mt 1 12 = ((D + 2 : ℕ) : ℤ) := by rw [hParT.hD2, hPD]
          have hlam_val : rVal inp mt (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))) =
              lam tf := by
            simp -zeta only [rArr, rVal_readRealHeap, iVal_add, iVal_mul, wReg, iVal_readHeap,
              iVal_lit, hksT, h12T, htT]
            have hidx : (k_star.val : ℤ) * ((D + 2 : ℕ) : ℤ) + (t : ℤ) =
                ((k_star.val * (D + 2) + t : ℕ) : ℤ) := by push_cast; ring
            rw [hidx]; exact hGaussT.2.2 k_star tf
          have hpt_val : rVal inp mt
              (rArr 2 (.add (.mul (wArr 2 (wReg 4 11)) (wReg 1 0)) (wReg 4 2))) =
              UL.euclideanCoord (pts tf) cf := by
            have hidx_arr : wRead mt 2 (t : ℤ) = ((choice.1 tf).val : ℤ) := hIdxT.1 tf
            simp -zeta only [rArr, rVal_readRealHeap, iVal_add, iVal_mul, wArr, wReg,
              iVal_readHeap, iVal_lit, htT, hidx_arr, h0T, hcT]
            have hidx : ((choice.1 tf).val : ℤ) * (D : ℤ) + (c : ℤ) =
                (((choice.1 tf).val * D + c : ℕ) : ℤ) := by push_cast; ring
            rw [hidx]; exact hPoolT (choice.1 tf) cf
          let next_acc := rRead mt 1 5 + termFn tf
          have hite : ∃ mt1,
              DetExec inp
                (.ite (.realLt (rLit 0) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))))
                  (rSet 1 5 (.add (rReg 1 5)
                    (.mul
                      (.div (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))) (rReg 1 4))
                      (rArr 2 (.add (.mul (wArr 2 (wReg 4 11)) (wReg 1 0)) (wReg 4 2))))))
                  .skip) mt mt1 50 ∧
              ParamsStored P mt1 ∧ PoolStored T mt1 ∧ IdxArrStored choice mt1 ∧ GaussStored st mt1 ∧
              wRead mt1 4 10 = (k_star.val : ℤ) ∧ wRead mt1 4 2 = (c : ℤ) ∧
              wRead mt1 4 11 = (t : ℤ) ∧ rRead mt1 1 4 = posSum ∧
              (∀ c' : Fin D, c'.val < c →
                rRead mt1 5 (c'.val : ℤ) = UL.euclideanCoord (gaussRadonPoint pts) c') ∧
              rRead mt1 1 5 = next_acc := by
            by_cases hpos : 0 < lam tf
            · have hcond : cVal inp mt
                  (.realLt (rLit 0) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11)))) =
                  true := by
                simp -zeta [rLit, hlam_val, hpos]
              let mt1 := rWrite mt 1 5 next_acc
              have hbr : DetExec inp
                  (rSet 1 5 (.add (rReg 1 5)
                    (.mul
                      (.div (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11))) (rReg 1 4))
                      (rArr 2 (.add (.mul (wArr 2 (wReg 4 11)) (wReg 1 0)) (wReg 4 2))))))
                  mt mt1 35 := by
                refine DetExec.writeReal inp mt 1 (.lit 5) _ rfl ?_
                  (by dsimp [intExprOps, realExprOps, rReg, rArr, wArr, wReg]; omega)
                simp -zeta [rReg, hlam_val, hpsT, hpt_val, next_acc, termFn, hpos]
              refine ⟨mt1, DetExec.ite_true (C_c := 15) hcond
                (by dsimp [condExprOps, realExprOps, intExprOps, rLit, rArr, wReg]; omega) hbr,
                hParT, poolStored_rWrite_ne hPoolT 1 _ _, hIdxT,
                gaussStored_rWrite_ne hGaussT 1 _ _, hksT, hcT, htT,
                by rw [rRead_rWrite_of_ne mt _ (Or.inr (by decide))]; exact hpsT,
                fun c' hc' => by
                  rw [rRead_rWrite_of_ne mt _ (Or.inl (by decide))]; exact hprevT c' hc',
                by simp [mt1]⟩
            · have hcond : cVal inp mt
                  (.realLt (rLit 0) (rArr 4 (.add (.mul (wReg 4 10) (wReg 1 12)) (wReg 4 11)))) =
                  false := by
                simp -zeta [rLit, hlam_val, hpos]
              refine ⟨mt, (DetExec.ite_false (C_c := 15) hcond
                (by dsimp [condExprOps, realExprOps, intExprOps, rLit, rArr, wReg]; omega)
                (DetExec.skip inp mt)).mono_cost (by omega),
                hParT, hPoolT, hIdxT, hGaussT, hksT, hcT, htT, hpsT, hprevT,
                by simp [next_acc, termFn, hpos]⟩
          rcases hite with
            ⟨mt1, hst1, hParT1, hPoolT1, hIdxT1, hGaussT1, hksT1, hcT1, htT1, hpsT1, hprevT1, haccT1⟩
          let mt2 := wWrite mt1 4 11 ((t + 1 : ℕ) : ℤ)
          have hst2 : DetExec inp (wSet 4 11 (.add (wReg 4 11) (iLit 1))) mt1 mt2 10 :=
            DetExec.writeWord inp mt1 4 (.lit 11) _ rfl (by simp -zeta [wReg, iLit, htT1])
              (by dsimp [intExprOps, wReg, iLit]; omega)
          refine ⟨mt2, hst1.seq hst2,
            paramsStored_wWrite_ne hParT1 4 _ _,
            poolStored_wWrite hPoolT1 4 _ _,
            idxArrStored_wWrite_ne hIdxT1 4 _ _,
            gaussStored_wWrite_ne hGaussT1 4 _ _,
            by rw [wRead_wWrite_of_ne mt1 _ (Or.inr (by decide))]; exact hksT1,
            by rw [wRead_wWrite_of_ne mt1 _ (Or.inr (by decide))]; exact hcT1,
            by simp [mt2], hpsT1, hprevT1, ⟨by omega, ?_⟩⟩
          simp only [mt2, rRead_wWrite, haccT1, next_acc, haccT]
          rw [Fin.sum_univ_castSucc]
          rfl)
        with ⟨mc3, ⟨hParC3, hPoolC3, hIdxC3, hGaussC3, hksC3, hcC3, _, hpsC3, hprevC3, ⟨_, haccC3⟩⟩, hsc3⟩
      have hrad_cf : rRead mc3 1 5 = UL.euclideanCoord (gaussRadonPoint pts) cf := by
        simpa [gaussRadonPoint, UL.euclideanCoord, st, k_star, lam, posSum, termFn] using haccC3
      let mc4 := rWrite mc3 5 (c : ℤ) (UL.euclideanCoord (gaussRadonPoint pts) cf)
      have hsc4 : DetExec inp (rSetArr 5 (wReg 4 2) (rReg 1 5)) mc3 mc4 10 :=
        DetExec.writeReal inp mc3 5 (wReg 4 2) (rReg 1 5) hcC3 hrad_cf
          (by dsimp [intExprOps, realExprOps, wReg, rReg]; omega)
      let mc5 := wWrite mc4 4 2 ((c + 1 : ℕ) : ℤ)
      have hsc5 : DetExec inp (wSet 4 2 (.add (wReg 4 2) (iLit 1))) mc4 mc5 10 :=
        DetExec.writeWord inp mc4 4 (.lit 2) _ rfl (by simp -zeta [wReg, iLit, mc4, hcC3])
          (by dsimp [intExprOps, wReg, iLit]; omega)
      refine ⟨mc5, ?_,
        paramsStored_wWrite_ne hParC3 4 _ _,
        poolStored_wWrite (poolStored_rWrite_ne hPoolC3 5 _ _) 4 _ _,
        idxArrStored_wWrite_ne hIdxC3 4 _ _,
        gaussStored_wWrite_ne (gaussStored_rWrite_ne hGaussC3 5 _ _) 4 _ _,
        by rw [wRead_wWrite_of_ne mc4 _ (Or.inr (by decide))]; exact hksC3,
        by simp [mc5],
        by simp only [mc5, rRead_wWrite, mc4];
           rw [rRead_rWrite_of_ne mc3 _ (Or.inl (by decide))]; exact hpsC3,
        fun c' hc' => ?_⟩
      · unfold radCoordBody seqList
        exact (hsc1.seq (hsc2.seq (hsc3.seq (hsc4.seq hsc5)))).mono_cost (by omega)
      · simp only [mc5, rRead_wWrite]
        by_cases hcc : c'.val = c
        · have hceq : c' = cf := Fin.ext hcc; subst hceq; simp [mc4, cf]
        · rw [rRead_rWrite_of_ne mc3 _ (Or.inr (by omega))]
          exact hprevC3 c' (by omega))
    with ⟨mem₁, ⟨hPar₁, hPool₁, hIdx₁, _, _, _, _, hrad₁⟩, hs3b⟩
  refine ⟨mem₁, ?_, hPar₁, hPool₁, hIdx₁, fun c => hrad₁ c c.isLt⟩
  unfold computeRadPtStmt seqList
  exact (hs1.seq (hs2.seq (hs3a.seq hs3b))).mono_cost (cost_radpt_outer D)

private theorem exec_copyRadPtToPool {d D m : ℕ} (inp : UL.ArithRAMInput d)
    {P : HPJParams} (hPD : P.D = D)
    {T : Fin m → EuclideanSpace ℝ (Fin D)}
    {choice : (Fin (D + 2) → Fin m) × Fin m}
    {pt : EuclideanSpace ℝ (Fin D)}
    (mem₀ : UL.ArithRAMMemory)
    (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T mem₀)
    (hIdx₀ : IdxArrStored choice mem₀) (hRad₀ : RadPtStored pt mem₀) :
    ∃ mem₁,
      DetExec inp copyRadPtToPoolStmt mem₀ mem₁ (40 * (D + 3)) ∧
      ParamsStored P mem₁ ∧
      PoolStored (Function.update T choice.2 pt) mem₁ := by
  let p_dst := choice.2
  have h12₀ : wRead mem₀ 1 12 = ((D + 2 : ℕ) : ℤ) := by rw [hPar₀.hD2, hPD]
  let m1 := wWrite mem₀ 4 12 (p_dst.val : ℤ)
  have hs1 : DetExec inp (wSet 4 12 (wArr 2 (wReg 1 12))) mem₀ m1 10 := by
    refine DetExec.writeWord inp mem₀ 4 (.lit 12) (wArr 2 (wReg 1 12)) rfl ?_
      (by dsimp [intExprOps, wArr, wReg]; omega)
    change wRead mem₀ 2 (wRead mem₀ 1 12) = _
    rw [h12₀]; exact hIdx₀.2
  let m2 := wWrite m1 4 2 0
  have hs2 : DetExec inp (wSet 4 2 (iLit 0)) m1 m2 5 :=
    DetExec.writeWord inp m1 4 (.lit 2) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let Inv : ℕ → UL.ArithRAMMemory → Prop := fun c mc =>
    ParamsStored P mc ∧ RadPtStored pt mc ∧
    wRead mc 4 12 = (p_dst.val : ℤ) ∧ wRead mc 4 2 = (c : ℤ) ∧
    (∀ c' : Fin D, c'.val < c →
      rRead mc 2 ((p_dst.val * D + c'.val : ℕ) : ℤ) = UL.euclideanCoord pt c') ∧
    (∀ c' : Fin D, c ≤ c'.val →
      rRead mc 2 ((p_dst.val * D + c'.val : ℕ) : ℤ) = UL.euclideanCoord (T p_dst) c') ∧
    (∀ (p : Fin m) (c' : Fin D), p ≠ p_dst →
      rRead mc 2 ((p.val * D + c'.val : ℕ) : ℤ) = UL.euclideanCoord (T p) c')
  have hPar2 : ParamsStored P m2 :=
    paramsStored_wWrite_ne (paramsStored_wWrite_ne hPar₀ 4 _ _) 4 _ _
  have hInv₀ : Inv 0 m2 :=
    ⟨hPar2, hRad₀,
     by rw [wRead_wWrite_of_ne m1 _ (Or.inr (by decide))]; simp [m1],
     by simp [m2], fun _ h => by omega,
     fun c' _ => hPool₀ p_dst c', fun p c' _ => hPool₀ p c'⟩
  have hcntD : iVal inp m2 (wReg 1 0) = (D : ℤ) := by
    change wRead m2 1 0 = _; rw [hPar2.hD, hPD]
  let copyBody : UL.ArithRAMStmt :=
    .seq
      (rSetArr 2 (.add (.mul (wReg 4 12) (wReg 1 0)) (wReg 4 2)) (rArr 5 (wReg 4 2)))
      (wSet 4 2 (.add (wReg 4 2) (iLit 1)))
  rcases DetExec.repeatN_nat (wReg 1 0) copyBody D 5 30 Inv hInv₀ hcntD
    (by dsimp [intExprOps, wReg]; omega)
    (fun c hc_lt mc ⟨hParC, hRadC, hpC, hcC, hltC, hgeC, hneC⟩ => by
      let cf : Fin D := ⟨c, hc_lt⟩
      have h0C : wRead mc 1 0 = (D : ℤ) := by rw [hParC.hD, hPD]
      let mc1 := rWrite mc 2 ((p_dst.val * D + c : ℕ) : ℤ) (UL.euclideanCoord pt cf)
      have hsc1 : DetExec inp
          (rSetArr 2 (.add (.mul (wReg 4 12) (wReg 1 0)) (wReg 4 2)) (rArr 5 (wReg 4 2)))
          mc mc1 20 := by
        refine DetExec.writeReal inp mc 2 _ (rArr 5 (wReg 4 2)) ?_ ?_
          (by dsimp [intExprOps, realExprOps, wReg, rArr]; omega)
        · simp -zeta [wReg, hpC, h0C, hcC]
        · change rRead mc 5 (wRead mc 4 2) = _; rw [hcC]; exact hRadC cf
      let mc2 := wWrite mc1 4 2 ((c + 1 : ℕ) : ℤ)
      have hsc2 : DetExec inp (wSet 4 2 (.add (wReg 4 2) (iLit 1))) mc1 mc2 10 :=
        DetExec.writeWord inp mc1 4 (.lit 2) _ rfl (by simp -zeta [wReg, iLit, mc1, hcC])
          (by dsimp [intExprOps, wReg, iLit]; omega)
      refine ⟨mc2, hsc1.seq hsc2,
        paramsStored_wWrite_ne hParC 4 _ _,
        fun coord => by
          simp only [mc2, rRead_wWrite, mc1]
          rw [rRead_rWrite_of_ne mc _ (Or.inl (by decide))]; exact hRadC coord,
        by rw [wRead_wWrite_of_ne mc1 _ (Or.inr (by decide))]; exact hpC,
        by simp [mc2], fun c' hc' => ?_, fun c' hc' => ?_, fun p c' hne => ?_⟩
      · simp only [mc2, rRead_wWrite]
        by_cases hcc : c'.val = c
        · have hceq : c' = cf := Fin.ext hcc; subst hceq; simp [mc1, cf]
        · have hne_idx : ((p_dst.val * D + c'.val : ℕ) : ℤ) ≠ ((p_dst.val * D + c : ℕ) : ℤ) :=
            fun heq => hcc (flat2d_inj c'.isLt hc_lt heq).2
          rw [rRead_rWrite_of_ne mc _ (Or.inr hne_idx)]
          exact hltC c' (by omega)
      · simp only [mc2, rRead_wWrite]
        have hne_idx : ((p_dst.val * D + c'.val : ℕ) : ℤ) ≠ ((p_dst.val * D + c : ℕ) : ℤ) := by
          intro heq; have := (flat2d_inj c'.isLt hc_lt heq).2; omega
        rw [rRead_rWrite_of_ne mc _ (Or.inr hne_idx)]
        exact hgeC c' (by omega)
      · simp only [mc2, rRead_wWrite]
        have hne_idx : ((p.val * D + c'.val : ℕ) : ℤ) ≠ ((p_dst.val * D + c : ℕ) : ℤ) :=
          fun heq => hne (Fin.ext (flat2d_inj c'.isLt hc_lt heq).1)
        rw [rRead_rWrite_of_ne mc _ (Or.inr hne_idx)]
        exact hneC p c' hne)
    with ⟨mem₁, ⟨hPar₁, _, _, _, hlt₁, _, hne₁⟩, hloop⟩
  refine ⟨mem₁, ?_, hPar₁, fun p c' => ?_⟩
  · unfold copyRadPtToPoolStmt seqList
    exact (hs1.seq (hs2.seq hloop)).mono_cost (by omega)
  · by_cases hp : p = p_dst
    · subst hp
      rw [Function.update_self]
      exact hlt₁ c' c'.isLt
    · rw [Function.update_of_ne hp]
      exact hne₁ p c' hp

private theorem exec_detWalkStep {d D m : ℕ} (inp : UL.ArithRAMInput d)
    {P : HPJParams} (hPD : P.D = D)
    {T : Fin m → EuclideanSpace ℝ (Fin D)}
    {choice : (Fin (D + 2) → Fin m) × Fin m}
    (mem₀ : UL.ArithRAMMemory)
    (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T mem₀)
    (hIdx₀ : IdxArrStored choice mem₀) :
    ∃ mem₁,
      DetExec inp detWalkStepStmt mem₀ mem₁ (500 * (D + 3) ^ 3) ∧
      ParamsStored P mem₁ ∧
      PoolStored (radonWalkStep gaussRadonPoint T choice) mem₁ := by
  rcases exec_initGauss inp hPD mem₀ hPar₀ hPool₀ hIdx₀ with
    ⟨m1, hs1, hPar1, hPool1, hIdx1, hGauss1⟩
  rcases exec_gaussRows inp hPD m1 hPar1 hPool1 hIdx1 hGauss1 with
    ⟨m2, hs2, hPar2, hPool2, hIdx2, hGauss2⟩
  rcases exec_computeRadPt inp hPD m2 hPar2 hPool2 hIdx2 hGauss2 with
    ⟨m3, hs3, hPar3, hPool3, hIdx3, hRad3⟩
  rcases exec_copyRadPtToPool inp hPD m3 hPar3 hPool3 hIdx3 hRad3 with
    ⟨m4, hs4, hPar4, hPool4⟩
  refine ⟨m4, ?_, hPar4, hPool4⟩
  unfold detWalkStepStmt seqList
  exact (hs1.seq (hs2.seq (hs3.seq hs4))).mono_cost (cost_det_step D)

private theorem exec_phase3 {d D : ℕ} (inp : UL.ArithRAMInput d)
    {P : HPJParams} (hPD : P.D = D)
    (T₀ : Fin (2 ^ P.q) → EuclideanSpace ℝ (Fin D))
    (mem₀ : UL.ArithRAMMemory) (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T₀ mem₀) :
    RandExec inp phase3Stmt (P.L * (D + 3) * P.q) mem₀
      (fun bits m₁ =>
        ParamsStored P m₁ ∧
        PoolStored (radonWalkChoices gaussRadonPoint T₀ P.L
          (extractWalkChoices D P.q P.L bits)) m₁)
      (10 + P.L * (50 * (D + 3) * (P.q + 1) + 500 * (D + 3) ^ 3)) := by
  let K := (D + 3) * P.q
  let Inv : (s : ℕ) → (Fin (s * K) → Bool) → UL.ArithRAMMemory → Prop := fun s f m =>
    ParamsStored P m ∧
    PoolStored
      (radonWalkChoices gaussRadonPoint T₀ s
        (fun step : Fin s =>
          stepChoiceOfBits D P.q (fun j : Fin K => f ⟨step.val * K + j.val, by
            calc step.val * K + j.val < step.val * K + K := by omega
              _ = (step.val + 1) * K := by ring
              _ ≤ s * K := Nat.mul_le_mul_right K step.isLt⟩)))
      m
  have hInv₀ : ∀ f₀ : Fin (0 * K) → Bool, Inv 0 f₀ mem₀ :=
    fun _ => ⟨hPar₀, hPool₀⟩
  have hcntL : iVal inp mem₀ (wReg 1 10) = (P.L : ℤ) := hPar₀.hL
  have hloop := RandExec.repeatN_nat (wReg 1 10) (.seq sampleSlotsStmt detWalkStepStmt)
    P.L K 10 (50 * (D + 3) * (P.q + 1) + 500 * (D + 3) ^ 3)
    Inv hInv₀ hcntL (by dsimp [intExprOps, wReg]; omega)
    (fun s _ f_prev m ⟨hPar, hPool⟩ => by
      have hsample := exec_sampleSlots inp hPD m hPar hPool
      refine RandExec.seq_det_right (s₂ := detWalkStepStmt) hsample ?_
      intro f_cur m_s ⟨hPar_s, hPool_s, hIdx_s⟩
      rcases exec_detWalkStep inp hPD m_s hPar_s hPool_s hIdx_s with
        ⟨m_next, hdet, hPar_n, hPool_n⟩
      refine ⟨m_next, hdet, fun f_next hprev hcur => ?_⟩
      refine ⟨hPar_n, ?_⟩
      have hch_init :
          (fun step : Fin s =>
            stepChoiceOfBits D P.q (fun j : Fin K => f_next ⟨step.castSucc.val * K + j.val, by
              calc step.castSucc.val * K + j.val < step.castSucc.val * K + K := by omega
                _ = (step.castSucc.val + 1) * K := by ring
                _ ≤ (s + 1) * K := Nat.mul_le_mul_right K (by omega)⟩)) =
          (fun step : Fin s =>
            stepChoiceOfBits D P.q (fun j : Fin K => f_prev ⟨step.val * K + j.val, by
              calc step.val * K + j.val < step.val * K + K := by omega
                _ = (step.val + 1) * K := by ring
                _ ≤ s * K := Nat.mul_le_mul_right K step.isLt⟩)) := by
        funext step
        congr 1
        funext j
        have hlt : step.val * K + j.val < s * K := by
          calc step.val * K + j.val < step.val * K + K := by omega
            _ = (step.val + 1) * K := by ring
            _ ≤ s * K := Nat.mul_le_mul_right K step.isLt
        exact hprev ⟨step.val * K + j.val, hlt⟩
      have hch_last :
          stepChoiceOfBits D P.q (fun j : Fin K => f_next ⟨(Fin.last s).val * K + j.val, by
            calc (Fin.last s).val * K + j.val < (Fin.last s).val * K + K := by omega
              _ = ((Fin.last s).val + 1) * K := by ring
              _ ≤ (s + 1) * K := Nat.mul_le_mul_right K (Fin.last s).isLt⟩) =
          stepChoiceOfBits D P.q f_cur := by
        congr 1
        funext j
        exact hcur j
      simpa only [radonWalkChoices, hch_init, hch_last] using hPool_n)
  have hmul : P.L * K = P.L * (D + 3) * P.q := by dsimp [K]; ring
  refine RandExec.cast_bits hmul hloop ?_
  intro bits m₁ ⟨hPar₁, hPool₁⟩
  refine ⟨hPar₁, ?_⟩
  have hchoices_eq :
      (fun step : Fin P.L =>
        stepChoiceOfBits D P.q (fun j : Fin K =>
          bits ⟨step.val * K + j.val, hmul ▸ (by
            calc step.val * K + j.val < step.val * K + K := by omega
              _ = (step.val + 1) * K := by ring
              _ ≤ P.L * K := Nat.mul_le_mul_right K step.isLt)⟩)) =
      extractWalkChoices D P.q P.L bits := by
    funext step
    ext
    · rename_i a
      simp only [stepChoiceOfBits, extractWalkChoices, bitsFnToFin]
      congr 1; funext b; congr 1; ext; dsimp [K]; ring
    · simp only [stepChoiceOfBits, extractWalkChoices, bitsFnToFin]
      congr 1; funext b; congr 1; ext; dsimp [K]; ring
  rwa [hchoices_eq] at hPool₁

/-! ### 7. Phase 4 verification and main theorem `hpjProg_spec` -/

private theorem exec_phase4 {d D m : ℕ} (inp : UL.ArithRAMInput d) (hm_pos : 0 < m)
    {P : HPJParams} (hPD : P.D = D)
    (T : Fin m → EuclideanSpace ℝ (Fin D))
    (mem₀ : UL.ArithRAMMemory) (hPar₀ : ParamsStored P mem₀) (hPool₀ : PoolStored T mem₀) :
    ∃ mem₁,
      DetExec inp phase4Stmt mem₀ mem₁ (40 * (D + 2)) ∧
      (∀ c : Fin D, rRead mem₁ 0 (c.val : ℤ) = UL.euclideanCoord (T ⟨0, hm_pos⟩) c) := by
  let m1 := wWrite mem₀ 4 2 0
  have hs1 : DetExec inp (wSet 4 2 (iLit 0)) mem₀ m1 5 :=
    DetExec.writeWord inp mem₀ 4 (.lit 2) (iLit 0) rfl rfl (by dsimp [intExprOps, iLit]; omega)
  let Inv : ℕ → UL.ArithRAMMemory → Prop := fun c mc =>
    ParamsStored P mc ∧ PoolStored T mc ∧ wRead mc 4 2 = (c : ℤ) ∧
    (∀ c' : Fin D, c'.val < c →
      rRead mc 0 (c'.val : ℤ) = UL.euclideanCoord (T ⟨0, hm_pos⟩) c')
  have hPar1 : ParamsStored P m1 := paramsStored_wWrite_ne hPar₀ 4 _ _
  have hInv₀ : Inv 0 m1 :=
    ⟨hPar1, poolStored_wWrite hPool₀ 4 _ _, by simp [m1], fun _ h => by omega⟩
  have hcntD : iVal inp m1 (wReg 1 0) = (D : ℤ) := by
    change wRead m1 1 0 = _; rw [hPar1.hD, hPD]
  let outBody : UL.ArithRAMStmt :=
    .seq (rSetArr 0 (wReg 4 2) (rArr 2 (wReg 4 2))) (wSet 4 2 (.add (wReg 4 2) (iLit 1)))
  rcases DetExec.repeatN_nat (wReg 1 0) outBody D 5 30 Inv hInv₀ hcntD
    (by dsimp [intExprOps, wReg]; omega)
    (fun c hc_lt mc ⟨hParC, hPoolC, hcC, hprevC⟩ => by
      let cf : Fin D := ⟨c, hc_lt⟩
      let mc1 := rWrite mc 0 (c : ℤ) (UL.euclideanCoord (T ⟨0, hm_pos⟩) cf)
      have hsc1 : DetExec inp (rSetArr 0 (wReg 4 2) (rArr 2 (wReg 4 2))) mc mc1 15 := by
        refine DetExec.writeReal inp mc 0 (wReg 4 2) (rArr 2 (wReg 4 2)) hcC ?_
          (by dsimp [intExprOps, realExprOps, wReg, rArr]; omega)
        change rRead mc 2 (wRead mc 4 2) = _
        rw [hcC]
        simpa [cf] using hPoolC ⟨0, hm_pos⟩ cf
      let mc2 := wWrite mc1 4 2 ((c + 1 : ℕ) : ℤ)
      have hsc2 : DetExec inp (wSet 4 2 (.add (wReg 4 2) (iLit 1))) mc1 mc2 10 :=
        DetExec.writeWord inp mc1 4 (.lit 2) _ rfl (by simp -zeta [wReg, iLit, mc1, hcC])
          (by dsimp [intExprOps, wReg, iLit]; omega)
      refine ⟨mc2, (hsc1.seq hsc2).mono_cost (by omega),
        paramsStored_wWrite_ne hParC 4 _ _,
        poolStored_wWrite (poolStored_rWrite_ne hPoolC 0 _ _) 4 _ _,
        by simp [mc2], fun c' hc' => ?_⟩
      simp only [mc2, rRead_wWrite]
      by_cases hcc : c'.val = c
      · have hceq : c' = cf := Fin.ext hcc; subst hceq; simp [mc1, cf]
      · rw [rRead_rWrite_of_ne mc _ (Or.inr (by omega))]
        exact hprevC c' (by omega))
    with ⟨mem₁, ⟨_, _, _, hout₁⟩, hloop⟩
  refine ⟨mem₁, ?_, fun c => hout₁ c c.isLt⟩
  unfold phase4Stmt seqList
  exact (hs1.seq hloop).mono_cost (by omega)

private theorem total_cost_le_bound (k_d k_phi m D L q : ℕ)
    (hkd : 1 ≤ k_d) (hm : 1 ≤ m) :
    200 * (k_d + k_phi) + (10 + m * (100 * (D + 2)) +
      (10 + L * (50 * (D + 3) * (q + 1) + 500 * (D + 3) ^ 3) +
        40 * (D + 2))) ≤
    100000 * (k_d + k_phi + m * (D + 2) +
      L * ((D + 3) * (q + 1) + (D + 3) ^ 3)) := by
  have h1 : 200 * (k_d + k_phi) + 20 ≤ 100000 * (k_d + k_phi) := by omega
  have h2 : m * (100 * (D + 2)) + 40 * (D + 2) ≤ 100000 * (m * (D + 2)) := by
    have hmD : D + 2 ≤ m * (D + 2) := by simpa using Nat.mul_le_mul_right (D + 2) hm
    have hmul : m * (100 * (D + 2)) = 100 * (m * (D + 2)) := by ring
    omega
  have h3 : L * (50 * (D + 3) * (q + 1) + 500 * (D + 3) ^ 3) ≤
      100000 * (L * ((D + 3) * (q + 1) + (D + 3) ^ 3)) := by
    calc L * (50 * (D + 3) * (q + 1) + 500 * (D + 3) ^ 3)
        ≤ L * (100000 * ((D + 3) * (q + 1) + (D + 3) ^ 3)) := by
          apply Nat.mul_le_mul_left
          have : 50 * (D + 3) * (q + 1) = 50 * ((D + 3) * (q + 1)) := by ring
          omega
      _ = 100000 * (L * ((D + 3) * (q + 1) + (D + 3) ^ 3)) := by ring
  omega

open Classical in
theorem hpjProg_spec
    {d : ℕ} {φ : ℝ} (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2)
    (P : HPJParams) (hP_eq : P = hpjParams d φ) (hP : HPJParamProps d φ P)
    (ι : Type) [Fintype ι] [Nonempty ι]
    (P₀ : ι → EuclideanSpace ℝ (Fin d))
    (handle : ι ↪ ℕ)
    (N : ℕ) (hmN : 2 ^ P.q ≤ N)
    (ω : Fin N → ι) :
    let inp : UL.ArithRAMInput d :=
      { intParams := List.ofFn (fun k : Fin N => (handle (ω k) : ℤ))
        activeHandles := (Finset.univ : Finset ι).map handle
        activeCoords := fun h =>
          if hh : ∃ i : ι, handle i = h then P₀ (Classical.choose hh) else 0
        extraReals := [φ] }
    let readOutput : UL.ArithRAMExecOutcome → EuclideanSpace ℝ (Fin (d + 1)) := fun out =>
      UL.liftedPoint
        (WithLp.toLp 2 (fun j : Fin d => out.mem.reals.read (.heap 0 (j.val : ℤ))))
        (out.mem.reals.read (.heap 0 (d : ℤ)))
    (∀ bs : List Bool, bs.length ≠ P.L * (d + 1 + 3) * P.q →
      UL.runArithRAMWithBits hpjProg inp UL.ArithRAMMemory.empty bs = none) ∧
    (∀ bits : Fin (P.L * (d + 1 + 3) * P.q) → Bool,
      ∃ out : UL.ArithRAMExecOutcome,
        UL.runArithRAMWithBits hpjProg inp UL.ArithRAMMemory.empty (List.ofFn bits) = some out ∧
        (out.unitCost : ℝ) ≤ hpjOpBound d φ ∧
        readOutput out =
          radonWalkOutput (d + 1) P.q P.L
            (fun j : Fin (2 ^ P.q) =>
              UL.paraboloidLift (P₀ (ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩)))
            bits) := by
  let _ := hφ1
  intro inp readOutput
  have hPD : P.D = d + 1 := hP.1
  have h1kd : 1 ≤ P.k_d := hP.2.1
  have hm_eq : P.m = 2 ^ P.q := hP.2.2.2.2.2.2.2.1
  have hop_bnd :
      100000 * ((P.k_d + P.k_phi + P.m * (P.D + 2) +
        P.L * ((P.D + 3) * (P.q + 1) + (P.D + 3) ^ 3) : ℕ) : ℝ) ≤ hpjOpBound d φ :=
    hP.2.2.2.2.2.2.2.2.2.2.2.2.2
  let initMem := UL.ArithRAMMemory.empty.popDepth 0
  let T₀ : Fin (2 ^ P.q) → EuclideanSpace ℝ (Fin (d + 1)) := fun j =>
    UL.paraboloidLift (P₀ (ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩))
  rcases exec_phase1 hφ0 P hP_eq hP inp rfl initMem with ⟨m1, hs1, hPar1⟩
  rcases exec_phase2 hPD hm_eq P₀ handle N hmN ω m1 hPar1 with ⟨m2, hs2, hPar2, hPool2⟩
  have hs3 := exec_phase3 inp hPD T₀ m2 hPar2 hPool2
  have hs34 := RandExec.seq_det_right (s₂ := phase4Stmt) hs3
    (fun bits m3 ⟨hPar3, hPool3⟩ => by
      rcases exec_phase4 inp (Nat.two_pow_pos P.q) hPD _ m3 hPar3 hPool3 with ⟨m4, hs4, hout4⟩
      exact ⟨m4, hs4, hout4⟩)
  let C_total : ℕ :=
    100000 * (P.k_d + P.k_phi + P.m * (P.D + 2) +
      P.L * ((P.D + 3) * (P.q + 1) + (P.D + 3) ^ 3))
  have hm_pos : 1 ≤ P.m := by rw [hm_eq]; exact Nat.one_le_two_pow
  have hcost_le :
      200 * (P.k_d + P.k_phi) + (10 + P.m * (100 * (P.D + 2)) +
        (10 + P.L * (50 * (d + 1 + 3) * (P.q + 1) + 500 * (d + 1 + 3) ^ 3) +
          40 * (d + 1 + 2))) ≤ C_total := by
    dsimp only [C_total]
    rw [← hPD]
    exact total_cost_le_bound P.k_d P.k_phi P.m P.D P.L P.q h1kd hm_pos
  have hprog : RandExec inp hpjProg (P.L * (d + 1 + 3) * P.q) initMem
      (fun bits m4 =>
        ∀ c : Fin (d + 1),
          rRead m4 0 (c.val : ℤ) =
            UL.euclideanCoord (radonWalkOutput (d + 1) P.q P.L T₀ bits) c)
      C_total := by
    unfold hpjProg seqList
    exact (RandExec.seq_det_left hs1 (RandExec.seq_det_left hs2 hs34)).mono
      (fun bits m4 h => h) hcost_le
  rcases hprog.to_spec with ⟨hnone, hsome⟩
  refine ⟨hnone, fun bits => ?_⟩
  rcases hsome bits with ⟨out, hout_run, hout_cost, m4, hm4_out, hout_mem⟩
  refine ⟨out, hout_run, ?_, ?_⟩
  · have hcast : (out.unitCost : ℝ) ≤ (C_total : ℝ) := by exact_mod_cast hout_cost
    exact hcast.trans (by simpa [C_total] using hop_bnd)
  · dsimp only [readOutput]
    rw [hout_mem]
    let z := radonWalkOutput (d + 1) P.q P.L T₀ bits
    have hcoord : ∀ c : Fin (d + 1),
        (m4.popDepth 0).reals.read (.heap 0 (c.val : ℤ)) = UL.euclideanCoord z c := by
      intro c
      rw [rRead_popDepth_heap, hm4_out c]
    ext k
    refine Fin.lastCases ?_ ?_ k
    · have hlast := hcoord (Fin.last d)
      simpa [UL.liftedPoint, UL.euclideanCoord, Fin.snoc_last] using hlast
    · intro j
      have hj := hcoord j.castSucc
      simpa [UL.liftedPoint, UL.euclideanCoord, Fin.snoc_castSucc] using hj

end UL.Proof_cit_hpj19_thm18
