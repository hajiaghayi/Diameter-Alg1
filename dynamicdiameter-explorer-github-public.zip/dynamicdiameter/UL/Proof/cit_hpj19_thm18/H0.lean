import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_halfspace_depth
import UL.Def.def_paraboloid_lift_variance
set_option autoImplicit false

namespace UL.Proof_cit_hpj19_thm18

/-- Integer doubling helper matching `while p < target do { e := e + 1; p := 2 * p }`. -/
def ceilPow2From (e p target : ℕ) : ℕ × ℕ :=
  if _h : p < target ∧ 0 < p then
    ceilPow2From (e + 1) (2 * p) target
  else
    (e, p)
termination_by target - p
decreasing_by omega

/-- Smallest `k ≥ 1` such that `2 ≤ (2 : ℝ) ^ k * φ` (for `0 < φ`), matching the `ArithRAM`
doubling loop `k := 1; r := 2 * φ; while r < 2 do { k := k + 1; r := r + r }`. -/
noncomputable def ceilLog2TwoDiv (φ : ℝ) : ℕ :=
  open Classical in
  if hφ : 0 < φ then
    Nat.find (show ∃ k : ℕ, 1 ≤ k ∧ 2 ≤ (2 : ℝ) ^ k * φ by
      obtain ⟨N, hN⟩ := exists_nat_gt (2 / φ)
      refine ⟨N + 1, by omega, ?_⟩
      have hpow : ((N + 1 : ℕ) : ℝ) ≤ (2 : ℝ) ^ (N + 1) := by
        have h := Nat.lt_two_pow_self (n := N + 1)
        exact_mod_cast h.le
      have hgt : 2 / φ ≤ ((N + 1 : ℕ) : ℝ) := by
        have : (N : ℝ) < ((N + 1 : ℕ) : ℝ) := by exact_mod_cast Nat.lt_succ_self N
        linarith
      have hle : 2 / φ ≤ (2 : ℝ) ^ (N + 1) := hgt.trans hpow
      rwa [div_le_iff₀ hφ] at hle)
  else
    1

/-- Concrete integer parameters computed deterministically by the HPJ algorithm from `(d, φ)`. -/
structure HPJParams : Type where
  D : ℕ
  k_d : ℕ
  p_d : ℕ
  k_phi : ℕ
  u_d : ℕ
  pk_d : ℕ
  u_phi : ℕ
  pk_phi : ℕ
  q : ℕ
  m : ℕ
  L : ℕ
  B_total : ℕ

/-- Compute `HPJParams` for ambient base dimension `d` and failure tolerance `φ`. -/
noncomputable def hpjParams (d : ℕ) (φ : ℝ) : HPJParams :=
  let D := d + 1
  let (k_d, p_d) := ceilPow2From 1 2 (d + 2)
  let k_phi := ceilLog2TwoDiv φ
  let (u_d, pk_d) := ceilPow2From 0 1 k_d
  let (u_phi, pk_phi) := ceilPow2From 0 1 k_phi
  let q := 16 + 3 * k_d + u_d + u_phi
  let m := 65536 * p_d * p_d * p_d * pk_d * pk_phi
  let L := 3 * m * (4 * (D + 2) * q + 4 * k_phi + 16)
  let B_total := L * (D + 3) * q
  { D, k_d, p_d, k_phi, u_d, pk_d, u_phi, pk_phi, q, m, L, B_total }

/-- Target centerpoint parameter `α = 1 / (4 * (d + 3)^2)` in lifted dimension `D = d + 1`. -/
noncomputable def hpjAlpha (d : ℕ) : ℝ :=
  1 / (4 * ((d : ℝ) + 3) ^ 2)

/-- Universal operation-bound constant `C > 0` for `S_cit_hpj19_thm18`. -/
noncomputable def hpjOpConst : ℝ := (2 : ℝ) ^ 80

/-- Operation upper bound `opBound` from `S_cit_hpj19_thm18`. -/
noncomputable def hpjOpBound (d : ℕ) (φ : ℝ) : ℝ :=
  hpjOpConst * ((d : ℝ) + 1) ^ 7 * (Real.log ((d : ℝ) + 2)) ^ 3 * (Real.log (2 / φ)) ^ 3

/-- Key arithmetic properties of `P = hpjParams d φ` shared across `H1`–`H4`. -/
def HPJParamProps (d : ℕ) (φ : ℝ) (P : HPJParams) : Prop :=
  P.D = d + 1 ∧
  1 ≤ P.k_d ∧
  3 ≤ P.k_phi ∧
  16 ≤ P.q ∧
  P.p_d = 2 ^ P.k_d ∧
  P.pk_d = 2 ^ P.u_d ∧
  P.pk_phi = 2 ^ P.u_phi ∧
  P.m = 2 ^ P.q ∧
  P.L = 3 * P.m * (4 * (P.D + 2) * P.q + 4 * P.k_phi + 16) ∧
  P.B_total = P.L * (P.D + 3) * P.q ∧
  2 / φ ≤ (2 : ℝ) ^ P.k_phi ∧
  1300 * ((P.D + 2) * P.q + P.k_phi) * (P.D + 2) ^ 2 ≤ P.m ∧
  (P.m : ℝ) ≤ hpjOpBound d φ ∧
  100000 * ((P.k_d + P.k_phi + P.m * (P.D + 2) +
    P.L * ((P.D + 3) * (P.q + 1) + (P.D + 3) ^ 3) : ℕ) : ℝ) ≤ hpjOpBound d φ

/-- State of column-based Gaussian elimination on `(D + 1) × (D + 2)` affine system. -/
structure GaussState (D : ℕ) : Type where
  used : Fin (D + 2) → Bool
  v : Fin (D + 2) → Fin (D + 1) → ℝ
  c : Fin (D + 2) → Fin (D + 2) → ℝ

/-- Initial Gaussian elimination state for `pts : Fin (D + 2) → ℝ^D`. -/
noncomputable def initGaussState {D : ℕ} (pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D)) :
    GaussState D where
  used := fun _ => false
  v := fun k i =>
    if h : i.val < D then UL.euclideanCoord (pts k) ⟨i.val, h⟩ else 1
  c := fun k j => if k = j then 1 else 0

/-- Find the smallest index `k : Fin n` satisfying `P`, if any. -/
noncomputable def findFirstFin {n : ℕ} (P : Fin n → Prop) : Option (Fin n) :=
  open Classical in
  let S : Finset (Fin n) := Finset.univ.filter P
  if h : S.Nonempty then some (S.min' h) else none

/-- One row-elimination step at row `i : Fin (D + 1)` without column swaps. -/
noncomputable def gaussRowStep {D : ℕ} (st : GaussState D) (i : Fin (D + 1)) : GaussState D :=
  open Classical in
  match findFirstFin (fun k : Fin (D + 2) => st.used k = false ∧ st.v k i ≠ 0) with
  | none => st
  | some p =>
      let used' := Function.update st.used p true
      let alpha : Fin (D + 2) → ℝ := fun j => st.v j i / st.v p i
      { used := used'
        v := fun j r =>
          if used' j = false then st.v j r - alpha j * st.v p r else st.v j r
        c := fun j r =>
          if used' j = false then st.c j r - alpha j * st.c p r else st.c j r }

/-- Run `gaussRowStep` across rows `0, 1, ..., n - 1` (for `n ≤ D + 1`). -/
noncomputable def gaussRunRows {D : ℕ} (pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D)) :
    (n : ℕ) → (hn : n ≤ D + 1) → GaussState D
  | 0, _ => initGaussState pts
  | n + 1, hn => gaussRowStep (gaussRunRows pts n (by omega)) ⟨n, hn⟩

/-- Complete `(D + 1)`-row Gaussian elimination state. -/
noncomputable def gaussFinalState {D : ℕ} (pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D)) :
    GaussState D :=
  gaussRunRows pts (D + 1) le_rfl

/-- Concrete Radon point of `pts : Fin (D + 2) → ℝ^D` computed by column Gaussian elimination. -/
noncomputable def gaussRadonPoint {D : ℕ} (pts : Fin (D + 2) → EuclideanSpace ℝ (Fin D)) :
    EuclideanSpace ℝ (Fin D) :=
  let st := gaussFinalState pts
  let k_star : Fin (D + 2) :=
    match findFirstFin (fun k : Fin (D + 2) => st.used k = false) with
    | some k => k
    | none => ⟨0, by omega⟩
  let lam : Fin (D + 2) → ℝ := fun r => st.c k_star r
  let posSum : ℝ := ∑ r : Fin (D + 2), if 0 < lam r then lam r else 0
  WithLp.toLp 2 (fun coord : Fin D =>
    ∑ r : Fin (D + 2),
      if 0 < lam r then (lam r / posSum) * UL.euclideanCoord (pts r) coord else 0)

/-- MSB-first decoding of `q` bits `Fin q → Bool` into `ℕ`, matching `acc := 2 * acc + b`. -/
def bitsFnToNat : (q : ℕ) → (Fin q → Bool) → ℕ
  | 0, _ => 0
  | q + 1, f =>
      2 * bitsFnToNat q (fun i => f i.castSucc) + (if f (Fin.last q) then 1 else 0)

theorem bitsFnToNat_lt : ∀ (q : ℕ) (f : Fin q → Bool), bitsFnToNat q f < 2 ^ q
  | 0, _ => by simp [bitsFnToNat]
  | q + 1, f => by
      have ih := bitsFnToNat_lt q (fun i => f i.castSucc)
      simp only [bitsFnToNat, pow_succ]
      split_ifs <;> omega

/-- MSB-first decoding of `q` bits into `Fin (2 ^ q)`. -/
def bitsFnToFin (q : ℕ) (f : Fin q → Bool) : Fin (2 ^ q) :=
  ⟨bitsFnToNat q f, bitsFnToNat_lt q f⟩

/-- Index of `(step, slot, bit)` inside a flat bit array of length `L * (D + 3) * q`. -/
lemma bitFlatIndex_lt {L D q : ℕ} (step : Fin L) (slot : Fin (D + 3)) (bit : Fin q) :
    step.val * ((D + 3) * q) + slot.val * q + bit.val < L * (D + 3) * q := by
  have h1 : slot.val * q + bit.val < (D + 3) * q := by
    have hs : slot.val + 1 ≤ D + 3 := slot.isLt
    have hb : bit.val < q := bit.isLt
    calc
      slot.val * q + bit.val < slot.val * q + q := by omega
      _ = (slot.val + 1) * q := by ring
      _ ≤ (D + 3) * q := Nat.mul_le_mul_right q hs
  have h2 : step.val + 1 ≤ L := step.isLt
  calc
    step.val * ((D + 3) * q) + slot.val * q + bit.val
        < step.val * ((D + 3) * q) + (D + 3) * q := by omega
    _ = (step.val + 1) * ((D + 3) * q) := by ring
    _ ≤ L * ((D + 3) * q) := Nat.mul_le_mul_right _ h2
    _ = L * (D + 3) * q := by ring

/-- One step of the Har-Peled–Jones Radon random walk on pool `T : Fin m → ℝ^D`. -/
noncomputable def radonWalkStep {D m : ℕ}
    (radonFn : (Fin (D + 2) → EuclideanSpace ℝ (Fin D)) → EuclideanSpace ℝ (Fin D))
    (T : Fin m → EuclideanSpace ℝ (Fin D))
    (choice : (Fin (D + 2) → Fin m) × Fin m) :
    Fin m → EuclideanSpace ℝ (Fin D) :=
  Function.update T choice.2 (radonFn (fun a => T (choice.1 a)))

/-- Run `n` steps of the Radon walk given explicit index choices. -/
noncomputable def radonWalkChoices {D m : ℕ}
    (radonFn : (Fin (D + 2) → EuclideanSpace ℝ (Fin D)) → EuclideanSpace ℝ (Fin D))
    (T₀ : Fin m → EuclideanSpace ℝ (Fin D)) :
    (L : ℕ) → (Fin L → (Fin (D + 2) → Fin m) × Fin m) → (Fin m → EuclideanSpace ℝ (Fin D))
  | 0, _ => T₀
  | L + 1, ch =>
      radonWalkStep radonFn
        (radonWalkChoices radonFn T₀ L (fun s => ch s.castSucc))
        (ch (Fin.last L))

/-- Extract the `L` step choices from a flat bit function `Fin (L * (D + 3) * q) → Bool`. -/
def extractWalkChoices (D q L : ℕ) (bits : Fin (L * (D + 3) * q) → Bool) :
    Fin L → (Fin (D + 2) → Fin (2 ^ q)) × Fin (2 ^ q) :=
  fun step =>
    (fun a : Fin (D + 2) =>
       bitsFnToFin q (fun b : Fin q =>
         bits ⟨step.val * ((D + 3) * q) + a.val * q + b.val,
           bitFlatIndex_lt step ⟨a.val, by omega⟩ b⟩),
     bitsFnToFin q (fun b : Fin q =>
       bits ⟨step.val * ((D + 3) * q) + (D + 2) * q + b.val,
         bitFlatIndex_lt step ⟨D + 2, by omega⟩ b⟩))

/-- Full pure execution of the Radon random walk from initial pool `T₀ : Fin (2 ^ q) → ℝ^D`
consuming `bits : Fin (L * (D + 3) * q) → Bool`, returning `T_L 0`. -/
noncomputable def radonWalkOutput (D q L : ℕ)
    (T₀ : Fin (2 ^ q) → EuclideanSpace ℝ (Fin D))
    (bits : Fin (L * (D + 3) * q) → Bool) :
    EuclideanSpace ℝ (Fin D) :=
  radonWalkChoices gaussRadonPoint T₀ L (extractWalkChoices D q L bits) ⟨0, Nat.two_pow_pos q⟩

/-- Initial sample goodness: every closed halfspace with population weight `< α` wrt `Q` has
empirical weight `< 2 α` on `ω₀ : Fin m → ι`. -/
def GoodInitialSample {D m : ℕ} {ι : Type*} [Fintype ι]
    (Q : ι → EuclideanSpace ℝ (Fin D)) (α : ℝ) (ω₀ : Fin m → ι) : Prop :=
  ∀ H : Set (EuclideanSpace ℝ (Fin D)),
    UL.IsClosedHalfspace H →
    (UL.pointCount Q H : ℝ) < α * (Fintype.card ι : ℝ) →
    (UL.pointCount (fun j : Fin m => Q (ω₀ j)) H : ℝ) < 2 * α * (m : ℝ)

end UL.Proof_cit_hpj19_thm18
