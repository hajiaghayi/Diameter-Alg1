import UL.Stmt.cit_hpj19_thm18
import UL.Proof.cit_hpj19_thm18.H0
import UL.Proof.cit_hpj19_thm18.H1
import UL.Proof.cit_hpj19_thm18.H2
import UL.Proof.cit_hpj19_thm18.H3
import UL.Proof.cit_hpj19_thm18.H4
set_option autoImplicit false

namespace UL

open UL.Proof_cit_hpj19_thm18

private lemma list_ofFn_get_cast {α : Type*} (xs : List α) {B : ℕ} (hlen : xs.length = B) :
    List.ofFn (fun i : Fin B => xs.get (i.cast hlen.symm)) = xs := by
  subst hlen
  simp

private lemma tsum_list_bool_eq_sum_fin (B : ℕ) (f : List Bool → ENNReal)
    (hzero : ∀ bs : List Bool, bs.length ≠ B → f bs = 0) :
    (∑' bs : List Bool, f bs) = ∑ bits : Fin B → Bool, f (List.ofFn bits) := by
  let emb : (Fin B → Bool) ↪ List Bool := ⟨List.ofFn, fun a b h => List.ofFn_inj.mp h⟩
  rw [tsum_eq_sum (s := (Finset.univ : Finset (Fin B → Bool)).map emb)]
  · rw [Finset.sum_map]
    rfl
  · intro bs hbs
    apply hzero
    intro hlen
    apply hbs
    rw [Finset.mem_map]
    exact ⟨fun i : Fin B => bs.get (i.cast hlen.symm), Finset.mem_univ _,
      list_ofFn_get_cast bs hlen⟩

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_cit_hpj19_thm18 : S_cit_hpj19_thm18 := by
  unfold S_cit_hpj19_thm18
  classical
  refine ⟨hpjProg, hpjOpConst, by unfold hpjOpConst; positivity, ?_⟩
  intro d φ hφ0 hφ1 ι _ _ P₀ handle N opBound hN inp readOutput
  let P : HPJParams := hpjParams d φ
  let B : ℕ := P.L * (d + 1 + 3) * P.q
  have hP : HPJParamProps d φ P := hpjParams_props d hφ0 hφ1
  have hm_eq : P.m = 2 ^ P.q := hP.2.2.2.2.2.2.2.1
  have hm_le_op : (P.m : ℝ) ≤ hpjOpBound d φ := hP.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hop_eq : hpjOpBound d φ = opBound := rfl
  have hmN : 2 ^ P.q ≤ N := by
    have hceil : hpjOpBound d φ ≤ (Nat.ceil (hpjOpBound d φ) : ℝ) := Nat.le_ceil _
    have hN_real : (Nat.ceil (hpjOpBound d φ) : ℝ) ≤ (N : ℝ) := by
      rw [hop_eq]
      exact_mod_cast hN
    have hm_real : ((2 ^ P.q : ℕ) : ℝ) ≤ (N : ℝ) := by
      rw [← hm_eq]
      exact hm_le_op.trans (hceil.trans hN_real)
    exact_mod_cast hm_real
  have hspec : ∀ ω : Fin N → ι,
      (∀ bs : List Bool, bs.length ≠ B →
        runArithRAMWithBits hpjProg (inp ω) ArithRAMMemory.empty bs = none) ∧
      (∀ bits : Fin B → Bool,
        ∃ out : ArithRAMExecOutcome,
          runArithRAMWithBits hpjProg (inp ω) ArithRAMMemory.empty (List.ofFn bits) = some out ∧
          (out.unitCost : ℝ) ≤ opBound ∧
          readOutput out =
            radonWalkOutput (d + 1) P.q P.L
              (fun j : Fin (2 ^ P.q) =>
                paraboloidLift (P₀ (ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩)))
              bits) := by
    intro ω
    exact hpjProg_spec hφ0 hφ1 P rfl hP ι P₀ handle N hmN ω
  have htwo_inv_pow : ((2 : ENNReal) ^ B) * (((2 : ENNReal)⁻¹) ^ B) = 1 := by
    rw [← mul_pow, ENNReal.mul_inv_cancel (by norm_num) (by norm_num), one_pow]
  constructor
  · intro ω
    obtain ⟨hnone, hsome⟩ := hspec ω
    constructor
    · rw [tsum_list_bool_eq_sum_fin B _ (fun bs hbs => by rw [hnone bs hbs]; simp)]
      have hterm : ∀ bits : Fin B → Bool,
          (if (runArithRAMWithBits hpjProg (inp ω) ArithRAMMemory.empty (List.ofFn bits)).isSome then
            ((2 : ENNReal)⁻¹) ^ (List.ofFn bits).length
          else (0 : ENNReal)) = ((2 : ENNReal)⁻¹) ^ B := by
        intro bits
        obtain ⟨out, hout, _, _⟩ := hsome bits
        rw [hout, List.length_ofFn]
        rfl
      rw [Finset.sum_congr rfl (fun bits _ => hterm bits)]
      rw [Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_fin,
        Fintype.card_bool, nsmul_eq_mul, Nat.cast_pow, Nat.cast_ofNat]
      exact htwo_inv_pow
    · intro bs out hout
      by_cases hbs : bs.length = B
      · let bits : Fin B → Bool := fun i => bs.get (i.cast hbs.symm)
        have hbs_eq : List.ofFn bits = bs := list_ofFn_get_cast bs hbs
        obtain ⟨out', hout', hcost, _⟩ := hsome bits
        rw [hbs_eq] at hout'
        rw [hout] at hout'
        cases hout'
        exact hcost
      · rw [hnone bs hbs] at hout
        cases hout
  · let Q : ι → EuclideanSpace ℝ (Fin (d + 1)) := paraboloidLiftSet P₀
    let GoodOmega : Finset (Fin N → ι) :=
      Finset.univ.filter (fun ω : Fin N → ι =>
        GoodInitialSample Q (hpjAlpha d)
          (fun j : Fin (2 ^ P.q) => ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩))
    have hinner_ge : ∀ ω ∈ GoodOmega,
        ENNReal.ofReal (1 - φ / 2) ≤
          ∑' bs : List Bool,
            match runArithRAMWithBits hpjProg (inp ω) ArithRAMMemory.empty bs with
            | some out =>
                if IsCenterpoint (1 / (4 * ((d : ℝ) + 3) ^ 2)) (paraboloidLiftSet P₀) (readOutput out) then
                  ((2 : ENNReal)⁻¹) ^ bs.length
                else 0
            | none => 0 := by
      intro ω hω
      obtain ⟨hnone, hsome⟩ := hspec ω
      rw [tsum_list_bool_eq_sum_fin B _ (fun bs hbs => by rw [hnone bs hbs])]
      let ω₀ : Fin (2 ^ P.q) → ι := fun j => ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩
      have hGood : GoodInitialSample Q (hpjAlpha d) ω₀ := (Finset.mem_filter.mp hω).2
      have hterm : ∀ bits : Fin B → Bool,
          (match runArithRAMWithBits hpjProg (inp ω) ArithRAMMemory.empty (List.ofFn bits) with
           | some out =>
               if IsCenterpoint (1 / (4 * ((d : ℝ) + 3) ^ 2)) (paraboloidLiftSet P₀) (readOutput out) then
                 ((2 : ENNReal)⁻¹) ^ (List.ofFn bits).length
               else (0 : ENNReal)
           | none => 0) =
          if IsCenterpoint (hpjAlpha d) Q
              (radonWalkOutput (d + 1) P.q P.L (fun j => Q (ω₀ j)) bits) then
            ((2 : ENNReal)⁻¹) ^ B
          else 0 := by
        intro bits
        obtain ⟨out, hout, _, hread⟩ := hsome bits
        rw [hout]
        dsimp only
        rw [List.length_ofFn, hread]
        rfl
      rw [Finset.sum_congr rfl (fun bits _ => hterm bits)]
      let GoodBits : Finset (Fin B → Bool) :=
        Finset.univ.filter (fun bits : Fin B → Bool =>
          IsCenterpoint (hpjAlpha d) Q
            (radonWalkOutput (d + 1) P.q P.L (fun j => Q (ω₀ j)) bits))
      have hsum_filter :
          (∑ bits : Fin B → Bool,
            if IsCenterpoint (hpjAlpha d) Q
                (radonWalkOutput (d + 1) P.q P.L (fun j => Q (ω₀ j)) bits) then
              ((2 : ENNReal)⁻¹) ^ B
            else 0) =
          (GoodBits.card : ENNReal) * (((2 : ENNReal)⁻¹) ^ B) := by
        rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul]
      rw [hsum_filter]
      have hwalk_real :
          (1 - φ / 2) * ((2 : ℝ) ^ B) ≤ (GoodBits.card : ℝ) :=
        card_goodWalkBits_centerpoint_ge hφ0 hφ1 P hP
          (fun pts K hK hr => gaussRadonPoint_avoid_of_convex pts K hK hr)
          ι Q ω₀ hGood
      have hwalk_enn :
          ENNReal.ofReal ((1 - φ / 2) * ((2 : ℝ) ^ B)) ≤
            ENNReal.ofReal (GoodBits.card : ℝ) :=
        ENNReal.ofReal_le_ofReal hwalk_real
      rw [ENNReal.ofReal_mul (by linarith), ENNReal.ofReal_pow (by norm_num),
        ENNReal.ofReal_ofNat, ENNReal.ofReal_natCast] at hwalk_enn
      calc
        ENNReal.ofReal (1 - φ / 2)
            = ENNReal.ofReal (1 - φ / 2) *
                (((2 : ENNReal) ^ B) * (((2 : ENNReal)⁻¹) ^ B)) := by
              rw [htwo_inv_pow, mul_one]
        _ = (ENNReal.ofReal (1 - φ / 2) * ((2 : ENNReal) ^ B)) *
              (((2 : ENNReal)⁻¹) ^ B) := by ring
        _ ≤ (GoodBits.card : ENNReal) * (((2 : ENNReal)⁻¹) ^ B) :=
              mul_le_mul_right' hwalk_enn _
    have hsum_omega :
        (GoodOmega.card : ENNReal) * ENNReal.ofReal (1 - φ / 2) ≤
          ∑ ω : Fin N → ι,
            ∑' bs : List Bool,
              match runArithRAMWithBits hpjProg (inp ω) ArithRAMMemory.empty bs with
              | some out =>
                  if IsCenterpoint (1 / (4 * ((d : ℝ) + 3) ^ 2)) (paraboloidLiftSet P₀) (readOutput out) then
                    ((2 : ENNReal)⁻¹) ^ bs.length
                  else 0
              | none => 0 := by
      calc
        (GoodOmega.card : ENNReal) * ENNReal.ofReal (1 - φ / 2)
            = ∑ _ω ∈ GoodOmega, ENNReal.ofReal (1 - φ / 2) := by
              rw [Finset.sum_const, nsmul_eq_mul]
        _ ≤ ∑ ω ∈ GoodOmega, _ := Finset.sum_le_sum hinner_ge
        _ ≤ ∑ ω : Fin N → ι, _ :=
              Finset.sum_le_sum_of_subset (Finset.subset_univ _)
    have homega_real :
        (1 - φ / 2) * (Fintype.card (Fin N → ι) : ℝ) ≤ (GoodOmega.card : ℝ) :=
      card_goodInitialSample_prefix_ge hφ0 hφ1 P hP ι Q N hmN
    have homega_enn :
        ENNReal.ofReal (1 - φ / 2) * (Fintype.card (Fin N → ι) : ENNReal) ≤
          (GoodOmega.card : ENNReal) := by
      have h := ENNReal.ofReal_le_ofReal homega_real
      rw [ENNReal.ofReal_mul (by linarith), ENNReal.ofReal_natCast, ENNReal.ofReal_natCast] at h
      exact h
    have hcard_ne_zero : (Fintype.card (Fin N → ι) : ENNReal) ≠ 0 := by
      exact_mod_cast Fintype.card_ne_zero (α := Fin N → ι)
    have hcard_ne_top : (Fintype.card (Fin N → ι) : ENNReal) ≠ ⊤ :=
      ENNReal.natCast_ne_top _
    have hprod_le :
        ENNReal.ofReal (1 - φ) ≤
          ENNReal.ofReal (1 - φ / 2) * ENNReal.ofReal (1 - φ / 2) := by
      rw [← ENNReal.ofReal_mul (by linarith)]
      exact ENNReal.ofReal_le_ofReal (by nlinarith)
    rw [ENNReal.le_div_iff_mul_le (Or.inl hcard_ne_zero) (Or.inl hcard_ne_top)]
    calc
      ENNReal.ofReal (1 - φ) * (Fintype.card (Fin N → ι) : ENNReal)
          ≤ (ENNReal.ofReal (1 - φ / 2) * ENNReal.ofReal (1 - φ / 2)) *
              (Fintype.card (Fin N → ι) : ENNReal) :=
            mul_le_mul_right' hprod_le _
      _ = (ENNReal.ofReal (1 - φ / 2) * (Fintype.card (Fin N → ι) : ENNReal)) *
            ENNReal.ofReal (1 - φ / 2) := by ring
      _ ≤ (GoodOmega.card : ENNReal) * ENNReal.ofReal (1 - φ / 2) :=
            mul_le_mul_right' homega_enn _
      _ ≤ _ := hsum_omega

end UL
