import UL.Stmt.lem_5_4
set_option autoImplicit false

namespace UL

private lemma stored_edge_retained_estimate_bounds
    {d : ℕ} {ι : Type} (pts : ι → EuclideanSpace ℝ (Fin d))
    (e γ lam : ℚ) (K : ℤ) (V : ℝ)
    (L : ℝ) (stored : ShellConfig → Option (ι × ι)) (cfg : ShellConfig) (x y : ι)
    (hV : 0 < V)
    (hcfg : cfg ∈ retainedConfigs e γ lam K V)
    (hstored : stored cfg = some (x, y)) :
    ‖pts x - pts y‖ ≤ nodeRetainedEstimate pts e γ lam K V L stored ∧
    L ≤ nodeRetainedEstimate pts e γ lam K V L stored := by
  have hne : (retainedConfigs e γ lam K V).Nonempty := ⟨cfg, hcfg⟩
  have hcand : storedEdgeCandidate pts L (stored cfg) ≤
      nodeRetainedEstimate pts e γ lam K V L stored := by
    simp only [nodeRetainedEstimate, hV, ↓reduceIte, matchingEstimateOn, hne, ↓reduceDIte]
    exact Finset.le_sup' (fun c => storedEdgeCandidate pts L (stored c)) hcfg
  rw [hstored] at hcand
  simp only [storedEdgeCandidate, max_le_iff] at hcand
  exact ⟨hcand.2, hcand.1⟩

private lemma inwardRound_sub_center {d : ℕ} (m0 : ℕ) (hm0 : 0 < m0)
    (o p : EuclideanSpace ℝ (Fin d)) (V : ℝ) (hV : 0 < V) :
    ∃ ξ : ℝ, 0 ≤ ξ ∧ ξ ≤ 1 ∧ inwardRound m0 o V p - o = ξ • (p - o) := by
  by_cases hp : p = o
  · refine ⟨0, le_rfl, zero_le_one, ?_⟩
    subst hp
    simp [inwardRound, radialDirection]
  · have hnorm : 0 < ‖p - o‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hp)
    have hm0r : (0 : ℝ) < (m0 : ℝ) := Nat.cast_pos.mpr hm0
    have hsqrt : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV
    let j := shellIndex m0 o V p
    let rj := shellRadius m0 V j
    have hrj_nonneg : 0 ≤ rj := by
      unfold rj shellRadius
      positivity
    have hj_le : (j : ℝ) ≤ (m0 : ℝ) * ‖p - o‖ / Real.sqrt V := by
      unfold j shellIndex
      exact Nat.floor_le (by positivity)
    have hrj_le : rj ≤ ‖p - o‖ := by
      unfold rj shellRadius
      have h1 : (j : ℝ) * Real.sqrt V ≤ (m0 : ℝ) * ‖p - o‖ :=
        (le_div_iff₀ hsqrt).mp hj_le
      rw [div_mul_eq_mul_div]
      exact (div_le_iff₀ hm0r).mpr (by linarith)
    refine ⟨rj / ‖p - o‖, div_nonneg hrj_nonneg hnorm.le, (div_le_one hnorm).mpr hrj_le, ?_⟩
    unfold inwardRound radialDirection
    rw [add_sub_cancel_left, smul_smul, div_eq_mul_inv]

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_5_4 : S_lem_5_4 := by
  unfold S_lem_5_4
  intro d ι pts o V e S L hV he hL
  have hm0 : 0 < shellSubdiv e := by
    unfold shellSubdiv
    exact Nat.ceil_pos.mpr (one_div_pos.mpr he)
  have hpart1 : ∀ x ∈ S, ∀ y ∈ S,
      ‖inwardRound (shellSubdiv e) o V (pts x) - inwardRound (shellSubdiv e) o V (pts y)‖ ≤
        max (max ‖pts x - pts y‖ ‖pts x - o‖) ‖pts y - o‖ ∧
      max (max ‖pts x - pts y‖ ‖pts x - o‖) ‖pts y - o‖ ≤ max ‖pts x - pts y‖ L := by
    intro x hx y hy
    have hSne : S.Nonempty := ⟨x, hx⟩
    have hL' : 0 ≤ L ∧ L ^ 2 ≥ V + (nodeMaxRadius pts o S) ^ 2 := by
      simpa [SatisfiesBaselineLengthCond, hSne] using hL
    have hxR : ‖pts x - o‖ ≤ nodeMaxRadius pts o S := by
      simp only [nodeMaxRadius, hSne, ↓reduceDIte]
      exact Finset.le_sup' (fun i => ‖pts i - o‖) hx
    have hyR : ‖pts y - o‖ ≤ nodeMaxRadius pts o S := by
      simp only [nodeMaxRadius, hSne, ↓reduceDIte]
      exact Finset.le_sup' (fun i => ‖pts i - o‖) hy
    have hRL : nodeMaxRadius pts o S ≤ L := by
      have hRS0 : 0 ≤ nodeMaxRadius pts o S := le_trans (norm_nonneg _) hxR
      nlinarith [hL'.1, hL'.2]
    refine ⟨?_, ?_⟩
    · obtain ⟨ξ, hξ0, hξ1, hξeq⟩ := inwardRound_sub_center (shellSubdiv e) hm0 o (pts x) V hV
      obtain ⟨υ, hυ0, hυ1, hυeq⟩ := inwardRound_sub_center (shellSubdiv e) hm0 o (pts y) V hV
      have hdiff : inwardRound (shellSubdiv e) o V (pts x) - inwardRound (shellSubdiv e) o V (pts y) =
          (ξ * υ) • (pts x - pts y) + (ξ * (1 - υ)) • (pts x - o) +
            ((1 - ξ) * υ) • (o - pts y) := by
        have h1 : inwardRound (shellSubdiv e) o V (pts x) - inwardRound (shellSubdiv e) o V (pts y) =
            (inwardRound (shellSubdiv e) o V (pts x) - o) -
              (inwardRound (shellSubdiv e) o V (pts y) - o) := by abel
        rw [h1, hξeq, hυeq]
        module
      rw [hdiff]
      let M := max (max ‖pts x - pts y‖ ‖pts x - o‖) ‖pts y - o‖
      have hM1 : ‖pts x - pts y‖ ≤ M := le_trans (le_max_left _ _) (le_max_left _ _)
      have hM2 : ‖pts x - o‖ ≤ M := le_trans (le_max_right _ _) (le_max_left _ _)
      have hM3 : ‖o - pts y‖ ≤ M := by rw [norm_sub_rev]; exact le_max_right _ _
      have hM0 : 0 ≤ M := le_trans (norm_nonneg _) hM1
      have hc1 : 0 ≤ ξ * υ := mul_nonneg hξ0 hυ0
      have hc2 : 0 ≤ ξ * (1 - υ) := mul_nonneg hξ0 (sub_nonneg.mpr hυ1)
      have hc3 : 0 ≤ (1 - ξ) * υ := mul_nonneg (sub_nonneg.mpr hξ1) hυ0
      calc
        ‖(ξ * υ) • (pts x - pts y) + (ξ * (1 - υ)) • (pts x - o) + ((1 - ξ) * υ) • (o - pts y)‖
            ≤ ‖(ξ * υ) • (pts x - pts y) + (ξ * (1 - υ)) • (pts x - o)‖ +
                ‖((1 - ξ) * υ) • (o - pts y)‖ := norm_add_le _ _
        _ ≤ ‖(ξ * υ) • (pts x - pts y)‖ + ‖(ξ * (1 - υ)) • (pts x - o)‖ +
              ‖((1 - ξ) * υ) • (o - pts y)‖ := by gcongr; exact norm_add_le _ _
        _ = (ξ * υ) * ‖pts x - pts y‖ + (ξ * (1 - υ)) * ‖pts x - o‖ +
              ((1 - ξ) * υ) * ‖o - pts y‖ := by
              simp [norm_smul, Real.norm_of_nonneg hc1, Real.norm_of_nonneg hc2,
                Real.norm_of_nonneg hc3]
        _ ≤ (ξ * υ) * M + (ξ * (1 - υ)) * M + ((1 - ξ) * υ) * M := by gcongr
        _ = (1 - (1 - ξ) * (1 - υ)) * M := by ring
        _ ≤ 1 * M := by
              gcongr
              have : 0 ≤ (1 - ξ) * (1 - υ) :=
                mul_nonneg (sub_nonneg.mpr hξ1) (sub_nonneg.mpr hυ1)
              linarith
        _ = M := one_mul M
    · refine max_le (max_le (le_max_left _ _) ?_) ?_
      · exact le_trans (le_trans hxR hRL) (le_max_right _ _)
      · exact le_trans (le_trans hyR hRL) (le_max_right _ _)
  refine ⟨hpart1, ?_⟩
  intro γ lam K _ _ _ M stored hinv cfg hcfg hMne
  obtain ⟨hsub, _, hst⟩ := hinv cfg hcfg
  cases hsc : stored cfg with
  | none =>
      rw [hsc] at hst
      simp [IsStoredMatchingEdge] at hst
      exact False.elim (hMne.ne_empty hst)
  | some xy =>
      rw [hsc] at hst
      have hmem : xy ∈ M cfg := hst
      have hweak : xy ∈ configWeakEdges pts (shellSubdiv e) lam o V K S cfg.j cfg.k cfg.ℓ :=
        hsub hmem
      simp only [configWeakEdges, weakEdgesOn, Finset.mem_filter, Finset.mem_product] at hweak
      have hxS : xy.1 ∈ S := by
        have := hweak.1.1
        simp only [configLeftVertices, shellSubset, nodeCore, Finset.mem_filter] at this
        exact this.1.1
      have hyS : xy.2 ∈ S := by
        have := hweak.1.2
        simp only [configRightVertices, shellSubset, nodeEligible, Finset.mem_filter] at this
        exact this.1.1
      have hRlt : distScale lam V cfg.ℓ <
          ‖inwardRound (shellSubdiv e) o V (pts xy.1) -
            inwardRound (shellSubdiv e) o V (pts xy.2)‖ := hweak.2
      have hbnd := hpart1 xy.1 hxS xy.2 hyS
      have hest := stored_edge_retained_estimate_bounds pts e γ lam K V L stored cfg
        xy.1 xy.2 hV hcfg hsc
      have hmax_le : max ‖pts xy.1 - pts xy.2‖ L ≤
          nodeRetainedEstimate pts e γ lam K V L stored := max_le hest.1 hest.2
      exact lt_of_lt_of_le hRlt (le_trans hbnd.1 (le_trans hbnd.2 hmax_le))

end UL
