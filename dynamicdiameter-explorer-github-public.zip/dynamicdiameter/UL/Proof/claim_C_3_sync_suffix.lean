import UL.Stmt.claim_C_3_sync_suffix
import UL.Stmt.clm_5_1_chain_contraction
import UL.Stmt.lem_A_2
import UL.Stmt.claim_A_2_deletion_witness
import UL.Proof.claim_C_3_sync_suffix.RaceV31_H1
import UL.Proof.claim_C_3_sync_suffix.RaceV31_H2
import UL.Proof.claim_C_3_sync_suffix.RaceV31_H3
set_option autoImplicit false

namespace UL

open scoped ENNReal
open UL.Proof_claim_C_3_sync_suffix_v31

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_claim_C_3_sync_suffix (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction) (h_lem_A_2 : S_lem_A_2) (h_claim_A_2_deletion_witness : S_claim_A_2_deletion_witness) : S_claim_C_3_sync_suffix := by
  let _ := h_lem_A_2
  let _ := h_claim_A_2_deletion_witness
  unfold S_claim_C_3_sync_suffix
  unfold S_clm_5_1_chain_contraction at h_clm_5_1_chain_contraction
  rcases h_clm_5_1_chain_contraction with ⟨c₁, C_nodes, hc₁_pos, hCn_pos, h51⟩
  intro P_α P_node hP_α hP_α_ge_one hP_node hP_node_nonneg
  let c_chg : ℝ := 1 / 17
  let C_sum : ℝ := max 1 (1 / c₁)
  let C_charge : ℝ := C_nodes + 1
  let P_suf : ℕ → ℕ → ℕ → ℝ := fun d B L => (1 / c₁) * P_α d * P_node d B L
  let K_card : ℝ := C_sum * (C_charge / c_chg)
  let B_card : ℕ → ℕ → ℝ := fun d L => K_card * (P_α d) ^ 3 * ((L + 1 : ℝ))
  let P_tot : ℕ → ℕ → ℕ → ℝ := fun d B L => B_card d L * P_suf d B L
  have hc_chg_pos : 0 < c_chg := by norm_num [c_chg]
  have hC_sum_pos : 0 < C_sum := lt_of_lt_of_le zero_lt_one (le_max_left 1 (1 / c₁))
  have hC_charge_pos : 0 < C_charge := by dsimp only [C_charge]; linarith
  have hK_card_nn : 0 ≤ K_card := by dsimp only [K_card]; positivity
  have hPsuf_nn : ∀ d B L : ℕ, 0 ≤ P_suf d B L := by
    intro d B L
    have : 0 ≤ P_α d := by linarith [hP_α_ge_one d]
    have := hP_node_nonneg d B L
    dsimp only [P_suf]
    positivity
  have hPsuf_poly : IsBoundedByPoly3 P_suf :=
    isBoundedByPoly3_P_suf (by positivity) hP_α hP_α_ge_one hP_node hP_node_nonneg
  have hBcard_nn : ∀ d L : ℕ, 0 ≤ B_card d L := by
    intro d L
    have : 0 ≤ P_α d := by linarith [hP_α_ge_one d]
    dsimp only [B_card]
    positivity
  have hBcard_poly : IsBoundedByPoly2 B_card :=
    isBoundedByPoly2_B_card hK_card_nn hP_α hP_α_ge_one
  have hPtot_nn : ∀ d B L : ℕ, 0 ≤ P_tot d B L := fun d B L =>
    mul_nonneg (hBcard_nn d L) (hPsuf_nn d B L)
  have hPtot_poly : IsBoundedByPoly3 P_tot :=
    isBoundedByPoly3_mul_poly2_poly3 hBcard_poly hBcard_nn hPsuf_poly hPsuf_nn
  refine ⟨c_chg, C_sum, C_charge, P_suf, B_card, P_tot,
    hc_chg_pos, hC_sum_pos, hC_charge_pos,
    hPsuf_poly, hPsuf_nn, hBcard_poly, hBcard_nn, hPtot_poly, hPtot_nn, ?_⟩
  intro d B n L_leaf NodeAux α c A_n admissiblePts ctor ansPol
    _hB hn hα_pos hα_le1 hbound_α _hc hA_nn L hctor hans
  constructor
  · -- Part (1): Conditional suffix reconstruction guarantees
    intro hist ltCoords S hSn hadm
    have hall := runSyncSuffixBuild_all hc₁_pos h51 hα_pos hα_le1
      (hP_α_ge_one d) hbound_α hA_nn (hP_node_nonneg d B L) hctor hist ltCoords S hSn hadm
    refine ⟨hall.1, hall.2.1, ?_, hall.2.2.2.2.1, hall.2.2.2.2.2⟩
    intro bs sufOut hsuf
    rcases hall.2.2.1 bs sufOut hsuf with ⟨hterm, _, _, hsum, _⟩
    exact ⟨hterm, hsum⟩
  · -- Part (2): Adaptive dynamic execution guarantees
    intro adv hadv
    constructor
    · intro bitTrace prefSt hrun
      exact (runSyncScheduleSteps_invariant hc₁_pos hCn_pos h51 hn hα_pos hα_le1
        (hP_α_ge_one d) hbound_α hA_nn (hP_node_nonneg d B L) hctor hans hadv bitTrace prefSt hrun).2.2
    · intro t _ht
      -- Helper: deterministic root & chain birth cardinality bounds for any halting `t`-step `out`
      have hout_det :
          ∀ (trace : Fin t → List Bool) (out : SyncSchedulePrefixState d NodeAux),
            runSyncSchedulePrefix L_leaf α ctor ansPol adv t trace = some out →
              (∀ snap ∈ out.snapshots, IsValidFactorCAnswer c snap.1 snap.2) ∧
              (∀ rec ∈ out.triggeredSuffixes,
                c_chg * α * (rec.rootBirthCard : ℝ) ≤ (rec.chargedUpdateSteps.card : ℝ) ∧
                (rec.chainBirthCards.map (fun m => (m : ℝ))).sum ≤
                  C_sum * ((rec.rootBirthCard : ℝ) / α) ∧
                ∀ u₀ ∈ rec.chargedUpdateSteps, u₀ ≤ rec.triggerStep ∧ u₀ < t) ∧
              (∀ u₀ : ℕ, u₀ < t →
                (out.triggeredSuffixes.filter (fun rec => u₀ ∈ rec.chargedUpdateSteps)).length ≤
                  out.chainSlotCounts.getD u₀ 0 ∧
                (out.chainSlotCounts.getD u₀ 0 : ℝ) ≤
                  C_charge * α⁻¹ * Real.log (2 * (n : ℝ))) ∧
              ((out.triggeredSuffixes.map (fun rec => (rec.rootBirthCard : ℝ))).sum ≤
                (t : ℝ) * B_card d L) ∧
              ((out.triggeredSuffixes.map (fun rec =>
                (rec.chainBirthCards.map (fun m => (m : ℝ))).sum)).sum ≤
                (t : ℝ) * B_card d L) := by
        intro trace out hout
        have hinv_all := runSyncScheduleSteps_invariant hc₁_pos hCn_pos h51 hn hα_pos hα_le1
          (hP_α_ge_one d) hbound_α hA_nn (hP_node_nonneg d B L) hctor hans hadv
          (List.ofFn trace) out hout
        rcases hinv_all with ⟨hinv_out, hlen_out, _⟩
        simp only [List.length_ofFn] at hlen_out
        rcases hinv_out with ⟨_, _, _, _, _, _, hsnaps, hrecs, _, hslot_bound, hpot⟩
        have hrecs' :
            ∀ rec ∈ out.triggeredSuffixes,
              c_chg * α * (rec.rootBirthCard : ℝ) ≤ (rec.chargedUpdateSteps.card : ℝ) ∧
              (rec.chainBirthCards.map (fun m => (m : ℝ))).sum ≤
                C_sum * ((rec.rootBirthCard : ℝ) / α) ∧
              ∀ u₀ ∈ rec.chargedUpdateSteps, u₀ ≤ rec.triggerStep ∧ u₀ < t := by
          intro rec hrec
          rcases hrecs rec hrec with ⟨h1, h2, h3, h4⟩
          rw [hlen_out] at h3
          exact ⟨h1, h2, fun u₀ hu₀ => ⟨h4 u₀ hu₀, Nat.lt_of_le_of_lt (h4 u₀ hu₀) h3⟩⟩
        have hslot' :
            ∀ u₀ : ℕ, u₀ < t →
              (out.triggeredSuffixes.filter (fun rec => u₀ ∈ rec.chargedUpdateSteps)).length ≤
                out.chainSlotCounts.getD u₀ 0 ∧
              (out.chainSlotCounts.getD u₀ 0 : ℝ) ≤
                C_charge * α⁻¹ * Real.log (2 * (n : ℝ)) := by
          intro u₀ hu₀
          have hu_hist : u₀ < out.history.length := hlen_out.symm ▸ hu₀
          have hp := hpot u₀
          rw [if_pos hu_hist] at hp
          exact ⟨Nat.le_of_add_right_le hp, hslot_bound u₀ hu_hist⟩
        -- Double-count `∑_{rec} |chargedUpdateSteps|`
        have hchg_sum_nat :
            (out.triggeredSuffixes.map (fun rec => rec.chargedUpdateSteps.card)).sum =
              ∑ u₀ ∈ Finset.range t,
                (out.triggeredSuffixes.filter (fun rec => decide (u₀ ∈ rec.chargedUpdateSteps))).length :=
          list_sum_finset_card_eq_range_sum out.triggeredSuffixes (fun rec => rec.chargedUpdateSteps) t
            (fun rec hrec u₀ hu₀ => ((hrecs' rec hrec).2.2 u₀ hu₀).2)
        have hchg_sum_real :
            (out.triggeredSuffixes.map (fun rec => (rec.chargedUpdateSteps.card : ℝ))).sum ≤
              (t : ℝ) * (C_charge * α⁻¹ * Real.log (2 * (n : ℝ))) := by
          have hcast_list :
              (out.triggeredSuffixes.map (fun rec => (rec.chargedUpdateSteps.card : ℝ))).sum =
                (((out.triggeredSuffixes.map (fun rec => rec.chargedUpdateSteps.card)).sum : ℕ) : ℝ) := by
            induction out.triggeredSuffixes with
            | nil => simp
            | cons r rs ih => simp [ih]
          rw [hcast_list, hchg_sum_nat, Nat.cast_sum]
          calc (∑ u₀ ∈ Finset.range t,
                  (((out.triggeredSuffixes.filter (fun rec => decide (u₀ ∈ rec.chargedUpdateSteps))).length : ℕ) : ℝ))
              ≤ ∑ _u₀ ∈ Finset.range t, (C_charge * α⁻¹ * Real.log (2 * (n : ℝ))) := by
                refine Finset.sum_le_sum fun u₀ hu₀ => ?_
                have hu_lt : u₀ < t := Finset.mem_range.mp hu₀
                rcases hslot' u₀ hu_lt with ⟨h1, h2⟩
                have h1r :
                    (((out.triggeredSuffixes.filter (fun rec => decide (u₀ ∈ rec.chargedUpdateSteps))).length : ℕ) : ℝ) ≤
                      (out.chainSlotCounts.getD u₀ 0 : ℝ) := by exact_mod_cast h1
                exact h1r.trans h2
            _ = (t : ℝ) * (C_charge * α⁻¹ * Real.log (2 * (n : ℝ))) := by
                simp [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
        have hinv_Pα : α⁻¹ ≤ P_α d := inv_alpha_le_P_alpha hα_pos hbound_α (hP_α_ge_one d)
        have hPα_ge1 : 1 ≤ P_α d := hP_α_ge_one d
        have hlog_le : Real.log (2 * (n : ℝ)) ≤ (L + 1 : ℝ) := log_two_mul_le_clog_add_one hn
        have hlog_nn : 0 ≤ Real.log (2 * (n : ℝ)) := by
          have := one_le_log_two_mul hn
          linarith
        -- Bound `∑ rootBirthCard`
        have hroot_sum_le :
            (out.triggeredSuffixes.map (fun rec => (rec.rootBirthCard : ℝ))).sum ≤
              (t : ℝ) * ((C_charge / c_chg) * (P_α d) ^ 2 * ((L + 1 : ℝ))) := by
          have hcα_pos : 0 < c_chg * α := mul_pos hc_chg_pos hα_pos
          have hpt :
              ∀ rec ∈ out.triggeredSuffixes,
                (rec.rootBirthCard : ℝ) ≤ (1 / (c_chg * α)) * (rec.chargedUpdateSteps.card : ℝ) := by
            intro rec hrec
            have h1 := (hrecs' rec hrec).1
            rw [one_div_mul_eq_div]
            exact (le_div_iff₀' hcα_pos).mpr h1
          calc (out.triggeredSuffixes.map (fun rec => (rec.rootBirthCard : ℝ))).sum
              ≤ (out.triggeredSuffixes.map
                  (fun rec => (1 / (c_chg * α)) * (rec.chargedUpdateSteps.card : ℝ))).sum :=
                list_sum_le_of_forall_le _ _ _ hpt
            _ = (1 / (c_chg * α)) *
                  (out.triggeredSuffixes.map (fun rec => (rec.chargedUpdateSteps.card : ℝ))).sum :=
                list_sum_mul_const _ _ _
            _ ≤ (1 / (c_chg * α)) * ((t : ℝ) * (C_charge * α⁻¹ * Real.log (2 * (n : ℝ)))) :=
                mul_le_mul_of_nonneg_left hchg_sum_real (by positivity)
            _ = (t : ℝ) * ((C_charge / c_chg) * (α⁻¹ * α⁻¹) * Real.log (2 * (n : ℝ))) := by
                have hc_ne : c_chg ≠ 0 := ne_of_gt hc_chg_pos
                have hα_ne : α ≠ 0 := ne_of_gt hα_pos
                field_simp
            _ ≤ (t : ℝ) * ((C_charge / c_chg) * (P_α d * P_α d) * ((L + 1 : ℝ))) := by
                refine mul_le_mul_of_nonneg_left ?_ (Nat.cast_nonneg t)
                have hα2 : α⁻¹ * α⁻¹ ≤ P_α d * P_α d :=
                  mul_le_mul hinv_Pα hinv_Pα (by positivity) (by linarith)
                have h12 :
                    (C_charge / c_chg) * (α⁻¹ * α⁻¹) ≤ (C_charge / c_chg) * (P_α d * P_α d) :=
                  mul_le_mul_of_nonneg_left hα2 (by positivity)
                exact mul_le_mul h12 hlog_le hlog_nn (by positivity)
            _ = (t : ℝ) * ((C_charge / c_chg) * (P_α d) ^ 2 * ((L + 1 : ℝ))) := by ring
        have hPα2_le_3 : (P_α d) ^ 2 ≤ (P_α d) ^ 3 := by
          have : (P_α d) ^ 2 * 1 ≤ (P_α d) ^ 2 * P_α d :=
            mul_le_mul_of_nonneg_left hPα_ge1 (by positivity)
          linarith [show (P_α d) ^ 2 * P_α d = (P_α d) ^ 3 by ring]
        have h1_le_Csum : (1 : ℝ) ≤ C_sum := le_max_left 1 (1 / c₁)
        have hroot_Bcard :
            (out.triggeredSuffixes.map (fun rec => (rec.rootBirthCard : ℝ))).sum ≤
              (t : ℝ) * B_card d L := by
          refine hroot_sum_le.trans (mul_le_mul_of_nonneg_left ?_ (Nat.cast_nonneg t))
          dsimp only [B_card, K_card]
          have h1 :
              1 * (C_charge / c_chg) * (P_α d) ^ 2 ≤ C_sum * (C_charge / c_chg) * (P_α d) ^ 3 := by
            have ha : 1 * (C_charge / c_chg) ≤ C_sum * (C_charge / c_chg) :=
              mul_le_mul_of_nonneg_right h1_le_Csum (by positivity)
            exact mul_le_mul ha hPα2_le_3 (by positivity) (by positivity)
          have h2 := mul_le_mul_of_nonneg_right h1 (by positivity : (0 : ℝ) ≤ (L + 1 : ℝ))
          linarith
        -- Bound `∑∑ chainBirthCards`
        have hchain_Bcard :
            (out.triggeredSuffixes.map (fun rec =>
              (rec.chainBirthCards.map (fun m => (m : ℝ))).sum)).sum ≤
              (t : ℝ) * B_card d L := by
          have hpt_c :
              ∀ rec ∈ out.triggeredSuffixes,
                (rec.chainBirthCards.map (fun m => (m : ℝ))).sum ≤
                  (C_sum * α⁻¹) * (rec.rootBirthCard : ℝ) := by
            intro rec hrec
            have h2 := (hrecs' rec hrec).2.1
            calc (rec.chainBirthCards.map (fun m => (m : ℝ))).sum
                ≤ C_sum * ((rec.rootBirthCard : ℝ) / α) := h2
              _ = (C_sum * α⁻¹) * (rec.rootBirthCard : ℝ) := by ring
          calc (out.triggeredSuffixes.map (fun rec =>
                  (rec.chainBirthCards.map (fun m => (m : ℝ))).sum)).sum
              ≤ (out.triggeredSuffixes.map
                  (fun rec => (C_sum * α⁻¹) * (rec.rootBirthCard : ℝ))).sum :=
                list_sum_le_of_forall_le _ _ _ hpt_c
            _ = (C_sum * α⁻¹) *
                  (out.triggeredSuffixes.map (fun rec => (rec.rootBirthCard : ℝ))).sum :=
                list_sum_mul_const _ _ _
            _ ≤ (C_sum * α⁻¹) *
                  ((t : ℝ) * ((C_charge / c_chg) * (P_α d) ^ 2 * ((L + 1 : ℝ)))) :=
                mul_le_mul_of_nonneg_left hroot_sum_le (by positivity)
            _ ≤ (C_sum * P_α d) *
                  ((t : ℝ) * ((C_charge / c_chg) * (P_α d) ^ 2 * ((L + 1 : ℝ)))) := by
                refine mul_le_mul_of_nonneg_right
                  (mul_le_mul_of_nonneg_left hinv_Pα (by positivity)) ?_
                have : 0 ≤ P_α d := by linarith
                positivity
            _ = (t : ℝ) * B_card d L := by
                dsimp only [B_card, K_card]
                ring
        exact ⟨hsnaps, hrecs', hslot', hroot_Bcard, hchain_Bcard⟩
      -- Combine `hout_det` with `syncPrefix_prob_and_work` at `s = t`
      have hpw := syncPrefix_prob_and_work hc₁_pos hCn_pos h51 hn hα_pos hα_le1
        (hP_α_ge_one d) hbound_α hA_nn (hP_node_nonneg d B L) hctor hans hadv t
      rcases hpw with ⟨hprob_t, hwork_t⟩
      have hwork_bound_enn :
          syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv t ≤
            ENNReal.ofReal ((t : ℝ) * A_n * P_tot d B L) := by
        refine hwork_t.trans ?_
        have hpt_enn :
            ∀ tr : Fin t → List Bool,
              Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv t tr) 0
                (fun out => prefixTraceProb tr * ENNReal.ofReal (rootBirthSum out * A_n * P_suf d B L)) ≤
              (if (runSyncSchedulePrefix L_leaf α ctor ansPol adv t tr).isSome then
                 prefixTraceProb tr
               else 0) * ENNReal.ofReal ((t : ℝ) * A_n * P_tot d B L) := by
          intro tr
          cases hout_tr : runSyncSchedulePrefix L_leaf α ctor ansPol adv t tr with
          | none => simp
          | some out =>
              simp only [Option.elim_some, Option.isSome_some, ↓reduceIte]
              refine mul_le_mul_of_nonneg_left (ENNReal.ofReal_le_ofReal ?_) (zero_le _)
              have hrb : rootBirthSum out ≤ (t : ℝ) * B_card d L :=
                (hout_det tr out hout_tr).2.2.2.1
              have hPsuf_nn_d : 0 ≤ P_suf d B L := hPsuf_nn d B L
              calc rootBirthSum out * A_n * P_suf d B L
                  ≤ ((t : ℝ) * B_card d L) * A_n * P_suf d B L :=
                    mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hrb hA_nn) hPsuf_nn_d
                _ = (t : ℝ) * A_n * P_tot d B L := by
                    dsimp only [P_tot]
                    ring
        calc (∑' tr : Fin t → List Bool,
                Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv t tr) 0
                  (fun out => prefixTraceProb tr * ENNReal.ofReal (rootBirthSum out * A_n * P_suf d B L)))
            ≤ ∑' tr : Fin t → List Bool,
                (if (runSyncSchedulePrefix L_leaf α ctor ansPol adv t tr).isSome then
                   prefixTraceProb tr
                 else 0) * ENNReal.ofReal ((t : ℝ) * A_n * P_tot d B L) :=
              ENNReal.tsum_le_tsum hpt_enn
          _ = (∑' tr : Fin t → List Bool,
                if (runSyncSchedulePrefix L_leaf α ctor ansPol adv t tr).isSome then
                  prefixTraceProb tr
                else 0) * ENNReal.ofReal ((t : ℝ) * A_n * P_tot d B L) :=
              ENNReal.tsum_mul_right
          _ = ENNReal.ofReal ((t : ℝ) * A_n * P_tot d B L) := by
              rw [hprob_t, one_mul]
      have htot_nn : 0 ≤ (t : ℝ) * A_n * P_tot d B L := by
        have := hPtot_nn d B L
        positivity
      exact ⟨hout_det,
        ne_top_of_le_ne_top ENNReal.ofReal_ne_top hwork_bound_enn,
        ENNReal.toReal_le_of_le_ofReal htot_nn hwork_bound_enn⟩

end UL
