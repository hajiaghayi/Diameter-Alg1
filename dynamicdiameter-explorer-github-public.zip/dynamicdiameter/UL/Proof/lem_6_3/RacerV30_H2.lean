import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_6_search_exponents
import UL.Def.def_6_1_gaussian_filter
import UL.Proof.lem_6_3.H1_RAM
set_option autoImplicit false

namespace UL.Proof.lem_6_3.RacerV30

open UL.Proof_lem_6_3

@[simp]
theorem words_read_heap (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) :
    mem.words.read (.heap t i) = wRead mem t i := rfl

@[simp]
theorem reals_read_heap (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) :
    mem.reals.read (.heap t i) = rRead mem t i := rfl

@[simp]
theorem listGetIntD_zero {α : Type*} (a : α) (xs : List α) (d : α) :
    listGetIntD (a :: xs) 0 d = a := rfl

@[simp]
theorem listGetIntD_one {α : Type*} (a b : α) (xs : List α) (d : α) :
    listGetIntD (a :: b :: xs) 1 d = b := rfl

@[simp]
theorem toWordView_intParams {d : ℕ} (inp : ArithRAMInput d) :
    inp.toWordView.intParams = inp.intParams := rfl

/-! ### 1. Elementary exponential and search-exponent bounds -/

theorem exp_half_le_two : Real.exp (1 / 2 : ℝ) ≤ 2 := by
  have h1 : (1 / 2 : ℝ) ≤ Real.exp (-(1 / 2 : ℝ)) := by
    linarith [Real.add_one_le_exp (-(1 / 2 : ℝ))]
  have hprod : Real.exp (1 / 2 : ℝ) * Real.exp (-(1 / 2 : ℝ)) = 1 := by
    rw [← Real.exp_add]; simp
  have hpos : 0 < Real.exp (1 / 2 : ℝ) := Real.exp_pos _
  nlinarith

theorem exp_one_le_four : Real.exp 1 ≤ 4 := by
  have hsq : Real.exp 1 = Real.exp (1 / 2 : ℝ) * Real.exp (1 / 2 : ℝ) := by
    rw [← Real.exp_add]; norm_num
  have hpos : 0 ≤ Real.exp (1 / 2 : ℝ) := (Real.exp_pos _).le
  rw [hsq]
  nlinarith [exp_half_le_two]

theorem two_le_exp_one : (2 : ℝ) ≤ Real.exp 1 := by
  linarith [Real.add_one_le_exp 1]

theorem exp_le_two_pow_two_mul {z : ℝ} (M : ℕ) (hz : z ≤ (M : ℝ)) :
    Real.exp z ≤ (2 : ℝ) ^ (2 * M) := by
  calc Real.exp z ≤ Real.exp (M : ℝ) := Real.exp_le_exp.mpr hz
    _ = (Real.exp 1) ^ M := by have := Real.exp_nat_mul 1 M; simpa using this
    _ ≤ (4 : ℝ) ^ M := pow_le_pow_left₀ (Real.exp_pos 1).le exp_one_le_four M
    _ = ((2 : ℝ) ^ 2) ^ M := by norm_num
    _ = (2 : ℝ) ^ (2 * M) := (pow_mul (2 : ℝ) 2 M).symm

theorem exp_le_four_pow {z : ℝ} (M : ℕ) (hz : z ≤ (M : ℝ)) :
    Real.exp z ≤ (4 : ℝ) ^ M := by
  calc Real.exp z ≤ Real.exp (M : ℝ) := Real.exp_le_exp.mpr hz
    _ = (Real.exp 1) ^ M := by have := Real.exp_nat_mul 1 M; simpa using this
    _ ≤ (4 : ℝ) ^ M := pow_le_pow_left₀ (Real.exp_pos 1).le exp_one_le_four M

theorem nat_cast_le_two_pow (n : ℕ) : (n : ℝ) ≤ (2 : ℝ) ^ n := by
  exact_mod_cast (Nat.lt_two_pow_self (n := n)).le

theorem rpow_scale_le {E C_sc : ℝ} {m K_exp : ℕ} {α : ℝ}
    (hE0 : 0 ≤ E) (hC1 : 1 ≤ C_sc)
    (hE_ub : E ≤ C_sc * (m : ℝ)) (hα0 : 0 ≤ α) (hα_ub : α ≤ (K_exp : ℝ)) :
    E ^ α ≤ C_sc ^ K_exp * (m : ℝ) ^ α := by
  calc E ^ α ≤ (C_sc * (m : ℝ)) ^ α := Real.rpow_le_rpow hE0 hE_ub hα0
    _ = C_sc ^ α * (m : ℝ) ^ α := Real.mul_rpow (by linarith) (Nat.cast_nonneg m)
    _ ≤ C_sc ^ (K_exp : ℝ) * (m : ℝ) ^ α :=
        mul_le_mul_of_nonneg_right (Real.rpow_le_rpow_of_exponent_le hC1 hα_ub)
          (Real.rpow_nonneg (Nat.cast_nonneg m) α)
    _ = C_sc ^ K_exp * (m : ℝ) ^ α := by rw [Real.rpow_natCast]

theorem one_plus_div_pow_approx {z : ℝ} {N : ℕ} (hz : 0 ≤ z) (hN : 3 * z ^ 2 + 1 ≤ (N : ℝ)) :
    1 ≤ (1 + z / (N : ℝ)) ^ N ∧
    (1 + z / (N : ℝ)) ^ N ≤ Real.exp z ∧
    Real.exp z ≤ 2 * (1 + z / (N : ℝ)) ^ N := by
  have hN_pos : (0 : ℝ) < (N : ℝ) := by nlinarith
  have hN_ne : (N : ℝ) ≠ 0 := hN_pos.ne'
  have hbase_ge_one : 1 ≤ 1 + z / (N : ℝ) := by
    have : 0 ≤ z / (N : ℝ) := div_nonneg hz hN_pos.le
    linarith
  have h1 : 1 ≤ (1 + z / (N : ℝ)) ^ N := one_le_pow₀ hbase_ge_one
  have h2 : (1 + z / (N : ℝ)) ^ N ≤ Real.exp z := by
    calc (1 + z / (N : ℝ)) ^ N
        ≤ (Real.exp (z / (N : ℝ))) ^ N := by
          refine pow_le_pow_left₀ (by linarith) ?_ N
          linarith [Real.add_one_le_exp (z / (N : ℝ))]
      _ = Real.exp ((N : ℝ) * (z / (N : ℝ))) := (Real.exp_nat_mul _ N).symm
      _ = Real.exp z := by congr 1; field_simp
  have hz_lt_N : z < (N : ℝ) := by
    have : 0 < 3 * (z - 1 / 6) ^ 2 + 11 / 12 := by positivity
    nlinarith
  have hNmz_pos : 0 < (N : ℝ) - z := by linarith
  have h1m_pos : 0 < 1 - z / (N : ℝ) := by
    rw [sub_pos, div_lt_one hN_pos]; exact hz_lt_N
  have h1m_pow : (1 - z / (N : ℝ)) ^ N ≤ Real.exp (-z) := by
    calc (1 - z / (N : ℝ)) ^ N
        ≤ (Real.exp (-(z / (N : ℝ)))) ^ N := by
          refine pow_le_pow_left₀ h1m_pos.le ?_ N
          linarith [Real.add_one_le_exp (-(z / (N : ℝ)))]
      _ = Real.exp ((N : ℝ) * (-(z / (N : ℝ)))) := (Real.exp_nat_mul _ N).symm
      _ = Real.exp (-z) := by congr 1; field_simp
  have hexp_le_inv : Real.exp z ≤ ((N : ℝ) / ((N : ℝ) - z)) ^ N := by
    have hprod_le : Real.exp z * (1 - z / (N : ℝ)) ^ N ≤ 1 := by
      calc Real.exp z * (1 - z / (N : ℝ)) ^ N
          ≤ Real.exp z * Real.exp (-z) :=
            mul_le_mul_of_nonneg_left h1m_pow (Real.exp_pos z).le
        _ = 1 := by rw [← Real.exp_add]; simp
    have hrew : (1 - z / (N : ℝ)) = ((N : ℝ) - z) / (N : ℝ) := by field_simp
    rw [hrew, div_pow] at hprod_le
    rw [div_pow, le_div_iff₀ (pow_pos hNmz_pos N)]
    have hmul := mul_le_mul_of_nonneg_right hprod_le (pow_nonneg hN_pos.le N)
    calc Real.exp z * ((N : ℝ) - z) ^ N
        = Real.exp z * (((N : ℝ) - z) ^ N / (N : ℝ) ^ N) * (N : ℝ) ^ N := by
          field_simp [pow_ne_zero N hN_ne]
      _ ≤ 1 * (N : ℝ) ^ N := hmul
      _ = (N : ℝ) ^ N := one_mul _
  have hN2mz2_pos : 0 < (N : ℝ) ^ 2 - z ^ 2 := by nlinarith
  have hN2mz2_ge : 2 * (N : ℝ) * z ^ 2 ≤ (N : ℝ) ^ 2 - z ^ 2 := by
    have : (3 * z ^ 2 + 1) * (N : ℝ) ≤ (N : ℝ) ^ 2 := by nlinarith
    nlinarith
  have hfrac_le : z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2) ≤ 1 / (2 * (N : ℝ)) := by
    rw [div_le_div_iff₀ hN2mz2_pos (by positivity)]
    nlinarith
  have hcorr_pow : (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) ^ N ≤ 2 := by
    calc (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) ^ N
        ≤ (1 + 1 / (2 * (N : ℝ))) ^ N :=
          pow_le_pow_left₀ (by positivity) (by linarith) N
      _ ≤ (Real.exp (1 / (2 * (N : ℝ)))) ^ N := by
          refine pow_le_pow_left₀ (by positivity) ?_ N
          linarith [Real.add_one_le_exp (1 / (2 * (N : ℝ)))]
      _ = Real.exp ((N : ℝ) * (1 / (2 * (N : ℝ)))) := (Real.exp_nat_mul _ N).symm
      _ = Real.exp (1 / 2 : ℝ) := by congr 1; field_simp
      _ ≤ 2 := exp_half_le_two
  have hdecomp : (N : ℝ) / ((N : ℝ) - z) =
      (1 + z / (N : ℝ)) * (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) := by
    have hne1 : (N : ℝ) - z ≠ 0 := hNmz_pos.ne'
    have hne2 : (N : ℝ) ^ 2 - z ^ 2 ≠ 0 := hN2mz2_pos.ne'
    field_simp
    ring
  have h3 : Real.exp z ≤ 2 * (1 + z / (N : ℝ)) ^ N := by
    calc Real.exp z ≤ ((N : ℝ) / ((N : ℝ) - z)) ^ N := hexp_le_inv
      _ = (1 + z / (N : ℝ)) ^ N * (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) ^ N := by
          rw [hdecomp, mul_pow]
      _ ≤ (1 + z / (N : ℝ)) ^ N * 2 :=
          mul_le_mul_of_nonneg_left hcorr_pow (by positivity)
      _ = 2 * (1 + z / (N : ℝ)) ^ N := mul_comm _ _
  exact ⟨h1, h2, h3⟩

theorem I_h_bounds {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1) :
    1 ≤ I_h h x ∧ I_h h x ≤ 2 ∧ 0 ≤ u_search h x ∧ u_search h x ≤ 1 ∧
    0 ≤ q_search h x ∧ q_search h x ≤ 1 + u_search h x := by
  have h1mh2 : 0 < 1 - h ^ 2 := by nlinarith
  have hu_eq : u_search h x = (x - h) ^ 2 / (1 - h ^ 2) := by
    unfold u_search I_h; field_simp; ring
  have hu0 : 0 ≤ u_search h x := by rw [hu_eq]; positivity
  have hI_ge : 1 ≤ I_h h x := by unfold u_search at hu0; linarith
  have h2mI : 0 ≤ 2 - I_h h x := by
    have hrew : 2 - I_h h x = ((1 - x ^ 2) + 2 * h * (x - h)) / (1 - h ^ 2) := by
      unfold I_h; field_simp; ring
    rw [hrew]
    exact div_nonneg (by nlinarith) h1mh2.le
  have hI_le : I_h h x ≤ 2 := by linarith
  have hu_le : u_search h x ≤ 1 := by unfold u_search; linarith
  have hq_eq : q_search h x = (1 - h * x) ^ 2 / (1 - h ^ 2) := by
    unfold q_search I_h; field_simp; ring
  have hq0 : 0 ≤ q_search h x := by rw [hq_eq]; positivity
  have hq_le : q_search h x ≤ 1 + u_search h x := by
    unfold q_search u_search; nlinarith
  exact ⟨hI_ge, hI_le, hu0, hu_le, hq0, hq_le⟩

/-! ### 2. Opaque footprint step helpers for `paramStmt` -/

def paramWordList : List RAMCellLoc :=
  [.heap 0 0,
   .heap 1 0, .heap 1 1, .heap 1 2, .heap 1 3, .heap 1 4,
   .heap 11 0, .heap 11 1, .heap 11 2, .heap 11 3, .heap 11 4, .heap 11 5, .heap 11 6]

def paramRealList : List RAMCellLoc :=
  [.heap 1 0, .heap 1 1,
   .heap 17 0, .heap 17 1, .heap 17 2, .heap 17 3, .heap 17 4, .heap 17 5]

@[irreducible]
def InParamFootprint (mem : ArithRAMMemory) : Prop :=
  mem.words.live ⊆ paramWordList.toFinset ∧ mem.reals.live ⊆ paramRealList.toFinset

theorem inParamFootprint_empty : InParamFootprint ArithRAMMemory.empty := by
  unfold InParamFootprint
  exact ⟨Finset.empty_subset _, Finset.empty_subset _⟩

theorem inParamFootprint_wWrite {mem : ArithRAMMemory} (h : InParamFootprint mem)
    {t : ℕ} {idx v : ℤ} (hmem : RAMCellLoc.heap t idx ∈ paramWordList) :
    InParamFootprint (wWrite mem t idx v) := by
  unfold InParamFootprint at h ⊢
  refine ⟨?_, h.2⟩
  unfold wWrite WordStore.write
  exact Finset.insert_subset (List.mem_toFinset.mpr hmem) h.1

theorem inParamFootprint_rWrite {mem : ArithRAMMemory} (h : InParamFootprint mem)
    {t : ℕ} {idx : ℤ} {v : ℝ} (hmem : RAMCellLoc.heap t idx ∈ paramRealList) :
    InParamFootprint (rWrite mem t idx v) := by
  unfold InParamFootprint at h ⊢
  refine ⟨h.1, ?_⟩
  unfold rWrite RealStore.write
  exact Finset.insert_subset (List.mem_toFinset.mpr hmem) h.2

theorem inParamFootprint_subsets {mem : ArithRAMMemory} (h : InParamFootprint mem) :
    mem.words.live ⊆ paramWordList.toFinset ∧ mem.reals.live ⊆ paramRealList.toFinset := by
  unfold InParamFootprint at h; exact h

theorem cellCount_le_of_inParamFootprint {mem : ArithRAMMemory} (h : InParamFootprint mem) :
    mem.cellCount ≤ 21 := by
  unfold InParamFootprint at h
  have hc := cellCount_le_of_subset h.1 h.2
  have hw : paramWordList.toFinset.card ≤ 13 := by decide
  have hr : paramRealList.toFinset.card ≤ 8 := by decide
  omega

theorem wRead_zero_of_inParamFootprint {mem : ArithRAMMemory} (h : InParamFootprint mem)
    {t : ℕ} (ht : 20 ≤ t) (idx : ℤ) :
    wRead mem t idx = 0 := by
  unfold InParamFootprint at h
  unfold wRead WordStore.read
  split_ifs with hlive
  · exfalso
    have hm : RAMCellLoc.heap t idx ∈ paramWordList := List.mem_toFinset.mp (h.1 hlive)
    simp [paramWordList] at hm
    rcases hm with ⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩ <;> omega
  · rfl

theorem evalIntExpr_eq {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e : IntExpr)
    (v : ℤ) (u : ℕ)
    (hv : (evalIntExpr inp 0 ws e).1 = v)
    (hu : (evalIntExpr inp 0 ws e).2.1 = u) :
    evalIntExpr inp 0 ws e = (v, u, (evalIntExpr inp 0 ws e).2.2) := by
  cases he : evalIntExpr inp 0 ws e with
  | mk v₀ rest =>
    cases rest with
    | mk u₀ b₀ =>
      rw [he] at hv hu
      dsimp at hv hu ⊢
      rw [hv, hu]

theorem exec_ite_true {d : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {tB fB : ArithRAMStmt} {m m' : ArithRAMMemory} {C_b C : ℕ}
    (hcond : (evalArithCond inp 0 m cond).1 = true)
    (ht : ExecStmt inp tB m m' C_b)
    (hcost : (evalArithCond inp 0 m cond).2 + C_b ≤ C) :
    ExecStmt inp (.ite cond tB fB) m m' C := by
  cases he : evalArithCond inp 0 m cond with
  | mk b u_c =>
    rw [he] at hcond hcost
    dsimp at hcond hcost
    subst b
    exact (ExecStmt.ite_true he le_rfl ht).mono_cost hcost

theorem exec_ite_false {d : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {tB fB : ArithRAMStmt} {m m' : ArithRAMMemory} {C_b C : ℕ}
    (hcond : (evalArithCond inp 0 m cond).1 = false)
    (hf : ExecStmt inp fB m m' C_b)
    (hcost : (evalArithCond inp 0 m cond).2 + C_b ≤ C) :
    ExecStmt inp (.ite cond tB fB) m m' C := by
  cases he : evalArithCond inp 0 m cond with
  | mk b u_c =>
    rw [he] at hcond hcost
    dsimp at hcond hcost
    subst b
    exact (ExecStmt.ite_false he le_rfl hf).mono_cost hcost

theorem exec_repeatN {d : ℕ} {inp : ArithRAMInput d} (countE : IntExpr) (body : ArithRAMStmt)
    (N C_cnt C_b : ℕ) (Inv : ℕ → ArithRAMMemory → Prop)
    {mem₀ : ArithRAMMemory} (hc₀ : CleanMem mem₀) (hInv₀ : Inv 0 mem₀)
    (hcnt : (evalIntExpr inp.toWordView 0 mem₀.words countE).1 = (N : ℤ))
    (hucnt : (evalIntExpr inp.toWordView 0 mem₀.words countE).2.1 ≤ C_cnt)
    (hstep : ∀ i < N, ∀ m : ArithRAMMemory, CleanMem m → Inv i m →
      ∃ m', ExecStmt inp body m m' C_b ∧ Inv (i + 1) m') :
    ∃ mem_N : ArithRAMMemory,
      Inv N mem_N ∧
      ExecStmt inp (.repeatN countE body) mem₀ mem_N (C_cnt + N * C_b) := by
  have he := evalIntExpr_eq inp.toWordView mem₀.words countE (N : ℤ)
    (evalIntExpr inp.toWordView 0 mem₀.words countE).2.1 hcnt rfl
  exact ExecStmt.repeatN_nat (countE := countE) (body := body) N C_cnt C_b Inv hc₀ hInv₀ he hucnt hstep

theorem exec_wSet_fp {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (hfp : InParamFootprint mem)
    (t : ℕ) (idx : ℤ) (hmem : RAMCellLoc.heap t idx ∈ paramWordList)
    (valE : IntExpr) (val : ℤ) (C : ℕ)
    (hval : (evalIntExpr inp.toWordView 0 mem.words valE).1 = val)
    (hcost : (evalIntExpr inp.toWordView 0 mem.words valE).2.1 + 2 ≤ C) :
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp (.writeWordHeap t (.lit idx) valE) mem mem' C ∧
      InParamFootprint mem' ∧
      wRead mem' t idx = val ∧
      (∀ t' i', (t' ≠ t ∨ i' ≠ idx) → wRead mem' t' i' = wRead mem t' i') ∧
      (∀ t' i', rRead mem' t' i' = rRead mem t' i') := by
  rcases hev : evalIntExpr inp.toWordView 0 mem.words valE with ⟨v₀, u₂, b₂⟩
  have hv₀ : v₀ = val := by rw [hev] at hval; exact hval
  rw [hv₀] at hev
  have hcost' : 1 + u₂ + 1 ≤ C := by
    have hc2 : u₂ + 2 ≤ C := by rw [hev] at hcost; exact hcost
    omega
  refine ⟨wWrite mem t idx val,
    ExecStmt.writeWordHeap inp hc t (.lit idx) valE rfl hev hcost',
    inParamFootprint_wWrite hfp hmem,
    wRead_wWrite_self mem t idx val,
    fun t' i' hne => wRead_wWrite_of_ne mem val hne,
    fun _ _ => rfl⟩

theorem exec_rSet_fp {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (hfp : InParamFootprint mem)
    (t : ℕ) (idx : ℤ) (hmem : RAMCellLoc.heap t idx ∈ paramRealList)
    (valE : RealExpr) (val : ℝ) (C : ℕ)
    (hval : (evalRealExpr inp 0 mem valE).1 = val)
    (hcost : (evalRealExpr inp 0 mem valE).2 + 2 ≤ C) :
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp (.writeRealHeap t (.lit idx) valE) mem mem' C ∧
      InParamFootprint mem' ∧
      rRead mem' t idx = val ∧
      (∀ t' i', wRead mem' t' i' = wRead mem t' i') ∧
      (∀ t' i', (t' ≠ t ∨ i' ≠ idx) → rRead mem' t' i' = rRead mem t' i') := by
  rcases hev : evalRealExpr inp 0 mem valE with ⟨v₀, u₂⟩
  have hv₀ : v₀ = val := by rw [hev] at hval; exact hval
  rw [hv₀] at hev
  have hcost' : 1 + u₂ + 1 ≤ C := by
    have hc2 : u₂ + 2 ≤ C := by rw [hev] at hcost; exact hcost
    omega
  refine ⟨rWrite mem t idx val,
    ExecStmt.writeRealHeap inp hc t (.lit idx) valE rfl hev hcost',
    inParamFootprint_rWrite hfp hmem,
    rRead_rWrite_self mem t idx val,
    fun _ _ => rfl,
    fun t' i' hne => rRead_rWrite_of_ne mem val hne⟩

/-! ### 3. Subroutines `pow1PlusZStmt` and `boundedDoublingStmt` -/

def pow1PlusZStmt : ArithRAMStmt :=
  .seq (.writeRealHeap 17 (.lit 1) (.ofInt (.lit 1)))
    (.repeatN (.readHeap 11 (.lit 2))
      (.writeRealHeap 17 (.lit 1)
        (.mul (.readRealHeap 17 (.lit 1))
          (.add (.ofInt (.lit 1))
            (.div (.readRealHeap 17 (.lit 0)) (.ofInt (.readHeap 11 (.lit 2))))))))

theorem exec_pow1PlusZStmt {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (hfp : InParamFootprint mem) {N : ℕ}
    (hN : wRead mem 11 2 = (N : ℤ)) :
    let z := rRead mem 17 0
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp pow1PlusZStmt mem mem' (10 + N * 14) ∧
      InParamFootprint mem' ∧
      (∀ t i, wRead mem' t i = wRead mem t i) ∧
      (∀ t i, (t ≠ 17 ∨ i ≠ 1) → rRead mem' t i = rRead mem t i) ∧
      rRead mem' 17 1 = (1 + z / (N : ℝ)) ^ N := by
  intro z
  rcases exec_rSet_fp inp hc hfp 17 1 (by decide) (.ofInt (.lit 1)) 1 4
    (by simp [evalRealExpr, evalIntExpr]) (by simp [evalRealExpr, evalIntExpr]) with
    ⟨m₀, hs₁, hfp₀, hr₀_self, hw₀, hr₀_ne⟩
  let body : ArithRAMStmt :=
    .writeRealHeap 17 (.lit 1)
      (.mul (.readRealHeap 17 (.lit 1))
        (.add (.ofInt (.lit 1))
          (.div (.readRealHeap 17 (.lit 0)) (.ofInt (.readHeap 11 (.lit 2))))))
  let Inv : ℕ → ArithRAMMemory → Prop := fun i m =>
    InParamFootprint m ∧
    (∀ t idx, wRead m t idx = wRead mem t idx) ∧
    (∀ t idx, (t ≠ 17 ∨ idx ≠ 1) → rRead m t idx = rRead mem t idx) ∧
    rRead m 17 1 = (1 + z / (N : ℝ)) ^ i
  have hInv₀ : Inv 0 m₀ := ⟨hfp₀, hw₀, hr₀_ne, by simpa using hr₀_self⟩
  have hw_N₀ : wRead m₀ 11 2 = (N : ℤ) := (hw₀ 11 2).trans hN
  rcases exec_repeatN (.readHeap 11 (.lit 2)) body N 5 14 Inv hs₁.2.1 hInv₀
    (by simp [evalIntExpr, hw_N₀]) (by simp [evalIntExpr])
    (fun i _ m hcm ⟨hfpm, hwm, hrm, hval⟩ => by
      have hz_eq : rRead m 17 0 = z := hrm 17 0 (Or.inr (by decide))
      have hN_eq : wRead m 11 2 = (N : ℤ) := (hwm 11 2).trans hN
      rcases exec_rSet_fp inp hcm hfpm 17 1 (by decide)
        (.mul (.readRealHeap 17 (.lit 1))
          (.add (.ofInt (.lit 1))
            (.div (.readRealHeap 17 (.lit 0)) (.ofInt (.readHeap 11 (.lit 2))))))
        ((1 + z / (N : ℝ)) ^ (i + 1)) 14
        (by simp [evalRealExpr, evalIntExpr, hz_eq, hN_eq, hval, pow_succ])
        (by simp [evalRealExpr, evalIntExpr]) with
        ⟨m', hs', hfp', hr'_self, hw', hr'_ne⟩
      exact ⟨m', hs', hfp',
        fun t idx => (hw' t idx).trans (hwm t idx),
        fun t idx hne => (hr'_ne t idx hne).trans (hrm t idx hne),
        hr'_self⟩) with
    ⟨mem', ⟨hfp', hw', hr', hpow'⟩, hrep⟩
  have htot : ExecStmt inp pow1PlusZStmt mem mem' (10 + N * 14) := by
    unfold pow1PlusZStmt
    exact (ExecStmt.seq hs₁ hrep).mono_cost (by omega)
  exact ⟨mem', htot, hfp', hw', hr', hpow'⟩

def boundedDoublingStmt (tbl : ℕ) (idx : ℤ) (initVal : ℤ) (rIdx : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap tbl (.lit idx) (.lit initVal))
    (.repeatN (.readHeap 11 (.lit 6))
      (.ite (.realLt (.ofInt (.readHeap tbl (.lit idx))) (.readRealHeap 17 (.lit rIdx)))
        (.writeWordHeap tbl (.lit idx) (.mul (.lit 2) (.readHeap tbl (.lit idx))))
        .skip))

theorem exec_boundedDoublingStmt {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (hfp : InParamFootprint mem)
    (tbl : ℕ) (idx : ℤ) (htbl_ne : tbl ≠ 11 ∨ idx ≠ 6)
    (hmem_loc : RAMCellLoc.heap tbl idx ∈ paramWordList)
    (initNat : ℕ) (hinit : 1 ≤ initNat) (rIdx : ℤ)
    {B : ℕ} (hB : wRead mem 11 6 = (B : ℤ))
    (htarget_ub : rRead mem 17 rIdx ≤ (initNat : ℝ) * (2 : ℝ) ^ B) :
    let target := rRead mem 17 rIdx
    ∃ (mem' : ArithRAMMemory) (val : ℕ),
      ExecStmt inp (boundedDoublingStmt tbl idx (initNat : ℤ) rIdx) mem mem' (10 + B * 16) ∧
      InParamFootprint mem' ∧
      initNat ≤ val ∧
      target ≤ (val : ℝ) ∧
      (val : ℝ) ≤ max (initNat : ℝ) (2 * target) ∧
      wRead mem' tbl idx = (val : ℤ) ∧
      (∀ t' i', (t' ≠ tbl ∨ i' ≠ idx) → wRead mem' t' i' = wRead mem t' i') ∧
      (∀ t' i', rRead mem' t' i' = rRead mem t' i') := by
  intro target
  rcases exec_wSet_fp inp hc hfp tbl idx hmem_loc (.lit (initNat : ℤ)) (initNat : ℤ) 3
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m₀, hs₁, hfp₀, hw₀_self, hw₀_ne, hr₀⟩
  let cond : ArithCondExpr :=
    .realLt (.ofInt (.readHeap tbl (.lit idx))) (.readRealHeap 17 (.lit rIdx))
  let body : ArithRAMStmt :=
    .ite cond (.writeWordHeap tbl (.lit idx) (.mul (.lit 2) (.readHeap tbl (.lit idx)))) .skip
  let Inv : ℕ → ArithRAMMemory → Prop := fun i m =>
    InParamFootprint m ∧
    (∀ t' i', (t' ≠ tbl ∨ i' ≠ idx) → wRead m t' i' = wRead mem t' i') ∧
    (∀ t' i', rRead m t' i' = rRead mem t' i') ∧
    ∃ v : ℕ, initNat ≤ v ∧
      wRead m tbl idx = (v : ℤ) ∧
      (v : ℝ) ≤ max (initNat : ℝ) (2 * target) ∧
      min target ((initNat : ℝ) * (2 : ℝ) ^ i) ≤ (v : ℝ)
  have hInv₀ : Inv 0 m₀ :=
    ⟨hfp₀, hw₀_ne, hr₀, initNat, le_rfl, hw₀_self, le_max_left _ _, by simp⟩
  have hB₀ : wRead m₀ 11 6 = (B : ℤ) := by
    refine (hw₀_ne 11 6 ?_).trans hB
    rcases htbl_ne with h1 | h2
    · exact Or.inl h1.symm
    · exact Or.inr h2.symm
  rcases exec_repeatN (.readHeap 11 (.lit 6)) body B 5 16 Inv hs₁.2.1 hInv₀
    (by simp [evalIntExpr, hB₀]) (by simp [evalIntExpr])
    (fun i _ m hcm ⟨hfpm, hwm, hrm, v, hv_ge, hv_eq, hv_ub, hv_lb⟩ => by
      have htar_m : rRead m 17 rIdx = target := hrm 17 rIdx
      by_cases hlt : (v : ℝ) < target
      · rcases exec_wSet_fp inp hcm hfpm tbl idx hmem_loc
          (.mul (.lit 2) (.readHeap tbl (.lit idx))) (((2 * v : ℕ) : ℤ)) 10
          (by simp [evalIntExpr, hv_eq]) (by simp [evalIntExpr]) with
          ⟨m', hw_step, hfp', hw'_self, hw'_ne, hr'⟩
        have hite : ExecStmt inp body m m' 16 :=
          exec_ite_true (fB := .skip)
            (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr, hv_eq, htar_m, hlt])
            hw_step (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr])
        refine ⟨m', hite, hfp',
          fun t' i' hne => (hw'_ne t' i' hne).trans (hwm t' i' hne),
          fun t' i' => (hr' t' i').trans (hrm t' i'),
          2 * v, by omega, hw'_self, ?_, ?_⟩
        · push_cast
          exact (mul_le_mul_of_nonneg_left hlt.le (by norm_num)).trans (le_max_right _ _)
        · push_cast
          have hpow_lt : (initNat : ℝ) * (2 : ℝ) ^ i ≤ (v : ℝ) := by
            by_cases htm : target ≤ (initNat : ℝ) * (2 : ℝ) ^ i
            · rw [min_eq_left htm] at hv_lb
              linarith
            · push_neg at htm
              rwa [min_eq_right htm.le] at hv_lb
          have hpow_succ : (initNat : ℝ) * (2 : ℝ) ^ (i + 1) ≤ 2 * (v : ℝ) := by
            rw [pow_succ]; linarith
          exact (min_le_right _ _).trans hpow_succ
      · have hge : target ≤ (v : ℝ) := not_lt.mp hlt
        have hite : ExecStmt inp body m m 16 :=
          exec_ite_false (tB := .writeWordHeap tbl (.lit idx) (.mul (.lit 2) (.readHeap tbl (.lit idx))))
            (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr, hv_eq, htar_m, hlt])
            (ExecStmt.skip inp hcm) (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr])
        exact ⟨m, hite, hfpm, hwm, hrm, v, hv_ge, hv_eq, hv_ub,
          (min_le_left _ _).trans hge⟩) with
    ⟨mem', ⟨hfp', hw', hr', val, hval_ge, hval_eq, hval_ub, hval_lb⟩, hrep⟩
  have hmin_eq : min target ((initNat : ℝ) * (2 : ℝ) ^ B) = target := min_eq_left htarget_ub
  rw [hmin_eq] at hval_lb
  have htot : ExecStmt inp (boundedDoublingStmt tbl idx (initNat : ℤ) rIdx) mem mem' (10 + B * 16) := by
    unfold boundedDoublingStmt
    exact (ExecStmt.seq hs₁ hrep).mono_cost (by omega)
  exact ⟨mem', val, htot, hfp', hval_ge, hval_lb, hval_ub, hval_eq, hw', hr'⟩

/-! ### 4. Program definitions and irreducible parameter sizes for `paramStmt` -/

@[irreducible]
def paramN (ℓ L : ℕ) : ℕ := 3 * ℓ * ℓ * (L + 2) ^ 4 + 1

@[irreducible]
def paramBMax (ℓ C_base L : ℕ) : ℕ := (ℓ + 1) * (C_base + 4 + 4 * (L + 2) ^ 2)

@[irreducible]
def paramEr1 (C_base L : ℕ) : ℕ := C_base + 4 * (L + 2) ^ 2

theorem paramN_def (ℓ L : ℕ) : paramN ℓ L = 3 * ℓ * ℓ * (L + 2) ^ 4 + 1 := by
  unfold paramN; rfl

theorem paramBMax_def (ℓ C_base L : ℕ) :
    paramBMax ℓ C_base L = (ℓ + 1) * (C_base + 4 + 4 * (L + 2) ^ 2) := by
  unfold paramBMax; rfl

theorem paramEr1_def (C_base L : ℕ) : paramEr1 C_base L = C_base + 4 * (L + 2) ^ 2 := by
  unfold paramEr1; rfl

theorem three_z_sq_le_paramN {ℓ L : ℕ} {z : ℝ} (hz0 : 0 ≤ z)
    (hz : z ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2) :
    3 * z ^ 2 + 1 ≤ (paramN ℓ L : ℝ) := by
  rw [paramN_def]
  push_cast
  have hsq : z ^ 2 ≤ ((ℓ : ℝ) * (L + 2 : ℝ) ^ 2) ^ 2 :=
    pow_le_pow_left₀ hz0 hz 2
  have hexp : ((ℓ : ℝ) * (L + 2 : ℝ) ^ 2) ^ 2 = (ℓ : ℝ) * (ℓ : ℝ) * (L + 2 : ℝ) ^ 4 := by ring
  rw [hexp] at hsq
  linarith

theorem three_z1_sq_le_paramN {ℓ L : ℕ} (hℓ : 1 ≤ ℓ) {z : ℝ} (hz0 : 0 ≤ z)
    (hz : z ≤ (L + 2 : ℝ) ^ 2) :
    3 * z ^ 2 + 1 ≤ (paramN ℓ L : ℝ) := by
  refine three_z_sq_le_paramN hz0 ?_
  have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
  calc z ≤ 1 * (L + 2 : ℝ) ^ 2 := by linarith
    _ ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := mul_le_mul_of_nonneg_right hℓ1 (by positivity)

theorem paramEr1_le_paramBMax (ℓ C_base L : ℕ) :
    paramEr1 C_base L ≤ paramBMax ℓ C_base L := by
  rw [paramEr1_def, paramBMax_def]
  have h1 : 1 * (C_base + 4 + 4 * (L + 2) ^ 2) ≤ (ℓ + 1) * (C_base + 4 + 4 * (L + 2) ^ 2) :=
    Nat.mul_le_mul_right _ (by omega)
  omega

theorem mul_er1_succ_le_paramBMax (ℓ C_base L : ℕ) :
    ℓ * (paramEr1 C_base L + 1) + 1 ≤ paramBMax ℓ C_base L := by
  rw [paramEr1_def, paramBMax_def]
  set X := 4 * (L + 2) ^ 2
  calc ℓ * (C_base + X + 1) + 1
      ≤ ℓ * (C_base + 4 + X) + (C_base + 4 + X) := by
        have : C_base + X + 1 ≤ C_base + 4 + X := by omega
        have hm : ℓ * (C_base + X + 1) ≤ ℓ * (C_base + 4 + X) := Nat.mul_le_mul_left ℓ this
        omega
    _ = (ℓ + 1) * (C_base + 4 + X) := by ring

def stepP1Stmt : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 1 (.lit 0) (.intParam (.lit 0)),
      .writeWordHeap 11 (.lit 0) (.readHeap 1 (.lit 0)),
      .writeWordHeap 11 (.lit 1) (.lit 0),
      .whileLoop (.intLt (.lit 0) (.readHeap 11 (.lit 0)))
        (.seq
          (.writeWordHeap 11 (.lit 0) (.div (.readHeap 11 (.lit 0)) (.lit 2)))
          (.writeWordHeap 11 (.lit 1) (.add (.readHeap 11 (.lit 1)) (.lit 1)))) ]

def bPlus2SqExpr : IntExpr :=
  let bp2 := IntExpr.add (.readHeap 11 (.lit 1)) (.lit 2)
  .mul bp2 bp2

def stepP2Stmt (ℓ C_base : ℕ) : ArithRAMStmt :=
  let bp2sq := bPlus2SqExpr
  let bp2pow4 := IntExpr.mul bp2sq bp2sq
  let nExpr := IntExpr.add (.mul (.lit ((3 * ℓ * ℓ : ℕ) : ℤ)) bp2pow4) (.lit 1)
  let denomExpr := IntExpr.mul (.lit (ℓ : ℤ)) (.readHeap 11 (.lit 1))
  let bMaxExpr :=
    IntExpr.mul (.lit ((ℓ + 1 : ℕ) : ℤ))
      (.add (.lit ((C_base + 4 : ℕ) : ℤ)) (.mul (.lit 4) bp2sq))
  let kMaxExpr :=
    IntExpr.mul (.mul (.lit (ℓ : ℤ)) (.readHeap 11 (.lit 1)))
      (.add (.readHeap 11 (.lit 1)) (.lit 1))
  let zFromT : RealExpr :=
    .div (.mul (.ofInt (.lit (ℓ : ℤ)))
      (.mul (.readRealHeap 1 (.lit 0)) (.readRealHeap 1 (.lit 0)))) (.ofInt (.lit 2))
  seqStmts
    [ .writeWordHeap 11 (.lit 2) nExpr,
      .writeWordHeap 11 (.lit 3) denomExpr,
      .writeWordHeap 11 (.lit 6) bMaxExpr,
      .writeWordHeap 11 (.lit 4) (.lit 0),
      .writeRealHeap 1 (.lit 0) (.ofInt (.lit 1)),
      .writeRealHeap 17 (.lit 0) zFromT,
      pow1PlusZStmt,
      .writeRealHeap 17 (.lit 2) (.readRealHeap 17 (.lit 1)),
      .repeatN kMaxExpr
        (.ite
          (.realLt (.readRealHeap 17 (.lit 2))
            (.mul (.ofInt (.lit 2)) (.ofInt (.readHeap 1 (.lit 0)))))
          (seqStmts
            [ .writeWordHeap 11 (.lit 4) (.add (.readHeap 11 (.lit 4)) (.lit 1)),
              .writeRealHeap 1 (.lit 0)
                (.add (.ofInt (.lit 1))
                  (.div (.ofInt (.readHeap 11 (.lit 4))) (.ofInt (.readHeap 11 (.lit 3))))),
              .writeRealHeap 17 (.lit 0) zFromT,
              pow1PlusZStmt,
              .writeRealHeap 17 (.lit 2) (.readRealHeap 17 (.lit 1)) ])
          .skip) ]

def stepP3Stmt (ℓ C_base : ℕ) : ArithRAMStmt :=
  let hE := RealExpr.extraReal (.lit 0)
  let xE := RealExpr.extraReal (.lit 1)
  let tE := RealExpr.readRealHeap 1 (.lit 0)
  let iExpr : RealExpr :=
    .div
      (.sub (.add (.ofInt (.lit 1)) (.mul xE xE)) (.mul (.mul (.ofInt (.lit 2)) hE) xE))
      (.sub (.ofInt (.lit 1)) (.mul hE hE))
  let z1Expr : RealExpr := .div (.mul iExpr (.mul tE tE)) (.ofInt (.lit 2))
  let r1Expr : RealExpr :=
    .mul (.mul (.ofInt (.lit (C_base : ℤ))) (.mul tE tE)) (.readRealHeap 17 (.lit 1))
  let zqExpr : RealExpr :=
    .div (.mul (.ofInt (.lit (ℓ : ℤ))) (.mul (.mul xE xE) (.mul tE tE))) (.ofInt (.lit 2))
  seqStmts
    [ .writeRealHeap 1 (.lit 1) (.mul xE tE),
      .writeRealHeap 17 (.lit 0) z1Expr,
      pow1PlusZStmt,
      .writeRealHeap 17 (.lit 3) r1Expr,
      boundedDoublingStmt 1 1 1 3,
      .writeWordHeap 1 (.lit 2) (.mul (.lit (ℓ : ℤ)) (.readHeap 1 (.lit 1))),
      .writeWordHeap 0 (.lit 0) (.readHeap 1 (.lit 2)),
      .writeWordHeap 11 (.lit 5) (.lit 1),
      .repeatN (.lit (ℓ : ℤ))
        (.writeWordHeap 11 (.lit 5)
          (.mul (.readHeap 11 (.lit 5)) (.readHeap 1 (.lit 1)))),
      .writeRealHeap 17 (.lit 4)
        (.mul (.ofInt (.lit 100))
          (.add (.div (.ofInt (.readHeap 11 (.lit 5))) (.readRealHeap 17 (.lit 2)))
            (.ofInt (.lit 1)))),
      boundedDoublingStmt 1 3 100 4,
      .writeRealHeap 17 (.lit 0) zqExpr,
      pow1PlusZStmt,
      .writeRealHeap 17 (.lit 5)
        (.mul (.ofInt (.lit 100))
          (.add (.div (.ofInt (.readHeap 11 (.lit 5))) (.readRealHeap 17 (.lit 1)))
            (.ofInt (.lit 1)))),
      boundedDoublingStmt 1 4 100 5 ]

def buildParamStmt (ℓ C_base : ℕ) : ArithRAMStmt :=
  .seq stepP1Stmt (.seq (stepP2Stmt ℓ C_base) (stepP3Stmt ℓ C_base))

/-! ### 5. Execution proofs for `stepP1`, `stepP2`, `stepP3` -/

theorem exec_stepP1Stmt {d : ℕ} (m : ℕ) (hm : 1 ≤ m) (h x : ℝ) :
    let inp : ArithRAMInput d :=
      { intParams := [(m : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0, extraReals := [h, x] }
    let L := natBitLength m
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp stepP1Stmt ArithRAMMemory.empty mem₁ (20 + 18 * L) ∧
      InParamFootprint mem₁ ∧
      wRead mem₁ 1 0 = (m : ℤ) ∧
      wRead mem₁ 11 1 = (L : ℤ) := by
  intro inp L
  rcases exec_wSet_fp inp cleanMem_empty inParamFootprint_empty 1 0 (by decide)
    (.intParam (.lit 0)) (m : ℤ) 4
    (by simp [inp, evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m1, hs1, hfp1, hw1_m, _, _⟩
  rcases exec_wSet_fp inp hs1.2.1 hfp1 11 0 (by decide)
    (.readHeap 1 (.lit 0)) (m : ℤ) 4
    (by simp [evalIntExpr, hw1_m]) (by simp [evalIntExpr]) with
    ⟨m2, hs2, hfp2, hw2_cur, hw2_ne, _⟩
  rcases exec_wSet_fp inp hs2.2.1 hfp2 11 1 (by decide)
    (.lit 0) 0 3
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m3, hs3, hfp3, hw3_b, hw3_ne, _⟩
  let cond : ArithCondExpr := .intLt (.lit 0) (.readHeap 11 (.lit 0))
  let wbody : ArithRAMStmt :=
    .seq (.writeWordHeap 11 (.lit 0) (.div (.readHeap 11 (.lit 0)) (.lit 2)))
      (.writeWordHeap 11 (.lit 1) (.add (.readHeap 11 (.lit 1)) (.lit 1)))
  let Inv : ℕ → ArithRAMMemory → Prop := fun i mem =>
    InParamFootprint mem ∧
    wRead mem 1 0 = (m : ℤ) ∧
    wRead mem 11 0 = ((m / 2 ^ i : ℕ) : ℤ) ∧
    wRead mem 11 1 = (i : ℤ)
  have hInv₀ : Inv 0 m3 := by
    refine ⟨hfp3, ?_, ?_, hw3_b⟩
    · exact (hw3_ne 1 0 (Or.inl (by decide))).trans ((hw2_ne 1 0 (Or.inl (by decide))).trans hw1_m)
    · simpa using (hw3_ne 11 0 (Or.inr (by decide))).trans hw2_cur
  rcases ExecStmt.whileLoop_nat (cond := cond) (body := wbody) L 5 12 Inv hs3.2.1 hInv₀
    (fun i hi mem hcm ⟨hfpm, hwm, hcur, hb⟩ => by
      have hpow_le : 2 ^ i ≤ m := by
        have hi_le : i ≤ Nat.log 2 m := by unfold L natBitLength at hi; omega
        exact (Nat.pow_le_pow_right (by decide) hi_le).trans (Nat.pow_log_le_self 2 (by omega))
      have hdiv_pos : 0 < m / 2 ^ i := Nat.div_pos hpow_le (by positivity)
      have hdiv_pos_z : (0 : ℤ) < ((m / 2 ^ i : ℕ) : ℤ) := by exact_mod_cast hdiv_pos
      have hcond : evalArithCond inp 0 mem cond = (true, 4) := by
        simp only [cond, evalArithCond, evalIntExpr, words_read_heap, hcur]
        exact Prod.ext (decide_eq_true hdiv_pos_z) rfl
      have hdiv_step : (((m / 2 ^ i : ℕ) : ℤ) / 2) = ((m / 2 ^ (i + 1) : ℕ) : ℤ) := by
        have hnat : (m / 2 ^ i) / 2 = m / 2 ^ (i + 1) := by
          rw [Nat.div_div_eq_div_mul, ← pow_succ]
        rw [← hnat]
        exact_mod_cast (Int.natCast_div (m / 2 ^ i) 2)
      rcases exec_wSet_fp inp hcm hfpm 11 0 (by decide)
        (.div (.readHeap 11 (.lit 0)) (.lit 2)) ((m / 2 ^ (i + 1) : ℕ) : ℤ) 6
        (by simpa [evalIntExpr, hcur] using hdiv_step) (by simp [evalIntExpr]) with
        ⟨ma, hb1, hfpa, hwa_cur, hwa_ne, _⟩
      have hba : wRead ma 11 1 = (i : ℤ) := (hwa_ne 11 1 (Or.inr (by decide))).trans hb
      rcases exec_wSet_fp inp hb1.2.1 hfpa 11 1 (by decide)
        (.add (.readHeap 11 (.lit 1)) (.lit 1)) (((i + 1 : ℕ) : ℤ)) 6
        (by simp [evalIntExpr, hba]) (by simp [evalIntExpr]) with
        ⟨mb, hb2, hfpb, hwb_b, hwb_ne, _⟩
      refine ⟨⟨4, hcond, by omega⟩, ⟨mb, ExecStmt.seq hb1 hb2, hfpb, ?_, ?_, hwb_b⟩⟩
      · exact (hwb_ne 1 0 (Or.inl (by decide))).trans ((hwa_ne 1 0 (Or.inl (by decide))).trans hwm)
      · exact (hwb_ne 11 0 (Or.inr (by decide))).trans hwa_cur)
    (fun mem _ ⟨_, _, hcur, _⟩ => by
      have hlt : m < 2 ^ L := Nat.lt_pow_succ_log_self (by decide) m
      have hdiv0 : m / 2 ^ L = 0 := Nat.div_eq_of_lt hlt
      have hcur0 : wRead mem 11 0 = 0 := by simpa [hdiv0] using hcur
      exact ⟨4, by simp [cond, evalArithCond, evalIntExpr, hcur0], by omega⟩) with
    ⟨mem₁, ⟨hfp₁, hwm₁, _, hb₁⟩, hwhile⟩
  have htot : ExecStmt inp stepP1Stmt ArithRAMMemory.empty mem₁ (20 + 18 * L) := by
    unfold stepP1Stmt seqStmts
    exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 (ExecStmt.seq hs3 hwhile))).mono_cost (by omega)
  exact ⟨mem₁, htot, hfp₁, hwm₁, hb₁⟩

theorem exec_stepP2Stmt {d : ℕ} (ℓ C_base : ℕ) (hℓ : 1 ≤ ℓ) (m : ℕ) (hm : 1 ≤ m) (h x : ℝ)
    {mem₁ : ArithRAMMemory} :
    let inp : ArithRAMInput d :=
      { intParams := [(m : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0, extraReals := [h, x] }
    let L : ℕ := natBitLength m
    let N : ℕ := paramN ℓ L
    let B_max : ℕ := paramBMax ℓ C_base L
    let kMax : ℕ := ℓ * L * (L + 1)
    CleanMem mem₁ →
    InParamFootprint mem₁ →
    wRead mem₁ 1 0 = (m : ℤ) →
    wRead mem₁ 11 1 = (L : ℤ) →
    ∃ (mem₂ : ArithRAMMemory) (t F_u : ℝ),
      ExecStmt inp (stepP2Stmt ℓ C_base) mem₁ mem₂
        (120 + 14 * N + kMax * (70 + 14 * N)) ∧
      InParamFootprint mem₂ ∧
      1 ≤ t ∧ t ≤ (L + 2 : ℝ) ∧
      F_u = (1 + ((ℓ : ℝ) * t ^ 2 / 2) / (N : ℝ)) ^ N ∧
      2 * (m : ℝ) ≤ F_u ∧
      Real.exp ((ℓ : ℝ) * t ^ 2 / 2) ≤ (4 : ℝ) ^ (ℓ + 5) * (m : ℝ) ∧
      wRead mem₂ 1 0 = (m : ℤ) ∧
      wRead mem₂ 11 2 = (N : ℤ) ∧
      wRead mem₂ 11 6 = (B_max : ℤ) ∧
      rRead mem₂ 1 0 = t ∧
      rRead mem₂ 17 2 = F_u := by
  intro inp L N B_max kMax hc₁ hfp₁ hwm₁ hwL₁
  have hL_pos : 1 ≤ L := by unfold L natBitLength; omega
  let denom : ℕ := ℓ * L
  have hdenom_pos : 1 ≤ denom := Nat.mul_pos (by omega) (by omega)
  let tSeq : ℕ → ℝ := fun k => 1 + (k : ℝ) / (denom : ℝ)
  let zSeq : ℕ → ℝ := fun k => ((ℓ : ℝ) * (tSeq k) ^ 2) / 2
  let FSeq : ℕ → ℝ := fun k => (1 + zSeq k / (N : ℝ)) ^ N

  let bp2sq := bPlus2SqExpr
  let bp2pow4 := IntExpr.mul bp2sq bp2sq
  let nExpr := IntExpr.add (.mul (.lit ((3 * ℓ * ℓ : ℕ) : ℤ)) bp2pow4) (.lit 1)
  let denomExpr := IntExpr.mul (.lit (ℓ : ℤ)) (.readHeap 11 (.lit 1))
  let bMaxExpr :=
    IntExpr.mul (.lit ((ℓ + 1 : ℕ) : ℤ))
      (.add (.lit ((C_base + 4 : ℕ) : ℤ)) (.mul (.lit 4) bp2sq))
  let kMaxExpr :=
    IntExpr.mul (.mul (.lit (ℓ : ℤ)) (.readHeap 11 (.lit 1)))
      (.add (.readHeap 11 (.lit 1)) (.lit 1))
  let zFromT : RealExpr :=
    .div (.mul (.ofInt (.lit (ℓ : ℤ)))
      (.mul (.readRealHeap 1 (.lit 0)) (.readRealHeap 1 (.lit 0)))) (.ofInt (.lit 2))

  have hn_val : (evalIntExpr inp.toWordView 0 mem₁.words nExpr).1 = (N : ℤ) := by
    have hL' : wRead mem₁ 11 1 = (natBitLength m : ℤ) := hwL₁
    have hN' : (N : ℤ) = ((3 * ℓ * ℓ * (natBitLength m + 2) ^ 4 + 1 : ℕ) : ℤ) := by
      change ((paramN ℓ (natBitLength m) : ℕ) : ℤ) = _
      rw [paramN_def]
    rw [hN']
    simp only [nExpr, bp2pow4, bp2sq, bPlus2SqExpr, evalIntExpr, words_read_heap, hL']
    push_cast
    ring
  rcases exec_wSet_fp inp hc₁ hfp₁ 11 2 (by decide) nExpr (N : ℤ) 26
    hn_val
    (by simp [nExpr, bp2pow4, bp2sq, bPlus2SqExpr, evalIntExpr]) with
    ⟨ma1, hs1, hfp_a1, hwa1_N, hwa1_ne, _⟩
  have hwa1_L : wRead ma1 11 1 = (L : ℤ) := (hwa1_ne 11 1 (Or.inr (by decide))).trans hwL₁
  have hwa1_m : wRead ma1 1 0 = (m : ℤ) := (hwa1_ne 1 0 (Or.inl (by decide))).trans hwm₁

  rcases exec_wSet_fp inp hs1.2.1 hfp_a1 11 3 (by decide) denomExpr (denom : ℤ) 10
    (by simp [denomExpr, evalIntExpr, hwa1_L, denom])
    (by simp [denomExpr, evalIntExpr]) with
    ⟨ma2, hs2, hfp_a2, hwa2_d, hwa2_ne, _⟩
  have hwa2_L : wRead ma2 11 1 = (L : ℤ) := (hwa2_ne 11 1 (Or.inr (by decide))).trans hwa1_L
  have hwa2_N : wRead ma2 11 2 = (N : ℤ) := (hwa2_ne 11 2 (Or.inr (by decide))).trans hwa1_N
  have hwa2_m : wRead ma2 1 0 = (m : ℤ) := (hwa2_ne 1 0 (Or.inl (by decide))).trans hwa1_m

  have hb_val : (evalIntExpr inp.toWordView 0 ma2.words bMaxExpr).1 = (B_max : ℤ) := by
    have hL' : wRead ma2 11 1 = (natBitLength m : ℤ) := hwa2_L
    have hB' : (B_max : ℤ) = (((ℓ + 1) * (C_base + 4 + 4 * (natBitLength m + 2) ^ 2) : ℕ) : ℤ) := by
      change ((paramBMax ℓ C_base (natBitLength m) : ℕ) : ℤ) = _
      rw [paramBMax_def]
    rw [hB']
    simp only [bMaxExpr, bp2sq, bPlus2SqExpr, evalIntExpr, words_read_heap, hL']
    push_cast
    ring
  rcases exec_wSet_fp inp hs2.2.1 hfp_a2 11 6 (by decide) bMaxExpr (B_max : ℤ) 20
    hb_val
    (by simp [bMaxExpr, bp2sq, bPlus2SqExpr, evalIntExpr]) with
    ⟨ma3, hs3, hfp_a3, hwa3_B, hwa3_ne, _⟩
  have hwa3_L : wRead ma3 11 1 = (L : ℤ) := (hwa3_ne 11 1 (Or.inr (by decide))).trans hwa2_L
  have hwa3_N : wRead ma3 11 2 = (N : ℤ) := (hwa3_ne 11 2 (Or.inr (by decide))).trans hwa2_N
  have hwa3_d : wRead ma3 11 3 = (denom : ℤ) := (hwa3_ne 11 3 (Or.inr (by decide))).trans hwa2_d
  have hwa3_m : wRead ma3 1 0 = (m : ℤ) := (hwa3_ne 1 0 (Or.inl (by decide))).trans hwa2_m

  rcases exec_wSet_fp inp hs3.2.1 hfp_a3 11 4 (by decide) (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨ma4, hs4, hfp_a4, hwa4_k, hwa4_ne, _⟩
  have hwa4_L : wRead ma4 11 1 = (L : ℤ) := (hwa4_ne 11 1 (Or.inr (by decide))).trans hwa3_L
  have hwa4_N : wRead ma4 11 2 = (N : ℤ) := (hwa4_ne 11 2 (Or.inr (by decide))).trans hwa3_N
  have hwa4_d : wRead ma4 11 3 = (denom : ℤ) := (hwa4_ne 11 3 (Or.inr (by decide))).trans hwa3_d
  have hwa4_B : wRead ma4 11 6 = (B_max : ℤ) := (hwa4_ne 11 6 (Or.inr (by decide))).trans hwa3_B
  have hwa4_m : wRead ma4 1 0 = (m : ℤ) := (hwa4_ne 1 0 (Or.inl (by decide))).trans hwa3_m

  rcases exec_rSet_fp inp hs4.2.1 hfp_a4 1 0 (by decide) (.ofInt (.lit 1)) (tSeq 0) 5
    (by simp [evalRealExpr, evalIntExpr, tSeq]) (by simp [evalRealExpr, evalIntExpr]) with
    ⟨ma5, hs5, hfp_a5, hra5_t, hwa5, _⟩

  rcases exec_rSet_fp inp hs5.2.1 hfp_a5 17 0 (by decide) zFromT (zSeq 0) 15
    (by simp [zFromT, evalRealExpr, evalIntExpr, hra5_t, zSeq, sq])
    (by simp [zFromT, evalRealExpr, evalIntExpr]) with
    ⟨ma6, hs6, hfp_a6, hra6_z, hwa6, hra6_ne⟩
  have hwa6_N : wRead ma6 11 2 = (N : ℤ) := (hwa6 11 2).trans ((hwa5 11 2).trans hwa4_N)

  rcases exec_pow1PlusZStmt inp hs6.2.1 hfp_a6 hwa6_N with
    ⟨ma7, hs7, hfp_a7, hwa7, hra7_ne, hra7_F⟩
  rw [hra6_z] at hra7_F

  rcases exec_rSet_fp inp hs7.2.1 hfp_a7 17 2 (by decide)
    (.readRealHeap 17 (.lit 1)) (FSeq 0) 5
    (by simp [evalRealExpr, evalIntExpr, hra7_F, FSeq])
    (by simp [evalRealExpr, evalIntExpr]) with
    ⟨ma8, hs8, hfp_a8, hra8_F, hwa8, hra8_ne⟩

  have hwa8_all : ∀ t' i', wRead ma8 t' i' = wRead ma4 t' i' := fun t' i' =>
    (hwa8 t' i').trans ((hwa7 t' i').trans ((hwa6 t' i').trans (hwa5 t' i')))
  have hra8_t : rRead ma8 1 0 = tSeq 0 :=
    (hra8_ne 1 0 (Or.inl (by decide))).trans
      ((hra7_ne 1 0 (Or.inl (by decide))).trans
        ((hra6_ne 1 0 (Or.inl (by decide))).trans hra5_t))

  let cond : ArithCondExpr :=
    .realLt (.readRealHeap 17 (.lit 2)) (.mul (.ofInt (.lit 2)) (.ofInt (.readHeap 1 (.lit 0))))
  let tBranch : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 4) (.add (.readHeap 11 (.lit 4)) (.lit 1)),
        .writeRealHeap 1 (.lit 0)
          (.add (.ofInt (.lit 1))
            (.div (.ofInt (.readHeap 11 (.lit 4))) (.ofInt (.readHeap 11 (.lit 3))))),
        .writeRealHeap 17 (.lit 0) zFromT,
        pow1PlusZStmt,
        .writeRealHeap 17 (.lit 2) (.readRealHeap 17 (.lit 1)) ]
  let rBody : ArithRAMStmt := .ite cond tBranch .skip

  let Inv : ℕ → ArithRAMMemory → Prop := fun i mem =>
    InParamFootprint mem ∧
    wRead mem 1 0 = (m : ℤ) ∧
    wRead mem 11 2 = (N : ℤ) ∧
    wRead mem 11 3 = (denom : ℤ) ∧
    wRead mem 11 6 = (B_max : ℤ) ∧
    ∃ k : ℕ, k ≤ i ∧
      wRead mem 11 4 = (k : ℤ) ∧
      rRead mem 1 0 = tSeq k ∧
      rRead mem 17 2 = FSeq k ∧
      (k = 0 ∨ FSeq (k - 1) < 2 * (m : ℝ)) ∧
      (k = i ∨ 2 * (m : ℝ) ≤ FSeq k)

  have hInv₀ : Inv 0 ma8 :=
    ⟨hfp_a8, (hwa8_all 1 0).trans hwa4_m, (hwa8_all 11 2).trans hwa4_N,
      (hwa8_all 11 3).trans hwa4_d, (hwa8_all 11 6).trans hwa4_B,
      0, le_rfl, (hwa8_all 11 4).trans hwa4_k, hra8_t, hra8_F, Or.inl rfl, Or.inl rfl⟩

  have hwa8_L : wRead ma8 11 1 = (L : ℤ) := (hwa8_all 11 1).trans hwa4_L

  rcases exec_repeatN kMaxExpr rBody kMax 12 (70 + 14 * N) Inv hs8.2.1 hInv₀
    (by simp [kMaxExpr, evalIntExpr, hwa8_L, kMax])
    (by simp [kMaxExpr, evalIntExpr])
    (fun i _ mem hcm ⟨hfpm, hwm, hwN, hwd, hwB, k, hki, hwk, hrt, hrF, hprev, hstop⟩ => by
      by_cases hlt : FSeq k < 2 * (m : ℝ)
      · have hki_eq : k = i := by
          rcases hstop with rfl | hge
          · rfl
          · linarith
        rcases exec_wSet_fp inp hcm hfpm 11 4 (by decide)
          (.add (.readHeap 11 (.lit 4)) (.lit 1)) (((k + 1 : ℕ) : ℤ)) 6
          (by simp [evalIntExpr, hwk]) (by simp [evalIntExpr]) with
          ⟨mb1, hb1, hfp_b1, hwb1_k, hwb1_ne, _⟩
        have hwb1_d : wRead mb1 11 3 = (denom : ℤ) := (hwb1_ne 11 3 (Or.inr (by decide))).trans hwd
        rcases exec_rSet_fp inp hb1.2.1 hfp_b1 1 0 (by decide)
          (.add (.ofInt (.lit 1))
            (.div (.ofInt (.readHeap 11 (.lit 4))) (.ofInt (.readHeap 11 (.lit 3)))))
          (tSeq (k + 1)) 12
          (by simp [evalRealExpr, evalIntExpr, hwb1_k, hwb1_d, tSeq])
          (by simp [evalRealExpr, evalIntExpr]) with
          ⟨mb2, hb2, hfp_b2, hrb2_t, hwb2, _⟩
        rcases exec_rSet_fp inp hb2.2.1 hfp_b2 17 0 (by decide) zFromT (zSeq (k + 1)) 15
          (by simp [zFromT, evalRealExpr, evalIntExpr, hrb2_t, zSeq, sq])
          (by simp [zFromT, evalRealExpr, evalIntExpr]) with
          ⟨mb3, hb3, hfp_b3, hrb3_z, hwb3, hrb3_ne⟩
        have hwb3_N : wRead mb3 11 2 = (N : ℤ) :=
          (hwb3 11 2).trans ((hwb2 11 2).trans ((hwb1_ne 11 2 (Or.inr (by decide))).trans hwN))
        rcases exec_pow1PlusZStmt inp hb3.2.1 hfp_b3 hwb3_N with
          ⟨mb4, hb4, hfp_b4, hwb4, hrb4_ne, hrb4_F⟩
        rw [hrb3_z] at hrb4_F
        rcases exec_rSet_fp inp hb4.2.1 hfp_b4 17 2 (by decide)
          (.readRealHeap 17 (.lit 1)) (FSeq (k + 1)) 5
          (by simp [evalRealExpr, evalIntExpr, hrb4_F, FSeq])
          (by simp [evalRealExpr, evalIntExpr]) with
          ⟨mb5, hb5, hfp_b5, hrb5_F, hwb5, hrb5_ne⟩
        have hwb5_all : ∀ t' i', wRead mb5 t' i' = wRead mb1 t' i' := fun t' i' =>
          (hwb5 t' i').trans ((hwb4 t' i').trans ((hwb3 t' i').trans (hwb2 t' i')))
        have htB : ExecStmt inp tBranch mem mb5 (50 + 14 * N) := by
          unfold tBranch seqStmts
          exact (ExecStmt.seq hb1 (ExecStmt.seq hb2 (ExecStmt.seq hb3 (ExecStmt.seq hb4 hb5)))).mono_cost
            (by omega)
        have hite : ExecStmt inp rBody mem mb5 (70 + 14 * N) :=
          exec_ite_true (fB := .skip)
            (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr, hrF, hwm, hlt])
            htB (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr]; omega)
        refine ⟨mb5, hite, hfp_b5,
          (hwb5_all 1 0).trans ((hwb1_ne 1 0 (Or.inl (by decide))).trans hwm),
          (hwb5_all 11 2).trans ((hwb1_ne 11 2 (Or.inr (by decide))).trans hwN),
          (hwb5_all 11 3).trans hwb1_d,
          (hwb5_all 11 6).trans ((hwb1_ne 11 6 (Or.inr (by decide))).trans hwB),
          k + 1, by omega,
          (hwb5_all 11 4).trans hwb1_k,
          (hrb5_ne 1 0 (Or.inl (by decide))).trans
            ((hrb4_ne 1 0 (Or.inl (by decide))).trans
              ((hrb3_ne 1 0 (Or.inl (by decide))).trans hrb2_t)),
          hrb5_F,
          Or.inr (by simpa using hlt),
          Or.inl (by omega)⟩
      · have hge : 2 * (m : ℝ) ≤ FSeq k := not_lt.mp hlt
        have hite : ExecStmt inp rBody mem mem (70 + 14 * N) :=
          exec_ite_false (tB := tBranch)
            (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr, hrF, hwm, hlt])
            (ExecStmt.skip inp hcm)
            (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr]; omega)
        exact ⟨mem, hite, hfpm, hwm, hwN, hwd, hwB, k, by omega, hwk, hrt, hrF,
          hprev, Or.inr hge⟩) with
    ⟨mem₂, ⟨hfp₂, hwm₂, hwN₂, _, hwB₂, k, hk_le, _, hrt₂, hrF₂, hprev, hstop⟩, hrep⟩

  have ht_bounds : ∀ j ≤ kMax, 1 ≤ tSeq j ∧ tSeq j ≤ (L + 2 : ℝ) := by
    intro j hj
    have hd_pos : (0 : ℝ) < (denom : ℝ) := by exact_mod_cast hdenom_pos
    have h1 : 1 ≤ tSeq j := by
      dsimp [tSeq]; linarith [div_nonneg (Nat.cast_nonneg j) hd_pos.le]
    have h2 : tSeq j ≤ (L + 2 : ℝ) := by
      dsimp [tSeq]
      have hj_le : (j : ℝ) ≤ (denom : ℝ) * (L + 1 : ℝ) := by
        have : j ≤ denom * (L + 1) := by simpa [denom, kMax] using hj
        exact_mod_cast this
      have hdiv : (j : ℝ) / (denom : ℝ) ≤ (L + 1 : ℝ) := (div_le_iff₀ hd_pos).mpr (by linarith)
      linarith
    exact ⟨h1, h2⟩

  have hz_approx : ∀ j ≤ kMax,
      1 ≤ FSeq j ∧ FSeq j ≤ Real.exp (zSeq j) ∧ Real.exp (zSeq j) ≤ 2 * FSeq j := by
    intro j hj
    rcases ht_bounds j hj with ⟨ht1, ht2⟩
    have hz_nonneg : 0 ≤ zSeq j := by dsimp [zSeq]; positivity
    have hz_le : zSeq j ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := by
      dsimp [zSeq]
      have hsq : (tSeq j) ^ 2 ≤ (L + 2 : ℝ) ^ 2 :=
        pow_le_pow_left₀ (by linarith) ht2 2
      have hmul : (ℓ : ℝ) * (tSeq j) ^ 2 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 :=
        mul_le_mul_of_nonneg_left hsq (Nat.cast_nonneg ℓ)
      have hnn : 0 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := by positivity
      linarith
    exact one_plus_div_pow_approx hz_nonneg (three_z_sq_le_paramN hz_nonneg hz_le)

  have hFu_ge : 2 * (m : ℝ) ≤ FSeq k := by
    rcases hstop with rfl | hge
    · have ht_kMax : tSeq kMax = (L + 2 : ℝ) := by
        dsimp [tSeq, kMax, denom]
        have h1 : (ℓ : ℝ) ≠ 0 := by positivity
        have h2 : (L : ℝ) ≠ 0 := by positivity
        push_cast; field_simp; ring
      have hz_ge : (L + 2 : ℝ) ≤ zSeq kMax := by
        dsimp [zSeq]
        rw [ht_kMax]
        have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
        have hLp2_ge2 : (2 : ℝ) ≤ (L + 2 : ℝ) := by
          have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
          linarith
        have hsq : 2 * (L + 2 : ℝ) ≤ (L + 2 : ℝ) ^ 2 := by
          rw [sq]; exact mul_le_mul_of_nonneg_right hLp2_ge2 (by linarith)
        have hmul : 1 * (2 * (L + 2 : ℝ)) ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 :=
          mul_le_mul hℓ1 hsq (by linarith) (by linarith)
        linarith
      have hexp_ge : 4 * (m : ℝ) ≤ Real.exp (zSeq kMax) := by
        have hm_lt : (m : ℝ) ≤ (2 : ℝ) ^ L :=
          by exact_mod_cast (Nat.lt_pow_succ_log_self (by decide) m).le
        have h2L : (2 : ℝ) ^ L ≤ Real.exp (L : ℝ) := by
          calc (2 : ℝ) ^ L ≤ (Real.exp 1) ^ L := pow_le_pow_left₀ (by norm_num) two_le_exp_one L
            _ = Real.exp (L : ℝ) := by simp [← Real.exp_nat_mul]
        have hexp2 : (4 : ℝ) ≤ Real.exp 2 := by
          have h2eq : Real.exp 2 = Real.exp 1 * Real.exp 1 := by rw [← Real.exp_add]; norm_num
          rw [h2eq]
          calc (4 : ℝ) = 2 * 2 := by norm_num
            _ ≤ Real.exp 1 * Real.exp 1 :=
              mul_le_mul two_le_exp_one two_le_exp_one (by norm_num) (Real.exp_pos 1).le
        calc 4 * (m : ℝ) ≤ 4 * (2 : ℝ) ^ L := by linarith
          _ ≤ Real.exp 2 * Real.exp (L : ℝ) :=
              mul_le_mul hexp2 h2L (by positivity) (Real.exp_pos 2).le
          _ = Real.exp ((L + 2 : ℝ)) := by rw [← Real.exp_add]; congr 1; ring
          _ ≤ Real.exp (zSeq kMax) := Real.exp_le_exp.mpr hz_ge
      linarith [(hz_approx kMax le_rfl).2.2]
    · exact hge

  have hexp_ub : Real.exp (zSeq k) ≤ (4 : ℝ) ^ (ℓ + 5) * (m : ℝ) := by
    by_cases hk0 : k = 0
    · subst hk0
      have hz0 : zSeq 0 ≤ (ℓ : ℝ) := by
        dsimp [zSeq, tSeq]; simp
      have hexp0 : Real.exp (zSeq 0) ≤ (4 : ℝ) ^ ℓ := exp_le_four_pow ℓ hz0
      have hpow_le : (4 : ℝ) ^ ℓ ≤ (4 : ℝ) ^ (ℓ + 5) :=
        pow_le_pow_right₀ (by norm_num) (by omega)
      have hm1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
      calc Real.exp (zSeq 0) ≤ (4 : ℝ) ^ ℓ := hexp0
        _ ≤ (4 : ℝ) ^ (ℓ + 5) := hpow_le
        _ ≤ (4 : ℝ) ^ (ℓ + 5) * (m : ℝ) := le_mul_of_one_le_right (by positivity) hm1
    · have hk_pos : 1 ≤ k := by omega
      have hprev_lt : FSeq (k - 1) < 2 * (m : ℝ) := by
        rcases hprev with rfl | hlt
        · exact absurd rfl hk0
        · exact hlt
      have hkm1_le : k - 1 ≤ kMax := by omega
      have hexp_prev : Real.exp (zSeq (k - 1)) ≤ 4 * (m : ℝ) := by
        linarith [(hz_approx (k - 1) hkm1_le).2.2]
      have hdiff_le : zSeq k - zSeq (k - 1) ≤ 4 := by
        have hk_cast : (k : ℝ) = ((k - 1 : ℕ) : ℝ) + 1 := by
          have : k - 1 + 1 = k := by omega
          exact_mod_cast this.symm
        have ht_step : tSeq k = tSeq (k - 1) + 1 / (denom : ℝ) := by
          dsimp [tSeq]; rw [hk_cast]; ring
        have ht_prev_ub : tSeq (k - 1) ≤ 3 * (L : ℝ) := by
          have h1 := (ht_bounds (k - 1) hkm1_le).2
          have hL1 : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast hL_pos
          linarith
        have hstep_id : zSeq k - zSeq (k - 1) =
            (ℓ : ℝ) * (tSeq (k - 1)) / (denom : ℝ) + (ℓ : ℝ) / (2 * (denom : ℝ) ^ 2) := by
          dsimp [zSeq]; rw [ht_step]; ring
        have hd_eq : (denom : ℝ) = (ℓ : ℝ) * (L : ℝ) := by dsimp [denom]; push_cast; rfl
        have hterm1 : (ℓ : ℝ) * (tSeq (k - 1)) / (denom : ℝ) ≤ 3 := by
          rw [hd_eq, div_le_iff₀ (by positivity)]
          calc (ℓ : ℝ) * tSeq (k - 1)
              ≤ (ℓ : ℝ) * (3 * (L : ℝ)) := mul_le_mul_of_nonneg_left ht_prev_ub (Nat.cast_nonneg ℓ)
            _ = 3 * ((ℓ : ℝ) * (L : ℝ)) := by ring
        have hterm2 : (ℓ : ℝ) / (2 * (denom : ℝ) ^ 2) ≤ 1 := by
          rw [hd_eq, div_le_iff₀ (by positivity)]
          have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
          have hL1 : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast hL_pos
          have hp : (ℓ : ℝ) * 1 ≤ (ℓ : ℝ) * ((ℓ : ℝ) * (L : ℝ) ^ 2) :=
            mul_le_mul_of_nonneg_left
              (one_le_mul_of_one_le_of_one_le hℓ1 (one_le_pow₀ hL1)) (Nat.cast_nonneg ℓ)
          have hnn : 0 ≤ ((ℓ : ℝ) * (L : ℝ)) ^ 2 := by positivity
          have hexp : (ℓ : ℝ) * ((ℓ : ℝ) * (L : ℝ) ^ 2) = ((ℓ : ℝ) * (L : ℝ)) ^ 2 := by ring
          rw [hexp] at hp
          linarith
        linarith
      have hexp_diff : Real.exp (zSeq k - zSeq (k - 1)) ≤ (4 : ℝ) ^ 4 :=
        exp_le_four_pow 4 (by simpa using hdiff_le)
      have hsplit : zSeq k = zSeq (k - 1) + (zSeq k - zSeq (k - 1)) := by ring
      calc Real.exp (zSeq k)
          = Real.exp (zSeq (k - 1)) * Real.exp (zSeq k - zSeq (k - 1)) := by
            rw [← Real.exp_add, ← hsplit]
        _ ≤ (4 * (m : ℝ)) * (4 : ℝ) ^ 4 :=
            mul_le_mul hexp_prev hexp_diff (Real.exp_pos _).le (by positivity)
        _ = (4 : ℝ) ^ 5 * (m : ℝ) := by ring
        _ ≤ (4 : ℝ) ^ (ℓ + 5) * (m : ℝ) :=
            mul_le_mul_of_nonneg_right
              (pow_le_pow_right₀ (by norm_num) (by omega)) (Nat.cast_nonneg m)

  have htot : ExecStmt inp (stepP2Stmt ℓ C_base) mem₁ mem₂
      (120 + 14 * N + kMax * (70 + 14 * N)) := by
    unfold stepP2Stmt seqStmts
    refine (ExecStmt.seq hs1 (ExecStmt.seq hs2 (ExecStmt.seq hs3 (ExecStmt.seq hs4
      (ExecStmt.seq hs5 (ExecStmt.seq hs6 (ExecStmt.seq hs7 (ExecStmt.seq hs8 hrep)))))))).mono_cost ?_
    calc 26 + (10 + (20 + (4 + (5 + (15 + (10 + N * 14 + (5 + (12 + kMax * (70 + 14 * N)))))))))
        = 107 + (14 * N + kMax * (70 + 14 * N)) := by ring
      _ ≤ 120 + (14 * N + kMax * (70 + 14 * N)) := Nat.add_le_add_right (by decide) _
      _ = 120 + 14 * N + kMax * (70 + 14 * N) := by ring

  exact ⟨mem₂, tSeq k, FSeq k, htot, hfp₂,
    (ht_bounds k hk_le).1, (ht_bounds k hk_le).2,
    rfl, hFu_ge, hexp_ub, hwm₂, hwN₂, hwB₂, hrt₂, hrF₂⟩

theorem exec_stepP3Stmt {d : ℕ} (ℓ C_base : ℕ) (hℓ : 1 ≤ ℓ) (hC_base : 1 ≤ C_base)
    (m : ℕ) (hm : 1 ≤ m) {h x t F_u : ℝ}
    (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1)
    (ht1 : 1 ≤ t) (ht2 : t ≤ (natBitLength m + 2 : ℝ))
    (hFu_eq : F_u = (1 + ((ℓ : ℝ) * t ^ 2 / 2) / (paramN ℓ (natBitLength m) : ℝ)) ^
      paramN ℓ (natBitLength m))
    {mem₂ : ArithRAMMemory} :
    let inp : ArithRAMInput d :=
      { intParams := [(m : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0, extraReals := [h, x] }
    let L : ℕ := natBitLength m
    let N : ℕ := paramN ℓ L
    let B_max : ℕ := paramBMax ℓ C_base L
    CleanMem mem₂ →
    InParamFootprint mem₂ →
    wRead mem₂ 1 0 = (m : ℤ) →
    wRead mem₂ 11 2 = (N : ℤ) →
    wRead mem₂ 11 6 = (B_max : ℤ) →
    rRead mem₂ 1 0 = t →
    rRead mem₂ 17 2 = F_u →
    ∃ (mem₃ : ArithRAMMemory) (M₀ Cap_u Cap_q : ℕ) (F₁ F_q : ℝ),
      ExecStmt inp (stepP3Stmt ℓ C_base) mem₂ mem₃
        (240 + 28 * N + 48 * B_max + 12 * ℓ) ∧
      InParamFootprint mem₃ ∧
      1 ≤ M₀ ∧ 100 ≤ Cap_u ∧ 100 ≤ Cap_q ∧
      F₁ = (1 + (I_h h x * t ^ 2 / 2) / (N : ℝ)) ^ N ∧
      F_q = (1 + ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2) / (N : ℝ)) ^ N ∧
      (C_base : ℝ) * t ^ 2 * F₁ ≤ (M₀ : ℝ) ∧
      (M₀ : ℝ) ≤ max 1 (2 * ((C_base : ℝ) * t ^ 2 * F₁)) ∧
      100 * (((M₀ : ℝ) ^ ℓ) / F_u + 1) ≤ (Cap_u : ℝ) ∧
      (Cap_u : ℝ) ≤ max 100 (200 * (((M₀ : ℝ) ^ ℓ) / F_u + 1)) ∧
      100 * (((M₀ : ℝ) ^ ℓ) / F_q + 1) ≤ (Cap_q : ℝ) ∧
      (Cap_q : ℝ) ≤ max 100 (200 * (((M₀ : ℝ) ^ ℓ) / F_q + 1)) ∧
      wRead mem₃ 0 0 = ((ℓ * M₀ : ℕ) : ℤ) ∧
      wRead mem₃ 1 0 = (m : ℤ) ∧
      wRead mem₃ 1 1 = (M₀ : ℤ) ∧
      wRead mem₃ 1 2 = ((ℓ * M₀ : ℕ) : ℤ) ∧
      wRead mem₃ 1 3 = (Cap_u : ℤ) ∧
      wRead mem₃ 1 4 = (Cap_q : ℤ) ∧
      rRead mem₃ 1 0 = t ∧
      rRead mem₃ 1 1 = x * t := by
  intro inp L N B_max hc₂ hfp₂ hwm₂ hwN₂ hwB₂ hrt₂ hrFu₂
  rcases I_h_bounds hh0 hh1 hx0 hx1 with ⟨hI1, hI2, _, _, _, _⟩
  have hx_pos : 0 < x := lt_of_lt_of_le hh0 hx0

  let hE := RealExpr.extraReal (.lit 0)
  let xE := RealExpr.extraReal (.lit 1)
  let tE := RealExpr.readRealHeap 1 (.lit 0)
  let iExpr : RealExpr :=
    .div
      (.sub (.add (.ofInt (.lit 1)) (.mul xE xE)) (.mul (.mul (.ofInt (.lit 2)) hE) xE))
      (.sub (.ofInt (.lit 1)) (.mul hE hE))
  let z1Expr : RealExpr := .div (.mul iExpr (.mul tE tE)) (.ofInt (.lit 2))
  let r1Expr : RealExpr :=
    .mul (.mul (.ofInt (.lit (C_base : ℤ))) (.mul tE tE)) (.readRealHeap 17 (.lit 1))
  let zqExpr : RealExpr :=
    .div (.mul (.ofInt (.lit (ℓ : ℤ))) (.mul (.mul xE xE) (.mul tE tE))) (.ofInt (.lit 2))

  let z₁ : ℝ := I_h h x * t ^ 2 / 2
  let F₁ : ℝ := (1 + z₁ / (N : ℝ)) ^ N
  let R₁ : ℝ := (C_base : ℝ) * t ^ 2 * F₁
  let z_q : ℝ := (ℓ : ℝ) * x ^ 2 * t ^ 2 / 2
  let F_q : ℝ := (1 + z_q / (N : ℝ)) ^ N

  have ht_sq_le : t ^ 2 ≤ (L + 2 : ℝ) ^ 2 := pow_le_pow_left₀ (by linarith) ht2 2

  have hz₁_approx : 1 ≤ F₁ ∧ F₁ ≤ Real.exp z₁ ∧ Real.exp z₁ ≤ 2 * F₁ := by
    have hz₁_0 : 0 ≤ z₁ := by dsimp [z₁]; positivity
    have hz₁_ub : z₁ ≤ (L + 2 : ℝ) ^ 2 := by
      dsimp [z₁]
      have hm1 : I_h h x * t ^ 2 ≤ 2 * t ^ 2 := mul_le_mul_of_nonneg_right hI2 (sq_nonneg t)
      linarith
    exact one_plus_div_pow_approx hz₁_0 (three_z1_sq_le_paramN hℓ hz₁_0 hz₁_ub)

  have hFu_approx : 1 ≤ F_u ∧ F_u ≤ Real.exp ((ℓ : ℝ) * t ^ 2 / 2) ∧
      Real.exp ((ℓ : ℝ) * t ^ 2 / 2) ≤ 2 * F_u := by
    rw [hFu_eq]
    have hz_0 : 0 ≤ (ℓ : ℝ) * t ^ 2 / 2 := by positivity
    have hz_ub : (ℓ : ℝ) * t ^ 2 / 2 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := by
      have hm1 : (ℓ : ℝ) * t ^ 2 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 :=
        mul_le_mul_of_nonneg_left ht_sq_le (Nat.cast_nonneg ℓ)
      have hnn : 0 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := by positivity
      linarith
    exact one_plus_div_pow_approx hz_0 (three_z_sq_le_paramN hz_0 hz_ub)

  have hFq_approx : 1 ≤ F_q ∧ F_q ≤ Real.exp z_q ∧ Real.exp z_q ≤ 2 * F_q := by
    have hzq_0 : 0 ≤ z_q := by dsimp [z_q]; positivity
    have hzq_ub : z_q ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := by
      dsimp [z_q]
      have hx2 : x ^ 2 ≤ 1 := by
        calc x ^ 2 ≤ 1 ^ 2 := pow_le_pow_left₀ hx_pos.le hx1 2
          _ = 1 := one_pow 2
      have hxt : x ^ 2 * t ^ 2 ≤ (L + 2 : ℝ) ^ 2 := by
        calc x ^ 2 * t ^ 2 ≤ 1 * t ^ 2 := mul_le_mul_of_nonneg_right hx2 (sq_nonneg t)
          _ = t ^ 2 := one_mul _
          _ ≤ (L + 2 : ℝ) ^ 2 := ht_sq_le
      have hm1 : (ℓ : ℝ) * (x ^ 2 * t ^ 2) ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 :=
        mul_le_mul_of_nonneg_left hxt (Nat.cast_nonneg ℓ)
      have hnn : 0 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := by positivity
      linarith
    exact one_plus_div_pow_approx hzq_0 (three_z_sq_le_paramN hzq_0 hzq_ub)

  -- 1. writeRealHeap 1 1 (x * t)
  rcases exec_rSet_fp inp hc₂ hfp₂ 1 1 (by decide) (.mul xE tE) (x * t) 8
    (by simp [xE, tE, inp, evalRealExpr, evalIntExpr, hrt₂])
    (by simp [xE, tE, evalRealExpr, evalIntExpr]) with
    ⟨mc1, hs1, hfp_c1, hrc1_xt, hwc1, hrc1_ne⟩
  have hrc1_t : rRead mc1 1 0 = t := (hrc1_ne 1 0 (Or.inr (by decide))).trans hrt₂
  have hrc1_Fu : rRead mc1 17 2 = F_u := (hrc1_ne 17 2 (Or.inl (by decide))).trans hrFu₂

  -- 2. writeRealHeap 17 0 z1Expr
  rcases exec_rSet_fp inp hs1.2.1 hfp_c1 17 0 (by decide) z1Expr z₁ 40
    (by simp [z1Expr, iExpr, hE, xE, tE, inp, evalRealExpr, evalIntExpr,
          hrc1_t, z₁, I_h, sq])
    (by simp [z1Expr, iExpr, hE, xE, tE, evalRealExpr, evalIntExpr]) with
    ⟨mc2, hs2, hfp_c2, hrc2_z1, hwc2, hrc2_ne⟩
  have hwc2_N : wRead mc2 11 2 = (N : ℤ) := (hwc2 11 2).trans ((hwc1 11 2).trans hwN₂)

  -- 3. pow1PlusZStmt -> F₁ in 17 1
  rcases exec_pow1PlusZStmt inp hs2.2.1 hfp_c2 hwc2_N with
    ⟨mc3, hs3, hfp_c3, hwc3, hrc3_ne, hrc3_F1⟩
  rw [hrc2_z1] at hrc3_F1
  have hrc3_t : rRead mc3 1 0 = t :=
    (hrc3_ne 1 0 (Or.inl (by decide))).trans ((hrc2_ne 1 0 (Or.inl (by decide))).trans hrc1_t)

  -- 4. writeRealHeap 17 3 r1Expr
  rcases exec_rSet_fp inp hs3.2.1 hfp_c3 17 3 (by decide) r1Expr R₁ 15
    (by simp [r1Expr, tE, evalRealExpr, evalIntExpr, hrc3_t, hrc3_F1, R₁, F₁, sq])
    (by simp [r1Expr, tE, evalRealExpr, evalIntExpr]) with
    ⟨mc4, hs4, hfp_c4, hrc4_R1, hwc4, hrc4_ne⟩
  have hwc4_all : ∀ t' i', wRead mc4 t' i' = wRead mem₂ t' i' := fun t' i' =>
    (hwc4 t' i').trans ((hwc3 t' i').trans ((hwc2 t' i').trans (hwc1 t' i')))

  let E_r1 : ℕ := paramEr1 C_base L
  have hR1_pow : R₁ ≤ (2 : ℝ) ^ E_r1 := by
    have hc_ub : (C_base : ℝ) ≤ (2 : ℝ) ^ C_base := nat_cast_le_two_pow C_base
    have ht_ub : t ^ 2 ≤ (2 : ℝ) ^ (2 * (L + 2) ^ 2) := by
      have ht_p : t ≤ (2 : ℝ) ^ (L + 2) :=
        ht2.trans (by exact_mod_cast (Nat.lt_two_pow_self (n := L + 2)).le)
      have h1 : t ^ 2 ≤ ((2 : ℝ) ^ (L + 2)) ^ 2 := pow_le_pow_left₀ (by linarith) ht_p 2
      have h2 : ((2 : ℝ) ^ (L + 2)) ^ 2 = (2 : ℝ) ^ (2 * (L + 2)) := by
        rw [← pow_mul]; congr 1; ring
      have hle_e : 2 * (L + 2) ≤ 2 * (L + 2) ^ 2 := by
        have : L + 2 ≤ (L + 2) * (L + 2) := Nat.le_mul_self (L + 2)
        rw [sq]; omega
      exact (h1.trans_eq h2).trans (pow_le_pow_right₀ (by norm_num) hle_e)
    have hF1_ub : F₁ ≤ (2 : ℝ) ^ (2 * (L + 2) ^ 2) := by
      have hz1_le : z₁ ≤ ((L + 2) ^ 2 : ℕ) := by
        push_cast; dsimp [z₁]
        have hm1 : I_h h x * t ^ 2 ≤ 2 * t ^ 2 := mul_le_mul_of_nonneg_right hI2 (sq_nonneg t)
        linarith
      exact hz₁_approx.2.1.trans (exp_le_two_pow_two_mul ((L + 2) ^ 2) hz1_le)
    calc R₁ = (C_base : ℝ) * t ^ 2 * F₁ := rfl
      _ ≤ (2 : ℝ) ^ C_base * (2 : ℝ) ^ (2 * (L + 2) ^ 2) * (2 : ℝ) ^ (2 * (L + 2) ^ 2) := by
          have hp1 : 0 ≤ t ^ 2 := sq_nonneg t
          have hp2 : 0 ≤ F₁ := by linarith [hz₁_approx.1]
          exact mul_le_mul (mul_le_mul hc_ub ht_ub hp1 (by positivity)) hF1_ub hp2 (by positivity)
      _ = (2 : ℝ) ^ E_r1 := by
          dsimp [E_r1]; rw [paramEr1_def]
          have heq : C_base + 4 * (L + 2) ^ 2 = C_base + 2 * (L + 2) ^ 2 + 2 * (L + 2) ^ 2 := by ring
          rw [heq, pow_add, pow_add]
  have hR1_B : rRead mc4 17 3 ≤ ((1 : ℕ) : ℝ) * (2 : ℝ) ^ B_max := by
    push_cast
    rw [hrc4_R1, one_mul]
    exact hR1_pow.trans (pow_le_pow_right₀ (by norm_num) (paramEr1_le_paramBMax ℓ C_base L))

  -- 5. boundedDoublingStmt 1 1 1 3 -> M₀ in 1 1
  rcases exec_boundedDoublingStmt inp hs4.2.1 hfp_c4 1 1 (Or.inl (by decide)) (by decide)
    1 le_rfl 3 ((hwc4_all 11 6).trans hwB₂) hR1_B with
    ⟨mc5, M₀, hs5, hfp_c5, hM0_ge, hM0_lb, hM0_ub, hwc5_M0, hwc5_ne, hrc5⟩
  rw [hrc4_R1] at hM0_lb hM0_ub

  -- 6. writeWordHeap 1 2 (ℓ * M₀)
  rcases exec_wSet_fp inp hs5.2.1 hfp_c5 1 2 (by decide)
    (.mul (.lit (ℓ : ℤ)) (.readHeap 1 (.lit 1))) (((ℓ * M₀ : ℕ) : ℤ)) 8
    (by simp [evalIntExpr, hwc5_M0]) (by simp [evalIntExpr]) with
    ⟨mc6, hs6, hfp_c6, hwc6_K, hwc6_ne, hrc6⟩

  -- 7. writeWordHeap 0 0 (readHeap 1 2)
  rcases exec_wSet_fp inp hs6.2.1 hfp_c6 0 0 (by decide)
    (.readHeap 1 (.lit 2)) (((ℓ * M₀ : ℕ) : ℤ)) 5
    (by simp [evalIntExpr, hwc6_K]) (by simp [evalIntExpr]) with
    ⟨mc7, hs7, hfp_c7, hwc7_K0, hwc7_ne, hrc7⟩

  -- 8. writeWordHeap 11 5 1
  rcases exec_wSet_fp inp hs7.2.1 hfp_c7 11 5 (by decide) (.lit 1) 1 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨mc8, hs8, hfp_c8, hwc8_A, hwc8_ne, hrc8⟩

  -- 9. repeatN ℓ: multiply 11 5 by M₀
  let powBody : ArithRAMStmt :=
    .writeWordHeap 11 (.lit 5) (.mul (.readHeap 11 (.lit 5)) (.readHeap 1 (.lit 1)))
  let InvA : ℕ → ArithRAMMemory → Prop := fun i mem =>
    InParamFootprint mem ∧
    wRead mem 11 5 = ((M₀ ^ i : ℕ) : ℤ) ∧
    (∀ t' i', (t' ≠ 11 ∨ i' ≠ 5) → wRead mem t' i' = wRead mc7 t' i') ∧
    (∀ t' i', rRead mem t' i' = rRead mc7 t' i')
  have hInvA₀ : InvA 0 mc8 := ⟨hfp_c8, by simpa using hwc8_A, hwc8_ne, hrc8⟩
  have hwc7_M0 : wRead mc7 1 1 = (M₀ : ℤ) :=
    (hwc7_ne 1 1 (Or.inl (by decide))).trans ((hwc6_ne 1 1 (Or.inr (by decide))).trans hwc5_M0)
  rcases exec_repeatN (.lit (ℓ : ℤ)) powBody ℓ 3 10 InvA hs8.2.1 hInvA₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun i _ mem hcm ⟨hfpm, hwA, hwne, hrne⟩ => by
      have hwM0 : wRead mem 1 1 = (M₀ : ℤ) := (hwne 1 1 (Or.inl (by decide))).trans hwc7_M0
      rcases exec_wSet_fp inp hcm hfpm 11 5 (by decide)
        (.mul (.readHeap 11 (.lit 5)) (.readHeap 1 (.lit 1))) (((M₀ ^ (i + 1) : ℕ) : ℤ)) 10
        (by simp [evalIntExpr, hwA, hwM0, pow_succ]) (by simp [evalIntExpr]) with
        ⟨m', hs', hfp', hw'_self, hw'_ne, hr'⟩
      exact ⟨m', hs', hfp', hw'_self,
        fun t' i' hne => (hw'_ne t' i' hne).trans (hwne t' i' hne),
        fun t' i' => (hr' t' i').trans (hrne t' i')⟩) with
    ⟨mc9, ⟨hfp_c9, hwc9_A, hwc9_ne, hrc9⟩, hs9⟩

  have hA_pow : ((M₀ : ℝ) ^ ℓ) + 1 ≤ (2 : ℝ) ^ B_max := by
    have hM0_pow : (M₀ : ℝ) ≤ (2 : ℝ) ^ (E_r1 + 1) := by
      have h2R1 : 2 * R₁ ≤ (2 : ℝ) ^ (E_r1 + 1) := by
        rw [pow_succ]; linarith
      have h1le : ((1 : ℕ) : ℝ) ≤ (2 : ℝ) ^ (E_r1 + 1) := by
        push_cast; exact one_le_pow₀ (by norm_num)
      exact hM0_ub.trans (max_le h1le h2R1)
    have hAl : (M₀ : ℝ) ^ ℓ ≤ (2 : ℝ) ^ (ℓ * (E_r1 + 1)) := by
      calc (M₀ : ℝ) ^ ℓ ≤ ((2 : ℝ) ^ (E_r1 + 1)) ^ ℓ := pow_le_pow_left₀ (Nat.cast_nonneg M₀) hM0_pow ℓ
        _ = (2 : ℝ) ^ (ℓ * (E_r1 + 1)) := by rw [← pow_mul]; congr 1; ring
    have hAl_ge1 : (1 : ℝ) ≤ (M₀ : ℝ) ^ ℓ := one_le_pow₀ (by exact_mod_cast hM0_ge)
    calc (M₀ : ℝ) ^ ℓ + 1 ≤ 2 * (M₀ : ℝ) ^ ℓ := by linarith
      _ ≤ 2 * (2 : ℝ) ^ (ℓ * (E_r1 + 1)) := by linarith
      _ = (2 : ℝ) ^ (ℓ * (E_r1 + 1) + 1) := by rw [pow_succ]; ring
      _ ≤ (2 : ℝ) ^ B_max := pow_le_pow_right₀ (by norm_num) (mul_er1_succ_le_paramBMax ℓ C_base L)

  have hrc9_all : ∀ t' i', rRead mc9 t' i' = rRead mc4 t' i' := fun t' i' =>
    (hrc9 t' i').trans ((hrc7 t' i').trans ((hrc6 t' i').trans (hrc5 t' i')))
  have hrc9_Fu : rRead mc9 17 2 = F_u :=
    (hrc9_all 17 2).trans
      ((hrc4_ne 17 2 (Or.inr (by decide))).trans
        ((hrc3_ne 17 2 (Or.inr (by decide))).trans
          ((hrc2_ne 17 2 (Or.inr (by decide))).trans hrc1_Fu)))

  -- 10. writeRealHeap 17 4 (100 * (A / F_u + 1))
  let target_u : ℝ := 100 * (((M₀ : ℝ) ^ ℓ) / F_u + 1)
  rcases exec_rSet_fp inp hs9.2.1 hfp_c9 17 4 (by decide)
    (.mul (.ofInt (.lit 100))
      (.add (.div (.ofInt (.readHeap 11 (.lit 5))) (.readRealHeap 17 (.lit 2)))
        (.ofInt (.lit 1))))
    target_u 16
    (by simp [evalRealExpr, evalIntExpr, hwc9_A, hrc9_Fu, target_u])
    (by simp [evalRealExpr, evalIntExpr]) with
    ⟨mc10, hs10, hfp_c10, hrc10_tu, hwc10, hrc10_ne⟩

  have hwc9_B : wRead mc9 11 6 = (B_max : ℤ) :=
    (hwc9_ne 11 6 (Or.inr (by decide))).trans
      ((hwc7_ne 11 6 (Or.inl (by decide))).trans
        ((hwc6_ne 11 6 (Or.inl (by decide))).trans
          ((hwc5_ne 11 6 (Or.inl (by decide))).trans ((hwc4_all 11 6).trans hwB₂))))
  have htu_ub : rRead mc10 17 4 ≤ (100 : ℝ) * (2 : ℝ) ^ B_max := by
    rw [hrc10_tu]
    have hdiv_le : ((M₀ : ℝ) ^ ℓ) / F_u ≤ (M₀ : ℝ) ^ ℓ :=
      div_le_self (by positivity) hFu_approx.1
    dsimp [target_u]
    linarith

  -- 11. boundedDoublingStmt 1 3 100 4 -> Cap_u in 1 3
  rcases exec_boundedDoublingStmt inp hs10.2.1 hfp_c10 1 3 (Or.inl (by decide)) (by decide)
    100 (by omega) 4 ((hwc10 11 6).trans hwc9_B) htu_ub with
    ⟨mc11, Cap_u, hs11, hfp_c11, hCapu_ge, hCapu_lb, hCapu_ub, hwc11_Cu, hwc11_ne, hrc11⟩
  rw [hrc10_tu] at hCapu_lb hCapu_ub

  -- 12. writeRealHeap 17 0 zqExpr
  have hrc11_t : rRead mc11 1 0 = t :=
    (hrc11 1 0).trans
      ((hrc10_ne 1 0 (Or.inl (by decide))).trans
        ((hrc9_all 1 0).trans ((hrc4_ne 1 0 (Or.inl (by decide))).trans hrc3_t)))
  rcases exec_rSet_fp inp hs11.2.1 hfp_c11 17 0 (by decide) zqExpr z_q 22
    (by simp [zqExpr, xE, tE, inp, evalRealExpr, evalIntExpr, hrc11_t, z_q, sq]; ring)
    (by simp [zqExpr, xE, tE, evalRealExpr, evalIntExpr]) with
    ⟨mc12, hs12, hfp_c12, hrc12_zq, hwc12, hrc12_ne⟩

  -- 13. pow1PlusZStmt -> F_q in 17 1
  have hwc12_N : wRead mc12 11 2 = (N : ℤ) :=
    (hwc12 11 2).trans
      ((hwc11_ne 11 2 (Or.inl (by decide))).trans
        ((hwc10 11 2).trans
          ((hwc9_ne 11 2 (Or.inr (by decide))).trans
            ((hwc7_ne 11 2 (Or.inl (by decide))).trans
              ((hwc6_ne 11 2 (Or.inl (by decide))).trans
                ((hwc5_ne 11 2 (Or.inl (by decide))).trans ((hwc4_all 11 2).trans hwN₂)))))))
  rcases exec_pow1PlusZStmt inp hs12.2.1 hfp_c12 hwc12_N with
    ⟨mc13, hs13, hfp_c13, hwc13, hrc13_ne, hrc13_Fq⟩
  rw [hrc12_zq] at hrc13_Fq

  -- 14. writeRealHeap 17 5 (100 * (A / F_q + 1))
  have hwc13_A : wRead mc13 11 5 = ((M₀ ^ ℓ : ℕ) : ℤ) :=
    (hwc13 11 5).trans
      ((hwc12 11 5).trans
        ((hwc11_ne 11 5 (Or.inl (by decide))).trans ((hwc10 11 5).trans hwc9_A)))
  let target_q : ℝ := 100 * (((M₀ : ℝ) ^ ℓ) / F_q + 1)
  rcases exec_rSet_fp inp hs13.2.1 hfp_c13 17 5 (by decide)
    (.mul (.ofInt (.lit 100))
      (.add (.div (.ofInt (.readHeap 11 (.lit 5))) (.readRealHeap 17 (.lit 1)))
        (.ofInt (.lit 1))))
    target_q 16
    (by simp [evalRealExpr, evalIntExpr, hwc13_A, hrc13_Fq, F_q, target_q])
    (by simp [evalRealExpr, evalIntExpr]) with
    ⟨mc14, hs14, hfp_c14, hrc14_tq, hwc14, hrc14_ne⟩

  have hwc14_B : wRead mc14 11 6 = (B_max : ℤ) :=
    (hwc14 11 6).trans
      ((hwc13 11 6).trans
        ((hwc12 11 6).trans
          ((hwc11_ne 11 6 (Or.inl (by decide))).trans ((hwc10 11 6).trans hwc9_B))))
  have htq_ub : rRead mc14 17 5 ≤ (100 : ℝ) * (2 : ℝ) ^ B_max := by
    rw [hrc14_tq]
    have hdiv_le : ((M₀ : ℝ) ^ ℓ) / F_q ≤ (M₀ : ℝ) ^ ℓ :=
      div_le_self (by positivity) hFq_approx.1
    dsimp [target_q]
    linarith

  -- 15. boundedDoublingStmt 1 4 100 5 -> Cap_q in 1 4
  rcases exec_boundedDoublingStmt inp hs14.2.1 hfp_c14 1 4 (Or.inl (by decide)) (by decide)
    100 (by omega) 5 hwc14_B htq_ub with
    ⟨mc15, Cap_q, hs15, hfp_c15, hCapq_ge, hCapq_lb, hCapq_ub, hwc15_Cq, hwc15_ne, hrc15⟩
  rw [hrc14_tq] at hCapq_lb hCapq_ub

  have htot : ExecStmt inp (stepP3Stmt ℓ C_base) mem₂ mc15
      (240 + 28 * N + 48 * B_max + 12 * ℓ) := by
    unfold stepP3Stmt seqStmts
    exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 (ExecStmt.seq hs3 (ExecStmt.seq hs4
      (ExecStmt.seq hs5 (ExecStmt.seq hs6 (ExecStmt.seq hs7 (ExecStmt.seq hs8
      (ExecStmt.seq hs9 (ExecStmt.seq hs10 (ExecStmt.seq hs11 (ExecStmt.seq hs12
      (ExecStmt.seq hs13 (ExecStmt.seq hs14 hs15)))))))))))))).mono_cost (by omega)

  have hw_thru_14 : ∀ t' i', (t' ≠ 1 ∨ i' ≠ 3) → (t' ≠ 11 ∨ i' ≠ 5) →
      wRead mc14 t' i' = wRead mc7 t' i' := by
    intro t' i' h13 h115
    exact (hwc14 t' i').trans ((hwc13 t' i').trans ((hwc12 t' i').trans
      ((hwc11_ne t' i' h13).trans ((hwc10 t' i').trans (hwc9_ne t' i' h115)))))

  refine ⟨mc15, M₀, Cap_u, Cap_q, F₁, F_q, htot, hfp_c15,
    hM0_ge, hCapu_ge, hCapq_ge, rfl, rfl,
    hM0_lb, by simpa [target_u] using hM0_ub,
    hCapu_lb, ?_,
    hCapq_lb, ?_, ?_, ?_, ?_, ?_, ?_, hwc15_Cq, ?_, ?_⟩
  · calc (Cap_u : ℝ) ≤ max 100 (2 * target_u) := hCapu_ub
      _ = max 100 (200 * ((M₀ : ℝ) ^ ℓ / F_u + 1)) := by dsimp [target_u]; congr 1; ring
  · calc (Cap_q : ℝ) ≤ max 100 (2 * target_q) := hCapq_ub
      _ = max 100 (200 * ((M₀ : ℝ) ^ ℓ / F_q + 1)) := by dsimp [target_q]; congr 1; ring
  · exact (hwc15_ne 0 0 (Or.inl (by decide))).trans
      ((hw_thru_14 0 0 (Or.inl (by decide)) (Or.inl (by decide))).trans hwc7_K0)
  · exact (hwc15_ne 1 0 (Or.inr (by decide))).trans
      ((hw_thru_14 1 0 (Or.inr (by decide)) (Or.inl (by decide))).trans
        ((hwc7_ne 1 0 (Or.inl (by decide))).trans
          ((hwc6_ne 1 0 (Or.inr (by decide))).trans
            ((hwc5_ne 1 0 (Or.inr (by decide))).trans ((hwc4_all 1 0).trans hwm₂)))))
  · exact (hwc15_ne 1 1 (Or.inr (by decide))).trans
      ((hw_thru_14 1 1 (Or.inr (by decide)) (Or.inl (by decide))).trans hwc7_M0)
  · exact (hwc15_ne 1 2 (Or.inr (by decide))).trans
      ((hw_thru_14 1 2 (Or.inr (by decide)) (Or.inl (by decide))).trans
        ((hwc7_ne 1 2 (Or.inl (by decide))).trans hwc6_K))
  · exact (hwc15_ne 1 3 (Or.inr (by decide))).trans
      ((hwc14 1 3).trans ((hwc13 1 3).trans ((hwc12 1 3).trans hwc11_Cu)))
  · exact (hrc15 1 0).trans
      ((hrc14_ne 1 0 (Or.inl (by decide))).trans
        ((hrc13_ne 1 0 (Or.inl (by decide))).trans
          ((hrc12_ne 1 0 (Or.inl (by decide))).trans hrc11_t)))
  · exact (hrc15 1 1).trans
      ((hrc14_ne 1 1 (Or.inl (by decide))).trans
        ((hrc13_ne 1 1 (Or.inl (by decide))).trans
          ((hrc12_ne 1 1 (Or.inl (by decide))).trans
            ((hrc11 1 1).trans
              ((hrc10_ne 1 1 (Or.inl (by decide))).trans
                ((hrc9_all 1 1).trans
                  ((hrc4_ne 1 1 (Or.inl (by decide))).trans
                    ((hrc3_ne 1 1 (Or.inl (by decide))).trans
                      ((hrc2_ne 1 1 (Or.inl (by decide))).trans hrc1_xt)))))))))

/-! ### 6. Master `paramStmt` theorem with polynomial, exponent, and probability bounds -/

/-- Explicit cost polynomial constant for `buildParamStmt ℓ C_base`. -/
@[irreducible]
def paramCostConst (ℓ C_base : ℕ) : ℕ :=
  200000 * (ℓ + 1) ^ 4 * (C_base + 10)

@[irreducible]
noncomputable def paramScale (ℓ : ℕ) : ℝ :=
  (4 : ℝ) ^ (ℓ + 5)

theorem paramScale_def (ℓ : ℕ) : paramScale ℓ = (4 : ℝ) ^ (ℓ + 5) := by
  unfold paramScale; rfl

theorem paramScale_ge_one (ℓ : ℕ) : 1 ≤ paramScale ℓ := by
  rw [paramScale_def]; exact one_le_pow₀ (by norm_num)

theorem paramScale_nonneg (ℓ : ℕ) : 0 ≤ paramScale ℓ :=
  le_trans zero_le_one (paramScale_ge_one ℓ)

/-- Explicit exponent-bound coefficient for `M₀, Cap_u, Cap_q`. -/
@[irreducible]
noncomputable def paramPowConst (ℓ C_base : ℕ) : ℝ :=
  1000 * ((8 + 8 * (C_base : ℝ)) ^ ℓ) * (paramScale ℓ) ^ 2

theorem paramPowConst_def (ℓ C_base : ℕ) :
    paramPowConst ℓ C_base = 1000 * ((8 + 8 * (C_base : ℝ)) ^ ℓ) * (paramScale ℓ) ^ 2 := by
  unfold paramPowConst; rfl

theorem paramPowConst_nonneg (ℓ C_base : ℕ) : 0 ≤ paramPowConst ℓ C_base := by
  rw [paramPowConst_def]
  have h1 : 0 ≤ (8 + 8 * (C_base : ℝ)) ^ ℓ := by positivity
  have h2 : 0 ≤ (paramScale ℓ) ^ 2 := sq_nonneg _
  positivity

theorem paramCost_le_bound (ℓ C_base L : ℕ) :
    (20 + 18 * L) +
      ((120 + 14 * paramN ℓ L + (ℓ * L * (L + 1)) * (70 + 14 * paramN ℓ L)) +
        (240 + 28 * paramN ℓ L + 48 * paramBMax ℓ C_base L + 12 * ℓ)) ≤
      paramCostConst ℓ C_base * (L + 1) ^ 6 := by
  rw [paramN_def, paramBMax_def]
  unfold paramCostConst
  set A := ℓ + 1
  set D := C_base + 10
  set Y := L + 1
  have hY_pos : 1 ≤ Y := by omega
  have hA_pos : 1 ≤ A := by omega
  have hD_pos : 1 ≤ D := by omega
  have hbp2 : L + 2 ≤ 2 * Y := by omega
  have hbp2_2 : (L + 2) ^ 2 ≤ 4 * Y ^ 2 := by
    calc (L + 2) ^ 2 ≤ (2 * Y) ^ 2 := Nat.pow_le_pow_left hbp2 2
      _ = 4 * Y ^ 2 := by ring
  have hbp2_4 : (L + 2) ^ 4 ≤ 16 * Y ^ 4 := by
    calc (L + 2) ^ 4 ≤ (2 * Y) ^ 4 := Nat.pow_le_pow_left hbp2 4
      _ = 16 * Y ^ 4 := by ring
  have hN_ub : 3 * ℓ * ℓ * (L + 2) ^ 4 + 1 ≤ 49 * A ^ 2 * Y ^ 4 := by
    have hℓA : ℓ * ℓ ≤ A ^ 2 := by
      rw [sq]; exact Nat.mul_le_mul (by omega) (by omega)
    have h1 : 3 * ℓ * ℓ * (L + 2) ^ 4 ≤ 48 * (A ^ 2 * Y ^ 4) := by
      calc 3 * ℓ * ℓ * (L + 2) ^ 4
          = 3 * (ℓ * ℓ) * (L + 2) ^ 4 := by ring
        _ ≤ 3 * A ^ 2 * (16 * Y ^ 4) :=
            Nat.mul_le_mul (Nat.mul_le_mul_left 3 hℓA) hbp2_4
        _ = 48 * (A ^ 2 * Y ^ 4) := by ring
    have h2 : 1 ≤ A ^ 2 * Y ^ 4 := Nat.mul_le_mul (one_le_pow₀ hA_pos) (one_le_pow₀ hY_pos)
    calc 3 * ℓ * ℓ * (L + 2) ^ 4 + 1
        ≤ 48 * (A ^ 2 * Y ^ 4) + A ^ 2 * Y ^ 4 := Nat.add_le_add h1 h2
      _ = 49 * A ^ 2 * Y ^ 4 := by ring
  have hB_ub : A * (C_base + 4 + 4 * (L + 2) ^ 2) ≤ 17 * A * D * Y ^ 2 := by
    have hcb : C_base + 4 ≤ D * Y ^ 2 := by
      calc C_base + 4 ≤ D * 1 := by omega
        _ ≤ D * Y ^ 2 := Nat.mul_le_mul_left D (one_le_pow₀ hY_pos)
    have h4 : 4 * (L + 2) ^ 2 ≤ 16 * D * Y ^ 2 := by
      calc 4 * (L + 2) ^ 2 ≤ 4 * (4 * Y ^ 2) := Nat.mul_le_mul_left 4 hbp2_2
        _ = 16 * 1 * Y ^ 2 := by ring
        _ ≤ 16 * D * Y ^ 2 := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 16 hD_pos)
    calc A * (C_base + 4 + 4 * (L + 2) ^ 2)
        ≤ A * (D * Y ^ 2 + 16 * D * Y ^ 2) := Nat.mul_le_mul_left A (Nat.add_le_add hcb h4)
      _ = 17 * A * D * Y ^ 2 := by ring
  have hk_ub : ℓ * L * Y ≤ A * Y ^ 2 := by
    calc ℓ * L * Y ≤ A * Y * Y :=
          Nat.mul_le_mul_right Y (Nat.mul_le_mul (by omega) (by omega))
      _ = A * Y ^ 2 := by ring
  have h_all_A : ∀ k ≤ 4, A ^ k ≤ A ^ 4 := fun k hk => Nat.pow_le_pow_right hA_pos hk
  have h_all_Y : ∀ k ≤ 6, Y ^ k ≤ Y ^ 6 := fun k hk => Nat.pow_le_pow_right hY_pos hk
  have ht1 : 20 + 18 * L ≤ 38 * (A ^ 4 * D * Y ^ 6) := by
    have hL : L ≤ Y ^ 6 := (by omega : L ≤ Y).trans (by simpa using h_all_Y 1 (by decide))
    have h1 : 1 ≤ A ^ 4 * D := Nat.mul_le_mul (one_le_pow₀ hA_pos) hD_pos
    calc 20 + 18 * L ≤ 20 * Y ^ 6 + 18 * Y ^ 6 :=
          Nat.add_le_add (Nat.le_mul_of_pos_right 20 (one_le_pow₀ hY_pos)) (Nat.mul_le_mul_left 18 hL)
      _ = 38 * 1 * Y ^ 6 := by ring
      _ ≤ 38 * (A ^ 4 * D) * Y ^ 6 := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 38 h1)
      _ = 38 * (A ^ 4 * D * Y ^ 6) := by ring
  have ht2 : 120 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1) +
      (ℓ * L * Y) * (70 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1)) ≤
      2000 * (A ^ 4 * D * Y ^ 6) := by
    have h70 : 70 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1) ≤ 756 * A ^ 2 * Y ^ 4 := by
      have h1 : 1 ≤ A ^ 2 * Y ^ 4 := Nat.mul_le_mul (one_le_pow₀ hA_pos) (one_le_pow₀ hY_pos)
      calc 70 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1)
          ≤ 70 * (A ^ 2 * Y ^ 4) + 14 * (49 * A ^ 2 * Y ^ 4) :=
            Nat.add_le_add (Nat.le_mul_of_pos_right 70 h1) (Nat.mul_le_mul_left 14 hN_ub)
        _ = 756 * A ^ 2 * Y ^ 4 := by ring
    have h120 : 120 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1) ≤ 806 * A ^ 4 * D * Y ^ 6 := by
      have h1 : 1 ≤ A ^ 4 * D * Y ^ 6 :=
        Nat.mul_le_mul (Nat.mul_le_mul (one_le_pow₀ hA_pos) hD_pos) (one_le_pow₀ hY_pos)
      have h2 : A ^ 2 * Y ^ 4 ≤ A ^ 4 * D * Y ^ 6 := by
        calc A ^ 2 * Y ^ 4 = A ^ 2 * 1 * Y ^ 4 := by ring
          _ ≤ A ^ 4 * D * Y ^ 6 :=
              Nat.mul_le_mul (Nat.mul_le_mul (h_all_A 2 (by decide)) hD_pos) (h_all_Y 4 (by decide))
      calc 120 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1)
          ≤ 120 * (A ^ 4 * D * Y ^ 6) + 14 * (49 * (A ^ 4 * D * Y ^ 6)) :=
            Nat.add_le_add (Nat.le_mul_of_pos_right 120 h1)
              (Nat.mul_le_mul_left 14 (hN_ub.trans (by calc 49 * A ^ 2 * Y ^ 4 = 49 * (A ^ 2 * Y ^ 4) := by ring
                _ ≤ 49 * (A ^ 4 * D * Y ^ 6) := Nat.mul_le_mul_left 49 h2)))
        _ = 806 * (A ^ 4 * D * Y ^ 6) := by ring
        _ = 806 * A ^ 4 * D * Y ^ 6 := by ring
    have hprod : (ℓ * L * Y) * (70 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1)) ≤
        756 * A ^ 4 * D * Y ^ 6 := by
      have hA3 : A ^ 3 ≤ A ^ 4 * D := by
        calc A ^ 3 = A ^ 3 * 1 := by ring
          _ ≤ A ^ 4 * D := Nat.mul_le_mul (h_all_A 3 (by decide)) hD_pos
      calc (ℓ * L * Y) * (70 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1))
          ≤ (A * Y ^ 2) * (756 * A ^ 2 * Y ^ 4) := Nat.mul_le_mul hk_ub h70
        _ = 756 * A ^ 3 * Y ^ 6 := by ring
        _ = 756 * (A ^ 3) * Y ^ 6 := by ring
        _ ≤ 756 * (A ^ 4 * D) * Y ^ 6 := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 756 hA3)
        _ = 756 * A ^ 4 * D * Y ^ 6 := by ring
    calc 120 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1) +
          (ℓ * L * Y) * (70 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1))
        ≤ 806 * A ^ 4 * D * Y ^ 6 + 756 * A ^ 4 * D * Y ^ 6 := Nat.add_le_add h120 hprod
      _ ≤ 2000 * (A ^ 4 * D * Y ^ 6) := by
          have : 806 * A ^ 4 * D * Y ^ 6 + 756 * A ^ 4 * D * Y ^ 6 = 1562 * (A ^ 4 * D * Y ^ 6) := by ring
          rw [this]
          exact Nat.mul_le_mul_right _ (by decide)
  have ht3 : 240 + 28 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1) +
      48 * (A * (C_base + 4 + 4 * (L + 2) ^ 2)) + 12 * ℓ ≤
      3000 * (A ^ 4 * D * Y ^ 6) := by
    have h1 : 1 ≤ A ^ 4 * D * Y ^ 6 :=
      Nat.mul_le_mul (Nat.mul_le_mul (one_le_pow₀ hA_pos) hD_pos) (one_le_pow₀ hY_pos)
    have h2 : A ^ 2 * Y ^ 4 ≤ A ^ 4 * D * Y ^ 6 := by
      calc A ^ 2 * Y ^ 4 = A ^ 2 * 1 * Y ^ 4 := by ring
        _ ≤ A ^ 4 * D * Y ^ 6 :=
            Nat.mul_le_mul (Nat.mul_le_mul (h_all_A 2 (by decide)) hD_pos) (h_all_Y 4 (by decide))
    have h3 : A * D * Y ^ 2 ≤ A ^ 4 * D * Y ^ 6 := by
      calc A * D * Y ^ 2 = A ^ 1 * D * Y ^ 2 := by ring
        _ ≤ A ^ 4 * D * Y ^ 6 :=
            Nat.mul_le_mul (Nat.mul_le_mul (h_all_A 1 (by decide)) le_rfl) (h_all_Y 2 (by decide))
    have h4 : ℓ ≤ A ^ 4 * D * Y ^ 6 := by
      calc ℓ ≤ A ^ 1 * 1 * 1 := by simp [A]
        _ ≤ A ^ 4 * D * Y ^ 6 :=
            Nat.mul_le_mul (Nat.mul_le_mul (h_all_A 1 (by decide)) hD_pos) (one_le_pow₀ hY_pos)
    have hp1 : 28 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1) ≤ 1372 * (A ^ 4 * D * Y ^ 6) := by
      calc 28 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1)
          ≤ 28 * (49 * (A ^ 2 * Y ^ 4)) :=
            Nat.mul_le_mul_left 28 (by simpa [mul_assoc] using hN_ub)
        _ ≤ 28 * (49 * (A ^ 4 * D * Y ^ 6)) :=
            Nat.mul_le_mul_left 28 (Nat.mul_le_mul_left 49 h2)
        _ = 1372 * (A ^ 4 * D * Y ^ 6) := by ring
    have hp2 : 48 * (A * (C_base + 4 + 4 * (L + 2) ^ 2)) ≤ 816 * (A ^ 4 * D * Y ^ 6) := by
      calc 48 * (A * (C_base + 4 + 4 * (L + 2) ^ 2))
          ≤ 48 * (17 * (A * D * Y ^ 2)) :=
            Nat.mul_le_mul_left 48 (by simpa [mul_assoc] using hB_ub)
        _ ≤ 48 * (17 * (A ^ 4 * D * Y ^ 6)) :=
            Nat.mul_le_mul_left 48 (Nat.mul_le_mul_left 17 h3)
        _ = 816 * (A ^ 4 * D * Y ^ 6) := by ring
    calc 240 + 28 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1) +
          48 * (A * (C_base + 4 + 4 * (L + 2) ^ 2)) + 12 * ℓ
        ≤ 240 * (A ^ 4 * D * Y ^ 6) + 1372 * (A ^ 4 * D * Y ^ 6) +
            816 * (A ^ 4 * D * Y ^ 6) + 12 * (A ^ 4 * D * Y ^ 6) :=
          Nat.add_le_add
            (Nat.add_le_add (Nat.add_le_add (Nat.le_mul_of_pos_right 240 h1) hp1) hp2)
            (Nat.mul_le_mul_left 12 h4)
      _ = 2440 * (A ^ 4 * D * Y ^ 6) := by ring
      _ ≤ 3000 * (A ^ 4 * D * Y ^ 6) := Nat.mul_le_mul_right _ (by decide)
  calc (20 + 18 * L) +
        ((120 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1) +
          (ℓ * L * Y) * (70 + 14 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1))) +
        (240 + 28 * (3 * ℓ * ℓ * (L + 2) ^ 4 + 1) +
          48 * (A * (C_base + 4 + 4 * (L + 2) ^ 2)) + 12 * ℓ))
      ≤ 38 * (A ^ 4 * D * Y ^ 6) + (2000 * (A ^ 4 * D * Y ^ 6) + 3000 * (A ^ 4 * D * Y ^ 6)) :=
        Nat.add_le_add ht1 (Nat.add_le_add ht2 ht3)
    _ = 5038 * (A ^ 4 * D * Y ^ 6) := by ring
    _ ≤ 200000 * (A ^ 4 * D * Y ^ 6) := Nat.mul_le_mul_right _ (by decide)
    _ = 200000 * A ^ 4 * D * Y ^ 6 := by ring

theorem exec_buildParamStmt {d : ℕ} (ℓ : ℕ) (hℓ : 1 ≤ ℓ)
    {c_h : ℝ} (hc_h : 0 < c_h)
    (m : ℕ) (hm : 1 ≤ m) {h x : ℝ}
    (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1) :
    let C_base : ℕ := Nat.ceil (2 * Real.log (100 * (ℓ : ℝ)) / c_h) + 1
    let inp : ArithRAMInput d :=
      { intParams := [(m : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0, extraReals := [h, x] }
    let L : ℕ := natBitLength m
    ∃ (memP : ArithRAMMemory) (t : ℝ) (M₀ Cap_u Cap_q : ℕ),
      ExecStmt inp (buildParamStmt ℓ C_base) ArithRAMMemory.empty memP
        (paramCostConst ℓ C_base * (L + 1) ^ 6) ∧
      InParamFootprint memP ∧
      1 ≤ M₀ ∧ 100 ≤ Cap_u ∧ 100 ≤ Cap_q ∧
      1 ≤ t ∧ t ≤ (L + 2 : ℝ) ∧
      wRead memP 0 0 = ((ℓ * M₀ : ℕ) : ℤ) ∧
      wRead memP 1 0 = (m : ℤ) ∧
      wRead memP 1 1 = (M₀ : ℤ) ∧
      wRead memP 1 2 = ((ℓ * M₀ : ℕ) : ℤ) ∧
      wRead memP 1 3 = (Cap_u : ℤ) ∧
      wRead memP 1 4 = (Cap_q : ℤ) ∧
      rRead memP 1 0 = t ∧
      rRead memP 1 1 = x * t ∧
      (M₀ : ℝ) ≤ paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ 2) * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) ∧
      (Cap_u : ℝ) ≤ paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (u_search h x) ∧
      (Cap_q : ℝ) ≤ paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (q_search h x) ∧
      (Cap_q : ℝ) ≤ paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (1 + u_search h x) ∧
      (∀ (p_u p_q p₁ p₂ : ℝ),
        0 ≤ p_u → 0 ≤ p_q → 0 ≤ p₂ →
        p_u ≤ Real.exp (-(t ^ 2 / 2)) →
        p_q ≤ Real.exp (-(x ^ 2 * t ^ 2 / 2)) →
        c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2)) ≤ p₁ →
        p₂ ≤ Real.exp (-((1 + x ^ 2) * t ^ 2 / 2)) →
        0 < p₁ ∧
        Real.log (100 * (ℓ : ℝ)) ≤ p₁ * (M₀ : ℝ) ∧
        100 * ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ + 1) ≤ (Cap_u : ℝ) ∧
        100 * ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ + 1) ≤ (Cap_q : ℝ) ∧
        100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ + 1) ≤ (Cap_q : ℝ)) := by
  intro C_base inp L
  have hC_base_pos : 1 ≤ C_base := by omega
  rcases exec_stepP1Stmt (d := d) m hm h x with ⟨mem₁, hs1, hfp₁, hwm₁, hwL₁⟩
  rcases exec_stepP2Stmt (d := d) ℓ C_base hℓ m hm h x hs1.2.1 hfp₁ hwm₁ hwL₁ with
    ⟨mem₂, t, F_u, hs2, hfp₂, ht1, ht2, hFu_eq, hFu_ge, hexp_ub, hwm₂, hwN₂, hwB₂, hrt₂, hrFu₂⟩
  rcases exec_stepP3Stmt (d := d) ℓ C_base hℓ hC_base_pos m hm hh0 hh1 hx0 hx1
    ht1 ht2 hFu_eq hs2.2.1 hfp₂ hwm₂ hwN₂ hwB₂ hrt₂ hrFu₂ with
    ⟨mem₃, M₀, Cap_u, Cap_q, F₁, F_q, hs3, hfp₃, hM0_ge, hCapu_ge, hCapq_ge,
      hF1_eq, hFq_eq, hM0_lb, hM0_ub, hCapu_lb, hCapu_ub_raw, hCapq_lb, hCapq_ub,
      hw00, hw10, hw11, hw12, hw13, hw14, hr10, hr11⟩

  have htot : ExecStmt inp (buildParamStmt ℓ C_base) ArithRAMMemory.empty mem₃
      (paramCostConst ℓ C_base * (L + 1) ^ 6) :=
    (ExecStmt.seq hs1 (ExecStmt.seq hs2 hs3)).mono_cost (paramCost_le_bound ℓ C_base L)

  rcases I_h_bounds hh0 hh1 hx0 hx1 with ⟨hI1, hI2, hu0, hu1, hq0, hq_le⟩
  have ht_sq_le : t ^ 2 ≤ (L + 2 : ℝ) ^ 2 := pow_le_pow_left₀ (by linarith only [ht1]) ht2 2
  have hbp2_r : (L + 2 : ℝ) ^ 2 ≤ 4 * (L + 1 : ℝ) ^ 2 := by
    have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
    have hb : (L + 2 : ℝ) ≤ 2 * (L + 1 : ℝ) := by linarith only [hL0]
    calc (L + 2 : ℝ) ^ 2 ≤ (2 * (L + 1 : ℝ)) ^ 2 :=
          pow_le_pow_left₀ (by linarith only [hL0]) hb 2
      _ = 4 * (L + 1 : ℝ) ^ 2 := by ring

  have hF1_approx : 1 ≤ F₁ ∧ F₁ ≤ Real.exp (I_h h x * t ^ 2 / 2) ∧
      Real.exp (I_h h x * t ^ 2 / 2) ≤ 2 * F₁ := by
    rw [hF1_eq]
    have hz0 : 0 ≤ I_h h x * t ^ 2 / 2 := by positivity
    have hzub : I_h h x * t ^ 2 / 2 ≤ (L + 2 : ℝ) ^ 2 := by
      have hm1 : I_h h x * t ^ 2 ≤ 2 * t ^ 2 := mul_le_mul_of_nonneg_right hI2 (sq_nonneg t)
      linarith only [hm1, ht_sq_le]
    exact one_plus_div_pow_approx hz0 (three_z1_sq_le_paramN hℓ hz0 hzub)

  have hFu_approx : 1 ≤ F_u ∧ F_u ≤ Real.exp ((ℓ : ℝ) * t ^ 2 / 2) ∧
      Real.exp ((ℓ : ℝ) * t ^ 2 / 2) ≤ 2 * F_u := by
    rw [hFu_eq]
    have hz0 : 0 ≤ (ℓ : ℝ) * t ^ 2 / 2 := by positivity
    have hzub : (ℓ : ℝ) * t ^ 2 / 2 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := by
      have hm1 : (ℓ : ℝ) * t ^ 2 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 :=
        mul_le_mul_of_nonneg_left ht_sq_le (Nat.cast_nonneg ℓ)
      have hnn : 0 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := by positivity
      linarith only [hm1, hnn]
    exact one_plus_div_pow_approx hz0 (three_z_sq_le_paramN hz0 hzub)

  have hFq_approx : 1 ≤ F_q ∧ F_q ≤ Real.exp ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2) ∧
      Real.exp ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2) ≤ 2 * F_q := by
    rw [hFq_eq]
    have hx_pos : 0 < x := lt_of_lt_of_le hh0 hx0
    have hz0 : 0 ≤ (ℓ : ℝ) * x ^ 2 * t ^ 2 / 2 := by positivity
    have hzub : (ℓ : ℝ) * x ^ 2 * t ^ 2 / 2 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := by
      have hx2 : x ^ 2 ≤ 1 := by
        calc x ^ 2 ≤ 1 ^ 2 := pow_le_pow_left₀ hx_pos.le hx1 2
          _ = 1 := one_pow 2
      have hxt : x ^ 2 * t ^ 2 ≤ (L + 2 : ℝ) ^ 2 := by
        calc x ^ 2 * t ^ 2 ≤ 1 * t ^ 2 := mul_le_mul_of_nonneg_right hx2 (sq_nonneg t)
          _ = t ^ 2 := one_mul _
          _ ≤ (L + 2 : ℝ) ^ 2 := ht_sq_le
      have hm1 : (ℓ : ℝ) * (x ^ 2 * t ^ 2) ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 :=
        mul_le_mul_of_nonneg_left hxt (Nat.cast_nonneg ℓ)
      have hnn : 0 ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 := by positivity
      linarith only [hm1, hnn]
    exact one_plus_div_pow_approx hz0 (three_z_sq_le_paramN hz0 hzub)

  let E : ℝ := Real.exp ((ℓ : ℝ) * t ^ 2 / 2)
  have hC_sc1 : 1 ≤ paramScale ℓ := paramScale_ge_one ℓ
  have hC_sc_sq_ge1 : (1 : ℝ) ≤ (paramScale ℓ) ^ 2 := one_le_pow₀ hC_sc1
  have hexp_ub_sc : E ≤ paramScale ℓ * (m : ℝ) := by
    dsimp [E]; rw [paramScale_def]; exact hexp_ub
  have hm1_r : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm

  -- Bound on M₀ in terms of E ^ (I_h / ℓ)
  have hM0_exp_ub : (M₀ : ℝ) ≤
      (8 + 8 * (C_base : ℝ)) * (L + 1 : ℝ) ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) := by
    have ht_L1 : t ^ 2 ≤ 4 * (L + 1 : ℝ) ^ 2 := ht_sq_le.trans hbp2_r
    have hc0 : (0 : ℝ) ≤ (C_base : ℝ) := Nat.cast_nonneg C_base
    have h1 : (C_base : ℝ) * t ^ 2 ≤ 4 * (C_base : ℝ) * (L + 1 : ℝ) ^ 2 := by
      calc (C_base : ℝ) * t ^ 2
          ≤ (C_base : ℝ) * (4 * (L + 1 : ℝ) ^ 2) := mul_le_mul_of_nonneg_left ht_L1 hc0
        _ = 4 * (C_base : ℝ) * (L + 1 : ℝ) ^ 2 := by ring
    have hF1_0 : 0 ≤ F₁ := le_trans zero_le_one hF1_approx.1
    have hR1_le : (C_base : ℝ) * t ^ 2 * F₁ ≤
        4 * (C_base : ℝ) * (L + 1 : ℝ) ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) :=
      mul_le_mul h1 hF1_approx.2.1 hF1_0 (by positivity)
    have hL1 : (1 : ℝ) ≤ (L + 1 : ℝ) ^ 2 :=
      one_le_pow₀ (by have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [hL0])
    have hex1 : (1 : ℝ) ≤ Real.exp (I_h h x * t ^ 2 / 2) :=
      Real.one_le_exp (by positivity)
    have h1_le : (1 : ℝ) ≤ (L + 1 : ℝ) ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) :=
      one_le_mul_of_one_le_of_one_le hL1 hex1
    set U : ℝ := (L + 1 : ℝ) ^ 2 * Real.exp (I_h h x * t ^ 2 / 2)
    have hU0 : 0 ≤ U := le_trans zero_le_one h1_le
    have hmax : max 1 (2 * ((C_base : ℝ) * t ^ 2 * F₁)) ≤
        (8 + 8 * (C_base : ℝ)) * (L + 1 : ℝ) ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) := by
      have hrhs : (8 + 8 * (C_base : ℝ)) * (L + 1 : ℝ) ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) =
          (8 + 8 * (C_base : ℝ)) * U := by dsimp [U]; ring
      rw [hrhs]
      refine max_le ?_ ?_
      · calc (1 : ℝ) ≤ 1 * U := by linarith only [h1_le]
          _ ≤ (8 + 8 * (C_base : ℝ)) * U :=
              mul_le_mul_of_nonneg_right (by linarith only [hc0]) hU0
      · have hR1_U : (C_base : ℝ) * t ^ 2 * F₁ ≤ 4 * (C_base : ℝ) * U := by
          dsimp [U]; linarith only [hR1_le]
        calc 2 * ((C_base : ℝ) * t ^ 2 * F₁)
            ≤ 2 * (4 * (C_base : ℝ) * U) := mul_le_mul_of_nonneg_left hR1_U (by norm_num)
          _ = (8 * (C_base : ℝ)) * U := by ring
          _ ≤ (8 + 8 * (C_base : ℝ)) * U :=
              mul_le_mul_of_nonneg_right (by linarith only [hc0]) hU0
    exact hM0_ub.trans hmax

  -- 1. M₀ ≤ paramPowConst * (L + 1)^2 * m ^ (I_h / ℓ)
  have hM0_final : (M₀ : ℝ) ≤
      paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ 2) * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
    have hexp_eq : Real.exp (I_h h x * t ^ 2 / 2) = E ^ (I_h h x / (ℓ : ℝ)) := by
      dsimp [E]
      rw [← Real.exp_mul]
      congr 1
      have hℓ_ne : (ℓ : ℝ) ≠ 0 := by positivity
      field_simp
    have hIb0 : 0 ≤ I_h h x / (ℓ : ℝ) := by positivity
    have hIb2 : I_h h x / (ℓ : ℝ) ≤ (2 : ℕ) := by
      push_cast
      have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
      rw [div_le_iff₀ (by positivity)]
      calc I_h h x ≤ 2 * 1 := by linarith only [hI2]
        _ ≤ 2 * (ℓ : ℝ) := mul_le_mul_of_nonneg_left hℓ1 (by norm_num)
    have hrp := rpow_scale_le (Real.exp_pos _).le hC_sc1 hexp_ub_sc hIb0 hIb2
    have hbase_le : (8 + 8 * (C_base : ℝ)) ≤ 1000 * ((8 + 8 * (C_base : ℝ)) ^ ℓ) := by
      have hself : (8 + 8 * (C_base : ℝ)) ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) :=
        le_self_pow₀ (by have hc0 : (0 : ℝ) ≤ (C_base : ℝ) := Nat.cast_nonneg C_base; linarith only [hc0]) (by omega)
      have hnn : 0 ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) := by positivity
      linarith only [hself, hnn]
    calc (M₀ : ℝ)
        ≤ (8 + 8 * (C_base : ℝ)) * (L + 1 : ℝ) ^ 2 * E ^ (I_h h x / (ℓ : ℝ)) := by
          rwa [hexp_eq] at hM0_exp_ub
      _ ≤ (8 + 8 * (C_base : ℝ)) * (L + 1 : ℝ) ^ 2 *
            ((paramScale ℓ) ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) :=
          mul_le_mul_of_nonneg_left hrp
            (mul_nonneg (by have hc0 : (0 : ℝ) ≤ (C_base : ℝ) := Nat.cast_nonneg C_base; linarith only [hc0]) (sq_nonneg _))
      _ = (8 + 8 * (C_base : ℝ)) *
            ((paramScale ℓ) ^ 2 * ((L + 1 : ℝ) ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))) := by ring
      _ ≤ (1000 * ((8 + 8 * (C_base : ℝ)) ^ ℓ)) *
            ((paramScale ℓ) ^ 2 * ((L + 1 : ℝ) ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))) :=
          mul_le_mul_of_nonneg_right hbase_le
            (mul_nonneg (sq_nonneg _) (mul_nonneg (sq_nonneg _) (Real.rpow_nonneg (Nat.cast_nonneg m) _)))
      _ = paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ 2) * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
          rw [paramPowConst_def]; ring

  -- Common bound on M₀^ℓ
  have hA_exp_ub : (M₀ : ℝ) ^ ℓ ≤
      ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
        Real.exp ((ℓ : ℝ) * I_h h x * t ^ 2 / 2) := by
    calc (M₀ : ℝ) ^ ℓ
        ≤ ((8 + 8 * (C_base : ℝ)) * (L + 1 : ℝ) ^ 2 * Real.exp (I_h h x * t ^ 2 / 2)) ^ ℓ :=
          pow_le_pow_left₀ (Nat.cast_nonneg M₀) hM0_exp_ub ℓ
      _ = ((8 + 8 * (C_base : ℝ)) ^ ℓ) * (((L + 1 : ℝ) ^ 2) ^ ℓ) *
            (Real.exp (I_h h x * t ^ 2 / 2)) ^ ℓ := by rw [mul_pow, mul_pow]
      _ = ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
            Real.exp ((ℓ : ℝ) * I_h h x * t ^ 2 / 2) := by
          rw [← pow_mul, ← Real.exp_nat_mul]
          congr 2; ring

  -- 2. Cap_u ≤ paramPowConst * (L + 1)^(2ℓ) * m ^ u_search
  have hCapu_final : (Cap_u : ℝ) ≤
      paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (u_search h x) := by
    have hexp_split : Real.exp ((ℓ : ℝ) * I_h h x * t ^ 2 / 2) =
        (E ^ (u_search h x)) * E := by
      dsimp [E]
      rw [← Real.exp_mul, ← Real.exp_add]
      congr 1
      unfold u_search
      ring
    have hdiv_Fu : ((M₀ : ℝ) ^ ℓ) / F_u ≤
        2 * ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) * (E ^ (u_search h x)) := by
      have hFu_pos : 0 < F_u := by linarith only [hFu_approx.1]
      rw [div_le_iff₀ hFu_pos]
      have h1 : (M₀ : ℝ) ^ ℓ ≤
          ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) * ((E ^ (u_search h x)) * E) := by
        rwa [hexp_split] at hA_exp_ub
      have h2 : E ≤ 2 * F_u := hFu_approx.2.2
      calc (M₀ : ℝ) ^ ℓ ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
              (E ^ (u_search h x)) * E := by linarith only [h1]
        _ ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
              (E ^ (u_search h x)) * (2 * F_u) :=
            mul_le_mul_of_nonneg_left h2
              (mul_nonneg (mul_nonneg (by positivity) (by positivity))
                (Real.rpow_nonneg (Real.exp_pos _).le _))
        _ = 2 * ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
              (E ^ (u_search h x)) * F_u := by ring
    have hu_2 : u_search h x ≤ (2 : ℕ) := by push_cast; linarith only [hu1]
    have hrp := rpow_scale_le (Real.exp_pos _).le hC_sc1 hexp_ub_sc hu0 hu_2
    have hm_ge1 : (1 : ℝ) ≤ (m : ℝ) ^ (u_search h x) := Real.one_le_rpow hm1_r hu0
    have hC1_ge1 : (1 : ℝ) ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) :=
      one_le_pow₀ (by have hc0 : (0 : ℝ) ≤ (C_base : ℝ) := Nat.cast_nonneg C_base; linarith only [hc0])
    have hL_ge1 : (1 : ℝ) ≤ (L + 1 : ℝ) ^ (2 * ℓ) :=
      one_le_pow₀ (by have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [hL0])
    set Q_u : ℝ := ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((paramScale ℓ) ^ 2) *
        ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (u_search h x)
    have hprod_ge1 : (1 : ℝ) ≤ Q_u := by
      dsimp [Q_u]
      have h12 : (1 : ℝ) ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((paramScale ℓ) ^ 2) :=
        one_le_mul_of_one_le_of_one_le hC1_ge1 hC_sc_sq_ge1
      have h123 : (1 : ℝ) ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((paramScale ℓ) ^ 2) *
          ((L + 1 : ℝ) ^ (2 * ℓ)) := one_le_mul_of_one_le_of_one_le h12 hL_ge1
      exact one_le_mul_of_one_le_of_one_le h123 hm_ge1
    have hdiv_final : ((M₀ : ℝ) ^ ℓ) / F_u ≤ 2 * Q_u := by
      calc ((M₀ : ℝ) ^ ℓ) / F_u
          ≤ 2 * ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
              ((paramScale ℓ) ^ 2 * (m : ℝ) ^ (u_search h x)) :=
            hdiv_Fu.trans (mul_le_mul_of_nonneg_left hrp (by positivity))
        _ = 2 * Q_u := by dsimp [Q_u]; ring
    have hrhs_eq : paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (u_search h x) =
        1000 * Q_u := by
      rw [paramPowConst_def]; dsimp [Q_u]; ring
    rw [hrhs_eq]
    refine hCapu_ub_raw.trans (max_le ?_ ?_)
    · linarith only [hprod_ge1]
    · linarith only [hprod_ge1, hdiv_final]

  -- 3. Cap_q ≤ paramPowConst * (L + 1)^(2ℓ) * m ^ q_search
  have hCapq_final : (Cap_q : ℝ) ≤
      paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (q_search h x) := by
    have hexp_split : Real.exp ((ℓ : ℝ) * I_h h x * t ^ 2 / 2) =
        (E ^ (q_search h x)) * Real.exp ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2) := by
      dsimp [E]
      rw [← Real.exp_mul, ← Real.exp_add]
      congr 1
      unfold q_search
      ring
    have hdiv_Fq : ((M₀ : ℝ) ^ ℓ) / F_q ≤
        2 * ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) * (E ^ (q_search h x)) := by
      have hFq_pos : 0 < F_q := by linarith only [hFq_approx.1]
      rw [div_le_iff₀ hFq_pos]
      have h1 : (M₀ : ℝ) ^ ℓ ≤
          ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
            ((E ^ (q_search h x)) * Real.exp ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) := by
        rwa [hexp_split] at hA_exp_ub
      calc (M₀ : ℝ) ^ ℓ
          ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
              (E ^ (q_search h x)) * Real.exp ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2) := by linarith only [h1]
        _ ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
              (E ^ (q_search h x)) * (2 * F_q) :=
            mul_le_mul_of_nonneg_left hFq_approx.2.2
              (mul_nonneg (mul_nonneg (by positivity) (by positivity))
                (Real.rpow_nonneg (Real.exp_pos _).le _))
        _ = 2 * ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
              (E ^ (q_search h x)) * F_q := by ring
    have hq_2 : q_search h x ≤ (2 : ℕ) := by push_cast; linarith only [hq_le, hu1]
    have hrp := rpow_scale_le (Real.exp_pos _).le hC_sc1 hexp_ub_sc hq0 hq_2
    have hm_ge1 : (1 : ℝ) ≤ (m : ℝ) ^ (q_search h x) := Real.one_le_rpow hm1_r hq0
    have hC1_ge1 : (1 : ℝ) ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) :=
      one_le_pow₀ (by have hc0 : (0 : ℝ) ≤ (C_base : ℝ) := Nat.cast_nonneg C_base; linarith only [hc0])
    have hL_ge1 : (1 : ℝ) ≤ (L + 1 : ℝ) ^ (2 * ℓ) :=
      one_le_pow₀ (by have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [hL0])
    set Q_q : ℝ := ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((paramScale ℓ) ^ 2) *
        ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (q_search h x)
    have hprod_ge1 : (1 : ℝ) ≤ Q_q := by
      dsimp [Q_q]
      have h12 : (1 : ℝ) ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((paramScale ℓ) ^ 2) :=
        one_le_mul_of_one_le_of_one_le hC1_ge1 hC_sc_sq_ge1
      have h123 : (1 : ℝ) ≤ ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((paramScale ℓ) ^ 2) *
          ((L + 1 : ℝ) ^ (2 * ℓ)) := one_le_mul_of_one_le_of_one_le h12 hL_ge1
      exact one_le_mul_of_one_le_of_one_le h123 hm_ge1
    have hdiv_final : ((M₀ : ℝ) ^ ℓ) / F_q ≤ 2 * Q_q := by
      calc ((M₀ : ℝ) ^ ℓ) / F_q
          ≤ 2 * ((8 + 8 * (C_base : ℝ)) ^ ℓ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
              ((paramScale ℓ) ^ 2 * (m : ℝ) ^ (q_search h x)) :=
            hdiv_Fq.trans (mul_le_mul_of_nonneg_left hrp (by positivity))
        _ = 2 * Q_q := by dsimp [Q_q]; ring
    have hrhs_eq : paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (q_search h x) =
        1000 * Q_q := by
      rw [paramPowConst_def]; dsimp [Q_q]; ring
    rw [hrhs_eq]
    refine hCapq_ub.trans (max_le ?_ ?_)
    · linarith only [hprod_ge1]
    · linarith only [hprod_ge1, hdiv_final]

  -- 4. Cap_q ≤ paramPowConst * (L + 1)^(2ℓ) * m ^ (1 + u_search)
  have hCapq_space : (Cap_q : ℝ) ≤
      paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (1 + u_search h x) := by
    have hm_mono : (m : ℝ) ^ (q_search h x) ≤ (m : ℝ) ^ (1 + u_search h x) :=
      Real.rpow_le_rpow_of_exponent_le hm1_r hq_le
    exact hCapq_final.trans
      (mul_le_mul_of_nonneg_left hm_mono (mul_nonneg (paramPowConst_nonneg ℓ C_base) (by positivity)))

  refine ⟨mem₃, t, M₀, Cap_u, Cap_q, htot, hfp₃, hM0_ge, hCapu_ge, hCapq_ge,
    ht1, ht2, hw00, hw10, hw11, hw12, hw13, hw14, hr10, hr11,
    hM0_final, hCapu_final, hCapq_final, hCapq_space, ?_⟩

  -- 5. Probability inequalities for H5_Prob.goodEvent_prob_ge
  intro p_u p_q p₁ p₂ hpu0 hpq0 hp₂0 hpu_ub hpq_ub hp₁_lb hp₂_ub
  have ht_pos : 0 < t := by linarith only [ht1]
  have ht_zpow_eq : t ^ (-2 : ℤ) = (t ^ 2)⁻¹ := by
    rw [zpow_neg, zpow_two, ← sq]
  have hp₁_pos : 0 < p₁ := by
    have hpos : 0 < c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2)) := by
      rw [ht_zpow_eq]; positivity
    linarith only [hpos, hp₁_lb]

  have hlog_p₁M : Real.log (100 * (ℓ : ℝ)) ≤ p₁ * (M₀ : ℝ) := by
    have hCb_ge : 2 * Real.log (100 * (ℓ : ℝ)) / c_h ≤ (C_base : ℝ) := by
      change 2 * Real.log (100 * (ℓ : ℝ)) / c_h ≤
        ((Nat.ceil (2 * Real.log (100 * (ℓ : ℝ)) / c_h) + 1 : ℕ) : ℝ)
      have hceil := Nat.le_ceil (2 * Real.log (100 * (ℓ : ℝ)) / c_h)
      push_cast; linarith only [hceil]
    have hlog_le : 2 * Real.log (100 * (ℓ : ℝ)) ≤ c_h * (C_base : ℝ) := by
      rw [div_le_iff₀ hc_h] at hCb_ge
      linarith only [hCb_ge]
    have hexp_inv : (2 * F₁)⁻¹ ≤ Real.exp (-(I_h h x * t ^ 2 / 2)) := by
      rw [Real.exp_neg]
      exact inv_anti₀ (Real.exp_pos _) hF1_approx.2.2
    have hF1_pos : 0 < F₁ := by linarith only [hF1_approx.1]
    have hprod_lb : c_h * (C_base : ℝ) / 2 ≤ p₁ * (M₀ : ℝ) := by
      have hp1_lo2 : c_h * (t ^ 2)⁻¹ * (2 * F₁)⁻¹ ≤ p₁ := by
        calc c_h * (t ^ 2)⁻¹ * (2 * F₁)⁻¹
            ≤ c_h * (t ^ 2)⁻¹ * Real.exp (-(I_h h x * t ^ 2 / 2)) :=
              mul_le_mul_of_nonneg_left hexp_inv (by positivity)
          _ = c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2)) := by rw [ht_zpow_eq]
          _ ≤ p₁ := hp₁_lb
      calc c_h * (C_base : ℝ) / 2
          = (c_h * (t ^ 2)⁻¹ * (2 * F₁)⁻¹) * ((C_base : ℝ) * t ^ 2 * F₁) := by
            have ht_ne : t ^ 2 ≠ 0 := by positivity
            have hF1_ne : F₁ ≠ 0 := hF1_pos.ne'
            field_simp
        _ ≤ p₁ * (M₀ : ℝ) :=
            mul_le_mul hp1_lo2 hM0_lb (by positivity) hp₁_pos.le
    linarith only [hlog_le, hprod_lb]

  have hpu_pow : p_u ^ ℓ ≤ F_u⁻¹ := by
    have hFu_pos : 0 < F_u := by linarith only [hFu_approx.1]
    calc p_u ^ ℓ ≤ (Real.exp (-(t ^ 2 / 2))) ^ ℓ := pow_le_pow_left₀ hpu0 hpu_ub ℓ
      _ = Real.exp (-((ℓ : ℝ) * t ^ 2 / 2)) := by
          rw [← Real.exp_nat_mul]; congr 1; ring
      _ = (Real.exp ((ℓ : ℝ) * t ^ 2 / 2))⁻¹ := Real.exp_neg _
      _ ≤ F_u⁻¹ := inv_anti₀ hFu_pos hFu_approx.2.1

  have hpq_pow : p_q ^ ℓ ≤ F_q⁻¹ := by
    have hFq_pos : 0 < F_q := by linarith only [hFq_approx.1]
    calc p_q ^ ℓ ≤ (Real.exp (-(x ^ 2 * t ^ 2 / 2))) ^ ℓ := pow_le_pow_left₀ hpq0 hpq_ub ℓ
      _ = Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) := by
          rw [← Real.exp_nat_mul]; congr 1; ring
      _ = (Real.exp ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2))⁻¹ := Real.exp_neg _
      _ ≤ F_q⁻¹ := inv_anti₀ hFq_pos hFq_approx.2.1

  have hp₂_pow : p₂ ^ ℓ ≤ F_u⁻¹ * F_q⁻¹ := by
    have hFu_pos : 0 < F_u := by linarith only [hFu_approx.1]
    have hFq_pos : 0 < F_q := by linarith only [hFq_approx.1]
    calc p₂ ^ ℓ ≤ (Real.exp (-((1 + x ^ 2) * t ^ 2 / 2))) ^ ℓ := pow_le_pow_left₀ hp₂0 hp₂_ub ℓ
      _ = Real.exp (-((ℓ : ℝ) * t ^ 2 / 2) + -((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) := by
          rw [← Real.exp_nat_mul]; congr 1; ring
      _ = Real.exp (-((ℓ : ℝ) * t ^ 2 / 2)) * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) :=
          Real.exp_add _ _
      _ = (Real.exp ((ℓ : ℝ) * t ^ 2 / 2))⁻¹ * (Real.exp ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2))⁻¹ := by
          rw [Real.exp_neg, Real.exp_neg]
      _ ≤ F_u⁻¹ * F_q⁻¹ :=
          mul_le_mul (inv_anti₀ hFu_pos hFu_approx.2.1)
            (inv_anti₀ hFq_pos hFq_approx.2.1)
            (by positivity) (inv_nonneg.mpr hFu_pos.le)

  have hcap_u_ok : 100 * ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ + 1) ≤ (Cap_u : ℝ) := by
    have h1 : (M₀ : ℝ) ^ ℓ * p_u ^ ℓ ≤ ((M₀ : ℝ) ^ ℓ) / F_u := by
      rw [div_eq_mul_inv]; exact mul_le_mul_of_nonneg_left hpu_pow (by positivity)
    linarith only [h1, hCapu_lb]

  have hcap_q_ok : 100 * ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ + 1) ≤ (Cap_q : ℝ) := by
    have h1 : (M₀ : ℝ) ^ ℓ * p_q ^ ℓ ≤ ((M₀ : ℝ) ^ ℓ) / F_q := by
      rw [div_eq_mul_inv]; exact mul_le_mul_of_nonneg_left hpq_pow (by positivity)
    linarith only [h1, hCapq_lb]

  have hcap_bad_ok : 100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ + 1) ≤ (Cap_q : ℝ) := by
    have hm_Fu : (m : ℝ) * F_u⁻¹ ≤ 1 := by
      have hFu_pos : 0 < F_u := by linarith only [hFu_approx.1]
      rw [← div_eq_mul_inv, div_le_one hFu_pos]
      linarith only [hFu_ge, hm1_r]
    have hFq_pos : 0 < F_q := by linarith only [hFq_approx.1]
    have hbad_le : (m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ ≤ ((M₀ : ℝ) ^ ℓ) / F_q := by
      calc (m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ
          ≤ (m : ℝ) * (M₀ : ℝ) ^ ℓ * (F_u⁻¹ * F_q⁻¹) :=
            mul_le_mul_of_nonneg_left hp₂_pow (by positivity)
        _ = ((m : ℝ) * F_u⁻¹) * ((M₀ : ℝ) ^ ℓ * F_q⁻¹) := by ring
        _ ≤ 1 * ((M₀ : ℝ) ^ ℓ * F_q⁻¹) :=
            mul_le_mul_of_nonneg_right hm_Fu
              (mul_nonneg (by positivity) (inv_nonneg.mpr hFq_pos.le))
        _ = ((M₀ : ℝ) ^ ℓ) / F_q := by rw [one_mul, div_eq_mul_inv]
    linarith only [hbad_le, hCapq_lb]

  exact ⟨hp₁_pos, hlog_p₁M, hcap_u_ok, hcap_q_ok, hcap_bad_ok⟩

end UL.Proof.lem_6_3.RacerV30
