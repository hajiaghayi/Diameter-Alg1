import Mathlib
import UL.Def.def_computation_model
set_option autoImplicit false

namespace UL.Proof_lem_6_3

/-! ### 1. Heap-only clean memories and read/write simp lemmas -/

/-- A `WordStore` is clean (contains no positive-depth local frame entries or values) if
`popDepth 0` is the identity. -/
def CleanWords (ws : WordStore) : Prop :=
  ws.popDepth 0 = ws

/-- A `RealStore` is clean if `popDepth 0` is the identity. -/
def CleanReals (rs : RealStore) : Prop :=
  rs.popDepth 0 = rs

/-- An `ArithRAMMemory` is clean if `popDepth 0` is the identity. -/
def CleanMem (mem : ArithRAMMemory) : Prop :=
  mem.popDepth 0 = mem

theorem cleanMem_iff (mem : ArithRAMMemory) :
    CleanMem mem ↔ CleanWords mem.words ∧ CleanReals mem.reals := by
  unfold CleanMem CleanWords CleanReals ArithRAMMemory.popDepth
  cases mem with
  | mk w r => simp

theorem cleanWords_empty : CleanWords WordStore.empty := by
  unfold CleanWords WordStore.popDepth WordStore.empty
  simp

theorem cleanReals_empty : CleanReals RealStore.empty := by
  unfold CleanReals RealStore.popDepth RealStore.empty
  simp

theorem cleanMem_empty : CleanMem ArithRAMMemory.empty := by
  rw [cleanMem_iff]
  exact ⟨cleanWords_empty, cleanReals_empty⟩

theorem cleanWords_write_heap {ws : WordStore} (h : CleanWords ws) (t : ℕ) (i : ℤ) (v : ℤ) :
    CleanWords (ws.write (.heap t i) v) := by
  unfold CleanWords at h ⊢
  have hlive : (ws.popDepth 0).live = ws.live := congrArg WordStore.live h
  have hvals : (ws.popDepth 0).vals = ws.vals := congrArg WordStore.vals h
  cases ws with
  | mk live vals =>
    simp only [WordStore.popDepth] at hlive hvals
    unfold WordStore.write WordStore.popDepth
    congr 1
    · ext loc
      simp only [Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨rfl | hmem, _⟩
        · exact Or.inl rfl
        · exact Or.inr hmem
      · rintro (rfl | hmem)
        · exact ⟨Or.inl rfl, rfl⟩
        · have hmem' : loc ∈ Finset.filter (fun l => l.keepAtDepth 0 = true) live := by
            rw [hlive]; exact hmem
          exact ⟨Or.inr hmem, (Finset.mem_filter.mp hmem').2⟩
    · funext loc
      by_cases heq : loc = .heap t i
      · subst heq
        simp [RAMCellLoc.keepAtDepth]
      · have hv := congrFun hvals loc
        simp [Function.update, heq] at hv ⊢
        exact hv

theorem cleanReals_write_heap {rs : RealStore} (h : CleanReals rs) (t : ℕ) (i : ℤ) (v : ℝ) :
    CleanReals (rs.write (.heap t i) v) := by
  unfold CleanReals at h ⊢
  have hlive : (rs.popDepth 0).live = rs.live := congrArg RealStore.live h
  have hvals : (rs.popDepth 0).vals = rs.vals := congrArg RealStore.vals h
  cases rs with
  | mk live vals =>
    simp only [RealStore.popDepth] at hlive hvals
    unfold RealStore.write RealStore.popDepth
    congr 1
    · ext loc
      simp only [Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨rfl | hmem, _⟩
        · exact Or.inl rfl
        · exact Or.inr hmem
      · rintro (rfl | hmem)
        · exact ⟨Or.inl rfl, rfl⟩
        · have hmem' : loc ∈ Finset.filter (fun l => l.keepAtDepth 0 = true) live := by
            rw [hlive]; exact hmem
          exact ⟨Or.inr hmem, (Finset.mem_filter.mp hmem').2⟩
    · funext loc
      by_cases heq : loc = .heap t i
      · subst heq
        simp [RAMCellLoc.keepAtDepth]
      · have hv := congrFun hvals loc
        simp [Function.update, heq] at hv ⊢
        exact hv

/-- Read word at `.heap t i`. -/
def wRead (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) : ℤ :=
  mem.words.read (.heap t i)

/-- Write word `v` at `.heap t i`. -/
def wWrite (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℤ) : ArithRAMMemory :=
  { mem with words := mem.words.write (.heap t i) v }

/-- Read real at `.heap t i`. -/
def rRead (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) : ℝ :=
  mem.reals.read (.heap t i)

/-- Write real `v` at `.heap t i`. -/
noncomputable def rWrite (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℝ) : ArithRAMMemory :=
  { mem with reals := mem.reals.write (.heap t i) v }

theorem cleanMem_wWrite {mem : ArithRAMMemory} (h : CleanMem mem) (t : ℕ) (i : ℤ) (v : ℤ) :
    CleanMem (wWrite mem t i v) := by
  rw [cleanMem_iff] at h ⊢
  exact ⟨cleanWords_write_heap h.1 t i v, h.2⟩

theorem cleanMem_rWrite {mem : ArithRAMMemory} (h : CleanMem mem) (t : ℕ) (i : ℤ) (v : ℝ) :
    CleanMem (rWrite mem t i v) := by
  rw [cleanMem_iff] at h ⊢
  exact ⟨h.1, cleanReals_write_heap h.2 t i v⟩

@[simp]
theorem wRead_empty (t : ℕ) (i : ℤ) : wRead ArithRAMMemory.empty t i = 0 := by
  simp [wRead, ArithRAMMemory.empty, WordStore.empty, WordStore.read]

@[simp]
theorem rRead_empty (t : ℕ) (i : ℤ) : rRead ArithRAMMemory.empty t i = 0 := by
  simp [rRead, ArithRAMMemory.empty, RealStore.empty, RealStore.read]

@[simp]
theorem wRead_wWrite_self (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℤ) :
    wRead (wWrite mem t i v) t i = v := by
  simp [wRead, wWrite, WordStore.read, WordStore.write]

theorem wRead_wWrite_of_ne (mem : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℤ)
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    wRead (wWrite mem t₂ i₂ v) t₁ i₁ = wRead mem t₁ i₁ := by
  have hloc : (RAMCellLoc.heap t₁ i₁) ≠ (RAMCellLoc.heap t₂ i₂) := by
    intro h
    cases h
    rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [wRead, wWrite, WordStore.read, WordStore.write, hloc]

@[simp]
theorem wRead_rWrite (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) (v : ℝ) :
    wRead (rWrite mem t₂ i₂ v) t₁ i₁ = wRead mem t₁ i₁ := rfl

@[simp]
theorem rRead_wWrite (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) (v : ℤ) :
    rRead (wWrite mem t₂ i₂ v) t₁ i₁ = rRead mem t₁ i₁ := rfl

@[simp]
theorem rRead_rWrite_self (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℝ) :
    rRead (rWrite mem t i v) t i = v := by
  simp [rRead, rWrite, RealStore.read, RealStore.write]

theorem rRead_rWrite_of_ne (mem : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℝ)
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    rRead (rWrite mem t₂ i₂ v) t₁ i₁ = rRead mem t₁ i₁ := by
  have hloc : (RAMCellLoc.heap t₁ i₁) ≠ (RAMCellLoc.heap t₂ i₂) := by
    intro h
    cases h
    rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [rRead, rWrite, RealStore.read, RealStore.write, hloc]

theorem cellCount_le_wWrite (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℤ) :
    mem.cellCount ≤ (wWrite mem t i v).cellCount := by
  unfold ArithRAMMemory.cellCount wWrite WordStore.cellCount WordStore.write
  gcongr
  exact Finset.subset_insert _ _

theorem cellCount_le_rWrite (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℝ) :
    mem.cellCount ≤ (rWrite mem t i v).cellCount := by
  unfold ArithRAMMemory.cellCount rWrite RealStore.cellCount RealStore.write
  gcongr
  exact Finset.subset_insert _ _

theorem cellCount_le_of_subset {mem : ArithRAMMemory} {W R : Finset RAMCellLoc}
    (hW : mem.words.live ⊆ W) (hR : mem.reals.live ⊆ R) :
    mem.cellCount ≤ W.card + R.card := by
  unfold ArithRAMMemory.cellCount WordStore.cellCount RealStore.cellCount
  exact Nat.add_le_add (Finset.card_le_card hW) (Finset.card_le_card hR)

/-! ### 2. Fuel monotonicity of `runArithRAMFuel` -/

theorem runArithRAMFuel_mono {d : ℕ} (inp : ArithRAMInput d) :
    ∀ {fuel₁ fuel₂ : ℕ} {stack : List ArithRAMCont} {st : ArithRAMExecState}
      {res : ArithRAMRunStatus},
      res ≠ .outOfFuel →
      fuel₁ ≤ fuel₂ →
      runArithRAMFuel inp fuel₁ stack st = res →
      runArithRAMFuel inp fuel₂ stack st = res
  | f₁, f₂, [], st, res, _, _, hrun => by
      cases f₁ <;> cases f₂ <;> simpa [runArithRAMFuel] using hrun
  | 0, _, _ :: _, _, res, hne, _, hrun => by
      simp [runArithRAMFuel] at hrun
      exact absurd hrun.symm hne
  | f₁ + 1, 0, _ :: _, _, _, _, hle, _ => by omega
  | f₁ + 1, f₂ + 1, item :: rest, st, res, hne, hle, hrun => by
      have hle' : f₁ ≤ f₂ := by omega
      cases item with
      | popScope prev =>
          simp only [runArithRAMFuel] at hrun ⊢
          exact runArithRAMFuel_mono inp hne hle' hrun
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | succ r =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
      | stmt s =>
          cases s with
          | skip =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | writeWordHeap table idxE valE =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | writeWordLocal var idxE valE =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | freeWordHeap table idxE =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | freeWordLocal var idxE =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | writeRealHeap table idxE valE =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | writeRealLocal var idxE valE =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | freeRealHeap table idxE =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | freeRealLocal var idxE =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | randBitHeap table idxE =>
              cases hbits : st.remainingBits with
              | nil =>
                  simp [runArithRAMFuel, hbits] at hrun ⊢
                  exact hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun ⊢
                  exact runArithRAMFuel_mono inp hne hle' hrun
          | randBitLocal var idxE =>
              cases hbits : st.remainingBits with
              | nil =>
                  simp [runArithRAMFuel, hbits] at hrun ⊢
                  exact hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun ⊢
                  exact runArithRAMFuel_mono inp hne hle' hrun
          | seq s₁ s₂ =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | ite cond tBranch fBranch =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | whileLoop cond body =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | repeatN countE body =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | localScope body =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun

theorem runArithRAMWithBits_eq_some_of_fuel {d : ℕ} (prog : ArithRAMStmt) (inp : ArithRAMInput d)
    (initMem : ArithRAMMemory) (bs : List Bool) (fuel : ℕ) (out : ArithRAMExecOutcome)
    (hrun : runArithRAMFuel inp fuel [.stmt prog]
      { mem := initMem.popDepth 0
        frameDepth := 0
        remainingBits := bs
        unitCost := 0
        peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } = .halted out) :
    runArithRAMWithBits prog inp initMem bs = some out := by
  classical
  unfold runArithRAMWithBits
  dsimp only
  have hex : ∃ f : ℕ, ∃ o : ArithRAMExecOutcome,
      runArithRAMFuel inp f [.stmt prog]
        { mem := initMem.popDepth 0, frameDepth := 0, remainingBits := bs,
          unitCost := 0, peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } =
        .halted o := ⟨fuel, out, hrun⟩
  rw [dif_pos hex]
  have hle : Nat.find hex ≤ fuel := Nat.find_min' hex ⟨out, hrun⟩
  rcases Nat.find_spec hex with ⟨o₀, ho₀⟩
  have heq : ArithRAMRunStatus.halted o₀ = .halted out := by
    have hm := runArithRAMFuel_mono inp (by simp) hle ho₀
    rw [hrun] at hm
    exact hm.symm
  cases heq
  simp [ho₀]

/-! ### 3. Compositional big-step relation `ExecStmt` for deterministic heap-only programs -/

/-- State builder at depth `0` with no random bits and exact monotone peak cell space. -/
def mkState {d : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory) (u : ℕ) : ArithRAMExecState :=
  { mem := mem
    frameDepth := 0
    remainingBits := []
    unitCost := u
    peakCellSpace := inp.inputCellSpace + mem.cellCount }

/-- Deterministic big-step execution of a heap-only `ArithRAMStmt` from `mem₀` to `mem₁`
within unit-cost budget `costBound`. -/
def ExecStmt {d : ℕ} (inp : ArithRAMInput d) (s : ArithRAMStmt)
    (mem₀ mem₁ : ArithRAMMemory) (costBound : ℕ) : Prop :=
  CleanMem mem₀ ∧ CleanMem mem₁ ∧
  ∀ (u₀ : ℕ) (rest : List ArithRAMCont),
    ∃ (fuel₀ u₁ : ℕ),
      u₁ ≤ u₀ + costBound ∧
      ∀ fuel : ℕ,
        runArithRAMFuel inp (fuel₀ + fuel) (.stmt s :: rest) (mkState inp mem₀ u₀) =
          runArithRAMFuel inp fuel rest (mkState inp mem₁ u₁)

theorem ExecStmt.mono_cost {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {mem₀ mem₁ : ArithRAMMemory} {c₁ c₂ : ℕ}
    (h : ExecStmt inp s mem₀ mem₁ c₁) (hle : c₁ ≤ c₂) :
    ExecStmt inp s mem₀ mem₁ c₂ := by
  refine ⟨h.1, h.2.1, fun u₀ rest => ?_⟩
  rcases h.2.2 u₀ rest with ⟨fuel₀, u₁, hu₁, hstep⟩
  exact ⟨fuel₀, u₁, by omega, hstep⟩

theorem ExecStmt.to_run {d : ℕ} {inp : ArithRAMInput d} {prog : ArithRAMStmt}
    {mem₀ mem₁ : ArithRAMMemory} {C : ℕ}
    (h : ExecStmt inp prog mem₀ mem₁ C) :
    ∃ out : ArithRAMExecOutcome,
      runArithRAMWithBits prog inp mem₀ [] = some out ∧
      out.mem = mem₁ ∧
      out.unitCost ≤ C ∧
      out.peakCellSpace = inp.inputCellSpace + mem₁.cellCount := by
  rcases h with ⟨hclean₀, hclean₁, hrun⟩
  rcases hrun 0 [] with ⟨fuel₀, u₁, hu₁, hstep⟩
  let out : ArithRAMExecOutcome :=
    { mem := mem₁, unitCost := u₁, peakCellSpace := inp.inputCellSpace + mem₁.cellCount }
  refine ⟨out, ?_, rfl, by dsimp [out]; omega, rfl⟩
  apply runArithRAMWithBits_eq_some_of_fuel prog inp mem₀ [] (fuel₀ + 1) out
  rw [hclean₀]
  change runArithRAMFuel inp (fuel₀ + 1) [.stmt prog] (mkState inp mem₀ 0) = .halted out
  rw [hstep 1]
  dsimp [runArithRAMFuel, mkState, out]
  rw [hclean₁]

theorem ExecStmt.skip {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory} (hc : CleanMem mem) :
    ExecStmt inp .skip mem mem 1 := by
  refine ⟨hc, hc, fun u₀ rest => ⟨1, u₀ + 1, le_rfl, fun fuel => ?_⟩⟩
  rw [Nat.add_comm 1 fuel]
  rfl

theorem ExecStmt.writeWordHeap {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (table : ℕ) (idxE valE : IntExpr) {idx val : ℤ} {u₁ u₂ b₁ b₂ C : ℕ}
    (hidx : evalIntExpr inp.toWordView 0 mem.words idxE = (idx, u₁, b₁))
    (hval : evalIntExpr inp.toWordView 0 mem.words valE = (val, u₂, b₂))
    (hcost : u₁ + u₂ + 1 ≤ C) :
    ExecStmt inp (.writeWordHeap table idxE valE) mem (wWrite mem table idx val) C := by
  refine ⟨hc, cleanMem_wWrite hc table idx val, fun u₀ rest => ?_⟩
  refine ⟨1, u₀ + u₁ + u₂ + 1, by omega, fun fuel => ?_⟩
  rw [Nat.add_comm 1 fuel]
  have hle : inp.inputCellSpace + mem.cellCount ≤
      inp.inputCellSpace + (wWrite mem table idx val).cellCount :=
    Nat.add_le_add_left (cellCount_le_wWrite mem table idx val) _
  dsimp only [runArithRAMFuel, mkState]
  rw [hidx, hval]
  dsimp only
  change runArithRAMFuel inp fuel rest
    { mem := wWrite mem table idx val, frameDepth := 0, remainingBits := [],
      unitCost := u₀ + u₁ + u₂ + 1,
      peakCellSpace := max (inp.inputCellSpace + mem.cellCount)
        (inp.inputCellSpace + (wWrite mem table idx val).cellCount) } = _
  rw [max_eq_right hle]

theorem ExecStmt.writeRealHeap {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (table : ℕ) (idxE : IntExpr) (valE : RealExpr)
    {idx : ℤ} {val : ℝ} {u₁ b₁ u₂ C : ℕ}
    (hidx : evalIntExpr inp.toWordView 0 mem.words idxE = (idx, u₁, b₁))
    (hval : evalRealExpr inp 0 mem valE = (val, u₂))
    (hcost : u₁ + u₂ + 1 ≤ C) :
    ExecStmt inp (.writeRealHeap table idxE valE) mem (rWrite mem table idx val) C := by
  refine ⟨hc, cleanMem_rWrite hc table idx val, fun u₀ rest => ?_⟩
  refine ⟨1, u₀ + u₁ + u₂ + 1, by omega, fun fuel => ?_⟩
  rw [Nat.add_comm 1 fuel]
  have hle : inp.inputCellSpace + mem.cellCount ≤
      inp.inputCellSpace + (rWrite mem table idx val).cellCount :=
    Nat.add_le_add_left (cellCount_le_rWrite mem table idx val) _
  dsimp only [runArithRAMFuel, mkState]
  rw [hidx, hval]
  dsimp only
  change runArithRAMFuel inp fuel rest
    { mem := rWrite mem table idx val, frameDepth := 0, remainingBits := [],
      unitCost := u₀ + u₁ + u₂ + 1,
      peakCellSpace := max (inp.inputCellSpace + mem.cellCount)
        (inp.inputCellSpace + (rWrite mem table idx val).cellCount) } = _
  rw [max_eq_right hle]

theorem ExecStmt.seq {d : ℕ} {inp : ArithRAMInput d} {s₁ s₂ : ArithRAMStmt}
    {mem₀ mem₁ mem₂ : ArithRAMMemory} {C₁ C₂ : ℕ}
    (h₁ : ExecStmt inp s₁ mem₀ mem₁ C₁)
    (h₂ : ExecStmt inp s₂ mem₁ mem₂ C₂) :
    ExecStmt inp (.seq s₁ s₂) mem₀ mem₂ (C₁ + C₂) := by
  refine ⟨h₁.1, h₂.2.1, fun u₀ rest => ?_⟩
  rcases h₁.2.2 u₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, hu₁, hs₁⟩
  rcases h₂.2.2 u₁ rest with ⟨f₂, u₂, hu₂, hs₂⟩
  refine ⟨1 + f₁ + f₂, u₂, by omega, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + f₂ + fuel = (f₁ + (f₂ + fuel)) + 1 := by omega
  rw [hfuel]
  dsimp only [runArithRAMFuel]
  rw [hs₁ (f₂ + fuel), hs₂ fuel]

theorem ExecStmt.ite_true {d : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {tB fB : ArithRAMStmt} {mem₀ mem₁ : ArithRAMMemory} {u_c C_c C_b : ℕ}
    (hcond : evalArithCond inp 0 mem₀ cond = (true, u_c))
    (huc : u_c ≤ C_c)
    (ht : ExecStmt inp tB mem₀ mem₁ C_b) :
    ExecStmt inp (.ite cond tB fB) mem₀ mem₁ (C_c + C_b) := by
  refine ⟨ht.1, ht.2.1, fun u₀ rest => ?_⟩
  rcases ht.2.2 (u₀ + u_c) rest with ⟨f₁, u₁, hu₁, hstep⟩
  refine ⟨1 + f₁, u₁, by omega, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + fuel = (f₁ + fuel) + 1 := by omega
  rw [hfuel]
  simp only [runArithRAMFuel, mkState, hcond, ↓reduceIte]
  exact hstep fuel

theorem ExecStmt.ite_false {d : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {tB fB : ArithRAMStmt} {mem₀ mem₁ : ArithRAMMemory} {u_c C_c C_b : ℕ}
    (hcond : evalArithCond inp 0 mem₀ cond = (false, u_c))
    (huc : u_c ≤ C_c)
    (hf : ExecStmt inp fB mem₀ mem₁ C_b) :
    ExecStmt inp (.ite cond tB fB) mem₀ mem₁ (C_c + C_b) := by
  refine ⟨hf.1, hf.2.1, fun u₀ rest => ?_⟩
  rcases hf.2.2 (u₀ + u_c) rest with ⟨f₁, u₁, hu₁, hstep⟩
  refine ⟨1 + f₁, u₁, by omega, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + fuel = (f₁ + fuel) + 1 := by omega
  rw [hfuel]
  simp only [runArithRAMFuel, mkState, hcond, Bool.false_eq_true, ↓reduceIte]
  exact hstep fuel

theorem ExecStmt.whileLoop_false {d : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {body : ArithRAMStmt} {mem : ArithRAMMemory} {u_c C_c : ℕ}
    (hc : CleanMem mem)
    (hcond : evalArithCond inp 0 mem cond = (false, u_c))
    (huc : u_c ≤ C_c) :
    ExecStmt inp (.whileLoop cond body) mem mem C_c := by
  refine ⟨hc, hc, fun u₀ rest => ⟨1, u₀ + u_c, by omega, fun fuel => ?_⟩⟩
  rw [Nat.add_comm 1 fuel]
  simp [runArithRAMFuel, mkState, hcond]

theorem ExecStmt.whileLoop_true {d : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {body : ArithRAMStmt} {mem₀ mem₁ mem₂ : ArithRAMMemory} {u_c C_c C_b C_rest : ℕ}
    (hcond : evalArithCond inp 0 mem₀ cond = (true, u_c))
    (huc : u_c ≤ C_c)
    (hbody : ExecStmt inp body mem₀ mem₁ C_b)
    (hrest : ExecStmt inp (.whileLoop cond body) mem₁ mem₂ C_rest) :
    ExecStmt inp (.whileLoop cond body) mem₀ mem₂ (C_c + C_b + C_rest) := by
  refine ⟨hbody.1, hrest.2.1, fun u₀ rest => ?_⟩
  rcases hbody.2.2 (u₀ + u_c) (.stmt (.whileLoop cond body) :: rest) with ⟨f₁, u₁, hu₁, hs₁⟩
  rcases hrest.2.2 u₁ rest with ⟨f₂, u₂, hu₂, hs₂⟩
  refine ⟨1 + f₁ + f₂, u₂, by omega, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + f₂ + fuel = (f₁ + (f₂ + fuel)) + 1 := by omega
  rw [hfuel]
  simp only [runArithRAMFuel, mkState, hcond, ↓reduceIte]
  change runArithRAMFuel inp (f₁ + (f₂ + fuel)) (.stmt body :: .stmt (.whileLoop cond body) :: rest)
      (mkState inp mem₀ (u₀ + u_c)) =
    runArithRAMFuel inp fuel rest (mkState inp mem₂ u₂)
  rw [hs₁ (f₂ + fuel), hs₂ fuel]

/-- Indexed `N`-iteration `whileLoop` rule with invariant `Inv : ℕ → ArithRAMMemory → Prop`. -/
theorem ExecStmt.whileLoop_nat {d : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {body : ArithRAMStmt} (N C_c C_b : ℕ) (Inv : ℕ → ArithRAMMemory → Prop)
    {mem₀ : ArithRAMMemory} (hc₀ : CleanMem mem₀) (hInv₀ : Inv 0 mem₀)
    (hstep : ∀ i < N, ∀ m : ArithRAMMemory, CleanMem m → Inv i m →
      (∃ u_c, evalArithCond inp 0 m cond = (true, u_c) ∧ u_c ≤ C_c) ∧
      (∃ m', ExecStmt inp body m m' C_b ∧ Inv (i + 1) m'))
    (hexit : ∀ m : ArithRAMMemory, CleanMem m → Inv N m →
      ∃ u_c, evalArithCond inp 0 m cond = (false, u_c) ∧ u_c ≤ C_c) :
    ∃ mem_N : ArithRAMMemory,
      Inv N mem_N ∧
      ExecStmt inp (.whileLoop cond body) mem₀ mem_N ((N + 1) * C_c + N * C_b) := by
  suffices hrem : ∀ k : ℕ, k ≤ N → ∀ m : ArithRAMMemory, CleanMem m → Inv (N - k) m →
      ∃ m_N : ArithRAMMemory,
        Inv N m_N ∧
        ExecStmt inp (.whileLoop cond body) m m_N ((k + 1) * C_c + k * C_b) by
    simpa using hrem N le_rfl mem₀ hc₀ (by simpa using hInv₀)
  intro k
  induction k with
  | zero =>
      intro _ m hcm hIm
      rw [Nat.sub_zero] at hIm
      rcases hexit m hcm hIm with ⟨u_c, hcond, huc⟩
      refine ⟨m, hIm, ?_⟩
      simpa using ExecStmt.whileLoop_false hcm hcond huc
  | succ k ih =>
      intro hk m hcm hIm
      have hi_lt : N - (k + 1) < N := by omega
      have hsucc : N - (k + 1) + 1 = N - k := by omega
      rcases hstep (N - (k + 1)) hi_lt m hcm hIm with ⟨⟨u_c, hcond, huc⟩, ⟨m', hbody, hIm'⟩⟩
      rw [hsucc] at hIm'
      rcases ih (by omega) m' hbody.2.1 hIm' with ⟨m_N, hIm_N, hrest⟩
      refine ⟨m_N, hIm_N, ?_⟩
      refine (ExecStmt.whileLoop_true hcond huc hbody hrest).mono_cost ?_
      linarith

/-- Indexed `N`-iteration `repeatN` rule with invariant `Inv : ℕ → ArithRAMMemory → Prop`. -/
theorem ExecStmt.repeatN_nat {d : ℕ} {inp : ArithRAMInput d} {countE : IntExpr}
    {body : ArithRAMStmt} (N C_cnt C_b : ℕ) (Inv : ℕ → ArithRAMMemory → Prop)
    {mem₀ : ArithRAMMemory} (hc₀ : CleanMem mem₀) (hInv₀ : Inv 0 mem₀)
    {u_cnt b_cnt : ℕ}
    (hcnt : evalIntExpr inp.toWordView 0 mem₀.words countE = ((N : ℤ), u_cnt, b_cnt))
    (hucnt : u_cnt ≤ C_cnt)
    (hstep : ∀ i < N, ∀ m : ArithRAMMemory, CleanMem m → Inv i m →
      ∃ m', ExecStmt inp body m m' C_b ∧ Inv (i + 1) m') :
    ∃ mem_N : ArithRAMMemory,
      Inv N mem_N ∧
      ExecStmt inp (.repeatN countE body) mem₀ mem_N (C_cnt + N * C_b) := by
  have hloop : ∀ k : ℕ, k ≤ N → ∀ m : ArithRAMMemory, CleanMem m → Inv (N - k) m →
      ∃ m_N : ArithRAMMemory, CleanMem m_N ∧ Inv N m_N ∧
        ∀ (u₀ : ℕ) (rest : List ArithRAMCont),
          ∃ (fuel₀ u₁ : ℕ),
            u₁ ≤ u₀ + k * C_b ∧
            ∀ fuel : ℕ,
              runArithRAMFuel inp (fuel₀ + fuel) (.repeatLoop k body :: rest) (mkState inp m u₀) =
                runArithRAMFuel inp fuel rest (mkState inp m_N u₁) := by
    intro k
    induction k with
    | zero =>
        intro _ m hcm hIm
        rw [Nat.sub_zero] at hIm
        refine ⟨m, hcm, hIm, fun u₀ rest => ⟨1, u₀, by simp, fun fuel => ?_⟩⟩
        rw [Nat.add_comm 1 fuel]
        rfl
    | succ k ih =>
        intro hk m hcm hIm
        have hi_lt : N - (k + 1) < N := by omega
        have hsucc : N - (k + 1) + 1 = N - k := by omega
        rcases hstep (N - (k + 1)) hi_lt m hcm hIm with ⟨m', hbody, hIm'⟩
        rw [hsucc] at hIm'
        rcases ih (by omega) m' hbody.2.1 hIm' with ⟨m_N, hcm_N, hIm_N, hrest⟩
        refine ⟨m_N, hcm_N, hIm_N, fun u₀ rest => ?_⟩
        rcases hbody.2.2 u₀ (.repeatLoop k body :: rest) with ⟨f₁, u₁, hu₁, hs₁⟩
        rcases hrest u₁ rest with ⟨f₂, u₂, hu₂, hs₂⟩
        refine ⟨1 + f₁ + f₂, u₂, ?_, fun fuel => ?_⟩
        · have : u₂ ≤ u₀ + C_b + k * C_b := by omega
          calc u₂ ≤ u₀ + C_b + k * C_b := this
            _ = u₀ + (k + 1) * C_b := by ring
        · have hfuel : 1 + f₁ + f₂ + fuel = (f₁ + (f₂ + fuel)) + 1 := by omega
          rw [hfuel]
          dsimp only [runArithRAMFuel]
          rw [hs₁ (f₂ + fuel), hs₂ fuel]
  rcases hloop N le_rfl mem₀ hc₀ (by simpa using hInv₀) with ⟨m_N, hcm_N, hIm_N, hrun⟩
  refine ⟨m_N, hIm_N, hc₀, hcm_N, fun u₀ rest => ?_⟩
  rcases hrun (u₀ + u_cnt) rest with ⟨f₁, u₁, hu₁, hs₁⟩
  refine ⟨1 + f₁, u₁, by omega, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + fuel = (f₁ + fuel) + 1 := by omega
  rw [hfuel]
  have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
  simp only [runArithRAMFuel, mkState, hcnt, hnIter]
  exact hs₁ fuel

/-- Right-nested sequential composition of a list of `ArithRAMStmt`s. -/
def seqStmts : List ArithRAMStmt → ArithRAMStmt
  | [] => .skip
  | [s] => s
  | s :: ss => .seq s (seqStmts ss)

end UL.Proof_lem_6_3
