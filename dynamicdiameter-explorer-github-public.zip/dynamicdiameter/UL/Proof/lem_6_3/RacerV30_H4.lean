import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_6_search_interface
import UL.Def.def_6_1_gaussian_filter
import UL.Proof.lem_6_3.H1_RAM
import UL.Proof.lem_6_3.H5_Prob
import UL.Proof.lem_6_3.RacerV30_H2
import UL.Proof.lem_6_3.RacerV30_H3
set_option autoImplicit false

namespace UL.Proof.lem_6_3.RacerV30

open UL.Proof_lem_6_3

/-! ### 1. List/real-input helpers and unallocated word-table reads -/

theorem list_getD_eq_getElem {α : Type*} :
    ∀ (l : List α) (n : ℕ) (hn : n < l.length) (d : α), l.getD n d = l[n]
  | [], _, hn, _ => by simp at hn
  | _ :: _, 0, _, _ => rfl
  | _ :: l, n + 1, hn, d => list_getD_eq_getElem l n (Nat.lt_of_succ_lt_succ hn) d

theorem list_getD_append_left {α : Type*} :
    ∀ (xs ys : List α) (n : ℕ) (_ : n < xs.length) (d : α),
      (xs ++ ys).getD n d = xs.getD n d
  | [], _, _, hn, _ => by simp at hn
  | _ :: _, _, 0, _, _ => rfl
  | _ :: xs, ys, n + 1, hn, d =>
      list_getD_append_left xs ys n (Nat.lt_of_succ_lt_succ hn) d

theorem list_getD_append_right {α : Type*} :
    ∀ (xs ys : List α) (n : ℕ) (d : α),
      (xs ++ ys).getD (xs.length + n) d = ys.getD n d
  | [], ys, n, d => by simp
  | _ :: xs, ys, n, d => by
      simpa [Nat.succ_add] using list_getD_append_right xs ys n d

theorem list_flatMap_ofFn_getD {α β : Type*} {d : ℕ} (f : α → Fin d → β) :
    ∀ (L : List α) (i : ℕ) (hi : i < L.length) (c : Fin d) (fallback : β),
      (L.flatMap (fun a => List.ofFn (f a))).getD (i * d + c.1) fallback = f (L[i]) c
  | [], _, hi, _, _ => by simp at hi
  | a :: tl, 0, _, c, fallback => by
      simp only [List.flatMap_cons, zero_mul, zero_add, List.getElem_cons_zero]
      rw [list_getD_append_left _ _ c.1 (by simp [c.2]) fallback,
        list_getD_eq_getElem _ c.1 (by simp [c.2]) fallback]
      simp
  | a :: tl, i + 1, hi, c, fallback => by
      simp only [List.flatMap_cons, List.getElem_cons_succ]
      have hidx : (i + 1) * d + c.1 = (List.ofFn (f a)).length + (i * d + c.1) := by
        simp only [List.length_ofFn]
        ring
      rw [hidx, list_getD_append_right]
      exact list_flatMap_ofFn_getD f tl i (Nat.lt_of_succ_lt_succ hi) c fallback

theorem listGetIntD_gaussianReals {K d : ℕ} (h x : ℝ)
    (ω : Fin K → EuclideanSpace ℝ (Fin d)) (g : Fin K) (c : Fin d) :
    listGetIntD
      (h :: x :: (List.finRange K).flatMap (fun k =>
        List.ofFn (fun c' : Fin d => euclideanCoord (ω k) c')))
      ((2 + (g.1 * d + c.1) : ℕ) : ℤ) 0 = euclideanCoord (ω g) c := by
  simp only [listGetIntD, Nat.cast_nonneg, ↓reduceIte, Int.toNat_natCast]
  have h2 : 2 + (g.1 * d + c.1) = (g.1 * d + c.1) + 2 := Nat.add_comm 2 _
  rw [h2]
  change ((List.finRange K).flatMap (fun k =>
    List.ofFn (fun c' : Fin d => euclideanCoord (ω k) c'))).getD (g.1 * d + c.1) 0 = _
  rw [list_flatMap_ofFn_getD (fun k c' => euclideanCoord (ω k) c') (List.finRange K)
    g.1 (by simp) c 0]
  simp

theorem evalRealExpr_activePtCoord {d : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (hE cE : IntExpr) (k : ℕ) (c : Fin d)
    (hk : (evalIntExpr inp.toWordView 0 mem.words hE).1 = (k : ℤ))
    (hc : (evalIntExpr inp.toWordView 0 mem.words cE).1 = (c.1 : ℤ))
    (hmem : k ∈ inp.activeHandles) :
    (evalRealExpr inp 0 mem (.activePtCoord hE cE)).1 =
      euclideanCoord (inp.activeCoords k) c := by
  simp [evalRealExpr, hk, hc, hmem, c.2]

theorem evalRealExpr_extraReal_ofFn {d : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (z : EuclideanSpace ℝ (Fin d))
    (hextra : inp.extraReals = List.ofFn (fun c : Fin d => euclideanCoord z c))
    (cE : IntExpr) (c : Fin d)
    (hc : (evalIntExpr inp.toWordView 0 mem.words cE).1 = (c.1 : ℤ)) :
    (evalRealExpr inp 0 mem (.extraReal cE)).1 = euclideanCoord z c := by
  simp only [evalRealExpr, hc, hextra, listGetIntD, Nat.cast_nonneg, ↓reduceIte, Int.toNat_natCast]
  rw [list_getD_eq_getElem _ c.1 (by simp [c.2]) 0]
  simp

theorem wRead_eq_zero_of_inParamFootprint {mem : ArithRAMMemory}
    (hfp : InParamFootprint mem) {tbl : ℕ} (htbl : 20 ≤ tbl) (i : ℤ) :
    wRead mem tbl i = 0 := by
  rcases inParamFootprint_subsets hfp with ⟨hfp_w, _⟩
  unfold wRead WordStore.read
  have hnot : RAMCellLoc.heap tbl i ∉ mem.words.live := by
    intro hmem
    have hp := List.mem_toFinset.mp (hfp_w hmem)
    simp only [paramWordList, List.mem_cons, List.not_mem_nil, or_false,
      RAMCellLoc.heap.injEq] at hp
    rcases hp with ⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩ |
      ⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩ | ⟨rfl, _⟩ <;>
      omega
  simp [hnot]

/-! ### 2. Dynamic swap-with-last bucket invariant (`BucketInv`) and append/remove steps -/

theorem pair_addr_inj {W a₁ b₁ a₂ b₂ : ℕ} (hb₁ : b₁ < W) (hb₂ : b₂ < W)
    (heq : a₁ * W + b₁ = a₂ * W + b₂) :
    a₁ = a₂ ∧ b₁ = b₂ := by
  have hW : 0 < W := by omega
  have hmod₁ : (a₁ * W + b₁) % W = b₁ := by
    rw [Nat.mul_comm, Nat.mul_add_mod, Nat.mod_eq_of_lt hb₁]
  have hmod₂ : (a₂ * W + b₂) % W = b₂ := by
    rw [Nat.mul_comm, Nat.mul_add_mod, Nat.mod_eq_of_lt hb₂]
  have hb : b₁ = b₂ := by
    have hm := congrArg (· % W) heq
    dsimp at hm
    rwa [hmod₁, hmod₂] at hm
  subst hb
  have ha : a₁ * W = a₂ * W := by omega
  exact ⟨Nat.eq_of_mul_eq_mul_right hW ha, rfl⟩

structure BucketInv {m : ℕ} (Cap_u : ℕ) (bktOf : Fin m → ℕ → ℕ)
    (Pairs : Finset (Fin m × ℕ)) (mem : ArithRAMMemory) : Prop where
  slot_lt : ∀ p ∈ Pairs, p.2 < Cap_u
  bkt_len : ∀ b : ℕ, wRead mem 24 (b : ℤ) =
    ((Pairs.filter (fun p => bktOf p.1 p.2 = b)).card : ℤ)
  fwd : ∀ (k : Fin m) (s : ℕ), (k, s) ∈ Pairs →
    wRead mem 22 ((k.1 * (Cap_u + 1) + s : ℕ) : ℤ) = ((bktOf k s : ℕ) : ℤ) ∧
    ∃ pos < (Pairs.filter (fun p => bktOf p.1 p.2 = bktOf k s)).card,
      wRead mem 23 ((k.1 * (Cap_u + 1) + s : ℕ) : ℤ) = (pos : ℤ) ∧
      wRead mem 25 (((bktOf k s) * (m + 1) + pos : ℕ) : ℤ) = (k.1 : ℤ) ∧
      wRead mem 26 (((bktOf k s) * (m + 1) + pos : ℕ) : ℤ) = (s : ℤ)
  bwd : ∀ (b pos : ℕ), pos < (Pairs.filter (fun p => bktOf p.1 p.2 = b)).card →
    ∃ (k : Fin m) (s : ℕ),
      (k, s) ∈ Pairs ∧ bktOf k s = b ∧
      wRead mem 25 ((b * (m + 1) + pos : ℕ) : ℤ) = (k.1 : ℤ) ∧
      wRead mem 26 ((b * (m + 1) + pos : ℕ) : ℤ) = (s : ℤ) ∧
      wRead mem 23 ((k.1 * (Cap_u + 1) + s : ℕ) : ℤ) = (pos : ℤ)

theorem bucketInv_card_le_m {m : ℕ} {bktOf : Fin m → ℕ → ℕ}
    {Pairs : Finset (Fin m × ℕ)}
    (hbkt_inj : ∀ {k : Fin m} {s₁ s₂ : ℕ},
      (k, s₁) ∈ Pairs → (k, s₂) ∈ Pairs → bktOf k s₁ = bktOf k s₂ → s₁ = s₂)
    (b : ℕ) :
    (Pairs.filter (fun p => bktOf p.1 p.2 = b)).card ≤ m := by
  let F := Pairs.filter (fun p => bktOf p.1 p.2 = b)
  have hinj : Set.InjOn Prod.fst (F : Set (Fin m × ℕ)) := by
    intro p₁ hp₁ p₂ hp₂ hfst
    rcases Finset.mem_filter.mp hp₁ with ⟨hm₁, hb₁⟩
    rcases Finset.mem_filter.mp hp₂ with ⟨hm₂, hb₂⟩
    cases p₁ with
    | mk k₁ s₁ =>
      cases p₂ with
      | mk k₂ s₂ =>
        dsimp at hfst hb₁ hb₂
        subst hfst
        have hs : s₁ = s₂ := hbkt_inj hm₁ hm₂ (hb₁.trans hb₂.symm)
        subst hs
        rfl
  calc F.card = (F.image Prod.fst).card := (Finset.card_image_of_injOn hinj).symm
    _ ≤ (Finset.univ : Finset (Fin m)).card := Finset.card_le_card (Finset.subset_univ _)
    _ = m := by simp

theorem bucketInv_empty {m : ℕ} (Cap_u : ℕ) (bktOf : Fin m → ℕ → ℕ)
    {mem : ArithRAMMemory} (hw24 : ∀ b : ℕ, wRead mem 24 (b : ℤ) = 0) :
    BucketInv Cap_u bktOf ∅ mem where
  slot_lt _ hp := by simp at hp
  bkt_len b := by simp [hw24 b]
  fwd _ _ hp := by simp at hp
  bwd _ _ hpos := by simp at hpos

theorem bucketInv_congr {m Cap_u : ℕ} {bktOf : Fin m → ℕ → ℕ}
    {Pairs : Finset (Fin m × ℕ)} {m₁ m₂ : ArithRAMMemory}
    (hinv : BucketInv Cap_u bktOf Pairs m₁)
    (hw : ∀ t i, 22 ≤ t → t ≤ 26 → wRead m₂ t i = wRead m₁ t i) :
    BucketInv Cap_u bktOf Pairs m₂ where
  slot_lt := hinv.slot_lt
  bkt_len b := (hw 24 _ (by decide) (by decide)).trans (hinv.bkt_len b)
  fwd k s hmem := by
    rcases hinv.fwd k s hmem with ⟨h22, pos, hpos, h23, h25, h26⟩
    exact ⟨(hw 22 _ (by decide) (by decide)).trans h22, pos, hpos,
      (hw 23 _ (by decide) (by decide)).trans h23,
      (hw 25 _ (by decide) (by decide)).trans h25,
      (hw 26 _ (by decide) (by decide)).trans h26⟩
  bwd b pos hpos := by
    rcases hinv.bwd b pos hpos with ⟨k, s, hm, hb, h25, h26, h23⟩
    exact ⟨k, s, hm, hb,
      (hw 25 _ (by decide) (by decide)).trans h25,
      (hw 26 _ (by decide) (by decide)).trans h26,
      (hw 23 _ (by decide) (by decide)).trans h23⟩

/-- Append `(k, s)` (with `k` in `(11, 22)`, `s` in `(11, 16)`, `b = bktOf k s` in `(11, 18)`)
into dynamic bucket `b`. -/
def bucketAppendStepStmt : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 11 (.lit 23) (.readHeap 24 (.readHeap 11 (.lit 18))),
      .writeWordHeap 24 (.readHeap 11 (.lit 18))
        (.add (.readHeap 11 (.lit 23)) (.lit 1)),
      .writeWordHeap 22
        (.add (.mul (.readHeap 11 (.lit 22)) (.add (.readHeap 1 (.lit 3)) (.lit 1)))
          (.readHeap 11 (.lit 16)))
        (.readHeap 11 (.lit 18)),
      .writeWordHeap 23
        (.add (.mul (.readHeap 11 (.lit 22)) (.add (.readHeap 1 (.lit 3)) (.lit 1)))
          (.readHeap 11 (.lit 16)))
        (.readHeap 11 (.lit 23)),
      .writeWordHeap 25
        (.add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
          (.readHeap 11 (.lit 23)))
        (.readHeap 11 (.lit 22)),
      .writeWordHeap 26
        (.add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
          (.readHeap 11 (.lit 23)))
        (.readHeap 11 (.lit 16)) ]

theorem exec_bucketAppendStep {d ℓ M₀ Cap_u Cap_q m : ℕ} (inp : ArithRAMInput d)
    {bktOf : Fin m → ℕ → ℕ}
    {Pairs : Finset (Fin m × ℕ)} {k : Fin m} {s : ℕ}
    (hbkt_inj : ∀ {k' : Fin m} {s₁ s₂ : ℕ},
      (k', s₁) ∈ insert (k, s) Pairs → (k', s₂) ∈ insert (k, s) Pairs →
        bktOf k' s₁ = bktOf k' s₂ → s₁ = s₂)
    (hs_lt : s < Cap_u) (hnot_mem : (k, s) ∉ Pairs)
    {mem : ArithRAMMemory} (hc : CleanMem mem)
    (hinv : BucketInv Cap_u bktOf Pairs mem)
    (hw_m : wRead mem 1 0 = (m : ℤ))
    (hw_Capu : wRead mem 1 3 = (Cap_u : ℤ))
    (hw_k : wRead mem 11 22 = (k.1 : ℤ))
    (hw_s : wRead mem 11 16 = (s : ℤ))
    (hw_b : wRead mem 11 18 = ((bktOf k s : ℕ) : ℤ)) :
    let SW := scratchWords ℓ M₀ Cap_q
    let SR := scratchReals d ℓ M₀
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp bucketAppendStepStmt mem mem' 100 ∧
      extraCells SW SR mem' ≤ extraCells SW SR mem + 5 ∧
      BucketInv Cap_u bktOf (insert (k, s) Pairs) mem' ∧
      (∀ t i, t ∉ ([22, 23, 24, 25, 26] : List ℕ) → (t ≠ 11 ∨ i ≠ 23) →
        wRead mem' t i = wRead mem t i) ∧
      (∀ t i, rRead mem' t i = rRead mem t i) := by
  intro SW SR
  let b := bktOf k s
  let len_b := (Pairs.filter (fun p => bktOf p.1 p.2 = b)).card
  let Pairs' := insert (k, s) Pairs
  have hslot' : ∀ p ∈ Pairs', p.2 < Cap_u := by
    intro p hp
    rcases Finset.mem_insert.mp hp with rfl | hmem
    · exact hs_lt
    · exact hinv.slot_lt p hmem
  have hfilter_eq : ∀ b' : ℕ,
      Pairs'.filter (fun p => bktOf p.1 p.2 = b') =
        if b' = b then insert (k, s) (Pairs.filter (fun p => bktOf p.1 p.2 = b))
        else Pairs.filter (fun p => bktOf p.1 p.2 = b') := by
    intro b'
    ext p
    by_cases hb' : b' = b
    · subst hb'
      simp only [Pairs', Finset.mem_filter, Finset.mem_insert, ↓reduceIte]
      constructor
      · rintro ⟨rfl | hp, heq⟩
        · exact Or.inl rfl
        · exact Or.inr ⟨hp, heq⟩
      · rintro (rfl | ⟨hp, heq⟩)
        · exact ⟨Or.inl rfl, rfl⟩
        · exact ⟨Or.inr hp, heq⟩
    · simp only [Pairs', Finset.mem_filter, Finset.mem_insert, hb', ↓reduceIte]
      constructor
      · rintro ⟨rfl | hp, heq⟩
        · exact absurd heq.symm hb'
        · exact ⟨hp, heq⟩
      · rintro ⟨hp, heq⟩
        exact ⟨Or.inr hp, heq⟩
  have hcard_b : (Pairs'.filter (fun p => bktOf p.1 p.2 = b)).card = len_b + 1 := by
    rw [hfilter_eq b]
    simp only [↓reduceIte]
    rw [Finset.card_insert_of_notMem]
    simp [hnot_mem]
  have hlen_lt_m1 : len_b < m + 1 := by
    have hle := bucketInv_card_le_m (Pairs := Pairs') hbkt_inj b
    rw [hcard_b] at hle
    omega

  let ptAddr : ℕ := k.1 * (Cap_u + 1) + s
  let bktAddr : ℕ := b * (m + 1) + len_b
  let ptAddrE : IntExpr :=
    .add (.mul (.readHeap 11 (.lit 22)) (.add (.readHeap 1 (.lit 3)) (.lit 1)))
      (.readHeap 11 (.lit 16))
  let bktAddrE : IntExpr :=
    .add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
      (.readHeap 11 (.lit 23))

  have hpt_cast : (k.1 : ℤ) * ((Cap_u : ℤ) + 1) + (s : ℤ) = (ptAddr : ℤ) := by
    simp only [ptAddr, Nat.cast_add, Nat.cast_mul, Nat.cast_one]
  have hbkt_cast : (b : ℤ) * ((m : ℤ) + 1) + (len_b : ℤ) = (bktAddr : ℤ) := by
    simp only [bktAddr, Nat.cast_add, Nat.cast_mul, Nat.cast_one]

  -- 1. (11, 23) := 24[b] = len_b
  rcases exec_wSet_sw SW SR inp hc 11 (.lit 23) 23 (mem_scratchWords_11 (i := 23) (by omega))
    (.readHeap 24 (.readHeap 11 (.lit 18))) (len_b : ℤ) 8
    (by simp [evalIntExpr])
    (by simp only [evalIntExpr, words_read_heap, hw_b]; exact hinv.bkt_len b)
    (by simp [evalIntExpr]) with
    ⟨m1, hs1, hex1, hw1_23, hw1_ne, hr1⟩
  -- 2. 24[b] := len_b + 1
  have hwb_1 : wRead m1 11 18 = (b : ℤ) := (hw1_ne 11 18 (Or.inr (by decide))).trans hw_b
  rcases exec_wSet_any SW SR inp hs1.2.1 24 (.readHeap 11 (.lit 18)) (b : ℤ)
    (.add (.readHeap 11 (.lit 23)) (.lit 1)) (((len_b + 1 : ℕ) : ℤ)) 10
    (by simp [evalIntExpr, hwb_1])
    (by simp [evalIntExpr, hw1_23])
    (by simp [evalIntExpr]) with
    ⟨m2, hs2, hex2, hw2_24, hw2_ne, hr2⟩
  -- 3. 22[ptAddr] := b
  have hwk_2 : wRead m2 11 22 = (k.1 : ℤ) :=
    (hw2_ne 11 22 (Or.inl (by decide))).trans ((hw1_ne 11 22 (Or.inr (by decide))).trans hw_k)
  have hwCapu_2 : wRead m2 1 3 = (Cap_u : ℤ) :=
    (hw2_ne 1 3 (Or.inl (by decide))).trans ((hw1_ne 1 3 (Or.inl (by decide))).trans hw_Capu)
  have hws_2 : wRead m2 11 16 = (s : ℤ) :=
    (hw2_ne 11 16 (Or.inl (by decide))).trans
      ((hw1_ne 11 16 (Or.inr (by decide))).trans hw_s)
  have hwb_2 : wRead m2 11 18 = (b : ℤ) :=
    (hw2_ne 11 18 (Or.inl (by decide))).trans hwb_1
  rcases exec_wSet_any SW SR inp hs2.2.1 22 ptAddrE (ptAddr : ℤ)
    (.readHeap 11 (.lit 18)) (b : ℤ) 16
    (by simp only [ptAddrE, evalIntExpr, words_read_heap, hwk_2, hwCapu_2, hws_2]; exact hpt_cast)
    (by simp [evalIntExpr, hwb_2])
    (by simp [ptAddrE, evalIntExpr]) with
    ⟨m3, hs3, hex3, hw3_22, hw3_ne, hr3⟩
  -- 4. 23[ptAddr] := len_b
  have hwk_3 : wRead m3 11 22 = (k.1 : ℤ) := (hw3_ne 11 22 (Or.inl (by decide))).trans hwk_2
  have hwCapu_3 : wRead m3 1 3 = (Cap_u : ℤ) := (hw3_ne 1 3 (Or.inl (by decide))).trans hwCapu_2
  have hws_3 : wRead m3 11 16 = (s : ℤ) := (hw3_ne 11 16 (Or.inl (by decide))).trans hws_2
  have hwlen_3 : wRead m3 11 23 = (len_b : ℤ) :=
    (hw3_ne 11 23 (Or.inl (by decide))).trans ((hw2_ne 11 23 (Or.inl (by decide))).trans hw1_23)
  rcases exec_wSet_any SW SR inp hs3.2.1 23 ptAddrE (ptAddr : ℤ)
    (.readHeap 11 (.lit 23)) (len_b : ℤ) 16
    (by simp only [ptAddrE, evalIntExpr, words_read_heap, hwk_3, hwCapu_3, hws_3]; exact hpt_cast)
    (by simp [evalIntExpr, hwlen_3])
    (by simp [ptAddrE, evalIntExpr]) with
    ⟨m4, hs4, hex4, hw4_23, hw4_ne, hr4⟩
  -- 5. 25[bktAddr] := k.1
  have hwb_4 : wRead m4 11 18 = (b : ℤ) :=
    (hw4_ne 11 18 (Or.inl (by decide))).trans ((hw3_ne 11 18 (Or.inl (by decide))).trans hwb_2)
  have hwm_4 : wRead m4 1 0 = (m : ℤ) :=
    (hw4_ne 1 0 (Or.inl (by decide))).trans
      ((hw3_ne 1 0 (Or.inl (by decide))).trans
        ((hw2_ne 1 0 (Or.inl (by decide))).trans ((hw1_ne 1 0 (Or.inl (by decide))).trans hw_m)))
  have hwlen_4 : wRead m4 11 23 = (len_b : ℤ) := (hw4_ne 11 23 (Or.inl (by decide))).trans hwlen_3
  have hwk_4 : wRead m4 11 22 = (k.1 : ℤ) := (hw4_ne 11 22 (Or.inl (by decide))).trans hwk_3
  rcases exec_wSet_any SW SR inp hs4.2.1 25 bktAddrE (bktAddr : ℤ)
    (.readHeap 11 (.lit 22)) (k.1 : ℤ) 16
    (by simp only [bktAddrE, evalIntExpr, words_read_heap, hwb_4, hwm_4, hwlen_4]; exact hbkt_cast)
    (by simp [evalIntExpr, hwk_4])
    (by simp [bktAddrE, evalIntExpr]) with
    ⟨m5, hs5, hex5, hw5_25, hw5_ne, hr5⟩
  -- 6. 26[bktAddr] := s
  have hwb_5 : wRead m5 11 18 = (b : ℤ) := (hw5_ne 11 18 (Or.inl (by decide))).trans hwb_4
  have hwm_5 : wRead m5 1 0 = (m : ℤ) := (hw5_ne 1 0 (Or.inl (by decide))).trans hwm_4
  have hwlen_5 : wRead m5 11 23 = (len_b : ℤ) := (hw5_ne 11 23 (Or.inl (by decide))).trans hwlen_4
  have hws_5 : wRead m5 11 16 = (s : ℤ) :=
    (hw5_ne 11 16 (Or.inl (by decide))).trans ((hw4_ne 11 16 (Or.inl (by decide))).trans hws_3)
  rcases exec_wSet_any SW SR inp hs5.2.1 26 bktAddrE (bktAddr : ℤ)
    (.readHeap 11 (.lit 16)) (s : ℤ) 16
    (by simp only [bktAddrE, evalIntExpr, words_read_heap, hwb_5, hwm_5, hwlen_5]; exact hbkt_cast)
    (by simp [evalIntExpr, hws_5])
    (by simp [bktAddrE, evalIntExpr]) with
    ⟨m6, hs6, hex6, hw6_26, hw6_ne, hr6⟩

  have htot : ExecStmt inp bucketAppendStepStmt mem m6 100 := by
    unfold bucketAppendStepStmt seqStmts
    exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 (ExecStmt.seq hs3
      (ExecStmt.seq hs4 (ExecStmt.seq hs5 hs6))))).mono_cost (by omega)
  have hex_tot : extraCells SW SR m6 ≤ extraCells SW SR mem + 5 := by omega

  -- Read helpers on m6 for tables 22..26
  have hw24_m6 : ∀ i, wRead m6 24 i = wRead m2 24 i := fun i =>
    (hw6_ne 24 i (Or.inl (by decide))).trans
      ((hw5_ne 24 i (Or.inl (by decide))).trans
        ((hw4_ne 24 i (Or.inl (by decide))).trans (hw3_ne 24 i (Or.inl (by decide)))))
  have hw22_m6 : ∀ i, wRead m6 22 i = wRead m3 22 i := fun i =>
    (hw6_ne 22 i (Or.inl (by decide))).trans
      ((hw5_ne 22 i (Or.inl (by decide))).trans (hw4_ne 22 i (Or.inl (by decide))))
  have hw23_m6 : ∀ i, wRead m6 23 i = wRead m4 23 i := fun i =>
    (hw6_ne 23 i (Or.inl (by decide))).trans (hw5_ne 23 i (Or.inl (by decide)))
  have hw25_m6 : ∀ i, wRead m6 25 i = wRead m5 25 i := fun i =>
    hw6_ne 25 i (Or.inl (by decide))

  have hpt_ne : ∀ {k' : Fin m} {s' : ℕ}, (k', s') ∈ Pairs →
      ((k'.1 * (Cap_u + 1) + s' : ℕ) : ℤ) ≠ (ptAddr : ℤ) := by
    intro k' s' hmem heq
    have hs' : s' < Cap_u + 1 := Nat.lt_succ_of_lt (hinv.slot_lt _ hmem)
    have hs1 : s < Cap_u + 1 := Nat.lt_succ_of_lt hs_lt
    rcases pair_addr_inj hs' hs1 (Int.ofNat.inj heq) with ⟨hk_eq, hs_eq⟩
    have hk' : k' = k := Fin.ext hk_eq
    subst hk'; subst hs_eq
    exact hnot_mem hmem

  have hbkt_ne : ∀ {b' pos' : ℕ},
      pos' < (Pairs.filter (fun p => bktOf p.1 p.2 = b')).card →
      ((b' * (m + 1) + pos' : ℕ) : ℤ) ≠ (bktAddr : ℤ) := by
    intro b' pos' hpos' heq
    have hbkt_inj_old : ∀ {k' : Fin m} {s₁ s₂ : ℕ},
        (k', s₁) ∈ Pairs → (k', s₂) ∈ Pairs → bktOf k' s₁ = bktOf k' s₂ → s₁ = s₂ :=
      fun hm₁ hm₂ => hbkt_inj (Finset.mem_insert_of_mem hm₁) (Finset.mem_insert_of_mem hm₂)
    have hle' := bucketInv_card_le_m hbkt_inj_old b'
    have hp1 : pos' < m + 1 := by omega
    rcases pair_addr_inj hp1 hlen_lt_m1 (Int.ofNat.inj heq) with ⟨hb_eq, hp_eq⟩
    subst hb_eq; subst hp_eq
    exact Nat.lt_irrefl len_b hpos'

  have hinv' : BucketInv Cap_u bktOf Pairs' m6 := by
    refine ⟨hslot', ?_, ?_, ?_⟩
    · intro b'
      rw [hw24_m6, hfilter_eq b']
      by_cases hb' : b' = b
      · subst hb'
        simp only [↓reduceIte]
        rw [Finset.card_insert_of_notMem (by simp [hnot_mem])]
        exact hw2_24
      · simp only [hb', ↓reduceIte]
        have hne : (24 : ℕ) ≠ 24 ∨ (b' : ℤ) ≠ (b : ℤ) := Or.inr (by omega)
        exact (hw2_ne 24 _ hne).trans ((hw1_ne 24 _ (Or.inl (by decide))).trans (hinv.bkt_len b'))
    · intro k' s' hmem'
      rcases Finset.mem_insert.mp hmem' with heq_ks | hmem
      · cases heq_ks
        refine ⟨(hw22_m6 _).trans hw3_22, len_b, ?_, (hw23_m6 _).trans hw4_23,
          (hw25_m6 _).trans hw5_25, hw6_26⟩
        rw [hcard_b]; omega
      · rcases hinv.fwd k' s' hmem with ⟨h22_old, pos', hpos', h23_old, h25_old, h26_old⟩
        have hpne := hpt_ne hmem
        have hbne := hbkt_ne hpos'
        have h22_new : wRead m6 22 ((k'.1 * (Cap_u + 1) + s' : ℕ) : ℤ) = ((bktOf k' s' : ℕ) : ℤ) :=
          (hw22_m6 _).trans
            ((hw3_ne 22 _ (Or.inr hpne)).trans
              ((hw2_ne 22 _ (Or.inl (by decide))).trans
                ((hw1_ne 22 _ (Or.inl (by decide))).trans h22_old)))
        have h23_new : wRead m6 23 ((k'.1 * (Cap_u + 1) + s' : ℕ) : ℤ) = (pos' : ℤ) :=
          (hw23_m6 _).trans
            ((hw4_ne 23 _ (Or.inr hpne)).trans
              ((hw3_ne 23 _ (Or.inl (by decide))).trans
                ((hw2_ne 23 _ (Or.inl (by decide))).trans
                  ((hw1_ne 23 _ (Or.inl (by decide))).trans h23_old))))
        have h25_new : wRead m6 25 (((bktOf k' s') * (m + 1) + pos' : ℕ) : ℤ) = (k'.1 : ℤ) :=
          (hw25_m6 _).trans
            ((hw5_ne 25 _ (Or.inr hbne)).trans
              ((hw4_ne 25 _ (Or.inl (by decide))).trans
                ((hw3_ne 25 _ (Or.inl (by decide))).trans
                  ((hw2_ne 25 _ (Or.inl (by decide))).trans
                    ((hw1_ne 25 _ (Or.inl (by decide))).trans h25_old)))))
        have h26_new : wRead m6 26 (((bktOf k' s') * (m + 1) + pos' : ℕ) : ℤ) = (s' : ℤ) :=
          (hw6_ne 26 _ (Or.inr hbne)).trans
            ((hw5_ne 26 _ (Or.inl (by decide))).trans
              ((hw4_ne 26 _ (Or.inl (by decide))).trans
                ((hw3_ne 26 _ (Or.inl (by decide))).trans
                  ((hw2_ne 26 _ (Or.inl (by decide))).trans
                    ((hw1_ne 26 _ (Or.inl (by decide))).trans h26_old)))))
        have hpos'_new : pos' < (Pairs'.filter (fun p => bktOf p.1 p.2 = bktOf k' s')).card := by
          by_cases hb_eq : bktOf k' s' = b
          · rw [hb_eq, hcard_b]
            rw [hb_eq] at hpos'
            dsimp only [len_b]
            omega
          · rwa [hfilter_eq (bktOf k' s'), if_neg hb_eq]
        exact ⟨h22_new, pos', hpos'_new, h23_new, h25_new, h26_new⟩
    · intro b' pos' hpos'
      by_cases hb' : b' = b
      · subst hb'
        rw [hcard_b] at hpos'
        rcases Nat.lt_succ_iff_lt_or_eq.mp hpos' with hlt | rfl
        · rcases hinv.bwd b pos' hlt with ⟨k', s', hmem, hb_eq, h25_old, h26_old, h23_old⟩
          have hpne := hpt_ne hmem
          have hbne := hbkt_ne hlt
          exact ⟨k', s', Finset.mem_insert_of_mem hmem, hb_eq,
            (hw25_m6 _).trans ((hw5_ne 25 _ (Or.inr hbne)).trans
              ((hw4_ne 25 _ (Or.inl (by decide))).trans ((hw3_ne 25 _ (Or.inl (by decide))).trans
                ((hw2_ne 25 _ (Or.inl (by decide))).trans ((hw1_ne 25 _ (Or.inl (by decide))).trans h25_old))))),
            (hw6_ne 26 _ (Or.inr hbne)).trans ((hw5_ne 26 _ (Or.inl (by decide))).trans
              ((hw4_ne 26 _ (Or.inl (by decide))).trans ((hw3_ne 26 _ (Or.inl (by decide))).trans
                ((hw2_ne 26 _ (Or.inl (by decide))).trans ((hw1_ne 26 _ (Or.inl (by decide))).trans h26_old))))),
            (hw23_m6 _).trans ((hw4_ne 23 _ (Or.inr hpne)).trans
              ((hw3_ne 23 _ (Or.inl (by decide))).trans
                ((hw2_ne 23 _ (Or.inl (by decide))).trans ((hw1_ne 23 _ (Or.inl (by decide))).trans h23_old))))⟩
        · exact ⟨k, s, Finset.mem_insert_self _ _, rfl,
            (hw25_m6 _).trans hw5_25, hw6_26, (hw23_m6 _).trans hw4_23⟩
      · rw [hfilter_eq b', if_neg hb'] at hpos'
        rcases hinv.bwd b' pos' hpos' with ⟨k', s', hmem, hb_eq, h25_old, h26_old, h23_old⟩
        have hpne := hpt_ne hmem
        have hbne := hbkt_ne hpos'
        exact ⟨k', s', Finset.mem_insert_of_mem hmem, hb_eq,
          (hw25_m6 _).trans ((hw5_ne 25 _ (Or.inr hbne)).trans
            ((hw4_ne 25 _ (Or.inl (by decide))).trans ((hw3_ne 25 _ (Or.inl (by decide))).trans
              ((hw2_ne 25 _ (Or.inl (by decide))).trans ((hw1_ne 25 _ (Or.inl (by decide))).trans h25_old))))),
          (hw6_ne 26 _ (Or.inr hbne)).trans ((hw5_ne 26 _ (Or.inl (by decide))).trans
            ((hw4_ne 26 _ (Or.inl (by decide))).trans ((hw3_ne 26 _ (Or.inl (by decide))).trans
              ((hw2_ne 26 _ (Or.inl (by decide))).trans ((hw1_ne 26 _ (Or.inl (by decide))).trans h26_old))))),
          (hw23_m6 _).trans ((hw4_ne 23 _ (Or.inr hpne)).trans
            ((hw3_ne 23 _ (Or.inl (by decide))).trans
              ((hw2_ne 23 _ (Or.inl (by decide))).trans ((hw1_ne 23 _ (Or.inl (by decide))).trans h23_old))))⟩

  refine ⟨m6, htot, hex_tot, hinv', ?_, ?_⟩
  · intro t i ht_not h11
    simp only [List.mem_cons, List.not_mem_nil, or_false, not_or] at ht_not
    rcases ht_not with ⟨ht22, ht23, ht24, ht25, ht26⟩
    exact (hw6_ne t i (Or.inl ht26)).trans
      ((hw5_ne t i (Or.inl ht25)).trans
        ((hw4_ne t i (Or.inl ht23)).trans
          ((hw3_ne t i (Or.inl ht22)).trans
            ((hw2_ne t i (Or.inl ht24)).trans (hw1_ne t i h11)))))
  · intro t i
    exact (hr6 t i).trans ((hr5 t i).trans ((hr4 t i).trans
      ((hr3 t i).trans ((hr2 t i).trans (hr1 t i)))))


/-- Swap-with-last removal of `(k, s) ∈ Pairs` (with `k.1` in `(11, 22)` and `s` in `(11, 16)`). -/
def bucketRemoveStepStmt : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 11 (.lit 18)
        (.readHeap 22
          (.add (.mul (.readHeap 11 (.lit 22)) (.add (.readHeap 1 (.lit 3)) (.lit 1)))
            (.readHeap 11 (.lit 16)))),
      .writeWordHeap 11 (.lit 23)
        (.readHeap 23
          (.add (.mul (.readHeap 11 (.lit 22)) (.add (.readHeap 1 (.lit 3)) (.lit 1)))
            (.readHeap 11 (.lit 16)))),
      .writeWordHeap 11 (.lit 24)
        (.sub (.readHeap 24 (.readHeap 11 (.lit 18))) (.lit 1)),
      .writeWordHeap 24 (.readHeap 11 (.lit 18)) (.readHeap 11 (.lit 24)),
      .writeWordHeap 11 (.lit 25)
        (.readHeap 25
          (.add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
            (.readHeap 11 (.lit 24)))),
      .writeWordHeap 11 (.lit 26)
        (.readHeap 26
          (.add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
            (.readHeap 11 (.lit 24)))),
      .writeWordHeap 25
        (.add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
          (.readHeap 11 (.lit 23)))
        (.readHeap 11 (.lit 25)),
      .writeWordHeap 26
        (.add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
          (.readHeap 11 (.lit 23)))
        (.readHeap 11 (.lit 26)),
      .writeWordHeap 23
        (.add (.mul (.readHeap 11 (.lit 25)) (.add (.readHeap 1 (.lit 3)) (.lit 1)))
          (.readHeap 11 (.lit 26)))
        (.readHeap 11 (.lit 23)) ]

theorem exec_bucketRemoveStep {d ℓ M₀ Cap_u Cap_q m : ℕ} (inp : ArithRAMInput d)
    {bktOf : Fin m → ℕ → ℕ}
    {Pairs : Finset (Fin m × ℕ)} {k : Fin m} {s : ℕ}
    (hbkt_inj : ∀ {k' : Fin m} {s₁ s₂ : ℕ},
      (k', s₁) ∈ Pairs → (k', s₂) ∈ Pairs → bktOf k' s₁ = bktOf k' s₂ → s₁ = s₂)
    (hmem_ks : (k, s) ∈ Pairs)
    {mem : ArithRAMMemory} (hc : CleanMem mem)
    (hinv : BucketInv Cap_u bktOf Pairs mem)
    (hw_m : wRead mem 1 0 = (m : ℤ))
    (hw_Capu : wRead mem 1 3 = (Cap_u : ℤ))
    (hw_k : wRead mem 11 22 = (k.1 : ℤ))
    (hw_s : wRead mem 11 16 = (s : ℤ)) :
    let SW := scratchWords ℓ M₀ Cap_q
    let SR := scratchReals d ℓ M₀
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp bucketRemoveStepStmt mem mem' 150 ∧
      extraCells SW SR mem' ≤ extraCells SW SR mem + 4 ∧
      BucketInv Cap_u bktOf (Pairs.erase (k, s)) mem' ∧
      (∀ t i, t ∉ ([23, 24, 25, 26] : List ℕ) →
        (t ≠ 11 ∨ i ∉ ([18, 23, 24, 25, 26] : List ℤ)) →
          wRead mem' t i = wRead mem t i) ∧
      (∀ t i, rRead mem' t i = rRead mem t i) := by
  intro SW SR
  let b := bktOf k s
  let len_b := (Pairs.filter (fun p => bktOf p.1 p.2 = b)).card
  rcases hinv.fwd k s hmem_ks with ⟨h22_ks, pos, hpos_lt, h23_ks, h25_ks, h26_ks⟩
  have hpos_lt' : pos < len_b := hpos_lt
  have hlen_pos : 1 ≤ len_b := by omega
  let lastPos : ℕ := len_b - 1
  have : lastPos = len_b - 1 := rfl
  have hlast_lt : lastPos < len_b := by omega
  rcases hinv.bwd b lastPos hlast_lt with
    ⟨lastK, lastS, hmem_last, hb_last, h25_last, h26_last, h23_last⟩
  have hlen_le_m : len_b ≤ m := bucketInv_card_le_m hbkt_inj b
  have hpos_lt_m1 : pos < m + 1 := by omega
  have hlast_lt_m1 : lastPos < m + 1 := by omega
  have hs_lt : s < Cap_u := hinv.slot_lt _ hmem_ks
  have hlastS_lt : lastS < Cap_u := hinv.slot_lt _ hmem_last

  let Pairs' := Pairs.erase (k, s)
  have hslot' : ∀ p ∈ Pairs', p.2 < Cap_u :=
    fun p hp => hinv.slot_lt p (Finset.mem_of_mem_erase hp)

  have hfilter_eq : ∀ b' : ℕ,
      Pairs'.filter (fun p => bktOf p.1 p.2 = b') =
        if b' = b then (Pairs.filter (fun p => bktOf p.1 p.2 = b)).erase (k, s)
        else Pairs.filter (fun p => bktOf p.1 p.2 = b') := by
    intro b'
    ext p
    by_cases hb' : b' = b
    · subst hb'
      simp [Pairs', Finset.mem_filter, Finset.mem_erase, and_assoc]
    · simp only [Pairs', Finset.mem_filter, Finset.mem_erase, hb', ↓reduceIte]
      constructor
      · rintro ⟨⟨_, hp⟩, heq⟩; exact ⟨hp, heq⟩
      · rintro ⟨hp, heq⟩
        refine ⟨⟨?_, hp⟩, heq⟩
        rintro rfl
        exact hb' heq.symm

  have hcard_b : (Pairs'.filter (fun p => bktOf p.1 p.2 = b)).card = lastPos := by
    rw [hfilter_eq b, if_pos rfl]
    have hmem_f : (k, s) ∈ Pairs.filter (fun p => bktOf p.1 p.2 = b) :=
      Finset.mem_filter.mpr ⟨hmem_ks, rfl⟩
    exact Finset.card_erase_of_mem hmem_f

  -- Equivalence: pos = lastPos ↔ (lastK, lastS) = (k, s)
  have hpos_eq_last_iff : pos = lastPos ↔ (lastK, lastS) = (k, s) := by
    constructor
    · intro hpeq
      have h25e : (lastK.1 : ℤ) = (k.1 : ℤ) := by
        rw [← h25_last, ← hpeq, h25_ks]
      have h26e : (lastS : ℤ) = (s : ℤ) := by
        rw [← h26_last, ← hpeq, h26_ks]
      exact Prod.ext (Fin.ext (Int.ofNat.inj h25e)) (Int.ofNat.inj h26e)
    · intro hkeq
      cases hkeq
      have h23e : (pos : ℤ) = (lastPos : ℤ) := h23_ks.symm.trans h23_last
      exact Int.ofNat.inj h23e

  let ptAddr : ℕ := k.1 * (Cap_u + 1) + s
  let lastPtAddr : ℕ := lastK.1 * (Cap_u + 1) + lastS
  let posBktAddr : ℕ := b * (m + 1) + pos
  let lastBktAddr : ℕ := b * (m + 1) + lastPos

  let ptAddrE : IntExpr :=
    .add (.mul (.readHeap 11 (.lit 22)) (.add (.readHeap 1 (.lit 3)) (.lit 1)))
      (.readHeap 11 (.lit 16))
  let lastBktAddrE : IntExpr :=
    .add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
      (.readHeap 11 (.lit 24))
  let posBktAddrE : IntExpr :=
    .add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
      (.readHeap 11 (.lit 23))
  let lastPtAddrE : IntExpr :=
    .add (.mul (.readHeap 11 (.lit 25)) (.add (.readHeap 1 (.lit 3)) (.lit 1)))
      (.readHeap 11 (.lit 26))

  have hpt_cast : (k.1 : ℤ) * ((Cap_u : ℤ) + 1) + (s : ℤ) = (ptAddr : ℤ) := by
    simp only [ptAddr, Nat.cast_add, Nat.cast_mul, Nat.cast_one]
  have hlastPt_cast : (lastK.1 : ℤ) * ((Cap_u : ℤ) + 1) + (lastS : ℤ) = (lastPtAddr : ℤ) := by
    simp only [lastPtAddr, Nat.cast_add, Nat.cast_mul, Nat.cast_one]
  have hposBkt_cast : (b : ℤ) * ((m : ℤ) + 1) + (pos : ℤ) = (posBktAddr : ℤ) := by
    simp only [posBktAddr, Nat.cast_add, Nat.cast_mul, Nat.cast_one]
  have hlastBkt_cast : (b : ℤ) * ((m : ℤ) + 1) + (lastPos : ℤ) = (lastBktAddr : ℤ) := by
    simp only [lastBktAddr, Nat.cast_add, Nat.cast_mul, Nat.cast_one]

  -- 1. (11, 18) := 22[ptAddr] = b
  rcases exec_wSet_sw SW SR inp hc 11 (.lit 18) 18 (mem_scratchWords_11 (i := 18) (by omega))
    (.readHeap 22 ptAddrE) (b : ℤ) 16
    (by simp [evalIntExpr])
    (by simp only [ptAddrE, evalIntExpr, words_read_heap, hw_k, hw_Capu, hw_s, hpt_cast]; exact h22_ks)
    (by simp [ptAddrE, evalIntExpr]) with
    ⟨m1, hs1, hex1, hw1_18, hw1_ne, hr1⟩
  -- 2. (11, 23) := 23[ptAddr] = pos
  have hwk_1 : wRead m1 11 22 = (k.1 : ℤ) := (hw1_ne 11 22 (Or.inr (by decide))).trans hw_k
  have hwCapu_1 : wRead m1 1 3 = (Cap_u : ℤ) := (hw1_ne 1 3 (Or.inl (by decide))).trans hw_Capu
  have hws_1 : wRead m1 11 16 = (s : ℤ) := (hw1_ne 11 16 (Or.inr (by decide))).trans hw_s
  have h23_m1 : wRead m1 23 (ptAddr : ℤ) = (pos : ℤ) :=
    (hw1_ne 23 _ (Or.inl (by decide))).trans h23_ks
  rcases exec_wSet_sw SW SR inp hs1.2.1 11 (.lit 23) 23 (mem_scratchWords_11 (i := 23) (by omega))
    (.readHeap 23 ptAddrE) (pos : ℤ) 16
    (by simp [evalIntExpr])
    (by simp only [ptAddrE, evalIntExpr, words_read_heap, hwk_1, hwCapu_1, hws_1, hpt_cast]; exact h23_m1)
    (by simp [ptAddrE, evalIntExpr]) with
    ⟨m2, hs2, hex2, hw2_23, hw2_ne, hr2⟩
  -- 3. (11, 24) := 24[b] - 1 = lastPos
  have hwb_2 : wRead m2 11 18 = (b : ℤ) := (hw2_ne 11 18 (Or.inr (by decide))).trans hw1_18
  have h24_m2 : wRead m2 24 (b : ℤ) = (len_b : ℤ) :=
    (hw2_ne 24 _ (Or.inl (by decide))).trans ((hw1_ne 24 _ (Or.inl (by decide))).trans (hinv.bkt_len b))
  have hlast_sub : (len_b : ℤ) - 1 = (lastPos : ℤ) := by dsimp [lastPos]; omega
  rcases exec_wSet_sw SW SR inp hs2.2.1 11 (.lit 24) 24 (mem_scratchWords_11 (i := 24) (by omega))
    (.sub (.readHeap 24 (.readHeap 11 (.lit 18))) (.lit 1)) (lastPos : ℤ) 12
    (by simp [evalIntExpr])
    (by simp only [evalIntExpr, words_read_heap, hwb_2, h24_m2]; exact hlast_sub)
    (by simp [evalIntExpr]) with
    ⟨m3, hs3, hex3, hw3_24, hw3_ne, hr3⟩
  -- 4. 24[b] := lastPos
  have hwb_3 : wRead m3 11 18 = (b : ℤ) := (hw3_ne 11 18 (Or.inr (by decide))).trans hwb_2
  rcases exec_wSet_any SW SR inp hs3.2.1 24 (.readHeap 11 (.lit 18)) (b : ℤ)
    (.readHeap 11 (.lit 24)) (lastPos : ℤ) 10
    (by simp [evalIntExpr, hwb_3])
    (by simp [evalIntExpr, hw3_24])
    (by simp [evalIntExpr]) with
    ⟨m4, hs4, hex4, hw4_24, hw4_ne, hr4⟩
  -- 5. (11, 25) := 25[lastBktAddr] = lastK.1
  have hwb_4 : wRead m4 11 18 = (b : ℤ) := (hw4_ne 11 18 (Or.inl (by decide))).trans hwb_3
  have hwm_4 : wRead m4 1 0 = (m : ℤ) :=
    (hw4_ne 1 0 (Or.inl (by decide))).trans
      ((hw3_ne 1 0 (Or.inl (by decide))).trans
        ((hw2_ne 1 0 (Or.inl (by decide))).trans ((hw1_ne 1 0 (Or.inl (by decide))).trans hw_m)))
  have hwlast_4 : wRead m4 11 24 = (lastPos : ℤ) := (hw4_ne 11 24 (Or.inl (by decide))).trans hw3_24
  have h25_m4 : wRead m4 25 (lastBktAddr : ℤ) = (lastK.1 : ℤ) :=
    (hw4_ne 25 _ (Or.inl (by decide))).trans
      ((hw3_ne 25 _ (Or.inl (by decide))).trans
        ((hw2_ne 25 _ (Or.inl (by decide))).trans ((hw1_ne 25 _ (Or.inl (by decide))).trans h25_last)))
  rcases exec_wSet_sw SW SR inp hs4.2.1 11 (.lit 25) 25 (mem_scratchWords_11 (i := 25) (by omega))
    (.readHeap 25 lastBktAddrE) (lastK.1 : ℤ) 18
    (by simp [evalIntExpr])
    (by simp only [lastBktAddrE, evalIntExpr, words_read_heap, hwb_4, hwm_4, hwlast_4, hlastBkt_cast]; exact h25_m4)
    (by simp [lastBktAddrE, evalIntExpr]) with
    ⟨m5, hs5, hex5, hw5_25, hw5_ne, hr5⟩
  -- 6. (11, 26) := 26[lastBktAddr] = lastS
  have hwb_5 : wRead m5 11 18 = (b : ℤ) := (hw5_ne 11 18 (Or.inr (by decide))).trans hwb_4
  have hwm_5 : wRead m5 1 0 = (m : ℤ) := (hw5_ne 1 0 (Or.inl (by decide))).trans hwm_4
  have hwlast_5 : wRead m5 11 24 = (lastPos : ℤ) := (hw5_ne 11 24 (Or.inr (by decide))).trans hwlast_4
  have h26_m5 : wRead m5 26 (lastBktAddr : ℤ) = (lastS : ℤ) :=
    (hw5_ne 26 _ (Or.inl (by decide))).trans
      ((hw4_ne 26 _ (Or.inl (by decide))).trans
        ((hw3_ne 26 _ (Or.inl (by decide))).trans
          ((hw2_ne 26 _ (Or.inl (by decide))).trans ((hw1_ne 26 _ (Or.inl (by decide))).trans h26_last))))
  rcases exec_wSet_sw SW SR inp hs5.2.1 11 (.lit 26) 26 (mem_scratchWords_11 (i := 26) (by omega))
    (.readHeap 26 lastBktAddrE) (lastS : ℤ) 18
    (by simp [evalIntExpr])
    (by simp only [lastBktAddrE, evalIntExpr, words_read_heap, hwb_5, hwm_5, hwlast_5, hlastBkt_cast]; exact h26_m5)
    (by simp [lastBktAddrE, evalIntExpr]) with
    ⟨m6, hs6, hex6, hw6_26, hw6_ne, hr6⟩
  -- 7. 25[posBktAddr] := lastK.1
  have hwb_6 : wRead m6 11 18 = (b : ℤ) := (hw6_ne 11 18 (Or.inr (by decide))).trans hwb_5
  have hwm_6 : wRead m6 1 0 = (m : ℤ) := (hw6_ne 1 0 (Or.inl (by decide))).trans hwm_5
  have hwpos_6 : wRead m6 11 23 = (pos : ℤ) :=
    (hw6_ne 11 23 (Or.inr (by decide))).trans
      ((hw5_ne 11 23 (Or.inr (by decide))).trans
        ((hw4_ne 11 23 (Or.inl (by decide))).trans ((hw3_ne 11 23 (Or.inr (by decide))).trans hw2_23)))
  have hwlastK_6 : wRead m6 11 25 = (lastK.1 : ℤ) := (hw6_ne 11 25 (Or.inr (by decide))).trans hw5_25
  rcases exec_wSet_any SW SR inp hs6.2.1 25 posBktAddrE (posBktAddr : ℤ)
    (.readHeap 11 (.lit 25)) (lastK.1 : ℤ) 18
    (by simp only [posBktAddrE, evalIntExpr, words_read_heap, hwb_6, hwm_6, hwpos_6]; exact hposBkt_cast)
    (by simp [evalIntExpr, hwlastK_6])
    (by simp [posBktAddrE, evalIntExpr]) with
    ⟨m7, hs7, hex7, hw7_25, hw7_ne, hr7⟩
  -- 8. 26[posBktAddr] := lastS
  have hwb_7 : wRead m7 11 18 = (b : ℤ) := (hw7_ne 11 18 (Or.inl (by decide))).trans hwb_6
  have hwm_7 : wRead m7 1 0 = (m : ℤ) := (hw7_ne 1 0 (Or.inl (by decide))).trans hwm_6
  have hwpos_7 : wRead m7 11 23 = (pos : ℤ) := (hw7_ne 11 23 (Or.inl (by decide))).trans hwpos_6
  have hwlastS_7 : wRead m7 11 26 = (lastS : ℤ) := (hw7_ne 11 26 (Or.inl (by decide))).trans hw6_26
  rcases exec_wSet_any SW SR inp hs7.2.1 26 posBktAddrE (posBktAddr : ℤ)
    (.readHeap 11 (.lit 26)) (lastS : ℤ) 18
    (by simp only [posBktAddrE, evalIntExpr, words_read_heap, hwb_7, hwm_7, hwpos_7]; exact hposBkt_cast)
    (by simp [evalIntExpr, hwlastS_7])
    (by simp [posBktAddrE, evalIntExpr]) with
    ⟨m8, hs8, hex8, hw8_26, hw8_ne, hr8⟩
  -- 9. 23[lastPtAddr] := pos
  have hwlastK_8 : wRead m8 11 25 = (lastK.1 : ℤ) :=
    (hw8_ne 11 25 (Or.inl (by decide))).trans ((hw7_ne 11 25 (Or.inl (by decide))).trans hwlastK_6)
  have hwlastS_8 : wRead m8 11 26 = (lastS : ℤ) := (hw8_ne 11 26 (Or.inl (by decide))).trans hwlastS_7
  have hwCapu_8 : wRead m8 1 3 = (Cap_u : ℤ) :=
    (hw8_ne 1 3 (Or.inl (by decide))).trans
      ((hw7_ne 1 3 (Or.inl (by decide))).trans
        ((hw6_ne 1 3 (Or.inl (by decide))).trans
          ((hw5_ne 1 3 (Or.inl (by decide))).trans
            ((hw4_ne 1 3 (Or.inl (by decide))).trans
              ((hw3_ne 1 3 (Or.inl (by decide))).trans
                ((hw2_ne 1 3 (Or.inl (by decide))).trans hwCapu_1))))))
  have hwpos_8 : wRead m8 11 23 = (pos : ℤ) := (hw8_ne 11 23 (Or.inl (by decide))).trans hwpos_7
  rcases exec_wSet_any SW SR inp hs8.2.1 23 lastPtAddrE (lastPtAddr : ℤ)
    (.readHeap 11 (.lit 23)) (pos : ℤ) 18
    (by simp only [lastPtAddrE, evalIntExpr, words_read_heap, hwlastK_8, hwCapu_8, hwlastS_8]; exact hlastPt_cast)
    (by simp [evalIntExpr, hwpos_8])
    (by simp [lastPtAddrE, evalIntExpr]) with
    ⟨m9, hs9, hex9, hw9_23, hw9_ne, hr9⟩

  have htot : ExecStmt inp bucketRemoveStepStmt mem m9 150 := by
    unfold bucketRemoveStepStmt seqStmts
    exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 (ExecStmt.seq hs3 (ExecStmt.seq hs4
      (ExecStmt.seq hs5 (ExecStmt.seq hs6 (ExecStmt.seq hs7 (ExecStmt.seq hs8 hs9)))))))).mono_cost
      (by omega)
  have hex_tot : extraCells SW SR m9 ≤ extraCells SW SR mem + 4 := by omega

  -- Read simplifications on m9 for tables 22..26
  have hw22_m9 : ∀ i, wRead m9 22 i = wRead mem 22 i := fun i =>
    (hw9_ne 22 i (Or.inl (by decide))).trans
      ((hw8_ne 22 i (Or.inl (by decide))).trans
        ((hw7_ne 22 i (Or.inl (by decide))).trans
          ((hw6_ne 22 i (Or.inl (by decide))).trans
            ((hw5_ne 22 i (Or.inl (by decide))).trans
              ((hw4_ne 22 i (Or.inl (by decide))).trans
                ((hw3_ne 22 i (Or.inl (by decide))).trans
                  ((hw2_ne 22 i (Or.inl (by decide))).trans
                    (hw1_ne 22 i (Or.inl (by decide))))))))))
  have hw24_m9 : ∀ i, wRead m9 24 i = wRead m4 24 i := fun i =>
    (hw9_ne 24 i (Or.inl (by decide))).trans
      ((hw8_ne 24 i (Or.inl (by decide))).trans
        ((hw7_ne 24 i (Or.inl (by decide))).trans
          ((hw6_ne 24 i (Or.inl (by decide))).trans (hw5_ne 24 i (Or.inl (by decide))))))
  have hw25_m9 : ∀ i, wRead m9 25 i = wRead m7 25 i := fun i =>
    (hw9_ne 25 i (Or.inl (by decide))).trans (hw8_ne 25 i (Or.inl (by decide)))
  have hw26_m9 : ∀ i, wRead m9 26 i = wRead m8 26 i := fun i =>
    hw9_ne 26 i (Or.inl (by decide))
  have hw23_m8 : ∀ i, wRead m8 23 i = wRead mem 23 i := fun i =>
    (hw8_ne 23 i (Or.inl (by decide))).trans
      ((hw7_ne 23 i (Or.inl (by decide))).trans
        ((hw6_ne 23 i (Or.inl (by decide))).trans
          ((hw5_ne 23 i (Or.inl (by decide))).trans
            ((hw4_ne 23 i (Or.inl (by decide))).trans
              ((hw3_ne 23 i (Or.inl (by decide))).trans
                ((hw2_ne 23 i (Or.inl (by decide))).trans
                  (hw1_ne 23 i (Or.inl (by decide)))))))))
  have hw25_m6 : ∀ i, wRead m6 25 i = wRead mem 25 i := fun i =>
    (hw6_ne 25 i (Or.inl (by decide))).trans
      ((hw5_ne 25 i (Or.inl (by decide))).trans
        ((hw4_ne 25 i (Or.inl (by decide))).trans
          ((hw3_ne 25 i (Or.inl (by decide))).trans
            ((hw2_ne 25 i (Or.inl (by decide))).trans (hw1_ne 25 i (Or.inl (by decide)))))))
  have hw26_m7 : ∀ i, wRead m7 26 i = wRead mem 26 i := fun i =>
    (hw7_ne 26 i (Or.inl (by decide))).trans
      ((hw6_ne 26 i (Or.inl (by decide))).trans
        ((hw5_ne 26 i (Or.inl (by decide))).trans
          ((hw4_ne 26 i (Or.inl (by decide))).trans
            ((hw3_ne 26 i (Or.inl (by decide))).trans
              ((hw2_ne 26 i (Or.inl (by decide))).trans (hw1_ne 26 i (Or.inl (by decide))))))))

  have hinv' : BucketInv Cap_u bktOf Pairs' m9 := by
    refine ⟨hslot', ?_, ?_, ?_⟩
    · intro b'
      rw [hw24_m9]
      by_cases hb' : b' = b
      · subst hb'
        rw [hcard_b]
        exact hw4_24
      · rw [hfilter_eq b', if_neg hb']
        have hne : (24 : ℕ) ≠ 24 ∨ (b' : ℤ) ≠ (b : ℤ) := Or.inr (by omega)
        exact (hw4_ne 24 _ hne).trans
          ((hw3_ne 24 _ (Or.inl (by decide))).trans
            ((hw2_ne 24 _ (Or.inl (by decide))).trans
              ((hw1_ne 24 _ (Or.inl (by decide))).trans (hinv.bkt_len b'))))
    · intro k' s' hmem'
      rcases Finset.mem_erase.mp hmem' with ⟨hne_ks, hmem_old⟩
      rcases hinv.fwd k' s' hmem_old with ⟨h22_old, pos', hpos'_old, h23_old, h25_old, h26_old⟩
      have h22_new : wRead m9 22 ((k'.1 * (Cap_u + 1) + s' : ℕ) : ℤ) = ((bktOf k' s' : ℕ) : ℤ) :=
        (hw22_m9 _).trans h22_old
      by_cases heq_last : (k', s') = (lastK, lastS)
      · cases heq_last
        have hpos_ne_last : pos ≠ lastPos := fun h => hne_ks (hpos_eq_last_iff.mp h)
        have hpos_lt_last : pos < lastPos := by omega
        refine ⟨h22_new, pos, ?_, hw9_23, ?_, ?_⟩
        · rw [hb_last, hcard_b]; exact hpos_lt_last
        · simp only [hb_last]
          exact (hw25_m9 _).trans hw7_25
        · simp only [hb_last]
          exact (hw26_m9 _).trans hw8_26
      · have hs'_lt : s' < Cap_u := hinv.slot_lt _ hmem_old
        have hpt_ne_last : ((k'.1 * (Cap_u + 1) + s' : ℕ) : ℤ) ≠ (lastPtAddr : ℤ) := by
          intro heq
          rcases pair_addr_inj (Nat.lt_succ_of_lt hs'_lt) (Nat.lt_succ_of_lt hlastS_lt)
            (Int.ofNat.inj heq) with ⟨hk_e, hs_e⟩
          exact heq_last (Prod.ext (Fin.ext hk_e) hs_e)
        have hpos'_lt_m1 : pos' < m + 1 := by
          have hle := bucketInv_card_le_m hbkt_inj (bktOf k' s')
          omega
        have hbkt_ne_pos : (((bktOf k' s') * (m + 1) + pos' : ℕ) : ℤ) ≠ (posBktAddr : ℤ) := by
          intro heq
          rcases pair_addr_inj hpos'_lt_m1 hpos_lt_m1 (Int.ofNat.inj heq) with ⟨hb_e, hp_e⟩
          have h25e : (k'.1 : ℤ) = (k.1 : ℤ) := by
            rw [← h25_old, hb_e, hp_e]; exact h25_ks
          have h26e : (s' : ℤ) = (s : ℤ) := by
            rw [← h26_old, hb_e, hp_e]; exact h26_ks
          exact hne_ks (Prod.ext (Fin.ext (Int.ofNat.inj h25e)) (Int.ofNat.inj h26e))
        have hpos'_new : pos' < (Pairs'.filter (fun p => bktOf p.1 p.2 = bktOf k' s')).card := by
          by_cases hb_eq : bktOf k' s' = b
          · rw [hb_eq, hcard_b]
            have hlt_len : pos' < len_b := by rwa [hb_eq] at hpos'_old
            have hne_lp : pos' ≠ lastPos := by
              intro hpe
              have h25e : (k'.1 : ℤ) = (lastK.1 : ℤ) := by
                rw [← h25_old, hb_eq, hpe]; exact h25_last
              have h26e : (s' : ℤ) = (lastS : ℤ) := by
                rw [← h26_old, hb_eq, hpe]; exact h26_last
              exact heq_last (Prod.ext (Fin.ext (Int.ofNat.inj h25e)) (Int.ofNat.inj h26e))
            omega
          · rwa [hfilter_eq (bktOf k' s'), if_neg hb_eq]
        exact ⟨h22_new, pos', hpos'_new,
          (hw9_ne 23 _ (Or.inr hpt_ne_last)).trans ((hw23_m8 _).trans h23_old),
          (hw25_m9 _).trans ((hw7_ne 25 _ (Or.inr hbkt_ne_pos)).trans ((hw25_m6 _).trans h25_old)),
          (hw26_m9 _).trans ((hw8_ne 26 _ (Or.inr hbkt_ne_pos)).trans ((hw26_m7 _).trans h26_old))⟩
    · intro b' pos' hpos'
      by_cases hcase : b' = b ∧ pos' = pos
      · rcases hcase with ⟨rfl, rfl⟩
        rw [hcard_b] at hpos'
        have hlast_ne_ks : (lastK, lastS) ≠ (k, s) := fun h => by
          have := hpos_eq_last_iff.mpr h
          omega
        exact ⟨lastK, lastS, Finset.mem_erase.mpr ⟨hlast_ne_ks, hmem_last⟩, hb_last,
          (hw25_m9 _).trans hw7_25, (hw26_m9 _).trans hw8_26, hw9_23⟩
      · have hpos'_old : pos' < (Pairs.filter (fun p => bktOf p.1 p.2 = b')).card := by
          by_cases hb' : b' = b
          · subst hb'; rw [hcard_b] at hpos'; omega
          · rwa [hfilter_eq b', if_neg hb'] at hpos'
        rcases hinv.bwd b' pos' hpos'_old with ⟨k', s', hmem_old, hb_old, h25_old, h26_old, h23_old⟩
        have hne_ks : (k', s') ≠ (k, s) := by
          intro heq
          cases heq
          have hb_eq : b' = b := hb_old.symm
          have hp_eq : pos' = pos := Int.ofNat.inj (h23_old.symm.trans h23_ks)
          exact hcase ⟨hb_eq, hp_eq⟩
        have hne_last : (k', s') ≠ (lastK, lastS) := by
          intro heq
          cases heq
          have hb_eq : b' = b := hb_old.symm.trans hb_last
          subst hb_eq
          rw [hcard_b] at hpos'
          have hp_eq : pos' = lastPos := Int.ofNat.inj (h23_old.symm.trans h23_last)
          omega
        have hs'_lt : s' < Cap_u := hinv.slot_lt _ hmem_old
        have hpt_ne_last : ((k'.1 * (Cap_u + 1) + s' : ℕ) : ℤ) ≠ (lastPtAddr : ℤ) := by
          intro heq
          rcases pair_addr_inj (Nat.lt_succ_of_lt hs'_lt) (Nat.lt_succ_of_lt hlastS_lt)
            (Int.ofNat.inj heq) with ⟨hk_e, hs_e⟩
          exact hne_last (Prod.ext (Fin.ext hk_e) hs_e)
        have hpos'_lt_m1 : pos' < m + 1 := by
          have hle := bucketInv_card_le_m hbkt_inj b'
          omega
        have hbkt_ne_pos : ((b' * (m + 1) + pos' : ℕ) : ℤ) ≠ (posBktAddr : ℤ) := by
          intro heq
          rcases pair_addr_inj hpos'_lt_m1 hpos_lt_m1 (Int.ofNat.inj heq) with ⟨hb_e, hp_e⟩
          exact hcase ⟨hb_e, hp_e⟩
        exact ⟨k', s', Finset.mem_erase.mpr ⟨hne_ks, hmem_old⟩, hb_old,
          (hw25_m9 _).trans ((hw7_ne 25 _ (Or.inr hbkt_ne_pos)).trans ((hw25_m6 _).trans h25_old)),
          (hw26_m9 _).trans ((hw8_ne 26 _ (Or.inr hbkt_ne_pos)).trans ((hw26_m7 _).trans h26_old)),
          (hw9_ne 23 _ (Or.inr hpt_ne_last)).trans ((hw23_m8 _).trans h23_old)⟩

  refine ⟨m9, htot, hex_tot, hinv', ?_, ?_⟩
  · intro t i ht_not h11
    simp only [List.mem_cons, List.not_mem_nil, or_false, not_or] at ht_not
    rcases ht_not with ⟨ht23, ht24, ht25, ht26⟩
    have h18 : t ≠ 11 ∨ i ≠ 18 := by
      rcases h11 with ht | hi; · exact Or.inl ht
      · simp only [List.mem_cons, List.not_mem_nil, or_false, not_or] at hi; exact Or.inr hi.1
    have h23 : t ≠ 11 ∨ i ≠ 23 := by
      rcases h11 with ht | hi; · exact Or.inl ht
      · simp only [List.mem_cons, List.not_mem_nil, or_false, not_or] at hi; exact Or.inr hi.2.1
    have h24 : t ≠ 11 ∨ i ≠ 24 := by
      rcases h11 with ht | hi; · exact Or.inl ht
      · simp only [List.mem_cons, List.not_mem_nil, or_false, not_or] at hi; exact Or.inr hi.2.2.1
    have h25 : t ≠ 11 ∨ i ≠ 25 := by
      rcases h11 with ht | hi; · exact Or.inl ht
      · simp only [List.mem_cons, List.not_mem_nil, or_false, not_or] at hi; exact Or.inr hi.2.2.2.1
    have h26 : t ≠ 11 ∨ i ≠ 26 := by
      rcases h11 with ht | hi; · exact Or.inl ht
      · simp only [List.mem_cons, List.not_mem_nil, or_false, not_or] at hi; exact Or.inr hi.2.2.2.2
    exact (hw9_ne t i (Or.inl ht23)).trans
      ((hw8_ne t i (Or.inl ht26)).trans
        ((hw7_ne t i (Or.inl ht25)).trans
          ((hw6_ne t i h26).trans
            ((hw5_ne t i h25).trans
              ((hw4_ne t i (Or.inl ht24)).trans
                ((hw3_ne t i h24).trans
                  ((hw2_ne t i h23).trans (hw1_ne t i h18))))))))
  · intro t i
    exact (hr9 t i).trans ((hr8 t i).trans ((hr7 t i).trans ((hr6 t i).trans
      ((hr5 t i).trans ((hr4 t i).trans ((hr3 t i).trans ((hr2 t i).trans (hr1 t i))))))))

/-! ### 3. Index invariant (`IndexInv`) and RAM procedures `initStmt`, `insertStmt`, `deleteStmt` -/

noncomputable def bktKey {ℓ M₀ m d : ℕ} (hM₀ : 1 ≤ M₀) (t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d))
    (k : Fin m) (s : ℕ) : ℕ :=
  hornerTuple (tupleOfIdx hM₀ t ω (ptsK k) s)

theorem bktKey_inj {ℓ M₀ m d : ℕ} (hM₀ : 1 ≤ M₀) (t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d))
    {k : Fin m} {s₁ s₂ : ℕ}
    (hs₁ : s₁ < dataTupleCard t ω (ptsK k))
    (hs₂ : s₂ < dataTupleCard t ω (ptsK k))
    (heq : bktKey hM₀ t ω ptsK k s₁ = bktKey hM₀ t ω ptsK k s₂) :
    s₁ = s₂ := by
  rw [← prod_eligList_eq_dataTupleCard] at hs₁ hs₂
  exact tupleOfIdx_injective hM₀ hs₁ hs₂ (hornerTuple_injective heq)

noncomputable def activePairs {ℓ M₀ m d : ℕ} (Cap_u : ℕ) (t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d))
    (Act : Finset (Fin m)) : Finset (Fin m × ℕ) :=
  open Classical in
  Act.biUnion (fun k =>
    let deg := dataTupleCard t ω (ptsK k)
    if 1 ≤ deg ∧ deg ≤ Cap_u then
      (Finset.range deg).image (fun s => (k, s))
    else
      ∅)

theorem mem_activePairs_iff {ℓ M₀ m d : ℕ} {Cap_u : ℕ} {t : ℝ}
    {ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)}
    {ptsK : Fin m → EuclideanSpace ℝ (Fin d)}
    {Act : Finset (Fin m)} {k : Fin m} {s : ℕ} :
    (k, s) ∈ activePairs Cap_u t ω ptsK Act ↔
      k ∈ Act ∧ 1 ≤ dataTupleCard t ω (ptsK k) ∧
      dataTupleCard t ω (ptsK k) ≤ Cap_u ∧ s < dataTupleCard t ω (ptsK k) := by
  classical
  unfold activePairs
  simp only [Finset.mem_biUnion]
  constructor
  · rintro ⟨k', hk', hm⟩
    split_ifs at hm with hdeg
    · rcases Finset.mem_image.mp hm with ⟨s', hs', heq⟩
      cases heq
      exact ⟨hk', hdeg.1, hdeg.2, Finset.mem_range.mp hs'⟩
    · simp at hm
  · rintro ⟨hk, h1, h2, hs⟩
    refine ⟨k, hk, ?_⟩
    dsimp only
    rw [if_pos ⟨h1, h2⟩]
    exact Finset.mem_image.mpr ⟨s, Finset.mem_range.mpr hs, rfl⟩

@[simp]
theorem activePairs_empty {ℓ M₀ m d : ℕ} (Cap_u : ℕ) (t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d)) :
    activePairs Cap_u t ω ptsK ∅ = ∅ := by
  ext ⟨k, s⟩
  simp [mem_activePairs_iff]

structure IndexInv {ℓ M₀ m d : ℕ} (hM₀ : 1 ≤ M₀) (x t : ℝ) (Cap_u Cap_q : ℕ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d))
    (Act : Finset (Fin m)) (mem : ArithRAMMemory) : Prop where
  clean : CleanMem mem
  w_m : wRead mem 1 0 = (m : ℤ)
  w_M₀ : wRead mem 1 1 = (M₀ : ℤ)
  w_K : wRead mem 1 2 = ((ℓ * M₀ : ℕ) : ℤ)
  w_Capu : wRead mem 1 3 = (Cap_u : ℤ)
  w_Capq : wRead mem 1 4 = (Cap_q : ℤ)
  r_t : rRead mem 1 0 = t
  r_xt : rRead mem 1 1 = x * t
  r_ω : ∀ (g : Fin (ℓ * M₀)) (c : Fin d),
    rRead mem 2 ((g.1 * d + c.1 : ℕ) : ℤ) = euclideanCoord (ω g) c
  pt_stored : ∀ k : Fin m,
    wRead mem 20 (k.1 : ℤ) =
      (open Classical in
        if k ∈ Act ∧ 1 ≤ dataTupleCard t ω (ptsK k) ∧ dataTupleCard t ω (ptsK k) ≤ Cap_u
        then 1 else 0)
  pt_deg : ∀ k : Fin m,
    k ∈ Act → 1 ≤ dataTupleCard t ω (ptsK k) → dataTupleCard t ω (ptsK k) ≤ Cap_u →
      wRead mem 21 (k.1 : ℤ) = ((dataTupleCard t ω (ptsK k) : ℕ) : ℤ)
  buckets : BucketInv Cap_u (bktKey hM₀ t ω ptsK) (activePairs Cap_u t ω ptsK Act) mem

/-- Copy all `K * d` Gaussian coordinates from `extraReals[2..]` into real table `2`. -/
def initStmt : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 11 (.lit 8) (.lit 0),
      .repeatN (.readHeap 1 (.lit 2))
        (seqStmts
          [ .writeWordHeap 11 (.lit 9) (.lit 0),
            .repeatN .dim
              (seqStmts
                [ .writeRealHeap 2
                    (.add (.mul (.readHeap 11 (.lit 8)) .dim) (.readHeap 11 (.lit 9)))
                    (.extraReal
                      (.add (.lit 2)
                        (.add (.mul (.readHeap 11 (.lit 8)) .dim) (.readHeap 11 (.lit 9))))),
                  .writeWordHeap 11 (.lit 9) (.add (.readHeap 11 (.lit 9)) (.lit 1)) ]),
            .writeWordHeap 11 (.lit 8) (.add (.readHeap 11 (.lit 8)) (.lit 1)) ]) ]

theorem exec_initStmt {d ℓ M₀ Cap_u Cap_q m : ℕ}
    (hM₀ : 1 ≤ M₀) {h x t : ℝ}
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d))
    {memP : ArithRAMMemory} (hcP : CleanMem memP) (hfp : InParamFootprint memP)
    (hw_m : wRead memP 1 0 = (m : ℤ))
    (hw_M₀ : wRead memP 1 1 = (M₀ : ℤ))
    (hw_K : wRead memP 1 2 = ((ℓ * M₀ : ℕ) : ℤ))
    (hw_Capu : wRead memP 1 3 = (Cap_u : ℤ))
    (hw_Capq : wRead memP 1 4 = (Cap_q : ℤ))
    (hr_t : rRead memP 1 0 = t)
    (hr_xt : rRead memP 1 1 = x * t) :
    let K := ℓ * M₀
    let gaussianReals :=
      (List.finRange K).flatMap (fun k =>
        List.ofFn (fun c : Fin d => euclideanCoord (ω k) c))
    let inp : ArithRAMInput d :=
      { intParams := [(m : ℤ), (K : ℤ)]
        activeHandles := ∅
        activeCoords := fun _ => 0
        extraReals := h :: x :: gaussianReals }
    let SW := scratchWords ℓ M₀ Cap_q
    let SR := scratchReals d ℓ M₀
    ∃ initMem : ArithRAMMemory,
      ExecStmt inp initStmt memP initMem (20 + (ℓ * M₀) * (20 + d * 35)) ∧
      extraCells SW SR initMem = 0 ∧
      IndexInv hM₀ x t Cap_u Cap_q ω ptsK ∅ initMem := by
  intro K gaussianReals inp SW SR
  have hex₀ : extraCells SW SR memP = 0 := extraCells_eq_zero_of_inParamFootprint hfp d ℓ M₀ Cap_q
  rcases exec_wSet_sw SW SR inp hcP 11 (.lit 8) 8 (mem_scratchWords_11 (i := 8) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m1, hs1, hex1, hw1_8, hw1_ne, hr1⟩
  let innerBody : ArithRAMStmt :=
    seqStmts
      [ .writeRealHeap 2
          (.add (.mul (.readHeap 11 (.lit 8)) .dim) (.readHeap 11 (.lit 9)))
          (.extraReal
            (.add (.lit 2) (.add (.mul (.readHeap 11 (.lit 8)) .dim) (.readHeap 11 (.lit 9))))),
        .writeWordHeap 11 (.lit 9) (.add (.readHeap 11 (.lit 9)) (.lit 1)) ]
  let outerBody : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 9) (.lit 0),
        .repeatN .dim innerBody,
        .writeWordHeap 11 (.lit 8) (.add (.readHeap 11 (.lit 8)) (.lit 1)) ]
  let OuterInv : ℕ → ArithRAMMemory → Prop := fun g m =>
    extraCells SW SR m = 0 ∧
    wRead m 11 8 = (g : ℤ) ∧
    (∀ (g' : Fin K) (c : Fin d), g'.1 < g →
      rRead m 2 ((g'.1 * d + c.1 : ℕ) : ℤ) = euclideanCoord (ω g') c) ∧
    (∀ tbl idx, (tbl ≠ 11 ∨ (idx ≠ 8 ∧ idx ≠ 9)) → wRead m tbl idx = wRead memP tbl idx) ∧
    (∀ tbl idx, tbl ≠ 2 → rRead m tbl idx = rRead memP tbl idx)
  have hOuter₀ : OuterInv 0 m1 := by
    refine ⟨hex1.trans hex₀, hw1_8, fun _ _ hg => by omega, ?_, fun tbl idx _ => hr1 tbl idx⟩
    intro tbl idx hne
    exact hw1_ne tbl idx (by rcases hne with h1 | ⟨h2, _⟩; exact Or.inl h1; exact Or.inr h2)
  have hwK_m1 : wRead m1 1 2 = (K : ℤ) := (hw1_ne 1 2 (Or.inl (by decide))).trans hw_K
  rcases exec_repeatN (inp := inp) (.readHeap 1 (.lit 2)) outerBody K 4 (20 + d * 35)
    OuterInv hs1.2.1 hOuter₀
    (by simp [evalIntExpr, hwK_m1]) (by simp [evalIntExpr])
    (fun g hg_lt m hcm ⟨hexm, hwg, hr_prev, hwm_p, hrm_p⟩ => by
      let gF : Fin K := ⟨g, hg_lt⟩
      rcases exec_wSet_sw SW SR inp hcm 11 (.lit 9) 9 (mem_scratchWords_11 (i := 9) (by omega))
        (.lit 0) 0 4
        (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
        ⟨ma1, hb1, hexa1, hwa1_9, hwa1_ne, hra1⟩
      let InnerInv : ℕ → ArithRAMMemory → Prop := fun c mI =>
        extraCells SW SR mI = 0 ∧
        wRead mI 11 8 = (g : ℤ) ∧
        wRead mI 11 9 = (c : ℤ) ∧
        (∀ (c' : Fin d), c'.1 < c →
          rRead mI 2 ((g * d + c'.1 : ℕ) : ℤ) = euclideanCoord (ω gF) c') ∧
        (∀ (g' : Fin K) (c' : Fin d), g'.1 < g →
          rRead mI 2 ((g'.1 * d + c'.1 : ℕ) : ℤ) = euclideanCoord (ω g') c') ∧
        (∀ tbl idx, (tbl ≠ 11 ∨ (idx ≠ 8 ∧ idx ≠ 9)) → wRead mI tbl idx = wRead memP tbl idx) ∧
        (∀ tbl idx, tbl ≠ 2 → rRead mI tbl idx = rRead memP tbl idx)
      have hInner₀ : InnerInv 0 ma1 := by
        refine ⟨hexa1.trans hexm, (hwa1_ne 11 8 (Or.inr (by decide))).trans hwg, hwa1_9,
          fun _ hc => by omega,
          fun g' c' hg' => (hra1 2 _).trans (hr_prev g' c' hg'),
          fun tbl idx hne => (hwa1_ne tbl idx (by rcases hne with h1 | ⟨_, h3⟩; exact Or.inl h1; exact Or.inr h3)).trans (hwm_p tbl idx hne),
          fun tbl idx ht2 => (hra1 tbl idx).trans (hrm_p tbl idx ht2)⟩
      rcases exec_repeatN (inp := inp) .dim innerBody d 3 35 InnerInv hb1.2.1 hInner₀
        (by simp [evalIntExpr]) (by simp [evalIntExpr])
        (fun c hc_lt mI hcmI ⟨hexI, hwgI, hwcI, hrc_cur, hrg_prev, hwmI, hrmI⟩ => by
          let cF : Fin d := ⟨c, hc_lt⟩
          have haddr_lt : g * d + c < ℓ * M₀ * d + 1 := by
            have : g * d + c < (g + 1) * d := by ring_nf; omega
            have h2 : (g + 1) * d ≤ (ℓ * M₀) * d := Nat.mul_le_mul_right d (by omega)
            omega
          have haddr_cast : (g : ℤ) * (d : ℤ) + (c : ℤ) = ((g * d + c : ℕ) : ℤ) := by
            simp only [Nat.cast_add, Nat.cast_mul]
          have hextra_cast : (2 : ℤ) + ((g : ℤ) * (d : ℤ) + (c : ℤ)) =
              ((2 + (gF.1 * d + cF.1) : ℕ) : ℤ) := by
            simp only [gF, cF, Nat.cast_add, Nat.cast_mul, Nat.cast_ofNat]
          rcases exec_rSet_sr SW SR inp hcmI 2
            (.add (.mul (.readHeap 11 (.lit 8)) .dim) (.readHeap 11 (.lit 9)))
            ((g * d + c : ℕ) : ℤ) (mem_scratchReals_2 haddr_lt)
            (.extraReal (.add (.lit 2) (.add (.mul (.readHeap 11 (.lit 8)) .dim) (.readHeap 11 (.lit 9)))))
            (euclideanCoord (ω gF) cF) 25
            (by simp only [evalIntExpr, words_read_heap, hwgI, hwcI]; exact haddr_cast)
            (by
              simp only [evalRealExpr, evalIntExpr, words_read_heap, hwgI, hwcI, hextra_cast]
              exact listGetIntD_gaussianReals h x ω gF cF)
            (by simp [evalRealExpr, evalIntExpr]) with
            ⟨mi1, hi1, hexi1, hri1_2, hwi1, hri1_ne⟩
          have hwc_i1 : wRead mi1 11 9 = (c : ℤ) := (hwi1 11 9).trans hwcI
          rcases exec_wSet_sw SW SR inp hi1.2.1 11 (.lit 9) 9 (mem_scratchWords_11 (i := 9) (by omega))
            (.add (.readHeap 11 (.lit 9)) (.lit 1)) (((c + 1 : ℕ) : ℤ)) 10
            (by simp [evalIntExpr]) (by simp [evalIntExpr, hwc_i1]) (by simp [evalIntExpr]) with
            ⟨mi2, hi2, hexi2, hwi2_9, hwi2_ne, hri2⟩
          have hstepI : ExecStmt inp innerBody mI mi2 35 := by
            unfold innerBody seqStmts
            exact (ExecStmt.seq hi1 hi2).mono_cost (by omega)
          refine ⟨mi2, hstepI, hexi2.trans (hexi1.trans hexI),
            (hwi2_ne 11 8 (Or.inr (by decide))).trans ((hwi1 11 8).trans hwgI),
            hwi2_9, ?_, ?_, ?_, ?_⟩
          · intro c' hc'
            rcases Nat.lt_succ_iff_lt_or_eq.mp hc' with hlt | heq
            · have hne : ((g * d + c'.1 : ℕ) : ℤ) ≠ ((g * d + c : ℕ) : ℤ) := by omega
              exact (hri2 2 _).trans ((hri1_ne 2 _ (Or.inr hne)).trans (hrc_cur c' hlt))
            · have hc'_eq : c' = cF := Fin.ext heq
              subst hc'_eq
              exact (hri2 2 _).trans hri1_2
          · intro g' c' hg'
            have hne : ((g'.1 * d + c'.1 : ℕ) : ℤ) ≠ ((g * d + c : ℕ) : ℤ) := by
              intro he
              rcases pair_addr_inj c'.2 hc_lt (Int.ofNat.inj he) with ⟨hge, _⟩
              omega
            exact (hri2 2 _).trans ((hri1_ne 2 _ (Or.inr hne)).trans (hrg_prev g' c' hg'))
          · intro tbl idx hne
            exact (hwi2_ne tbl idx (by rcases hne with h1 | ⟨_, h3⟩; exact Or.inl h1; exact Or.inr h3)).trans
              ((hwi1 tbl idx).trans (hwmI tbl idx hne))
          · intro tbl idx ht2
            exact (hri2 tbl idx).trans ((hri1_ne tbl idx (Or.inl ht2)).trans (hrmI tbl idx ht2))) with
        ⟨ma2, ⟨hexa2, hwg_a2, _, hrc_all, hrg_all, hwm_a2, hrm_a2⟩, hrepI⟩
      rcases exec_wSet_sw SW SR inp hrepI.2.1 11 (.lit 8) 8 (mem_scratchWords_11 (i := 8) (by omega))
        (.add (.readHeap 11 (.lit 8)) (.lit 1)) (((g + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, hwg_a2]) (by simp [evalIntExpr]) with
        ⟨ma3, hb3, hexa3, hwa3_8, hwa3_ne, hra3⟩
      have hstepO : ExecStmt inp outerBody m ma3 (20 + d * 35) := by
        unfold outerBody seqStmts
        exact (ExecStmt.seq hb1 (ExecStmt.seq hrepI hb3)).mono_cost (by omega)
      refine ⟨ma3, hstepO, hexa3.trans hexa2, hwa3_8, ?_, ?_, ?_⟩
      · intro g' c' hg'
        rcases Nat.lt_succ_iff_lt_or_eq.mp hg' with hlt | heq
        · exact (hra3 2 _).trans (hrg_all g' c' hlt)
        · have hg'_eq : g' = gF := Fin.ext heq
          subst hg'_eq
          exact (hra3 2 _).trans (hrc_all c' c'.2)
      · intro tbl idx hne
        exact (hwa3_ne tbl idx (by rcases hne with h1 | ⟨h2, _⟩; exact Or.inl h1; exact Or.inr h2)).trans
          (hwm_a2 tbl idx hne)
      · intro tbl idx ht2
        exact (hra3 tbl idx).trans (hrm_a2 tbl idx ht2)) with
    ⟨initMem, ⟨hex_f, _, hr_ω_f, hwm_f, hrm_f⟩, hrepO⟩
  have htot : ExecStmt inp initStmt memP initMem (20 + (ℓ * M₀) * (20 + d * 35)) := by
    unfold initStmt seqStmts
    dsimp only [K] at hrepO
    exact (ExecStmt.seq hs1 hrepO).mono_cost (by omega)
  have hw20 : ∀ k : Fin m, wRead initMem 20 (k.1 : ℤ) = 0 := fun k =>
    (hwm_f 20 _ (Or.inl (by decide))).trans (wRead_eq_zero_of_inParamFootprint hfp (by decide) _)
  have hw24 : ∀ b : ℕ, wRead initMem 24 (b : ℤ) = 0 := fun b =>
    (hwm_f 24 _ (Or.inl (by decide))).trans (wRead_eq_zero_of_inParamFootprint hfp (by decide) _)
  refine ⟨initMem, htot, hex_f,
    hrepO.2.1,
    (hwm_f 1 0 (Or.inl (by decide))).trans hw_m,
    (hwm_f 1 1 (Or.inl (by decide))).trans hw_M₀,
    (hwm_f 1 2 (Or.inl (by decide))).trans hw_K,
    (hwm_f 1 3 (Or.inl (by decide))).trans hw_Capu,
    (hwm_f 1 4 (Or.inl (by decide))).trans hw_Capq,
    (hrm_f 1 0 (by decide)).trans hr_t,
    (hrm_f 1 1 (by decide)).trans hr_xt,
    fun g c => hr_ω_f g c g.2,
    fun k => by simp [hw20 k],
    fun _ hk => by simp at hk,
    by rw [activePairs_empty]; exact bucketInv_empty Cap_u (bktKey hM₀ t ω ptsK) hw24⟩

/-- Insert handle `k = .intParam (.lit 0)` into the capped explicit index. -/
def insertStmt (ℓ : ℕ) : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 11 (.lit 22) (.intParam (.lit 0)),
      .writeWordHeap 11 (.lit 9) (.lit 0),
      .repeatN .dim
        (seqStmts
          [ .writeRealHeap 3 (.readHeap 11 (.lit 9))
              (.activePtCoord (.readHeap 11 (.lit 22)) (.readHeap 11 (.lit 9))),
            .writeWordHeap 11 (.lit 9) (.add (.readHeap 11 (.lit 9)) (.lit 1)) ]),
      .writeRealHeap 17 (.lit 6) (.readRealHeap 1 (.lit 0)),
      computeBaseListsStmt ℓ,
      .ite
        (.and
          (.intLe (.lit 1) (.readHeap 11 (.lit 15)))
          (.intLe (.readHeap 11 (.lit 15)) (.readHeap 1 (.lit 3))))
        (seqStmts
          [ .writeWordHeap 20 (.readHeap 11 (.lit 22)) (.lit 1),
            .writeWordHeap 21 (.readHeap 11 (.lit 22)) (.readHeap 11 (.lit 15)),
            .writeWordHeap 11 (.lit 16) (.lit 0),
            .repeatN (.readHeap 11 (.lit 15))
              (seqStmts
                [ decodeTupleBucketStmt ℓ,
                  bucketAppendStepStmt,
                  .writeWordHeap 11 (.lit 16) (.add (.readHeap 11 (.lit 16)) (.lit 1)) ]) ])
        (.writeWordHeap 20 (.readHeap 11 (.lit 22)) (.lit 0)) ]

theorem exec_insertStmt {d ℓ M₀ Cap_u Cap_q m : ℕ}
    (hM₀ : 1 ≤ M₀) {x t : ℝ}
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d))
    {Act : Finset (Fin m)} {k : Fin m} (hk_not : k ∉ Act)
    (inp : ArithRAMInput d)
    (hinp_p : inp.intParams = [(k.1 : ℤ)])
    (hinp_h : k.1 ∈ inp.activeHandles)
    (hinp_c : inp.activeCoords k.1 = ptsK k)
    {mem₀ : ArithRAMMemory}
    (hinv : IndexInv hM₀ x t Cap_u Cap_q ω ptsK Act mem₀) :
    let SW := scratchWords ℓ M₀ Cap_q
    let SR := scratchReals d ℓ M₀
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp (insertStmt ℓ) mem₀ mem₁
        (100 + d * 30 + ℓ * 40 + ℓ * M₀ * (65 + d * 30) + Cap_u * (150 + ℓ * 60)) ∧
      extraCells SW SR mem₁ ≤ extraCells SW SR mem₀ + (5 * Cap_u + 2) ∧
      IndexInv hM₀ x t Cap_u Cap_q ω ptsK (insert k Act) mem₁ := by
  classical
  intro SW SR
  -- 1. (11, 22) := k.1
  rcases exec_wSet_sw SW SR inp hinv.clean 11 (.lit 22) 22 (mem_scratchWords_11 (i := 22) (by omega))
    (.intParam (.lit 0)) (k.1 : ℤ) 6
    (by simp [evalIntExpr])
    (by simp [evalIntExpr, hinp_p, listGetIntD])
    (by simp [evalIntExpr]) with
    ⟨m1, hs1, hex1, hw1_22, hw1_ne, hr1⟩
  -- 2. (11, 9) := 0
  rcases exec_wSet_sw SW SR inp hs1.2.1 11 (.lit 9) 9 (mem_scratchWords_11 (i := 9) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m2, hs2, hex2, hw2_9, hw2_ne, hr2⟩
  -- 3. Copy ptsK k to real table 3
  let copyBody : ArithRAMStmt :=
    seqStmts
      [ .writeRealHeap 3 (.readHeap 11 (.lit 9))
          (.activePtCoord (.readHeap 11 (.lit 22)) (.readHeap 11 (.lit 9))),
        .writeWordHeap 11 (.lit 9) (.add (.readHeap 11 (.lit 9)) (.lit 1)) ]
  let CopyInv : ℕ → ArithRAMMemory → Prop := fun c m =>
    extraCells SW SR m = extraCells SW SR mem₀ ∧
    wRead m 11 9 = (c : ℤ) ∧
    wRead m 11 22 = (k.1 : ℤ) ∧
    (∀ c' : Fin d, c'.1 < c → rRead m 3 (c'.1 : ℤ) = euclideanCoord (ptsK k) c') ∧
    (∀ tbl idx, (tbl ≠ 11 ∨ (idx ≠ 9 ∧ idx ≠ 22)) → wRead m tbl idx = wRead mem₀ tbl idx) ∧
    (∀ tbl idx, tbl ≠ 3 → rRead m tbl idx = rRead mem₀ tbl idx)
  have hCopy₀ : CopyInv 0 m2 := by
    refine ⟨hex2.trans hex1, hw2_9, (hw2_ne 11 22 (Or.inr (by decide))).trans hw1_22,
      fun _ hc => by omega, ?_, fun tbl idx _ => (hr2 tbl idx).trans (hr1 tbl idx)⟩
    intro tbl idx hne
    rcases hne with ht | ⟨h9, h22⟩
    · exact (hw2_ne tbl idx (Or.inl ht)).trans (hw1_ne tbl idx (Or.inl ht))
    · exact (hw2_ne tbl idx (Or.inr h9)).trans (hw1_ne tbl idx (Or.inr h22))
  rcases exec_repeatN (inp := inp) .dim copyBody d 3 30 CopyInv hs2.2.1 hCopy₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun c hc_lt m hcm ⟨hexm, hwc, hwk, hr3_prev, hwm_p, hrm_p⟩ => by
      let cF : Fin d := ⟨c, hc_lt⟩
      have heval_pt :
          (evalRealExpr inp 0 m (.activePtCoord (.readHeap 11 (.lit 22)) (.readHeap 11 (.lit 9)))).1 =
            euclideanCoord (ptsK k) cF := by
        rw [← hinp_c]
        exact evalRealExpr_activePtCoord inp m (.readHeap 11 (.lit 22)) (.readHeap 11 (.lit 9))
          k.1 cF (by simp [evalIntExpr, hwk]) (by simp [cF, evalIntExpr, hwc]) hinp_h
      rcases exec_rSet_sr SW SR inp hcm 3 (.readHeap 11 (.lit 9)) (c : ℤ)
        (mem_scratchReals_3 (i := c) (by omega))
        (.activePtCoord (.readHeap 11 (.lit 22)) (.readHeap 11 (.lit 9)))
        (euclideanCoord (ptsK k) cF) 20
        (by simp [evalIntExpr, hwc]) heval_pt (by simp [evalRealExpr, evalIntExpr]) with
        ⟨ma1, hb1, hexa1, hra1_3, hwa1, hra1_ne⟩
      have hwc_a1 : wRead ma1 11 9 = (c : ℤ) := (hwa1 11 9).trans hwc
      rcases exec_wSet_sw SW SR inp hb1.2.1 11 (.lit 9) 9 (mem_scratchWords_11 (i := 9) (by omega))
        (.add (.readHeap 11 (.lit 9)) (.lit 1)) (((c + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, hwc_a1]) (by simp [evalIntExpr]) with
        ⟨ma2, hb2, hexa2, hwa2_9, hwa2_ne, hra2⟩
      have hstepC : ExecStmt inp copyBody m ma2 30 := by
        unfold copyBody seqStmts
        exact (ExecStmt.seq hb1 hb2).mono_cost (by omega)
      refine ⟨ma2, hstepC, hexa2.trans (hexa1.trans hexm), hwa2_9,
        (hwa2_ne 11 22 (Or.inr (by decide))).trans ((hwa1 11 22).trans hwk), ?_, ?_, ?_⟩
      · intro c' hc'
        rcases Nat.lt_succ_iff_lt_or_eq.mp hc' with hlt | heq
        · exact (hra2 3 _).trans ((hra1_ne 3 _ (Or.inr (by omega))).trans (hr3_prev c' hlt))
        · have hc'_eq : c' = cF := Fin.ext heq
          subst hc'_eq
          exact (hra2 3 _).trans hra1_3
      · intro tbl idx hne
        exact (hwa2_ne tbl idx (by rcases hne with h1 | ⟨h9, _⟩; exact Or.inl h1; exact Or.inr h9)).trans
          ((hwa1 tbl idx).trans (hwm_p tbl idx hne))
      · intro tbl idx ht3
        exact (hra2 tbl idx).trans ((hra1_ne tbl idx (Or.inl ht3)).trans (hrm_p tbl idx ht3))) with
    ⟨m3, ⟨hex3, _, hwk_3, hr3_all, hwm_3, hrm_3⟩, hrepC⟩
  -- 4. (17, 6) := rRead 1 0 = t
  have hrt_3 : rRead m3 1 0 = t := (hrm_3 1 0 (by decide)).trans hinv.r_t
  rcases exec_rSet_sr SW SR inp hrepC.2.1 17 (.lit 6) 6 (mem_scratchReals_17 (i := 6) (by omega))
    (.readRealHeap 1 (.lit 0)) t 8
    (by simp [evalIntExpr]) (by simp [evalRealExpr, evalIntExpr, hrt_3])
    (by simp [evalRealExpr, evalIntExpr]) with
    ⟨m4, hs4, hex4, hr4_6, hw4, hr4_ne⟩
  -- 5. computeBaseListsStmt ℓ
  have hwM₀_4 : wRead m4 1 1 = (M₀ : ℤ) :=
    (hw4 1 1).trans ((hwm_3 1 1 (Or.inl (by decide))).trans hinv.w_M₀)
  have hrω_4 : ∀ (g : Fin (ℓ * M₀)) (c : Fin d),
      rRead m4 2 ((g.1 * d + c.1 : ℕ) : ℤ) = euclideanCoord (ω g) c := fun g c =>
    (hr4_ne 2 _ (Or.inl (by decide))).trans ((hrm_3 2 _ (by decide)).trans (hinv.r_ω g c))
  have hrv_4 : ∀ c : Fin d, rRead m4 3 (c.1 : ℤ) = euclideanCoord (ptsK k) c := fun c =>
    (hr4_ne 3 _ (Or.inl (by decide))).trans (hr3_all c c.2)
  rcases exec_computeBaseListsStmt (Cap_q := Cap_q) inp hM₀ t ω (ptsK k) hs4.2.1
    hwM₀_4 hr4_6 hrω_4 hrv_4 with
    ⟨m5, hs5, hex5, hw5_15, hw5_5, hw5_6, hw5_pres, hr5_pres⟩

  let deg := dataTupleCard t ω (ptsK k)
  have hprod_eq : (∏ j : Fin ℓ, (eligList t ω (ptsK k) j).length) = deg :=
    prod_eligList_eq_dataTupleCard t ω (ptsK k)
  rw [hprod_eq] at hw5_15

  -- Preservation helpers on m5
  have hwk_5 : wRead m5 11 22 = (k.1 : ℤ) :=
    (hw5_pres 11 22 (by decide) (by decide) (Or.inr (Or.inr (by decide)))).trans ((hw4 11 22).trans hwk_3)
  have hw_m5_hi : ∀ tbl idx, (tbl = 1 ∨ 20 ≤ tbl) → wRead m5 tbl idx = wRead mem₀ tbl idx := by
    intro tbl idx htbl
    have ht5 : tbl ≠ 5 := by omega
    have ht6 : tbl ≠ 6 := by omega
    have ht11 : tbl ≠ 11 := by omega
    exact (hw5_pres tbl idx ht5 ht6 (Or.inl ht11)).trans
      ((hw4 tbl idx).trans (hwm_3 tbl idx (Or.inl ht11)))
  have hr_m5_low : ∀ tbl idx, (tbl = 1 ∨ tbl = 2) → rRead m5 tbl idx = rRead mem₀ tbl idx := by
    intro tbl idx htbl
    have ht17 : tbl ≠ 17 := by omega
    have ht3 : tbl ≠ 3 := by omega
    exact (hr5_pres tbl idx (Or.inl ht17)).trans
      ((hr4_ne tbl idx (Or.inl ht17)).trans (hrm_3 tbl idx ht3))

  have hwCapu_5 : wRead m5 1 3 = (Cap_u : ℤ) := (hw_m5_hi 1 3 (Or.inl rfl)).trans hinv.w_Capu
  have hwm_5 : wRead m5 1 0 = (m : ℤ) := (hw_m5_hi 1 0 (Or.inl rfl)).trans hinv.w_m
  have hwM₀_5 : wRead m5 1 1 = (M₀ : ℤ) := (hw_m5_hi 1 1 (Or.inl rfl)).trans hinv.w_M₀

  let condE : ArithCondExpr :=
    .and (.intLe (.lit 1) (.readHeap 11 (.lit 15)))
      (.intLe (.readHeap 11 (.lit 15)) (.readHeap 1 (.lit 3)))
  let tBranch : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 20 (.readHeap 11 (.lit 22)) (.lit 1),
        .writeWordHeap 21 (.readHeap 11 (.lit 22)) (.readHeap 11 (.lit 15)),
        .writeWordHeap 11 (.lit 16) (.lit 0),
        .repeatN (.readHeap 11 (.lit 15))
          (seqStmts
            [ decodeTupleBucketStmt ℓ,
              bucketAppendStepStmt,
              .writeWordHeap 11 (.lit 16) (.add (.readHeap 11 (.lit 16)) (.lit 1)) ]) ]
  let fBranch : ArithRAMStmt :=
    .writeWordHeap 20 (.readHeap 11 (.lit 22)) (.lit 0)

  have hbkt_m5 : BucketInv Cap_u (bktKey hM₀ t ω ptsK) (activePairs Cap_u t ω ptsK Act) m5 :=
    bucketInv_congr hinv.buckets (fun tbl idx h22 _ => hw_m5_hi tbl idx (Or.inr (by omega)))

  by_cases hdeg : 1 ≤ deg ∧ deg ≤ Cap_u
  · -- True branch: store point and append deg bucket entries
    have hcond_t : (evalArithCond inp 0 m5 condE).1 = true := by
      simp only [condE, evalArithCond, evalIntExpr, words_read_heap, hw5_15, hwCapu_5,
        Bool.and_eq_true, decide_eq_true_eq]
      exact ⟨by exact_mod_cast hdeg.1, by exact_mod_cast hdeg.2⟩
    rcases exec_wSet_any SW SR inp hs5.2.1 20 (.readHeap 11 (.lit 22)) (k.1 : ℤ)
      (.lit 1) 1 8
      (by simp [evalIntExpr, hwk_5]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
      ⟨mt1, ht1, hext1, hwt1_20, hwt1_ne, hrt1⟩
    have hwk_t1 : wRead mt1 11 22 = (k.1 : ℤ) := (hwt1_ne 11 22 (Or.inl (by decide))).trans hwk_5
    have hwdeg_t1 : wRead mt1 11 15 = (deg : ℤ) := (hwt1_ne 11 15 (Or.inl (by decide))).trans hw5_15
    rcases exec_wSet_any SW SR inp ht1.2.1 21 (.readHeap 11 (.lit 22)) (k.1 : ℤ)
      (.readHeap 11 (.lit 15)) (deg : ℤ) 10
      (by simp [evalIntExpr, hwk_t1]) (by simp [evalIntExpr, hwdeg_t1]) (by simp [evalIntExpr]) with
      ⟨mt2, ht2, hext2, hwt2_21, hwt2_ne, hrt2⟩
    rcases exec_wSet_sw SW SR inp ht2.2.1 11 (.lit 16) 16 (mem_scratchWords_11 (i := 16) (by omega))
      (.lit 0) 0 4
      (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
      ⟨mt3, ht3, hext3, hwt3_16, hwt3_ne, hrt3⟩

    let P₀ := activePairs Cap_u t ω ptsK Act
    let PStep : ℕ → Finset (Fin m × ℕ) := fun s =>
      P₀ ∪ (Finset.range s).image (fun r => (k, r))
    let appBody : ArithRAMStmt :=
      seqStmts
        [ decodeTupleBucketStmt ℓ,
          bucketAppendStepStmt,
          .writeWordHeap 11 (.lit 16) (.add (.readHeap 11 (.lit 16)) (.lit 1)) ]
    let AppInv : ℕ → ArithRAMMemory → Prop := fun s mA =>
      extraCells SW SR mA ≤ extraCells SW SR mem₀ + 2 + 5 * s ∧
      wRead mA 11 16 = (s : ℤ) ∧
      wRead mA 11 22 = (k.1 : ℤ) ∧
      BucketInv Cap_u (bktKey hM₀ t ω ptsK) (PStep s) mA ∧
      (∀ tbl idx, tbl ∉ ([11, 22, 23, 24, 25, 26] : List ℕ) → wRead mA tbl idx = wRead mt3 tbl idx) ∧
      (∀ tbl idx, rRead mA tbl idx = rRead mt3 tbl idx)
    have hApp₀ : AppInv 0 mt3 := by
      have hbkt_mt3 : BucketInv Cap_u (bktKey hM₀ t ω ptsK) P₀ mt3 :=
        bucketInv_congr hbkt_m5 (fun tbl idx h22 _ =>
          (hwt3_ne tbl idx (Or.inl (by omega))).trans
            ((hwt2_ne tbl idx (Or.inl (by omega))).trans (hwt1_ne tbl idx (Or.inl (by omega)))))
      have hex_prev : extraCells SW SR m5 = extraCells SW SR mem₀ := hex5.trans (hex4.trans hex3)
      refine ⟨by omega,
        hwt3_16,
        (hwt3_ne 11 22 (Or.inr (by decide))).trans ((hwt2_ne 11 22 (Or.inl (by decide))).trans hwk_t1),
        by simpa [PStep] using hbkt_mt3,
        fun _ _ _ => rfl, fun _ _ => rfl⟩

    have hwdeg_t3 : wRead mt3 11 15 = (deg : ℤ) :=
      (hwt3_ne 11 15 (Or.inr (by decide))).trans ((hwt2_ne 11 15 (Or.inl (by decide))).trans hwdeg_t1)
    have hw_mt3_from_m5 : ∀ tbl idx, tbl ≠ 20 → tbl ≠ 21 → (tbl ≠ 11 ∨ idx ≠ 16) →
        wRead mt3 tbl idx = wRead m5 tbl idx := fun tbl idx h20 h21 h11 =>
      (hwt3_ne tbl idx h11).trans ((hwt2_ne tbl idx (Or.inl h21)).trans (hwt1_ne tbl idx (Or.inl h20)))

    have hprod_pos : 1 ≤ ∏ j : Fin ℓ, (eligList t ω (ptsK k) j).length := by
      rw [hprod_eq]; exact hdeg.1

    rcases exec_repeatN (inp := inp) (.readHeap 11 (.lit 15)) appBody deg 4 (150 + ℓ * 60)
      AppInv ht3.2.1 hApp₀
      (by simp [evalIntExpr, hwdeg_t3]) (by simp [evalIntExpr])
      (fun s hs_lt mA hcmA ⟨hexA, hwsA, hwkA, hbktA, hwmA, hrmA⟩ => by
        have hwM₀_A : wRead mA 1 1 = (M₀ : ℤ) :=
          (hwmA 1 1 (by decide)).trans
            ((hw_mt3_from_m5 1 1 (by decide) (by decide) (Or.inl (by decide))).trans hwM₀_5)
        have hwm_A : wRead mA 1 0 = (m : ℤ) :=
          (hwmA 1 0 (by decide)).trans
            ((hw_mt3_from_m5 1 0 (by decide) (by decide) (Or.inl (by decide))).trans hwm_5)
        have hwCapu_A : wRead mA 1 3 = (Cap_u : ℤ) :=
          (hwmA 1 3 (by decide)).trans
            ((hw_mt3_from_m5 1 3 (by decide) (by decide) (Or.inl (by decide))).trans hwCapu_5)
        have hw5_A : ∀ j : Fin ℓ, wRead mA 5 (j.1 : ℤ) = ((eligList t ω (ptsK k) j).length : ℤ) :=
          fun j => (hwmA 5 _ (by decide)).trans
            ((hw_mt3_from_m5 5 _ (by decide) (by decide) (Or.inl (by decide))).trans (hw5_5 j))
        have hw6_A : ∀ j : Fin ℓ, ∀ (pos : ℕ) (hpos : pos < (eligList t ω (ptsK k) j).length),
            wRead mA 6 ((j.1 * M₀ + pos : ℕ) : ℤ) = (((eligList t ω (ptsK k) j)[pos]).1 : ℤ) :=
          fun j pos hpos => (hwmA 6 _ (by decide)).trans
            ((hw_mt3_from_m5 6 _ (by decide) (by decide) (Or.inl (by decide))).trans (hw5_6 j pos hpos))
        -- 1. decodeTupleBucketStmt ℓ -> bktKey in (11, 18)
        rcases exec_decodeTupleBucketStmt (Cap_q := Cap_q) inp hM₀ t ω (ptsK k) hprod_pos s
          hcmA hwM₀_A hw5_A hw6_A hwsA with
          ⟨md1, hd1, hexd1, hwd1_18, hwd1_pres, hrd1⟩
        have hbkt_md1 : BucketInv Cap_u (bktKey hM₀ t ω ptsK) (PStep s) md1 :=
          bucketInv_congr hbktA (fun tbl idx h22 _ => hwd1_pres tbl idx (Or.inl (by omega)))
        have hnot_PStep : (k, s) ∉ PStep s := by
          simp only [PStep, P₀, Finset.mem_union, mem_activePairs_iff, Finset.mem_image,
            Finset.mem_range, not_or]
          refine ⟨fun h => hk_not h.1, ?_⟩
          rintro ⟨r, hr, heq⟩
          rcases Prod.mk.inj heq with ⟨_, rfl⟩
          omega
        have hPStep_succ : insert (k, s) (PStep s) = PStep (s + 1) := by
          ext p
          simp only [PStep, Finset.mem_insert, Finset.mem_union, Finset.mem_image,
            Finset.mem_range]
          constructor
          · rintro (rfl | hp | ⟨r, hr, rfl⟩)
            · exact Or.inr ⟨s, by omega, rfl⟩
            · exact Or.inl hp
            · exact Or.inr ⟨r, by omega, rfl⟩
          · rintro (hp | ⟨r, hr, rfl⟩)
            · exact Or.inr (Or.inl hp)
            · rcases Nat.lt_succ_iff_lt_or_eq.mp hr with hlt | rfl
              · exact Or.inr (Or.inr ⟨r, hlt, rfl⟩)
              · exact Or.inl rfl
        have hbkt_inj_step : ∀ {k' : Fin m} {s₁ s₂ : ℕ},
            (k', s₁) ∈ insert (k, s) (PStep s) → (k', s₂) ∈ insert (k, s) (PStep s) →
              bktKey hM₀ t ω ptsK k' s₁ = bktKey hM₀ t ω ptsK k' s₂ → s₁ = s₂ := by
          intro k' s₁ s₂ hm₁ hm₂ heq
          rw [hPStep_succ] at hm₁ hm₂
          have hlt_deg : ∀ {r : ℕ}, (k', r) ∈ PStep (s + 1) → r < dataTupleCard t ω (ptsK k') := by
            intro r hr
            rcases Finset.mem_union.mp hr with hp0 | himg
            · exact (mem_activePairs_iff.mp hp0).2.2.2
            · rcases Finset.mem_image.mp himg with ⟨r', hr', he⟩
              rcases Prod.mk.inj he with ⟨rfl, rfl⟩
              have hr_lt : r' < s + 1 := Finset.mem_range.mp hr'
              dsimp only [deg] at hs_lt
              omega
          exact bktKey_inj hM₀ t ω ptsK (hlt_deg hm₁) (hlt_deg hm₂) heq
        -- 2. bucketAppendStepStmt
        rcases exec_bucketAppendStep (ℓ := ℓ) (M₀ := M₀) (Cap_q := Cap_q) inp
          hbkt_inj_step (by omega : s < Cap_u) hnot_PStep hd1.2.1 hbkt_md1
          ((hwd1_pres 1 0 (Or.inl (by decide))).trans hwm_A)
          ((hwd1_pres 1 3 (Or.inl (by decide))).trans hwCapu_A)
          ((hwd1_pres 11 22 (Or.inr (Or.inr (by decide)))).trans hwkA)
          ((hwd1_pres 11 16 (Or.inr (Or.inl (by decide)))).trans hwsA)
          hwd1_18 with
          ⟨md2, hd2, hexd2, hbkt_md2, hwd2_pres, hrd2⟩
        rw [hPStep_succ] at hbkt_md2
        -- 3. (11, 16) := s + 1
        have hws_md2 : wRead md2 11 16 = (s : ℤ) :=
          (hwd2_pres 11 16 (by decide) (Or.inr (by decide))).trans
            ((hwd1_pres 11 16 (Or.inr (Or.inl (by decide)))).trans hwsA)
        rcases exec_wSet_sw SW SR inp hd2.2.1 11 (.lit 16) 16 (mem_scratchWords_11 (i := 16) (by omega))
          (.add (.readHeap 11 (.lit 16)) (.lit 1)) (((s + 1 : ℕ) : ℤ)) 10
          (by simp [evalIntExpr]) (by simp [evalIntExpr, hws_md2]) (by simp [evalIntExpr]) with
          ⟨md3, hd3, hexd3, hwd3_16, hwd3_ne, hrd3⟩
        have hstepA : ExecStmt inp appBody mA md3 (150 + ℓ * 60) := by
          unfold appBody seqStmts
          exact (ExecStmt.seq hd1 (ExecStmt.seq hd2 hd3)).mono_cost (by omega)
        have hex_md3 : extraCells SW SR md3 ≤ extraCells SW SR mem₀ + 2 + 5 * (s + 1) := by
          dsimp only [SW, SR] at hexA hexd1 hexd2 hexd3 ⊢
          omega
        refine ⟨md3, hstepA, hex_md3, hwd3_16,
          (hwd3_ne 11 22 (Or.inr (by decide))).trans
            ((hwd2_pres 11 22 (by decide) (Or.inr (by decide))).trans
              ((hwd1_pres 11 22 (Or.inr (Or.inr (by decide)))).trans hwkA)),
          bucketInv_congr hbkt_md2 (fun tbl idx h22 _ => hwd3_ne tbl idx (Or.inl (by omega))),
          ?_, ?_⟩
        · intro tbl idx hnot
          have ht11 : tbl ≠ 11 := by
            intro h; subst h; simp at hnot
          have ht_not22 : tbl ∉ ([22, 23, 24, 25, 26] : List ℕ) :=
            fun hm => hnot (List.mem_cons_of_mem 11 hm)
          exact (hwd3_ne tbl idx (Or.inl ht11)).trans
            ((hwd2_pres tbl idx ht_not22 (Or.inl ht11)).trans
              ((hwd1_pres tbl idx (Or.inl ht11)).trans (hwmA tbl idx hnot)))
        · intro tbl idx
          exact (hrd3 tbl idx).trans ((hrd2 tbl idx).trans ((hrd1 tbl idx).trans (hrmA tbl idx)))) with
      ⟨mt4, ⟨hext4, _, _, hbkt_mt4, hwm_mt4, hrm_mt4⟩, hrepA⟩

    have htBranch_exec : ExecStmt inp tBranch m5 mt4 (30 + Cap_u * (150 + ℓ * 60)) := by
      unfold tBranch seqStmts
      have hdeg_mul : deg * (150 + ℓ * 60) ≤ Cap_u * (150 + ℓ * 60) :=
        Nat.mul_le_mul_right _ hdeg.2
      exact (ExecStmt.seq ht1 (ExecStmt.seq ht2 (ExecStmt.seq ht3 hrepA))).mono_cost (by omega)
    have hite_exec : ExecStmt inp (.ite condE tBranch fBranch) m5 mt4
        (45 + Cap_u * (150 + ℓ * 60)) :=
      exec_ite_true hcond_t htBranch_exec (by simp only [condE, evalArithCond, evalIntExpr]; omega)
    have htot : ExecStmt inp (insertStmt ℓ) mem₀ mt4
        (100 + d * 30 + ℓ * 40 + ℓ * M₀ * (65 + d * 30) + Cap_u * (150 + ℓ * 60)) := by
      unfold insertStmt seqStmts
      exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 (ExecStmt.seq hrepC
        (ExecStmt.seq hs4 (ExecStmt.seq hs5 hite_exec))))).mono_cost (by omega)

    have hPStep_eq : PStep deg = activePairs Cap_u t ω ptsK (insert k Act) := by
      ext ⟨k', s'⟩
      simp only [PStep, P₀, Finset.mem_union, mem_activePairs_iff, Finset.mem_image,
        Finset.mem_range, Finset.mem_insert]
      constructor
      · rintro (⟨hk', h1, h2, hs'⟩ | ⟨r, hr, heq⟩)
        · exact ⟨Or.inr hk', h1, h2, hs'⟩
        · cases heq
          exact ⟨Or.inl rfl, hdeg.1, hdeg.2, hr⟩
      · rintro ⟨rfl | hk', h1, h2, hs'⟩
        · exact Or.inr ⟨s', hs', rfl⟩
        · exact Or.inl ⟨hk', h1, h2, hs'⟩
    rw [hPStep_eq] at hbkt_mt4

    have hw_mt4_1 : ∀ idx, wRead mt4 1 idx = wRead mem₀ 1 idx := fun idx =>
      (hwm_mt4 1 idx (by decide)).trans
        ((hw_mt3_from_m5 1 idx (by decide) (by decide) (Or.inl (by decide))).trans
          (hw_m5_hi 1 idx (Or.inl rfl)))
    have hr_mt4_12 : ∀ tbl idx, (tbl = 1 ∨ tbl = 2) → rRead mt4 tbl idx = rRead mem₀ tbl idx :=
      fun tbl idx htbl =>
        (hrm_mt4 tbl idx).trans
          ((hrt3 tbl idx).trans ((hrt2 tbl idx).trans ((hrt1 tbl idx).trans (hr_m5_low tbl idx htbl))))

    refine ⟨mt4, htot, by omega, hrepA.2.1,
      (hw_mt4_1 0).trans hinv.w_m,
      (hw_mt4_1 1).trans hinv.w_M₀,
      (hw_mt4_1 2).trans hinv.w_K,
      (hw_mt4_1 3).trans hinv.w_Capu,
      (hw_mt4_1 4).trans hinv.w_Capq,
      (hr_mt4_12 1 0 (Or.inl rfl)).trans hinv.r_t,
      (hr_mt4_12 1 1 (Or.inl rfl)).trans hinv.r_xt,
      fun g c => (hr_mt4_12 2 _ (Or.inr rfl)).trans (hinv.r_ω g c),
      ?_, ?_, hbkt_mt4⟩
    · intro k'
      rw [hwm_mt4 20 _ (by decide), hwt3_ne 20 _ (Or.inl (by decide)),
        hwt2_ne 20 _ (Or.inl (by decide))]
      by_cases hk' : k' = k
      · subst hk'
        change wRead mt1 20 (k'.1 : ℤ) = if k' ∈ insert k' Act ∧ 1 ≤ deg ∧ deg ≤ Cap_u then 1 else 0
        rw [if_pos ⟨Finset.mem_insert_self k' Act, hdeg⟩]
        exact hwt1_20
      · have hne : (k'.1 : ℤ) ≠ (k.1 : ℤ) := fun h => hk' (Fin.ext (Int.ofNat.inj h))
        rw [hwt1_ne 20 _ (Or.inr hne), hw_m5_hi 20 _ (Or.inr (by decide)), hinv.pt_stored k']
        simp [hk']
    · intro k' hk'_in h1 h2
      rw [hwm_mt4 21 _ (by decide), hwt3_ne 21 _ (Or.inl (by decide))]
      rcases Finset.mem_insert.mp hk'_in with rfl | hk'_old
      · exact hwt2_21
      · have hk'_ne : k' ≠ k := fun h => by subst h; exact hk_not hk'_old
        have hne : (k'.1 : ℤ) ≠ (k.1 : ℤ) := fun h => hk'_ne (Fin.ext (Int.ofNat.inj h))
        exact (hwt2_ne 21 _ (Or.inr hne)).trans
          ((hwt1_ne 21 _ (Or.inl (by decide))).trans
            ((hw_m5_hi 21 _ (Or.inr (by decide))).trans (hinv.pt_deg k' hk'_old h1 h2)))
  · -- False branch: mark ptStored[k] = 0
    have hcond_f : (evalArithCond inp 0 m5 condE).1 = false := by
      simp only [condE, evalArithCond, evalIntExpr, words_read_heap, hw5_15, hwCapu_5,
        Bool.and_eq_false_iff, decide_eq_false_iff_not]
      by_cases h1 : 1 ≤ deg
      · exact Or.inr (by have : ¬ deg ≤ Cap_u := fun h2 => hdeg ⟨h1, h2⟩; exact_mod_cast this)
      · exact Or.inl (by exact_mod_cast h1)
    rcases exec_wSet_any SW SR inp hs5.2.1 20 (.readHeap 11 (.lit 22)) (k.1 : ℤ)
      (.lit 0) 0 8
      (by simp [evalIntExpr, hwk_5]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
      ⟨mf1, hf1, hexf1, hwf1_20, hwf1_ne, hrf1⟩
    have hite_exec : ExecStmt inp (.ite condE tBranch fBranch) m5 mf1 25 :=
      exec_ite_false hcond_f hf1 (by simp [condE, evalArithCond, evalIntExpr])
    have htot : ExecStmt inp (insertStmt ℓ) mem₀ mf1
        (100 + d * 30 + ℓ * 40 + ℓ * M₀ * (65 + d * 30) + Cap_u * (150 + ℓ * 60)) := by
      unfold insertStmt seqStmts
      exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 (ExecStmt.seq hrepC
        (ExecStmt.seq hs4 (ExecStmt.seq hs5 hite_exec))))).mono_cost (by omega)
    have hPairs_eq : activePairs Cap_u t ω ptsK (insert k Act) = activePairs Cap_u t ω ptsK Act := by
      ext ⟨k', s'⟩
      simp only [mem_activePairs_iff, Finset.mem_insert]
      constructor
      · rintro ⟨rfl | hk', h1, h2, hs'⟩
        · exact absurd ⟨h1, h2⟩ hdeg
        · exact ⟨hk', h1, h2, hs'⟩
      · rintro ⟨hk', h1, h2, hs'⟩
        exact ⟨Or.inr hk', h1, h2, hs'⟩
    have hbkt_mf1 : BucketInv Cap_u (bktKey hM₀ t ω ptsK)
        (activePairs Cap_u t ω ptsK (insert k Act)) mf1 := by
      rw [hPairs_eq]
      exact bucketInv_congr hbkt_m5 (fun tbl idx h22 _ => hwf1_ne tbl idx (Or.inl (by omega)))
    have hex_prev : extraCells SW SR m5 = extraCells SW SR mem₀ := hex5.trans (hex4.trans hex3)
    refine ⟨mf1, htot, by omega, hf1.2.1,
      (hwf1_ne 1 0 (Or.inl (by decide))).trans hwm_5,
      (hwf1_ne 1 1 (Or.inl (by decide))).trans hwM₀_5,
      (hwf1_ne 1 2 (Or.inl (by decide))).trans ((hw_m5_hi 1 2 (Or.inl rfl)).trans hinv.w_K),
      (hwf1_ne 1 3 (Or.inl (by decide))).trans hwCapu_5,
      (hwf1_ne 1 4 (Or.inl (by decide))).trans ((hw_m5_hi 1 4 (Or.inl rfl)).trans hinv.w_Capq),
      (hrf1 1 0).trans ((hr_m5_low 1 0 (Or.inl rfl)).trans hinv.r_t),
      (hrf1 1 1).trans ((hr_m5_low 1 1 (Or.inl rfl)).trans hinv.r_xt),
      fun g c => (hrf1 2 _).trans ((hr_m5_low 2 _ (Or.inr rfl)).trans (hinv.r_ω g c)),
      ?_, ?_, hbkt_mf1⟩
    · intro k'
      by_cases hk' : k' = k
      · subst hk'
        change wRead mf1 20 (k'.1 : ℤ) = if k' ∈ insert k' Act ∧ 1 ≤ deg ∧ deg ≤ Cap_u then 1 else 0
        rw [if_neg (fun h => hdeg h.2)]
        exact hwf1_20
      · have hne : (k'.1 : ℤ) ≠ (k.1 : ℤ) := fun h => hk' (Fin.ext (Int.ofNat.inj h))
        rw [hwf1_ne 20 _ (Or.inr hne), hw_m5_hi 20 _ (Or.inr (by decide)), hinv.pt_stored k']
        simp [hk']
    · intro k' hk'_in h1 h2
      rcases Finset.mem_insert.mp hk'_in with rfl | hk'_old
      · exact absurd ⟨h1, h2⟩ hdeg
      · exact (hwf1_ne 21 _ (Or.inl (by decide))).trans
          ((hw_m5_hi 21 _ (Or.inr (by decide))).trans (hinv.pt_deg k' hk'_old h1 h2))

/-- Delete handle `k = .intParam (.lit 0)` from the capped explicit index. -/
def deleteStmt : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 11 (.lit 22) (.intParam (.lit 0)),
      .ite (.intEq (.readHeap 20 (.readHeap 11 (.lit 22))) (.lit 1))
        (seqStmts
          [ .writeWordHeap 20 (.readHeap 11 (.lit 22)) (.lit 0),
            .writeWordHeap 11 (.lit 27) (.readHeap 21 (.readHeap 11 (.lit 22))),
            .writeWordHeap 11 (.lit 16) (.lit 0),
            .repeatN (.readHeap 11 (.lit 27))
              (seqStmts
                [ bucketRemoveStepStmt,
                  .writeWordHeap 11 (.lit 16) (.add (.readHeap 11 (.lit 16)) (.lit 1)) ]) ])
        .skip ]

theorem exec_deleteStmt {d ℓ M₀ Cap_u Cap_q m : ℕ}
    (hM₀ : 1 ≤ M₀) {x t : ℝ}
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d))
    {Act : Finset (Fin m)} (k : Fin m)
    (inp : ArithRAMInput d)
    (hinp_p : inp.intParams = [(k.1 : ℤ)])
    {mem₀ : ArithRAMMemory}
    (hinv : IndexInv hM₀ x t Cap_u Cap_q ω ptsK Act mem₀) :
    let SW := scratchWords ℓ M₀ Cap_q
    let SR := scratchReals d ℓ M₀
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp deleteStmt mem₀ mem₁ (45 + Cap_u * 165) ∧
      extraCells SW SR mem₁ ≤ extraCells SW SR mem₀ + (4 * Cap_u + 1) ∧
      IndexInv hM₀ x t Cap_u Cap_q ω ptsK (Act.erase k) mem₁ := by
  classical
  intro SW SR
  rcases exec_wSet_sw SW SR inp hinv.clean 11 (.lit 22) 22 (mem_scratchWords_11 (i := 22) (by omega))
    (.intParam (.lit 0)) (k.1 : ℤ) 6
    (by simp [evalIntExpr]) (by simp [evalIntExpr, hinp_p, listGetIntD]) (by simp [evalIntExpr]) with
    ⟨m1, hs1, hex1, hw1_22, hw1_ne, hr1⟩
  let deg := dataTupleCard t ω (ptsK k)
  let condE : ArithCondExpr := .intEq (.readHeap 20 (.readHeap 11 (.lit 22))) (.lit 1)
  let tBranch : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 20 (.readHeap 11 (.lit 22)) (.lit 0),
        .writeWordHeap 11 (.lit 27) (.readHeap 21 (.readHeap 11 (.lit 22))),
        .writeWordHeap 11 (.lit 16) (.lit 0),
        .repeatN (.readHeap 11 (.lit 27))
          (seqStmts
            [ bucketRemoveStepStmt,
              .writeWordHeap 11 (.lit 16) (.add (.readHeap 11 (.lit 16)) (.lit 1)) ]) ]
  have hw20_m1 : wRead m1 20 (k.1 : ℤ) =
      if k ∈ Act ∧ 1 ≤ deg ∧ deg ≤ Cap_u then 1 else 0 :=
    (hw1_ne 20 _ (Or.inl (by decide))).trans (hinv.pt_stored k)
  have hbkt_m1 : BucketInv Cap_u (bktKey hM₀ t ω ptsK) (activePairs Cap_u t ω ptsK Act) m1 :=
    bucketInv_congr hinv.buckets (fun tbl idx h22 _ => hw1_ne tbl idx (Or.inl (by omega)))

  by_cases hstored : k ∈ Act ∧ 1 ≤ deg ∧ deg ≤ Cap_u
  · rw [if_pos hstored] at hw20_m1
    have hcond_t : (evalArithCond inp 0 m1 condE).1 = true := by
      simp [condE, evalArithCond, evalIntExpr, hw1_22, hw20_m1]
    rcases exec_wSet_any SW SR inp hs1.2.1 20 (.readHeap 11 (.lit 22)) (k.1 : ℤ)
      (.lit 0) 0 8
      (by simp [evalIntExpr, hw1_22]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
      ⟨mt1, ht1, hext1, hwt1_20, hwt1_ne, hrt1⟩
    have hwk_t1 : wRead mt1 11 22 = (k.1 : ℤ) := (hwt1_ne 11 22 (Or.inl (by decide))).trans hw1_22
    have hw21_t1 : wRead mt1 21 (k.1 : ℤ) = (deg : ℤ) :=
      (hwt1_ne 21 _ (Or.inl (by decide))).trans
        ((hw1_ne 21 _ (Or.inl (by decide))).trans (hinv.pt_deg k hstored.1 hstored.2.1 hstored.2.2))
    rcases exec_wSet_sw SW SR inp ht1.2.1 11 (.lit 27) 27 (mem_scratchWords_11 (i := 27) (by omega))
      (.readHeap 21 (.readHeap 11 (.lit 22))) (deg : ℤ) 10
      (by simp [evalIntExpr])
      (by simp only [evalIntExpr, words_read_heap, hwk_t1]; exact hw21_t1)
      (by simp [evalIntExpr]) with
      ⟨mt2, ht2, hext2, hwt2_27, hwt2_ne, hrt2⟩
    rcases exec_wSet_sw SW SR inp ht2.2.1 11 (.lit 16) 16 (mem_scratchWords_11 (i := 16) (by omega))
      (.lit 0) 0 4
      (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
      ⟨mt3, ht3, hext3, hwt3_16, hwt3_ne, hrt3⟩

    let P_er := activePairs Cap_u t ω ptsK (Act.erase k)
    let DStep : ℕ → Finset (Fin m × ℕ) := fun s =>
      P_er ∪ (Finset.Ico s deg).image (fun r => (k, r))
    have hDStep_0 : DStep 0 = activePairs Cap_u t ω ptsK Act := by
      ext ⟨k', s'⟩
      simp only [DStep, P_er, Finset.mem_union, mem_activePairs_iff, Finset.mem_erase,
        Finset.mem_image, Finset.mem_Ico, zero_le, true_and]
      constructor
      · rintro (⟨⟨_, hk'⟩, h1, h2, hs'⟩ | ⟨r, hr, heq⟩)
        · exact ⟨hk', h1, h2, hs'⟩
        · cases heq; exact ⟨hstored.1, hstored.2.1, hstored.2.2, hr⟩
      · rintro ⟨hk', h1, h2, hs'⟩
        by_cases he : k' = k
        · subst he; exact Or.inr ⟨s', hs', rfl⟩
        · exact Or.inl ⟨⟨he, hk'⟩, h1, h2, hs'⟩

    let remBody : ArithRAMStmt :=
      seqStmts
        [ bucketRemoveStepStmt,
          .writeWordHeap 11 (.lit 16) (.add (.readHeap 11 (.lit 16)) (.lit 1)) ]
    let RemInv : ℕ → ArithRAMMemory → Prop := fun s mR =>
      extraCells SW SR mR ≤ extraCells SW SR mem₀ + 1 + 4 * s ∧
      wRead mR 11 16 = (s : ℤ) ∧
      wRead mR 11 22 = (k.1 : ℤ) ∧
      BucketInv Cap_u (bktKey hM₀ t ω ptsK) (DStep s) mR ∧
      (∀ tbl idx, tbl ∉ ([11, 23, 24, 25, 26] : List ℕ) → wRead mR tbl idx = wRead mt3 tbl idx) ∧
      (∀ tbl idx, rRead mR tbl idx = rRead mt3 tbl idx)
    have hRem₀ : RemInv 0 mt3 := by
      have hbkt_mt3 : BucketInv Cap_u (bktKey hM₀ t ω ptsK) (DStep 0) mt3 := by
        rw [hDStep_0]
        exact bucketInv_congr hbkt_m1 (fun tbl idx h22 _ =>
          (hwt3_ne tbl idx (Or.inl (by omega))).trans
            ((hwt2_ne tbl idx (Or.inl (by omega))).trans (hwt1_ne tbl idx (Or.inl (by omega)))))
      refine ⟨by omega, hwt3_16,
        (hwt3_ne 11 22 (Or.inr (by decide))).trans ((hwt2_ne 11 22 (Or.inr (by decide))).trans hwk_t1),
        hbkt_mt3, fun _ _ _ => rfl, fun _ _ => rfl⟩

    have hwdeg_mt3 : wRead mt3 11 27 = (deg : ℤ) :=
      (hwt3_ne 11 27 (Or.inr (by decide))).trans hwt2_27
    have hw_mt3_1 : ∀ idx, wRead mt3 1 idx = wRead mem₀ 1 idx := fun idx =>
      (hwt3_ne 1 idx (Or.inl (by decide))).trans
        ((hwt2_ne 1 idx (Or.inl (by decide))).trans
          ((hwt1_ne 1 idx (Or.inl (by decide))).trans (hw1_ne 1 idx (Or.inl (by decide)))))

    rcases exec_repeatN (inp := inp) (.readHeap 11 (.lit 27)) remBody deg 4 165
      RemInv ht3.2.1 hRem₀
      (by simp [evalIntExpr, hwdeg_mt3]) (by simp [evalIntExpr])
      (fun s hs_lt mR hcmR ⟨hexR, hwsR, hwkR, hbktR, hwmR, hrmR⟩ => by
        have hmem_ks : (k, s) ∈ DStep s := by
          simp only [DStep, Finset.mem_union, Finset.mem_image, Finset.mem_Ico]
          exact Or.inr ⟨s, ⟨le_rfl, hs_lt⟩, rfl⟩
        have hbkt_inj_R : ∀ {k' : Fin m} {s₁ s₂ : ℕ},
            (k', s₁) ∈ DStep s → (k', s₂) ∈ DStep s →
              bktKey hM₀ t ω ptsK k' s₁ = bktKey hM₀ t ω ptsK k' s₂ → s₁ = s₂ := by
          intro k' s₁ s₂ hm₁ hm₂ heq
          have hlt_d : ∀ {r : ℕ}, (k', r) ∈ DStep s → r < dataTupleCard t ω (ptsK k') := by
            intro r hr
            rcases Finset.mem_union.mp hr with hp0 | himg
            · exact (mem_activePairs_iff.mp hp0).2.2.2
            · rcases Finset.mem_image.mp himg with ⟨r', hr', he⟩
              cases he
              exact (Finset.mem_Ico.mp hr').2
          exact bktKey_inj hM₀ t ω ptsK (hlt_d hm₁) (hlt_d hm₂) heq
        have hwm_R : wRead mR 1 0 = (m : ℤ) :=
          (hwmR 1 0 (by decide)).trans ((hw_mt3_1 0).trans hinv.w_m)
        have hwCapu_R : wRead mR 1 3 = (Cap_u : ℤ) :=
          (hwmR 1 3 (by decide)).trans ((hw_mt3_1 3).trans hinv.w_Capu)
        rcases exec_bucketRemoveStep (ℓ := ℓ) (M₀ := M₀) (Cap_q := Cap_q) inp
          hbkt_inj_R hmem_ks hcmR hbktR hwm_R hwCapu_R hwkR hwsR with
          ⟨mr1, hr_step, hexr1, hbkt_mr1, hwr1_pres, hrr1⟩
        have hDStep_succ : (DStep s).erase (k, s) = DStep (s + 1) := by
          ext ⟨k', s'⟩
          simp only [DStep, P_er, Finset.mem_erase, Finset.mem_union, mem_activePairs_iff,
            Finset.mem_image, Finset.mem_Ico]
          constructor
          · rintro ⟨hne, hp | ⟨r, ⟨hr1, hr2⟩, heq⟩⟩
            · exact Or.inl hp
            · rcases Prod.mk.inj heq with ⟨rfl, rfl⟩
              have hne_r : r ≠ s := fun h => hne (by subst h; rfl)
              exact Or.inr ⟨r, ⟨by omega, hr2⟩, rfl⟩
          · rintro (⟨⟨hk'_ne, hk'_in⟩, h1, h2, hs'⟩ | ⟨r, ⟨hr1, hr2⟩, heq⟩)
            · refine ⟨fun h => hk'_ne (Prod.mk.inj h).1, Or.inl ⟨⟨hk'_ne, hk'_in⟩, h1, h2, hs'⟩⟩
            · rcases Prod.mk.inj heq with ⟨rfl, rfl⟩
              have hne_pair : (k, r) ≠ (k, s) := fun h => by
                have hr_eq : r = s := (Prod.mk.inj h).2
                omega
              exact ⟨hne_pair, Or.inr ⟨r, ⟨by omega, hr2⟩, rfl⟩⟩
        rw [hDStep_succ] at hbkt_mr1
        have hws_mr1 : wRead mr1 11 16 = (s : ℤ) :=
          (hwr1_pres 11 16 (by decide) (Or.inr (by decide))).trans hwsR
        rcases exec_wSet_sw SW SR inp hr_step.2.1 11 (.lit 16) 16 (mem_scratchWords_11 (i := 16) (by omega))
          (.add (.readHeap 11 (.lit 16)) (.lit 1)) (((s + 1 : ℕ) : ℤ)) 10
          (by simp [evalIntExpr]) (by simp [evalIntExpr, hws_mr1]) (by simp [evalIntExpr]) with
          ⟨mr2, hr_inc, hexr2, hwr2_16, hwr2_ne, hrr2⟩
        have hstepR : ExecStmt inp remBody mR mr2 165 := by
          unfold remBody seqStmts
          exact (ExecStmt.seq hr_step hr_inc).mono_cost (by omega)
        have hex_mr2 : extraCells SW SR mr2 ≤ extraCells SW SR mem₀ + 1 + 4 * (s + 1) := by
          dsimp only [SW, SR] at hexR hexr1 hexr2 ⊢
          omega
        refine ⟨mr2, hstepR, hex_mr2, hwr2_16,
          (hwr2_ne 11 22 (Or.inr (by decide))).trans
            ((hwr1_pres 11 22 (by decide) (Or.inr (by decide))).trans hwkR),
          bucketInv_congr hbkt_mr1 (fun tbl idx h22 _ => hwr2_ne tbl idx (Or.inl (by omega))),
          ?_, ?_⟩
        · intro tbl idx hnot
          have ht11 : tbl ≠ 11 := by intro h; subst h; simp at hnot
          have ht_not23 : tbl ∉ ([23, 24, 25, 26] : List ℕ) :=
            fun hm => hnot (List.mem_cons_of_mem 11 hm)
          exact (hwr2_ne tbl idx (Or.inl ht11)).trans
            ((hwr1_pres tbl idx ht_not23 (Or.inl ht11)).trans (hwmR tbl idx hnot))
        · intro tbl idx
          exact (hrr2 tbl idx).trans ((hrr1 tbl idx).trans (hrmR tbl idx))) with
      ⟨mt4, ⟨hext4, _, _, hbkt_mt4, hwm_mt4, hrm_mt4⟩, hrepR⟩

    have hDStep_deg : DStep deg = P_er := by
      simp [DStep]
    rw [hDStep_deg] at hbkt_mt4
    have htBranch_exec : ExecStmt inp tBranch m1 mt4 (26 + Cap_u * 165) := by
      unfold tBranch seqStmts
      have hdeg_mul : deg * 165 ≤ Cap_u * 165 := Nat.mul_le_mul_right _ hstored.2.2
      exact (ExecStmt.seq ht1 (ExecStmt.seq ht2 (ExecStmt.seq ht3 hrepR))).mono_cost (by omega)
    have hite_exec : ExecStmt inp (.ite condE tBranch .skip) m1 mt4 (36 + Cap_u * 165) :=
      exec_ite_true hcond_t htBranch_exec (by simp only [condE, evalArithCond, evalIntExpr]; omega)
    have htot : ExecStmt inp deleteStmt mem₀ mt4 (45 + Cap_u * 165) := by
      unfold deleteStmt seqStmts
      exact (ExecStmt.seq hs1 hite_exec).mono_cost (by omega)
    have hw_mt4_1 : ∀ idx, wRead mt4 1 idx = wRead mem₀ 1 idx :=
      fun idx => (hwm_mt4 1 idx (by decide)).trans (hw_mt3_1 idx)
    have hr_mt4 : ∀ tbl idx, rRead mt4 tbl idx = rRead mem₀ tbl idx := fun tbl idx =>
      (hrm_mt4 tbl idx).trans
        ((hrt3 tbl idx).trans ((hrt2 tbl idx).trans ((hrt1 tbl idx).trans (hr1 tbl idx))))
    refine ⟨mt4, htot, by omega, hrepR.2.1,
      (hw_mt4_1 0).trans hinv.w_m,
      (hw_mt4_1 1).trans hinv.w_M₀,
      (hw_mt4_1 2).trans hinv.w_K,
      (hw_mt4_1 3).trans hinv.w_Capu,
      (hw_mt4_1 4).trans hinv.w_Capq,
      (hr_mt4 1 0).trans hinv.r_t,
      (hr_mt4 1 1).trans hinv.r_xt,
      fun g c => (hr_mt4 2 _).trans (hinv.r_ω g c),
      ?_, ?_, hbkt_mt4⟩
    · intro k'
      rw [hwm_mt4 20 _ (by decide), hwt3_ne 20 _ (Or.inl (by decide)),
        hwt2_ne 20 _ (Or.inl (by decide))]
      by_cases hk' : k' = k
      · subst hk'
        simp [hwt1_20]
      · have hne : (k'.1 : ℤ) ≠ (k.1 : ℤ) := fun h => hk' (Fin.ext (Int.ofNat.inj h))
        rw [hwt1_ne 20 _ (Or.inr hne), hw1_ne 20 _ (Or.inl (by decide)), hinv.pt_stored k']
        simp [hk']
    · intro k' hk'_er h1 h2
      rcases Finset.mem_erase.mp hk'_er with ⟨_, hk'_old⟩
      exact (hwm_mt4 21 _ (by decide)).trans
        ((hwt3_ne 21 _ (Or.inl (by decide))).trans
          ((hwt2_ne 21 _ (Or.inl (by decide))).trans
            ((hwt1_ne 21 _ (Or.inl (by decide))).trans
              ((hw1_ne 21 _ (Or.inl (by decide))).trans (hinv.pt_deg k' hk'_old h1 h2)))))
  · -- False branch: point was not stored in buckets
    rw [if_neg hstored] at hw20_m1
    have hcond_f : (evalArithCond inp 0 m1 condE).1 = false := by
      simp [condE, evalArithCond, evalIntExpr, hw1_22, hw20_m1]
    have hite_exec : ExecStmt inp (.ite condE tBranch .skip) m1 m1 15 :=
      exec_ite_false hcond_f (ExecStmt.skip inp hs1.2.1) (by simp [condE, evalArithCond, evalIntExpr])
    have htot : ExecStmt inp deleteStmt mem₀ m1 (45 + Cap_u * 165) := by
      unfold deleteStmt seqStmts
      exact (ExecStmt.seq hs1 hite_exec).mono_cost (by omega)
    have hPairs_eq : activePairs Cap_u t ω ptsK (Act.erase k) = activePairs Cap_u t ω ptsK Act := by
      ext ⟨k', s'⟩
      simp only [mem_activePairs_iff, Finset.mem_erase]
      constructor
      · rintro ⟨⟨_, hk'⟩, h1, h2, hs'⟩; exact ⟨hk', h1, h2, hs'⟩
      · rintro ⟨hk', h1, h2, hs'⟩
        refine ⟨⟨?_, hk'⟩, h1, h2, hs'⟩
        rintro rfl
        exact hstored ⟨hk', h1, h2⟩
    rw [← hPairs_eq] at hbkt_m1
    refine ⟨m1, htot, by omega, hs1.2.1,
      (hw1_ne 1 0 (Or.inl (by decide))).trans hinv.w_m,
      (hw1_ne 1 1 (Or.inl (by decide))).trans hinv.w_M₀,
      (hw1_ne 1 2 (Or.inl (by decide))).trans hinv.w_K,
      (hw1_ne 1 3 (Or.inl (by decide))).trans hinv.w_Capu,
      (hw1_ne 1 4 (Or.inl (by decide))).trans hinv.w_Capq,
      (hr1 1 0).trans hinv.r_t,
      (hr1 1 1).trans hinv.r_xt,
      fun g c => (hr1 2 _).trans (hinv.r_ω g c),
      ?_, ?_, hbkt_m1⟩
    · intro k'
      rw [hw1_ne 20 _ (Or.inl (by decide))]
      by_cases hk' : k' = k
      · subst hk'
        have h0 : wRead mem₀ 20 (k'.1 : ℤ) = 0 := by
          rw [hinv.pt_stored k', if_neg hstored]
        simp [h0]
      · rw [hinv.pt_stored k']
        simp [hk']
    · intro k' hk'_er h1 h2
      rcases Finset.mem_erase.mp hk'_er with ⟨_, hk'_old⟩
      exact (hw1_ne 21 _ (Or.inl (by decide))).trans (hinv.pt_deg k' hk'_old h1 h2)


/-! ### 4. Capped query procedure `queryStmt` and its soundness, distinctness, and completeness -/

def qStepCount (Cap_q : ℕ) (lenOf : ℕ → ℕ) : ℕ → ℕ
  | 0 => 0
  | qIdx + 1 => min (Cap_q + 1) (qStepCount Cap_q lenOf qIdx + lenOf qIdx)

theorem qStepCount_le_cap (Cap_q : ℕ) (lenOf : ℕ → ℕ) :
    ∀ n : ℕ, qStepCount Cap_q lenOf n ≤ Cap_q + 1
  | 0 => by simp [qStepCount]
  | n + 1 => Nat.min_le_left _ _

theorem qStepCount_mono (Cap_q : ℕ) (lenOf : ℕ → ℕ) (n : ℕ) :
    qStepCount Cap_q lenOf n ≤ qStepCount Cap_q lenOf (n + 1) := by
  have hle := qStepCount_le_cap Cap_q lenOf n
  dsimp only [qStepCount]
  omega

theorem qStepCount_mono_le (Cap_q : ℕ) (lenOf : ℕ → ℕ) {i j : ℕ} (hij : i ≤ j) :
    qStepCount Cap_q lenOf i ≤ qStepCount Cap_q lenOf j := by
  induction hij with
  | refl => exact le_rfl
  | @step m _ ih => exact ih.trans (qStepCount_mono Cap_q lenOf m)

theorem qStepCount_diff (Cap_q : ℕ) (lenOf : ℕ → ℕ) (n : ℕ) :
    min (lenOf n) (Cap_q + 1 - qStepCount Cap_q lenOf n) =
      qStepCount Cap_q lenOf (n + 1) - qStepCount Cap_q lenOf n := by
  have hle := qStepCount_le_cap Cap_q lenOf n
  dsimp only [qStepCount]
  omega

/-- Capped query procedure writing `r ≤ Cap_q + 1` to `0[0]` and candidate handles to `0[1..r]`. -/
def queryStmt (ℓ : ℕ) : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 0 (.lit 0) (.lit 0),
      .writeWordHeap 11 (.lit 9) (.lit 0),
      .repeatN .dim
        (seqStmts
          [ .writeRealHeap 3 (.readHeap 11 (.lit 9)) (.extraReal (.readHeap 11 (.lit 9))),
            .writeWordHeap 11 (.lit 9) (.add (.readHeap 11 (.lit 9)) (.lit 1)) ]),
      .writeRealHeap 17 (.lit 6) (.readRealHeap 1 (.lit 1)),
      computeBaseListsStmt ℓ,
      .ite (.intLe (.lit 1) (.readHeap 11 (.lit 15)))
        (seqStmts
          [ .ite (.intLe (.readHeap 11 (.lit 15)) (.readHeap 1 (.lit 4)))
              (.writeWordHeap 11 (.lit 27) (.readHeap 11 (.lit 15)))
              (.writeWordHeap 11 (.lit 27) (.readHeap 1 (.lit 4))),
            .writeWordHeap 11 (.lit 16) (.lit 0),
            .repeatN (.readHeap 11 (.lit 27))
              (seqStmts
                [ decodeTupleBucketStmt ℓ,
                  .writeWordHeap 11 (.lit 23) (.readHeap 24 (.readHeap 11 (.lit 18))),
                  .writeWordHeap 11 (.lit 24)
                    (.sub (.add (.readHeap 1 (.lit 4)) (.lit 1)) (.readHeap 0 (.lit 0))),
                  .ite (.intLe (.readHeap 11 (.lit 23)) (.readHeap 11 (.lit 24)))
                    (.writeWordHeap 11 (.lit 25) (.readHeap 11 (.lit 23)))
                    (.writeWordHeap 11 (.lit 25) (.readHeap 11 (.lit 24))),
                  .writeWordHeap 11 (.lit 26) (.lit 0),
                  .repeatN (.readHeap 11 (.lit 25))
                    (seqStmts
                      [ .writeWordHeap 11 (.lit 28)
                          (.readHeap 25
                            (.add
                              (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
                              (.readHeap 11 (.lit 26)))),
                        .writeWordHeap 11 (.lit 29) (.add (.readHeap 0 (.lit 0)) (.lit 1)),
                        .writeWordHeap 0 (.readHeap 11 (.lit 29)) (.readHeap 11 (.lit 28)),
                        .writeWordHeap 0 (.lit 0) (.readHeap 11 (.lit 29)),
                        .writeWordHeap 11 (.lit 26) (.add (.readHeap 11 (.lit 26)) (.lit 1)) ]),
                  .writeWordHeap 11 (.lit 16) (.add (.readHeap 11 (.lit 16)) (.lit 1)) ]) ])
        .skip ]

theorem exec_queryStmt {d ℓ M₀ Cap_u Cap_q m : ℕ}
    (hM₀ : 1 ≤ M₀) {x t : ℝ}
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d))
    {Act : Finset (Fin m)}
    (z : EuclideanSpace ℝ (Fin d))
    (inp : ArithRAMInput d)
    (hinp_z : inp.extraReals = List.ofFn (fun c : Fin d => euclideanCoord z c))
    {mem₀ : ArithRAMMemory}
    (hinv : IndexInv hM₀ x t Cap_u Cap_q ω ptsK Act mem₀) :
    let SW := scratchWords ℓ M₀ Cap_q
    let SR := scratchReals d ℓ M₀
    ∃ (qMem : ArithRAMMemory) (r : ℕ),
      ExecStmt inp (queryStmt ℓ) mem₀ qMem
        (160 + d * 30 + ℓ * 40 + ℓ * M₀ * (65 + d * 30) + Cap_q * (130 + ℓ * 60)) ∧
      extraCells SW SR qMem = extraCells SW SR mem₀ ∧
      r ≤ Cap_q + 1 ∧
      wRead qMem 0 0 = (r : ℤ) ∧
      (∃ pairs : Fin r → Fin m × (Fin ℓ → Fin M₀),
        Function.Injective pairs ∧
        ∀ u : Fin r,
          (pairs u).1 ∈ Act ∧
          IsSharedTuple x t ω (ptsK (pairs u).1) z (pairs u).2 ∧
          wRead qMem 0 ((u.1 + 1 : ℕ) : ℤ) = ((pairs u).1.1 : ℤ)) ∧
      (r < Cap_q + 1 →
        ∀ k_star : Fin m,
          k_star ∈ Act →
          dataTupleCard t ω (ptsK k_star) ≤ Cap_u →
          queryTupleCard x t ω z ≤ Cap_q →
          (∃ τ : Fin ℓ → Fin M₀, IsSharedTuple x t ω (ptsK k_star) z τ) →
          ∃ idx < r, wRead qMem 0 ((idx + 1 : ℕ) : ℤ) = (k_star.1 : ℤ)) := by
  classical
  intro SW SR
  -- 1. 0[0] := 0
  rcases exec_wSet_sw SW SR inp hinv.clean 0 (.lit 0) 0 (mem_scratchWords_0 (i := 0) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m1, hs1, hex1, hw1_00, hw1_ne, hr1⟩
  -- 2. (11, 9) := 0
  rcases exec_wSet_sw SW SR inp hs1.2.1 11 (.lit 9) 9 (mem_scratchWords_11 (i := 9) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m2, hs2, hex2, hw2_9, hw2_ne, hr2⟩
  -- 3. Copy z into real table 3
  let copyZBody : ArithRAMStmt :=
    seqStmts
      [ .writeRealHeap 3 (.readHeap 11 (.lit 9)) (.extraReal (.readHeap 11 (.lit 9))),
        .writeWordHeap 11 (.lit 9) (.add (.readHeap 11 (.lit 9)) (.lit 1)) ]
  let CopyZInv : ℕ → ArithRAMMemory → Prop := fun c m =>
    extraCells SW SR m = extraCells SW SR mem₀ ∧
    wRead m 0 0 = 0 ∧
    wRead m 11 9 = (c : ℤ) ∧
    (∀ c' : Fin d, c'.1 < c → rRead m 3 (c'.1 : ℤ) = euclideanCoord z c') ∧
    (∀ tbl idx, tbl ≠ 0 → (tbl ≠ 11 ∨ idx ≠ 9) → wRead m tbl idx = wRead mem₀ tbl idx) ∧
    (∀ tbl idx, tbl ≠ 3 → rRead m tbl idx = rRead mem₀ tbl idx)
  have hCopyZ₀ : CopyZInv 0 m2 := by
    refine ⟨hex2.trans hex1, (hw2_ne 0 0 (Or.inl (by decide))).trans hw1_00, hw2_9,
      fun _ hc => by omega, ?_, fun tbl idx _ => (hr2 tbl idx).trans (hr1 tbl idx)⟩
    intro tbl idx ht0 h11
    exact (hw2_ne tbl idx h11).trans (hw1_ne tbl idx (Or.inl ht0))
  rcases exec_repeatN (inp := inp) .dim copyZBody d 3 30 CopyZInv hs2.2.1 hCopyZ₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun c hc_lt m hcm ⟨hexm, hw00, hwc, hr3_prev, hwm_p, hrm_p⟩ => by
      let cF : Fin d := ⟨c, hc_lt⟩
      have heval_z : (evalRealExpr inp 0 m (.extraReal (.readHeap 11 (.lit 9)))).1 =
          euclideanCoord z cF :=
        evalRealExpr_extraReal_ofFn inp m z hinp_z (.readHeap 11 (.lit 9)) cF
          (by simp [cF, evalIntExpr, hwc])
      rcases exec_rSet_sr SW SR inp hcm 3 (.readHeap 11 (.lit 9)) (c : ℤ)
        (mem_scratchReals_3 (i := c) (by omega))
        (.extraReal (.readHeap 11 (.lit 9))) (euclideanCoord z cF) 15
        (by simp [evalIntExpr, hwc]) heval_z (by simp [evalRealExpr, evalIntExpr]) with
        ⟨ma1, hb1, hexa1, hra1_3, hwa1, hra1_ne⟩
      have hwc_a1 : wRead ma1 11 9 = (c : ℤ) := (hwa1 11 9).trans hwc
      rcases exec_wSet_sw SW SR inp hb1.2.1 11 (.lit 9) 9 (mem_scratchWords_11 (i := 9) (by omega))
        (.add (.readHeap 11 (.lit 9)) (.lit 1)) (((c + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, hwc_a1]) (by simp [evalIntExpr]) with
        ⟨ma2, hb2, hexa2, hwa2_9, hwa2_ne, hra2⟩
      have hstepZ : ExecStmt inp copyZBody m ma2 30 := by
        unfold copyZBody seqStmts
        exact (ExecStmt.seq hb1 hb2).mono_cost (by omega)
      refine ⟨ma2, hstepZ, hexa2.trans (hexa1.trans hexm),
        (hwa2_ne 0 0 (Or.inl (by decide))).trans ((hwa1 0 0).trans hw00),
        hwa2_9, ?_, ?_, ?_⟩
      · intro c' hc'
        rcases Nat.lt_succ_iff_lt_or_eq.mp hc' with hlt | heq
        · exact (hra2 3 _).trans ((hra1_ne 3 _ (Or.inr (by omega))).trans (hr3_prev c' hlt))
        · have hc'_eq : c' = cF := Fin.ext heq
          subst hc'_eq
          exact (hra2 3 _).trans hra1_3
      · intro tbl idx ht0 h11
        exact (hwa2_ne tbl idx h11).trans ((hwa1 tbl idx).trans (hwm_p tbl idx ht0 h11))
      · intro tbl idx ht3
        exact (hra2 tbl idx).trans ((hra1_ne tbl idx (Or.inl ht3)).trans (hrm_p tbl idx ht3))) with
    ⟨m3, ⟨hex3, hw00_3, _, hr3_all, hwm_3, hrm_3⟩, hrepZ⟩
  -- 4. (17, 6) := rRead 1 1 = x * t
  have hrxt_3 : rRead m3 1 1 = x * t := (hrm_3 1 1 (by decide)).trans hinv.r_xt
  rcases exec_rSet_sr SW SR inp hrepZ.2.1 17 (.lit 6) 6 (mem_scratchReals_17 (i := 6) (by omega))
    (.readRealHeap 1 (.lit 1)) (x * t) 8
    (by simp [evalIntExpr]) (by simp [evalRealExpr, evalIntExpr, hrxt_3])
    (by simp [evalRealExpr, evalIntExpr]) with
    ⟨m4, hs4, hex4, hr4_6, hw4, hr4_ne⟩
  -- 5. computeBaseListsStmt ℓ
  have hwM₀_4 : wRead m4 1 1 = (M₀ : ℤ) :=
    (hw4 1 1).trans ((hwm_3 1 1 (by decide) (Or.inl (by decide))).trans hinv.w_M₀)
  have hrω_4 : ∀ (g : Fin (ℓ * M₀)) (c : Fin d),
      rRead m4 2 ((g.1 * d + c.1 : ℕ) : ℤ) = euclideanCoord (ω g) c := fun g c =>
    (hr4_ne 2 _ (Or.inl (by decide))).trans ((hrm_3 2 _ (by decide)).trans (hinv.r_ω g c))
  have hrv_4 : ∀ c : Fin d, rRead m4 3 (c.1 : ℤ) = euclideanCoord z c := fun c =>
    (hr4_ne 3 _ (Or.inl (by decide))).trans (hr3_all c c.2)
  rcases exec_computeBaseListsStmt (Cap_q := Cap_q) inp hM₀ (x * t) ω z hs4.2.1
    hwM₀_4 hr4_6 hrω_4 hrv_4 with
    ⟨m5, hs5, hex5, hw5_15, hw5_5, hw5_6, hw5_pres, hr5_pres⟩

  let qProd := queryTupleCard x t ω z
  have hqProd_eq : (∏ j : Fin ℓ, (eligList (x * t) ω z j).length) = qProd :=
    prod_eligList_eq_queryTupleCard x t ω z
  rw [hqProd_eq] at hw5_15

  have hw00_5 : wRead m5 0 0 = 0 :=
    (hw5_pres 0 0 (by decide) (by decide) (Or.inl (by decide))).trans ((hw4 0 0).trans hw00_3)
  have hw_m5_hi : ∀ tbl idx, (tbl = 1 ∨ 20 ≤ tbl) → wRead m5 tbl idx = wRead mem₀ tbl idx := by
    intro tbl idx htbl
    have ht0 : tbl ≠ 0 := by omega
    have ht5 : tbl ≠ 5 := by omega
    have ht6 : tbl ≠ 6 := by omega
    have ht11 : tbl ≠ 11 := by omega
    exact (hw5_pres tbl idx ht5 ht6 (Or.inl ht11)).trans
      ((hw4 tbl idx).trans (hwm_3 tbl idx ht0 (Or.inl ht11)))
  have hwCapq_5 : wRead m5 1 4 = (Cap_q : ℤ) := (hw_m5_hi 1 4 (Or.inl rfl)).trans hinv.w_Capq
  have hwm_5 : wRead m5 1 0 = (m : ℤ) := (hw_m5_hi 1 0 (Or.inl rfl)).trans hinv.w_m
  have hwM₀_5 : wRead m5 1 1 = (M₀ : ℤ) := (hw_m5_hi 1 1 (Or.inl rfl)).trans hinv.w_M₀

  let innerEmitBody : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 28)
          (.readHeap 25
            (.add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
              (.readHeap 11 (.lit 26)))),
        .writeWordHeap 11 (.lit 29) (.add (.readHeap 0 (.lit 0)) (.lit 1)),
        .writeWordHeap 0 (.readHeap 11 (.lit 29)) (.readHeap 11 (.lit 28)),
        .writeWordHeap 0 (.lit 0) (.readHeap 11 (.lit 29)),
        .writeWordHeap 11 (.lit 26) (.add (.readHeap 11 (.lit 26)) (.lit 1)) ]
  let outerQBody : ArithRAMStmt :=
    seqStmts
      [ decodeTupleBucketStmt ℓ,
        .writeWordHeap 11 (.lit 23) (.readHeap 24 (.readHeap 11 (.lit 18))),
        .writeWordHeap 11 (.lit 24)
          (.sub (.add (.readHeap 1 (.lit 4)) (.lit 1)) (.readHeap 0 (.lit 0))),
        .ite (.intLe (.readHeap 11 (.lit 23)) (.readHeap 11 (.lit 24)))
          (.writeWordHeap 11 (.lit 25) (.readHeap 11 (.lit 23)))
          (.writeWordHeap 11 (.lit 25) (.readHeap 11 (.lit 24))),
        .writeWordHeap 11 (.lit 26) (.lit 0),
        .repeatN (.readHeap 11 (.lit 25)) innerEmitBody,
        .writeWordHeap 11 (.lit 16) (.add (.readHeap 11 (.lit 16)) (.lit 1)) ]
  let tBranchQ : ArithRAMStmt :=
    seqStmts
      [ .ite (.intLe (.readHeap 11 (.lit 15)) (.readHeap 1 (.lit 4)))
          (.writeWordHeap 11 (.lit 27) (.readHeap 11 (.lit 15)))
          (.writeWordHeap 11 (.lit 27) (.readHeap 1 (.lit 4))),
        .writeWordHeap 11 (.lit 16) (.lit 0),
        .repeatN (.readHeap 11 (.lit 27)) outerQBody ]

  by_cases hq_pos : 1 ≤ qProd
  · -- True branch: 1 ≤ qProd
    have hcond_pos : (evalArithCond inp 0 m5 (.intLe (.lit 1) (.readHeap 11 (.lit 15)))).1 = true := by
      simp only [evalArithCond, evalIntExpr, words_read_heap, hw5_15, decide_eq_true_eq]
      exact_mod_cast hq_pos
    let Q : ℕ := min qProd Cap_q
    -- Set (11, 27) := Q
    have hmin_step :
        ∃ m6 : ArithRAMMemory,
          ExecStmt inp
            (.ite (.intLe (.readHeap 11 (.lit 15)) (.readHeap 1 (.lit 4)))
              (.writeWordHeap 11 (.lit 27) (.readHeap 11 (.lit 15)))
              (.writeWordHeap 11 (.lit 27) (.readHeap 1 (.lit 4))))
            m5 m6 18 ∧
          extraCells SW SR m6 = extraCells SW SR m5 ∧
          wRead m6 11 27 = (Q : ℤ) ∧
          (∀ tbl idx, (tbl ≠ 11 ∨ idx ≠ 27) → wRead m6 tbl idx = wRead m5 tbl idx) ∧
          (∀ tbl idx, rRead m6 tbl idx = rRead m5 tbl idx) := by
      by_cases hle : qProd ≤ Cap_q
      · have hQ : Q = qProd := Nat.min_eq_left hle
        rcases exec_wSet_sw SW SR inp hs5.2.1 11 (.lit 27) 27 (mem_scratchWords_11 (i := 27) (by omega))
          (.readHeap 11 (.lit 15)) (Q : ℤ) 8
          (by simp [evalIntExpr]) (by simp [evalIntExpr, hw5_15, hQ]) (by simp [evalIntExpr]) with
          ⟨m6, hs6, hex6, hw6_27, hw6_ne, hr6⟩
        have hc_le : (evalArithCond inp 0 m5 (.intLe (.readHeap 11 (.lit 15)) (.readHeap 1 (.lit 4)))).1 = true := by
          simp only [evalArithCond, evalIntExpr, words_read_heap, hw5_15, hwCapq_5, decide_eq_true_eq]
          exact_mod_cast hle
        exact ⟨m6, exec_ite_true hc_le hs6 (by simp [evalArithCond, evalIntExpr]),
          hex6, hw6_27, hw6_ne, hr6⟩
      · have hQ : Q = Cap_q := Nat.min_eq_right (by omega)
        rcases exec_wSet_sw SW SR inp hs5.2.1 11 (.lit 27) 27 (mem_scratchWords_11 (i := 27) (by omega))
          (.readHeap 1 (.lit 4)) (Q : ℤ) 8
          (by simp [evalIntExpr]) (by simp [evalIntExpr, hwCapq_5, hQ]) (by simp [evalIntExpr]) with
          ⟨m6, hs6, hex6, hw6_27, hw6_ne, hr6⟩
        have hc_gt : (evalArithCond inp 0 m5 (.intLe (.readHeap 11 (.lit 15)) (.readHeap 1 (.lit 4)))).1 = false := by
          simp only [evalArithCond, evalIntExpr, words_read_heap, hw5_15, hwCapq_5, decide_eq_false_iff_not]
          exact_mod_cast hle
        exact ⟨m6, exec_ite_false hc_gt hs6 (by simp [evalArithCond, evalIntExpr]),
          hex6, hw6_27, hw6_ne, hr6⟩
    rcases hmin_step with ⟨m6, hs6, hex6, hw6_27, hw6_ne, hr6⟩
    -- (11, 16) := 0
    rcases exec_wSet_sw SW SR inp hs6.2.1 11 (.lit 16) 16 (mem_scratchWords_11 (i := 16) (by omega))
      (.lit 0) 0 4
      (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
      ⟨m7, hs7, hex7, hw7_16, hw7_ne, hr7⟩

    let Pairs := activePairs Cap_u t ω ptsK Act
    let bOf : ℕ → ℕ := fun qIdx => hornerTuple (tupleOfIdx hM₀ (x * t) ω z qIdx)
    let lenOf : ℕ → ℕ := fun qIdx =>
      (Pairs.filter (fun p => bktKey hM₀ t ω ptsK p.1 p.2 = bOf qIdx)).card
    let rCount : ℕ → ℕ := qStepCount Cap_q lenOf

    have hprod_q_pos : 1 ≤ ∏ j : Fin ℓ, (eligList (x * t) ω z j).length := by
      rw [hqProd_eq]; exact hq_pos

    let OuterQInv : ℕ → ArithRAMMemory → Prop := fun qIdx mQ =>
      extraCells SW SR mQ = extraCells SW SR mem₀ ∧
      wRead mQ 0 0 = ((rCount qIdx : ℕ) : ℤ) ∧
      wRead mQ 11 16 = (qIdx : ℤ) ∧
      (∀ tbl idx, tbl ≠ 0 → tbl ≠ 11 → wRead mQ tbl idx = wRead m5 tbl idx) ∧
      (∃ pairs : Fin (rCount qIdx) → Fin m × (Fin ℓ → Fin M₀),
        Function.Injective pairs ∧
        ∀ u : Fin (rCount qIdx),
          (pairs u).1 ∈ Act ∧
          IsSharedTuple x t ω (ptsK (pairs u).1) z (pairs u).2 ∧
          (∃ q₀ < qIdx, (pairs u).2 = tupleOfIdx hM₀ (x * t) ω z q₀) ∧
          wRead mQ 0 ((u.1 + 1 : ℕ) : ℤ) = ((pairs u).1.1 : ℤ)) ∧
      (∀ (q₀ : ℕ), q₀ < qIdx → rCount (q₀ + 1) ≤ Cap_q →
        ∀ (k : Fin m), k ∈ Act → 1 ≤ dataTupleCard t ω (ptsK k) →
          dataTupleCard t ω (ptsK k) ≤ Cap_u →
          IsDataTuple t ω (ptsK k) (tupleOfIdx hM₀ (x * t) ω z q₀) →
          ∃ idx < rCount qIdx, wRead mQ 0 ((idx + 1 : ℕ) : ℤ) = (k.1 : ℤ))

    have hOuterQ₀ : OuterQInv 0 m7 := by
      have hex_m7 : extraCells SW SR m7 = extraCells SW SR mem₀ :=
        hex7.trans (hex6.trans (hex5.trans (hex4.trans hex3)))
      have hw00_7 : wRead m7 0 0 = 0 :=
        (hw7_ne 0 0 (Or.inl (by decide))).trans ((hw6_ne 0 0 (Or.inl (by decide))).trans hw00_5)
      refine ⟨hex_m7, by simpa [rCount, qStepCount] using hw00_7, hw7_16,
        fun tbl idx _ ht11 =>
          (hw7_ne tbl idx (Or.inl ht11)).trans (hw6_ne tbl idx (Or.inl ht11)),
        ⟨fun u => Fin.elim0 (by simpa [rCount, qStepCount] using u),
          fun u => Fin.elim0 (by simpa [rCount, qStepCount] using u),
          fun u => Fin.elim0 (by simpa [rCount, qStepCount] using u)⟩,
        fun _ hq₀ => by omega⟩

    have hwQ_7 : wRead m7 11 27 = (Q : ℤ) := (hw7_ne 11 27 (Or.inr (by decide))).trans hw6_27

    rcases ExecStmt.repeatN_telescope (inp := inp) (.readHeap 11 (.lit 27)) outerQBody
      Q 4 (80 + ℓ * 60) 45 rCount (fun i _ => qStepCount_mono Cap_q lenOf i)
      OuterQInv hs7.2.1 hOuterQ₀
      (by simp [evalIntExpr, hwQ_7]) (by simp [evalIntExpr])
      (fun qIdx hqIdx_lt mQ hcmQ ⟨hexQ, hw00_Q, hw16_Q, hwmQ_pres, hpairs_prev, hcomp_prev⟩ => by
        have hqIdx_prod : qIdx < qProd := lt_of_lt_of_le hqIdx_lt (Nat.min_le_left _ _)
        let τ_q := tupleOfIdx hM₀ (x * t) ω z qIdx
        let b := bOf qIdx
        let len_b := lenOf qIdx
        let r₀ := rCount qIdx
        have hr₀_le : r₀ ≤ Cap_q + 1 := qStepCount_le_cap Cap_q lenOf qIdx
        let remCap : ℕ := Cap_q + 1 - r₀
        let L_emit : ℕ := min len_b remCap
        have hL_diff : L_emit = rCount (qIdx + 1) - r₀ := qStepCount_diff Cap_q lenOf qIdx
        have hr_next_eq : r₀ + L_emit = rCount (qIdx + 1) := by
          have hm : r₀ ≤ rCount (qIdx + 1) := qStepCount_mono Cap_q lenOf qIdx
          omega

        -- Read helpers from mQ -> m5 -> mem₀
        have hwM₀_Q : wRead mQ 1 1 = (M₀ : ℤ) :=
          (hwmQ_pres 1 1 (by decide) (by decide)).trans hwM₀_5
        have hwm_Q : wRead mQ 1 0 = (m : ℤ) :=
          (hwmQ_pres 1 0 (by decide) (by decide)).trans hwm_5
        have hwCapq_Q : wRead mQ 1 4 = (Cap_q : ℤ) :=
          (hwmQ_pres 1 4 (by decide) (by decide)).trans hwCapq_5
        have hw5_Q : ∀ j : Fin ℓ, wRead mQ 5 (j.1 : ℤ) = ((eligList (x * t) ω z j).length : ℤ) :=
          fun j => (hwmQ_pres 5 _ (by decide) (by decide)).trans (hw5_5 j)
        have hw6_Q : ∀ j : Fin ℓ, ∀ (pos : ℕ) (hpos : pos < (eligList (x * t) ω z j).length),
            wRead mQ 6 ((j.1 * M₀ + pos : ℕ) : ℤ) = (((eligList (x * t) ω z j)[pos]).1 : ℤ) :=
          fun j pos hpos => (hwmQ_pres 6 _ (by decide) (by decide)).trans (hw5_6 j pos hpos)

        -- 1. decodeTupleBucketStmt ℓ -> b in (11, 18)
        rcases exec_decodeTupleBucketStmt (Cap_q := Cap_q) inp hM₀ (x * t) ω z hprod_q_pos qIdx
          hcmQ hwM₀_Q hw5_Q hw6_Q hw16_Q with
          ⟨md1, hd1, hexd1, hwd1_18, hwd1_pres, _⟩
        -- 2. (11, 23) := 24[b] = len_b
        have hw24_md1 : wRead md1 24 (b : ℤ) = (len_b : ℤ) :=
          (hwd1_pres 24 _ (Or.inl (by decide))).trans
            ((hwmQ_pres 24 _ (by decide) (by decide)).trans
              ((hw_m5_hi 24 _ (Or.inr (by decide))).trans (hinv.buckets.bkt_len b)))
        rcases exec_wSet_sw SW SR inp hd1.2.1 11 (.lit 23) 23 (mem_scratchWords_11 (i := 23) (by omega))
          (.readHeap 24 (.readHeap 11 (.lit 18))) (len_b : ℤ) 10
          (by simp [evalIntExpr])
          (by simp only [evalIntExpr, words_read_heap, hwd1_18]; exact hw24_md1)
          (by simp [evalIntExpr]) with
          ⟨md2, hd2, hexd2, hwd2_23, hwd2_ne, _⟩
        -- 3. (11, 24) := Cap_q + 1 - r₀ = remCap
        have hwCapq_md2 : wRead md2 1 4 = (Cap_q : ℤ) :=
          (hwd2_ne 1 4 (Or.inl (by decide))).trans ((hwd1_pres 1 4 (Or.inl (by decide))).trans hwCapq_Q)
        have hw00_md2 : wRead md2 0 0 = (r₀ : ℤ) :=
          (hwd2_ne 0 0 (Or.inl (by decide))).trans ((hwd1_pres 0 0 (Or.inl (by decide))).trans hw00_Q)
        have hrem_cast : ((Cap_q : ℤ) + 1) - (r₀ : ℤ) = (remCap : ℤ) := by
          dsimp [remCap]; omega
        rcases exec_wSet_sw SW SR inp hd2.2.1 11 (.lit 24) 24 (mem_scratchWords_11 (i := 24) (by omega))
          (.sub (.add (.readHeap 1 (.lit 4)) (.lit 1)) (.readHeap 0 (.lit 0))) (remCap : ℤ) 14
          (by simp [evalIntExpr])
          (by simp only [evalIntExpr, words_read_heap, hwCapq_md2, hw00_md2]; exact hrem_cast)
          (by simp [evalIntExpr]) with
          ⟨md3, hd3, hexd3, hwd3_24, hwd3_ne, _⟩
        -- 4. (11, 25) := min len_b remCap = L_emit
        have hw23_md3 : wRead md3 11 23 = (len_b : ℤ) :=
          (hwd3_ne 11 23 (Or.inr (by decide))).trans hwd2_23
        have hminL :
            ∃ md4 : ArithRAMMemory,
              ExecStmt inp
                (.ite (.intLe (.readHeap 11 (.lit 23)) (.readHeap 11 (.lit 24)))
                  (.writeWordHeap 11 (.lit 25) (.readHeap 11 (.lit 23)))
                  (.writeWordHeap 11 (.lit 25) (.readHeap 11 (.lit 24))))
                md3 md4 18 ∧
              extraCells SW SR md4 = extraCells SW SR md3 ∧
              wRead md4 11 25 = (L_emit : ℤ) ∧
              (∀ tbl idx, (tbl ≠ 11 ∨ idx ≠ 25) → wRead md4 tbl idx = wRead md3 tbl idx) := by
          by_cases hleL : len_b ≤ remCap
          · have hL : L_emit = len_b := Nat.min_eq_left hleL
            rcases exec_wSet_sw SW SR inp hd3.2.1 11 (.lit 25) 25 (mem_scratchWords_11 (i := 25) (by omega))
              (.readHeap 11 (.lit 23)) (L_emit : ℤ) 8
              (by simp [evalIntExpr]) (by simp [evalIntExpr, hw23_md3, hL]) (by simp [evalIntExpr]) with
              ⟨md4, hs_m, hex_m, hw_m25, hw_mne, _⟩
            have hc_t : (evalArithCond inp 0 md3 (.intLe (.readHeap 11 (.lit 23)) (.readHeap 11 (.lit 24)))).1 = true := by
              simp only [evalArithCond, evalIntExpr, words_read_heap, hw23_md3, hwd3_24, decide_eq_true_eq]
              exact_mod_cast hleL
            exact ⟨md4, exec_ite_true hc_t hs_m (by simp [evalArithCond, evalIntExpr]),
              hex_m, hw_m25, hw_mne⟩
          · have hL : L_emit = remCap := Nat.min_eq_right (by omega)
            rcases exec_wSet_sw SW SR inp hd3.2.1 11 (.lit 25) 25 (mem_scratchWords_11 (i := 25) (by omega))
              (.readHeap 11 (.lit 24)) (L_emit : ℤ) 8
              (by simp [evalIntExpr]) (by simp [evalIntExpr, hwd3_24, hL]) (by simp [evalIntExpr]) with
              ⟨md4, hs_m, hex_m, hw_m25, hw_mne, _⟩
            have hc_f : (evalArithCond inp 0 md3 (.intLe (.readHeap 11 (.lit 23)) (.readHeap 11 (.lit 24)))).1 = false := by
              simp only [evalArithCond, evalIntExpr, words_read_heap, hw23_md3, hwd3_24, decide_eq_false_iff_not]
              exact_mod_cast hleL
            exact ⟨md4, exec_ite_false hc_f hs_m (by simp [evalArithCond, evalIntExpr]),
              hex_m, hw_m25, hw_mne⟩
        rcases hminL with ⟨md4, hd4, hexd4, hwd4_25, hwd4_ne⟩
        -- 5. (11, 26) := 0
        rcases exec_wSet_sw SW SR inp hd4.2.1 11 (.lit 26) 26 (mem_scratchWords_11 (i := 26) (by omega))
          (.lit 0) 0 4
          (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
          ⟨md5, hd5, hexd5, hwd5_26, hwd5_ne, _⟩

        have hw_md5_from_mQ : ∀ tbl idx, tbl ≠ 11 → wRead md5 tbl idx = wRead mQ tbl idx :=
          fun tbl idx ht11 =>
            (hwd5_ne tbl idx (Or.inl ht11)).trans
              ((hwd4_ne tbl idx (Or.inl ht11)).trans
                ((hwd3_ne tbl idx (Or.inl ht11)).trans
                  ((hwd2_ne tbl idx (Or.inl ht11)).trans
                    (hwd1_pres tbl idx (Or.inl ht11)))))
        have hwb_md5 : wRead md5 11 18 = (b : ℤ) :=
          (hwd5_ne 11 18 (Or.inr (by decide))).trans
            ((hwd4_ne 11 18 (Or.inr (by decide))).trans
              ((hwd3_ne 11 18 (Or.inr (by decide))).trans
                ((hwd2_ne 11 18 (Or.inr (by decide))).trans hwd1_18)))
        have hw16_md5 : wRead md5 11 16 = (qIdx : ℤ) :=
          (hwd5_ne 11 16 (Or.inr (by decide))).trans
            ((hwd4_ne 11 16 (Or.inr (by decide))).trans
              ((hwd3_ne 11 16 (Or.inr (by decide))).trans
                ((hwd2_ne 11 16 (Or.inr (by decide))).trans
                  ((hwd1_pres 11 16 (Or.inr (Or.inl (by decide)))).trans hw16_Q))))
        have hwL_md5 : wRead md5 11 25 = (L_emit : ℤ) :=
          (hwd5_ne 11 25 (Or.inr (by decide))).trans hwd4_25

        -- 6. Inner emit loop (L_emit iterations)
        let InnerQInv : ℕ → ArithRAMMemory → Prop := fun pos mI =>
          extraCells SW SR mI = extraCells SW SR mem₀ ∧
          wRead mI 0 0 = ((r₀ + pos : ℕ) : ℤ) ∧
          wRead mI 11 26 = (pos : ℤ) ∧
          (∀ idx < r₀, wRead mI 0 ((idx + 1 : ℕ) : ℤ) = wRead mQ 0 ((idx + 1 : ℕ) : ℤ)) ∧
          (∀ p' < pos, wRead mI 0 ((r₀ + p' + 1 : ℕ) : ℤ) =
            wRead mem₀ 25 ((b * (m + 1) + p' : ℕ) : ℤ)) ∧
          (∀ tbl idx, tbl ≠ 0 → (tbl ≠ 11 ∨ (idx ≠ 26 ∧ idx ≠ 28 ∧ idx ≠ 29)) →
            wRead mI tbl idx = wRead md5 tbl idx)
        have hInnerQ₀ : InnerQInv 0 md5 := by
          refine ⟨hexd5.trans (hexd4.trans (hexd3.trans (hexd2.trans (hexd1.trans hexQ)))),
            by simpa using (hw_md5_from_mQ 0 0 (by decide)).trans hw00_Q,
            hwd5_26,
            fun idx _ => hw_md5_from_mQ 0 _ (by decide),
            fun _ hp => by omega,
            fun _ _ _ _ => rfl⟩

        rcases exec_repeatN (inp := inp) (.readHeap 11 (.lit 25)) innerEmitBody L_emit 4 45
          InnerQInv hd5.2.1 hInnerQ₀
          (by simp [evalIntExpr, hwL_md5]) (by simp [evalIntExpr])
          (fun pos hpos_lt mI hcmI ⟨hexI, hw00_I, hwpos_I, hw0_old, hw0_new, hwmI_pres⟩ => by
            have hwb_I : wRead mI 11 18 = (b : ℤ) :=
              (hwmI_pres 11 18 (by decide) (Or.inr ⟨by decide, by decide, by decide⟩)).trans hwb_md5
            have hwm_I : wRead mI 1 0 = (m : ℤ) :=
              (hwmI_pres 1 0 (by decide) (Or.inl (by decide))).trans
                ((hw_md5_from_mQ 1 0 (by decide)).trans hwm_Q)
            have hw25_I : wRead mI 25 ((b * (m + 1) + pos : ℕ) : ℤ) =
                wRead mem₀ 25 ((b * (m + 1) + pos : ℕ) : ℤ) :=
              (hwmI_pres 25 _ (by decide) (Or.inl (by decide))).trans
                ((hw_md5_from_mQ 25 _ (by decide)).trans
                  ((hwmQ_pres 25 _ (by decide) (by decide)).trans
                    (hw_m5_hi 25 _ (Or.inr (by decide)))))
            have hb_cast : (b : ℤ) * ((m : ℤ) + 1) + (pos : ℤ) = ((b * (m + 1) + pos : ℕ) : ℤ) := by
              simp only [Nat.cast_add, Nat.cast_mul, Nat.cast_one]
            -- i1: (11, 28) := 25[b * (m + 1) + pos]
            rcases exec_wSet_sw SW SR inp hcmI 11 (.lit 28) 28 (mem_scratchWords_11 (i := 28) (by omega))
              (.readHeap 25 (.add (.mul (.readHeap 11 (.lit 18)) (.add (.readHeap 1 (.lit 0)) (.lit 1)))
                (.readHeap 11 (.lit 26))))
              (wRead mem₀ 25 ((b * (m + 1) + pos : ℕ) : ℤ)) 18
              (by simp [evalIntExpr])
              (by simp only [evalIntExpr, words_read_heap, hwb_I, hwm_I, hwpos_I, hb_cast]; exact hw25_I)
              (by simp [evalIntExpr]) with
              ⟨mi1, hi1, hexi1, hwi1_28, hwi1_ne, _⟩
            -- i2: (11, 29) := 0[0] + 1 = r₀ + pos + 1
            have hw00_i1 : wRead mi1 0 0 = ((r₀ + pos : ℕ) : ℤ) :=
              (hwi1_ne 0 0 (Or.inl (by decide))).trans hw00_I
            rcases exec_wSet_sw SW SR inp hi1.2.1 11 (.lit 29) 29 (mem_scratchWords_11 (i := 29) (by omega))
              (.add (.readHeap 0 (.lit 0)) (.lit 1)) (((r₀ + pos + 1 : ℕ) : ℤ)) 8
              (by simp [evalIntExpr]) (by simp [evalIntExpr, hw00_i1]) (by simp [evalIntExpr]) with
              ⟨mi2, hi2, hexi2, hwi2_29, hwi2_ne, _⟩
            -- i3: 0[r₀ + pos + 1] := (11, 28)
            have hw28_i2 : wRead mi2 11 28 = wRead mem₀ 25 ((b * (m + 1) + pos : ℕ) : ℤ) :=
              (hwi2_ne 11 28 (Or.inr (by decide))).trans hwi1_28
            have hr_slot_lt : r₀ + pos + 1 < Cap_q + 3 := by
              have hle_cap : rCount (qIdx + 1) ≤ Cap_q + 1 := qStepCount_le_cap Cap_q lenOf (qIdx + 1)
              omega
            rcases exec_wSet_sw SW SR inp hi2.2.1 0 (.readHeap 11 (.lit 29))
              (((r₀ + pos + 1 : ℕ) : ℤ)) (mem_scratchWords_0 hr_slot_lt)
              (.readHeap 11 (.lit 28)) (wRead mem₀ 25 ((b * (m + 1) + pos : ℕ) : ℤ)) 6
              (by simp [evalIntExpr, hwi2_29]) (by simp [evalIntExpr, hw28_i2]) (by simp [evalIntExpr]) with
              ⟨mi3, hi3, hexi3, hwi3_slot, hwi3_ne, _⟩
            -- i4: 0[0] := r₀ + pos + 1
            have hw29_i3 : wRead mi3 11 29 = ((r₀ + pos + 1 : ℕ) : ℤ) :=
              (hwi3_ne 11 29 (Or.inl (by decide))).trans hwi2_29
            rcases exec_wSet_sw SW SR inp hi3.2.1 0 (.lit 0) 0 (mem_scratchWords_0 (i := 0) (by omega))
              (.readHeap 11 (.lit 29)) (((r₀ + pos + 1 : ℕ) : ℤ)) 6
              (by simp [evalIntExpr]) (by simp [evalIntExpr, hw29_i3]) (by simp [evalIntExpr]) with
              ⟨mi4, hi4, hexi4, hwi4_00, hwi4_ne, _⟩
            -- i5: (11, 26) := pos + 1
            have hw26_i4 : wRead mi4 11 26 = (pos : ℤ) :=
              (hwi4_ne 11 26 (Or.inl (by decide))).trans
                ((hwi3_ne 11 26 (Or.inl (by decide))).trans
                  ((hwi2_ne 11 26 (Or.inr (by decide))).trans
                    ((hwi1_ne 11 26 (Or.inr (by decide))).trans hwpos_I)))
            rcases exec_wSet_sw SW SR inp hi4.2.1 11 (.lit 26) 26 (mem_scratchWords_11 (i := 26) (by omega))
              (.add (.readHeap 11 (.lit 26)) (.lit 1)) (((pos + 1 : ℕ) : ℤ)) 6
              (by simp [evalIntExpr]) (by simp [evalIntExpr, hw26_i4]) (by simp [evalIntExpr]) with
              ⟨mi5, hi5, hexi5, hwi5_26, hwi5_ne, _⟩

            have hstepI : ExecStmt inp innerEmitBody mI mi5 45 := by
              unfold innerEmitBody seqStmts
              exact (ExecStmt.seq hi1 (ExecStmt.seq hi2 (ExecStmt.seq hi3
                (ExecStmt.seq hi4 hi5)))).mono_cost (by omega)
            refine ⟨mi5, hstepI,
              hexi5.trans (hexi4.trans (hexi3.trans (hexi2.trans (hexi1.trans hexI)))),
              by simpa [Nat.add_assoc] using (hwi5_ne 0 0 (Or.inl (by decide))).trans hwi4_00,
              hwi5_26, ?_, ?_, ?_⟩
            · intro idx hidx
              have hne_slot : ((idx + 1 : ℕ) : ℤ) ≠ ((r₀ + pos + 1 : ℕ) : ℤ) := by omega
              have hne_0 : ((idx + 1 : ℕ) : ℤ) ≠ 0 := by omega
              exact (hwi5_ne 0 _ (Or.inl (by decide))).trans
                ((hwi4_ne 0 _ (Or.inr hne_0)).trans
                  ((hwi3_ne 0 _ (Or.inr hne_slot)).trans
                    ((hwi2_ne 0 _ (Or.inl (by decide))).trans
                      ((hwi1_ne 0 _ (Or.inl (by decide))).trans (hw0_old idx hidx)))))
            · intro p' hp'
              have hne_0 : ((r₀ + p' + 1 : ℕ) : ℤ) ≠ 0 := by omega
              rcases Nat.lt_succ_iff_lt_or_eq.mp hp' with hlt | rfl
              · have hne_slot : ((r₀ + p' + 1 : ℕ) : ℤ) ≠ ((r₀ + pos + 1 : ℕ) : ℤ) := by omega
                exact (hwi5_ne 0 _ (Or.inl (by decide))).trans
                  ((hwi4_ne 0 _ (Or.inr hne_0)).trans
                    ((hwi3_ne 0 _ (Or.inr hne_slot)).trans
                      ((hwi2_ne 0 _ (Or.inl (by decide))).trans
                        ((hwi1_ne 0 _ (Or.inl (by decide))).trans (hw0_new p' hlt)))))
              · exact (hwi5_ne 0 _ (Or.inl (by decide))).trans
                  ((hwi4_ne 0 _ (Or.inr hne_0)).trans hwi3_slot)
            · intro tbl idx ht0 h11
              have h26 : tbl ≠ 11 ∨ idx ≠ 26 := by
                rcases h11 with h | h; exact Or.inl h; exact Or.inr h.1
              have h28 : tbl ≠ 11 ∨ idx ≠ 28 := by
                rcases h11 with h | h; exact Or.inl h; exact Or.inr h.2.1
              have h29 : tbl ≠ 11 ∨ idx ≠ 29 := by
                rcases h11 with h | h; exact Or.inl h; exact Or.inr h.2.2
              exact (hwi5_ne tbl idx h26).trans
                ((hwi4_ne tbl idx (Or.inl ht0)).trans
                  ((hwi3_ne tbl idx (Or.inl ht0)).trans
                    ((hwi2_ne tbl idx h29).trans
                      ((hwi1_ne tbl idx h28).trans (hwmI_pres tbl idx ht0 h11)))))) with
          ⟨md6, ⟨hexd6, hw00_d6, _, hw0_old_d6, hw0_new_d6, hwm_d6⟩, hrepI⟩

        -- 7. (11, 16) := qIdx + 1
        have hw16_d6 : wRead md6 11 16 = (qIdx : ℤ) :=
          (hwm_d6 11 16 (by decide) (Or.inr ⟨by decide, by decide, by decide⟩)).trans hw16_md5
        rcases exec_wSet_sw SW SR inp hrepI.2.1 11 (.lit 16) 16 (mem_scratchWords_11 (i := 16) (by omega))
          (.add (.readHeap 11 (.lit 16)) (.lit 1)) (((qIdx + 1 : ℕ) : ℤ)) 8
          (by simp [evalIntExpr]) (by simp [evalIntExpr, hw16_d6]) (by simp [evalIntExpr]) with
          ⟨md7, hd7, hexd7, hwd7_16, hwd7_ne, _⟩

        have hstepO : ExecStmt inp outerQBody mQ md7
            ((80 + ℓ * 60) + 45 * (rCount (qIdx + 1) - r₀)) := by
          unfold outerQBody seqStmts
          rw [← hL_diff]
          exact (ExecStmt.seq hd1 (ExecStmt.seq hd2 (ExecStmt.seq hd3 (ExecStmt.seq hd4
            (ExecStmt.seq hd5 (ExecStmt.seq hrepI hd7)))))).mono_cost (by omega)

        have hw0_d7 : ∀ idx, wRead md7 0 idx = wRead md6 0 idx :=
          fun idx => hwd7_ne 0 idx (Or.inl (by decide))

        -- Extend `pairs` from `r₀` to `rCount (qIdx + 1) = r₀ + L_emit`
        rcases hpairs_prev with ⟨pairs₀, hinj₀, hpairs₀_spec⟩
        have hL_le_len : L_emit ≤ len_b := Nat.min_le_left _ _
        have hbwd_wit : ∀ p' : Fin L_emit,
            ∃ (k' : Fin m) (s' : ℕ),
              (k', s') ∈ Pairs ∧ bktKey hM₀ t ω ptsK k' s' = b ∧
              wRead mem₀ 25 ((b * (m + 1) + p'.1 : ℕ) : ℤ) = (k'.1 : ℤ) ∧
              wRead mem₀ 26 ((b * (m + 1) + p'.1 : ℕ) : ℤ) = (s' : ℤ) ∧
              wRead mem₀ 23 ((k'.1 * (Cap_u + 1) + s' : ℕ) : ℤ) = (p'.1 : ℤ) :=
          fun p' => hinv.buckets.bwd b p'.1 (lt_of_lt_of_le p'.2 hL_le_len)
        let kNew : Fin L_emit → Fin m := fun p' => Classical.choose (hbwd_wit p')
        let sNew : Fin L_emit → ℕ := fun p' =>
          Classical.choose (Classical.choose_spec (hbwd_wit p'))
        have hkNew_spec : ∀ p' : Fin L_emit,
            (kNew p', sNew p') ∈ Pairs ∧
            bktKey hM₀ t ω ptsK (kNew p') (sNew p') = b ∧
            wRead mem₀ 25 ((b * (m + 1) + p'.1 : ℕ) : ℤ) = ((kNew p').1 : ℤ) ∧
            wRead mem₀ 26 ((b * (m + 1) + p'.1 : ℕ) : ℤ) = ((sNew p' : ℕ) : ℤ) ∧
            wRead mem₀ 23 (((kNew p').1 * (Cap_u + 1) + sNew p' : ℕ) : ℤ) = (p'.1 : ℤ) :=
          fun p' => Classical.choose_spec (Classical.choose_spec (hbwd_wit p'))

        have hτ_query : IsQueryTuple x t ω z τ_q := tupleOfIdx_isQueryTuple hM₀ hq_pos qIdx

        let pairs₁ : Fin (rCount (qIdx + 1)) → Fin m × (Fin ℓ → Fin M₀) := fun u =>
          if hu : u.1 < r₀ then
            pairs₀ ⟨u.1, hu⟩
          else
            (kNew ⟨u.1 - r₀, by omega⟩, τ_q)

        have hinj₁ : Function.Injective pairs₁ := by
          intro u₁ u₂ heq
          by_cases h₁ : u₁.1 < r₀
          · by_cases h₂ : u₂.1 < r₀
            · simp only [pairs₁, h₁, h₂, ↓reduceDIte] at heq
              have hfin := hinj₀ heq
              exact Fin.ext (Fin.mk.inj hfin)
            · simp only [pairs₁, h₁, h₂, ↓reduceDIte] at heq
              rcases (hpairs₀_spec ⟨u₁.1, h₁⟩).2.2.1 with ⟨q₀, hq₀_lt, hτ₀⟩
              have hτ_eq : tupleOfIdx hM₀ (x * t) ω z q₀ = τ_q := hτ₀.symm.trans (congrArg Prod.snd heq)
              have hq₀_prod : q₀ < ∏ j : Fin ℓ, (eligList (x * t) ω z j).length := by
                rw [hqProd_eq]; omega
              have hqI_prod : qIdx < ∏ j : Fin ℓ, (eligList (x * t) ω z j).length := by
                rw [hqProd_eq]; exact hqIdx_prod
              have hq_eq := tupleOfIdx_injective hM₀ hq₀_prod hqI_prod hτ_eq
              omega
          · by_cases h₂ : u₂.1 < r₀
            · simp only [pairs₁, h₁, h₂, ↓reduceDIte] at heq
              rcases (hpairs₀_spec ⟨u₂.1, h₂⟩).2.2.1 with ⟨q₀, hq₀_lt, hτ₀⟩
              have hτ_eq : τ_q = tupleOfIdx hM₀ (x * t) ω z q₀ := (congrArg Prod.snd heq).trans hτ₀
              have hq₀_prod : q₀ < ∏ j : Fin ℓ, (eligList (x * t) ω z j).length := by
                rw [hqProd_eq]; omega
              have hqI_prod : qIdx < ∏ j : Fin ℓ, (eligList (x * t) ω z j).length := by
                rw [hqProd_eq]; exact hqIdx_prod
              have hq_eq := tupleOfIdx_injective hM₀ hqI_prod hq₀_prod hτ_eq
              omega
            · simp only [pairs₁, h₁, h₂, ↓reduceDIte, Prod.mk.injEq] at heq
              let p₁ : Fin L_emit := ⟨u₁.1 - r₀, by omega⟩
              let p₂ : Fin L_emit := ⟨u₂.1 - r₀, by omega⟩
              have hk_eq : kNew p₁ = kNew p₂ := heq.1
              rcases hkNew_spec p₁ with ⟨hm₁, hb₁, _, _, h23_₁⟩
              rcases hkNew_spec p₂ with ⟨hm₂, hb₂, _, _, h23_₂⟩
              rw [hk_eq] at hm₁ hb₁ h23_₁
              have hs_eq : sNew p₁ = sNew p₂ :=
                bktKey_inj hM₀ t ω ptsK (mem_activePairs_iff.mp hm₁).2.2.2
                  (mem_activePairs_iff.mp hm₂).2.2.2 (hb₁.trans hb₂.symm)
              rw [hs_eq] at h23_₁
              have hp_eq : p₁.1 = p₂.1 := Int.ofNat.inj (h23_₁.symm.trans h23_₂)
              dsimp [p₁, p₂] at hp_eq
              exact Fin.ext (by omega)

        have hpairs₁_spec : ∀ u : Fin (rCount (qIdx + 1)),
            (pairs₁ u).1 ∈ Act ∧
            IsSharedTuple x t ω (ptsK (pairs₁ u).1) z (pairs₁ u).2 ∧
            (∃ q₀ < qIdx + 1, (pairs₁ u).2 = tupleOfIdx hM₀ (x * t) ω z q₀) ∧
            wRead md7 0 ((u.1 + 1 : ℕ) : ℤ) = ((pairs₁ u).1.1 : ℤ) := by
          intro u
          by_cases hu : u.1 < r₀
          · simp only [pairs₁, hu, ↓reduceDIte]
            rcases hpairs₀_spec ⟨u.1, hu⟩ with ⟨hAct, hSh, ⟨q₀, hq₀, hτ₀⟩, hw0⟩
            refine ⟨hAct, hSh, ⟨q₀, by omega, hτ₀⟩, ?_⟩
            exact (hw0_d7 _).trans ((hw0_old_d6 u.1 hu).trans hw0)
          · simp only [pairs₁, hu, ↓reduceDIte]
            let p' : Fin L_emit := ⟨u.1 - r₀, by omega⟩
            rcases hkNew_spec p' with ⟨hm_p, hb_p, h25_p, _, _⟩
            rcases mem_activePairs_iff.mp hm_p with ⟨hk_Act, hk_d1, _, _⟩
            have hτ_eq : tupleOfIdx hM₀ t ω (ptsK (kNew p')) (sNew p') = τ_q :=
              hornerTuple_injective hb_p
            have hτ_data : IsDataTuple t ω (ptsK (kNew p')) τ_q := by
              rw [← hτ_eq]
              exact tupleOfIdx_isDataTuple hM₀ hk_d1 (sNew p')
            have hu_eq : u.1 + 1 = r₀ + p'.1 + 1 := by dsimp [p']; omega
            refine ⟨hk_Act, ⟨hτ_data, hτ_query⟩, ⟨qIdx, by omega, rfl⟩, ?_⟩
            rw [hw0_d7, hu_eq]
            exact (hw0_new_d6 p'.1 p'.2).trans h25_p

        refine ⟨md7, hstepO, hexd7.trans hexd6,
          by rw [hw0_d7, ← hr_next_eq]; exact hw00_d6,
          hwd7_16,
          fun tbl idx ht0 ht11 =>
            (hwd7_ne tbl idx (Or.inl ht11)).trans
              ((hwm_d6 tbl idx ht0 (Or.inl ht11)).trans
                ((hw_md5_from_mQ tbl idx ht11).trans (hwmQ_pres tbl idx ht0 ht11))),
          ⟨pairs₁, hinj₁, hpairs₁_spec⟩,
          ?_⟩
        · intro q₀ hq₀_lt hr_cap k hk_Act hk_d1 hk_d2 hk_data
          rcases Nat.lt_succ_iff_lt_or_eq.mp hq₀_lt with hlt | rfl
          · rcases hcomp_prev q₀ hlt hr_cap k hk_Act hk_d1 hk_d2 hk_data with ⟨idx, hidx_lt, hw_idx⟩
            exact ⟨idx, lt_of_lt_of_le hidx_lt (qStepCount_mono Cap_q lenOf qIdx),
              (hw0_d7 _).trans ((hw0_old_d6 idx hidx_lt).trans hw_idx)⟩
          · -- q₀ = qIdx and rCount (qIdx + 1) ≤ Cap_q, so L_emit = len_b
            have hL_full : L_emit = len_b := by
              have : r₀ + len_b ≤ Cap_q := by
                dsimp [r₀, len_b, rCount, qStepCount] at hr_cap ⊢
                omega
              dsimp [L_emit, remCap]
              omega
            rcases exists_idx_of_elig_tuple hM₀ hk_data with ⟨s, hs_lt_prod, hs_eq⟩
            have hs_lt_deg : s < dataTupleCard t ω (ptsK k) := by
              rwa [prod_eligList_eq_dataTupleCard] at hs_lt_prod
            have hks_mem : (k, s) ∈ Pairs :=
              mem_activePairs_iff.mpr ⟨hk_Act, hk_d1, hk_d2, hs_lt_deg⟩
            have hb_ks : bktKey hM₀ t ω ptsK k s = b := by
              unfold bktKey
              rw [hs_eq]
            rcases hinv.buckets.fwd k s hks_mem with ⟨_, pos, hpos_bkt, _, h25_ks, _⟩
            rw [hb_ks] at hpos_bkt h25_ks
            have hpos_L : pos < L_emit := by rw [hL_full]; exact hpos_bkt
            refine ⟨r₀ + pos, by omega, ?_⟩
            rw [hw0_d7]
            exact (hw0_new_d6 pos hpos_L).trans h25_ks) with
      ⟨qMem, ⟨hex_q, hw00_q, _, _, ⟨pairs_f, hinj_f, hpairs_f⟩, hcomp_f⟩, hrepO⟩

    let r := rCount Q
    have hr_le : r ≤ Cap_q + 1 := qStepCount_le_cap Cap_q lenOf Q
    have htBranch_exec : ExecStmt inp tBranchQ m5 qMem
        (80 + Cap_q * (130 + ℓ * 60)) := by
      unfold tBranchQ seqStmts
      have hQ_le : Q ≤ Cap_q := Nat.min_le_right _ _
      have hmul1 : Q * (80 + ℓ * 60) ≤ Cap_q * (80 + ℓ * 60) := Nat.mul_le_mul_right _ hQ_le
      have hmul2 : 45 * (rCount Q - rCount 0) ≤ 45 * (Cap_q + 1) := by
        have hr_le' : rCount Q ≤ Cap_q + 1 := qStepCount_le_cap Cap_q lenOf Q
        have : rCount Q - rCount 0 ≤ Cap_q + 1 := by omega
        exact Nat.mul_le_mul_left 45 this
      have : Cap_q * (80 + ℓ * 60) + 45 * (Cap_q + 1) =
          45 + Cap_q * 125 + Cap_q * (ℓ * 60) := by ring
      have : Cap_q * (130 + ℓ * 60) = Cap_q * 130 + Cap_q * (ℓ * 60) := by ring
      exact (ExecStmt.seq hs6 (ExecStmt.seq hs7 hrepO)).mono_cost (by omega)
    have hite_exec : ExecStmt inp (.ite (.intLe (.lit 1) (.readHeap 11 (.lit 15))) tBranchQ .skip)
        m5 qMem (95 + Cap_q * (130 + ℓ * 60)) :=
      exec_ite_true hcond_pos htBranch_exec (by simp only [evalArithCond, evalIntExpr]; omega)
    have htot : ExecStmt inp (queryStmt ℓ) mem₀ qMem
        (160 + d * 30 + ℓ * 40 + ℓ * M₀ * (65 + d * 30) + Cap_q * (130 + ℓ * 60)) := by
      unfold queryStmt seqStmts
      exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 (ExecStmt.seq hrepZ
        (ExecStmt.seq hs4 (ExecStmt.seq hs5 hite_exec))))).mono_cost (by omega)

    refine ⟨qMem, r, htot, hex_q, hr_le, hw00_q,
      ⟨pairs_f, hinj_f, fun u => ⟨(hpairs_f u).1, (hpairs_f u).2.1, (hpairs_f u).2.2.2⟩⟩, ?_⟩
    intro hr_lt k_star hk_Act hk_Capu hq_Capq ⟨τ_star, hτ_data, hτ_query⟩
    have hk_d1 : 1 ≤ dataTupleCard t ω (ptsK k_star) := by
      unfold dataTupleCard
      exact Finset.card_pos.mpr ⟨τ_star, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hτ_data⟩⟩
    rcases exists_idx_of_elig_tuple hM₀ hτ_query with ⟨q₀, hq₀_prod, hq₀_eq⟩
    rw [hqProd_eq] at hq₀_prod
    have hQ_eq : Q = qProd := Nat.min_eq_left hq_Capq
    have hq₀_lt_Q : q₀ < Q := by rw [hQ_eq]; exact hq₀_prod
    have hr_q₀ : rCount (q₀ + 1) ≤ Cap_q := by
      have hle_r : rCount (q₀ + 1) ≤ r := qStepCount_mono_le Cap_q lenOf (Nat.succ_le_of_lt hq₀_lt_Q)
      omega
    rw [← hq₀_eq] at hτ_data
    exact hcomp_f q₀ hq₀_lt_Q hr_q₀ k_star hk_Act hk_d1 hk_Capu hτ_data

  · -- False branch: qProd = 0
    have hqProd_0 : qProd = 0 := by omega
    have hcond_zero : (evalArithCond inp 0 m5 (.intLe (.lit 1) (.readHeap 11 (.lit 15)))).1 = false := by
      simp [evalArithCond, evalIntExpr, hw5_15, hqProd_0]
    have hite_exec : ExecStmt inp (.ite (.intLe (.lit 1) (.readHeap 11 (.lit 15))) tBranchQ .skip)
        m5 m5 15 :=
      exec_ite_false hcond_zero (ExecStmt.skip inp hs5.2.1) (by simp [evalArithCond, evalIntExpr])
    have htot : ExecStmt inp (queryStmt ℓ) mem₀ m5
        (160 + d * 30 + ℓ * 40 + ℓ * M₀ * (65 + d * 30) + Cap_q * (130 + ℓ * 60)) := by
      unfold queryStmt seqStmts
      exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 (ExecStmt.seq hrepZ
        (ExecStmt.seq hs4 (ExecStmt.seq hs5 hite_exec))))).mono_cost (by omega)
    refine ⟨m5, 0, htot, hex5.trans (hex4.trans hex3), Nat.zero_le _, hw00_5,
      ⟨Fin.elim0, fun u => Fin.elim0 u, fun u => Fin.elim0 u⟩, ?_⟩
    intro _ _ _ _ _ ⟨τ_star, _, hτ_query⟩
    have hpos : 1 ≤ qProd := by
      unfold qProd queryTupleCard
      exact Finset.card_pos.mpr ⟨τ_star, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hτ_query⟩⟩
    omega

end UL.Proof.lem_6_3.RacerV30
