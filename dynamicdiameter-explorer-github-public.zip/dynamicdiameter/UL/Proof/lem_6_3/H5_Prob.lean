import Mathlib
import UL.Def.def_6_search_interface
import UL.Def.def_6_1_gaussian_filter
import UL.Proof.lem_6_2.H1
set_option autoImplicit false

open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal Real

namespace UL.Proof_lem_6_3

/-! ### 1. Basic `measureReal` tools on probability spaces and product Gaussians -/

theorem measureReal_union_le_add {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) [IsFiniteMeasure μ]
    (A B : Set Ω) :
    μ.real (A ∪ B) ≤ μ.real A + μ.real B := by
  simp only [MeasureTheory.measureReal_def]
  rw [← ENNReal.toReal_add (measure_ne_top μ A) (measure_ne_top μ B)]
  exact ENNReal.toReal_mono (ENNReal.add_ne_top.mpr ⟨measure_ne_top μ A, measure_ne_top μ B⟩)
    (measure_union_le A B)

theorem measureReal_biUnion_finset_le_sum {Ω β : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (S : Finset β) (E : β → Set Ω) :
    μ.real (⋃ b ∈ S, E b) ≤ ∑ b ∈ S, μ.real (E b) := by
  classical
  induction S using Finset.induction_on with
  | empty => simp [MeasureTheory.measureReal_def]
  | @insert a s ha ih =>
      rw [Finset.set_biUnion_insert, Finset.sum_insert ha]
      linarith [measureReal_union_le_add μ (E a) (⋃ b ∈ s, E b), ih]

theorem probReal_compl_eq {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {B : Set Ω} (hB : MeasurableSet B) :
    μ.real (Bᶜ) = 1 - μ.real B := by
  simp only [MeasureTheory.measureReal_def]
  rw [measure_compl hB (measure_ne_top μ B), measure_univ,
    ENNReal.toReal_sub_of_le prob_le_one ENNReal.one_ne_top, ENNReal.toReal_one]

/-- Cylinder probability on `Measure.pi (fun _ : Fin K => stdGaussianMeasure d)` along any injective
index map `f : α → Fin K`. -/
theorem measureReal_forall_injective {α : Type*} [Fintype α]
    (K d : ℕ) (f : α → Fin K) (hf : Function.Injective f)
    (A : Set (EuclideanSpace ℝ (Fin d))) :
    (Measure.pi (fun _ : Fin K => UL.stdGaussianMeasure d)).real {ω | ∀ a : α, ω (f a) ∈ A} =
      ((UL.stdGaussianMeasure d).real A) ^ Fintype.card α := by
  classical
  let T : Fin K → Set (EuclideanSpace ℝ (Fin d)) :=
    fun g => if g ∈ Finset.univ.image f then A else Set.univ
  have hset : {ω : Fin K → EuclideanSpace ℝ (Fin d) | ∀ a : α, ω (f a) ∈ A} = Set.univ.pi T := by
    ext ω
    simp only [Set.mem_setOf_eq, Set.mem_univ_pi, T, Finset.mem_image, Finset.mem_univ, true_and]
    constructor
    · intro h g
      split_ifs with hg
      · rcases hg with ⟨a, rfl⟩
        exact h a
      · trivial
    · intro h a
      have hg := h (f a)
      rw [if_pos ⟨a, rfl⟩] at hg
      exact hg
  rw [hset, MeasureTheory.measureReal_def, Measure.pi_pi, ENNReal.toReal_prod]
  have hterm : ∀ g : Fin K,
      (UL.stdGaussianMeasure d (T g)).toReal =
        if g ∈ Finset.univ.image f then (UL.stdGaussianMeasure d).real A else 1 := by
    intro g
    dsimp only [T]
    split_ifs
    · rfl
    · simp
  simp_rw [hterm]
  rw [Finset.prod_ite_mem, Finset.univ_inter, Finset.prod_const,
    Finset.card_image_of_injective _ hf, Finset.card_univ]

/-- Markov's inequality for the cardinality of a finite family of measurable events. -/
theorem markov_card_filter_lt {Ω β : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ]
    (S : Finset β) (E : β → Set Ω) (hE : ∀ b ∈ S, MeasurableSet (E b))
    (N : ℕ) (hN : 1 ≤ N) :
    MeasurableSet {ω : Ω | N < (open Classical in (S.filter (fun b => ω ∈ E b)).card)} ∧
    μ.real {ω : Ω | N < (open Classical in (S.filter (fun b => ω ∈ E b)).card)} ≤
      (∑ b ∈ S, μ.real (E b)) / (N : ℝ) := by
  classical
  let cnt : Ω → ℝ := fun ω => ∑ b ∈ S, (E b).indicator (fun _ : Ω => (1 : ℝ)) ω
  have hcnt_eq : ∀ ω : Ω, cnt ω = ((S.filter (fun b => ω ∈ E b)).card : ℝ) := by
    intro ω
    dsimp only [cnt]
    rw [Finset.card_eq_sum_ones, Nat.cast_sum, Finset.sum_filter]
    refine Finset.sum_congr rfl fun b _ => ?_
    by_cases hb : ω ∈ E b <;> simp [Set.indicator, hb]
  have hcnt_meas : Measurable cnt :=
    Finset.measurable_sum S (fun b hb => measurable_const.indicator (hE b hb))
  have hcnt_int : Integrable cnt μ :=
    integrable_finset_sum S (fun b hb => (integrable_const (1 : ℝ)).indicator (hE b hb))
  have hcnt_integral : ∫ ω, cnt ω ∂μ = ∑ b ∈ S, μ.real (E b) := by
    dsimp only [cnt]
    rw [integral_finset_sum S (fun b hb => (integrable_const (1 : ℝ)).indicator (hE b hb))]
    refine Finset.sum_congr rfl fun b hb => ?_
    simp [integral_indicator (hE b hb), MeasureTheory.measureReal_def]
  let Bad : Set Ω := {ω : Ω | N < (S.filter (fun b => ω ∈ E b)).card}
  have hBad_eq : Bad = {ω : Ω | (N : ℝ) < cnt ω} := by
    ext ω
    simp only [Bad, Set.mem_setOf_eq, hcnt_eq ω, Nat.cast_lt]
  have hBad_meas : MeasurableSet Bad := by
    rw [hBad_eq]
    exact measurableSet_lt measurable_const hcnt_meas
  refine ⟨hBad_meas, ?_⟩
  have hN_pos : (0 : ℝ) < (N : ℝ) := by positivity
  rw [le_div_iff₀ hN_pos]
  have hpt : ∀ ω : Ω, Bad.indicator (fun _ : Ω => (N : ℝ)) ω ≤ cnt ω := by
    intro ω
    by_cases hω : ω ∈ Bad
    · rw [Set.indicator_of_mem hω]
      rw [hBad_eq] at hω
      exact le_of_lt hω
    · simp only [Set.indicator, hω, ↓reduceIte]
      exact Finset.sum_nonneg fun b _ => Set.indicator_nonneg (fun _ _ => zero_le_one) ω
  have hint_le := integral_mono ((integrable_const (N : ℝ)).indicator hBad_meas) hcnt_int hpt
  rw [integral_indicator_const (N : ℝ) hBad_meas, smul_eq_mul, hcnt_integral] at hint_le
  exact hint_le

/-! ### 2. Base-cap indexing and tuple predicates -/

/-- Flattened Gaussian index `j * M₀ + s < ℓ * M₀` for family `j : Fin ℓ` and cap `s : Fin M₀`. -/
def capIdx {ℓ M₀ : ℕ} (j : Fin ℓ) (s : Fin M₀) : Fin (ℓ * M₀) :=
  ⟨j.1 * M₀ + s.1, by
    calc j.1 * M₀ + s.1 < j.1 * M₀ + M₀ := Nat.add_lt_add_left s.2 _
      _ = (j.1 + 1) * M₀ := by ring
      _ ≤ ℓ * M₀ := Nat.mul_le_mul_right M₀ (Nat.succ_le_of_lt j.2)⟩

theorem capIdx_injective_right {ℓ M₀ : ℕ} (j : Fin ℓ) :
    Function.Injective (capIdx j : Fin M₀ → Fin (ℓ * M₀)) := by
  intro s₁ s₂ h
  apply Fin.ext
  have hv := congrArg Fin.val h
  dsimp [capIdx] at hv
  omega

theorem capIdx_tuple_injective {ℓ M₀ : ℕ} (hM₀ : 1 ≤ M₀) (τ : Fin ℓ → Fin M₀) :
    Function.Injective (fun j : Fin ℓ => capIdx j (τ j)) := by
  intro j₁ j₂ h
  apply Fin.ext
  have hv := congrArg Fin.val h
  dsimp [capIdx] at hv
  have hs₁ : (τ j₁).1 < M₀ := (τ j₁).2
  have hs₂ : (τ j₂).1 < M₀ := (τ j₂).2
  have hdiv₁ : (j₁.1 * M₀ + (τ j₁).1) / M₀ = j₁.1 := by
    rw [Nat.mul_comm, Nat.mul_add_div (by omega), Nat.div_eq_of_lt hs₁, Nat.add_zero]
  have hdiv₂ : (j₂.1 * M₀ + (τ j₂).1) / M₀ = j₂.1 := by
    rw [Nat.mul_comm, Nat.mul_add_div (by omega), Nat.div_eq_of_lt hs₂, Nat.add_zero]
  have hq := congrArg (· / M₀) hv
  dsimp only at hq
  rw [hdiv₁, hdiv₂] at hq
  exact hq

/-- Data-tuple membership on outcome `ω` for point `p` and tuple `τ : Fin ℓ → Fin M₀`. -/
def IsDataTuple {ℓ M₀ d : ℕ} (t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (p : EuclideanSpace ℝ (Fin d)) (τ : Fin ℓ → Fin M₀) : Prop :=
  ∀ j : Fin ℓ, UL.gaussianDataTest t (ω (capIdx j (τ j))) p

/-- Query-tuple membership on outcome `ω` for query vector `z` and tuple `τ : Fin ℓ → Fin M₀`. -/
def IsQueryTuple {ℓ M₀ d : ℕ} (x t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (z : EuclideanSpace ℝ (Fin d)) (τ : Fin ℓ → Fin M₀) : Prop :=
  ∀ j : Fin ℓ, UL.gaussianQueryTest x t (ω (capIdx j (τ j))) z

/-- Shared-tuple membership on outcome `ω` for point `p`, query `z`, and tuple `τ`. -/
def IsSharedTuple {ℓ M₀ d : ℕ} (x t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (p z : EuclideanSpace ℝ (Fin d)) (τ : Fin ℓ → Fin M₀) : Prop :=
  IsDataTuple t ω p τ ∧ IsQueryTuple x t ω z τ

/-- Number of data tuples of `p` on outcome `ω`. -/
noncomputable def dataTupleCard {ℓ M₀ d : ℕ} (t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (p : EuclideanSpace ℝ (Fin d)) : ℕ :=
  open Classical in (Finset.univ.filter (fun τ : Fin ℓ → Fin M₀ => IsDataTuple t ω p τ)).card

/-- Number of query tuples of `z` on outcome `ω`. -/
noncomputable def queryTupleCard {ℓ M₀ d : ℕ} (x t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (z : EuclideanSpace ℝ (Fin d)) : ℕ :=
  open Classical in (Finset.univ.filter (fun τ : Fin ℓ → Fin M₀ => IsQueryTuple x t ω z τ)).card

/-- Number of shared `(k, τ)` pairs with nonpositive-correlation birth points `⟪pts k, z⟫ ≤ 0`. -/
noncomputable def badSharedCard {ℓ M₀ m d : ℕ} (x t : ℝ)
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d))
    (z : EuclideanSpace ℝ (Fin d))
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) : ℕ :=
  open Classical in
  (Finset.univ.filter (fun kt : Fin m × (Fin ℓ → Fin M₀) =>
    inner ℝ (ptsK kt.1) z ≤ 0 ∧ IsSharedTuple x t ω (ptsK kt.1) z kt.2)).card

/-! ### 3. Main probability bound for the good event `E` (at least `24 / 25 ≥ 9 / 10`) -/

theorem goodEvent_prob_ge {ℓ M₀ m d : ℕ}
    (hℓ : 1 ≤ ℓ) (hM₀ : 1 ≤ M₀)
    {h x t p_u p_q p₁ p₂ : ℝ}
    (hprobs : UL.IsGaussianFilterProbs d h x t p_u p_q p₁ p₂)
    (hp₁_pos : 0 < p₁)
    (hp₁_M : Real.log (100 * (ℓ : ℝ)) ≤ p₁ * (M₀ : ℝ))
    {Cap_u Cap_q : ℕ}
    (hCap_u_pos : 1 ≤ Cap_u) (hCap_q_pos : 1 ≤ Cap_q)
    (hCap_u : 100 * ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ + 1) ≤ (Cap_u : ℝ))
    (hCap_q : 100 * ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ + 1) ≤ (Cap_q : ℝ))
    (hCap_bad : 100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ + 1) ≤ (Cap_q : ℝ))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin d))
    (hunit_pts : ∀ k : Fin m, UL.IsUnitVec (ptsK k))
    {p_star z : EuclideanSpace ℝ (Fin d)}
    (hp_star : UL.IsUnitVec p_star) (hz : UL.IsUnitVec z)
    (htarget : h ≤ inner ℝ p_star z) :
    let μ := Measure.pi (fun _ : Fin (ℓ * M₀) => UL.stdGaussianMeasure d)
    let E : Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) :=
      {ω | (∃ τ : Fin ℓ → Fin M₀, IsSharedTuple x t ω p_star z τ) ∧
           dataTupleCard t ω p_star ≤ Cap_u ∧
           queryTupleCard x t ω z ≤ Cap_q ∧
           badSharedCard x t ptsK z ω ≤ Cap_q}
    MeasurableSet E ∧ (9 / 10 : ℝ) ≤ μ.real E := by
  classical
  intro μ E
  rcases hprobs with ⟨_, hmarg_u, hmarg_q, hjoint_lo, hjoint_hi⟩
  have hmeas_data : ∀ p : EuclideanSpace ℝ (Fin d),
      MeasurableSet {G : EuclideanSpace ℝ (Fin d) | UL.gaussianDataTest t G p} :=
    fun p => measurableSet_le measurable_const (continuous_id.inner continuous_const).measurable
  have hmeas_query :
      MeasurableSet {G : EuclideanSpace ℝ (Fin d) | UL.gaussianQueryTest x t G z} :=
    measurableSet_le measurable_const (continuous_id.inner continuous_const).measurable
  have hmeas_joint : ∀ p : EuclideanSpace ℝ (Fin d),
      MeasurableSet {G : EuclideanSpace ℝ (Fin d) |
        UL.gaussianDataTest t G p ∧ UL.gaussianQueryTest x t G z} :=
    fun p => (hmeas_data p).inter hmeas_query

  -- Bad event 1: missing a shared base cap in some family `j : Fin ℓ`
  let S_star : Set (EuclideanSpace ℝ (Fin d)) :=
    {G | UL.gaussianDataTest t G p_star ∧ UL.gaussianQueryTest x t G z}
  let B₁_fam : Fin ℓ → Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) :=
    fun j => {ω | ∀ s : Fin M₀, ω (capIdx j s) ∈ S_starᶜ}
  let B₁ : Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) := ⋃ j ∈ (Finset.univ : Finset (Fin ℓ)), B₁_fam j

  have hB₁_eq : B₁ = {ω | ∃ τ : Fin ℓ → Fin M₀, IsSharedTuple x t ω p_star z τ}ᶜ := by
    ext ω
    simp only [B₁, B₁_fam, S_star, Finset.mem_univ, Set.mem_iUnion, exists_prop, true_and,
      Set.mem_setOf_eq, Set.mem_compl_iff, IsSharedTuple, IsDataTuple, IsQueryTuple]
    constructor
    · rintro ⟨j, hj⟩ ⟨τ, hτ₁, hτ₂⟩
      exact hj (τ j) ⟨hτ₁ j, hτ₂ j⟩
    · intro hno
      by_contra hall
      push_neg at hall
      choose τ hτ using hall
      exact hno ⟨τ, fun j => (hτ j).1, fun j => (hτ j).2⟩

  have hB₁_meas : MeasurableSet B₁ := by
    refine Finset.measurableSet_biUnion _ fun j _ => ?_
    have : B₁_fam j = ⋂ s : Fin M₀, {ω | ω (capIdx j s) ∈ S_starᶜ} := by
      ext ω; simp [B₁_fam]
    rw [this]
    exact MeasurableSet.iInter fun s => (hmeas_joint p_star).compl.preimage (measurable_pi_apply _)

  have hB₁_prob : μ.real B₁ ≤ 1 / 100 := by
    have h_each : ∀ j : Fin ℓ, μ.real (B₁_fam j) ≤ 1 / (100 * (ℓ : ℝ)) := by
      intro j
      have hcyl := measureReal_forall_injective (ℓ * M₀) d (capIdx j) (capIdx_injective_right j) S_starᶜ
      rw [Fintype.card_fin] at hcyl
      have hcompl : (UL.stdGaussianMeasure d).real S_starᶜ = 1 - UL.gaussianJointProb x t p_star z :=
        probReal_compl_eq (UL.stdGaussianMeasure d) (hmeas_joint p_star)
      have hp₁_le : p₁ ≤ UL.gaussianJointProb x t p_star z := hjoint_lo p_star z hp_star hz htarget
      have hj_le_one : UL.gaussianJointProb x t p_star z ≤ 1 := by
        unfold UL.gaussianJointProb
        simpa [MeasureTheory.measureReal_def] using ENNReal.toReal_mono ENNReal.one_ne_top prob_le_one
      have hnonneg : 0 ≤ 1 - UL.gaussianJointProb x t p_star z := by linarith
      have h1mp : 1 - UL.gaussianJointProb x t p_star z ≤ Real.exp (-p₁) := by
        calc 1 - UL.gaussianJointProb x t p_star z ≤ 1 - p₁ := by linarith
          _ = -p₁ + 1 := by ring
          _ ≤ Real.exp (-p₁) := Real.add_one_le_exp (-p₁)
      have hpow : (1 - UL.gaussianJointProb x t p_star z) ^ M₀ ≤ 1 / (100 * (ℓ : ℝ)) := by
        calc (1 - UL.gaussianJointProb x t p_star z) ^ M₀
            ≤ (Real.exp (-p₁)) ^ M₀ := pow_le_pow_left₀ hnonneg h1mp M₀
          _ = Real.exp (-(p₁ * (M₀ : ℝ))) := by
              rw [← Real.exp_nat_mul]; congr 1; ring
          _ ≤ Real.exp (-Real.log (100 * (ℓ : ℝ))) :=
              Real.exp_le_exp.mpr (by linarith)
          _ = (100 * (ℓ : ℝ))⁻¹ := by
              rw [Real.exp_neg, Real.exp_log (by positivity)]
          _ = 1 / (100 * (ℓ : ℝ)) := (one_div _).symm
      dsimp only [B₁_fam, μ]
      rw [hcyl, hcompl]
      exact hpow
    calc μ.real B₁ ≤ ∑ j ∈ (Finset.univ : Finset (Fin ℓ)), μ.real (B₁_fam j) :=
          measureReal_biUnion_finset_le_sum μ _ _
      _ ≤ ∑ _j ∈ (Finset.univ : Finset (Fin ℓ)), (1 / (100 * (ℓ : ℝ))) :=
          Finset.sum_le_sum fun j _ => h_each j
      _ = (ℓ : ℝ) * (1 / (100 * (ℓ : ℝ))) := by simp
      _ = 1 / 100 := by
          have hℓ_ne : (ℓ : ℝ) ≠ 0 := by positivity
          field_simp

  -- Bad event 2: `Cap_u < dataTupleCard`
  let E_data : (Fin ℓ → Fin M₀) → Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) :=
    fun τ => {ω | IsDataTuple t ω p_star τ}
  have hE_data_meas : ∀ τ ∈ (Finset.univ : Finset (Fin ℓ → Fin M₀)), MeasurableSet (E_data τ) := by
    intro τ _
    have : E_data τ = ⋂ j : Fin ℓ, {ω | ω (capIdx j (τ j)) ∈ {G | UL.gaussianDataTest t G p_star}} := by
      ext ω; simp [E_data, IsDataTuple]
    rw [this]
    exact MeasurableSet.iInter fun j => (hmeas_data p_star).preimage (measurable_pi_apply _)
  rcases markov_card_filter_lt μ Finset.univ E_data hE_data_meas Cap_u hCap_u_pos with
    ⟨hB₂_meas, hB₂_markov⟩
  have hB₂_prob : μ.real {ω | Cap_u < dataTupleCard t ω p_star} ≤ 1 / 100 := by
    have hsum : ∑ τ ∈ (Finset.univ : Finset (Fin ℓ → Fin M₀)), μ.real (E_data τ) =
        (M₀ : ℝ) ^ ℓ * p_u ^ ℓ := by
      have h_each : ∀ τ : Fin ℓ → Fin M₀, μ.real (E_data τ) = p_u ^ ℓ := by
        intro τ
        have hcyl := measureReal_forall_injective (ℓ * M₀) d (fun j => capIdx j (τ j))
          (capIdx_tuple_injective hM₀ τ) {G | UL.gaussianDataTest t G p_star}
        rw [Fintype.card_fin] at hcyl
        have hpu : (UL.stdGaussianMeasure d).real {G | UL.gaussianDataTest t G p_star} = p_u :=
          hmarg_u p_star hp_star
        change (Measure.pi fun _ : Fin (ℓ * M₀) => UL.stdGaussianMeasure d).real
            {ω | ∀ a : Fin ℓ, ω (capIdx a (τ a)) ∈ {G | UL.gaussianDataTest t G p_star}} = p_u ^ ℓ
        rw [hcyl]
        dsimp only [UL.gaussianDataProb] at hpu
        rw [hpu]
      simp [h_each]
    have hpu_nonneg : 0 ≤ (M₀ : ℝ) ^ ℓ * p_u ^ ℓ := by
      have : 0 ≤ p_u := by
        rw [← hmarg_u p_star hp_star]; exact MeasureTheory.measureReal_nonneg
      positivity
    have hdiv : ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ) / (Cap_u : ℝ) ≤ 1 / 100 := by
      rw [div_le_iff₀ (by positivity)]
      linarith
    have hstep1 : μ.real {ω | Cap_u < dataTupleCard t ω p_star} ≤
        ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ) / (Cap_u : ℝ) := by
      rw [← hsum]
      exact hB₂_markov
    exact hstep1.trans hdiv

  -- Bad event 3: `Cap_q < queryTupleCard`
  let E_query : (Fin ℓ → Fin M₀) → Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) :=
    fun τ => {ω | IsQueryTuple x t ω z τ}
  have hE_query_meas : ∀ τ ∈ (Finset.univ : Finset (Fin ℓ → Fin M₀)), MeasurableSet (E_query τ) := by
    intro τ _
    have : E_query τ = ⋂ j : Fin ℓ, {ω | ω (capIdx j (τ j)) ∈ {G | UL.gaussianQueryTest x t G z}} := by
      ext ω; simp [E_query, IsQueryTuple]
    rw [this]
    exact MeasurableSet.iInter fun j => hmeas_query.preimage (measurable_pi_apply _)
  rcases markov_card_filter_lt μ Finset.univ E_query hE_query_meas Cap_q hCap_q_pos with
    ⟨hB₃_meas, hB₃_markov⟩
  have hB₃_prob : μ.real {ω | Cap_q < queryTupleCard x t ω z} ≤ 1 / 100 := by
    have hsum : ∑ τ ∈ (Finset.univ : Finset (Fin ℓ → Fin M₀)), μ.real (E_query τ) =
        (M₀ : ℝ) ^ ℓ * p_q ^ ℓ := by
      have h_each : ∀ τ : Fin ℓ → Fin M₀, μ.real (E_query τ) = p_q ^ ℓ := by
        intro τ
        have hcyl := measureReal_forall_injective (ℓ * M₀) d (fun j => capIdx j (τ j))
          (capIdx_tuple_injective hM₀ τ) {G | UL.gaussianQueryTest x t G z}
        rw [Fintype.card_fin] at hcyl
        have hpq : (UL.stdGaussianMeasure d).real {G | UL.gaussianQueryTest x t G z} = p_q :=
          hmarg_q z hz
        change (Measure.pi fun _ : Fin (ℓ * M₀) => UL.stdGaussianMeasure d).real
            {ω | ∀ a : Fin ℓ, ω (capIdx a (τ a)) ∈ {G | UL.gaussianQueryTest x t G z}} = p_q ^ ℓ
        rw [hcyl]
        dsimp only [UL.gaussianQueryProb] at hpq
        rw [hpq]
      simp [h_each]
    have hpq_nonneg : 0 ≤ (M₀ : ℝ) ^ ℓ * p_q ^ ℓ := by
      have : 0 ≤ p_q := by
        rw [← hmarg_q z hz]; exact MeasureTheory.measureReal_nonneg
      positivity
    have hdiv : ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ) / (Cap_q : ℝ) ≤ 1 / 100 := by
      rw [div_le_iff₀ (by positivity)]
      linarith
    have hstep1 : μ.real {ω | Cap_q < queryTupleCard x t ω z} ≤
        ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ) / (Cap_q : ℝ) := by
      rw [← hsum]
      exact hB₃_markov
    exact hstep1.trans hdiv

  -- Bad event 4: `Cap_q < badSharedCard`
  let E_bad : (Fin m × (Fin ℓ → Fin M₀)) → Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) :=
    fun kt => {ω | inner ℝ (ptsK kt.1) z ≤ 0 ∧ IsSharedTuple x t ω (ptsK kt.1) z kt.2}
  have hE_bad_meas :
      ∀ kt ∈ (Finset.univ : Finset (Fin m × (Fin ℓ → Fin M₀))), MeasurableSet (E_bad kt) := by
    intro kt _
    have hshared_eq :
        {ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d) | IsSharedTuple x t ω (ptsK kt.1) z kt.2} =
          ⋂ j : Fin ℓ, {ω | ω (capIdx j (kt.2 j)) ∈
            {G | UL.gaussianDataTest t G (ptsK kt.1) ∧ UL.gaussianQueryTest x t G z}} := by
      ext ω
      simp [IsSharedTuple, IsDataTuple, IsQueryTuple, forall_and]
    have hsm : MeasurableSet {ω | IsSharedTuple x t ω (ptsK kt.1) z kt.2} := by
      rw [hshared_eq]
      exact MeasurableSet.iInter fun j => (hmeas_joint (ptsK kt.1)).preimage (measurable_pi_apply _)
    exact (MeasurableSet.const _).inter hsm
  rcases markov_card_filter_lt μ Finset.univ E_bad hE_bad_meas Cap_q hCap_q_pos with
    ⟨hB₄_meas, hB₄_markov⟩
  have hp₂_nonneg : 0 ≤ p₂ := by
    -- If m = 0, m * ... = 0 anyway; otherwise check nonnegativity directly if needed:
    -- Better: we bound each term μ.real (E_bad kt) ≤ max 0 p₂ or prove 0 ≤ p₂ from -z!
    have hneg_z : UL.IsUnitVec (-z) := by
      unfold UL.IsUnitVec at hz ⊢; simpa using hz
    have hle0 : inner ℝ (-z) z ≤ 0 := by
      rw [inner_neg_left, real_inner_self_eq_norm_sq]
      nlinarith [norm_nonneg z]
    exact MeasureTheory.measureReal_nonneg.trans (hjoint_hi (-z) z hneg_z hz hle0)
  have hB₄_prob : μ.real {ω | Cap_q < badSharedCard x t ptsK z ω} ≤ 1 / 100 := by
    have hsum_le : ∑ kt ∈ (Finset.univ : Finset (Fin m × (Fin ℓ → Fin M₀))), μ.real (E_bad kt) ≤
        (m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ := by
      have h_each : ∀ kt : Fin m × (Fin ℓ → Fin M₀), μ.real (E_bad kt) ≤ p₂ ^ ℓ := by
        intro kt
        by_cases hcor : inner ℝ (ptsK kt.1) z ≤ 0
        · have hset_eq : E_bad kt =
              {ω | ∀ j : Fin ℓ, ω (capIdx j (kt.2 j)) ∈
                {G | UL.gaussianDataTest t G (ptsK kt.1) ∧ UL.gaussianQueryTest x t G z}} := by
            ext ω
            simp [E_bad, hcor, IsSharedTuple, IsDataTuple, IsQueryTuple, forall_and]
          rw [hset_eq, measureReal_forall_injective (ℓ * M₀) d (fun j => capIdx j (kt.2 j))
            (capIdx_tuple_injective hM₀ kt.2), Fintype.card_fin]
          exact pow_le_pow_left₀ MeasureTheory.measureReal_nonneg
            (hjoint_hi (ptsK kt.1) z (hunit_pts kt.1) hz hcor) ℓ
        · have hset_emp : E_bad kt = ∅ := by ext ω; simp [E_bad, hcor]
          rw [hset_emp]
          simp only [MeasureTheory.measureReal_empty]
          positivity
      calc ∑ kt ∈ (Finset.univ : Finset (Fin m × (Fin ℓ → Fin M₀))), μ.real (E_bad kt)
          ≤ ∑ _kt ∈ (Finset.univ : Finset (Fin m × (Fin ℓ → Fin M₀))), p₂ ^ ℓ :=
            Finset.sum_le_sum fun kt _ => h_each kt
        _ = (m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ := by
            simp [mul_assoc]
    have hdiv : ((m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ) / (Cap_q : ℝ) ≤ 1 / 100 := by
      rw [div_le_iff₀ (by positivity)]
      linarith
    have hset_bad : {ω | Cap_q < badSharedCard x t ptsK z ω} =
        {ω | Cap_q < (@Finset.filter _ (fun b => ω ∈ E_bad b)
          (fun b => Classical.propDecidable _) Finset.univ).card} := by
      ext ω
      simp only [Set.mem_setOf_eq, badSharedCard]
      have hf : Finset.univ.filter (fun kt : Fin m × (Fin ℓ → Fin M₀) =>
          inner ℝ (ptsK kt.1) z ≤ 0 ∧ IsSharedTuple x t ω (ptsK kt.1) z kt.2) =
          @Finset.filter _ (fun b => ω ∈ E_bad b)
            (fun b => Classical.propDecidable _) Finset.univ := by
        ext kt
        simp [E_bad]
      rw [hf]
    have hstep1 : μ.real {ω | Cap_q < badSharedCard x t ptsK z ω} ≤
        (∑ kt ∈ Finset.univ, μ.real (E_bad kt)) / (Cap_q : ℝ) := by
      rw [hset_bad]
      exact hB₄_markov
    exact hstep1.trans ((div_le_div_of_nonneg_right hsum_le (by positivity)).trans hdiv)

  -- Combine the four bad events
  let B₂ : Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) := {ω | Cap_u < dataTupleCard t ω p_star}
  let B₃ : Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) := {ω | Cap_q < queryTupleCard x t ω z}
  let B₄ : Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) := {ω | Cap_q < badSharedCard x t ptsK z ω}
  have hB₂_m : MeasurableSet B₂ := hB₂_meas
  have hB₃_m : MeasurableSet B₃ := hB₃_meas
  have hB₄_m : MeasurableSet B₄ := by
    have hset_bad : B₄ =
        {ω | Cap_q < (@Finset.filter _ (fun b => ω ∈ E_bad b)
          (fun b => Classical.propDecidable _) Finset.univ).card} := by
      ext ω
      simp only [B₄, Set.mem_setOf_eq, badSharedCard]
      have hf : Finset.univ.filter (fun kt : Fin m × (Fin ℓ → Fin M₀) =>
          inner ℝ (ptsK kt.1) z ≤ 0 ∧ IsSharedTuple x t ω (ptsK kt.1) z kt.2) =
          @Finset.filter _ (fun b => ω ∈ E_bad b)
            (fun b => Classical.propDecidable _) Finset.univ := by
        ext kt
        simp [E_bad]
      rw [hf]
    rw [hset_bad]
    exact hB₄_meas
  let B_all := B₁ ∪ B₂ ∪ B₃ ∪ B₄
  have hB_all_m : MeasurableSet B_all := ((hB₁_meas.union hB₂_m).union hB₃_m).union hB₄_m
  have hE_eq : E = B_allᶜ := by
    ext ω
    simp only [E, B_all, B₂, B₃, B₄, hB₁_eq, Set.mem_compl_iff, Set.mem_union, Set.mem_setOf_eq,
      not_or, not_not, not_lt, and_assoc]
  rw [hE_eq]
  refine ⟨hB_all_m.compl, ?_⟩
  rw [probReal_compl_eq μ hB_all_m]
  have hB_all_le : μ.real B_all ≤ 4 / 100 := by
    calc μ.real (B₁ ∪ B₂ ∪ B₃ ∪ B₄)
        ≤ μ.real (B₁ ∪ B₂ ∪ B₃) + μ.real B₄ := measureReal_union_le_add μ _ _
      _ ≤ (μ.real (B₁ ∪ B₂) + μ.real B₃) + μ.real B₄ := by
          gcongr; exact measureReal_union_le_add μ _ _
      _ ≤ ((μ.real B₁ + μ.real B₂) + μ.real B₃) + μ.real B₄ := by
          gcongr; exact measureReal_union_le_add μ _ _
      _ ≤ ((1 / 100 + 1 / 100) + 1 / 100) + 1 / 100 := by
          linarith [hB₁_prob, hB₂_prob, hB₃_prob, hB₄_prob]
      _ = 4 / 100 := by norm_num
  linarith

end UL.Proof_lem_6_3
