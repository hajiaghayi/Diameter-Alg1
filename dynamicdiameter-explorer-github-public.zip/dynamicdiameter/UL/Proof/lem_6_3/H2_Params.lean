import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_6_search_exponents
import UL.Proof.lem_6_3.H1_RAM
set_option autoImplicit false

namespace UL.Proof_lem_6_3

/-! ### 1. Elementary exponential and exponent inequalities -/

theorem exp_half_le_two : Real.exp (1 / 2 : ℝ) ≤ 2 := by
  have h1 : (1 / 2 : ℝ) ≤ Real.exp (-(1 / 2 : ℝ)) := by
    have := Real.add_one_le_exp (-(1 / 2 : ℝ))
    linarith
  have hprod : Real.exp (1 / 2 : ℝ) * Real.exp (-(1 / 2 : ℝ)) = 1 := by
    rw [← Real.exp_add]; simp
  have hpos : 0 < Real.exp (1 / 2 : ℝ) := Real.exp_pos _
  nlinarith

theorem exp_one_le_four : Real.exp 1 ≤ 4 := by
  have hsq : Real.exp 1 = Real.exp (1 / 2 : ℝ) * Real.exp (1 / 2 : ℝ) := by
    rw [← Real.exp_add]; norm_num
  have hpos : 0 ≤ Real.exp (1 / 2 : ℝ) := (Real.exp_pos _).le
  rw [hsq]
  nlinarith [exp_half_le_two]

theorem two_le_exp_one : (2 : ℝ) ≤ Real.exp 1 := by
  have := Real.add_one_le_exp 1
  linarith

theorem exp_le_two_pow_two_mul {z : ℝ} (M : ℕ) (hz : z ≤ (M : ℝ)) :
    Real.exp z ≤ (2 : ℝ) ^ (2 * M) := by
  calc Real.exp z ≤ Real.exp (M : ℝ) := Real.exp_le_exp.mpr hz
    _ = (Real.exp 1) ^ M := by simpa using Real.exp_nat_mul 1 M
    _ ≤ (4 : ℝ) ^ M := pow_le_pow_left₀ (Real.exp_pos 1).le exp_one_le_four M
    _ = ((2 : ℝ) ^ 2) ^ M := by norm_num
    _ = (2 : ℝ) ^ (2 * M) := (pow_mul (2 : ℝ) 2 M).symm

theorem nat_cast_le_two_pow (n : ℕ) : (n : ℝ) ≤ (2 : ℝ) ^ n := by
  exact_mod_cast (Nat.lt_two_pow_self (n := n)).le

/-- Rational power approximation `(1 + z / N)^N ∈ [1/2 exp z, exp z]` for `0 ≤ z` and
`3 z^2 + 1 ≤ N`. -/
theorem one_plus_div_pow_approx {z : ℝ} {N : ℕ} (hz : 0 ≤ z) (hN : 3 * z ^ 2 + 1 ≤ (N : ℝ)) :
    1 ≤ (1 + z / (N : ℝ)) ^ N ∧
    (1 + z / (N : ℝ)) ^ N ≤ Real.exp z ∧
    Real.exp z ≤ 2 * (1 + z / (N : ℝ)) ^ N := by
  have hN1 : (1 : ℝ) ≤ (N : ℝ) := by nlinarith
  have hN_pos : (0 : ℝ) < (N : ℝ) := by positivity
  have hN_ne : (N : ℝ) ≠ 0 := hN_pos.ne'
  have hbase_ge_one : 1 ≤ 1 + z / (N : ℝ) := by
    have : 0 ≤ z / (N : ℝ) := div_nonneg hz hN_pos.le
    linarith
  have h1 : 1 ≤ (1 + z / (N : ℝ)) ^ N := one_le_pow₀ hbase_ge_one
  have h2 : (1 + z / (N : ℝ)) ^ N ≤ Real.exp z := by
    calc (1 + z / (N : ℝ)) ^ N
        ≤ (Real.exp (z / (N : ℝ))) ^ N := by
          refine pow_le_pow_left₀ (by linarith) ?_ N
          linarith [Real.add_one_le_exp (z / (N : ℝ))]
      _ = Real.exp ((N : ℝ) * (z / (N : ℝ))) := (Real.exp_nat_mul _ N).symm
      _ = Real.exp z := by congr 1; field_simp
  have hz_lt_N : z < (N : ℝ) := by
    have : 0 < 3 * (z - 1 / 6) ^ 2 + 11 / 12 := by positivity
    nlinarith
  have hNmz_pos : 0 < (N : ℝ) - z := by linarith
  have h1m_pos : 0 < 1 - z / (N : ℝ) := by
    rw [sub_pos, div_lt_one hN_pos]; exact hz_lt_N
  have h1m_pow : (1 - z / (N : ℝ)) ^ N ≤ Real.exp (-z) := by
    calc (1 - z / (N : ℝ)) ^ N
        ≤ (Real.exp (-(z / (N : ℝ)))) ^ N := by
          refine pow_le_pow_left₀ h1m_pos.le ?_ N
          linarith [Real.add_one_le_exp (-(z / (N : ℝ)))]
      _ = Real.exp ((N : ℝ) * (-(z / (N : ℝ)))) := (Real.exp_nat_mul _ N).symm
      _ = Real.exp (-z) := by congr 1; field_simp
  have hexp_le_inv : Real.exp z ≤ ((N : ℝ) / ((N : ℝ) - z)) ^ N := by
    have hprod_le : Real.exp z * (1 - z / (N : ℝ)) ^ N ≤ 1 := by
      calc Real.exp z * (1 - z / (N : ℝ)) ^ N
          ≤ Real.exp z * Real.exp (-z) :=
            mul_le_mul_of_nonneg_left h1m_pow (Real.exp_pos z).le
        _ = 1 := by rw [← Real.exp_add]; simp
    have hrew : (1 - z / (N : ℝ)) = ((N : ℝ) - z) / (N : ℝ) := by field_simp
    have hpow_pos : 0 < (1 - z / (N : ℝ)) ^ N := pow_pos h1m_pos N
    rw [hrew, div_pow] at hprod_le hpow_pos
    rw [div_pow, le_div_iff₀ (pow_pos hNmz_pos N)]
    have hmul := mul_le_mul_of_nonneg_right hprod_le (pow_nonneg hN_pos.le N)
    calc Real.exp z * ((N : ℝ) - z) ^ N
        = Real.exp z * (((N : ℝ) - z) ^ N / (N : ℝ) ^ N) * (N : ℝ) ^ N := by
          field_simp [pow_ne_zero N hN_ne]
      _ ≤ 1 * (N : ℝ) ^ N := hmul
      _ = (N : ℝ) ^ N := one_mul _
  have hN2mz2_pos : 0 < (N : ℝ) ^ 2 - z ^ 2 := by nlinarith
  have hN2mz2_ge : 2 * (N : ℝ) * z ^ 2 ≤ (N : ℝ) ^ 2 - z ^ 2 := by
    have : (3 * z ^ 2 + 1) * (N : ℝ) ≤ (N : ℝ) ^ 2 := by nlinarith
    nlinarith
  have hfrac_le : z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2) ≤ 1 / (2 * (N : ℝ)) := by
    rw [div_le_div_iff₀ hN2mz2_pos (by positivity)]
    nlinarith
  have hcorr_pow : (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) ^ N ≤ 2 := by
    calc (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) ^ N
        ≤ (1 + 1 / (2 * (N : ℝ))) ^ N := by
          refine pow_le_pow_left₀ (by positivity) (by linarith) N
      _ ≤ (Real.exp (1 / (2 * (N : ℝ)))) ^ N := by
          refine pow_le_pow_left₀ (by positivity) ?_ N
          linarith [Real.add_one_le_exp (1 / (2 * (N : ℝ)))]
      _ = Real.exp ((N : ℝ) * (1 / (2 * (N : ℝ)))) := (Real.exp_nat_mul _ N).symm
      _ = Real.exp (1 / 2 : ℝ) := by congr 1; field_simp
      _ ≤ 2 := exp_half_le_two
  have hdecomp : (N : ℝ) / ((N : ℝ) - z) =
      (1 + z / (N : ℝ)) * (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) := by
    have hne1 : (N : ℝ) - z ≠ 0 := hNmz_pos.ne'
    have hne2 : (N : ℝ) ^ 2 - z ^ 2 ≠ 0 := hN2mz2_pos.ne'
    field_simp
    ring
  have h3 : Real.exp z ≤ 2 * (1 + z / (N : ℝ)) ^ N := by
    calc Real.exp z ≤ ((N : ℝ) / ((N : ℝ) - z)) ^ N := hexp_le_inv
      _ = (1 + z / (N : ℝ)) ^ N * (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) ^ N := by
          rw [hdecomp, mul_pow]
      _ ≤ (1 + z / (N : ℝ)) ^ N * 2 :=
          mul_le_mul_of_nonneg_left hcorr_pow (by positivity)
      _ = 2 * (1 + z / (N : ℝ)) ^ N := mul_comm _ _
  exact ⟨h1, h2, h3⟩

theorem I_h_bounds {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1) :
    1 ≤ I_h h x ∧ I_h h x ≤ 2 ∧ 0 ≤ u_search h x ∧ u_search h x ≤ 1 ∧
    0 ≤ q_search h x ∧ q_search h x ≤ 1 + u_search h x := by
  have h1mh2 : 0 < 1 - h ^ 2 := by nlinarith
  have hu_eq : u_search h x = (x - h) ^ 2 / (1 - h ^ 2) := by
    unfold u_search I_h; field_simp; ring
  have hu0 : 0 ≤ u_search h x := by rw [hu_eq]; positivity
  have hI_ge : 1 ≤ I_h h x := by unfold u_search at hu0; linarith
  have h2mI : 0 ≤ 2 - I_h h x := by
    have hrew : 2 - I_h h x = ((1 - x ^ 2) + 2 * h * (x - h)) / (1 - h ^ 2) := by
      unfold I_h; field_simp; ring
    rw [hrew]
    refine div_nonneg ?_ h1mh2.le
    nlinarith
  have hI_le : I_h h x ≤ 2 := by linarith
  have hu_le : u_search h x ≤ 1 := by unfold u_search; linarith
  have hq_eq : q_search h x = (1 - h * x) ^ 2 / (1 - h ^ 2) := by
    unfold q_search I_h; field_simp; ring
  have hq0 : 0 ≤ q_search h x := by rw [hq_eq]; positivity
  have hq_le : q_search h x ≤ 1 + u_search h x := by
    unfold q_search u_search
    nlinarith
  exact ⟨hI_ge, hI_le, hu0, hu_le, hq0, hq_le⟩

/-! ### 2. Statement helpers and footprint for `paramStmt` -/

theorem exec_wSet_lit {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (t : ℕ) (idx : ℤ) (valE : IntExpr) (C : ℕ)
    (hcost : (evalIntExpr inp.toWordView 0 mem.words valE).2.1 + 2 ≤ C) :
    ExecStmt inp (.writeWordHeap t (.lit idx) valE) mem
      (wWrite mem t idx (evalIntExpr inp.toWordView 0 mem.words valE).1) C := by
  rcases h : evalIntExpr inp.toWordView 0 mem.words valE with ⟨val, u₂, b₂⟩
  have hcost' : u₂ + 2 ≤ C := by simpa [h] using hcost
  exact ExecStmt.writeWordHeap inp hc t (.lit idx) valE (u₁ := 1) (b₁ := intBitLength idx) rfl h (by omega)

theorem exec_rSet_lit {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (t : ℕ) (idx : ℤ) (valE : RealExpr) (C : ℕ)
    (hcost : (evalRealExpr inp 0 mem valE).2 + 2 ≤ C) :
    ExecStmt inp (.writeRealHeap t (.lit idx) valE) mem
      (rWrite mem t idx (evalRealExpr inp 0 mem valE).1) C := by
  rcases h : evalRealExpr inp 0 mem valE with ⟨val, u₂⟩
  have hcost' : u₂ + 2 ≤ C := by simpa [h] using hcost
  exact ExecStmt.writeRealHeap inp hc t (.lit idx) valE (u₁ := 1) (b₁ := intBitLength idx) rfl h (by omega)

def paramWordList : List RAMCellLoc :=
  [.heap 0 0,
   .heap 1 0, .heap 1 1, .heap 1 2, .heap 1 3, .heap 1 4,
   .heap 11 0, .heap 11 1, .heap 11 2, .heap 11 3, .heap 11 4, .heap 11 5, .heap 11 6]

def paramRealList : List RAMCellLoc :=
  [.heap 1 0, .heap 1 1,
   .heap 17 0, .heap 17 1, .heap 17 2, .heap 17 3, .heap 17 4, .heap 17 5]

def InParamFootprint (mem : ArithRAMMemory) : Prop :=
  mem.words.live ⊆ paramWordList.toFinset ∧ mem.reals.live ⊆ paramRealList.toFinset

theorem inParamFootprint_empty : InParamFootprint ArithRAMMemory.empty := by
  exact ⟨Finset.empty_subset _, Finset.empty_subset _⟩

theorem inParamFootprint_wWrite {mem : ArithRAMMemory} (h : InParamFootprint mem)
    {t : ℕ} {idx v : ℤ} (hmem : RAMCellLoc.heap t idx ∈ paramWordList) :
    InParamFootprint (wWrite mem t idx v) := by
  refine ⟨?_, h.2⟩
  unfold wWrite WordStore.write
  exact Finset.insert_subset (List.mem_toFinset.mpr hmem) h.1

theorem inParamFootprint_rWrite {mem : ArithRAMMemory} (h : InParamFootprint mem)
    {t : ℕ} {idx : ℤ} {v : ℝ} (hmem : RAMCellLoc.heap t idx ∈ paramRealList) :
    InParamFootprint (rWrite mem t idx v) := by
  refine ⟨h.1, ?_⟩
  unfold rWrite RealStore.write
  exact Finset.insert_subset (List.mem_toFinset.mpr hmem) h.2

theorem cellCount_le_of_inParamFootprint {mem : ArithRAMMemory} (h : InParamFootprint mem) :
    mem.cellCount ≤ 21 := by
  have hc := cellCount_le_of_subset h.1 h.2
  have hw : paramWordList.toFinset.card ≤ 13 := by decide
  have hr : paramRealList.toFinset.card ≤ 8 := by decide
  omega

/-! ### 3. Reusable subroutines: `pow1PlusZStmt` and `boundedDoublingStmt` -/

/-- Computes `(1 + z / N)^N` into real `.heap 17 1`, reading `z` from real `.heap 17 0`
and `N` from word `.heap 11 2`. -/
def pow1PlusZStmt : ArithRAMStmt :=
  .seq (.writeRealHeap 17 (.lit 1) (.ofInt (.lit 1)))
    (.repeatN (.readHeap 11 (.lit 2))
      (.writeRealHeap 17 (.lit 1)
        (.mul (.readRealHeap 17 (.lit 1))
          (.add (.ofInt (.lit 1))
            (.div (.readRealHeap 17 (.lit 0)) (.ofInt (.readHeap 11 (.lit 2))))))))

theorem exec_pow1PlusZStmt {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (hfp : InParamFootprint mem) {N : ℕ}
    (hN : wRead mem 11 2 = (N : ℤ)) :
    let z := rRead mem 17 0
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp pow1PlusZStmt mem mem' (20 + N * 20) ∧
      InParamFootprint mem' ∧
      (∀ t i, wRead mem' t i = wRead mem t i) ∧
      (∀ t i, (t ≠ 17 ∨ i ≠ 1) → rRead mem' t i = rRead mem t i) ∧
      rRead mem' 17 1 = (1 + z / (N : ℝ)) ^ N := by
  intro z
  let m₀ := rWrite mem 17 1 1
  have hs₁ : ExecStmt inp (.writeRealHeap 17 (.lit 1) (.ofInt (.lit 1))) mem m₀ 10 := by
    simpa [m₀, evalRealExpr, evalIntExpr] using
      exec_rSet_lit inp hc 17 1 (.ofInt (.lit 1)) 10 (by simp [evalRealExpr, evalIntExpr])
  have hfp₀ : InParamFootprint m₀ := inParamFootprint_rWrite hfp (by decide)
  let Inv : ℕ → ArithRAMMemory → Prop := fun i m =>
    InParamFootprint m ∧
    (∀ t idx, wRead m t idx = wRead mem t idx) ∧
    (∀ t idx, (t ≠ 17 ∨ idx ≠ 1) → rRead m t idx = rRead mem t idx) ∧
    rRead m 17 1 = (1 + z / (N : ℝ)) ^ i
  have hInv₀ : Inv 0 m₀ := by
    refine ⟨hfp₀, fun _ _ => rfl, fun t idx hne => rRead_rWrite_of_ne mem 1 hne, ?_⟩
    simp [m₀]
  have hw_N₀ : m₀.words.read (.heap 11 2) = (N : ℤ) := hN
  have hcnt : evalIntExpr inp.toWordView 0 m₀.words (.readHeap 11 (.lit 2)) =
      ((N : ℤ), 2, (evalIntExpr inp.toWordView 0 m₀.words (.readHeap 11 (.lit 2))).2.2) := by
    simp [evalIntExpr, hw_N₀]
  rcases ExecStmt.repeatN_nat N 10 20 Inv hs₁.2.1 hInv₀ hcnt (by omega)
    (fun i _ m hcm ⟨hfpm, hwm, hrm, hval⟩ => by
      have hstep_e := exec_rSet_lit inp hcm 17 1
        (.mul (.readRealHeap 17 (.lit 1))
          (.add (.ofInt (.lit 1))
            (.div (.readRealHeap 17 (.lit 0)) (.ofInt (.readHeap 11 (.lit 2)))))) 20
        (by simp [evalRealExpr, evalIntExpr])
      refine ⟨_, hstep_e, inParamFootprint_rWrite hfpm (by decide),
        fun t idx => by simp [hwm],
        fun t idx hne => by rw [rRead_rWrite_of_ne _ _ hne]; exact hrm t idx hne, ?_⟩
      have hz_eq : m.reals.read (.heap 17 0) = z := hrm 17 0 (Or.inr (by decide))
      have hN_eq : m.words.read (.heap 11 2) = (N : ℤ) := (hwm 11 2).trans hN
      have hcur_eq : m.reals.read (.heap 17 1) = (1 + z / (N : ℝ)) ^ i := hval
      simp [evalRealExpr, evalIntExpr, hz_eq, hN_eq, hcur_eq, pow_succ]) with
    ⟨mem', ⟨hfp', hw', hr', hpow'⟩, hrep⟩
  refine ⟨mem', (ExecStmt.seq hs₁ hrep).mono_cost (by omega), hfp', hw', hr', hpow'⟩

/-- Bounded doubling into word `.heap tbl idx` starting from `initVal ≥ 1`, comparing against
real `.heap 17 rIdx`, for `B` steps read from word `.heap 11 6`. -/
def boundedDoublingStmt (tbl : ℕ) (idx : ℤ) (initVal : ℤ) (rIdx : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap tbl (.lit idx) (.lit initVal))
    (.repeatN (.readHeap 11 (.lit 6))
      (.ite (.realLt (.ofInt (.readHeap tbl (.lit idx))) (.readRealHeap 17 (.lit rIdx)))
        (.writeWordHeap tbl (.lit idx) (.mul (.lit 2) (.readHeap tbl (.lit idx))))
        .skip))

theorem exec_boundedDoublingStmt {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (hfp : InParamFootprint mem)
    (tbl : ℕ) (idx : ℤ) (htbl_ne : tbl ≠ 11 ∨ idx ≠ 6)
    (hmem_loc : RAMCellLoc.heap tbl idx ∈ paramWordList)
    (initNat : ℕ) (hinit : 1 ≤ initNat) (rIdx : ℤ)
    {B : ℕ} (hB : wRead mem 11 6 = (B : ℤ))
    (htarget_ub : rRead mem 17 rIdx ≤ (initNat : ℝ) * (2 : ℝ) ^ B) :
    let target := rRead mem 17 rIdx
    ∃ (mem' : ArithRAMMemory) (val : ℕ),
      ExecStmt inp (boundedDoublingStmt tbl idx (initNat : ℤ) rIdx) mem mem' (20 + B * 20) ∧
      InParamFootprint mem' ∧
      initNat ≤ val ∧
      target ≤ (val : ℝ) ∧
      (val : ℝ) ≤ max (initNat : ℝ) (2 * target) ∧
      wRead mem' tbl idx = (val : ℤ) ∧
      (∀ t' i', (t' ≠ tbl ∨ i' ≠ idx) → wRead mem' t' i' = wRead mem t' i') ∧
      (∀ t' i', rRead mem' t' i' = rRead mem t' i') := by
  intro target
  let m₀ := wWrite mem tbl idx (initNat : ℤ)
  have hs₁ : ExecStmt inp (.writeWordHeap tbl (.lit idx) (.lit (initNat : ℤ))) mem m₀ 10 := by
    simpa [m₀, evalIntExpr] using
      exec_wSet_lit inp hc tbl idx (.lit (initNat : ℤ)) 10 (by simp [evalIntExpr])
  have hfp₀ : InParamFootprint m₀ := inParamFootprint_wWrite hfp hmem_loc
  let Inv : ℕ → ArithRAMMemory → Prop := fun i m =>
    InParamFootprint m ∧
    (∀ t' i', (t' ≠ tbl ∨ i' ≠ idx) → wRead m t' i' = wRead mem t' i') ∧
    (∀ t' i', rRead m t' i' = rRead mem t' i') ∧
    ∃ v : ℕ, initNat ≤ v ∧
      wRead m tbl idx = (v : ℤ) ∧
      (v : ℝ) ≤ max (initNat : ℝ) (2 * target) ∧
      min target ((initNat : ℝ) * (2 : ℝ) ^ i) ≤ (v : ℝ)
  have hInv₀ : Inv 0 m₀ := by
    refine ⟨hfp₀, fun t' i' hne => wRead_wWrite_of_ne mem _ hne, fun _ _ => rfl,
      initNat, le_rfl, by simp [m₀], le_max_left _ _, ?_⟩
    simp
  have hB₀ : m₀.words.read (.heap 11 6) = (B : ℤ) := by
    have := wRead_wWrite_of_ne mem (initNat : ℤ) (t₁ := 11) (i₁ := 6) (by
      rcases htbl_ne with h1 | h2
      · exact Or.inl h1.symm
      · exact Or.inr h2.symm)
    exact this.trans hB
  have hcnt : evalIntExpr inp.toWordView 0 m₀.words (.readHeap 11 (.lit 6)) =
      ((B : ℤ), 2, (evalIntExpr inp.toWordView 0 m₀.words (.readHeap 11 (.lit 6))).2.2) := by
    simp [evalIntExpr, hB₀]
  let cond : ArithCondExpr :=
    .realLt (.ofInt (.readHeap tbl (.lit idx))) (.readRealHeap 17 (.lit rIdx))
  let dblBody : ArithRAMStmt :=
    .ite cond (.writeWordHeap tbl (.lit idx) (.mul (.lit 2) (.readHeap tbl (.lit idx)))) .skip
  rcases ExecStmt.repeatN_nat (body := dblBody) B 10 20 Inv hs₁.2.1 hInv₀ hcnt (by omega)
    (fun i _ m hcm ⟨hfpm, hwm, hrm, v, hv_ge, hv_eq, hv_ub, hv_lb⟩ => by
      have htar_m : m.reals.read (.heap 17 rIdx) = target := hrm 17 rIdx
      have hv_m : m.words.read (.heap tbl idx) = (v : ℤ) := hv_eq
      by_cases hlt : (v : ℝ) < target
      · have hcond : evalArithCond inp 0 m cond = (true, 6) := by
          simp [cond, evalArithCond, evalRealExpr, evalIntExpr, hv_m, htar_m, hlt]
        have hw_step := exec_wSet_lit inp hcm tbl idx
          (.mul (.lit 2) (.readHeap tbl (.lit idx))) 10 (by simp [evalIntExpr])
        refine ⟨_, (ExecStmt.ite_true hcond (C_c := 10) (by omega) hw_step).mono_cost (by omega), inParamFootprint_wWrite hfpm hmem_loc,
          fun t' i' hne => (wRead_wWrite_of_ne _ _ hne).trans (hwm t' i' hne),
          fun t' i' => hrm t' i', 2 * v, by omega, ?_, ?_, ?_⟩
        · simp [evalIntExpr, hv_m]
        · push_cast
          exact (mul_le_mul_of_nonneg_left hlt.le (by norm_num)).trans (le_max_right _ _)
        · push_cast
          have hpow_lt : (initNat : ℝ) * (2 : ℝ) ^ i ≤ (v : ℝ) := by
            by_cases hcmp : target ≤ (initNat : ℝ) * (2 : ℝ) ^ i
            · have hm : min target ((initNat : ℝ) * (2 : ℝ) ^ i) = target := min_eq_left hcmp
              linarith [hv_lb]
            · push_neg at hcmp
              have hm : min target ((initNat : ℝ) * (2 : ℝ) ^ i) = (initNat : ℝ) * (2 : ℝ) ^ i :=
                min_eq_right hcmp.le
              linarith [hv_lb]
          have hpow_succ : (initNat : ℝ) * (2 : ℝ) ^ (i + 1) ≤ 2 * (v : ℝ) := by
            rw [pow_succ]; linarith
          exact (min_le_right _ _).trans hpow_succ
      · have hge : target ≤ (v : ℝ) := not_lt.mp hlt
        have hcond : evalArithCond inp 0 m cond = (false, 6) := by
          simp [cond, evalArithCond, evalRealExpr, evalIntExpr, hv_m, htar_m, hlt]
        refine ⟨m, (ExecStmt.ite_false hcond (C_c := 10) (by omega)
          (ExecStmt.skip inp hcm)).mono_cost (by omega), hfpm, hwm, hrm, v, hv_ge, hv_eq, hv_ub,
          (min_le_left _ _).trans hge⟩) with
    ⟨mem', ⟨hfp', hw', hr', val, hval_ge, hval_eq, hval_ub, hval_lb⟩, hrep⟩
  have hmin_eq : min target ((initNat : ℝ) * (2 : ℝ) ^ B) = target := min_eq_left htarget_ub
  rw [hmin_eq] at hval_lb
  refine ⟨mem', val, (ExecStmt.seq hs₁ hrep).mono_cost (by omega), hfp',
    hval_ge, hval_lb, hval_ub, hval_eq, hw', hr'⟩

/-! ### 4. Complete `paramStmt` definition and correctness theorem -/

/-- Step P1: Store `m` at `.heap 1 0` and compute `b = natBitLength m` at `.heap 11 1`. -/
def stepP1Stmt : ArithRAMStmt :=
  .seq (.writeWordHeap 1 (.lit 0) (.intParam (.lit 0)))
    (.seq (.writeWordHeap 11 (.lit 0) (.readHeap 1 (.lit 0)))
      (.seq (.writeWordHeap 11 (.lit 1) (.lit 0))
        (.whileLoop (.intLt (.lit 0) (.readHeap 11 (.lit 0)))
          (.seq
            (.writeWordHeap 11 (.lit 0) (.div (.readHeap 11 (.lit 0)) (.lit 2)))
            (.writeWordHeap 11 (.lit 1) (.add (.readHeap 11 (.lit 1)) (.lit 1)))))))

/-- Expression `(b + 2)^2` reading `b` from `.heap 11 1`. -/
def bPlus2SqExpr : IntExpr :=
  let bp2 := IntExpr.add (.readHeap 11 (.lit 1)) (.lit 2)
  .mul bp2 bp2

/-- Step P2: Compute `N`, `denom = ℓ * b`, `B_max`, and step `t` until `F_u ≥ 2 * m`. -/
def stepP2Stmt (ℓ C_base : ℕ) : ArithRAMStmt :=
  let bp2sq := bPlus2SqExpr
  let bp2pow4 := IntExpr.mul bp2sq bp2sq
  let nExpr := IntExpr.add (.mul (.lit ((3 * ℓ * ℓ : ℕ) : ℤ)) bp2pow4) (.lit 1)
  let denomExpr := IntExpr.mul (.lit (ℓ : ℤ)) (.readHeap 11 (.lit 1))
  let bMaxExpr :=
    IntExpr.mul (.lit ((ℓ + 1 : ℕ) : ℤ))
      (.add (.lit ((C_base + 2 : ℕ) : ℤ)) (.mul (.lit 3) bp2sq))
  let kMaxExpr :=
    IntExpr.mul (.mul (.lit (ℓ : ℤ)) (.readHeap 11 (.lit 1)))
      (.add (.readHeap 11 (.lit 1)) (.lit 1))
  let zFromT : RealExpr :=
    .div (.mul (.ofInt (.lit (ℓ : ℤ)))
      (.mul (.readRealHeap 1 (.lit 0)) (.readRealHeap 1 (.lit 0)))) (.ofInt (.lit 2))
  .seq (.writeWordHeap 11 (.lit 2) nExpr)
    (.seq (.writeWordHeap 11 (.lit 3) denomExpr)
      (.seq (.writeWordHeap 11 (.lit 6) bMaxExpr)
        (.seq (.writeWordHeap 11 (.lit 4) (.lit 0))
          (.seq (.writeRealHeap 1 (.lit 0) (.ofInt (.lit 1)))
            (.seq (.writeRealHeap 17 (.lit 0) zFromT)
              (.seq pow1PlusZStmt
                (.seq (.writeRealHeap 17 (.lit 2) (.readRealHeap 17 (.lit 1)))
                  (.repeatN kMaxExpr
                    (.ite
                      (.realLt (.readRealHeap 17 (.lit 2))
                        (.mul (.ofInt (.lit 2)) (.ofInt (.readHeap 1 (.lit 0)))))
                      (.seq (.writeWordHeap 11 (.lit 4) (.add (.readHeap 11 (.lit 4)) (.lit 1)))
                        (.seq
                          (.writeRealHeap 1 (.lit 0)
                            (.add (.ofInt (.lit 1))
                              (.div (.ofInt (.readHeap 11 (.lit 4)))
                                (.ofInt (.readHeap 11 (.lit 3))))))
                          (.seq (.writeRealHeap 17 (.lit 0) zFromT)
                            (.seq pow1PlusZStmt
                              (.writeRealHeap 17 (.lit 2) (.readRealHeap 17 (.lit 1)))))))
                      .skip)))))))))

/-- Step P3: Compute `x * t`, `R_1`, `M_0`, `K`, `A`, `Cap_u`, `Cap_q`, and output `K` at `.heap 0 0`. -/
def stepP3Stmt (ℓ C_base : ℕ) : ArithRAMStmt :=
  let hE := RealExpr.extraReal (.lit 0)
  let xE := RealExpr.extraReal (.lit 1)
  let tE := RealExpr.readRealHeap 1 (.lit 0)
  let iExpr : RealExpr :=
    .div
      (.sub (.add (.ofInt (.lit 1)) (.mul xE xE)) (.mul (.mul (.ofInt (.lit 2)) hE) xE))
      (.sub (.ofInt (.lit 1)) (.mul hE hE))
  let z1Expr : RealExpr := .div (.mul iExpr (.mul tE tE)) (.ofInt (.lit 2))
  let r1Expr : RealExpr :=
    .mul (.mul (.ofInt (.lit (C_base : ℤ))) (.mul tE tE)) (.readRealHeap 17 (.lit 1))
  let zqExpr : RealExpr :=
    .div (.mul (.ofInt (.lit (ℓ : ℤ))) (.mul (.mul xE xE) (.mul tE tE))) (.ofInt (.lit 2))
  .seq (.writeRealHeap 1 (.lit 1) (.mul xE tE))
    (.seq (.writeRealHeap 17 (.lit 0) z1Expr)
      (.seq pow1PlusZStmt
        (.seq (.writeRealHeap 17 (.lit 3) r1Expr)
          (.seq (boundedDoublingStmt 1 1 1 3)
            (.seq (.writeWordHeap 1 (.lit 2) (.mul (.lit (ℓ : ℤ)) (.readHeap 1 (.lit 1))))
              (.seq (.writeWordHeap 0 (.lit 0) (.readHeap 1 (.lit 2)))
                (.seq (.writeWordHeap 11 (.lit 5) (.lit 1))
                  (.seq
                    (.repeatN (.lit (ℓ : ℤ))
                      (.writeWordHeap 11 (.lit 5)
                        (.mul (.readHeap 11 (.lit 5)) (.readHeap 1 (.lit 1)))))
                    (.seq
                      (.writeRealHeap 17 (.lit 4)
                        (.mul (.ofInt (.lit 100))
                          (.add (.div (.ofInt (.readHeap 11 (.lit 5))) (.readRealHeap 17 (.lit 2)))
                            (.ofInt (.lit 1)))))
                      (.seq (boundedDoublingStmt 1 3 100 4)
                        (.seq (.writeRealHeap 17 (.lit 0) zqExpr)
                          (.seq pow1PlusZStmt
                            (.seq
                              (.writeRealHeap 17 (.lit 5)
                                (.mul (.ofInt (.lit 100))
                                  (.add (.div (.ofInt (.readHeap 11 (.lit 5)))
                                      (.readRealHeap 17 (.lit 1)))
                                    (.ofInt (.lit 1)))))
                              (boundedDoublingStmt 1 4 100 5))))))))))))))

/-- Complete parameter computation program `paramStmt`. -/
def buildParamStmt (ℓ C_base : ℕ) : ArithRAMStmt :=
  .seq stepP1Stmt (.seq (stepP2Stmt ℓ C_base) (stepP3Stmt ℓ C_base))

theorem exec_stepP1Stmt {d : ℕ} (m : ℕ) (hm : 1 ≤ m) (h x : ℝ) :
    let inp : ArithRAMInput d :=
      { intParams := [(m : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0, extraReals := [h, x] }
    let L : ℕ := natBitLength m
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp stepP1Stmt ArithRAMMemory.empty mem₁ (40 + 30 * L) ∧
      InParamFootprint mem₁ ∧
      wRead mem₁ 1 0 = (m : ℤ) ∧
      wRead mem₁ 11 1 = (L : ℤ) := by
  intro inp L
  have hc₀ := cleanMem_empty
  have hfp₀ := inParamFootprint_empty
  have hs1 := exec_wSet_lit inp hc₀ 1 0 (.intParam (.lit 0)) 10 (by simp [evalIntExpr])
  let m1 := wWrite ArithRAMMemory.empty 1 0 (m : ℤ)
  have hs1' : ExecStmt inp (.writeWordHeap 1 (.lit 0) (.intParam (.lit 0))) ArithRAMMemory.empty m1 10 := by
    simpa [m1, inp, evalIntExpr, listGetIntD] using hs1
  have hfp1 : InParamFootprint m1 := inParamFootprint_wWrite hfp₀ (by decide)
  let m2 := wWrite m1 11 0 (m : ℤ)
  have hs2 : ExecStmt inp (.writeWordHeap 11 (.lit 0) (.readHeap 1 (.lit 0))) m1 m2 10 := by
    have := exec_wSet_lit inp hs1'.2.1 11 0 (.readHeap 1 (.lit 0)) 10 (by simp [evalIntExpr])
    have hw : m1.words.read (.heap 1 0) = (m : ℤ) := wRead_wWrite_self _ _ _ _
    simpa [m2, evalIntExpr, hw] using this
  have hfp2 : InParamFootprint m2 := inParamFootprint_wWrite hfp1 (by decide)
  let m3 := wWrite m2 11 1 0
  have hs3 : ExecStmt inp (.writeWordHeap 11 (.lit 1) (.lit 0)) m2 m3 10 := by
    simpa [m3, evalIntExpr] using exec_wSet_lit inp hs2.2.1 11 1 (.lit 0) 10 (by simp [evalIntExpr])
  have hfp3 : InParamFootprint m3 := inParamFootprint_wWrite hfp2 (by decide)

  let cond : ArithCondExpr := .intLt (.lit 0) (.readHeap 11 (.lit 0))
  let Inv : ℕ → ArithRAMMemory → Prop := fun i mem =>
    InParamFootprint mem ∧
    wRead mem 1 0 = (m : ℤ) ∧
    wRead mem 11 0 = ((m / 2 ^ i : ℕ) : ℤ) ∧
    wRead mem 11 1 = (i : ℤ)
  have hInv₀ : Inv 0 m3 := by
    refine ⟨hfp3, ?_, ?_, ?_⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]; simp
    · simp [m3]
  rcases ExecStmt.whileLoop_nat L 10 20 Inv hs3.2.1 hInv₀
    (fun i hi cur hcm ⟨hfpm, hwm, hcur, hb⟩ => by
      have hpow_le : 2 ^ i ≤ m := by
        have hi_le : i ≤ Nat.log 2 m := by unfold L natBitLength at hi; omega
        exact (Nat.pow_le_pow_right (by decide) hi_le).trans (Nat.pow_log_le_self 2 (by omega))
      have hdiv_pos : 0 < m / 2 ^ i := Nat.div_pos hpow_le (by positivity)
      have hcur_r : cur.words.read (.heap 11 0) = ((m / 2 ^ i : ℕ) : ℤ) := hcur
      have hcond : evalArithCond inp 0 cur cond = (true, 4) := by
        have hpos_z : (0 : ℤ) < ((m / 2 ^ i : ℕ) : ℤ) := by exact_mod_cast hdiv_pos
        dsimp [cond, evalArithCond, evalIntExpr]
        rw [hcur_r, decide_eq_true hpos_z]
      have hb1 := exec_wSet_lit inp hcm 11 0 (.div (.readHeap 11 (.lit 0)) (.lit 2)) 10
        (by simp [evalIntExpr])
      have hb2 := exec_wSet_lit inp hb1.2.1 11 1 (.add (.readHeap 11 (.lit 1)) (.lit 1)) 10
        (by simp [evalIntExpr])
      refine ⟨⟨4, hcond, by omega⟩, ⟨_, ExecStmt.seq hb1 hb2, ?_⟩⟩
      have hdiv_step : (((m / 2 ^ i : ℕ) : ℤ) / 2) = ((m / 2 ^ (i + 1) : ℕ) : ℤ) := by
        have hnat : (m / 2 ^ i) / 2 = m / 2 ^ (i + 1) := by
          rw [Nat.div_div_eq_div_mul, ← pow_succ]
        rw [← hnat]
        exact_mod_cast (Int.natCast_div (m / 2 ^ i) 2)
      refine ⟨inParamFootprint_wWrite (inParamFootprint_wWrite hfpm (by decide)) (by decide),
        ?_, ?_, ?_⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        exact hwm
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]
        simpa [evalIntExpr, hcur_r] using hdiv_step
      · rw [wRead_wWrite_self]
        dsimp only [evalIntExpr]
        change wRead (wWrite cur 11 0 (cur.words.read (.heap 11 0) / 2)) 11 1 + 1 = ↑(i + 1)
        rw [wRead_wWrite_of_ne cur _ (Or.inr (by decide)), hb]
        push_cast; ring)
    (fun cur _ ⟨_, _, hcur, _⟩ => by
      have hlt : m < 2 ^ L := Nat.lt_pow_succ_log_self (by decide) m
      have hdiv0 : m / 2 ^ L = 0 := Nat.div_eq_of_lt hlt
      have hcur_r : cur.words.read (.heap 11 0) = 0 := by simpa [hdiv0] using hcur
      exact ⟨4, by simp [cond, evalArithCond, evalIntExpr, hcur_r], by omega⟩) with
    ⟨mem₁, ⟨hfp₁, hwm₁, _, hb₁⟩, hwhile⟩
  have htot : ExecStmt inp stepP1Stmt ArithRAMMemory.empty mem₁ (40 + 30 * L) := by
    unfold stepP1Stmt
    exact (ExecStmt.seq hs1' (ExecStmt.seq hs2 (ExecStmt.seq hs3 hwhile))).mono_cost (by omega)
  exact ⟨mem₁, htot, hfp₁, hwm₁, hb₁⟩

theorem exec_stepP2Stmt {d : ℕ} (ℓ C_base : ℕ) (hℓ : 1 ≤ ℓ)
    (m : ℕ) (hm : 1 ≤ m) (h x : ℝ) {mem₁ : ArithRAMMemory}
    (hc₁ : CleanMem mem₁) (hfp₁ : InParamFootprint mem₁)
    (hwm₁ : wRead mem₁ 1 0 = (m : ℤ))
    (hwb₁ : wRead mem₁ 11 1 = ((natBitLength m) : ℤ)) :
    let inp : ArithRAMInput d :=
      { intParams := [(m : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0, extraReals := [h, x] }
    let L : ℕ := natBitLength m
    let N : ℕ := 3 * ℓ * ℓ * (L + 2) ^ 4 + 1
    let B_max : ℕ := (ℓ + 1) * (C_base + 2 + 3 * (L + 2) ^ 2)
    let K_max : ℕ := ℓ * L * (L + 1)
    let C_scale : ℝ := max (Real.exp ((ℓ : ℝ) / 2)) (4 * Real.exp 3)
    ∃ (mem₂ : ArithRAMMemory) (t F_u : ℝ),
      ExecStmt inp (stepP2Stmt ℓ C_base) mem₁ mem₂
        (200 + N * 20 + K_max * (120 + N * 20)) ∧
      InParamFootprint mem₂ ∧
      wRead mem₂ 1 0 = (m : ℤ) ∧
      wRead mem₂ 11 1 = (L : ℤ) ∧
      wRead mem₂ 11 2 = (N : ℤ) ∧
      wRead mem₂ 11 6 = (B_max : ℤ) ∧
      rRead mem₂ 1 0 = t ∧
      rRead mem₂ 17 2 = F_u ∧
      1 ≤ t ∧ t ≤ (L + 2 : ℝ) ∧
      1 ≤ F_u ∧
      2 * (m : ℝ) ≤ F_u ∧
      F_u ≤ Real.exp ((ℓ : ℝ) * t ^ 2 / 2) ∧
      Real.exp ((ℓ : ℝ) * t ^ 2 / 2) ≤ C_scale * (m : ℝ) := by
  intro inp L N B_max K_max C_scale
  have hL_pos : 1 ≤ L := by unfold L natBitLength; omega
  let denom : ℕ := ℓ * L
  have hdenom_pos : 1 ≤ denom := Nat.mul_pos hℓ hL_pos
  let tOf : ℕ → ℝ := fun k => 1 + (k : ℝ) / (denom : ℝ)
  let zOf : ℕ → ℝ := fun k => (ℓ : ℝ) * (tOf k * tOf k) / 2
  let FOf : ℕ → ℝ := fun k => (1 + zOf k / (N : ℝ)) ^ N

  -- Execute preamble writes 1..8
  have s1 := exec_wSet_lit inp hc₁ 11 2
    (.add (.mul (.lit ((3 * ℓ * ℓ : ℕ) : ℤ)) (.mul bPlus2SqExpr bPlus2SqExpr)) (.lit 1)) 30
    (by simp [bPlus2SqExpr, evalIntExpr])
  let ma1 := wWrite mem₁ 11 2 (N : ℤ)
  have hm1_eq : wWrite mem₁ 11 2
      (evalIntExpr inp.toWordView 0 mem₁.words
        (.add (.mul (.lit ((3 * ℓ * ℓ : ℕ) : ℤ)) (.mul bPlus2SqExpr bPlus2SqExpr)) (.lit 1))).1 = ma1 := by
    congr 1
    have hb : mem₁.words.read (.heap 11 1) = (L : ℤ) := hwb₁
    simp only [bPlus2SqExpr, evalIntExpr, hb, N]
    push_cast; ring
  rw [hm1_eq] at s1
  have hfp_a1 : InParamFootprint ma1 := inParamFootprint_wWrite hfp₁ (by decide)

  have s2 := exec_wSet_lit inp s1.2.1 11 3
    (.mul (.lit (ℓ : ℤ)) (.readHeap 11 (.lit 1))) 10 (by simp [evalIntExpr])
  let ma2 := wWrite ma1 11 3 (denom : ℤ)
  have hm2_eq : wWrite ma1 11 3
      (evalIntExpr inp.toWordView 0 ma1.words (.mul (.lit (ℓ : ℤ)) (.readHeap 11 (.lit 1)))).1 = ma2 := by
    congr 1
    have hb : ma1.words.read (.heap 11 1) = (L : ℤ) :=
      (wRead_wWrite_of_ne mem₁ _ (Or.inr (by decide))).trans hwb₁
    simp only [evalIntExpr, hb, denom]; push_cast; ring
  rw [hm2_eq] at s2
  have hfp_a2 : InParamFootprint ma2 := inParamFootprint_wWrite hfp_a1 (by decide)

  have s3 := exec_wSet_lit inp s2.2.1 11 6
    (.mul (.lit ((ℓ + 1 : ℕ) : ℤ))
      (.add (.lit ((C_base + 2 : ℕ) : ℤ)) (.mul (.lit 3) bPlus2SqExpr))) 30
    (by simp [bPlus2SqExpr, evalIntExpr])
  let ma3 := wWrite ma2 11 6 (B_max : ℤ)
  have hm3_eq : wWrite ma2 11 6
      (evalIntExpr inp.toWordView 0 ma2.words
        (.mul (.lit ((ℓ + 1 : ℕ) : ℤ))
          (.add (.lit ((C_base + 2 : ℕ) : ℤ)) (.mul (.lit 3) bPlus2SqExpr)))).1 = ma3 := by
    congr 1
    have hb : ma2.words.read (.heap 11 1) = (L : ℤ) :=
      (wRead_wWrite_of_ne ma1 _ (Or.inr (by decide))).trans
        ((wRead_wWrite_of_ne mem₁ _ (Or.inr (by decide))).trans hwb₁)
    simp only [bPlus2SqExpr, evalIntExpr, hb, B_max]; push_cast; ring
  rw [hm3_eq] at s3
  have hfp_a3 : InParamFootprint ma3 := inParamFootprint_wWrite hfp_a2 (by decide)

  have s4 := exec_wSet_lit inp s3.2.1 11 4 (.lit 0) 10 (by simp [evalIntExpr])
  let ma4 := wWrite ma3 11 4 0
  have hm4_eq : wWrite ma3 11 4 (evalIntExpr inp.toWordView 0 ma3.words (.lit 0)).1 = ma4 := rfl
  rw [hm4_eq] at s4
  have hfp_a4 : InParamFootprint ma4 := inParamFootprint_wWrite hfp_a3 (by decide)

  have s5 := exec_rSet_lit inp s4.2.1 1 0 (.ofInt (.lit 1)) 10 (by simp [evalRealExpr, evalIntExpr])
  let ma5 := rWrite ma4 1 0 (tOf 0)
  have hm5_eq : rWrite ma4 1 0 (evalRealExpr inp 0 ma4 (.ofInt (.lit 1))).1 = ma5 := by
    congr 1; simp [evalRealExpr, evalIntExpr, tOf]
  rw [hm5_eq] at s5
  have hfp_a5 : InParamFootprint ma5 := inParamFootprint_rWrite hfp_a4 (by decide)

  let zFromT : RealExpr :=
    .div (.mul (.ofInt (.lit (ℓ : ℤ)))
      (.mul (.readRealHeap 1 (.lit 0)) (.readRealHeap 1 (.lit 0)))) (.ofInt (.lit 2))
  have s6 := exec_rSet_lit inp s5.2.1 17 0 zFromT 20 (by simp [zFromT, evalRealExpr, evalIntExpr])
  let ma6 := rWrite ma5 17 0 (zOf 0)
  have hm6_eq : rWrite ma5 17 0 (evalRealExpr inp 0 ma5 zFromT).1 = ma6 := by
    congr 1
    have ht : ma5.reals.read (.heap 1 0) = tOf 0 := rRead_rWrite_self ma4 1 0 (tOf 0)
    simp [zFromT, evalRealExpr, evalIntExpr, ht, zOf]
  rw [hm6_eq] at s6
  have hfp_a6 : InParamFootprint ma6 := inParamFootprint_rWrite hfp_a5 (by decide)

  have hN_ma6 : wRead ma6 11 2 = (N : ℤ) := by
    simp only [ma6, ma5, wRead_rWrite]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        wRead_wWrite_self]
  rcases exec_pow1PlusZStmt inp s6.2.1 hfp_a6 hN_ma6 with ⟨ma7, s7, hfp_a7, hw_a7, hr_a7, hpow_a7⟩
  have hz_ma6 : rRead ma6 17 0 = zOf 0 := rRead_rWrite_self ma5 17 0 (zOf 0)
  rw [hz_ma6] at hpow_a7

  have s8 := exec_rSet_lit inp s7.2.1 17 2 (.readRealHeap 17 (.lit 1)) 10
    (by simp [evalRealExpr, evalIntExpr])
  let ma8 := rWrite ma7 17 2 (FOf 0)
  have hm8_eq : rWrite ma7 17 2 (evalRealExpr inp 0 ma7 (.readRealHeap 17 (.lit 1))).1 = ma8 :=
    congrArg (rWrite ma7 17 2) hpow_a7
  rw [hm8_eq] at s8
  have hfp_a8 : InParamFootprint ma8 := inParamFootprint_rWrite hfp_a7 (by decide)

  -- Search `repeatN` loop
  let Inv : ℕ → ArithRAMMemory → Prop := fun i mem =>
    InParamFootprint mem ∧
    wRead mem 1 0 = (m : ℤ) ∧
    wRead mem 11 1 = (L : ℤ) ∧
    wRead mem 11 2 = (N : ℤ) ∧
    wRead mem 11 3 = (denom : ℤ) ∧
    wRead mem 11 6 = (B_max : ℤ) ∧
    ∃ k : ℕ, k ≤ i ∧
      wRead mem 11 4 = (k : ℤ) ∧
      rRead mem 1 0 = tOf k ∧
      rRead mem 17 2 = FOf k ∧
      (k = i ∨ 2 * (m : ℝ) ≤ FOf k) ∧
      (∀ j < k, FOf j < 2 * (m : ℝ))
  have hInv₀ : Inv 0 ma8 := by
    refine ⟨hfp_a8, ?_, ?_, ?_, ?_, ?_, 0, le_rfl, ?_, ?_, ?_, Or.inl rfl, fun _ hj => by omega⟩
    · simp only [ma8, wRead_rWrite]; rw [hw_a7]; simp only [ma6, ma5, wRead_rWrite]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
      exact hwm₁
    · simp only [ma8, wRead_rWrite]; rw [hw_a7]; simp only [ma6, ma5, wRead_rWrite]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inr (by decide))]
      exact hwb₁
    · simp only [ma8, wRead_rWrite]; rw [hw_a7]; exact hN_ma6
    · simp only [ma8, wRead_rWrite]; rw [hw_a7]; simp only [ma6, ma5, wRead_rWrite]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
          wRead_wWrite_self]
    · simp only [ma8, wRead_rWrite]; rw [hw_a7]; simp only [ma6, ma5, wRead_rWrite]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]
    · simp only [ma8, wRead_rWrite]; rw [hw_a7]; simp only [ma6, ma5, wRead_rWrite]
      exact wRead_wWrite_self ma3 11 4 0
    · rw [rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_a7 1 0 (Or.inl (by decide)),
          rRead_rWrite_of_ne _ _ (Or.inl (by decide)), rRead_rWrite_self]
    · exact rRead_rWrite_self ma7 17 2 (FOf 0)

  let kMaxExpr : IntExpr :=
    .mul (.mul (.lit (ℓ : ℤ)) (.readHeap 11 (.lit 1)))
      (.add (.readHeap 11 (.lit 1)) (.lit 1))
  have hb_ma8 : ma8.words.read (.heap 11 1) = (L : ℤ) := hInv₀.2.2.1
  have hcnt : evalIntExpr inp.toWordView 0 ma8.words kMaxExpr =
      ((K_max : ℤ), 9, (evalIntExpr inp.toWordView 0 ma8.words kMaxExpr).2.2) := by
    simp only [kMaxExpr, evalIntExpr, hb_ma8, K_max]
    refine Prod.ext (by push_cast; ring) (Prod.ext rfl rfl)

  let cond : ArithCondExpr :=
    .realLt (.readRealHeap 17 (.lit 2))
      (.mul (.ofInt (.lit 2)) (.ofInt (.readHeap 1 (.lit 0))))
  let searchBody : ArithRAMStmt :=
    .ite cond
      (.seq (.writeWordHeap 11 (.lit 4) (.add (.readHeap 11 (.lit 4)) (.lit 1)))
        (.seq
          (.writeRealHeap 1 (.lit 0)
            (.add (.ofInt (.lit 1))
              (.div (.ofInt (.readHeap 11 (.lit 4))) (.ofInt (.readHeap 11 (.lit 3))))))
          (.seq (.writeRealHeap 17 (.lit 0) zFromT)
            (.seq pow1PlusZStmt
              (.writeRealHeap 17 (.lit 2) (.readRealHeap 17 (.lit 1)))))))
      .skip
  rcases ExecStmt.repeatN_nat (body := searchBody) K_max 20 (120 + N * 20) Inv s8.2.1 hInv₀ hcnt (by omega)
    (fun i _ cur hcm ⟨hfpc, hwm_c, hwb_c, hwN_c, hwd_c, hwB_c, k, hk_le, hwk_c, hrt_c, hrF_c, hor_c, hlt_prev⟩ => by
      have hF_r : cur.reals.read (.heap 17 2) = FOf k := hrF_c
      have hm_r : cur.words.read (.heap 1 0) = (m : ℤ) := hwm_c
      by_cases hlt : FOf k < 2 * (m : ℝ)
      · have hk_eq_i : k = i := by
          rcases hor_c with rfl | hge
          · rfl
          · linarith
        have hcond : evalArithCond inp 0 cur cond = (true, 9) := by
          dsimp [cond, evalArithCond, evalRealExpr, evalIntExpr]
          rw [hF_r, hm_r]
          simp [hlt]
        have u1 := exec_wSet_lit inp hcm 11 4 (.add (.readHeap 11 (.lit 4)) (.lit 1)) 10
          (by simp [evalIntExpr])
        let c1 := wWrite cur 11 4 ((k + 1 : ℕ) : ℤ)
        have hc1_eq : wWrite cur 11 4
            (evalIntExpr inp.toWordView 0 cur.words (.add (.readHeap 11 (.lit 4)) (.lit 1))).1 = c1 := by
          congr 1; have hk_r : cur.words.read (.heap 11 4) = (k : ℤ) := hwk_c
          simp [evalIntExpr, hk_r]
        rw [hc1_eq] at u1
        have hfp_c1 : InParamFootprint c1 := inParamFootprint_wWrite hfpc (by decide)

        have u2 := exec_rSet_lit inp u1.2.1 1 0
          (.add (.ofInt (.lit 1))
            (.div (.ofInt (.readHeap 11 (.lit 4))) (.ofInt (.readHeap 11 (.lit 3))))) 20
          (by simp [evalRealExpr, evalIntExpr])
        let c2 := rWrite c1 1 0 (tOf (k + 1))
        have hc2_eq : rWrite c1 1 0
            (evalRealExpr inp 0 c1
              (.add (.ofInt (.lit 1))
                (.div (.ofInt (.readHeap 11 (.lit 4))) (.ofInt (.readHeap 11 (.lit 3)))))).1 = c2 := by
          congr 1
          have hk1 : c1.words.read (.heap 11 4) = ((k + 1 : ℕ) : ℤ) := wRead_wWrite_self _ _ _ _
          have hd1 : c1.words.read (.heap 11 3) = (denom : ℤ) :=
            (wRead_wWrite_of_ne cur _ (Or.inr (by decide))).trans hwd_c
          simp [evalRealExpr, evalIntExpr, hk1, hd1, tOf]
        rw [hc2_eq] at u2
        have hfp_c2 : InParamFootprint c2 := inParamFootprint_rWrite hfp_c1 (by decide)

        have u3 := exec_rSet_lit inp u2.2.1 17 0 zFromT 20
          (by simp [zFromT, evalRealExpr, evalIntExpr])
        let c3 := rWrite c2 17 0 (zOf (k + 1))
        have hc3_eq : rWrite c2 17 0 (evalRealExpr inp 0 c2 zFromT).1 = c3 := by
          congr 1
          have ht2 : c2.reals.read (.heap 1 0) = tOf (k + 1) := rRead_rWrite_self _ _ _ _
          simp [zFromT, evalRealExpr, evalIntExpr, ht2, zOf]
        rw [hc3_eq] at u3
        have hfp_c3 : InParamFootprint c3 := inParamFootprint_rWrite hfp_c2 (by decide)

        have hwN_c3 : wRead c3 11 2 = (N : ℤ) := by
          simp only [c3, c2, wRead_rWrite]
          exact (wRead_wWrite_of_ne cur _ (Or.inr (by decide))).trans hwN_c
        rcases exec_pow1PlusZStmt inp u3.2.1 hfp_c3 hwN_c3 with
          ⟨c4, u4, hfp_c4, hw_c4, hr_c4, hpow_c4⟩
        have hz_c3 : rRead c3 17 0 = zOf (k + 1) := rRead_rWrite_self _ _ _ _
        rw [hz_c3] at hpow_c4

        have u5 := exec_rSet_lit inp u4.2.1 17 2 (.readRealHeap 17 (.lit 1)) 10
          (by simp [evalRealExpr, evalIntExpr])
        let c5 := rWrite c4 17 2 (FOf (k + 1))
        have hc5_eq : rWrite c4 17 2 (evalRealExpr inp 0 c4 (.readRealHeap 17 (.lit 1))).1 = c5 :=
          congrArg (rWrite c4 17 2) hpow_c4
        rw [hc5_eq] at u5
        have hfp_c5 : InParamFootprint c5 := inParamFootprint_rWrite hfp_c4 (by decide)

        have hbranch := ExecStmt.seq u1 (ExecStmt.seq u2 (ExecStmt.seq u3 (ExecStmt.seq u4 u5)))
        refine ⟨c5, (ExecStmt.ite_true hcond (C_c := 20) (by omega) hbranch).mono_cost (by omega), hfp_c5, ?_, ?_, ?_, ?_, ?_, k + 1, by omega, ?_, ?_, ?_, Or.inl (by omega), ?_⟩
        · simp only [c5, wRead_rWrite]; rw [hw_c4]; simp only [c3, c2, wRead_rWrite]
          exact (wRead_wWrite_of_ne cur _ (Or.inl (by decide))).trans hwm_c
        · simp only [c5, wRead_rWrite]; rw [hw_c4]; simp only [c3, c2, wRead_rWrite]
          exact (wRead_wWrite_of_ne cur _ (Or.inr (by decide))).trans hwb_c
        · simp only [c5, wRead_rWrite]; rw [hw_c4]; exact hwN_c3
        · simp only [c5, wRead_rWrite]; rw [hw_c4]; simp only [c3, c2, wRead_rWrite]
          exact (wRead_wWrite_of_ne cur _ (Or.inr (by decide))).trans hwd_c
        · simp only [c5, wRead_rWrite]; rw [hw_c4]; simp only [c3, c2, wRead_rWrite]
          exact (wRead_wWrite_of_ne cur _ (Or.inr (by decide))).trans hwB_c
        · simp only [c5, wRead_rWrite]; rw [hw_c4]; simp only [c3, c2, wRead_rWrite]
          exact wRead_wWrite_self _ _ _ _
        · rw [rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_c4 1 0 (Or.inl (by decide)),
              rRead_rWrite_of_ne _ _ (Or.inl (by decide)), rRead_rWrite_self]
        · exact rRead_rWrite_self _ _ _ _
        · intro j hj
          rcases Nat.lt_succ_iff_lt_or_eq.mp hj with hjk | rfl
          · exact hlt_prev j hjk
          · exact hlt
      · have hge : 2 * (m : ℝ) ≤ FOf k := not_lt.mp hlt
        have hcond : evalArithCond inp 0 cur cond = (false, 9) := by
          dsimp [cond, evalArithCond, evalRealExpr, evalIntExpr]
          rw [hF_r, hm_r]
          simp [hlt]
        refine ⟨cur, (ExecStmt.ite_false hcond (C_c := 20) (by omega)
          (ExecStmt.skip inp hcm)).mono_cost (by omega), hfpc, hwm_c, hwb_c, hwN_c, hwd_c, hwB_c,
          k, by omega, hwk_c, hrt_c, hrF_c, Or.inr hge, hlt_prev⟩) with
    ⟨mem₂, ⟨hfp₂, hwm₂, hwb₂, hwN₂, _, hwB₂, k, hk_le, _, hrt₂, hrF₂, hor₂, hlt_prev⟩, hrep⟩

  -- Prove analytic bounds for chosen `k`
  have htOf_bounds : ∀ j ≤ K_max, 1 ≤ tOf j ∧ tOf j ≤ (L + 2 : ℝ) := by
    intro j hj
    have hd_pos : (0 : ℝ) < (denom : ℝ) := by positivity
    constructor
    · dsimp [tOf]
      have : 0 ≤ (j : ℝ) / (denom : ℝ) := by positivity
      linarith
    · dsimp [tOf]
      have hj_le : (j : ℝ) ≤ (L + 1 : ℝ) * (denom : ℝ) := by
        have : j ≤ (L + 1) * denom := by
          have : j ≤ denom * (L + 1) := by simpa [denom, K_max, mul_assoc] using hj
          linarith
        exact_mod_cast this
      have hdiv : (j : ℝ) / (denom : ℝ) ≤ (L + 1 : ℝ) := (div_le_iff₀ hd_pos).mpr hj_le
      linarith

  have hzOf_approx : ∀ j ≤ K_max,
      1 ≤ FOf j ∧ FOf j ≤ Real.exp (zOf j) ∧ Real.exp (zOf j) ≤ 2 * FOf j := by
    intro j hj
    rcases htOf_bounds j hj with ⟨ht1, ht2⟩
    have hz_nonneg : 0 ≤ zOf j := by dsimp [zOf]; positivity
    have hz_le : zOf j ≤ (ℓ : ℝ) * ((L + 2 : ℝ) ^ 2) / 2 := by
      dsimp [zOf]
      have htsq : tOf j * tOf j ≤ (L + 2 : ℝ) ^ 2 := by nlinarith
      have : (ℓ : ℝ) * (tOf j * tOf j) ≤ (ℓ : ℝ) * ((L + 2 : ℝ) ^ 2) :=
        mul_le_mul_of_nonneg_left htsq (by positivity)
      linarith
    have hN_ge : 3 * (zOf j) ^ 2 + 1 ≤ (N : ℝ) := by
      have hsq4 : 4 * (zOf j) ^ 2 ≤ (ℓ : ℝ) ^ 2 * (L + 2 : ℝ) ^ 4 := by nlinarith
      have hN_eq : (N : ℝ) = 3 * ((ℓ : ℝ) ^ 2 * (L + 2 : ℝ) ^ 4) + 1 := by
        dsimp [N]; push_cast; ring
      have hsq0 : 0 ≤ (zOf j) ^ 2 := sq_nonneg _
      linarith only [hsq4, hN_eq, hsq0]
    exact one_plus_div_pow_approx hz_nonneg hN_ge

  have hFK_ge : 2 * (m : ℝ) ≤ FOf K_max := by
    have hd_ne : (denom : ℝ) ≠ 0 := by positivity
    have htK : tOf K_max = (L + 2 : ℝ) := by
      dsimp [tOf, K_max, denom]
      have hℓ_ne : (ℓ : ℝ) ≠ 0 := by positivity
      have hL_ne : (L : ℝ) ≠ 0 := by positivity
      push_cast; field_simp; ring
    have hzK_ge : (L + 2 : ℝ) ≤ zOf K_max := by
      dsimp [zOf]; rw [htK]
      have h1 : 2 * (L + 2 : ℝ) ≤ (L + 2 : ℝ) * (L + 2 : ℝ) := by
        have h2le : (2 : ℝ) ≤ (L + 2 : ℝ) := by
          have : (0 : ℝ) ≤ (L : ℝ) := by positivity
          linarith
        nlinarith only [h2le]
      have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
      nlinarith
    have hm_lt : (m : ℝ) ≤ (2 : ℝ) ^ L := by
      exact_mod_cast (Nat.lt_pow_succ_log_self (by decide) m).le
    have h4m : 4 * (m : ℝ) ≤ Real.exp (zOf K_max) := by
      calc 4 * (m : ℝ) ≤ 4 * (2 : ℝ) ^ L := by linarith
        _ = (2 : ℝ) ^ (L + 2) := by ring
        _ ≤ (Real.exp 1) ^ (L + 2) := pow_le_pow_left₀ (by norm_num) two_le_exp_one _
        _ = Real.exp ((L + 2 : ℕ) : ℝ) := by rw [← Real.exp_nat_mul, mul_one]
        _ = Real.exp (L + 2 : ℝ) := by push_cast; rfl
        _ ≤ Real.exp (zOf K_max) := Real.exp_le_exp.mpr hzK_ge
    have h2F := (hzOf_approx K_max le_rfl).2.2
    linarith

  have hFu_ge_2m : 2 * (m : ℝ) ≤ FOf k := by
    rcases hor₂ with rfl | hge
    · exact hFK_ge
    · exact hge

  rcases htOf_bounds k hk_le with ⟨ht_lo, ht_hi⟩
  rcases hzOf_approx k hk_le with ⟨hF1, hF_le_exp, _⟩
  have hz_eq_sq : zOf k = (ℓ : ℝ) * (tOf k) ^ 2 / 2 := by dsimp [zOf]; ring

  have hexp_ub : Real.exp ((ℓ : ℝ) * (tOf k) ^ 2 / 2) ≤ C_scale * (m : ℝ) := by
    rw [← hz_eq_sq]
    cases k with
    | zero =>
        have hz0 : zOf 0 = (ℓ : ℝ) / 2 := by dsimp [zOf, tOf]; ring
        rw [hz0]
        have hm1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
        calc Real.exp ((ℓ : ℝ) / 2) = Real.exp ((ℓ : ℝ) / 2) * 1 := (mul_one _).symm
          _ ≤ C_scale * (m : ℝ) :=
              mul_le_mul (le_max_left _ _) hm1 zero_le_one (le_trans (Real.exp_pos _).le (le_max_left _ _))
    | succ km =>
        have hkm_lt : km < km + 1 := Nat.lt_succ_self km
        have hF_prev : FOf km < 2 * (m : ℝ) := hlt_prev km hkm_lt
        have hexp_prev : Real.exp (zOf km) ≤ 4 * (m : ℝ) := by
          have := (hzOf_approx km (by omega)).2.2
          linarith
        have hdiff_le : zOf (km + 1) - zOf km ≤ 3 := by
          have ht_step : tOf (km + 1) - tOf km = 1 / ((ℓ : ℝ) * (L : ℝ)) := by
            dsimp [tOf, denom]; push_cast; ring
          have ht_sum : tOf (km + 1) + tOf km ≤ 2 * (L + 2 : ℝ) := by
            have h_a := (htOf_bounds (km + 1) hk_le).2
            have h_b := (htOf_bounds km (by omega)).2
            linarith
          have hzd : zOf (km + 1) - zOf km =
              ((ℓ : ℝ) / 2) * (tOf (km + 1) - tOf km) * (tOf (km + 1) + tOf km) := by
            dsimp [zOf]; ring
          rw [hzd, ht_step]
          have hℓ_ne : (ℓ : ℝ) ≠ 0 := by positivity
          have hL_pos_r : (0 : ℝ) < (L : ℝ) := by positivity
          have hsimp : ((ℓ : ℝ) / 2) * (1 / ((ℓ : ℝ) * (L : ℝ))) = 1 / (2 * (L : ℝ)) := by
            field_simp
          rw [hsimp]
          calc (1 / (2 * (L : ℝ))) * (tOf (km + 1) + tOf km)
              ≤ (1 / (2 * (L : ℝ))) * (2 * (L + 2 : ℝ)) :=
                mul_le_mul_of_nonneg_left ht_sum (by positivity)
            _ = (L + 2 : ℝ) / (L : ℝ) := by field_simp
            _ ≤ 3 := by
                rw [div_le_iff₀ hL_pos_r]
                have : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast hL_pos
                linarith
        calc Real.exp (zOf (km + 1))
            = Real.exp (zOf km + (zOf (km + 1) - zOf km)) := by congr 1; ring
          _ = Real.exp (zOf km) * Real.exp (zOf (km + 1) - zOf km) := Real.exp_add _ _
          _ ≤ (4 * (m : ℝ)) * Real.exp 3 :=
              mul_le_mul hexp_prev (Real.exp_le_exp.mpr hdiff_le) (Real.exp_pos _).le (by positivity)
          _ = (4 * Real.exp 3) * (m : ℝ) := by ring
          _ ≤ C_scale * (m : ℝ) :=
              mul_le_mul_of_nonneg_right (le_max_right _ _) (by positivity)

  have htot : ExecStmt inp (stepP2Stmt ℓ C_base) mem₁ mem₂
      (200 + N * 20 + K_max * (120 + N * 20)) := by
    unfold stepP2Stmt
    exact (ExecStmt.seq s1 (ExecStmt.seq s2 (ExecStmt.seq s3 (ExecStmt.seq s4
      (ExecStmt.seq s5 (ExecStmt.seq s6 (ExecStmt.seq s7 (ExecStmt.seq s8 hrep)))))))).mono_cost
      (by omega)

  exact ⟨mem₂, tOf k, FOf k, htot, hfp₂, hwm₂, hwb₂, hwN₂, hwB₂, hrt₂, hrF₂,
    ht_lo, ht_hi, hF1, hFu_ge_2m, hz_eq_sq ▸ hF_le_exp, hexp_ub⟩

set_option maxHeartbeats 400000 in
/-- Step P3 execution helper: computes `x * t`, `M₀`, `K`, `A = M₀ ^ ℓ`, `Cap_u`, and `Cap_q`
with clean bounds and no `rpow` obligations in local memory context. -/
theorem exec_stepP3Stmt {d : ℕ} (ℓ C_base : ℕ) (hℓ : 1 ≤ ℓ)
    (m : ℕ) (h x : ℝ)
    (hh0 : 0 < h) (hx0 : h ≤ x) (hx1 : x ≤ 1)
    (mem₂ : ArithRAMMemory) (t F_u : ℝ) :
    let inp : ArithRAMInput d :=
      { intParams := [(m : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0, extraReals := [h, x] }
    let L : ℕ := natBitLength m
    let N : ℕ := 3 * ℓ * ℓ * (L + 2) ^ 4 + 1
    let B_max : ℕ := (ℓ + 1) * (C_base + 2 + 3 * (L + 2) ^ 2)
    CleanMem mem₂ →
    InParamFootprint mem₂ →
    wRead mem₂ 1 0 = (m : ℤ) →
    wRead mem₂ 11 2 = (N : ℤ) →
    wRead mem₂ 11 6 = (B_max : ℤ) →
    rRead mem₂ 1 0 = t →
    rRead mem₂ 17 2 = F_u →
    1 ≤ t → t ≤ (L + 2 : ℝ) →
    1 ≤ F_u →
    0 ≤ I_h h x → I_h h x ≤ 2 →
    ∃ (mem₃ : ArithRAMMemory) (M₀ Cap_u Cap_q : ℕ) (F1 F_q : ℝ),
      ExecStmt inp (stepP3Stmt ℓ C_base) mem₂ mem₃
        (350 + 2 * (20 + N * 20) + 3 * (20 + B_max * 20) + ℓ * 10) ∧
      InParamFootprint mem₃ ∧
      1 ≤ M₀ ∧ 100 ≤ Cap_u ∧ 100 ≤ Cap_q ∧
      wRead mem₃ 0 0 = ((ℓ * M₀ : ℕ) : ℤ) ∧
      wRead mem₃ 1 0 = (m : ℤ) ∧
      wRead mem₃ 1 1 = (M₀ : ℤ) ∧
      wRead mem₃ 1 2 = ((ℓ * M₀ : ℕ) : ℤ) ∧
      wRead mem₃ 1 3 = (Cap_u : ℤ) ∧
      wRead mem₃ 1 4 = (Cap_q : ℤ) ∧
      rRead mem₃ 1 0 = t ∧
      rRead mem₃ 1 1 = x * t ∧
      1 ≤ F1 ∧ F1 ≤ Real.exp (I_h h x * t ^ 2 / 2) ∧ Real.exp (I_h h x * t ^ 2 / 2) ≤ 2 * F1 ∧
      (C_base : ℝ) * t ^ 2 * F1 ≤ (M₀ : ℝ) ∧
      (M₀ : ℝ) ≤ max 1 (2 * ((C_base : ℝ) * t ^ 2 * F1)) ∧
      100 * ((((M₀ ^ ℓ : ℕ) : ℝ)) / F_u + 1) ≤ (Cap_u : ℝ) ∧
      (Cap_u : ℝ) ≤ max 100 (2 * (100 * ((((M₀ ^ ℓ : ℕ) : ℝ)) / F_u + 1))) ∧
      1 ≤ F_q ∧ F_q ≤ Real.exp ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2) ∧
      Real.exp ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2) ≤ 2 * F_q ∧
      100 * ((((M₀ ^ ℓ : ℕ) : ℝ)) / F_q + 1) ≤ (Cap_q : ℝ) ∧
      (Cap_q : ℝ) ≤ max 100 (2 * (100 * ((((M₀ ^ ℓ : ℕ) : ℝ)) / F_q + 1))) := by
  intro inp L N B_max hc₂ hfp₂ hwm₂ hwN₂ hwB₂ hrt₂ hrF₂ ht_lo ht_hi hFu_ge1 hI_ge hI_le
  let hE := RealExpr.extraReal (.lit 0)
  let xE := RealExpr.extraReal (.lit 1)
  let tE := RealExpr.readRealHeap 1 (.lit 0)
  let iExpr : RealExpr :=
    .div
      (.sub (.add (.ofInt (.lit 1)) (.mul xE xE)) (.mul (.mul (.ofInt (.lit 2)) hE) xE))
      (.sub (.ofInt (.lit 1)) (.mul hE hE))
  let z1Expr : RealExpr := .div (.mul iExpr (.mul tE tE)) (.ofInt (.lit 2))
  let r1Expr : RealExpr :=
    .mul (.mul (.ofInt (.lit (C_base : ℤ))) (.mul tE tE)) (.readRealHeap 17 (.lit 1))
  let zqExpr : RealExpr :=
    .div (.mul (.ofInt (.lit (ℓ : ℤ))) (.mul (.mul xE xE) (.mul tE tE))) (.ofInt (.lit 2))

  have hextra0 : listGetIntD inp.extraReals 0 0 = h := rfl
  have hextra1 : listGetIntD inp.extraReals 1 0 = x := rfl
  have htsq_bound : t ^ 2 ≤ (L + 2 : ℝ) ^ 2 :=
    pow_le_pow_left₀ (by linarith only [ht_lo]) ht_hi 2

  -- P3.1: `.heap 1 1 := x * t`
  have q1 := exec_rSet_lit inp hc₂ 1 1 (.mul xE tE) 15
    (by simp [xE, tE, evalRealExpr, evalIntExpr])
  let mb1 := rWrite mem₂ 1 1 (x * t)
  have hmb1 : rWrite mem₂ 1 1 (evalRealExpr inp 0 mem₂ (.mul xE tE)).1 = mb1 := by
    have ht_r : mem₂.reals.read (.heap 1 0) = t := hrt₂
    have hv : (evalRealExpr inp 0 mem₂ (.mul xE tE)).1 = x * t := by
      dsimp only [xE, tE, evalRealExpr, evalIntExpr]
      rw [hextra1, ht_r]
    exact congrArg (rWrite mem₂ 1 1) hv
  rw [hmb1] at q1
  have hfp_b1 : InParamFootprint mb1 := inParamFootprint_rWrite hfp₂ (by decide)

  -- P3.2: `.heap 17 0 := z1`
  let z1 : ℝ := I_h h x * t ^ 2 / 2
  have q2 := exec_rSet_lit inp q1.2.1 17 0 z1Expr 50
    (by simp [z1Expr, iExpr, hE, xE, tE, evalRealExpr, evalIntExpr])
  let mb2 := rWrite mb1 17 0 z1
  have hmb2 : rWrite mb1 17 0 (evalRealExpr inp 0 mb1 z1Expr).1 = mb2 := by
    have ht_r : mb1.reals.read (.heap 1 0) = t :=
      (rRead_rWrite_of_ne mem₂ _ (Or.inr (by decide))).trans hrt₂
    have hv : (evalRealExpr inp 0 mb1 z1Expr).1 = z1 := by
      dsimp only [z1Expr, iExpr, hE, xE, tE, evalRealExpr, evalIntExpr, z1, I_h]
      rw [hextra0, hextra1, ht_r]
      norm_num; ring
    exact congrArg (rWrite mb1 17 0) hv
  rw [hmb2] at q2
  have hfp_b2 : InParamFootprint mb2 := inParamFootprint_rWrite hfp_b1 (by decide)

  -- P3.3: `pow1PlusZStmt` for `z1`
  have hwN_b2 : wRead mb2 11 2 = (N : ℤ) := hwN₂
  rcases exec_pow1PlusZStmt inp q2.2.1 hfp_b2 hwN_b2 with ⟨mb3, q3, hfp_b3, hw_b3, hr_b3, hpow_b3⟩
  let F1 : ℝ := (1 + z1 / (N : ℝ)) ^ N
  have hz1_b2 : rRead mb2 17 0 = z1 := rRead_rWrite_self _ _ _ _
  have hF1_eq : rRead mb3 17 1 = F1 := by simpa [F1, hz1_b2] using hpow_b3

  -- P3.4: `.heap 17 3 := R1`
  let R1 : ℝ := (C_base : ℝ) * t ^ 2 * F1
  have q4 := exec_rSet_lit inp q3.2.1 17 3 r1Expr 30
    (by simp [r1Expr, tE, evalRealExpr, evalIntExpr])
  let mb4 := rWrite mb3 17 3 R1
  have hmb4 : rWrite mb3 17 3 (evalRealExpr inp 0 mb3 r1Expr).1 = mb4 := by
    have ht_r : mb3.reals.read (.heap 1 0) = t :=
      (hr_b3 1 0 (Or.inl (by decide))).trans
        ((rRead_rWrite_of_ne mb1 _ (Or.inl (by decide))).trans
          ((rRead_rWrite_of_ne mem₂ _ (Or.inr (by decide))).trans hrt₂))
    have hf1_r : mb3.reals.read (.heap 17 1) = F1 := hF1_eq
    have hv : (evalRealExpr inp 0 mb3 r1Expr).1 = R1 := by
      dsimp only [r1Expr, tE, evalRealExpr, evalIntExpr, R1]
      rw [ht_r, hf1_r]
      push_cast; ring
    exact congrArg (rWrite mb3 17 3) hv
  rw [hmb4] at q4
  have hfp_b4 : InParamFootprint mb4 := inParamFootprint_rWrite hfp_b3 (by decide)

  -- Bound `z1`, `F1`, and `R1 ≤ 2 ^ B_max`
  have hz1_nonneg : 0 ≤ z1 := by dsimp [z1]; positivity
  have hz1_le_sq : z1 ≤ (L + 2 : ℝ) ^ 2 := by
    have h1 : I_h h x * t ^ 2 ≤ 2 * (L + 2 : ℝ) ^ 2 := by
      have : 0 ≤ t ^ 2 := sq_nonneg t
      nlinarith only [hI_le, htsq_bound, this]
    dsimp [z1]; linarith only [h1]
  have hN_z1 : 3 * z1 ^ 2 + 1 ≤ (N : ℝ) := by
    have h1 : z1 ^ 2 ≤ ((L + 2 : ℝ) ^ 2) ^ 2 := pow_le_pow_left₀ hz1_nonneg hz1_le_sq 2
    have h1' : z1 ^ 2 ≤ (L + 2 : ℝ) ^ 4 := by ring_nf at h1 ⊢; exact h1
    have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) ^ 2 := by
      have : 1 ≤ ℓ ^ 2 := by nlinarith only [hℓ]
      exact_mod_cast this
    have hN_r : (N : ℝ) = 3 * (ℓ : ℝ) ^ 2 * (L + 2 : ℝ) ^ 4 + 1 := by
      dsimp [N]; push_cast; ring
    have hmul : (L + 2 : ℝ) ^ 4 ≤ (ℓ : ℝ) ^ 2 * (L + 2 : ℝ) ^ 4 := by
      have : 0 ≤ (L + 2 : ℝ) ^ 4 := by positivity
      nlinarith only [hℓ1, this]
    linarith only [h1', hmul, hN_r]
  rcases one_plus_div_pow_approx hz1_nonneg hN_z1 with ⟨hF1_ge1, hF1_le_exp, hexp_le_2F1⟩

  have hR1_pow_ub : R1 ≤ ((1 : ℕ) : ℝ) * (2 : ℝ) ^ B_max := by
    have hc_ub : (C_base : ℝ) ≤ (2 : ℝ) ^ C_base := nat_cast_le_two_pow C_base
    have ht_ub : t ^ 2 ≤ (2 : ℝ) ^ ((L + 2) ^ 2) := by
      have htsq : t ^ 2 ≤ (((L + 2) ^ 2 : ℕ) : ℝ) := by push_cast; exact htsq_bound
      exact htsq.trans (nat_cast_le_two_pow _)
    have hf_ub : F1 ≤ (2 : ℝ) ^ (2 * (L + 2) ^ 2) := by
      have hz_cast : z1 ≤ (((L + 2) ^ 2 : ℕ) : ℝ) := by push_cast; exact hz1_le_sq
      exact hF1_le_exp.trans (exp_le_two_pow_two_mul ((L + 2) ^ 2) hz_cast)
    have hprod_pow : R1 ≤ (2 : ℝ) ^ (C_base + 3 * (L + 2) ^ 2) := by
      calc R1 = (C_base : ℝ) * t ^ 2 * F1 := rfl
        _ ≤ (2 : ℝ) ^ C_base * (2 : ℝ) ^ ((L + 2) ^ 2) * (2 : ℝ) ^ (2 * (L + 2) ^ 2) := by
            have h12 : (C_base : ℝ) * t ^ 2 ≤ (2 : ℝ) ^ C_base * (2 : ℝ) ^ ((L + 2) ^ 2) :=
              mul_le_mul hc_ub ht_ub (by positivity) (by positivity)
            exact mul_le_mul h12 hf_ub (by positivity) (by positivity)
        _ = (2 : ℝ) ^ (C_base + 3 * (L + 2) ^ 2) := by
            rw [← pow_add, ← pow_add]; congr 1; ring
    have hexp_le : C_base + 3 * (L + 2) ^ 2 ≤ B_max := by
      dsimp only [B_max]; nlinarith only [hℓ]
    push_cast
    rw [one_mul]
    exact hprod_pow.trans (pow_le_pow_right₀ (by norm_num) hexp_le)

  -- P3.5: `boundedDoublingStmt 1 1 1 3` -> `M₀`
  have hwB_b4 : wRead mb4 11 6 = (B_max : ℤ) := by
    simp only [mb4, wRead_rWrite]; rw [hw_b3]; exact hwB₂
  have hrR1_b4 : rRead mb4 17 3 = R1 := rRead_rWrite_self _ _ _ _
  rcases exec_boundedDoublingStmt inp q4.2.1 hfp_b4 1 1 (Or.inl (by decide)) (by decide)
    1 le_rfl 3 hwB_b4 (hrR1_b4 ▸ hR1_pow_ub) with
    ⟨mb5, M₀, q5, hfp_b5, hM₀_ge1, hM₀_lb, hM₀_ub, hwM₀_b5, hw_b5, hr_b5⟩
  rw [hrR1_b4] at hM₀_lb hM₀_ub
  push_cast at hM₀_ub

  -- P3.6 & P3.7: `.heap 1 2 := ℓ * M₀`, `.heap 0 0 := ℓ * M₀`
  have q6 := exec_wSet_lit inp q5.2.1 1 2 (.mul (.lit (ℓ : ℤ)) (.readHeap 1 (.lit 1))) 10
    (by simp [evalIntExpr])
  let mb6 := wWrite mb5 1 2 ((ℓ * M₀ : ℕ) : ℤ)
  have hmb6 : wWrite mb5 1 2
      (evalIntExpr inp.toWordView 0 mb5.words (.mul (.lit (ℓ : ℤ)) (.readHeap 1 (.lit 1)))).1 = mb6 := by
    congr 1; have hm0_r : mb5.words.read (.heap 1 1) = (M₀ : ℤ) := hwM₀_b5
    simp [evalIntExpr, hm0_r]
  rw [hmb6] at q6
  have hfp_b6 : InParamFootprint mb6 := inParamFootprint_wWrite hfp_b5 (by decide)

  have q7 := exec_wSet_lit inp q6.2.1 0 0 (.readHeap 1 (.lit 2)) 10 (by simp [evalIntExpr])
  let mb7 := wWrite mb6 0 0 ((ℓ * M₀ : ℕ) : ℤ)
  have hmb7 : wWrite mb6 0 0 (evalIntExpr inp.toWordView 0 mb6.words (.readHeap 1 (.lit 2))).1 = mb7 := by
    congr 1; have hk_r : mb6.words.read (.heap 1 2) = ((ℓ * M₀ : ℕ) : ℤ) := wRead_wWrite_self _ _ _ _
    simp [evalIntExpr, hk_r]
  rw [hmb7] at q7
  have hfp_b7 : InParamFootprint mb7 := inParamFootprint_wWrite hfp_b6 (by decide)

  -- P3.8 & P3.9: compute `A = M₀ ^ ℓ` in `.heap 11 5`
  have q8 := exec_wSet_lit inp q7.2.1 11 5 (.lit 1) 10 (by simp [evalIntExpr])
  let mb8 := wWrite mb7 11 5 1
  have hmb8 : wWrite mb7 11 5 (evalIntExpr inp.toWordView 0 mb7.words (.lit 1)).1 = mb8 := rfl
  rw [hmb8] at q8
  have hfp_b8 : InParamFootprint mb8 := inParamFootprint_wWrite hfp_b7 (by decide)

  let InvA : ℕ → ArithRAMMemory → Prop := fun i m_cur =>
    InParamFootprint m_cur ∧
    (∀ t' i', (t' ≠ 11 ∨ i' ≠ 5) → wRead m_cur t' i' = wRead mb8 t' i') ∧
    (∀ t' i', rRead m_cur t' i' = rRead mb8 t' i') ∧
    wRead m_cur 11 5 = ((M₀ ^ i : ℕ) : ℤ)
  have hInvA₀ : InvA 0 mb8 := ⟨hfp_b8, fun _ _ _ => rfl, fun _ _ => rfl, by simp [mb8]⟩
  have hcnt_ell : evalIntExpr inp.toWordView 0 mb8.words (.lit (ℓ : ℤ)) =
      ((ℓ : ℤ), 1, intBitLength (ℓ : ℤ)) := rfl
  have hwM₀_b8 : wRead mb8 1 1 = (M₀ : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr (by decide))]
    exact hwM₀_b5
  rcases ExecStmt.repeatN_nat ℓ 10 10 InvA q8.2.1 hInvA₀ hcnt_ell (by omega)
    (fun i _ mc hcm ⟨hfpc, hwc, hrc, hpowA⟩ => by
      have stepA := exec_wSet_lit inp hcm 11 5
        (.mul (.readHeap 11 (.lit 5)) (.readHeap 1 (.lit 1))) 10 (by simp [evalIntExpr])
      refine ⟨_, stepA, inParamFootprint_wWrite hfpc (by decide),
        fun t' i' hne => (wRead_wWrite_of_ne _ _ hne).trans (hwc t' i' hne),
        fun t' i' => hrc t' i', ?_⟩
      have hcurA : mc.words.read (.heap 11 5) = ((M₀ ^ i : ℕ) : ℤ) := hpowA
      have hm0_c : mc.words.read (.heap 1 1) = (M₀ : ℤ) :=
        (hwc 1 1 (Or.inl (by decide))).trans hwM₀_b8
      simp [evalIntExpr, hcurA, hm0_c, pow_succ]) with
    ⟨mb9, ⟨hfp_b9, hw_b9, hr_b9, hwA_b9⟩, q9⟩

  -- Bound `A ≤ 2 ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2))`
  let A : ℕ := M₀ ^ ℓ
  have hA_pow_ub : (A : ℝ) ≤ (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2)) := by
    have hM₀_2 : (M₀ : ℝ) ≤ (2 : ℝ) ^ (C_base + 1 + 3 * (L + 2) ^ 2) := by
      have hR1_p : R1 ≤ (2 : ℝ) ^ (C_base + 3 * (L + 2) ^ 2) := by
        have hc_ub : (C_base : ℝ) ≤ (2 : ℝ) ^ C_base := nat_cast_le_two_pow C_base
        have ht_ub : t ^ 2 ≤ (2 : ℝ) ^ ((L + 2) ^ 2) := by
          have htsq : t ^ 2 ≤ (((L + 2) ^ 2 : ℕ) : ℝ) := by push_cast; exact htsq_bound
          exact htsq.trans (nat_cast_le_two_pow _)
        have hf_ub : F1 ≤ (2 : ℝ) ^ (2 * (L + 2) ^ 2) := by
          have hz_cast : z1 ≤ (((L + 2) ^ 2 : ℕ) : ℝ) := by push_cast; exact hz1_le_sq
          exact hF1_le_exp.trans (exp_le_two_pow_two_mul ((L + 2) ^ 2) hz_cast)
        calc R1 = (C_base : ℝ) * t ^ 2 * F1 := rfl
          _ ≤ (2 : ℝ) ^ C_base * (2 : ℝ) ^ ((L + 2) ^ 2) * (2 : ℝ) ^ (2 * (L + 2) ^ 2) :=
              mul_le_mul (mul_le_mul hc_ub ht_ub (by positivity) (by positivity)) hf_ub
                (by positivity) (by positivity)
          _ = (2 : ℝ) ^ (C_base + 3 * (L + 2) ^ 2) := by
              rw [← pow_add, ← pow_add]; congr 1; ring
      have h2R1 : 2 * R1 ≤ (2 : ℝ) ^ (C_base + 1 + 3 * (L + 2) ^ 2) := by
        have heq : C_base + 1 + 3 * (L + 2) ^ 2 = (C_base + 3 * (L + 2) ^ 2) + 1 := by ring
        rw [heq, pow_succ]; linarith only [hR1_p]
      have h1_le : (1 : ℝ) ≤ (2 : ℝ) ^ (C_base + 1 + 3 * (L + 2) ^ 2) :=
        one_le_pow₀ (by norm_num)
      exact hM₀_ub.trans (max_le h1_le h2R1)
    calc (A : ℝ) = (M₀ : ℝ) ^ ℓ := by simp [A]
      _ ≤ ((2 : ℝ) ^ (C_base + 1 + 3 * (L + 2) ^ 2)) ^ ℓ :=
          pow_le_pow_left₀ (by positivity) hM₀_2 ℓ
      _ = (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2)) := by
          rw [← pow_mul]; congr 1; ring

  -- P3.10 & P3.11: `target_u` and `Cap_u`
  let target_u : ℝ := 100 * ((A : ℝ) / F_u + 1)
  have q10 := exec_rSet_lit inp q9.2.1 17 4
    (.mul (.ofInt (.lit 100))
      (.add (.div (.ofInt (.readHeap 11 (.lit 5))) (.readRealHeap 17 (.lit 2))) (.ofInt (.lit 1)))) 20
    (by simp [evalRealExpr, evalIntExpr])
  let mb10 := rWrite mb9 17 4 target_u
  have hmb10 : rWrite mb9 17 4
      (evalRealExpr inp 0 mb9
        (.mul (.ofInt (.lit 100))
          (.add (.div (.ofInt (.readHeap 11 (.lit 5))) (.readRealHeap 17 (.lit 2)))
            (.ofInt (.lit 1))))).1 = mb10 := by
    congr 1
    have hA_r : mb9.words.read (.heap 11 5) = (A : ℤ) := hwA_b9
    have hFu_r : mb9.reals.read (.heap 17 2) = F_u := by
      change rRead mb9 17 2 = F_u
      rw [hr_b9]; simp only [mb8, mb7, mb6, rRead_wWrite]; rw [hr_b5]
      rw [rRead_rWrite_of_ne _ _ (Or.inr (by decide)), hr_b3 17 2 (Or.inr (by decide)),
          rRead_rWrite_of_ne _ _ (Or.inr (by decide)), rRead_rWrite_of_ne _ _ (Or.inl (by decide))]
      exact hrF₂
    simp [evalRealExpr, evalIntExpr, hA_r, hFu_r, target_u]
  rw [hmb10] at q10
  have hfp_b10 : InParamFootprint mb10 := inParamFootprint_rWrite hfp_b9 (by decide)

  have htar_u_ub : target_u ≤ ((100 : ℕ) : ℝ) * (2 : ℝ) ^ B_max := by
    have hdiv_le : (A : ℝ) / F_u ≤ (A : ℝ) := div_le_self (by positivity) hFu_ge1
    have hA1 : (A : ℝ) + 1 ≤ 2 * (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2)) := by
      have h1_le : (1 : ℝ) ≤ (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2)) :=
        one_le_pow₀ (by norm_num)
      linarith only [hA_pow_ub, h1_le]
    have hexp_le : ℓ * (C_base + 1 + 3 * (L + 2) ^ 2) + 1 ≤ B_max := by
      dsimp only [B_max]; nlinarith only [hℓ]
    have h2pow : 2 * (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2)) ≤ (2 : ℝ) ^ B_max := by
      calc 2 * (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2))
          = (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2) + 1) := by rw [pow_succ]; ring
        _ ≤ (2 : ℝ) ^ B_max := pow_le_pow_right₀ (by norm_num) hexp_le
    push_cast
    dsimp [target_u]; linarith only [hdiv_le, hA1, h2pow]

  have hwB_b10 : wRead mb10 11 6 = (B_max : ℤ) := by
    simp only [mb10, wRead_rWrite]; rw [hw_b9 11 6 (Or.inr (by decide))]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        hw_b5 11 6 (Or.inl (by decide))]
    exact hwB_b4
  have hrtar_u_b10 : rRead mb10 17 4 = target_u := rRead_rWrite_self _ _ _ _
  rcases exec_boundedDoublingStmt inp q10.2.1 hfp_b10 1 3 (Or.inl (by decide)) (by decide)
    100 (by omega) 4 hwB_b10 (hrtar_u_b10 ▸ htar_u_ub) with
    ⟨mb11, Cap_u, q11, hfp_b11, hCapu_ge100, hCapu_lb, hCapu_ub, hwCapu_b11, hw_b11, hr_b11⟩
  rw [hrtar_u_b10] at hCapu_lb hCapu_ub
  push_cast at hCapu_ub

  -- P3.12..15: `zq`, `F_q`, `target_q`, and `Cap_q`
  let zq : ℝ := (ℓ : ℝ) * x ^ 2 * t ^ 2 / 2
  have q12 := exec_rSet_lit inp q11.2.1 17 0 zqExpr 40
    (by simp [zqExpr, xE, tE, evalRealExpr, evalIntExpr])
  let mb12 := rWrite mb11 17 0 zq
  have hmb12 : rWrite mb11 17 0 (evalRealExpr inp 0 mb11 zqExpr).1 = mb12 := by
    have ht_r : mb11.reals.read (.heap 1 0) = t := by
      change rRead mb11 1 0 = t
      rw [hr_b11, rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_b9]
      simp only [mb8, mb7, mb6, rRead_wWrite]; rw [hr_b5]
      rw [rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_b3 1 0 (Or.inl (by decide)),
          rRead_rWrite_of_ne _ _ (Or.inl (by decide)), rRead_rWrite_of_ne _ _ (Or.inr (by decide))]
      exact hrt₂
    have hv : (evalRealExpr inp 0 mb11 zqExpr).1 = zq := by
      dsimp only [zqExpr, xE, tE, evalRealExpr, evalIntExpr, zq]
      rw [hextra1, ht_r]
      push_cast; norm_num; ring
    exact congrArg (rWrite mb11 17 0) hv
  rw [hmb12] at q12
  have hfp_b12 : InParamFootprint mb12 := inParamFootprint_rWrite hfp_b11 (by decide)

  have hwN_b12 : wRead mb12 11 2 = (N : ℤ) := by
    simp only [mb12, wRead_rWrite]; rw [hw_b11 11 2 (Or.inl (by decide))]
    simp only [mb10, wRead_rWrite]; rw [hw_b9 11 2 (Or.inr (by decide))]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        hw_b5 11 2 (Or.inl (by decide))]
    simp only [mb4, wRead_rWrite]; rw [hw_b3]; exact hwN_b2
  rcases exec_pow1PlusZStmt inp q12.2.1 hfp_b12 hwN_b12 with
    ⟨mb13, q13, hfp_b13, hw_b13, hr_b13, hpow_b13⟩
  let F_q : ℝ := (1 + zq / (N : ℝ)) ^ N
  have hzq_b12 : rRead mb12 17 0 = zq := rRead_rWrite_self _ _ _ _
  have hFq_eq : rRead mb13 17 1 = F_q := by simpa [F_q, hzq_b12] using hpow_b13

  have hzq_nonneg : 0 ≤ zq := by dsimp [zq]; positivity
  have hN_zq : 3 * zq ^ 2 + 1 ≤ (N : ℝ) := by
    have hx0' : 0 ≤ x := le_trans hh0.le hx0
    have hx_sq_le : x ^ 2 ≤ 1 ^ 2 := pow_le_pow_left₀ hx0' hx1 2
    have hzq_le : zq ≤ (ℓ : ℝ) * (L + 2 : ℝ) ^ 2 / 2 := by
      dsimp [zq]
      have hxt : x ^ 2 * t ^ 2 ≤ 1 * (L + 2 : ℝ) ^ 2 :=
        mul_le_mul (by linarith only [hx_sq_le]) htsq_bound (sq_nonneg t) zero_le_one
      have hmul := mul_le_mul_of_nonneg_left hxt (by positivity : 0 ≤ (ℓ : ℝ))
      linarith only [hmul]
    have hsq0 : zq ^ 2 ≤ ((ℓ : ℝ) * (L + 2 : ℝ) ^ 2 / 2) ^ 2 :=
      pow_le_pow_left₀ hzq_nonneg hzq_le 2
    have hsq_id : ((ℓ : ℝ) * (L + 2 : ℝ) ^ 2 / 2) ^ 2 = ((ℓ : ℝ) ^ 2 * (L + 2 : ℝ) ^ 4) / 4 := by
      ring
    have hsq4 : 4 * zq ^ 2 ≤ (ℓ : ℝ) ^ 2 * (L + 2 : ℝ) ^ 4 := by linarith only [hsq0, hsq_id]
    have hN_r : (N : ℝ) = 3 * ((ℓ : ℝ) ^ 2 * (L + 2 : ℝ) ^ 4) + 1 := by
      dsimp [N]; push_cast; ring
    have hzq_sq0 : 0 ≤ zq ^ 2 := sq_nonneg zq
    linarith only [hsq4, hN_r, hzq_sq0]
  rcases one_plus_div_pow_approx hzq_nonneg hN_zq with ⟨hFq_ge1, hFq_le_exp, hexp_le_2Fq⟩

  let target_q : ℝ := 100 * ((A : ℝ) / F_q + 1)
  have q14 := exec_rSet_lit inp q13.2.1 17 5
    (.mul (.ofInt (.lit 100))
      (.add (.div (.ofInt (.readHeap 11 (.lit 5))) (.readRealHeap 17 (.lit 1))) (.ofInt (.lit 1)))) 20
    (by simp [evalRealExpr, evalIntExpr])
  let mb14 := rWrite mb13 17 5 target_q
  have hmb14 : rWrite mb13 17 5
      (evalRealExpr inp 0 mb13
        (.mul (.ofInt (.lit 100))
          (.add (.div (.ofInt (.readHeap 11 (.lit 5))) (.readRealHeap 17 (.lit 1)))
            (.ofInt (.lit 1))))).1 = mb14 := by
    congr 1
    have hA_r : mb13.words.read (.heap 11 5) = (A : ℤ) := by
      change wRead mb13 11 5 = (A : ℤ)
      rw [hw_b13]; simp only [mb12, wRead_rWrite]; rw [hw_b11 11 5 (Or.inl (by decide))]
      simp only [mb10, wRead_rWrite]; exact hwA_b9
    have hFq_r : mb13.reals.read (.heap 17 1) = F_q := hFq_eq
    simp [evalRealExpr, evalIntExpr, hA_r, hFq_r, target_q]
  rw [hmb14] at q14
  have hfp_b14 : InParamFootprint mb14 := inParamFootprint_rWrite hfp_b13 (by decide)

  have htar_q_ub : target_q ≤ ((100 : ℕ) : ℝ) * (2 : ℝ) ^ B_max := by
    have hdiv_le : (A : ℝ) / F_q ≤ (A : ℝ) := div_le_self (by positivity) hFq_ge1
    have hA1 : (A : ℝ) + 1 ≤ 2 * (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2)) := by
      have h1_le : (1 : ℝ) ≤ (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2)) :=
        one_le_pow₀ (by norm_num)
      linarith only [hA_pow_ub, h1_le]
    have hexp_le : ℓ * (C_base + 1 + 3 * (L + 2) ^ 2) + 1 ≤ B_max := by
      dsimp only [B_max]; nlinarith only [hℓ]
    have h2pow : 2 * (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2)) ≤ (2 : ℝ) ^ B_max := by
      calc 2 * (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2))
          = (2 : ℝ) ^ (ℓ * (C_base + 1 + 3 * (L + 2) ^ 2) + 1) := by rw [pow_succ]; ring
        _ ≤ (2 : ℝ) ^ B_max := pow_le_pow_right₀ (by norm_num) hexp_le
    push_cast
    dsimp [target_q]; linarith only [hdiv_le, hA1, h2pow]

  have hwB_b14 : wRead mb14 11 6 = (B_max : ℤ) := by
    simp only [mb14, wRead_rWrite]; rw [hw_b13]; simp only [mb12, wRead_rWrite]
    rw [hw_b11 11 6 (Or.inl (by decide))]; exact hwB_b10
  have hrtar_q_b14 : rRead mb14 17 5 = target_q := rRead_rWrite_self _ _ _ _
  rcases exec_boundedDoublingStmt inp q14.2.1 hfp_b14 1 4 (Or.inl (by decide)) (by decide)
    100 (by omega) 5 hwB_b14 (hrtar_q_b14 ▸ htar_q_ub) with
    ⟨mem₃, Cap_q, q15, hfp₃, hCapq_ge100, hCapq_lb, hCapq_ub, hwCapq₃, hw₃, hr₃⟩
  rw [hrtar_q_b14] at hCapq_lb hCapq_ub
  push_cast at hCapq_ub

  have hp3 : ExecStmt inp (stepP3Stmt ℓ C_base) mem₂ mem₃
      (350 + 2 * (20 + N * 20) + 3 * (20 + B_max * 20) + ℓ * 10) := by
    unfold stepP3Stmt
    exact (ExecStmt.seq q1 (ExecStmt.seq q2 (ExecStmt.seq q3 (ExecStmt.seq q4
      (ExecStmt.seq q5 (ExecStmt.seq q6 (ExecStmt.seq q7 (ExecStmt.seq q8
        (ExecStmt.seq q9 (ExecStmt.seq q10 (ExecStmt.seq q11 (ExecStmt.seq q12
          (ExecStmt.seq q13 (ExecStmt.seq q14 q15)))))))))))))).mono_cost (by omega)

  have hw00 : wRead mem₃ 0 0 = ((ℓ * M₀ : ℕ) : ℤ) := by
    rw [hw₃ 0 0 (Or.inl (by decide))]; simp only [mb14, wRead_rWrite]; rw [hw_b13]
    simp only [mb12, wRead_rWrite]; rw [hw_b11 0 0 (Or.inl (by decide))]
    simp only [mb10, wRead_rWrite]; rw [hw_b9 0 0 (Or.inl (by decide))]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]; exact wRead_wWrite_self _ _ _ _
  have hw10 : wRead mem₃ 1 0 = (m : ℤ) := by
    rw [hw₃ 1 0 (Or.inr (by decide))]; simp only [mb14, wRead_rWrite]; rw [hw_b13]
    simp only [mb12, wRead_rWrite]; rw [hw_b11 1 0 (Or.inr (by decide))]
    simp only [mb10, wRead_rWrite]; rw [hw_b9 1 0 (Or.inl (by decide))]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        hw_b5 1 0 (Or.inr (by decide))]
    simp only [mb4, wRead_rWrite]; rw [hw_b3]
    simp only [mb2, mb1, wRead_rWrite]; exact hwm₂
  have hw11 : wRead mem₃ 1 1 = (M₀ : ℤ) := by
    rw [hw₃ 1 1 (Or.inr (by decide))]; simp only [mb14, wRead_rWrite]; rw [hw_b13]
    simp only [mb12, wRead_rWrite]; rw [hw_b11 1 1 (Or.inr (by decide))]
    simp only [mb10, wRead_rWrite]; rw [hw_b9 1 1 (Or.inl (by decide))]
    exact hwM₀_b8
  have hw12 : wRead mem₃ 1 2 = ((ℓ * M₀ : ℕ) : ℤ) := by
    rw [hw₃ 1 2 (Or.inr (by decide))]; simp only [mb14, wRead_rWrite]; rw [hw_b13]
    simp only [mb12, wRead_rWrite]; rw [hw_b11 1 2 (Or.inr (by decide))]
    simp only [mb10, wRead_rWrite]; rw [hw_b9 1 2 (Or.inl (by decide))]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
    exact wRead_wWrite_self _ _ _ _
  have hw13 : wRead mem₃ 1 3 = (Cap_u : ℤ) := by
    rw [hw₃ 1 3 (Or.inr (by decide))]; simp only [mb14, wRead_rWrite]; rw [hw_b13]
    simp only [mb12, wRead_rWrite]; exact hwCapu_b11
  have hw14 : wRead mem₃ 1 4 = (Cap_q : ℤ) := hwCapq₃
  have hr10 : rRead mem₃ 1 0 = t := by
    rw [hr₃, rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_b13 1 0 (Or.inl (by decide)),
        rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_b11,
        rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_b9]
    simp only [mb8, mb7, mb6, rRead_wWrite]; rw [hr_b5]
    rw [rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_b3 1 0 (Or.inl (by decide)),
        rRead_rWrite_of_ne _ _ (Or.inl (by decide)), rRead_rWrite_of_ne _ _ (Or.inr (by decide))]
    exact hrt₂
  have hr11 : rRead mem₃ 1 1 = x * t := by
    rw [hr₃, rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_b13 1 1 (Or.inl (by decide)),
        rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_b11,
        rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_b9]
    simp only [mb8, mb7, mb6, rRead_wWrite]; rw [hr_b5]
    rw [rRead_rWrite_of_ne _ _ (Or.inl (by decide)), hr_b3 1 1 (Or.inl (by decide)),
        rRead_rWrite_of_ne _ _ (Or.inl (by decide))]
    exact rRead_rWrite_self _ _ _ _

  exact ⟨mem₃, M₀, Cap_u, Cap_q, F1, F_q, hp3, hfp₃,
    hM₀_ge1, hCapu_ge100, hCapq_ge100,
    hw00, hw10, hw11, hw12, hw13, hw14, hr10, hr11,
    hF1_ge1, hF1_le_exp, hexp_le_2F1, hM₀_lb, hM₀_ub,
    hCapu_lb, hCapu_ub, hFq_ge1, hFq_le_exp, hexp_le_2Fq, hCapq_lb, hCapq_ub⟩

/-- Main execution and analytic specification of `buildParamStmt ℓ C_base`. -/
theorem run_buildParamStmt {d : ℕ} (ℓ C_base : ℕ) (hℓ : 1 ≤ ℓ) (hC_base : 1 ≤ C_base)
    (m : ℕ) (hm : 1 ≤ m) (h x : ℝ)
    (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1) :
    let inp : ArithRAMInput d :=
      { intParams := [(m : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0, extraReals := [h, x] }
    let L : ℕ := natBitLength m
    let C_scale : ℝ := max (Real.exp ((ℓ : ℝ) / 2)) (4 * Real.exp 3)
    let C_M : ℝ := 1 + 2 * (C_base : ℝ) * C_scale ^ (2 : ℝ)
    let cost_bound : ℕ := 1000 * (ℓ + C_base + 1) ^ 4 * (L + 2) ^ 6
    ∃ (pOut : ArithRAMExecOutcome) (t : ℝ) (M₀ Cap_u Cap_q : ℕ),
      runArithRAMWithBits (buildParamStmt ℓ C_base) inp ArithRAMMemory.empty [] = some pOut ∧
      CleanMem pOut.mem ∧
      InParamFootprint pOut.mem ∧
      pOut.unitCost ≤ cost_bound ∧
      pOut.peakCellSpace ≤ 24 ∧
      1 ≤ t ∧ t ≤ (L + 2 : ℝ) ∧
      1 ≤ M₀ ∧ 1 ≤ Cap_u ∧ 1 ≤ Cap_q ∧
      wRead pOut.mem 0 0 = ((ℓ * M₀ : ℕ) : ℤ) ∧
      wRead pOut.mem 1 0 = (m : ℤ) ∧
      wRead pOut.mem 1 1 = (M₀ : ℤ) ∧
      wRead pOut.mem 1 2 = ((ℓ * M₀ : ℕ) : ℤ) ∧
      wRead pOut.mem 1 3 = (Cap_u : ℤ) ∧
      wRead pOut.mem 1 4 = (Cap_q : ℤ) ∧
      rRead pOut.mem 1 0 = t ∧
      rRead pOut.mem 1 1 = x * t ∧
      (M₀ : ℝ) ≤ C_M * ((L + 2 : ℝ) ^ 2) * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) ∧
      (Cap_u : ℝ) ≤ 400 * (C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) + 1) * (m : ℝ) ^ (u_search h x) ∧
      (Cap_q : ℝ) ≤ 400 * (2 * C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) + 1) * (m : ℝ) ^ (q_search h x) ∧
      (C_base : ℝ) * t ^ 2 * ((1 / 2 : ℝ) * Real.exp (I_h h x * t ^ 2 / 2)) ≤ (M₀ : ℝ) ∧
      100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t ^ 2 / 2)) + 1) ≤ (Cap_u : ℝ) ∧
      100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) + 1) ≤ (Cap_q : ℝ) ∧
      100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * (1 + x ^ 2) * t ^ 2 / 2)) + 1) ≤
        (Cap_q : ℝ) := by
  intro inp L C_scale C_M cost_bound
  have hL_pos : 1 ≤ L := by unfold L natBitLength; omega
  rcases I_h_bounds hh0 hh1 hx0 hx1 with ⟨hI_ge, hI_le, hu0, _, hq0, _⟩
  rcases exec_stepP1Stmt (d := d) m hm h x with ⟨mem₁, hp1, hfp₁, hwm₁, hwb₁⟩
  rcases exec_stepP2Stmt ℓ C_base hℓ m hm h x hp1.2.1 hfp₁ hwm₁ hwb₁ with
    ⟨mem₂, t, F_u, hp2, hfp₂, hwm₂, _, hwN₂, hwB₂, hrt₂, hrF₂,
     ht_lo, ht_hi, hFu_ge1, hFu_ge2m, hFu_le_exp, hexp_ub⟩
  rcases exec_stepP3Stmt ℓ C_base hℓ m h x hh0 hx0 hx1 mem₂ t F_u
    hp2.2.1 hfp₂ hwm₂ hwN₂ hwB₂ hrt₂ hrF₂ ht_lo ht_hi hFu_ge1 (by linarith only [hI_ge]) hI_le with
    ⟨mem₃, M₀, Cap_u, Cap_q, F1, F_q, hp3, hfp₃,
     hM₀_ge1, hCapu_ge100, hCapq_ge100,
     hw00, hw10, hw11, hw12, hw13, hw14, hr10, hr11,
     hF1_ge1, hF1_le_exp, hexp_le_2F1, hM₀_lb, hM₀_ub,
     hCapu_lb, hCapu_ub, hFq_ge1, hFq_le_exp, hexp_le_2Fq, hCapq_lb, hCapq_ub⟩

  let N : ℕ := 3 * ℓ * ℓ * (L + 2) ^ 4 + 1
  let B_max : ℕ := (ℓ + 1) * (C_base + 2 + 3 * (L + 2) ^ 2)
  let K_max : ℕ := ℓ * L * (L + 1)

  change ExecStmt inp stepP1Stmt ArithRAMMemory.empty mem₁ (40 + 30 * L) at hp1
  change ExecStmt inp (stepP2Stmt ℓ C_base) mem₁ mem₂ (200 + N * 20 + K_max * (120 + N * 20)) at hp2
  change ExecStmt inp (stepP3Stmt ℓ C_base) mem₂ mem₃
    (350 + 2 * (20 + N * 20) + 3 * (20 + B_max * 20) + ℓ * 10) at hp3

  have hcost_tot :
      (40 + 30 * L) + ((200 + N * 20 + K_max * (120 + N * 20)) +
        (350 + 2 * (20 + N * 20) + 3 * (20 + B_max * 20) + ℓ * 10)) ≤ cost_bound := by
    set P : ℕ := ℓ + C_base + 1
    set Q : ℕ := L + 2
    have hP3 : 3 ≤ P := by omega
    have hQ3 : 3 ≤ Q := by omega
    have hP_pos : 0 < P := by omega
    have hQ_pos : 0 < Q := by omega
    have hP2_le : P ^ 2 ≤ P ^ 4 := Nat.pow_le_pow_right hP_pos (by omega)
    have hP3_le : P ^ 3 ≤ P ^ 4 := Nat.pow_le_pow_right hP_pos (by omega)
    have hQ2_le : Q ^ 2 ≤ Q ^ 6 := Nat.pow_le_pow_right hQ_pos (by omega)
    have hQ4_le : Q ^ 4 ≤ Q ^ 6 := Nat.pow_le_pow_right hQ_pos (by omega)
    have hN_ub : N ≤ 4 * P ^ 2 * Q ^ 4 := by
      have hℓP : ℓ ≤ P := by omega
      have hℓ2 : ℓ * ℓ ≤ P ^ 2 := by simpa [sq] using Nat.mul_le_mul hℓP hℓP
      have h3 : 3 * ℓ * ℓ * Q ^ 4 ≤ 3 * P ^ 2 * Q ^ 4 := by
        calc 3 * ℓ * ℓ * Q ^ 4 = 3 * (ℓ * ℓ) * Q ^ 4 := by ring
          _ ≤ 3 * P ^ 2 * Q ^ 4 :=
              Nat.mul_le_mul_right (Q ^ 4) (Nat.mul_le_mul_left 3 hℓ2)
      have h1 : 1 ≤ P ^ 2 * Q ^ 4 :=
        Nat.mul_le_mul (Nat.one_le_pow 2 P hP_pos) (Nat.one_le_pow 4 Q hQ_pos)
      calc N = 3 * ℓ * ℓ * Q ^ 4 + 1 := rfl
        _ ≤ 3 * P ^ 2 * Q ^ 4 + P ^ 2 * Q ^ 4 := Nat.add_le_add h3 h1
        _ = 4 * P ^ 2 * Q ^ 4 := by ring
    have hN_pq : N ≤ 4 * (P ^ 4 * Q ^ 6) := by
      calc N ≤ 4 * P ^ 2 * Q ^ 4 := hN_ub
        _ ≤ 4 * P ^ 4 * Q ^ 6 :=
            Nat.mul_le_mul (Nat.mul_le_mul_left 4 hP2_le) hQ4_le
        _ = 4 * (P ^ 4 * Q ^ 6) := by ring
    have hK_ub : K_max ≤ P * Q ^ 2 := by
      have h1 : ℓ ≤ P := by omega
      have h2 : L * (L + 1) ≤ Q ^ 2 := by
        have hLQ : L ≤ Q := by omega
        have hL1Q : L + 1 ≤ Q := by omega
        simpa [sq] using Nat.mul_le_mul hLQ hL1Q
      calc K_max = ℓ * (L * (L + 1)) := by dsimp [K_max]; ring
        _ ≤ P * Q ^ 2 := Nat.mul_le_mul h1 h2
    have h120N : 120 + N * 20 ≤ 100 * P ^ 2 * Q ^ 4 := by
      have h9 : 9 ≤ P ^ 2 := by
        simpa using Nat.pow_le_pow_left hP3 2
      have hq1 : 1 ≤ Q ^ 4 := Nat.one_le_pow 4 Q hQ_pos
      have h120 : 120 ≤ 20 * P ^ 2 * Q ^ 4 := by
        calc 120 ≤ 20 * 9 * 1 := by omega
          _ ≤ 20 * P ^ 2 * Q ^ 4 :=
              Nat.mul_le_mul (Nat.mul_le_mul_left 20 h9) hq1
      have hN20 : N * 20 ≤ 80 * P ^ 2 * Q ^ 4 := by
        calc N * 20 ≤ (4 * P ^ 2 * Q ^ 4) * 20 := Nat.mul_le_mul_right 20 hN_ub
          _ = 80 * P ^ 2 * Q ^ 4 := by ring
      calc 120 + N * 20 ≤ 20 * P ^ 2 * Q ^ 4 + 80 * P ^ 2 * Q ^ 4 := Nat.add_le_add h120 hN20
        _ = 100 * P ^ 2 * Q ^ 4 := by ring
    have hKN_pq : K_max * (120 + N * 20) ≤ 100 * (P ^ 4 * Q ^ 6) := by
      calc K_max * (120 + N * 20) ≤ (P * Q ^ 2) * (100 * P ^ 2 * Q ^ 4) := Nat.mul_le_mul hK_ub h120N
        _ = 100 * P ^ 3 * Q ^ 6 := by ring
        _ ≤ 100 * P ^ 4 * Q ^ 6 := Nat.mul_le_mul_right (Q ^ 6) (Nat.mul_le_mul_left 100 hP3_le)
        _ = 100 * (P ^ 4 * Q ^ 6) := by ring
    have hB_pq : B_max ≤ 4 * (P ^ 4 * Q ^ 6) := by
      have h1 : ℓ + 1 ≤ P := by omega
      have h2 : C_base + 2 + 3 * Q ^ 2 ≤ 4 * P * Q ^ 2 := by
        have hcP : C_base + 2 ≤ P * 1 := by omega
        have hq1 : 1 ≤ Q ^ 2 := Nat.one_le_pow 2 Q hQ_pos
        have hcPQ : C_base + 2 ≤ P * Q ^ 2 := le_trans hcP (Nat.mul_le_mul_left P hq1)
        have h3PQ : 3 * Q ^ 2 ≤ 3 * P * Q ^ 2 :=
          Nat.mul_le_mul_right (Q ^ 2) (by omega : 3 ≤ 3 * P)
        calc C_base + 2 + 3 * Q ^ 2 ≤ P * Q ^ 2 + 3 * P * Q ^ 2 := Nat.add_le_add hcPQ h3PQ
          _ = 4 * P * Q ^ 2 := by ring
      calc B_max = (ℓ + 1) * (C_base + 2 + 3 * Q ^ 2) := rfl
        _ ≤ P * (4 * P * Q ^ 2) := Nat.mul_le_mul h1 h2
        _ = 4 * P ^ 2 * Q ^ 2 := by ring
        _ ≤ 4 * P ^ 4 * Q ^ 6 := Nat.mul_le_mul (Nat.mul_le_mul_left 4 hP2_le) hQ2_le
        _ = 4 * (P ^ 4 * Q ^ 6) := by ring
    have hPQ_big : 1000 ≤ P ^ 4 * Q ^ 6 := by
      calc 1000 ≤ 3 ^ 4 * 3 ^ 6 := by decide
        _ ≤ P ^ 4 * Q ^ 6 := Nat.mul_le_mul (Nat.pow_le_pow_left hP3 4) (Nat.pow_le_pow_left hQ3 6)
    have hL_pq : L ≤ P ^ 4 * Q ^ 6 := by
      have hLQ : L ≤ Q := by omega
      have h1 : 1 ≤ P ^ 4 := Nat.one_le_pow 4 P hP_pos
      have h2 : Q ≤ Q ^ 6 := Nat.le_self_pow (by omega) Q
      exact le_trans hLQ (by simpa using Nat.mul_le_mul h1 h2)
    have hℓ_pq : ℓ ≤ P ^ 4 * Q ^ 6 := by
      have hℓP : ℓ ≤ P := by omega
      have h1 : P ≤ P ^ 4 := Nat.le_self_pow (by omega) P
      have h2 : 1 ≤ Q ^ 6 := Nat.one_le_pow 6 Q hQ_pos
      exact le_trans hℓP (by simpa using Nat.mul_le_mul h1 h2)
    have hcb : cost_bound = 1000 * (P ^ 4 * Q ^ 6) := by dsimp [cost_bound, P, Q]; ring
    rw [hcb]
    generalize P ^ 4 * Q ^ 6 = M_pq at hPQ_big hN_pq hKN_pq hB_pq hL_pq hℓ_pq ⊢
    omega

  have hexec_all : ExecStmt inp (buildParamStmt ℓ C_base) ArithRAMMemory.empty mem₃ cost_bound :=
    (ExecStmt.seq hp1 (ExecStmt.seq hp2 hp3)).mono_cost hcost_tot

  rcases hexec_all.to_run with ⟨pOut, hrun, hpOut_mem, hpOut_cost, hpOut_space⟩

  have hspace_le : pOut.peakCellSpace ≤ 24 := by
    have hinp_sp : inp.inputCellSpace = 3 := by
      simp [inp, ArithRAMInput.inputCellSpace]
    have hcc := cellCount_le_of_inParamFootprint hfp₃
    omega

  -- Exponent and probability inequalities
  have hCscale_ge1 : 1 ≤ C_scale := by
    have : 1 ≤ Real.exp ((ℓ : ℝ) / 2) := Real.one_le_exp (by positivity)
    exact this.trans (le_max_left _ _)
  have hm_ge1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
  have hm_pos : (0 : ℝ) < (m : ℝ) := by positivity
  let base_exp : ℝ := I_h h x / (ℓ : ℝ)
  have hbase_nonneg : 0 ≤ base_exp := div_nonneg (by linarith only [hI_ge]) (by positivity)
  have hbase_le2 : base_exp ≤ 2 := by
    dsimp [base_exp]
    have hℓ1 : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
    exact (div_le_self (by linarith only [hI_ge]) hℓ1).trans hI_le

  let z1 : ℝ := I_h h x * t ^ 2 / 2
  have hexp_z1_ub : Real.exp z1 ≤ C_scale ^ (2 : ℝ) * (m : ℝ) ^ base_exp := by
    have heq : z1 = ((ℓ : ℝ) * t ^ 2 / 2) * base_exp := by
      dsimp [z1, base_exp]
      have hℓ_ne : (ℓ : ℝ) ≠ 0 := by positivity
      field_simp
    calc Real.exp z1 = (Real.exp ((ℓ : ℝ) * t ^ 2 / 2)) ^ base_exp := by
          rw [heq, Real.exp_mul]
      _ ≤ (C_scale * (m : ℝ)) ^ base_exp :=
          Real.rpow_le_rpow (Real.exp_pos _).le hexp_ub hbase_nonneg
      _ = C_scale ^ base_exp * (m : ℝ) ^ base_exp :=
          Real.mul_rpow (by positivity) hm_pos.le
      _ ≤ C_scale ^ (2 : ℝ) * (m : ℝ) ^ base_exp :=
          mul_le_mul_of_nonneg_right (Real.rpow_le_rpow_of_exponent_le hCscale_ge1 hbase_le2)
            (Real.rpow_nonneg hm_pos.le _)

  have hM₀_rpow_ub : (M₀ : ℝ) ≤ C_M * ((L + 2 : ℝ) ^ 2) * (m : ℝ) ^ base_exp := by
    let R1 : ℝ := (C_base : ℝ) * t ^ 2 * F1
    have hR1_nonneg : 0 ≤ R1 := by dsimp [R1]; positivity
    have hR1_ub : R1 ≤ (C_base : ℝ) * ((L + 2 : ℝ) ^ 2) * C_scale ^ (2 : ℝ) * (m : ℝ) ^ base_exp := by
      have htsq : t ^ 2 ≤ (L + 2 : ℝ) ^ 2 :=
        pow_le_pow_left₀ (by linarith only [ht_lo]) ht_hi 2
      calc R1 = (C_base : ℝ) * t ^ 2 * F1 := rfl
        _ ≤ (C_base : ℝ) * ((L + 2 : ℝ) ^ 2) * Real.exp z1 :=
            mul_le_mul (mul_le_mul_of_nonneg_left htsq (by positivity)) hF1_le_exp
              (by linarith only [hF1_ge1]) (by positivity)
        _ ≤ (C_base : ℝ) * ((L + 2 : ℝ) ^ 2) * (C_scale ^ (2 : ℝ) * (m : ℝ) ^ base_exp) :=
            mul_le_mul_of_nonneg_left hexp_z1_ub (by positivity)
        _ = (C_base : ℝ) * ((L + 2 : ℝ) ^ 2) * C_scale ^ (2 : ℝ) * (m : ℝ) ^ base_exp := by ring
    have hm_base_ge1 : 1 ≤ (m : ℝ) ^ base_exp := Real.one_le_rpow hm_ge1 hbase_nonneg
    have hL2_ge1 : 1 ≤ (L + 2 : ℝ) ^ 2 := by
      have : (1 : ℝ) ≤ (L + 2 : ℝ) := by exact_mod_cast (show 1 ≤ L + 2 by omega)
      nlinarith only [this]
    have h1_le : 1 ≤ (L + 2 : ℝ) ^ 2 * (m : ℝ) ^ base_exp := by
      simpa using mul_le_mul hL2_ge1 hm_base_ge1 zero_le_one (by linarith only [hL2_ge1])
    have hM₀_le_sum : (M₀ : ℝ) ≤ 1 + 2 * R1 := by
      refine hM₀_ub.trans (max_le ?_ ?_) <;> linarith only [hR1_nonneg]
    calc (M₀ : ℝ) ≤ 1 + 2 * R1 := hM₀_le_sum
      _ ≤ (L + 2 : ℝ) ^ 2 * (m : ℝ) ^ base_exp +
          2 * ((C_base : ℝ) * ((L + 2 : ℝ) ^ 2) * C_scale ^ (2 : ℝ) * (m : ℝ) ^ base_exp) := by
          linarith only [h1_le, hR1_ub]
      _ = C_M * ((L + 2 : ℝ) ^ 2) * (m : ℝ) ^ base_exp := by dsimp [C_M]; ring

  let A : ℕ := M₀ ^ ℓ
  have hA_rpow_ub : (A : ℝ) ≤ C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (I_h h x) := by
    have hm_pow_ell : ((m : ℝ) ^ base_exp) ^ ℓ = (m : ℝ) ^ (I_h h x) := by
      rw [← Real.rpow_natCast, ← Real.rpow_mul hm_pos.le]
      congr 1; dsimp [base_exp]
      have hℓ_ne : (ℓ : ℝ) ≠ 0 := by positivity
      field_simp
    calc (A : ℝ) = (M₀ : ℝ) ^ ℓ := by simp [A]
      _ ≤ (C_M * ((L + 2 : ℝ) ^ 2) * (m : ℝ) ^ base_exp) ^ ℓ :=
          pow_le_pow_left₀ (by positivity) hM₀_rpow_ub ℓ
      _ = C_M ^ ℓ * (((L + 2 : ℝ) ^ 2) ^ ℓ) * (((m : ℝ) ^ base_exp) ^ ℓ) := by
          rw [mul_pow, mul_pow]
      _ = C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (I_h h x) := by
          rw [← pow_mul, hm_pow_ell]

  have hCapu_rpow_ub :
      (Cap_u : ℝ) ≤ 400 * (C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) + 1) * (m : ℝ) ^ (u_search h x) := by
    have hm_Ih : (m : ℝ) ^ (I_h h x) = (m : ℝ) ^ (u_search h x) * (m : ℝ) := by
      have hrew : I_h h x = u_search h x + 1 := by unfold u_search; ring
      rw [hrew, Real.rpow_add_one hm_pos.ne']
    have hdiv_u : (A : ℝ) / F_u ≤ C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (u_search h x) := by
      rw [div_le_iff₀ (by linarith only [hFu_ge1])]
      calc (A : ℝ) ≤ C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * ((m : ℝ) ^ (u_search h x) * (m : ℝ)) := by
            rw [← hm_Ih]; exact hA_rpow_ub
        _ ≤ C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * ((m : ℝ) ^ (u_search h x) * F_u) := by
            gcongr; linarith only [hFu_ge2m, hm_pos]
        _ = C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (u_search h x) * F_u := by ring
    have hmu_ge1 : 1 ≤ (m : ℝ) ^ (u_search h x) := Real.one_le_rpow hm_ge1 hu0
    let target_u : ℝ := 100 * ((A : ℝ) / F_u + 1)
    have htar_ge100 : (100 : ℝ) ≤ 2 * target_u := by
      have hdiv0 : 0 ≤ (A : ℝ) / F_u := by positivity
      dsimp [target_u]; linarith only [hdiv0]
    have hCapu_2tar : (Cap_u : ℝ) ≤ 2 * target_u := hCapu_ub.trans (max_eq_right htar_ge100).le
    calc (Cap_u : ℝ) ≤ 2 * (100 * ((A : ℝ) / F_u + 1)) := hCapu_2tar
      _ ≤ 200 * (C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (u_search h x) +
          1 * (m : ℝ) ^ (u_search h x)) := by linarith only [hdiv_u, hmu_ge1]
      _ = 200 * (C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) + 1) * (m : ℝ) ^ (u_search h x) := by ring
      _ ≤ 400 * (C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) + 1) * (m : ℝ) ^ (u_search h x) := by
          have hp0 : 0 ≤ (C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) + 1) * (m : ℝ) ^ (u_search h x) := by
            dsimp [C_M]; positivity
          linarith only [hp0]

  have hCapq_rpow_ub :
      (Cap_q : ℝ) ≤ 400 * (2 * C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) + 1) * (m : ℝ) ^ (q_search h x) := by
    let zq : ℝ := (ℓ : ℝ) * x ^ 2 * t ^ 2 / 2
    have hmx2_le : (m : ℝ) ^ (x ^ 2) ≤ 2 * F_q := by
      have hm_le_exp : (m : ℝ) ≤ Real.exp ((ℓ : ℝ) * t ^ 2 / 2) := by
        linarith only [hFu_ge2m, hFu_le_exp, hm_pos]
      have hx2_nonneg : 0 ≤ x ^ 2 := sq_nonneg x
      have h1 : (m : ℝ) ^ (x ^ 2) ≤ (Real.exp ((ℓ : ℝ) * t ^ 2 / 2)) ^ (x ^ 2) :=
        Real.rpow_le_rpow hm_pos.le hm_le_exp hx2_nonneg
      have h2 : (Real.exp ((ℓ : ℝ) * t ^ 2 / 2)) ^ (x ^ 2) = Real.exp zq := by
        rw [← Real.exp_mul]; congr 1; dsimp [zq]; ring
      linarith only [h1, h2, hexp_le_2Fq]
    have hm_Ih_q : (m : ℝ) ^ (I_h h x) = (m : ℝ) ^ (q_search h x) * (m : ℝ) ^ (x ^ 2) := by
      have hrew : I_h h x = q_search h x + x ^ 2 := by unfold q_search; ring
      rw [hrew, Real.rpow_add hm_pos]
    have hdiv_q : (A : ℝ) / F_q ≤ 2 * C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (q_search h x) := by
      rw [div_le_iff₀ (by linarith only [hFq_ge1])]
      calc (A : ℝ) ≤ C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * ((m : ℝ) ^ (q_search h x) * (m : ℝ) ^ (x ^ 2)) := by
            rw [← hm_Ih_q]; exact hA_rpow_ub
        _ ≤ C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * ((m : ℝ) ^ (q_search h x) * (2 * F_q)) := by
            have hCM_nonneg : 0 ≤ C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) := by dsimp [C_M]; positivity
            exact mul_le_mul_of_nonneg_left
              (mul_le_mul_of_nonneg_left hmx2_le (Real.rpow_nonneg hm_pos.le _)) hCM_nonneg
        _ = 2 * C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (q_search h x) * F_q := by ring
    have hmq_ge1 : 1 ≤ (m : ℝ) ^ (q_search h x) := Real.one_le_rpow hm_ge1 hq0
    let target_q : ℝ := 100 * ((A : ℝ) / F_q + 1)
    have htar_ge100 : (100 : ℝ) ≤ 2 * target_q := by
      have hdiv0 : 0 ≤ (A : ℝ) / F_q := by positivity
      dsimp [target_q]; linarith only [hdiv0]
    have hCapq_2tar : (Cap_q : ℝ) ≤ 2 * target_q := hCapq_ub.trans (max_eq_right htar_ge100).le
    calc (Cap_q : ℝ) ≤ 2 * (100 * ((A : ℝ) / F_q + 1)) := hCapq_2tar
      _ ≤ 200 * (2 * C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (q_search h x) +
          1 * (m : ℝ) ^ (q_search h x)) := by linarith only [hdiv_q, hmq_ge1]
      _ = 200 * (2 * C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) + 1) * (m : ℝ) ^ (q_search h x) := by ring
      _ ≤ 400 * (2 * C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) + 1) * (m : ℝ) ^ (q_search h x) := by
          have hp0 : 0 ≤ (2 * C_M ^ ℓ * ((L + 2 : ℝ) ^ (2 * ℓ)) + 1) * (m : ℝ) ^ (q_search h x) := by
            dsimp [C_M]; positivity
          linarith only [hp0]

  -- Lower bounds on `M₀`, `Cap_u`, `Cap_q` for probability estimates
  have hM₀_prob_lb : (C_base : ℝ) * t ^ 2 * ((1 / 2 : ℝ) * Real.exp (I_h h x * t ^ 2 / 2)) ≤ (M₀ : ℝ) := by
    have hhalf : (1 / 2 : ℝ) * Real.exp z1 ≤ F1 := by linarith only [hexp_le_2F1]
    have hmul : (C_base : ℝ) * t ^ 2 * ((1 / 2 : ℝ) * Real.exp z1) ≤ (C_base : ℝ) * t ^ 2 * F1 :=
      mul_le_mul_of_nonneg_left hhalf (by positivity)
    exact hmul.trans hM₀_lb

  have hCapu_prob_lb : 100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t ^ 2 / 2)) + 1) ≤ (Cap_u : ℝ) := by
    have hexp_inv : Real.exp (-((ℓ : ℝ) * t ^ 2 / 2)) ≤ 1 / F_u := by
      rw [Real.exp_neg, one_div]
      exact inv_anti₀ (by linarith only [hFu_ge1]) hFu_le_exp
    have hmul : (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t ^ 2 / 2)) ≤ (A : ℝ) / F_u := by
      calc (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t ^ 2 / 2))
          ≤ (M₀ : ℝ) ^ ℓ * (1 / F_u) := mul_le_mul_of_nonneg_left hexp_inv (by positivity)
        _ = (A : ℝ) / F_u := by simp [A, div_eq_mul_inv]
    exact (by linarith only [hmul] : _ ≤ 100 * ((A : ℝ) / F_u + 1)).trans hCapu_lb

  have hCapq_prob_lb :
      100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) + 1) ≤ (Cap_q : ℝ) := by
    have hexp_inv : Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) ≤ 1 / F_q := by
      rw [Real.exp_neg, one_div]
      exact inv_anti₀ (by linarith only [hFq_ge1]) hFq_le_exp
    have hmul : (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) ≤ (A : ℝ) / F_q := by
      calc (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2))
          ≤ (M₀ : ℝ) ^ ℓ * (1 / F_q) := mul_le_mul_of_nonneg_left hexp_inv (by positivity)
        _ = (A : ℝ) / F_q := by simp [A, div_eq_mul_inv]
    exact (by linarith only [hmul] : _ ≤ 100 * ((A : ℝ) / F_q + 1)).trans hCapq_lb

  have hCapq_bad_lb :
      100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * (1 + x ^ 2) * t ^ 2 / 2)) + 1) ≤
        (Cap_q : ℝ) := by
    have hsplit : Real.exp (-((ℓ : ℝ) * (1 + x ^ 2) * t ^ 2 / 2)) =
        Real.exp (-((ℓ : ℝ) * t ^ 2 / 2)) * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) := by
      rw [← Real.exp_add]; congr 1; ring
    have hm_exp_le_one : (m : ℝ) * Real.exp (-((ℓ : ℝ) * t ^ 2 / 2)) ≤ 1 := by
      rw [Real.exp_neg]
      have h2m_exp : 2 * (m : ℝ) ≤ Real.exp ((ℓ : ℝ) * t ^ 2 / 2) := hFu_ge2m.trans hFu_le_exp
      exact (mul_inv_le_iff₀ (Real.exp_pos _)).mpr (by linarith only [h2m_exp, hm_pos])
    have hprod_le :
        (m : ℝ) * (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * (1 + x ^ 2) * t ^ 2 / 2)) ≤
          (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) := by
      rw [hsplit]
      calc (m : ℝ) * (M₀ : ℝ) ^ ℓ *
            (Real.exp (-((ℓ : ℝ) * t ^ 2 / 2)) * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)))
          = ((m : ℝ) * Real.exp (-((ℓ : ℝ) * t ^ 2 / 2))) *
              ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2))) := by ring
        _ ≤ 1 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2))) :=
              mul_le_mul_of_nonneg_right hm_exp_le_one (by positivity)
        _ = (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2)) := one_mul _
    linarith only [hprod_le, hCapq_prob_lb]

  refine ⟨pOut, t, M₀, Cap_u, Cap_q, hrun, ?_, ?_, hpOut_cost, hspace_le,
    ht_lo, ht_hi, hM₀_ge1, by omega, by omega,
    ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_,
    hM₀_rpow_ub, hCapu_rpow_ub, hCapq_rpow_ub,
    hM₀_prob_lb, hCapu_prob_lb, hCapq_prob_lb, hCapq_bad_lb⟩
  all_goals rw [hpOut_mem]
  · exact hexec_all.2.1
  · exact hfp₃
  · exact hw00
  · exact hw10
  · exact hw11
  · exact hw12
  · exact hw13
  · exact hw14
  · exact hr10
  · exact hr11

end UL.Proof_lem_6_3
