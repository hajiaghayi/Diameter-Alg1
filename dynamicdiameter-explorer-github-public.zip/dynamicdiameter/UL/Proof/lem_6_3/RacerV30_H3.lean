import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_6_1_gaussian_filter
import UL.Proof.lem_6_3.H1_RAM
import UL.Proof.lem_6_3.H5_Prob
import UL.Proof.lem_6_3.RacerV30_H2
set_option autoImplicit false

namespace UL.Proof.lem_6_3.RacerV30

open UL.Proof_lem_6_3

/-! ### 1. Telescoping `repeatN`, reusable footprint `(SW, SR)`, and opaque step helpers -/

theorem ExecStmt.repeatN_telescope {d : ℕ} {inp : ArithRAMInput d} (countE : IntExpr)
    (body : ArithRAMStmt) (N C_cnt A B : ℕ) (f : ℕ → ℕ)
    (hf_mono : ∀ i < N, f i ≤ f (i + 1))
    (Inv : ℕ → ArithRAMMemory → Prop)
    {mem₀ : ArithRAMMemory} (hc₀ : CleanMem mem₀) (hInv₀ : Inv 0 mem₀)
    (hcnt : (evalIntExpr inp.toWordView 0 mem₀.words countE).1 = (N : ℤ))
    (hucnt : (evalIntExpr inp.toWordView 0 mem₀.words countE).2.1 ≤ C_cnt)
    (hstep : ∀ i < N, ∀ m : ArithRAMMemory, CleanMem m → Inv i m →
      ∃ m', ExecStmt inp body m m' (A + B * (f (i + 1) - f i)) ∧ Inv (i + 1) m') :
    ∃ mem_N : ArithRAMMemory,
      Inv N mem_N ∧
      ExecStmt inp (.repeatN countE body) mem₀ mem_N (C_cnt + N * A + B * (f N - f 0)) := by
  set u_cnt := (evalIntExpr inp.toWordView 0 mem₀.words countE).2.1
  have hev := evalIntExpr_eq inp.toWordView mem₀.words countE (N : ℤ) u_cnt hcnt rfl
  have hf_le : ∀ i j, i ≤ j → j ≤ N → f i ≤ f j := by
    intro i j hij hjN
    induction hij with
    | refl => exact le_rfl
    | @step m hm ih => exact (ih (by omega)).trans (hf_mono m (by omega))
  have hloop : ∀ k : ℕ, k ≤ N → ∀ m : ArithRAMMemory, CleanMem m → Inv (N - k) m →
      ∃ m_N : ArithRAMMemory, CleanMem m_N ∧ Inv N m_N ∧
        ∀ (u₀ : ℕ) (rest : List ArithRAMCont),
          ∃ (fuel₀ u₁ : ℕ),
            u₁ ≤ u₀ + k * A + B * (f N - f (N - k)) ∧
            ∀ fuel : ℕ,
              runArithRAMFuel inp (fuel₀ + fuel) (.repeatLoop k body :: rest) (mkState inp m u₀) =
                runArithRAMFuel inp fuel rest (mkState inp m_N u₁) := by
    intro k
    induction k with
    | zero =>
        intro _ m hcm hIm
        rw [Nat.sub_zero] at hIm ⊢
        refine ⟨m, hcm, hIm, fun u₀ rest => ⟨1, u₀, by simp, fun fuel => ?_⟩⟩
        rw [Nat.add_comm 1 fuel]
        rfl
    | succ k ih =>
        intro hk m hcm hIm
        have hi_lt : N - (k + 1) < N := by omega
        have hsucc : N - (k + 1) + 1 = N - k := by omega
        rcases hstep (N - (k + 1)) hi_lt m hcm hIm with ⟨m', hbody, hIm'⟩
        rw [hsucc] at hbody hIm'
        rcases ih (by omega) m' hbody.2.1 hIm' with ⟨m_N, hcm_N, hIm_N, hrest⟩
        refine ⟨m_N, hcm_N, hIm_N, fun u₀ rest => ?_⟩
        rcases hbody.2.2 u₀ (.repeatLoop k body :: rest) with ⟨f₁, u₁, hu₁, hs₁⟩
        rcases hrest u₁ rest with ⟨f₂, u₂, hu₂, hs₂⟩
        have hfx : f (N - (k + 1)) ≤ f (N - k) := hf_le _ _ (by omega) (by omega)
        have hfy : f (N - k) ≤ f N := hf_le _ _ (by omega) le_rfl
        refine ⟨1 + f₁ + f₂, u₂, ?_, fun fuel => ?_⟩
        · set d₁ := f (N - k) - f (N - (k + 1))
          set d₂ := f N - f (N - k)
          have hd : f N - f (N - (k + 1)) = d₁ + d₂ := by omega
          rw [hd]
          have hbound : u₂ ≤ u₀ + (A + B * d₁) + k * A + B * d₂ := by omega
          calc u₂ ≤ u₀ + (A + B * d₁) + k * A + B * d₂ := hbound
            _ = u₀ + (k + 1) * A + B * (d₁ + d₂) := by ring
        · have hfuel : 1 + f₁ + f₂ + fuel = (f₁ + (f₂ + fuel)) + 1 := by omega
          rw [hfuel]
          dsimp only [runArithRAMFuel]
          rw [hs₁ (f₂ + fuel), hs₂ fuel]
  rcases hloop N le_rfl mem₀ hc₀ (by simpa using hInv₀) with ⟨m_N, hcm_N, hIm_N, hrun⟩
  rw [Nat.sub_self] at hrun
  refine ⟨m_N, hIm_N, hc₀, hcm_N, fun u₀ rest => ?_⟩
  rcases hrun (u₀ + u_cnt) rest with ⟨f₁, u₁, hu₁, hs₁⟩
  refine ⟨1 + f₁, u₁, by omega, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + fuel = (f₁ + fuel) + 1 := by omega
  rw [hfuel]
  have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
  dsimp only [runArithRAMFuel, mkState]
  rw [hev]
  dsimp only
  rw [hnIter]
  exact hs₁ fuel

def rangeHeap (t : ℕ) (N : ℕ) : Finset RAMCellLoc :=
  (Finset.range N).image (fun i : ℕ => RAMCellLoc.heap t (i : ℤ))

theorem mem_rangeHeap {t : ℕ} {N i : ℕ} (hi : i < N) :
    RAMCellLoc.heap t (i : ℤ) ∈ rangeHeap t N :=
  Finset.mem_image_of_mem _ (Finset.mem_range.mpr hi)

theorem card_rangeHeap_le (t N : ℕ) : (rangeHeap t N).card ≤ N := by
  unfold rangeHeap
  exact Finset.card_image_le.trans (by simp)

def scratchWords (ℓ M₀ Cap_q : ℕ) : Finset RAMCellLoc :=
  rangeHeap 0 (Cap_q + 3) ∪ rangeHeap 1 10 ∪ rangeHeap 5 (ℓ + 1) ∪
    rangeHeap 6 (ℓ * M₀ + 1) ∪ rangeHeap 11 32

def scratchReals (d ℓ M₀ : ℕ) : Finset RAMCellLoc :=
  rangeHeap 1 5 ∪ rangeHeap 2 (ℓ * M₀ * d + 1) ∪ rangeHeap 3 (d + 1) ∪ rangeHeap 17 16

theorem card_scratch_le (d ℓ M₀ Cap_q : ℕ) :
    (scratchWords ℓ M₀ Cap_q).card + (scratchReals d ℓ M₀).card ≤
      Cap_q + ℓ * M₀ * (d + 1) + d + ℓ + 70 := by
  have hw : (scratchWords ℓ M₀ Cap_q).card ≤ (Cap_q + 3) + 10 + (ℓ + 1) + (ℓ * M₀ + 1) + 32 := by
    unfold scratchWords
    calc _ ≤ (rangeHeap 0 (Cap_q + 3) ∪ rangeHeap 1 10 ∪ rangeHeap 5 (ℓ + 1) ∪
              rangeHeap 6 (ℓ * M₀ + 1)).card + (rangeHeap 11 32).card := Finset.card_union_le _ _
      _ ≤ (rangeHeap 0 (Cap_q + 3) ∪ rangeHeap 1 10 ∪ rangeHeap 5 (ℓ + 1)).card +
            (rangeHeap 6 (ℓ * M₀ + 1)).card + (rangeHeap 11 32).card := by
          gcongr; exact Finset.card_union_le _ _
      _ ≤ (rangeHeap 0 (Cap_q + 3) ∪ rangeHeap 1 10).card + (rangeHeap 5 (ℓ + 1)).card +
            (rangeHeap 6 (ℓ * M₀ + 1)).card + (rangeHeap 11 32).card := by
          gcongr; exact Finset.card_union_le _ _
      _ ≤ (rangeHeap 0 (Cap_q + 3)).card + (rangeHeap 1 10).card + (rangeHeap 5 (ℓ + 1)).card +
            (rangeHeap 6 (ℓ * M₀ + 1)).card + (rangeHeap 11 32).card := by
          gcongr; exact Finset.card_union_le _ _
      _ ≤ (Cap_q + 3) + 10 + (ℓ + 1) + (ℓ * M₀ + 1) + 32 := by
          gcongr <;> exact card_rangeHeap_le _ _
  have hr : (scratchReals d ℓ M₀).card ≤ 5 + (ℓ * M₀ * d + 1) + (d + 1) + 16 := by
    unfold scratchReals
    calc _ ≤ (rangeHeap 1 5 ∪ rangeHeap 2 (ℓ * M₀ * d + 1) ∪ rangeHeap 3 (d + 1)).card +
            (rangeHeap 17 16).card := Finset.card_union_le _ _
      _ ≤ (rangeHeap 1 5 ∪ rangeHeap 2 (ℓ * M₀ * d + 1)).card + (rangeHeap 3 (d + 1)).card +
            (rangeHeap 17 16).card := by
          gcongr; exact Finset.card_union_le _ _
      _ ≤ (rangeHeap 1 5).card + (rangeHeap 2 (ℓ * M₀ * d + 1)).card +
            (rangeHeap 3 (d + 1)).card + (rangeHeap 17 16).card := by
          gcongr; exact Finset.card_union_le _ _
      _ ≤ 5 + (ℓ * M₀ * d + 1) + (d + 1) + 16 := by
          gcongr <;> exact card_rangeHeap_le _ _
  have hm : ℓ * M₀ + ℓ * M₀ * d = ℓ * M₀ * (d + 1) := by ring
  omega

/-- Number of live cells in `mem` outside `(SW, SR)`. -/
def extraCells (SW SR : Finset RAMCellLoc) (mem : ArithRAMMemory) : ℕ :=
  (mem.words.live \ SW).card + (mem.reals.live \ SR).card

theorem cellCount_le_card_add_extraCells (SW SR : Finset RAMCellLoc) (mem : ArithRAMMemory) :
    mem.cellCount ≤ SW.card + SR.card + extraCells SW SR mem := by
  unfold ArithRAMMemory.cellCount WordStore.cellCount RealStore.cellCount extraCells
  have hw : mem.words.live.card ≤ SW.card + (mem.words.live \ SW).card := by
    have hsub : mem.words.live ⊆ SW ∪ (mem.words.live \ SW) := by
      intro x hx; by_cases h : x ∈ SW <;> simp [hx, h]
    exact (Finset.card_le_card hsub).trans (Finset.card_union_le _ _)
  have hr : mem.reals.live.card ≤ SR.card + (mem.reals.live \ SR).card := by
    have hsub : mem.reals.live ⊆ SR ∪ (mem.reals.live \ SR) := by
      intro x hx; by_cases h : x ∈ SR <;> simp [hx, h]
    exact (Finset.card_le_card hsub).trans (Finset.card_union_le _ _)
  omega

theorem extraCells_eq_zero_of_inParamFootprint {mem : ArithRAMMemory}
    (hfp : InParamFootprint mem) (d ℓ M₀ Cap_q : ℕ) :
    extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) mem = 0 := by
  rcases inParamFootprint_subsets hfp with ⟨hfp_w, hfp_r⟩
  unfold extraCells
  have hw : mem.words.live \ scratchWords ℓ M₀ Cap_q = ∅ := by
    rw [Finset.sdiff_eq_empty_iff_subset]
    refine hfp_w.trans ?_
    intro loc hloc
    have hm : loc ∈ paramWordList := List.mem_toFinset.mp hloc
    simp only [paramWordList, List.mem_cons, List.not_mem_nil, or_false] at hm
    unfold scratchWords
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
        (Finset.mem_union_left _ (mem_rangeHeap (i := 0) (by omega)))))
    · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
        (Finset.mem_union_right _ (mem_rangeHeap (i := 0) (by omega)))))
    · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
        (Finset.mem_union_right _ (mem_rangeHeap (i := 1) (by omega)))))
    · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
        (Finset.mem_union_right _ (mem_rangeHeap (i := 2) (by omega)))))
    · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
        (Finset.mem_union_right _ (mem_rangeHeap (i := 3) (by omega)))))
    · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
        (Finset.mem_union_right _ (mem_rangeHeap (i := 4) (by omega)))))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 0) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 1) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 2) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 3) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 4) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 5) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 6) (by omega))
  have hr : mem.reals.live \ scratchReals d ℓ M₀ = ∅ := by
    rw [Finset.sdiff_eq_empty_iff_subset]
    refine hfp_r.trans ?_
    intro loc hloc
    have hm : loc ∈ paramRealList := List.mem_toFinset.mp hloc
    simp only [paramRealList, List.mem_cons, List.not_mem_nil, or_false] at hm
    unfold scratchReals
    rcases hm with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact Finset.mem_union_left _ (Finset.mem_union_left _
        (Finset.mem_union_left _ (mem_rangeHeap (i := 0) (by omega))))
    · exact Finset.mem_union_left _ (Finset.mem_union_left _
        (Finset.mem_union_left _ (mem_rangeHeap (i := 1) (by omega))))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 0) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 1) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 2) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 3) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 4) (by omega))
    · exact Finset.mem_union_right _ (mem_rangeHeap (i := 5) (by omega))
  simp [hw, hr]

theorem extraCells_wWrite_mem {SW SR : Finset RAMCellLoc} (mem : ArithRAMMemory)
    {t : ℕ} {i v : ℤ} (hmem : RAMCellLoc.heap t i ∈ SW) :
    extraCells SW SR (wWrite mem t i v) = extraCells SW SR mem := by
  unfold extraCells wWrite WordStore.write
  congr 2
  ext loc
  simp only [Finset.mem_sdiff, Finset.mem_insert]
  constructor
  · rintro ⟨rfl | h1, h2⟩
    · exact absurd hmem h2
    · exact ⟨h1, h2⟩
  · rintro ⟨h1, h2⟩
    exact ⟨Or.inr h1, h2⟩

theorem extraCells_rWrite_mem {SW SR : Finset RAMCellLoc} (mem : ArithRAMMemory)
    {t : ℕ} {i : ℤ} {v : ℝ} (hmem : RAMCellLoc.heap t i ∈ SR) :
    extraCells SW SR (rWrite mem t i v) = extraCells SW SR mem := by
  unfold extraCells rWrite RealStore.write
  congr 1
  congr 1
  ext loc
  simp only [Finset.mem_sdiff, Finset.mem_insert]
  constructor
  · rintro ⟨rfl | h1, h2⟩
    · exact absurd hmem h2
    · exact ⟨h1, h2⟩
  · rintro ⟨h1, h2⟩
    exact ⟨Or.inr h1, h2⟩

theorem extraCells_wWrite_le (SW SR : Finset RAMCellLoc) (mem : ArithRAMMemory)
    (t : ℕ) (i v : ℤ) :
    extraCells SW SR (wWrite mem t i v) ≤ extraCells SW SR mem + 1 := by
  unfold extraCells wWrite WordStore.write
  have hsub : (insert (RAMCellLoc.heap t i) mem.words.live) \ SW ⊆
      insert (RAMCellLoc.heap t i) (mem.words.live \ SW) := by
    intro loc hloc
    simp only [Finset.mem_sdiff, Finset.mem_insert] at hloc ⊢
    rcases hloc with ⟨rfl | h1, h2⟩
    · exact Or.inl rfl
    · exact Or.inr ⟨h1, h2⟩
  have hcard := (Finset.card_le_card hsub).trans (Finset.card_insert_le _ _)
  dsimp only
  omega

theorem mem_scratchWords_0 {ℓ M₀ Cap_q i : ℕ} (hi : i < Cap_q + 3) :
    RAMCellLoc.heap 0 (i : ℤ) ∈ scratchWords ℓ M₀ Cap_q :=
  Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_union_left _
    (Finset.mem_union_left _ (mem_rangeHeap hi))))

theorem mem_scratchWords_5 {ℓ M₀ Cap_q i : ℕ} (hi : i < ℓ + 1) :
    RAMCellLoc.heap 5 (i : ℤ) ∈ scratchWords ℓ M₀ Cap_q :=
  Finset.mem_union_left _ (Finset.mem_union_left _
    (Finset.mem_union_right _ (mem_rangeHeap hi)))

theorem mem_scratchWords_6 {ℓ M₀ Cap_q i : ℕ} (hi : i < ℓ * M₀ + 1) :
    RAMCellLoc.heap 6 (i : ℤ) ∈ scratchWords ℓ M₀ Cap_q :=
  Finset.mem_union_left _ (Finset.mem_union_right _ (mem_rangeHeap hi))

theorem mem_scratchWords_11 {ℓ M₀ Cap_q i : ℕ} (hi : i < 32) :
    RAMCellLoc.heap 11 (i : ℤ) ∈ scratchWords ℓ M₀ Cap_q :=
  Finset.mem_union_right _ (mem_rangeHeap hi)

theorem mem_scratchReals_2 {d ℓ M₀ i : ℕ} (hi : i < ℓ * M₀ * d + 1) :
    RAMCellLoc.heap 2 (i : ℤ) ∈ scratchReals d ℓ M₀ :=
  Finset.mem_union_left _ (Finset.mem_union_left _
    (Finset.mem_union_right _ (mem_rangeHeap hi)))

theorem mem_scratchReals_3 {d ℓ M₀ i : ℕ} (hi : i < d + 1) :
    RAMCellLoc.heap 3 (i : ℤ) ∈ scratchReals d ℓ M₀ :=
  Finset.mem_union_left _ (Finset.mem_union_right _ (mem_rangeHeap hi))

theorem mem_scratchReals_17 {d ℓ M₀ i : ℕ} (hi : i < 16) :
    RAMCellLoc.heap 17 (i : ℤ) ∈ scratchReals d ℓ M₀ :=
  Finset.mem_union_right _ (mem_rangeHeap hi)

theorem exec_wSet_sw {d : ℕ} (SW SR : Finset RAMCellLoc) (inp : ArithRAMInput d)
    {mem : ArithRAMMemory} (hc : CleanMem mem)
    (t : ℕ) (idxE : IntExpr) (idx : ℤ) (hmem : RAMCellLoc.heap t idx ∈ SW)
    (valE : IntExpr) (val : ℤ) (C : ℕ)
    (hidx : (evalIntExpr inp.toWordView 0 mem.words idxE).1 = idx)
    (hval : (evalIntExpr inp.toWordView 0 mem.words valE).1 = val)
    (hcost : (evalIntExpr inp.toWordView 0 mem.words idxE).2.1 +
      (evalIntExpr inp.toWordView 0 mem.words valE).2.1 + 1 ≤ C) :
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp (.writeWordHeap t idxE valE) mem mem' C ∧
      extraCells SW SR mem' = extraCells SW SR mem ∧
      wRead mem' t idx = val ∧
      (∀ t' i', (t' ≠ t ∨ i' ≠ idx) → wRead mem' t' i' = wRead mem t' i') ∧
      (∀ t' i', rRead mem' t' i' = rRead mem t' i') := by
  have hi := evalIntExpr_eq inp.toWordView mem.words idxE idx
    (evalIntExpr inp.toWordView 0 mem.words idxE).2.1 hidx rfl
  have hv := evalIntExpr_eq inp.toWordView mem.words valE val
    (evalIntExpr inp.toWordView 0 mem.words valE).2.1 hval rfl
  exact ⟨wWrite mem t idx val,
    ExecStmt.writeWordHeap inp hc t idxE valE hi hv hcost,
    extraCells_wWrite_mem mem hmem,
    wRead_wWrite_self mem t idx val,
    fun t' i' hne => wRead_wWrite_of_ne mem val hne,
    fun _ _ => rfl⟩

theorem exec_wSet_any {d : ℕ} (SW SR : Finset RAMCellLoc) (inp : ArithRAMInput d)
    {mem : ArithRAMMemory} (hc : CleanMem mem)
    (t : ℕ) (idxE : IntExpr) (idx : ℤ)
    (valE : IntExpr) (val : ℤ) (C : ℕ)
    (hidx : (evalIntExpr inp.toWordView 0 mem.words idxE).1 = idx)
    (hval : (evalIntExpr inp.toWordView 0 mem.words valE).1 = val)
    (hcost : (evalIntExpr inp.toWordView 0 mem.words idxE).2.1 +
      (evalIntExpr inp.toWordView 0 mem.words valE).2.1 + 1 ≤ C) :
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp (.writeWordHeap t idxE valE) mem mem' C ∧
      extraCells SW SR mem' ≤ extraCells SW SR mem + 1 ∧
      wRead mem' t idx = val ∧
      (∀ t' i', (t' ≠ t ∨ i' ≠ idx) → wRead mem' t' i' = wRead mem t' i') ∧
      (∀ t' i', rRead mem' t' i' = rRead mem t' i') := by
  have hi := evalIntExpr_eq inp.toWordView mem.words idxE idx
    (evalIntExpr inp.toWordView 0 mem.words idxE).2.1 hidx rfl
  have hv := evalIntExpr_eq inp.toWordView mem.words valE val
    (evalIntExpr inp.toWordView 0 mem.words valE).2.1 hval rfl
  exact ⟨wWrite mem t idx val,
    ExecStmt.writeWordHeap inp hc t idxE valE hi hv hcost,
    extraCells_wWrite_le SW SR mem t idx val,
    wRead_wWrite_self mem t idx val,
    fun t' i' hne => wRead_wWrite_of_ne mem val hne,
    fun _ _ => rfl⟩

theorem exec_rSet_sr {d : ℕ} (SW SR : Finset RAMCellLoc) (inp : ArithRAMInput d)
    {mem : ArithRAMMemory} (hc : CleanMem mem)
    (t : ℕ) (idxE : IntExpr) (idx : ℤ) (hmem : RAMCellLoc.heap t idx ∈ SR)
    (valE : RealExpr) (val : ℝ) (C : ℕ)
    (hidx : (evalIntExpr inp.toWordView 0 mem.words idxE).1 = idx)
    (hval : (evalRealExpr inp 0 mem valE).1 = val)
    (hcost : (evalIntExpr inp.toWordView 0 mem.words idxE).2.1 +
      (evalRealExpr inp 0 mem valE).2 + 1 ≤ C) :
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp (.writeRealHeap t idxE valE) mem mem' C ∧
      extraCells SW SR mem' = extraCells SW SR mem ∧
      rRead mem' t idx = val ∧
      (∀ t' i', wRead mem' t' i' = wRead mem t' i') ∧
      (∀ t' i', (t' ≠ t ∨ i' ≠ idx) → rRead mem' t' i' = rRead mem t' i') := by
  have hi := evalIntExpr_eq inp.toWordView mem.words idxE idx
    (evalIntExpr inp.toWordView 0 mem.words idxE).2.1 hidx rfl
  cases hev : evalRealExpr inp 0 mem valE with
  | mk v₀ u₂ =>
    rw [hev] at hval hcost
    dsimp at hval hcost
    rw [hval] at hev
    exact ⟨rWrite mem t idx val,
      ExecStmt.writeRealHeap inp hc t idxE valE hi hev hcost,
      extraCells_rWrite_mem mem hmem,
      rRead_rWrite_self mem t idx val,
      fun _ _ => rfl,
      fun t' i' hne => rRead_rWrite_of_ne mem val hne⟩

/-! ### 2. Mixed-radix Cartesian product enumeration and Horner base-`M₀` encoding -/

def prodPrefix (c : ℕ → ℕ) : ℕ → ℕ
  | 0 => 1
  | j + 1 => prodPrefix c j * c j

theorem prodPrefix_pos {c : ℕ → ℕ} {n : ℕ} (hc : ∀ j < n, 1 ≤ c j) :
    1 ≤ prodPrefix c n := by
  induction n with
  | zero => simp [prodPrefix]
  | succ n ih =>
      simp only [prodPrefix]
      exact Nat.mul_pos (ih fun j hj => hc j (by omega)) (hc n (by omega))

theorem prodPrefix_pos_iff {c : ℕ → ℕ} {n : ℕ} :
    1 ≤ prodPrefix c n ↔ ∀ j < n, 1 ≤ c j := by
  constructor
  · intro h
    induction n with
    | zero => intro j hj; omega
    | succ n ih =>
        simp only [prodPrefix] at h
        have h1 : 1 ≤ prodPrefix c n := by
          by_contra h0; have : prodPrefix c n = 0 := by omega
          rw [this, zero_mul] at h; omega
        have h2 : 1 ≤ c n := by
          by_contra h0; have : c n = 0 := by omega
          rw [this, mul_zero] at h; omega
        intro j hj
        rcases Nat.lt_succ_iff_lt_or_eq.mp hj with hlt | rfl
        · exact ih h1 j hlt
        · exact h2
  · exact prodPrefix_pos

theorem prodPrefix_eq_prod (ℓ : ℕ) (f : Fin ℓ → ℕ) :
    prodPrefix (fun j => if hj : j < ℓ then f ⟨j, hj⟩ else 1) ℓ = ∏ j : Fin ℓ, f j := by
  induction ℓ with
  | zero => simp [prodPrefix]
  | succ n ih =>
      rw [Fin.prod_univ_castSucc]
      simp only [prodPrefix, Nat.lt_succ_self, ↓reduceDIte]
      congr 1
      have hcongr : prodPrefix (fun j => if hj : j < n + 1 then f ⟨j, hj⟩ else 1) n =
          prodPrefix (fun j => if hj : j < n then f ⟨j, Nat.lt_succ_of_lt hj⟩ else 1) n := by
        clear ih
        suffices ∀ k ≤ n,
            prodPrefix (fun j => if hj : j < n + 1 then f ⟨j, hj⟩ else 1) k =
              prodPrefix (fun j => if hj : j < n then f ⟨j, Nat.lt_succ_of_lt hj⟩ else 1) k from
          this n le_rfl
        intro k hk
        induction k with
        | zero => rfl
        | succ k ihk =>
            have hk_lt : k < n := by omega
            have hk_lt' : k < n + 1 := by omega
            simp only [prodPrefix, ihk (by omega), hk_lt, hk_lt', ↓reduceDIte]
      rw [hcongr]
      exact ih (fun j => f j.castSucc)

theorem prodPrefix_dvd (c : ℕ → ℕ) {n m : ℕ} (h : n ≤ m) :
    ∃ K : ℕ, prodPrefix c m = prodPrefix c n * K := by
  induction h with
  | refl => exact ⟨1, by simp⟩
  | @step k _ ih =>
      rcases ih with ⟨K, hK⟩
      exact ⟨K * c k, by simp [prodPrefix, hK, mul_assoc]⟩

def remStep (c : ℕ → ℕ) (idx : ℕ) : ℕ → ℕ
  | 0 => idx
  | j + 1 => remStep c idx j / c j

def posAt (c : ℕ → ℕ) (idx j : ℕ) : ℕ :=
  remStep c idx j % c j

theorem posAt_lt {c : ℕ → ℕ} (idx j : ℕ) (hc : 1 ≤ c j) :
    posAt c idx j < c j :=
  Nat.mod_lt _ (by omega)

theorem remStep_eq_div (c : ℕ → ℕ) (idx : ℕ) :
    ∀ j : ℕ, remStep c idx j = idx / prodPrefix c j
  | 0 => by simp [remStep, prodPrefix]
  | j + 1 => by
      simp only [remStep, prodPrefix, remStep_eq_div c idx j]
      exact Nat.div_div_eq_div_mul idx (prodPrefix c j) (c j)

theorem mod_prodPrefix_succ {c : ℕ → ℕ} (idx n : ℕ)
    (hP : 1 ≤ prodPrefix c n) (hq : 1 ≤ c n) :
    idx % prodPrefix c (n + 1) = idx % prodPrefix c n + prodPrefix c n * posAt c idx n := by
  set P := prodPrefix c n
  set q := c n
  change idx % (P * q) = idx % P + P * (remStep c idx n % q)
  rw [remStep_eq_div]
  set r₁ := idx % P
  set d₁ := idx / P
  have hr₁ : r₁ < P := Nat.mod_lt idx (by omega)
  have hd₁_mod : d₁ % q < q := Nat.mod_lt d₁ (by omega)
  have hid₁ : P * d₁ + r₁ = idx := Nat.div_add_mod idx P
  have hid₂ : q * (d₁ / q) + d₁ % q = d₁ := Nat.div_add_mod d₁ q
  have hlt : r₁ + P * (d₁ % q) < P * q := by
    have hle : d₁ % q + 1 ≤ q := by omega
    calc r₁ + P * (d₁ % q) < P + P * (d₁ % q) := by omega
      _ = P * (d₁ % q + 1) := by ring
      _ ≤ P * q := Nat.mul_le_mul_left P hle
  have hdecomp : idx = (r₁ + P * (d₁ % q)) + (P * q) * (d₁ / q) := by
    calc idx = P * d₁ + r₁ := hid₁.symm
      _ = P * (q * (d₁ / q) + d₁ % q) + r₁ := by rw [hid₂]
      _ = (r₁ + P * (d₁ % q)) + (P * q) * (d₁ / q) := by ring
  rw [hdecomp, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hlt]

theorem posAt_injective {c : ℕ → ℕ} {ℓ : ℕ} (hc : ∀ j < ℓ, 1 ≤ c j)
    {idx₁ idx₂ : ℕ} (h₁ : idx₁ < prodPrefix c ℓ) (h₂ : idx₂ < prodPrefix c ℓ)
    (heq : ∀ j < ℓ, posAt c idx₁ j = posAt c idx₂ j) :
    idx₁ = idx₂ := by
  suffices ∀ n ≤ ℓ, idx₁ % prodPrefix c n = idx₂ % prodPrefix c n by
    have hmod := this ℓ le_rfl
    rwa [Nat.mod_eq_of_lt h₁, Nat.mod_eq_of_lt h₂] at hmod
  intro n hn
  induction n with
  | zero => simp [prodPrefix, Nat.mod_one]
  | succ n ih =>
      have hP : 1 ≤ prodPrefix c n := prodPrefix_pos (fun j hj => hc j (by omega))
      have hq : 1 ≤ c n := hc n (by omega)
      rw [mod_prodPrefix_succ idx₁ n hP hq, mod_prodPrefix_succ idx₂ n hP hq,
        ih (by omega), heq n (by omega)]

def encodeMixed (c p : ℕ → ℕ) : ℕ → ℕ
  | 0 => 0
  | n + 1 => encodeMixed c p n + prodPrefix c n * p n

theorem encodeMixed_lt {c p : ℕ → ℕ} :
    ∀ n : ℕ, (∀ j < n, p j < c j) → encodeMixed c p n < prodPrefix c n
  | 0, _ => by simp [encodeMixed, prodPrefix]
  | n + 1, hp => by
      have ih := encodeMixed_lt n (fun j hj => hp j (by omega))
      have hpn : p n + 1 ≤ c n := hp n (by omega)
      simp only [encodeMixed, prodPrefix]
      calc encodeMixed c p n + prodPrefix c n * p n
          < prodPrefix c n + prodPrefix c n * p n := by omega
        _ = prodPrefix c n * (p n + 1) := by ring
        _ ≤ prodPrefix c n * c n := Nat.mul_le_mul_left _ hpn

theorem encodeMixed_split (c p : ℕ → ℕ) {n m : ℕ} (hm : n ≤ m) :
    ∃ Q : ℕ, encodeMixed c p m = encodeMixed c p n + prodPrefix c n * Q := by
  induction hm with
  | refl => exact ⟨0, by simp⟩
  | @step k hnk ih =>
      rcases ih with ⟨Q, hQ⟩
      rcases prodPrefix_dvd c hnk with ⟨K, hK⟩
      exact ⟨Q + K * p k, by simp only [encodeMixed, hQ, hK]; ring⟩

theorem posAt_encodeMixed {c p : ℕ → ℕ} {ℓ : ℕ} (hp : ∀ j < ℓ, p j < c j)
    {j : ℕ} (hj : j < ℓ) :
    posAt c (encodeMixed c p ℓ) j = p j := by
  rcases encodeMixed_split c p (Nat.succ_le_of_lt hj) with ⟨Q, hQ⟩
  have hlt_j : encodeMixed c p j < prodPrefix c j :=
    encodeMixed_lt j (fun i hi => hp i (by omega))
  have hP_pos : 0 < prodPrefix c j := by omega
  have hdecomp : encodeMixed c p ℓ =
      encodeMixed c p j + (p j + c j * Q) * prodPrefix c j := by
    simp only [encodeMixed, prodPrefix] at hQ
    linarith
  have hdiv : encodeMixed c p ℓ / prodPrefix c j = p j + c j * Q := by
    rw [hdecomp, Nat.add_mul_div_right _ _ hP_pos, Nat.div_eq_of_lt hlt_j, zero_add]
  unfold posAt
  rw [remStep_eq_div, hdiv, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt (hp j hj)]

def hornerStep (M₀ : ℕ) (f : ℕ → ℕ) : ℕ → ℕ
  | 0 => 0
  | j + 1 => hornerStep M₀ f j * M₀ + f j

theorem hornerStep_lt {M₀ : ℕ} {f : ℕ → ℕ} :
    ∀ n : ℕ, 1 ≤ M₀ → (∀ j < n, f j < M₀) → hornerStep M₀ f n < M₀ ^ n
  | 0, _, _ => by simp [hornerStep]
  | n + 1, hM₀, hf => by
      have ih := hornerStep_lt n hM₀ (fun j hj => hf j (by omega))
      have hfn : f n < M₀ := hf n (by omega)
      have hle : hornerStep M₀ f n + 1 ≤ M₀ ^ n := by omega
      simp only [hornerStep, pow_succ]
      calc hornerStep M₀ f n * M₀ + f n
          < hornerStep M₀ f n * M₀ + M₀ := by omega
        _ = (hornerStep M₀ f n + 1) * M₀ := by ring
        _ ≤ M₀ ^ n * M₀ := Nat.mul_le_mul_right M₀ hle

theorem hornerStep_injective {M₀ : ℕ} {f₁ f₂ : ℕ → ℕ} :
    ∀ n : ℕ, (∀ j < n, f₁ j < M₀) → (∀ j < n, f₂ j < M₀) →
      hornerStep M₀ f₁ n = hornerStep M₀ f₂ n → ∀ j < n, f₁ j = f₂ j
  | 0, _, _, _, j, hj => by omega
  | n + 1, hf₁, hf₂, heq, j, hj => by
      have hfn₁ : f₁ n < M₀ := hf₁ n (by omega)
      have hfn₂ : f₂ n < M₀ := hf₂ n (by omega)
      have hM₀_pos : 0 < M₀ := by omega
      simp only [hornerStep] at heq
      have hmod₁ : (hornerStep M₀ f₁ n * M₀ + f₁ n) % M₀ = f₁ n := by
        rw [Nat.mul_comm, Nat.mul_add_mod, Nat.mod_eq_of_lt hfn₁]
      have hmod₂ : (hornerStep M₀ f₂ n * M₀ + f₂ n) % M₀ = f₂ n := by
        rw [Nat.mul_comm, Nat.mul_add_mod, Nat.mod_eq_of_lt hfn₂]
      have hfn_eq : f₁ n = f₂ n := by
        have hm := congrArg (· % M₀) heq
        dsimp at hm
        rwa [hmod₁, hmod₂] at hm
      have hdiv₁ : (hornerStep M₀ f₁ n * M₀ + f₁ n) / M₀ = hornerStep M₀ f₁ n := by
        rw [Nat.mul_comm, Nat.mul_add_div hM₀_pos, Nat.div_eq_of_lt hfn₁, Nat.add_zero]
      have hdiv₂ : (hornerStep M₀ f₂ n * M₀ + f₂ n) / M₀ = hornerStep M₀ f₂ n := by
        rw [Nat.mul_comm, Nat.mul_add_div hM₀_pos, Nat.div_eq_of_lt hfn₂, Nat.add_zero]
      have hprev_eq : hornerStep M₀ f₁ n = hornerStep M₀ f₂ n := by
        have hd := congrArg (· / M₀) heq
        dsimp at hd
        rwa [hdiv₁, hdiv₂] at hd
      rcases Nat.lt_succ_iff_lt_or_eq.mp hj with hlt | rfl
      · exact hornerStep_injective n (fun i hi => hf₁ i (by omega))
          (fun i hi => hf₂ i (by omega)) hprev_eq j hlt
      · exact hfn_eq

def hornerTuple {ℓ M₀ : ℕ} (τ : Fin ℓ → Fin M₀) : ℕ :=
  hornerStep M₀ (fun j => if hj : j < ℓ then (τ ⟨j, hj⟩).1 else 0) ℓ

theorem hornerTuple_lt {ℓ M₀ : ℕ} (hM₀ : 1 ≤ M₀) (τ : Fin ℓ → Fin M₀) :
    hornerTuple τ < M₀ ^ ℓ :=
  hornerStep_lt ℓ hM₀ (fun j hj => by simp [hj, (τ ⟨j, hj⟩).2])

theorem hornerTuple_injective {ℓ M₀ : ℕ} :
    Function.Injective (@hornerTuple ℓ M₀) := by
  intro τ₁ τ₂ heq
  funext j
  apply Fin.ext
  have h := hornerStep_injective ℓ
    (fun i hi => by simp [hi, (τ₁ ⟨i, hi⟩).2])
    (fun i hi => by simp [hi, (τ₂ ⟨i, hi⟩).2])
    heq j.1 j.2
  simpa [j.2] using h

/-! ### 3. Exact dot-product prefix, eligible cap lists, and `computeBaseListsStmt` -/

noncomputable def dotSum (f g : ℕ → ℝ) : ℕ → ℝ
  | 0 => 0
  | n + 1 => dotSum f g n + f n * g n

theorem dotSum_eq_sum_range (f g : ℕ → ℝ) :
    ∀ n : ℕ, dotSum f g n = ∑ i ∈ Finset.range n, f i * g i
  | 0 => by simp [dotSum]
  | n + 1 => by simp [dotSum, Finset.sum_range_succ, dotSum_eq_sum_range f g n]

theorem dotSum_eq_inner {d : ℕ} (G v : EuclideanSpace ℝ (Fin d)) :
    dotSum (fun c => if hc : c < d then euclideanCoord G ⟨c, hc⟩ else 0)
      (fun c => if hc : c < d then euclideanCoord v ⟨c, hc⟩ else 0) d =
      inner ℝ G v := by
  rw [dotSum_eq_sum_range, PiLp.inner_apply,
    ← Fin.sum_univ_eq_sum_range
      (fun c => (if hc : c < d then euclideanCoord G ⟨c, hc⟩ else 0) *
        (if hc : c < d then euclideanCoord v ⟨c, hc⟩ else 0)) d]
  refine Finset.sum_congr rfl fun c _ => ?_
  simp only [c.2, ↓reduceDIte, Fin.eta, euclideanCoord, WithLp.equiv_apply,
    RCLike.inner_apply, conj_trivial]
  ring

noncomputable def eligPrefix {ℓ M₀ d : ℕ} (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d)) (j : Fin ℓ) : ℕ → List (Fin M₀)
  | 0 => []
  | s + 1 =>
      let prev := eligPrefix θ ω v j s
      open Classical in
      if hs : s < M₀ then
        if θ ≤ inner ℝ (ω (capIdx j ⟨s, hs⟩)) v then
          prev ++ [⟨s, hs⟩]
        else
          prev
      else
        prev

noncomputable def eligList {ℓ M₀ d : ℕ} (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d)) (j : Fin ℓ) : List (Fin M₀) :=
  eligPrefix θ ω v j M₀

theorem eligPrefix_spec {ℓ M₀ d : ℕ} (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d)) (j : Fin ℓ) :
    ∀ n ≤ M₀,
      (eligPrefix θ ω v j n).Nodup ∧
      (∀ x : Fin M₀, x ∈ eligPrefix θ ω v j n ↔
        x.1 < n ∧ θ ≤ inner ℝ (ω (capIdx j x)) v)
  | 0, _ => by simp [eligPrefix]
  | n + 1, hn => by
      have hn_lt : n < M₀ := by omega
      rcases eligPrefix_spec θ ω v j n (by omega) with ⟨hnod, hmem⟩
      classical
      simp only [eligPrefix, hn_lt, ↓reduceDIte]
      by_cases htest : θ ≤ inner ℝ (ω (capIdx j ⟨n, hn_lt⟩)) v
      · simp only [htest, ↓reduceIte]
        refine ⟨?_, fun x => ?_⟩
        · rw [List.nodup_append]
          refine ⟨hnod, List.nodup_singleton _, fun a ha b hb => ?_⟩
          rw [List.mem_singleton] at hb
          subst hb
          have ha_lt := (hmem a).mp ha |>.1
          intro heq
          rw [heq] at ha_lt
          exact Nat.lt_irrefl n ha_lt
        · rw [List.mem_append, List.mem_singleton, hmem x]
          constructor
          · rintro (⟨hx1, hx2⟩ | rfl)
            · exact ⟨by omega, hx2⟩
            · exact ⟨by simp, htest⟩
          · rintro ⟨hx1, hx2⟩
            rcases Nat.lt_succ_iff_lt_or_eq.mp hx1 with hlt | heq
            · exact Or.inl ⟨hlt, hx2⟩
            · right; apply Fin.ext; exact heq
      · simp only [htest, ↓reduceIte]
        refine ⟨hnod, fun x => ?_⟩
        rw [hmem x]
        constructor
        · rintro ⟨hx1, hx2⟩; exact ⟨by omega, hx2⟩
        · rintro ⟨hx1, hx2⟩
          rcases Nat.lt_succ_iff_lt_or_eq.mp hx1 with hlt | heq
          · exact ⟨hlt, hx2⟩
          · exfalso
            have hx_eq : x = ⟨n, hn_lt⟩ := Fin.ext heq
            rw [hx_eq] at hx2
            exact htest hx2

theorem eligList_nodup {ℓ M₀ d : ℕ} (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d)) (j : Fin ℓ) :
    (eligList θ ω v j).Nodup :=
  (eligPrefix_spec θ ω v j M₀ le_rfl).1

theorem mem_eligList_iff {ℓ M₀ d : ℕ} (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d)) (j : Fin ℓ) (s : Fin M₀) :
    s ∈ eligList θ ω v j ↔ θ ≤ inner ℝ (ω (capIdx j s)) v := by
  unfold eligList
  rw [(eligPrefix_spec θ ω v j M₀ le_rfl).2 s]
  exact ⟨fun h => h.2, fun h => ⟨s.2, h⟩⟩

theorem eligPrefix_length_le {ℓ M₀ d : ℕ} (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d)) (j : Fin ℓ) :
    ∀ n ≤ M₀, (eligPrefix θ ω v j n).length ≤ n
  | 0, _ => by simp [eligPrefix]
  | n + 1, hn => by
      have ih := eligPrefix_length_le θ ω v j n (by omega)
      have hn_lt : n < M₀ := by omega
      classical
      simp only [eligPrefix, hn_lt, ↓reduceDIte]
      split_ifs <;> simp <;> omega

theorem prod_eligList_eq_card {ℓ M₀ d : ℕ} (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d)) :
    (∏ j : Fin ℓ, (eligList θ ω v j).length) =
      (open Classical in
        (Finset.univ.filter (fun τ : Fin ℓ → Fin M₀ =>
          ∀ j : Fin ℓ, θ ≤ inner ℝ (ω (capIdx j (τ j))) v)).card) := by
  classical
  let S : Fin ℓ → Finset (Fin M₀) := fun j => (eligList θ ω v j).toFinset
  have hlen : ∀ j : Fin ℓ, (eligList θ ω v j).length = (S j).card := fun j =>
    (List.toFinset_card_of_nodup (eligList_nodup θ ω v j)).symm
  simp_rw [hlen, ← Fintype.card_piFinset]
  congr 1
  ext τ
  simp [Fintype.mem_piFinset, S, mem_eligList_iff]

theorem prod_eligList_eq_dataTupleCard {ℓ M₀ d : ℕ} (t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (p : EuclideanSpace ℝ (Fin d)) :
    (∏ j : Fin ℓ, (eligList t ω p j).length) = dataTupleCard t ω p := by
  rw [prod_eligList_eq_card]
  unfold dataTupleCard
  congr 1
  ext τ
  simp [IsDataTuple, UL.gaussianDataTest]

theorem prod_eligList_eq_queryTupleCard {ℓ M₀ d : ℕ} (x t : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (z : EuclideanSpace ℝ (Fin d)) :
    (∏ j : Fin ℓ, (eligList (x * t) ω z j).length) = queryTupleCard x t ω z := by
  rw [prod_eligList_eq_card]
  unfold queryTupleCard
  congr 1
  ext τ
  simp [IsQueryTuple, UL.gaussianQueryTest]

/-- Inner product loop accumulating `⟨G, v⟩` into `(17, 7)` using counter `(11, 13)`
for Gaussian index `g` stored at `(11, 14)`. -/
def dotLoopStmt : ArithRAMStmt :=
  seqStmts
    [ .writeRealHeap 17 (.lit 7) (.ofInt (.lit 0)),
      .writeWordHeap 11 (.lit 13) (.lit 0),
      .repeatN .dim
        (seqStmts
          [ .writeRealHeap 17 (.lit 7)
              (.add (.readRealHeap 17 (.lit 7))
                (.mul
                  (.readRealHeap 2
                    (.add (.mul (.readHeap 11 (.lit 14)) .dim)
                      (.readHeap 11 (.lit 13))))
                  (.readRealHeap 3 (.readHeap 11 (.lit 13))))),
            .writeWordHeap 11 (.lit 13)
              (.add (.readHeap 11 (.lit 13)) (.lit 1)) ]) ]

/-- RAM subroutine computing all `ℓ` base eligible lists into table `6`, counts into table `5`,
and tuple product `∏_j c_j` into `(11, 15)`. -/
def computeBaseListsStmt (ℓ : ℕ) : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 11 (.lit 15) (.lit 1),
      .writeWordHeap 11 (.lit 10) (.lit 0),
      .repeatN (.lit (ℓ : ℤ))
        (seqStmts
          [ .writeWordHeap 11 (.lit 12) (.lit 0),
            .writeWordHeap 11 (.lit 11) (.lit 0),
            .repeatN (.readHeap 1 (.lit 1))
              (seqStmts
                [ .writeWordHeap 11 (.lit 14)
                    (.add (.mul (.readHeap 11 (.lit 10)) (.readHeap 1 (.lit 1)))
                      (.readHeap 11 (.lit 11))),
                  dotLoopStmt,
                  .ite (.realLe (.readRealHeap 17 (.lit 6)) (.readRealHeap 17 (.lit 7)))
                    (seqStmts
                      [ .writeWordHeap 6
                          (.add (.mul (.readHeap 11 (.lit 10)) (.readHeap 1 (.lit 1)))
                            (.readHeap 11 (.lit 12)))
                          (.readHeap 11 (.lit 11)),
                        .writeWordHeap 11 (.lit 12)
                          (.add (.readHeap 11 (.lit 12)) (.lit 1)) ])
                    .skip,
                  .writeWordHeap 11 (.lit 11)
                    (.add (.readHeap 11 (.lit 11)) (.lit 1)) ]),
            .writeWordHeap 5 (.readHeap 11 (.lit 10)) (.readHeap 11 (.lit 12)),
            .writeWordHeap 11 (.lit 15)
              (.mul (.readHeap 11 (.lit 15)) (.readHeap 11 (.lit 12))),
            .writeWordHeap 11 (.lit 10)
              (.add (.readHeap 11 (.lit 10)) (.lit 1)) ]) ]

theorem exec_dotLoop {d ℓ M₀ Cap_q : ℕ} (inp : ArithRAMInput d)
    (G v : EuclideanSpace ℝ (Fin d)) (g : Fin (ℓ * M₀))
    {mem : ArithRAMMemory} (hc : CleanMem mem)
    (hw_g : wRead mem 11 14 = (g.1 : ℤ))
    (hr_G : ∀ c : Fin d, rRead mem 2 ((g.1 * d + c.1 : ℕ) : ℤ) = euclideanCoord G c)
    (hr_v : ∀ c : Fin d, rRead mem 3 (c.1 : ℤ) = euclideanCoord v c) :
    let SW := scratchWords ℓ M₀ Cap_q
    let SR := scratchReals d ℓ M₀
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp dotLoopStmt mem mem' (15 + d * 30) ∧
      extraCells SW SR mem' = extraCells SW SR mem ∧
      rRead mem' 17 7 = inner ℝ G v ∧
      (∀ t i, (t ≠ 11 ∨ i ≠ 13) → wRead mem' t i = wRead mem t i) ∧
      (∀ t i, (t ≠ 17 ∨ i ≠ 7) → rRead mem' t i = rRead mem t i) := by
  intro SW SR
  rcases exec_rSet_sr SW SR inp hc 17 (.lit 7) 7 (mem_scratchReals_17 (i := 7) (by omega))
    (.ofInt (.lit 0)) 0 5
    (by simp [evalIntExpr]) (by simp [evalRealExpr, evalIntExpr])
    (by simp [evalRealExpr, evalIntExpr]) with
    ⟨m1, hs1, hex1, hr1_7, hw1, hr1_ne⟩
  rcases exec_wSet_sw SW SR inp hs1.2.1 11 (.lit 13) 13 (mem_scratchWords_11 (i := 13) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m2, hs2, hex2, hw2_13, hw2_ne, hr2⟩
  let fG : ℕ → ℝ := fun c => if hc : c < d then euclideanCoord G ⟨c, hc⟩ else 0
  let fv : ℕ → ℝ := fun c => if hc : c < d then euclideanCoord v ⟨c, hc⟩ else 0
  let body : ArithRAMStmt :=
    seqStmts
      [ .writeRealHeap 17 (.lit 7)
          (.add (.readRealHeap 17 (.lit 7))
            (.mul
              (.readRealHeap 2
                (.add (.mul (.readHeap 11 (.lit 14)) .dim) (.readHeap 11 (.lit 13))))
              (.readRealHeap 3 (.readHeap 11 (.lit 13))))),
        .writeWordHeap 11 (.lit 13) (.add (.readHeap 11 (.lit 13)) (.lit 1)) ]
  let Inv : ℕ → ArithRAMMemory → Prop := fun c m =>
    extraCells SW SR m = extraCells SW SR mem ∧
    wRead m 11 13 = (c : ℤ) ∧
    rRead m 17 7 = dotSum fG fv c ∧
    (∀ t i, (t ≠ 11 ∨ i ≠ 13) → wRead m t i = wRead mem t i) ∧
    (∀ t i, (t ≠ 17 ∨ i ≠ 7) → rRead m t i = rRead mem t i)
  have hInv₀ : Inv 0 m2 :=
    ⟨hex2.trans hex1, hw2_13, by simpa [dotSum] using (hr2 17 7).trans hr1_7,
      fun t i hne => (hw2_ne t i hne).trans (hw1 t i),
      fun t i hne => (hr2 t i).trans (hr1_ne t i hne)⟩
  rcases exec_repeatN (inp := inp) .dim body d 3 30 Inv hs2.2.1 hInv₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun c hc_lt m hcm ⟨hexm, hwc, hracc, hwm, hrm⟩ => by
      have hwg_m : wRead m 11 14 = (g.1 : ℤ) := (hwm 11 14 (Or.inr (by decide))).trans hw_g
      have hrG_m : rRead m 2 ((g.1 * d + c : ℕ) : ℤ) = euclideanCoord G ⟨c, hc_lt⟩ :=
        (hrm 2 _ (Or.inl (by decide))).trans (hr_G ⟨c, hc_lt⟩)
      have hrv_m : rRead m 3 (c : ℤ) = euclideanCoord v ⟨c, hc_lt⟩ :=
        (hrm 3 _ (Or.inl (by decide))).trans (hr_v ⟨c, hc_lt⟩)
      have haddr : (g.1 : ℤ) * (d : ℤ) + (c : ℤ) = ((g.1 * d + c : ℕ) : ℤ) := by push_cast; ring
      rcases exec_rSet_sr SW SR inp hcm 17 (.lit 7) 7 (mem_scratchReals_17 (i := 7) (by omega))
        (.add (.readRealHeap 17 (.lit 7))
          (.mul
            (.readRealHeap 2 (.add (.mul (.readHeap 11 (.lit 14)) .dim) (.readHeap 11 (.lit 13))))
            (.readRealHeap 3 (.readHeap 11 (.lit 13)))))
        (dotSum fG fv (c + 1)) 20
        (by simp [evalIntExpr])
        (by simp only [evalRealExpr, evalIntExpr, words_read_heap, reals_read_heap,
              hracc, hwg_m, hwc, haddr, hrG_m, hrv_m, dotSum, fG, fv, hc_lt, ↓reduceDIte])
        (by simp [evalRealExpr, evalIntExpr]) with
        ⟨ma, hb1, hexa, hra_7, hwa, hra_ne⟩
      have hwc_a : wRead ma 11 13 = (c : ℤ) := (hwa 11 13).trans hwc
      rcases exec_wSet_sw SW SR inp hb1.2.1 11 (.lit 13) 13 (mem_scratchWords_11 (i := 13) (by omega))
        (.add (.readHeap 11 (.lit 13)) (.lit 1)) (((c + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, hwc_a]) (by simp [evalIntExpr]) with
        ⟨mb, hb2, hexb, hwb_13, hwb_ne, hrb⟩
      have hstep_b : ExecStmt inp body m mb 30 := by
        unfold body seqStmts
        exact (ExecStmt.seq hb1 hb2).mono_cost (by omega)
      exact ⟨mb, hstep_b, hexb.trans (hexa.trans hexm), hwb_13, (hrb 17 7).trans hra_7,
        fun t i hne => (hwb_ne t i hne).trans ((hwa t i).trans (hwm t i hne)),
        fun t i hne => (hrb t i).trans ((hra_ne t i hne).trans (hrm t i hne))⟩) with
    ⟨mem', ⟨hex', _, hr', hw', hrm'⟩, hrep⟩
  rw [dotSum_eq_inner G v] at hr'
  have htot : ExecStmt inp dotLoopStmt mem mem' (15 + d * 30) := by
    unfold dotLoopStmt seqStmts
    exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 hrep)).mono_cost (by omega)
  exact ⟨mem', htot, hex', hr', hw', hrm'⟩

theorem exec_computeBaseListsStmt {d ℓ M₀ Cap_q : ℕ} (inp : ArithRAMInput d)
    (_hM₀ : 1 ≤ M₀) (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d))
    {mem : ArithRAMMemory} (hc : CleanMem mem)
    (hw_M₀ : wRead mem 1 1 = (M₀ : ℤ))
    (hr_θ : rRead mem 17 6 = θ)
    (hr_ω : ∀ g : Fin (ℓ * M₀), ∀ c : Fin d,
      rRead mem 2 ((g.1 * d + c.1 : ℕ) : ℤ) = euclideanCoord (ω g) c)
    (hr_v : ∀ c : Fin d, rRead mem 3 (c.1 : ℤ) = euclideanCoord v c) :
    let SW := scratchWords ℓ M₀ Cap_q
    let SR := scratchReals d ℓ M₀
    let prod : ℕ := ∏ j : Fin ℓ, (eligList θ ω v j).length
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp (computeBaseListsStmt ℓ) mem mem'
        (20 + ℓ * 40 + ℓ * M₀ * (65 + d * 30)) ∧
      extraCells SW SR mem' = extraCells SW SR mem ∧
      wRead mem' 11 15 = (prod : ℤ) ∧
      (∀ j : Fin ℓ, wRead mem' 5 (j.1 : ℤ) = ((eligList θ ω v j).length : ℤ)) ∧
      (∀ j : Fin ℓ, ∀ (pos : ℕ) (hpos : pos < (eligList θ ω v j).length),
        wRead mem' 6 ((j.1 * M₀ + pos : ℕ) : ℤ) = (((eligList θ ω v j)[pos]).1 : ℤ)) ∧
      (∀ t i, t ≠ 5 → t ≠ 6 → (t ≠ 11 ∨ i < 10 ∨ 15 < i) →
        wRead mem' t i = wRead mem t i) ∧
      (∀ t i, (t ≠ 17 ∨ i ≠ 7) → rRead mem' t i = rRead mem t i) := by
  intro SW SR prod
  rcases exec_wSet_sw SW SR inp hc 11 (.lit 15) 15 (mem_scratchWords_11 (i := 15) (by omega))
    (.lit 1) 1 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m1, hs1, hex1, hw1_15, hw1_ne, hr1⟩
  rcases exec_wSet_sw SW SR inp hs1.2.1 11 (.lit 10) 10 (mem_scratchWords_11 (i := 10) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m2, hs2, hex2, hw2_10, hw2_ne, hr2⟩

  let cFun : ℕ → ℕ := fun j => if hj : j < ℓ then (eligList θ ω v ⟨j, hj⟩).length else 1
  let innerBody : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 14)
          (.add (.mul (.readHeap 11 (.lit 10)) (.readHeap 1 (.lit 1)))
            (.readHeap 11 (.lit 11))),
        dotLoopStmt,
        .ite (.realLe (.readRealHeap 17 (.lit 6)) (.readRealHeap 17 (.lit 7)))
          (seqStmts
            [ .writeWordHeap 6
                (.add (.mul (.readHeap 11 (.lit 10)) (.readHeap 1 (.lit 1)))
                  (.readHeap 11 (.lit 12)))
                (.readHeap 11 (.lit 11)),
              .writeWordHeap 11 (.lit 12) (.add (.readHeap 11 (.lit 12)) (.lit 1)) ])
          .skip,
        .writeWordHeap 11 (.lit 11) (.add (.readHeap 11 (.lit 11)) (.lit 1)) ]
  let outerBody : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 12) (.lit 0),
        .writeWordHeap 11 (.lit 11) (.lit 0),
        .repeatN (.readHeap 1 (.lit 1)) innerBody,
        .writeWordHeap 5 (.readHeap 11 (.lit 10)) (.readHeap 11 (.lit 12)),
        .writeWordHeap 11 (.lit 15) (.mul (.readHeap 11 (.lit 15)) (.readHeap 11 (.lit 12))),
        .writeWordHeap 11 (.lit 10) (.add (.readHeap 11 (.lit 10)) (.lit 1)) ]

  let OuterInv : ℕ → ArithRAMMemory → Prop := fun j m =>
    extraCells SW SR m = extraCells SW SR mem ∧
    wRead m 11 10 = (j : ℤ) ∧
    wRead m 11 15 = ((prodPrefix cFun j : ℕ) : ℤ) ∧
    (∀ j' : Fin ℓ, j'.1 < j → wRead m 5 (j'.1 : ℤ) = ((eligList θ ω v j').length : ℤ)) ∧
    (∀ j' : Fin ℓ, j'.1 < j → ∀ (pos : ℕ) (hpos : pos < (eligList θ ω v j').length),
      wRead m 6 ((j'.1 * M₀ + pos : ℕ) : ℤ) = (((eligList θ ω v j')[pos]).1 : ℤ)) ∧
    (∀ t i, t ≠ 5 → t ≠ 6 → (t ≠ 11 ∨ i < 10 ∨ 15 < i) →
      wRead m t i = wRead mem t i) ∧
    (∀ t i, (t ≠ 17 ∨ i ≠ 7) → rRead m t i = rRead mem t i)

  have hOuter₀ : OuterInv 0 m2 := by
    refine ⟨hex2.trans hex1, hw2_10, ?_, fun _ hj => by omega, fun _ hj => by omega, ?_, ?_⟩
    · simpa [prodPrefix] using (hw2_ne 11 15 (Or.inr (by decide))).trans hw1_15
    · intro t i ht5 ht6 h11
      have hne10 : t ≠ 11 ∨ i ≠ 10 := by
        rcases h11 with ht | hi1 | hi2
        · exact Or.inl ht
        · exact Or.inr (by omega)
        · exact Or.inr (by omega)
      have hne15 : t ≠ 11 ∨ i ≠ 15 := by
        rcases h11 with ht | hi1 | hi2
        · exact Or.inl ht
        · exact Or.inr (by omega)
        · exact Or.inr (by omega)
      exact (hw2_ne t i hne10).trans (hw1_ne t i hne15)
    · intro t i _
      exact (hr2 t i).trans (hr1 t i)

  rcases exec_repeatN (.lit (ℓ : ℤ)) outerBody ℓ 3 (40 + M₀ * (65 + d * 30))
    OuterInv hs2.2.1 hOuter₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun j hj_lt m hcm ⟨hexm, hwj, hwprod, hw5_prev, hw6_prev, hwm_pres, hrm_pres⟩ => by
      let jFin : Fin ℓ := ⟨j, hj_lt⟩
      have hwM₀_m : wRead m 1 1 = (M₀ : ℤ) :=
        (hwm_pres 1 1 (by decide) (by decide) (Or.inl (by decide))).trans hw_M₀
      rcases exec_wSet_sw SW SR inp hcm 11 (.lit 12) 12 (mem_scratchWords_11 (i := 12) (by omega))
        (.lit 0) 0 4
        (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
        ⟨ma1, hb1, hexa1, hwa1_12, hwa1_ne, hra1⟩
      rcases exec_wSet_sw SW SR inp hb1.2.1 11 (.lit 11) 11 (mem_scratchWords_11 (i := 11) (by omega))
        (.lit 0) 0 4
        (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
        ⟨ma2, hb2, hexa2, hwa2_11, hwa2_ne, hra2⟩

      let InnerInv : ℕ → ArithRAMMemory → Prop := fun s mI =>
        extraCells SW SR mI = extraCells SW SR mem ∧
        wRead mI 11 10 = (j : ℤ) ∧
        wRead mI 11 11 = (s : ℤ) ∧
        wRead mI 11 12 = ((eligPrefix θ ω v jFin s).length : ℤ) ∧
        wRead mI 11 15 = ((prodPrefix cFun j : ℕ) : ℤ) ∧
        (∀ (pos : ℕ) (hpos : pos < (eligPrefix θ ω v jFin s).length),
          wRead mI 6 ((j * M₀ + pos : ℕ) : ℤ) = (((eligPrefix θ ω v jFin s)[pos]).1 : ℤ)) ∧
        (∀ j' : Fin ℓ, j'.1 < j → wRead mI 5 (j'.1 : ℤ) = ((eligList θ ω v j').length : ℤ)) ∧
        (∀ j' : Fin ℓ, j'.1 < j → ∀ (pos : ℕ) (hpos : pos < (eligList θ ω v j').length),
          wRead mI 6 ((j'.1 * M₀ + pos : ℕ) : ℤ) = (((eligList θ ω v j')[pos]).1 : ℤ)) ∧
        (∀ t i, t ≠ 5 → t ≠ 6 → (t ≠ 11 ∨ i < 10 ∨ 15 < i) →
          wRead mI t i = wRead mem t i) ∧
        (∀ t i, (t ≠ 17 ∨ i ≠ 7) → rRead mI t i = rRead mem t i)

      have hInner₀ : InnerInv 0 ma2 := by
        have hw_ma2 : ∀ t i, (t ≠ 11 ∨ (i ≠ 11 ∧ i ≠ 12)) → wRead ma2 t i = wRead m t i := by
          intro t i hne
          rcases hne with ht | ⟨hi11, hi12⟩
          · exact (hwa2_ne t i (Or.inl ht)).trans (hwa1_ne t i (Or.inl ht))
          · exact (hwa2_ne t i (Or.inr hi11)).trans (hwa1_ne t i (Or.inr hi12))
        refine ⟨hexa2.trans (hexa1.trans hexm),
          (hw_ma2 11 10 (Or.inr ⟨by decide, by decide⟩)).trans hwj,
          hwa2_11,
          by simpa [eligPrefix] using (hwa2_ne 11 12 (Or.inr (by decide))).trans hwa1_12,
          (hw_ma2 11 15 (Or.inr ⟨by decide, by decide⟩)).trans hwprod,
          fun _ hpos => by simp [eligPrefix] at hpos,
          fun j' hj' => (hw_ma2 5 _ (Or.inl (by decide))).trans (hw5_prev j' hj'),
          fun j' hj' pos hpos => (hw_ma2 6 _ (Or.inl (by decide))).trans (hw6_prev j' hj' pos hpos),
          fun t i ht5 ht6 h11 => (hw_ma2 t i (by
            rcases h11 with ht | hi1 | hi2
            · exact Or.inl ht
            · exact Or.inr ⟨by omega, by omega⟩
            · exact Or.inr ⟨by omega, by omega⟩)).trans (hwm_pres t i ht5 ht6 h11),
          fun t i hne => (hra2 t i).trans ((hra1 t i).trans (hrm_pres t i hne))⟩

      have hwM₀_ma2 : wRead ma2 1 1 = (M₀ : ℤ) :=
        (hwa2_ne 1 1 (Or.inl (by decide))).trans ((hwa1_ne 1 1 (Or.inl (by decide))).trans hwM₀_m)

      rcases exec_repeatN (.readHeap 1 (.lit 1)) innerBody M₀ 4 (65 + d * 30)
        InnerInv hb2.2.1 hInner₀
        (by simp [evalIntExpr, hwM₀_ma2]) (by simp [evalIntExpr])
        (fun s hs_lt mI hcmI
          ⟨hexI, hwjI, hwsI, hwcntI, hwprodI, hw6_cur, hw5_I, hw6_I, hwm_I, hrm_I⟩ => by
          let gFin : Fin (ℓ * M₀) := capIdx jFin ⟨s, hs_lt⟩
          have hwM₀_I : wRead mI 1 1 = (M₀ : ℤ) :=
            (hwm_I 1 1 (by decide) (by decide) (Or.inl (by decide))).trans hw_M₀
          have hg_cast : (j : ℤ) * (M₀ : ℤ) + (s : ℤ) = (gFin.1 : ℤ) := by
            dsimp only [gFin, capIdx, jFin]
            rw [Nat.cast_add, Nat.cast_mul]
          -- 1. write g := j * M₀ + s into (11, 14)
          rcases exec_wSet_sw SW SR inp hcmI 11 (.lit 14) 14 (mem_scratchWords_11 (i := 14) (by omega))
            (.add (.mul (.readHeap 11 (.lit 10)) (.readHeap 1 (.lit 1))) (.readHeap 11 (.lit 11)))
            (gFin.1 : ℤ) 12
            (by simp [evalIntExpr])
            (by simp only [evalIntExpr, words_read_heap, hwjI, hwM₀_I, hwsI]; exact hg_cast)
            (by simp [evalIntExpr]) with
            ⟨mi1, hi1, hexi1, hwi1_14, hwi1_ne, hri1⟩
          -- 2. dotLoop -> inner ℝ (ω gFin) v in (17, 7)
          have hrG_mi1 : ∀ c : Fin d,
              rRead mi1 2 ((gFin.1 * d + c.1 : ℕ) : ℤ) = euclideanCoord (ω gFin) c := fun c =>
            (hri1 2 _).trans ((hrm_I 2 _ (Or.inl (by decide))).trans (hr_ω gFin c))
          have hrv_mi1 : ∀ c : Fin d, rRead mi1 3 (c.1 : ℤ) = euclideanCoord v c := fun c =>
            (hri1 3 _).trans ((hrm_I 3 _ (Or.inl (by decide))).trans (hr_v c))
          rcases exec_dotLoop (ℓ := ℓ) (M₀ := M₀) (Cap_q := Cap_q) inp (ω gFin) v gFin
            hi1.2.1 hwi1_14 hrG_mi1 hrv_mi1 with
            ⟨mi2, hi2, hexi2, hri2_7, hwi2_ne, hri2_ne⟩
          have hw_mi2 : ∀ t i, (t ≠ 11 ∨ (i ≠ 13 ∧ i ≠ 14)) → wRead mi2 t i = wRead mI t i := by
            intro t i hne
            rcases hne with ht | ⟨hi13, hi14⟩
            · exact (hwi2_ne t i (Or.inl ht)).trans (hwi1_ne t i (Or.inl ht))
            · exact (hwi2_ne t i (Or.inr hi13)).trans (hwi1_ne t i (Or.inr hi14))
          have hrθ_mi2 : rRead mi2 17 6 = θ :=
            (hri2_ne 17 6 (Or.inr (by decide))).trans
              ((hri1 17 6).trans ((hrm_I 17 6 (Or.inr (by decide))).trans hr_θ))
          -- 3. ite (θ ≤ dot)
          let prev := eligPrefix θ ω v jFin s
          have hprev_len_lt : prev.length < M₀ := by
            have hle := eligPrefix_length_le θ ω v jFin s (by omega)
            dsimp [prev]
            omega
          let condE : ArithCondExpr := .realLe (.readRealHeap 17 (.lit 6)) (.readRealHeap 17 (.lit 7))
          let tBr : ArithRAMStmt :=
            seqStmts
              [ .writeWordHeap 6
                  (.add (.mul (.readHeap 11 (.lit 10)) (.readHeap 1 (.lit 1)))
                    (.readHeap 11 (.lit 12)))
                  (.readHeap 11 (.lit 11)),
                .writeWordHeap 11 (.lit 12) (.add (.readHeap 11 (.lit 12)) (.lit 1)) ]
          have hite_branch :
              ∃ mi3 : ArithRAMMemory,
                ExecStmt inp (.ite condE tBr .skip) mi2 mi3 26 ∧
                extraCells SW SR mi3 = extraCells SW SR mem ∧
                wRead mi3 11 10 = (j : ℤ) ∧
                wRead mi3 11 11 = (s : ℤ) ∧
                wRead mi3 11 12 = ((eligPrefix θ ω v jFin (s + 1)).length : ℤ) ∧
                wRead mi3 11 15 = ((prodPrefix cFun j : ℕ) : ℤ) ∧
                (∀ (pos : ℕ) (hpos : pos < (eligPrefix θ ω v jFin (s + 1)).length),
                  wRead mi3 6 ((j * M₀ + pos : ℕ) : ℤ) =
                    (((eligPrefix θ ω v jFin (s + 1))[pos]).1 : ℤ)) ∧
                (∀ j' : Fin ℓ, j'.1 < j → wRead mi3 5 (j'.1 : ℤ) = ((eligList θ ω v j').length : ℤ)) ∧
                (∀ j' : Fin ℓ, j'.1 < j → ∀ (pos : ℕ) (hpos : pos < (eligList θ ω v j').length),
                  wRead mi3 6 ((j'.1 * M₀ + pos : ℕ) : ℤ) = (((eligList θ ω v j')[pos]).1 : ℤ)) ∧
                (∀ t i, t ≠ 5 → t ≠ 6 → (t ≠ 11 ∨ i < 10 ∨ 15 < i) →
                  wRead mi3 t i = wRead mem t i) ∧
                (∀ t i, (t ≠ 17 ∨ i ≠ 7) → rRead mi3 t i = rRead mem t i) := by
            classical
            by_cases htest : θ ≤ inner ℝ (ω gFin) v
            · have helig_succ : eligPrefix θ ω v jFin (s + 1) = prev ++ [⟨s, hs_lt⟩] := by
                simp [eligPrefix, hs_lt, gFin, htest, prev]
              have hwj_2 : wRead mi2 11 10 = (j : ℤ) :=
                (hw_mi2 11 10 (Or.inr ⟨by decide, by decide⟩)).trans hwjI
              have hws_2 : wRead mi2 11 11 = (s : ℤ) :=
                (hw_mi2 11 11 (Or.inr ⟨by decide, by decide⟩)).trans hwsI
              have hwcnt_2 : wRead mi2 11 12 = (prev.length : ℤ) :=
                (hw_mi2 11 12 (Or.inr ⟨by decide, by decide⟩)).trans hwcntI
              have hwM₀_2 : wRead mi2 1 1 = (M₀ : ℤ) :=
                (hw_mi2 1 1 (Or.inl (by decide))).trans hwM₀_I
              have hslot_lt : j * M₀ + prev.length < ℓ * M₀ + 1 := by
                calc j * M₀ + prev.length < j * M₀ + M₀ := Nat.add_lt_add_left hprev_len_lt _
                  _ = (j + 1) * M₀ := by ring
                  _ ≤ ℓ * M₀ := Nat.mul_le_mul_right M₀ (by omega)
                  _ < ℓ * M₀ + 1 := by omega
              have hslot_cast : (j : ℤ) * (M₀ : ℤ) + (prev.length : ℤ) =
                  ((j * M₀ + prev.length : ℕ) : ℤ) := by push_cast; ring
              rcases exec_wSet_sw SW SR inp hi2.2.1 6
                (.add (.mul (.readHeap 11 (.lit 10)) (.readHeap 1 (.lit 1)))
                  (.readHeap 11 (.lit 12)))
                ((j * M₀ + prev.length : ℕ) : ℤ)
                (mem_scratchWords_6 hslot_lt)
                (.readHeap 11 (.lit 11)) (s : ℤ) 12
                (by simp only [evalIntExpr, words_read_heap, hwj_2, hwM₀_2, hwcnt_2]; exact hslot_cast)
                (by simp [evalIntExpr, hws_2])
                (by simp [evalIntExpr]) with
                ⟨mt1, ht1, hext1, hwt1_6, hwt1_ne, hrt1⟩
              have hwcnt_t1 : wRead mt1 11 12 = (prev.length : ℤ) :=
                (hwt1_ne 11 12 (Or.inl (by decide))).trans hwcnt_2
              rcases exec_wSet_sw SW SR inp ht1.2.1 11 (.lit 12) 12
                (mem_scratchWords_11 (i := 12) (by omega))
                (.add (.readHeap 11 (.lit 12)) (.lit 1)) (((prev.length + 1 : ℕ) : ℤ)) 8
                (by simp [evalIntExpr])
                (by simp [evalIntExpr, hwcnt_t1])
                (by simp [evalIntExpr]) with
                ⟨mt2, ht2, hext2, hwt2_12, hwt2_ne, hrt2⟩
              have htBr_exec : ExecStmt inp tBr mi2 mt2 20 := by
                unfold tBr seqStmts
                exact ExecStmt.seq ht1 ht2
              have hite_exec : ExecStmt inp (.ite condE tBr .skip) mi2 mt2 26 :=
                exec_ite_true (fB := .skip)
                  (by
                    simp only [condE, evalArithCond, evalRealExpr, evalIntExpr,
                      reals_read_heap, hrθ_mi2, hri2_7]
                    exact decide_eq_true htest)
                  htBr_exec
                  (by simp [condE, evalArithCond, evalRealExpr, evalIntExpr])
              refine ⟨mt2, hite_exec,
                hext2.trans (hext1.trans (hexi2.trans (hexi1.trans hexI))),
                (hwt2_ne 11 10 (Or.inr (by decide))).trans
                  ((hwt1_ne 11 10 (Or.inl (by decide))).trans hwj_2),
                (hwt2_ne 11 11 (Or.inr (by decide))).trans
                  ((hwt1_ne 11 11 (Or.inl (by decide))).trans hws_2),
                by simpa [helig_succ] using hwt2_12,
                (hwt2_ne 11 15 (Or.inr (by decide))).trans
                  ((hwt1_ne 11 15 (Or.inl (by decide))).trans
                    ((hw_mi2 11 15 (Or.inr ⟨by decide, by decide⟩)).trans hwprodI)),
                ?_, ?_, ?_, ?_, ?_⟩
              · intro pos hpos
                simp only [helig_succ, List.length_append, List.length_singleton] at hpos
                rcases Nat.lt_succ_iff_lt_or_eq.mp hpos with hlt_p | rfl
                · have hne_slot : (6 : ℕ) ≠ 6 ∨
                      ((j * M₀ + pos : ℕ) : ℤ) ≠ ((j * M₀ + prev.length : ℕ) : ℤ) :=
                    Or.inr (by omega)
                  have hw_old := (hwt2_ne 6 _ (Or.inl (by decide))).trans
                    ((hwt1_ne 6 _ hne_slot).trans
                      ((hw_mi2 6 _ (Or.inl (by decide))).trans (hw6_cur pos hlt_p)))
                  simpa [helig_succ, List.getElem_append_left hlt_p] using hw_old
                · have hw_new := (hwt2_ne 6 _ (Or.inl (by decide))).trans hwt1_6
                  simpa [helig_succ] using hw_new
              · intro j' hj'
                exact (hwt2_ne 5 _ (Or.inl (by decide))).trans
                  ((hwt1_ne 5 _ (Or.inl (by decide))).trans
                    ((hw_mi2 5 _ (Or.inl (by decide))).trans (hw5_I j' hj')))
              · intro j' hj' pos hpos
                have hpos_lt : pos < M₀ := by
                  have hle := eligPrefix_length_le θ ω v j' M₀ le_rfl
                  change pos < (eligPrefix θ ω v j' M₀).length at hpos
                  omega
                have haddr_lt : j'.1 * M₀ + pos < j * M₀ + prev.length := by
                  calc j'.1 * M₀ + pos < j'.1 * M₀ + M₀ := Nat.add_lt_add_left hpos_lt _
                    _ = (j'.1 + 1) * M₀ := by ring
                    _ ≤ j * M₀ := Nat.mul_le_mul_right M₀ (by omega)
                    _ ≤ j * M₀ + prev.length := Nat.le_add_right _ _
                have hne_slot : (6 : ℕ) ≠ 6 ∨
                    ((j'.1 * M₀ + pos : ℕ) : ℤ) ≠ ((j * M₀ + prev.length : ℕ) : ℤ) :=
                  Or.inr (by omega)
                exact (hwt2_ne 6 _ (Or.inl (by decide))).trans
                  ((hwt1_ne 6 _ hne_slot).trans
                    ((hw_mi2 6 _ (Or.inl (by decide))).trans (hw6_I j' hj' pos hpos)))
              · intro t i ht5 ht6 h11
                have hne12 : t ≠ 11 ∨ i ≠ 12 := by
                  rcases h11 with ht | hi1 | hi2
                  · exact Or.inl ht
                  · exact Or.inr (by omega)
                  · exact Or.inr (by omega)
                have hne1314 : t ≠ 11 ∨ (i ≠ 13 ∧ i ≠ 14) := by
                  rcases h11 with ht | hi1 | hi2
                  · exact Or.inl ht
                  · exact Or.inr ⟨by omega, by omega⟩
                  · exact Or.inr ⟨by omega, by omega⟩
                exact (hwt2_ne t i hne12).trans
                  ((hwt1_ne t i (Or.inl ht6)).trans ((hw_mi2 t i hne1314).trans (hwm_I t i ht5 ht6 h11)))
              · intro t i hne
                exact (hrt2 t i).trans ((hrt1 t i).trans
                  ((hri2_ne t i hne).trans ((hri1 t i).trans (hrm_I t i hne))))
            · have helig_succ : eligPrefix θ ω v jFin (s + 1) = prev := by
                simp [eligPrefix, hs_lt, gFin, htest, prev]
              have hite_exec : ExecStmt inp (.ite condE tBr .skip) mi2 mi2 26 :=
                exec_ite_false (tB := tBr)
                  (by
                    simp only [condE, evalArithCond, evalRealExpr, evalIntExpr,
                      reals_read_heap, hrθ_mi2, hri2_7]
                    exact decide_eq_false htest)
                  (ExecStmt.skip inp hi2.2.1)
                  (by simp [condE, evalArithCond, evalRealExpr, evalIntExpr])
              refine ⟨mi2, hite_exec,
                hexi2.trans (hexi1.trans hexI),
                (hw_mi2 11 10 (Or.inr ⟨by decide, by decide⟩)).trans hwjI,
                (hw_mi2 11 11 (Or.inr ⟨by decide, by decide⟩)).trans hwsI,
                by simpa [helig_succ] using
                  (hw_mi2 11 12 (Or.inr ⟨by decide, by decide⟩)).trans hwcntI,
                (hw_mi2 11 15 (Or.inr ⟨by decide, by decide⟩)).trans hwprodI,
                fun pos hpos => by
                  rw [helig_succ] at hpos
                  simpa [helig_succ] using (hw_mi2 6 _ (Or.inl (by decide))).trans (hw6_cur pos hpos),
                fun j' hj' => (hw_mi2 5 _ (Or.inl (by decide))).trans (hw5_I j' hj'),
                fun j' hj' pos hpos => (hw_mi2 6 _ (Or.inl (by decide))).trans (hw6_I j' hj' pos hpos),
                fun t i ht5 ht6 h11 => (hw_mi2 t i (by
                  rcases h11 with ht | hi1 | hi2
                  · exact Or.inl ht
                  · exact Or.inr ⟨by omega, by omega⟩
                  · exact Or.inr ⟨by omega, by omega⟩)).trans (hwm_I t i ht5 ht6 h11),
                fun t i hne => (hri2_ne t i hne).trans ((hri1 t i).trans (hrm_I t i hne))⟩
          rcases hite_branch with
            ⟨mi3, hi3, hex3, hwj3, hws3, hwcnt3, hwprod3, hw6_cur3, hw5_3, hw6_3, hwm_3, hrm_3⟩
          -- 4. s := s + 1
          rcases exec_wSet_sw SW SR inp hi3.2.1 11 (.lit 11) 11
            (mem_scratchWords_11 (i := 11) (by omega))
            (.add (.readHeap 11 (.lit 11)) (.lit 1)) (((s + 1 : ℕ) : ℤ)) 8
            (by simp [evalIntExpr])
            (by simp [evalIntExpr, hws3])
            (by simp [evalIntExpr]) with
            ⟨mi4, hi4, hex4, hws4, hwi4_ne, hri4⟩
          have hinner_tot : ExecStmt inp innerBody mI mi4 (65 + d * 30) := by
            unfold innerBody seqStmts
            exact (ExecStmt.seq hi1 (ExecStmt.seq hi2 (ExecStmt.seq hi3 hi4))).mono_cost (by omega)
          exact ⟨mi4, hinner_tot, hex4.trans hex3,
            (hwi4_ne 11 10 (Or.inr (by decide))).trans hwj3,
            hws4,
            (hwi4_ne 11 12 (Or.inr (by decide))).trans hwcnt3,
            (hwi4_ne 11 15 (Or.inr (by decide))).trans hwprod3,
            fun pos hpos => (hwi4_ne 6 _ (Or.inl (by decide))).trans (hw6_cur3 pos hpos),
            fun j' hj' => (hwi4_ne 5 _ (Or.inl (by decide))).trans (hw5_3 j' hj'),
            fun j' hj' pos hpos => (hwi4_ne 6 _ (Or.inl (by decide))).trans (hw6_3 j' hj' pos hpos),
            fun t i ht5 ht6 h11 => (hwi4_ne t i (by
              rcases h11 with ht | hi1 | hi2
              · exact Or.inl ht
              · exact Or.inr (by omega)
              · exact Or.inr (by omega))).trans (hwm_3 t i ht5 ht6 h11),
            fun t i hne => (hri4 t i).trans (hrm_3 t i hne)⟩) with
        ⟨ma3, ⟨hex_a3, hwj_a3, _, hwcnt_a3, hwprod_a3, hw6_cur_a3, hw5_a3, hw6_a3, hwm_a3, hrm_a3⟩, hs3⟩

      -- Trailing outer statements: 5[j] := cnt, 11[15] := 11[15] * cnt, 11[10] := j + 1
      rcases exec_wSet_sw SW SR inp hs3.2.1 5 (.readHeap 11 (.lit 10)) (j : ℤ)
        (mem_scratchWords_5 (i := j) (by omega))
        (.readHeap 11 (.lit 12)) ((eligList θ ω v jFin).length : ℤ) 9
        (by simp [evalIntExpr, hwj_a3])
        (by simp only [evalIntExpr, words_read_heap, hwcnt_a3]; rfl)
        (by simp [evalIntExpr]) with
        ⟨ma4, hb4, hexa4, hwa4_5, hwa4_ne, hra4⟩
      have hwprod_a4 : wRead ma4 11 15 = ((prodPrefix cFun j : ℕ) : ℤ) :=
        (hwa4_ne 11 15 (Or.inl (by decide))).trans hwprod_a3
      have hwcnt_a4 : wRead ma4 11 12 = ((eligList θ ω v jFin).length : ℤ) :=
        (hwa4_ne 11 12 (Or.inl (by decide))).trans hwcnt_a3
      have hprod_succ :
          ((prodPrefix cFun j : ℕ) : ℤ) * ((eligList θ ω v jFin).length : ℤ) =
            ((prodPrefix cFun (j + 1) : ℕ) : ℤ) := by
        simp only [prodPrefix, cFun, hj_lt, ↓reduceDIte, jFin]
        push_cast
        rfl
      rcases exec_wSet_sw SW SR inp hb4.2.1 11 (.lit 15) 15
        (mem_scratchWords_11 (i := 15) (by omega))
        (.mul (.readHeap 11 (.lit 15)) (.readHeap 11 (.lit 12)))
        ((prodPrefix cFun (j + 1) : ℕ) : ℤ) 9
        (by simp [evalIntExpr])
        (by simp only [evalIntExpr, words_read_heap, hwprod_a4, hwcnt_a4]; exact hprod_succ)
        (by simp [evalIntExpr]) with
        ⟨ma5, hb5, hexa5, hwa5_15, hwa5_ne, hra5⟩
      have hwj_a5 : wRead ma5 11 10 = (j : ℤ) :=
        (hwa5_ne 11 10 (Or.inr (by decide))).trans
          ((hwa4_ne 11 10 (Or.inl (by decide))).trans hwj_a3)
      rcases exec_wSet_sw SW SR inp hb5.2.1 11 (.lit 10) 10
        (mem_scratchWords_11 (i := 10) (by omega))
        (.add (.readHeap 11 (.lit 10)) (.lit 1)) (((j + 1 : ℕ) : ℤ)) 8
        (by simp [evalIntExpr])
        (by simp [evalIntExpr, hwj_a5])
        (by simp [evalIntExpr]) with
        ⟨ma6, hb6, hexa6, hwa6_10, hwa6_ne, hra6⟩
      have houter_tot : ExecStmt inp outerBody m ma6 (40 + M₀ * (65 + d * 30)) := by
        unfold outerBody seqStmts
        exact (ExecStmt.seq hb1 (ExecStmt.seq hb2 (ExecStmt.seq hs3
          (ExecStmt.seq hb4 (ExecStmt.seq hb5 hb6))))).mono_cost (by omega)
      refine ⟨ma6, houter_tot,
        hexa6.trans (hexa5.trans (hexa4.trans hex_a3)),
        hwa6_10,
        (hwa6_ne 11 15 (Or.inr (by decide))).trans hwa5_15,
        ?_, ?_, ?_, ?_⟩
      · intro j' hj'
        rcases Nat.lt_succ_iff_lt_or_eq.mp hj' with hlt_j | heq_j
        · have hne_j : (5 : ℕ) ≠ 5 ∨ (j'.1 : ℤ) ≠ (j : ℤ) := Or.inr (by omega)
          exact (hwa6_ne 5 _ (Or.inl (by decide))).trans
            ((hwa5_ne 5 _ (Or.inl (by decide))).trans
              ((hwa4_ne 5 _ hne_j).trans (hw5_a3 j' hlt_j)))
        · have hj'_eq : j' = jFin := Fin.ext heq_j
          subst hj'_eq
          exact (hwa6_ne 5 _ (Or.inl (by decide))).trans
            ((hwa5_ne 5 _ (Or.inl (by decide))).trans hwa4_5)
      · intro j' hj' pos hpos
        have hw6_63 : wRead ma6 6 ((j'.1 * M₀ + pos : ℕ) : ℤ) =
            wRead ma3 6 ((j'.1 * M₀ + pos : ℕ) : ℤ) :=
          (hwa6_ne 6 _ (Or.inl (by decide))).trans
            ((hwa5_ne 6 _ (Or.inl (by decide))).trans (hwa4_ne 6 _ (Or.inl (by decide))))
        rw [hw6_63]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hj' with hlt_j | heq_j
        · exact hw6_a3 j' hlt_j pos hpos
        · have hj'_eq : j' = jFin := Fin.ext heq_j
          subst hj'_eq
          exact hw6_cur_a3 pos hpos
      · intro t i ht5 ht6 h11
        have hne10 : t ≠ 11 ∨ i ≠ 10 := by
          rcases h11 with ht | hi1 | hi2
          · exact Or.inl ht
          · exact Or.inr (by omega)
          · exact Or.inr (by omega)
        have hne15 : t ≠ 11 ∨ i ≠ 15 := by
          rcases h11 with ht | hi1 | hi2
          · exact Or.inl ht
          · exact Or.inr (by omega)
          · exact Or.inr (by omega)
        exact (hwa6_ne t i hne10).trans
          ((hwa5_ne t i hne15).trans
            ((hwa4_ne t i (Or.inl ht5)).trans (hwm_a3 t i ht5 ht6 h11)))
      · intro t i hne
        exact (hra6 t i).trans ((hra5 t i).trans ((hra4 t i).trans (hrm_a3 t i hne)))) with
    ⟨mem', ⟨hex', _, hwprod', hw5', hw6', hwm', hrm'⟩, hrep⟩
  have hprod_eq : prodPrefix cFun ℓ = prod :=
    prodPrefix_eq_prod ℓ (fun j => (eligList θ ω v j).length)
  rw [hprod_eq] at hwprod'
  have htot : ExecStmt inp (computeBaseListsStmt ℓ) mem mem'
      (20 + ℓ * 40 + ℓ * M₀ * (65 + d * 30)) := by
    unfold computeBaseListsStmt seqStmts
    exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 hrep)).mono_cost (by nlinarith)
  exact ⟨mem', htot, hex', hwprod',
    fun j => hw5' j j.2,
    fun j pos hpos => hw6' j j.2 pos hpos,
    hwm', hrm'⟩

/-! ### 4. Tuple index bijection (`tupleOfIdx`) and `decodeTupleBucketStmt` -/

theorem list_nodup_getElem_inj {α : Type*} :
    ∀ {l : List α} (_hnod : l.Nodup) {i j : ℕ} (hi : i < l.length) (hj : j < l.length),
      l[i] = l[j] → i = j
  | [], _, i, _, hi, _, _ => by simp at hi
  | a :: l, hnod, 0, 0, _, _, _ => rfl
  | a :: l, hnod, 0, j + 1, _, hj, heq => by
      rcases List.nodup_cons.mp hnod with ⟨ha, _⟩
      have hmem : l[j]'(Nat.lt_of_succ_lt_succ hj) ∈ l := List.getElem_mem _
      simp only [List.getElem_cons_zero, List.getElem_cons_succ] at heq
      rw [← heq] at hmem
      exact absurd hmem ha
  | a :: l, hnod, i + 1, 0, hi, _, heq => by
      rcases List.nodup_cons.mp hnod with ⟨ha, _⟩
      have hmem : l[i]'(Nat.lt_of_succ_lt_succ hi) ∈ l := List.getElem_mem _
      simp only [List.getElem_cons_zero, List.getElem_cons_succ] at heq
      rw [heq] at hmem
      exact absurd hmem ha
  | a :: l, hnod, i + 1, j + 1, hi, hj, heq => by
      rcases List.nodup_cons.mp hnod with ⟨_, hnod_l⟩
      simp only [List.getElem_cons_succ] at heq
      exact congrArg Nat.succ
        (list_nodup_getElem_inj hnod_l (Nat.lt_of_succ_lt_succ hi) (Nat.lt_of_succ_lt_succ hj) heq)

theorem exists_getElem_of_mem {α : Type*} {x : α} :
    ∀ {l : List α}, x ∈ l → ∃ (p : ℕ) (hp : p < l.length), l[p] = x
  | [], h => by simp at h
  | a :: l, h => by
      rcases List.mem_cons.mp h with rfl | htl
      · exact ⟨0, by simp, rfl⟩
      · rcases exists_getElem_of_mem htl with ⟨p, hp, heq⟩
        exact ⟨p + 1, Nat.succ_lt_succ hp, heq⟩

noncomputable def cLen {ℓ M₀ d : ℕ} (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d)) (j : ℕ) : ℕ :=
  if hj : j < ℓ then (eligList θ ω v ⟨j, hj⟩).length else 1

theorem prodPrefix_cLen_eq {ℓ M₀ d : ℕ} (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d)) :
    prodPrefix (cLen θ ω v) ℓ = ∏ j : Fin ℓ, (eligList θ ω v j).length :=
  prodPrefix_eq_prod ℓ (fun j => (eligList θ ω v j).length)

noncomputable def tupleOfIdx {ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀) (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d)) (idx : ℕ) (j : Fin ℓ) : Fin M₀ :=
  let L := eligList θ ω v j
  let pos := posAt (cLen θ ω v) idx j.1
  if hpos : pos < L.length then
    L[pos]
  else
    ⟨0, hM₀⟩

theorem posAt_lt_eligList_length {ℓ M₀ d : ℕ} {θ : ℝ}
    {ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)}
    {v : EuclideanSpace ℝ (Fin d)}
    (hprod : 1 ≤ ∏ j : Fin ℓ, (eligList θ ω v j).length)
    (idx : ℕ) (j : Fin ℓ) :
    posAt (cLen θ ω v) idx j.1 < (eligList θ ω v j).length := by
  rw [← prodPrefix_cLen_eq] at hprod
  have hcj : 1 ≤ cLen θ ω v j.1 := (prodPrefix_pos_iff.mp hprod) j.1 j.2
  have hlt := posAt_lt idx j.1 hcj
  simpa [cLen, j.2] using hlt

theorem tupleOfIdx_apply {ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀) {θ : ℝ}
    {ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)}
    {v : EuclideanSpace ℝ (Fin d)}
    (hprod : 1 ≤ ∏ j : Fin ℓ, (eligList θ ω v j).length)
    (idx : ℕ) (j : Fin ℓ) :
    tupleOfIdx hM₀ θ ω v idx j =
      (eligList θ ω v j)[posAt (cLen θ ω v) idx j.1]'(posAt_lt_eligList_length hprod idx j) := by
  have hpos := posAt_lt_eligList_length hprod idx j
  simp [tupleOfIdx, hpos]

theorem tupleOfIdx_elig {ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀) {θ : ℝ}
    {ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)}
    {v : EuclideanSpace ℝ (Fin d)}
    (hprod : 1 ≤ ∏ j : Fin ℓ, (eligList θ ω v j).length)
    (idx : ℕ) (j : Fin ℓ) :
    θ ≤ inner ℝ (ω (capIdx j (tupleOfIdx hM₀ θ ω v idx j))) v := by
  rw [tupleOfIdx_apply hM₀ hprod idx j, ← mem_eligList_iff]
  exact List.getElem_mem _

theorem tupleOfIdx_isDataTuple {ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀) {t : ℝ}
    {ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)}
    {p : EuclideanSpace ℝ (Fin d)}
    (hcard : 1 ≤ dataTupleCard t ω p) (idx : ℕ) :
    IsDataTuple t ω p (tupleOfIdx hM₀ t ω p idx) := by
  rw [← prod_eligList_eq_dataTupleCard] at hcard
  intro j
  exact tupleOfIdx_elig hM₀ hcard idx j

theorem tupleOfIdx_isQueryTuple {ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀) {x t : ℝ}
    {ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)}
    {z : EuclideanSpace ℝ (Fin d)}
    (hcard : 1 ≤ queryTupleCard x t ω z) (idx : ℕ) :
    IsQueryTuple x t ω z (tupleOfIdx hM₀ (x * t) ω z idx) := by
  rw [← prod_eligList_eq_queryTupleCard] at hcard
  intro j
  exact tupleOfIdx_elig hM₀ hcard idx j

theorem tupleOfIdx_injective {ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀) {θ : ℝ}
    {ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)}
    {v : EuclideanSpace ℝ (Fin d)}
    {idx₁ idx₂ : ℕ}
    (h₁ : idx₁ < ∏ j : Fin ℓ, (eligList θ ω v j).length)
    (h₂ : idx₂ < ∏ j : Fin ℓ, (eligList θ ω v j).length)
    (heq : tupleOfIdx hM₀ θ ω v idx₁ = tupleOfIdx hM₀ θ ω v idx₂) :
    idx₁ = idx₂ := by
  have hprod : 1 ≤ ∏ j : Fin ℓ, (eligList θ ω v j).length := by omega
  have hprod' : 1 ≤ prodPrefix (cLen θ ω v) ℓ := by rwa [prodPrefix_cLen_eq]
  rw [← prodPrefix_cLen_eq] at h₁ h₂
  refine posAt_injective (prodPrefix_pos_iff.mp hprod') h₁ h₂ (fun j hj => ?_)
  let jF : Fin ℓ := ⟨j, hj⟩
  have hj_eq := congrFun heq jF
  rw [tupleOfIdx_apply hM₀ hprod idx₁ jF, tupleOfIdx_apply hM₀ hprod idx₂ jF] at hj_eq
  exact list_nodup_getElem_inj (eligList_nodup θ ω v jF)
    (posAt_lt_eligList_length hprod idx₁ jF)
    (posAt_lt_eligList_length hprod idx₂ jF) hj_eq

theorem exists_idx_of_elig_tuple {ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀) {θ : ℝ}
    {ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)}
    {v : EuclideanSpace ℝ (Fin d)}
    {τ : Fin ℓ → Fin M₀}
    (hτ : ∀ j : Fin ℓ, θ ≤ inner ℝ (ω (capIdx j (τ j))) v) :
    ∃ idx < ∏ j : Fin ℓ, (eligList θ ω v j).length,
      tupleOfIdx hM₀ θ ω v idx = τ := by
  classical
  have hex : ∀ j : Fin ℓ, ∃ (p : ℕ) (hp : p < (eligList θ ω v j).length),
      (eligList θ ω v j)[p] = τ j := fun j =>
    exists_getElem_of_mem ((mem_eligList_iff θ ω v j (τ j)).mpr (hτ j))
  let pFun : ℕ → ℕ := fun j =>
    if hj : j < ℓ then Classical.choose (hex ⟨j, hj⟩) else 0
  have hp_lt : ∀ j < ℓ, pFun j < cLen θ ω v j := by
    intro j hj
    dsimp [pFun, cLen]
    simp only [hj, ↓reduceDIte]
    exact (Classical.choose_spec (hex ⟨j, hj⟩)).1
  let idx := encodeMixed (cLen θ ω v) pFun ℓ
  have hidx_lt : idx < ∏ j : Fin ℓ, (eligList θ ω v j).length := by
    rw [← prodPrefix_cLen_eq]
    exact encodeMixed_lt ℓ hp_lt
  have hprod : 1 ≤ ∏ j : Fin ℓ, (eligList θ ω v j).length := by omega
  refine ⟨idx, hidx_lt, ?_⟩
  funext j
  rw [tupleOfIdx_apply hM₀ hprod idx j]
  have hpos_eq : posAt (cLen θ ω v) idx j.1 = Classical.choose (hex j) := by
    have h1 := posAt_encodeMixed hp_lt j.2
    simpa [idx, pFun, j.2] using h1
  have hget :
      (eligList θ ω v j)[posAt (cLen θ ω v) idx j.1]'(posAt_lt_eligList_length hprod idx j) =
        (eligList θ ω v j)[Classical.choose (hex j)]'((Classical.choose_spec (hex j)).1) := by
    congr 1
  rw [hget]
  exact (Classical.choose_spec (hex j)).2

/-- RAM subroutine reading `idx` from `(11, 16)` and writing
`hornerTuple (tupleOfIdx hM₀ θ ω v idx)` to `(11, 18)` using scratch `(11, 17..21)`. -/
def decodeTupleBucketStmt (ℓ : ℕ) : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 11 (.lit 17) (.readHeap 11 (.lit 16)),
      .writeWordHeap 11 (.lit 18) (.lit 0),
      .writeWordHeap 11 (.lit 19) (.lit 0),
      .repeatN (.lit (ℓ : ℤ))
        (seqStmts
          [ .writeWordHeap 11 (.lit 20) (.readHeap 5 (.readHeap 11 (.lit 19))),
            .writeWordHeap 11 (.lit 21)
              (.mod (.readHeap 11 (.lit 17)) (.readHeap 11 (.lit 20))),
            .writeWordHeap 11 (.lit 17)
              (.div (.readHeap 11 (.lit 17)) (.readHeap 11 (.lit 20))),
            .writeWordHeap 11 (.lit 18)
              (.add (.mul (.readHeap 11 (.lit 18)) (.readHeap 1 (.lit 1)))
                (.readHeap 6
                  (.add (.mul (.readHeap 11 (.lit 19)) (.readHeap 1 (.lit 1)))
                    (.readHeap 11 (.lit 21))))),
            .writeWordHeap 11 (.lit 19)
              (.add (.readHeap 11 (.lit 19)) (.lit 1)) ]) ]

theorem exec_decodeTupleBucketStmt {d ℓ M₀ Cap_q : ℕ} (inp : ArithRAMInput d)
    (hM₀ : 1 ≤ M₀) (θ : ℝ)
    (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
    (v : EuclideanSpace ℝ (Fin d))
    (hprod : 1 ≤ ∏ j : Fin ℓ, (eligList θ ω v j).length)
    (idx : ℕ)
    {mem : ArithRAMMemory} (hc : CleanMem mem)
    (hw_M₀ : wRead mem 1 1 = (M₀ : ℤ))
    (hw_5 : ∀ j : Fin ℓ, wRead mem 5 (j.1 : ℤ) = ((eligList θ ω v j).length : ℤ))
    (hw_6 : ∀ j : Fin ℓ, ∀ (pos : ℕ) (hpos : pos < (eligList θ ω v j).length),
      wRead mem 6 ((j.1 * M₀ + pos : ℕ) : ℤ) = (((eligList θ ω v j)[pos]).1 : ℤ))
    (hw_idx : wRead mem 11 16 = (idx : ℤ)) :
    let SW := scratchWords ℓ M₀ Cap_q
    let SR := scratchReals d ℓ M₀
    let τ := tupleOfIdx hM₀ θ ω v idx
    ∃ mem' : ArithRAMMemory,
      ExecStmt inp (decodeTupleBucketStmt ℓ) mem mem' (20 + ℓ * 60) ∧
      extraCells SW SR mem' = extraCells SW SR mem ∧
      wRead mem' 11 18 = ((hornerTuple τ : ℕ) : ℤ) ∧
      (∀ t i, (t ≠ 11 ∨ i < 17 ∨ 21 < i) → wRead mem' t i = wRead mem t i) ∧
      (∀ t i, rRead mem' t i = rRead mem t i) := by
  intro SW SR τ
  rcases exec_wSet_sw SW SR inp hc 11 (.lit 17) 17 (mem_scratchWords_11 (i := 17) (by omega))
    (.readHeap 11 (.lit 16)) (idx : ℤ) 8
    (by simp [evalIntExpr]) (by simp [evalIntExpr, hw_idx]) (by simp [evalIntExpr]) with
    ⟨m1, hs1, hex1, hw1_17, hw1_ne, hr1⟩
  rcases exec_wSet_sw SW SR inp hs1.2.1 11 (.lit 18) 18 (mem_scratchWords_11 (i := 18) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m2, hs2, hex2, hw2_18, hw2_ne, hr2⟩
  rcases exec_wSet_sw SW SR inp hs2.2.1 11 (.lit 19) 19 (mem_scratchWords_11 (i := 19) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr]) with
    ⟨m3, hs3, hex3, hw3_19, hw3_ne, hr3⟩

  let c := cLen θ ω v
  let f : ℕ → ℕ := fun j => if hj : j < ℓ then (τ ⟨j, hj⟩).1 else 0
  let body : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 20) (.readHeap 5 (.readHeap 11 (.lit 19))),
        .writeWordHeap 11 (.lit 21)
          (.mod (.readHeap 11 (.lit 17)) (.readHeap 11 (.lit 20))),
        .writeWordHeap 11 (.lit 17)
          (.div (.readHeap 11 (.lit 17)) (.readHeap 11 (.lit 20))),
        .writeWordHeap 11 (.lit 18)
          (.add (.mul (.readHeap 11 (.lit 18)) (.readHeap 1 (.lit 1)))
            (.readHeap 6
              (.add (.mul (.readHeap 11 (.lit 19)) (.readHeap 1 (.lit 1)))
                (.readHeap 11 (.lit 21))))),
        .writeWordHeap 11 (.lit 19)
          (.add (.readHeap 11 (.lit 19)) (.lit 1)) ]

  let Inv : ℕ → ArithRAMMemory → Prop := fun j m =>
    extraCells SW SR m = extraCells SW SR mem ∧
    wRead m 11 17 = ((remStep c idx j : ℕ) : ℤ) ∧
    wRead m 11 18 = ((hornerStep M₀ f j : ℕ) : ℤ) ∧
    wRead m 11 19 = (j : ℤ) ∧
    (∀ t i, (t ≠ 11 ∨ i < 17 ∨ 21 < i) → wRead m t i = wRead mem t i) ∧
    (∀ t i, rRead m t i = rRead mem t i)

  have hInv₀ : Inv 0 m3 := by
    refine ⟨hex3.trans (hex2.trans hex1),
      by simpa [remStep] using
        (hw3_ne 11 17 (Or.inr (by decide))).trans
          ((hw2_ne 11 17 (Or.inr (by decide))).trans hw1_17),
      by simpa [hornerStep] using (hw3_ne 11 18 (Or.inr (by decide))).trans hw2_18,
      hw3_19, ?_, ?_⟩
    · intro t i hne
      have h17 : t ≠ 11 ∨ i ≠ 17 := by
        rcases hne with ht | hi1 | hi2
        · exact Or.inl ht
        · exact Or.inr (by omega)
        · exact Or.inr (by omega)
      have h18 : t ≠ 11 ∨ i ≠ 18 := by
        rcases hne with ht | hi1 | hi2
        · exact Or.inl ht
        · exact Or.inr (by omega)
        · exact Or.inr (by omega)
      have h19 : t ≠ 11 ∨ i ≠ 19 := by
        rcases hne with ht | hi1 | hi2
        · exact Or.inl ht
        · exact Or.inr (by omega)
        · exact Or.inr (by omega)
      exact (hw3_ne t i h19).trans ((hw2_ne t i h18).trans (hw1_ne t i h17))
    · intro t i
      exact (hr3 t i).trans ((hr2 t i).trans (hr1 t i))

  rcases exec_repeatN (.lit (ℓ : ℤ)) body ℓ 3 60 Inv hs3.2.1 hInv₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun j hj_lt m hcm ⟨hexm, hwrem, hwhorn, hwj, hwm_pres, hrm_pres⟩ => by
      let jF : Fin ℓ := ⟨j, hj_lt⟩
      have hw5_j : wRead m 5 (j : ℤ) = ((c j : ℕ) : ℤ) := by
        have h := (hwm_pres 5 (j : ℤ) (Or.inl (by decide))).trans (hw_5 jF)
        simpa [c, cLen, hj_lt, jF] using h
      -- 1. (11, 20) := 5[j] = c j
      rcases exec_wSet_sw SW SR inp hcm 11 (.lit 20) 20 (mem_scratchWords_11 (i := 20) (by omega))
        (.readHeap 5 (.readHeap 11 (.lit 19))) ((c j : ℕ) : ℤ) 8
        (by simp [evalIntExpr])
        (by simp only [evalIntExpr, words_read_heap, hwj]; exact hw5_j)
        (by simp [evalIntExpr]) with
        ⟨ma1, hb1, hexa1, hwa1_20, hwa1_ne, hra1⟩
      -- 2. (11, 21) := rem % c j = posAt c idx j
      have hwrem_a1 : wRead ma1 11 17 = ((remStep c idx j : ℕ) : ℤ) :=
        (hwa1_ne 11 17 (Or.inr (by decide))).trans hwrem
      have hmod_eq : ((remStep c idx j : ℕ) : ℤ) % ((c j : ℕ) : ℤ) = ((posAt c idx j : ℕ) : ℤ) := by
        unfold posAt
        exact_mod_cast rfl
      rcases exec_wSet_sw SW SR inp hb1.2.1 11 (.lit 21) 21 (mem_scratchWords_11 (i := 21) (by omega))
        (.mod (.readHeap 11 (.lit 17)) (.readHeap 11 (.lit 20))) ((posAt c idx j : ℕ) : ℤ) 10
        (by simp [evalIntExpr])
        (by simp only [evalIntExpr, words_read_heap, hwrem_a1, hwa1_20]; exact hmod_eq)
        (by simp [evalIntExpr]) with
        ⟨ma2, hb2, hexa2, hwa2_21, hwa2_ne, hra2⟩
      -- 3. (11, 17) := rem / c j = remStep c idx (j + 1)
      have hwrem_a2 : wRead ma2 11 17 = ((remStep c idx j : ℕ) : ℤ) :=
        (hwa2_ne 11 17 (Or.inr (by decide))).trans hwrem_a1
      have hwcj_a2 : wRead ma2 11 20 = ((c j : ℕ) : ℤ) :=
        (hwa2_ne 11 20 (Or.inr (by decide))).trans hwa1_20
      have hdiv_eq :
          ((remStep c idx j : ℕ) : ℤ) / ((c j : ℕ) : ℤ) = ((remStep c idx (j + 1) : ℕ) : ℤ) := by
        simp only [remStep]
        exact_mod_cast rfl
      rcases exec_wSet_sw SW SR inp hb2.2.1 11 (.lit 17) 17 (mem_scratchWords_11 (i := 17) (by omega))
        (.div (.readHeap 11 (.lit 17)) (.readHeap 11 (.lit 20)))
        ((remStep c idx (j + 1) : ℕ) : ℤ) 10
        (by simp [evalIntExpr])
        (by simp only [evalIntExpr, words_read_heap, hwrem_a2, hwcj_a2]; exact hdiv_eq)
        (by simp [evalIntExpr]) with
        ⟨ma3, hb3, hexa3, hwa3_17, hwa3_ne, hra3⟩
      -- 4. (11, 18) := b * M₀ + 6[j * M₀ + posAt c idx j] = hornerStep M₀ f (j + 1)
      have hwhorn_a3 : wRead ma3 11 18 = ((hornerStep M₀ f j : ℕ) : ℤ) :=
        (hwa3_ne 11 18 (Or.inr (by decide))).trans
          ((hwa2_ne 11 18 (Or.inr (by decide))).trans
            ((hwa1_ne 11 18 (Or.inr (by decide))).trans hwhorn))
      have hwj_a3 : wRead ma3 11 19 = (j : ℤ) :=
        (hwa3_ne 11 19 (Or.inr (by decide))).trans
          ((hwa2_ne 11 19 (Or.inr (by decide))).trans
            ((hwa1_ne 11 19 (Or.inr (by decide))).trans hwj))
      have hwpos_a3 : wRead ma3 11 21 = ((posAt c idx j : ℕ) : ℤ) :=
        (hwa3_ne 11 21 (Or.inr (by decide))).trans hwa2_21
      have hwM₀_a3 : wRead ma3 1 1 = (M₀ : ℤ) :=
        (hwa3_ne 1 1 (Or.inl (by decide))).trans
          ((hwa2_ne 1 1 (Or.inl (by decide))).trans
            ((hwa1_ne 1 1 (Or.inl (by decide))).trans
              ((hwm_pres 1 1 (Or.inl (by decide))).trans hw_M₀)))
      have hpos_lt : posAt c idx j < (eligList θ ω v jF).length :=
        posAt_lt_eligList_length hprod idx jF
      have haddr_cast : (j : ℤ) * (M₀ : ℤ) + ((posAt c idx j : ℕ) : ℤ) =
          ((jF.1 * M₀ + posAt c idx j : ℕ) : ℤ) := by
        dsimp only [jF]
        rw [Nat.cast_add, Nat.cast_mul]
      have hw6_a3 :
          wRead ma3 6 ((jF.1 * M₀ + posAt c idx j : ℕ) : ℤ) =
            (((eligList θ ω v jF)[posAt c idx j]).1 : ℤ) :=
        (hwa3_ne 6 _ (Or.inl (by decide))).trans
          ((hwa2_ne 6 _ (Or.inl (by decide))).trans
            ((hwa1_ne 6 _ (Or.inl (by decide))).trans
              ((hwm_pres 6 _ (Or.inl (by decide))).trans (hw_6 jF (posAt c idx j) hpos_lt))))
      have hfj_eq : (((eligList θ ω v jF)[posAt c idx j]).1 : ℤ) = ((f j : ℕ) : ℤ) := by
        have hτj : τ jF = (eligList θ ω v jF)[posAt c idx j] := tupleOfIdx_apply hM₀ hprod idx jF
        simp only [f, hj_lt, ↓reduceDIte]
        exact congrArg (fun x : Fin M₀ => (x.1 : ℤ)) hτj.symm
      have hhorn_succ :
          ((hornerStep M₀ f j : ℕ) : ℤ) * (M₀ : ℤ) + ((f j : ℕ) : ℤ) =
            ((hornerStep M₀ f (j + 1) : ℕ) : ℤ) := by
        dsimp only [hornerStep]
        rw [Nat.cast_add, Nat.cast_mul]
      rcases exec_wSet_sw SW SR inp hb3.2.1 11 (.lit 18) 18 (mem_scratchWords_11 (i := 18) (by omega))
        (.add (.mul (.readHeap 11 (.lit 18)) (.readHeap 1 (.lit 1)))
          (.readHeap 6
            (.add (.mul (.readHeap 11 (.lit 19)) (.readHeap 1 (.lit 1)))
              (.readHeap 11 (.lit 21)))))
        ((hornerStep M₀ f (j + 1) : ℕ) : ℤ) 20
        (by simp [evalIntExpr])
        (by
          simp only [evalIntExpr, words_read_heap, hwhorn_a3, hwM₀_a3, hwj_a3, hwpos_a3,
            haddr_cast, hw6_a3, hfj_eq]
          exact hhorn_succ)
        (by simp [evalIntExpr]) with
        ⟨ma4, hb4, hexa4, hwa4_18, hwa4_ne, hra4⟩
      -- 5. (11, 19) := j + 1
      have hwj_a4 : wRead ma4 11 19 = (j : ℤ) :=
        (hwa4_ne 11 19 (Or.inr (by decide))).trans hwj_a3
      rcases exec_wSet_sw SW SR inp hb4.2.1 11 (.lit 19) 19 (mem_scratchWords_11 (i := 19) (by omega))
        (.add (.readHeap 11 (.lit 19)) (.lit 1)) (((j + 1 : ℕ) : ℤ)) 8
        (by simp [evalIntExpr])
        (by simp [evalIntExpr, hwj_a4])
        (by simp [evalIntExpr]) with
        ⟨ma5, hb5, hexa5, hwa5_19, hwa5_ne, hra5⟩
      have hbody_tot : ExecStmt inp body m ma5 60 := by
        unfold body seqStmts
        exact (ExecStmt.seq hb1 (ExecStmt.seq hb2 (ExecStmt.seq hb3
          (ExecStmt.seq hb4 hb5)))).mono_cost (by omega)
      refine ⟨ma5, hbody_tot,
        hexa5.trans (hexa4.trans (hexa3.trans (hexa2.trans (hexa1.trans hexm)))),
        (hwa5_ne 11 17 (Or.inr (by decide))).trans
          ((hwa4_ne 11 17 (Or.inr (by decide))).trans hwa3_17),
        (hwa5_ne 11 18 (Or.inr (by decide))).trans hwa4_18,
        hwa5_19, ?_, ?_⟩
      · intro t i hne
        have h17 : t ≠ 11 ∨ i ≠ 17 := by
          rcases hne with ht | hi1 | hi2
          · exact Or.inl ht
          · exact Or.inr (by omega)
          · exact Or.inr (by omega)
        have h18 : t ≠ 11 ∨ i ≠ 18 := by
          rcases hne with ht | hi1 | hi2
          · exact Or.inl ht
          · exact Or.inr (by omega)
          · exact Or.inr (by omega)
        have h19 : t ≠ 11 ∨ i ≠ 19 := by
          rcases hne with ht | hi1 | hi2
          · exact Or.inl ht
          · exact Or.inr (by omega)
          · exact Or.inr (by omega)
        have h20 : t ≠ 11 ∨ i ≠ 20 := by
          rcases hne with ht | hi1 | hi2
          · exact Or.inl ht
          · exact Or.inr (by omega)
          · exact Or.inr (by omega)
        have h21 : t ≠ 11 ∨ i ≠ 21 := by
          rcases hne with ht | hi1 | hi2
          · exact Or.inl ht
          · exact Or.inr (by omega)
          · exact Or.inr (by omega)
        exact (hwa5_ne t i h19).trans
          ((hwa4_ne t i h18).trans
            ((hwa3_ne t i h17).trans
              ((hwa2_ne t i h21).trans
                ((hwa1_ne t i h20).trans (hwm_pres t i hne)))))
      · intro t i
        exact (hra5 t i).trans ((hra4 t i).trans ((hra3 t i).trans
          ((hra2 t i).trans ((hra1 t i).trans (hrm_pres t i)))))) with
    ⟨mem', ⟨hex', _, hwhorn', _, hwm', hrm'⟩, hrep⟩
  have htot : ExecStmt inp (decodeTupleBucketStmt ℓ) mem mem' (20 + ℓ * 60) := by
    unfold decodeTupleBucketStmt seqStmts
    exact (ExecStmt.seq hs1 (ExecStmt.seq hs2 (ExecStmt.seq hs3 hrep))).mono_cost (by omega)
  exact ⟨mem', htot, hex', hwhorn', hwm', hrm'⟩

end UL.Proof.lem_6_3.RacerV30
