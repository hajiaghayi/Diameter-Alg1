import UL.Stmt.clm_5_1_block_witness
set_option autoImplicit false

namespace UL

namespace Proof_clm_5_1_block_witness

private lemma liftedPoint_apply_castSucc {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (k : Fin d) :
    (liftedPoint o s) k.castSucc = o k := by
  simp [liftedPoint]

private lemma liftedPoint_apply_last {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    (liftedPoint o s) (Fin.last d) = s := by
  simp [liftedPoint]

private lemma euclidean_sum_smul_apply {n : ℕ} {ι : Type*} [DecidableEq ι]
    (B : Finset ι) (c : ι → ℝ) (f : ι → EuclideanSpace ℝ (Fin n)) (k : Fin n) :
    (∑ p ∈ B, c p • f p) k = ∑ p ∈ B, c p * f p k := by
  induction B using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
    simp [Finset.sum_insert ha, ih]

private lemma sum_inner_left {d : ℕ} {ι : Type*} [DecidableEq ι]
    (B : Finset ι) (f : ι → EuclideanSpace ℝ (Fin d)) (q : EuclideanSpace ℝ (Fin d)) :
    ∑ p ∈ B, inner ℝ (f p) q = inner ℝ (∑ p ∈ B, f p) q := by
  induction B using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
    rw [Finset.sum_insert ha, Finset.sum_insert ha, inner_add_left, ih]

private lemma cert_sum_pts {d : ℕ} {ι : Type*} [DecidableEq ι]
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (cert : BlockCertificate pts P₀ (liftedPoint o s)) :
    ∑ p ∈ cert.B, cert.coeff p • pts p = o := by
  ext k
  rw [euclidean_sum_smul_apply]
  have hk : (∑ p ∈ cert.B, cert.coeff p • paraboloidLift (pts p)) k.castSucc = (liftedPoint o s) k.castSucc := by
    rw [cert.sum_lift]
  rw [euclidean_sum_smul_apply, liftedPoint_apply_castSucc] at hk
  simpa [paraboloidLift, liftedPoint_apply_castSucc] using hk

private lemma cert_sum_sq {d : ℕ} {ι : Type*} [DecidableEq ι]
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (cert : BlockCertificate pts P₀ (liftedPoint o s)) :
    ∑ p ∈ cert.B, cert.coeff p * ‖pts p‖ ^ 2 = s := by
  have hlast : (∑ p ∈ cert.B, cert.coeff p • paraboloidLift (pts p)) (Fin.last d) = (liftedPoint o s) (Fin.last d) := by
    rw [cert.sum_lift]
  rw [euclidean_sum_smul_apply, liftedPoint_apply_last] at hlast
  simpa [paraboloidLift, liftedPoint_apply_last] using hlast

private lemma cert_variance_identity {d : ℕ} {ι : Type*} [DecidableEq ι]
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (cert : BlockCertificate pts P₀ (liftedPoint o s))
    (q : EuclideanSpace ℝ (Fin d)) :
    ∑ p ∈ cert.B, cert.coeff p * ‖pts p - q‖ ^ 2 = ‖q - o‖ ^ 2 + liftVariance o s := by
  have hexpand : ∀ p : ι,
      cert.coeff p * ‖pts p - q‖ ^ 2 =
        cert.coeff p * ‖pts p‖ ^ 2 - 2 * inner ℝ (cert.coeff p • pts p) q +
          cert.coeff p * ‖q‖ ^ 2 := by
    intro p
    rw [norm_sub_sq_real, inner_smul_left, RCLike.conj_to_real]
    ring
  calc
    ∑ p ∈ cert.B, cert.coeff p * ‖pts p - q‖ ^ 2
        = ∑ p ∈ cert.B, (cert.coeff p * ‖pts p‖ ^ 2 -
            2 * inner ℝ (cert.coeff p • pts p) q + cert.coeff p * ‖q‖ ^ 2) := by
          refine Finset.sum_congr rfl (fun p _ => hexpand p)
    _ = (∑ p ∈ cert.B, cert.coeff p * ‖pts p‖ ^ 2) -
          2 * (∑ p ∈ cert.B, inner ℝ (cert.coeff p • pts p) q) +
          (∑ p ∈ cert.B, cert.coeff p) * ‖q‖ ^ 2 := by
          rw [Finset.sum_add_distrib, Finset.sum_sub_distrib,
            ← Finset.mul_sum, ← Finset.sum_mul]
    _ = s - 2 * inner ℝ o q + 1 * ‖q‖ ^ 2 := by
          rw [cert_sum_sq cert, sum_inner_left, cert_sum_pts cert, cert.sum_coeff]
    _ = ‖q - o‖ ^ 2 + liftVariance o s := by
          unfold liftVariance
          rw [norm_sub_sq_real, real_inner_comm]
          ring

private lemma cert_B_nonempty {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {z : EuclideanSpace ℝ (Fin (d + 1))}
    (cert : BlockCertificate pts P₀ z) :
    cert.B.Nonempty := by
  by_contra hempty
  rw [Finset.not_nonempty_iff_eq_empty] at hempty
  have hsum := cert.sum_coeff
  rw [hempty, Finset.sum_empty] at hsum
  norm_num at hsum

private lemma cert_witness {d : ℕ} {ι : Type*} [DecidableEq ι]
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ S : Finset ι}
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (cert : BlockCertificate pts P₀ (liftedPoint o s))
    (hintact : cert.IsIntact S)
    (q : EuclideanSpace ℝ (Fin d)) :
    ∃ p ∈ cert.B,
      p ∈ S ∧
      ‖pts p - q‖ ^ 2 ≥ ∑ p' ∈ cert.B, cert.coeff p' * ‖pts p' - q‖ ^ 2 ∧
      IsVarianceWitness o (liftVariance o s) q (pts p) := by
  have hB := cert_B_nonempty cert
  obtain ⟨p, hpB, hp_eq⟩ := Finset.exists_mem_eq_sup' hB (fun z => ‖pts z - q‖ ^ 2)
  have havg_le : ∑ p' ∈ cert.B, cert.coeff p' * ‖pts p' - q‖ ^ 2 ≤ ‖pts p - q‖ ^ 2 := by
    calc
      ∑ p' ∈ cert.B, cert.coeff p' * ‖pts p' - q‖ ^ 2
          ≤ ∑ p' ∈ cert.B, cert.coeff p' * ‖pts p - q‖ ^ 2 := by
            refine Finset.sum_le_sum (fun p' hp' => ?_)
            have hle_sup : ‖pts p' - q‖ ^ 2 ≤ ‖pts p - q‖ ^ 2 := by
              rw [← hp_eq]
              exact Finset.le_sup' (fun z => ‖pts z - q‖ ^ 2) hp'
            exact mul_le_mul_of_nonneg_left hle_sup (cert.coeff_nonneg p' hp')
      _ = (∑ p' ∈ cert.B, cert.coeff p') * ‖pts p - q‖ ^ 2 := by
            rw [← Finset.sum_mul]
      _ = ‖pts p - q‖ ^ 2 := by
            rw [cert.sum_coeff, one_mul]
  have hvar := cert_variance_identity cert q
  have hwit : IsVarianceWitness o (liftVariance o s) q (pts p) := by
    unfold IsVarianceWitness
    linarith
  exact ⟨p, hpB, hintact hpB, havg_le, hwit⟩

private def applyOp {ι : Type*} [DecidableEq ι]
    (acc : Finset ι) (op : ι ⊕ ι) : Finset ι :=
  match op with
  | Sum.inl i => insert i acc
  | Sum.inr i => acc.erase i

private lemma card_sdiff_foldl_le {ι : Type*} [DecidableEq ι]
    (B : Finset ι) (ops : List (ι ⊕ ι)) (A : Finset ι) :
    (B \ ops.foldl applyOp A).card ≤ (B \ A).card + (ops.filter Sum.isRight).length := by
  induction ops generalizing A with
  | nil =>
    simp
  | cons op tl ih =>
    simp only [List.foldl_cons]
    have htl := ih (applyOp A op)
    cases op with
    | inl i =>
      simp only [applyOp, List.filter_cons_of_neg (by simp : ¬Sum.isRight (Sum.inl i : ι ⊕ ι))] at htl ⊢
      have hsub : B \ insert i A ⊆ B \ A := by
        intro x hx
        rw [Finset.mem_sdiff] at hx ⊢
        exact ⟨hx.1, fun hA => hx.2 (Finset.mem_insert_of_mem hA)⟩
      have hcard : (B \ insert i A).card ≤ (B \ A).card := Finset.card_le_card hsub
      omega
    | inr i =>
      simp only [applyOp, List.filter_cons_of_pos (by simp : Sum.isRight (Sum.inr i : ι ⊕ ι)),
        List.length_cons] at htl ⊢
      have hsub : B \ A.erase i ⊆ insert i (B \ A) := by
        intro x hx
        rw [Finset.mem_sdiff, Finset.mem_erase] at hx
        by_cases hxi : x = i
        · exact hxi ▸ Finset.mem_insert_self i (B \ A)
        · exact Finset.mem_insert_of_mem (Finset.mem_sdiff.mpr ⟨hx.1, fun hA => hx.2 ⟨hxi, hA⟩⟩)
      have hcard : (B \ A.erase i).card ≤ (B \ A).card + 1 :=
        (Finset.card_le_card hsub).trans (Finset.card_insert_le i (B \ A))
      omega

end Proof_clm_5_1_block_witness

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_5_1_block_witness : S_clm_5_1_block_witness := by
  unfold S_clm_5_1_block_witness
  intro d ι _ pts P₀ o s β r₀ certs hβm hr₀ hdisj
  dsimp only
  refine ⟨?_, ?_, ?_⟩
  · intro S j hintact
    refine ⟨?_, ?_, ?_⟩
    · intro q
      exact Proof_clm_5_1_block_witness.cert_variance_identity (certs j) q
    · intro q
      exact Proof_clm_5_1_block_witness.cert_witness (certs j) hintact q
    · intro y hy
      rcases hy with ⟨hyS, hyR⟩
      obtain ⟨p, hpB, hpS, _, hwit⟩ :=
        Proof_clm_5_1_block_witness.cert_witness (certs j) hintact (pts y)
      refine ⟨p, hpB, hyS, hpS, ?_⟩
      unfold IsVarianceWitness at hwit
      rw [norm_sub_rev (pts y) (pts p), ← hyR]
      exact hwit
  · intro S x
    rw [Finset.card_le_one]
    intro j₁ hj₁ j₂ hj₂
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hj₁ hj₂
    have hx₁ : x ∈ (certs j₁).B := by
      by_contra hx₁
      apply hj₁.2
      intro z hz
      refine Finset.mem_erase.mpr ⟨?_, hj₁.1 hz⟩
      rintro rfl
      exact hx₁ hz
    have hx₂ : x ∈ (certs j₂).B := by
      by_contra hx₂
      apply hj₂.2
      intro z hz
      refine Finset.mem_erase.mpr ⟨?_, hj₂.1 hz⟩
      rintro rfl
      exact hx₂ hz
    by_contra hne
    exact Finset.disjoint_left.mp (hdisj hne) hx₁ hx₂
  · intro ops ha
    let a : ℕ := (ops.filter Sum.isRight).length
    have ha_lt_real : (a : ℝ) < (r₀ : ℝ) := by
      change ((ops.filter Sum.isRight).length : ℝ) < (r₀ : ℝ)
      linarith
    have ha_lt : a < r₀ := by exact_mod_cast ha_lt_real
    refine ⟨ha_lt_real, ?_⟩
    let S : Finset ι := ops.foldl Proof_clm_5_1_block_witness.applyOp P₀
    change ∃ j : Fin r₀, (certs j).IsIntact S
    have hdiff_le : (P₀ \ S).card ≤ a := by
      have h1 := Proof_clm_5_1_block_witness.card_sdiff_foldl_le P₀ ops P₀
      simp only [sdiff_self, Finset.bot_eq_empty, Finset.card_empty, zero_add] at h1
      exact h1
    by_contra hnone
    push_neg at hnone
    let t : Fin r₀ → Finset ι := fun j => (certs j).B ∩ (P₀ \ S)
    have ht_pos : ∀ j : Fin r₀, 1 ≤ (t j).card := by
      intro j
      have hnot_sub : ¬ ((certs j).B ⊆ S) := hnone j
      obtain ⟨z, hzB, hzS⟩ := Finset.not_subset.mp hnot_sub
      have hz_mem : z ∈ t j :=
        Finset.mem_inter.mpr ⟨hzB, Finset.mem_sdiff.mpr ⟨(certs j).subset_birth hzB, hzS⟩⟩
      exact Finset.one_le_card.mpr ⟨z, hz_mem⟩
    have ht_disj : ((Finset.univ : Finset (Fin r₀)) : Set (Fin r₀)).PairwiseDisjoint t := by
      intro j₁ _ j₂ _ hne
      exact Disjoint.mono Finset.inter_subset_left Finset.inter_subset_left (hdisj hne)
    have hbi_sub : Finset.univ.biUnion t ⊆ P₀ \ S :=
      Finset.biUnion_subset.mpr (fun _ _ => Finset.inter_subset_right)
    have hr₀_le : r₀ ≤ (P₀ \ S).card := by
      calc
        r₀ = ∑ _j ∈ (Finset.univ : Finset (Fin r₀)), 1 := by simp
        _ ≤ ∑ j ∈ (Finset.univ : Finset (Fin r₀)), (t j).card :=
          Finset.sum_le_sum (fun j _ => ht_pos j)
        _ = (Finset.univ.biUnion t).card := (Finset.card_biUnion ht_disj).symm
        _ ≤ (P₀ \ S).card := Finset.card_le_card hbi_sub
    omega

end UL
