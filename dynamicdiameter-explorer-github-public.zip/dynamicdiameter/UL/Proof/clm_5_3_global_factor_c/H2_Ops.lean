import UL.Stmt.clm_5_3_global_factor_c
import UL.Proof.clm_5_3_matching_invariant.H1
set_option autoImplicit false

namespace UL.Proof_clm_5_3_global_factor_c

open UL
open UL.Proof_clm_5_3_matching_invariant

open Classical in
private noncomputable def indexSymmDiffCost {ι : Type*}
    (st st' : LocalMatchingState ι) : ℕ :=
  (symmDiff st.leftIndexSet st'.leftIndexSet).card +
    (symmDiff st.rightIndexSet st'.rightIndexSet).card

open Classical in
private lemma symmDiff_card_triangle {ι : Type*} (A B C : Finset ι) :
    (symmDiff A C).card ≤ (symmDiff A B).card + (symmDiff B C).card := by
  have hsub : symmDiff A C ⊆ symmDiff A B ∪ symmDiff B C := by
    intro x hx
    unfold symmDiff at hx ⊢
    simp only [Finset.sup_eq_union, Finset.mem_union, Finset.mem_sdiff] at hx ⊢
    tauto
  exact le_trans (Finset.card_le_card hsub) (Finset.card_union_le _ _)

open Classical in
private lemma symmDiff_self_card {ι : Type*} (A : Finset ι) :
    (symmDiff A A).card = 0 := by
  have h : symmDiff A A = ∅ := by
    ext x
    unfold symmDiff
    simp
  rw [h, Finset.card_empty]

open Classical in
private lemma symmDiff_insert_card_le_one {ι : Type*} (A : Finset ι) (x : ι) :
    (symmDiff A (insert x A)).card ≤ 1 := by
  have hsub : symmDiff A (insert x A) ⊆ {x} := by
    intro z hz
    unfold symmDiff at hz
    simp only [Finset.sup_eq_union, Finset.mem_union, Finset.mem_sdiff, Finset.mem_insert,
      Finset.mem_singleton] at hz ⊢
    tauto
  exact le_trans (Finset.card_le_card hsub) (by simp)

open Classical in
private lemma symmDiff_erase_card_le_one {ι : Type*} (A : Finset ι) (x : ι) :
    (symmDiff A (A.erase x)).card ≤ 1 := by
  have hsub : symmDiff A (A.erase x) ⊆ {x} := by
    intro z hz
    unfold symmDiff at hz
    simp only [Finset.sup_eq_union, Finset.mem_union, Finset.mem_sdiff, Finset.mem_erase,
      Finset.mem_singleton] at hz ⊢
    tauto
  exact le_trans (Finset.card_le_card hsub) (by simp)

open Classical in
private lemma indexSymmDiffCost_refl {ι : Type*} (st : LocalMatchingState ι) :
    indexSymmDiffCost st st = 0 := by
  simp [indexSymmDiffCost, symmDiff_self_card]

open Classical in
private lemma indexSymmDiffCost_triangle {ι : Type*}
    (s1 s2 s3 : LocalMatchingState ι) :
    indexSymmDiffCost s1 s3 ≤ indexSymmDiffCost s1 s2 + indexSymmDiffCost s2 s3 := by
  have hL := symmDiff_card_triangle s1.leftIndexSet s2.leftIndexSet s3.leftIndexSet
  have hR := symmDiff_card_triangle s1.rightIndexSet s2.rightIndexSet s3.rightIndexSet
  unfold indexSymmDiffCost
  omega

open Classical in
private lemma attachStep_cost_le_one {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (st : LocalMatchingState ι) (v : CopyVertex ι) (ans : Option ι) :
    indexSymmDiffCost st (attachStep pts st v ans) ≤ 1 := by
  rcases v with ⟨side, vid⟩
  cases side with
  | left =>
    cases ans with
    | none =>
      have hL : (attachStep pts st ⟨.left, vid⟩ none).leftIndexSet =
          insert vid st.leftIndexSet := by
        ext z
        simp [attachStep, LocalMatchingState.leftIndexSet, List.mem_toFinset, List.mem_map,
          Finset.mem_insert, eq_comm]
      have hR : (attachStep pts st ⟨.left, vid⟩ none).rightIndexSet = st.rightIndexSet := rfl
      unfold indexSymmDiffCost
      rw [hL, hR, symmDiff_self_card]
      have h1 := symmDiff_insert_card_le_one st.leftIndexSet vid
      omega
    | some w =>
      have hL : (attachStep pts st ⟨.left, vid⟩ (some w)).leftIndexSet = st.leftIndexSet := rfl
      have hR : (attachStep pts st ⟨.left, vid⟩ (some w)).rightIndexSet =
          st.rightIndexSet.erase w := by
        ext z
        simp only [attachStep, LocalMatchingState.rightIndexSet, List.mem_toFinset, List.mem_map,
          List.mem_filter, decide_eq_true_eq, Finset.mem_erase]
        constructor
        · rintro ⟨e, ⟨he, hne⟩, rfl⟩
          exact ⟨hne, e, he, rfl⟩
        · rintro ⟨hne, e, he, rfl⟩
          exact ⟨e, ⟨he, hne⟩, rfl⟩
      unfold indexSymmDiffCost
      rw [hL, hR, symmDiff_self_card]
      have h1 := symmDiff_erase_card_le_one st.rightIndexSet w
      omega
  | right =>
    cases ans with
    | none =>
      have hL : (attachStep pts st ⟨.right, vid⟩ none).leftIndexSet = st.leftIndexSet := rfl
      have hR : (attachStep pts st ⟨.right, vid⟩ none).rightIndexSet =
          insert vid st.rightIndexSet := by
        ext z
        simp [attachStep, LocalMatchingState.rightIndexSet, List.mem_toFinset, List.mem_map,
          Finset.mem_insert, eq_comm]
      unfold indexSymmDiffCost
      rw [hL, hR, symmDiff_self_card]
      have h1 := symmDiff_insert_card_le_one st.rightIndexSet vid
      omega
    | some w =>
      have hL : (attachStep pts st ⟨.right, vid⟩ (some w)).leftIndexSet =
          st.leftIndexSet.erase w := by
        ext z
        simp only [attachStep, LocalMatchingState.leftIndexSet, List.mem_toFinset, List.mem_map,
          List.mem_filter, decide_eq_true_eq, Finset.mem_erase]
        constructor
        · rintro ⟨e, ⟨he, hne⟩, rfl⟩
          exact ⟨hne, e, he, rfl⟩
        · rintro ⟨hne, e, he, rfl⟩
          exact ⟨e, ⟨he, hne⟩, rfl⟩
      have hR : (attachStep pts st ⟨.right, vid⟩ (some w)).rightIndexSet = st.rightIndexSet := rfl
      unfold indexSymmDiffCost
      rw [hL, hR, symmDiff_self_card]
      have h1 := symmDiff_erase_card_le_one st.leftIndexSet w
      omega

open Classical in
private lemma removeCopies_cost_le_two {ι : Type*}
    (st : LocalMatchingState ι) (p : ι) :
    indexSymmDiffCost st (removeCopiesFromState st p) ≤ 2 := by
  have hL : (removeCopiesFromState st p).leftIndexSet = st.leftIndexSet.erase p := by
    ext z
    simp only [removeCopiesFromState, LocalMatchingState.leftIndexSet, List.mem_toFinset,
      List.mem_map, List.mem_filter, decide_eq_true_eq, Finset.mem_erase]
    constructor
    · rintro ⟨e, ⟨he, hne⟩, rfl⟩
      exact ⟨hne, e, he, rfl⟩
    · rintro ⟨hne, e, he, rfl⟩
      exact ⟨e, ⟨he, hne⟩, rfl⟩
  have hR : (removeCopiesFromState st p).rightIndexSet = st.rightIndexSet.erase p := by
    ext z
    simp only [removeCopiesFromState, LocalMatchingState.rightIndexSet, List.mem_toFinset,
      List.mem_map, List.mem_filter, decide_eq_true_eq, Finset.mem_erase]
    constructor
    · rintro ⟨e, ⟨he, hne⟩, rfl⟩
      exact ⟨hne, e, he, rfl⟩
    · rintro ⟨hne, e, he, rfl⟩
      exact ⟨e, ⟨he, hne⟩, rfl⟩
  unfold indexSymmDiffCost
  rw [hL, hR]
  have h1 := symmDiff_erase_card_le_one st.leftIndexSet p
  have h2 := symmDiff_erase_card_le_one st.rightIndexSet p
  omega

open Classical in
private lemma validRepairAngularSteps_cost_le {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {a b : ℝ} {V_L' V_R' : Finset ι}
    (F : List (CopyVertex ι))
    (st st' : LocalMatchingState ι)
    (hrep : ValidRepairAngularSteps pts o a b V_L' V_R' st F st') :
    indexSymmDiffCost st st' ≤ F.length := by
  induction F generalizing st with
  | nil =>
    simp only [ValidRepairAngularSteps] at hrep
    rw [hrep, indexSymmDiffCost_refl]
    exact Nat.zero_le _
  | cons u us ih =>
    simp only [ValidRepairAngularSteps, List.length_cons] at hrep ⊢
    rcases hrep with ⟨_, hrest⟩ | ⟨_, st₁, ⟨_, ans, _, hst₁⟩, hrest⟩
    · have h1 := ih st hrest
      omega
    · have hc1 : indexSymmDiffCost st st₁ ≤ 1 := by
        rw [hst₁]
        exact attachStep_cost_le_one pts st u ans
      have hc2 := ih st₁ hrest
      have htri := indexSymmDiffCost_triangle st st₁ st'
      omega

open Classical in
private lemma repairFormerPartners_take {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (F : List (CopyVertex ι)) :
    ∀ (cur : LocalMatchingState ι) (answers : List (Option ι)) (n : ℕ),
      F.length ≤ n →
      repairFormerPartners pts cur F answers =
        repairFormerPartners pts cur F (answers.take n) := by
  induction F with
  | nil =>
    intro cur answers n _
    rfl
  | cons u us ih =>
    intro cur answers n hlen
    cases n with
    | zero =>
      simp at hlen
    | succ m =>
      simp only [List.length_cons, Nat.succ_le_succ_iff] at hlen
      unfold repairFormerPartners
      split_ifs with hskip
      · exact ih cur answers (m + 1) (Nat.le_succ_of_le hlen)
      · cases answers with
        | nil => rfl
        | cons ans rest =>
          dsimp only
          exact ih (attachStep pts cur u ans) rest m hlen

private lemma validAttach_to_repair_singleton {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {a b : ℝ} {V_L' V_R' : Finset ι}
    {st st₁ : LocalMatchingState ι} {u : CopyVertex ι}
    (hatt : ValidAttachAngularStep pts o a b V_L' V_R' st u st₁) :
    ValidRepairAngularSteps pts o a b V_L' V_R' st [u] st₁ :=
  Or.inr ⟨not_or.mpr ⟨hatt.1.2.1, hatt.1.2.2⟩, st₁, hatt, rfl⟩

open Classical in
theorem prove_conjunct_2 :
    ∃ C_ops : ℕ,
      ∀ (d : ℕ) (ι : Type)
        (pts : ι → EuclideanSpace ℝ (Fin d))
        (params : LocalScaleParams)
        (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
        (S : Finset ι) (cfg : ShellConfig) (st : LocalMatchingState ι),
        0 < V →
        cfg ∈ params.retainedConfigs V →
        st.WellFormed pts
          (params.leftVertices pts o V S cfg.j)
          (params.rightVertices pts o V S cfg.k) →
        let a := params.thresholdA V cfg.j cfg.k cfg.ℓ
        let b := params.thresholdB V cfg.j cfg.k cfg.ℓ
        (∀ (p : ι), p ∉ S →
          let V_L' := params.leftVertices pts o V (insert p S) cfg.j
          let V_R' := params.rightVertices pts o V (insert p S) cfg.k
          ((¬ hasApplicableLeftCopy params.m0 o V cfg.j (pts p) ∧
              ¬ hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p)) →
            (∀ ansLeft ansRight : Option ι,
              configInsertOriginalStep pts params.m0 o V params.K cfg.j cfg.k st p ansLeft ansRight = st) ∧
            (∀ st' : LocalMatchingState ι,
              ValidInsertOriginalAngularStep pts o a b V_L' V_R' st p st' → st' = st)) ∧
          (∀ st' : LocalMatchingState ι,
            ValidInsertOriginalAngularStep pts o a b V_L' V_R' st p st' →
            (∃ copies : List (CopyVertex ι),
              copies.length ≤ C_ops ∧
              ValidRepairAngularSteps pts o a b V_L' V_R' st copies st') ∧
            (symmDiff st.leftIndexSet st'.leftIndexSet).card +
              (symmDiff st.rightIndexSet st'.rightIndexSet).card ≤ C_ops)) ∧
        (∀ (p : ι), p ∈ S →
          let V_L := params.leftVertices pts o V S cfg.j
          let V_R := params.rightVertices pts o V S cfg.k
          let V_L' := params.leftVertices pts o V (S.erase p) cfg.j
          let V_R' := params.rightVertices pts o V (S.erase p) cfg.k
          ((p ∉ V_L ∧ p ∉ V_R) →
            removeCopiesFromState st p = st ∧
            survivingFormerPartners st p = [] ∧
            (∀ st' : LocalMatchingState ι,
              ValidDeleteOriginalAngularStep pts o a b V_L' V_R' st p st' → st' = st)) ∧
          (st.leftUnmatchedIndex.filter (fun e => e.id = p)).length +
            (st.rightUnmatchedIndex.filter (fun e => e.id = p)).length +
            (survivingFormerPartners st p).length ≤ C_ops ∧
          (∀ answers : List (Option ι),
            deleteOriginalStep pts st p answers =
              deleteOriginalStep pts st p (answers.take C_ops)) ∧
          (∀ st' : LocalMatchingState ι,
            ValidDeleteOriginalAngularStep pts o a b V_L' V_R' st p st' →
            (∃ F : List (CopyVertex ι),
              F.length ≤ C_ops ∧
              ValidRepairAngularSteps pts o a b V_L' V_R' (removeCopiesFromState st p) F st') ∧
            (symmDiff st.leftIndexSet st'.leftIndexSet).card +
              (symmDiff st.rightIndexSet st'.rightIndexSet).card ≤ C_ops)) := by
  refine ⟨4, ?_⟩
  intro d ι pts params o V S cfg st _ _ hwf
  dsimp only
  let a := params.thresholdA V cfg.j cfg.k cfg.ℓ
  let b := params.thresholdB V cfg.j cfg.k cfg.ℓ
  refine ⟨?_, ?_⟩
  · intro p _
    let V_L' := params.leftVertices pts o V (insert p S) cfg.j
    let V_R' := params.rightVertices pts o V (insert p S) cfg.k
    refine ⟨?_, ?_⟩
    · rintro ⟨hnoL, hnoR⟩
      refine ⟨?_, ?_⟩
      · intro ansLeft ansRight
        simp [configInsertOriginalStep, insertOriginalStep, hnoL, hnoR]
      · intro st' hins
        have hp_notL : p ∉ V_L' := by
          intro hpL
          simp only [V_L', LocalScaleParams.leftVertices, configLeftVertices, shellSubset,
            nodeCore, Finset.mem_filter] at hpL
          exact hnoL ⟨hpL.1.2, hpL.2⟩
        have hp_notR : p ∉ V_R' := by
          intro hpR
          simp only [V_R', LocalScaleParams.rightVertices, configRightVertices, shellSubset,
            nodeEligible, Finset.mem_filter] at hpR
          exact hnoR ⟨hpR.1.2, hpR.2⟩
        rcases hins with ⟨st₁, hL, hR⟩
        have hst₁ : st₁ = st := by
          rcases hL with ⟨hpL, _⟩ | ⟨_, hEq⟩
          · exact False.elim (hp_notL hpL)
          · exact hEq
        rcases hR with ⟨hpR, _⟩ | ⟨_, hEq⟩
        · exact False.elim (hp_notR hpR)
        · exact hEq.trans hst₁
    · intro st' hins
      have hcopies : ∃ copies : List (CopyVertex ι),
          copies.length ≤ 2 ∧
          ValidRepairAngularSteps pts o a b V_L' V_R' st copies st' := by
        rcases hins with ⟨st₁, hL, hR⟩
        rcases hL with ⟨_, hattL⟩ | ⟨_, rfl⟩
        · rcases hR with ⟨_, hattR⟩ | ⟨_, rfl⟩
          · refine ⟨[⟨.left, p⟩, ⟨.right, p⟩], by simp, ?_⟩
            exact Or.inr ⟨not_or.mpr ⟨hattL.1.2.1, hattL.1.2.2⟩, st₁, hattL,
              validAttach_to_repair_singleton hattR⟩
          · exact ⟨[⟨.left, p⟩], by simp, validAttach_to_repair_singleton hattL⟩
        · rcases hR with ⟨_, hattR⟩ | ⟨_, rfl⟩
          · exact ⟨[⟨.right, p⟩], by simp, validAttach_to_repair_singleton hattR⟩
          · exact ⟨[], by simp, rfl⟩
      obtain ⟨copies, hlen2, hrep⟩ := hcopies
      have hcost := validRepairAngularSteps_cost_le copies st st' hrep
      unfold indexSymmDiffCost at hcost
      exact ⟨⟨copies, by omega, hrep⟩, by omega⟩
  · intro p _
    let V_L := params.leftVertices pts o V S cfg.j
    let V_R := params.rightVertices pts o V S cfg.k
    let V_L' := params.leftVertices pts o V (S.erase p) cfg.j
    let V_R' := params.rightVertices pts o V (S.erase p) cfg.k
    have hbnds := surviving_partners_bounds hwf p
    rcases hwf with ⟨hndML, hndMR, hedges, hndUL, hLset, hndUR, hRset, hrest_wf⟩
    have hwf' : st.WellFormed pts V_L V_R :=
      ⟨hndML, hndMR, hedges, hndUL, hLset, hndUR, hRset, hrest_wf⟩
    refine ⟨?_, ?_, ?_, ?_⟩
    · rintro ⟨hp_notL, hp_notR⟩
      have hm_eq : st.matchingList.filter (fun e => decide (e.left ≠ p ∧ e.right ≠ p)) =
          st.matchingList := by
        rw [List.filter_eq_self]
        intro e he
        rw [decide_eq_true_eq]
        rcases hedges e he with ⟨heL, heR, _⟩
        exact ⟨fun h => hp_notL (h ▸ heL), fun h => hp_notR (h ▸ heR)⟩
      have hl_eq : st.leftUnmatchedIndex.filter (fun e => decide (e.id ≠ p)) =
          st.leftUnmatchedIndex := by
        rw [List.filter_eq_self]
        intro e he
        rw [decide_eq_true_eq]
        intro hEq
        have hmem : e.id ∈ st.leftIndexSet := by
          unfold LocalMatchingState.leftIndexSet
          exact List.mem_toFinset.mpr (List.mem_map_of_mem he)
        rw [hLset] at hmem
        have hinVL : e.id ∈ V_L := (Finset.mem_filter.mp hmem).1
        rw [hEq] at hinVL
        exact hp_notL hinVL
      have hr_eq : st.rightUnmatchedIndex.filter (fun e => decide (e.id ≠ p)) =
          st.rightUnmatchedIndex := by
        rw [List.filter_eq_self]
        intro e he
        rw [decide_eq_true_eq]
        intro hEq
        have hmem : e.id ∈ st.rightIndexSet := by
          unfold LocalMatchingState.rightIndexSet
          exact List.mem_toFinset.mpr (List.mem_map_of_mem he)
        rw [hRset] at hmem
        have hinVR : e.id ∈ V_R := (Finset.mem_filter.mp hmem).1
        rw [hEq] at hinVR
        exact hp_notR hinVR
      have hrem_eq : removeCopiesFromState st p = st := by
        cases st
        simp only [removeCopiesFromState] at hm_eq hl_eq hr_eq ⊢
        congr
      have hsurv_nil : survivingFormerPartners st p = [] := by
        have hrp : st.matchingList.filter (fun e => decide (e.left = p ∧ e.right ≠ p)) = [] := by
          rw [List.filter_eq_nil_iff]
          intro e he hdec
          rw [decide_eq_true_eq] at hdec
          have heL := (hedges e he).1
          rw [hdec.1] at heL
          exact hp_notL heL
        have hlp : st.matchingList.filter (fun e => decide (e.right = p ∧ e.left ≠ p)) = [] := by
          rw [List.filter_eq_nil_iff]
          intro e he hdec
          rw [decide_eq_true_eq] at hdec
          have heR := (hedges e he).2.1
          rw [hdec.1] at heR
          exact hp_notR heR
        unfold survivingFormerPartners
        dsimp only
        rw [hrp, hlp]
        simp
      refine ⟨hrem_eq, hsurv_nil, ?_⟩
      intro st' hdel
      rcases hdel with ⟨F, hperm, hrep⟩
      rw [hsurv_nil] at hperm
      cases F with
      | nil =>
        simp only [ValidRepairAngularSteps] at hrep
        exact hrep.trans hrem_eq
      | cons u us =>
        exfalso
        have hmem := hperm.mem_iff.mp List.mem_cons_self
        simp at hmem
    · have hlenL : (st.leftUnmatchedIndex.filter (fun e => decide (e.id = p))).length ≤ 1 :=
        filter_eq_length_le_one hndUL _ p (fun x hx => of_decide_eq_true hx)
      have hlenR : (st.rightUnmatchedIndex.filter (fun e => decide (e.id = p))).length ≤ 1 :=
        filter_eq_length_le_one hndUR _ p (fun x hx => of_decide_eq_true hx)
      have hlenF : (survivingFormerPartners st p).length ≤ 2 := hbnds.2
      omega
    · intro answers
      unfold deleteOriginalStep
      exact repairFormerPartners_take pts (survivingFormerPartners st p)
        (removeCopiesFromState st p) answers 4 (by omega)
    · intro st' hdel
      rcases hdel with ⟨F, hperm, hrep⟩
      have hFlen : F.length ≤ 2 := by
        rw [hperm.length_eq]
        exact hbnds.2
      have hcost_rem := removeCopies_cost_le_two st p
      have hcost_rep := validRepairAngularSteps_cost_le F (removeCopiesFromState st p) st' hrep
      have htri := indexSymmDiffCost_triangle st (removeCopiesFromState st p) st'
      unfold indexSymmDiffCost at hcost_rem hcost_rep htri
      exact ⟨⟨F, by omega, hrep⟩, by omega⟩

end UL.Proof_clm_5_3_global_factor_c
