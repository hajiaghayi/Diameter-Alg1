import UL.Stmt.clm_5_3_global_factor_c
import UL.Stmt.lem_5_5
import UL.Proof.lem_5_5.H1
set_option autoImplicit false

namespace UL.Proof_clm_5_3_global_factor_c

open UL

private lemma baselinePairLength_nonneg {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (pair : Option (ι × ι)) :
    0 ≤ baselinePairLength pts pair := by
  cases pair with
  | none => simp [baselinePairLength]
  | some uv => simp [baselinePairLength]

private lemma indexedEuclideanDiam_mono {d : ℕ} {ι : Type*}
    {S P : Finset ι} (pts : ι → EuclideanSpace ℝ (Fin d)) (hsub : S ⊆ P) :
    indexedEuclideanDiam S pts ≤ indexedEuclideanDiam P pts := by
  by_cases hS : S.Nonempty
  · have hEq : indexedEuclideanDiam S pts =
        (S ×ˢ S).sup' (hS.product hS) (fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) := by
      unfold indexedEuclideanDiam
      rw [dif_pos hS]
    rw [hEq]
    apply Finset.sup'_le
    intro xy hxy
    rcases Finset.mem_product.mp hxy with ⟨hx, hy⟩
    exact UL.Proof_lem_5_5.pair_norm_le_indexedEuclideanDiam P pts (hsub hx) (hsub hy)
  · have h0 : indexedEuclideanDiam S pts = 0 := by
      unfold indexedEuclideanDiam
      rw [dif_neg hS]
    rw [h0]
    exact UL.Proof_lem_5_5.indexedEuclideanDiam_nonneg P pts

private lemma chainInput_zero {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι) :
    chainInput pts nodes P 0 = P :=
  rfl

private lemma chainInput_succ {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (i : Fin k) :
    chainInput pts nodes P i.succ =
      (nodes i).residual pts (chainInput pts nodes P i.castSucc) :=
  rfl

open Classical in
private lemma chainInput_subset {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (j : Fin (k + 1)) :
    chainInput pts nodes P j ⊆ P := by
  induction j using Fin.induction with
  | zero =>
    rw [chainInput_zero]
  | succ i ih =>
    rw [chainInput_succ]
    unfold ChainNode.residual nodeResidual
    exact Finset.sdiff_subset.trans ih

open Classical in
private lemma chain_dichotomy_aux {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    {x y : ι} (hx : x ∈ P) (hy : y ∈ P) (j : Fin (k + 1)) :
    (x ∈ chainInput pts nodes P j ∧ y ∈ chainInput pts nodes P j) ∨
      ∃ i : Fin k,
        x ∈ chainInput pts nodes P i.castSucc ∧
        y ∈ chainInput pts nodes P i.castSucc ∧
        (x ∈ chainCore pts nodes P i ∨ y ∈ chainCore pts nodes P i) := by
  induction j using Fin.induction with
  | zero =>
    left
    simpa [chainInput_zero] using ⟨hx, hy⟩
  | succ m ih =>
    rcases ih with ⟨hxm, hym⟩ | ⟨i, hi⟩
    · by_cases hcore : x ∈ chainCore pts nodes P m ∨ y ∈ chainCore pts nodes P m
      · right
        exact ⟨m, hxm, hym, hcore⟩
      · left
        push_neg at hcore
        rw [chainInput_succ]
        unfold ChainNode.residual nodeResidual
        change x ∈ chainInput pts nodes P m.castSucc \ chainCore pts nodes P m ∧
          y ∈ chainInput pts nodes P m.castSucc \ chainCore pts nodes P m
        exact ⟨Finset.mem_sdiff.mpr ⟨hxm, hcore.1⟩, Finset.mem_sdiff.mpr ⟨hym, hcore.2⟩⟩
    · right
      exact ⟨i, hi⟩

open Classical in
private lemma norm_le_nodeCoreInputDiam {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    {S : Finset ι} {u v : ι}
    (huC : u ∈ nodeCore pts o V S) (hvS : v ∈ S) :
    ‖pts u - pts v‖ ≤ nodeCoreInputDiam pts o V S := by
  have hcond : (nodeCore pts o V S).Nonempty ∧ S.Nonempty := ⟨⟨u, huC⟩, ⟨v, hvS⟩⟩
  have hmem : (u, v) ∈ nodeCore pts o V S ×ˢ S := Finset.mem_product.mpr ⟨huC, hvS⟩
  unfold nodeCoreInputDiam indexedCoreInputDiam
  rw [dif_pos hcond]
  exact Finset.le_sup' (f := fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) hmem

private lemma activePair_realizer_of_pos {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {S : Finset ι} {pair : Option (ι × ι)}
    (hact : IsActiveNodePair S pair)
    (hpos : 0 < baselinePairLength pts pair) :
    ∃ x y : ι, x ∈ S ∧ y ∈ S ∧
      ‖pts x - pts y‖ = baselinePairLength pts pair ∧
      pair = some (x, y) := by
  cases hpair : pair with
  | none =>
    rw [hpair] at hpos
    simp [baselinePairLength] at hpos
  | some xy =>
    rcases xy with ⟨x, y⟩
    rw [hpair] at hact
    exact ⟨x, y, hact.1, hact.2, by simp [baselinePairLength], rfl⟩

open Classical in
private lemma stored_edge_endpoints_in_S {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)}
    {params : LocalScaleParams}
    {o : EuclideanSpace ℝ (Fin d)} {V : ℝ} {S : Finset ι}
    {cfg : ShellConfig} {M_cfg : Finset (ι × ι)} {st_cfg : Option (ι × ι)}
    {x y : ι}
    (hm : params.SatisfiesMatchingInvariant pts o V S cfg.j cfg.k cfg.ℓ M_cfg ∧
      IsStoredMatchingEdge M_cfg st_cfg)
    (hst : st_cfg = some (x, y)) :
    x ∈ S ∧ y ∈ S := by
  have hxyM : (x, y) ∈ M_cfg := by
    simpa [IsStoredMatchingEdge, hst] using hm.2
  have hxyW : (x, y) ∈ configWeakEdges pts params.m0 params.lam o V params.K S cfg.j cfg.k cfg.ℓ :=
    hm.1.1 hxyM
  have hxyProd : (x, y) ∈ configLeftVertices pts params.m0 o V S cfg.j ×ˢ
      configRightVertices pts params.m0 o V params.K S cfg.k := by
    unfold configWeakEdges weakEdgesOn at hxyW
    exact (Finset.mem_filter.mp hxyW).1
  rcases Finset.mem_product.mp hxyProd with ⟨hxL, hyR⟩
  have hxCore : x ∈ nodeCore pts o V S := by
    unfold configLeftVertices shellSubset at hxL
    exact (Finset.mem_filter.mp hxL).1
  have hxS : x ∈ S := by
    unfold nodeCore at hxCore
    exact (Finset.mem_filter.mp hxCore).1
  have hyElig : y ∈ nodeEligible pts o V params.K S := by
    unfold configRightVertices shellSubset at hyR
    exact (Finset.mem_filter.mp hyR).1
  have hyS : y ∈ S := by
    unfold nodeEligible at hyElig
    exact (Finset.mem_filter.mp hyElig).1
  exact ⟨hxS, hyS⟩

open Classical in
private lemma nodeRetainedEstimate_realizer {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)}
    {params : LocalScaleParams}
    {o : EuclideanSpace ℝ (Fin d)} {V : ℝ} {S : Finset ι}
    {basePair : Option (ι × ι)}
    {M : ShellConfig → Finset (ι × ι)}
    {stored : ShellConfig → Option (ι × ι)}
    (h_base : SatisfiesNodeBaselineCond pts o V S basePair)
    (h_match : 0 < V →
      ∀ cfg ∈ params.retainedConfigs V,
        params.SatisfiesMatchingInvariant pts o V S cfg.j cfg.k cfg.ℓ (M cfg) ∧
        IsStoredMatchingEdge (M cfg) (stored cfg))
    (hpos : 0 < params.nodeRetainedEstimate pts V (baselinePairLength pts basePair) stored) :
    ∃ x y : ι, x ∈ S ∧ y ∈ S ∧
      ‖pts x - pts y‖ =
        params.nodeRetainedEstimate pts V (baselinePairLength pts basePair) stored ∧
      (basePair = some (x, y) ∨
        (0 < V ∧ ∃ cfg ∈ params.retainedConfigs V, stored cfg = some (x, y))) := by
  let L := baselinePairLength pts basePair
  let W := params.nodeRetainedEstimate pts V L stored
  change 0 < W at hpos
  change ∃ x y : ι, x ∈ S ∧ y ∈ S ∧ ‖pts x - pts y‖ = W ∧ _
  have hW_def : W = (if 0 < V then
      matchingEstimateOn pts L (params.retainedConfigs V) stored else L) := rfl
  by_cases hVpos : 0 < V
  · have hW_V : W = matchingEstimateOn pts L (params.retainedConfigs V) stored := by
      rw [hW_def, if_pos hVpos]
    unfold matchingEstimateOn at hW_V
    split_ifs at hW_V with hNE
    · obtain ⟨cfg, hcfg, hsup⟩ :=
        Finset.exists_mem_eq_sup' hNE (fun c => storedEdgeCandidate pts L (stored c))
      have hW_cfg : W = storedEdgeCandidate pts L (stored cfg) := hW_V.trans hsup
      cases hst : stored cfg with
      | none =>
        have hWL : W = L := by simpa [storedEdgeCandidate, hst] using hW_cfg
        have hLpos : 0 < L := hWL ▸ hpos
        obtain ⟨x, y, hx, hy, hnorm, hbp⟩ := activePair_realizer_of_pos h_base.1 hLpos
        exact ⟨x, y, hx, hy, hnorm.trans hWL.symm, Or.inl hbp⟩
      | some uv =>
        rcases uv with ⟨u, v⟩
        have hW_max : W = max L ‖pts u - pts v‖ := by
          simpa [storedEdgeCandidate, hst] using hW_cfg
        by_cases hle : L ≤ ‖pts u - pts v‖
        · have hW_uv : W = ‖pts u - pts v‖ := hW_max.trans (max_eq_right hle)
          obtain ⟨hu, hv⟩ := stored_edge_endpoints_in_S (h_match hVpos cfg hcfg) hst
          exact ⟨u, v, hu, hv, hW_uv.symm, Or.inr ⟨hVpos, cfg, hcfg, hst⟩⟩
        · have hWL : W = L := hW_max.trans (max_eq_left (le_of_not_ge hle))
          have hLpos : 0 < L := hWL ▸ hpos
          obtain ⟨x, y, hx, hy, hnorm, hbp⟩ := activePair_realizer_of_pos h_base.1 hLpos
          exact ⟨x, y, hx, hy, hnorm.trans hWL.symm, Or.inl hbp⟩
    · have hLpos : 0 < L := hW_V ▸ hpos
      obtain ⟨x, y, hx, hy, hnorm, hbp⟩ := activePair_realizer_of_pos h_base.1 hLpos
      exact ⟨x, y, hx, hy, hnorm.trans hW_V.symm, Or.inl hbp⟩
  · have hWL : W = L := by rw [hW_def, if_neg hVpos]
    have hLpos : 0 < L := hWL ▸ hpos
    obtain ⟨x, y, hx, hy, hnorm, hbp⟩ := activePair_realizer_of_pos h_base.1 hLpos
    exact ⟨x, y, hx, hy, hnorm.trans hWL.symm, Or.inl hbp⟩

open Classical in
theorem prove_conjunct_1 (h_lem_5_5 : S_lem_5_5) :
    ∀ (d : ℕ) (ι : Type) (k : ℕ)
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (P : Finset ι)
      (params : LocalScaleParams)
      (nodes : Fin k → ChainNode d)
      (basePairs : Fin k → Option (ι × ι))
      (M : Fin k → ShellConfig → Finset (ι × ι))
      (stored : Fin k → ShellConfig → Option (ι × ι))
      (leafPair : Option (ι × ι))
      (_ : ∀ i : Fin k,
        (nodes i).SatisfiesBaselineCond pts (chainInput pts nodes P i.castSucc) (basePairs i))
      (_ : ∀ i : Fin k,
        0 < (nodes i).V →
        ∀ cfg ∈ params.retainedConfigs (nodes i).V,
          params.SatisfiesMatchingInvariant pts (nodes i).o (nodes i).V
            (chainInput pts nodes P i.castSucc) cfg.j cfg.k cfg.ℓ (M i cfg) ∧
          IsStoredMatchingEdge (M i cfg) (stored i cfg))
      (_ : IsActiveNodePair (chainTerminal pts nodes P) leafPair)
      (_ : baselinePairLength pts leafPair = indexedEuclideanDiam (chainTerminal pts nodes P) pts),
    let W_max : ℝ :=
      (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty
        (Fin.lastCases (baselinePairLength pts leafPair)
          (fun i => params.nodeRetainedEstimate pts (nodes i).V
            (baselinePairLength pts (basePairs i)) (stored i)))
    W_max ∈ Set.Icc (indexedEuclideanDiam P pts / params.c) (indexedEuclideanDiam P pts) ∧
    (2 ≤ P.card →
      ∃ x y : ι,
        IsIndexedFactorCDiameterPair params.c P pts x y ∧
        (0 < W_max →
          ‖pts x - pts y‖ = W_max ∧
          (leafPair = some (x, y) ∨
            (∃ i : Fin k, basePairs i = some (x, y)) ∨
            (∃ i : Fin k,
              0 < (nodes i).V ∧
              ∃ cfg ∈ params.retainedConfigs (nodes i).V,
                stored i cfg = some (x, y))))) := by
  unfold S_lem_5_5 at h_lem_5_5
  intro d ι k pts P params nodes basePairs M stored leafPair h_base h_match h_leaf_active h_leaf_diam
  let f : Fin (k + 1) → ℝ :=
    Fin.lastCases (baselinePairLength pts leafPair)
      (fun i => params.nodeRetainedEstimate pts (nodes i).V
        (baselinePairLength pts (basePairs i)) (stored i))
  let W_max : ℝ := (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty f
  have hc_gt_one : (1 : ℝ) < params.c := params.one_lt_c
  have hc_pos : (0 : ℝ) < params.c := lt_trans zero_lt_one hc_gt_one
  have h_node_lem : ∀ i : Fin k,
      nodeCoreInputDiam pts (nodes i).o (nodes i).V (chainInput pts nodes P i.castSucc) / params.c ≤
        f i.castSucc ∧
      f i.castSucc ≤ indexedEuclideanDiam (chainInput pts nodes P i.castSucc) pts := by
    intro i
    have hi := h_lem_5_5 d ι pts (nodes i).o (nodes i).V
      (chainInput pts nodes P i.castSucc) params (basePairs i) (M i) (stored i)
      (nodes i).V_nonneg (h_base i) (h_match i)
    simpa [f, Fin.lastCases_castSucc] using hi
  have hW_nonneg : 0 ≤ W_max := by
    have hlast_nn : 0 ≤ f (Fin.last k) := by
      simp only [f, Fin.lastCases_last]
      exact baselinePairLength_nonneg pts leafPair
    exact hlast_nn.trans (Finset.le_sup' f (Finset.mem_univ (Fin.last k)))
  have hW_upper : W_max ≤ indexedEuclideanDiam P pts := by
    refine Finset.sup'_le Finset.univ_nonempty f ?_
    intro j _
    refine Fin.lastCases ?_ ?_ j
    · simp only [f, Fin.lastCases_last, h_leaf_diam]
      exact indexedEuclideanDiam_mono pts (chainInput_subset pts nodes P (Fin.last k))
    · intro i
      exact (h_node_lem i).2.trans
        (indexedEuclideanDiam_mono pts (chainInput_subset pts nodes P i.castSucc))
  have hW_lower : indexedEuclideanDiam P pts / params.c ≤ W_max := by
    by_cases hP : P.Nonempty
    · have hPP : (P ×ˢ P).Nonempty := hP.product hP
      obtain ⟨⟨x, y⟩, hxy_mem, hxy_eq⟩ :=
        Finset.exists_mem_eq_sup' hPP (fun z : ι × ι => ‖pts z.1 - pts z.2‖)
      rcases Finset.mem_product.mp hxy_mem with ⟨hx, hy⟩
      have hdiam_eq : indexedEuclideanDiam P pts = ‖pts x - pts y‖ := by
        unfold indexedEuclideanDiam
        rw [dif_pos hP]
        exact hxy_eq
      rcases chain_dichotomy_aux pts nodes P hx hy (Fin.last k) with
        ⟨hxT, hyT⟩ | ⟨i, hxS, hyS, hcore⟩
      · have hle_term : ‖pts x - pts y‖ ≤ indexedEuclideanDiam (chainTerminal pts nodes P) pts :=
          UL.Proof_lem_5_5.pair_norm_le_indexedEuclideanDiam _ pts hxT hyT
        have hdiv_le_self : indexedEuclideanDiam P pts / params.c ≤ indexedEuclideanDiam P pts := by
          rw [div_le_iff₀ hc_pos]
          have hd_nn := UL.Proof_lem_5_5.indexedEuclideanDiam_nonneg P pts
          nlinarith
        have hf_last : f (Fin.last k) = indexedEuclideanDiam (chainTerminal pts nodes P) pts := by
          simp [f, Fin.lastCases_last, h_leaf_diam]
        have hlast_le : f (Fin.last k) ≤ W_max :=
          Finset.le_sup' f (Finset.mem_univ (Fin.last k))
        linarith
      · have hi_le : f i.castSucc ≤ W_max :=
          Finset.le_sup' f (Finset.mem_univ i.castSucc)
        have h_lo_i := (h_node_lem i).1
        rcases hcore with hxC | hyC
        · have hle_DC : ‖pts x - pts y‖ ≤
              nodeCoreInputDiam pts (nodes i).o (nodes i).V (chainInput pts nodes P i.castSucc) :=
            norm_le_nodeCoreInputDiam pts (nodes i).o (nodes i).V hxC hyS
          have hdiv : ‖pts x - pts y‖ / params.c ≤
              nodeCoreInputDiam pts (nodes i).o (nodes i).V (chainInput pts nodes P i.castSucc) /
                params.c :=
            div_le_div_of_nonneg_right hle_DC (le_of_lt hc_pos)
          rw [hdiam_eq]
          linarith
        · have hle_DC : ‖pts y - pts x‖ ≤
              nodeCoreInputDiam pts (nodes i).o (nodes i).V (chainInput pts nodes P i.castSucc) :=
            norm_le_nodeCoreInputDiam pts (nodes i).o (nodes i).V hyC hxS
          have hdiv : ‖pts x - pts y‖ / params.c ≤
              nodeCoreInputDiam pts (nodes i).o (nodes i).V (chainInput pts nodes P i.castSucc) /
                params.c := by
            rw [norm_sub_rev (pts x) (pts y)]
            exact div_le_div_of_nonneg_right hle_DC (le_of_lt hc_pos)
          rw [hdiam_eq]
          linarith
    · have hdiam_zero : indexedEuclideanDiam P pts = 0 := by
        unfold indexedEuclideanDiam
        rw [dif_neg hP]
      rw [hdiam_zero, zero_div]
      exact hW_nonneg
  refine ⟨⟨hW_lower, hW_upper⟩, ?_⟩
  intro hcard
  by_cases hWpos : 0 < W_max
  · obtain ⟨j, _, hj_eq⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty f
    have hf_eq : f j = W_max := hj_eq.symm
    refine Fin.lastCases ?_ ?_ j hf_eq
    · intro hlast
      simp only [f, Fin.lastCases_last] at hlast
      have hLpos : 0 < baselinePairLength pts leafPair := hlast.symm ▸ hWpos
      obtain ⟨x, y, hxT, hyT, hnorm, hlp⟩ := activePair_realizer_of_pos h_leaf_active hLpos
      have hxP : x ∈ P := chainInput_subset pts nodes P (Fin.last k) hxT
      have hyP : y ∈ P := chainInput_subset pts nodes P (Fin.last k) hyT
      have hnormW : ‖pts x - pts y‖ = W_max := hnorm.trans hlast
      have hne : x ≠ y := by
        intro hEq
        rw [hEq, sub_self, norm_zero] at hnormW
        linarith
      refine ⟨x, y, ⟨hxP, hyP, hne, ?_, ?_⟩, fun _ => ⟨hnormW, Or.inl hlp⟩⟩
      · linarith
      · linarith
    · intro i hi_eq
      simp only [f, Fin.lastCases_castSucc] at hi_eq
      have hWi_pos : 0 < params.nodeRetainedEstimate pts (nodes i).V
          (baselinePairLength pts (basePairs i)) (stored i) := hi_eq.symm ▸ hWpos
      obtain ⟨x, y, hxS, hyS, hnorm, hsrc⟩ :=
        nodeRetainedEstimate_realizer (h_base i) (h_match i) hWi_pos
      have hxP : x ∈ P := chainInput_subset pts nodes P i.castSucc hxS
      have hyP : y ∈ P := chainInput_subset pts nodes P i.castSucc hyS
      have hnormW : ‖pts x - pts y‖ = W_max := hnorm.trans hi_eq
      have hne : x ≠ y := by
        intro hEq
        rw [hEq, sub_self, norm_zero] at hnormW
        linarith
      refine ⟨x, y, ⟨hxP, hyP, hne, ?_, ?_⟩, fun _ => ⟨hnormW, ?_⟩⟩
      · linarith
      · linarith
      · rcases hsrc with hbp | ⟨hVi, cfg, hcfg, hst⟩
        · exact Or.inr (Or.inl ⟨i, hbp⟩)
        · exact Or.inr (Or.inr ⟨i, hVi, cfg, hcfg, hst⟩)
  · have hW0 : W_max = 0 := le_antisymm (le_of_not_gt hWpos) hW_nonneg
    have hdiam0 : indexedEuclideanDiam P pts = 0 := by
      have hd_nn := UL.Proof_lem_5_5.indexedEuclideanDiam_nonneg P pts
      have hdiv0 : indexedEuclideanDiam P pts / params.c ≤ 0 := by linarith
      have hd_le0 : indexedEuclideanDiam P pts ≤ 0 := by
        rw [div_le_iff₀ hc_pos, zero_mul] at hdiv0
        exact hdiv0
      exact le_antisymm hd_le0 hd_nn
    have h1lt : 1 < P.card := Nat.lt_of_lt_of_le (by decide : 1 < 2) hcard
    obtain ⟨x, hxP, y, hyP, hne⟩ := Finset.one_lt_card.mp h1lt
    have hxy_le : ‖pts x - pts y‖ ≤ 0 := by
      rw [← hdiam0]
      exact UL.Proof_lem_5_5.pair_norm_le_indexedEuclideanDiam P pts hxP hyP
    have hxy0 : ‖pts x - pts y‖ = 0 := le_antisymm hxy_le (norm_nonneg _)
    refine ⟨x, y, ⟨hxP, hyP, hne, ?_, ?_⟩, fun hpos => False.elim (hWpos hpos)⟩
    · rw [hdiam0, zero_div, hxy0]
    · rw [hdiam0, hxy0]

end UL.Proof_clm_5_3_global_factor_c
