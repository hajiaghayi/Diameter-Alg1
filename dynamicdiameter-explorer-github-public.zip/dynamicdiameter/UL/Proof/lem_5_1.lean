import UL.Stmt.lem_5_1
set_option autoImplicit false

namespace UL

private theorem liftedPoint_apply_castSucc {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (i : Fin d) :
    (liftedPoint o s) i.castSucc = o i := by
  simp [liftedPoint]

private theorem liftedPoint_apply_last {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    (liftedPoint o s) (Fin.last d) = s := by
  simp [liftedPoint]

private theorem liftedBase_apply {d : ℕ}
    (w : EuclideanSpace ℝ (Fin (d + 1))) (i : Fin d) :
    (liftedBase w) i = w i.castSucc := by
  simp [liftedBase, Fin.init]

private theorem liftedBase_liftedPoint {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    liftedBase (liftedPoint o s) = o := by
  ext i
  rw [liftedBase_apply, liftedPoint_apply_castSucc]

private theorem liftedHeight_liftedPoint {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    liftedHeight (liftedPoint o s) = s := by
  unfold liftedHeight
  exact liftedPoint_apply_last o s

private theorem liftedPoint_ne_zero_of_ne_zero {d : ℕ}
    (u : EuclideanSpace ℝ (Fin d)) {c : ℝ} (hc : c ≠ 0) :
    liftedPoint u c ≠ 0 := by
  intro h
  have hlast : (liftedPoint u c) (Fin.last d) = (0 : EuclideanSpace ℝ (Fin (d + 1))) (Fin.last d) :=
    congrArg (fun v => v (Fin.last d)) h
  rw [liftedPoint_apply_last] at hlast
  simp at hlast
  exact hc hlast

private theorem inner_liftedPoint_left {d : ℕ}
    (u : EuclideanSpace ℝ (Fin d)) (c : ℝ) (w : EuclideanSpace ℝ (Fin (d + 1))) :
    inner ℝ (liftedPoint u c) w = inner ℝ u (liftedBase w) + c * liftedHeight w := by
  rw [PiLp.inner_apply, Fin.sum_univ_castSucc, PiLp.inner_apply]
  congr 1
  · refine Finset.sum_congr rfl (fun i _ => ?_)
    rw [liftedPoint_apply_castSucc, liftedBase_apply]
  · rw [liftedPoint_apply_last]
    unfold liftedHeight
    simp [mul_comm]

private theorem halfspaceDepth_le_pointCount {k : ℕ} {α_idx : Type*} [Fintype α_idx]
    (Q : α_idx → EuclideanSpace ℝ (Fin k)) (z : EuclideanSpace ℝ (Fin k))
    {H : Set (EuclideanSpace ℝ (Fin k))} (hH : IsClosedHalfspace H) (hz : z ∈ H) :
    halfspaceDepth Q z ≤ pointCount Q H := by
  unfold halfspaceDepth
  exact Nat.sInf_le ⟨H, hH, hz, rfl⟩

private theorem pointCount_paraboloidLiftSet_eq {d : ℕ} {α_idx : Type*} [Fintype α_idx]
    (Q : α_idx → EuclideanSpace ℝ (Fin d))
    (H : Set (EuclideanSpace ℝ (Fin (d + 1))))
    (T : Set (EuclideanSpace ℝ (Fin d)))
    (hHT : ∀ x, paraboloidLift x ∈ H ↔ x ∈ T) :
    pointCount (paraboloidLiftSet Q) H = pointCount Q T := by
  unfold pointCount paraboloidLiftSet
  apply congrArg Finset.card
  ext i
  simp [hHT]

private theorem isClosedHalfspace_coreHalfspace {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    IsClosedHalfspace (coreHalfspace o s) := by
  refine ⟨liftedPoint (-((2 : ℝ) • o)) 1, liftedPoint_ne_zero_of_ne_zero _ one_ne_zero,
    s - 2 * ‖o‖ ^ 2, ?_⟩
  ext w
  simp only [coreHalfspace, Set.mem_setOf_eq, inner_liftedPoint_left,
    inner_neg_left, inner_smul_left, RCLike.conj_to_real]
  constructor <;> intro h <;> linarith

private theorem liftedPoint_mem_coreHalfspace {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    liftedPoint o s ∈ coreHalfspace o s := by
  simp only [coreHalfspace, Set.mem_setOf_eq, liftedHeight_liftedPoint,
    liftedBase_liftedPoint, real_inner_self_eq_norm_sq]
  exact le_rfl

private theorem paraboloidLift_mem_coreHalfspace_iff {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (x : EuclideanSpace ℝ (Fin d)) :
    paraboloidLift x ∈ coreHalfspace o s ↔ ‖x - o‖ ^ 2 ≤ liftVariance o s := by
  simp only [paraboloidLift, coreHalfspace, liftVariance, Set.mem_setOf_eq,
    liftedHeight_liftedPoint, liftedBase_liftedPoint]
  have hsq : ‖x - o‖ ^ 2 = ‖x‖ ^ 2 - 2 * inner ℝ o x + ‖o‖ ^ 2 := by
    rw [norm_sub_sq_real, real_inner_comm]
  constructor <;> intro h <;> linarith

private theorem isClosedHalfspace_witnessHalfspace {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (q : EuclideanSpace ℝ (Fin d)) :
    IsClosedHalfspace (witnessHalfspace o s q) := by
  have hneg1 : (-1 : ℝ) ≠ 0 := by norm_num
  refine ⟨liftedPoint ((2 : ℝ) • q) (-1), liftedPoint_ne_zero_of_ne_zero _ hneg1,
    2 * inner ℝ q o - s, ?_⟩
  ext w
  simp only [witnessHalfspace, Set.mem_setOf_eq, inner_liftedPoint_left,
    inner_smul_left, RCLike.conj_to_real]
  constructor <;> intro h <;> linarith

private theorem liftedPoint_mem_witnessHalfspace {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (q : EuclideanSpace ℝ (Fin d)) :
    liftedPoint o s ∈ witnessHalfspace o s q := by
  simp only [witnessHalfspace, Set.mem_setOf_eq, liftedHeight_liftedPoint,
    liftedBase_liftedPoint]
  exact le_rfl

private theorem paraboloidLift_mem_witnessHalfspace_iff {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (q x : EuclideanSpace ℝ (Fin d)) :
    paraboloidLift x ∈ witnessHalfspace o s q ↔ IsVarianceWitness o (liftVariance o s) q x := by
  simp only [paraboloidLift, witnessHalfspace, IsVarianceWitness, liftVariance,
    Set.mem_setOf_eq, liftedHeight_liftedPoint, liftedBase_liftedPoint]
  have hxq : ‖x - q‖ ^ 2 = ‖x‖ ^ 2 - 2 * inner ℝ q x + ‖q‖ ^ 2 := by
    rw [norm_sub_sq_real, real_inner_comm]
  have hqo : ‖q - o‖ ^ 2 = ‖q‖ ^ 2 - 2 * inner ℝ q o + ‖o‖ ^ 2 := by
    rw [norm_sub_sq_real]
  constructor <;> intro h <;> linarith

private theorem coreBall_eq_norm_sq_le {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 ≤ V) :
    coreBall o V = {x | ‖x - o‖ ^ 2 ≤ V} := by
  ext x
  simp only [coreBall, Metric.mem_closedBall, dist_eq_norm, Set.mem_setOf_eq]
  rw [Real.le_sqrt (norm_nonneg _) hV]

open Classical in
private theorem pointCount_subtype_eq_card_filter {d : ℕ} {ι : Type*} [DecidableEq ι]
    (p : ι → EuclideanSpace ℝ (Fin d)) (A : Finset ι)
    (T : Set (EuclideanSpace ℝ (Fin d))) :
    pointCount (fun i : ↥A => p i.1) T = (A.filter (fun i => p i ∈ T)).card := by
  unfold pointCount
  rw [← Finset.card_map ⟨Subtype.val, Subtype.val_injective⟩]
  apply congrArg Finset.card
  ext x
  simp [and_comm]

private def applyUpdateOp {ι : Type*} [DecidableEq ι]
    (acc : Finset ι) (op : ι ⊕ ι) : Finset ι :=
  match op with
  | Sum.inl j => insert j acc
  | Sum.inr j => acc.erase j

private theorem card_sdiff_foldl_le {ι : Type*} [DecidableEq ι]
    (B : Finset ι) (ops : List (ι ⊕ ι)) (A : Finset ι) :
    (B \ ops.foldl applyUpdateOp A).card ≤ (B \ A).card + (ops.filter Sum.isRight).length := by
  induction ops generalizing A with
  | nil =>
    simp
  | cons op tl ih =>
    simp only [List.foldl_cons]
    have htl := ih (applyUpdateOp A op)
    cases op with
    | inl j =>
      simp only [applyUpdateOp, List.filter_cons_of_neg (by simp : ¬Sum.isRight (Sum.inl j : ι ⊕ ι))] at htl ⊢
      have hsub : B \ insert j A ⊆ B \ A := by
        intro x hx
        rw [Finset.mem_sdiff] at hx ⊢
        exact ⟨hx.1, fun hA => hx.2 (Finset.mem_insert_of_mem hA)⟩
      have hcard : (B \ insert j A).card ≤ (B \ A).card := Finset.card_le_card hsub
      omega
    | inr j =>
      simp only [applyUpdateOp, List.filter_cons_of_pos (by simp : Sum.isRight (Sum.inr j : ι ⊕ ι)),
        List.length_cons] at htl ⊢
      have hsub : B \ A.erase j ⊆ insert j (B \ A) := by
        intro x hx
        rw [Finset.mem_sdiff, Finset.mem_erase] at hx
        by_cases hxj : x = j
        · exact hxj ▸ Finset.mem_insert_self j (B \ A)
        · exact Finset.mem_insert_of_mem (Finset.mem_sdiff.mpr ⟨hx.1, fun hA => hx.2 ⟨hxj, hA⟩⟩)
      have hcard : (B \ A.erase j).card ≤ (B \ A).card + 1 :=
        (Finset.card_le_card hsub).trans (Finset.card_insert_le j (B \ A))
      omega

open Classical in
private theorem pointCount_inter_and_superset_survival {d : ℕ} {ι : Type*} [DecidableEq ι]
    (p : ι → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ι)
    (T : Set (EuclideanSpace ℝ (Fin d)))
    {bound : ℝ} (hbound : bound ≤ (pointCount (fun i : P₀ => p i.1) T : ℝ))
    {a : ℕ} {ops : List (ι ⊕ ι)} (ha : (ops.filter Sum.isRight).length ≤ a) :
    let S := ops.foldl applyUpdateOp P₀
    bound - (a : ℝ) ≤ (pointCount (fun i : ↥(P₀ ∩ S) => p i.1) T : ℝ) ∧
    bound - (a : ℝ) ≤ (pointCount (fun i : ↥S => p i.1) T : ℝ) := by
  intro S
  let B : Finset ι := P₀.filter (fun i => p i ∈ T)
  have hB_sdiff_P₀ : B \ P₀ = ∅ :=
    Finset.sdiff_eq_empty_iff_subset.mpr (Finset.filter_subset _ _)
  have hB_sdiff_S : (B \ S).card ≤ a := by
    have h1 := card_sdiff_foldl_le B ops P₀
    rw [hB_sdiff_P₀, Finset.card_empty, zero_add] at h1
    exact h1.trans ha
  let C : Finset ι := (P₀ ∩ S).filter (fun i => p i ∈ T)
  have hB_sub : B ⊆ C ∪ (B \ S) := by
    intro x hx
    by_cases hxS : x ∈ S
    · apply Finset.mem_union_left
      have hxP : x ∈ P₀ ∧ p x ∈ T := Finset.mem_filter.mp hx
      exact Finset.mem_filter.mpr ⟨Finset.mem_inter.mpr ⟨hxP.1, hxS⟩, hxP.2⟩
    · exact Finset.mem_union_right _ (Finset.mem_sdiff.mpr ⟨hx, hxS⟩)
  have hcard_nat : B.card ≤ C.card + a := by
    calc B.card ≤ (C ∪ (B \ S)).card := Finset.card_le_card hB_sub
      _ ≤ C.card + (B \ S).card := Finset.card_union_le C (B \ S)
      _ ≤ C.card + a := Nat.add_le_add_left hB_sdiff_S C.card
  have hB_eq : pointCount (fun i : P₀ => p i.1) T = B.card :=
    pointCount_subtype_eq_card_filter p P₀ T
  have hC_eq : pointCount (fun i : ↥(P₀ ∩ S) => p i.1) T = C.card :=
    pointCount_subtype_eq_card_filter p (P₀ ∩ S) T
  have hcard_real : (pointCount (fun i : P₀ => p i.1) T : ℝ) ≤
      (pointCount (fun i : ↥(P₀ ∩ S) => p i.1) T : ℝ) + (a : ℝ) := by
    rw [hB_eq, hC_eq]
    exact_mod_cast hcard_nat
  have hinter : bound - (a : ℝ) ≤ (pointCount (fun i : ↥(P₀ ∩ S) => p i.1) T : ℝ) := by
    linarith
  have hsub_S : C ⊆ S.filter (fun i => p i ∈ T) :=
    Finset.filter_subset_filter _ Finset.inter_subset_right
  have hCS_nat : pointCount (fun i : ↥(P₀ ∩ S) => p i.1) T ≤
      pointCount (fun i : ↥S => p i.1) T := by
    rw [hC_eq, pointCount_subtype_eq_card_filter]
    exact Finset.card_le_card hsub_S
  have hCS_real : (pointCount (fun i : ↥(P₀ ∩ S) => p i.1) T : ℝ) ≤
      (pointCount (fun i : ↥S => p i.1) T : ℝ) := by
    exact_mod_cast hCS_nat
  exact ⟨hinter, hinter.trans hCS_real⟩

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_5_1 : S_lem_5_1 := by
  unfold S_lem_5_1
  intro d ι _ p P₀ hm α hα o s hdepth
  dsimp only
  set V := liftVariance o s
  set m : ℝ := (P₀.card : ℝ)
  have hcore_sq : α * m ≤ (pointCount (fun i : P₀ => p i.1) {x | ‖x - o‖ ^ 2 ≤ V} : ℝ) := by
    have hle_depth : halfspaceDepth (paraboloidLiftSet (fun i : P₀ => p i.1)) (liftedPoint o s) ≤
        pointCount (paraboloidLiftSet (fun i : P₀ => p i.1)) (coreHalfspace o s) :=
      halfspaceDepth_le_pointCount _ _
        (isClosedHalfspace_coreHalfspace o s) (liftedPoint_mem_coreHalfspace o s)
    have hcnt_eq : pointCount (paraboloidLiftSet (fun i : P₀ => p i.1)) (coreHalfspace o s) =
        pointCount (fun i : P₀ => p i.1) {x | ‖x - o‖ ^ 2 ≤ V} :=
      pointCount_paraboloidLiftSet_eq _ _ _ (paraboloidLift_mem_coreHalfspace_iff o s)
    have hle_real : (halfspaceDepth (paraboloidLiftSet (fun i : P₀ => p i.1)) (liftedPoint o s) : ℝ) ≤
        (pointCount (fun i : P₀ => p i.1) {x | ‖x - o‖ ^ 2 ≤ V} : ℝ) := by
      rw [← hcnt_eq]
      exact_mod_cast hle_depth
    exact hdepth.trans hle_real
  have hV_nonneg : 0 ≤ V := by
    have hm_pos : (0 : ℝ) < m := by
      change (0 : ℝ) < (P₀.card : ℝ)
      exact_mod_cast (Nat.lt_of_lt_of_le Nat.zero_lt_one hm)
    have hαm_pos : 0 < α * m := mul_pos hα hm_pos
    have hcnt_pos_real : (0 : ℝ) < (pointCount (fun i : P₀ => p i.1) {x | ‖x - o‖ ^ 2 ≤ V} : ℝ) :=
      hαm_pos.trans_le hcore_sq
    have hcnt_pos : 0 < pointCount (fun i : P₀ => p i.1) {x | ‖x - o‖ ^ 2 ≤ V} := by
      exact_mod_cast hcnt_pos_real
    unfold pointCount at hcnt_pos
    obtain ⟨i₀, hi₀⟩ := Finset.card_pos.mp hcnt_pos
    have hi₀_mem : ‖p i₀.1 - o‖ ^ 2 ≤ V := (Finset.mem_filter.mp hi₀).2
    exact (sq_nonneg _).trans hi₀_mem
  have hcore_eq : coreBall o V = {x | ‖x - o‖ ^ 2 ≤ V} := coreBall_eq_norm_sq_le o hV_nonneg
  have hcore_ball : α * m ≤ (pointCount (fun i : P₀ => p i.1) (coreBall o V) : ℝ) := by
    rwa [hcore_eq]
  have hwitness : ∀ q : EuclideanSpace ℝ (Fin d),
      α * m ≤ (pointCount (fun i : P₀ => p i.1) {x | IsVarianceWitness o V q x} : ℝ) := by
    intro q
    have hle_depth : halfspaceDepth (paraboloidLiftSet (fun i : P₀ => p i.1)) (liftedPoint o s) ≤
        pointCount (paraboloidLiftSet (fun i : P₀ => p i.1)) (witnessHalfspace o s q) :=
      halfspaceDepth_le_pointCount _ _
        (isClosedHalfspace_witnessHalfspace o s q) (liftedPoint_mem_witnessHalfspace o s q)
    have hcnt_eq : pointCount (paraboloidLiftSet (fun i : P₀ => p i.1)) (witnessHalfspace o s q) =
        pointCount (fun i : P₀ => p i.1) {x | IsVarianceWitness o V q x} :=
      pointCount_paraboloidLiftSet_eq _ _ _ (paraboloidLift_mem_witnessHalfspace_iff o s q)
    have hle_real : (halfspaceDepth (paraboloidLiftSet (fun i : P₀ => p i.1)) (liftedPoint o s) : ℝ) ≤
        (pointCount (fun i : P₀ => p i.1) {x | IsVarianceWitness o V q x} : ℝ) := by
      rw [← hcnt_eq]
      exact_mod_cast hle_depth
    exact hdepth.trans hle_real
  refine ⟨hcore_ball, hwitness, ?_⟩
  intro a ops ha
  have hsurv_ball := pointCount_inter_and_superset_survival p P₀ (coreBall o V) hcore_ball ha
  have hsurv_sq := pointCount_inter_and_superset_survival p P₀ {x | ‖x - o‖ ^ 2 ≤ V} hcore_sq ha
  have hsurv_wit : ∀ q : EuclideanSpace ℝ (Fin d),
      (α * m - (a : ℝ) ≤
        (pointCount (fun i : ↥(P₀ ∩ ops.foldl applyUpdateOp P₀) => p i.1)
          {x | IsVarianceWitness o V q x} : ℝ)) ∧
      (α * m - (a : ℝ) ≤
        (pointCount (fun i : ↥(ops.foldl applyUpdateOp P₀) => p i.1)
          {x | IsVarianceWitness o V q x} : ℝ)) :=
    fun q => pointCount_inter_and_superset_survival p P₀ {x | IsVarianceWitness o V q x}
      (hwitness q) ha
  exact ⟨hsurv_ball.1, hsurv_sq.1, fun q => (hsurv_wit q).1,
    hsurv_ball.2, hsurv_sq.2, fun q => (hsurv_wit q).2⟩

end UL
