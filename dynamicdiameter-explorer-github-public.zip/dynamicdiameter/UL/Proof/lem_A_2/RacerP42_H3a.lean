import Mathlib
import UL.Proof.lem_A_2.H1c_Retry
import UL.Proof.lem_A_2.H2b_SubSim
set_option autoImplicit false

namespace UL.Proof_lem_A_2

/-! ### 0. Missing `freeLocal` helper and `WordStore` read rewrite wrappers -/

theorem RunsTo.freeLocal {d : ℕ} (inp : BitRAMInput d) (var : ℕ) (idxE : IntExpr)
    (st : BitRAMExecState) :
    let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
    let loc := RAMCellLoc.localFrame st.frameDepth var idx
    RunsTo inp [.stmt (.freeLocal var idxE)] st
      { st with
        words := st.words.free loc
        unitCost := st.unitCost + u + 1
        bitCost := st.bitCost + b + loc.bitLength } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem rw_read_write_ne {ws : WordStore} {loc₁ loc₂ : RAMCellLoc} {v : ℤ}
    (hne : loc₁ ≠ loc₂) : (ws.write loc₂ v).read loc₁ = ws.read loc₁ :=
  wordStore_read_write_of_ne ws hne v

theorem rw_read_free_ne {ws : WordStore} {loc₁ loc₂ : RAMCellLoc}
    (hne : loc₁ ≠ loc₂) : (ws.free loc₂).read loc₁ = ws.read loc₁ :=
  wordStore_read_free_of_ne ws hne

/-! ### 1. Arena invariant `InAttemptArena` for zero-boilerplate space bounds -/

def InAttemptArena (A V : ℕ) (ws : WordStore) : Prop :=
  IsSimBaseStore ws ∧
  (∀ loc ∈ ws.live,
    match loc with
    | .heap t idx => t < 8 ∧ 0 ≤ idx ∧ idx.toNat < A
    | .localFrame fd var idx => fd = 1 ∧ var < 100 ∧ 0 ≤ idx ∧ idx.toNat < A) ∧
  (∀ loc ∈ ws.live, intBitLength (ws.vals loc) ≤ V)

theorem intBitLength_natCast_le_succ (n : ℕ) : intBitLength (n : ℤ) ≤ natBitLength n + 1 := by
  unfold intBitLength
  split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega

theorem inAttemptArena_write_local {A V : ℕ} {ws : WordStore}
    (h : InAttemptArena A V ws) {var : ℕ} {idx val : ℤ}
    (hvar : var < 100) (hidx0 : 0 ≤ idx) (hidxA : idx.toNat < A)
    (hval : intBitLength val ≤ V) :
    InAttemptArena A V (ws.write (.localFrame 1 var idx) val) := by
  refine ⟨⟨wellFormedWS_write h.1.1 _ _, ?_⟩, ?_, ?_⟩
  · intro loc hloc
    rcases Finset.mem_insert.mp hloc with rfl | hmem
    · exact Or.inr ⟨var, idx, rfl⟩
    · exact h.1.2 loc hmem
  · intro loc hloc
    rcases Finset.mem_insert.mp hloc with rfl | hmem
    · exact ⟨rfl, hvar, hidx0, hidxA⟩
    · exact h.2.1 loc hmem
  · intro loc hloc
    dsimp only [WordStore.write] at hloc ⊢
    by_cases heq : loc = .localFrame 1 var idx
    · subst heq; rw [Function.update_self]; exact hval
    · rw [Function.update_of_ne heq]
      rcases Finset.mem_insert.mp hloc with hc | hmem
      · exact False.elim (heq hc)
      · exact h.2.2 loc hmem

theorem inAttemptArena_write_heap {A V : ℕ} {ws : WordStore}
    (h : InAttemptArena A V ws) {t : ℕ} {idx val : ℤ}
    (ht : t < 8) (hidx0 : 0 ≤ idx) (hidxA : idx.toNat < A)
    (hval : intBitLength val ≤ V) :
    InAttemptArena A V (ws.write (.heap t idx) val) := by
  refine ⟨⟨wellFormedWS_write h.1.1 _ _, ?_⟩, ?_, ?_⟩
  · intro loc hloc
    rcases Finset.mem_insert.mp hloc with rfl | hmem
    · exact Or.inl ⟨t, idx, ht, rfl⟩
    · exact h.1.2 loc hmem
  · intro loc hloc
    rcases Finset.mem_insert.mp hloc with rfl | hmem
    · exact ⟨ht, hidx0, hidxA⟩
    · exact h.2.1 loc hmem
  · intro loc hloc
    dsimp only [WordStore.write] at hloc ⊢
    by_cases heq : loc = .heap t idx
    · subst heq; rw [Function.update_self]; exact hval
    · rw [Function.update_of_ne heq]
      rcases Finset.mem_insert.mp hloc with hc | hmem
      · exact False.elim (heq hc)
      · exact h.2.2 loc hmem

theorem inAttemptArena_free {A V : ℕ} {ws : WordStore}
    (h : InAttemptArena A V ws) (loc₀ : RAMCellLoc) :
    InAttemptArena A V (ws.free loc₀) := by
  refine ⟨⟨wellFormedWS_free h.1.1 loc₀, ?_⟩, ?_, ?_⟩
  · intro loc hloc
    exact h.1.2 loc (Finset.mem_of_mem_erase hloc)
  · intro loc hloc
    exact h.2.1 loc (Finset.mem_of_mem_erase hloc)
  · intro loc hloc
    have hne : loc ≠ loc₀ := Finset.ne_of_mem_erase hloc
    dsimp only [WordStore.free]
    rw [Function.update_of_ne hne]
    exact h.2.2 loc (Finset.mem_of_mem_erase hloc)

private def arenaSuperset (A : ℕ) : Finset RAMCellLoc :=
  ((Finset.range 8 ×ˢ Finset.range A).image (fun p => RAMCellLoc.heap p.1 (p.2 : ℤ))) ∪
  ((Finset.range 100 ×ˢ Finset.range A).image (fun p => RAMCellLoc.localFrame 1 p.1 (p.2 : ℤ)))

theorem inAttemptArena_size_le {A V : ℕ} {ws : WordStore}
    (h : InAttemptArena A V ws) :
    ws.cellCount ≤ 108 * A ∧
    ws.bitSize ≤ 108 * A * (natBitLength A + V + 16) := by
  have hsub : ws.live ⊆ arenaSuperset A := by
    intro loc hloc
    have hb := h.2.1 loc hloc
    unfold arenaSuperset
    rw [Finset.mem_union]
    cases loc with
    | heap t idx =>
        dsimp only at hb
        left
        rw [Finset.mem_image]
        refine ⟨(t, idx.toNat), ?_, ?_⟩
        · rw [Finset.mem_product, Finset.mem_range, Finset.mem_range]
          exact ⟨hb.1, hb.2.2⟩
        · simp [Int.toNat_of_nonneg hb.2.1]
    | localFrame fd var idx =>
        dsimp only at hb
        rcases hb with ⟨rfl, hvar, hidx0, hidxA⟩
        right
        rw [Finset.mem_image]
        refine ⟨(var, idx.toNat), ?_, ?_⟩
        · rw [Finset.mem_product, Finset.mem_range, Finset.mem_range]
          exact ⟨hvar, hidxA⟩
        · simp [Int.toNat_of_nonneg hidx0]
  have hcard_sup : (arenaSuperset A).card ≤ 108 * A := by
    unfold arenaSuperset
    have h1 := Finset.card_union_le
      ((Finset.range 8 ×ˢ Finset.range A).image (fun p => RAMCellLoc.heap p.1 (p.2 : ℤ)))
      ((Finset.range 100 ×ˢ Finset.range A).image (fun p => RAMCellLoc.localFrame 1 p.1 (p.2 : ℤ)))
    have h2 : ((Finset.range 8 ×ˢ Finset.range A).image
        (fun p => RAMCellLoc.heap p.1 (p.2 : ℤ))).card ≤ 8 * A := by
      calc _ ≤ (Finset.range 8 ×ˢ Finset.range A).card := Finset.card_image_le
        _ = 8 * A := by rw [Finset.card_product, Finset.card_range, Finset.card_range]
    have h3 : ((Finset.range 100 ×ˢ Finset.range A).image
        (fun p => RAMCellLoc.localFrame 1 p.1 (p.2 : ℤ))).card ≤ 100 * A := by
      calc _ ≤ (Finset.range 100 ×ˢ Finset.range A).card := Finset.card_image_le
        _ = 100 * A := by rw [Finset.card_product, Finset.card_range, Finset.card_range]
    omega
  have hcc : ws.cellCount ≤ 108 * A := (Finset.card_le_card hsub).trans hcard_sup
  refine ⟨hcc, ?_⟩
  unfold WordStore.bitSize
  calc
    (∑ loc ∈ ws.live, (loc.bitLength + intBitLength (ws.vals loc)))
        ≤ ∑ _loc ∈ ws.live, (natBitLength A + V + 16) := by
          refine Finset.sum_le_sum fun loc hloc => ?_
          have hb := h.2.1 loc hloc
          have hv := h.2.2 loc hloc
          cases loc with
          | heap t idx =>
              dsimp only [RAMCellLoc.bitLength] at hb ⊢
              have ht_b : natBitLength t ≤ 4 :=
                (natBitLength_mono (le_of_lt hb.1)).trans (by decide)
              have hi_b : intBitLength idx ≤ natBitLength A + 1 := by
                rw [← Int.toNat_of_nonneg hb.2.1]
                exact (intBitLength_natCast_le_succ idx.toNat).trans
                  (Nat.add_le_add_right (natBitLength_mono (le_of_lt hb.2.2)) 1)
              omega
          | localFrame fd var idx =>
              dsimp only [RAMCellLoc.bitLength] at hb ⊢
              rcases hb with ⟨rfl, hvar, hidx0, hidxA⟩
              have hn1 : natBitLength 1 = 1 := rfl
              have hv_b : natBitLength var ≤ 7 :=
                (natBitLength_mono (le_of_lt hvar)).trans (by decide)
              have hi_b : intBitLength idx ≤ natBitLength A + 1 := by
                rw [← Int.toNat_of_nonneg hidx0]
                exact (intBitLength_natCast_le_succ idx.toNat).trans
                  (Nat.add_le_add_right (natBitLength_mono (le_of_lt hidxA)) 1)
              omega
    _ = ws.cellCount * (natBitLength A + V + 16) := by
          simp [WordStore.cellCount]
    _ ≤ (108 * A) * (natBitLength A + V + 16) :=
          Nat.mul_le_mul_right _ hcc

/-! ### 2. Compositional bounded execution `ExecBounded` at `frameDepth = 1` -/

def ExecBounded {d : ℕ} (inp : BitRAMInput d) (s : BitRAMStmt)
    (ws₁ : WordStore) (bs₁ : List Bool)
    (ws₂ : WordStore) (bs₂ : List Bool)
    (Δu Δb C_max S_max : ℕ) : Prop :=
  ∀ st₁ : BitRAMExecState,
    st₁.words = ws₁ →
    st₁.frameDepth = 1 →
    st₁.remainingBits = bs₁ →
    ∃ st₂ : BitRAMExecState,
      RunsTo inp [.stmt s] st₁ st₂ ∧
      st₂.words = ws₂ ∧
      st₂.frameDepth = 1 ∧
      st₂.remainingBits = bs₂ ∧
      st₂.unitCost ≤ st₁.unitCost + Δu ∧
      st₂.bitCost ≤ st₁.bitCost + Δb ∧
      st₂.peakCellSpace ≤ max st₁.peakCellSpace C_max ∧
      st₂.peakBitSpace ≤ max st₁.peakBitSpace S_max

theorem ExecBounded.mono {d : ℕ} {inp : BitRAMInput d} {s : BitRAMStmt}
    {ws₁ ws₂ : WordStore} {bs₁ bs₂ : List Bool}
    {Δu Δu' Δb Δb' C C' S S' : ℕ}
    (h : ExecBounded inp s ws₁ bs₁ ws₂ bs₂ Δu Δb C S)
    (hu : Δu ≤ Δu') (hb : Δb ≤ Δb') (hC : C ≤ C') (hS : S ≤ S') :
    ExecBounded inp s ws₁ bs₁ ws₂ bs₂ Δu' Δb' C' S' := by
  intro st₁ hw hf hbs
  obtain ⟨st₂, hr, hw₂, hf₂, hbs₂, hu₂, hb₂, hpc₂, hpb₂⟩ := h st₁ hw hf hbs
  exact ⟨st₂, hr, hw₂, hf₂, hbs₂, by omega, by omega,
    hpc₂.trans (max_le_max le_rfl hC), hpb₂.trans (max_le_max le_rfl hS)⟩

theorem ExecBounded.skip {d : ℕ} (inp : BitRAMInput d)
    (ws : WordStore) (bs : List Bool) (C S : ℕ) :
    ExecBounded inp .skip ws bs ws bs 1 1 C S := by
  intro st₁ hw hf hbs
  exact ⟨_, RunsTo.skip inp st₁, hw, hf, hbs, le_rfl, le_rfl, le_max_left _ _, le_max_left _ _⟩

theorem ExecBounded.seq {d : ℕ} {inp : BitRAMInput d} {s₁ s₂ : BitRAMStmt}
    {ws₁ ws₂ ws₃ : WordStore} {bs₁ bs₂ bs₃ : List Bool}
    {u₁ b₁ u₂ b₂ C S : ℕ}
    (h₁ : ExecBounded inp s₁ ws₁ bs₁ ws₂ bs₂ u₁ b₁ C S)
    (h₂ : ExecBounded inp s₂ ws₂ bs₂ ws₃ bs₃ u₂ b₂ C S) :
    ExecBounded inp (.seq s₁ s₂) ws₁ bs₁ ws₃ bs₃ (u₁ + u₂) (b₁ + b₂) C S := by
  intro st₁ hw₁ hf₁ hbs₁
  obtain ⟨st₂, hr₁, hw₂, hf₂, hbs₂, hu₁, hb₁, hpc₁, hpb₁⟩ := h₁ st₁ hw₁ hf₁ hbs₁
  obtain ⟨st₃, hr₂, hw₃, hf₃, hbs₃, hu₂, hb₂, hpc₂, hpb₂⟩ := h₂ st₂ hw₂ hf₂ hbs₂
  refine ⟨st₃, RunsTo.seq hr₁ hr₂, hw₃, hf₃, hbs₃, by omega, by omega,
    hpc₂.trans (max_le (hpc₁) (le_max_right _ _)),
    hpb₂.trans (max_le (hpb₁) (le_max_right _ _))⟩

theorem ExecBounded.writeLocal {d : ℕ} {inp : BitRAMInput d}
    {var : ℕ} {idxE valE : IntExpr} {ws : WordStore} {bs : List Bool}
    {idx val : ℤ} {u₁ b₁ u₂ b₂ Δu Δb C S : ℕ}
    (hidx : evalIntExpr inp 1 ws idxE = (idx, u₁, b₁))
    (hval : evalIntExpr inp 1 ws valE = (val, u₂, b₂))
    (hu : u₁ + u₂ + 1 ≤ Δu)
    (hb : b₁ + b₂ + (RAMCellLoc.localFrame 1 var idx).bitLength + intBitLength val ≤ Δb)
    (hC : inp.inputCellSpace + (ws.write (.localFrame 1 var idx) val).cellCount ≤ C)
    (hS : inp.inputBitSpace + (ws.write (.localFrame 1 var idx) val).bitSize ≤ S) :
    ExecBounded inp (.writeLocal var idxE valE) ws bs
      (ws.write (.localFrame 1 var idx) val) bs Δu Δb C S := by
  intro st₁ hw hf hbs
  have hr := RunsTo.writeLocal inp var idxE valE st₁
  dsimp only at hr
  rw [hw, hf, hidx, hval] at hr
  dsimp only at hr
  refine ⟨_, hr, rfl, rfl, hbs, by dsimp; omega, by dsimp; omega,
    max_le_max le_rfl hC, max_le_max le_rfl hS⟩

theorem ExecBounded.writeLocal_arena {d A V : ℕ} {inp : BitRAMInput d}
    {var : ℕ} {idxE valE : IntExpr} {ws : WordStore} {bs : List Bool}
    {idx val : ℤ} {u₁ b₁ u₂ b₂ Δu Δb : ℕ}
    (ha : InAttemptArena A V (ws.write (.localFrame 1 var idx) val))
    (hidx : evalIntExpr inp 1 ws idxE = (idx, u₁, b₁))
    (hval : evalIntExpr inp 1 ws valE = (val, u₂, b₂))
    (hu : u₁ + u₂ + 1 ≤ Δu)
    (hb : b₁ + b₂ + (RAMCellLoc.localFrame 1 var idx).bitLength + intBitLength val ≤ Δb) :
    ExecBounded inp (.writeLocal var idxE valE) ws bs
      (ws.write (.localFrame 1 var idx) val) bs Δu Δb
      (inp.inputCellSpace + 108 * A)
      (inp.inputBitSpace + 108 * A * (natBitLength A + V + 16)) := by
  obtain ⟨hc, hs⟩ := inAttemptArena_size_le ha
  exact ExecBounded.writeLocal hidx hval hu hb (by omega) (by omega)

theorem ExecBounded.writeHeap {d : ℕ} {inp : BitRAMInput d}
    {t : ℕ} {idxE valE : IntExpr} {ws : WordStore} {bs : List Bool}
    {idx val : ℤ} {u₁ b₁ u₂ b₂ Δu Δb C S : ℕ}
    (hidx : evalIntExpr inp 1 ws idxE = (idx, u₁, b₁))
    (hval : evalIntExpr inp 1 ws valE = (val, u₂, b₂))
    (hu : u₁ + u₂ + 1 ≤ Δu)
    (hb : b₁ + b₂ + (RAMCellLoc.heap t idx).bitLength + intBitLength val ≤ Δb)
    (hC : inp.inputCellSpace + (ws.write (.heap t idx) val).cellCount ≤ C)
    (hS : inp.inputBitSpace + (ws.write (.heap t idx) val).bitSize ≤ S) :
    ExecBounded inp (.writeHeap t idxE valE) ws bs
      (ws.write (.heap t idx) val) bs Δu Δb C S := by
  intro st₁ hw hf hbs
  have hr := RunsTo.writeHeap inp t idxE valE st₁
  dsimp only at hr
  rw [hw, hf, hidx, hval] at hr
  dsimp only at hr
  refine ⟨_, hr, rfl, rfl, hbs, by dsimp; omega, by dsimp; omega,
    max_le_max le_rfl hC, max_le_max le_rfl hS⟩

theorem ExecBounded.writeHeap_arena {d A V : ℕ} {inp : BitRAMInput d}
    {t : ℕ} {idxE valE : IntExpr} {ws : WordStore} {bs : List Bool}
    {idx val : ℤ} {u₁ b₁ u₂ b₂ Δu Δb : ℕ}
    (ha : InAttemptArena A V (ws.write (.heap t idx) val))
    (hidx : evalIntExpr inp 1 ws idxE = (idx, u₁, b₁))
    (hval : evalIntExpr inp 1 ws valE = (val, u₂, b₂))
    (hu : u₁ + u₂ + 1 ≤ Δu)
    (hb : b₁ + b₂ + (RAMCellLoc.heap t idx).bitLength + intBitLength val ≤ Δb) :
    ExecBounded inp (.writeHeap t idxE valE) ws bs
      (ws.write (.heap t idx) val) bs Δu Δb
      (inp.inputCellSpace + 108 * A)
      (inp.inputBitSpace + 108 * A * (natBitLength A + V + 16)) := by
  obtain ⟨hc, hs⟩ := inAttemptArena_size_le ha
  exact ExecBounded.writeHeap hidx hval hu hb (by omega) (by omega)

theorem ExecBounded.freeHeap {d : ℕ} {inp : BitRAMInput d}
    {t : ℕ} {idxE : IntExpr} {ws : WordStore} {bs : List Bool}
    {idx : ℤ} {u b Δu Δb C S : ℕ}
    (hidx : evalIntExpr inp 1 ws idxE = (idx, u, b))
    (hu : u + 1 ≤ Δu)
    (hb : b + (RAMCellLoc.heap t idx).bitLength ≤ Δb) :
    ExecBounded inp (.freeHeap t idxE) ws bs (ws.free (.heap t idx)) bs Δu Δb C S := by
  intro st₁ hw hf hbs
  have hr := RunsTo.freeHeap inp t idxE st₁
  dsimp only at hr
  rw [hw, hf, hidx] at hr
  dsimp only at hr
  exact ⟨_, hr, rfl, rfl, hbs, by dsimp; omega, by dsimp; omega, le_max_left _ _, le_max_left _ _⟩

theorem ExecBounded.freeLocal {d : ℕ} {inp : BitRAMInput d}
    {var : ℕ} {idxE : IntExpr} {ws : WordStore} {bs : List Bool}
    {idx : ℤ} {u b Δu Δb C S : ℕ}
    (hidx : evalIntExpr inp 1 ws idxE = (idx, u, b))
    (hu : u + 1 ≤ Δu)
    (hb : b + (RAMCellLoc.localFrame 1 var idx).bitLength ≤ Δb) :
    ExecBounded inp (.freeLocal var idxE) ws bs (ws.free (.localFrame 1 var idx)) bs Δu Δb C S := by
  intro st₁ hw hf hbs
  have hr := RunsTo.freeLocal inp var idxE st₁
  dsimp only at hr
  rw [hw, hf, hidx] at hr
  dsimp only at hr
  exact ⟨_, hr, rfl, rfl, hbs, by dsimp; omega, by dsimp; omega, le_max_left _ _, le_max_left _ _⟩

theorem ExecBounded.randBitLocal {d : ℕ} {inp : BitRAMInput d}
    {var : ℕ} {idxE : IntExpr} {ws : WordStore} {bit : Bool} {bs' : List Bool}
    {idx : ℤ} {u b Δu Δb C S : ℕ}
    (hidx : evalIntExpr inp 1 ws idxE = (idx, u, b))
    (hu : u + 1 ≤ Δu)
    (hb : b + (RAMCellLoc.localFrame 1 var idx).bitLength + 2 ≤ Δb)
    (hC : inp.inputCellSpace + (ws.write (.localFrame 1 var idx) (if bit then 1 else 0)).cellCount ≤ C)
    (hS : inp.inputBitSpace + (ws.write (.localFrame 1 var idx) (if bit then 1 else 0)).bitSize ≤ S) :
    ExecBounded inp (.randBitLocal var idxE) ws (bit :: bs')
      (ws.write (.localFrame 1 var idx) (if bit then 1 else 0)) bs' Δu Δb C S := by
  intro st₁ hw hf hbs
  have hr := RunsTo.randBitLocal inp var idxE bit bs' st₁ hbs
  dsimp only at hr
  rw [hw, hf, hidx] at hr
  dsimp only at hr
  refine ⟨_, hr, rfl, rfl, rfl, by dsimp; omega, by dsimp; omega,
    max_le_max le_rfl hC, max_le_max le_rfl hS⟩

theorem ExecBounded.randBitLocal_arena {d A V : ℕ} {inp : BitRAMInput d}
    {var : ℕ} {idxE : IntExpr} {ws : WordStore} {bit : Bool} {bs' : List Bool}
    {idx : ℤ} {u b Δu Δb : ℕ}
    (ha : InAttemptArena A V (ws.write (.localFrame 1 var idx) (if bit then 1 else 0)))
    (hidx : evalIntExpr inp 1 ws idxE = (idx, u, b))
    (hu : u + 1 ≤ Δu)
    (hb : b + (RAMCellLoc.localFrame 1 var idx).bitLength + 2 ≤ Δb) :
    ExecBounded inp (.randBitLocal var idxE) ws (bit :: bs')
      (ws.write (.localFrame 1 var idx) (if bit then 1 else 0)) bs' Δu Δb
      (inp.inputCellSpace + 108 * A)
      (inp.inputBitSpace + 108 * A * (natBitLength A + V + 16)) := by
  obtain ⟨hc, hs⟩ := inAttemptArena_size_le ha
  exact ExecBounded.randBitLocal hidx hu hb (by omega) (by omega)

theorem ExecBounded.ite {d : ℕ} {inp : BitRAMInput d}
    {cond : BitCondExpr} {tB fB : BitRAMStmt}
    {ws₁ ws₂ : WordStore} {bs₁ bs₂ : List Bool}
    {fl : Bool} {uc bc ub bb C S : ℕ}
    (hcond : evalBitCond inp 1 ws₁ cond = (fl, uc, bc))
    (hbody : ExecBounded inp (if fl then tB else fB) ws₁ bs₁ ws₂ bs₂ ub bb C S) :
    ExecBounded inp (.ite cond tB fB) ws₁ bs₁ ws₂ bs₂ (uc + ub) (bc + bb) C S := by
  intro st₁ hw₁ hf₁ hbs₁
  let stMid : BitRAMExecState :=
    { st₁ with unitCost := st₁.unitCost + uc, bitCost := st₁.bitCost + bc }
  obtain ⟨st₂, hr, hw₂, hf₂, hbs₂, hu₂, hb₂, hpc₂, hpb₂⟩ :=
    hbody stMid hw₁ hf₁ hbs₁
  have hite : RunsTo inp [.stmt (.ite cond tB fB)] st₁ st₂ := by
    refine RunsTo.ite cond tB fB ?_
    have hc' : evalBitCond inp st₁.frameDepth st₁.words cond = (fl, uc, bc) := by
      rwa [hf₁, hw₁]
    rw [hc']
    exact hr
  dsimp [stMid] at hu₂ hb₂ hpc₂ hpb₂
  exact ⟨st₂, hite, hw₂, hf₂, hbs₂, by omega, by omega, hpc₂, hpb₂⟩

theorem ExecBounded.repeatN {d : ℕ} {inp : BitRAMInput d}
    {countE : IntExpr} {body : BitRAMStmt}
    (n : ℕ) (wsSeq : ℕ → WordStore) (bsSeq : ℕ → List Bool)
    {uc bc U B C S : ℕ}
    (hcnt : evalIntExpr inp 1 (wsSeq 0) countE = ((n : ℤ), uc, bc))
    (hstep : ∀ k : ℕ, k < n →
      ExecBounded inp body (wsSeq k) (bsSeq k) (wsSeq (k + 1)) (bsSeq (k + 1)) U B C S) :
    ExecBounded inp (.repeatN countE body) (wsSeq 0) (bsSeq 0) (wsSeq n) (bsSeq n)
      (uc + 1 + n * U) (bc + 1 + n * B) C S := by
  have hloop : ∀ (rem k : ℕ), k + rem = n →
      ∀ st_k : BitRAMExecState,
        st_k.words = wsSeq k → st_k.frameDepth = 1 → st_k.remainingBits = bsSeq k →
        ∃ st_end : BitRAMExecState,
          RunsTo inp [.repeatLoop rem body] st_k st_end ∧
          st_end.words = wsSeq n ∧
          st_end.frameDepth = 1 ∧
          st_end.remainingBits = bsSeq n ∧
          st_end.unitCost ≤ st_k.unitCost + rem * U ∧
          st_end.bitCost ≤ st_k.bitCost + rem * B ∧
          st_end.peakCellSpace ≤ max st_k.peakCellSpace C ∧
          st_end.peakBitSpace ≤ max st_k.peakBitSpace S := by
    intro rem
    induction rem with
    | zero =>
        intro k hkn st_k hw hf hbs
        have hkn' : k = n := by omega
        subst hkn'
        exact ⟨st_k, RunsTo.repeatLoop_zero body st_k, hw, hf, hbs,
          by simp, by simp, le_max_left _ _, le_max_left _ _⟩
    | succ rem ih =>
        intro k hkn st_k hw hf hbs
        obtain ⟨st_next, hr1, hw1, hf1, hbs1, hu1, hb1, hpc1, hpb1⟩ :=
          hstep k (by omega) st_k hw hf hbs
        obtain ⟨st_end, hr2, hw2, hf2, hbs2, hu2, hb2, hpc2, hpb2⟩ :=
          ih (k + 1) (by omega) st_next hw1 hf1 hbs1
        refine ⟨st_end, RunsTo.repeatLoop_succ hr1 hr2, hw2, hf2, hbs2, ?_, ?_,
          hpc2.trans (max_le hpc1 (le_max_right _ _)),
          hpb2.trans (max_le hpb1 (le_max_right _ _))⟩
        · have : (rem + 1) * U = U + rem * U := by ring
          omega
        · have : (rem + 1) * B = B + rem * B := by ring
          omega
  intro st₁ hw₁ hf₁ hbs₁
  let st₀ : BitRAMExecState :=
    { st₁ with unitCost := st₁.unitCost + uc, bitCost := st₁.bitCost + bc }
  obtain ⟨st_end, hrl, hw_e, hf_e, hbs_e, hu_e, hb_e, hpc_e, hpb_e⟩ :=
    hloop n 0 (by omega) st₀ hw₁ hf₁ hbs₁
  have hrep : RunsTo inp [.stmt (.repeatN countE body)] st₁ st_end := by
    refine RunsTo.repeatN countE body ?_
    have hc' : evalIntExpr inp st₁.frameDepth st₁.words countE = ((n : ℤ), uc, bc) := by
      rwa [hf₁, hw₁]
    rw [hc']
    dsimp only
    rw [if_pos (Int.natCast_nonneg n), Int.toNat_natCast]
    exact hrl
  dsimp [st₀] at hu_e hb_e hpc_e hpb_e
  exact ⟨st_end, hrep, hw_e, hf_e, hbs_e, by omega, by omega, hpc_e, hpb_e⟩

theorem ExecBounded.whileLoop {d : ℕ} {inp : BitRAMInput d}
    {cond : BitCondExpr} {body : BitRAMStmt}
    (n : ℕ) (wsSeq : ℕ → WordStore) (bs : List Bool)
    {Uc Bc Ub Bb C S : ℕ}
    (hcond_true : ∀ k : ℕ, k < n →
      ∃ uc bc, evalBitCond inp 1 (wsSeq k) cond = (true, uc, bc) ∧ uc ≤ Uc ∧ bc ≤ Bc)
    (hcond_false :
      ∃ uc bc, evalBitCond inp 1 (wsSeq n) cond = (false, uc, bc) ∧ uc ≤ Uc ∧ bc ≤ Bc)
    (hstep : ∀ k : ℕ, k < n →
      ExecBounded inp body (wsSeq k) bs (wsSeq (k + 1)) bs Ub Bb C S) :
    ExecBounded inp (.whileLoop cond body) (wsSeq 0) bs (wsSeq n) bs
      ((n + 1) * Uc + n * Ub) ((n + 1) * Bc + n * Bb) C S := by
  have haux : ∀ (rem k : ℕ), k + rem = n →
      ∀ st_k : BitRAMExecState,
        st_k.words = wsSeq k → st_k.frameDepth = 1 → st_k.remainingBits = bs →
        ∃ st_end : BitRAMExecState,
          RunsTo inp [.stmt (.whileLoop cond body)] st_k st_end ∧
          st_end.words = wsSeq n ∧
          st_end.frameDepth = 1 ∧
          st_end.remainingBits = bs ∧
          st_end.unitCost ≤ st_k.unitCost + (rem + 1) * Uc + rem * Ub ∧
          st_end.bitCost ≤ st_k.bitCost + (rem + 1) * Bc + rem * Bb ∧
          st_end.peakCellSpace ≤ max st_k.peakCellSpace C ∧
          st_end.peakBitSpace ≤ max st_k.peakBitSpace S := by
    intro rem
    induction rem with
    | zero =>
        intro k hkn st_k hw hf hbs
        have hkn' : k = n := by omega
        subst hkn'
        obtain ⟨uc, bc, hc, huc, hbc⟩ := hcond_false
        have hc' : evalBitCond inp st_k.frameDepth st_k.words cond = (false, uc, bc) := by
          rw [hw, hf]; exact hc
        exact ⟨_, RunsTo.whileLoop_false cond body hc', hw, hf, hbs,
          by dsimp; omega, by dsimp; omega, le_max_left _ _, le_max_left _ _⟩
    | succ rem ih =>
        intro k hkn st_k hw hf hbs
        obtain ⟨uc, bc, hc, huc, hbc⟩ := hcond_true k (by omega)
        have hc' : evalBitCond inp st_k.frameDepth st_k.words cond = (true, uc, bc) := by
          rw [hw, hf]; exact hc
        let stMid : BitRAMExecState :=
          { st_k with unitCost := st_k.unitCost + uc, bitCost := st_k.bitCost + bc }
        obtain ⟨st_next, hr1, hw1, hf1, hbs1, hu1, hb1, hpc1, hpb1⟩ :=
          hstep k (by omega) stMid hw hf hbs
        obtain ⟨st_end, hr2, hw2, hf2, hbs2, hu2, hb2, hpc2, hpb2⟩ :=
          ih (k + 1) (by omega) st_next hw1 hf1 hbs1
        dsimp [stMid] at hu1 hb1 hpc1 hpb1
        refine ⟨st_end, RunsTo.whileLoop_true cond body hc' hr1 hr2,
          hw2, hf2, hbs2, ?_, ?_,
          hpc2.trans (max_le hpc1 (le_max_right _ _)),
          hpb2.trans (max_le hpb1 (le_max_right _ _))⟩
        · have h1 : (rem + 1 + 1) * Uc = Uc + (rem + 1) * Uc := by ring
          have h2 : (rem + 1) * Ub = Ub + rem * Ub := by ring
          omega
        · have h1 : (rem + 1 + 1) * Bc = Bc + (rem + 1) * Bc := by ring
          have h2 : (rem + 1) * Bb = Bb + rem * Bb := by ring
          omega
  intro st₁ hw₁ hf₁ hbs₁
  obtain ⟨st_e, hr, hw, hf, hbs, hu, hb, hpc, hpb⟩ := haux n 0 (by omega) st₁ hw₁ hf₁ hbs₁
  exact ⟨st_e, hr, hw, hf, hbs, by omega, by omega, hpc, hpb⟩

/-! ### 3. Reusable BitRAM loop gadgets at `frameDepth = 1` -/

private theorem z_toNat_lt_of_lt16 {z : ℤ} {A : ℕ} (h0 : 0 ≤ z) (h16 : z < 16) (hA : 16 ≤ A) :
    z.toNat < A := by
  omega

/-- Compute `(pow2, cnt)` with `pow2 = 2 ^ cnt` and `cnt = Nat.clog 2 target` via doubling. -/
def clog2LoopStmt (targetIdx powIdx cntIdx : ℤ) : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit powIdx) (.lit 1))
  (.seq (.writeLocal 1 (.lit cntIdx) (.lit 0))
    (.whileLoop (.intLt (.readLocal 1 (.lit powIdx)) (.readLocal 1 (.lit targetIdx)))
      (.seq (.writeLocal 1 (.lit powIdx) (.mul (.lit 2) (.readLocal 1 (.lit powIdx))))
            (.writeLocal 1 (.lit cntIdx) (.add (.readLocal 1 (.lit cntIdx)) (.lit 1))))))

theorem exec_clog2LoopStmt {d A V : ℕ} {inp : BitRAMInput d}
    {ws₀ : WordStore} {bs : List Bool} {T : ℕ}
    {targetIdx powIdx cntIdx : ℤ}
    (harena : InAttemptArena A V ws₀)
    (hidx_distinct : targetIdx ≠ powIdx ∧ targetIdx ≠ cntIdx ∧ powIdx ≠ cntIdx)
    (hidx_bounds : 0 ≤ targetIdx ∧ targetIdx < 16 ∧ 0 ≤ powIdx ∧ powIdx < 16 ∧
      0 ≤ cntIdx ∧ cntIdx < 16 ∧ 16 ≤ A)
    (hreadT : ws₀.read (.localFrame 1 1 targetIdx) = (T : ℤ))
    (hT1 : 1 ≤ T)
    (hV_pow : natBitLength (2 ^ Nat.clog 2 T) + 2 ≤ V) :
    let k := Nat.clog 2 T
    let wsEnd := (ws₀.write (.localFrame 1 1 powIdx) ((2 ^ k : ℕ) : ℤ)).write
      (.localFrame 1 1 cntIdx) (k : ℤ)
    let C_ar := inp.inputCellSpace + 108 * A
    let S_ar := inp.inputBitSpace + 108 * A * (natBitLength A + V + 16)
    InAttemptArena A V wsEnd ∧
    T ≤ 2 ^ k ∧
    (2 ≤ T → 2 ^ k < 2 * T) ∧
    ExecBounded inp (clog2LoopStmt targetIdx powIdx cntIdx) ws₀ bs wsEnd bs
      (32 * (k + 1)) (64 * (k + natBitLength T + 16) ^ 2) C_ar S_ar := by
  intro k wsEnd C_ar S_ar
  change natBitLength (2 ^ k) + 2 ≤ V at hV_pow
  have hk_pow : T ≤ 2 ^ k := Nat.le_pow_clog (by norm_num) T
  have hk_ub : 2 ≤ T → 2 ^ k < 2 * T := by
    intro hT2
    rcases Nat.eq_zero_or_pos k with hk0 | hk_pos
    · rw [hk0] at hk_pow; omega
    · obtain ⟨m, hm⟩ := Nat.exists_eq_succ_of_ne_zero hk_pos.ne'
      have hlt : m < Nat.clog 2 T := by dsimp [k] at hm; omega
      have hgt : 2 ^ m < T := (Nat.lt_clog_iff_pow_lt (by norm_num)).mp hlt
      rw [hm, pow_succ]
      omega
  let wsSeq : ℕ → WordStore := fun j =>
    (ws₀.write (.localFrame 1 1 powIdx) ((2 ^ j : ℕ) : ℤ)).write
      (.localFrame 1 1 cntIdx) (j : ℤ)
  have hpow_idx_lt : powIdx.toNat < A :=
    z_toNat_lt_of_lt16 hidx_bounds.2.2.1 hidx_bounds.2.2.2.1 hidx_bounds.2.2.2.2.2.2
  have hcnt_idx_lt : cntIdx.toNat < A :=
    z_toNat_lt_of_lt16 hidx_bounds.2.2.2.2.1 hidx_bounds.2.2.2.2.2.1 hidx_bounds.2.2.2.2.2.2
  have harena_j : ∀ j : ℕ, j ≤ k → InAttemptArena A V (wsSeq j) := by
    intro j hj
    have hp_le : 2 ^ j ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hj
    have hp_ib : intBitLength ((2 ^ j : ℕ) : ℤ) ≤ V := by
      have := intBitLength_natCast_le_succ (2 ^ j)
      have := natBitLength_mono hp_le
      omega
    have hj_le : j ≤ 2 ^ k := (Nat.lt_pow_self (by norm_num : 1 < 2)).le.trans
      (Nat.pow_le_pow_right (by norm_num) hj)
    have hj_ib : intBitLength (j : ℤ) ≤ V := by
      have := intBitLength_natCast_le_succ j
      have := natBitLength_mono hj_le
      omega
    exact inAttemptArena_write_local (var := 1)
      (inAttemptArena_write_local (var := 1) harena (by norm_num) hidx_bounds.2.2.1 hpow_idx_lt hp_ib)
      (by norm_num) hidx_bounds.2.2.2.2.1 hcnt_idx_lt hj_ib
  have hloc_ib : ∀ z : ℤ, 0 ≤ z → z < 16 → intBitLength z ≤ 6 := by
    intro z hz0 hz16
    rw [← Int.toNat_of_nonneg hz0]
    have hlt : z.toNat < 2 ^ 4 := by omega
    have := natBitLength_le_of_lt_two_pow (by norm_num) hlt
    have := intBitLength_natCast_le_succ z.toNat
    omega
  have hi_t := hloc_ib targetIdx hidx_bounds.1 hidx_bounds.2.1
  have hi_p := hloc_ib powIdx hidx_bounds.2.2.1 hidx_bounds.2.2.2.1
  have hi_c := hloc_ib cntIdx hidx_bounds.2.2.2.2.1 hidx_bounds.2.2.2.2.2.1
  have hn1 : natBitLength 1 = 1 := rfl
  have hi0 : intBitLength 0 = 1 := rfl
  have hi1 : intBitLength 1 = 2 := by decide
  have hi2 : intBitLength 2 = 3 := by decide
  have hT_ib : intBitLength (T : ℤ) ≤ natBitLength T + 1 := intBitLength_natCast_le_succ T
  let wsInit1 := ws₀.write (.localFrame 1 1 powIdx) 1
  have haInit1 : InAttemptArena A V wsInit1 := by
    refine inAttemptArena_write_local (var := 1) harena (by norm_num) hidx_bounds.2.2.1 hpow_idx_lt ?_
    have : 2 ≤ V := by have := natBitLength_pos (2 ^ k); omega
    rw [hi1]; exact this
  have hs1 : ExecBounded inp (.writeLocal 1 (.lit powIdx) (.lit 1)) ws₀ bs wsInit1 bs
      3 24 C_ar S_ar := by
    refine ExecBounded.writeLocal_arena haInit1 rfl rfl (by omega) ?_
    simp only [RAMCellLoc.bitLength, hn1, hi1]; omega
  have hs2 : ExecBounded inp (.writeLocal 1 (.lit cntIdx) (.lit 0)) wsInit1 bs (wsSeq 0) bs
      3 24 C_ar S_ar := by
    have ha0 : InAttemptArena A V (wsInit1.write (.localFrame 1 1 cntIdx) 0) :=
      harena_j 0 (Nat.zero_le k)
    refine ExecBounded.writeLocal_arena ha0 rfl rfl (by omega) ?_
    simp only [RAMCellLoc.bitLength, hn1, Nat.cast_zero, hi0]; omega
  have hreads : ∀ j : ℕ,
      (wsSeq j).read (.localFrame 1 1 powIdx) = ((2 ^ j : ℕ) : ℤ) ∧
      (wsSeq j).read (.localFrame 1 1 cntIdx) = (j : ℤ) ∧
      (wsSeq j).read (.localFrame 1 1 targetIdx) = (T : ℤ) := by
    intro j
    dsimp [wsSeq]
    refine ⟨?_, wordStore_read_write_self _ _ _, ?_⟩
    · rw [rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hidx_distinct.2.2 h),
        wordStore_read_write_self]
    · rw [rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hidx_distinct.2.1 h),
        rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hidx_distinct.1 h),
        hreadT]
  have hpow_ib_le : ∀ j : ℕ, j ≤ k → intBitLength ((2 ^ j : ℕ) : ℤ) ≤ k + 3 := by
    intro j hj
    have hlt : 2 ^ j < 2 ^ (j + 1) := Nat.pow_lt_pow_right (by norm_num) (Nat.lt_succ_self j)
    have hnb := natBitLength_le_of_lt_two_pow (by omega) hlt
    have hib := intBitLength_natCast_le_succ (2 ^ j)
    omega
  have hj_ib_le : ∀ j : ℕ, j ≤ k → intBitLength (j : ℤ) ≤ k + 3 := by
    intro j hj
    have := natBitLength_le j
    have := intBitLength_natCast_le_succ j
    omega
  let B_step : ℕ := 10 * (k + natBitLength T + 16)
  have hwhile : ExecBounded inp
      (.whileLoop (.intLt (.readLocal 1 (.lit powIdx)) (.readLocal 1 (.lit targetIdx)))
        (.seq (.writeLocal 1 (.lit powIdx) (.mul (.lit 2) (.readLocal 1 (.lit powIdx))))
              (.writeLocal 1 (.lit cntIdx) (.add (.readLocal 1 (.lit cntIdx)) (.lit 1)))))
      (wsSeq 0) bs (wsSeq k) bs
      ((k + 1) * 5 + k * 12) ((k + 1) * B_step + k * B_step) C_ar S_ar := by
    refine ExecBounded.whileLoop k wsSeq bs (Uc := 5) (Bc := B_step) (Ub := 12) (Bb := B_step)
      (fun j hj => ?_) ?_ (fun j hj => ?_)
    · obtain ⟨hr_p, _, hr_t⟩ := hreads j
      have hp_lt_T : 2 ^ j < T := (Nat.lt_clog_iff_pow_lt (by norm_num)).mp hj
      have hp_lt_Tz : ((2 ^ j : ℕ) : ℤ) < (T : ℤ) := by exact_mod_cast hp_lt_T
      have hib_p := hpow_ib_le j (le_of_lt hj)
      refine ⟨5,
        (intBitLength powIdx + 1 + intBitLength powIdx + intBitLength ((2 ^ j : ℕ) : ℤ)) +
          (intBitLength targetIdx + 1 + intBitLength targetIdx + intBitLength (T : ℤ)) +
          intBitLength ((2 ^ j : ℕ) : ℤ) + intBitLength (T : ℤ),
        ?_, le_rfl, ?_⟩
      · simp only [evalBitCond, evalIntExpr, hr_p, hr_t, hp_lt_Tz, decide_true, hn1]
      · have hcast_j : ((2 ^ j : ℕ) : ℤ) = (2 : ℤ) ^ j := Nat.cast_pow 2 j
        rw [hcast_j] at hib_p ⊢
        dsimp [B_step]; omega
    · obtain ⟨hr_p, _, hr_t⟩ := hreads k
      have hp_not_lt : ¬ (((2 ^ k : ℕ) : ℤ) < (T : ℤ)) := by exact_mod_cast not_lt.mpr hk_pow
      have hib_p := hpow_ib_le k le_rfl
      refine ⟨5,
        (intBitLength powIdx + 1 + intBitLength powIdx + intBitLength ((2 ^ k : ℕ) : ℤ)) +
          (intBitLength targetIdx + 1 + intBitLength targetIdx + intBitLength (T : ℤ)) +
          intBitLength ((2 ^ k : ℕ) : ℤ) + intBitLength (T : ℤ),
        ?_, le_rfl, ?_⟩
      · simp only [evalBitCond, evalIntExpr, hr_p, hr_t, hp_not_lt, decide_false, hn1]
      · have hcast_k : ((2 ^ k : ℕ) : ℤ) = (2 : ℤ) ^ k := Nat.cast_pow 2 k
        rw [hcast_k] at hib_p ⊢
        dsimp [B_step]; omega
    · obtain ⟨hr_p, hr_c, _⟩ := hreads j
      have hib_p := hpow_ib_le j (le_of_lt hj)
      have hib_p1 := hpow_ib_le (j + 1) hj
      have hib_c := hj_ib_le j (le_of_lt hj)
      have hib_c1 := hj_ib_le (j + 1) hj
      let wsMid := (wsSeq j).write (.localFrame 1 1 powIdx) (((2 ^ (j + 1) : ℕ) : ℤ))
      have haMid : InAttemptArena A V wsMid := by
        refine inAttemptArena_write_local (var := 1) (harena_j j (le_of_lt hj)) (by norm_num)
          hidx_bounds.2.2.1 hpow_idx_lt ?_
        have hp_le : 2 ^ (j + 1) ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hj
        have := intBitLength_natCast_le_succ (2 ^ (j + 1))
        have := natBitLength_mono hp_le
        omega
      have hmul_val : (2 : ℤ) * ((2 ^ j : ℕ) : ℤ) = ((2 ^ (j + 1) : ℕ) : ℤ) := by
        rw [pow_succ]; push_cast; ring
      have hev1 : evalIntExpr inp 1 (wsSeq j) (.mul (.lit 2) (.readLocal 1 (.lit powIdx))) =
          (((2 ^ (j + 1) : ℕ) : ℤ), 4,
           intBitLength 2 + (intBitLength powIdx + 1 + intBitLength powIdx + intBitLength ((2 ^ j : ℕ) : ℤ)) +
             intBitLength 2 * intBitLength ((2 ^ j : ℕ) : ℤ)) := by
        simp only [evalIntExpr, hr_p, hmul_val, hn1]
      have hw1 : ExecBounded inp
          (.writeLocal 1 (.lit powIdx) (.mul (.lit 2) (.readLocal 1 (.lit powIdx))))
          (wsSeq j) bs wsMid bs 6 (6 * (k + natBitLength T + 16)) C_ar S_ar := by
        refine ExecBounded.writeLocal_arena haMid rfl hev1 (by omega) ?_
        simp only [RAMCellLoc.bitLength, hn1, hi2]; omega
      have hr_c_mid : wsMid.read (.localFrame 1 1 cntIdx) = (j : ℤ) := by
        dsimp [wsMid]
        rw [rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hidx_distinct.2.2 h.symm)]
        exact hr_c
      have hw_Overwrite : wsMid.write (.localFrame 1 1 cntIdx) (((j + 1 : ℕ) : ℤ)) = wsSeq (j + 1) := by
        dsimp [wsMid, wsSeq]
        unfold WordStore.write
        congr 1
        · ext l
          simp only [Finset.mem_insert]
          tauto
        · funext l
          dsimp only
          by_cases hc1 : l = .localFrame 1 1 cntIdx
          · subst hc1; simp
          · rw [Function.update_of_ne hc1, Function.update_of_ne hc1]
            by_cases hp1 : l = .localFrame 1 1 powIdx
            · subst hp1; simp
            · simp [Function.update_of_ne hp1, Function.update_of_ne hc1]
      have hadd_val : (j : ℤ) + 1 = ((j + 1 : ℕ) : ℤ) := by push_cast; rfl
      have hev2 : evalIntExpr inp 1 wsMid (.add (.readLocal 1 (.lit cntIdx)) (.lit 1)) =
          (((j + 1 : ℕ) : ℤ), 4,
           (intBitLength cntIdx + 1 + intBitLength cntIdx + intBitLength (j : ℤ)) + intBitLength 1 +
             intBitLength (j : ℤ) + intBitLength 1) := by
        simp only [evalIntExpr, hr_c_mid, hadd_val, hn1]
      have haNext' : InAttemptArena A V (wsMid.write (.localFrame 1 1 cntIdx) (((j + 1 : ℕ) : ℤ))) := by
        rw [hw_Overwrite]; exact harena_j (j + 1) hj
      have hw2 : ExecBounded inp
          (.writeLocal 1 (.lit cntIdx) (.add (.readLocal 1 (.lit cntIdx)) (.lit 1)))
          wsMid bs (wsSeq (j + 1)) bs 6 (4 * (k + natBitLength T + 16)) C_ar S_ar := by
        rw [← hw_Overwrite]
        refine ExecBounded.writeLocal_arena haNext' rfl hev2 (by omega) ?_
        simp only [RAMCellLoc.bitLength, hn1, hi1]; omega
      exact ExecBounded.mono (ExecBounded.seq hw1 hw2) (by omega) (by dsimp [B_step]; omega) le_rfl le_rfl
  refine ⟨harena_j k le_rfl, hk_pow, hk_ub, ?_⟩
  have hfull := ExecBounded.seq hs1 (ExecBounded.seq hs2 hwhile)
  refine ExecBounded.mono hfull (by omega) ?_ le_rfl le_rfl
  dsimp [B_step]
  set X := k + natBitLength T + 16
  have hX16 : 16 ≤ X := by dsimp [X]; omega
  have h1 : k + 1 ≤ X := by dsimp [X]; omega
  have h2 : k ≤ X := by dsimp [X]; omega
  have h3 : (k + 1) * (10 * X) ≤ 10 * (X * X) := by
    calc (k + 1) * (10 * X) = 10 * ((k + 1) * X) := by ring
      _ ≤ 10 * (X * X) := Nat.mul_le_mul_left 10 (Nat.mul_le_mul_right X h1)
  have h4 : k * (10 * X) ≤ 10 * (X * X) := by
    calc k * (10 * X) = 10 * (k * X) := by ring
      _ ≤ 10 * (X * X) := Nat.mul_le_mul_left 10 (Nat.mul_le_mul_right X h2)
  have h5 : 48 ≤ X * X := by
    calc 48 ≤ 16 * 16 := by norm_num
      _ ≤ X * X := Nat.mul_le_mul hX16 hX16
  rw [sq]
  omega

/-- Draw `W` random bits (where `W` is stored in `.localFrame 1 0 wIdx`) into `.localFrame 1 1 accIdx`
using scratch bit `.localFrame 1 1 bitIdx`. -/
def drawBitsStmt (wIdx accIdx bitIdx : ℤ) : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit accIdx) (.lit 0))
    (.repeatN (.readLocal 0 (.lit wIdx))
      (.seq (.randBitLocal 1 (.lit bitIdx))
            (.writeLocal 1 (.lit accIdx)
              (.add (.mul (.lit 2) (.readLocal 1 (.lit accIdx)))
                    (.readLocal 1 (.lit bitIdx))))))

theorem bitsToNat_prefix_step {W k : ℕ} (hk : k < W) (f : Fin W → Bool) :
    bitsToNat (k + 1) (fun i : Fin (k + 1) => f ⟨i.1, Nat.lt_of_lt_of_le i.2 hk⟩) =
      2 * bitsToNat k (fun i : Fin k => f ⟨i.1, Nat.lt_trans i.2 hk⟩) +
        (if f ⟨k, hk⟩ then 1 else 0) :=
  rfl

private def drawBitsStepWS {W : ℕ} (f : Fin W → Bool) (accIdx bitIdx : ℤ) (ws₀ : WordStore) :
    ℕ → WordStore
  | 0 => ws₀.write (.localFrame 1 1 accIdx) 0
  | j + 1 =>
      if hj : j < W then
        let bval : ℤ := if f ⟨j, hj⟩ then 1 else 0
        let accNext : ℕ := bitsToNat (j + 1) (fun i : Fin (j + 1) => f ⟨i.1, Nat.lt_of_lt_of_le i.2 hj⟩)
        ((drawBitsStepWS f accIdx bitIdx ws₀ j).write (.localFrame 1 1 bitIdx) bval).write
          (.localFrame 1 1 accIdx) (accNext : ℤ)
      else drawBitsStepWS f accIdx bitIdx ws₀ j

theorem exec_drawBitsStmt {d A V : ℕ} {inp : BitRAMInput d}
    {ws₀ : WordStore} {W : ℕ} (f : Fin W → Bool) (rest : List Bool)
    {wIdx accIdx bitIdx : ℤ}
    (harena : InAttemptArena A V ws₀)
    (hdistinct : accIdx ≠ bitIdx)
    (hbounds : 0 ≤ wIdx ∧ wIdx < 16 ∧ 0 ≤ accIdx ∧ accIdx < 16 ∧
      0 ≤ bitIdx ∧ bitIdx < 16 ∧ 16 ≤ A)
    (hreadW : ws₀.read (.localFrame 1 0 wIdx) = (W : ℤ))
    (hV_acc : W + 4 ≤ V) :
    let C_ar := inp.inputCellSpace + 108 * A
    let S_ar := inp.inputBitSpace + 108 * A * (natBitLength A + V + 16)
    ∃ wsEnd : WordStore,
      InAttemptArena A V wsEnd ∧
      wsEnd.read (.localFrame 1 1 accIdx) = (bitsToNat W f : ℤ) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .localFrame 1 1 accIdx → loc ≠ .localFrame 1 1 bitIdx →
        wsEnd.read loc = ws₀.read loc) ∧
      ExecBounded inp (drawBitsStmt wIdx accIdx bitIdx)
        ws₀ (List.ofFn f ++ rest) wsEnd rest
        (24 * (W + 1)) (64 * (W + 16) ^ 2) C_ar S_ar := by
  intro C_ar S_ar
  let accAt : (j : ℕ) → j ≤ W → ℕ := fun j hj =>
    bitsToNat j (fun i : Fin j => f ⟨i.1, Nat.lt_of_lt_of_le i.2 hj⟩)
  let wsStep : ℕ → WordStore := drawBitsStepWS f accIdx bitIdx ws₀
  let bsStep : ℕ → List Bool := fun j => (List.ofFn f).drop j ++ rest
  have hacc_idx_lt : accIdx.toNat < A :=
    z_toNat_lt_of_lt16 hbounds.2.2.1 hbounds.2.2.2.1 hbounds.2.2.2.2.2.2
  have hbit_idx_lt : bitIdx.toNat < A :=
    z_toNat_lt_of_lt16 hbounds.2.2.2.2.1 hbounds.2.2.2.2.2.1 hbounds.2.2.2.2.2.2
  have hn0 : natBitLength 0 = 1 := rfl
  have hn1 : natBitLength 1 = 1 := rfl
  have hi0 : intBitLength 0 = 1 := rfl
  have hi1 : intBitLength 1 = 2 := by decide
  have hi2 : intBitLength 2 = 3 := by decide
  have hacc_ib : ∀ (j : ℕ) (hj : j ≤ W), intBitLength ((accAt j hj : ℕ) : ℤ) ≤ W + 2 := by
    intro j hj
    have hlt : accAt j hj < 2 ^ j := bitsToNat_lt j _
    have hltW : accAt j hj < 2 ^ (W + 1) :=
      hlt.trans_le (Nat.pow_le_pow_right (by norm_num) (by omega))
    have hnb := natBitLength_le_of_lt_two_pow (by omega) hltW
    have hib := intBitLength_natCast_le_succ (accAt j hj)
    omega
  have hinv : ∀ (j : ℕ) (hj : j ≤ W),
      InAttemptArena A V (wsStep j) ∧
      (wsStep j).read (.localFrame 1 1 accIdx) = ((accAt j hj : ℕ) : ℤ) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .localFrame 1 1 accIdx → loc ≠ .localFrame 1 1 bitIdx →
        (wsStep j).read loc = ws₀.read loc) := by
    intro j
    induction j with
    | zero =>
        intro hj
        dsimp only [wsStep, drawBitsStepWS]
        refine ⟨inAttemptArena_write_local (var := 1) harena (by norm_num) hbounds.2.2.1 hacc_idx_lt
          (by rw [hi0]; omega),
          wordStore_read_write_self _ _ _,
          fun loc h1 _ => rw_read_write_ne h1⟩
    | succ j ih =>
        intro hj
        have hj_lt : j < W := hj
        obtain ⟨ha_prev, hr_prev, hother_prev⟩ := ih (le_of_lt hj_lt)
        dsimp only [wsStep, drawBitsStepWS]
        rw [dif_pos hj_lt]
        have hb_ib : intBitLength (if f ⟨j, hj_lt⟩ then (1 : ℤ) else 0) ≤ V := by
          split_ifs
          · rw [hi1]; omega
          · rw [hi0]; omega
        have ha1 := inAttemptArena_write_local (var := 1) ha_prev (by norm_num) hbounds.2.2.2.2.1 hbit_idx_lt hb_ib
        have ha2 := inAttemptArena_write_local (var := 1) ha1 (by norm_num) hbounds.2.2.1 hacc_idx_lt
          ((hacc_ib (j + 1) hj).trans (by omega))
        refine ⟨ha2, wordStore_read_write_self _ _ _, fun loc h1 h2 => ?_⟩
        rw [rw_read_write_ne h1, rw_read_write_ne h2]
        exact hother_prev loc h1 h2
  have hloc_ib : ∀ z : ℤ, 0 ≤ z → z < 16 → intBitLength z ≤ 6 := by
    intro z hz0 hz16
    rw [← Int.toNat_of_nonneg hz0]
    have hlt : z.toNat < 2 ^ 4 := by omega
    have := natBitLength_le_of_lt_two_pow (by norm_num) hlt
    have := intBitLength_natCast_le_succ z.toNat
    omega
  have hi_w := hloc_ib wIdx hbounds.1 hbounds.2.1
  have hi_a := hloc_ib accIdx hbounds.2.2.1 hbounds.2.2.2.1
  have hi_b := hloc_ib bitIdx hbounds.2.2.2.2.1 hbounds.2.2.2.2.2.1
  have hs_init : ExecBounded inp (.writeLocal 1 (.lit accIdx) (.lit 0))
      ws₀ (bsStep 0) (wsStep 0) (bsStep 0) 3 24 C_ar S_ar := by
    have ha0 : InAttemptArena A V (ws₀.write (.localFrame 1 1 accIdx) 0) :=
      (hinv 0 (Nat.zero_le W)).1
    refine ExecBounded.writeLocal_arena ha0 rfl rfl (by omega) ?_
    simp only [RAMCellLoc.bitLength, hn1, hi0]; omega
  have hrW0 : (wsStep 0).read (.localFrame 1 0 wIdx) = (W : ℤ) := by
    rw [(hinv 0 (Nat.zero_le W)).2.2 _ (by intro h; nomatch h) (by intro h; nomatch h), hreadW]
  have hW_ib : intBitLength (W : ℤ) ≤ W + 2 := by
    have := natBitLength_le W; have := intBitLength_natCast_le_succ W; omega
  let B_iter : ℕ := 16 * (W + 16)
  have hcnt_W : evalIntExpr inp 1 (wsStep 0) (.readLocal 0 (.lit wIdx)) =
      ((W : ℤ), 2, intBitLength wIdx + 1 + intBitLength wIdx + intBitLength (W : ℤ)) := by
    simp [evalIntExpr, hrW0, hn0]
  have hrep : ExecBounded inp
      (.repeatN (.readLocal 0 (.lit wIdx))
        (.seq (.randBitLocal 1 (.lit bitIdx))
              (.writeLocal 1 (.lit accIdx)
                (.add (.mul (.lit 2) (.readLocal 1 (.lit accIdx)))
                      (.readLocal 1 (.lit bitIdx))))))
      (wsStep 0) (bsStep 0) (wsStep W) (bsStep W)
      (2 + 1 + W * 12) ((intBitLength wIdx + 1 + intBitLength wIdx + intBitLength (W : ℤ)) + 1 + W * B_iter)
      C_ar S_ar := by
    refine ExecBounded.repeatN W wsStep bsStep (U := 12) (B := B_iter)
      hcnt_W (fun j hj => ?_)
    obtain ⟨ha_j, hr_acc_j, _⟩ := hinv j (le_of_lt hj)
    have hbs_j : bsStep j = f ⟨j, hj⟩ :: bsStep (j + 1) := by
      dsimp [bsStep]
      have hlen : j < (List.ofFn f).length := by simpa using hj
      rw [List.drop_eq_getElem_cons hlen, List.getElem_ofFn, List.cons_append]
    rw [hbs_j]
    let bval : ℤ := if f ⟨j, hj⟩ then 1 else 0
    let wsMid := (wsStep j).write (.localFrame 1 1 bitIdx) bval
    have hb_ib_v : intBitLength bval ≤ 2 := by
      dsimp [bval]; split_ifs <;> decide
    have haMid : InAttemptArena A V wsMid :=
      inAttemptArena_write_local (var := 1) ha_j (by norm_num) hbounds.2.2.2.2.1 hbit_idx_lt (hb_ib_v.trans (by omega))
    have hs_bit : ExecBounded inp (.randBitLocal 1 (.lit bitIdx))
        (wsStep j) (f ⟨j, hj⟩ :: bsStep (j + 1)) wsMid (bsStep (j + 1))
        2 24 C_ar S_ar := by
      refine ExecBounded.randBitLocal_arena haMid rfl (by omega) ?_
      simp only [RAMCellLoc.bitLength, hn1]; omega
    have hr_acc_mid : wsMid.read (.localFrame 1 1 accIdx) = ((accAt j (le_of_lt hj) : ℕ) : ℤ) := by
      dsimp [wsMid]
      rw [rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hdistinct h)]
      exact hr_acc_j
    have hr_bit_mid : wsMid.read (.localFrame 1 1 bitIdx) = bval :=
      wordStore_read_write_self _ _ _
    have hstep_eq : wsStep (j + 1) = wsMid.write (.localFrame 1 1 accIdx) ((accAt (j + 1) hj : ℕ) : ℤ) := by
      dsimp only [wsStep, drawBitsStepWS, wsMid, bval, accAt]
      rw [dif_pos hj]
    have hval_eq : (2 : ℤ) * ((accAt j (le_of_lt hj) : ℕ) : ℤ) + bval = ((accAt (j + 1) hj : ℕ) : ℤ) := by
      dsimp [accAt, bval]
      rw [bitsToNat_prefix_step hj f]
      push_cast
      split_ifs <;> ring
    have hib_a0 := hacc_ib j (le_of_lt hj)
    have hib_a1 := hacc_ib (j + 1) hj
    have hib_2a : intBitLength ((2 : ℤ) * ((accAt j (le_of_lt hj) : ℕ) : ℤ)) ≤ W + 5 :=
      (intBitLength_mul_le 2 _).trans (by rw [hi2]; omega)
    have hev_upd : evalIntExpr inp 1 wsMid
        (.add (.mul (.lit 2) (.readLocal 1 (.lit accIdx))) (.readLocal 1 (.lit bitIdx))) =
        (((accAt (j + 1) hj : ℕ) : ℤ), 7,
         (intBitLength 2 + (intBitLength accIdx + 1 + intBitLength accIdx + intBitLength ((accAt j (le_of_lt hj) : ℕ) : ℤ)) +
           intBitLength 2 * intBitLength ((accAt j (le_of_lt hj) : ℕ) : ℤ)) +
         (intBitLength bitIdx + 1 + intBitLength bitIdx + intBitLength bval) +
         intBitLength ((2 : ℤ) * ((accAt j (le_of_lt hj) : ℕ) : ℤ)) + intBitLength bval) := by
      simp only [evalIntExpr, hr_acc_mid, hr_bit_mid, hval_eq, hn1]
    have haNext : InAttemptArena A V (wsMid.write (.localFrame 1 1 accIdx) ((accAt (j + 1) hj : ℕ) : ℤ)) := by
      rw [← hstep_eq]; exact (hinv (j + 1) hj).1
    have hs_upd : ExecBounded inp
        (.writeLocal 1 (.lit accIdx)
          (.add (.mul (.lit 2) (.readLocal 1 (.lit accIdx))) (.readLocal 1 (.lit bitIdx))))
        wsMid (bsStep (j + 1)) (wsStep (j + 1)) (bsStep (j + 1))
        9 (12 * (W + 16)) C_ar S_ar := by
      rw [hstep_eq]
      refine ExecBounded.writeLocal_arena haNext rfl hev_upd (by omega) ?_
      simp only [RAMCellLoc.bitLength, hn1, hi2]; omega
    exact ExecBounded.mono (ExecBounded.seq hs_bit hs_upd) (by omega) (by dsimp [B_iter]; omega) le_rfl le_rfl
  obtain ⟨ha_W, hr_W, hother_W⟩ := hinv W le_rfl
  have hacc_W : accAt W le_rfl = bitsToNat W f := rfl
  have hbs0 : bsStep 0 = List.ofFn f ++ rest := by simp [bsStep]
  have hbsW : bsStep W = rest := by simp [bsStep]
  rw [hbs0] at hs_init
  rw [hbsW] at hrep
  refine ⟨wsStep W, ha_W, by rw [hr_W, hacc_W], hother_W, ?_⟩
  refine ExecBounded.mono (ExecBounded.seq hs_init hrep) (by omega) ?_ le_rfl le_rfl
  dsimp [B_iter]
  set X := W + 16
  have hX16 : 16 ≤ X := by dsimp [X]; omega
  have hWX : W ≤ X := by dsimp [X]; omega
  have h1 : W * (16 * X) ≤ 16 * (X * X) := by
    calc W * (16 * X) = 16 * (W * X) := by ring
      _ ≤ 16 * (X * X) := Nat.mul_le_mul_left 16 (Nat.mul_le_mul_right X hWX)
  have h2 : 16 * X ≤ X * X := Nat.mul_le_mul_right X hX16
  rw [sq]
  omega

/-- Run `N` Euclidean `gcdStep` iterations on `(a, b)` in `.localFrame 1 1 [aIdx, bIdx]` using
scratch `.localFrame 1 1 tmpIdx`, reading `N` from `.localFrame 1 1 nIdx`. -/
def gcdLoopStmt (nIdx aIdx bIdx tmpIdx : ℤ) : BitRAMStmt :=
  .repeatN (.readLocal 1 (.lit nIdx))
    (.ite (.intEq (.readLocal 1 (.lit bIdx)) (.lit 0))
      .skip
      (.seq (.writeLocal 1 (.lit tmpIdx)
              (.mod (.readLocal 1 (.lit aIdx)) (.readLocal 1 (.lit bIdx))))
      (.seq (.writeLocal 1 (.lit aIdx) (.readLocal 1 (.lit bIdx)))
            (.writeLocal 1 (.lit bIdx) (.readLocal 1 (.lit tmpIdx))))))

theorem gcdStep_iter_bounds {a₀ b₀ : ℕ} :
    ∀ k : ℕ,
      (gcdStep^[k] (a₀, b₀)).1 ≤ max a₀ b₀ ∧
      (gcdStep^[k] (a₀, b₀)).2 ≤ max a₀ b₀
  | 0 => ⟨le_max_left _ _, le_max_right _ _⟩
  | k + 1 => by
      rw [Function.iterate_succ_apply']
      obtain ⟨h1, h2⟩ := gcdStep_iter_bounds k
      obtain ⟨s1, s2⟩ := gcdStep_bounds (gcdStep^[k] (a₀, b₀))
      exact ⟨s1.trans (max_le h1 h2), s2.trans h2⟩

private def gcdLoopStepWS (a₀ b₀ : ℕ) (aIdx bIdx tmpIdx : ℤ) (ws₀ : WordStore) : ℕ → WordStore
  | 0 => ws₀
  | k + 1 =>
      let cur := gcdStep^[k] (a₀, b₀)
      if cur.2 = 0 then gcdLoopStepWS a₀ b₀ aIdx bIdx tmpIdx ws₀ k
      else
        (((gcdLoopStepWS a₀ b₀ aIdx bIdx tmpIdx ws₀ k).write
          (.localFrame 1 1 tmpIdx) ((cur.1 % cur.2 : ℕ) : ℤ)).write
          (.localFrame 1 1 aIdx) (cur.2 : ℤ)).write
          (.localFrame 1 1 bIdx) ((cur.1 % cur.2 : ℕ) : ℤ)

theorem exec_gcdLoopStmt {d A V : ℕ} {inp : BitRAMInput d}
    {ws₀ : WordStore} {bs : List Bool} {N a₀ b₀ L_ab : ℕ}
    {nIdx aIdx bIdx tmpIdx : ℤ}
    (harena : InAttemptArena A V ws₀)
    (hdistinct : nIdx ≠ aIdx ∧ nIdx ≠ bIdx ∧ nIdx ≠ tmpIdx ∧
      aIdx ≠ bIdx ∧ aIdx ≠ tmpIdx ∧ bIdx ≠ tmpIdx)
    (hbounds : 0 ≤ nIdx ∧ nIdx < 16 ∧ 0 ≤ aIdx ∧ aIdx < 16 ∧
      0 ≤ bIdx ∧ bIdx < 16 ∧ 0 ≤ tmpIdx ∧ tmpIdx < 16 ∧ 16 ≤ A)
    (hreadN : ws₀.read (.localFrame 1 1 nIdx) = (N : ℤ))
    (hreadA : ws₀.read (.localFrame 1 1 aIdx) = (a₀ : ℤ))
    (hreadB : ws₀.read (.localFrame 1 1 bIdx) = (b₀ : ℤ))
    (hab_len : natBitLength (max a₀ b₀) + 2 ≤ L_ab)
    (hV_ab : L_ab ≤ V) :
    let C_ar := inp.inputCellSpace + 108 * A
    let S_ar := inp.inputBitSpace + 108 * A * (natBitLength A + V + 16)
    ∃ wsEnd : WordStore,
      InAttemptArena A V wsEnd ∧
      wsEnd.read (.localFrame 1 1 aIdx) = ((gcdStep^[N] (a₀, b₀)).1 : ℤ) ∧
      wsEnd.read (.localFrame 1 1 bIdx) = ((gcdStep^[N] (a₀, b₀)).2 : ℤ) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .localFrame 1 1 aIdx → loc ≠ .localFrame 1 1 bIdx →
        loc ≠ .localFrame 1 1 tmpIdx → wsEnd.read loc = ws₀.read loc) ∧
      ExecBounded inp (gcdLoopStmt nIdx aIdx bIdx tmpIdx) ws₀ bs wsEnd bs
        (24 * (N + 1)) (64 * (N + 1) * (L_ab + natBitLength N + 16) ^ 2) C_ar S_ar := by
  intro C_ar S_ar
  let wsStep : ℕ → WordStore := gcdLoopStepWS a₀ b₀ aIdx bIdx tmpIdx ws₀
  have ha_idx_lt : aIdx.toNat < A :=
    z_toNat_lt_of_lt16 hbounds.2.2.1 hbounds.2.2.2.1 hbounds.2.2.2.2.2.2.2.2
  have hb_idx_lt : bIdx.toNat < A :=
    z_toNat_lt_of_lt16 hbounds.2.2.2.2.1 hbounds.2.2.2.2.2.1 hbounds.2.2.2.2.2.2.2.2
  have ht_idx_lt : tmpIdx.toNat < A :=
    z_toNat_lt_of_lt16 hbounds.2.2.2.2.2.2.1 hbounds.2.2.2.2.2.2.2.1 hbounds.2.2.2.2.2.2.2.2
  have hib_bound : ∀ x : ℕ, x ≤ max a₀ b₀ → intBitLength (x : ℤ) ≤ L_ab := by
    intro x hx
    have := intBitLength_natCast_le_succ x
    have := natBitLength_mono hx
    omega
  have hinv : ∀ k : ℕ,
      InAttemptArena A V (wsStep k) ∧
      (wsStep k).read (.localFrame 1 1 nIdx) = (N : ℤ) ∧
      (wsStep k).read (.localFrame 1 1 aIdx) = ((gcdStep^[k] (a₀, b₀)).1 : ℤ) ∧
      (wsStep k).read (.localFrame 1 1 bIdx) = ((gcdStep^[k] (a₀, b₀)).2 : ℤ) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .localFrame 1 1 aIdx → loc ≠ .localFrame 1 1 bIdx →
        loc ≠ .localFrame 1 1 tmpIdx → (wsStep k).read loc = ws₀.read loc) := by
    intro k
    induction k with
    | zero => exact ⟨harena, hreadN, hreadA, hreadB, fun _ _ _ _ => rfl⟩
    | succ k ih =>
        obtain ⟨ha_k, hrN_k, hrA_k, hrB_k, hother_k⟩ := ih
        obtain ⟨hb1, hb2⟩ := gcdStep_iter_bounds (a₀ := a₀) (b₀ := b₀) k
        rw [Function.iterate_succ_apply']
        dsimp only [wsStep, gcdLoopStepWS]
        by_cases hz : (gcdStep^[k] (a₀, b₀)).2 = 0
        · rw [if_pos hz]
          have hg : gcdStep (gcdStep^[k] (a₀, b₀)) = gcdStep^[k] (a₀, b₀) := by
            rcases hpair : gcdStep^[k] (a₀, b₀) with ⟨x, y⟩
            rw [hpair] at hz
            dsimp at hz
            subst hz
            rfl
          rw [hg]
          exact ⟨ha_k, hrN_k, hrA_k, hrB_k, hother_k⟩
        · rw [if_neg hz]
          have hg1 : (gcdStep (gcdStep^[k] (a₀, b₀))).1 = (gcdStep^[k] (a₀, b₀)).2 := by
            rcases hpair : gcdStep^[k] (a₀, b₀) with ⟨x, y⟩
            rw [hpair] at hz; dsimp at hz
            simp [gcdStep, hz]
          have hg2 : (gcdStep (gcdStep^[k] (a₀, b₀))).2 =
              (gcdStep^[k] (a₀, b₀)).1 % (gcdStep^[k] (a₀, b₀)).2 := by
            rcases hpair : gcdStep^[k] (a₀, b₀) with ⟨x, y⟩
            rw [hpair] at hz; dsimp at hz
            simp [gcdStep, hz]
          rw [hg1, hg2]
          have hmod_le : (gcdStep^[k] (a₀, b₀)).1 % (gcdStep^[k] (a₀, b₀)).2 ≤ max a₀ b₀ :=
            (Nat.mod_le _ _).trans hb1
          have ha1 := inAttemptArena_write_local (var := 1) ha_k (by norm_num) hbounds.2.2.2.2.2.2.1 ht_idx_lt
            ((hib_bound _ hmod_le).trans hV_ab)
          have ha2 := inAttemptArena_write_local (var := 1) ha1 (by norm_num) hbounds.2.2.1 ha_idx_lt
            ((hib_bound _ hb2).trans hV_ab)
          have ha3 := inAttemptArena_write_local (var := 1) ha2 (by norm_num) hbounds.2.2.2.2.1 hb_idx_lt
            ((hib_bound _ hmod_le).trans hV_ab)
          refine ⟨ha3, ?_, ?_, wordStore_read_write_self _ _ _, fun loc h1 h2 h3 => ?_⟩
          · rw [rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hdistinct.2.1 h),
              rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hdistinct.1 h),
              rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hdistinct.2.2.1 h)]
            exact hrN_k
          · rw [rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hdistinct.2.2.2.1 h),
              wordStore_read_write_self]
          · rw [rw_read_write_ne h2, rw_read_write_ne h1, rw_read_write_ne h3]
            exact hother_k loc h1 h2 h3
  have hloc_ib : ∀ z : ℤ, 0 ≤ z → z < 16 → intBitLength z ≤ 6 := by
    intro z hz0 hz16
    rw [← Int.toNat_of_nonneg hz0]
    have hlt : z.toNat < 2 ^ 4 := by omega
    have := natBitLength_le_of_lt_two_pow (by norm_num) hlt
    have := intBitLength_natCast_le_succ z.toNat
    omega
  have hi_n := hloc_ib nIdx hbounds.1 hbounds.2.1
  have hi_a := hloc_ib aIdx hbounds.2.2.1 hbounds.2.2.2.1
  have hi_b := hloc_ib bIdx hbounds.2.2.2.2.1 hbounds.2.2.2.2.2.1
  have hi_t := hloc_ib tmpIdx hbounds.2.2.2.2.2.2.1 hbounds.2.2.2.2.2.2.2.1
  have hn1 : natBitLength 1 = 1 := rfl
  have hi0 : intBitLength 0 = 1 := rfl
  have hN_ib := intBitLength_natCast_le_succ N
  let X := L_ab + natBitLength N + 16
  let B_iter := 16 * (X * X)
  have hcnt_N : evalIntExpr inp 1 (wsStep 0) (.readLocal 1 (.lit nIdx)) =
      ((N : ℤ), 2, intBitLength nIdx + 1 + intBitLength nIdx + intBitLength (N : ℤ)) := by
    dsimp only [wsStep, gcdLoopStepWS]
    simp [evalIntExpr, hreadN, hn1]
  have hrep : ExecBounded inp (gcdLoopStmt nIdx aIdx bIdx tmpIdx)
      (wsStep 0) bs (wsStep N) bs
      (2 + 1 + N * 20)
      ((intBitLength nIdx + 1 + intBitLength nIdx + intBitLength (N : ℤ)) + 1 + N * B_iter) C_ar S_ar := by
    refine ExecBounded.repeatN N wsStep (fun _ => bs) (U := 20) (B := B_iter)
      hcnt_N (fun k _ => ?_)
    obtain ⟨ha_k, _, hrA_k, hrB_k, _⟩ := hinv k
    obtain ⟨hb1, hb2⟩ := gcdStep_iter_bounds (a₀ := a₀) (b₀ := b₀) k
    set ak := (gcdStep^[k] (a₀, b₀)).1
    set bk := (gcdStep^[k] (a₀, b₀)).2
    have hib_ak := hib_bound ak hb1
    have hib_bk := hib_bound bk hb2
    have hX16 : 16 ≤ X := by dsimp [X]; omega
    have hXX : 16 * X ≤ X * X := Nat.mul_le_mul_right X hX16
    by_cases hz : bk = 0
    · have hcond : evalBitCond inp 1 (wsStep k) (.intEq (.readLocal 1 (.lit bIdx)) (.lit 0)) =
          (true, 4, intBitLength bIdx + 1 + intBitLength bIdx + intBitLength (bk : ℤ) + 1 + intBitLength (bk : ℤ) + 1) := by
        simp only [evalBitCond, evalIntExpr, hrB_k, hn1, hi0]
        have hbz : ((bk : ℕ) : ℤ) = 0 := by exact_mod_cast hz
        simp [hbz, hi0]
      have hstep_eq : wsStep (k + 1) = wsStep k := by
        dsimp only [wsStep, gcdLoopStepWS]
        exact if_pos hz
      rw [hstep_eq]
      have hite := ExecBounded.ite (tB := .skip)
        (fB := .seq (.writeLocal 1 (.lit tmpIdx) (.mod (.readLocal 1 (.lit aIdx)) (.readLocal 1 (.lit bIdx))))
               (.seq (.writeLocal 1 (.lit aIdx) (.readLocal 1 (.lit bIdx)))
                     (.writeLocal 1 (.lit bIdx) (.readLocal 1 (.lit tmpIdx)))))
        hcond (by simpa using ExecBounded.skip inp (wsStep k) bs C_ar S_ar)
      refine ExecBounded.mono hite (by omega) ?_ le_rfl le_rfl
      dsimp [B_iter]; have : intBitLength (bk : ℤ) ≤ X := by dsimp [X]; omega
      omega
    · have hbk_ne_z : ((bk : ℕ) : ℤ) ≠ 0 := by exact_mod_cast hz
      have hcond : evalBitCond inp 1 (wsStep k) (.intEq (.readLocal 1 (.lit bIdx)) (.lit 0)) =
          (false, 4, intBitLength bIdx + 1 + intBitLength bIdx + intBitLength (bk : ℤ) + 1 + intBitLength (bk : ℤ) + 1) := by
        simp only [evalBitCond, evalIntExpr, hrB_k, hn1, hi0, hbk_ne_z, decide_false]
      have hmod_le : ak % bk ≤ max a₀ b₀ := (Nat.mod_le _ _).trans hb1
      have hib_mod := hib_bound (ak % bk) hmod_le
      have hmod_z : ((ak : ℕ) : ℤ) % ((bk : ℕ) : ℤ) = ((ak % bk : ℕ) : ℤ) := Int.natCast_emod ak bk
      have hib_mod_z : intBitLength (((ak : ℕ) : ℤ) % ((bk : ℕ) : ℤ)) ≤ L_ab := by
        rwa [hmod_z]
      let ws1 := (wsStep k).write (.localFrame 1 1 tmpIdx) ((ak % bk : ℕ) : ℤ)
      let ws2 := ws1.write (.localFrame 1 1 aIdx) (bk : ℤ)
      let ws3 := ws2.write (.localFrame 1 1 bIdx) ((ak % bk : ℕ) : ℤ)
      have ha1 := inAttemptArena_write_local (var := 1) ha_k (by norm_num) hbounds.2.2.2.2.2.2.1 ht_idx_lt (hib_mod.trans hV_ab)
      have ha2 := inAttemptArena_write_local (var := 1) ha1 (by norm_num) hbounds.2.2.1 ha_idx_lt (hib_bk.trans hV_ab)
      have ha3 := inAttemptArena_write_local (var := 1) ha2 (by norm_num) hbounds.2.2.2.2.1 hb_idx_lt (hib_mod.trans hV_ab)
      have hprod_ab : intBitLength (ak : ℤ) * intBitLength (bk : ℤ) ≤ X * X :=
        Nat.mul_le_mul (by dsimp [X]; omega) (by dsimp [X]; omega)
      have hev_g1 : evalIntExpr inp 1 (wsStep k)
          (.mod (.readLocal 1 (.lit aIdx)) (.readLocal 1 (.lit bIdx))) =
          (((ak % bk : ℕ) : ℤ), 5,
           (intBitLength aIdx + 1 + intBitLength aIdx + intBitLength (ak : ℤ)) +
           (intBitLength bIdx + 1 + intBitLength bIdx + intBitLength (bk : ℤ)) +
           intBitLength (ak : ℤ) * intBitLength (bk : ℤ)) := by
        simp only [evalIntExpr, hrA_k, hrB_k, hmod_z, hn1]
      have hw1 : ExecBounded inp
          (.writeLocal 1 (.lit tmpIdx) (.mod (.readLocal 1 (.lit aIdx)) (.readLocal 1 (.lit bIdx))))
          (wsStep k) bs ws1 bs 7 (4 * (X * X)) C_ar S_ar := by
        refine ExecBounded.writeLocal_arena ha1 rfl hev_g1 (by omega) ?_
        dsimp only [RAMCellLoc.bitLength]; rw [hn1]
        have hlin : intBitLength tmpIdx +
            (intBitLength aIdx + 1 + intBitLength aIdx + intBitLength (ak : ℤ) +
              (intBitLength bIdx + 1 + intBitLength bIdx + intBitLength (bk : ℤ))) +
            (1 + 1 + intBitLength tmpIdx) + intBitLength ((ak % bk : ℕ) : ℤ) ≤ 16 * X := by
          dsimp [X]; omega
        omega
      have hrB_1 : ws1.read (.localFrame 1 1 bIdx) = (bk : ℤ) := by
        dsimp [ws1]
        rw [rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hdistinct.2.2.2.2.2 h)]
        exact hrB_k
      have hev_g2 : evalIntExpr inp 1 ws1 (.readLocal 1 (.lit bIdx)) =
          ((bk : ℤ), 2, intBitLength bIdx + 1 + intBitLength bIdx + intBitLength (bk : ℤ)) := by
        simp only [evalIntExpr, hrB_1, hn1]
      have hw2 : ExecBounded inp
          (.writeLocal 1 (.lit aIdx) (.readLocal 1 (.lit bIdx)))
          ws1 bs ws2 bs 4 (2 * (X * X)) C_ar S_ar := by
        refine ExecBounded.writeLocal_arena ha2 rfl hev_g2 (by omega) ?_
        simp only [RAMCellLoc.bitLength, hn1]
        have : intBitLength aIdx + (intBitLength bIdx + 1 + intBitLength bIdx + intBitLength (bk : ℤ)) +
            (1 + 1 + intBitLength aIdx) + intBitLength (bk : ℤ) ≤ 16 * X := by dsimp [X]; omega
        omega
      have hrT_2 : ws2.read (.localFrame 1 1 tmpIdx) = ((ak % bk : ℕ) : ℤ) := by
        dsimp [ws2, ws1]
        rw [rw_read_write_ne (by intro hc; injection hc with _ _ h; exact hdistinct.2.2.2.2.1 h.symm),
          wordStore_read_write_self]
      have hev_g3 : evalIntExpr inp 1 ws2 (.readLocal 1 (.lit tmpIdx)) =
          (((ak % bk : ℕ) : ℤ), 2,
           intBitLength tmpIdx + 1 + intBitLength tmpIdx + intBitLength ((ak % bk : ℕ) : ℤ)) := by
        simp only [evalIntExpr, hrT_2, hn1]
      have hw3 : ExecBounded inp
          (.writeLocal 1 (.lit bIdx) (.readLocal 1 (.lit tmpIdx)))
          ws2 bs ws3 bs 4 (2 * (X * X)) C_ar S_ar := by
        refine ExecBounded.writeLocal_arena ha3 rfl hev_g3 (by omega) ?_
        dsimp only [RAMCellLoc.bitLength]; rw [hn1]
        have : intBitLength bIdx + (intBitLength tmpIdx + 1 + intBitLength tmpIdx + intBitLength ((ak % bk : ℕ) : ℤ)) +
            (1 + 1 + intBitLength bIdx) + intBitLength ((ak % bk : ℕ) : ℤ) ≤ 16 * X := by dsimp [X]; omega
        omega
      have hstep_eq : wsStep (k + 1) = ws3 := by
        dsimp only [wsStep, gcdLoopStepWS, ws3, ws2, ws1]
        exact if_neg hz
      rw [hstep_eq]
      have hite := ExecBounded.ite (tB := .skip) hcond (by simpa using ExecBounded.seq hw1 (ExecBounded.seq hw2 hw3))
      refine ExecBounded.mono hite (by omega) ?_ le_rfl le_rfl
      dsimp [B_iter]
      have : intBitLength bIdx + 1 + intBitLength bIdx + intBitLength (bk : ℤ) + 1 + intBitLength (bk : ℤ) + 1 ≤ 16 * X := by
        dsimp [X]; omega
      omega
  obtain ⟨ha_N, _, hrA_N, hrB_N, hother_N⟩ := hinv N
  refine ⟨wsStep N, ha_N, hrA_N, hrB_N, hother_N, ?_⟩
  refine ExecBounded.mono hrep (by omega) ?_ le_rfl le_rfl
  dsimp [B_iter]
  have hX16 : 16 ≤ X := by dsimp [X]; omega
  have hXX : 16 * X ≤ X * X := Nat.mul_le_mul_right X hX16
  have hinit : intBitLength nIdx + 1 + intBitLength nIdx + intBitLength (N : ℤ) + 1 ≤ 16 * X := by dsimp [X]; omega
  have hgoal_eq : 64 * (N + 1) * (X ^ 2) = 64 * (X * X) + N * (64 * (X * X)) := by rw [sq]; ring
  rw [hgoal_eq]
  have hN_mono : N * (16 * (X * X)) ≤ N * (64 * (X * X)) :=
    Nat.mul_le_mul_left N (Nat.mul_le_mul_right (X * X) (by norm_num))
  omega

end UL.Proof_lem_A_2
