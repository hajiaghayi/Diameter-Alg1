import Mathlib
import UL.Proof.lem_A_2.ExactA_Prob
import UL.Proof.lem_A_2.RacerP54_H3h
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 1600000

namespace UL.Proof_lem_A_2

/-! ### 1. Compact Phase-4 statement combinators and `PreserveOutside4` -/

@[simp] theorem evalCondVal_and {d : ℕ} (inp : BitRAMInput d) (ws : WordStore)
    (c₁ c₂ : BitCondExpr) :
    evalCondVal inp ws (.and c₁ c₂) = (evalCondVal inp ws c₁ && evalCondVal inp ws c₂) := rfl

theorem polyPerm_arith_core (p : CoreParams) {s₁ : ℕ}
    (hs₁ : 2 ≤ s₁) (hs₀_ge : 64 * s₁ ^ 2 ≤ p.s₀) (hm : 2 * p.s₀ ≤ p.m) :
    512 ≤ p.m ∧ 1 ≤ s₁ ∧ s₁ ≤ p.s₀ ∧ p.r * p.s₀ ≤ p.m ∧ 64 * (p.r * s₁ ^ 2) ≤ p.m ∧ p.r * s₁ < p.m ∧
    Nat.Prime (firstPrimeIn (qOfM p.m)) ∧ 26 ≤ firstPrimeIn (qOfM p.m) ∧
    firstPrimeIn (qOfM p.m) < p.m ∧ p.m < firstPrimeIn (qOfM p.m) * firstPrimeIn (qOfM p.m) ∧
    1 ≤ firstQnr (firstPrimeIn (qOfM p.m)) ∧
    firstQnr (firstPrimeIn (qOfM p.m)) < firstPrimeIn (qOfM p.m) ∧
    (∀ z : ZMod (firstPrimeIn (qOfM p.m)),
      z * z ≠ (firstQnr (firstPrimeIn (qOfM p.m)) : ZMod (firstPrimeIn (qOfM p.m)))) :=
  polyPerm_arith hs₁ hs₀_ge hm

def condOkSyntax : BitCondExpr → Bool
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ =>
      exprOkSyntax e₁ && exprOkSyntax e₂ &&
      decide (exprMaxLitAbs e₁ ≤ 64) && decide (exprMaxLitAbs e₂ ≤ 64)
  | .not c => condOkSyntax c
  | .and c₁ c₂ | .or c₁ c₂ => condOkSyntax c₁ && condOkSyntax c₂

theorem condInArena_small {V : ℕ} {c : BitCondExpr}
    (hs : condOkSyntax c = true) (hV : 16 ≤ V) :
    CondInArena V c := by
  induction c with
  | intEq e₁ e₂ | intLt e₁ e₂ | intLe e₁ e₂ =>
      simp only [condOkSyntax, Bool.and_eq_true, decide_eq_true_eq] at hs
      exact ⟨exprInArena_small hs.1.1.1 hs.1.2 hV, exprInArena_small hs.1.1.2 hs.2 hV⟩
  | not c ih => exact ih hs
  | and c₁ c₂ ih₁ ih₂ | or c₁ c₂ ih₁ ih₂ =>
      simp only [condOkSyntax, Bool.and_eq_true] at hs
      exact ⟨ih₁ hs.1, ih₂ hs.2⟩

theorem exec_wl {d A V : ℕ} {inp : BitRAMInput d}
    {ws : WordStore} {bs : List Bool}
    {var : ℕ} {idxE valE : IntExpr} {idx val : ℤ}
    (harena : InAttemptArena A V ws)
    (hinp : ArenaInputOK A V inp)
    (hidx_eq : evalVal inp ws idxE = idx)
    (hval_eq : evalVal inp ws valE = val)
    (hidx0 : 0 ≤ idx) (hidxA : idx.toNat < A)
    (hvalV : intBitLength val ≤ V)
    (hok : decide (var < 100 ∧ exprOkSyntax idxE = true ∧ exprMaxLitAbs idxE ≤ 64 ∧
      exprNodes idxE ≤ 16 ∧ exprOkSyntax valE = true ∧ exprMaxLitAbs valE ≤ 64 ∧
      exprNodes valE ≤ 16) = true := by decide) :
    InAttemptArena A V (ws.write (.localFrame 1 var idx) val) ∧
    ExecBounded inp (.writeLocal var idxE valE) ws bs
      (ws.write (.localFrame 1 var idx) val) bs
      68 (66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have h := of_decide_eq_true hok
  have hV16 : 16 ≤ V := by have := hinp.2.1; omega
  exact exec_writeLocal_auto harena hinp
    (exprInArena_small h.2.1 h.2.2.1 hV16)
    (exprInArena_small h.2.2.2.2.1 h.2.2.2.2.2.1 hV16)
    ⟨h.2.2.2.1, h.2.2.2.2.2.2⟩
    hidx_eq hval_eq h.1 hidx0 hidxA hvalV

theorem exec_wl_reg {d A V : ℕ} {inp : BitRAMInput d}
    {ws : WordStore} {bs : List Bool}
    (var : ℕ) (idx : ℤ) (valE : IntExpr) {val : ℤ}
    (harena : InAttemptArena A V ws)
    (hinp : ArenaInputOK A V inp)
    (hval_eq : evalVal inp ws valE = val)
    (hvalV : intBitLength val ≤ V)
    (hok : decide (var < 100 ∧ 0 ≤ idx ∧ idx < 16 ∧ exprOkSyntax valE = true ∧
      exprMaxLitAbs valE ≤ 64 ∧ exprNodes valE ≤ 16) = true := by decide) :
    InAttemptArena A V (ws.write (.localFrame 1 var idx) val) ∧
    ExecBounded inp (.writeLocal var (.lit idx) valE) ws bs
      (ws.write (.localFrame 1 var idx) val) bs
      68 (66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have h := of_decide_eq_true hok
  have hV16 : 16 ≤ V := by have := hinp.2.1; omega
  have h16A : 16 ≤ A := hinp.1
  have hidx_V : ExprInArena V (.lit idx) :=
    exprInArena_small (e := .lit idx) rfl
      (by dsimp [exprMaxLitAbs]; try omega) hV16
  exact exec_writeLocal_auto harena hinp hidx_V
    (exprInArena_small h.2.2.2.1 h.2.2.2.2.1 hV16)
    ⟨by simp [exprNodes], h.2.2.2.2.2⟩
    rfl hval_eq h.1 h.2.1 (by omega) hvalV

theorem exec_ite_s {d A V : ℕ} {inp : BitRAMInput d}
    {ws₁ ws₂ : WordStore} {bs₁ bs₂ : List Bool}
    {cond : BitCondExpr} (tB fB : BitRAMStmt) {fl : Bool} {ub bb : ℕ}
    (harena : InAttemptArena A V ws₁)
    (hinp : ArenaInputOK A V inp)
    (hc_eq : evalCondVal inp ws₁ cond = fl)
    (hbody : ExecBounded inp (if fl then tB else fB) ws₁ bs₁ ws₂ bs₂
      ub bb (arenaCellCap inp A) (arenaBitCap inp A V))
    (hok : decide (condOkSyntax cond = true ∧ condNodes cond ≤ 16) = true := by decide) :
    ExecBounded inp (.ite cond tB fB) ws₁ bs₁ ws₂ bs₂
      (68 + ub) (66000 * (V + 8) ^ 2 + bb) (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have h := of_decide_eq_true hok
  have hV16 : 16 ≤ V := by have := hinp.2.1; omega
  exact exec_ite_auto harena hinp (condInArena_small h.1 hV16) h.2 hc_eq hbody

theorem exec_skip_s {d A V : ℕ} {inp : BitRAMInput d} (ws : WordStore) (bs : List Bool)
    (hinp : ArenaInputOK A V inp) :
    ExecBounded inp .skip ws bs ws bs
      68 (66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have hV16 : 16 ≤ V := by have := hinp.2.1; omega
  have h1 : 1 ≤ (V + 8) ^ 2 := Nat.one_le_pow 2 _ (by omega)
  exact ExecBounded.mono (ExecBounded.skip inp ws bs _ _)
    (by omega) (by nlinarith) le_rfl le_rfl

theorem ibl_le_V_of_le_four_m_sq {m V : ℕ} (_hm : 2 ≤ m)
    (hwV : 2 * Nat.clog 2 (2 * m) + 32 ≤ V) {x : ℕ} (hx : x ≤ 4 * m * m) :
    intBitLength (x : ℤ) ≤ V := by
  set w := Nat.clog 2 (2 * m)
  have hpow_m : 2 * m ≤ 2 ^ w := Nat.le_pow_clog (by norm_num) (2 * m)
  have hx_lt : x < 2 ^ (2 * w + 1) := by
    calc x ≤ (2 * m) * (2 * m) := by linarith
      _ ≤ (2 ^ w) * (2 ^ w) := Nat.mul_le_mul hpow_m hpow_m
      _ = 2 ^ (2 * w) := by rw [← pow_add, two_mul]
      _ < 2 ^ (2 * w + 1) := Nat.pow_lt_pow_right (by norm_num) (Nat.lt_succ_self _)
  have hnb := natBitLength_le_of_lt_two_pow (by omega : 1 ≤ 2 * w + 1) hx_lt
  have hib := intBitLength_natCast_le_succ x
  omega

theorem ibl_zero_le {V : ℕ} (hV : 16 ≤ V) : intBitLength (0 : ℤ) ≤ V := by
  have : intBitLength (0 : ℤ) = 1 := by decide
  omega

theorem ibl_one_le {V : ℕ} (hV : 16 ≤ V) : intBitLength (1 : ℤ) ≤ V := by
  have : intBitLength (1 : ℤ) = 2 := by decide
  omega

def PreserveOutside4 (ws₀ ws : WordStore) : Prop :=
  (∀ t idx, ws.read (.heap t idx) = ws₀.read (.heap t idx)) ∧
  (∀ v idx, v ≠ 1 → v ≠ 5 → v < 10 → ws.read (.localFrame 1 v idx) = ws₀.read (.localFrame 1 v idx))

theorem preserveOutside4_refl (ws : WordStore) : PreserveOutside4 ws ws :=
  ⟨fun _ _ => rfl, fun _ _ _ _ _ => rfl⟩

theorem PreserveOutside4.trans {ws₀ ws₁ ws₂ : WordStore}
    (h₁ : PreserveOutside4 ws₀ ws₁) (h₂ : PreserveOutside4 ws₁ ws₂) :
    PreserveOutside4 ws₀ ws₂ :=
  ⟨fun t idx => (h₂.1 t idx).trans (h₁.1 t idx),
   fun v idx hv1 hv5 hv10 => (h₂.2 v idx hv1 hv5 hv10).trans (h₁.2 v idx hv1 hv5 hv10)⟩

theorem PreserveOutside4.write_local {ws₀ ws : WordStore}
    (h : PreserveOutside4 ws₀ ws) {var : ℕ} (idx val : ℤ)
    (hvar : var = 1 ∨ var = 5 ∨ 10 ≤ var) :
    PreserveOutside4 ws₀ (ws.write (.localFrame 1 var idx) val) := by
  refine ⟨fun t i => (rw_heap_local ws t i 1 var idx val).trans (h.1 t i),
          fun v i hv1 hv5 hv10 => ?_⟩
  have hne : v ≠ var := by rcases hvar with rfl | rfl | hge <;> omega
  exact (rw_local_var_ne ws hne).trans (h.2 v i hv1 hv5 hv10)

/-! ### 2. Substage A: Compute `s₁`, `2*s₁`, `r*s₁`, `s`, `q`, `p_pr`, `a_qnr`, `p_pr - 1` -/

def HasP4Consts (p : CoreParams) (K₀ deg_α₀ : ℕ) (ws : WordStore) : Prop :=
  let s₁ := s₁Val K₀ deg_α₀ p.d
  let q := qOfM p.m
  let p_pr := firstPrimeIn q
  let a_qnr := firstQnr p_pr
  ws.read (.localFrame 1 10 0) = (s₁ : ℤ) ∧
  ws.read (.localFrame 1 10 1) = ((2 * s₁ : ℕ) : ℤ) ∧
  ws.read (.localFrame 1 10 2) = ((p.r * s₁ : ℕ) : ℤ) ∧
  ws.read (.localFrame 1 10 3) = (Nat.sqrt p.m : ℤ) ∧
  ws.read (.localFrame 1 10 4) = (q : ℤ) ∧
  ws.read (.localFrame 1 10 5) = (p_pr : ℤ) ∧
  ws.read (.localFrame 1 10 6) = (a_qnr : ℤ) ∧
  ws.read (.localFrame 1 10 7) = ((p_pr - 1 : ℕ) : ℤ)

theorem hasP4Consts_of_eq {p : CoreParams} {K₀ deg_α₀ : ℕ} {ws ws' : WordStore}
    (h : HasP4Consts p K₀ deg_α₀ ws)
    (heq : ∀ idx : ℤ, ws'.read (.localFrame 1 10 idx) = ws.read (.localFrame 1 10 idx)) :
    HasP4Consts p K₀ deg_α₀ ws' :=
  ⟨(heq 0).trans h.1,
   (heq 1).trans h.2.1,
   (heq 2).trans h.2.2.1,
   (heq 3).trans h.2.2.2.1,
   (heq 4).trans h.2.2.2.2.1,
   (heq 5).trans h.2.2.2.2.2.1,
   (heq 6).trans h.2.2.2.2.2.2.1,
   (heq 7).trans h.2.2.2.2.2.2.2⟩

def p4SqrtBody : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 0) (.add (.readLocal 10 (.lit 3)) (.lit 1)))
       (.ite (.intLe (.mul (.readLocal 11 (.lit 0)) (.readLocal 11 (.lit 0)))
                     (.readLocal 0 (.lit 2)))
             (.writeLocal 10 (.lit 3) (.readLocal 11 (.lit 0)))
             .skip)

def p4PrimeInnerBody : BitRAMStmt :=
  .seq (.ite (.intEq (.mod (.readLocal 11 (.lit 1))
                           (.add (.readLocal 11 (.lit 4)) (.lit 2)))
                     (.lit 0))
             (.writeLocal 11 (.lit 3) (.lit 0))
             .skip)
       (.writeLocal 11 (.lit 4) (.add (.readLocal 11 (.lit 4)) (.lit 1)))

def p4PrimeOuterBody : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 1)
          (.add (.add (.readLocal 10 (.lit 4)) (.lit 1)) (.readLocal 11 (.lit 0))))
  (.seq (.writeLocal 11 (.lit 2) (.sub (.readLocal 11 (.lit 1)) (.lit 2)))
  (.seq (.writeLocal 11 (.lit 3) (.lit 1))
  (.seq (.writeLocal 11 (.lit 4) (.lit 0))
  (.seq (.repeatN (.readLocal 11 (.lit 2)) p4PrimeInnerBody)
  (.seq (.ite (.and (.intEq (.readLocal 10 (.lit 5)) (.lit 0))
                    (.intEq (.readLocal 11 (.lit 3)) (.lit 1)))
              (.writeLocal 10 (.lit 5) (.readLocal 11 (.lit 1)))
              .skip)
        (.writeLocal 11 (.lit 0) (.add (.readLocal 11 (.lit 0)) (.lit 1))))))))

def p4QnrInnerBody : BitRAMStmt :=
  .seq (.ite (.intEq (.mod (.mul (.readLocal 11 (.lit 3)) (.readLocal 11 (.lit 3)))
                           (.readLocal 10 (.lit 5)))
                     (.readLocal 11 (.lit 1)))
             (.writeLocal 11 (.lit 2) (.lit 0))
             .skip)
       (.writeLocal 11 (.lit 3) (.add (.readLocal 11 (.lit 3)) (.lit 1)))

def p4QnrOuterBody : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 1) (.add (.readLocal 11 (.lit 0)) (.lit 1)))
  (.seq (.writeLocal 11 (.lit 2) (.lit 1))
  (.seq (.writeLocal 11 (.lit 3) (.lit 0))
  (.seq (.repeatN (.readLocal 10 (.lit 5)) p4QnrInnerBody)
  (.seq (.ite (.and (.intEq (.readLocal 10 (.lit 6)) (.lit 0))
                    (.intEq (.readLocal 11 (.lit 2)) (.lit 1)))
              (.writeLocal 10 (.lit 6) (.readLocal 11 (.lit 1)))
              .skip)
        (.writeLocal 11 (.lit 0) (.add (.readLocal 11 (.lit 0)) (.lit 1)))))))

def p4aSetupStmt (K₀ deg_α₀ : ℕ) : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 0) (.add (.readLocal 0 (.lit 0)) (.lit 2)))
  (.seq (powConstStmt 10 0 ((72 * K₀ ^ 3 : ℕ) : ℤ) 1 0 (2 * deg_α₀ + 1))
  (.seq (.writeLocal 10 (.lit 1) (.mul (.lit 2) (.readLocal 10 (.lit 0))))
  (.seq (.writeLocal 10 (.lit 2) (.mul (.readLocal 0 (.lit 6)) (.readLocal 10 (.lit 0))))
  (.seq (.writeLocal 10 (.lit 3) (.lit 0))
  (.seq (.repeatN (.readLocal 0 (.lit 2)) p4SqrtBody)
  (.seq (.writeLocal 10 (.lit 4) (.add (.readLocal 10 (.lit 3)) (.lit 3)))
  (.seq (.writeLocal 10 (.lit 5) (.lit 0))
  (.seq (.writeLocal 11 (.lit 0) (.lit 0))
  (.seq (.repeatN (.readLocal 10 (.lit 4)) p4PrimeOuterBody)
  (.seq (.writeLocal 10 (.lit 7) (.sub (.readLocal 10 (.lit 5)) (.lit 1)))
  (.seq (.writeLocal 10 (.lit 6) (.lit 0))
  (.seq (.writeLocal 11 (.lit 0) (.lit 0))
        (.repeatN (.readLocal 10 (.lit 7)) p4QnrOuterBody)))))))))))))

theorem exec_p4aSetupStmt {A V M K₀ deg_α₀ : ℕ} (p : CoreParams)
    {inp : BitRAMInput p.d} {ws₀ : WordStore} {bs : List Bool}
    (hK₀ : 1 ≤ K₀)
    (hpK : p.K = 25 * K₀ ^ 2)
    (hpdeg : p.deg_α = 2 * deg_α₀ + 1)
    (harena : InAttemptArena A V ws₀)
    (hregs : HasPhase2Regs p M ws₀)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p) :
    ∃ ws₁ : WordStore,
      InAttemptArena A V ws₁ ∧
      PreserveOutside4 ws₀ ws₁ ∧
      HasPhase2Regs p M ws₁ ∧
      HasP4Consts p K₀ deg_α₀ ws₁ ∧
      ExecBounded inp (p4aSetupStmt K₀ deg_α₀) ws₀ bs ws₁ bs
        (2000 + 200 * deg_α₀ + 5000 * p.m)
        ((2000000 + 200000 * deg_α₀ + 5000000 * p.m) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  let s₁ := s₁Val K₀ deg_α₀ p.d
  have hs₁_144 : 144 ≤ s₁ := s₁Val_ge_144 hK₀ p.d
  have hs₁_2 : 2 ≤ s₁ := by omega
  have hs₀_ge : 64 * s₁ ^ 2 ≤ p.s₀ := by
    dsimp [CoreParams.s₀, s₁]; rw [hpK, hpdeg]; exact sixtyFour_s₁Val_sq_le_s₀Val hK₀ p.d
  have hm2s : 2 * p.s₀ ≤ p.m := hfit.2.2.2.1
  obtain ⟨hm512, _, _, hrs, _, hrs1_lt, hp_pr, hp26, hp_lt_m, _, ha1, ha_lt_p, _⟩ :=
    polyPerm_arith_core p hs₁_2 hs₀_ge hm2s
  have hm2 : 2 ≤ p.m := by omega
  have hwV : 2 * p.w + 32 ≤ V := hfit.2.2.2.2.2.2.2.2.1
  have h16A : 16 ≤ A := hinp.1
  have hV16 : 16 ≤ V := by have := hinp.2.1; omega
  have h2s1_lt_m : 2 * s₁ < p.m := by nlinarith
  have hib_2m : ∀ {x : ℕ}, x ≤ 2 * p.m → intBitLength (x : ℤ) ≤ V :=
    fun hx => ibl_le_V_of_le_four_m_sq hm2 hwV (by nlinarith)
  -- 1. `s₁`, `2 * s₁`, `r * s₁`
  have hd2_V : intBitLength (((p.d + 2 : ℕ) : ℤ)) ≤ V := by
    have : p.d + 2 ≤ s₁ := by
      dsimp [s₁, s₁Val]
      calc p.d + 2 = 1 * (p.d + 2) ^ 1 := by ring
        _ ≤ (72 * K₀ ^ 3) * (p.d + 2) ^ (2 * deg_α₀ + 1) :=
            Nat.mul_le_mul (by have := Nat.one_le_pow 3 K₀ hK₀; omega)
              (Nat.pow_le_pow_right (by omega) (by omega))
    exact hib_2m (by omega)
  obtain ⟨ha1, ex1⟩ := exec_wl_reg 1 0 (.add (.readLocal 0 (.lit 0)) (.lit 2)) harena hinp
    (val := ((p.d + 2 : ℕ) : ℤ))
    (by simp [hregs.1.1]; try (push_cast; ring)) hd2_V
  have hp_exp_V : intBitLength (((2 * deg_α₀ + 1 : ℕ) : ℤ)) ≤ V :=
    (intBitLength_natCast_mono (by rw [hpdeg]; omega)).trans hfit.2.2.2.2.2.2.2.2.2.2.1
  have hpow_V : ∀ k ≤ 2 * deg_α₀ + 1,
      intBitLength (((72 * K₀ ^ 3 * (p.d + 2) ^ k : ℕ) : ℤ)) ≤ V := by
    intro k hk
    have hle : 72 * K₀ ^ 3 * (p.d + 2) ^ k ≤ s₁ :=
      Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) hk)
    exact hib_2m (by omega)
  obtain ⟨ha2, ex2⟩ := exec_powConstStmt (inp := inp) (bs := bs)
    (dstVar := 10) (dstIdx := 0) (initVal := 72 * K₀ ^ 3) (baseVar := 1) (baseIdx := 0)
    (2 * deg_α₀ + 1) ha1 hinp
    ⟨by decide, by decide, Or.inl (by decide)⟩
    ⟨by decide, by simp; omega, ibl_zero_le hV16, ibl_zero_le hV16⟩
    (wordStore_read_write_self _ _ _) hp_exp_V hpow_V
  have hs1_eq : (((72 * K₀ ^ 3 * (p.d + 2) ^ (2 * deg_α₀ + 1) : ℕ) : ℤ)) = (s₁ : ℤ) := rfl
  rw [hs1_eq] at ha2 ex2
  have hp2 : PreserveOutside4 ws₀ (wsOf ha2) :=
    (PreserveOutside4.write_local (preserveOutside4_refl ws₀) 0 _ (Or.inl rfl)).write_local
      0 _ (Or.inr (Or.inr (by decide)))
  obtain ⟨ha3, ex3⟩ := exec_wl_reg 10 1 (.mul (.lit 2) (.readLocal 10 (.lit 0))) ha2 hinp
    (val := ((2 * s₁ : ℕ) : ℤ))
    (by simp [wordStore_read_write_self]; try (push_cast; ring))
    (hib_2m (by omega))
  obtain ⟨ha4, ex4⟩ := exec_wl_reg 10 2 (.mul (.readLocal 0 (.lit 6)) (.readLocal 10 (.lit 0))) ha3 hinp
    (val := ((p.r * s₁ : ℕ) : ℤ))
    (by have hr0 : (wsOf ha3).read (.localFrame 1 0 6) = (p.r : ℤ) := by
          rw [rw_local_var_ne _ (by decide)]; exact (hp2.2 0 6 (by decide) (by decide) (by decide)).trans hregs.1.2.2.2.2.2.2.1
        have hr10 : (wsOf ha3).read (.localFrame 1 10 0) = (s₁ : ℤ) := by
          rw [wordStore_read_write_of_ne _ (by decide)]; exact wordStore_read_write_self _ _ _
        dsimp [wsOf] at hr0 hr10
        simp [hr0, hr10]; try (push_cast; ring))
    (hib_2m (by omega))
  obtain ⟨ha5, ex5⟩ := exec_wl_reg 10 3 (.lit 0) ha4 hinp (val := 0) rfl (ibl_zero_le hV16)
  have hp5 : PreserveOutside4 ws₀ (wsOf ha5) :=
    ((hp2.write_local 1 _ (Or.inr (Or.inr (by decide)))).write_local
      2 _ (Or.inr (Or.inr (by decide)))).write_local 3 _ (Or.inr (Or.inr (by decide)))
  -- 2. `sqrt` loop (`p.m` iterations)
  let InvSqrt : ℕ → WordStore → List Bool → Prop := fun k ws_k bs_k =>
    bs_k = bs ∧
    InAttemptArena A V ws_k ∧
    PreserveOutside4 ws₀ ws_k ∧
    ws_k.read (.localFrame 1 10 0) = (s₁ : ℤ) ∧
    ws_k.read (.localFrame 1 10 1) = ((2 * s₁ : ℕ) : ℤ) ∧
    ws_k.read (.localFrame 1 10 2) = ((p.r * s₁ : ℕ) : ℤ) ∧
    ws_k.read (.localFrame 1 10 3) = (sqrtIter p.m k : ℤ)
  have hInvSqrt0 : InvSqrt 0 (wsOf ha5) bs := by
    refine ⟨rfl, ha5, hp5, ?_, ?_, ?_, wordStore_read_write_self _ _ _⟩
    · simp [wsOf, rw_write_eq]
    · simp [wsOf, rw_write_eq]
    · simp [wsOf, rw_write_eq]
  obtain ⟨wsSq, bsSq, hInvSqEnd, ex_sq⟩ := exec_repeatN_inv (bs₀ := bs)
    (U := 204) (B := 198000 * (V + 8) ^ 2)
    (countE := .readLocal 0 (.lit 2)) (body := p4SqrtBody) p.m InvSqrt ha5 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by have hm0 := (hp5.2 0 2 (by decide) (by decide) (by decide)).trans hregs.1.2.2.1
        dsimp [wsOf] at hm0; simp [hm0])
    hInvSqrt0
    (fun k ws_k bs_k hk hInv_k => by
      rcases hInv_k with ⟨hbs, ha_k, hp_k, hr0, hr1, hr2, hr3⟩; subst bs_k
      let sk := sqrtIter p.m k
      have hsk_le : sk ≤ p.m := by dsimp [sk]; rw [sqrtIter_eq_min]; exact (Nat.min_le_right _ _).trans (Nat.sqrt_le_self _)
      obtain ⟨ha_s1, ex_s1⟩ := exec_wl_reg 11 0 (.add (.readLocal 10 (.lit 3)) (.lit 1)) ha_k hinp
        (val := ((sk + 1 : ℕ) : ℤ))
        (by simp [hr3]; try (push_cast; ring))
        (hib_2m (by omega))
      have hm_val : (wsOf ha_s1).read (.localFrame 1 0 2) = (p.m : ℤ) := by
        rw [rw_local_var_ne _ (by decide)]
        exact (hp_k.2 0 2 (by decide) (by decide) (by decide)).trans hregs.1.2.2.1
      have hcond_eq : evalCondVal inp (wsOf ha_s1)
          (.intLe (.mul (.readLocal 11 (.lit 0)) (.readLocal 11 (.lit 0))) (.readLocal 0 (.lit 2))) =
          decide ((sk + 1) * (sk + 1) ≤ p.m) := by
        simp only [evalCondVal_intLe, evalVal_mul, evalVal_readLocal, evalVal_lit,
          wordStore_read_write_self, hm_val]
        exact decide_eq_decide.mpr (by exact_mod_cast Iff.rfl)
      by_cases hle : (sk + 1) * (sk + 1) ≤ p.m
      · obtain ⟨ha_t, ex_t⟩ := exec_wl_reg 10 3 (.readLocal 11 (.lit 0)) ha_s1 hinp
          (val := ((sk + 1 : ℕ) : ℤ))
          (by simp [wordStore_read_write_self])
          (hib_2m (by omega))
        have hc_t : decide ((sk + 1) * (sk + 1) ≤ p.m) = true := decide_eq_true hle
        have ex_ite := exec_ite_s (.writeLocal 10 (.lit 3) (.readLocal 11 (.lit 0))) .skip ha_s1 hinp (hcond_eq.trans hc_t)
          (by simpa [hc_t] using ex_t)
        refine ⟨wsOf ha_t, bs, ⟨rfl, ha_t,
          (hp_k.write_local 0 _ (Or.inr (Or.inr (by decide)))).write_local 3 _ (Or.inr (Or.inr (by decide))),
          by simp [wsOf, rw_write_eq, hr0],
          by simp [wsOf, rw_write_eq, hr1],
          by simp [wsOf, rw_write_eq, hr2],
          by simp [wsOf, sqrtIter, hle, sk, wordStore_read_write_self]⟩,
          ExecBounded.mono (ExecBounded.seq ex_s1 ex_ite) (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩
      · have hc_f : decide ((sk + 1) * (sk + 1) ≤ p.m) = false := decide_eq_false hle
        have ex_ite := exec_ite_s (.writeLocal 10 (.lit 3) (.readLocal 11 (.lit 0))) .skip ha_s1 hinp (hcond_eq.trans hc_f)
          (by simpa [hc_f] using exec_skip_s (wsOf ha_s1) bs hinp)
        refine ⟨wsOf ha_s1, bs, ⟨rfl, ha_s1,
          hp_k.write_local 0 _ (Or.inr (Or.inr (by decide))),
          by simp [wsOf, rw_write_eq, hr0],
          by simp [wsOf, rw_write_eq, hr1],
          by simp [wsOf, rw_write_eq, hr2],
          by simp [wsOf, sqrtIter, hle, sk, rw_write_eq, hr3]⟩,
          ExecBounded.mono (ExecBounded.seq ex_s1 ex_ite) (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩)
  rcases hInvSqEnd with ⟨hbsSq, haSq, hpSq, hs_r0, hs_r1, hs_r2, hs_r3⟩; subst bsSq
  rw [sqrtIter_self] at hs_r3
  let q := qOfM p.m
  obtain ⟨hq25, _, h2q_lt_m, hq2_le_2m⟩ := qOfM_bounds hm512
  obtain ⟨ha_q, ex_q⟩ := exec_wl_reg 10 4 (.add (.readLocal 10 (.lit 3)) (.lit 3)) haSq hinp (val := (q : ℤ))
    (by simp [hs_r3, q, qOfM]; try (push_cast; ring)) (hib_2m (by omega))
  obtain ⟨ha_p0, ex_p0⟩ := exec_wl_reg 10 5 (.lit 0) ha_q hinp (val := 0) rfl (ibl_zero_le hV16)
  obtain ⟨ha_pi0, ex_pi0⟩ := exec_wl_reg 11 0 (.lit 0) ha_p0 hinp (val := 0) rfl (ibl_zero_le hV16)
  have hp_pi0 : PreserveOutside4 ws₀ (wsOf ha_pi0) :=
    ((hpSq.write_local 4 _ (Or.inr (Or.inr (by decide)))).write_local
      5 _ (Or.inr (Or.inr (by decide)))).write_local 0 _ (Or.inr (Or.inr (by decide)))
  -- 3. `firstPrimeIn q` outer loop (`q` iterations, inner `n - 2 ≤ 2 * q` iterations)
  let InvPr : ℕ → WordStore → List Bool → Prop := fun i ws_i bs_i =>
    bs_i = bs ∧
    InAttemptArena A V ws_i ∧
    PreserveOutside4 ws₀ ws_i ∧
    ws_i.read (.localFrame 1 10 0) = (s₁ : ℤ) ∧
    ws_i.read (.localFrame 1 10 1) = ((2 * s₁ : ℕ) : ℤ) ∧
    ws_i.read (.localFrame 1 10 2) = ((p.r * s₁ : ℕ) : ℤ) ∧
    ws_i.read (.localFrame 1 10 3) = (Nat.sqrt p.m : ℤ) ∧
    ws_i.read (.localFrame 1 10 4) = (q : ℤ) ∧
    ws_i.read (.localFrame 1 10 5) = (firstPrimeIter q i : ℤ) ∧
    ws_i.read (.localFrame 1 11 0) = (i : ℤ)
  have hInvPr0 : InvPr 0 (wsOf ha_pi0) bs := by
    refine ⟨rfl, ha_pi0, hp_pi0, ?_, ?_, ?_, ?_, ?_, ?_, wordStore_read_write_self _ _ _⟩
    all_goals simp [wsOf, rw_write_eq, hs_r0, hs_r1, hs_r2, hs_r3, firstPrimeIter]
  obtain ⟨wsPr, bsPr, hInvPrEnd, ex_pr⟩ := exec_repeatN_inv (bs₀ := bs)
    (U := 600 + 408 * q) (B := (600000 + 400000 * q) * (V + 8) ^ 2)
    (countE := .readLocal 10 (.lit 4)) (body := p4PrimeOuterBody) q InvPr ha_pi0 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by simp [wsOf, rw_write_eq])
    hInvPr0
    (fun i ws_i bs_i hi hInv_i => by
      rcases hInv_i with ⟨hbs_i, ha_i, hp_i, hr0, hr1, hr2, hr3, hr4, hr5, hri⟩; subst bs_i
      let n := q + 1 + i
      have hn_le_2q : n ≤ 2 * q := by dsimp [n]; omega
      have hn_ge2 : 2 ≤ n := by dsimp [n]; omega
      obtain ⟨ha_n, ex_n⟩ := exec_wl_reg 11 1 (.add (.add (.readLocal 10 (.lit 4)) (.lit 1)) (.readLocal 11 (.lit 0))) ha_i hinp (val := (n : ℤ))
        (by simp [hr4, hri, n]; try (push_cast; ring)) (hib_2m (by omega))
      obtain ⟨ha_nm2, ex_nm2⟩ := exec_wl_reg 11 2 (.sub (.readLocal 11 (.lit 1)) (.lit 2)) ha_n hinp (val := ((n - 2 : ℕ) : ℤ))
        (by simp [wordStore_read_write_self]; try omega) (hib_2m (by omega))
      obtain ⟨ha_f1, ex_f1⟩ := exec_wl_reg 11 3 (.lit 1) ha_nm2 hinp (val := 1) rfl (ibl_one_le hV16)
      obtain ⟨ha_j0, ex_j0⟩ := exec_wl_reg 11 4 (.lit 0) ha_f1 hinp (val := 0) rfl (ibl_zero_le hV16)
      have hp_j0 : PreserveOutside4 ws₀ (wsOf ha_j0) :=
        (((hp_i.write_local 1 _ (Or.inr (Or.inr (by decide)))).write_local
          2 _ (Or.inr (Or.inr (by decide)))).write_local
          3 _ (Or.inr (Or.inr (by decide)))).write_local 4 _ (Or.inr (Or.inr (by decide)))
      let InvIn : ℕ → WordStore → List Bool → Prop := fun j ws_j bs_j =>
        bs_j = bs ∧
        InAttemptArena A V ws_j ∧
        PreserveOutside4 ws₀ ws_j ∧
        (∀ idx : ℤ, ws_j.read (.localFrame 1 10 idx) = ws_i.read (.localFrame 1 10 idx)) ∧
        ws_j.read (.localFrame 1 11 0) = (i : ℤ) ∧
        ws_j.read (.localFrame 1 11 1) = (n : ℤ) ∧
        ws_j.read (.localFrame 1 11 3) = (primeTrialIter n j : ℤ) ∧
        ws_j.read (.localFrame 1 11 4) = (j : ℤ)
      have hInvIn0 : InvIn 0 (wsOf ha_j0) bs := by
        refine ⟨rfl, ha_j0, hp_j0, fun idx => by simp [wsOf, rw_write_eq],
          by simp [wsOf, rw_write_eq, hri],
          by simp [wsOf, rw_write_eq],
          by simp [wsOf, rw_write_eq, primeTrialIter],
          wordStore_read_write_self _ _ _⟩
      obtain ⟨wsIn, bsIn, hInvInEnd, ex_in⟩ := exec_repeatN_inv (bs₀ := bs)
        (U := 204) (B := 198000 * (V + 8) ^ 2)
        (countE := .readLocal 11 (.lit 2)) (body := p4PrimeInnerBody) (n - 2) InvIn ha_j0 hinp
        (exprInArena_small (by decide) (by decide) hV16) (by decide)
        (by simp [wsOf, rw_write_eq])
        hInvIn0
        (fun j ws_j bs_j hj hInv_j => by
          rcases hInv_j with ⟨hbs_j, ha_j, hp_j, h10_j, h11_0, h11_1, h11_3, h11_4⟩; subst bs_j
          have hc_mod : evalCondVal inp ws_j
              (.intEq (.mod (.readLocal 11 (.lit 1)) (.add (.readLocal 11 (.lit 4)) (.lit 2))) (.lit 0)) =
              decide (n % (j + 2) = 0) := by
            simp only [evalCondVal_intEq, evalVal_mod, evalVal_add, evalVal_readLocal, evalVal_lit,
              h11_1, h11_4]
            have hcast : ((n : ℤ) % ((j : ℤ) + 2)) = (((n % (j + 2) : ℕ) : ℤ)) := by
              have h1 : ((j : ℤ) + 2) = (((j + 2 : ℕ) : ℤ)) := by push_cast; ring
              rw [h1, ← Int.natCast_emod]
            rw [hcast]
            exact decide_eq_decide.mpr (by exact_mod_cast Iff.rfl)
          by_cases hm0 : n % (j + 2) = 0
          · obtain ⟨ha_t, ex_t⟩ := exec_wl_reg 11 3 (.lit 0) ha_j hinp (val := 0) rfl (ibl_zero_le hV16)
            have hc_t : decide (n % (j + 2) = 0) = true := decide_eq_true hm0
            have ex_ite := exec_ite_s (.writeLocal 11 (.lit 3) (.lit 0)) .skip ha_j hinp (hc_mod.trans hc_t) (by simpa [hc_t] using ex_t)
            obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 4 (.add (.readLocal 11 (.lit 4)) (.lit 1)) ha_t hinp (val := ((j + 1 : ℕ) : ℤ))
              (by simp [wsOf, rw_write_eq, h11_4]; try (push_cast; ring)) (hib_2m (by omega))
            refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx,
              (hp_j.write_local 3 _ (Or.inr (Or.inr (by decide)))).write_local 4 _ (Or.inr (Or.inr (by decide))),
              fun idx => by simp [wsOf, rw_write_eq, h10_j],
              by simp [wsOf, rw_write_eq, h11_0],
              by simp [wsOf, rw_write_eq, h11_1],
              by simp [wsOf, rw_write_eq, primeTrialIter, hm0],
              wordStore_read_write_self _ _ _⟩,
              ExecBounded.mono (ExecBounded.seq ex_ite ex_nx) (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩
          · have hc_f : decide (n % (j + 2) = 0) = false := decide_eq_false hm0
            have ex_ite := exec_ite_s (.writeLocal 11 (.lit 3) (.lit 0)) .skip ha_j hinp (hc_mod.trans hc_f)
              (by simpa [hc_f] using exec_skip_s ws_j bs hinp)
            obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 4 (.add (.readLocal 11 (.lit 4)) (.lit 1)) ha_j hinp (val := ((j + 1 : ℕ) : ℤ))
              (by simp [h11_4]; try (push_cast; ring)) (hib_2m (by omega))
            refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx,
              hp_j.write_local 4 _ (Or.inr (Or.inr (by decide))),
              fun idx => by simp [wsOf, rw_write_eq, h10_j],
              by simp [wsOf, rw_write_eq, h11_0],
              by simp [wsOf, rw_write_eq, h11_1],
              by simp [wsOf, rw_write_eq, primeTrialIter, hm0, h11_3],
              wordStore_read_write_self _ _ _⟩,
              ExecBounded.mono (ExecBounded.seq ex_ite ex_nx) (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩)
      rcases hInvInEnd with ⟨hbsIn, ha_in, hp_in, h10_in, h11_0_in, h11_1_in, h11_3_in, _⟩; subst bsIn
      let cur := firstPrimeIter q i
      let flg := primeTrialIter n (n - 2)
      have hc_upd : evalCondVal inp wsIn
          (.and (.intEq (.readLocal 10 (.lit 5)) (.lit 0)) (.intEq (.readLocal 11 (.lit 3)) (.lit 1))) =
          decide (cur = 0 ∧ flg = 1) := by
        simp only [evalCondVal_and, evalCondVal_intEq, evalVal_readLocal, evalVal_lit,
          h10_in 5, hr5, h11_3_in, Bool.decide_and]
        congr 1 <;> exact decide_eq_decide.mpr (by exact_mod_cast Iff.rfl)
      have hite_upd :
          ∃ wsU : WordStore,
            InAttemptArena A V wsU ∧
            PreserveOutside4 ws₀ wsU ∧
            (∀ idx : ℤ, idx ≠ 5 → wsU.read (.localFrame 1 10 idx) = ws_i.read (.localFrame 1 10 idx)) ∧
            wsU.read (.localFrame 1 10 5) = (firstPrimeIter q (i + 1) : ℤ) ∧
            wsU.read (.localFrame 1 11 0) = (i : ℤ) ∧
            ExecBounded inp
              (.ite (.and (.intEq (.readLocal 10 (.lit 5)) (.lit 0))
                          (.intEq (.readLocal 11 (.lit 3)) (.lit 1)))
                    (.writeLocal 10 (.lit 5) (.readLocal 11 (.lit 1)))
                    .skip)
              wsIn bs wsU bs 136 (66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
        by_cases hcond : cur = 0 ∧ flg = 1
        · obtain ⟨ha_u, ex_u⟩ := exec_wl_reg 10 5 (.readLocal 11 (.lit 1)) ha_in hinp (val := (n : ℤ))
            (by simp [h11_1_in]) (hib_2m (by omega))
          have hc_t : decide (cur = 0 ∧ flg = 1) = true := decide_eq_true hcond
          have ex_u_ite := exec_ite_s (.writeLocal 10 (.lit 5) (.readLocal 11 (.lit 1))) .skip ha_in hinp (hc_upd.trans hc_t) (by simpa [hc_t] using ex_u)
          exact ⟨wsOf ha_u, ha_u, hp_in.write_local 5 _ (Or.inr (Or.inr (by decide))),
            fun idx hne => by rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi'; exact hne hi')]; exact h10_in idx,
            by rw [wordStore_read_write_self]; unfold firstPrimeIter; dsimp only; rw [if_pos hcond],
            by simp [wsOf, rw_write_eq, h11_0_in],
            ex_u_ite⟩
        · have hc_f : decide (cur = 0 ∧ flg = 1) = false := decide_eq_false hcond
          have ex_u_ite := exec_ite_s (.writeLocal 10 (.lit 5) (.readLocal 11 (.lit 1))) .skip ha_in hinp (hc_upd.trans hc_f)
            (by simpa [hc_f] using exec_skip_s wsIn bs hinp)
          exact ⟨wsIn, ha_in, hp_in,
            fun idx _ => h10_in idx,
            by have hfp : firstPrimeIter q (i + 1) = cur := if_neg hcond; rw [h10_in 5, hr5, hfp],
            h11_0_in,
            ex_u_ite⟩
      obtain ⟨wsU, haU, hpU, h10U, hr5U, hriU, ex_upd⟩ := hite_upd
      obtain ⟨ha_inc, ex_inc⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) haU hinp (val := ((i + 1 : ℕ) : ℤ))
        (by simp [hriU]; try (push_cast; ring)) (hib_2m (by omega))
      have hnm2_le : n - 2 ≤ 2 * q := by omega
      have hu_in : 68 + (n - 2) * 204 ≤ 68 + (2 * q) * 204 :=
        Nat.add_le_add_left (Nat.mul_le_mul_right 204 hnm2_le) 68
      have hb_in : 66000 * (V + 8) ^ 2 + (n - 2) * (198000 * (V + 8) ^ 2) ≤
          (66000 + 396000 * q) * (V + 8) ^ 2 := by
        simp only [← Nat.mul_assoc, ← Nat.add_mul]
        apply Nat.mul_le_mul_right
        omega
      have ex_step :=
        ExecBounded.seq ex_n (ExecBounded.seq ex_nm2 (ExecBounded.seq ex_f1
        (ExecBounded.seq ex_j0 (ExecBounded.seq
          (ExecBounded.mono ex_in hu_in hb_in le_rfl le_rfl)
          (ExecBounded.seq ex_upd ex_inc)))))
      refine ⟨wsOf ha_inc, bs, ⟨rfl, ha_inc,
        hpU.write_local 0 _ (Or.inr (Or.inr (by decide))),
        by rw [rw_local_var_ne _ (by decide), h10U 0 (by decide), hr0],
        by rw [rw_local_var_ne _ (by decide), h10U 1 (by decide), hr1],
        by rw [rw_local_var_ne _ (by decide), h10U 2 (by decide), hr2],
        by rw [rw_local_var_ne _ (by decide), h10U 3 (by decide), hr3],
        by rw [rw_local_var_ne _ (by decide), h10U 4 (by decide), hr4],
        by rw [rw_local_var_ne _ (by decide), hr5U],
        wordStore_read_write_self _ _ _⟩,
        ExecBounded.mono ex_step (by omega) ?_ le_rfl le_rfl⟩
      simp only [← Nat.mul_assoc, ← Nat.add_mul]
      apply Nat.mul_le_mul_right
      omega)
  rcases hInvPrEnd with ⟨hbsPr, haPr, hpPr, hp_r0, hp_r1, hp_r2, hp_r3, hp_r4, hp_r5, _⟩; subst bsPr
  let p_pr := firstPrimeIn q
  have hp_r5' : wsPr.read (.localFrame 1 10 5) = (p_pr : ℤ) := hp_r5
  obtain ⟨_, _, hp_le_2q_raw, hp26_raw⟩ := firstPrimeIn_spec hq25
  have hp_pr_26 : 26 ≤ p_pr := hp26_raw
  have hp_pr_le_2q : p_pr ≤ 2 * q := hp_le_2q_raw
  have hp_pr_lt_m : p_pr < p.m := hp_lt_m
  -- 4. `firstQnr p_pr` outer loop (`p_pr - 1` iterations, inner `p_pr` iterations)
  obtain ⟨ha_pm1, ex_pm1⟩ := exec_wl_reg 10 7 (.sub (.readLocal 10 (.lit 5)) (.lit 1)) haPr hinp (val := ((p_pr - 1 : ℕ) : ℤ))
    (by simp [hp_r5']; try omega) (hib_2m (by omega))
  obtain ⟨ha_a0, ex_a0⟩ := exec_wl_reg 10 6 (.lit 0) ha_pm1 hinp (val := 0) rfl (ibl_zero_le hV16)
  obtain ⟨ha_qi0, ex_qi0⟩ := exec_wl_reg 11 0 (.lit 0) ha_a0 hinp (val := 0) rfl (ibl_zero_le hV16)
  have hp_qi0 : PreserveOutside4 ws₀ (wsOf ha_qi0) :=
    ((hpPr.write_local 7 _ (Or.inr (Or.inr (by decide)))).write_local
      6 _ (Or.inr (Or.inr (by decide)))).write_local 0 _ (Or.inr (Or.inr (by decide)))
  let InvQn : ℕ → WordStore → List Bool → Prop := fun i ws_i bs_i =>
    bs_i = bs ∧
    InAttemptArena A V ws_i ∧
    PreserveOutside4 ws₀ ws_i ∧
    ws_i.read (.localFrame 1 10 0) = (s₁ : ℤ) ∧
    ws_i.read (.localFrame 1 10 1) = ((2 * s₁ : ℕ) : ℤ) ∧
    ws_i.read (.localFrame 1 10 2) = ((p.r * s₁ : ℕ) : ℤ) ∧
    ws_i.read (.localFrame 1 10 3) = (Nat.sqrt p.m : ℤ) ∧
    ws_i.read (.localFrame 1 10 4) = (q : ℤ) ∧
    ws_i.read (.localFrame 1 10 5) = (p_pr : ℤ) ∧
    ws_i.read (.localFrame 1 10 6) = (firstQnrIter p_pr i : ℤ) ∧
    ws_i.read (.localFrame 1 10 7) = ((p_pr - 1 : ℕ) : ℤ) ∧
    ws_i.read (.localFrame 1 11 0) = (i : ℤ)
  have hInvQn0 : InvQn 0 (wsOf ha_qi0) bs := by
    refine ⟨rfl, ha_qi0, hp_qi0, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, wordStore_read_write_self _ _ _⟩
    all_goals simp [wsOf, rw_write_eq, hp_r0, hp_r1, hp_r2, hp_r3, hp_r4, hp_r5', firstQnrIter]
  obtain ⟨wsQn, bsQn, hInvQnEnd, ex_qn⟩ := exec_repeatN_inv (bs₀ := bs)
    (U := 600 + 204 * p_pr) (B := (600000 + 198000 * p_pr) * (V + 8) ^ 2)
    (countE := .readLocal 10 (.lit 7)) (body := p4QnrOuterBody) (p_pr - 1) InvQn ha_qi0 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by simp [wsOf, rw_write_eq])
    hInvQn0
    (fun i ws_i bs_i hi hInv_i => by
      rcases hInv_i with ⟨hbs_i, ha_i, hp_i, hr0, hr1, hr2, hr3, hr4, hr5, hr6, hr7, hri⟩; subst bs_i
      let cand := i + 1
      obtain ⟨ha_c, ex_c⟩ := exec_wl_reg 11 1 (.add (.readLocal 11 (.lit 0)) (.lit 1)) ha_i hinp (val := (cand : ℤ))
        (by simp [hri, cand]; try (push_cast; ring)) (hib_2m (by omega))
      obtain ⟨ha_f1, ex_f1⟩ := exec_wl_reg 11 2 (.lit 1) ha_c hinp (val := 1) rfl (ibl_one_le hV16)
      obtain ⟨ha_x0, ex_x0⟩ := exec_wl_reg 11 3 (.lit 0) ha_f1 hinp (val := 0) rfl (ibl_zero_le hV16)
      have hp_x0 : PreserveOutside4 ws₀ (wsOf ha_x0) :=
        ((hp_i.write_local 1 _ (Or.inr (Or.inr (by decide)))).write_local
          2 _ (Or.inr (Or.inr (by decide)))).write_local 3 _ (Or.inr (Or.inr (by decide)))
      let InvQIn : ℕ → WordStore → List Bool → Prop := fun x ws_x bs_x =>
        bs_x = bs ∧
        InAttemptArena A V ws_x ∧
        PreserveOutside4 ws₀ ws_x ∧
        (∀ idx : ℤ, ws_x.read (.localFrame 1 10 idx) = ws_i.read (.localFrame 1 10 idx)) ∧
        ws_x.read (.localFrame 1 11 0) = (i : ℤ) ∧
        ws_x.read (.localFrame 1 11 1) = (cand : ℤ) ∧
        ws_x.read (.localFrame 1 11 2) = (qnrTrialIter p_pr cand x : ℤ) ∧
        ws_x.read (.localFrame 1 11 3) = (x : ℤ)
      have hInvQIn0 : InvQIn 0 (wsOf ha_x0) bs := by
        refine ⟨rfl, ha_x0, hp_x0, fun idx => by simp [wsOf, rw_write_eq],
          by simp [wsOf, rw_write_eq, hri],
          by simp [wsOf, rw_write_eq],
          by simp [wsOf, rw_write_eq, qnrTrialIter],
          wordStore_read_write_self _ _ _⟩
      obtain ⟨wsQIn, bsQIn, hInvQInEnd, ex_qin⟩ := exec_repeatN_inv (bs₀ := bs)
        (U := 204) (B := 198000 * (V + 8) ^ 2)
        (countE := .readLocal 10 (.lit 5)) (body := p4QnrInnerBody) p_pr InvQIn ha_x0 hinp
        (exprInArena_small (by decide) (by decide) hV16) (by decide)
        (by simp [wsOf, rw_write_eq, hr5])
        hInvQIn0
        (fun x ws_x bs_x hx hInv_x => by
          rcases hInv_x with ⟨hbs_x, ha_x, hp_x, h10_x, h11_0, h11_1, h11_2, h11_3⟩; subst bs_x
          have hc_sq : evalCondVal inp ws_x
              (.intEq (.mod (.mul (.readLocal 11 (.lit 3)) (.readLocal 11 (.lit 3)))
                            (.readLocal 10 (.lit 5)))
                      (.readLocal 11 (.lit 1))) =
              decide ((x * x) % p_pr = cand) := by
            simp only [evalCondVal_intEq, evalVal_mod, evalVal_mul, evalVal_readLocal, evalVal_lit,
              h11_3, h10_x 5, hr5, h11_1]
            have hcast : (((x : ℤ) * (x : ℤ)) % (p_pr : ℤ)) = ((((x * x) % p_pr : ℕ) : ℤ)) := by
              have h1 : (x : ℤ) * (x : ℤ) = (((x * x : ℕ) : ℤ)) := by push_cast; ring
              rw [h1, ← Int.natCast_emod]
            rw [hcast]
            exact decide_eq_decide.mpr (by exact_mod_cast Iff.rfl)
          by_cases hsq : (x * x) % p_pr = cand
          · obtain ⟨ha_t, ex_t⟩ := exec_wl_reg 11 2 (.lit 0) ha_x hinp (val := 0) rfl (ibl_zero_le hV16)
            have hc_t : decide ((x * x) % p_pr = cand) = true := decide_eq_true hsq
            have ex_ite := exec_ite_s (.writeLocal 11 (.lit 2) (.lit 0)) .skip ha_x hinp (hc_sq.trans hc_t) (by simpa [hc_t] using ex_t)
            obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 3 (.add (.readLocal 11 (.lit 3)) (.lit 1)) ha_t hinp (val := ((x + 1 : ℕ) : ℤ))
              (by simp [wsOf, rw_write_eq, h11_3]; try (push_cast; ring)) (hib_2m (by omega))
            refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx,
              (hp_x.write_local 2 _ (Or.inr (Or.inr (by decide)))).write_local 3 _ (Or.inr (Or.inr (by decide))),
              fun idx => by simp [wsOf, rw_write_eq, h10_x],
              by simp [wsOf, rw_write_eq, h11_0],
              by simp [wsOf, rw_write_eq, h11_1],
              by simp [wsOf, rw_write_eq, qnrTrialIter, hsq],
              wordStore_read_write_self _ _ _⟩,
              ExecBounded.mono (ExecBounded.seq ex_ite ex_nx) (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩
          · have hc_f : decide ((x * x) % p_pr = cand) = false := decide_eq_false hsq
            have ex_ite := exec_ite_s (.writeLocal 11 (.lit 2) (.lit 0)) .skip ha_x hinp (hc_sq.trans hc_f)
              (by simpa [hc_f] using exec_skip_s ws_x bs hinp)
            obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 3 (.add (.readLocal 11 (.lit 3)) (.lit 1)) ha_x hinp (val := ((x + 1 : ℕ) : ℤ))
              (by simp [h11_3]; try (push_cast; ring)) (hib_2m (by omega))
            refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx,
              hp_x.write_local 3 _ (Or.inr (Or.inr (by decide))),
              fun idx => by simp [wsOf, rw_write_eq, h10_x],
              by simp [wsOf, rw_write_eq, h11_0],
              by simp [wsOf, rw_write_eq, h11_1],
              by simp [wsOf, rw_write_eq, qnrTrialIter, hsq, h11_2],
              wordStore_read_write_self _ _ _⟩,
              ExecBounded.mono (ExecBounded.seq ex_ite ex_nx) (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩)
      rcases hInvQInEnd with ⟨hbsQIn, ha_qin, hp_qin, h10_qin, h11_0_qin, h11_1_qin, h11_2_qin, _⟩; subst bsQIn
      let cur := firstQnrIter p_pr i
      let flg := qnrTrialIter p_pr cand p_pr
      have hc_upd : evalCondVal inp wsQIn
          (.and (.intEq (.readLocal 10 (.lit 6)) (.lit 0)) (.intEq (.readLocal 11 (.lit 2)) (.lit 1))) =
          decide (cur = 0 ∧ flg = 1) := by
        simp only [evalCondVal_and, evalCondVal_intEq, evalVal_readLocal, evalVal_lit,
          h10_qin 6, hr6, h11_2_qin, Bool.decide_and]
        congr 1 <;> exact decide_eq_decide.mpr (by exact_mod_cast Iff.rfl)
      have hite_upd :
          ∃ wsU : WordStore,
            InAttemptArena A V wsU ∧
            PreserveOutside4 ws₀ wsU ∧
            (∀ idx : ℤ, idx ≠ 6 → wsU.read (.localFrame 1 10 idx) = ws_i.read (.localFrame 1 10 idx)) ∧
            wsU.read (.localFrame 1 10 6) = (firstQnrIter p_pr (i + 1) : ℤ) ∧
            wsU.read (.localFrame 1 11 0) = (i : ℤ) ∧
            ExecBounded inp
              (.ite (.and (.intEq (.readLocal 10 (.lit 6)) (.lit 0))
                          (.intEq (.readLocal 11 (.lit 2)) (.lit 1)))
                    (.writeLocal 10 (.lit 6) (.readLocal 11 (.lit 1)))
                    .skip)
              wsQIn bs wsU bs 136 (66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
        by_cases hcond : cur = 0 ∧ flg = 1
        · obtain ⟨ha_u, ex_u⟩ := exec_wl_reg 10 6 (.readLocal 11 (.lit 1)) ha_qin hinp (val := (cand : ℤ))
            (by simp [h11_1_qin]) (hib_2m (by omega))
          have hc_t : decide (cur = 0 ∧ flg = 1) = true := decide_eq_true hcond
          have ex_u_ite := exec_ite_s (.writeLocal 10 (.lit 6) (.readLocal 11 (.lit 1))) .skip ha_qin hinp (hc_upd.trans hc_t) (by simpa [hc_t] using ex_u)
          exact ⟨wsOf ha_u, ha_u, hp_qin.write_local 6 _ (Or.inr (Or.inr (by decide))),
            fun idx hne => by rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi'; exact hne hi')]; exact h10_qin idx,
            by rw [wordStore_read_write_self]; unfold firstQnrIter; dsimp only; rw [if_pos hcond],
            by simp [wsOf, rw_write_eq, h11_0_qin],
            ex_u_ite⟩
        · have hc_f : decide (cur = 0 ∧ flg = 1) = false := decide_eq_false hcond
          have ex_u_ite := exec_ite_s (.writeLocal 10 (.lit 6) (.readLocal 11 (.lit 1))) .skip ha_qin hinp (hc_upd.trans hc_f)
            (by simpa [hc_f] using exec_skip_s wsQIn bs hinp)
          exact ⟨wsQIn, ha_qin, hp_qin,
            fun idx _ => h10_qin idx,
            by have hfq : firstQnrIter p_pr (i + 1) = cur := if_neg hcond; rw [h10_qin 6, hr6, hfq],
            h11_0_qin,
            ex_u_ite⟩
      obtain ⟨wsU, haU, hpU, h10U, hr6U, hriU, ex_upd⟩ := hite_upd
      obtain ⟨ha_inc, ex_inc⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) haU hinp (val := ((i + 1 : ℕ) : ℤ))
        (by simp [hriU]; try (push_cast; ring)) (hib_2m (by omega))
      have ex_step :=
        ExecBounded.seq ex_c (ExecBounded.seq ex_f1 (ExecBounded.seq ex_x0
        (ExecBounded.seq ex_qin (ExecBounded.seq ex_upd ex_inc))))
      refine ⟨wsOf ha_inc, bs, ⟨rfl, ha_inc,
        hpU.write_local 0 _ (Or.inr (Or.inr (by decide))),
        by rw [rw_local_var_ne _ (by decide), h10U 0 (by decide), hr0],
        by rw [rw_local_var_ne _ (by decide), h10U 1 (by decide), hr1],
        by rw [rw_local_var_ne _ (by decide), h10U 2 (by decide), hr2],
        by rw [rw_local_var_ne _ (by decide), h10U 3 (by decide), hr3],
        by rw [rw_local_var_ne _ (by decide), h10U 4 (by decide), hr4],
        by rw [rw_local_var_ne _ (by decide), h10U 5 (by decide), hr5],
        by rw [rw_local_var_ne _ (by decide), hr6U],
        by rw [rw_local_var_ne _ (by decide), h10U 7 (by decide), hr7],
        wordStore_read_write_self _ _ _⟩,
        ExecBounded.mono ex_step
          (show _ ≤ 600 + 204 * p_pr by omega)
          (show _ ≤ (600000 + 198000 * p_pr) * (V + 8) ^ 2 by simp only [← Nat.mul_assoc, ← Nat.add_mul]; apply Nat.mul_le_mul_right; omega)
          le_rfl le_rfl⟩)
  rcases hInvQnEnd with ⟨hbsQn, haQn, hpQn, hq_r0, hq_r1, hq_r2, hq_r3, hq_r4, hq_r5, hq_r6, hq_r7, _⟩; subst bsQn
  have hex_all :=
    ExecBounded.seq ex1 (ExecBounded.seq ex2 (ExecBounded.seq ex3 (ExecBounded.seq ex4
    (ExecBounded.seq ex5 (ExecBounded.seq ex_sq (ExecBounded.seq ex_q (ExecBounded.seq ex_p0
    (ExecBounded.seq ex_pi0 (ExecBounded.seq ex_pr (ExecBounded.seq ex_pm1
    (ExecBounded.seq ex_a0 (ExecBounded.seq ex_qi0 ex_qn))))))))))))
  have hregs_end : HasPhase2Regs p M wsQn :=
    hasPhase2Regs_of_eq hregs (fun idx => hpQn.2 0 idx (by decide) (by decide) (by decide))
  refine ⟨wsQn, haQn, hpQn, hregs_end,
    ⟨hq_r0, hq_r1, hq_r2, hq_r3, hq_r4, hq_r5, hq_r6, hq_r7⟩,
    ExecBounded.mono hex_all ?_ ?_ le_rfl le_rfl⟩
  · -- Unit cost ≤ 2000 + 200 * deg_α₀ + 5000 * p.m
    have h2q : 2 * q < p.m := h2q_lt_m
    have hqq : q * q ≤ 2 * p.m := by simpa [sq, q] using hq2_le_2m
    have hpr_u : q * (600 + 408 * q) ≤ 1200 * p.m := by
      have : q * (600 + 408 * q) = 600 * q + 408 * (q * q) := by ring
      omega
    have hqn_u : (p_pr - 1) * (600 + 204 * p_pr) ≤ 3000 * p.m := by
      calc (p_pr - 1) * (600 + 204 * p_pr)
          ≤ (2 * q) * (600 + 204 * (2 * q)) := Nat.mul_le_mul (by omega) (by omega)
        _ = 1200 * q + 816 * (q * q) := by ring
        _ ≤ 3000 * p.m := by omega
    omega
  · -- Bit cost ≤ (2000000 + 200000 * deg_α₀ + 5000000 * p.m) * (V + 8) ^ 2
    simp only [← Nat.mul_assoc, ← Nat.add_mul]
    apply Nat.mul_le_mul_right
    have h2q : 2 * q < p.m := h2q_lt_m
    have hqq : q * q ≤ 2 * p.m := by simpa [sq, q] using hq2_le_2m
    have hpr_b : q * (600000 + 400000 * q) ≤ 1200000 * p.m := by
      have : q * (600000 + 400000 * q) = 600000 * q + 400000 * (q * q) := by ring
      omega
    have hqn_b : (p_pr - 1) * (600000 + 198000 * p_pr) ≤ 3000000 * p.m := by
      calc (p_pr - 1) * (600000 + 198000 * p_pr)
          ≤ (2 * q) * (600000 + 198000 * (2 * q)) := Nat.mul_le_mul (by omega) (by omega)
        _ = 1200000 * q + 792000 * (q * q) := by ring
        _ ≤ 3000000 * p.m := by omega
    omega

end UL.Proof_lem_A_2
