import Mathlib
import UL.Proof.lem_A_2.RacerP42_H2d
import UL.Proof.lem_A_2.RacerP42_H3a
set_option autoImplicit false
set_option maxHeartbeats 1000000

namespace UL.Proof_lem_A_2

/-! ### 1. Basic `WordStore` and `runBitRAMFuel` invariants for subroutine extraction -/

theorem wordStore_free_write_self (ws : WordStore) (loc : RAMCellLoc) (val : ℤ) :
    (ws.write loc val).free loc = ws.free loc := by
  unfold WordStore.free WordStore.write
  congr 1
  · ext x; simp only [Finset.mem_erase, Finset.mem_insert]; tauto
  · funext x
    by_cases hx : x = loc
    · subst hx; simp
    · simp [Function.update_of_ne hx]

theorem simMergeStore_read_local1 {T_max : ℕ} {wsBase wsSub : WordStore}
    (hT : 1 ≤ T_max) (log : List ℤ) (var : ℕ) (idx : ℤ) :
    (simMergeStore wsBase T_max hT wsSub log).read (.localFrame 1 var idx) =
      wsBase.read (.localFrame 1 var idx) := by
  have hnot_sub : RAMCellLoc.localFrame 1 var idx ∉ wsSub.live.map (shiftSubEmb T_max hT) := by
    simp only [Finset.mem_map, shiftSubEmb, Function.Embedding.coeFn_mk, not_exists, not_and]
    intro u _ hc
    cases u with
    | heap _ _ => dsimp [shiftSubLoc] at hc; split_ifs at hc <;> nomatch hc
    | localFrame _ _ _ => dsimp [shiftSubLoc] at hc; injection hc with hd _ _; omega
  have hnot_log : RAMCellLoc.localFrame 1 var idx ∉ logLiveFinset log := by
    intro hm
    simp only [logLiveFinset, Finset.mem_insert, Finset.mem_map, heap11Emb,
      Function.Embedding.coeFn_mk] at hm
    rcases hm with h | ⟨_, _, h⟩ <;> nomatch h
  have hmem_iff : RAMCellLoc.localFrame 1 var idx ∈
      (simMergeStore wsBase T_max hT wsSub log).live ↔
      RAMCellLoc.localFrame 1 var idx ∈ wsBase.live := by
    dsimp [simMergeStore]
    simp only [Finset.mem_union, hnot_sub, hnot_log, or_false]
  unfold WordStore.read
  by_cases hm : RAMCellLoc.localFrame 1 var idx ∈ wsBase.live
  · rw [if_pos (hmem_iff.mpr hm), if_pos hm]
    rfl
  · rw [if_neg (mt hmem_iff.mp hm), if_neg hm]

theorem simMergeStore_read_heap10_of_base {T_max : ℕ} {wsBase wsBase' wsSub : WordStore}
    (hb : IsSimBaseStore wsBase) (hb' : IsSimBaseStore wsBase')
    (hT : 1 ≤ T_max) (log : List ℤ) (enc : ℤ) :
    (simMergeStore wsBase' T_max hT wsSub log).read (.heap 10 enc) =
      (simMergeStore wsBase T_max hT wsSub log).read (.heap 10 enc) := by
  have hnot1 : RAMCellLoc.heap 10 enc ∉ wsBase.live := by
    intro hm
    rcases hb.2 _ hm with ⟨t, _, ht8, hc⟩ | ⟨_, _, hc⟩
    · injection hc with ht _; omega
    · nomatch hc
  have hnot2 : RAMCellLoc.heap 10 enc ∉ wsBase'.live := by
    intro hm
    rcases hb'.2 _ hm with ⟨t, _, ht8, hc⟩ | ⟨_, _, hc⟩
    · injection hc with ht _; omega
    · nomatch hc
  have hlive_eq :
      (RAMCellLoc.heap 10 enc ∈ (simMergeStore wsBase' T_max hT wsSub log).live) ↔
      (RAMCellLoc.heap 10 enc ∈ (simMergeStore wsBase T_max hT wsSub log).live) := by
    dsimp [simMergeStore]
    simp only [Finset.mem_union, hnot1, hnot2, false_or]
  have hval_eq :
      (simMergeStore wsBase' T_max hT wsSub log).vals (.heap 10 enc) =
      (simMergeStore wsBase T_max hT wsSub log).vals (.heap 10 enc) := by
    dsimp [simMergeStore, simMergeVals]
  unfold WordStore.read
  by_cases hm : RAMCellLoc.heap 10 enc ∈ (simMergeStore wsBase T_max hT wsSub log).live
  · rw [if_pos (hlive_eq.mpr hm), if_pos hm, hval_eq]
  · rw [if_neg (mt hlive_eq.mp hm), if_neg hm]

theorem runBitRAMFuel_words_le_peak {d : ℕ} {inp : BitRAMInput d} :
    ∀ (fuel : ℕ) (stack : List BitRAMCont) (st : BitRAMExecState) (out : BitRAMExecOutcome),
      inp.inputCellSpace + st.words.cellCount ≤ st.peakCellSpace →
      inp.inputBitSpace + st.words.bitSize ≤ st.peakBitSpace →
      runBitRAMFuel inp fuel stack st = .halted out →
      out.words.cellCount ≤ out.peakCellSpace ∧
      out.words.bitSize ≤ out.peakBitSpace := by
  intro fuel
  induction fuel with
  | zero =>
      intro stack st out hpc hpb hrun
      cases stack with
      | nil =>
          simp only [runBitRAMFuel] at hrun
          split_ifs at hrun
          injection hrun with hout; subst hout
          have hc := cellCount_popDepth_le st.words 0
          have hb := bitSize_popDepth_le st.words 0
          dsimp only
          exact ⟨by omega, by omega⟩
      | cons _ _ => simp [runBitRAMFuel] at hrun
  | succ fuel ih =>
      intro stack st out hpc hpb hrun
      cases stack with
      | nil =>
          simp only [runBitRAMFuel] at hrun
          split_ifs at hrun
          injection hrun with hout; subst hout
          have hc := cellCount_popDepth_le st.words 0
          have hb := bitSize_popDepth_le st.words 0
          dsimp only
          exact ⟨by omega, by omega⟩
      | cons item rest =>
          cases item with
          | popScope prev =>
              simp only [runBitRAMFuel] at hrun
              have hc := cellCount_popDepth_le st.words prev
              have hb := bitSize_popDepth_le st.words prev
              exact ih rest _ out (by dsimp; omega) (by dsimp; omega) hrun
          | repeatLoop rem body =>
              cases rem <;> (simp only [runBitRAMFuel] at hrun; exact ih _ _ out hpc hpb hrun)
          | stmt s =>
              cases s with
              | skip =>
                  simp only [runBitRAMFuel] at hrun
                  exact ih rest _ out (by dsimp; omega) (by dsimp; omega) hrun
              | seq s₁ s₂ =>
                  simp only [runBitRAMFuel] at hrun
                  exact ih _ _ out hpc hpb hrun
              | localScope body =>
                  simp only [runBitRAMFuel] at hrun
                  have hc := cellCount_popDepth_le st.words st.frameDepth
                  have hb := bitSize_popDepth_le st.words st.frameDepth
                  exact ih _ _ out (by dsimp; omega) (by dsimp; omega) hrun
              | writeHeap _ _ _ | writeLocal _ _ _ =>
                  simp only [runBitRAMFuel] at hrun
                  exact ih rest _ out (le_max_right _ _) (le_max_right _ _) hrun
              | freeHeap table idxE =>
                  simp only [runBitRAMFuel] at hrun
                  rcases he : evalIntExpr inp st.frameDepth st.words idxE with ⟨idx, u, b⟩
                  rw [he] at hrun
                  have hc := cellCount_free_le st.words (.heap table idx)
                  have hb := bitSize_free_le st.words (.heap table idx)
                  exact ih rest _ out (by dsimp; omega) (by dsimp; omega) hrun
              | freeLocal var idxE =>
                  simp only [runBitRAMFuel] at hrun
                  rcases he : evalIntExpr inp st.frameDepth st.words idxE with ⟨idx, u, b⟩
                  rw [he] at hrun
                  have hc := cellCount_free_le st.words (.localFrame st.frameDepth var idx)
                  have hb := bitSize_free_le st.words (.localFrame st.frameDepth var idx)
                  exact ih rest _ out (by dsimp; omega) (by dsimp; omega) hrun
              | randBitHeap _ _ | randBitLocal _ _ =>
                  simp only [runBitRAMFuel] at hrun
                  cases hrb : st.remainingBits with
                  | nil => rw [hrb] at hrun; simp at hrun
                  | cons _ _ =>
                      rw [hrb] at hrun
                      dsimp only at hrun
                      exact ih rest _ out (le_max_right _ _) (le_max_right _ _) hrun
              | ite _ _ _ | whileLoop _ _ | repeatN _ _ =>
                  simp only [runBitRAMFuel] at hrun
                  exact ih _ _ out (by dsimp; omega) (by dsimp; omega) hrun

theorem outSub_words_le_peak {d : ℕ} {prog : BitRAMStmt} {inp : BitRAMInput d}
    {out : BitRAMExecOutcome}
    (hrun : runBitRAMWithBits prog inp WordStore.empty [] = some out) :
    out.words.cellCount ≤ out.peakCellSpace ∧
    out.words.bitSize ≤ out.peakBitSpace := by
  obtain ⟨fuel, hfuel⟩ := (runBitRAMWithBits_eq_some_iff prog inp WordStore.empty [] out).mp hrun
  exact runBitRAMFuel_words_le_peak fuel [.stmt prog] _ out le_rfl le_rfl hfuel

theorem runBitRAMFuel_no_high_heap {d T : ℕ} {inp : BitRAMInput d} :
    ∀ (fuel : ℕ) (stack : List BitRAMCont) (st : BitRAMExecState) (out : BitRAMExecOutcome),
      (∀ item ∈ stack,
        match item with
        | .popScope _ => True
        | .repeatLoop _ body => maxTableStmtFull body ≤ T
        | .stmt s => maxTableStmtFull s ≤ T) →
      (∀ t idx, T ≤ t → RAMCellLoc.heap t idx ∉ st.words.live) →
      runBitRAMFuel inp fuel stack st = .halted out →
      ∀ t idx, T ≤ t → out.words.read (.heap t idx) = 0 := by
  intro fuel
  induction fuel with
  | zero =>
      intro stack st out _ hno hrun t idx ht
      cases stack with
      | nil =>
          simp only [runBitRAMFuel] at hrun
          split_ifs at hrun
          injection hrun with hout; subst hout
          dsimp [WordStore.read, WordStore.popDepth]
          rw [if_neg]
          intro hm; exact hno t idx ht (Finset.mem_of_mem_filter _ hm)
      | cons _ _ => simp [runBitRAMFuel] at hrun
  | succ fuel ih =>
      intro stack st out hstk hno hrun t idx ht
      cases stack with
      | nil =>
          simp only [runBitRAMFuel] at hrun
          split_ifs at hrun
          injection hrun with hout; subst hout
          dsimp [WordStore.read, WordStore.popDepth]
          rw [if_neg]
          intro hm; exact hno t idx ht (Finset.mem_of_mem_filter _ hm)
      | cons item rest =>
          have hhead := hstk item (List.mem_cons.mpr (Or.inl rfl))
          have hrest : ∀ x ∈ rest, match x with
              | .popScope _ => True
              | .repeatLoop _ body => maxTableStmtFull body ≤ T
              | .stmt s => maxTableStmtFull s ≤ T :=
            fun x hx => hstk x (List.mem_cons.mpr (Or.inr hx))
          cases item with
          | popScope prev =>
              simp only [runBitRAMFuel] at hrun
              exact ih rest _ out hrest
                (fun t' i' ht' hm => hno t' i' ht' (Finset.mem_of_mem_filter _ hm)) hrun t idx ht
          | repeatLoop rem body =>
              cases rem with
              | zero =>
                  simp only [runBitRAMFuel] at hrun
                  exact ih rest st out hrest hno hrun t idx ht
              | succ rem' =>
                  simp only [runBitRAMFuel] at hrun
                  refine ih (.stmt body :: .repeatLoop rem' body :: rest) st out ?_ hno hrun t idx ht
                  intro x hx
                  rcases List.mem_cons.mp hx with rfl | hx1
                  · exact hhead
                  · rcases List.mem_cons.mp hx1 with rfl | hx2
                    · exact hhead
                    · exact hrest x hx2
          | stmt s =>
              dsimp only at hhead
              cases s with
              | skip =>
                  simp only [runBitRAMFuel] at hrun
                  exact ih rest _ out hrest (by dsimp; exact hno) hrun t idx ht
              | seq s₁ s₂ =>
                  simp only [runBitRAMFuel] at hrun
                  simp only [maxTableStmtFull, max_le_iff] at hhead
                  refine ih (.stmt s₁ :: .stmt s₂ :: rest) st out ?_ hno hrun t idx ht
                  intro x hx
                  rcases List.mem_cons.mp hx with rfl | hx1
                  · exact hhead.1
                  · rcases List.mem_cons.mp hx1 with rfl | hx2
                    · exact hhead.2
                    · exact hrest x hx2
              | localScope body =>
                  simp only [runBitRAMFuel] at hrun
                  simp only [maxTableStmtFull] at hhead
                  refine ih (.stmt body :: .popScope st.frameDepth :: rest) _ out ?_
                    (fun t' i' ht' hm => hno t' i' ht' (Finset.mem_of_mem_filter _ hm)) hrun t idx ht
                  intro x hx
                  rcases List.mem_cons.mp hx with rfl | hx1
                  · exact hhead
                  · rcases List.mem_cons.mp hx1 with rfl | hx2
                    · trivial
                    · exact hrest x hx2
              | ite cond tB fB =>
                  simp only [runBitRAMFuel] at hrun
                  simp only [maxTableStmtFull, max_le_iff] at hhead
                  rcases hc : evalBitCond inp st.frameDepth st.words cond with ⟨fl, u, b⟩
                  rw [hc] at hrun
                  dsimp only at hrun
                  refine ih (.stmt (if fl then tB else fB) :: rest) _ out ?_ (by dsimp; exact hno) hrun t idx ht
                  intro x hx
                  rcases List.mem_cons.mp hx with rfl | hx1
                  · dsimp; split_ifs <;> omega
                  · exact hrest x hx1
              | whileLoop cond body =>
                  simp only [runBitRAMFuel] at hrun
                  simp only [maxTableStmtFull, max_le_iff] at hhead
                  rcases hc : evalBitCond inp st.frameDepth st.words cond with ⟨fl, u, b⟩
                  rw [hc] at hrun
                  dsimp only at hrun
                  refine ih _ _ out ?_ (by dsimp; exact hno) hrun t idx ht
                  intro x hx
                  cases fl with
                  | false => exact hrest x hx
                  | true =>
                      rcases List.mem_cons.mp hx with rfl | hx1
                      · exact hhead.2
                      · rcases List.mem_cons.mp hx1 with rfl | hx2
                        · exact max_le hhead.1 hhead.2
                        · exact hrest x hx2
              | repeatN countE body =>
                  simp only [runBitRAMFuel] at hrun
                  simp only [maxTableStmtFull, max_le_iff] at hhead
                  rcases he : evalIntExpr inp st.frameDepth st.words countE with ⟨cnt, u, b⟩
                  rw [he] at hrun
                  dsimp only at hrun
                  refine ih _ _ out ?_ (by dsimp; exact hno) hrun t idx ht
                  intro x hx
                  rcases List.mem_cons.mp hx with rfl | hx1
                  · exact hhead.2
                  · exact hrest x hx1
              | freeHeap _ _ | freeLocal _ _ =>
                  simp only [runBitRAMFuel] at hrun
                  exact ih rest _ out hrest
                    (fun t' i' ht' hm => hno t' i' ht' (Finset.mem_of_mem_erase hm)) hrun t idx ht
              | writeLocal var idxE valE =>
                  simp only [runBitRAMFuel] at hrun
                  refine ih rest _ out hrest ?_ hrun t idx ht
                  intro t' i' ht' hm
                  rcases Finset.mem_insert.mp hm with hc | hm'
                  · nomatch hc
                  · exact hno t' i' ht' hm'
              | writeHeap table idxE valE =>
                  simp only [runBitRAMFuel] at hrun
                  simp only [maxTableStmtFull, max_le_iff] at hhead
                  refine ih rest _ out hrest ?_ hrun t idx ht
                  intro t' i' ht' hm
                  rcases Finset.mem_insert.mp hm with hc | hm'
                  · injection hc with hteq _; omega
                  · exact hno t' i' ht' hm'
              | randBitLocal var idxE =>
                  simp only [runBitRAMFuel] at hrun
                  cases hrb : st.remainingBits with
                  | nil => rw [hrb] at hrun; simp at hrun
                  | cons _ _ =>
                      rw [hrb] at hrun; dsimp only at hrun
                      refine ih rest _ out hrest ?_ hrun t idx ht
                      intro t' i' ht' hm
                      rcases Finset.mem_insert.mp hm with hc | hm'
                      · nomatch hc
                      · exact hno t' i' ht' hm'
              | randBitHeap table idxE =>
                  simp only [runBitRAMFuel] at hrun
                  simp only [maxTableStmtFull, max_le_iff] at hhead
                  cases hrb : st.remainingBits with
                  | nil => rw [hrb] at hrun; simp at hrun
                  | cons _ _ =>
                      rw [hrb] at hrun; dsimp only at hrun
                      refine ih rest _ out hrest ?_ hrun t idx ht
                      intro t' i' ht' hm
                      rcases Finset.mem_insert.mp hm with hc | hm'
                      · injection hc with hteq _; omega
                      · exact hno t' i' ht' hm'

theorem read_heap_eq_zero_of_ge_maxTableStmtFull {d : ℕ} {prog : BitRAMStmt}
    {inp : BitRAMInput d} {out : BitRAMExecOutcome}
    (hrun : runBitRAMWithBits prog inp WordStore.empty [] = some out)
    {t : ℕ} (idx : ℤ) (ht : maxTableStmtFull prog ≤ t) :
    out.words.read (.heap t idx) = 0 := by
  obtain ⟨fuel, hfuel⟩ := (runBitRAMWithBits_eq_some_iff prog inp WordStore.empty [] out).mp hrun
  refine runBitRAMFuel_no_high_heap fuel [.stmt prog] _ out ?_ ?_ hfuel t idx ht
  · intro item hmem
    rcases List.mem_singleton.mp hmem with rfl
    exact le_rfl
  · intro _ _ _ hm
    simp [WordStore.popDepth, WordStore.empty] at hm

/-! ### 2. `runSubAndExtractStmt` and its complete `ExecBounded` specification -/

def subCountExpr : Option (ℕ × ℕ) → IntExpr
  | none => .lit 0
  | some (nv, ni) => .readLocal nv (.lit (ni : ℤ))

def runSubAndExtractStmt (isDimD : Bool) (progSub : BitRAMStmt)
    (flagVar flagIdx : ℕ) (outVar : ℕ) (nOutLoc : Option (ℕ × ℕ)) (loopIdxVar : ℕ) : BitRAMStmt :=
  let T_max := maxTableStmtFull progSub
  let countE : IntExpr := subCountExpr nOutLoc
  .seq (enterAndRunSubStmt isDimD progSub)
  (.seq (.writeLocal flagVar (.lit (flagIdx : ℤ)) (.readHeap 10 (.lit 0)))
  (.seq (.writeLocal loopIdxVar (.lit 0) (.lit 0))
  (.seq (.repeatN countE
    (.seq
      (if 1 < T_max then
        .writeLocal outVar (.readLocal loopIdxVar (.lit 0))
          (.readHeap 10 (.add (.mul (.readLocal loopIdxVar (.lit 0)) (.lit (T_max : ℤ))) (.lit 1)))
      else
        .writeLocal outVar (.readLocal loopIdxVar (.lit 0)) (.lit 0))
      (.writeLocal loopIdxVar (.lit 0) (.add (.readLocal loopIdxVar (.lit 0)) (.lit 1)))))
  (.seq cleanupSubLogStmt
        (.freeLocal 99 (.lit 0))))))

def copyOutLoopWS (wsInit : WordStore) (outVar loopIdxVar : ℕ)
    (wsOutSub : WordStore) : ℕ → WordStore
  | 0 => wsInit.write (.localFrame 1 loopIdxVar 0) 0
  | j + 1 =>
      ((copyOutLoopWS wsInit outVar loopIdxVar wsOutSub j).write
        (.localFrame 1 outVar (j : ℤ)) (wsOutSub.read (.heap 1 (j : ℤ)))).write
        (.localFrame 1 loopIdxVar 0) (((j + 1 : ℕ) : ℤ))

def extractSubResultWS (ws₀ : WordStore) (flagVar flagIdx outVar loopIdxVar : ℕ)
    (wsOutSub : WordStore) (N_out : ℕ) : WordStore :=
  (copyOutLoopWS
    (ws₀.write (.localFrame 1 flagVar (flagIdx : ℤ)) (wsOutSub.read (.heap 0 0)))
    outVar loopIdxVar wsOutSub N_out).free (.localFrame 1 99 0)

theorem copyOutLoopWS_props {A V : ℕ} {wsInit wsOutSub : WordStore}
    {outVar loopIdxVar N_out : ℕ}
    (harena : InAttemptArena A V wsInit)
    (hvars : outVar < 99 ∧ loopIdxVar < 99 ∧ outVar ≠ loopIdxVar)
    (hA : 1 ≤ A ∧ N_out ≤ A)
    (hV_idx : ∀ k : ℕ, k ≤ N_out → intBitLength (k : ℤ) ≤ V)
    (hV_out : ∀ j : ℕ, j < N_out → intBitLength (wsOutSub.read (.heap 1 (j : ℤ))) ≤ V) :
    ∀ k : ℕ, k ≤ N_out →
      InAttemptArena A V (copyOutLoopWS wsInit outVar loopIdxVar wsOutSub k) ∧
      (copyOutLoopWS wsInit outVar loopIdxVar wsOutSub k).read (.localFrame 1 loopIdxVar 0) = (k : ℤ) ∧
      (∀ j : ℕ, j < k →
        (copyOutLoopWS wsInit outVar loopIdxVar wsOutSub k).read (.localFrame 1 outVar (j : ℤ)) =
          wsOutSub.read (.heap 1 (j : ℤ))) ∧
      (∀ loc : RAMCellLoc,
        loc ≠ .localFrame 1 loopIdxVar 0 →
        (∀ j : ℕ, j < k → loc ≠ .localFrame 1 outVar (j : ℤ)) →
        (copyOutLoopWS wsInit outVar loopIdxVar wsOutSub k).read loc = wsInit.read loc) := by
  intro k
  induction k with
  | zero =>
      intro hk
      dsimp [copyOutLoopWS]
      refine ⟨inAttemptArena_write_local (var := loopIdxVar) (idx := 0) (val := 0) harena (by omega) (by omega) (by simp; omega) (hV_idx 0 hk),
        wordStore_read_write_self _ _ _,
        fun _ hj => by omega,
        fun loc hne _ => rw_read_write_ne hne⟩
  | succ k ih =>
      intro hk1
      obtain ⟨ha_k, hr_idx, hr_out, hr_other⟩ := ih (by omega)
      dsimp [copyOutLoopWS]
      have ha1 := inAttemptArena_write_local (var := outVar) (idx := (k : ℤ))
        (val := wsOutSub.read (.heap 1 (k : ℤ))) ha_k (by omega) (by positivity)
        (by rw [Int.toNat_natCast]; omega) (hV_out k (by omega))
      have ha2 := inAttemptArena_write_local (var := loopIdxVar) (idx := 0)
        (val := (((k + 1 : ℕ) : ℤ))) ha1 (by omega) (by omega)
        (by simp; omega) (hV_idx (k + 1) hk1)
      refine ⟨ha2, wordStore_read_write_self _ _ _, ?_, ?_⟩
      · intro j hj
        rw [rw_read_write_ne (by intro h; injection h with _ hv _; exact hvars.2.2 hv)]
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hj) with hlt | rfl
        · rw [rw_read_write_ne (by intro h; injection h with _ _ hi; omega)]
          exact hr_out j hlt
        · exact wordStore_read_write_self _ _ _
      · intro loc hne_idx hne_out
        rw [rw_read_write_ne hne_idx,
          rw_read_write_ne (hne_out k (Nat.lt_succ_self k))]
        exact hr_other loc hne_idx (fun j hj => hne_out j (Nat.lt_succ_of_lt hj))

theorem extractSubResultWS_props {A V : ℕ} {ws₀ wsOutSub : WordStore}
    {flagVar flagIdx outVar loopIdxVar N_out : ℕ}
    (harena : InAttemptArena A V ws₀)
    (hvars : flagVar < 99 ∧ outVar < 99 ∧ loopIdxVar < 99 ∧
      flagVar ≠ outVar ∧ flagVar ≠ loopIdxVar ∧ outVar ≠ loopIdxVar)
    (hA : 1 ≤ A ∧ flagIdx < A ∧ N_out ≤ A)
    (hV_flag : intBitLength (wsOutSub.read (.heap 0 0)) ≤ V)
    (hV_idx : ∀ k : ℕ, k ≤ N_out → intBitLength (k : ℤ) ≤ V)
    (hV_out : ∀ j : ℕ, j < N_out → intBitLength (wsOutSub.read (.heap 1 (j : ℤ))) ≤ V) :
    let wsFinal := extractSubResultWS ws₀ flagVar flagIdx outVar loopIdxVar wsOutSub N_out
    InAttemptArena A V wsFinal ∧
    wsFinal.read (.localFrame 1 flagVar (flagIdx : ℤ)) = wsOutSub.read (.heap 0 0) ∧
    (∀ j : ℕ, j < N_out →
      wsFinal.read (.localFrame 1 outVar (j : ℤ)) = wsOutSub.read (.heap 1 (j : ℤ))) ∧
    (∀ loc : RAMCellLoc,
      loc ≠ .localFrame 1 flagVar (flagIdx : ℤ) →
      loc ≠ .localFrame 1 loopIdxVar 0 →
      loc ≠ .localFrame 1 99 0 →
      (∀ j : ℕ, j < N_out → loc ≠ .localFrame 1 outVar (j : ℤ)) →
      wsFinal.read loc = ws₀.read loc) := by
  intro wsFinal
  have ha_init : InAttemptArena A V
      (ws₀.write (.localFrame 1 flagVar (flagIdx : ℤ)) (wsOutSub.read (.heap 0 0))) :=
    inAttemptArena_write_local (var := flagVar) harena (by omega) (by positivity)
      (by rw [Int.toNat_natCast]; exact hA.2.1) hV_flag
  obtain ⟨ha_N, _, hr_out, hr_other⟩ := copyOutLoopWS_props ha_init
    ⟨hvars.2.1, hvars.2.2.1, hvars.2.2.2.2.2⟩ ⟨hA.1, hA.2.2⟩ hV_idx hV_out N_out le_rfl
  refine ⟨inAttemptArena_free ha_N _, ?_, ?_, ?_⟩
  · dsimp [wsFinal, extractSubResultWS]
    rw [rw_read_free_ne (by intro h; injection h with _ hv _; omega)]
    rw [hr_other _ (by intro h; injection h with _ hv _; exact hvars.2.2.2.2.1 hv)
      (fun j _ h => by injection h with _ hv _; exact hvars.2.2.2.1 hv)]
    exact wordStore_read_write_self _ _ _
  · intro j hj
    dsimp [wsFinal, extractSubResultWS]
    rw [rw_read_free_ne (by intro h; injection h with _ hv _; omega)]
    exact hr_out j hj
  · intro loc hne_fl hne_lp hne99 hne_out
    dsimp [wsFinal, extractSubResultWS]
    rw [rw_read_free_ne hne99, hr_other loc hne_lp hne_out,
      rw_read_write_ne hne_fl]

theorem exec_runSubAndExtractStmt {isDimD : Bool} {d dSub L_p A V : ℕ}
    {inpSim : BitRAMInput d} {inpSub : BitRAMInput dSub}
    {ws₀ : WordStore} {bs : List Bool}
    (progSub : BitRAMStmt) {outSub : BitRAMExecOutcome}
    {flagVar flagIdx outVar loopIdxVar N_out : ℕ}
    {nOutLoc : Option (ℕ × ℕ)}
    {U_sub B_sub C_sub S_sub : ℕ}
    (harena : InAttemptArena A V ws₀)
    (hstage : SimStageMatches isDimD d dSub L_p ws₀ inpSub)
    (hrunSub : runBitRAMWithBits progSub inpSub WordStore.empty [] = some outSub)
    (hvars : flagVar < 99 ∧ outVar < 99 ∧ loopIdxVar < 99 ∧
      flagVar ≠ outVar ∧ flagVar ≠ loopIdxVar ∧ outVar ≠ loopIdxVar)
    (hA : 1 ≤ A ∧ flagIdx < A ∧ N_out ≤ A)
    (hnOut : match nOutLoc with
      | none => N_out = 0
      | some (nv, ni) =>
          nv < 99 ∧ ni < A ∧ nv ≠ flagVar ∧ nv ≠ loopIdxVar ∧
          ws₀.read (.localFrame 1 nv (ni : ℤ)) = (N_out : ℤ))
    (hV_flag : intBitLength (outSub.words.read (.heap 0 0)) ≤ V)
    (hV_out : ∀ j : ℕ, j < N_out → intBitLength (outSub.words.read (.heap 1 (j : ℤ))) ≤ V)
    (hV_A : natBitLength A + 2 ≤ V)
    (hsub_bounds : outSub.unitCost ≤ U_sub ∧ outSub.bitCost ≤ B_sub ∧
      outSub.peakCellSpace ≤ C_sub ∧ outSub.peakBitSpace ≤ S_sub) :
    let T_max := maxTableStmtFull progSub
    let F := stmtFactor progSub
    let L_enc_max := B_sub + 2 * natBitLength T_max + 6
    let K_bit_max := 256 * F * (L_p + natBitLength T_max + 8) ^ 2 * (B_sub + U_sub + 16)
    let Δu := 80 * F * (U_sub + 1) + 16 * N_out + 64
    let Δb := K_bit_max * B_sub +
      (U_sub + 2) * (8 * natBitLength (U_sub + 2) + 4 * L_enc_max + 80) +
      (N_out + 4) * (32 * (natBitLength A + natBitLength T_max + V + 16) ^ 2)
    let C_call := inpSim.inputCellSpace + 108 * A + C_sub + U_sub + 8
    let S_call := inpSim.inputBitSpace + 108 * A * (natBitLength A + V + 16) +
      (natBitLength T_max + 12) * S_sub +
      (U_sub + 3) * (natBitLength (U_sub + 2) + L_enc_max + 12) +
      2 * natBitLength (U_sub + 2) + 64
    ExecBounded inpSim
      (runSubAndExtractStmt isDimD progSub flagVar flagIdx outVar nOutLoc loopIdxVar)
      ws₀ bs
      (extractSubResultWS ws₀ flagVar flagIdx outVar loopIdxVar outSub.words N_out) bs
      Δu Δb C_call S_call := by
  intro T_max F L_enc_max K_bit_max Δu Δb C_call S_call
  have hT : 1 ≤ T_max := maxTableStmtFull_pos progSub
  have hF : 1 ≤ F := stmtFactor_pos progSub
  obtain ⟨hwHeap_c, hwHeap_b⟩ := outSub_words_le_peak hrunSub
  have hV_idx : ∀ k : ℕ, k ≤ N_out → intBitLength (k : ℤ) ≤ V := by
    intro k hk
    have h1 := intBitLength_natCast_le_succ k
    have h2 := natBitLength_mono (hk.trans hA.2.2)
    omega
  intro st₁ hws₁ hfd₁ hbs₁
  -- Step 1: enterAndRunSubStmt
  obtain ⟨wsHeap, log, stMid, hruns_enter, ⟨hheap_c, hheap_b⟩, hwfHeap, hHeapLog, hread10,
    hlen_log, hlogb, hwsMid, hfdMid, hbsMid, huMid, hbMid, hpcMid, hpbMid⟩ :=
    exec_enterAndRunSubStmt (inpSim := inpSim) progSub hstage hws₁ hfd₁ hrunSub
  have hlog_U : log.length ≤ U_sub := hlen_log.trans hsub_bounds.1
  have hLenc_le : outSub.bitCost + 2 * natBitLength T_max + 6 ≤ L_enc_max := by
    dsimp [L_enc_max]; omega
  have hlogb_max : ∀ x ∈ log, intBitLength x ≤ L_enc_max :=
    fun x hx => (hlogb x hx).trans hLenc_le
  -- Uniform cellCount and bitSize bound for `simMergeStore wsB T_max hT wsHeap log`
  have hmerge_bounds : ∀ wsB : WordStore, InAttemptArena A V wsB →
      inpSim.inputCellSpace + (simMergeStore wsB T_max hT wsHeap log).cellCount ≤ C_call ∧
      inpSim.inputBitSpace + (simMergeStore wsB T_max hT wsHeap log).bitSize ≤ S_call -
        (2 * natBitLength (U_sub + 2) + 32) := by
    intro wsB haB
    obtain ⟨hcB, hbB⟩ := inAttemptArena_size_le haB
    have hmc := simMergeStore_cellCount_le wsB hT wsHeap log
    have hmb := simMergeStore_bitSize_le haB.1 hT wsHeap log hlogb_max
    have hm_sub : (natBitLength T_max + 12) * wsHeap.bitSize ≤
        (natBitLength T_max + 12) * S_sub :=
      Nat.mul_le_mul_left _ (hheap_b.trans (hwHeap_b.trans hsub_bounds.2.2.2))
    have hn_log : natBitLength log.length ≤ natBitLength (U_sub + 2) :=
      natBitLength_mono (by omega)
    have hm_log : (log.length + 1) * (natBitLength log.length + L_enc_max + 10) ≤
        (U_sub + 3) * (natBitLength (U_sub + 2) + L_enc_max + 12) :=
      Nat.mul_le_mul (by omega) (by omega)
    refine ⟨by dsimp [C_call]; omega, ?_⟩
    dsimp [S_call]
    omega
  -- Step 2: writeLocal flagVar flagIdx (readHeap 10 0)
  let vFlag := outSub.words.read (.heap 0 0)
  have hread10_0 : stMid.words.read (.heap 10 0) = vFlag := by
    have h0 := hread10 0 0 hT
    simpa using h0
  let wsB₁ := ws₀.write (.localFrame 1 flagVar (flagIdx : ℤ)) vFlag
  have haB₁ : InAttemptArena A V wsB₁ :=
    inAttemptArena_write_local (var := flagVar) harena (by omega) (by positivity)
      (by rw [Int.toNat_natCast]; exact hA.2.1) hV_flag
  have hs_flag := RunsTo.writeLocal inpSim flagVar (.lit (flagIdx : ℤ)) (.readHeap 10 (.lit 0)) stMid
  dsimp only at hs_flag
  have he_fi : evalIntExpr inpSim stMid.frameDepth stMid.words (.lit (flagIdx : ℤ)) =
      ((flagIdx : ℤ), 1, intBitLength (flagIdx : ℤ)) := rfl
  have he_h0 : evalIntExpr inpSim stMid.frameDepth stMid.words (.readHeap 10 (.lit 0)) =
      (vFlag, 2, 1 + natBitLength 10 + 1 + intBitLength vFlag) := by
    simp [evalIntExpr, hread10_0]; rfl
  rw [he_fi, he_h0, hfdMid] at hs_flag
  dsimp only at hs_flag
  set stF : BitRAMExecState :=
    { stMid with
      words := stMid.words.write (.localFrame 1 flagVar (flagIdx : ℤ)) vFlag
      frameDepth := 1
      unitCost := stMid.unitCost + 1 + 2 + 1
      bitCost := stMid.bitCost + intBitLength (flagIdx : ℤ) +
        (1 + natBitLength 10 + 1 + intBitLength vFlag) +
        (RAMCellLoc.localFrame 1 flagVar (flagIdx : ℤ)).bitLength + intBitLength vFlag
      peakCellSpace := max stMid.peakCellSpace
        (inpSim.inputCellSpace + (stMid.words.write (.localFrame 1 flagVar (flagIdx : ℤ)) vFlag).cellCount)
      peakBitSpace := max stMid.peakBitSpace
        (inpSim.inputBitSpace + (stMid.words.write (.localFrame 1 flagVar (flagIdx : ℤ)) vFlag).bitSize) }
  change RunsTo inpSim _ stMid stF at hs_flag
  have hwsF : stF.words = simMergeStore wsB₁ T_max hT wsHeap log := by
    dsimp [stF, wsB₁]
    rw [hwsMid, simMergeStore_write_local1 ws₀ hT wsHeap log]
  -- Step 3: writeLocal loopIdxVar 0 0
  let wsB₂ := copyOutLoopWS wsB₁ outVar loopIdxVar outSub.words 0
  have haB₂ : InAttemptArena A V wsB₂ :=
    (copyOutLoopWS_props haB₁ ⟨hvars.2.1, hvars.2.2.1, hvars.2.2.2.2.2⟩
      ⟨hA.1, hA.2.2⟩ hV_idx hV_out 0 (Nat.zero_le _)).1
  have hs_l0 := RunsTo.writeLocal inpSim loopIdxVar (.lit 0) (.lit 0) stF
  dsimp only at hs_l0
  have he_z1 : evalIntExpr inpSim stF.frameDepth stF.words (.lit 0) = (0, 1, 1) := rfl
  have hfdF : stF.frameDepth = 1 := rfl
  rw [he_z1, hfdF] at hs_l0
  dsimp only at hs_l0
  set stL0 : BitRAMExecState :=
    { stF with
      words := stF.words.write (.localFrame 1 loopIdxVar 0) 0
      frameDepth := 1
      unitCost := stF.unitCost + 1 + 1 + 1
      bitCost := stF.bitCost + 1 + 1 + (RAMCellLoc.localFrame 1 loopIdxVar 0).bitLength + 1
      peakCellSpace := max stF.peakCellSpace
        (inpSim.inputCellSpace + (stF.words.write (.localFrame 1 loopIdxVar 0) 0).cellCount)
      peakBitSpace := max stF.peakBitSpace
        (inpSim.inputBitSpace + (stF.words.write (.localFrame 1 loopIdxVar 0) 0).bitSize) }
  change RunsTo inpSim _ stF stL0 at hs_l0
  have hwsL0 : stL0.words = simMergeStore wsB₂ T_max hT wsHeap log := by
    dsimp [stL0, wsB₂, copyOutLoopWS]
    rw [hwsF, simMergeStore_write_local1 wsB₁ hT wsHeap log]
  -- Step 4: repeatN countE copyBody
  let copyBody : BitRAMStmt :=
    .seq
      (if 1 < T_max then
        .writeLocal outVar (.readLocal loopIdxVar (.lit 0))
          (.readHeap 10 (.add (.mul (.readLocal loopIdxVar (.lit 0)) (.lit (T_max : ℤ))) (.lit 1)))
      else
        .writeLocal outVar (.readLocal loopIdxVar (.lit 0)) (.lit 0))
      (.writeLocal loopIdxVar (.lit 0) (.add (.readLocal loopIdxVar (.lit 0)) (.lit 1)))
  let B_step : ℕ := 32 * (natBitLength A + natBitLength T_max + V + 16) ^ 2
  have hB_lin : 16 * (natBitLength A + natBitLength T_max + V + 16) ≤ B_step := by
    dsimp [B_step]; rw [sq]
    have h1 : 16 * (natBitLength A + natBitLength T_max + V + 16) ≤
        (natBitLength A + natBitLength T_max + V + 16) *
          (natBitLength A + natBitLength T_max + V + 16) :=
      Nat.mul_le_mul_right _ (by omega)
    exact h1.trans (Nat.le_mul_of_pos_left _ (by norm_num))
  have hcopy_loop : ∀ (rem j : ℕ), j + rem = N_out →
      ∀ st_j : BitRAMExecState,
        st_j.words = simMergeStore (copyOutLoopWS wsB₁ outVar loopIdxVar outSub.words j) T_max hT wsHeap log →
        st_j.frameDepth = 1 →
        ∃ st_end : BitRAMExecState,
          RunsTo inpSim [.repeatLoop rem copyBody] st_j st_end ∧
          st_end.words = simMergeStore (copyOutLoopWS wsB₁ outVar loopIdxVar outSub.words N_out) T_max hT wsHeap log ∧
          st_end.frameDepth = 1 ∧
          st_end.remainingBits = st_j.remainingBits ∧
          st_end.unitCost ≤ st_j.unitCost + 16 * rem ∧
          st_end.bitCost ≤ st_j.bitCost + rem * B_step ∧
          st_end.peakCellSpace ≤ max st_j.peakCellSpace C_call ∧
          st_end.peakBitSpace ≤ max st_j.peakBitSpace S_call := by
    intro rem
    induction rem with
    | zero =>
        intro j hjn st_j hwj hfj
        have hjn' : j = N_out := by omega
        subst hjn'
        exact ⟨st_j, RunsTo.repeatLoop_zero copyBody st_j, hwj, hfj, rfl,
          by simp, by simp, le_max_left _ _, le_max_left _ _⟩
    | succ rem ih =>
        intro j hjn st_j hwj hfj
        have hj_lt : j < N_out := by omega
        set wsBj := copyOutLoopWS wsB₁ outVar loopIdxVar outSub.words j
        obtain ⟨haBj, hr_lp_j, _, _⟩ := copyOutLoopWS_props haB₁
          ⟨hvars.2.1, hvars.2.2.1, hvars.2.2.2.2.2⟩ ⟨hA.1, hA.2.2⟩ hV_idx hV_out j (by omega)
        have hr_lp_sim : st_j.words.read (.localFrame 1 loopIdxVar 0) = (j : ℤ) := by
          rw [hwj, simMergeStore_read_local1 hT log, hr_lp_j]
        let v_j := outSub.words.read (.heap 1 (j : ℤ))
        let wsBj_mid := wsBj.write (.localFrame 1 outVar (j : ℤ)) v_j
        have haBj_mid : InAttemptArena A V wsBj_mid :=
          inAttemptArena_write_local (var := outVar) haBj (by omega) (by positivity)
            (by rw [Int.toNat_natCast]; omega) (hV_out j hj_lt)
        have hnv_lp : natBitLength loopIdxVar ≤ 7 :=
          (natBitLength_mono (by omega : loopIdxVar ≤ 100)).trans (by decide)
        have hnv_out : natBitLength outVar ≤ 7 :=
          (natBitLength_mono (by omega : outVar ≤ 100)).trans (by decide)
        have hij_b : intBitLength (j : ℤ) ≤ natBitLength A + 1 :=
          (intBitLength_natCast_le_succ j).trans
            (Nat.add_le_add_right (natBitLength_mono (by omega : j ≤ A)) 1)
        have hij1_b : intBitLength (Nat.cast (j + 1)) ≤ natBitLength A + 1 :=
          (intBitLength_natCast_le_succ (j + 1)).trans
            (Nat.add_le_add_right (natBitLength_mono (by omega : j + 1 ≤ A)) 1)
        have hij1_b' : intBitLength ((j : ℤ) + 1) ≤ natBitLength A + 1 := by
          rw [← Nat.cast_add_one]; exact hij1_b
        have hvj_b : intBitLength v_j ≤ V := hV_out j hj_lt
        -- Branch on `1 < T_max` for the first statement of `copyBody`
        have hs_part1 : ∃ st_m : BitRAMExecState,
            RunsTo inpSim [.stmt (if 1 < T_max then
              .writeLocal outVar (.readLocal loopIdxVar (.lit 0))
                (.readHeap 10 (.add (.mul (.readLocal loopIdxVar (.lit 0)) (.lit (T_max : ℤ))) (.lit 1)))
            else
              .writeLocal outVar (.readLocal loopIdxVar (.lit 0)) (.lit 0))] st_j st_m ∧
            st_m.words = simMergeStore wsBj_mid T_max hT wsHeap log ∧
            st_m.frameDepth = 1 ∧
            st_m.remainingBits = st_j.remainingBits ∧
            st_m.unitCost ≤ st_j.unitCost + 10 ∧
            st_m.bitCost ≤ st_j.bitCost + 16 * (natBitLength A + natBitLength T_max + V + 16) ^ 2 ∧
            st_m.peakCellSpace ≤ max st_j.peakCellSpace C_call ∧
            st_m.peakBitSpace ≤ max st_j.peakBitSpace S_call := by
          by_cases hT1 : 1 < T_max
          · rw [if_pos hT1]
            let enc_j : ℤ := (j : ℤ) * (T_max : ℤ) + 1
            have hr_enc : st_j.words.read (.heap 10 enc_j) = v_j := by
              rw [hwj, simMergeStore_read_heap10_of_base hstage.1 haBj.1 hT log enc_j,
                ← hwsMid]
              exact hread10 1 (j : ℤ) hT1
            have hs1 := RunsTo.writeLocal inpSim outVar (.readLocal loopIdxVar (.lit 0))
              (.readHeap 10 (.add (.mul (.readLocal loopIdxVar (.lit 0)) (.lit (T_max : ℤ))) (.lit 1))) st_j
            dsimp only at hs1
            have he_idx : evalIntExpr inpSim st_j.frameDepth st_j.words (.readLocal loopIdxVar (.lit 0)) =
                ((j : ℤ), 2, 1 + natBitLength loopIdxVar + 1 + intBitLength (j : ℤ)) := by
              rw [hfj]; simp [evalIntExpr, hr_lp_sim]; rfl
            have he_val : evalIntExpr inpSim st_j.frameDepth st_j.words
                (.readHeap 10 (.add (.mul (.readLocal loopIdxVar (.lit 0)) (.lit (T_max : ℤ))) (.lit 1))) =
                (v_j, 7,
                 1 + natBitLength loopIdxVar + 1 + intBitLength (j : ℤ) +
                   intBitLength (T_max : ℤ) + intBitLength (j : ℤ) * intBitLength (T_max : ℤ) +
                   2 + intBitLength ((j : ℤ) * (T_max : ℤ)) + 2 +
                   natBitLength 10 + intBitLength enc_j + intBitLength v_j) := by
              rw [hfj]
              simp only [evalIntExpr, hr_lp_sim, enc_j, hr_enc]
              have hi0 : intBitLength 0 = 1 := rfl
              have hi1 : intBitLength 1 = 2 := by decide
              rw [hi0, hi1]
            rw [he_idx, he_val, hfj] at hs1
            dsimp only at hs1
            have hws_m : st_j.words.write (.localFrame 1 outVar (j : ℤ)) v_j =
                simMergeStore wsBj_mid T_max hT wsHeap log := by
              rw [hwj]; exact simMergeStore_write_local1 wsBj hT wsHeap log outVar (j : ℤ) v_j
            obtain ⟨hmc_m, hmb_m⟩ := hmerge_bounds wsBj_mid haBj_mid
            have hT_ib := intBitLength_natCast_le_succ T_max
            have hmul_ib := intBitLength_mul_le (j : ℤ) (T_max : ℤ)
            have hadd_ib := intBitLength_add_le ((j : ℤ) * (T_max : ℤ)) 1
            have hi1 : intBitLength 1 = 2 := by decide
            have hn10 : natBitLength 10 = 4 := by decide
            have hloc_out : (RAMCellLoc.localFrame 1 outVar (j : ℤ)).bitLength ≤ natBitLength A + 10 := by
              dsimp [RAMCellLoc.bitLength]
              have hn1 : natBitLength 1 = 1 := rfl
              omega
            let X := natBitLength A + natBitLength T_max + V + 16
            have hprod : intBitLength (j : ℤ) * intBitLength (T_max : ℤ) ≤ X * X :=
              Nat.mul_le_mul (by dsimp [X]; omega) (by dsimp [X]; omega)
            have hlinX : 8 * X ≤ 8 * (X * X) :=
              Nat.mul_le_mul_left 8 (Nat.le_mul_of_pos_right X (by dsimp [X]; omega))
            refine ⟨_, hs1, hws_m, rfl, rfl, by dsimp; omega, ?_,
              max_le (le_max_left _ _) (le_trans (by rw [hws_m]; exact hmc_m) (le_max_right _ _)),
              max_le (le_max_left _ _) (le_trans (by rw [hws_m]; exact hmb_m.trans (Nat.sub_le _ _)) (le_max_right _ _))⟩
            dsimp only
            rw [sq]
            have hsum_b :
                (1 + natBitLength loopIdxVar + 1 + intBitLength (j : ℤ)) +
                (1 + natBitLength loopIdxVar + 1 + intBitLength (j : ℤ) +
                  intBitLength (T_max : ℤ) + intBitLength (j : ℤ) * intBitLength (T_max : ℤ) +
                  2 + intBitLength ((j : ℤ) * (T_max : ℤ)) + 2 +
                  natBitLength 10 + intBitLength enc_j + intBitLength v_j) +
                (RAMCellLoc.localFrame 1 outVar (j : ℤ)).bitLength + intBitLength v_j ≤
                X * X + 8 * X := by
              dsimp [X] at hprod hlinX
              dsimp [X, enc_j] at hadd_ib ⊢
              rw [hi1] at hadd_ib
              rw [hn10]
              omega
            dsimp [X] at hsum_b hlinX ⊢
            omega
          · rw [if_neg hT1]
            have hvj_zero : v_j = 0 :=
              read_heap_eq_zero_of_ge_maxTableStmtFull hrunSub (j : ℤ) (by dsimp [T_max] at hT1; omega)
            have hs1 := RunsTo.writeLocal inpSim outVar (.readLocal loopIdxVar (.lit 0)) (.lit 0) st_j
            dsimp only at hs1
            have he_idx : evalIntExpr inpSim st_j.frameDepth st_j.words (.readLocal loopIdxVar (.lit 0)) =
                ((j : ℤ), 2, 1 + natBitLength loopIdxVar + 1 + intBitLength (j : ℤ)) := by
              rw [hfj]; simp [evalIntExpr, hr_lp_sim]; rfl
            have he_z : evalIntExpr inpSim st_j.frameDepth st_j.words (.lit 0) = (0, 1, 1) := rfl
            rw [he_idx, he_z, hfj] at hs1
            dsimp only at hs1
            have hws_m : st_j.words.write (.localFrame 1 outVar (j : ℤ)) 0 =
                simMergeStore wsBj_mid T_max hT wsHeap log := by
              dsimp [wsBj_mid]; rw [hvj_zero, hwj]
              exact simMergeStore_write_local1 wsBj hT wsHeap log outVar (j : ℤ) 0
            obtain ⟨hmc_m, hmb_m⟩ := hmerge_bounds wsBj_mid haBj_mid
            have hloc_out : (RAMCellLoc.localFrame 1 outVar (j : ℤ)).bitLength ≤ natBitLength A + 10 := by
              dsimp [RAMCellLoc.bitLength]
              have hn1 : natBitLength 1 = 1 := rfl
              omega
            let X := natBitLength A + natBitLength T_max + V + 16
            have hlinX : 8 * X ≤ 16 * (X ^ 2) := by
              rw [sq]
              have h1 : 8 * X ≤ X * X := Nat.mul_le_mul_right X (by dsimp [X]; omega)
              exact h1.trans (Nat.le_mul_of_pos_left _ (by norm_num))
            refine ⟨_, hs1, hws_m, rfl, rfl, by dsimp; omega, ?_,
              max_le (le_max_left _ _) (le_trans (by rw [hws_m]; exact hmc_m) (le_max_right _ _)),
              max_le (le_max_left _ _) (le_trans (by rw [hws_m]; exact hmb_m.trans (Nat.sub_le _ _)) (le_max_right _ _))⟩
            dsimp only
            have hi0 : intBitLength 0 = 1 := rfl
            have hsum_b : (1 + natBitLength loopIdxVar + 1 + intBitLength (j : ℤ)) + 1 +
                (RAMCellLoc.localFrame 1 outVar (j : ℤ)).bitLength + intBitLength 0 ≤ 8 * X := by
              rw [hi0]; dsimp [X]; omega
            dsimp [X] at hlinX hsum_b ⊢
            omega
        obtain ⟨st_m, hr_p1, hws_m, hfd_m, hbs_m, hu_m, hb_m, hpc_m, hpb_m⟩ := hs_part1
        -- Second statement of `copyBody`: increment `loopIdxVar`
        have hr_lp_m : st_m.words.read (.localFrame 1 loopIdxVar 0) = (j : ℤ) := by
          rw [hws_m, simMergeStore_read_local1 hT log]
          dsimp [wsBj_mid]
          rw [rw_read_write_ne (by intro h; injection h with _ hv _; exact hvars.2.2.2.2.2 hv.symm)]
          exact hr_lp_j
        have hs2 := RunsTo.writeLocal inpSim loopIdxVar (.lit 0)
          (.add (.readLocal loopIdxVar (.lit 0)) (.lit 1)) st_m
        dsimp only at hs2
        have he_z : evalIntExpr inpSim st_m.frameDepth st_m.words (.lit 0) = (0, 1, 1) := rfl
        have he_inc : evalIntExpr inpSim st_m.frameDepth st_m.words
            (.add (.readLocal loopIdxVar (.lit 0)) (.lit 1)) =
            (((j + 1 : ℕ) : ℤ), 4,
             1 + natBitLength loopIdxVar + 1 + intBitLength (j : ℤ) + 2 + intBitLength (j : ℤ) + 2) := by
          rw [hfd_m]
          simp only [evalIntExpr, hr_lp_m]
          have hi0 : intBitLength 0 = 1 := rfl
          have hi1 : intBitLength 1 = 2 := by decide
          rw [hi0, hi1]
          congr 1
        rw [he_z, he_inc, hfd_m] at hs2
        dsimp only at hs2
        set st_j1 : BitRAMExecState :=
          { st_m with
            words := st_m.words.write (.localFrame 1 loopIdxVar 0) (((j + 1 : ℕ) : ℤ))
            frameDepth := 1
            unitCost := st_m.unitCost + 1 + 4 + 1
            bitCost := st_m.bitCost + 1 +
              (1 + natBitLength loopIdxVar + 1 + intBitLength (j : ℤ) + 2 + intBitLength (j : ℤ) + 2) +
              (RAMCellLoc.localFrame 1 loopIdxVar 0).bitLength + intBitLength (((j + 1 : ℕ) : ℤ))
            peakCellSpace := max st_m.peakCellSpace
              (inpSim.inputCellSpace + (st_m.words.write (.localFrame 1 loopIdxVar 0) (((j + 1 : ℕ) : ℤ))).cellCount)
            peakBitSpace := max st_m.peakBitSpace
              (inpSim.inputBitSpace + (st_m.words.write (.localFrame 1 loopIdxVar 0) (((j + 1 : ℕ) : ℤ))).bitSize) }
        change RunsTo inpSim _ st_m st_j1 at hs2
        have hws_j1 : st_j1.words =
            simMergeStore (copyOutLoopWS wsB₁ outVar loopIdxVar outSub.words (j + 1)) T_max hT wsHeap log := by
          dsimp [st_j1, copyOutLoopWS]
          rw [hws_m, simMergeStore_write_local1 wsBj_mid hT wsHeap log]
        have haBj1 : InAttemptArena A V (copyOutLoopWS wsB₁ outVar loopIdxVar outSub.words (j + 1)) :=
          (copyOutLoopWS_props haB₁ ⟨hvars.2.1, hvars.2.2.1, hvars.2.2.2.2.2⟩
            ⟨hA.1, hA.2.2⟩ hV_idx hV_out (j + 1) (by omega)).1
        obtain ⟨hmc_j1, hmb_j1⟩ := hmerge_bounds _ haBj1
        have hbody_runs : RunsTo inpSim [.stmt copyBody] st_j st_j1 :=
          RunsTo.seq hr_p1 hs2
        obtain ⟨st_end, hrem_r, hw_e, hf_e, hbs_e, hu_e, hb_e, hpc_e, hpb_e⟩ :=
          ih (j + 1) (by omega) st_j1 hws_j1 rfl
        have hloc_lp : (RAMCellLoc.localFrame 1 loopIdxVar 0).bitLength ≤ 10 := by
          dsimp [RAMCellLoc.bitLength]
          have hn1 : natBitLength 1 = 1 := rfl
          have hi0 : intBitLength 0 = 1 := rfl
          omega
        let X := natBitLength A + natBitLength T_max + V + 16
        have hstep2_b : 1 + (1 + natBitLength loopIdxVar + 1 + intBitLength (j : ℤ) + 2 +
            intBitLength (j : ℤ) + 2) + (RAMCellLoc.localFrame 1 loopIdxVar 0).bitLength +
            intBitLength (((j + 1 : ℕ) : ℤ)) ≤ 16 * (X ^ 2) := by
          have h1 : 1 + (1 + natBitLength loopIdxVar + 1 + intBitLength (j : ℤ) + 2 +
              intBitLength (j : ℤ) + 2) + (RAMCellLoc.localFrame 1 loopIdxVar 0).bitLength +
              intBitLength (((j + 1 : ℕ) : ℤ)) ≤ 16 * X := by dsimp [X]; omega
          rw [sq]
          exact h1.trans (Nat.mul_le_mul_left 16 (Nat.le_mul_of_pos_right X (by dsimp [X]; omega)))
        have hpc_j1 : st_j1.peakCellSpace ≤ max st_j.peakCellSpace C_call := by
          dsimp [st_j1]
          exact max_le hpc_m (le_trans (by change inpSim.inputCellSpace + st_j1.words.cellCount ≤ C_call; rw [hws_j1]; exact hmc_j1) (le_max_right _ _))
        have hpb_j1 : st_j1.peakBitSpace ≤ max st_j.peakBitSpace S_call := by
          dsimp [st_j1]
          exact max_le hpb_m (le_trans (by change inpSim.inputBitSpace + st_j1.words.bitSize ≤ S_call; rw [hws_j1]; exact hmb_j1.trans (Nat.sub_le _ _)) (le_max_right _ _))
        refine ⟨st_end, RunsTo.repeatLoop_succ hbody_runs hrem_r, hw_e, hf_e,
          hbs_e.trans hbs_m, ?_, ?_,
          hpc_e.trans (max_le hpc_j1 (le_max_right _ _)),
          hpb_e.trans (max_le hpb_j1 (le_max_right _ _))⟩
        · dsimp [st_j1] at hu_e; omega
        · dsimp [st_j1] at hb_e
          rw [Nat.succ_mul]
          have hB_eq : 16 * (X ^ 2) + 16 * (X ^ 2) = B_step := by dsimp [B_step, X]; ring
          dsimp [X] at hstep2_b hB_eq
          omega
  -- Evaluate `countE` on `stL0`
  let countE : IntExpr := subCountExpr nOutLoc
  have hcnt_eval : ∃ uc bc : ℕ,
      evalIntExpr inpSim stL0.frameDepth stL0.words countE = ((N_out : ℤ), uc, bc) ∧
      uc ≤ 3 ∧ bc ≤ B_step := by
    cases nOutLoc with
    | none =>
        dsimp at hnOut; subst hnOut
        refine ⟨1, 1, rfl, by omega, ?_⟩
        exact (by omega : 1 ≤ 16 * (natBitLength A + natBitLength T_max + V + 16)).trans hB_lin
    | some pair =>
        rcases pair with ⟨nv, ni⟩
        dsimp at hnOut
        rcases hnOut with ⟨hnv99, hniA, hnv_fl, hnv_lp, hr_nout⟩
        have hr_stL0 : stL0.words.read (.localFrame 1 nv (ni : ℤ)) = (N_out : ℤ) := by
          rw [hwsL0, simMergeStore_read_local1 hT log]
          dsimp [wsB₂, copyOutLoopWS, wsB₁]
          rw [rw_read_write_ne (by intro h; injection h with _ hv _; exact hnv_lp hv),
            rw_read_write_ne (by intro h; injection h with _ hv _; exact hnv_fl hv)]
          exact hr_nout
        refine ⟨2, intBitLength (ni : ℤ) + natBitLength nv + intBitLength (ni : ℤ) + intBitLength (N_out : ℤ), ?_, by omega, ?_⟩
        · dsimp [countE, subCountExpr]; rw [hfdF]
          simp [evalIntExpr, hr_stL0]
        · have hnv_b : natBitLength nv ≤ 7 :=
            (natBitLength_mono (by omega : nv ≤ 100)).trans (by decide)
          have hni_b : intBitLength (ni : ℤ) ≤ natBitLength A + 1 :=
            (intBitLength_natCast_le_succ ni).trans
              (Nat.add_le_add_right (natBitLength_mono (by omega : ni ≤ A)) 1)
          have hno_b : intBitLength (N_out : ℤ) ≤ natBitLength A + 1 :=
            (intBitLength_natCast_le_succ N_out).trans
              (Nat.add_le_add_right (natBitLength_mono hA.2.2) 1)
          exact (by omega : _ ≤ 16 * (natBitLength A + natBitLength T_max + V + 16)).trans hB_lin
  obtain ⟨uc_cnt, bc_cnt, he_cnt, huc_le, hbc_le⟩ := hcnt_eval
  let stRepInit : BitRAMExecState :=
    { stL0 with unitCost := stL0.unitCost + uc_cnt, bitCost := stL0.bitCost + bc_cnt }
  obtain ⟨stAfterCopy, hrl_copy, hwsAfter, hfdAfter, hbsAfter, huAfter, hbAfter, hpcAfter, hpbAfter⟩ :=
    hcopy_loop N_out 0 (Nat.zero_add N_out) stRepInit hwsL0 hfdF
  have hs_rep : RunsTo inpSim [.stmt (.repeatN countE copyBody)] stL0 stAfterCopy := by
    refine RunsTo.repeatN countE copyBody ?_
    rw [he_cnt]; dsimp only
    rw [if_pos (Int.natCast_nonneg N_out), Int.toNat_natCast]
    exact hrl_copy
  -- Step 5: cleanupSubLogStmt
  set wsBN := copyOutLoopWS wsB₁ outVar loopIdxVar outSub.words N_out
  have haBN : InAttemptArena A V wsBN :=
    (copyOutLoopWS_props haB₁ ⟨hvars.2.1, hvars.2.2.1, hvars.2.2.2.2.2⟩
      ⟨hA.1, hA.2.2⟩ hV_idx hV_out N_out le_rfl).1
  obtain ⟨stClean, hs_clean, hwsClean, _, hfdClean, hbsClean, huClean, hbClean, hpcClean, hpbClean⟩ :=
    exec_cleanupSubLogStmt haBN.1 hT hwfHeap hHeapLog hlogb_max hwsAfter hfdAfter
  -- Step 6: freeLocal 99 0
  have hs_free99 := RunsTo.freeLocal inpSim 99 (.lit 0) stClean
  dsimp only at hs_free99
  have he_z99 : evalIntExpr inpSim stClean.frameDepth stClean.words (.lit 0) = (0, 1, 1) := rfl
  rw [he_z99, hfdClean] at hs_free99
  dsimp only at hs_free99
  set stFinal : BitRAMExecState :=
    { stClean with
      words := stClean.words.free (.localFrame 1 99 0)
      frameDepth := 1
      unitCost := stClean.unitCost + 1 + 1
      bitCost := stClean.bitCost + 1 + (RAMCellLoc.localFrame 1 99 0).bitLength }
  change RunsTo inpSim _ stClean stFinal at hs_free99
  have hwsFinal : stFinal.words =
      extractSubResultWS ws₀ flagVar flagIdx outVar loopIdxVar outSub.words N_out := by
    dsimp [stFinal, extractSubResultWS]
    rw [hwsClean, wordStore_free_write_self]
  have htot : RunsTo inpSim
      [.stmt (runSubAndExtractStmt isDimD progSub flagVar flagIdx outVar nOutLoc loopIdxVar)]
      st₁ stFinal := by
    unfold runSubAndExtractStmt
    dsimp only
    dsimp only [countE, copyBody, T_max] at hs_rep
    exact RunsTo.seq hruns_enter
      (RunsTo.seq hs_flag
        (RunsTo.seq hs_l0
          (RunsTo.seq hs_rep
            (RunsTo.seq hs_clean hs_free99))))
  -- Assemble all final bounds!
  refine ⟨stFinal, htot, hwsFinal, rfl,
    hbsClean.trans (hbsAfter.trans hbsMid) ▸ hbs₁, ?_, ?_, ?_, ?_⟩
  · -- unitCost bound
    dsimp [stFinal, stRepInit, stL0, stF, Δu] at huClean huAfter huMid ⊢
    have hFU : 64 * F * outSub.unitCost + 16 * log.length ≤ 80 * F * (U_sub + 1) := by
      have h1 : 64 * F * outSub.unitCost ≤ 64 * F * U_sub :=
        Nat.mul_le_mul_left _ hsub_bounds.1
      have h2 : 16 * log.length ≤ 16 * F * U_sub := by
        have : 16 ≤ 16 * F := Nat.le_mul_of_pos_right 16 hF
        exact Nat.mul_le_mul this hlog_U
      have h3 : 64 * F * U_sub + 16 * F * U_sub ≤ 80 * F * (U_sub + 1) := by
        calc 64 * F * U_sub + 16 * F * U_sub = 80 * F * U_sub := by ring
          _ ≤ 80 * F * (U_sub + 1) := Nat.mul_le_mul_left _ (by omega)
      omega
    dsimp [F] at hFU ⊢
    omega
  · -- bitCost bound
    dsimp [stFinal, stRepInit, stL0, stF, Δb] at hbClean hbAfter hbMid ⊢
    have hK_le : 256 * F * (L_p + natBitLength T_max + 8) ^ 2 *
        (outSub.bitCost + outSub.unitCost + 16) * outSub.bitCost ≤ K_bit_max * B_sub := by
      dsimp [K_bit_max]
      exact Nat.mul_le_mul
        (Nat.mul_le_mul_left _ (by omega))
        hsub_bounds.2.1
    have hcl_le : (log.length + 2) * (8 * natBitLength (log.length + 2) + 4 * L_enc_max + 80) ≤
        (U_sub + 2) * (8 * natBitLength (U_sub + 2) + 4 * L_enc_max + 80) :=
      Nat.mul_le_mul (by omega) (by have := natBitLength_mono (by omega : log.length + 2 ≤ U_sub + 2); omega)
    have hfl_ib : intBitLength (flagIdx : ℤ) ≤ natBitLength A + 1 :=
      (intBitLength_natCast_le_succ flagIdx).trans
        (Nat.add_le_add_right (natBitLength_mono (le_of_lt hA.2.1)) 1)
    have hn10 : natBitLength 10 = 4 := by decide
    have hl99 : (RAMCellLoc.localFrame 1 99 0).bitLength = 9 := by decide
    have hnv_fl : natBitLength flagVar ≤ 7 :=
      (natBitLength_mono (by omega : flagVar ≤ 100)).trans (by decide)
    have hnv_lp : natBitLength loopIdxVar ≤ 7 :=
      (natBitLength_mono (by omega : loopIdxVar ≤ 100)).trans (by decide)
    have hloc_fl : (RAMCellLoc.localFrame 1 flagVar (flagIdx : ℤ)).bitLength ≤ natBitLength A + 10 := by
      dsimp [RAMCellLoc.bitLength]
      have hn1 : natBitLength 1 = 1 := rfl
      omega
    have hloc_lp : (RAMCellLoc.localFrame 1 loopIdxVar 0).bitLength ≤ 10 := by
      dsimp [RAMCellLoc.bitLength]
      have hn1 : natBitLength 1 = 1 := rfl
      have hi0 : intBitLength 0 = 1 := rfl
      omega
    have hsmall :
        32 + intBitLength (flagIdx : ℤ) + (1 + natBitLength 10 + 1 + intBitLength vFlag) +
          (RAMCellLoc.localFrame 1 flagVar (flagIdx : ℤ)).bitLength + intBitLength vFlag +
          1 + 1 + (RAMCellLoc.localFrame 1 loopIdxVar 0).bitLength + 1 +
          bc_cnt + 1 + 1 + (RAMCellLoc.localFrame 1 99 0).bitLength ≤ 4 * B_step := by
      rw [hn10, hl99]
      have h1 : 32 + intBitLength (flagIdx : ℤ) + (1 + 4 + 1 + intBitLength vFlag) +
          (RAMCellLoc.localFrame 1 flagVar (flagIdx : ℤ)).bitLength + intBitLength vFlag +
          1 + 1 + (RAMCellLoc.localFrame 1 loopIdxVar 0).bitLength + 1 +
          1 + 1 + 9 ≤ 16 * (natBitLength A + natBitLength T_max + V + 16) := by
        dsimp [vFlag]
        have := hV_flag
        omega
      omega
    have hN_split : (N_out + 4) * B_step = N_out * B_step + 4 * B_step := by ring
    dsimp [F, T_max] at hK_le hsmall hN_split hbc_le hbAfter ⊢
    dsimp [B_step, T_max] at hN_split hsmall hbc_le hbAfter ⊢
    omega
  · -- peakCellSpace bound
    obtain ⟨hmc0, _⟩ := inAttemptArena_size_le harena
    obtain ⟨hmcF, _⟩ := hmerge_bounds wsB₁ haB₁
    obtain ⟨hmcL0, _⟩ := hmerge_bounds wsB₂ haB₂
    obtain ⟨hmcN, _⟩ := hmerge_bounds wsBN haBN
    have hpcMid' : stMid.peakCellSpace ≤ max st₁.peakCellSpace C_call := by
      refine hpcMid.trans (max_le (le_max_left _ _) (le_trans ?_ (le_max_right _ _)))
      dsimp [C_call]; omega
    have hpcF' : stF.peakCellSpace ≤ max st₁.peakCellSpace C_call := by
      dsimp [stF]
      exact max_le hpcMid' (le_trans (by change inpSim.inputCellSpace + stF.words.cellCount ≤ C_call; rw [hwsF]; exact hmcF) (le_max_right _ _))
    have hpcL0' : stL0.peakCellSpace ≤ max st₁.peakCellSpace C_call := by
      dsimp [stL0]
      exact max_le hpcF' (le_trans (by change inpSim.inputCellSpace + stL0.words.cellCount ≤ C_call; rw [hwsL0]; exact hmcL0) (le_max_right _ _))
    have hpcAfter' : stAfterCopy.peakCellSpace ≤ max st₁.peakCellSpace C_call :=
      hpcAfter.trans (max_le hpcL0' (le_max_right _ _))
    dsimp [stFinal]
    refine hpcClean.trans (max_le hpcAfter' (le_trans ?_ (le_max_right _ _)))
    rw [hwsAfter]
    obtain ⟨hc_bn, _⟩ := inAttemptArena_size_le haBN
    have hmc_bn := simMergeStore_cellCount_le wsBN hT wsHeap log
    dsimp [C_call]; omega
  · -- peakBitSpace bound
    obtain ⟨_, hmb0⟩ := inAttemptArena_size_le harena
    obtain ⟨_, hmbF⟩ := hmerge_bounds wsB₁ haB₁
    obtain ⟨_, hmbL0⟩ := hmerge_bounds wsB₂ haB₂
    obtain ⟨_, hmbN⟩ := hmerge_bounds wsBN haBN
    have hpbMid' : stMid.peakBitSpace ≤ max st₁.peakBitSpace S_call := by
      refine hpbMid.trans (max_le (le_max_left _ _) (le_trans ?_ (le_max_right _ _)))
      have hm_sub : (natBitLength T_max + 12) * outSub.peakBitSpace ≤
          (natBitLength T_max + 12) * S_sub :=
        Nat.mul_le_mul_left _ hsub_bounds.2.2.2
      have hn_u : natBitLength (outSub.unitCost + 2) ≤ natBitLength (U_sub + 2) :=
        natBitLength_mono (by omega)
      have hm_u : (outSub.unitCost + 3) *
          (natBitLength (outSub.unitCost + 2) + (outSub.bitCost + 2 * natBitLength T_max + 6) + 12) ≤
          (U_sub + 3) * (natBitLength (U_sub + 2) + L_enc_max + 12) :=
        Nat.mul_le_mul (by omega) (by dsimp [L_enc_max]; omega)
      dsimp [S_call, L_enc_max, T_max] at hm_sub hm_u ⊢
      omega
    have hpbF' : stF.peakBitSpace ≤ max st₁.peakBitSpace S_call := by
      dsimp [stF]
      exact max_le hpbMid' (le_trans (by change inpSim.inputBitSpace + stF.words.bitSize ≤ S_call; rw [hwsF]; exact hmbF.trans (Nat.sub_le _ _)) (le_max_right _ _))
    have hpbL0' : stL0.peakBitSpace ≤ max st₁.peakBitSpace S_call := by
      dsimp [stL0]
      exact max_le hpbF' (le_trans (by change inpSim.inputBitSpace + stL0.words.bitSize ≤ S_call; rw [hwsL0]; exact hmbL0.trans (Nat.sub_le _ _)) (le_max_right _ _))
    have hpbAfter' : stAfterCopy.peakBitSpace ≤ max st₁.peakBitSpace S_call :=
      hpbAfter.trans (max_le hpbL0' (le_max_right _ _))
    dsimp [stFinal]
    refine hpbClean.trans (max_le hpbAfter' (le_trans ?_ (le_max_right _ _)))
    rw [hwsAfter]
    have hn_l2 : natBitLength (log.length + 2) ≤ natBitLength (U_sub + 2) :=
      natBitLength_mono (by omega)
    dsimp [S_call] at hmbN ⊢
    omega

end UL.Proof_lem_A_2
