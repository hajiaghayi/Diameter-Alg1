import Mathlib
import UL.Proof.lem_A_2.H2a_RAM
set_option autoImplicit false

namespace UL.Proof_lem_A_2

/-! ### 1. Output bit-length of `evalIntExpr` is at most its `bitOps` -/

theorem natBitLength_add_le (a b : ℕ) :
    natBitLength (a + b) ≤ max (natBitLength a) (natBitLength b) + 1 := by
  let L := max (natBitLength a) (natBitLength b)
  have ha : a < 2 ^ L := by
    have h1 : a < 2 ^ (Nat.log 2 a + 1) := Nat.lt_pow_succ_log_self (by norm_num) a
    exact h1.trans_le (Nat.pow_le_pow_right (by norm_num) (le_max_left _ _))
  have hb : b < 2 ^ L := by
    have h1 : b < 2 ^ (Nat.log 2 b + 1) := Nat.lt_pow_succ_log_self (by norm_num) b
    exact h1.trans_le (Nat.pow_le_pow_right (by norm_num) (le_max_right _ _))
  have hab : a + b < 2 ^ (L + 1) := by
    rw [pow_succ]
    omega
  rcases Nat.eq_zero_or_pos (a + b) with hz | hpos
  · rw [hz]; unfold natBitLength; simp
  · have hlog : Nat.log 2 (a + b) < L + 1 :=
      (Nat.log_lt_iff_lt_pow (by norm_num) hpos.ne').mpr hab
    dsimp [L] at hlog
    unfold natBitLength at hlog ⊢
    omega

theorem natBitLength_mul_le (a b : ℕ) :
    natBitLength (a * b) ≤ natBitLength a + natBitLength b := by
  have ha : a < 2 ^ (natBitLength a) := Nat.lt_pow_succ_log_self (by norm_num) a
  have hb : b < 2 ^ (natBitLength b) := Nat.lt_pow_succ_log_self (by norm_num) b
  have hab : a * b < 2 ^ (natBitLength a + natBitLength b) := by
    rw [pow_add]
    exact Nat.mul_lt_mul'' ha hb
  rcases Nat.eq_zero_or_pos (a * b) with hz | hpos
  · rw [hz]
    have h1 := natBitLength_pos a
    have h2 := natBitLength_pos b
    have h0 : natBitLength 0 = 1 := rfl
    omega
  · have hlog : Nat.log 2 (a * b) < natBitLength a + natBitLength b :=
      (Nat.log_lt_iff_lt_pow (by norm_num) hpos.ne').mpr hab
    unfold natBitLength at hlog ⊢
    omega

theorem intBitLength_neg (z : ℤ) : intBitLength (-z) = intBitLength z := by
  unfold intBitLength
  simp

theorem intBitLength_add_le (a b : ℤ) :
    intBitLength (a + b) ≤ intBitLength a + intBitLength b + 1 := by
  set S : ℕ := a.natAbs + b.natAbs
  have habs : (a + b).natAbs ≤ S := Int.natAbs_add_le a b
  have h1 : intBitLength (a + b) ≤ intBitLength (S : ℤ) + 1 :=
    intBitLength_mono_natAbs (by rw [Int.natAbs_natCast]; exact habs)
  have h2 : natBitLength S ≤ max (natBitLength a.natAbs) (natBitLength b.natAbs) + 1 :=
    natBitLength_add_le a.natAbs b.natAbs
  have hS : intBitLength (S : ℤ) ≤ 1 + natBitLength S := by
    unfold intBitLength
    split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
  have ha1 : natBitLength a.natAbs ≤ intBitLength a := by
    unfold intBitLength
    by_cases ha : a = 0
    · subst ha; decide
    · simp [ha]
  have hb1 : natBitLength b.natAbs ≤ intBitLength b := by
    unfold intBitLength
    by_cases hb : b = 0
    · subst hb; decide
    · simp [hb]
  by_cases ha0 : a = 0
  · subst ha0; simp only [zero_add]; have : intBitLength 0 = 1 := rfl; omega
  · by_cases hb0 : b = 0
    · subst hb0; simp only [add_zero]; have : intBitLength 0 = 1 := rfl; omega
    · have ha2 : intBitLength a = 1 + natBitLength a.natAbs := by simp [intBitLength, ha0]
      have hb2 : intBitLength b = 1 + natBitLength b.natAbs := by simp [intBitLength, hb0]
      omega

theorem intBitLength_sub_le (a b : ℤ) :
    intBitLength (a - b) ≤ intBitLength a + intBitLength b + 1 := by
  rw [sub_eq_add_neg, ← intBitLength_neg b]
  exact intBitLength_add_le a (-b)

theorem intBitLength_mul_le (a b : ℤ) :
    intBitLength (a * b) ≤ intBitLength a + intBitLength b := by
  by_cases ha : a = 0
  · subst ha; simp [intBitLength]
  · by_cases hb : b = 0
    · subst hb; simp [intBitLength]
    · have hmul : a * b ≠ 0 := mul_ne_zero ha hb
      unfold intBitLength
      simp only [ha, hb, hmul, ↓reduceIte, Int.natAbs_mul]
      have := natBitLength_mul_le a.natAbs b.natAbs
      omega

theorem evalIntExpr_bitLen_le {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore) :
    ∀ e : IntExpr,
      let (v, u, b) := evalIntExpr inp fd ws e
      1 ≤ u ∧ 1 ≤ b ∧ intBitLength v ≤ b
  | .lit c => ⟨le_rfl, intBitLength_pos c, le_rfl⟩
  | .dim => ⟨le_rfl, intBitLength_pos _, le_rfl⟩
  | .intParam idxE => by
      rcases h : evalIntExpr inp fd ws idxE with ⟨idx, u, b⟩
      simp only [evalIntExpr, h]
      exact ⟨by omega, by have := intBitLength_pos idx; omega, by omega⟩
  | .readHeap table idxE => by
      rcases h : evalIntExpr inp fd ws idxE with ⟨idx, u, b⟩
      simp only [evalIntExpr, h]
      exact ⟨by omega, by have := intBitLength_pos idx; omega, by omega⟩
  | .readLocal var idxE => by
      rcases h : evalIntExpr inp fd ws idxE with ⟨idx, u, b⟩
      simp only [evalIntExpr, h]
      exact ⟨by omega, by have := intBitLength_pos idx; omega, by omega⟩
  | .activeRatNum hE cE => by
      rcases h1 : evalIntExpr inp fd ws hE with ⟨h, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws cE with ⟨c, u₂, b₂⟩
      simp only [evalIntExpr, h1, h2]
      exact ⟨by omega, by have := intBitLength_pos h; omega, by omega⟩
  | .activeRatDen hE cE => by
      rcases h1 : evalIntExpr inp fd ws hE with ⟨h, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws cE with ⟨c, u₂, b₂⟩
      simp only [evalIntExpr, h1, h2]
      exact ⟨by omega, by have := intBitLength_pos h; omega, by omega⟩
  | .extraRatNum idxE => by
      rcases h : evalIntExpr inp fd ws idxE with ⟨idx, u, b⟩
      simp only [evalIntExpr, h]
      exact ⟨by omega, by have := intBitLength_pos idx; omega, by omega⟩
  | .extraRatDen idxE => by
      rcases h : evalIntExpr inp fd ws idxE with ⟨idx, u, b⟩
      simp only [evalIntExpr, h]
      exact ⟨by omega, by have := intBitLength_pos idx; omega, by omega⟩
  | .neg e => by
      have ih := evalIntExpr_bitLen_le inp fd ws e
      rcases h : evalIntExpr inp fd ws e with ⟨v, u, b⟩
      simp only [h] at ih
      simp only [evalIntExpr, h, intBitLength_neg]
      exact ⟨by omega, by omega, by omega⟩
  | .add e₁ e₂ => by
      have ih₁ := evalIntExpr_bitLen_le inp fd ws e₁
      have ih₂ := evalIntExpr_bitLen_le inp fd ws e₂
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [h1] at ih₁; simp only [h2] at ih₂
      simp only [evalIntExpr, h1, h2]
      have hadd := intBitLength_add_le v₁ v₂
      exact ⟨by omega, by omega, by omega⟩
  | .sub e₁ e₂ => by
      have ih₁ := evalIntExpr_bitLen_le inp fd ws e₁
      have ih₂ := evalIntExpr_bitLen_le inp fd ws e₂
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [h1] at ih₁; simp only [h2] at ih₂
      simp only [evalIntExpr, h1, h2]
      have hsub := intBitLength_sub_le v₁ v₂
      exact ⟨by omega, by omega, by omega⟩
  | .mul e₁ e₂ => by
      have ih₁ := evalIntExpr_bitLen_le inp fd ws e₁
      have ih₂ := evalIntExpr_bitLen_le inp fd ws e₂
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [h1] at ih₁; simp only [h2] at ih₂
      simp only [evalIntExpr, h1, h2]
      have hmul := intBitLength_mul_le v₁ v₂
      exact ⟨by omega, by omega, by omega⟩
  | .div e₁ e₂ => by
      have ih₁ := evalIntExpr_bitLen_le inp fd ws e₁
      have ih₂ := evalIntExpr_bitLen_le inp fd ws e₂
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [h1] at ih₁; simp only [h2] at ih₂
      simp only [evalIntExpr, h1, h2]
      have hdiv_abs : (v₁ / v₂).natAbs ≤ v₁.natAbs + 1 := by
        rw [Int.natAbs_ediv]
        have := Nat.div_le_self v₁.natAbs v₂.natAbs
        split_ifs <;> omega
      set S : ℕ := v₁.natAbs + 1
      have hdiv : intBitLength (v₁ / v₂) ≤ intBitLength (S : ℤ) + 1 :=
        intBitLength_mono_natAbs (by rw [Int.natAbs_natCast]; exact hdiv_abs)
      have hlen1 : intBitLength (S : ℤ) ≤ intBitLength v₁ + 2 := by
        have hn_add := natBitLength_add_le v₁.natAbs 1
        have hn1 : natBitLength 1 = 1 := rfl
        have hS_ne : (S : ℤ) ≠ 0 := by exact_mod_cast (show S ≠ 0 by dsimp [S]; omega)
        have hS_ib : intBitLength (S : ℤ) = 1 + natBitLength (v₁.natAbs + 1) := by
          unfold intBitLength; rw [if_neg hS_ne, Int.natAbs_natCast]
        have hv1_pos := intBitLength_pos v₁
        by_cases hv0 : v₁ = 0
        · subst hv0; dsimp [S] at hS_ib ⊢; rw [hS_ib]; decide
        · have hv_ib : intBitLength v₁ = 1 + natBitLength v₁.natAbs := by simp [intBitLength, hv0]
          omega
      have hb1 := intBitLength_pos v₁
      have hb2 := intBitLength_pos v₂
      exact ⟨by omega, by omega, by
        by_cases hmul2 : intBitLength v₁ ≤ intBitLength v₁ * intBitLength v₂
        · have h12 : 3 ≤ b₁ + b₂ + 1 := by omega
          by_cases hv0 : v₁ = 0
          · subst hv0; simp only [Int.zero_ediv]; have : intBitLength 0 = 1 := rfl; omega
          · by_cases hv2_0 : v₂ = 0
            · subst hv2_0; simp only [Int.ediv_zero]; have : intBitLength 0 = 1 := rfl; omega
            · have hv2_ge2 : 2 ≤ intBitLength v₂ := by
                have := natBitLength_pos v₂.natAbs
                simp [intBitLength, hv2_0]; omega
              nlinarith
        · nlinarith⟩
  | .mod e₁ e₂ => by
      have ih₁ := evalIntExpr_bitLen_le inp fd ws e₁
      have ih₂ := evalIntExpr_bitLen_le inp fd ws e₂
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [h1] at ih₁; simp only [h2] at ih₂
      simp only [evalIntExpr, h1, h2]
      exact ⟨by omega, by omega, by
        by_cases hv₂ : v₂ = 0
        · subst hv₂; simp only [Int.emod_zero]; omega
        · have hm0 : 0 ≤ v₁ % v₂ := Int.emod_nonneg v₁ hv₂
          have hm1 : v₁ % v₂ < |v₂| := Int.emod_lt_abs v₁ hv₂
          have habs : (v₁ % v₂).natAbs ≤ v₂.natAbs := by
            have hcast : ((v₁ % v₂).natAbs : ℤ) < (v₂.natAbs : ℤ) := by
              rw [Int.natAbs_of_nonneg hm0, Int.natCast_natAbs]
              exact hm1
            omega
          have hmod := intBitLength_mono_natAbs habs
          omega⟩

/-! ### 2. Arithmetic range indicator `inRangeExpr` and syntax bounds -/

/-- Evaluates to `1` if `0 ≤ x < N` (for `1 ≤ N`) and `0` otherwise, using Euclidean division. -/
def inRangeExpr (xE NE : IntExpr) : IntExpr :=
  let qE := IntExpr.div xE NE
  IntExpr.div (.lit 1) (.add (.lit 1) (.mul qE qE))

theorem inRange_val_eq {x N : ℤ} (hN : 1 ≤ N) :
    (1 : ℤ) / (1 + (x / N) * (x / N)) = if 0 ≤ x ∧ x < N then 1 else 0 := by
  split_ifs with h
  · have hq0 : x / N = 0 := Int.ediv_eq_zero_of_lt h.1 h.2
    rw [hq0]
    norm_num
  · have hq_ne : x / N ≠ 0 := by
      intro hq0
      apply h
      have hmod := Int.ediv_add_emod x N
      rw [hq0, mul_zero, zero_add] at hmod
      have hm0 : 0 ≤ x % N := Int.emod_nonneg x (by omega)
      have hm1 : x % N < N := Int.emod_lt_of_pos x (by omega)
      exact ⟨by omega, by omega⟩
    have hsq_pos : 1 ≤ (x / N) * (x / N) := by
      rcases lt_or_gt_of_ne hq_ne with hlt | hgt
      · have hle : x / N ≤ -1 := by omega
        nlinarith
      · have hge : 1 ≤ x / N := by omega
        nlinarith
    exact Int.ediv_eq_zero_of_lt (by omega) (by omega)

/-- Max heap table index + 1 appearing in an `IntExpr`, `BitCondExpr`, or `BitRAMStmt`. -/
def maxTableExpr : IntExpr → ℕ
  | .lit _ | .dim => 1
  | .intParam e | .extraRatNum e | .extraRatDen e | .neg e => maxTableExpr e
  | .readHeap t e => max (t + 1) (maxTableExpr e)
  | .readLocal _ e => maxTableExpr e
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂
  | .add e₁ e₂ | .sub e₁ e₂ | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ =>
      max (maxTableExpr e₁) (maxTableExpr e₂)

def maxTableCond : BitCondExpr → ℕ
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => max (maxTableExpr e₁) (maxTableExpr e₂)
  | .not c => maxTableCond c
  | .and c₁ c₂ | .or c₁ c₂ => max (maxTableCond c₁) (maxTableCond c₂)

def maxTableStmt : BitRAMStmt → ℕ
  | .skip => 1
  | .writeHeap t e₁ e₂ => max (t + 1) (max (maxTableExpr e₁) (maxTableExpr e₂))
  | .writeLocal _ e₁ e₂ => max (maxTableExpr e₁) (maxTableExpr e₂)
  | .freeHeap t e | .randBitHeap t e => max (t + 1) (maxTableExpr e)
  | .freeLocal _ e | .randBitLocal _ e | .repeatN e _ => maxTableExpr e
  | .seq s₁ s₂ => max (maxTableStmt s₁) (maxTableStmt s₂)
  | .ite c s₁ s₂ => max (maxTableCond c) (max (maxTableStmt s₁) (maxTableStmt s₂))
  | .whileLoop c body => max (maxTableCond c) (maxTableStmt body)
  | .localScope body => maxTableStmt body

-- Fix repeatN to also include body!
def maxTableStmtFull : BitRAMStmt → ℕ
  | .skip => 1
  | .writeHeap t e₁ e₂ => max (t + 1) (max (maxTableExpr e₁) (maxTableExpr e₂))
  | .writeLocal _ e₁ e₂ => max (maxTableExpr e₁) (maxTableExpr e₂)
  | .freeHeap t e | .randBitHeap t e => max (t + 1) (maxTableExpr e)
  | .freeLocal _ e | .randBitLocal _ e => maxTableExpr e
  | .repeatN e body => max (maxTableExpr e) (maxTableStmtFull body)
  | .seq s₁ s₂ => max (maxTableStmtFull s₁) (maxTableStmtFull s₂)
  | .ite c s₁ s₂ => max (maxTableCond c) (max (maxTableStmtFull s₁) (maxTableStmtFull s₂))
  | .whileLoop c body => max (maxTableCond c) (maxTableStmtFull body)
  | .localScope body => maxTableStmtFull body

theorem maxTableExpr_pos (e : IntExpr) : 1 ≤ maxTableExpr e := by
  induction e <;> simp [maxTableExpr] <;> omega

theorem maxTableCond_pos (c : BitCondExpr) : 1 ≤ maxTableCond c := by
  induction c with
  | intEq e₁ _ | intLt e₁ _ | intLe e₁ _ =>
      simp only [maxTableCond]; have := maxTableExpr_pos e₁; omega
  | not _ ih => simpa [maxTableCond] using ih
  | and _ _ ih₁ _ | or _ _ ih₁ _ =>
      simp only [maxTableCond]; omega

theorem maxTableStmtFull_pos (s : BitRAMStmt) : 1 ≤ maxTableStmtFull s := by
  induction s with
  | skip => decide
  | writeHeap _ _ _ | freeHeap _ _ | randBitHeap _ _ =>
      simp [maxTableStmtFull]
  | writeLocal _ e₁ _ =>
      simp only [maxTableStmtFull]; have := maxTableExpr_pos e₁; omega
  | freeLocal _ e | randBitLocal _ e =>
      simpa [maxTableStmtFull] using maxTableExpr_pos e
  | repeatN e _ _ =>
      simp only [maxTableStmtFull]; have := maxTableExpr_pos e; omega
  | seq _ _ ih₁ _ | localScope _ ih₁ =>
      simp only [maxTableStmtFull]; omega
  | ite c _ _ _ _ | whileLoop c _ _ =>
      simp only [maxTableStmtFull]; have := maxTableCond_pos c; omega

/-! ### 3. Disjoint region embedding `shiftSubEmb` and `simMergeStore` -/

def IsSimBaseStore (wsBase : WordStore) : Prop :=
  WellFormedWS wsBase ∧
  ∀ loc ∈ wsBase.live,
    (∃ t idx, t < 8 ∧ loc = .heap t idx) ∨
    (∃ var idx, loc = .localFrame 1 var idx)

@[simp] def isHeapLoc : RAMCellLoc → Bool
  | .heap _ _ => true
  | .localFrame _ _ _ => false

def heapOnlyStore (ws : WordStore) : WordStore where
  live := ws.live.filter (fun loc => isHeapLoc loc = true)
  vals := fun loc => match loc with | .heap t idx => ws.vals (.heap t idx) | .localFrame _ _ _ => 0

theorem wellFormedWS_heapOnlyStore {ws : WordStore} (h : WellFormedWS ws) :
    WellFormedWS (heapOnlyStore ws) := by
  intro loc hloc
  cases loc with
  | localFrame _ _ _ => rfl
  | heap t idx =>
      simp only [heapOnlyStore, Finset.mem_filter, isHeapLoc, and_true] at hloc
      exact h (.heap t idx) hloc

theorem heapOnlyStore_read_heap (ws : WordStore) (t : ℕ) (idx : ℤ) :
    (heapOnlyStore ws).read (.heap t idx) = (ws.popDepth 0).read (.heap t idx) := by
  simp [heapOnlyStore, WordStore.popDepth, WordStore.read, RAMCellLoc.keepAtDepth]

def shiftSubLoc (T_max : ℕ) : RAMCellLoc → RAMCellLoc
  | .heap t idx =>
      if t < T_max then .heap 10 (idx * (T_max : ℤ) + (t : ℤ))
      else .heap (13 + t) idx
  | .localFrame d var idx => .localFrame (2 + d) var idx

theorem shiftSubLoc_injective {T_max : ℕ} (hT : 1 ≤ T_max) :
    Function.Injective (shiftSubLoc T_max) := by
  intro u₁ u₂ heq
  cases u₁ with
  | heap t₁ idx₁ =>
      cases u₂ with
      | localFrame _ _ _ =>
          dsimp [shiftSubLoc] at heq; split_ifs at heq <;> nomatch heq
      | heap t₂ idx₂ =>
          dsimp [shiftSubLoc] at heq
          by_cases h1 : t₁ < T_max <;> by_cases h2 : t₂ < T_max
          · simp only [h1, h2, ↓reduceIte, RAMCellLoc.heap.injEq, true_and] at heq
            have hT_z : (0 : ℤ) < (T_max : ℤ) := by exact_mod_cast hT
            have hmod := congrArg (· % (T_max : ℤ)) heq
            dsimp only at hmod
            rw [Int.mul_add_emod_self_right, Int.emod_eq_of_lt (by positivity) (by exact_mod_cast h1),
              Int.mul_add_emod_self_right, Int.emod_eq_of_lt (by positivity) (by exact_mod_cast h2)] at hmod
            have ht_eq : t₁ = t₂ := by exact_mod_cast hmod
            subst ht_eq
            have hidx_eq : idx₁ = idx₂ := mul_right_cancel₀ hT_z.ne' (by linarith)
            subst hidx_eq
            rfl
          · simp only [h1, h2, ↓reduceIte, RAMCellLoc.heap.injEq] at heq; omega
          · simp only [h1, h2, ↓reduceIte, RAMCellLoc.heap.injEq] at heq; omega
          · simp only [h1, h2, ↓reduceIte, RAMCellLoc.heap.injEq] at heq
            obtain ⟨ht, hi⟩ := heq
            have : t₁ = t₂ := by omega
            subst this; subst hi; rfl
  | localFrame d₁ v₁ i₁ =>
      cases u₂ with
      | heap _ _ =>
          dsimp [shiftSubLoc] at heq; split_ifs at heq <;> nomatch heq
      | localFrame d₂ v₂ i₂ =>
          dsimp [shiftSubLoc] at heq
          injection heq with hd hv hi
          have : d₁ = d₂ := by omega
          subst this; subst hv; subst hi; rfl

def shiftSubEmb (T_max : ℕ) (hT : 1 ≤ T_max) : RAMCellLoc ↪ RAMCellLoc :=
  ⟨shiftSubLoc T_max, shiftSubLoc_injective hT⟩

def heap11Emb : ℕ ↪ RAMCellLoc :=
  ⟨fun k => .heap 11 (k : ℤ), fun a b h => by injection h with _ h'; exact_mod_cast h'⟩

def logLiveFinset (log : List ℤ) : Finset RAMCellLoc :=
  insert (.heap 12 0) ((Finset.range log.length).map heap11Emb)

def simMergeVals (wsBase : WordStore) (T_max : ℕ) (wsSub : WordStore) (log : List ℤ) :
    RAMCellLoc → ℤ
  | .heap t idx =>
      if t < 8 then wsBase.vals (.heap t idx)
      else if t = 10 then
        let r := idx % (T_max : ℤ)
        let q := idx / (T_max : ℤ)
        if 0 ≤ r ∧ r.toNat < T_max then wsSub.vals (.heap r.toNat q) else 0
      else if t = 11 then
        if 0 ≤ idx ∧ idx.toNat < log.length then log.getD idx.toNat 0 else 0
      else if t = 12 then
        if idx = 0 then (log.length : ℤ) else 0
      else if 13 ≤ t ∧ T_max ≤ t - 13 then
        wsSub.vals (.heap (t - 13) idx)
      else 0
  | .localFrame d var idx =>
      if d = 1 then wsBase.vals (.localFrame 1 var idx)
      else if 2 ≤ d then wsSub.vals (.localFrame (d - 2) var idx)
      else 0

def simMergeStore (wsBase : WordStore) (T_max : ℕ) (hT : 1 ≤ T_max)
    (wsSub : WordStore) (log : List ℤ) : WordStore where
  live := wsBase.live ∪ wsSub.live.map (shiftSubEmb T_max hT) ∪ logLiveFinset log
  vals := simMergeVals wsBase T_max wsSub log

theorem shiftSubLoc_not_in_base {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    (T_max : ℕ) (u : RAMCellLoc) :
    shiftSubLoc T_max u ∉ wsBase.live := by
  intro hm
  rcases hbase.2 _ hm with ⟨t, idx, ht8, heq⟩ | ⟨var, idx, heq⟩
  · cases u with
    | localFrame _ _ _ => dsimp [shiftSubLoc] at heq; nomatch heq
    | heap tu iu =>
        dsimp [shiftSubLoc] at heq
        split_ifs at heq <;> (injection heq with ht _; omega)
  · cases u with
    | heap _ _ => dsimp [shiftSubLoc] at heq; split_ifs at heq <;> nomatch heq
    | localFrame du _ _ =>
        dsimp [shiftSubLoc] at heq; injection heq with hd _ _; omega

theorem shiftSubLoc_not_in_log (T_max : ℕ) (log : List ℤ) (u : RAMCellLoc) :
    shiftSubLoc T_max u ∉ logLiveFinset log := by
  simp only [logLiveFinset, Finset.mem_insert, Finset.mem_map, heap11Emb,
    Function.Embedding.coeFn_mk, Finset.mem_range, not_or, not_exists, not_and]
  cases u with
  | localFrame _ _ _ =>
      dsimp [shiftSubLoc]
      exact ⟨(fun h => nomatch h), (fun _ _ h => nomatch h)⟩
  | heap _ _ =>
      dsimp [shiftSubLoc]
      split_ifs <;> refine ⟨(fun h => by injection h with ht _; omega),
        (fun _ _ h => by injection h with ht _; omega)⟩

theorem shiftSubLoc_vals_eq (wsBase : WordStore) {T_max : ℕ} (hT : 1 ≤ T_max)
    (wsSub : WordStore) (log : List ℤ) (u : RAMCellLoc) :
    simMergeVals wsBase T_max wsSub log (shiftSubLoc T_max u) = wsSub.vals u := by
  cases u with
  | localFrame d var idx =>
      have hd1 : 2 + d ≠ 1 := by omega
      have hd2 : 2 ≤ 2 + d := by omega
      have hdsub : 2 + d - 2 = d := by omega
      simp [shiftSubLoc, simMergeVals, hd1, hd2, hdsub]
  | heap t idx =>
      dsimp only [shiftSubLoc]
      split_ifs with ht
      · have hT_z : (0 : ℤ) < (T_max : ℤ) := by exact_mod_cast hT
        have hrem : (idx * (T_max : ℤ) + (t : ℤ)) % (T_max : ℤ) = (t : ℤ) := by
          rw [Int.mul_add_emod_self_right]
          exact Int.emod_eq_of_lt (by positivity) (by exact_mod_cast ht)
        have hdiv : (idx * (T_max : ℤ) + (t : ℤ)) / (T_max : ℤ) = idx := by
          rw [Int.mul_add_ediv_right _ _ hT_z.ne',
            Int.ediv_eq_zero_of_lt (by positivity) (by exact_mod_cast ht), add_zero]
        simp [simMergeVals, hrem, hdiv, ht]
      · have hnot8 : ¬ (13 + t < 8) := by omega
        have hne10 : 13 + t ≠ 10 := by omega
        have hne11 : 13 + t ≠ 11 := by omega
        have hne12 : 13 + t ≠ 12 := by omega
        have hge13 : 13 ≤ 13 + t ∧ T_max ≤ 13 + t - 13 := by omega
        have hsub : 13 + t - 13 = t := by omega
        dsimp only [simMergeVals]
        rw [if_neg hnot8, if_neg hne10, if_neg hne11, if_neg hne12, if_pos hge13, hsub]

theorem wellFormedWS_simMergeStore {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) {wsSub : WordStore} (hsub : WellFormedWS wsSub)
    (log : List ℤ) :
    WellFormedWS (simMergeStore wsBase T_max hT wsSub log) := by
  intro loc hloc
  simp only [simMergeStore, Finset.mem_union, Finset.mem_map, logLiveFinset,
    Finset.mem_insert, heap11Emb, Function.Embedding.coeFn_mk, Finset.mem_range,
    not_or, not_exists, not_and] at hloc
  obtain ⟨⟨hnb, hns⟩, hnl0, hnl11⟩ := hloc
  dsimp only [simMergeStore]
  cases loc with
  | localFrame d var idx =>
      dsimp only [simMergeVals]
      split_ifs with hd1 hd2
      · subst hd1; exact hbase.1 _ hnb
      · exact hsub (.localFrame (d - 2) var idx) fun hm =>
          hns _ hm (by simp [shiftSubEmb, shiftSubLoc]; omega)
      · rfl
  | heap t idx =>
      dsimp only [simMergeVals]
      by_cases ht8 : t < 8
      · rw [if_pos ht8]; exact hbase.1 _ hnb
      · rw [if_neg ht8]
        by_cases ht10 : t = 10
        · rw [if_pos ht10]; subst ht10
          split_ifs with hr
          · let r := idx % (T_max : ℤ)
            let q := idx / (T_max : ℤ)
            refine hsub (.heap r.toNat q) fun hm => hns (.heap r.toNat q) hm ?_
            dsimp only [r, q]
            simp only [shiftSubEmb, Function.Embedding.coeFn_mk, shiftSubLoc, hr.2, ↓reduceIte,
              RAMCellLoc.heap.injEq, true_and]
            rw [Int.toNat_of_nonneg hr.1, mul_comm, Int.mul_ediv_add_emod]
          · rfl
        · rw [if_neg ht10]
          by_cases ht11 : t = 11
          · rw [if_pos ht11]; subst ht11
            split_ifs with hk
            · exfalso; apply hnl11 idx.toNat hk.2; rw [Int.toNat_of_nonneg hk.1]
            · rfl
          · rw [if_neg ht11]
            by_cases ht12 : t = 12
            · rw [if_pos ht12]; subst ht12
              split_ifs with h0
              · exfalso; exact hnl0 (h0 ▸ rfl)
              · rfl
            · rw [if_neg ht12]
              by_cases ht13 : 13 ≤ t ∧ T_max ≤ t - 13
              · rw [if_pos ht13]
                refine hsub (.heap (t - 13) idx) fun hm => hns (.heap (t - 13) idx) hm ?_
                simp only [shiftSubEmb, Function.Embedding.coeFn_mk, shiftSubLoc]
                have hnot_lt : ¬ (t - 13 < T_max) := by omega
                simp only [hnot_lt, ↓reduceIte, RAMCellLoc.heap.injEq, and_true]
                omega
              · rw [if_neg ht13]

theorem popDepth_one_of_isSimBaseStore {wsBase : WordStore} (hbase : IsSimBaseStore wsBase) :
    wsBase.popDepth 1 = wsBase := by
  cases wsBase with
  | mk live vals =>
    unfold WordStore.popDepth
    congr 1
    · ext l
      simp only [Finset.mem_filter, and_iff_left_iff_imp]
      intro hl
      rcases hbase.2 l hl with ⟨_, _, _, rfl⟩ | ⟨_, _, rfl⟩ <;> rfl
    · funext l
      cases l with
      | heap _ _ => rfl
      | localFrame d v idx =>
          dsimp only
          split_ifs with hk
          · rfl
          · symm
            apply hbase.1 (.localFrame d v idx)
            intro hm
            rcases hbase.2 _ hm with ⟨_, _, _, hc⟩ | ⟨_, _, hc⟩
            · nomatch hc
            · injection hc with hd _ _
              subst hd
              simp [RAMCellLoc.keepAtDepth] at hk

theorem simMergeStore_init {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) :
    (wsBase.write (.heap 12 0) 0).popDepth 1 =
      simMergeStore wsBase T_max hT WordStore.empty [] := by
  have hnot_base_ge8 : ∀ (t : ℕ) (idx : ℤ), 8 ≤ t → wsBase.vals (.heap t idx) = 0 := by
    intro t idx ht
    refine hbase.1 (.heap t idx) fun hm => ?_
    rcases hbase.2 _ hm with ⟨t', _, ht', hc⟩ | ⟨_, _, hc⟩
    · injection hc with heq _; omega
    · nomatch hc
  have hnot_base_fd : ∀ (d var : ℕ) (idx : ℤ), d ≠ 1 → wsBase.vals (.localFrame d var idx) = 0 := by
    intro d var idx hd
    refine hbase.1 (.localFrame d var idx) fun hm => ?_
    rcases hbase.2 _ hm with ⟨_, _, _, hc⟩ | ⟨_, _, hc⟩
    · nomatch hc
    · injection hc with heq _ _; exact hd heq
  cases wsBase with
  | mk live vals =>
    unfold WordStore.popDepth WordStore.write simMergeStore
    congr 1
    · ext l
      simp only [Finset.mem_filter, Finset.mem_insert, Finset.mem_union, WordStore.empty,
        Finset.map_empty, Finset.union_empty, logLiveFinset, List.length_nil, Finset.range_zero,
        Finset.notMem_empty, or_false]
      constructor
      · rintro ⟨rfl | hl, _⟩
        · exact Or.inr rfl
        · exact Or.inl hl
      · rintro (hl | rfl)
        · refine ⟨Or.inr hl, ?_⟩
          rcases hbase.2 l hl with ⟨_, _, _, rfl⟩ | ⟨_, _, rfl⟩ <;> rfl
        · exact ⟨Or.inl rfl, rfl⟩
    · funext l
      cases l with
      | localFrame d var idx =>
          have hne : RAMCellLoc.localFrame d var idx ≠ .heap 12 0 := by intro h; nomatch h
          simp only [Function.update_of_ne hne]
          dsimp [simMergeVals, RAMCellLoc.keepAtDepth, WordStore.empty]
          by_cases hd1 : d = 1
          · subst hd1; simp
          · simp only [hd1, ↓reduceIte]
            by_cases hk : d ≤ 1 <;> by_cases hd2 : 2 ≤ d <;> simp [hk, hd2]
            · omega
            · exact hnot_base_fd d var idx hd1
      | heap t idx =>
          simp only [RAMCellLoc.keepAtDepth, ↓reduceIte]
          by_cases h12_0 : t = 12 ∧ idx = 0
          · rcases h12_0 with ⟨rfl, rfl⟩
            simp [simMergeVals]
          · have hne : RAMCellLoc.heap t idx ≠ .heap 12 0 := by
              intro hc; injection hc with ht hi; exact h12_0 ⟨ht, hi⟩
            rw [Function.update_of_ne hne]
            dsimp only [simMergeVals, WordStore.empty]
            by_cases ht8 : t < 8
            · rw [if_pos ht8]
            · rw [if_neg ht8]
              have hzero : vals (.heap t idx) = 0 := hnot_base_ge8 t idx (by omega)
              rw [hzero]
              by_cases ht10 : t = 10
              · rw [if_pos ht10]; split_ifs <;> rfl
              · rw [if_neg ht10]
                by_cases ht11 : t = 11
                · rw [if_pos ht11]; simp
                · rw [if_neg ht11]
                  by_cases ht12 : t = 12
                  · rw [if_pos ht12]; subst ht12
                    have hi0 : idx ≠ 0 := fun h => h12_0 ⟨rfl, h⟩
                    simp [hi0]
                  · rw [if_neg ht12]; split_ifs <;> rfl

theorem simMergeStore_read_base_heap {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) {wsSub : WordStore} (hsub : WellFormedWS wsSub)
    (log : List ℤ) {t : ℕ} (ht : t < 8) (idx : ℤ) :
    (simMergeStore wsBase T_max hT wsSub log).read (.heap t idx) = wsBase.read (.heap t idx) := by
  rw [wordStore_read_eq_vals (wellFormedWS_simMergeStore hbase hT hsub log),
    wordStore_read_eq_vals hbase.1]
  simp [simMergeStore, simMergeVals, ht]

theorem simMergeStore_read_sub {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) {wsSub : WordStore} (hsub : WellFormedWS wsSub)
    (log : List ℤ) (u : RAMCellLoc) :
    (simMergeStore wsBase T_max hT wsSub log).read (shiftSubLoc T_max u) = wsSub.read u := by
  rw [wordStore_read_eq_vals (wellFormedWS_simMergeStore hbase hT hsub log),
    wordStore_read_eq_vals hsub]
  exact shiftSubLoc_vals_eq wsBase hT wsSub log u

theorem simMergeStore_read_logLen {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) {wsSub : WordStore} (hsub : WellFormedWS wsSub)
    (log : List ℤ) :
    (simMergeStore wsBase T_max hT wsSub log).read (.heap 12 0) = (log.length : ℤ) := by
  rw [wordStore_read_eq_vals (wellFormedWS_simMergeStore hbase hT hsub log)]
  simp [simMergeStore, simMergeVals]

theorem simMergeStore_read_logEntry {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) {wsSub : WordStore} (hsub : WellFormedWS wsSub)
    (log : List ℤ) {j : ℕ} (hj : j < log.length) :
    (simMergeStore wsBase T_max hT wsSub log).read (.heap 11 (j : ℤ)) = log.getD j 0 := by
  rw [wordStore_read_eq_vals (wellFormedWS_simMergeStore hbase hT hsub log)]
  simp [simMergeStore, simMergeVals, hj]

theorem simMergeStore_write_sub {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) (wsSub : WordStore) (log : List ℤ)
    (u : RAMCellLoc) (val : ℤ) :
    (simMergeStore wsBase T_max hT wsSub log).write (shiftSubLoc T_max u) val =
      simMergeStore wsBase T_max hT (wsSub.write u val) log := by
  unfold WordStore.write simMergeStore
  congr 1
  · ext l
    dsimp only
    simp only [Finset.mem_insert, Finset.mem_union, Finset.mem_map, shiftSubEmb,
      Function.Embedding.coeFn_mk]
    constructor
    · rintro (rfl | (hb | ⟨u', hu', rfl⟩) | hl)
      · exact Or.inl (Or.inr ⟨u, Or.inl rfl, rfl⟩)
      · exact Or.inl (Or.inl hb)
      · exact Or.inl (Or.inr ⟨u', Or.inr hu', rfl⟩)
      · exact Or.inr hl
    · rintro ((hb | ⟨u', rfl | hu', rfl⟩) | hl)
      · exact Or.inr (Or.inl (Or.inl hb))
      · exact Or.inl rfl
      · exact Or.inr (Or.inl (Or.inr ⟨u', hu', rfl⟩))
      · exact Or.inr (Or.inr hl)
  · funext l
    by_cases hl : l = shiftSubLoc T_max u
    · subst hl
      rw [Function.update_self, shiftSubLoc_vals_eq wsBase hT _ log u]
      simp [WordStore.write]
    · rw [Function.update_of_ne hl]
      cases l with
      | localFrame d var idx =>
          dsimp [simMergeVals, WordStore.write]
          split_ifs with hd1 hd2
          · rfl
          · have hne : RAMCellLoc.localFrame (d - 2) var idx ≠ u := by
              intro rfl; apply hl; simp [shiftSubLoc]; omega
            rw [Function.update_of_ne hne]
          · rfl
      | heap t idx =>
          dsimp only [simMergeVals, WordStore.write]
          by_cases ht8 : t < 8
          · rw [if_pos ht8, if_pos ht8]
          · rw [if_neg ht8, if_neg ht8]
            by_cases ht10 : t = 10
            · rw [if_pos ht10, if_pos ht10]; subst ht10
              split_ifs with hr
              · have hne : RAMCellLoc.heap (idx % (T_max : ℤ)).toNat (idx / (T_max : ℤ)) ≠ u := by
                  intro rfl; apply hl
                  simp only [shiftSubLoc, hr.2, ↓reduceIte, RAMCellLoc.heap.injEq, true_and]
                  rw [Int.toNat_of_nonneg hr.1]
                  rw [mul_comm, Int.mul_ediv_add_emod]
                rw [Function.update_of_ne hne]
              · rfl
            · rw [if_neg ht10, if_neg ht10]
              by_cases ht11 : t = 11
              · rw [if_pos ht11, if_pos ht11]
              · rw [if_neg ht11, if_neg ht11]
                by_cases ht12 : t = 12
                · rw [if_pos ht12, if_pos ht12]
                · rw [if_neg ht12, if_neg ht12]
                  by_cases ht13 : 13 ≤ t ∧ T_max ≤ t - 13
                  · rw [if_pos ht13, if_pos ht13]
                    have hne : RAMCellLoc.heap (t - 13) idx ≠ u := by
                      intro rfl; apply hl
                      have hnot : ¬ (t - 13 < T_max) := by omega
                      simp [shiftSubLoc, hnot]; omega
                    rw [Function.update_of_ne hne]
                  · rw [if_neg ht13, if_neg ht13]

theorem simMergeStore_write_heap_logged {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) (wsSub : WordStore) (log : List ℤ)
    {t : ℕ} (ht : t < T_max) (idx val : ℤ) :
    let enc : ℤ := idx * (T_max : ℤ) + (t : ℤ)
    (((simMergeStore wsBase T_max hT wsSub log).write (.heap 11 (log.length : ℤ)) enc).write
      (.heap 10 enc) val).write (.heap 12 0) ((log.length : ℤ) + 1) =
    simMergeStore wsBase T_max hT (wsSub.write (.heap t idx) val) (log ++ [enc]) := by
  intro enc
  have hshift : shiftSubLoc T_max (.heap t idx) = .heap 10 enc := by
    simp [shiftSubLoc, ht, enc]
  rw [← hshift]
  unfold WordStore.write simMergeStore
  congr 1
  · ext l
    simp only [Finset.mem_insert, Finset.mem_union, Finset.mem_map, shiftSubEmb,
      logLiveFinset, heap11Emb, Function.Embedding.coeFn_mk, Finset.mem_range,
      List.length_append, List.length_singleton]
    constructor
    · rintro (rfl | rfl | rfl | ((hb | ⟨u', hu', rfl⟩) | rfl | ⟨k, hk, rfl⟩))
      · exact Or.inr (Or.inl rfl)
      · exact Or.inl (Or.inr ⟨.heap t idx, Or.inl rfl, rfl⟩)
      · exact Or.inr (Or.inr ⟨log.length, by omega, rfl⟩)
      · exact Or.inl (Or.inl hb)
      · exact Or.inl (Or.inr ⟨u', Or.inr hu', rfl⟩)
      · exact Or.inr (Or.inl rfl)
      · exact Or.inr (Or.inr ⟨k, by omega, rfl⟩)
    · rintro ((hb | ⟨u', rfl | hu', rfl⟩) | rfl | ⟨k, hk, rfl⟩)
      · exact Or.inr (Or.inr (Or.inr (Or.inl (Or.inl hb))))
      · exact Or.inr (Or.inl rfl)
      · exact Or.inr (Or.inr (Or.inr (Or.inl (Or.inr ⟨u', hu', rfl⟩))))
      · exact Or.inl rfl
      · rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hk) with hlt | rfl
        · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨k, hlt, rfl⟩))))
        · exact Or.inr (Or.inr (Or.inl rfl))
  · funext l
    dsimp only
    by_cases h12 : l = .heap 12 0
    · subst h12
      simp [simMergeVals]
    · rw [Function.update_of_ne h12]
      by_cases h10 : l = shiftSubLoc T_max (.heap t idx)
      · subst h10
        rw [Function.update_self,
          shiftSubLoc_vals_eq wsBase hT _ (log ++ [enc]) (.heap t idx)]
        simp [WordStore.write]
      · rw [Function.update_of_ne h10]
        by_cases h11 : l = .heap 11 (log.length : ℤ)
        · subst h11
          rw [Function.update_self]
          dsimp [simMergeVals]
          simp [List.getD_eq_getElem?_getD, List.getElem?_append_right]
        · rw [Function.update_of_ne h11]
          cases l with
          | localFrame d var i =>
              dsimp [simMergeVals, WordStore.write]
              split_ifs with hd1 hd2 <;> rfl
          | heap tl il =>
              dsimp only [simMergeVals, WordStore.write]
              by_cases ht8 : tl < 8
              · rw [if_pos ht8, if_pos ht8]
              · rw [if_neg ht8, if_neg ht8]
                by_cases ht10 : tl = 10
                · rw [if_pos ht10, if_pos ht10]; subst ht10
                  split_ifs with hr
                  · have hne : RAMCellLoc.heap (il % (T_max : ℤ)).toNat (il / (T_max : ℤ)) ≠ .heap t idx := by
                      intro hc; apply h10
                      injection hc with htr hqr
                      rw [← htr, ← hqr]
                      simp only [shiftSubLoc, hr.2, ↓reduceIte, RAMCellLoc.heap.injEq, true_and]
                      rw [Int.toNat_of_nonneg hr.1]
                      rw [mul_comm, Int.mul_ediv_add_emod]
                    rw [Function.update_of_ne hne]
                  · rfl
                · rw [if_neg ht10, if_neg ht10]
                  by_cases ht11 : tl = 11
                  · rw [if_pos ht11, if_pos ht11]; subst ht11
                    simp only [List.length_append, List.length_singleton]
                    by_cases hil : 0 ≤ il ∧ il.toNat < log.length
                    · have hil' : 0 ≤ il ∧ il.toNat < log.length + 1 := ⟨hil.1, by omega⟩
                      simp only [hil, hil', and_self, ↓reduceIte, List.getD_eq_getElem?_getD]
                      rw [List.getElem?_append_left hil.2]
                    · have hil' : ¬ (0 ≤ il ∧ il.toNat < log.length + 1) := by
                        rintro ⟨h0, hlt1⟩
                        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hlt1) with hlt | heq
                        · exact hil ⟨h0, hlt⟩
                        · exact h11 (by rw [← Int.toNat_of_nonneg h0, heq])
                      rw [if_neg hil, if_neg hil']
                  · rw [if_neg ht11, if_neg ht11]
                    by_cases ht12 : tl = 12
                    · rw [if_pos ht12, if_pos ht12]; subst ht12
                      have hi0 : il ≠ 0 := fun h => h12 (h ▸ rfl)
                      simp [hi0]
                    · rw [if_neg ht12, if_neg ht12]
                      by_cases ht13 : 13 ≤ tl ∧ T_max ≤ tl - 13
                      · rw [if_pos ht13, if_pos ht13]
                        have hne : RAMCellLoc.heap (tl - 13) il ≠ .heap t idx := by
                          intro hc; injection hc with htr _; omega
                        rw [Function.update_of_ne hne]
                      · rw [if_neg ht13, if_neg ht13]

theorem simMergeStore_free_sub {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) (wsSub : WordStore) (log : List ℤ) (u : RAMCellLoc) :
    (simMergeStore wsBase T_max hT wsSub log).free (shiftSubLoc T_max u) =
      simMergeStore wsBase T_max hT (wsSub.free u) log := by
  unfold WordStore.free simMergeStore
  congr 1
  · ext l
    simp only [Finset.mem_erase, Finset.mem_union, Finset.mem_map, shiftSubEmb,
      Function.Embedding.coeFn_mk]
    constructor
    · rintro ⟨hne, (hb | ⟨u', hu', rfl⟩) | hl⟩
      · exact Or.inl (Or.inl hb)
      · refine Or.inl (Or.inr ⟨u', ⟨fun hu_eq => hne (hu_eq ▸ rfl), hu'⟩, rfl⟩)
      · exact Or.inr hl
    · rintro ((hb | ⟨u', ⟨hne_u, hu'⟩, rfl⟩) | hl)
      · refine ⟨fun h => shiftSubLoc_not_in_base hbase T_max u (h ▸ hb), Or.inl (Or.inl hb)⟩
      · refine ⟨fun h => hne_u (shiftSubLoc_injective hT h),
          Or.inl (Or.inr ⟨u', hu', rfl⟩)⟩
      · refine ⟨fun h => shiftSubLoc_not_in_log T_max log u (h ▸ hl), Or.inr hl⟩
  · funext l
    by_cases hl : l = shiftSubLoc T_max u
    · subst hl
      rw [Function.update_self, shiftSubLoc_vals_eq wsBase hT _ log u]
      simp [WordStore.free]
    · rw [Function.update_of_ne hl]
      cases l with
      | localFrame d var idx =>
          dsimp [simMergeVals, WordStore.free]
          split_ifs with hd1 hd2
          · rfl
          · have hne : RAMCellLoc.localFrame (d - 2) var idx ≠ u := by
              intro rfl; apply hl; simp [shiftSubLoc]; omega
            rw [Function.update_of_ne hne]
          · rfl
      | heap t idx =>
          dsimp only [simMergeVals, WordStore.free]
          by_cases ht8 : t < 8
          · rw [if_pos ht8, if_pos ht8]
          · rw [if_neg ht8, if_neg ht8]
            by_cases ht10 : t = 10
            · rw [if_pos ht10, if_pos ht10]; subst ht10
              split_ifs with hr
              · have hne : RAMCellLoc.heap (idx % (T_max : ℤ)).toNat (idx / (T_max : ℤ)) ≠ u := by
                  intro rfl; apply hl
                  simp only [shiftSubLoc, hr.2, ↓reduceIte, RAMCellLoc.heap.injEq, true_and]
                  rw [Int.toNat_of_nonneg hr.1]
                  rw [mul_comm, Int.mul_ediv_add_emod]
                rw [Function.update_of_ne hne]
              · rfl
            · rw [if_neg ht10, if_neg ht10]
              by_cases ht11 : t = 11
              · rw [if_pos ht11, if_pos ht11]
              · rw [if_neg ht11, if_neg ht11]
                by_cases ht12 : t = 12
                · rw [if_pos ht12, if_pos ht12]
                · rw [if_neg ht12, if_neg ht12]
                  by_cases ht13 : 13 ≤ t ∧ T_max ≤ t - 13
                  · rw [if_pos ht13, if_pos ht13]
                    have hne : RAMCellLoc.heap (t - 13) idx ≠ u := by
                      intro rfl; apply hl
                      have hnot : ¬ (t - 13 < T_max) := by omega
                      simp [shiftSubLoc, hnot]; omega
                    rw [Function.update_of_ne hne]
                  · rw [if_neg ht13, if_neg ht13]

theorem simMergeStore_popDepth {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) (wsSub : WordStore) (log : List ℤ) (keep : ℕ) :
    (simMergeStore wsBase T_max hT wsSub log).popDepth (2 + keep) =
      simMergeStore wsBase T_max hT (wsSub.popDepth keep) log := by
  unfold WordStore.popDepth simMergeStore
  congr 1
  · ext l
    simp only [Finset.mem_filter, Finset.mem_union, Finset.mem_map, shiftSubEmb,
      Function.Embedding.coeFn_mk]
    constructor
    · rintro ⟨(hb | ⟨u, hu, rfl⟩) | hl, hk⟩
      · exact Or.inl (Or.inl hb)
      · refine Or.inl (Or.inr ⟨u, ⟨hu, ?_⟩, rfl⟩)
        cases u with
        | heap _ _ => rfl
        | localFrame d _ _ =>
            simp [shiftSubLoc, RAMCellLoc.keepAtDepth] at hk ⊢
            omega
      · exact Or.inr hl
    · rintro ((hb | ⟨u, ⟨hu, hku⟩, rfl⟩) | hl)
      · refine ⟨Or.inl (Or.inl hb), ?_⟩
        rcases hbase.2 _ hb with ⟨_, _, _, rfl⟩ | ⟨_, _, rfl⟩
        · rfl
        · simp [RAMCellLoc.keepAtDepth]; omega
      · refine ⟨Or.inl (Or.inr ⟨u, hu, rfl⟩), ?_⟩
        cases u with
        | heap _ _ => dsimp [shiftSubLoc]; split_ifs <;> rfl
        | localFrame d _ _ =>
            simp [shiftSubLoc, RAMCellLoc.keepAtDepth] at hku ⊢
            omega
      · refine ⟨Or.inr hl, ?_⟩
        simp only [logLiveFinset, Finset.mem_insert, Finset.mem_map, heap11Emb,
          Function.Embedding.coeFn_mk] at hl
        rcases hl with rfl | ⟨_, _, rfl⟩ <;> rfl
  · funext l
    dsimp only
    cases l with
    | heap t idx =>
        simp [RAMCellLoc.keepAtDepth, simMergeVals]
    | localFrame d var idx =>
        dsimp only [simMergeVals, RAMCellLoc.keepAtDepth]
        by_cases hd1 : d = 1
        · subst hd1
          have hk : decide (1 ≤ 2 + keep) = true := decide_eq_true (by omega)
          simp [hk]
        · by_cases hd2 : 2 ≤ d
          · by_cases hk : d ≤ 2 + keep
            · have hk' : d - 2 ≤ keep := by omega
              simp [hd1, hd2, hk, hk']
            · have hk' : ¬ (d - 2 ≤ keep) := by omega
              simp [hd1, hd2, hk, hk']
          · simp [hd1, hd2]

theorem simMergeStore_popDepth_one {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) (wsSub : WordStore) (log : List ℤ) :
    (simMergeStore wsBase T_max hT wsSub log).popDepth 1 =
      simMergeStore wsBase T_max hT (heapOnlyStore wsSub) log := by
  unfold WordStore.popDepth simMergeStore heapOnlyStore
  congr 1
  · ext l
    simp only [Finset.mem_filter, Finset.mem_union, Finset.mem_map, shiftSubEmb,
      Function.Embedding.coeFn_mk]
    constructor
    · rintro ⟨(hb | ⟨u, hu, rfl⟩) | hl, hk⟩
      · exact Or.inl (Or.inl hb)
      · refine Or.inl (Or.inr ⟨u, ⟨hu, ?_⟩, rfl⟩)
        cases u with
        | heap _ _ => rfl
        | localFrame d _ _ =>
            simp [shiftSubLoc, RAMCellLoc.keepAtDepth] at hk; omega
      · exact Or.inr hl
    · rintro ((hb | ⟨u, ⟨hu, hku⟩, rfl⟩) | hl)
      · refine ⟨Or.inl (Or.inl hb), ?_⟩
        rcases hbase.2 _ hb with ⟨_, _, _, rfl⟩ | ⟨_, _, rfl⟩ <;> rfl
      · refine ⟨Or.inl (Or.inr ⟨u, hu, rfl⟩), ?_⟩
        cases u with
        | heap _ _ => dsimp [shiftSubLoc]; split_ifs <;> rfl
        | localFrame _ _ _ => simp at hku
      · refine ⟨Or.inr hl, ?_⟩
        simp only [logLiveFinset, Finset.mem_insert, Finset.mem_map, heap11Emb,
          Function.Embedding.coeFn_mk] at hl
        rcases hl with rfl | ⟨_, _, rfl⟩ <;> rfl
  · funext l
    dsimp only
    cases l with
    | heap t idx => simp [RAMCellLoc.keepAtDepth, simMergeVals]
    | localFrame d var idx =>
        dsimp only [simMergeVals, RAMCellLoc.keepAtDepth]
        by_cases hd1 : d = 1
        · subst hd1; simp
        · by_cases hd2 : 2 ≤ d
          · have hk : ¬ (d ≤ 1) := by omega
            simp [hd1, hd2, hk]
          · simp [hd1, hd2]

theorem shiftSubLoc_bitLength_le (T_max : ℕ) (u : RAMCellLoc) :
    (shiftSubLoc T_max u).bitLength ≤ (natBitLength T_max + 12) * u.bitLength := by
  have hu1 := ramCellLoc_bitLength_pos u
  have hT1 := natBitLength_pos T_max
  cases u with
  | localFrame d var idx =>
      dsimp [shiftSubLoc, RAMCellLoc.bitLength]
      have hd : natBitLength (2 + d) ≤ natBitLength d + 2 := by
        have h1 : 2 + d < 2 ^ (natBitLength d + 2) := by
          have := Nat.lt_pow_succ_log_self (by norm_num : 1 < 2) d
          have hpow : 2 ^ (natBitLength d + 2) = 4 * 2 ^ (natBitLength d) := by
            rw [pow_add, pow_two]; ring
          unfold natBitLength at hpow ⊢
          omega
        unfold natBitLength
        have hlog : Nat.log 2 (2 + d) < Nat.log 2 d + 3 :=
          (Nat.log_lt_iff_lt_pow (by norm_num) (by omega)).mpr h1
        omega
      have := natBitLength_pos d
      nlinarith
  | heap t idx =>
      dsimp [shiftSubLoc]
      split_ifs with ht
      · dsimp [RAMCellLoc.bitLength]
        have hn10 : natBitLength 10 = 4 := by decide
        have hadd := intBitLength_add_le (idx * (T_max : ℤ)) (t : ℤ)
        have hmul := intBitLength_mul_le idx (T_max : ℤ)
        have hT_ib : intBitLength (T_max : ℤ) ≤ natBitLength T_max + 1 := by
          unfold intBitLength
          split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
        have ht_ib : intBitLength (t : ℤ) ≤ natBitLength t + 1 := by
          unfold intBitLength
          split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
        rw [hn10]
        have := natBitLength_pos t
        have := intBitLength_pos idx
        nlinarith
      · dsimp [RAMCellLoc.bitLength]
        have ht13 : natBitLength (13 + t) ≤ natBitLength t + 5 := by
          have h1 : 13 + t < 2 ^ (natBitLength t + 5) := by
            have := Nat.lt_pow_succ_log_self (by norm_num : 1 < 2) t
            have hpow : 2 ^ (natBitLength t + 5) = 32 * 2 ^ (natBitLength t) := by
              rw [pow_add]; norm_num; ring
            unfold natBitLength at hpow ⊢
            omega
          unfold natBitLength
          have hlog : Nat.log 2 (13 + t) < Nat.log 2 t + 6 :=
            (Nat.log_lt_iff_lt_pow (by norm_num) (by omega)).mpr h1
          omega
        have := natBitLength_pos t
        have := intBitLength_pos idx
        nlinarith

theorem simMergeStore_cellCount_le (wsBase : WordStore) {T_max : ℕ} (hT : 1 ≤ T_max)
    (wsSub : WordStore) (log : List ℤ) :
    (simMergeStore wsBase T_max hT wsSub log).cellCount ≤
      wsBase.cellCount + wsSub.cellCount + log.length + 1 := by
  unfold WordStore.cellCount simMergeStore logLiveFinset
  dsimp only
  have h1 := Finset.card_union_le
    (wsBase.live ∪ wsSub.live.map (shiftSubEmb T_max hT))
    (insert (.heap 12 0) ((Finset.range log.length).map heap11Emb))
  have h2 := Finset.card_union_le wsBase.live (wsSub.live.map (shiftSubEmb T_max hT))
  have h3 := Finset.card_insert_le (.heap 12 0) ((Finset.range log.length).map heap11Emb)
  rw [Finset.card_map] at h2
  rw [Finset.card_map, Finset.card_range] at h3
  omega

theorem simMergeStore_bitSize_le {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) (wsSub : WordStore) (log : List ℤ)
    {L_log : ℕ} (hlog_len : ∀ x ∈ log, intBitLength x ≤ L_log) :
    (simMergeStore wsBase T_max hT wsSub log).bitSize ≤
      wsBase.bitSize + (natBitLength T_max + 12) * wsSub.bitSize +
        (log.length + 1) * (natBitLength log.length + L_log + 10) := by
  change (∑ loc ∈ (wsBase.live ∪ wsSub.live.map (shiftSubEmb T_max hT)) ∪ logLiveFinset log,
    (loc.bitLength + intBitLength (simMergeVals wsBase T_max wsSub log loc))) ≤ _
  have hdisj1 : Disjoint wsBase.live (wsSub.live.map (shiftSubEmb T_max hT)) := by
    rw [Finset.disjoint_left]
    intro l hl hm
    rcases Finset.mem_map.mp hm with ⟨u, _, rfl⟩
    exact shiftSubLoc_not_in_base hbase T_max u hl
  have hdisj2 : Disjoint (wsBase.live ∪ wsSub.live.map (shiftSubEmb T_max hT))
      (logLiveFinset log) := by
    rw [Finset.disjoint_left]
    intro l hl hlog
    rcases Finset.mem_union.mp hl with hb | hm
    · simp only [logLiveFinset, Finset.mem_insert, Finset.mem_map, heap11Emb,
        Function.Embedding.coeFn_mk] at hlog
      rcases hbase.2 l hb with ⟨t, _, ht8, rfl⟩ | ⟨_, _, rfl⟩
      · rcases hlog with hc | ⟨_, _, hc⟩ <;> (injection hc with ht _; omega)
      · rcases hlog with hc | ⟨_, _, hc⟩ <;> nomatch hc
    · rcases Finset.mem_map.mp hm with ⟨u, _, rfl⟩
      exact shiftSubLoc_not_in_log T_max log u hlog
  rw [Finset.sum_union hdisj2, Finset.sum_union hdisj1]
  have hbase_eq :
      (∑ loc ∈ wsBase.live, (loc.bitLength + intBitLength (simMergeVals wsBase T_max wsSub log loc))) =
        wsBase.bitSize := by
    unfold WordStore.bitSize
    refine Finset.sum_congr rfl fun loc hloc => ?_
    rcases hbase.2 loc hloc with ⟨t, idx, ht8, rfl⟩ | ⟨var, idx, rfl⟩
    · simp [simMergeVals, ht8]
    · simp [simMergeVals]
  have hsub_le :
      (∑ loc ∈ wsSub.live.map (shiftSubEmb T_max hT),
        (loc.bitLength + intBitLength (simMergeVals wsBase T_max wsSub log loc))) ≤
      (natBitLength T_max + 12) * wsSub.bitSize := by
    unfold WordStore.bitSize
    rw [Finset.sum_map, Finset.mul_sum]
    refine Finset.sum_le_sum fun u _ => ?_
    simp only [shiftSubEmb, Function.Embedding.coeFn_mk]
    rw [shiftSubLoc_vals_eq wsBase hT wsSub log u]
    have hb1 := shiftSubLoc_bitLength_le T_max u
    have hT1 := natBitLength_pos T_max
    nlinarith
  have hlog_le :
      (∑ loc ∈ logLiveFinset log,
        (loc.bitLength + intBitLength (simMergeVals wsBase T_max wsSub log loc))) ≤
      (log.length + 1) * (natBitLength log.length + L_log + 10) := by
    unfold logLiveFinset
    have hnot : RAMCellLoc.heap 12 0 ∉ (Finset.range log.length).map heap11Emb := by
      simp [heap11Emb]
    rw [Finset.sum_insert hnot, Finset.sum_map]
    have h12 : (RAMCellLoc.heap 12 0).bitLength +
        intBitLength (simMergeVals wsBase T_max wsSub log (.heap 12 0)) ≤
        natBitLength log.length + L_log + 10 := by
      dsimp [RAMCellLoc.bitLength, simMergeVals]
      have hn12 : natBitLength 12 = 4 := by decide
      have hi0 : intBitLength 0 = 1 := rfl
      have hll : intBitLength (log.length : ℤ) ≤ natBitLength log.length + 1 := by
        unfold intBitLength
        split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
      omega
    have hsum11 :
        (∑ k ∈ Finset.range log.length,
          ((heap11Emb k).bitLength +
            intBitLength (simMergeVals wsBase T_max wsSub log (heap11Emb k)))) ≤
        log.length * (natBitLength log.length + L_log + 10) := by
      calc
        (∑ k ∈ Finset.range log.length, _)
            ≤ ∑ _k ∈ Finset.range log.length, (natBitLength log.length + L_log + 10) := by
              refine Finset.sum_le_sum fun k hk => ?_
              have hk_lt : k < log.length := Finset.mem_range.mp hk
              simp only [heap11Emb, Function.Embedding.coeFn_mk]
              dsimp [RAMCellLoc.bitLength, simMergeVals]
              have hn11 : natBitLength 11 = 4 := by decide
              have hik : intBitLength (k : ℤ) ≤ natBitLength log.length + 1 := by
                have hkm : natBitLength k ≤ natBitLength log.length :=
                  natBitLength_mono (le_of_lt hk_lt)
                unfold intBitLength
                split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
              simp only [Int.natCast_nonneg, Int.toNat_natCast, hk_lt, and_self, ↓reduceIte]
              have hmem : log.getD k 0 ∈ log := by
                rw [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem hk_lt]
                exact List.getElem_mem hk_lt
              have hv := hlog_len _ hmem
              omega
        _ = log.length * (natBitLength log.length + L_log + 10) := by simp
    nlinarith
  omega

end UL.Proof_lem_A_2
