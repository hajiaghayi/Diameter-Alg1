import Mathlib
import UL.Proof.lem_A_2.RacerP54_H3f
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 1200000

namespace UL.Proof_lem_A_2

/-! ### Phase 5 combined block-verification execution theorem -/

theorem exec_phase5Stmt {A V M U_cert : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ) (zRat : Fin p.D → ℚ) (π : Equiv.Perm (Fin p.m))
    (progCert : BitRAMStmt) (outCert : Fin p.r → BitRAMExecOutcome)
    {inp : BitRAMInput p.d} {ws₅ : WordStore} {bs : List Bool}
    (harena : InAttemptArena A V ws₅)
    (hhz : HeapAllZero ws₅)
    (hregs : HasPhase2Regs p M ws₅)
    (hlifts : HasLiftArrays p pts_h ws₅)
    (hz : HasZArray p.D zRat ws₅)
    (hfy : HasFYArray p.m π ws₅)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hpts_b : ∀ h : ℕ, h < p.m → RatPointBitBounded p.B (pts_h h))
    (hip_handles : inp.activeHandles = Finset.range p.m)
    (hip_coords : ∀ h : ℕ, h < p.m → inp.activeRatCoords h = pts_h h)
    (hz_V : ∀ c : Fin p.D,
      intBitLength (zRat c).num ≤ V ∧ intBitLength (((zRat c).den : ℤ) - 1) ≤ V)
    (h5_fit : p.D + p.s₀ * p.D + 4 ≤ A ∧ U_cert + 2 ≤ V)
    (hrun_cert : ∀ b : Fin p.r,
      runBitRAMWithBits progCert (certBlockInp p pts_h zRat π b) WordStore.empty [] = some (outCert b))
    (hcert_bounds : ∀ b : Fin p.r,
      (outCert b).unitCost ≤ U_cert ∧ (outCert b).bitCost ≤ U_cert ∧
      (outCert b).peakCellSpace ≤ U_cert ∧ (outCert b).peakBitSpace ≤ U_cert) :
    let T_c := maxTableStmtFull progCert
    let F_c := stmtFactor progCert
    let C_c := arenaCellCap inp A + 2 * U_cert + 8
    let S_c := arenaBitCap inp A V + (natBitLength T_c + 12) * U_cert +
      (U_cert + 3) * (natBitLength (U_cert + 2) + U_cert + 2 * natBitLength T_c + 18) +
      2 * natBitLength (U_cert + 2) + 64
    let passBool : Fin p.r → Bool := fun b => decide ((outCert b).words.read (.heap 0 0) = 1)
    let L_pass : List (Fin p.r) := (List.finRange p.r).filter passBool
    ∃ ws₆ : WordStore,
      InAttemptArena A V ws₆ ∧
      HeapAllZero ws₆ ∧
      HasPhase2Regs p M ws₆ ∧
      HasZArray p.D zRat ws₆ ∧
      ws₆.read (.localFrame 1 1 14) = (L_pass.length : ℤ) ∧
      (∀ (i : ℕ) (hi : i < L_pass.length) (j : Fin p.s₀),
        let flatIdx : ℤ := ((i * p.s₀ + j.1 : ℕ) : ℤ)
        ws₆.read (.localFrame 1 7 flatIdx) = ((blkHandle p π L_pass[i] j).1 : ℤ) ∧
        ws₆.read (.localFrame 1 8 (2 * flatIdx)) =
          (outCert L_pass[i]).words.read (.heap 1 (2 * (j.1 : ℤ))) ∧
        ws₆.read (.localFrame 1 8 (2 * flatIdx + 1)) =
          (outCert L_pass[i]).words.read (.heap 1 (2 * (j.1 : ℤ) + 1))) ∧
      ExecBounded inp (phase5Stmt progCert) ws₅ bs ws₆ bs
        (2000 + 800 * (p.D + p.s₀ * p.D) +
          p.r * (2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (U_cert + 1)))
        ((2000000 + 800000 * (p.D + p.s₀ * p.D)) * (V + natBitLength T_c + 16) ^ 2 +
          p.r * ((2000000 + p.s₀ * (1500000 + 300000 * p.d)) * (V + natBitLength T_c + 16) ^ 2 +
            256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * U_cert + 16) * U_cert +
            (U_cert + 2) * (8 * natBitLength (U_cert + 2) + 4 * (U_cert + 2 * natBitLength T_c + 6) + 80)))
        C_c S_c := by
  intro T_c F_c C_c S_c passBool L_pass
  have hK1 := hfit.1
  have hB1 := hfit.2.1
  have hm2s := hfit.2.2.2.1
  have h16A := hfit.2.2.2.2.1
  have hmA := hfit.2.2.2.2.2.1
  have hVA := hfit.2.2.2.2.2.2.1
  have hBlV := hfit.2.2.2.2.2.2.2.1
  rcases h5_fit with ⟨hsDA, hUcV⟩
  have hV16 : 16 ≤ V := by omega
  have hD_pos : 1 ≤ p.D := by dsimp [CoreParams.D]; omega
  have hs0_pos : 1 ≤ p.s₀ := s₀Val_pos hK1 p.d
  have hrs_le_m : p.r * p.s₀ ≤ p.m := Nat.div_mul_le_self p.m p.s₀
  have hd_V : intBitLength (p.d : ℤ) ≤ V := by
    have hd_lt_A : p.d < A := by dsimp [CoreParams.D] at hmA; omega
    have h1 := intBitLength_natCast_le_succ p.d
    have h2 := natBitLength_mono (le_of_lt hd_lt_A)
    omega
  have idx_V : ∀ k : ℕ, k ≤ A → intBitLength (k : ℤ) ≤ V := by
    intro k hk
    have h1 := intBitLength_natCast_le_succ k
    have h2 := natBitLength_mono hk
    omega
  have hCS : arenaCellCap inp A ≤ C_c ∧ arenaBitCap inp A V ≤ S_c :=
    ⟨by dsimp [C_c]; omega, by dsimp [S_c]; omega⟩
  -- 1. PreStage
  obtain ⟨wsPre, ha_pre, hregs_pre, hlifts_pre, hz_pre, hfy_pre, hr8_pre, hr14_pre,
    hht_pre, hh5_pre, hzc_pre, hzz_pre, ex_pre⟩ :=
    exec_phase5PreStageStmt (bs := bs) p pts_h zRat π harena hhz hregs hlifts hz hfy hinp hfit hz_V
  -- 2. Outer loop over `b = 0 .. p.r - 1`
  let passedPre : ℕ → List (Fin p.r) := fun b => ((List.finRange p.r).take b).filter passBool
  have hpass_len_le : ∀ b : ℕ, (passedPre b).length ≤ b := by
    intro b
    calc (passedPre b).length ≤ ((List.finRange p.r).take b).length := List.length_filter_le _ _
      _ ≤ b := List.length_take_le b _
  let Z := V + natBitLength T_c + 16
  have hVZ : V + 8 ≤ Z := by dsimp [Z]; omega
  have hYZ : (V + 8) ^ 2 ≤ Z ^ 2 := Nat.pow_le_pow_left hVZ 2
  let stepU : ℕ := 2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (U_cert + 1)
  let stepB : ℕ := (2000000 + p.s₀ * (1500000 + 300000 * p.d)) * Z ^ 2 +
    256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * U_cert + 16) * U_cert +
    (U_cert + 2) * (8 * natBitLength (U_cert + 2) + 4 * (U_cert + 2 * natBitLength T_c + 6) + 80)
  let BlockInv (b : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
    bs_c = bs ∧
    InAttemptArena A V ws ∧
    HasPhase2Regs p M ws ∧
    HasLiftArrays p pts_h ws ∧
    HasZArray p.D zRat ws ∧
    HasFYArray p.m π ws ∧
    ws.read (.localFrame 1 1 8) = (b : ℤ) ∧
    ws.read (.localFrame 1 1 14) = ((passedPre b).length : ℤ) ∧
    (∀ t idx, t ≠ 5 → t ≠ 6 → t ≠ 7 → ws.read (.heap t idx) = 0) ∧
    (∀ idx : ℤ, ws.read (.heap 5 idx) = listGetIntD [(p.D : ℤ), (p.s₀ : ℤ)] idx 0) ∧
    (∀ c : Fin p.D,
      ws.read (.heap 6 (c.1 : ℤ)) = (zRat c).num ∧
      ws.read (.heap 7 (c.1 : ℤ)) + 1 = ((zRat c).den : ℤ)) ∧
    (∀ idx : ℤ, (idx < 0 ∨ ((p.D + p.s₀ * p.D : ℕ) : ℤ) ≤ idx) →
      ws.read (.heap 6 idx) = 0 ∧ ws.read (.heap 7 idx) = 0) ∧
    (∀ (i : ℕ) (hi : i < (passedPre b).length) (j : Fin p.s₀),
      let flatIdx : ℤ := ((i * p.s₀ + j.1 : ℕ) : ℤ)
      ws.read (.localFrame 1 7 flatIdx) = ((blkHandle p π (passedPre b)[i] j).1 : ℤ) ∧
      ws.read (.localFrame 1 8 (2 * flatIdx)) =
        (outCert (passedPre b)[i]).words.read (.heap 1 (2 * (j.1 : ℤ))) ∧
      ws.read (.localFrame 1 8 (2 * flatIdx + 1)) =
        (outCert (passedPre b)[i]).words.read (.heap 1 (2 * (j.1 : ℤ) + 1)))
  have hinit_blk : BlockInv 0 wsPre bs := by
    refine ⟨rfl, ha_pre, hregs_pre, hlifts_pre, hz_pre, hfy_pre, hr8_pre,
      by simp [passedPre, hr14_pre],
      hht_pre, hh5_pre, hzc_pre,
      fun idx hrange => hzz_pre idx (by omega),
      fun _ hi => absurd hi (by simp [passedPre])⟩
  obtain ⟨wsPostLoop, _, hinv_r, ex_rloop⟩ := exec_repeatN_inv (countE := (.readLocal 0 (.lit 6))) (body := (phase5BlockOuterBody progCert)) p.r BlockInv
    ha_pre hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
    hregs_pre.1.2.2.2.2.2.2.1 hinit_blk
    (U := stepU) (B := stepB) (C := C_c) (S := S_c)
    (fun b ws_b bs_b hb ⟨hbs_b, ha_b, hregs_b, hlifts_b, hz_b, hfy_b, hr8_b, hr14_b,
        hht_b, hh5_b, hzc_b, hzz_b, hpass_b⟩ => by
      subst bs_b
      let bFin : Fin p.r := ⟨b, hb⟩
      let k_cur : ℕ := (passedPre b).length
      have hk_cur_le_b : k_cur ≤ b := hpass_len_le b
      -- 2a. `(1, 9) := 0` and stage `s₀` points of block `bFin`
      obtain ⟨ha_j0, ex_j0⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 9)) (idx := 9) (valE := (.lit 0)) (val := 0) (bs := bs) ha_b hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl rfl (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
      let StageJInv (j : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
        bs_c = bs ∧
        InAttemptArena A V ws ∧
        HasPhase2Regs p M ws ∧
        HasLiftArrays p pts_h ws ∧
        HasZArray p.D zRat ws ∧
        HasFYArray p.m π ws ∧
        ws.read (.localFrame 1 1 8) = (b : ℤ) ∧
        ws.read (.localFrame 1 1 9) = (j : ℤ) ∧
        ws.read (.localFrame 1 1 14) = (k_cur : ℤ) ∧
        (∀ idx : ℤ, ws.read (.localFrame 1 7 idx) = ws_b.read (.localFrame 1 7 idx)) ∧
        (∀ idx : ℤ, ws.read (.localFrame 1 8 idx) = ws_b.read (.localFrame 1 8 idx)) ∧
        (∀ t idx, t ≠ 5 → t ≠ 6 → t ≠ 7 → ws.read (.heap t idx) = 0) ∧
        (∀ idx : ℤ, ws.read (.heap 5 idx) = listGetIntD [(p.D : ℤ), (p.s₀ : ℤ)] idx 0) ∧
        (∀ c : Fin p.D,
          ws.read (.heap 6 (c.1 : ℤ)) = (zRat c).num ∧
          ws.read (.heap 7 (c.1 : ℤ)) + 1 = ((zRat c).den : ℤ)) ∧
        (∀ idx : ℤ, (idx < 0 ∨ ((p.D + p.s₀ * p.D : ℕ) : ℤ) ≤ idx) →
          ws.read (.heap 6 idx) = 0 ∧ ws.read (.heap 7 idx) = 0) ∧
        (∀ (j' : ℕ) (hj' : j' < j) (hjs : j' < p.s₀) (c : Fin p.D),
          let a : ℤ := ((p.D + j' * p.D + c.1 : ℕ) : ℤ)
          let q := liftRatPoint (pts_h (blkHandle p π bFin ⟨j', hjs⟩).1) c
          ws.read (.heap 6 a) = q.num ∧
          ws.read (.heap 7 a) + 1 = (q.den : ℤ))
      have hinit_sj : StageJInv 0 (ws_b.write (.localFrame 1 1 9) 0) bs := by
        refine ⟨rfl, ha_j0,
          hasPhase2Regs_of_eq hregs_b (fun _ => by simp [rw_write_eq]),
          hasLiftArrays_of_eq hlifts_b (fun v _ hv =>
            by rcases hv with rfl | rfl <;> simp [rw_write_eq]),
          hasZArray_of_eq hz_b (fun _ => by simp [rw_write_eq]),
          hasFYArray_of_eq hfy_b (fun _ => by simp [rw_write_eq]),
          by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr8_b],
          wordStore_read_write_self _ _ _,
          by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr14_b],
          fun _ => by simp [rw_write_eq],
          fun _ => by simp [rw_write_eq],
          fun t idx ht5 ht6 ht7 => by
            rw [wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact hht_b t idx ht5 ht6 ht7,
          fun idx => by rw [wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact hh5_b idx,
          fun c => ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzc_b c).1,
                    by rw [wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzc_b c).2⟩,
          fun idx hr => ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzz_b idx hr).1,
                         by rw [wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzz_b idx hr).2⟩,
          fun _ hj' _ _ => absurd hj' (by omega)⟩
      obtain ⟨wsStaged_b, _, hinv_s0, ex_sj⟩ := exec_repeatN_inv (countE := (.readLocal 0 (.lit 5))) (body := phase5BlockStagePointBody) p.s₀ StageJInv
        ha_j0 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
        (by simp [rw_write_eq, evalVal_readLocal, evalVal_lit, hregs_b.1.2.2.2.2.2.1])
        hinit_sj (U := 800 + 300 * p.d) (B := (800000 + 300000 * p.d) * (V + 8) ^ 2)
        (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
        (fun j ws_j bs_j hj ⟨hbs_j, ha_j, hregs_j, hlifts_j, hz_j, hfy_j, hr8_j, hr9_j, hr14_j,
            hr7_j, hr8arr_j, hht_j, hh5_j, hzc_j, hzz_j, hpts_prev_j⟩ => by
          subst bs_j
          let jFin : Fin p.s₀ := ⟨j, hj⟩
          let pos_bj : ℕ := b * p.s₀ + j
          have hpos_lt_m : pos_bj < p.m := by
            have hb1 : (b + 1) * p.s₀ ≤ p.r * p.s₀ := Nat.mul_le_mul_right p.s₀ hb
            rw [Nat.add_mul, Nat.one_mul] at hb1
            dsimp [pos_bj]; omega
          let idx_bj : ℕ := (blkHandle p π bFin jFin).1
          have hidx_lt_m : idx_bj < p.m := (blkHandle p π bFin jFin).2
          let base_bj : ℕ := p.D + j * p.D
          have hbase_le : base_bj + p.d < p.D + p.s₀ * p.D := by
            have hj1 : (j + 1) * p.D ≤ p.s₀ * p.D := Nat.mul_le_mul_right p.D hj
            rw [Nat.add_mul, Nat.one_mul] at hj1
            dsimp [base_bj, CoreParams.D] at hj1 ⊢; omega
          have hlift_b : RatPointBitBounded p.B_lift (liftRatPoint (pts_h idx_bj)) :=
            ratPointBitBounded_liftRatPoint hB1 (hpts_b idx_bj hidx_lt_m)
          obtain ⟨ha_p1, ex_p1⟩ := exec_writeLocal_auto (bs := bs) (var := 1) (idxE := (.lit 11)) (idx := 11) (valE := (.add (.mul (.readLocal 1 (.lit 8)) (.readLocal 0 (.lit 5))) (.readLocal 1 (.lit 9)))) (val := (pos_bj : ℤ)) ha_j hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
            (by simp only [evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit,
                  hr8_j, hregs_j.1.2.2.2.2.2.1, hr9_j]
                dsimp [pos_bj]; try push_cast; try ring)
            (by decide) (by omega) (by simp; omega) (idx_V pos_bj (by omega))
          obtain ⟨ha_p2, ex_p2⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 13)) (idx := 13) (valE := (.readLocal 5 (.readLocal 1 (.lit 11)))) (val := (idx_bj : ℤ)) ha_p1 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
            (by simp [rw_write_eq, evalVal_readLocal, evalVal_lit]
                exact hfy_j ⟨pos_bj, hpos_lt_m⟩)
            (by decide) (by omega) (by simp; omega) (idx_V idx_bj (by omega))
          obtain ⟨ha_p3, ex_p3⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 11)) (idx := 11) (valE := (.add (.readLocal 0 (.lit 1)) (.mul (.readLocal 1 (.lit 9)) (.readLocal 0 (.lit 1))))) (val := (base_bj : ℤ)) ha_p2 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
            (by simp [rw_write_eq, evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit, hregs_j.1.2.1, hr9_j]
                dsimp [base_bj]; try push_cast; try ring)
            (by decide) (by omega) (by simp; omega) (idx_V base_bj (by omega))
          obtain ⟨ha_p4, ex_p4⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 10)) (idx := 10) (valE := (.lit 0)) (val := 0) ha_p3 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl rfl
            (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
          let CoordInv (c : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
            bs_c = bs ∧
            InAttemptArena A V ws ∧
            HasPhase2Regs p M ws ∧
            HasLiftArrays p pts_h ws ∧
            HasZArray p.D zRat ws ∧
            HasFYArray p.m π ws ∧
            ws.read (.localFrame 1 1 8) = (b : ℤ) ∧
            ws.read (.localFrame 1 1 9) = (j : ℤ) ∧
            ws.read (.localFrame 1 1 10) = (c : ℤ) ∧
            ws.read (.localFrame 1 1 11) = (base_bj : ℤ) ∧
            ws.read (.localFrame 1 1 13) = (idx_bj : ℤ) ∧
            ws.read (.localFrame 1 1 14) = (k_cur : ℤ) ∧
            (∀ idx : ℤ, ws.read (.localFrame 1 7 idx) = ws_b.read (.localFrame 1 7 idx)) ∧
            (∀ idx : ℤ, ws.read (.localFrame 1 8 idx) = ws_b.read (.localFrame 1 8 idx)) ∧
            (∀ t idx, t ≠ 5 → t ≠ 6 → t ≠ 7 → ws.read (.heap t idx) = 0) ∧
            (∀ idx : ℤ, ws.read (.heap 5 idx) = listGetIntD [(p.D : ℤ), (p.s₀ : ℤ)] idx 0) ∧
            (∀ c' : Fin p.D,
              ws.read (.heap 6 (c'.1 : ℤ)) = (zRat c').num ∧
              ws.read (.heap 7 (c'.1 : ℤ)) + 1 = ((zRat c').den : ℤ)) ∧
            (∀ idx : ℤ, (idx < 0 ∨ ((p.D + p.s₀ * p.D : ℕ) : ℤ) ≤ idx) →
              ws.read (.heap 6 idx) = 0 ∧ ws.read (.heap 7 idx) = 0) ∧
            (∀ (j' : ℕ) (hj' : j' < j) (c' : Fin p.D),
              let a : ℤ := ((p.D + j' * p.D + c'.1 : ℕ) : ℤ)
              let q := liftRatPoint (pts_h (blkHandle p π bFin ⟨j', hj'.trans hj⟩).1) c'
              ws.read (.heap 6 a) = q.num ∧
              ws.read (.heap 7 a) + 1 = (q.den : ℤ)) ∧
            (∀ (c' : ℕ) (hc' : c' < c) (hcd : c' < p.d),
              let a : ℤ := ((base_bj + c' : ℕ) : ℤ)
              let q := liftRatPoint (pts_h idx_bj) ⟨c', Nat.lt_succ_of_lt hcd⟩
              ws.read (.heap 6 a) = q.num ∧
              ws.read (.heap 7 a) + 1 = (q.den : ℤ))
          have hinit_coord : CoordInv 0 ((((ws_j.write (.localFrame 1 1 11) (pos_bj : ℤ)).write (.localFrame 1 1 13) (idx_bj : ℤ)).write (.localFrame 1 1 11) (base_bj : ℤ)).write (.localFrame 1 1 10) 0) bs := by
            have hloc : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
                ((((ws_j.write (.localFrame 1 1 11) (pos_bj : ℤ)).write
                  (.localFrame 1 1 13) (idx_bj : ℤ)).write
                  (.localFrame 1 1 11) (base_bj : ℤ)).write (.localFrame 1 1 10) 0).read (.localFrame 1 v idx) =
                ws_j.read (.localFrame 1 v idx) := by
              intro v idx hne1
              simp [rw_write_eq, hne1]
            have hheap : ∀ t idx,
                ((((ws_j.write (.localFrame 1 1 11) (pos_bj : ℤ)).write
                  (.localFrame 1 1 13) (idx_bj : ℤ)).write
                  (.localFrame 1 1 11) (base_bj : ℤ)).write (.localFrame 1 1 10) 0).read (.heap t idx) =
                ws_j.read (.heap t idx) := by
              intro t idx
              simp [rw_write_eq, rf_free_eq]
            refine ⟨rfl, ha_p4,
              hasPhase2Regs_of_eq hregs_j (fun idx => hloc 0 idx (by decide)),
              hasLiftArrays_of_eq hlifts_j (fun v idx hv => hloc v idx (by rcases hv with rfl | rfl <;> decide)),
              hasZArray_of_eq hz_j (fun idx => hloc 4 idx (by decide)),
              hasFYArray_of_eq hfy_j (fun idx => hloc 5 idx (by decide)),
              by simp [rw_write_eq, hr8_j],
              by simp [rw_write_eq, hr9_j],
              wordStore_read_write_self _ _ _,
              by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), wordStore_read_write_self],
              by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                   wordStore_read_write_self],
              by simp [rw_write_eq, hr14_j],
              fun idx => (hloc 7 idx (by decide)).trans (hr7_j idx),
              fun idx => (hloc 8 idx (by decide)).trans (hr8arr_j idx),
              fun t idx ht5 ht6 ht7 => (hheap t idx).trans (hht_j t idx ht5 ht6 ht7),
              fun idx => (hheap 5 idx).trans (hh5_j idx),
              fun c' => ⟨(hheap 6 _).trans (hzc_j c').1, by rw [hheap 7 _]; exact (hzc_j c').2⟩,
              fun idx hr => ⟨(hheap 6 idx).trans (hzz_j idx hr).1, (hheap 7 idx).trans (hzz_j idx hr).2⟩,
              fun j' hj' c' => by dsimp only; rw [hheap 6 _, hheap 7 _]; exact hpts_prev_j j' hj' (hj'.trans hj) c',
              fun _ hc' _ => absurd hc' (by omega)⟩
          obtain ⟨ws_cin, _, hinv_cd, ex_cin⟩ := exec_repeatN_inv (countE := (.readLocal 0 (.lit 0))) (body := phase3InnerCoordBody) p.d CoordInv
            ha_p4 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
            (by simp [rw_write_eq, evalVal_readLocal, evalVal_lit, hregs_j.1.1])
            hinit_coord (U := 300) (B := 300000 * (V + 8) ^ 2)
            (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
            (fun c ws_c bs_c hc ⟨hbs_c, ha_c, hregs_c, hlifts_c, hz_c, hfy_c,
                hr8_c, hr9_c, hr10_c, hr11_c, hr13_c, hr14_c, hr7_c, hr8arr_c,
                hht_c, hh5_c, hzc_c, hzz_c, hprev_c, hcur_c⟩ => by
              subst bs_c
              let addr_c : ℕ := base_bj + c
              have haddr_lt_A : addr_c < A := by dsimp [addr_c]; omega
              have hcoord_b := ratCoordBitBounded_num_den_V (B := p.B_lift) (V := V)
                (hlift_b ⟨c, Nat.lt_succ_of_lt hc⟩) (by omega)
              have hl_eq : liftRatPoint (pts_h idx_bj) ⟨c, Nat.lt_succ_of_lt hc⟩ = pts_h idx_bj ⟨c, hc⟩ :=
                liftRatPoint_cast_lt (pts_h idx_bj) hc
              have hh_mem : idx_bj ∈ inp.activeHandles := by
                rw [hip_handles, Finset.mem_range]; exact hidx_lt_m
              obtain ⟨ha_1, ex_1⟩ := exec_writeLocal_auto (bs := bs) (var := 1) (idxE := (.lit 12)) (idx := 12) (valE := (.add (.readLocal 1 (.lit 11)) (.readLocal 1 (.lit 10)))) (val := (addr_c : ℤ)) ha_c hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
                (by simp only [evalVal_add, evalVal_readLocal, evalVal_lit, hr11_c, hr10_c]
                    dsimp [addr_c]; try push_cast; try ring)
                (by decide) (by omega) (by simp; omega) (idx_V addr_c (by omega))
              have hnum_eval :
                  evalVal inp (ws_c.write (.localFrame 1 1 12) (addr_c : ℤ))
                    (.activeRatNum (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 10))) =
                  (liftRatPoint (pts_h idx_bj) ⟨c, Nat.lt_succ_of_lt hc⟩).num := by
                have h1 : (0 : ℤ) ≤ (idx_bj : ℤ) ∧ ((idx_bj : ℤ)).toNat ∈ inp.activeHandles :=
                  ⟨by positivity, by simpa using hh_mem⟩
                have h2 : (0 : ℤ) ≤ (c : ℤ) ∧ ((c : ℤ)).toNat < p.d :=
                  ⟨by positivity, by simpa using hc⟩
                rw [evalVal_activeRatNum, evalVal_readLocal, evalVal_lit,
                  wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 1 13 ≠ .localFrame 1 1 12),
                  evalVal_readLocal, evalVal_lit,
                  wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 1 10 ≠ .localFrame 1 1 12),
                  hr13_c, hr10_c, dif_pos h1, dif_pos h2]
                simp only [Int.toNat_natCast, hip_coords idx_bj hidx_lt_m, hl_eq]
              obtain ⟨ha_2, ex_2⟩ := exec_writeHeap_auto (t := 6) (idxE := (.readLocal 1 (.lit 12))) (idx := (addr_c : ℤ)) (valE := (.activeRatNum (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 10)))) (val := (liftRatPoint (pts_h idx_bj) ⟨c, Nat.lt_succ_of_lt hc⟩).num) ha_1 hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩
                (by simp only [evalVal_readLocal, evalVal_lit, wordStore_read_write_self])
                hnum_eval (by decide) (by positivity) (by simpa using haddr_lt_A) hcoord_b.1
              have hden_eval :
                  evalVal inp ((ws_c.write (.localFrame 1 1 12) (addr_c : ℤ)).write
                    (.heap 6 (addr_c : ℤ)) (liftRatPoint (pts_h idx_bj) ⟨c, Nat.lt_succ_of_lt hc⟩).num)
                    (.sub (.activeRatDen (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 10))) (.lit 1)) =
                  ((liftRatPoint (pts_h idx_bj) ⟨c, Nat.lt_succ_of_lt hc⟩).den : ℤ) - 1 := by
                have h1 : (0 : ℤ) ≤ (idx_bj : ℤ) ∧ ((idx_bj : ℤ)).toNat ∈ inp.activeHandles :=
                  ⟨by positivity, by simpa using hh_mem⟩
                have h2 : (0 : ℤ) ≤ (c : ℤ) ∧ ((c : ℤ)).toNat < p.d :=
                  ⟨by positivity, by simpa using hc⟩
                rw [evalVal_sub, evalVal_activeRatDen, evalVal_readLocal, evalVal_lit, rw_local_heap,
                  wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 1 13 ≠ .localFrame 1 1 12),
                  evalVal_readLocal, evalVal_lit, rw_local_heap,
                  wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 1 10 ≠ .localFrame 1 1 12),
                  hr13_c, hr10_c, dif_pos h1, dif_pos h2, evalVal_lit]
                simp only [Int.toNat_natCast, hip_coords idx_bj hidx_lt_m, hl_eq]
              obtain ⟨ha_3, ex_3⟩ := exec_writeHeap_auto (t := 7) (idxE := (.readLocal 1 (.lit 12))) (idx := (addr_c : ℤ)) (valE := (.sub (.activeRatDen (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 10))) (.lit 1))) (val := ((liftRatPoint (pts_h idx_bj) ⟨c, Nat.lt_succ_of_lt hc⟩).den : ℤ) - 1) ha_2 hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩
                (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
                      wordStore_read_write_self])
                hden_eval (by decide) (by positivity) (by simpa using haddr_lt_A) hcoord_b.2.2
              obtain ⟨ha_4, ex_4⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 10)) (idx := 10) (valE := (.add (.readLocal 1 (.lit 10)) (.lit 1))) (val := ((c + 1 : ℕ) : ℤ)) ha_3 hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
                (by simp [rw_write_eq, evalVal_add, evalVal_readLocal, evalVal_lit, hr10_c]
                    try push_cast; try ring)
                (by decide) (by omega) (by simp; omega) (idx_V (c + 1) (by omega))
              let ws_next := ((((ws_c.write (.localFrame 1 1 12) (addr_c : ℤ)).write
                (.heap 6 (addr_c : ℤ)) (liftRatPoint (pts_h idx_bj) ⟨c, Nat.lt_succ_of_lt hc⟩).num).write
                (.heap 7 (addr_c : ℤ)) (((liftRatPoint (pts_h idx_bj) ⟨c, Nat.lt_succ_of_lt hc⟩).den : ℤ) - 1)).write
                (.localFrame 1 1 10) (((c + 1 : ℕ) : ℤ)))
              have hloc_ne1 : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
                  ws_next.read (.localFrame 1 v idx) = ws_c.read (.localFrame 1 v idx) := by
                intro v idx hne1
                dsimp [ws_next]
                rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
                  wordStore_read_write_of_ne _ (by intro h; simp at h),
                  wordStore_read_write_of_ne _ (by intro h; simp at h),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv)]
              refine ⟨ws_next, bs, ⟨rfl, ha_4,
                hasPhase2Regs_of_eq hregs_c (fun idx => hloc_ne1 0 idx (by decide)),
                hasLiftArrays_of_eq hlifts_c (fun v idx hv => hloc_ne1 v idx (by rcases hv with rfl | rfl <;> decide)),
                hasZArray_of_eq hz_c (fun idx => hloc_ne1 4 idx (by decide)),
                hasFYArray_of_eq hfy_c (fun idx => hloc_ne1 5 idx (by decide)),
                by dsimp [ws_next]; rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                     wordStore_read_write_of_ne _ (by intro h; simp at h),
                     wordStore_read_write_of_ne _ (by intro h; simp at h),
                     wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr8_c],
                by dsimp [ws_next]; rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                     wordStore_read_write_of_ne _ (by intro h; simp at h),
                     wordStore_read_write_of_ne _ (by intro h; simp at h),
                     wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr9_c],
                wordStore_read_write_self _ _ _,
                by dsimp [ws_next]; rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                     wordStore_read_write_of_ne _ (by intro h; simp at h),
                     wordStore_read_write_of_ne _ (by intro h; simp at h),
                     wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr11_c],
                by dsimp [ws_next]; rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                     wordStore_read_write_of_ne _ (by intro h; simp at h),
                     wordStore_read_write_of_ne _ (by intro h; simp at h),
                     wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr13_c],
                by dsimp [ws_next]; rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                     wordStore_read_write_of_ne _ (by intro h; simp at h),
                     wordStore_read_write_of_ne _ (by intro h; simp at h),
                     wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr14_c],
                fun idx => (hloc_ne1 7 idx (by decide)).trans (hr7_c idx),
                fun idx => (hloc_ne1 8 idx (by decide)).trans (hr8arr_c idx),
                fun t idx ht5 ht6 ht7 => by
                  dsimp [ws_next]
                  rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                    wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht7 ht),
                    wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht6 ht),
                    wordStore_read_write_of_ne _ (by intro h; simp at h)]
                  exact hht_c t idx ht5 ht6 ht7,
                fun idx => by
                  dsimp [ws_next]
                  rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; simp at h)]
                  exact hh5_c idx,
                fun c' => by
                  have hne_a : (c'.1 : ℤ) ≠ (addr_c : ℤ) := by
                    have := c'.2; dsimp [addr_c, base_bj]; omega
                  dsimp [ws_next]
                  exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                              wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                              wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                              wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzc_c c').1,
                         by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                              wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                              wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                              wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzc_c c').2⟩,
                fun idx hr => by
                  have hne_a : idx ≠ (addr_c : ℤ) := by dsimp [addr_c, base_bj] at hr ⊢; omega
                  dsimp [ws_next]
                  exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                              wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                              wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                              wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzz_c idx hr).1,
                         by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                              wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                              wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                              wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzz_c idx hr).2⟩,
                fun j' hj' c' => by
                  dsimp only
                  have hj'_lt : p.D + j' * p.D + c'.1 < base_bj := by
                    have h1 : (j' + 1) * p.D ≤ j * p.D := Nat.mul_le_mul_right p.D hj'
                    rw [Nat.add_mul, Nat.one_mul] at h1
                    have := c'.2; dsimp [base_bj]; omega
                  have hne_a : ((p.D + j' * p.D + c'.1 : ℕ) : ℤ) ≠ (addr_c : ℤ) := by
                    dsimp [addr_c]; omega
                  dsimp [ws_next]
                  exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                              wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                              wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                              wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hprev_c j' hj' c').1,
                         by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                              wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                              wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                              wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hprev_c j' hj' c').2⟩,
                fun c' hc' hcd => by
                  dsimp only
                  rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hc') with hlt | rfl
                  · have hne_a : ((base_bj + c' : ℕ) : ℤ) ≠ (addr_c : ℤ) := by dsimp [addr_c]; omega
                    dsimp [ws_next]
                    exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                                wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                                wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                                wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hcur_c c' hlt hcd).1,
                           by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                                wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                                wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                                wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hcur_c c' hlt hcd).2⟩
                  · dsimp [ws_next, addr_c]
                    exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                                wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), wordStore_read_write_self],
                           by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                                wordStore_read_write_self]; ring⟩⟩,
                ExecBounded.mono (ExecBounded.seq ex_1 (ExecBounded.seq ex_2 (ExecBounded.seq ex_3 ex_4)))
                  (by omega) (by omega) le_rfl le_rfl⟩)
          rcases hinv_cd with ⟨hbs_cd, ha_cd, hregs_cd, hlifts_cd, hz_cd, hfy_cd,
            hr8_cd, hr9_cd, _, hr11_cd, hr13_cd, hr14_cd, hr7_cd, hr8arr_cd,
            hht_cd, hh5_cd, hzc_cd, hzz_cd, hprev_cd, hcur_cd⟩
          rw [hbs_cd] at ex_cin
          let addr_d : ℕ := base_bj + p.d
          have haddr_d_lt : addr_d < A := by dsimp [addr_d]; omega
          have hlast_b := ratCoordBitBounded_num_den_V (B := p.B_lift) (V := V) (hlift_b (Fin.last p.d)) (by omega)
          obtain ⟨ha_l1, ex_l1⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 12)) (idx := 12) (valE := (.add (.readLocal 1 (.lit 11)) (.readLocal 0 (.lit 0)))) (val := (addr_d : ℤ)) ha_cd hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
            (by simp only [evalVal_add, evalVal_readLocal, evalVal_lit, hr11_cd, hregs_cd.1.1]
                dsimp [addr_d]; try push_cast; try ring)
            (by decide) (by omega) (by simp; omega) (idx_V addr_d (by omega))
          obtain ⟨ha_l2, ex_l2⟩ := exec_writeHeap_auto (t := 6) (idxE := (.readLocal 1 (.lit 12))) (idx := (addr_d : ℤ)) (valE := (.readLocal 2 (.readLocal 1 (.lit 13)))) (val := (liftRatPoint (pts_h idx_bj) (Fin.last p.d)).num) ha_l1 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by simp [exprNodes], by simp [exprNodes]⟩
            (by simp only [evalVal_readLocal, evalVal_lit, wordStore_read_write_self])
            (by simp [rw_write_eq, evalVal_readLocal, evalVal_lit, hr13_cd, (hlifts_cd idx_bj hidx_lt_m).1])
            (by decide) (by positivity) (by simpa using haddr_d_lt) hlast_b.1
          obtain ⟨ha_l3, ex_l3⟩ := exec_writeHeap_auto (t := 7) (idxE := (.readLocal 1 (.lit 12))) (idx := (addr_d : ℤ)) (valE := (.sub (.readLocal 3 (.readLocal 1 (.lit 13))) (.lit 1))) (val := ((liftRatPoint (pts_h idx_bj) (Fin.last p.d)).den : ℤ) - 1) ha_l2 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by simp [exprNodes], by simp [exprNodes]⟩
            (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
                  wordStore_read_write_self])
            (by simp [rw_write_eq, evalVal_sub, evalVal_readLocal, evalVal_lit, hr13_cd, (hlifts_cd idx_bj hidx_lt_m).2])
            (by decide) (by positivity) (by simpa using haddr_d_lt) hlast_b.2.2
          obtain ⟨ha_l4, ex_l4⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 9)) (idx := 9) (valE := (.add (.readLocal 1 (.lit 9)) (.lit 1))) (val := ((j + 1 : ℕ) : ℤ)) ha_l3 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
            (by simp [rw_write_eq, evalVal_add, evalVal_readLocal, evalVal_lit, hr9_cd]
                try push_cast; try ring)
            (by decide) (by omega) (by simp; omega) (idx_V (j + 1) (by omega))
          let ws_jnext := ((((ws_cin.write (.localFrame 1 1 12) (addr_d : ℤ)).write
            (.heap 6 (addr_d : ℤ)) (liftRatPoint (pts_h idx_bj) (Fin.last p.d)).num).write
            (.heap 7 (addr_d : ℤ)) (((liftRatPoint (pts_h idx_bj) (Fin.last p.d)).den : ℤ) - 1)).write
            (.localFrame 1 1 9) (((j + 1 : ℕ) : ℤ)))
          have hloc_out : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
              ws_jnext.read (.localFrame 1 v idx) = ws_cin.read (.localFrame 1 v idx) := by
            intro v idx hne1
            dsimp [ws_jnext]
            rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
              wordStore_read_write_of_ne _ (by intro h; simp at h),
              wordStore_read_write_of_ne _ (by intro h; simp at h),
              wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv)]
          have ex_jstep :=
            ExecBounded.seq ex_p1 (ExecBounded.seq ex_p2 (ExecBounded.seq ex_p3
            (ExecBounded.seq ex_p4 (ExecBounded.seq ex_cin (ExecBounded.seq ex_l1
            (ExecBounded.seq ex_l2 (ExecBounded.seq ex_l3 ex_l4)))))))
          have hb_jstep :
              66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 +
              (66000 * (V + 8) ^ 2 + ((66000 * (V + 8) ^ 2 + p.d * (300000 * (V + 8) ^ 2)) +
              (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2))))))) ≤
              (800000 + 300000 * p.d) * (V + 8) ^ 2 := by
            set Y := (V + 8) ^ 2
            have : (800000 + 300000 * p.d) * Y = 800000 * Y + p.d * (300000 * Y) := by ring
            omega
          refine ⟨ws_jnext, bs, ⟨rfl, ha_l4,
            hasPhase2Regs_of_eq hregs_cd (fun idx => hloc_out 0 idx (by decide)),
            hasLiftArrays_of_eq hlifts_cd (fun v idx hv => hloc_out v idx (by rcases hv with rfl | rfl <;> decide)),
            hasZArray_of_eq hz_cd (fun idx => hloc_out 4 idx (by decide)),
            hasFYArray_of_eq hfy_cd (fun idx => hloc_out 5 idx (by decide)),
            by dsimp [ws_jnext]; rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                 wordStore_read_write_of_ne _ (by intro h; simp at h),
                 wordStore_read_write_of_ne _ (by intro h; simp at h),
                 wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr8_cd],
            wordStore_read_write_self _ _ _,
            by dsimp [ws_jnext]; rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                 wordStore_read_write_of_ne _ (by intro h; simp at h),
                 wordStore_read_write_of_ne _ (by intro h; simp at h),
                 wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr14_cd],
            fun idx => (hloc_out 7 idx (by decide)).trans (hr7_cd idx),
            fun idx => (hloc_out 8 idx (by decide)).trans (hr8arr_cd idx),
            fun t idx ht5 ht6 ht7 => by
              dsimp [ws_jnext]
              rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht7 ht),
                wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht6 ht),
                wordStore_read_write_of_ne _ (by intro h; simp at h)]
              exact hht_cd t idx ht5 ht6 ht7,
            fun idx => by
              dsimp [ws_jnext]
              rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                wordStore_read_write_of_ne _ (by intro h; simp at h)]
              exact hh5_cd idx,
            fun c' => by
              have hne_ad : (c'.1 : ℤ) ≠ (addr_d : ℤ) := by
                have := c'.2; dsimp [addr_d, base_bj]; omega
              dsimp [ws_jnext]
              exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                          wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                          wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
                          wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzc_cd c').1,
                     by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                          wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
                          wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                          wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzc_cd c').2⟩,
            fun idx hr => by
              have hne_ad : idx ≠ (addr_d : ℤ) := by dsimp [addr_d] at hr ⊢; omega
              dsimp [ws_jnext]
              exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                          wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                          wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
                          wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzz_cd idx hr).1,
                     by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                          wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
                          wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                          wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hzz_cd idx hr).2⟩,
            fun j' hj' hjs c' => by
              dsimp only
              rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hj') with hlt | hjeq
              · have hj'_lt : p.D + j' * p.D + c'.1 < base_bj := by
                  have h1 : (j' + 1) * p.D ≤ j * p.D := Nat.mul_le_mul_right p.D hlt
                  rw [Nat.add_mul, Nat.one_mul] at h1
                  have := c'.2; dsimp [base_bj]; omega
                have hne_ad : ((p.D + j' * p.D + c'.1 : ℕ) : ℤ) ≠ (addr_d : ℤ) := by
                  dsimp [addr_d]; omega
                dsimp [ws_jnext]
                exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                            wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                            wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
                            wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hprev_cd j' hlt c').1,
                       by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                            wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
                            wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                            wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hprev_cd j' hlt c').2⟩
              · subst j'
                have hc'_le : c'.1 ≤ p.d := by have := c'.2; dsimp [CoreParams.D] at this; omega
                rcases Nat.lt_or_eq_of_le hc'_le with hclt | hceq
                · have hne_ad : ((p.D + j * p.D + c'.1 : ℕ) : ℤ) ≠ (addr_d : ℤ) := by
                    dsimp [addr_d, base_bj]; omega
                  have ha_eq : ((p.D + j * p.D + c'.1 : ℕ) : ℤ) = ((base_bj + c'.1 : ℕ) : ℤ) := rfl
                  rw [ha_eq]
                  dsimp only [ws_jnext]
                  exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                              wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                              wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
                              wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hcur_cd c'.1 hclt hclt).1,
                         by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                              wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
                              wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                              wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact (hcur_cd c'.1 hclt hclt).2⟩
                · have hc_last : c' = Fin.last p.d := by ext; exact hceq
                  have ha_eq : ((p.D + j * p.D + c'.1 : ℕ) : ℤ) = (addr_d : ℤ) := by
                    dsimp [addr_d, base_bj]; rw [hceq]
                  subst hc_last
                  rw [ha_eq]
                  dsimp only [ws_jnext]
                  exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                              wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), wordStore_read_write_self],
                         by rw [wordStore_read_write_of_ne _ (by intro h; simp at h),
                              wordStore_read_write_self]; ring⟩⟩,
            ExecBounded.mono ex_jstep (by omega) hb_jstep le_rfl le_rfl⟩)
      rcases hinv_s0 with ⟨hbs_s0, ha_sb, hregs_sb, hlifts_sb, hz_sb, hfy_sb,
        hr8_sb, _, hr14_sb, hr7_sb, hr8arr_sb, hht_sb, hh5_sb, hzc_sb, hzz_sb, hpts_sb⟩
      rw [hbs_s0] at ex_sj
      -- 2b. Prove `SimStageMatches false`
      have hstage_b : SimStageMatches false p.d 0 V wsStaged_b (certBlockInp p pts_h zRat π bFin) := by
        refine ⟨ha_sb.1, by omega, hd_V, ?_⟩
        rw [if_neg Bool.false_ne_true]
        have hextra : (certBlockInp p pts_h zRat π bFin).extraRats =
            List.ofFn zRat ++ (List.finRange p.s₀).flatMap
              (fun j => List.ofFn (liftRatPoint (pts_h (blkHandle p π bFin j).1))) := rfl
        have hfl_len : ((List.finRange p.s₀).flatMap
            (fun j => List.ofFn (liftRatPoint (pts_h (blkHandle p π bFin j).1)))).length = p.s₀ * p.D :=
          flatPts_length _
        refine ⟨rfl, rfl, hh5_sb, ?_, ?_⟩
        · intro idx
          rw [hextra]
          by_cases hn : idx < 0
          · rw [(hzz_sb idx (Or.inl hn)).1]; unfold listGetIntD; rw [if_neg (not_le_of_gt hn)]; simp
          · push_neg at hn
            by_cases hltD : idx < (p.D : ℤ)
            · have hiD : idx.toNat < p.D := by omega
              have hi_eq : idx = (idx.toNat : ℤ) := (Int.toNat_of_nonneg hn).symm
              rw [hi_eq, (hzc_sb ⟨idx.toNat, hiD⟩).1]
              unfold listGetIntD; rw [if_pos (Int.natCast_nonneg _)]
              simp only [Int.toNat_natCast, List.getD]
              rw [List.getElem?_eq_getElem (by rw [List.length_append, List.length_ofFn]; omega),
                List.getElem_append_left (by rw [List.length_ofFn]; omega),
                List.getElem_ofFn, Option.getD_some]
            · by_cases hltTot : idx < ((p.D + p.s₀ * p.D : ℕ) : ℤ)
              · set rem : ℕ := idx.toNat - p.D
                have hrem_lt : rem < p.s₀ * p.D := by omega
                have hrem_lt' : rem < p.D * p.s₀ := by rw [mul_comm]; exact hrem_lt
                let j_q : Fin p.s₀ := ⟨rem / p.D, Nat.div_lt_of_lt_mul hrem_lt'⟩
                let c_q : Fin p.D := ⟨rem % p.D, Nat.mod_lt _ hD_pos⟩
                have hrem_eq : j_q.1 * p.D + c_q.1 = rem := by
                  dsimp [j_q, c_q]; rw [mul_comm]; exact Nat.div_add_mod rem p.D
                have hidx_eq : idx = ((p.D + j_q.1 * p.D + c_q.1 : ℕ) : ℤ) := by omega
                rw [hidx_eq, (hpts_sb j_q.1 j_q.2 j_q.2 c_q).1]
                unfold listGetIntD; rw [if_pos (Int.natCast_nonneg _)]
                simp only [Int.toNat_natCast, List.getD]
                have hlen_tot : p.D + j_q.1 * p.D + c_q.1 <
                    (List.ofFn zRat ++ (List.finRange p.s₀).flatMap
                      (fun j => List.ofFn (liftRatPoint (pts_h (blkHandle p π bFin j).1)))).length := by
                  rw [List.length_append, List.length_ofFn, hfl_len]; omega
                rw [List.getElem?_eq_getElem hlen_tot,
                  List.getElem_append_right (by rw [List.length_ofFn]; omega), Option.getD_some]
                simp only [List.length_ofFn, Nat.add_assoc, Nat.add_sub_cancel_left]
                exact congrArg Rat.num (flatPts_getElem (fun j => liftRatPoint (pts_h (blkHandle p π bFin j).1)) j_q c_q).symm
              · rw [(hzz_sb idx (Or.inr (by omega))).1]
                unfold listGetIntD; rw [if_pos hn]
                have hnone : ((List.ofFn zRat ++ (List.finRange p.s₀).flatMap
                    (fun j => List.ofFn (liftRatPoint (pts_h (blkHandle p π bFin j).1))))[idx.toNat]?) = none :=
                  List.getElem?_eq_none (by rw [List.length_append, List.length_ofFn, hfl_len]; omega)
                rw [List.getD, hnone]; simp
        · intro idx
          rw [hextra]
          by_cases hn : idx < 0
          · rw [(hzz_sb idx (Or.inl hn)).2]; unfold listGetIntD; rw [if_neg (not_le_of_gt hn)]; simp
          · push_neg at hn
            by_cases hltD : idx < (p.D : ℤ)
            · have hiD : idx.toNat < p.D := by omega
              have hi_eq : idx = (idx.toNat : ℤ) := (Int.toNat_of_nonneg hn).symm
              rw [hi_eq, (hzc_sb ⟨idx.toNat, hiD⟩).2]
              unfold listGetIntD; rw [if_pos (Int.natCast_nonneg _)]
              simp only [Int.toNat_natCast, List.getD]
              rw [List.getElem?_eq_getElem (by rw [List.length_append, List.length_ofFn]; omega),
                List.getElem_append_left (by rw [List.length_ofFn]; omega),
                List.getElem_ofFn, Option.getD_some]
            · by_cases hltTot : idx < ((p.D + p.s₀ * p.D : ℕ) : ℤ)
              · set rem : ℕ := idx.toNat - p.D
                have hrem_lt : rem < p.s₀ * p.D := by omega
                have hrem_lt' : rem < p.D * p.s₀ := by rw [mul_comm]; exact hrem_lt
                let j_q : Fin p.s₀ := ⟨rem / p.D, Nat.div_lt_of_lt_mul hrem_lt'⟩
                let c_q : Fin p.D := ⟨rem % p.D, Nat.mod_lt _ hD_pos⟩
                have hrem_eq : j_q.1 * p.D + c_q.1 = rem := by
                  dsimp [j_q, c_q]; rw [mul_comm]; exact Nat.div_add_mod rem p.D
                have hidx_eq : idx = ((p.D + j_q.1 * p.D + c_q.1 : ℕ) : ℤ) := by omega
                rw [hidx_eq, (hpts_sb j_q.1 j_q.2 j_q.2 c_q).2]
                unfold listGetIntD; rw [if_pos (Int.natCast_nonneg _)]
                simp only [Int.toNat_natCast, List.getD]
                have hlen_tot : p.D + j_q.1 * p.D + c_q.1 <
                    (List.ofFn zRat ++ (List.finRange p.s₀).flatMap
                      (fun j => List.ofFn (liftRatPoint (pts_h (blkHandle p π bFin j).1)))).length := by
                  rw [List.length_append, List.length_ofFn, hfl_len]; omega
                rw [List.getElem?_eq_getElem hlen_tot,
                  List.getElem_append_right (by rw [List.length_ofFn]; omega), Option.getD_some]
                simp only [List.length_ofFn, Nat.add_assoc, Nat.add_sub_cancel_left]
                exact congrArg (fun q : ℚ => (q.den : ℤ)) (flatPts_getElem (fun j => liftRatPoint (pts_h (blkHandle p π bFin j).1)) j_q c_q).symm
              · rw [(hzz_sb idx (Or.inr (by omega))).2]
                unfold listGetIntD; rw [if_pos hn]
                have hnone : ((List.ofFn zRat ++ (List.finRange p.s₀).flatMap
                    (fun j => List.ofFn (liftRatPoint (pts_h (blkHandle p π bFin j).1))))[idx.toNat]?) = none :=
                  List.getElem?_eq_none (by rw [List.length_append, List.length_ofFn, hfl_len]; omega)
                rw [List.getD, hnone]; simp
      -- 2c. Call `progCert`
      have hV_flag : intBitLength ((outCert bFin).words.read (.heap 0 0)) ≤ V :=
        (outSub_read_bitLength_le (hrun_cert bFin) (.heap 0 0)).trans (by have := (hcert_bounds bFin).2.2.2; omega)
      have hV_out : ∀ j : ℕ, j < 2 * p.s₀ → intBitLength ((outCert bFin).words.read (.heap 1 (j : ℤ))) ≤ V :=
        fun j _ => (outSub_read_bitLength_le (hrun_cert bFin) (.heap 1 (j : ℤ))).trans
          (by have := (hcert_bounds bFin).2.2.2; omega)
      have hV_idx_2s : ∀ k : ℕ, k ≤ 2 * p.s₀ → intBitLength (k : ℤ) ≤ V :=
        fun k _ => idx_V k (by omega)
      have ex_sub := exec_runSubAndExtractStmt (inpSim := inp) (isDimD := false) (progSub := progCert)
        (flagVar := 1) (flagIdx := 15) (outVar := 6) (nOutLoc := some (0, 15))
        (loopIdxVar := 9) (N_out := 2 * p.s₀) (bs := bs)
        (U_sub := U_cert) (B_sub := U_cert) (C_sub := U_cert) (S_sub := U_cert)
        ha_sb hstage_b (hrun_cert bFin)
        ⟨by decide, by decide, by decide, by decide, by decide, by decide⟩
        ⟨by omega, by omega, by omega⟩
        ⟨by decide, by omega, by decide, by decide, hregs_sb.1.2.2.2.2.2.2.2.2.2.2.2.2.2⟩
        hV_flag hV_out (by omega) (hcert_bounds bFin)
      obtain ⟨ha_ext, hr_flag_ext, hr_out_ext, hoth_ext⟩ := extractSubResultWS_props ha_sb
        (wsOutSub := (outCert bFin).words) (flagVar := 1) (flagIdx := 15) (outVar := 6)
        (loopIdxVar := 9) (N_out := 2 * p.s₀)
        ⟨by decide, by decide, by decide, by decide, by decide, by decide⟩
        ⟨by omega, by omega, by omega⟩ hV_flag hV_idx_2s hV_out
      let wsExt := extractSubResultWS wsStaged_b 1 15 6 9 (outCert bFin).words (2 * p.s₀)
      have hregs_ext : HasPhase2Regs p M wsExt :=
        hasPhase2Regs_of_eq hregs_sb (fun idx =>
          hoth_ext _ (by intro h; injection h; intros; omega) (by intro h; injection h; intros; omega)
            (by intro h; injection h; intros; omega) (fun _ _ h => by injection h; intros; omega))
      have hlifts_ext : HasLiftArrays p pts_h wsExt :=
        hasLiftArrays_of_eq hlifts_sb (fun v idx hv =>
          hoth_ext _ (by intro h; rcases hv with rfl | rfl <;> (injection h; intros; omega))
            (by intro h; rcases hv with rfl | rfl <;> (injection h; intros; omega))
            (by intro h; rcases hv with rfl | rfl <;> (injection h; intros; omega))
            (fun _ _ h => by rcases hv with rfl | rfl <;> (injection h; intros; omega)))
      have hz_ext : HasZArray p.D zRat wsExt :=
        hasZArray_of_eq hz_sb (fun idx =>
          hoth_ext _ (by intro h; injection h; intros; omega) (by intro h; injection h; intros; omega)
            (by intro h; injection h; intros; omega) (fun _ _ h => by injection h; intros; omega))
      have hfy_ext : HasFYArray p.m π wsExt :=
        hasFYArray_of_eq hfy_sb (fun idx =>
          hoth_ext _ (by intro h; injection h; intros; omega) (by intro h; injection h; intros; omega)
            (by intro h; injection h; intros; omega) (fun _ _ h => by injection h; intros; omega))
      have hr8_ext : wsExt.read (.localFrame 1 1 8) = (b : ℤ) :=
        (hoth_ext _ (by intro h; injection h; intros; omega) (by intro h; injection h; intros; omega)
          (by intro h; injection h; intros; omega) (fun _ _ h => by injection h; intros; omega)).trans hr8_sb
      have hr14_ext : wsExt.read (.localFrame 1 1 14) = (k_cur : ℤ) :=
        (hoth_ext _ (by intro h; injection h; intros; omega) (by intro h; injection h; intros; omega)
          (by intro h; injection h; intros; omega) (fun _ _ h => by injection h; intros; omega)).trans hr14_sb
      have hr7_ext : ∀ idx : ℤ, wsExt.read (.localFrame 1 7 idx) = ws_b.read (.localFrame 1 7 idx) :=
        fun idx => (hoth_ext _ (by intro h; injection h; intros; omega) (by intro h; injection h; intros; omega)
          (by intro h; injection h; intros; omega) (fun _ _ h => by injection h; intros; omega)).trans (hr7_sb idx)
      have hr8arr_ext : ∀ idx : ℤ, wsExt.read (.localFrame 1 8 idx) = ws_b.read (.localFrame 1 8 idx) :=
        fun idx => (hoth_ext _ (by intro h; injection h; intros; omega) (by intro h; injection h; intros; omega)
          (by intro h; injection h; intros; omega) (fun _ _ h => by injection h; intros; omega)).trans (hr8arr_sb idx)
      have hheap_ext : ∀ t idx, wsExt.read (.heap t idx) = wsStaged_b.read (.heap t idx) :=
        fun t idx => hoth_ext _ (by intro h; cases h) (by intro h; cases h)
          (by intro h; cases h) (fun _ _ h => by cases h)
      -- 2d. Conditional copy if `passBool bFin = true`
      have htake_succ : (List.finRange p.r).take (b + 1) = (List.finRange p.r).take b ++ [bFin] := by
        have hlen : b < (List.finRange p.r).length := by simp [hb]
        rw [List.take_succ_eq_append_getElem hlen]
        have hget : (List.finRange p.r)[b] = bFin := by ext; simp [bFin]
        rw [hget]
      have hcond_eval : evalCondVal inp wsExt (.intEq (.readLocal 1 (.lit 15)) (.lit 1)) = passBool bFin := by
        have h15 : wsExt.read (.localFrame 1 1 15) = (outCert bFin).words.read (.heap 0 0) := hr_flag_ext
        simp only [evalCondVal_intEq, evalVal_readLocal, evalVal_lit, h15, passBool]
      have hite_res :
          ∃ wsAfterIte : WordStore,
            InAttemptArena A V wsAfterIte ∧
            HasPhase2Regs p M wsAfterIte ∧
            HasLiftArrays p pts_h wsAfterIte ∧
            HasZArray p.D zRat wsAfterIte ∧
            HasFYArray p.m π wsAfterIte ∧
            wsAfterIte.read (.localFrame 1 1 8) = (b : ℤ) ∧
            wsAfterIte.read (.localFrame 1 1 14) = ((passedPre (b + 1)).length : ℤ) ∧
            (∀ t idx, wsAfterIte.read (.heap t idx) = wsStaged_b.read (.heap t idx)) ∧
            (∀ (i : ℕ) (hi : i < (passedPre (b + 1)).length) (j : Fin p.s₀),
              let flatIdx : ℤ := ((i * p.s₀ + j.1 : ℕ) : ℤ)
              wsAfterIte.read (.localFrame 1 7 flatIdx) = ((blkHandle p π (passedPre (b + 1))[i] j).1 : ℤ) ∧
              wsAfterIte.read (.localFrame 1 8 (2 * flatIdx)) =
                (outCert (passedPre (b + 1))[i]).words.read (.heap 1 (2 * (j.1 : ℤ))) ∧
              wsAfterIte.read (.localFrame 1 8 (2 * flatIdx + 1)) =
                (outCert (passedPre (b + 1))[i]).words.read (.heap 1 (2 * (j.1 : ℤ) + 1))) ∧
            ExecBounded inp
              (if passBool bFin then
                .seq (.writeLocal 1 (.lit 9) (.lit 0))
                (.seq (.repeatN (.readLocal 0 (.lit 5)) phase5CopyPassBody)
                      (.writeLocal 1 (.lit 14) (.add (.readLocal 1 (.lit 14)) (.lit 1))))
              else .skip)
              wsExt bs wsAfterIte bs
              (300 + 600 * p.s₀) ((300000 + 600000 * p.s₀) * (V + 8) ^ 2)
              (arenaCellCap inp A) (arenaBitCap inp A V) := by
        by_cases hpass : passBool bFin = true
        · rw [if_pos hpass]
          have hpre_succ : passedPre (b + 1) = passedPre b ++ [bFin] := by
            dsimp [passedPre]; rw [htake_succ, List.filter_append, List.filter_cons_of_pos hpass, List.filter_nil]
          obtain ⟨ha_c0, ex_c0⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 9)) (idx := 9) (valE := (.lit 0)) (val := 0) (bs := bs) ha_ext hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl rfl (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
          let CopyInv (j : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
            bs_c = bs ∧
            InAttemptArena A V ws ∧
            HasPhase2Regs p M ws ∧
            HasLiftArrays p pts_h ws ∧
            HasZArray p.D zRat ws ∧
            HasFYArray p.m π ws ∧
            ws.read (.localFrame 1 1 8) = (b : ℤ) ∧
            ws.read (.localFrame 1 1 9) = (j : ℤ) ∧
            ws.read (.localFrame 1 1 14) = (k_cur : ℤ) ∧
            (∀ j' : ℕ, j' < 2 * p.s₀ →
              ws.read (.localFrame 1 6 (j' : ℤ)) = (outCert bFin).words.read (.heap 1 (j' : ℤ))) ∧
            (∀ t idx, ws.read (.heap t idx) = wsStaged_b.read (.heap t idx)) ∧
            (∀ idx : ℤ, idx < ((k_cur * p.s₀ : ℕ) : ℤ) →
              ws.read (.localFrame 1 7 idx) = ws_b.read (.localFrame 1 7 idx)) ∧
            (∀ idx : ℤ, idx < ((2 * (k_cur * p.s₀) : ℕ) : ℤ) →
              ws.read (.localFrame 1 8 idx) = ws_b.read (.localFrame 1 8 idx)) ∧
            (∀ (j' : ℕ) (hj' : j' < j) (hjs : j' < p.s₀),
              let flatIdx : ℤ := ((k_cur * p.s₀ + j' : ℕ) : ℤ)
              ws.read (.localFrame 1 7 flatIdx) = ((blkHandle p π bFin ⟨j', hjs⟩).1 : ℤ) ∧
              ws.read (.localFrame 1 8 (2 * flatIdx)) =
                (outCert bFin).words.read (.heap 1 (2 * (j' : ℤ))) ∧
              ws.read (.localFrame 1 8 (2 * flatIdx + 1)) =
                (outCert bFin).words.read (.heap 1 (2 * (j' : ℤ) + 1)))
          have hinit_cp : CopyInv 0 (wsExt.write (.localFrame 1 1 9) 0) bs := by
            refine ⟨rfl, ha_c0,
              hasPhase2Regs_of_eq hregs_ext (fun _ => by simp [rw_write_eq]),
              hasLiftArrays_of_eq hlifts_ext (fun v _ hv =>
                by rcases hv with rfl | rfl <;> simp [rw_write_eq]),
              hasZArray_of_eq hz_ext (fun _ => by simp [rw_write_eq]),
              hasFYArray_of_eq hfy_ext (fun _ => by simp [rw_write_eq]),
              by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr8_ext],
              wordStore_read_write_self _ _ _,
              by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr14_ext],
              fun j' hj' => by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega))]; exact hr_out_ext j' hj',
              fun t idx => by rw [wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact hheap_ext t idx,
              fun idx _ => by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega))]; exact hr7_ext idx,
              fun idx _ => by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega))]; exact hr8arr_ext idx,
              fun _ hj' _ => absurd hj' (by omega)⟩
          obtain ⟨wsCp, _, hinv_cp, ex_cp⟩ := exec_repeatN_inv (countE := (.readLocal 0 (.lit 5))) (body := phase5CopyPassBody) p.s₀ CopyInv
            ha_c0 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
            (by have hs5 : (extractSubResultWS wsStaged_b 1 15 6 9 (outCert bFin).words (2 * p.s₀)).read (.localFrame 1 0 5) = (p.s₀ : ℤ) := hregs_ext.1.2.2.2.2.2.1; simp [wsExt, rw_write_eq, evalVal_readLocal, evalVal_lit, hs5])
            hinit_cp (U := 560) (B := 560000 * (V + 8) ^ 2)
            (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
            (fun j ws_j bs_j hj ⟨hbs_j, ha_j, hregs_j, hlifts_j, hz_j, hfy_j,
                hr8_j, hr9_j, hr14_j, hr6_j, hheap_j, hr7_prev, hr8_prev, hr_cur⟩ => by
              subst bs_j
              let pos_bj : ℕ := b * p.s₀ + j
              have hpos_lt_m : pos_bj < p.m := by
                have hb1 : (b + 1) * p.s₀ ≤ p.r * p.s₀ := Nat.mul_le_mul_right p.s₀ hb
                rw [Nat.add_mul, Nat.one_mul] at hb1; dsimp [pos_bj]; omega
              let flat_j : ℕ := k_cur * p.s₀ + j
              have hflat_lt_m : flat_j < p.m := by
                have hk1 : (k_cur + 1) * p.s₀ ≤ p.r * p.s₀ :=
                  Nat.mul_le_mul_right p.s₀ (Nat.succ_le_of_lt (lt_of_le_of_lt hk_cur_le_b hb))
                rw [Nat.add_mul, Nat.one_mul] at hk1; dsimp [flat_j]; omega
              let hdl_j : ℕ := (blkHandle p π bFin ⟨j, hj⟩).1
              have hhdl_lt_m : hdl_j < p.m := (blkHandle p π bFin ⟨j, hj⟩).2
              obtain ⟨ha_1, ex_1⟩ := exec_writeLocal_auto (bs := bs) (var := 1) (idxE := (.lit 10)) (idx := 10) (valE := (.add (.mul (.readLocal 1 (.lit 8)) (.readLocal 0 (.lit 5))) (.readLocal 1 (.lit 9)))) (val := (pos_bj : ℤ)) ha_j hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
                (by simp only [evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit,
                      hr8_j, hregs_j.1.2.2.2.2.2.1, hr9_j]
                    dsimp [pos_bj]; try push_cast; try ring)
                (by decide) (by omega) (by simp; omega) (idx_V pos_bj (by omega))
              obtain ⟨ha_2, ex_2⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 11)) (idx := 11) (valE := (.add (.mul (.readLocal 1 (.lit 14)) (.readLocal 0 (.lit 5))) (.readLocal 1 (.lit 9)))) (val := (flat_j : ℤ)) ha_1 hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
                (by simp [rw_write_eq, evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit, hr14_j, hregs_j.1.2.2.2.2.2.1, hr9_j]
                    dsimp [flat_j]; try push_cast; try ring)
                (by decide) (by omega) (by simp; omega) (idx_V flat_j (by omega))
              obtain ⟨ha_3, ex_3⟩ := exec_writeLocal_auto (var := 7) (idxE := (.readLocal 1 (.lit 11))) (idx := (flat_j : ℤ)) (valE := (.readLocal 5 (.readLocal 1 (.lit 10)))) (val := (hdl_j : ℤ)) ha_2 hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩
                (by simp only [evalVal_readLocal, evalVal_lit, wordStore_read_write_self])
                (by simp [rw_write_eq, evalVal_readLocal, evalVal_lit]
                    exact hfy_j ⟨pos_bj, hpos_lt_m⟩)
                (by decide) (by positivity) (by simpa using (by omega : flat_j < A)) (idx_V hdl_j (by omega))
              obtain ⟨ha_4, ex_4⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 12)) (idx := 12) (valE := (.mul (.lit 2) (.readLocal 1 (.lit 11)))) (val := 2 * (flat_j : ℤ)) ha_3 hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
                (by simp [rw_write_eq, evalVal_mul, evalVal_readLocal, evalVal_lit])
                (by decide) (by omega) (by simp; omega) (by have heq : (2 * (flat_j : ℤ)) = ((2 * flat_j : ℕ) : ℤ) := by { try push_cast; try ring }; rw [heq]; exact idx_V (2 * flat_j) (by omega))
              obtain ⟨ha_5, ex_5⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 13)) (idx := 13) (valE := (.mul (.lit 2) (.readLocal 1 (.lit 9)))) (val := 2 * (j : ℤ)) ha_4 hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
                (by simp [rw_write_eq, evalVal_mul, evalVal_readLocal, evalVal_lit, hr9_j])
                (by decide) (by omega) (by simp; omega) (by have heq : (2 * (j : ℤ)) = ((2 * j : ℕ) : ℤ) := by { try push_cast; try ring }; rw [heq]; exact idx_V (2 * j) (by omega))
              have h2j_eq : (2 * (j : ℤ)) = ((2 * j : ℕ) : ℤ) := by try push_cast; try ring
              have h2j1_eq : (2 * (j : ℤ) + 1) = ((2 * j + 1 : ℕ) : ℤ) := by try push_cast; try ring
              obtain ⟨ha_6, ex_6⟩ := exec_writeLocal_auto (var := 8) (idxE := (.readLocal 1 (.lit 12))) (idx := 2 * (flat_j : ℤ)) (valE := (.readLocal 6 (.readLocal 1 (.lit 13)))) (val := (outCert bFin).words.read (.heap 1 (2 * (j : ℤ)))) ha_5 hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩
                (by simp [rw_write_eq, evalVal_readLocal, evalVal_lit])
                (by simp [rw_write_eq, evalVal_readLocal, evalVal_lit]
                    rw [h2j_eq, hr6_j (2 * j) (by omega), ← h2j_eq])
                (by decide) (by positivity) (by omega)
                (by rw [h2j_eq]; exact hV_out (2 * j) (by omega))
              obtain ⟨ha_7, ex_7⟩ := exec_writeLocal_auto (var := 8) (idxE := (.add (.readLocal 1 (.lit 12)) (.lit 1))) (idx := 2 * (flat_j : ℤ) + 1) (valE := (.readLocal 6 (.add (.readLocal 1 (.lit 13)) (.lit 1)))) (val := (outCert bFin).words.read (.heap 1 (2 * (j : ℤ) + 1))) ha_6 hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩
                (by simp [rw_write_eq, evalVal_add, evalVal_readLocal, evalVal_lit])
                (by simp [rw_write_eq, evalVal_add, evalVal_readLocal, evalVal_lit]
                    rw [h2j1_eq, hr6_j (2 * j + 1) (by omega), ← h2j1_eq])
                (by decide) (by positivity) (by omega)
                (by rw [h2j1_eq]; exact hV_out (2 * j + 1) (by omega))
              obtain ⟨ha_8, ex_8⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 9)) (idx := 9) (valE := (.add (.readLocal 1 (.lit 9)) (.lit 1))) (val := ((j + 1 : ℕ) : ℤ)) ha_7 hinp
                (exprInArena_small (by decide) (by decide) hV16)
                (exprInArena_small (by decide) (by decide) hV16)
                ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
                (by simp [rw_write_eq, evalVal_add, evalVal_readLocal, evalVal_lit, hr9_j]
                    try push_cast; try ring)
                (by decide) (by omega) (by simp; omega) (idx_V (j + 1) (by omega))
              let ws_cnext := ((((((((ws_j.write (.localFrame 1 1 10) (pos_bj : ℤ)).write
                (.localFrame 1 1 11) (flat_j : ℤ)).write
                (.localFrame 1 7 (flat_j : ℤ)) (hdl_j : ℤ)).write
                (.localFrame 1 1 12) (2 * (flat_j : ℤ))).write
                (.localFrame 1 1 13) (2 * (j : ℤ))).write
                (.localFrame 1 8 (2 * (flat_j : ℤ))) ((outCert bFin).words.read (.heap 1 (2 * (j : ℤ))))).write
                (.localFrame 1 8 (2 * (flat_j : ℤ) + 1)) ((outCert bFin).words.read (.heap 1 (2 * (j : ℤ) + 1)))).write
                (.localFrame 1 1 9) (((j + 1 : ℕ) : ℤ)))
              have hloc_other : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 → v ≠ 7 → v ≠ 8 →
                  ws_cnext.read (.localFrame 1 v idx) = ws_j.read (.localFrame 1 v idx) := by
                intro v idx hne1 hne7 hne8
                dsimp [ws_cnext]
                rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne8 hv),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne8 hv),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne7 hv),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv)]
              have ex_cstep :=
                ExecBounded.seq ex_1 (ExecBounded.seq ex_2 (ExecBounded.seq ex_3
                (ExecBounded.seq ex_4 (ExecBounded.seq ex_5 (ExecBounded.seq ex_6
                (ExecBounded.seq ex_7 ex_8))))))
              refine ⟨ws_cnext, bs, ⟨rfl, ha_8,
                hasPhase2Regs_of_eq hregs_j (fun idx => hloc_other 0 idx (by decide) (by decide) (by decide)),
                hasLiftArrays_of_eq hlifts_j (fun v idx hv =>
                  hloc_other v idx (by rcases hv with rfl | rfl <;> decide)
                    (by rcases hv with rfl | rfl <;> decide) (by rcases hv with rfl | rfl <;> decide)),
                hasZArray_of_eq hz_j (fun idx => hloc_other 4 idx (by decide) (by decide) (by decide)),
                hasFYArray_of_eq hfy_j (fun idx => hloc_other 5 idx (by decide) (by decide) (by decide)),
                by dsimp [ws_cnext]; simp [rw_write_eq, hr8_j],
                wordStore_read_write_self _ _ _,
                by dsimp [ws_cnext]; simp [rw_write_eq, hr14_j],
                fun j' hj' => (hloc_other 6 _ (by decide) (by decide) (by decide)).trans (hr6_j j' hj'),
                fun t idx => by
                  dsimp [ws_cnext]; simp [rw_write_eq, rf_free_eq]
                  exact hheap_j t idx,
                fun idx hlt => by
                  have hne_f : idx ≠ (flat_j : ℤ) := by dsimp [flat_j]; omega
                  dsimp [ws_cnext]
                  rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi; exact hne_f hi),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega))]
                  exact hr7_prev idx hlt,
                fun idx hlt => by
                  have hne0 : idx ≠ 2 * (flat_j : ℤ) := by dsimp [flat_j]; omega
                  have hne1 : idx ≠ 2 * (flat_j : ℤ) + 1 := by dsimp [flat_j]; omega
                  dsimp [ws_cnext]
                  rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi; exact hne1 hi),
                    wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi; exact hne0 hi),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                    wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega))]
                  exact hr8_prev idx hlt,
                fun j' hj' hjs => by
                  dsimp only
                  rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hj') with hlt | hjeq
                  · have hne_f : ((k_cur * p.s₀ + j' : ℕ) : ℤ) ≠ (flat_j : ℤ) := by dsimp [flat_j]; omega
                    have hne0 : 2 * ((k_cur * p.s₀ + j' : ℕ) : ℤ) ≠ 2 * (flat_j : ℤ) := by dsimp [flat_j]; omega
                    have hne1 : 2 * ((k_cur * p.s₀ + j' : ℕ) : ℤ) ≠ 2 * (flat_j : ℤ) + 1 := by dsimp [flat_j]; omega
                    have hne2 : 2 * ((k_cur * p.s₀ + j' : ℕ) : ℤ) + 1 ≠ 2 * (flat_j : ℤ) := by dsimp [flat_j]; omega
                    have hne3 : 2 * ((k_cur * p.s₀ + j' : ℕ) : ℤ) + 1 ≠ 2 * (flat_j : ℤ) + 1 := by dsimp [flat_j]; omega
                    dsimp [ws_cnext]
                    refine ⟨?_, ?_, ?_⟩
                    · rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                        wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                        wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                        wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                        wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                        wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi; exact hne_f hi),
                        wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                        wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega))]
                      exact (hr_cur j' hlt hjs).1
                    · rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                        wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi; exact hne1 hi),
                        wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi; exact hne0 hi)]
                      rw [rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide)]
                      exact (hr_cur j' hlt hjs).2.1
                    · rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                        wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi; exact hne3 hi),
                        wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi; exact hne2 hi)]
                      rw [rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide)]
                      exact (hr_cur j' hlt hjs).2.2
                  · subst j'
                    dsimp [ws_cnext, flat_j, hdl_j]
                    exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                                wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                                wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                                wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                                wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                                wordStore_read_write_self],
                           by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                                wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
                                wordStore_read_write_self],
                           by rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)),
                                wordStore_read_write_self]⟩⟩,
                ExecBounded.mono ex_cstep (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩)
          rcases hinv_cp with ⟨hbs_cp, ha_cp, hregs_cp, hlifts_cp, hz_cp, hfy_cp,
            hr8_cp, _, hr14_cp, _, hheap_cp, hr7_cp, hr8_cp_arr, hr_new_cp⟩
          rw [hbs_cp] at ex_cp
          obtain ⟨ha_inc_k, ex_inc_k⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 14)) (idx := 14) (valE := (.add (.readLocal 1 (.lit 14)) (.lit 1))) (val := ((k_cur + 1 : ℕ) : ℤ)) (bs := bs) ha_cp hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
            (by simp only [evalVal_add, evalVal_readLocal, evalVal_lit, hr14_cp]
                try push_cast; try ring)
            (by decide) (by omega) (by simp; omega)
            (idx_V (k_cur + 1) (by have := hrs_le_m; have : b + 1 ≤ p.r := hb; have : p.r ≤ p.r * p.s₀ := Nat.le_mul_of_pos_right _ hs0_pos; omega))
          let wsT := wsCp.write (.localFrame 1 1 14) (((k_cur + 1 : ℕ) : ℤ))
          have hlen_succ : (passedPre (b + 1)).length = k_cur + 1 := by
            rw [hpre_succ, List.length_append, List.length_singleton]
          have hb_true :
              66000 * (V + 8) ^ 2 + ((66000 * (V + 8) ^ 2 + p.s₀ * (560000 * (V + 8) ^ 2)) +
              66000 * (V + 8) ^ 2) ≤ (300000 + 600000 * p.s₀) * (V + 8) ^ 2 := by
            set Y := (V + 8) ^ 2
            have h1 : p.s₀ * (560000 * Y) ≤ p.s₀ * (600000 * Y) :=
              Nat.mul_le_mul_left p.s₀ (Nat.mul_le_mul_right Y (by omega))
            have h2 : (300000 + 600000 * p.s₀) * Y = 300000 * Y + p.s₀ * (600000 * Y) := by ring
            omega
          refine ⟨wsT, ha_inc_k,
            hasPhase2Regs_of_eq hregs_cp (fun _ => by simp [wsT, rw_write_eq]),
            hasLiftArrays_of_eq hlifts_cp (fun v _ hv =>
              by rcases hv with rfl | rfl <;> simp [wsT, rw_write_eq]),
            hasZArray_of_eq hz_cp (fun _ => by simp [wsT, rw_write_eq]),
            hasFYArray_of_eq hfy_cp (fun _ => by simp [wsT, rw_write_eq]),
            by dsimp [wsT]; rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr8_cp],
            by dsimp [wsT]; rw [wordStore_read_write_self, hlen_succ]; omega,
            fun t idx => by dsimp [wsT]; rw [wordStore_read_write_of_ne _ (by intro h; simp at h)]; exact hheap_cp t idx,
            fun i hi j => by
              dsimp only
              simp [wsT, rw_write_eq]
              rw [hlen_succ] at hi
              rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hi) with hlt | rfl
              · have hget_lt : (passedPre (b + 1))[i] = (passedPre b)[i] := by
                  simp only [hpre_succ]
                  exact List.getElem_append_left hlt
                have hi_lt_ks : i * p.s₀ + j.1 < k_cur * p.s₀ := by
                  have h1 : (i + 1) * p.s₀ ≤ k_cur * p.s₀ := Nat.mul_le_mul_right p.s₀ hlt
                  rw [Nat.add_mul, Nat.one_mul] at h1; have := j.2; omega
                rw [hget_lt, hr7_cp _ (by exact_mod_cast hi_lt_ks),
                  hr8_cp_arr _ (by omega), hr8_cp_arr _ (by omega)]
                exact hpass_b i hlt j
              · have hget_eq : (passedPre (b + 1))[k_cur] = bFin := by
                  simp only [hpre_succ]
                  rw [List.getElem_append_right (le_rfl)]
                  simp [k_cur]
                rw [hget_eq]
                exact hr_new_cp j.1 j.2 j.2,
            ExecBounded.mono (ExecBounded.seq ex_c0 (ExecBounded.seq ex_cp ex_inc_k))
              (by omega) hb_true le_rfl le_rfl⟩
        · have hfalse : passBool bFin = false := Bool.eq_false_iff.mpr hpass
          rw [hfalse, if_neg Bool.false_ne_true]
          have hpre_succ : passedPre (b + 1) = passedPre b := by
            dsimp [passedPre]; rw [htake_succ, List.filter_append, List.filter_cons_of_neg hpass, List.filter_nil, List.append_nil]
          have hsz_ext := inAttemptArena_size_le ha_ext
          refine ⟨wsExt, ha_ext, hregs_ext, hlifts_ext, hz_ext, hfy_ext, hr8_ext,
            by rw [hpre_succ, hr14_ext],
            hheap_ext,
            fun i hi j => by
              dsimp only
              have hi' : i < (passedPre b).length := hpre_succ ▸ hi
              have hget : (passedPre (b + 1))[i] = (passedPre b)[i] := by simp [hpre_succ]
              rw [hget, hr7_ext, hr8arr_ext, hr8arr_ext]
              exact hpass_b i hi' j,
            ExecBounded.mono
              (ExecBounded.skip inp wsExt bs (arenaCellCap inp A) (arenaBitCap inp A V))
              (by omega) (Nat.succ_le_of_lt (by positivity)) le_rfl le_rfl⟩
      obtain ⟨wsAfterIte, ha_ite, hregs_ite, hlifts_ite, hz_ite, hfy_ite,
        hr8_ite, hr14_ite, hheap_ite, hpass_ite, ex_ite_branch⟩ := hite_res
      have hc_cond : CondInArena V (.intEq (.readLocal 1 (.lit 15)) (.lit 1)) :=
        ⟨exprInArena_small (by decide) (by decide) hV16, exprInArena_small (by decide) (by decide) hV16⟩
      have ex_ite := exec_ite_auto (cond := (.intEq (.readLocal 1 (.lit 15)) (.lit 1))) (tB := (.seq (.writeLocal 1 (.lit 9) (.lit 0)) (.seq (.repeatN (.readLocal 0 (.lit 5)) phase5CopyPassBody) (.writeLocal 1 (.lit 14) (.add (.readLocal 1 (.lit 14)) (.lit 1)))))) (fB := .skip) ha_ext hinp hc_cond (by decide) hcond_eval ex_ite_branch
      -- 2e. Increment `b`: `(1, 8) := b + 1`
      obtain ⟨ha_inc_b, ex_inc_b⟩ := exec_writeLocal_auto (var := 1) (idxE := (.lit 8)) (idx := 8) (valE := (.add (.readLocal 1 (.lit 8)) (.lit 1))) (val := ((b + 1 : ℕ) : ℤ)) (bs := bs) ha_ite hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
        (by simp only [evalVal_add, evalVal_readLocal, evalVal_lit, hr8_ite]
            try push_cast; try ring)
        (by decide) (by omega) (by simp; omega)
        (idx_V (b + 1) (by have := hrs_le_m; have : p.r ≤ p.r * p.s₀ := Nat.le_mul_of_pos_right _ hs0_pos; omega))
      let wsNext_b := wsAfterIte.write (.localFrame 1 1 8) (((b + 1 : ℕ) : ℤ))
      have ex_j0' := ExecBounded.mono ex_j0 le_rfl le_rfl hCS.1 hCS.2
      have ex_sj' := ExecBounded.mono ex_sj le_rfl le_rfl hCS.1 hCS.2
      have ex_ite' := ExecBounded.mono ex_ite le_rfl le_rfl hCS.1 hCS.2
      have ex_inc_b' := ExecBounded.mono ex_inc_b le_rfl le_rfl hCS.1 hCS.2
      have hex_tail : (2 * p.s₀ + 4) * (32 * (natBitLength A + natBitLength T_c + V + 16) ^ 2) ≤
          (256 * p.s₀ + 512) * Z ^ 2 := by
        have h1 : natBitLength A + natBitLength T_c + V + 16 ≤ 2 * Z := by dsimp [Z]; omega
        calc (2 * p.s₀ + 4) * (32 * (natBitLength A + natBitLength T_c + V + 16) ^ 2)
            ≤ (2 * p.s₀ + 4) * (32 * (2 * Z) ^ 2) :=
              Nat.mul_le_mul_left _ (Nat.mul_le_mul_left 32 (Nat.pow_le_pow_left h1 2))
          _ = (256 * p.s₀ + 512) * Z ^ 2 := by ring
      have ex_sub' : ExecBounded inp (runSubAndExtractStmt false progCert 1 15 6 (some (0, 15)) 9)
          wsStaged_b bs wsExt bs
          (80 * F_c * (U_cert + 1) + 32 * p.s₀ + 64)
          (256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * U_cert + 16) * U_cert +
            (U_cert + 2) * (8 * natBitLength (U_cert + 2) + 4 * (U_cert + 2 * natBitLength T_c + 6) + 80) +
            (256 * p.s₀ + 512) * Z ^ 2)
          C_c S_c := by
        refine ExecBounded.mono ex_sub (by dsimp [F_c]; omega) ?_
          (by dsimp [C_c, arenaCellCap]; omega) (le_of_eq (by dsimp [S_c, arenaBitCap, T_c]; ring))
        dsimp [F_c, T_c] at hex_tail ⊢
        rw [show U_cert + U_cert + 16 = 2 * U_cert + 16 by omega]
        omega
      have ex_bstep :=
        ExecBounded.seq ex_j0' (ExecBounded.seq ex_sj' (ExecBounded.seq ex_sub'
        (ExecBounded.seq ex_ite' ex_inc_b')))
      have hu_bstep :
          68 + ((68 + p.s₀ * (800 + 300 * p.d)) +
            ((80 * F_c * (U_cert + 1) + 32 * p.s₀ + 64) +
              ((68 + (300 + 600 * p.s₀)) + 68))) ≤ stepU := by
        dsimp [stepU]
        have hs_m : p.s₀ * (800 + 300 * p.d) + 32 * p.s₀ + 600 * p.s₀ ≤ p.s₀ * (1500 + 300 * p.d) := by
          have : p.s₀ * (800 + 300 * p.d) + 32 * p.s₀ + 600 * p.s₀ = p.s₀ * (1432 + 300 * p.d) := by ring
          rw [this]
          exact Nat.mul_le_mul_left p.s₀ (by omega)
        omega
      have hb_bstep :
          66000 * (V + 8) ^ 2 + ((66000 * (V + 8) ^ 2 + p.s₀ * ((800000 + 300000 * p.d) * (V + 8) ^ 2)) +
            ((256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * U_cert + 16) * U_cert +
              (U_cert + 2) * (8 * natBitLength (U_cert + 2) + 4 * (U_cert + 2 * natBitLength T_c + 6) + 80) +
              (256 * p.s₀ + 512) * Z ^ 2) +
              ((66000 * (V + 8) ^ 2 + (300000 + 600000 * p.s₀) * (V + 8) ^ 2) + 66000 * (V + 8) ^ 2))) ≤ stepB := by
        have hy1 := Nat.mul_le_mul_left 66000 hYZ
        have hy2 := Nat.mul_le_mul_left (p.s₀ * (800000 + 300000 * p.d)) hYZ
        have hy3 := Nat.mul_le_mul_left (300000 + 600000 * p.s₀) hYZ
        have hrew2 : p.s₀ * ((800000 + 300000 * p.d) * (V + 8) ^ 2) =
            (p.s₀ * (800000 + 300000 * p.d)) * (V + 8) ^ 2 := by ring
        rw [hrew2]
        have hsumZ :
            4 * (66000 * Z ^ 2) + (p.s₀ * (800000 + 300000 * p.d)) * Z ^ 2 +
              (256 * p.s₀ + 512) * Z ^ 2 + (300000 + 600000 * p.s₀) * Z ^ 2 ≤
            (2000000 + p.s₀ * (1500000 + 300000 * p.d)) * Z ^ 2 := by
          have hf :
              4 * (66000 * Z ^ 2) + (p.s₀ * (800000 + 300000 * p.d)) * Z ^ 2 +
                (256 * p.s₀ + 512) * Z ^ 2 + (300000 + 600000 * p.s₀) * Z ^ 2 =
              (564512 + p.s₀ * (1400256 + 300000 * p.d)) * Z ^ 2 := by ring
          rw [hf]
          refine Nat.mul_le_mul_right (Z ^ 2) ?_
          have hsm : p.s₀ * (1400256 + 300000 * p.d) ≤ p.s₀ * (1500000 + 300000 * p.d) :=
            Nat.mul_le_mul_left p.s₀ (by omega)
          omega
        change _ ≤ (2000000 + p.s₀ * (1500000 + 300000 * p.d)) * Z ^ 2 +
          256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * U_cert + 16) * U_cert +
          (U_cert + 2) * (8 * natBitLength (U_cert + 2) + 4 * (U_cert + 2 * natBitLength T_c + 6) + 80)
        omega
      refine ⟨wsNext_b, bs, ⟨rfl, ha_inc_b,
        hasPhase2Regs_of_eq hregs_ite (fun _ => by simp [wsNext_b, rw_write_eq]),
        hasLiftArrays_of_eq hlifts_ite (fun v _ hv =>
          by rcases hv with rfl | rfl <;> simp [wsNext_b, rw_write_eq]),
        hasZArray_of_eq hz_ite (fun _ => by simp [wsNext_b, rw_write_eq]),
        hasFYArray_of_eq hfy_ite (fun _ => by simp [wsNext_b, rw_write_eq]),
        wordStore_read_write_self _ _ _,
        by dsimp [wsNext_b]; rw [wordStore_read_write_of_ne _ (by intro h; first | nomatch h | (injection h; intros; omega)), hr14_ite],
        fun t idx ht5 ht6 ht7 => by
          dsimp [wsNext_b]; rw [wordStore_read_write_of_ne _ (by intro h; simp at h), hheap_ite]
          exact hht_sb t idx ht5 ht6 ht7,
        fun idx => by
          dsimp [wsNext_b]; rw [wordStore_read_write_of_ne _ (by intro h; simp at h), hheap_ite]
          exact hh5_sb idx,
        fun c => ⟨by dsimp [wsNext_b]; rw [wordStore_read_write_of_ne _ (by intro h; simp at h), hheap_ite]; exact (hzc_sb c).1,
                  by dsimp [wsNext_b]; rw [wordStore_read_write_of_ne _ (by intro h; simp at h), hheap_ite]; exact (hzc_sb c).2⟩,
        fun idx hr => ⟨by dsimp [wsNext_b]; rw [wordStore_read_write_of_ne _ (by intro h; simp at h), hheap_ite]; exact (hzz_sb idx hr).1,
                       by dsimp [wsNext_b]; rw [wordStore_read_write_of_ne _ (by intro h; simp at h), hheap_ite]; exact (hzz_sb idx hr).2⟩,
        fun i hi j => by
          dsimp only
          simp [wsNext_b, rw_write_eq]
          exact hpass_ite i hi j⟩,
        ExecBounded.mono ex_bstep hu_bstep hb_bstep le_rfl le_rfl⟩)
  rcases hinv_r with ⟨hbs_r, ha_r, hregs_r, _, hz_r, _, _, hr14_r, hht_r, hh5_r, _, hzz_r, hpass_r⟩
  rw [hbs_r] at ex_rloop
  have hpre_full : passedPre p.r = L_pass := by
    dsimp [passedPre, L_pass]
    rw [List.take_of_length_le (by simp)]
  -- 3. Unstage
  have hh5_zero_r : ∀ idx : ℤ, idx ≠ 0 → idx ≠ 1 → wsPostLoop.read (.heap 5 idx) = 0 := by
    intro idx h0 h1
    rw [hh5_r idx]
    unfold listGetIntD
    by_cases hn : idx < 0
    · rw [if_neg (not_le_of_gt hn)]
    · rw [if_pos (not_lt.mp hn)]
      have hnone : ([(p.D : ℤ), (p.s₀ : ℤ)][idx.toNat]?) = none :=
        List.getElem?_eq_none (by simp; omega)
      simp [List.getD, hnone]
  obtain ⟨ws₆, ha_6, hhz_6, hregs_6, hloc_6, hr14_6, ex_un⟩ :=
    exec_phase5UnstageStmt (bs := bs) p ha_r hregs_r hinp hfit hsDA hht_r hh5_zero_r hzz_r
  have ex_pre' := ExecBounded.mono ex_pre le_rfl le_rfl hCS.1 hCS.2
  have ex_un' := ExecBounded.mono ex_un le_rfl le_rfl hCS.1 hCS.2
  have ex_all := ExecBounded.seq ex_pre' (ExecBounded.seq ex_rloop ex_un')
  have hu_all :
      (500 + 400 * p.D) + ((68 + p.r * stepU) + (500 + 250 * (p.D + p.s₀ * p.D))) ≤
      2000 + 800 * (p.D + p.s₀ * p.D) + p.r * stepU := by omega
  have hb_all :
      (500000 + 400000 * p.D) * (V + 8) ^ 2 +
        ((66000 * (V + 8) ^ 2 + p.r * stepB) +
          (500000 + 250000 * (p.D + p.s₀ * p.D)) * (V + 8) ^ 2) ≤
      (2000000 + 800000 * (p.D + p.s₀ * p.D)) * Z ^ 2 + p.r * stepB := by
    have hy1 := Nat.mul_le_mul_left (500000 + 400000 * p.D) hYZ
    have hy2 := Nat.mul_le_mul_left 66000 hYZ
    have hy3 := Nat.mul_le_mul_left (500000 + 250000 * (p.D + p.s₀ * p.D)) hYZ
    have hsumZ :
        (500000 + 400000 * p.D) * Z ^ 2 + 66000 * Z ^ 2 +
          (500000 + 250000 * (p.D + p.s₀ * p.D)) * Z ^ 2 ≤
        (2000000 + 800000 * (p.D + p.s₀ * p.D)) * Z ^ 2 := by
      have hf :
          (500000 + 400000 * p.D) * Z ^ 2 + 66000 * Z ^ 2 +
            (500000 + 250000 * (p.D + p.s₀ * p.D)) * Z ^ 2 =
          (1066000 + 650000 * p.D + 250000 * (p.s₀ * p.D)) * Z ^ 2 := by ring
      have hg :
          (2000000 + 800000 * (p.D + p.s₀ * p.D)) * Z ^ 2 =
          (2000000 + 800000 * p.D + 800000 * (p.s₀ * p.D)) * Z ^ 2 := by ring
      rw [hf, hg]
      exact Nat.mul_le_mul_right (Z ^ 2) (by omega)
    omega
  refine ⟨ws₆, ha_6, hhz_6, hregs_6,
    hasZArray_of_eq hz_r (fun idx => hloc_6 4 idx (by decide)),
    by rw [hr14_6, hr14_r, hpre_full],
    fun i hi j => by
      dsimp only
      rw [hloc_6 7 _ (by decide), hloc_6 8 _ (by decide), hloc_6 8 _ (by decide)]
      have hi' : i < (passedPre p.r).length := hpre_full.symm ▸ hi
      have hget : (passedPre p.r)[i] = L_pass[i] := by simp [hpre_full]
      simpa [hget] using hpass_r i hi' j,
    ExecBounded.mono ex_all hu_all hb_all le_rfl le_rfl⟩

end UL.Proof_lem_A_2
