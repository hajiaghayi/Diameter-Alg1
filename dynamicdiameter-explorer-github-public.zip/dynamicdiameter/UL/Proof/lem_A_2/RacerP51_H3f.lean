import Mathlib
import UL.Proof.lem_A_2.RacerP51_H3e
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 1000000

namespace UL.Proof_lem_A_2

/-! ### Phase 4: Forward Fisher–Yates Shuffle in `var 5 [0 .. m - 1]` -/

def fyPref {m : ℕ} (u : (i : Fin m) → Fin (m - i.1)) :
    (k : ℕ) → k ≤ m → Equiv.Perm (Fin m)
  | 0, _ => Equiv.refl (Fin m)
  | k + 1, hk =>
      let ik : Fin m := ⟨k, hk⟩
      let jk : Fin m := ⟨k + (u ik).1, by have h : (u ik).1 < m - k := (u ik).2; omega⟩
      (Equiv.swap ik jk).trans (fyPref u k (le_of_lt hk))

private theorem fyTail_congr_rem {m r₁ r₂ : ℕ} (hr : r₁ = r₂) (h₁ : r₁ ≤ m) (h₂ : r₂ ≤ m)
    (π : Equiv.Perm (Fin m)) (u : (i : Fin m) → Fin (m - i.1)) :
    fyTail r₁ h₁ π u = fyTail r₂ h₂ π u := by
  subst hr; rfl

private theorem swap_u_congr {m : ℕ} (u : (i : Fin m) → Fin (m - i.1))
    {k₁ k₂ : ℕ} (hk : k₁ = k₂) (h₁ : k₁ < m) (h₂ : k₂ < m) :
    Equiv.swap (⟨k₁, h₁⟩ : Fin m) ⟨k₁ + (u ⟨k₁, h₁⟩).1, by have h : (u ⟨k₁, h₁⟩).1 < m - k₁ := (u ⟨k₁, h₁⟩).2; omega⟩ =
    Equiv.swap (⟨k₂, h₂⟩ : Fin m) ⟨k₂ + (u ⟨k₂, h₂⟩).1, by have h : (u ⟨k₂, h₂⟩).1 < m - k₂ := (u ⟨k₂, h₂⟩).2; omega⟩ := by
  subst hk; rfl

theorem fyTail_fyPref {m : ℕ} (u : (i : Fin m) → Fin (m - i.1)) :
    ∀ (k : ℕ) (hk : k ≤ m),
      fyTail (m - k) (Nat.sub_le m k) (fyPref u k hk) u = fyPerm u := by
  intro k
  induction k with
  | zero => intro _; rfl
  | succ k ih =>
      intro hk1
      have hk : k ≤ m := le_of_lt hk1
      rw [← ih hk]
      have hsub : m - k = (m - (k + 1)) + 1 := by omega
      rw [fyTail_congr_rem hsub (Nat.sub_le m k) (by omega)]
      simp only [fyTail, fyPref]
      have hk_eq : m - ((m - (k + 1)) + 1) = k := by omega
      rw [swap_u_congr u hk_eq]

theorem fyPref_full_eq_fyPerm {m : ℕ} (u : (i : Fin m) → Fin (m - i.1)) :
    fyPref u m le_rfl = fyPerm u := by
  have h := fyTail_fyPref u m le_rfl
  rw [fyTail_congr_rem (Nat.sub_self m) _ (Nat.zero_le m)] at h
  exact h

theorem fyPref_succ_apply {m : ℕ} (u : (i : Fin m) → Fin (m - i.1))
    {k : ℕ} (hk : k < m) (x : Fin m) :
    let π := fyPref u k (le_of_lt hk)
    let ik : Fin m := ⟨k, hk⟩
    let jk : Fin m := ⟨k + (u ik).1, by have h : (u ik).1 < m - k := (u ik).2; omega⟩
    fyPref u (k + 1) hk x =
      if x = ik then π jk else if x = jk then π ik else π x := by
  intro π ik jk
  change π (Equiv.swap ik jk x) = _
  by_cases hx1 : x = ik
  · subst hx1; simp
  · rw [if_neg hx1]
    by_cases hx2 : x = jk
    · subst hx2; simp
    · rw [if_neg hx2, Equiv.swap_apply_of_ne_of_ne hx1 hx2]

def HasPermArray (m : ℕ) (π : Equiv.Perm (Fin m)) (ws : WordStore) : Prop :=
  ∀ i : Fin m, ws.read (.localFrame 1 5 (i.1 : ℤ)) = ((π i).1 : ℤ)

theorem hasPermArray_of_eq {m : ℕ} {π : Equiv.Perm (Fin m)} {ws ws' : WordStore}
    (h : HasPermArray m π ws)
    (heq : ∀ idx : ℤ, ws'.read (.localFrame 1 5 idx) = ws.read (.localFrame 1 5 idx)) :
    HasPermArray m π ws' :=
  fun i => (heq (i.1 : ℤ)).trans (h i)

def phase4InitBody : BitRAMStmt :=
  .seq (.writeLocal 5 (.readLocal 1 (.lit 9)) (.readLocal 1 (.lit 9)))
       (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1)))

def phase4SwapBody : BitRAMStmt :=
  .seq (drawBitsStmt 13 3 4)
  (.seq (.writeLocal 1 (.lit 10) (.sub (.readLocal 0 (.lit 2)) (.readLocal 1 (.lit 9))))
  (.seq (.writeLocal 1 (.lit 11)
          (.add (.readLocal 1 (.lit 9)) (.mod (.readLocal 1 (.lit 3)) (.readLocal 1 (.lit 10)))))
  (.seq (.writeLocal 1 (.lit 12) (.readLocal 5 (.readLocal 1 (.lit 9))))
  (.seq (.writeLocal 1 (.lit 13) (.readLocal 5 (.readLocal 1 (.lit 11))))
  (.seq (.writeLocal 5 (.readLocal 1 (.lit 9)) (.readLocal 1 (.lit 13)))
  (.seq (.writeLocal 5 (.readLocal 1 (.lit 11)) (.readLocal 1 (.lit 12)))
        (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1)))))))))

def phase4Stmt : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 9) (.lit 0))
  (.seq (.repeatN (.readLocal 0 (.lit 2)) phase4InitBody)
  (.seq (.writeLocal 1 (.lit 9) (.lit 0))
        (.repeatN (.readLocal 0 (.lit 2)) phase4SwapBody)))

theorem exec_phase4Stmt {A V M : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ) (zRat : Fin p.D → ℚ)
    (f_fy : Fin p.m → Fin p.W₂ → Bool) (restBits : List Bool)
    {inp : BitRAMInput p.d} {ws₄ : WordStore}
    (harena : InAttemptArena A V ws₄)
    (hhz : HeapAllZero ws₄)
    (hregs : HasPhase2Regs p M ws₄)
    (hlifts : HasLiftArrays p pts_h ws₄)
    (hz : HasZArray p.D zRat ws₄)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p) :
    let u : (i : Fin p.m) → Fin (p.m - i.1) := fun i =>
      ⟨bitsToNat p.W₂ (f_fy i) % (p.m - i.1), Nat.mod_lt _ (by have := i.2; omega)⟩
    ∃ ws₅ : WordStore,
      InAttemptArena A V ws₅ ∧
      HeapAllZero ws₅ ∧
      HasPhase2Regs p M ws₅ ∧
      HasLiftArrays p pts_h ws₅ ∧
      HasZArray p.D zRat ws₅ ∧
      HasPermArray p.m (fyPerm u) ws₅ ∧
      ExecBounded inp phase4Stmt
        ws₄ (blockBitStream f_fy restBits 0) ws₅ restBits
        (600 + p.m * (900 + 24 * (p.W₂ + 1)))
        ((400000 + 700000 * p.m) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  intro u
  rcases hfit with ⟨hK1, _, _, hm2s, h16A, hmA, hVA, _, hwV, _, _, _, _, _⟩
  have hV16 : 16 ≤ V := by omega
  have idx_V : ∀ k : ℕ, k ≤ A → intBitLength (k : ℤ) ≤ V := by
    intro k hk
    have h1 := intBitLength_natCast_le_succ k
    have h2 := natBitLength_mono hk
    omega
  -- Part 1: Initialize `var 5 [0 .. m - 1]` to `0 .. m - 1`
  let bs₀ := blockBitStream f_fy restBits 0
  obtain ⟨ha_i0, ex_i0⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .lit 0)
    harena hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _)
    (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
  let InitInv (k : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
    bs_c = bs₀ ∧
    InAttemptArena A V ws ∧
    HeapAllZero ws ∧
    HasPhase2Regs p M ws ∧
    HasLiftArrays p pts_h ws ∧
    HasZArray p.D zRat ws ∧
    ws.read (.localFrame 1 1 9) = (k : ℤ) ∧
    (∀ i : ℕ, i < k → ws.read (.localFrame 1 5 (i : ℤ)) = (i : ℤ))
  have hinit1 : InitInv 0 (wsOf ha_i0) bs₀ := by
    refine ⟨rfl, ha_i0, heapAllZero_write_local hhz 1 1 9 0,
      hasPhase2Regs_of_eq hregs (fun _ => rw_local_var_ne _ (by decide)),
      hasLiftArrays_of_eq hlifts (fun v _ hv => rw_local_var_ne _ (by rcases hv with rfl | rfl <;> decide)),
      hasZArray_of_eq hz (fun _ => rw_local_var_ne _ (by decide)),
      wordStore_read_write_self _ _ _,
      fun _ hi => by omega⟩
  have hcnt1 : evalVal inp (wsOf ha_i0) (.readLocal 0 (.lit 2)) = (p.m : ℤ) := by
    simp only [evalVal_readLocal, evalVal_lit, rw_local_var_ne _ (by decide : 0 ≠ 1)]
    exact hregs.1.2.2.1
  obtain ⟨ws_init, bs_init, hinv_init, ex_init_loop⟩ :=
    exec_repeatN_inv (countE := .readLocal 0 (.lit 2)) (body := phase4InitBody) p.m InitInv
      ha_i0 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
      hcnt1 hinit1
      (U := 200) (B := 200000 * (V + 8) ^ 2)
      (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
      (fun k ws_k bs_k hk ⟨hbs_k, ha_k, hhz_k, hregs_k, hlifts_k, hz_k, hr9_k, harr_k⟩ => by
        subst bs_k
        obtain ⟨ha_s1, ex_s1⟩ := exec_writeLocal_auto (var := 5)
          (idxE := .readLocal 1 (.lit 9)) (valE := .readLocal 1 (.lit 9))
          ha_k hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩
          (by simp only [evalVal_readLocal, evalVal_lit, hr9_k]; try rfl)
          (by simp only [evalVal_readLocal, evalVal_lit, hr9_k]; try rfl)
          (by decide) (by positivity) (by rw [Int.toNat_natCast]; omega) (idx_V k (by omega))
        obtain ⟨ha_s2, ex_s2⟩ := exec_writeLocal_auto (var := 1)
          (idxE := .lit 9) (valE := .add (.readLocal 1 (.lit 9)) (.lit 1))
          ha_s1 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp only [evalVal_add, evalVal_readLocal, evalVal_lit,
                rw_local_var_ne _ (by decide : 1 ≠ 5), hr9_k]
              try push_cast; try ring; try rfl)
          (by decide) (by omega) (by simp; omega) (idx_V (k + 1) (by omega))
        have hkeep : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 → v ≠ 5 →
            (wsOf ha_s2).read (.localFrame 1 v idx) = ws_k.read (.localFrame 1 v idx) := by
          intro v idx hv1 hv5
          exact (rw_local_var_ne _ hv1).trans (rw_local_var_ne _ hv5)
        refine ⟨wsOf ha_s2, bs₀, ⟨rfl, ha_s2,
          heapAllZero_write_local (heapAllZero_write_local hhz_k _ _ _ _) _ _ _ _,
          hasPhase2Regs_of_eq hregs_k (fun idx => hkeep 0 idx (by decide) (by decide)),
          hasLiftArrays_of_eq hlifts_k (fun v idx hv =>
            hkeep v idx (by rcases hv with rfl | rfl <;> decide) (by rcases hv with rfl | rfl <;> decide)),
          hasZArray_of_eq hz_k (fun idx => hkeep 4 idx (by decide) (by decide)),
          wordStore_read_write_self _ _ _,
          fun i hi => by
            rw [rw_local_var_ne _ (by decide : 5 ≠ 1)]
            rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hi) with hlt | rfl
            · rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ heq; omega)]
              exact harr_k i hlt
            · exact wordStore_read_write_self _ _ _⟩,
          ExecBounded.mono (ExecBounded.seq ex_s1 ex_s2) (by omega) (by omega) le_rfl le_rfl⟩)
  rcases hinv_init with ⟨hbs_in1, ha_in1, hhz_in1, hregs_in1, hlifts_in1, hz_in1, _, harr_in1⟩
  subst bs_init
  -- Part 2: Shuffle loop (`k = 0 .. m - 1`)
  obtain ⟨ha_i2, ex_i2⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .lit 0)
    ha_in1 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _)
    (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
  let SwapInv (k : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
    ∃ hk : k ≤ p.m,
      bs_c = blockBitStream f_fy restBits k ∧
      InAttemptArena A V ws ∧
      HeapAllZero ws ∧
      HasPhase2Regs p M ws ∧
      HasLiftArrays p pts_h ws ∧
      HasZArray p.D zRat ws ∧
      ws.read (.localFrame 1 1 9) = (k : ℤ) ∧
      HasPermArray p.m (fyPref u k hk) ws
  have hinit2 : SwapInv 0 (wsOf ha_i2) bs₀ := by
    refine ⟨Nat.zero_le p.m, rfl, ha_i2,
      heapAllZero_write_local hhz_in1 1 1 9 0,
      hasPhase2Regs_of_eq hregs_in1 (fun _ => rw_local_var_ne _ (by decide)),
      hasLiftArrays_of_eq hlifts_in1 (fun v _ hv => rw_local_var_ne _ (by rcases hv with rfl | rfl <;> decide)),
      hasZArray_of_eq hz_in1 (fun _ => rw_local_var_ne _ (by decide)),
      wordStore_read_write_self _ _ _,
      fun x => by
        rw [rw_local_var_ne _ (by decide : 5 ≠ 1)]
        simpa [fyPref] using harr_in1 x.1 x.2⟩
  have hcnt2 : evalVal inp (wsOf ha_i2) (.readLocal 0 (.lit 2)) = (p.m : ℤ) := by
    simp only [evalVal_readLocal, evalVal_lit, rw_local_var_ne _ (by decide : 0 ≠ 1)]
    exact hregs_in1.1.2.2.1
  obtain ⟨ws₅, bs₅, hinv_end, ex_swap_loop⟩ :=
    exec_repeatN_inv (countE := .readLocal 0 (.lit 2)) (body := phase4SwapBody) p.m SwapInv
      ha_i2 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
      hcnt2 hinit2
      (U := 600 + 24 * (p.W₂ + 1)) (B := 500000 * (V + 8) ^ 2)
      (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
      (fun k ws_k bs_k hk ⟨_, hbs_k, ha_k, hhz_k, hregs_k, hlifts_k, hz_k, hr9_k, hperm_k⟩ => by
        rw [blockBitStream_step f_fy restBits hk] at hbs_k
        subst bs_k
        set bsNext := blockBitStream f_fy restBits (k + 1)
        set π_k := fyPref u k (le_of_lt hk)
        let ik : Fin p.m := ⟨k, hk⟩
        let jk : Fin p.m := ⟨k + (u ik).1, by have h : (u ik).1 < p.m - k := (u ik).2; omega⟩
        -- 1. drawBitsStmt 13 3 4
        have hW2_fit : p.W₂ + 4 ≤ V := by dsimp [CoreParams.W₂]; omega
        obtain ⟨ws_d, ha_d, hr3_d, hoth_d, ex_d⟩ :=
          exec_drawBitsStmt (inp := inp) (f_fy ik) bsNext
            (wIdx := 13) (accIdx := 3) (bitIdx := 4)
            ha_k (by decide)
            ⟨by omega, by omega, by omega, by omega, by omega, by omega, h16A⟩
            hregs_k.1.2.2.2.2.2.2.2.2.2.2.2.1 hW2_fit
        have hr9_d : ws_d.read (.localFrame 1 1 9) = (k : ℤ) :=
          (hoth_d (.localFrame 1 1 9) (by decide) (by decide)).trans hr9_k
        have hr0_2_d : ws_d.read (.localFrame 1 0 2) = (p.m : ℤ) :=
          (hoth_d (.localFrame 1 0 2) (by decide) (by decide)).trans hregs_k.1.2.2.1
        have hperm_d : HasPermArray p.m π_k ws_d :=
          hasPermArray_of_eq hperm_k (fun idx => hoth_d _ (by intro hc; nomatch hc) (by intro hc; nomatch hc))
        -- 2. (1, 10) := m - k
        have hsub_mk : (p.m : ℤ) - (k : ℤ) = ((p.m - k : ℕ) : ℤ) := by omega
        obtain ⟨ha_10, ex_10⟩ := exec_writeLocal_auto (var := 1)
          (idxE := .lit 10) (valE := .sub (.readLocal 0 (.lit 2)) (.readLocal 1 (.lit 9)))
          ha_d hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp only [evalVal_sub, evalVal_readLocal, evalVal_lit, hr0_2_d, hr9_d, hsub_mk]; try rfl)
          (by decide) (by omega) (by simp; omega) (idx_V (p.m - k) (by omega))
        -- 3. (1, 11) := k + (acc % (m - k)) = jk.1
        have hjk_eq : (k : ℤ) + (bitsToNat p.W₂ (f_fy ik) : ℤ) % ((p.m - k : ℕ) : ℤ) = (jk.1 : ℤ) := by
          dsimp [jk, u]
          try rw [← Int.natCast_emod]; try rw [← Int.natCast_add]; try push_cast; try ring
        obtain ⟨ha_11, ex_11⟩ := exec_writeLocal_auto (var := 1)
          (idxE := .lit 11)
          (valE := .add (.readLocal 1 (.lit 9)) (.mod (.readLocal 1 (.lit 3)) (.readLocal 1 (.lit 10))))
          ha_10 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp [evalVal_add, evalVal_mod, evalVal_readLocal, evalVal_lit,
                rw_write_eq, RAMCellLoc.localFrame.injEq, 
                and_self, and_true, and_false, ite_true, ite_false,
                hr9_d, hr3_d, hjk_eq]; try rfl)
          (by decide) (by omega) (by simp; omega) (idx_V jk.1 (by have := jk.2; omega))
        -- 4. (1, 12) := var 5 [k] = (π_k ik).1
        obtain ⟨ha_12, ex_12⟩ := exec_writeLocal_auto (var := 1)
          (idxE := .lit 12) (valE := .readLocal 5 (.readLocal 1 (.lit 9)))
          ha_11 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp [evalVal_readLocal, evalVal_lit,
                rw_write_eq, RAMCellLoc.localFrame.injEq, 
                and_self, and_true, and_false, false_and, ite_false,
                hr9_d]
              exact hperm_d ik)
          (by decide) (by omega) (by simp; omega) (idx_V (π_k ik).1 (by have := (π_k ik).2; omega))
        -- 5. (1, 13) := var 5 [jk.1] = (π_k jk).1
        obtain ⟨ha_13, ex_13⟩ := exec_writeLocal_auto (var := 1)
          (idxE := .lit 13) (valE := .readLocal 5 (.readLocal 1 (.lit 11)))
          ha_12 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp [evalVal_readLocal, evalVal_lit,
                rw_write_eq, RAMCellLoc.localFrame.injEq, 
                and_self, and_true, and_false, false_and, ite_true, ite_false]
              exact hperm_d jk)
          (by decide) (by omega) (by simp; omega) (idx_V (π_k jk).1 (by have := (π_k jk).2; omega))
        -- 6. var 5 [k] := (π_k jk).1
        obtain ⟨ha_w1, ex_w1⟩ := exec_writeLocal_auto (var := 5)
          (idxE := .readLocal 1 (.lit 9)) (valE := .readLocal 1 (.lit 13))
          ha_13 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩
          (by simp [evalVal_readLocal, evalVal_lit,
                rw_write_eq, RAMCellLoc.localFrame.injEq, 
                and_self, and_true, and_false, ite_false, hr9_d]; try rfl)
          (by simp only [evalVal_readLocal, evalVal_lit, wordStore_read_write_self]; try rfl)
          (by decide) (by positivity) (by rw [Int.toNat_natCast]; omega)
          (idx_V (π_k jk).1 (by have := (π_k jk).2; omega))
        -- 7. var 5 [jk.1] := (π_k ik).1
        obtain ⟨ha_w2, ex_w2⟩ := exec_writeLocal_auto (var := 5)
          (idxE := .readLocal 1 (.lit 11)) (valE := .readLocal 1 (.lit 12))
          ha_w1 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩
          (by simp [evalVal_readLocal, evalVal_lit,
                rw_write_eq, RAMCellLoc.localFrame.injEq, 
                and_self, and_true, and_false, false_and, ite_true, ite_false]; try rfl)
          (by simp [evalVal_readLocal, evalVal_lit,
                rw_write_eq, RAMCellLoc.localFrame.injEq, 
                and_self, and_true, and_false, false_and, ite_true, ite_false]; try rfl)
          (by decide) (by positivity) (by rw [Int.toNat_natCast]; have := jk.2; omega)
          (idx_V (π_k ik).1 (by have := (π_k ik).2; omega))
        -- 8. (1, 9) := k + 1
        obtain ⟨ha_inc, ex_inc⟩ := exec_writeLocal_auto (var := 1)
          (idxE := .lit 9) (valE := .add (.readLocal 1 (.lit 9)) (.lit 1))
          ha_w2 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp [evalVal_add, evalVal_readLocal, evalVal_lit,
                rw_write_eq, RAMCellLoc.localFrame.injEq, 
                and_self, and_true, and_false, false_and, ite_false, hr9_d]
              try push_cast; try ring; try rfl)
          (by decide) (by omega) (by simp; omega) (idx_V (k + 1) (by omega))
        have hkeep : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 → v ≠ 5 →
            (wsOf ha_inc).read (.localFrame 1 v idx) = ws_k.read (.localFrame 1 v idx) := by
          intro v idx hv1 hv5
          rw [rw_local_var_ne _ hv1, rw_local_var_ne _ hv5, rw_local_var_ne _ hv5,
            rw_local_var_ne _ hv1, rw_local_var_ne _ hv1, rw_local_var_ne _ hv1, rw_local_var_ne _ hv1]
          exact hoth_d _ (by intro hc; injection hc with _ hv _; exact hv1 hv)
            (by intro hc; injection hc with _ hv _; exact hv1 hv)
        have hhz_next : HeapAllZero (wsOf ha_inc) := by
          refine heapAllZero_of_eq_heap hhz_k fun t idx => ?_
          simp only [rw_heap_local]
          exact hoth_d _ (by intro hc; nomatch hc) (by intro hc; nomatch hc)
        have hperm_next : HasPermArray p.m (fyPref u (k + 1) hk) (wsOf ha_inc) := by
          intro x
          rw [fyPref_succ_apply u hk x]
          rw [rw_local_var_ne _ (by decide : 5 ≠ 1)]
          by_cases hxj : x = jk
          · subst hxj
            rw [wordStore_read_write_self]
            by_cases hji : jk = ik
            · rw [if_pos hji]; dsimp [π_k]; rw [← hji]
            · rw [if_neg hji, if_pos rfl]
          · have hne_j : (x.1 : ℤ) ≠ (jk.1 : ℤ) := by
              intro hc; apply hxj; exact Fin.ext (Int.ofNat.inj hc)
            rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ hi; exact hne_j hi)]
            by_cases hxi : x = ik
            · subst hxi
              rw [if_pos rfl, wordStore_read_write_self]
            · have hne_i : (x.1 : ℤ) ≠ (k : ℤ) := by
                intro hc; apply hxi; exact Fin.ext (Int.ofNat.inj hc)
              rw [if_neg hxi, if_neg hxj,
                wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ hi; exact hne_i hi),
                rw_local_var_ne _ (by decide : 5 ≠ 1),
                rw_local_var_ne _ (by decide : 5 ≠ 1),
                rw_local_var_ne _ (by decide : 5 ≠ 1),
                rw_local_var_ne _ (by decide : 5 ≠ 1)]
              exact hperm_d x
        have hb_draw : 64 * (p.W₂ + 16) ^ 2 ≤ 256 * (V + 8) ^ 2 := by
          have h1 : p.W₂ + 16 ≤ 2 * (V + 8) := by dsimp [CoreParams.W₂]; omega
          calc 64 * (p.W₂ + 16) ^ 2 ≤ 64 * (2 * (V + 8)) ^ 2 :=
                Nat.mul_le_mul_left 64 (Nat.pow_le_pow_left h1 2)
            _ = 256 * (V + 8) ^ 2 := by ring
        have hex_step :=
          ExecBounded.seq ex_d (ExecBounded.seq ex_10 (ExecBounded.seq ex_11
          (ExecBounded.seq ex_12 (ExecBounded.seq ex_13 (ExecBounded.seq ex_w1
          (ExecBounded.seq ex_w2 ex_inc))))))
        refine ⟨wsOf ha_inc, bsNext,
          ⟨hk, rfl, ha_inc, hhz_next,
            hasPhase2Regs_of_eq hregs_k (fun idx => hkeep 0 idx (by decide) (by decide)),
            hasLiftArrays_of_eq hlifts_k (fun v idx hv =>
              hkeep v idx (by rcases hv with rfl | rfl <;> decide) (by rcases hv with rfl | rfl <;> decide)),
            hasZArray_of_eq hz_k (fun idx => hkeep 4 idx (by decide) (by decide)),
            wordStore_read_write_self _ _ _,
            hperm_next⟩,
          ExecBounded.mono hex_step (by omega) ?_ le_rfl le_rfl⟩
        set Y := (V + 8) ^ 2
        omega)
  rcases hinv_end with ⟨_, hbs5, ha5, hhz5, hregs5, hlifts5, hz5, _, hperm5⟩
  rw [blockBitStream_self] at hbs5
  subst bs₅
  rw [fyPref_full_eq_fyPerm u] at hperm5
  have ex_all :=
    ExecBounded.seq ex_i0 (ExecBounded.seq ex_init_loop (ExecBounded.seq ex_i2 ex_swap_loop))
  have hu_all : 68 + ((68 + p.m * 200) + (68 + (68 + p.m * (600 + 24 * (p.W₂ + 1))))) ≤
      600 + p.m * (900 + 24 * (p.W₂ + 1)) := by
    have h1 : p.m * 200 + p.m * (600 + 24 * (p.W₂ + 1)) ≤ p.m * (900 + 24 * (p.W₂ + 1)) := by
      have : p.m * 200 + p.m * (600 + 24 * (p.W₂ + 1)) = p.m * (800 + 24 * (p.W₂ + 1)) := by ring
      rw [this]; exact Nat.mul_le_mul_left p.m (by omega)
    omega
  refine ⟨ws₅, ha5, hhz5, hregs5, hlifts5, hz5, hperm5,
    ExecBounded.mono ex_all hu_all ?_ le_rfl le_rfl⟩
  set Y := (V + 8) ^ 2
  have h1 : (400000 + 700000 * p.m) * Y = 400000 * Y + p.m * (700000 * Y) := by ring
  have h2 : p.m * (200000 * Y) + p.m * (500000 * Y) = p.m * (700000 * Y) := by ring
  omega

end UL.Proof_lem_A_2
