import Mathlib
import UL.Proof.lem_A_2.ExactA_Field
import UL.Proof.lem_A_2.H1b_FY
set_option autoImplicit false
set_option maxHeartbeats 1200000

namespace UL.Proof_lem_A_2

/-! ### 1. Core-placement & unused-fill permutation `coreFillPerm` -/

def freqOf {m N : ℕ} (g_hat : Fin N → Fin m) (h : Fin m) : ℕ :=
  (Finset.univ.filter (fun t : Fin N => g_hat t = h)).card

theorem coreIdxLt {r s₁ : ℕ} (b : Fin r) (j : Fin s₁) : b.1 * s₁ + j.1 < r * s₁ := by
  have hb : (b.1 + 1) * s₁ ≤ r * s₁ := Nat.mul_le_mul_right s₁ b.2
  rw [Nat.add_mul, Nat.one_mul] at hb
  have hj := j.2
  omega

def coreGood {m r s₁ : ℕ} (g_hat : Fin (r * s₁) → Fin m) (b : Fin r) : Bool :=
  decide (∀ j : Fin s₁, freqOf g_hat (g_hat ⟨b.1 * s₁ + j.1, coreIdxLt b j⟩) = 1)

def coreSlotOpt {m r s₁ : ℕ} (s₀ : ℕ) (g_hat : Fin (r * s₁) → Fin m) (idx : Fin m) :
    Option (Fin m) :=
  if hb : idx.1 / s₀ < r then
    if hj : idx.1 % s₀ < s₁ then
      if coreGood g_hat ⟨idx.1 / s₀, hb⟩ = true then
        some (g_hat ⟨(idx.1 / s₀) * s₁ + (idx.1 % s₀), coreIdxLt ⟨idx.1 / s₀, hb⟩ ⟨idx.1 % s₀, hj⟩⟩)
      else none
    else none
  else none

theorem coreSlotOpt_blk {m r s₀ s₁ : ℕ} (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀)
    (hrs : r * s₀ ≤ m) (g_hat : Fin (r * s₁) → Fin m) (b : Fin r) (j : Fin s₁) :
    let idx : Fin m := ⟨b.1 * s₀ + j.1, by
      have hb : (b.1 + 1) * s₀ ≤ r * s₀ := Nat.mul_le_mul_right s₀ b.2
      rw [Nat.add_mul, Nat.one_mul] at hb
      have hj := j.2
      omega⟩
    coreSlotOpt s₀ g_hat idx =
      if coreGood g_hat b = true then
        some (g_hat ⟨b.1 * s₁ + j.1, coreIdxLt b j⟩)
      else none := by
  intro idx
  have hs₀_pos : 0 < s₀ := lt_of_lt_of_le (by omega) hs₁_le
  have hj_lt_s₀ : j.1 < s₀ := lt_of_lt_of_le j.2 hs₁_le
  have hdiv : idx.1 / s₀ = b.1 := by
    dsimp [idx]
    rw [mul_comm, Nat.mul_add_div hs₀_pos, Nat.div_eq_of_lt hj_lt_s₀, add_zero]
  have hmod : idx.1 % s₀ = j.1 := by
    dsimp [idx]
    rw [mul_comm, Nat.mul_add_mod, Nat.mod_eq_of_lt hj_lt_s₀]
  unfold coreSlotOpt
  have hb' : idx.1 / s₀ < r := hdiv ▸ b.2
  have hj' : idx.1 % s₀ < s₁ := hmod ▸ j.2
  rw [dif_pos hb', dif_pos hj']
  have hb_fin : (⟨idx.1 / s₀, hb'⟩ : Fin r) = b := Fin.ext hdiv
  have ht_fin : (⟨(idx.1 / s₀) * s₁ + (idx.1 % s₀), coreIdxLt ⟨idx.1 / s₀, hb'⟩ ⟨idx.1 % s₀, hj'⟩⟩ : Fin (r * s₁)) =
      ⟨b.1 * s₁ + j.1, coreIdxLt b j⟩ := by
    apply Fin.ext; dsimp; rw [hdiv, hmod]
  rw [hb_fin, ht_fin]

theorem coreSlotOpt_injective {m r s₀ s₁ : ℕ} (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀)
    (g_hat : Fin (r * s₁) → Fin m) {idx₁ idx₂ : Fin m} {h : Fin m}
    (h₁ : coreSlotOpt s₀ g_hat idx₁ = some h)
    (h₂ : coreSlotOpt s₀ g_hat idx₂ = some h) :
    idx₁ = idx₂ := by
  unfold coreSlotOpt at h₁ h₂
  split_ifs at h₁ with hb₁ hj₁ hg₁
  split_ifs at h₂ with hb₂ hj₂ hg₂
  injection h₁ with hh₁
  injection h₂ with hh₂
  let t₁ : Fin (r * s₁) := ⟨(idx₁.1 / s₀) * s₁ + (idx₁.1 % s₀), coreIdxLt ⟨idx₁.1 / s₀, hb₁⟩ ⟨idx₁.1 % s₀, hj₁⟩⟩
  let t₂ : Fin (r * s₁) := ⟨(idx₂.1 / s₀) * s₁ + (idx₂.1 % s₀), coreIdxLt ⟨idx₂.1 / s₀, hb₂⟩ ⟨idx₂.1 % s₀, hj₂⟩⟩
  have hfreq1 : freqOf g_hat (g_hat t₁) = 1 :=
    (of_decide_eq_true hg₁) ⟨idx₁.1 % s₀, hj₁⟩
  rw [hh₁] at hfreq1
  have ht₁_mem : t₁ ∈ Finset.univ.filter (fun t => g_hat t = h) :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ _, hh₁⟩
  have ht₂_mem : t₂ ∈ Finset.univ.filter (fun t => g_hat t = h) :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ _, hh₂⟩
  have ht_eq : t₁ = t₂ :=
    Finset.card_le_one.mp (le_of_eq hfreq1) t₁ ht₁_mem t₂ ht₂_mem
  have hval : (idx₁.1 / s₀) * s₁ + (idx₁.1 % s₀) = (idx₂.1 / s₀) * s₁ + (idx₂.1 % s₀) :=
    congrArg Fin.val ht_eq
  have hdiv_eq : idx₁.1 / s₀ = idx₂.1 / s₀ := by
    have hd := congrArg (· / s₁) hval
    dsimp only at hd
    rwa [mul_comm (idx₁.1 / s₀) s₁, Nat.mul_add_div hs₁, Nat.div_eq_of_lt hj₁, add_zero,
         mul_comm (idx₂.1 / s₀) s₁, Nat.mul_add_div hs₁, Nat.div_eq_of_lt hj₂, add_zero] at hd
  have hmod_eq : idx₁.1 % s₀ = idx₂.1 % s₀ := by
    rw [hdiv_eq] at hval; omega
  apply Fin.ext
  have hd1 := Nat.div_add_mod idx₁.1 s₀
  have hd2 := Nat.div_add_mod idx₂.1 s₀
  rw [hdiv_eq, hmod_eq] at hd1
  exact hd1.symm.trans hd2

def isPlacedHandle {m r s₁ : ℕ} (g_hat : Fin (r * s₁) → Fin m) (h : Fin m) : Bool :=
  decide (∃ b : Fin r, coreGood g_hat b = true ∧
    ∃ j : Fin s₁, g_hat ⟨b.1 * s₁ + j.1, coreIdxLt b j⟩ = h)

theorem isPlacedHandle_iff_exists_slot {m r s₀ s₁ : ℕ} (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀)
    (hrs : r * s₀ ≤ m) (g_hat : Fin (r * s₁) → Fin m) (h : Fin m) :
    isPlacedHandle g_hat h = true ↔ ∃ idx : Fin m, coreSlotOpt s₀ g_hat idx = some h := by
  unfold isPlacedHandle
  rw [decide_eq_true_eq]
  constructor
  · rintro ⟨b, hg, j, rfl⟩
    let idx : Fin m := ⟨b.1 * s₀ + j.1, by
      have hb : (b.1 + 1) * s₀ ≤ r * s₀ := Nat.mul_le_mul_right s₀ b.2
      rw [Nat.add_mul, Nat.one_mul] at hb; have := j.2; omega⟩
    refine ⟨idx, ?_⟩
    rw [coreSlotOpt_blk hs₁ hs₁_le hrs g_hat b j, if_pos hg]
  · rintro ⟨idx, hsome⟩
    unfold coreSlotOpt at hsome
    split_ifs at hsome with hb hj hg
    · injection hsome with hh
      exact ⟨⟨idx.1 / s₀, hb⟩, hg, ⟨idx.1 % s₀, hj⟩, hh⟩

private theorem count_prefix_eq_card {m : ℕ} (P : Fin m → Bool) :
    ∀ k : ℕ, k ≤ m →
      (Finset.univ.filter (fun x : Fin m => x.1 < k ∧ P x = true)).card +
      (Finset.univ.filter (fun x : Fin m => x.1 < k ∧ P x = false)).card = k := by
  intro k hk
  have hpart := Finset.card_filter_add_card_filter_not
    (s := Finset.univ.filter (fun x : Fin m => x.1 < k))
    (fun x : Fin m => P x = true)
  simp only [Finset.filter_filter, Bool.not_eq_true] at hpart
  rw [hpart]
  have hcard : (Finset.univ.filter (fun x : Fin m => x.1 < k)).card = (Finset.range k).card := by
    refine Finset.card_bij (fun x _ => x.1) ?_ ?_ ?_
    · intro x hx; exact Finset.mem_range.mpr (Finset.mem_filter.mp hx).2
    · intro x₁ _ x₂ _ h; exact Fin.ext h
    · intro i hi
      have hi_lt : i < k := Finset.mem_range.mp hi
      exact ⟨⟨i, lt_of_lt_of_le hi_lt hk⟩, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hi_lt⟩, rfl⟩
  rw [hcard, Finset.card_range]

def unusedPrefix {m r s₁ : ℕ} (g_hat : Fin (r * s₁) → Fin m) : ℕ → List (Fin m)
  | 0 => []
  | k + 1 =>
      if hk : k < m then
        if isPlacedHandle g_hat ⟨k, hk⟩ then
          unusedPrefix g_hat k
        else
          unusedPrefix g_hat k ++ [⟨k, hk⟩]
      else
        unusedPrefix g_hat k

theorem unusedPrefix_props {m r s₁ : ℕ} (g_hat : Fin (r * s₁) → Fin m) :
    ∀ k : ℕ, k ≤ m →
      (unusedPrefix g_hat k).Nodup ∧
      (∀ x ∈ unusedPrefix g_hat k, x.1 < k ∧ isPlacedHandle g_hat x = false) ∧
      (unusedPrefix g_hat k).length =
        (Finset.univ.filter (fun h : Fin m => h.1 < k ∧ isPlacedHandle g_hat h = false)).card := by
  intro k
  induction k with
  | zero =>
      intro _
      refine ⟨List.nodup_nil, ?_, ?_⟩
      · intro _ h; simp [unusedPrefix] at h
      · have h0 : Finset.univ.filter (fun h : Fin m => h.1 < 0 ∧ isPlacedHandle g_hat h = false) = ∅ := by
          ext x; simp
        rw [h0]; rfl
  | succ k ih =>
      intro hk1
      have hk : k < m := hk1
      obtain ⟨hnodup, hmem, hlen⟩ := ih (le_of_lt hk1)
      simp only [unusedPrefix, dif_pos hk]
      by_cases hp : isPlacedHandle g_hat ⟨k, hk⟩ = true
      · rw [if_pos hp]
        have hfeq : Finset.univ.filter (fun h : Fin m => h.1 < k + 1 ∧ isPlacedHandle g_hat h = false) =
            Finset.univ.filter (fun h : Fin m => h.1 < k ∧ isPlacedHandle g_hat h = false) := by
          ext x
          simp only [Finset.mem_filter, Finset.mem_univ, true_and]
          constructor
          · rintro ⟨hlt, hfx⟩
            rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hlt) with hlt' | heq
            · exact ⟨hlt', hfx⟩
            · have hx_eq : x = ⟨k, hk⟩ := Fin.ext heq
              rw [hx_eq, hp] at hfx; nomatch hfx
          · rintro ⟨hlt, hfx⟩; exact ⟨by omega, hfx⟩
        exact ⟨hnodup, fun x hx => ⟨by have := (hmem x hx).1; omega, (hmem x hx).2⟩, hfeq ▸ hlen⟩
      · have hp_false : isPlacedHandle g_hat ⟨k, hk⟩ = false := Bool.eq_false_iff.mpr hp
        rw [if_neg hp]
        have hnot_in : (⟨k, hk⟩ : Fin m) ∉ unusedPrefix g_hat k := by
          intro hin
          have hlt : k < k := (hmem (⟨k, hk⟩ : Fin m) hin).1
          omega
        have hnodup' : (unusedPrefix g_hat k ++ [(⟨k, hk⟩ : Fin m)]).Nodup :=
          List.nodup_append.mpr ⟨hnodup, List.nodup_singleton _, fun x hx y hy heq => by
            rcases List.mem_singleton.mp hy with rfl
            subst heq
            exact hnot_in hx⟩
        have hfeq : Finset.univ.filter (fun h : Fin m => h.1 < k + 1 ∧ isPlacedHandle g_hat h = false) =
            insert (⟨k, hk⟩ : Fin m)
              (Finset.univ.filter (fun h : Fin m => h.1 < k ∧ isPlacedHandle g_hat h = false)) := by
          ext x
          simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert]
          constructor
          · rintro ⟨hlt, hfx⟩
            rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hlt) with hlt' | heq
            · exact Or.inr ⟨hlt', hfx⟩
            · exact Or.inl (Fin.ext heq)
          · rintro (rfl | ⟨hlt, hfx⟩)
            · exact ⟨Nat.lt_succ_self k, hp_false⟩
            · exact ⟨by omega, hfx⟩
        have hnot_f : (⟨k, hk⟩ : Fin m) ∉
            Finset.univ.filter (fun h : Fin m => h.1 < k ∧ isPlacedHandle g_hat h = false) := by
          simp
        refine ⟨hnodup', ?_, ?_⟩
        · intro x hx
          rcases List.mem_append.mp hx with hx1 | hx2
          · exact ⟨by have := (hmem x hx1).1; omega, (hmem x hx1).2⟩
          · rcases List.mem_singleton.mp hx2 with rfl
            exact ⟨Nat.lt_succ_self k, hp_false⟩
        · rw [List.length_append, List.length_singleton, hlen, hfeq, Finset.card_insert_of_notMem hnot_f]

def emptyBefore {m r s₁ : ℕ} (s₀ : ℕ) (g_hat : Fin (r * s₁) → Fin m) : ℕ → ℕ
  | 0 => 0
  | k + 1 =>
      emptyBefore s₀ g_hat k +
        if hk : k < m then
          if (coreSlotOpt s₀ g_hat ⟨k, hk⟩).isSome then 0 else 1
        else 0

theorem emptyBefore_mono {m r s₀ s₁ : ℕ} (g_hat : Fin (r * s₁) → Fin m) :
    ∀ {a b : ℕ}, a ≤ b → emptyBefore s₀ g_hat a ≤ emptyBefore s₀ g_hat b := by
  intro a b hab
  induction hab with
  | refl => exact le_rfl
  | step _ ih => simp only [emptyBefore]; omega

theorem emptyBefore_lt_of_none {m r s₀ s₁ : ℕ} (g_hat : Fin (r * s₁) → Fin m)
    {i₁ i₂ : ℕ} (hi₁ : i₁ < m) (hnone : coreSlotOpt s₀ g_hat ⟨i₁, hi₁⟩ = none)
    (hlt : i₁ < i₂) :
    emptyBefore s₀ g_hat i₁ < emptyBefore s₀ g_hat i₂ := by
  have hstep : emptyBefore s₀ g_hat (i₁ + 1) = emptyBefore s₀ g_hat i₁ + 1 := by
    simp [emptyBefore, hi₁, hnone]
  have hmono : emptyBefore s₀ g_hat (i₁ + 1) ≤ emptyBefore s₀ g_hat i₂ :=
    emptyBefore_mono g_hat hlt
  omega

theorem emptyBefore_eq_card {m r s₀ s₁ : ℕ} (g_hat : Fin (r * s₁) → Fin m) :
    ∀ k : ℕ, k ≤ m →
      emptyBefore s₀ g_hat k =
        (Finset.univ.filter (fun idx : Fin m =>
          idx.1 < k ∧ (coreSlotOpt s₀ g_hat idx).isSome = false)).card := by
  intro k
  induction k with
  | zero =>
      intro _
      have h0 : Finset.univ.filter (fun idx : Fin m =>
          idx.1 < 0 ∧ (coreSlotOpt s₀ g_hat idx).isSome = false) = ∅ := by ext x; simp
      rw [h0]; rfl
  | succ k ih =>
      intro hk1
      have hk : k < m := hk1
      simp only [emptyBefore, dif_pos hk, ih (le_of_lt hk1)]
      by_cases hs : (coreSlotOpt s₀ g_hat ⟨k, hk⟩).isSome = true
      · rw [if_pos hs, add_zero]
        congr 1; ext x
        simp only [Finset.mem_filter, Finset.mem_univ, true_and]
        constructor
        · rintro ⟨hlt, hfx⟩; exact ⟨by omega, hfx⟩
        · rintro ⟨hlt, hfx⟩
          rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hlt) with hlt' | heq
          · exact ⟨hlt', hfx⟩
          · have hx_eq : x = ⟨k, hk⟩ := Fin.ext heq
            rw [hx_eq, hs] at hfx; nomatch hfx
      · have hs_f : (coreSlotOpt s₀ g_hat ⟨k, hk⟩).isSome = false := Bool.eq_false_iff.mpr hs
        rw [if_neg hs]
        have hfeq : Finset.univ.filter (fun idx : Fin m =>
            idx.1 < k + 1 ∧ (coreSlotOpt s₀ g_hat idx).isSome = false) =
            insert (⟨k, hk⟩ : Fin m)
              (Finset.univ.filter (fun idx : Fin m =>
                idx.1 < k ∧ (coreSlotOpt s₀ g_hat idx).isSome = false)) := by
          ext x
          simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert]
          constructor
          · rintro ⟨hlt, hfx⟩
            rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hlt) with hlt' | heq
            · exact Or.inr ⟨hlt', hfx⟩
            · exact Or.inl (Fin.ext heq)
          · rintro (rfl | ⟨hlt, hfx⟩)
            · exact ⟨Nat.lt_succ_self k, hs_f⟩
            · exact ⟨by omega, hfx⟩
        have hnot_f : (⟨k, hk⟩ : Fin m) ∉
            Finset.univ.filter (fun idx : Fin m =>
              idx.1 < k ∧ (coreSlotOpt s₀ g_hat idx).isSome = false) := by simp
        rw [hfeq, Finset.card_insert_of_notMem hnot_f]

theorem emptyBefore_full_eq_unused_length {m r s₀ s₁ : ℕ}
    (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀) (hrs : r * s₀ ≤ m)
    (g_hat : Fin (r * s₁) → Fin m) :
    emptyBefore s₀ g_hat m = (unusedPrefix g_hat m).length := by
  rw [emptyBefore_eq_card g_hat m le_rfl, (unusedPrefix_props g_hat m le_rfl).2.2]
  have hcard_placed :
      (Finset.univ.filter (fun idx : Fin m => idx.1 < m ∧ (coreSlotOpt s₀ g_hat idx).isSome = true)).card =
      (Finset.univ.filter (fun h : Fin m => h.1 < m ∧ isPlacedHandle g_hat h = true)).card := by
    refine Finset.card_bij
      (fun idx hidx => (coreSlotOpt s₀ g_hat idx).get (Finset.mem_filter.mp hidx).2.2)
      ?_ ?_ ?_
    · intro idx hidx
      have his := (Finset.mem_filter.mp hidx).2.2
      let h := (coreSlotOpt s₀ g_hat idx).get his
      have hsome : coreSlotOpt s₀ g_hat idx = some h := Option.some_get his |>.symm
      have hpl : isPlacedHandle g_hat h = true :=
        (isPlacedHandle_iff_exists_slot hs₁ hs₁_le hrs g_hat h).mpr ⟨idx, hsome⟩
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, h.2, hpl⟩
    · intro idx₁ h₁ idx₂ h₂ heq
      have hs₁' := Option.some_get (Finset.mem_filter.mp h₁).2.2 |>.symm
      have hs₂' := Option.some_get (Finset.mem_filter.mp h₂).2.2 |>.symm
      dsimp only at heq
      rw [heq] at hs₁'
      exact coreSlotOpt_injective hs₁ hs₁_le g_hat hs₁' hs₂'
    · intro h hh
      have hpl := (Finset.mem_filter.mp hh).2.2
      obtain ⟨idx, hsome⟩ := (isPlacedHandle_iff_exists_slot hs₁ hs₁_le hrs g_hat h).mp hpl
      have his : (coreSlotOpt s₀ g_hat idx).isSome = true := by simp [hsome]
      refine ⟨idx, Finset.mem_filter.mpr ⟨Finset.mem_univ _, idx.2, his⟩, ?_⟩
      simp [hsome]
  have h1 := count_prefix_eq_card (fun idx : Fin m => (coreSlotOpt s₀ g_hat idx).isSome) m le_rfl
  have h2 := count_prefix_eq_card (fun h : Fin m => isPlacedHandle g_hat h) m le_rfl
  dsimp only at h1 h2
  omega

theorem emptyBefore_lt_unused_length {m r s₀ s₁ : ℕ}
    (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀) (hrs : r * s₀ ≤ m)
    (g_hat : Fin (r * s₁) → Fin m) {idx : Fin m}
    (hnone : coreSlotOpt s₀ g_hat idx = none) :
    emptyBefore s₀ g_hat idx.1 < (unusedPrefix g_hat m).length := by
  rw [← emptyBefore_full_eq_unused_length hs₁ hs₁_le hrs g_hat]
  exact emptyBefore_lt_of_none g_hat idx.2 hnone idx.2

def coreFillFn {m r s₀ s₁ : ℕ}
    (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀) (hrs : r * s₀ ≤ m)
    (g_hat : Fin (r * s₁) → Fin m) (idx : Fin m) : Fin m :=
  match hopt : coreSlotOpt s₀ g_hat idx with
  | some h => h
  | none =>
      (unusedPrefix g_hat m)[emptyBefore s₀ g_hat idx.1]'(
        emptyBefore_lt_unused_length hs₁ hs₁_le hrs g_hat hopt)

theorem coreFillFn_of_some {m r s₀ s₁ : ℕ}
    (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀) (hrs : r * s₀ ≤ m)
    (g_hat : Fin (r * s₁) → Fin m) {idx y : Fin m}
    (h : coreSlotOpt s₀ g_hat idx = some y) :
    coreFillFn hs₁ hs₁_le hrs g_hat idx = y := by
  unfold coreFillFn
  split
  · next h' hopt => rw [h] at hopt; injection hopt with hy; exact hy.symm
  · next hopt => rw [h] at hopt; nomatch hopt

theorem coreFillFn_of_none {m r s₀ s₁ : ℕ}
    (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀) (hrs : r * s₀ ≤ m)
    (g_hat : Fin (r * s₁) → Fin m) {idx : Fin m}
    (h : coreSlotOpt s₀ g_hat idx = none) :
    coreFillFn hs₁ hs₁_le hrs g_hat idx =
      (unusedPrefix g_hat m)[emptyBefore s₀ g_hat idx.1]'(
        emptyBefore_lt_unused_length hs₁ hs₁_le hrs g_hat h) := by
  unfold coreFillFn
  split
  · next _ hopt => rw [h] at hopt; nomatch hopt
  · next hopt => rfl

theorem coreFillFn_bijective {m r s₀ s₁ : ℕ}
    (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀) (hrs : r * s₀ ≤ m)
    (g_hat : Fin (r * s₁) → Fin m) :
    Function.Bijective (coreFillFn hs₁ hs₁_le hrs g_hat) := by
  rw [Fintype.bijective_iff_injective_and_card]
  refine ⟨?_, rfl⟩
  intro idx₁ idx₂ heq
  obtain ⟨hnodup, hmem, _⟩ := unusedPrefix_props g_hat m le_rfl
  cases h₁ : coreSlotOpt s₀ g_hat idx₁ with
  | some y₁ =>
      rw [coreFillFn_of_some hs₁ hs₁_le hrs g_hat h₁] at heq
      cases h₂ : coreSlotOpt s₀ g_hat idx₂ with
      | some y₂ =>
          rw [coreFillFn_of_some hs₁ hs₁_le hrs g_hat h₂] at heq
          subst heq
          exact coreSlotOpt_injective hs₁ hs₁_le g_hat h₁ h₂
      | none =>
          rw [coreFillFn_of_none hs₁ hs₁_le hrs g_hat h₂] at heq
          have hy₁_pl : isPlacedHandle g_hat y₁ = true :=
            (isPlacedHandle_iff_exists_slot hs₁ hs₁_le hrs g_hat y₁).mpr ⟨idx₁, h₁⟩
          have hy₂_mem : (unusedPrefix g_hat m)[emptyBefore s₀ g_hat idx₂.1]'(
              emptyBefore_lt_unused_length hs₁ hs₁_le hrs g_hat h₂) ∈ unusedPrefix g_hat m :=
            List.getElem_mem _
          have hy₂_npl : isPlacedHandle g_hat y₁ = false := heq ▸ (hmem _ hy₂_mem).2
          rw [hy₁_pl] at hy₂_npl; nomatch hy₂_npl
  | none =>
      rw [coreFillFn_of_none hs₁ hs₁_le hrs g_hat h₁] at heq
      cases h₂ : coreSlotOpt s₀ g_hat idx₂ with
      | some y₂ =>
          rw [coreFillFn_of_some hs₁ hs₁_le hrs g_hat h₂] at heq
          have hy₂_pl : isPlacedHandle g_hat y₂ = true :=
            (isPlacedHandle_iff_exists_slot hs₁ hs₁_le hrs g_hat y₂).mpr ⟨idx₂, h₂⟩
          have hy₁_mem : (unusedPrefix g_hat m)[emptyBefore s₀ g_hat idx₁.1]'(
              emptyBefore_lt_unused_length hs₁ hs₁_le hrs g_hat h₁) ∈ unusedPrefix g_hat m :=
            List.getElem_mem _
          have hy₁_npl : isPlacedHandle g_hat y₂ = false := heq.symm ▸ (hmem _ hy₁_mem).2
          rw [hy₂_pl] at hy₁_npl; nomatch hy₁_npl
      | none =>
          rw [coreFillFn_of_none hs₁ hs₁_le hrs g_hat h₂] at heq
          have hidx_eq : emptyBefore s₀ g_hat idx₁.1 = emptyBefore s₀ g_hat idx₂.1 :=
            (hnodup.getElem_inj_iff).mp heq
          by_contra hne
          have hval_ne : idx₁.1 ≠ idx₂.1 := fun hv => hne (Fin.ext hv)
          rcases lt_or_gt_of_ne hval_ne with hlt | hgt
          · have := emptyBefore_lt_of_none g_hat idx₁.2 h₁ hlt; omega
          · have := emptyBefore_lt_of_none g_hat idx₂.2 h₂ hgt; omega

noncomputable def coreFillPerm {m r s₀ s₁ : ℕ}
    (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀) (hrs : r * s₀ ≤ m)
    (g_hat : Fin (r * s₁) → Fin m) : Equiv.Perm (Fin m) :=
  Equiv.ofBijective (coreFillFn hs₁ hs₁_le hrs g_hat) (coreFillFn_bijective hs₁ hs₁_le hrs g_hat)

@[simp] theorem coreFillPerm_apply {m r s₀ s₁ : ℕ}
    (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀) (hrs : r * s₀ ≤ m)
    (g_hat : Fin (r * s₁) → Fin m) (idx : Fin m) :
    coreFillPerm hs₁ hs₁_le hrs g_hat idx = coreFillFn hs₁ hs₁_le hrs g_hat idx := rfl

theorem coreFillPerm_mem_sliceBlockSet {m r s₀ s₁ : ℕ}
    (hs₁ : 1 ≤ s₁) (hs₁_le : s₁ ≤ s₀) (hrs : r * s₀ ≤ m)
    (g_hat : Fin (r * s₁) → Fin m) {b : Fin r}
    (hgood : coreGood g_hat b = true) (j : Fin s₁) :
    g_hat ⟨b.1 * s₁ + j.1, coreIdxLt b j⟩ ∈
      sliceBlockSet hrs (coreFillPerm hs₁ hs₁_le hrs g_hat) b := by
  unfold sliceBlockSet
  rw [Finset.mem_image]
  let j₀ : Fin s₀ := ⟨j.1, lt_of_lt_of_le j.2 hs₁_le⟩
  refine ⟨j₀, Finset.mem_univ j₀, ?_⟩
  rw [coreFillPerm_apply]
  unfold coreFillFn
  have hblk := coreSlotOpt_blk hs₁ hs₁_le hrs g_hat b j
  rw [if_pos hgood] at hblk
  dsimp [j₀]
  split
  · next h hopt =>
    rw [hblk] at hopt
    injection hopt with hh
    exact hh.symm
  · next hopt =>
    rw [hblk] at hopt; nomatch hopt

/-! ### 2. Padded centerpoint depth & pairwise collision probability over `QuadExt` -/

theorem isCenterpoint_half_pad {D m N : ℕ} (hD : 1 ≤ D) (hm : 1 ≤ m) (hmN : m < N)
    {K : Type*} [Fintype K] (eK : K ≃ Fin N)
    {α₀ : ℝ} (hα0 : 0 < α₀)
    {Q_lift : Fin m → EuclideanSpace ℝ (Fin D)}
    {z : EuclideanSpace ℝ (Fin D)}
    (hcp : IsCenterpoint α₀ Q_lift z) :
    let padIdx : K → Fin m := fun y => ⟨(eK y).1 % m, Nat.mod_lt _ hm⟩
    IsCenterpoint (α₀ / 2) (fun y => Q_lift (padIdx y)) z := by
  classical
  intro padIdx
  let Q_pad : K → EuclideanSpace ℝ (Fin D) := fun y => Q_lift (padIdx y)
  let Q_m : ℕ := N / m
  have hQm1 : 1 ≤ Q_m := Nat.div_pos (le_of_lt hmN) hm
  -- Existence of a closed halfspace containing `z` in `ℝ^D` (`D ≥ 1`)
  have hne_depth : {n : ℕ | ∃ H : Set (EuclideanSpace ℝ (Fin D)),
      IsClosedHalfspace H ∧ z ∈ H ∧ n = pointCount Q_pad H}.Nonempty := by
    let v : EuclideanSpace ℝ (Fin D) := EuclideanSpace.single ⟨0, by omega⟩ 1
    have hv_ne : v ≠ 0 := by
      intro hv0
      have h1 : v ⟨0, by omega⟩ = 0 := by rw [hv0]; rfl
      simp [v] at h1
    let H : Set (EuclideanSpace ℝ (Fin D)) := {x | inner ℝ v x ≤ inner ℝ v z}
    exact ⟨pointCount Q_pad H, H, ⟨v, hv_ne, inner ℝ v z, rfl⟩, by simp [H], rfl⟩
  obtain ⟨H₀, hH₀_cl, hz_H₀, hdepth_eq⟩ := Nat.sInf_mem hne_depth
  -- Each `h ∈ Fin m` has at least `Q_m` preimages in `K` under `padIdx`
  let emb : Fin m × Fin Q_m → K := fun hk =>
    eK.symm ⟨hk.2.1 * m + hk.1.1, by
      have hk_lt : (hk.2.1 + 1) * m ≤ Q_m * m := Nat.mul_le_mul_right m hk.2.2
      have hqm_le : Q_m * m ≤ N := Nat.div_mul_le_self N m
      have hh_lt : hk.1.1 < m := hk.1.2
      nlinarith⟩
  have hemb_inj : Function.Injective emb := by
    rintro ⟨h₁, k₁⟩ ⟨h₂, k₂⟩ heq
    have hfin := eK.symm.injective heq
    have hval : k₁.1 * m + h₁.1 = k₂.1 * m + h₂.1 := congrArg Fin.val hfin
    have hh_eq : h₁.1 = h₂.1 := by
      have hm1 := congrArg (· % m) hval
      dsimp only at hm1
      rwa [mul_comm k₁.1 m, Nat.mul_add_mod, Nat.mod_eq_of_lt h₁.2,
           mul_comm k₂.1 m, Nat.mul_add_mod, Nat.mod_eq_of_lt h₂.2] at hm1
    have hk_eq : k₁.1 = k₂.1 := by
      have hd1 := congrArg (· / m) hval
      dsimp only at hd1
      rwa [mul_comm k₁.1 m, Nat.mul_add_div hm, Nat.div_eq_of_lt h₁.2, add_zero,
           mul_comm k₂.1 m, Nat.mul_add_div hm, Nat.div_eq_of_lt h₂.2, add_zero] at hd1
    exact Prod.ext (Fin.ext hh_eq) (Fin.ext hk_eq)
  have hsub :
      ((Finset.univ.filter (fun h : Fin m => Q_lift h ∈ H₀)) ×ˢ (Finset.univ : Finset (Fin Q_m))).image emb ⊆
      Finset.univ.filter (fun y : K => Q_pad y ∈ H₀) := by
    intro y hy
    rcases Finset.mem_image.mp hy with ⟨⟨h, k⟩, hmem, rfl⟩
    have hh_H₀ : Q_lift h ∈ H₀ := (Finset.mem_filter.mp (Finset.mem_product.mp hmem).1).2
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
    have hpad : padIdx (emb (h, k)) = h := by
      apply Fin.ext
      dsimp [padIdx, emb]
      rw [eK.apply_symm_apply]
      dsimp only
      rw [mul_comm k.1 m, Nat.mul_add_mod, Nat.mod_eq_of_lt h.2]
    dsimp [Q_pad]
    rwa [hpad]
  have hcnt_ge : pointCount Q_lift H₀ * Q_m ≤ pointCount Q_pad H₀ := by
    unfold pointCount
    have hc := Finset.card_le_card hsub
    rw [Finset.card_image_of_injective _ hemb_inj, Finset.card_product, Finset.card_univ, Fintype.card_fin] at hc
    exact hc
  have hdepth_lift : halfspaceDepth Q_lift z ≤ pointCount Q_lift H₀ :=
    Nat.sInf_le ⟨H₀, hH₀_cl, hz_H₀, rfl⟩
  have hdepth_pad_ge : Q_m * halfspaceDepth Q_lift z ≤ halfspaceDepth Q_pad z := by
    rw [show halfspaceDepth Q_pad z = pointCount Q_pad H₀ from hdepth_eq]
    calc Q_m * halfspaceDepth Q_lift z
        ≤ Q_m * pointCount Q_lift H₀ := Nat.mul_le_mul_left Q_m hdepth_lift
      _ = pointCount Q_lift H₀ * Q_m := mul_comm _ _
      _ ≤ pointCount Q_pad H₀ := hcnt_ge
  have hcardK : Fintype.card K = N := by
    rw [Fintype.card_congr eK, Fintype.card_fin]
  have hN_le : N ≤ 2 * Q_m * m := by
    have hdiv := Nat.div_add_mod N m
    have hmod := Nat.mod_lt N hm
    dsimp [Q_m] at hQm1 ⊢
    nlinarith
  unfold IsCenterpoint at hcp ⊢
  rw [Fintype.card_fin] at hcp
  rw [hcardK]
  have hN_real : (N : ℝ) ≤ 2 * (Q_m : ℝ) * (m : ℝ) := by exact_mod_cast hN_le
  have hdp_real : (Q_m : ℝ) * (halfspaceDepth Q_lift z : ℝ) ≤ (halfspaceDepth Q_pad z : ℝ) := by
    exact_mod_cast hdepth_pad_ge
  calc (α₀ / 2) * (N : ℝ)
      ≤ (α₀ / 2) * (2 * (Q_m : ℝ) * (m : ℝ)) :=
        mul_le_mul_of_nonneg_left hN_real (by positivity)
    _ = (Q_m : ℝ) * (α₀ * (m : ℝ)) := by ring
    _ ≤ (Q_m : ℝ) * (halfspaceDepth Q_lift z : ℝ) :=
        mul_le_mul_of_nonneg_left hcp (Nat.cast_nonneg Q_m)
    _ ≤ (halfspaceDepth Q_pad z : ℝ) := hdp_real

theorem mod_fiber_card_le {m N : ℕ} (hm : 1 ≤ m) (hmN : m < N)
    {K : Type*} [Fintype K] (eK : K ≃ Fin N) (h : Fin m) :
    (Finset.univ.filter (fun y : K => (eK y).1 % m = h.1)).card ≤ 2 * (N / m) := by
  let Q_m := N / m
  have hQm1 : 1 ≤ Q_m := Nat.div_pos (le_of_lt hmN) hm
  have hN_lt : N < (Q_m + 1) * m := by
    have hdiv := Nat.div_add_mod N m
    have hmod := Nat.mod_lt N hm
    dsimp [Q_m]; nlinarith
  let qMap : (y : K) → y ∈ Finset.univ.filter (fun y : K => (eK y).1 % m = h.1) → Fin (Q_m + 1) :=
    fun y _ => ⟨(eK y).1 / m, Nat.div_lt_of_lt_mul (by linarith [(eK y).2])⟩
  have hcard_le :
      (Finset.univ.filter (fun y : K => (eK y).1 % m = h.1)).card ≤ (Finset.univ : Finset (Fin (Q_m + 1))).card := by
    refine Finset.card_le_card_of_injOn (fun y => ⟨(eK y).1 / m, Nat.div_lt_of_lt_mul (by linarith [(eK y).2])⟩)
      (fun _ _ => Finset.mem_coe.mpr (Finset.mem_univ _)) ?_
    intro y₁ hy₁ y₂ hy₂ heq
    have hm1 : (eK y₁).1 % m = h.1 := (Finset.mem_filter.mp hy₁).2
    have hm2 : (eK y₂).1 % m = h.1 := (Finset.mem_filter.mp hy₂).2
    have hd_eq : (eK y₁).1 / m = (eK y₂).1 / m := congrArg Fin.val heq
    have hval_eq : (eK y₁).1 = (eK y₂).1 := by
      have a1 := Nat.div_add_mod (eK y₁).1 m
      have a2 := Nat.div_add_mod (eK y₂).1 m
      rw [hd_eq, hm1] at a1
      rw [hm2] at a2
      exact a1.symm.trans a2
    exact eK.injective (Fin.ext hval_eq)
  rw [Finset.card_univ, Fintype.card_fin] at hcard_le
  dsimp [Q_m] at hcard_le hQm1
  omega

theorem pair_mod_collision_card_le {m N : ℕ} (hm : 1 ≤ m) (hmN : m < N)
    {K : Type*} [Field K] [Fintype K] [DecidableEq K] (eK : K ≃ Fin N)
    {s₁ : ℕ} (hs₁ : 2 ≤ s₁) {x₁ x₂ : K} (hne : x₁ ≠ x₂) :
    m * (Finset.univ.filter (fun c : Fin s₁ → K =>
      (eK (evalPoly c x₁)).1 % m = (eK (evalPoly c x₂)).1 % m)).card ≤
    2 * Fintype.card (Fin s₁ → K) := by
  classical
  have hcardK : Fintype.card K = N := by rw [Fintype.card_congr eK, Fintype.card_fin]
  let P : K × K → Prop := fun yy => (eK yy.1).1 % m = (eK yy.2).1 % m
  have hpair := evalPoly_pair_filter_card hs₁ hne P
  dsimp [P] at hpair
  rw [hpair]
  -- Bound `(Finset.univ.filter P).card ≤ N * (2 * (N / m))`
  have hprod_sub :
      Finset.univ.filter P ⊆
        (Finset.univ : Finset K).biUnion (fun y₁ =>
          ({y₁} : Finset K) ×ˢ Finset.univ.filter (fun y₂ : K => (eK y₂).1 % m = (eK y₁).1 % m)) := by
    rintro ⟨y₁, y₂⟩ hy
    have hP : (eK y₁).1 % m = (eK y₂).1 % m := (Finset.mem_filter.mp hy).2
    rw [Finset.mem_biUnion]
    exact ⟨y₁, Finset.mem_univ _, Finset.mem_product.mpr
      ⟨Finset.mem_singleton_self y₁, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hP.symm⟩⟩⟩
  have hP_le : (Finset.univ.filter P).card ≤ N * (2 * (N / m)) := by
    calc (Finset.univ.filter P).card
        ≤ ((Finset.univ : Finset K).biUnion (fun y₁ =>
            ({y₁} : Finset K) ×ˢ Finset.univ.filter (fun y₂ : K => (eK y₂).1 % m = (eK y₁).1 % m))).card :=
          Finset.card_le_card hprod_sub
      _ ≤ ∑ y₁ : K, (({y₁} : Finset K) ×ˢ
            Finset.univ.filter (fun y₂ : K => (eK y₂).1 % m = (eK y₁).1 % m)).card :=
          Finset.card_biUnion_le
      _ ≤ ∑ _y₁ : K, (2 * (N / m)) := by
          refine Finset.sum_le_sum fun y₁ _ => ?_
          rw [Finset.card_product, Finset.card_singleton, one_mul]
          exact mod_fiber_card_le hm hmN eK ⟨(eK y₁).1 % m, Nat.mod_lt _ hm⟩
      _ = N * (2 * (N / m)) := by simp [hcardK]
  have hm_P : m * (Finset.univ.filter P).card ≤ 2 * N ^ 2 := by
    have hqm : m * (N / m) ≤ N := Nat.mul_div_le N m
    calc m * (Finset.univ.filter P).card
        ≤ m * (N * (2 * (N / m))) := Nat.mul_le_mul_left m hP_le
      _ = 2 * N * (m * (N / m)) := by ring
      _ ≤ 2 * N * N := Nat.mul_le_mul_left (2 * N) hqm
      _ = 2 * N ^ 2 := by ring
  have hcard_pi : Fintype.card (Fin s₁ → K) = N ^ 2 * N ^ (s₁ - 2) := by
    rw [Fintype.card_pi]
    simp only [Finset.prod_const, Finset.card_univ, Fintype.card_fin, hcardK]
    rw [← pow_add, show 2 + (s₁ - 2) = s₁ by omega]
  rw [hcardK, hcard_pi]
  calc m * ((Finset.univ.filter P).card * N ^ (s₁ - 2))
      = (m * (Finset.univ.filter P).card) * N ^ (s₁ - 2) := by ring
    _ ≤ (2 * N ^ 2) * N ^ (s₁ - 2) := Nat.mul_le_mul_right _ hm_P
    _ = 2 * (N ^ 2 * N ^ (s₁ - 2)) := by ring

/-! ### 3. Pure specification connecting `2 * s₁` modular bit-draws to `Equiv.Perm (Fin m)` -/

def coeffsEquivRaw (p a s₁ : ℕ) [NeZero p] :
    (Fin (2 * s₁) → Fin p) ≃ (Fin s₁ → QuadExt p a) where
  toFun raw k :=
    ⟨((raw ⟨2 * k.1, by omega⟩).1 : ZMod p),
     ((raw ⟨2 * k.1 + 1, by omega⟩).1 : ZMod p)⟩
  invFun c i :=
    if i.1 % 2 = 0 then
      ⟨(c ⟨i.1 / 2, by omega⟩).re.val, (c ⟨i.1 / 2, by omega⟩).re.val_lt⟩
    else
      ⟨(c ⟨i.1 / 2, by omega⟩).im.val, (c ⟨i.1 / 2, by omega⟩).im.val_lt⟩
  left_inv raw := by
    funext i
    apply Fin.ext
    dsimp only
    by_cases hev : i.1 % 2 = 0
    · rw [if_pos hev]
      dsimp only
      have hidx : (⟨2 * (i.1 / 2), by omega⟩ : Fin (2 * s₁)) = i := Fin.ext (by dsimp; omega)
      rw [hidx, ZMod.val_natCast_of_lt (raw i).2]
    · rw [if_neg hev]
      dsimp only
      have hidx : (⟨2 * (i.1 / 2) + 1, by omega⟩ : Fin (2 * s₁)) = i := Fin.ext (by dsimp; omega)
      rw [hidx, ZMod.val_natCast_of_lt (raw i).2]
  right_inv c := by
    funext k
    ext
    · dsimp only
      have hev : (2 * k.1) % 2 = 0 := by omega
      rw [if_pos hev]
      dsimp only
      have hk : (⟨(2 * k.1) / 2, by omega⟩ : Fin s₁) = k := Fin.ext (by dsimp; omega)
      rw [hk, ZMod.natCast_zmod_val]
    · dsimp only
      have hodd : ¬ ((2 * k.1 + 1) % 2 = 0) := by omega
      rw [if_neg hodd]
      dsimp only
      have hk : (⟨(2 * k.1 + 1) / 2, by omega⟩ : Fin s₁) = k := Fin.ext (by dsimp; omega)
      rw [hk, ZMod.natCast_zmod_val]

section PolyPerm

variable {m W₂ s₀ s₁ : ℕ}

theorem polyPerm_arith (hs₁ : 2 ≤ s₁) (hs₀_ge : 64 * s₁ ^ 2 ≤ s₀) (hm : 2 * s₀ ≤ m) :
    let r := m / s₀
    let q := qOfM m
    let p_pr := firstPrimeIn q
    let a_qnr := firstQnr p_pr
    512 ≤ m ∧ 1 ≤ s₁ ∧ s₁ ≤ s₀ ∧ r * s₀ ≤ m ∧ 64 * (r * s₁ ^ 2) ≤ m ∧ r * s₁ < m ∧
    Nat.Prime p_pr ∧ 26 ≤ p_pr ∧ p_pr < m ∧ m < p_pr * p_pr ∧
    1 ≤ a_qnr ∧ a_qnr < p_pr ∧ (∀ z : ZMod p_pr, z * z ≠ (a_qnr : ZMod p_pr)) := by
  intro r q p_pr a_qnr
  have hs1_sq : 4 ≤ s₁ ^ 2 := by nlinarith
  have hm512 : 512 ≤ m := by nlinarith
  have hs1_le_s0 : s₁ ≤ s₀ := by nlinarith
  have hrs : r * s₀ ≤ m := Nat.div_mul_le_self m s₀
  have h64rs : 64 * (r * s₁ ^ 2) ≤ m := by
    calc 64 * (r * s₁ ^ 2) = r * (64 * s₁ ^ 2) := by ring
      _ ≤ r * s₀ := Nat.mul_le_mul_left r hs₀_ge
      _ ≤ m := hrs
  have hr_ge2 : 2 ≤ r := by
    have : 2 * s₀ / s₀ ≤ m / s₀ := Nat.div_le_div_right hm
    rwa [Nat.mul_div_cancel _ (by omega)] at this
  have hrs1_lt : r * s₁ < m := by nlinarith
  obtain ⟨hq25, hm_lt_q2, h2q_lt_m, _⟩ := qOfM_bounds hm512
  obtain ⟨hp_pr, hq_lt_p, hp_le_2q, hp26⟩ := firstPrimeIn_spec hq25
  obtain ⟨ha1, ha_lt_p, _, hqnr_z⟩ := firstQnr_spec hp_pr hp26
  have hm_lt_p2 : m < p_pr * p_pr := by nlinarith
  exact ⟨hm512, by omega, hs1_le_s0, hrs, h64rs, hrs1_lt,
    hp_pr, hp26, lt_of_le_of_lt hp_le_2q h2q_lt_m, hm_lt_p2,
    ha1, ha_lt_p, hqnr_z⟩

def gHatOfCoeffs (hs₁ : 2 ≤ s₁) (hs₀_ge : 64 * s₁ ^ 2 ≤ s₀) (hm : 2 * s₀ ≤ m)
    (c : Fin s₁ → QuadExt (firstPrimeIn (qOfM m)) (firstQnr (firstPrimeIn (qOfM m))))
    (t : Fin ((m / s₀) * s₁)) : Fin m :=
  let ar := polyPerm_arith hs₁ hs₀_ge hm
  let p_pr := firstPrimeIn (qOfM m)
  let a_qnr := firstQnr p_pr
  haveI : NeZero p_pr := ⟨by have := ar.2.2.2.2.2.2.2.1; omega⟩
  let x_t : QuadExt p_pr a_qnr :=
    QuadExt.decodeFin p_pr a_qnr ⟨t.1, lt_trans t.2 (lt_trans ar.2.2.2.2.2.1 ar.2.2.2.2.2.2.2.2.2.1)⟩
  let y_t : QuadExt p_pr a_qnr := evalPoly c x_t
  ⟨(QuadExt.encodeFin y_t).1 % m, Nat.mod_lt _ (by have := ar.1; omega)⟩

noncomputable def permOfCoeffs (hs₁ : 2 ≤ s₁) (hs₀_ge : 64 * s₁ ^ 2 ≤ s₀) (hm : 2 * s₀ ≤ m)
    (c : Fin s₁ → QuadExt (firstPrimeIn (qOfM m)) (firstQnr (firstPrimeIn (qOfM m)))) :
    Equiv.Perm (Fin m) :=
  let ar := polyPerm_arith hs₁ hs₀_ge hm
  coreFillPerm ar.2.1 ar.2.2.1 ar.2.2.2.1 (gHatOfCoeffs hs₁ hs₀_ge hm c)

noncomputable def permOfPolyBits (hs₁ : 2 ≤ s₁) (hs₀_ge : 64 * s₁ ^ 2 ≤ s₀) (hm : 2 * s₀ ≤ m)
    (f_poly : Fin (2 * s₁) → Fin W₂ → Bool) : Equiv.Perm (Fin m) :=
  let ar := polyPerm_arith hs₁ hs₀_ge hm
  let p_pr := firstPrimeIn (qOfM m)
  let a_qnr := firstQnr p_pr
  have hp_pos : 0 < p_pr := by have := ar.2.2.2.2.2.2.2.1; omega
  haveI : NeZero p_pr := ⟨hp_pos.ne'⟩
  let raw : Fin (2 * s₁) → Fin p_pr := fun i =>
    ⟨bitsToNat W₂ (f_poly i) % p_pr, Nat.mod_lt _ hp_pos⟩
  permOfCoeffs hs₁ hs₀_ge hm (coeffsEquivRaw p_pr a_qnr s₁ raw)

end PolyPerm

/-! ### 4. Master attempt success probability `≥ 1 / 2` -/

private theorem convex_comb_mem_ch {D : ℕ} {κ : Type*} [DecidableEq κ]
    (f : κ → EuclideanSpace ℝ (Fin D)) :
    ∀ (s : Finset κ) (w : κ → ℝ),
      (∀ j ∈ s, 0 ≤ w j) →
      ∑ j ∈ s, w j = 1 →
      ∑ j ∈ s, w j • f j ∈ convexHull ℝ (Set.range f) := by
  intro s
  induction s using Finset.induction with
  | empty => intro w _ h1; simp at h1
  | @insert a t ha ih =>
      intro w hw0 hsum
      rw [Finset.sum_insert ha] at hsum ⊢
      let c : ℝ := ∑ j ∈ t, w j
      have hc_nn : 0 ≤ c := Finset.sum_nonneg (fun j hj => hw0 j (Finset.mem_insert_of_mem hj))
      have hwa_nn : 0 ≤ w a := hw0 a (Finset.mem_insert_self a t)
      have hfa : f a ∈ convexHull ℝ (Set.range f) := subset_convexHull ℝ _ ⟨a, rfl⟩
      by_cases hc0 : c = 0
      · have hj0 : ∀ j ∈ t, w j = 0 :=
          (Finset.sum_eq_zero_iff_of_nonneg (fun j hj => hw0 j (Finset.mem_insert_of_mem hj))).mp hc0
        have hvec0 : ∑ j ∈ t, w j • f j = 0 :=
          Finset.sum_eq_zero (fun j hj => by rw [hj0 j hj, zero_smul])
        have hwa1 : w a = 1 := by dsimp [c] at hc0; linarith
        rw [hvec0, add_zero, hwa1, one_smul]
        exact hfa
      · let w' : κ → ℝ := fun j => w j / c
        have hw'0 : ∀ j ∈ t, 0 ≤ w' j := fun j hj =>
          div_nonneg (hw0 j (Finset.mem_insert_of_mem hj)) hc_nn
        have hw'1 : ∑ j ∈ t, w' j = 1 := by
          dsimp [w']; simp_rw [div_eq_mul_inv]; rw [← Finset.sum_mul]; exact mul_inv_cancel₀ hc0
        have hy : ∑ j ∈ t, w' j • f j ∈ convexHull ℝ (Set.range f) := ih w' hw'0 hw'1
        have hcy : c • ∑ j ∈ t, w' j • f j = ∑ j ∈ t, w j • f j := by
          rw [Finset.smul_sum]
          refine Finset.sum_congr rfl fun j _ => ?_
          rw [smul_smul, mul_div_cancel₀ _ hc0]
        rw [← hcy]
        exact (convex_convexHull ℝ (Set.range f)) hfa hy hwa_nn hc_nn hsum

private theorem mem_convexHull_of_cert {D : ℕ} {κ : Type*} [Fintype κ] [DecidableEq κ]
    {f : κ → EuclideanSpace ℝ (Fin D)} {z : EuclideanSpace ℝ (Fin D)}
    (h : HasConvexHullCert f z) : z ∈ convexHull ℝ (Set.range f) := by
  rcases h with ⟨w, hw0, hw1, hwz⟩
  rw [← hwz]
  exact convex_comb_mem_ch f Finset.univ w (fun j _ => hw0 j) hw1

open Classical in
theorem exact_attempt_success_prob_ge_half
    {D M W₁ m W₂ s₀ s₁ : ℕ} {α₀ : ℝ}
    (hD : 1 ≤ D) (hM : 1 ≤ M) (hs₁ : 2 ≤ s₁)
    (hs₀_ge : 64 * s₁ ^ 2 ≤ s₀) (hm : 2 * s₀ ≤ m)
    (hW₁ : 64 * (M * m) ≤ 2 ^ W₁)
    (hW₂ : 64 * (m * m) ≤ 2 ^ W₂)
    (hα0 : 0 < α₀)
    (Q_lift : Fin m → EuclideanSpace ℝ (Fin D))
    (zPt : (Fin M → Fin m) → EuclideanSpace ℝ (Fin D))
    (goodSample : (Fin M → Fin m) → Bool)
    (hGoodSample :
      9 / 10 ≤ ((Finset.univ.filter (fun ω : Fin M → Fin m => goodSample ω = true)).card : ℝ) /
        (Fintype.card (Fin M → Fin m) : ℝ))
    (hGoodCP : ∀ ω : Fin M → Fin m, goodSample ω = true → IsCenterpoint α₀ Q_lift (zPt ω))
    (hHW_s₁ : ∀ (ι : Type) [Fintype ι] [Nonempty ι] (P : ι → EuclideanSpace ℝ (Fin D)),
      (15 / 16 : ℝ) ≤
        ((Finset.univ.filter (fun sample : Fin s₁ → ι =>
          IsIndexedHalfspaceNet (α₀ / 2) P sample)).card : ℝ) /
        (Fintype.card (Fin s₁ → ι) : ℝ))
    (passBlock : (Fin M → Fin m) → Finset (Fin m) → Bool)
    (hPassSpec : ∀ (ω : Fin M → Fin m) (S : Finset (Fin m)),
      zPt ω ∈ convexHull ℝ (Q_lift '' (S : Set (Fin m))) → passBlock ω S = true) :
    let r : ℕ := m / s₀
    have hrs : r * s₀ ≤ m := Nat.div_mul_le_self m s₀
    1 / 2 ≤
      ((Finset.univ.filter (fun v : Fin (M * W₁ + (2 * s₁) * W₂) → Bool =>
        let sp := splitAttemptBits M W₁ (2 * s₁) W₂ v
        let ω : Fin M → Fin m := fun j =>
          ⟨bitsToNat W₁ (sp.1 j) % m, Nat.mod_lt _ (by
            have := (polyPerm_arith hs₁ hs₀_ge hm).1; omega)⟩
        let π : Equiv.Perm (Fin m) := permOfPolyBits hs₁ hs₀_ge hm sp.2
        let k_pass : ℕ :=
          (Finset.univ.filter (fun b : Fin r =>
            passBlock ω (sliceBlockSet hrs π b) = true)).card
        decide (r ≤ 2 * k_pass))).card : ℝ) /
      ((2 : ℝ) ^ (M * W₁ + (2 * s₁) * W₂)) := by
  classical
  set r : ℕ := m / s₀
  have hrs : r * s₀ ≤ m := Nat.div_mul_le_self m s₀
  obtain ⟨hm512, hs1_1, hs1_le_s0, _, h64rs, hrs1_lt,
    hp_pr, hp26, hp_lt_m, hm_lt_p2, ha1, ha_lt_p, hqnr_z⟩ := polyPerm_arith hs₁ hs₀_ge hm
  have hm1 : 1 ≤ m := by omega
  have hr1 : 1 ≤ r := by
    have : 2 * s₀ / s₀ ≤ m / s₀ := Nat.div_le_div_right hm
    rw [Nat.mul_div_cancel _ (by omega)] at this
    omega
  let p_pr := firstPrimeIn (qOfM m)
  let a_qnr := firstQnr p_pr
  have hp_pos : 0 < p_pr := by omega
  haveI : NeZero p_pr := ⟨hp_pos.ne'⟩
  haveI : Fact p_pr.Prime := ⟨hp_pr⟩
  let K := QuadExt p_pr a_qnr
  letI : Field K := QuadExt.mkField hqnr_z
  haveI : Nonempty K := ⟨0⟩
  let eK : K ≃ Fin (p_pr * p_pr) := QuadExt.equivFin p_pr a_qnr
  let padIdx : K → Fin m := fun y => ⟨(eK y).1 % m, Nat.mod_lt _ hm1⟩
  let Q_pad : K → EuclideanSpace ℝ (Fin D) := fun y => Q_lift (padIdx y)
  -- Phase 1 bound on `V₁ := Fin M → Fin W₁ → Bool`
  let Good1 : Finset (Fin M → Fin m) := Finset.univ.filter (fun ω => goodSample ω = true)
  let V1Good : Finset (Fin M → Fin W₁ → Bool) :=
    Finset.univ.filter (fun v1 =>
      (fun j : Fin M => (⟨bitsToNat W₁ (v1 j) % m, Nat.mod_lt _ hm1⟩ : Fin m)) ∈ Good1)
  have hp1 := mod_draw_prob_ge (t := M) (W := W₁) (m := m) hM hm1
    (L := fun _ => m) (fun _ => hm1) (fun _ => le_rfl)
    ((Nat.le_mul_of_pos_left (M * m) (by norm_num : 0 < 64)).trans hW₁) Good1
  have hprod1 : (∏ _j : Fin M, (m : ℝ)) = (Fintype.card (Fin M → Fin m) : ℝ) := by
    simp [Fintype.card_pi]
  rw [hprod1] at hp1
  have htail1 : (63 / 64 : ℝ) ≤ 1 - ((M * m : ℕ) : ℝ) / (2 ^ W₁ : ℝ) := by
    have hpow_pos : (0 : ℝ) < (2 ^ W₁ : ℝ) := by positivity
    have h64 : 64 * ((M * m : ℕ) : ℝ) ≤ (2 ^ W₁ : ℝ) := by exact_mod_cast hW₁
    have hdiv : ((M * m : ℕ) : ℝ) / (2 ^ W₁ : ℝ) ≤ 1 / 64 := by
      rw [div_le_iff₀ hpow_pos]; linarith
    linarith
  have hv1_lb : (567 / 640 : ℝ) ≤ (V1Good.card : ℝ) / ((2 ^ W₁ : ℝ) ^ M) := by
    have hmul : (9 / 10 : ℝ) * (63 / 64) ≤
        ((Good1.card : ℝ) / (Fintype.card (Fin M → Fin m) : ℝ)) *
          (1 - ((M * m : ℕ) : ℝ) / (2 ^ W₁ : ℝ)) :=
      mul_le_mul hGoodSample htail1 (by norm_num) (by positivity)
    linarith
  -- Per-block ≥ 9/10 bound over uniform `c : Fin s₁ → K` when `ω ∈ Good1`
  have hblk_prob : ∀ (ω : Fin M → Fin m), ω ∈ Good1 → ∀ b : Fin r,
      9 / 10 ≤
        ((Finset.univ.filter (fun c : Fin s₁ → K =>
          passBlock ω (sliceBlockSet hrs (permOfCoeffs hs₁ hs₀_ge hm c) b) = true)).card : ℝ) /
        (Fintype.card (Fin s₁ → K) : ℝ) := by
    intro ω hω b
    have hcp : IsCenterpoint α₀ Q_lift (zPt ω) :=
      hGoodCP ω (Finset.mem_filter.mp hω).2
    have hcp_pad : IsCenterpoint (α₀ / 2) Q_pad (zPt ω) :=
      isCenterpoint_half_pad hD hm1 hm_lt_p2 eK hα0 hcp
    let evalPt : Fin (r * s₁) → K := fun t =>
      QuadExt.decodeFin p_pr a_qnr ⟨t.1, lt_trans t.2 (lt_trans hrs1_lt hm_lt_p2)⟩
    have hinj_evalPt : Function.Injective evalPt := by
      intro t₁ t₂ heq
      have hfin := eK.symm.injective heq
      have hv := congrArg Fin.val hfin
      dsimp only at hv
      exact Fin.ext hv
    let pts_b : Fin s₁ → K := fun j => evalPt ⟨b.1 * s₁ + j.1, coreIdxLt b j⟩
    have hinj_pts_b : Function.Injective pts_b := by
      intro j₁ j₂ heq
      have ht := hinj_evalPt heq
      have hv : b.1 * s₁ + j₁.1 = b.1 * s₁ + j₂.1 := congrArg Fin.val ht
      exact Fin.ext (by omega)
    let evalEquiv : (Fin s₁ → K) ≃ (Fin s₁ → K) :=
      Equiv.ofBijective _ (evalPoly_pts_bijective hs1_1 hinj_pts_b)
    let N_nat : ℕ := Fintype.card (Fin s₁ → K)
    let N_real : ℝ := (N_nat : ℝ)
    have hN_pos : 0 < N_real := by dsimp [N_real, N_nat]; exact_mod_cast Fintype.card_pos (α := Fin s₁ → K)
    -- 1. Net failure count `≤ (1 / 16) * N_real`
    let NetGood : Finset (Fin s₁ → K) :=
      Finset.univ.filter (fun c : Fin s₁ → K => IsIndexedHalfspaceNet (α₀ / 2) Q_pad (evalEquiv c))
    let NetBad : Finset (Fin s₁ → K) :=
      Finset.univ.filter (fun c : Fin s₁ → K => ¬ IsIndexedHalfspaceNet (α₀ / 2) Q_pad (evalEquiv c))
    have hNetGood_card :
        NetGood.card =
          (Finset.univ.filter (fun sample : Fin s₁ → K =>
            IsIndexedHalfspaceNet (α₀ / 2) Q_pad sample)).card := by
      refine Finset.card_bij (fun c _ => evalEquiv c) ?_ (fun _ _ _ _ h => evalEquiv.injective h) ?_
      · intro c hc; exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hc).2⟩
      · intro s hs
        refine ⟨evalEquiv.symm s, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, evalEquiv.apply_symm_apply s⟩
        rw [evalEquiv.apply_symm_apply]; exact (Finset.mem_filter.mp hs).2
    have hhw := hHW_s₁ K Q_pad
    rw [← hNetGood_card] at hhw
    have hNet_sum : NetGood.card + NetBad.card = N_nat := by
      have h := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset (Fin s₁ → K)))
        (fun c => IsIndexedHalfspaceNet (α₀ / 2) Q_pad (evalEquiv c))
      simpa [NetGood, NetBad, N_nat] using h
    have hNetBad_le : (NetBad.card : ℝ) ≤ (1 / 16) * N_real := by
      have h1 := (le_div_iff₀ hN_pos).mp hhw
      have h2 : (NetGood.card : ℝ) + (NetBad.card : ℝ) = N_real := by dsimp [N_real]; exact_mod_cast hNet_sum
      linarith
    -- 2. Collision failure count `≤ (1 / 32) * N_real`
    let CoreBad : Finset (Fin s₁ → K) :=
      Finset.univ.filter (fun c : Fin s₁ → K => ¬ (coreGood (gHatOfCoeffs hs₁ hs₀_ge hm c) b = true))
    let Pairs : Finset (Fin s₁ × Fin (r * s₁)) :=
      Finset.univ.filter (fun jt => jt.2.1 ≠ b.1 * s₁ + jt.1.1)
    have hCoreBad_sub :
        CoreBad ⊆ Pairs.biUnion (fun jt =>
          Finset.univ.filter (fun c : Fin s₁ → K =>
            gHatOfCoeffs hs₁ hs₀_ge hm c ⟨b.1 * s₁ + jt.1.1, coreIdxLt b jt.1⟩ =
              gHatOfCoeffs hs₁ hs₀_ge hm c jt.2)) := by
      intro c hc
      have hnot : ¬ (coreGood (gHatOfCoeffs hs₁ hs₀_ge hm c) b = true) := (Finset.mem_filter.mp hc).2
      unfold coreGood at hnot
      rw [decide_eq_true_eq] at hnot
      push_neg at hnot
      obtain ⟨j, hj_ne1⟩ := hnot
      let t₀ : Fin (r * s₁) := ⟨b.1 * s₁ + j.1, coreIdxLt b j⟩
      let Fib : Finset (Fin (r * s₁)) :=
        Finset.univ.filter (fun t => gHatOfCoeffs hs₁ hs₀_ge hm c t = gHatOfCoeffs hs₁ hs₀_ge hm c t₀)
      have ht₀_mem : t₀ ∈ Fib := Finset.mem_filter.mpr ⟨Finset.mem_univ _, rfl⟩
      have hpos_fib : 1 ≤ Fib.card := Finset.card_pos.mpr ⟨t₀, ht₀_mem⟩
      have hgt1 : 1 < Fib.card := lt_of_le_of_ne hpos_fib (Ne.symm hj_ne1)
      obtain ⟨t, ht_mem, ht_ne⟩ := Finset.exists_mem_ne hgt1 t₀
      have ht_val_ne : t.1 ≠ b.1 * s₁ + j.1 := fun hv => ht_ne (Fin.ext hv)
      rw [Finset.mem_biUnion]
      exact ⟨(j, t), Finset.mem_filter.mpr ⟨Finset.mem_univ _, ht_val_ne⟩,
        Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp ht_mem).2.symm⟩⟩
    have hCoreBad_nat : 32 * CoreBad.card ≤ N_nat := by
      have hbi : CoreBad.card ≤
          ∑ jt ∈ Pairs, (Finset.univ.filter (fun c : Fin s₁ → K =>
            gHatOfCoeffs hs₁ hs₀_ge hm c ⟨b.1 * s₁ + jt.1.1, coreIdxLt b jt.1⟩ =
              gHatOfCoeffs hs₁ hs₀_ge hm c jt.2)).card :=
        (Finset.card_le_card hCoreBad_sub).trans Finset.card_biUnion_le
      have hm_sum : m * CoreBad.card ≤ Pairs.card * (2 * N_nat) := by
        calc m * CoreBad.card
            ≤ m * ∑ jt ∈ Pairs, (Finset.univ.filter (fun c : Fin s₁ → K =>
                gHatOfCoeffs hs₁ hs₀_ge hm c ⟨b.1 * s₁ + jt.1.1, coreIdxLt b jt.1⟩ =
                  gHatOfCoeffs hs₁ hs₀_ge hm c jt.2)).card := Nat.mul_le_mul_left m hbi
          _ = ∑ jt ∈ Pairs, m * (Finset.univ.filter (fun c : Fin s₁ → K =>
                gHatOfCoeffs hs₁ hs₀_ge hm c ⟨b.1 * s₁ + jt.1.1, coreIdxLt b jt.1⟩ =
                  gHatOfCoeffs hs₁ hs₀_ge hm c jt.2)).card := Finset.mul_sum _ _ _
          _ ≤ ∑ _jt ∈ Pairs, (2 * N_nat) := by
              refine Finset.sum_le_sum fun jt hjt => ?_
              have hne_val : jt.2.1 ≠ b.1 * s₁ + jt.1.1 := (Finset.mem_filter.mp hjt).2
              let t₁ : Fin (r * s₁) := ⟨b.1 * s₁ + jt.1.1, coreIdxLt b jt.1⟩
              have ht_ne : t₁ ≠ jt.2 := fun h => hne_val (congrArg Fin.val h).symm
              have hx_ne : evalPt t₁ ≠ evalPt jt.2 := fun h => ht_ne (hinj_evalPt h)
              have hfeq : Finset.univ.filter (fun c : Fin s₁ → K =>
                  gHatOfCoeffs hs₁ hs₀_ge hm c t₁ = gHatOfCoeffs hs₁ hs₀_ge hm c jt.2) =
                  Finset.univ.filter (fun c : Fin s₁ → K =>
                    (eK (evalPoly c (evalPt t₁))).1 % m = (eK (evalPoly c (evalPt jt.2))).1 % m) := by
                ext c
                simp only [Finset.mem_filter, Finset.mem_univ, true_and, gHatOfCoeffs, Fin.ext_iff]
                rfl
              rw [hfeq]
              exact pair_mod_collision_card_le hm1 hm_lt_p2 eK hs₁ hx_ne
          _ = Pairs.card * (2 * N_nat) := by simp
      have hPairs_le : Pairs.card ≤ r * s₁ ^ 2 := by
        calc Pairs.card ≤ (Finset.univ : Finset (Fin s₁ × Fin (r * s₁))).card :=
              Finset.card_le_card (Finset.filter_subset _ _)
          _ = s₁ * (r * s₁) := by simp
          _ = r * s₁ ^ 2 := by ring
      have h1 : m * (32 * CoreBad.card) ≤ m * N_nat := by
        calc m * (32 * CoreBad.card)
            = 32 * (m * CoreBad.card) := by ring
          _ ≤ 32 * (Pairs.card * (2 * N_nat)) := Nat.mul_le_mul_left 32 hm_sum
          _ ≤ 32 * ((r * s₁ ^ 2) * (2 * N_nat)) :=
              Nat.mul_le_mul_left 32 (Nat.mul_le_mul_right _ hPairs_le)
          _ = (64 * (r * s₁ ^ 2)) * N_nat := by ring
          _ ≤ m * N_nat := Nat.mul_le_mul_right N_nat h64rs
      exact Nat.le_of_mul_le_mul_left h1 (by omega)
    have hCoreBad_le : (CoreBad.card : ℝ) ≤ (1 / 32) * N_real := by
      have hr : 32 * (CoreBad.card : ℝ) ≤ N_real := by dsimp [N_real]; exact_mod_cast hCoreBad_nat
      linarith
    -- 3. Every `c` outside `NetBad ∪ CoreBad` passes block `b`
    let FailSet : Finset (Fin s₁ → K) :=
      Finset.univ.filter (fun c : Fin s₁ → K =>
        ¬ (passBlock ω (sliceBlockSet hrs (permOfCoeffs hs₁ hs₀_ge hm c) b) = true))
    have hFail_sub : FailSet ⊆ NetBad ∪ CoreBad := by
      intro c hc
      by_contra hnot_u
      rw [Finset.mem_union, not_or] at hnot_u
      have hnet_idx : IsIndexedHalfspaceNet (α₀ / 2) Q_pad (evalEquiv c) := by
        by_contra hn; exact hnot_u.1 (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hn⟩)
      have hgood_b : coreGood (gHatOfCoeffs hs₁ hs₀_ge hm c) b = true := by
        by_contra hn; exact hnot_u.2 (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hn⟩)
      have hnet_set : IsHalfspaceNet (α₀ / 2) Q_pad (Finset.univ.image (evalEquiv c)) := by
        intro H hH_cl hH_cnt
        obtain ⟨j, hjH⟩ := hnet_idx H hH_cl hH_cnt
        exact ⟨evalEquiv c j, Finset.mem_image_of_mem _ (Finset.mem_univ j), hjH⟩
      have hcert := centerpoint_and_net_imp_hasConvexHullCert hs1_1 hcp_pad hnet_set
      have hmem_pad := mem_convexHull_of_cert hcert
      have hsub_range :
          Set.range (fun j : Fin s₁ => Q_pad (evalEquiv c j)) ⊆
            Q_lift '' (sliceBlockSet hrs (permOfCoeffs hs₁ hs₀_ge hm c) b : Set (Fin m)) := by
        rintro _ ⟨j, rfl⟩
        refine ⟨gHatOfCoeffs hs₁ hs₀_ge hm c ⟨b.1 * s₁ + j.1, coreIdxLt b j⟩, ?_, rfl⟩
        exact coreFillPerm_mem_sliceBlockSet hs1_1 hs1_le_s0 hrs _ hgood_b j
      have hmem_slice := convexHull_mono hsub_range hmem_pad
      have hpass := hPassSpec ω _ hmem_slice
      exact (Finset.mem_filter.mp hc).2 hpass
    have hFail_le : (FailSet.card : ℝ) ≤ (3 / 32) * N_real := by
      have hcard_u : (FailSet.card : ℝ) ≤ (NetBad.card : ℝ) + (CoreBad.card : ℝ) := by
        exact_mod_cast (Finset.card_le_card hFail_sub).trans (Finset.card_union_le _ _)
      linarith
    let PassSet : Finset (Fin s₁ → K) :=
      Finset.univ.filter (fun c : Fin s₁ → K =>
        passBlock ω (sliceBlockSet hrs (permOfCoeffs hs₁ hs₀_ge hm c) b) = true)
    have hPF_sum : (PassSet.card : ℝ) + (FailSet.card : ℝ) = N_real := by
      have h := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset (Fin s₁ → K)))
        (fun c => passBlock ω (sliceBlockSet hrs (permOfCoeffs hs₁ hs₀_ge hm c) b) = true)
      rw [Finset.card_univ] at h
      dsimp [PassSet, FailSet, N_real, N_nat]
      exact_mod_cast h
    rw [le_div_iff₀ hN_pos]
    dsimp [PassSet, N_real, N_nat] at hPF_sum hFail_le ⊢
    linarith
  -- Phase 2 bound for each fixed `ω ∈ Good1` over `V₂ := Fin (2 * s₁) → Fin W₂ → Bool`
  have hv2_lb : ∀ ω : Fin M → Fin m, ω ∈ Good1 →
      (504 / 640 : ℝ) ≤
        ((Finset.univ.filter (fun v2 : Fin (2 * s₁) → Fin W₂ → Bool =>
          r ≤ 2 * (Finset.univ.filter (fun b : Fin r =>
            passBlock ω (sliceBlockSet hrs (permOfPolyBits hs₁ hs₀_ge hm v2) b) = true)).card)).card : ℝ) /
        ((2 ^ W₂ : ℝ) ^ (2 * s₁)) := by
    intro ω hω
    let eRaw := coeffsEquivRaw p_pr a_qnr s₁
    haveI : Nonempty (Fin (2 * s₁) → Fin p_pr) := ⟨fun _ => ⟨0, hp_pos⟩⟩
    have hblk_raw : ∀ b : Fin r,
        9 / 10 ≤
          ((Finset.univ.filter (fun raw : Fin (2 * s₁) → Fin p_pr =>
            passBlock ω (sliceBlockSet hrs (permOfCoeffs hs₁ hs₀_ge hm (eRaw raw)) b) = true)).card : ℝ) /
          (Fintype.card (Fin (2 * s₁) → Fin p_pr) : ℝ) := by
      intro b
      have h1 := hblk_prob ω hω b
      have hcard_dom : Fintype.card (Fin (2 * s₁) → Fin p_pr) = Fintype.card (Fin s₁ → K) :=
        Fintype.card_congr eRaw
      have hcard_f :
          (Finset.univ.filter (fun raw : Fin (2 * s₁) → Fin p_pr =>
            passBlock ω (sliceBlockSet hrs (permOfCoeffs hs₁ hs₀_ge hm (eRaw raw)) b) = true)).card =
          (Finset.univ.filter (fun c : Fin s₁ → K =>
            passBlock ω (sliceBlockSet hrs (permOfCoeffs hs₁ hs₀_ge hm c) b) = true)).card := by
        refine Finset.card_bij (fun raw _ => eRaw raw) ?_ (fun _ _ _ _ h => eRaw.injective h) ?_
        · intro raw hrw; exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hrw).2⟩
        · intro c hc
          refine ⟨eRaw.symm c, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, eRaw.apply_symm_apply c⟩
          rw [eRaw.apply_symm_apply]; exact (Finset.mem_filter.mp hc).2
      rwa [hcard_f, hcard_dom]
    have hmarkov := markov_half_blocks_pass hr1
      (fun (raw : Fin (2 * s₁) → Fin p_pr) (b : Fin r) =>
        passBlock ω (sliceBlockSet hrs (permOfCoeffs hs₁ hs₀_ge hm (eRaw raw)) b))
      hblk_raw
    let GoodRaw : Finset (Fin (2 * s₁) → Fin p_pr) :=
      Finset.univ.filter (fun raw =>
        r ≤ 2 * (Finset.univ.filter (fun b : Fin r =>
          passBlock ω (sliceBlockSet hrs (permOfCoeffs hs₁ hs₀_ge hm (eRaw raw)) b) = true)).card)
    have h2s_le_m : 2 * s₁ ≤ m := by nlinarith
    have h64_2sm : 64 * ((2 * s₁) * m) ≤ 2 ^ W₂ :=
      (Nat.mul_le_mul_left 64 (Nat.mul_le_mul_right m h2s_le_m)).trans hW₂
    have hp2 := mod_draw_prob_ge (t := 2 * s₁) (W := W₂) (m := m) (by omega) hm1
      (L := fun _ => p_pr) (fun _ => hp_pos) (fun _ => le_of_lt hp_lt_m)
      ((Nat.le_mul_of_pos_left ((2 * s₁) * m) (by norm_num : 0 < 64)).trans h64_2sm)
      GoodRaw
    have hprod2 : (∏ _i : Fin (2 * s₁), (p_pr : ℝ)) = (Fintype.card (Fin (2 * s₁) → Fin p_pr) : ℝ) := by
      simp [Fintype.card_pi]
    rw [hprod2] at hp2
    have htail2 : (63 / 64 : ℝ) ≤ 1 - (((2 * s₁) * m : ℕ) : ℝ) / (2 ^ W₂ : ℝ) := by
      have hpow_pos : (0 : ℝ) < (2 ^ W₂ : ℝ) := by positivity
      have h64 : 64 * (((2 * s₁) * m : ℕ) : ℝ) ≤ (2 ^ W₂ : ℝ) := by exact_mod_cast h64_2sm
      have hdiv : (((2 * s₁) * m : ℕ) : ℝ) / (2 ^ W₂ : ℝ) ≤ 1 / 64 := by
        rw [div_le_iff₀ hpow_pos]; linarith
      linarith
    have hmul : (4 / 5 : ℝ) * (63 / 64) ≤
        ((GoodRaw.card : ℝ) / (Fintype.card (Fin (2 * s₁) → Fin p_pr) : ℝ)) *
          (1 - (((2 * s₁) * m : ℕ) : ℝ) / (2 ^ W₂ : ℝ)) :=
      mul_le_mul hmarkov htail2 (by norm_num) (by positivity)
    have hfilt_card :
        (Finset.univ.filter (fun v2 : Fin (2 * s₁) → Fin W₂ → Bool =>
          (fun i : Fin (2 * s₁) => (⟨bitsToNat W₂ (v2 i) % p_pr, Nat.mod_lt _ hp_pos⟩ : Fin p_pr)) ∈ GoodRaw)).card =
        (Finset.univ.filter (fun v2 : Fin (2 * s₁) → Fin W₂ → Bool =>
          r ≤ 2 * (Finset.univ.filter (fun b : Fin r =>
            passBlock ω (sliceBlockSet hrs (permOfPolyBits hs₁ hs₀_ge hm v2) b) = true)).card)).card := by
      congr 1
      refine Finset.filter_congr fun v2 _ => ?_
      simp only [GoodRaw, Finset.mem_filter, Finset.mem_univ, true_and]
      rfl
    rw [hfilt_card] at hp2
    linarith
  -- Combine `V₁` and `V₂` via `splitAttemptBits_bijective`
  let eSplit := Equiv.ofBijective _ (splitAttemptBits_bijective M W₁ (2 * s₁) W₂)
  let V2GoodOf : (Fin M → Fin W₁ → Bool) → Finset (Fin (2 * s₁) → Fin W₂ → Bool) := fun v1 =>
    let ω : Fin M → Fin m := fun j => ⟨bitsToNat W₁ (v1 j) % m, Nat.mod_lt _ hm1⟩
    Finset.univ.filter (fun v2 =>
      r ≤ 2 * (Finset.univ.filter (fun b : Fin r =>
        passBlock ω (sliceBlockSet hrs (permOfPolyBits hs₁ hs₀_ge hm v2) b) = true)).card)
  let TotalGood : Finset (Fin (M * W₁ + (2 * s₁) * W₂) → Bool) :=
    Finset.univ.filter (fun v =>
      let sp := splitAttemptBits M W₁ (2 * s₁) W₂ v
      let ω : Fin M → Fin m := fun j => ⟨bitsToNat W₁ (sp.1 j) % m, Nat.mod_lt _ hm1⟩
      let π := permOfPolyBits hs₁ hs₀_ge hm sp.2
      let k_pass := (Finset.univ.filter (fun b : Fin r =>
        passBlock ω (sliceBlockSet hrs π b) = true)).card
      decide (r ≤ 2 * k_pass) = true)
  have hsub_prod :
      (V1Good.sigma V2GoodOf).image (fun p => eSplit.symm (p.1, p.2)) ⊆ TotalGood := by
    intro v hv
    rcases Finset.mem_image.mp hv with ⟨⟨v1, v2⟩, hmem, rfl⟩
    have hv2 := (Finset.mem_sigma.mp hmem).2
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
    have hsp : splitAttemptBits M W₁ (2 * s₁) W₂ (eSplit.symm (v1, v2)) = (v1, v2) :=
      eSplit.apply_symm_apply (v1, v2)
    dsimp only
    rw [hsp, decide_eq_true_eq]
    exact (Finset.mem_filter.mp hv2).2
  have hinj_sig : Function.Injective (fun p : Σ _ : Fin M → Fin W₁ → Bool, Fin (2 * s₁) → Fin W₂ → Bool =>
      eSplit.symm (p.1, p.2)) := by
    rintro ⟨a₁, b₁⟩ ⟨a₂, b₂⟩ heq
    have hp := eSplit.symm.injective heq
    injection hp with ha hb
    subst ha; subst hb; rfl
  have hcard_tot_ge :
      (∑ v1 ∈ V1Good, ((V2GoodOf v1).card : ℝ)) ≤ (TotalGood.card : ℝ) := by
    have hc := Finset.card_le_card hsub_prod
    rw [Finset.card_image_of_injective _ hinj_sig, Finset.card_sigma] at hc
    exact_mod_cast hc
  have hsum_v2 :
      (V1Good.card : ℝ) * ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ (2 * s₁))) ≤
        ∑ v1 ∈ V1Good, ((V2GoodOf v1).card : ℝ) := by
    calc (V1Good.card : ℝ) * ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ (2 * s₁)))
        = ∑ _v1 ∈ V1Good, ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ (2 * s₁))) := by simp
      _ ≤ ∑ v1 ∈ V1Good, ((V2GoodOf v1).card : ℝ) := by
          refine Finset.sum_le_sum fun v1 hv1 => ?_
          have hω : (fun j : Fin M => (⟨bitsToNat W₁ (v1 j) % m, Nat.mod_lt _ hm1⟩ : Fin m)) ∈ Good1 :=
            (Finset.mem_filter.mp hv1).2
          have hb2 := hv2_lb _ hω
          exact (le_div_iff₀ (by positivity)).mp hb2
  have hden_pos : (0 : ℝ) < (2 : ℝ) ^ (M * W₁ + (2 * s₁) * W₂) := by positivity
  have hden_eq : ((2 : ℝ) ^ (M * W₁ + (2 * s₁) * W₂)) =
      ((2 ^ W₁ : ℝ) ^ M) * ((2 ^ W₂ : ℝ) ^ (2 * s₁)) := by
    rw [pow_add, mul_comm M W₁, pow_mul, mul_comm (2 * s₁) W₂, pow_mul]
  have hv1_mul : (567 / 640 : ℝ) * ((2 ^ W₁ : ℝ) ^ M) ≤ (V1Good.card : ℝ) :=
    (le_div_iff₀ (by positivity)).mp hv1_lb
  rw [le_div_iff₀ hden_pos]
  have hprod_lb :
      (1 / 2 : ℝ) * ((2 : ℝ) ^ (M * W₁ + (2 * s₁) * W₂)) ≤
        (V1Good.card : ℝ) * ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ (2 * s₁))) := by
    rw [hden_eq]
    have h1 : (1 / 2 : ℝ) ≤ (567 / 640) * (504 / 640) := by norm_num
    calc (1 / 2 : ℝ) * (((2 ^ W₁ : ℝ) ^ M) * ((2 ^ W₂ : ℝ) ^ (2 * s₁)))
        ≤ ((567 / 640 : ℝ) * (504 / 640)) * (((2 ^ W₁ : ℝ) ^ M) * ((2 ^ W₂ : ℝ) ^ (2 * s₁))) :=
          mul_le_mul_of_nonneg_right h1 (by positivity)
      _ = ((567 / 640 : ℝ) * ((2 ^ W₁ : ℝ) ^ M)) * ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ (2 * s₁))) := by ring
      _ ≤ (V1Good.card : ℝ) * ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ (2 * s₁))) :=
          mul_le_mul_of_nonneg_right hv1_mul (by positivity)
  exact hprod_lb.trans (hsum_v2.trans hcard_tot_ge)

end UL.Proof_lem_A_2
