import Mathlib
import UL.Proof.lem_A_2.ExactA_Phase4a1
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 1600000

namespace UL.Proof_lem_A_2

theorem exec_wl_reg19 {d A V : ℕ} {inp : BitRAMInput d}
    {ws : WordStore} {bs : List Bool}
    (var : ℕ) (idx : ℤ) (valE : IntExpr) {val : ℤ}
    (harena : InAttemptArena A V ws)
    (hinp : ArenaInputOK A V inp)
    (hval_eq : evalVal inp ws valE = val)
    (hvalV : intBitLength val ≤ V)
    (hok : decide (var < 100 ∧ 0 ≤ idx ∧ idx < 16 ∧ exprOkSyntax valE = true ∧
      exprMaxLitAbs valE ≤ 64 ∧ exprNodes valE ≤ 19) = true := by decide) :
    InAttemptArena A V (ws.write (.localFrame 1 var idx) val) ∧
    ExecBounded inp (.writeLocal var (.lit idx) valE) ws bs
      (ws.write (.localFrame 1 var idx) val) bs
      68 (66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have h := of_decide_eq_true hok
  have hV16 : 16 ≤ V := by have := hinp.2.1; omega
  have h16A : 16 ≤ A := hinp.1
  have hidx_V : ExprInArena V (.lit idx) :=
    exprInArena_small (e := .lit idx) rfl
      (by dsimp [exprMaxLitAbs]; omega) hV16
  exact exec_writeLocal_auto19 harena hinp hidx_V
    (exprInArena_small h.2.2.2.1 h.2.2.2.2.1 hV16)
    ⟨by simp [exprNodes], h.2.2.2.2.2⟩
    rfl hval_eq h.1 h.2.1 (by omega) hvalV

/-! ### 3. Substage B: Draw `2 * s₁` modular values into `var 20 [0 .. 2 * s₁ - 1]` -/

def p4bDrawBody : BitRAMStmt :=
  .seq (drawBitsStmt 13 3 4)
  (.seq (.writeLocal 20 (.readLocal 11 (.lit 0))
          (.mod (.readLocal 1 (.lit 3)) (.readLocal 10 (.lit 5))))
        (.writeLocal 11 (.lit 0) (.add (.readLocal 11 (.lit 0)) (.lit 1))))

def p4bDrawStmt : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 0) (.lit 0))
       (.repeatN (.readLocal 10 (.lit 1)) p4bDrawBody)

theorem exec_p4bDrawStmt {A V M K₀ deg_α₀ : ℕ} (p : CoreParams)
    (f_poly : Fin (2 * s₁Val K₀ deg_α₀ p.d) → Fin p.W₂ → Bool) (restBits : List Bool)
    {inp : BitRAMInput p.d} {ws₁ : WordStore}
    (hK₀ : 1 ≤ K₀)
    (hpK : p.K = 25 * K₀ ^ 2)
    (hpdeg : p.deg_α = 2 * deg_α₀ + 1)
    (harena : InAttemptArena A V ws₁)
    (hregs : HasPhase2Regs p M ws₁)
    (hcst : HasP4Consts p K₀ deg_α₀ ws₁)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p) :
    let s₁ := s₁Val K₀ deg_α₀ p.d
    let p_pr := firstPrimeIn (qOfM p.m)
    ∃ ws₂ : WordStore,
      InAttemptArena A V ws₂ ∧
      PreserveOutside4 ws₁ ws₂ ∧
      HasPhase2Regs p M ws₂ ∧
      HasP4Consts p K₀ deg_α₀ ws₂ ∧
      (∀ i : Fin (2 * s₁),
        ws₂.read (.localFrame 1 20 (i.1 : ℤ)) = ((bitsToNat p.W₂ (f_poly i) % p_pr : ℕ) : ℤ)) ∧
      ExecBounded inp p4bDrawStmt
        ws₁ (blockBitStream f_poly restBits 0) ws₂ restBits
        (200 + (2 * s₁) * (300 + 24 * (p.W₂ + 1)))
        ((200000 + 500000 * p.m) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  intro s₁ p_pr
  have hs₁_2 : 2 ≤ s₁ := by have := s₁Val_ge_144 (deg_α := deg_α₀) hK₀ p.d; omega
  have hs₀_ge : 64 * s₁ ^ 2 ≤ p.s₀ := by
    dsimp [CoreParams.s₀, s₁]; rw [hpK, hpdeg]; exact sixtyFour_s₁Val_sq_le_s₀Val hK₀ p.d
  have hm2s : 2 * p.s₀ ≤ p.m := hfit.2.2.2.1
  obtain ⟨hm512, _, _, _, _, _, _, hp26, hp_lt_m, _, _, _, _⟩ :=
    polyPerm_arith_core p hs₁_2 hs₀_ge hm2s
  have h2s_lt_m : 2 * s₁ < p.m := by nlinarith
  have hmA : 2 * p.m + 4 * p.D + 16 ≤ A := hfit.2.2.2.2.2.1
  have hwV : 2 * p.w + 32 ≤ V := hfit.2.2.2.2.2.2.2.2.1
  have h16A : 16 ≤ A := hinp.1
  have hV16 : 16 ≤ V := by have := hinp.2.1; omega
  have hib_2m : ∀ {x : ℕ}, x ≤ 2 * p.m → intBitLength (x : ℤ) ≤ V :=
    fun hx => ibl_le_V_of_le_four_m_sq (by omega) hwV (by nlinarith)
  obtain ⟨ha_i0, ex_i0⟩ := exec_wl_reg 11 0 (.lit 0) harena hinp (val := 0) rfl (ibl_zero_le hV16)
    (bs := blockBitStream f_poly restBits 0)
  have hp_i0 : PreserveOutside4 ws₁ (wsOf ha_i0) :=
    (preserveOutside4_refl ws₁).write_local 0 _ (Or.inr (Or.inr (by decide)))
  let InvDraw : ℕ → WordStore → List Bool → Prop := fun k ws_k bs_k =>
    k ≤ 2 * s₁ ∧
    bs_k = blockBitStream f_poly restBits k ∧
    InAttemptArena A V ws_k ∧
    PreserveOutside4 ws₁ ws_k ∧
    HasP4Consts p K₀ deg_α₀ ws_k ∧
    ws_k.read (.localFrame 1 11 0) = (k : ℤ) ∧
    (∀ i : Fin (2 * s₁), i.1 < k →
      ws_k.read (.localFrame 1 20 (i.1 : ℤ)) = ((bitsToNat p.W₂ (f_poly i) % p_pr : ℕ) : ℤ))
  have hInvDraw0 : InvDraw 0 (wsOf ha_i0) (blockBitStream f_poly restBits 0) :=
    ⟨Nat.zero_le _, rfl, ha_i0, hp_i0,
     hasP4Consts_of_eq hcst (fun _ => rw_local_var_ne _ (by decide)),
     wordStore_read_write_self _ _ _,
     fun _ h => by omega⟩
  obtain ⟨wsEnd, bsEnd, hInvEnd, ex_loop⟩ := exec_repeatN_inv
    (bs₀ := blockBitStream f_poly restBits 0)
    (U := 200 + 24 * (p.W₂ + 1)) (B := 400000 * (V + 8) ^ 2)
    (countE := .readLocal 10 (.lit 1)) (body := p4bDrawBody) (2 * s₁) InvDraw ha_i0 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by simp [wsOf, rw_write_eq, hcst.2.1]; rfl)
    hInvDraw0
    (fun k ws_k bs_k hk hInv_k => by
      rcases hInv_k with ⟨_, rfl, ha_k, hp_k, hcst_k, hr11_0, hdone_k⟩
      have hrW2 : ws_k.read (.localFrame 1 0 13) = (p.W₂ : ℤ) :=
        (hp_k.2 0 13 (by decide) (by decide) (by decide)).trans hregs.1.2.2.2.2.2.2.2.2.2.2.2.1
      have hW2_V : p.W₂ + 4 ≤ V := by dsimp [CoreParams.W₂]; omega
      let fk := f_poly ⟨k, hk⟩
      let bsNext := blockBitStream f_poly restBits (k + 1)
      have hbs_step := blockBitStream_step f_poly restBits hk
      obtain ⟨wsD, ha_d, hr_d, hoth_d, ex_d⟩ :=
        exec_drawBitsStmt (inp := inp) (wIdx := 13) (accIdx := 3) (bitIdx := 4)
          fk bsNext ha_k (by decide)
          ⟨by decide, by decide, by decide, by decide, by decide, by decide, h16A⟩
          hrW2 hW2_V
      rw [← hbs_step] at ex_d
      have hp_d : PreserveOutside4 ws₁ wsD :=
        ⟨fun t idx => (hoth_d _ (by intro h; nomatch h) (by intro h; nomatch h)).trans (hp_k.1 t idx),
         fun v idx hv1 hv5 hv10 =>
           (hoth_d _ (by intro h; injection h with _ hv _; exact hv1 hv)
                     (by intro h; injection h with _ hv _; exact hv1 hv)).trans
             (hp_k.2 v idx hv1 hv5 hv10)⟩
      have hcst_d : HasP4Consts p K₀ deg_α₀ wsD :=
        hasP4Consts_of_eq hcst_k (fun idx =>
          hoth_d _ (by intro h; nomatch h) (by intro h; nomatch h))
      have hr11_d : wsD.read (.localFrame 1 11 0) = (k : ℤ) :=
        (hoth_d _ (by intro h; nomatch h) (by intro h; nomatch h)).trans hr11_0
      let rval := bitsToNat p.W₂ fk % p_pr
      obtain ⟨ha_w20, ex_w20⟩ := exec_wl ha_d hinp
        (var := 20) (idxE := .readLocal 11 (.lit 0)) (idx := (k : ℤ))
        (valE := .mod (.readLocal 1 (.lit 3)) (.readLocal 10 (.lit 5)))
        (val := (rval : ℤ))
        (bs := bsNext)
        (by simp [hr11_d])
        (by simp only [evalVal_mod, evalVal_readLocal, evalVal_lit, hr_d, hcst_d.2.2.2.2.2.1]
            exact (Int.natCast_emod _ _).symm)
        (by positivity)
        (by rw [Int.toNat_natCast]; omega)
        (hib_2m (by have : rval < p_pr := Nat.mod_lt _ (by omega); omega))
      obtain ⟨ha_inc, ex_inc⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) ha_w20 hinp (val := ((k + 1 : ℕ) : ℤ))
        (bs := bsNext)
        (by simp [wsOf, rw_write_eq, hr11_d]; try (push_cast; ring))
        (hib_2m (by omega))
      have hb_draw : 64 * (p.W₂ + 16) ^ 2 ≤ 256 * (V + 8) ^ 2 := by
        have h1 : p.W₂ + 16 ≤ 2 * (V + 8) := by dsimp [CoreParams.W₂]; omega
        calc 64 * (p.W₂ + 16) ^ 2 ≤ 64 * (2 * (V + 8)) ^ 2 :=
              Nat.mul_le_mul_left 64 (Nat.pow_le_pow_left h1 2)
          _ = 256 * (V + 8) ^ 2 := by ring
      refine ⟨wsOf ha_inc, bsNext, ⟨hk, rfl, ha_inc,
        (hp_d.write_local (k : ℤ) _ (Or.inr (Or.inr (by decide)))).write_local
          0 _ (Or.inr (Or.inr (by decide))),
        hasP4Consts_of_eq hcst_d (fun _ => by simp [wsOf, rw_write_eq]),
        wordStore_read_write_self _ _ _,
        fun i hi => by
          rw [rw_local_var_ne _ (by decide)]
          rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hi) with hlt | heq
          · have hne : (i.1 : ℤ) ≠ (k : ℤ) := by omega
            rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hh; exact hne hh),
                hoth_d _ (by intro h; nomatch h) (by intro h; nomatch h)]
            exact hdone_k i hlt
          · have hi_eq : i = ⟨k, hk⟩ := Fin.ext heq
            subst hi_eq
            exact wordStore_read_write_self _ _ _⟩,
        ExecBounded.mono (ExecBounded.seq ex_d (ExecBounded.seq ex_w20 ex_inc))
          (by omega)
          (by refine (Nat.add_le_add_right hb_draw _).trans ?_
              simp only [← Nat.mul_assoc, ← Nat.add_mul]
              apply Nat.mul_le_mul_right; omega)
          le_rfl le_rfl⟩)
  rcases hInvEnd with ⟨_, hbs_end, ha2, hp2, hcst2, _, hraw2⟩
  rw [blockBitStream_self] at hbs_end
  subst bsEnd
  refine ⟨wsEnd, ha2, hp2,
    hasPhase2Regs_of_eq hregs (fun idx => hp2.2 0 idx (by decide) (by decide) (by decide)),
    hcst2, fun i => hraw2 i i.2,
    ExecBounded.mono (ExecBounded.seq ex_i0 ex_loop)
      (by have : (2 * s₁) * (200 + 24 * (p.W₂ + 1)) ≤ (2 * s₁) * (300 + 24 * (p.W₂ + 1)) :=
            Nat.mul_le_mul_left _ (by omega); omega)
      ?_ le_rfl le_rfl⟩
  simp only [← Nat.mul_assoc, ← Nat.add_mul]
  apply Nat.mul_le_mul_right
  have hmul : (2 * s₁) * 400000 ≤ p.m * 400000 := Nat.mul_le_mul_right 400000 (le_of_lt h2s_lt_m)
  omega

/-! ### 4. Substage C: Horner evaluation into `var 21 [0 .. r * s₁ - 1]` -/

def p4cHornerInnerBody : BitRAMStmt :=
  .seq (.writeLocal 12 (.lit 0)
          (.sub (.sub (.readLocal 10 (.lit 0)) (.lit 1)) (.readLocal 11 (.lit 5))))
  (.seq (.writeLocal 12 (.lit 1)
          (.readLocal 20 (.mul (.lit 2) (.readLocal 12 (.lit 0)))))
  (.seq (.writeLocal 12 (.lit 2)
          (.readLocal 20 (.add (.mul (.lit 2) (.readLocal 12 (.lit 0))) (.lit 1))))
  (.seq (.writeLocal 12 (.lit 3)
          (.mod (.mul (.readLocal 10 (.lit 6)) (.readLocal 11 (.lit 4)))
                (.readLocal 10 (.lit 5))))
  (.seq (.writeLocal 12 (.lit 4)
          (.mod (.add (.add (.mul (.readLocal 11 (.lit 3)) (.readLocal 11 (.lit 1)))
                            (.mul (.readLocal 12 (.lit 3)) (.readLocal 11 (.lit 2))))
                      (.readLocal 12 (.lit 1)))
                (.readLocal 10 (.lit 5))))
  (.seq (.writeLocal 12 (.lit 5)
          (.mod (.add (.add (.mul (.readLocal 11 (.lit 3)) (.readLocal 11 (.lit 2)))
                            (.mul (.readLocal 11 (.lit 4)) (.readLocal 11 (.lit 1))))
                      (.readLocal 12 (.lit 2)))
                (.readLocal 10 (.lit 5))))
  (.seq (.writeLocal 11 (.lit 3) (.readLocal 12 (.lit 4)))
  (.seq (.writeLocal 11 (.lit 4) (.readLocal 12 (.lit 5)))
        (.writeLocal 11 (.lit 5) (.add (.readLocal 11 (.lit 5)) (.lit 1))))))))))

def p4cHornerOuterBody : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 1) (.mod (.readLocal 11 (.lit 0)) (.readLocal 10 (.lit 5))))
  (.seq (.writeLocal 11 (.lit 2) (.div (.readLocal 11 (.lit 0)) (.readLocal 10 (.lit 5))))
  (.seq (.writeLocal 11 (.lit 3) (.lit 0))
  (.seq (.writeLocal 11 (.lit 4) (.lit 0))
  (.seq (.writeLocal 11 (.lit 5) (.lit 0))
  (.seq (.repeatN (.readLocal 10 (.lit 0)) p4cHornerInnerBody)
  (.seq (.writeLocal 21 (.readLocal 11 (.lit 0))
          (.mod (.add (.readLocal 11 (.lit 3))
                      (.mul (.readLocal 10 (.lit 5)) (.readLocal 11 (.lit 4))))
                (.readLocal 0 (.lit 2))))
        (.writeLocal 11 (.lit 0) (.add (.readLocal 11 (.lit 0)) (.lit 1)))))))))

def p4cHornerStmt : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 0) (.lit 0))
       (.repeatN (.readLocal 10 (.lit 2)) p4cHornerOuterBody)

theorem exec_p4cHornerStmt {A V M K₀ deg_α₀ : ℕ} (p : CoreParams)
    (f_poly : Fin (2 * s₁Val K₀ deg_α₀ p.d) → Fin p.W₂ → Bool)
    {inp : BitRAMInput p.d} {ws₂ : WordStore} {bs : List Bool}
    (hK₀ : 1 ≤ K₀)
    (hpK : p.K = 25 * K₀ ^ 2)
    (hpdeg : p.deg_α = 2 * deg_α₀ + 1)
    (harena : InAttemptArena A V ws₂)
    (hregs : HasPhase2Regs p M ws₂)
    (hcst : HasP4Consts p K₀ deg_α₀ ws₂)
    (hraw : ∀ i : Fin (2 * s₁Val K₀ deg_α₀ p.d),
      ws₂.read (.localFrame 1 20 (i.1 : ℤ)) =
        ((bitsToNat p.W₂ (f_poly i) % firstPrimeIn (qOfM p.m) : ℕ) : ℤ))
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p) :
    let s₁ := s₁Val K₀ deg_α₀ p.d
    have hs₁_2 : 2 ≤ s₁ := by have := s₁Val_ge_144 (deg_α := deg_α₀) hK₀ p.d; omega
    have hs₀_ge : 64 * s₁ ^ 2 ≤ p.s₀ := by
      dsimp [CoreParams.s₀, s₁]; rw [hpK, hpdeg]; exact sixtyFour_s₁Val_sq_le_s₀Val hK₀ p.d
    have hm2s : 2 * p.s₀ ≤ p.m := hfit.2.2.2.1
    let p_pr := firstPrimeIn (qOfM p.m)
    let a_qnr := firstQnr p_pr
    have hp_pos : 0 < p_pr := by
      have := (polyPerm_arith hs₁_2 hs₀_ge hm2s).2.2.2.2.2.2.2.1; omega
    haveI : NeZero p_pr := ⟨hp_pos.ne'⟩
    let raw : Fin (2 * s₁) → Fin p_pr := fun i =>
      ⟨bitsToNat p.W₂ (f_poly i) % p_pr, Nat.mod_lt _ hp_pos⟩
    let c := coeffsEquivRaw p_pr a_qnr s₁ raw
    let g_hat := gHatOfCoeffs hs₁_2 hs₀_ge hm2s c
    ∃ ws₃ : WordStore,
      InAttemptArena A V ws₃ ∧
      PreserveOutside4 ws₂ ws₃ ∧
      HasPhase2Regs p M ws₃ ∧
      HasP4Consts p K₀ deg_α₀ ws₃ ∧
      (∀ t : Fin (p.r * s₁), ws₃.read (.localFrame 1 21 (t.1 : ℤ)) = ((g_hat t).1 : ℤ)) ∧
      ExecBounded inp p4cHornerStmt ws₂ bs ws₃ bs
        (200 + 2000 * p.m)
        ((200000 + 2000000 * p.m) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  dsimp only
  let s₁ := s₁Val K₀ deg_α₀ p.d
  have hs₁_2 : 2 ≤ s₁ := by have := s₁Val_ge_144 (deg_α := deg_α₀) hK₀ p.d; omega
  have hs₀_ge : 64 * s₁ ^ 2 ≤ p.s₀ := by
    dsimp [CoreParams.s₀, s₁]; rw [hpK, hpdeg]; exact sixtyFour_s₁Val_sq_le_s₀Val hK₀ p.d
  have hm2s : 2 * p.s₀ ≤ p.m := hfit.2.2.2.1
  obtain ⟨hm512, hs₁_1, _, _, h64rs, hrs1_lt, _, hp26, hp_lt_m, hm_lt_p2, _, ha_lt_p, _⟩ :=
    polyPerm_arith_core p hs₁_2 hs₀_ge hm2s
  let p_pr := firstPrimeIn (qOfM p.m)
  let a_qnr := firstQnr p_pr
  have hp_pos : 0 < p_pr := by omega
  letI : NeZero p_pr := ⟨hp_pos.ne'⟩
  let raw : Fin (2 * s₁) → Fin p_pr := fun i =>
    ⟨bitsToNat p.W₂ (f_poly i) % p_pr, Nat.mod_lt _ hp_pos⟩
  let c := coeffsEquivRaw p_pr a_qnr s₁ raw
  let g_hat := gHatOfCoeffs hs₁_2 hs₀_ge hm2s c
  have h2s1_lt_m : 2 * s₁ < p.m := by nlinarith
  have hmA : 2 * p.m + 4 * p.D + 16 ≤ A := hfit.2.2.2.2.2.1
  have hwV : 2 * p.w + 32 ≤ V := hfit.2.2.2.2.2.2.2.2.1
  have hV16 : 16 ≤ V := by have := hinp.2.1; omega
  have hib_2m : ∀ {x : ℕ}, x ≤ 2 * p.m → intBitLength (x : ℤ) ≤ V :=
    fun hx => ibl_le_V_of_le_four_m_sq (by omega) hwV (by nlinarith)
  obtain ⟨ha_t0, ex_t0⟩ := exec_wl_reg 11 0 (.lit 0) harena hinp (val := 0) rfl (ibl_zero_le hV16)
  have hp_t0 : PreserveOutside4 ws₂ (wsOf ha_t0) :=
    (preserveOutside4_refl ws₂).write_local 0 _ (Or.inr (Or.inr (by decide)))
  let InvOut : ℕ → WordStore → List Bool → Prop := fun t ws_t bs_t =>
    bs_t = bs ∧
    InAttemptArena A V ws_t ∧
    PreserveOutside4 ws₂ ws_t ∧
    HasP4Consts p K₀ deg_α₀ ws_t ∧
    (∀ i : Fin (2 * s₁), ws_t.read (.localFrame 1 20 (i.1 : ℤ)) = ((raw i).1 : ℤ)) ∧
    ws_t.read (.localFrame 1 11 0) = (t : ℤ) ∧
    (∀ u : Fin (p.r * s₁), u.1 < t → ws_t.read (.localFrame 1 21 (u.1 : ℤ)) = ((g_hat u).1 : ℤ))
  have hInvOut0 : InvOut 0 (wsOf ha_t0) bs :=
    ⟨rfl, ha_t0, hp_t0,
     hasP4Consts_of_eq hcst (fun _ => rw_local_var_ne _ (by decide)),
     fun i => (rw_local_var_ne _ (by decide)).trans (hraw i),
     wordStore_read_write_self _ _ _,
     fun _ h => by omega⟩
  have hrs_eq : p.r = p.m / p.s₀ := rfl
  obtain ⟨wsEnd, bsEnd, hInvEnd, ex_out⟩ := exec_repeatN_inv (bs₀ := bs)
    (U := 600 + 612 * s₁) (B := (600000 + 594000 * s₁) * (V + 8) ^ 2)
    (countE := .readLocal 10 (.lit 2)) (body := p4cHornerOuterBody) (p.r * s₁) InvOut ha_t0 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by simp only [evalVal_readLocal, evalVal_lit]; rw [rw_local_var_ne _ (by decide), hcst.2.2.1])
    hInvOut0
    (fun t ws_t bs_t ht hInv_t => by
      rcases hInv_t with ⟨hbs_t, ha_t, hp_t, hcst_t, h20_t, hr11_0, h21_t⟩; subst bs_t
      let tFin : Fin (p.r * s₁) := ⟨t, ht⟩
      let x_t : QuadExt p_pr a_qnr :=
        QuadExt.decodeFin p_pr a_qnr ⟨t, lt_trans ht (lt_trans hrs1_lt hm_lt_p2)⟩
      have hx_re : x_t.re.val = t % p_pr :=
        ZMod.val_natCast_of_lt (Nat.mod_lt t hp_pos)
      have hx_im : x_t.im.val = t / p_pr :=
        ZMod.val_natCast_of_lt (Nat.div_lt_of_lt_mul (by linarith [lt_trans ht (lt_trans hrs1_lt hm_lt_p2)]))
      obtain ⟨ha_1, ex_1⟩ := exec_wl_reg 11 1 (.mod (.readLocal 11 (.lit 0)) (.readLocal 10 (.lit 5))) ha_t hinp (val := ((t % p_pr : ℕ) : ℤ))
        (by simp only [evalVal_mod, evalVal_readLocal, evalVal_lit, hr11_0, hcst_t.2.2.2.2.2.1]
            exact (Int.natCast_emod t p_pr).symm)
        (hib_2m (by have := Nat.mod_lt t hp_pos; omega))
      obtain ⟨ha_2, ex_2⟩ := exec_wl_reg 11 2 (.div (.readLocal 11 (.lit 0)) (.readLocal 10 (.lit 5))) ha_1 hinp (val := ((t / p_pr : ℕ) : ℤ))
        (by simp [wsOf, rw_write_eq, hr11_0, hcst_t.2.2.2.2.2.1]
            exact (Int.natCast_ediv t p_pr).symm)
        (hib_2m (by have : t / p_pr ≤ t := Nat.div_le_self _ _; omega))
      obtain ⟨ha_3, ex_3⟩ := exec_wl_reg 11 3 (.lit 0) ha_2 hinp (val := 0) rfl (ibl_zero_le hV16)
      obtain ⟨ha_4, ex_4⟩ := exec_wl_reg 11 4 (.lit 0) ha_3 hinp (val := 0) rfl (ibl_zero_le hV16)
      obtain ⟨ha_5, ex_5⟩ := exec_wl_reg 11 5 (.lit 0) ha_4 hinp (val := 0) rfl (ibl_zero_le hV16)
      have hp_5 : PreserveOutside4 ws₂ (wsOf ha_5) :=
        ((((hp_t.write_local 1 _ (Or.inr (Or.inr (by decide)))).write_local
           2 _ (Or.inr (Or.inr (by decide)))).write_local
           3 _ (Or.inr (Or.inr (by decide)))).write_local
           4 _ (Or.inr (Or.inr (by decide)))).write_local
           5 _ (Or.inr (Or.inr (by decide)))
      let InvH : ℕ → WordStore → List Bool → Prop := fun stp ws_s bs_s =>
        bs_s = bs ∧
        InAttemptArena A V ws_s ∧
        PreserveOutside4 ws₂ ws_s ∧
        HasP4Consts p K₀ deg_α₀ ws_s ∧
        (∀ i : Fin (2 * s₁), ws_s.read (.localFrame 1 20 (i.1 : ℤ)) = ((raw i).1 : ℤ)) ∧
        (∀ u : Fin (p.r * s₁), u.1 < t → ws_s.read (.localFrame 1 21 (u.1 : ℤ)) = ((g_hat u).1 : ℤ)) ∧
        ws_s.read (.localFrame 1 11 0) = (t : ℤ) ∧
        ws_s.read (.localFrame 1 11 1) = (x_t.re.val : ℤ) ∧
        ws_s.read (.localFrame 1 11 2) = (x_t.im.val : ℤ) ∧
        ws_s.read (.localFrame 1 11 3) = ((hornerIter c x_t stp).re.val : ℤ) ∧
        ws_s.read (.localFrame 1 11 4) = ((hornerIter c x_t stp).im.val : ℤ) ∧
        ws_s.read (.localFrame 1 11 5) = (stp : ℤ)
      have hInvH0 : InvH 0 (wsOf ha_5) bs := by
        refine ⟨rfl, ha_5, hp_5,
          hasP4Consts_of_eq hcst_t (fun _ => by simp [wsOf, rw_write_eq]),
          fun i => by simp [wsOf, rw_write_eq, h20_t i],
          fun u hu => by simp [wsOf, rw_write_eq, h21_t u hu],
          by simp [wsOf, rw_write_eq, hr11_0],
          by simp [wsOf, rw_write_eq, hx_re],
          by simp [wsOf, rw_write_eq, hx_im],
          by simp [wsOf, rw_write_eq, hornerIter],
          by simp [wsOf, rw_write_eq, hornerIter],
          wordStore_read_write_self _ _ _⟩
      obtain ⟨wsH, bsH, hInvHEnd, ex_in⟩ := exec_repeatN_inv (bs₀ := bs)
        (U := 612) (B := 594000 * (V + 8) ^ 2)
        (countE := .readLocal 10 (.lit 0)) (body := p4cHornerInnerBody) s₁ InvH ha_5 hinp
        (exprInArena_small (by decide) (by decide) hV16) (by decide)
        (by simp only [wsOf, evalVal_readLocal, evalVal_lit, rw_local_var_ne _ (by decide : 10 ≠ 11)]; exact hcst_t.1)
        hInvH0
        (fun stp ws_s bs_s hstp hInv_s => by
          rcases hInv_s with ⟨hbs_s, ha_s, hp_s, hcst_s, h20_s, h21_s, h11_0, h11_1, h11_2, h11_3, h11_4, h11_5⟩; subst bs_s
          let kIdx : Fin s₁ := ⟨s₁ - 1 - stp, by omega⟩
          let ck := c kIdx
          have hck_re : ck.re.val = (raw ⟨2 * kIdx.1, by omega⟩).1 :=
            ZMod.val_natCast_of_lt (raw _).2
          have hck_im : ck.im.val = (raw ⟨2 * kIdx.1 + 1, by omega⟩).1 :=
            ZMod.val_natCast_of_lt (raw _).2
          let acc := hornerIter c x_t stp
          obtain ⟨hre_step, him_step⟩ := QuadExt.mul_add_val_eq acc x_t ck
          obtain ⟨ha_k0, ex_k0⟩ := exec_wl_reg (bs := bs) 12 0 (.sub (.sub (.readLocal 10 (.lit 0)) (.lit 1)) (.readLocal 11 (.lit 5))) ha_s hinp (val := (kIdx.1 : ℤ))
            (by simp [hcst_s.1, h11_5, kIdx]; try omega) (hib_2m (by have := kIdx.2; omega))
          obtain ⟨ha_k1, ex_k1⟩ := exec_wl_reg 12 1 (.readLocal 20 (.mul (.lit 2) (.readLocal 12 (.lit 0)))) ha_k0 hinp (val := (ck.re.val : ℤ))
            (by simp only [wsOf, evalVal_readLocal, evalVal_mul, evalVal_lit, wordStore_read_write_self,
                  rw_local_var_ne _ (by decide : 20 ≠ 12)]
                have h2k : ((2 : ℤ) * (kIdx.1 : ℤ)) = ((((2 * kIdx.1 : ℕ) : ℤ))) := by push_cast; ring
                rw [h2k, h20_s ⟨2 * kIdx.1, by omega⟩, hck_re])
            (hib_2m (by have := ck.re.val_lt; omega))
          obtain ⟨ha_k2, ex_k2⟩ := exec_wl_reg 12 2 (.readLocal 20 (.add (.mul (.lit 2) (.readLocal 12 (.lit 0))) (.lit 1))) ha_k1 hinp (val := (ck.im.val : ℤ))
            (by simp only [wsOf, evalVal_readLocal, evalVal_add, evalVal_mul, evalVal_lit,
                  wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 12 0 ≠ .localFrame 1 12 1),
                  wordStore_read_write_self,
                  rw_local_var_ne _ (by decide : 20 ≠ 12)]
                have h2k1 : ((2 : ℤ) * (kIdx.1 : ℤ) + 1) = ((((2 * kIdx.1 + 1 : ℕ) : ℤ))) := by push_cast; ring
                rw [h2k1, h20_s ⟨2 * kIdx.1 + 1, by omega⟩, hck_im])
            (hib_2m (by have := ck.im.val_lt; omega))
          let aim := (a_qnr * acc.im.val) % p_pr
          obtain ⟨ha_k3, ex_k3⟩ := exec_wl_reg 12 3 (.mod (.mul (.readLocal 10 (.lit 6)) (.readLocal 11 (.lit 4))) (.readLocal 10 (.lit 5))) ha_k2 hinp (val := (aim : ℤ))
            (by simp only [wsOf, evalVal_mod, evalVal_mul, evalVal_readLocal, evalVal_lit,
                  rw_local_var_ne _ (by decide : 10 ≠ 12),
                  rw_local_var_ne _ (by decide : 11 ≠ 12),
                  hcst_s.2.2.2.2.2.2.1, hcst_s.2.2.2.2.2.1, h11_4]
                have hm : ((a_qnr : ℤ) * (acc.im.val : ℤ)) = (((a_qnr * acc.im.val : ℕ) : ℤ)) := by push_cast; ring
                rw [hm, ← Int.natCast_emod])
            (hib_2m (by have : aim < p_pr := Nat.mod_lt _ hp_pos; omega))
          obtain ⟨ha_k4, ex_k4⟩ := exec_wl_reg19 12 4 (.mod (.add (.add (.mul (.readLocal 11 (.lit 3)) (.readLocal 11 (.lit 1))) (.mul (.readLocal 12 (.lit 3)) (.readLocal 11 (.lit 2)))) (.readLocal 12 (.lit 1))) (.readLocal 10 (.lit 5))) ha_k3 hinp (val := ((acc * x_t + ck).re.val : ℤ))
            (by simp only [wsOf, evalVal_mod, evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit,
                  rw_local_var_ne _ (by decide : 10 ≠ 12),
                  rw_local_var_ne _ (by decide : 11 ≠ 12),
                  wordStore_read_write_self,
                  wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 12 1 ≠ .localFrame 1 12 3),
                  wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 12 1 ≠ .localFrame 1 12 2),
                  h11_3, h11_1, h11_2, hcst_s.2.2.2.2.2.1]
                dsimp only [acc, p_pr] at hre_step ⊢
                rw [hre_step]
                have hcast : ((acc.re.val : ℤ) * (x_t.re.val : ℤ) + (aim : ℤ) * (x_t.im.val : ℤ) + (ck.re.val : ℤ)) =
                    (((acc.re.val * x_t.re.val + aim * x_t.im.val + ck.re.val : ℕ) : ℤ)) := by push_cast; ring
                rw [hcast, ← Int.natCast_emod])
            (hib_2m (by have := (acc * x_t + ck).re.val_lt; omega))
          obtain ⟨ha_k5, ex_k5⟩ := exec_wl_reg19 12 5 (.mod (.add (.add (.mul (.readLocal 11 (.lit 3)) (.readLocal 11 (.lit 2))) (.mul (.readLocal 11 (.lit 4)) (.readLocal 11 (.lit 1)))) (.readLocal 12 (.lit 2))) (.readLocal 10 (.lit 5))) ha_k4 hinp (val := ((acc * x_t + ck).im.val : ℤ))
            (by simp only [wsOf, evalVal_mod, evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit,
                  rw_local_var_ne _ (by decide : 10 ≠ 12),
                  rw_local_var_ne _ (by decide : 11 ≠ 12),
                  wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 12 2 ≠ .localFrame 1 12 4),
                  wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 12 2 ≠ .localFrame 1 12 3),
                  wordStore_read_write_self,
                  h11_3, h11_4, h11_1, h11_2, hcst_s.2.2.2.2.2.1]
                dsimp only [acc, p_pr] at him_step ⊢
                rw [him_step]
                have hcast : ((acc.re.val : ℤ) * (x_t.im.val : ℤ) + (acc.im.val : ℤ) * (x_t.re.val : ℤ) + (ck.im.val : ℤ)) =
                    (((acc.re.val * x_t.im.val + acc.im.val * x_t.re.val + ck.im.val : ℕ) : ℤ)) := by push_cast; ring
                rw [hcast, ← Int.natCast_emod])
            (hib_2m (by have := (acc * x_t + ck).im.val_lt; omega))
          obtain ⟨ha_u3, ex_u3⟩ := exec_wl_reg 11 3 (.readLocal 12 (.lit 4)) ha_k5 hinp (val := ((acc * x_t + ck).re.val : ℤ))
            (by simp [wsOf, rw_write_eq])
            (hib_2m (by have := (acc * x_t + ck).re.val_lt; omega))
          obtain ⟨ha_u4, ex_u4⟩ := exec_wl_reg 11 4 (.readLocal 12 (.lit 5)) ha_u3 hinp (val := ((acc * x_t + ck).im.val : ℤ))
            (by simp [wsOf, rw_write_eq])
            (hib_2m (by have := (acc * x_t + ck).im.val_lt; omega))
          obtain ⟨ha_u5, ex_u5⟩ := exec_wl_reg 11 5 (.add (.readLocal 11 (.lit 5)) (.lit 1)) ha_u4 hinp (val := ((stp + 1 : ℕ) : ℤ))
            (by simp [wsOf, rw_write_eq, h11_5]; try (push_cast; ring))
            (hib_2m (by omega))
          have hp_next : PreserveOutside4 ws₂ (wsOf ha_u5) := by
            iterate 9 apply PreserveOutside4.write_local _ _ _ (Or.inr (Or.inr (by decide)))
            exact hp_s
          have hh_succ : hornerIter c x_t (stp + 1) = acc * x_t + ck := by
            simp [hornerIter, hstp, acc, ck, kIdx]
          have ex_hstep :=
            ExecBounded.seq ex_k0 (ExecBounded.seq ex_k1 (ExecBounded.seq ex_k2
            (ExecBounded.seq ex_k3 (ExecBounded.seq ex_k4 (ExecBounded.seq ex_k5
            (ExecBounded.seq ex_u3 (ExecBounded.seq ex_u4 ex_u5)))))))
          refine ⟨wsOf ha_u5, bs, ⟨rfl, ha_u5, hp_next,
            hasP4Consts_of_eq hcst_s (fun _ => by simp [wsOf, rw_write_eq]),
            fun i => by simp [wsOf, rw_write_eq, h20_s i],
            fun u hu => by simp [wsOf, rw_write_eq, h21_s u hu],
            by simp [wsOf, rw_write_eq, h11_0],
            by simp [wsOf, rw_write_eq, h11_1],
            by simp [wsOf, rw_write_eq, h11_2],
            by simp [wsOf, rw_write_eq, hh_succ],
            by simp [wsOf, rw_write_eq, hh_succ],
            wordStore_read_write_self _ _ _⟩,
            ExecBounded.mono ex_hstep (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩)
      rcases hInvHEnd with ⟨hbsH, haH, hpH, hcstH, h20H, h21H, h11_0H, _, _, h11_3H, h11_4H, _⟩; subst bsH
      rw [hornerIter_full] at h11_3H h11_4H
      have hg_val : ((evalPoly c x_t).re.val + p_pr * (evalPoly c x_t).im.val) % p.m = (g_hat tFin).1 := rfl
      have hm0_H : wsH.read (.localFrame 1 0 2) = (p.m : ℤ) :=
        (hpH.2 0 2 (by decide) (by decide) (by decide)).trans hregs.1.2.2.1
      obtain ⟨ha_w21, ex_w21⟩ := exec_wl haH hinp
        (var := 21) (idxE := .readLocal 11 (.lit 0)) (idx := (t : ℤ))
        (valE := .mod (.add (.readLocal 11 (.lit 3))
                            (.mul (.readLocal 10 (.lit 5)) (.readLocal 11 (.lit 4))))
                      (.readLocal 0 (.lit 2)))
        (val := ((g_hat tFin).1 : ℤ))
        (by simp [h11_0H])
        (by simp only [evalVal_mod, evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit,
              h11_3H, hcstH.2.2.2.2.2.1, h11_4H, hm0_H]
            have hcast : (((evalPoly c x_t).re.val : ℤ) + (p_pr : ℤ) * ((evalPoly c x_t).im.val : ℤ)) =
                ((((evalPoly c x_t).re.val + p_pr * (evalPoly c x_t).im.val : ℕ) : ℤ)) := by push_cast; ring
            rw [hcast, ← Int.natCast_emod, hg_val])
        (by positivity)
        (by rw [Int.toNat_natCast]; omega)
        (hib_2m (by have := (g_hat tFin).2; omega))
      obtain ⟨ha_inc, ex_inc⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) ha_w21 hinp (val := ((t + 1 : ℕ) : ℤ))
        (by simp [wsOf, rw_write_eq, h11_0H]; try (push_cast; ring))
        (hib_2m (by omega))
      have ex_ostep :=
        ExecBounded.seq ex_1 (ExecBounded.seq ex_2 (ExecBounded.seq ex_3
        (ExecBounded.seq ex_4 (ExecBounded.seq ex_5 (ExecBounded.seq ex_in
        (ExecBounded.seq ex_w21 ex_inc))))))
      refine ⟨wsOf ha_inc, bs, ⟨rfl, ha_inc,
        (hpH.write_local (t : ℤ) _ (Or.inr (Or.inr (by decide)))).write_local
          0 _ (Or.inr (Or.inr (by decide))),
        hasP4Consts_of_eq hcstH (fun _ => by simp [wsOf, rw_write_eq]),
        fun i => by simp [wsOf, rw_write_eq, h20H i],
        wordStore_read_write_self _ _ _,
        fun u hu => by
          rw [rw_local_var_ne _ (by decide)]
          rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hu) with hlt | heq
          · have hne : (u.1 : ℤ) ≠ (t : ℤ) := by omega
            rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hh; exact hne hh)]
            exact h21H u hlt
          · have hu_eq : u = tFin := Fin.ext heq
            subst hu_eq
            exact wordStore_read_write_self _ _ _⟩,
        ExecBounded.mono ex_ostep
          (show _ ≤ 600 + 612 * s₁ by omega)
          (show _ ≤ (600000 + 594000 * s₁) * (V + 8) ^ 2 by simp only [← Nat.mul_assoc, ← Nat.add_mul]; apply Nat.mul_le_mul_right; omega)
          le_rfl le_rfl⟩)
  rcases hInvEnd with ⟨hbsEnd, ha3, hp3, hcst3, _, _, h21_end⟩; subst bsEnd
  refine ⟨wsEnd, ha3, hp3,
    hasPhase2Regs_of_eq hregs (fun idx => hp3.2 0 idx (by decide) (by decide) (by decide)),
    hcst3, fun u => h21_end u u.2,
    ExecBounded.mono (ExecBounded.seq ex_t0 ex_out) ?_ ?_ le_rfl le_rfl⟩
  · -- Unit cost: `(p.r * s₁) * (600 + 612 * s₁) ≤ 2000 * p.m` since `64 * (p.r * s₁^2) ≤ p.m`!
    have : (p.r * s₁) * (600 + 612 * s₁) = 600 * (p.r * s₁) + 612 * (p.r * s₁ ^ 2) := by ring
    omega
  · -- Bit cost
    simp only [← Nat.mul_assoc, ← Nat.add_mul]
    apply Nat.mul_le_mul_right
    have : (p.r * s₁) * (600000 + 594000 * s₁) = 600000 * (p.r * s₁) + 594000 * (p.r * s₁ ^ 2) := by ring
    omega

end UL.Proof_lem_A_2
