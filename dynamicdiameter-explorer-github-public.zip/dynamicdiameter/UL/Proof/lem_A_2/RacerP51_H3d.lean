import Mathlib
import UL.Proof.lem_A_2.H1a_Math
import UL.Proof.lem_A_2.RacerP51_H3c
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 1200000

namespace UL.Proof_lem_A_2

@[reducible] def wsOf {A V : ℕ} {ws : WordStore} (_ : InAttemptArena A V ws) : WordStore := ws

theorem rw_write_eq (ws : WordStore) (loc₁ loc₂ : RAMCellLoc) (val : ℤ) :
    (ws.write loc₂ val).read loc₁ = if loc₁ = loc₂ then val else ws.read loc₁ := by
  by_cases h : loc₁ = loc₂
  · subst h; rw [if_pos rfl]; exact wordStore_read_write_self ws loc₁ val
  · rw [if_neg h]; exact wordStore_read_write_of_ne ws h val

theorem rf_free_eq (ws : WordStore) (loc₁ loc₂ : RAMCellLoc) :
    (ws.free loc₂).read loc₁ = if loc₁ = loc₂ then 0 else ws.read loc₁ := by
  by_cases h : loc₁ = loc₂
  · subst h; rw [if_pos rfl]; exact wordStore_read_free_self ws loc₁
  · rw [if_neg h]; exact wordStore_read_free_of_ne ws h

theorem rw_ne (ws : WordStore) {loc₁ loc₂ : RAMCellLoc} {v : ℤ}
    (hne : decide (loc₁ ≠ loc₂) = true := by decide) :
    (ws.write loc₂ v).read loc₁ = ws.read loc₁ :=
  wordStore_read_write_of_ne ws (of_decide_eq_true hne) v

theorem rf_ne (ws : WordStore) {loc₁ loc₂ : RAMCellLoc}
    (hne : decide (loc₁ ≠ loc₂) = true := by decide) :
    (ws.free loc₂).read loc₁ = ws.read loc₁ :=
  wordStore_read_free_of_ne ws (of_decide_eq_true hne)

theorem rw_heap_local (ws : WordStore) (t : ℕ) (idx : ℤ) (fd var : ℕ) (lidx val : ℤ) :
    (ws.write (.localFrame fd var lidx) val).read (.heap t idx) = ws.read (.heap t idx) :=
  wordStore_read_write_of_ne ws (by intro hc; nomatch hc) val

theorem rw_local_heap (ws : WordStore) (fd var : ℕ) (lidx : ℤ) (t : ℕ) (idx val : ℤ) :
    (ws.write (.heap t idx) val).read (.localFrame fd var lidx) = ws.read (.localFrame fd var lidx) :=
  wordStore_read_write_of_ne ws (by intro hc; nomatch hc) val

theorem rf_local_heap (ws : WordStore) (fd var : ℕ) (lidx : ℤ) (t : ℕ) (idx : ℤ) :
    (ws.free (.heap t idx)).read (.localFrame fd var lidx) = ws.read (.localFrame fd var lidx) :=
  wordStore_read_free_of_ne ws (by intro hc; nomatch hc)

theorem rw_local_var_ne (ws : WordStore) {fd v₁ v₂ : ℕ} {i₁ i₂ val : ℤ} (hne : v₁ ≠ v₂) :
    (ws.write (.localFrame fd v₂ i₂) val).read (.localFrame fd v₁ i₁) = ws.read (.localFrame fd v₁ i₁) :=
  wordStore_read_write_of_ne ws (by intro hc; injection hc with _ hv _; exact hne hv) val

theorem exec_writeLocal_auto19 {d A V : ℕ} {inp : BitRAMInput d}
    {ws : WordStore} {bs : List Bool}
    {var : ℕ} {idxE valE : IntExpr} {idx val : ℤ}
    (harena : InAttemptArena A V ws)
    (hinp : ArenaInputOK A V inp)
    (hin_idx : ExprInArena V idxE)
    (hin_val : ExprInArena V valE)
    (hnodes : exprNodes idxE ≤ 2 ∧ exprNodes valE ≤ 19)
    (hidx_eq : evalVal inp ws idxE = idx)
    (hval_eq : evalVal inp ws valE = val)
    (hvar : var < 100) (hidx0 : 0 ≤ idx) (hidxA : idx.toNat < A)
    (hvalV : intBitLength val ≤ V) :
    InAttemptArena A V (ws.write (.localFrame 1 var idx) val) ∧
    ExecBounded inp (.writeLocal var idxE valE) ws bs
      (ws.write (.localFrame 1 var idx) val) bs
      68 (66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have ha' := inAttemptArena_write_local harena hvar hidx0 hidxA hvalV
  have hsz' := inAttemptArena_size_le ha'
  obtain ⟨_, hu1, hb1⟩ := evalIntExpr_arena_bound harena hinp idxE hin_idx
  obtain ⟨_, hu2, hb2⟩ := evalIntExpr_arena_bound harena hinp valE hin_val
  rcases he1 : evalIntExpr inp 1 ws idxE with ⟨i₀, u₁, b₁⟩
  rcases he2 : evalIntExpr inp 1 ws valE with ⟨v₀, u₂, b₂⟩
  dsimp [evalVal] at hidx_eq hval_eq
  rw [he1] at hidx_eq hu1 hb1; rw [he2] at hval_eq hu2 hb2
  dsimp only at hidx_eq hval_eq hu1 hb1 hu2 hb2
  subst i₀; subst v₀
  have hb1_cap : b₁ ≤ 64 * (V + 8) ^ 2 :=
    hb1.trans (Nat.mul_le_mul_right _ (by
      have : (exprNodes idxE) ^ 3 ≤ 2 ^ 3 := Nat.pow_le_pow_left hnodes.1 3
      omega))
  have hb2_cap : b₂ ≤ 54872 * (V + 8) ^ 2 :=
    hb2.trans (Nat.mul_le_mul_right _ (by
      have : (exprNodes valE) ^ 3 ≤ 19 ^ 3 := Nat.pow_le_pow_left hnodes.2 3
      omega))
  have hloc_le : (RAMCellLoc.localFrame 1 var idx).bitLength + intBitLength val ≤
      464 * (V + 8) ^ 2 := by
    dsimp [RAMCellLoc.bitLength]
    have hn1 : natBitLength 1 = 1 := rfl
    have hv_b : natBitLength var ≤ 7 := (natBitLength_mono (le_of_lt hvar)).trans (by decide)
    have hi_b : intBitLength idx ≤ natBitLength A + 1 := by
      rw [← Int.toNat_of_nonneg hidx0]
      exact (intBitLength_natCast_le_succ idx.toNat).trans
        (Nat.add_le_add_right (natBitLength_mono (le_of_lt hidxA)) 1)
    have hVA := hinp.2.1
    have hlin : (1 + natBitLength var + intBitLength idx) + intBitLength val ≤ 2 * (V + 8) := by omega
    rw [sq]
    exact hlin.trans ((Nat.mul_le_mul_left 2 (Nat.le_mul_self (V + 8))).trans
      (Nat.mul_le_mul_right _ (by norm_num)))
  have hn_i := hnodes.1; have hn_v := hnodes.2
  refine ⟨ha', ExecBounded.writeLocal he1 he2 (by omega) (by omega)
    (Nat.add_le_add_left hsz'.1 _) (Nat.add_le_add_left hsz'.2 _)⟩

/-! ### 1. Automatic `ExprInArena`, invariant-driven `repeatN`, and core attempt registers -/

def exprMaxLitAbs : IntExpr → ℕ
  | .lit c => c.natAbs
  | .dim => 0
  | .intParam e | .extraRatNum e | .extraRatDen e | .neg e
  | .readHeap _ e | .readLocal _ e => exprMaxLitAbs e
  | .add e₁ e₂ | .sub e₁ e₂ | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ =>
      max (exprMaxLitAbs e₁) (exprMaxLitAbs e₂)

def exprOkSyntax : IntExpr → Bool
  | .lit _ | .dim => true
  | .intParam e | .extraRatNum e | .extraRatDen e | .neg e => exprOkSyntax e
  | .readHeap t e => decide (t < 8) && exprOkSyntax e
  | .readLocal var e => decide (var < 100) && exprOkSyntax e
  | .add e₁ e₂ | .sub e₁ e₂ | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ =>
      exprOkSyntax e₁ && exprOkSyntax e₂

theorem intBitLength_natCast_mono {a b : ℕ} (h : a ≤ b) :
    intBitLength (a : ℤ) ≤ intBitLength (b : ℤ) := by
  rcases Nat.eq_zero_or_pos a with rfl | ha
  · change 1 ≤ intBitLength (b : ℤ); exact intBitLength_pos _
  · have hb : 0 < b := lt_of_lt_of_le ha h
    unfold intBitLength
    rw [if_neg (by positivity), if_neg (by positivity), Int.natAbs_natCast, Int.natAbs_natCast]
    exact Nat.add_le_add_left (natBitLength_mono h) 1

theorem exprInArena_of_maxLit {V : ℕ} (hV1 : 1 ≤ V) :
    ∀ e : IntExpr,
      exprOkSyntax e = true →
      intBitLength ((exprMaxLitAbs e : ℕ) : ℤ) ≤ V →
      ExprInArena V e := by
  intro e
  induction e with
  | lit c =>
      intro _ hmax
      dsimp [ExprInArena, exprMaxLitAbs] at hmax ⊢
      unfold intBitLength at hmax ⊢
      by_cases hc : c = 0
      · subst hc; exact hV1
      · have hne : ((c.natAbs : ℕ) : ℤ) ≠ 0 := by exact_mod_cast Int.natAbs_ne_zero.mpr hc
        rw [if_neg hc]
        rw [if_neg hne, Int.natAbs_natCast] at hmax
        exact hmax
  | dim => intros; trivial
  | intParam e ih | extraRatNum e ih | extraRatDen e ih | neg e ih =>
      intro hs hm; exact ih hs hm
  | readHeap t e ih =>
      intro hs hm
      simp only [exprOkSyntax, Bool.and_eq_true, decide_eq_true_eq] at hs
      exact ⟨hs.1, ih hs.2 hm⟩
  | readLocal var e ih =>
      intro hs hm
      simp only [exprOkSyntax, Bool.and_eq_true, decide_eq_true_eq] at hs
      exact ⟨hs.1, ih hs.2 hm⟩
  | add e₁ e₂ ih₁ ih₂ | sub e₁ e₂ ih₁ ih₂ | mul e₁ e₂ ih₁ ih₂
  | div e₁ e₂ ih₁ ih₂ | mod e₁ e₂ ih₁ ih₂
  | activeRatNum e₁ e₂ ih₁ ih₂ | activeRatDen e₁ e₂ ih₁ ih₂ =>
      intro hs hm
      simp only [exprOkSyntax, Bool.and_eq_true] at hs
      dsimp [exprMaxLitAbs] at hm
      exact ⟨ih₁ hs.1 ((intBitLength_natCast_mono (le_max_left _ _)).trans hm),
             ih₂ hs.2 ((intBitLength_natCast_mono (le_max_right _ _)).trans hm)⟩

theorem exprInArena_small {V : ℕ} {e : IntExpr}
    (hs : exprOkSyntax e = true) (hmax : exprMaxLitAbs e ≤ 64) (hV : 16 ≤ V) :
    ExprInArena V e := by
  refine exprInArena_of_maxLit (by omega) e hs ?_
  have h1 := intBitLength_natCast_le_succ (exprMaxLitAbs e)
  have h2 : natBitLength (exprMaxLitAbs e) ≤ 7 := (natBitLength_mono hmax).trans (by decide)
  omega

theorem exec_repeatN_inv {d A V : ℕ} {inp : BitRAMInput d}
    {countE : IntExpr} {body : BitRAMStmt}
    (n : ℕ) (Inv : ℕ → WordStore → List Bool → Prop)
    {ws₀ : WordStore} {bs₀ : List Bool} {U B C S : ℕ}
    (harena0 : InAttemptArena A V ws₀)
    (hinp : ArenaInputOK A V inp)
    (hin_cnt : ExprInArena V countE)
    (hnodes : exprNodes countE ≤ 16)
    (hcnt_eq : evalVal inp ws₀ countE = (n : ℤ))
    (hinit : Inv 0 ws₀ bs₀)
    (hstep : ∀ (k : ℕ) (ws_k : WordStore) (bs_k : List Bool),
      k < n → Inv k ws_k bs_k →
      ∃ (ws_next : WordStore) (bs_next : List Bool),
        Inv (k + 1) ws_next bs_next ∧
        ExecBounded inp body ws_k bs_k ws_next bs_next U B C S) :
    ∃ (ws_n : WordStore) (bs_n : List Bool),
      Inv n ws_n bs_n ∧
      ExecBounded inp (.repeatN countE body) ws₀ bs₀ ws_n bs_n
        (68 + n * U) (66000 * (V + 8) ^ 2 + n * B) C S := by
  classical
  have hchain : ∀ k : ℕ, k ≤ n →
      ∃ (ws_k : WordStore) (bs_k : List Bool),
        (k = 0 → ws_k = ws₀ ∧ bs_k = bs₀) ∧
        Inv k ws_k bs_k ∧
        (∀ hk : k < n, ∃ ws_next bs_next,
          Inv (k + 1) ws_next bs_next ∧
          ExecBounded inp body ws_k bs_k ws_next bs_next U B C S) := by
    intro k
    induction k with
    | zero =>
        intro _
        exact ⟨ws₀, bs₀, fun _ => ⟨rfl, rfl⟩, hinit, fun hk => hstep 0 ws₀ bs₀ hk hinit⟩
    | succ k ih =>
        intro hk1
        obtain ⟨ws_k, bs_k, _, hinv_k, hnext_k⟩ := ih (le_of_lt hk1)
        obtain ⟨ws_next, bs_next, hinv_next, _⟩ := hnext_k hk1
        exact ⟨ws_next, bs_next, fun h => by omega, hinv_next,
          fun hk' => hstep (k + 1) ws_next bs_next hk' hinv_next⟩
  -- Build the concrete trajectory `seq : (k : ℕ) → { p : WordStore × List Bool // k ≤ n → Inv k p.1 p.2 }`
  let stepChoice (k : ℕ) (cur : WordStore × List Bool) : WordStore × List Bool :=
    if h : k < n ∧ Inv k cur.1 cur.2 then
      let ex := hstep k cur.1 cur.2 h.1 h.2
      (Classical.choose ex, Classical.choose (Classical.choose_spec ex))
    else cur
  let seq : ℕ → WordStore × List Bool := fun k => Nat.rec (ws₀, bs₀) stepChoice k
  have hseq_inv : ∀ k : ℕ, k ≤ n → Inv k (seq k).1 (seq k).2 := by
    intro k
    induction k with
    | zero => intro _; exact hinit
    | succ k ih =>
        intro hk1
        have hk_lt : k < n := hk1
        have hinv_k := ih (le_of_lt hk_lt)
        change Inv (k + 1) (stepChoice k (seq k)).1 (stepChoice k (seq k)).2
        dsimp only [stepChoice]
        rw [dif_pos ⟨hk_lt, hinv_k⟩]
        exact (Classical.choose_spec (Classical.choose_spec (hstep k (seq k).1 (seq k).2 hk_lt hinv_k))).1
  have hseq_exec : ∀ k : ℕ, k < n →
      ExecBounded inp body (seq k).1 (seq k).2 (seq (k + 1)).1 (seq (k + 1)).2 U B C S := by
    intro k hk_lt
    have hinv_k := hseq_inv k (le_of_lt hk_lt)
    change ExecBounded inp body (seq k).1 (seq k).2 (stepChoice k (seq k)).1 (stepChoice k (seq k)).2 U B C S
    dsimp only [stepChoice]
    rw [dif_pos ⟨hk_lt, hinv_k⟩]
    exact (Classical.choose_spec (Classical.choose_spec (hstep k (seq k).1 (seq k).2 hk_lt hinv_k))).2
  obtain ⟨_, hu, hb⟩ := evalIntExpr_arena_bound harena0 hinp countE hin_cnt
  rcases he : evalIntExpr inp 1 ws₀ countE with ⟨cnt₀, uc, bc⟩
  dsimp [evalVal] at hcnt_eq
  rw [he] at hcnt_eq hu hb
  dsimp only at hcnt_eq hu hb
  subst cnt₀
  have hb_cap : bc ≤ 32768 * (V + 8) ^ 2 :=
    hb.trans (Nat.mul_le_mul_right _ (by
      have : (exprNodes countE) ^ 3 ≤ 16 ^ 3 := Nat.pow_le_pow_left hnodes 3
      omega))
  have h1 : 1 ≤ (V + 8) ^ 2 := Nat.one_le_pow 2 _ (by have := hinp.2.1; omega)
  have hrep := ExecBounded.repeatN n (fun k => (seq k).1) (fun k => (seq k).2) he hseq_exec
  exact ⟨(seq n).1, (seq n).2, hseq_inv n le_rfl,
    ExecBounded.mono hrep (by omega) (by omega) le_rfl le_rfl⟩

structure CoreParams where
  d : ℕ
  m : ℕ
  B : ℕ
  K : ℕ
  deg_α : ℕ
  C_z : ℕ
  deg_alg : ℕ
  k_φ : ℕ

def CoreParams.D (p : CoreParams) : ℕ := p.d + 1
def CoreParams.B_lift (p : CoreParams) : ℕ := bLiftVal p.d p.B
def CoreParams.s₀ (p : CoreParams) : ℕ := s₀Val p.K p.deg_α p.d
def CoreParams.r (p : CoreParams) : ℕ := p.m / p.s₀
def CoreParams.w (p : CoreParams) : ℕ := Nat.clog 2 (2 * p.m)
def CoreParams.W₂ (p : CoreParams) : ℕ := 2 * p.w + 6
def CoreParams.L_z (p : CoreParams) : ℕ :=
  p.C_z * (p.D + 1) ^ p.deg_alg * (p.B_lift + 1) ^ p.deg_alg

def ParamFit (A V : ℕ) (p : CoreParams) : Prop :=
  1 ≤ p.K ∧ 1 ≤ p.B ∧ 1 ≤ p.C_z ∧ 2 * p.s₀ ≤ p.m ∧
  16 ≤ A ∧ 2 * p.m + 4 * p.D + 16 ≤ A ∧
  natBitLength A + 16 ≤ V ∧
  2 * p.B_lift + 16 ≤ V ∧
  2 * p.w + 32 ≤ V ∧
  intBitLength (p.s₀ : ℤ) ≤ V ∧
  intBitLength ((2 * p.deg_α + 1 : ℕ) : ℤ) ≤ V ∧
  intBitLength ((2 * p.L_z : ℕ) : ℤ) ≤ V ∧
  intBitLength (p.deg_alg : ℤ) ≤ V ∧
  intBitLength (p.k_φ : ℤ) ≤ V

def HeapAllZero (ws : WordStore) : Prop :=
  ∀ (t : ℕ) (idx : ℤ), ws.read (.heap t idx) = 0

theorem heapAllZero_empty : HeapAllZero WordStore.empty :=
  fun _ _ => rfl

theorem heapAllZero_of_eq_heap {ws ws' : WordStore} (h : HeapAllZero ws)
    (heq : ∀ t idx, ws'.read (.heap t idx) = ws.read (.heap t idx)) :
    HeapAllZero ws' :=
  fun t idx => (heq t idx).trans (h t idx)

theorem heapAllZero_write_local {ws : WordStore} (h : HeapAllZero ws)
    (fd var : ℕ) (idx val : ℤ) :
    HeapAllZero (ws.write (.localFrame fd var idx) val) :=
  fun t i => (wordStore_read_write_of_ne ws (by intro hc; nomatch hc) val).trans (h t i)

theorem heapAllZero_free {ws : WordStore} (h : HeapAllZero ws) (loc : RAMCellLoc) :
    HeapAllZero (ws.free loc) := by
  intro t idx
  by_cases heq : RAMCellLoc.heap t idx = loc
  · subst heq; simp [WordStore.read, WordStore.free]
  · rw [wordStore_read_free_of_ne ws heq]; exact h t idx

def HasPhase0Regs (p : CoreParams) (ws : WordStore) : Prop :=
  ws.read (.localFrame 1 0 0) = (p.d : ℤ) ∧
  ws.read (.localFrame 1 0 1) = (p.D : ℤ) ∧
  ws.read (.localFrame 1 0 2) = (p.m : ℤ) ∧
  ws.read (.localFrame 1 0 3) = (p.B : ℤ) ∧
  ws.read (.localFrame 1 0 4) = (p.B_lift : ℤ) ∧
  ws.read (.localFrame 1 0 5) = (p.s₀ : ℤ) ∧
  ws.read (.localFrame 1 0 6) = (p.r : ℤ) ∧
  ws.read (.localFrame 1 0 7) = (p.w : ℤ) ∧
  ws.read (.localFrame 1 0 8) = (p.L_z : ℤ) ∧
  ws.read (.localFrame 1 0 9) = ((2 * p.B_lift : ℕ) : ℤ) ∧
  ws.read (.localFrame 1 0 10) = ((2 * p.L_z : ℕ) : ℤ) ∧
  ws.read (.localFrame 1 0 13) = (p.W₂ : ℤ) ∧
  ws.read (.localFrame 1 0 14) = ((2 * p.D : ℕ) : ℤ) ∧
  ws.read (.localFrame 1 0 15) = ((2 * p.s₀ : ℕ) : ℤ)

theorem hasPhase0Regs_of_eq {p : CoreParams} {ws ws' : WordStore}
    (h : HasPhase0Regs p ws)
    (heq : ∀ idx : ℤ, idx ≠ 11 → idx ≠ 12 →
      ws'.read (.localFrame 1 0 idx) = ws.read (.localFrame 1 0 idx)) :
    HasPhase0Regs p ws' :=
  ⟨(heq 0 (by decide) (by decide)).trans h.1,
   (heq 1 (by decide) (by decide)).trans h.2.1,
   (heq 2 (by decide) (by decide)).trans h.2.2.1,
   (heq 3 (by decide) (by decide)).trans h.2.2.2.1,
   (heq 4 (by decide) (by decide)).trans h.2.2.2.2.1,
   (heq 5 (by decide) (by decide)).trans h.2.2.2.2.2.1,
   (heq 6 (by decide) (by decide)).trans h.2.2.2.2.2.2.1,
   (heq 7 (by decide) (by decide)).trans h.2.2.2.2.2.2.2.1,
   (heq 8 (by decide) (by decide)).trans h.2.2.2.2.2.2.2.2.1,
   (heq 9 (by decide) (by decide)).trans h.2.2.2.2.2.2.2.2.2.1,
   (heq 10 (by decide) (by decide)).trans h.2.2.2.2.2.2.2.2.2.2.1,
   (heq 13 (by decide) (by decide)).trans h.2.2.2.2.2.2.2.2.2.2.2.1,
   (heq 14 (by decide) (by decide)).trans h.2.2.2.2.2.2.2.2.2.2.2.2.1,
   (heq 15 (by decide) (by decide)).trans h.2.2.2.2.2.2.2.2.2.2.2.2.2⟩

def HasLiftArrays (p : CoreParams) (pts_h : ℕ → Fin p.d → ℚ) (ws : WordStore) : Prop :=
  ∀ h : ℕ, h < p.m →
    ws.read (.localFrame 1 2 (h : ℤ)) = (liftRatPoint (pts_h h) (Fin.last p.d)).num ∧
    ws.read (.localFrame 1 3 (h : ℤ)) = ((liftRatPoint (pts_h h) (Fin.last p.d)).den : ℤ)

theorem hasLiftArrays_of_eq {p : CoreParams} {pts_h : ℕ → Fin p.d → ℚ}
    {ws ws' : WordStore} (h : HasLiftArrays p pts_h ws)
    (heq : ∀ (v : ℕ) (idx : ℤ), (v = 2 ∨ v = 3) →
      ws'.read (.localFrame 1 v idx) = ws.read (.localFrame 1 v idx)) :
    HasLiftArrays p pts_h ws' :=
  fun i hi =>
    ⟨(heq 2 (i : ℤ) (Or.inl rfl)).trans (h i hi).1,
     (heq 3 (i : ℤ) (Or.inr rfl)).trans (h i hi).2⟩

/-! ### 2. Phase 0: Initialize all scalar registers -/

def phase0Stmt (K deg_α C_z deg_alg : ℕ) : BitRAMStmt :=
  .seq (.writeLocal 0 (.lit 0) .dim)
  (.seq (.writeLocal 0 (.lit 1) (.add (.readLocal 0 (.lit 0)) (.lit 1)))
  (.seq (.writeLocal 0 (.lit 2) (.intParam (.lit 0)))
  (.seq (.writeLocal 0 (.lit 3) (.intParam (.lit 1)))
  (.seq (.writeLocal 0 (.lit 4)
    (.add (.add (.mul (.add (.mul (.lit 2) (.readLocal 0 (.lit 0))) (.lit 2))
                      (.readLocal 0 (.lit 3)))
                (.readLocal 0 (.lit 0)))
          (.lit 2)))
  (.seq (.writeLocal 1 (.lit 0) (.add (.readLocal 0 (.lit 0)) (.lit 2)))
  (.seq (powConstStmt 0 5 ((22 * K ^ 3 : ℕ) : ℤ) 1 0 (2 * deg_α + 1))
  (.seq (.writeLocal 0 (.lit 6) (.div (.readLocal 0 (.lit 2)) (.readLocal 0 (.lit 5))))
  (.seq (.writeLocal 1 (.lit 0) (.mul (.lit 2) (.readLocal 0 (.lit 2))))
  (.seq (clog2LoopStmt 0 1 2)
  (.seq (.writeLocal 0 (.lit 7) (.readLocal 1 (.lit 2)))
  (.seq (.writeLocal 0 (.lit 13) (.add (.mul (.lit 2) (.readLocal 0 (.lit 7))) (.lit 6)))
  (.seq (.writeLocal 1 (.lit 0) (.add (.readLocal 0 (.lit 1)) (.lit 1)))
  (.seq (powConstStmt 1 9 1 1 0 deg_alg)
  (.seq (.writeLocal 1 (.lit 0) (.add (.readLocal 0 (.lit 4)) (.lit 1)))
  (.seq (powConstStmt 1 10 1 1 0 deg_alg)
  (.seq (.writeLocal 0 (.lit 8)
    (.mul (.mul (.lit (C_z : ℤ)) (.readLocal 1 (.lit 9))) (.readLocal 1 (.lit 10))))
  (.seq (.writeLocal 0 (.lit 9) (.mul (.lit 2) (.readLocal 0 (.lit 4))))
  (.seq (.writeLocal 0 (.lit 10) (.mul (.lit 2) (.readLocal 0 (.lit 8))))
  (.seq (.writeLocal 0 (.lit 14) (.mul (.lit 2) (.readLocal 0 (.lit 1))))
        (.writeLocal 0 (.lit 15) (.mul (.lit 2) (.readLocal 0 (.lit 5)))))))))))))))))))))))

theorem exec_phase0Stmt {A V : ℕ} (p : CoreParams)
    {inp : BitRAMInput p.d} {ws₀ : WordStore} {bs : List Bool}
    (harena : InAttemptArena A V ws₀)
    (hhz : HeapAllZero ws₀)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hip_params : inp.intParams = [(p.m : ℤ), (p.B : ℤ)]) :
    ∃ ws₁ : WordStore,
      InAttemptArena A V ws₁ ∧
      HeapAllZero ws₁ ∧
      HasPhase0Regs p ws₁ ∧
      ExecBounded inp (phase0Stmt p.K p.deg_α p.C_z p.deg_alg) ws₀ bs ws₁ bs
        (32 * (p.w + 1) + 400 * (p.deg_α + p.deg_alg + 16))
        ((4000000 + 400000 * (p.deg_α + p.deg_alg)) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  rcases hfit with ⟨hK1, hB1, hCz1, hm2s, h16A, hmA, hVA, hBlV, hwV, hs0V, hdaV, h2LzV, hdalgV, _⟩
  have hV16 : 16 ≤ V := by omega
  have hs0_pos : 1 ≤ p.s₀ := s₀Val_pos hK1 p.d
  have hm2 : 2 ≤ p.m := by omega
  have hd_V : intBitLength (p.d : ℤ) ≤ V := hinp.2.2.1
  have hD_V : intBitLength (p.D : ℤ) ≤ V := by
    have : p.D ≤ p.B_lift := by dsimp [CoreParams.D, CoreParams.B_lift, bLiftVal]; omega
    exact (intBitLength_natCast_le_succ p.D).trans (by have := natBitLength_le p.D; omega)
  have hm_V : intBitLength (p.m : ℤ) ≤ V := by
    have h := hinp.2.2.2.1 0; simpa [hip_params, listGetIntD] using h
  have hB_V : intBitLength (p.B : ℤ) ≤ V := by
    have h := hinp.2.2.2.1 1; simpa [hip_params, listGetIntD] using h
  have hBl_V : intBitLength (p.B_lift : ℤ) ≤ V :=
    (intBitLength_natCast_le_succ p.B_lift).trans (by have := natBitLength_le p.B_lift; omega)
  have h2Bl_V : intBitLength ((2 * p.B_lift : ℕ) : ℤ) ≤ V :=
    (intBitLength_natCast_le_succ (2 * p.B_lift)).trans
      (by have := natBitLength_le (2 * p.B_lift); omega)
  have hd2_V : intBitLength ((p.d + 2 : ℕ) : ℤ) ≤ V :=
    (intBitLength_natCast_mono (by dsimp [CoreParams.B_lift, bLiftVal]; omega : p.d + 2 ≤ p.B_lift)).trans hBl_V
  have hr_V : intBitLength (p.r : ℤ) ≤ V :=
    (intBitLength_natCast_mono (Nat.div_le_self p.m p.s₀)).trans hm_V
  have h2m_V : intBitLength ((2 * p.m : ℕ) : ℤ) ≤ V :=
    (intBitLength_natCast_le_succ (2 * p.m)).trans
      (by have := natBitLength_mono (by omega : 2 * p.m ≤ A); omega)
  have hw_V : intBitLength (p.w : ℤ) ≤ V :=
    (intBitLength_natCast_le_succ p.w).trans (by have := natBitLength_le p.w; omega)
  have hW2_V : intBitLength (p.W₂ : ℤ) ≤ V :=
    (intBitLength_natCast_le_succ p.W₂).trans
      (by have := natBitLength_le p.W₂; dsimp [CoreParams.W₂] at *; omega)
  have h2D_V : intBitLength ((2 * p.D : ℕ) : ℤ) ≤ V :=
    (intBitLength_natCast_le_succ (2 * p.D)).trans
      (by have := natBitLength_mono (by omega : 2 * p.D ≤ A); omega)
  have h2s0_V : intBitLength ((2 * p.s₀ : ℕ) : ℤ) ≤ V :=
    (intBitLength_natCast_mono hm2s).trans hm_V
  have hD1_V : intBitLength ((p.D + 1 : ℕ) : ℤ) ≤ V :=
    (intBitLength_natCast_mono (by dsimp [CoreParams.D, CoreParams.B_lift, bLiftVal]; omega : p.D + 1 ≤ 2 * p.B_lift)).trans h2Bl_V
  have hBl1_V : intBitLength ((p.B_lift + 1 : ℕ) : ℤ) ≤ V :=
    (intBitLength_natCast_mono (by dsimp [CoreParams.B_lift, bLiftVal]; omega : p.B_lift + 1 ≤ 2 * p.B_lift)).trans h2Bl_V
  have hD1_pow_V : ∀ k : ℕ, k ≤ p.deg_alg → intBitLength ((1 * (p.D + 1) ^ k : ℕ) : ℤ) ≤ V := by
    intro k hk
    have h1 : 1 * (p.D + 1) ^ k ≤ 2 * p.L_z := by
      rw [Nat.one_mul]
      have ha : (p.D + 1) ^ k ≤ (p.D + 1) ^ p.deg_alg :=
        Nat.pow_le_pow_right (by dsimp [CoreParams.D]; omega) hk
      have hb : (p.D + 1) ^ p.deg_alg ≤ p.L_z := by
        dsimp [CoreParams.L_z]
        exact (Nat.le_mul_of_pos_left _ hCz1).trans
          (Nat.le_mul_of_pos_right _ (Nat.one_le_pow _ _ (by omega)))
      omega
    exact (intBitLength_natCast_mono h1).trans h2LzV
  have hBl1_pow_V : ∀ k : ℕ, k ≤ p.deg_alg → intBitLength ((1 * (p.B_lift + 1) ^ k : ℕ) : ℤ) ≤ V := by
    intro k hk
    have h1 : 1 * (p.B_lift + 1) ^ k ≤ 2 * p.L_z := by
      rw [Nat.one_mul]
      have ha : (p.B_lift + 1) ^ k ≤ (p.B_lift + 1) ^ p.deg_alg :=
        Nat.pow_le_pow_right (by omega) hk
      have hb : (p.B_lift + 1) ^ p.deg_alg ≤ p.L_z := by
        dsimp [CoreParams.L_z]
        exact Nat.le_mul_of_pos_left _
          (Nat.mul_pos hCz1 (Nat.one_le_pow _ _ (by dsimp [CoreParams.D]; omega)))
      omega
    exact (intBitLength_natCast_mono h1).trans h2LzV
  have hs0_pow_V : ∀ k : ℕ, k ≤ 2 * p.deg_α + 1 →
      intBitLength (((22 * p.K ^ 3) * (p.d + 2) ^ k : ℕ) : ℤ) ≤ V := by
    intro k hk
    have h1 : (22 * p.K ^ 3) * (p.d + 2) ^ k ≤ p.s₀ := by
      dsimp [CoreParams.s₀, s₀Val]
      exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) hk)
    exact (intBitLength_natCast_mono h1).trans hs0V
  have hCz_V : intBitLength (p.C_z : ℤ) ≤ V := by
    have h1 : p.C_z ≤ 2 * p.L_z := by
      dsimp [CoreParams.L_z]
      have hp1 : 1 ≤ (p.D + 1) ^ p.deg_alg := Nat.one_le_pow p.deg_alg (p.D + 1) (Nat.succ_pos _)
      have hp2 : 1 ≤ (p.B_lift + 1) ^ p.deg_alg := Nat.one_le_pow p.deg_alg (p.B_lift + 1) (Nat.succ_pos _)
      exact (Nat.le_mul_of_pos_right p.C_z hp1).trans
        ((Nat.le_mul_of_pos_right _ hp2).trans (by omega))
    exact (intBitLength_natCast_mono h1).trans h2LzV
  have hLz_V : intBitLength (p.L_z : ℤ) ≤ V :=
    (intBitLength_natCast_mono (by omega : p.L_z ≤ 2 * p.L_z)).trans h2LzV
  -- Execute statements 1..21 sequentially
  obtain ⟨ha1, ex1⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 0) (valE := .dim) harena hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_dim _ _) (by decide) (by omega) (by simp; omega) hd_V
  obtain ⟨ha2, ex2⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 1) (valE := .add (.readLocal 0 (.lit 0)) (.lit 1)) ha1 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by dsimp [CoreParams.D]; simp [rw_write_eq, rf_free_eq])
    (by decide) (by omega) (by simp; omega) hD_V
  obtain ⟨ha3, ex3⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 2) (valE := .intParam (.lit 0)) ha2 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (by simp [hip_params, listGetIntD])
    (by decide) (by omega) (by simp; omega) hm_V
  obtain ⟨ha4, ex4⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 3) (valE := .intParam (.lit 1)) ha3 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (by simp [hip_params, listGetIntD])
    (by decide) (by omega) (by simp; omega) hB_V
  obtain ⟨ha5, ex5⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 4) (valE := .add (.add (.mul (.add (.mul (.lit 2) (.readLocal 0 (.lit 0))) (.lit 2)) (.readLocal 0 (.lit 3))) (.readLocal 0 (.lit 0))) (.lit 2)) ha4 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit]
        dsimp [CoreParams.B_lift, bLiftVal]; try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) hBl_V
  obtain ⟨ha6, ex6⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 0) (valE := .add (.readLocal 0 (.lit 0)) (.lit 2)) ha5 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit]
        try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) hd2_V
  obtain ⟨ha7, ex7⟩ := exec_powConstStmt (dstVar := 0) (dstIdx := 5) (initVal := 22 * p.K ^ 3) (baseVar := 1) (baseIdx := 0) (2 * p.deg_α + 1) ha6 hinp
    ⟨by decide, by decide, Or.inl (by decide)⟩
    ⟨by omega, by simp; omega, (exprInArena_small (e := .lit 5) (by decide) (by decide) hV16 : intBitLength 5 ≤ V),
      (exprInArena_small (e := .lit 0) (by decide) (by decide) hV16 : intBitLength 0 ≤ V)⟩
    (wordStore_read_write_self _ _ _) hdaV hs0_pow_V
  have hs0_cast : (((22 * p.K ^ 3 * (p.d + 2) ^ (2 * p.deg_α + 1) : ℕ) : ℤ)) = (p.s₀ : ℤ) := rfl
  rw [hs0_cast] at ha7 ex7
  obtain ⟨ha8, ex8⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 6) (valE := .div (.readLocal 0 (.lit 2)) (.readLocal 0 (.lit 5))) ha7 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_div, evalVal_readLocal, evalVal_lit]
        exact (Int.natCast_ediv p.m p.s₀).symm)
    (by decide) (by omega) (by simp; omega) hr_V
  obtain ⟨ha9, ex9⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 0) (valE := .mul (.lit 2) (.readLocal 0 (.lit 2))) ha8 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_mul, evalVal_readLocal, evalVal_lit]
        try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) h2m_V
  have hpow_w_V : natBitLength (2 ^ Nat.clog 2 (2 * p.m)) + 2 ≤ V := by
    change natBitLength (2 ^ p.w) + 2 ≤ V
    have hlt : 2 ^ p.w < 2 ^ (p.w + 1) := Nat.pow_lt_pow_right (by norm_num) (Nat.lt_succ_self _)
    have := natBitLength_le_of_lt_two_pow (by omega) hlt
    omega
  obtain ⟨ha10, _, _, ex10⟩ := exec_clog2LoopStmt (inp := inp) (bs := bs) (T := 2 * p.m)
    (targetIdx := 0) (powIdx := 1) (cntIdx := 2)
    ha9 ⟨by decide, by decide, by decide⟩
    ⟨by omega, by omega, by omega, by omega, by omega, by omega, h16A⟩
    (wordStore_read_write_self _ _ _) (by omega) hpow_w_V
  change ExecBounded inp (clog2LoopStmt 0 1 2) (wsOf ha9) bs (wsOf ha10) bs
    (32 * (p.w + 1)) (64 * (p.w + natBitLength (2 * p.m) + 16) ^ 2)
    (arenaCellCap inp A) (arenaBitCap inp A V) at ex10
  obtain ⟨ha11, ex11⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 7) (valE := .readLocal 1 (.lit 2)) ha10 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by dsimp [CoreParams.w]; simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit])
    (by decide) (by omega) (by simp; omega) hw_V
  obtain ⟨ha12, ex12⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 13) (valE := .add (.mul (.lit 2) (.readLocal 0 (.lit 7))) (.lit 6)) ha11 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit]
        dsimp [CoreParams.W₂]; try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) hW2_V
  obtain ⟨ha13, ex13⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 0) (valE := .add (.readLocal 0 (.lit 1)) (.lit 1)) ha12 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit]
        try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) hD1_V
  obtain ⟨ha14, ex14⟩ := exec_powConstStmt (dstVar := 1) (dstIdx := 9) (initVal := 1) (baseVar := 1) (baseIdx := 0) p.deg_alg ha13 hinp
    ⟨by decide, by decide, Or.inr (by decide)⟩
    ⟨by omega, by simp; omega, (exprInArena_small (e := .lit 9) (by decide) (by decide) hV16 : intBitLength 9 ≤ V),
      (exprInArena_small (e := .lit 0) (by decide) (by decide) hV16 : intBitLength 0 ≤ V)⟩
    (wordStore_read_write_self _ _ _) hdalgV hD1_pow_V
  obtain ⟨ha15, ex15⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 0) (valE := .add (.readLocal 0 (.lit 4)) (.lit 1)) ha14 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit]
        try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) hBl1_V
  obtain ⟨ha16, ex16⟩ := exec_powConstStmt (dstVar := 1) (dstIdx := 10) (initVal := 1) (baseVar := 1) (baseIdx := 0) p.deg_alg ha15 hinp
    ⟨by decide, by decide, Or.inr (by decide)⟩
    ⟨by omega, by simp; omega, (exprInArena_small (e := .lit 10) (by decide) (by decide) hV16 : intBitLength 10 ≤ V),
      (exprInArena_small (e := .lit 0) (by decide) (by decide) hV16 : intBitLength 0 ≤ V)⟩
    (wordStore_read_write_self _ _ _) hdalgV hBl1_pow_V
  obtain ⟨ha17, ex17⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 8) (valE := .mul (.mul (.lit (p.C_z : ℤ)) (.readLocal 1 (.lit 9))) (.readLocal 1 (.lit 10))) ha16 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨⟨hCz_V, exprInArena_small (by decide) (by decide) hV16⟩,
      exprInArena_small (by decide) (by decide) hV16⟩
    ⟨by simp [exprNodes], by simp [exprNodes]⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_mul, evalVal_readLocal, evalVal_lit]
        dsimp [CoreParams.L_z]; try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) hLz_V
  obtain ⟨ha18, ex18⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 9) (valE := .mul (.lit 2) (.readLocal 0 (.lit 4))) ha17 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_mul, evalVal_readLocal, evalVal_lit]
        try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) h2Bl_V
  obtain ⟨ha19, ex19⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 10) (valE := .mul (.lit 2) (.readLocal 0 (.lit 8))) ha18 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_mul, evalVal_readLocal, evalVal_lit]
        try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) h2LzV
  obtain ⟨ha20, ex20⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 14) (valE := .mul (.lit 2) (.readLocal 0 (.lit 1))) ha19 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_mul, evalVal_readLocal, evalVal_lit]
        try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) h2D_V
  obtain ⟨ha21, ex21⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 15) (valE := .mul (.lit 2) (.readLocal 0 (.lit 5))) ha20 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_mul, evalVal_readLocal, evalVal_lit]
        try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) h2s0_V
  have ex_all :=
    ExecBounded.seq ex1 (ExecBounded.seq ex2 (ExecBounded.seq ex3 (ExecBounded.seq ex4
    (ExecBounded.seq ex5 (ExecBounded.seq ex6 (ExecBounded.seq ex7 (ExecBounded.seq ex8
    (ExecBounded.seq ex9 (ExecBounded.seq ex10 (ExecBounded.seq ex11 (ExecBounded.seq ex12
    (ExecBounded.seq ex13 (ExecBounded.seq ex14 (ExecBounded.seq ex15 (ExecBounded.seq ex16
    (ExecBounded.seq ex17 (ExecBounded.seq ex18 (ExecBounded.seq ex19
    (ExecBounded.seq ex20 ex21)))))))))))))))))))
  have hhz_final : HeapAllZero (wsOf ha21) := by
    intro t idx
    simp [rw_write_eq, rf_free_eq]
    exact hhz t idx
  have hregs_final : HasPhase0Regs p (wsOf ha21) := by
    refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;>
      simp [rw_write_eq, rf_free_eq]
  have hnb_2m : natBitLength (2 * p.m) ≤ natBitLength A := natBitLength_mono (by omega)
  have hclog_b : 64 * (p.w + natBitLength (2 * p.m) + 16) ^ 2 ≤ 256 * (V + 8) ^ 2 := by
    have h1 : p.w + natBitLength (2 * p.m) + 16 ≤ 2 * (V + 8) := by omega
    calc 64 * (p.w + natBitLength (2 * p.m) + 16) ^ 2
        ≤ 64 * (2 * (V + 8)) ^ 2 := Nat.mul_le_mul_left 64 (Nat.pow_le_pow_left h1 2)
      _ = 256 * (V + 8) ^ 2 := by ring
  refine ⟨_, ha21, hhz_final, hregs_final,
    ExecBounded.mono ex_all (by omega) ?_ le_rfl le_rfl⟩
  set Y := (V + 8) ^ 2
  have h1 : (132000 + (2 * p.deg_α + 1) * 66000) * Y = 198000 * Y + 132000 * (p.deg_α * Y) := by ring
  have h2 : (132000 + p.deg_alg * 66000) * Y = 132000 * Y + 66000 * (p.deg_alg * Y) := by ring
  have h3 : (4000000 + 400000 * (p.deg_α + p.deg_alg)) * Y =
      4000000 * Y + 400000 * (p.deg_α * Y) + 400000 * (p.deg_alg * Y) := by ring
  omega

/-! ### 3. Phase 1: Paraboloid lift `(sNum[h], sDen[h])` for `h = 0 .. m - 1` -/

theorem sumSqPairAux_step_lt_bLift {d B : ℕ} (hB : 1 ≤ B) {q : Fin d → ℚ}
    (hq : RatPointBitBounded B q) (k : ℕ) (hk : k ≤ d) :
    0 ≤ (sumSqPairAux q k hk).1 ∧
    1 ≤ (sumSqPairAux q k hk).2 ∧
    (sumSqPairAux q k hk).1 < (2 : ℤ) ^ (bLiftVal d B) ∧
    (sumSqPairAux q k hk).2 < (2 : ℤ) ^ (bLiftVal d B) := by
  obtain ⟨hn0, hd1, hn_ub, hd_ub, _⟩ := sumSqPairAux_spec hq k hk
  set nd := sumSqPairAux q k hk
  have hk_lt_2d : (k : ℤ) < (2 : ℤ) ^ (d + 1) := by
    have hnat : k < 2 ^ (d + 1) :=
      (lt_of_le_of_lt hk (Nat.lt_two_pow_self (n := d))).trans_le
        (Nat.pow_le_pow_right (by norm_num) (by omega))
    exact_mod_cast hnat
  have hd_le_2kd : (2 : ℤ) ^ (2 * k * B) ≤ (2 : ℤ) ^ (2 * d * B) := by
    have : 2 * k * B ≤ 2 * d * B := Nat.mul_le_mul_right B (Nat.mul_le_mul_left 2 hk)
    exact pow_le_pow_right₀ (by norm_num) this
  have hn_lt : nd.1 < (2 : ℤ) ^ (bLiftVal d B) := by
    have h1 : nd.1 ≤ (k : ℤ) * ((2 : ℤ) ^ (2 * B) * (2 : ℤ) ^ (2 * d * B)) :=
      hn_ub.trans (mul_le_mul_of_nonneg_left
        (mul_le_mul_of_nonneg_left (hd_ub.trans hd_le_2kd) (by positivity)) (by positivity))
    have h2 : (k : ℤ) * ((2 : ℤ) ^ (2 * B) * (2 : ℤ) ^ (2 * d * B)) <
        (2 : ℤ) ^ (d + 1) * ((2 : ℤ) ^ (2 * B) * (2 : ℤ) ^ (2 * d * B)) :=
      mul_lt_mul_of_pos_right hk_lt_2d (by positivity)
    have h3 : (2 : ℤ) ^ (d + 1) * ((2 : ℤ) ^ (2 * B) * (2 : ℤ) ^ (2 * d * B)) ≤
        (2 : ℤ) ^ (bLiftVal d B) := by
      rw [← pow_add, ← pow_add]
      exact pow_le_pow_right₀ (by norm_num) (by unfold bLiftVal; ring_nf; omega)
    exact lt_of_le_of_lt h1 (lt_of_lt_of_le h2 h3)
  have hd_lt : nd.2 < (2 : ℤ) ^ (bLiftVal d B) := by
    have hlt_pow : (2 : ℤ) ^ (2 * d * B) < (2 : ℤ) ^ (bLiftVal d B) :=
      pow_lt_pow_right₀ (by norm_num) (by unfold bLiftVal; ring_nf; omega)
    exact lt_of_le_of_lt (hd_ub.trans hd_le_2kd) hlt_pow
  exact ⟨hn0, hd1, hn_lt, hd_lt⟩

def phase1InnerBody : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 13) (.activeRatNum (.readLocal 1 (.lit 9)) (.readLocal 1 (.lit 10))))
  (.seq (.writeLocal 1 (.lit 14) (.activeRatDen (.readLocal 1 (.lit 9)) (.readLocal 1 (.lit 10))))
  (.seq (.writeLocal 1 (.lit 6)
    (.add (.mul (.readLocal 1 (.lit 11)) (.mul (.readLocal 1 (.lit 14)) (.readLocal 1 (.lit 14))))
          (.mul (.mul (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 13))) (.readLocal 1 (.lit 12)))))
  (.seq (.writeLocal 1 (.lit 12)
    (.mul (.readLocal 1 (.lit 12)) (.mul (.readLocal 1 (.lit 14)) (.readLocal 1 (.lit 14)))))
  (.seq (.writeLocal 1 (.lit 11) (.readLocal 1 (.lit 6)))
        (.writeLocal 1 (.lit 10) (.add (.readLocal 1 (.lit 10)) (.lit 1)))))))

def phase1OuterBody : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 11) (.lit 0))
  (.seq (.writeLocal 1 (.lit 12) (.lit 1))
  (.seq (.writeLocal 1 (.lit 10) (.lit 0))
  (.seq (.repeatN (.readLocal 0 (.lit 0)) phase1InnerBody)
  (.seq (.writeLocal 1 (.lit 6) (.readLocal 1 (.lit 11)))
  (.seq (.writeLocal 1 (.lit 7) (.readLocal 1 (.lit 12)))
  (.seq (gcdLoopStmt 5 6 7 8)
  (.seq (.writeLocal 2 (.readLocal 1 (.lit 9))
          (.div (.readLocal 1 (.lit 11)) (.readLocal 1 (.lit 6))))
  (.seq (.writeLocal 3 (.readLocal 1 (.lit 9))
          (.div (.readLocal 1 (.lit 12)) (.readLocal 1 (.lit 6))))
        (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1)))))))))))

def phase1Stmt : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 9) (.lit 0))
  (.seq (.writeLocal 1 (.lit 5) (.readLocal 0 (.lit 9)))
        (.repeatN (.readLocal 0 (.lit 2)) phase1OuterBody))

private def phase1InnerStepWS {d : ℕ} (q : Fin d → ℚ) (ws₀ : WordStore) : ℕ → WordStore
  | 0 => ((ws₀.write (.localFrame 1 1 11) 0).write (.localFrame 1 1 12) 1).write (.localFrame 1 1 10) 0
  | c + 1 =>
      if hc : c < d then
        let qc := q ⟨c, hc⟩
        let nd := sumSqPairAux q (c + 1) hc
        ((((((phase1InnerStepWS q ws₀ c).write (.localFrame 1 1 13) qc.num).write
          (.localFrame 1 1 14) (qc.den : ℤ)).write
          (.localFrame 1 1 6) nd.1).write
          (.localFrame 1 1 12) nd.2).write
          (.localFrame 1 1 11) nd.1).write
          (.localFrame 1 1 10) (((c + 1 : ℕ) : ℤ))
      else phase1InnerStepWS q ws₀ c

theorem exec_phase1Stmt {A V : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ)
    {inp : BitRAMInput p.d} {ws₁ : WordStore} {bs : List Bool}
    (harena : InAttemptArena A V ws₁)
    (hhz : HeapAllZero ws₁)
    (hregs : HasPhase0Regs p ws₁)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hpts_b : ∀ h : ℕ, h < p.m → RatPointBitBounded p.B (pts_h h))
    (hip_handles : inp.activeHandles = Finset.range p.m)
    (hip_coords : ∀ h : ℕ, h < p.m → inp.activeRatCoords h = pts_h h) :
    ∃ ws₂ : WordStore,
      InAttemptArena A V ws₂ ∧
      HeapAllZero ws₂ ∧
      HasPhase0Regs p ws₂ ∧
      HasLiftArrays p pts_h ws₂ ∧
      ExecBounded inp phase1Stmt ws₁ bs ws₂ bs
        (300 + p.m * (1000 + 500 * p.d + 60 * p.B_lift))
        ((300000 + p.m * (1000000 + 500000 * p.d + 600 * p.B_lift)) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  rcases hfit with ⟨hK1, hB1, _, hm2s, h16A, hmA, hVA, hBlV, _, _, _, _, _, _⟩
  have hV16 : 16 ≤ V := by omega
  have h2Bl_V : intBitLength ((2 * p.B_lift : ℕ) : ℤ) ≤ V :=
    (intBitLength_natCast_le_succ (2 * p.B_lift)).trans
      (by have := natBitLength_le (2 * p.B_lift); omega)
  have hlt_bLift_V : ∀ z : ℤ, 0 ≤ z → z < (2 : ℤ) ^ p.B_lift → intBitLength z ≤ V := by
    intro z hz0 hzlt
    have hnat : z.natAbs < 2 ^ p.B_lift := by
      have : (z.natAbs : ℤ) = z := Int.natAbs_of_nonneg hz0
      exact_mod_cast (this.symm ▸ hzlt)
    have hnb := natBitLength_le_of_lt_two_pow (by dsimp [CoreParams.B_lift, bLiftVal]; omega) hnat
    unfold intBitLength; split_ifs <;> omega
  obtain ⟨ha_i1, ex_i1⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .lit 0) harena hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _) (by decide) (by omega) (by simp; omega)
    (by change 1 ≤ V; omega)
  obtain ⟨ha_i2, ex_i2⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 5) (valE := .readLocal 0 (.lit 9)) ha_i1 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
          hregs.2.2.2.2.2.2.2.2.2.1])
    (by decide) (by omega) (by simp; omega) h2Bl_V
  let Inv (h : ℕ) (ws : WordStore) (bs_cur : List Bool) : Prop :=
    bs_cur = bs ∧
    InAttemptArena A V ws ∧
    HeapAllZero ws ∧
    HasPhase0Regs p ws ∧
    ws.read (.localFrame 1 1 9) = (h : ℤ) ∧
    ws.read (.localFrame 1 1 5) = ((2 * p.B_lift : ℕ) : ℤ) ∧
    (∀ i : ℕ, i < h →
      ws.read (.localFrame 1 2 (i : ℤ)) = (liftRatPoint (pts_h i) (Fin.last p.d)).num ∧
      ws.read (.localFrame 1 3 (i : ℤ)) = ((liftRatPoint (pts_h i) (Fin.last p.d)).den : ℤ))
  have hinit_inv : Inv 0 (wsOf ha_i2) bs := by
    refine ⟨rfl, ha_i2,
      heapAllZero_write_local (heapAllZero_write_local hhz 1 1 9 0) 1 1 5 _,
      hasPhase0Regs_of_eq hregs (fun _ _ _ => by simp [rw_write_eq, rf_free_eq]),
      by simp [rw_write_eq, rf_free_eq],
      wordStore_read_write_self _ _ _,
      fun _ hi => by omega⟩
  have hr_m0 : evalVal inp (wsOf ha_i2) (.readLocal 0 (.lit 2)) = (p.m : ℤ) := by
    simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
      hregs.2.2.1]
  obtain ⟨ws₂, bs₂, hinv_m, ex_loop⟩ := exec_repeatN_inv (countE := .readLocal 0 (.lit 2)) (body := phase1OuterBody) p.m Inv
    (U := 1000 + 500 * p.d + 60 * p.B_lift)
    (B := (1000000 + 500000 * p.d + 600 * p.B_lift) * (V + 8) ^ 2)
    ha_i2 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide) hr_m0 hinit_inv
    (fun h ws_h bs_cur hh_lt hinv_h => by
      rcases hinv_h with ⟨hbs_cur, ha_h, hhz_h, hregs_h, hr_h9, hr_h5, hprev_lifts⟩
      subst bs_cur
      let q := pts_h h
      have hq_b : RatPointBitBounded p.B q := hpts_b h hh_lt
      obtain ⟨ha_s1, ex_s1⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 11) (valE := .lit 0) ha_h hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _) (by decide) (by omega) (by simp; omega)
        (by change 1 ≤ V; omega)
      obtain ⟨ha_s2, ex_s2⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 12) (valE := .lit 1) ha_s1 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _) (by decide) (by omega) (by simp; omega)
        (exprInArena_small (e := .lit 1) (by decide) (by decide) hV16 : intBitLength 1 ≤ V)
      obtain ⟨ha_s3, ex_s3⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 10) (valE := .lit 0) ha_s2 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _) (by decide) (by omega) (by simp; omega)
        (by change 1 ≤ V; omega)
      have hinner_inv : ∀ (c : ℕ) (hc : c ≤ p.d),
          let ws_c := phase1InnerStepWS q ws_h c
          InAttemptArena A V ws_c ∧
          ws_c.read (.localFrame 1 1 10) = (c : ℤ) ∧
          ws_c.read (.localFrame 1 1 11) = (sumSqPairAux q c hc).1 ∧
          ws_c.read (.localFrame 1 1 12) = (sumSqPairAux q c hc).2 ∧
          ws_c.read (.localFrame 1 1 9) = (h : ℤ) ∧
          ws_c.read (.localFrame 1 1 5) = ((2 * p.B_lift : ℕ) : ℤ) ∧
          (∀ loc : RAMCellLoc,
            (∀ idx : ℤ, loc ≠ .localFrame 1 1 idx) → ws_c.read loc = ws_h.read loc) := by
        intro c
        induction c with
        | zero =>
            intro hc
            dsimp [phase1InnerStepWS, sumSqPairAux]
            refine ⟨ha_s3, wordStore_read_write_self _ _ _, ?_, ?_, ?_, ?_, ?_⟩
            · simp [rw_write_eq, rf_free_eq]
            · simp [rw_write_eq, rf_free_eq]
            · simp [rw_write_eq, rf_free_eq, hr_h9]
            · simp [rw_write_eq, rf_free_eq, hr_h5]
            · intro loc hne
              rw [wordStore_read_write_of_ne _ (hne 10), wordStore_read_write_of_ne _ (hne 12),
                wordStore_read_write_of_ne _ (hne 11)]
        | succ c ih =>
            intro hc1
            have hc_lt : c < p.d := hc1
            obtain ⟨ha_c, hr10, hr11, hr12, hr9, hr5, hoth⟩ := ih (le_of_lt hc_lt)
            dsimp only [phase1InnerStepWS]
            rw [dif_pos hc_lt]
            obtain ⟨hn0_next, _, hn_lt_next, hd_lt_next⟩ :=
              sumSqPairAux_step_lt_bLift hB1 hq_b (c + 1) hc1
            have hB_le_Bl : p.B ≤ p.B_lift := by dsimp [CoreParams.B_lift, bLiftVal]; nlinarith
            have hqc_num_V : intBitLength (q ⟨c, hc_lt⟩).num ≤ V := by
              have hb := (hq_b ⟨c, hc_lt⟩).1
              unfold intBitLength; split_ifs <;> (omega)
            have hqc_den_V : intBitLength ((q ⟨c, hc_lt⟩).den : ℤ) ≤ V := by
              have hb := (hq_b ⟨c, hc_lt⟩).2
              have := intBitLength_natCast_le_succ (q ⟨c, hc_lt⟩).den
              omega
            have hc1_V : intBitLength (((c + 1 : ℕ) : ℤ)) ≤ V :=
              (intBitLength_natCast_mono (by dsimp [CoreParams.B_lift, bLiftVal]; omega : c + 1 ≤ p.B_lift)).trans
                ((intBitLength_natCast_le_succ p.B_lift).trans (by have := natBitLength_le p.B_lift; omega))
            have ha_1 := inAttemptArena_write_local ha_c (var := 1) (idx := 13)
              (by decide) (by omega) (by simp; omega) hqc_num_V
            have ha_2 := inAttemptArena_write_local ha_1 (var := 1) (idx := 14)
              (by decide) (by omega) (by simp; omega) hqc_den_V
            have ha_3 := inAttemptArena_write_local ha_2 (var := 1) (idx := 6)
              (by decide) (by omega) (by simp; omega) (hlt_bLift_V _ hn0_next hn_lt_next)
            have ha_4 := inAttemptArena_write_local ha_3 (var := 1) (idx := 12)
              (by decide) (by omega) (by simp; omega) (hlt_bLift_V _ (by omega) hd_lt_next)
            have ha_5 := inAttemptArena_write_local ha_4 (var := 1) (idx := 11)
              (by decide) (by omega) (by simp; omega) (hlt_bLift_V _ hn0_next hn_lt_next)
            have ha_6 := inAttemptArena_write_local ha_5 (var := 1) (idx := 10)
              (by decide) (by omega) (by simp; omega) hc1_V
            refine ⟨ha_6, wordStore_read_write_self _ _ _, ?_, ?_, ?_, ?_, ?_⟩
            · simp [rw_write_eq, rf_free_eq]
            · simp [rw_write_eq, rf_free_eq]
            · simp [rw_write_eq, rf_free_eq, hr9]
            · simp [rw_write_eq, rf_free_eq, hr5]
            · intro loc hne
              rw [wordStore_read_write_of_ne _ (hne 10), wordStore_read_write_of_ne _ (hne 11),
                wordStore_read_write_of_ne _ (hne 12), wordStore_read_write_of_ne _ (hne 6),
                wordStore_read_write_of_ne _ (hne 14), wordStore_read_write_of_ne _ (hne 13)]
              exact hoth loc hne
      have hr0_d : (phase1InnerStepWS q ws_h 0).read (.localFrame 1 0 0) = (p.d : ℤ) := by
        rw [(hinner_inv 0 (Nat.zero_le _)).2.2.2.2.2.2 _ (fun _ hc => by nomatch hc), hregs_h.1]
      have ex_inner : ExecBounded inp (.repeatN (.readLocal 0 (.lit 0)) phase1InnerBody)
          (phase1InnerStepWS q ws_h 0) bs (phase1InnerStepWS q ws_h p.d) bs
          (68 + p.d * 408) (66000 * (V + 8) ^ 2 + p.d * (396000 * (V + 8) ^ 2))
          (arenaCellCap inp A) (arenaBitCap inp A V) := by
        refine exec_repeatN_auto p.d (phase1InnerStepWS q ws_h) (fun _ => bs)
          ha_s3 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
          (by simp [hr0_d]) (fun c hc_lt => ?_)
        obtain ⟨ha_c, hr10, hr11, hr12, hr9, _, _⟩ := hinner_inv c (le_of_lt hc_lt)
        obtain ⟨hn0_next, _, hn_lt_next, hd_lt_next⟩ :=
          sumSqPairAux_step_lt_bLift hB1 hq_b (c + 1) hc_lt
        have hB_le_Bl : p.B ≤ p.B_lift := by dsimp [CoreParams.B_lift, bLiftVal]; nlinarith
        have hqc_num_V : intBitLength (q ⟨c, hc_lt⟩).num ≤ V := by
          have hb := (hq_b ⟨c, hc_lt⟩).1
          unfold intBitLength; split_ifs <;> (omega)
        have hqc_den_V : intBitLength ((q ⟨c, hc_lt⟩).den : ℤ) ≤ V := by
          have hb := (hq_b ⟨c, hc_lt⟩).2
          have := intBitLength_natCast_le_succ (q ⟨c, hc_lt⟩).den
          omega
        have hc1_V : intBitLength (((c + 1 : ℕ) : ℤ)) ≤ V :=
          (intBitLength_natCast_mono (by dsimp [CoreParams.B_lift, bLiftVal]; omega : c + 1 ≤ p.B_lift)).trans
            ((intBitLength_natCast_le_succ p.B_lift).trans (by have := natBitLength_le p.B_lift; omega))
        have hh_mem : 0 ≤ (h : ℤ) ∧ (h : ℤ).toNat ∈ inp.activeHandles := by
          rw [Int.toNat_natCast, hip_handles, Finset.mem_range]
          exact ⟨Int.natCast_nonneg h, hh_lt⟩
        have hc_mem : 0 ≤ (c : ℤ) ∧ (c : ℤ).toNat < p.d := by
          rw [Int.toNat_natCast]; exact ⟨Int.natCast_nonneg c, hc_lt⟩
        obtain ⟨ha_1, ex_b1⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 13) (valE := .activeRatNum (.readLocal 1 (.lit 9)) (.readLocal 1 (.lit 10))) ha_c hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp only [evalVal_activeRatNum, evalVal_readLocal, evalVal_lit, hr9, hr10,
                dif_pos hh_mem, dif_pos hc_mem]
              simp [Int.toNat_natCast, hip_coords h hh_lt, q])
          (by decide) (by omega) (by simp; omega) hqc_num_V
        obtain ⟨ha_2, ex_b2⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 14) (valE := .activeRatDen (.readLocal 1 (.lit 9)) (.readLocal 1 (.lit 10))) ha_1 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp only [evalVal_activeRatDen, evalVal_readLocal, evalVal_lit,
                wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 1 9 ≠ .localFrame 1 1 13),
                wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 1 10 ≠ .localFrame 1 1 13),
                hr9, hr10, dif_pos hh_mem, dif_pos hc_mem]
              simp [Int.toNat_natCast, hip_coords h hh_lt, q])
          (by decide) (by omega) (by simp; omega) hqc_den_V
        obtain ⟨ha_3, ex_b3⟩ := exec_writeLocal_auto19 (var := 1) (idxE := .lit 6) (valE := .add (.mul (.readLocal 1 (.lit 11)) (.mul (.readLocal 1 (.lit 14)) (.readLocal 1 (.lit 14)))) (.mul (.mul (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 13))) (.readLocal 1 (.lit 12)))) ha_2 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit,
                hr11, hr12]
              rfl)
          (by decide) (by omega) (by simp; omega) (hlt_bLift_V _ hn0_next hn_lt_next)
        obtain ⟨ha_4, ex_b4⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 12) (valE := .mul (.readLocal 1 (.lit 12)) (.mul (.readLocal 1 (.lit 14)) (.readLocal 1 (.lit 14)))) ha_3 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp [rw_write_eq, rf_free_eq, evalVal_mul, evalVal_readLocal, evalVal_lit,
                hr12]
              rfl)
          (by decide) (by omega) (by simp; omega) (hlt_bLift_V _ (by omega) hd_lt_next)
        obtain ⟨ha_5, ex_b5⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 11) (valE := .readLocal 1 (.lit 6)) ha_4 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit])
          (by decide) (by omega) (by simp; omega) (hlt_bLift_V _ hn0_next hn_lt_next)
        obtain ⟨ha_6, ex_b6⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 10) (valE := .add (.readLocal 1 (.lit 10)) (.lit 1)) ha_5 hinp
          (exprInArena_small (by decide) (by decide) hV16)
          (exprInArena_small (by decide) (by decide) hV16)
          ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
          (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit,
                hr10]
              try push_cast; try ring)
          (by decide) (by omega) (by simp; omega) hc1_V
        have ex_b6' : ExecBounded inp (.writeLocal 1 (.lit 10) (.add (.readLocal 1 (.lit 10)) (.lit 1)))
            (wsOf ha_5) bs (phase1InnerStepWS q ws_h (c + 1)) bs 68 (66000 * (V + 8) ^ 2)
            (arenaCellCap inp A) (arenaBitCap inp A V) := by
          dsimp only [phase1InnerStepWS]; rw [dif_pos hc_lt]; exact ex_b6
        exact ExecBounded.mono
          (ExecBounded.seq ex_b1 (ExecBounded.seq ex_b2 (ExecBounded.seq ex_b3
            (ExecBounded.seq ex_b4 (ExecBounded.seq ex_b5 ex_b6')))))
          (by omega) (by omega) le_rfl le_rfl
      obtain ⟨ha_d, _, hr11_d, hr12_d, hr9_d, hr5_d, hoth_d⟩ := hinner_inv p.d le_rfl
      obtain ⟨hn0_d, hd1_d, hn_lt_d, hd_lt_d, hsum_d⟩ := sumSqPair_lt_two_pow_bLift hB1 hq_b
      set nd := sumSqPairAux q p.d le_rfl
      obtain ⟨ha_g1, ex_g1⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 6) (valE := .readLocal 1 (.lit 11)) ha_d hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (by simp [hr11_d]; try rfl)
        (by decide) (by omega) (by simp; omega) (hlt_bLift_V _ hn0_d hn_lt_d)
      obtain ⟨ha_g2, ex_g2⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 7) (valE := .readLocal 1 (.lit 12)) ha_g1 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp [rw_write_eq, rf_free_eq, hr12_d]; try rfl)
        (by decide) (by omega) (by simp; omega) (hlt_bLift_V _ (by omega) hd_lt_d)
      have hr6_nat : (wsOf ha_g2).read (.localFrame 1 1 6) = (nd.1.natAbs : ℤ) := by
        rw [wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)), wordStore_read_write_self]
        exact (Int.natAbs_of_nonneg hn0_d).symm
      have hr7_nat : (wsOf ha_g2).read (.localFrame 1 1 7) = (nd.2.natAbs : ℤ) := by
        rw [wordStore_read_write_self]
        exact (Int.natAbs_of_nonneg (by omega)).symm
      have hr5_g : (wsOf ha_g2).read (.localFrame 1 1 5) = ((2 * p.B_lift : ℕ) : ℤ) := by
        simp [rw_write_eq, rf_free_eq, hr5_d]
      have hmax_ab_lt : max nd.1.natAbs nd.2.natAbs < 2 ^ p.B_lift := by
        have h1 : nd.1.natAbs < 2 ^ p.B_lift := by
          have := Int.natAbs_of_nonneg hn0_d; exact_mod_cast (this.symm ▸ hn_lt_d)
        have h2 : nd.2.natAbs < 2 ^ p.B_lift := by
          have := Int.natAbs_of_nonneg (by omega : 0 ≤ nd.2); exact_mod_cast (this.symm ▸ hd_lt_d)
        exact max_lt h1 h2
      have hLab : natBitLength (max nd.1.natAbs nd.2.natAbs) + 2 ≤ p.B_lift + 2 :=
        Nat.add_le_add_right
          (natBitLength_le_of_lt_two_pow (by dsimp [CoreParams.B_lift, bLiftVal]; omega) hmax_ab_lt) 2
      obtain ⟨ws_gcd, ha_gcd, hr_g6, _, hoth_gcd, ex_gcd⟩ :=
        exec_gcdLoopStmt (inp := inp) (bs := bs) (N := 2 * p.B_lift) (a₀ := nd.1.natAbs) (b₀ := nd.2.natAbs)
          (L_ab := p.B_lift + 2) (nIdx := 5) (aIdx := 6) (bIdx := 7) (tmpIdx := 8)
          ha_g2 ⟨by decide, by decide, by decide, by decide, by decide, by decide⟩
          ⟨by omega, by omega, by omega, by omega, by omega, by omega, by omega, by omega, h16A⟩
          hr5_g hr6_nat hr7_nat hLab (by omega)
      have hred := reduceRatPair_spec (K := p.B_lift) (num := nd.1) (den := nd.2)
        (q := liftRatPoint q (Fin.last p.d))
        (by omega)
        (by have := Int.natAbs_of_nonneg (by omega : 0 ≤ nd.2); exact_mod_cast (this.symm ▸ hd_lt_d))
        (by simp [liftRatPoint, hsum_d])
      have hr11_gcd : ws_gcd.read (.localFrame 1 1 11) = nd.1 := by
        rw [hoth_gcd _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega))]
        simp [rw_write_eq, rf_free_eq, hr11_d]
      have hr12_gcd : ws_gcd.read (.localFrame 1 1 12) = nd.2 := by
        rw [hoth_gcd _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega))]
        simp [rw_write_eq, rf_free_eq, hr12_d]
      have hr9_gcd : ws_gcd.read (.localFrame 1 1 9) = (h : ℤ) := by
        rw [hoth_gcd _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega))]
        simp [rw_write_eq, rf_free_eq, hr9_d]
      have hr5_gcd : ws_gcd.read (.localFrame 1 1 5) = ((2 * p.B_lift : ℕ) : ℤ) := by
        rw [hoth_gcd _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega))]
        exact hr5_g
      have hlq_b : RatCoordBitBounded p.B_lift (liftRatPoint q (Fin.last p.d)) := ratPointBitBounded_liftRatPoint hB1 hq_b (Fin.last p.d)
      have hsnum_V : intBitLength (liftRatPoint q (Fin.last p.d)).num ≤ V := by
        have hb := hlq_b.1; unfold intBitLength; split_ifs <;> omega
      have hsden_V : intBitLength ((liftRatPoint q (Fin.last p.d)).den : ℤ) ≤ V := by
        have hb := hlq_b.2
        have := intBitLength_natCast_le_succ (liftRatPoint q (Fin.last p.d)).den
        omega
      obtain ⟨ha_w2, ex_w2⟩ := exec_writeLocal_auto (var := 2) (idxE := .readLocal 1 (.lit 9)) (valE := .div (.readLocal 1 (.lit 11)) (.readLocal 1 (.lit 6))) ha_gcd hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩
        (by simp [hr9_gcd]; rfl)
        (by simp only [evalVal_div, evalVal_readLocal, evalVal_lit, hr11_gcd, hr_g6]
            exact congrArg Prod.fst hred)
        (by decide) (by positivity) (by rw [Int.toNat_natCast]; omega) hsnum_V
      obtain ⟨ha_w3, ex_w3⟩ := exec_writeLocal_auto (var := 3) (idxE := .readLocal 1 (.lit 9)) (valE := .div (.readLocal 1 (.lit 12)) (.readLocal 1 (.lit 6))) ha_w2 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩
        (by simp [rw_write_eq, rf_free_eq, hr9_gcd]; rfl)
        (by simp [rw_write_eq, rf_free_eq, evalVal_div, evalVal_readLocal, evalVal_lit,
              hr12_gcd, hr_g6]
            exact congrArg Prod.snd hred)
        (by decide) (by positivity) (by rw [Int.toNat_natCast]; omega) hsden_V
      have hh1_V : intBitLength (((h + 1 : ℕ) : ℤ)) ≤ V :=
        (intBitLength_natCast_le_succ (h + 1)).trans
          (by have := natBitLength_mono (by omega : h + 1 ≤ A); omega)
      obtain ⟨ha_w9, ex_w9⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .add (.readLocal 1 (.lit 9)) (.lit 1)) ha_w3 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit,
              hr9_gcd]
            try push_cast; try ring)
        (by decide) (by omega) (by simp; omega) hh1_V
      have hhz_next : HeapAllZero (wsOf ha_w9) := by
        refine heapAllZero_write_local (heapAllZero_write_local (heapAllZero_write_local ?_ _ _ _ _) _ _ _ _) _ _ _ _
        refine heapAllZero_of_eq_heap hhz_h fun t idx => ?_
        rw [hoth_gcd _ (by intro hc; nomatch hc) (by intro hc; nomatch hc) (by intro hc; nomatch hc),
          wordStore_read_write_of_ne _ (by intro hc; nomatch hc),
          wordStore_read_write_of_ne _ (by intro hc; nomatch hc),
          hoth_d _ (fun _ hc => by nomatch hc)]
      have hregs_next : HasPhase0Regs p (wsOf ha_w9) := by
        refine hasPhase0Regs_of_eq hregs_h fun idx _ _ => ?_
        rw [wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
          wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
          wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
          hoth_gcd _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
          wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
          wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
          hoth_d _ (fun _ hc => by injection hc with _ hv _; omega)]
      have hlifts_next : ∀ i : ℕ, i < h + 1 → (wsOf ha_w9).read (.localFrame 1 2 (i : ℤ)) = (liftRatPoint (pts_h i) (Fin.last p.d)).num ∧ (wsOf ha_w9).read (.localFrame 1 3 (i : ℤ)) = ((liftRatPoint (pts_h i) (Fin.last p.d)).den : ℤ) := by
        intro i hi
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hi) with hlt | rfl
        · have hne_hi : (i : ℤ) ≠ (h : ℤ) := by omega
          refine ⟨?_, ?_⟩
          · rw [wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ heq; exact hne_hi heq),
              hoth_gcd _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              hoth_d _ (fun _ hc => by injection hc with _ hv _; omega)]
            exact (hprev_lifts i hlt).1
          · rw [wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ heq; exact hne_hi heq),
              wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              hoth_gcd _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)) (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              hoth_d _ (fun _ hc => by injection hc with _ hv _; omega)]
            exact (hprev_lifts i hlt).2
        · refine ⟨?_, ?_⟩
          · rw [wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              wordStore_read_write_self]
          · rw [wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
              wordStore_read_write_self]
      have hgcd_b : 64 * (2 * p.B_lift + 1) * (p.B_lift + 2 + natBitLength (2 * p.B_lift) + 16) ^ 2 ≤
          256 * (2 * p.B_lift + 1) * (V + 8) ^ 2 := by
        have hnb_2bl := natBitLength_le (2 * p.B_lift)
        have h1 : p.B_lift + 2 + natBitLength (2 * p.B_lift) + 16 ≤ 2 * (V + 8) := by omega
        calc 64 * (2 * p.B_lift + 1) * (p.B_lift + 2 + natBitLength (2 * p.B_lift) + 16) ^ 2
            ≤ 64 * (2 * p.B_lift + 1) * (2 * (V + 8)) ^ 2 :=
              Nat.mul_le_mul_left _ (Nat.pow_le_pow_left h1 2)
          _ = 256 * (2 * p.B_lift + 1) * (V + 8) ^ 2 := by ring
      have ex_outer_body :=
        ExecBounded.seq ex_s1 (ExecBounded.seq ex_s2 (ExecBounded.seq ex_s3
        (ExecBounded.seq ex_inner (ExecBounded.seq ex_g1 (ExecBounded.seq ex_g2
        (ExecBounded.seq ex_gcd (ExecBounded.seq ex_w2 (ExecBounded.seq ex_w3 ex_w9))))))))
      refine ⟨_, bs, ⟨rfl, ha_w9, hhz_next, hregs_next, wordStore_read_write_self _ _ _, ?_, hlifts_next⟩,
        ExecBounded.mono ex_outer_body (by omega) ?_ le_rfl le_rfl⟩
      · simp [rw_write_eq, rf_free_eq, hr5_gcd]
      · set Y := (V + 8) ^ 2
        change _ ≤ (1000000 + 500000 * p.d + 600 * p.B_lift) * Y
        have h1 : p.d * (396000 * Y) = 396000 * (p.d * Y) := by ring
        have h2 : 256 * (2 * p.B_lift + 1) * Y = 256 * Y + 512 * (p.B_lift * Y) := by ring
        have h3 : (1000000 + 500000 * p.d + 600 * p.B_lift) * Y =
            1000000 * Y + 500000 * (p.d * Y) + 600 * (p.B_lift * Y) := by ring
        omega)
  rcases hinv_m with ⟨hbs_m, ha_m, hhz_m, hregs_m, _, _, hlifts_m⟩
  subst bs₂
  refine ⟨ws₂, ha_m, hhz_m, hregs_m, hlifts_m, ?_⟩
  refine ExecBounded.mono (ExecBounded.seq ex_i1 (ExecBounded.seq ex_i2 ex_loop))
    (by omega) ?_ le_rfl le_rfl
  have : 66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 +
      (66000 * (V + 8) ^ 2 + p.m * ((1000000 + 500000 * p.d + 600 * p.B_lift) * (V + 8) ^ 2))) ≤
      (300000 + p.m * (1000000 + 500000 * p.d + 600 * p.B_lift)) * (V + 8) ^ 2 := by
    set Y := (V + 8) ^ 2
    have h1 : (300000 + p.m * (1000000 + 500000 * p.d + 600 * p.B_lift)) * Y =
        300000 * Y + p.m * ((1000000 + 500000 * p.d + 600 * p.B_lift) * Y) := by ring
    omega
  exact this

/-! ### 4. Phase 2: Call `sizeProg` to obtain `M` and compute `W₁` -/

def CoreParams.W₁ (p : CoreParams) (M : ℕ) : ℕ :=
  p.w + Nat.clog 2 (M + 1) + 8

theorem two_pow_W₁_ge (p : CoreParams) (M : ℕ) :
    64 * (M * p.m) ≤ 2 ^ (p.W₁ M) := by
  dsimp [CoreParams.W₁]
  have hw_le : 2 * p.m ≤ 2 ^ p.w := Nat.le_pow_clog (by norm_num) (2 * p.m)
  have hm_le : M + 1 ≤ 2 ^ (Nat.clog 2 (M + 1)) := Nat.le_pow_clog (by norm_num) (M + 1)
  have hprod := Nat.mul_le_mul hw_le (Nat.le_of_succ_le hm_le)
  rw [pow_add, pow_add]
  have h256 : 2 ^ 8 = 256 := by decide
  rw [h256]
  calc 64 * (M * p.m) ≤ (2 * p.m * M) * 256 := by
        have : 2 * p.m * M = 2 * (M * p.m) := by ring
        rw [this]; omega
    _ ≤ (2 ^ p.w * 2 ^ Nat.clog 2 (M + 1)) * 256 := Nat.mul_le_mul_right 256 hprod

theorem two_pow_W₂_ge (p : CoreParams) :
    64 * (p.m * p.m) ≤ 2 ^ p.W₂ := by
  dsimp [CoreParams.W₂]
  have hw_le : 2 * p.m ≤ 2 ^ p.w := Nat.le_pow_clog (by norm_num) (2 * p.m)
  have hprod := Nat.mul_le_mul hw_le hw_le
  rw [pow_add, two_mul, pow_add]
  have h64 : 2 ^ 6 = 64 := by decide
  rw [h64]
  calc 64 * (p.m * p.m) ≤ (2 * p.m * (2 * p.m)) * 64 := by
        have : 2 * p.m * (2 * p.m) = 4 * (p.m * p.m) := by ring
        rw [this]; omega
    _ ≤ (2 ^ p.w * 2 ^ p.w) * 64 := Nat.mul_le_mul_right 64 hprod

def HasPhase2Regs (p : CoreParams) (M : ℕ) (ws : WordStore) : Prop :=
  HasPhase0Regs p ws ∧
  ws.read (.localFrame 1 0 11) = (M : ℤ) ∧
  ws.read (.localFrame 1 0 12) = (p.W₁ M : ℤ)

theorem hasPhase2Regs_of_eq {p : CoreParams} {M : ℕ} {ws ws' : WordStore}
    (h : HasPhase2Regs p M ws)
    (heq : ∀ idx : ℤ, ws'.read (.localFrame 1 0 idx) = ws.read (.localFrame 1 0 idx)) :
    HasPhase2Regs p M ws' :=
  ⟨hasPhase0Regs_of_eq h.1 (fun idx _ _ => heq idx),
   (heq 11).trans h.2.1,
   (heq 12).trans h.2.2⟩

def phase2Stmt (k_φ : ℕ) (sizeProg : BitRAMStmt) : BitRAMStmt :=
  .seq (.writeHeap 5 (.lit 0) (.readLocal 0 (.lit 1)))
  (.seq (.writeHeap 5 (.lit 1) (.readLocal 0 (.lit 4)))
  (.seq (.writeHeap 5 (.lit 2) (.lit (k_φ : ℤ)))
  (.seq (runSubAndExtractStmt false sizeProg 0 11 6 none 9)
  (.seq (.freeHeap 5 (.lit 0))
  (.seq (.freeHeap 5 (.lit 1))
  (.seq (.freeHeap 5 (.lit 2))
  (.seq (.writeLocal 1 (.lit 0) (.add (.readLocal 0 (.lit 11)) (.lit 1)))
  (.seq (clog2LoopStmt 0 1 2)
        (.writeLocal 0 (.lit 12)
          (.add (.add (.readLocal 0 (.lit 7)) (.readLocal 1 (.lit 2))) (.lit 8)))))))))))

theorem exec_phase2Stmt {A V M U_sz : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ)
    (sizeProg : BitRAMStmt) {sizeOut : BitRAMExecOutcome}
    {inp : BitRAMInput p.d} {ws₂ : WordStore} {bs : List Bool}
    (harena : InAttemptArena A V ws₂)
    (hhz : HeapAllZero ws₂)
    (hregs : HasPhase0Regs p ws₂)
    (hlifts : HasLiftArrays p pts_h ws₂)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hrun_sz : runBitRAMWithBits sizeProg
      (BitRAMInput.ofIntParams [(p.D : ℤ), (p.B_lift : ℤ), (p.k_φ : ℤ)])
      WordStore.empty [] = some sizeOut)
    (hM_out : sizeOut.words.read (.heap 0 0) = (M : ℤ))
    (hsz_bounds : sizeOut.unitCost ≤ U_sz ∧ sizeOut.bitCost ≤ U_sz ∧
      sizeOut.peakCellSpace ≤ U_sz ∧ sizeOut.peakBitSpace ≤ U_sz)
    (hM_fit : intBitLength ((M + 1 : ℕ) : ℤ) ≤ V ∧
      natBitLength (2 ^ Nat.clog 2 (M + 1)) + 2 ≤ V ∧
      p.w + Nat.clog 2 (M + 1) + 16 ≤ V) :
    let T_sz := maxTableStmtFull sizeProg
    let F_sz := stmtFactor sizeProg
    let C_sz := arenaCellCap inp A + 2 * U_sz + 8
    let S_sz := arenaBitCap inp A V + (natBitLength T_sz + 12) * U_sz +
      (U_sz + 3) * (natBitLength (U_sz + 2) + U_sz + 2 * natBitLength T_sz + 18) +
      2 * natBitLength (U_sz + 2) + 64
    ∃ ws₃ : WordStore,
      InAttemptArena A V ws₃ ∧
      HeapAllZero ws₃ ∧
      HasPhase2Regs p M ws₃ ∧
      HasLiftArrays p pts_h ws₃ ∧
      ExecBounded inp (phase2Stmt p.k_φ sizeProg) ws₂ bs ws₃ bs
        (80 * F_sz * (U_sz + 1) + 32 * (Nat.clog 2 (M + 1) + 1) + 1000)
        (256 * F_sz * (V + natBitLength T_sz + 8) ^ 2 * (2 * U_sz + 16) * U_sz +
          (U_sz + 2) * (8 * natBitLength (U_sz + 2) + 4 * (U_sz + 2 * natBitLength T_sz + 6) + 80) +
          1000000 * (V + natBitLength T_sz + 16) ^ 2)
        C_sz S_sz := by
  intro T_sz F_sz C_sz S_sz
  rcases hfit with ⟨_, _, _, _, h16A, _, hVA, hBlV, _, _, _, _, _, hkφV⟩
  rcases hM_fit with ⟨hM1_V, hpowM_V, hW1_fit⟩
  have hV16 : 16 ≤ V := by omega
  have hD_V : intBitLength (p.D : ℤ) ≤ V := by
    have : p.D ≤ p.B_lift := by dsimp [CoreParams.D, CoreParams.B_lift, bLiftVal]; omega
    exact (intBitLength_natCast_le_succ p.D).trans (by have := natBitLength_le p.D; omega)
  have hBl_V : intBitLength (p.B_lift : ℤ) ≤ V :=
    (intBitLength_natCast_le_succ p.B_lift).trans (by have := natBitLength_le p.B_lift; omega)
  have hM_V : intBitLength (M : ℤ) ≤ V :=
    (intBitLength_natCast_mono (Nat.le_succ M)).trans hM1_V
  have hW1_V : intBitLength (p.W₁ M : ℤ) ≤ V :=
    (intBitLength_natCast_le_succ (p.W₁ M)).trans
      (by have := natBitLength_le (p.W₁ M); dsimp [CoreParams.W₁] at *; omega)
  -- Stage [D, B_lift, k_φ] into `.heap 5 [0, 1, 2]`
  obtain ⟨ha_h0, ex_h0⟩ := exec_writeHeap_auto (t := 5) (idxE := .lit 0) (valE := .readLocal 0 (.lit 1)) harena hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (by simp [hregs.2.1])
    (by decide) (by omega) (by simp; omega) hD_V
  obtain ⟨ha_h1, ex_h1⟩ := exec_writeHeap_auto (t := 5) (idxE := .lit 1) (valE := .readLocal 0 (.lit 4)) ha_h0 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, hregs.2.2.2.2.1])
    (by decide) (by omega) (by simp; omega) hBl_V
  obtain ⟨ha_h2, ex_h2⟩ := exec_writeHeap_auto (t := 5) (idxE := .lit 2) (valE := .lit (p.k_φ : ℤ)) ha_h1 hinp
    (exprInArena_small (by decide) (by decide) hV16) hkφV
    ⟨by simp [exprNodes], by simp [exprNodes]⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _)
    (by decide) (by omega) (by simp; omega) hkφV
  -- Prove `SimStageMatches false p.d 0 V _ (BitRAMInput.ofIntParams [D, B_lift, k_φ])`
  let inpSz : BitRAMInput 0 := BitRAMInput.ofIntParams [(p.D : ℤ), (p.B_lift : ℤ), (p.k_φ : ℤ)]
  have hstage_sz : SimStageMatches false p.d 0 V (wsOf ha_h2) inpSz := by
    refine ⟨ha_h2.1, by omega, hinp.2.2.1, ?_⟩
    simp only [Bool.false_eq_true, ↓reduceIte]
    refine ⟨trivial, rfl, fun idx => ?_, fun idx => ?_, fun idx => ?_⟩
    · by_cases h0 : idx = 0
      · subst h0
        simp [rw_write_eq, rf_free_eq, inpSz, BitRAMInput.ofIntParams, listGetIntD]
      · by_cases h1 : idx = 1
        · subst h1
          simp [rw_write_eq, rf_free_eq, inpSz, BitRAMInput.ofIntParams, listGetIntD]
        · by_cases h2 : idx = 2
          · subst h2
            simp [rw_write_eq, rf_free_eq, inpSz, BitRAMInput.ofIntParams, listGetIntD]
          · rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ hi; exact h2 hi),
              wordStore_read_write_of_ne _ (by intro hc; injection hc with _ hi; exact h1 hi),
              wordStore_read_write_of_ne _ (by intro hc; injection hc with _ hi; exact h0 hi),
              hhz 5 idx]
            dsimp [inpSz, BitRAMInput.ofIntParams, listGetIntD]
            split_ifs with hnn
            · have hge3 : 3 ≤ idx.toNat := by omega
              rcases h : idx.toNat with _ | _ | _ | n <;> simp_all
            · rfl
    · rw [wordStore_read_write_of_ne _ (by intro hc; nomatch hc), wordStore_read_write_of_ne _ (by intro hc; nomatch hc),
        wordStore_read_write_of_ne _ (by intro hc; nomatch hc), hhz 6 idx]
      simp [inpSz, BitRAMInput.ofIntParams, listGetIntD]
    · rw [wordStore_read_write_of_ne _ (by intro hc; nomatch hc), wordStore_read_write_of_ne _ (by intro hc; nomatch hc),
        wordStore_read_write_of_ne _ (by intro hc; nomatch hc), hhz 7 idx]
      simp [inpSz, BitRAMInput.ofIntParams, listGetIntD]
  -- Call `runSubAndExtractStmt false sizeProg 0 11 6 none 9`
  have ex_sub := exec_runSubAndExtractStmt (inpSim := inp) (bs := bs) (N_out := 0)
    (nOutLoc := none) (flagVar := 0) (flagIdx := 11) (outVar := 6) (loopIdxVar := 9)
    (U_sub := U_sz) (B_sub := U_sz) (C_sub := U_sz) (S_sub := U_sz)
    sizeProg ha_h2 hstage_sz hrun_sz
    ⟨by decide, by decide, by decide, by decide, by decide, by decide⟩
    ⟨by omega, by omega, by omega⟩ rfl
    (by rw [hM_out]; exact hM_V) (fun _ hj => by omega) (by omega) hsz_bounds
  obtain ⟨ha_after_sub, hr_M_sub, _, hoth_sub⟩ := extractSubResultWS_props (wsOutSub := sizeOut.words) (flagVar := 0) (flagIdx := 11) (outVar := 6) (loopIdxVar := 9) (N_out := 0) ha_h2
    ⟨by decide, by decide, by decide, by decide, by decide, by decide⟩
    ⟨by omega, by omega, by omega⟩
    (by rw [hM_out]; exact hM_V)
    (fun k hk => by rw [Nat.le_zero.mp hk]; change 1 ≤ V; omega)
    (fun _ hj => by omega)
  -- Free `.heap 5 0`, `.heap 5 1`, `.heap 5 2`
  obtain ⟨ha_f0, ex_f0⟩ := exec_freeHeap_auto (t := 5) (idxE := .lit 0) ha_after_sub hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide) (evalVal_lit _ _ _)
    (by decide) (by omega) (by simp; omega)
  obtain ⟨ha_f1, ex_f1⟩ := exec_freeHeap_auto (t := 5) (idxE := .lit 1) ha_f0 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide) (evalVal_lit _ _ _)
    (by decide) (by omega) (by simp; omega)
  obtain ⟨ha_f2, ex_f2⟩ := exec_freeHeap_auto (t := 5) (idxE := .lit 2) ha_f1 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide) (evalVal_lit _ _ _)
    (by decide) (by omega) (by simp; omega)
  have hhz_after_free : HeapAllZero (wsOf ha_f2) := by
    intro t idx
    by_cases ht5 : t = 5 ∧ (idx = 0 ∨ idx = 1 ∨ idx = 2)
    · rcases ht5 with ⟨rfl, rfl | rfl | rfl⟩
      · rw [wordStore_read_free_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)), wordStore_read_free_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega))]
        simp [WordStore.read, WordStore.free]
      · rw [wordStore_read_free_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega))]
        simp [WordStore.read, WordStore.free]
      · simp [WordStore.read, WordStore.free]
    · have hne2 : RAMCellLoc.heap t idx ≠ .heap 5 2 := by
        intro hc; injection hc with ht hi; exact ht5 ⟨ht, Or.inr (Or.inr hi)⟩
      have hne1 : RAMCellLoc.heap t idx ≠ .heap 5 1 := by
        intro hc; injection hc with ht hi; exact ht5 ⟨ht, Or.inr (Or.inl hi)⟩
      have hne0 : RAMCellLoc.heap t idx ≠ .heap 5 0 := by
        intro hc; injection hc with ht hi; exact ht5 ⟨ht, Or.inl hi⟩
      rw [wordStore_read_free_of_ne _ hne2, wordStore_read_free_of_ne _ hne1,
        wordStore_read_free_of_ne _ hne0,
        hoth_sub _ (by intro hc; nomatch hc) (by intro hc; nomatch hc) (by intro hc; nomatch hc) (fun _ hj => by omega),
        wordStore_read_write_of_ne _ hne2, wordStore_read_write_of_ne _ hne1,
        wordStore_read_write_of_ne _ hne0, hhz t idx]
  -- Compute `lM := Nat.clog 2 (M + 1)` and `W₁ := w + lM + 8`
  have hr_M_f2 : (wsOf ha_f2).read (.localFrame 1 0 11) = (M : ℤ) := by
    rw [wordStore_read_free_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)), wordStore_read_free_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
      wordStore_read_free_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega))]
    exact hr_M_sub.trans hM_out
  obtain ⟨ha_m1, ex_m1⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 0) (valE := .add (.readLocal 0 (.lit 11)) (.lit 1)) ha_f2 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp only [evalVal_add, evalVal_readLocal, evalVal_lit, hr_M_f2]; push_cast; ring)
    (by decide) (by omega) (by simp; omega) hM1_V
  obtain ⟨ha_cl, _, _, ex_cl⟩ := exec_clog2LoopStmt (inp := inp) (bs := bs) (T := M + 1)
    (targetIdx := 0) (powIdx := 1) (cntIdx := 2)
    ha_m1 ⟨by decide, by decide, by decide⟩
    ⟨by omega, by omega, by omega, by omega, by omega, by omega, h16A⟩
    (wordStore_read_write_self _ _ _) (by omega) hpowM_V
  have hr_w_cl : (wsOf ha_cl).read (.localFrame 1 0 7) = (p.w : ℤ) := by
    simp [rw_write_eq, rf_free_eq]
    rw [hoth_sub _ (by intro hc; nomatch hc) (by intro hc; nomatch hc) (by intro hc; nomatch hc) (fun _ hj => by omega)]
    simp [rw_write_eq, rf_free_eq]
    exact hregs.2.2.2.2.2.2.2.1
  obtain ⟨ha_w1, ex_w1⟩ := exec_writeLocal_auto (var := 0) (idxE := .lit 12) (valE := .add (.add (.readLocal 0 (.lit 7)) (.readLocal 1 (.lit 2))) (.lit 8)) ha_cl hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by rw [evalVal_add, evalVal_add, evalVal_readLocal, evalVal_lit, hr_w_cl,
          evalVal_readLocal, evalVal_lit, wordStore_read_write_self, evalVal_lit]
        dsimp [CoreParams.W₁]; try push_cast; try ring)
    (by decide) (by omega) (by simp; omega) hW1_V
  -- Assemble all 10 steps of Phase 2 via `ExecBounded.mono` to `(C_sz, S_sz)`!
  have hC_le : arenaCellCap inp A ≤ C_sz := by dsimp [C_sz, arenaCellCap]; omega
  have hS_le : arenaBitCap inp A V ≤ S_sz := by dsimp [S_sz, arenaBitCap]; omega
  have liftA := fun {s w₁ w₂ u b} (h : ExecBounded inp s w₁ bs w₂ bs u b (arenaCellCap inp A) (arenaBitCap inp A V)) =>
    ExecBounded.mono h le_rfl le_rfl hC_le hS_le
  have ex_sub' : ExecBounded inp (runSubAndExtractStmt false sizeProg 0 11 6 none 9) (wsOf ha_h2) bs (wsOf ha_after_sub) bs
      (80 * F_sz * (U_sz + 1) + 64)
      (256 * F_sz * (V + natBitLength T_sz + 8) ^ 2 * (2 * U_sz + 16) * U_sz +
        (U_sz + 2) * (8 * natBitLength (U_sz + 2) + 4 * (U_sz + 2 * natBitLength T_sz + 6) + 80) +
        4 * (32 * (natBitLength A + natBitLength T_sz + V + 16) ^ 2))
      C_sz S_sz := by
    refine ExecBounded.mono ex_sub (by dsimp [F_sz]; omega) ?_
      (by dsimp [C_sz, arenaCellCap]; omega) (by dsimp [S_sz, arenaBitCap, T_sz]; ring_nf; omega)
    dsimp [F_sz, T_sz]
    rw [show U_sz + U_sz + 16 = 2 * U_sz + 16 by omega]
  have ex_all :=
    ExecBounded.seq (liftA ex_h0) (ExecBounded.seq (liftA ex_h1) (ExecBounded.seq (liftA ex_h2)
    (ExecBounded.seq ex_sub' (ExecBounded.seq (liftA ex_f0) (ExecBounded.seq (liftA ex_f1)
    (ExecBounded.seq (liftA ex_f2) (ExecBounded.seq (liftA ex_m1)
    (ExecBounded.seq (liftA ex_cl) (liftA ex_w1)))))))))
  -- Check final invariants on `ws₃`
  have hhz_3 : HeapAllZero (wsOf ha_w1) := by
    intro t idx
    simp only [rw_heap_local]
    exact hhz_after_free t idx
  have hregs_3 : HasPhase2Regs p M (wsOf ha_w1) := by
    refine ⟨hasPhase0Regs_of_eq hregs (fun idx hne11 hne12 => ?_), ?_, wordStore_read_write_self _ _ _⟩
    · rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ hi; exact hne12 hi),
        wordStore_read_write_of_ne _ (by intro hc; nomatch hc),
        wordStore_read_write_of_ne _ (by intro hc; nomatch hc),
        wordStore_read_write_of_ne _ (by intro hc; nomatch hc),
        wordStore_read_free_of_ne _ (by intro hc; nomatch hc),
        wordStore_read_free_of_ne _ (by intro hc; nomatch hc),
        wordStore_read_free_of_ne _ (by intro hc; nomatch hc),
        hoth_sub _ (by intro hc; injection hc with _ _ hi; exact hne11 hi)
          (by intro hc; nomatch hc) (by intro hc; nomatch hc) (fun _ hj => by omega)]
      simp [rw_write_eq, rf_free_eq]
    · rw [wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
        wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
        wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega)),
        wordStore_read_write_of_ne _ (by intro h_ne; first | nomatch h_ne | (injection h_ne; omega))]
      exact hr_M_f2
  have hlifts_3 : HasLiftArrays p pts_h (wsOf ha_w1) := by
    refine hasLiftArrays_of_eq hlifts fun v idx hv => ?_
    have hne0 : v ≠ 0 := by rcases hv with rfl | rfl <;> decide
    have hne1 : v ≠ 1 := by rcases hv with rfl | rfl <;> decide
    have hne9 : v ≠ 9 := by rcases hv with rfl | rfl <;> decide
    have hne99 : v ≠ 99 := by rcases hv with rfl | rfl <;> decide
    rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ heq _; exact hne0 heq),
      wordStore_read_write_of_ne _ (by intro hc; injection hc with _ heq _; exact hne1 heq),
      wordStore_read_write_of_ne _ (by intro hc; injection hc with _ heq _; exact hne1 heq),
      wordStore_read_write_of_ne _ (by intro hc; injection hc with _ heq _; exact hne1 heq),
      wordStore_read_free_of_ne _ (by intro hc; nomatch hc),
      wordStore_read_free_of_ne _ (by intro hc; nomatch hc),
      wordStore_read_free_of_ne _ (by intro hc; nomatch hc),
      hoth_sub _ (by intro hc; injection hc with _ heq _; exact hne0 heq)
        (by intro hc; injection hc with _ heq _; exact hne9 heq)
        (by intro hc; injection hc with _ heq _; exact hne99 heq)
        (fun _ hj => by omega)]
    simp [rw_write_eq, rf_free_eq]
  -- Bound the local bit costs by `1000000 * (V + natBitLength T_sz + 16) ^ 2`
  let Z := V + natBitLength T_sz + 16
  have hVZ : V + 8 ≤ Z := by dsimp [Z]; omega
  have hYZ : (V + 8) ^ 2 ≤ Z ^ 2 := Nat.pow_le_pow_left hVZ 2
  have hsub_tail : 4 * (32 * (natBitLength A + natBitLength T_sz + V + 16) ^ 2) ≤ 512 * Z ^ 2 := by
    have h1 : natBitLength A + natBitLength T_sz + V + 16 ≤ 2 * Z := by dsimp [Z]; omega
    calc 4 * (32 * (natBitLength A + natBitLength T_sz + V + 16) ^ 2)
        ≤ 4 * (32 * (2 * Z) ^ 2) := Nat.mul_le_mul_left 4 (Nat.mul_le_mul_left 32 (Nat.pow_le_pow_left h1 2))
      _ = 512 * Z ^ 2 := by ring
  have hcl_M : 64 * (Nat.clog 2 (M + 1) + natBitLength (M + 1) + 16) ^ 2 ≤ 256 * Z ^ 2 := by
    have hnb_m1 : natBitLength (M + 1) ≤ V := by
      unfold intBitLength at hM1_V
      rw [if_neg (by positivity), Int.natAbs_natCast] at hM1_V
      omega
    have h1 : Nat.clog 2 (M + 1) + natBitLength (M + 1) + 16 ≤ 2 * Z := by dsimp [Z]; omega
    calc 64 * (Nat.clog 2 (M + 1) + natBitLength (M + 1) + 16) ^ 2
        ≤ 64 * (2 * Z) ^ 2 := Nat.mul_le_mul_left 64 (Nat.pow_le_pow_left h1 2)
      _ = 256 * Z ^ 2 := by ring
  refine ⟨_, ha_w1, hhz_3, hregs_3, hlifts_3,
    ExecBounded.mono ex_all (by omega) ?_ le_rfl le_rfl⟩
  have h8 : 8 * (66000 * (V + 8) ^ 2) ≤ 528000 * Z ^ 2 := by
    calc 8 * (66000 * (V + 8) ^ 2) = 528000 * (V + 8) ^ 2 := by ring
      _ ≤ 528000 * Z ^ 2 := Nat.mul_le_mul_left 528000 hYZ
  dsimp only [Z] at hsub_tail hcl_M h8
  omega

end UL.Proof_lem_A_2

