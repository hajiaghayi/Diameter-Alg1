import Mathlib
import UL.Proof.lem_A_2.H1a_Math
set_option autoImplicit false

namespace UL.Proof_lem_A_2

/-! ### 4. Forward Fisher–Yates bijection and uniform block marginals -/

/-- Forward Fisher–Yates tail from step `m - rem` to `m - 1`. -/
def fyTail {m : ℕ} : (rem : ℕ) → rem ≤ m → Equiv.Perm (Fin m) →
    ((i : Fin m) → Fin (m - i.1)) → Equiv.Perm (Fin m)
  | 0, _, π, _ => π
  | rem + 1, hrem, π, u =>
      let k : ℕ := m - (rem + 1)
      have hk : k < m := by omega
      let ik : Fin m := ⟨k, hk⟩
      let jk : Fin m := ⟨k + (u ik).1, by
        have hlt : (u ik).1 < m - k := (u ik).2
        omega⟩
      fyTail rem (Nat.le_of_succ_le hrem) ((Equiv.swap ik jk).trans π) u

theorem fyTail_apply_lt {m : ℕ} :
    ∀ (rem : ℕ) (hrem : rem ≤ m) (π : Equiv.Perm (Fin m))
      (u : (i : Fin m) → Fin (m - i.1)) (x : Fin m),
      x.1 < m - rem → fyTail rem hrem π u x = π x := by
  intro rem
  induction rem with
  | zero =>
      intro _ _ _ _ _
      rfl
  | succ rem ih =>
      intro hrem π u x hx
      unfold fyTail
      dsimp only
      let k : ℕ := m - (rem + 1)
      have hxk : x.1 < k := hx
      have hx_lt_rem : x.1 < m - rem := by omega
      rw [ih (Nat.le_of_succ_le hrem) _ u x hx_lt_rem]
      simp only [Equiv.trans_apply]
      congr 1
      apply Equiv.swap_apply_of_ne_of_ne
      · intro heq
        have := congrArg Fin.val heq
        dsimp at this
        omega
      · intro heq
        have := congrArg Fin.val heq
        dsimp at this
        omega

theorem fyTail_injective_aux {m : ℕ} :
    ∀ (rem : ℕ) (hrem : rem ≤ m) (π : Equiv.Perm (Fin m))
      {u u' : (i : Fin m) → Fin (m - i.1)},
      (∀ i : Fin m, i.1 < m - rem → u i = u' i) →
      fyTail rem hrem π u = fyTail rem hrem π u' →
      u = u' := by
  intro rem
  induction rem with
  | zero =>
      intro _ _ u u' hpre _
      funext i
      exact hpre i (by simp [i.2])
  | succ rem ih =>
      intro hrem π u u' hpre heq
      unfold fyTail at heq
      dsimp only at heq
      set k : ℕ := m - (rem + 1)
      have hk : k < m := by omega
      let ik : Fin m := ⟨k, hk⟩
      have hik_lt : ik.1 < m - rem := by dsimp [ik]; omega
      let jk₁ : Fin m := ⟨k + (u ik).1, by have hlt : (u ik).1 < m - k := (u ik).2; omega⟩
      let jk₂ : Fin m := ⟨k + (u' ik).1, by have hlt : (u' ik).1 < m - k := (u' ik).2; omega⟩
      have heq' :
          fyTail rem (Nat.le_of_succ_le hrem) ((Equiv.swap ik jk₁).trans π) u =
          fyTail rem (Nat.le_of_succ_le hrem) ((Equiv.swap ik jk₂).trans π) u' := heq
      have heval :
          fyTail rem (Nat.le_of_succ_le hrem) ((Equiv.swap ik jk₁).trans π) u ik =
          fyTail rem (Nat.le_of_succ_le hrem) ((Equiv.swap ik jk₂).trans π) u' ik :=
        congrFun (congrArg DFunLike.coe heq') ik
      rw [fyTail_apply_lt rem _ _ u ik hik_lt, fyTail_apply_lt rem _ _ u' ik hik_lt] at heval
      simp only [Equiv.trans_apply, Equiv.swap_apply_left] at heval
      have hjk_fin : jk₁ = jk₂ := π.injective heval
      have hjk_eq : k + (u ik).1 = k + (u' ik).1 := congrArg Fin.val hjk_fin
      have hu_ik : u ik = u' ik := Fin.ext (by omega)
      rw [hjk_fin] at heq'
      refine ih (Nat.le_of_succ_le hrem) _ (fun i hi => ?_) heq'
      rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp (by omega : i.1 < k + 1)) with hlt | h_eq
      · exact hpre i hlt
      · have hi_eq : i = ik := Fin.ext h_eq
        rw [hi_eq]
        exact hu_ik

/-- Full forward Fisher–Yates map on `Fin m`. -/
def fyPerm {m : ℕ} (u : (i : Fin m) → Fin (m - i.1)) : Equiv.Perm (Fin m) :=
  fyTail m le_rfl (Equiv.refl (Fin m)) u

private theorem card_fyDomain :
    ∀ m : ℕ, Fintype.card ((i : Fin m) → Fin (m - i.1)) = m.factorial := by
  intro m
  rw [Fintype.card_pi]
  simp only [Fintype.card_fin]
  induction m with
  | zero => simp
  | succ m ih =>
      rw [Fin.prod_univ_succ]
      simp only [Fin.val_zero, Nat.sub_zero, Fin.val_succ, Nat.succ_sub_succ_eq_sub]
      rw [ih, Nat.factorial_succ]

theorem fyPerm_bijective (m : ℕ) :
    Function.Bijective (fyPerm (m := m)) := by
  rw [Fintype.bijective_iff_injective_and_card]
  refine ⟨fun u u' heq => fyTail_injective_aux m le_rfl _ (fun _ h => by simp at h) heq, ?_⟩
  rw [card_fyDomain, Fintype.card_perm, Fintype.card_fin]

/-- Slice `b` of size `s₀` inside `Fin m` when `r * s₀ ≤ m`. -/
def sliceBlockSet {m r s₀ : ℕ} (hrs : r * s₀ ≤ m) (π : Equiv.Perm (Fin m)) (b : Fin r) :
    Finset (Fin m) :=
  Finset.univ.image (fun j : Fin s₀ =>
    π ⟨b.1 * s₀ + j.1, by
      have hb : (b.1 + 1) * s₀ ≤ r * s₀ := Nat.mul_le_mul_right s₀ b.2
      have hj : j.1 < s₀ := j.2
      nlinarith⟩)

private noncomputable def permTakingFinset {m s₀ : ℕ} {S₁ S₂ : Finset (Fin m)}
    (h₁ : S₁.card = s₀) (h₂ : S₂.card = s₀) :
    {σ : Equiv.Perm (Fin m) // S₁.image σ = S₂} := by
  classical
  let e₁ : ↥S₁ ≃ ↥S₂ := Finset.equivOfCardEq (h₁.trans h₂.symm)
  have hc : (S₁ᶜ).card = (S₂ᶜ).card := by
    rw [Finset.card_compl, Finset.card_compl, h₁, h₂]
  let e₂ : ↥(S₁ᶜ) ≃ ↥(S₂ᶜ) := Finset.equivOfCardEq hc
  let σ : Equiv.Perm (Fin m) :=
    { toFun := fun x =>
        if hx : x ∈ S₁ then (e₁ ⟨x, hx⟩).1 else (e₂ ⟨x, Finset.mem_compl.mpr hx⟩).1
      invFun := fun y =>
        if hy : y ∈ S₂ then (e₁.symm ⟨y, hy⟩).1 else (e₂.symm ⟨y, Finset.mem_compl.mpr hy⟩).1
      left_inv := fun x => by
        by_cases hx : x ∈ S₁
        · have hy : (e₁ ⟨x, hx⟩).1 ∈ S₂ := (e₁ ⟨x, hx⟩).2
          simp [hx, hy]
        · have hy : (e₂ ⟨x, Finset.mem_compl.mpr hx⟩).1 ∉ S₂ :=
            Finset.mem_compl.mp (e₂ ⟨x, Finset.mem_compl.mpr hx⟩).2
          simp [hx, hy]
      right_inv := fun y => by
        by_cases hy : y ∈ S₂
        · have hx : (e₁.symm ⟨y, hy⟩).1 ∈ S₁ := (e₁.symm ⟨y, hy⟩).2
          simp [hy, hx]
        · have hx : (e₂.symm ⟨y, Finset.mem_compl.mpr hy⟩).1 ∉ S₁ :=
            Finset.mem_compl.mp (e₂.symm ⟨y, Finset.mem_compl.mpr hy⟩).2
          simp [hy, hx] }
  refine ⟨σ, ?_⟩
  ext y
  simp only [Finset.mem_image]
  constructor
  · rintro ⟨x, hx, rfl⟩
    dsimp [σ]
    rw [dif_pos hx]
    exact (e₁ ⟨x, hx⟩).2
  · intro hy
    let x := e₁.symm ⟨y, hy⟩
    refine ⟨x.1, x.2, ?_⟩
    dsimp [σ]
    rw [dif_pos x.2, Equiv.apply_symm_apply]

theorem sliceBlockSet_card {m r s₀ : ℕ} (hrs : r * s₀ ≤ m)
    (π : Equiv.Perm (Fin m)) (b : Fin r) :
    (sliceBlockSet hrs π b).card = s₀ := by
  unfold sliceBlockSet
  have hinj : Function.Injective (fun j : Fin s₀ =>
      π ⟨b.1 * s₀ + j.1, by
        have hb : (b.1 + 1) * s₀ ≤ r * s₀ := Nat.mul_le_mul_right s₀ b.2
        have hj : j.1 < s₀ := j.2
        nlinarith⟩) := by
    intro j₁ j₂ heq
    have hval := congrArg Fin.val (π.injective heq)
    dsimp at hval
    exact Fin.ext (by omega)
  rw [Finset.card_image_of_injective _ hinj, Finset.card_univ, Fintype.card_fin]

theorem fyPerm_block_prob_eq {m r s₀ : ℕ} (hrs : r * s₀ ≤ m) (b : Fin r)
    (P : Finset (Fin m) → Bool) :
    ((Finset.univ.filter (fun u : (i : Fin m) → Fin (m - i.1) =>
        P (sliceBlockSet hrs (fyPerm u) b) = true)).card : ℝ) /
      (Fintype.card ((i : Fin m) → Fin (m - i.1)) : ℝ) =
    ((((Finset.univ : Finset (Fin m)).powersetCard s₀).filter
        (fun S => P S = true)).card : ℝ) /
      (((Finset.univ : Finset (Fin m)).powersetCard s₀).card : ℝ) := by
  classical
  let fyEquiv : ((i : Fin m) → Fin (m - i.1)) ≃ Equiv.Perm (Fin m) :=
    Equiv.ofBijective fyPerm (fyPerm_bijective m)
  let powS : Finset (Finset (Fin m)) := (Finset.univ : Finset (Fin m)).powersetCard s₀
  have hS0_mem : sliceBlockSet hrs (Equiv.refl (Fin m)) b ∈ powS := by
    rw [Finset.mem_powersetCard]
    exact ⟨Finset.subset_univ _, sliceBlockSet_card hrs _ b⟩
  let S₀ := sliceBlockSet hrs (Equiv.refl (Fin m)) b
  let fiber : Finset (Fin m) → Finset (Equiv.Perm (Fin m)) :=
    fun S => Finset.univ.filter (fun π => sliceBlockSet hrs π b = S)
  let c : ℕ := (fiber S₀).card
  have hfiber_const : ∀ S ∈ powS, (fiber S).card = c := by
    intro S hS
    have hS_card : S.card = s₀ := (Finset.mem_powersetCard.mp hS).2
    have hS0_card : S₀.card = s₀ := (Finset.mem_powersetCard.mp hS0_mem).2
    obtain ⟨σ, hσ⟩ := permTakingFinset hS0_card hS_card
    symm
    refine Finset.card_bij (fun π _ => π.trans σ) ?_ ?_ ?_
    · intro π hπ
      have hπS0 : sliceBlockSet hrs π b = S₀ := (Finset.mem_filter.mp hπ).2
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
      have himg : sliceBlockSet hrs (π.trans σ) b = (sliceBlockSet hrs π b).image σ := by
        unfold sliceBlockSet
        rw [Finset.image_image]
        rfl
      rw [himg, hπS0, hσ]
    · intro π₁ _ π₂ _ heq
      exact Equiv.ext fun x => σ.injective (congrFun (congrArg DFunLike.coe heq) x)
    · intro π' hπ'
      have hπ'S : sliceBlockSet hrs π' b = S := (Finset.mem_filter.mp hπ').2
      refine ⟨π'.trans σ.symm, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, ?_⟩
      · apply Finset.image_injective σ.injective
        have himg : (sliceBlockSet hrs (π'.trans σ.symm) b).image σ = sliceBlockSet hrs π' b := by
          unfold sliceBlockSet
          rw [Finset.image_image]
          ext y
          simp
        rw [himg, hπ'S, hσ]
      · ext x
        simp
  have huniv_card : Fintype.card (Equiv.Perm (Fin m)) = powS.card * c := by
    have hbi : (Finset.univ : Finset (Equiv.Perm (Fin m))) = powS.biUnion fiber := by
      ext π
      simp only [Finset.mem_univ, Finset.mem_biUnion, true_iff]
      refine ⟨sliceBlockSet hrs π b, ?_, Finset.mem_filter.mpr ⟨Finset.mem_univ _, rfl⟩⟩
      rw [Finset.mem_powersetCard]
      exact ⟨Finset.subset_univ _, sliceBlockSet_card hrs π b⟩
    have hdisj : (powS : Set (Finset (Fin m))).PairwiseDisjoint fiber := by
      intro S₁ _ S₂ _ hne
      dsimp [Function.onFun]
      rw [Finset.disjoint_left]
      intro π h₁ h₂
      exact hne ((Finset.mem_filter.mp h₁).2.symm.trans (Finset.mem_filter.mp h₂).2)
    rw [← Finset.card_univ, hbi, Finset.card_biUnion hdisj]
    calc
      ∑ S ∈ powS, (fiber S).card = ∑ _S ∈ powS, c := Finset.sum_congr rfl hfiber_const
      _ = powS.card * c := by simp
  have hfilt_perm :
      (Finset.univ.filter (fun u => P (sliceBlockSet hrs (fyPerm u) b) = true)).card =
        (powS.filter (fun S => P S = true)).card * c := by
    have heq_perm :
        (Finset.univ.filter (fun u => P (sliceBlockSet hrs (fyPerm u) b) = true)).card =
          (Finset.univ.filter (fun π : Equiv.Perm (Fin m) =>
            P (sliceBlockSet hrs π b) = true)).card := by
      refine Finset.card_bij (fun u _ => fyEquiv u) ?_ ?_ ?_
      · intro u hu
        exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hu).2⟩
      · intro u₁ _ u₂ _ h
        exact fyEquiv.injective h
      · intro π hπ
        refine ⟨fyEquiv.symm π, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩,
          fyEquiv.apply_symm_apply π⟩
        have hfy : fyPerm (fyEquiv.symm π) = π := fyEquiv.apply_symm_apply π
        rw [hfy]
        exact (Finset.mem_filter.mp hπ).2
    rw [heq_perm]
    have hbi :
        Finset.univ.filter (fun π : Equiv.Perm (Fin m) => P (sliceBlockSet hrs π b) = true) =
          (powS.filter (fun S => P S = true)).biUnion fiber := by
      ext π
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_biUnion]
      constructor
      · intro hP
        refine ⟨sliceBlockSet hrs π b, ⟨?_, hP⟩, Finset.mem_filter.mpr ⟨Finset.mem_univ _, rfl⟩⟩
        rw [Finset.mem_powersetCard]
        exact ⟨Finset.subset_univ _, sliceBlockSet_card hrs π b⟩
      · rintro ⟨S, ⟨_, hPS⟩, hmem⟩
        rwa [(Finset.mem_filter.mp hmem).2]
    have hdisj : ((powS.filter (fun S => P S = true)) : Set (Finset (Fin m))).PairwiseDisjoint fiber := by
      intro S₁ _ S₂ _ hne
      dsimp [Function.onFun]
      rw [Finset.disjoint_left]
      intro π h₁ h₂
      exact hne ((Finset.mem_filter.mp h₁).2.symm.trans (Finset.mem_filter.mp h₂).2)
    rw [hbi, Finset.card_biUnion hdisj]
    calc
      ∑ S ∈ powS.filter (fun S => P S = true), (fiber S).card
          = ∑ _S ∈ powS.filter (fun S => P S = true), c :=
            Finset.sum_congr rfl fun S hS => hfiber_const S (Finset.mem_of_mem_filter S hS)
      _ = (powS.filter (fun S => P S = true)).card * c := by simp
  have hc_pos : 0 < c := by
    have hperm_pos : 0 < Fintype.card (Equiv.Perm (Fin m)) := Fintype.card_pos
    rw [huniv_card] at hperm_pos
    exact Nat.pos_of_mul_pos_left hperm_pos
  have hc_ne : (c : ℝ) ≠ 0 := by exact_mod_cast hc_pos.ne'
  have hdom_eq : Fintype.card ((i : Fin m) → Fin (m - i.1)) = powS.card * c := by
    rw [Fintype.card_congr fyEquiv, huniv_card]
  rw [hfilt_perm, hdom_eq]
  push_cast
  exact mul_div_mul_right _ _ hc_ne


end UL.Proof_lem_A_2
