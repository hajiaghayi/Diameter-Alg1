import Mathlib
import UL.Stmt.lem_A_2
import UL.Stmt.cit_hw87_halfspace_net
import UL.Stmt.cit_gls88_rational_lp
import UL.Stmt.lem_A_1
import UL.Proof.lem_A_2.RacerP54_H3h
set_option autoImplicit false
set_option maxHeartbeats 4000000

namespace UL.Proof_lem_A_2

/-! ### 1. Compositional `IsBoundedByPoly2` & `IsNatPoly2` combinators -/

def IsNatPoly2 (F : ℕ → ℕ → ℕ) : Prop :=
  IsBoundedByPoly2 (fun d B => (F d B : ℝ))

theorem poly2_mono {f g : ℕ → ℕ → ℝ} (hg : IsBoundedByPoly2 g)
    (hle : ∀ d B : ℕ, f d B ≤ g d B) : IsBoundedByPoly2 f := by
  rcases hg with ⟨C, deg, hC, hg'⟩
  exact ⟨C, deg, hC, fun d B => (hle d B).trans (hg' d B)⟩

theorem poly2_add {f g : ℕ → ℕ → ℝ} (hf : IsBoundedByPoly2 f) (hg : IsBoundedByPoly2 g) :
    IsBoundedByPoly2 (fun d B => f d B + g d B) := by
  rcases hf with ⟨C₁, k₁, hC₁, hf'⟩
  rcases hg with ⟨C₂, k₂, hC₂, hg'⟩
  refine ⟨C₁ + C₂, max k₁ k₂, add_nonneg hC₁ hC₂, fun d B => ?_⟩
  have hd1 : (1 : ℝ) ≤ (d + 1 : ℝ) := by linarith
  have hB1 : (1 : ℝ) ≤ (B + 1 : ℝ) := by linarith
  have hp1 : ((d + 1 : ℝ) ^ k₁) * ((B + 1 : ℝ) ^ k₁) ≤
      ((d + 1 : ℝ) ^ max k₁ k₂) * ((B + 1 : ℝ) ^ max k₁ k₂) :=
    mul_le_mul (pow_le_pow_right₀ hd1 (le_max_left _ _))
      (pow_le_pow_right₀ hB1 (le_max_left _ _)) (by positivity) (by positivity)
  have hp2 : ((d + 1 : ℝ) ^ k₂) * ((B + 1 : ℝ) ^ k₂) ≤
      ((d + 1 : ℝ) ^ max k₁ k₂) * ((B + 1 : ℝ) ^ max k₁ k₂) :=
    mul_le_mul (pow_le_pow_right₀ hd1 (le_max_right _ _))
      (pow_le_pow_right₀ hB1 (le_max_right _ _)) (by positivity) (by positivity)
  calc f d B + g d B
      ≤ C₁ * ((d + 1 : ℝ) ^ k₁) * ((B + 1 : ℝ) ^ k₁) +
          C₂ * ((d + 1 : ℝ) ^ k₂) * ((B + 1 : ℝ) ^ k₂) := add_le_add (hf' d B) (hg' d B)
    _ = C₁ * (((d + 1 : ℝ) ^ k₁) * ((B + 1 : ℝ) ^ k₁)) +
          C₂ * (((d + 1 : ℝ) ^ k₂) * ((B + 1 : ℝ) ^ k₂)) := by ring
    _ ≤ C₁ * (((d + 1 : ℝ) ^ max k₁ k₂) * ((B + 1 : ℝ) ^ max k₁ k₂)) +
          C₂ * (((d + 1 : ℝ) ^ max k₁ k₂) * ((B + 1 : ℝ) ^ max k₁ k₂)) :=
        add_le_add (mul_le_mul_of_nonneg_left hp1 hC₁) (mul_le_mul_of_nonneg_left hp2 hC₂)
    _ = (C₁ + C₂) * ((d + 1 : ℝ) ^ max k₁ k₂) * ((B + 1 : ℝ) ^ max k₁ k₂) := by ring

theorem poly2_mul {f g : ℕ → ℕ → ℝ} (hf : IsBoundedByPoly2 f) (hg : IsBoundedByPoly2 g)
    (hg0 : ∀ d B : ℕ, 0 ≤ g d B) :
    IsBoundedByPoly2 (fun d B => f d B * g d B) := by
  rcases hf with ⟨C₁, k₁, hC₁, hf'⟩
  rcases hg with ⟨C₂, k₂, hC₂, hg'⟩
  refine ⟨C₁ * C₂, k₁ + k₂, mul_nonneg hC₁ hC₂, fun d B => ?_⟩
  calc f d B * g d B
      ≤ (C₁ * ((d + 1 : ℝ) ^ k₁) * ((B + 1 : ℝ) ^ k₁)) *
          (C₂ * ((d + 1 : ℝ) ^ k₂) * ((B + 1 : ℝ) ^ k₂)) :=
        mul_le_mul (hf' d B) (hg' d B) (hg0 d B) (by positivity)
    _ = C₁ * C₂ * ((d + 1 : ℝ) ^ (k₁ + k₂)) * ((B + 1 : ℝ) ^ (k₁ + k₂)) := by
        rw [pow_add, pow_add]; ring

theorem natPoly2_const (c : ℕ) : IsNatPoly2 (fun _ _ => c) :=
  ⟨(c : ℝ), 0, Nat.cast_nonneg c, fun _ _ => by simp⟩

theorem natPoly2_d : IsNatPoly2 (fun d _ => d) := by
  refine ⟨1, 1, zero_le_one, fun d B => ?_⟩
  simp only [pow_one, one_mul]
  have hd : (d : ℝ) ≤ (d : ℝ) + 1 := by linarith
  have hB : (1 : ℝ) ≤ (B : ℝ) + 1 := by linarith
  calc (d : ℝ) = (d : ℝ) * 1 := (mul_one _).symm
    _ ≤ ((d : ℝ) + 1) * ((B : ℝ) + 1) := mul_le_mul hd hB zero_le_one (by positivity)

theorem natPoly2_B : IsNatPoly2 (fun _ B => B) := by
  refine ⟨1, 1, zero_le_one, fun d B => ?_⟩
  simp only [pow_one, one_mul]
  have hd : (1 : ℝ) ≤ (d : ℝ) + 1 := by linarith
  have hB : (B : ℝ) ≤ (B : ℝ) + 1 := by linarith
  calc (B : ℝ) = 1 * (B : ℝ) := (one_mul _).symm
    _ ≤ ((d : ℝ) + 1) * ((B : ℝ) + 1) := mul_le_mul hd hB (Nat.cast_nonneg B) (by positivity)

theorem natPoly2_mono {F G : ℕ → ℕ → ℕ} (hG : IsNatPoly2 G)
    (hle : ∀ d B : ℕ, F d B ≤ G d B) : IsNatPoly2 F :=
  poly2_mono hG (fun d B => by exact_mod_cast hle d B)

theorem natPoly2_add {F G : ℕ → ℕ → ℕ} (hF : IsNatPoly2 F) (hG : IsNatPoly2 G) :
    IsNatPoly2 (fun d B => F d B + G d B) :=
  poly2_mono (poly2_add hF hG) (fun d B => by push_cast; exact le_rfl)

theorem natPoly2_mul {F G : ℕ → ℕ → ℕ} (hF : IsNatPoly2 F) (hG : IsNatPoly2 G) :
    IsNatPoly2 (fun d B => F d B * G d B) :=
  poly2_mono (poly2_mul hF hG (fun _ _ => Nat.cast_nonneg _))
    (fun d B => by push_cast; exact le_rfl)

theorem natPoly2_pow {F : ℕ → ℕ → ℕ} (hF : IsNatPoly2 F) :
    ∀ k : ℕ, IsNatPoly2 (fun d B => (F d B) ^ k)
  | 0 => natPoly2_const 1
  | k + 1 =>
      natPoly2_mono (natPoly2_mul (natPoly2_pow hF k) hF)
        (fun d B => by rw [pow_succ])

theorem natPoly2_bitLen {F : ℕ → ℕ → ℕ} (hF : IsNatPoly2 F) :
    IsNatPoly2 (fun d B => natBitLength (F d B)) :=
  natPoly2_mono (natPoly2_add hF (natPoly2_const 1)) (fun d B => natBitLength_le (F d B))

/-! ### 2. Elementary `Nat.clog 2`, `convexHull`, and block-injectivity helpers -/

theorem clog2_le_self (n : ℕ) : Nat.clog 2 n ≤ n := by
  by_contra hlt
  have hgt : n < Nat.clog 2 n := Nat.lt_of_not_ge hlt
  have hpow : 2 ^ n < n := (Nat.lt_clog_iff_pow_lt (by norm_num)).mp hgt
  have hself : n < 2 ^ n := Nat.lt_pow_self (by norm_num : 1 < 2)
  omega

theorem two_le_clog2_of_four_le {n : ℕ} (h : 4 ≤ n) : 2 ≤ Nat.clog 2 n := by
  have hlt : 1 < Nat.clog 2 n := (Nat.lt_clog_iff_pow_lt (by norm_num)).mpr (by omega)
  omega

theorem natBitLength_two_pow_le (k : ℕ) : natBitLength (2 ^ k) ≤ k + 1 :=
  natBitLength_le_of_lt_two_pow (by omega : 1 ≤ k + 1)
    (Nat.pow_lt_pow_right (by norm_num) (Nat.lt_succ_self k))

theorem ratPointBitBounded_mono {d B₁ B₂ : ℕ} (h : B₁ ≤ B₂) {q : Fin d → ℚ}
    (hq : RatPointBitBounded B₁ q) : RatPointBitBounded B₂ q :=
  fun i => ⟨(hq i).1.trans h, (hq i).2.trans h⟩

theorem convex_comb_mem_convexHull {D : ℕ} {κ : Type _} [DecidableEq κ]
    (f : κ → EuclideanSpace ℝ (Fin D)) :
    ∀ (s : Finset κ) (w : κ → ℝ),
      (∀ j ∈ s, 0 ≤ w j) →
      ∑ j ∈ s, w j = 1 →
      ∑ j ∈ s, w j • f j ∈ convexHull ℝ (Set.range f) := by
  intro s
  induction s using Finset.induction with
  | empty =>
      intro w _ h1
      simp at h1
  | @insert a t ha ih =>
      intro w hw0 hsum
      rw [Finset.sum_insert ha] at hsum ⊢
      let c : ℝ := ∑ j ∈ t, w j
      have hc_nn : 0 ≤ c := Finset.sum_nonneg (fun j hj => hw0 j (Finset.mem_insert_of_mem hj))
      have hwa_nn : 0 ≤ w a := hw0 a (Finset.mem_insert_self a t)
      have hfa : f a ∈ convexHull ℝ (Set.range f) := subset_convexHull ℝ _ ⟨a, rfl⟩
      by_cases hc0 : c = 0
      · have hj0 : ∀ j ∈ t, w j = 0 :=
          (Finset.sum_eq_zero_iff_of_nonneg (fun j hj => hw0 j (Finset.mem_insert_of_mem hj))).mp hc0
        have hvec0 : ∑ j ∈ t, w j • f j = 0 :=
          Finset.sum_eq_zero (fun j hj => by rw [hj0 j hj, zero_smul])
        have hwa1 : w a = 1 := by dsimp [c] at hc0; linarith
        rw [hvec0, add_zero, hwa1, one_smul]
        exact hfa
      · have hc_pos : 0 < c := lt_of_le_of_ne hc_nn (Ne.symm hc0)
        let w' : κ → ℝ := fun j => w j / c
        have hw'0 : ∀ j ∈ t, 0 ≤ w' j := fun j hj =>
          div_nonneg (hw0 j (Finset.mem_insert_of_mem hj)) hc_nn
        have hw'1 : ∑ j ∈ t, w' j = 1 := by
          dsimp [w']
          simp_rw [div_eq_mul_inv]
          rw [← Finset.sum_mul]
          exact mul_inv_cancel₀ hc0
        have hy : ∑ j ∈ t, w' j • f j ∈ convexHull ℝ (Set.range f) := ih w' hw'0 hw'1
        have hcy : c • ∑ j ∈ t, w' j • f j = ∑ j ∈ t, w j • f j := by
          rw [Finset.smul_sum]
          refine Finset.sum_congr rfl fun j _ => ?_
          rw [smul_smul, mul_div_cancel₀ _ hc0]
        rw [← hcy]
        exact (convex_convexHull ℝ (Set.range f)) hfa hy hwa_nn hc_nn hsum

theorem hasConvexHullCert_iff_mem_convexHull {D : ℕ} {κ : Type _} [Fintype κ] [DecidableEq κ]
    (f : κ → EuclideanSpace ℝ (Fin D)) (z : EuclideanSpace ℝ (Fin D)) :
    HasConvexHullCert f z ↔ z ∈ convexHull ℝ (Set.range f) := by
  constructor
  · rintro ⟨w, hw0, hw1, hwz⟩
    rw [← hwz]
    exact convex_comb_mem_convexHull f Finset.univ w (fun j _ => hw0 j) hw1
  · exact mem_convexHull_range_imp_hasConvexHullCert f

theorem blkHandle_pair_injective (p : CoreParams)
    (π : Equiv.Perm (Fin p.m)) {L_pass : List (Fin p.r)} (hnodup : L_pass.Nodup) :
    Function.Injective
      (fun x : Fin L_pass.length × Fin p.s₀ => blkHandle p π L_pass[x.1.1] x.2) := by
  rintro ⟨i₁, j₁⟩ ⟨i₂, j₂⟩ heq
  dsimp [blkHandle] at heq
  have hfin := π.injective heq
  have hval : (L_pass[i₁.1]).1 * p.s₀ + j₁.1 = (L_pass[i₂.1]).1 * p.s₀ + j₂.1 :=
    congrArg Fin.val hfin
  have hj1 := j₁.2
  have hj2 := j₂.2
  have hb_eq_val : (L_pass[i₁.1]).1 = (L_pass[i₂.1]).1 := by
    by_contra hne
    rcases lt_or_gt_of_ne hne with hlt | hgt
    · have hle : ((L_pass[i₁.1]).1 + 1) * p.s₀ ≤ (L_pass[i₂.1]).1 * p.s₀ :=
        Nat.mul_le_mul_right p.s₀ hlt
      rw [Nat.add_mul, Nat.one_mul] at hle
      omega
    · have hle : ((L_pass[i₂.1]).1 + 1) * p.s₀ ≤ (L_pass[i₁.1]).1 * p.s₀ :=
        Nat.mul_le_mul_right p.s₀ hgt
      rw [Nat.add_mul, Nat.one_mul] at hle
      omega
  have hj_eq_val : j₁.1 = j₂.1 := by rw [hb_eq_val] at hval; omega
  have hb_eq : L_pass[i₁.1] = L_pass[i₂.1] := Fin.ext hb_eq_val
  have hi_eq_val : i₁.1 = i₂.1 := (hnodup.getElem_inj_iff).mp hb_eq
  exact Prod.ext (Fin.ext hi_eq_val) (Fin.ext hj_eq_val)

/-! ### 3. Polynomial capacity envelopes (`spaceCapNat`, `timeCapNat`, `bitLenCapNat`) -/

section Caps

variable (K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c : ℕ)

def s0Fn (d _B : ℕ) : ℕ := s₀Val K deg_α d
def bLiftFn (d B : ℕ) : ℕ := bLiftVal d B
def lzFn (d B : ℕ) : ℕ := C_z * (d + 2) ^ deg_alg * (bLiftVal d B + 1) ^ deg_alg
def ucertFn (d B : ℕ) : ℕ :=
  C_cert * (d + 1 + s0Fn K deg_α d B + (bLiftFn d B + lzFn C_z deg_alg d B) + 1) ^ deg_cert
def qaFn (d B : ℕ) : ℕ :=
  4 + (lzFn C_z deg_alg d B + s0Fn K deg_α d B + 4) * (d + 1) + 64
def qvFn (d B : ℕ) : ℕ :=
  natBitLength (qaFn K deg_α C_z deg_alg d B) +
  4 * bLiftFn d B + 4 * lzFn C_z deg_alg d B +
  2 * ucertFn K deg_α C_z deg_alg C_cert deg_cert d B +
  2 * s0Fn K deg_α d B + 2 * deg_α + 2 * deg_alg + 2 * k_φ + 128

def bitLenCapNat (d B : ℕ) : ℕ :=
  2 * lzFn C_z deg_alg d B + ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 2

def subBitExtra (d B : ℕ) : ℕ :=
  let U₁ := lzFn C_z deg_alg d B
  let U₃ := ucertFn K deg_α C_z deg_alg C_cert deg_cert d B
  ((natBitLength T_sz + 12) * U₁ +
    (U₁ + 3) * (natBitLength (U₁ + 2) + U₁ + 2 * natBitLength T_sz + 18) +
    2 * natBitLength (U₁ + 2) + 64) +
  ((natBitLength T_A1 + 12) * U₁ +
    (U₁ + 3) * (natBitLength (U₁ + 2) + U₁ + 2 * natBitLength T_A1 + 18) +
    2 * natBitLength (U₁ + 2) + 64) +
  ((natBitLength T_c + 12) * U₃ +
    (U₃ + 3) * (natBitLength (U₃ + 2) + U₃ + 2 * natBitLength T_c + 18) +
    2 * natBitLength (U₃ + 2) + 64)

def spaceCapNat (d B : ℕ) : ℕ :=
  let QA := qaFn K deg_α C_z deg_alg d B
  let QV := qvFn K deg_α C_z deg_alg k_φ C_cert deg_cert d B
  let U₁ := lzFn C_z deg_alg d B
  let U₃ := ucertFn K deg_α C_z deg_alg C_cert deg_cert d B
  (2 * d * B + 3 * d + B + 16) +
  108 * QA * (5 + QA + QV + 20) +
  4 * U₁ + 2 * U₃ +
  subBitExtra K deg_α C_z deg_alg C_cert deg_cert T_sz T_A1 T_c d B + 16

def vCoefNat (d B : ℕ) : ℕ :=
  4 + qvFn K deg_α C_z deg_alg k_φ C_cert deg_cert d B +
  natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 24

def timeCapNat (d B : ℕ) : ℕ :=
  let S0 := s0Fn K deg_α d B
  let BL := bLiftFn d B
  let LZ := lzFn C_z deg_alg d B
  let UC := ucertFn K deg_α C_z deg_alg C_cert deg_cert d B
  let VC := vCoefNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c d B
  let U_poly : ℕ :=
    (64 + 400 * (deg_α + deg_alg + 16)) +
    (300 + (1000 + 500 * d + 60 * BL)) +
    (80 * F_sz * (LZ + 1) + 32 * (LZ + 2) + 1000) +
    (2000 + LZ * (1200 + 600 * d + 24 * (LZ + 12)) +
      (d + 1) * (1000 + 50 * LZ) + 80 * F_A1 * (LZ + 1)) +
    (600 + 1600) +
    (2000 + 800 * ((d + 1) + S0 * (d + 1)) +
      (2000 + S0 * (1500 + 300 * d) + 80 * F_c * (UC + 1))) +
    (1500 + 600 * (d + 1) + 800) + 32
  let B_sq_coef : ℕ :=
    (4000000 + 400000 * (deg_α + deg_alg)) +
    (300000 + (1000000 + 500000 * d + 600 * BL)) +
    (256 * F_sz * (2 * LZ + 16) * LZ + 1000000) +
    (2000000 + LZ * (1200000 + 600000 * d) + (d + 1) * (1000000 + 600 * LZ) +
      256 * F_A1 * (2 * LZ + 16) * LZ) +
    (400000 + 900000) +
    (2000000 + 800000 * ((d + 1) + S0 * (d + 1)) +
      2000000 + S0 * (1500000 + 300000 * d) + 256 * F_c * (2 * UC + 16) * UC) +
    (1500000 + 600000 * (d + 1) + 800000) + 32
  let B_extra : ℕ :=
    (LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_sz + 6) + 80) +
    (LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_A1 + 6) + 80) +
    (UC + 2) * (8 * (UC + 3) + 4 * (UC + 2 * natBitLength T_c + 6) + 80) + 32
  4 * U_poly + 4 * (B_sq_coef * (VC ^ 2) + B_extra)

theorem isNatPoly2_s0Fn : IsNatPoly2 (s0Fn K deg_α) := by
  unfold s0Fn s₀Val
  exact natPoly2_mul (natPoly2_const (22 * K ^ 3))
    (natPoly2_pow (natPoly2_add natPoly2_d (natPoly2_const 2)) (2 * deg_α + 1))

theorem isNatPoly2_bLiftFn : IsNatPoly2 bLiftFn := by
  unfold bLiftFn bLiftVal
  exact natPoly2_add
    (natPoly2_add
      (natPoly2_mul (natPoly2_add (natPoly2_mul (natPoly2_const 2) natPoly2_d) (natPoly2_const 2)) natPoly2_B)
      natPoly2_d)
    (natPoly2_const 2)

theorem isNatPoly2_lzFn : IsNatPoly2 (lzFn C_z deg_alg) := by
  unfold lzFn
  exact natPoly2_mul
    (natPoly2_mul (natPoly2_const C_z)
      (natPoly2_pow (natPoly2_add natPoly2_d (natPoly2_const 2)) deg_alg))
    (natPoly2_pow (natPoly2_add isNatPoly2_bLiftFn (natPoly2_const 1)) deg_alg)

theorem isNatPoly2_ucertFn :
    IsNatPoly2 (ucertFn K deg_α C_z deg_alg C_cert deg_cert) := by
  unfold ucertFn
  exact natPoly2_mul (natPoly2_const C_cert)
    (natPoly2_pow
      (natPoly2_add
        (natPoly2_add
          (natPoly2_add (natPoly2_add natPoly2_d (natPoly2_const 1)) (isNatPoly2_s0Fn K deg_α))
          (natPoly2_add isNatPoly2_bLiftFn (isNatPoly2_lzFn C_z deg_alg)))
        (natPoly2_const 1))
      deg_cert)

theorem isNatPoly2_qaFn : IsNatPoly2 (qaFn K deg_α C_z deg_alg) := by
  unfold qaFn
  exact natPoly2_add
    (natPoly2_add (natPoly2_const 4)
      (natPoly2_mul
        (natPoly2_add (natPoly2_add (isNatPoly2_lzFn C_z deg_alg) (isNatPoly2_s0Fn K deg_α)) (natPoly2_const 4))
        (natPoly2_add natPoly2_d (natPoly2_const 1))))
    (natPoly2_const 64)

theorem isNatPoly2_qvFn :
    IsNatPoly2 (qvFn K deg_α C_z deg_alg k_φ C_cert deg_cert) := by
  unfold qvFn
  exact natPoly2_add
    (natPoly2_add
      (natPoly2_add
        (natPoly2_add
          (natPoly2_add
            (natPoly2_add
              (natPoly2_add
                (natPoly2_add
                  (natPoly2_bitLen (isNatPoly2_qaFn K deg_α C_z deg_alg))
                  (natPoly2_mul (natPoly2_const 4) isNatPoly2_bLiftFn))
                (natPoly2_mul (natPoly2_const 4) (isNatPoly2_lzFn C_z deg_alg)))
              (natPoly2_mul (natPoly2_const 2) (isNatPoly2_ucertFn K deg_α C_z deg_alg C_cert deg_cert)))
            (natPoly2_mul (natPoly2_const 2) (isNatPoly2_s0Fn K deg_α)))
          (natPoly2_const (2 * deg_α)))
        (natPoly2_const (2 * deg_alg)))
      (natPoly2_const (2 * k_φ)))
    (natPoly2_const 128)

theorem isNatPoly2_bitLenCapNat :
    IsNatPoly2 (bitLenCapNat K deg_α C_z deg_alg C_cert deg_cert) := by
  unfold bitLenCapNat
  exact natPoly2_add
    (natPoly2_add
      (natPoly2_mul (natPoly2_const 2) (isNatPoly2_lzFn C_z deg_alg))
      (isNatPoly2_ucertFn K deg_α C_z deg_alg C_cert deg_cert))
    (natPoly2_const 2)

theorem isNatPoly2_subBitExtra :
    IsNatPoly2 (subBitExtra K deg_α C_z deg_alg C_cert deg_cert T_sz T_A1 T_c) := by
  unfold subBitExtra
  have hU1 := isNatPoly2_lzFn C_z deg_alg
  have hU3 := isNatPoly2_ucertFn K deg_α C_z deg_alg C_cert deg_cert
  have hU1_b := natPoly2_bitLen (natPoly2_add hU1 (natPoly2_const 2))
  have hU3_b := natPoly2_bitLen (natPoly2_add hU3 (natPoly2_const 2))
  have ht1 := natPoly2_add
    (natPoly2_add
      (natPoly2_add (natPoly2_mul (natPoly2_const (natBitLength T_sz + 12)) hU1)
        (natPoly2_mul (natPoly2_add hU1 (natPoly2_const 3))
          (natPoly2_add (natPoly2_add (natPoly2_add hU1_b hU1) (natPoly2_const (2 * natBitLength T_sz))) (natPoly2_const 18))))
      (natPoly2_mul (natPoly2_const 2) hU1_b))
    (natPoly2_const 64)
  have ht2 := natPoly2_add
    (natPoly2_add
      (natPoly2_add (natPoly2_mul (natPoly2_const (natBitLength T_A1 + 12)) hU1)
        (natPoly2_mul (natPoly2_add hU1 (natPoly2_const 3))
          (natPoly2_add (natPoly2_add (natPoly2_add hU1_b hU1) (natPoly2_const (2 * natBitLength T_A1))) (natPoly2_const 18))))
      (natPoly2_mul (natPoly2_const 2) hU1_b))
    (natPoly2_const 64)
  have ht3 := natPoly2_add
    (natPoly2_add
      (natPoly2_add (natPoly2_mul (natPoly2_const (natBitLength T_c + 12)) hU3)
        (natPoly2_mul (natPoly2_add hU3 (natPoly2_const 3))
          (natPoly2_add (natPoly2_add (natPoly2_add hU3_b hU3) (natPoly2_const (2 * natBitLength T_c))) (natPoly2_const 18))))
      (natPoly2_mul (natPoly2_const 2) hU3_b))
    (natPoly2_const 64)
  exact natPoly2_add (natPoly2_add ht1 ht2) ht3

theorem isNatPoly2_spaceCapNat :
    IsNatPoly2 (spaceCapNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c) := by
  unfold spaceCapNat
  have hQA := isNatPoly2_qaFn K deg_α C_z deg_alg
  have hQV := isNatPoly2_qvFn K deg_α C_z deg_alg k_φ C_cert deg_cert
  have hU1 := isNatPoly2_lzFn C_z deg_alg
  have hU3 := isNatPoly2_ucertFn K deg_α C_z deg_alg C_cert deg_cert
  have hinp := natPoly2_add
    (natPoly2_add
      (natPoly2_add (natPoly2_mul (natPoly2_mul (natPoly2_const 2) natPoly2_d) natPoly2_B)
        (natPoly2_mul (natPoly2_const 3) natPoly2_d))
      natPoly2_B)
    (natPoly2_const 16)
  have har := natPoly2_mul (natPoly2_mul (natPoly2_const 108) hQA)
    (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_const 5) hQA) hQV) (natPoly2_const 20))
  exact natPoly2_add
    (natPoly2_add
      (natPoly2_add
        (natPoly2_add
          (natPoly2_add hinp har)
          (natPoly2_mul (natPoly2_const 4) hU1))
        (natPoly2_mul (natPoly2_const 2) hU3))
      (isNatPoly2_subBitExtra K deg_α C_z deg_alg C_cert deg_cert T_sz T_A1 T_c))
    (natPoly2_const 16)

theorem isNatPoly2_vCoefNat :
    IsNatPoly2 (vCoefNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c) := by
  unfold vCoefNat
  exact natPoly2_add
    (natPoly2_add
      (natPoly2_add
        (natPoly2_add
          (natPoly2_add (natPoly2_const 4) (isNatPoly2_qvFn K deg_α C_z deg_alg k_φ C_cert deg_cert))
          (natPoly2_const (natBitLength T_sz)))
        (natPoly2_const (natBitLength T_A1)))
      (natPoly2_const (natBitLength T_c)))
    (natPoly2_const 24)

theorem isNatPoly2_timeCapNat :
    IsNatPoly2 (timeCapNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c) := by
  unfold timeCapNat
  have hS0 := isNatPoly2_s0Fn K deg_α
  have hBL := isNatPoly2_bLiftFn
  have hLZ := isNatPoly2_lzFn C_z deg_alg
  have hUC := isNatPoly2_ucertFn K deg_α C_z deg_alg C_cert deg_cert
  have hVC := isNatPoly2_vCoefNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c
  have hd1 := natPoly2_add natPoly2_d (natPoly2_const 1)
  have hUp : IsNatPoly2 (fun d B =>
      (64 + 400 * (deg_α + deg_alg + 16)) +
      (300 + (1000 + 500 * d + 60 * bLiftFn d B)) +
      (80 * F_sz * (lzFn C_z deg_alg d B + 1) + 32 * (lzFn C_z deg_alg d B + 2) + 1000) +
      (2000 + lzFn C_z deg_alg d B * (1200 + 600 * d + 24 * (lzFn C_z deg_alg d B + 12)) +
        (d + 1) * (1000 + 50 * lzFn C_z deg_alg d B) + 80 * F_A1 * (lzFn C_z deg_alg d B + 1)) +
      (600 + 1600) +
      (2000 + 800 * ((d + 1) + s0Fn K deg_α d B * (d + 1)) +
        (2000 + s0Fn K deg_α d B * (1500 + 300 * d) +
          80 * F_c * (ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 1))) +
      (1500 + 600 * (d + 1) + 800) + 32) := by
    have u0 := natPoly2_const (64 + 400 * (deg_α + deg_alg + 16))
    have u1 := natPoly2_add (natPoly2_const 300)
      (natPoly2_add (natPoly2_add (natPoly2_const 1000) (natPoly2_mul (natPoly2_const 500) natPoly2_d))
        (natPoly2_mul (natPoly2_const 60) hBL))
    have u2 := natPoly2_add
      (natPoly2_add (natPoly2_mul (natPoly2_const (80 * F_sz)) (natPoly2_add hLZ (natPoly2_const 1)))
        (natPoly2_mul (natPoly2_const 32) (natPoly2_add hLZ (natPoly2_const 2))))
      (natPoly2_const 1000)
    have u3 := natPoly2_add
      (natPoly2_add
        (natPoly2_add (natPoly2_const 2000)
          (natPoly2_mul hLZ
            (natPoly2_add (natPoly2_add (natPoly2_const 1200) (natPoly2_mul (natPoly2_const 600) natPoly2_d))
              (natPoly2_mul (natPoly2_const 24) (natPoly2_add hLZ (natPoly2_const 12))))))
        (natPoly2_mul hd1 (natPoly2_add (natPoly2_const 1000) (natPoly2_mul (natPoly2_const 50) hLZ))))
      (natPoly2_mul (natPoly2_const (80 * F_A1)) (natPoly2_add hLZ (natPoly2_const 1)))
    have u4 := natPoly2_const (600 + 1600)
    have u5 := natPoly2_add
      (natPoly2_add (natPoly2_const 2000)
        (natPoly2_mul (natPoly2_const 800) (natPoly2_add hd1 (natPoly2_mul hS0 hd1))))
      (natPoly2_add
        (natPoly2_add (natPoly2_const 2000)
          (natPoly2_mul hS0 (natPoly2_add (natPoly2_const 1500) (natPoly2_mul (natPoly2_const 300) natPoly2_d))))
        (natPoly2_mul (natPoly2_const (80 * F_c)) (natPoly2_add hUC (natPoly2_const 1))))
    have u6 := natPoly2_add (natPoly2_add (natPoly2_const 1500) (natPoly2_mul (natPoly2_const 600) hd1))
      (natPoly2_const 800)
    exact natPoly2_add
      (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add u0 u1) u2) u3) u4) u5) u6)
      (natPoly2_const 32)
  have hBsq : IsNatPoly2 (fun d B =>
      (4000000 + 400000 * (deg_α + deg_alg)) +
      (300000 + (1000000 + 500000 * d + 600 * bLiftFn d B)) +
      (256 * F_sz * (2 * lzFn C_z deg_alg d B + 16) * lzFn C_z deg_alg d B + 1000000) +
      (2000000 + lzFn C_z deg_alg d B * (1200000 + 600000 * d) +
        (d + 1) * (1000000 + 600 * lzFn C_z deg_alg d B) +
        256 * F_A1 * (2 * lzFn C_z deg_alg d B + 16) * lzFn C_z deg_alg d B) +
      (400000 + 900000) +
      (2000000 + 800000 * ((d + 1) + s0Fn K deg_α d B * (d + 1)) +
        2000000 + s0Fn K deg_α d B * (1500000 + 300000 * d) +
        256 * F_c * (2 * ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 16) *
          ucertFn K deg_α C_z deg_alg C_cert deg_cert d B) +
      (1500000 + 600000 * (d + 1) + 800000) + 32) := by
    have b0 := natPoly2_const (4000000 + 400000 * (deg_α + deg_alg))
    have b1 := natPoly2_add (natPoly2_const 300000)
      (natPoly2_add (natPoly2_add (natPoly2_const 1000000) (natPoly2_mul (natPoly2_const 500000) natPoly2_d))
        (natPoly2_mul (natPoly2_const 600) hBL))
    have b2 := natPoly2_add
      (natPoly2_mul
        (natPoly2_mul (natPoly2_const (256 * F_sz))
          (natPoly2_add (natPoly2_mul (natPoly2_const 2) hLZ) (natPoly2_const 16)))
        hLZ)
      (natPoly2_const 1000000)
    have b3 := natPoly2_add
      (natPoly2_add
        (natPoly2_add (natPoly2_const 2000000)
          (natPoly2_mul hLZ (natPoly2_add (natPoly2_const 1200000) (natPoly2_mul (natPoly2_const 600000) natPoly2_d))))
        (natPoly2_mul hd1 (natPoly2_add (natPoly2_const 1000000) (natPoly2_mul (natPoly2_const 600) hLZ))))
      (natPoly2_mul
        (natPoly2_mul (natPoly2_const (256 * F_A1))
          (natPoly2_add (natPoly2_mul (natPoly2_const 2) hLZ) (natPoly2_const 16)))
        hLZ)
    have b4 := natPoly2_const (400000 + 900000)
    have b5 := natPoly2_add
      (natPoly2_add
        (natPoly2_add
          (natPoly2_add (natPoly2_const 2000000)
            (natPoly2_mul (natPoly2_const 800000) (natPoly2_add hd1 (natPoly2_mul hS0 hd1))))
          (natPoly2_const 2000000))
        (natPoly2_mul hS0 (natPoly2_add (natPoly2_const 1500000) (natPoly2_mul (natPoly2_const 300000) natPoly2_d))))
      (natPoly2_mul
        (natPoly2_mul (natPoly2_const (256 * F_c))
          (natPoly2_add (natPoly2_mul (natPoly2_const 2) hUC) (natPoly2_const 16)))
        hUC)
    have b6 := natPoly2_add (natPoly2_add (natPoly2_const 1500000) (natPoly2_mul (natPoly2_const 600000) hd1))
      (natPoly2_const 800000)
    exact natPoly2_add
      (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add b0 b1) b2) b3) b4) b5) b6)
      (natPoly2_const 32)
  have hBex : IsNatPoly2 (fun d B =>
      (lzFn C_z deg_alg d B + 2) *
        (8 * (lzFn C_z deg_alg d B + 3) + 4 * (lzFn C_z deg_alg d B + 2 * natBitLength T_sz + 6) + 80) +
      (lzFn C_z deg_alg d B + 2) *
        (8 * (lzFn C_z deg_alg d B + 3) + 4 * (lzFn C_z deg_alg d B + 2 * natBitLength T_A1 + 6) + 80) +
      (ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 2) *
        (8 * (ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 3) +
          4 * (ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 2 * natBitLength T_c + 6) + 80) + 32) := by
    have mkEx := fun {U : ℕ → ℕ → ℕ} (hU : IsNatPoly2 U) (T : ℕ) =>
      natPoly2_mul (natPoly2_add hU (natPoly2_const 2))
        (natPoly2_add
          (natPoly2_add (natPoly2_mul (natPoly2_const 8) (natPoly2_add hU (natPoly2_const 3)))
            (natPoly2_mul (natPoly2_const 4) (natPoly2_add hU (natPoly2_const (2 * natBitLength T + 6)))))
          (natPoly2_const 80))
    exact natPoly2_add
      (natPoly2_add (natPoly2_add (mkEx hLZ T_sz) (mkEx hLZ T_A1)) (mkEx hUC T_c))
      (natPoly2_const 32)
  exact natPoly2_add
    (natPoly2_mul (natPoly2_const 4) hUp)
    (natPoly2_mul (natPoly2_const 4)
      (natPoly2_add (natPoly2_mul hBsq (natPoly2_pow hVC 2)) hBex))

end Caps

/-! ### 4. Input size, `ParamFit` / `ArenaInputOK`, and space/cost envelope bounds -/

private theorem le_mw {X m w : ℕ} (hm : 1 ≤ m) (hw : 1 ≤ w) : X ≤ m * w * X :=
  Nat.le_mul_of_pos_left X (Nat.mul_pos hm hw)

private theorem le_mw2 {X m w : ℕ} (hm : 1 ≤ m) (hw : 1 ≤ w) : X ≤ m * w ^ 2 * X :=
  Nat.le_mul_of_pos_left X (Nat.mul_pos hm (Nat.pos_of_ne_zero (by positivity)))

theorem inp_space_bounds {d B m : ℕ} (hB : 1 ≤ B) (hm2 : 2 ≤ m)
    {pts_h : ℕ → Fin d → ℚ}
    (hpts_b : ∀ h : ℕ, h < m → RatPointBitBounded B (pts_h h))
    {inp : BitRAMInput d}
    (hip_params : inp.intParams = [(m : ℤ), (B : ℤ)])
    (hip_handles : inp.activeHandles = Finset.range m)
    (hip_coords : ∀ h : ℕ, h < m → inp.activeRatCoords h = pts_h h)
    (hip_extra : inp.extraRats = []) :
    let w := Nat.clog 2 (2 * m)
    2 ≤ w ∧
    natBitLength m ≤ w ∧
    inp.inputCellSpace ≤ m * (2 * d + 3) ∧
    inp.inputBitSpace ≤ m * w * (2 * d * B + d + B + 6) := by
  intro w
  have hw2 : 2 ≤ w := two_le_clog2_of_four_le (by omega)
  have hm_lt_pow : m < 2 ^ w :=
    lt_of_lt_of_le (by omega : m < 2 * m) (Nat.le_pow_clog (by norm_num) (2 * m))
  have hnb_m : natBitLength m ≤ w := natBitLength_le_of_lt_two_pow (by omega) hm_lt_pow
  have hcell : inp.inputCellSpace ≤ m * (2 * d + 3) := by
    unfold BitRAMInput.inputCellSpace
    rw [hip_params, hip_handles, hip_extra]
    simp only [List.length_cons, List.length_nil, Finset.card_range]
    calc 2 + m * (2 * d + 1) + 2 * 0 ≤ 2 * m + m * (2 * d + 1) := by omega
      _ = m * (2 * d + 3) := by ring
  have hbit : inp.inputBitSpace ≤ m * w * (2 * d * B + d + B + 6) := by
    unfold BitRAMInput.inputBitSpace
    rw [hip_params, hip_handles, hip_extra]
    simp only [List.map_cons, List.map_nil, List.sum_cons, List.sum_nil, add_zero]
    have hm_ib : intBitLength (m : ℤ) ≤ w + 1 :=
      (intBitLength_natCast_le_succ m).trans (by omega)
    have hB_ib : intBitLength (B : ℤ) ≤ B + 2 :=
      (intBitLength_natCast_le_succ B).trans (by have := natBitLength_le B; omega)
    have hsum_h :
        (∑ h ∈ Finset.range m,
          (natBitLength h + ∑ c : Fin d, ratBitLength (inp.activeRatCoords h c))) ≤
        m * (w + d * (2 * B + 1)) := by
      calc (∑ h ∈ Finset.range m,
              (natBitLength h + ∑ c : Fin d, ratBitLength (inp.activeRatCoords h c)))
          ≤ ∑ _h ∈ Finset.range m, (w + d * (2 * B + 1)) := by
            refine Finset.sum_le_sum fun h hh => ?_
            have hh_lt : h < m := Finset.mem_range.mp hh
            have hh_nb : natBitLength h ≤ w :=
              (natBitLength_mono (le_of_lt hh_lt)).trans hnb_m
            rw [hip_coords h hh_lt]
            have hc_sum : (∑ c : Fin d, ratBitLength (pts_h h c)) ≤ d * (2 * B + 1) := by
              calc (∑ c : Fin d, ratBitLength (pts_h h c))
                  ≤ ∑ _c : Fin d, (2 * B + 1) := by
                    refine Finset.sum_le_sum fun c _ => ?_
                    obtain ⟨hn_b, hd_b⟩ := hpts_b h hh_lt c
                    unfold ratBitLength intBitLength
                    split_ifs <;> omega
                _ = d * (2 * B + 1) := by simp
            omega
        _ = m * (w + d * (2 * B + 1)) := by simp
    have h1 : w + 1 + (B + 2) ≤ m * w * (B + 4) := by
      calc w + 1 + (B + 2) ≤ w * (B + 4) := by
            have : w + B + 3 ≤ w + w * B + 3 * w := by
              have : B ≤ w * B := Nat.le_mul_of_pos_left B (by omega)
              omega
            linarith
        _ ≤ m * (w * (B + 4)) := Nat.le_mul_of_pos_left _ (by omega)
        _ = m * w * (B + 4) := by ring
    have h2 : m * (w + d * (2 * B + 1)) ≤ m * w * (2 * d * B + d + 2) := by
      have hw_d : w + d * (2 * B + 1) ≤ w * (2 * d * B + d + 2) := by
        have hd_le : d * (2 * B + 1) ≤ w * (d * (2 * B + 1)) :=
          Nat.le_mul_of_pos_left _ (by omega)
        calc w + d * (2 * B + 1) ≤ w + w * (d * (2 * B + 1)) := by omega
          _ = w * (2 * d * B + d + 1) := by ring
          _ ≤ w * (2 * d * B + d + 2) := Nat.mul_le_mul_left w (by omega)
      calc m * (w + d * (2 * B + 1)) ≤ m * (w * (2 * d * B + d + 2)) :=
            Nat.mul_le_mul_left m hw_d
        _ = m * w * (2 * d * B + d + 2) := by ring
    calc intBitLength (m : ℤ) + intBitLength (B : ℤ) + _
        ≤ (w + 1 + (B + 2)) + m * (w + d * (2 * B + 1)) := by omega
      _ ≤ m * w * (B + 4) + m * w * (2 * d * B + d + 2) := Nat.add_le_add h1 h2
      _ = m * w * (2 * d * B + d + B + 6) := by ring
  exact ⟨hw2, hnb_m, hcell, hbit⟩

theorem arena_fit_all (p : CoreParams) {C_cert deg_cert M : ℕ}
    (hK1 : 1 ≤ p.K) (hB1 : 1 ≤ p.B) (hCz1 : 1 ≤ p.C_z) (hm2s : 2 * p.s₀ ≤ p.m)
    (hM1 : 1 ≤ M) (hMLz : M ≤ p.L_z)
    {pts_h : ℕ → Fin p.d → ℚ}
    (hpts_b : ∀ h : ℕ, h < p.m → RatPointBitBounded p.B (pts_h h))
    {inp : BitRAMInput p.d}
    (hip_params : inp.intParams = [(p.m : ℤ), (p.B : ℤ)])
    (hip_handles : inp.activeHandles = Finset.range p.m)
    (hip_coords : ∀ h : ℕ, h < p.m → inp.activeRatCoords h = pts_h h)
    (hip_extra : inp.extraRats = []) :
    let QA := qaFn p.K p.deg_α p.C_z p.deg_alg p.d p.B
    let QV := qvFn p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert p.d p.B
    let A := p.m * QA
    let V := 4 * p.w + QV
    ParamFit A V p ∧
    ArenaInputOK A V inp ∧
    (intBitLength ((M + 1 : ℕ) : ℤ) ≤ V ∧
      natBitLength (2 ^ Nat.clog 2 (M + 1)) + 2 ≤ V ∧
      p.w + Nat.clog 2 (M + 1) + 16 ≤ V) ∧
    (1 ≤ M ∧ M * p.D + 4 ≤ A ∧ p.W₁ M + 4 ≤ V ∧ 2 * p.L_z + 16 ≤ V ∧
      lzFn p.C_z p.deg_alg p.d p.B + 2 ≤ V) ∧
    (p.D + p.s₀ * p.D + 4 ≤ A ∧
      ucertFn p.K p.deg_α p.C_z p.deg_alg C_cert deg_cert p.d p.B + 2 ≤ V) := by
  intro QA QV A V
  have hs0_pos : 1 ≤ p.s₀ := s₀Val_pos hK1 p.d
  have hm2 : 2 ≤ p.m := by omega
  obtain ⟨hw2, hnb_m, _, _⟩ :=
    inp_space_bounds hB1 hm2 hpts_b hip_params hip_handles hip_coords hip_extra
  have hw_def : p.w = Nat.clog 2 (2 * p.m) := rfl
  have hLz_eq : p.L_z = lzFn p.C_z p.deg_alg p.d p.B := rfl
  have hs0_eq : p.s₀ = s0Fn p.K p.deg_α p.d p.B := rfl
  have hBl_eq : p.B_lift = bLiftFn p.d p.B := rfl
  have hD_eq : p.D = p.d + 1 := rfl
  have hQA_ge : 68 + (p.L_z + p.s₀ + 4) * p.D ≤ QA := by
    dsimp [QA, qaFn]; rw [← hLz_eq, ← hs0_eq, ← hD_eq]; omega
  have h16A : 16 ≤ A := by
    have : 68 ≤ QA := by omega
    have : 2 * 68 ≤ p.m * QA := Nat.mul_le_mul hm2 this
    dsimp [A]; omega
  have hmA : 2 * p.m + 4 * p.D + 16 ≤ A := by
    have h1 : 4 * p.D ≤ p.m * (4 * p.D) := Nat.le_mul_of_pos_left _ (by omega)
    have h4D : 4 * p.D ≤ (p.L_z + p.s₀ + 4) * p.D := Nat.mul_le_mul_right p.D (by omega)
    have h2 : p.m * (68 + 4 * p.D) ≤ p.m * QA := Nat.mul_le_mul_left _ (by omega)
    dsimp [A]; linarith
  have hnbA : natBitLength A ≤ p.w + natBitLength QA := by
    dsimp [A]
    exact (natBitLength_mul_le p.m QA).trans (by omega)
  have hQV_ge : natBitLength QA + 4 * p.B_lift + 4 * p.L_z +
      2 * ucertFn p.K p.deg_α p.C_z p.deg_alg C_cert deg_cert p.d p.B +
      2 * p.s₀ + 2 * p.deg_α + 2 * p.deg_alg + 2 * p.k_φ + 128 ≤ QV := by
    dsimp only [QV, qvFn]; rw [← hLz_eq, ← hs0_eq, ← hBl_eq]
  have hVA : natBitLength A + 16 ≤ V := by dsimp [V]; omega
  have hnat_ib : ∀ n : ℕ, n + 2 ≤ V → intBitLength (n : ℤ) ≤ V := fun n hn =>
    (intBitLength_natCast_le_succ n).trans (by have := natBitLength_le n; omega)
  have hfit : ParamFit A V p := by
    refine ⟨hK1, hB1, hCz1, hm2s, h16A, hmA, hVA, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · dsimp [V]; omega
    · dsimp [CoreParams.W₂, V]; omega
    · exact hnat_ib p.s₀ (by dsimp [V]; omega)
    · exact hnat_ib (2 * p.deg_α + 1) (by dsimp [V]; omega)
    · exact hnat_ib (2 * p.L_z) (by dsimp [V]; omega)
    · exact hnat_ib p.deg_alg (by dsimp [V]; omega)
    · exact hnat_ib p.k_φ (by dsimp [V]; omega)
  have hinp : ArenaInputOK A V inp := by
    refine ⟨h16A, hVA, ?_, ?_, ?_, ?_⟩
    · exact hnat_ib p.d (by have : p.d ≤ p.B_lift := by dsimp [CoreParams.B_lift, bLiftVal]; omega
                            dsimp [V]; omega)
    · intro idx
      rw [hip_params]
      by_cases h0 : idx = 0
      · subst h0; dsimp [listGetIntD]
        exact (intBitLength_natCast_le_succ p.m).trans (by dsimp [V]; omega)
      · by_cases h1 : idx = 1
        · subst h1; dsimp [listGetIntD]
          exact hnat_ib p.B (by have : p.B ≤ p.B_lift := by dsimp [CoreParams.B_lift, bLiftVal]; have := Nat.le_mul_of_pos_left p.B (by omega : 0 < 2 * p.d + 2); omega
                                dsimp [V]; omega)
        · unfold listGetIntD
          split_ifs with hnn
          · rcases h : idx.toNat with _ | _ | n
            · omega
            · omega
            · simp [List.getD]; change 1 ≤ V; dsimp [V]; omega
          · change 1 ≤ V; dsimp [V]; omega
    · intro idx
      rw [hip_extra]
      have h0 : listGetIntD ([] : List ℚ) idx 0 = 0 := by unfold listGetIntD; split_ifs <;> simp
      rw [h0]
      have hd1 : intBitLength ((0 : ℚ).den : ℤ) = 2 := by decide
      exact ⟨by change 1 ≤ V; dsimp [V]; omega, by rw [hd1]; dsimp [V]; omega⟩
    · intro h hh c
      have hh_lt : h < p.m := Finset.mem_range.mp (hip_handles ▸ hh)
      rw [hip_coords h hh_lt]
      obtain ⟨hnum_b, hden_b⟩ := hpts_b h hh_lt c
      have hB_le : p.B ≤ p.B_lift := by dsimp [CoreParams.B_lift, bLiftVal]; have := Nat.le_mul_of_pos_left p.B (by omega : 0 < 2 * p.d + 2); omega
      refine ⟨?_, ?_⟩
      · unfold intBitLength; split_ifs <;> (dsimp [V]; omega)
      · exact (intBitLength_natCast_le_succ _).trans (by dsimp [V]; omega)
  have hclog_M1 : Nat.clog 2 (M + 1) ≤ p.L_z + 1 :=
    (clog2_le_self (M + 1)).trans (by omega)
  have h2_fit : intBitLength ((M + 1 : ℕ) : ℤ) ≤ V ∧
      natBitLength (2 ^ Nat.clog 2 (M + 1)) + 2 ≤ V ∧
      p.w + Nat.clog 2 (M + 1) + 16 ≤ V := by
    refine ⟨hnat_ib (M + 1) (by dsimp [V]; omega), ?_, by dsimp [V]; omega⟩
    have := natBitLength_two_pow_le (Nat.clog 2 (M + 1))
    dsimp [V]; omega
  have h3_fit : 1 ≤ M ∧ M * p.D + 4 ≤ A ∧ p.W₁ M + 4 ≤ V ∧ 2 * p.L_z + 16 ≤ V ∧
      lzFn p.C_z p.deg_alg p.d p.B + 2 ≤ V := by
    refine ⟨hM1, ?_, ?_, by dsimp [V]; omega, by rw [← hLz_eq]; dsimp [V]; omega⟩
    · have h1 : M * p.D + 4 ≤ QA := by
        have : M * p.D ≤ (p.L_z + p.s₀ + 4) * p.D := Nat.mul_le_mul_right p.D (by omega)
        omega
      exact h1.trans (Nat.le_mul_of_pos_left QA (by omega))
    · dsimp [CoreParams.W₁, V]; omega
  have h5_fit : p.D + p.s₀ * p.D + 4 ≤ A ∧
      ucertFn p.K p.deg_α p.C_z p.deg_alg C_cert deg_cert p.d p.B + 2 ≤ V := by
    refine ⟨?_, by dsimp [V]; omega⟩
    have h1 : p.D + p.s₀ * p.D + 4 ≤ QA := by
      have : p.D + p.s₀ * p.D ≤ (p.L_z + p.s₀ + 4) * p.D := by
        have : (1 + p.s₀) * p.D ≤ (p.L_z + p.s₀ + 4) * p.D := Nat.mul_le_mul_right p.D (by omega)
        linarith
      omega
    exact h1.trans (Nat.le_mul_of_pos_left QA (by omega))
  exact ⟨hfit, hinp, h2_fit, h3_fit, h5_fit⟩

theorem space_and_cost_caps_le (p : CoreParams)
    {C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c M : ℕ}
    (hK1 : 1 ≤ p.K) (hB1 : 1 ≤ p.B) (hm2s : 2 * p.s₀ ≤ p.m)
    (hMLz : M ≤ p.L_z)
    {pts_h : ℕ → Fin p.d → ℚ}
    (hpts_b : ∀ h : ℕ, h < p.m → RatPointBitBounded p.B (pts_h h))
    {inp : BitRAMInput p.d}
    (hip_params : inp.intParams = [(p.m : ℤ), (p.B : ℤ)])
    (hip_handles : inp.activeHandles = Finset.range p.m)
    (hip_coords : ∀ h : ℕ, h < p.m → inp.activeRatCoords h = pts_h h)
    (hip_extra : inp.extraRats = []) :
    let QA := qaFn p.K p.deg_α p.C_z p.deg_alg p.d p.B
    let QV := qvFn p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert p.d p.B
    let LZ := lzFn p.C_z p.deg_alg p.d p.B
    let UC := ucertFn p.K p.deg_α p.C_z p.deg_alg C_cert deg_cert p.d p.B
    let A := p.m * QA
    let V := 4 * p.w + QV
    attemptCellCap inp A LZ LZ UC ≤
      p.m * spaceCapNat p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c p.d p.B ∧
    attemptBitSpaceCap inp A V T_sz T_A1 T_c LZ LZ UC ≤
      p.m * p.w * spaceCapNat p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c p.d p.B ∧
    4 * (attemptUnitCap p M F_sz F_A1 F_c LZ LZ UC + 16) ≤
      p.m * p.w * timeCapNat p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c p.d p.B ∧
    4 * (attemptBitCap p V M T_sz T_A1 T_c F_sz F_A1 F_c LZ LZ UC + 4 * V + 16) ≤
      p.m * p.w ^ 2 * timeCapNat p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c p.d p.B := by
  intro QA QV LZ UC A V
  have hs0_pos : 1 ≤ p.s₀ := s₀Val_pos hK1 p.d
  have hm2 : 2 ≤ p.m := by omega
  have hm1 : 1 ≤ p.m := by omega
  obtain ⟨hw2, hnb_m, hcell_inp, hbit_inp⟩ :=
    inp_space_bounds hB1 hm2 hpts_b hip_params hip_handles hip_coords hip_extra
  have hw_def : p.w = Nat.clog 2 (2 * p.m) := rfl
  have hw1 : 1 ≤ p.w := by omega
  have hLz_eq : p.L_z = LZ := rfl
  have hs0_eq : p.s₀ = s0Fn p.K p.deg_α p.d p.B := rfl
  have hBl_eq : p.B_lift = bLiftFn p.d p.B := rfl
  have hD_eq : p.D = p.d + 1 := rfl
  have hr_le_m : p.r ≤ p.m := Nat.div_le_self p.m p.s₀
  -- 1. Cell space cap
  have hcell_tot : attemptCellCap inp A LZ LZ UC ≤
      p.m * spaceCapNat p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c p.d p.B := by
    unfold attemptCellCap arenaCellCap spaceCapNat
    dsimp only
    have hQA_le : 108 * QA ≤ 108 * QA * (5 + QA + QV + 20) :=
      Nat.le_mul_of_pos_right _ (by omega)
    have h1 : 108 * (p.m * QA) ≤ p.m * (108 * QA * (5 + QA + QV + 20)) := by
      calc 108 * (p.m * QA) = p.m * (108 * QA) := by ring
        _ ≤ p.m * (108 * QA * (5 + QA + QV + 20)) := Nat.mul_le_mul_left p.m hQA_le
    have h2 : 2 * (LZ + LZ + UC) + 8 ≤ p.m * (4 * LZ + 2 * UC + 16) := by
      have : 2 * (LZ + LZ + UC) + 8 ≤ 4 * LZ + 2 * UC + 16 := by omega
      exact this.trans (Nat.le_mul_of_pos_left _ hm1)
    have h3 : p.m * (2 * p.d + 3) ≤ p.m * (2 * p.d * p.B + 3 * p.d + p.B + 16) :=
      Nat.mul_le_mul_left p.m (by omega)
    calc inp.inputCellSpace + 108 * A + 2 * (LZ + LZ + UC) + 8
        ≤ p.m * (2 * p.d * p.B + 3 * p.d + p.B + 16) +
            p.m * (108 * QA * (5 + QA + QV + 20)) +
            p.m * (4 * LZ + 2 * UC + 16) := by
          dsimp [A]; omega
      _ = p.m * ((2 * p.d * p.B + 3 * p.d + p.B + 16) +
            108 * QA * (5 + QA + QV + 20) + 4 * LZ + 2 * UC + 16) := by ring
      _ ≤ p.m * _ := Nat.mul_le_mul_left p.m (by dsimp [QA, QV, LZ, UC]; omega)
  -- 2. Bit space cap
  have hbit_tot : attemptBitSpaceCap inp A V T_sz T_A1 T_c LZ LZ UC ≤
      p.m * p.w * spaceCapNat p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c p.d p.B := by
    unfold attemptBitSpaceCap arenaBitCap spaceCapNat
    dsimp only
    have hnbA : natBitLength A ≤ p.w + QA + 1 := by
      dsimp [A]
      exact (natBitLength_mul_le p.m QA).trans (by have := natBitLength_le QA; omega)
    have hv_lin : natBitLength A + V + 16 ≤ p.w * (5 + QA + QV + 20) := by
      have h1 : natBitLength A + V + 16 ≤ 5 * p.w + (QA + QV + 17) := by dsimp [V]; omega
      have h2 : QA + QV + 17 ≤ p.w * (QA + QV + 20) :=
        (by omega : QA + QV + 17 ≤ QA + QV + 20).trans (Nat.le_mul_of_pos_left _ hw1)
      calc natBitLength A + V + 16 ≤ 5 * p.w + p.w * (QA + QV + 20) := by omega
        _ = p.w * (5 + QA + QV + 20) := by ring
    have har_bit : 108 * A * (natBitLength A + V + 16) ≤
        p.m * p.w * (108 * QA * (5 + QA + QV + 20)) := by
      calc 108 * (p.m * QA) * (natBitLength A + V + 16)
          ≤ 108 * (p.m * QA) * (p.w * (5 + QA + QV + 20)) := Nat.mul_le_mul_left _ hv_lin
        _ = p.m * p.w * (108 * QA * (5 + QA + QV + 20)) := by ring
    let SBE := subBitExtra p.K p.deg_α p.C_z p.deg_alg C_cert deg_cert T_sz T_A1 T_c p.d p.B
    have hsbe : SBE ≤ p.m * p.w * SBE := le_mw hm1 hw1
    have hinp_b : inp.inputBitSpace ≤ p.m * p.w * (2 * p.d * p.B + 3 * p.d + p.B + 16) :=
      hbit_inp.trans (Nat.mul_le_mul_left _ (by omega))
    change inp.inputBitSpace + 108 * A * (natBitLength A + V + 16) + _ + _ + _ ≤ _
    have hfold : ((natBitLength T_sz + 12) * LZ +
        (LZ + 3) * (natBitLength (LZ + 2) + LZ + 2 * natBitLength T_sz + 18) +
        2 * natBitLength (LZ + 2) + 64) +
      ((natBitLength T_A1 + 12) * LZ +
        (LZ + 3) * (natBitLength (LZ + 2) + LZ + 2 * natBitLength T_A1 + 18) +
        2 * natBitLength (LZ + 2) + 64) +
      ((natBitLength T_c + 12) * UC +
        (UC + 3) * (natBitLength (UC + 2) + UC + 2 * natBitLength T_c + 18) +
        2 * natBitLength (UC + 2) + 64) = SBE := by dsimp [SBE, subBitExtra, LZ, UC]; try ring
    calc inp.inputBitSpace + 108 * A * (natBitLength A + V + 16) + _ + _ + _
        = inp.inputBitSpace + 108 * A * (natBitLength A + V + 16) + SBE := by rw [← hfold]; ring
      _ ≤ p.m * p.w * (2 * p.d * p.B + 3 * p.d + p.B + 16) +
            p.m * p.w * (108 * QA * (5 + QA + QV + 20)) +
            p.m * p.w * SBE := Nat.add_le_add (Nat.add_le_add hinp_b har_bit) hsbe
      _ = p.m * p.w * ((2 * p.d * p.B + 3 * p.d + p.B + 16) +
            108 * QA * (5 + QA + QV + 20) + SBE) := by ring
      _ ≤ p.m * p.w * _ := Nat.mul_le_mul_left (p.m * p.w) (by dsimp [SBE, QA, QV]; omega)
  -- 3. Unit cost cap
  have hclog_M1 : Nat.clog 2 (M + 1) ≤ LZ + 1 :=
    (clog2_le_self (M + 1)).trans (by omega)
  have hunit_tot : 4 * (attemptUnitCap p M F_sz F_A1 F_c LZ LZ UC + 16) ≤
      p.m * p.w * timeCapNat p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c p.d p.B := by
    unfold attemptUnitCap timeCapNat
    dsimp only
    rw [← hLz_eq, ← hs0_eq, ← hBl_eq]
    have u0 : 32 * (p.w + 1) + 400 * (p.deg_α + p.deg_alg + 16) ≤
        p.m * p.w * (64 + 400 * (p.deg_α + p.deg_alg + 16)) := by
      have ha : 32 * (p.w + 1) ≤ p.m * p.w * 64 := by
        have : 32 * (p.w + 1) ≤ p.w * 64 := by omega
        exact this.trans ((Nat.le_mul_of_pos_left _ hm1).trans (by apply le_of_eq; ring))
      have hb := le_mw (X := 400 * (p.deg_α + p.deg_alg + 16)) hm1 hw1
      linarith
    have u1 : 300 + p.m * (1000 + 500 * p.d + 60 * p.B_lift) ≤
        p.m * p.w * (300 + (1000 + 500 * p.d + 60 * p.B_lift)) := by
      have ha := le_mw (X := 300) hm1 hw1
      have hb : p.m * (1000 + 500 * p.d + 60 * p.B_lift) ≤
          p.m * p.w * (1000 + 500 * p.d + 60 * p.B_lift) := by
        rw [mul_assoc]
        exact Nat.mul_le_mul_left p.m (Nat.le_mul_of_pos_left _ hw1)
      linarith
    have u2 : 80 * F_sz * (p.L_z + 1) + 32 * (Nat.clog 2 (M + 1) + 1) + 1000 ≤
        p.m * p.w * (80 * F_sz * (p.L_z + 1) + 32 * (p.L_z + 2) + 1000) := by
      have h1 : 80 * F_sz * (p.L_z + 1) + 32 * (Nat.clog 2 (M + 1) + 1) + 1000 ≤
          80 * F_sz * (p.L_z + 1) + 32 * (p.L_z + 2) + 1000 := by omega
      exact h1.trans (le_mw hm1 hw1)
    have u3 : 2000 + M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1)) +
        p.D * (1000 + 50 * p.L_z) + 80 * F_A1 * (p.L_z + 1) ≤
        p.m * p.w * (2000 + p.L_z * (1200 + 600 * p.d + 24 * (p.L_z + 12)) +
          (p.d + 1) * (1000 + 50 * p.L_z) + 80 * F_A1 * (p.L_z + 1)) := by
      have hw1_le : p.W₁ M + 1 ≤ p.w * (p.L_z + 12) := by
        dsimp [CoreParams.W₁]
        have : Nat.clog 2 (M + 1) + 9 ≤ p.w * (p.L_z + 11) :=
          (by omega : Nat.clog 2 (M + 1) + 9 ≤ p.L_z + 11).trans (Nat.le_mul_of_pos_left _ hw1)
        linarith
      have hM_term : M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1)) ≤
          p.m * p.w * (p.L_z * (1200 + 600 * p.d + 24 * (p.L_z + 12))) := by
        have h_in : 1200 + 600 * p.d + 24 * (p.W₁ M + 1) ≤
            p.w * (1200 + 600 * p.d + 24 * (p.L_z + 12)) := by
          have : 1200 + 600 * p.d ≤ p.w * (1200 + 600 * p.d) := Nat.le_mul_of_pos_left _ hw1
          linarith
        calc M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1))
            ≤ p.L_z * (p.w * (1200 + 600 * p.d + 24 * (p.L_z + 12))) := Nat.mul_le_mul hMLz h_in
          _ ≤ p.m * (p.L_z * (p.w * (1200 + 600 * p.d + 24 * (p.L_z + 12)))) :=
              Nat.le_mul_of_pos_left _ hm1
          _ = p.m * p.w * (p.L_z * (1200 + 600 * p.d + 24 * (p.L_z + 12))) := by ring
      have h_rest := le_mw (X := 2000 + (p.d + 1) * (1000 + 50 * p.L_z) + 80 * F_A1 * (p.L_z + 1)) hm1 hw1
      rw [hD_eq]
      linarith
    have u4 : 600 + p.m * (900 + 24 * (p.W₂ + 1)) ≤ p.m * p.w * (600 + 1600) := by
      have ha := le_mw (X := 600) hm1 hw1
      have hb_in : 900 + 24 * (p.W₂ + 1) ≤ p.w * 1600 := by
        dsimp [CoreParams.W₂]; omega
      have hb : p.m * (900 + 24 * (p.W₂ + 1)) ≤ p.m * p.w * 1600 := by
        rw [mul_assoc]; exact Nat.mul_le_mul_left p.m hb_in
      linarith
    have u5 : 2000 + 800 * (p.D + p.s₀ * p.D) +
        p.r * (2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (UC + 1)) ≤
        p.m * p.w * (2000 + 800 * ((p.d + 1) + p.s₀ * (p.d + 1)) +
          (2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (UC + 1))) := by
      rw [hD_eq]
      have ha := le_mw (X := 2000 + 800 * ((p.d + 1) + p.s₀ * (p.d + 1))) hm1 hw1
      let Yr := 2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (UC + 1)
      have hb : p.r * Yr ≤ p.m * p.w * Yr := by
        calc p.r * Yr ≤ p.m * Yr := Nat.mul_le_mul_right Yr hr_le_m
          _ ≤ p.m * (p.w * Yr) := Nat.mul_le_mul_left p.m (Nat.le_mul_of_pos_left Yr hw1)
          _ = p.m * p.w * Yr := by ring
      dsimp [Yr] at hb
      linarith
    have u6 : (1500 + 600 * p.D + 800 * p.m) + 16 ≤
        p.m * p.w * ((1500 + 600 * (p.d + 1) + 800) + 32) := by
      rw [hD_eq]
      have ha := le_mw (X := 1500 + 600 * (p.d + 1) + 32) hm1 hw1
      have hb : 800 * p.m ≤ p.m * p.w * 800 := by
        calc 800 * p.m = p.m * 800 := by ring
          _ ≤ p.m * (p.w * 800) := Nat.mul_le_mul_left p.m (Nat.le_mul_of_pos_left 800 hw1)
          _ = p.m * p.w * 800 := by ring
      linarith
    let Up := (64 + 400 * (p.deg_α + p.deg_alg + 16)) +
      (300 + (1000 + 500 * p.d + 60 * p.B_lift)) +
      (80 * F_sz * (p.L_z + 1) + 32 * (p.L_z + 2) + 1000) +
      (2000 + p.L_z * (1200 + 600 * p.d + 24 * (p.L_z + 12)) +
        (p.d + 1) * (1000 + 50 * p.L_z) + 80 * F_A1 * (p.L_z + 1)) +
      (600 + 1600) +
      (2000 + 800 * ((p.d + 1) + p.s₀ * (p.d + 1)) +
        (2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (UC + 1))) +
      (1500 + 600 * (p.d + 1) + 800) + 32
    have hsum_u : attemptUnitCap p M F_sz F_A1 F_c LZ LZ UC + 16 ≤ p.m * p.w * Up := by
      unfold attemptUnitCap
      rw [← hLz_eq]
      dsimp [Up]
      linarith
    calc 4 * (attemptUnitCap p M F_sz F_A1 F_c LZ LZ UC + 16)
        ≤ 4 * (p.m * p.w * Up) := Nat.mul_le_mul_left 4 hsum_u
      _ = p.m * p.w * (4 * Up) := by ring
      _ ≤ p.m * p.w * _ := Nat.mul_le_mul_left (p.m * p.w) (Nat.le_add_right (4 * Up) _)
  -- 4. Bit cost cap
  have hbitc_tot : 4 * (attemptBitCap p V M T_sz T_A1 T_c F_sz F_A1 F_c LZ LZ UC + 4 * V + 16) ≤
      p.m * p.w ^ 2 * timeCapNat p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c p.d p.B := by
    let VC := vCoefNat p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c p.d p.B
    have hv_le : ∀ extra : ℕ, extra ≤ natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 20 →
        (V + extra) ^ 2 ≤ p.w ^ 2 * VC ^ 2 := by
      intro extra hex
      have hlin : V + extra ≤ p.w * VC := by
        have h1 : V + extra ≤ 4 * p.w + (QV + natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 24) := by
          dsimp [V]; omega
        have h2 : QV + natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 24 ≤
            p.w * (QV + natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 24) :=
          Nat.le_mul_of_pos_left _ hw1
        calc V + extra ≤ 4 * p.w + p.w * (QV + natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 24) := by omega
          _ = p.w * VC := by dsimp [VC, vCoefNat, QV]; ring
      calc (V + extra) ^ 2 ≤ (p.w * VC) ^ 2 := Nat.pow_le_pow_left hlin 2
        _ = p.w ^ 2 * VC ^ 2 := by ring
    have hv8 := hv_le 8 (by omega)
    have hv_sz8 := hv_le (natBitLength T_sz + 8) (by omega)
    have hv_sz16 := hv_le (natBitLength T_sz + 16) (by omega)
    have hv_a1_8 := hv_le (natBitLength T_A1 + 8) (by omega)
    have hv_a1_16 := hv_le (natBitLength T_A1 + 16) (by omega)
    have hv_c8 := hv_le (natBitLength T_c + 8) (by omega)
    have hv_c16 := hv_le (natBitLength T_c + 16) (by omega)
    have h_m_sq : ∀ {C_m Y : ℕ}, Y ≤ p.w ^ 2 * VC ^ 2 →
        (p.m * C_m) * Y ≤ p.m * p.w ^ 2 * (C_m * VC ^ 2) := fun {C_m Y} hY =>
      calc (p.m * C_m) * Y ≤ (p.m * C_m) * (p.w ^ 2 * VC ^ 2) := Nat.mul_le_mul_left _ hY
        _ = p.m * p.w ^ 2 * (C_m * VC ^ 2) := by ring
    have h_1_sq : ∀ {C_1 Y : ℕ}, Y ≤ p.w ^ 2 * VC ^ 2 →
        C_1 * Y ≤ p.m * p.w ^ 2 * (C_1 * VC ^ 2) := fun {C_1 Y} hY =>
      calc C_1 * Y ≤ C_1 * (p.w ^ 2 * VC ^ 2) := Nat.mul_le_mul_left _ hY
        _ ≤ p.m * (C_1 * (p.w ^ 2 * VC ^ 2)) := Nat.le_mul_of_pos_left _ hm1
        _ = p.m * p.w ^ 2 * (C_1 * VC ^ 2) := by ring
    have hb0 := h_1_sq (C_1 := 4000000 + 400000 * (p.deg_α + p.deg_alg)) hv8
    have hb1 : (300000 + p.m * (1000000 + 500000 * p.d + 600 * p.B_lift)) * (V + 8) ^ 2 ≤
        p.m * p.w ^ 2 * ((300000 + (1000000 + 500000 * p.d + 600 * p.B_lift)) * VC ^ 2) := by
      rw [Nat.add_mul]
      have ha := h_1_sq (C_1 := 300000) hv8
      have hb := h_m_sq (C_m := 1000000 + 500000 * p.d + 600 * p.B_lift) hv8
      linarith
    have hb2_sq : 256 * F_sz * (V + natBitLength T_sz + 8) ^ 2 * (2 * LZ + 16) * LZ +
        1000000 * (V + natBitLength T_sz + 16) ^ 2 ≤
        p.m * p.w ^ 2 * ((256 * F_sz * (2 * LZ + 16) * LZ + 1000000) * VC ^ 2) := by
      have ha : 256 * F_sz * (V + natBitLength T_sz + 8) ^ 2 * (2 * LZ + 16) * LZ =
          (256 * F_sz * (2 * LZ + 16) * LZ) * (V + (natBitLength T_sz + 8)) ^ 2 := by ring
      have hb : V + natBitLength T_sz + 16 = V + (natBitLength T_sz + 16) := by omega
      rw [ha, hb]
      have h1 := h_1_sq (C_1 := 256 * F_sz * (2 * LZ + 16) * LZ) hv_sz8
      have h2 := h_1_sq (C_1 := 1000000) hv_sz16
      linarith
    have hb3_sq : (2000000 + M * (1200000 + 600000 * p.d) + p.D * (1000000 + 600 * p.L_z)) *
        (V + natBitLength T_A1 + 16) ^ 2 +
        256 * F_A1 * (V + natBitLength T_A1 + 8) ^ 2 * (2 * LZ + 16) * LZ ≤
        p.m * p.w ^ 2 * ((2000000 + LZ * (1200000 + 600000 * p.d) + (p.d + 1) * (1000000 + 600 * LZ) +
          256 * F_A1 * (2 * LZ + 16) * LZ) * VC ^ 2) := by
      have hM_le : 2000000 + M * (1200000 + 600000 * p.d) + p.D * (1000000 + 600 * p.L_z) ≤
          2000000 + LZ * (1200000 + 600000 * p.d) + (p.d + 1) * (1000000 + 600 * LZ) := by
        have hMLz' : M ≤ LZ := hMLz
        rw [hD_eq, hLz_eq]
        have := Nat.mul_le_mul_right (1200000 + 600000 * p.d) hMLz'
        omega
      have ha : V + natBitLength T_A1 + 16 = V + (natBitLength T_A1 + 16) := by omega
      have hb : 256 * F_A1 * (V + natBitLength T_A1 + 8) ^ 2 * (2 * LZ + 16) * LZ =
          (256 * F_A1 * (2 * LZ + 16) * LZ) * (V + (natBitLength T_A1 + 8)) ^ 2 := by ring
      rw [ha, hb]
      have h1 := (Nat.mul_le_mul_right _ hM_le).trans (h_1_sq hv_a1_16)
      have h2 := h_1_sq (C_1 := 256 * F_A1 * (2 * LZ + 16) * LZ) hv_a1_8
      linarith
    have hb4 : (400000 + p.m * 900000) * (V + 8) ^ 2 ≤
        p.m * p.w ^ 2 * ((400000 + 900000) * VC ^ 2) := by
      rw [Nat.add_mul]
      have h1 := h_1_sq (C_1 := 400000) hv8
      have h2 := h_m_sq (C_m := 900000) hv8
      linarith
    have hb5_sq : (2000000 + 800000 * (p.D + p.s₀ * p.D)) * (V + natBitLength T_c + 16) ^ 2 +
        p.r * ((2000000 + p.s₀ * (1500000 + 300000 * p.d)) * (V + natBitLength T_c + 16) ^ 2 +
          256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * UC + 16) * UC) ≤
        p.m * p.w ^ 2 * ((2000000 + 800000 * ((p.d + 1) + p.s₀ * (p.d + 1)) +
          2000000 + p.s₀ * (1500000 + 300000 * p.d) + 256 * F_c * (2 * UC + 16) * UC) * VC ^ 2) := by
      have ha : V + natBitLength T_c + 16 = V + (natBitLength T_c + 16) := by omega
      have hb : 256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * UC + 16) * UC =
          (256 * F_c * (2 * UC + 16) * UC) * (V + (natBitLength T_c + 8)) ^ 2 := by ring
      rw [ha, hb, hD_eq]
      have h1 := h_1_sq (C_1 := 2000000 + 800000 * ((p.d + 1) + p.s₀ * (p.d + 1))) hv_c16
      have hr_le := Nat.mul_le_mul_right
        ((2000000 + p.s₀ * (1500000 + 300000 * p.d)) * (V + (natBitLength T_c + 16)) ^ 2 +
          (256 * F_c * (2 * UC + 16) * UC) * (V + (natBitLength T_c + 8)) ^ 2) hr_le_m
      have h2 := h_m_sq (C_m := 2000000 + p.s₀ * (1500000 + 300000 * p.d)) hv_c16
      have h3 := h_m_sq (C_m := 256 * F_c * (2 * UC + 16) * UC) hv_c8
      linarith
    have hb6 : (1500000 + 600000 * p.D + 800000 * p.m) * (V + 8) ^ 2 + (4 * V + 16) ≤
        p.m * p.w ^ 2 * ((1500000 + 600000 * (p.d + 1) + 800000 + 32) * VC ^ 2) := by
      rw [hD_eq, Nat.add_mul]
      have h1 := h_1_sq (C_1 := 1500000 + 600000 * (p.d + 1)) hv8
      have h2 := h_m_sq (C_m := 800000) hv8
      have h3 : 4 * V + 16 ≤ 32 * (V + 8) ^ 2 := by
        rw [sq]
        have : 4 * V + 16 ≤ 32 * (V + 8) := by omega
        exact this.trans (Nat.mul_le_mul_left 32 (Nat.le_mul_of_pos_right _ (by omega)))
      have h4 := h3.trans (h_1_sq (C_1 := 32) hv8)
      linarith
    -- Non-(V+..)^2 additive subroutine cleanup terms
    have hex_sz : (LZ + 2) * (8 * natBitLength (LZ + 2) + 4 * (LZ + 2 * natBitLength T_sz + 6) + 80) ≤
        p.m * p.w ^ 2 * ((LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_sz + 6) + 80)) := by
      have hnb := natBitLength_le (LZ + 2)
      exact (Nat.mul_le_mul_left (LZ + 2) (by omega)).trans (le_mw2 hm1 hw1)
    have hex_a1 : (LZ + 2) * (8 * natBitLength (LZ + 2) + 4 * (LZ + 2 * natBitLength T_A1 + 6) + 80) ≤
        p.m * p.w ^ 2 * ((LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_A1 + 6) + 80)) := by
      have hnb := natBitLength_le (LZ + 2)
      exact (Nat.mul_le_mul_left (LZ + 2) (by omega)).trans (le_mw2 hm1 hw1)
    have hex_c : p.r * ((UC + 2) * (8 * natBitLength (UC + 2) + 4 * (UC + 2 * natBitLength T_c + 6) + 80)) ≤
        p.m * p.w ^ 2 * ((UC + 2) * (8 * (UC + 3) + 4 * (UC + 2 * natBitLength T_c + 6) + 80) + 32) := by
      have hnb := natBitLength_le (UC + 2)
      let Ec := (UC + 2) * (8 * (UC + 3) + 4 * (UC + 2 * natBitLength T_c + 6) + 80) + 32
      have h1 : (UC + 2) * (8 * natBitLength (UC + 2) + 4 * (UC + 2 * natBitLength T_c + 6) + 80) ≤ Ec := by
        dsimp [Ec]
        exact (Nat.mul_le_mul_left (UC + 2) (by omega)).trans (Nat.le_add_right _ 32)
      calc p.r * _ ≤ p.m * Ec := Nat.mul_le_mul hr_le_m h1
        _ ≤ p.m * (p.w ^ 2 * Ec) := Nat.mul_le_mul_left p.m
            (Nat.le_mul_of_pos_left Ec (Nat.pos_of_ne_zero (by positivity)))
        _ = p.m * p.w ^ 2 * Ec := by ring
    let Bsq := (4000000 + 400000 * (p.deg_α + p.deg_alg)) +
      (300000 + (1000000 + 500000 * p.d + 600 * p.B_lift)) +
      (256 * F_sz * (2 * LZ + 16) * LZ + 1000000) +
      (2000000 + LZ * (1200000 + 600000 * p.d) + (p.d + 1) * (1000000 + 600 * LZ) +
        256 * F_A1 * (2 * LZ + 16) * LZ) +
      (400000 + 900000) +
      (2000000 + 800000 * ((p.d + 1) + p.s₀ * (p.d + 1)) +
        2000000 + p.s₀ * (1500000 + 300000 * p.d) + 256 * F_c * (2 * UC + 16) * UC) +
      (1500000 + 600000 * (p.d + 1) + 800000) + 32
    let Bex := (LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_sz + 6) + 80) +
      (LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_A1 + 6) + 80) +
      (UC + 2) * (8 * (UC + 3) + 4 * (UC + 2 * natBitLength T_c + 6) + 80) + 32
    have hsum_b : attemptBitCap p V M T_sz T_A1 T_c F_sz F_A1 F_c LZ LZ UC + 4 * V + 16 ≤
        p.m * p.w ^ 2 * (Bsq * VC ^ 2 + Bex) := by
      unfold attemptBitCap
      rw [Nat.mul_add]
      dsimp [Bsq, Bex]
      linarith
    unfold timeCapNat
    dsimp only
    rw [← hLz_eq, ← hs0_eq, ← hBl_eq]
    calc 4 * (attemptBitCap p V M T_sz T_A1 T_c F_sz F_A1 F_c LZ LZ UC + 4 * V + 16)
        ≤ 4 * (p.m * p.w ^ 2 * (Bsq * VC ^ 2 + Bex)) := Nat.mul_le_mul_left 4 hsum_b
      _ = p.m * p.w ^ 2 * (4 * (Bsq * VC ^ 2 + Bex)) := by ring
      _ ≤ p.m * p.w ^ 2 * _ := Nat.mul_le_mul_left (p.m * p.w ^ 2) (Nat.le_add_left _ _)
  exact ⟨hcell_tot, hbit_tot, hunit_tot, hbitc_tot⟩

end UL.Proof_lem_A_2
