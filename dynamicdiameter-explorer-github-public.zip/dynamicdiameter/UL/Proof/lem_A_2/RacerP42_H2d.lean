import Mathlib
import UL.Proof.lem_A_2.H2c_SimExec
set_option autoImplicit false
set_option maxHeartbeats 2000000

namespace UL.Proof_lem_A_2

/-! ### 1. Stack invariant and single-step `RunsTo` helper -/

def StackOK (F T_max : ℕ) : List BitRAMCont → Prop
  | [] => True
  | .popScope _ :: rest => StackOK F T_max rest
  | .repeatLoop _ body :: rest =>
      maxTableStmtFull body ≤ T_max ∧ stmtFactor body ≤ F ∧ StackOK F T_max rest
  | .stmt s :: rest =>
      maxTableStmtFull s ≤ T_max ∧ stmtFactor s ≤ F ∧ StackOK F T_max rest

def SubHeapLogged (T_max : ℕ) (wsSub : WordStore) (log : List ℤ) : Prop :=
  ∀ u ∈ wsSub.live, ∀ t idx, u = .heap t idx →
    t < T_max ∧ (idx * (T_max : ℤ) + (t : ℤ)) ∈ log

private theorem step_RunsTo {d : ℕ} {inp : BitRAMInput d}
    {c : BitRAMCont} {mid tail : List BitRAMCont}
    {st₁ st₂ st₃ : BitRAMExecState}
    (hstep : ∀ (r : List BitRAMCont) (k : ℕ),
      runBitRAMFuel inp (k + 1) (c :: r) st₁ = runBitRAMFuel inp k (mid ++ r) st₂)
    (hrest : RunsTo inp (mid ++ tail) st₂ st₃) :
    RunsTo inp (c :: tail) st₁ st₃ := by
  rcases hrest with ⟨f, hf⟩
  refine ⟨1 + f, fun r k => ?_⟩
  have hcons : (c :: tail) ++ r = c :: (tail ++ r) := rfl
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega,
    hcons, hstep (tail ++ r) (f + k), ← List.append_assoc, hf r k]

private theorem cost_step_combine {cE cSim' cSim dSim K outC subC' subC dSub : ℕ}
    (hE : cE ≤ cSim' + K * (outC - subC'))
    (hcSim : cSim' = cSim + dSim)
    (hsub : subC' = subC + dSub)
    (hm : subC' ≤ outC)
    (hd : dSim ≤ K * dSub) :
    cE ≤ cSim + K * (outC - subC) := by
  subst hcSim; subst hsub
  have hsplit : K * (outC - (subC + dSub)) + K * dSub = K * (outC - subC) := by
    rw [← Nat.mul_add, show outC - (subC + dSub) + dSub = outC - subC by omega]
  omega

private theorem kbit_ge_256 {F Q M : ℕ} (hF : 1 ≤ F) (hQ : 1 ≤ Q) (hM : 1 ≤ M) :
    256 ≤ 256 * F * Q * M := by
  have h1 : 256 ≤ 256 * F := Nat.le_mul_of_pos_right 256 hF
  have h2 : 256 * F ≤ 256 * F * Q := Nat.le_mul_of_pos_right _ hQ
  exact h1.trans (h2.trans (Nat.le_mul_of_pos_right _ hM))

private theorem kbit_quad_bound {f F Q M b : ℕ} (hf : f ≤ F) (hb : b ≤ M) :
    f * Q * (b ^ 2) ≤ (256 * F * Q * M) * b := by
  have h1 : f ≤ 256 * F := hf.trans (Nat.le_mul_of_pos_left F (by norm_num))
  have h2 : f * Q ≤ 256 * F * Q := Nat.mul_le_mul_right Q h1
  have h3 : (f * Q) * b ≤ (256 * F * Q) * M := Nat.mul_le_mul h2 hb
  calc f * Q * (b ^ 2) = ((f * Q) * b) * b := by ring
    _ ≤ ((256 * F * Q) * M) * b := Nat.mul_le_mul_right b h3

private theorem unit_quad_bound {f F u : ℕ} (hf : f ≤ F) :
    f * u ≤ (64 * F) * u :=
  Nat.mul_le_mul_right u (hf.trans (Nat.le_mul_of_pos_left F (by norm_num)))

private theorem seq_step_RunsTo {d : ℕ} {inp : BitRAMInput d}
    {s : BitRAMStmt} {rest : List BitRAMCont}
    {st₁ st₂ st₃ : BitRAMExecState}
    (hs : RunsTo inp [.stmt s] st₁ st₂)
    (hrest : RunsTo inp rest st₂ st₃) :
    RunsTo inp (.stmt s :: rest) st₁ st₃ :=
  RunsTo.trans hs hrest

/-! ### 2. Main stack simulation theorem `simulate_trStack` -/

theorem simulate_trStack {isDimD : Bool} {d dSub T_max F L_p : ℕ}
    {inpSim : BitRAMInput d} {inpSub : BitRAMInput dSub}
    {wsBase : WordStore}
    (hstage : SimStageMatches isDimD d dSub L_p wsBase inpSub)
    (hT : 1 ≤ T_max) (hF : 1 ≤ F) :
    ∀ (fuel : ℕ) (stack : List BitRAMCont)
      (stSub stSim : BitRAMExecState) (outSub : BitRAMExecOutcome)
      (log : List ℤ),
      let L_enc : ℕ := outSub.bitCost + 2 * natBitLength T_max + 6
      let K_bit : ℕ := 256 * F * (L_p + natBitLength T_max + 8) ^ 2 *
        (outSub.bitCost + outSub.unitCost + 16)
      WellFormedWS stSub.words →
      StackOK F T_max stack →
      SubHeapLogged T_max stSub.words log →
      log.length ≤ stSub.unitCost →
      (∀ x ∈ log, intBitLength x ≤ L_enc) →
      stSub.remainingBits = [] →
      stSim.words = simMergeStore wsBase T_max hT stSub.words log →
      stSim.frameDepth = 2 + stSub.frameDepth →
      inpSub.inputCellSpace + stSub.words.cellCount ≤ stSub.peakCellSpace →
      inpSub.inputBitSpace + stSub.words.bitSize ≤ stSub.peakBitSpace →
      runBitRAMFuel inpSub fuel stack stSub = .halted outSub →
      ∃ (wsEnd : WordStore) (logEnd : List ℤ) (stEnd : BitRAMExecState),
        RunsTo inpSim (stack.map (trCont isDimD T_max)) stSim stEnd ∧
        WellFormedWS wsEnd ∧
        outSub.words = wsEnd.popDepth 0 ∧
        SubHeapLogged T_max wsEnd logEnd ∧
        logEnd.length ≤ outSub.unitCost ∧
        (∀ x ∈ logEnd, intBitLength x ≤ L_enc) ∧
        stEnd.words = simMergeStore wsBase T_max hT wsEnd logEnd ∧
        stEnd.remainingBits = stSim.remainingBits ∧
        stEnd.unitCost ≤ stSim.unitCost + 64 * F * (outSub.unitCost - stSub.unitCost) ∧
        stEnd.bitCost ≤ stSim.bitCost + K_bit * (outSub.bitCost - stSub.bitCost) ∧
        stEnd.peakCellSpace ≤ max stSim.peakCellSpace
          (inpSim.inputCellSpace + wsBase.cellCount + outSub.peakCellSpace + outSub.unitCost + 3) ∧
        stEnd.peakBitSpace ≤ max stSim.peakBitSpace
          (inpSim.inputBitSpace + wsBase.bitSize + (natBitLength T_max + 12) * outSub.peakBitSpace +
            (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12)) := by
  intro fuel
  induction fuel with
  | zero =>
      intro stack stSub stSim outSub log L_enc K_bit hwf hok hlog hlen hlogb hbitsH hws hfd _ _ hrun
      cases stack with
      | nil =>
          simp only [runBitRAMFuel, hbitsH, List.isEmpty_nil, ↓reduceIte,
            BitRAMRunStatus.halted.injEq] at hrun
          subst hrun
          exact ⟨stSub.words, log, stSim, RunsTo.nil stSim, hwf, rfl, hlog, hlen, hlogb,
            hws, rfl, by omega, by omega, le_max_left _ _, le_max_left _ _⟩
      | cons _ _ => simp [runBitRAMFuel] at hrun
  | succ fuel ih =>
      intro stack stSub stSim outSub log L_enc K_bit hwf hok hlog hlen hlogb hbitsH hws hfd hpcH hpbH hrun
      cases stack with
      | nil =>
          simp only [runBitRAMFuel, hbitsH, List.isEmpty_nil, ↓reduceIte,
            BitRAMRunStatus.halted.injEq] at hrun
          subst hrun
          exact ⟨stSub.words, log, stSim, RunsTo.nil stSim, hwf, rfl, hlog, hlen, hlogb,
            hws, rfl, by omega, by omega, le_max_left _ _, le_max_left _ _⟩
      | cons item rest =>
          cases item with
          | popScope prev =>
              simp only [runBitRAMFuel] at hrun
              have hok' : StackOK F T_max rest := hok
              let stSub' : BitRAMExecState :=
                { stSub with words := stSub.words.popDepth prev, frameDepth := prev }
              let stSim' : BitRAMExecState :=
                { stSim with words := stSim.words.popDepth (2 + prev), frameDepth := 2 + prev }
              have hwf' : WellFormedWS stSub'.words := wellFormedWS_popDepth hwf prev
              have hlog' : SubHeapLogged T_max stSub'.words log := fun u hu t idx heq =>
                hlog u (Finset.mem_of_mem_filter u hu) t idx heq
              have hws' : stSim'.words = simMergeStore wsBase T_max hT stSub'.words log := by
                dsimp [stSim', stSub']
                rw [hws, simMergeStore_popDepth hstage.1 hT]
              have hpc' : inpSub.inputCellSpace + stSub'.words.cellCount ≤ stSub'.peakCellSpace := by
                have := cellCount_popDepth_le stSub.words prev; dsimp [stSub']; omega
              have hpb' : inpSub.inputBitSpace + stSub'.words.bitSize ≤ stSub'.peakBitSpace := by
                have := bitSize_popDepth_le stSub.words prev; dsimp [stSub']; omega
              obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                huE, hbE, hpcE, hpbE⟩ :=
                ih rest stSub' stSim' outSub log hwf' hok' hlog' hlen hlogb hbitsH hws' rfl hpc' hpb' hrun
              refine ⟨wsE, logE, stE,
                step_RunsTo (mid := []) (fun _ _ => rfl) hruns,
                hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                huE, hbE, hpcE, hpbE⟩
          | repeatLoop rem body =>
              obtain ⟨htm_b, hfb, hok_r⟩ := hok
              cases rem with
              | zero =>
                  simp only [runBitRAMFuel] at hrun
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih rest stSub stSim outSub log hwf hok_r hlog hlen hlogb hbitsH hws hfd hpcH hpbH hrun
                  refine ⟨wsE, logE, stE,
                    step_RunsTo (mid := []) (fun _ _ => rfl) hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩
              | succ rem' =>
                  simp only [runBitRAMFuel] at hrun
                  have hok' : StackOK F T_max (.stmt body :: .repeatLoop rem' body :: rest) :=
                    ⟨htm_b, hfb, htm_b, hfb, hok_r⟩
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih (.stmt body :: .repeatLoop rem' body :: rest) stSub stSim outSub log
                      hwf hok' hlog hlen hlogb hbitsH hws hfd hpcH hpbH hrun
                  refine ⟨wsE, logE, stE,
                    step_RunsTo (mid := [.stmt (trStmt isDimD T_max body),
                      .repeatLoop rem' (trStmt isDimD T_max body)]) (fun _ _ => rfl) hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩
          | stmt s =>
              obtain ⟨htm_s, hfs, hok_r⟩ := hok
              have hag : AgreesForExpr wsBase T_max stSub.words stSub.frameDepth stSim.words := by
                rw [hws]
                exact agreesForExpr_simMergeStore hstage.1 hT hwf log stSub.frameDepth
              cases s with
              | skip =>
                  simp only [runBitRAMFuel] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono hrun
                  dsimp only at hmu hmb
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih rest
                      { stSub with unitCost := stSub.unitCost + 1, bitCost := stSub.bitCost + 1 }
                      { stSim with unitCost := stSim.unitCost + 1, bitCost := stSim.bitCost + 1 }
                      outSub log hwf hok_r hlog (Nat.le_add_right_of_le hlen) hlogb hbitsH hws hfd hpcH hpbH hrun
                  dsimp only at huE hbE hpcE hpbE
                  have h256 : 256 ≤ K_bit := kbit_ge_256 hF (Nat.one_le_pow 2 _ (by omega)) (by omega)
                  have h64 : 64 ≤ 64 * F := Nat.le_mul_of_pos_right 64 hF
                  refine ⟨wsE, logE, stE,
                    step_RunsTo (mid := []) (fun _ _ => rfl) hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    cost_step_combine huE rfl rfl hmu (by omega),
                    cost_step_combine hbE rfl rfl hmb (by omega), hpcE, hpbE⟩
              | seq s₁ s₂ =>
                  simp only [runBitRAMFuel] at hrun
                  simp only [maxTableStmtFull, stmtFactor, max_le_iff] at htm_s hfs
                  have hok' : StackOK F T_max (.stmt s₁ :: .stmt s₂ :: rest) :=
                    ⟨htm_s.1, hfs.1, htm_s.2, hfs.2, hok_r⟩
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih (.stmt s₁ :: .stmt s₂ :: rest) stSub stSim outSub log
                      hwf hok' hlog hlen hlogb hbitsH hws hfd hpcH hpbH hrun
                  refine ⟨wsE, logE, stE,
                    step_RunsTo (mid := [.stmt (trStmt isDimD T_max s₁),
                      .stmt (trStmt isDimD T_max s₂)]) (fun _ _ => rfl) hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩
              | localScope body =>
                  simp only [runBitRAMFuel] at hrun
                  let stSub' : BitRAMExecState :=
                    { stSub with words := stSub.words.popDepth stSub.frameDepth,
                                 frameDepth := stSub.frameDepth + 1 }
                  let stSim' : BitRAMExecState :=
                    { stSim with words := stSim.words.popDepth stSim.frameDepth,
                                 frameDepth := stSim.frameDepth + 1 }
                  have hwf' : WellFormedWS stSub'.words := wellFormedWS_popDepth hwf _
                  have hlog' : SubHeapLogged T_max stSub'.words log := fun u hu t idx heq =>
                    hlog u (Finset.mem_of_mem_filter u hu) t idx heq
                  have hws' : stSim'.words = simMergeStore wsBase T_max hT stSub'.words log := by
                    dsimp [stSim', stSub']
                    rw [hws, hfd, simMergeStore_popDepth hstage.1 hT]
                  have hfd' : stSim'.frameDepth = 2 + stSub'.frameDepth := by
                    dsimp [stSim', stSub']; omega
                  have hpc' : inpSub.inputCellSpace + stSub'.words.cellCount ≤ stSub'.peakCellSpace := by
                    have := cellCount_popDepth_le stSub.words stSub.frameDepth; dsimp [stSub']; omega
                  have hpb' : inpSub.inputBitSpace + stSub'.words.bitSize ≤ stSub'.peakBitSpace := by
                    have := bitSize_popDepth_le stSub.words stSub.frameDepth; dsimp [stSub']; omega
                  have hok' : StackOK F T_max (.stmt body :: .popScope stSub.frameDepth :: rest) :=
                    ⟨htm_s, hfs, hok_r⟩
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih (.stmt body :: .popScope stSub.frameDepth :: rest) stSub' stSim' outSub log
                      hwf' hok' hlog' hlen hlogb hbitsH hws' hfd' hpc' hpb' hrun
                  have hstep_loc : ∀ (r : List BitRAMCont) (k : ℕ),
                      runBitRAMFuel inpSim (k + 1) (.stmt (.localScope (trStmt isDimD T_max body)) :: r) stSim =
                        runBitRAMFuel inpSim k ([.stmt (trStmt isDimD T_max body),
                          .popScope (2 + stSub.frameDepth)] ++ r) stSim' := by
                    intro r k; simp [runBitRAMFuel, stSim', hfd]
                  refine ⟨wsE, logE, stE, step_RunsTo hstep_loc hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩
              | randBitHeap _ _ => simp [runBitRAMFuel, hbitsH] at hrun
              | randBitLocal _ _ => simp [runBitRAMFuel, hbitsH] at hrun
              | ite cond tB fB =>
                  simp only [maxTableStmtFull, stmtFactor, max_le_iff] at htm_s hfs
                  have htr := evalBitCond_trCond (inpSim := inpSim) hstage hag cond htm_s.1
                  have hpos := evalBitCond_bitOps_pos inpSub stSub.frameDepth stSub.words cond
                  rcases hc1 : evalBitCond inpSub stSub.frameDepth stSub.words cond with ⟨fl, u, b⟩
                  rcases hc2 : evalBitCond inpSim (2 + stSub.frameDepth) stSim.words
                    (trCond isDimD T_max cond) with ⟨fl', u', b'⟩
                  rw [← hfd] at hc2
                  simp only [hc1, hfd ▸ hc2] at htr hpos
                  rcases htr with ⟨heq_fl, hu', hb'⟩
                  subst fl'
                  simp only [runBitRAMFuel, hc1] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono hrun
                  dsimp only at hmu hmb
                  have hok_c : StackOK F T_max (.stmt (if fl then tB else fB) :: rest) := by
                    split_ifs <;> exact ⟨by omega, by omega, hok_r⟩
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih (.stmt (if fl then tB else fB) :: rest)
                      { stSub with unitCost := stSub.unitCost + u, bitCost := stSub.bitCost + b }
                      { stSim with unitCost := stSim.unitCost + u', bitCost := stSim.bitCost + b' }
                      outSub log hwf hok_c hlog (Nat.le_add_right_of_le hlen) hlogb hbitsH hws hfd hpcH hpbH hrun
                  dsimp only at huE hbE hpcE hpbE
                  have hstep_ite : ∀ (r : List BitRAMCont) (k : ℕ),
                      runBitRAMFuel inpSim (k + 1) (.stmt (trStmt isDimD T_max (.ite cond tB fB)) :: r) stSim =
                        runBitRAMFuel inpSim k ([.stmt (trStmt isDimD T_max (if fl then tB else fB))] ++ r)
                          { stSim with unitCost := stSim.unitCost + u', bitCost := stSim.bitCost + b' } := by
                    intro r k; simp only [trStmt, runBitRAMFuel, hc2]; cases fl <;> rfl
                  refine ⟨wsE, logE, stE, step_RunsTo hstep_ite hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    cost_step_combine huE rfl rfl hmu (hu'.trans (unit_quad_bound hfs.1)),
                    cost_step_combine hbE rfl rfl hmb (hb'.trans (kbit_quad_bound hfs.1 (by omega))),
                    hpcE, hpbE⟩
              | whileLoop cond body =>
                  simp only [maxTableStmtFull, stmtFactor, max_le_iff] at htm_s hfs
                  have htr := evalBitCond_trCond (inpSim := inpSim) hstage hag cond htm_s.1
                  have hpos := evalBitCond_bitOps_pos inpSub stSub.frameDepth stSub.words cond
                  rcases hc1 : evalBitCond inpSub stSub.frameDepth stSub.words cond with ⟨fl, u, b⟩
                  rcases hc2 : evalBitCond inpSim (2 + stSub.frameDepth) stSim.words
                    (trCond isDimD T_max cond) with ⟨fl', u', b'⟩
                  rw [← hfd] at hc2
                  simp only [hc1, hfd ▸ hc2] at htr hpos
                  rcases htr with ⟨heq_fl, hu', hb'⟩
                  subst fl'
                  simp only [runBitRAMFuel, hc1] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono hrun
                  dsimp only at hmu hmb
                  let nextSub := if fl then BitRAMCont.stmt body :: .stmt (.whileLoop cond body) :: rest else rest
                  have hok_w : StackOK F T_max nextSub := by
                    dsimp [nextSub]; split_ifs
                    · exact ⟨htm_s.2, hfs.2, ⟨max_le htm_s.1 htm_s.2, max_le hfs.1 hfs.2, hok_r⟩⟩
                    · exact hok_r
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih nextSub
                      { stSub with unitCost := stSub.unitCost + u, bitCost := stSub.bitCost + b }
                      { stSim with unitCost := stSim.unitCost + u', bitCost := stSim.bitCost + b' }
                      outSub log hwf hok_w hlog (Nat.le_add_right_of_le hlen) hlogb hbitsH hws hfd hpcH hpbH hrun
                  dsimp only at huE hbE hpcE hpbE
                  have hstep_w : ∀ (r : List BitRAMCont) (k : ℕ),
                      runBitRAMFuel inpSim (k + 1) (.stmt (trStmt isDimD T_max (.whileLoop cond body)) :: r) stSim =
                        runBitRAMFuel inpSim k
                          ((if fl then [BitRAMCont.stmt (trStmt isDimD T_max body),
                              .stmt (trStmt isDimD T_max (.whileLoop cond body))] else []) ++ r)
                          { stSim with unitCost := stSim.unitCost + u', bitCost := stSim.bitCost + b' } := by
                    intro r k; simp only [trStmt, runBitRAMFuel, hc2]; cases fl <;> rfl
                  have hmap_eq : nextSub.map (trCont isDimD T_max) =
                      (if fl then [BitRAMCont.stmt (trStmt isDimD T_max body),
                        .stmt (trStmt isDimD T_max (.whileLoop cond body))] else []) ++
                        rest.map (trCont isDimD T_max) := by
                    dsimp [nextSub]; cases fl <;> rfl
                  rw [hmap_eq] at hruns
                  refine ⟨wsE, logE, stE, step_RunsTo hstep_w hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    cost_step_combine huE rfl rfl hmu (hu'.trans (unit_quad_bound hfs.1)),
                    cost_step_combine hbE rfl rfl hmb (hb'.trans (kbit_quad_bound hfs.1 (by omega))),
                    hpcE, hpbE⟩
              | repeatN countE body =>
                  simp only [maxTableStmtFull, stmtFactor, max_le_iff] at htm_s hfs
                  have htr := evalIntExpr_trExpr (inpSim := inpSim) hstage hag countE htm_s.1
                  have hpos := evalIntExpr_bitLen_le inpSub stSub.frameDepth stSub.words countE
                  rcases he1 : evalIntExpr inpSub stSub.frameDepth stSub.words countE with ⟨cnt, u, b⟩
                  rcases he2 : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words
                    (trExpr isDimD T_max countE) with ⟨cnt', u', b'⟩
                  rw [← hfd] at he2
                  simp only [he1, hfd ▸ he2] at htr hpos
                  rcases htr with ⟨heq_cnt, hu', hb'⟩
                  subst cnt'
                  simp only [runBitRAMFuel, he1] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono hrun
                  dsimp only at hmu hmb
                  let nIter := if 0 ≤ cnt then cnt.toNat else 0
                  have hok_n : StackOK F T_max (.repeatLoop nIter body :: rest) :=
                    ⟨htm_s.2, hfs.2, hok_r⟩
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih (.repeatLoop nIter body :: rest)
                      { stSub with unitCost := stSub.unitCost + u, bitCost := stSub.bitCost + b }
                      { stSim with unitCost := stSim.unitCost + u', bitCost := stSim.bitCost + b' }
                      outSub log hwf hok_n hlog (Nat.le_add_right_of_le hlen) hlogb hbitsH hws hfd hpcH hpbH hrun
                  dsimp only at huE hbE hpcE hpbE
                  have hef : exprFactor countE ≤ F := by omega
                  have hstep_n : ∀ (r : List BitRAMCont) (k : ℕ),
                      runBitRAMFuel inpSim (k + 1) (.stmt (trStmt isDimD T_max (.repeatN countE body)) :: r) stSim =
                        runBitRAMFuel inpSim k ([.repeatLoop nIter (trStmt isDimD T_max body)] ++ r)
                          { stSim with unitCost := stSim.unitCost + u', bitCost := stSim.bitCost + b' } := by
                    intro r k; simp [trStmt, runBitRAMFuel, he2, nIter]
                  refine ⟨wsE, logE, stE, step_RunsTo hstep_n hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    cost_step_combine huE rfl rfl hmu (hu'.trans (unit_quad_bound hef)),
                    cost_step_combine hbE rfl rfl hmb (hb'.trans (kbit_quad_bound hef (by omega))),
                    hpcE, hpbE⟩
              | freeLocal var idxE =>
                  have htr := evalIntExpr_trExpr (inpSim := inpSim) hstage hag idxE htm_s
                  have hpos := evalIntExpr_bitLen_le inpSub stSub.frameDepth stSub.words idxE
                  rcases he1 : evalIntExpr inpSub stSub.frameDepth stSub.words idxE with ⟨idx, u, b⟩
                  rcases he2 : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words
                    (trExpr isDimD T_max idxE) with ⟨idx', u', b'⟩
                  rw [← hfd] at he2
                  simp only [he1, hfd ▸ he2] at htr hpos
                  rcases htr with ⟨heq_idx, hu', hb'⟩
                  subst idx'
                  simp only [runBitRAMFuel, he1] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono hrun
                  dsimp only at hmu hmb
                  let stSub' : BitRAMExecState :=
                    { stSub with words := stSub.words.free (.localFrame stSub.frameDepth var idx),
                                 unitCost := stSub.unitCost + u + 1,
                                 bitCost := stSub.bitCost + b + (RAMCellLoc.localFrame stSub.frameDepth var idx).bitLength }
                  let stSim' : BitRAMExecState :=
                    { stSim with words := stSim.words.free (.localFrame stSim.frameDepth var idx),
                                 unitCost := stSim.unitCost + u' + 1,
                                 bitCost := stSim.bitCost + b' + (RAMCellLoc.localFrame stSim.frameDepth var idx).bitLength }
                  have hwf' : WellFormedWS stSub'.words := wellFormedWS_free hwf _
                  have hlog' : SubHeapLogged T_max stSub'.words log := fun u₀ hu₀ t₀ idx₀ heq =>
                    hlog u₀ (Finset.mem_of_mem_erase hu₀) t₀ idx₀ heq
                  have hws' : stSim'.words = simMergeStore wsBase T_max hT stSub'.words log := by
                    dsimp [stSim', stSub']
                    rw [hws, hfd]
                    exact simMergeStore_free_sub hstage.1 hT stSub.words log
                      (.localFrame stSub.frameDepth var idx)
                  have hpc' : inpSub.inputCellSpace + stSub'.words.cellCount ≤ stSub'.peakCellSpace := by
                    have := cellCount_free_le stSub.words (.localFrame stSub.frameDepth var idx)
                    dsimp [stSub']; omega
                  have hpb' : inpSub.inputBitSpace + stSub'.words.bitSize ≤ stSub'.peakBitSpace := by
                    have := bitSize_free_le stSub.words (.localFrame stSub.frameDepth var idx)
                    dsimp [stSub']; omega
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih rest stSub' stSim' outSub log hwf' hok_r hlog' (by dsimp [stSub']; omega)
                      hlogb hbitsH hws' hfd hpc' hpb' hrun
                  dsimp [stSub', stSim'] at huE hbE hpcE hpbE
                  have hstep_fl : ∀ (r : List BitRAMCont) (k : ℕ),
                      runBitRAMFuel inpSim (k + 1) (.stmt (trStmt isDimD T_max (.freeLocal var idxE)) :: r) stSim =
                        runBitRAMFuel inpSim k ([] ++ r) stSim' := by
                    intro r k; simp [trStmt, runBitRAMFuel, he2, stSim']
                  have hloc_le :
                      (RAMCellLoc.localFrame stSim.frameDepth var idx).bitLength ≤
                        2 * (RAMCellLoc.localFrame stSub.frameDepth var idx).bitLength + 4 := by
                    rw [hfd]
                    dsimp [RAMCellLoc.bitLength]
                    have hadd := natBitLength_add_le 2 stSub.frameDepth
                    have hn2 : natBitLength 2 = 2 := by decide
                    omega
                  have hef : exprFactor idxE ≤ F := by simp [stmtFactor] at hfs; omega
                  have h64 : 64 ≤ 64 * F := Nat.le_mul_of_pos_right 64 hF
                  have h256 : 256 ≤ K_bit := kbit_ge_256 hF (Nat.one_le_pow 2 _ (by omega)) (by omega)
                  have hu_q : u' ≤ (64 * F) * u := hu'.trans (unit_quad_bound hef)
                  have hb_q : b' ≤ K_bit * b := hb'.trans (kbit_quad_bound
                    (Q := (L_p + natBitLength T_max + 8) ^ 2)
                    (M := outSub.bitCost + outSub.unitCost + 16) hef (by omega))
                  have hloc1 := ramCellLoc_bitLength_pos (.localFrame stSub.frameDepth var idx)
                  have hlocK : 6 * (RAMCellLoc.localFrame stSub.frameDepth var idx).bitLength ≤
                      K_bit * (RAMCellLoc.localFrame stSub.frameDepth var idx).bitLength :=
                    Nat.mul_le_mul_right _ (by omega)
                  refine ⟨wsE, logE, stE, step_RunsTo hstep_fl hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    cost_step_combine huE (cSim := stSim.unitCost) (dSim := u' + 1)
                      (subC := stSub.unitCost) (dSub := u + 1)
                      (by omega) (by omega) (by exact hmu)
                      (by rw [Nat.mul_add]; omega),
                    cost_step_combine hbE (cSim := stSim.bitCost)
                      (dSim := b' + (RAMCellLoc.localFrame stSim.frameDepth var idx).bitLength)
                      (subC := stSub.bitCost)
                      (dSub := b + (RAMCellLoc.localFrame stSub.frameDepth var idx).bitLength)
                      (by omega) (by omega) (by dsimp [RAMCellLoc.bitLength] at hmb ⊢; exact hmb)
                      (by rw [Nat.mul_add]; omega),
                    hpcE, hpbE⟩
              | freeHeap table idxE =>
                  simp only [maxTableStmtFull, max_le_iff] at htm_s
                  have ht_lt : table < T_max := by omega
                  have htr := evalIntExpr_trExpr (inpSim := inpSim) hstage hag idxE htm_s.2
                  have hpos := evalIntExpr_bitLen_le inpSub stSub.frameDepth stSub.words idxE
                  rcases he1 : evalIntExpr inpSub stSub.frameDepth stSub.words idxE with ⟨idx, u, b⟩
                  rcases he2 : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words
                    (trExpr isDimD T_max idxE) with ⟨idx', u', b'⟩
                  rw [← hfd] at he2
                  simp only [he1, hfd ▸ he2] at htr hpos
                  rcases htr with ⟨heq_idx, hu', hb'⟩
                  subst idx'
                  simp only [runBitRAMFuel, he1] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono hrun
                  dsimp only at hmu hmb
                  let enc : ℤ := idx * (T_max : ℤ) + (table : ℤ)
                  have henc_eval :
                      evalIntExpr inpSim stSim.frameDepth stSim.words
                        (.add (.mul (trExpr isDimD T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ))) =
                      (enc,
                       u' + 1 + 1 + 1 + 1,
                       b' + intBitLength (T_max : ℤ) + intBitLength idx * intBitLength (T_max : ℤ) +
                         intBitLength (table : ℤ) + intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ)) := by
                    simp [evalIntExpr, he2, enc]
                  let stSub' : BitRAMExecState :=
                    { stSub with words := stSub.words.free (.heap table idx),
                                 unitCost := stSub.unitCost + u + 1,
                                 bitCost := stSub.bitCost + b + (RAMCellLoc.heap table idx).bitLength }
                  rcases he_enc : evalIntExpr inpSim stSim.frameDepth stSim.words
                    (.add (.mul (trExpr isDimD T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ))) with
                    ⟨enc_v, u_enc, b_enc⟩
                  have henc_eq := he_enc.symm.trans henc_eval
                  rcases Prod.mk.inj henc_eq with ⟨heq_e1, henc_eq2⟩
                  rcases Prod.mk.inj henc_eq2 with ⟨heq_e2, heq_e3⟩
                  subst enc_v
                  let stSim' : BitRAMExecState :=
                    { stSim with words := stSim.words.free (.heap 10 enc),
                                 unitCost := stSim.unitCost + u_enc + 1,
                                 bitCost := stSim.bitCost + b_enc + (RAMCellLoc.heap 10 enc).bitLength }
                  have hwf' : WellFormedWS stSub'.words := wellFormedWS_free hwf _
                  have hlog' : SubHeapLogged T_max stSub'.words log := fun u₀ hu₀ t₀ idx₀ heq =>
                    hlog u₀ (Finset.mem_of_mem_erase hu₀) t₀ idx₀ heq
                  have hws' : stSim'.words = simMergeStore wsBase T_max hT stSub'.words log := by
                    dsimp [stSim', stSub']
                    have hsh : shiftSubLoc T_max (.heap table idx) = .heap 10 enc := by
                      dsimp [shiftSubLoc, enc]
                      rw [if_pos ht_lt]
                    rw [hws, ← hsh]
                    exact simMergeStore_free_sub hstage.1 hT stSub.words log (.heap table idx)
                  have hpc' : inpSub.inputCellSpace + stSub'.words.cellCount ≤ stSub'.peakCellSpace := by
                    have := cellCount_free_le stSub.words (.heap table idx); dsimp [stSub']; omega
                  have hpb' : inpSub.inputBitSpace + stSub'.words.bitSize ≤ stSub'.peakBitSpace := by
                    have := bitSize_free_le stSub.words (.heap table idx); dsimp [stSub']; omega
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih rest stSub' stSim' outSub log hwf' hok_r hlog' (by dsimp [stSub']; omega)
                      hlogb hbitsH hws' hfd hpc' hpb' hrun
                  dsimp [stSub', stSim'] at huE hbE hpcE hpbE
                  have hstep_fh : ∀ (r : List BitRAMCont) (k : ℕ),
                      runBitRAMFuel inpSim (k + 1) (.stmt (trStmt isDimD T_max (.freeHeap table idxE)) :: r) stSim =
                        runBitRAMFuel inpSim k ([] ++ r) stSim' := by
                    intro r k; simp [trStmt, runBitRAMFuel, he_enc, stSim']
                  subst u_enc; subst b_enc
                  have hT_ib : intBitLength (T_max : ℤ) ≤ natBitLength T_max + 1 := by
                    unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
                  have ht_ib : intBitLength (table : ℤ) ≤ natBitLength T_max + 1 := by
                    have := natBitLength_mono (le_of_lt ht_lt)
                    unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
                  have hmul_ib := intBitLength_mul_le idx (T_max : ℤ)
                  have hadd_ib := intBitLength_add_le (idx * (T_max : ℤ)) (table : ℤ)
                  have hn10 : natBitLength 10 = 4 := by decide
                  have hloc_enc : (RAMCellLoc.heap 10 enc).bitLength ≤
                      intBitLength idx + 2 * natBitLength T_max + 8 := by
                    dsimp [RAMCellLoc.bitLength, enc]; rw [hn10]; omega
                  have hef : exprFactor idxE ≤ F := by simp [stmtFactor] at hfs; omega
                  have h64 : 64 ≤ 64 * F := Nat.le_mul_of_pos_right 64 hF
                  have hu_q : u' ≤ (64 * F) * u := hu'.trans (unit_quad_bound hef)
                  have hb_q : b' ≤ K_bit * b := hb'.trans (kbit_quad_bound
                    (Q := (L_p + natBitLength T_max + 8) ^ 2)
                    (M := outSub.bitCost + outSub.unitCost + 16) hef (by omega))
                  have hloc_ge_idx : intBitLength idx ≤ (RAMCellLoc.heap table idx).bitLength := by
                    dsimp [RAMCellLoc.bitLength]; omega
                  have hloc1 := ramCellLoc_bitLength_pos (.heap table idx)
                  let Q := (L_p + natBitLength T_max + 8) ^ 2
                  let M_out := outSub.bitCost + outSub.unitCost + 16
                  have hQ_ge : natBitLength T_max + 8 ≤ Q := by
                    dsimp [Q]; rw [sq]
                    exact (by omega : natBitLength T_max + 8 ≤ L_p + natBitLength T_max + 8).trans
                      (Nat.le_mul_of_pos_right _ (by omega))
                  have hQM : Q ≤ F * Q * M_out := by
                    have h1 : Q ≤ F * Q := Nat.le_mul_of_pos_left Q hF
                    exact h1.trans (Nat.le_mul_of_pos_right _ (by dsimp [M_out]; omega))
                  have hextra_fh :
                      intBitLength (T_max : ℤ) + intBitLength idx * intBitLength (T_max : ℤ) +
                        intBitLength (table : ℤ) + intBitLength (idx * (T_max : ℤ)) +
                        intBitLength (table : ℤ) + (RAMCellLoc.heap 10 enc).bitLength ≤
                      K_bit * (RAMCellLoc.heap table idx).bitLength := by
                    set L_loc := (RAMCellLoc.heap table idx).bitLength
                    have hprod : intBitLength idx * intBitLength (T_max : ℤ) ≤ Q * L_loc := by
                      rw [mul_comm Q]
                      exact Nat.mul_le_mul hloc_ge_idx (by omega)
                    have hlin : intBitLength (T_max : ℤ) + intBitLength (table : ℤ) +
                        intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ) +
                        (RAMCellLoc.heap 10 enc).bitLength ≤
                        10 * (Q * L_loc) := by
                      have h1 : intBitLength (T_max : ℤ) + intBitLength (table : ℤ) +
                          intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ) +
                          (RAMCellLoc.heap 10 enc).bitLength ≤
                          8 * Q + 2 * L_loc := by omega
                      have h2 : Q ≤ Q * L_loc := Nat.le_mul_of_pos_right Q hloc1
                      have h3 : L_loc ≤ Q * L_loc := Nat.le_mul_of_pos_left L_loc (by omega)
                      omega
                    have h12 : 12 * (Q * L_loc) ≤ K_bit * L_loc := by
                      dsimp [K_bit]
                      rw [show 12 * (Q * L_loc) = (12 * Q) * L_loc by ring,
                          show 256 * F * Q * M_out = 256 * (F * Q * M_out) by ring]
                      refine Nat.mul_le_mul_right L_loc ?_
                      have := Nat.mul_le_mul_left 12 hQM
                      omega
                    omega
                  refine ⟨wsE, logE, stE, step_RunsTo hstep_fh hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    cost_step_combine huE (cSim := stSim.unitCost) (dSim := (u' + 1 + 1 + 1 + 1) + 1)
                      (subC := stSub.unitCost) (dSub := u + 1)
                      (by omega) (by omega) (by exact hmu)
                      (by rw [Nat.mul_add]; omega),
                    cost_step_combine hbE (cSim := stSim.bitCost)
                      (dSim := (b' + intBitLength (T_max : ℤ) + intBitLength idx * intBitLength (T_max : ℤ) +
                        intBitLength (table : ℤ) + intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ)) +
                        (RAMCellLoc.heap 10 enc).bitLength)
                      (subC := stSub.bitCost)
                      (dSub := b + (RAMCellLoc.heap table idx).bitLength)
                      (by omega) (by omega) (by dsimp [RAMCellLoc.bitLength] at hmb ⊢; exact hmb)
                      (by rw [Nat.mul_add]; omega),
                    hpcE, hpbE⟩
              | writeLocal var idxE valE =>
                  simp only [maxTableStmtFull, max_le_iff] at htm_s
                  have htr1 := evalIntExpr_trExpr (inpSim := inpSim) hstage hag idxE htm_s.1
                  have htr2 := evalIntExpr_trExpr (inpSim := inpSim) hstage hag valE htm_s.2
                  have hp1 := evalIntExpr_bitLen_le inpSub stSub.frameDepth stSub.words idxE
                  have hp2 := evalIntExpr_bitLen_le inpSub stSub.frameDepth stSub.words valE
                  rcases he1 : evalIntExpr inpSub stSub.frameDepth stSub.words idxE with ⟨idx, u₁, b₁⟩
                  rcases he2 : evalIntExpr inpSub stSub.frameDepth stSub.words valE with ⟨val, u₂, b₂⟩
                  rcases he1' : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words
                    (trExpr isDimD T_max idxE) with ⟨idx', u'₁, b'₁⟩
                  rcases he2' : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words
                    (trExpr isDimD T_max valE) with ⟨val', u'₂, b'₂⟩
                  rw [← hfd] at he1' he2'
                  simp only [he1, hfd ▸ he1'] at htr1 hp1
                  simp only [he2, hfd ▸ he2'] at htr2 hp2
                  rcases htr1 with ⟨heq_i, hu₁, hb₁⟩; subst idx'
                  rcases htr2 with ⟨heq_v, hu₂, hb₂⟩; subst val'
                  simp only [runBitRAMFuel, he1, he2] at hrun
                  obtain ⟨hmu, hmb, hmc, hmp⟩ := runBitRAMFuel_cost_mono hrun
                  dsimp only at hmu hmb hmc hmp
                  let locSub := RAMCellLoc.localFrame stSub.frameDepth var idx
                  let wsSub' := stSub.words.write locSub val
                  let locSim := RAMCellLoc.localFrame stSim.frameDepth var idx
                  let wsSim' := stSim.words.write locSim val
                  let stSub' : BitRAMExecState :=
                    { stSub with words := wsSub',
                                 unitCost := stSub.unitCost + u₁ + u₂ + 1,
                                 bitCost := stSub.bitCost + b₁ + b₂ + locSub.bitLength + intBitLength val,
                                 peakCellSpace := max stSub.peakCellSpace (inpSub.inputCellSpace + wsSub'.cellCount),
                                 peakBitSpace := max stSub.peakBitSpace (inpSub.inputBitSpace + wsSub'.bitSize) }
                  let stSim' : BitRAMExecState :=
                    { stSim with words := wsSim',
                                 unitCost := stSim.unitCost + u'₁ + u'₂ + 1,
                                 bitCost := stSim.bitCost + b'₁ + b'₂ + locSim.bitLength + intBitLength val,
                                 peakCellSpace := max stSim.peakCellSpace (inpSim.inputCellSpace + wsSim'.cellCount),
                                 peakBitSpace := max stSim.peakBitSpace (inpSim.inputBitSpace + wsSim'.bitSize) }
                  have hwf' : WellFormedWS wsSub' := wellFormedWS_write hwf _ _
                  have hlog' : SubHeapLogged T_max wsSub' log := by
                    intro u₀ hu₀ t₀ idx₀ heq
                    rcases Finset.mem_insert.mp hu₀ with rfl | hm
                    · nomatch heq
                    · exact hlog u₀ hm t₀ idx₀ heq
                  have hws' : wsSim' = simMergeStore wsBase T_max hT wsSub' log := by
                    dsimp [wsSim', wsSub', locSim, locSub]
                    rw [hws, hfd]
                    exact simMergeStore_write_sub hstage.1 hT stSub.words log locSub val
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih rest stSub' stSim' outSub log hwf' hok_r hlog' (by dsimp [stSub']; omega)
                      hlogb hbitsH hws' hfd
                      (by dsimp [stSub']; exact le_max_right _ _)
                      (by dsimp [stSub']; exact le_max_right _ _) hrun
                  dsimp [stSub', stSim'] at huE hbE hpcE hpbE
                  have hstep_wl : ∀ (r : List BitRAMCont) (k : ℕ),
                      runBitRAMFuel inpSim (k + 1) (.stmt (trStmt isDimD T_max (.writeLocal var idxE valE)) :: r) stSim =
                        runBitRAMFuel inpSim k ([] ++ r) stSim' := by
                    intro r k; simp [trStmt, runBitRAMFuel, he1', he2', stSim', wsSim', locSim]
                  have hsub_c : wsSub'.cellCount ≤ outSub.peakCellSpace := by
                    have h := le_trans (le_max_right _ _) hmc
                    dsimp only [wsSub', locSub] at h ⊢
                    omega
                  have hsub_b : wsSub'.bitSize ≤ outSub.peakBitSpace := by
                    have h := le_trans (le_max_right _ _) hmp
                    dsimp only [wsSub', locSub] at h ⊢
                    omega
                  have hcell_bound :
                      inpSim.inputCellSpace + wsSim'.cellCount ≤
                        inpSim.inputCellSpace + wsBase.cellCount + outSub.peakCellSpace + outSub.unitCost + 3 := by
                    rw [hws']
                    have hc := simMergeStore_cellCount_le wsBase hT wsSub' log
                    omega
                  have hbit_bound :
                      inpSim.inputBitSpace + wsSim'.bitSize ≤
                        inpSim.inputBitSpace + wsBase.bitSize +
                          (natBitLength T_max + 12) * outSub.peakBitSpace +
                          (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) := by
                    rw [hws']
                    have hb_m := simMergeStore_bitSize_le hstage.1 hT wsSub' log hlogb
                    have hll : log.length ≤ outSub.unitCost := by omega
                    have hn_ll : natBitLength log.length ≤ natBitLength (outSub.unitCost + 2) :=
                      natBitLength_mono (by omega)
                    have hm1 := Nat.mul_le_mul_left (natBitLength T_max + 12) hsub_b
                    have hm2 : (log.length + 1) * (natBitLength log.length + L_enc + 10) ≤
                        (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) :=
                      Nat.mul_le_mul (by omega) (by omega)
                    omega
                  have hloc_le : locSim.bitLength ≤ 2 * locSub.bitLength + 4 := by
                    dsimp [locSim, locSub, RAMCellLoc.bitLength]
                    rw [hfd]
                    have hadd := natBitLength_add_le 2 stSub.frameDepth
                    have hn2 : natBitLength 2 = 2 := by decide
                    omega
                  have hef : exprFactor idxE + exprFactor valE ≤ F := by
                    simp [stmtFactor] at hfs; omega
                  have h64 : 64 ≤ 64 * F := Nat.le_mul_of_pos_right 64 hF
                  have h256 : 256 ≤ K_bit := kbit_ge_256 hF (Nat.one_le_pow 2 _ (by omega)) (by omega)
                  have hu1_q : u'₁ ≤ (64 * F) * u₁ := hu₁.trans (unit_quad_bound (F := F) (by omega))
                  have hu2_q : u'₂ ≤ (64 * F) * u₂ := hu₂.trans (unit_quad_bound (F := F) (by omega))
                  have hb1_q : b'₁ ≤ K_bit * b₁ := hb₁.trans (kbit_quad_bound
                    (Q := (L_p + natBitLength T_max + 8) ^ 2)
                    (M := outSub.bitCost + outSub.unitCost + 16) (F := F) (by omega) (by dsimp [RAMCellLoc.bitLength] at hmb; omega))
                  have hb2_q : b'₂ ≤ K_bit * b₂ := hb₂.trans (kbit_quad_bound
                    (Q := (L_p + natBitLength T_max + 8) ^ 2)
                    (M := outSub.bitCost + outSub.unitCost + 16) (F := F) (by omega) (by dsimp [RAMCellLoc.bitLength] at hmb; omega))
                  have hloc1 := ramCellLoc_bitLength_pos locSub
                  have hlocK : 6 * locSub.bitLength ≤ K_bit * locSub.bitLength :=
                    Nat.mul_le_mul_right _ (by omega)
                  have hvalK : 1 * intBitLength val ≤ K_bit * intBitLength val :=
                    Nat.mul_le_mul_right _ (by omega)
                  refine ⟨wsE, logE, stE, step_RunsTo hstep_wl hruns,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    cost_step_combine huE (cSim := stSim.unitCost) (dSim := u'₁ + u'₂ + 1)
                      (subC := stSub.unitCost) (dSub := u₁ + u₂ + 1)
                      (by omega) (by omega) (by exact hmu)
                      (by simp only [Nat.mul_add]; omega),
                    cost_step_combine hbE (cSim := stSim.bitCost)
                      (dSim := b'₁ + b'₂ + locSim.bitLength + intBitLength val)
                      (subC := stSub.bitCost)
                      (dSub := b₁ + b₂ + locSub.bitLength + intBitLength val)
                      (by omega) (by omega) (by dsimp [RAMCellLoc.bitLength] at hmb ⊢; exact hmb)
                      (by simp only [Nat.mul_add]; omega),
                    by
                      refine hpcE.trans (max_le (max_le (le_max_left _ _) ?_) (le_max_right _ _))
                      exact le_trans hcell_bound (le_max_right _ _),
                    by
                      refine hpbE.trans (max_le (max_le (le_max_left _ _) ?_) (le_max_right _ _))
                      exact le_trans hbit_bound (le_max_right _ _)⟩
              | writeHeap table idxE valE =>
                  simp only [maxTableStmtFull, max_le_iff] at htm_s
                  have ht_lt : table < T_max := by omega
                  have htr1 := evalIntExpr_trExpr (inpSim := inpSim) hstage hag idxE htm_s.2.1
                  have hp1 := evalIntExpr_bitLen_le inpSub stSub.frameDepth stSub.words idxE
                  have hp2 := evalIntExpr_bitLen_le inpSub stSub.frameDepth stSub.words valE
                  rcases he1 : evalIntExpr inpSub stSub.frameDepth stSub.words idxE with ⟨idx, u₁, b₁⟩
                  rcases he2 : evalIntExpr inpSub stSub.frameDepth stSub.words valE with ⟨val, u₂, b₂⟩
                  rcases he1' : evalIntExpr inpSim (2 + stSub.frameDepth) stSim.words
                    (trExpr isDimD T_max idxE) with ⟨idx', u'₁, b'₁⟩
                  rw [← hfd] at he1'
                  simp only [he1, hfd ▸ he1'] at htr1 hp1
                  simp only [he2] at hp2
                  rcases htr1 with ⟨heq_i, hu₁, hb₁⟩; subst idx'
                  simp only [runBitRAMFuel, he1, he2] at hrun
                  obtain ⟨hmu, hmb, hmc, hmp⟩ := runBitRAMFuel_cost_mono hrun
                  dsimp only at hmu hmb hmc hmp
                  let enc : ℤ := idx * (T_max : ℤ) + (table : ℤ)
                  have hT_ib : intBitLength (T_max : ℤ) ≤ natBitLength T_max + 1 := by
                    unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
                  have ht_ib : intBitLength (table : ℤ) ≤ natBitLength T_max + 1 := by
                    have := natBitLength_mono (le_of_lt ht_lt)
                    unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
                  have hmul_ib := intBitLength_mul_le idx (T_max : ℤ)
                  have hadd_ib := intBitLength_add_le (idx * (T_max : ℤ)) (table : ℤ)
                  have henc_ib : intBitLength enc ≤ L_enc := by
                    dsimp [enc, L_enc]; omega
                  have hread12_0 : stSim.words.read (.heap 12 0) = (log.length : ℤ) := by
                    rw [hws]; exact simMergeStore_read_logLen hstage.1 hT hwf log
                  have hi0 : intBitLength 0 = 1 := rfl
                  have hi1 : intBitLength 1 = 2 := by decide
                  let encE := IntExpr.add (.mul (trExpr isDimD T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ))
                  let s₁ := BitRAMStmt.writeHeap 11 (.readHeap 12 (.lit 0)) encE
                  let s₂ := BitRAMStmt.writeHeap 10 (.readHeap 11 (.readHeap 12 (.lit 0))) (trExpr isDimD T_max valE)
                  let s₃ := BitRAMStmt.writeHeap 12 (.lit 0) (.add (.readHeap 12 (.lit 0)) (.lit 1))
                  have hs1 := RunsTo.writeHeap inpSim 11 (.readHeap 12 (.lit 0)) encE stSim
                  dsimp only at hs1
                  have he_l0 : evalIntExpr inpSim stSim.frameDepth stSim.words (.readHeap 12 (.lit 0)) =
                      ((log.length : ℤ), 2, 1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ)) := by
                    simp only [evalIntExpr, hread12_0, hi0]
                  have he_enc : evalIntExpr inpSim stSim.frameDepth stSim.words encE =
                      (enc, u'₁ + 4,
                       b'₁ + intBitLength (T_max : ℤ) + intBitLength idx * intBitLength (T_max : ℤ) +
                         intBitLength (table : ℤ) + intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ)) := by
                    simp only [encE, evalIntExpr, he1', enc]
                  rw [he_l0, he_enc] at hs1
                  dsimp only at hs1
                  set W₁ := stSim.words.write (.heap 11 (log.length : ℤ)) enc
                  set st₁ : BitRAMExecState :=
                    { stSim with
                      words := W₁
                      unitCost := stSim.unitCost + 2 + (u'₁ + 4) + 1
                      bitCost := stSim.bitCost + (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ)) +
                        (b'₁ + intBitLength (T_max : ℤ) + intBitLength idx * intBitLength (T_max : ℤ) +
                         intBitLength (table : ℤ) + intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ)) +
                        (RAMCellLoc.heap 11 (log.length : ℤ)).bitLength + intBitLength enc
                      peakCellSpace := max stSim.peakCellSpace (inpSim.inputCellSpace + W₁.cellCount)
                      peakBitSpace := max stSim.peakBitSpace (inpSim.inputBitSpace + W₁.bitSize) }
                  have hag1 : AgreesForExpr wsBase T_max stSub.words stSub.frameDepth W₁ :=
                    agreesForExpr_write_heap11 hag (log.length : ℤ) enc
                  have htr2 := evalIntExpr_trExpr (inpSim := inpSim) hstage hag1 valE htm_s.2.2
                  rcases he2' : evalIntExpr inpSim (2 + stSub.frameDepth) W₁
                    (trExpr isDimD T_max valE) with ⟨val', u'₂, b'₂⟩
                  simp only [he2, he2'] at htr2
                  rcases htr2 with ⟨heq_v, hu₂, hb₂⟩; subst val'
                  have he2_st1 : evalIntExpr inpSim st₁.frameDepth st₁.words (trExpr isDimD T_max valE) =
                      (val, u'₂, b'₂) := by
                    dsimp [st₁]; rwa [hfd]
                  have hW1_12 : W₁.read (.heap 12 0) = (log.length : ℤ) := by
                    dsimp [W₁]
                    rw [wordStore_read_write_of_ne _ (by intro h; nomatch h), hread12_0]
                  have hW1_11 : W₁.read (.heap 11 (log.length : ℤ)) = enc :=
                    wordStore_read_write_self _ _ _
                  have he_addr2 : evalIntExpr inpSim st₁.frameDepth st₁.words
                      (.readHeap 11 (.readHeap 12 (.lit 0))) =
                      (enc, 3, 1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ) +
                        natBitLength 11 + intBitLength (log.length : ℤ) + intBitLength enc) := by
                    dsimp [st₁]
                    simp only [evalIntExpr, hW1_12, hW1_11, hi0]
                  have hs2 := RunsTo.writeHeap inpSim 10 (.readHeap 11 (.readHeap 12 (.lit 0)))
                    (trExpr isDimD T_max valE) st₁
                  dsimp only at hs2
                  rw [he_addr2, he2_st1] at hs2
                  dsimp only at hs2
                  set W₂ := W₁.write (.heap 10 enc) val
                  set st₂ : BitRAMExecState :=
                    { st₁ with
                      words := W₂
                      unitCost := st₁.unitCost + 3 + u'₂ + 1
                      bitCost := st₁.bitCost +
                        (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ) +
                          natBitLength 11 + intBitLength (log.length : ℤ) + intBitLength enc) +
                        b'₂ + (RAMCellLoc.heap 10 enc).bitLength + intBitLength val
                      peakCellSpace := max st₁.peakCellSpace (inpSim.inputCellSpace + W₂.cellCount)
                      peakBitSpace := max st₁.peakBitSpace (inpSim.inputBitSpace + W₂.bitSize) }
                  have hW2_12 : W₂.read (.heap 12 0) = (log.length : ℤ) := by
                    dsimp [W₂]
                    rw [wordStore_read_write_of_ne _ (by intro h; nomatch h), hW1_12]
                  have hs3 := RunsTo.writeHeap inpSim 12 (.lit 0)
                    (.add (.readHeap 12 (.lit 0)) (.lit 1)) st₂
                  dsimp only at hs3
                  have he_zero : evalIntExpr inpSim st₂.frameDepth st₂.words (.lit 0) = (0, 1, 1) := rfl
                  have he_inc : evalIntExpr inpSim st₂.frameDepth st₂.words
                      (.add (.readHeap 12 (.lit 0)) (.lit 1)) =
                      ((log.length : ℤ) + 1, 4,
                       1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ) + 2 +
                        intBitLength (log.length : ℤ) + 2) := by
                    dsimp [st₂]
                    simp only [evalIntExpr, hW2_12, hi0, hi1]
                  rw [he_zero, he_inc] at hs3
                  dsimp only at hs3
                  set W₃ := W₂.write (.heap 12 0) ((log.length : ℤ) + 1)
                  set stSim' : BitRAMExecState :=
                    { st₂ with
                      words := W₃
                      unitCost := st₂.unitCost + 1 + 4 + 1
                      bitCost := st₂.bitCost + 1 +
                        (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ) + 2 +
                          intBitLength (log.length : ℤ) + 2) +
                        (RAMCellLoc.heap 12 0).bitLength + intBitLength ((log.length : ℤ) + 1)
                      peakCellSpace := max st₂.peakCellSpace (inpSim.inputCellSpace + W₃.cellCount)
                      peakBitSpace := max st₂.peakBitSpace (inpSim.inputBitSpace + W₃.bitSize) }
                  have h123 : RunsTo inpSim [.stmt (trStmt isDimD T_max (.writeHeap table idxE valE))]
                      stSim stSim' := by
                    change RunsTo inpSim [.stmt (.seq s₁ (.seq s₂ s₃))] stSim stSim'
                    exact RunsTo.seq hs1 (RunsTo.seq hs2 hs3)
                  let locSub := RAMCellLoc.heap table idx
                  let wsSub' := stSub.words.write locSub val
                  let log' := log ++ [enc]
                  let stSub' : BitRAMExecState :=
                    { stSub with words := wsSub',
                                 unitCost := stSub.unitCost + u₁ + u₂ + 1,
                                 bitCost := stSub.bitCost + b₁ + b₂ + locSub.bitLength + intBitLength val,
                                 peakCellSpace := max stSub.peakCellSpace (inpSub.inputCellSpace + wsSub'.cellCount),
                                 peakBitSpace := max stSub.peakBitSpace (inpSub.inputBitSpace + wsSub'.bitSize) }
                  have hwf' : WellFormedWS wsSub' := wellFormedWS_write hwf _ _
                  have hlog' : SubHeapLogged T_max wsSub' log' := by
                    intro u₀ hu₀ t₀ idx₀ heq
                    rcases Finset.mem_insert.mp hu₀ with rfl | hm
                    · injection heq with ht₀ hi₀
                      subst ht₀; subst hi₀
                      exact ⟨ht_lt, List.mem_append_right _ (List.mem_singleton_self _)⟩
                    · obtain ⟨ht₀, hmem₀⟩ := hlog u₀ hm t₀ idx₀ heq
                      exact ⟨ht₀, List.mem_append_left _ hmem₀⟩
                  have hlogb' : ∀ x ∈ log', intBitLength x ≤ L_enc := by
                    intro x hx
                    rcases List.mem_append.mp hx with hm | hm
                    · exact hlogb x hm
                    · rw [List.mem_singleton.mp hm]; exact henc_ib
                  have hws' : stSim'.words = simMergeStore wsBase T_max hT wsSub' log' := by
                    dsimp [stSim', W₃, W₂, W₁, wsSub', locSub, log']
                    rw [hws]
                    exact simMergeStore_write_heap_logged hstage.1 hT stSub.words log ht_lt idx val
                  obtain ⟨wsE, logE, stE, hruns, hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    huE, hbE, hpcE, hpbE⟩ :=
                    ih rest stSub' stSim' outSub log' hwf' hok_r hlog'
                      (by dsimp [stSub', log']; simp; omega)
                      hlogb' hbitsH hws' hfd
                      (by dsimp [stSub']; exact le_max_right _ _)
                      (by dsimp [stSub']; exact le_max_right _ _) hrun
                  have htotal_runs :
                      RunsTo inpSim (.stmt (trStmt isDimD T_max (.writeHeap table idxE valE)) ::
                        rest.map (trCont isDimD T_max)) stSim stE :=
                    seq_step_RunsTo h123 hruns
                  have hsub_c : wsSub'.cellCount ≤ outSub.peakCellSpace := by
                    have h := le_trans (le_max_right _ _) hmc
                    dsimp only [wsSub', locSub] at h ⊢
                    omega
                  have hsub_b : wsSub'.bitSize ≤ outSub.peakBitSpace := by
                    have h := le_trans (le_max_right _ _) hmp
                    dsimp only [wsSub', locSub] at h ⊢
                    omega
                  have hll_le : log.length + 1 ≤ outSub.unitCost := by omega
                  have hstSub_c : stSub.words.cellCount ≤ outSub.peakCellSpace := by omega
                  have hstSub_b : stSub.words.bitSize ≤ outSub.peakBitSpace := by omega
                  have hW0_c : stSim.words.cellCount ≤
                      wsBase.cellCount + stSub.words.cellCount + log.length + 1 := by
                    rw [hws]; exact simMergeStore_cellCount_le wsBase hT stSub.words log
                  have hW1_c : W₁.cellCount ≤ wsBase.cellCount + outSub.peakCellSpace + outSub.unitCost + 3 := by
                    have hw1c := wordStore_cellCount_write_le stSim.words (.heap 11 (log.length : ℤ)) enc
                    change (stSim.words.write (.heap 11 (log.length : ℤ)) enc).cellCount ≤ _
                    omega
                  have hW2_alt : W₂ =
                      (simMergeStore wsBase T_max hT wsSub' log).write (.heap 11 (log.length : ℤ)) enc := by
                    dsimp [W₂, W₁, wsSub', locSub]
                    rw [hws]
                    have hsh : shiftSubLoc T_max (.heap table idx) = .heap 10 enc := by
                      dsimp [shiftSubLoc, enc]
                      rw [if_pos ht_lt]
                    have hne11_10 : RAMCellLoc.heap 11 (log.length : ℤ) ≠ .heap 10 enc := by
                      intro h; nomatch h
                    have hcomm :
                        ((simMergeStore wsBase T_max hT stSub.words log).write (.heap 11 (log.length : ℤ)) enc).write (.heap 10 enc) val =
                        ((simMergeStore wsBase T_max hT stSub.words log).write (.heap 10 enc) val).write (.heap 11 (log.length : ℤ)) enc := by
                      unfold WordStore.write
                      congr 1
                      · ext x; simp [or_left_comm]
                      · funext x
                        by_cases hx10 : x = .heap 10 enc
                        · subst hx10; simp [Function.update_of_ne hne11_10.symm]
                        · by_cases hx11 : x = .heap 11 (log.length : ℤ)
                          · subst hx11; simp [Function.update_of_ne hne11_10]
                          · simp [Function.update_of_ne hx10, Function.update_of_ne hx11]
                    rw [hcomm, ← hsh, simMergeStore_write_sub hstage.1 hT stSub.words log (.heap table idx) val]
                  have hW2_c : W₂.cellCount ≤ wsBase.cellCount + outSub.peakCellSpace + outSub.unitCost + 3 := by
                    rw [hW2_alt]
                    have hc_m := simMergeStore_cellCount_le wsBase hT wsSub' log
                    have hw2c := wordStore_cellCount_write_le
                      (simMergeStore wsBase T_max hT wsSub' log) (.heap 11 (log.length : ℤ)) enc
                    omega
                  have hlen_lg : log'.length = log.length + 1 := by simp [log']
                  have hW3_c : W₃.cellCount ≤ wsBase.cellCount + outSub.peakCellSpace + outSub.unitCost + 3 := by
                    change stSim'.words.cellCount ≤ _
                    rw [hws']
                    have hc := simMergeStore_cellCount_le wsBase hT wsSub' log'
                    rw [hlen_lg] at hc
                    omega
                  have hW3_b : W₃.bitSize ≤
                      wsBase.bitSize + (natBitLength T_max + 12) * outSub.peakBitSpace +
                        (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) := by
                    change stSim'.words.bitSize ≤ _
                    rw [hws']
                    have hb_m := simMergeStore_bitSize_le hstage.1 hT wsSub' log' hlogb'
                    rw [hlen_lg] at hb_m
                    have hn_ll : natBitLength (log.length + 1) ≤ natBitLength (outSub.unitCost + 2) :=
                      natBitLength_mono (by omega)
                    have hm1 := Nat.mul_le_mul_left (natBitLength T_max + 12) hsub_b
                    have hm2 : (log.length + 1 + 1) * (natBitLength (log.length + 1) + L_enc + 10) ≤
                        (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) :=
                      Nat.mul_le_mul (by omega) (by omega)
                    omega
                  have hW0_b : stSim.words.bitSize ≤
                      wsBase.bitSize + (natBitLength T_max + 12) * stSub.words.bitSize +
                        (log.length + 1) * (natBitLength log.length + L_enc + 10) := by
                    rw [hws]; exact simMergeStore_bitSize_le hstage.1 hT stSub.words log hlogb
                  have hll_nb : intBitLength (log.length : ℤ) ≤ natBitLength (outSub.unitCost + 2) + 1 := by
                    have hn_ll : natBitLength log.length ≤ natBitLength (outSub.unitCost + 2) :=
                      natBitLength_mono (by omega)
                    unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
                  have hll1_ib : intBitLength ((log.length : ℤ) + 1) ≤ outSub.unitCost + 3 := by
                    have := intBitLength_le_natAbs (((log.length + 1 : ℕ) : ℤ))
                    simp only [Int.natAbs_natCast] at this
                    push_cast at this; omega
                  have hn11 : natBitLength 11 = 4 := by decide
                  have hn10 : natBitLength 10 = 4 := by decide
                  have hn12 : natBitLength 12 = 4 := by decide
                  have hloc11_b : (RAMCellLoc.heap 11 (log.length : ℤ)).bitLength ≤
                      natBitLength (outSub.unitCost + 2) + 5 := by
                    dsimp [RAMCellLoc.bitLength]; rw [hn11]; omega
                  have hlog_step_mul :
                      (log.length + 1) * (natBitLength log.length + L_enc + 10) +
                        (natBitLength (outSub.unitCost + 2) + L_enc + 12) ≤
                      (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) := by
                    have hn_ll : natBitLength log.length ≤ natBitLength (outSub.unitCost + 2) :=
                      natBitLength_mono (by omega)
                    have h1 : (log.length + 1) * (natBitLength log.length + L_enc + 10) ≤
                        (log.length + 1) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) :=
                      Nat.mul_le_mul_left _ (by omega)
                    have h2 : (log.length + 2) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) ≤
                        (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) :=
                      Nat.mul_le_mul_right _ (by omega)
                    rw [show log.length + 2 = (log.length + 1) + 1 by omega, Nat.add_mul, Nat.one_mul] at h2
                    omega
                  have hW1_b : W₁.bitSize ≤
                      wsBase.bitSize + (natBitLength T_max + 12) * outSub.peakBitSpace +
                        (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) := by
                    have hw1 := wordStore_bitSize_write_le stSim.words (.heap 11 (log.length : ℤ)) enc
                    have hm1 := Nat.mul_le_mul_left (natBitLength T_max + 12) hstSub_b
                    change (stSim.words.write (.heap 11 (log.length : ℤ)) enc).bitSize ≤ _
                    omega
                  have hW2_b : W₂.bitSize ≤
                      wsBase.bitSize + (natBitLength T_max + 12) * outSub.peakBitSpace +
                        (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) := by
                    rw [hW2_alt]
                    have hw2 := wordStore_bitSize_write_le
                      (simMergeStore wsBase T_max hT wsSub' log) (.heap 11 (log.length : ℤ)) enc
                    have hb_m := simMergeStore_bitSize_le hstage.1 hT wsSub' log hlogb
                    have hm1 := Nat.mul_le_mul_left (natBitLength T_max + 12) hsub_b
                    omega
                  dsimp [stSub', stSim', st₂, st₁] at huE hbE hpcE hpbE
                  have hef : exprFactor idxE + exprFactor valE ≤ F := by
                    simp [stmtFactor] at hfs; omega
                  have hloc10_b : (RAMCellLoc.heap 10 enc).bitLength ≤ L_enc + 4 := by
                    dsimp [RAMCellLoc.bitLength]; rw [hn10]; omega
                  have hloc12_b : (RAMCellLoc.heap 12 0).bitLength = 5 := by decide
                  have h64 : 64 ≤ 64 * F := Nat.le_mul_of_pos_right 64 hF
                  have h256 : 256 ≤ K_bit := kbit_ge_256 hF (Nat.one_le_pow 2 _ (by omega)) (by omega)
                  have hu1_q : u'₁ ≤ (64 * F) * u₁ := hu₁.trans (unit_quad_bound (F := F) (by omega))
                  have hu2_q : u'₂ ≤ (64 * F) * u₂ := hu₂.trans (unit_quad_bound (F := F) (by omega))
                  have hb1_q : b'₁ ≤ K_bit * b₁ := hb₁.trans (kbit_quad_bound
                    (Q := (L_p + natBitLength T_max + 8) ^ 2)
                    (M := outSub.bitCost + outSub.unitCost + 16) (F := F) (by omega) (by dsimp [RAMCellLoc.bitLength] at hmb; omega))
                  have hb2_q : b'₂ ≤ K_bit * b₂ := hb₂.trans (kbit_quad_bound
                    (Q := (L_p + natBitLength T_max + 8) ^ 2)
                    (M := outSub.bitCost + outSub.unitCost + 16) (F := F) (by omega) (by dsimp [RAMCellLoc.bitLength] at hmb; omega))
                  have hvalK : 1 * intBitLength val ≤ K_bit * intBitLength val :=
                    Nat.mul_le_mul_right _ (by omega)
                  have hloc_ge_idx : intBitLength idx ≤ locSub.bitLength := by
                    dsimp [locSub, RAMCellLoc.bitLength]; omega
                  have hloc1 := ramCellLoc_bitLength_pos locSub
                  let Q := (L_p + natBitLength T_max + 8) ^ 2
                  let M_out := outSub.bitCost + outSub.unitCost + 16
                  have hQ_ge : natBitLength T_max + 8 ≤ Q := by
                    dsimp [Q]; rw [sq]
                    exact (by omega : natBitLength T_max + 8 ≤ L_p + natBitLength T_max + 8).trans
                      (Nat.le_mul_of_pos_right _ (by omega))
                  have hQM1 : Q ≤ F * Q * M_out := by
                    have h1 : Q ≤ F * Q := Nat.le_mul_of_pos_left Q hF
                    exact h1.trans (Nat.le_mul_of_pos_right _ (by dsimp [M_out]; omega))
                  have hprod_wh : intBitLength idx * intBitLength (T_max : ℤ) ≤
                      (F * Q * M_out) * locSub.bitLength := by
                    have h1 : intBitLength idx * intBitLength (T_max : ℤ) ≤ locSub.bitLength * Q :=
                      Nat.mul_le_mul hloc_ge_idx (by omega)
                    rw [mul_comm locSub.bitLength Q] at h1
                    exact h1.trans (Nat.mul_le_mul_right _ hQM1)
                  have hM_bound : M_out ≤ F * Q * M_out := by
                    have h1 : 1 ≤ F * Q := Nat.mul_pos hF (by omega)
                    exact Nat.le_mul_of_pos_left M_out h1
                  have hlin_wh :
                      (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ)) +
                        (intBitLength (T_max : ℤ) + intBitLength (table : ℤ) +
                          intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ)) +
                        (RAMCellLoc.heap 11 (log.length : ℤ)).bitLength + intBitLength enc +
                        (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ) +
                          natBitLength 11 + intBitLength (log.length : ℤ) + intBitLength enc) +
                        (RAMCellLoc.heap 10 enc).bitLength +
                        1 + (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ) + 2 +
                          intBitLength (log.length : ℤ) + 2) +
                        (RAMCellLoc.heap 12 0).bitLength + intBitLength ((log.length : ℤ) + 1) ≤
                      20 * (F * Q * M_out) * locSub.bitLength := by
                    rw [hn12, hn11, hloc12_b]
                    have hidx_b : intBitLength idx ≤ outSub.bitCost := by
                      dsimp [locSub, RAMCellLoc.bitLength] at hmb; omega
                    have hsum :
                        (1 + 4 + 1 + intBitLength (log.length : ℤ)) +
                          (intBitLength (T_max : ℤ) + intBitLength (table : ℤ) +
                            intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ)) +
                          (RAMCellLoc.heap 11 (log.length : ℤ)).bitLength + intBitLength enc +
                          (1 + 4 + 1 + intBitLength (log.length : ℤ) +
                            4 + intBitLength (log.length : ℤ) + intBitLength enc) +
                          (RAMCellLoc.heap 10 enc).bitLength +
                          1 + (1 + 4 + 1 + intBitLength (log.length : ℤ) + 2 +
                            intBitLength (log.length : ℤ) + 2) +
                          5 + intBitLength ((log.length : ℤ) + 1) ≤
                        10 * M_out + 10 * Q := by
                      dsimp [M_out, L_enc] at henc_ib hloc10_b ⊢
                      have hn_u : natBitLength (outSub.unitCost + 2) ≤ outSub.unitCost + 3 :=
                        natBitLength_le (outSub.unitCost + 2)
                      omega
                    have h20 : 10 * M_out + 10 * Q ≤ 20 * (F * Q * M_out) := by omega
                    exact hsum.trans (h20.trans (Nat.le_mul_of_pos_right _ hloc1))
                  have hloc_wh :
                      intBitLength idx * intBitLength (T_max : ℤ) +
                        ((1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ)) +
                          (intBitLength (T_max : ℤ) + intBitLength (table : ℤ) +
                            intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ)) +
                          (RAMCellLoc.heap 11 (log.length : ℤ)).bitLength + intBitLength enc +
                          (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ) +
                            natBitLength 11 + intBitLength (log.length : ℤ) + intBitLength enc) +
                          (RAMCellLoc.heap 10 enc).bitLength +
                          1 + (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ) + 2 +
                            intBitLength (log.length : ℤ) + 2) +
                          (RAMCellLoc.heap 12 0).bitLength + intBitLength ((log.length : ℤ) + 1)) ≤
                      K_bit * locSub.bitLength := by
                    have h21 : 21 * ((F * Q * M_out) * locSub.bitLength) ≤
                        K_bit * locSub.bitLength := by
                      dsimp [K_bit]
                      rw [show 21 * ((F * Q * M_out) * locSub.bitLength) =
                            (21 * (F * Q * M_out)) * locSub.bitLength by ring,
                          show 256 * F * Q * M_out = 256 * (F * Q * M_out) by ring]
                      exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by norm_num))
                    rw [show 20 * (F * Q * M_out) * locSub.bitLength =
                        20 * ((F * Q * M_out) * locSub.bitLength) by ring] at hlin_wh
                    omega
                  refine ⟨wsE, logE, stE, htotal_runs,
                    hwfE, hpopE, hlogE, hlenE, hlogbE, hwsE, hbitsE,
                    cost_step_combine huE (cSim := stSim.unitCost)
                      (dSim := 2 + (u'₁ + 4) + 1 + 3 + u'₂ + 1 + 1 + 4 + 1)
                      (subC := stSub.unitCost) (dSub := u₁ + u₂ + 1)
                      (by omega) (by omega) (by exact hmu)
                      (by simp only [Nat.mul_add]; omega),
                    cost_step_combine hbE (cSim := stSim.bitCost)
                      (dSim := (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ)) +
                        (b'₁ + intBitLength (T_max : ℤ) + intBitLength idx * intBitLength (T_max : ℤ) +
                          intBitLength (table : ℤ) + intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ)) +
                        (RAMCellLoc.heap 11 (log.length : ℤ)).bitLength + intBitLength enc +
                        (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ) +
                          natBitLength 11 + intBitLength (log.length : ℤ) + intBitLength enc) +
                        b'₂ + (RAMCellLoc.heap 10 enc).bitLength + intBitLength val +
                        1 + (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ) + 2 +
                          intBitLength (log.length : ℤ) + 2) +
                        (RAMCellLoc.heap 12 0).bitLength + intBitLength ((log.length : ℤ) + 1))
                      (subC := stSub.bitCost)
                      (dSub := b₁ + b₂ + locSub.bitLength + intBitLength val)
                      (by omega) (by omega) (by dsimp [RAMCellLoc.bitLength] at hmb ⊢; exact hmb)
                      (by simp only [Nat.mul_add]; omega),
                    by
                      refine hpcE.trans ?_
                      simp only [max_le_iff]
                      exact ⟨⟨⟨⟨le_max_left _ _, le_trans (by omega) (le_max_right _ _)⟩,
                        le_trans (by omega) (le_max_right _ _)⟩,
                        le_trans (by omega) (le_max_right _ _)⟩, le_max_right _ _⟩,
                    by
                      refine hpbE.trans ?_
                      simp only [max_le_iff]
                      exact ⟨⟨⟨⟨le_max_left _ _, le_trans (by omega) (le_max_right _ _)⟩,
                        le_trans (by omega) (le_max_right _ _)⟩,
                        le_trans (by omega) (le_max_right _ _)⟩, le_max_right _ _⟩⟩

/-! ### 3. Base-local writes on `simMergeStore`, `enterAndRunSubStmt`, and `cleanupSubLogStmt` -/

theorem isSimBaseStore_write_local1 {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    (var : ℕ) (idx val : ℤ) :
    IsSimBaseStore (wsBase.write (.localFrame 1 var idx) val) := by
  refine ⟨wellFormedWS_write hbase.1 _ _, fun loc hloc => ?_⟩
  rcases Finset.mem_insert.mp hloc with rfl | hm
  · exact Or.inr ⟨var, idx, rfl⟩
  · exact hbase.2 loc hm

theorem isSimBaseStore_write_heap {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {t : ℕ} (ht : t < 8) (idx val : ℤ) :
    IsSimBaseStore (wsBase.write (.heap t idx) val) := by
  refine ⟨wellFormedWS_write hbase.1 _ _, fun loc hloc => ?_⟩
  rcases Finset.mem_insert.mp hloc with rfl | hm
  · exact Or.inl ⟨t, idx, ht, rfl⟩
  · exact hbase.2 loc hm

theorem isSimBaseStore_free {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    (loc : RAMCellLoc) :
    IsSimBaseStore (wsBase.free loc) :=
  ⟨wellFormedWS_free hbase.1 loc, fun l hl => hbase.2 l (Finset.mem_of_mem_erase hl)⟩

theorem simMergeStore_write_local1 (wsBase : WordStore) {T_max : ℕ} (hT : 1 ≤ T_max)
    (wsSub : WordStore) (log : List ℤ) (var : ℕ) (idx val : ℤ) :
    (simMergeStore wsBase T_max hT wsSub log).write (.localFrame 1 var idx) val =
      simMergeStore (wsBase.write (.localFrame 1 var idx) val) T_max hT wsSub log := by
  unfold WordStore.write simMergeStore
  congr 1
  · ext l
    simp only [Finset.mem_insert, Finset.mem_union]
    tauto
  · funext l
    by_cases hl : l = .localFrame 1 var idx
    · subst hl; simp [simMergeVals]
    · rw [Function.update_of_ne hl]
      cases l with
      | heap t_h i_h =>
          have hne_h : RAMCellLoc.heap t_h i_h ≠ .localFrame 1 var idx := by intro h; nomatch h
          dsimp [simMergeVals]
          by_cases ht8 : t_h < 8
          · rw [if_pos ht8, if_pos ht8, Function.update_of_ne hne_h]
          · rw [if_neg ht8, if_neg ht8]
      | localFrame d v i =>
          dsimp [simMergeVals]
          by_cases hd1 : d = 1
          · subst hd1
            simp [Function.update_of_ne hl]
          · rw [if_neg hd1, if_neg hd1]

def enterAndRunSubStmt (isDimD : Bool) (progSub : BitRAMStmt) : BitRAMStmt :=
  let T_max := maxTableStmtFull progSub
  .seq (.writeHeap 12 (.lit 0) (.lit 0))
       (.localScope (trStmt isDimD T_max progSub))

def cleanupSubLogStmt : BitRAMStmt :=
  .seq (.writeLocal 99 (.lit 0) (.lit 0))
  (.seq (.repeatN (.readHeap 12 (.lit 0))
    (.seq (.freeHeap 10 (.readHeap 11 (.readLocal 99 (.lit 0))))
    (.seq (.freeHeap 11 (.readLocal 99 (.lit 0)))
          (.writeLocal 99 (.lit 0) (.add (.readLocal 99 (.lit 0)) (.lit 1))))))
        (.freeHeap 12 (.lit 0)))

theorem exec_enterAndRunSubStmt {isDimD : Bool} {d dSub L_p : ℕ}
    {inpSim : BitRAMInput d} {inpSub : BitRAMInput dSub}
    {wsBase : WordStore} (progSub : BitRAMStmt)
    {outSub : BitRAMExecOutcome} {stSim : BitRAMExecState}
    (hstage : SimStageMatches isDimD d dSub L_p wsBase inpSub)
    (hws : stSim.words = wsBase)
    (hfd : stSim.frameDepth = 1)
    (hrunSub : runBitRAMWithBits progSub inpSub WordStore.empty [] = some outSub) :
    let T_max := maxTableStmtFull progSub
    let hT : 1 ≤ T_max := maxTableStmtFull_pos progSub
    let F := stmtFactor progSub
    let L_enc : ℕ := outSub.bitCost + 2 * natBitLength T_max + 6
    let K_bit : ℕ := 256 * F * (L_p + natBitLength T_max + 8) ^ 2 *
      (outSub.bitCost + outSub.unitCost + 16)
    ∃ (wsHeap : WordStore) (log : List ℤ) (stMid : BitRAMExecState),
      RunsTo inpSim [.stmt (enterAndRunSubStmt isDimD progSub)] stSim stMid ∧
      (wsHeap.cellCount ≤ outSub.words.cellCount ∧ wsHeap.bitSize ≤ outSub.words.bitSize) ∧
      WellFormedWS wsHeap ∧
      (∀ u ∈ wsHeap.live, ∃ t idx, u = .heap t idx ∧ t < T_max ∧
        (idx * (T_max : ℤ) + (t : ℤ)) ∈ log) ∧
      (∀ t idx, t < T_max →
        stMid.words.read (.heap 10 (idx * (T_max : ℤ) + (t : ℤ))) =
          outSub.words.read (.heap t idx)) ∧
      log.length ≤ outSub.unitCost ∧
      (∀ x ∈ log, intBitLength x ≤ L_enc) ∧
      stMid.words = simMergeStore wsBase T_max hT wsHeap log ∧
      stMid.frameDepth = 1 ∧
      stMid.remainingBits = stSim.remainingBits ∧
      stMid.unitCost ≤ stSim.unitCost + 64 * F * outSub.unitCost + 8 ∧
      stMid.bitCost ≤ stSim.bitCost + K_bit * outSub.bitCost + 32 ∧
      stMid.peakCellSpace ≤ max stSim.peakCellSpace
        (inpSim.inputCellSpace + wsBase.cellCount + outSub.peakCellSpace + outSub.unitCost + 3) ∧
      stMid.peakBitSpace ≤ max stSim.peakBitSpace
        (inpSim.inputBitSpace + wsBase.bitSize + (natBitLength T_max + 12) * outSub.peakBitSpace +
          (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12)) := by
  intro T_max hT F L_enc K_bit
  have hF : 1 ≤ F := stmtFactor_pos progSub
  obtain ⟨fuel, hfuel⟩ := (runBitRAMWithBits_eq_some_iff progSub inpSub WordStore.empty [] outSub).mp hrunSub
  have hemp_pop : WordStore.empty.popDepth 0 = WordStore.empty := by
    unfold WordStore.popDepth WordStore.empty
    congr 1; simp
  simp only [hemp_pop] at hfuel
  have hw0 := RunsTo.writeHeap inpSim 12 (.lit 0) (.lit 0) stSim
  dsimp only at hw0
  have he0 : evalIntExpr inpSim stSim.frameDepth stSim.words (.lit 0) = (0, 1, 1) := rfl
  rw [he0] at hw0
  dsimp only at hw0
  set st₀ : BitRAMExecState :=
    { stSim with
      words := stSim.words.write (.heap 12 0) 0
      unitCost := stSim.unitCost + 1 + 1 + 1
      bitCost := stSim.bitCost + 1 + 1 + (RAMCellLoc.heap 12 0).bitLength + intBitLength 0
      peakCellSpace := max stSim.peakCellSpace
        (inpSim.inputCellSpace + (stSim.words.write (.heap 12 0) 0).cellCount)
      peakBitSpace := max stSim.peakBitSpace
        (inpSim.inputBitSpace + (stSim.words.write (.heap 12 0) 0).bitSize) }
  set stIn : BitRAMExecState :=
    { st₀ with words := st₀.words.popDepth 1, frameDepth := 2 }
  have hwsIn : stIn.words = simMergeStore wsBase T_max hT WordStore.empty [] := by
    dsimp [stIn, st₀]
    rw [hws]
    exact simMergeStore_init hstage.1 hT
  have hok_init : StackOK F T_max [.stmt progSub] := ⟨le_rfl, le_rfl, trivial⟩
  have hlog_init : SubHeapLogged T_max WordStore.empty [] := by
    intro _ hm; simp [WordStore.empty] at hm
  obtain ⟨wsEnd, logEnd, stEnd, hruns, hwfEnd, hpopEnd, hlogEnd, hlenEnd, hlogbEnd,
    hwsEnd, hbitsEnd, huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
    simulate_trStack hstage hT hF fuel [.stmt progSub]
      { words := WordStore.empty
        frameDepth := 0
        remainingBits := []
        unitCost := 0
        bitCost := 0
        peakCellSpace := inpSub.inputCellSpace + WordStore.empty.cellCount
        peakBitSpace := inpSub.inputBitSpace + WordStore.empty.bitSize }
      stIn outSub []
      wellFormedWS_empty hok_init hlog_init (by simp) (by simp) rfl hwsIn rfl le_rfl le_rfl hfuel
  dsimp [trCont] at hruns
  have hfd0 : st₀.frameDepth = 1 := hfd
  have hscope : RunsTo inpSim [.stmt (.localScope (trStmt isDimD T_max progSub))] st₀
      { stEnd with words := stEnd.words.popDepth 1, frameDepth := 1 } := by
    have h1 := RunsTo.localScope (inp := inpSim) (body := trStmt isDimD T_max progSub) (st := st₀)
      (stBody := stEnd) (by simpa [stIn, hfd0] using hruns)
    simpa [hfd0] using h1
  set stMid : BitRAMExecState := { stEnd with words := stEnd.words.popDepth 1, frameDepth := 1 }
  have htot : RunsTo inpSim [.stmt (enterAndRunSubStmt isDimD progSub)] stSim stMid :=
    RunsTo.seq hw0 hscope
  let wsHeap := heapOnlyStore wsEnd
  have hwsMid : stMid.words = simMergeStore wsBase T_max hT wsHeap logEnd := by
    dsimp [stMid, wsHeap]
    rw [hwsEnd, simMergeStore_popDepth_one hstage.1 hT wsEnd logEnd]
  have hwfHeap : WellFormedWS wsHeap := wellFormedWS_heapOnlyStore hwfEnd
  have hheap_le : wsHeap.cellCount ≤ outSub.words.cellCount ∧ wsHeap.bitSize ≤ outSub.words.bitSize := by
    rw [hpopEnd]
    have hsub_h : wsHeap.live ⊆ (wsEnd.popDepth 0).live := by
      intro loc hloc
      cases loc with
      | localFrame _ _ _ => simp [wsHeap, heapOnlyStore] at hloc
      | heap t idx =>
          have hm : RAMCellLoc.heap t idx ∈ wsEnd.live := (Finset.mem_filter.mp hloc).1
          simp [WordStore.popDepth, RAMCellLoc.keepAtDepth, hm]
    refine ⟨Finset.card_le_card hsub_h, ?_⟩
    unfold WordStore.bitSize
    calc
      (∑ loc ∈ wsHeap.live, (loc.bitLength + intBitLength (wsHeap.vals loc)))
          = ∑ loc ∈ wsHeap.live, (loc.bitLength + intBitLength ((wsEnd.popDepth 0).vals loc)) := by
            refine Finset.sum_congr rfl fun loc hloc => ?_
            cases loc with
            | localFrame _ _ _ => simp [wsHeap, heapOnlyStore] at hloc
            | heap t idx => rfl
      _ ≤ ∑ loc ∈ (wsEnd.popDepth 0).live,
            (loc.bitLength + intBitLength ((wsEnd.popDepth 0).vals loc)) :=
            Finset.sum_le_sum_of_subset_of_nonneg hsub_h (fun _ _ _ => Nat.zero_le _)
  refine ⟨wsHeap, logEnd, stMid, htot, hheap_le, hwfHeap, ?_, ?_, hlenEnd, hlogbEnd,
    hwsMid, rfl, hbitsEnd, ?_, ?_, ?_, ?_⟩
  · intro u hu
    cases u with
    | localFrame _ _ _ => simp [wsHeap, heapOnlyStore] at hu
    | heap t idx =>
        have hu' : RAMCellLoc.heap t idx ∈ wsEnd.live := (Finset.mem_filter.mp hu).1
        obtain ⟨ht, hmem⟩ := hlogEnd (.heap t idx) hu' t idx rfl
        exact ⟨t, idx, rfl, ht, hmem⟩
  · intro t idx ht
    rw [hwsMid]
    have hsh : shiftSubLoc T_max (.heap t idx) = .heap 10 (idx * (T_max : ℤ) + (t : ℤ)) := by
      dsimp [shiftSubLoc]; rw [if_pos ht]
    rw [← hsh, simMergeStore_read_sub hstage.1 hT hwfHeap logEnd (.heap t idx)]
    dsimp [wsHeap]
    rw [heapOnlyStore_read_heap, ← hpopEnd]
  · dsimp [stMid, stIn, st₀] at huEnd ⊢
    omega
  · dsimp [stMid, stIn, st₀, K_bit] at hbEnd ⊢
    have hl12 : (RAMCellLoc.heap 12 0).bitLength = 5 := by decide
    have hi0 : intBitLength 0 = 1 := rfl
    rw [hl12, hi0] at hbEnd
    omega
  · dsimp [stMid, stIn, st₀] at hpcEnd ⊢
    have hc0 : (stSim.words.write (.heap 12 0) 0).cellCount ≤ wsBase.cellCount + 1 := by
      rw [hws]; exact wordStore_cellCount_write_le wsBase _ _
    refine hpcEnd.trans (max_le (max_le (le_max_left _ _) ?_) (le_max_right _ _))
    exact le_trans (by omega) (le_max_right _ _)
  · dsimp [stMid, stIn, st₀] at hpbEnd ⊢
    have hb0 : (stSim.words.write (.heap 12 0) 0).bitSize ≤ wsBase.bitSize + 6 := by
      rw [hws]
      have hw := wordStore_bitSize_write_le wsBase (.heap 12 0) 0
      have hl12 : (RAMCellLoc.heap 12 0).bitLength = 5 := by decide
      have hi0 : intBitLength 0 = 1 := rfl
      rw [hl12, hi0] at hw; omega
    have h36 : 36 ≤ (outSub.unitCost + 3) * (natBitLength (outSub.unitCost + 2) + L_enc + 12) :=
      Nat.mul_le_mul (by omega : 3 ≤ outSub.unitCost + 3)
        (by omega : 12 ≤ natBitLength (outSub.unitCost + 2) + L_enc + 12)
    refine hpbEnd.trans (max_le (max_le (le_max_left _ _) ?_) (le_max_right _ _))
    exact le_trans (by omega) (le_max_right _ _)

private def cleanStepFn (log : List ℤ) (k : ℕ) (ws : WordStore) : WordStore :=
  ((ws.free (.heap 10 (log.getD k 0))).free (.heap 11 (k : ℤ))).write
    (.localFrame 1 99 0) (((k + 1 : ℕ) : ℤ))

private def cleanWsAt (ws₀ : WordStore) (log : List ℤ) : ℕ → WordStore
  | 0 => ws₀.write (.localFrame 1 99 0) 0
  | k + 1 => cleanStepFn log k (cleanWsAt ws₀ log k)

private theorem cleanWsAt_inv {T_max : ℕ} {wsBase wsHeap : WordStore}
    (hbase : IsSimBaseStore wsBase) (hT : 1 ≤ T_max) (hwfHeap : WellFormedWS wsHeap)
    (log : List ℤ) :
    let ws₀ := simMergeStore wsBase T_max hT wsHeap log
    ∀ k : ℕ, k ≤ log.length →
      WellFormedWS (cleanWsAt ws₀ log k) ∧
      (cleanWsAt ws₀ log k).read (.localFrame 1 99 0) = (k : ℤ) ∧
      (cleanWsAt ws₀ log k).read (.heap 12 0) = (log.length : ℤ) ∧
      (∀ j : ℕ, k ≤ j → j < log.length → (cleanWsAt ws₀ log k).read (.heap 11 (j : ℤ)) = log.getD j 0) ∧
      (cleanWsAt ws₀ log k).live ⊆ insert (.localFrame 1 99 0) ws₀.live ∧
      ((cleanWsAt ws₀ log k).free (.localFrame 1 99 0)).bitSize ≤ ws₀.bitSize ∧
      (∀ j : ℕ, j < k →
        RAMCellLoc.heap 10 (log.getD j 0) ∉ (cleanWsAt ws₀ log k).live ∧
        RAMCellLoc.heap 11 (j : ℤ) ∉ (cleanWsAt ws₀ log k).live) ∧
      (∀ loc : RAMCellLoc,
        ((∃ t idx, t < 8 ∧ loc = .heap t idx) ∨
         (∃ var idx, (var ≠ 99 ∨ idx ≠ 0) ∧ loc = .localFrame 1 var idx)) →
        (loc ∈ (cleanWsAt ws₀ log k).live ↔ loc ∈ wsBase.live) ∧
        (cleanWsAt ws₀ log k).vals loc = wsBase.vals loc) := by
  intro ws₀ k
  have hwf0 : WellFormedWS ws₀ := wellFormedWS_simMergeStore hbase hT hwfHeap log
  induction k with
  | zero =>
      intro _
      dsimp [cleanWsAt]
      refine ⟨wellFormedWS_write hwf0 _ _, wordStore_read_write_self _ _ _, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · rw [wordStore_read_write_of_ne _ (by intro h; nomatch h)]
        exact simMergeStore_read_logLen hbase hT hwfHeap log
      · intro j _ hj
        rw [wordStore_read_write_of_ne _ (by intro h; nomatch h)]
        exact simMergeStore_read_logEntry hbase hT hwfHeap log hj
      · exact Finset.Subset.refl _
      · unfold WordStore.bitSize WordStore.free WordStore.write
        have hsub : (insert (RAMCellLoc.localFrame 1 99 0) ws₀.live).erase (.localFrame 1 99 0) ⊆ ws₀.live := by
          intro x hx
          rcases Finset.mem_erase.mp hx with ⟨hne, hm⟩
          rcases Finset.mem_insert.mp hm with rfl | h0
          · exact False.elim (hne rfl)
          · exact h0
        calc
          (∑ l ∈ (insert (RAMCellLoc.localFrame 1 99 0) ws₀.live).erase (.localFrame 1 99 0), _)
              = ∑ l ∈ (insert (RAMCellLoc.localFrame 1 99 0) ws₀.live).erase (.localFrame 1 99 0),
                  (l.bitLength + intBitLength (ws₀.vals l)) := by
                refine Finset.sum_congr rfl fun l hl => ?_
                have hne := Finset.ne_of_mem_erase hl
                simp [Function.update_of_ne hne]
          _ ≤ ∑ l ∈ ws₀.live, (l.bitLength + intBitLength (ws₀.vals l)) :=
                Finset.sum_le_sum_of_subset_of_nonneg hsub (fun _ _ _ => Nat.zero_le _)
      · intro _ hj; omega
      · intro loc hloc
        have hne99 : loc ≠ .localFrame 1 99 0 := by
          rcases hloc with ⟨_, _, _, rfl⟩ | ⟨v, i, hv, rfl⟩
          · intro h; nomatch h
          · intro h; injection h with _ hv' hi'; exact hv.elim (fun h1 => h1 hv') (fun h2 => h2 hi')
        have hnot_sub_log : loc ∉ wsHeap.live.map (shiftSubEmb T_max hT) ∪ logLiveFinset log := by
          intro hmem
          rcases Finset.mem_union.mp hmem with hsub | hlg
          · rcases Finset.mem_map.mp hsub with ⟨u, _, hc⟩
            rcases hloc with ⟨t, idx, ht8, rfl⟩ | ⟨v, i, _, rfl⟩
            · cases u with
              | localFrame _ _ _ => dsimp [shiftSubEmb, shiftSubLoc] at hc; nomatch hc
              | heap _ _ => dsimp [shiftSubEmb, shiftSubLoc] at hc; split_ifs at hc <;> (injection hc with ht _; omega)
            · cases u with
              | heap _ _ => dsimp [shiftSubEmb, shiftSubLoc] at hc; split_ifs at hc <;> nomatch hc
              | localFrame _ _ _ => dsimp [shiftSubEmb, shiftSubLoc] at hc; injection hc with hd _ _; omega
          · simp only [logLiveFinset, Finset.mem_insert, Finset.mem_map, heap11Emb,
              Function.Embedding.coeFn_mk, Finset.mem_range] at hlg
            rcases hloc with ⟨t, idx, ht8, rfl⟩ | ⟨v, i, _, rfl⟩
            · rcases hlg with hc | ⟨_, _, hc⟩ <;> (injection hc with ht _; omega)
            · rcases hlg with hc | ⟨_, _, hc⟩ <;> nomatch hc
        constructor
        · simp only [WordStore.write, Finset.mem_insert, hne99, false_or]
          dsimp [ws₀, simMergeStore]
          rw [Finset.union_assoc, Finset.mem_union]
          exact ⟨fun h => h.resolve_right hnot_sub_log, Or.inl⟩
        · simp only [WordStore.write, Function.update_of_ne hne99]
          rcases hloc with ⟨t, idx, ht8, rfl⟩ | ⟨v, i, _, rfl⟩
          · simp [ws₀, simMergeStore, simMergeVals, ht8]
          · simp [ws₀, simMergeStore, simMergeVals]
  | succ k ih =>
      intro hk1
      obtain ⟨hwf_k, hr99, hr12, hr11, hsub_k, hbit_k, hgone_k, hbase_k⟩ := ih (by omega)
      set wk := cleanWsAt ws₀ log k
      dsimp [cleanWsAt, cleanStepFn]
      set w1 := wk.free (.heap 10 (log.getD k 0))
      set w2 := w1.free (.heap 11 (k : ℤ))
      set w3 := w2.write (.localFrame 1 99 0) (((k + 1 : ℕ) : ℤ))
      refine ⟨wellFormedWS_write (wellFormedWS_free (wellFormedWS_free hwf_k _) _) _ _,
        wordStore_read_write_self _ _ _, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · rw [wordStore_read_write_of_ne _ (by intro h; nomatch h),
          wordStore_read_free_of_ne _ (by intro h; nomatch h),
          wordStore_read_free_of_ne _ (by intro h; nomatch h), hr12]
      · intro j hkj hj
        rw [wordStore_read_write_of_ne _ (by intro h; nomatch h),
          wordStore_read_free_of_ne _ (by intro h; injection h with _ h'; omega),
          wordStore_read_free_of_ne _ (by intro h; nomatch h)]
        exact hr11 j (by omega) hj
      · intro l hl
        rcases Finset.mem_insert.mp hl with rfl | hm2
        · exact Finset.mem_insert_self _ _
        · exact hsub_k (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hm2))
      · have heq_free : w3.free (.localFrame 1 99 0) =
            ((wk.free (.localFrame 1 99 0)).free (.heap 10 (log.getD k 0))).free (.heap 11 (k : ℤ)) := by
          dsimp only [w3, w2, w1]
          unfold WordStore.free WordStore.write
          dsimp only
          congr 1
          · ext x; simp only [Finset.mem_erase, Finset.mem_insert]; tauto
          · funext x
            simp only [Function.update_apply]
            split_ifs <;> simp_all
        change (w3.free (.localFrame 1 99 0)).bitSize ≤ ws₀.bitSize
        rw [heq_free]
        exact (bitSize_free_le _ _).trans ((bitSize_free_le _ _).trans hbit_k)
      · intro j hj
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hj) with hlt | rfl
        · obtain ⟨hg10, hg11⟩ := hgone_k j hlt
          refine ⟨?_, ?_⟩
          · intro hm
            rcases Finset.mem_insert.mp hm with hc | hm'
            · nomatch hc
            · exact hg10 (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hm'))
          · intro hm
            rcases Finset.mem_insert.mp hm with hc | hm'
            · nomatch hc
            · exact hg11 (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hm'))
        · refine ⟨?_, ?_⟩
          · intro hm
            rcases Finset.mem_insert.mp hm with hc | hm'
            · nomatch hc
            · exact (Finset.mem_erase.mp (Finset.mem_of_mem_erase hm')).1 rfl
          · intro hm
            rcases Finset.mem_insert.mp hm with hc | hm'
            · nomatch hc
            · exact (Finset.mem_erase.mp hm').1 rfl
      · intro loc hloc
        have hne99 : loc ≠ .localFrame 1 99 0 := by
          rcases hloc with ⟨_, _, _, rfl⟩ | ⟨v, i, hv, rfl⟩
          · intro h; nomatch h
          · intro h; injection h with _ hv' hi'; exact hv.elim (fun h1 => h1 hv') (fun h2 => h2 hi')
        have hne11 : loc ≠ .heap 11 (k : ℤ) := by
          rcases hloc with ⟨t, _, ht8, rfl⟩ | ⟨_, _, _, rfl⟩
          · intro h; injection h with ht _; omega
          · intro h; nomatch h
        have hne10 : loc ≠ .heap 10 (log.getD k 0) := by
          rcases hloc with ⟨t, _, ht8, rfl⟩ | ⟨_, _, _, rfl⟩
          · intro h; injection h with ht _; omega
          · intro h; nomatch h
        obtain ⟨hlive_k, hval_k⟩ := hbase_k loc hloc
        refine ⟨?_, ?_⟩
        · dsimp only [w3, w2, w1, WordStore.write, WordStore.free]
          simp only [Finset.mem_insert, Finset.mem_erase, ne_eq, hne99, hne11, hne10,
            not_false_eq_true, true_and, false_or]
          exact hlive_k
        · dsimp only [w3, w2, w1, WordStore.write, WordStore.free]
          rw [Function.update_of_ne hne99, Function.update_of_ne hne11, Function.update_of_ne hne10]
          exact hval_k

theorem exec_cleanupSubLogStmt {d T_max L_enc : ℕ} {inpSim : BitRAMInput d}
    {wsBase wsHeap : WordStore} {log : List ℤ} {st : BitRAMExecState}
    (hbase : IsSimBaseStore wsBase)
    (hT : 1 ≤ T_max)
    (hwfHeap : WellFormedWS wsHeap)
    (hHeapLog : ∀ u ∈ wsHeap.live, ∃ t idx, u = .heap t idx ∧ t < T_max ∧
      (idx * (T_max : ℤ) + (t : ℤ)) ∈ log)
    (hlogb : ∀ x ∈ log, intBitLength x ≤ L_enc)
    (hws : st.words = simMergeStore wsBase T_max hT wsHeap log)
    (hfd : st.frameDepth = 1) :
    let wsClean := wsBase.write (.localFrame 1 99 0) (log.length : ℤ)
    ∃ stClean : BitRAMExecState,
      RunsTo inpSim [.stmt cleanupSubLogStmt] st stClean ∧
      stClean.words = wsClean ∧
      IsSimBaseStore stClean.words ∧
      stClean.frameDepth = 1 ∧
      stClean.remainingBits = st.remainingBits ∧
      stClean.unitCost ≤ st.unitCost + 16 * log.length + 16 ∧
      stClean.bitCost ≤ st.bitCost + (log.length + 2) *
        (8 * natBitLength (log.length + 2) + 4 * L_enc + 80) ∧
      stClean.peakCellSpace ≤ max st.peakCellSpace
        (inpSim.inputCellSpace + st.words.cellCount + 1) ∧
      stClean.peakBitSpace ≤ max st.peakBitSpace
        (inpSim.inputBitSpace + st.words.bitSize + 2 * natBitLength (log.length + 2) + 24) := by
  intro wsClean
  set ws₀ := simMergeStore wsBase T_max hT wsHeap log
  have hi0 : intBitLength 0 = 1 := rfl
  have hi1 : intBitLength 1 = 2 := by decide
  let body : BitRAMStmt :=
    .seq (.freeHeap 10 (.readHeap 11 (.readLocal 99 (.lit 0))))
    (.seq (.freeHeap 11 (.readLocal 99 (.lit 0)))
          (.writeLocal 99 (.lit 0) (.add (.readLocal 99 (.lit 0)) (.lit 1))))
  have hbit_bound : ∀ k : ℕ, k ≤ log.length →
      (cleanWsAt ws₀ log k).cellCount ≤ ws₀.cellCount + 1 ∧
      (cleanWsAt ws₀ log k).bitSize ≤ ws₀.bitSize + 2 * natBitLength (log.length + 2) + 24 := by
    intro k hk
    obtain ⟨hwf_ck, hr99, _, _, hsub, hbfree, _, _⟩ := cleanWsAt_inv hbase hT hwfHeap log k hk
    change ((cleanWsAt ws₀ log k).free (.localFrame 1 99 0)).bitSize ≤ ws₀.bitSize at hbfree
    have hc : (cleanWsAt ws₀ log k).cellCount ≤ ws₀.cellCount + 1 :=
      (Finset.card_le_card hsub).trans (Finset.card_insert_le _ _)
    have hb : (cleanWsAt ws₀ log k).bitSize ≤
        ((cleanWsAt ws₀ log k).free (.localFrame 1 99 0)).bitSize +
          (RAMCellLoc.localFrame 1 99 0).bitLength + intBitLength (k : ℤ) := by
      have hw : ((cleanWsAt ws₀ log k).free (.localFrame 1 99 0)).write (.localFrame 1 99 0) (k : ℤ) =
          cleanWsAt ws₀ log k := by
        have hmem99 : RAMCellLoc.localFrame 1 99 0 ∈ (cleanWsAt ws₀ log k).live := by
          cases k <;> simp [cleanWsAt, cleanStepFn, WordStore.write]
        have hval99 : (cleanWsAt ws₀ log k).vals (.localFrame 1 99 0) = (k : ℤ) := by
          rw [← wordStore_read_eq_vals hwf_ck, hr99]
        unfold WordStore.write WordStore.free
        congr 1
        · exact Finset.insert_erase hmem99
        · funext x
          by_cases hx : x = .localFrame 1 99 0
          · subst hx; simp [hval99]
          · simp [Function.update_of_ne hx]
      have h1 := wordStore_bitSize_write_le
        ((cleanWsAt ws₀ log k).free (.localFrame 1 99 0)) (.localFrame 1 99 0) (k : ℤ)
      rwa [hw] at h1
    have hl99 : (RAMCellLoc.localFrame 1 99 0).bitLength = 9 := by decide
    have hik : intBitLength (k : ℤ) ≤ natBitLength (log.length + 2) + 1 := by
      have := natBitLength_mono (by omega : k ≤ log.length + 2)
      unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
    exact ⟨hc, by omega⟩
  let stepB : ℕ := 8 * natBitLength (log.length + 2) + 4 * L_enc + 80
  have hloop : ∀ (rem k : ℕ), rem + k = log.length →
      ∀ st_k : BitRAMExecState,
        st_k.words = cleanWsAt ws₀ log k →
        st_k.frameDepth = 1 →
        ∃ st_end : BitRAMExecState,
          RunsTo inpSim [.repeatLoop rem body] st_k st_end ∧
          st_end.words = cleanWsAt ws₀ log log.length ∧
          st_end.frameDepth = 1 ∧
          st_end.remainingBits = st_k.remainingBits ∧
          st_end.unitCost ≤ st_k.unitCost + 16 * rem ∧
          st_end.bitCost ≤ st_k.bitCost + rem * stepB ∧
          st_end.peakCellSpace ≤ max st_k.peakCellSpace
            (inpSim.inputCellSpace + ws₀.cellCount + 1) ∧
          st_end.peakBitSpace ≤ max st_k.peakBitSpace
            (inpSim.inputBitSpace + ws₀.bitSize + 2 * natBitLength (log.length + 2) + 24) := by
    intro rem
    induction rem with
    | zero =>
        intro k hk st_k hwk hfk
        have hk_eq : k = log.length := by omega
        subst hk_eq
        exact ⟨st_k, RunsTo.repeatLoop_zero body st_k, hwk, hfk, rfl,
          by omega, by omega, le_max_left _ _, le_max_left _ _⟩
    | succ rem ih =>
        intro k hk st_k hwk hfk
        have hk_lt : k < log.length := by omega
        obtain ⟨_, hr99, _, hr11, _, _, _, _⟩ := cleanWsAt_inv hbase hT hwfHeap log k (by omega)
        change (cleanWsAt ws₀ log k).read (.localFrame 1 99 0) = (k : ℤ) at hr99
        change ∀ j : ℕ, k ≤ j → j < log.length → (cleanWsAt ws₀ log k).read (.heap 11 (j : ℤ)) = log.getD j 0 at hr11
        have hs1 := RunsTo.freeHeap inpSim 10 (.readHeap 11 (.readLocal 99 (.lit 0))) st_k
        dsimp only at hs1
        have he1 : evalIntExpr inpSim st_k.frameDepth st_k.words
            (.readHeap 11 (.readLocal 99 (.lit 0))) =
            (log.getD k 0, 3,
             1 + natBitLength 99 + 1 + intBitLength (k : ℤ) +
               natBitLength 11 + intBitLength (k : ℤ) + intBitLength (log.getD k 0)) := by
          rw [hfk, hwk]
          simp only [evalIntExpr, hr99, hr11 k le_rfl hk_lt, hi0]
        rw [he1] at hs1
        dsimp only at hs1
        set st1 : BitRAMExecState :=
          { st_k with
            words := st_k.words.free (.heap 10 (log.getD k 0))
            unitCost := st_k.unitCost + 3 + 1
            bitCost := st_k.bitCost +
              (1 + natBitLength 99 + 1 + intBitLength (k : ℤ) +
                natBitLength 11 + intBitLength (k : ℤ) + intBitLength (log.getD k 0)) +
              (RAMCellLoc.heap 10 (log.getD k 0)).bitLength }
        have hr99_1 : st1.words.read (.localFrame 1 99 0) = (k : ℤ) := by
          dsimp [st1]
          rw [wordStore_read_free_of_ne _ (by intro h; nomatch h), hwk, hr99]
        have hs2 := RunsTo.freeHeap inpSim 11 (.readLocal 99 (.lit 0)) st1
        dsimp only at hs2
        have he2 : evalIntExpr inpSim st1.frameDepth st1.words (.readLocal 99 (.lit 0)) =
            ((k : ℤ), 2, 1 + natBitLength 99 + 1 + intBitLength (k : ℤ)) := by
          have hfk1 : st1.frameDepth = 1 := hfk
          rw [hfk1]
          simp only [evalIntExpr, hr99_1, hi0]
        rw [he2] at hs2
        dsimp only at hs2
        set st2 : BitRAMExecState :=
          { st1 with
            words := st1.words.free (.heap 11 (k : ℤ))
            unitCost := st1.unitCost + 2 + 1
            bitCost := st1.bitCost + (1 + natBitLength 99 + 1 + intBitLength (k : ℤ)) +
              (RAMCellLoc.heap 11 (k : ℤ)).bitLength }
        have hr99_2 : st2.words.read (.localFrame 1 99 0) = (k : ℤ) := by
          dsimp [st2]
          rw [wordStore_read_free_of_ne _ (by intro h; nomatch h), hr99_1]
        have hs3 := RunsTo.writeLocal inpSim 99 (.lit 0) (.add (.readLocal 99 (.lit 0)) (.lit 1)) st2
        dsimp only at hs3
        have he3a : evalIntExpr inpSim st2.frameDepth st2.words (.lit 0) = (0, 1, 1) := rfl
        have hk1_cast : (k : ℤ) + 1 = (((k + 1 : ℕ) : ℤ)) := by push_cast; ring
        have he3b : evalIntExpr inpSim st2.frameDepth st2.words
            (.add (.readLocal 99 (.lit 0)) (.lit 1)) =
            ((((k + 1 : ℕ) : ℤ)), 4,
             1 + natBitLength 99 + 1 + intBitLength (k : ℤ) + 2 + intBitLength (k : ℤ) + 2) := by
          have hfk2 : st2.frameDepth = 1 := hfk
          rw [hfk2]
          simp only [evalIntExpr, hr99_2, hi0, hi1, hk1_cast]
        have hfk2 : st2.frameDepth = 1 := hfk
        rw [he3a, he3b, hfk2] at hs3
        dsimp only at hs3
        set st3 : BitRAMExecState :=
          { st2 with
            words := st2.words.write (.localFrame 1 99 0) (((k + 1 : ℕ) : ℤ))
            frameDepth := 1
            unitCost := st2.unitCost + 1 + 4 + 1
            bitCost := st2.bitCost + 1 +
              (1 + natBitLength 99 + 1 + intBitLength (k : ℤ) + 2 + intBitLength (k : ℤ) + 2) +
              (RAMCellLoc.localFrame 1 99 0).bitLength + intBitLength (((k + 1 : ℕ) : ℤ))
            peakCellSpace := max st2.peakCellSpace
              (inpSim.inputCellSpace + (st2.words.write (.localFrame 1 99 0) (((k + 1 : ℕ) : ℤ))).cellCount)
            peakBitSpace := max st2.peakBitSpace
              (inpSim.inputBitSpace + (st2.words.write (.localFrame 1 99 0) (((k + 1 : ℕ) : ℤ))).bitSize) }
        have hbody : RunsTo inpSim [.stmt body] st_k st3 :=
          RunsTo.seq hs1 (RunsTo.seq hs2 hs3)
        have hw3 : st3.words = cleanWsAt ws₀ log (k + 1) := by
          dsimp [st3, st2, st1, cleanWsAt, cleanStepFn]; rw [hwk]
        obtain ⟨st_end, hrem_runs, hwe, hfe, hbe, hue, hbite, hpce, hpbe⟩ :=
          ih (k + 1) (by omega) st3 hw3 rfl
        obtain ⟨hc_k1, hb_k1⟩ := hbit_bound (k + 1) (by omega)
        rw [← hw3] at hc_k1 hb_k1
        have hik : intBitLength (k : ℤ) ≤ natBitLength (log.length + 2) + 1 := by
          have := natBitLength_mono (by omega : k ≤ log.length + 2)
          unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
        have hik1 : intBitLength ((k : ℤ) + 1) ≤ natBitLength (log.length + 2) + 1 := by
          have hcast : (k : ℤ) + 1 = (((k + 1 : ℕ) : ℤ)) := (Nat.cast_add_one k).symm
          rw [hcast]
          have := natBitLength_mono (by omega : k + 1 ≤ log.length + 2)
          unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
        have hmem_k : log.getD k 0 ∈ log := by
          rw [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem hk_lt]
          exact List.getElem_mem hk_lt
        have hlk_ib : intBitLength (log.getD k 0) ≤ L_enc := hlogb _ hmem_k
        have hn99 : natBitLength 99 = 7 := by decide
        have hn10 : natBitLength 10 = 4 := by decide
        have hn11 : natBitLength 11 = 4 := by decide
        have hl99 : (RAMCellLoc.localFrame 1 99 0).bitLength = 9 := by decide
        have hl10 : (RAMCellLoc.heap 10 (log.getD k 0)).bitLength ≤ L_enc + 4 := by
          dsimp [RAMCellLoc.bitLength]; rw [hn10]; omega
        have hl11 : (RAMCellLoc.heap 11 (k : ℤ)).bitLength ≤ natBitLength (log.length + 2) + 5 := by
          dsimp [RAMCellLoc.bitLength]; rw [hn11]; omega
        dsimp [st3, st2, st1] at hue hbite hpce hpbe hc_k1 hb_k1
        refine ⟨st_end, RunsTo.repeatLoop_succ hbody hrem_runs, hwe, hfe, hbe,
          by omega, by
            rw [Nat.succ_mul]
            rw [hn99, hn11, hl99] at hbite
            have hstep_le : st_k.bitCost +
                (1 + 7 + 1 + intBitLength (k : ℤ) + 4 + intBitLength (k : ℤ) + intBitLength (log.getD k 0)) +
                (RAMCellLoc.heap 10 (log.getD k 0)).bitLength +
                (1 + 7 + 1 + intBitLength (k : ℤ)) + (RAMCellLoc.heap 11 (k : ℤ)).bitLength +
                1 + (1 + 7 + 1 + intBitLength (k : ℤ) + 2 + intBitLength (k : ℤ) + 2) +
                9 + intBitLength ((k : ℤ) + 1) ≤ st_k.bitCost + stepB := by
              dsimp [stepB]; omega
            omega,
          hpce.trans (max_le (max_le (le_max_left _ _) (le_trans (by omega) (le_max_right _ _))) (le_max_right _ _)),
          hpbe.trans (max_le (max_le (le_max_left _ _) (le_trans (by omega) (le_max_right _ _))) (le_max_right _ _))⟩
  have hw99 := RunsTo.writeLocal inpSim 99 (.lit 0) (.lit 0) st
  dsimp only at hw99
  have he0 : evalIntExpr inpSim st.frameDepth st.words (.lit 0) = (0, 1, 1) := rfl
  rw [he0, hfd] at hw99
  dsimp only at hw99
  set st_init : BitRAMExecState :=
    { st with
      words := st.words.write (.localFrame 1 99 0) 0
      frameDepth := 1
      unitCost := st.unitCost + 1 + 1 + 1
      bitCost := st.bitCost + 1 + 1 + (RAMCellLoc.localFrame 1 99 0).bitLength + 1
      peakCellSpace := max st.peakCellSpace
        (inpSim.inputCellSpace + (st.words.write (.localFrame 1 99 0) 0).cellCount)
      peakBitSpace := max st.peakBitSpace
        (inpSim.inputBitSpace + (st.words.write (.localFrame 1 99 0) 0).bitSize) }
  have hw_init : st_init.words = cleanWsAt ws₀ log 0 := by
    dsimp [st_init, cleanWsAt, ws₀]; rw [hws]
  obtain ⟨_, _, hr12_0, _, _, _, _, _⟩ := cleanWsAt_inv hbase hT hwfHeap log 0 (Nat.zero_le _)
  change (cleanWsAt ws₀ log 0).read (.heap 12 0) = (log.length : ℤ) at hr12_0
  obtain ⟨st_loop, hruns_loop, hw_loop, hf_loop, hb_loop, hu_loop, hbit_loop, hpc_loop, hpb_loop⟩ :=
    hloop log.length 0 (by omega)
      { st_init with
        unitCost := st_init.unitCost + 2
        bitCost := st_init.bitCost + (1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ)) }
      hw_init rfl
  have hrep : RunsTo inpSim [.stmt (.repeatN (.readHeap 12 (.lit 0)) body)] st_init st_loop := by
    refine RunsTo.repeatN (.readHeap 12 (.lit 0)) body ?_
    dsimp only
    have he12 : evalIntExpr inpSim st_init.frameDepth st_init.words (.readHeap 12 (.lit 0)) =
        ((log.length : ℤ), 2, 1 + natBitLength 12 + 1 + intBitLength (log.length : ℤ)) := by
      rw [hw_init]; simp only [evalIntExpr, hr12_0, hi0]
    rw [he12]
    simpa using hruns_loop
  have hfree12 := RunsTo.freeHeap inpSim 12 (.lit 0) st_loop
  dsimp only at hfree12
  have he0_l : evalIntExpr inpSim st_loop.frameDepth st_loop.words (.lit 0) = (0, 1, 1) := rfl
  rw [he0_l] at hfree12
  dsimp only at hfree12
  set stClean : BitRAMExecState :=
    { st_loop with
      words := st_loop.words.free (.heap 12 0)
      unitCost := st_loop.unitCost + 1 + 1
      bitCost := st_loop.bitCost + 1 + (RAMCellLoc.heap 12 0).bitLength }
  have hws_clean_eq : stClean.words = wsClean := by
    dsimp [stClean, wsClean]
    rw [hw_loop]
    obtain ⟨hwf_f, hr99_f, _, _, hsub_f, _, hgone_f, hbase_f⟩ :=
      cleanWsAt_inv hbase hT hwfHeap log log.length le_rfl
    have hwf_lhs : WellFormedWS ((cleanWsAt ws₀ log log.length).free (.heap 12 0)) :=
      wellFormedWS_free hwf_f _
    have hwf_rhs : WellFormedWS (wsBase.write (.localFrame 1 99 0) (log.length : ℤ)) :=
      wellFormedWS_write hbase.1 _ _
    have hlive_eq :
        ((cleanWsAt ws₀ log log.length).free (.heap 12 0)).live =
          (wsBase.write (.localFrame 1 99 0) (log.length : ℤ)).live := by
      ext l
      simp only [WordStore.free, WordStore.write, Finset.mem_erase, Finset.mem_insert]
      constructor
      · rintro ⟨hne12, hml⟩
        by_cases hl99 : l = .localFrame 1 99 0
        · exact Or.inl hl99
        · right
          have hm0 : l ∈ ws₀.live := by
            rcases Finset.mem_insert.mp (hsub_f hml) with hc | h0
            · exact False.elim (hl99 hc)
            · exact h0
          dsimp [ws₀, simMergeStore] at hm0
          rcases Finset.mem_union.mp hm0 with hm01 | hlg
          · rcases Finset.mem_union.mp hm01 with hb | hs
            · exact hb
            · exfalso
              rcases Finset.mem_map.mp hs with ⟨u, hu, rfl⟩
              obtain ⟨t, idx, rfl, ht, hmem_log⟩ := hHeapLog u hu
              obtain ⟨j, hj_lt, hj_eq⟩ := List.mem_iff_getElem.mp hmem_log
              have hgetD : log.getD j 0 = idx * (T_max : ℤ) + (t : ℤ) := by
                rw [List.getD_eq_getElem?_getD, List.getElem?_eq_getElem hj_lt, Option.getD_some, hj_eq]
              have hsh : shiftSubEmb T_max hT (.heap t idx) = .heap 10 (log.getD j 0) := by
                dsimp [shiftSubEmb, shiftSubLoc]
                rw [if_pos ht, hgetD]
              rw [hsh] at hml
              exact (hgone_f j hj_lt).1 hml
          · exfalso
            simp only [logLiveFinset, Finset.mem_insert, Finset.mem_map, heap11Emb,
              Function.Embedding.coeFn_mk, Finset.mem_range] at hlg
            rcases hlg with h12 | ⟨j, hj_lt, rfl⟩
            · exact hne12 h12
            · exact (hgone_f j hj_lt).2 hml
      · rintro (rfl | hb)
        · refine ⟨(by intro h; nomatch h), ?_⟩
          cases hlen0 : log.length with
          | zero => simp [cleanWsAt, hlen0, WordStore.write]
          | succ m => simp [cleanWsAt, hlen0, cleanStepFn, WordStore.write]
        · rcases hbase.2 l hb with ⟨t, idx, ht8, rfl⟩ | ⟨v, i, rfl⟩
          · refine ⟨(by intro h; injection h with ht _; omega), ?_⟩
            exact ((hbase_f _ (Or.inl ⟨t, idx, ht8, rfl⟩)).1).mpr hb
          · by_cases hv99 : v = 99 ∧ i = 0
            · rcases hv99 with ⟨rfl, rfl⟩
              refine ⟨(by intro h; nomatch h), ?_⟩
              cases hlen0 : log.length with
              | zero => simp [cleanWsAt, hlen0, WordStore.write]
              | succ m => simp [cleanWsAt, hlen0, cleanStepFn, WordStore.write]
            · have hv_or : v ≠ 99 ∨ i ≠ 0 := by tauto
              refine ⟨(by intro h; nomatch h), ?_⟩
              exact ((hbase_f _ (Or.inr ⟨v, i, hv_or, rfl⟩)).1).mpr hb
    cases h_lhs : (cleanWsAt ws₀ log log.length).free (.heap 12 0) with
    | mk liveL valsL =>
      cases h_rhs : wsBase.write (.localFrame 1 99 0) (log.length : ℤ) with
      | mk liveR valsR =>
        rw [h_lhs] at hlive_eq hwf_lhs
        rw [h_rhs] at hlive_eq hwf_rhs
        dsimp at hlive_eq
        subst hlive_eq
        congr 1
        funext l
        by_cases hmem : l ∈ liveL
        · have h_in_rhs : l ∈ (wsBase.write (.localFrame 1 99 0) (log.length : ℤ)).live := by
            rwa [h_rhs]
          by_cases hl99 : l = .localFrame 1 99 0
          · subst hl99
            have h1 : ((cleanWsAt ws₀ log log.length).free (.heap 12 0)).read (.localFrame 1 99 0) =
                (log.length : ℤ) := by
              rw [wordStore_read_free_of_ne _ (by intro h; nomatch h), hr99_f]
            have h2 : (wsBase.write (.localFrame 1 99 0) (log.length : ℤ)).read (.localFrame 1 99 0) =
                (log.length : ℤ) := wordStore_read_write_self _ _ _
            rw [wordStore_read_eq_vals (h_lhs ▸ hwf_lhs), h_lhs] at h1
            rw [wordStore_read_eq_vals (h_rhs ▸ hwf_rhs), h_rhs] at h2
            exact h1.trans h2.symm
          · have hb_mem : l ∈ wsBase.live := by
              rcases Finset.mem_insert.mp h_in_rhs with hc | hb
              · exact False.elim (hl99 hc)
              · exact hb
            have hloc_case :
                (∃ t idx, t < 8 ∧ l = .heap t idx) ∨
                (∃ var idx, (var ≠ 99 ∨ idx ≠ 0) ∧ l = .localFrame 1 var idx) := by
              rcases hbase.2 l hb_mem with ⟨t, idx, ht8, rfl⟩ | ⟨v, i, rfl⟩
              · exact Or.inl ⟨t, idx, ht8, rfl⟩
              · refine Or.inr ⟨v, i, ?_, rfl⟩
                by_contra hnot; push_neg at hnot; exact hl99 (by rw [hnot.1, hnot.2])
            have hne12 : l ≠ .heap 12 0 := by
              rcases hloc_case with ⟨t, _, ht8, rfl⟩ | ⟨_, _, _, rfl⟩
              · intro h; injection h with ht _; omega
              · intro h; nomatch h
            have h1 : ((cleanWsAt ws₀ log log.length).free (.heap 12 0)).vals l = wsBase.vals l := by
              simp only [WordStore.free, Function.update_of_ne hne12]
              exact (hbase_f l hloc_case).2
            have h2 : (wsBase.write (.localFrame 1 99 0) (log.length : ℤ)).vals l = wsBase.vals l := by
              simp [WordStore.write, Function.update_of_ne hl99]
            rw [h_lhs] at h1; rw [h_rhs] at h2
            exact h1.trans h2.symm
        · exact (hwf_lhs l hmem).trans (hwf_rhs l hmem).symm
  have htot : RunsTo inpSim [.stmt cleanupSubLogStmt] st stClean :=
    RunsTo.seq hw99 (RunsTo.seq hrep hfree12)
  obtain ⟨hc0, hb0⟩ := hbit_bound 0 (Nat.zero_le _)
  rw [← hw_init] at hc0 hb0
  dsimp only [st_init] at hc0 hb0
  have hws0_eq : st.words = ws₀ := hws
  have hn12 : natBitLength 12 = 4 := by decide
  have hl99 : (RAMCellLoc.localFrame 1 99 0).bitLength = 9 := by decide
  have hl12 : (RAMCellLoc.heap 12 0).bitLength = 5 := by decide
  have hill : intBitLength (log.length : ℤ) ≤ natBitLength (log.length + 2) + 1 := by
    have := natBitLength_mono (by omega : log.length ≤ log.length + 2)
    unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
  dsimp [stClean, st_init] at hu_loop hbit_loop hpc_loop hpb_loop ⊢
  refine ⟨stClean, htot, hws_clean_eq,
    hws_clean_eq ▸ isSimBaseStore_write_local1 hbase 99 0 (log.length : ℤ),
    hf_loop, hb_loop,
    by dsimp [stClean]; omega,
    by
      dsimp [stClean]
      change st_loop.bitCost + 1 + (RAMCellLoc.heap 12 0).bitLength ≤ st.bitCost + (log.length + 2) * stepB
      rw [show (log.length + 2) * stepB = log.length * stepB + stepB + stepB by ring]
      rw [hl99, hn12] at hbit_loop
      rw [hl12]
      have htwo : 1 + 1 + 9 + 1 + (1 + 4 + 1 + intBitLength (log.length : ℤ)) + 1 + 5 ≤ stepB + stepB := by
        dsimp [stepB]; omega
      omega,
    by
      dsimp [stClean]
      rw [← hws0_eq] at hpc_loop hc0
      refine hpc_loop.trans (max_le (max_le (le_max_left _ _) (le_trans (by omega) (le_max_right _ _))) (le_max_right _ _)),
    by
      dsimp [stClean]
      rw [← hws0_eq] at hpb_loop hb0
      refine hpb_loop.trans (max_le (max_le (le_max_left _ _) (le_trans (by omega) (le_max_right _ _))) (le_max_right _ _))⟩

end UL.Proof_lem_A_2
