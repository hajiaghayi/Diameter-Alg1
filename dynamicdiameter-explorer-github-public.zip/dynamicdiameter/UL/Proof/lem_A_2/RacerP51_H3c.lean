import Mathlib
import UL.Proof.lem_A_2.RacerP42_H3b
set_option autoImplicit false
set_option maxHeartbeats 1000000

namespace UL.Proof_lem_A_2

/-! ### 1. Pure value evaluators and arena cost caps -/

def arenaCellCap {d : ℕ} (inp : BitRAMInput d) (A : ℕ) : ℕ :=
  inp.inputCellSpace + 108 * A

def arenaBitCap {d : ℕ} (inp : BitRAMInput d) (A V : ℕ) : ℕ :=
  inp.inputBitSpace + 108 * A * (natBitLength A + V + 16)

def evalVal {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e : IntExpr) : ℤ :=
  (evalIntExpr inp 1 ws e).1

@[simp] theorem evalVal_lit {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (c : ℤ) :
    evalVal inp ws (.lit c) = c := rfl

@[simp] theorem evalVal_dim {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) :
    evalVal inp ws .dim = (d : ℤ) := rfl

@[simp] theorem evalVal_intParam {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e : IntExpr) :
    evalVal inp ws (.intParam e) = listGetIntD inp.intParams (evalVal inp ws e) 0 := rfl

@[simp] theorem evalVal_readHeap {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (t : ℕ) (e : IntExpr) :
    evalVal inp ws (.readHeap t e) = ws.read (.heap t (evalVal inp ws e)) := rfl

@[simp] theorem evalVal_readLocal {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (v : ℕ) (e : IntExpr) :
    evalVal inp ws (.readLocal v e) = ws.read (.localFrame 1 v (evalVal inp ws e)) := rfl

@[simp] theorem evalVal_activeRatNum {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (hE cE : IntExpr) :
    evalVal inp ws (.activeRatNum hE cE) =
      let h := evalVal inp ws hE
      let c := evalVal inp ws cE
      if _ : 0 ≤ h ∧ h.toNat ∈ inp.activeHandles then
        if hc : 0 ≤ c ∧ c.toNat < d then
          (inp.activeRatCoords h.toNat ⟨c.toNat, hc.2⟩).num
        else 0
      else 0 := rfl

@[simp] theorem evalVal_activeRatDen {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (hE cE : IntExpr) :
    evalVal inp ws (.activeRatDen hE cE) =
      let h := evalVal inp ws hE
      let c := evalVal inp ws cE
      if _ : 0 ≤ h ∧ h.toNat ∈ inp.activeHandles then
        if hc : 0 ≤ c ∧ c.toNat < d then
          ((inp.activeRatCoords h.toNat ⟨c.toNat, hc.2⟩).den : ℤ)
        else 1
      else 1 := rfl

@[simp] theorem evalVal_neg {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e : IntExpr) :
    evalVal inp ws (.neg e) = -(evalVal inp ws e) := rfl

@[simp] theorem evalVal_add {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e₁ e₂ : IntExpr) :
    evalVal inp ws (.add e₁ e₂) = evalVal inp ws e₁ + evalVal inp ws e₂ := rfl

@[simp] theorem evalVal_sub {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e₁ e₂ : IntExpr) :
    evalVal inp ws (.sub e₁ e₂) = evalVal inp ws e₁ - evalVal inp ws e₂ := rfl

@[simp] theorem evalVal_mul {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e₁ e₂ : IntExpr) :
    evalVal inp ws (.mul e₁ e₂) = evalVal inp ws e₁ * evalVal inp ws e₂ := rfl

@[simp] theorem evalVal_div {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e₁ e₂ : IntExpr) :
    evalVal inp ws (.div e₁ e₂) = evalVal inp ws e₁ / evalVal inp ws e₂ := rfl

@[simp] theorem evalVal_mod {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e₁ e₂ : IntExpr) :
    evalVal inp ws (.mod e₁ e₂) = evalVal inp ws e₁ % evalVal inp ws e₂ := rfl

def evalCondVal {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (c : BitCondExpr) : Bool :=
  (evalBitCond inp 1 ws c).1

@[simp] theorem evalCondVal_intEq {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e₁ e₂ : IntExpr) :
    evalCondVal inp ws (.intEq e₁ e₂) = decide (evalVal inp ws e₁ = evalVal inp ws e₂) := rfl

@[simp] theorem evalCondVal_intLt {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e₁ e₂ : IntExpr) :
    evalCondVal inp ws (.intLt e₁ e₂) = decide (evalVal inp ws e₁ < evalVal inp ws e₂) := rfl

@[simp] theorem evalCondVal_intLe {d : ℕ} (inp : BitRAMInput d) (ws : WordStore) (e₁ e₂ : IntExpr) :
    evalCondVal inp ws (.intLe e₁ e₂) = decide (evalVal inp ws e₁ ≤ evalVal inp ws e₂) := rfl

/-! ### 2. Universal arena expression & condition cost bounds -/

def ArenaInputOK {d : ℕ} (A V : ℕ) (inp : BitRAMInput d) : Prop :=
  16 ≤ A ∧
  natBitLength A + 16 ≤ V ∧
  intBitLength (d : ℤ) ≤ V ∧
  (∀ idx : ℤ, intBitLength (listGetIntD inp.intParams idx 0) ≤ V) ∧
  (∀ idx : ℤ, intBitLength (listGetIntD inp.extraRats idx 0).num ≤ V ∧
    intBitLength ((listGetIntD inp.extraRats idx 0).den : ℤ) ≤ V) ∧
  (∀ h ∈ inp.activeHandles, ∀ c : Fin d,
    intBitLength (inp.activeRatCoords h c).num ≤ V ∧
    intBitLength ((inp.activeRatCoords h c).den : ℤ) ≤ V)

def ExprInArena (V : ℕ) : IntExpr → Prop
  | .lit c => intBitLength c ≤ V
  | .dim => True
  | .intParam e | .extraRatNum e | .extraRatDen e | .neg e => ExprInArena V e
  | .readHeap t e => t < 8 ∧ ExprInArena V e
  | .readLocal var e => var < 100 ∧ ExprInArena V e
  | .add e₁ e₂ | .sub e₁ e₂ | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ =>
      ExprInArena V e₁ ∧ ExprInArena V e₂

def CondInArena (V : ℕ) : BitCondExpr → Prop
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => ExprInArena V e₁ ∧ ExprInArena V e₂
  | .not c => CondInArena V c
  | .and c₁ c₂ | .or c₁ c₂ => CondInArena V c₁ ∧ CondInArena V c₂

def exprNodes : IntExpr → ℕ
  | .lit _ | .dim => 1
  | .intParam e | .readHeap _ e | .readLocal _ e | .extraRatNum e | .extraRatDen e | .neg e =>
      exprNodes e + 1
  | .add e₁ e₂ | .sub e₁ e₂ | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ =>
      exprNodes e₁ + exprNodes e₂ + 1

def condNodes : BitCondExpr → ℕ
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1
  | .not c => condNodes c + 1
  | .and c₁ c₂ | .or c₁ c₂ => condNodes c₁ + condNodes c₂ + 1

theorem exprNodes_pos (e : IntExpr) : 1 ≤ exprNodes e := by
  cases e <;> simp [exprNodes]

theorem condNodes_pos (c : BitCondExpr) : 1 ≤ condNodes c := by
  cases c <;> simp [condNodes]

theorem inAttemptArena_read_bitLen_le {A V : ℕ} {ws : WordStore}
    (h : InAttemptArena A V ws) (hV1 : 1 ≤ V) (loc : RAMCellLoc) :
    intBitLength (ws.read loc) ≤ V := by
  unfold WordStore.read
  split_ifs with hmem
  · exact h.2.2 loc hmem
  · change 1 ≤ V; exact hV1

theorem intBitLength_ediv_le (a b : ℤ) :
    intBitLength (a / b) ≤ intBitLength a + 2 := by
  have hdiv_abs : (a / b).natAbs ≤ a.natAbs + 1 := by
    rw [Int.natAbs_ediv]
    have := Nat.div_le_self a.natAbs b.natAbs
    split_ifs <;> omega
  set S : ℕ := a.natAbs + 1
  have hdiv : intBitLength (a / b) ≤ intBitLength (S : ℤ) + 1 :=
    intBitLength_mono_natAbs (by rw [Int.natAbs_natCast]; exact hdiv_abs)
  have hn_add := natBitLength_add_le a.natAbs 1
  have hn1 : natBitLength 1 = 1 := rfl
  have hS_ne : (S : ℤ) ≠ 0 := by exact_mod_cast (show S ≠ 0 by dsimp [S]; omega)
  have hS_ib : intBitLength (S : ℤ) = 1 + natBitLength (a.natAbs + 1) := by
    unfold intBitLength; rw [if_neg hS_ne, Int.natAbs_natCast]
  by_cases ha0 : a = 0
  · subst ha0
    have : (0 : ℤ) / b = 0 := Int.zero_ediv b
    rw [this]
    have : intBitLength 0 = 1 := rfl
    omega
  · have ha_ib : intBitLength a = 1 + natBitLength a.natAbs := by simp [intBitLength, ha0]
    have := natBitLength_pos a.natAbs
    omega

theorem intBitLength_emod_le (a b : ℤ) :
    intBitLength (a % b) ≤ intBitLength a + intBitLength b := by
  by_cases hb : b = 0
  · subst hb; simp only [Int.emod_zero]; have := intBitLength_pos 0; omega
  · have hm0 : 0 ≤ a % b := Int.emod_nonneg a hb
    have hm1 : a % b < |b| := Int.emod_lt_abs a hb
    have habs : (a % b).natAbs ≤ b.natAbs := by
      have hcast : ((a % b).natAbs : ℤ) < (b.natAbs : ℤ) := by
        rw [Int.natAbs_of_nonneg hm0, Int.natCast_natAbs]
        exact hm1
      omega
    have hmod := intBitLength_mono_natAbs habs
    have := intBitLength_pos a
    omega

private theorem unary_cube_step {n X : ℕ} (hn : 1 ≤ n) (hX : 8 ≤ X)
    {b₁ extra : ℕ} (hb₁ : b₁ ≤ 8 * n ^ 3 * X ^ 2)
    (hextra : extra ≤ (n + 2) * X) :
    b₁ + extra ≤ 8 * (n + 1) ^ 3 * X ^ 2 := by
  have hXX : (n + 2) * X ≤ 3 * n * (X ^ 2) := by nlinarith
  have hcube : 8 * n ^ 3 + 3 * n ≤ 8 * (n + 1) ^ 3 := by nlinarith
  have hmul := Nat.mul_le_mul_right (X ^ 2) hcube
  rw [Nat.add_mul] at hmul
  linarith

private theorem binary_cube_step {n₁ n₂ X : ℕ} (hn₁ : 1 ≤ n₁) (hn₂ : 1 ≤ n₂) (_hX : 8 ≤ X)
    {b₁ b₂ extra : ℕ}
    (hb₁ : b₁ ≤ 8 * n₁ ^ 3 * X ^ 2)
    (hb₂ : b₂ ≤ 8 * n₂ ^ 3 * X ^ 2)
    (hextra : extra ≤ (n₁ * n₂ + n₁ + n₂ + 1) * X ^ 2) :
    b₁ + b₂ + extra ≤ 8 * (n₁ + n₂ + 1) ^ 3 * X ^ 2 := by
  have hcube : 8 * n₁ ^ 3 + 8 * n₂ ^ 3 + (n₁ * n₂ + n₁ + n₂ + 1) ≤ 8 * (n₁ + n₂ + 1) ^ 3 := by
    have : 0 ≤ n₁ * n₂ := Nat.zero_le _
    nlinarith
  have hmul := Nat.mul_le_mul_right (X ^ 2) hcube
  simp only [Nat.add_mul] at hmul
  linarith

theorem evalIntExpr_arena_bound {d A V : ℕ} {inp : BitRAMInput d} {ws : WordStore}
    (harena : InAttemptArena A V ws) (hinp : ArenaInputOK A V inp) :
    ∀ e : IntExpr,
      ExprInArena V e →
      intBitLength (evalVal inp ws e) ≤ exprNodes e * (V + 4) ∧
      (evalIntExpr inp 1 ws e).2.1 ≤ 2 * exprNodes e ∧
      (evalIntExpr inp 1 ws e).2.2 ≤ 8 * (exprNodes e) ^ 3 * (V + 8) ^ 2 := by
  have hV16 : 16 ≤ V := by have h := hinp.2.1; omega
  let X := V + 8
  have hX8 : 8 ≤ X := by dsimp [X]; omega
  intro e
  induction e with
  | lit c =>
      intro hin
      dsimp [ExprInArena, exprNodes, evalVal, evalIntExpr] at hin ⊢
      have h1 : intBitLength c ≤ 8 * 1 ^ 3 * (V + 8) ^ 2 := by
        rw [sq]
        have : intBitLength c ≤ V + 8 := by omega
        exact this.trans ((Nat.le_mul_of_pos_right _ (by omega)).trans (Nat.le_mul_of_pos_left _ (by norm_num)))
      exact ⟨by omega, by omega, h1⟩
  | dim =>
      intro _
      dsimp [exprNodes, evalVal, evalIntExpr]
      have hdV := hinp.2.2.1
      have h1 : intBitLength (d : ℤ) ≤ 8 * 1 ^ 3 * (V + 8) ^ 2 := by
        rw [sq]
        have : intBitLength (d : ℤ) ≤ V + 8 := by omega
        exact this.trans ((Nat.le_mul_of_pos_right _ (by omega)).trans (Nat.le_mul_of_pos_left _ (by norm_num)))
      exact ⟨by omega, by omega, h1⟩
  | intParam e ih =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih hin
      have hn1 := exprNodes_pos e
      rcases he : evalIntExpr inp 1 ws e with ⟨v₁, u₁, b₁⟩
      dsimp [evalVal] at hv1
      rw [he] at hv1 hu1 hb1; dsimp only at hv1 hu1 hb1
      dsimp [evalVal, evalIntExpr, exprNodes]
      rw [he]; dsimp only
      have hv_out := hinp.2.2.2.1 v₁
      refine ⟨by rw [Nat.add_mul, Nat.one_mul]; omega, by omega, ?_⟩
      rw [Nat.add_assoc]
      refine unary_cube_step hn1 hX8 hb1 ?_
      rw [Nat.add_mul]; dsimp [X]; have := Nat.mul_le_mul_left (exprNodes e) (show V + 4 ≤ V + 8 by omega); omega
  | extraRatNum e ih =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih hin
      have hn1 := exprNodes_pos e
      rcases he : evalIntExpr inp 1 ws e with ⟨v₁, u₁, b₁⟩
      dsimp [evalVal] at hv1; rw [he] at hv1 hu1 hb1; dsimp only at hv1 hu1 hb1
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he]; dsimp only
      have hv_out := (hinp.2.2.2.2.1 v₁).1
      refine ⟨by rw [Nat.add_mul, Nat.one_mul]; omega, by omega, ?_⟩
      rw [Nat.add_assoc]
      refine unary_cube_step hn1 hX8 hb1 ?_
      rw [Nat.add_mul]; dsimp [X]; have := Nat.mul_le_mul_left (exprNodes e) (show V + 4 ≤ V + 8 by omega); omega
  | extraRatDen e ih =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih hin
      have hn1 := exprNodes_pos e
      rcases he : evalIntExpr inp 1 ws e with ⟨v₁, u₁, b₁⟩
      dsimp [evalVal] at hv1; rw [he] at hv1 hu1 hb1; dsimp only at hv1 hu1 hb1
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he]; dsimp only
      have hv_out := (hinp.2.2.2.2.1 v₁).2
      refine ⟨by rw [Nat.add_mul, Nat.one_mul]; omega, by omega, ?_⟩
      rw [Nat.add_assoc]
      refine unary_cube_step hn1 hX8 hb1 ?_
      rw [Nat.add_mul]; dsimp [X]; have := Nat.mul_le_mul_left (exprNodes e) (show V + 4 ≤ V + 8 by omega); omega
  | readHeap t e ih =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih hin.2
      have hn1 := exprNodes_pos e
      rcases he : evalIntExpr inp 1 ws e with ⟨v₁, u₁, b₁⟩
      dsimp [evalVal] at hv1; rw [he] at hv1 hu1 hb1; dsimp only at hv1 hu1 hb1
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he]; dsimp only
      have hv_out := inAttemptArena_read_bitLen_le harena (by omega) (.heap t v₁)
      have ht_b : natBitLength t ≤ 4 := (natBitLength_mono (le_of_lt hin.1)).trans (by decide)
      refine ⟨by rw [Nat.add_mul, Nat.one_mul]; omega, by omega, ?_⟩
      simp only [Nat.add_assoc]
      refine unary_cube_step hn1 hX8 hb1 ?_
      rw [Nat.add_mul]; dsimp [X]; have := Nat.mul_le_mul_left (exprNodes e) (show V + 4 ≤ V + 8 by omega); omega
  | readLocal var e ih =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih hin.2
      have hn1 := exprNodes_pos e
      rcases he : evalIntExpr inp 1 ws e with ⟨v₁, u₁, b₁⟩
      dsimp [evalVal] at hv1; rw [he] at hv1 hu1 hb1; dsimp only at hv1 hu1 hb1
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he]; dsimp only
      have hv_out := inAttemptArena_read_bitLen_le harena (by omega) (.localFrame 1 var v₁)
      have hv_b : natBitLength var ≤ 7 := (natBitLength_mono (le_of_lt hin.1)).trans (by decide)
      refine ⟨by rw [Nat.add_mul, Nat.one_mul]; omega, by omega, ?_⟩
      simp only [Nat.add_assoc]
      refine unary_cube_step hn1 hX8 hb1 ?_
      rw [Nat.add_mul]; dsimp [X]; have := Nat.mul_le_mul_left (exprNodes e) (show V + 4 ≤ V + 8 by omega); omega
  | neg e ih =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih hin
      have hn1 := exprNodes_pos e
      rcases he : evalIntExpr inp 1 ws e with ⟨v₁, u₁, b₁⟩
      dsimp [evalVal] at hv1; rw [he] at hv1 hu1 hb1; dsimp only at hv1 hu1 hb1
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he]; dsimp only
      rw [intBitLength_neg]
      refine ⟨by rw [Nat.add_mul, Nat.one_mul]; omega, by omega,
        unary_cube_step hn1 hX8 hb1 ?_⟩
      rw [Nat.add_mul]; dsimp [X]; have := Nat.mul_le_mul_left (exprNodes e) (show V + 4 ≤ V + 8 by omega); omega
  | activeRatNum e₁ e₂ ih₁ ih₂ =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hin.1
      obtain ⟨hv2, hu2, hb2⟩ := ih₂ hin.2
      have hn1 := exprNodes_pos e₁; have hn2 := exprNodes_pos e₂
      rcases he1 : evalIntExpr inp 1 ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases he2 : evalIntExpr inp 1 ws e₂ with ⟨v₂, u₂, b₂⟩
      dsimp [evalVal] at hv1 hv2; rw [he1] at hv1 hu1 hb1; rw [he2] at hv2 hu2 hb2
      dsimp only at hv1 hu1 hb1 hv2 hu2 hb2
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he1, he2]; dsimp only
      have hv_out : intBitLength
          (if 0 ≤ v₁ ∧ v₁.toNat ∈ inp.activeHandles then
            if hc : 0 ≤ v₂ ∧ v₂.toNat < d then
              (inp.activeRatCoords v₁.toNat ⟨v₂.toNat, hc.2⟩).num
            else 0
          else 0) ≤ V := by
        split_ifs with h1 h2
        · exact (hinp.2.2.2.2.2 v₁.toNat h1.2 ⟨v₂.toNat, h2.2⟩).1
        · change 1 ≤ V; omega
        · change 1 ≤ V; omega
      refine ⟨by simp only [Nat.add_mul, Nat.one_mul]; omega, by omega, ?_⟩
      rw [Nat.add_assoc (b₁ + b₂), Nat.add_assoc (b₁ + b₂)]
      refine binary_cube_step hn1 hn2 hX8 hb1 hb2 ?_
      have hlin : intBitLength v₁ + intBitLength v₂ + intBitLength
          (if 0 ≤ v₁ ∧ v₁.toNat ∈ inp.activeHandles then
            if hc : 0 ≤ v₂ ∧ v₂.toNat < d then
              (inp.activeRatCoords v₁.toNat ⟨v₂.toNat, hc.2⟩).num
            else 0
          else 0) ≤ (exprNodes e₁ + exprNodes e₂ + 1) * X := by
        simp only [Nat.add_mul, Nat.one_mul]; dsimp [X]
        have := Nat.mul_le_mul_left (exprNodes e₁) (show V + 4 ≤ V + 8 by omega)
        have := Nat.mul_le_mul_left (exprNodes e₂) (show V + 4 ≤ V + 8 by omega)
        omega
      have hsq : (exprNodes e₁ + exprNodes e₂ + 1) * X ≤
          (exprNodes e₁ * exprNodes e₂ + exprNodes e₁ + exprNodes e₂ + 1) * X ^ 2 :=
        (Nat.mul_le_mul_right X (by omega)).trans (Nat.mul_le_mul_left _ (by nlinarith))
      exact hlin.trans hsq
  | activeRatDen e₁ e₂ ih₁ ih₂ =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hin.1
      obtain ⟨hv2, hu2, hb2⟩ := ih₂ hin.2
      have hn1 := exprNodes_pos e₁; have hn2 := exprNodes_pos e₂
      rcases he1 : evalIntExpr inp 1 ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases he2 : evalIntExpr inp 1 ws e₂ with ⟨v₂, u₂, b₂⟩
      dsimp [evalVal] at hv1 hv2; rw [he1] at hv1 hu1 hb1; rw [he2] at hv2 hu2 hb2
      dsimp only at hv1 hu1 hb1 hv2 hu2 hb2
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he1, he2]; dsimp only
      have hv_out : intBitLength
          (if 0 ≤ v₁ ∧ v₁.toNat ∈ inp.activeHandles then
            if hc : 0 ≤ v₂ ∧ v₂.toNat < d then
              ((inp.activeRatCoords v₁.toNat ⟨v₂.toNat, hc.2⟩).den : ℤ)
            else 1
          else 1) ≤ V := by
        have h12 : intBitLength 1 = 2 := by decide
        split_ifs with h1 h2
        · exact (hinp.2.2.2.2.2 v₁.toNat h1.2 ⟨v₂.toNat, h2.2⟩).2
        · omega
        · omega
      refine ⟨by simp only [Nat.add_mul, Nat.one_mul]; omega, by omega, ?_⟩
      rw [Nat.add_assoc (b₁ + b₂), Nat.add_assoc (b₁ + b₂)]
      refine binary_cube_step hn1 hn2 hX8 hb1 hb2 ?_
      have hlin : intBitLength v₁ + intBitLength v₂ + intBitLength
          (if 0 ≤ v₁ ∧ v₁.toNat ∈ inp.activeHandles then
            if hc : 0 ≤ v₂ ∧ v₂.toNat < d then
              ((inp.activeRatCoords v₁.toNat ⟨v₂.toNat, hc.2⟩).den : ℤ)
            else 1
          else 1) ≤ (exprNodes e₁ + exprNodes e₂ + 1) * X := by
        simp only [Nat.add_mul, Nat.one_mul]; dsimp [X]
        have := Nat.mul_le_mul_left (exprNodes e₁) (show V + 4 ≤ V + 8 by omega)
        have := Nat.mul_le_mul_left (exprNodes e₂) (show V + 4 ≤ V + 8 by omega)
        omega
      have hsq : (exprNodes e₁ + exprNodes e₂ + 1) * X ≤
          (exprNodes e₁ * exprNodes e₂ + exprNodes e₁ + exprNodes e₂ + 1) * X ^ 2 :=
        (Nat.mul_le_mul_right X (by omega)).trans (Nat.mul_le_mul_left _ (by nlinarith))
      exact hlin.trans hsq
  | add e₁ e₂ ih₁ ih₂ =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hin.1; obtain ⟨hv2, hu2, hb2⟩ := ih₂ hin.2
      have hn1 := exprNodes_pos e₁; have hn2 := exprNodes_pos e₂
      rcases he1 : evalIntExpr inp 1 ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases he2 : evalIntExpr inp 1 ws e₂ with ⟨v₂, u₂, b₂⟩
      dsimp [evalVal] at hv1 hv2; rw [he1] at hv1 hu1 hb1; rw [he2] at hv2 hu2 hb2
      dsimp only at hv1 hu1 hb1 hv2 hu2 hb2
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he1, he2]; dsimp only
      have hadd := intBitLength_add_le v₁ v₂
      refine ⟨by simp only [Nat.add_mul, Nat.one_mul]; omega, by omega, ?_⟩
      rw [Nat.add_assoc (b₁ + b₂)]
      refine binary_cube_step hn1 hn2 hX8 hb1 hb2 ?_
      have hlin : intBitLength v₁ + intBitLength v₂ ≤ (exprNodes e₁ + exprNodes e₂ + 1) * X := by
        simp only [Nat.add_mul, Nat.one_mul]; dsimp [X]
        have := Nat.mul_le_mul_left (exprNodes e₁) (show V + 4 ≤ V + 8 by omega)
        have := Nat.mul_le_mul_left (exprNodes e₂) (show V + 4 ≤ V + 8 by omega)
        omega
      have hsq : (exprNodes e₁ + exprNodes e₂ + 1) * X ≤
          (exprNodes e₁ * exprNodes e₂ + exprNodes e₁ + exprNodes e₂ + 1) * X ^ 2 :=
        (Nat.mul_le_mul_right X (by omega)).trans (Nat.mul_le_mul_left _ (by nlinarith))
      exact hlin.trans hsq
  | sub e₁ e₂ ih₁ ih₂ =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hin.1; obtain ⟨hv2, hu2, hb2⟩ := ih₂ hin.2
      have hn1 := exprNodes_pos e₁; have hn2 := exprNodes_pos e₂
      rcases he1 : evalIntExpr inp 1 ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases he2 : evalIntExpr inp 1 ws e₂ with ⟨v₂, u₂, b₂⟩
      dsimp [evalVal] at hv1 hv2; rw [he1] at hv1 hu1 hb1; rw [he2] at hv2 hu2 hb2
      dsimp only at hv1 hu1 hb1 hv2 hu2 hb2
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he1, he2]; dsimp only
      have hsub := intBitLength_sub_le v₁ v₂
      refine ⟨by simp only [Nat.add_mul, Nat.one_mul]; omega, by omega, ?_⟩
      rw [Nat.add_assoc (b₁ + b₂)]
      refine binary_cube_step hn1 hn2 hX8 hb1 hb2 ?_
      have hlin : intBitLength v₁ + intBitLength v₂ ≤ (exprNodes e₁ + exprNodes e₂ + 1) * X := by
        simp only [Nat.add_mul, Nat.one_mul]; dsimp [X]
        have := Nat.mul_le_mul_left (exprNodes e₁) (show V + 4 ≤ V + 8 by omega)
        have := Nat.mul_le_mul_left (exprNodes e₂) (show V + 4 ≤ V + 8 by omega)
        omega
      have hsq : (exprNodes e₁ + exprNodes e₂ + 1) * X ≤
          (exprNodes e₁ * exprNodes e₂ + exprNodes e₁ + exprNodes e₂ + 1) * X ^ 2 :=
        (Nat.mul_le_mul_right X (by omega)).trans (Nat.mul_le_mul_left _ (by nlinarith))
      exact hlin.trans hsq
  | mul e₁ e₂ ih₁ ih₂ =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hin.1; obtain ⟨hv2, hu2, hb2⟩ := ih₂ hin.2
      have hn1 := exprNodes_pos e₁; have hn2 := exprNodes_pos e₂
      rcases he1 : evalIntExpr inp 1 ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases he2 : evalIntExpr inp 1 ws e₂ with ⟨v₂, u₂, b₂⟩
      dsimp [evalVal] at hv1 hv2; rw [he1] at hv1 hu1 hb1; rw [he2] at hv2 hu2 hb2
      dsimp only at hv1 hu1 hb1 hv2 hu2 hb2
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he1, he2]; dsimp only
      have hmul := intBitLength_mul_le v₁ v₂
      refine ⟨by simp only [Nat.add_mul, Nat.one_mul]; omega, by omega,
        binary_cube_step hn1 hn2 hX8 hb1 hb2 ?_⟩
      have hv1X : intBitLength v₁ ≤ exprNodes e₁ * X :=
        hv1.trans (Nat.mul_le_mul_left _ (by dsimp [X]; omega))
      have hv2X : intBitLength v₂ ≤ exprNodes e₂ * X :=
        hv2.trans (Nat.mul_le_mul_left _ (by dsimp [X]; omega))
      calc intBitLength v₁ * intBitLength v₂
          ≤ (exprNodes e₁ * X) * (exprNodes e₂ * X) := Nat.mul_le_mul hv1X hv2X
        _ = (exprNodes e₁ * exprNodes e₂) * X ^ 2 := by ring
        _ ≤ (exprNodes e₁ * exprNodes e₂ + exprNodes e₁ + exprNodes e₂ + 1) * X ^ 2 :=
              Nat.mul_le_mul_right _ (by omega)
  | div e₁ e₂ ih₁ ih₂ =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hin.1; obtain ⟨hv2, hu2, hb2⟩ := ih₂ hin.2
      have hn1 := exprNodes_pos e₁; have hn2 := exprNodes_pos e₂
      rcases he1 : evalIntExpr inp 1 ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases he2 : evalIntExpr inp 1 ws e₂ with ⟨v₂, u₂, b₂⟩
      dsimp [evalVal] at hv1 hv2; rw [he1] at hv1 hu1 hb1; rw [he2] at hv2 hu2 hb2
      dsimp only at hv1 hu1 hb1 hv2 hu2 hb2
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he1, he2]; dsimp only
      have hdiv := intBitLength_ediv_le v₁ v₂
      refine ⟨by simp only [Nat.add_mul, Nat.one_mul]; omega, by omega,
        binary_cube_step hn1 hn2 hX8 hb1 hb2 ?_⟩
      have hv1X : intBitLength v₁ ≤ exprNodes e₁ * X :=
        hv1.trans (Nat.mul_le_mul_left _ (by dsimp [X]; omega))
      have hv2X : intBitLength v₂ ≤ exprNodes e₂ * X :=
        hv2.trans (Nat.mul_le_mul_left _ (by dsimp [X]; omega))
      calc intBitLength v₁ * intBitLength v₂
          ≤ (exprNodes e₁ * X) * (exprNodes e₂ * X) := Nat.mul_le_mul hv1X hv2X
        _ = (exprNodes e₁ * exprNodes e₂) * X ^ 2 := by ring
        _ ≤ (exprNodes e₁ * exprNodes e₂ + exprNodes e₁ + exprNodes e₂ + 1) * X ^ 2 :=
              Nat.mul_le_mul_right _ (by omega)
  | mod e₁ e₂ ih₁ ih₂ =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hin.1; obtain ⟨hv2, hu2, hb2⟩ := ih₂ hin.2
      have hn1 := exprNodes_pos e₁; have hn2 := exprNodes_pos e₂
      rcases he1 : evalIntExpr inp 1 ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases he2 : evalIntExpr inp 1 ws e₂ with ⟨v₂, u₂, b₂⟩
      dsimp [evalVal] at hv1 hv2; rw [he1] at hv1 hu1 hb1; rw [he2] at hv2 hu2 hb2
      dsimp only at hv1 hu1 hb1 hv2 hu2 hb2
      dsimp [evalVal, evalIntExpr, exprNodes]; rw [he1, he2]; dsimp only
      have hmod := intBitLength_emod_le v₁ v₂
      refine ⟨by simp only [Nat.add_mul, Nat.one_mul]; omega, by omega,
        binary_cube_step hn1 hn2 hX8 hb1 hb2 ?_⟩
      have hv1X : intBitLength v₁ ≤ exprNodes e₁ * X :=
        hv1.trans (Nat.mul_le_mul_left _ (by dsimp [X]; omega))
      have hv2X : intBitLength v₂ ≤ exprNodes e₂ * X :=
        hv2.trans (Nat.mul_le_mul_left _ (by dsimp [X]; omega))
      calc intBitLength v₁ * intBitLength v₂
          ≤ (exprNodes e₁ * X) * (exprNodes e₂ * X) := Nat.mul_le_mul hv1X hv2X
        _ = (exprNodes e₁ * exprNodes e₂) * X ^ 2 := by ring
        _ ≤ (exprNodes e₁ * exprNodes e₂ + exprNodes e₁ + exprNodes e₂ + 1) * X ^ 2 :=
              Nat.mul_le_mul_right _ (by omega)

theorem evalBitCond_arena_bound {d A V : ℕ} {inp : BitRAMInput d} {ws : WordStore}
    (harena : InAttemptArena A V ws) (hinp : ArenaInputOK A V inp) :
    ∀ c : BitCondExpr,
      CondInArena V c →
      (evalBitCond inp 1 ws c).2.1 ≤ 2 * condNodes c ∧
      (evalBitCond inp 1 ws c).2.2 ≤ 8 * (condNodes c) ^ 3 * (V + 8) ^ 2 := by
  have hV16 : 16 ≤ V := by have h := hinp.2.1; omega
  let X := V + 8
  have hX8 : 8 ≤ X := by dsimp [X]; omega
  intro c
  induction c with
  | intEq e₁ e₂ | intLt e₁ e₂ | intLe e₁ e₂ =>
      intro hin
      obtain ⟨hv1, hu1, hb1⟩ := evalIntExpr_arena_bound harena hinp e₁ hin.1
      obtain ⟨hv2, hu2, hb2⟩ := evalIntExpr_arena_bound harena hinp e₂ hin.2
      have hn1 := exprNodes_pos e₁; have hn2 := exprNodes_pos e₂
      rcases he1 : evalIntExpr inp 1 ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases he2 : evalIntExpr inp 1 ws e₂ with ⟨v₂, u₂, b₂⟩
      dsimp [evalVal] at hv1 hv2; rw [he1] at hv1 hu1 hb1; rw [he2] at hv2 hu2 hb2
      dsimp only at hv1 hu1 hb1 hv2 hu2 hb2
      dsimp [evalBitCond, condNodes]; rw [he1, he2]; dsimp only
      refine ⟨by omega, ?_⟩
      rw [Nat.add_assoc (b₁ + b₂)]
      refine binary_cube_step hn1 hn2 hX8 hb1 hb2 ?_
      have hlin : intBitLength v₁ + intBitLength v₂ ≤ (exprNodes e₁ + exprNodes e₂ + 1) * X := by
        simp only [Nat.add_mul, Nat.one_mul]; dsimp [X]
        have := Nat.mul_le_mul_left (exprNodes e₁) (show V + 4 ≤ V + 8 by omega)
        have := Nat.mul_le_mul_left (exprNodes e₂) (show V + 4 ≤ V + 8 by omega)
        omega
      have hsq : (exprNodes e₁ + exprNodes e₂ + 1) * X ≤
          (exprNodes e₁ * exprNodes e₂ + exprNodes e₁ + exprNodes e₂ + 1) * X ^ 2 :=
        (Nat.mul_le_mul_right X (by omega)).trans (Nat.mul_le_mul_left _ (by nlinarith))
      exact hlin.trans hsq
  | not c ih =>
      intro hin
      obtain ⟨hu1, hb1⟩ := ih hin
      have hn1 := condNodes_pos c
      rcases hc : evalBitCond inp 1 ws c with ⟨r, u, b⟩
      rw [hc] at hu1 hb1; dsimp only at hu1 hb1
      dsimp [evalBitCond, condNodes]; rw [hc]; dsimp only
      refine ⟨by omega, unary_cube_step hn1 hX8 hb1 (by dsimp [X]; nlinarith)⟩
  | and c₁ c₂ ih₁ ih₂ | or c₁ c₂ ih₁ ih₂ =>
      intro hin
      obtain ⟨hu1, hb1⟩ := ih₁ hin.1; obtain ⟨hu2, hb2⟩ := ih₂ hin.2
      have hn1 := condNodes_pos c₁; have hn2 := condNodes_pos c₂
      rcases hc1 : evalBitCond inp 1 ws c₁ with ⟨r₁, u₁, b₁⟩
      rcases hc2 : evalBitCond inp 1 ws c₂ with ⟨r₂, u₂, b₂⟩
      rw [hc1] at hu1 hb1; rw [hc2] at hu2 hb2; dsimp only at hu1 hb1 hu2 hb2
      dsimp [evalBitCond, condNodes]; rw [hc1, hc2]; dsimp only
      refine ⟨by omega, binary_cube_step hn1 hn2 hX8 hb1 hb2 ?_⟩
      have h1 : 1 ≤ X ^ 2 := Nat.one_le_pow 2 X (by omega)
      exact h1.trans (Nat.le_mul_of_pos_left _ (by omega))

/-! ### 3. High-level zero-boilerplate statement combinators -/

theorem exec_writeLocal_auto {d A V : ℕ} {inp : BitRAMInput d}
    {ws : WordStore} {bs : List Bool}
    {var : ℕ} {idxE valE : IntExpr} {idx val : ℤ}
    (harena : InAttemptArena A V ws)
    (hinp : ArenaInputOK A V inp)
    (hin_idx : ExprInArena V idxE)
    (hin_val : ExprInArena V valE)
    (hnodes : exprNodes idxE ≤ 16 ∧ exprNodes valE ≤ 16)
    (hidx_eq : evalVal inp ws idxE = idx)
    (hval_eq : evalVal inp ws valE = val)
    (hvar : var < 100) (hidx0 : 0 ≤ idx) (hidxA : idx.toNat < A)
    (hvalV : intBitLength val ≤ V) :
    InAttemptArena A V (ws.write (.localFrame 1 var idx) val) ∧
    ExecBounded inp (.writeLocal var idxE valE) ws bs
      (ws.write (.localFrame 1 var idx) val) bs
      68 (66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have hn_i := hnodes.1; have hn_v := hnodes.2
  have ha' := inAttemptArena_write_local harena hvar hidx0 hidxA hvalV
  have hsz' := inAttemptArena_size_le ha'
  obtain ⟨_, hu1, hb1⟩ := evalIntExpr_arena_bound harena hinp idxE hin_idx
  obtain ⟨_, hu2, hb2⟩ := evalIntExpr_arena_bound harena hinp valE hin_val
  rcases he1 : evalIntExpr inp 1 ws idxE with ⟨i₀, u₁, b₁⟩
  rcases he2 : evalIntExpr inp 1 ws valE with ⟨v₀, u₂, b₂⟩
  dsimp [evalVal] at hidx_eq hval_eq
  rw [he1] at hidx_eq hu1 hb1; rw [he2] at hval_eq hu2 hb2
  dsimp only at hidx_eq hval_eq hu1 hb1 hu2 hb2
  subst i₀; subst v₀
  have hb1_cap : b₁ ≤ 32768 * (V + 8) ^ 2 :=
    hb1.trans (Nat.mul_le_mul_right _ (by
      have : (exprNodes idxE) ^ 3 ≤ 16 ^ 3 := Nat.pow_le_pow_left hnodes.1 3
      omega))
  have hb2_cap : b₂ ≤ 32768 * (V + 8) ^ 2 :=
    hb2.trans (Nat.mul_le_mul_right _ (by
      have : (exprNodes valE) ^ 3 ≤ 16 ^ 3 := Nat.pow_le_pow_left hnodes.2 3
      omega))
  have hloc_le : (RAMCellLoc.localFrame 1 var idx).bitLength + intBitLength val ≤
      464 * (V + 8) ^ 2 := by
    dsimp [RAMCellLoc.bitLength]
    have hn1 : natBitLength 1 = 1 := rfl
    have hv_b : natBitLength var ≤ 7 := (natBitLength_mono (le_of_lt hvar)).trans (by decide)
    have hi_b : intBitLength idx ≤ natBitLength A + 1 := by
      rw [← Int.toNat_of_nonneg hidx0]
      exact (intBitLength_natCast_le_succ idx.toNat).trans
        (Nat.add_le_add_right (natBitLength_mono (le_of_lt hidxA)) 1)
    have hVA := hinp.2.1
    have hlin : (1 + natBitLength var + intBitLength idx) + intBitLength val ≤ 2 * (V + 8) := by omega
    rw [sq]
    exact hlin.trans ((Nat.mul_le_mul_left 2 (Nat.le_mul_self (V + 8))).trans
      (Nat.mul_le_mul_right _ (by norm_num)))
  refine ⟨ha', ExecBounded.writeLocal he1 he2 (by omega) (by omega)
    (Nat.add_le_add_left hsz'.1 _) (Nat.add_le_add_left hsz'.2 _)⟩

theorem exec_writeHeap_auto {d A V : ℕ} {inp : BitRAMInput d}
    {ws : WordStore} {bs : List Bool}
    {t : ℕ} {idxE valE : IntExpr} {idx val : ℤ}
    (harena : InAttemptArena A V ws)
    (hinp : ArenaInputOK A V inp)
    (hin_idx : ExprInArena V idxE)
    (hin_val : ExprInArena V valE)
    (hnodes : exprNodes idxE ≤ 16 ∧ exprNodes valE ≤ 16)
    (hidx_eq : evalVal inp ws idxE = idx)
    (hval_eq : evalVal inp ws valE = val)
    (ht : t < 8) (hidx0 : 0 ≤ idx) (hidxA : idx.toNat < A)
    (hvalV : intBitLength val ≤ V) :
    InAttemptArena A V (ws.write (.heap t idx) val) ∧
    ExecBounded inp (.writeHeap t idxE valE) ws bs
      (ws.write (.heap t idx) val) bs
      68 (66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have hn_i := hnodes.1; have hn_v := hnodes.2
  have ha' := inAttemptArena_write_heap harena ht hidx0 hidxA hvalV
  have hsz' := inAttemptArena_size_le ha'
  obtain ⟨_, hu1, hb1⟩ := evalIntExpr_arena_bound harena hinp idxE hin_idx
  obtain ⟨_, hu2, hb2⟩ := evalIntExpr_arena_bound harena hinp valE hin_val
  rcases he1 : evalIntExpr inp 1 ws idxE with ⟨i₀, u₁, b₁⟩
  rcases he2 : evalIntExpr inp 1 ws valE with ⟨v₀, u₂, b₂⟩
  dsimp [evalVal] at hidx_eq hval_eq
  rw [he1] at hidx_eq hu1 hb1; rw [he2] at hval_eq hu2 hb2
  dsimp only at hidx_eq hval_eq hu1 hb1 hu2 hb2
  subst i₀; subst v₀
  have hb1_cap : b₁ ≤ 32768 * (V + 8) ^ 2 :=
    hb1.trans (Nat.mul_le_mul_right _ (by
      have : (exprNodes idxE) ^ 3 ≤ 16 ^ 3 := Nat.pow_le_pow_left hnodes.1 3
      omega))
  have hb2_cap : b₂ ≤ 32768 * (V + 8) ^ 2 :=
    hb2.trans (Nat.mul_le_mul_right _ (by
      have : (exprNodes valE) ^ 3 ≤ 16 ^ 3 := Nat.pow_le_pow_left hnodes.2 3
      omega))
  have hloc_le : (RAMCellLoc.heap t idx).bitLength + intBitLength val ≤
      464 * (V + 8) ^ 2 := by
    dsimp [RAMCellLoc.bitLength]
    have ht_b : natBitLength t ≤ 4 := (natBitLength_mono (le_of_lt ht)).trans (by decide)
    have hi_b : intBitLength idx ≤ natBitLength A + 1 := by
      rw [← Int.toNat_of_nonneg hidx0]
      exact (intBitLength_natCast_le_succ idx.toNat).trans
        (Nat.add_le_add_right (natBitLength_mono (le_of_lt hidxA)) 1)
    have hVA := hinp.2.1
    have hlin : (natBitLength t + intBitLength idx) + intBitLength val ≤ 2 * (V + 8) := by omega
    rw [sq]
    exact hlin.trans ((Nat.mul_le_mul_left 2 (Nat.le_mul_self (V + 8))).trans
      (Nat.mul_le_mul_right _ (by norm_num)))
  refine ⟨ha', ExecBounded.writeHeap he1 he2 (by omega) (by omega)
    (Nat.add_le_add_left hsz'.1 _) (Nat.add_le_add_left hsz'.2 _)⟩

theorem exec_freeHeap_auto {d A V : ℕ} {inp : BitRAMInput d}
    {ws : WordStore} {bs : List Bool}
    {t : ℕ} {idxE : IntExpr} {idx : ℤ}
    (harena : InAttemptArena A V ws)
    (hinp : ArenaInputOK A V inp)
    (hin_idx : ExprInArena V idxE)
    (hnodes : exprNodes idxE ≤ 16)
    (hidx_eq : evalVal inp ws idxE = idx)
    (ht : t < 8) (hidx0 : 0 ≤ idx) (hidxA : idx.toNat < A) :
    InAttemptArena A V (ws.free (.heap t idx)) ∧
    ExecBounded inp (.freeHeap t idxE) ws bs
      (ws.free (.heap t idx)) bs
      68 (66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have ha' := inAttemptArena_free harena (.heap t idx)
  obtain ⟨_, hu1, hb1⟩ := evalIntExpr_arena_bound harena hinp idxE hin_idx
  rcases he1 : evalIntExpr inp 1 ws idxE with ⟨i₀, u₁, b₁⟩
  dsimp [evalVal] at hidx_eq
  rw [he1] at hidx_eq hu1 hb1
  dsimp only at hidx_eq hu1 hb1
  subst i₀
  have hb1_cap : b₁ ≤ 32768 * (V + 8) ^ 2 :=
    hb1.trans (Nat.mul_le_mul_right _ (by
      have : (exprNodes idxE) ^ 3 ≤ 16 ^ 3 := Nat.pow_le_pow_left hnodes 3
      omega))
  have hloc_le : (RAMCellLoc.heap t idx).bitLength ≤ 464 * (V + 8) ^ 2 := by
    dsimp [RAMCellLoc.bitLength]
    have ht_b : natBitLength t ≤ 4 := (natBitLength_mono (le_of_lt ht)).trans (by decide)
    have hi_b : intBitLength idx ≤ natBitLength A + 1 := by
      rw [← Int.toNat_of_nonneg hidx0]
      exact (intBitLength_natCast_le_succ idx.toNat).trans
        (Nat.add_le_add_right (natBitLength_mono (le_of_lt hidxA)) 1)
    have hVA := hinp.2.1
    have hlin : natBitLength t + intBitLength idx ≤ V + 8 := by omega
    rw [sq]
    exact hlin.trans ((Nat.le_mul_self (V + 8)).trans (Nat.le_mul_of_pos_left _ (by norm_num)))
  exact ⟨ha', ExecBounded.freeHeap he1 (by omega) (by omega)⟩

theorem exec_ite_auto {d A V : ℕ} {inp : BitRAMInput d}
    {ws₁ ws₂ : WordStore} {bs₁ bs₂ : List Bool}
    {cond : BitCondExpr} {tB fB : BitRAMStmt} {fl : Bool}
    {ub bb : ℕ}
    (harena : InAttemptArena A V ws₁)
    (hinp : ArenaInputOK A V inp)
    (hin_c : CondInArena V cond)
    (hnodes : condNodes cond ≤ 16)
    (hc_eq : evalCondVal inp ws₁ cond = fl)
    (hbody : ExecBounded inp (if fl then tB else fB) ws₁ bs₁ ws₂ bs₂
      ub bb (arenaCellCap inp A) (arenaBitCap inp A V)) :
    ExecBounded inp (.ite cond tB fB) ws₁ bs₁ ws₂ bs₂
      (68 + ub) (66000 * (V + 8) ^ 2 + bb) (arenaCellCap inp A) (arenaBitCap inp A V) := by
  obtain ⟨hu, hb⟩ := evalBitCond_arena_bound harena hinp cond hin_c
  rcases hc : evalBitCond inp 1 ws₁ cond with ⟨fl₀, uc, bc⟩
  dsimp [evalCondVal] at hc_eq
  rw [hc] at hc_eq hu hb
  dsimp only at hc_eq hu hb
  subst fl₀
  have hb_cap : bc ≤ 32768 * (V + 8) ^ 2 :=
    hb.trans (Nat.mul_le_mul_right _ (by
      have : (condNodes cond) ^ 3 ≤ 16 ^ 3 := Nat.pow_le_pow_left hnodes 3
      omega))
  exact ExecBounded.mono (ExecBounded.ite hc hbody) (by omega) (by omega) le_rfl le_rfl

theorem exec_repeatN_auto {d A V : ℕ} {inp : BitRAMInput d}
    {countE : IntExpr} {body : BitRAMStmt}
    (n : ℕ) (wsSeq : ℕ → WordStore) (bsSeq : ℕ → List Bool)
    {U B : ℕ}
    (harena0 : InAttemptArena A V (wsSeq 0))
    (hinp : ArenaInputOK A V inp)
    (hin_cnt : ExprInArena V countE)
    (hnodes : exprNodes countE ≤ 16)
    (hcnt_eq : evalVal inp (wsSeq 0) countE = (n : ℤ))
    (hstep : ∀ k : ℕ, k < n →
      ExecBounded inp body (wsSeq k) (bsSeq k) (wsSeq (k + 1)) (bsSeq (k + 1))
        U B (arenaCellCap inp A) (arenaBitCap inp A V)) :
    ExecBounded inp (.repeatN countE body) (wsSeq 0) (bsSeq 0) (wsSeq n) (bsSeq n)
      (68 + n * U) (66000 * (V + 8) ^ 2 + n * B)
      (arenaCellCap inp A) (arenaBitCap inp A V) := by
  obtain ⟨_, hu, hb⟩ := evalIntExpr_arena_bound harena0 hinp countE hin_cnt
  rcases he : evalIntExpr inp 1 (wsSeq 0) countE with ⟨cnt₀, uc, bc⟩
  dsimp [evalVal] at hcnt_eq
  rw [he] at hcnt_eq hu hb
  dsimp only at hcnt_eq hu hb
  subst cnt₀
  have hb_cap : bc ≤ 32768 * (V + 8) ^ 2 :=
    hb.trans (Nat.mul_le_mul_right _ (by
      have : (exprNodes countE) ^ 3 ≤ 16 ^ 3 := Nat.pow_le_pow_left hnodes 3
      omega))
  have h1 : 1 ≤ (V + 8) ^ 2 := Nat.one_le_pow 2 _ (by omega)
  exact ExecBounded.mono (ExecBounded.repeatN n wsSeq bsSeq he hstep)
    (by omega) (by omega) le_rfl le_rfl

/-- Compute `init * base ^ p` in `.localFrame 1 dstVar dstIdx`, where `base` is read from
`.localFrame 1 baseVar baseIdx`, for a compile-time constant exponent `p : ℕ`. -/
def powConstStmt (dstVar : ℕ) (dstIdx : ℤ) (initVal : ℤ)
    (baseVar : ℕ) (baseIdx : ℤ) (p : ℕ) : BitRAMStmt :=
  .seq (.writeLocal dstVar (.lit dstIdx) (.lit initVal))
    (.repeatN (.lit (p : ℤ))
      (.writeLocal dstVar (.lit dstIdx)
        (.mul (.readLocal dstVar (.lit dstIdx)) (.readLocal baseVar (.lit baseIdx)))))

theorem exec_powConstStmt {d A V : ℕ} {inp : BitRAMInput d}
    {ws₀ : WordStore} {bs : List Bool}
    {dstVar baseVar : ℕ} {dstIdx baseIdx : ℤ} {initVal bVal : ℕ} (p : ℕ)
    (harena : InAttemptArena A V ws₀)
    (hinp : ArenaInputOK A V inp)
    (hvars : dstVar < 100 ∧ baseVar < 100 ∧ (dstVar ≠ baseVar ∨ dstIdx ≠ baseIdx))
    (hidx : 0 ≤ dstIdx ∧ dstIdx.toNat < A ∧ intBitLength dstIdx ≤ V ∧
      intBitLength baseIdx ≤ V)
    (hr_base : ws₀.read (.localFrame 1 baseVar baseIdx) = (bVal : ℤ))
    (hp_V : intBitLength (p : ℤ) ≤ V)
    (hprod_V : ∀ k : ℕ, k ≤ p → intBitLength (((initVal * bVal ^ k : ℕ) : ℤ)) ≤ V) :
    InAttemptArena A V (ws₀.write (.localFrame 1 dstVar dstIdx) (((initVal * bVal ^ p : ℕ) : ℤ))) ∧
    ExecBounded inp (powConstStmt dstVar dstIdx (initVal : ℤ) baseVar baseIdx p)
      ws₀ bs
      (ws₀.write (.localFrame 1 dstVar dstIdx) (((initVal * bVal ^ p : ℕ) : ℤ))) bs
      (136 + p * 68) ((132000 + p * 66000) * (V + 8) ^ 2)
      (arenaCellCap inp A) (arenaBitCap inp A V) := by
  let wsSeq : ℕ → WordStore := fun k =>
    ws₀.write (.localFrame 1 dstVar dstIdx) (((initVal * bVal ^ k : ℕ) : ℤ))
  have ha_seq : ∀ k : ℕ, k ≤ p → InAttemptArena A V (wsSeq k) := fun k hk =>
    inAttemptArena_write_local harena hvars.1 hidx.1 hidx.2.1 (hprod_V k hk)
  have hinit_val : initVal * bVal ^ 0 = initVal := by simp
  have hinit_V : intBitLength (initVal : ℤ) ≤ V := by simpa [hinit_val] using hprod_V 0 (Nat.zero_le p)
  obtain ⟨_, hs_init⟩ := exec_writeLocal_auto
    (idxE := .lit dstIdx) (valE := .lit (initVal : ℤ))
    (idx := dstIdx) (val := (initVal : ℤ))
    harena hinp hidx.2.2.1 hinit_V ⟨by simp [exprNodes], by simp [exprNodes]⟩
    rfl rfl hvars.1 hidx.1 hidx.2.1 hinit_V
  have hs_init' : ExecBounded inp (.writeLocal dstVar (.lit dstIdx) (.lit (initVal : ℤ)))
      ws₀ bs (wsSeq 0) bs 68 (66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
    simpa [wsSeq] using hs_init
  have hrep : ExecBounded inp
      (.repeatN (.lit (p : ℤ))
        (.writeLocal dstVar (.lit dstIdx)
          (.mul (.readLocal dstVar (.lit dstIdx)) (.readLocal baseVar (.lit baseIdx)))))
      (wsSeq 0) bs (wsSeq p) bs
      (68 + p * 68) (66000 * (V + 8) ^ 2 + p * (66000 * (V + 8) ^ 2))
      (arenaCellCap inp A) (arenaBitCap inp A V) := by
    refine exec_repeatN_auto (countE := .lit (p : ℤ)) p wsSeq (fun _ => bs)
      (ha_seq 0 (Nat.zero_le p)) hinp hp_V (by simp [exprNodes]) rfl (fun k hk => ?_)
    have hr_d : (wsSeq k).read (.localFrame 1 dstVar dstIdx) = (((initVal * bVal ^ k : ℕ) : ℤ)) :=
      wordStore_read_write_self _ _ _
    have hr_b : (wsSeq k).read (.localFrame 1 baseVar baseIdx) = (bVal : ℤ) := by
      dsimp [wsSeq]
      rw [wordStore_read_write_of_ne _ (by
        intro h; injection h with _ hv hi
        exact hvars.2.2.elim (fun h1 => h1 hv.symm) (fun h2 => h2 hi.symm))]
      exact hr_base
    have h_ow : (wsSeq k).write (.localFrame 1 dstVar dstIdx) (((initVal * bVal ^ (k + 1) : ℕ) : ℤ)) =
        wsSeq (k + 1) := by
      dsimp [wsSeq]
      unfold WordStore.write
      congr 1
      · ext x; simp only [Finset.mem_insert]; tauto
      · funext x; by_cases hx : x = .localFrame 1 dstVar dstIdx <;> simp [hx]
    obtain ⟨_, hs_step⟩ := exec_writeLocal_auto
      (idxE := .lit dstIdx)
      (valE := .mul (.readLocal dstVar (.lit dstIdx)) (.readLocal baseVar (.lit baseIdx)))
      (idx := dstIdx)
      (val := (((initVal * bVal ^ (k + 1) : ℕ) : ℤ)))
      (ha_seq k (le_of_lt hk)) hinp
      hidx.2.2.1
      ⟨⟨hvars.1, hidx.2.2.1⟩, ⟨hvars.2.1, hidx.2.2.2⟩⟩
      ⟨by simp [exprNodes], by simp [exprNodes]⟩
      rfl
      (by simp only [evalVal_mul, evalVal_readLocal, evalVal_lit, hr_d, hr_b]; rw [pow_succ]; push_cast; ring)
      hvars.1 hidx.1 hidx.2.1 (hprod_V (k + 1) hk)
    rwa [h_ow] at hs_step
  refine ⟨ha_seq p le_rfl, ?_⟩
  refine ExecBounded.mono (ExecBounded.seq hs_init' hrep) (by omega) ?_ le_rfl le_rfl
  have : 66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + p * (66000 * (V + 8) ^ 2)) =
      (132000 + p * 66000) * (V + 8) ^ 2 := by ring
  omega

end UL.Proof_lem_A_2
