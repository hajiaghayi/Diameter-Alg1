import Mathlib
import UL.Proof.lem_A_2.H1b_FY
import UL.Proof.lem_A_2.RacerP51_H3f
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 1200000

namespace UL.Proof_lem_A_2

/-! ### 1. `popDepth 0` arena lemmas and `HasFYArray` alias for `HasPermArray` -/

theorem inAttemptArena_empty {A V : ℕ} :
    InAttemptArena A V WordStore.empty := by
  refine ⟨⟨wellFormedWS_empty, fun _ hm => by simp [WordStore.empty] at hm⟩,
    fun _ hm => by simp [WordStore.empty] at hm,
    fun _ hm => by simp [WordStore.empty] at hm⟩

theorem inAttemptArena_popDepth_zero {A V : ℕ} {ws : WordStore}
    (h : InAttemptArena A V ws) :
    InAttemptArena A V (ws.popDepth 0) := by
  refine ⟨⟨wellFormedWS_popDepth h.1.1 0, ?_⟩, ?_, ?_⟩
  · intro loc hloc
    exact h.1.2 loc (Finset.mem_of_mem_filter loc hloc)
  · intro loc hloc
    exact h.2.1 loc (Finset.mem_of_mem_filter loc hloc)
  · intro loc hloc
    obtain ⟨hm, hk⟩ := Finset.mem_filter.mp hloc
    dsimp [WordStore.popDepth]
    rw [if_pos hk]
    exact h.2.2 loc hm

theorem popDepth_zero_read_heap (ws : WordStore) (t : ℕ) (idx : ℤ) :
    (ws.popDepth 0).read (.heap t idx) = ws.read (.heap t idx) := by
  unfold WordStore.read WordStore.popDepth
  have hk : (RAMCellLoc.heap t idx).keepAtDepth 0 = true := rfl
  simp [hk]

theorem heapAllZero_popDepth_zero {ws : WordStore} (h : HeapAllZero ws) :
    HeapAllZero (ws.popDepth 0) :=
  fun t idx => (popDepth_zero_read_heap ws t idx).trans (h t idx)

abbrev HasFYArray := HasPermArray

theorem hasFYArray_of_eq {m : ℕ} {π : Equiv.Perm (Fin m)} {ws ws' : WordStore}
    (h : HasFYArray m π ws)
    (heq : ∀ idx : ℤ, ws'.read (.localFrame 1 5 idx) = ws.read (.localFrame 1 5 idx)) :
    HasFYArray m π ws' :=
  hasPermArray_of_eq h heq

/-! ### 3. Phase 5: Exact LP verification of `r` disjoint blocks -/

theorem flatPts_length :
    ∀ {s D : ℕ} (pts : Fin s → Fin D → ℚ),
      ((List.finRange s).flatMap (fun j => List.ofFn (pts j))).length = s * D
  | 0, _, _ => by simp
  | s + 1, D, pts => by
      rw [List.finRange_succ, List.flatMap_cons, List.length_append, List.length_ofFn,
        List.flatMap_map, flatPts_length (fun j : Fin s => pts j.succ)]
      ring

theorem flatPts_lt {s D : ℕ} (pts : Fin s → Fin D → ℚ) (j : Fin s) (c : Fin D) :
    j.1 * D + c.1 < ((List.finRange s).flatMap (fun i => List.ofFn (pts i))).length := by
  rw [flatPts_length]
  have hj : (j.1 + 1) * D ≤ s * D := Nat.mul_le_mul_right D j.2
  have hc : c.1 < D := c.2
  rw [Nat.add_mul, Nat.one_mul] at hj
  omega

theorem flatPts_getElem :
    ∀ {s D : ℕ} (pts : Fin s → Fin D → ℚ) (j : Fin s) (c : Fin D),
      ((List.finRange s).flatMap (fun i => List.ofFn (pts i)))[j.1 * D + c.1]'(flatPts_lt pts j c) = pts j c
  | 0, _, _, j, _ => Fin.elim0 j
  | s + 1, D, pts, ⟨0, _⟩, c => by
      simp only [Nat.zero_mul, Nat.zero_add, List.finRange_succ, List.flatMap_cons]
      rw [List.getElem_append_left (by simp [c.2]), List.getElem_ofFn]
      rfl
  | s + 1, D, pts, ⟨j' + 1, hj⟩, c => by
      let jFin : Fin s := ⟨j', Nat.lt_of_succ_lt_succ hj⟩
      have hge : D ≤ (j' + 1) * D + c.1 := by rw [Nat.add_mul, Nat.one_mul]; omega
      have hsub : (j' + 1) * D + c.1 - D = j' * D + c.1 := by rw [Nat.add_mul, Nat.one_mul]; omega
      simp only [List.finRange_succ, List.flatMap_cons, List.flatMap_map]
      rw [List.getElem_append_right (by simp [hge])]
      simp only [List.length_ofFn, hsub]
      exact flatPts_getElem (fun i : Fin s => pts i.succ) jFin c

def phase5PreStageStmt : BitRAMStmt :=
  .seq (.writeHeap 5 (.lit 0) (.readLocal 0 (.lit 1)))
  (.seq (.writeHeap 5 (.lit 1) (.readLocal 0 (.lit 5)))
  (.seq (.writeLocal 1 (.lit 9) (.lit 0))
  (.seq (.repeatN (.readLocal 0 (.lit 1))
          (.seq (.writeLocal 1 (.lit 10) (.mul (.lit 2) (.readLocal 1 (.lit 9))))
          (.seq (.writeLocal 1 (.lit 11) (.add (.readLocal 1 (.lit 10)) (.lit 1)))
          (.seq (.writeHeap 6 (.readLocal 1 (.lit 9)) (.readLocal 4 (.readLocal 1 (.lit 10))))
          (.seq (.writeHeap 7 (.readLocal 1 (.lit 9))
                  (.sub (.readLocal 4 (.readLocal 1 (.lit 11))) (.lit 1)))
                (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1))))))))
  (.seq (.writeLocal 1 (.lit 14) (.lit 0))
        (.writeLocal 1 (.lit 8) (.lit 0))))))

def phase5BlockStagePointBody : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 11)
          (.add (.mul (.readLocal 1 (.lit 8)) (.readLocal 0 (.lit 5))) (.readLocal 1 (.lit 9))))
  (.seq (.writeLocal 1 (.lit 13) (.readLocal 5 (.readLocal 1 (.lit 11))))
  (.seq (.writeLocal 1 (.lit 11)
          (.add (.readLocal 0 (.lit 1)) (.mul (.readLocal 1 (.lit 9)) (.readLocal 0 (.lit 1)))))
  (.seq (.writeLocal 1 (.lit 10) (.lit 0))
  (.seq (.repeatN (.readLocal 0 (.lit 0)) phase3InnerCoordBody)
  (.seq (.writeLocal 1 (.lit 12) (.add (.readLocal 1 (.lit 11)) (.readLocal 0 (.lit 0))))
  (.seq (.writeHeap 6 (.readLocal 1 (.lit 12)) (.readLocal 2 (.readLocal 1 (.lit 13))))
  (.seq (.writeHeap 7 (.readLocal 1 (.lit 12))
          (.sub (.readLocal 3 (.readLocal 1 (.lit 13))) (.lit 1)))
        (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1))))))))))

def phase5CopyPassBody : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 10)
          (.add (.mul (.readLocal 1 (.lit 8)) (.readLocal 0 (.lit 5))) (.readLocal 1 (.lit 9))))
  (.seq (.writeLocal 1 (.lit 11)
          (.add (.mul (.readLocal 1 (.lit 14)) (.readLocal 0 (.lit 5))) (.readLocal 1 (.lit 9))))
  (.seq (.writeLocal 7 (.readLocal 1 (.lit 11)) (.readLocal 5 (.readLocal 1 (.lit 10))))
  (.seq (.writeLocal 1 (.lit 12) (.mul (.lit 2) (.readLocal 1 (.lit 11))))
  (.seq (.writeLocal 1 (.lit 13) (.mul (.lit 2) (.readLocal 1 (.lit 9))))
  (.seq (.writeLocal 8 (.readLocal 1 (.lit 12)) (.readLocal 6 (.readLocal 1 (.lit 13))))
  (.seq (.writeLocal 8 (.add (.readLocal 1 (.lit 12)) (.lit 1))
          (.readLocal 6 (.add (.readLocal 1 (.lit 13)) (.lit 1))))
        (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1)))))))))

def phase5BlockOuterBody (progCert : BitRAMStmt) : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 9) (.lit 0))
  (.seq (.repeatN (.readLocal 0 (.lit 5)) phase5BlockStagePointBody)
  (.seq (runSubAndExtractStmt false progCert 1 15 6 (some (0, 15)) 9)
  (.seq (.ite (.intEq (.readLocal 1 (.lit 15)) (.lit 1))
          (.seq (.writeLocal 1 (.lit 9) (.lit 0))
          (.seq (.repeatN (.readLocal 0 (.lit 5)) phase5CopyPassBody)
                (.writeLocal 1 (.lit 14) (.add (.readLocal 1 (.lit 14)) (.lit 1)))))
          .skip)
        (.writeLocal 1 (.lit 8) (.add (.readLocal 1 (.lit 8)) (.lit 1))))))

def phase5UnstageStmt : BitRAMStmt :=
  .seq (.freeHeap 5 (.lit 0))
  (.seq (.freeHeap 5 (.lit 1))
  (.seq (.writeLocal 1 (.lit 9) (.lit 0))
  (.seq (.writeLocal 1 (.lit 10)
          (.add (.readLocal 0 (.lit 1)) (.mul (.readLocal 0 (.lit 5)) (.readLocal 0 (.lit 1)))))
        (.repeatN (.readLocal 1 (.lit 10))
          (.seq (.freeHeap 6 (.readLocal 1 (.lit 9)))
          (.seq (.freeHeap 7 (.readLocal 1 (.lit 9)))
                (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1)))))))))

def phase5Stmt (progCert : BitRAMStmt) : BitRAMStmt :=
  .seq phase5PreStageStmt
  (.seq (.repeatN (.readLocal 0 (.lit 6)) (phase5BlockOuterBody progCert))
        phase5UnstageStmt)

def blkHandle (p : CoreParams) (π : Equiv.Perm (Fin p.m)) (b : Fin p.r) (j : Fin p.s₀) : Fin p.m :=
  π ⟨b.1 * p.s₀ + j.1, by
    have hb : (b.1 + 1) * p.s₀ ≤ p.r * p.s₀ := Nat.mul_le_mul_right p.s₀ b.2
    have hrs : p.r * p.s₀ ≤ p.m := Nat.div_mul_le_self p.m p.s₀
    rw [Nat.add_mul, Nat.one_mul] at hb
    omega⟩

def certBlockInp (p : CoreParams) (pts_h : ℕ → Fin p.d → ℚ) (zRat : Fin p.D → ℚ)
    (π : Equiv.Perm (Fin p.m)) (b : Fin p.r) : BitRAMInput 0 :=
  let pts_b : Fin p.s₀ → Fin p.D → ℚ := fun j => liftRatPoint (pts_h (blkHandle p π b j).1)
  { intParams := [(p.D : ℤ), (p.s₀ : ℤ)]
    activeHandles := ∅
    activeRatCoords := fun _ k => Fin.elim0 k
    extraRats := List.ofFn zRat ++ (List.finRange p.s₀).flatMap (fun j => List.ofFn (pts_b j)) }

theorem exec_phase5PreStageStmt {A V M : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ) (zRat : Fin p.D → ℚ) (π : Equiv.Perm (Fin p.m))
    {inp : BitRAMInput p.d} {ws₅ : WordStore} {bs : List Bool}
    (harena : InAttemptArena A V ws₅)
    (hhz : HeapAllZero ws₅)
    (hregs : HasPhase2Regs p M ws₅)
    (hlifts : HasLiftArrays p pts_h ws₅)
    (hz : HasZArray p.D zRat ws₅)
    (hfy : HasFYArray p.m π ws₅)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hz_V : ∀ c : Fin p.D,
      intBitLength (zRat c).num ≤ V ∧ intBitLength (((zRat c).den : ℤ) - 1) ≤ V) :
    ∃ wsPre : WordStore,
      InAttemptArena A V wsPre ∧
      HasPhase2Regs p M wsPre ∧
      HasLiftArrays p pts_h wsPre ∧
      HasZArray p.D zRat wsPre ∧
      HasFYArray p.m π wsPre ∧
      wsPre.read (.localFrame 1 1 8) = 0 ∧
      wsPre.read (.localFrame 1 1 14) = 0 ∧
      (∀ t idx, t ≠ 5 → t ≠ 6 → t ≠ 7 → wsPre.read (.heap t idx) = 0) ∧
      (∀ idx : ℤ, wsPre.read (.heap 5 idx) = listGetIntD [(p.D : ℤ), (p.s₀ : ℤ)] idx 0) ∧
      (∀ c : Fin p.D,
        wsPre.read (.heap 6 (c.1 : ℤ)) = (zRat c).num ∧
        wsPre.read (.heap 7 (c.1 : ℤ)) + 1 = ((zRat c).den : ℤ)) ∧
      (∀ idx : ℤ, (idx < 0 ∨ (p.D : ℤ) ≤ idx) →
        wsPre.read (.heap 6 idx) = 0 ∧ wsPre.read (.heap 7 idx) = 0) ∧
      ExecBounded inp phase5PreStageStmt ws₅ bs wsPre bs
        (500 + 400 * p.D) ((500000 + 400000 * p.D) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have hmA := hfit.2.2.2.2.2.1
  have hVA := hfit.2.2.2.2.2.2.1
  have hs0_V := hfit.2.2.2.2.2.2.2.2.2.1
  have hV16 : 16 ≤ V := by omega
  have idx_V : ∀ k : ℕ, k ≤ A → intBitLength (k : ℤ) ≤ V := by
    intro k hk
    have h1 := intBitLength_natCast_le_succ k
    have h2 := natBitLength_mono hk
    omega
  obtain ⟨ha_1, ex_1⟩ := exec_writeHeap_auto (t := 5) (idxE := .lit 0) (valE := .readLocal 0 (.lit 1)) (idx := 0) (val := (p.D : ℤ)) harena hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ rfl hregs.1.2.1 (by decide) (by omega) (by simp; omega)
    (idx_V p.D (by omega))
  obtain ⟨ha_2, ex_2⟩ := exec_writeHeap_auto (t := 5) (idxE := .lit 1) (valE := .readLocal 0 (.lit 5)) (idx := 1) (val := (p.s₀ : ℤ)) ha_1 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ rfl
    (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit]; rw []; exact hregs.1.2.2.2.2.2.1)
    (by decide) (by omega) (by simp; omega) hs0_V
  obtain ⟨ha_3, ex_3⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .lit 0) (idx := 9) (val := 0) ha_2 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ rfl rfl (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
  let Inv (c : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
    bs_c = bs ∧
    InAttemptArena A V ws ∧
    HasPhase2Regs p M ws ∧
    HasLiftArrays p pts_h ws ∧
    HasZArray p.D zRat ws ∧
    HasFYArray p.m π ws ∧
    ws.read (.localFrame 1 1 9) = (c : ℤ) ∧
    (∀ t idx, t ≠ 5 → t ≠ 6 → t ≠ 7 → ws.read (.heap t idx) = 0) ∧
    (∀ idx : ℤ, ws.read (.heap 5 idx) = listGetIntD [(p.D : ℤ), (p.s₀ : ℤ)] idx 0) ∧
    (∀ (k : ℕ) (hk : k < c) (hkD : k < p.D),
      ws.read (.heap 6 (k : ℤ)) = (zRat ⟨k, hkD⟩).num ∧
      ws.read (.heap 7 (k : ℤ)) + 1 = ((zRat ⟨k, hkD⟩).den : ℤ)) ∧
    (∀ idx : ℤ, (idx < 0 ∨ (c : ℤ) ≤ idx) →
      ws.read (.heap 6 idx) = 0 ∧ ws.read (.heap 7 idx) = 0)
  have hinit : Inv 0 (((ws₅.write (.heap 5 0) (p.D : ℤ)).write (.heap 5 1) (p.s₀ : ℤ)).write (.localFrame 1 1 9) 0) bs := by
    have hloc : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
        (((ws₅.write (.heap 5 0) (p.D : ℤ)).write (.heap 5 1) (p.s₀ : ℤ)).write
          (.localFrame 1 1 9) 0).read (.localFrame 1 v idx) = ws₅.read (.localFrame 1 v idx) := by
      intro v idx hne1
      rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
        wordStore_read_write_of_ne _ (by intro h; cases h),
        wordStore_read_write_of_ne _ (by intro h; cases h)]
    refine ⟨rfl, ha_3,
      hasPhase2Regs_of_eq hregs (fun idx => hloc 0 idx (by decide)),
      hasLiftArrays_of_eq hlifts (fun v idx hv => hloc v idx (by rcases hv with rfl | rfl <;> decide)),
      hasZArray_of_eq hz (fun idx => hloc 4 idx (by decide)),
      hasFYArray_of_eq hfy (fun idx => hloc 5 idx (by decide)),
      wordStore_read_write_self _ _ _,
      fun t idx ht5 _ _ => by
        rw [wordStore_read_write_of_ne _ (by intro h; cases h),
          wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht5 ht),
          wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht5 ht)]
        exact hhz t idx,
      fun idx => ?_,
      fun _ hk _ => absurd hk (by omega),
      fun idx _ => ⟨by
        simp [rw_write_eq, rf_free_eq]
        exact hhz 6 idx, by
        simp [rw_write_eq, rf_free_eq]
        exact hhz 7 idx⟩⟩
    rw [wordStore_read_write_of_ne _ (by intro h; cases h)]
    by_cases h1 : idx = 1
    · subst h1; rw [wordStore_read_write_self]; rfl
    · rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact h1 hi)]
      by_cases h0 : idx = 0
      · subst h0; rw [wordStore_read_write_self]; rfl
      · rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact h0 hi), hhz 5 idx]
        unfold listGetIntD
        by_cases hn : idx < 0
        · simp [hn]
        · have hnone : ([(p.D : ℤ), (p.s₀ : ℤ)][idx.toNat]?) = none :=
            List.getElem?_eq_none (by simp; omega)
          simp [hn, List.getD, hnone]
  obtain ⟨wsL, _, hinv_D, ex_loop⟩ := exec_repeatN_inv (countE := .readLocal 0 (.lit 1)) (body := .seq (.writeLocal 1 (.lit 10) (.mul (.lit 2) (.readLocal 1 (.lit 9)))) (.seq (.writeLocal 1 (.lit 11) (.add (.readLocal 1 (.lit 10)) (.lit 1))) (.seq (.writeHeap 6 (.readLocal 1 (.lit 9)) (.readLocal 4 (.readLocal 1 (.lit 10)))) (.seq (.writeHeap 7 (.readLocal 1 (.lit 9)) (.sub (.readLocal 4 (.readLocal 1 (.lit 11))) (.lit 1))) (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1))))))) p.D Inv
    ha_3 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit, hregs.1.2.1])
    hinit (U := 360) (B := 350000 * (V + 8) ^ 2)
    (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
    (fun c ws_c bs_c hc ⟨hbs_c, ha_c, hregs_c, hlifts_c, hz_c, hfy_c, hr9_c, hht_c, hh5_c, hzc_c, hzz_c⟩ => by
      subst bs_c
      obtain ⟨hzn_V, hzd1_V⟩ := hz_V ⟨c, hc⟩
      obtain ⟨ha_s1, ex_s1⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 10) (valE := .mul (.lit 2) (.readLocal 1 (.lit 9))) (idx := 10) (val := 2 * (c : ℤ)) ha_c hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ rfl
        (by simp only [evalVal_mul, evalVal_readLocal, evalVal_lit, hr9_c])
        (by decide) (by omega) (by simp; omega) (by have heq : (2 * (c : ℤ)) = ((2 * c : ℕ) : ℤ) := by { push_cast; ring }; rw [heq]; exact idx_V (2 * c) (by omega))
      obtain ⟨ha_s2, ex_s2⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 11) (valE := .add (.readLocal 1 (.lit 10)) (.lit 1)) (idx := 11) (val := 2 * (c : ℤ) + 1) ha_s1 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ rfl
        (by simp only [evalVal_add, evalVal_readLocal, evalVal_lit, wordStore_read_write_self])
        (by decide) (by omega) (by simp; omega) (by have heq : (2 * (c : ℤ) + 1) = ((2 * c + 1 : ℕ) : ℤ) := by { push_cast; ring }; rw [heq]; exact idx_V (2 * c + 1) (by omega))
      obtain ⟨ha_s3, ex_s3⟩ := exec_writeHeap_auto (t := 6) (idxE := .readLocal 1 (.lit 9)) (valE := .readLocal 4 (.readLocal 1 (.lit 10))) (idx := (c : ℤ)) (val := (zRat ⟨c, hc⟩).num) ha_s2 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
              hr9_c])
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
               (hz_c ⟨c, hc⟩).1])
        (by decide) (by positivity) (by simpa using (by omega : c < A)) hzn_V
      obtain ⟨ha_s4, ex_s4⟩ := exec_writeHeap_auto (t := 7) (idxE := .readLocal 1 (.lit 9)) (valE := .sub (.readLocal 4 (.readLocal 1 (.lit 11))) (.lit 1)) (idx := (c : ℤ)) (val := ((zRat ⟨c, hc⟩).den : ℤ) - 1) ha_s3 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
              hr9_c])
        (by simp [rw_write_eq, rf_free_eq, evalVal_sub, evalVal_readLocal, evalVal_lit,
               (hz_c ⟨c, hc⟩).2])
        (by decide) (by positivity) (by simpa using (by omega : c < A)) hzd1_V
      obtain ⟨ha_s5, ex_s5⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .add (.readLocal 1 (.lit 9)) (.lit 1)) (idx := 9) (val := ((c + 1 : ℕ) : ℤ)) ha_s4 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ rfl
        (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit, hr9_c])
        (by decide) (by omega) (by simp; omega) (idx_V (c + 1) (by omega))
      let ws_next := (((((ws_c.write (.localFrame 1 1 10) (2 * (c : ℤ))).write
        (.localFrame 1 1 11) (2 * (c : ℤ) + 1)).write
        (.heap 6 (c : ℤ)) (zRat ⟨c, hc⟩).num).write
        (.heap 7 (c : ℤ)) (((zRat ⟨c, hc⟩).den : ℤ) - 1)).write
        (.localFrame 1 1 9) (((c + 1 : ℕ) : ℤ)))
      have hloc : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
          ws_next.read (.localFrame 1 v idx) = ws_c.read (.localFrame 1 v idx) := by
        intro v idx hne1
        dsimp [ws_next]
        rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
          wordStore_read_write_of_ne _ (by intro h; cases h),
          wordStore_read_write_of_ne _ (by intro h; cases h),
          wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
          wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv)]
      refine ⟨ws_next, bs, ⟨rfl, ha_s5,
        hasPhase2Regs_of_eq hregs_c (fun idx => hloc 0 idx (by decide)),
        hasLiftArrays_of_eq hlifts_c (fun v idx hv => hloc v idx (by rcases hv with rfl | rfl <;> decide)),
        hasZArray_of_eq hz_c (fun idx => hloc 4 idx (by decide)),
        hasFYArray_of_eq hfy_c (fun idx => hloc 5 idx (by decide)),
        wordStore_read_write_self _ _ _,
        fun t idx ht5 ht6 ht7 => by
          dsimp [ws_next]
          rw [wordStore_read_write_of_ne _ (by intro h; cases h),
            wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht7 ht),
            wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht6 ht),
            wordStore_read_write_of_ne _ (by intro h; cases h),
            wordStore_read_write_of_ne _ (by intro h; cases h)]
          exact hht_c t idx ht5 ht6 ht7,
        fun idx => by
          dsimp [ws_next]
          rw [wordStore_read_write_of_ne _ (by intro h; cases h),
            wordStore_read_write_of_ne _ (by intro h; simp at h; try omega), wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
            wordStore_read_write_of_ne _ (by intro h; cases h),
            wordStore_read_write_of_ne _ (by intro h; cases h)]
          exact hh5_c idx,
        fun k hk hkD => by
          rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hk) with hlt | rfl
          · dsimp [ws_next]
            refine ⟨?_, ?_⟩
            · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
                wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
                wordStore_read_write_of_ne _ (by intro h; cases h),
                wordStore_read_write_of_ne _ (by intro h; cases h)]
              exact (hzc_c k hlt hkD).1
            · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
                wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
                wordStore_read_write_of_ne _ (by intro h; cases h),
                wordStore_read_write_of_ne _ (by intro h; cases h)]
              exact (hzc_c k hlt hkD).2
          · dsimp [ws_next]
            exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                        wordStore_read_write_of_ne _ (by intro h; simp at h; try omega), wordStore_read_write_self],
                   by rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                        wordStore_read_write_self]; ring⟩,
        fun idx hrange => by
          dsimp [ws_next]
          refine ⟨?_, ?_⟩
          · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
              wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
              wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
              wordStore_read_write_of_ne _ (by intro h; cases h),
              wordStore_read_write_of_ne _ (by intro h; cases h)]
            exact (hzz_c idx (by omega)).1
          · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
              wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
              wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
              wordStore_read_write_of_ne _ (by intro h; cases h),
              wordStore_read_write_of_ne _ (by intro h; cases h)]
            exact (hzz_c idx (by omega)).2⟩,
        ExecBounded.mono (ExecBounded.seq ex_s1 (ExecBounded.seq ex_s2
          (ExecBounded.seq ex_s3 (ExecBounded.seq ex_s4 ex_s5))))
          (by omega) (by omega) le_rfl le_rfl⟩)
  rcases hinv_D with ⟨hbs_D, ha_D, hregs_D, hlifts_D, hz_D, hfy_D, _, hht_D, hh5_D, hzc_D, hzz_D⟩
  rw [hbs_D] at ex_loop
  obtain ⟨ha_k0, ex_k0⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 14) (valE := .lit 0) (idx := 14) (val := 0) (bs := bs) ha_D hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ rfl rfl (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
  obtain ⟨ha_b0, ex_b0⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 8) (valE := .lit 0) (idx := 8) (val := 0) (bs := bs) ha_k0 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ rfl rfl (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
  let wsPre := (wsL.write (.localFrame 1 1 14) 0).write (.localFrame 1 1 8) 0
  have hloc_end : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
      wsPre.read (.localFrame 1 v idx) = wsL.read (.localFrame 1 v idx) := by
    intro v idx hne1
    dsimp [wsPre]
    rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
      wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv)]
  have hheap_end : ∀ t idx, wsPre.read (.heap t idx) = wsL.read (.heap t idx) := by
    intro t idx; dsimp [wsPre]
    rw [wordStore_read_write_of_ne _ (by intro h; cases h),
      wordStore_read_write_of_ne _ (by intro h; cases h)]
  have ex_tot := ExecBounded.seq ex_1 (ExecBounded.seq ex_2 (ExecBounded.seq ex_3
    (ExecBounded.seq ex_loop (ExecBounded.seq ex_k0 ex_b0))))
  have hb_tot :
      66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 +
      ((66000 * (V + 8) ^ 2 + p.D * (350000 * (V + 8) ^ 2)) +
      (66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2)))) ≤
      (500000 + 400000 * p.D) * (V + 8) ^ 2 := by
    set Y := (V + 8) ^ 2
    have h1 : p.D * (350000 * Y) ≤ p.D * (400000 * Y) :=
      Nat.mul_le_mul_left p.D (Nat.mul_le_mul_right Y (by omega))
    have h2 : (500000 + 400000 * p.D) * Y = 500000 * Y + p.D * (400000 * Y) := by ring
    omega
  exact ⟨wsPre, ha_b0,
    hasPhase2Regs_of_eq hregs_D (fun idx => hloc_end 0 idx (by decide)),
    hasLiftArrays_of_eq hlifts_D (fun v idx hv => hloc_end v idx (by rcases hv with rfl | rfl <;> decide)),
    hasZArray_of_eq hz_D (fun idx => hloc_end 4 idx (by decide)),
    hasFYArray_of_eq hfy_D (fun idx => hloc_end 5 idx (by decide)),
    wordStore_read_write_self _ _ _,
    by dsimp [wsPre]; rw [wordStore_read_write_of_ne _ (by intro h; simp at h; try omega), wordStore_read_write_self],
    fun t idx ht5 ht6 ht7 => (hheap_end t idx).trans (hht_D t idx ht5 ht6 ht7),
    fun idx => (hheap_end 5 idx).trans (hh5_D idx),
    fun c => ⟨(hheap_end 6 _).trans (hzc_D c.1 c.2 c.2).1,
              by rw [hheap_end 7 _]; exact (hzc_D c.1 c.2 c.2).2⟩,
    fun idx hr => ⟨(hheap_end 6 idx).trans (hzz_D idx hr).1,
                   (hheap_end 7 idx).trans (hzz_D idx hr).2⟩,
    ExecBounded.mono ex_tot (by omega) hb_tot le_rfl le_rfl⟩

theorem exec_phase5UnstageStmt {A V M : ℕ} (p : CoreParams)
    {inp : BitRAMInput p.d} {ws₀ : WordStore} {bs : List Bool}
    (harena : InAttemptArena A V ws₀)
    (hregs : HasPhase2Regs p M ws₀)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hsDA : p.D + p.s₀ * p.D + 4 ≤ A)
    (hht : ∀ t idx, t ≠ 5 → t ≠ 6 → t ≠ 7 → ws₀.read (.heap t idx) = 0)
    (hh5 : ∀ idx : ℤ, idx ≠ 0 → idx ≠ 1 → ws₀.read (.heap 5 idx) = 0)
    (hh67 : ∀ idx : ℤ, (idx < 0 ∨ ((p.D + p.s₀ * p.D : ℕ) : ℤ) ≤ idx) →
      ws₀.read (.heap 6 idx) = 0 ∧ ws₀.read (.heap 7 idx) = 0) :
    ∃ ws₁ : WordStore,
      InAttemptArena A V ws₁ ∧
      HeapAllZero ws₁ ∧
      HasPhase2Regs p M ws₁ ∧
      (∀ (v : ℕ) (idx : ℤ), v ≠ 1 → ws₁.read (.localFrame 1 v idx) = ws₀.read (.localFrame 1 v idx)) ∧
      ws₁.read (.localFrame 1 1 14) = ws₀.read (.localFrame 1 1 14) ∧
      ExecBounded inp phase5UnstageStmt ws₀ bs ws₁ bs
        (500 + 250 * (p.D + p.s₀ * p.D))
        ((500000 + 250000 * (p.D + p.s₀ * p.D)) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have h16A := hfit.2.2.2.2.1
  have hVA := hfit.2.2.2.2.2.2.1
  have hV16 : 16 ≤ V := by omega
  let N_tot : ℕ := p.D + p.s₀ * p.D
  have idx_V : ∀ k : ℕ, k ≤ A → intBitLength (k : ℤ) ≤ V := by
    intro k hk
    have h1 := intBitLength_natCast_le_succ k
    have h2 := natBitLength_mono hk
    omega
  obtain ⟨ha_1, ex_1⟩ := exec_freeHeap_auto (t := 5) (idxE := .lit 0) (idx := 0) harena hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide) rfl
    (by decide) (by omega) (by simp; omega)
  obtain ⟨ha_2, ex_2⟩ := exec_freeHeap_auto (t := 5) (idxE := .lit 1) (idx := 1) ha_1 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide) rfl
    (by decide) (by omega) (by simp; omega)
  obtain ⟨ha_3, ex_3⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .lit 0) (idx := 9) (val := 0) ha_2 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ rfl rfl (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
  obtain ⟨ha_4, ex_4⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 10) (valE := .add (.readLocal 0 (.lit 1)) (.mul (.readLocal 0 (.lit 5)) (.readLocal 0 (.lit 1)))) (idx := 10) (val := (N_tot : ℤ)) ha_3 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ rfl
    (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit, hregs.1.2.1, hregs.1.2.2.2.2.2.1, N_tot])
    (by decide) (by omega) (by simp; omega) (idx_V N_tot (by omega))
  let Inv (k : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
    bs_c = bs ∧
    InAttemptArena A V ws ∧
    HasPhase2Regs p M ws ∧
    (∀ (v : ℕ) (idx : ℤ), v ≠ 1 → ws.read (.localFrame 1 v idx) = ws₀.read (.localFrame 1 v idx)) ∧
    ws.read (.localFrame 1 1 14) = ws₀.read (.localFrame 1 1 14) ∧
    ws.read (.localFrame 1 1 9) = (k : ℤ) ∧
    (∀ t idx, t ≠ 6 → t ≠ 7 → ws.read (.heap t idx) = 0) ∧
    (∀ idx : ℤ, (idx < (k : ℤ) ∨ (N_tot : ℤ) ≤ idx) →
      ws.read (.heap 6 idx) = 0 ∧ ws.read (.heap 7 idx) = 0)
  have hinit : Inv 0 ((((ws₀.free (.heap 5 0)).free (.heap 5 1)).write (.localFrame 1 1 9) 0).write (.localFrame 1 1 10) (N_tot : ℤ)) bs := by
    have hloc_ne1 : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
        ((((ws₀.free (.heap 5 0)).free (.heap 5 1)).write
          (.localFrame 1 1 9) 0).write (.localFrame 1 1 10) (N_tot : ℤ)).read (.localFrame 1 v idx) =
        ws₀.read (.localFrame 1 v idx) := by
      intro v idx hne1
      rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
        wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
        wordStore_read_free_of_ne _ (by intro h; cases h),
        wordStore_read_free_of_ne _ (by intro h; cases h)]
    refine ⟨rfl, ha_4,
      hasPhase2Regs_of_eq hregs (fun idx => hloc_ne1 0 idx (by decide)),
      hloc_ne1,
      by simp [rw_write_eq, rf_free_eq],
      by simp [rw_write_eq, rf_free_eq],
      fun t idx ht6 ht7 => ?_,
      fun idx hrange => ?_⟩
    · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
        wordStore_read_write_of_ne _ (by intro h; cases h)]
      by_cases ht5 : t = 5
      · subst ht5
        by_cases h1 : idx = 1
        · subst h1; exact wordStore_read_free_self _ _
        · rw [wordStore_read_free_of_ne _ (by intro h; injection h with _ hi; exact h1 hi)]
          by_cases h0 : idx = 0
          · subst h0; exact wordStore_read_free_self _ _
          · rw [wordStore_read_free_of_ne _ (by intro h; injection h with _ hi; exact h0 hi)]
            exact hh5 idx h0 h1
      · rw [wordStore_read_free_of_ne _ (by intro h; injection h with ht _; exact ht5 ht),
          wordStore_read_free_of_ne _ (by intro h; injection h with ht _; exact ht5 ht)]
        exact hht t idx ht5 ht6 ht7
    · simp [rw_write_eq, rf_free_eq]
      exact hh67 idx (by simpa [N_tot] using hrange)
  obtain ⟨ws₁, _, hinv_end, ex_loop⟩ := exec_repeatN_inv (countE := .readLocal 1 (.lit 10)) (body := .seq (.freeHeap 6 (.readLocal 1 (.lit 9))) (.seq (.freeHeap 7 (.readLocal 1 (.lit 9))) (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1))))) N_tot Inv
    ha_4 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by simp only [evalVal_readLocal, evalVal_lit, wordStore_read_write_self])
    hinit (U := 220) (B := 210000 * (V + 8) ^ 2)
    (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
    (fun k ws_k bs_k hk ⟨hbs_k, ha_k, hregs_k, hloc_k, hr14_k, hr9_k, hht_k, hh67_k⟩ => by
      subst bs_k
      have hk_lt_A : k < A := by dsimp [N_tot] at hk; omega
      obtain ⟨ha_f6, ex_f6⟩ := exec_freeHeap_auto (t := 6) (idxE := .readLocal 1 (.lit 9)) (idx := (k : ℤ)) ha_k hinp
        (exprInArena_small (by decide) (by decide) hV16) (by decide)
        (by simp only [evalVal_readLocal, evalVal_lit, hr9_k])
        (by decide) (by positivity) (by simpa using hk_lt_A)
      obtain ⟨ha_f7, ex_f7⟩ := exec_freeHeap_auto (t := 7) (idxE := .readLocal 1 (.lit 9)) (idx := (k : ℤ)) ha_f6 hinp
        (exprInArena_small (by decide) (by decide) hV16) (by decide)
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
              hr9_k])
        (by decide) (by positivity) (by simpa using hk_lt_A)
      obtain ⟨ha_inc, ex_inc⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .add (.readLocal 1 (.lit 9)) (.lit 1)) (idx := 9) (val := ((k + 1 : ℕ) : ℤ)) ha_f7 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ rfl
        (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit, hr9_k])
        (by decide) (by omega) (by simp; omega) (idx_V (k + 1) (by omega))
      let ws_next := ((ws_k.free (.heap 6 (k : ℤ))).free (.heap 7 (k : ℤ))).write
        (.localFrame 1 1 9) (((k + 1 : ℕ) : ℤ))
      have hloc_ne1 : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
          ws_next.read (.localFrame 1 v idx) = ws_k.read (.localFrame 1 v idx) := by
        intro v idx hne1
        dsimp [ws_next]
        rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
          wordStore_read_free_of_ne _ (by intro h; cases h),
          wordStore_read_free_of_ne _ (by intro h; cases h)]
      refine ⟨ws_next, bs, ⟨rfl, ha_inc,
        hasPhase2Regs_of_eq hregs_k (fun idx => hloc_ne1 0 idx (by decide)),
        fun v idx hne1 => (hloc_ne1 v idx hne1).trans (hloc_k v idx hne1),
        by dsimp [ws_next]
           rw [wordStore_read_write_of_ne _ (by intro h; simp at h; try omega),
             wordStore_read_free_of_ne _ (by intro h; cases h),
             wordStore_read_free_of_ne _ (by intro h; cases h), hr14_k],
        wordStore_read_write_self _ _ _,
        fun t idx ht6 ht7 => by
          dsimp [ws_next]
          rw [wordStore_read_write_of_ne _ (by intro h; cases h),
            wordStore_read_free_of_ne _ (by intro h; injection h with ht _; exact ht7 ht),
            wordStore_read_free_of_ne _ (by intro h; injection h with ht _; exact ht6 ht)]
          exact hht_k t idx ht6 ht7,
        fun idx hrange => by
          dsimp [ws_next]
          rw [wordStore_read_write_of_ne _ (by intro h; cases h),
            wordStore_read_write_of_ne _ (by intro h; cases h)]
          by_cases heq : idx = (k : ℤ)
          · subst heq
            exact ⟨by rw [wordStore_read_free_of_ne _ (by intro h; simp at h; try omega), wordStore_read_free_self],
                   wordStore_read_free_self _ _⟩
          · refine ⟨?_, ?_⟩
            · rw [wordStore_read_free_of_ne _ (by intro h; simp at h; try omega),
                wordStore_read_free_of_ne _ (by intro h; injection h with _ hi; exact heq hi)]
              exact (hh67_k idx (by omega)).1
            · rw [wordStore_read_free_of_ne _ (by intro h; injection h with _ hi; exact heq hi),
                wordStore_read_free_of_ne _ (by intro h; simp at h; try omega)]
              exact (hh67_k idx (by omega)).2⟩,
        ExecBounded.mono (ExecBounded.seq ex_f6 (ExecBounded.seq ex_f7 ex_inc))
          (by omega) (by omega) le_rfl le_rfl⟩)
  rcases hinv_end with ⟨hbs_end, ha_end, hregs_end, hloc_end, hr14_end, _, hht_end, hh67_end⟩
  rw [hbs_end] at ex_loop
  have hhz_end : HeapAllZero ws₁ := by
    intro t idx
    by_cases ht6 : t = 6
    · subst ht6; exact (hh67_end idx (by omega)).1
    · by_cases ht7 : t = 7
      · subst ht7; exact (hh67_end idx (by omega)).2
      · exact hht_end t idx ht6 ht7
  have ex_tot := ExecBounded.seq ex_1 (ExecBounded.seq ex_2 (ExecBounded.seq ex_3
    (ExecBounded.seq ex_4 ex_loop)))
  have hb_tot :
      66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 +
      (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + N_tot * (210000 * (V + 8) ^ 2))))) ≤
      (500000 + 250000 * N_tot) * (V + 8) ^ 2 := by
    set Y := (V + 8) ^ 2
    have h1 : N_tot * (210000 * Y) ≤ N_tot * (250000 * Y) :=
      Nat.mul_le_mul_left N_tot (Nat.mul_le_mul_right Y (by omega))
    have h2 : (500000 + 250000 * N_tot) * Y = 500000 * Y + N_tot * (250000 * Y) := by ring
    omega
  have hu_tot : 68 + (68 + (68 + (68 + (68 + N_tot * 220)))) ≤ 500 + 250 * (p.D + p.s₀ * p.D) := by dsimp [N_tot]; omega
  exact ⟨ws₁, ha_end, hhz_end, hregs_end, hloc_end, hr14_end,
    ExecBounded.mono ex_tot hu_tot hb_tot le_rfl le_rfl⟩

end UL.Proof_lem_A_2
