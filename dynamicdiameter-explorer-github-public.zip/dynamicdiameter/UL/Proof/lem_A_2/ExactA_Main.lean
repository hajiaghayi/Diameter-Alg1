import Mathlib
import UL.Stmt.lem_A_2
import UL.Stmt.cit_hw87_halfspace_net
import UL.Stmt.cit_gls88_rational_lp
import UL.Stmt.lem_A_1
import UL.Proof.lem_A_2.ExactA_Phase4b
import UL.Proof.lem_A_2.ExactA_Caps
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 4000000

namespace UL.Proof_lem_A_2

/-! ### 1. Exact single-attempt statement, cost caps, and `.localScope` execution -/

def exactAttemptBodyStmt (K₀ deg_α₀ C_z deg_alg k_φ : ℕ)
    (sizeProg prog_A1 progCert : BitRAMStmt) : BitRAMStmt :=
  .seq (phase0Stmt (25 * K₀ ^ 2) (2 * deg_α₀ + 1) C_z deg_alg)
  (.seq phase1Stmt
  (.seq (phase2Stmt k_φ sizeProg)
  (.seq (phase3Stmt k_φ prog_A1)
  (.seq (exactPhase4Stmt K₀ deg_α₀)
  (.seq (phase5Stmt progCert)
        phase6Stmt)))))

def exactRetryMainProg (K₀ deg_α₀ C_z deg_alg k_φ : ℕ)
    (sizeProg prog_A1 progCert : BitRAMStmt) : BitRAMStmt :=
  .whileLoop (.intEq (.readHeap 0 (.lit 0)) (.lit 0))
    (.localScope (exactAttemptBodyStmt K₀ deg_α₀ C_z deg_alg k_φ sizeProg prog_A1 progCert))

def exactAttemptUnitCap (p : CoreParams) (K₀ deg_α₀ M F_sz F_A1 F_c U_sz U_A1 U_cert : ℕ) : ℕ :=
  let s₁ := s₁Val K₀ deg_α₀ p.d
  (32 * (p.w + 1) + 400 * (p.deg_α + p.deg_alg + 16)) +
  (300 + p.m * (1000 + 500 * p.d + 60 * p.B_lift)) +
  (80 * F_sz * (U_sz + 1) + 32 * (Nat.clog 2 (M + 1) + 1) + 1000) +
  (2000 + M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1)) +
    p.D * (1000 + 50 * p.L_z) + 80 * F_A1 * (U_A1 + 1)) +
  (4400 + 200 * deg_α₀ + 12000 * p.m + (2 * s₁) * (300 + 24 * (p.W₂ + 1))) +
  (2000 + 800 * (p.D + p.s₀ * p.D) +
    p.r * (2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (U_cert + 1))) +
  (1500 + 600 * p.D + 800 * p.m)

def exactAttemptBitCap (p : CoreParams)
    (deg_α₀ V M T_sz T_A1 T_c F_sz F_A1 F_c U_sz U_A1 U_cert : ℕ) : ℕ :=
  ((4000000 + 400000 * (p.deg_α + p.deg_alg)) * (V + 8) ^ 2) +
  ((300000 + p.m * (1000000 + 500000 * p.d + 600 * p.B_lift)) * (V + 8) ^ 2) +
  (256 * F_sz * (V + natBitLength T_sz + 8) ^ 2 * (2 * U_sz + 16) * U_sz +
    (U_sz + 2) * (8 * natBitLength (U_sz + 2) + 4 * (U_sz + 2 * natBitLength T_sz + 6) + 80) +
    1000000 * (V + natBitLength T_sz + 16) ^ 2) +
  ((2000000 + M * (1200000 + 600000 * p.d) + p.D * (1000000 + 600 * p.L_z)) *
    (V + natBitLength T_A1 + 16) ^ 2 +
    256 * F_A1 * (V + natBitLength T_A1 + 8) ^ 2 * (2 * U_A1 + 16) * U_A1 +
    (U_A1 + 2) * (8 * natBitLength (U_A1 + 2) + 4 * (U_A1 + 2 * natBitLength T_A1 + 6) + 80)) +
  ((4400000 + 200000 * deg_α₀ + 12500000 * p.m) * (V + 8) ^ 2) +
  ((2000000 + 800000 * (p.D + p.s₀ * p.D)) * (V + natBitLength T_c + 16) ^ 2 +
    p.r * ((2000000 + p.s₀ * (1500000 + 300000 * p.d)) * (V + natBitLength T_c + 16) ^ 2 +
      256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * U_cert + 16) * U_cert +
      (U_cert + 2) * (8 * natBitLength (U_cert + 2) + 4 * (U_cert + 2 * natBitLength T_c + 6) + 80))) +
  ((1500000 + 600000 * p.D + 800000 * p.m) * (V + 8) ^ 2)

theorem exec_localScope_exactAttempt {A V M K₀ deg_α₀ U_sz U_A1 U_cert : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ)
    (sizeProg prog_A1 progCert : BitRAMStmt)
    {sizeOut outA1 : BitRAMExecOutcome} (zRat : Fin p.D → ℚ)
    (outCert : Fin p.r → BitRAMExecOutcome)
    (v : Fin (M * p.W₁ M + (2 * s₁Val K₀ deg_α₀ p.d) * p.W₂) → Bool) (restBits : List Bool)
    {inp : BitRAMInput p.d} {st : BitRAMExecState}
    (hK₀ : 1 ≤ K₀)
    (hpK : p.K = 25 * K₀ ^ 2)
    (hpdeg : p.deg_α = 2 * deg_α₀ + 1)
    (hfd0 : st.frameDepth = 0)
    (harena : InAttemptArena A V st.words)
    (hhz : HeapAllZero st.words)
    (hbits : st.remainingBits = List.ofFn v ++ restBits)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hip_params : inp.intParams = [(p.m : ℤ), (p.B : ℤ)])
    (hip_handles : inp.activeHandles = Finset.range p.m)
    (hip_coords : ∀ h : ℕ, h < p.m → inp.activeRatCoords h = pts_h h)
    (hpts_b : ∀ h : ℕ, h < p.m → RatPointBitBounded p.B (pts_h h))
    (hrun_sz : runBitRAMWithBits sizeProg
      (BitRAMInput.ofIntParams [(p.D : ℤ), (p.B_lift : ℤ), (p.k_φ : ℤ)])
      WordStore.empty [] = some sizeOut)
    (hM_out : sizeOut.words.read (.heap 0 0) = (M : ℤ))
    (hsz_bounds : sizeOut.unitCost ≤ U_sz ∧ sizeOut.bitCost ≤ U_sz ∧
      sizeOut.peakCellSpace ≤ U_sz ∧ sizeOut.peakBitSpace ≤ U_sz)
    (h2_fit : intBitLength ((M + 1 : ℕ) : ℤ) ≤ V ∧
      natBitLength (2 ^ Nat.clog 2 (M + 1)) + 2 ≤ V ∧
      p.w + Nat.clog 2 (M + 1) + 16 ≤ V)
    (h3_fit : 1 ≤ M ∧ M * p.D + 4 ≤ A ∧ p.W₁ M + 4 ≤ V ∧ 2 * p.L_z + 16 ≤ V ∧ U_A1 + 2 ≤ V)
    (h5_fit : p.D + p.s₀ * p.D + 4 ≤ A ∧ U_cert + 2 ≤ V)
    (hrun_A1 :
      let hm_pos : 0 < p.m := by
        have hs1 := s₀Val_pos (deg_α := p.deg_α) hfit.1 p.d
        have hm2 := hfit.2.2.2.1
        dsimp [CoreParams.s₀] at hm2; omega
      let sp := splitAttemptBits M (p.W₁ M) (2 * s₁Val K₀ deg_α₀ p.d) p.W₂ v
      let ω : Fin M → Fin p.m := fun j =>
        ⟨bitsToNat (p.W₁ M) (sp.1 j) % p.m, Nat.mod_lt _ hm_pos⟩
      runBitRAMWithBits prog_A1
        { intParams := [(p.B_lift : ℤ), (p.k_φ : ℤ), (M : ℤ)]
          activeHandles := Finset.range M
          activeRatCoords := fun j =>
            if hj : j < M then liftRatPoint (pts_h (ω ⟨j, hj⟩).1) else fun _ => 0
          extraRats := [] }
        WordStore.empty [] = some outA1)
    (ha1_bounds : outA1.unitCost ≤ U_A1 ∧ outA1.bitCost ≤ U_A1 ∧
      outA1.peakCellSpace ≤ U_A1 ∧ outA1.peakBitSpace ≤ U_A1)
    (hz_out : ∀ c : Fin p.D,
      let zNum := outA1.words.read (.heap 1 (2 * (c.1 : ℤ)))
      let zDen := outA1.words.read (.heap 1 (2 * (c.1 : ℤ) + 1))
      0 < zDen ∧ zRat c = (zNum : ℚ) / (zDen : ℚ) ∧
      intBitLength zNum ≤ p.L_z ∧ intBitLength zDen ≤ p.L_z)
    (hrun_cert :
      let hs₁_2 : 2 ≤ s₁Val K₀ deg_α₀ p.d := by have := s₁Val_ge_144 (deg_α := deg_α₀) hK₀ p.d; omega
      let hs₀_ge : 64 * (s₁Val K₀ deg_α₀ p.d) ^ 2 ≤ p.s₀ := by
        dsimp [CoreParams.s₀]; rw [hpK, hpdeg]; exact sixtyFour_s₁Val_sq_le_s₀Val hK₀ p.d
      let sp := splitAttemptBits M (p.W₁ M) (2 * s₁Val K₀ deg_α₀ p.d) p.W₂ v
      let π := permOfPolyBits hs₁_2 hs₀_ge hfit.2.2.2.1 sp.2
      ∀ b : Fin p.r,
        runBitRAMWithBits progCert (certBlockInp p pts_h zRat π b)
          WordStore.empty [] = some (outCert b))
    (hcert_bounds : ∀ b : Fin p.r,
      (outCert b).unitCost ≤ U_cert ∧ (outCert b).bitCost ≤ U_cert ∧
      (outCert b).peakCellSpace ≤ U_cert ∧ (outCert b).peakBitSpace ≤ U_cert) :
    let T_sz := maxTableStmtFull sizeProg
    let T_A1 := maxTableStmtFull prog_A1
    let T_c := maxTableStmtFull progCert
    let F_sz := stmtFactor sizeProg
    let F_A1 := stmtFactor prog_A1
    let F_c := stmtFactor progCert
    let hs₁_2 : 2 ≤ s₁Val K₀ deg_α₀ p.d := by have := s₁Val_ge_144 (deg_α := deg_α₀) hK₀ p.d; omega
    let hs₀_ge : 64 * (s₁Val K₀ deg_α₀ p.d) ^ 2 ≤ p.s₀ := by
      dsimp [CoreParams.s₀]; rw [hpK, hpdeg]; exact sixtyFour_s₁Val_sq_le_s₀Val hK₀ p.d
    let sp := splitAttemptBits M (p.W₁ M) (2 * s₁Val K₀ deg_α₀ p.d) p.W₂ v
    let π := permOfPolyBits hs₁_2 hs₀_ge hfit.2.2.2.1 sp.2
    let passBool : Fin p.r → Bool := fun b => decide ((outCert b).words.read (.heap 0 0) = 1)
    let L_pass : List (Fin p.r) := (List.finRange p.r).filter passBool
    ∃ st' : BitRAMExecState,
      RunsTo inp
        [.stmt (.localScope (exactAttemptBodyStmt K₀ deg_α₀ p.C_z p.deg_alg p.k_φ sizeProg prog_A1 progCert))]
        st st' ∧
      st'.frameDepth = 0 ∧
      st'.remainingBits = restBits ∧
      InAttemptArena A V st'.words ∧
      st'.unitCost ≤ st.unitCost + exactAttemptUnitCap p K₀ deg_α₀ M F_sz F_A1 F_c U_sz U_A1 U_cert ∧
      st'.bitCost ≤ st.bitCost + exactAttemptBitCap p deg_α₀ V M T_sz T_A1 T_c F_sz F_A1 F_c U_sz U_A1 U_cert ∧
      st'.peakCellSpace ≤ max st.peakCellSpace (attemptCellCap inp A U_sz U_A1 U_cert) ∧
      st'.peakBitSpace ≤ max st.peakBitSpace (attemptBitSpaceCap inp A V T_sz T_A1 T_c U_sz U_A1 U_cert) ∧
      (if p.r ≤ 2 * L_pass.length then
        st'.words.read (.heap 0 0) = (L_pass.length : ℤ) ∧
        (∀ c : Fin p.D,
          st'.words.read (.heap 1 (2 * (c.1 : ℤ))) = (zRat c).num ∧
          st'.words.read (.heap 1 (2 * (c.1 : ℤ) + 1)) = ((zRat c).den : ℤ)) ∧
        (∀ (i : ℕ) (hi : i < L_pass.length) (j : Fin p.s₀),
          let flatIdx : ℤ := ((i * p.s₀ + j.1 : ℕ) : ℤ)
          st'.words.read (.heap 2 flatIdx) = ((blkHandle p π L_pass[i] j).1 : ℤ) ∧
          st'.words.read (.heap 3 (2 * flatIdx)) =
            (outCert L_pass[i]).words.read (.heap 1 (2 * (j.1 : ℤ))) ∧
          st'.words.read (.heap 3 (2 * flatIdx + 1)) =
            (outCert L_pass[i]).words.read (.heap 1 (2 * (j.1 : ℤ) + 1)))
      else
        HeapAllZero st'.words) := by
  intro T_sz T_A1 T_c F_sz F_A1 F_c hs₁_2 hs₀_ge sp π passBool L_pass
  let C_tot := attemptCellCap inp A U_sz U_A1 U_cert
  let S_tot := attemptBitSpaceCap inp A V T_sz T_A1 T_c U_sz U_A1 U_cert
  let ws₀ := st.words.popDepth 0
  have ha₀ : InAttemptArena A V ws₀ := inAttemptArena_popDepth_zero harena
  have hhz₀ : HeapAllZero ws₀ := heapAllZero_popDepth_zero hhz
  let bs₀ := blockBitStream sp.1 (blockBitStream sp.2 restBits 0) 0
  have hbs_eq : st.remainingBits = bs₀ :=
    hbits.trans (splitAttemptBits_stream v restBits)
  obtain ⟨ws₁, ha₁, hhz₁, hregs₁, ex₀⟩ := exec_phase0Stmt p ha₀ hhz₀ hinp hfit hip_params (bs := bs₀)
  rw [hpK, hpdeg] at ex₀
  obtain ⟨ws₂, ha₂, hhz₂, hregs₂, hlifts₂, ex₁⟩ :=
    exec_phase1Stmt p pts_h ha₁ hhz₁ hregs₁ hinp hfit hpts_b hip_handles hip_coords (bs := bs₀)
  obtain ⟨ws₃, ha₃, hhz₃, hregs₃, hlifts₃, ex₂⟩ :=
    exec_phase2Stmt p pts_h sizeProg ha₂ hhz₂ hregs₂ hlifts₂ hinp hfit
      hrun_sz hM_out hsz_bounds h2_fit (bs := bs₀)
  obtain ⟨ws₄, ha₄, hhz₄, hregs₄, hlifts₄, hz₄, ex₃⟩ :=
    exec_phase3Stmt p pts_h prog_A1 zRat sp.1 (blockBitStream sp.2 restBits 0)
      ha₃ hhz₃ hregs₃ hlifts₃ hinp hfit hpts_b hip_handles hip_coords h3_fit
      hrun_A1 ha1_bounds hz_out
  obtain ⟨ws₅, ha₅, hhz₅, hregs₅, hlifts₅, hz₅, hperm₅, ex₄⟩ :=
    exec_exactPhase4Stmt p pts_h zRat sp.2 restBits hK₀ hpK hpdeg ha₄ hhz₄ hregs₄ hlifts₄ hz₄ hinp hfit
  have hz_V : ∀ c : Fin p.D,
      intBitLength (zRat c).num ≤ V ∧ intBitLength (((zRat c).den : ℤ) - 1) ≤ V :=
    hz_V_of_hasZArray ha₅ (by have := hinp.2.1; omega) hz₅
  obtain ⟨ws₆, ha₆, hhz₆, hregs₆, hz₆, hk_pass, hpass_data, ex₅⟩ :=
    exec_phase5Stmt p pts_h zRat π progCert outCert
      ha₅ hhz₅ hregs₅ hlifts₅ hz₅ hperm₅ hinp hfit hpts_b hip_handles hip_coords
      hz_V h5_fit hrun_cert hcert_bounds (bs := restBits)
  have hlen_le : L_pass.length ≤ p.r :=
    (List.length_filter_le passBool (List.finRange p.r)).trans (by simp [List.length_finRange])
  obtain ⟨ws₇, ha₇, hout₆, ex₆⟩ :=
    exec_phase6Stmt p zRat π outCert L_pass
      ha₆ hhz₆ hregs₆ hz₆ hinp hfit hlen_le hk_pass hpass_data (bs := restBits)
  have ex₀' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₀ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₁' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₁ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₂' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₂ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₃' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₃ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₄' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₄ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₅' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₅ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₆' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₆ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex_body := ExecBounded.seq ex₀'
    (ExecBounded.seq ex₁'
      (ExecBounded.seq ex₂'
        (ExecBounded.seq ex₃'
          (ExecBounded.seq ex₄'
            (ExecBounded.seq ex₅' ex₆')))))
  let stEnter : BitRAMExecState :=
    { st with words := st.words.popDepth st.frameDepth, frameDepth := st.frameDepth + 1 }
  have hfd_en : stEnter.frameDepth = 1 := by dsimp [stEnter]; omega
  have hws_en : stEnter.words = ws₀ := by dsimp [stEnter, ws₀]; rw [hfd0]
  obtain ⟨stBody, hr_body, hws_b, _, hbs_b, hu_b, hb_b, hpc_b, hpb_b⟩ :=
    ex_body stEnter hws_en hfd_en hbs_eq
  have hr_scope := RunsTo.localScope hr_body
  set st' : BitRAMExecState :=
    { stBody with words := stBody.words.popDepth st.frameDepth, frameDepth := st.frameDepth }
  have hws_st' : st'.words = ws₇.popDepth 0 := by
    dsimp [st']; rw [hws_b, hfd0]
  refine ⟨st', hr_scope, hfd0, hbs_b, hws_st' ▸ inAttemptArena_popDepth_zero ha₇,
    ?_, ?_, hpc_b, hpb_b, ?_⟩
  · have hu0 : stEnter.unitCost = st.unitCost := rfl
    have hu1 : st'.unitCost = stBody.unitCost := rfl
    dsimp [exactAttemptUnitCap, F_sz, F_A1, F_c]
    omega
  · have hb0 : stEnter.bitCost = st.bitCost := rfl
    have hb1 : st'.bitCost = stBody.bitCost := rfl
    dsimp [exactAttemptBitCap, F_sz, F_A1, F_c, T_sz, T_A1, T_c]
    rw [hpdeg]
    omega
  · by_cases hp : p.r ≤ 2 * L_pass.length
    · rw [if_pos hp] at hout₆ ⊢
      rcases hout₆ with ⟨hr0, hr1, hr23⟩
      refine ⟨(hws_st' ▸ popDepth_zero_read_heap ws₇ 0 0).trans hr0, ?_, ?_⟩
      · intro c
        exact ⟨(hws_st' ▸ popDepth_zero_read_heap ws₇ 1 _).trans (hr1 c).1,
               (hws_st' ▸ popDepth_zero_read_heap ws₇ 1 _).trans (hr1 c).2⟩
      · intro i hi j
        obtain ⟨h2, h30, h31⟩ := hr23 i hi j
        exact ⟨(hws_st' ▸ popDepth_zero_read_heap ws₇ 2 _).trans h2,
               (hws_st' ▸ popDepth_zero_read_heap ws₇ 3 _).trans h30,
               (hws_st' ▸ popDepth_zero_read_heap ws₇ 3 _).trans h31⟩
    · rw [if_neg hp] at hout₆ ⊢
      rw [hws_st']
      exact heapAllZero_popDepth_zero hout₆

/-! ### 2. `w`-free unit-time polynomial `exactTimeCapNat` and `IsNatPoly2` -/

def s1Fn (K₀ deg_α₀ d _B : ℕ) : ℕ := s₁Val K₀ deg_α₀ d

theorem isNatPoly2_s1Fn (K₀ deg_α₀ : ℕ) : IsNatPoly2 (s1Fn K₀ deg_α₀) :=
  natPoly2_mul (natPoly2_const (72 * K₀ ^ 3))
    (natPoly2_pow (natPoly2_add natPoly2_d (natPoly2_const 2)) (2 * deg_α₀ + 1))

def exactTimeCapNat (K₀ deg_α₀ C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c d B : ℕ) : ℕ :=
  let K := 25 * K₀ ^ 2
  let deg_α := 2 * deg_α₀ + 1
  let S1 := s1Fn K₀ deg_α₀ d B
  let S0 := s0Fn K deg_α d B
  let BL := bLiftFn d B
  let LZ := lzFn C_z deg_alg d B
  let UC := ucertFn K deg_α C_z deg_alg C_cert deg_cert d B
  let VC := vCoefNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c d B
  let U_poly : ℕ :=
    (96 + 400 * (deg_α + deg_alg + 16)) +
    (300 + (1000 + 500 * d + 60 * BL)) +
    (80 * F_sz * (LZ + 1) + 32 * (LZ + 2) + 1000) +
    (2000 + LZ * (1200 + 600 * d + 24 * (LZ + 12)) +
      (d + 1) * (1000 + 50 * LZ) + 80 * F_A1 * (LZ + 1)) +
    (16400 + 200 * deg_α₀ + 1128 * S1) +
    (2000 + 800 * ((d + 1) + S0 * (d + 1)) +
      (2000 + S0 * (1500 + 300 * d) + 80 * F_c * (UC + 1))) +
    (1500 + 600 * (d + 1) + 800) + 32
  let B_sq_coef : ℕ :=
    (4000000 + 400000 * (deg_α + deg_alg)) +
    (300000 + (1000000 + 500000 * d + 600 * BL)) +
    (256 * F_sz * (2 * LZ + 16) * LZ + 1000000) +
    (2000000 + LZ * (1200000 + 600000 * d) + (d + 1) * (1000000 + 600 * LZ) +
      256 * F_A1 * (2 * LZ + 16) * LZ) +
    (4400000 + 200000 * deg_α₀ + 12500000) +
    (2000000 + 800000 * ((d + 1) + S0 * (d + 1)) +
      2000000 + S0 * (1500000 + 300000 * d) + 256 * F_c * (2 * UC + 16) * UC) +
    (1500000 + 600000 * (d + 1) + 800000) + 32
  let B_extra : ℕ :=
    (LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_sz + 6) + 80) +
    (LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_A1 + 6) + 80) +
    (UC + 2) * (8 * (UC + 3) + 4 * (UC + 2 * natBitLength T_c + 6) + 80) + 32
  4 * U_poly + 4 * (B_sq_coef * (VC ^ 2) + B_extra)

theorem isNatPoly2_exactTimeCapNat
    (K₀ deg_α₀ C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c : ℕ) :
    IsNatPoly2 (exactTimeCapNat K₀ deg_α₀ C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c) := by
  let K := 25 * K₀ ^ 2
  let deg_α := 2 * deg_α₀ + 1
  have hS1 := isNatPoly2_s1Fn K₀ deg_α₀
  have hS0 := isNatPoly2_s0Fn K deg_α
  have hBL := isNatPoly2_bLiftFn
  have hLZ := isNatPoly2_lzFn C_z deg_alg
  have hUC := isNatPoly2_ucertFn K deg_α C_z deg_alg C_cert deg_cert
  have hVC : IsNatPoly2 (vCoefNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c) := by
    unfold vCoefNat
    exact natPoly2_add
      (natPoly2_add
        (natPoly2_add
          (natPoly2_add
            (natPoly2_add (natPoly2_const 4) (isNatPoly2_qvFn K deg_α C_z deg_alg k_φ C_cert deg_cert))
            (natPoly2_const (natBitLength T_sz)))
          (natPoly2_const (natBitLength T_A1)))
        (natPoly2_const (natBitLength T_c)))
      (natPoly2_const 24)
  have hd1 := natPoly2_add natPoly2_d (natPoly2_const 1)
  have hUp : IsNatPoly2 (fun d B =>
      (96 + 400 * (deg_α + deg_alg + 16)) +
      (300 + (1000 + 500 * d + 60 * bLiftFn d B)) +
      (80 * F_sz * (lzFn C_z deg_alg d B + 1) + 32 * (lzFn C_z deg_alg d B + 2) + 1000) +
      (2000 + lzFn C_z deg_alg d B * (1200 + 600 * d + 24 * (lzFn C_z deg_alg d B + 12)) +
        (d + 1) * (1000 + 50 * lzFn C_z deg_alg d B) + 80 * F_A1 * (lzFn C_z deg_alg d B + 1)) +
      (16400 + 200 * deg_α₀ + 1128 * s1Fn K₀ deg_α₀ d B) +
      (2000 + 800 * ((d + 1) + s0Fn K deg_α d B * (d + 1)) +
        (2000 + s0Fn K deg_α d B * (1500 + 300 * d) +
          80 * F_c * (ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 1))) +
      (1500 + 600 * (d + 1) + 800) + 32) := by
    have p0 := natPoly2_const ((96 + 400 * (deg_α + deg_alg + 16)))
    have p1 := natPoly2_add (natPoly2_const 300)
      (natPoly2_add (natPoly2_add (natPoly2_const 1000) (natPoly2_mul (natPoly2_const 500) natPoly2_d))
        (natPoly2_mul (natPoly2_const 60) hBL))
    have p2 := natPoly2_add
      (natPoly2_add (natPoly2_mul (natPoly2_const (80 * F_sz)) (natPoly2_add hLZ (natPoly2_const 1)))
        (natPoly2_mul (natPoly2_const 32) (natPoly2_add hLZ (natPoly2_const 2))))
      (natPoly2_const 1000)
    have p3 := natPoly2_add
      (natPoly2_add
        (natPoly2_add (natPoly2_const 2000)
          (natPoly2_mul hLZ
            (natPoly2_add (natPoly2_add (natPoly2_const 1200) (natPoly2_mul (natPoly2_const 600) natPoly2_d))
              (natPoly2_mul (natPoly2_const 24) (natPoly2_add hLZ (natPoly2_const 12))))))
        (natPoly2_mul hd1 (natPoly2_add (natPoly2_const 1000) (natPoly2_mul (natPoly2_const 50) hLZ))))
      (natPoly2_mul (natPoly2_const (80 * F_A1)) (natPoly2_add hLZ (natPoly2_const 1)))
    have p4 := natPoly2_add (natPoly2_const (16400 + 200 * deg_α₀))
      (natPoly2_mul (natPoly2_const 1128) hS1)
    have p5 := natPoly2_add
      (natPoly2_add (natPoly2_const 2000)
        (natPoly2_mul (natPoly2_const 800) (natPoly2_add hd1 (natPoly2_mul hS0 hd1))))
      (natPoly2_add
        (natPoly2_add (natPoly2_const 2000)
          (natPoly2_mul hS0 (natPoly2_add (natPoly2_const 1500) (natPoly2_mul (natPoly2_const 300) natPoly2_d))))
        (natPoly2_mul (natPoly2_const (80 * F_c)) (natPoly2_add hUC (natPoly2_const 1))))
    have p6 := natPoly2_add (natPoly2_add (natPoly2_const 1500) (natPoly2_mul (natPoly2_const 600) hd1))
      (natPoly2_const 800)
    exact natPoly2_add
      (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add p0 p1) p2) p3) p4) p5) p6)
      (natPoly2_const 32)
  have hBsq : IsNatPoly2 (fun d B =>
      (4000000 + 400000 * (deg_α + deg_alg)) +
      (300000 + (1000000 + 500000 * d + 600 * bLiftFn d B)) +
      (256 * F_sz * (2 * lzFn C_z deg_alg d B + 16) * lzFn C_z deg_alg d B + 1000000) +
      (2000000 + lzFn C_z deg_alg d B * (1200000 + 600000 * d) +
        (d + 1) * (1000000 + 600 * lzFn C_z deg_alg d B) +
        256 * F_A1 * (2 * lzFn C_z deg_alg d B + 16) * lzFn C_z deg_alg d B) +
      (4400000 + 200000 * deg_α₀ + 12500000) +
      (2000000 + 800000 * ((d + 1) + s0Fn K deg_α d B * (d + 1)) +
        2000000 + s0Fn K deg_α d B * (1500000 + 300000 * d) +
        256 * F_c * (2 * ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 16) *
          ucertFn K deg_α C_z deg_alg C_cert deg_cert d B) +
      (1500000 + 600000 * (d + 1) + 800000) + 32) := by
    have b0 := natPoly2_const (4000000 + 400000 * (deg_α + deg_alg))
    have b1 := natPoly2_add (natPoly2_const 300000)
      (natPoly2_add (natPoly2_add (natPoly2_const 1000000) (natPoly2_mul (natPoly2_const 500000) natPoly2_d))
        (natPoly2_mul (natPoly2_const 600) hBL))
    have b2 := natPoly2_add
      (natPoly2_mul
        (natPoly2_mul (natPoly2_const (256 * F_sz))
          (natPoly2_add (natPoly2_mul (natPoly2_const 2) hLZ) (natPoly2_const 16)))
        hLZ)
      (natPoly2_const 1000000)
    have b3 := natPoly2_add
      (natPoly2_add
        (natPoly2_add (natPoly2_const 2000000)
          (natPoly2_mul hLZ (natPoly2_add (natPoly2_const 1200000) (natPoly2_mul (natPoly2_const 600000) natPoly2_d))))
        (natPoly2_mul hd1 (natPoly2_add (natPoly2_const 1000000) (natPoly2_mul (natPoly2_const 600) hLZ))))
      (natPoly2_mul
        (natPoly2_mul (natPoly2_const (256 * F_A1))
          (natPoly2_add (natPoly2_mul (natPoly2_const 2) hLZ) (natPoly2_const 16)))
        hLZ)
    have b4 := natPoly2_const (4400000 + 200000 * deg_α₀ + 12500000)
    have b5 := natPoly2_add
      (natPoly2_add
        (natPoly2_add
          (natPoly2_add (natPoly2_const 2000000)
            (natPoly2_mul (natPoly2_const 800000) (natPoly2_add hd1 (natPoly2_mul hS0 hd1))))
          (natPoly2_const 2000000))
        (natPoly2_mul hS0 (natPoly2_add (natPoly2_const 1500000) (natPoly2_mul (natPoly2_const 300000) natPoly2_d))))
      (natPoly2_mul
        (natPoly2_mul (natPoly2_const (256 * F_c))
          (natPoly2_add (natPoly2_mul (natPoly2_const 2) hUC) (natPoly2_const 16)))
        hUC)
    have b6 := natPoly2_add (natPoly2_add (natPoly2_const 1500000) (natPoly2_mul (natPoly2_const 600000) hd1))
      (natPoly2_const 800000)
    exact natPoly2_add
      (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add (natPoly2_add b0 b1) b2) b3) b4) b5) b6)
      (natPoly2_const 32)
  have hBex : IsNatPoly2 (fun d B =>
      (lzFn C_z deg_alg d B + 2) *
        (8 * (lzFn C_z deg_alg d B + 3) + 4 * (lzFn C_z deg_alg d B + 2 * natBitLength T_sz + 6) + 80) +
      (lzFn C_z deg_alg d B + 2) *
        (8 * (lzFn C_z deg_alg d B + 3) + 4 * (lzFn C_z deg_alg d B + 2 * natBitLength T_A1 + 6) + 80) +
      (ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 2) *
        (8 * (ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 3) +
          4 * (ucertFn K deg_α C_z deg_alg C_cert deg_cert d B + 2 * natBitLength T_c + 6) + 80) + 32) := by
    have mkEx := fun {U : ℕ → ℕ → ℕ} (hU : IsNatPoly2 U) (T : ℕ) =>
      natPoly2_mul (natPoly2_add hU (natPoly2_const 2))
        (natPoly2_add
          (natPoly2_add (natPoly2_mul (natPoly2_const 8) (natPoly2_add hU (natPoly2_const 3)))
            (natPoly2_mul (natPoly2_const 4) (natPoly2_add hU (natPoly2_const (2 * natBitLength T + 6)))))
          (natPoly2_const 80))
    exact natPoly2_add
      (natPoly2_add (natPoly2_add (mkEx hLZ T_sz) (mkEx hLZ T_A1)) (mkEx hUC T_c))
      (natPoly2_const 32)
  exact natPoly2_add
    (natPoly2_mul (natPoly2_const 4) hUp)
    (natPoly2_mul (natPoly2_const 4)
      (natPoly2_add (natPoly2_mul hBsq (natPoly2_pow hVC 2)) hBex))

theorem exact_time_caps_le (p : CoreParams)
    {K₀ deg_α₀ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c M : ℕ}
    (hK₀ : 1 ≤ K₀)
    (hpK : p.K = 25 * K₀ ^ 2)
    (hpdeg : p.deg_α = 2 * deg_α₀ + 1)
    (hB1 : 1 ≤ p.B) (hm2s : 2 * p.s₀ ≤ p.m)
    (hMLz : M ≤ p.L_z) :
    let QV := qvFn p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert p.d p.B
    let LZ := lzFn p.C_z p.deg_alg p.d p.B
    let UC := ucertFn p.K p.deg_α p.C_z p.deg_alg C_cert deg_cert p.d p.B
    let V := 4 * p.w + QV
    4 * (exactAttemptUnitCap p K₀ deg_α₀ M F_sz F_A1 F_c LZ LZ UC + 16) ≤
      p.m * exactTimeCapNat K₀ deg_α₀ p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c p.d p.B ∧
    4 * (exactAttemptBitCap p deg_α₀ V M T_sz T_A1 T_c F_sz F_A1 F_c LZ LZ UC + 4 * V + 16) ≤
      p.m * p.w ^ 2 * exactTimeCapNat K₀ deg_α₀ p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c p.d p.B := by
  intro QV LZ UC V
  have hK1 : 1 ≤ p.K := by rw [hpK]; nlinarith
  have hs0_pos : 1 ≤ p.s₀ := s₀Val_pos hK1 p.d
  have hm2 : 2 ≤ p.m := by omega
  have hm1 : 1 ≤ p.m := by omega
  have hw2 : 2 ≤ p.w := two_le_clog2_of_four_le (by omega)
  have hw1 : 1 ≤ p.w := by omega
  have hw_le_2m : p.w ≤ 2 * p.m := clog2_le_self (2 * p.m)
  have hLz_eq : p.L_z = LZ := rfl
  have hs0_eq : p.s₀ = s0Fn p.K p.deg_α p.d p.B := rfl
  have hBl_eq : p.B_lift = bLiftFn p.d p.B := rfl
  have hD_eq : p.D = p.d + 1 := rfl
  have hr_le_m : p.r ≤ p.m := Nat.div_le_self p.m p.s₀
  have hclog_M1 : Nat.clog 2 (M + 1) ≤ LZ + 1 :=
    (clog2_le_self (M + 1)).trans (by omega)
  let s₁ := s₁Val K₀ deg_α₀ p.d
  have hs1_eq : s₁ = s1Fn K₀ deg_α₀ p.d p.B := rfl
  -- 1. `w`-free unit cost cap: `4 * (U_att + 16) ≤ p.m * exactTimeCapNat ...`
  have hunit_tot :
      4 * (exactAttemptUnitCap p K₀ deg_α₀ M F_sz F_A1 F_c LZ LZ UC + 16) ≤
      p.m * exactTimeCapNat K₀ deg_α₀ p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c p.d p.B := by
    have le_m : ∀ {X : ℕ}, X ≤ p.m * X := fun {X} => Nat.le_mul_of_pos_left X hm1
    have u0 : 32 * (p.w + 1) + 400 * (p.deg_α + p.deg_alg + 16) ≤
        p.m * (96 + 400 * (p.deg_α + p.deg_alg + 16)) := by
      have ha : 32 * (p.w + 1) ≤ p.m * 96 := by omega
      have hb := le_m (X := 400 * (p.deg_α + p.deg_alg + 16))
      linarith
    have u1 : 300 + p.m * (1000 + 500 * p.d + 60 * p.B_lift) ≤
        p.m * (300 + (1000 + 500 * p.d + 60 * p.B_lift)) := by
      have ha := le_m (X := 300)
      linarith
    have u2 : 80 * F_sz * (LZ + 1) + 32 * (Nat.clog 2 (M + 1) + 1) + 1000 ≤
        p.m * (80 * F_sz * (LZ + 1) + 32 * (LZ + 2) + 1000) := by
      have h1 : 80 * F_sz * (LZ + 1) + 32 * (Nat.clog 2 (M + 1) + 1) + 1000 ≤
          80 * F_sz * (LZ + 1) + 32 * (LZ + 2) + 1000 := by omega
      exact h1.trans le_m
    have u3 : 2000 + M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1)) +
        p.D * (1000 + 50 * p.L_z) + 80 * F_A1 * (LZ + 1) ≤
        p.m * (2000 + LZ * (1200 + 600 * p.d + 24 * (LZ + 12)) +
          (p.d + 1) * (1000 + 50 * LZ) + 80 * F_A1 * (LZ + 1)) := by
      have hw1_le : p.W₁ M + 1 ≤ p.m * (LZ + 12) := by
        dsimp [CoreParams.W₁]
        have h_c : Nat.clog 2 (M + 1) + 9 ≤ p.m * (LZ + 10) :=
          (by omega : Nat.clog 2 (M + 1) + 9 ≤ LZ + 10).trans le_m
        linarith
      have h_in : 1200 + 600 * p.d + 24 * (p.W₁ M + 1) ≤
          p.m * (1200 + 600 * p.d + 24 * (LZ + 12)) := by
        have h_base := le_m (X := 1200 + 600 * p.d)
        linarith
      have hM_term : M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1)) ≤
          p.m * (LZ * (1200 + 600 * p.d + 24 * (LZ + 12))) := by
        calc M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1))
            ≤ LZ * (p.m * (1200 + 600 * p.d + 24 * (LZ + 12))) := Nat.mul_le_mul hMLz h_in
          _ = p.m * (LZ * (1200 + 600 * p.d + 24 * (LZ + 12))) := by ring
      have h_rest := le_m (X := 2000 + (p.d + 1) * (1000 + 50 * LZ) + 80 * F_A1 * (LZ + 1))
      rw [hD_eq, hLz_eq]
      linarith
    have u4 : 4400 + 200 * deg_α₀ + 12000 * p.m + (2 * s₁) * (300 + 24 * (p.W₂ + 1)) ≤
        p.m * (16400 + 200 * deg_α₀ + 1128 * s₁) := by
      have hw2_le : p.W₂ + 1 ≤ 11 * p.m := by dsimp [CoreParams.W₂]; omega
      have h_in : 300 + 24 * (p.W₂ + 1) ≤ 564 * p.m := by omega
      have h_draw : (2 * s₁) * (300 + 24 * (p.W₂ + 1)) ≤ p.m * (1128 * s₁) := by
        calc (2 * s₁) * (300 + 24 * (p.W₂ + 1))
            ≤ (2 * s₁) * (564 * p.m) := Nat.mul_le_mul_left _ h_in
          _ = p.m * (1128 * s₁) := by ring
      have h_base : 4400 + 200 * deg_α₀ + 12000 * p.m ≤ p.m * (16400 + 200 * deg_α₀) := by
        have := le_m (X := 4400 + 200 * deg_α₀)
        linarith
      linarith
    have u5 : 2000 + 800 * (p.D + p.s₀ * p.D) +
        p.r * (2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (UC + 1)) ≤
        p.m * (2000 + 800 * ((p.d + 1) + p.s₀ * (p.d + 1)) +
          (2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (UC + 1))) := by
      rw [hD_eq]
      have ha := le_m (X := 2000 + 800 * ((p.d + 1) + p.s₀ * (p.d + 1)))
      have hb := Nat.mul_le_mul_right (2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (UC + 1)) hr_le_m
      linarith
    have u6 : (1500 + 600 * p.D + 800 * p.m) + 16 ≤
        p.m * ((1500 + 600 * (p.d + 1) + 800) + 32) := by
      rw [hD_eq]
      have ha := le_m (X := 1500 + 600 * (p.d + 1) + 32)
      linarith
    let Up := (96 + 400 * (p.deg_α + p.deg_alg + 16)) +
      (300 + (1000 + 500 * p.d + 60 * p.B_lift)) +
      (80 * F_sz * (LZ + 1) + 32 * (LZ + 2) + 1000) +
      (2000 + LZ * (1200 + 600 * p.d + 24 * (LZ + 12)) +
        (p.d + 1) * (1000 + 50 * LZ) + 80 * F_A1 * (LZ + 1)) +
      (16400 + 200 * deg_α₀ + 1128 * s₁) +
      (2000 + 800 * ((p.d + 1) + p.s₀ * (p.d + 1)) +
        (2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (UC + 1))) +
      (1500 + 600 * (p.d + 1) + 800) + 32
    have hsum_u : exactAttemptUnitCap p K₀ deg_α₀ M F_sz F_A1 F_c LZ LZ UC + 16 ≤ p.m * Up := by
      unfold exactAttemptUnitCap
      dsimp only [s₁, Up] at u4 ⊢
      linarith
    unfold exactTimeCapNat
    dsimp only
    rw [← hpK, ← hpdeg, ← hs1_eq, ← hs0_eq, ← hBl_eq]
    calc 4 * (exactAttemptUnitCap p K₀ deg_α₀ M F_sz F_A1 F_c LZ LZ UC + 16)
        ≤ 4 * (p.m * Up) := Nat.mul_le_mul_left 4 hsum_u
      _ = p.m * (4 * Up) := by ring
      _ ≤ p.m * _ := Nat.mul_le_mul_left p.m (Nat.le_add_right (4 * Up) _)
  -- 2. Bit cost cap: `4 * (B_att + 4 * V + 16) ≤ p.m * p.w ^ 2 * exactTimeCapNat ...`
  have hbitc_tot :
      4 * (exactAttemptBitCap p deg_α₀ V M T_sz T_A1 T_c F_sz F_A1 F_c LZ LZ UC + 4 * V + 16) ≤
      p.m * p.w ^ 2 * exactTimeCapNat K₀ deg_α₀ p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c p.d p.B := by
    let VC := vCoefNat p.K p.deg_α p.C_z p.deg_alg p.k_φ C_cert deg_cert T_sz T_A1 T_c p.d p.B
    have hv_le : ∀ extra : ℕ, extra ≤ natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 20 →
        (V + extra) ^ 2 ≤ p.w ^ 2 * VC ^ 2 := by
      intro extra hex
      have hlin : V + extra ≤ p.w * VC := by
        have h1 : V + extra ≤ 4 * p.w + (QV + natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 24) := by
          dsimp [V]; omega
        have h2 : QV + natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 24 ≤
            p.w * (QV + natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 24) :=
          Nat.le_mul_of_pos_left _ hw1
        calc V + extra ≤ 4 * p.w + p.w * (QV + natBitLength T_sz + natBitLength T_A1 + natBitLength T_c + 24) := by omega
          _ = p.w * VC := by dsimp [VC, vCoefNat, QV]; ring
      calc (V + extra) ^ 2 ≤ (p.w * VC) ^ 2 := Nat.pow_le_pow_left hlin 2
        _ = p.w ^ 2 * VC ^ 2 := by ring
    have hv8 := hv_le 8 (by omega)
    have hv_sz8 := hv_le (natBitLength T_sz + 8) (by omega)
    have hv_sz16 := hv_le (natBitLength T_sz + 16) (by omega)
    have hv_a1_8 := hv_le (natBitLength T_A1 + 8) (by omega)
    have hv_a1_16 := hv_le (natBitLength T_A1 + 16) (by omega)
    have hv_c8 := hv_le (natBitLength T_c + 8) (by omega)
    have hv_c16 := hv_le (natBitLength T_c + 16) (by omega)
    have h_m_sq : ∀ {C_m Y : ℕ}, Y ≤ p.w ^ 2 * VC ^ 2 →
        (p.m * C_m) * Y ≤ p.m * p.w ^ 2 * (C_m * VC ^ 2) := fun {C_m Y} hY =>
      calc (p.m * C_m) * Y ≤ (p.m * C_m) * (p.w ^ 2 * VC ^ 2) := Nat.mul_le_mul_left _ hY
        _ = p.m * p.w ^ 2 * (C_m * VC ^ 2) := by ring
    have h_1_sq : ∀ {C_1 Y : ℕ}, Y ≤ p.w ^ 2 * VC ^ 2 →
        C_1 * Y ≤ p.m * p.w ^ 2 * (C_1 * VC ^ 2) := fun {C_1 Y} hY =>
      calc C_1 * Y ≤ C_1 * (p.w ^ 2 * VC ^ 2) := Nat.mul_le_mul_left _ hY
        _ ≤ p.m * (C_1 * (p.w ^ 2 * VC ^ 2)) := Nat.le_mul_of_pos_left _ hm1
        _ = p.m * p.w ^ 2 * (C_1 * VC ^ 2) := by ring
    have hb0 := h_1_sq (C_1 := 4000000 + 400000 * (p.deg_α + p.deg_alg)) hv8
    have hb1 : (300000 + p.m * (1000000 + 500000 * p.d + 600 * p.B_lift)) * (V + 8) ^ 2 ≤
        p.m * p.w ^ 2 * ((300000 + (1000000 + 500000 * p.d + 600 * p.B_lift)) * VC ^ 2) := by
      rw [Nat.add_mul]
      have ha := h_1_sq (C_1 := 300000) hv8
      have hb := h_m_sq (C_m := 1000000 + 500000 * p.d + 600 * p.B_lift) hv8
      linarith
    have hb2_sq : 256 * F_sz * (V + natBitLength T_sz + 8) ^ 2 * (2 * LZ + 16) * LZ +
        1000000 * (V + natBitLength T_sz + 16) ^ 2 ≤
        p.m * p.w ^ 2 * ((256 * F_sz * (2 * LZ + 16) * LZ + 1000000) * VC ^ 2) := by
      have ha : 256 * F_sz * (V + natBitLength T_sz + 8) ^ 2 * (2 * LZ + 16) * LZ =
          (256 * F_sz * (2 * LZ + 16) * LZ) * (V + (natBitLength T_sz + 8)) ^ 2 := by ring
      have hb : V + natBitLength T_sz + 16 = V + (natBitLength T_sz + 16) := by omega
      rw [ha, hb]
      have h1 := h_1_sq (C_1 := 256 * F_sz * (2 * LZ + 16) * LZ) hv_sz8
      have h2 := h_1_sq (C_1 := 1000000) hv_sz16
      linarith
    have hb3_sq : (2000000 + M * (1200000 + 600000 * p.d) + p.D * (1000000 + 600 * p.L_z)) *
        (V + natBitLength T_A1 + 16) ^ 2 +
        256 * F_A1 * (V + natBitLength T_A1 + 8) ^ 2 * (2 * LZ + 16) * LZ ≤
        p.m * p.w ^ 2 * ((2000000 + LZ * (1200000 + 600000 * p.d) + (p.d + 1) * (1000000 + 600 * LZ) +
          256 * F_A1 * (2 * LZ + 16) * LZ) * VC ^ 2) := by
      have hM_le : 2000000 + M * (1200000 + 600000 * p.d) + p.D * (1000000 + 600 * p.L_z) ≤
          2000000 + LZ * (1200000 + 600000 * p.d) + (p.d + 1) * (1000000 + 600 * LZ) := by
        have hMLz' : M ≤ LZ := hMLz
        rw [hD_eq, hLz_eq]
        have := Nat.mul_le_mul_right (1200000 + 600000 * p.d) hMLz'
        omega
      have ha : V + natBitLength T_A1 + 16 = V + (natBitLength T_A1 + 16) := by omega
      have hb : 256 * F_A1 * (V + natBitLength T_A1 + 8) ^ 2 * (2 * LZ + 16) * LZ =
          (256 * F_A1 * (2 * LZ + 16) * LZ) * (V + (natBitLength T_A1 + 8)) ^ 2 := by ring
      rw [ha, hb]
      have h1 := (Nat.mul_le_mul_right _ hM_le).trans (h_1_sq hv_a1_16)
      have h2 := h_1_sq (C_1 := 256 * F_A1 * (2 * LZ + 16) * LZ) hv_a1_8
      linarith
    have hb4 : (4400000 + 200000 * deg_α₀ + 12500000 * p.m) * (V + 8) ^ 2 ≤
        p.m * p.w ^ 2 * ((4400000 + 200000 * deg_α₀ + 12500000) * VC ^ 2) := by
      have hsplit : (4400000 + 200000 * deg_α₀ + 12500000 * p.m) * (V + 8) ^ 2 =
          (4400000 + 200000 * deg_α₀) * (V + 8) ^ 2 + (p.m * 12500000) * (V + 8) ^ 2 := by ring
      rw [hsplit]
      have h1 := h_1_sq (C_1 := 4400000 + 200000 * deg_α₀) hv8
      have h2 := h_m_sq (C_m := 12500000) hv8
      linarith
    have hb5_sq : (2000000 + 800000 * (p.D + p.s₀ * p.D)) * (V + natBitLength T_c + 16) ^ 2 +
        p.r * ((2000000 + p.s₀ * (1500000 + 300000 * p.d)) * (V + natBitLength T_c + 16) ^ 2 +
          256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * UC + 16) * UC) ≤
        p.m * p.w ^ 2 * ((2000000 + 800000 * ((p.d + 1) + p.s₀ * (p.d + 1)) +
          2000000 + p.s₀ * (1500000 + 300000 * p.d) + 256 * F_c * (2 * UC + 16) * UC) * VC ^ 2) := by
      have ha : V + natBitLength T_c + 16 = V + (natBitLength T_c + 16) := by omega
      have hb : 256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * UC + 16) * UC =
          (256 * F_c * (2 * UC + 16) * UC) * (V + (natBitLength T_c + 8)) ^ 2 := by ring
      rw [ha, hb, hD_eq]
      have h1 := h_1_sq (C_1 := 2000000 + 800000 * ((p.d + 1) + p.s₀ * (p.d + 1))) hv_c16
      have hr_le := Nat.mul_le_mul_right
        ((2000000 + p.s₀ * (1500000 + 300000 * p.d)) * (V + (natBitLength T_c + 16)) ^ 2 +
          (256 * F_c * (2 * UC + 16) * UC) * (V + (natBitLength T_c + 8)) ^ 2) hr_le_m
      have h2 := h_m_sq (C_m := 2000000 + p.s₀ * (1500000 + 300000 * p.d)) hv_c16
      have h3 := h_m_sq (C_m := 256 * F_c * (2 * UC + 16) * UC) hv_c8
      linarith
    have hb6 : (1500000 + 600000 * p.D + 800000 * p.m) * (V + 8) ^ 2 + (4 * V + 16) ≤
        p.m * p.w ^ 2 * ((1500000 + 600000 * (p.d + 1) + 800000 + 32) * VC ^ 2) := by
      rw [hD_eq]
      have hsplit : (1500000 + 600000 * (p.d + 1) + 800000 * p.m) * (V + 8) ^ 2 =
          (1500000 + 600000 * (p.d + 1)) * (V + 8) ^ 2 + (p.m * 800000) * (V + 8) ^ 2 := by ring
      rw [hsplit]
      have h1 := h_1_sq (C_1 := 1500000 + 600000 * (p.d + 1)) hv8
      have h2 := h_m_sq (C_m := 800000) hv8
      have h3 : 4 * V + 16 ≤ 32 * (V + 8) ^ 2 := by rw [sq]; nlinarith
      have h4 := h3.trans (h_1_sq (C_1 := 32) hv8)
      linarith
    have hex_sz : (LZ + 2) * (8 * natBitLength (LZ + 2) + 4 * (LZ + 2 * natBitLength T_sz + 6) + 80) ≤
        p.m * p.w ^ 2 * ((LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_sz + 6) + 80)) := by
      have hnb := natBitLength_le (LZ + 2)
      exact (Nat.mul_le_mul_left (LZ + 2) (by omega)).trans
        (Nat.le_mul_of_pos_left _ (Nat.mul_pos hm1 (by positivity)))
    have hex_a1 : (LZ + 2) * (8 * natBitLength (LZ + 2) + 4 * (LZ + 2 * natBitLength T_A1 + 6) + 80) ≤
        p.m * p.w ^ 2 * ((LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_A1 + 6) + 80)) := by
      have hnb := natBitLength_le (LZ + 2)
      exact (Nat.mul_le_mul_left (LZ + 2) (by omega)).trans
        (Nat.le_mul_of_pos_left _ (Nat.mul_pos hm1 (by positivity)))
    have hex_c : p.r * ((UC + 2) * (8 * natBitLength (UC + 2) + 4 * (UC + 2 * natBitLength T_c + 6) + 80)) ≤
        p.m * p.w ^ 2 * ((UC + 2) * (8 * (UC + 3) + 4 * (UC + 2 * natBitLength T_c + 6) + 80) + 32) := by
      have hnb := natBitLength_le (UC + 2)
      let Ec := (UC + 2) * (8 * (UC + 3) + 4 * (UC + 2 * natBitLength T_c + 6) + 80) + 32
      have h1 : (UC + 2) * (8 * natBitLength (UC + 2) + 4 * (UC + 2 * natBitLength T_c + 6) + 80) ≤ Ec := by
        dsimp [Ec]
        exact (Nat.mul_le_mul_left (UC + 2) (by omega)).trans (Nat.le_add_right _ 32)
      calc p.r * _ ≤ p.m * Ec := Nat.mul_le_mul hr_le_m h1
        _ ≤ p.m * (p.w ^ 2 * Ec) := Nat.mul_le_mul_left p.m
            (Nat.le_mul_of_pos_left Ec (by positivity))
        _ = p.m * p.w ^ 2 * Ec := by ring
    let Bsq := (4000000 + 400000 * (p.deg_α + p.deg_alg)) +
      (300000 + (1000000 + 500000 * p.d + 600 * p.B_lift)) +
      (256 * F_sz * (2 * LZ + 16) * LZ + 1000000) +
      (2000000 + LZ * (1200000 + 600000 * p.d) + (p.d + 1) * (1000000 + 600 * LZ) +
        256 * F_A1 * (2 * LZ + 16) * LZ) +
      (4400000 + 200000 * deg_α₀ + 12500000) +
      (2000000 + 800000 * ((p.d + 1) + p.s₀ * (p.d + 1)) +
        2000000 + p.s₀ * (1500000 + 300000 * p.d) + 256 * F_c * (2 * UC + 16) * UC) +
      (1500000 + 600000 * (p.d + 1) + 800000) + 32
    let Bex := (LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_sz + 6) + 80) +
      (LZ + 2) * (8 * (LZ + 3) + 4 * (LZ + 2 * natBitLength T_A1 + 6) + 80) +
      (UC + 2) * (8 * (UC + 3) + 4 * (UC + 2 * natBitLength T_c + 6) + 80) + 32
    have hsum_b : exactAttemptBitCap p deg_α₀ V M T_sz T_A1 T_c F_sz F_A1 F_c LZ LZ UC + 4 * V + 16 ≤
        p.m * p.w ^ 2 * (Bsq * VC ^ 2 + Bex) := by
      unfold exactAttemptBitCap
      rw [Nat.mul_add]
      dsimp [Bsq, Bex]
      linarith
    unfold exactTimeCapNat
    dsimp only
    rw [← hpK, ← hpdeg, ← hs1_eq, ← hs0_eq, ← hBl_eq]
    calc 4 * (exactAttemptBitCap p deg_α₀ V M T_sz T_A1 T_c F_sz F_A1 F_c LZ LZ UC + 4 * V + 16)
        ≤ 4 * (p.m * p.w ^ 2 * (Bsq * VC ^ 2 + Bex)) := Nat.mul_le_mul_left 4 hsum_b
      _ = p.m * p.w ^ 2 * (4 * (Bsq * VC ^ 2 + Bex)) := by ring
      _ ≤ p.m * p.w ^ 2 * _ := Nat.mul_le_mul_left (p.m * p.w ^ 2) (Nat.le_add_left _ _)
  exact ⟨hunit_tot, hbitc_tot⟩

/-! ### 3. Master Proof of Exact `S_lem_A_2` -/

theorem exact_lem_A_2_main
    (h_hw87_stmt : S_cit_hw87_halfspace_net)
    (h_gls_stmt : S_cit_gls88_rational_lp)
    (h_A1_stmt : S_lem_A_1) :
    S_lem_A_2 := by
  rcases h_hw87_stmt with ⟨C_HW, hCHW_pos, h_hw87⟩
  rcases h_gls_stmt.2.2 with ⟨progCert, C_cert, deg_cert, h_gls_cert⟩
  rcases h_A1_stmt with ⟨sizeProg, prog_A1, α, C_α, deg_α₀, C_alg, deg_alg,
    hCα_pos, hCalg_pos, hα_spec, h_A1⟩
  let φ : ℝ := 1 / 10
  have hφ_pos : 0 < φ := by norm_num [φ]
  have hφ_lt : φ < 1 / 2 := by norm_num [φ]
  let k_φ : ℕ := Nat.ceil (Real.logb 2 (1 / φ))
  obtain ⟨K₀, hK₀, hCHW_le_K₀, hCα_le_K₀⟩ :
      ∃ K₀ : ℕ, 1 ≤ K₀ ∧ C_HW ≤ (K₀ : ℝ) ∧ C_α * (Real.log (1 / φ) + 1) ^ deg_α₀ ≤ (K₀ : ℝ) :=
    ⟨max 1 (max (Nat.ceil C_HW) (Nat.ceil (C_α * (Real.log (1 / φ) + 1) ^ deg_α₀))),
     le_max_left _ _,
     (Nat.le_ceil C_HW).trans (by exact_mod_cast (le_max_left _ _).trans (le_max_right 1 _)),
     (Nat.le_ceil _).trans (by exact_mod_cast (le_max_right _ _).trans (le_max_right 1 _))⟩
  let K : ℕ := 25 * K₀ ^ 2
  let deg_α : ℕ := 2 * deg_α₀ + 1
  have hK1 : 1 ≤ K := by dsimp [K]; nlinarith
  obtain ⟨C_z, hCz1, hCalg_le_Cz⟩ :
      ∃ C_z : ℕ, 1 ≤ C_z ∧ C_alg * (Real.log (1 / φ) + 1) ^ deg_alg ≤ (C_z : ℝ) :=
    ⟨max 1 (Nat.ceil (C_alg * (Real.log (1 / φ) + 1) ^ deg_alg)),
     le_max_left _ _,
     (Nat.le_ceil _).trans (by exact_mod_cast le_max_right 1 _)⟩
  let T_sz := maxTableStmtFull sizeProg
  let T_A1 := maxTableStmtFull prog_A1
  let T_c := maxTableStmtFull progCert
  let F_sz := stmtFactor sizeProg
  let F_A1 := stmtFactor prog_A1
  let F_c := stmtFactor progCert
  let s₀ : ℕ → ℕ := fun d => s₀Val K deg_α d
  let prog : BitRAMStmt := exactRetryMainProg K₀ deg_α₀ C_z deg_alg k_φ sizeProg prog_A1 progCert
  let timePoly : ℕ → ℕ → ℝ := fun d B =>
    (exactTimeCapNat K₀ deg_α₀ C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c d B : ℝ)
  let spacePoly : ℕ → ℕ → ℝ := fun d B =>
    (spaceCapNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c d B : ℝ)
  let bitLenPoly : ℕ → ℕ → ℝ := fun d B =>
    (bitLenCapNat K deg_α C_z deg_alg C_cert deg_cert d B : ℝ)
  refine ⟨s₀, prog, timePoly, spacePoly, bitLenPoly,
    fun d => s₀Val_pos hK1 d,
    isBoundedByPoly1_s₀Val K deg_α,
    isNatPoly2_exactTimeCapNat K₀ deg_α₀ C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c,
    isNatPoly2_spaceCapNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c,
    isNatPoly2_bitLenCapNat K deg_α C_z deg_alg C_cert deg_cert,
    ?_⟩
  intro d B hB ι instDec pts P₀ enum hm2s hpts_P0
  let m : ℕ := P₀.card
  let w : ℕ := Nat.clog 2 (2 * m)
  let s₁ : ℕ := s₁Val K₀ deg_α₀ d
  have hs₁_2 : 2 ≤ s₁ := by have := s₁Val_ge_144 (deg_α := deg_α₀) hK₀ d; omega
  have hs₀_ge : 64 * s₁ ^ 2 ≤ s₀ d := sixtyFour_s₁Val_sq_le_s₀Val hK₀ d
  let pts_h : ℕ → Fin d → ℚ := fun h =>
    if hh : h < m then pts (enum ⟨h, hh⟩).1 else fun _ => 0
  have hpts_b : ∀ h : ℕ, h < m → RatPointBitBounded B (pts_h h) := by
    intro h hh
    dsimp [pts_h]; rw [dif_pos hh]
    exact hpts_P0 (enum ⟨h, hh⟩).1 (enum ⟨h, hh⟩).2
  let inp : BitRAMInput d :=
    { intParams := [(m : ℤ), (B : ℤ)]
      activeHandles := Finset.range m
      activeRatCoords := pts_h
      extraRats := [] }
  let p : CoreParams :=
    { d := d, m := m, B := B, K := K, deg_α := deg_α, C_z := C_z, deg_alg := deg_alg, k_φ := k_φ }
  have hs0_pos : 1 ≤ p.s₀ := s₀Val_pos hK1 d
  have hs0_def : p.s₀ = s₀ d := rfl
  have hm2 : 2 ≤ m := by omega
  haveI : Nonempty (Fin m) := ⟨⟨0, by omega⟩⟩
  have hD1 : 1 ≤ p.D := by dsimp [CoreParams.D]; omega
  have hBl1 : 1 ≤ p.B_lift := by dsimp [CoreParams.B_lift, bLiftVal]; omega
  have hLz1 : 1 ≤ p.L_z := by
    dsimp [CoreParams.L_z]
    exact Nat.mul_pos (Nat.mul_pos hCz1 (Nat.one_le_pow _ _ (by omega))) (Nat.one_le_pow _ _ (by omega))
  -- Instantiate Lemma A.1 on `(p.D, p.B_lift, φ)` and lifted population `Fin m`
  have hpoly_le_Lz :
      C_alg * ((p.D : ℝ) + 1) ^ deg_alg * ((p.B_lift : ℝ) + 1) ^ deg_alg *
        (Real.log (1 / φ) + 1) ^ deg_alg ≤ (p.L_z : ℝ) := by
    calc C_alg * ((p.D : ℝ) + 1) ^ deg_alg * ((p.B_lift : ℝ) + 1) ^ deg_alg *
            (Real.log (1 / φ) + 1) ^ deg_alg
        = (C_alg * (Real.log (1 / φ) + 1) ^ deg_alg) *
            (((p.D : ℝ) + 1) ^ deg_alg * ((p.B_lift : ℝ) + 1) ^ deg_alg) := by ring
      _ ≤ (C_z : ℝ) * (((p.D : ℝ) + 1) ^ deg_alg * ((p.B_lift : ℝ) + 1) ^ deg_alg) :=
          mul_le_mul_of_nonneg_right hCalg_le_Cz (by positivity)
      _ = (p.L_z : ℝ) := by dsimp [CoreParams.L_z, p]; push_cast; ring
  obtain ⟨M, sizeOut, hrun_sz, hM_out, hM1, hM_poly, hsz_u, hsz_b, hsz_pc, hsz_pb, hA1_pop⟩ :=
    h_A1 p.D p.B_lift hD1 hBl1 φ hφ_pos hφ_lt
  have hMLz : M ≤ p.L_z := by exact_mod_cast hM_poly.trans hpoly_le_Lz
  have hsz_bounds : sizeOut.unitCost ≤ p.L_z ∧ sizeOut.bitCost ≤ p.L_z ∧
      sizeOut.peakCellSpace ≤ p.L_z ∧ sizeOut.peakBitSpace ≤ p.L_z :=
    ⟨by exact_mod_cast hsz_u.trans hpoly_le_Lz,
     by exact_mod_cast hsz_b.trans hpoly_le_Lz,
     by exact_mod_cast hsz_pc.trans hpoly_le_Lz,
     by exact_mod_cast hsz_pb.trans hpoly_le_Lz⟩
  let P_lift : Fin m → Fin p.D → ℚ := fun idx => liftRatPoint (pts_h idx.1)
  have hPlift_b : ∀ idx : Fin m, RatPointBitBounded p.B_lift (P_lift idx) :=
    fun idx => ratPointBitBounded_liftRatPoint hB (hpts_b idx.1 idx.2)
  obtain ⟨hA1_all_ω, hA1_prob⟩ := hA1_pop (Fin m) P_lift hPlift_b
  obtain ⟨outA1Of, zRatOf, hA1_spec⟩ :
      ∃ (outA1Of : (Fin M → Fin m) → BitRAMExecOutcome)
        (zRatOf : (Fin M → Fin m) → Fin p.D → ℚ),
      ∀ ω : Fin M → Fin m,
      runBitRAMWithBits prog_A1
        { intParams := [(p.B_lift : ℤ), (p.k_φ : ℤ), (M : ℤ)]
          activeHandles := Finset.range M
          activeRatCoords := fun j => if hj : j < M then P_lift (ω ⟨j, hj⟩) else fun _ => 0
          extraRats := [] }
        WordStore.empty [] = some (outA1Of ω) ∧
      ((outA1Of ω).unitCost ≤ p.L_z ∧ (outA1Of ω).bitCost ≤ p.L_z ∧
        (outA1Of ω).peakCellSpace ≤ p.L_z ∧ (outA1Of ω).peakBitSpace ≤ p.L_z) ∧
      (∀ c : Fin p.D,
        let zNum := (outA1Of ω).words.read (.heap 1 (2 * (c.1 : ℤ)))
        let zDen := (outA1Of ω).words.read (.heap 1 (2 * (c.1 : ℤ) + 1))
        0 < zDen ∧ zRatOf ω c = (zNum : ℚ) / (zDen : ℚ) ∧
        intBitLength zNum ≤ p.L_z ∧ intBitLength zDen ≤ p.L_z) := by
    refine ⟨fun ω => (hA1_all_ω ω).choose, fun ω => (hA1_all_ω ω).choose_spec.choose, fun ω => ?_⟩
    obtain ⟨hrun, hu, hb, hpc, hpb, hz, _⟩ := (hA1_all_ω ω).choose_spec.choose_spec
    refine ⟨hrun,
      ⟨by exact_mod_cast hu.trans hpoly_le_Lz,
       by exact_mod_cast hb.trans hpoly_le_Lz,
       by exact_mod_cast hpc.trans hpoly_le_Lz,
       by exact_mod_cast hpb.trans hpoly_le_Lz⟩,
      fun c => ?_⟩
    obtain ⟨hden0, hzeq, hnum_b, hden_b, _⟩ := hz c
    exact ⟨hden0, hzeq, by exact_mod_cast hnum_b.trans hpoly_le_Lz,
           by exact_mod_cast hden_b.trans hpoly_le_Lz⟩
  let B_cert := p.B_lift + p.L_z
  let U_cert := ucertFn K deg_α C_z deg_alg C_cert deg_cert d B
  have hUcert_eq : C_cert * (p.D + p.s₀ + B_cert + 1) ^ deg_cert = U_cert := rfl
  have hzRat_b : ∀ ω : Fin M → Fin m, RatPointBitBounded B_cert (zRatOf ω) := by
    intro ω c
    exact (ratPointBitBounded_mono (Nat.le_add_left p.L_z p.B_lift)
      (fun c' => by
        obtain ⟨hd0', hzeq', hnb', hdb'⟩ := (hA1_spec ω).2.2 c'
        exact ratCoordBitBounded_of_num_den_intBitLength hLz1 hd0' hzeq' hnb' hdb')) c
  have hCert_all : ∀ (ω : Fin M → Fin m) (π : Equiv.Perm (Fin m)) (b : Fin p.r),
      let pts_b : Fin p.s₀ → Fin p.D → ℚ := fun j => liftRatPoint (pts_h (blkHandle p π b j).1)
      ∃ out : BitRAMExecOutcome,
        runBitRAMWithBits progCert (certBlockInp p pts_h (zRatOf ω) π b) WordStore.empty [] = some out ∧
        (out.unitCost ≤ U_cert ∧ out.bitCost ≤ U_cert ∧
          out.peakCellSpace ≤ U_cert ∧ out.peakBitSpace ≤ U_cert) ∧
        (out.words.read (.heap 0 0) = 1 ↔
          HasConvexHullCert (fun j : Fin p.s₀ => ratPointToEuclidean (pts_b j))
            (ratPointToEuclidean (zRatOf ω))) ∧
        (out.words.read (.heap 0 0) = 1 →
          let lamNum : Fin p.s₀ → ℤ := fun j => out.words.read (.heap 1 (2 * (j.1 : ℤ)))
          let lamDen : Fin p.s₀ → ℤ := fun j => out.words.read (.heap 1 (2 * (j.1 : ℤ) + 1))
          let lam : Fin p.s₀ → ℚ := fun j => (lamNum j : ℚ) / (lamDen j : ℚ)
          (∀ j : Fin p.s₀,
            0 < lamDen j ∧ intBitLength (lamNum j) ≤ U_cert ∧
            intBitLength (lamDen j) ≤ U_cert ∧ ratBitLength (lam j) ≤ U_cert) ∧
          IsConvexHullCert (fun j : Fin p.s₀ => ratPointToEuclidean (pts_b j))
            (ratPointToEuclidean (zRatOf ω)) (fun j : Fin p.s₀ => (lam j : ℝ))) := by
    intro ω π b pts_b
    have hpb_b : ∀ j : Fin p.s₀, RatPointBitBounded B_cert (pts_b j) := fun j =>
      ratPointBitBounded_mono (Nat.le_add_right p.B_lift p.L_z)
        (hPlift_b (blkHandle p π b j))
    obtain ⟨out, hrun, hu, hb, hpc, hpb, _, hiff, himp⟩ :=
      h_gls_cert p.D p.s₀ B_cert pts_b (zRatOf ω) hpb_b (hzRat_b ω)
    rw [hUcert_eq] at hu hb hpc hpb himp
    refine ⟨out, hrun, ⟨hu, hb, hpc, hpb⟩, hiff, fun hfl => ?_⟩
    obtain ⟨hlam_b, hconv⟩ := himp hfl
    exact ⟨fun j => ⟨(hlam_b j).1, (hlam_b j).2.1, (hlam_b j).2.2.1, (hlam_b j).2.2.2.2⟩, hconv⟩
  obtain ⟨outCertOf, hCert_spec⟩ :
      ∃ outCertOf : (Fin M → Fin m) → Equiv.Perm (Fin m) → Fin p.r → BitRAMExecOutcome,
      ∀ (ω : Fin M → Fin m) (π : Equiv.Perm (Fin m)) (b : Fin p.r),
        let pts_b : Fin p.s₀ → Fin p.D → ℚ := fun j => liftRatPoint (pts_h (blkHandle p π b j).1)
        let out := outCertOf ω π b
        runBitRAMWithBits progCert (certBlockInp p pts_h (zRatOf ω) π b) WordStore.empty [] = some out ∧
        (out.unitCost ≤ U_cert ∧ out.bitCost ≤ U_cert ∧
          out.peakCellSpace ≤ U_cert ∧ out.peakBitSpace ≤ U_cert) ∧
        (out.words.read (.heap 0 0) = 1 ↔
          HasConvexHullCert (fun j : Fin p.s₀ => ratPointToEuclidean (pts_b j))
            (ratPointToEuclidean (zRatOf ω))) ∧
        (out.words.read (.heap 0 0) = 1 →
          let lamNum : Fin p.s₀ → ℤ := fun j => out.words.read (.heap 1 (2 * (j.1 : ℤ)))
          let lamDen : Fin p.s₀ → ℤ := fun j => out.words.read (.heap 1 (2 * (j.1 : ℤ) + 1))
          let lam : Fin p.s₀ → ℚ := fun j => (lamNum j : ℚ) / (lamDen j : ℚ)
          (∀ j : Fin p.s₀,
            0 < lamDen j ∧ intBitLength (lamNum j) ≤ U_cert ∧
            intBitLength (lamDen j) ≤ U_cert ∧ ratBitLength (lam j) ≤ U_cert) ∧
          IsConvexHullCert (fun j : Fin p.s₀ => ratPointToEuclidean (pts_b j))
            (ratPointToEuclidean (zRatOf ω)) (fun j : Fin p.s₀ => (lam j : ℝ))) :=
    ⟨fun ω π b => (hCert_all ω π b).choose, fun ω π b => (hCert_all ω π b).choose_spec⟩
  -- Define `N_bits` and chunk acceptance predicate `acc`
  let N_bits : ℕ := M * p.W₁ M + (2 * s₁) * p.W₂
  let ωOf : (Fin N_bits → Bool) → (Fin M → Fin m) := fun v j =>
    let sp := splitAttemptBits M (p.W₁ M) (2 * s₁) p.W₂ v
    ⟨bitsToNat (p.W₁ M) (sp.1 j) % m, Nat.mod_lt _ (by omega)⟩
  let πOf : (Fin N_bits → Bool) → Equiv.Perm (Fin m) := fun v =>
    let sp := splitAttemptBits M (p.W₁ M) (2 * s₁) p.W₂ v
    permOfPolyBits hs₁_2 hs₀_ge hm2s sp.2
  let passBoolOf : (Fin N_bits → Bool) → Fin p.r → Bool := fun v b =>
    decide ((outCertOf (ωOf v) (πOf v) b).words.read (.heap 0 0) = 1)
  let L_passOf : (Fin N_bits → Bool) → List (Fin p.r) := fun v =>
    (List.finRange p.r).filter (passBoolOf v)
  let acc : (Fin N_bits → Bool) → Bool := fun v =>
    decide (p.r ≤ 2 * (L_passOf v).length)
  -- Prove `1 / 2` acceptance probability via `exact_attempt_success_prob_ge_half`
  have hprob_half :
      1 / 2 ≤ ((Finset.univ.filter (fun v : Fin N_bits → Bool => acc v = true)).card : ℝ) /
        ((2 : ℝ) ^ N_bits) := by
    classical
    let Q_lift : Fin m → EuclideanSpace ℝ (Fin p.D) := fun idx => ratPointToEuclidean (P_lift idx)
    let goodSample : (Fin M → Fin m) → Bool := fun ω =>
      decide (IsCenterpoint (α p.D φ) Q_lift (ratPointToEuclidean (zRatOf ω)))
    let passBlock : (Fin M → Fin m) → Finset (Fin m) → Bool := fun ω S =>
      decide (ratPointToEuclidean (zRatOf ω) ∈ convexHull ℝ (Q_lift '' (S : Set (Fin m))))
    have hGoodSample :
        9 / 10 ≤ ((Finset.univ.filter (fun ω : Fin M → Fin m => goodSample ω = true)).card : ℝ) /
          (Fintype.card (Fin M → Fin m) : ℝ) := by
      have hsub :
          Finset.univ.filter (fun ω : Fin M → Fin m =>
            ∃ (out : BitRAMExecOutcome) (zRat : Fin p.D → ℚ),
              runBitRAMWithBits prog_A1
                { intParams := [(p.B_lift : ℤ), (p.k_φ : ℤ), (M : ℤ)]
                  activeHandles := Finset.range M
                  activeRatCoords := fun j => if hj : j < M then P_lift (ω ⟨j, hj⟩) else fun _ => 0
                  extraRats := [] }
                WordStore.empty [] = some out ∧
              (∀ c : Fin p.D,
                let zNum := out.words.read (.heap 1 (2 * (c.val : ℤ)))
                let zDen := out.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
                0 < zDen ∧ zRat c = (zNum : ℚ) / (zDen : ℚ)) ∧
              IsCenterpoint (α p.D φ) Q_lift (ratPointToEuclidean zRat)) ⊆
          Finset.univ.filter (fun ω : Fin M → Fin m => goodSample ω = true) := by
        intro ω hω
        rcases (Finset.mem_filter.mp hω).2 with ⟨out, zR, hrun, hz_r, hcp⟩
        have hrun0 := (hA1_spec ω).1
        rw [hrun0] at hrun
        injection hrun with hout_eq
        subst hout_eq
        have hz_eq : zR = zRatOf ω := by
          funext c
          rw [(hz_r c).2, ((hA1_spec ω).2.2 c).2.1]
        subst hz_eq
        exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, decide_eq_true hcp⟩
      have hcard := Finset.card_le_card hsub
      have hcardR := (Nat.cast_le (α := ℝ)).mpr hcard
      have hdiv := div_le_div_of_nonneg_right hcardR (Nat.cast_nonneg (Fintype.card (Fin M → Fin m)))
      have h910 : (9 / 10 : ℝ) = 1 - φ := by norm_num [φ]
      rw [h910]
      exact hA1_prob.trans hdiv
    obtain ⟨hα0, hα1, hα_inv⟩ := hα_spec p.D hD1 φ hφ_pos hφ_lt
    have hα_K₀ : (α p.D φ)⁻¹ ≤ (K₀ : ℝ) * ((d + 2 : ℝ) ^ deg_α₀) := by
      calc (α p.D φ)⁻¹
          ≤ (C_α * (Real.log (1 / φ) + 1) ^ deg_α₀) * (((p.D : ℝ) + 1) ^ deg_α₀) := by
            linarith [hα_inv]
        _ ≤ (K₀ : ℝ) * (((p.D : ℝ) + 1) ^ deg_α₀) :=
            mul_le_mul_of_nonneg_right hCα_le_K₀ (by positivity)
        _ = (K₀ : ℝ) * ((d + 2 : ℝ) ^ deg_α₀) := by dsimp [CoreParams.D, p]; push_cast; ring
    have hs₁_hw := hw87_half_depth_le_s₁Val hK₀ hCHW_pos hCHW_le_K₀ hα0 hα1 hα_K₀
    have hs₁_hw' :
        Nat.ceil (C_HW * (α p.D φ / 2)⁻¹ *
          (((p.D : ℝ) + 1) * Real.log (2 / (α p.D φ / 2)) + Real.log (2 / (1 / 16 : ℝ)))) ≤ s₁ := by
      dsimp [CoreParams.D, p, s₁]; push_cast; exact hs₁_hw
    have hHW_s₁ : ∀ (κ : Type) [Fintype κ] [Nonempty κ] (P : κ → EuclideanSpace ℝ (Fin p.D)),
        (15 / 16 : ℝ) ≤
          ((Finset.univ.filter (fun sample : Fin s₁ → κ =>
            IsIndexedHalfspaceNet (α p.D φ / 2) P sample)).card : ℝ) /
          (Fintype.card (Fin s₁ → κ) : ℝ) := by
      intro κ _ _ P
      have h1 := (h_hw87 p.D hD1 κ P (α p.D φ / 2) (by linarith) (by linarith)
        (1 / 16) (by norm_num) (by norm_num) s₁ hs₁_hw').1
      linarith
    have hmain := exact_attempt_success_prob_ge_half
      hD1 hM1 hs₁_2 hs₀_ge hm2s
      (two_pow_W₁_ge p M) (two_pow_W₂_ge p) hα0
      Q_lift (fun ω => ratPointToEuclidean (zRatOf ω)) goodSample hGoodSample
      (fun ω hg => of_decide_eq_true hg)
      hHW_s₁ passBlock
      (fun ω S hmem => decide_eq_true hmem)
    have hrs : p.r * p.s₀ ≤ m := Nat.div_mul_le_self m p.s₀
    have hpred_eq : ∀ v : Fin N_bits → Bool,
        (let sp := splitAttemptBits M (p.W₁ M) (2 * s₁) p.W₂ v
         let ω : Fin M → Fin m := fun j =>
           ⟨bitsToNat (p.W₁ M) (sp.1 j) % m, Nat.mod_lt _ (by omega)⟩
         let π := permOfPolyBits hs₁_2 hs₀_ge hm2s sp.2
         let k_pass : ℕ := (Finset.univ.filter (fun b : Fin p.r =>
           passBlock ω (sliceBlockSet hrs π b) = true)).card
         decide (p.r ≤ 2 * k_pass)) = acc v := by
      intro v
      have hpass_eq : ∀ b : Fin p.r,
          passBlock (ωOf v) (sliceBlockSet hrs (πOf v) b) = passBoolOf v b := by
        intro b
        have hslice_eq : sliceBlockSet hrs (πOf v) b =
            Finset.univ.image (blkHandle p (πOf v) b) := rfl
        have hrange_eq : Q_lift '' (sliceBlockSet hrs (πOf v) b : Set (Fin m)) =
            Set.range (fun j : Fin p.s₀ => Q_lift (blkHandle p (πOf v) b j)) := by
          ext x; simp [hslice_eq]
        have hiff1 := (hCert_spec (ωOf v) (πOf v) b).2.2.1
        have hiff2 := hasConvexHullCert_iff_mem_convexHull
          (fun j : Fin p.s₀ => Q_lift (blkHandle p (πOf v) b j))
          (ratPointToEuclidean (zRatOf (ωOf v)))
        dsimp [passBlock, passBoolOf, Q_lift, P_lift]
        rw [hrange_eq]
        exact decide_eq_decide.mpr (hiff1.trans hiff2).symm
      have hlen_eq : (L_passOf v).length =
          (Finset.univ.filter (fun b : Fin p.r =>
            passBlock (ωOf v) (sliceBlockSet hrs (πOf v) b) = true)).card := by
        have hnodup : (L_passOf v).Nodup := (List.nodup_finRange p.r).filter (passBoolOf v)
        rw [← List.toFinset_card_of_nodup hnodup]
        congr 1; ext b; simp [L_passOf, hpass_eq b]
      dsimp [acc]
      rw [hlen_eq]
    have hfilt_eq : Finset.univ.filter (fun v : Fin N_bits → Bool =>
          (let sp := splitAttemptBits M (p.W₁ M) (2 * s₁) p.W₂ v
           let ω : Fin M → Fin m := fun j =>
             ⟨bitsToNat (p.W₁ M) (sp.1 j) % m, Nat.mod_lt _ (by omega)⟩
           let π := permOfPolyBits hs₁_2 hs₀_ge hm2s sp.2
           let k_pass : ℕ := (Finset.univ.filter (fun b : Fin p.r =>
             passBlock ω (sliceBlockSet hrs π b) = true)).card
           decide (m / p.s₀ ≤ 2 * k_pass)) = true) =
        Finset.univ.filter (fun v : Fin N_bits → Bool => acc v = true) :=
      Finset.filter_congr (fun v _ => by rw [← hpred_eq v]; rfl)
    dsimp only [N_bits] at hfilt_eq ⊢
    rwa [← hfilt_eq]
  -- Arena parameters and fit (reused directly from `RacerP54_H3i`!)
  let QA := qaFn K deg_α C_z deg_alg d B
  let QV := qvFn K deg_α C_z deg_alg k_φ C_cert deg_cert d B
  let A := m * QA
  let V := 4 * p.w + QV
  obtain ⟨hfit, hinp, h2_fit, h3_fit, h5_fit⟩ :=
    arena_fit_all p (C_cert := C_cert) (deg_cert := deg_cert) (M := M)
      (pts_h := pts_h) (inp := inp) hK1 hB hCz1 hm2s hM1 hMLz
      hpts_b rfl rfl (fun _ _ => rfl) rfl
  obtain ⟨hcell_le, hbitsp_le, _, _⟩ :=
    space_and_cost_caps_le p (C_cert := C_cert) (deg_cert := deg_cert) (M := M)
      (pts_h := pts_h) (inp := inp)
      (T_sz := T_sz) (T_A1 := T_A1) (T_c := T_c) (F_sz := F_sz) (F_A1 := F_A1) (F_c := F_c)
      hK1 hB hm2s hMLz hpts_b rfl rfl (fun _ _ => rfl) rfl
  obtain ⟨hunit_le, hbitc_le⟩ :=
    exact_time_caps_le p (K₀ := K₀) (deg_α₀ := deg_α₀)
      (C_cert := C_cert) (deg_cert := deg_cert)
      (T_sz := T_sz) (T_A1 := T_A1) (T_c := T_c) (F_sz := F_sz) (F_A1 := F_A1) (F_c := F_c)
      (M := M) hK₀ rfl rfl hB hm2s hMLz
  let GoodProp : WordStore → Prop := fun ws =>
    ∃ (k : ℕ) (oRat : Fin d → ℚ) (sRat : ℚ)
      (blocks : Fin k → Fin (s₀ d) → ι)
      (lam : Fin k → Fin (s₀ d) → ℚ),
      ws.read (.heap 0 0) = (k : ℤ) ∧
      (∀ c : Fin d,
        let oNum := ws.read (.heap 1 (2 * (c.val : ℤ)))
        let oDen := ws.read (.heap 1 (2 * (c.val : ℤ) + 1))
        0 < oDen ∧ oRat c = (oNum : ℚ) / (oDen : ℚ) ∧
        (intBitLength oNum : ℝ) ≤ bitLenPoly d B ∧
        (intBitLength oDen : ℝ) ≤ bitLenPoly d B ∧
        (ratBitLength (oRat c) : ℝ) ≤ bitLenPoly d B) ∧
      (let sNum := ws.read (.heap 1 (2 * (d : ℤ)))
       let sDen := ws.read (.heap 1 (2 * (d : ℤ) + 1))
       0 < sDen ∧ sRat = (sNum : ℚ) / (sDen : ℚ) ∧
       (intBitLength sNum : ℝ) ≤ bitLenPoly d B ∧
       (intBitLength sDen : ℝ) ≤ bitLenPoly d B ∧
       (ratBitLength sRat : ℝ) ≤ bitLenPoly d B) ∧
      (∀ (b : Fin k) (j : Fin (s₀ d)),
        let flatIdx : ℤ := ((b.val * s₀ d + j.val : ℕ) : ℤ)
        (∃ idx : Fin m,
          ws.read (.heap 2 flatIdx) = (idx.val : ℤ) ∧
          blocks b j = (enum idx).1) ∧
        let lamNum := ws.read (.heap 3 (2 * flatIdx))
        let lamDen := ws.read (.heap 3 (2 * flatIdx + 1))
        0 < lamDen ∧ lam b j = (lamNum : ℚ) / (lamDen : ℚ) ∧
        (intBitLength lamNum : ℝ) ≤ bitLenPoly d B ∧
        (intBitLength lamDen : ℝ) ≤ bitLenPoly d B ∧
        (ratBitLength (lam b j) : ℝ) ≤ bitLenPoly d B) ∧
      (m : ℝ) / (4 * (s₀ d : ℝ)) ≤ (k : ℝ) ∧
      let z : EuclideanSpace ℝ (Fin (d + 1)) :=
        liftedPoint (ratPointToEuclidean oRat) (sRat : ℝ)
      let blockSet : Fin k → Finset ι :=
        fun b => Finset.univ.image (blocks b)
      (∀ b : Fin k, (blockSet b).card = s₀ d) ∧
      (∀ b₁ b₂ : Fin k, b₁ ≠ b₂ → Disjoint (blockSet b₁) (blockSet b₂)) ∧
      (∀ b : Fin k,
        IsIndexedBlockCertificate (fun i => ratPointToEuclidean (pts i)) P₀ z
          (blocks b) (fun j => (lam b j : ℝ)) ∧
        IsBlockCertificate (fun i => ratPointToEuclidean (pts i)) P₀ z
          (blockSet b)
          (fun i => ∑ j : Fin (s₀ d), if blocks b j = i then (lam b j : ℝ) else 0))
  let U_att := exactAttemptUnitCap p K₀ deg_α₀ M F_sz F_A1 F_c p.L_z p.L_z U_cert
  let B_att := exactAttemptBitCap p deg_α₀ V M T_sz T_A1 T_c F_sz F_A1 F_c p.L_z p.L_z U_cert
  let C_att := attemptCellCap inp A p.L_z p.L_z U_cert
  let S_att := attemptBitSpaceCap inp A V T_sz T_A1 T_c p.L_z p.L_z U_cert
  have hchunks := exec_retry_chunks (inp := inp) (A := A) (V := V)
    (body := .localScope (exactAttemptBodyStmt K₀ deg_α₀ C_z deg_alg k_φ sizeProg prog_A1 progCert))
    acc GoodProp U_att B_att C_att S_att (Nat.le_trans (by omega : 1 ≤ natBitLength A + 16) hinp.2.1)
    (fun v hv_bad rest st hfd ha hhz hbs => by
      obtain ⟨st', hr, hfd', hbs', ha', hu', hb', hpc', hpb', hout⟩ :=
        exec_localScope_exactAttempt p pts_h sizeProg prog_A1 progCert
          (zRatOf (ωOf v)) (outCertOf (ωOf v) (πOf v)) v rest
          hK₀ rfl rfl hfd ha hhz hbs hinp hfit rfl rfl (fun _ _ => rfl) hpts_b
          hrun_sz hM_out hsz_bounds h2_fit h3_fit h5_fit
          (hA1_spec (ωOf v)).1 (hA1_spec (ωOf v)).2.1 (hA1_spec (ωOf v)).2.2
          (fun b => (hCert_spec (ωOf v) (πOf v) b).1)
          (fun b => (hCert_spec (ωOf v) (πOf v) b).2.1)
      have hnot : ¬ (p.r ≤ 2 * (L_passOf v).length) := of_decide_eq_false hv_bad
      rw [if_neg hnot] at hout
      exact ⟨st', hr, hfd', hbs', ha', hout, hu', hb', hpc', hpb'⟩)
    (fun v hv_good st hfd ha hhz hbs => by
      obtain ⟨st', hr, hfd', hbs', ha', hu', hb', hpc', hpb', hout⟩ :=
        exec_localScope_exactAttempt p pts_h sizeProg prog_A1 progCert
          (zRatOf (ωOf v)) (outCertOf (ωOf v) (πOf v)) v []
          hK₀ rfl rfl hfd ha hhz hbs hinp hfit rfl rfl (fun _ _ => rfl) hpts_b
          hrun_sz hM_out hsz_bounds h2_fit h3_fit h5_fit
          (hA1_spec (ωOf v)).1 (hA1_spec (ωOf v)).2.1 (hA1_spec (ωOf v)).2.2
          (fun b => (hCert_spec (ωOf v) (πOf v) b).1)
          (fun b => (hCert_spec (ωOf v) (πOf v) b).2.1)
      have hyes : p.r ≤ 2 * (L_passOf v).length := of_decide_eq_true hv_good
      rw [if_pos hyes] at hout
      rcases hout with ⟨hr0, hr1, hr23⟩
      obtain ⟨hk1, hk_quarter⟩ := k_pass_ge_quarter hs0_pos hm2s hyes
      have hnz : st'.words.read (.heap 0 0) ≠ 0 := by rw [hr0]; exact Int.natCast_ne_zero.mpr (Nat.pos_iff_ne_zero.mp hk1)
      refine ⟨st', hr, hfd', hbs', ha', hnz, ?_, hu', hb', hpc', hpb'⟩
      let k := (L_passOf v).length
      let zRat := zRatOf (ωOf v)
      let oRat : Fin d → ℚ := fun c => zRat c.castSucc
      let sRat : ℚ := zRat (Fin.last d)
      let π := πOf v
      let blocks : Fin k → Fin (s₀ d) → ι := fun b j =>
        (enum (blkHandle p π (L_passOf v)[b.1] j)).1
      let lam : Fin k → Fin (s₀ d) → ℚ := fun b j =>
        let out := outCertOf (ωOf v) π (L_passOf v)[b.1]
        (out.words.read (.heap 1 (2 * (j.1 : ℤ))) : ℚ) /
          (out.words.read (.heap 1 (2 * (j.1 : ℤ) + 1)) : ℚ)
      have hz_coord_b : ∀ c' : Fin p.D,
          intBitLength (zRat c').num ≤ bitLenCapNat K deg_α C_z deg_alg C_cert deg_cert d B ∧
          intBitLength ((zRat c').den : ℤ) ≤ bitLenCapNat K deg_α C_z deg_alg C_cert deg_cert d B ∧
          ratBitLength (zRat c') ≤ bitLenCapNat K deg_α C_z deg_alg C_cert deg_cert d B := by
        intro c'
        obtain ⟨hd0', hzeq', hnb', hdb'⟩ := (hA1_spec (ωOf v)).2.2 c'
        obtain ⟨hnum_nb, hden_nb⟩ := ratCoordBitBounded_of_num_den_intBitLength hLz1 hd0' hzeq' hnb' hdb'
        dsimp only [zRat]
        have hLz_def : p.L_z = lzFn C_z deg_alg d B := rfl
        have h1 : intBitLength (zRatOf (ωOf v) c').num ≤ p.L_z + 1 := by
          rw [intBitLength]; split_ifs with h0
          · exact Nat.le_add_left 1 p.L_z
          · rw [Nat.add_comm 1 _]; exact Nat.succ_le_succ hnum_nb
        have h2 : intBitLength ((zRatOf (ωOf v) c').den : ℤ) ≤ p.L_z + 1 :=
          (intBitLength_natCast_le_succ _).trans (Nat.succ_le_succ hden_nb)
        have h3 : ratBitLength (zRatOf (ωOf v) c') ≤ 2 * p.L_z + 1 := by
          unfold ratBitLength; omega
        unfold bitLenCapNat
        rw [← hLz_def]
        exact ⟨by omega, by omega, by omega⟩
      refine ⟨k, oRat, sRat, blocks, lam,
        (popDepth_zero_read_heap st'.words 0 0).trans hr0, ?_, ?_, ?_, hk_quarter, ?_⟩
      · intro c
        have hr_n := (popDepth_zero_read_heap st'.words 1 (2 * (c.1 : ℤ))).trans (hr1 c.castSucc).1
        have hr_d := (popDepth_zero_read_heap st'.words 1 (2 * (c.1 : ℤ) + 1)).trans (hr1 c.castSucc).2
        obtain ⟨hb1, hb2, hb3⟩ := hz_coord_b c.castSucc
        dsimp only
        rw [hr_n, hr_d]
        exact ⟨Nat.cast_pos.mpr (Rat.den_pos _), (Rat.num_div_den (oRat c)).symm,
          by dsimp [bitLenPoly]; exact_mod_cast hb1,
          by dsimp [bitLenPoly]; exact_mod_cast hb2,
          by dsimp [bitLenPoly]; exact_mod_cast hb3⟩
      · have hr_n := (popDepth_zero_read_heap st'.words 1 (2 * (d : ℤ))).trans (hr1 (Fin.last d)).1
        have hr_d := (popDepth_zero_read_heap st'.words 1 (2 * (d : ℤ) + 1)).trans (hr1 (Fin.last d)).2
        obtain ⟨hb1, hb2, hb3⟩ := hz_coord_b (Fin.last d)
        dsimp only
        rw [hr_n, hr_d]
        exact ⟨Nat.cast_pos.mpr (Rat.den_pos _), (Rat.num_div_den sRat).symm,
          by dsimp [bitLenPoly]; exact_mod_cast hb1,
          by dsimp [bitLenPoly]; exact_mod_cast hb2,
          by dsimp [bitLenPoly]; exact_mod_cast hb3⟩
      · intro b j
        obtain ⟨h2, h30, h31⟩ := hr23 b.1 b.2 j
        have hmem_pass : (L_passOf v)[b.1] ∈ L_passOf v := List.getElem_mem b.2
        have hpass_true : passBoolOf v (L_passOf v)[b.1] = true :=
          (List.mem_filter.mp hmem_pass).2
        have hfl1 : (outCertOf (ωOf v) π (L_passOf v)[b.1]).words.read (.heap 0 0) = 1 :=
          of_decide_eq_true hpass_true
        obtain ⟨hlam_j, _⟩ := ((hCert_spec (ωOf v) π (L_passOf v)[b.1]).2.2.2 hfl1)
        obtain ⟨hd_pos, hln_b, hld_b, hlr_b⟩ := hlam_j j
        have h_uc_le : U_cert ≤ bitLenCapNat K deg_α C_z deg_alg C_cert deg_cert d B := by
          dsimp [U_cert, bitLenCapNat]; omega
        dsimp only
        refine ⟨⟨blkHandle p π (L_passOf v)[b.1] j,
          (popDepth_zero_read_heap st'.words 2 _).trans h2, rfl⟩, ?_⟩
        dsimp only [s₀, CoreParams.s₀, p] at h30 h31 ⊢
        rw [(popDepth_zero_read_heap st'.words 3 _).trans h30,
            (popDepth_zero_read_heap st'.words 3 _).trans h31]
        exact ⟨hd_pos, rfl,
          by dsimp [bitLenPoly]; exact_mod_cast hln_b.trans h_uc_le,
          by dsimp [bitLenPoly]; exact_mod_cast hld_b.trans h_uc_le,
          Nat.cast_le.mpr (show ratBitLength (lam b j) ≤ bitLenCapNat K deg_α C_z deg_alg C_cert deg_cert d B from hlr_b.trans h_uc_le)⟩
      · have hz_eq : liftedPoint (ratPointToEuclidean oRat) (sRat : ℝ) = ratPointToEuclidean zRat :=
          liftedPoint_oRat_sRat_eq zRat
        have hnodup : (L_passOf v).Nodup := (List.nodup_finRange p.r).filter (passBoolOf v)
        have hinj_blk : Function.Injective (fun x : Fin k × Fin (s₀ d) => blocks x.1 x.2) := by
          intro x₁ x₂ heq
          have henum_eq : enum (blkHandle p π (L_passOf v)[x₁.1.1] x₁.2) =
              enum (blkHandle p π (L_passOf v)[x₂.1.1] x₂.2) := Subtype.ext heq
          exact blkHandle_pair_injective p π hnodup (enum.injective henum_eq)
        have hidx_cert : ∀ b : Fin k,
            IsIndexedBlockCertificate (fun i => ratPointToEuclidean (pts i)) P₀
              (liftedPoint (ratPointToEuclidean oRat) (sRat : ℝ))
              (blocks b) (fun j => (lam b j : ℝ)) := by
          intro b
          have hmem_pass : (L_passOf v)[b.1] ∈ L_passOf v := List.getElem_mem b.2
          have hfl1 : (outCertOf (ωOf v) π (L_passOf v)[b.1]).words.read (.heap 0 0) = 1 :=
            of_decide_eq_true (List.mem_filter.mp hmem_pass).2
          obtain ⟨_, hconv⟩ := (hCert_spec (ωOf v) π (L_passOf v)[b.1]).2.2.2 hfl1
          refine ⟨fun j => (enum _).2, ?_⟩
          rw [hz_eq]
          have hfn_eq : (fun j : Fin (s₀ d) => paraboloidLift (ratPointToEuclidean (pts (blocks b j)))) =
              (fun j : Fin p.s₀ => ratPointToEuclidean
                (liftRatPoint (pts_h (blkHandle p π (L_passOf v)[b.1] j).1))) := by
            funext j
            have hh_lt : (blkHandle p π (L_passOf v)[b.1] j).1 < m := (blkHandle p π (L_passOf v)[b.1] j).2
            have hpt : pts_h (blkHandle p π (L_passOf v)[b.1] j).1 = pts (blocks b j) := by
              dsimp only [pts_h, blocks]; rw [dif_pos hh_lt]
            rw [hpt, ratPointToEuclidean_liftRatPoint]
          rwa [hfn_eq]
        obtain ⟨hcard_b, hdisj_b, hblk_cert⟩ := indexedCert_to_blockCert hinj_blk hidx_cert
        exact ⟨hcard_b, hdisj_b, fun b => ⟨hidx_cert b, hblk_cert b⟩⟩)
  have hchunks_out : ∀ (t : ℕ) (bad : Fin t → {v : Fin N_bits → Bool // acc v = false})
      (good : {v : Fin N_bits → Bool // acc v = true}),
      ∃ out : BitRAMExecOutcome,
        runBitRAMWithBits prog inp WordStore.empty (chunkList t bad good) = some out ∧
        out.unitCost ≤ (t + 1) * (U_att + 16) ∧
        out.bitCost ≤ (t + 1) * (B_att + 4 * V + 16) ∧
        out.peakCellSpace ≤ C_att ∧
        out.peakBitSpace ≤ S_att ∧
        GoodProp out.words := by
    intro t bad good
    let ws0 := WordStore.empty.popDepth 0
    let st0 : BitRAMExecState :=
      { words := ws0
        frameDepth := 0
        remainingBits := chunkList t bad good
        unitCost := 0
        bitCost := 0
        peakCellSpace := inp.inputCellSpace + ws0.cellCount
        peakBitSpace := inp.inputBitSpace + ws0.bitSize }
    have ha0 : InAttemptArena A V st0.words := inAttemptArena_popDepth_zero inAttemptArena_empty
    have hhz0 : HeapAllZero st0.words := heapAllZero_popDepth_zero heapAllZero_empty
    obtain ⟨stEnd, hr_end, hbs_end, hgood_end, hu_end, hb_end, hpc_end, hpb_end⟩ :=
      hchunks t bad good st0 rfl ha0 hhz0 rfl
    have hrun_eq := RunsTo.toRunBitRAMWithBits (ws₀ := WordStore.empty) hr_end hbs_end
    have hc0 : ws0.cellCount = 0 := by simp [ws0, WordStore.popDepth, WordStore.empty, WordStore.cellCount]
    have hb0 : ws0.bitSize = 0 := by simp [ws0, WordStore.popDepth, WordStore.empty, WordStore.bitSize]
    have hpc_cap : stEnd.peakCellSpace ≤ C_att := by
      refine hpc_end.trans (max_le ?_ le_rfl)
      dsimp [st0, C_att, attemptCellCap, arenaCellCap]
      omega
    have hpb_cap : stEnd.peakBitSpace ≤ S_att := by
      refine hpb_end.trans (max_le ?_ le_rfl)
      dsimp [st0, S_att, attemptBitSpaceCap, arenaBitCap]
      omega
    exact ⟨_, hrun_eq,
      by have h0 : st0.unitCost = 0 := rfl; rw [h0, Nat.zero_add] at hu_end; exact hu_end,
      by have h0 : st0.bitCost = 0 := rfl; rw [h0, Nat.zero_add] at hb_end; exact hb_end,
      hpc_cap, hpb_cap, hgood_end⟩
  obtain ⟨hhalt, hexpU_ne, hexpU_le, hexpB_ne, hexpB_le, hout_all⟩ :=
    retry_program_full_spec prog inp acc GoodProp (U_att + 16) (B_att + 4 * V + 16) C_att S_att
      hprob_half hchunks_out
  dsimp only
  refine ⟨hhalt, ?_, ?_, ?_, ?_, ?_⟩
  · convert hexpU_ne using 1
  · refine le_trans ?_ (show (4 : ℝ) * (U_att + 16 : ℕ) ≤ (m : ℝ) * timePoly d B by
      have hcast : ((4 * (U_att + 16) : ℕ) : ℝ) ≤
          ((m * exactTimeCapNat K₀ deg_α₀ C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c d B : ℕ) : ℝ) :=
        Nat.cast_le.mpr hunit_le
      simpa [timePoly, Nat.cast_mul, Nat.cast_add] using hcast)
    convert hexpU_le using 1
  · convert hexpB_ne using 1
  · refine le_trans ?_ (show (4 : ℝ) * (B_att + 4 * V + 16 : ℕ) ≤ (m : ℝ) * ((w : ℝ) ^ 2) * timePoly d B by
      have hcast : ((4 * (B_att + 4 * V + 16) : ℕ) : ℝ) ≤
          ((m * w ^ 2 * exactTimeCapNat K₀ deg_α₀ C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c F_sz F_A1 F_c d B : ℕ) : ℝ) :=
        Nat.cast_le.mpr hbitc_le
      simpa [timePoly, Nat.cast_mul, Nat.cast_add, Nat.cast_pow] using hcast)
    convert hexpB_le using 1
  · intro bs out hrun
    obtain ⟨hpc, hpb, hg⟩ := hout_all bs out hrun
    refine ⟨?_, ?_, hg⟩
    · have hc := hpc.trans hcell_le
      have hcast : (out.peakCellSpace : ℝ) ≤
          ((m * spaceCapNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c d B : ℕ) : ℝ) :=
        Nat.cast_le.mpr hc
      simpa [spacePoly, Nat.cast_mul] using hcast
    · have hb := hpb.trans hbitsp_le
      have hcast : (out.peakBitSpace : ℝ) ≤
          ((m * w * spaceCapNat K deg_α C_z deg_alg k_φ C_cert deg_cert T_sz T_A1 T_c d B : ℕ) : ℝ) :=
        Nat.cast_le.mpr hb
      simpa [spacePoly, Nat.cast_mul] using hcast

end UL.Proof_lem_A_2
