import Mathlib
import UL.Proof.lem_A_2.RacerP54_H3g
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 1200000

namespace UL.Proof_lem_A_2

/-! ### 1. Small bit-length helper for `HasZArray` -/

theorem intBitLength_pred_pos {n : ℕ} (hn : 1 ≤ n) :
    intBitLength ((n : ℤ) - 1) ≤ intBitLength (n : ℤ) := by
  rcases eq_or_lt_of_le hn with rfl | hn2
  · norm_num
    exact intBitLength_pos 1
  · have hsub : ((n : ℤ) - 1) = ((n - 1 : ℕ) : ℤ) := by omega
    rw [hsub]
    exact intBitLength_natCast_mono (Nat.sub_le n 1)

theorem hz_V_of_hasZArray {A V D : ℕ} {zRat : Fin D → ℚ} {ws : WordStore}
    (ha : InAttemptArena A V ws) (hV1 : 1 ≤ V) (hz : HasZArray D zRat ws) (c : Fin D) :
    intBitLength (zRat c).num ≤ V ∧ intBitLength (((zRat c).den : ℤ) - 1) ≤ V := by
  have h1 := inAttemptArena_read_bitLen_le ha hV1 (.localFrame 1 4 (2 * (c.1 : ℤ)))
  have h2 := inAttemptArena_read_bitLen_le ha hV1 (.localFrame 1 4 (2 * (c.1 : ℤ) + 1))
  rw [(hz c).1] at h1
  rw [(hz c).2] at h2
  exact ⟨h1, (intBitLength_pred_pos (Rat.den_pos (zRat c))).trans h2⟩

/-! ### 2. `copyLocalToHeapStmt` and its `ExecBounded` specification -/

def copyLocalToHeapBody (t srcVar : ℕ) : BitRAMStmt :=
  .seq
    (.writeHeap t (.readLocal 9 (.lit 0)) (.readLocal srcVar (.readLocal 9 (.lit 0))))
    (.writeLocal 9 (.lit 0) (.add (.readLocal 9 (.lit 0)) (.lit 1)))

def copyLocalToHeapStmt (t srcVar : ℕ) (cntE : IntExpr) : BitRAMStmt :=
  .seq
    (.writeLocal 9 (.lit 0) (.lit 0))
    (.repeatN cntE (copyLocalToHeapBody t srcVar))

theorem exec_copyLocalToHeap {d A V : ℕ} {inp : BitRAMInput d}
    {ws₀ : WordStore} {bs : List Bool}
    {t srcVar : ℕ} {cntE : IntExpr} (N : ℕ)
    (harena : InAttemptArena A V ws₀)
    (hinp : ArenaInputOK A V inp)
    (ht : t < 8)
    (hsrc : srcVar < 100 ∧ srcVar ≠ 9)
    (hNA : N ≤ A)
    (hin_cnt : ExprInArena V cntE)
    (hnodes_cnt : exprNodes cntE ≤ 16)
    (hcnt_pres : evalVal inp (ws₀.write (.localFrame 1 9 0) 0) cntE = (N : ℤ)) :
    ∃ ws₁ : WordStore,
      InAttemptArena A V ws₁ ∧
      (∀ i : ℕ, i < N → ws₁.read (.heap t (i : ℤ)) = ws₀.read (.localFrame 1 srcVar (i : ℤ))) ∧
      (∀ (t' : ℕ) (idx : ℤ), t' ≠ t → ws₁.read (.heap t' idx) = ws₀.read (.heap t' idx)) ∧
      (∀ (var : ℕ) (idx : ℤ), (var ≠ 9 ∨ idx ≠ 0) →
        ws₁.read (.localFrame 1 var idx) = ws₀.read (.localFrame 1 var idx)) ∧
      ExecBounded inp (copyLocalToHeapStmt t srcVar cntE) ws₀ bs ws₁ bs
        (200 + 200 * N) ((200000 + 200000 * N) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have h16A := hinp.1
  have hVA := hinp.2.1
  have hV16 : 16 ≤ V := by omega
  obtain ⟨ha_init, ex_init⟩ := exec_writeLocal_auto (var := 9) (idxE := (.lit 0)) (idx := 0) (valE := (.lit 0)) (val := 0) harena hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl rfl (by decide) (by positivity)
    (by rw [Int.toNat_zero]; omega) (by change 1 ≤ V; omega)
  let wsInit := ws₀.write (.localFrame 1 9 0) 0
  let Inv : ℕ → WordStore → List Bool → Prop := fun k ws_k bs_k =>
    bs_k = bs ∧
    InAttemptArena A V ws_k ∧
    ws_k.read (.localFrame 1 9 0) = (k : ℤ) ∧
    (∀ i : ℕ, i < k → ws_k.read (.heap t (i : ℤ)) = ws₀.read (.localFrame 1 srcVar (i : ℤ))) ∧
    (∀ (t' : ℕ) (idx : ℤ), t' ≠ t → ws_k.read (.heap t' idx) = ws₀.read (.heap t' idx)) ∧
    (∀ (var : ℕ) (idx : ℤ), (var ≠ 9 ∨ idx ≠ 0) →
      ws_k.read (.localFrame 1 var idx) = ws₀.read (.localFrame 1 var idx))
  have hInv0 : Inv 0 wsInit bs := by
    refine ⟨rfl, ha_init, wordStore_read_write_self ws₀ _ 0, fun _ h => by omega, ?_, ?_⟩
    · intro t' idx _
      exact rw_heap_local ws₀ t' idx 1 9 0 0
    · intro var idx hne
      refine wordStore_read_write_of_ne ws₀ (fun h => ?_) 0
      injection h with _ hv hi
      rcases hne with hv' | hi' <;> omega
  obtain ⟨ws₁, bs₁, hInvN, ex_loop⟩ := exec_repeatN_inv (bs₀ := bs) (countE := cntE) (body := (copyLocalToHeapBody t srcVar)) N Inv ha_init hinp
    hin_cnt hnodes_cnt hcnt_pres hInv0 (fun k ws_k bs_k hk hInv_k => by
      rcases hInv_k with ⟨hbs_k, ha_k, hr9, hcopied, hheap_other, hloc_other⟩
      subst bs_k
      have hsrc_val : ws_k.read (.localFrame 1 srcVar (k : ℤ)) =
          ws₀.read (.localFrame 1 srcVar (k : ℤ)) :=
        hloc_other srcVar (k : ℤ) (Or.inl hsrc.2)
      obtain ⟨ha_mid, ex_wh⟩ := exec_writeHeap_auto (t := t) (idxE := (.readLocal 9 (.lit 0))) (idx := (k : ℤ)) (valE := (.readLocal srcVar (.readLocal 9 (.lit 0)))) (val := ws₀.read (.localFrame 1 srcVar (k : ℤ))) ha_k hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (show ExprInArena V (.readLocal srcVar (.readLocal 9 (.lit 0))) from
          ⟨hsrc.1, exprInArena_small (by decide) (by decide) hV16⟩)
        ⟨by simp [exprNodes], by simp [exprNodes]⟩
        (by simp [hr9])
        (by simp [hr9, hsrc_val])
        ht (by positivity) (by rw [Int.toNat_natCast]; omega)
        (inAttemptArena_read_bitLen_le harena (by omega) (.localFrame 1 srcVar (k : ℤ)))
      let ws_mid := ws_k.write (.heap t (k : ℤ)) (ws₀.read (.localFrame 1 srcVar (k : ℤ)))
      have hr9_mid : ws_mid.read (.localFrame 1 9 0) = (k : ℤ) :=
        (rw_local_heap ws_k 1 9 0 t (k : ℤ) _).trans hr9
      have hk1_V : intBitLength (((k + 1 : ℕ) : ℤ)) ≤ V :=
        (intBitLength_natCast_le_succ (k + 1)).trans
          (by have := natBitLength_mono (by omega : k + 1 ≤ A); omega)
      obtain ⟨ha_next, ex_inc⟩ := exec_writeLocal_auto (var := 9) (idxE := (.lit 0)) (idx := 0) (valE := (.add (.readLocal 9 (.lit 0)) (.lit 1))) (val := ((k + 1 : ℕ) : ℤ)) ha_mid hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by simp [exprNodes], by simp [exprNodes]⟩
        rfl
        (show evalVal inp ws_mid (.add (.readLocal 9 (.lit 0)) (.lit 1)) = (((k + 1 : ℕ) : ℤ)) by
          simp [hr9_mid]; try push_cast; try ring)
        (by decide) (by positivity) (by rw [Int.toNat_zero]; omega) hk1_V
      let ws_next := ws_mid.write (.localFrame 1 9 0) (((k + 1 : ℕ) : ℤ))
      refine ⟨ws_next, bs, ⟨rfl, ha_next, wordStore_read_write_self ws_mid _ _, ?_, ?_, ?_⟩,
        ExecBounded.seq ex_wh ex_inc⟩
      · intro i hi
        rw [rw_heap_local]
        rcases eq_or_lt_of_le (Nat.lt_succ_iff.mp hi) with hieq | hi_lt
        · subst i; exact wordStore_read_write_self ws_k _ _
        · rw [wordStore_read_write_of_ne ws_k (by intro h; injection h with _ heq; omega)]
          exact hcopied i hi_lt
      · intro t' idx hne_t
        rw [rw_heap_local,
          wordStore_read_write_of_ne ws_k (by intro h; injection h with ht' _; exact hne_t ht')]
        exact hheap_other t' idx hne_t
      · intro var idx hne_v
        rw [wordStore_read_write_of_ne ws_mid (by
          intro h; injection h with _ hv hi; rcases hne_v with hv' | hi' <;> omega),
          rw_local_heap]
        exact hloc_other var idx hne_v)
  rcases hInvN with ⟨rfl, ha₁, _, hcp₁, hho₁, hlo₁⟩
  have htot := ExecBounded.seq ex_init ex_loop
  refine ⟨ws₁, ha₁, hcp₁, hho₁, hlo₁, ExecBounded.mono htot (by omega) ?_ le_rfl le_rfl⟩
  have hcoef : 66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + N * (66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2)) =
      (132000 + 132000 * N) * (V + 8) ^ 2 := by ring
  rw [hcoef]
  exact Nat.mul_le_mul_right _ (by omega)

/-! ### 3. `phase6Stmt` and `exec_phase6Stmt` -/

def phase6AcceptStmt : BitRAMStmt :=
  .seq (copyLocalToHeapStmt 1 4 (.readLocal 0 (.lit 14)))
  (.seq (.writeLocal 9 (.lit 1) (.mul (.readLocal 1 (.lit 14)) (.readLocal 0 (.lit 5))))
  (.seq (copyLocalToHeapStmt 2 7 (.readLocal 9 (.lit 1)))
  (.seq (.writeLocal 9 (.lit 2) (.mul (.lit 2) (.readLocal 9 (.lit 1))))
  (.seq (copyLocalToHeapStmt 3 8 (.readLocal 9 (.lit 2)))
        (.writeHeap 0 (.lit 0) (.readLocal 1 (.lit 14)))))))

def phase6Stmt : BitRAMStmt :=
  .ite (.intLe (.readLocal 0 (.lit 6)) (.mul (.lit 2) (.readLocal 1 (.lit 14))))
    phase6AcceptStmt
    .skip

theorem exec_phase6Stmt {A V M : ℕ} (p : CoreParams)
    (zRat : Fin p.D → ℚ) (π : Equiv.Perm (Fin p.m))
    (outCert : Fin p.r → BitRAMExecOutcome) (L_pass : List (Fin p.r))
    {inp : BitRAMInput p.d} {ws₆ : WordStore} {bs : List Bool}
    (harena : InAttemptArena A V ws₆)
    (hhz : HeapAllZero ws₆)
    (hregs : HasPhase2Regs p M ws₆)
    (hz : HasZArray p.D zRat ws₆)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hlen_le : L_pass.length ≤ p.r)
    (hk_pass : ws₆.read (.localFrame 1 1 14) = (L_pass.length : ℤ))
    (hpass_data : ∀ (i : ℕ) (hi : i < L_pass.length) (j : Fin p.s₀),
      let flatIdx : ℤ := ((i * p.s₀ + j.1 : ℕ) : ℤ)
      ws₆.read (.localFrame 1 7 flatIdx) = ((blkHandle p π L_pass[i] j).1 : ℤ) ∧
      ws₆.read (.localFrame 1 8 (2 * flatIdx)) =
        (outCert L_pass[i]).words.read (.heap 1 (2 * (j.1 : ℤ))) ∧
      ws₆.read (.localFrame 1 8 (2 * flatIdx + 1)) =
        (outCert L_pass[i]).words.read (.heap 1 (2 * (j.1 : ℤ) + 1))) :
    ∃ ws₇ : WordStore,
      InAttemptArena A V ws₇ ∧
      (if p.r ≤ 2 * L_pass.length then
        ws₇.read (.heap 0 0) = (L_pass.length : ℤ) ∧
        (∀ c : Fin p.D,
          ws₇.read (.heap 1 (2 * (c.1 : ℤ))) = (zRat c).num ∧
          ws₇.read (.heap 1 (2 * (c.1 : ℤ) + 1)) = ((zRat c).den : ℤ)) ∧
        (∀ (i : ℕ) (hi : i < L_pass.length) (j : Fin p.s₀),
          let flatIdx : ℤ := ((i * p.s₀ + j.1 : ℕ) : ℤ)
          ws₇.read (.heap 2 flatIdx) = ((blkHandle p π L_pass[i] j).1 : ℤ) ∧
          ws₇.read (.heap 3 (2 * flatIdx)) =
            (outCert L_pass[i]).words.read (.heap 1 (2 * (j.1 : ℤ))) ∧
          ws₇.read (.heap 3 (2 * flatIdx + 1)) =
            (outCert L_pass[i]).words.read (.heap 1 (2 * (j.1 : ℤ) + 1)))
      else
        HeapAllZero ws₇) ∧
      ExecBounded inp phase6Stmt ws₆ bs ws₇ bs
        (1500 + 600 * p.D + 800 * p.m)
        ((1500000 + 600000 * p.D + 800000 * p.m) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have h16A := hfit.2.2.2.2.1
  have hmA := hfit.2.2.2.2.2.1
  have hVA := hfit.2.2.2.2.2.2.1
  have hV16 : 16 ≤ V := by omega
  have hrs_le_m : p.r * p.s₀ ≤ p.m := Nat.div_mul_le_self p.m p.s₀
  have hks_le_m : L_pass.length * p.s₀ ≤ p.m :=
    (Nat.mul_le_mul_right p.s₀ hlen_le).trans hrs_le_m
  have hr_s0 : ws₆.read (.localFrame 1 0 5) = (p.s₀ : ℤ) := hregs.1.2.2.2.2.2.1
  have hr_r : ws₆.read (.localFrame 1 0 6) = (p.r : ℤ) := hregs.1.2.2.2.2.2.2.1
  have hr_2D : ws₆.read (.localFrame 1 0 14) = ((2 * p.D : ℕ) : ℤ) :=
    hregs.1.2.2.2.2.2.2.2.2.2.2.2.2.1
  let cond : BitCondExpr := .intLe (.readLocal 0 (.lit 6)) (.mul (.lit 2) (.readLocal 1 (.lit 14)))
  have hin_cond : CondInArena V cond :=
    ⟨exprInArena_small (by decide) (by decide) hV16,
     exprInArena_small (by decide) (by decide) hV16⟩
  have hc_eval : evalCondVal inp ws₆ cond = decide (p.r ≤ 2 * L_pass.length) := by
    simp only [cond, evalCondVal_intLe, evalVal_readLocal, evalVal_lit, evalVal_mul, hr_r, hk_pass]
    have hcast : (2 : ℤ) * (L_pass.length : ℤ) = ((2 * L_pass.length : ℕ) : ℤ) := by try push_cast; try ring
    rw [hcast]
    exact decide_eq_decide.mpr Int.ofNat_le
  by_cases hp : p.r ≤ 2 * L_pass.length
  · have hc_true : evalCondVal inp ws₆ cond = true := by rw [hc_eval]; exact decide_eq_true hp
    obtain ⟨wsA, haA, hcpA, hhoA, hloA, exA⟩ := exec_copyLocalToHeap (bs := bs) (t := 1) (srcVar := 4) (cntE := .readLocal 0 (.lit 14)) (2 * p.D) harena hinp
      (by decide : 1 < 8) ⟨by decide, by decide⟩ (by omega)
      (exprInArena_small (by decide) (by decide) hV16) (by decide)
      (by simp [rw_write_eq, hr_2D])
    have hk_A : wsA.read (.localFrame 1 1 14) = (L_pass.length : ℤ) :=
      (hloA 1 14 (Or.inl (by decide))).trans hk_pass
    have hs0_A : wsA.read (.localFrame 1 0 5) = (p.s₀ : ℤ) :=
      (hloA 0 5 (Or.inl (by decide))).trans hr_s0
    let N₂ : ℕ := L_pass.length * p.s₀
    have hN2_V : intBitLength ((N₂ : ℕ) : ℤ) ≤ V :=
      (intBitLength_natCast_le_succ N₂).trans
        (by have := natBitLength_mono (by omega : N₂ ≤ A); omega)
    obtain ⟨haB, exB⟩ := exec_writeLocal_auto (bs := bs) (var := 9) (idxE := .lit 1) (idx := 1) (valE := .mul (.readLocal 1 (.lit 14)) (.readLocal 0 (.lit 5))) (val := (N₂ : ℤ)) haA hinp
      (exprInArena_small (by decide) (by decide) hV16)
      (exprInArena_small (by decide) (by decide) hV16)
      ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
      (show evalVal inp wsA (.mul (.readLocal 1 (.lit 14)) (.readLocal 0 (.lit 5))) = (N₂ : ℤ) by
        simp [hk_A, hs0_A, N₂])
      (by decide) (by positivity) (by rw [Int.toNat_one]; omega) hN2_V
    let wsB := wsA.write (.localFrame 1 9 1) (N₂ : ℤ)
    have hr91_B : wsB.read (.localFrame 1 9 1) = (N₂ : ℤ) := wordStore_read_write_self wsA _ _
    obtain ⟨wsC, haC, hcpC, hhoC, hloC, exC⟩ := exec_copyLocalToHeap (bs := bs) (t := 2) (srcVar := 7) (cntE := .readLocal 9 (.lit 1)) N₂ haB hinp
      (by decide : 2 < 8) ⟨by decide, by decide⟩ (by omega)
      (exprInArena_small (by decide) (by decide) hV16) (by decide)
      (by simp [wsB, rw_write_eq, hr91_B])
    have hr91_C : wsC.read (.localFrame 1 9 1) = (N₂ : ℤ) :=
      (hloC 9 1 (Or.inr (by decide))).trans hr91_B
    let N₃ : ℕ := 2 * N₂
    have hN3_V : intBitLength ((N₃ : ℕ) : ℤ) ≤ V :=
      (intBitLength_natCast_le_succ N₃).trans
        (by have := natBitLength_mono (by omega : N₃ ≤ A); omega)
    obtain ⟨haD, exD⟩ := exec_writeLocal_auto (bs := bs) (var := 9) (idxE := .lit 2) (idx := 2) (valE := .mul (.lit 2) (.readLocal 9 (.lit 1))) (val := (N₃ : ℤ)) haC hinp
      (exprInArena_small (by decide) (by decide) hV16)
      (exprInArena_small (by decide) (by decide) hV16)
      ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
      (show evalVal inp wsC (.mul (.lit 2) (.readLocal 9 (.lit 1))) = (N₃ : ℤ) by
        simp [hr91_C, N₃]; try push_cast; try ring)
      (by decide) (by positivity) (by change (2 : ℕ) < A; omega) hN3_V
    let wsD := wsC.write (.localFrame 1 9 2) (N₃ : ℤ)
    have hr92_D : wsD.read (.localFrame 1 9 2) = (N₃ : ℤ) := wordStore_read_write_self wsC _ _
    obtain ⟨wsE, haE, hcpE, hhoE, hloE, exE⟩ := exec_copyLocalToHeap (bs := bs) (t := 3) (srcVar := 8) (cntE := .readLocal 9 (.lit 2)) N₃ haD hinp
      (by decide : 3 < 8) ⟨by decide, by decide⟩ (by omega)
      (exprInArena_small (by decide) (by decide) hV16) (by decide)
      (by simp [wsD, rw_write_eq, hr92_D])
    have hk_E : wsE.read (.localFrame 1 1 14) = (L_pass.length : ℤ) := by
      rw [hloE 1 14 (Or.inl (by decide)),
        rw_local_var_ne wsC (by decide),
        hloC 1 14 (Or.inl (by decide)),
        rw_local_var_ne wsA (by decide)]
      exact hk_A
    have hs0_pos : 1 ≤ p.s₀ := s₀Val_pos (deg_α := p.deg_α) hfit.1 p.d
    have hk_le_ks : L_pass.length ≤ L_pass.length * p.s₀ := Nat.le_mul_of_pos_right _ hs0_pos
    have hk_V : intBitLength (L_pass.length : ℤ) ≤ V :=
      (intBitLength_natCast_le_succ L_pass.length).trans
        (by have := natBitLength_mono (by omega : L_pass.length ≤ A); omega)
    obtain ⟨haF, exF⟩ := exec_writeHeap_auto (bs := bs) (t := 0) (idxE := .lit 0) (idx := 0) (valE := .readLocal 1 (.lit 14)) (val := (L_pass.length : ℤ)) haE hinp
      (exprInArena_small (by decide) (by decide) hV16)
      (exprInArena_small (by decide) (by decide) hV16)
      ⟨by simp [exprNodes], by simp [exprNodes]⟩ rfl
      (by simp [hk_E])
      (by decide : 0 < 8) (by positivity) (by rw [Int.toNat_zero]; omega) hk_V
    let ws₇ := wsE.write (.heap 0 0) (L_pass.length : ℤ)
    have ex_acc : ExecBounded inp phase6AcceptStmt ws₆ bs ws₇ bs
        (804 + 200 * (2 * p.D) + 200 * N₂ + 200 * N₃)
        ((798000 + 200000 * (2 * p.D) + 200000 * N₂ + 200000 * N₃) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
      have hseq := ExecBounded.seq exA
        (ExecBounded.seq exB
          (ExecBounded.seq exC
            (ExecBounded.seq exD
              (ExecBounded.seq exE exF))))
      refine ExecBounded.mono hseq (by omega) ?_ le_rfl le_rfl
      apply le_of_eq; ring
    have ex_ite := exec_ite_auto (cond := cond) (tB := phase6AcceptStmt) (fB := .skip) harena hinp hin_cond (by decide) hc_true
      (by rw [if_pos rfl]; exact ex_acc)
    refine ⟨ws₇, haF, ?_, ExecBounded.mono ex_ite (by dsimp [N₃, N₂]; omega) ?_ le_rfl le_rfl⟩
    · rw [if_pos hp]
      refine ⟨wordStore_read_write_self wsE _ _, ?_, ?_⟩
      · intro c
        have hc0 : 2 * c.1 < 2 * p.D := by omega
        have hc1 : 2 * c.1 + 1 < 2 * p.D := by omega
        have hr1_0 : ws₇.read (.heap 1 (2 * (c.1 : ℤ))) = ws₆.read (.localFrame 1 4 (2 * (c.1 : ℤ))) := by
          have hcast0 : (2 * (c.1 : ℤ)) = (((2 * c.1 : ℕ) : ℤ)) := by try push_cast; try ring
          dsimp only [ws₇, wsD, wsB]
          rw [wordStore_read_write_of_ne wsE (by intro h; injection h; intros; omega),
            hhoE 1 _ (by decide), rw_heap_local, hhoC 1 _ (by decide), rw_heap_local,
            hcast0, hcpA (2 * c.1) hc0]
        have hr1_1 : ws₇.read (.heap 1 (2 * (c.1 : ℤ) + 1)) = ws₆.read (.localFrame 1 4 (2 * (c.1 : ℤ) + 1)) := by
          have hcast1 : (2 * (c.1 : ℤ) + 1) = (((2 * c.1 + 1 : ℕ) : ℤ)) := by try push_cast; try ring
          dsimp only [ws₇, wsD, wsB]
          rw [wordStore_read_write_of_ne wsE (by intro h; injection h; intros; omega),
            hhoE 1 _ (by decide), rw_heap_local, hhoC 1 _ (by decide), rw_heap_local,
            hcast1, hcpA (2 * c.1 + 1) hc1]
        exact ⟨hr1_0.trans (hz c).1, hr1_1.trans (hz c).2⟩
      · intro i hi j
        have hfl_lt : i * p.s₀ + j.1 < N₂ := by
          dsimp [N₂]
          calc i * p.s₀ + j.1 < i * p.s₀ + p.s₀ := Nat.add_lt_add_left j.2 _
            _ = (i + 1) * p.s₀ := by ring
            _ ≤ L_pass.length * p.s₀ := Nat.mul_le_mul_right _ hi
        have h2fl_0 : 2 * (i * p.s₀ + j.1) < N₃ := by dsimp [N₃]; omega
        have h2fl_1 : 2 * (i * p.s₀ + j.1) + 1 < N₃ := by dsimp [N₃]; omega
        obtain ⟨hp7, hp8_0, hp8_1⟩ := hpass_data i hi j
        dsimp only at hp7 hp8_0 hp8_1 ⊢
        set fNat := i * p.s₀ + j.1
        have hr2 : ws₇.read (.heap 2 (fNat : ℤ)) = ws₆.read (.localFrame 1 7 (fNat : ℤ)) := by
          dsimp only [ws₇, wsD, wsB]
          rw [wordStore_read_write_of_ne wsE (by intro h; injection h; intros; omega),
            hhoE 2 _ (by decide), rw_heap_local, hcpC fNat hfl_lt,
            rw_local_var_ne wsA (by decide), hloA 7 _ (Or.inl (by decide))]
        have hr3_0 : ws₇.read (.heap 3 (2 * (fNat : ℤ))) = ws₆.read (.localFrame 1 8 (2 * (fNat : ℤ))) := by
          have hc0 : (2 * (fNat : ℤ)) = (((2 * fNat : ℕ) : ℤ)) := by try push_cast; try ring
          dsimp only [ws₇, wsD, wsB]
          rw [wordStore_read_write_of_ne wsE (by intro h; injection h; intros; omega),
            hc0, hcpE (2 * fNat) h2fl_0,
            rw_local_var_ne wsC (by decide), hloC 8 _ (Or.inl (by decide)),
            rw_local_var_ne wsA (by decide), hloA 8 _ (Or.inl (by decide))]
        have hr3_1 : ws₇.read (.heap 3 (2 * (fNat : ℤ) + 1)) =
            ws₆.read (.localFrame 1 8 (2 * (fNat : ℤ) + 1)) := by
          have hc1 : (2 * (fNat : ℤ) + 1) = (((2 * fNat + 1 : ℕ) : ℤ)) := by try push_cast; try ring
          dsimp only [ws₇, wsD, wsB]
          rw [wordStore_read_write_of_ne wsE (by intro h; injection h; intros; omega),
            hc1, hcpE (2 * fNat + 1) h2fl_1,
            rw_local_var_ne wsC (by decide), hloC 8 _ (Or.inl (by decide)),
            rw_local_var_ne wsA (by decide), hloA 8 _ (Or.inl (by decide))]
        exact ⟨hr2.trans hp7, hr3_0.trans hp8_0, hr3_1.trans hp8_1⟩
    · have hring : 66000 * (V + 8) ^ 2 +
          (798000 + 200000 * (2 * p.D) + 200000 * N₂ + 200000 * N₃) * (V + 8) ^ 2 =
          (864000 + 400000 * p.D + 600000 * N₂) * (V + 8) ^ 2 := by
        dsimp [N₃]; ring
      rw [hring]
      exact Nat.mul_le_mul_right _ (by dsimp [N₂]; omega)
  · have hc_false : evalCondVal inp ws₆ cond = false := by
      rw [hc_eval]; exact decide_eq_false hp
    have ex_sk : ExecBounded inp (if false then phase6AcceptStmt else .skip) ws₆ bs ws₆ bs
        1 1 (arenaCellCap inp A) (arenaBitCap inp A V) :=
      ExecBounded.skip inp ws₆ bs _ _
    have ex_ite := exec_ite_auto (cond := cond) (tB := phase6AcceptStmt) (fB := .skip) harena hinp hin_cond (by decide) hc_false ex_sk
    refine ⟨ws₆, harena, ?_, ExecBounded.mono ex_ite (by omega) ?_ le_rfl le_rfl⟩
    · rw [if_neg hp]; exact hhz
    · have h1 : 1 ≤ (V + 8) ^ 2 := Nat.succ_le_of_lt (by positivity)
      have h2 : 66000 * (V + 8) ^ 2 + 1 ≤ 66001 * (V + 8) ^ 2 := by omega
      exact h2.trans (Nat.mul_le_mul_right _ (by omega))

/-! ### 4. Complete single-attempt statement `attemptBodyStmt` and `.localScope` execution -/

def attemptBodyStmt (K deg_α C_z deg_alg k_φ : ℕ)
    (sizeProg prog_A1 progCert : BitRAMStmt) : BitRAMStmt :=
  .seq (phase0Stmt K deg_α C_z deg_alg)
  (.seq phase1Stmt
  (.seq (phase2Stmt k_φ sizeProg)
  (.seq (phase3Stmt k_φ prog_A1)
  (.seq phase4Stmt
  (.seq (phase5Stmt progCert)
        phase6Stmt)))))

def attemptUnitCap (p : CoreParams) (M F_sz F_A1 F_c U_sz U_A1 U_cert : ℕ) : ℕ :=
  (32 * (p.w + 1) + 400 * (p.deg_α + p.deg_alg + 16)) +
  (300 + p.m * (1000 + 500 * p.d + 60 * p.B_lift)) +
  (80 * F_sz * (U_sz + 1) + 32 * (Nat.clog 2 (M + 1) + 1) + 1000) +
  (2000 + M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1)) +
    p.D * (1000 + 50 * p.L_z) + 80 * F_A1 * (U_A1 + 1)) +
  (600 + p.m * (900 + 24 * (p.W₂ + 1))) +
  (2000 + 800 * (p.D + p.s₀ * p.D) +
    p.r * (2000 + p.s₀ * (1500 + 300 * p.d) + 80 * F_c * (U_cert + 1))) +
  (1500 + 600 * p.D + 800 * p.m)

def attemptBitCap (p : CoreParams) (V M T_sz T_A1 T_c F_sz F_A1 F_c U_sz U_A1 U_cert : ℕ) : ℕ :=
  ((4000000 + 400000 * (p.deg_α + p.deg_alg)) * (V + 8) ^ 2) +
  ((300000 + p.m * (1000000 + 500000 * p.d + 600 * p.B_lift)) * (V + 8) ^ 2) +
  (256 * F_sz * (V + natBitLength T_sz + 8) ^ 2 * (2 * U_sz + 16) * U_sz +
    (U_sz + 2) * (8 * natBitLength (U_sz + 2) + 4 * (U_sz + 2 * natBitLength T_sz + 6) + 80) +
    1000000 * (V + natBitLength T_sz + 16) ^ 2) +
  ((2000000 + M * (1200000 + 600000 * p.d) + p.D * (1000000 + 600 * p.L_z)) *
    (V + natBitLength T_A1 + 16) ^ 2 +
    256 * F_A1 * (V + natBitLength T_A1 + 8) ^ 2 * (2 * U_A1 + 16) * U_A1 +
    (U_A1 + 2) * (8 * natBitLength (U_A1 + 2) + 4 * (U_A1 + 2 * natBitLength T_A1 + 6) + 80)) +
  ((400000 + p.m * 900000) * (V + 8) ^ 2) +
  ((2000000 + 800000 * (p.D + p.s₀ * p.D)) * (V + natBitLength T_c + 16) ^ 2 +
    p.r * ((2000000 + p.s₀ * (1500000 + 300000 * p.d)) * (V + natBitLength T_c + 16) ^ 2 +
      256 * F_c * (V + natBitLength T_c + 8) ^ 2 * (2 * U_cert + 16) * U_cert +
      (U_cert + 2) * (8 * natBitLength (U_cert + 2) + 4 * (U_cert + 2 * natBitLength T_c + 6) + 80))) +
  ((1500000 + 600000 * p.D + 800000 * p.m) * (V + 8) ^ 2)

def attemptCellCap {d : ℕ} (inp : BitRAMInput d) (A U_sz U_A1 U_cert : ℕ) : ℕ :=
  arenaCellCap inp A + 2 * (U_sz + U_A1 + U_cert) + 8

def attemptBitSpaceCap {d : ℕ} (inp : BitRAMInput d)
    (A V T_sz T_A1 T_c U_sz U_A1 U_cert : ℕ) : ℕ :=
  arenaBitCap inp A V +
  ((natBitLength T_sz + 12) * U_sz +
    (U_sz + 3) * (natBitLength (U_sz + 2) + U_sz + 2 * natBitLength T_sz + 18) +
    2 * natBitLength (U_sz + 2) + 64) +
  ((natBitLength T_A1 + 12) * U_A1 +
    (U_A1 + 3) * (natBitLength (U_A1 + 2) + U_A1 + 2 * natBitLength T_A1 + 18) +
    2 * natBitLength (U_A1 + 2) + 64) +
  ((natBitLength T_c + 12) * U_cert +
    (U_cert + 3) * (natBitLength (U_cert + 2) + U_cert + 2 * natBitLength T_c + 18) +
    2 * natBitLength (U_cert + 2) + 64)

theorem exec_localScope_attempt {A V M U_sz U_A1 U_cert : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ)
    (sizeProg prog_A1 progCert : BitRAMStmt)
    {sizeOut outA1 : BitRAMExecOutcome} (zRat : Fin p.D → ℚ)
    (outCert : Fin p.r → BitRAMExecOutcome)
    (v : Fin (M * p.W₁ M + p.m * p.W₂) → Bool) (restBits : List Bool)
    {inp : BitRAMInput p.d} {st : BitRAMExecState}
    (hfd0 : st.frameDepth = 0)
    (harena : InAttemptArena A V st.words)
    (hhz : HeapAllZero st.words)
    (hbits : st.remainingBits = List.ofFn v ++ restBits)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hip_params : inp.intParams = [(p.m : ℤ), (p.B : ℤ)])
    (hip_handles : inp.activeHandles = Finset.range p.m)
    (hip_coords : ∀ h : ℕ, h < p.m → inp.activeRatCoords h = pts_h h)
    (hpts_b : ∀ h : ℕ, h < p.m → RatPointBitBounded p.B (pts_h h))
    (hrun_sz : runBitRAMWithBits sizeProg
      (BitRAMInput.ofIntParams [(p.D : ℤ), (p.B_lift : ℤ), (p.k_φ : ℤ)])
      WordStore.empty [] = some sizeOut)
    (hM_out : sizeOut.words.read (.heap 0 0) = (M : ℤ))
    (hsz_bounds : sizeOut.unitCost ≤ U_sz ∧ sizeOut.bitCost ≤ U_sz ∧
      sizeOut.peakCellSpace ≤ U_sz ∧ sizeOut.peakBitSpace ≤ U_sz)
    (h2_fit : intBitLength ((M + 1 : ℕ) : ℤ) ≤ V ∧
      natBitLength (2 ^ Nat.clog 2 (M + 1)) + 2 ≤ V ∧
      p.w + Nat.clog 2 (M + 1) + 16 ≤ V)
    (h3_fit : 1 ≤ M ∧ M * p.D + 4 ≤ A ∧ p.W₁ M + 4 ≤ V ∧ 2 * p.L_z + 16 ≤ V ∧ U_A1 + 2 ≤ V)
    (h5_fit : p.D + p.s₀ * p.D + 4 ≤ A ∧ U_cert + 2 ≤ V)
    (hrun_A1 :
      let hm_pos : 0 < p.m := by
        have hs1 := s₀Val_pos (deg_α := p.deg_α) hfit.1 p.d; have hm2 := hfit.2.2.2.1
        dsimp [CoreParams.s₀] at hm2; omega
      let sp := splitAttemptBits M (p.W₁ M) p.m p.W₂ v
      let ω : Fin M → Fin p.m := fun j =>
        ⟨bitsToNat (p.W₁ M) (sp.1 j) % p.m, Nat.mod_lt _ hm_pos⟩
      runBitRAMWithBits prog_A1
        { intParams := [(p.B_lift : ℤ), (p.k_φ : ℤ), (M : ℤ)]
          activeHandles := Finset.range M
          activeRatCoords := fun j =>
            if hj : j < M then liftRatPoint (pts_h (ω ⟨j, hj⟩).1) else fun _ => 0
          extraRats := [] }
        WordStore.empty [] = some outA1)
    (ha1_bounds : outA1.unitCost ≤ U_A1 ∧ outA1.bitCost ≤ U_A1 ∧
      outA1.peakCellSpace ≤ U_A1 ∧ outA1.peakBitSpace ≤ U_A1)
    (hz_out : ∀ c : Fin p.D,
      let zNum := outA1.words.read (.heap 1 (2 * (c.1 : ℤ)))
      let zDen := outA1.words.read (.heap 1 (2 * (c.1 : ℤ) + 1))
      0 < zDen ∧ zRat c = (zNum : ℚ) / (zDen : ℚ) ∧
      intBitLength zNum ≤ p.L_z ∧ intBitLength zDen ≤ p.L_z)
    (hrun_cert :
      let sp := splitAttemptBits M (p.W₁ M) p.m p.W₂ v
      let u : (i : Fin p.m) → Fin (p.m - i.1) := fun i =>
        ⟨bitsToNat p.W₂ (sp.2 i) % (p.m - i.1), Nat.mod_lt _ (by have := i.2; omega)⟩
      ∀ b : Fin p.r,
        runBitRAMWithBits progCert (certBlockInp p pts_h zRat (fyPerm u) b)
          WordStore.empty [] = some (outCert b))
    (hcert_bounds : ∀ b : Fin p.r,
      (outCert b).unitCost ≤ U_cert ∧ (outCert b).bitCost ≤ U_cert ∧
      (outCert b).peakCellSpace ≤ U_cert ∧ (outCert b).peakBitSpace ≤ U_cert) :
    let T_sz := maxTableStmtFull sizeProg
    let T_A1 := maxTableStmtFull prog_A1
    let T_c := maxTableStmtFull progCert
    let F_sz := stmtFactor sizeProg
    let F_A1 := stmtFactor prog_A1
    let F_c := stmtFactor progCert
    let sp := splitAttemptBits M (p.W₁ M) p.m p.W₂ v
    let u : (i : Fin p.m) → Fin (p.m - i.1) := fun i =>
      ⟨bitsToNat p.W₂ (sp.2 i) % (p.m - i.1), Nat.mod_lt _ (by have := i.2; omega)⟩
    let passBool : Fin p.r → Bool := fun b => decide ((outCert b).words.read (.heap 0 0) = 1)
    let L_pass : List (Fin p.r) := (List.finRange p.r).filter passBool
    ∃ st' : BitRAMExecState,
      RunsTo inp
        [.stmt (.localScope (attemptBodyStmt p.K p.deg_α p.C_z p.deg_alg p.k_φ sizeProg prog_A1 progCert))]
        st st' ∧
      st'.frameDepth = 0 ∧
      st'.remainingBits = restBits ∧
      InAttemptArena A V st'.words ∧
      st'.unitCost ≤ st.unitCost + attemptUnitCap p M F_sz F_A1 F_c U_sz U_A1 U_cert ∧
      st'.bitCost ≤ st.bitCost + attemptBitCap p V M T_sz T_A1 T_c F_sz F_A1 F_c U_sz U_A1 U_cert ∧
      st'.peakCellSpace ≤ max st.peakCellSpace (attemptCellCap inp A U_sz U_A1 U_cert) ∧
      st'.peakBitSpace ≤ max st.peakBitSpace (attemptBitSpaceCap inp A V T_sz T_A1 T_c U_sz U_A1 U_cert) ∧
      (if p.r ≤ 2 * L_pass.length then
        st'.words.read (.heap 0 0) = (L_pass.length : ℤ) ∧
        (∀ c : Fin p.D,
          st'.words.read (.heap 1 (2 * (c.1 : ℤ))) = (zRat c).num ∧
          st'.words.read (.heap 1 (2 * (c.1 : ℤ) + 1)) = ((zRat c).den : ℤ)) ∧
        (∀ (i : ℕ) (hi : i < L_pass.length) (j : Fin p.s₀),
          let flatIdx : ℤ := ((i * p.s₀ + j.1 : ℕ) : ℤ)
          st'.words.read (.heap 2 flatIdx) = ((blkHandle p (fyPerm u) L_pass[i] j).1 : ℤ) ∧
          st'.words.read (.heap 3 (2 * flatIdx)) =
            (outCert L_pass[i]).words.read (.heap 1 (2 * (j.1 : ℤ))) ∧
          st'.words.read (.heap 3 (2 * flatIdx + 1)) =
            (outCert L_pass[i]).words.read (.heap 1 (2 * (j.1 : ℤ) + 1)))
      else
        HeapAllZero st'.words) := by
  intro T_sz T_A1 T_c F_sz F_A1 F_c sp u passBool L_pass
  let C_tot := attemptCellCap inp A U_sz U_A1 U_cert
  let S_tot := attemptBitSpaceCap inp A V T_sz T_A1 T_c U_sz U_A1 U_cert
  let ws₀ := st.words.popDepth 0
  have ha₀ : InAttemptArena A V ws₀ := inAttemptArena_popDepth_zero harena
  have hhz₀ : HeapAllZero ws₀ := heapAllZero_popDepth_zero hhz
  let bs₀ := blockBitStream sp.1 (blockBitStream sp.2 restBits 0) 0
  have hbs_eq : st.remainingBits = bs₀ :=
    hbits.trans (splitAttemptBits_stream v restBits)
  obtain ⟨ws₁, ha₁, hhz₁, hregs₁, ex₀⟩ := exec_phase0Stmt p ha₀ hhz₀ hinp hfit hip_params (bs := bs₀)
  obtain ⟨ws₂, ha₂, hhz₂, hregs₂, hlifts₂, ex₁⟩ :=
    exec_phase1Stmt p pts_h ha₁ hhz₁ hregs₁ hinp hfit hpts_b hip_handles hip_coords (bs := bs₀)
  obtain ⟨ws₃, ha₃, hhz₃, hregs₃, hlifts₃, ex₂⟩ :=
    exec_phase2Stmt p pts_h sizeProg ha₂ hhz₂ hregs₂ hlifts₂ hinp hfit
      hrun_sz hM_out hsz_bounds h2_fit (bs := bs₀)
  obtain ⟨ws₄, ha₄, hhz₄, hregs₄, hlifts₄, hz₄, ex₃⟩ :=
    exec_phase3Stmt p pts_h prog_A1 zRat sp.1 (blockBitStream sp.2 restBits 0)
      ha₃ hhz₃ hregs₃ hlifts₃ hinp hfit hpts_b hip_handles hip_coords h3_fit
      hrun_A1 ha1_bounds hz_out
  obtain ⟨ws₅, ha₅, hhz₅, hregs₅, hlifts₅, hz₅, hfy₅, ex₄⟩ :=
    exec_phase4Stmt p pts_h zRat sp.2 restBits ha₄ hhz₄ hregs₄ hlifts₄ hz₄ hinp hfit
  have hz_V : ∀ c : Fin p.D,
      intBitLength (zRat c).num ≤ V ∧ intBitLength (((zRat c).den : ℤ) - 1) ≤ V :=
    hz_V_of_hasZArray ha₅ (by have := hinp.2.1; omega) hz₅
  obtain ⟨ws₆, ha₆, hhz₆, hregs₆, hz₆, hk_pass, hpass_data, ex₅⟩ :=
    exec_phase5Stmt p pts_h zRat (fyPerm u) progCert outCert
      ha₅ hhz₅ hregs₅ hlifts₅ hz₅ hfy₅ hinp hfit hpts_b hip_handles hip_coords
      hz_V h5_fit hrun_cert hcert_bounds (bs := restBits)
  have hlen_le : L_pass.length ≤ p.r :=
    (List.length_filter_le passBool (List.finRange p.r)).trans
      (by simp [List.length_finRange])
  obtain ⟨ws₇, ha₇, hout₆, ex₆⟩ :=
    exec_phase6Stmt p zRat (fyPerm u) outCert L_pass
      ha₆ hhz₆ hregs₆ hz₆ hinp hfit hlen_le hk_pass hpass_data (bs := restBits)
  have ex₀' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₀ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₁' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₁ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₂' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₂ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₃' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₃ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₄' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₄ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₅' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₅ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex₆' := ExecBounded.mono (C' := C_tot) (S' := S_tot) ex₆ le_rfl le_rfl
    (by dsimp [C_tot, attemptCellCap]; omega) (by dsimp [S_tot, attemptBitSpaceCap, T_sz, T_A1, T_c]; omega)
  have ex_body := ExecBounded.seq ex₀'
    (ExecBounded.seq ex₁'
      (ExecBounded.seq ex₂'
        (ExecBounded.seq ex₃'
          (ExecBounded.seq ex₄'
            (ExecBounded.seq ex₅' ex₆')))))
  let stEnter : BitRAMExecState :=
    { st with words := st.words.popDepth st.frameDepth, frameDepth := st.frameDepth + 1 }
  have hfd_en : stEnter.frameDepth = 1 := by dsimp [stEnter]; omega
  have hws_en : stEnter.words = ws₀ := by dsimp [stEnter, ws₀]; rw [hfd0]
  obtain ⟨stBody, hr_body, hws_b, _, hbs_b, hu_b, hb_b, hpc_b, hpb_b⟩ :=
    ex_body stEnter hws_en hfd_en hbs_eq
  have hr_scope := RunsTo.localScope hr_body
  set st' : BitRAMExecState :=
    { stBody with words := stBody.words.popDepth st.frameDepth, frameDepth := st.frameDepth }
  have hws_st' : st'.words = ws₇.popDepth 0 := by
    dsimp [st']; rw [hws_b, hfd0]
  refine ⟨st', hr_scope, hfd0, hbs_b, hws_st' ▸ inAttemptArena_popDepth_zero ha₇,
    ?_, ?_, hpc_b, hpb_b, ?_⟩
  · have hu0 : stEnter.unitCost = st.unitCost := rfl
    have hu1 : st'.unitCost = stBody.unitCost := rfl
    dsimp [attemptUnitCap, F_sz, F_A1, F_c]
    omega
  · have hb0 : stEnter.bitCost = st.bitCost := rfl
    have hb1 : st'.bitCost = stBody.bitCost := rfl
    have h79 : (400000 + 700000 * p.m) * (V + 8) ^ 2 ≤ (400000 + p.m * 900000) * (V + 8) ^ 2 := Nat.mul_le_mul_right _ (by omega)
    dsimp [attemptBitCap, F_sz, F_A1, F_c, T_sz, T_A1, T_c]
    omega
  · by_cases hp : p.r ≤ 2 * L_pass.length
    · rw [if_pos hp] at hout₆ ⊢
      rcases hout₆ with ⟨hr0, hr1, hr23⟩
      refine ⟨(hws_st' ▸ popDepth_zero_read_heap ws₇ 0 0).trans hr0, ?_, ?_⟩
      · intro c
        exact ⟨(hws_st' ▸ popDepth_zero_read_heap ws₇ 1 _).trans (hr1 c).1,
               (hws_st' ▸ popDepth_zero_read_heap ws₇ 1 _).trans (hr1 c).2⟩
      · intro i hi j
        obtain ⟨h2, h30, h31⟩ := hr23 i hi j
        exact ⟨(hws_st' ▸ popDepth_zero_read_heap ws₇ 2 _).trans h2,
               (hws_st' ▸ popDepth_zero_read_heap ws₇ 3 _).trans h30,
               (hws_st' ▸ popDepth_zero_read_heap ws₇ 3 _).trans h31⟩
    · rw [if_neg hp] at hout₆ ⊢
      rw [hws_st']
      exact heapAllZero_popDepth_zero hout₆

/-! ### 5. Outer retry `whileLoop` + prefix-free geometric tail master theorem -/

def retryMainProg (K deg_α C_z deg_alg k_φ : ℕ)
    (sizeProg prog_A1 progCert : BitRAMStmt) : BitRAMStmt :=
  .whileLoop (.intEq (.readHeap 0 (.lit 0)) (.lit 0))
    (.localScope (attemptBodyStmt K deg_α C_z deg_alg k_φ sizeProg prog_A1 progCert))

theorem exec_retry_chunks {d A V N : ℕ} {inp : BitRAMInput d}
    {body : BitRAMStmt}
    (acc : (Fin N → Bool) → Bool)
    (GoodProp : WordStore → Prop)
    (U_att B_att C_att S_att : ℕ)
    (hV1 : 1 ≤ V)
    (hstep_bad : ∀ (v : Fin N → Bool), acc v = false →
      ∀ (rest : List Bool) (st : BitRAMExecState),
        st.frameDepth = 0 →
        InAttemptArena A V st.words →
        HeapAllZero st.words →
        st.remainingBits = List.ofFn v ++ rest →
        ∃ st' : BitRAMExecState,
          RunsTo inp [.stmt body] st st' ∧
          st'.frameDepth = 0 ∧
          st'.remainingBits = rest ∧
          InAttemptArena A V st'.words ∧
          HeapAllZero st'.words ∧
          st'.unitCost ≤ st.unitCost + U_att ∧
          st'.bitCost ≤ st.bitCost + B_att ∧
          st'.peakCellSpace ≤ max st.peakCellSpace C_att ∧
          st'.peakBitSpace ≤ max st.peakBitSpace S_att)
    (hstep_good : ∀ (v : Fin N → Bool), acc v = true →
      ∀ (st : BitRAMExecState),
        st.frameDepth = 0 →
        InAttemptArena A V st.words →
        HeapAllZero st.words →
        st.remainingBits = List.ofFn v ++ [] →
        ∃ st' : BitRAMExecState,
          RunsTo inp [.stmt body] st st' ∧
          st'.frameDepth = 0 ∧
          st'.remainingBits = [] ∧
          InAttemptArena A V st'.words ∧
          st'.words.read (.heap 0 0) ≠ 0 ∧
          GoodProp (st'.words.popDepth 0) ∧
          st'.unitCost ≤ st.unitCost + U_att ∧
          st'.bitCost ≤ st.bitCost + B_att ∧
          st'.peakCellSpace ≤ max st.peakCellSpace C_att ∧
          st'.peakBitSpace ≤ max st.peakBitSpace S_att) :
    let prog := BitRAMStmt.whileLoop (.intEq (.readHeap 0 (.lit 0)) (.lit 0)) body
    ∀ (t : ℕ) (bad : Fin t → {v : Fin N → Bool // acc v = false})
      (good : {v : Fin N → Bool // acc v = true})
      (st : BitRAMExecState),
      st.frameDepth = 0 →
      InAttemptArena A V st.words →
      HeapAllZero st.words →
      st.remainingBits = chunkList t bad good →
      ∃ stEnd : BitRAMExecState,
        RunsTo inp [.stmt prog] st stEnd ∧
        stEnd.remainingBits = [] ∧
        GoodProp (stEnd.words.popDepth 0) ∧
        stEnd.unitCost ≤ st.unitCost + (t + 1) * (U_att + 16) ∧
        stEnd.bitCost ≤ st.bitCost + (t + 1) * (B_att + 4 * V + 16) ∧
        stEnd.peakCellSpace ≤ max st.peakCellSpace C_att ∧
        stEnd.peakBitSpace ≤ max st.peakBitSpace S_att := by
  intro prog t
  let cond : BitCondExpr := .intEq (.readHeap 0 (.lit 0)) (.lit 0)
  have hcond_zero : ∀ st : BitRAMExecState, HeapAllZero st.words →
      evalBitCond inp st.frameDepth st.words cond = (true, 4, 7) := by
    intro st hhz
    have hr0 : st.words.read (.heap 0 0) = 0 := hhz 0 0
    simp only [cond, evalBitCond, evalIntExpr, hr0]
    rfl
  induction t with
  | zero =>
      intro bad good st hfd ha hhz hbs
      have hc1 := hcond_zero st hhz
      let stC : BitRAMExecState := { st with unitCost := st.unitCost + 4, bitCost := st.bitCost + 7 }
      have hbsC : stC.remainingBits = List.ofFn good.1 ++ [] := by
        dsimp [stC]; rw [hbs, List.append_nil]; rfl
      obtain ⟨st₁, hr₁, _, hbs₁, ha₁, hnz₁, hgood₁, hu₁, hb₁, hpc₁, hpb₁⟩ :=
        hstep_good good.1 good.2 stC hfd ha hhz hbsC
      let v₁ := st₁.words.read (.heap 0 0)
      have hv₁_V : intBitLength v₁ ≤ V := inAttemptArena_read_bitLen_le ha₁ hV1 (.heap 0 0)
      have hc2 : evalBitCond inp st₁.frameDepth st₁.words cond =
          (false, 4, 5 + 2 * intBitLength v₁) := by
        have hi0 : intBitLength 0 = 1 := rfl
        have hn0 : natBitLength 0 = 1 := rfl
        have hdec : decide (v₁ = 0) = false := decide_eq_false hnz₁
        refine Prod.ext ?_ (Prod.ext ?_ ?_)
        · simp only [cond, evalBitCond, evalIntExpr]; exact hdec
        · simp only [cond, evalBitCond, evalIntExpr] <;> rfl
        · simp only [cond, evalBitCond, evalIntExpr, hi0, hn0]
          change 1 + 1 + 1 + intBitLength v₁ + 1 + intBitLength v₁ + 1 = 5 + 2 * intBitLength v₁
          omega
      have hr_false := RunsTo.whileLoop_false cond body hc2
      have hr_tot := RunsTo.whileLoop_true cond body hc1 hr₁ hr_false
      refine ⟨_, hr_tot, hbs₁, hgood₁, ?_, ?_, hpc₁, hpb₁⟩
      · have huC : stC.unitCost = st.unitCost + 4 := rfl
        dsimp only; omega
      · have hbC : stC.bitCost = st.bitCost + 7 := rfl
        dsimp only; omega
  | succ t ih =>
      intro bad good st hfd ha hhz hbs
      have hc1 := hcond_zero st hhz
      let stC : BitRAMExecState := { st with unitCost := st.unitCost + 4, bitCost := st.bitCost + 7 }
      have hbsC : stC.remainingBits = List.ofFn (bad 0).1 ++ chunkList t (fun i => bad i.succ) good := by
        dsimp [stC]; exact hbs
      obtain ⟨st₁, hr₁, hfd₁, hbs₁, ha₁, hhz₁, hu₁, hb₁, hpc₁, hpb₁⟩ :=
        hstep_bad (bad 0).1 (bad 0).2 (chunkList t (fun i => bad i.succ) good) stC hfd ha hhz hbsC
      obtain ⟨stEnd, hr_rem, hbs_e, hgood_e, hu_e, hb_e, hpc_e, hpb_e⟩ :=
        ih (fun i => bad i.succ) good st₁ hfd₁ ha₁ hhz₁ hbs₁
      have hr_tot := RunsTo.whileLoop_true cond body hc1 hr₁ hr_rem
      refine ⟨stEnd, hr_tot, hbs_e, hgood_e, ?_, ?_,
        hpc_e.trans (max_le hpc₁ (le_max_right _ _)),
        hpb_e.trans (max_le hpb₁ (le_max_right _ _))⟩
      · have huC : stC.unitCost = st.unitCost + 4 := rfl
        rw [Nat.succ_add, Nat.add_one_mul]
        omega
      · have hbC : stC.bitCost = st.bitCost + 7 := rfl
        rw [Nat.succ_add, Nat.add_one_mul]
        omega

theorem retry_program_full_spec {d N : ℕ}
    (prog : BitRAMStmt) (inp : BitRAMInput d)
    (acc : (Fin N → Bool) → Bool)
    (GoodProp : WordStore → Prop)
    (U_step B_step C_cap S_cap : ℕ)
    (hprob : 1 / 2 ≤
      ((Finset.univ.filter (fun v : Fin N → Bool => acc v = true)).card : ℝ) / ((2 : ℝ) ^ N))
    (h_chunks : ∀ (t : ℕ) (bad : Fin t → {v : Fin N → Bool // acc v = false})
      (good : {v : Fin N → Bool // acc v = true}),
      ∃ out : BitRAMExecOutcome,
        runBitRAMWithBits prog inp WordStore.empty (chunkList t bad good) = some out ∧
        out.unitCost ≤ (t + 1) * U_step ∧
        out.bitCost ≤ (t + 1) * B_step ∧
        out.peakCellSpace ≤ C_cap ∧
        out.peakBitSpace ≤ S_cap ∧
        GoodProp out.words) :
    let haltProb : ENNReal :=
      ∑' bs : List Bool,
        if (runBitRAMWithBits prog inp WordStore.empty bs).isSome then bitListProb bs else 0
    let expUnitCost : ENNReal :=
      ∑' bs : List Bool,
        match runBitRAMWithBits prog inp WordStore.empty bs with
        | some out => bitListProb bs * (out.unitCost : ENNReal)
        | none => 0
    let expBitCost : ENNReal :=
      ∑' bs : List Bool,
        match runBitRAMWithBits prog inp WordStore.empty bs with
        | some out => bitListProb bs * (out.bitCost : ENNReal)
        | none => 0
    haltProb = 1 ∧
    expUnitCost ≠ ⊤ ∧ expUnitCost.toReal ≤ 4 * (U_step : ℝ) ∧
    expBitCost ≠ ⊤ ∧ expBitCost.toReal ≤ 4 * (B_step : ℝ) ∧
    ∀ (bs : List Bool) (out : BitRAMExecOutcome),
      runBitRAMWithBits prog inp WordStore.empty bs = some out →
        out.peakCellSpace ≤ C_cap ∧
        out.peakBitSpace ≤ S_cap ∧
        GoodProp out.words := by
  classical
  intro haltProb expUnitCost expBitCost
  let F := {v : Fin N → Bool // acc v = false}
  let G := {v : Fin N → Bool // acc v = true}
  let Dom := Σ t : ℕ, (Fin t → F) × G
  let C : Set (List Bool) := Set.range (fun x : Dom => chunkList x.1 x.2.1 x.2.2)
  let H : Set (List Bool) := {bs : List Bool | (runBitRAMWithBits prog inp WordStore.empty bs).isSome = true}
  have hsub : C ⊆ H := by
    rintro bs ⟨⟨t, bad, good⟩, rfl⟩
    obtain ⟨out, hout, _⟩ := h_chunks t bad good
    simp [H, hout]
  -- 1. Use `geom_retry_tsum_bounds` on dummy `runC` to get `∑_{bs ∈ C} bitListProb bs = 1`
  let runC : List Bool → Option Unit := fun bs => if bs ∈ C then some () else none
  have htsum_C : (∑' bs : List Bool, if bs ∈ C then bitListProb bs else 0) = 1 := by
    have hdum := geom_retry_tsum_bounds runC (fun _ => 0) (fun _ => 0) acc
      (le_refl (0 : ℝ)) (le_refl (0 : ℝ)) hprob
      (fun t bad good => by
        have hmem : chunkList t bad good ∈ C := ⟨⟨t, (bad, good)⟩, rfl⟩
        simp [runC, hmem])
      (fun bs _ hopt => by
        by_cases hm : bs ∈ C
        · rcases hm with ⟨⟨t, bad, good⟩, rfl⟩
          exact ⟨t, bad, good, rfl, by simp, by simp⟩
        · simp [runC, hm] at hopt)
    have heq_fn : (fun bs : List Bool => if (runC bs).isSome then bitListProb bs else 0) =
        (fun bs : List Bool => if bs ∈ C then bitListProb bs else 0) := by
      funext bs
      by_cases hm : bs ∈ C <;> simp [runC, hm]
    simpa [heq_fn] using hdum.1
  -- 2. Prefix-freeness forces `H = C`
  have hHC : H = C := prefixFree_eq_of_subset_tsum_one hsub
    (fun a ha b hb hp => by
      obtain ⟨oa, hoa⟩ := Option.isSome_iff_exists.mp ha
      obtain ⟨ob, hob⟩ := Option.isSome_iff_exists.mp hb
      exact runBitRAMWithBits_prefixFree prog inp WordStore.empty hoa hob hp) htsum_C
  have h_decomp : ∀ (bs : List Bool) (out : BitRAMExecOutcome),
      runBitRAMWithBits prog inp WordStore.empty bs = some out →
      ∃ (t : ℕ) (bad : Fin t → F) (good : G),
        bs = chunkList t bad good ∧
        out.unitCost ≤ (t + 1) * U_step ∧
        out.bitCost ≤ (t + 1) * B_step ∧
        out.peakCellSpace ≤ C_cap ∧
        out.peakBitSpace ≤ S_cap ∧
        GoodProp out.words := by
    intro bs out hrun
    have hbsH : bs ∈ H := by simp [H, hrun]
    rw [hHC] at hbsH
    rcases hbsH with ⟨⟨t, bad, good⟩, rfl⟩
    obtain ⟨out', hout', hu, hb, hc, hs, hg⟩ := h_chunks t bad good
    rw [hrun] at hout'
    injection hout' with heq
    subst heq
    exact ⟨t, bad, good, rfl, hu, hb, hc, hs, hg⟩
  -- 3. Apply `geom_retry_tsum_bounds` to `runBitRAMWithBits prog inp WordStore.empty`
  have hreal := geom_retry_tsum_bounds
    (runBitRAMWithBits prog inp WordStore.empty)
    BitRAMExecOutcome.unitCost BitRAMExecOutcome.bitCost acc
    (Nat.cast_nonneg U_step) (Nat.cast_nonneg B_step) hprob
    (fun t bad good => by
      obtain ⟨out, hout, _⟩ := h_chunks t bad good
      simp [hout])
    (fun bs out hrun => by
      obtain ⟨t, bad, good, heq, hu, hb, _⟩ := h_decomp bs out hrun
      refine ⟨t, bad, good, heq, ?_, ?_⟩
      · exact_mod_cast hu
      · exact_mod_cast hb)
  rcases hreal with ⟨hr1, hr2, hr3, hr4, hr5⟩
  dsimp only [haltProb, expUnitCost, expBitCost]
  refine ⟨hr1, ?_, ?_, ?_, ?_, ?_⟩
  · convert hr2 using 1; congr 1; ext bs; cases runBitRAMWithBits prog inp WordStore.empty bs <;> rfl
  · convert hr3 using 1; congr 1; congr 1; ext bs; cases runBitRAMWithBits prog inp WordStore.empty bs <;> rfl
  · convert hr4 using 1; congr 1; ext bs; cases runBitRAMWithBits prog inp WordStore.empty bs <;> rfl
  · convert hr5 using 1; congr 1; congr 1; ext bs; cases runBitRAMWithBits prog inp WordStore.empty bs <;> rfl
  intro bs out hrun
  obtain ⟨_, _, _, _, _, _, hc, hs, hg⟩ := h_decomp bs out hrun
  exact ⟨hc, hs, hg⟩

end UL.Proof_lem_A_2
