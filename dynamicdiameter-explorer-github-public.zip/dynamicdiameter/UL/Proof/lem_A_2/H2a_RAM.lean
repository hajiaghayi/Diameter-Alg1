import Mathlib
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
set_option autoImplicit false

namespace UL.Proof_lem_A_2

/-! ### 1. Bit-length helpers -/

theorem natBitLength_pos (m : ℕ) : 1 ≤ natBitLength m := by
  unfold natBitLength
  omega

theorem natBitLength_le (m : ℕ) : natBitLength m ≤ m + 1 := by
  unfold natBitLength
  have := Nat.log_le_self 2 m
  omega

theorem natBitLength_mono {a b : ℕ} (h : a ≤ b) : natBitLength a ≤ natBitLength b := by
  unfold natBitLength
  exact Nat.add_le_add_right (Nat.log_mono_right h) 1

theorem intBitLength_pos (z : ℤ) : 1 ≤ intBitLength z := by
  unfold intBitLength
  split_ifs
  · omega
  · have := natBitLength_pos z.natAbs
    omega

theorem intBitLength_le_natAbs (z : ℤ) : intBitLength z ≤ z.natAbs + 2 := by
  unfold intBitLength
  split_ifs with h
  · omega
  · have := natBitLength_le z.natAbs
    omega

theorem intBitLength_mono_natAbs {a b : ℤ} (h : a.natAbs ≤ b.natAbs) :
    intBitLength a ≤ intBitLength b + 1 := by
  unfold intBitLength
  by_cases ha : a = 0 <;> by_cases hb : b = 0
  · simp [ha, hb]
  · simp only [ha, hb, ↓reduceIte]
    have := natBitLength_pos b.natAbs
    omega
  · subst hb; simp at h; omega
  · simp only [ha, hb, ↓reduceIte]
    have := natBitLength_mono h
    omega

theorem ramCellLoc_bitLength_pos (loc : RAMCellLoc) : 1 ≤ loc.bitLength := by
  cases loc with
  | heap t idx =>
      dsimp [RAMCellLoc.bitLength]
      have := natBitLength_pos t
      have := intBitLength_pos idx
      omega
  | localFrame d v idx =>
      dsimp [RAMCellLoc.bitLength]
      have := natBitLength_pos d
      have := natBitLength_pos v
      have := intBitLength_pos idx
      omega

/-! ### 2. `runBitRAMFuel` fuel monotonicity, cost monotonicity, and prefix-freeness -/

theorem runBitRAMFuel_mono {d : ℕ} {inp : BitRAMInput d} :
    ∀ {fuel fuel' : ℕ} {stack : List BitRAMCont} {st : BitRAMExecState} {out : BitRAMExecOutcome},
      runBitRAMFuel inp fuel stack st = .halted out →
      fuel ≤ fuel' →
      runBitRAMFuel inp fuel' stack st = .halted out
  | _, _, [], st, out, h, _ => by
      unfold runBitRAMFuel at h ⊢
      exact h
  | 0, _, _ :: _, _, _, h, _ => by
      simp [runBitRAMFuel] at h
  | _ + 1, 0, _ :: _, _, _, _, hle => by
      omega
  | fuel + 1, fuel' + 1, item :: rest, st, out, h, hle => by
      have hle' : fuel ≤ fuel' := by omega
      cases item with
      | popScope _ =>
          simp only [runBitRAMFuel] at h ⊢
          exact runBitRAMFuel_mono h hle'
      | repeatLoop rem _ =>
          cases rem <;> (simp only [runBitRAMFuel] at h ⊢; exact runBitRAMFuel_mono h hle')
      | stmt s =>
          cases s with
          | randBitHeap _ _ =>
              simp only [runBitRAMFuel] at h ⊢
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h
              | cons b bs =>
                  simp only [hbits] at h ⊢
                  exact runBitRAMFuel_mono h hle'
          | randBitLocal _ _ =>
              simp only [runBitRAMFuel] at h ⊢
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h
              | cons b bs =>
                  simp only [hbits] at h ⊢
                  exact runBitRAMFuel_mono h hle'
          | _ =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'

theorem runBitRAMFuel_cost_mono {d : ℕ} {inp : BitRAMInput d} :
    ∀ {fuel : ℕ} {stack : List BitRAMCont} {st : BitRAMExecState} {out : BitRAMExecOutcome},
      runBitRAMFuel inp fuel stack st = .halted out →
      st.unitCost ≤ out.unitCost ∧
      st.bitCost ≤ out.bitCost ∧
      st.peakCellSpace ≤ out.peakCellSpace ∧
      st.peakBitSpace ≤ out.peakBitSpace
  | _, [], _, _, h => by
      simp only [runBitRAMFuel] at h
      split_ifs at h
      injection h with hout
      subst hout
      exact ⟨le_rfl, le_rfl, le_rfl, le_rfl⟩
  | 0, _ :: _, _, _, h => by
      simp [runBitRAMFuel] at h
  | fuel + 1, item :: rest, st, out, h => by
      cases item with
      | popScope _ =>
          simp only [runBitRAMFuel] at h
          simpa using runBitRAMFuel_cost_mono h
      | repeatLoop rem _ =>
          cases rem <;> (simp only [runBitRAMFuel] at h; simpa using runBitRAMFuel_cost_mono h)
      | stmt s =>
          cases s with
          | skip =>
              simp only [runBitRAMFuel] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | writeHeap _ _ _ =>
              simp only [runBitRAMFuel] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, (le_max_left _ _).trans h3, (le_max_left _ _).trans h4⟩
          | writeLocal _ _ _ =>
              simp only [runBitRAMFuel] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, (le_max_left _ _).trans h3, (le_max_left _ _).trans h4⟩
          | freeHeap _ _ =>
              simp only [runBitRAMFuel] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | freeLocal _ _ =>
              simp only [runBitRAMFuel] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | randBitHeap _ _ =>
              simp only [runBitRAMFuel] at h
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h
              | cons _ _ =>
                  simp only [hbits] at h
                  obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono h
                  dsimp only at h1 h2 h3 h4
                  exact ⟨by omega, by omega, (le_max_left _ _).trans h3, (le_max_left _ _).trans h4⟩
          | randBitLocal _ _ =>
              simp only [runBitRAMFuel] at h
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h
              | cons _ _ =>
                  simp only [hbits] at h
                  obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono h
                  dsimp only at h1 h2 h3 h4
                  exact ⟨by omega, by omega, (le_max_left _ _).trans h3, (le_max_left _ _).trans h4⟩
          | seq _ _ =>
              simp only [runBitRAMFuel] at h
              simpa using runBitRAMFuel_cost_mono h
          | ite _ _ _ =>
              simp only [runBitRAMFuel] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | whileLoop _ _ =>
              simp only [runBitRAMFuel] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | repeatN _ _ =>
              simp only [runBitRAMFuel] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | localScope _ =>
              simp only [runBitRAMFuel] at h
              simpa using runBitRAMFuel_cost_mono h

theorem runBitRAMWithBits_eq_some_iff {d : ℕ} (prog : BitRAMStmt) (inp : BitRAMInput d)
    (initWords : WordStore) (bs : List Bool) (out : BitRAMExecOutcome) :
    runBitRAMWithBits prog inp initWords bs = some out ↔
      ∃ fuel : ℕ,
        let ws0 := initWords.popDepth 0
        runBitRAMFuel inp fuel [.stmt prog]
          { words := ws0
            frameDepth := 0
            remainingBits := bs
            unitCost := 0
            bitCost := 0
            peakCellSpace := inp.inputCellSpace + ws0.cellCount
            peakBitSpace := inp.inputBitSpace + ws0.bitSize } = .halted out := by
  classical
  unfold runBitRAMWithBits
  dsimp only
  set ws0 := initWords.popDepth 0
  set initSt : BitRAMExecState :=
    { words := ws0
      frameDepth := 0
      remainingBits := bs
      unitCost := 0
      bitCost := 0
      peakCellSpace := inp.inputCellSpace + ws0.cellCount
      peakBitSpace := inp.inputBitSpace + ws0.bitSize }
  constructor
  · intro h
    split_ifs at h with hex
    rcases Nat.find_spec hex with ⟨out', hout'⟩
    rw [hout'] at h
    injection h with heq
    subst heq
    exact ⟨Nat.find hex, hout'⟩
  · rintro ⟨fuel, hfuel⟩
    have hex : ∃ f out', runBitRAMFuel inp f [.stmt prog] initSt = .halted out' :=
      ⟨fuel, out, hfuel⟩
    rw [dif_pos hex]
    rcases Nat.find_spec hex with ⟨out', hout'⟩
    rw [hout']
    have h1 := runBitRAMFuel_mono hfuel (Nat.le_max_left fuel (Nat.find hex))
    have h2 := runBitRAMFuel_mono hout' (Nat.le_max_right fuel (Nat.find hex))
    rw [h1] at h2
    injection h2 with heq
    rw [heq]

private theorem runBitRAMFuel_prefix_eq {d : ℕ} {inp : BitRAMInput d} :
    ∀ (fuel : ℕ) {stack : List BitRAMCont} {st₁ st₂ : BitRAMExecState}
      {out₁ out₂ : BitRAMExecOutcome},
      runBitRAMFuel inp fuel stack st₁ = .halted out₁ →
      runBitRAMFuel inp fuel stack st₂ = .halted out₂ →
      st₁.words = st₂.words →
      st₁.frameDepth = st₂.frameDepth →
      st₁.remainingBits <+: st₂.remainingBits →
      st₁.remainingBits = st₂.remainingBits
  | _, [], _, _, _, _, h₁, h₂, _, _, _ => by
      simp only [runBitRAMFuel] at h₁ h₂
      split_ifs at h₁ with he₁
      split_ifs at h₂ with he₂
      rw [List.isEmpty_iff.mp he₁, List.isEmpty_iff.mp he₂]
  | 0, _ :: _, _, _, _, _, h₁, _, _, _, _ => by
      simp [runBitRAMFuel] at h₁
  | fuel + 1, item :: rest, st₁, st₂, _, _, h₁, h₂, hws, hfd, hpre => by
      cases item with
      | popScope _ =>
          simp only [runBitRAMFuel] at h₁ h₂
          simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂
            (by dsimp; rw [hws]) rfl hpre
      | repeatLoop rem _ =>
          cases rem <;>
            (simp only [runBitRAMFuel] at h₁ h₂
             simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂ hws hfd hpre)
      | stmt s =>
          cases s with
          | skip =>
              simp only [runBitRAMFuel] at h₁ h₂
              simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂ hws hfd hpre
          | writeHeap table idxE valE =>
              simp only [runBitRAMFuel] at h₁ h₂
              simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂
                (by dsimp; rw [hws, hfd]) hfd hpre
          | writeLocal var idxE valE =>
              simp only [runBitRAMFuel] at h₁ h₂
              simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂
                (by dsimp; rw [hws, hfd]) hfd hpre
          | freeHeap table idxE =>
              simp only [runBitRAMFuel] at h₁ h₂
              simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂
                (by dsimp; rw [hws, hfd]) hfd hpre
          | freeLocal var idxE =>
              simp only [runBitRAMFuel] at h₁ h₂
              simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂
                (by dsimp; rw [hws, hfd]) hfd hpre
          | randBitHeap table idxE =>
              simp only [runBitRAMFuel] at h₁ h₂
              cases hb₁ : st₁.remainingBits with
              | nil => simp [hb₁] at h₁
              | cons b bs₁' =>
                  rw [hb₁] at hpre
                  rcases hpre with ⟨extra, hb₂_eq⟩
                  simp only [List.cons_append] at hb₂_eq
                  rw [hb₁] at h₁
                  rw [← hb₂_eq] at h₂
                  dsimp only at h₁ h₂
                  have hrec := runBitRAMFuel_prefix_eq fuel h₁ h₂
                    (by dsimp; rw [hws, hfd]) hfd ⟨extra, rfl⟩
                  dsimp at hrec
                  rw [← hb₂_eq, ← hrec]
          | randBitLocal var idxE =>
              simp only [runBitRAMFuel] at h₁ h₂
              cases hb₁ : st₁.remainingBits with
              | nil => simp [hb₁] at h₁
              | cons b bs₁' =>
                  rw [hb₁] at hpre
                  rcases hpre with ⟨extra, hb₂_eq⟩
                  simp only [List.cons_append] at hb₂_eq
                  rw [hb₁] at h₁
                  rw [← hb₂_eq] at h₂
                  dsimp only at h₁ h₂
                  have hrec := runBitRAMFuel_prefix_eq fuel h₁ h₂
                    (by dsimp; rw [hws, hfd]) hfd ⟨extra, rfl⟩
                  dsimp at hrec
                  rw [← hb₂_eq, ← hrec]
          | seq _ _ =>
              simp only [runBitRAMFuel] at h₁ h₂
              simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂ hws hfd hpre
          | ite cond _ _ =>
              simp only [runBitRAMFuel] at h₁ h₂
              have hcond : evalBitCond inp st₁.frameDepth st₁.words cond =
                  evalBitCond inp st₂.frameDepth st₂.words cond := by rw [hws, hfd]
              rcases hc1 : evalBitCond inp st₁.frameDepth st₁.words cond with ⟨fl, u, b⟩
              have hc2 : evalBitCond inp st₂.frameDepth st₂.words cond = (fl, u, b) :=
                hcond.symm.trans hc1
              rw [hc1] at h₁; rw [hc2] at h₂
              dsimp only at h₁ h₂
              simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂ hws hfd hpre
          | whileLoop cond _ =>
              simp only [runBitRAMFuel] at h₁ h₂
              have hcond : evalBitCond inp st₁.frameDepth st₁.words cond =
                  evalBitCond inp st₂.frameDepth st₂.words cond := by rw [hws, hfd]
              rcases hc1 : evalBitCond inp st₁.frameDepth st₁.words cond with ⟨fl, u, b⟩
              have hc2 : evalBitCond inp st₂.frameDepth st₂.words cond = (fl, u, b) :=
                hcond.symm.trans hc1
              rw [hc1] at h₁; rw [hc2] at h₂
              dsimp only at h₁ h₂
              simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂ hws hfd hpre
          | repeatN countE _ =>
              simp only [runBitRAMFuel] at h₁ h₂
              have hexp : evalIntExpr inp st₁.frameDepth st₁.words countE =
                  evalIntExpr inp st₂.frameDepth st₂.words countE := by rw [hws, hfd]
              rcases he1 : evalIntExpr inp st₁.frameDepth st₁.words countE with ⟨cnt, u, b⟩
              have he2 : evalIntExpr inp st₂.frameDepth st₂.words countE = (cnt, u, b) :=
                hexp.symm.trans he1
              rw [he1] at h₁; rw [he2] at h₂
              dsimp only at h₁ h₂
              simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂ hws hfd hpre
          | localScope _ =>
              simp only [runBitRAMFuel] at h₁ h₂
              have hstk :
                  (BitRAMCont.popScope st₁.frameDepth :: rest) =
                  (BitRAMCont.popScope st₂.frameDepth :: rest) := by
                rw [hfd]
              rw [hstk] at h₁
              simpa using runBitRAMFuel_prefix_eq fuel h₁ h₂
                (by dsimp; rw [hws, hfd]) (by dsimp; rw [hfd]) hpre

/-- Every `BitRAMStmt` execution via `runBitRAMWithBits` is prefix-free on `bs : List Bool`. -/
theorem runBitRAMWithBits_prefixFree {d : ℕ} (prog : BitRAMStmt) (inp : BitRAMInput d)
    (ws : WordStore) {bs₁ bs₂ : List Bool} {out₁ out₂ : BitRAMExecOutcome}
    (h₁ : runBitRAMWithBits prog inp ws bs₁ = some out₁)
    (h₂ : runBitRAMWithBits prog inp ws bs₂ = some out₂)
    (hpre : bs₁ <+: bs₂) : bs₁ = bs₂ := by
  obtain ⟨f₁, hf₁⟩ := (runBitRAMWithBits_eq_some_iff prog inp ws bs₁ out₁).mp h₁
  obtain ⟨f₂, hf₂⟩ := (runBitRAMWithBits_eq_some_iff prog inp ws bs₂ out₂).mp h₂
  dsimp only at hf₁ hf₂
  have hm₁ := runBitRAMFuel_mono hf₁ (Nat.le_max_left f₁ f₂)
  have hm₂ := runBitRAMFuel_mono hf₂ (Nat.le_max_right f₁ f₂)
  exact runBitRAMFuel_prefix_eq (max f₁ f₂) hm₁ hm₂ rfl rfl hpre

/-! ### 3. Kraft's inequality and uniqueness of mass-`1` prefix-free subsets -/

theorem kraft_finset_le_one :
    ∀ (L : ℕ) (S : Finset (List Bool)),
      (∀ xs ∈ S, xs.length ≤ L) →
      (∀ a ∈ S, ∀ b ∈ S, a <+: b → a = b) →
      (∑ xs ∈ S, bitListProb xs) ≤ 1 := by
  classical
  intro L
  induction L with
  | zero =>
      intro S hlen _
      by_cases hemp : [] ∈ S
      · have hS : S = {[]} := by
          ext xs
          simp only [Finset.mem_singleton]
          constructor
          · intro hxs
            exact List.eq_nil_of_length_eq_zero (Nat.eq_zero_of_le_zero (hlen xs hxs))
          · rintro rfl; exact hemp
        rw [hS]
        simp [bitListProb]
      · have hS : S = ∅ := by
          ext xs
          simp only [Finset.notMem_empty, iff_false]
          intro hxs
          have := List.eq_nil_of_length_eq_zero (Nat.eq_zero_of_le_zero (hlen xs hxs))
          subst this
          exact hemp hxs
        rw [hS]
        simp
  | succ L ih =>
      intro S hlen hpf
      by_cases hnil : [] ∈ S
      · have hS : S = {[]} := by
          ext xs
          simp only [Finset.mem_singleton]
          constructor
          · intro hxs
            exact (hpf [] hnil xs hxs (List.nil_prefix)).symm
          · rintro rfl; exact hnil
        rw [hS]
        simp [bitListProb]
      · let S_f : Finset (List Bool) :=
          (S.filter (fun xs => xs.head? = some false)).image List.tail
        let S_t : Finset (List Bool) :=
          (S.filter (fun xs => xs.head? = some true)).image List.tail
        have h_decomp : ∀ xs ∈ S, xs = false :: xs.tail ∨ xs = true :: xs.tail := by
          intro xs hxs
          cases xs with
          | nil => exact False.elim (hnil hxs)
          | cons b tl => cases b <;> simp
        have hSf_len : ∀ ys ∈ S_f, ys.length ≤ L := by
          intro ys hys
          rcases Finset.mem_image.mp hys with ⟨xs, hxs, rfl⟩
          have hxsS := Finset.mem_of_mem_filter xs hxs
          cases xs with
          | nil => exact False.elim (hnil hxsS)
          | cons _ tl =>
              have := hlen _ hxsS
              simp at this ⊢
              omega
        have hSt_len : ∀ ys ∈ S_t, ys.length ≤ L := by
          intro ys hys
          rcases Finset.mem_image.mp hys with ⟨xs, hxs, rfl⟩
          have hxsS := Finset.mem_of_mem_filter xs hxs
          cases xs with
          | nil => exact False.elim (hnil hxsS)
          | cons _ tl =>
              have := hlen _ hxsS
              simp at this ⊢
              omega
        have hSf_pf : ∀ a ∈ S_f, ∀ b ∈ S_f, a <+: b → a = b := by
          intro a ha b hb hab
          rcases Finset.mem_image.mp ha with ⟨xa, hxa, rfl⟩
          rcases Finset.mem_image.mp hb with ⟨xb, hxb, rfl⟩
          obtain ⟨hxaS, hha⟩ := Finset.mem_filter.mp hxa
          obtain ⟨hxbS, hhb⟩ := Finset.mem_filter.mp hxb
          cases xa with
          | nil => simp at hha
          | cons ba tla =>
              cases xb with
              | nil => simp at hhb
              | cons bb tlb =>
                  simp at hha hhb hab ⊢
                  subst hha; subst hhb
                  have heq := hpf _ hxaS _ hxbS (List.cons_prefix_cons.mpr ⟨rfl, hab⟩)
                  injection heq
        have hSt_pf : ∀ a ∈ S_t, ∀ b ∈ S_t, a <+: b → a = b := by
          intro a ha b hb hab
          rcases Finset.mem_image.mp ha with ⟨xa, hxa, rfl⟩
          rcases Finset.mem_image.mp hb with ⟨xb, hxb, rfl⟩
          obtain ⟨hxaS, hha⟩ := Finset.mem_filter.mp hxa
          obtain ⟨hxbS, hhb⟩ := Finset.mem_filter.mp hxb
          cases xa with
          | nil => simp at hha
          | cons ba tla =>
              cases xb with
              | nil => simp at hhb
              | cons bb tlb =>
                  simp at hha hhb hab ⊢
                  subst hha; subst hhb
                  have heq := hpf _ hxaS _ hxbS (List.cons_prefix_cons.mpr ⟨rfl, hab⟩)
                  injection heq
        have hS_union :
            S = S_f.image (List.cons false) ∪ S_t.image (List.cons true) := by
          ext xs
          simp only [Finset.mem_union, Finset.mem_image]
          constructor
          · intro hxs
            rcases h_decomp xs hxs with h | h
            · left
              refine ⟨xs.tail, ?_, h.symm⟩
              refine Finset.mem_image.mpr ⟨xs, Finset.mem_filter.mpr ⟨hxs, ?_⟩, rfl⟩
              rw [h]; rfl
            · right
              refine ⟨xs.tail, ?_, h.symm⟩
              refine Finset.mem_image.mpr ⟨xs, Finset.mem_filter.mpr ⟨hxs, ?_⟩, rfl⟩
              rw [h]; rfl
          · rintro (⟨ys, hys, rfl⟩ | ⟨ys, hys, rfl⟩)
            · rcases Finset.mem_image.mp hys with ⟨xs, hxs, rfl⟩
              obtain ⟨hxsS, hh⟩ := Finset.mem_filter.mp hxs
              cases xs with
              | nil => simp at hh
              | cons b tl => simp at hh; subst hh; exact hxsS
            · rcases Finset.mem_image.mp hys with ⟨xs, hxs, rfl⟩
              obtain ⟨hxsS, hh⟩ := Finset.mem_filter.mp hxs
              cases xs with
              | nil => simp at hh
              | cons b tl => simp at hh; subst hh; exact hxsS
        have hdisj : Disjoint (S_f.image (List.cons false)) (S_t.image (List.cons true)) := by
          rw [Finset.disjoint_left]
          intro xs h₁ h₂
          rcases Finset.mem_image.mp h₁ with ⟨_, _, rfl⟩
          rcases Finset.mem_image.mp h₂ with ⟨_, _, hc⟩
          nomatch hc
        rw [hS_union, Finset.sum_union hdisj,
          Finset.sum_image (fun _ _ _ _ h => List.cons.inj h |>.2),
          Finset.sum_image (fun _ _ _ _ h => List.cons.inj h |>.2)]
        have hcons_prob : ∀ (b : Bool) (ys : List Bool),
            bitListProb (b :: ys) = (2 : ENNReal)⁻¹ * bitListProb ys := by
          intro b ys
          unfold bitListProb
          simp [pow_succ, mul_comm]
        simp_rw [hcons_prob, ← Finset.mul_sum]
        have h1 := ih S_f hSf_len hSf_pf
        have h2 := ih S_t hSt_len hSt_pf
        calc
          (2 : ENNReal)⁻¹ * (∑ x ∈ S_f, bitListProb x) +
              (2 : ENNReal)⁻¹ * (∑ x ∈ S_t, bitListProb x)
              ≤ (2 : ENNReal)⁻¹ * 1 + (2 : ENNReal)⁻¹ * 1 := by gcongr
          _ = 1 := by rw [mul_one, ENNReal.inv_two_add_inv_two]

/-- If a prefix-free set `H` contains a subset `C` whose `bitListProb` sum is already `1`,
then `H = C`. -/
theorem prefixFree_eq_of_subset_tsum_one {C H : Set (List Bool)}
    (hsub : C ⊆ H)
    (hpf : ∀ a ∈ H, ∀ b ∈ H, a <+: b → a = b)
    (htsum : (∑' bs : List Bool, open Classical in if bs ∈ C then bitListProb bs else 0) = 1) :
    H = C := by
  classical
  apply Set.Subset.antisymm _ hsub
  intro bs₀ hbs₀H
  by_contra hbs₀C
  let p₀ : ENNReal := bitListProb bs₀
  have hp₀_eq : p₀ = ENNReal.ofReal ((1 / 2 : ℝ) ^ bs₀.length) := by
    dsimp [p₀, bitListProb]
    rw [one_div, ENNReal.ofReal_pow (by positivity),
      ENNReal.ofReal_inv_of_pos (by norm_num), ENNReal.ofReal_ofNat]
  let r₀ : ℝ := (1 / 2 : ℝ) ^ bs₀.length
  have hr₀_pos : 0 < r₀ := by positivity
  have hr₀_le1 : r₀ ≤ 1 := pow_le_one₀ (by positivity) (by norm_num)
  have hlt1 : ENNReal.ofReal (1 - r₀ / 2) < 1 := by
    rw [← ENNReal.ofReal_one]
    exact ENNReal.ofReal_lt_ofReal_iff (by norm_num) |>.mpr (by linarith)
  rw [← htsum, ENNReal.tsum_eq_iSup_sum, lt_iSup_iff] at hlt1
  rcases hlt1 with ⟨F, hF_gt⟩
  let F' : Finset (List Bool) := F.filter (· ∈ C)
  have hsum_F' :
      (∑ bs ∈ F, if bs ∈ C then bitListProb bs else 0) = ∑ bs ∈ F', bitListProb bs := by
    rw [Finset.sum_filter]
  rw [hsum_F'] at hF_gt
  have hbs₀_not_F' : bs₀ ∉ F' := fun h => hbs₀C (Finset.mem_filter.mp h).2
  let S : Finset (List Bool) := insert bs₀ F'
  have hS_sub : ∀ x ∈ S, x ∈ H := by
    intro x hx
    rcases Finset.mem_insert.mp hx with rfl | hx'
    · exact hbs₀H
    · exact hsub (Finset.mem_filter.mp hx').2
  let L_max : ℕ := (S.image List.length).max' (by simp [S])
  have hS_len : ∀ x ∈ S, x.length ≤ L_max := fun x hx =>
    Finset.le_max' _ _ (Finset.mem_image_of_mem List.length hx)
  have hkraft := kraft_finset_le_one L_max S hS_len (fun a ha b hb => hpf a (hS_sub a ha) b (hS_sub b hb))
  rw [Finset.sum_insert hbs₀_not_F'] at hkraft
  have h_gt_one : 1 < bitListProb bs₀ + ∑ bs ∈ F', bitListProb bs := by
    calc
      (1 : ENNReal) = ENNReal.ofReal (r₀ + (1 - r₀ / 2) - r₀ / 2) := by
            have : r₀ + (1 - r₀ / 2) - r₀ / 2 = 1 := by ring
            rw [this, ENNReal.ofReal_one]
      _ < ENNReal.ofReal (r₀ + (1 - r₀ / 2)) := by
            exact (ENNReal.ofReal_lt_ofReal_iff (by linarith)).mpr (by linarith)
      _ = ENNReal.ofReal r₀ + ENNReal.ofReal (1 - r₀ / 2) :=
            ENNReal.ofReal_add hr₀_pos.le (by linarith)
      _ < bitListProb bs₀ + ∑ bs ∈ F', bitListProb bs := by
            rw [← hp₀_eq]
            exact ENNReal.add_lt_add_left (by simp [p₀, bitListProb]) hF_gt
  exact (not_le_of_gt h_gt_one) hkraft

/-! ### 4. Compositional `RunsTo` combinators and `WordStore` algebra -/

def RunsTo {d : ℕ} (inp : BitRAMInput d) (items : List BitRAMCont)
    (st₁ st₂ : BitRAMExecState) : Prop :=
  ∃ fuel : ℕ, ∀ (rest : List BitRAMCont) (k : ℕ),
    runBitRAMFuel inp (fuel + k) (items ++ rest) st₁ =
      runBitRAMFuel inp k rest st₂

theorem RunsTo.nil {d : ℕ} {inp : BitRAMInput d} (st : BitRAMExecState) :
    RunsTo inp [] st st :=
  ⟨0, fun _ _ => by simp⟩

theorem RunsTo.trans {d : ℕ} {inp : BitRAMInput d} {xs ys : List BitRAMCont}
    {st₁ st₂ st₃ : BitRAMExecState}
    (h₁ : RunsTo inp xs st₁ st₂) (h₂ : RunsTo inp ys st₂ st₃) :
    RunsTo inp (xs ++ ys) st₁ st₃ := by
  rcases h₁ with ⟨f₁, hf₁⟩
  rcases h₂ with ⟨f₂, hf₂⟩
  refine ⟨f₁ + f₂, fun rest k => ?_⟩
  rw [Nat.add_assoc, List.append_assoc, hf₁ (ys ++ rest) (f₂ + k), hf₂ rest k]

theorem RunsTo.skip {d : ℕ} (inp : BitRAMInput d) (st : BitRAMExecState) :
    RunsTo inp [.stmt .skip] st
      { st with unitCost := st.unitCost + 1, bitCost := st.bitCost + 1 } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.seq {d : ℕ} {inp : BitRAMInput d} {s₁ s₂ : BitRAMStmt}
    {st₁ st₂ st₃ : BitRAMExecState}
    (h₁ : RunsTo inp [.stmt s₁] st₁ st₂) (h₂ : RunsTo inp [.stmt s₂] st₂ st₃) :
    RunsTo inp [.stmt (.seq s₁ s₂)] st₁ st₃ := by
  have h12 : RunsTo inp [.stmt s₁, .stmt s₂] st₁ st₃ := RunsTo.trans h₁ h₂
  rcases h12 with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  simpa [runBitRAMFuel] using hf rest k

theorem RunsTo.writeHeap {d : ℕ} (inp : BitRAMInput d) (table : ℕ) (idxE valE : IntExpr)
    (st : BitRAMExecState) :
    let (idx, u₁, b₁) := evalIntExpr inp st.frameDepth st.words idxE
    let (val, u₂, b₂) := evalIntExpr inp st.frameDepth st.words valE
    let loc := RAMCellLoc.heap table idx
    let ws' := st.words.write loc val
    RunsTo inp [.stmt (.writeHeap table idxE valE)] st
      { st with
        words := ws'
        unitCost := st.unitCost + u₁ + u₂ + 1
        bitCost := st.bitCost + b₁ + b₂ + loc.bitLength + intBitLength val
        peakCellSpace := max st.peakCellSpace (inp.inputCellSpace + ws'.cellCount)
        peakBitSpace := max st.peakBitSpace (inp.inputBitSpace + ws'.bitSize) } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.writeLocal {d : ℕ} (inp : BitRAMInput d) (var : ℕ) (idxE valE : IntExpr)
    (st : BitRAMExecState) :
    let (idx, u₁, b₁) := evalIntExpr inp st.frameDepth st.words idxE
    let (val, u₂, b₂) := evalIntExpr inp st.frameDepth st.words valE
    let loc := RAMCellLoc.localFrame st.frameDepth var idx
    let ws' := st.words.write loc val
    RunsTo inp [.stmt (.writeLocal var idxE valE)] st
      { st with
        words := ws'
        unitCost := st.unitCost + u₁ + u₂ + 1
        bitCost := st.bitCost + b₁ + b₂ + loc.bitLength + intBitLength val
        peakCellSpace := max st.peakCellSpace (inp.inputCellSpace + ws'.cellCount)
        peakBitSpace := max st.peakBitSpace (inp.inputBitSpace + ws'.bitSize) } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.freeHeap {d : ℕ} (inp : BitRAMInput d) (table : ℕ) (idxE : IntExpr)
    (st : BitRAMExecState) :
    let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
    let loc := RAMCellLoc.heap table idx
    RunsTo inp [.stmt (.freeHeap table idxE)] st
      { st with
        words := st.words.free loc
        unitCost := st.unitCost + u + 1
        bitCost := st.bitCost + b + loc.bitLength } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.randBitLocal {d : ℕ} (inp : BitRAMInput d) (var : ℕ) (idxE : IntExpr)
    (bit : Bool) (bs' : List Bool) (st : BitRAMExecState)
    (hbits : st.remainingBits = bit :: bs') :
    let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
    let loc := RAMCellLoc.localFrame st.frameDepth var idx
    let v : ℤ := if bit then 1 else 0
    let ws' := st.words.write loc v
    RunsTo inp [.stmt (.randBitLocal var idxE)] st
      { st with
        words := ws'
        remainingBits := bs'
        unitCost := st.unitCost + u + 1
        bitCost := st.bitCost + b + loc.bitLength + 1
        peakCellSpace := max st.peakCellSpace (inp.inputCellSpace + ws'.cellCount)
        peakBitSpace := max st.peakBitSpace (inp.inputBitSpace + ws'.bitSize) } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  simp [runBitRAMFuel, hbits]

theorem RunsTo.ite {d : ℕ} {inp : BitRAMInput d} (cond : BitCondExpr) (tB fB : BitRAMStmt)
    {st st' : BitRAMExecState}
    (hbranch :
      let (flag, u, b) := evalBitCond inp st.frameDepth st.words cond
      RunsTo inp [.stmt (if flag then tB else fB)]
        { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b } st') :
    RunsTo inp [.stmt (.ite cond tB fB)] st st' := by
  dsimp only at hbranch
  rcases hbranch with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  simpa [runBitRAMFuel] using hf rest k

theorem RunsTo.whileLoop_false {d : ℕ} {inp : BitRAMInput d} (cond : BitCondExpr) (body : BitRAMStmt)
    {st : BitRAMExecState} {u b : ℕ}
    (hcond : evalBitCond inp st.frameDepth st.words cond = (false, u, b)) :
    RunsTo inp [.stmt (.whileLoop cond body)] st
      { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  simp [runBitRAMFuel, hcond]

theorem RunsTo.whileLoop_true {d : ℕ} {inp : BitRAMInput d} (cond : BitCondExpr) (body : BitRAMStmt)
    {st st₁ st₂ : BitRAMExecState} {u b : ℕ}
    (hcond : evalBitCond inp st.frameDepth st.words cond = (true, u, b))
    (hbody : RunsTo inp [.stmt body]
      { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b } st₁)
    (hrest : RunsTo inp [.stmt (.whileLoop cond body)] st₁ st₂) :
    RunsTo inp [.stmt (.whileLoop cond body)] st st₂ := by
  have h12 : RunsTo inp [.stmt body, .stmt (.whileLoop cond body)]
      { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b } st₂ :=
    RunsTo.trans hbody hrest
  rcases h12 with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  simpa [runBitRAMFuel, hcond] using hf rest k

theorem RunsTo.localScope {d : ℕ} {inp : BitRAMInput d} {body : BitRAMStmt}
    {st stBody : BitRAMExecState}
    (hbody : RunsTo inp [.stmt body]
      { st with words := st.words.popDepth st.frameDepth, frameDepth := st.frameDepth + 1 }
      stBody) :
    RunsTo inp [.stmt (.localScope body)] st
      { stBody with words := stBody.words.popDepth st.frameDepth, frameDepth := st.frameDepth } := by
  rcases hbody with ⟨fb, hfb⟩
  refine ⟨1 + fb + 1, fun rest k => ?_⟩
  have h1 : 1 + fb + 1 + k = (fb + (1 + k)) + 1 := by omega
  rw [h1]
  simp only [List.singleton_append, runBitRAMFuel]
  have h2 := hfb (.popScope st.frameDepth :: rest) (1 + k)
  simp only [List.singleton_append] at h2
  rw [h2, show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.repeatLoop_zero {d : ℕ} {inp : BitRAMInput d} (body : BitRAMStmt)
    (st : BitRAMExecState) :
    RunsTo inp [.repeatLoop 0 body] st st := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.repeatLoop_succ {d : ℕ} {inp : BitRAMInput d} {rem : ℕ} {body : BitRAMStmt}
    {st₁ st₂ st₃ : BitRAMExecState}
    (h₁ : RunsTo inp [.stmt body] st₁ st₂)
    (h₂ : RunsTo inp [.repeatLoop rem body] st₂ st₃) :
    RunsTo inp [.repeatLoop (rem + 1) body] st₁ st₃ := by
  have h12 : RunsTo inp [.stmt body, .repeatLoop rem body] st₁ st₃ := RunsTo.trans h₁ h₂
  rcases h12 with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  simpa [runBitRAMFuel] using hf rest k

theorem RunsTo.repeatN {d : ℕ} {inp : BitRAMInput d} (countE : IntExpr) (body : BitRAMStmt)
    {st st' : BitRAMExecState}
    (hloop :
      let (cnt, u, b) := evalIntExpr inp st.frameDepth st.words countE
      let nIter := if 0 ≤ cnt then cnt.toNat else 0
      RunsTo inp [.repeatLoop nIter body]
        { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b } st') :
    RunsTo inp [.stmt (.repeatN countE body)] st st' := by
  dsimp only at hloop
  rcases hloop with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  simpa [runBitRAMFuel] using hf rest k

theorem RunsTo.toRunBitRAMWithBits {d : ℕ} {prog : BitRAMStmt} {inp : BitRAMInput d}
    {ws₀ : WordStore} {bs : List Bool} {stEnd : BitRAMExecState}
    (hrun :
      let ws0 := ws₀.popDepth 0
      RunsTo inp [.stmt prog]
        { words := ws0
          frameDepth := 0
          remainingBits := bs
          unitCost := 0
          bitCost := 0
          peakCellSpace := inp.inputCellSpace + ws0.cellCount
          peakBitSpace := inp.inputBitSpace + ws0.bitSize } stEnd)
    (hbits : stEnd.remainingBits = []) :
    runBitRAMWithBits prog inp ws₀ bs =
      some
        { words := stEnd.words.popDepth 0
          unitCost := stEnd.unitCost
          bitCost := stEnd.bitCost
          peakCellSpace := stEnd.peakCellSpace
          peakBitSpace := stEnd.peakBitSpace } := by
  rw [runBitRAMWithBits_eq_some_iff]
  rcases hrun with ⟨f, hf⟩
  refine ⟨f + 1, ?_⟩
  dsimp only
  have h := hf [] 1
  simp only [List.append_nil] at h
  rw [h]
  simp [runBitRAMFuel, hbits]

/-! ### 5. `WordStore` read/write/free/popDepth size lemmas -/

def WellFormedWS (ws : WordStore) : Prop :=
  ∀ loc : RAMCellLoc, loc ∉ ws.live → ws.vals loc = 0

theorem wellFormedWS_empty : WellFormedWS WordStore.empty :=
  fun _ _ => rfl

theorem wellFormedWS_write {ws : WordStore} (h : WellFormedWS ws) (loc : RAMCellLoc) (v : ℤ) :
    WellFormedWS (ws.write loc v) := by
  intro l hl
  simp only [WordStore.write, Finset.mem_insert, not_or] at hl ⊢
  rw [Function.update_of_ne hl.1]
  exact h l hl.2

theorem wellFormedWS_free {ws : WordStore} (h : WellFormedWS ws) (loc : RAMCellLoc) :
    WellFormedWS (ws.free loc) := by
  intro l hl
  simp only [WordStore.free, Finset.mem_erase] at hl ⊢
  by_cases heq : l = loc
  · subst heq; simp
  · rw [Function.update_of_ne heq]
    exact h l (fun hm => hl ⟨heq, hm⟩)

theorem wellFormedWS_popDepth {ws : WordStore} (h : WellFormedWS ws) (keep : ℕ) :
    WellFormedWS (ws.popDepth keep) := by
  intro l hl
  simp only [WordStore.popDepth, Finset.mem_filter] at hl ⊢
  split_ifs with hk
  · exact h l (fun hm => hl ⟨hm, hk⟩)
  · rfl

theorem wordStore_read_eq_vals {ws : WordStore} (h : WellFormedWS ws) (loc : RAMCellLoc) :
    ws.read loc = ws.vals loc := by
  unfold WordStore.read
  split_ifs with hm
  · rfl
  · exact (h loc hm).symm

theorem wordStore_read_write_self (ws : WordStore) (loc : RAMCellLoc) (v : ℤ) :
    (ws.write loc v).read loc = v := by
  simp [WordStore.write, WordStore.read]

theorem wordStore_read_write_of_ne (ws : WordStore) {loc₁ loc₂ : RAMCellLoc}
    (hne : loc₁ ≠ loc₂) (v : ℤ) :
    (ws.write loc₂ v).read loc₁ = ws.read loc₁ := by
  simp [WordStore.write, WordStore.read, hne]

theorem wordStore_read_free_self (ws : WordStore) (loc : RAMCellLoc) :
    (ws.free loc).read loc = 0 := by
  simp [WordStore.free, WordStore.read]

theorem wordStore_read_free_of_ne (ws : WordStore) {loc₁ loc₂ : RAMCellLoc}
    (hne : loc₁ ≠ loc₂) :
    (ws.free loc₂).read loc₁ = ws.read loc₁ := by
  simp [WordStore.free, WordStore.read, hne]

theorem wordStore_cellCount_write_le (ws : WordStore) (loc : RAMCellLoc) (v : ℤ) :
    (ws.write loc v).cellCount ≤ ws.cellCount + 1 :=
  Finset.card_insert_le loc ws.live

theorem wordStore_bitSize_write_le (ws : WordStore) (loc : RAMCellLoc) (v : ℤ) :
    (ws.write loc v).bitSize ≤ ws.bitSize + loc.bitLength + intBitLength v := by
  unfold WordStore.bitSize WordStore.write
  by_cases hmem : loc ∈ ws.live
  · have hins : insert loc ws.live = ws.live := Finset.insert_eq_of_mem hmem
    rw [hins, ← Finset.insert_erase hmem,
      Finset.sum_insert (Finset.notMem_erase loc ws.live),
      Finset.sum_insert (Finset.notMem_erase loc ws.live)]
    simp only [Function.update_self]
    have hrest :
        ∑ x ∈ ws.live.erase loc, (x.bitLength + intBitLength (Function.update ws.vals loc v x)) =
          ∑ x ∈ ws.live.erase loc, (x.bitLength + intBitLength (ws.vals x)) := by
      refine Finset.sum_congr rfl fun x hx => ?_
      rw [Function.update_of_ne (Finset.ne_of_mem_erase hx)]
    rw [hrest]
    omega
  · rw [Finset.sum_insert hmem]
    simp only [Function.update_self]
    have hrest :
        ∑ x ∈ ws.live, (x.bitLength + intBitLength (Function.update ws.vals loc v x)) =
          ∑ x ∈ ws.live, (x.bitLength + intBitLength (ws.vals x)) := by
      refine Finset.sum_congr rfl fun x hx => ?_
      rw [Function.update_of_ne (by rintro rfl; exact hmem hx)]
    rw [hrest]
    omega

theorem cellCount_free_le (ws : WordStore) (loc : RAMCellLoc) :
    (ws.free loc).cellCount ≤ ws.cellCount :=
  Finset.card_erase_le

theorem bitSize_free_le (ws : WordStore) (loc : RAMCellLoc) :
    (ws.free loc).bitSize ≤ ws.bitSize := by
  unfold WordStore.bitSize WordStore.free
  calc
    ∑ l ∈ ws.live.erase loc, (l.bitLength + intBitLength (Function.update ws.vals loc 0 l))
        = ∑ l ∈ ws.live.erase loc, (l.bitLength + intBitLength (ws.vals l)) := by
          refine Finset.sum_congr rfl fun l hl => ?_
          rw [Function.update_of_ne (Finset.ne_of_mem_erase hl)]
    _ ≤ ∑ l ∈ ws.live, (l.bitLength + intBitLength (ws.vals l)) :=
          Finset.sum_le_sum_of_subset_of_nonneg (Finset.erase_subset loc ws.live)
            (fun _ _ _ => Nat.zero_le _)

theorem cellCount_popDepth_le (ws : WordStore) (keep : ℕ) :
    (ws.popDepth keep).cellCount ≤ ws.cellCount :=
  Finset.card_filter_le _ _

theorem bitSize_popDepth_le (ws : WordStore) (keep : ℕ) :
    (ws.popDepth keep).bitSize ≤ ws.bitSize := by
  unfold WordStore.bitSize WordStore.popDepth
  calc
    ∑ l ∈ ws.live.filter (fun loc => loc.keepAtDepth keep = true),
        (l.bitLength + intBitLength (if l.keepAtDepth keep then ws.vals l else 0))
        = ∑ l ∈ ws.live.filter (fun loc => loc.keepAtDepth keep = true),
            (l.bitLength + intBitLength (ws.vals l)) := by
          refine Finset.sum_congr rfl fun l hl => ?_
          rw [(Finset.mem_filter.mp hl).2, if_pos rfl]
    _ ≤ ∑ l ∈ ws.live, (l.bitLength + intBitLength (ws.vals l)) :=
          Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
            (fun _ _ _ => Nat.zero_le _)

end UL.Proof_lem_A_2
