import Mathlib
import UL.Proof.lem_A_2.H1b_FY
set_option autoImplicit false

namespace UL.Proof_lem_A_2

/-! ### 6. Big-endian bit decoding, modulo-bias coupling, Markov, and geometric retry -/

/-- Big-endian decoding of `W` bits, matching `acc := 0; repeatN W { acc := 2 * acc + bit }`. -/
def bitsToNat : (W : ℕ) → (Fin W → Bool) → ℕ
  | 0, _ => 0
  | W + 1, v => 2 * bitsToNat W (fun i => v i.castSucc) + (if v (Fin.last W) then 1 else 0)

theorem bitsToNat_lt (W : ℕ) (v : Fin W → Bool) : bitsToNat W v < 2 ^ W := by
  induction W with
  | zero => simp [bitsToNat]
  | succ W ih =>
      unfold bitsToNat
      have h := ih (fun i => v i.castSucc)
      have hpow : 2 ^ (W + 1) = 2 * 2 ^ W := by rw [pow_succ, mul_comm]
      split_ifs <;> omega

theorem bitsToNat_bijective (W : ℕ) :
    Function.Bijective (fun v : Fin W → Bool => (⟨bitsToNat W v, bitsToNat_lt W v⟩ : Fin (2 ^ W))) := by
  rw [Fintype.bijective_iff_injective_and_card]
  refine ⟨?_, by simp⟩
  induction W with
  | zero =>
      intro v₁ v₂ _
      funext i
      exact Fin.elim0 i
  | succ W ih =>
      intro v₁ v₂ heq
      have hval := congrArg Fin.val heq
      dsimp only [bitsToNat] at hval
      let b₁ : ℕ := if v₁ (Fin.last W) then 1 else 0
      let b₂ : ℕ := if v₂ (Fin.last W) then 1 else 0
      have hb₁ : b₁ < 2 := by dsimp [b₁]; split_ifs <;> omega
      have hb₂ : b₂ < 2 := by dsimp [b₂]; split_ifs <;> omega
      have h_last_nat : b₁ = b₂ := by omega
      have h_init_nat :
          bitsToNat W (fun i => v₁ i.castSucc) = bitsToNat W (fun i => v₂ i.castSucc) := by omega
      have h_init := ih (Fin.ext h_init_nat)
      funext i
      refine Fin.lastCases ?_ ?_ i
      · dsimp [b₁, b₂] at h_last_nat
        cases h1 : v₁ (Fin.last W) <;> cases h2 : v₂ (Fin.last W) <;>
          simp [h1, h2] at h_last_nat ⊢
      · intro j
        exact congrFun h_init j

/-- Lower bound on the fraction of `W`-bit tuples whose coordinatewise `% L_i` lands in `Good`. -/
theorem mod_draw_prob_ge {t W m : ℕ} (ht : 1 ≤ t) (_hm : 1 ≤ m) {L : Fin t → ℕ}
    (hL_pos : ∀ i : Fin t, 1 ≤ L i) (hL_le : ∀ i : Fin t, L i ≤ m)
    (hW : t * m ≤ 2 ^ W)
    (Good : Finset ((i : Fin t) → Fin (L i))) :
    ((Good.card : ℝ) / (∏ i : Fin t, (L i : ℝ))) *
      (1 - ((t * m : ℕ) : ℝ) / (2 ^ W : ℝ)) ≤
    ((Finset.univ.filter (fun v : Fin t → (Fin W → Bool) =>
      (fun i : Fin t => (⟨bitsToNat W (v i) % L i, Nat.mod_lt _ (hL_pos i)⟩ : Fin (L i))) ∈
        Good)).card : ℝ) / ((2 ^ W : ℝ) ^ t) := by
  classical
  let eW : (Fin W → Bool) ≃ Fin (2 ^ W) := Equiv.ofBijective _ (bitsToNat_bijective W)
  let ePi : (Fin t → (Fin W → Bool)) ≃ (Fin t → Fin (2 ^ W)) :=
    Equiv.piCongrRight fun _ => eW
  let q : Fin t → ℕ := fun i => (2 ^ W) / (L i)
  have hcard_eq :
      (Finset.univ.filter (fun v : Fin t → (Fin W → Bool) =>
        (fun i : Fin t => (⟨bitsToNat W (v i) % L i, Nat.mod_lt _ (hL_pos i)⟩ : Fin (L i))) ∈
          Good)).card =
      (Finset.univ.filter (fun x : Fin t → Fin (2 ^ W) =>
        (fun i : Fin t => (⟨(x i).1 % L i, Nat.mod_lt _ (hL_pos i)⟩ : Fin (L i))) ∈ Good)).card := by
    refine Finset.card_bij (fun v _ => ePi v) ?_ (fun _ _ _ _ h => ePi.injective h) ?_
    · intro v hv
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hv).2⟩
    · intro x hx
      refine ⟨ePi.symm x, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, ePi.apply_symm_apply x⟩
      have hx_mem := (Finset.mem_filter.mp hx).2
      have hconv : (fun i : Fin t =>
          (⟨bitsToNat W (ePi.symm x i) % L i, Nat.mod_lt _ (hL_pos i)⟩ : Fin (L i))) =
          (fun i : Fin t => (⟨(x i).1 % L i, Nat.mod_lt _ (hL_pos i)⟩ : Fin (L i))) := by
        funext i
        apply Fin.ext
        have : (eW (eW.symm (x i))).1 = (x i).1 := by simp
        exact congrArg (· % L i) this
      rwa [hconv]
  rw [hcard_eq]
  let QSet : Finset ((i : Fin t) → Fin (q i)) := Finset.univ
  let emb : ((i : Fin t) → Fin (L i)) × ((i : Fin t) → Fin (q i)) → (Fin t → Fin (2 ^ W)) :=
    fun yk i => ⟨L i * (yk.2 i).1 + (yk.1 i).1, by
      have hk_lt : (yk.2 i).1 + 1 ≤ q i := (yk.2 i).2
      have hy_lt : (yk.1 i).1 < L i := (yk.1 i).2
      have hmul : L i * ((yk.2 i).1 + 1) ≤ L i * q i := Nat.mul_le_mul_left (L i) hk_lt
      have hql : q i * L i ≤ 2 ^ W := Nat.div_mul_le_self (2 ^ W) (L i)
      nlinarith⟩
  have hemb_inj : Function.Injective emb := by
    rintro ⟨y₁, k₁⟩ ⟨y₂, k₂⟩ heq
    have h_coord : ∀ i : Fin t,
        L i * (k₂ i).1 + (y₂ i).1 = L i * (k₁ i).1 + (y₁ i).1 := fun i =>
      (congrArg Fin.val (congrFun heq i)).symm
    congr
    · funext i
      apply Fin.ext
      have hmod : (L i * (k₂ i).1 + (y₂ i).1) % L i = (L i * (k₁ i).1 + (y₁ i).1) % L i :=
        congrArg (· % L i) (h_coord i)
      rw [Nat.mul_add_mod, Nat.mod_eq_of_lt (y₂ i).2,
        Nat.mul_add_mod, Nat.mod_eq_of_lt (y₁ i).2] at hmod
      exact hmod.symm
    · funext i
      apply Fin.ext
      have hdiv : (L i * (k₂ i).1 + (y₂ i).1) / L i = (L i * (k₁ i).1 + (y₁ i).1) / L i :=
        congrArg (· / L i) (h_coord i)
      rw [Nat.mul_add_div (hL_pos i), Nat.div_eq_of_lt (y₂ i).2, add_zero,
        Nat.mul_add_div (hL_pos i), Nat.div_eq_of_lt (y₁ i).2, add_zero] at hdiv
      exact hdiv.symm
  have himg_sub :
      (Good ×ˢ QSet).image emb ⊆
        Finset.univ.filter (fun x : Fin t → Fin (2 ^ W) =>
          (fun i : Fin t => (⟨(x i).1 % L i, Nat.mod_lt _ (hL_pos i)⟩ : Fin (L i))) ∈ Good) := by
    intro x hx
    rcases Finset.mem_image.mp hx with ⟨⟨y, k⟩, hyk, rfl⟩
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
    have hy_good : y ∈ Good := (Finset.mem_product.mp hyk).1
    have hmod_eq :
        (fun i : Fin t => (⟨(emb (y, k) i).1 % L i, Nat.mod_lt _ (hL_pos i)⟩ : Fin (L i))) = y := by
      funext i
      apply Fin.ext
      dsimp [emb]
      rw [Nat.mul_add_mod, Nat.mod_eq_of_lt (y i).2]
    rwa [hmod_eq]
  have hcard_ge :
      Good.card * (∏ i : Fin t, q i) ≤
        (Finset.univ.filter (fun x : Fin t → Fin (2 ^ W) =>
          (fun i : Fin t => (⟨(x i).1 % L i, Nat.mod_lt _ (hL_pos i)⟩ : Fin (L i))) ∈ Good)).card := by
    have h1 := Finset.card_le_card himg_sub
    rw [Finset.card_image_of_injective _ hemb_inj, Finset.card_product] at h1
    have hQ : QSet.card = ∏ i : Fin t, q i := by
      simp [QSet, Fintype.card_pi]
    rwa [hQ] at h1
  have hpowW_pos : (0 : ℝ) < (2 ^ W : ℝ) := by positivity
  have hm_le_tm : m ≤ t * m := Nat.le_mul_of_pos_left m (by omega)
  have hm_le_W : (m : ℝ) ≤ (2 ^ W : ℝ) := by exact_mod_cast (hm_le_tm.trans hW)
  have h_one_sub_nn : 0 ≤ 1 - (m : ℝ) / (2 ^ W : ℝ) := by
    have : (m : ℝ) / (2 ^ W : ℝ) ≤ 1 := (div_le_one hpowW_pos).mpr hm_le_W
    linarith
  have hqi_ge : ∀ i : Fin t,
      (1 / (L i : ℝ)) * (1 - (m : ℝ) / (2 ^ W : ℝ)) ≤ (q i : ℝ) / (2 ^ W : ℝ) := by
    intro i
    have hLi_pos : (0 : ℝ) < (L i : ℝ) := by exact_mod_cast hL_pos i
    have hrem : 2 ^ W % L i < L i := Nat.mod_lt _ (hL_pos i)
    have hdiv_mod := Nat.div_add_mod (2 ^ W) (L i)
    have hnat : 2 ^ W ≤ q i * L i + m := by
      have := hL_le i
      dsimp [q]
      nlinarith
    have hreal : (2 ^ W : ℝ) - (m : ℝ) ≤ (q i : ℝ) * (L i : ℝ) := by
      have h2 : (2 ^ W : ℝ) ≤ (q i : ℝ) * (L i : ℝ) + (m : ℝ) := by exact_mod_cast hnat
      linarith
    rw [one_div, inv_mul_eq_div, div_le_div_iff₀ hLi_pos hpowW_pos]
    calc
      (1 - (m : ℝ) / (2 ^ W : ℝ)) * (2 ^ W : ℝ)
          = (2 ^ W : ℝ) - (m : ℝ) := by field_simp [hpowW_pos.ne']
      _ ≤ (q i : ℝ) * (L i : ℝ) := hreal
  have hprod_ge :
      (∏ i : Fin t, (1 / (L i : ℝ))) * (1 - (m : ℝ) / (2 ^ W : ℝ)) ^ t ≤
        (∏ i : Fin t, (q i : ℝ)) / ((2 ^ W : ℝ) ^ t) := by
    calc
      (∏ i : Fin t, (1 / (L i : ℝ))) * (1 - (m : ℝ) / (2 ^ W : ℝ)) ^ t
          = ∏ i : Fin t, ((1 / (L i : ℝ)) * (1 - (m : ℝ) / (2 ^ W : ℝ))) := by
              rw [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ, Fintype.card_fin]
      _ ≤ ∏ i : Fin t, ((q i : ℝ) / (2 ^ W : ℝ)) :=
            Finset.prod_le_prod (fun i _ => by positivity) (fun i _ => hqi_ge i)
      _ = (∏ i : Fin t, (q i : ℝ)) / ((2 ^ W : ℝ) ^ t) := by
            rw [Finset.prod_div_distrib, Finset.prod_const, Finset.card_univ, Fintype.card_fin]
  have hbern :
      1 - ((t * m : ℕ) : ℝ) / (2 ^ W : ℝ) ≤ (1 - (m : ℝ) / (2 ^ W : ℝ)) ^ t := by
    set δ : ℝ := (m : ℝ) / (2 ^ W : ℝ)
    have hδ0 : 0 ≤ δ := by positivity
    have hδ1 : 0 ≤ 1 - δ := h_one_sub_nn
    have haux : ∀ k : ℕ, 1 - (k : ℝ) * δ ≤ (1 - δ) ^ k := by
      intro k
      induction k with
      | zero => simp
      | succ k ih =>
          rw [pow_succ]
          push_cast
          have hmul : (1 - (k : ℝ) * δ) * (1 - δ) ≤ ((1 - δ) ^ k) * (1 - δ) :=
            mul_le_mul_of_nonneg_right ih hδ1
          have hkδ2 : 0 ≤ (k : ℝ) * (δ * δ) := by positivity
          nlinarith
    have h1 := haux t
    have hrew : 1 - ((t * m : ℕ) : ℝ) / (2 ^ W : ℝ) = 1 - (t : ℝ) * δ := by
      dsimp [δ]
      push_cast
      ring
    rwa [hrew]
  have hprod_inv : (∏ i : Fin t, (1 / (L i : ℝ))) = 1 / (∏ i : Fin t, (L i : ℝ)) := by
    simp_rw [one_div]
    rw [Finset.prod_inv_distrib]
  calc
    ((Good.card : ℝ) / (∏ i : Fin t, (L i : ℝ))) * (1 - ((t * m : ℕ) : ℝ) / (2 ^ W : ℝ))
        = (Good.card : ℝ) * ((∏ i : Fin t, (1 / (L i : ℝ))) *
            (1 - ((t * m : ℕ) : ℝ) / (2 ^ W : ℝ))) := by
          rw [hprod_inv, div_eq_mul_inv, one_div]
          ring
    _ ≤ (Good.card : ℝ) * ((∏ i : Fin t, (1 / (L i : ℝ))) *
          (1 - (m : ℝ) / (2 ^ W : ℝ)) ^ t) := by
          gcongr
    _ ≤ (Good.card : ℝ) * ((∏ i : Fin t, (q i : ℝ)) / ((2 ^ W : ℝ) ^ t)) := by
          gcongr
    _ = ((Good.card : ℝ) * (∏ i : Fin t, (q i : ℝ))) / ((2 ^ W : ℝ) ^ t) :=
          (mul_div_assoc _ _ _).symm
    _ ≤ ((Finset.univ.filter (fun x : Fin t → Fin (2 ^ W) =>
          (fun i : Fin t => (⟨(x i).1 % L i, Nat.mod_lt _ (hL_pos i)⟩ : Fin (L i))) ∈ Good)).card : ℝ) /
          ((2 ^ W : ℝ) ^ t) := by
          gcongr
          exact_mod_cast hcard_ge

/-- Markov's inequality on `r ≥ 1` block indicators: if each block passes on at least `9 / 10`
of inputs `u : α`, then at least `4 / 5` of inputs `u` pass at least `⌈r / 2⌉` blocks (`r ≤ 2 * passCount`). -/
theorem markov_half_blocks_pass {α : Type*} [Fintype α] [Nonempty α]
    {r : ℕ} (hr : 1 ≤ r) (pass : α → Fin r → Bool)
    (hblk : ∀ b : Fin r,
      9 / 10 ≤ ((Finset.univ.filter (fun u : α => pass u b = true)).card : ℝ) /
        (Fintype.card α : ℝ)) :
    4 / 5 ≤
      ((Finset.univ.filter (fun u : α =>
        r ≤ 2 * (Finset.univ.filter (fun b : Fin r => pass u b = true)).card)).card : ℝ) /
      (Fintype.card α : ℝ) := by
  classical
  let N : ℝ := Fintype.card α
  have hN_pos : 0 < N := by dsimp [N]; exact_mod_cast Fintype.card_pos (α := α)
  let passCnt : α → ℕ := fun u => (Finset.univ.filter (fun b : Fin r => pass u b = true)).card
  let failCnt : α → ℕ := fun u => (Finset.univ.filter (fun b : Fin r => ¬ (pass u b = true))).card
  have h_add : ∀ u : α, passCnt u + failCnt u = r := by
    intro u
    have h := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset (Fin r)))
      (fun b => pass u b = true)
    simpa [passCnt, failCnt] using h
  have h_fail_b : ∀ b : Fin r,
      ((Finset.univ.filter (fun u : α => ¬ (pass u b = true))).card : ℝ) ≤ (1 / 10) * N := by
    intro b
    have hsum := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset α))
      (fun u => pass u b = true)
    rw [Finset.card_univ] at hsum
    have hsum_r :
        ((Finset.univ.filter (fun u : α => pass u b = true)).card : ℝ) +
          ((Finset.univ.filter (fun u : α => ¬ (pass u b = true))).card : ℝ) = N := by
      dsimp [N]
      exact_mod_cast hsum
    have hb := (le_div_iff₀ hN_pos).mp (hblk b)
    linarith
  have h_sum_fail :
      (∑ u : α, (failCnt u : ℝ)) ≤ (r : ℝ) * ((1 / 10) * N) := by
    have hswap :
        (∑ u : α, (failCnt u : ℝ)) =
          ∑ b : Fin r, ((Finset.univ.filter (fun u : α => ¬ (pass u b = true))).card : ℝ) := by
      simp only [failCnt, Finset.card_filter, Nat.cast_sum, Nat.cast_ite, Nat.cast_one,
        Nat.cast_zero]
      exact Finset.sum_comm
    rw [hswap]
    calc
      ∑ b : Fin r, ((Finset.univ.filter (fun u : α => ¬ (pass u b = true))).card : ℝ)
          ≤ ∑ _b : Fin r, ((1 / 10) * N) := Finset.sum_le_sum fun b _ => h_fail_b b
      _ = (r : ℝ) * ((1 / 10) * N) := by simp
  let BadU : Finset α := Finset.univ.filter (fun u : α => ¬ (r ≤ 2 * passCnt u))
  let GoodU : Finset α := Finset.univ.filter (fun u : α => r ≤ 2 * passCnt u)
  have h_bad_lb : ∀ u ∈ BadU, ((r : ℝ) / 2) ≤ (failCnt u : ℝ) := by
    intro u hu
    have hnot : ¬ (r ≤ 2 * passCnt u) := (Finset.mem_filter.mp hu).2
    have hgt : r < 2 * failCnt u := by have := h_add u; omega
    have hgt_r : (r : ℝ) ≤ 2 * (failCnt u : ℝ) := by exact_mod_cast (le_of_lt hgt)
    linarith
  have h_markov : (BadU.card : ℝ) * ((r : ℝ) / 2) ≤ (r : ℝ) * ((1 / 10) * N) := by
    calc
      (BadU.card : ℝ) * ((r : ℝ) / 2)
          = ∑ _u ∈ BadU, ((r : ℝ) / 2) := by simp
      _ ≤ ∑ u ∈ BadU, (failCnt u : ℝ) := Finset.sum_le_sum h_bad_lb
      _ ≤ ∑ u ∈ (Finset.univ : Finset α), (failCnt u : ℝ) :=
            Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun _ _ _ => by positivity)
      _ ≤ (r : ℝ) * ((1 / 10) * N) := h_sum_fail
  have hr_pos : (0 : ℝ) < (r : ℝ) := by exact_mod_cast hr
  have hBad_le : (BadU.card : ℝ) ≤ (1 / 5) * N := by
    nlinarith
  have hGU_add : (GoodU.card : ℝ) + (BadU.card : ℝ) = N := by
    have h := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset α))
      (fun u => r ≤ 2 * passCnt u)
    rw [Finset.card_univ] at h
    dsimp [GoodU, BadU, N]
    exact_mod_cast h
  rw [le_div_iff₀ hN_pos]
  dsimp [GoodU] at hGU_add
  linarith

/-- Split a flat `(M * W₁ + m * W₂)`-bit vector into Phase-1 and Phase-2 bit matrices. -/
def splitAttemptBits (M W₁ m W₂ : ℕ) (v : Fin (M * W₁ + m * W₂) → Bool) :
    (Fin M → Fin W₁ → Bool) × (Fin m → Fin W₂ → Bool) :=
  (fun j b => v ⟨j.1 * W₁ + b.1, by
      have hj : (j.1 + 1) * W₁ ≤ M * W₁ := Nat.mul_le_mul_right W₁ j.2
      have hb : b.1 < W₁ := b.2
      nlinarith⟩,
   fun i b => v ⟨M * W₁ + (i.1 * W₂ + b.1), by
      have hi : (i.1 + 1) * W₂ ≤ m * W₂ := Nat.mul_le_mul_right W₂ i.2
      have hb : b.1 < W₂ := b.2
      nlinarith⟩)

theorem splitAttemptBits_bijective (M W₁ m W₂ : ℕ) :
    Function.Bijective (splitAttemptBits M W₁ m W₂) := by
  rw [Fintype.bijective_iff_injective_and_card]
  refine ⟨?_, ?_⟩
  · intro v₁ v₂ heq
    have h1 := congrArg Prod.fst heq
    have h2 := congrArg Prod.snd heq
    funext idx
    by_cases hlt : idx.1 < M * W₁
    · have hW1_pos : 0 < W₁ := by
        by_contra h0; simp [Nat.eq_zero_of_not_pos h0] at hlt
      have hlt' : idx.1 < W₁ * M := by linarith
      let j : Fin M := ⟨idx.1 / W₁, Nat.div_lt_of_lt_mul hlt'⟩
      let b : Fin W₁ := ⟨idx.1 % W₁, Nat.mod_lt _ hW1_pos⟩
      have hidx : (⟨j.1 * W₁ + b.1, by
          have hj : (j.1 + 1) * W₁ ≤ M * W₁ := Nat.mul_le_mul_right W₁ j.2
          have hb : b.1 < W₁ := b.2
          nlinarith⟩ : Fin (M * W₁ + m * W₂)) = idx := by
        apply Fin.ext
        dsimp [j, b]
        rw [mul_comm, Nat.div_add_mod]
      have hv := congrFun (congrFun h1 j) b
      simpa [splitAttemptBits, hidx] using hv
    · push_neg at hlt
      have hidx_bound := idx.2
      set rem := idx.1 - M * W₁
      have hrem_lt : rem < m * W₂ := by omega
      have hW2_pos : 0 < W₂ := by
        by_contra h0; simp [Nat.eq_zero_of_not_pos h0] at hrem_lt
      have hrem_lt' : rem < W₂ * m := by linarith
      let i : Fin m := ⟨rem / W₂, Nat.div_lt_of_lt_mul hrem_lt'⟩
      let b : Fin W₂ := ⟨rem % W₂, Nat.mod_lt _ hW2_pos⟩
      have hidx : (⟨M * W₁ + (i.1 * W₂ + b.1), by
          have hi : (i.1 + 1) * W₂ ≤ m * W₂ := Nat.mul_le_mul_right W₂ i.2
          have hb : b.1 < W₂ := b.2
          nlinarith⟩ : Fin (M * W₁ + m * W₂)) = idx := by
        apply Fin.ext
        have hdiv : i.1 * W₂ + b.1 = idx.1 - M * W₁ := by
          dsimp [i, b, rem]; rw [mul_comm, Nat.div_add_mod]
        change M * W₁ + (i.1 * W₂ + b.1) = idx.1
        rw [hdiv, Nat.add_sub_cancel' hlt]
      have hv := congrFun (congrFun h2 i) b
      simpa [splitAttemptBits, hidx] using hv
  · simp only [Fintype.card_prod, Fintype.card_pi, Finset.prod_const, Finset.card_univ,
      Fintype.card_fin, Fintype.card_bool]
    rw [← pow_mul, ← pow_mul, ← pow_add]
    congr 1; ring

/-- Combined probability bound: at least `1 / 2` of `(M * W₁ + m * W₂)`-bit chunks succeed. -/
theorem attempt_success_prob_ge_half
    {M W₁ m W₂ s₀ : ℕ}
    (hM : 1 ≤ M) (hs₀ : 1 ≤ s₀) (hm : 2 * s₀ ≤ m)
    (hW₁ : 64 * (M * m) ≤ 2 ^ W₁)
    (hW₂ : 64 * (m * m) ≤ 2 ^ W₂)
    (goodSample : (Fin M → Fin m) → Bool)
    (hGoodSample :
      9 / 10 ≤ ((Finset.univ.filter (fun ω : Fin M → Fin m => goodSample ω = true)).card : ℝ) /
        (Fintype.card (Fin M → Fin m) : ℝ))
    (passBlock : (Fin M → Fin m) → Finset (Fin m) → Bool)
    (hPassBlock : ∀ ω : Fin M → Fin m, goodSample ω = true →
      9 / 10 ≤
        ((((Finset.univ : Finset (Fin m)).powersetCard s₀).filter
          (fun S => passBlock ω S = true)).card : ℝ) /
        (((Finset.univ : Finset (Fin m)).powersetCard s₀).card : ℝ)) :
    let r : ℕ := m / s₀
    have hrs : r * s₀ ≤ m := Nat.div_mul_le_self m s₀
    1 / 2 ≤
      ((Finset.univ.filter (fun v : Fin (M * W₁ + m * W₂) → Bool =>
        let sp := splitAttemptBits M W₁ m W₂ v
        let ω : Fin M → Fin m := fun j =>
          ⟨bitsToNat W₁ (sp.1 j) % m, Nat.mod_lt _ (by omega)⟩
        let u : (i : Fin m) → Fin (m - i.1) := fun i =>
          ⟨bitsToNat W₂ (sp.2 i) % (m - i.1), Nat.mod_lt _ (by have := i.2; omega)⟩
        let k_pass : ℕ :=
          (Finset.univ.filter (fun b : Fin r =>
            passBlock ω (sliceBlockSet hrs (fyPerm u) b) = true)).card
        decide (r ≤ 2 * k_pass))).card : ℝ) /
      ((2 : ℝ) ^ (M * W₁ + m * W₂)) := by
  classical
  set r : ℕ := m / s₀
  have hrs : r * s₀ ≤ m := Nat.div_mul_le_self m s₀
  have hm1 : 1 ≤ m := by omega
  have hr1 : 1 ≤ r := by
    have : 2 * s₀ / s₀ ≤ m / s₀ := Nat.div_le_div_right hm
    rw [Nat.mul_div_cancel _ (by omega)] at this
    omega
  -- Phase 1 bound on V₁ := Fin M → Fin W₁ → Bool
  let Good1 : Finset (Fin M → Fin m) := Finset.univ.filter (fun ω => goodSample ω = true)
  let V1Good : Finset (Fin M → Fin W₁ → Bool) :=
    Finset.univ.filter (fun v1 =>
      (fun j : Fin M => (⟨bitsToNat W₁ (v1 j) % m, Nat.mod_lt _ (by omega)⟩ : Fin m)) ∈ Good1)
  have hp1 := mod_draw_prob_ge (t := M) (W := W₁) (m := m) hM hm1
    (L := fun _ => m) (fun _ => hm1) (fun _ => le_rfl)
    ((Nat.le_mul_of_pos_left (M * m) (by norm_num : 0 < 64)).trans hW₁) Good1
  have hprod1 : (∏ _j : Fin M, (m : ℝ)) = (Fintype.card (Fin M → Fin m) : ℝ) := by
    simp [Fintype.card_pi]
  rw [hprod1] at hp1
  have htail1 : (63 / 64 : ℝ) ≤ 1 - ((M * m : ℕ) : ℝ) / (2 ^ W₁ : ℝ) := by
    have hpow_pos : (0 : ℝ) < (2 ^ W₁ : ℝ) := by positivity
    have h64 : 64 * ((M * m : ℕ) : ℝ) ≤ (2 ^ W₁ : ℝ) := by exact_mod_cast hW₁
    have hdiv : ((M * m : ℕ) : ℝ) / (2 ^ W₁ : ℝ) ≤ 1 / 64 := by
      rw [div_le_iff₀ hpow_pos]
      linarith
    linarith
  have hv1_lb :
      (567 / 640 : ℝ) ≤ (V1Good.card : ℝ) / ((2 ^ W₁ : ℝ) ^ M) := by
    have hmul : (9 / 10 : ℝ) * (63 / 64) ≤
        ((Good1.card : ℝ) / (Fintype.card (Fin M → Fin m) : ℝ)) *
          (1 - ((M * m : ℕ) : ℝ) / (2 ^ W₁ : ℝ)) :=
      mul_le_mul hGoodSample htail1 (by norm_num) (by positivity)
    linarith
  -- Phase 2 bound for each fixed ω ∈ Good1
  have hv2_lb : ∀ ω : Fin M → Fin m, ω ∈ Good1 →
      (504 / 640 : ℝ) ≤
        ((Finset.univ.filter (fun v2 : Fin m → Fin W₂ → Bool =>
          let u : (i : Fin m) → Fin (m - i.1) := fun i =>
            ⟨bitsToNat W₂ (v2 i) % (m - i.1), Nat.mod_lt _ (by have := i.2; omega)⟩
          r ≤ 2 * (Finset.univ.filter (fun b : Fin r =>
            passBlock ω (sliceBlockSet hrs (fyPerm u) b) = true)).card)).card : ℝ) /
        ((2 ^ W₂ : ℝ) ^ m) := by
    intro ω hω
    have hω_good : goodSample ω = true := (Finset.mem_filter.mp hω).2
    let Good2 : Finset ((i : Fin m) → Fin (m - i.1)) :=
      Finset.univ.filter (fun u =>
        r ≤ 2 * (Finset.univ.filter (fun b : Fin r =>
          passBlock ω (sliceBlockSet hrs (fyPerm u) b) = true)).card)
    haveI : Nonempty ((i : Fin m) → Fin (m - i.1)) :=
      ⟨fun i => ⟨0, by have := i.2; omega⟩⟩
    have hmarkov :
        (4 / 5 : ℝ) ≤ (Good2.card : ℝ) / (Fintype.card ((i : Fin m) → Fin (m - i.1)) : ℝ) := by
      refine markov_half_blocks_pass hr1
        (fun u b => passBlock ω (sliceBlockSet hrs (fyPerm u) b)) (fun b => ?_)
      rw [fyPerm_block_prob_eq hrs b (passBlock ω)]
      exact hPassBlock ω hω_good
    have hp2 := mod_draw_prob_ge (t := m) (W := W₂) (m := m) hm1 hm1
      (L := fun i => m - i.1) (fun i => Nat.sub_pos_of_lt i.2) (fun _ => Nat.sub_le _ _)
      ((Nat.le_mul_of_pos_left (m * m) (by norm_num : 0 < 64)).trans hW₂) Good2
    have hprod2 : (∏ i : Fin m, ((m - i.1 : ℕ) : ℝ)) =
        (Fintype.card ((i : Fin m) → Fin (m - i.1)) : ℝ) := by
      simp [Fintype.card_pi]
    rw [hprod2] at hp2
    have htail2 : (63 / 64 : ℝ) ≤ 1 - ((m * m : ℕ) : ℝ) / (2 ^ W₂ : ℝ) := by
      have hpow_pos : (0 : ℝ) < (2 ^ W₂ : ℝ) := by positivity
      have h64 : 64 * ((m * m : ℕ) : ℝ) ≤ (2 ^ W₂ : ℝ) := by exact_mod_cast hW₂
      have hdiv : ((m * m : ℕ) : ℝ) / (2 ^ W₂ : ℝ) ≤ 1 / 64 := by
        rw [div_le_iff₀ hpow_pos]
        linarith
      linarith
    have hmul : (4 / 5 : ℝ) * (63 / 64) ≤
        ((Good2.card : ℝ) / (Fintype.card ((i : Fin m) → Fin (m - i.1)) : ℝ)) *
          (1 - ((m * m : ℕ) : ℝ) / (2 ^ W₂ : ℝ)) :=
      mul_le_mul hmarkov htail2 (by norm_num) (by positivity)
    have hfilt2 :
        (Finset.univ.filter (fun v : Fin m → Fin W₂ → Bool =>
          (fun i : Fin m => ⟨bitsToNat W₂ (v i) % (m - i.1), Nat.mod_lt _ (Nat.sub_pos_of_lt i.2)⟩) ∈ Good2)) =
        (Finset.univ.filter (fun v2 : Fin m → Fin W₂ → Bool =>
          let u : (i : Fin m) → Fin (m - i.1) := fun i =>
            ⟨bitsToNat W₂ (v2 i) % (m - i.1), Nat.mod_lt _ (by have := i.2; omega)⟩
          r ≤ 2 * (Finset.univ.filter (fun b : Fin r =>
            passBlock ω (sliceBlockSet hrs (fyPerm u) b) = true)).card)) := by
      ext v; simp [Good2]
    rw [hfilt2] at hp2
    have h504 : (504 / 640 : ℝ) = (4 / 5 : ℝ) * (63 / 64) := by norm_num
    rw [h504]
    exact hmul.trans hp2
  -- Combine Phase 1 × Phase 2 via `splitAttemptBits`
  let eSplit := Equiv.ofBijective _ (splitAttemptBits_bijective M W₁ m W₂)
  let V2Good : (Fin M → Fin W₁ → Bool) → Finset (Fin m → Fin W₂ → Bool) :=
    fun v1 =>
      let ω : Fin M → Fin m := fun j => ⟨bitsToNat W₁ (v1 j) % m, Nat.mod_lt _ (by omega)⟩
      Finset.univ.filter (fun v2 =>
        let u : (i : Fin m) → Fin (m - i.1) := fun i =>
          ⟨bitsToNat W₂ (v2 i) % (m - i.1), Nat.mod_lt _ (by have := i.2; omega)⟩
        r ≤ 2 * (Finset.univ.filter (fun b : Fin r =>
          passBlock ω (sliceBlockSet hrs (fyPerm u) b) = true)).card)
  let PairGood : Finset ((Fin M → Fin W₁ → Bool) × (Fin m → Fin W₂ → Bool)) :=
    V1Good.sigma V2Good |>.map
      ⟨fun p => (p.1, p.2), fun p₁ p₂ h => by
        rcases p₁ with ⟨a₁, b₁⟩; rcases p₂ with ⟨a₂, b₂⟩
        injection h with ha hb; subst ha; subst hb; rfl⟩
  have hPair_le :
      PairGood.card ≤
        (Finset.univ.filter (fun v : Fin (M * W₁ + m * W₂) → Bool =>
          let sp := splitAttemptBits M W₁ m W₂ v
          let ω : Fin M → Fin m := fun j =>
            ⟨bitsToNat W₁ (sp.1 j) % m, Nat.mod_lt _ (by omega)⟩
          let u : (i : Fin m) → Fin (m - i.1) := fun i =>
            ⟨bitsToNat W₂ (sp.2 i) % (m - i.1), Nat.mod_lt _ (by have := i.2; omega)⟩
          let k_pass : ℕ :=
            (Finset.univ.filter (fun b : Fin r =>
              passBlock ω (sliceBlockSet hrs (fyPerm u) b) = true)).card
          decide (r ≤ 2 * k_pass) = true)).card := by
    have himg :
        PairGood.image eSplit.symm ⊆
          Finset.univ.filter (fun v : Fin (M * W₁ + m * W₂) → Bool =>
            let sp := splitAttemptBits M W₁ m W₂ v
            let ω : Fin M → Fin m := fun j =>
              ⟨bitsToNat W₁ (sp.1 j) % m, Nat.mod_lt _ (by omega)⟩
            let u : (i : Fin m) → Fin (m - i.1) := fun i =>
              ⟨bitsToNat W₂ (sp.2 i) % (m - i.1), Nat.mod_lt _ (by have := i.2; omega)⟩
            let k_pass : ℕ :=
              (Finset.univ.filter (fun b : Fin r =>
                passBlock ω (sliceBlockSet hrs (fyPerm u) b) = true)).card
            decide (r ≤ 2 * k_pass) = true) := by
      intro v hv
      rcases Finset.mem_image.mp hv with ⟨⟨v1, v2⟩, hpair, rfl⟩
      rcases Finset.mem_map.mp hpair with ⟨⟨v1', v2'⟩, hsig, heq_p⟩
      dsimp at heq_p
      injection heq_p with hv1_eq hv2_eq
      subst hv1_eq; subst hv2_eq
      have hv2_mem : v2' ∈ V2Good v1' := (Finset.mem_sigma.mp hsig).2
      have hpass := (Finset.mem_filter.mp hv2_mem).2
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
      have hsp : splitAttemptBits M W₁ m W₂ (eSplit.symm (v1', v2')) = (v1', v2') :=
        eSplit.apply_symm_apply (v1', v2')
      simpa [hsp] using hpass
    have h1 := Finset.card_le_card himg
    rwa [Finset.card_image_of_injective _ eSplit.symm.injective] at h1
  have hPair_card : (PairGood.card : ℝ) = ∑ v1 ∈ V1Good, ((V2Good v1).card : ℝ) := by
    simp [PairGood, Finset.card_sigma, Nat.cast_sum]
  have h_sum_lb :
      (V1Good.card : ℝ) * ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ m)) ≤ (PairGood.card : ℝ) := by
    rw [hPair_card]
    calc
      (V1Good.card : ℝ) * ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ m))
          = ∑ _v1 ∈ V1Good, ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ m)) := by simp
      _ ≤ ∑ v1 ∈ V1Good, ((V2Good v1).card : ℝ) := by
            refine Finset.sum_le_sum fun v1 hv1 => ?_
            have hω_mem : (fun j : Fin M =>
                (⟨bitsToNat W₁ (v1 j) % m, Nat.mod_lt _ (by omega)⟩ : Fin m)) ∈ Good1 :=
              (Finset.mem_filter.mp hv1).2
            exact (le_div_iff₀ (by positivity)).mp (hv2_lb _ hω_mem)
  have h_tot_denom :
      (2 : ℝ) ^ (M * W₁ + m * W₂) = ((2 ^ W₁ : ℝ) ^ M) * ((2 ^ W₂ : ℝ) ^ m) := by
    rw [pow_add, mul_comm M W₁, pow_mul, mul_comm m W₂, pow_mul]
  rw [h_tot_denom]
  have hden_pos : (0 : ℝ) < ((2 ^ W₁ : ℝ) ^ M) * ((2 ^ W₂ : ℝ) ^ m) := by positivity
  rw [le_div_iff₀ hden_pos]
  have hv1_mul : (567 / 640 : ℝ) * ((2 ^ W₁ : ℝ) ^ M) ≤ (V1Good.card : ℝ) :=
    (le_div_iff₀ (by positivity)).mp hv1_lb
  have hprod_lb :
      (567 / 640 : ℝ) * (504 / 640 : ℝ) * (((2 ^ W₁ : ℝ) ^ M) * ((2 ^ W₂ : ℝ) ^ m)) ≤
        (PairGood.card : ℝ) := by
    calc
      (567 / 640 : ℝ) * (504 / 640 : ℝ) * (((2 ^ W₁ : ℝ) ^ M) * ((2 ^ W₂ : ℝ) ^ m))
          = ((567 / 640 : ℝ) * ((2 ^ W₁ : ℝ) ^ M)) *
              ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ m)) := by ring
      _ ≤ (V1Good.card : ℝ) * ((504 / 640 : ℝ) * ((2 ^ W₂ : ℝ) ^ m)) :=
            mul_le_mul_of_nonneg_right hv1_mul (by positivity)
      _ ≤ (PairGood.card : ℝ) := h_sum_lb
  have hPair_real := (Nat.cast_le (α := ℝ)).mpr hPair_le
  simp only [Bool.decide_coe] at hPair_real ⊢
  have hhalf : (1 / 2 : ℝ) ≤ (567 / 640 : ℝ) * (504 / 640 : ℝ) := by norm_num
  nlinarith

/-! ### 7. Fixed-length chunk geometric retry `tsum` bounds -/

/-- Concatenate `t` failed `N`-bit chunks followed by one accepted `N`-bit chunk. -/
def chunkList {N : ℕ} {acc : (Fin N → Bool) → Bool} :
    (t : ℕ) → (Fin t → {v : Fin N → Bool // acc v = false}) →
      {v : Fin N → Bool // acc v = true} → List Bool
  | 0, _, good => List.ofFn good.1
  | t + 1, bad, good => List.ofFn (bad 0).1 ++ chunkList t (fun i => bad i.succ) good

theorem chunkList_length {N : ℕ} {acc : (Fin N → Bool) → Bool} :
    ∀ (t : ℕ) (bad : Fin t → {v : Fin N → Bool // acc v = false})
      (good : {v : Fin N → Bool // acc v = true}),
      (chunkList t bad good).length = (t + 1) * N
  | 0, _, good => by simp [chunkList]
  | t + 1, bad, good => by
      simp only [chunkList, List.length_append, List.length_ofFn,
        chunkList_length t (fun i => bad i.succ) good]
      ring

theorem chunkList_injective {N : ℕ} {acc : (Fin N → Bool) → Bool} :
    Function.Injective
      (fun x : Σ t : ℕ, (Fin t → {v : Fin N → Bool // acc v = false}) ×
          {v : Fin N → Bool // acc v = true} =>
        chunkList x.1 x.2.1 x.2.2) := by
  let Dom := Σ t : ℕ, (Fin t → {v : Fin N → Bool // acc v = false}) ×
      {v : Fin N → Bool // acc v = true}
  have haux : ∀ (t₁ : ℕ)
      (bad₁ : Fin t₁ → {v : Fin N → Bool // acc v = false})
      (good₁ : {v : Fin N → Bool // acc v = true})
      (t₂ : ℕ)
      (bad₂ : Fin t₂ → {v : Fin N → Bool // acc v = false})
      (good₂ : {v : Fin N → Bool // acc v = true}),
      chunkList t₁ bad₁ good₁ = chunkList t₂ bad₂ good₂ →
      (⟨t₁, (bad₁, good₁)⟩ : Dom) = ⟨t₂, (bad₂, good₂)⟩ := by
    intro t₁
    induction t₁ with
    | zero =>
        intro bad₁ good₁ t₂ bad₂ good₂ heq
        cases t₂ with
        | zero =>
            dsimp [chunkList] at heq
            have hg' : good₁ = good₂ := Subtype.ext (List.ofFn_injective heq)
            subst hg'
            have hb : bad₁ = bad₂ := funext fun i => Fin.elim0 i
            subst hb
            rfl
        | succ t₂ =>
            dsimp [chunkList] at heq
            have htake := congrArg (List.take N) heq
            rw [List.take_of_length_le (by simp),
              List.take_left' (by simp)] at htake
            have hveq : good₁.1 = (bad₂ 0).1 := List.ofFn_injective htake
            have h1 := good₁.2
            have h2 := (bad₂ 0).2
            rw [hveq, h2] at h1
            nomatch h1
    | succ t₁ ih =>
        intro bad₁ good₁ t₂ bad₂ good₂ heq
        cases t₂ with
        | zero =>
            dsimp [chunkList] at heq
            have htake := congrArg (List.take N) heq
            rw [List.take_left' (by simp), List.take_of_length_le (by simp)] at htake
            have hveq : (bad₁ 0).1 = good₂.1 := List.ofFn_injective htake
            have h1 := (bad₁ 0).2
            have h2 := good₂.2
            rw [hveq, h2] at h1
            nomatch h1
        | succ t₂ =>
            dsimp [chunkList] at heq
            obtain ⟨hhead, htail⟩ := List.append_inj heq (by simp)
            have hb0 : bad₁ 0 = bad₂ 0 := Subtype.ext (List.ofFn_injective hhead)
            have hrec := ih (fun i : Fin t₁ => bad₁ i.succ) good₁ t₂ (fun i : Fin t₂ => bad₂ i.succ) good₂ htail
            injection hrec with ht hrest
            subst ht
            have hpair : ((fun i : Fin t₁ => bad₁ i.succ), good₁) =
                ((fun i : Fin t₁ => bad₂ i.succ), good₂) :=
              eq_of_heq hrest
            obtain ⟨hbsucc, hgood⟩ := Prod.mk.inj hpair
            subst hgood
            have hbad : bad₁ = bad₂ := by
              funext i
              refine Fin.cases ?_ ?_ i
              · exact hb0
              · intro j; exact congrFun hbsucc j
            subst hbad
            rfl
  rintro ⟨t₁, bad₁, good₁⟩ ⟨t₂, bad₂, good₂⟩ heq
  exact haux t₁ bad₁ good₁ t₂ bad₂ good₂ heq

private theorem summable_half_pow_mul_succ :
    Summable (fun t : ℕ => ((1 / 2 : ℝ) ^ t) * ((t : ℝ) + 1)) := by
  have hdom : Summable (fun t : ℕ => 2 * ((3 / 4 : ℝ) ^ t)) :=
    (summable_geometric_of_lt_one (by norm_num) (by norm_num)).mul_left 2
  refine Summable.of_nonneg_of_le (fun t => by positivity) (fun t => ?_) hdom
  have h32 : ((t : ℝ) + 1) ≤ 2 * ((3 / 2 : ℝ) ^ t) := by
    induction t with
    | zero => norm_num
    | succ t ih =>
        rw [pow_succ]
        push_cast
        have hp1 : (1 : ℝ) ≤ (3 / 2 : ℝ) ^ t := one_le_pow₀ (by norm_num)
        linarith
  calc
    ((1 / 2 : ℝ) ^ t) * ((t : ℝ) + 1)
        ≤ ((1 / 2 : ℝ) ^ t) * (2 * ((3 / 2 : ℝ) ^ t)) :=
          mul_le_mul_of_nonneg_left h32 (by positivity)
    _ = 2 * (((1 / 2 : ℝ) * (3 / 2 : ℝ)) ^ t) := by rw [mul_pow]; ring
    _ = 2 * ((3 / 4 : ℝ) ^ t) := by norm_num

private theorem tsum_half_pow_mul_succ_le :
    (∑' t : ℕ, ((1 / 2 : ℝ) ^ t) * ((t : ℝ) + 1)) ≤ 4 := by
  let f : ℕ → ℝ := fun t => ((1 / 2 : ℝ) ^ t) * ((t : ℝ) + 1)
  have hf_sum : Summable f := summable_half_pow_mul_succ
  have hshift := Summable.tsum_eq_zero_add hf_sum
  have hgeom : (∑' t : ℕ, (1 / 2 : ℝ) ^ t) = 2 := by
    rw [tsum_geometric_of_lt_one (by norm_num) (by norm_num)]
    norm_num
  have hstep : ∀ t : ℕ, f (t + 1) = (1 / 2 : ℝ) * f t + (1 / 2 : ℝ) * ((1 / 2 : ℝ) ^ t) := by
    intro t
    dsimp [f]
    push_cast
    rw [pow_succ]
    ring
  have hsum_succ :
      (∑' t : ℕ, f (t + 1)) =
        (1 / 2 : ℝ) * (∑' t : ℕ, f t) + (1 / 2 : ℝ) * (∑' t : ℕ, (1 / 2 : ℝ) ^ t) := by
    simp_rw [hstep]
    rw [Summable.tsum_add (hf_sum.mul_left _)
      ((summable_geometric_of_lt_one (by norm_num) (by norm_num)).mul_left _),
      tsum_mul_left, tsum_mul_left]
  have hf0 : f 0 = 1 := by simp [f]
  rw [hf0, hsum_succ, hgeom] at hshift
  linarith

/-- Full `haltProb = 1` and expected cost `≤ 4 * bound` theorem for a fixed-`N`-bit geometric retry loop. -/
theorem geom_retry_tsum_bounds {α : Type*} {N : ℕ}
    (runProg : List Bool → Option α)
    (uCost bCost : α → ℕ)
    (acc : (Fin N → Bool) → Bool)
    {U B_c : ℝ} (hU : 0 ≤ U) (hB : 0 ≤ B_c)
    (hprob : 1 / 2 ≤
      ((Finset.univ.filter (fun v : Fin N → Bool => acc v = true)).card : ℝ) / ((2 : ℝ) ^ N))
    (h_forward : ∀ (t : ℕ) (bad : Fin t → {v : Fin N → Bool // acc v = false})
      (good : {v : Fin N → Bool // acc v = true}),
      (runProg (chunkList t bad good)).isSome = true)
    (h_backward : ∀ (bs : List Bool) (out : α),
      runProg bs = some out →
      ∃ (t : ℕ) (bad : Fin t → {v : Fin N → Bool // acc v = false})
        (good : {v : Fin N → Bool // acc v = true}),
        bs = chunkList t bad good ∧
        (uCost out : ℝ) ≤ ((t : ℝ) + 1) * U ∧
        (bCost out : ℝ) ≤ ((t : ℝ) + 1) * B_c) :
    let haltP : ENNReal :=
      ∑' bs : List Bool, if (runProg bs).isSome then bitListProb bs else 0
    let expU : ENNReal :=
      ∑' bs : List Bool,
        match runProg bs with
        | some out => bitListProb bs * (uCost out : ENNReal)
        | none => 0
    let expB : ENNReal :=
      ∑' bs : List Bool,
        match runProg bs with
        | some out => bitListProb bs * (bCost out : ENNReal)
        | none => 0
    haltP = 1 ∧
    expU ≠ ⊤ ∧ expU.toReal ≤ 4 * U ∧
    expB ≠ ⊤ ∧ expB.toReal ≤ 4 * B_c := by
  classical
  dsimp only
  let F := {v : Fin N → Bool // acc v = false}
  let G := {v : Fin N → Bool // acc v = true}
  let Dom := Σ t : ℕ, (Fin t → F) × G
  let HaltSet : Set (List Bool) := {bs : List Bool | (runProg bs).isSome = true}
  have hbij : Function.Bijective (fun x : Dom =>
      (⟨chunkList x.1 x.2.1 x.2.2, h_forward x.1 x.2.1 x.2.2⟩ : HaltSet)) := by
    refine ⟨?_, ?_⟩
    · intro x₁ x₂ h
      exact chunkList_injective (congrArg Subtype.val h)
    · rintro ⟨bs, hbs⟩
      rcases hopt : runProg bs with _ | out
      · simp [HaltSet, hopt] at hbs
      · obtain ⟨t, bad, good, rfl, _, _⟩ := h_backward bs out hopt
        exact ⟨⟨t, bad, good⟩, rfl⟩
  let eDom : Dom ≃ HaltSet := Equiv.ofBijective _ hbij
  let p : ℝ := (Fintype.card G : ℝ) / ((2 : ℝ) ^ N)
  let q : ℝ := (Fintype.card F : ℝ) / ((2 : ℝ) ^ N)
  have hG_card : Fintype.card G = (Finset.univ.filter (fun v : Fin N → Bool => acc v = true)).card :=
    Fintype.card_subtype _
  have hF_card : Fintype.card F = (Finset.univ.filter (fun v : Fin N → Bool => acc v = false)).card :=
    Fintype.card_subtype _
  have hp_ge : 1 / 2 ≤ p := by simpa [p, hG_card] using hprob
  have hpq_sum : p + q = 1 := by
    have hsum : Fintype.card G + Fintype.card F = 2 ^ N := by
      rw [hG_card, hF_card]
      have h := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset (Fin N → Bool)))
        (fun v => acc v = true)
      have hnot : (Finset.univ.filter (fun v : Fin N → Bool => ¬ (acc v = true))) =
          (Finset.univ.filter (fun v : Fin N → Bool => acc v = false)) := by
        ext v; cases acc v <;> simp
      rw [hnot, Finset.card_univ, Fintype.card_pi] at h
      simpa using h
    have hsum_r : (Fintype.card G : ℝ) + (Fintype.card F : ℝ) = (2 : ℝ) ^ N := by
      exact_mod_cast hsum
    dsimp [p, q]
    rw [← add_div, hsum_r, div_self (by positivity)]
  have hp_pos : 0 < p := by linarith
  have hp_le1 : p ≤ 1 := by
    have hq_nn : 0 ≤ q := by positivity
    linarith
  have hq_nn : 0 ≤ q := by positivity
  have hq_le_half : q ≤ 1 / 2 := by linarith
  have hq_lt1 : q < 1 := by linarith
  have hprob_chunk : ∀ (t : ℕ) (bad : Fin t → F) (good : G),
      bitListProb (chunkList t bad good) =
        (((2 : ENNReal)⁻¹) ^ N) ^ (t + 1) := by
    intro t bad good
    unfold bitListProb
    rw [chunkList_length, mul_comm (t + 1) N, pow_mul]
  have h_inv2N : ((2 : ENNReal)⁻¹) ^ N = ENNReal.ofReal ((1 / (2 : ℝ) ^ N)) := by
    rw [one_div, ← inv_pow, ENNReal.ofReal_pow (by positivity),
      ENNReal.ofReal_inv_of_pos (by norm_num), ENNReal.ofReal_ofNat]
  -- Helper reindexing any `g : List Bool → ENNReal` supported on `HaltSet` over `Dom`
  have h_reindex : ∀ g : List Bool → ENNReal,
      (∀ bs : List Bool, (runProg bs).isSome = false → g bs = 0) →
      (∑' bs : List Bool, g bs) =
        ∑' t : ℕ, ∑ bg : (Fin t → F) × G, g (chunkList t bg.1 bg.2) := by
    intro g hg0
    have h1 : (∑' bs : List Bool, g bs) = ∑' s : HaltSet, g s.1 := by
      symm
      refine tsum_subtype_eq_of_support_subset ?_
      intro bs hbs
      simp only [Function.mem_support, ne_eq] at hbs
      by_contra hnot
      simp only [HaltSet, Set.mem_setOf_eq, Bool.not_eq_true] at hnot
      exact hbs (hg0 bs hnot)
    rw [h1, ← eDom.tsum_eq]
    dsimp only [Dom]
    rw [ENNReal.tsum_sigma']
    congr 1
    funext t
    rw [tsum_fintype]
    rfl
  -- (1) haltProb = 1
  have h_halt :
      (∑' bs : List Bool, if (runProg bs).isSome then bitListProb bs else 0) = 1 := by
    rw [h_reindex _ (fun bs h => by simp [h])]
    have h_term : ∀ t : ℕ,
        (∑ bg : (Fin t → F) × G,
          if (runProg (chunkList t bg.1 bg.2)).isSome then
            bitListProb (chunkList t bg.1 bg.2) else 0) =
          ENNReal.ofReal ((q ^ t) * p) := by
      intro t
      have hite : ∀ bg : (Fin t → F) × G,
          (if (runProg (chunkList t bg.1 bg.2)).isSome then
            bitListProb (chunkList t bg.1 bg.2) else 0) =
            (((2 : ENNReal)⁻¹) ^ N) ^ (t + 1) := by
        intro bg
        rw [if_pos (h_forward t bg.1 bg.2), hprob_chunk]
      simp_rw [hite]
      rw [Finset.sum_const, Finset.card_univ, Fintype.card_prod, Fintype.card_pi]
      simp only [Finset.prod_const, Finset.card_univ, Fintype.card_fin]
      rw [h_inv2N, ← ENNReal.ofReal_pow (by positivity), nsmul_eq_mul,
        ← ENNReal.ofReal_natCast, ← ENNReal.ofReal_mul (by positivity)]
      congr 1
      push_cast
      dsimp [q, p]
      simp only [one_div, div_eq_mul_inv, pow_succ, mul_pow]
      ring
    simp_rw [h_term]
    have hsum_qp : Summable (fun t : ℕ => (q ^ t) * p) :=
      (summable_geometric_of_lt_one hq_nn hq_lt1).mul_right p
    rw [← ENNReal.ofReal_tsum_of_nonneg (fun t => by positivity) hsum_qp,
      tsum_mul_right, tsum_geometric_of_lt_one hq_nn hq_lt1]
    have h1q : 1 - q = p := by linarith
    rw [h1q, inv_mul_cancel₀ hp_pos.ne', ENNReal.ofReal_one]
  -- (2) Expected cost helper for any `cFn : α → ℕ` bounded by `(t + 1) * C_b`
  have h_exp : ∀ (cFn : α → ℕ) (C_b : ℝ), 0 ≤ C_b →
      (∀ (t : ℕ) (bad : Fin t → F) (good : G) (out : α),
        runProg (chunkList t bad good) = some out → (cFn out : ℝ) ≤ ((t : ℝ) + 1) * C_b) →
      let E : ENNReal := ∑' bs : List Bool,
        match runProg bs with
        | some out => bitListProb bs * (cFn out : ENNReal)
        | none => 0
      E ≠ ⊤ ∧ E.toReal ≤ 4 * C_b := by
    intro cFn C_b hCb hbound E
    have hE_eq : E = ∑' t : ℕ, ∑ bg : (Fin t → F) × G,
        match runProg (chunkList t bg.1 bg.2) with
        | some out => bitListProb (chunkList t bg.1 bg.2) * (cFn out : ENNReal)
        | none => 0 := by
      refine h_reindex _ (fun bs h => ?_)
      cases hopt : runProg bs <;> simp [hopt] at h ⊢
    have h_term_le : ∀ t : ℕ,
        (∑ bg : (Fin t → F) × G,
          match runProg (chunkList t bg.1 bg.2) with
          | some out => bitListProb (chunkList t bg.1 bg.2) * (cFn out : ENNReal)
          | none => 0) ≤
        ENNReal.ofReal (((1 / 2 : ℝ) ^ t) * ((t : ℝ) + 1) * C_b) := by
      intro t
      have h_each : ∀ bg : (Fin t → F) × G,
          (match runProg (chunkList t bg.1 bg.2) with
          | some out => bitListProb (chunkList t bg.1 bg.2) * (cFn out : ENNReal)
          | none => 0) ≤
          (((2 : ENNReal)⁻¹) ^ N) ^ (t + 1) * ENNReal.ofReal (((t : ℝ) + 1) * C_b) := by
        intro bg
        rcases hopt : runProg (chunkList t bg.1 bg.2) with _ | out
        · simp
        · dsimp only
          rw [hprob_chunk]
          gcongr
          have hle := hbound t bg.1 bg.2 out hopt
          calc
            (cFn out : ENNReal) = ENNReal.ofReal (cFn out : ℝ) :=
              (ENNReal.ofReal_natCast (cFn out)).symm
            _ ≤ ENNReal.ofReal (((t : ℝ) + 1) * C_b) := ENNReal.ofReal_le_ofReal hle
      calc
        (∑ bg : (Fin t → F) × G, _)
            ≤ ∑ _bg : (Fin t → F) × G,
                ((((2 : ENNReal)⁻¹) ^ N) ^ (t + 1) * ENNReal.ofReal (((t : ℝ) + 1) * C_b)) :=
              Finset.sum_le_sum fun bg _ => h_each bg
        _ = ENNReal.ofReal ((q ^ t) * p * (((t : ℝ) + 1) * C_b)) := by
              rw [Finset.sum_const, Finset.card_univ, Fintype.card_prod, Fintype.card_pi]
              simp only [Finset.prod_const, Finset.card_univ, Fintype.card_fin]
              rw [h_inv2N, ← ENNReal.ofReal_pow (by positivity), nsmul_eq_mul,
                ← ENNReal.ofReal_natCast, ← ENNReal.ofReal_mul (by positivity),
                ← ENNReal.ofReal_mul (by positivity)]
              congr 1
              push_cast
              dsimp [q, p]
              simp only [one_div, div_eq_mul_inv, pow_succ, mul_pow]
              ring
        _ ≤ ENNReal.ofReal (((1 / 2 : ℝ) ^ t) * ((t : ℝ) + 1) * C_b) := by
              apply ENNReal.ofReal_le_ofReal
              have hqt : q ^ t ≤ (1 / 2 : ℝ) ^ t := pow_le_pow_left₀ hq_nn hq_le_half t
              have hqp : (q ^ t) * p ≤ ((1 / 2 : ℝ) ^ t) * 1 :=
                mul_le_mul hqt hp_le1 (by positivity) (by positivity)
              have hmul := mul_le_mul_of_nonneg_right hqp (show 0 ≤ ((t : ℝ) + 1) * C_b by positivity)
              linarith
    have hE_le : E ≤ ENNReal.ofReal (4 * C_b) := by
      rw [hE_eq]
      calc
        (∑' t : ℕ, _) ≤ ∑' t : ℕ, ENNReal.ofReal (((1 / 2 : ℝ) ^ t) * ((t : ℝ) + 1) * C_b) :=
          ENNReal.tsum_le_tsum h_term_le
        _ = ENNReal.ofReal (∑' t : ℕ, (((1 / 2 : ℝ) ^ t) * ((t : ℝ) + 1) * C_b)) :=
          (ENNReal.ofReal_tsum_of_nonneg (fun t => by positivity)
            (summable_half_pow_mul_succ.mul_right C_b)).symm
        _ = ENNReal.ofReal ((∑' t : ℕ, ((1 / 2 : ℝ) ^ t) * ((t : ℝ) + 1)) * C_b) := by
          rw [tsum_mul_right]
        _ ≤ ENNReal.ofReal (4 * C_b) :=
          ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_right tsum_half_pow_mul_succ_le hCb)
    have hne_top : E ≠ ⊤ := ne_top_of_le_ne_top ENNReal.ofReal_ne_top hE_le
    refine ⟨hne_top, ?_⟩
    exact (ENNReal.toReal_le_of_le_ofReal (by positivity) hE_le)
  have hU_res := h_exp uCost U hU (fun t bad good out hopt => by
    obtain ⟨t', bad', good', heq, hu, _⟩ := h_backward _ out hopt
    have hinj := @chunkList_injective N acc ⟨t, (bad, good)⟩ ⟨t', (bad', good')⟩ heq
    injection hinj with ht_eq _
    subst ht_eq
    exact hu)
  have hB_res := h_exp bCost B_c hB (fun t bad good out hopt => by
    obtain ⟨t', bad', good', heq, _, hb⟩ := h_backward _ out hopt
    have hinj := @chunkList_injective N acc ⟨t, (bad, good)⟩ ⟨t', (bad', good')⟩ heq
    injection hinj with ht_eq _
    subst ht_eq
    exact hb)
  exact ⟨h_halt, hU_res.1, hU_res.2, hB_res.1, hB_res.2⟩

end UL.Proof_lem_A_2
