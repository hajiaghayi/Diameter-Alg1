import Mathlib
import UL.Proof.lem_A_2.H1a_Math
import UL.Proof.lem_A_2.H1c_Retry
set_option autoImplicit false
set_option maxHeartbeats 1200000

namespace UL.Proof_lem_A_2

/-! ### 1. Core sample size `s₁Val` and `64 * s₁^2 ≤ s₀` parameter relation -/

/-- Polynomial core sample size `s₁(d) = 72 K₀^3 (d + 2)^{2 deg_α + 1}`. -/
def s₁Val (K₀ deg_α d : ℕ) : ℕ :=
  72 * K₀ ^ 3 * (d + 2) ^ (2 * deg_α + 1)

theorem s₁Val_ge_144 {K₀ deg_α : ℕ} (hK : 1 ≤ K₀) (d : ℕ) :
    144 ≤ s₁Val K₀ deg_α d := by
  unfold s₁Val
  have hK3 : 1 ≤ K₀ ^ 3 := Nat.one_le_pow 3 K₀ hK
  have hd_pow : 2 ≤ (d + 2) ^ (2 * deg_α + 1) := by
    calc 2 = 2 ^ 1 := rfl
      _ ≤ (d + 2) ^ 1 := Nat.pow_le_pow_left (by omega) 1
      _ ≤ (d + 2) ^ (2 * deg_α + 1) := Nat.pow_le_pow_right (by omega) (by omega)
  have h1 : 72 * 1 ≤ 72 * K₀ ^ 3 := Nat.mul_le_mul_left 72 hK3
  calc 144 = 72 * 1 * 2 := rfl
    _ ≤ (72 * K₀ ^ 3) * (d + 2) ^ (2 * deg_α + 1) := Nat.mul_le_mul h1 hd_pow

theorem sixtyFour_s₁Val_sq_le_s₀Val {K₀ deg_α : ℕ} (_hK : 1 ≤ K₀) (d : ℕ) :
    64 * (s₁Val K₀ deg_α d) ^ 2 ≤ s₀Val (25 * K₀ ^ 2) (2 * deg_α + 1) d := by
  unfold s₁Val s₀Val
  set X : ℕ := d + 2
  have hX1 : 1 ≤ X := by dsimp [X]; omega
  have hexp : 2 * (2 * deg_α + 1) ≤ 2 * (2 * deg_α + 1) + 1 := by omega
  have hpow : X ^ (2 * (2 * deg_α + 1)) ≤ X ^ (2 * (2 * deg_α + 1) + 1) :=
    Nat.pow_le_pow_right hX1 hexp
  have hcoef : 64 * (72 ^ 2 * K₀ ^ 6) ≤ 22 * (25 * K₀ ^ 2) ^ 3 := by
    have h1 : 64 * (72 ^ 2 * K₀ ^ 6) = 331776 * K₀ ^ 6 := by ring
    have h2 : 22 * (25 * K₀ ^ 2) ^ 3 = 343750 * K₀ ^ 6 := by ring
    rw [h1, h2]
    exact Nat.mul_le_mul_right (K₀ ^ 6) (by decide)
  calc 64 * (72 * K₀ ^ 3 * X ^ (2 * deg_α + 1)) ^ 2
      = (64 * (72 ^ 2 * K₀ ^ 6)) * (X ^ (2 * (2 * deg_α + 1))) := by
        rw [mul_pow, mul_pow, ← pow_mul, ← pow_mul]
        ring
    _ ≤ (22 * (25 * K₀ ^ 2) ^ 3) * X ^ (2 * (2 * deg_α + 1) + 1) :=
        Nat.mul_le_mul hcoef hpow

theorem hw87_half_depth_le_s₁Val {K₀ deg_α d : ℕ} (hK : 1 ≤ K₀)
    {C_HW α₀ : ℝ} (_hCHW0 : 0 < C_HW) (hCHW : C_HW ≤ (K₀ : ℝ))
    (hα0 : 0 < α₀) (_hα1 : α₀ ≤ 1)
    (hα_inv : α₀⁻¹ ≤ (K₀ : ℝ) * ((d + 2 : ℝ) ^ deg_α)) :
    Nat.ceil (C_HW * (α₀ / 2)⁻¹ * (((d + 1 : ℝ) + 1) * Real.log (2 / (α₀ / 2)) +
      Real.log (2 / (1 / 16 : ℝ)))) ≤ s₁Val K₀ deg_α d := by
  refine Nat.ceil_le.mpr ?_
  have hK1 : (1 : ℝ) ≤ (K₀ : ℝ) := by exact_mod_cast hK
  have hd2_ge1 : (1 : ℝ) ≤ (d + 2 : ℝ) := by linarith
  have hα_half_pos : 0 < α₀ / 2 := by linarith
  have h_inv_half : (α₀ / 2)⁻¹ = 2 * α₀⁻¹ := by field_simp
  have h_two_div : 2 / (α₀ / 2) = 4 * α₀⁻¹ := by field_simp; ring
  have h_log_alpha : Real.log (2 / (α₀ / 2)) ≤ 4 * α₀⁻¹ := by
    have hpos : 0 < 2 / (α₀ / 2) := div_pos (by norm_num) hα_half_pos
    calc Real.log (2 / (α₀ / 2)) ≤ 2 / (α₀ / 2) - 1 := Real.log_le_sub_one_of_pos hpos
      _ ≤ 2 / (α₀ / 2) := by linarith
      _ = 4 * α₀⁻¹ := h_two_div
  have h_log_delta : Real.log (2 / (1 / 16 : ℝ)) ≤ 32 := by
    have heq : (2 : ℝ) / (1 / 16 : ℝ) = 32 := by norm_num
    rw [heq]
    linarith [Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 32)]
  have h_d1 : ((d + 1 : ℝ) + 1) = (d + 2 : ℝ) := by push_cast; ring
  rw [h_d1]
  have h_inner_1 :
      (d + 2 : ℝ) * Real.log (2 / (α₀ / 2)) ≤
        4 * (K₀ : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1) := by
    calc (d + 2 : ℝ) * Real.log (2 / (α₀ / 2))
        ≤ (d + 2 : ℝ) * (4 * α₀⁻¹) := mul_le_mul_of_nonneg_left h_log_alpha (by positivity)
      _ ≤ (d + 2 : ℝ) * (4 * ((K₀ : ℝ) * (d + 2 : ℝ) ^ deg_α)) := by gcongr
      _ = 4 * (K₀ : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1) := by rw [pow_succ]; ring
  have h_32 : (32 : ℝ) ≤ 32 * (K₀ : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1) := by
    have hpow1 : (1 : ℝ) ≤ (d + 2 : ℝ) ^ (deg_α + 1) := one_le_pow₀ hd2_ge1
    have hk_pow : (1 : ℝ) ≤ (K₀ : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1) :=
      one_le_mul_of_one_le_of_one_le hK1 hpow1
    linarith
  have h_inner :
      (d + 2 : ℝ) * Real.log (2 / (α₀ / 2)) + Real.log (2 / (1 / 16 : ℝ)) ≤
        36 * (K₀ : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1) := by linarith
  have h_inner_nn :
      0 ≤ (d + 2 : ℝ) * Real.log (2 / (α₀ / 2)) + Real.log (2 / (1 / 16 : ℝ)) := by
    have h2a : 1 ≤ 2 / (α₀ / 2) := by rw [le_div_iff₀ hα_half_pos]; linarith
    have h1 : 0 ≤ Real.log (2 / (α₀ / 2)) := Real.log_nonneg h2a
    have h2 : 0 ≤ Real.log (2 / (1 / 16 : ℝ)) := by
      have heq : (2 : ℝ) / (1 / 16 : ℝ) = 32 := by norm_num
      rw [heq]; exact Real.log_nonneg (by norm_num)
    positivity
  have h_prod1 : C_HW * (α₀ / 2)⁻¹ ≤ 2 * (K₀ : ℝ) ^ 2 * (d + 2 : ℝ) ^ deg_α := by
    rw [h_inv_half]
    calc C_HW * (2 * α₀⁻¹)
        ≤ (K₀ : ℝ) * (2 * ((K₀ : ℝ) * (d + 2 : ℝ) ^ deg_α)) :=
          mul_le_mul hCHW (by linarith) (by positivity) (by positivity)
      _ = 2 * (K₀ : ℝ) ^ 2 * (d + 2 : ℝ) ^ deg_α := by ring
  calc C_HW * (α₀ / 2)⁻¹ * ((d + 2 : ℝ) * Real.log (2 / (α₀ / 2)) + Real.log (2 / (1 / 16 : ℝ)))
      ≤ (2 * (K₀ : ℝ) ^ 2 * (d + 2 : ℝ) ^ deg_α) *
          (36 * (K₀ : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1)) :=
        mul_le_mul h_prod1 h_inner h_inner_nn (by positivity)
    _ = ((s₁Val K₀ deg_α d : ℕ) : ℝ) := by
        unfold s₁Val
        push_cast
        rw [show 2 * deg_α + 1 = deg_α + (deg_α + 1) by omega, pow_add]
        ring

/-! ### 2. Deterministic square-root, Bertrand prime, and QNR specifications -/

def sqrtIter (m : ℕ) : ℕ → ℕ
  | 0 => 0
  | k + 1 =>
      let s := sqrtIter m k
      if (s + 1) * (s + 1) ≤ m then s + 1 else s

theorem sqrtIter_eq_min (m : ℕ) : ∀ k : ℕ, sqrtIter m k = min k (Nat.sqrt m)
  | 0 => by simp [sqrtIter]
  | k + 1 => by
      simp only [sqrtIter, sqrtIter_eq_min m k]
      by_cases hk : k < Nat.sqrt m
      · have hmin : min k (Nat.sqrt m) = k := Nat.min_eq_left (le_of_lt hk)
        rw [hmin]
        have hsq : (k + 1) * (k + 1) ≤ m := Nat.le_sqrt.mp hk
        rw [if_pos hsq]
        exact (Nat.min_eq_left hk).symm
      · have hk_ge : Nat.sqrt m ≤ k := Nat.le_of_not_lt hk
        have hmin : min k (Nat.sqrt m) = Nat.sqrt m := Nat.min_eq_right hk_ge
        rw [hmin]
        have hgt : m < (Nat.sqrt m + 1) * (Nat.sqrt m + 1) := Nat.lt_succ_sqrt m
        rw [if_neg (not_le_of_gt hgt)]
        exact (Nat.min_eq_right (by omega)).symm

theorem sqrtIter_self (m : ℕ) : sqrtIter m m = Nat.sqrt m := by
  rw [sqrtIter_eq_min, Nat.min_eq_right (Nat.sqrt_le_self m)]

def qOfM (m : ℕ) : ℕ := Nat.sqrt m + 3

theorem qOfM_bounds {m : ℕ} (hm : 512 ≤ m) :
    25 ≤ qOfM m ∧ m < (qOfM m) ^ 2 ∧ 2 * qOfM m < m ∧ (qOfM m) ^ 2 ≤ 2 * m := by
  unfold qOfM
  set s := Nat.sqrt m
  have hs22 : 22 ≤ s := Nat.le_sqrt.mpr (by omega)
  have hss : s * s ≤ m := Nat.sqrt_le m
  have hlt : m < (s + 1) * (s + 1) := Nat.lt_succ_sqrt m
  refine ⟨by omega, ?_, ?_, ?_⟩
  · nlinarith
  · nlinarith
  · nlinarith

def primeTrialIter (n : ℕ) : ℕ → ℕ
  | 0 => 1
  | j + 1 => if n % (j + 2) = 0 then 0 else primeTrialIter n j

theorem primeTrialIter_spec (n : ℕ) :
    ∀ j : ℕ,
      (primeTrialIter n j = 0 ∨ primeTrialIter n j = 1) ∧
      (primeTrialIter n j = 1 ↔ ∀ d : ℕ, 2 ≤ d → d < j + 2 → n % d ≠ 0)
  | 0 => ⟨Or.inr rfl, ⟨fun _ d hd1 hd2 => by omega, fun _ => rfl⟩⟩
  | j + 1 => by
      obtain ⟨h01, hiff⟩ := primeTrialIter_spec n j
      simp only [primeTrialIter]
      by_cases hmod : n % (j + 2) = 0
      · rw [if_pos hmod]
        refine ⟨Or.inl rfl, ⟨fun h => by omega, fun hall => False.elim (hall (j + 2) (by omega) (by omega) hmod)⟩⟩
      · rw [if_neg hmod]
        refine ⟨h01, ⟨fun h1 d hd2 hdlt => ?_, fun hall => hiff.mpr fun d hd2 hdlt => hall d hd2 (by omega)⟩⟩
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hdlt) with hlt' | rfl
        · exact hiff.mp h1 d hd2 hlt'
        · exact hmod

theorem primeTrialIter_prime_iff {n : ℕ} (hn : 2 ≤ n) :
    primeTrialIter n (n - 2) = 1 ↔ Nat.Prime n := by
  have hspec := (primeTrialIter_spec n (n - 2)).2
  have hadd : n - 2 + 2 = n := by omega
  rw [hadd] at hspec
  rw [hspec]
  constructor
  · intro hall
    by_contra hnp
    have hm_pr : Nat.Prime n.minFac := Nat.minFac_prime (by omega)
    have hm_ge2 : 2 ≤ n.minFac := hm_pr.two_le
    have hm_le : n.minFac ≤ n := Nat.minFac_le (by omega)
    have hm_ne : n.minFac ≠ n := fun heq => hnp (heq ▸ hm_pr)
    have hm_dvd : n.minFac ∣ n := Nat.minFac_dvd n
    exact hall n.minFac hm_ge2 (lt_of_le_of_ne hm_le hm_ne) (Nat.mod_eq_zero_of_dvd hm_dvd)
  · intro hp d hd2 hdlt hmod
    have hdvd : d ∣ n := Nat.dvd_of_mod_eq_zero hmod
    rcases hp.eq_one_or_self_of_dvd d hdvd with rfl | rfl <;> omega

def firstPrimeIter (q : ℕ) : ℕ → ℕ
  | 0 => 0
  | i + 1 =>
      let cur := firstPrimeIter q i
      let n := q + 1 + i
      if cur = 0 ∧ primeTrialIter n (n - 2) = 1 then n else cur

def firstPrimeIn (q : ℕ) : ℕ := firstPrimeIter q q

theorem firstPrimeIter_inv {q : ℕ} (hq : 1 ≤ q) :
    ∀ k : ℕ, k ≤ q →
      (firstPrimeIter q k = 0 ∧ ∀ i < k, ¬ Nat.Prime (q + 1 + i)) ∨
      (Nat.Prime (firstPrimeIter q k) ∧ q + 1 ≤ firstPrimeIter q k ∧ firstPrimeIter q k ≤ q + k)
  | 0, _ => Or.inl ⟨rfl, fun _ h => by omega⟩
  | k + 1, hk => by
      rcases firstPrimeIter_inv hq k (le_of_lt hk) with ⟨h0, hnone⟩ | ⟨hpr, hlo, hhi⟩
      · simp only [firstPrimeIter, h0, true_and]
        have hn2 : 2 ≤ q + 1 + k := by omega
        by_cases ht : primeTrialIter (q + 1 + k) (q + 1 + k - 2) = 1
        · rw [if_pos ht]
          exact Or.inr ⟨(primeTrialIter_prime_iff hn2).mp ht, by omega, by omega⟩
        · rw [if_neg ht]
          refine Or.inl ⟨rfl, fun i hi => ?_⟩
          rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hi) with hlt | rfl
          · exact hnone i hlt
          · exact fun hp => ht ((primeTrialIter_prime_iff hn2).mpr hp)
      · simp only [firstPrimeIter]
        have hne : firstPrimeIter q k ≠ 0 := by omega
        rw [if_neg (fun h => hne h.1)]
        exact Or.inr ⟨hpr, hlo, by omega⟩

theorem firstPrimeIn_spec {q : ℕ} (hq : 25 ≤ q) :
    Nat.Prime (firstPrimeIn q) ∧ q < firstPrimeIn q ∧ firstPrimeIn q ≤ 2 * q ∧ 26 ≤ firstPrimeIn q := by
  rcases firstPrimeIter_inv (by omega : 1 ≤ q) q le_rfl with ⟨h0, hnone⟩ | ⟨hpr, hlo, hhi⟩
  · obtain ⟨p, hp_pr, hqp, hp2q⟩ := Nat.exists_prime_lt_and_le_two_mul q (by omega)
    let idx := p - (q + 1)
    have hi_lt : idx < q := by dsimp [idx]; omega
    have heq : q + 1 + idx = p := by dsimp [idx]; omega
    have hp_idx : Nat.Prime (q + 1 + idx) := by rwa [heq]
    exact False.elim (hnone idx hi_lt hp_idx)
  · exact ⟨hpr, by change q < firstPrimeIter q q; omega,
      by change firstPrimeIter q q ≤ 2 * q; omega,
      by change 26 ≤ firstPrimeIter q q; omega⟩

def qnrTrialIter (p cand : ℕ) : ℕ → ℕ
  | 0 => 1
  | x + 1 => if (x * x) % p = cand then 0 else qnrTrialIter p cand x

theorem qnrTrialIter_spec (p cand : ℕ) :
    ∀ k : ℕ,
      (qnrTrialIter p cand k = 0 ∨ qnrTrialIter p cand k = 1) ∧
      (qnrTrialIter p cand k = 1 ↔ ∀ x < k, (x * x) % p ≠ cand)
  | 0 => ⟨Or.inr rfl, ⟨fun _ _ h => by omega, fun _ => rfl⟩⟩
  | k + 1 => by
      obtain ⟨h01, hiff⟩ := qnrTrialIter_spec p cand k
      simp only [qnrTrialIter]
      by_cases hmod : (k * k) % p = cand
      · rw [if_pos hmod]
        exact ⟨Or.inl rfl, ⟨fun h => by omega, fun hall => False.elim (hall k (Nat.lt_succ_self k) hmod)⟩⟩
      · rw [if_neg hmod]
        refine ⟨h01, ⟨fun h1 x hx => ?_, fun hall => hiff.mpr fun x hx => hall x (by omega)⟩⟩
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hx) with hlt | rfl
        · exact hiff.mp h1 x hlt
        · exact hmod

def firstQnrIter (p : ℕ) : ℕ → ℕ
  | 0 => 0
  | i + 1 =>
      let cur := firstQnrIter p i
      let cand := i + 1
      if cur = 0 ∧ qnrTrialIter p cand p = 1 then cand else cur

def firstQnr (p : ℕ) : ℕ := firstQnrIter p (p - 1)

theorem firstQnrIter_inv (p : ℕ) :
    ∀ k : ℕ,
      (firstQnrIter p k = 0 ∧ ∀ i < k, qnrTrialIter p (i + 1) p ≠ 1) ∨
      (1 ≤ firstQnrIter p k ∧ firstQnrIter p k ≤ k ∧ qnrTrialIter p (firstQnrIter p k) p = 1)
  | 0 => Or.inl ⟨rfl, fun _ h => by omega⟩
  | k + 1 => by
      rcases firstQnrIter_inv p k with ⟨h0, hnone⟩ | ⟨hlo, hhi, hok⟩
      · simp only [firstQnrIter, h0, true_and]
        by_cases ht : qnrTrialIter p (k + 1) p = 1
        · rw [if_pos ht]; exact Or.inr ⟨by omega, le_rfl, ht⟩
        · rw [if_neg ht]
          refine Or.inl ⟨rfl, fun i hi => ?_⟩
          rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hi) with hlt | rfl
          · exact hnone i hlt
          · exact ht
      · simp only [firstQnrIter]
        have hne : firstQnrIter p k ≠ 0 := by omega
        rw [if_neg (fun h => hne h.1)]
        exact Or.inr ⟨hlo, by omega, hok⟩

theorem exists_qnr_nat {p : ℕ} (hp : Nat.Prime p) (hp26 : 26 ≤ p) :
    ∃ a : ℕ, 1 ≤ a ∧ a < p ∧ ∀ x < p, (x * x) % p ≠ a := by
  haveI : Fact p.Prime := ⟨hp⟩
  let sqMap : ZMod p → ZMod p := fun x => x * x
  have h_not_inj : ¬ Function.Injective sqMap := by
    intro hinj
    have h1 : sqMap 1 = sqMap (-1) := by dsimp [sqMap]; ring
    have heq : (1 : ZMod p) = -1 := hinj h1
    have h20 : ((2 : ℕ) : ZMod p) = 0 := by
      have : (1 : ZMod p) + 1 = 0 := by linear_combination heq
      simpa [one_add_one_eq_two] using this
    have hdvd : p ∣ 2 := (ZMod.natCast_eq_zero_iff 2 p).mp h20
    have hle2 : p ≤ 2 := Nat.le_of_dvd (by decide) hdvd
    omega
  have h_not_surj : ¬ Function.Surjective sqMap :=
    fun hsurj => h_not_inj (Finite.injective_iff_surjective.mpr hsurj)
  have hex_y : ∃ y : ZMod p, ∀ x : ZMod p, sqMap x ≠ y := by
    by_contra hall
    push_neg at hall
    exact h_not_surj hall
  obtain ⟨y, hy⟩ := hex_y
  have hy0 : y ≠ 0 := fun h0 => hy 0 (by simp [sqMap, h0])
  have hval_pos : 1 ≤ y.val := by
    by_contra h0
    have hv0 : y.val = 0 := by omega
    exact hy0 ((ZMod.val_eq_zero y).mp hv0)
  refine ⟨y.val, hval_pos, y.val_lt, fun x hx hmod => ?_⟩
  have hcast : ((x : ZMod p) * (x : ZMod p)) = y := by
    calc (x : ZMod p) * (x : ZMod p) = ((x * x : ℕ) : ZMod p) := by push_cast; rfl
      _ = (((x * x) % p : ℕ) : ZMod p) := (ZMod.natCast_mod (x * x) p).symm
      _ = (y.val : ZMod p) := by rw [hmod]
      _ = y := ZMod.natCast_zmod_val y
  exact hy (x : ZMod p) hcast

theorem firstQnr_spec {p : ℕ} (hp : Nat.Prime p) (hp26 : 26 ≤ p) :
    1 ≤ firstQnr p ∧ firstQnr p < p ∧
    (∀ x < p, (x * x) % p ≠ firstQnr p) ∧
    (∀ z : ZMod p, z * z ≠ (firstQnr p : ZMod p)) := by
  haveI : Fact p.Prime := ⟨hp⟩
  rcases firstQnrIter_inv p (p - 1) with ⟨h0, hnone⟩ | ⟨hlo, hhi, hok⟩
  · obtain ⟨a, ha1, hap, hall⟩ := exists_qnr_nat hp hp26
    have hi_lt : a - 1 < p - 1 := by omega
    have ha_eq : a - 1 + 1 = a := by omega
    have hqt : qnrTrialIter p a p = 1 := (qnrTrialIter_spec p a p).2.mpr hall
    exact False.elim (hnone (a - 1) hi_lt (ha_eq.symm ▸ hqt))
  · have ha_lt : firstQnr p < p := by change firstQnrIter p (p - 1) < p; omega
    have hall_nat : ∀ x < p, (x * x) % p ≠ firstQnr p :=
      (qnrTrialIter_spec p (firstQnr p) p).2.mp hok
    refine ⟨hlo, ha_lt, hall_nat, fun z hz => ?_⟩
    have hval_lt : z.val < p := z.val_lt
    have hcast : (((z.val * z.val) % p : ℕ) : ZMod p) = (firstQnr p : ZMod p) := by
      rw [ZMod.natCast_mod]
      push_cast
      rw [ZMod.natCast_zmod_val, hz]
    have hmod_lt : (z.val * z.val) % p < p := Nat.mod_lt _ (by omega)
    have h_eq_nat : (z.val * z.val) % p = firstQnr p := by
      have h1 := congrArg ZMod.val hcast
      rwa [ZMod.val_natCast_of_lt hmod_lt, ZMod.val_natCast_of_lt ha_lt] at h1
    exact hall_nat z.val hval_lt h_eq_nat

/-! ### 3. Quadratic extension field `QuadExt p a` and bijection with `Fin (p * p)` -/

@[ext]
structure QuadExt (p a : ℕ) where
  re : ZMod p
  im : ZMod p
  deriving DecidableEq

namespace QuadExt

section RingOps
variable {p a : ℕ}

instance : Zero (QuadExt p a) := ⟨⟨0, 0⟩⟩
instance : One (QuadExt p a) := ⟨⟨1, 0⟩⟩
instance : Add (QuadExt p a) := ⟨fun x y => ⟨x.re + y.re, x.im + y.im⟩⟩
instance : Neg (QuadExt p a) := ⟨fun x => ⟨-x.re, -x.im⟩⟩
instance : Sub (QuadExt p a) := ⟨fun x y => ⟨x.re - y.re, x.im - y.im⟩⟩
instance : Mul (QuadExt p a) :=
  ⟨fun x y => ⟨x.re * y.re + (a : ZMod p) * x.im * y.im, x.re * y.im + x.im * y.re⟩⟩

@[simp] theorem zero_re : (0 : QuadExt p a).re = 0 := rfl
@[simp] theorem zero_im : (0 : QuadExt p a).im = 0 := rfl
@[simp] theorem one_re : (1 : QuadExt p a).re = 1 := rfl
@[simp] theorem one_im : (1 : QuadExt p a).im = 0 := rfl
@[simp] theorem add_re (x y : QuadExt p a) : (x + y).re = x.re + y.re := rfl
@[simp] theorem add_im (x y : QuadExt p a) : (x + y).im = x.im + y.im := rfl
@[simp] theorem neg_re (x : QuadExt p a) : (-x).re = -x.re := rfl
@[simp] theorem neg_im (x : QuadExt p a) : (-x).im = -x.im := rfl
@[simp] theorem sub_re (x y : QuadExt p a) : (x - y).re = x.re - y.re := rfl
@[simp] theorem sub_im (x y : QuadExt p a) : (x - y).im = x.im - y.im := rfl
@[simp] theorem mul_re (x y : QuadExt p a) :
    (x * y).re = x.re * y.re + (a : ZMod p) * x.im * y.im := rfl
@[simp] theorem mul_im (x y : QuadExt p a) :
    (x * y).im = x.re * y.im + x.im * y.re := rfl

instance : CommRing (QuadExt p a) where
  add_assoc _ _ _ := by ext <;> simp <;> ring
  zero_add _ := by ext <;> simp
  add_zero _ := by ext <;> simp
  nsmul := nsmulRec
  add_comm _ _ := by ext <;> simp <;> ring
  left_distrib _ _ _ := by ext <;> simp <;> ring
  right_distrib _ _ _ := by ext <;> simp <;> ring
  zero_mul _ := by ext <;> simp
  mul_zero _ := by ext <;> simp
  mul_assoc _ _ _ := by ext <;> simp <;> ring
  one_mul _ := by ext <;> simp
  mul_one _ := by ext <;> simp
  npow := npowRec
  sub_eq_add_neg _ _ := by ext <;> simp [sub_eq_add_neg]
  zsmul := zsmulRec
  neg_add_cancel _ := by ext <;> simp
  mul_comm _ _ := by ext <;> simp <;> ring

end RingOps

def equivProd (p a : ℕ) : QuadExt p a ≃ ZMod p × ZMod p where
  toFun z := (z.re, z.im)
  invFun xy := ⟨xy.1, xy.2⟩
  left_inv _ := rfl
  right_inv _ := rfl

instance instFintype (p a : ℕ) [NeZero p] : Fintype (QuadExt p a) :=
  Fintype.ofEquiv (ZMod p × ZMod p) (equivProd p a).symm

theorem card_eq (p a : ℕ) [NeZero p] : Fintype.card (QuadExt p a) = p * p := by
  rw [Fintype.card_congr (equivProd p a), Fintype.card_prod, ZMod.card]

def normVal {p a : ℕ} (z : QuadExt p a) : ZMod p :=
  z.re * z.re - (a : ZMod p) * z.im * z.im

theorem normVal_ne_zero {p a : ℕ} [Fact p.Prime]
    (hqnr : ∀ x : ZMod p, x * x ≠ (a : ZMod p))
    {z : QuadExt p a} (hz : z ≠ 0) : normVal z ≠ 0 := by
  intro hn0
  have heq : z.re * z.re = (a : ZMod p) * z.im * z.im := sub_eq_zero.mp hn0
  by_cases him : z.im = 0
  · rw [him, mul_zero] at heq
    have hre : z.re = 0 := mul_self_eq_zero.mp heq
    exact hz (QuadExt.ext hre him)
  · have hsq : (z.re * z.im⁻¹) * (z.re * z.im⁻¹) = (a : ZMod p) := by
      calc (z.re * z.im⁻¹) * (z.re * z.im⁻¹)
          = (z.re * z.re) * (z.im⁻¹ * z.im⁻¹) := by ring
        _ = ((a : ZMod p) * z.im * z.im) * (z.im⁻¹ * z.im⁻¹) := by rw [heq]
        _ = (a : ZMod p) * (z.im * z.im⁻¹) * (z.im * z.im⁻¹) := by ring
        _ = (a : ZMod p) * 1 * 1 := by rw [mul_inv_cancel₀ him]
        _ = (a : ZMod p) := by ring
    exact hqnr (z.re * z.im⁻¹) hsq

noncomputable def mkField {p a : ℕ} [Fact p.Prime]
    (hqnr : ∀ x : ZMod p, x * x ≠ (a : ZMod p)) : Field (QuadExt p a) :=
  letI : Nontrivial (QuadExt p a) :=
    ⟨⟨0, 1, fun h => zero_ne_one (congrArg QuadExt.re h)⟩⟩
  Field.ofIsUnitOrEqZero (fun z : QuadExt p a => by
    by_cases hz : z = 0
    · exact Or.inr hz
    · left
      have hd : normVal z ≠ 0 := normVal_ne_zero hqnr hz
      let w : QuadExt p a := ⟨z.re * (normVal z)⁻¹, -(z.im * (normVal z)⁻¹)⟩
      refine isUnit_iff_exists_inv.mpr ⟨w, ?_⟩
      ext
      · dsimp [w, normVal]
        calc z.re * (z.re * (z.re * z.re - (a : ZMod p) * z.im * z.im)⁻¹) +
              (a : ZMod p) * z.im * -(z.im * (z.re * z.re - (a : ZMod p) * z.im * z.im)⁻¹)
            = normVal z * (normVal z)⁻¹ := by dsimp [normVal]; ring
          _ = 1 := mul_inv_cancel₀ hd
      · dsimp [w]; ring)

def encodeFin {p a : ℕ} [NeZero p] (z : QuadExt p a) : Fin (p * p) :=
  ⟨z.re.val + p * z.im.val, by
    have hp : 0 < p := NeZero.pos p
    have hr : z.re.val < p := z.re.val_lt
    have hi : z.im.val + 1 ≤ p := z.im.val_lt
    have hmul : p * (z.im.val + 1) ≤ p * p := Nat.mul_le_mul_left p hi
    nlinarith⟩

def decodeFin (p a : ℕ) (t : Fin (p * p)) : QuadExt p a :=
  ⟨((t.1 % p : ℕ) : ZMod p), ((t.1 / p : ℕ) : ZMod p)⟩

def equivFin (p a : ℕ) [NeZero p] : QuadExt p a ≃ Fin (p * p) where
  toFun := encodeFin
  invFun := decodeFin p a
  left_inv z := by
    have hp : 0 < p := NeZero.pos p
    ext
    · dsimp [encodeFin, decodeFin]
      have hmod : (z.re.val + p * z.im.val) % p = z.re.val := by
        rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt z.re.val_lt]
      rw [hmod, ZMod.natCast_zmod_val]
    · dsimp [encodeFin, decodeFin]
      have hdiv : (z.re.val + p * z.im.val) / p = z.im.val := by
        rw [Nat.add_mul_div_left _ _ hp, Nat.div_eq_of_lt z.re.val_lt, zero_add]
      rw [hdiv, ZMod.natCast_zmod_val]
  right_inv t := by
    have hp : 0 < p := NeZero.pos p
    apply Fin.ext
    dsimp [encodeFin, decodeFin]
    have hmod_lt : t.1 % p < p := Nat.mod_lt _ hp
    have hdiv_lt : t.1 / p < p := Nat.div_lt_of_lt_mul (by linarith [t.2])
    rw [ZMod.val_natCast_of_lt hmod_lt, ZMod.val_natCast_of_lt hdiv_lt]
    exact Nat.mod_add_div t.1 p

theorem mul_add_val_eq {p a : ℕ} [NeZero p] (acc x c : QuadExt p a) :
    (acc * x + c).re.val =
      (acc.re.val * x.re.val + ((a * acc.im.val) % p) * x.im.val + c.re.val) % p ∧
    (acc * x + c).im.val =
      (acc.re.val * x.im.val + acc.im.val * x.re.val + c.im.val) % p := by
  have hp : 0 < p := NeZero.pos p
  constructor
  · have hcast : (((acc.re.val * x.re.val + ((a * acc.im.val) % p) * x.im.val + c.re.val) % p : ℕ) : ZMod p) =
        (acc * x + c).re := by
      rw [ZMod.natCast_mod]
      push_cast
      rw [ZMod.natCast_mod]
      push_cast
      simp only [ZMod.natCast_zmod_val, add_re, mul_re]
    have h1 := congrArg ZMod.val hcast
    rw [ZMod.val_natCast_of_lt (Nat.mod_lt _ hp)] at h1
    exact h1.symm
  · have hcast : (((acc.re.val * x.im.val + acc.im.val * x.re.val + c.im.val) % p : ℕ) : ZMod p) =
        (acc * x + c).im := by
      rw [ZMod.natCast_mod]
      push_cast
      simp only [ZMod.natCast_zmod_val, add_im, mul_im]
    have h1 := congrArg ZMod.val hcast
    rw [ZMod.val_natCast_of_lt (Nat.mod_lt _ hp)] at h1
    exact h1.symm

end QuadExt

/-! ### 4. Horner evaluation and polynomial evaluation bijections over a finite field -/

def evalPoly {K : Type*} [Semiring K] {s₁ : ℕ} (c : Fin s₁ → K) (x : K) : K :=
  ∑ k : Fin s₁, c k * x ^ k.1

def hornerIter {K : Type*} [Semiring K] {s₁ : ℕ} (c : Fin s₁ → K) (x : K) : ℕ → K
  | 0 => 0
  | t + 1 =>
      if ht : t < s₁ then
        hornerIter c x t * x + c ⟨s₁ - 1 - t, by omega⟩
      else
        hornerIter c x t

theorem hornerIter_eq_sum {K : Type*} [CommRing K] {s₁ : ℕ} (c : Fin s₁ → K) (x : K) :
    ∀ (t : ℕ) (ht : t ≤ s₁),
      hornerIter c x t =
        ∑ i : Fin t, c ⟨s₁ - 1 - i.1, by have := i.2; omega⟩ * x ^ (t - 1 - i.1) := by
  intro t
  induction t with
  | zero => intro _; simp [hornerIter]
  | succ t ih =>
      intro ht1
      have ht : t < s₁ := ht1
      simp only [hornerIter, dif_pos ht]
      rw [ih (le_of_lt ht), Fin.sum_univ_castSucc]
      simp only [Fin.val_castSucc, Fin.val_last, Nat.add_sub_cancel, Nat.sub_self, pow_zero, mul_one]
      congr 1
      rw [Finset.sum_mul]
      refine Finset.sum_congr rfl fun i _ => ?_
      have hi_lt : i.1 < t := i.2
      have hexp : t - i.1 = (t - 1 - i.1) + 1 := by omega
      rw [hexp, pow_succ, mul_assoc]

theorem hornerIter_full {K : Type*} [CommRing K] {s₁ : ℕ} (c : Fin s₁ → K) (x : K) :
    hornerIter c x s₁ = evalPoly c x := by
  rw [hornerIter_eq_sum c x s₁ le_rfl]
  unfold evalPoly
  let rev : Fin s₁ ≃ Fin s₁ :=
    { toFun := fun i => ⟨s₁ - 1 - i.1, by omega⟩
      invFun := fun k => ⟨s₁ - 1 - k.1, by omega⟩
      left_inv := fun i => Fin.ext (by dsimp; have := i.2; omega)
      right_inv := fun k => Fin.ext (by dsimp; have := k.2; omega) }
  exact Fintype.sum_equiv rev _ _ fun i => rfl

theorem evalPoly_pts_bijective {K : Type*} [Field K] [Fintype K] [DecidableEq K]
    {s₁ : ℕ} (_hs₁ : 1 ≤ s₁) {pts : Fin s₁ → K} (hinj_pts : Function.Injective pts) :
    Function.Bijective (fun (c : Fin s₁ → K) (j : Fin s₁) => evalPoly c (pts j)) := by
  rw [Fintype.bijective_iff_injective_and_card]
  refine ⟨?_, rfl⟩
  intro c₁ c₂ heq
  let d : Fin s₁ → K := fun k => c₁ k - c₂ k
  let P : Polynomial K := ∑ k : Fin s₁, Polynomial.monomial k.1 (d k)
  have hP_eval : ∀ x : K, P.eval x = ∑ k : Fin s₁, d k * x ^ k.1 := by
    intro x
    simp [P, Polynomial.eval_finset_sum]
  have hP_zero_pts : ∀ j : Fin s₁, P.eval (pts j) = 0 := by
    intro j
    rw [hP_eval]
    have hj := congrFun heq j
    unfold evalPoly at hj
    calc ∑ k : Fin s₁, (c₁ k - c₂ k) * (pts j) ^ k.1
        = (∑ k : Fin s₁, c₁ k * (pts j) ^ k.1) - (∑ k : Fin s₁, c₂ k * (pts j) ^ k.1) := by
          simp_rw [sub_mul]; exact Finset.sum_sub_distrib _ _
      _ = 0 := sub_eq_zero.mpr hj
  have hP_coeff : ∀ k : Fin s₁, P.coeff k.1 = d k := by
    intro k₀
    simp only [P, Polynomial.finset_sum_coeff, Polynomial.coeff_monomial]
    have hite : ∀ k : Fin s₁, (if k.1 = k₀.1 then d k else 0) = (if k = k₀ then d k₀ else 0) := by
      intro k
      by_cases hk : k = k₀
      · subst hk; simp
      · have hne : k.1 ≠ k₀.1 := fun h => hk (Fin.ext h)
        simp [hk, hne]
    simp_rw [hite]
    simp
  have hP_eq_zero : P = 0 := by
    by_contra hP_ne
    have hdeg_le : P.natDegree ≤ s₁ - 1 := by
      refine (Polynomial.natDegree_sum_le Finset.univ (fun k : Fin s₁ => Polynomial.monomial k.1 (d k))).trans ?_
      refine Finset.sup_le fun k _ => ?_
      exact (Polynomial.natDegree_monomial_le (d k)).trans (by have := k.2; omega)
    let S : Finset K := Finset.univ.image pts
    have hS_card : S.card = s₁ := by
      rw [Finset.card_image_of_injective _ hinj_pts, Finset.card_univ, Fintype.card_fin]
    have hsub_roots : S ⊆ P.roots.toFinset := by
      intro x hx
      rw [Multiset.mem_toFinset, Polynomial.mem_roots hP_ne]
      rcases Finset.mem_image.mp hx with ⟨j, _, rfl⟩
      exact hP_zero_pts j
    have hcard_le : S.card ≤ P.roots.card :=
      (Finset.card_le_card hsub_roots).trans (Multiset.toFinset_card_le P.roots)
    have hroots_le : P.roots.card ≤ P.natDegree := Polynomial.card_roots' P
    omega
  funext k
  have hd0 : d k = 0 := by
    rw [← hP_coeff k, hP_eq_zero, Polynomial.coeff_zero]
  exact sub_eq_zero.mp hd0

private theorem evalPoly_split_two {K : Type*} [CommRing K]
    {s₁ : ℕ} (hs₁ : 2 ≤ s₁) (c : Fin s₁ → K) (x : K) :
    evalPoly c x =
      c ⟨0, by omega⟩ + c ⟨1, by omega⟩ * x +
        ∑ i : Fin (s₁ - 2), c ⟨i.1 + 2, by omega⟩ * x ^ (i.1 + 2) := by
  obtain ⟨n, rfl⟩ : ∃ n : ℕ, s₁ = n + 2 := ⟨s₁ - 2, by omega⟩
  unfold evalPoly
  rw [Fin.sum_univ_succ, Fin.sum_univ_succ]
  simp only [Fin.val_zero, pow_zero, mul_one, Fin.val_succ, zero_add, pow_one, add_assoc]
  rfl

/-- Explicit bijection `(Fin s₁ → K) ≃ (K × K) × (Fin (s₁ - 2) → K)` for `s₁ ≥ 2` and `x₁ ≠ x₂`,
giving exact pairwise independence of `(evalPoly c x₁, evalPoly c x₂)`. -/
noncomputable def evalPolyPairEquiv {K : Type*} [Field K]
    {s₁ : ℕ} (hs₁ : 2 ≤ s₁) {x₁ x₂ : K} (hne : x₁ ≠ x₂) :
    (Fin s₁ → K) ≃ (K × K) × (Fin (s₁ - 2) → K) where
  toFun c :=
    ((evalPoly c x₁, evalPoly c x₂), fun i => c ⟨i.1 + 2, by omega⟩)
  invFun yt :=
    let y₁ := yt.1.1
    let y₂ := yt.1.2
    let tail := yt.2
    let r₁ : K := ∑ i : Fin (s₁ - 2), tail i * x₁ ^ (i.1 + 2)
    let r₂ : K := ∑ i : Fin (s₁ - 2), tail i * x₂ ^ (i.1 + 2)
    let c₁ : K := ((y₁ - r₁) - (y₂ - r₂)) / (x₁ - x₂)
    let c₀ : K := (y₁ - r₁) - c₁ * x₁
    fun k =>
      if _ : k.1 = 0 then c₀
      else if _ : k.1 = 1 then c₁
      else tail ⟨k.1 - 2, by omega⟩
  left_inv c := by
    have hdx : x₁ - x₂ ≠ 0 := sub_ne_zero.mpr hne
    have hs1 := evalPoly_split_two hs₁ c x₁
    have hs2 := evalPoly_split_two hs₁ c x₂
    set r₁ : K := ∑ i : Fin (s₁ - 2), c ⟨i.1 + 2, by omega⟩ * x₁ ^ (i.1 + 2)
    set r₂ : K := ∑ i : Fin (s₁ - 2), c ⟨i.1 + 2, by omega⟩ * x₂ ^ (i.1 + 2)
    have hy1 : evalPoly c x₁ - r₁ = c ⟨0, by omega⟩ + c ⟨1, by omega⟩ * x₁ := by
      rw [hs1]; dsimp [r₁]; ring
    have hy2 : evalPoly c x₂ - r₂ = c ⟨0, by omega⟩ + c ⟨1, by omega⟩ * x₂ := by
      rw [hs2]; dsimp [r₂]; ring
    have hc1 : ((evalPoly c x₁ - r₁) - (evalPoly c x₂ - r₂)) / (x₁ - x₂) = c ⟨1, by omega⟩ := by
      rw [hy1, hy2]
      have hdiff : (c ⟨0, by omega⟩ + c ⟨1, by omega⟩ * x₁) -
          (c ⟨0, by omega⟩ + c ⟨1, by omega⟩ * x₂) = c ⟨1, by omega⟩ * (x₁ - x₂) := by ring
      rw [hdiff]
      exact mul_div_cancel_right₀ (c ⟨1, by omega⟩) hdx
    have hc0 : (evalPoly c x₁ - r₁) - c ⟨1, by omega⟩ * x₁ = c ⟨0, by omega⟩ := by
      rw [hy1]; ring
    funext k
    dsimp only
    change (if _ : k.1 = 0 then (evalPoly c x₁ - r₁) - (((evalPoly c x₁ - r₁) - (evalPoly c x₂ - r₂)) / (x₁ - x₂)) * x₁
      else if _ : k.1 = 1 then ((evalPoly c x₁ - r₁) - (evalPoly c x₂ - r₂)) / (x₁ - x₂)
      else c ⟨k.1 - 2 + 2, by omega⟩) = c k
    rw [hc1, hc0]
    by_cases hk0 : k.1 = 0
    · rw [dif_pos hk0]; exact congrArg c (Fin.ext hk0.symm)
    · rw [dif_neg hk0]
      by_cases hk1 : k.1 = 1
      · rw [dif_pos hk1]; exact congrArg c (Fin.ext hk1.symm)
      · rw [dif_neg hk1]; exact congrArg c (Fin.ext (by dsimp; omega))
  right_inv := by
    rintro ⟨⟨y₁, y₂⟩, tail⟩
    have hdx : x₁ - x₂ ≠ 0 := sub_ne_zero.mpr hne
    let r₁ : K := ∑ i : Fin (s₁ - 2), tail i * x₁ ^ (i.1 + 2)
    let r₂ : K := ∑ i : Fin (s₁ - 2), tail i * x₂ ^ (i.1 + 2)
    let c₁ : K := ((y₁ - r₁) - (y₂ - r₂)) / (x₁ - x₂)
    let c₀ : K := (y₁ - r₁) - c₁ * x₁
    let c : Fin s₁ → K := fun k =>
      if _ : k.1 = 0 then c₀ else if _ : k.1 = 1 then c₁ else tail ⟨k.1 - 2, by omega⟩
    have hc_0 : c ⟨0, by omega⟩ = c₀ := by simp [c]
    have hc_1 : c ⟨1, by omega⟩ = c₁ := by simp [c]
    have hc_t : ∀ i : Fin (s₁ - 2), c ⟨i.1 + 2, by omega⟩ = tail i := by
      intro i
      dsimp [c]
      exact congrArg tail (Fin.ext (by dsimp; omega))
    have hev1 : evalPoly c x₁ = y₁ := by
      rw [evalPoly_split_two hs₁ c x₁, hc_0, hc_1]
      have hsum : (∑ i : Fin (s₁ - 2), c ⟨i.1 + 2, by omega⟩ * x₁ ^ (i.1 + 2)) = r₁ :=
        Finset.sum_congr rfl fun i _ => by rw [hc_t i]
      rw [hsum]
      dsimp [c₀]; ring
    have hev2 : evalPoly c x₂ = y₂ := by
      rw [evalPoly_split_two hs₁ c x₂, hc_0, hc_1]
      have hsum : (∑ i : Fin (s₁ - 2), c ⟨i.1 + 2, by omega⟩ * x₂ ^ (i.1 + 2)) = r₂ :=
        Finset.sum_congr rfl fun i _ => by rw [hc_t i]
      rw [hsum]
      have hc1_mul : c₁ * (x₁ - x₂) = (y₁ - r₁) - (y₂ - r₂) := div_mul_cancel₀ _ hdx
      dsimp [c₀]
      linear_combination -hc1_mul
    exact Prod.ext (Prod.ext hev1 hev2) (funext hc_t)

theorem evalPoly_pair_filter_card {K : Type*} [Field K] [Fintype K]
    {s₁ : ℕ} (hs₁ : 2 ≤ s₁) {x₁ x₂ : K} (hne : x₁ ≠ x₂)
    (P : K × K → Prop) [DecidablePred P] :
    (Finset.univ.filter (fun c : Fin s₁ → K => P (evalPoly c x₁, evalPoly c x₂))).card =
      (Finset.univ.filter P).card * (Fintype.card K) ^ (s₁ - 2) := by
  classical
  let e := evalPolyPairEquiv hs₁ hne
  let TailSet : Finset (Fin (s₁ - 2) → K) := Finset.univ
  have hbij :
      (Finset.univ.filter (fun c : Fin s₁ → K => P (evalPoly c x₁, evalPoly c x₂))).card =
      ((Finset.univ.filter P) ×ˢ TailSet).card := by
    refine Finset.card_bij (fun c _ => e c) ?_ (fun _ _ _ _ h => e.injective h) ?_
    · intro c hc
      exact Finset.mem_product.mpr
        ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hc).2⟩, Finset.mem_univ _⟩
    · intro yt hyt
      refine ⟨e.symm yt, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, e.apply_symm_apply yt⟩
      have hP : P yt.1 := (Finset.mem_filter.mp (Finset.mem_product.mp hyt).1).2
      have hfst : (evalPoly (e.symm yt) x₁, evalPoly (e.symm yt) x₂) = yt.1 :=
        congrArg Prod.fst (e.apply_symm_apply yt)
      rwa [hfst]
  rw [hbij, Finset.card_product]
  simp [TailSet, Fintype.card_pi]

end UL.Proof_lem_A_2
