import Mathlib
import UL.Proof.lem_A_2.RacerP51_H3d
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 1200000

namespace UL.Proof_lem_A_2

/-! ### 1. Bit-stream slicing and subroutine read helpers -/

theorem outSub_read_bitLength_le {d : ℕ} {prog : BitRAMStmt} {inp : BitRAMInput d}
    {out : BitRAMExecOutcome}
    (hrun : runBitRAMWithBits prog inp WordStore.empty [] = some out)
    (loc : RAMCellLoc) :
    intBitLength (out.words.read loc) ≤ out.peakBitSpace + 1 := by
  obtain ⟨_, hb⟩ := outSub_words_le_peak hrun
  unfold WordStore.read
  by_cases hm : loc ∈ out.words.live
  · rw [if_pos hm]
    have hterm : loc.bitLength + intBitLength (out.words.vals loc) ≤ out.words.bitSize := by
      dsimp [WordStore.bitSize]
      exact Finset.single_le_sum (f := fun x => x.bitLength + intBitLength (out.words.vals x)) (fun _ _ => Nat.zero_le _) hm
    omega
  · rw [if_neg hm]
    change 1 ≤ out.peakBitSpace + 1
    omega

theorem natBitLength_natAbs_le_of_intBitLength_le {z : ℤ} {L : ℕ} (h : intBitLength z ≤ L) :
    natBitLength z.natAbs ≤ L := by
  unfold intBitLength at h
  by_cases hz : z = 0
  · subst hz; change 1 ≤ L at h ⊢; exact h
  · rw [if_neg hz] at h; omega

theorem natAbs_lt_two_pow_of_intBitLength {z : ℤ} {K : ℕ}
    (hz : z ≠ 0) (hb : intBitLength z ≤ K) :
    z.natAbs < 2 ^ K := by
  have hnb : natBitLength z.natAbs ≤ K := by
    unfold intBitLength at hb
    split_ifs at hb <;> omega
  have hlt : z.natAbs < 2 ^ (natBitLength z.natAbs) := by
    unfold natBitLength
    exact Nat.lt_pow_succ_log_self (by norm_num) z.natAbs
  exact hlt.trans_le (Nat.pow_le_pow_right (by norm_num) hnb)

theorem ratCoordBitBounded_num_den_V {B V : ℕ} {q : ℚ}
    (hq : RatCoordBitBounded B q) (hBV : B + 4 ≤ V) :
    intBitLength q.num ≤ V ∧
    intBitLength (q.den : ℤ) ≤ V ∧
    intBitLength ((q.den : ℤ) - 1) ≤ V := by
  obtain ⟨hn, hd⟩ := hq
  have h1 : intBitLength q.num ≤ B + 2 := by
    unfold intBitLength; split_ifs <;> omega
  have h2 : intBitLength (q.den : ℤ) ≤ B + 2 := by
    have := intBitLength_natCast_le_succ q.den; omega
  have h3 : intBitLength ((q.den : ℤ) - 1) ≤ B + 2 := by
    have hpos : 1 ≤ q.den := q.pos
    have hsub : ((q.den : ℤ) - 1) = (((q.den - 1 : ℕ) : ℤ)) := by omega
    rw [hsub]
    have := intBitLength_natCast_le_succ (q.den - 1)
    have := natBitLength_mono (by omega : q.den - 1 ≤ q.den)
    omega
  exact ⟨by omega, by omega, by omega⟩

theorem liftRatPoint_cast_lt {d : ℕ} (q : Fin d → ℚ) {c : ℕ} (hc : c < d) :
    liftRatPoint q ⟨c, Nat.lt_succ_of_lt hc⟩ = q ⟨c, hc⟩ := by
  simp [liftRatPoint, Fin.snoc, hc]

def blockBitStream {K W : ℕ} (f : Fin K → Fin W → Bool) (rest : List Bool) (k : ℕ) : List Bool :=
  ((List.finRange K).drop k).flatMap (fun j => List.ofFn (f j)) ++ rest

theorem blockBitStream_self {K W : ℕ} (f : Fin K → Fin W → Bool) (rest : List Bool) :
    blockBitStream f rest K = rest := by
  unfold blockBitStream
  rw [List.drop_eq_nil_of_le (by simp)]
  simp

theorem blockBitStream_step {K W : ℕ} (f : Fin K → Fin W → Bool) (rest : List Bool)
    {k : ℕ} (hk : k < K) :
    blockBitStream f rest k = List.ofFn (f ⟨k, hk⟩) ++ blockBitStream f rest (k + 1) := by
  unfold blockBitStream
  have hlen : k < (List.finRange K).length := by simp [hk]
  rw [List.drop_eq_getElem_cons hlen, List.flatMap_cons, List.append_assoc]
  have hget : (List.finRange K)[k] = ⟨k, hk⟩ := by ext; simp
  rw [hget]

theorem ofFn_add_split {A B : ℕ} (g : Fin (A + B) → Bool) :
    List.ofFn g =
      List.ofFn (fun i : Fin A => g ⟨i.1, by omega⟩) ++
      List.ofFn (fun j : Fin B => g ⟨A + j.1, by omega⟩) := by
  apply List.ext_getElem
  · simp
  · intro i h1 h2
    rw [List.getElem_ofFn, List.getElem_append]
    simp only [List.length_ofFn]
    split_ifs with hlt
    · rw [List.getElem_ofFn]
    · rw [List.getElem_ofFn]
      congr 1; ext; dsimp; omega

theorem blockBitStream_zero_eq :
    ∀ (K W : ℕ) (f : Fin K → Fin W → Bool) (rest : List Bool)
      (g : Fin (K * W) → Bool),
      (∀ (j : Fin K) (b : Fin W),
        g ⟨j.1 * W + b.1, by
          have hj : (j.1 + 1) * W ≤ K * W := Nat.mul_le_mul_right W j.2
          have hb : b.1 < W := b.2
          rw [Nat.add_mul, Nat.one_mul] at hj
          omega⟩ = f j b) →
      List.ofFn g ++ rest = blockBitStream f rest 0
  | 0, W, f, rest, g, _ => by
      have hg0 : List.ofFn g = [] := by
        rw [List.eq_nil_iff_forall_not_mem]
        intro x hx
        obtain ⟨i, _⟩ := List.mem_ofFn.mp hx
        exact absurd i.2 (by simp)
      simp [blockBitStream, hg0]
  | K + 1, W, f, rest, g, hg => by
      have hsplit : (K + 1) * W = W + K * W := by ring
      let g' : Fin (W + K * W) → Bool := fun i => g ⟨i.1, by omega⟩
      have hg_eq : List.ofFn g = List.ofFn g' := by
        apply List.ext_getElem
        · simp [hsplit]
        · intro i _ _; simp [g']
      rw [hg_eq, ofFn_add_split g', List.append_assoc]
      have hf0 : List.ofFn (fun b : Fin W => g' ⟨b.1, by omega⟩) = List.ofFn (f 0) := by
        congr 1; funext b
        simpa [g'] using hg 0 b
      rw [hf0, blockBitStream_step f rest (Nat.zero_lt_succ K)]
      congr 1
      have hdrop1 : (List.finRange (K + 1)).drop 1 = (List.finRange K).map Fin.succ := by
        rw [List.finRange_succ]; rfl
      have hbs1 : blockBitStream f rest 1 = blockBitStream (fun j : Fin K => f j.succ) rest 0 := by
        unfold blockBitStream
        rw [hdrop1, List.flatMap_map]
        rfl
      rw [hbs1]
      refine blockBitStream_zero_eq K W (fun j => f j.succ) rest
        (fun idx => g' ⟨W + idx.1, by omega⟩) fun j b => ?_
      have hidx : W + (j.1 * W + b.1) = j.succ.1 * W + b.1 := by
        dsimp [Fin.succ]; ring
      have := hg j.succ b
      dsimp [g']
      convert this using 2
      ext; exact hidx

theorem splitAttemptBits_stream {M W₁ m W₂ : ℕ}
    (v : Fin (M * W₁ + m * W₂) → Bool) (rest : List Bool) :
    let sp := splitAttemptBits M W₁ m W₂ v
    List.ofFn v ++ rest = blockBitStream sp.1 (blockBitStream sp.2 rest 0) 0 := by
  intro sp
  rw [ofFn_add_split v, List.append_assoc]
  rw [blockBitStream_zero_eq m W₂ sp.2 rest _ (fun _ _ => rfl)]
  exact blockBitStream_zero_eq M W₁ sp.1 _ _ (fun _ _ => rfl)

/-! ### 2. `HasZArray` and Phase 3 statements -/

def HasZArray (D : ℕ) (zRat : Fin D → ℚ) (ws : WordStore) : Prop :=
  ∀ c : Fin D,
    ws.read (.localFrame 1 4 (2 * (c.1 : ℤ))) = (zRat c).num ∧
    ws.read (.localFrame 1 4 (2 * (c.1 : ℤ) + 1)) = ((zRat c).den : ℤ)

theorem hasZArray_of_eq {D : ℕ} {zRat : Fin D → ℚ} {ws ws' : WordStore}
    (h : HasZArray D zRat ws)
    (heq : ∀ idx : ℤ, ws'.read (.localFrame 1 4 idx) = ws.read (.localFrame 1 4 idx)) :
    HasZArray D zRat ws' :=
  fun c => ⟨(heq _).trans (h c).1, (heq _).trans (h c).2⟩

def phase3InnerCoordBody : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 12) (.add (.readLocal 1 (.lit 11)) (.readLocal 1 (.lit 10))))
  (.seq (.writeHeap 6 (.readLocal 1 (.lit 12))
          (.activeRatNum (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 10))))
  (.seq (.writeHeap 7 (.readLocal 1 (.lit 12))
          (.sub (.activeRatDen (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 10))) (.lit 1)))
        (.writeLocal 1 (.lit 10) (.add (.readLocal 1 (.lit 10)) (.lit 1)))))

def phase3SampleOuterBody : BitRAMStmt :=
  .seq (drawBitsStmt 12 3 4)
  (.seq (.writeLocal 1 (.lit 13) (.mod (.readLocal 1 (.lit 3)) (.readLocal 0 (.lit 2))))
  (.seq (.writeLocal 1 (.lit 11)
          (.add (.mul (.readLocal 1 (.lit 9)) (.readLocal 0 (.lit 1))) (.lit 1)))
  (.seq (.writeLocal 1 (.lit 10) (.lit 0))
  (.seq (.repeatN (.readLocal 0 (.lit 0)) phase3InnerCoordBody)
  (.seq (.writeLocal 1 (.lit 12) (.add (.readLocal 1 (.lit 11)) (.readLocal 0 (.lit 0))))
  (.seq (.writeHeap 6 (.readLocal 1 (.lit 12)) (.readLocal 2 (.readLocal 1 (.lit 13))))
  (.seq (.writeHeap 7 (.readLocal 1 (.lit 12))
          (.sub (.readLocal 3 (.readLocal 1 (.lit 13))) (.lit 1)))
        (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1))))))))))

def phase3StageStmt (k_φ : ℕ) : BitRAMStmt :=
  .seq (.writeHeap 5 (.lit 0) (.readLocal 0 (.lit 4)))
  (.seq (.writeHeap 5 (.lit 1) (.lit (k_φ : ℤ)))
  (.seq (.writeHeap 5 (.lit 2) (.readLocal 0 (.lit 11)))
  (.seq (.writeLocal 1 (.lit 9) (.lit 0))
        (.repeatN (.readLocal 0 (.lit 11)) phase3SampleOuterBody))))

def phase3UnstageStmt : BitRAMStmt :=
  .seq (.freeHeap 5 (.lit 0))
  (.seq (.freeHeap 5 (.lit 1))
  (.seq (.freeHeap 5 (.lit 2))
  (.seq (.writeLocal 1 (.lit 9) (.lit 1))
  (.seq (.writeLocal 1 (.lit 10) (.mul (.readLocal 0 (.lit 11)) (.readLocal 0 (.lit 1))))
        (.repeatN (.readLocal 1 (.lit 10))
          (.seq (.freeHeap 6 (.readLocal 1 (.lit 9)))
          (.seq (.freeHeap 7 (.readLocal 1 (.lit 9)))
                (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1))))))))))

def phase3ReduceBody : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 10) (.mul (.lit 2) (.readLocal 1 (.lit 9))))
  (.seq (.writeLocal 1 (.lit 13) (.add (.readLocal 1 (.lit 10)) (.lit 1)))
  (.seq (.writeLocal 1 (.lit 11) (.readLocal 4 (.readLocal 1 (.lit 10))))
  (.seq (.writeLocal 1 (.lit 12) (.readLocal 4 (.readLocal 1 (.lit 13))))
  (.seq (.ite (.intLt (.readLocal 1 (.lit 11)) (.lit 0))
          (.writeLocal 1 (.lit 6) (.neg (.readLocal 1 (.lit 11))))
          (.writeLocal 1 (.lit 6) (.readLocal 1 (.lit 11))))
  (.seq (.writeLocal 1 (.lit 7) (.readLocal 1 (.lit 12)))
  (.seq (gcdLoopStmt 5 6 7 8)
  (.seq (.writeLocal 4 (.readLocal 1 (.lit 10))
          (.div (.readLocal 1 (.lit 11)) (.readLocal 1 (.lit 6))))
  (.seq (.writeLocal 4 (.readLocal 1 (.lit 13))
          (.div (.readLocal 1 (.lit 12)) (.readLocal 1 (.lit 6))))
        (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1)))))))))))

def phase3ReduceStmt : BitRAMStmt :=
  .seq (.writeLocal 1 (.lit 5) (.readLocal 0 (.lit 10)))
  (.seq (.writeLocal 1 (.lit 9) (.lit 0))
        (.repeatN (.readLocal 0 (.lit 1)) phase3ReduceBody))

def phase3Stmt (k_φ : ℕ) (prog_A1 : BitRAMStmt) : BitRAMStmt :=
  .seq (phase3StageStmt k_φ)
  (.seq (runSubAndExtractStmt true prog_A1 1 15 4 (some (0, 14)) 9)
  (.seq phase3UnstageStmt phase3ReduceStmt))

/-! ### 3. Execution of `phase3StageStmt` -/

theorem exec_phase3StageStmt {A V M : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ)
    (f_samp : Fin M → Fin (p.W₁ M) → Bool) (restBits : List Bool)
    {inp : BitRAMInput p.d} {ws₃ : WordStore}
    (harena : InAttemptArena A V ws₃)
    (hhz : HeapAllZero ws₃)
    (hregs : HasPhase2Regs p M ws₃)
    (hlifts : HasLiftArrays p pts_h ws₃)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hpts_b : ∀ h : ℕ, h < p.m → RatPointBitBounded p.B (pts_h h))
    (hip_handles : inp.activeHandles = Finset.range p.m)
    (hip_coords : ∀ h : ℕ, h < p.m → inp.activeRatCoords h = pts_h h)
    (hM_fit : 1 ≤ M ∧ M * p.D + 4 ≤ A ∧ p.W₁ M + 4 ≤ V) :
    let hm_pos : 0 < p.m := by
      have hs1 := s₀Val_pos (deg_α := p.deg_α) hfit.1 p.d
      have hm2 := hfit.2.2.2.1
      dsimp [CoreParams.s₀] at hm2
      omega
    let ω : Fin M → Fin p.m := fun j =>
      ⟨bitsToNat (p.W₁ M) (f_samp j) % p.m, Nat.mod_lt _ hm_pos⟩
    let sampleInp : BitRAMInput p.D :=
      { intParams := [(p.B_lift : ℤ), (p.k_φ : ℤ), (M : ℤ)]
        activeHandles := Finset.range M
        activeRatCoords := fun j =>
          if hj : j < M then liftRatPoint (pts_h (ω ⟨j, hj⟩).1) else fun _ => 0
        extraRats := [] }
    ∃ wsStaged : WordStore,
      InAttemptArena A V wsStaged ∧
      HasPhase2Regs p M wsStaged ∧
      HasLiftArrays p pts_h wsStaged ∧
      SimStageMatches true p.d p.D V wsStaged sampleInp ∧
      (∀ t idx, t ≠ 5 → t ≠ 6 → t ≠ 7 → wsStaged.read (.heap t idx) = 0) ∧
      (∀ idx : ℤ, idx ≠ 0 → idx ≠ 1 → idx ≠ 2 → wsStaged.read (.heap 5 idx) = 0) ∧
      (∀ idx : ℤ, (idx < 1 ∨ ((M * p.D : ℕ) : ℤ) < idx) →
        wsStaged.read (.heap 6 idx) = 0 ∧ wsStaged.read (.heap 7 idx) = 0) ∧
      ExecBounded inp (phase3StageStmt p.k_φ)
        ws₃ (blockBitStream f_samp restBits 0) wsStaged restBits
        (400 + M * (900 + 300 * p.d + 24 * (p.W₁ M + 1)))
        ((400000 + M * (900000 + 300000 * p.d)) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  intro hm_pos ω sampleInp
  rcases hfit with ⟨hK1, hB1, _, hm2s, h16A, hmA, hVA, hBlV, _, _, _, _, _, hkφV⟩
  rcases hM_fit with ⟨hM1, hMDA, hW1V⟩
  have hV16 : 16 ≤ V := by omega
  have hD_pos : 1 ≤ p.D := by dsimp [CoreParams.D]; omega
  have hM_le_A : M < A := by
    have : M ≤ M * p.D := Nat.le_mul_of_pos_right M hD_pos
    omega
  have hM_V : intBitLength (M : ℤ) ≤ V := by
    have h1 := intBitLength_natCast_le_succ M
    have h2 := natBitLength_mono (le_of_lt hM_le_A)
    omega
  have hBl_iV : intBitLength (p.B_lift : ℤ) ≤ V := by
    have h1 := intBitLength_natCast_le_succ p.B_lift
    have h2 := natBitLength_le p.B_lift
    omega
  have hd_V : intBitLength (p.d : ℤ) ≤ V := by
    have hd_lt_A : p.d < A := by dsimp [CoreParams.D] at hmA; omega
    have h1 := intBitLength_natCast_le_succ p.d
    have h2 := natBitLength_mono (le_of_lt hd_lt_A)
    omega
  have idx_V : ∀ k : ℕ, k ≤ A → intBitLength (k : ℤ) ≤ V := by
    intro k hk
    have h1 := intBitLength_natCast_le_succ k
    have h2 := natBitLength_mono hk
    omega
  -- Step 1: writeHeap 5 [0, 1, 2] := [B_lift, k_φ, M] and writeLocal 1 9 0
  obtain ⟨ha_s1, ex_s1⟩ := exec_writeHeap_auto (t := 5) (idxE := .lit 0) (valE := .readLocal 0 (.lit 4)) harena hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) hregs.1.2.2.2.2.1 (by decide) (by omega) (by simp; omega) hBl_iV
  obtain ⟨ha_s2, ex_s2⟩ := exec_writeHeap_auto (t := 5) (idxE := .lit 1) (valE := .lit (p.k_φ : ℤ)) ha_s1 hinp
    (exprInArena_small (by decide) (by decide) hV16) hkφV
    ⟨by simp [exprNodes], by simp [exprNodes]⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _) (by decide) (by omega) (by simp; omega) hkφV
  obtain ⟨ha_s3, ex_s3⟩ := exec_writeHeap_auto (t := 5) (idxE := .lit 2) (valE := .readLocal 0 (.lit 11)) ha_s2 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
          hregs.2.1]; try rfl)
    (by decide) (by omega) (by simp; omega) hM_V
  obtain ⟨ha_s4, ex_s4⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .lit 0) ha_s3 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _) (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
  -- Outer loop invariant over `j ≤ M`
  let OuterInv (j : ℕ) (ws : WordStore) (bs_cur : List Bool) : Prop :=
    bs_cur = blockBitStream f_samp restBits j ∧
    InAttemptArena A V ws ∧
    HasPhase2Regs p M ws ∧
    HasLiftArrays p pts_h ws ∧
    ws.read (.localFrame 1 1 9) = (j : ℤ) ∧
    (∀ t idx, t ≠ 5 → t ≠ 6 → t ≠ 7 → ws.read (.heap t idx) = 0) ∧
    (∀ idx : ℤ, ws.read (.heap 5 idx) = listGetIntD [(p.B_lift : ℤ), (p.k_φ : ℤ), (M : ℤ)] idx 0) ∧
    (∀ idx : ℤ, (idx < 1 ∨ ((j * p.D : ℕ) : ℤ) < idx) →
      ws.read (.heap 6 idx) = 0 ∧ ws.read (.heap 7 idx) = 0) ∧
    (∀ (j' : ℕ) (hj' : j' < min j M) (c : Fin p.D),
      let a : ℤ := ((j' * p.D + c.1 + 1 : ℕ) : ℤ)
      ws.read (.heap 6 a) = (liftRatPoint (pts_h (ω ⟨j', Nat.lt_of_lt_of_le hj' (Nat.min_le_right j M)⟩).1) c).num ∧
      ws.read (.heap 7 a) + 1 = ((liftRatPoint (pts_h (ω ⟨j', Nat.lt_of_lt_of_le hj' (Nat.min_le_right j M)⟩).1) c).den : ℤ))
  have hinit_outer : OuterInv 0 (wsOf ha_s4) (blockBitStream f_samp restBits 0) := by
    refine ⟨rfl, ha_s4,
      hasPhase2Regs_of_eq hregs (fun idx => by
        simp [rw_write_eq, rf_free_eq]),
      hasLiftArrays_of_eq hlifts (fun v idx hv => by
        have hne1 : v ≠ 1 := by rcases hv with rfl | rfl <;> decide
        rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ hv' _; exact hne1 hv')]
        simp [rw_write_eq, rf_free_eq]),
      wordStore_read_write_self _ _ _,
      fun t idx ht5 _ _ => by
        rw [wordStore_read_write_of_ne _ (by intro hc; cases hc),
          wordStore_read_write_of_ne _ (by intro hc; injection hc with ht _; exact ht5 ht),
          wordStore_read_write_of_ne _ (by intro hc; injection hc with ht _; exact ht5 ht),
          wordStore_read_write_of_ne _ (by intro hc; injection hc with ht _; exact ht5 ht)]
        exact hhz t idx,
      fun idx => ?_,
      fun idx _ => ⟨by
        simp [rw_write_eq, rf_free_eq]
        exact hhz 6 idx, by
        simp [rw_write_eq, rf_free_eq]
        exact hhz 7 idx⟩,
      fun _ hj' => absurd hj' (by omega)⟩
    rw [wordStore_read_write_of_ne _ (by intro hc; cases hc)]
    by_cases h2 : idx = 2
    · subst h2; rw [wordStore_read_write_self]; rfl
    · rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ hi; exact h2 hi)]
      by_cases h1 : idx = 1
      · subst h1; rw [wordStore_read_write_self]; rfl
      · rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ hi; exact h1 hi)]
        by_cases h0 : idx = 0
        · subst h0; rw [wordStore_read_write_self]; rfl
        · rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ hi; exact h0 hi),
            hhz 5 idx]
          unfold listGetIntD
          by_cases hn : 0 ≤ idx
          · rw [if_pos hn]
            have hge3 : 3 ≤ idx.toNat := by omega
            have hnone : ([(p.B_lift : ℤ), (p.k_φ : ℤ), (M : ℤ)][idx.toNat]?) = none :=
              List.getElem?_eq_none (by simp; omega)
            simp [List.getD, hnone]
          · rw [if_neg hn]
  have hcnt_M : evalVal inp (wsOf ha_s4) (.readLocal 0 (.lit 11)) = (M : ℤ) := by
    simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit]
    exact hregs.2.1
  obtain ⟨wsStaged, bsAfter, hinv_M, ex_loop⟩ := exec_repeatN_inv (countE := .readLocal 0 (.lit 11)) (body := phase3SampleOuterBody) M OuterInv
    ha_s4 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
    hcnt_M hinit_outer
    (U := 800 + 300 * p.d + 24 * (p.W₁ M + 1))
    (B := (850000 + 300000 * p.d) * (V + 8) ^ 2)
    (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
    (fun j ws_j bs_j hj ⟨hbs_j, ha_j, hregs_j, hlifts_j, hr9_j, hht_j, hh5_j, hh67_zero_j, hh67_prev_j⟩ => by
      subst bs_j
      rw [blockBitStream_step f_samp restBits hj]
      -- 1. drawBitsStmt 12 3 4
      obtain ⟨ws_d, ha_d, hr3_d, hoth_d, ex_d⟩ :=
        exec_drawBitsStmt (inp := inp) (f_samp ⟨j, hj⟩) (blockBitStream f_samp restBits (j + 1))
          (wIdx := 12) (accIdx := 3) (bitIdx := 4) ha_j (by decide)
          ⟨by omega, by omega, by omega, by omega, by omega, by omega, h16A⟩
          hregs_j.2.2 hW1V
      let idx_j : ℕ := (ω ⟨j, hj⟩).1
      have hidx_lt_m : idx_j < p.m := (ω ⟨j, hj⟩).2
      have hmod_eq : (bitsToNat (p.W₁ M) (f_samp ⟨j, hj⟩) : ℤ) % (p.m : ℤ) = (idx_j : ℤ) := by
        exact_mod_cast rfl
      -- 2. (1, 13) := (1, 3) % (0, 2)
      obtain ⟨ha_m, ex_m⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 13) (valE := .mod (.readLocal 1 (.lit 3)) (.readLocal 0 (.lit 2))) ha_d hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp only [evalVal_mod, evalVal_readLocal, evalVal_lit, hr3_d,
              hoth_d (.localFrame 1 0 2) (by decide) (by decide), hregs_j.1.2.2.1, hmod_eq]; try rfl)
        (by decide) (by omega) (by simp; omega)
        (idx_V idx_j (by omega))
      -- 3. (1, 11) := j * D + 1
      let base_j : ℕ := j * p.D + 1
      have hbase_le_MD : base_j + p.d ≤ M * p.D := by
        have hj1 : (j + 1) * p.D ≤ M * p.D := Nat.mul_le_mul_right p.D hj
        dsimp [base_j, CoreParams.D] at hj1 ⊢
        rw [Nat.add_mul, Nat.one_mul] at hj1
        omega
      obtain ⟨ha_b, ex_b⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 11) (valE := .add (.mul (.readLocal 1 (.lit 9)) (.readLocal 0 (.lit 1))) (.lit 1)) ha_m hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_mul, evalVal_readLocal, evalVal_lit,
              hoth_d (.localFrame 1 1 9) (by decide) (by decide), hoth_d (.localFrame 1 0 1) (by decide) (by decide), hr9_j, hregs_j.1.2.1]
            dsimp [base_j]; try push_cast; try ring; try rfl)
        (by decide) (by omega) (by simp; omega)
        (idx_V base_j (by omega))
      -- 4. (1, 10) := 0
      obtain ⟨ha_c0, ex_c0⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 10) (valE := .lit 0) ha_b hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _)
        (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
      -- Lift bit bounds for `pts_h idx_j`
      have hlift_b : RatPointBitBounded p.B_lift (liftRatPoint (pts_h idx_j)) :=
        ratPointBitBounded_liftRatPoint hB1 (hpts_b idx_j hidx_lt_m)
      -- 5. Inner loop over `c = 0 .. p.d - 1`
      let bsNext := blockBitStream f_samp restBits (j + 1)
      let InnerInv (c : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
        bs_c = bsNext ∧
        InAttemptArena A V ws ∧
        HasPhase2Regs p M ws ∧
        HasLiftArrays p pts_h ws ∧
        ws.read (.localFrame 1 1 9) = (j : ℤ) ∧
        ws.read (.localFrame 1 1 10) = (c : ℤ) ∧
        ws.read (.localFrame 1 1 11) = (base_j : ℤ) ∧
        ws.read (.localFrame 1 1 13) = (idx_j : ℤ) ∧
        (∀ t idx, t ≠ 5 → t ≠ 6 → t ≠ 7 → ws.read (.heap t idx) = 0) ∧
        (∀ idx : ℤ, ws.read (.heap 5 idx) = listGetIntD [(p.B_lift : ℤ), (p.k_φ : ℤ), (M : ℤ)] idx 0) ∧
        (∀ idx : ℤ, (idx < 1 ∨ ((base_j + c : ℕ) : ℤ) ≤ idx) →
          ws.read (.heap 6 idx) = 0 ∧ ws.read (.heap 7 idx) = 0) ∧
        (∀ (j' : ℕ) (hj' : j' < j) (c' : Fin p.D),
          let a : ℤ := ((j' * p.D + c'.1 + 1 : ℕ) : ℤ)
          ws.read (.heap 6 a) = (liftRatPoint (pts_h (ω ⟨j', hj'.trans hj⟩).1) c').num ∧
          ws.read (.heap 7 a) + 1 = ((liftRatPoint (pts_h (ω ⟨j', hj'.trans hj⟩).1) c').den : ℤ)) ∧
        (∀ (c' : ℕ) (hc' : c' < min c p.d),
          let a : ℤ := ((base_j + c' : ℕ) : ℤ)
          ws.read (.heap 6 a) = (liftRatPoint (pts_h idx_j) ⟨c', Nat.lt_succ_of_lt (Nat.lt_of_lt_of_le hc' (Nat.min_le_right c p.d))⟩).num ∧
          ws.read (.heap 7 a) + 1 = ((liftRatPoint (pts_h idx_j) ⟨c', Nat.lt_succ_of_lt (Nat.lt_of_lt_of_le hc' (Nat.min_le_right c p.d))⟩).den : ℤ))
      have hinit_inner : InnerInv 0 (wsOf ha_c0) bsNext := by
        have hloc_unch : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
            ((((ws_d.write (.localFrame 1 1 13) (idx_j : ℤ)).write
              (.localFrame 1 1 11) (base_j : ℤ)).write (.localFrame 1 1 10) 0)).read (.localFrame 1 v idx) =
            ws_j.read (.localFrame 1 v idx) := by
          intro v idx hne1
          rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ hv _; exact hne1 hv),
            wordStore_read_write_of_ne _ (by intro hc; injection hc with _ hv _; exact hne1 hv),
            wordStore_read_write_of_ne _ (by intro hc; injection hc with _ hv _; exact hne1 hv),
            hoth_d _ (by intro hc; injection hc with _ hv _; exact hne1 hv)
              (by intro hc; injection hc with _ hv _; exact hne1 hv)]
        have hheap_unch : ∀ (t : ℕ) (idx : ℤ),
            ((((ws_d.write (.localFrame 1 1 13) (idx_j : ℤ)).write
              (.localFrame 1 1 11) (base_j : ℤ)).write (.localFrame 1 1 10) 0)).read (.heap t idx) =
            ws_j.read (.heap t idx) := by
          intro t idx
          rw [wordStore_read_write_of_ne _ (by intro hc; cases hc),
            wordStore_read_write_of_ne _ (by intro hc; cases hc),
            wordStore_read_write_of_ne _ (by intro hc; cases hc),
            hoth_d _ (by intro hc; cases hc) (by intro hc; cases hc)]
        refine ⟨rfl, ha_c0,
          hasPhase2Regs_of_eq hregs_j (fun idx => hloc_unch 0 idx (by decide)),
          hasLiftArrays_of_eq hlifts_j (fun v idx hv => hloc_unch v idx (by rcases hv with rfl | rfl <;> decide)),
          by rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
               wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), hoth_d _ (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega), hr9_j],
          wordStore_read_write_self _ _ _,
          by rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_self],
          by rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
               wordStore_read_write_self],
          fun t idx ht5 ht6 ht7 => (hheap_unch t idx).trans (hht_j t idx ht5 ht6 ht7),
          fun idx => (hheap_unch 5 idx).trans (hh5_j idx),
          fun idx hrange => by
            rw [hheap_unch 6 idx, hheap_unch 7 idx]
            exact hh67_zero_j idx (by dsimp [base_j] at hrange; omega),
          fun j' hj' c' => by
            dsimp only
            rw [hheap_unch 6 _, hheap_unch 7 _]
            exact hh67_prev_j j' (lt_min hj' (hj'.trans hj)) c',
          fun _ hc' => absurd hc' (by omega)⟩
      have hcnt_d : evalVal inp (wsOf ha_c0) (.readLocal 0 (.lit 0)) = (p.d : ℤ) := by
        simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
          hoth_d (.localFrame 1 0 0) (by decide) (by decide), hregs_j.1.1]
      obtain ⟨ws_in, bs_in, hinv_d, ex_in⟩ := exec_repeatN_inv (countE := .readLocal 0 (.lit 0)) (body := phase3InnerCoordBody) p.d InnerInv
        ha_c0 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
        hcnt_d hinit_inner
        (U := 300) (B := 300000 * (V + 8) ^ 2)
        (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
        (fun c ws_c bs_c hc ⟨hbs_c, ha_c, hregs_c, hlifts_c, hr9_c, hr10_c, hr11_c, hr13_c,
            hht_c, hh5_c, hh67_zero_c, hh67_prev_c, hh67_cur_c⟩ => by
          subst bs_c
          let addr_c : ℕ := base_j + c
          have haddr_lt_A : addr_c < A := by dsimp [addr_c]; omega
          have hcoord_b := ratCoordBitBounded_num_den_V (B := p.B_lift) (V := V)
            (hlift_b ⟨c, Nat.lt_succ_of_lt hc⟩) (by omega)
          have hl_eq : liftRatPoint (pts_h idx_j) ⟨c, Nat.lt_succ_of_lt hc⟩ = pts_h idx_j ⟨c, hc⟩ :=
            liftRatPoint_cast_lt (pts_h idx_j) hc
          -- (1, 12) := base_j + c
          obtain ⟨ha_1, ex_1⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 12) (valE := .add (.readLocal 1 (.lit 11)) (.readLocal 1 (.lit 10))) ha_c hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
            (by simp only [evalVal_add, evalVal_readLocal, evalVal_lit, hr11_c, hr10_c]
                dsimp [addr_c]; try push_cast; try ring; try rfl)
            (by decide) (by omega) (by simp; omega) (idx_V addr_c (by omega))
          -- writeHeap 6 addr_c (activeRatNum idx_j c)
          have hh_mem : idx_j ∈ inp.activeHandles := by
            rw [hip_handles, Finset.mem_range]; exact hidx_lt_m
          have hnum_eval :
              evalVal inp (ws_c.write (.localFrame 1 1 12) (addr_c : ℤ))
                (.activeRatNum (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 10))) =
              (liftRatPoint (pts_h idx_j) ⟨c, Nat.lt_succ_of_lt hc⟩).num := by
            have h1 : (0 : ℤ) ≤ (idx_j : ℤ) ∧ ((idx_j : ℤ)).toNat ∈ inp.activeHandles :=
              ⟨by positivity, by simpa using hh_mem⟩
            have h2 : (0 : ℤ) ≤ (c : ℤ) ∧ ((c : ℤ)).toNat < p.d :=
              ⟨by positivity, by simpa using hc⟩
            rw [evalVal_activeRatNum, evalVal_readLocal, evalVal_lit,
              wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 1 13 ≠ .localFrame 1 1 12),
              evalVal_readLocal, evalVal_lit,
              wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 1 10 ≠ .localFrame 1 1 12),
              hr13_c, hr10_c, dif_pos h1, dif_pos h2]
            simp only [Int.toNat_natCast, hip_coords idx_j hidx_lt_m, hl_eq]
          obtain ⟨ha_2, ex_2⟩ := exec_writeHeap_auto (t := 6) (idxE := .readLocal 1 (.lit 12)) (valE := .activeRatNum (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 10))) ha_1 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by decide, by decide⟩
            (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit]; try rfl)
            hnum_eval (by decide) (by positivity) (by simpa using haddr_lt_A) hcoord_b.1
          -- writeHeap 7 addr_c (activeRatDen idx_j c - 1)
          have hden_eval :
              evalVal inp ((ws_c.write (.localFrame 1 1 12) (addr_c : ℤ)).write
                (.heap 6 (addr_c : ℤ)) (liftRatPoint (pts_h idx_j) ⟨c, Nat.lt_succ_of_lt hc⟩).num)
                (.sub (.activeRatDen (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 10))) (.lit 1)) =
              ((liftRatPoint (pts_h idx_j) ⟨c, Nat.lt_succ_of_lt hc⟩).den : ℤ) - 1 := by
            have h1 : (0 : ℤ) ≤ (idx_j : ℤ) ∧ ((idx_j : ℤ)).toNat ∈ inp.activeHandles :=
              ⟨by positivity, by simpa using hh_mem⟩
            have h2 : (0 : ℤ) ≤ (c : ℤ) ∧ ((c : ℤ)).toNat < p.d :=
              ⟨by positivity, by simpa using hc⟩
            rw [evalVal_sub, evalVal_activeRatDen, evalVal_readLocal, evalVal_lit, rw_local_heap,
              wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 1 13 ≠ .localFrame 1 1 12),
              evalVal_readLocal, evalVal_lit, rw_local_heap,
              wordStore_read_write_of_ne _ (by decide : RAMCellLoc.localFrame 1 1 10 ≠ .localFrame 1 1 12),
              hr13_c, hr10_c, dif_pos h1, dif_pos h2, evalVal_lit]
            simp only [Int.toNat_natCast, hip_coords idx_j hidx_lt_m, hl_eq]
          obtain ⟨ha_3, ex_3⟩ := exec_writeHeap_auto (t := 7) (idxE := .readLocal 1 (.lit 12)) (valE := .sub (.activeRatDen (.readLocal 1 (.lit 13)) (.readLocal 1 (.lit 10))) (.lit 1)) ha_2 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by decide, by decide⟩
            (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit]; try rfl)
            hden_eval (by decide) (by positivity) (by simpa using haddr_lt_A) hcoord_b.2.2
          -- (1, 10) := c + 1
          obtain ⟨ha_4, ex_4⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 10) (valE := .add (.readLocal 1 (.lit 10)) (.lit 1)) ha_3 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
            (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit,
                  hr10_c]
                try push_cast; try ring; try rfl)
            (by decide) (by omega) (by simp; omega) (idx_V (c + 1) (by omega))
          let ws_next := ((((ws_c.write (.localFrame 1 1 12) (addr_c : ℤ)).write
            (.heap 6 (addr_c : ℤ)) (liftRatPoint (pts_h idx_j) ⟨c, Nat.lt_succ_of_lt hc⟩).num).write
            (.heap 7 (addr_c : ℤ)) (((liftRatPoint (pts_h idx_j) ⟨c, Nat.lt_succ_of_lt hc⟩).den : ℤ) - 1)).write
            (.localFrame 1 1 10) (((c + 1 : ℕ) : ℤ)))
          have hloc_ne1 : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
              ws_next.read (.localFrame 1 v idx) = ws_c.read (.localFrame 1 v idx) := by
            intro v idx hne1
            dsimp [ws_next]
            rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
              wordStore_read_write_of_ne _ (by intro h; cases h),
              wordStore_read_write_of_ne _ (by intro h; cases h),
              wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv)]
          refine ⟨ws_next, bsNext, ⟨rfl, ha_4,
            hasPhase2Regs_of_eq hregs_c (fun idx => hloc_ne1 0 idx (by decide)),
            hasLiftArrays_of_eq hlifts_c (fun v idx hv => hloc_ne1 v idx (by rcases hv with rfl | rfl <;> decide)),
            by dsimp [ws_next]; rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                 wordStore_read_write_of_ne _ (by intro h; cases h),
                 wordStore_read_write_of_ne _ (by intro h; cases h),
                 wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), hr9_c],
            wordStore_read_write_self _ _ _,
            by dsimp [ws_next]; rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                 wordStore_read_write_of_ne _ (by intro h; cases h),
                 wordStore_read_write_of_ne _ (by intro h; cases h),
                 wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), hr11_c],
            by dsimp [ws_next]; rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                 wordStore_read_write_of_ne _ (by intro h; cases h),
                 wordStore_read_write_of_ne _ (by intro h; cases h),
                 wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), hr13_c],
            fun t idx ht5 ht6 ht7 => by
              dsimp [ws_next]
              rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht7 ht),
                wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht6 ht),
                wordStore_read_write_of_ne _ (by intro h; cases h)]
              exact hht_c t idx ht5 ht6 ht7,
            fun idx => by
              dsimp [ws_next]
              rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                wordStore_read_write_of_ne _ (by intro h; cases h)]
              exact hh5_c idx,
            fun idx hrange => by
              have hne_a : idx ≠ (addr_c : ℤ) := by dsimp [addr_c]; omega
              dsimp [ws_next]
              refine ⟨?_, ?_⟩
              · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                  wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                  wordStore_read_write_of_ne _ (by intro h; cases h)]
                exact (hh67_zero_c idx (by omega)).1
              · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                  wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                  wordStore_read_write_of_ne _ (by intro h; cases h)]
                exact (hh67_zero_c idx (by omega)).2,
            fun j' hj' c' => by
              dsimp only
              have hj'_le : j' * p.D + c'.1 + 1 ≤ j * p.D := by
                have h1 : (j' + 1) * p.D ≤ j * p.D := Nat.mul_le_mul_right p.D hj'
                rw [Nat.add_mul, Nat.one_mul] at h1
                have h2 := c'.2
                omega
              have hne_a : ((j' * p.D + c'.1 + 1 : ℕ) : ℤ) ≠ (addr_c : ℤ) := by
                dsimp [addr_c, base_j]; omega
              dsimp [ws_next]
              refine ⟨?_, ?_⟩
              · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                  wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                  wordStore_read_write_of_ne _ (by intro h; cases h)]
                exact (hh67_prev_c j' hj' c').1
              · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                  wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                  wordStore_read_write_of_ne _ (by intro h; cases h)]
                exact (hh67_prev_c j' hj' c').2,
            fun c' hc' => by
              dsimp only
              have hc'_lt : c' < c + 1 := Nat.lt_of_lt_of_le hc' (Nat.min_le_left _ _)
              rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hc'_lt) with hlt | rfl
              · have hne_a : ((base_j + c' : ℕ) : ℤ) ≠ (addr_c : ℤ) := by dsimp [addr_c]; omega
                dsimp [ws_next]
                refine ⟨?_, ?_⟩
                · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                    wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                    wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                    wordStore_read_write_of_ne _ (by intro h; cases h)]
                  exact (hh67_cur_c c' (lt_min hlt (hlt.trans hc))).1
                · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                    wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_a hi),
                    wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                    wordStore_read_write_of_ne _ (by intro h; cases h)]
                  exact (hh67_cur_c c' (lt_min hlt (hlt.trans hc))).2
              · dsimp [ws_next, addr_c]
                refine ⟨?_, ?_⟩
                · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                    wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                    wordStore_read_write_self]
                · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                    wordStore_read_write_self]
                  ring⟩,
            ExecBounded.mono (ExecBounded.seq ex_1 (ExecBounded.seq ex_2 (ExecBounded.seq ex_3 ex_4)))
              (by omega) (by omega) le_rfl le_rfl⟩)
      rcases hinv_d with ⟨hbs_d_eq, ha_in, hregs_in, hlifts_in, hr9_in, _, hr11_in, hr13_in,
        hht_in, hh5_in, hh67_zero_in, hh67_prev_in, hh67_cur_in⟩
      subst bs_in
      -- 6. Stage last coordinate `c = p.d` at `addr_d := base_j + p.d`
      let addr_d : ℕ := base_j + p.d
      have haddr_d_lt : addr_d < A := by dsimp [addr_d]; omega
      have hlast_b := ratCoordBitBounded_num_den_V (B := p.B_lift) (V := V) (hlift_b (Fin.last p.d)) (by omega)
      obtain ⟨ha_l1, ex_l1⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 12) (valE := .add (.readLocal 1 (.lit 11)) (.readLocal 0 (.lit 0))) ha_in hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp only [evalVal_add, evalVal_readLocal, evalVal_lit, hr11_in, hregs_in.1.1]
            dsimp [addr_d]; try push_cast; try ring; try rfl)
        (by decide) (by omega) (by simp; omega) (idx_V addr_d (by omega))
      obtain ⟨ha_l2, ex_l2⟩ := exec_writeHeap_auto (t := 6) (idxE := .readLocal 1 (.lit 12)) (valE := .readLocal 2 (.readLocal 1 (.lit 13))) ha_l1 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit]; try rfl)
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
              hr13_in, (hlifts_in idx_j hidx_lt_m).1]; try rfl)
        (by decide) (by positivity) (by simpa using haddr_d_lt) hlast_b.1
      obtain ⟨ha_l3, ex_l3⟩ := exec_writeHeap_auto (t := 7) (idxE := .readLocal 1 (.lit 12)) (valE := .sub (.readLocal 3 (.readLocal 1 (.lit 13))) (.lit 1)) ha_l2 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit]; try rfl)
        (by simp [rw_write_eq, rf_free_eq, evalVal_sub, evalVal_readLocal, evalVal_lit,
              hr13_in, (hlifts_in idx_j hidx_lt_m).2]; try rfl)
        (by decide) (by positivity) (by simpa using haddr_d_lt) hlast_b.2.2
      obtain ⟨ha_l4, ex_l4⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .add (.readLocal 1 (.lit 9)) (.lit 1)) ha_l3 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit,
              hr9_in]
            try push_cast; try ring; try rfl)
        (by decide) (by omega) (by simp; omega) (idx_V (j + 1) (by omega))
      let ws_out := ((((ws_in.write (.localFrame 1 1 12) (addr_d : ℤ)).write
        (.heap 6 (addr_d : ℤ)) (liftRatPoint (pts_h idx_j) (Fin.last p.d)).num).write
        (.heap 7 (addr_d : ℤ)) (((liftRatPoint (pts_h idx_j) (Fin.last p.d)).den : ℤ) - 1)).write
        (.localFrame 1 1 9) (((j + 1 : ℕ) : ℤ)))
      have hloc_out : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
          ws_out.read (.localFrame 1 v idx) = ws_in.read (.localFrame 1 v idx) := by
        intro v idx hne1
        dsimp [ws_out]
        rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
          wordStore_read_write_of_ne _ (by intro h; cases h),
          wordStore_read_write_of_ne _ (by intro h; cases h),
          wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv)]
      have hstep_body :=
        ExecBounded.seq ex_d (ExecBounded.seq ex_m (ExecBounded.seq ex_b
        (ExecBounded.seq ex_c0 (ExecBounded.seq ex_in (ExecBounded.seq ex_l1
        (ExecBounded.seq ex_l2 (ExecBounded.seq ex_l3 ex_l4)))))))
      have hb_draw : 64 * (p.W₁ M + 16) ^ 2 ≤ 256 * (V + 8) ^ 2 := by
        have h1 : p.W₁ M + 16 ≤ 2 * (V + 8) := by omega
        calc 64 * (p.W₁ M + 16) ^ 2 ≤ 64 * (2 * (V + 8)) ^ 2 :=
              Nat.mul_le_mul_left 64 (Nat.pow_le_pow_left h1 2)
          _ = 256 * (V + 8) ^ 2 := by ring
      have hb_outer :
          64 * (p.W₁ M + 16) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 +
          (66000 * (V + 8) ^ 2 + ((66000 * (V + 8) ^ 2 + p.d * (300000 * (V + 8) ^ 2)) +
          (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2))))))) ≤
          (850000 + 300000 * p.d) * (V + 8) ^ 2 := by
        set Y := (V + 8) ^ 2
        have h1 : (850000 + 300000 * p.d) * Y = 850000 * Y + p.d * (300000 * Y) := by ring
        omega
      refine ⟨ws_out, bsNext, ⟨rfl, ha_l4,
        hasPhase2Regs_of_eq hregs_in (fun idx => hloc_out 0 idx (by decide)),
        hasLiftArrays_of_eq hlifts_in (fun v idx hv => hloc_out v idx (by rcases hv with rfl | rfl <;> decide)),
        wordStore_read_write_self _ _ _,
        fun t idx ht5 ht6 ht7 => by
          dsimp [ws_out]
          rw [wordStore_read_write_of_ne _ (by intro h; cases h),
            wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht7 ht),
            wordStore_read_write_of_ne _ (by intro h; injection h with ht _; exact ht6 ht),
            wordStore_read_write_of_ne _ (by intro h; cases h)]
          exact hht_in t idx ht5 ht6 ht7,
        fun idx => by
          dsimp [ws_out]
          rw [wordStore_read_write_of_ne _ (by intro h; cases h),
            wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
            wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
            wordStore_read_write_of_ne _ (by intro h; cases h)]
          exact hh5_in idx,
        fun idx hrange => by
          have hjp1 : (j + 1) * p.D = addr_d := by
            dsimp [addr_d, base_j, CoreParams.D]; ring
          have hne_ad : idx ≠ (addr_d : ℤ) := by omega
          dsimp [ws_out]
          refine ⟨?_, ?_⟩
          · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
              wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
              wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
              wordStore_read_write_of_ne _ (by intro h; cases h)]
            exact (hh67_zero_in idx (by dsimp [addr_d] at hjp1; omega)).1
          · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
              wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
              wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
              wordStore_read_write_of_ne _ (by intro h; cases h)]
            exact (hh67_zero_in idx (by dsimp [addr_d] at hjp1; omega)).2,
        fun j' hj' c' => by
          dsimp only
          have hj'_lt : j' < j + 1 := Nat.lt_of_lt_of_le hj' (Nat.min_le_left _ _)
          rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hj'_lt) with hlt | hjeq
          · have hj'_le : j' * p.D + c'.1 + 1 ≤ j * p.D := by
              have h1 : (j' + 1) * p.D ≤ j * p.D := Nat.mul_le_mul_right p.D hlt
              rw [Nat.add_mul, Nat.one_mul] at h1
              have h2 := c'.2
              omega
            have hne_ad : ((j' * p.D + c'.1 + 1 : ℕ) : ℤ) ≠ (addr_d : ℤ) := by
              dsimp [addr_d, base_j]; omega
            dsimp [ws_out]
            refine ⟨?_, ?_⟩
            · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
                wordStore_read_write_of_ne _ (by intro h; cases h)]
              exact (hh67_prev_in j' hlt c').1
            · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; exact hne_ad hi),
                wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                wordStore_read_write_of_ne _ (by intro h; cases h)]
              exact (hh67_prev_in j' hlt c').2
          · subst j'
            have hc'_le : c'.1 ≤ p.d := by
              have := c'.2; dsimp [CoreParams.D] at this; omega
            rcases Nat.lt_or_eq_of_le hc'_le with hclt | hceq
            · have hne_ad : ((j * p.D + c'.1 + 1 : ℕ) : ℤ) ≠ (addr_d : ℤ) := by
                dsimp [addr_d, base_j]; omega
              have ha_eq : ((j * p.D + c'.1 + 1 : ℕ) : ℤ) = ((base_j + c'.1 : ℕ) : ℤ) := by
                dsimp [base_j]; push_cast; ring
              dsimp [ws_out]
              refine ⟨?_, ?_⟩
              · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                  wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; omega),
                  wordStore_read_write_of_ne _ (by intro h; cases h)]
                convert (hh67_cur_in c'.1 (lt_min hclt hclt)).1 using 2
                dsimp [base_j]; push_cast; ring
              · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                  wordStore_read_write_of_ne _ (by intro h; injection h with _ hi; omega),
                  wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                  wordStore_read_write_of_ne _ (by intro h; cases h)]
                convert (hh67_cur_in c'.1 (lt_min hclt hclt)).2 using 3
                dsimp [base_j]; push_cast; ring
            · have hc_last : c' = Fin.last p.d := by ext; exact hceq
              subst hc_last
              dsimp [ws_out]
              have ha_eq2 : ((j * p.D + (Fin.last p.d).1 + 1 : ℕ) : ℤ) = (addr_d : ℤ) := by
                dsimp [addr_d, base_j, Fin.last]; push_cast; ring
              have ha_eq3 : (j : ℤ) * (p.D : ℤ) + (p.d : ℤ) + 1 = (addr_d : ℤ) := by
                dsimp [addr_d, base_j]; push_cast; ring
              try rw [ha_eq2]
              try rw [ha_eq3]
              refine ⟨?_, ?_⟩
              · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                  wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                  wordStore_read_write_self]
              · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
                  wordStore_read_write_self]
                ring⟩,
        ExecBounded.mono hstep_body (by omega) hb_outer le_rfl le_rfl⟩)
  rcases hinv_M with ⟨hbs_M, ha_M, hregs_M, hlifts_M, _, hht_M, hh5_M, hh67_zero_M, hh67_all⟩
  rw [blockBitStream_self] at hbs_M
  subst hbs_M
  have hstage : SimStageMatches true p.d p.D V wsStaged sampleInp := by
    refine ⟨ha_M.1, by omega, hd_V, ?_⟩
    rw [if_pos rfl]
    refine ⟨rfl, rfl, M, hM1, hM_V, rfl, hh5_M 2, hh5_M,
      (hh67_zero_M 0 (Or.inl (by omega))).1,
      (hh67_zero_M 0 (Or.inl (by omega))).2, ?_⟩
    intro j hj c
    dsimp [sampleInp]
    rw [dif_pos hj]
    exact hh67_all j (lt_min hj hj) c
  have hh5_zero : ∀ idx : ℤ, idx ≠ 0 → idx ≠ 1 → idx ≠ 2 → wsStaged.read (.heap 5 idx) = 0 := by
    intro idx h0 h1 h2
    rw [hh5_M idx]
    unfold listGetIntD
    by_cases hn : 0 ≤ idx
    · rw [if_pos hn]
      have hge3 : 3 ≤ idx.toNat := by omega
      have hnone : ([(p.B_lift : ℤ), (p.k_φ : ℤ), (M : ℤ)][idx.toNat]?) = none :=
        List.getElem?_eq_none (by simp; omega)
      simp [List.getD, hnone]
    · rw [if_neg hn]
  have ex_tot := ExecBounded.seq ex_s1 (ExecBounded.seq ex_s2 (ExecBounded.seq ex_s3
    (ExecBounded.seq ex_s4 ex_loop)))
  have hb_tot :
      66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 +
      (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + M * ((850000 + 300000 * p.d) * (V + 8) ^ 2))))) ≤
      (400000 + M * (900000 + 300000 * p.d)) * (V + 8) ^ 2 := by
    set Y := (V + 8) ^ 2
    have h1 : M * ((850000 + 300000 * p.d) * Y) ≤ M * ((900000 + 300000 * p.d) * Y) :=
      Nat.mul_le_mul_left M (Nat.mul_le_mul_right Y (by omega))
    have h2 : (400000 + M * (900000 + 300000 * p.d)) * Y =
        400000 * Y + M * ((900000 + 300000 * p.d) * Y) := by ring
    omega
  have hu_m : M * (800 + 300 * p.d + 24 * (p.W₁ M + 1)) ≤ M * (900 + 300 * p.d + 24 * (p.W₁ M + 1)) :=
    Nat.mul_le_mul_left M (by omega)
  exact ⟨wsStaged, ha_M, hregs_M, hlifts_M, hstage, hht_M, hh5_zero, hh67_zero_M,
    ExecBounded.mono ex_tot (by omega) hb_tot le_rfl le_rfl⟩

/-! ### 4. Execution of `phase3UnstageStmt` -/

theorem exec_phase3UnstageStmt {A V M : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ)
    {inp : BitRAMInput p.d} {ws₀ : WordStore} {bs : List Bool}
    (harena : InAttemptArena A V ws₀)
    (hregs : HasPhase2Regs p M ws₀)
    (hlifts : HasLiftArrays p pts_h ws₀)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hMDA : M * p.D + 4 ≤ A)
    (hht : ∀ t idx, t ≠ 5 → t ≠ 6 → t ≠ 7 → ws₀.read (.heap t idx) = 0)
    (hh5 : ∀ idx : ℤ, idx ≠ 0 → idx ≠ 1 → idx ≠ 2 → ws₀.read (.heap 5 idx) = 0)
    (hh67 : ∀ idx : ℤ, (idx < 1 ∨ ((M * p.D : ℕ) : ℤ) < idx) →
      ws₀.read (.heap 6 idx) = 0 ∧ ws₀.read (.heap 7 idx) = 0) :
    ∃ ws₁ : WordStore,
      InAttemptArena A V ws₁ ∧
      HeapAllZero ws₁ ∧
      HasPhase2Regs p M ws₁ ∧
      HasLiftArrays p pts_h ws₁ ∧
      (∀ idx : ℤ, ws₁.read (.localFrame 1 4 idx) = ws₀.read (.localFrame 1 4 idx)) ∧
      ExecBounded inp phase3UnstageStmt ws₀ bs ws₁ bs
        (500 + 250 * (M * p.D))
        ((500000 + 250000 * (M * p.D)) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have h16A := hfit.2.2.2.2.1
  have hVA := hfit.2.2.2.2.2.2.1
  have hV16 : 16 ≤ V := by omega
  have idx_V : ∀ k : ℕ, k ≤ A → intBitLength (k : ℤ) ≤ V := by
    intro k hk
    have h1 := intBitLength_natCast_le_succ k
    have h2 := natBitLength_mono hk
    omega
  obtain ⟨ha_1, ex_1⟩ := exec_freeHeap_auto (t := 5) (idxE := .lit 0) harena hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide) (evalVal_lit _ _ _)
    (by decide) (by omega) (by simp; omega)
  obtain ⟨ha_2, ex_2⟩ := exec_freeHeap_auto (t := 5) (idxE := .lit 1) ha_1 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide) (evalVal_lit _ _ _)
    (by decide) (by omega) (by simp; omega)
  obtain ⟨ha_3, ex_3⟩ := exec_freeHeap_auto (t := 5) (idxE := .lit 2) ha_2 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide) (evalVal_lit _ _ _)
    (by decide) (by omega) (by simp; omega)
  obtain ⟨ha_4, ex_4⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .lit 1) ha_3 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _) (by decide) (by omega) (by simp; omega) (idx_V 1 (by omega))
  obtain ⟨ha_5, ex_5⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 10) (valE := .mul (.readLocal 0 (.lit 11)) (.readLocal 0 (.lit 1))) ha_4 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
    (by simp [rw_write_eq, rf_free_eq, evalVal_mul, evalVal_readLocal, evalVal_lit,
          hregs.2.1, hregs.1.2.1]
        try push_cast; try ring; try rfl)
    (by decide) (by omega) (by simp; omega) (idx_V (M * p.D) (by omega))
  let Inv (k : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
    bs_c = bs ∧
    InAttemptArena A V ws ∧
    HasPhase2Regs p M ws ∧
    HasLiftArrays p pts_h ws ∧
    (∀ idx : ℤ, ws.read (.localFrame 1 4 idx) = ws₀.read (.localFrame 1 4 idx)) ∧
    ws.read (.localFrame 1 1 9) = (((k + 1 : ℕ) : ℤ)) ∧
    (∀ t idx, t ≠ 6 → t ≠ 7 → ws.read (.heap t idx) = 0) ∧
    (∀ idx : ℤ, (idx < ((k + 1 : ℕ) : ℤ) ∨ ((M * p.D : ℕ) : ℤ) < idx) →
      ws.read (.heap 6 idx) = 0 ∧ ws.read (.heap 7 idx) = 0)
  have hinit : Inv 0 (wsOf ha_5) bs := by
    have hloc_ne1 : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
        (((((ws₀.free (.heap 5 0)).free (.heap 5 1)).free (.heap 5 2)).write
          (.localFrame 1 1 9) 1).write (.localFrame 1 1 10) ((M * p.D : ℕ) : ℤ)).read (.localFrame 1 v idx) =
        ws₀.read (.localFrame 1 v idx) := by
      intro v idx hne1
      rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
        wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
        wordStore_read_free_of_ne _ (by intro h; cases h),
        wordStore_read_free_of_ne _ (by intro h; cases h),
        wordStore_read_free_of_ne _ (by intro h; cases h)]
    refine ⟨rfl, ha_5,
      hasPhase2Regs_of_eq hregs (fun idx => hloc_ne1 0 idx (by decide)),
      hasLiftArrays_of_eq hlifts (fun v idx hv => hloc_ne1 v idx (by rcases hv with rfl | rfl <;> decide)),
      fun idx => hloc_ne1 4 idx (by decide),
      by rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_self]; rfl,
      fun t idx ht6 ht7 => ?_,
      fun idx hrange => ?_⟩
    · rw [wordStore_read_write_of_ne _ (by intro h; cases h),
        wordStore_read_write_of_ne _ (by intro h; cases h)]
      by_cases ht5 : t = 5
      · subst ht5
        by_cases h2 : idx = 2
        · subst h2; exact wordStore_read_free_self _ _
        · rw [wordStore_read_free_of_ne _ (by intro h; injection h with _ hi; exact h2 hi)]
          by_cases h1 : idx = 1
          · subst h1; exact wordStore_read_free_self _ _
          · rw [wordStore_read_free_of_ne _ (by intro h; injection h with _ hi; exact h1 hi)]
            by_cases h0 : idx = 0
            · subst h0; exact wordStore_read_free_self _ _
            · rw [wordStore_read_free_of_ne _ (by intro h; injection h with _ hi; exact h0 hi)]
              exact hh5 idx h0 h1 h2
      · rw [wordStore_read_free_of_ne _ (by intro h; injection h with ht _; exact ht5 ht),
          wordStore_read_free_of_ne _ (by intro h; injection h with ht _; exact ht5 ht),
          wordStore_read_free_of_ne _ (by intro h; injection h with ht _; exact ht5 ht)]
        exact hht t idx ht5 ht6 ht7
    · simp [rw_write_eq, rf_free_eq]
      exact hh67 idx (by simpa using hrange)
  obtain ⟨ws₁, bs₁, hinv_end, ex_loop⟩ := exec_repeatN_inv (countE := .readLocal 1 (.lit 10)) (body := .seq (.freeHeap 6 (.readLocal 1 (.lit 9))) (.seq (.freeHeap 7 (.readLocal 1 (.lit 9))) (.writeLocal 1 (.lit 9) (.add (.readLocal 1 (.lit 9)) (.lit 1))))) (M * p.D) Inv
    ha_5 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit]; try rfl)
    hinit (U := 220) (B := 210000 * (V + 8) ^ 2)
    (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
    (fun k ws_k bs_k hk ⟨hbs_k, ha_k, hregs_k, hlifts_k, hz4_k, hr9_k, hht_k, hh67_k⟩ => by
      subst bs_k
      have hk1_lt : k + 1 < A := by omega
      obtain ⟨ha_f6, ex_f6⟩ := exec_freeHeap_auto (t := 6) (idxE := .readLocal 1 (.lit 9)) ha_k hinp
        (exprInArena_small (by decide) (by decide) hV16) (by decide)
        (by simp only [evalVal_readLocal, evalVal_lit, hr9_k]; try rfl)
        (by decide) (by positivity) (by simpa using hk1_lt)
      obtain ⟨ha_f7, ex_f7⟩ := exec_freeHeap_auto (t := 7) (idxE := .readLocal 1 (.lit 9)) ha_f6 hinp
        (exprInArena_small (by decide) (by decide) hV16) (by decide)
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
              hr9_k]; try rfl)
        (by decide) (by positivity) (by simpa using hk1_lt)
      obtain ⟨ha_inc, ex_inc⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .add (.readLocal 1 (.lit 9)) (.lit 1)) ha_f7 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit,
              hr9_k]
            try push_cast; try ring; try rfl)
        (by decide) (by omega) (by simp; omega) (idx_V (k + 2) (by omega))
      let ws_next := ((ws_k.free (.heap 6 (((k + 1 : ℕ) : ℤ)))).free
        (.heap 7 (((k + 1 : ℕ) : ℤ)))).write (.localFrame 1 1 9) (((k + 2 : ℕ) : ℤ))
      have hloc_ne1 : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 →
          ws_next.read (.localFrame 1 v idx) = ws_k.read (.localFrame 1 v idx) := by
        intro v idx hne1
        dsimp [ws_next]
        rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
          wordStore_read_free_of_ne _ (by intro h; cases h),
          wordStore_read_free_of_ne _ (by intro h; cases h)]
      refine ⟨ws_next, bs, ⟨rfl, ha_inc,
        hasPhase2Regs_of_eq hregs_k (fun idx => hloc_ne1 0 idx (by decide)),
        hasLiftArrays_of_eq hlifts_k (fun v idx hv => hloc_ne1 v idx (by rcases hv with rfl | rfl <;> decide)),
        fun idx => (hloc_ne1 4 idx (by decide)).trans (hz4_k idx),
        wordStore_read_write_self _ _ _,
        fun t idx ht6 ht7 => by
          dsimp [ws_next]
          rw [wordStore_read_write_of_ne _ (by intro h; cases h),
            wordStore_read_free_of_ne _ (by intro h; injection h with ht _; exact ht7 ht),
            wordStore_read_free_of_ne _ (by intro h; injection h with ht _; exact ht6 ht)]
          exact hht_k t idx ht6 ht7,
        fun idx hrange => by
          dsimp [ws_next]
          rw [wordStore_read_write_of_ne _ (by intro h; cases h),
            wordStore_read_write_of_ne _ (by intro h; cases h)]
          by_cases heq : idx = (((k + 1 : ℕ) : ℤ))
          · subst heq
            push_cast
            exact ⟨by rw [wordStore_read_free_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_free_self],
                   wordStore_read_free_self _ _⟩
          · refine ⟨?_, ?_⟩
            · rw [wordStore_read_free_of_ne _ (by intro h_ne; injection h_ne; try omega),
                wordStore_read_free_of_ne _ (by intro h; injection h with _ hi; exact heq hi)]
              exact (hh67_k idx (by omega)).1
            · rw [wordStore_read_free_of_ne _ (by intro h; injection h with _ hi; exact heq hi),
                wordStore_read_free_of_ne _ (by intro h_ne; injection h_ne; try omega)]
              exact (hh67_k idx (by omega)).2⟩,
        ExecBounded.mono (ExecBounded.seq ex_f6 (ExecBounded.seq ex_f7 ex_inc))
          (by omega) (by omega) le_rfl le_rfl⟩)
  rcases hinv_end with ⟨hbs_end_eq, ha_end, hregs_end, hlifts_end, hz4_end, _, hht_end, hh67_end⟩
  subst bs₁
  have hhz_end : HeapAllZero ws₁ := by
    intro t idx
    by_cases ht6 : t = 6
    · subst ht6; exact (hh67_end idx (by omega)).1
    · by_cases ht7 : t = 7
      · subst ht7; exact (hh67_end idx (by omega)).2
      · exact hht_end t idx ht6 ht7
  have ex_tot := ExecBounded.seq ex_1 (ExecBounded.seq ex_2 (ExecBounded.seq ex_3
    (ExecBounded.seq ex_4 (ExecBounded.seq ex_5 ex_loop))))
  have hb_tot :
      66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 +
      (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 +
      M * p.D * (210000 * (V + 8) ^ 2)))))) ≤
      (500000 + 250000 * (M * p.D)) * (V + 8) ^ 2 := by
    set Y := (V + 8) ^ 2
    have h1 : M * p.D * (210000 * Y) ≤ M * p.D * (250000 * Y) :=
      Nat.mul_le_mul_left (M * p.D) (Nat.mul_le_mul_right Y (by omega))
    have h2 : (500000 + 250000 * (M * p.D)) * Y = 500000 * Y + M * p.D * (250000 * Y) := by ring
    omega
  exact ⟨ws₁, ha_end, hhz_end, hregs_end, hlifts_end, hz4_end,
    ExecBounded.mono ex_tot (by omega) hb_tot le_rfl le_rfl⟩

/-! ### 5. Execution of `phase3ReduceStmt` and combined `phase3Stmt` -/

theorem exec_phase3ReduceStmt {A V M : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ) (zRat : Fin p.D → ℚ)
    {inp : BitRAMInput p.d} {ws₀ : WordStore} {bs : List Bool}
    (harena : InAttemptArena A V ws₀)
    (hhz : HeapAllZero ws₀)
    (hregs : HasPhase2Regs p M ws₀)
    (hlifts : HasLiftArrays p pts_h ws₀)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hLzV : 2 * p.L_z + 16 ≤ V)
    (hz_raw : ∀ c : Fin p.D,
      let zNum := ws₀.read (.localFrame 1 4 (2 * (c.1 : ℤ)))
      let zDen := ws₀.read (.localFrame 1 4 (2 * (c.1 : ℤ) + 1))
      0 < zDen ∧ zRat c = (zNum : ℚ) / (zDen : ℚ) ∧
      intBitLength zNum ≤ p.L_z ∧ intBitLength zDen ≤ p.L_z) :
    ∃ ws₁ : WordStore,
      InAttemptArena A V ws₁ ∧
      HeapAllZero ws₁ ∧
      HasPhase2Regs p M ws₁ ∧
      HasLiftArrays p pts_h ws₁ ∧
      HasZArray p.D zRat ws₁ ∧
      ExecBounded inp phase3ReduceStmt ws₀ bs ws₁ bs
        (300 + p.D * (800 + 50 * p.L_z))
        ((300000 + p.D * (800000 + 600 * p.L_z)) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  have h16A := hfit.2.2.2.2.1
  have hmA := hfit.2.2.2.2.2.1
  have hVA := hfit.2.2.2.2.2.2.1
  have h2Lz_V := hfit.2.2.2.2.2.2.2.2.2.2.2.1
  have hV16 : 16 ≤ V := by omega
  have idx_V : ∀ k : ℕ, k ≤ A → intBitLength (k : ℤ) ≤ V := by
    intro k hk
    have h1 := intBitLength_natCast_le_succ k
    have h2 := natBitLength_mono hk
    omega
  obtain ⟨ha_1, ex_1⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 5) (valE := .readLocal 0 (.lit 10)) harena hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) hregs.1.2.2.2.2.2.2.2.2.2.2.1
    (by decide) (by omega) (by simp; omega) h2Lz_V
  obtain ⟨ha_2, ex_2⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .lit 0) ha_1 hinp
    (exprInArena_small (by decide) (by decide) hV16)
    (exprInArena_small (by decide) (by decide) hV16)
    ⟨by decide, by decide⟩ (evalVal_lit _ _ _) (evalVal_lit _ _ _) (by decide) (by omega) (by simp; omega) (idx_V 0 (by omega))
  let Inv (c : ℕ) (ws : WordStore) (bs_c : List Bool) : Prop :=
    bs_c = bs ∧
    InAttemptArena A V ws ∧
    HeapAllZero ws ∧
    HasPhase2Regs p M ws ∧
    HasLiftArrays p pts_h ws ∧
    ws.read (.localFrame 1 1 5) = ((2 * p.L_z : ℕ) : ℤ) ∧
    ws.read (.localFrame 1 1 9) = (c : ℤ) ∧
    (∀ (k : ℕ) (hk : k < min c p.D),
      ws.read (.localFrame 1 4 (2 * (k : ℤ))) = (zRat ⟨k, Nat.lt_of_lt_of_le hk (Nat.min_le_right c p.D)⟩).num ∧
      ws.read (.localFrame 1 4 (2 * (k : ℤ) + 1)) = ((zRat ⟨k, Nat.lt_of_lt_of_le hk (Nat.min_le_right c p.D)⟩).den : ℤ)) ∧
    (∀ (k : ℕ), c ≤ k → k < p.D →
      ws.read (.localFrame 1 4 (2 * (k : ℤ))) = ws₀.read (.localFrame 1 4 (2 * (k : ℤ))) ∧
      ws.read (.localFrame 1 4 (2 * (k : ℤ) + 1)) = ws₀.read (.localFrame 1 4 (2 * (k : ℤ) + 1)))
  have hinit : Inv 0 (wsOf ha_2) bs := by
    refine ⟨rfl, ha_2,
      heapAllZero_write_local (heapAllZero_write_local hhz 1 1 5 _) 1 1 9 0,
      hasPhase2Regs_of_eq hregs (fun idx => by
        rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega)]),
      hasLiftArrays_of_eq hlifts (fun v idx hv => by
        have hne1 : v ≠ 1 := by rcases hv with rfl | rfl <;> decide
        rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv' _; exact hne1 hv'),
          wordStore_read_write_of_ne _ (by intro h; injection h with _ hv' _; exact hne1 hv')]),
      by rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_self],
      wordStore_read_write_self _ _ _,
      fun _ hk => absurd hk (by omega),
      fun k _ _ => ⟨by rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega)],
                    by rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega)]⟩⟩
  obtain ⟨ws₁, bs₁, hinv_D, ex_loop⟩ := exec_repeatN_inv (countE := .readLocal 0 (.lit 1)) (body := phase3ReduceBody) p.D Inv
    ha_2 hinp (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit, hregs.1.2.1]; try rfl)
    hinit (U := 750 + 50 * p.L_z) (B := (750000 + 600 * p.L_z) * (V + 8) ^ 2)
    (C := arenaCellCap inp A) (S := arenaBitCap inp A V)
    (fun c ws_c bs_c hc ⟨hbs_c, ha_c, hhz_c, hregs_c, hlifts_c, hr5_c, hr9_c, hdone_c, hrem_c⟩ => by
      subst bs_c
      have h2c_lt : 2 * c + 1 < A := by omega
      let zNum := ws₀.read (.localFrame 1 4 (2 * (c : ℤ)))
      let zDen := ws₀.read (.localFrame 1 4 (2 * (c : ℤ) + 1))
      obtain ⟨hz_pos, hz_eq, hzn_ib, hzd_ib⟩ :
        0 < zDen ∧ zRat ⟨c, hc⟩ = (zNum : ℚ) / (zDen : ℚ) ∧
        intBitLength zNum ≤ p.L_z ∧ intBitLength zDen ≤ p.L_z := hz_raw ⟨c, hc⟩
      obtain ⟨hcur_n, hcur_d⟩ := hrem_c c le_rfl hc
      -- 1. (1, 10) := 2 * c
      obtain ⟨ha_s1, ex_s1⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 10) (valE := .mul (.lit 2) (.readLocal 1 (.lit 9)))
        (idx := 10) (val := 2 * (c : ℤ)) ha_c hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp only [evalVal_mul, evalVal_readLocal, evalVal_lit, hr9_c]; try ring)
        (by decide) (by omega) (by simp; omega)
        (by have h_eq : (2 * (c : ℤ)) = ((2 * c : ℕ) : ℤ) := by { push_cast; ring }; rw [h_eq]; exact idx_V (2 * c) (by omega))
      -- 2. (1, 13) := 2 * c + 1
      obtain ⟨ha_s2, ex_s2⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 13) (valE := .add (.readLocal 1 (.lit 10)) (.lit 1))
        (idx := 13) (val := 2 * (c : ℤ) + 1) ha_s1 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit])
        (by decide) (by omega) (by simp; omega)
        (by have h_eq : (2 * (c : ℤ) + 1) = ((2 * c + 1 : ℕ) : ℤ) := by { push_cast; ring }; rw [h_eq]; exact idx_V (2 * c + 1) (by omega))
      -- 3. (1, 11) := zNum
      obtain ⟨ha_s3, ex_s3⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 11) (valE := .readLocal 4 (.readLocal 1 (.lit 10)))
        (idx := 11) (val := zNum) ha_s2 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit, hcur_n]; rfl)
        (by decide) (by omega) (by simp; omega) (hzn_ib.trans (by omega))
      -- 4. (1, 12) := zDen
      obtain ⟨ha_s4, ex_s4⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 12) (valE := .readLocal 4 (.readLocal 1 (.lit 13)))
        (idx := 12) (val := zDen) ha_s3 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit, hcur_d]; rfl)
        (by decide) (by omega) (by simp; omega) (hzd_ib.trans (by omega))
      -- 5. ite (zNum < 0) ((1, 6) := -zNum) ((1, 6) := zNum) -> (1, 6) = (zNum.natAbs : ℤ)
      let ws_pre_ite := (((ws_c.write (.localFrame 1 1 10) (2 * (c : ℤ))).write
        (.localFrame 1 1 13) (2 * (c : ℤ) + 1)).write
        (.localFrame 1 1 11) zNum).write (.localFrame 1 1 12) zDen
      have ha_abs_ib : intBitLength ((zNum.natAbs : ℕ) : ℤ) ≤ V := by
        have h1 := natBitLength_natAbs_le_of_intBitLength_le hzn_ib
        have h2 := intBitLength_natCast_le_succ zNum.natAbs
        omega
      have hc_cond : CondInArena V (.intLt (.readLocal 1 (.lit 11)) (.lit 0)) :=
        ⟨exprInArena_small (by decide) (by decide) hV16, exprInArena_small (by decide) (by decide) hV16⟩
      have hc_eval : evalCondVal inp ws_pre_ite (.intLt (.readLocal 1 (.lit 11)) (.lit 0)) = decide (zNum < 0) := by
        dsimp [ws_pre_ite]
        simp [rw_write_eq, rf_free_eq, evalCondVal_intLt, evalVal_readLocal, evalVal_lit]
      have hite_branch :
          InAttemptArena A V (ws_pre_ite.write (.localFrame 1 1 6) ((zNum.natAbs : ℕ) : ℤ)) ∧
          ExecBounded inp
            (if decide (zNum < 0) then
              .writeLocal 1 (.lit 6) (.neg (.readLocal 1 (.lit 11)))
            else
              .writeLocal 1 (.lit 6) (.readLocal 1 (.lit 11)))
            ws_pre_ite bs
            (ws_pre_ite.write (.localFrame 1 1 6) ((zNum.natAbs : ℕ) : ℤ)) bs
            68 (66000 * (V + 8) ^ 2) (arenaCellCap inp A) (arenaBitCap inp A V) := by
        by_cases hlt0 : zNum < 0
        · rw [if_pos (decide_eq_true hlt0)]
          have hneg : -zNum = ((zNum.natAbs : ℕ) : ℤ) := by omega
          exact exec_writeLocal_auto (var := 1) (idxE := .lit 6) (valE := .neg (.readLocal 1 (.lit 11)))
            (idx := 6) (val := ((zNum.natAbs : ℕ) : ℤ)) ha_s4 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
            (by rw [evalVal_neg, evalVal_readLocal, evalVal_lit]; dsimp [ws_pre_ite]
                rw [wordStore_read_write_of_ne _ (by decide), wordStore_read_write_self]; exact hneg)
            (by decide) (by omega) (by simp; omega) ha_abs_ib
        · simp only [decide_eq_false hlt0, Bool.false_eq_true, ↓reduceIte]
          have hnonneg : zNum = ((zNum.natAbs : ℕ) : ℤ) := by omega
          exact exec_writeLocal_auto (var := 1) (idxE := .lit 6) (valE := .readLocal 1 (.lit 11))
            (idx := 6) (val := ((zNum.natAbs : ℕ) : ℤ)) ha_s4 hinp
            (exprInArena_small (by decide) (by decide) hV16)
            (exprInArena_small (by decide) (by decide) hV16)
            ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
            (by rw [evalVal_readLocal, evalVal_lit]; dsimp [ws_pre_ite]
                rw [wordStore_read_write_of_ne _ (by decide), wordStore_read_write_self]; exact hnonneg)
            (by decide) (by omega) (by simp; omega) ha_abs_ib
      have ha_s5 := hite_branch.1
      have ex_s5 := exec_ite_auto (cond := .intLt (.readLocal 1 (.lit 11)) (.lit 0)) ha_s4 hinp hc_cond (by decide) hc_eval hite_branch.2
      -- 6. (1, 7) := zDen (= (zDen.natAbs : ℤ))
      have hden_nat : zDen = ((zDen.natAbs : ℕ) : ℤ) := by omega
      obtain ⟨ha_s6, ex_s6⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 7) (valE := .readLocal 1 (.lit 12))
        (idx := 7) (val := ((zDen.natAbs : ℕ) : ℤ)) ha_s5 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by rw [evalVal_readLocal, evalVal_lit]; dsimp [ws_pre_ite]
            rw [wordStore_read_write_of_ne _ (by decide), wordStore_read_write_self]
            exact hden_nat)
        (by decide) (by omega) (by simp; omega) (by rw [← hden_nat]; exact hzd_ib.trans (by omega))
      -- 7. gcdLoopStmt 5 6 7 8
      have hab_len : natBitLength (max zNum.natAbs zDen.natAbs) + 2 ≤ p.L_z + 4 := by
        have h1 := natBitLength_natAbs_le_of_intBitLength_le hzn_ib
        have h2 := natBitLength_natAbs_le_of_intBitLength_le hzd_ib
        rcases le_total zNum.natAbs zDen.natAbs with hle | hle
        · rw [max_eq_right hle]; omega
        · rw [max_eq_left hle]; omega
      obtain ⟨ws_g, ha_g, hr6_g, _, hoth_g, ex_g⟩ :=
        exec_gcdLoopStmt (inp := inp) (bs := bs)
          (N := 2 * p.L_z) (a₀ := zNum.natAbs) (b₀ := zDen.natAbs) (L_ab := p.L_z + 4)
          (nIdx := 5) (aIdx := 6) (bIdx := 7) (tmpIdx := 8)
          ha_s6 ⟨by decide, by decide, by decide, by decide, by decide, by decide⟩
          ⟨by omega, by omega, by omega, by omega, by omega, by omega, by omega, by omega, h16A⟩
          (by dsimp [ws_pre_ite]; simp [rw_write_eq, rf_free_eq, hr5_c]; try rfl)
          (by rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_self])
          (wordStore_read_write_self _ _ _)
          hab_len (by omega)
      -- Apply `reduceRatPair_spec`
      have hden_lt_pow : zDen.natAbs < 2 ^ p.L_z :=
        natAbs_lt_two_pow_of_intBitLength (by omega) hzd_ib
      have hred := reduceRatPair_spec hz_pos hden_lt_pow hz_eq
      dsimp [reduceRatPair] at hred
      injection hred with hnum_red hden_red
      set g : ℕ := (gcdStep^[2 * p.L_z] (zNum.natAbs, zDen.natAbs)).1
      have hzn_red_ib : intBitLength ((zRat ⟨c, hc⟩).num) ≤ V := by
        rw [← hnum_red]
        have := intBitLength_ediv_le zNum (g : ℤ)
        omega
      have hzd_red_ib : intBitLength (((zRat ⟨c, hc⟩).den : ℤ)) ≤ V := by
        rw [← hden_red]
        have := intBitLength_ediv_le zDen (g : ℤ)
        omega
      -- 8. var 4 [2 * c] := zNum / g
      have hr10_g : ws_g.read (.localFrame 1 1 10) = 2 * (c : ℤ) := by
        rw [hoth_g _ (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega)]
        dsimp [ws_pre_ite]
        simp [rw_write_eq, rf_free_eq]
      have hr13_g : ws_g.read (.localFrame 1 1 13) = 2 * (c : ℤ) + 1 := by
        rw [hoth_g _ (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega)]
        dsimp [ws_pre_ite]
        simp [rw_write_eq, rf_free_eq]
      have hr11_g : ws_g.read (.localFrame 1 1 11) = zNum := by
        rw [hoth_g _ (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega)]
        dsimp [ws_pre_ite]
        simp [rw_write_eq, rf_free_eq]
      have hr12_g : ws_g.read (.localFrame 1 1 12) = zDen := by
        rw [hoth_g _ (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega)]
        dsimp [ws_pre_ite]
        simp [rw_write_eq, rf_free_eq]
      obtain ⟨ha_s8, ex_s8⟩ := exec_writeLocal_auto (var := 4) (idxE := .readLocal 1 (.lit 10)) (valE := .div (.readLocal 1 (.lit 11)) (.readLocal 1 (.lit 6))) ha_g hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩
        (by simp only [evalVal_readLocal, evalVal_lit, hr10_g]; try rfl)
        (by simp only [evalVal_div, evalVal_readLocal, evalVal_lit, hr11_g, hr6_g, hnum_red]; try rfl)
        (by decide) (by omega) (by omega) hzn_red_ib
      -- 9. var 4 [2 * c + 1] := zDen / g
      obtain ⟨ha_s9, ex_s9⟩ := exec_writeLocal_auto (var := 4) (idxE := .readLocal 1 (.lit 13)) (valE := .div (.readLocal 1 (.lit 12)) (.readLocal 1 (.lit 6))) ha_s8 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩
        (by simp [rw_write_eq, rf_free_eq, evalVal_readLocal, evalVal_lit,
              hr13_g]; try rfl)
        (by simp [rw_write_eq, rf_free_eq, evalVal_div, evalVal_readLocal, evalVal_lit,
              hr12_g, hr6_g, hden_red]; try rfl)
        (by decide) (by omega) (by omega) hzd_red_ib
      -- 10. (1, 9) := c + 1
      have hr9_g : ws_g.read (.localFrame 1 1 9) = (c : ℤ) := by
        rw [hoth_g _ (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega)]
        dsimp [ws_pre_ite]
        simp [rw_write_eq, rf_free_eq, hr9_c]
      obtain ⟨ha_s10, ex_s10⟩ := exec_writeLocal_auto (var := 1) (idxE := .lit 9) (valE := .add (.readLocal 1 (.lit 9)) (.lit 1)) ha_s9 hinp
        (exprInArena_small (by decide) (by decide) hV16)
        (exprInArena_small (by decide) (by decide) hV16)
        ⟨by decide, by decide⟩ (evalVal_lit _ _ _)
        (by simp [rw_write_eq, rf_free_eq, evalVal_add, evalVal_readLocal, evalVal_lit,
              hr9_g]
            try push_cast; try ring; try rfl)
        (by decide) (by omega) (by simp; omega) (idx_V (c + 1) (by omega))
      let ws_next := ((ws_g.write (.localFrame 1 4 (2 * (c : ℤ))) (zRat ⟨c, hc⟩).num).write
        (.localFrame 1 4 (2 * (c : ℤ) + 1)) ((zRat ⟨c, hc⟩).den : ℤ)).write
        (.localFrame 1 1 9) (((c + 1 : ℕ) : ℤ))
      have hloc_other : ∀ (v : ℕ) (idx : ℤ), v ≠ 1 → v ≠ 4 →
          ws_next.read (.localFrame 1 v idx) = ws_c.read (.localFrame 1 v idx) := by
        intro v idx hne1 hne4
        dsimp [ws_next]
        rw [wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne1 hv),
          wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne4 hv),
          wordStore_read_write_of_ne _ (by intro h; injection h with _ hv _; exact hne4 hv),
          hoth_g _ (by intro h; injection h with _ hv _; exact hne1 hv)
            (by intro h; injection h with _ hv _; exact hne1 hv)
            (by intro h; injection h with _ hv _; exact hne1 hv)]
        dsimp [ws_pre_ite]
        simp only [rw_local_var_ne _ hne1]
      have hvar4_unch : ∀ idx : ℤ, idx ≠ 2 * (c : ℤ) → idx ≠ 2 * (c : ℤ) + 1 →
          ws_next.read (.localFrame 1 4 idx) = ws_c.read (.localFrame 1 4 idx) := by
        intro idx hne0 hne1
        dsimp [ws_next]
        rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
          wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi; exact hne1 hi),
          wordStore_read_write_of_ne _ (by intro h; injection h with _ _ hi; exact hne0 hi),
          hoth_g _ (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega)]
        dsimp [ws_pre_ite]
        simp [rw_write_eq, rf_free_eq]
      have hhz_next : HeapAllZero ws_next := by
        intro t idx
        dsimp [ws_next]
        rw [wordStore_read_write_of_ne _ (by intro h; cases h),
          wordStore_read_write_of_ne _ (by intro h; cases h),
          wordStore_read_write_of_ne _ (by intro h; cases h),
          hoth_g _ (by intro h; cases h) (by intro h; cases h) (by intro h; cases h)]
        dsimp [ws_pre_ite]
        simp [rw_write_eq, rf_free_eq]
        exact hhz_c t idx
      have hb_gcd : 64 * (2 * p.L_z + 1) * (p.L_z + 4 + natBitLength (2 * p.L_z) + 16) ^ 2 ≤
          (300 + 600 * p.L_z) * (V + 8) ^ 2 := by
        have hnb2L : natBitLength (2 * p.L_z) ≤ V := by
          have := natBitLength_le (2 * p.L_z); omega
        have h1 : p.L_z + 4 + natBitLength (2 * p.L_z) + 16 ≤ 2 * (V + 8) := by omega
        calc 64 * (2 * p.L_z + 1) * (p.L_z + 4 + natBitLength (2 * p.L_z) + 16) ^ 2
            ≤ 64 * (2 * p.L_z + 1) * (2 * (V + 8)) ^ 2 :=
              Nat.mul_le_mul_left _ (Nat.pow_le_pow_left h1 2)
          _ = (512 * p.L_z + 256) * (V + 8) ^ 2 := by ring
          _ ≤ (300 + 600 * p.L_z) * (V + 8) ^ 2 := Nat.mul_le_mul_right _ (by omega)
      have ex_step :=
        ExecBounded.seq ex_s1 (ExecBounded.seq ex_s2 (ExecBounded.seq ex_s3
        (ExecBounded.seq ex_s4 (ExecBounded.seq ex_s5 (ExecBounded.seq ex_s6
        (ExecBounded.seq ex_g (ExecBounded.seq ex_s8 (ExecBounded.seq ex_s9 ex_s10))))))))
      have hb_step :
          66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 +
          (66000 * (V + 8) ^ 2 + ((66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2) +
          (66000 * (V + 8) ^ 2 + (64 * (2 * p.L_z + 1) * (p.L_z + 4 + natBitLength (2 * p.L_z) + 16) ^ 2 +
          (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2)))))))) ≤
          (750000 + 600 * p.L_z) * (V + 8) ^ 2 := by
        set Y := (V + 8) ^ 2
        have h1 : (750000 + 600 * p.L_z) * Y = 750000 * Y + 600 * p.L_z * Y := by ring
        have h2 : (300 + 600 * p.L_z) * Y = 300 * Y + 600 * p.L_z * Y := by ring
        omega
      refine ⟨ws_next, bs, ⟨rfl, ha_s10, hhz_next,
        hasPhase2Regs_of_eq hregs_c (fun idx => hloc_other 0 idx (by decide) (by decide)),
        hasLiftArrays_of_eq hlifts_c (fun v idx hv =>
          hloc_other v idx (by rcases hv with rfl | rfl <;> decide) (by rcases hv with rfl | rfl <;> decide)),
        by dsimp [ws_next]; rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
             wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
             hoth_g _ (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega)]
           dsimp [ws_pre_ite]; simp [rw_write_eq, rf_free_eq, hr5_c],
        wordStore_read_write_self _ _ _,
        fun k hk => by
          have hk_lt : k < c + 1 := Nat.lt_of_lt_of_le hk (Nat.min_le_left _ _)
          rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hk_lt) with hlt | rfl
          · exact ⟨(hvar4_unch _ (by omega) (by omega)).trans (hdone_c k (lt_min hlt (hlt.trans hc))).1,
                   (hvar4_unch _ (by omega) (by omega)).trans (hdone_c k (lt_min hlt (hlt.trans hc))).2⟩
          · dsimp [ws_next]
            exact ⟨by rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega),
                        wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_self],
                   by rw [wordStore_read_write_of_ne _ (by intro h_ne; injection h_ne; try omega), wordStore_read_write_self]⟩,
        fun k hck hkD =>
          ⟨(hvar4_unch _ (by omega) (by omega)).trans (hrem_c k (by omega) hkD).1,
           (hvar4_unch _ (by omega) (by omega)).trans (hrem_c k (by omega) hkD).2⟩⟩,
        ExecBounded.mono ex_step (by omega) hb_step le_rfl le_rfl⟩)
  rcases hinv_D with ⟨hbs_D_eq, ha_end, hhz_end, hregs_end, hlifts_end, _, _, hdone_end, _⟩
  subst bs₁
  have ex_tot := ExecBounded.seq ex_1 (ExecBounded.seq ex_2 ex_loop)
  have hb_tot :
      66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 +
      (66000 * (V + 8) ^ 2 + p.D * ((750000 + 600 * p.L_z) * (V + 8) ^ 2))) ≤
      (300000 + p.D * (800000 + 600 * p.L_z)) * (V + 8) ^ 2 := by
    set Y := (V + 8) ^ 2
    have h1 : p.D * ((750000 + 600 * p.L_z) * Y) ≤ p.D * ((800000 + 600 * p.L_z) * Y) :=
      Nat.mul_le_mul_left p.D (Nat.mul_le_mul_right Y (by omega))
    have h2 : (300000 + p.D * (800000 + 600 * p.L_z)) * Y =
        300000 * Y + p.D * ((800000 + 600 * p.L_z) * Y) := by ring
    omega
  have hu_D : p.D * (750 + 50 * p.L_z) ≤ p.D * (800 + 50 * p.L_z) := Nat.mul_le_mul_left p.D (by omega)
  exact ⟨ws₁, ha_end, hhz_end, hregs_end, hlifts_end,
    fun c => hdone_end c.1 (lt_min c.2 c.2),
    ExecBounded.mono ex_tot (by omega) hb_tot le_rfl le_rfl⟩

theorem exec_phase3Stmt {A V M U_A1 : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ)
    (prog_A1 : BitRAMStmt) {outA1 : BitRAMExecOutcome} (zRat : Fin p.D → ℚ)
    (f_samp : Fin M → Fin (p.W₁ M) → Bool) (restBits : List Bool)
    {inp : BitRAMInput p.d} {ws₃ : WordStore}
    (harena : InAttemptArena A V ws₃)
    (hhz : HeapAllZero ws₃)
    (hregs : HasPhase2Regs p M ws₃)
    (hlifts : HasLiftArrays p pts_h ws₃)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p)
    (hpts_b : ∀ h : ℕ, h < p.m → RatPointBitBounded p.B (pts_h h))
    (hip_handles : inp.activeHandles = Finset.range p.m)
    (hip_coords : ∀ h : ℕ, h < p.m → inp.activeRatCoords h = pts_h h)
    (hM_fit : 1 ≤ M ∧ M * p.D + 4 ≤ A ∧ p.W₁ M + 4 ≤ V ∧ 2 * p.L_z + 16 ≤ V ∧ U_A1 + 2 ≤ V)
    (hrun_A1 :
      let hm_pos : 0 < p.m := by
        have hs1 := s₀Val_pos (deg_α := p.deg_α) hfit.1 p.d
        have hm2 := hfit.2.2.2.1
        dsimp [CoreParams.s₀] at hm2; omega
      let ω : Fin M → Fin p.m := fun j =>
        ⟨bitsToNat (p.W₁ M) (f_samp j) % p.m, Nat.mod_lt _ hm_pos⟩
      runBitRAMWithBits prog_A1
        { intParams := [(p.B_lift : ℤ), (p.k_φ : ℤ), (M : ℤ)]
          activeHandles := Finset.range M
          activeRatCoords := fun j =>
            if hj : j < M then liftRatPoint (pts_h (ω ⟨j, hj⟩).1) else fun _ => 0
          extraRats := [] }
        WordStore.empty [] = some outA1)
    (ha1_bounds : outA1.unitCost ≤ U_A1 ∧ outA1.bitCost ≤ U_A1 ∧
      outA1.peakCellSpace ≤ U_A1 ∧ outA1.peakBitSpace ≤ U_A1)
    (hz_out : ∀ c : Fin p.D,
      let zNum := outA1.words.read (.heap 1 (2 * (c.1 : ℤ)))
      let zDen := outA1.words.read (.heap 1 (2 * (c.1 : ℤ) + 1))
      0 < zDen ∧ zRat c = (zNum : ℚ) / (zDen : ℚ) ∧
      intBitLength zNum ≤ p.L_z ∧ intBitLength zDen ≤ p.L_z) :
    let T_A1 := maxTableStmtFull prog_A1
    let F_A1 := stmtFactor prog_A1
    let C_A1 := arenaCellCap inp A + 2 * U_A1 + 8
    let S_A1 := arenaBitCap inp A V + (natBitLength T_A1 + 12) * U_A1 +
      (U_A1 + 3) * (natBitLength (U_A1 + 2) + U_A1 + 2 * natBitLength T_A1 + 18) +
      2 * natBitLength (U_A1 + 2) + 64
    ∃ ws₄ : WordStore,
      InAttemptArena A V ws₄ ∧
      HeapAllZero ws₄ ∧
      HasPhase2Regs p M ws₄ ∧
      HasLiftArrays p pts_h ws₄ ∧
      HasZArray p.D zRat ws₄ ∧
      ExecBounded inp (phase3Stmt p.k_φ prog_A1)
        ws₃ (blockBitStream f_samp restBits 0) ws₄ restBits
        (2000 + M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1)) +
          p.D * (1000 + 50 * p.L_z) + 80 * F_A1 * (U_A1 + 1))
        ((2000000 + M * (1200000 + 600000 * p.d) + p.D * (1000000 + 600 * p.L_z)) *
          (V + natBitLength T_A1 + 16) ^ 2 +
          256 * F_A1 * (V + natBitLength T_A1 + 8) ^ 2 * (2 * U_A1 + 16) * U_A1 +
          (U_A1 + 2) * (8 * natBitLength (U_A1 + 2) + 4 * (U_A1 + 2 * natBitLength T_A1 + 6) + 80))
        C_A1 S_A1 := by
  intro T_A1 F_A1 C_A1 S_A1
  have h16A := hfit.2.2.2.2.1
  have hmA := hfit.2.2.2.2.2.1
  have hVA := hfit.2.2.2.2.2.2.1
  -- 1. Stage
  obtain ⟨wsStaged, ha_st, hregs_st, hlifts_st, hstage, hht_st, hh5_st, hh67_st, ex_st⟩ :=
    exec_phase3StageStmt p pts_h f_samp restBits harena hhz hregs hlifts hinp hfit
      hpts_b hip_handles hip_coords ⟨hM_fit.1, hM_fit.2.1, hM_fit.2.2.1⟩
  -- 2. Call `prog_A1` and extract `2 * p.D` words into `var 4`
  have hV_flag : intBitLength (outA1.words.read (.heap 0 0)) ≤ V :=
    (outSub_read_bitLength_le hrun_A1 (.heap 0 0)).trans (by omega)
  have hV_out : ∀ j : ℕ, j < 2 * p.D → intBitLength (outA1.words.read (.heap 1 (j : ℤ))) ≤ V :=
    fun j _ => (outSub_read_bitLength_le hrun_A1 (.heap 1 (j : ℤ))).trans (by omega)
  have hV_idx : ∀ k : ℕ, k ≤ 2 * p.D → intBitLength (k : ℤ) ≤ V := by
    intro k hk
    have h1 := intBitLength_natCast_le_succ k
    have h2 := natBitLength_mono (by omega : k ≤ A)
    omega
  have ex_sub := exec_runSubAndExtractStmt (inpSim := inp) (isDimD := true) (progSub := prog_A1)
    (flagVar := 1) (flagIdx := 15) (outVar := 4) (nOutLoc := some (0, 14))
    (loopIdxVar := 9) (N_out := 2 * p.D) (bs := restBits)
    (U_sub := U_A1) (B_sub := U_A1) (C_sub := U_A1) (S_sub := U_A1)
    ha_st hstage hrun_A1
    ⟨by decide, by decide, by decide, by decide, by decide, by decide⟩
    ⟨by omega, by omega, by omega⟩
    ⟨by decide, by omega, by decide, by decide, hregs_st.1.2.2.2.2.2.2.2.2.2.2.2.2.1⟩
    hV_flag hV_out (by omega) ha1_bounds
  obtain ⟨ha_ext, _, hr_out_ext, hoth_ext⟩ := extractSubResultWS_props ha_st
    (wsOutSub := outA1.words) (flagVar := 1) (flagIdx := 15) (outVar := 4)
    (loopIdxVar := 9) (N_out := 2 * p.D)
    ⟨by decide, by decide, by decide, by decide, by decide, by decide⟩
    ⟨by omega, by omega, by omega⟩ hV_flag hV_idx hV_out
  let wsExt := extractSubResultWS wsStaged 1 15 4 9 outA1.words (2 * p.D)
  have hregs_ext : HasPhase2Regs p M wsExt :=
    hasPhase2Regs_of_eq hregs_st (fun idx =>
      hoth_ext _ (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega) (by intro h_ne; injection h_ne; try omega) (fun _ _ => (by intro h_ne; injection h_ne; try omega)))
  have hlifts_ext : HasLiftArrays p pts_h wsExt :=
    hasLiftArrays_of_eq hlifts_st (fun v idx hv =>
      hoth_ext _ (by rcases hv with rfl | rfl <;> (intro h_ne; nomatch h_ne))
        (by rcases hv with rfl | rfl <;> (intro h_ne; nomatch h_ne))
        (by rcases hv with rfl | rfl <;> (intro h_ne; nomatch h_ne))
        (fun _ _ => by rcases hv with rfl | rfl <;> (intro h_ne; nomatch h_ne)))
  have hheap_ext : ∀ t idx, wsExt.read (.heap t idx) = wsStaged.read (.heap t idx) :=
    fun t idx => hoth_ext _ (by intro h; cases h) (by intro h; cases h)
      (by intro h; cases h) (fun _ _ h => by cases h)
  -- 3. Unstage
  obtain ⟨wsUn, ha_un, hhz_un, hregs_un, hlifts_un, hz4_un, ex_un⟩ :=
    exec_phase3UnstageStmt p pts_h ha_ext hregs_ext hlifts_ext hinp hfit hM_fit.2.1
      (fun t idx ht5 ht6 ht7 => (hheap_ext t idx).trans (hht_st t idx ht5 ht6 ht7))
      (fun idx h0 h1 h2 => (hheap_ext 5 idx).trans (hh5_st idx h0 h1 h2))
      (fun idx hr => ⟨(hheap_ext 6 idx).trans (hh67_st idx hr).1,
                      (hheap_ext 7 idx).trans (hh67_st idx hr).2⟩)
  -- 4. Reduce
  have hz_raw_un : ∀ c : Fin p.D,
      let zNum := wsUn.read (.localFrame 1 4 (2 * (c.1 : ℤ)))
      let zDen := wsUn.read (.localFrame 1 4 (2 * (c.1 : ℤ) + 1))
      0 < zDen ∧ zRat c = (zNum : ℚ) / (zDen : ℚ) ∧
      intBitLength zNum ≤ p.L_z ∧ intBitLength zDen ≤ p.L_z := by
    intro c
    have h0_eq : (2 * (c.1 : ℤ)) = ((2 * c.1 : ℕ) : ℤ) := by push_cast; ring
    have h1_eq : (2 * (c.1 : ℤ) + 1) = ((2 * c.1 + 1 : ℕ) : ℤ) := by push_cast; ring
    have hr0 : wsUn.read (.localFrame 1 4 (2 * (c.1 : ℤ))) =
        outA1.words.read (.heap 1 (2 * (c.1 : ℤ))) := by
      rw [hz4_un, h0_eq, hr_out_ext (2 * c.1) (by omega)]
    have hr1 : wsUn.read (.localFrame 1 4 (2 * (c.1 : ℤ) + 1)) =
        outA1.words.read (.heap 1 (2 * (c.1 : ℤ) + 1)) := by
      rw [hz4_un, h1_eq, hr_out_ext (2 * c.1 + 1) (by omega)]
    dsimp only
    rw [hr0, hr1]
    exact hz_out c
  obtain ⟨ws₄, ha_4, hhz_4, hregs_4, hlifts_4, hz_4, ex_red⟩ :=
    exec_phase3ReduceStmt p pts_h zRat ha_un hhz_un hregs_un hlifts_un hinp hfit
      hM_fit.2.2.2.1 hz_raw_un
  -- Combine space and cost bounds
  have hCS : arenaCellCap inp A ≤ C_A1 ∧ arenaBitCap inp A V ≤ S_A1 :=
    ⟨by dsimp [C_A1]; omega, by dsimp [S_A1]; omega⟩
  have ex_st' := ExecBounded.mono ex_st le_rfl le_rfl hCS.1 hCS.2
  have ex_un' := ExecBounded.mono ex_un le_rfl le_rfl hCS.1 hCS.2
  have ex_red' := ExecBounded.mono ex_red le_rfl le_rfl hCS.1 hCS.2
  let Z := V + natBitLength T_A1 + 16
  have hVZ : V + 8 ≤ Z := by dsimp [Z]; omega
  have hYZ : (V + 8) ^ 2 ≤ Z ^ 2 := Nat.pow_le_pow_left hVZ 2
  have hex_tail : (2 * p.D + 4) * (32 * (natBitLength A + natBitLength T_A1 + V + 16) ^ 2) ≤
      (256 * p.D + 512) * Z ^ 2 := by
    have h1 : natBitLength A + natBitLength T_A1 + V + 16 ≤ 2 * Z := by dsimp [Z]; omega
    calc (2 * p.D + 4) * (32 * (natBitLength A + natBitLength T_A1 + V + 16) ^ 2)
        ≤ (2 * p.D + 4) * (32 * (2 * Z) ^ 2) :=
          Nat.mul_le_mul_left _ (Nat.mul_le_mul_left 32 (Nat.pow_le_pow_left h1 2))
      _ = (256 * p.D + 512) * Z ^ 2 := by ring
  have ex_sub' : ExecBounded inp (runSubAndExtractStmt true prog_A1 1 15 4 (some (0, 14)) 9)
      wsStaged restBits wsExt restBits
      (80 * F_A1 * (U_A1 + 1) + 32 * p.D + 64)
      (256 * F_A1 * (V + natBitLength T_A1 + 8) ^ 2 * (2 * U_A1 + 16) * U_A1 +
        (U_A1 + 2) * (8 * natBitLength (U_A1 + 2) + 4 * (U_A1 + 2 * natBitLength T_A1 + 6) + 80) +
        (256 * p.D + 512) * Z ^ 2)
      C_A1 S_A1 := by
    refine ExecBounded.mono ex_sub (by dsimp [F_A1]; omega) ?_
      (by dsimp [C_A1, arenaCellCap]; omega) (by dsimp [S_A1, arenaBitCap, T_A1]; ring_nf; omega)
    dsimp [F_A1, T_A1, Z] at hex_tail ⊢
    rw [show U_A1 + U_A1 + 16 = 2 * U_A1 + 16 by omega]
    omega
  have ex_all := ExecBounded.seq ex_st' (ExecBounded.seq ex_sub' (ExecBounded.seq ex_un' ex_red'))
  have hu_all :
      (400 + M * (900 + 300 * p.d + 24 * (p.W₁ M + 1))) +
        ((80 * F_A1 * (U_A1 + 1) + 32 * p.D + 64) +
          ((500 + 250 * (M * p.D)) + (300 + p.D * (800 + 50 * p.L_z)))) ≤
      2000 + M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1)) +
        p.D * (1000 + 50 * p.L_z) + 80 * F_A1 * (U_A1 + 1) := by
    have hMD : 250 * (M * p.D) = M * (250 * p.d + 250) := by dsimp [CoreParams.D]; ring
    have hM_mono : M * (900 + 300 * p.d + 24 * (p.W₁ M + 1)) + M * (250 * p.d + 250) ≤
        M * (1200 + 600 * p.d + 24 * (p.W₁ M + 1)) := by
      rw [← Nat.mul_add]
      exact Nat.mul_le_mul_left M (by omega)
    have hD_mono : 32 * p.D + p.D * (800 + 50 * p.L_z) ≤ p.D * (1000 + 50 * p.L_z) := by
      have : 32 * p.D + p.D * (800 + 50 * p.L_z) = p.D * (832 + 50 * p.L_z) := by ring
      rw [this]
      exact Nat.mul_le_mul_left p.D (by omega)
    omega
  have hb_all :
      (400000 + M * (900000 + 300000 * p.d)) * (V + 8) ^ 2 +
        ((256 * F_A1 * (V + natBitLength T_A1 + 8) ^ 2 * (2 * U_A1 + 16) * U_A1 +
          (U_A1 + 2) * (8 * natBitLength (U_A1 + 2) + 4 * (U_A1 + 2 * natBitLength T_A1 + 6) + 80) +
          (256 * p.D + 512) * Z ^ 2) +
          ((500000 + 250000 * (M * p.D)) * (V + 8) ^ 2 +
            (300000 + p.D * (800000 + 600 * p.L_z)) * (V + 8) ^ 2)) ≤
      (2000000 + M * (1200000 + 600000 * p.d) + p.D * (1000000 + 600 * p.L_z)) * Z ^ 2 +
        256 * F_A1 * (V + natBitLength T_A1 + 8) ^ 2 * (2 * U_A1 + 16) * U_A1 +
        (U_A1 + 2) * (8 * natBitLength (U_A1 + 2) + 4 * (U_A1 + 2 * natBitLength T_A1 + 6) + 80) := by
    have h_y1 := Nat.mul_le_mul_left (400000 + M * (900000 + 300000 * p.d)) hYZ
    have h_y2 := Nat.mul_le_mul_left (500000 + 250000 * (M * p.D)) hYZ
    have h_y3 := Nat.mul_le_mul_left (300000 + p.D * (800000 + 600 * p.L_z)) hYZ
    have hsumZ :
        (400000 + M * (900000 + 300000 * p.d)) * Z ^ 2 +
          (256 * p.D + 512) * Z ^ 2 +
          (500000 + 250000 * (M * p.D)) * Z ^ 2 +
          (300000 + p.D * (800000 + 600 * p.L_z)) * Z ^ 2 ≤
        (2000000 + M * (1200000 + 600000 * p.d) + p.D * (1000000 + 600 * p.L_z)) * Z ^ 2 := by
      have hfactor :
          (400000 + M * (900000 + 300000 * p.d)) * Z ^ 2 +
            (256 * p.D + 512) * Z ^ 2 +
            (500000 + 250000 * (M * p.D)) * Z ^ 2 +
            (300000 + p.D * (800000 + 600 * p.L_z)) * Z ^ 2 =
          (1200512 + (M * (900000 + 300000 * p.d) + 250000 * (M * p.D)) +
            (256 * p.D + p.D * (800000 + 600 * p.L_z))) * Z ^ 2 := by ring
      rw [hfactor]
      refine Nat.mul_le_mul_right (Z ^ 2) ?_
      have hMD : M * (900000 + 300000 * p.d) + 250000 * (M * p.D) =
          M * (1150000 + 550000 * p.d) := by dsimp [CoreParams.D]; ring
      have hMm : M * (1150000 + 550000 * p.d) ≤ M * (1200000 + 600000 * p.d) :=
        Nat.mul_le_mul_left M (by omega)
      have hDm : 256 * p.D + p.D * (800000 + 600 * p.L_z) ≤ p.D * (1000000 + 600 * p.L_z) := by
        have : 256 * p.D + p.D * (800000 + 600 * p.L_z) = p.D * (800256 + 600 * p.L_z) := by ring
        rw [this]
        exact Nat.mul_le_mul_left p.D (by omega)
      omega
    omega
  exact ⟨ws₄, ha_4, hhz_4, hregs_4, hlifts_4, hz_4,
    ExecBounded.mono ex_all hu_all hb_all le_rfl le_rfl⟩

end UL.Proof_lem_A_2
