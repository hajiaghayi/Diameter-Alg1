import Mathlib
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_node_chain_blocks
import UL.Def.def_A_convex_hull_cert
import UL.Def.def_A_halfspace_net
set_option autoImplicit false

namespace UL.Proof_lem_A_2

/-! ### 1. Polynomial block size `s₀Val` and Haussler–Welzl threshold -/

/-- Explicit polynomial block size `s₀(d) = 22 K^3 (d + 2)^{2 deg_α + 1}`. -/
def s₀Val (K deg_α d : ℕ) : ℕ :=
  22 * K ^ 3 * (d + 2) ^ (2 * deg_α + 1)

theorem s₀Val_pos {K deg_α : ℕ} (hK : 1 ≤ K) (d : ℕ) : 1 ≤ s₀Val K deg_α d := by
  unfold s₀Val
  have hK0 : 0 < K := by omega
  have hd0 : 0 < d + 2 := by omega
  have hp : 0 < 22 * K ^ 3 * (d + 2) ^ (2 * deg_α + 1) := by positivity
  omega

theorem isBoundedByPoly1_s₀Val (K deg_α : ℕ) :
    IsBoundedByPoly1 (fun d => (s₀Val K deg_α d : ℝ)) := by
  let p : ℕ := 2 * deg_α + 1
  refine ⟨(22 * K ^ 3 * 2 ^ p : ℕ), p, by positivity, fun d => ?_⟩
  have hd2 : (d + 2 : ℝ) ≤ 2 * (d + 1 : ℝ) := by linarith
  have hpow : (d + 2 : ℝ) ^ p ≤ (2 : ℝ) ^ p * (d + 1 : ℝ) ^ p := by
    rw [← mul_pow]
    exact pow_le_pow_left₀ (by positivity) hd2 p
  unfold s₀Val
  push_cast
  calc
    22 * (K : ℝ) ^ 3 * ((d : ℝ) + 2) ^ p
        ≤ 22 * (K : ℝ) ^ 3 * ((2 : ℝ) ^ p * ((d : ℝ) + 1) ^ p) :=
          mul_le_mul_of_nonneg_left (by exact_mod_cast hpow) (by positivity)
    _ = (22 * (K : ℝ) ^ 3 * (2 : ℝ) ^ p) * ((d : ℝ) + 1) ^ p := by ring

theorem hw87_threshold_le_s₀Val {K deg_α d : ℕ} (hK : 1 ≤ K)
    {C_HW α₀ : ℝ} (hCHW0 : 0 < C_HW) (hCHW : C_HW ≤ (K : ℝ))
    (hα0 : 0 < α₀) (hα1 : α₀ ≤ 1)
    (hα_inv : α₀⁻¹ ≤ (K : ℝ) * ((d + 2 : ℝ) ^ deg_α)) :
    Nat.ceil (C_HW * α₀⁻¹ * (((d + 1 : ℝ) + 1) * Real.log (2 / α₀) +
      Real.log (2 / (1 / 10 : ℝ)))) ≤ s₀Val K deg_α d := by
  refine Nat.ceil_le.mpr ?_
  have hK1 : (1 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
  have hd2_ge1 : (1 : ℝ) ≤ (d + 2 : ℝ) := by linarith
  have hpow_ge1 : (1 : ℝ) ≤ (d + 2 : ℝ) ^ deg_α := one_le_pow₀ hd2_ge1
  have h_log_alpha : Real.log (2 / α₀) ≤ 2 * α₀⁻¹ := by
    have hpos : 0 < 2 / α₀ := div_pos (by norm_num) hα0
    calc
      Real.log (2 / α₀) ≤ 2 / α₀ - 1 := Real.log_le_sub_one_of_pos hpos
      _ ≤ 2 / α₀ := by linarith
      _ = 2 * α₀⁻¹ := div_eq_mul_inv 2 α₀
  have h_log_delta : Real.log (2 / (1 / 10 : ℝ)) ≤ 20 := by
    have heq : (2 : ℝ) / (1 / 10 : ℝ) = 20 := by norm_num
    rw [heq]
    have hle := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 20)
    linarith
  have h_d1 : ((d + 1 : ℝ) + 1) = (d + 2 : ℝ) := by push_cast; ring
  rw [h_d1]
  have h_inner_1 :
      (d + 2 : ℝ) * Real.log (2 / α₀) ≤
        2 * (K : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1) := by
    have h1 : (d + 2 : ℝ) * Real.log (2 / α₀) ≤ (d + 2 : ℝ) * (2 * α₀⁻¹) :=
      mul_le_mul_of_nonneg_left h_log_alpha (by positivity)
    have h2 : (d + 2 : ℝ) * (2 * α₀⁻¹) ≤
        (d + 2 : ℝ) * (2 * ((K : ℝ) * (d + 2 : ℝ) ^ deg_α)) := by
      gcongr
    calc
      (d + 2 : ℝ) * Real.log (2 / α₀)
          ≤ (d + 2 : ℝ) * (2 * ((K : ℝ) * (d + 2 : ℝ) ^ deg_α)) := h1.trans h2
      _ = 2 * (K : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1) := by rw [pow_succ]; ring
  have h_20 :
      (20 : ℝ) ≤ 20 * (K : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1) := by
    have hpow1 : (1 : ℝ) ≤ (d + 2 : ℝ) ^ (deg_α + 1) := one_le_pow₀ hd2_ge1
    have hk_pow : (1 : ℝ) ≤ (K : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1) :=
      one_le_mul_of_one_le_of_one_le hK1 hpow1
    linarith
  have h_inner :
      (d + 2 : ℝ) * Real.log (2 / α₀) + Real.log (2 / (1 / 10 : ℝ)) ≤
        22 * (K : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1) := by
    linarith
  have h_inner_nn :
      0 ≤ (d + 2 : ℝ) * Real.log (2 / α₀) + Real.log (2 / (1 / 10 : ℝ)) := by
    have h2a : 1 ≤ 2 / α₀ := by
      rw [le_div_iff₀ hα0]
      linarith
    have h1 : 0 ≤ Real.log (2 / α₀) := Real.log_nonneg h2a
    have h2 : 0 ≤ Real.log (2 / (1 / 10 : ℝ)) := by
      have heq : (2 : ℝ) / (1 / 10 : ℝ) = 20 := by norm_num
      rw [heq]
      exact Real.log_nonneg (by norm_num)
    positivity
  have h_prod1 : C_HW * α₀⁻¹ ≤ (K : ℝ) ^ 2 * (d + 2 : ℝ) ^ deg_α := by
    calc
      C_HW * α₀⁻¹ ≤ (K : ℝ) * ((K : ℝ) * (d + 2 : ℝ) ^ deg_α) :=
        mul_le_mul hCHW hα_inv (inv_nonneg.mpr hα0.le) (by positivity)
      _ = (K : ℝ) ^ 2 * (d + 2 : ℝ) ^ deg_α := by ring
  calc
    C_HW * α₀⁻¹ * ((d + 2 : ℝ) * Real.log (2 / α₀) + Real.log (2 / (1 / 10 : ℝ)))
        ≤ ((K : ℝ) ^ 2 * (d + 2 : ℝ) ^ deg_α) *
            (22 * (K : ℝ) * (d + 2 : ℝ) ^ (deg_α + 1)) :=
          mul_le_mul h_prod1 h_inner h_inner_nn (by positivity)
    _ = 22 * (K : ℝ) ^ 3 * (d + 2 : ℝ) ^ (2 * deg_α + 1) := by
          have hexp : deg_α + (deg_α + 1) = 2 * deg_α + 1 := by omega
          rw [← hexp, pow_add]
          ring
    _ = (s₀Val K deg_α d : ℝ) := by
          unfold s₀Val
          push_cast
          ring

/-! ### 2. Rational paraboloid lift and unreduced sum-of-squares bounds -/

/-- Lifted coordinate bit-length bound `B_lift(d, B) = (2 d + 1) B + d + 2`. -/
def bLiftVal (d B : ℕ) : ℕ :=
  (2 * d + 2) * B + d + 2

/-- Rational paraboloid lift `q ↦ (q, ∑_{c < d} q_c^2) ∈ ℚ^{d + 1}`. -/
def liftRatPoint {d : ℕ} (q : Fin d → ℚ) : Fin (d + 1) → ℚ :=
  Fin.snoc q (∑ c : Fin d, (q c) ^ 2)

theorem ratPointToEuclidean_liftRatPoint {d : ℕ} (q : Fin d → ℚ) :
    ratPointToEuclidean (liftRatPoint q) = paraboloidLift (ratPointToEuclidean q) := by
  ext i
  refine Fin.lastCases ?_ ?_ i
  · simp only [ratPointToEuclidean, WithLp.equiv_symm_apply, liftRatPoint, Fin.snoc_last,
      paraboloidLift, liftedPoint, Rat.cast_sum, Rat.cast_pow]
    rw [EuclideanSpace.norm_sq_eq]
    refine Finset.sum_congr rfl fun c _ => ?_
    simp only [WithLp.ofLp_toLp, Real.norm_eq_abs, sq_abs]
  · intro c
    simp [ratPointToEuclidean, liftRatPoint, paraboloidLift, liftedPoint]

theorem liftedPoint_oRat_sRat_eq {d : ℕ} (zRat : Fin (d + 1) → ℚ) :
    liftedPoint (ratPointToEuclidean (fun c : Fin d => zRat c.castSucc))
      (zRat (Fin.last d) : ℝ) = ratPointToEuclidean zRat := by
  ext i
  refine Fin.lastCases ?_ ?_ i
  · simp [liftedPoint, ratPointToEuclidean]
  · intro c
    simp [liftedPoint, ratPointToEuclidean]

/-- Pure integer accumulator for unreduced `∑_{c < k} (num_c / den_c)^2`. -/
def sumSqPairAux {d : ℕ} (q : Fin d → ℚ) : (k : ℕ) → k ≤ d → ℤ × ℤ
  | 0, _ => (0, 1)
  | k + 1, hk =>
      let prev := sumSqPairAux q k (Nat.le_of_succ_le hk)
      let qc := q ⟨k, hk⟩
      let p : ℤ := qc.num
      let dn : ℤ := (qc.den : ℤ)
      (prev.1 * (dn * dn) + (p * p) * prev.2, prev.2 * (dn * dn))

theorem nat_lt_two_pow_of_natBitLength_le {n B : ℕ} (h : natBitLength n ≤ B) :
    n < 2 ^ B := by
  unfold natBitLength at h
  have hlt : n < 2 ^ (Nat.log 2 n + 1) := Nat.lt_pow_succ_log_self (by norm_num) n
  exact hlt.trans_le (Nat.pow_le_pow_right (by norm_num) h)

theorem natBitLength_le_of_lt_two_pow {n B : ℕ} (hB : 1 ≤ B) (h : n < 2 ^ B) :
    natBitLength n ≤ B := by
  unfold natBitLength
  rcases Nat.eq_zero_or_pos n with rfl | hn
  · simp [hB]
  · have hlog : Nat.log 2 n < B := (Nat.log_lt_iff_lt_pow (by norm_num) hn.ne').mpr h
    omega

theorem sumSqPairAux_spec {d B : ℕ} {q : Fin d → ℚ}
    (hq : RatPointBitBounded B q) :
    ∀ (k : ℕ) (hk : k ≤ d),
      let nd := sumSqPairAux q k hk
      0 ≤ nd.1 ∧
      1 ≤ nd.2 ∧
      nd.1 ≤ (k : ℤ) * ((2 : ℤ) ^ (2 * B) * nd.2) ∧
      nd.2 ≤ (2 : ℤ) ^ (2 * k * B) ∧
      ((nd.1 : ℚ) / (nd.2 : ℚ)) = ∑ i : Fin k, (q ⟨i.1, lt_of_lt_of_le i.2 hk⟩) ^ 2 := by
  intro k
  induction k with
  | zero =>
      intro hk
      simp [sumSqPairAux]
  | succ k ih =>
      intro hk
      obtain ⟨hn0, hd1, hn_ub, hd_ub, hval⟩ := ih (Nat.le_of_succ_le hk)
      set prev := sumSqPairAux q k (Nat.le_of_succ_le hk)
      set qc := q ⟨k, hk⟩
      have hqc := hq ⟨k, hk⟩
      have hp_lt_nat : qc.num.natAbs < 2 ^ B := nat_lt_two_pow_of_natBitLength_le hqc.1
      have hdn_lt_nat : qc.den < 2 ^ B := nat_lt_two_pow_of_natBitLength_le hqc.2
      have hdn_pos_nat : 1 ≤ qc.den := qc.pos
      set p : ℤ := qc.num
      set dn : ℤ := (qc.den : ℤ)
      have hp_sq_nn : 0 ≤ p * p := mul_self_nonneg p
      have hp_sq_le : p * p ≤ (2 : ℤ) ^ (2 * B) := by
        have hp_abs : p * p = ((qc.num.natAbs * qc.num.natAbs : ℕ) : ℤ) := by
          dsimp [p]
          exact_mod_cast (Int.natAbs_mul_self' qc.num).symm
        have hnat_le : qc.num.natAbs * qc.num.natAbs ≤ 2 ^ (2 * B) := by
          calc
            qc.num.natAbs * qc.num.natAbs ≤ (2 ^ B) * (2 ^ B) :=
              Nat.mul_le_mul hp_lt_nat.le hp_lt_nat.le
            _ = 2 ^ (2 * B) := by rw [← pow_add, two_mul]
        rw [hp_abs]
        exact_mod_cast hnat_le
      have hdn_sq_pos : 1 ≤ dn * dn := by
        have h1 : (1 : ℤ) ≤ dn := by dsimp [dn]; exact_mod_cast hdn_pos_nat
        nlinarith
      have hdn_sq_le : dn * dn ≤ (2 : ℤ) ^ (2 * B) := by
        have hnat_le : qc.den * qc.den ≤ 2 ^ (2 * B) := by
          calc
            qc.den * qc.den ≤ (2 ^ B) * (2 ^ B) :=
              Nat.mul_le_mul hdn_lt_nat.le hdn_lt_nat.le
            _ = 2 ^ (2 * B) := by rw [← pow_add, two_mul]
        dsimp [dn]
        exact_mod_cast hnat_le
      change
        0 ≤ prev.1 * (dn * dn) + p * p * prev.2 ∧
        1 ≤ prev.2 * (dn * dn) ∧
        prev.1 * (dn * dn) + p * p * prev.2 ≤
          ((k + 1 : ℕ) : ℤ) * ((2 : ℤ) ^ (2 * B) * (prev.2 * (dn * dn))) ∧
        prev.2 * (dn * dn) ≤ (2 : ℤ) ^ (2 * (k + 1) * B) ∧
        (((prev.1 * (dn * dn) + p * p * prev.2 : ℤ) : ℚ) /
          ((prev.2 * (dn * dn) : ℤ) : ℚ)) =
          ∑ i : Fin (k + 1), (q ⟨i.1, lt_of_lt_of_le i.2 hk⟩) ^ 2
      refine ⟨by nlinarith, by nlinarith, ?_, ?_, ?_⟩
      · calc
          prev.1 * (dn * dn) + p * p * prev.2
              ≤ ((k : ℤ) * ((2 : ℤ) ^ (2 * B) * prev.2)) * (dn * dn) +
                  (2 : ℤ) ^ (2 * B) * prev.2 := by
                have h1 : prev.1 * (dn * dn) ≤
                    ((k : ℤ) * ((2 : ℤ) ^ (2 * B) * prev.2)) * (dn * dn) :=
                  mul_le_mul_of_nonneg_right hn_ub (by linarith)
                have h2 : p * p * prev.2 ≤ (2 : ℤ) ^ (2 * B) * prev.2 :=
                  mul_le_mul_of_nonneg_right hp_sq_le (by linarith)
                linarith
          _ ≤ ((k : ℤ) * ((2 : ℤ) ^ (2 * B) * prev.2)) * (dn * dn) +
                (2 : ℤ) ^ (2 * B) * (prev.2 * (dn * dn)) := by
                have h3 : (2 : ℤ) ^ (2 * B) * prev.2 ≤
                    (2 : ℤ) ^ (2 * B) * (prev.2 * (dn * dn)) := by
                  apply mul_le_mul_of_nonneg_left _ (by positivity)
                  nlinarith
                linarith
          _ = ((k + 1 : ℕ) : ℤ) * ((2 : ℤ) ^ (2 * B) * (prev.2 * (dn * dn))) := by
                push_cast
                ring
      · calc
          prev.2 * (dn * dn) ≤ (2 : ℤ) ^ (2 * k * B) * (2 : ℤ) ^ (2 * B) :=
            mul_le_mul hd_ub hdn_sq_le (by linarith) (by positivity)
          _ = (2 : ℤ) ^ (2 * (k + 1) * B) := by
            rw [← pow_add]
            congr 1
            ring
      · have hd_ne : (prev.2 : ℚ) ≠ 0 := by exact_mod_cast (show prev.2 ≠ 0 by linarith)
        have hdn_ne : (dn : ℚ) ≠ 0 := by
          have : (1 : ℤ) ≤ dn := by dsimp [dn]; exact_mod_cast hdn_pos_nat
          exact_mod_cast (show dn ≠ 0 by linarith)
        have hqc_eq : (p : ℚ) / (dn : ℚ) = qc := by
          dsimp [p, dn]
          exact Rat.num_div_den qc
        rw [Fin.sum_univ_castSucc]
        dsimp only [Fin.val_castSucc, Fin.val_last]
        have hlast_eq : q ⟨k, lt_of_lt_of_le (Nat.lt_succ_self k) hk⟩ = qc := rfl
        rw [hlast_eq, ← hval, ← hqc_eq]
        push_cast
        field_simp [hd_ne, hdn_ne]

theorem sumSqPair_lt_two_pow_bLift {d B : ℕ} (hB : 1 ≤ B) {q : Fin d → ℚ}
    (hq : RatPointBitBounded B q) :
    let nd := sumSqPairAux q d le_rfl
    0 ≤ nd.1 ∧ 1 ≤ nd.2 ∧
    nd.1 < (2 : ℤ) ^ (bLiftVal d B) ∧
    nd.2 < (2 : ℤ) ^ (bLiftVal d B) ∧
    ((nd.1 : ℚ) / (nd.2 : ℚ)) = ∑ c : Fin d, (q c) ^ 2 := by
  obtain ⟨hn0, hd1, hn_ub, hd_ub, hval⟩ := sumSqPairAux_spec hq d le_rfl
  set nd := sumSqPairAux q d le_rfl
  have hd_lt_2d : (d : ℤ) < (2 : ℤ) ^ (d + 1) := by
    have hnat : d < 2 ^ (d + 1) :=
      (Nat.lt_two_pow_self (n := d)).trans_le (Nat.pow_le_pow_right (by norm_num) (by omega))
    exact_mod_cast hnat
  have hn_lt : nd.1 < (2 : ℤ) ^ (bLiftVal d B) := by
    have h1 : nd.1 ≤ (d : ℤ) * ((2 : ℤ) ^ (2 * B) * (2 : ℤ) ^ (2 * d * B)) := by
      refine hn_ub.trans ?_
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      exact mul_le_mul_of_nonneg_left hd_ub (by positivity)
    have h2 : (d : ℤ) * ((2 : ℤ) ^ (2 * B) * (2 : ℤ) ^ (2 * d * B)) <
        (2 : ℤ) ^ (d + 1) * ((2 : ℤ) ^ (2 * B) * (2 : ℤ) ^ (2 * d * B)) :=
      mul_lt_mul_of_pos_right hd_lt_2d (by positivity)
    have h3 : (2 : ℤ) ^ (d + 1) * ((2 : ℤ) ^ (2 * B) * (2 : ℤ) ^ (2 * d * B)) ≤
        (2 : ℤ) ^ (bLiftVal d B) := by
      rw [← pow_add, ← pow_add]
      have hexp : (d + 1) + (2 * B + 2 * d * B) ≤ bLiftVal d B := by
        unfold bLiftVal
        nlinarith
      exact pow_le_pow_right₀ (by norm_num) hexp
    linarith
  have hd_lt : nd.2 < (2 : ℤ) ^ (bLiftVal d B) := by
    have hexp : 2 * d * B < bLiftVal d B := by
      unfold bLiftVal
      nlinarith
    have hpow : (2 : ℤ) ^ (2 * d * B) < (2 : ℤ) ^ (bLiftVal d B) :=
      pow_lt_pow_right₀ (by norm_num : (1 : ℤ) < 2) hexp
    exact hd_ub.trans_lt hpow
  refine ⟨hn0, hd1, hn_lt, hd_lt, ?_⟩
  simpa using hval

/-! ### 3. Bounded-iteration Euclidean GCD and exact `ℚ` `.num`/`.den` extraction -/

/-- Single step of bounded-iteration Euclidean GCD. -/
def gcdStep (ab : ℕ × ℕ) : ℕ × ℕ :=
  if ab.2 = 0 then (ab.1, 0) else (ab.2, ab.1 % ab.2)

theorem gcdStep_gcd (ab : ℕ × ℕ) :
    Nat.gcd (gcdStep ab).1 (gcdStep ab).2 = Nat.gcd ab.1 ab.2 := by
  unfold gcdStep
  split_ifs with h
  · simp [h]
  · dsimp only
    rw [Nat.gcd_comm, ← Nat.gcd_rec, Nat.gcd_comm]

theorem gcdStep_bounds (ab : ℕ × ℕ) :
    (gcdStep ab).1 ≤ max ab.1 ab.2 ∧ (gcdStep ab).2 ≤ ab.2 := by
  unfold gcdStep
  split_ifs with h
  · exact ⟨le_max_left _ _, by omega⟩
  · refine ⟨le_max_right _ _, ?_⟩
    exact (Nat.mod_lt ab.1 (Nat.pos_of_ne_zero h)).le

private theorem two_mul_mod_lt {b b₁ : ℕ} (hb₁ : 0 < b₁) (hlt : b₁ < b) :
    2 * (b % b₁) < b := by
  by_cases h2 : 2 * b₁ ≤ b
  · have hm : b % b₁ < b₁ := Nat.mod_lt b hb₁
    omega
  · have hsub_lt : b - b₁ < b₁ := by omega
    have hmod : b % b₁ = b - b₁ := by
      rw [Nat.mod_eq_sub_mod (le_of_lt hlt), Nat.mod_eq_of_lt hsub_lt]
    omega

theorem gcdStep_iter_spec :
    ∀ (K a b : ℕ), b < 2 ^ K →
      (gcdStep^[2 * K] (a, b)) = (Nat.gcd a b, 0) := by
  intro K
  induction K with
  | zero =>
      intro a b hb
      have hb0 : b = 0 := by simp at hb; omega
      subst hb0
      simp
  | succ K ih =>
      intro a b hb
      have hstep2 :
          gcdStep^[2 * (K + 1)] (a, b) = gcdStep^[2 * K] (gcdStep (gcdStep (a, b))) := by
        have hexp : 2 * (K + 1) = 2 * K + 2 := by omega
        rw [hexp, Function.iterate_add_apply]
        rfl
      rw [hstep2]
      let p1 := gcdStep (a, b)
      let p2 := gcdStep p1
      have hp2_lt : p2.2 < 2 ^ K := by
        by_cases hb0 : b = 0
        · subst hb0
          simp [p2, p1, gcdStep]
        · have hb_pos : 0 < b := Nat.pos_of_ne_zero hb0
          have hp1_eq : p1 = (b, a % b) := by simp [p1, gcdStep, hb0]
          by_cases hm0 : a % b = 0
          · simp [p2, hp1_eq, gcdStep, hm0]
          · have hm_pos : 0 < a % b := Nat.pos_of_ne_zero hm0
            have hm_lt : a % b < b := Nat.mod_lt a hb_pos
            have hp2_eq : p2 = (a % b, b % (a % b)) := by simp [p2, hp1_eq, gcdStep, hm0]
            have h2lt : 2 * p2.2 < b := by
              rw [hp2_eq]
              exact two_mul_mod_lt hm_pos hm_lt
            have hpow : 2 ^ (K + 1) = 2 * 2 ^ K := by rw [pow_succ, mul_comm]
            omega
      rw [ih p2.1 p2.2 hp2_lt]
      congr 1
      dsimp [p2, p1]
      rw [gcdStep_gcd, gcdStep_gcd]

/-- Pure specification of fraction reduction by `2 * K` Euclidean GCD steps. -/
def reduceRatPair (K : ℕ) (num den : ℤ) : ℤ × ℤ :=
  let g : ℕ := (gcdStep^[2 * K] (num.natAbs, den.natAbs)).1
  (num / (g : ℤ), den / (g : ℤ))

theorem reduceRatPair_spec {K : ℕ} {num den : ℤ} {q : ℚ}
    (hden_pos : 0 < den) (hden_lt : den.natAbs < 2 ^ K)
    (hq : q = (num : ℚ) / (den : ℚ)) :
    reduceRatPair K num den = (q.num, (q.den : ℤ)) := by
  unfold reduceRatPair
  rw [gcdStep_iter_spec K num.natAbs den.natAbs hden_lt]
  dsimp only
  set g : ℕ := Nat.gcd num.natAbs den.natAbs
  have hden_nat_pos : 0 < den.natAbs := Int.natAbs_pos.mpr hden_pos.ne'
  have hg_pos : 0 < g := Nat.gcd_pos_of_pos_right _ hden_nat_pos
  have hg_dvd_num_abs : g ∣ num.natAbs := Nat.gcd_dvd_left _ _
  have hg_dvd_den_abs : g ∣ den.natAbs := Nat.gcd_dvd_right _ _
  have hg_dvd_num : (g : ℤ) ∣ num := Int.natCast_dvd.mpr hg_dvd_num_abs
  have hg_dvd_den : (g : ℤ) ∣ den := Int.natCast_dvd.mpr hg_dvd_den_abs
  set n' : ℤ := num / (g : ℤ)
  set d_nat : ℕ := den.natAbs / g
  have hden_eq_nat : den = (den.natAbs : ℤ) := (Int.natAbs_of_nonneg hden_pos.le).symm
  have hd'_eq : den / (g : ℤ) = (d_nat : ℤ) := by
    rw [hden_eq_nat]
    exact_mod_cast rfl
  rw [hd'_eq]
  have hn_mul : num = n' * (g : ℤ) := (Int.ediv_mul_cancel hg_dvd_num).symm
  have hd_mul_nat : den.natAbs = d_nat * g := (Nat.div_mul_cancel hg_dvd_den_abs).symm
  have hd_pos : 0 < d_nat := by
    refine Nat.pos_of_ne_zero fun hd_zero => ?_
    rw [hd_zero, zero_mul] at hd_mul_nat
    exact hden_nat_pos.ne' hd_mul_nat
  have hn_abs_eq : n'.natAbs = num.natAbs / g := by
    have h1 : num.natAbs = (n' * (g : ℤ)).natAbs := congrArg Int.natAbs hn_mul
    rw [Int.natAbs_mul, Int.natAbs_natCast] at h1
    exact Nat.eq_div_of_mul_eq_left hg_pos.ne' h1.symm
  have hcop : Nat.Coprime n'.natAbs d_nat := by
    rw [hn_abs_eq]
    exact Nat.coprime_div_gcd_div_gcd hg_pos
  have hq_eq : (q.num : ℚ) / (q.den : ℚ) = (n' : ℚ) / (d_nat : ℚ) := by
    rw [Rat.num_div_den, hq, hn_mul, hden_eq_nat, hd_mul_nat]
    push_cast
    have hg_ne : (g : ℚ) ≠ 0 := by exact_mod_cast hg_pos.ne'
    exact mul_div_mul_right (n' : ℚ) (d_nat : ℚ) hg_ne
  have hqd_ne : (q.den : ℚ) ≠ 0 := by exact_mod_cast q.pos.ne'
  have hd_ne : (d_nat : ℚ) ≠ 0 := by exact_mod_cast hd_pos.ne'
  have hcross_q : (q.num : ℚ) * (d_nat : ℚ) = (n' : ℚ) * (q.den : ℚ) :=
    (div_eq_div_iff hqd_ne hd_ne).mp hq_eq
  have hcross_z : q.num * (d_nat : ℤ) = n' * (q.den : ℤ) := by exact_mod_cast hcross_q
  have hcross_nat : q.num.natAbs * d_nat = n'.natAbs * q.den := by
    have h1 := congrArg Int.natAbs hcross_z
    simpa [Int.natAbs_mul] using h1
  have hdvd1 : q.den ∣ d_nat :=
    q.reduced.symm.dvd_of_dvd_mul_left ⟨n'.natAbs, by linarith [hcross_nat]⟩
  have hdvd2 : d_nat ∣ q.den :=
    hcop.symm.dvd_of_dvd_mul_left ⟨q.num.natAbs, by linarith [hcross_nat]⟩
  have hden_eq : q.den = d_nat := Nat.dvd_antisymm hdvd1 hdvd2
  have hnum_eq : q.num = n' := by
    rw [hden_eq] at hcross_z
    exact mul_right_cancel₀ (by exact_mod_cast hd_pos.ne') hcross_z
  rw [hnum_eq, hden_eq]

theorem ratCoordBitBounded_of_div {L : ℕ} {num den : ℤ} {q : ℚ}
    (hL : 1 ≤ L) (hden_pos : 0 < den) (hq : q = (num : ℚ) / (den : ℚ))
    (hn_lt : num.natAbs < 2 ^ L) (hd_lt : den.natAbs < 2 ^ L) :
    RatCoordBitBounded L q := by
  have hred := reduceRatPair_spec (K := L) hden_pos hd_lt hq
  unfold reduceRatPair at hred
  rw [gcdStep_iter_spec _ _ _ hd_lt] at hred
  dsimp only at hred
  set g := Nat.gcd num.natAbs den.natAbs
  have hg_pos : 1 ≤ g := Nat.gcd_pos_of_pos_right _ (Int.natAbs_pos.mpr hden_pos.ne')
  have hg_dvd_num : (g : ℤ) ∣ num := Int.natCast_dvd.mpr (Nat.gcd_dvd_left _ _)
  have hg_dvd_den : (g : ℤ) ∣ den := Int.natCast_dvd.mpr (Nat.gcd_dvd_right _ _)
  have hnum_mul : num = q.num * (g : ℤ) := by
    rw [(Prod.mk.inj hred).1.symm]
    exact (Int.ediv_mul_cancel hg_dvd_num).symm
  have hden_mul : den = (q.den : ℤ) * (g : ℤ) := by
    rw [(Prod.mk.inj hred).2.symm]
    exact (Int.ediv_mul_cancel hg_dvd_den).symm
  have hqn_le : q.num.natAbs ≤ num.natAbs := by
    have h1 := congrArg Int.natAbs hnum_mul
    rw [Int.natAbs_mul, Int.natAbs_natCast] at h1
    calc
      q.num.natAbs ≤ q.num.natAbs * g := Nat.le_mul_of_pos_right _ hg_pos
      _ = num.natAbs := h1.symm
  have hqd_le : q.den ≤ den.natAbs := by
    have h1 := congrArg Int.natAbs hden_mul
    simp only [Int.natAbs_mul, Int.natAbs_natCast] at h1
    calc
      q.den ≤ q.den * g := Nat.le_mul_of_pos_right _ hg_pos
      _ = den.natAbs := h1.symm
  exact ⟨natBitLength_le_of_lt_two_pow hL (hqn_le.trans_lt hn_lt),
    natBitLength_le_of_lt_two_pow hL (hqd_le.trans_lt hd_lt)⟩

theorem ratPointBitBounded_liftRatPoint {d B : ℕ} (hB : 1 ≤ B) {q : Fin d → ℚ}
    (hq : RatPointBitBounded B q) :
    RatPointBitBounded (bLiftVal d B) (liftRatPoint q) := by
  intro i
  have hB_le : B ≤ bLiftVal d B := by unfold bLiftVal; nlinarith
  have hBL_pos : 1 ≤ bLiftVal d B := by unfold bLiftVal; nlinarith
  refine Fin.lastCases ?_ ?_ i
  · simp only [liftRatPoint, Fin.snoc_last]
    obtain ⟨hn0, hd1, hn_lt, hd_lt, hval⟩ := sumSqPair_lt_two_pow_bLift hB hq
    set nd := sumSqPairAux q d le_rfl
    have hnd2_abs : nd.2.natAbs < 2 ^ (bLiftVal d B) := by
      have h1 : (nd.2.natAbs : ℤ) = nd.2 := Int.natAbs_of_nonneg (by linarith)
      exact_mod_cast (h1.symm ▸ hd_lt)
    have hnd1_abs : nd.1.natAbs < 2 ^ (bLiftVal d B) := by
      have h1 : (nd.1.natAbs : ℤ) = nd.1 := Int.natAbs_of_nonneg hn0
      exact_mod_cast (h1.symm ▸ hn_lt)
    exact ratCoordBitBounded_of_div hBL_pos (by linarith) hval.symm hnd1_abs hnd2_abs
  · intro c
    simp only [liftRatPoint, Fin.snoc_castSucc]
    exact ⟨(hq c).1.trans hB_le, (hq c).2.trans hB_le⟩

theorem ratCoordBitBounded_of_num_den_intBitLength {L : ℕ} {num den : ℤ} {q : ℚ}
    (hL : 1 ≤ L) (hden_pos : 0 < den) (hq : q = (num : ℚ) / (den : ℚ))
    (hb_num : intBitLength num ≤ L) (hb_den : intBitLength den ≤ L) :
    RatCoordBitBounded L q := by
  have hnum_abs_lt : num.natAbs < 2 ^ L := by
    unfold intBitLength at hb_num
    split_ifs at hb_num with hz
    · subst hz
      have : 1 < 2 ^ L := Nat.one_lt_two_pow (by omega)
      simpa using this
    · exact nat_lt_two_pow_of_natBitLength_le (by omega)
  have hden_abs_lt : den.natAbs < 2 ^ L := by
    unfold intBitLength at hb_den
    split_ifs at hb_den with hz
    · omega
    · exact nat_lt_two_pow_of_natBitLength_le (by omega)
  exact ratCoordBitBounded_of_div hL hden_pos hq hnum_abs_lt hden_abs_lt

/-! ### 5. Centerpoint + halfspace-net implies `HasConvexHullCert`, and certificate glue -/

theorem mem_convexHull_range_imp_hasConvexHullCert {D : ℕ} {κ : Type*} [Fintype κ]
    (f : κ → EuclideanSpace ℝ (Fin D)) {z : EuclideanSpace ℝ (Fin D)}
    (hz : z ∈ convexHull ℝ (Set.range f)) :
    HasConvexHullCert f z := by
  classical
  let K : Set (EuclideanSpace ℝ (Fin D)) := {x | HasConvexHullCert f x}
  have h_sub : Set.range f ⊆ K := by
    rintro _ ⟨j₀, rfl⟩
    refine ⟨fun j => if j = j₀ then 1 else 0, ?_, ?_, ?_⟩
    · intro j; dsimp only; split_ifs <;> norm_num
    · simp
    · simp
  have h_conv : Convex ℝ K := by
    rintro x ⟨wx, hwx0, hwx1, hwx_sum⟩ y ⟨wy, hwy0, hwy1, hwy_sum⟩ a b ha hb hab
    refine ⟨fun j => a * wx j + b * wy j, ?_, ?_, ?_⟩
    · intro j; dsimp only; have := hwx0 j; have := hwy0 j; positivity
    · simp_rw [Finset.sum_add_distrib, ← Finset.mul_sum, hwx1, hwy1, mul_one]
      exact hab
    · calc
        ∑ j : κ, (a * wx j + b * wy j) • f j
            = ∑ j : κ, (a • (wx j • f j) + b • (wy j • f j)) := by
              refine Finset.sum_congr rfl fun j _ => ?_
              rw [add_smul, mul_smul, mul_smul]
        _ = a • (∑ j : κ, wx j • f j) + b • (∑ j : κ, wy j • f j) := by
              rw [Finset.sum_add_distrib, Finset.smul_sum, Finset.smul_sum]
        _ = a • x + b • y := by rw [hwx_sum, hwy_sum]
  exact convexHull_min h_sub h_conv hz

theorem centerpoint_and_net_imp_hasConvexHullCert {D : ℕ} {ι : Type*} [Fintype ι] [DecidableEq ι]
    {α₀ : ℝ} {Q : ι → EuclideanSpace ℝ (Fin D)} {z : EuclideanSpace ℝ (Fin D)}
    {s₀ : ℕ} (hs₀ : 1 ≤ s₀) {blk : Fin s₀ → ι}
    (hcp : IsCenterpoint α₀ Q z)
    (hnet : IsHalfspaceNet α₀ Q (Finset.univ.image blk)) :
    HasConvexHullCert (fun j : Fin s₀ => Q (blk j)) z := by
  classical
  apply mem_convexHull_range_imp_hasConvexHullCert
  let K : Set (EuclideanSpace ℝ (Fin D)) :=
    convexHull ℝ (Set.range (fun j : Fin s₀ => Q (blk j)))
  change z ∈ K
  by_contra hz_not_K
  have hK_conv : Convex ℝ K := convex_convexHull ℝ _
  have hK_closed : IsClosed K := (Set.finite_range _).isClosed_convexHull
  obtain ⟨f, u, hf_z, hf_K⟩ := geometric_hahn_banach_point_closed hK_conv hK_closed hz_not_K
  let j₀ : Fin s₀ := ⟨0, by omega⟩
  have hQj0_K : Q (blk j₀) ∈ K := subset_convexHull ℝ _ ⟨j₀, rfl⟩
  have hf_ne : f ≠ 0 := by
    intro hf0
    rw [hf0] at hf_z hf_K
    have h1 : (0 : ℝ) < u := by simpa using hf_z
    have h2 : u < (0 : ℝ) := by simpa using hf_K _ hQj0_K
    linarith
  let v : EuclideanSpace ℝ (Fin D) :=
    (InnerProductSpace.toDual ℝ (EuclideanSpace ℝ (Fin D))).symm f
  have hv_ne : v ≠ 0 := by simpa [v] using hf_ne
  let H : Set (EuclideanSpace ℝ (Fin D)) := {x | inner ℝ v x ≤ u}
  have hH_closed : IsClosedHalfspace H := ⟨v, hv_ne, u, rfl⟩
  have hzH : z ∈ H := by
    simp only [H, Set.mem_setOf_eq, v, InnerProductSpace.toDual_symm_apply]
    exact hf_z.le
  have hdepth_le : halfspaceDepth Q z ≤ pointCount Q H :=
    Nat.sInf_le ⟨H, hH_closed, hzH, rfl⟩
  have hcnt_ge : α₀ * (Fintype.card ι : ℝ) ≤ (pointCount Q H : ℝ) :=
    hcp.trans (by exact_mod_cast hdepth_le)
  obtain ⟨i, hi_mem, hiH⟩ := hnet H hH_closed hcnt_ge
  rcases Finset.mem_image.mp hi_mem with ⟨j, _, rfl⟩
  have hle : f (Q (blk j)) ≤ u := by
    simpa [H, v, InnerProductSpace.toDual_symm_apply] using hiH
  have hgt : u < f (Q (blk j)) := hf_K _ (subset_convexHull ℝ _ ⟨j, rfl⟩)
  linarith

theorem indexedCert_to_blockCert {d k s₀ : ℕ} {ι : Type*} [DecidableEq ι]
    {ptsE : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {z : EuclideanSpace ℝ (Fin (d + 1))}
    {blocks : Fin k → Fin s₀ → ι} {w : Fin k → Fin s₀ → ℝ}
    (hinj : Function.Injective (fun p : Fin k × Fin s₀ => blocks p.1 p.2))
    (hcert : ∀ b : Fin k, IsIndexedBlockCertificate ptsE P₀ z (blocks b) (w b)) :
    let blockSet : Fin k → Finset ι := fun b => Finset.univ.image (blocks b)
    (∀ b : Fin k, (blockSet b).card = s₀) ∧
    (∀ b₁ b₂ : Fin k, b₁ ≠ b₂ → Disjoint (blockSet b₁) (blockSet b₂)) ∧
    (∀ b : Fin k, IsBlockCertificate ptsE P₀ z (blockSet b)
      (fun i => ∑ j : Fin s₀, if blocks b j = i then w b j else 0)) := by
  dsimp only
  have hinj_b : ∀ b : Fin k, Function.Injective (blocks b) := by
    intro b j₁ j₂ h
    exact (Prod.mk.inj (@hinj (b, j₁) (b, j₂) h)).2
  refine ⟨?_, ?_, ?_⟩
  · intro b
    rw [Finset.card_image_of_injective _ (hinj_b b), Finset.card_univ, Fintype.card_fin]
  · intro b₁ b₂ hne
    rw [Finset.disjoint_left]
    intro x hx₁ hx₂
    rcases Finset.mem_image.mp hx₁ with ⟨j₁, _, rfl⟩
    rcases Finset.mem_image.mp hx₂ with ⟨j₂, _, heq⟩
    have hp := @hinj (b₂, j₂) (b₁, j₁) heq
    exact hne (Prod.mk.inj hp).1.symm
  · intro b
    obtain ⟨hmem, hw0, hw1, hwz⟩ := hcert b
    have hcoeff_eq : ∀ j₀ : Fin s₀,
        (∑ j : Fin s₀, if blocks b j = blocks b j₀ then w b j else 0) = w b j₀ := by
      intro j₀
      have hite : ∀ j : Fin s₀,
          (if blocks b j = blocks b j₀ then w b j else 0) =
            (if j = j₀ then w b j else 0) := by
        intro j
        by_cases h : j = j₀
        · subst h; simp
        · have hne : blocks b j ≠ blocks b j₀ := fun heq => h (hinj_b b heq)
          simp [h, hne]
      simp_rw [hite]
      simp
    refine ⟨?_, ?_, ?_, ?_⟩
    · intro x hx
      rcases Finset.mem_image.mp hx with ⟨j, _, rfl⟩
      exact hmem j
    · intro x _
      exact Finset.sum_nonneg fun j _ => by split_ifs; exacts [hw0 j, le_rfl]
    · rw [Finset.sum_image (fun j₁ _ j₂ _ h => hinj_b b h)]
      simp_rw [hcoeff_eq]
      exact hw1
    · rw [Finset.sum_image (fun j₁ _ j₂ _ h => hinj_b b h)]
      simp_rw [hcoeff_eq]
      exact hwz

theorem k_pass_ge_quarter {m s₀ k : ℕ} (hs₀ : 1 ≤ s₀) (hm : 2 * s₀ ≤ m)
    (hk : m / s₀ ≤ 2 * k) :
    1 ≤ k ∧ (m : ℝ) / (4 * (s₀ : ℝ)) ≤ (k : ℝ) := by
  set r : ℕ := m / s₀
  have hr2 : 2 ≤ r := by
    have : 2 * s₀ / s₀ ≤ m / s₀ := Nat.div_le_div_right hm
    rwa [Nat.mul_div_cancel _ (by omega)] at this
  have hk1 : 1 ≤ k := by omega
  refine ⟨hk1, ?_⟩
  have hm_lt : m < (r + 1) * s₀ := by
    have hdiv : s₀ * r + m % s₀ = m := Nat.div_add_mod m s₀
    have hmod : m % s₀ < s₀ := Nat.mod_lt m (by omega)
    nlinarith
  have hr1_le : r + 1 ≤ 4 * k := by omega
  have hmul : m ≤ 4 * k * s₀ := by nlinarith
  have hs0_pos : (0 : ℝ) < 4 * (s₀ : ℝ) := by positivity
  rw [div_le_iff₀ hs0_pos]
  have hreal : (m : ℝ) ≤ 4 * (k : ℝ) * (s₀ : ℝ) := by exact_mod_cast hmul
  linarith


end UL.Proof_lem_A_2
