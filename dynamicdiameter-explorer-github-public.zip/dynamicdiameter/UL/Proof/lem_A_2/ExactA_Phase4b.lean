import Mathlib
import UL.Proof.lem_A_2.ExactA_Phase4a
set_option autoImplicit false
set_option linter.unusedSimpArgs false
set_option maxHeartbeats 1600000

namespace UL.Proof_lem_A_2

/-! ### 1. Substage D: Frequency count, good-core placement, and two-pass unused fill -/

def p4dInitBody : BitRAMStmt :=
  .seq (.writeLocal 22 (.readLocal 11 (.lit 0)) (.lit 0))
  (.seq (.writeLocal 23 (.readLocal 11 (.lit 0)) (.lit 0))
  (.seq (.writeLocal 5 (.readLocal 11 (.lit 0)) (.lit (-1)))
        (.writeLocal 11 (.lit 0) (.add (.readLocal 11 (.lit 0)) (.lit 1)))))

def p4dInitStmt : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 0) (.lit 0))
       (.repeatN (.readLocal 0 (.lit 2)) p4dInitBody)

def p4dFreqBody : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 1) (.readLocal 21 (.readLocal 11 (.lit 0))))
  (.seq (.writeLocal 22 (.readLocal 11 (.lit 1))
          (.add (.readLocal 22 (.readLocal 11 (.lit 1))) (.lit 1)))
        (.writeLocal 11 (.lit 0) (.add (.readLocal 11 (.lit 0)) (.lit 1))))

def p4dFreqStmt : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 0) (.lit 0))
       (.repeatN (.readLocal 10 (.lit 2)) p4dFreqBody)

def p4dCheckInnerBody : BitRAMStmt :=
  .seq (.writeLocal 12 (.lit 0)
          (.readLocal 21 (.add (.mul (.readLocal 11 (.lit 0)) (.readLocal 10 (.lit 0)))
                               (.readLocal 11 (.lit 2)))))
  (.seq (.ite (.intEq (.readLocal 22 (.readLocal 12 (.lit 0))) (.lit 1))
              .skip
              (.writeLocal 11 (.lit 1) (.lit 0)))
        (.writeLocal 11 (.lit 2) (.add (.readLocal 11 (.lit 2)) (.lit 1))))

def p4dPlaceInnerBody : BitRAMStmt :=
  .seq (.writeLocal 12 (.lit 0)
          (.readLocal 21 (.add (.mul (.readLocal 11 (.lit 0)) (.readLocal 10 (.lit 0)))
                               (.readLocal 11 (.lit 2)))))
  (.seq (.writeLocal 5 (.add (.mul (.readLocal 11 (.lit 0)) (.readLocal 0 (.lit 5)))
                             (.readLocal 11 (.lit 2)))
          (.readLocal 12 (.lit 0)))
  (.seq (.writeLocal 23 (.readLocal 12 (.lit 0)) (.lit 1))
        (.writeLocal 11 (.lit 2) (.add (.readLocal 11 (.lit 2)) (.lit 1)))))

def p4dPlaceOuterBody : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 1) (.lit 1))
  (.seq (.writeLocal 11 (.lit 2) (.lit 0))
  (.seq (.repeatN (.readLocal 10 (.lit 0)) p4dCheckInnerBody)
  (.seq (.ite (.intEq (.readLocal 11 (.lit 1)) (.lit 1))
              (.seq (.writeLocal 11 (.lit 2) (.lit 0))
                    (.repeatN (.readLocal 10 (.lit 0)) p4dPlaceInnerBody))
              .skip)
        (.writeLocal 11 (.lit 0) (.add (.readLocal 11 (.lit 0)) (.lit 1))))))

def p4dPlaceStmt : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 0) (.lit 0))
       (.repeatN (.readLocal 0 (.lit 6)) p4dPlaceOuterBody)

def p4dUnusedBody : BitRAMStmt :=
  .seq (.ite (.intEq (.readLocal 23 (.readLocal 11 (.lit 0))) (.lit 0))
             (.seq (.writeLocal 24 (.readLocal 11 (.lit 1)) (.readLocal 11 (.lit 0)))
                   (.writeLocal 11 (.lit 1) (.add (.readLocal 11 (.lit 1)) (.lit 1))))
             .skip)
       (.writeLocal 11 (.lit 0) (.add (.readLocal 11 (.lit 0)) (.lit 1)))

def p4dUnusedStmt : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 0) (.lit 0))
  (.seq (.writeLocal 11 (.lit 1) (.lit 0))
        (.repeatN (.readLocal 0 (.lit 2)) p4dUnusedBody))

def p4dFillBody : BitRAMStmt :=
  .seq (.ite (.intEq (.readLocal 5 (.readLocal 11 (.lit 0))) (.lit (-1)))
             (.seq (.writeLocal 5 (.readLocal 11 (.lit 0))
                     (.readLocal 24 (.readLocal 11 (.lit 1))))
                   (.writeLocal 11 (.lit 1) (.add (.readLocal 11 (.lit 1)) (.lit 1))))
             .skip)
       (.writeLocal 11 (.lit 0) (.add (.readLocal 11 (.lit 0)) (.lit 1)))

def p4dFillStmt : BitRAMStmt :=
  .seq (.writeLocal 11 (.lit 0) (.lit 0))
  (.seq (.writeLocal 11 (.lit 1) (.lit 0))
        (.repeatN (.readLocal 0 (.lit 2)) p4dFillBody))

def p4dBuildPermStmt : BitRAMStmt :=
  .seq p4dInitStmt
  (.seq p4dFreqStmt
  (.seq p4dPlaceStmt
  (.seq p4dUnusedStmt
        p4dFillStmt)))

private def optToInt {m : ℕ} : Option (Fin m) → ℤ
  | some y => (y.1 : ℤ)
  | none => -1

theorem exec_p4dBuildPermStmt {A V M K₀ deg_α₀ : ℕ} (p : CoreParams)
    (g_hat : Fin (p.r * s₁Val K₀ deg_α₀ p.d) → Fin p.m)
    {inp : BitRAMInput p.d} {ws₃ : WordStore} {bs : List Bool}
    (hK₀ : 1 ≤ K₀)
    (hpK : p.K = 25 * K₀ ^ 2)
    (hpdeg : p.deg_α = 2 * deg_α₀ + 1)
    (harena : InAttemptArena A V ws₃)
    (hregs : HasPhase2Regs p M ws₃)
    (hcst : HasP4Consts p K₀ deg_α₀ ws₃)
    (hghat : ∀ t : Fin (p.r * s₁Val K₀ deg_α₀ p.d),
      ws₃.read (.localFrame 1 21 (t.1 : ℤ)) = ((g_hat t).1 : ℤ))
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p) :
    let s₁ := s₁Val K₀ deg_α₀ p.d
    have hs₁_1 : 1 ≤ s₁ := by have := s₁Val_ge_144 (deg_α := deg_α₀) hK₀ p.d; omega
    have hs₁_le_s₀ : s₁ ≤ p.s₀ := by
      have hs₁_2 : 2 ≤ s₁ := by have := s₁Val_ge_144 (deg_α := deg_α₀) hK₀ p.d; omega
      have hs₀_ge : 64 * s₁ ^ 2 ≤ p.s₀ := by
        dsimp [CoreParams.s₀, s₁]; rw [hpK, hpdeg]; exact sixtyFour_s₁Val_sq_le_s₀Val hK₀ p.d
      exact (polyPerm_arith hs₁_2 hs₀_ge hfit.2.2.2.1).2.2.1
    have hrs : p.r * p.s₀ ≤ p.m := Nat.div_mul_le_self p.m p.s₀
    ∃ ws₅ : WordStore,
      InAttemptArena A V ws₅ ∧
      PreserveOutside4 ws₃ ws₅ ∧
      HasPermArray p.m (coreFillPerm hs₁_1 hs₁_le_s₀ hrs g_hat) ws₅ ∧
      ExecBounded inp p4dBuildPermStmt ws₃ bs ws₅ bs
        (2000 + 5000 * p.m)
        ((2000000 + 5000000 * p.m) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  dsimp only
  let s₁ := s₁Val K₀ deg_α₀ p.d
  have hs₁_144 : 144 ≤ s₁ := s₁Val_ge_144 (deg_α := deg_α₀) hK₀ p.d
  have hs₁_1 : 1 ≤ s₁ := by omega
  have hs₁_2 : 2 ≤ s₁ := by omega
  have hs₀_ge : 64 * s₁ ^ 2 ≤ p.s₀ := by
    dsimp [CoreParams.s₀, s₁]; rw [hpK, hpdeg]; exact sixtyFour_s₁Val_sq_le_s₀Val hK₀ p.d
  have hm2s : 2 * p.s₀ ≤ p.m := hfit.2.2.2.1
  obtain ⟨hm512, _, hs₁_le_s₀, hrs, h64rs, hrs1_lt, _, _, _, _, _, _, _⟩ :=
    polyPerm_arith_core p hs₁_2 hs₀_ge hm2s
  have h2s1_lt_m : 2 * s₁ < p.m := by nlinarith
  have hr_le_m : p.r ≤ p.m := Nat.div_le_self p.m p.s₀
  have hrs1_le_m : p.r * s₁ ≤ p.m := le_of_lt hrs1_lt
  have hrs_only : p.r * s₁ ≤ p.m := hrs1_le_m
  have hmA : 2 * p.m + 4 * p.D + 16 ≤ A := hfit.2.2.2.2.2.1
  have hwV : 2 * p.w + 32 ≤ V := hfit.2.2.2.2.2.2.2.2.1
  have hV16 : 16 ≤ V := by have := hinp.2.1; omega
  have hib_2m : ∀ {x : ℕ}, x ≤ 2 * p.m → intBitLength (x : ℤ) ≤ V :=
    fun hx => ibl_le_V_of_le_four_m_sq (by omega) hwV (by nlinarith)
  have hib_neg1 : intBitLength (-1 : ℤ) ≤ V := by
    have : intBitLength (-1 : ℤ) = 2 := by decide
    omega
  -- D.1: `p4dInitStmt`
  obtain ⟨ha_d1_0, ex_d1_0⟩ := exec_wl_reg 11 0 (.lit 0) harena hinp (val := 0) rfl (ibl_zero_le hV16)
  have hp_d1_0 : PreserveOutside4 ws₃ (wsOf ha_d1_0) :=
    (preserveOutside4_refl ws₃).write_local 0 _ (Or.inr (Or.inr (by decide)))
  let InvInit : ℕ → WordStore → List Bool → Prop := fun k ws_k bs_k =>
    bs_k = bs ∧
    InAttemptArena A V ws_k ∧
    PreserveOutside4 ws₃ ws_k ∧
    HasP4Consts p K₀ deg_α₀ ws_k ∧
    (∀ t : Fin (p.r * s₁), ws_k.read (.localFrame 1 21 (t.1 : ℤ)) = ((g_hat t).1 : ℤ)) ∧
    ws_k.read (.localFrame 1 11 0) = (k : ℤ) ∧
    (∀ i : Fin p.m, i.1 < k →
      ws_k.read (.localFrame 1 22 (i.1 : ℤ)) = 0 ∧
      ws_k.read (.localFrame 1 23 (i.1 : ℤ)) = 0 ∧
      ws_k.read (.localFrame 1 5 (i.1 : ℤ)) = -1)
  have hInvInit0 : InvInit 0 (wsOf ha_d1_0) bs :=
    ⟨rfl, ha_d1_0, hp_d1_0,
     hasP4Consts_of_eq hcst (fun _ => rw_local_var_ne _ (by decide)),
     fun t => (rw_local_var_ne _ (by decide)).trans (hghat t),
     wordStore_read_write_self _ _ _,
     fun _ h => by omega⟩
  obtain ⟨wsI, bsI, hInvIEnd, ex_d1_loop⟩ := exec_repeatN_inv (bs₀ := bs)
    (U := 68 + (68 + (68 + 68)))
    (B := 66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2)))
    (countE := .readLocal 0 (.lit 2)) (body := p4dInitBody) p.m InvInit ha_d1_0 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by have hm0 := (hp_d1_0.2 0 2 (by decide) (by decide) (by decide)).trans hregs.1.2.2.1
        dsimp [wsOf] at hm0; simp [hm0])
    hInvInit0
    (fun k ws_k bs_k hk hInv_k => by
      rcases hInv_k with ⟨hbs_k, ha_k, hp_k, hcst_k, hg_k, hr11_0, hdone_k⟩; subst bs_k
      obtain ⟨ha_22, ex_22⟩ := exec_wl ha_k hinp
        (var := 22) (idxE := .readLocal 11 (.lit 0)) (idx := (k : ℤ)) (valE := .lit 0) (val := 0)
        (by simp [hr11_0]) rfl (by positivity) (by rw [Int.toNat_natCast]; try omega) (ibl_zero_le hV16)
      obtain ⟨ha_23, ex_23⟩ := exec_wl ha_22 hinp
        (var := 23) (idxE := .readLocal 11 (.lit 0)) (idx := (k : ℤ)) (valE := .lit 0) (val := 0)
        (by simp [wsOf, rw_write_eq, hr11_0]) rfl (by positivity) (by rw [Int.toNat_natCast]; try omega) (ibl_zero_le hV16)
      obtain ⟨ha_5, ex_5⟩ := exec_wl ha_23 hinp
        (var := 5) (idxE := .readLocal 11 (.lit 0)) (idx := (k : ℤ)) (valE := .lit (-1)) (val := -1)
        (by simp [wsOf, rw_write_eq, hr11_0]) rfl (by positivity) (by rw [Int.toNat_natCast]; try omega) hib_neg1
      obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) ha_5 hinp (val := ((k + 1 : ℕ) : ℤ))
        (by simp [wsOf, rw_write_eq, hr11_0]; try (push_cast; ring)) (hib_2m (by omega))
      have hp_nx : PreserveOutside4 ws₃ (wsOf ha_nx) :=
        (((hp_k.write_local (k : ℤ) _ (Or.inr (Or.inr (by decide)))).write_local
           (k : ℤ) _ (Or.inr (Or.inr (by decide)))).write_local
           (k : ℤ) _ (Or.inr (Or.inl rfl))).write_local
           0 _ (Or.inr (Or.inr (by decide)))
      refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx, hp_nx,
        hasP4Consts_of_eq hcst_k (fun _ => by simp [wsOf, rw_write_eq]),
        fun t => by simp [wsOf, rw_write_eq, hg_k t],
        wordStore_read_write_self _ _ _,
        fun i hi => by
          rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hi) with hlt | heq
          · have hne : (i.1 : ℤ) ≠ (k : ℤ) := by omega
            obtain ⟨z22, z23, z5⟩ := hdone_k i hlt
            refine ⟨?_, ?_, ?_⟩
            · simp [wsOf, rw_write_eq, hne, z22]
            · simp [wsOf, rw_write_eq, hne, z23]
            · simp [wsOf, rw_write_eq, hne, z5]
          · have hi_eq : i = ⟨k, hk⟩ := Fin.ext heq
            subst hi_eq
            simp [wsOf, rw_write_eq]⟩,
        ExecBounded.seq ex_22 (ExecBounded.seq ex_23 (ExecBounded.seq ex_5 ex_nx))⟩)
  rcases hInvIEnd with ⟨hbsI, haI, hpI, hcstI, hgI, _, hinit_end⟩; subst bsI
  have ex_d1 := ExecBounded.seq ex_d1_0 ex_d1_loop
  -- D.2: `p4dFreqStmt`
  obtain ⟨ha_d2_0, ex_d2_0⟩ := exec_wl_reg 11 0 (.lit 0) haI hinp (val := 0) rfl (ibl_zero_le hV16)
  have hp_d2_0 : PreserveOutside4 ws₃ (wsOf ha_d2_0) :=
    hpI.write_local 0 _ (Or.inr (Or.inr (by decide)))
  let InvFreq : ℕ → WordStore → List Bool → Prop := fun k ws_k bs_k =>
    bs_k = bs ∧
    InAttemptArena A V ws_k ∧
    PreserveOutside4 ws₃ ws_k ∧
    HasP4Consts p K₀ deg_α₀ ws_k ∧
    (∀ t : Fin (p.r * s₁), ws_k.read (.localFrame 1 21 (t.1 : ℤ)) = ((g_hat t).1 : ℤ)) ∧
    (∀ h : Fin p.m, ws_k.read (.localFrame 1 23 (h.1 : ℤ)) = 0) ∧
    (∀ idx : Fin p.m, ws_k.read (.localFrame 1 5 (idx.1 : ℤ)) = -1) ∧
    ws_k.read (.localFrame 1 11 0) = (k : ℤ) ∧
    (∀ h : Fin p.m,
      ws_k.read (.localFrame 1 22 (h.1 : ℤ)) =
        (((Finset.univ.filter (fun u : Fin (p.r * s₁) => u.1 < k ∧ g_hat u = h)).card : ℕ) : ℤ))
  have hInvFreq0 : InvFreq 0 (wsOf ha_d2_0) bs := by
    refine ⟨rfl, ha_d2_0, hp_d2_0,
      hasP4Consts_of_eq hcstI (fun _ => rw_local_var_ne _ (by decide)),
      fun t => (rw_local_var_ne _ (by decide)).trans (hgI t),
      fun h => (rw_local_var_ne _ (by decide)).trans (hinit_end h h.2).2.1,
      fun idx => (rw_local_var_ne _ (by decide)).trans (hinit_end idx idx.2).2.2,
      wordStore_read_write_self _ _ _,
      fun h => ?_⟩
    have h0 : Finset.univ.filter (fun u : Fin (p.r * s₁) => u.1 < 0 ∧ g_hat u = h) = ∅ := by ext x; simp
    rw [h0, Finset.card_empty, rw_local_var_ne _ (by decide)]
    exact (hinit_end h h.2).1
  obtain ⟨wsF, bsF, hInvFEnd, ex_d2_loop⟩ := exec_repeatN_inv (bs₀ := bs)
    (U := 68 + (68 + 68))
    (B := 66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2))
    (countE := .readLocal 10 (.lit 2)) (body := p4dFreqBody) (p.r * s₁) InvFreq ha_d2_0 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by simp only [wsOf, evalVal_readLocal, evalVal_lit, rw_local_var_ne _ (by decide : 10 ≠ 11)]; exact hcstI.2.2.1)
    hInvFreq0
    (fun k ws_k bs_k hk hInv_k => by
      rcases hInv_k with ⟨hbs_k, ha_k, hp_k, hcst_k, hg_k, h23_k, h5_k, hr11_0, h22_k⟩; subst bs_k
      let tk : Fin (p.r * s₁) := ⟨k, hk⟩
      let hk_val : Fin p.m := g_hat tk
      obtain ⟨ha_h, ex_h⟩ := exec_wl_reg 11 1 (.readLocal 21 (.readLocal 11 (.lit 0))) ha_k hinp (val := (hk_val.1 : ℤ))
        (by simp only [evalVal_readLocal, evalVal_lit, hr11_0]; exact hg_k tk)
        (hib_2m (by have := hk_val.2; omega))
      let oldCnt := (Finset.univ.filter (fun u : Fin (p.r * s₁) => u.1 < k ∧ g_hat u = hk_val)).card
      have hold_le : oldCnt ≤ p.r * s₁ := by
        calc oldCnt ≤ (Finset.univ : Finset (Fin (p.r * s₁))).card := Finset.card_le_card (Finset.filter_subset _ _)
          _ = p.r * s₁ := by simp
      obtain ⟨ha_inc22, ex_inc22⟩ := exec_wl ha_h hinp
        (var := 22) (idxE := .readLocal 11 (.lit 1)) (idx := (hk_val.1 : ℤ))
        (valE := .add (.readLocal 22 (.readLocal 11 (.lit 1))) (.lit 1))
        (val := ((oldCnt + 1 : ℕ) : ℤ))
        (by simp [wsOf, rw_write_eq])
        (by simp [wsOf, rw_write_eq, h22_k hk_val]; try (push_cast; ring))
        (by positivity)
        (by rw [Int.toNat_natCast]; have := hk_val.2; omega)
        (hib_2m (by omega))
      obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) ha_inc22 hinp (val := ((k + 1 : ℕ) : ℤ))
        (by simp [wsOf, rw_write_eq, hr11_0]; try (push_cast; ring))
        (hib_2m (by omega))
      have hp_nx : PreserveOutside4 ws₃ (wsOf ha_nx) :=
        ((hp_k.write_local 1 _ (Or.inr (Or.inr (by decide)))).write_local
           (hk_val.1 : ℤ) _ (Or.inr (Or.inr (by decide)))).write_local
           0 _ (Or.inr (Or.inr (by decide)))
      refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx, hp_nx,
        hasP4Consts_of_eq hcst_k (fun _ => by simp [wsOf, rw_write_eq]),
        fun t => by simp [wsOf, rw_write_eq, hg_k t],
        fun h => by simp [wsOf, rw_write_eq, h23_k h],
        fun idx => by simp [wsOf, rw_write_eq, h5_k idx],
        wordStore_read_write_self _ _ _,
        fun h => ?_⟩,
        ExecBounded.seq ex_h (ExecBounded.seq ex_inc22 ex_nx)⟩
      rw [rw_local_var_ne _ (by decide)]
      by_cases h_eq : h = hk_val
      · subst h_eq
        rw [wordStore_read_write_self]
        have hfeq : Finset.univ.filter (fun u : Fin (p.r * s₁) => u.1 < k + 1 ∧ g_hat u = hk_val) =
            insert tk (Finset.univ.filter (fun u : Fin (p.r * s₁) => u.1 < k ∧ g_hat u = hk_val)) := by
          ext u
          simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert]
          constructor
          · rintro ⟨hlt, hgu⟩
            rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hlt) with hlt' | heq
            · exact Or.inr ⟨hlt', hgu⟩
            · exact Or.inl (Fin.ext heq)
          · rintro (rfl | ⟨hlt, hgu⟩)
            · exact ⟨Nat.lt_succ_self k, rfl⟩
            · exact ⟨by omega, hgu⟩
        have hnot : tk ∉ Finset.univ.filter (fun u : Fin (p.r * s₁) => u.1 < k ∧ g_hat u = hk_val) := by
          simp [tk]
        rw [hfeq, Finset.card_insert_of_notMem hnot]
      · have hne_z : (h.1 : ℤ) ≠ (hk_val.1 : ℤ) := fun hv => h_eq (Fin.ext (Int.ofNat.inj hv))
        rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ hi; exact hne_z hi),
            rw_local_var_ne _ (by decide), h22_k h]
        have hfeq : Finset.univ.filter (fun u : Fin (p.r * s₁) => u.1 < k + 1 ∧ g_hat u = h) =
            Finset.univ.filter (fun u : Fin (p.r * s₁) => u.1 < k ∧ g_hat u = h) := by
          ext u
          simp only [Finset.mem_filter, Finset.mem_univ, true_and]
          constructor
          · rintro ⟨hlt, hgu⟩
            rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hlt) with hlt' | heq
            · exact ⟨hlt', hgu⟩
            · have hu_eq : u = tk := Fin.ext heq
              rw [hu_eq] at hgu
              exact False.elim (h_eq hgu.symm)
          · rintro ⟨hlt, hgu⟩; exact ⟨by omega, hgu⟩
        rw [hfeq])
  rcases hInvFEnd with ⟨hbsF, haF, hpF, hcstF, hgF, h23F, h5F, _, h22F_raw⟩; subst bsF
  have hfreqF : ∀ h : Fin p.m, wsF.read (.localFrame 1 22 (h.1 : ℤ)) = (freqOf g_hat h : ℤ) := by
    intro h
    rw [h22F_raw h]
    unfold freqOf
    congr 2; ext u; simp [u.2]
  have ex_d2 := ExecBounded.seq ex_d2_0 ex_d2_loop
  -- D.3: `p4dPlaceStmt` (`p.r` outer steps)
  obtain ⟨ha_d3_0, ex_d3_0⟩ := exec_wl_reg 11 0 (.lit 0) haF hinp (val := 0) rfl (ibl_zero_le hV16)
  have hp_d3_0 : PreserveOutside4 ws₃ (wsOf ha_d3_0) :=
    hpF.write_local 0 _ (Or.inr (Or.inr (by decide)))
  let placedBefore : ℕ → Fin p.m → Bool := fun b h =>
    decide (∃ b' : Fin p.r, b'.1 < b ∧ coreGood g_hat b' = true ∧
      ∃ j : Fin s₁, g_hat ⟨b'.1 * s₁ + j.1, coreIdxLt b' j⟩ = h)
  let InvPlace : ℕ → WordStore → List Bool → Prop := fun b ws_b bs_b =>
    bs_b = bs ∧
    InAttemptArena A V ws_b ∧
    PreserveOutside4 ws₃ ws_b ∧
    HasP4Consts p K₀ deg_α₀ ws_b ∧
    (∀ t : Fin (p.r * s₁), ws_b.read (.localFrame 1 21 (t.1 : ℤ)) = ((g_hat t).1 : ℤ)) ∧
    (∀ h : Fin p.m, ws_b.read (.localFrame 1 22 (h.1 : ℤ)) = (freqOf g_hat h : ℤ)) ∧
    ws_b.read (.localFrame 1 11 0) = (b : ℤ) ∧
    (∀ idx : Fin p.m,
      ws_b.read (.localFrame 1 5 (idx.1 : ℤ)) =
        if idx.1 / p.s₀ < b then optToInt (coreSlotOpt p.s₀ g_hat idx) else -1) ∧
    (∀ h : Fin p.m,
      ws_b.read (.localFrame 1 23 (h.1 : ℤ)) = if placedBefore b h then 1 else 0)
  have hInvPlace0 : InvPlace 0 (wsOf ha_d3_0) bs := by
    refine ⟨rfl, ha_d3_0, hp_d3_0,
      hasP4Consts_of_eq hcstF (fun _ => rw_local_var_ne _ (by decide)),
      fun t => (rw_local_var_ne _ (by decide)).trans (hgF t),
      fun h => (rw_local_var_ne _ (by decide)).trans (hfreqF h),
      wordStore_read_write_self _ _ _,
      fun idx => by simp [wsOf, rw_write_eq, h5F idx],
      fun h => ?_⟩
    have hf : placedBefore 0 h = false := by simp [placedBefore]
    rw [hf, if_neg Bool.false_ne_true, rw_local_var_ne _ (by decide), h23F h]
  obtain ⟨wsP, bsP, hInvPEnd, ex_d3_loop⟩ := exec_repeatN_inv (bs₀ := bs)
    (U := 600 + 600 * s₁) (B := (600000 + 600000 * s₁) * (V + 8) ^ 2)
    (countE := .readLocal 0 (.lit 6)) (body := p4dPlaceOuterBody) p.r InvPlace ha_d3_0 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by have hr0 := (hp_d3_0.2 0 6 (by decide) (by decide) (by decide)).trans hregs.1.2.2.2.2.2.2.1
        dsimp [wsOf] at hr0; simp [hr0])
    hInvPlace0
    (fun b ws_b bs_b hb hInv_b => by
      rcases hInv_b with ⟨hbs_b, ha_b, hp_b, hcst_b, hg_b, hfreq_b, hr11_0, h5_b, h23_b⟩; subst bs_b
      let bFin : Fin p.r := ⟨b, hb⟩
      obtain ⟨ha_g1, ex_g1⟩ := exec_wl_reg 11 1 (.lit 1) ha_b hinp (val := 1) rfl (ibl_one_le hV16)
      obtain ⟨ha_j0, ex_j0⟩ := exec_wl_reg 11 2 (.lit 0) ha_g1 hinp (val := 0) rfl (ibl_zero_le hV16)
      have hp_j0 : PreserveOutside4 ws₃ (wsOf ha_j0) :=
        (hp_b.write_local 1 _ (Or.inr (Or.inr (by decide)))).write_local
          2 _ (Or.inr (Or.inr (by decide)))
      let goodPref : ℕ → Bool := fun j =>
        decide (∀ j' : Fin s₁, j'.1 < j →
          freqOf g_hat (g_hat ⟨b * s₁ + j'.1, coreIdxLt bFin j'⟩) = 1)
      let InvChk : ℕ → WordStore → List Bool → Prop := fun j ws_j bs_j =>
        bs_j = bs ∧
        InAttemptArena A V ws_j ∧
        PreserveOutside4 ws₃ ws_j ∧
        HasP4Consts p K₀ deg_α₀ ws_j ∧
        (∀ t : Fin (p.r * s₁), ws_j.read (.localFrame 1 21 (t.1 : ℤ)) = ((g_hat t).1 : ℤ)) ∧
        (∀ h : Fin p.m, ws_j.read (.localFrame 1 22 (h.1 : ℤ)) = (freqOf g_hat h : ℤ)) ∧
        (∀ idx : Fin p.m, ws_j.read (.localFrame 1 5 (idx.1 : ℤ)) = ws_b.read (.localFrame 1 5 (idx.1 : ℤ))) ∧
        (∀ h : Fin p.m, ws_j.read (.localFrame 1 23 (h.1 : ℤ)) = ws_b.read (.localFrame 1 23 (h.1 : ℤ))) ∧
        ws_j.read (.localFrame 1 11 0) = (b : ℤ) ∧
        ws_j.read (.localFrame 1 11 1) = (if goodPref j then 1 else 0) ∧
        ws_j.read (.localFrame 1 11 2) = (j : ℤ)
      have hInvChk0 : InvChk 0 (wsOf ha_j0) bs := by
        have hg0 : goodPref 0 = true := by simp [goodPref]
        refine ⟨rfl, ha_j0, hp_j0,
          hasP4Consts_of_eq hcst_b (fun _ => by simp [wsOf, rw_write_eq]),
          fun t => by simp [wsOf, rw_write_eq, hg_b t],
          fun h => by simp [wsOf, rw_write_eq, hfreq_b h],
          fun idx => by simp [wsOf, rw_write_eq],
          fun h => by simp [wsOf, rw_write_eq],
          by simp [wsOf, rw_write_eq, hr11_0],
          by simp [wsOf, rw_write_eq, hg0],
          wordStore_read_write_self _ _ _⟩
      obtain ⟨wsCk, bsCk, hInvCkEnd, ex_ck⟩ := exec_repeatN_inv (bs₀ := bs)
        (U := 272) (B := 264000 * (V + 8) ^ 2)
        (countE := .readLocal 10 (.lit 0)) (body := p4dCheckInnerBody) s₁ InvChk ha_j0 hinp
        (exprInArena_small (by decide) (by decide) hV16) (by decide)
        (by simp only [wsOf, evalVal_readLocal, evalVal_lit, rw_local_var_ne _ (by decide : 10 ≠ 11)]; exact hcst_b.1)
        hInvChk0
        (fun j ws_j bs_j hj hInv_j => by
          rcases hInv_j with ⟨hbs_j, ha_j, hp_j, hcst_j, hg_j, hfreq_j, h5_j, h23_j, h11_0, h11_1, h11_2⟩; subst bs_j
          let jFin : Fin s₁ := ⟨j, hj⟩
          let tFin : Fin (p.r * s₁) := ⟨b * s₁ + j, coreIdxLt bFin jFin⟩
          let hj_val : Fin p.m := g_hat tFin
          obtain ⟨ha_h, ex_h⟩ := exec_wl_reg 12 0 (.readLocal 21 (.add (.mul (.readLocal 11 (.lit 0)) (.readLocal 10 (.lit 0))) (.readLocal 11 (.lit 2)))) ha_j hinp (val := (hj_val.1 : ℤ))
            (by have ht_z : ((b : ℤ) * (s₁Val K₀ deg_α₀ p.d : ℤ) + (j : ℤ)) = ((tFin.1 : ℕ) : ℤ) := by
                  dsimp [tFin, s₁]; try (push_cast; ring)
                simp only [evalVal_readLocal, evalVal_add, evalVal_mul, evalVal_lit, h11_0, hcst_j.1, h11_2, ht_z]
                exact hg_j tFin)
            (hib_2m (by have := hj_val.2; omega))
          have hc_eq1 : evalCondVal inp (wsOf ha_h)
              (.intEq (.readLocal 22 (.readLocal 12 (.lit 0))) (.lit 1)) =
              decide (freqOf g_hat hj_val = 1) := by
            simp only [wsOf, evalCondVal_intEq, evalVal_readLocal, evalVal_lit,
              wordStore_read_write_self, rw_local_var_ne _ (by decide : 22 ≠ 12), hfreq_j hj_val]
            exact decide_eq_decide.mpr (by exact_mod_cast Iff.rfl)
          by_cases hf1 : freqOf g_hat hj_val = 1
          · have hc_t : decide (freqOf g_hat hj_val = 1) = true := decide_eq_true hf1
            have ex_ite := exec_ite_s .skip (.writeLocal 11 (.lit 1) (.lit 0)) ha_h hinp (hc_eq1.trans hc_t)
              (by simpa [hc_t] using exec_skip_s (wsOf ha_h) bs hinp)
            obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 2 (.add (.readLocal 11 (.lit 2)) (.lit 1)) ha_h hinp (val := ((j + 1 : ℕ) : ℤ))
              (by simp [wsOf, rw_write_eq, h11_2]; try (push_cast; ring)) (hib_2m (by omega))
            have hgp_eq : goodPref (j + 1) = goodPref j := by
              dsimp [goodPref]
              apply decide_eq_decide.mpr
              constructor
              · intro hall j' hj'; exact hall j' (by omega)
              · intro hall j' hj'
                rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hj') with hlt | heq
                · exact hall j' hlt
                · have hj_eq : j' = jFin := Fin.ext heq
                  subst hj_eq; exact hf1
            refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx,
              (hp_j.write_local 0 _ (Or.inr (Or.inr (by decide)))).write_local 2 _ (Or.inr (Or.inr (by decide))),
              hasP4Consts_of_eq hcst_j (fun _ => by simp [wsOf, rw_write_eq]),
              fun t => by simp [wsOf, rw_write_eq, hg_j t],
              fun h => by simp [wsOf, rw_write_eq, hfreq_j h],
              fun idx => by simp [wsOf, rw_write_eq, h5_j idx],
              fun h => by simp [wsOf, rw_write_eq, h23_j h],
              by simp [wsOf, rw_write_eq, h11_0],
              by simp [wsOf, rw_write_eq, hgp_eq, h11_1],
              wordStore_read_write_self _ _ _⟩,
              ExecBounded.mono (ExecBounded.seq ex_h (ExecBounded.seq ex_ite ex_nx))
                (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩
          · obtain ⟨ha_f0, ex_f0⟩ := exec_wl_reg (bs := bs) 11 1 (.lit 0) ha_h hinp (val := 0) rfl (ibl_zero_le hV16)
            have hc_f : decide (freqOf g_hat hj_val = 1) = false := decide_eq_false hf1
            have ex_ite := exec_ite_s .skip (.writeLocal 11 (.lit 1) (.lit 0)) ha_h hinp (hc_eq1.trans hc_f)
              (by simpa [hc_f] using ex_f0)
            obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 2 (.add (.readLocal 11 (.lit 2)) (.lit 1)) ha_f0 hinp (val := ((j + 1 : ℕ) : ℤ))
              (by simp [wsOf, rw_write_eq, h11_2]; try (push_cast; ring)) (hib_2m (by omega))
            have hgp_f : goodPref (j + 1) = false := by
              dsimp [goodPref]
              exact decide_eq_false (fun hall => hf1 (hall jFin (Nat.lt_succ_self j)))
            refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx,
              ((hp_j.write_local 0 _ (Or.inr (Or.inr (by decide)))).write_local
                1 _ (Or.inr (Or.inr (by decide)))).write_local 2 _ (Or.inr (Or.inr (by decide))),
              hasP4Consts_of_eq hcst_j (fun _ => by simp [wsOf, rw_write_eq]),
              fun t => by simp [wsOf, rw_write_eq, hg_j t],
              fun h => by simp [wsOf, rw_write_eq, hfreq_j h],
              fun idx => by simp [wsOf, rw_write_eq, h5_j idx],
              fun h => by simp [wsOf, rw_write_eq, h23_j h],
              by simp [wsOf, rw_write_eq, h11_0],
              by simp [wsOf, rw_write_eq, hgp_f],
              wordStore_read_write_self _ _ _⟩,
              ExecBounded.mono (ExecBounded.seq ex_h (ExecBounded.seq ex_ite ex_nx))
                (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩)
      rcases hInvCkEnd with ⟨hbsCk, haCk, hpCk, hcstCk, hgCk, hfreqCk, h5Ck, h23Ck, h11_0Ck, h11_1Ck, _⟩; subst bsCk
      have hgp_full : goodPref s₁ = coreGood g_hat bFin := by
        dsimp [goodPref, coreGood]
        exact decide_eq_decide.mpr ⟨fun h j => h j j.2, fun h j _ => h j⟩
      rw [hgp_full] at h11_1Ck
      have hc_good : evalCondVal inp wsCk (.intEq (.readLocal 11 (.lit 1)) (.lit 1)) =
          coreGood g_hat bFin := by
        simp only [evalCondVal_intEq, evalVal_readLocal, evalVal_lit, h11_1Ck]
        cases coreGood g_hat bFin <;> rfl
      -- Branch on `coreGood g_hat bFin`
      have hbranch :
          ∃ wsBr : WordStore,
            InAttemptArena A V wsBr ∧
            PreserveOutside4 ws₃ wsBr ∧
            HasP4Consts p K₀ deg_α₀ wsBr ∧
            (∀ t : Fin (p.r * s₁), wsBr.read (.localFrame 1 21 (t.1 : ℤ)) = ((g_hat t).1 : ℤ)) ∧
            (∀ h : Fin p.m, wsBr.read (.localFrame 1 22 (h.1 : ℤ)) = (freqOf g_hat h : ℤ)) ∧
            wsBr.read (.localFrame 1 11 0) = (b : ℤ) ∧
            (∀ idx : Fin p.m,
              wsBr.read (.localFrame 1 5 (idx.1 : ℤ)) =
                if idx.1 / p.s₀ < b + 1 then optToInt (coreSlotOpt p.s₀ g_hat idx) else -1) ∧
            (∀ h : Fin p.m,
              wsBr.read (.localFrame 1 23 (h.1 : ℤ)) = if placedBefore (b + 1) h then 1 else 0) ∧
            ExecBounded inp
              (if coreGood g_hat bFin then
                 .seq (.writeLocal 11 (.lit 2) (.lit 0))
                      (.repeatN (.readLocal 10 (.lit 0)) p4dPlaceInnerBody)
               else .skip)
              wsCk bs wsBr bs
              (200 + 300 * s₁) ((200000 + 300000 * s₁) * (V + 8) ^ 2)
              (arenaCellCap inp A) (arenaBitCap inp A V) := by
        by_cases hcg : coreGood g_hat bFin = true
        · rw [if_pos hcg]
          obtain ⟨ha_pj0, ex_pj0⟩ := exec_wl_reg 11 2 (.lit 0) haCk hinp (val := 0) rfl (ibl_zero_le hV16)
          have hp_pj0 : PreserveOutside4 ws₃ (wsOf ha_pj0) :=
            hpCk.write_local 2 _ (Or.inr (Or.inr (by decide)))
          let InvPlIn : ℕ → WordStore → List Bool → Prop := fun j ws_j bs_j =>
            bs_j = bs ∧
            InAttemptArena A V ws_j ∧
            PreserveOutside4 ws₃ ws_j ∧
            HasP4Consts p K₀ deg_α₀ ws_j ∧
            (∀ t : Fin (p.r * s₁), ws_j.read (.localFrame 1 21 (t.1 : ℤ)) = ((g_hat t).1 : ℤ)) ∧
            (∀ h : Fin p.m, ws_j.read (.localFrame 1 22 (h.1 : ℤ)) = (freqOf g_hat h : ℤ)) ∧
            ws_j.read (.localFrame 1 11 0) = (b : ℤ) ∧
            ws_j.read (.localFrame 1 11 2) = (j : ℤ) ∧
            (∀ idx : Fin p.m,
              ws_j.read (.localFrame 1 5 (idx.1 : ℤ)) =
                if idx.1 / p.s₀ = b ∧ idx.1 % p.s₀ < j then
                  optToInt (coreSlotOpt p.s₀ g_hat idx)
                else
                  ws_b.read (.localFrame 1 5 (idx.1 : ℤ))) ∧
            (∀ h : Fin p.m,
              ws_j.read (.localFrame 1 23 (h.1 : ℤ)) =
                if (∃ j' : Fin s₁, j'.1 < j ∧ g_hat ⟨b * s₁ + j'.1, coreIdxLt bFin j'⟩ = h) then
                  1
                else
                  ws_b.read (.localFrame 1 23 (h.1 : ℤ)))
          have hInvPlIn0 : InvPlIn 0 (wsOf ha_pj0) bs := by
            refine ⟨rfl, ha_pj0, hp_pj0,
              hasP4Consts_of_eq hcstCk (fun _ => by simp [wsOf, rw_write_eq]),
              fun t => by simp [wsOf, rw_write_eq, hgCk t],
              fun h => by simp [wsOf, rw_write_eq, hfreqCk h],
              by simp [wsOf, rw_write_eq, h11_0Ck],
              wordStore_read_write_self _ _ _,
              fun idx => by simp [wsOf, rw_write_eq, h5Ck idx],
              fun h => by simp [wsOf, rw_write_eq, h23Ck h]⟩
          obtain ⟨wsPl, bsPl, hInvPlEnd, ex_pl⟩ := exec_repeatN_inv (bs₀ := bs)
            (U := 68 + (68 + (68 + 68)))
            (B := 66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + (66000 * (V + 8) ^ 2 + 66000 * (V + 8) ^ 2)))
            (countE := .readLocal 10 (.lit 0)) (body := p4dPlaceInnerBody) s₁ InvPlIn ha_pj0 hinp
            (exprInArena_small (by decide) (by decide) hV16) (by decide)
            (by simp only [wsOf, evalVal_readLocal, evalVal_lit, rw_local_var_ne _ (by decide : 10 ≠ 11)]; exact hcstCk.1)
            hInvPlIn0
            (fun j ws_j bs_j hj hInv_j => by
              rcases hInv_j with ⟨hbs_j, ha_j, hp_j, hcst_j, hg_j, hfreq_j, h11_0, h11_2, h5_j, h23_j⟩; subst bs_j
              let jFin : Fin s₁ := ⟨j, hj⟩
              let tFin : Fin (p.r * s₁) := ⟨b * s₁ + j, coreIdxLt bFin jFin⟩
              let hj_val : Fin p.m := g_hat tFin
              have hslot_lt : b * p.s₀ + j < p.m := by
                have hb1 : (b + 1) * p.s₀ ≤ p.r * p.s₀ := Nat.mul_le_mul_right p.s₀ hb
                rw [Nat.add_mul, Nat.one_mul] at hb1
                have : j < p.s₀ := lt_of_lt_of_le hj hs₁_le_s₀
                omega
              let slotFin : Fin p.m := ⟨b * p.s₀ + j, hslot_lt⟩
              have hs0_j : ws_j.read (.localFrame 1 0 5) = (p.s₀ : ℤ) :=
                (hp_j.2 0 5 (by decide) (by decide) (by decide)).trans hregs.1.2.2.2.2.2.1
              obtain ⟨ha_h, ex_h⟩ := exec_wl_reg 12 0 (.readLocal 21 (.add (.mul (.readLocal 11 (.lit 0)) (.readLocal 10 (.lit 0))) (.readLocal 11 (.lit 2)))) ha_j hinp (val := (hj_val.1 : ℤ))
                (by have ht_z : ((b : ℤ) * (s₁Val K₀ deg_α₀ p.d : ℤ) + (j : ℤ)) = ((tFin.1 : ℕ) : ℤ) := by
                      dsimp [tFin, s₁]; try (push_cast; ring)
                    simp only [evalVal_readLocal, evalVal_add, evalVal_mul, evalVal_lit, h11_0, hcst_j.1, h11_2, ht_z]
                    exact hg_j tFin)
                (hib_2m (by have := hj_val.2; omega))
              obtain ⟨ha_w5, ex_w5⟩ := exec_wl ha_h hinp
                (var := 5)
                (idxE := .add (.mul (.readLocal 11 (.lit 0)) (.readLocal 0 (.lit 5)))
                              (.readLocal 11 (.lit 2)))
                (idx := (slotFin.1 : ℤ))
                (valE := .readLocal 12 (.lit 0))
                (val := (hj_val.1 : ℤ))
                (by simp [wsOf, rw_write_eq, h11_0, hs0_j, h11_2, slotFin]; try (push_cast; ring))
                (by simp [wsOf, wordStore_read_write_self])
                (by positivity)
                (by rw [Int.toNat_natCast]; omega)
                (hib_2m (by have := hj_val.2; omega))
              obtain ⟨ha_w23, ex_w23⟩ := exec_wl ha_w5 hinp
                (var := 23) (idxE := .readLocal 12 (.lit 0)) (idx := (hj_val.1 : ℤ))
                (valE := .lit 1) (val := 1)
                (by simp [wsOf, rw_write_eq])
                rfl
                (by positivity)
                (by rw [Int.toNat_natCast]; have := hj_val.2; omega)
                (ibl_one_le hV16)
              obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 2 (.add (.readLocal 11 (.lit 2)) (.lit 1)) ha_w23 hinp (val := ((j + 1 : ℕ) : ℤ))
                (by simp [wsOf, rw_write_eq, h11_2]; try (push_cast; ring))
                (hib_2m (by omega))
              have hp_nx : PreserveOutside4 ws₃ (wsOf ha_nx) :=
                (((hp_j.write_local 0 _ (Or.inr (Or.inr (by decide)))).write_local
                   (slotFin.1 : ℤ) _ (Or.inr (Or.inl rfl))).write_local
                   (hj_val.1 : ℤ) _ (Or.inr (Or.inr (by decide)))).write_local
                   2 _ (Or.inr (Or.inr (by decide)))
              refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx, hp_nx,
                hasP4Consts_of_eq hcst_j (fun _ => by simp [wsOf, rw_write_eq]),
                fun t => by simp [wsOf, rw_write_eq, hg_j t],
                fun h => by simp [wsOf, rw_write_eq, hfreq_j h],
                by simp [wsOf, rw_write_eq, h11_0],
                wordStore_read_write_self _ _ _,
                fun idx => ?_,
                fun h => ?_⟩,
                ExecBounded.seq ex_h (ExecBounded.seq ex_w5 (ExecBounded.seq ex_w23 ex_nx))⟩
              · rw [rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide)]
                by_cases h_eq : idx = slotFin
                · subst h_eq
                  rw [wordStore_read_write_self]
                  have hs0_pos : 0 < p.s₀ := lt_of_lt_of_le (by omega) hs₁_le_s₀
                  have hj_lt_s0 : j < p.s₀ := lt_of_lt_of_le hj hs₁_le_s₀
                  have hdiv : slotFin.1 / p.s₀ = b := by
                    dsimp [slotFin]
                    rw [mul_comm, Nat.mul_add_div hs0_pos, Nat.div_eq_of_lt hj_lt_s0, add_zero]
                  have hmod : slotFin.1 % p.s₀ = j := by
                    dsimp [slotFin]
                    rw [mul_comm, Nat.mul_add_mod, Nat.mod_eq_of_lt hj_lt_s0]
                  rw [if_pos ⟨hdiv, by omega⟩]
                  have hblk := coreSlotOpt_blk hs₁_1 hs₁_le_s₀ hrs g_hat bFin jFin
                  rw [if_pos hcg] at hblk
                  dsimp only [slotFin] at hblk ⊢
                  rw [hblk]
                  rfl
                · have hne_z : (idx.1 : ℤ) ≠ (slotFin.1 : ℤ) :=
                    fun hv => h_eq (Fin.ext (Int.ofNat.inj hv))
                  rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ hi; exact hne_z hi),
                      rw_local_var_ne _ (by decide), h5_j idx]
                  have hnot_eq : ¬ (idx.1 / p.s₀ = b ∧ idx.1 % p.s₀ = j) := by
                    rintro ⟨hd, hm⟩
                    apply h_eq; apply Fin.ext
                    have hd_mod := Nat.div_add_mod idx.1 p.s₀
                    dsimp [slotFin]; rw [hd, hm] at hd_mod; linarith
                  by_cases hprev : idx.1 / p.s₀ = b ∧ idx.1 % p.s₀ < j
                  · rw [if_pos hprev, if_pos ⟨hprev.1, by omega⟩]
                  · rw [if_neg hprev, if_neg]
                    rintro ⟨hd, hlt1⟩
                    rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hlt1) with hlt' | hm
                    · exact hprev ⟨hd, hlt'⟩
                    · exact hnot_eq ⟨hd, hm⟩
              · rw [rw_local_var_ne _ (by decide)]
                by_cases h_eq : h = hj_val
                · subst h_eq
                  rw [wordStore_read_write_self, if_pos ⟨jFin, Nat.lt_succ_self j, rfl⟩]
                · have hne_z : (h.1 : ℤ) ≠ (hj_val.1 : ℤ) :=
                    fun hv => h_eq (Fin.ext (Int.ofNat.inj hv))
                  rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ hi; exact hne_z hi),
                      rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide), h23_j h]
                  have hiff : (∃ j' : Fin s₁, j'.1 < j + 1 ∧ g_hat ⟨b * s₁ + j'.1, coreIdxLt bFin j'⟩ = h) ↔
                      (∃ j' : Fin s₁, j'.1 < j ∧ g_hat ⟨b * s₁ + j'.1, coreIdxLt bFin j'⟩ = h) := by
                    constructor
                    · rintro ⟨j', hj', heq⟩
                      rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hj') with hlt | hjeq
                      · exact ⟨j', hlt, heq⟩
                      · have hj_fin : j' = jFin := Fin.ext hjeq
                        subst hj_fin
                        exact False.elim (h_eq heq.symm)
                    · rintro ⟨j', hj', heq⟩; exact ⟨j', by omega, heq⟩
                  by_cases hex : ∃ j' : Fin s₁, j'.1 < j ∧ g_hat ⟨b * s₁ + j'.1, coreIdxLt bFin j'⟩ = h
                  · rw [if_pos hex, if_pos (hiff.mpr hex)]
                  · rw [if_neg hex, if_neg (fun h' => hex (hiff.mp h'))])
          rcases hInvPlEnd with ⟨hbsPl, haPl, hpPl, hcstPl, hgPl, hfreqPl, h11_0Pl, _, h5Pl, h23Pl⟩; subst bsPl
          refine ⟨wsPl, haPl, hpPl, hcstPl, hgPl, hfreqPl, h11_0Pl,
            fun idx => ?_, fun h => ?_,
            ExecBounded.mono (ExecBounded.seq ex_pj0 ex_pl) (by omega) (by simp only [← Nat.mul_assoc, ← Nat.add_mul]; apply Nat.mul_le_mul_right; omega) le_rfl le_rfl⟩
          · rw [h5Pl idx, h5_b idx]
            by_cases hdb : idx.1 / p.s₀ = b
            · by_cases hms : idx.1 % p.s₀ < s₁
              · rw [if_pos ⟨hdb, hms⟩, if_pos (by omega : idx.1 / p.s₀ < b + 1)]
              · rw [if_neg (fun hc => hms hc.2), if_neg (by omega : ¬ idx.1 / p.s₀ < b),
                    if_pos (by omega : idx.1 / p.s₀ < b + 1)]
                unfold coreSlotOpt
                have hb' : idx.1 / p.s₀ < p.r := hdb ▸ hb
                rw [dif_pos hb', dif_neg hms]; rfl
            · rw [if_neg (fun hc => hdb hc.1)]
              by_cases hlt_b : idx.1 / p.s₀ < b
              · rw [if_pos hlt_b, if_pos (by omega : idx.1 / p.s₀ < b + 1)]
              · rw [if_neg hlt_b, if_neg (by omega : ¬ idx.1 / p.s₀ < b + 1)]
          · rw [h23Pl h, h23_b h]
            by_cases hex_cur : ∃ j' : Fin s₁, j'.1 < s₁ ∧ g_hat ⟨b * s₁ + j'.1, coreIdxLt bFin j'⟩ = h
            · rcases hex_cur with ⟨j', _, hj'_eq⟩
              have hpb1 : placedBefore (b + 1) h = true :=
                decide_eq_true ⟨bFin, Nat.lt_succ_self b, hcg, j', hj'_eq⟩
              rw [if_pos ⟨j', j'.2, hj'_eq⟩, hpb1, if_pos rfl]
            · rw [if_neg hex_cur]
              have hpb_eq : placedBefore (b + 1) h = placedBefore b h := by
                dsimp [placedBefore]
                apply decide_eq_decide.mpr
                constructor
                · rintro ⟨b', hb', hcg', j', hj'⟩
                  rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hb') with hlt | heq
                  · exact ⟨b', hlt, hcg', j', hj'⟩
                  · have hb_fin : b' = bFin := Fin.ext heq
                    subst hb_fin
                    exact False.elim (hex_cur ⟨j', j'.2, hj'⟩)
                · rintro ⟨b', hb', hcg', j', hj'⟩
                  exact ⟨b', by omega, hcg', j', hj'⟩
              rw [hpb_eq]
        · rw [if_neg hcg]
          refine ⟨wsCk, haCk, hpCk, hcstCk, hgCk, hfreqCk, h11_0Ck,
            fun idx => ?_, fun h => ?_,
            ExecBounded.mono (exec_skip_s wsCk bs hinp) (by omega)
              (by apply Nat.mul_le_mul_right; omega) le_rfl le_rfl⟩
          · rw [h5Ck idx, h5_b idx]
            by_cases hdb : idx.1 / p.s₀ = b
            · rw [if_neg (by omega : ¬ idx.1 / p.s₀ < b), if_pos (by omega : idx.1 / p.s₀ < b + 1)]
              unfold coreSlotOpt
              have hb' : idx.1 / p.s₀ < p.r := hdb ▸ hb
              rw [dif_pos hb']
              by_cases hj' : idx.1 % p.s₀ < s₁
              · rw [dif_pos hj']
                have hb_fin : (⟨idx.1 / p.s₀, hb'⟩ : Fin p.r) = bFin := Fin.ext hdb
                rw [hb_fin, if_neg hcg]; rfl
              · rw [dif_neg hj']; rfl
            · by_cases hlt_b : idx.1 / p.s₀ < b
              · rw [if_pos hlt_b, if_pos (by omega : idx.1 / p.s₀ < b + 1)]
              · rw [if_neg hlt_b, if_neg (by omega : ¬ idx.1 / p.s₀ < b + 1)]
          · rw [h23Ck h, h23_b h]
            have hpb_eq : placedBefore (b + 1) h = placedBefore b h := by
              dsimp [placedBefore]
              apply decide_eq_decide.mpr
              constructor
              · rintro ⟨b', hb', hcg', j', hj'⟩
                rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hb') with hlt | heq
                · exact ⟨b', hlt, hcg', j', hj'⟩
                · have hb_fin : b' = bFin := Fin.ext heq
                  subst hb_fin
                  exact False.elim (hcg hcg')
              · rintro ⟨b', hb', hcg', j', hj'⟩
                exact ⟨b', by omega, hcg', j', hj'⟩
            rw [hpb_eq]
      obtain ⟨wsBr, haBr, hpBr, hcstBr, hgBr, hfreqBr, h11_0Br, h5Br, h23Br, ex_br⟩ := hbranch
      have ex_ite_pl := exec_ite_s (.seq (.writeLocal 11 (.lit 2) (.lit 0)) (.repeatN (.readLocal 10 (.lit 0)) p4dPlaceInnerBody)) .skip haCk hinp hc_good ex_br
      obtain ⟨ha_inc, ex_inc⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) haBr hinp (val := ((b + 1 : ℕ) : ℤ))
        (by simp [h11_0Br]; try (push_cast; ring)) (hib_2m (by omega))
      have ex_ostep :=
        ExecBounded.seq ex_g1 (ExecBounded.seq ex_j0 (ExecBounded.seq ex_ck
        (ExecBounded.seq ex_ite_pl ex_inc)))
      refine ⟨wsOf ha_inc, bs, ⟨rfl, ha_inc,
        hpBr.write_local 0 _ (Or.inr (Or.inr (by decide))),
        hasP4Consts_of_eq hcstBr (fun _ => by simp [wsOf, rw_write_eq]),
        fun t => by simp [wsOf, rw_write_eq, hgBr t],
        fun h => by simp [wsOf, rw_write_eq, hfreqBr h],
        wordStore_read_write_self _ _ _,
        fun idx => by rw [rw_local_var_ne _ (by decide)]; exact h5Br idx,
        fun h => by rw [rw_local_var_ne _ (by decide)]; exact h23Br h⟩,
        ExecBounded.mono ex_ostep
          (show _ ≤ 600 + 600 * s₁ by omega)
          (show _ ≤ (600000 + 600000 * s₁) * (V + 8) ^ 2 by simp only [← Nat.mul_assoc, ← Nat.add_mul]; apply Nat.mul_le_mul_right; omega)
          le_rfl le_rfl⟩)
  rcases hInvPEnd with ⟨hbsP, haP, hpP, _, _, _, _, h5P_raw, h23P_raw⟩; subst bsP
  have h5P : ∀ idx : Fin p.m, wsP.read (.localFrame 1 5 (idx.1 : ℤ)) = optToInt (coreSlotOpt p.s₀ g_hat idx) := by
    intro idx
    rw [h5P_raw idx]
    by_cases hlt : idx.1 / p.s₀ < p.r
    · rw [if_pos hlt]
    · rw [if_neg hlt]
      unfold coreSlotOpt
      rw [dif_neg hlt]; rfl
  have h23P : ∀ h : Fin p.m, wsP.read (.localFrame 1 23 (h.1 : ℤ)) = if isPlacedHandle g_hat h then 1 else 0 := by
    intro h
    rw [h23P_raw h]
    have heq_b : placedBefore p.r h = isPlacedHandle g_hat h := by
      dsimp [placedBefore, isPlacedHandle]
      exact decide_eq_decide.mpr
        ⟨fun ⟨b', _, hg, j, hj⟩ => ⟨b', hg, j, hj⟩,
         fun ⟨b', hg, j, hj⟩ => ⟨b', b'.2, hg, j, hj⟩⟩
    rw [heq_b]
  have ex_d3 := ExecBounded.seq ex_d3_0 ex_d3_loop
  -- D.4: `p4dUnusedStmt` (Pass 1: build `unusedPrefix` in `var 24`)
  obtain ⟨ha_d4_0, ex_d4_0⟩ := exec_wl_reg 11 0 (.lit 0) haP hinp (val := 0) rfl (ibl_zero_le hV16)
  obtain ⟨ha_d4_1, ex_d4_1⟩ := exec_wl_reg 11 1 (.lit 0) ha_d4_0 hinp (val := 0) rfl (ibl_zero_le hV16)
  have hp_d4_1 : PreserveOutside4 ws₃ (wsOf ha_d4_1) :=
    (hpP.write_local 0 _ (Or.inr (Or.inr (by decide)))).write_local 1 _ (Or.inr (Or.inr (by decide)))
  let InvUn : ℕ → WordStore → List Bool → Prop := fun k ws_k bs_k =>
    bs_k = bs ∧
    InAttemptArena A V ws_k ∧
    PreserveOutside4 ws₃ ws_k ∧
    (∀ idx : Fin p.m, ws_k.read (.localFrame 1 5 (idx.1 : ℤ)) = optToInt (coreSlotOpt p.s₀ g_hat idx)) ∧
    (∀ h : Fin p.m, ws_k.read (.localFrame 1 23 (h.1 : ℤ)) = if isPlacedHandle g_hat h then 1 else 0) ∧
    ws_k.read (.localFrame 1 11 0) = (k : ℤ) ∧
    ws_k.read (.localFrame 1 11 1) = ((unusedPrefix g_hat k).length : ℤ) ∧
    (∀ (u : ℕ) (hu : u < (unusedPrefix g_hat k).length),
      ws_k.read (.localFrame 1 24 (u : ℤ)) = (((unusedPrefix g_hat k)[u]).1 : ℤ))
  have hInvUn0 : InvUn 0 (wsOf ha_d4_1) bs :=
    ⟨rfl, ha_d4_1, hp_d4_1,
     fun idx => by simp [wsOf, rw_write_eq, h5P idx],
     fun h => by simp [wsOf, rw_write_eq, h23P h],
     by simp [wsOf, rw_write_eq],
     wordStore_read_write_self _ _ _,
     fun _ hu => by simp [unusedPrefix] at hu⟩
  obtain ⟨wsU, bsU, hInvUEnd, ex_d4_loop⟩ := exec_repeatN_inv (bs₀ := bs)
    (U := 272) (B := 264000 * (V + 8) ^ 2)
    (countE := .readLocal 0 (.lit 2)) (body := p4dUnusedBody) p.m InvUn ha_d4_1 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by have hm0 := (hp_d4_1.2 0 2 (by decide) (by decide) (by decide)).trans hregs.1.2.2.1
        dsimp [wsOf] at hm0; simp [hm0])
    hInvUn0
    (fun k ws_k bs_k hk hInv_k => by
      rcases hInv_k with ⟨hbs_k, ha_k, hp_k, h5_k, h23_k, hr11_0, hr11_1, h24_k⟩; subst bs_k
      let hk_fin : Fin p.m := ⟨k, hk⟩
      let L_cur := (unusedPrefix g_hat k).length
      have hL_le_m : L_cur ≤ p.m := by
        dsimp [L_cur]
        rw [(unusedPrefix_props g_hat k (le_of_lt hk)).2.2]
        exact (Finset.card_filter_le _ _).trans (by simp)
      have hc_un : evalCondVal inp ws_k (.intEq (.readLocal 23 (.readLocal 11 (.lit 0))) (.lit 0)) =
          !isPlacedHandle g_hat hk_fin := by
        have h23_eq : ws_k.read (.localFrame 1 23 (k : ℤ)) = if isPlacedHandle g_hat hk_fin then 1 else 0 :=
          h23_k hk_fin
        simp only [evalCondVal_intEq, evalVal_readLocal, evalVal_lit, hr11_0, h23_eq]
        cases isPlacedHandle g_hat hk_fin <;> rfl
      by_cases hpl : isPlacedHandle g_hat hk_fin = true
      · have hc_f : (!isPlacedHandle g_hat hk_fin) = false := by simp [hpl]
        have ex_ite := exec_ite_s (.seq (.writeLocal 24 (.readLocal 11 (.lit 1)) (.readLocal 11 (.lit 0))) (.writeLocal 11 (.lit 1) (.add (.readLocal 11 (.lit 1)) (.lit 1)))) .skip ha_k hinp (hc_un.trans hc_f)
          (by simpa [hc_f] using exec_skip_s ws_k bs hinp)
        obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) ha_k hinp (val := ((k + 1 : ℕ) : ℤ))
          (by simp [hr11_0]; try (push_cast; ring)) (hib_2m (by omega))
        have hun_step : unusedPrefix g_hat (k + 1) = unusedPrefix g_hat k := by
          simp [unusedPrefix, hk, hk_fin, hpl]
        refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx,
          hp_k.write_local 0 _ (Or.inr (Or.inr (by decide))),
          fun idx => by simp [wsOf, rw_write_eq, h5_k idx],
          fun h => by simp [wsOf, rw_write_eq, h23_k h],
          wordStore_read_write_self _ _ _,
          by simp [wsOf, rw_write_eq, hun_step, hr11_1],
          fun u hu => by
            rw [rw_local_var_ne _ (by decide)]
            have hu' : u < (unusedPrefix g_hat k).length := hun_step ▸ hu
            have hget : (unusedPrefix g_hat (k + 1))[u] = (unusedPrefix g_hat k)[u] := by simp [hun_step]
            rw [hget]
            exact h24_k u hu'⟩,
          ExecBounded.mono (ExecBounded.seq ex_ite ex_nx) (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩
      · have hc_t : (!isPlacedHandle g_hat hk_fin) = true := by
          cases h : isPlacedHandle g_hat hk_fin
          · rfl
          · exact False.elim (hpl h)
        obtain ⟨ha_w24, ex_w24⟩ := exec_wl (bs := bs) ha_k hinp
          (var := 24) (idxE := .readLocal 11 (.lit 1)) (idx := (L_cur : ℤ))
          (valE := .readLocal 11 (.lit 0)) (val := (k : ℤ))
          (by simp [hr11_1, L_cur])
          (by simp [hr11_0])
          (by positivity)
          (by rw [Int.toNat_natCast]; omega)
          (hib_2m (by omega))
        obtain ⟨ha_l1, ex_l1⟩ := exec_wl_reg 11 1 (.add (.readLocal 11 (.lit 1)) (.lit 1)) ha_w24 hinp (val := ((L_cur + 1 : ℕ) : ℤ))
          (by simp [wsOf, rw_write_eq, hr11_1, L_cur]; try (push_cast; ring)) (hib_2m (by omega))
        have ex_ite := exec_ite_s (.seq (.writeLocal 24 (.readLocal 11 (.lit 1)) (.readLocal 11 (.lit 0))) (.writeLocal 11 (.lit 1) (.add (.readLocal 11 (.lit 1)) (.lit 1)))) .skip ha_k hinp (hc_un.trans hc_t)
          (by simpa [hc_t] using ExecBounded.seq ex_w24 ex_l1)
        obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) ha_l1 hinp (val := ((k + 1 : ℕ) : ℤ))
          (by simp [wsOf, rw_write_eq, hr11_0]; try (push_cast; ring)) (hib_2m (by omega))
        have hun_step : unusedPrefix g_hat (k + 1) = unusedPrefix g_hat k ++ [hk_fin] := by
          simp [unusedPrefix, hk, hk_fin, hpl]
        have hlen_step : (unusedPrefix g_hat (k + 1)).length = L_cur + 1 := by
          simp [hun_step, L_cur]
        refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx,
          ((hp_k.write_local (L_cur : ℤ) _ (Or.inr (Or.inr (by decide)))).write_local
             1 _ (Or.inr (Or.inr (by decide)))).write_local 0 _ (Or.inr (Or.inr (by decide))),
          fun idx => by simp [wsOf, rw_write_eq, h5_k idx],
          fun h => by simp [wsOf, rw_write_eq, h23_k h],
          wordStore_read_write_self _ _ _,
          by simp [wsOf, rw_write_eq, hlen_step],
          fun u hu => by
            rw [rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide)]
            rw [hlen_step] at hu
            rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hu) with hlt | rfl
            · have hne_z : (u : ℤ) ≠ (L_cur : ℤ) := by omega
              rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ hi; exact hne_z hi)]
              have hget : (unusedPrefix g_hat (k + 1))[u] = (unusedPrefix g_hat k)[u] := by
                simp only [hun_step]
                exact List.getElem_append_left hlt
              rw [hget]
              exact h24_k u hlt
            · rw [wordStore_read_write_self]
              have hget : (unusedPrefix g_hat (k + 1))[L_cur] = hk_fin := by
                simp only [hun_step]
                rw [List.getElem_append_right le_rfl]
                simp [L_cur]
              rw [hget]⟩,
          ExecBounded.mono (ExecBounded.seq ex_ite ex_nx) (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩)
  rcases hInvUEnd with ⟨hbsU, haU, hpU, h5U, _, _, _, h24U⟩; subst bsU
  have ex_d4 := ExecBounded.seq ex_d4_0 (ExecBounded.seq ex_d4_1 ex_d4_loop)
  -- D.5: `p4dFillStmt` (Pass 2: fill `-1` slots in `var 5` from `var 24`)
  obtain ⟨ha_d5_0, ex_d5_0⟩ := exec_wl_reg 11 0 (.lit 0) haU hinp (val := 0) rfl (ibl_zero_le hV16)
  obtain ⟨ha_d5_1, ex_d5_1⟩ := exec_wl_reg 11 1 (.lit 0) ha_d5_0 hinp (val := 0) rfl (ibl_zero_le hV16)
  have hp_d5_1 : PreserveOutside4 ws₃ (wsOf ha_d5_1) :=
    (hpU.write_local 0 _ (Or.inr (Or.inr (by decide)))).write_local 1 _ (Or.inr (Or.inr (by decide)))
  let InvFill : ℕ → WordStore → List Bool → Prop := fun k ws_k bs_k =>
    bs_k = bs ∧
    InAttemptArena A V ws_k ∧
    PreserveOutside4 ws₃ ws_k ∧
    (∀ (u : ℕ) (hu : u < (unusedPrefix g_hat p.m).length),
      ws_k.read (.localFrame 1 24 (u : ℤ)) = (((unusedPrefix g_hat p.m)[u]).1 : ℤ)) ∧
    ws_k.read (.localFrame 1 11 0) = (k : ℤ) ∧
    ws_k.read (.localFrame 1 11 1) = (emptyBefore p.s₀ g_hat k : ℤ) ∧
    (∀ idx : Fin p.m,
      ws_k.read (.localFrame 1 5 (idx.1 : ℤ)) =
        if idx.1 < k then
          ((coreFillFn hs₁_1 hs₁_le_s₀ hrs g_hat idx).1 : ℤ)
        else
          optToInt (coreSlotOpt p.s₀ g_hat idx))
  have hInvFill0 : InvFill 0 (wsOf ha_d5_1) bs :=
    ⟨rfl, ha_d5_1, hp_d5_1,
     fun u hu => by simp [wsOf, rw_write_eq, h24U u hu],
     by simp [wsOf, rw_write_eq],
     wordStore_read_write_self _ _ _,
     fun idx => by simp [wsOf, rw_write_eq, h5U idx]⟩
  obtain ⟨ws5, bs5, hInv5End, ex_d5_loop⟩ := exec_repeatN_inv (bs₀ := bs)
    (U := 272) (B := 264000 * (V + 8) ^ 2)
    (countE := .readLocal 0 (.lit 2)) (body := p4dFillBody) p.m InvFill ha_d5_1 hinp
    (exprInArena_small (by decide) (by decide) hV16) (by decide)
    (by have hm0 := (hp_d5_1.2 0 2 (by decide) (by decide) (by decide)).trans hregs.1.2.2.1
        dsimp [wsOf] at hm0; simp [hm0])
    hInvFill0
    (fun k ws_k bs_k hk hInv_k => by
      rcases hInv_k with ⟨hbs_k, ha_k, hp_k, h24_k, hr11_0, hr11_1, h5_k⟩; subst bs_k
      let idx_k : Fin p.m := ⟨k, hk⟩
      have h5_at_k : ws_k.read (.localFrame 1 5 (k : ℤ)) = optToInt (coreSlotOpt p.s₀ g_hat idx_k) := by
        have h := h5_k idx_k
        rw [if_neg (Nat.lt_irrefl k)] at h
        exact h
      cases hopt : coreSlotOpt p.s₀ g_hat idx_k with
      | some y =>
          have hc_f : evalCondVal inp ws_k (.intEq (.readLocal 5 (.readLocal 11 (.lit 0))) (.lit (-1))) = false := by
            simp only [evalCondVal_intEq, evalVal_readLocal, evalVal_lit, hr11_0, h5_at_k, hopt, optToInt]
            exact decide_eq_false (by omega)
          have ex_ite := exec_ite_s (.seq (.writeLocal 5 (.readLocal 11 (.lit 0)) (.readLocal 24 (.readLocal 11 (.lit 1)))) (.writeLocal 11 (.lit 1) (.add (.readLocal 11 (.lit 1)) (.lit 1)))) .skip ha_k hinp hc_f
            (by simpa using exec_skip_s ws_k bs hinp)
          obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) ha_k hinp (val := ((k + 1 : ℕ) : ℤ))
            (by simp [hr11_0]; try (push_cast; ring)) (hib_2m (by omega))
          have heb_step : emptyBefore p.s₀ g_hat (k + 1) = emptyBefore p.s₀ g_hat k := by
            simp [emptyBefore, hk, idx_k, hopt]
          have hfn_k : coreFillFn hs₁_1 hs₁_le_s₀ hrs g_hat idx_k = y :=
            coreFillFn_of_some hs₁_1 hs₁_le_s₀ hrs g_hat hopt
          refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx,
            hp_k.write_local 0 _ (Or.inr (Or.inr (by decide))),
            fun u hu => by simp [wsOf, rw_write_eq, h24_k u hu],
            wordStore_read_write_self _ _ _,
            by simp [wsOf, rw_write_eq, heb_step, hr11_1],
            fun idx => by
              rw [rw_local_var_ne _ (by decide), h5_k idx]
              by_cases hlt : idx.1 < k
              · rw [if_pos hlt, if_pos (by omega : idx.1 < k + 1)]
              · rw [if_neg hlt]
                by_cases heq : idx.1 = k
                · have hidx_eq : idx = idx_k := Fin.ext heq
                  subst hidx_eq
                  rw [if_pos (Nat.lt_succ_self k), hopt, hfn_k]; rfl
                · rw [if_neg (by omega : ¬ idx.1 < k + 1)]⟩,
            ExecBounded.mono (ExecBounded.seq ex_ite ex_nx) (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩
      | none =>
          have hc_t : evalCondVal inp ws_k (.intEq (.readLocal 5 (.readLocal 11 (.lit 0))) (.lit (-1))) = true := by
            simp [evalCondVal_intEq, evalVal_readLocal, evalVal_lit, hr11_0, h5_at_k, hopt, optToInt]
          let u_ptr := emptyBefore p.s₀ g_hat k
          have hu_lt : u_ptr < (unusedPrefix g_hat p.m).length :=
            emptyBefore_lt_unused_length hs₁_1 hs₁_le_s₀ hrs g_hat hopt
          let u_val : Fin p.m := (unusedPrefix g_hat p.m)[u_ptr]
          have hfn_k : coreFillFn hs₁_1 hs₁_le_s₀ hrs g_hat idx_k = u_val :=
            coreFillFn_of_none hs₁_1 hs₁_le_s₀ hrs g_hat hopt
          obtain ⟨ha_w5, ex_w5⟩ := exec_wl (bs := bs) ha_k hinp
            (var := 5) (idxE := .readLocal 11 (.lit 0)) (idx := (k : ℤ))
            (valE := .readLocal 24 (.readLocal 11 (.lit 1))) (val := (u_val.1 : ℤ))
            (by simp [hr11_0])
            (by simp [hr11_1, h24_k u_ptr hu_lt, u_ptr, u_val])
            (by positivity)
            (by rw [Int.toNat_natCast]; omega)
            (hib_2m (by have := u_val.2; omega))
          obtain ⟨ha_u1, ex_u1⟩ := exec_wl_reg 11 1 (.add (.readLocal 11 (.lit 1)) (.lit 1)) ha_w5 hinp (val := ((u_ptr + 1 : ℕ) : ℤ))
            (by simp [wsOf, rw_write_eq, hr11_1, u_ptr]; try (push_cast; ring))
            (hib_2m (by have hlen : (unusedPrefix g_hat p.m).length ≤ p.m := by
                          rw [(unusedPrefix_props g_hat p.m le_rfl).2.2]
                          exact (Finset.card_filter_le _ _).trans (by simp)
                        omega))
          have ex_ite := exec_ite_s (.seq (.writeLocal 5 (.readLocal 11 (.lit 0)) (.readLocal 24 (.readLocal 11 (.lit 1)))) (.writeLocal 11 (.lit 1) (.add (.readLocal 11 (.lit 1)) (.lit 1)))) .skip ha_k hinp hc_t
            (by simpa using ExecBounded.seq ex_w5 ex_u1)
          obtain ⟨ha_nx, ex_nx⟩ := exec_wl_reg 11 0 (.add (.readLocal 11 (.lit 0)) (.lit 1)) ha_u1 hinp (val := ((k + 1 : ℕ) : ℤ))
            (by simp [wsOf, rw_write_eq, hr11_0]; try (push_cast; ring))
            (hib_2m (by omega))
          have heb_step : emptyBefore p.s₀ g_hat (k + 1) = u_ptr + 1 := by
            simp [emptyBefore, hk, idx_k, hopt, u_ptr]
          refine ⟨wsOf ha_nx, bs, ⟨rfl, ha_nx,
            ((hp_k.write_local (k : ℤ) _ (Or.inr (Or.inl rfl))).write_local
               1 _ (Or.inr (Or.inr (by decide)))).write_local 0 _ (Or.inr (Or.inr (by decide))),
            fun u hu => by simp [wsOf, rw_write_eq, h24_k u hu],
            wordStore_read_write_self _ _ _,
            by simp [wsOf, rw_write_eq, heb_step],
            fun idx => by
              rw [rw_local_var_ne _ (by decide), rw_local_var_ne _ (by decide)]
              by_cases heq : idx = idx_k
              · subst heq
                rw [wordStore_read_write_self, if_pos (Nat.lt_succ_self k), hfn_k]
              · have hne_z : (idx.1 : ℤ) ≠ (k : ℤ) :=
                  fun hv => heq (Fin.ext (Int.ofNat.inj hv))
                rw [wordStore_read_write_of_ne _ (by intro hc; injection hc with _ _ hi; exact hne_z hi),
                    h5_k idx]
                by_cases hlt : idx.1 < k
                · rw [if_pos hlt, if_pos (by omega : idx.1 < k + 1)]
                · have hne_n : idx.1 ≠ k := fun hv => heq (Fin.ext hv)
                  rw [if_neg hlt, if_neg (by omega : ¬ idx.1 < k + 1)]⟩,
            ExecBounded.mono (ExecBounded.seq ex_ite ex_nx) (by omega) (by set Y := (V + 8) ^ 2; omega) le_rfl le_rfl⟩)
  rcases hInv5End with ⟨hbs5, ha5, hp5, _, _, _, h5_final⟩; subst bs5
  have ex_d5 := ExecBounded.seq ex_d5_0 (ExecBounded.seq ex_d5_1 ex_d5_loop)
  have hperm : HasPermArray p.m (coreFillPerm hs₁_1 hs₁_le_s₀ hrs g_hat) ws5 := by
    intro idx
    rw [h5_final idx, if_pos idx.2, coreFillPerm_apply]
  have ex_tot :=
    ExecBounded.seq ex_d1 (ExecBounded.seq ex_d2 (ExecBounded.seq ex_d3
    (ExecBounded.seq ex_d4 ex_d5)))
  refine ⟨ws5, ha5, hp5, hperm, ExecBounded.mono ex_tot ?_ ?_ le_rfl le_rfl⟩
  · have : p.r * (600 + 600 * s₁) = 600 * p.r + 600 * (p.r * s₁) := by ring
    omega
  · simp only [← Nat.mul_assoc, ← Nat.add_mul]
    apply Nat.mul_le_mul_right
    have : p.r * (600000 + 600000 * s₁) = 600000 * p.r + 600000 * (p.r * s₁) := by ring
    omega

/-! ### 2. Full `exactPhase4Stmt` combining Substages A, B, C, D -/

def exactPhase4Stmt (K₀ deg_α₀ : ℕ) : BitRAMStmt :=
  .seq (p4aSetupStmt K₀ deg_α₀)
  (.seq p4bDrawStmt
  (.seq p4cHornerStmt
        p4dBuildPermStmt))

theorem exec_exactPhase4Stmt {A V M K₀ deg_α₀ : ℕ} (p : CoreParams)
    (pts_h : ℕ → Fin p.d → ℚ) (zRat : Fin p.D → ℚ)
    (f_poly : Fin (2 * s₁Val K₀ deg_α₀ p.d) → Fin p.W₂ → Bool) (restBits : List Bool)
    {inp : BitRAMInput p.d} {ws₄ : WordStore}
    (hK₀ : 1 ≤ K₀)
    (hpK : p.K = 25 * K₀ ^ 2)
    (hpdeg : p.deg_α = 2 * deg_α₀ + 1)
    (harena : InAttemptArena A V ws₄)
    (hhz : HeapAllZero ws₄)
    (hregs : HasPhase2Regs p M ws₄)
    (hlifts : HasLiftArrays p pts_h ws₄)
    (hz : HasZArray p.D zRat ws₄)
    (hinp : ArenaInputOK A V inp)
    (hfit : ParamFit A V p) :
    let s₁ := s₁Val K₀ deg_α₀ p.d
    have hs₁_2 : 2 ≤ s₁ := by have := s₁Val_ge_144 (deg_α := deg_α₀) hK₀ p.d; omega
    have hs₀_ge : 64 * s₁ ^ 2 ≤ p.s₀ := by
      dsimp [CoreParams.s₀, s₁]; rw [hpK, hpdeg]; exact sixtyFour_s₁Val_sq_le_s₀Val hK₀ p.d
    have hm2s : 2 * p.s₀ ≤ p.m := hfit.2.2.2.1
    ∃ ws₅ : WordStore,
      InAttemptArena A V ws₅ ∧
      HeapAllZero ws₅ ∧
      HasPhase2Regs p M ws₅ ∧
      HasLiftArrays p pts_h ws₅ ∧
      HasZArray p.D zRat ws₅ ∧
      HasPermArray p.m (permOfPolyBits hs₁_2 hs₀_ge hm2s f_poly) ws₅ ∧
      ExecBounded inp (exactPhase4Stmt K₀ deg_α₀)
        ws₄ (blockBitStream f_poly restBits 0) ws₅ restBits
        (4400 + 200 * deg_α₀ + 12000 * p.m + (2 * s₁) * (300 + 24 * (p.W₂ + 1)))
        ((4400000 + 200000 * deg_α₀ + 12500000 * p.m) * (V + 8) ^ 2)
        (arenaCellCap inp A) (arenaBitCap inp A V) := by
  dsimp only
  obtain ⟨wsA, haA, hpA, hregsA, hcstA, exA⟩ :=
    exec_p4aSetupStmt p hK₀ hpK hpdeg harena hregs hinp hfit (bs := blockBitStream f_poly restBits 0)
  obtain ⟨wsB, haB, hpB, hregsB, hcstB, hrawB, exB⟩ :=
    exec_p4bDrawStmt p f_poly restBits hK₀ hpK hpdeg haA hregsA hcstA hinp hfit
  obtain ⟨wsC, haC, hpC, hregsC, hcstC, hghatC, exC⟩ :=
    exec_p4cHornerStmt p f_poly hK₀ hpK hpdeg haB hregsB hcstB hrawB hinp hfit (bs := restBits)
  obtain ⟨ws₅, ha5, hpD, hperm5, exD⟩ :=
    exec_p4dBuildPermStmt p _ hK₀ hpK hpdeg haC hregsC hcstC hghatC hinp hfit (bs := restBits)
  have hp_tot : PreserveOutside4 ws₄ ws₅ := hpA.trans (hpB.trans (hpC.trans hpD))
  have ex_all := ExecBounded.seq exA (ExecBounded.seq exB (ExecBounded.seq exC exD))
  refine ⟨ws₅, ha5,
    heapAllZero_of_eq_heap hhz hp_tot.1,
    hasPhase2Regs_of_eq hregs (fun idx => hp_tot.2 0 idx (by decide) (by decide) (by decide)),
    hasLiftArrays_of_eq hlifts (fun v idx hv =>
      hp_tot.2 v idx (by rcases hv with rfl | rfl <;> decide)
                     (by rcases hv with rfl | rfl <;> decide)
                     (by rcases hv with rfl | rfl <;> decide)),
    hasZArray_of_eq hz (fun idx => hp_tot.2 4 idx (by decide) (by decide) (by decide)),
    hperm5,
    ExecBounded.mono ex_all (by omega) ?_ le_rfl le_rfl⟩
  simp only [← Nat.mul_assoc, ← Nat.add_mul]
  apply Nat.mul_le_mul_right
  omega

end UL.Proof_lem_A_2
