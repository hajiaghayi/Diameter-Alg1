import Mathlib
import UL.Proof.lem_A_2.H2b_SubSim
set_option autoImplicit false
set_option maxHeartbeats 400000

namespace UL.Proof_lem_A_2

/-! ### 1. Syntax translation `trExpr`, `trCond`, `trStmt` -/

def addr2DExpr (hTr cTr : IntExpr) : IntExpr :=
  let ME := IntExpr.readHeap 5 (.lit 2)
  let DE := IntExpr.add .dim (.lit 1)
  let valE := IntExpr.mul (inRangeExpr hTr ME) (inRangeExpr cTr DE)
  IntExpr.mul valE (.add (.add (.mul hTr DE) cTr) (.lit 1))

def trExpr (isDimD : Bool) (T_max : ℕ) : IntExpr → IntExpr
  | .lit c => .lit c
  | .dim => if isDimD then .add .dim (.lit 1) else .lit 0
  | .intParam idxE => .readHeap 5 (trExpr isDimD T_max idxE)
  | .readHeap table idxE =>
      .readHeap 10 (.add (.mul (trExpr isDimD T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ)))
  | .readLocal var idxE => .readLocal var (trExpr isDimD T_max idxE)
  | .activeRatNum hE cE =>
      if isDimD then .readHeap 6 (addr2DExpr (trExpr isDimD T_max hE) (trExpr isDimD T_max cE))
      else .lit 0
  | .activeRatDen hE cE =>
      if isDimD then
        .add (.readHeap 7 (addr2DExpr (trExpr isDimD T_max hE) (trExpr isDimD T_max cE))) (.lit 1)
      else .lit 1
  | .extraRatNum idxE =>
      if isDimD then .lit 0 else .readHeap 6 (trExpr isDimD T_max idxE)
  | .extraRatDen idxE =>
      if isDimD then .lit 1 else .add (.readHeap 7 (trExpr isDimD T_max idxE)) (.lit 1)
  | .neg e => .neg (trExpr isDimD T_max e)
  | .add e₁ e₂ => .add (trExpr isDimD T_max e₁) (trExpr isDimD T_max e₂)
  | .sub e₁ e₂ => .sub (trExpr isDimD T_max e₁) (trExpr isDimD T_max e₂)
  | .mul e₁ e₂ => .mul (trExpr isDimD T_max e₁) (trExpr isDimD T_max e₂)
  | .div e₁ e₂ => .div (trExpr isDimD T_max e₁) (trExpr isDimD T_max e₂)
  | .mod e₁ e₂ => .mod (trExpr isDimD T_max e₁) (trExpr isDimD T_max e₂)

def trCond (isDimD : Bool) (T_max : ℕ) : BitCondExpr → BitCondExpr
  | .intEq e₁ e₂ => .intEq (trExpr isDimD T_max e₁) (trExpr isDimD T_max e₂)
  | .intLt e₁ e₂ => .intLt (trExpr isDimD T_max e₁) (trExpr isDimD T_max e₂)
  | .intLe e₁ e₂ => .intLe (trExpr isDimD T_max e₁) (trExpr isDimD T_max e₂)
  | .not c => .not (trCond isDimD T_max c)
  | .and c₁ c₂ => .and (trCond isDimD T_max c₁) (trCond isDimD T_max c₂)
  | .or c₁ c₂ => .or (trCond isDimD T_max c₁) (trCond isDimD T_max c₂)

def trStmt (isDimD : Bool) (T_max : ℕ) : BitRAMStmt → BitRAMStmt
  | .skip => .skip
  | .writeHeap table idxE valE =>
      let encE := IntExpr.add (.mul (trExpr isDimD T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ))
      .seq (.writeHeap 11 (.readHeap 12 (.lit 0)) encE)
      (.seq (.writeHeap 10 (.readHeap 11 (.readHeap 12 (.lit 0))) (trExpr isDimD T_max valE))
            (.writeHeap 12 (.lit 0) (.add (.readHeap 12 (.lit 0)) (.lit 1))))
  | .writeLocal var idxE valE =>
      .writeLocal var (trExpr isDimD T_max idxE) (trExpr isDimD T_max valE)
  | .freeHeap table idxE =>
      .freeHeap 10 (.add (.mul (trExpr isDimD T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ)))
  | .freeLocal var idxE =>
      .freeLocal var (trExpr isDimD T_max idxE)
  | .randBitHeap table idxE =>
      .randBitHeap 10 (.add (.mul (trExpr isDimD T_max idxE) (.lit (T_max : ℤ))) (.lit (table : ℤ)))
  | .randBitLocal var idxE =>
      .randBitLocal var (trExpr isDimD T_max idxE)
  | .seq s₁ s₂ => .seq (trStmt isDimD T_max s₁) (trStmt isDimD T_max s₂)
  | .ite c tB fB => .ite (trCond isDimD T_max c) (trStmt isDimD T_max tB) (trStmt isDimD T_max fB)
  | .whileLoop c body => .whileLoop (trCond isDimD T_max c) (trStmt isDimD T_max body)
  | .repeatN countE body => .repeatN (trExpr isDimD T_max countE) (trStmt isDimD T_max body)
  | .localScope body => .localScope (trStmt isDimD T_max body)

def trCont (isDimD : Bool) (T_max : ℕ) : BitRAMCont → BitRAMCont
  | .stmt s => .stmt (trStmt isDimD T_max s)
  | .repeatLoop rem body => .repeatLoop rem (trStmt isDimD T_max body)
  | .popScope prev => .popScope (2 + prev)

/-! ### 2. Expression blowup factor and staging predicate -/

def exprFactor : IntExpr → ℕ
  | .lit _ | .dim => 64
  | .intParam e | .readHeap _ e | .readLocal _ e
  | .extraRatNum e | .extraRatDen e | .neg e => 64 * exprFactor e
  | .add e₁ e₂ | .sub e₁ e₂ | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ =>
      64 * (exprFactor e₁ + exprFactor e₂)
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ =>
      2048 * (exprFactor e₁ + exprFactor e₂)

def condFactor : BitCondExpr → ℕ
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => 16 * (exprFactor e₁ + exprFactor e₂)
  | .not c => 16 * condFactor c
  | .and c₁ c₂ | .or c₁ c₂ => 16 * (condFactor c₁ + condFactor c₂)

def stmtFactor : BitRAMStmt → ℕ
  | .skip => 64
  | .writeHeap _ e₁ e₂ | .writeLocal _ e₁ e₂ => 64 * (exprFactor e₁ + exprFactor e₂)
  | .freeHeap _ e | .freeLocal _ e | .randBitHeap _ e | .randBitLocal _ e => 64 * exprFactor e
  | .repeatN e body => max (64 * exprFactor e) (stmtFactor body)
  | .seq s₁ s₂ => max (stmtFactor s₁) (stmtFactor s₂)
  | .ite c s₁ s₂ => max (condFactor c) (max (stmtFactor s₁) (stmtFactor s₂))
  | .whileLoop c body => max (condFactor c) (stmtFactor body)
  | .localScope body => stmtFactor body

theorem exprFactor_pos (e : IntExpr) : 1 ≤ exprFactor e := by
  induction e <;> simp [exprFactor] <;> omega

theorem condFactor_pos (c : BitCondExpr) : 1 ≤ condFactor c := by
  induction c with
  | intEq e₁ _ | intLt e₁ _ | intLe e₁ _ =>
      simp only [condFactor]; have := exprFactor_pos e₁; omega
  | not _ ih => simp only [condFactor]; omega
  | and _ _ ih₁ _ | or _ _ ih₁ _ => simp only [condFactor]; omega

theorem stmtFactor_pos (s : BitRAMStmt) : 1 ≤ stmtFactor s := by
  induction s with
  | skip => decide
  | writeHeap _ e₁ _ | writeLocal _ e₁ _ =>
      simp only [stmtFactor]; have := exprFactor_pos e₁; omega
  | freeHeap _ e | freeLocal _ e | randBitHeap _ e | randBitLocal _ e =>
      simp only [stmtFactor]; have := exprFactor_pos e; omega
  | repeatN e _ _ =>
      simp only [stmtFactor]; have := exprFactor_pos e; omega
  | seq _ _ ih₁ _ | localScope _ ih₁ =>
      simp only [stmtFactor]; omega
  | ite c _ _ _ _ | whileLoop c _ _ =>
      simp only [stmtFactor]; have := condFactor_pos c; omega

def SimStageMatches (isDimD : Bool) (d dSub : ℕ) (L_p : ℕ)
    (wsBase : WordStore) (inpSub : BitRAMInput dSub) : Prop :=
  IsSimBaseStore wsBase ∧
  8 ≤ L_p ∧
  intBitLength (d : ℤ) ≤ L_p ∧
  (if isDimD then
    dSub = d + 1 ∧
    inpSub.extraRats = [] ∧
    ∃ M : ℕ, 1 ≤ M ∧
      intBitLength (M : ℤ) ≤ L_p ∧
      inpSub.activeHandles = Finset.range M ∧
      wsBase.read (.heap 5 2) = (M : ℤ) ∧
      (∀ idx : ℤ, wsBase.read (.heap 5 idx) = listGetIntD inpSub.intParams idx 0) ∧
      wsBase.read (.heap 6 0) = 0 ∧
      wsBase.read (.heap 7 0) = 0 ∧
      (∀ (j : ℕ), j < M → ∀ c : Fin dSub,
        let a : ℤ := ((j * dSub + c.1 + 1 : ℕ) : ℤ)
        wsBase.read (.heap 6 a) = (inpSub.activeRatCoords j c).num ∧
        wsBase.read (.heap 7 a) + 1 = ((inpSub.activeRatCoords j c).den : ℤ))
  else
    dSub = 0 ∧
    inpSub.activeHandles = ∅ ∧
    (∀ idx : ℤ, wsBase.read (.heap 5 idx) = listGetIntD inpSub.intParams idx 0) ∧
    (∀ idx : ℤ, wsBase.read (.heap 6 idx) = (listGetIntD inpSub.extraRats idx 0).num) ∧
    (∀ idx : ℤ, wsBase.read (.heap 7 idx) + 1 = ((listGetIntD inpSub.extraRats idx 0).den : ℤ)))

def AgreesForExpr (wsBase : WordStore) (T_max : ℕ) (wsSub : WordStore) (fd : ℕ)
    (wsSim : WordStore) : Prop :=
  (∀ t idx, t < 8 → wsSim.read (.heap t idx) = wsBase.read (.heap t idx)) ∧
  (∀ t idx, t < T_max → wsSim.read (.heap 10 (idx * (T_max : ℤ) + (t : ℤ))) = wsSub.read (.heap t idx)) ∧
  (∀ var idx, wsSim.read (.localFrame (2 + fd) var idx) = wsSub.read (.localFrame fd var idx))

theorem agreesForExpr_simMergeStore {wsBase : WordStore} (hbase : IsSimBaseStore wsBase)
    {T_max : ℕ} (hT : 1 ≤ T_max) {wsSub : WordStore} (hsub : WellFormedWS wsSub)
    (log : List ℤ) (fd : ℕ) :
    AgreesForExpr wsBase T_max wsSub fd (simMergeStore wsBase T_max hT wsSub log) := by
  refine ⟨fun t idx ht => simMergeStore_read_base_heap hbase hT hsub log ht idx, ?_, ?_⟩
  · intro t idx ht
    have h := simMergeStore_read_sub hbase hT hsub log (.heap t idx)
    simpa [shiftSubLoc, ht] using h
  · intro var idx
    exact simMergeStore_read_sub hbase hT hsub log (.localFrame fd var idx)

theorem agreesForExpr_write_heap11 {wsBase : WordStore} {T_max : ℕ} {wsSub : WordStore}
    {fd : ℕ} {wsSim : WordStore} (hag : AgreesForExpr wsBase T_max wsSub fd wsSim)
    (k v : ℤ) :
    AgreesForExpr wsBase T_max wsSub fd (wsSim.write (.heap 11 k) v) := by
  refine ⟨fun t idx ht => ?_, fun t idx ht => ?_, fun var idx => ?_⟩
  · rw [wordStore_read_write_of_ne _ (by intro h; injection h with ht' _; omega)]
    exact hag.1 t idx ht
  · rw [wordStore_read_write_of_ne _ (by intro h; injection h with ht' _; omega)]
    exact hag.2.1 t idx ht
  · rw [wordStore_read_write_of_ne _ (by intro h; nomatch h)]
    exact hag.2.2 var idx

private theorem eval_inRangeExpr {d : ℕ} (inpSim : BitRAMInput d) (fd : ℕ) (wsSim : WordStore)
    {xE NE : IntExpr} {x N : ℤ} {ux bx uN bN : ℕ}
    (hx : evalIntExpr inpSim fd wsSim xE = (x, ux, bx))
    (hN : evalIntExpr inpSim fd wsSim NE = (N, uN, bN))
    (hN1 : 1 ≤ N) :
    ∃ uOut bOut : ℕ,
      evalIntExpr inpSim fd wsSim (inRangeExpr xE NE) =
        (if 0 ≤ x ∧ x < N then 1 else 0, uOut, bOut) ∧
      uOut ≤ 2 * ux + 2 * uN + 8 ∧
      bOut ≤ 2 * bx + 2 * bN + 2 * intBitLength x * intBitLength N +
        (intBitLength x + 5) ^ 2 + 16 := by
  have hbx_len := (evalIntExpr_bitLen_le inpSim fd wsSim xE)
  rw [hx] at hbx_len
  unfold inRangeExpr
  dsimp only
  simp only [evalIntExpr, hx, hN]
  have hval := inRange_val_eq (x := x) (N := N) hN1
  rw [hval]
  let q := x / N
  have hq_abs : q.natAbs ≤ x.natAbs := by
    dsimp [q]
    have hN_ne : N ≠ 0 := by omega
    have hmod := Int.mul_ediv_add_emod x N
    have hm0 : 0 ≤ x % N := Int.emod_nonneg x hN_ne
    have hm1 : x % N < N := Int.emod_lt_of_pos x (by omega)
    by_cases hx0 : 0 ≤ x
    · have hq0 : 0 ≤ x / N := Int.ediv_nonneg hx0 (by omega)
      have hle : x / N ≤ x := by nlinarith
      omega
    · have hx_neg : x ≤ -1 := by omega
      by_cases hrem0 : x % N = 0
      · have h_Nq : N * (x / N) = x := by linarith
        have h_abs_N : (N * (x / N)).natAbs = N.natAbs * (x / N).natAbs := Int.natAbs_mul N (x / N)
        rw [h_Nq] at h_abs_N
        have hN_pos_nat : 1 ≤ N.natAbs := by omega
        calc
          (x / N).natAbs ≤ N.natAbs * (x / N).natAbs := Nat.le_mul_of_pos_left _ hN_pos_nat
          _ = x.natAbs := h_abs_N.symm
      · have hrem_pos : 1 ≤ x % N := by omega
        have hN2 : 2 ≤ N := by omega
        have h_Nq_lb : N * x ≤ N * (x / N) := by
          have : (N - 1) * (-1 - x) ≥ 0 := mul_nonneg (by omega) (by omega)
          nlinarith
        have h_Nq_ub : N * (x / N) ≤ -1 := by linarith
        have hq_ge_x : x ≤ x / N := by
          by_contra hlt
          push_neg at hlt
          have : N * (x / N) < N * x := mul_lt_mul_of_pos_left hlt (by omega)
          linarith
        have hq_neg : x / N < 0 := by
          by_contra hnn
          push_neg at hnn
          have : 0 ≤ N * (x / N) := mul_nonneg (by omega) hnn
          linarith
        omega
  have hq_ib : intBitLength q ≤ intBitLength x + 1 := intBitLength_mono_natAbs hq_abs
  have hqq_ib : intBitLength (q * q) ≤ 2 * (intBitLength x + 1) :=
    (intBitLength_mul_le q q).trans (by omega)
  have h1qq_ib : intBitLength (1 + q * q) ≤ 2 * intBitLength x + 5 := by
    have := intBitLength_add_le 1 (q * q)
    have hi1 : intBitLength 1 = 2 := by decide
    omega
  have hi1 : intBitLength 1 = 2 := by decide
  refine ⟨_, _, rfl, by omega, ?_⟩
  rw [hi1]
  nlinarith [intBitLength_pos x, intBitLength_pos N]

private theorem add_sq_le_four_mul_sq {L B : ℕ} (hL : 1 ≤ L) (hB : 1 ≤ B) :
    (L + B) * (L + B) ≤ 4 * (L ^ 2) * (B ^ 2) := by
  simp only [sq]
  have hL2 : L ≤ L * L := Nat.le_mul_self L
  have hB2 : B ≤ B * B := Nat.le_mul_self B
  have h1 : L * L ≤ (L * L) * (B * B) := Nat.le_mul_of_pos_right _ (by nlinarith)
  have h2 : B * B ≤ (L * L) * (B * B) := Nat.le_mul_of_pos_left _ (by nlinarith)
  have h3 : L * B ≤ (L * L) * (B * B) := Nat.mul_le_mul hL2 hB2
  linarith [show (L + B) * (L + B) = L * L + 2 * (L * B) + B * B by ring,
            show 4 * (L * L) * (B * B) = 4 * ((L * L) * (B * B)) by ring]

private theorem sim_bound_zero {M L B b' : ℕ} (hM : 4 ≤ M) (hL : 1 ≤ L) (hB : 1 ≤ B)
    (hex : b' ≤ (L + B) * (L + B)) :
    b' ≤ M * (L ^ 2) * (B ^ 2) := by
  calc
    b' ≤ 4 * (L ^ 2) * (B ^ 2) := hex.trans (add_sq_le_four_mul_sq hL hB)
    _ ≤ M * (L ^ 2) * (B ^ 2) := Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ hM)

private theorem sim_bound_unary {M F L b₀ B b'₀ extra : ℕ}
    (hM : 16 ≤ M) (hF : 1 ≤ F) (hL : 1 ≤ L) (hB : 1 ≤ B) (hle : b₀ ≤ B)
    (hb₀ : b'₀ ≤ F * (L ^ 2) * (b₀ ^ 2))
    (hex : extra ≤ 3 * ((L + B) * (L + B))) :
    b'₀ + extra ≤ (M * F) * (L ^ 2) * (B ^ 2) := by
  have hmono : F * (L ^ 2) * (b₀ ^ 2) ≤ F * (L ^ 2) * (B ^ 2) :=
    Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hle 2)
  have hsq := add_sq_le_four_mul_sq hL hB
  have hex1 : extra ≤ 12 * ((L ^ 2) * (B ^ 2)) := by
    calc
      extra ≤ 3 * (4 * (L ^ 2) * (B ^ 2)) := hex.trans (Nat.mul_le_mul_left 3 hsq)
      _ = 12 * ((L ^ 2) * (B ^ 2)) := by ring
  have hex2 : 12 * ((L ^ 2) * (B ^ 2)) ≤ 12 * F * (L ^ 2) * (B ^ 2) := by
    calc
      12 * ((L ^ 2) * (B ^ 2)) = 12 * 1 * (L ^ 2) * (B ^ 2) := by ring
      _ ≤ 12 * F * (L ^ 2) * (B ^ 2) :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 12 hF))
  have htot : (1 + 12) * F * (L ^ 2) * (B ^ 2) ≤ (M * F) * (L ^ 2) * (B ^ 2) :=
    Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by omega)))
  linarith [hb₀.trans hmono, hex1.trans hex2,
    show F * (L ^ 2) * (B ^ 2) + 12 * F * (L ^ 2) * (B ^ 2) =
      (1 + 12) * F * (L ^ 2) * (B ^ 2) by ring]

private theorem sim_bound_binary {M k C F₁ F₂ L b₁ b₂ B b'₁ b'₂ extra : ℕ}
    (hM : k + 4 * C ≤ M) (hF₁ : 1 ≤ F₁) (hF₂ : 1 ≤ F₂) (hL : 1 ≤ L) (hB : 1 ≤ B)
    (hle₁ : b₁ ≤ B) (hle₂ : b₂ ≤ B)
    (hb₁ : b'₁ ≤ F₁ * (L ^ 2) * (b₁ ^ 2))
    (hb₂ : b'₂ ≤ F₂ * (L ^ 2) * (b₂ ^ 2))
    (hex : extra ≤ C * ((L + B) * (L + B))) :
    k * b'₁ + k * b'₂ + extra ≤ (M * (F₁ + F₂)) * (L ^ 2) * (B ^ 2) := by
  have hm₁ : F₁ * (L ^ 2) * (b₁ ^ 2) ≤ F₁ * (L ^ 2) * (B ^ 2) :=
    Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hle₁ 2)
  have hm₂ : F₂ * (L ^ 2) * (b₂ ^ 2) ≤ F₂ * (L ^ 2) * (B ^ 2) :=
    Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hle₂ 2)
  have hk₁ := Nat.mul_le_mul_left k (hb₁.trans hm₁)
  have hk₂ := Nat.mul_le_mul_left k (hb₂.trans hm₂)
  have hsq := add_sq_le_four_mul_sq hL hB
  have hex1 : extra ≤ (4 * C) * ((L ^ 2) * (B ^ 2)) := by
    calc
      extra ≤ C * (4 * (L ^ 2) * (B ^ 2)) := hex.trans (Nat.mul_le_mul_left C hsq)
      _ = (4 * C) * ((L ^ 2) * (B ^ 2)) := by ring
  have hex2 : (4 * C) * ((L ^ 2) * (B ^ 2)) ≤ (4 * C) * (F₁ + F₂) * (L ^ 2) * (B ^ 2) := by
    calc
      (4 * C) * ((L ^ 2) * (B ^ 2)) = (4 * C) * 1 * (L ^ 2) * (B ^ 2) := by ring
      _ ≤ (4 * C) * (F₁ + F₂) * (L ^ 2) * (B ^ 2) :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ (by omega)))
  have htot : (k + 4 * C) * (F₁ + F₂) * (L ^ 2) * (B ^ 2) ≤
      (M * (F₁ + F₂)) * (L ^ 2) * (B ^ 2) :=
    Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ hM))
  linarith [hex1.trans hex2,
    show k * (F₁ * (L ^ 2) * (B ^ 2)) + k * (F₂ * (L ^ 2) * (B ^ 2)) +
      (4 * C) * (F₁ + F₂) * (L ^ 2) * (B ^ 2) =
      (k + 4 * C) * (F₁ + F₂) * (L ^ 2) * (B ^ 2) by ring]

private theorem linear_le_three_sq {L B x : ℕ} (hL : 9 ≤ L) (hx : x ≤ 27 * (L + B)) :
    x ≤ 3 * ((L + B) * (L + B)) := by
  let S := L + B
  have hS : 9 ≤ S := by dsimp [S]; omega
  have hSS : 9 * S ≤ S * S := Nat.mul_le_mul_right S hS
  dsimp [S] at hSS
  omega

private theorem prod_le_three_sq {L B a b : ℕ} (ha : a ≤ L + B) (hb : b ≤ L + B) :
    a * b ≤ 3 * ((L + B) * (L + B)) := by
  calc
    a * b ≤ (L + B) * (L + B) := Nat.mul_le_mul ha hb
    _ ≤ 3 * ((L + B) * (L + B)) := Nat.le_mul_of_pos_left _ (by norm_num)

private theorem unit_bound_unary {M F u₀ u'₀ c : ℕ}
    (hM : 1 + c ≤ M) (hF : 1 ≤ F) (hu : u'₀ ≤ F * u₀) :
    u'₀ + c ≤ (M * F) * (u₀ + 1) := by
  have hcF : c ≤ c * (F * (u₀ + 1)) :=
    Nat.le_mul_of_pos_right c (Nat.mul_pos hF (Nat.succ_pos u₀))
  have huF : F * u₀ ≤ 1 * (F * (u₀ + 1)) := by
    rw [one_mul]; exact Nat.mul_le_mul_left F (Nat.le_succ u₀)
  have hsum : (1 + c) * (F * (u₀ + 1)) ≤ (M * F) * (u₀ + 1) := by
    rw [show (1 + c) * (F * (u₀ + 1)) = ((1 + c) * F) * (u₀ + 1) by ring]
    exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ hM)
  linarith [hu.trans huF,
    show 1 * (F * (u₀ + 1)) + c * (F * (u₀ + 1)) = (1 + c) * (F * (u₀ + 1)) by ring]

private theorem unit_bound_binary {M k c F₁ F₂ u₁ u₂ u'₁ u'₂ u : ℕ}
    (hM : k + c ≤ M) (hF₁ : 1 ≤ F₁) (hF₂ : 1 ≤ F₂)
    (hu_ge1 : u₁ ≤ u) (hu_ge2 : u₂ ≤ u) (hu_pos : 1 ≤ u)
    (hu₁ : u'₁ ≤ F₁ * u₁) (hu₂ : u'₂ ≤ F₂ * u₂) :
    k * u'₁ + k * u'₂ + c ≤ (M * (F₁ + F₂)) * u := by
  have hm₁ : F₁ * u₁ ≤ F₁ * u := Nat.mul_le_mul_left F₁ hu_ge1
  have hm₂ : F₂ * u₂ ≤ F₂ * u := Nat.mul_le_mul_left F₂ hu_ge2
  have hk₁ := Nat.mul_le_mul_left k (hu₁.trans hm₁)
  have hk₂ := Nat.mul_le_mul_left k (hu₂.trans hm₂)
  have hcF : c ≤ c * ((F₁ + F₂) * u) :=
    Nat.le_mul_of_pos_right c (Nat.mul_pos (by omega) hu_pos)
  have htot : (k + c) * ((F₁ + F₂) * u) ≤ (M * (F₁ + F₂)) * u := by
    rw [show (k + c) * ((F₁ + F₂) * u) = ((k + c) * (F₁ + F₂)) * u by ring]
    exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ hM)
  linarith [
    show k * (F₁ * u) + k * (F₂ * u) + c * ((F₁ + F₂) * u) =
      (k + c) * ((F₁ + F₂) * u) by ring]

private theorem activeRat_extra_le {L B ih ic iM id0 id1 ihd ihdc ihdc1 iv : ℕ}
    (hL9 : 9 ≤ L)
    (hih : ih ≤ B) (hic : ic ≤ B) (hiM : iM ≤ L) (hid0 : id0 ≤ L) (hid1 : id1 ≤ L)
    (hihd : ihd ≤ ih + id1) (hihdc : ihdc ≤ ihd + ic + 1) (hihdc1 : ihdc1 ≤ ihdc + 3)
    (hiv : iv ≤ B) :
    2 * (3 + 3 + 3 + iM) + 2 * ih * iM + (ih + 5) ^ 2 + 16 +
      (2 * (id0 + 2 + id0 + 2) + 2 * ic * id1 + (ic + 5) ^ 2 + 16) +
      4 + (id0 + 2 + id0 + 2) + ih * id1 + ihd + ic + 4 + ihdc +
      3 * ihdc1 + 24 + 2 * iv ≤
    100 * ((L + B) * (L + B)) := by
  let S := L + B
  have hS9 : 9 ≤ S := by dsimp [S]; omega
  have h1 : 2 * ih * iM ≤ 2 * (S * S) := by
    rw [mul_assoc]; exact Nat.mul_le_mul_left 2 (Nat.mul_le_mul (by dsimp [S]; omega) (by dsimp [S]; omega))
  have h2 : 2 * ic * id1 ≤ 2 * (S * S) := by
    rw [mul_assoc]; exact Nat.mul_le_mul_left 2 (Nat.mul_le_mul (by dsimp [S]; omega) (by dsimp [S]; omega))
  have h3 : ih * id1 ≤ S * S := Nat.mul_le_mul (by dsimp [S]; omega) (by dsimp [S]; omega)
  have h4 : (ih + 5) ^ 2 ≤ 4 * (S * S) := by
    have : ih + 5 ≤ 2 * S := by dsimp [S]; omega
    calc (ih + 5) ^ 2 ≤ (2 * S) ^ 2 := Nat.pow_le_pow_left this 2
      _ = 4 * (S * S) := by ring
  have h5 : (ic + 5) ^ 2 ≤ 4 * (S * S) := by
    have : ic + 5 ≤ 2 * S := by dsimp [S]; omega
    calc (ic + 5) ^ 2 ≤ (2 * S) ^ 2 := Nat.pow_le_pow_left this 2
      _ = 4 * (S * S) := by ring
  have h6 : 45 * S ≤ 5 * (S * S) := by
    calc 45 * S = 5 * (9 * S) := by ring
      _ ≤ 5 * (S * S) := Nat.mul_le_mul_left 5 (Nat.mul_le_mul_right S hS9)
  have hlin : 2 * (3 + 3 + 3 + iM) + 16 + 2 * (id0 + 2 + id0 + 2) + 16 +
      4 + (id0 + 2 + id0 + 2) + ihd + ic + 4 + ihdc + 3 * ihdc1 + 24 + 2 * iv ≤ 45 * S := by
    dsimp [S]; omega
  dsimp [S] at h1 h2 h3 h4 h5 h6 hlin
  omega

theorem evalIntExpr_trExpr {isDimD : Bool} {d dSub T_max L_p : ℕ}
    {inpSim : BitRAMInput d} {inpSub : BitRAMInput dSub}
    {wsBase wsSub wsSim : WordStore} {fd : ℕ}
    (hstage : SimStageMatches isDimD d dSub L_p wsBase inpSub)
    (hag : AgreesForExpr wsBase T_max wsSub fd wsSim) :
    ∀ (e : IntExpr),
      maxTableExpr e ≤ T_max →
      let (v, u, b) := evalIntExpr inpSub fd wsSub e
      let (v', u', b') := evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max e)
      v' = v ∧
      u' ≤ exprFactor e * u ∧
      b' ≤ exprFactor e * (L_p + natBitLength T_max + 8) ^ 2 * (b ^ 2) := by
  have hLp8_top : 8 ≤ L_p := hstage.2.1
  have hT1_top : 1 ≤ natBitLength T_max := natBitLength_pos T_max
  let L : ℕ := L_p + natBitLength T_max + 8
  have hL9 : 9 ≤ L := by dsimp [L]; omega
  have hL1 : 1 ≤ L := by omega
  intro e
  induction e with
  | lit c =>
      intro _
      dsimp only [trExpr, evalIntExpr, exprFactor]
      have hb := intBitLength_pos c
      exact ⟨rfl, by omega,
        sim_bound_zero (M := 64) (L := L) (B := intBitLength c) (by norm_num) hL1 hb
          (Nat.le_trans (by omega) (Nat.le_mul_self (L + intBitLength c)))⟩
  | dim =>
      intro _
      obtain ⟨_, _, hd_ib, hcases⟩ := hstage
      cases isDimD with
      | false =>
          dsimp at hcases
          rcases hcases with ⟨rfl, _⟩
          have hi0 : intBitLength 0 = 1 := rfl
          simp only [Bool.false_eq_true, ↓reduceIte, trExpr, evalIntExpr, exprFactor, Nat.cast_zero, hi0]
          exact ⟨by simp, by omega,
            sim_bound_zero (M := 64) (L := L) (B := 1) (by norm_num) hL1 le_rfl
              (Nat.le_trans (by dsimp [L]; omega) (Nat.le_mul_self (L + 1)))⟩
      | true =>
          dsimp at hcases
          rcases hcases with ⟨rfl, _⟩
          have hi1 : intBitLength 1 = 2 := by decide
          have hb_d1 := intBitLength_pos ((d + 1 : ℕ) : ℤ)
          simp only [↓reduceIte, trExpr, evalIntExpr, exprFactor, hi1]
          refine ⟨by push_cast; ring, by omega, ?_⟩
          refine sim_bound_zero (M := 64) (L := L) (B := intBitLength ((d + 1 : ℕ) : ℤ))
            (by norm_num) hL1 hb_d1 ?_
          calc
            intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2
                ≤ 3 * (L + intBitLength ((d + 1 : ℕ) : ℤ)) := by dsimp [L]; omega
            _ ≤ (L + intBitLength ((d + 1 : ℕ) : ℤ)) * (L + intBitLength ((d + 1 : ℕ) : ℤ)) :=
                Nat.mul_le_mul_right _ (by dsimp [L]; omega)
  | intParam idxE ih =>
      intro htm
      have hrec := ih htm
      have hbl := evalIntExpr_bitLen_le inpSub fd wsSub idxE
      rcases h1 : evalIntExpr inpSub fd wsSub idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max idxE) with ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at hrec; simp only [h1] at hbl
      rcases hrec with ⟨heq, hu₀, hb₀⟩; subst idx'
      have hparam : wsBase.read (.heap 5 idx) = listGetIntD inpSub.intParams idx 0 := by
        obtain ⟨_, _, _, hc⟩ := hstage
        cases isDimD <;> dsimp at hc
        · exact hc.2.2.1 idx
        · rcases hc.2.2 with ⟨_, _, _, _, _, hp, _⟩; exact hp idx
      have hn5 : natBitLength 5 = 3 := by decide
      simp only [trExpr, evalIntExpr, h1, h2, hag.1 5 idx (by omega), hparam, exprFactor, hn5]
      set v := listGetIntD inpSub.intParams idx 0
      have hef := exprFactor_pos idxE
      refine ⟨by simp, unit_bound_unary (by norm_num) hef hu₀, ?_⟩
      refine le_trans ?_
        (sim_bound_unary (B := b₀ + intBitLength idx + intBitLength v)
          (extra := 3 + intBitLength idx + intBitLength v)
          (by norm_num) hef hL1 (by omega) (by omega) hb₀
          (linear_le_three_sq hL9 (by omega)))
      omega
  | readHeap table idxE ih =>
      intro htm
      simp only [maxTableExpr, max_le_iff] at htm
      have hrec := ih htm.2
      have hbl := evalIntExpr_bitLen_le inpSub fd wsSub idxE
      rcases h1 : evalIntExpr inpSub fd wsSub idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max idxE) with ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at hrec; simp only [h1] at hbl
      rcases hrec with ⟨heq, hu₀, hb₀⟩; subst idx'
      have hn10 : natBitLength 10 = 4 := by decide
      simp only [trExpr, evalIntExpr, h1, h2, hag.2.1 table idx htm.1, exprFactor, hn10]
      have hT_ib : intBitLength (T_max : ℤ) ≤ natBitLength T_max + 1 := by
        unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
      have ht_ib : intBitLength (table : ℤ) ≤ natBitLength table + 1 := by
        unfold intBitLength; split_ifs <;> (try simp only [Int.natAbs_natCast]) <;> omega
      have hmul_ib := intBitLength_mul_le idx (T_max : ℤ)
      have hadd_ib := intBitLength_add_le (idx * (T_max : ℤ)) (table : ℤ)
      set v := wsSub.read (.heap table idx)
      have hef := exprFactor_pos idxE
      refine ⟨by simp, le_trans (by omega : _ ≤ u'₀ + 5) (unit_bound_unary (by norm_num) hef hu₀), ?_⟩
      refine le_trans ?_
        (sim_bound_unary (B := b₀ + natBitLength table + intBitLength idx + intBitLength v)
          (extra := intBitLength (T_max : ℤ) + intBitLength idx * intBitLength (T_max : ℤ) +
            intBitLength (table : ℤ) + intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ) +
            4 + intBitLength (idx * (T_max : ℤ) + (table : ℤ)) + intBitLength v)
          (by norm_num) hef hL1 (by omega) (by omega) hb₀ ?_)
      · omega
      · set S := (L_p + natBitLength T_max + 8) +
            (b₀ + natBitLength table + intBitLength idx + intBitLength v)
        have hS9 : 9 ≤ S := by dsimp [S]; omega
        have hSS : 9 * S ≤ S * S := Nat.mul_le_mul_right S hS9
        have hprod : intBitLength idx * intBitLength (T_max : ℤ) ≤ S * S :=
          Nat.mul_le_mul (by dsimp [S]; omega) (by dsimp [S]; omega)
        have hlin : intBitLength (T_max : ℤ) + intBitLength (table : ℤ) +
            intBitLength (idx * (T_max : ℤ)) + intBitLength (table : ℤ) + 4 +
            intBitLength (idx * (T_max : ℤ) + (table : ℤ)) + intBitLength v ≤ 9 * S := by
          dsimp [S]; omega
        change _ ≤ 3 * (S * S)
        omega
  | readLocal var idxE ih =>
      intro htm
      have hrec := ih htm
      have hbl := evalIntExpr_bitLen_le inpSub fd wsSub idxE
      rcases h1 : evalIntExpr inpSub fd wsSub idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max idxE) with ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at hrec; simp only [h1] at hbl
      rcases hrec with ⟨heq, hu₀, hb₀⟩; subst idx'
      simp only [trExpr, evalIntExpr, h1, h2, hag.2.2 var idx, exprFactor]
      have hef := exprFactor_pos idxE
      set v := wsSub.read (.localFrame fd var idx)
      refine ⟨by simp, unit_bound_unary (by norm_num) hef hu₀, ?_⟩
      refine le_trans ?_
        (sim_bound_unary (B := b₀ + natBitLength var + intBitLength idx + intBitLength v)
          (extra := natBitLength var + intBitLength idx + intBitLength v)
          (by norm_num) hef hL1 (by omega) (by omega) hb₀
          (linear_le_three_sq hL9 (by omega)))
      omega
  | extraRatNum idxE ih =>
      intro htm
      obtain ⟨_, _, _, hc⟩ := hstage
      have hef := exprFactor_pos idxE
      cases isDimD with
      | true =>
          dsimp at hc
          rcases h1 : evalIntExpr inpSub fd wsSub idxE with ⟨idx, u₀, b₀⟩
          have hb_pos := evalIntExpr_bitLen_le inpSub fd wsSub idxE; rw [h1] at hb_pos
          simp only [↓reduceIte, trExpr, evalIntExpr, h1, hc.2.1, listGetIntD]
          have hq0 : (if 0 ≤ idx then ([] : List ℚ).getD idx.toNat 0 else 0) = 0 := by
            split_ifs <;> simp
          rw [hq0]
          have hi0 : intBitLength 0 = 1 := rfl
          simp only [Rat.num_zero, hi0, exprFactor]
          refine ⟨by simp, ?_, ?_⟩
          · calc 1 ≤ 64 * 1 * 1 := by norm_num
              _ ≤ (64 * exprFactor idxE) * (u₀ + 1) :=
                Nat.mul_le_mul (Nat.mul_le_mul_left 64 hef) (by omega)
          · calc 1 ≤ (64 * 1) * 1 * 1 := by norm_num
              _ ≤ (64 * exprFactor idxE) * ((L_p + natBitLength T_max + 8) ^ 2) *
                    ((b₀ + intBitLength idx + 1) ^ 2) :=
                Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul_left 64 hef)
                  (Nat.one_le_pow 2 _ hL1)) (Nat.one_le_pow 2 _ (by omega))
      | false =>
          dsimp at hc
          have hrec := ih htm
          have hbl := evalIntExpr_bitLen_le inpSub fd wsSub idxE
          rcases h1 : evalIntExpr inpSub fd wsSub idxE with ⟨idx, u₀, b₀⟩
          rcases h2 : evalIntExpr inpSim (2 + fd) wsSim (trExpr false T_max idxE) with ⟨idx', u'₀, b'₀⟩
          simp only [h1, h2] at hrec; simp only [h1] at hbl
          rcases hrec with ⟨heq, hu₀, hb₀⟩; subst idx'
          have hn6 : natBitLength 6 = 3 := by decide
          simp only [Bool.false_eq_true, ↓reduceIte, trExpr, evalIntExpr, h1, h2,
            hag.1 6 idx (by omega), hc.2.2.2.1 idx, exprFactor, hn6]
          set v := (listGetIntD inpSub.extraRats idx 0).num
          refine ⟨by simp, unit_bound_unary (by norm_num) hef hu₀, ?_⟩
          refine le_trans ?_
            (sim_bound_unary (B := b₀ + intBitLength idx + intBitLength v)
              (extra := 3 + intBitLength idx + intBitLength v)
              (by norm_num) hef hL1 (by omega) (by omega) hb₀
              (linear_le_three_sq hL9 (by omega)))
          omega
  | extraRatDen idxE ih =>
      intro htm
      obtain ⟨_, _, _, hc⟩ := hstage
      have hef := exprFactor_pos idxE
      cases isDimD with
      | true =>
          dsimp at hc
          rcases h1 : evalIntExpr inpSub fd wsSub idxE with ⟨idx, u₀, b₀⟩
          have hb_pos := evalIntExpr_bitLen_le inpSub fd wsSub idxE; rw [h1] at hb_pos
          simp only [↓reduceIte, trExpr, evalIntExpr, h1, hc.2.1, listGetIntD]
          have hq0 : (if 0 ≤ idx then ([] : List ℚ).getD idx.toNat 0 else 0) = 0 := by
            split_ifs <;> simp
          rw [hq0]
          have hi1 : intBitLength 1 = 2 := by decide
          simp only [Rat.den_zero, Nat.cast_one, hi1, exprFactor]
          refine ⟨by simp, ?_, ?_⟩
          · calc 1 ≤ 64 * 1 * 1 := by norm_num
              _ ≤ (64 * exprFactor idxE) * (u₀ + 1) :=
                Nat.mul_le_mul (Nat.mul_le_mul_left 64 hef) (by omega)
          · calc 2 ≤ (64 * 1) * 1 * 1 := by norm_num
              _ ≤ (64 * exprFactor idxE) * ((L_p + natBitLength T_max + 8) ^ 2) *
                    ((b₀ + intBitLength idx + 2) ^ 2) :=
                Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul_left 64 hef)
                  (Nat.one_le_pow 2 _ hL1)) (Nat.one_le_pow 2 _ (by omega))
      | false =>
          dsimp at hc
          have hrec := ih htm
          have hbl := evalIntExpr_bitLen_le inpSub fd wsSub idxE
          rcases h1 : evalIntExpr inpSub fd wsSub idxE with ⟨idx, u₀, b₀⟩
          rcases h2 : evalIntExpr inpSim (2 + fd) wsSim (trExpr false T_max idxE) with ⟨idx', u'₀, b'₀⟩
          simp only [h1, h2] at hrec; simp only [h1] at hbl
          rcases hrec with ⟨heq, hu₀, hb₀⟩; subst idx'
          let q := listGetIntD inpSub.extraRats idx 0
          have hread7 : wsSim.read (.heap 7 idx) = (q.den : ℤ) - 1 := by
            rw [hag.1 7 idx (by omega)]
            have := hc.2.2.2.2 idx
            dsimp [q]; omega
          have hn7 : natBitLength 7 = 3 := by decide
          have hi1 : intBitLength 1 = 2 := by decide
          have hv_pos : (1 : ℤ) ≤ (q.den : ℤ) := by exact_mod_cast q.pos
          have habs : ((q.den : ℤ) - 1).natAbs ≤ ((q.den : ℤ)).natAbs := by omega
          have hbl_sub := intBitLength_mono_natAbs habs
          dsimp [q] at hbl_sub hv_pos
          simp only [Bool.false_eq_true, ↓reduceIte, trExpr, evalIntExpr, h1, h2, hread7,
            exprFactor, hn7, hi1]
          rw [show ((listGetIntD inpSub.extraRats idx 0).den : ℤ) - 1 + 1 =
            ((listGetIntD inpSub.extraRats idx 0).den : ℤ) by omega]
          set vd : ℤ := ((listGetIntD inpSub.extraRats idx 0).den : ℤ)
          refine ⟨by simp, le_trans (by omega : _ ≤ u'₀ + 3) (unit_bound_unary (by norm_num) hef hu₀), ?_⟩
          refine le_trans ?_
            (sim_bound_unary (B := b₀ + intBitLength idx + intBitLength vd)
              (extra := 3 + intBitLength idx + intBitLength (vd - 1) + 2 +
                intBitLength (vd - 1) + 2)
              (by norm_num) hef hL1 (by omega) (by omega) hb₀
              (linear_le_three_sq hL9 (by omega)))
          omega
  | activeRatNum hE cE ih₁ ih₂ =>
      intro htm
      simp only [maxTableExpr, max_le_iff] at htm
      obtain ⟨_, hLp8, hd_ib, hc⟩ := hstage
      have hef1 := exprFactor_pos hE
      have hef2 := exprFactor_pos cE
      cases isDimD with
      | false =>
          dsimp at hc
          rcases h1 : evalIntExpr inpSub fd wsSub hE with ⟨h, u₁, b₁⟩
          rcases h2 : evalIntExpr inpSub fd wsSub cE with ⟨c, u₂, b₂⟩
          have hb1 := evalIntExpr_bitLen_le inpSub fd wsSub hE; rw [h1] at hb1
          have hb2 := evalIntExpr_bitLen_le inpSub fd wsSub cE; rw [h2] at hb2
          have hi0 : intBitLength 0 = 1 := rfl
          simp only [Bool.false_eq_true, ↓reduceIte, trExpr, evalIntExpr, h1, h2,
            hc.2.1, Finset.notMem_empty, and_false, ↓reduceDIte, exprFactor, hi0]
          refine ⟨by simp, ?_, ?_⟩
          · calc 1 ≤ 2048 * 1 * 1 := by norm_num
              _ ≤ (2048 * (exprFactor hE + exprFactor cE)) * (u₁ + u₂ + 1) :=
                Nat.mul_le_mul (Nat.mul_le_mul_left 2048 (by omega)) (by omega)
          · calc 1 ≤ 2048 * 1 * 1 * 1 := by norm_num
              _ ≤ 2048 * (exprFactor hE + exprFactor cE) * ((L_p + natBitLength T_max + 8) ^ 2) *
                    ((b₁ + b₂ + intBitLength h + intBitLength c + 1) ^ 2) :=
                Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul_left 2048 (by omega))
                  (Nat.one_le_pow 2 _ hL1)) (Nat.one_le_pow 2 _ (by omega))
      | true =>
          dsimp at hc
          rcases hc with ⟨hdSub, _, M, hM1, hM_ib, hAct, hM_read, _, h6_0, _, hcoords⟩
          subst hdSub
          have hr1 := ih₁ htm.1
          have hr2 := ih₂ htm.2
          have hbl1 := evalIntExpr_bitLen_le inpSub fd wsSub hE
          have hbl2 := evalIntExpr_bitLen_le inpSub fd wsSub cE
          rcases h1 : evalIntExpr inpSub fd wsSub hE with ⟨h, u₁, b₁⟩
          rcases h2 : evalIntExpr inpSub fd wsSub cE with ⟨c, u₂, b₂⟩
          rcases h1' : evalIntExpr inpSim (2 + fd) wsSim (trExpr true T_max hE) with ⟨h', u'₁, b'₁⟩
          rcases h2' : evalIntExpr inpSim (2 + fd) wsSim (trExpr true T_max cE) with ⟨c', u'₂, b'₂⟩
          simp only [h1, h1'] at hr1; simp only [h1] at hbl1
          simp only [h2, h2'] at hr2; simp only [h2] at hbl2
          rcases hr1 with ⟨heq1, hu₁, hb₁⟩; subst h'
          rcases hr2 with ⟨heq2, hu₂, hb₂⟩; subst c'
          let ME := IntExpr.readHeap 5 (.lit 2)
          let DE := IntExpr.add .dim (.lit 1)
          have hi0 : intBitLength 0 = 1 := rfl
          have hi1 : intBitLength 1 = 2 := by decide
          have hi2 : intBitLength 2 = 3 := by decide
          have hn5 : natBitLength 5 = 3 := by decide
          have hn6 : natBitLength 6 = 3 := by decide
          have hME : evalIntExpr inpSim (2 + fd) wsSim ME =
              ((M : ℤ), 2, 3 + natBitLength 5 + 3 + intBitLength (M : ℤ)) := by
            simp [ME, evalIntExpr, hag.1 5 2 (by omega), hM_read, hi2]
          have hDE : evalIntExpr inpSim (2 + fd) wsSim DE =
              ((d : ℤ) + 1, 3, intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2) := by
            simp [DE, evalIntExpr, hi1]
          obtain ⟨uR1, bR1, heR1, huR1, hbR1⟩ :=
            eval_inRangeExpr inpSim (2 + fd) wsSim h1' hME (by exact_mod_cast hM1)
          obtain ⟨uR2, bR2, heR2, huR2, hbR2⟩ :=
            eval_inRangeExpr inpSim (2 + fd) wsSim h2' hDE (by omega)
          dsimp only [ME, DE] at heR1 heR2 hDE
          simp only [↓reduceIte, trExpr, addr2DExpr, evalIntExpr, h1, h2]
          change
            let res := evalIntExpr inpSim (2 + fd) wsSim
              (.readHeap 6 (.mul (.mul (inRangeExpr (trExpr true T_max hE) (.readHeap 5 (.lit 2)))
                (inRangeExpr (trExpr true T_max cE) (.add .dim (.lit 1))))
                (.add (.add (.mul (trExpr true T_max hE) (.add .dim (.lit 1))) (trExpr true T_max cE)) (.lit 1))))
            _
          dsimp only
          simp only [evalIntExpr, heR1, heR2, h1', h2', hDE, hag.1 6 _ (by omega), hAct]
          have hD_ib : intBitLength ((d : ℤ) + 1) ≤ L_p + 3 := by
            have := intBitLength_add_le (d : ℤ) 1
            omega
          have hmul_hd := intBitLength_mul_le h ((d : ℤ) + 1)
          have hadd_hdc := intBitLength_add_le (h * ((d : ℤ) + 1)) c
          have hadd_1 := intBitLength_add_le (h * ((d : ℤ) + 1) + c) 1
          by_cases hvalid : (0 ≤ h ∧ h < (M : ℤ)) ∧ (0 ≤ c ∧ c < (d : ℤ) + 1)
          · rcases hvalid with ⟨⟨hh0, hhM⟩, ⟨hc0, hcD⟩⟩
            have hh_mem : h.toNat ∈ Finset.range M :=
              Finset.mem_range.mpr ((Int.toNat_lt hh0).mpr (by exact_mod_cast hhM))
            have hc_lt : c.toNat < d + 1 := (Int.toNat_lt hc0).mpr (by omega)
            simp only [hh0, hhM, hc0, hcD, hh_mem, hc_lt, and_self, ↓reduceIte, ↓reduceDIte, mul_one]
            have ha_eq : 1 * (h * ((d : ℤ) + 1) + c + 1) =
                ((h.toNat * (d + 1) + c.toNat + 1 : ℕ) : ℤ) := by
              push_cast
              rw [Int.toNat_of_nonneg hh0, Int.toNat_of_nonneg hc0]
              ring
            have h6_eq : wsBase.read (.heap 6 ((h.toNat * (d + 1) + c.toNat + 1 : ℕ) : ℤ)) =
                (inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).num :=
              (hcoords h.toNat (Finset.mem_range.mp hh_mem) ⟨c.toNat, hc_lt⟩).1
            rw [ha_eq, h6_eq]
            refine ⟨by simp, ?_, ?_⟩
            · simp only [exprFactor]
              refine le_trans (by omega : _ ≤ 3 * u'₁ + 3 * u'₂ + 40)
                (unit_bound_binary (by norm_num) hef1 hef2 (by omega) (by omega) (by omega) hu₁ hu₂)
            · simp only [exprFactor]
              rw [← ha_eq]
              refine le_trans ?_
                (sim_bound_binary (M := 2048) (k := 3) (C := 100)
                  (B := b₁ + b₂ + intBitLength h + intBitLength c +
                    intBitLength ((inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).num))
                  (by norm_num) hef1 hef2 hL1 (by omega) (by omega) (by omega) hb₁ hb₂
                  (extra := 2 * (3 + natBitLength 5 + 3 + intBitLength (M : ℤ)) +
                    2 * intBitLength h * intBitLength (M : ℤ) + (intBitLength h + 5) ^ 2 + 16 +
                    (2 * (intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2) +
                      2 * intBitLength c * intBitLength ((d : ℤ) + 1) + (intBitLength c + 5) ^ 2 + 16) +
                    4 + (intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2) +
                    intBitLength h * intBitLength ((d : ℤ) + 1) +
                    intBitLength (h * ((d : ℤ) + 1)) + intBitLength c + 4 +
                    intBitLength (h * ((d : ℤ) + 1) + c) +
                    3 * intBitLength (1 * (h * ((d : ℤ) + 1) + c + 1)) + 3 +
                    intBitLength ((inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).num)) ?_)
              · have hm1 : 1 * (h * ((d : ℤ) + 1) + c + 1) = h * ((d : ℤ) + 1) + c + 1 := one_mul _
                rw [hm1, hi1, hn6]
                omega
              · have hm1 : 1 * (h * ((d : ℤ) + 1) + c + 1) = h * ((d : ℤ) + 1) + c + 1 := one_mul _
                rw [hm1, hn5]
                have h_ex := activeRat_extra_le (L := L_p + natBitLength T_max + 8)
                  (B := b₁ + b₂ + intBitLength h + intBitLength c +
                    intBitLength ((inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).num))
                  (ih := intBitLength h) (ic := intBitLength c) (iM := intBitLength (M : ℤ))
                  (id0 := intBitLength (d : ℤ)) (id1 := intBitLength ((d : ℤ) + 1))
                  (ihd := intBitLength (h * ((d : ℤ) + 1)))
                  (ihdc := intBitLength (h * ((d : ℤ) + 1) + c))
                  (ihdc1 := intBitLength (h * ((d : ℤ) + 1) + c + 1))
                  (iv := intBitLength ((inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).num))
                  (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
                  hmul_hd hadd_hdc (by rw [hi1] at hadd_1; omega) (by omega)
                (try dsimp [L]); omega
          · have hmul0 :
                (if 0 ≤ h ∧ h < (M : ℤ) then (1 : ℤ) else 0) *
                (if 0 ≤ c ∧ c < (d : ℤ) + 1 then (1 : ℤ) else 0) = 0 := by
              by_cases hA : 0 ≤ h ∧ h < (M : ℤ)
              · have hB : ¬ (0 ≤ c ∧ c < (d : ℤ) + 1) := fun hb => hvalid ⟨hA, hb⟩
                rw [if_pos hA, if_neg hB, mul_zero]
              · rw [if_neg hA, zero_mul]
            have hsub_zero :
                (if _ : 0 ≤ h ∧ h.toNat ∈ Finset.range M then
                  if hc' : 0 ≤ c ∧ c.toNat < d + 1 then
                    (inpSub.activeRatCoords h.toNat ⟨c.toNat, hc'.2⟩).num
                  else 0
                else 0) = 0 := by
              split_ifs with hh' hc'
              · exfalso; apply hvalid
                exact ⟨⟨hh'.1, by
                  have := Finset.mem_range.mp hh'.2
                  have hcast : ((h.toNat : ℕ) : ℤ) = h := Int.toNat_of_nonneg hh'.1
                  omega⟩, ⟨hc'.1, by
                  have hcast : ((c.toNat : ℕ) : ℤ) = c := Int.toNat_of_nonneg hc'.1
                  omega⟩⟩
              · rfl
              · rfl
            rw [hsub_zero]
            simp only [hmul0, zero_mul, h6_0]
            refine ⟨by simp, ?_, ?_⟩
            · simp only [exprFactor]
              refine le_trans (by omega : _ ≤ 3 * u'₁ + 3 * u'₂ + 40)
                (unit_bound_binary (by norm_num) hef1 hef2 (by omega) (by omega) (by omega) hu₁ hu₂)
            · simp only [exprFactor]
              have hb1_ib : intBitLength (if 0 ≤ h ∧ h < (M : ℤ) then (1 : ℤ) else 0) ≤ 2 := by
                split_ifs <;> decide
              have hb2_ib : intBitLength (if 0 ≤ c ∧ c < (d : ℤ) + 1 then (1 : ℤ) else 0) ≤ 2 := by
                split_ifs <;> decide
              refine le_trans ?_
                (sim_bound_binary (M := 2048) (k := 3) (C := 100)
                  (B := b₁ + b₂ + intBitLength h + intBitLength c + 1)
                  (by norm_num) hef1 hef2 hL1 (by omega) (by omega) (by omega) hb₁ hb₂
                  (extra := 2 * (3 + natBitLength 5 + 3 + intBitLength (M : ℤ)) +
                    2 * intBitLength h * intBitLength (M : ℤ) + (intBitLength h + 5) ^ 2 + 16 +
                    (2 * (intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2) +
                      2 * intBitLength c * intBitLength ((d : ℤ) + 1) + (intBitLength c + 5) ^ 2 + 16) +
                    4 + (intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2) +
                    intBitLength h * intBitLength ((d : ℤ) + 1) +
                    intBitLength (h * ((d : ℤ) + 1)) + intBitLength c + 4 +
                    intBitLength (h * ((d : ℤ) + 1) + c) +
                    intBitLength (h * ((d : ℤ) + 1) + c + 1) + 16) ?_)
              · have := Nat.mul_le_mul hb1_ib hb2_ib; rw [hi0, hi1, hn6]; omega
              · rw [hn5]
                have h_ex := activeRat_extra_le (L := L_p + natBitLength T_max + 8)
                  (B := b₁ + b₂ + intBitLength h + intBitLength c + 1)
                  (ih := intBitLength h) (ic := intBitLength c) (iM := intBitLength (M : ℤ))
                  (id0 := intBitLength (d : ℤ)) (id1 := intBitLength ((d : ℤ) + 1))
                  (ihd := intBitLength (h * ((d : ℤ) + 1)))
                  (ihdc := intBitLength (h * ((d : ℤ) + 1) + c))
                  (ihdc1 := intBitLength (h * ((d : ℤ) + 1) + c + 1))
                  (iv := 0)
                  (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
                  hmul_hd hadd_hdc (by rw [hi1] at hadd_1; omega) (by omega)
                (try dsimp [L]); omega
  | activeRatDen hE cE ih₁ ih₂ =>
      intro htm
      simp only [maxTableExpr, max_le_iff] at htm
      obtain ⟨_, hLp8, hd_ib, hc⟩ := hstage
      have hef1 := exprFactor_pos hE
      have hef2 := exprFactor_pos cE
      cases isDimD with
      | false =>
          dsimp at hc
          rcases h1 : evalIntExpr inpSub fd wsSub hE with ⟨h, u₁, b₁⟩
          rcases h2 : evalIntExpr inpSub fd wsSub cE with ⟨c, u₂, b₂⟩
          have hb1 := evalIntExpr_bitLen_le inpSub fd wsSub hE; rw [h1] at hb1
          have hb2 := evalIntExpr_bitLen_le inpSub fd wsSub cE; rw [h2] at hb2
          have hi1 : intBitLength 1 = 2 := by decide
          simp only [Bool.false_eq_true, ↓reduceIte, trExpr, evalIntExpr, h1, h2,
            hc.2.1, Finset.notMem_empty, and_false, ↓reduceDIte, exprFactor, hi1]
          refine ⟨by simp, ?_, ?_⟩
          · calc 1 ≤ 2048 * 1 * 1 := by norm_num
              _ ≤ (2048 * (exprFactor hE + exprFactor cE)) * (u₁ + u₂ + 1) :=
                Nat.mul_le_mul (Nat.mul_le_mul_left 2048 (by omega)) (by omega)
          · calc 2 ≤ 2048 * 1 * 1 * 1 := by norm_num
              _ ≤ 2048 * (exprFactor hE + exprFactor cE) * ((L_p + natBitLength T_max + 8) ^ 2) *
                    ((b₁ + b₂ + intBitLength h + intBitLength c + 2) ^ 2) :=
                Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul_left 2048 (by omega))
                  (Nat.one_le_pow 2 _ hL1)) (Nat.one_le_pow 2 _ (by omega))
      | true =>
          dsimp at hc
          rcases hc with ⟨hdSub, _, M, hM1, hM_ib, hAct, hM_read, _, _, h7_0, hcoords⟩
          subst hdSub
          have hr1 := ih₁ htm.1
          have hr2 := ih₂ htm.2
          have hbl1 := evalIntExpr_bitLen_le inpSub fd wsSub hE
          have hbl2 := evalIntExpr_bitLen_le inpSub fd wsSub cE
          rcases h1 : evalIntExpr inpSub fd wsSub hE with ⟨h, u₁, b₁⟩
          rcases h2 : evalIntExpr inpSub fd wsSub cE with ⟨c, u₂, b₂⟩
          rcases h1' : evalIntExpr inpSim (2 + fd) wsSim (trExpr true T_max hE) with ⟨h', u'₁, b'₁⟩
          rcases h2' : evalIntExpr inpSim (2 + fd) wsSim (trExpr true T_max cE) with ⟨c', u'₂, b'₂⟩
          simp only [h1, h1'] at hr1; simp only [h1] at hbl1
          simp only [h2, h2'] at hr2; simp only [h2] at hbl2
          rcases hr1 with ⟨heq1, hu₁, hb₁⟩; subst h'
          rcases hr2 with ⟨heq2, hu₂, hb₂⟩; subst c'
          let ME := IntExpr.readHeap 5 (.lit 2)
          let DE := IntExpr.add .dim (.lit 1)
          have hi0 : intBitLength 0 = 1 := rfl
          have hi1 : intBitLength 1 = 2 := by decide
          have hi2 : intBitLength 2 = 3 := by decide
          have hn5 : natBitLength 5 = 3 := by decide
          have hn7 : natBitLength 7 = 3 := by decide
          have hME : evalIntExpr inpSim (2 + fd) wsSim ME =
              ((M : ℤ), 2, 3 + natBitLength 5 + 3 + intBitLength (M : ℤ)) := by
            simp [ME, evalIntExpr, hag.1 5 2 (by omega), hM_read, hi2]
          have hDE : evalIntExpr inpSim (2 + fd) wsSim DE =
              ((d : ℤ) + 1, 3, intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2) := by
            simp [DE, evalIntExpr, hi1]
          obtain ⟨uR1, bR1, heR1, huR1, hbR1⟩ :=
            eval_inRangeExpr inpSim (2 + fd) wsSim h1' hME (by exact_mod_cast hM1)
          obtain ⟨uR2, bR2, heR2, huR2, hbR2⟩ :=
            eval_inRangeExpr inpSim (2 + fd) wsSim h2' hDE (by omega)
          dsimp only [ME, DE] at heR1 heR2 hDE
          simp only [↓reduceIte, trExpr, addr2DExpr, evalIntExpr, h1, h2]
          change
            let res := evalIntExpr inpSim (2 + fd) wsSim
              (.add (.readHeap 7 (.mul (.mul (inRangeExpr (trExpr true T_max hE) (.readHeap 5 (.lit 2)))
                (inRangeExpr (trExpr true T_max cE) (.add .dim (.lit 1))))
                (.add (.add (.mul (trExpr true T_max hE) (.add .dim (.lit 1))) (trExpr true T_max cE)) (.lit 1)))) (.lit 1))
            _
          dsimp only
          simp only [evalIntExpr, heR1, heR2, h1', h2', hDE, hag.1 7 _ (by omega), hAct]
          have hD_ib : intBitLength ((d : ℤ) + 1) ≤ L_p + 3 := by
            have := intBitLength_add_le (d : ℤ) 1
            omega
          have hmul_hd := intBitLength_mul_le h ((d : ℤ) + 1)
          have hadd_hdc := intBitLength_add_le (h * ((d : ℤ) + 1)) c
          have hadd_1 := intBitLength_add_le (h * ((d : ℤ) + 1) + c) 1
          by_cases hvalid : (0 ≤ h ∧ h < (M : ℤ)) ∧ (0 ≤ c ∧ c < (d : ℤ) + 1)
          · rcases hvalid with ⟨⟨hh0, hhM⟩, ⟨hc0, hcD⟩⟩
            have hh_mem : h.toNat ∈ Finset.range M :=
              Finset.mem_range.mpr ((Int.toNat_lt hh0).mpr (by exact_mod_cast hhM))
            have hc_lt : c.toNat < d + 1 := (Int.toNat_lt hc0).mpr (by omega)
            simp only [hh0, hhM, hc0, hcD, hh_mem, hc_lt, and_self, ↓reduceIte, ↓reduceDIte, mul_one]
            have ha_eq : 1 * (h * ((d : ℤ) + 1) + c + 1) =
                ((h.toNat * (d + 1) + c.toNat + 1 : ℕ) : ℤ) := by
              push_cast
              rw [Int.toNat_of_nonneg hh0, Int.toNat_of_nonneg hc0]
              ring
            let denZ : ℤ := ((inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).den : ℤ)
            have hden_pos : 1 ≤ denZ := by
              dsimp [denZ]; exact_mod_cast (inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).pos
            have h7_eq : wsBase.read (.heap 7 ((h.toNat * (d + 1) + c.toNat + 1 : ℕ) : ℤ)) = denZ - 1 := by
              have := (hcoords h.toNat (Finset.mem_range.mp hh_mem) ⟨c.toNat, hc_lt⟩).2
              dsimp [denZ] at *; omega
            rw [ha_eq, h7_eq]
            have hden_add : denZ - 1 + 1 = denZ := by omega
            have habs_sub : (denZ - 1).natAbs ≤ denZ.natAbs := by omega
            have hbl_sub := intBitLength_mono_natAbs habs_sub
            rw [hden_add]
            refine ⟨by dsimp [denZ], ?_, ?_⟩
            · simp only [exprFactor]
              refine le_trans (by omega : _ ≤ 3 * u'₁ + 3 * u'₂ + 40)
                (unit_bound_binary (by norm_num) hef1 hef2 (by omega) (by omega) (by omega) hu₁ hu₂)
            · simp only [exprFactor]
              rw [← ha_eq]
              dsimp [denZ] at hbl_sub ⊢
              refine le_trans ?_
                (sim_bound_binary (M := 2048) (k := 3) (C := 100)
                  (B := b₁ + b₂ + intBitLength h + intBitLength c +
                    intBitLength ((inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).den : ℤ))
                  (by norm_num) hef1 hef2 hL1 (by omega) (by omega) (by omega) hb₁ hb₂
                  (extra := 2 * (3 + natBitLength 5 + 3 + intBitLength (M : ℤ)) +
                    2 * intBitLength h * intBitLength (M : ℤ) + (intBitLength h + 5) ^ 2 + 16 +
                    (2 * (intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2) +
                      2 * intBitLength c * intBitLength ((d : ℤ) + 1) + (intBitLength c + 5) ^ 2 + 16) +
                    4 + (intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2) +
                    intBitLength h * intBitLength ((d : ℤ) + 1) +
                    intBitLength (h * ((d : ℤ) + 1)) + intBitLength c + 4 +
                    intBitLength (h * ((d : ℤ) + 1) + c) +
                    3 * intBitLength (1 * (h * ((d : ℤ) + 1) + c + 1)) + 16 +
                    2 * intBitLength ((inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).den : ℤ)) ?_)
              · have hm1 : 1 * (h * ((d : ℤ) + 1) + c + 1) = h * ((d : ℤ) + 1) + c + 1 := one_mul _
                rw [hm1, hi1, hn7]
                omega
              · have hm1 : 1 * (h * ((d : ℤ) + 1) + c + 1) = h * ((d : ℤ) + 1) + c + 1 := one_mul _
                rw [hm1, hn5]
                have h_ex := activeRat_extra_le (L := L_p + natBitLength T_max + 8)
                  (B := b₁ + b₂ + intBitLength h + intBitLength c +
                    intBitLength ((inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).den : ℤ))
                  (ih := intBitLength h) (ic := intBitLength c) (iM := intBitLength (M : ℤ))
                  (id0 := intBitLength (d : ℤ)) (id1 := intBitLength ((d : ℤ) + 1))
                  (ihd := intBitLength (h * ((d : ℤ) + 1)))
                  (ihdc := intBitLength (h * ((d : ℤ) + 1) + c))
                  (ihdc1 := intBitLength (h * ((d : ℤ) + 1) + c + 1))
                  (iv := intBitLength ((inpSub.activeRatCoords h.toNat ⟨c.toNat, hc_lt⟩).den : ℤ))
                  (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
                  hmul_hd hadd_hdc (by rw [hi1] at hadd_1; omega) (by omega)
                (try dsimp [L]); omega
          · have hmul0 :
                (if 0 ≤ h ∧ h < (M : ℤ) then (1 : ℤ) else 0) *
                (if 0 ≤ c ∧ c < (d : ℤ) + 1 then (1 : ℤ) else 0) = 0 := by
              by_cases hA : 0 ≤ h ∧ h < (M : ℤ)
              · have hB : ¬ (0 ≤ c ∧ c < (d : ℤ) + 1) := fun hb => hvalid ⟨hA, hb⟩
                rw [if_pos hA, if_neg hB, mul_zero]
              · rw [if_neg hA, zero_mul]
            have hsub_one :
                (if _ : 0 ≤ h ∧ h.toNat ∈ Finset.range M then
                  if hc' : 0 ≤ c ∧ c.toNat < d + 1 then
                    ((inpSub.activeRatCoords h.toNat ⟨c.toNat, hc'.2⟩).den : ℤ)
                  else 1
                else 1) = 1 := by
              split_ifs with hh' hc'
              · exfalso; apply hvalid
                exact ⟨⟨hh'.1, by
                  have := Finset.mem_range.mp hh'.2
                  have hcast : ((h.toNat : ℕ) : ℤ) = h := Int.toNat_of_nonneg hh'.1
                  omega⟩, ⟨hc'.1, by
                  have hcast : ((c.toNat : ℕ) : ℤ) = c := Int.toNat_of_nonneg hc'.1
                  omega⟩⟩
              · rfl
              · rfl
            rw [hsub_one]
            simp only [hmul0, zero_mul, h7_0, zero_add]
            refine ⟨by simp, ?_, ?_⟩
            · simp only [exprFactor]
              refine le_trans (by omega : _ ≤ 3 * u'₁ + 3 * u'₂ + 40)
                (unit_bound_binary (by norm_num) hef1 hef2 (by omega) (by omega) (by omega) hu₁ hu₂)
            · simp only [exprFactor]
              have hb1_ib : intBitLength (if 0 ≤ h ∧ h < (M : ℤ) then (1 : ℤ) else 0) ≤ 2 := by
                split_ifs <;> decide
              have hb2_ib : intBitLength (if 0 ≤ c ∧ c < (d : ℤ) + 1 then (1 : ℤ) else 0) ≤ 2 := by
                split_ifs <;> decide
              refine le_trans ?_
                (sim_bound_binary (M := 2048) (k := 3) (C := 100)
                  (B := b₁ + b₂ + intBitLength h + intBitLength c + 2)
                  (by norm_num) hef1 hef2 hL1 (by omega) (by omega) (by omega) hb₁ hb₂
                  (extra := 2 * (3 + natBitLength 5 + 3 + intBitLength (M : ℤ)) +
                    2 * intBitLength h * intBitLength (M : ℤ) + (intBitLength h + 5) ^ 2 + 16 +
                    (2 * (intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2) +
                      2 * intBitLength c * intBitLength ((d : ℤ) + 1) + (intBitLength c + 5) ^ 2 + 16) +
                    4 + (intBitLength (d : ℤ) + 2 + intBitLength (d : ℤ) + 2) +
                    intBitLength h * intBitLength ((d : ℤ) + 1) +
                    intBitLength (h * ((d : ℤ) + 1)) + intBitLength c + 4 +
                    intBitLength (h * ((d : ℤ) + 1) + c) +
                    intBitLength (h * ((d : ℤ) + 1) + c + 1) + 24) ?_)
              · have := Nat.mul_le_mul hb1_ib hb2_ib; rw [hi0, hi1, hn7]; omega
              · rw [hn5]
                have h_ex := activeRat_extra_le (L := L_p + natBitLength T_max + 8)
                  (B := b₁ + b₂ + intBitLength h + intBitLength c + 2)
                  (ih := intBitLength h) (ic := intBitLength c) (iM := intBitLength (M : ℤ))
                  (id0 := intBitLength (d : ℤ)) (id1 := intBitLength ((d : ℤ) + 1))
                  (ihd := intBitLength (h * ((d : ℤ) + 1)))
                  (ihdc := intBitLength (h * ((d : ℤ) + 1) + c))
                  (ihdc1 := intBitLength (h * ((d : ℤ) + 1) + c + 1))
                  (iv := 0)
                  (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
                  hmul_hd hadd_hdc (by rw [hi1] at hadd_1; omega) (by omega)
                (try dsimp [L]); omega
  | neg e ih =>
      intro htm
      have hrec := ih htm
      have hbl := evalIntExpr_bitLen_le inpSub fd wsSub e
      rcases h1 : evalIntExpr inpSub fd wsSub e with ⟨v, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max e) with ⟨v', u'₀, b'₀⟩
      simp only [h1, h2] at hrec; simp only [h1] at hbl
      rcases hrec with ⟨heq, hu₀, hb₀⟩; subst v'
      dsimp only [trExpr, evalIntExpr, exprFactor]
      rw [h1, h2]; dsimp only
      have hef := exprFactor_pos e
      refine ⟨rfl, unit_bound_unary (by norm_num) hef hu₀, ?_⟩
      exact sim_bound_unary (by norm_num) hef hL1 (by omega) (by omega) hb₀
        (linear_le_three_sq hL9 (by omega))
  | add e₁ e₂ ih₁ ih₂ | sub e₁ e₂ ih₁ ih₂ =>
      intro htm
      simp only [maxTableExpr, max_le_iff] at htm
      have hr1 := ih₁ htm.1; have hr2 := ih₂ htm.2
      have hbl1 := evalIntExpr_bitLen_le inpSub fd wsSub e₁
      have hbl2 := evalIntExpr_bitLen_le inpSub fd wsSub e₂
      rcases h1 : evalIntExpr inpSub fd wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSub fd wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h1' : evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h2' : evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h1'] at hr1; simp only [h1] at hbl1
      simp only [h2, h2'] at hr2; simp only [h2] at hbl2
      rcases hr1 with ⟨heq1, hu₁, hb₁⟩; subst v'₁; rcases hr2 with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      dsimp only [trExpr, evalIntExpr, exprFactor]
      rw [h1, h2, h1', h2']; dsimp only
      have hef1 := exprFactor_pos e₁; have hef2 := exprFactor_pos e₂
      refine ⟨rfl,
        le_trans (by omega : _ ≤ 1 * u'₁ + 1 * u'₂ + 1)
          (unit_bound_binary (by norm_num) hef1 hef2 (by omega) (by omega) (by omega) hu₁ hu₂), ?_⟩
      refine le_trans ?_
        (sim_bound_binary (M := 64) (k := 1) (C := 3)
          (B := b₁ + b₂ + intBitLength v₁ + intBitLength v₂)
          (by norm_num) hef1 hef2 hL1 (by omega) (by omega) (by omega) hb₁ hb₂
          (extra := intBitLength v₁ + intBitLength v₂)
          (linear_le_three_sq hL9 (by omega)))
      omega
  | mul e₁ e₂ ih₁ ih₂ | div e₁ e₂ ih₁ ih₂ | mod e₁ e₂ ih₁ ih₂ =>
      intro htm
      simp only [maxTableExpr, max_le_iff] at htm
      have hr1 := ih₁ htm.1; have hr2 := ih₂ htm.2
      have hbl1 := evalIntExpr_bitLen_le inpSub fd wsSub e₁
      have hbl2 := evalIntExpr_bitLen_le inpSub fd wsSub e₂
      rcases h1 : evalIntExpr inpSub fd wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSub fd wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h1' : evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h2' : evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h1'] at hr1; simp only [h1] at hbl1
      simp only [h2, h2'] at hr2; simp only [h2] at hbl2
      rcases hr1 with ⟨heq1, hu₁, hb₁⟩; subst v'₁; rcases hr2 with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      dsimp only [trExpr, evalIntExpr, exprFactor]
      rw [h1, h2, h1', h2']; dsimp only
      have hef1 := exprFactor_pos e₁; have hef2 := exprFactor_pos e₂
      refine ⟨rfl,
        le_trans (by omega : _ ≤ 1 * u'₁ + 1 * u'₂ + 1)
          (unit_bound_binary (by norm_num) hef1 hef2 (by omega) (by omega) (by omega) hu₁ hu₂), ?_⟩
      refine le_trans ?_
        (sim_bound_binary (M := 64) (k := 1) (C := 3)
          (B := b₁ + b₂ + intBitLength v₁ * intBitLength v₂)
          (by norm_num) hef1 hef2 hL1 (by omega)
          (by omega) (by omega) hb₁ hb₂
          (extra := intBitLength v₁ * intBitLength v₂)
          (prod_le_three_sq (L := L) (B := b₁ + b₂ + intBitLength v₁ * intBitLength v₂)
            (by have := Nat.le_mul_of_pos_right (intBitLength v₁) (intBitLength_pos v₂); omega)
            (by have := Nat.le_mul_of_pos_left (intBitLength v₂) (intBitLength_pos v₁); omega)))
      omega

theorem evalBitCond_bitOps_pos {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore) :
    ∀ c : BitCondExpr,
      let (_, u, b) := evalBitCond inp fd ws c
      1 ≤ u ∧ 1 ≤ b
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => by
      rcases h1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
      simp only [evalBitCond, h1, h2]
      have := intBitLength_pos v₁
      exact ⟨by omega, by omega⟩
  | .not c => by
      rcases h1 : evalBitCond inp fd ws c with ⟨_, u, b⟩
      simp only [evalBitCond, h1]
      exact ⟨by omega, by omega⟩
  | .and c₁ c₂ | .or c₁ c₂ => by
      rcases h1 : evalBitCond inp fd ws c₁ with ⟨_, u₁, b₁⟩
      rcases h2 : evalBitCond inp fd ws c₂ with ⟨_, u₂, b₂⟩
      simp only [evalBitCond, h1, h2]
      exact ⟨by omega, by omega⟩

theorem evalBitCond_trCond {isDimD : Bool} {d dSub T_max L_p : ℕ}
    {inpSim : BitRAMInput d} {inpSub : BitRAMInput dSub}
    {wsBase wsSub wsSim : WordStore} {fd : ℕ}
    (hstage : SimStageMatches isDimD d dSub L_p wsBase inpSub)
    (hag : AgreesForExpr wsBase T_max wsSub fd wsSim) :
    ∀ (c : BitCondExpr),
      maxTableCond c ≤ T_max →
      let (res, u, b) := evalBitCond inpSub fd wsSub c
      let (res', u', b') := evalBitCond inpSim (2 + fd) wsSim (trCond isDimD T_max c)
      res' = res ∧
      u' ≤ condFactor c * u ∧
      b' ≤ condFactor c * (L_p + natBitLength T_max + 8) ^ 2 * (b ^ 2) := by
  have hLp8_top : 8 ≤ L_p := hstage.2.1
  have hT1_top : 1 ≤ natBitLength T_max := natBitLength_pos T_max
  let L : ℕ := L_p + natBitLength T_max + 8
  have hL9 : 9 ≤ L := by dsimp [L]; omega
  have hL1 : 1 ≤ L := by omega
  intro c
  induction c with
  | intEq e₁ e₂ | intLt e₁ e₂ | intLe e₁ e₂ =>
      intro htm
      simp only [maxTableCond, max_le_iff] at htm
      have hr1 := evalIntExpr_trExpr (inpSim := inpSim) hstage hag e₁ htm.1
      have hr2 := evalIntExpr_trExpr (inpSim := inpSim) hstage hag e₂ htm.2
      have hbl1 := evalIntExpr_bitLen_le inpSub fd wsSub e₁
      have hbl2 := evalIntExpr_bitLen_le inpSub fd wsSub e₂
      rcases h1 : evalIntExpr inpSub fd wsSub e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSub fd wsSub e₂ with ⟨v₂, u₂, b₂⟩
      rcases h1' : evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max e₁) with ⟨v'₁, u'₁, b'₁⟩
      rcases h2' : evalIntExpr inpSim (2 + fd) wsSim (trExpr isDimD T_max e₂) with ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h1'] at hr1; simp only [h1] at hbl1
      simp only [h2, h2'] at hr2; simp only [h2] at hbl2
      rcases hr1 with ⟨heq1, hu₁, hb₁⟩; subst v'₁; rcases hr2 with ⟨heq2, hu₂, hb₂⟩; subst v'₂
      dsimp only [trCond, evalBitCond, condFactor]
      rw [h1, h2, h1', h2']; dsimp only
      have hef1 := exprFactor_pos e₁; have hef2 := exprFactor_pos e₂
      refine ⟨rfl,
        le_trans (by omega : _ ≤ 1 * u'₁ + 1 * u'₂ + 1)
          (unit_bound_binary (by norm_num) hef1 hef2 (by omega) (by omega) (by omega) hu₁ hu₂), ?_⟩
      refine le_trans ?_
        (sim_bound_binary (M := 16) (k := 1) (C := 3)
          (B := b₁ + b₂ + intBitLength v₁ + intBitLength v₂)
          (by norm_num) hef1 hef2 hL1 (by omega) (by omega) (by omega) hb₁ hb₂
          (extra := intBitLength v₁ + intBitLength v₂)
          (linear_le_three_sq hL9 (by omega)))
      omega
  | not c ih =>
      intro htm
      have hr := ih htm
      have hbp := evalBitCond_bitOps_pos inpSub fd wsSub c
      rcases h1 : evalBitCond inpSub fd wsSub c with ⟨r, u, b⟩
      rcases h1' : evalBitCond inpSim (2 + fd) wsSim (trCond isDimD T_max c) with ⟨r', u', b'⟩
      simp only [h1, h1'] at hr; simp only [h1] at hbp
      rcases hr with ⟨heq, hu, hb⟩; subst r'
      dsimp only [trCond, evalBitCond, condFactor]
      rw [h1, h1']; dsimp only
      have hcf := condFactor_pos c
      refine ⟨rfl, unit_bound_unary (by norm_num) hcf hu, ?_⟩
      exact sim_bound_unary (by norm_num) hcf hL1 (by omega) (by omega) hb
        (linear_le_three_sq hL9 (by omega))
  | and c₁ c₂ ih₁ ih₂ | or c₁ c₂ ih₁ ih₂ =>
      intro htm
      simp only [maxTableCond, max_le_iff] at htm
      have hr1 := ih₁ htm.1; have hr2 := ih₂ htm.2
      have hbp1 := evalBitCond_bitOps_pos inpSub fd wsSub c₁
      have hbp2 := evalBitCond_bitOps_pos inpSub fd wsSub c₂
      rcases h1 : evalBitCond inpSub fd wsSub c₁ with ⟨r₁, u₁, b₁⟩
      rcases h2 : evalBitCond inpSub fd wsSub c₂ with ⟨r₂, u₂, b₂⟩
      rcases h1' : evalBitCond inpSim (2 + fd) wsSim (trCond isDimD T_max c₁) with ⟨r'₁, u'₁, b'₁⟩
      rcases h2' : evalBitCond inpSim (2 + fd) wsSim (trCond isDimD T_max c₂) with ⟨r'₂, u'₂, b'₂⟩
      simp only [h1, h1'] at hr1; simp only [h1] at hbp1
      simp only [h2, h2'] at hr2; simp only [h2] at hbp2
      rcases hr1 with ⟨heq1, hu₁, hb₁⟩; subst r'₁; rcases hr2 with ⟨heq2, hu₂, hb₂⟩; subst r'₂
      dsimp only [trCond, evalBitCond, condFactor]
      rw [h1, h2, h1', h2']; dsimp only
      have hcf1 := condFactor_pos c₁; have hcf2 := condFactor_pos c₂
      refine ⟨rfl,
        le_trans (by omega : _ ≤ 1 * u'₁ + 1 * u'₂ + 1)
          (unit_bound_binary (by norm_num) hcf1 hcf2 (by omega) (by omega) (by omega) hu₁ hu₂), ?_⟩
      refine le_trans ?_
        (sim_bound_binary (M := 16) (k := 1) (C := 3)
          (B := b₁ + b₂ + 1)
          (by norm_num) hcf1 hcf2 hL1 (by omega) (by omega) (by omega) hb₁ hb₂
          (extra := 1)
          (linear_le_three_sq hL9 (by omega)))
      omega

end UL.Proof_lem_A_2
