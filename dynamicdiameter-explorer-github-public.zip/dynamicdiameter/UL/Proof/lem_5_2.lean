import UL.Stmt.lem_5_2
set_option autoImplicit false

namespace UL

namespace Proof_lem_5_2

private lemma baselinePairLength_nonneg {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (pair : Option (ι × ι)) :
    0 ≤ baselinePairLength pts pair := by
  cases pair with
  | none => simp [baselinePairLength]
  | some uv => simp [baselinePairLength]

private lemma indexedEuclideanDiam_nonneg {d : ℕ} {ι : Type*}
    (I : Finset ι) (pts : ι → EuclideanSpace ℝ (Fin d)) :
    0 ≤ indexedEuclideanDiam I pts := by
  unfold indexedEuclideanDiam
  split_ifs with hI
  · obtain ⟨x, hx⟩ := hI
    have hmem : (x, x) ∈ I ×ˢ I := Finset.mem_product.mpr ⟨hx, hx⟩
    have hle := Finset.le_sup' (fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) hmem
    simpa using hle
  · exact le_rfl

private lemma norm_sub_le_indexedEuclideanDiam {d : ℕ} {ι : Type*}
    {I : Finset ι} {pts : ι → EuclideanSpace ℝ (Fin d)} {u v : ι}
    (hu : u ∈ I) (hv : v ∈ I) :
    ‖pts u - pts v‖ ≤ indexedEuclideanDiam I pts := by
  have hI : I.Nonempty := ⟨u, hu⟩
  unfold indexedEuclideanDiam
  rw [dif_pos hI]
  have hmem : (u, v) ∈ I ×ˢ I := Finset.mem_product.mpr ⟨hu, hv⟩
  exact Finset.le_sup' (fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) hmem

private lemma activePair_length_le_diam {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {S P : Finset ι} {pair : Option (ι × ι)}
    (hsub : S ⊆ P) (hact : IsActiveNodePair S pair) :
    baselinePairLength pts pair ≤ indexedEuclideanDiam P pts := by
  cases pair with
  | none =>
    simpa [baselinePairLength] using indexedEuclideanDiam_nonneg P pts
  | some uv =>
    rcases uv with ⟨u, v⟩
    rcases hact with ⟨hu, hv⟩
    exact norm_sub_le_indexedEuclideanDiam (hsub hu) (hsub hv)

private lemma chainInput_zero {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι) :
    chainInput pts nodes P 0 = P := by
  rfl

private lemma chainInput_succ {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (i : Fin k) :
    chainInput pts nodes P i.succ =
      (nodes i).residual pts (chainInput pts nodes P i.castSucc) := by
  rfl

open Classical in
private lemma chainInput_subset {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (j : Fin (k + 1)) :
    chainInput pts nodes P j ⊆ P := by
  induction j using Fin.induction with
  | zero =>
    rw [chainInput_zero]
  | succ i ih =>
    rw [chainInput_succ]
    unfold ChainNode.residual nodeResidual
    exact Finset.sdiff_subset.trans ih

open Classical in
private lemma chain_dichotomy_aux {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    {x y : ι} (hx : x ∈ P) (hy : y ∈ P) (j : Fin (k + 1)) :
    (x ∈ chainInput pts nodes P j ∧ y ∈ chainInput pts nodes P j) ∨
      ∃ i : Fin k,
        x ∈ chainInput pts nodes P i.castSucc ∧
        y ∈ chainInput pts nodes P i.castSucc ∧
        (x ∈ chainCore pts nodes P i ∨ y ∈ chainCore pts nodes P i) := by
  induction j using Fin.induction with
  | zero =>
    left
    simpa [chainInput_zero] using ⟨hx, hy⟩
  | succ m ih =>
    rcases ih with ⟨hxm, hym⟩ | ⟨i, hi⟩
    · by_cases hcore : x ∈ chainCore pts nodes P m ∨ y ∈ chainCore pts nodes P m
      · right
        exact ⟨m, hxm, hym, hcore⟩
      · left
        push_neg at hcore
        rw [chainInput_succ]
        unfold ChainNode.residual nodeResidual
        change x ∈ chainInput pts nodes P m.castSucc \ chainCore pts nodes P m ∧
          y ∈ chainInput pts nodes P m.castSucc \ chainCore pts nodes P m
        exact ⟨Finset.mem_sdiff.mpr ⟨hxm, hcore.1⟩, Finset.mem_sdiff.mpr ⟨hym, hcore.2⟩⟩
    · right
      exact ⟨i, hi⟩

open Classical in
private lemma core_pair_div_sqrt_two_le {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {N : ChainNode d} {S : Finset ι}
    {pair : Option (ι × ι)} {u v : ι}
    (hbase : N.SatisfiesBaselineCond pts S pair)
    (huS : u ∈ S) (hvS : v ∈ S) (huC : u ∈ N.core pts S) :
    ‖pts u - pts v‖ / Real.sqrt 2 ≤ baselinePairLength pts pair := by
  have hS : S.Nonempty := ⟨u, huS⟩
  have hL_sq : (baselinePairLength pts pair) ^ 2 ≥ N.V + (nodeMaxRadius pts N.o S) ^ 2 :=
    hbase.2 hS
  have hu_ball : pts u ∈ coreBall N.o N.V := by
    unfold ChainNode.core nodeCore at huC
    exact (Finset.mem_filter.mp huC).2
  have hu_norm : ‖pts u - N.o‖ ≤ Real.sqrt N.V := by
    unfold coreBall at hu_ball
    simpa [Metric.mem_closedBall, dist_eq_norm] using hu_ball
  have hv_norm : ‖pts v - N.o‖ ≤ nodeMaxRadius pts N.o S := by
    unfold nodeMaxRadius
    rw [dif_pos hS]
    exact Finset.le_sup' (fun z => ‖pts z - N.o‖) hvS
  have htri : ‖pts u - pts v‖ ≤ ‖pts u - N.o‖ + ‖pts v - N.o‖ := by
    have hsub : pts u - pts v = (pts u - N.o) - (pts v - N.o) := by abel
    rw [hsub]
    exact norm_sub_le (pts u - N.o) (pts v - N.o)
  have hsum : ‖pts u - pts v‖ ≤ Real.sqrt N.V + nodeMaxRadius pts N.o S :=
    htri.trans (add_le_add hu_norm hv_norm)
  have hV : (Real.sqrt N.V) ^ 2 = N.V := Real.sq_sqrt N.V_nonneg
  have hsqrt2_pos : 0 < Real.sqrt 2 := Real.sqrt_pos.mpr (by norm_num)
  have hsqrt2_sq : (Real.sqrt 2) ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  have hL_nonneg : 0 ≤ baselinePairLength pts pair := baselinePairLength_nonneg pts pair
  have hR_nonneg : 0 ≤ nodeMaxRadius pts N.o S := le_trans (norm_nonneg _) hv_norm
  have hsqrtV_nonneg : 0 ≤ Real.sqrt N.V := Real.sqrt_nonneg N.V
  have hnorm_nonneg : 0 ≤ ‖pts u - pts v‖ := norm_nonneg _
  have hsq_bound : ‖pts u - pts v‖ ^ 2 ≤ (Real.sqrt 2 * baselinePairLength pts pair) ^ 2 := by
    have h1 : ‖pts u - pts v‖ ^ 2 ≤ (Real.sqrt N.V + nodeMaxRadius pts N.o S) ^ 2 := by
      nlinarith
    have h2 : (Real.sqrt N.V + nodeMaxRadius pts N.o S) ^ 2 ≤
        2 * (N.V + (nodeMaxRadius pts N.o S) ^ 2) := by
      nlinarith [sq_nonneg (Real.sqrt N.V - nodeMaxRadius pts N.o S)]
    have h3 : (Real.sqrt 2 * baselinePairLength pts pair) ^ 2 =
        2 * (baselinePairLength pts pair) ^ 2 := by
      rw [mul_pow, hsqrt2_sq]
    nlinarith
  have hle_mul : ‖pts u - pts v‖ ≤ Real.sqrt 2 * baselinePairLength pts pair := by
    have hprod_nonneg : 0 ≤ Real.sqrt 2 * baselinePairLength pts pair :=
      mul_nonneg (le_of_lt hsqrt2_pos) hL_nonneg
    nlinarith
  rw [div_le_iff₀ hsqrt2_pos]
  linarith

end Proof_lem_5_2

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_5_2 : S_lem_5_2 := by
  unfold S_lem_5_2
  intro d ι k pts P nodes basePairs leafPair h_base h_leaf_active h_leaf_diam
  let f : Fin (k + 1) → ℝ :=
    Fin.lastCases (baselinePairLength pts leafPair)
      (fun i => baselinePairLength pts (basePairs i))
  change (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty f ∈
    Set.Icc (indexedEuclideanDiam P pts / Real.sqrt 2) (indexedEuclideanDiam P pts)
  constructor
  · by_cases hP : P.Nonempty
    · have hPP : (P ×ˢ P).Nonempty := hP.product hP
      have hex : ∃ xy ∈ P ×ˢ P,
          (P ×ˢ P).sup' hPP (fun z : ι × ι => ‖pts z.1 - pts z.2‖) = ‖pts xy.1 - pts xy.2‖ :=
        Finset.exists_mem_eq_sup' hPP (fun z : ι × ι => ‖pts z.1 - pts z.2‖)
      rcases hex with ⟨⟨x, y⟩, hxy_mem, hxy_eq⟩
      rcases Finset.mem_product.mp hxy_mem with ⟨hx, hy⟩
      have hdiam_eq : indexedEuclideanDiam P pts = ‖pts x - pts y‖ := by
        unfold indexedEuclideanDiam
        rw [dif_pos hP]
        exact hxy_eq
      rcases Proof_lem_5_2.chain_dichotomy_aux pts nodes P hx hy (Fin.last k) with
        ⟨hxT, hyT⟩ | ⟨i, hxS, hyS, hcore⟩
      · have hle_term : ‖pts x - pts y‖ ≤ indexedEuclideanDiam (chainTerminal pts nodes P) pts :=
          Proof_lem_5_2.norm_sub_le_indexedEuclideanDiam hxT hyT
        have hsqrt2_pos : 0 < Real.sqrt 2 := Real.sqrt_pos.mpr (by norm_num)
        have hsqrt2_ge_one : (1 : ℝ) ≤ Real.sqrt 2 := by
          have hsq : (1 : ℝ) ^ 2 ≤ (Real.sqrt 2) ^ 2 := by
            rw [Real.sq_sqrt (by norm_num)]
            norm_num
          nlinarith [Real.sqrt_nonneg 2]
        have hdiv_le_self : indexedEuclideanDiam P pts / Real.sqrt 2 ≤ indexedEuclideanDiam P pts := by
          rw [div_le_iff₀ hsqrt2_pos]
          have hd_nonneg := Proof_lem_5_2.indexedEuclideanDiam_nonneg P pts
          nlinarith
        have hf_last : f (Fin.last k) = indexedEuclideanDiam (chainTerminal pts nodes P) pts := by
          simp [f, Fin.lastCases_last, h_leaf_diam]
        have hlast_le : f (Fin.last k) ≤
            (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty f :=
          Finset.le_sup' f (Finset.mem_univ (Fin.last k))
        linarith
      · have hfi : f i.castSucc = baselinePairLength pts (basePairs i) := by
          simp [f, Fin.lastCases_castSucc]
        have hi_le : f i.castSucc ≤
            (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty f :=
          Finset.le_sup' f (Finset.mem_univ i.castSucc)
        rcases hcore with hxC | hyC
        · have hbound := Proof_lem_5_2.core_pair_div_sqrt_two_le (h_base i) hxS hyS hxC
          rw [hdiam_eq]
          linarith
        · have hbound := Proof_lem_5_2.core_pair_div_sqrt_two_le (h_base i) hyS hxS hyC
          rw [hdiam_eq, norm_sub_rev (pts x) (pts y)]
          linarith
    · have hdiam_zero : indexedEuclideanDiam P pts = 0 := by
        unfold indexedEuclideanDiam
        rw [dif_neg hP]
      rw [hdiam_zero, zero_div]
      have hf_last_nonneg : 0 ≤ f (Fin.last k) := by
        simp only [f, Fin.lastCases_last]
        exact Proof_lem_5_2.baselinePairLength_nonneg pts leafPair
      exact hf_last_nonneg.trans (Finset.le_sup' f (Finset.mem_univ (Fin.last k)))
  · refine Finset.sup'_le Finset.univ_nonempty f ?_
    intro j _
    refine Fin.lastCases ?_ ?_ j
    · simp only [f, Fin.lastCases_last]
      exact Proof_lem_5_2.activePair_length_le_diam
        (Proof_lem_5_2.chainInput_subset pts nodes P (Fin.last k)) h_leaf_active
    · intro i
      simp only [f, Fin.lastCases_castSucc]
      exact Proof_lem_5_2.activePair_length_le_diam
        (Proof_lem_5_2.chainInput_subset pts nodes P i.castSucc) (h_base i).1

end UL
