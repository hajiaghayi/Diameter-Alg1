import UL.Stmt.clm_5_3_matching_invariant
import UL.Stmt.clm_5_2_config_gap
import UL.Proof.clm_5_3_matching_invariant.H1
set_option autoImplicit false

namespace UL

open UL.Proof_clm_5_3_matching_invariant

private theorem radialCorrelation_symm {d : ℕ} (o x y : EuclideanSpace ℝ (Fin d)) :
    radialCorrelation o x y = radialCorrelation o y x := by
  unfold radialCorrelation
  rw [inner_neg_left, inner_neg_left, real_inner_comm]

private theorem radialCorrelation_self_nonpos {d : ℕ} (o x : EuclideanSpace ℝ (Fin d)) :
    radialCorrelation o x x ≤ 0 := by
  unfold radialCorrelation
  rw [inner_neg_left, real_inner_self_eq_norm_sq]
  linarith [sq_nonneg ‖radialDirection o x‖]

open Classical in
private theorem validAttachAngular_to_edge {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (m0 : ℕ) (γ lam : ℚ) (V : ℝ) (K : ℤ) (j k ℓ : ℕ)
    {a b : ℝ}
    (hpair : ∀ (o' x y : EuclideanSpace ℝ (Fin d)),
      shellIndex m0 o' V x = j →
      shellIndex m0 o' V y = k →
      (IsStrongRoundedPair m0 γ lam o' V ℓ x y → a < radialCorrelation o' x y) ∧
      (IsWeakRoundedPair m0 lam o' V ℓ x y ↔ b < radialCorrelation o' x y))
    {S V_L V_R : Finset ι}
    (hVL : V_L ⊆ configLeftVertices pts m0 o V S j)
    (hVR : V_R ⊆ configRightVertices pts m0 o V K S k)
    {st : LocalMatchingState ι} {v : CopyVertex ι} {st' : LocalMatchingState ι}
    (hwf :
      let V_L₀ := if v.side = .left then V_L.erase v.id else V_L
      let V_R₀ := if v.side = .right then V_R.erase v.id else V_R
      st.WellFormed pts V_L₀ V_R₀)
    (hang : ValidAttachAngularStep pts o a b V_L V_R st v st') :
    ValidAttachEdgeStep pts V_L V_R
      (weakEdgesOn pts m0 lam o V ℓ V_L V_R)
      (strongEdgesOn pts m0 γ lam o V ℓ V_L V_R)
      st v st' := by
  rcases v with ⟨side, vid⟩
  rcases hang with ⟨hpre, ans, hprom, hst'⟩
  refine ⟨hpre, ans, ?_, hst'⟩
  have hshellL : ∀ x ∈ V_L, shellIndex m0 o V (pts x) = j := by
    intro x hx
    have hx' := hVL hx
    unfold configLeftVertices shellSubset at hx'
    exact (Finset.mem_filter.mp hx').2
  have hshellR : ∀ y ∈ V_R, shellIndex m0 o V (pts y) = k := by
    intro y hy
    have hy' := hVR hy
    unfold configRightVertices shellSubset at hy'
    exact (Finset.mem_filter.mp hy').2
  cases side with
  | left =>
    dsimp only at hwf
    rw [if_pos rfl, if_neg (by intro h; cases h)] at hwf
    have hrset : st.rightIndexSet = unmatchedRight V_R st.matching := hwf.2.2.2.2.2.2.1
    have hvid_VL : vid ∈ V_L := hpre.1
    cases ans with
    | some w =>
      dsimp only [SatisfiesAngularSearchPromise, LocalMatchingState.oppositeIndexSet] at hprom
      dsimp only [SatisfiesEdgeSearchPromise, LocalMatchingState.oppositeIndexSet]
      rcases hprom with ⟨hw_rset, hcorr⟩
      have hw_VR : w ∈ V_R := by
        rw [hrset] at hw_rset
        exact (Finset.mem_filter.mp hw_rset).1
      have hweak := (hpair o (pts vid) (pts w) (hshellL vid hvid_VL) (hshellR w hw_VR)).2.mpr hcorr
      exact ⟨hw_rset, Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨hvid_VL, hw_VR⟩, hweak⟩⟩
    | none =>
      dsimp only [SatisfiesAngularSearchPromise, LocalMatchingState.oppositeIndexSet] at hprom
      dsimp only [SatisfiesEdgeSearchPromise, LocalMatchingState.oppositeIndexSet]
      intro w hw_rset hstrong_mem
      have hw_VR : w ∈ V_R := by
        rw [hrset] at hw_rset
        exact (Finset.mem_filter.mp hw_rset).1
      have hstrong := (Finset.mem_filter.mp hstrong_mem).2
      have hgt := (hpair o (pts vid) (pts w) (hshellL vid hvid_VL) (hshellR w hw_VR)).1 hstrong
      have hle := hprom w hw_rset
      linarith
  | right =>
    dsimp only at hwf
    rw [if_neg (by intro h; cases h), if_pos rfl] at hwf
    have hlset : st.leftIndexSet = unmatchedLeft V_L st.matching := hwf.2.2.2.2.1
    have hvid_VR : vid ∈ V_R := hpre.1
    cases ans with
    | some w =>
      dsimp only [SatisfiesAngularSearchPromise, LocalMatchingState.oppositeIndexSet] at hprom
      dsimp only [SatisfiesEdgeSearchPromise, LocalMatchingState.oppositeIndexSet]
      rcases hprom with ⟨hw_lset, hcorr⟩
      have hw_VL : w ∈ V_L := by
        rw [hlset] at hw_lset
        exact (Finset.mem_filter.mp hw_lset).1
      rw [radialCorrelation_symm] at hcorr
      have hweak := (hpair o (pts w) (pts vid) (hshellL w hw_VL) (hshellR vid hvid_VR)).2.mpr hcorr
      exact ⟨hw_lset, Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨hw_VL, hvid_VR⟩, hweak⟩⟩
    | none =>
      dsimp only [SatisfiesAngularSearchPromise, LocalMatchingState.oppositeIndexSet] at hprom
      dsimp only [SatisfiesEdgeSearchPromise, LocalMatchingState.oppositeIndexSet]
      intro w hw_lset hstrong_mem
      have hw_VL : w ∈ V_L := by
        rw [hlset] at hw_lset
        exact (Finset.mem_filter.mp hw_lset).1
      have hstrong := (Finset.mem_filter.mp hstrong_mem).2
      have hgt := (hpair o (pts w) (pts vid) (hshellL w hw_VL) (hshellR vid hvid_VR)).1 hstrong
      have hle := hprom w hw_lset
      rw [radialCorrelation_symm] at hle
      linarith

open Classical in
private theorem attach_angular_preserves_invariant {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (m0 : ℕ) (γ lam : ℚ) (V : ℝ) (K : ℤ) (j k ℓ : ℕ)
    {a b : ℝ}
    (hpair : ∀ (o' x y : EuclideanSpace ℝ (Fin d)),
      shellIndex m0 o' V x = j →
      shellIndex m0 o' V y = k →
      (IsStrongRoundedPair m0 γ lam o' V ℓ x y → a < radialCorrelation o' x y) ∧
      (IsWeakRoundedPair m0 lam o' V ℓ x y ↔ b < radialCorrelation o' x y))
    (S V_L V_R : Finset ι)
    (st : LocalMatchingState ι) (v : CopyVertex ι) (st' : LocalMatchingState ι)
    (hVL : V_L ⊆ configLeftVertices pts m0 o V S j)
    (hVR : V_R ⊆ configRightVertices pts m0 o V K S k)
    (hinv :
      let V_L₀ := if v.side = .left then V_L.erase v.id else V_L
      let V_R₀ := if v.side = .right then V_R.erase v.id else V_R
      st.SatisfiesInvariant pts V_L₀ V_R₀
        (weakEdgesOn pts m0 lam o V ℓ V_L₀ V_R₀)
        (strongEdgesOn pts m0 γ lam o V ℓ V_L₀ V_R₀))
    (hang : ValidAttachAngularStep pts o a b V_L V_R st v st') :
    st'.SatisfiesInvariant pts V_L V_R
      (weakEdgesOn pts m0 lam o V ℓ V_L V_R)
      (strongEdgesOn pts m0 γ lam o V ℓ V_L V_R) := by
  have hedge := validAttachAngular_to_edge pts o m0 γ lam V K j k ℓ hpair hVL hVR hinv.1 hang
  exact attach_edge_preserves_invariant pts m0 γ lam o V ℓ V_L V_R st v st' hinv hedge

open Classical in
private theorem repair_angular_preserves_invariant {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (m0 : ℕ) (γ lam : ℚ) (V : ℝ) (K : ℤ) (j k ℓ : ℕ)
    {a b : ℝ}
    (hpair : ∀ (o' x y : EuclideanSpace ℝ (Fin d)),
      shellIndex m0 o' V x = j →
      shellIndex m0 o' V y = k →
      (IsStrongRoundedPair m0 γ lam o' V ℓ x y → a < radialCorrelation o' x y) ∧
      (IsWeakRoundedPair m0 lam o' V ℓ x y ↔ b < radialCorrelation o' x y))
    (S' : Finset ι) :
    let V_L' := configLeftVertices pts m0 o V S' j
    let V_R' := configRightVertices pts m0 o V K S' k
    ∀ (L : List (CopyVertex ι)) (cur st' : LocalMatchingState ι),
      L.Nodup →
      (∀ u ∈ L, isCopyActive V_L' V_R' u) →
      cur.SatisfiesInvariant pts (remLeft L V_L') (remRight L V_R')
        (weakEdgesOn pts m0 lam o V ℓ (remLeft L V_L') (remRight L V_R'))
        (strongEdgesOn pts m0 γ lam o V ℓ (remLeft L V_L') (remRight L V_R')) →
      ValidRepairAngularSteps pts o a b V_L' V_R' cur L st' →
      st'.SatisfiesInvariant pts V_L' V_R'
        (weakEdgesOn pts m0 lam o V ℓ V_L' V_R')
        (strongEdgesOn pts m0 γ lam o V ℓ V_L' V_R') := by
  dsimp only
  set V_L' := configLeftVertices pts m0 o V S' j
  set V_R' := configRightVertices pts m0 o V K S' k
  intro L
  induction L with
  | nil =>
    intro cur st' _ _ hinv hrep
    dsimp only [ValidRepairAngularSteps] at hrep
    subst hrep
    have hL : remLeft [] V_L' = V_L' := by ext x; simp [remLeft]
    have hR : remRight [] V_R' = V_R' := by ext y; simp [remRight]
    rwa [hL, hR] at hinv
  | cons u us ih =>
    intro cur st' hnd hact hinv hrep
    rw [List.nodup_cons] at hnd
    rcases hnd with ⟨hu_not_us, hnd_us⟩
    have hu_absent : ¬ (cur.isCopyMatched u ∨ cur.isCopyInIndex u) := by
      rcases hinv.1 with ⟨_, _, hedges, _, hlset, _, hrset, _⟩
      rcases u with ⟨side, uid⟩
      cases side with
      | left =>
        have huid_not : uid ∉ remLeft (⟨.left, uid⟩ :: us) V_L' := by
          simp [remLeft]
        dsimp only [LocalMatchingState.isCopyMatched, LocalMatchingState.isCopyInIndex]
        rintro (⟨e, he, hel⟩ | ⟨e, he, heid⟩)
        · subst hel
          exact huid_not (hedges e he).1
        · have hmem : uid ∈ cur.leftIndexSet := by
            simp only [LocalMatchingState.leftIndexSet, List.mem_toFinset, List.mem_map]
            exact ⟨e, he, heid⟩
          rw [hlset] at hmem
          exact huid_not (Finset.mem_filter.mp hmem).1
      | right =>
        have huid_not : uid ∉ remRight (⟨.right, uid⟩ :: us) V_R' := by
          simp [remRight]
        dsimp only [LocalMatchingState.isCopyMatched, LocalMatchingState.isCopyInIndex]
        rintro (⟨e, he, her⟩ | ⟨e, he, heid⟩)
        · subst her
          exact huid_not (hedges e he).2.1
        · have hmem : uid ∈ cur.rightIndexSet := by
            simp only [LocalMatchingState.rightIndexSet, List.mem_toFinset, List.mem_map]
            exact ⟨e, he, heid⟩
          rw [hrset] at hmem
          exact huid_not (Finset.mem_filter.mp hmem).1
    dsimp only [ValidRepairAngularSteps] at hrep
    rcases hrep with ⟨hbad, _⟩ | ⟨_, st₁, hatt, hrep_tl⟩
    · exact False.elim (hu_absent hbad)
    · let A_next := remLeft us V_L'
      let B_next := remRight us V_R'
      have hA_sub : A_next ⊆ V_L' := Finset.filter_subset _ _
      have hB_sub : B_next ⊆ V_R' := Finset.filter_subset _ _
      have hu_act_next : isCopyActive A_next B_next u := by
        have hu_act := hact u List.mem_cons_self
        rcases u with ⟨side, uid⟩
        cases side with
        | left =>
          dsimp only [isCopyActive] at hu_act ⊢
          exact Finset.mem_filter.mpr ⟨hu_act, hu_not_us⟩
        | right =>
          dsimp only [isCopyActive] at hu_act ⊢
          exact Finset.mem_filter.mpr ⟨hu_act, hu_not_us⟩
      have hatt_next : ValidAttachAngularStep pts o a b A_next B_next cur u st₁ := by
        rcases hatt with ⟨⟨_, hunm, hnidx⟩, ans, hprom, hst1⟩
        exact ⟨⟨hu_act_next, hunm, hnidx⟩, ans, hprom, hst1⟩
      have hA0_eq : (if u.side = .left then A_next.erase u.id else A_next) =
          remLeft (u :: us) V_L' := by
        rcases u with ⟨side, uid⟩
        cases side with
        | left =>
          dsimp only
          rw [if_pos rfl]
          ext x
          simp [A_next, remLeft]
          tauto
        | right =>
          dsimp only
          rw [if_neg (by intro h; cases h)]
          ext x
          simp [A_next, remLeft]
      have hB0_eq : (if u.side = .right then B_next.erase u.id else B_next) =
          remRight (u :: us) V_R' := by
        rcases u with ⟨side, uid⟩
        cases side with
        | left =>
          dsimp only
          rw [if_neg (by intro h; cases h)]
          ext y
          simp [B_next, remRight]
        | right =>
          dsimp only
          rw [if_pos rfl]
          ext y
          simp [B_next, remRight]
          tauto
      have hinv_next_pre :
          let V_L₀ := if u.side = .left then A_next.erase u.id else A_next
          let V_R₀ := if u.side = .right then B_next.erase u.id else B_next
          cur.SatisfiesInvariant pts V_L₀ V_R₀
            (weakEdgesOn pts m0 lam o V ℓ V_L₀ V_R₀)
            (strongEdgesOn pts m0 γ lam o V ℓ V_L₀ V_R₀) := by
        dsimp only
        rwa [hA0_eq, hB0_eq]
      have hinv1 := attach_angular_preserves_invariant pts o m0 γ lam V K j k ℓ hpair
        S' A_next B_next cur u st₁ hA_sub hB_sub hinv_next_pre hatt_next
      exact ih st₁ st' hnd_us (fun w hw => hact w (List.mem_cons_of_mem _ hw)) hinv1 hrep_tl

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_5_3_matching_invariant (h_clm_5_2_config_gap : S_clm_5_2_config_gap) : S_clm_5_3_matching_invariant := by
  classical
  unfold S_clm_5_3_matching_invariant
  intro d ι pts o V e γ lam K j k ℓ hV he hγ hlam hcfg
  dsimp only
  have h52 := h_clm_5_2_config_gap e γ lam K V j k ℓ he hγ hlam hV hcfg
  have hpair : ∀ (o' x y : EuclideanSpace ℝ (Fin d)),
      shellIndex (shellSubdiv e) o' V x = j →
      shellIndex (shellSubdiv e) o' V y = k →
      (IsStrongRoundedPair (shellSubdiv e) γ lam o' V ℓ x y →
        configThresholdA (shellSubdiv e) γ lam V j k ℓ < radialCorrelation o' x y) ∧
      (IsWeakRoundedPair (shellSubdiv e) lam o' V ℓ x y ↔
        configThresholdB (shellSubdiv e) lam V j k ℓ < radialCorrelation o' x y) :=
    h52.1 d
  have hb_nonneg : 0 ≤ configThresholdB (shellSubdiv e) lam V j k ℓ := h52.2.2.2.1
  have hR_pos : 0 < distScale lam V ℓ := by
    unfold distScale
    have hsqrt : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV
    have hlam_pos : (0 : ℝ) < (lam : ℝ) := by
      have h1 : (1 : ℝ) < (lam : ℝ) := by exact_mod_cast hlam
      linarith
    positivity
  have hconj1 : ∀ p : ι,
      ‖inwardRound (shellSubdiv e) o V (pts p) - inwardRound (shellSubdiv e) o V (pts p)‖ = 0 ∧
      ¬ IsWeakRoundedPair (shellSubdiv e) lam o V ℓ (pts p) (pts p) ∧
      ¬ attachAcceptsCorrelation o (pts p) (pts p)
          (configThresholdB (shellSubdiv e) lam V j k ℓ) := by
    intro p
    refine ⟨by rw [sub_self, norm_zero], ?_, ?_⟩
    · unfold IsWeakRoundedPair
      rw [sub_self, norm_zero]
      linarith
    · unfold attachAcceptsCorrelation
      have hle0 := radialCorrelation_self_nonpos o (pts p)
      linarith
  have hconj2 := attach_angular_preserves_invariant (ι := ι) pts o
    (shellSubdiv e) γ lam V K j k ℓ hpair
  have hconj3 : ∀ (S : Finset ι) (p : ι) (st st' : LocalMatchingState ι),
      p ∉ S →
      st.SatisfiesInvariant pts
        (configLeftVertices pts (shellSubdiv e) o V S j)
        (configRightVertices pts (shellSubdiv e) o V K S k)
        (configWeakEdges pts (shellSubdiv e) lam o V K S j k ℓ)
        (configStrongEdges pts (shellSubdiv e) γ lam o V K S j k ℓ) →
      ValidInsertOriginalAngularStep pts o
        (configThresholdA (shellSubdiv e) γ lam V j k ℓ)
        (configThresholdB (shellSubdiv e) lam V j k ℓ)
        (configLeftVertices pts (shellSubdiv e) o V (insert p S) j)
        (configRightVertices pts (shellSubdiv e) o V K (insert p S) k)
        st p st' →
      st'.SatisfiesInvariant pts
        (configLeftVertices pts (shellSubdiv e) o V (insert p S) j)
        (configRightVertices pts (shellSubdiv e) o V K (insert p S) k)
        (configWeakEdges pts (shellSubdiv e) lam o V K (insert p S) j k ℓ)
        (configStrongEdges pts (shellSubdiv e) γ lam o V K (insert p S) j k ℓ) := by
    intro S p st st' hp_not_S hinv hins
    let V_L := configLeftVertices pts (shellSubdiv e) o V S j
    let V_R := configRightVertices pts (shellSubdiv e) o V K S k
    let V_L' := configLeftVertices pts (shellSubdiv e) o V (insert p S) j
    let V_R' := configRightVertices pts (shellSubdiv e) o V K (insert p S) k
    have hVR_sub : V_R ⊆ V_R' := by
      intro y hy
      simp only [V_R, V_R', configRightVertices, shellSubset, nodeEligible, Finset.mem_filter,
        Finset.mem_insert] at hy ⊢
      exact ⟨⟨Or.inr hy.1.1, hy.1.2⟩, hy.2⟩
    rcases hins with ⟨st₁, hstepL, hstepR⟩
    have hinv1 : st₁.SatisfiesInvariant pts V_L' V_R
        (weakEdgesOn pts (shellSubdiv e) lam o V ℓ V_L' V_R)
        (strongEdgesOn pts (shellSubdiv e) γ lam o V ℓ V_L' V_R) := by
      rcases hstepL with ⟨hp_inL, hattL⟩ | ⟨hp_notL, rfl⟩
      · have hVL_erase : V_L'.erase p = V_L := by
          ext x
          simp only [V_L, V_L', configLeftVertices, shellSubset, nodeCore, Finset.mem_erase,
            Finset.mem_filter, Finset.mem_insert]
          constructor
          · rintro ⟨hxp, ⟨rfl | hxS, hball⟩, hsh⟩
            · exact False.elim (hxp rfl)
            · exact ⟨⟨hxS, hball⟩, hsh⟩
          · rintro ⟨⟨hxS, hball⟩, hsh⟩
            exact ⟨fun hEq => hp_not_S (hEq ▸ hxS), ⟨Or.inr hxS, hball⟩, hsh⟩
        have hattL_VR : ValidAttachAngularStep pts o
            (configThresholdA (shellSubdiv e) γ lam V j k ℓ)
            (configThresholdB (shellSubdiv e) lam V j k ℓ)
            V_L' V_R st ⟨.left, p⟩ st₁ := hattL
        refine hconj2 (insert p S) V_L' V_R st ⟨.left, p⟩ st₁
          (Finset.Subset.refl _) hVR_sub ?_ hattL_VR
        dsimp only
        rw [if_pos rfl, if_neg (by intro h; cases h), hVL_erase]
        exact hinv
      · have hVL_eq : configLeftVertices pts (shellSubdiv e) o V (insert p S) j =
            configLeftVertices pts (shellSubdiv e) o V S j := by
          ext x
          constructor
          · intro hx
            have hx' := hx
            simp only [configLeftVertices, shellSubset, nodeCore, Finset.mem_filter,
              Finset.mem_insert] at hx'
            rcases hx' with ⟨⟨rfl | hxS, hball⟩, hsh⟩
            · exact False.elim (hp_notL hx)
            · simp only [configLeftVertices, shellSubset, nodeCore, Finset.mem_filter]
              exact ⟨⟨hxS, hball⟩, hsh⟩
          · intro hx
            simp only [configLeftVertices, shellSubset, nodeCore, Finset.mem_filter,
              Finset.mem_insert] at hx ⊢
            exact ⟨⟨Or.inr hx.1.1, hx.1.2⟩, hx.2⟩
        dsimp only [V_L', V_R]
        unfold configWeakEdges configStrongEdges at hinv
        rwa [hVL_eq]
    rcases hstepR with ⟨hp_inR, hattR⟩ | ⟨hp_notR, rfl⟩
    · have hVR_erase : V_R'.erase p = V_R := by
        ext y
        simp only [V_R, V_R', configRightVertices, shellSubset, nodeEligible, Finset.mem_erase,
          Finset.mem_filter, Finset.mem_insert]
        constructor
        · rintro ⟨hyp, ⟨rfl | hyS, helig⟩, hsh⟩
          · exact False.elim (hyp rfl)
          · exact ⟨⟨hyS, helig⟩, hsh⟩
        · rintro ⟨⟨hyS, helig⟩, hsh⟩
          exact ⟨fun hEq => hp_not_S (hEq ▸ hyS), ⟨Or.inr hyS, helig⟩, hsh⟩
      refine hconj2 (insert p S) V_L' V_R' st₁ ⟨.right, p⟩ st'
        (Finset.Subset.refl _) (Finset.Subset.refl _) ?_ hattR
      dsimp only
      rw [if_neg (by intro h; cases h), if_pos rfl, hVR_erase]
      exact hinv1
    · have hVR_eq : configRightVertices pts (shellSubdiv e) o V K (insert p S) k =
          configRightVertices pts (shellSubdiv e) o V K S k := by
        ext y
        constructor
        · intro hy
          have hy' := hy
          simp only [configRightVertices, shellSubset, nodeEligible, Finset.mem_filter,
            Finset.mem_insert] at hy'
          rcases hy' with ⟨⟨rfl | hyS, helig⟩, hsh⟩
          · exact False.elim (hp_notR hy)
          · simp only [configRightVertices, shellSubset, nodeEligible, Finset.mem_filter]
            exact ⟨⟨hyS, helig⟩, hsh⟩
        · intro hy
          simp only [configRightVertices, shellSubset, nodeEligible, Finset.mem_filter,
            Finset.mem_insert] at hy ⊢
          exact ⟨⟨Or.inr hy.1.1, hy.1.2⟩, hy.2⟩
      dsimp only [V_L', V_R] at hinv1
      unfold configWeakEdges configStrongEdges
      rwa [hVR_eq]
  have hconj4 : ∀ (S : Finset ι) (p : ι) (st : LocalMatchingState ι),
      p ∈ S →
      st.SatisfiesInvariant pts
        (configLeftVertices pts (shellSubdiv e) o V S j)
        (configRightVertices pts (shellSubdiv e) o V K S k)
        (configWeakEdges pts (shellSubdiv e) lam o V K S j k ℓ)
        (configStrongEdges pts (shellSubdiv e) γ lam o V K S j k ℓ) →
      (survivingFormerPartnerSet st p).card ≤ 2 ∧
      (survivingFormerPartners st p).length ≤ 2 ∧
      (survivingFormerPartnerSet st p = ∅ →
        (removeCopiesFromState st p).SatisfiesInvariant pts
          (configLeftVertices pts (shellSubdiv e) o V (S.erase p) j)
          (configRightVertices pts (shellSubdiv e) o V K (S.erase p) k)
          (configWeakEdges pts (shellSubdiv e) lam o V K (S.erase p) j k ℓ)
          (configStrongEdges pts (shellSubdiv e) γ lam o V K (S.erase p) j k ℓ)) ∧
      (∀ st' : LocalMatchingState ι,
        ValidDeleteOriginalAngularStep pts o
          (configThresholdA (shellSubdiv e) γ lam V j k ℓ)
          (configThresholdB (shellSubdiv e) lam V j k ℓ)
          (configLeftVertices pts (shellSubdiv e) o V (S.erase p) j)
          (configRightVertices pts (shellSubdiv e) o V K (S.erase p) k)
          st p st' →
        st'.SatisfiesInvariant pts
          (configLeftVertices pts (shellSubdiv e) o V (S.erase p) j)
          (configRightVertices pts (shellSubdiv e) o V K (S.erase p) k)
          (configWeakEdges pts (shellSubdiv e) lam o V K (S.erase p) j k ℓ)
          (configStrongEdges pts (shellSubdiv e) γ lam o V K (S.erase p) j k ℓ)) := by
    intro S p st _ hinv
    let V_L := configLeftVertices pts (shellSubdiv e) o V S j
    let V_R := configRightVertices pts (shellSubdiv e) o V K S k
    have hVL_erase : configLeftVertices pts (shellSubdiv e) o V (S.erase p) j = V_L.erase p := by
      ext x
      simp only [V_L, configLeftVertices, shellSubset, nodeCore, Finset.mem_filter, Finset.mem_erase]
      tauto
    have hVR_erase : configRightVertices pts (shellSubdiv e) o V K (S.erase p) k = V_R.erase p := by
      ext y
      simp only [V_R, configRightVertices, shellSubset, nodeEligible, Finset.mem_filter,
        Finset.mem_erase]
      tauto
    have hbnds := surviving_partners_bounds hinv.1 p
    have hrem := removeCopies_satisfies_invariant pts (shellSubdiv e) γ lam o V ℓ V_L V_R st p hinv
    refine ⟨hbnds.1, hbnds.2, ?_, ?_⟩
    · intro hF_empty
      have hF_nil : survivingFormerPartners st p = [] := by
        cases hL_eq : survivingFormerPartners st p with
        | nil => rfl
        | cons hd tl =>
          exfalso
          have hmem : hd ∈ survivingFormerPartnerSet st p := by
            unfold survivingFormerPartnerSet
            rw [hL_eq, List.mem_toFinset]
            exact List.mem_cons_self
          rw [hF_empty] at hmem
          simp at hmem
      dsimp only at hrem
      rw [hF_nil] at hrem
      have hL : remLeft [] (V_L.erase p) = V_L.erase p := by ext x; simp [remLeft]
      have hR : remRight [] (V_R.erase p) = V_R.erase p := by ext y; simp [remRight]
      rw [hL, hR] at hrem
      unfold configWeakEdges configStrongEdges
      rwa [hVL_erase, hVR_erase]
    · intro st' hdel
      rcases hdel with ⟨L, hperm, hrep⟩
      have hnd_L : L.Nodup := hperm.nodup_iff.mpr (List.nodup_dedup _)
      have hact_L : ∀ u ∈ L, isCopyActive
          (configLeftVertices pts (shellSubdiv e) o V (S.erase p) j)
          (configRightVertices pts (shellSubdiv e) o V K (S.erase p) k) u := by
        intro u hu
        rw [hVL_erase, hVR_erase]
        exact surviving_partners_active hinv.1 p (hperm.mem_iff.mp hu)
      have hremL : remLeft L (configLeftVertices pts (shellSubdiv e) o V (S.erase p) j) =
          remLeft (survivingFormerPartners st p) (V_L.erase p) := by
        rw [hVL_erase]
        ext x
        simp [remLeft, hperm.mem_iff]
      have hremR : remRight L (configRightVertices pts (shellSubdiv e) o V K (S.erase p) k) =
          remRight (survivingFormerPartners st p) (V_R.erase p) := by
        rw [hVR_erase]
        ext y
        simp [remRight, hperm.mem_iff]
      dsimp only at hrem
      rw [← hremL, ← hremR] at hrem
      exact repair_angular_preserves_invariant pts o (shellSubdiv e) γ lam V K j k ℓ hpair
        (S.erase p) L (removeCopiesFromState st p) st' hnd_L hact_L hrem hrep
  have hconj5 : ∀ (S : Finset ι) (M : Finset (ι × ι)),
      SatisfiesConfigMatchingInvariant pts (shellSubdiv e) γ lam o V K S j k ℓ M →
      (M = ∅ → configStrongEdges pts (shellSubdiv e) γ lam o V K S j k ℓ = ∅) ∧
      ((configStrongEdges pts (shellSubdiv e) γ lam o V K S j k ℓ).Nonempty → M.Nonempty) ∧
      (M.Nonempty → ∃ x y : ι, (x, y) ∈ M ∧
        (x, y) ∈ configWeakEdges pts (shellSubdiv e) lam o V K S j k ℓ ∧
        x ∈ S ∧ y ∈ S ∧ x ≠ y) ∧
      (∀ e_pair ∈ M,
        e_pair ∈ configWeakEdges pts (shellSubdiv e) lam o V K S j k ℓ ∧
        e_pair.1 ∈ S ∧ e_pair.2 ∈ S ∧ e_pair.1 ≠ e_pair.2) := by
    intro S M hinv
    rcases hinv with ⟨hM_weak, _, hdisj⟩
    have hempty : M = ∅ → configStrongEdges pts (shellSubdiv e) γ lam o V K S j k ℓ = ∅ := by
      intro hM0
      subst hM0
      have huL : unmatchedLeft (configLeftVertices pts (shellSubdiv e) o V S j) ∅ =
          configLeftVertices pts (shellSubdiv e) o V S j := by
        ext x; simp [unmatchedLeft]
      have huR : unmatchedRight (configRightVertices pts (shellSubdiv e) o V K S k) ∅ =
          configRightVertices pts (shellSubdiv e) o V K S k := by
        ext y; simp [unmatchedRight]
      rw [huL, huR] at hdisj
      ext xy
      constructor
      · intro hxy
        exfalso
        have hprod : xy ∈ configLeftVertices pts (shellSubdiv e) o V S j ×ˢ
            configRightVertices pts (shellSubdiv e) o V K S k := by
          unfold configStrongEdges strongEdgesOn at hxy
          exact (Finset.mem_filter.mp hxy).1
        exact Finset.disjoint_left.mp hdisj hxy hprod
      · intro hxy
        simp at hxy
    have hnonempty : (configStrongEdges pts (shellSubdiv e) γ lam o V K S j k ℓ).Nonempty →
        M.Nonempty := by
      intro hne
      rw [Finset.nonempty_iff_ne_empty]
      intro hM0
      exact hne.ne_empty (hempty hM0)
    have hall : ∀ e_pair ∈ M,
        e_pair ∈ configWeakEdges pts (shellSubdiv e) lam o V K S j k ℓ ∧
        e_pair.1 ∈ S ∧ e_pair.2 ∈ S ∧ e_pair.1 ≠ e_pair.2 := by
      intro e_pair he
      have hw := hM_weak he
      have hw' := hw
      unfold configWeakEdges weakEdgesOn at hw'
      rw [Finset.mem_filter, Finset.mem_product] at hw'
      rcases hw' with ⟨⟨hxL, hyR⟩, hweak_pair⟩
      have hxS : e_pair.1 ∈ S := by
        unfold configLeftVertices shellSubset nodeCore at hxL
        rw [Finset.mem_filter, Finset.mem_filter] at hxL
        exact hxL.1.1
      have hyS : e_pair.2 ∈ S := by
        unfold configRightVertices shellSubset nodeEligible at hyR
        rw [Finset.mem_filter, Finset.mem_filter] at hyR
        exact hyR.1.1
      have hne_pair : e_pair.1 ≠ e_pair.2 := by
        intro hEq
        rw [hEq] at hweak_pair
        exact (hconj1 e_pair.2).2.1 hweak_pair
      exact ⟨hw, hxS, hyS, hne_pair⟩
    refine ⟨hempty, hnonempty, ?_, hall⟩
    intro hMne
    rcases hMne with ⟨⟨x, y⟩, hxy⟩
    exact ⟨x, y, hxy, hall (x, y) hxy⟩
  exact ⟨hconj1, hconj2, hconj3, hconj4, hconj5⟩

end UL
