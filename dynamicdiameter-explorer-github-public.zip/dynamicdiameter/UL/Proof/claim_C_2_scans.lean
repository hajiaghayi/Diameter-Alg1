import UL.Stmt.claim_C_2_scans
import UL.Stmt.clm_5_3_matching_invariant
import UL.Stmt.lem_7_1
import UL.Proof.claim_C_2_scans.H1_AVL
import UL.Proof.claim_C_2_scans.RaceV30_H2
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_claim_C_2_scans (h_clm_5_3_matching_invariant : S_clm_5_3_matching_invariant) (h_lem_7_1 : S_lem_7_1) : S_claim_C_2_scans := by
  let _ := h_lem_7_1
  exact ⟨claim_C_2_scans_part1, UL.C2ScansRaceV30.claim_C_2_scans_part2 h_clm_5_3_matching_invariant⟩

end UL
