import UL.Stmt.clm_5_2_config_gap
set_option autoImplicit false

namespace UL

private theorem norm_radialDirection_eq_one {d : ℕ}
    {o p : EuclideanSpace ℝ (Fin d)} (hp : ‖p - o‖ ≠ 0) :
    ‖radialDirection o p‖ = 1 := by
  unfold radialDirection
  rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_of_nonneg (norm_nonneg _), inv_mul_cancel₀ hp]

private theorem norm_inwardRound_sub_sq {d : ℕ}
    (m0 : ℕ) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (j k : ℕ)
    (x y : EuclideanSpace ℝ (Fin d))
    (hx_shell : shellIndex m0 o V x = j)
    (hy_shell : shellIndex m0 o V y = k)
    (hj : 1 ≤ j) (hk : 1 ≤ k) :
    ‖inwardRound m0 o V x - inwardRound m0 o V y‖ ^ 2 =
      shellRadius m0 V j ^ 2 + shellRadius m0 V k ^ 2 +
        2 * shellRadius m0 V j * shellRadius m0 V k * radialCorrelation o x y := by
  have hx_ne : ‖x - o‖ ≠ 0 := by
    intro h0
    unfold shellIndex at hx_shell
    rw [h0, mul_zero, zero_div, Nat.floor_zero] at hx_shell
    omega
  have hy_ne : ‖y - o‖ ≠ 0 := by
    intro h0
    unfold shellIndex at hy_shell
    rw [h0, mul_zero, zero_div, Nat.floor_zero] at hy_shell
    omega
  have hux : ‖radialDirection o x‖ = 1 := norm_radialDirection_eq_one hx_ne
  have huy : ‖radialDirection o y‖ = 1 := norm_radialDirection_eq_one hy_ne
  have hdiff : inwardRound m0 o V x - inwardRound m0 o V y =
      shellRadius m0 V j • radialDirection o x - shellRadius m0 V k • radialDirection o y := by
    unfold inwardRound
    rw [hx_shell, hy_shell]
    abel
  rw [hdiff, norm_sub_sq_real]
  rw [norm_smul, norm_smul, Real.norm_eq_abs, Real.norm_eq_abs, hux, huy, mul_one, mul_one,
    sq_abs, sq_abs]
  rw [real_inner_smul_left, real_inner_smul_right]
  unfold radialCorrelation
  rw [inner_neg_left]
  ring

private theorem threshold_gap_identity (γ R rj rk : ℝ) (hden : 2 * rj * rk ≠ 0) :
    (γ ^ 2 * R ^ 2 - rj ^ 2 - rk ^ 2) / (2 * rj * rk) -
      (1 + (γ ^ 2 - 1)) * ((R ^ 2 - rj ^ 2 - rk ^ 2) / (2 * rj * rk)) =
    (γ ^ 2 - 1) * ((rj ^ 2 + rk ^ 2) / (2 * rj * rk)) := by
  field_simp [hden]
  ring

private theorem pair_correlation_iff
    (m0 : ℕ) (γ lam : ℚ) (V : ℝ) (j k ℓ : ℕ)
    (hm0 : 0 < m0) (hγ : 1 < γ) (hlam : 1 < lam) (hV : 0 < V)
    (hj : 1 ≤ j) (hk : 1 ≤ k) :
    ∀ (d : ℕ) (o x y : EuclideanSpace ℝ (Fin d)),
      shellIndex m0 o V x = j →
      shellIndex m0 o V y = k →
      (IsStrongRoundedPair m0 γ lam o V ℓ x y →
        configThresholdA m0 γ lam V j k ℓ < radialCorrelation o x y) ∧
      (IsWeakRoundedPair m0 lam o V ℓ x y ↔
        configThresholdB m0 lam V j k ℓ < radialCorrelation o x y) := by
  have hm0_real : (0 : ℝ) < (m0 : ℝ) := by exact_mod_cast hm0
  have hsqrtV : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV
  have hrj : 0 < shellRadius m0 V j := by
    unfold shellRadius
    have hj_pos : (0 : ℝ) < (j : ℝ) := by exact_mod_cast hj
    positivity
  have hrk : 0 < shellRadius m0 V k := by
    unfold shellRadius
    have hk_pos : (0 : ℝ) < (k : ℝ) := by exact_mod_cast hk
    positivity
  have hdenom : 0 < 2 * shellRadius m0 V j * shellRadius m0 V k := by positivity
  have hγ_real : (1 : ℝ) < (γ : ℝ) := by exact_mod_cast hγ
  have hlam_real : (1 : ℝ) < (lam : ℝ) := by exact_mod_cast hlam
  have hR_pos : 0 < distScale lam V ℓ := by
    unfold distScale
    have hlam_pos : (0 : ℝ) < (lam : ℝ) := by linarith
    positivity
  have hγR_pos : 0 < (γ : ℝ) * distScale lam V ℓ := by
    have hγ_pos : (0 : ℝ) < (γ : ℝ) := by linarith
    positivity
  intro d o x y hx hy
  have hnorm_sq := norm_inwardRound_sub_sq m0 o V j k x y hx hy hj hk
  have hD_nonneg : 0 ≤ ‖inwardRound m0 o V x - inwardRound m0 o V y‖ := norm_nonneg _
  constructor
  · intro hstrong
    unfold IsStrongRoundedPair at hstrong
    have hsq_lt : ((γ : ℝ) * distScale lam V ℓ) ^ 2 <
        ‖inwardRound m0 o V x - inwardRound m0 o V y‖ ^ 2 := by
      nlinarith [hγR_pos]
    rw [hnorm_sq] at hsq_lt
    unfold configThresholdA
    rw [div_lt_iff₀ hdenom]
    nlinarith
  · unfold IsWeakRoundedPair configThresholdB
    rw [div_lt_iff₀ hdenom]
    constructor
    · intro hlt
      have hsq_lt : distScale lam V ℓ ^ 2 <
          ‖inwardRound m0 o V x - inwardRound m0 o V y‖ ^ 2 := by
        nlinarith [hR_pos]
      rw [hnorm_sq] at hsq_lt
      linarith
    · intro hlt
      have hsq_lt : distScale lam V ℓ ^ 2 <
          ‖inwardRound m0 o V x - inwardRound m0 o V y‖ ^ 2 := by
        rw [hnorm_sq]
        linarith
      nlinarith [hR_pos, hD_nonneg]

open Classical in
private theorem graph_correlation_iff
    (m0 : ℕ) (γ lam : ℚ) (K : ℤ) (V : ℝ) (j k ℓ : ℕ)
    (hpair : ∀ (d : ℕ) (o x y : EuclideanSpace ℝ (Fin d)),
      shellIndex m0 o V x = j →
      shellIndex m0 o V y = k →
      (IsStrongRoundedPair m0 γ lam o V ℓ x y →
        configThresholdA m0 γ lam V j k ℓ < radialCorrelation o x y) ∧
      (IsWeakRoundedPair m0 lam o V ℓ x y ↔
        configThresholdB m0 lam V j k ℓ < radialCorrelation o x y)) :
    ∀ (d : ℕ) (ι : Type) (pts : ι → EuclideanSpace ℝ (Fin d))
      (o : EuclideanSpace ℝ (Fin d)) (S : Finset ι),
      (∀ xy ∈ configStrongEdges pts m0 γ lam o V K S j k ℓ,
        configThresholdA m0 γ lam V j k ℓ < radialCorrelation o (pts xy.1) (pts xy.2)) ∧
      (∀ x ∈ configLeftVertices pts m0 o V S j,
       ∀ y ∈ configRightVertices pts m0 o V K S k,
        ((x, y) ∈ configWeakEdges pts m0 lam o V K S j k ℓ ↔
          configThresholdB m0 lam V j k ℓ < radialCorrelation o (pts x) (pts y))) := by
  intro d ι pts o S
  constructor
  · intro xy hxy
    unfold configStrongEdges strongEdgesOn at hxy
    rw [Finset.mem_filter, Finset.mem_product] at hxy
    rcases hxy with ⟨⟨hxL, hyR⟩, hstrong⟩
    unfold configLeftVertices shellSubset at hxL
    unfold configRightVertices shellSubset at hyR
    have hx_shell : shellIndex m0 o V (pts xy.1) = j := (Finset.mem_filter.mp hxL).2
    have hy_shell : shellIndex m0 o V (pts xy.2) = k := (Finset.mem_filter.mp hyR).2
    exact (hpair d o (pts xy.1) (pts xy.2) hx_shell hy_shell).1 hstrong
  · intro x hxL y hyR
    have hx_shell : shellIndex m0 o V (pts x) = j := by
      unfold configLeftVertices shellSubset at hxL
      exact (Finset.mem_filter.mp hxL).2
    have hy_shell : shellIndex m0 o V (pts y) = k := by
      unfold configRightVertices shellSubset at hyR
      exact (Finset.mem_filter.mp hyR).2
    unfold configWeakEdges weakEdgesOn
    rw [Finset.mem_filter, Finset.mem_product]
    simp only [hxL, hyR, and_self, true_and]
    exact (hpair d o (pts x) (pts y) hx_shell hy_shell).2

private theorem thresholds_rational
    (m0 : ℕ) (γ lam : ℚ) (V : ℝ) (j k ℓ : ℕ) (hV : 0 < V) :
    ∃ a_rat b_rat : ℚ,
      configThresholdA m0 γ lam V j k ℓ = (a_rat : ℝ) ∧
      configThresholdB m0 lam V j k ℓ = (b_rat : ℝ) ∧
      ∀ V' : ℝ, 0 < V' →
        configThresholdA m0 γ lam V' j k ℓ = (a_rat : ℝ) ∧
        configThresholdB m0 lam V' j k ℓ = (b_rat : ℝ) := by
  let rj0 : ℚ := (j : ℚ) / (m0 : ℚ)
  let rk0 : ℚ := (k : ℚ) / (m0 : ℚ)
  let R0 : ℚ := lam ^ ℓ / 2
  let a_rat : ℚ := (γ ^ 2 * R0 ^ 2 - rj0 ^ 2 - rk0 ^ 2) / (2 * rj0 * rk0)
  let b_rat : ℚ := (R0 ^ 2 - rj0 ^ 2 - rk0 ^ 2) / (2 * rj0 * rk0)
  have hV_inv : ∀ V' : ℝ, 0 < V' →
      configThresholdA m0 γ lam V' j k ℓ = (a_rat : ℝ) ∧
      configThresholdB m0 lam V' j k ℓ = (b_rat : ℝ) := by
    intro V' hV'
    have hsqV' : Real.sqrt V' ^ 2 = V' := Real.sq_sqrt hV'.le
    have hV'_ne : V' ≠ 0 := hV'.ne'
    have hrj_sq : shellRadius m0 V' j ^ 2 = ((rj0 : ℝ) ^ 2) * V' := by
      unfold shellRadius
      dsimp [rj0]
      push_cast
      rw [mul_pow, hsqV']
    have hrk_sq : shellRadius m0 V' k ^ 2 = ((rk0 : ℝ) ^ 2) * V' := by
      unfold shellRadius
      dsimp [rk0]
      push_cast
      rw [mul_pow, hsqV']
    have hR_sq : distScale lam V' ℓ ^ 2 = ((R0 : ℝ) ^ 2) * V' := by
      unfold distScale
      dsimp [R0]
      push_cast
      have h1 : (lam : ℝ) ^ ℓ * Real.sqrt V' / 2 = ((lam : ℝ) ^ ℓ / 2) * Real.sqrt V' := by ring
      rw [h1, mul_pow, hsqV']
    have hden_V' : 2 * shellRadius m0 V' j * shellRadius m0 V' k =
        (2 * (rj0 : ℝ) * (rk0 : ℝ)) * V' := by
      unfold shellRadius
      dsimp [rj0, rk0]
      push_cast
      calc 2 * ((j : ℝ) / (m0 : ℝ) * Real.sqrt V') * ((k : ℝ) / (m0 : ℝ) * Real.sqrt V')
          = (2 * ((j : ℝ) / (m0 : ℝ)) * ((k : ℝ) / (m0 : ℝ))) * (Real.sqrt V' ^ 2) := by ring
        _ = (2 * ((j : ℝ) / (m0 : ℝ)) * ((k : ℝ) / (m0 : ℝ))) * V' := by rw [hsqV']
    constructor
    · unfold configThresholdA
      rw [hrj_sq, hrk_sq, hR_sq, hden_V']
      have hnumA : (γ : ℝ) ^ 2 * ((R0 : ℝ) ^ 2 * V') - (rj0 : ℝ) ^ 2 * V' - (rk0 : ℝ) ^ 2 * V' =
          ((γ : ℝ) ^ 2 * (R0 : ℝ) ^ 2 - (rj0 : ℝ) ^ 2 - (rk0 : ℝ) ^ 2) * V' := by ring
      rw [hnumA, mul_div_mul_right _ _ hV'_ne]
      dsimp [a_rat]
      push_cast
      rfl
    · unfold configThresholdB
      rw [hrj_sq, hrk_sq, hR_sq, hden_V']
      have hnumB : (R0 : ℝ) ^ 2 * V' - (rj0 : ℝ) ^ 2 * V' - (rk0 : ℝ) ^ 2 * V' =
          ((R0 : ℝ) ^ 2 - (rj0 : ℝ) ^ 2 - (rk0 : ℝ) ^ 2) * V' := by ring
      rw [hnumB, mul_div_mul_right _ _ hV'_ne]
      dsimp [b_rat]
      push_cast
      rfl
  exact ⟨a_rat, b_rat, (hV_inv V hV).1, (hV_inv V hV).2, hV_inv⟩

private theorem thresholds_gap_bounds
    (m0 : ℕ) (γ lam : ℚ) (V : ℝ) (j k ℓ : ℕ)
    (hm0 : 0 < m0) (hγ : 1 < γ) (hlam : 1 < lam) (hV : 0 < V)
    (hj : 1 ≤ j) (hk : 1 ≤ k)
    (hret : SatisfiesRetentionCond m0 γ lam V j k ℓ) :
    let r_j := shellRadius m0 V j
    let r_k := shellRadius m0 V k
    let a := configThresholdA m0 γ lam V j k ℓ
    let b := configThresholdB m0 lam V j k ℓ
    let g : ℝ := (γ : ℝ) ^ 2 - 1
    0 ≤ b ∧
    b < a ∧
    a ≤ 1 ∧
    a - (1 + g) * b = g * ((r_j ^ 2 + r_k ^ 2) / (2 * r_j * r_k)) ∧
    g ≤ g * ((r_j ^ 2 + r_k ^ 2) / (2 * r_j * r_k)) := by
  dsimp only
  rcases hret with ⟨hret_sq, hret_sum⟩
  have hm0_real : (0 : ℝ) < (m0 : ℝ) := by exact_mod_cast hm0
  have hsqrtV : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV
  have hrj_pos : 0 < shellRadius m0 V j := by
    unfold shellRadius
    have hj_pos : (0 : ℝ) < (j : ℝ) := by exact_mod_cast hj
    positivity
  have hrk_pos : 0 < shellRadius m0 V k := by
    unfold shellRadius
    have hk_pos : (0 : ℝ) < (k : ℝ) := by exact_mod_cast hk
    positivity
  have hdenom_pos : 0 < 2 * shellRadius m0 V j * shellRadius m0 V k := by positivity
  have hγ_real : (1 : ℝ) < (γ : ℝ) := by exact_mod_cast hγ
  have hlam_real : (1 : ℝ) < (lam : ℝ) := by exact_mod_cast hlam
  have hR_pos : 0 < distScale lam V ℓ := by
    unfold distScale
    have hlam_pos : (0 : ℝ) < (lam : ℝ) := by linarith
    positivity
  have hγR_pos : 0 < (γ : ℝ) * distScale lam V ℓ := by
    have hγ_pos : (0 : ℝ) < (γ : ℝ) := by linarith
    positivity
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · unfold configThresholdB
    apply div_nonneg _ hdenom_pos.le
    linarith [hret_sq]
  · unfold configThresholdB configThresholdA
    apply div_lt_div_of_pos_right _ hdenom_pos
    have hγ2 : 1 < (γ : ℝ) ^ 2 := by nlinarith [hγ_real]
    have hR2_pos : 0 < distScale lam V ℓ ^ 2 := sq_pos_of_pos hR_pos
    nlinarith
  · unfold configThresholdA
    rw [div_le_one hdenom_pos]
    have hsq_sum : ((γ : ℝ) * distScale lam V ℓ) ^ 2 ≤
        (shellRadius m0 V j + shellRadius m0 V k) ^ 2 := by
      nlinarith [hret_sum, hγR_pos]
    nlinarith
  · unfold configThresholdA configThresholdB
    exact threshold_gap_identity (γ : ℝ) (distScale lam V ℓ)
      (shellRadius m0 V j) (shellRadius m0 V k) hdenom_pos.ne'
  · have hg_pos : 0 < (γ : ℝ) ^ 2 - 1 := by nlinarith [hγ_real]
    have h1_le_ratio : 1 ≤ (shellRadius m0 V j ^ 2 + shellRadius m0 V k ^ 2) /
        (2 * shellRadius m0 V j * shellRadius m0 V k) := by
      rw [one_le_div hdenom_pos]
      nlinarith [sq_nonneg (shellRadius m0 V j - shellRadius m0 V k)]
    calc ((γ : ℝ) ^ 2 - 1) = ((γ : ℝ) ^ 2 - 1) * 1 := (mul_one _).symm
      _ ≤ ((γ : ℝ) ^ 2 - 1) * ((shellRadius m0 V j ^ 2 + shellRadius m0 V k ^ 2) /
            (2 * shellRadius m0 V j * shellRadius m0 V k)) :=
          mul_le_mul_of_nonneg_left h1_le_ratio hg_pos.le

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_5_2_config_gap : S_clm_5_2_config_gap := by
  unfold S_clm_5_2_config_gap
  intro e γ lam K V j k ℓ he hγ hlam hV hret
  have hm0 : 0 < shellSubdiv e := Nat.ceil_pos.mpr (div_pos one_pos he)
  rcases hret with ⟨⟨hj1, _, hk1, _, _⟩, hret_cond⟩
  have hp1 := pair_correlation_iff (shellSubdiv e) γ lam V j k ℓ hm0 hγ hlam hV hj1 hk1
  have hp2 := graph_correlation_iff (shellSubdiv e) γ lam K V j k ℓ hp1
  have hp3 := thresholds_rational (shellSubdiv e) γ lam V j k ℓ hV
  have hp4 := thresholds_gap_bounds (shellSubdiv e) γ lam V j k ℓ hm0 hγ hlam hV hj1 hk1 hret_cond
  exact ⟨hp1, hp2, hp3, hp4.1, hp4.2.1, hp4.2.2.1, hp4.2.2.2.1, hp4.2.2.2.2⟩

end UL
