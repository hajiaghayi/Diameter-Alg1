import Mathlib
import UL.Stmt.lem_6_1
import UL.Stmt.lem_6_2
import UL.Stmt.lem_6_3
import UL.Proof.lem_6_3.H1_RAM
import UL.Proof.lem_6_3.H5_Prob
import UL.Proof.lem_6_3.RacerV30_H2
import UL.Proof.lem_6_3.RacerV30_H3
import UL.Proof.lem_6_3.RacerV30_H4
set_option autoImplicit false

namespace UL.Proof.lem_6_3.RacerV30

open UL.Proof_lem_6_3

/-! ### 1. Polynomial, work, and peak-space helper bounds -/

noncomputable def polyFactor (ℓ C_base d L : ℕ) : ℝ :=
  4000 * ((paramCostConst ℓ C_base : ℝ) + 1 +
      (paramPowConst ℓ C_base + 1) * ((ℓ : ℝ) + 1)) *
    ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6))

theorem isBoundedByPoly2_polyFactor (ℓ C_base : ℕ) :
    IsBoundedByPoly2 (polyFactor ℓ C_base) := by
  refine ⟨4000 * ((paramCostConst ℓ C_base : ℝ) + 1 +
      (paramPowConst ℓ C_base + 1) * ((ℓ : ℝ) + 1)), 2 * ℓ + 6, ?_, fun _ _ => le_rfl⟩
  have hp : 0 ≤ paramPowConst ℓ C_base := paramPowConst_nonneg ℓ C_base
  positivity

theorem polyFactor_nonneg (ℓ C_base d L : ℕ) : 0 ≤ polyFactor ℓ C_base d L := by
  unfold polyFactor
  have hp : 0 ≤ paramPowConst ℓ C_base := paramPowConst_nonneg ℓ C_base
  positivity

theorem param_cost_le_quarter {ℓ C_base d m : ℕ} {h x : ℝ}
    (hm : 1 ≤ m) (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1)
    {cost : ℕ} (hcost : cost ≤ paramCostConst ℓ C_base * (natBitLength m + 1) ^ 6) :
    (cost : ℝ) ≤
      (1 / 4 : ℝ) * (((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        polyFactor ℓ C_base d (natBitLength m)) := by
  let L := natBitLength m
  rcases I_h_bounds hh0 hh1 hx0 hx1 with ⟨_, _, hu0, _, _, _⟩
  have hm1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
  have hmu1 : (1 : ℝ) ≤ (m : ℝ) ^ (u_search h x) := Real.one_le_rpow hm1 hu0
  have hmb0 : (0 : ℝ) ≤ (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by positivity
  have hXd1 : (1 : ℝ) ≤ ((d + 1 : ℝ) ^ (2 * ℓ + 6)) :=
    one_le_pow₀ (by have : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d; linarith only [this])
  have hXL_le : ((L + 1 : ℝ) ^ 6) ≤ ((L + 1 : ℝ) ^ (2 * ℓ + 6)) :=
    pow_le_pow_right₀ (by have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [this])
      (by omega)
  have hp : 0 ≤ paramPowConst ℓ C_base := paramPowConst_nonneg ℓ C_base
  have hcost_r : (cost : ℝ) ≤ (paramCostConst ℓ C_base : ℝ) * ((L + 1 : ℝ) ^ 6) := by
    exact_mod_cast hcost
  have hK : (paramCostConst ℓ C_base : ℝ) ≤
      (1 / 4 : ℝ) * (4000 * ((paramCostConst ℓ C_base : ℝ) + 1 +
        (paramPowConst ℓ C_base + 1) * ((ℓ : ℝ) + 1))) := by
    have hnn : 0 ≤ (paramPowConst ℓ C_base + 1) * ((ℓ : ℝ) + 1) := by positivity
    have hpc0 : 0 ≤ (paramCostConst ℓ C_base : ℝ) := Nat.cast_nonneg _
    linarith only [hnn, hpc0]
  calc (cost : ℝ)
      ≤ (paramCostConst ℓ C_base : ℝ) * ((L + 1 : ℝ) ^ 6) := hcost_r
    _ = (paramCostConst ℓ C_base : ℝ) * 1 * ((L + 1 : ℝ) ^ 6) := by ring
    _ ≤ ((1 / 4 : ℝ) * (4000 * ((paramCostConst ℓ C_base : ℝ) + 1 +
          (paramPowConst ℓ C_base + 1) * ((ℓ : ℝ) + 1)))) *
          ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) := by
        refine mul_le_mul (mul_le_mul hK hXd1 zero_le_one (by positivity)) hXL_le
          (by positivity) (by positivity)
    _ = (1 / 4 : ℝ) * (1 * polyFactor ℓ C_base d L) := by unfold polyFactor; ring
    _ ≤ (1 / 4 : ℝ) * (((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
          polyFactor ℓ C_base d L) := by
        have hsum1 : (1 : ℝ) ≤ (m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
          linarith only [hmu1, hmb0]
        exact mul_le_mul_of_nonneg_left
          (mul_le_mul_of_nonneg_right hsum1 (polyFactor_nonneg ℓ C_base d L)) (by norm_num)

theorem init_cost_le_quarter {ℓ C_base d m M₀ : ℕ} {h x : ℝ}
    (hM₀ : 1 ≤ M₀)
    (hM₀_ub : (M₀ : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength m + 1 : ℝ) ^ 2) *
      (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))
    {cost : ℕ} (hcost : cost ≤ 20 + (ℓ * M₀) * (20 + d * 35)) :
    (cost : ℝ) ≤
      (1 / 4 : ℝ) * (((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        polyFactor ℓ C_base d (natBitLength m)) := by
  let L := natBitLength m
  have hnat : cost ≤ 55 * (ℓ + 1) * (d + 1) * M₀ := by
    have h1 : 20 + d * 35 ≤ 35 * (d + 1) := by omega
    have h2 : (ℓ * M₀) * (20 + d * 35) ≤ 35 * (ℓ + 1) * (d + 1) * M₀ := by
      calc (ℓ * M₀) * (20 + d * 35) ≤ (ℓ * M₀) * (35 * (d + 1)) := Nat.mul_le_mul_left _ h1
        _ = 35 * ℓ * (d + 1) * M₀ := by ring
        _ ≤ 35 * (ℓ + 1) * (d + 1) * M₀ :=
          Nat.mul_le_mul_right M₀ (Nat.mul_le_mul_right (d + 1) (Nat.mul_le_mul_left 35 (by omega)))
    have h3 : 1 ≤ (ℓ + 1) * (d + 1) * M₀ := by
      have hld : 1 ≤ (ℓ + 1) * (d + 1) := by nlinarith
      simpa using Nat.mul_le_mul hld hM₀
    calc cost ≤ 20 + (ℓ * M₀) * (20 + d * 35) := hcost
      _ ≤ 20 * ((ℓ + 1) * (d + 1) * M₀) + 35 * (ℓ + 1) * (d + 1) * M₀ :=
        Nat.add_le_add (Nat.le_mul_of_pos_right 20 h3) h2
      _ = 55 * (ℓ + 1) * (d + 1) * M₀ := by ring
  have hcost_r : (cost : ℝ) ≤ 55 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (M₀ : ℝ) := by
    exact_mod_cast hnat
  have hXd : (d + 1 : ℝ) ≤ ((d + 1 : ℝ) ^ (2 * ℓ + 6)) := by
    simpa using pow_le_pow_right₀
      (by have : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d; linarith only [this])
      (by omega : 1 ≤ 2 * ℓ + 6)
  have hXL : ((L + 1 : ℝ) ^ 2) ≤ ((L + 1 : ℝ) ^ (2 * ℓ + 6)) :=
    pow_le_pow_right₀ (by have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [this])
      (by omega)
  have hp : 0 ≤ paramPowConst ℓ C_base := paramPowConst_nonneg ℓ C_base
  have hmu0 : (0 : ℝ) ≤ (m : ℝ) ^ (u_search h x) := by positivity
  have hmb0 : (0 : ℝ) ≤ (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by positivity
  have hK : 55 * ((ℓ : ℝ) + 1) * paramPowConst ℓ C_base ≤
      (1 / 4 : ℝ) * (4000 * ((paramCostConst ℓ C_base : ℝ) + 1 +
        (paramPowConst ℓ C_base + 1) * ((ℓ : ℝ) + 1))) := by
    have hpc0 : 0 ≤ (paramCostConst ℓ C_base : ℝ) := Nat.cast_nonneg _
    have hℓ0 : 0 ≤ (ℓ : ℝ) := Nat.cast_nonneg ℓ
    nlinarith only [hp, hpc0, hℓ0]
  calc (cost : ℝ)
      ≤ 55 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) *
          (paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ 2) * (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) :=
        hcost_r.trans (mul_le_mul_of_nonneg_left hM₀_ub (by positivity))
    _ = (55 * ((ℓ : ℝ) + 1) * paramPowConst ℓ C_base) * (d + 1 : ℝ) * ((L + 1 : ℝ) ^ 2) *
          (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by ring
    _ ≤ ((1 / 4 : ℝ) * (4000 * ((paramCostConst ℓ C_base : ℝ) + 1 +
          (paramPowConst ℓ C_base + 1) * ((ℓ : ℝ) + 1)))) *
          ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
          ((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) := by
        refine mul_le_mul
          (mul_le_mul (mul_le_mul hK hXd (by positivity) (by positivity)) hXL
            (by positivity) (by positivity))
          (by linarith only [hmu0]) hmb0 (by positivity)
    _ = (1 / 4 : ℝ) * (((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
          polyFactor ℓ C_base d L) := by unfold polyFactor; ring

theorem update_cost_le_half {ℓ C_base d m M₀ Cap_u : ℕ} {h x : ℝ}
    (hM₀ : 1 ≤ M₀)
    (hM₀_ub : (M₀ : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength m + 1 : ℝ) ^ 2) *
      (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))
    (hCapu_ub : (Cap_u : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength m + 1 : ℝ) ^ (2 * ℓ)) *
      (m : ℝ) ^ (u_search h x))
    {cost : ℕ}
    (hcost : cost ≤ 100 + d * 30 + ℓ * 40 + ℓ * M₀ * (65 + d * 30) + Cap_u * (150 + ℓ * 60)) :
    (cost : ℝ) ≤
      (1 / 2 : ℝ) * (((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        polyFactor ℓ C_base d (natBitLength m)) := by
  let L := natBitLength m
  have hnat : cost ≤ 235 * (ℓ + 1) * (d + 1) * M₀ + 150 * (ℓ + 1) * (d + 1) * Cap_u := by
    have h1 : 100 + d * 30 + ℓ * 40 ≤ 140 * (ℓ + 1) * (d + 1) * M₀ := by
      have hbase : 100 + d * 30 + ℓ * 40 ≤ 140 * (ℓ + 1) * (d + 1) := by nlinarith
      calc 100 + d * 30 + ℓ * 40 ≤ 140 * (ℓ + 1) * (d + 1) * 1 := by omega
        _ ≤ 140 * (ℓ + 1) * (d + 1) * M₀ := Nat.mul_le_mul_left _ hM₀
    have h2 : ℓ * M₀ * (65 + d * 30) ≤ 95 * (ℓ + 1) * (d + 1) * M₀ := by
      have hb : 65 + d * 30 ≤ 95 * (d + 1) := by omega
      calc ℓ * M₀ * (65 + d * 30) ≤ ℓ * M₀ * (95 * (d + 1)) := Nat.mul_le_mul_left _ hb
        _ = 95 * ℓ * (d + 1) * M₀ := by ring
        _ ≤ 95 * (ℓ + 1) * (d + 1) * M₀ :=
          Nat.mul_le_mul_right M₀ (Nat.mul_le_mul_right (d + 1) (Nat.mul_le_mul_left 95 (by omega)))
    have h3 : Cap_u * (150 + ℓ * 60) ≤ 150 * (ℓ + 1) * (d + 1) * Cap_u := by
      have hb : 150 + ℓ * 60 ≤ 150 * (ℓ + 1) * (d + 1) := by nlinarith
      calc Cap_u * (150 + ℓ * 60) ≤ Cap_u * (150 * (ℓ + 1) * (d + 1)) := Nat.mul_le_mul_left _ hb
        _ = 150 * (ℓ + 1) * (d + 1) * Cap_u := by ring
    calc cost ≤ (100 + d * 30 + ℓ * 40) + ℓ * M₀ * (65 + d * 30) + Cap_u * (150 + ℓ * 60) := hcost
      _ ≤ 140 * (ℓ + 1) * (d + 1) * M₀ + 95 * (ℓ + 1) * (d + 1) * M₀ +
            150 * (ℓ + 1) * (d + 1) * Cap_u :=
          Nat.add_le_add (Nat.add_le_add h1 h2) h3
      _ = 235 * (ℓ + 1) * (d + 1) * M₀ + 150 * (ℓ + 1) * (d + 1) * Cap_u := by ring
  have hcost_r : (cost : ℝ) ≤
      235 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (M₀ : ℝ) +
      150 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (Cap_u : ℝ) := by
    exact_mod_cast hnat
  have hXd : (d + 1 : ℝ) ≤ ((d + 1 : ℝ) ^ (2 * ℓ + 6)) := by
    simpa using pow_le_pow_right₀
      (by have : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d; linarith only [this])
      (by omega : 1 ≤ 2 * ℓ + 6)
  have hXL2 : ((L + 1 : ℝ) ^ 2) ≤ ((L + 1 : ℝ) ^ (2 * ℓ + 6)) :=
    pow_le_pow_right₀ (by have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [this])
      (by omega)
  have hXLu : ((L + 1 : ℝ) ^ (2 * ℓ)) ≤ ((L + 1 : ℝ) ^ (2 * ℓ + 6)) :=
    pow_le_pow_right₀ (by have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [this])
      (by omega)
  have hp : 0 ≤ paramPowConst ℓ C_base := paramPowConst_nonneg ℓ C_base
  have hpc0 : 0 ≤ (paramCostConst ℓ C_base : ℝ) := Nat.cast_nonneg _
  have hℓ0 : 0 ≤ (ℓ : ℝ) := Nat.cast_nonneg ℓ
  set C_tot := ((paramCostConst ℓ C_base : ℝ) + 1 + (paramPowConst ℓ C_base + 1) * ((ℓ : ℝ) + 1))
  have hK : ((ℓ : ℝ) + 1) * paramPowConst ℓ C_base ≤ C_tot := by
    dsimp [C_tot]; nlinarith only [hp, hpc0, hℓ0]
  have ht1 : 235 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (M₀ : ℝ) ≤
      235 * C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
        (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
    calc 235 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (M₀ : ℝ)
        ≤ 235 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) *
            (paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ 2) * (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) :=
          mul_le_mul_of_nonneg_left hM₀_ub (by positivity)
      _ = 235 * (((ℓ : ℝ) + 1) * paramPowConst ℓ C_base) * (d + 1 : ℝ) * ((L + 1 : ℝ) ^ 2) *
            (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by ring
      _ ≤ 235 * C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
            (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
          refine mul_le_mul_of_nonneg_right ?_ (by positivity)
          exact mul_le_mul
            (mul_le_mul (mul_le_mul_of_nonneg_left hK (by norm_num)) hXd
              (by positivity) (by positivity))
            hXL2 (by positivity) (by positivity)
  have ht2 : 150 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (Cap_u : ℝ) ≤
      235 * C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
        (m : ℝ) ^ (u_search h x) := by
    have h150 : 150 * (((ℓ : ℝ) + 1) * paramPowConst ℓ C_base) ≤ 235 * C_tot := by
      have hK0 : 0 ≤ C_tot := by dsimp [C_tot]; positivity
      linarith only [hK, hK0]
    calc 150 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (Cap_u : ℝ)
        ≤ 150 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) *
            (paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (u_search h x)) :=
          mul_le_mul_of_nonneg_left hCapu_ub (by positivity)
      _ = (150 * (((ℓ : ℝ) + 1) * paramPowConst ℓ C_base)) * (d + 1 : ℝ) *
            ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (u_search h x) := by ring
      _ ≤ (235 * C_tot) * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
            (m : ℝ) ^ (u_search h x) := by
          refine mul_le_mul_of_nonneg_right ?_ (by positivity)
          exact mul_le_mul
            (mul_le_mul h150 hXd (by positivity) (by dsimp [C_tot]; positivity))
            hXLu (by positivity) (by dsimp [C_tot]; positivity)
  have hpoly_nn : 0 ≤ C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
      ((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) := by
    dsimp [C_tot]; positivity
  have hsum : (cost : ℝ) ≤
      235 * (C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
        ((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))) := by
    linarith only [hcost_r, ht1, ht2]
  have hrhs : (1 / 2 : ℝ) * (((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
      polyFactor ℓ C_base d L) =
      2000 * (C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
        ((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))) := by
    unfold polyFactor; dsimp [C_tot]; ring
  rw [hrhs]
  linarith only [hsum, hpoly_nn]

theorem query_cost_le_bound {ℓ C_base d m M₀ Cap_q r : ℕ} {h x : ℝ}
    (hM₀ : 1 ≤ M₀) (hCapq : 100 ≤ Cap_q) (hr : r ≤ Cap_q + 1)
    (hM₀_ub : (M₀ : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength m + 1 : ℝ) ^ 2) *
      (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))
    (hCapq_ub : (Cap_q : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength m + 1 : ℝ) ^ (2 * ℓ)) *
      (m : ℝ) ^ (q_search h x))
    {cost : ℕ}
    (hcost : cost ≤ 160 + d * 30 + ℓ * 40 + ℓ * M₀ * (65 + d * 30) + Cap_q * (130 + ℓ * 60)) :
    (cost + r : ℝ) ≤
      ((m : ℝ) ^ (q_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        polyFactor ℓ C_base d (natBitLength m) := by
  let L := natBitLength m
  have hnat : cost + r ≤ 300 * (ℓ + 1) * (d + 1) * M₀ + 150 * (ℓ + 1) * (d + 1) * Cap_q := by
    have h1 : 160 + d * 30 + ℓ * 40 ≤ 200 * (ℓ + 1) * (d + 1) * M₀ := by
      have hb : 160 + d * 30 + ℓ * 40 ≤ 200 * (ℓ + 1) * (d + 1) := by nlinarith
      calc 160 + d * 30 + ℓ * 40 ≤ 200 * (ℓ + 1) * (d + 1) * 1 := by omega
        _ ≤ 200 * (ℓ + 1) * (d + 1) * M₀ := Nat.mul_le_mul_left _ hM₀
    have h2 : ℓ * M₀ * (65 + d * 30) ≤ 95 * (ℓ + 1) * (d + 1) * M₀ := by
      have hb : 65 + d * 30 ≤ 95 * (d + 1) := by omega
      calc ℓ * M₀ * (65 + d * 30) ≤ ℓ * M₀ * (95 * (d + 1)) := Nat.mul_le_mul_left _ hb
        _ = 95 * ℓ * (d + 1) * M₀ := by ring
        _ ≤ 95 * (ℓ + 1) * (d + 1) * M₀ :=
          Nat.mul_le_mul_right M₀ (Nat.mul_le_mul_right (d + 1) (Nat.mul_le_mul_left 95 (by omega)))
    have h3 : Cap_q * (130 + ℓ * 60) + r ≤ 150 * (ℓ + 1) * (d + 1) * Cap_q := by
      have hr2 : r ≤ 2 * Cap_q := by omega
      have hb : 132 + ℓ * 60 ≤ 150 * (ℓ + 1) * (d + 1) := by nlinarith
      calc Cap_q * (130 + ℓ * 60) + r ≤ Cap_q * (130 + ℓ * 60) + 2 * Cap_q :=
            Nat.add_le_add_left hr2 _
        _ = Cap_q * (132 + ℓ * 60) := by ring
        _ ≤ Cap_q * (150 * (ℓ + 1) * (d + 1)) := Nat.mul_le_mul_left _ hb
        _ = 150 * (ℓ + 1) * (d + 1) * Cap_q := by ring
    have h295 : 200 * (ℓ + 1) * (d + 1) * M₀ + 95 * (ℓ + 1) * (d + 1) * M₀ ≤
        300 * (ℓ + 1) * (d + 1) * M₀ := by
      have ha : 200 * (ℓ + 1) * (d + 1) * M₀ + 95 * (ℓ + 1) * (d + 1) * M₀ =
          295 * ((ℓ + 1) * (d + 1) * M₀) := by ring
      have hb : 300 * (ℓ + 1) * (d + 1) * M₀ = 300 * ((ℓ + 1) * (d + 1) * M₀) := by ring
      rw [ha, hb]
      exact Nat.mul_le_mul_right _ (by decide)
    calc cost + r
        ≤ (160 + d * 30 + ℓ * 40) + ℓ * M₀ * (65 + d * 30) + (Cap_q * (130 + ℓ * 60) + r) := by
            omega
      _ ≤ (200 * (ℓ + 1) * (d + 1) * M₀ + 95 * (ℓ + 1) * (d + 1) * M₀) +
            150 * (ℓ + 1) * (d + 1) * Cap_q :=
          Nat.add_le_add (Nat.add_le_add h1 h2) h3
      _ ≤ 300 * (ℓ + 1) * (d + 1) * M₀ + 150 * (ℓ + 1) * (d + 1) * Cap_q :=
          Nat.add_le_add_right h295 _
  have hcost_r : (cost + r : ℝ) ≤
      300 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (M₀ : ℝ) +
      150 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (Cap_q : ℝ) := by
    exact_mod_cast hnat
  have hXd : (d + 1 : ℝ) ≤ ((d + 1 : ℝ) ^ (2 * ℓ + 6)) := by
    simpa using pow_le_pow_right₀
      (by have : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d; linarith only [this])
      (by omega : 1 ≤ 2 * ℓ + 6)
  have hXL2 : ((L + 1 : ℝ) ^ 2) ≤ ((L + 1 : ℝ) ^ (2 * ℓ + 6)) :=
    pow_le_pow_right₀ (by have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [this])
      (by omega)
  have hXLq : ((L + 1 : ℝ) ^ (2 * ℓ)) ≤ ((L + 1 : ℝ) ^ (2 * ℓ + 6)) :=
    pow_le_pow_right₀ (by have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [this])
      (by omega)
  have hp : 0 ≤ paramPowConst ℓ C_base := paramPowConst_nonneg ℓ C_base
  have hpc0 : 0 ≤ (paramCostConst ℓ C_base : ℝ) := Nat.cast_nonneg _
  have hℓ0 : 0 ≤ (ℓ : ℝ) := Nat.cast_nonneg ℓ
  set C_tot := ((paramCostConst ℓ C_base : ℝ) + 1 + (paramPowConst ℓ C_base + 1) * ((ℓ : ℝ) + 1))
  have hK : ((ℓ : ℝ) + 1) * paramPowConst ℓ C_base ≤ C_tot := by
    dsimp [C_tot]; nlinarith only [hp, hpc0, hℓ0]
  have ht1 : 300 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (M₀ : ℝ) ≤
      300 * C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
        (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
    calc 300 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (M₀ : ℝ)
        ≤ 300 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) *
            (paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ 2) * (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) :=
          mul_le_mul_of_nonneg_left hM₀_ub (by positivity)
      _ = 300 * (((ℓ : ℝ) + 1) * paramPowConst ℓ C_base) * (d + 1 : ℝ) * ((L + 1 : ℝ) ^ 2) *
            (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by ring
      _ ≤ 300 * C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
            (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
          refine mul_le_mul_of_nonneg_right ?_ (by positivity)
          exact mul_le_mul
            (mul_le_mul (mul_le_mul_of_nonneg_left hK (by norm_num)) hXd
              (by positivity) (by positivity))
            hXL2 (by positivity) (by positivity)
  have ht2 : 150 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (Cap_q : ℝ) ≤
      300 * C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
        (m : ℝ) ^ (q_search h x) := by
    have h150 : 150 * (((ℓ : ℝ) + 1) * paramPowConst ℓ C_base) ≤ 300 * C_tot := by
      have hK0 : 0 ≤ C_tot := by dsimp [C_tot]; positivity
      linarith only [hK, hK0]
    calc 150 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (Cap_q : ℝ)
        ≤ 150 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) *
            (paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (q_search h x)) :=
          mul_le_mul_of_nonneg_left hCapq_ub (by positivity)
      _ = (150 * (((ℓ : ℝ) + 1) * paramPowConst ℓ C_base)) * (d + 1 : ℝ) *
            ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (q_search h x) := by ring
      _ ≤ (300 * C_tot) * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
            (m : ℝ) ^ (q_search h x) := by
          refine mul_le_mul_of_nonneg_right ?_ (by positivity)
          exact mul_le_mul
            (mul_le_mul h150 hXd (by positivity) (by dsimp [C_tot]; positivity))
            hXLq (by positivity) (by dsimp [C_tot]; positivity)
  have hpoly_nn : 0 ≤ C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
      ((m : ℝ) ^ (q_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) := by
    dsimp [C_tot]; positivity
  have hsum : (cost + r : ℝ) ≤
      300 * (C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
        ((m : ℝ) ^ (q_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))) := by
    linarith only [hcost_r, ht1, ht2]
  have hrhs : ((m : ℝ) ^ (q_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
      polyFactor ℓ C_base d L =
      4000 * (C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
        ((m : ℝ) ^ (q_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))) := by
    unfold polyFactor; dsimp [C_tot]; ring
  rw [hrhs]
  linarith only [hsum, hpoly_nn]

theorem peakCellSpace_le_spaceBound {ℓ C_base d m M₀ Cap_u Cap_q : ℕ} {h x : ℝ}
    (hm : 1 ≤ m) (hM₀ : 1 ≤ M₀) (hCapu : 100 ≤ Cap_u)
    (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1)
    (hM₀_ub : (M₀ : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength m + 1 : ℝ) ^ 2) *
      (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))
    (hCapu_ub : (Cap_u : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength m + 1 : ℝ) ^ (2 * ℓ)) *
      (m : ℝ) ^ (u_search h x))
    (hCapq_sp : (Cap_q : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength m + 1 : ℝ) ^ (2 * ℓ)) *
      (m : ℝ) ^ (1 + u_search h x))
    {inp : ArithRAMInput d} {mem : ArithRAMMemory} {peak : ℕ}
    (hpeak : peak = inp.inputCellSpace + mem.cellCount)
    (hinp : inp.inputCellSpace ≤ 4 + m * (d + 1) + ℓ * M₀ * d + d)
    (hex : extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) mem ≤
      m * (9 * Cap_u + 3)) :
    (peak : ℝ) ≤
      ((m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
        polyFactor ℓ C_base d (natBitLength m) := by
  let L := natBitLength m
  have hcell : mem.cellCount ≤ Cap_q + ℓ * M₀ * (d + 1) + d + ℓ + 70 + m * (9 * Cap_u + 3) := by
    have h1 := cellCount_le_card_add_extraCells
      (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) mem
    have h2 := card_scratch_le d ℓ M₀ Cap_q
    omega
  have hnat : peak ≤
      100 * (ℓ + 1) * (d + 1) * M₀ + (d + 1) * Cap_q + (d + 1) * m + 12 * (d + 1) * (m * Cap_u) := by
    have hex12 : m * (9 * Cap_u + 3) ≤ 12 * (d + 1) * (m * Cap_u) := by
      have hcap : 9 * Cap_u + 3 ≤ 12 * Cap_u := by omega
      calc m * (9 * Cap_u + 3) ≤ m * (12 * Cap_u) := Nat.mul_le_mul_left m hcap
        _ = 12 * 1 * (m * Cap_u) := by ring
        _ ≤ 12 * (d + 1) * (m * Cap_u) :=
          Nat.mul_le_mul_right _ (Nat.mul_le_mul_left 12 (by omega))
    have hM_part : 4 + ℓ * M₀ * d + d + (ℓ * M₀ * (d + 1) + d + ℓ + 70) ≤
        100 * (ℓ + 1) * (d + 1) * M₀ := by
      have hb : 74 + 2 * d + ℓ ≤ 98 * (ℓ + 1) * (d + 1) := by nlinarith
      have hbM : 74 + 2 * d + ℓ ≤ 98 * (ℓ + 1) * (d + 1) * M₀ := by
        calc 74 + 2 * d + ℓ ≤ 98 * (ℓ + 1) * (d + 1) * 1 := by simpa using hb
          _ ≤ 98 * (ℓ + 1) * (d + 1) * M₀ := Nat.mul_le_mul_left _ hM₀
      have hMd : ℓ * M₀ * d + ℓ * M₀ * (d + 1) ≤ 2 * (ℓ + 1) * (d + 1) * M₀ := by
        calc ℓ * M₀ * d + ℓ * M₀ * (d + 1)
            ≤ ℓ * M₀ * (d + 1) + ℓ * M₀ * (d + 1) :=
              Nat.add_le_add_right (Nat.mul_le_mul_left _ (by omega)) _
          _ = 2 * ℓ * (d + 1) * M₀ := by ring
          _ ≤ 2 * (ℓ + 1) * (d + 1) * M₀ :=
              Nat.mul_le_mul_right M₀ (Nat.mul_le_mul_right (d + 1) (Nat.mul_le_mul_left 2 (by omega)))
      calc 4 + ℓ * M₀ * d + d + (ℓ * M₀ * (d + 1) + d + ℓ + 70)
          = (74 + 2 * d + ℓ) + (ℓ * M₀ * d + ℓ * M₀ * (d + 1)) := by ring
        _ ≤ 98 * (ℓ + 1) * (d + 1) * M₀ + 2 * (ℓ + 1) * (d + 1) * M₀ := Nat.add_le_add hbM hMd
        _ = 100 * (ℓ + 1) * (d + 1) * M₀ := by ring
    have hq_part : Cap_q ≤ (d + 1) * Cap_q := Nat.le_mul_of_pos_left Cap_q (by omega)
    have hm_part : m * (d + 1) = (d + 1) * m := Nat.mul_comm _ _
    omega
  have hpeak_r : (peak : ℝ) ≤
      100 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (M₀ : ℝ) +
      (d + 1 : ℝ) * (Cap_q : ℝ) +
      (d + 1 : ℝ) * (m : ℝ) +
      12 * (d + 1 : ℝ) * ((m : ℝ) * (Cap_u : ℝ)) := by
    exact_mod_cast hnat
  rcases I_h_bounds hh0 hh1 hx0 hx1 with ⟨_, _, hu0, _, _, _⟩
  have hm1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
  have hm_pos : (0 : ℝ) < (m : ℝ) := by positivity
  have hm_le_rpow : (m : ℝ) ≤ (m : ℝ) ^ (1 + u_search h x) := by
    calc (m : ℝ) = (m : ℝ) ^ (1 : ℝ) := (Real.rpow_one (m : ℝ)).symm
      _ ≤ (m : ℝ) ^ (1 + u_search h x) :=
        Real.rpow_le_rpow_of_exponent_le hm1 (by linarith only [hu0])
  have hm_mul_rpow : (m : ℝ) * (m : ℝ) ^ (u_search h x) = (m : ℝ) ^ (1 + u_search h x) := by
    rw [Real.rpow_add hm_pos 1 (u_search h x), Real.rpow_one]
  have hXd : (d + 1 : ℝ) ≤ ((d + 1 : ℝ) ^ (2 * ℓ + 6)) := by
    simpa using pow_le_pow_right₀
      (by have : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d; linarith only [this])
      (by omega : 1 ≤ 2 * ℓ + 6)
  have hXL1 : (1 : ℝ) ≤ ((L + 1 : ℝ) ^ (2 * ℓ + 6)) :=
    one_le_pow₀ (by have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [this])
  have hXL2 : ((L + 1 : ℝ) ^ 2) ≤ ((L + 1 : ℝ) ^ (2 * ℓ + 6)) :=
    pow_le_pow_right₀ (by have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [this])
      (by omega)
  have hXLu : ((L + 1 : ℝ) ^ (2 * ℓ)) ≤ ((L + 1 : ℝ) ^ (2 * ℓ + 6)) :=
    pow_le_pow_right₀ (by have : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L; linarith only [this])
      (by omega)
  have hp : 0 ≤ paramPowConst ℓ C_base := paramPowConst_nonneg ℓ C_base
  have hpc0 : 0 ≤ (paramCostConst ℓ C_base : ℝ) := Nat.cast_nonneg _
  have hℓ0 : 0 ≤ (ℓ : ℝ) := Nat.cast_nonneg ℓ
  set C_tot := ((paramCostConst ℓ C_base : ℝ) + 1 + (paramPowConst ℓ C_base + 1) * ((ℓ : ℝ) + 1))
  have hC1 : (1 : ℝ) ≤ C_tot := by dsimp [C_tot]; nlinarith only [hp, hpc0, hℓ0]
  have hKp : paramPowConst ℓ C_base ≤ C_tot := by
    dsimp [C_tot]; nlinarith only [hp, hpc0, hℓ0]
  have hKℓ : ((ℓ : ℝ) + 1) * paramPowConst ℓ C_base ≤ C_tot := by
    dsimp [C_tot]; nlinarith only [hp, hpc0, hℓ0]
  set P_base := C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6))
  have ht1 : 100 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (M₀ : ℝ) ≤
      100 * P_base * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
    calc 100 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) * (M₀ : ℝ)
        ≤ 100 * ((ℓ : ℝ) + 1) * (d + 1 : ℝ) *
            (paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ 2) * (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) :=
          mul_le_mul_of_nonneg_left hM₀_ub (by positivity)
      _ = (100 * (((ℓ : ℝ) + 1) * paramPowConst ℓ C_base)) * (d + 1 : ℝ) * ((L + 1 : ℝ) ^ 2) *
            (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by ring
      _ ≤ (100 * C_tot) * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
            (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
          refine mul_le_mul_of_nonneg_right ?_ (by positivity)
          have h100 : 100 * (((ℓ : ℝ) + 1) * paramPowConst ℓ C_base) ≤ 100 * C_tot :=
            mul_le_mul_of_nonneg_left hKℓ (by norm_num)
          exact mul_le_mul
            (mul_le_mul h100 hXd (by positivity) (by positivity))
            hXL2 (by positivity) (by positivity)
      _ = 100 * P_base * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by dsimp [P_base]; ring
  have ht2 : (d + 1 : ℝ) * (Cap_q : ℝ) ≤ P_base * (m : ℝ) ^ (1 + u_search h x) := by
    calc (d + 1 : ℝ) * (Cap_q : ℝ)
        ≤ (d + 1 : ℝ) *
            (paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (1 + u_search h x)) :=
          mul_le_mul_of_nonneg_left hCapq_sp (by positivity)
      _ = paramPowConst ℓ C_base * (d + 1 : ℝ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
            (m : ℝ) ^ (1 + u_search h x) := by ring
      _ ≤ P_base * (m : ℝ) ^ (1 + u_search h x) := by
          dsimp [P_base]
          refine mul_le_mul_of_nonneg_right ?_ (by positivity)
          exact mul_le_mul (mul_le_mul hKp hXd (by positivity) (by positivity))
            hXLu (by positivity) (by positivity)
  have ht3 : (d + 1 : ℝ) * (m : ℝ) ≤ P_base * (m : ℝ) ^ (1 + u_search h x) := by
    calc (d + 1 : ℝ) * (m : ℝ)
        = 1 * (d + 1 : ℝ) * 1 * (m : ℝ) := by ring
      _ ≤ C_tot * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
            (m : ℝ) ^ (1 + u_search h x) := by
          refine mul_le_mul
            (mul_le_mul (mul_le_mul hC1 hXd (by positivity) (by positivity))
              hXL1 zero_le_one (by positivity))
            hm_le_rpow (Nat.cast_nonneg m) (by positivity)
  have ht4 : 12 * (d + 1 : ℝ) * ((m : ℝ) * (Cap_u : ℝ)) ≤
      12 * P_base * (m : ℝ) ^ (1 + u_search h x) := by
    calc 12 * (d + 1 : ℝ) * ((m : ℝ) * (Cap_u : ℝ))
        ≤ 12 * (d + 1 : ℝ) * ((m : ℝ) *
            (paramPowConst ℓ C_base * ((L + 1 : ℝ) ^ (2 * ℓ)) * (m : ℝ) ^ (u_search h x))) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul_of_nonneg_left hCapu_ub (Nat.cast_nonneg m)) (by positivity)
      _ = 12 * paramPowConst ℓ C_base * (d + 1 : ℝ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
            ((m : ℝ) * (m : ℝ) ^ (u_search h x)) := by ring
      _ = (12 * paramPowConst ℓ C_base) * (d + 1 : ℝ) * ((L + 1 : ℝ) ^ (2 * ℓ)) *
            (m : ℝ) ^ (1 + u_search h x) := by rw [hm_mul_rpow]
      _ ≤ (12 * C_tot) * ((d + 1 : ℝ) ^ (2 * ℓ + 6)) * ((L + 1 : ℝ) ^ (2 * ℓ + 6)) *
            (m : ℝ) ^ (1 + u_search h x) := by
          refine mul_le_mul_of_nonneg_right ?_ (by positivity)
          exact mul_le_mul
            (mul_le_mul (mul_le_mul_of_nonneg_left hKp (by norm_num)) hXd
              (by positivity) (by positivity))
            hXLu (by positivity) (by positivity)
      _ = 12 * P_base * (m : ℝ) ^ (1 + u_search h x) := by dsimp [P_base]; ring
  have hP_nn : 0 ≤ P_base * ((m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) := by
    dsimp [P_base, C_tot]; positivity
  have hsum : (peak : ℝ) ≤
      100 * (P_base * ((m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))) := by
    have h1u : 0 ≤ P_base * (m : ℝ) ^ (1 + u_search h x) := by dsimp [P_base, C_tot]; positivity
    have hIb : 0 ≤ P_base * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by dsimp [P_base, C_tot]; positivity
    linarith only [hpeak_r, ht1, ht2, ht3, ht4, h1u, hIb]
  have hrhs : ((m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) *
      polyFactor ℓ C_base d L =
      4000 * (P_base * ((m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ)))) := by
    unfold polyFactor; dsimp [P_base, C_tot]; ring
  rw [hrhs]
  linarith only [hsum, hP_nn]

/-! ### 2. Deterministic RAM step iterators and active-set combinatorics -/

noncomputable def nextMem {d : ℕ} (s : ArithRAMStmt) (inp : ArithRAMInput d)
    (mem : ArithRAMMemory) : ArithRAMMemory :=
  match runArithRAMWithBits s inp mem [] with
  | some out => out.mem
  | none => mem

theorem nextMem_of_some {d : ℕ} {s : ArithRAMStmt} {inp : ArithRAMInput d}
    {mem : ArithRAMMemory} {out : ArithRAMExecOutcome}
    (h : runArithRAMWithBits s inp mem [] = some out) :
    nextMem s inp mem = out.mem := by
  simp [nextMem, h]

def actPrefix (m j : ℕ) : Finset (Fin m) :=
  Finset.univ.filter (fun k : Fin m => k.1 < j)

theorem actPrefix_zero (m : ℕ) : actPrefix m 0 = ∅ := by
  ext k; simp [actPrefix]

theorem actPrefix_self (m : ℕ) : actPrefix m m = Finset.univ := by
  ext k; simp [actPrefix]

theorem notMem_actPrefix {m j : ℕ} (hj : j < m) : ⟨j, hj⟩ ∉ actPrefix m j := by
  simp [actPrefix]

theorem insert_actPrefix {m j : ℕ} (hj : j < m) :
    insert ⟨j, hj⟩ (actPrefix m j) = actPrefix m (j + 1) := by
  ext k
  simp only [actPrefix, Finset.mem_insert, Finset.mem_filter, Finset.mem_univ, true_and,
    Fin.ext_iff]
  omega

theorem mem_take_succ_iff {α : Type*} :
    ∀ (xs : List α) (s : ℕ) (_ : s < xs.length) (x : α),
      x ∈ xs.take (s + 1) ↔ x ∈ xs.take s ∨ x = xs[s]
  | [], _, hs, _ => by simp at hs
  | _ :: _, 0, _, _ => by simp [eq_comm]
  | _ :: xs, s + 1, hs, x => by
      simp only [List.take_succ_cons, List.mem_cons, List.getElem_cons_succ]
      rw [mem_take_succ_iff xs s (Nat.lt_of_succ_lt_succ hs) x]
      tauto

def actAfterDel {m : ℕ} (dels : List (Fin m)) (s : ℕ) : Finset (Fin m) :=
  open Classical in Finset.univ.filter (fun k : Fin m => k ∉ dels.take s)

theorem actAfterDel_zero {m : ℕ} (dels : List (Fin m)) : actAfterDel dels 0 = Finset.univ := by
  ext k; simp [actAfterDel]

theorem erase_actAfterDel {m : ℕ} (dels : List (Fin m)) {s : ℕ} (hs : s < dels.length) :
    (actAfterDel dels s).erase (dels.get ⟨s, hs⟩) = actAfterDel dels (s + 1) := by
  classical
  ext k
  simp only [actAfterDel, Finset.mem_erase, Finset.mem_filter, Finset.mem_univ, true_and,
    List.get_eq_getElem, mem_take_succ_iff dels s hs k, not_or]
  exact and_comm

theorem actAfterDel_length {m : ℕ} (dels : List (Fin m)) :
    actAfterDel dels dels.length = Finset.univ.filter (fun k : Fin m => k ∉ dels) := by
  classical
  simp [actAfterDel]

/-! ### 3. Main body after `pOut` (with `K` generalized so `subst hK` aligns `Fin K` and `Fin (ℓ * M₀)`) -/

theorem mainAfterPOut {d ℓ C_base M₀ Cap_u Cap_q : ℕ}
    (hℓ : 1 ≤ ℓ)
    (hM₀ : 1 ≤ M₀) (hCapu : 100 ≤ Cap_u) (hCapq : 100 ≤ Cap_q)
    {c_h : ℝ}
    {ι : Type} (gen : SearchGeneration ι d) (enum : Fin gen.m ≃ ↥gen.P₀)
    {x t : ℝ} (hx0 : gen.h ≤ x) (hx1 : x ≤ 1)
    (hprobs_inst : ∃ p_u p_q p₁ p₂ : ℝ,
      IsGaussianFilterProbs d gen.h x t p_u p_q p₁ p₂ ∧
      p_u ≤ Real.exp (-(t ^ 2 / 2)) ∧
      p_q ≤ Real.exp (-(x ^ 2 * t ^ 2 / 2)) ∧
      c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h gen.h x * t ^ 2 / 2)) ≤ p₁ ∧
      p₂ ≤ Real.exp (-((1 + x ^ 2) * t ^ 2 / 2)))
    (pOut : ArithRAMExecOutcome)
    (hfpP : InParamFootprint pOut.mem)
    (hcP : CleanMem pOut.mem)
    (hw10 : wRead pOut.mem 1 0 = (gen.m : ℤ))
    (hw11 : wRead pOut.mem 1 1 = (M₀ : ℤ))
    (hw12 : wRead pOut.mem 1 2 = ((ℓ * M₀ : ℕ) : ℤ))
    (hw13 : wRead pOut.mem 1 3 = (Cap_u : ℤ))
    (hw14 : wRead pOut.mem 1 4 = (Cap_q : ℤ))
    (hr10 : rRead pOut.mem 1 0 = t)
    (hr11 : rRead pOut.mem 1 1 = x * t)
    (hpOut_cost_qtr : (pOut.unitCost : ℝ) ≤
      (1 / 4 : ℝ) * (((gen.m : ℝ) ^ (u_search gen.h x) + (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) *
        polyFactor ℓ C_base d (natBitLength gen.m)))
    (hM₀_ub : (M₀ : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength gen.m + 1 : ℝ) ^ 2) *
      (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ)))
    (hCapu_ub : (Cap_u : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength gen.m + 1 : ℝ) ^ (2 * ℓ)) *
      (gen.m : ℝ) ^ (u_search gen.h x))
    (hCapq_ub : (Cap_q : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength gen.m + 1 : ℝ) ^ (2 * ℓ)) *
      (gen.m : ℝ) ^ (q_search gen.h x))
    (hCapq_sp : (Cap_q : ℝ) ≤ paramPowConst ℓ C_base * ((natBitLength gen.m + 1 : ℝ) ^ (2 * ℓ)) *
      (gen.m : ℝ) ^ (1 + u_search gen.h x))
    (hprob_ineqs : ∀ (p_u p_q p₁ p₂ : ℝ),
      0 ≤ p_u → 0 ≤ p_q → 0 ≤ p₂ →
      p_u ≤ Real.exp (-(t ^ 2 / 2)) →
      p_q ≤ Real.exp (-(x ^ 2 * t ^ 2 / 2)) →
      c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h gen.h x * t ^ 2 / 2)) ≤ p₁ →
      p₂ ≤ Real.exp (-((1 + x ^ 2) * t ^ 2 / 2)) →
      0 < p₁ ∧
      Real.log (100 * (ℓ : ℝ)) ≤ p₁ * (M₀ : ℝ) ∧
      100 * ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ + 1) ≤ (Cap_u : ℝ) ∧
      100 * ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ + 1) ≤ (Cap_q : ℝ) ∧
      100 * ((gen.m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ + 1) ≤ (Cap_q : ℝ))
    (K : ℕ) (hK : K = ℓ * M₀) :
    let m : ℕ := gen.m
    let h : ℝ := gen.h
    let poly : ℝ := polyFactor ℓ C_base d (natBitLength m)
    let u : ℝ := u_search h x
    let q_exp : ℝ := q_search h x
    let base_exp : ℝ := I_h h x / (ℓ : ℝ)
    let dataWorkBound : ℝ := ((m : ℝ) ^ u + (m : ℝ) ^ base_exp) * poly
    let queryWorkBound : ℝ := ((m : ℝ) ^ q_exp + (m : ℝ) ^ base_exp) * poly
    let spaceBound : ℝ := ((m : ℝ) ^ (1 + u) + (m : ℝ) ^ base_exp) * poly
    let poolCoords : ℕ → EuclideanSpace ℝ (Fin d) :=
      fun k => if hk : k < m then gen.pts (enum ⟨k, hk⟩).1 else 0
    let survivingHandles : List (Fin m) → Finset (Fin m) :=
      fun dels => Finset.univ.filter (fun k => k ∉ dels)
    let survivingSet : List (Fin m) → Finset ι :=
      fun dels => open Classical in (survivingHandles dels).image (fun k => (enum k).1)
    let decodeCandidates : ArithRAMMemory → List ι :=
      fun qMem =>
        let r : ℕ := (qMem.words.read (.heap 0 0)).toNat
        (List.range r).filterMap (fun idx =>
          let h_z := qMem.words.read (.heap 0 ((idx : ℤ) + 1))
          if hh : 0 ≤ h_z ∧ h_z.toNat < m then
            some (enum ⟨h_z.toNat, hh.2⟩).1
          else
            none)
    let queryAnswer : ArithRAMMemory → (ι → Prop) → Option ι :=
      fun qMem accept =>
        open Classical in (decodeCandidates qMem).find? (fun i => decide (accept i))
    let μ : MeasureTheory.Measure (Fin K → EuclideanSpace ℝ (Fin d)) :=
      MeasureTheory.Measure.pi (fun _ : Fin K => stdGaussianMeasure d)
    let gaussianReals : (Fin K → EuclideanSpace ℝ (Fin d)) → List ℝ :=
      fun ω =>
        (List.finRange K).flatMap (fun k =>
          List.ofFn (fun c : Fin d => euclideanCoord (ω k) c))
    let validBuildTrace :
        (Fin K → EuclideanSpace ℝ (Fin d)) → ArithRAMMemory → Prop :=
      fun ω builtMem =>
        ∃ (initOut : ArithRAMExecOutcome)
          (insMem : Fin (m + 1) → ArithRAMMemory)
          (insOut : Fin m → ArithRAMExecOutcome),
          runArithRAMWithBits initStmt
            ({ intParams := [(m : ℤ), (K : ℤ)]
               activeHandles := ∅
               activeCoords := fun _ => 0
               extraReals := h :: x :: gaussianReals ω } : ArithRAMInput d)
            pOut.mem [] = some initOut ∧
          (initOut.unitCost : ℝ) ≤ dataWorkBound ∧
          (initOut.peakCellSpace : ℝ) ≤ spaceBound ∧
          insMem 0 = initOut.mem ∧
          (∀ k : Fin m,
            runArithRAMWithBits (insertStmt ℓ)
              ({ intParams := [(k.1 : ℤ)]
                 activeHandles := Finset.range (k.1 + 1)
                 activeCoords := poolCoords
                 extraReals := [] } : ArithRAMInput d)
              (insMem k.castSucc) [] = some (insOut k) ∧
            insMem k.succ = (insOut k).mem ∧
            ((insOut k).unitCost : ℝ) ≤ dataWorkBound ∧
            ((insOut k).peakCellSpace : ℝ) ≤ spaceBound) ∧
          ((pOut.unitCost + initOut.unitCost +
              ∑ k : Fin m, (insOut k).unitCost : ℝ) ≤ (m : ℝ) * dataWorkBound) ∧
          builtMem = insMem (Fin.last m)
    let validDeleteTrace :
        ArithRAMMemory → List (Fin m) → ArithRAMMemory → Prop :=
      fun builtMem dels finalMem =>
        ∃ (delMem : Fin (dels.length + 1) → ArithRAMMemory)
          (delOut : Fin dels.length → ArithRAMExecOutcome),
          delMem 0 = builtMem ∧
          (∀ step : Fin dels.length,
            let activeAfter : Finset ℕ :=
              (Finset.univ.filter
                (fun k : Fin m => k ∉ dels.take (step.1 + 1))).image Fin.val
            runArithRAMWithBits deleteStmt
              ({ intParams := [((dels.get step).1 : ℤ)]
                 activeHandles := activeAfter
                 activeCoords := poolCoords
                 extraReals := [] } : ArithRAMInput d)
              (delMem step.castSucc) [] = some (delOut step) ∧
            delMem step.succ = (delOut step).mem ∧
            ((delOut step).unitCost : ℝ) ≤ dataWorkBound ∧
            ((delOut step).peakCellSpace : ℝ) ≤ spaceBound) ∧
          finalMem = delMem (Fin.last dels.length)
    let validQueryRun :
        ArithRAMMemory → List (Fin m) → EuclideanSpace ℝ (Fin d) →
          ArithRAMExecOutcome → Prop :=
      fun finalMem dels z qOut =>
        runArithRAMWithBits (queryStmt ℓ)
          ({ intParams := []
             activeHandles := (survivingHandles dels).image Fin.val
             activeCoords := poolCoords
             extraReals := List.ofFn (fun c : Fin d => euclideanCoord z c) } :
            ArithRAMInput d)
          finalMem [] = some qOut ∧
        (qOut.peakCellSpace : ℝ) ≤ spaceBound ∧
        0 ≤ qOut.mem.words.read (.heap 0 0) ∧
        let r : ℕ := (qOut.mem.words.read (.heap 0 0)).toNat
        ((qOut.unitCost + r : ℝ) ≤ queryWorkBound) ∧
        (∀ idx : ℕ, idx < r →
          let h_z := qOut.mem.words.read (.heap 0 ((idx : ℤ) + 1))
          0 ≤ h_z ∧ h_z.toNat ∈ (survivingHandles dels).image Fin.val)
    (∀ ω : Fin K → EuclideanSpace ℝ (Fin d),
      ∃ builtMem : ArithRAMMemory,
        validBuildTrace ω builtMem ∧
        ∀ (dels : List (Fin m)), dels.Nodup →
          ∃ finalMem : ArithRAMMemory,
            validDeleteTrace builtMem dels finalMem ∧
            ∀ (z : EuclideanSpace ℝ (Fin d)), IsUnitVec z →
              ∃ qOut : ArithRAMExecOutcome,
                validQueryRun finalMem dels z qOut ∧
                ∀ (q : SearchQuery ι d), q.z = z →
                  q.IsValidAnswer (survivingSet dels) (queryAnswer qOut.mem q.accept)) ∧
    (∀ (z : EuclideanSpace ℝ (Fin d)), IsUnitVec z →
      ∀ (i_star : ι), IsSearchTarget gen.pts gen.P₀ h z i_star →
        ∃ E : Set (Fin K → EuclideanSpace ℝ (Fin d)),
          MeasurableSet E ∧
          (9 / 10 : ℝ) ≤ μ.real E ∧
          ∀ ω ∈ E,
            ∀ (builtMem : ArithRAMMemory), validBuildTrace ω builtMem →
              ∀ (dels : List (Fin m)), dels.Nodup →
                let P_cur := survivingSet dels
                i_star ∈ P_cur →
                  ∀ (finalMem : ArithRAMMemory),
                    validDeleteTrace builtMem dels finalMem →
                    ∀ (qOut : ArithRAMExecOutcome),
                      validQueryRun finalMem dels z qOut →
                      ∀ (q : SearchQuery ι d), q.z = z → gen.IsCompatible P_cur q →
                        let ans := queryAnswer qOut.mem q.accept
                        ans ≠ none ∧ gen.IsCorrectAnswer P_cur q ans) := by
  classical
  subst hK
  dsimp only
  let m : ℕ := gen.m
  let h : ℝ := gen.h
  have hm : 1 ≤ m := Finset.card_pos.mpr gen.nonempty
  have hh0 : 0 < h := gen.h_pos
  have hh1 : h < 1 := gen.h_lt_one
  let ptsK : Fin m → EuclideanSpace ℝ (Fin d) := fun k => gen.pts (enum k).1
  let poolCoords : ℕ → EuclideanSpace ℝ (Fin d) :=
    fun k => if hk : k < m then gen.pts (enum ⟨k, hk⟩).1 else 0
  let SW := scratchWords ℓ M₀ Cap_q
  let SR := scratchReals d ℓ M₀
  let poly : ℝ := polyFactor ℓ C_base d (natBitLength m)
  let dataWorkBound : ℝ :=
    ((m : ℝ) ^ (u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) * poly
  let queryWorkBound : ℝ :=
    ((m : ℝ) ^ (q_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) * poly
  let spaceBound : ℝ :=
    ((m : ℝ) ^ (1 + u_search h x) + (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) * poly
  have hdwb_nn : 0 ≤ dataWorkBound := by
    have hp := polyFactor_nonneg ℓ C_base d (natBitLength m)
    dsimp only [dataWorkBound, poly]
    positivity
  have hpool_eq : ∀ k : Fin m, poolCoords k.1 = ptsK k := by
    intro k
    simp [poolCoords, k.2, ptsK]

  -- Input builders matching `S_lem_6_3`
  let gaussianReals : (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) → List ℝ :=
    fun ω =>
      (List.finRange (ℓ * M₀)).flatMap (fun k =>
        List.ofFn (fun c : Fin d => euclideanCoord (ω k) c))
  let initInp : (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) → ArithRAMInput d :=
    fun ω =>
      { intParams := [(m : ℤ), ((ℓ * M₀ : ℕ) : ℤ)]
        activeHandles := ∅
        activeCoords := fun _ => 0
        extraReals := h :: x :: gaussianReals ω }
  let insInp : Fin m → ArithRAMInput d :=
    fun k =>
      { intParams := [(k.1 : ℤ)]
        activeHandles := Finset.range (k.1 + 1)
        activeCoords := poolCoords
        extraReals := [] }
  let delInp : ∀ (dels : List (Fin m)), Fin dels.length → ArithRAMInput d :=
    fun dels step =>
      { intParams := [((dels.get step).1 : ℤ)]
        activeHandles :=
          (Finset.univ.filter (fun k : Fin m => k ∉ dels.take (step.1 + 1))).image Fin.val
        activeCoords := poolCoords
        extraReals := [] }
  let qInp : List (Fin m) → EuclideanSpace ℝ (Fin d) → ArithRAMInput d :=
    fun dels z =>
      { intParams := []
        activeHandles := (Finset.univ.filter (fun k : Fin m => k ∉ dels)).image Fin.val
        activeCoords := poolCoords
        extraReals := List.ofFn (fun c : Fin d => euclideanCoord z c) }

  -- Input cell space bounds for all 4 runtime phases
  have hlen_gauss : ∀ ω, (gaussianReals ω).length = (ℓ * M₀) * d := by
    intro ω
    dsimp only [gaussianReals]
    have hmap : ((List.finRange (ℓ * M₀)).map
        (fun k => (List.ofFn (fun c : Fin d => euclideanCoord (ω k) c)).length)) =
        List.replicate (ℓ * M₀) d := by
      rw [List.eq_replicate_iff]
      refine ⟨by simp, ?_⟩
      intro len hmem
      rcases List.mem_map.mp hmem with ⟨k, _, rfl⟩
      simp
    rw [List.length_flatMap, hmap, List.sum_replicate, smul_eq_mul]
  have hinp_init : ∀ ω, (initInp ω).inputCellSpace ≤ 4 + m * (d + 1) + ℓ * M₀ * d + d := by
    intro ω
    simp only [initInp, ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil,
      Finset.card_empty, zero_mul, hlen_gauss ω]
    omega
  have hinp_ins : ∀ k : Fin m, (insInp k).inputCellSpace ≤ 4 + m * (d + 1) + ℓ * M₀ * d + d := by
    intro k
    simp only [insInp, ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil,
      Finset.card_range]
    have hk_le : (k.1 + 1) * (d + 1) ≤ m * (d + 1) := Nat.mul_le_mul_right (d + 1) k.2
    omega
  have hinp_del : ∀ (dels : List (Fin m)) (step : Fin dels.length),
      (delInp dels step).inputCellSpace ≤ 4 + m * (d + 1) + ℓ * M₀ * d + d := by
    intro dels step
    simp only [delInp, ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil]
    have hcard : ((Finset.univ.filter (fun k : Fin m => k ∉ dels.take (step.1 + 1))).image Fin.val).card ≤ m :=
      Finset.card_image_le.trans
        ((Finset.card_le_card (Finset.subset_univ _)).trans (by simp [m]))
    have hmul : ((Finset.univ.filter (fun k : Fin m => k ∉ dels.take (step.1 + 1))).image Fin.val).card * (d + 1) ≤
        m * (d + 1) := Nat.mul_le_mul_right (d + 1) hcard
    omega
  have hinp_q : ∀ (dels : List (Fin m)) (z : EuclideanSpace ℝ (Fin d)),
      (qInp dels z).inputCellSpace ≤ 4 + m * (d + 1) + ℓ * M₀ * d + d := by
    intro dels z
    simp only [qInp, ArithRAMInput.inputCellSpace, List.length_nil, List.length_ofFn]
    have hcard : ((Finset.univ.filter (fun k : Fin m => k ∉ dels)).image Fin.val).card ≤ m :=
      Finset.card_image_le.trans
        ((Finset.card_le_card (Finset.subset_univ _)).trans (by simp [m]))
    have hmul : ((Finset.univ.filter (fun k : Fin m => k ∉ dels)).image Fin.val).card * (d + 1) ≤
        m * (d + 1) := Nat.mul_le_mul_right (d + 1) hcard
    omega

  -- Canonical build sequence for any `ω`
  have hBuild : ∀ ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d),
      ∃ builtMem : ArithRAMMemory,
        -- validBuildTrace
        (∃ (initOut : ArithRAMExecOutcome)
           (insMem : Fin (m + 1) → ArithRAMMemory)
           (insOut : Fin m → ArithRAMExecOutcome),
           runArithRAMWithBits initStmt (initInp ω) pOut.mem [] = some initOut ∧
           (initOut.unitCost : ℝ) ≤ dataWorkBound ∧
           (initOut.peakCellSpace : ℝ) ≤ spaceBound ∧
           insMem 0 = initOut.mem ∧
           (∀ k : Fin m,
             runArithRAMWithBits (insertStmt ℓ) (insInp k) (insMem k.castSucc) [] = some (insOut k) ∧
             insMem k.succ = (insOut k).mem ∧
             ((insOut k).unitCost : ℝ) ≤ dataWorkBound ∧
             ((insOut k).peakCellSpace : ℝ) ≤ spaceBound) ∧
           ((pOut.unitCost + initOut.unitCost +
               ∑ k : Fin m, (insOut k).unitCost : ℝ) ≤ (m : ℝ) * dataWorkBound) ∧
           builtMem = insMem (Fin.last m)) ∧
        -- Uniqueness: any validBuildTrace produces this exact `builtMem`
        (∀ bm', (∃ (initOut : ArithRAMExecOutcome)
           (insMem : Fin (m + 1) → ArithRAMMemory)
           (insOut : Fin m → ArithRAMExecOutcome),
           runArithRAMWithBits initStmt (initInp ω) pOut.mem [] = some initOut ∧
           (initOut.unitCost : ℝ) ≤ dataWorkBound ∧
           (initOut.peakCellSpace : ℝ) ≤ spaceBound ∧
           insMem 0 = initOut.mem ∧
           (∀ k : Fin m,
             runArithRAMWithBits (insertStmt ℓ) (insInp k) (insMem k.castSucc) [] = some (insOut k) ∧
             insMem k.succ = (insOut k).mem ∧
             ((insOut k).unitCost : ℝ) ≤ dataWorkBound ∧
             ((insOut k).peakCellSpace : ℝ) ≤ spaceBound) ∧
           ((pOut.unitCost + initOut.unitCost +
               ∑ k : Fin m, (insOut k).unitCost : ℝ) ≤ (m : ℝ) * dataWorkBound) ∧
           bm' = insMem (Fin.last m)) → bm' = builtMem) ∧
        IndexInv hM₀ x t Cap_u Cap_q ω ptsK Finset.univ builtMem ∧
        extraCells SW SR builtMem ≤ m * (5 * Cap_u + 2) := by
    intro ω
    rcases exec_initStmt (Cap_q := Cap_q) hM₀ (h := h) ω ptsK hcP hfpP
      hw10 hw11 hw12 hw13 hw14 hr10 hr11 with ⟨cInitMem, hInitExec, hexInit, hInvInit⟩
    rcases hInitExec.to_run with ⟨cInitOut, hInitRun, hInitMemEq, hInitCost, hInitPeak⟩
    rw [← hInitMemEq] at hexInit hInvInit hInitPeak
    have hInitQtr : (cInitOut.unitCost : ℝ) ≤ (1 / 4 : ℝ) * dataWorkBound :=
      init_cost_le_quarter hM₀ hM₀_ub hInitCost
    have hInitCost_le : (cInitOut.unitCost : ℝ) ≤ dataWorkBound := by
      linarith only [hInitQtr, hdwb_nn]
    have hInitSpace_le : (cInitOut.peakCellSpace : ℝ) ≤ spaceBound :=
      peakCellSpace_le_spaceBound hm hM₀ hCapu hh0 hh1 hx0 hx1 hM₀_ub hCapu_ub hCapq_sp
        hInitPeak (hinp_init ω) (by rw [hexInit]; exact Nat.zero_le _)

    let buildSeq : ℕ → ArithRAMMemory := fun j =>
      Nat.rec cInitOut.mem
        (fun i acc => if hi : i < m then nextMem (insertStmt ℓ) (insInp ⟨i, hi⟩) acc else acc) j
    have hBuildSeq : ∀ j ≤ m,
        IndexInv hM₀ x t Cap_u Cap_q ω ptsK (actPrefix m j) (buildSeq j) ∧
        extraCells SW SR (buildSeq j) ≤ j * (5 * Cap_u + 2) := by
      intro j
      induction j with
      | zero =>
          intro _
          rw [actPrefix_zero]
          refine ⟨hInvInit, ?_⟩
          change extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) cInitOut.mem ≤
            0 * (5 * Cap_u + 2)
          rw [hexInit]
          exact Nat.zero_le _
      | succ j ih =>
          intro hj_le
          have hj_lt : j < m := by omega
          rcases ih (by omega) with ⟨hInv_j, hex_j⟩
          let kj : Fin m := ⟨j, hj_lt⟩
          rcases exec_insertStmt hM₀ ω ptsK (notMem_actPrefix hj_lt) (insInp kj)
            rfl (Finset.mem_range.mpr (Nat.lt_succ_self j)) (hpool_eq kj) hInv_j with
            ⟨mem_next, hInsExec, hex_next, hInv_next⟩
          rcases hInsExec.to_run with ⟨out_j, hInsRun, hMemEq, _, _⟩
          have hstep_eq : buildSeq (j + 1) = mem_next := by
            change (if hi : j < m then nextMem (insertStmt ℓ) (insInp ⟨j, hi⟩) (buildSeq j)
              else buildSeq j) = mem_next
            rw [dif_pos hj_lt, nextMem_of_some hInsRun, hMemEq]
          rw [hstep_eq, ← insert_actPrefix hj_lt]
          refine ⟨hInv_next, ?_⟩
          dsimp only [SW, SR] at hex_j ⊢
          calc extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) mem_next
              ≤ extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) (buildSeq j) +
                  (5 * Cap_u + 2) := hex_next
            _ ≤ j * (5 * Cap_u + 2) + (5 * Cap_u + 2) := Nat.add_le_add_right hex_j _
            _ = (j + 1) * (5 * Cap_u + 2) := by ring

    have hStepOut : ∀ k : Fin m,
        ∃ out : ArithRAMExecOutcome,
          runArithRAMWithBits (insertStmt ℓ) (insInp k) (buildSeq k.1) [] = some out ∧
          buildSeq (k.1 + 1) = out.mem ∧
          (out.unitCost : ℝ) ≤ (1 / 2 : ℝ) * dataWorkBound ∧
          (out.peakCellSpace : ℝ) ≤ spaceBound := by
      intro k
      rcases hBuildSeq k.1 (Nat.le_of_lt k.2) with ⟨hInv_k, hex_k⟩
      rcases exec_insertStmt hM₀ ω ptsK (notMem_actPrefix k.2) (insInp k)
        rfl (Finset.mem_range.mpr (Nat.lt_succ_self k.1)) (hpool_eq k) hInv_k with
        ⟨mem_next, hInsExec, hex_next, _⟩
      rcases hInsExec.to_run with ⟨out, hRun, hMemEq, hCost, hPeak⟩
      have hseq_eq : buildSeq (k.1 + 1) = out.mem := by
        change (if hi : k.1 < m then nextMem (insertStmt ℓ) (insInp ⟨k.1, hi⟩) (buildSeq k.1)
          else buildSeq k.1) = out.mem
        rw [dif_pos k.2, nextMem_of_some hRun]
      have hCostHalf : (out.unitCost : ℝ) ≤ (1 / 2 : ℝ) * dataWorkBound :=
        update_cost_le_half hM₀ hM₀_ub hCapu_ub hCost
      have hex_bound : extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) mem_next ≤
          m * (9 * Cap_u + 3) := by
        dsimp only [SW, SR] at hex_k
        have hk1 : k.1 + 1 ≤ m := k.2
        have h1 : (k.1 + 1) * (5 * Cap_u + 2) ≤ m * (5 * Cap_u + 2) :=
          Nat.mul_le_mul_right _ hk1
        have h2 : m * (5 * Cap_u + 2) ≤ m * (9 * Cap_u + 3) :=
          Nat.mul_le_mul_left m (by omega)
        calc extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) mem_next
            ≤ extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) (buildSeq k.1) +
                (5 * Cap_u + 2) := hex_next
          _ ≤ (k.1 + 1) * (5 * Cap_u + 2) := by
              calc extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) (buildSeq k.1) +
                    (5 * Cap_u + 2)
                  ≤ k.1 * (5 * Cap_u + 2) + (5 * Cap_u + 2) := Nat.add_le_add_right hex_k _
                _ = (k.1 + 1) * (5 * Cap_u + 2) := by ring
          _ ≤ m * (9 * Cap_u + 3) := h1.trans h2
      rw [← hMemEq] at hex_bound hPeak
      have hSpace : (out.peakCellSpace : ℝ) ≤ spaceBound :=
        peakCellSpace_le_spaceBound hm hM₀ hCapu hh0 hh1 hx0 hx1 hM₀_ub hCapu_ub hCapq_sp
          hPeak (hinp_ins k) hex_bound
      exact ⟨out, hRun, hseq_eq, hCostHalf, hSpace⟩

    let cInsOut : Fin m → ArithRAMExecOutcome := fun k => Classical.choose (hStepOut k)
    have hcInsOut : ∀ k : Fin m,
        runArithRAMWithBits (insertStmt ℓ) (insInp k) (buildSeq k.1) [] = some (cInsOut k) ∧
        buildSeq (k.1 + 1) = (cInsOut k).mem ∧
        ((cInsOut k).unitCost : ℝ) ≤ (1 / 2 : ℝ) * dataWorkBound ∧
        ((cInsOut k).peakCellSpace : ℝ) ≤ spaceBound :=
      fun k => Classical.choose_spec (hStepOut k)
    let cInsMem : Fin (m + 1) → ArithRAMMemory := fun i => buildSeq i.1

    have hSumCost : (pOut.unitCost + cInitOut.unitCost +
        ∑ k : Fin m, (cInsOut k).unitCost : ℝ) ≤ (m : ℝ) * dataWorkBound := by
      have hsum_ins : (∑ k : Fin m, ((cInsOut k).unitCost : ℝ)) ≤
          (m : ℝ) * ((1 / 2 : ℝ) * dataWorkBound) := by
        calc (∑ k : Fin m, ((cInsOut k).unitCost : ℝ))
            ≤ ∑ _k : Fin m, ((1 / 2 : ℝ) * dataWorkBound) :=
              Finset.sum_le_sum (fun k _ => (hcInsOut k).2.2.1)
          _ = (m : ℝ) * ((1 / 2 : ℝ) * dataWorkBound) := by simp [m]
      have hm1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
      push_cast
      nlinarith only [hpOut_cost_qtr, hInitQtr, hsum_ins, hm1, hdwb_nn]

    have hValid : ∃ (initOut : ArithRAMExecOutcome)
        (insMem : Fin (m + 1) → ArithRAMMemory)
        (insOut : Fin m → ArithRAMExecOutcome),
        runArithRAMWithBits initStmt (initInp ω) pOut.mem [] = some initOut ∧
        (initOut.unitCost : ℝ) ≤ dataWorkBound ∧
        (initOut.peakCellSpace : ℝ) ≤ spaceBound ∧
        insMem 0 = initOut.mem ∧
        (∀ k : Fin m,
          runArithRAMWithBits (insertStmt ℓ) (insInp k) (insMem k.castSucc) [] = some (insOut k) ∧
          insMem k.succ = (insOut k).mem ∧
          ((insOut k).unitCost : ℝ) ≤ dataWorkBound ∧
          ((insOut k).peakCellSpace : ℝ) ≤ spaceBound) ∧
        ((pOut.unitCost + initOut.unitCost +
            ∑ k : Fin m, (insOut k).unitCost : ℝ) ≤ (m : ℝ) * dataWorkBound) ∧
        buildSeq m = insMem (Fin.last m) := by
      refine ⟨cInitOut, cInsMem, cInsOut, hInitRun, hInitCost_le, hInitSpace_le, rfl, ?_, hSumCost, rfl⟩
      intro k
      rcases hcInsOut k with ⟨hRun, hSeq, hHalf, hSp⟩
      exact ⟨hRun, hSeq, by linarith only [hHalf, hdwb_nn], hSp⟩

    have hUniq : ∀ bm', (∃ (initOut : ArithRAMExecOutcome)
        (insMem : Fin (m + 1) → ArithRAMMemory)
        (insOut : Fin m → ArithRAMExecOutcome),
        runArithRAMWithBits initStmt (initInp ω) pOut.mem [] = some initOut ∧
        (initOut.unitCost : ℝ) ≤ dataWorkBound ∧
        (initOut.peakCellSpace : ℝ) ≤ spaceBound ∧
        insMem 0 = initOut.mem ∧
        (∀ k : Fin m,
          runArithRAMWithBits (insertStmt ℓ) (insInp k) (insMem k.castSucc) [] = some (insOut k) ∧
          insMem k.succ = (insOut k).mem ∧
          ((insOut k).unitCost : ℝ) ≤ dataWorkBound ∧
          ((insOut k).peakCellSpace : ℝ) ≤ spaceBound) ∧
        ((pOut.unitCost + initOut.unitCost +
            ∑ k : Fin m, (insOut k).unitCost : ℝ) ≤ (m : ℝ) * dataWorkBound) ∧
        bm' = insMem (Fin.last m)) → bm' = buildSeq m := by
      rintro bm' ⟨initOut', insMem', insOut', hIRun', _, _, hIM0', hIStep', _, rfl⟩
      have hInitEq : initOut' = cInitOut := Option.some.inj (hIRun'.symm.trans hInitRun)
      have hall : ∀ j : ℕ, (hj : j ≤ m) → insMem' ⟨j, Nat.lt_succ_of_le hj⟩ = buildSeq j := by
        intro j
        induction j with
        | zero =>
            intro _
            change insMem' 0 = cInitOut.mem
            rw [hIM0', hInitEq]
        | succ j ih =>
            intro hj_le
            have hj_lt : j < m := by omega
            have hprev := ih (Nat.le_of_lt hj_lt)
            let kj : Fin m := ⟨j, hj_lt⟩
            rcases hIStep' kj with ⟨hRun', hSucc', _, _⟩
            have hcast : kj.castSucc = ⟨j, Nat.lt_succ_of_le (Nat.le_of_lt hj_lt)⟩ := rfl
            rw [hcast, hprev] at hRun'
            change insMem' kj.succ =
              (if hi : j < m then nextMem (insertStmt ℓ) (insInp ⟨j, hi⟩) (buildSeq j) else buildSeq j)
            rw [dif_pos hj_lt, hSucc', ← nextMem_of_some hRun']
      exact hall m le_rfl

    rcases hBuildSeq m le_rfl with ⟨hInv_m, hex_m⟩
    rw [actPrefix_self] at hInv_m
    exact ⟨buildSeq m, hValid, hUniq, hInv_m, hex_m⟩

  -- Canonical delete sequence from `builtMem`
  have hDel : ∀ (ω : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d))
      (builtMem : ArithRAMMemory)
      (hInvB : IndexInv hM₀ x t Cap_u Cap_q ω ptsK Finset.univ builtMem)
      (hexB : extraCells SW SR builtMem ≤ m * (5 * Cap_u + 2))
      (dels : List (Fin m)) (hdels : dels.Nodup),
      ∃ finalMem : ArithRAMMemory,
        (∃ (delMem : Fin (dels.length + 1) → ArithRAMMemory)
           (delOut : Fin dels.length → ArithRAMExecOutcome),
           delMem 0 = builtMem ∧
           (∀ step : Fin dels.length,
             runArithRAMWithBits deleteStmt (delInp dels step) (delMem step.castSucc) [] =
               some (delOut step) ∧
             delMem step.succ = (delOut step).mem ∧
             ((delOut step).unitCost : ℝ) ≤ dataWorkBound ∧
             ((delOut step).peakCellSpace : ℝ) ≤ spaceBound) ∧
           finalMem = delMem (Fin.last dels.length)) ∧
        (∀ fm', (∃ (delMem : Fin (dels.length + 1) → ArithRAMMemory)
           (delOut : Fin dels.length → ArithRAMExecOutcome),
           delMem 0 = builtMem ∧
           (∀ step : Fin dels.length,
             runArithRAMWithBits deleteStmt (delInp dels step) (delMem step.castSucc) [] =
               some (delOut step) ∧
             delMem step.succ = (delOut step).mem ∧
             ((delOut step).unitCost : ℝ) ≤ dataWorkBound ∧
             ((delOut step).peakCellSpace : ℝ) ≤ spaceBound) ∧
           fm' = delMem (Fin.last dels.length)) → fm' = finalMem) ∧
        IndexInv hM₀ x t Cap_u Cap_q ω ptsK
          (Finset.univ.filter (fun k : Fin m => k ∉ dels)) finalMem ∧
        extraCells SW SR finalMem ≤ m * (9 * Cap_u + 3) := by
    intro ω builtMem hInvB hexB dels hdels
    have hdels_len : dels.length ≤ m := by
      simpa [m] using hdels.length_le_card
    let delSeq : ℕ → ArithRAMMemory := fun s =>
      Nat.rec builtMem
        (fun i acc => if hi : i < dels.length then nextMem deleteStmt (delInp dels ⟨i, hi⟩) acc else acc) s
    have hDelSeq : ∀ s ≤ dels.length,
        IndexInv hM₀ x t Cap_u Cap_q ω ptsK (actAfterDel dels s) (delSeq s) ∧
        extraCells SW SR (delSeq s) ≤ m * (5 * Cap_u + 2) + s * (4 * Cap_u + 1) := by
      intro s
      induction s with
      | zero =>
          intro _
          rw [actAfterDel_zero]
          refine ⟨hInvB, ?_⟩
          change extraCells SW SR builtMem ≤ m * (5 * Cap_u + 2) + 0 * (4 * Cap_u + 1)
          simpa using hexB
      | succ s ih =>
          intro hs_le
          have hs_lt : s < dels.length := by omega
          rcases ih (by omega) with ⟨hInv_s, hex_s⟩
          let st : Fin dels.length := ⟨s, hs_lt⟩
          rcases exec_deleteStmt hM₀ ω ptsK (dels.get st) (delInp dels st) rfl hInv_s with
            ⟨mem_next, hDelExec, hex_next, hInv_next⟩
          rcases hDelExec.to_run with ⟨out_s, hDelRun, hMemEq, _, _⟩
          have hstep_eq : delSeq (s + 1) = mem_next := by
            change (if hi : s < dels.length then nextMem deleteStmt (delInp dels ⟨s, hi⟩) (delSeq s)
              else delSeq s) = mem_next
            rw [dif_pos hs_lt, nextMem_of_some hDelRun, hMemEq]
          rw [hstep_eq, ← erase_actAfterDel dels hs_lt]
          refine ⟨hInv_next, ?_⟩
          dsimp only [SW, SR] at hex_s ⊢
          calc extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) mem_next
              ≤ extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) (delSeq s) +
                  (4 * Cap_u + 1) := hex_next
            _ ≤ (m * (5 * Cap_u + 2) + s * (4 * Cap_u + 1)) + (4 * Cap_u + 1) :=
                Nat.add_le_add_right hex_s _
            _ = m * (5 * Cap_u + 2) + (s + 1) * (4 * Cap_u + 1) := by ring

    have hStepOut : ∀ step : Fin dels.length,
        ∃ out : ArithRAMExecOutcome,
          runArithRAMWithBits deleteStmt (delInp dels step) (delSeq step.1) [] = some out ∧
          delSeq (step.1 + 1) = out.mem ∧
          (out.unitCost : ℝ) ≤ dataWorkBound ∧
          (out.peakCellSpace : ℝ) ≤ spaceBound := by
      intro step
      rcases hDelSeq step.1 (Nat.le_of_lt step.2) with ⟨hInv_s, hex_s⟩
      rcases exec_deleteStmt hM₀ ω ptsK (dels.get step) (delInp dels step) rfl hInv_s with
        ⟨mem_next, hDelExec, hex_next, _⟩
      rcases hDelExec.to_run with ⟨out, hRun, hMemEq, hCost, hPeak⟩
      have hseq_eq : delSeq (step.1 + 1) = out.mem := by
        change (if hi : step.1 < dels.length then nextMem deleteStmt (delInp dels ⟨step.1, hi⟩) (delSeq step.1)
          else delSeq step.1) = out.mem
        rw [dif_pos step.2, nextMem_of_some hRun]
      have hCost_ins : out.unitCost ≤
          100 + d * 30 + ℓ * 40 + ℓ * M₀ * (65 + d * 30) + Cap_u * (150 + ℓ * 60) := by
        have h165 : Cap_u * 165 ≤ Cap_u * (150 + ℓ * 60) :=
          Nat.mul_le_mul_left Cap_u (by omega)
        omega
      have hHalf : (out.unitCost : ℝ) ≤ (1 / 2 : ℝ) * dataWorkBound :=
        update_cost_le_half hM₀ hM₀_ub hCapu_ub hCost_ins
      have hex_bound : extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) mem_next ≤
          m * (9 * Cap_u + 3) := by
        dsimp only [SW, SR] at hex_s
        have hs1 : step.1 + 1 ≤ m := step.2.trans_le hdels_len
        have hmul : (step.1 + 1) * (4 * Cap_u + 1) ≤ m * (4 * Cap_u + 1) :=
          Nat.mul_le_mul_right _ hs1
        calc extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) mem_next
            ≤ extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) (delSeq step.1) +
                (4 * Cap_u + 1) := hex_next
          _ ≤ m * (5 * Cap_u + 2) + step.1 * (4 * Cap_u + 1) + (4 * Cap_u + 1) :=
              Nat.add_le_add_right hex_s _
          _ = m * (5 * Cap_u + 2) + (step.1 + 1) * (4 * Cap_u + 1) := by ring
          _ ≤ m * (5 * Cap_u + 2) + m * (4 * Cap_u + 1) := Nat.add_le_add_left hmul _
          _ = m * (9 * Cap_u + 3) := by ring
      rw [← hMemEq] at hex_bound hPeak
      have hSpace : (out.peakCellSpace : ℝ) ≤ spaceBound :=
        peakCellSpace_le_spaceBound hm hM₀ hCapu hh0 hh1 hx0 hx1 hM₀_ub hCapu_ub hCapq_sp
          hPeak (hinp_del dels step) hex_bound
      exact ⟨out, hRun, hseq_eq, by linarith only [hHalf, hdwb_nn], hSpace⟩

    let cDelOut : Fin dels.length → ArithRAMExecOutcome := fun st => Classical.choose (hStepOut st)
    have hcDelOut : ∀ st : Fin dels.length,
        runArithRAMWithBits deleteStmt (delInp dels st) (delSeq st.1) [] = some (cDelOut st) ∧
        delSeq (st.1 + 1) = (cDelOut st).mem ∧
        ((cDelOut st).unitCost : ℝ) ≤ dataWorkBound ∧
        ((cDelOut st).peakCellSpace : ℝ) ≤ spaceBound :=
      fun st => Classical.choose_spec (hStepOut st)
    let cDelMem : Fin (dels.length + 1) → ArithRAMMemory := fun i => delSeq i.1

    have hValid : ∃ (delMem : Fin (dels.length + 1) → ArithRAMMemory)
        (delOut : Fin dels.length → ArithRAMExecOutcome),
        delMem 0 = builtMem ∧
        (∀ step : Fin dels.length,
          runArithRAMWithBits deleteStmt (delInp dels step) (delMem step.castSucc) [] =
            some (delOut step) ∧
          delMem step.succ = (delOut step).mem ∧
          ((delOut step).unitCost : ℝ) ≤ dataWorkBound ∧
          ((delOut step).peakCellSpace : ℝ) ≤ spaceBound) ∧
        delSeq dels.length = delMem (Fin.last dels.length) :=
      ⟨cDelMem, cDelOut, rfl, hcDelOut, rfl⟩

    have hUniq : ∀ fm', (∃ (delMem : Fin (dels.length + 1) → ArithRAMMemory)
        (delOut : Fin dels.length → ArithRAMExecOutcome),
        delMem 0 = builtMem ∧
        (∀ step : Fin dels.length,
          runArithRAMWithBits deleteStmt (delInp dels step) (delMem step.castSucc) [] =
            some (delOut step) ∧
          delMem step.succ = (delOut step).mem ∧
          ((delOut step).unitCost : ℝ) ≤ dataWorkBound ∧
          ((delOut step).peakCellSpace : ℝ) ≤ spaceBound) ∧
        fm' = delMem (Fin.last dels.length)) → fm' = delSeq dels.length := by
      rintro fm' ⟨delMem', delOut', hDM0', hDStep', rfl⟩
      have hall : ∀ s : ℕ, (hs : s ≤ dels.length) → delMem' ⟨s, Nat.lt_succ_of_le hs⟩ = delSeq s := by
        intro s
        induction s with
        | zero =>
            intro _
            exact hDM0'
        | succ s ih =>
            intro hs_le
            have hs_lt : s < dels.length := by omega
            have hprev := ih (Nat.le_of_lt hs_lt)
            let st : Fin dels.length := ⟨s, hs_lt⟩
            rcases hDStep' st with ⟨hRun', hSucc', _, _⟩
            have hcast : st.castSucc = ⟨s, Nat.lt_succ_of_le (Nat.le_of_lt hs_lt)⟩ := rfl
            rw [hcast, hprev] at hRun'
            change delMem' st.succ =
              (if hi : s < dels.length then nextMem deleteStmt (delInp dels ⟨s, hi⟩) (delSeq s)
                else delSeq s)
            rw [dif_pos hs_lt, hSucc', ← nextMem_of_some hRun']
      exact hall dels.length le_rfl

    rcases hDelSeq dels.length le_rfl with ⟨hInv_f, hex_f⟩
    rw [actAfterDel_length] at hInv_f
    have hex_f_ub : extraCells SW SR (delSeq dels.length) ≤ m * (9 * Cap_u + 3) := by
      have hmul : dels.length * (4 * Cap_u + 1) ≤ m * (4 * Cap_u + 1) :=
        Nat.mul_le_mul_right _ hdels_len
      calc extraCells SW SR (delSeq dels.length)
          ≤ m * (5 * Cap_u + 2) + dels.length * (4 * Cap_u + 1) := hex_f
        _ ≤ m * (5 * Cap_u + 2) + m * (4 * Cap_u + 1) := Nat.add_le_add_left hmul _
        _ = m * (9 * Cap_u + 3) := by ring
    exact ⟨delSeq dels.length, hValid, hUniq, hInv_f, hex_f_ub⟩

  -- Canonical query run + soundness/completeness from `finalMem`
  let decodeCandidates : ArithRAMMemory → List ι :=
    fun qMem =>
      let r : ℕ := (qMem.words.read (.heap 0 0)).toNat
      (List.range r).filterMap (fun idx =>
        let h_z := qMem.words.read (.heap 0 ((idx : ℤ) + 1))
        if hh : 0 ≤ h_z ∧ h_z.toNat < m then
          some (enum ⟨h_z.toNat, hh.2⟩).1
        else
          none)
  let queryAnswer : ArithRAMMemory → (ι → Prop) → Option ι :=
    fun qMem accept =>
      (decodeCandidates qMem).find? (fun i => decide (accept i))

  have hMemDecode : ∀ (qMem : ArithRAMMemory) (r : ℕ)
      (hw00 : wRead qMem 0 0 = (r : ℤ))
      {idx : ℕ} (hidx : idx < r) {k₀ : Fin m}
      (hslot : wRead qMem 0 ((idx + 1 : ℕ) : ℤ) = (k₀.1 : ℤ)),
      (enum k₀).1 ∈ decodeCandidates qMem := by
    intro qMem r hw00 idx hidx k₀ hslot
    dsimp only [decodeCandidates]
    have hr_eq : (qMem.words.read (.heap 0 0)).toNat = r := by
      change (wRead qMem 0 0).toNat = r
      rw [hw00, Int.toNat_natCast]
    rw [hr_eq, List.mem_filterMap]
    refine ⟨(idx : ℤ), by simp [hidx], ?_⟩
    have hz_eq : qMem.words.read (.heap 0 ((idx : ℤ) + 1)) = (k₀.1 : ℤ) := by
      rw [← Nat.cast_succ idx]
      exact hslot
    simp only [hz_eq, Nat.cast_nonneg, Int.toNat_natCast, k₀.2, and_self, ↓reduceDIte, Fin.eta]

  have hValidAns : ∀ (dels : List (Fin m)) (qMem : ArithRAMMemory) (r : ℕ)
      (hw00 : wRead qMem 0 0 = (r : ℤ))
      (pairs : Fin r → Fin m × (Fin ℓ → Fin M₀))
      (hpairs : ∀ u : Fin r,
        (pairs u).1 ∈ Finset.univ.filter (fun k : Fin m => k ∉ dels) ∧
        wRead qMem 0 ((u.1 + 1 : ℕ) : ℤ) = ((pairs u).1.1 : ℤ))
      (q : SearchQuery ι d),
      q.IsValidAnswer
        ((Finset.univ.filter (fun k : Fin m => k ∉ dels)).image (fun k => (enum k).1))
        (queryAnswer qMem q.accept) := by
    intro dels qMem r hw00 pairs hpairs q
    unfold SearchQuery.IsValidAnswer IsValidSearchAnswer
    cases hfind : queryAnswer qMem q.accept with
    | none => trivial
    | some i =>
        have hfind' : (decodeCandidates qMem).find? (fun x => decide (q.accept x)) = some i := hfind
        have hp := List.find?_some hfind'
        have hacc : q.accept i := of_decide_eq_true hp
        have hmem_cand : i ∈ decodeCandidates qMem := List.mem_of_find?_eq_some hfind'
        dsimp only [decodeCandidates] at hmem_cand
        have hr_eq : (qMem.words.read (.heap 0 0)).toNat = r := by
          change (wRead qMem 0 0).toNat = r
          rw [hw00, Int.toNat_natCast]
        rw [hr_eq, List.mem_filterMap] at hmem_cand
        rcases hmem_cand with ⟨idx_z, hidx_mem, hopt⟩
        have hidx_ex : ∃ idx < r, idx_z = (idx : ℤ) := by simpa using hidx_mem
        rcases hidx_ex with ⟨idx, hidx_lt, rfl⟩
        let u : Fin r := ⟨idx, hidx_lt⟩
        rcases hpairs u with ⟨hu_surv, hu_slot⟩
        have hz_eq : qMem.words.read (.heap 0 ((idx : ℤ) + 1)) = ((pairs u).1.1 : ℤ) := by
          rw [← Nat.cast_succ idx]
          exact hu_slot
        simp only [hz_eq, Nat.cast_nonneg, Int.toNat_natCast, (pairs u).1.2, and_self,
          ↓reduceDIte, Fin.eta, Option.some.injEq] at hopt
        refine ⟨?_, hacc⟩
        rw [← hopt]
        exact Finset.mem_image_of_mem _ hu_surv

  -- Assemble Conjunct 1 & Conjunct 2
  constructor
  · -- Conjunct 1: Universal execution & soundness on every outcome `ω`
    intro ω
    rcases hBuild ω with ⟨builtMem, hBT, _, hInvB, hexB⟩
    refine ⟨builtMem, hBT, ?_⟩
    intro dels hdels
    rcases hDel ω builtMem hInvB hexB dels hdels with ⟨finalMem, hDT, _, hInvF, hexF⟩
    refine ⟨finalMem, hDT, ?_⟩
    intro z _hz
    rcases exec_queryStmt hM₀ ω ptsK z (qInp dels z) rfl hInvF with
      ⟨qMem, r, hQExec, hexQ, hr_le, hw00_q, ⟨pairs, _, hpairs⟩, _⟩
    rcases hQExec.to_run with ⟨qOut, hQRun, hQMemEq, hQCost, hQPeak⟩
    rw [← hQMemEq] at hexQ hw00_q hpairs hQPeak
    have hQSpace : (qOut.peakCellSpace : ℝ) ≤ spaceBound :=
      peakCellSpace_le_spaceBound hm hM₀ hCapu hh0 hh1 hx0 hx1 hM₀_ub hCapu_ub hCapq_sp
        hQPeak (hinp_q dels z) (by dsimp only [SW, SR] at hexF; rw [hexQ]; exact hexF)
    have hr_toNat : (qOut.mem.words.read (.heap 0 0)).toNat = r := by
      change (wRead qOut.mem 0 0).toNat = r
      rw [hw00_q, Int.toNat_natCast]
    have hw00_nn : 0 ≤ qOut.mem.words.read (.heap 0 0) := by
      change 0 ≤ wRead qOut.mem 0 0
      rw [hw00_q]
      exact Nat.cast_nonneg r
    have hQWork : (qOut.unitCost + (qOut.mem.words.read (.heap 0 0)).toNat : ℝ) ≤ queryWorkBound := by
      rw [hr_toNat]
      exact query_cost_le_bound hM₀ hCapq hr_le hM₀_ub hCapq_ub hQCost
    refine ⟨qOut, ⟨hQRun, hQSpace, hw00_nn, hQWork, ?_⟩, ?_⟩
    · intro idx hidx
      rw [hr_toNat] at hidx
      let u : Fin r := ⟨idx, hidx⟩
      rcases hpairs u with ⟨hu_surv, _, hu_slot⟩
      have hz_eq : qOut.mem.words.read (.heap 0 ((idx : ℤ) + 1)) = ((pairs u).1.1 : ℤ) := by
        rw [← Nat.cast_succ idx]
        exact hu_slot
      rw [hz_eq]
      exact ⟨Nat.cast_nonneg _,
        by simpa using Finset.mem_image_of_mem Fin.val hu_surv⟩
    · intro q _hqz
      exact hValidAns dels qOut.mem r hw00_q pairs
        (fun u => ⟨(hpairs u).1, (hpairs u).2.2⟩) q

  · -- Conjunct 2: Good event `E` with probability `≥ 9 / 10` for fixed target `(z, i_star)`
    intro z hz i_star hi_star
    let k_star : Fin m := enum.symm ⟨i_star, hi_star.1⟩
    have henum_k : (enum k_star).1 = i_star := by
      simp [k_star]
    have hpts_k : ptsK k_star = gen.pts i_star := by
      simp [ptsK, henum_k]
    have hunit_ptsK : ∀ k : Fin m, IsUnitVec (ptsK k) :=
      fun k => gen.unit_pts (enum k).1 (enum k).2
    have hp_star_unit : IsUnitVec (ptsK k_star) := hunit_ptsK k_star
    have htarget_k : h ≤ inner ℝ (ptsK k_star) z := by
      rw [hpts_k]; exact hi_star.2

    rcases hprobs_inst with
      ⟨p_u, p_q, p₁, p₂, hprobs, hpu_ub, hpq_ub, hp₁_lb, hp₂_ub⟩
    have hpu0 : 0 ≤ p_u := by
      rw [← hprobs.2.1 (ptsK k_star) hp_star_unit]
      exact MeasureTheory.measureReal_nonneg
    have hpq0 : 0 ≤ p_q := by
      rw [← hprobs.2.2.1 z hz]
      exact MeasureTheory.measureReal_nonneg
    have hp₂0 : 0 ≤ p₂ := by
      have hneg_z : IsUnitVec (-z) := by unfold IsUnitVec at hz ⊢; simpa using hz
      have hle0 : inner ℝ (-z) z ≤ 0 := by
        rw [inner_neg_left, real_inner_self_eq_norm_sq]
        nlinarith [norm_nonneg z]
      exact MeasureTheory.measureReal_nonneg.trans (hprobs.2.2.2.2 (-z) z hneg_z hz hle0)
    rcases hprob_ineqs p_u p_q p₁ p₂ hpu0 hpq0 hp₂0 hpu_ub hpq_ub hp₁_lb hp₂_ub with
      ⟨hp₁_pos, hlog_p₁M, hcap_u_ok, hcap_q_ok, hcap_bad_ok⟩

    let E : Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin d)) :=
      {ω | (∃ τ : Fin ℓ → Fin M₀, IsSharedTuple x t ω (ptsK k_star) z τ) ∧
           dataTupleCard t ω (ptsK k_star) ≤ Cap_u ∧
           queryTupleCard x t ω z ≤ Cap_q ∧
           badSharedCard x t ptsK z ω ≤ Cap_q}
    rcases goodEvent_prob_ge hℓ hM₀ hprobs hp₁_pos hlog_p₁M (by omega) (by omega)
      hcap_u_ok hcap_q_ok hcap_bad_ok ptsK hunit_ptsK hp_star_unit hz htarget_k with
      ⟨hE_meas, hE_prob⟩

    refine ⟨E, hE_meas, hE_prob, ?_⟩
    intro ω hω builtMem hBT_any dels hdels hi_cur finalMem hDT_any qOut hQR_any q hqz hcompat
    rcases hω with ⟨hE_sh, hE_du, hE_dq, hE_bad⟩
    -- Identify `builtMem`, `finalMem`, and `qOut` with the canonical deterministic outcomes
    rcases hBuild ω with ⟨cBuilt, _, hUniqB, hInvB, hexB⟩
    have hBM_eq : builtMem = cBuilt := hUniqB builtMem hBT_any
    subst hBM_eq
    rcases hDel ω builtMem hInvB hexB dels hdels with ⟨cFinal, _, hUniqD, hInvF, _⟩
    have hFM_eq : finalMem = cFinal := hUniqD finalMem hDT_any
    subst hFM_eq
    rcases exec_queryStmt hM₀ ω ptsK z (qInp dels z) rfl hInvF with
      ⟨qMem, r, hQExec, _, hr_le, hw00_q, ⟨pairs, hinj, hpairs⟩, hcomp⟩
    rcases hQExec.to_run with ⟨cQOut, hQRun_c, hQMemEq, _, _⟩
    have hQOut_eq : qOut = cQOut := Option.some.inj (hQR_any.1.symm.trans hQRun_c)
    subst hQOut_eq
    rw [← hQMemEq] at hw00_q hpairs hcomp

    let survH := Finset.univ.filter (fun k : Fin m => k ∉ dels)
    let P_cur := survH.image (fun k => (enum k).1)

    have hk_star_surv : k_star ∈ survH := by
      rcases Finset.mem_image.mp hi_cur with ⟨k', hk'_in, hk'_eq⟩
      have heq_sub : enum k' = enum k_star := Subtype.ext (hk'_eq.trans henum_k.symm)
      rwa [enum.injective heq_sub] at hk'_in

    have hpos_accept : ∀ k₀ : Fin m, k₀ ∈ survH → 0 < inner ℝ (ptsK k₀) z →
        q.accept (enum k₀).1 := by
      intro k₀ hk₀ hpos_cor
      have hi₀_in : (enum k₀).1 ∈ P_cur := Finset.mem_image_of_mem _ hk₀
      by_contra hrej
      have hle0 : inner ℝ (gen.pts (enum k₀).1) q.z ≤ 0 := hcompat (enum k₀).1 hi₀_in hrej
      rw [hqz] at hle0
      dsimp only [ptsK] at hpos_cor
      linarith only [hpos_cor, hle0]

    have hvalid : q.IsValidAnswer P_cur (queryAnswer qOut.mem q.accept) :=
      hValidAns dels qOut.mem r hw00_q pairs (fun u => ⟨(hpairs u).1, (hpairs u).2.2⟩) q

    have hans_ne : queryAnswer qOut.mem q.accept ≠ none := by
      suffices hex_good : ∃ k₀ : Fin m,
          (enum k₀).1 ∈ decodeCandidates qOut.mem ∧ q.accept (enum k₀).1 by
        rcases hex_good with ⟨k₀, hcand, hacc⟩
        intro hnone
        have hnone' : (decodeCandidates qOut.mem).find? (fun x => decide (q.accept x)) = none := hnone
        have hall := List.find?_eq_none.mp hnone' (enum k₀).1 hcand
        exact hall (decide_eq_true hacc)
      by_cases hr_lt : r < Cap_q + 1
      · -- Below cap: completeness guarantees `k_star` itself is emitted
        rcases hcomp hr_lt k_star hk_star_surv hE_du hE_dq hE_sh with ⟨idx, hidx_lt, hslot⟩
        refine ⟨k_star, hMemDecode qOut.mem r hw00_q hidx_lt hslot, ?_⟩
        exact hpos_accept k_star hk_star_surv (lt_of_lt_of_le hh0 htarget_k)
      · -- Hit cap `r = Cap_q + 1 > badSharedCard`: pigeonhole gives a pair with `> 0` correlation
        have hr_eq : r = Cap_q + 1 := by omega
        have hex_u : ∃ u₀ : Fin r, 0 < inner ℝ (ptsK (pairs u₀).1) z := by
          by_contra hall_bad
          push_neg at hall_bad
          let badSet := Finset.univ.filter (fun kt : Fin m × (Fin ℓ → Fin M₀) =>
            inner ℝ (ptsK kt.1) z ≤ 0 ∧ IsSharedTuple x t ω (ptsK kt.1) z kt.2)
          have hsub : (Finset.univ : Finset (Fin r)).image pairs ⊆ badSet := by
            intro kt hkt
            rcases Finset.mem_image.mp hkt with ⟨u, _, rfl⟩
            exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hall_bad u, (hpairs u).2.1⟩
          have hcard_img : ((Finset.univ : Finset (Fin r)).image pairs).card = r := by
            rw [Finset.card_image_of_injective _ hinj, Finset.card_fin]
          have hle_bad : r ≤ badSharedCard x t ptsK z ω := by
            rw [← hcard_img]
            exact Finset.card_le_card hsub
          omega
        rcases hex_u with ⟨u₀, hu₀_pos⟩
        rcases hpairs u₀ with ⟨hu₀_surv, _, hu₀_slot⟩
        exact ⟨(pairs u₀).1, hMemDecode qOut.mem r hw00_q u₀.2 hu₀_slot,
          hpos_accept (pairs u₀).1 hu₀_surv hu₀_pos⟩

    exact ⟨hans_ne, hvalid, fun hnone => absurd hnone hans_ne⟩

end UL.Proof.lem_6_3.RacerV30

namespace UL

open UL.Proof_lem_6_3
open UL.Proof.lem_6_3.RacerV30

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_6_3 (h_lem_6_1 : S_lem_6_1) (h_lem_6_2 : S_lem_6_2) : S_lem_6_3 := by
  let _ := h_lem_6_1
  unfold S_lem_6_3
  intro ℓ hℓ h_min h_max hh_min hh_le hh_max
  rcases h_lem_6_2 h_min h_max hh_min hh_le hh_max with ⟨c_h, hc_h, h_probs_all⟩
  let C_base : ℕ := Nat.ceil (2 * Real.log (100 * (ℓ : ℝ)) / c_h) + 1
  refine ⟨buildParamStmt ℓ C_base, initStmt, insertStmt ℓ, deleteStmt, queryStmt ℓ,
    polyFactor ℓ C_base, 9 / 10, isBoundedByPoly2_polyFactor ℓ C_base, by norm_num, ?_⟩
  intro d hd ι gen enum hh_lo hh_hi x hx0 hx1
  dsimp only
  have hm : 1 ≤ gen.m := Finset.card_pos.mpr gen.nonempty
  have hh0 : 0 < gen.h := gen.h_pos
  have hh1 : gen.h < 1 := gen.h_lt_one
  let pInp : ArithRAMInput d :=
    { intParams := [(gen.m : ℤ)]
      activeHandles := ∅
      activeCoords := fun _ => 0
      extraReals := [gen.h, x] }
  rcases exec_buildParamStmt (d := d) ℓ hℓ hc_h gen.m hm hh0 hh1 hx0 hx1 with
    ⟨memP, t, M₀, Cap_u, Cap_q, hpExec, hfpP, hM₀, hCapu, hCapq,
      ht1, _ht2, hw00, hw10, hw11, hw12, hw13, hw14, hr10, hr11,
      hM₀_ub, hCapu_ub, hCapq_ub, hCapq_sp, hprob_ineqs⟩
  have hcMemP : CleanMem memP := hpExec.2.1
  rcases hpExec.to_run with ⟨pOut, hpRun, hpMemEq, hpCost, hpPeak⟩
  rw [← hpMemEq] at hfpP hw00 hw10 hw11 hw12 hw13 hw14 hr10 hr11 hpPeak hcMemP
  have hpQtr : (pOut.unitCost : ℝ) ≤
      (1 / 4 : ℝ) * (((gen.m : ℝ) ^ (u_search gen.h x) + (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) *
        polyFactor ℓ C_base d (natBitLength gen.m)) :=
    param_cost_le_quarter hm hh0 hh1 hx0 hx1 hpCost
  have hdwb_nn : 0 ≤ ((gen.m : ℝ) ^ (u_search gen.h x) + (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) *
      polyFactor ℓ C_base d (natBitLength gen.m) := by
    have hp := polyFactor_nonneg ℓ C_base d (natBitLength gen.m)
    positivity
  have hpCost_le : (pOut.unitCost : ℝ) ≤
      ((gen.m : ℝ) ^ (u_search gen.h x) + (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) *
        polyFactor ℓ C_base d (natBitLength gen.m) := by
    linarith only [hpQtr, hdwb_nn]
  have hpInp_le : pInp.inputCellSpace ≤ 4 + gen.m * (d + 1) + ℓ * M₀ * d + d := by
    simp only [pInp, ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil,
      Finset.card_empty, zero_mul]
    omega
  have hpEx0 : extraCells (scratchWords ℓ M₀ Cap_q) (scratchReals d ℓ M₀) pOut.mem = 0 :=
    extraCells_eq_zero_of_inParamFootprint hfpP d ℓ M₀ Cap_q
  have hpSpace_le : (pOut.peakCellSpace : ℝ) ≤
      ((gen.m : ℝ) ^ (1 + u_search gen.h x) + (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) *
        polyFactor ℓ C_base d (natBitLength gen.m) :=
    peakCellSpace_le_spaceBound hm hM₀ hCapu hh0 hh1 hx0 hx1 hM₀_ub hCapu_ub hCapq_sp
      hpPeak hpInp_le (by rw [hpEx0]; exact Nat.zero_le _)
  have hK_ge1 : 1 ≤ pOut.mem.words.read (.heap 0 0) := by
    change 1 ≤ wRead pOut.mem 0 0
    rw [hw00]
    have : 1 ≤ ℓ * M₀ := Nat.mul_le_mul hℓ hM₀
    exact_mod_cast this
  have hK_eq : (pOut.mem.words.read (.heap 0 0)).toNat = ℓ * M₀ := by
    change (wRead pOut.mem 0 0).toNat = ℓ * M₀
    rw [hw00, Int.toNat_natCast]
  refine ⟨pOut, hpRun, hpCost_le, hpSpace_le, hK_ge1, ?_⟩
  exact mainAfterPOut hℓ hM₀ hCapu hCapq
    gen enum hx0 hx1 (h_probs_all d hd gen.h x t hh_lo hh_hi hx0 hx1 ht1)
    pOut hfpP hcMemP
    hw10 hw11 hw12 hw13 hw14 hr10 hr11 hpQtr hM₀_ub hCapu_ub hCapq_ub hCapq_sp hprob_ineqs
    (pOut.mem.words.read (.heap 0 0)).toNat hK_eq

end UL
