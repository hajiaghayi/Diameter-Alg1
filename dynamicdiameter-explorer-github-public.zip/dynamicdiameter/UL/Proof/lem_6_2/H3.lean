import Mathlib
import UL.Def.def_6_search_exponents
import UL.Proof.lem_6_2.H1
import UL.Proof.lem_6_2.H2
set_option autoImplicit false

open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal Real

namespace UL.Proof_lem_6_2

/-- For nonpositive correlation `ρ ≤ 0` and `x, t > 0`, the 2D Gaussian wedge probability is at
most `exp(-(1 + x^2) * t^2 / 2)`. -/
theorem gaussianWedge_le_of_nonpos {ρ x t : ℝ} (hρ0 : ρ ≤ 0) (hx : 0 < x) (ht : 0 < t) :
    (stdNormal.prod stdNormal).real (gaussianWedge ρ x t) ≤
      Real.exp (-((1 + x ^ 2) * t ^ 2 / 2)) := by
  have hsub : gaussianWedge ρ x t ⊆ Set.Ici t ×ˢ Set.Ici (x * t) := by
    rintro ⟨u, v⟩ ⟨hu, huv⟩
    refine ⟨hu, ?_⟩
    dsimp only [Set.mem_Ici] at hu huv ⊢
    have hu_pos : 0 < u := lt_of_lt_of_le ht hu
    have hρu : ρ * u ≤ 0 := mul_nonpos_of_nonpos_of_nonneg hρ0 hu_pos.le
    have hsv : x * t ≤ Real.sqrt (1 - ρ ^ 2) * v := by linarith
    have hxt_pos : 0 < x * t := mul_pos hx ht
    have hs_nonneg : 0 ≤ Real.sqrt (1 - ρ ^ 2) := Real.sqrt_nonneg _
    have hv_pos : 0 < v := by
      by_contra hv_le
      push_neg at hv_le
      have : Real.sqrt (1 - ρ ^ 2) * v ≤ 0 := mul_nonpos_of_nonneg_of_nonpos hs_nonneg hv_le
      linarith
    have hs_le_one : Real.sqrt (1 - ρ ^ 2) ≤ 1 := by
      calc
        Real.sqrt (1 - ρ ^ 2) ≤ Real.sqrt 1 := Real.sqrt_le_sqrt (sub_le_self 1 (sq_nonneg ρ))
        _ = 1 := Real.sqrt_one
    have hsv_le : Real.sqrt (1 - ρ ^ 2) * v ≤ v := by
      simpa only [one_mul] using mul_le_mul_of_nonneg_right hs_le_one hv_pos.le
    exact hsv.trans hsv_le
  have hmono : (stdNormal.prod stdNormal).real (gaussianWedge ρ x t) ≤
      (stdNormal.prod stdNormal).real (Set.Ici t ×ˢ Set.Ici (x * t)) :=
    MeasureTheory.measureReal_mono hsub
  rw [MeasureTheory.measureReal_prod_prod] at hmono
  have h1 : stdNormal.real (Set.Ici t) ≤ Real.exp (-(t ^ 2 / 2)) :=
    stdGaussian_tail_le ht.le
  have h2 : stdNormal.real (Set.Ici (x * t)) ≤ Real.exp (-((x * t) ^ 2 / 2)) :=
    stdGaussian_tail_le (mul_pos hx ht).le
  have hprod :
      stdNormal.real (Set.Ici t) * stdNormal.real (Set.Ici (x * t)) ≤
        Real.exp (-(t ^ 2 / 2)) * Real.exp (-((x * t) ^ 2 / 2)) :=
    mul_le_mul h1 h2 MeasureTheory.measureReal_nonneg (Real.exp_pos _).le
  refine hmono.trans (hprod.trans_eq ?_)
  rw [← Real.exp_add]
  congr 1
  ring

/-- For correlation `h ≤ ρ ≤ 1` (`0 < h < 1`, `h ≤ x ≤ 1`, `1 ≤ t`), the 2D Gaussian wedge
probability is at least `(exp(-3) / (2 * π)) * t^(-2) * exp(-I_h(x) * t^2 / 2)`. -/
theorem gaussianWedge_ge_of_ge {h ρ x t : ℝ}
    (hh0 : 0 < h) (hh1 : h < 1) (hx_lo : h ≤ x) (hx_hi : x ≤ 1)
    (ht : 1 ≤ t) (hρ_lo : h ≤ ρ) :
    (Real.exp (-3) / (2 * Real.pi)) * t ^ (-2 : ℤ) * Real.exp (-(UL.I_h h x * t ^ 2 / 2)) ≤
      (stdNormal.prod stdNormal).real (gaussianWedge ρ x t) := by
  have ht0 : 0 < t := by linarith
  have hρ_pos : 0 < ρ := lt_of_lt_of_le hh0 hρ_lo
  have h1h2 : 0 < 1 - h ^ 2 := by nlinarith
  have hIh_eq : UL.I_h h x = 1 + (x - h) ^ 2 / (1 - h ^ 2) := by
    unfold UL.I_h
    field_simp [h1h2.ne']
    ring
  let α : ℝ := if x ≤ ρ then 0 else (x - ρ) / Real.sqrt (1 - ρ ^ 2)
  have hα0 : 0 ≤ α := by
    dsimp only [α]
    split_ifs with hle
    · exact le_rfl
    · push_neg at hle
      exact div_nonneg (by linarith) (Real.sqrt_nonneg _)
  have hα1 : α ≤ 1 := by
    dsimp only [α]
    split_ifs with hle
    · norm_num
    · push_neg at hle
      have hρ1 : ρ < 1 := lt_of_lt_of_le hle hx_hi
      have h1ρ2 : 0 < 1 - ρ ^ 2 := by nlinarith
      have hs_pos : 0 < Real.sqrt (1 - ρ ^ 2) := Real.sqrt_pos.mpr h1ρ2
      rw [div_le_one hs_pos]
      have hxr : x - ρ ≤ 1 - ρ := by linarith
      have h1r : 1 - ρ ≤ Real.sqrt (1 - ρ ^ 2) := by
        rw [← Real.sqrt_sq (by linarith : 0 ≤ 1 - ρ)]
        apply Real.sqrt_le_sqrt
        nlinarith
      linarith
  have hα_Ih : 1 + α ^ 2 ≤ UL.I_h h x := by
    rw [hIh_eq]
    dsimp only [α]
    split_ifs with hle
    · simp only [ne_eq, OfNat.ofNat_ne_zero, not_false_eq_true, zero_pow, add_zero]
      have : 0 ≤ (x - h) ^ 2 / (1 - h ^ 2) := by positivity
      linarith
    · push_neg at hle
      have hρ1 : ρ < 1 := lt_of_lt_of_le hle hx_hi
      have h1ρ2 : 0 < 1 - ρ ^ 2 := by nlinarith
      rw [div_pow, Real.sq_sqrt h1ρ2.le]
      suffices (x - ρ) ^ 2 / (1 - ρ ^ 2) ≤ (x - h) ^ 2 / (1 - h ^ 2) by linarith
      rw [div_le_div_iff₀ h1ρ2 h1h2]
      have hpoly :
          (x - h) ^ 2 * (1 - ρ ^ 2) - (x - ρ) ^ 2 * (1 - h ^ 2) =
            (ρ - h) * ((1 - x) * (ρ - h) * (1 + ρ) + 2 * (x - ρ) * (1 - h) +
              (ρ + h) * (x - ρ) * (1 - x)) := by
        ring
      have h_sub_lo : 0 ≤ ρ - h := by linarith
      have h_sub_xr : 0 ≤ x - ρ := by linarith
      have h_sub_1x : 0 ≤ 1 - x := by linarith
      have h_sub_1h : 0 ≤ 1 - h := by linarith
      have h_nonneg :
          0 ≤ (ρ - h) * ((1 - x) * (ρ - h) * (1 + ρ) + 2 * (x - ρ) * (1 - h) +
            (ρ + h) * (x - ρ) * (1 - x)) := by
        positivity
      linarith
  have hbox :
      Set.Icc (1 * t) (1 * t + t⁻¹) ×ˢ Set.Icc (α * t) (α * t + t⁻¹) ⊆
        gaussianWedge ρ x t := by
    rintro ⟨u, v⟩ ⟨hu, hv⟩
    refine ⟨by linarith [hu.1], ?_⟩
    dsimp only
    have hρu : ρ * t ≤ ρ * u := mul_le_mul_of_nonneg_left (by linarith [hu.1]) hρ_pos.le
    have hsv : Real.sqrt (1 - ρ ^ 2) * (α * t) ≤ Real.sqrt (1 - ρ ^ 2) * v :=
      mul_le_mul_of_nonneg_left hv.1 (Real.sqrt_nonneg _)
    suffices hcorner : x * t ≤ ρ * t + Real.sqrt (1 - ρ ^ 2) * (α * t) by linarith
    dsimp only [α]
    split_ifs with hle
    · simp only [ zero_mul, mul_zero, add_zero]
      exact mul_le_mul_of_nonneg_right hle ht0.le
    · push_neg at hle
      have hρ1 : ρ < 1 := lt_of_lt_of_le hle hx_hi
      have h1ρ2 : 0 < 1 - ρ ^ 2 := by nlinarith
      have hs_ne : Real.sqrt (1 - ρ ^ 2) ≠ 0 := (Real.sqrt_pos.mpr h1ρ2).ne'
      have hcancel : Real.sqrt (1 - ρ ^ 2) * ((x - ρ) / Real.sqrt (1 - ρ ^ 2) * t) = (x - ρ) * t := by
        field_simp [hs_ne]
      rw [hcancel]
      linarith
  have hmono :
      (stdNormal.prod stdNormal).real
          (Set.Icc (1 * t) (1 * t + t⁻¹) ×ˢ Set.Icc (α * t) (α * t + t⁻¹)) ≤
        (stdNormal.prod stdNormal).real (gaussianWedge ρ x t) :=
    MeasureTheory.measureReal_mono hbox
  rw [MeasureTheory.measureReal_prod_prod] at hmono
  have hI1 := stdGaussian_Icc_ge (a := 1) zero_le_one le_rfl ht
  have hIα := stdGaussian_Icc_ge hα0 hα1 ht
  have hprod :
      (Real.exp (-3 / 2) / Real.sqrt (2 * Real.pi) * t⁻¹ * Real.exp (-(1 ^ 2 * t ^ 2 / 2))) *
          (Real.exp (-3 / 2) / Real.sqrt (2 * Real.pi) * t⁻¹ * Real.exp (-(α ^ 2 * t ^ 2 / 2))) ≤
        stdNormal.real (Set.Icc (1 * t) (1 * t + t⁻¹)) *
          stdNormal.real (Set.Icc (α * t) (α * t + t⁻¹)) :=
    mul_le_mul hI1 hIα (by positivity) MeasureTheory.measureReal_nonneg
  refine le_trans ?_ (hprod.trans hmono)
  have h2pi_pos : 0 < 2 * Real.pi := by positivity
  have hsqrt_sq : Real.sqrt (2 * Real.pi) * Real.sqrt (2 * Real.pi) = 2 * Real.pi :=
    Real.mul_self_sqrt h2pi_pos.le
  have hexp3 : Real.exp (-3 / 2) * Real.exp (-3 / 2) = Real.exp (-3) := by
    rw [← Real.exp_add]
    norm_num
  have hzpow : t ^ (-2 : ℤ) = t⁻¹ * t⁻¹ := by
    rw [zpow_neg, zpow_two, mul_inv]
  have hexp_mono :
      Real.exp (-(UL.I_h h x * t ^ 2 / 2)) ≤ Real.exp (-((1 + α ^ 2) * t ^ 2 / 2)) := by
    apply Real.exp_le_exp.mpr
    nlinarith
  calc
    (Real.exp (-3) / (2 * Real.pi)) * t ^ (-2 : ℤ) * Real.exp (-(UL.I_h h x * t ^ 2 / 2))
      ≤ (Real.exp (-3) / (2 * Real.pi)) * t ^ (-2 : ℤ) * Real.exp (-((1 + α ^ 2) * t ^ 2 / 2)) :=
        mul_le_mul_of_nonneg_left hexp_mono (by positivity)
    _ = (Real.exp (-3 / 2) / Real.sqrt (2 * Real.pi) * t⁻¹ * Real.exp (-(1 ^ 2 * t ^ 2 / 2))) *
          (Real.exp (-3 / 2) / Real.sqrt (2 * Real.pi) * t⁻¹ * Real.exp (-(α ^ 2 * t ^ 2 / 2))) := by
        have hdiv :
            Real.exp (-3) / (2 * Real.pi) =
              (Real.exp (-3 / 2) / Real.sqrt (2 * Real.pi)) *
                (Real.exp (-3 / 2) / Real.sqrt (2 * Real.pi)) := by
          rw [div_mul_div_comm, hexp3, hsqrt_sq]
        have hexp_combine :
            Real.exp (-((1 + α ^ 2) * t ^ 2 / 2)) =
              Real.exp (-(1 ^ 2 * t ^ 2 / 2)) * Real.exp (-(α ^ 2 * t ^ 2 / 2)) := by
          rw [← Real.exp_add]
          congr 1
          ring
        rw [hdiv, hzpow, hexp_combine]
        ring

end UL.Proof_lem_6_2
