import Mathlib
import UL.Def.def_6_1_gaussian_filter
set_option autoImplicit false

open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal Real

namespace UL.Proof_lem_6_2

/-- Standard 1D normal measure `𝒩(0, 1)`. -/
noncomputable abbrev stdNormal : Measure ℝ := gaussianReal 0 1

/-- The standard `d`-dimensional Gaussian measure equals `(Measure.pi ...).map (WithLp.toLp 2)`. -/
theorem stdGaussianMeasure_eq_map_toLp (d : ℕ) :
    UL.stdGaussianMeasure d =
      (Measure.pi fun _ : Fin d => stdNormal).map (WithLp.toLp 2) := by
  rfl

instance isProbabilityMeasure_stdGaussianMeasure (d : ℕ) :
    IsProbabilityMeasure (UL.stdGaussianMeasure d) := by
  unfold UL.stdGaussianMeasure
  exact Measure.isProbabilityMeasure_map (by fun_prop)

/-- Characteristic function of `stdNormal` at `u : ℝ`. -/
theorem charFun_stdNormal (u : ℝ) :
    charFun stdNormal u = Complex.exp (-((u : ℂ) ^ 2) / 2) := by
  rw [ProbabilityTheory.charFun_gaussianReal]
  simp only [Complex.ofReal_zero, mul_zero, zero_mul, zero_sub, NNReal.coe_one,
    Complex.ofReal_one, one_mul]
  congr 1
  ring

/-- Characteristic function of `stdGaussianMeasure d` at `v ∈ ℝ^d`. -/
theorem charFun_stdGaussianMeasure (d : ℕ) (v : EuclideanSpace ℝ (Fin d)) :
    charFun (UL.stdGaussianMeasure d) v = Complex.exp (-((‖v‖ : ℂ) ^ 2) / 2) := by
  rw [stdGaussianMeasure_eq_map_toLp, MeasureTheory.charFun_pi]
  simp_rw [charFun_stdNormal]
  have hprod :
      (∏ i : Fin d, Complex.exp (-((v i : ℂ) ^ 2) / 2)) =
        Complex.exp (∑ i : Fin d, (-((v i : ℂ) ^ 2) / 2)) := by
    rw [Complex.exp_sum]
  rw [hprod]
  congr 1
  have hnorm : ‖v‖ ^ 2 = ∑ i : Fin d, (v i) ^ 2 := by
    rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
    refine Finset.sum_congr rfl fun i _ => ?_
    simp [sq]
  have hnormC : ((‖v‖ : ℂ) ^ 2) = ∑ i : Fin d, ((v i : ℂ) ^ 2) := by
    exact_mod_cast hnorm
  rw [hnormC, ← Finset.sum_neg_distrib, ← Finset.sum_div]

/-- For any unit vector `p ∈ ℝ^d`, `⟪G, p⟫ ~ 𝒩(0, 1)` under `G ~ stdGaussianMeasure d`. -/
theorem map_inner_stdGaussianMeasure {d : ℕ}
    (p : EuclideanSpace ℝ (Fin d)) (hp : UL.IsUnitVec p) :
    (UL.stdGaussianMeasure d).map (fun G => inner ℝ G p) = stdNormal := by
  have hp1 : ‖p‖ = 1 := hp
  have hmeas : Measurable (fun G : EuclideanSpace ℝ (Fin d) => inner ℝ G p) :=
    (continuous_id.inner continuous_const).measurable
  haveI : IsProbabilityMeasure ((UL.stdGaussianMeasure d).map (fun G => inner ℝ G p)) :=
    Measure.isProbabilityMeasure_map hmeas.aemeasurable
  apply Measure.ext_of_charFun
  ext u
  rw [charFun_apply_real, integral_map hmeas.aemeasurable (by fun_prop)]
  have h_eq :
      (∫ G, Complex.exp ((u : ℂ) * (inner ℝ G p : ℂ) * Complex.I) ∂UL.stdGaussianMeasure d) =
        charFun (UL.stdGaussianMeasure d) (u • p) := by
    rw [charFun_apply]
    refine integral_congr_ae (ae_of_all _ fun G => ?_)
    dsimp only
    rw [inner_smul_right]
    push_cast
    ring_nf
  rw [h_eq, charFun_stdGaussianMeasure, charFun_stdNormal]
  have hnorm : ‖u • p‖ ^ 2 = u ^ 2 := by
    rw [norm_smul, hp1, mul_one, Real.norm_eq_abs, sq_abs]
  have hnormC : ((‖u • p‖ : ℂ) ^ 2) = (u : ℂ) ^ 2 := by
    exact_mod_cast hnorm
  rw [hnormC]

/-- For orthonormal unit vectors `p, q ∈ ℝ^d`, `(⟪G, p⟫, ⟪G, q⟫) ~ 𝒩(0, 1) ⊗ 𝒩(0, 1)`. -/
theorem map_pair_inner_stdGaussianMeasure {d : ℕ}
    (p q : EuclideanSpace ℝ (Fin d))
    (hp : UL.IsUnitVec p) (hq : UL.IsUnitVec q) (hpq : inner ℝ p q = 0) :
    (UL.stdGaussianMeasure d).map (fun G => (inner ℝ G p, inner ℝ G q)) =
      stdNormal.prod stdNormal := by
  have hp1 : ‖p‖ = 1 := hp
  have hq1 : ‖q‖ = 1 := hq
  let f : EuclideanSpace ℝ (Fin d) → ℝ × ℝ := fun G => (inner ℝ G p, inner ℝ G q)
  have hf : Measurable f :=
    ((continuous_id.inner continuous_const).prodMk (continuous_id.inner continuous_const)).measurable
  have hg : Measurable (WithLp.toLp 2 : ℝ × ℝ → WithLp 2 (ℝ × ℝ)) :=
    (MeasurableEquiv.toLp 2 (ℝ × ℝ)).measurable
  haveI : IsProbabilityMeasure ((UL.stdGaussianMeasure d).map f) :=
    Measure.isProbabilityMeasure_map hf.aemeasurable
  rw [← MeasureTheory.charFun_eq_prod_iff]
  intro w
  set a : ℝ := (WithLp.ofLp w).1
  set b : ℝ := (WithLp.ofLp w).2
  have hmap :
      (((UL.stdGaussianMeasure d).map f).map (WithLp.toLp 2)) =
        (UL.stdGaussianMeasure d).map ((WithLp.toLp 2 : ℝ × ℝ → WithLp 2 (ℝ × ℝ)) ∘ f) :=
    Measure.map_map hg hf
  rw [hmap, charFun_apply, integral_map (hg.comp hf).aemeasurable (by fun_prop)]
  have h_eq :
      (∫ G, Complex.exp ((inner ℝ (((WithLp.toLp 2 : ℝ × ℝ → WithLp 2 (ℝ × ℝ)) ∘ f) G) w : ℂ) * Complex.I)
          ∂UL.stdGaussianMeasure d) =
        charFun (UL.stdGaussianMeasure d) (a • p + b • q) := by
    rw [charFun_apply]
    refine integral_congr_ae (ae_of_all _ fun G => ?_)
    dsimp only
    have hinner :
        inner ℝ (((WithLp.toLp 2 : ℝ × ℝ → WithLp 2 (ℝ × ℝ)) ∘ f) G) w =
          inner ℝ G (a • p + b • q) := by
      simp only [Function.comp_apply, f, WithLp.prod_inner_apply,
        RCLike.inner_apply, conj_trivial, inner_add_right, inner_smul_right, a, b]
    rw [hinner]
  rw [h_eq, charFun_stdGaussianMeasure, charFun_stdNormal, charFun_stdNormal, ← Complex.exp_add]
  congr 1
  have hnorm : ‖a • p + b • q‖ ^ 2 = a ^ 2 + b ^ 2 := by
    rw [norm_add_sq_real, norm_smul, norm_smul, hp1, hq1, mul_one, mul_one,
      Real.norm_eq_abs, Real.norm_eq_abs, sq_abs, sq_abs,
      inner_smul_left, inner_smul_right, hpq]
    ring
  have hnormC : ((‖a • p + b • q‖ : ℂ) ^ 2) = (a : ℂ) ^ 2 + (b : ℂ) ^ 2 := by
    exact_mod_cast hnorm
  rw [hnormC]
  ring

/-- 2D wedge `{ (u, v) | t ≤ u ∧ x * t ≤ ρ * u + √(1 - ρ^2) * v }`. -/
def gaussianWedge (ρ x t : ℝ) : Set (ℝ × ℝ) :=
  {uv : ℝ × ℝ | t ≤ uv.1 ∧ x * t ≤ ρ * uv.1 + Real.sqrt (1 - ρ ^ 2) * uv.2}

theorem measurableSet_gaussianWedge (ρ x t : ℝ) : MeasurableSet (gaussianWedge ρ x t) := by
  unfold gaussianWedge
  have h1 : MeasurableSet {uv : ℝ × ℝ | t ≤ uv.1} :=
    measurableSet_le measurable_const measurable_fst
  have h2 : MeasurableSet {uv : ℝ × ℝ | x * t ≤ ρ * uv.1 + Real.sqrt (1 - ρ ^ 2) * uv.2} :=
    measurableSet_le measurable_const
      ((measurable_const.mul measurable_fst).add (measurable_const.mul measurable_snd))
  exact h1.inter h2

/-- Marginal data probability equals `stdNormal.real (Set.Ici t)` for every unit vector `p`. -/
theorem gaussianDataProb_eq {d : ℕ} (t : ℝ) (p : EuclideanSpace ℝ (Fin d))
    (hp : UL.IsUnitVec p) :
    UL.gaussianDataProb t p = stdNormal.real (Set.Ici t) := by
  unfold UL.gaussianDataProb UL.gaussianDataTest
  have hmeas : Measurable (fun G : EuclideanSpace ℝ (Fin d) => inner ℝ G p) :=
    (continuous_id.inner continuous_const).measurable
  rw [← map_inner_stdGaussianMeasure p hp, MeasureTheory.measureReal_def,
    MeasureTheory.measureReal_def, Measure.map_apply hmeas measurableSet_Ici]
  rfl

/-- Marginal query probability equals `stdNormal.real (Set.Ici (x * t))` for every unit vector `z`. -/
theorem gaussianQueryProb_eq {d : ℕ} (x t : ℝ) (z : EuclideanSpace ℝ (Fin d))
    (hz : UL.IsUnitVec z) :
    UL.gaussianQueryProb x t z = stdNormal.real (Set.Ici (x * t)) := by
  unfold UL.gaussianQueryProb UL.gaussianQueryTest
  have hmeas : Measurable (fun G : EuclideanSpace ℝ (Fin d) => inner ℝ G z) :=
    (continuous_id.inner continuous_const).measurable
  rw [← map_inner_stdGaussianMeasure z hz, MeasureTheory.measureReal_def,
    MeasureTheory.measureReal_def, Measure.map_apply hmeas measurableSet_Ici]
  rfl

/-- Joint probability equals `(stdNormal.prod stdNormal).real (gaussianWedge (inner ℝ p z) x t)`
for all unit vectors `p, z ∈ ℝ^d`. -/
theorem gaussianJointProb_eq_wedge {d : ℕ} (x t : ℝ)
    (p z : EuclideanSpace ℝ (Fin d)) (hp : UL.IsUnitVec p) (hz : UL.IsUnitVec z) :
    UL.gaussianJointProb x t p z =
      (stdNormal.prod stdNormal).real (gaussianWedge (inner ℝ p z) x t) := by
  have hp1 : ‖p‖ = 1 := hp
  have hz1 : ‖z‖ = 1 := hz
  set ρ : ℝ := inner ℝ p z
  set w : EuclideanSpace ℝ (Fin d) := z - ρ • p
  have hpw : inner ℝ p w = 0 := by
    simp only [w, inner_sub_right, inner_smul_right, real_inner_self_eq_norm_sq, hp1, one_pow,
      mul_one, ρ, sub_self]
  have hw_sq : ‖w‖ ^ 2 = 1 - ρ ^ 2 := by
    have hsub : ‖z - ρ • p‖ ^ 2 = ‖z‖ ^ 2 - 2 * inner ℝ z (ρ • p) + ‖ρ • p‖ ^ 2 :=
      norm_sub_sq_real z (ρ • p)
    rw [show w = z - ρ • p from rfl, hsub, hz1, norm_smul, hp1, mul_one, Real.norm_eq_abs, sq_abs,
      inner_smul_right, real_inner_comm]
    change 1 ^ 2 - 2 * (ρ * ρ) + ρ ^ 2 = 1 - ρ ^ 2
    ring
  have hsqrt : Real.sqrt (1 - ρ ^ 2) = ‖w‖ := by
    rw [← hw_sq, Real.sqrt_sq (norm_nonneg w)]
  by_cases hw0 : ‖w‖ = 0
  · have hw_zero : w = 0 := norm_eq_zero.mp hw0
    have hz_eq : z = ρ • p := sub_eq_zero.mp hw_zero
    have hmeas1 : Measurable (fun G : EuclideanSpace ℝ (Fin d) => inner ℝ G p) :=
      (continuous_id.inner continuous_const).measurable
    let S : Set ℝ := {u : ℝ | t ≤ u ∧ x * t ≤ ρ * u}
    have hS : MeasurableSet S :=
      (measurableSet_le measurable_const measurable_id).inter
        (measurableSet_le measurable_const (measurable_const.mul measurable_id))
    have hpre1 :
        {G : EuclideanSpace ℝ (Fin d) | UL.gaussianDataTest t G p ∧ UL.gaussianQueryTest x t G z} =
          (fun G => inner ℝ G p) ⁻¹' S := by
      ext G
      simp [UL.gaussianDataTest, UL.gaussianQueryTest, hz_eq, inner_smul_right, S]
    have hwedge_prod : gaussianWedge ρ x t = S ×ˢ (Set.univ : Set ℝ) := by
      ext ⟨u, v⟩
      simp [gaussianWedge, hsqrt, hw0, S]
    unfold UL.gaussianJointProb
    rw [hpre1, MeasureTheory.measureReal_def, ← Measure.map_apply hmeas1 hS,
      map_inner_stdGaussianMeasure p hp, ← MeasureTheory.measureReal_def,
      hwedge_prod, MeasureTheory.measureReal_prod_prod]
    simp
  · have hw_pos : 0 < ‖w‖ := lt_of_le_of_ne (norm_nonneg w) (Ne.symm hw0)
    let q : EuclideanSpace ℝ (Fin d) := ‖w‖⁻¹ • w
    have hq : UL.IsUnitVec q := by
      unfold UL.IsUnitVec
      rw [norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hw_pos), inv_mul_cancel₀ hw0]
    have hpq : inner ℝ p q = 0 := by
      simp [q, inner_smul_right, hpw]
    have hz_decomp : z = ρ • p + ‖w‖ • q := by
      simp only [q, smul_smul, mul_inv_cancel₀ hw0, one_smul, w]
      abel
    let f : EuclideanSpace ℝ (Fin d) → ℝ × ℝ := fun G => (inner ℝ G p, inner ℝ G q)
    have hf : Measurable f :=
      ((continuous_id.inner continuous_const).prodMk (continuous_id.inner continuous_const)).measurable
    have hpre2 :
        {G : EuclideanSpace ℝ (Fin d) | UL.gaussianDataTest t G p ∧ UL.gaussianQueryTest x t G z} =
          f ⁻¹' gaussianWedge ρ x t := by
      ext G
      simp only [Set.mem_setOf_eq, Set.mem_preimage, UL.gaussianDataTest, UL.gaussianQueryTest,
        gaussianWedge, f, hsqrt]
      rw [hz_decomp, inner_add_right, inner_smul_right, inner_smul_right]
    unfold UL.gaussianJointProb
    rw [hpre2, MeasureTheory.measureReal_def, ← Measure.map_apply hf (measurableSet_gaussianWedge ρ x t),
      map_pair_inner_stdGaussianMeasure p q hp hq hpq, ← MeasureTheory.measureReal_def]

end UL.Proof_lem_6_2
