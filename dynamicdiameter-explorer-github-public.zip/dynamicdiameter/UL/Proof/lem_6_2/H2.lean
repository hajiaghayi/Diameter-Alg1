import Mathlib
set_option autoImplicit false

open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal Real

namespace UL.Proof_lem_6_2

/-- Standard 1D Gaussian upper tail bound `Pr[Z ≥ s] ≤ exp(-s^2 / 2)` for all `s ≥ 0`. -/
theorem stdGaussian_tail_le {s : ℝ} (hs : 0 ≤ s) :
    (gaussianReal 0 1).real (Set.Ici s) ≤ Real.exp (-(s ^ 2 / 2)) := by
  have h1 := ProbabilityTheory.measure_ge_le_exp_cgf (μ := gaussianReal 0 1) (X := id)
    s hs (ProbabilityTheory.integrable_exp_mul_gaussianReal s)
  have hcgf : cgf id (gaussianReal 0 1) s = s ^ 2 / 2 := by
    rw [ProbabilityTheory.cgf_gaussianReal (μ := 0) (v := 1) Measure.map_id]
    simp
  have hset : {ω : ℝ | s ≤ id ω} = Set.Ici s := rfl
  rw [← hset]
  refine h1.trans_eq ?_
  rw [hcgf]
  congr 1
  ring

/-- Standard 1D Gaussian lower bound on `[a * t, a * t + t⁻¹]` for `0 ≤ a ≤ 1` and `1 ≤ t`. -/
theorem stdGaussian_Icc_ge {a t : ℝ} (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (ht : 1 ≤ t) :
    Real.exp (-3 / 2) / Real.sqrt (2 * Real.pi) * t⁻¹ * Real.exp (-(a ^ 2 * t ^ 2 / 2)) ≤
      (gaussianReal 0 1).real (Set.Icc (a * t) (a * t + t⁻¹)) := by
  have ht0 : 0 < t := by linarith
  have ht_inv_nonneg : 0 ≤ t⁻¹ := inv_nonneg.mpr ht0.le
  have hab : a * t ≤ a * t + t⁻¹ := le_add_of_nonneg_right ht_inv_nonneg
  let S : Set ℝ := Set.Icc (a * t) (a * t + t⁻¹)
  have h_eq_int : (gaussianReal 0 1).real S = ∫ u in S, gaussianPDFReal 0 1 u := by
    rw [MeasureTheory.measureReal_def, gaussianReal_apply_eq_integral 0 one_ne_zero S,
      ENNReal.toReal_ofReal (integral_nonneg fun u => gaussianPDFReal_nonneg 0 1 u)]
  let c : ℝ := (Real.sqrt (2 * Real.pi))⁻¹ * Real.exp (-3 / 2 - a ^ 2 * t ^ 2 / 2)
  have hc_le : ∀ u ∈ S, c ≤ gaussianPDFReal 0 1 u := by
    intro u hu
    have hu_lo : 0 ≤ u := le_trans (mul_nonneg ha0 ht0.le) hu.1
    have hu_hi : u ≤ a * t + t⁻¹ := hu.2
    have ht_inv_le_one : t⁻¹ ≤ 1 := inv_le_one_of_one_le₀ ht
    have ht_inv_sq : (t⁻¹) ^ 2 ≤ 1 := by nlinarith
    have h_at_inv : a * t * t⁻¹ = a := by
      rw [mul_assoc, mul_inv_cancel₀ ht0.ne', mul_one]
    have hu_sq : u ^ 2 ≤ a ^ 2 * t ^ 2 + 3 := by
      have hsq1 : u ^ 2 ≤ (a * t + t⁻¹) ^ 2 := by nlinarith
      have hsq2 : (a * t + t⁻¹) ^ 2 = a ^ 2 * t ^ 2 + 2 * (a * t * t⁻¹) + (t⁻¹) ^ 2 := by ring
      rw [h_at_inv] at hsq2
      linarith
    have hexp : Real.exp (-3 / 2 - a ^ 2 * t ^ 2 / 2) ≤ Real.exp (-(u ^ 2 / 2)) := by
      apply Real.exp_le_exp.mpr
      linarith
    have hpdf : gaussianPDFReal 0 1 u = (Real.sqrt (2 * Real.pi))⁻¹ * Real.exp (-(u ^ 2 / 2)) := by
      unfold gaussianPDFReal
      simp [neg_div]
    rw [hpdf]
    exact mul_le_mul_of_nonneg_left hexp (by positivity)
  have hint : c * volume.real S ≤ ∫ u in S, gaussianPDFReal 0 1 u :=
    MeasureTheory.setIntegral_ge_of_const_le_real measurableSet_Icc measure_Icc_lt_top.ne
      hc_le (integrable_gaussianPDFReal 0 1).integrableOn
  have hvol : volume.real S = t⁻¹ := by
    simp [S, Real.volume_real_Icc_of_le hab]
  rw [h_eq_int]
  refine Eq.trans_le ?_ hint
  rw [hvol]
  dsimp only [c]
  rw [sub_eq_add_neg, Real.exp_add]
  ring

end UL.Proof_lem_6_2
