import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_6_search_interface
import UL.Def.def_C_3_birth_var
set_option autoImplicit false

/-! Definition (Sec. 7: The birth-pool interface) (paper p.31). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-! ### 1. Standing parameters, polynomial overhead factors `𝒫`, and target time bound `A(n)` -/

/-- Standing capacity and exponent conditions for the birth-pool interface: active-set capacity
`n ≥ 2`, extra space exponent `σ ≥ 0` above linear, and target time exponent `θ ≥ σ`. -/
def ValidBirthPoolExponents (n : ℕ) (σ θ : ℝ) : Prop :=
  2 ≤ n ∧ 0 ≤ σ ∧ σ ≤ θ

/-- Standing assumptions for a birth-pool index built on a frozen birth pool `P₀` of size `m`:
active-set capacity `n ≥ 2`, frozen birth-pool size `1 ≤ m ≤ n`, extra space exponent `σ ≥ 0`,
and target time exponent `θ ≥ σ`. -/
def ValidBirthPoolParams (n m : ℕ) (σ θ : ℝ) : Prop :=
  2 ≤ n ∧ 1 ≤ m ∧ m ≤ n ∧ 0 ≤ σ ∧ σ ≤ θ

/-- A factor family `P_fac : ℕ → (Fin k → ℝ) → ℝ` (in the unit-cost Arithmetic-RAM model where
coordinate bit-length does not enter) is a polynomial overhead factor `≥ 1` in ambient dimension
`d` and `k` nonnegative logarithmic parameters `logs : Fin k → ℝ`, with no hidden power of `n`. -/
def IsBirthPoolPolyInDimLogs {k : ℕ} (P_fac : ℕ → (Fin k → ℝ) → ℝ) : Prop :=
  ∃ (C : ℝ) (deg : ℕ), 1 ≤ C ∧
    ∀ (d : ℕ) (logs : Fin k → ℝ),
      (∀ j : Fin k, 0 ≤ logs j) →
        1 ≤ P_fac d logs ∧
        P_fac d logs ≤ C * ((d + 1 : ℝ) ^ deg) * ((1 + ∑ j : Fin k, logs j) ^ deg)

/-- A factor family `P_fac : ℕ → ℕ → (Fin k → ℝ) → ℝ` is a polynomial overhead factor `≥ 1` in
ambient dimension `d`, input precision (coordinate bit-length) `B`, and `k` nonnegative logarithmic
parameters `logs : Fin k → ℝ`, with no hidden power of `n`. -/
def IsBirthPoolPolyInDimPrecLogs {k : ℕ} (P_fac : ℕ → ℕ → (Fin k → ℝ) → ℝ) : Prop :=
  ∃ (C : ℝ) (deg : ℕ), 1 ≤ C ∧
    ∀ (d B : ℕ) (logs : Fin k → ℝ),
      (∀ j : Fin k, 0 ≤ logs j) →
        1 ≤ P_fac d B logs ∧
        P_fac d B logs ≤
          C * ((d + 1 : ℝ) ^ deg) * ((B + 1 : ℝ) ^ deg) * ((1 + ∑ j : Fin k, logs j) ^ deg)

/-- Target time bound `A(n) = n^θ 𝒫` for capacity `n`, time exponent `θ`, and polynomial factor
`P_time`. -/
noncomputable def birthPoolTargetTime (n : ℕ) (θ P_time : ℝ) : ℝ :=
  (n : ℝ) ^ θ * P_time

/-- Space bound `m^{1+σ} 𝒫` for an index built on `m` points with extra space exponent `σ` and
polynomial factor `P_space`. -/
noncomputable def birthPoolSpaceBound (m : ℕ) (σ P_space : ℝ) : ℝ :=
  (m : ℝ) ^ (1 + σ) * P_space

/-- Construction work bound `m A(n) 𝒫` for an index built on `m` points with target time `A_n` and
polynomial factor `P_build`. -/
def birthPoolBuildWorkBound (m : ℕ) (A_n P_build : ℝ) : ℝ :=
  (m : ℝ) * A_n * P_build

/-- Deletion work bound `A(n) 𝒫` with target time `A_n` and polynomial factor `P_del`. -/
def birthPoolDeleteWorkBound (A_n P_del : ℝ) : ℝ :=
  A_n * P_del

/-- Query work bound `A(n) 𝒫` with target time `A_n` and polynomial factor `P_query`. -/
def birthPoolQueryWorkBound (A_n P_query : ℝ) : ℝ :=
  A_n * P_query

/-- Bundle of polynomial overhead factors `𝒫` for the birth-pool interface, allowing `𝒫` to vary
or increase between the target time bound `A(n) = n^θ P_time`, space bound `m^{1+σ} P_space`,
construction work bound `m A(n) P_build`, deletion work bound `A(n) P_del`, and query work bound
`A(n) P_query`. -/
structure BirthPoolPolyFactors where
  P_time : ℝ
  P_space : ℝ
  P_build : ℝ
  P_del : ℝ
  P_query : ℝ

/-- Validity of `BirthPoolPolyFactors` as multiplicative overhead factors (`≥ 1`). -/
def BirthPoolPolyFactors.Valid (facs : BirthPoolPolyFactors) : Prop :=
  1 ≤ facs.P_time ∧
  1 ≤ facs.P_space ∧
  1 ≤ facs.P_build ∧
  1 ≤ facs.P_del ∧
  1 ≤ facs.P_query

/-- Specialization of `BirthPoolPolyFactors` using `P_time` in `A(n) = n^θ P_time` and a common
overhead factor `P_fac` across the space, build, deletion, and query bounds. -/
def BirthPoolPolyFactors.uniform (P_time P_fac : ℝ) : BirthPoolPolyFactors :=
  { P_time := P_time
    P_space := P_fac
    P_build := P_fac
    P_del := P_fac
    P_query := P_fac }

/-- Target time bound `A(n) = n^θ P_time` associated with `facs : BirthPoolPolyFactors`. -/
noncomputable def BirthPoolPolyFactors.targetTime
    (facs : BirthPoolPolyFactors) (n : ℕ) (θ : ℝ) : ℝ :=
  birthPoolTargetTime n θ facs.P_time

/-- Space bound `m^{1+σ} P_space` associated with `facs : BirthPoolPolyFactors`. -/
noncomputable def BirthPoolPolyFactors.spaceBound
    (facs : BirthPoolPolyFactors) (m : ℕ) (σ : ℝ) : ℝ :=
  birthPoolSpaceBound m σ facs.P_space

/-- Construction work bound `m A(n) P_build` associated with `facs : BirthPoolPolyFactors`. -/
noncomputable def BirthPoolPolyFactors.buildWorkBound
    (facs : BirthPoolPolyFactors) (m n : ℕ) (θ : ℝ) : ℝ :=
  birthPoolBuildWorkBound m (facs.targetTime n θ) facs.P_build

/-- Deletion work bound `A(n) P_del` associated with `facs : BirthPoolPolyFactors`. -/
noncomputable def BirthPoolPolyFactors.deleteWorkBound
    (facs : BirthPoolPolyFactors) (n : ℕ) (θ : ℝ) : ℝ :=
  birthPoolDeleteWorkBound (facs.targetTime n θ) facs.P_del

/-- Query work bound `A(n) P_query` associated with `facs : BirthPoolPolyFactors`. -/
noncomputable def BirthPoolPolyFactors.queryWorkBound
    (facs : BirthPoolPolyFactors) (n : ℕ) (θ : ℝ) : ℝ :=
  birthPoolQueryWorkBound (facs.targetTime n θ) facs.P_query

/-- Every component of `facFam : ℕ → (Fin k → ℝ) → BirthPoolPolyFactors` is a polynomial overhead
factor in ambient dimension `d` and the logarithmic parameters `logs`. -/
def IsPolyBirthPoolFactorFamily2 {k : ℕ}
    (facFam : ℕ → (Fin k → ℝ) → BirthPoolPolyFactors) : Prop :=
  IsBirthPoolPolyInDimLogs (fun d logs => (facFam d logs).P_time) ∧
  IsBirthPoolPolyInDimLogs (fun d logs => (facFam d logs).P_space) ∧
  IsBirthPoolPolyInDimLogs (fun d logs => (facFam d logs).P_build) ∧
  IsBirthPoolPolyInDimLogs (fun d logs => (facFam d logs).P_del) ∧
  IsBirthPoolPolyInDimLogs (fun d logs => (facFam d logs).P_query)

/-- Every component of `facFam : ℕ → ℕ → (Fin k → ℝ) → BirthPoolPolyFactors` is a polynomial
overhead factor in ambient dimension `d`, input precision `B`, and the logarithmic parameters
`logs`. -/
def IsPolyBirthPoolFactorFamily3 {k : ℕ}
    (facFam : ℕ → ℕ → (Fin k → ℝ) → BirthPoolPolyFactors) : Prop :=
  IsBirthPoolPolyInDimPrecLogs (fun d B logs => (facFam d B logs).P_time) ∧
  IsBirthPoolPolyInDimPrecLogs (fun d B logs => (facFam d B logs).P_space) ∧
  IsBirthPoolPolyInDimPrecLogs (fun d B logs => (facFam d B logs).P_build) ∧
  IsBirthPoolPolyInDimPrecLogs (fun d B logs => (facFam d B logs).P_del) ∧
  IsBirthPoolPolyInDimPrecLogs (fun d B logs => (facFam d B logs).P_query)

/-! ### 2. Variant (1A): Sample-space Monte Carlo capped birth-pool interface -/

/-- Halting outcome of constructing a Monte Carlo birth-pool index: immutable birth data
`birthState`, initial live index state `initState` on `P₀`, construction work `work`, and peak
space `peakSpace`. -/
structure MCBirthOutcome (BirthState IndexState : Type*) where
  birthState : BirthState
  initState : IndexState
  work : ℕ
  peakSpace : ℕ

/-- Outcome of deleting an active point from a birth-pool index: updated index state `nextState`,
deletion work `work`, and peak space `peakSpace`. -/
structure MCDeleteOutcome (IndexState : Type*) where
  nextState : IndexState
  work : ℕ
  peakSpace : ℕ

/-- Outcome of executing a search query on a birth-pool index: returned answer (`some i` or `none`
for `NONE`), query work `work`, and peak space `peakSpace`. -/
structure MCQueryOutcome (ι : Type*) where
  answer : Option ι
  work : ℕ
  peakSpace : ℕ

/-- Sample-space operational bundle of a Monte Carlo capped birth-pool index built on a frozen
birth pool `gen : SearchGeneration ι d_s` (fixed prior to the random draw `ω : Ω`), supporting
deletions of members of `P₀` and search queries on surviving subsets `S ⊆ P₀`. -/
structure CappedBirthPoolIndex (Ω ι : Type*) (d_s : ℕ) (IndexState : Type*) where
  gen : SearchGeneration ι d_s
  IsValidState : Ω → Finset ι → IndexState → Prop
  initState : Ω → IndexState
  buildWork : Ω → ℕ
  buildPeakSpace : Ω → ℕ
  delete : Ω → Finset ι → IndexState → ι → MCDeleteOutcome IndexState
  runQuery : Ω → Finset ι → IndexState → SearchQuery ι d_s → MCQueryOutcome ι

/-- Deterministic resource caps and single-event correctness for `idx : CappedBirthPoolIndex`:
1. `n ≥ 2`, `1 ≤ |P₀| ≤ n`, `0 ≤ σ ≤ θ`, and valid polynomial overhead factors `facs`;
2. On every sample `ω : Ω` (unconditionally), construction uses at most `m^{1+σ} P_space` space and
   `m A(n) P_build` work, every deletion of `i ∈ S` from a valid surviving state preserves state
   validity on `S \ {i}` within `m^{1+σ} P_space` space and `A(n) P_del` work, and every query on
   a valid surviving state uses at most `m^{1+σ} P_space` space and `A(n) P_query` work;
3. One generation success event `successEvent : Set Ω` guarantees full search correctness
   `idx.gen.IsCorrectAnswer S q` simultaneously for all surviving subsets `S ⊆ P₀`, all valid
   states for `S`, all unit query directions, and all compatible predicates (`idx.gen.IsCompatible S q`). -/
def SatisfiesCappedBirthPoolOnEvent
    {Ω ι : Type*} [DecidableEq ι] {d_s : ℕ} {IndexState : Type*}
    (n : ℕ) (σ θ : ℝ) (facs : BirthPoolPolyFactors)
    (successEvent : Set Ω)
    (idx : CappedBirthPoolIndex Ω ι d_s IndexState) : Prop :=
  let m := idx.gen.m
  ValidBirthPoolParams n m σ θ ∧
  facs.Valid ∧
  (∀ ω : Ω,
    idx.IsValidState ω idx.gen.P₀ (idx.initState ω) ∧
    (idx.buildWork ω : ℝ) ≤ facs.buildWorkBound m n θ ∧
    (idx.buildPeakSpace ω : ℝ) ≤ facs.spaceBound m σ) ∧
  (∀ (ω : Ω) (S : Finset ι) (st : IndexState) (i : ι),
    idx.gen.IsSurvivingSubset S →
    idx.IsValidState ω S st →
    i ∈ S →
      let dOut := idx.delete ω S st i
      idx.IsValidState ω (S.erase i) dOut.nextState ∧
      (dOut.work : ℝ) ≤ facs.deleteWorkBound n θ ∧
      (dOut.peakSpace : ℝ) ≤ facs.spaceBound m σ) ∧
  (∀ (ω : Ω) (S : Finset ι) (st : IndexState) (q : SearchQuery ι d_s),
    idx.gen.IsSurvivingSubset S →
    idx.IsValidState ω S st →
      let qOut := idx.runQuery ω S st q
      (qOut.work : ℝ) ≤ facs.queryWorkBound n θ ∧
      (qOut.peakSpace : ℝ) ≤ facs.spaceBound m σ) ∧
  (∀ ω ∈ successEvent, ∀ (S : Finset ι) (st : IndexState) (q : SearchQuery ι d_s),
    idx.gen.IsSurvivingSubset S →
    idx.IsValidState ω S st →
    idx.gen.IsCompatible S q →
      idx.gen.IsCorrectAnswer S q (idx.runQuery ω S st q).answer)

/-- Measure-theoretic Monte Carlo capped birth-pool interface on probability space `(Ω, μ)` with
generation failure probability bound `δ_fail ∈ [0, 1)`: there exists a single measurable generation
success event `successEvent` of probability `μ(successEvent) ≥ 1 - δ_fail` on which
`SatisfiesCappedBirthPoolOnEvent` holds. -/
def SatisfiesMeasureMonteCarloBirthPool
    {Ω ι : Type*} [MeasurableSpace Ω] [DecidableEq ι] {d_s : ℕ} {IndexState : Type*}
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsProbabilityMeasure μ]
    (n : ℕ) (σ θ δ_fail : ℝ) (facs : BirthPoolPolyFactors)
    (idx : CappedBirthPoolIndex Ω ι d_s IndexState) : Prop :=
  0 ≤ δ_fail ∧ δ_fail < 1 ∧
  ∃ successEvent : Set Ω,
    MeasurableSet successEvent ∧
    ENNReal.ofReal (1 - δ_fail) ≤ μ successEvent ∧
    SatisfiesCappedBirthPoolOnEvent n σ θ facs successEvent idx

/-! ### 3. Variant (1B): Exposed-randomness (`List Bool`) Monte Carlo capped birth-pool interface -/

/-- Operational bundle of a Monte Carlo deletion-only birth-pool search generation constructed on
`gen : SearchGeneration ι d_s` after conditioning on an adaptive execution history in
`ExecutionHistory d`, using prefix-free fresh random coin sequences `List Bool` and a single
generation birth success predicate `IsBirthSuccess`. -/
structure MonteCarloSearchGeneration (ι : Type*) (d d_s : ℕ)
    (BirthState IndexState : Type*) where
  gen : SearchGeneration ι d_s
  IsValidState : ExecutionHistory d → BirthState → Finset ι → IndexState → Prop
  IsBirthSuccess : ExecutionHistory d → BirthState → Prop
  buildWithBits :
    ExecutionHistory d → List Bool → Option (MCBirthOutcome BirthState IndexState)
  deleteWithBits :
    ExecutionHistory d → BirthState → Finset ι → IndexState → ι → List Bool →
      Option (MCDeleteOutcome IndexState)
  runQuery :
    BirthState → Finset ι → IndexState → SearchQuery ι d_s → MCQueryOutcome ι

/-- Construct a `MonteCarloSearchGeneration` whose deletion step is deterministic (consuming `[]`
random bits). -/
def MonteCarloSearchGeneration.ofDeterministicDelete
    {ι : Type*} {d d_s : ℕ} {BirthState IndexState : Type*}
    (gen : SearchGeneration ι d_s)
    (IsValidState : ExecutionHistory d → BirthState → Finset ι → IndexState → Prop)
    (IsBirthSuccess : ExecutionHistory d → BirthState → Prop)
    (buildWithBits :
      ExecutionHistory d → List Bool → Option (MCBirthOutcome BirthState IndexState))
    (deleteDet :
      BirthState → Finset ι → IndexState → ι → MCDeleteOutcome IndexState)
    (runQuery :
      BirthState → Finset ι → IndexState → SearchQuery ι d_s → MCQueryOutcome ι) :
    MonteCarloSearchGeneration ι d d_s BirthState IndexState :=
  { gen := gen
    IsValidState := IsValidState
    IsBirthSuccess := IsBirthSuccess
    buildWithBits := buildWithBits
    deleteWithBits := fun _ bState S st i bs =>
      match bs with
      | [] => some (deleteDet bState S st i)
      | _ :: _ => none
    runQuery := runQuery }

/-- Conditional probability (given `birthHist` at birth) that Monte Carlo index construction halts
over fresh fair coin flips `bs : List Bool`. -/
noncomputable def MonteCarloSearchGeneration.birthHaltProb
    {ι : Type*} {d d_s : ℕ} {BirthState IndexState : Type*}
    (inst : MonteCarloSearchGeneration ι d d_s BirthState IndexState)
    (birthHist : ExecutionHistory d) : ENNReal :=
  ∑' bs : List Bool,
    if (inst.buildWithBits birthHist bs).isSome then bitListProb bs else 0

/-- Conditional probability (given `stepHist`) that deleting `i ∈ S` halts over fresh fair coin
flips `bs : List Bool`. -/
noncomputable def MonteCarloSearchGeneration.deleteHaltProb
    {ι : Type*} {d d_s : ℕ} {BirthState IndexState : Type*}
    (inst : MonteCarloSearchGeneration ι d d_s BirthState IndexState)
    (stepHist : ExecutionHistory d) (bState : BirthState)
    (S : Finset ι) (st : IndexState) (i : ι) : ENNReal :=
  ∑' bs : List Bool,
    if (inst.deleteWithBits stepHist bState S st i bs).isSome then bitListProb bs else 0

/-- Conditional probability (given `birthHist` at birth) that construction halts on the single
generation birth success event `IsBirthSuccess birthHist bOut.birthState`. -/
noncomputable def MonteCarloSearchGeneration.birthSuccessProb
    {ι : Type*} {d d_s : ℕ} {BirthState IndexState : Type*}
    (inst : MonteCarloSearchGeneration ι d d_s BirthState IndexState)
    (birthHist : ExecutionHistory d) : ENNReal :=
  open Classical in
  ∑' bs : List Bool,
    match inst.buildWithBits birthHist bs with
    | some bOut =>
        if inst.IsBirthSuccess birthHist bOut.birthState then bitListProb bs else 0
    | none => 0

/-- Deterministic space/build/deletion/query caps, almost-sure termination, and simultaneous
on-event correctness at `birthHist` for `inst : MonteCarloSearchGeneration`. -/
def SatisfiesMonteCarloBirthPoolCapsAndEvent
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState IndexState : Type*}
    (n : ℕ) (σ θ : ℝ) (facs : BirthPoolPolyFactors)
    (birthHist : ExecutionHistory d)
    (inst : MonteCarloSearchGeneration ι d d_s BirthState IndexState) : Prop :=
  let m := inst.gen.m
  ValidBirthPoolParams n m σ θ ∧
  facs.Valid ∧
  -- (1) Prefix-free coin consumption, almost-sure halting, and deterministic build & space caps
  (∀ bs₁ bs₂ : List Bool, ∀ out₁ out₂,
    inst.buildWithBits birthHist bs₁ = some out₁ →
    inst.buildWithBits birthHist bs₂ = some out₂ →
    bs₁ <+: bs₂ → bs₁ = bs₂) ∧
  inst.birthHaltProb birthHist = 1 ∧
  (∀ bs : List Bool, ∀ bOut,
    inst.buildWithBits birthHist bs = some bOut →
      inst.IsValidState birthHist bOut.birthState inst.gen.P₀ bOut.initState ∧
      (bOut.work : ℝ) ≤ facs.buildWorkBound m n θ ∧
      (bOut.peakSpace : ℝ) ≤ facs.spaceBound m σ) ∧
  -- (2) Prefix-free coin consumption, almost-sure halting, and deterministic deletion & space caps
  (∀ (stepHist : ExecutionHistory d) (bState : BirthState) (S : Finset ι)
     (st : IndexState) (i : ι),
    inst.gen.IsSurvivingSubset S →
    inst.IsValidState birthHist bState S st →
    i ∈ S →
      (∀ bs₁ bs₂ : List Bool, ∀ out₁ out₂,
        inst.deleteWithBits stepHist bState S st i bs₁ = some out₁ →
        inst.deleteWithBits stepHist bState S st i bs₂ = some out₂ →
        bs₁ <+: bs₂ → bs₁ = bs₂) ∧
      inst.deleteHaltProb stepHist bState S st i = 1 ∧
      (∀ bs : List Bool, ∀ dOut,
        inst.deleteWithBits stepHist bState S st i bs = some dOut →
          inst.IsValidState birthHist bState (S.erase i) dOut.nextState ∧
          (dOut.work : ℝ) ≤ facs.deleteWorkBound n θ ∧
          (dOut.peakSpace : ℝ) ≤ facs.spaceBound m σ)) ∧
  -- (3) Deterministic query work and space caps across all valid states and queries
  (∀ (bState : BirthState) (S : Finset ι) (st : IndexState) (q : SearchQuery ι d_s),
    inst.gen.IsSurvivingSubset S →
    inst.IsValidState birthHist bState S st →
      let qOut := inst.runQuery bState S st q
      (qOut.work : ℝ) ≤ facs.queryWorkBound n θ ∧
      (qOut.peakSpace : ℝ) ≤ facs.spaceBound m σ) ∧
  -- (4) Single generation birth success event valid simultaneously for all surviving subsets,
  -- all unit query directions, and all compatible predicates
  (∀ (bState : BirthState) (S : Finset ι) (st : IndexState) (q : SearchQuery ι d_s),
    inst.IsBirthSuccess birthHist bState →
    inst.gen.IsSurvivingSubset S →
    inst.IsValidState birthHist bState S st →
    inst.gen.IsCompatible S q →
      inst.gen.IsCorrectAnswer S q (inst.runQuery bState S st q).answer)

/-- Complete history-conditioned Monte Carlo capped birth-pool interface at `birthHist` with
generation failure probability bound `δ_fail ∈ [0, 1)`. -/
def SatisfiesMonteCarloBirthPoolAtHistory
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState IndexState : Type*}
    (n : ℕ) (σ θ δ_fail : ℝ) (facs : BirthPoolPolyFactors)
    (birthHist : ExecutionHistory d)
    (inst : MonteCarloSearchGeneration ι d d_s BirthState IndexState) : Prop :=
  0 ≤ δ_fail ∧ δ_fail < 1 ∧
  SatisfiesMonteCarloBirthPoolCapsAndEvent n σ θ facs birthHist inst ∧
  ENNReal.ofReal (1 - δ_fail) ≤ inst.birthSuccessProb birthHist

/-- Uniform history-conditioned Monte Carlo capped birth-pool interface across all preceding
adaptive execution histories `birthHist : ExecutionHistory d`. -/
def SatisfiesMonteCarloBirthPoolUniform
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState IndexState : Type*}
    (n : ℕ) (σ θ δ_fail : ℝ) (facs : BirthPoolPolyFactors)
    (inst : MonteCarloSearchGeneration ι d d_s BirthState IndexState) : Prop :=
  ∀ birthHist : ExecutionHistory d,
    SatisfiesMonteCarloBirthPoolAtHistory n σ θ δ_fail facs birthHist inst

/-! ### 4. Variant (2): Certified birth-pool interface (always-correct birth-variable interface) -/

/-- Certified birth-pool interface at `birthHist` with per-bound polynomial overhead factors
`facs : BirthPoolPolyFactors` and target time bound `A(n) = n^θ P_time`:
always-correct generation `inst : CertifiedSearchGeneration` satisfying `n ≥ 2`, `1 ≤ m ≤ n`,
`0 ≤ σ ≤ θ`, deterministic space cap `m^{1+σ} P_space`, conditional expected construction and
internal phase-rebuild work `≤ m A(n) P_build`, and nonnegative birth-random query-work variables
`(Z_z)_{z ∈ N}` with `E[Z_z | birthHist] ≤ A(n) P_query` deterministically upper-bounding query
work across all surviving subsets `S ⊆ P₀`, `δ`-compatible predicates, and accepted inverse phases. -/
def SatisfiesCertifiedBirthPoolFactorsAtHistory
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    (n : ℕ) (σ θ netLogBound : ℝ) (facs : BirthPoolPolyFactors)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (birthHist : ExecutionHistory d)
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState) : Prop :=
  let m := inst.gen.m
  ValidBirthPoolParams n m σ θ ∧
  facs.Valid ∧
  0 ≤ inst.δ ∧
  IsValidImplicitDirectionNet N netLogBound ∧
  (∀ bs₁ bs₂ : List Bool, ∀ out₁ out₂,
    inst.buildWithBits birthHist bs₁ = some out₁ →
    inst.buildWithBits birthHist bs₂ = some out₂ →
    bs₁ <+: bs₂ → bs₁ = bs₂) ∧
  inst.birthHaltProb birthHist = 1 ∧
  (∀ bs : List Bool, ∀ bOut,
    inst.buildWithBits birthHist bs = some bOut →
      inst.IsAcceptedBirth birthHist bOut.birthState ∧
      inst.IsAcceptedPhase birthHist bOut.birthState inst.gen.P₀ bOut.initPhase ∧
      (bOut.peakSpace : ℝ) ≤ facs.spaceBound m σ) ∧
  (∀ (stepHist : ExecutionHistory d) (bState : BirthState) (S : Finset ι)
     (ph : PhaseState) (i : ι),
    inst.IsAcceptedBirth birthHist bState →
    inst.gen.IsSurvivingSubset S →
    inst.IsAcceptedPhase birthHist bState S ph →
    i ∈ S →
      (∀ bs₁ bs₂ : List Bool, ∀ out₁ out₂,
        inst.deleteWithBits stepHist bState S ph i bs₁ = some out₁ →
        inst.deleteWithBits stepHist bState S ph i bs₂ = some out₂ →
        bs₁ <+: bs₂ → bs₁ = bs₂) ∧
      inst.deleteHaltProb stepHist bState S ph i = 1 ∧
      (∀ bs : List Bool, ∀ dOut,
        inst.deleteWithBits stepHist bState S ph i bs = some dOut →
          inst.IsAcceptedPhase birthHist bState (S.erase i) dOut.nextPhase ∧
          (dOut.peakSpace : ℝ) ≤ facs.spaceBound m σ)) ∧
  (∀ delAdv : CertifiedDeletionAdversary ι d BirthState PhaseState,
    IsValidCertifiedDeletionAdversary inst birthHist delAdv →
      ∀ k : ℕ,
        inst.expectedTotalBuildAndRebuildWork birthHist delAdv k ≠ ⊤ ∧
        (inst.expectedTotalBuildAndRebuildWork birthHist delAdv k).toReal ≤
          facs.buildWorkBound m n θ) ∧
  (∀ (bState : BirthState) (S : Finset ι) (ph : PhaseState) (q : SearchQuery ι d_s),
    inst.IsAcceptedBirth birthHist bState →
    inst.gen.IsSurvivingSubset S →
    inst.IsAcceptedPhase birthHist bState S ph →
    IsCertifiedCompatible inst.gen inst.δ S q →
      let qOut := inst.runQuery bState S ph q
      inst.gen.IsCorrectAnswer S q qOut.answer ∧
      (qOut.peakSpace : ℝ) ≤ facs.spaceBound m σ) ∧
  (∀ (bState : BirthState) (z : EuclideanSpace ℝ (Fin d_s)),
    inst.IsAcceptedBirth birthHist bState → z ∈ N →
      0 ≤ inst.queryLabelCost bState z ∧
      (∀ i ∈ inst.gen.P₀, 0 ≤ inst.birthPointIncidenceCost bState z i)) ∧
  (∀ z ∈ N,
    inst.birthVarExpected birthHist z ≠ ⊤ ∧
    (inst.birthVarExpected birthHist z).toReal ≤ facs.queryWorkBound n θ) ∧
  (∀ (bState : BirthState) (S : Finset ι) (ph : PhaseState) (q : SearchQuery ι d_s),
    inst.IsAcceptedBirth birthHist bState →
    inst.gen.IsSurvivingSubset S →
    inst.IsAcceptedPhase birthHist bState S ph →
    IsCertifiedCompatible inst.gen inst.δ S q →
    q.z ∈ N →
      ((inst.runQuery bState S ph q).work : ℝ) ≤ inst.birthVar bState q.z)

/-- Certified birth-pool interface at `birthHist` on implicit direction net `N`, specializing the
abstract certified birth-variable search interface (`SatisfiesCertifiedBirthVarAtHistory` from
`UL.Def.def_C_3_birth_var`) to the Section 7 birth-pool parameters `ValidBirthPoolParams n m σ θ`
and target time bound `A(n) = n^θ P_time`. -/
def SatisfiesCertifiedBirthPoolAtHistory
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    (n : ℕ) (σ θ P_time P_fac netLogBound : ℝ)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (birthHist : ExecutionHistory d)
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState) : Prop :=
  ValidBirthPoolParams n inst.gen.m σ θ ∧
  1 ≤ P_time ∧ 1 ≤ P_fac ∧
  SatisfiesCertifiedBirthVarAtHistory n σ (birthPoolTargetTime n θ P_time) P_fac
    netLogBound N birthHist inst

/-- Uniform history-conditioned certified birth-pool interface on a fixed implicit direction net
`N` across all preceding execution histories `birthHist : ExecutionHistory d`. -/
def SatisfiesCertifiedBirthPoolOnNet
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    (n : ℕ) (σ θ P_time P_fac netLogBound : ℝ)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState) : Prop :=
  ValidBirthPoolParams n inst.gen.m σ θ ∧
  1 ≤ P_time ∧ 1 ≤ P_fac ∧
  SatisfiesCertifiedBirthVarOnNet n σ (birthPoolTargetTime n θ P_time) P_fac netLogBound N inst

/-- Certified birth-pool interface covering a query family `ActualQuery` at `birthHist` via
`SatisfiesCertifiedBirthVarInterface` with target time bound `A(n) = n^θ P_time`. -/
def SatisfiesCertifiedBirthPoolInterface
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    {ActualQuery : Type*}
    (n : ℕ) (σ θ P_time P_fac netLogBound : ℝ)
    (birthHist : ExecutionHistory d)
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (isCompatibleActual : Finset ι → ActualQuery → Prop)
    (hasActualTarget : Finset ι → ActualQuery → Prop)
    (actualAccept : ActualQuery → ι → Prop)
    (toNetQuery : ActualQuery → SearchQuery ι d_s) : Prop :=
  ValidBirthPoolParams n inst.gen.m σ θ ∧
  1 ≤ P_time ∧ 1 ≤ P_fac ∧
  SatisfiesCertifiedBirthVarInterface n σ (birthPoolTargetTime n θ P_time) P_fac
    netLogBound birthHist inst isCompatibleActual hasActualTarget actualAccept toNetQuery

/-- Padded-net certified birth-pool interface for original unit points in `ℝ^d` embedded into
`ℝ^{d+1}` (`d_s = d + 1`) at `birthHist` via `SatisfiesPaddedCertifiedBirthVarInterface` with
target time bound `A(n) = n^θ P_time`. -/
def SatisfiesPaddedCertifiedBirthPoolInterface
    {ι : Type*} [DecidableEq ι] {d : ℕ} {BirthState PhaseState : Type*}
    (n : ℕ) (σ θ P_time P_fac netLogBound : ℝ)
    (origPts : ι → EuclideanSpace ℝ (Fin d))
    (a b A_pad B_pad : ℝ)
    (birthHist : ExecutionHistory d)
    (inst : CertifiedSearchGeneration ι d (d + 1) BirthState PhaseState) : Prop :=
  ValidBirthPoolParams n inst.gen.m σ θ ∧
  1 ≤ P_time ∧ 1 ≤ P_fac ∧
  SatisfiesPaddedCertifiedBirthVarInterface n σ (birthPoolTargetTime n θ P_time) P_fac
    netLogBound origPts a b A_pad B_pad birthHist inst

end UL
-- Section 7 birth-pool interface.
