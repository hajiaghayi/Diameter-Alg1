import Mathlib
import UL.Def.def_halfspace_depth
set_option autoImplicit false

/-! Definition (Sec. 4: Birth pool, paraboloid lift, and variance certificate) (paper p.14). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- Embeds `(o, s) ∈ ℝ^d × ℝ` as a point in `ℝ^{d+1}` by appending `s` as the last coordinate
(`Fin.last d`). -/
def liftedPoint {d : ℕ} (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    EuclideanSpace ℝ (Fin (d + 1)) :=
  WithLp.toLp 2 (Fin.snoc (WithLp.ofLp o) s)

/-- Base projection `(o, s) ↦ o ∈ ℝ^d` of a point in `ℝ^{d+1}` onto its first `d` coordinates. -/
def liftedBase {d : ℕ} (z : EuclideanSpace ℝ (Fin (d + 1))) :
    EuclideanSpace ℝ (Fin d) :=
  WithLp.toLp 2 (Fin.init (WithLp.ofLp z))

/-- Height projection `(o, s) ↦ s ∈ ℝ` of a point in `ℝ^{d+1}` onto its last coordinate
(`Fin.last d`). -/
def liftedHeight {d : ℕ} (z : EuclideanSpace ℝ (Fin (d + 1))) : ℝ :=
  z (Fin.last d)

/-- The paraboloid lift mapping `p ∈ ℝ^d` to `p^+ = (p, ‖p‖^2) ∈ ℝ^{d+1}`. -/
noncomputable def paraboloidLift {d : ℕ} (p : EuclideanSpace ℝ (Fin d)) :
    EuclideanSpace ℝ (Fin (d + 1)) :=
  liftedPoint p (‖p‖ ^ 2)

/-- Lifts a finite indexed point set (birth set / birth pool) `P₀ : ι → ℝ^d` of size
`m = |P₀| = Fintype.card ι` indexwise to `P₀^+ : ι → ℝ^{d+1}`, `i ↦ (P₀ i)^+`. -/
noncomputable def paraboloidLiftSet {d : ℕ} {ι : Type*}
    (P₀ : ι → EuclideanSpace ℝ (Fin d)) : ι → EuclideanSpace ℝ (Fin (d + 1)) :=
  fun i => paraboloidLift (P₀ i)

/-- A point `z ∈ ℝ^{d+1}` is a positive-depth point of the lifted birth set `P₀^+` if
`depth_{P₀^+}(z) > 0`. -/
def IsPositiveDepthLift {d : ℕ} {ι : Type*} [Fintype ι]
    (P₀ : ι → EuclideanSpace ℝ (Fin d)) (z : EuclideanSpace ℝ (Fin (d + 1))) : Prop :=
  0 < halfspaceDepth (paraboloidLiftSet P₀) z

/-- The variance quantity `V = s - ‖o‖^2` associated with `z = (o, s) ∈ ℝ^d × ℝ`. -/
noncomputable def liftVariance {d : ℕ} (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) : ℝ :=
  s - ‖o‖ ^ 2

/-- The variance quantity `V = s - ‖o‖^2` read directly from a lifted point `z = (o, s) ∈ ℝ^{d+1}`. -/
noncomputable def liftedPointVariance {d : ℕ} (z : EuclideanSpace ℝ (Fin (d + 1))) : ℝ :=
  liftVariance (liftedBase z) (liftedHeight z)

end UL
