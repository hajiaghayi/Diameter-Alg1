import Mathlib
set_option autoImplicit false

/-! Definition (Sec. 1: Euclidean diameter and factor-c diameter pair) (paper p.2, Sec. 3 p.13).
Ambient space `ℝ^d` is represented as Mathlib's `EuclideanSpace ℝ (Fin d)` equipped with the
standard Euclidean `ℓ_2` norm `‖x - y‖`. -/

namespace UL

/-- For a finite point set `P ⊆ ℝ^d`, its Euclidean diameter `diam(P) = max_{x, y ∈ P} ‖x - y‖`,
equal to `0` when `|P| ≤ 1` (in particular `0` when `P = ∅`, and `‖x - x‖ = 0` when `|P| = 1`). -/
noncomputable def euclideanDiam {d : ℕ} (P : Finset (EuclideanSpace ℝ (Fin d))) : ℝ :=
  if h : P.Nonempty then
    (P ×ˢ P).sup' (h.product h) (fun xy => ‖xy.1 - xy.2‖)
  else
    0

/-- A factor-`c` diameter pair of a finite point set `P ⊆ ℝ^d` is a pair of points `x, y ∈ P`
satisfying `‖x - y‖ ≥ diam(P) / c`. -/
def IsFactorCDiameterPair {d : ℕ} (c : ℝ) (P : Finset (EuclideanSpace ℝ (Fin d)))
    (x y : EuclideanSpace ℝ (Fin d)) : Prop :=
  x ∈ P ∧ y ∈ P ∧ ‖x - y‖ ≥ euclideanDiam P / c

/-- Euclidean diameter `diam(P) = max_{x, y ∈ P} ‖pts x - pts y‖` of a finite indexed set of
active point identities `I : Finset ι` with coordinates `pts : ι → ℝ^d`, equal to `0` when
`|I| ≤ 1`. -/
noncomputable def indexedEuclideanDiam {ι : Type*} {d : ℕ}
    (I : Finset ι) (pts : ι → EuclideanSpace ℝ (Fin d)) : ℝ :=
  if h : I.Nonempty then
    (I ×ˢ I).sup' (h.product h) (fun xy => ‖pts xy.1 - pts xy.2‖)
  else
    0

/-- For an indexed finite set of active point identities `I : Finset ι` with `|I| ≥ 2` and
coordinates `pts : ι → ℝ^d`, an indexed factor-`c` diameter pair consists of two distinct active
identities `x ≠ y` in `I` (including when all coordinates coincide and `diam(P) = 0`) whose
Euclidean distance lies in `[diam(P) / c, diam(P)]`. -/
def IsIndexedFactorCDiameterPair {ι : Type*} {d : ℕ} (c : ℝ)
    (I : Finset ι) (pts : ι → EuclideanSpace ℝ (Fin d)) (x y : ι) : Prop :=
  x ∈ I ∧ y ∈ I ∧ x ≠ y ∧
    indexedEuclideanDiam I pts / c ≤ ‖pts x - pts y‖ ∧
    ‖pts x - pts y‖ ≤ indexedEuclideanDiam I pts

end UL
