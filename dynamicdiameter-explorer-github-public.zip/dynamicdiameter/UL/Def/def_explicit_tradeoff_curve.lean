import Mathlib
set_option autoImplicit false

/-! Definition (Sec. 1.1: Explicit filter tradeoff exponent Q_c(σ)) (paper p.3). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- Parameter `g = c^2 - 1` for approximation factor `c` (where `1 < c < √2`). -/
noncomputable def g_c (c : ℝ) : ℝ :=
  c ^ 2 - 1

/-- Balanced space/update tradeoff parameter `ρ = 2 / c^2 - 1` for approximation factor `c`
(where `1 < c < √2`). -/
noncomputable def rho_c (c : ℝ) : ℝ :=
  2 / c ^ 2 - 1

/-- Explicit filter list update exponent `Q_c(σ) = (√(1 - g^2) - g√σ)^2` where `g = c^2 - 1`,
for space bound `n^{1 + σ}` with `0 ≤ σ ≤ ρ`. -/
noncomputable def Q_c (c σ : ℝ) : ℝ :=
  (Real.sqrt (1 - (g_c c) ^ 2) - g_c c * Real.sqrt σ) ^ 2

end UL
