import Mathlib
import UL.Def.def_dynamic_points_model
import UL.Def.def_computation_model
import UL.Def.def_node_chain_blocks
import UL.Def.def_node_baseline
set_option autoImplicit false

/-! Definition (Sec. C.2: Late-opening replacement schedule and fallback) (paper p.52). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-! ### 1. Pool clock ticks vs. virtual value deletions and unaffected pools -/

/-- Event observed at a point pool during an update step: an external point insertion or deletion
in that pool counts as a clock tick, whereas an internal virtual value deletion or an external
update leaving the pool unaffected receives no tick. -/
inductive PoolUpdateEvent (ι : Type*) where
  | externalInsert (id : ι)
  | externalDelete (id : ι)
  | virtualValueDelete
  | unaffected
  deriving DecidableEq

/-- A clock tick of a pool is an external point insertion or deletion in that pool, rather than a
virtual value deletion; unaffected pools receive no tick. -/
def PoolUpdateEvent.isClockTick {ι : Type*} : PoolUpdateEvent ι → Bool
  | .externalInsert _ => true
  | .externalDelete _ => true
  | .virtualValueDelete => false
  | .unaffected => false

/-- Number of clock ticks (`1` or `0`) contributed to a pool by `ev`. -/
def PoolUpdateEvent.ticks {ι : Type*} (ev : PoolUpdateEvent ι) : ℕ :=
  if ev.isClockTick then 1 else 0

open Classical in
/-- Validity of `ev : PoolUpdateEvent ι` for a pool transitioning from finite identity set `S` to
`S'`: clock-tick events correspond to single-element external insertions (`id ∉ S`,
`S' = insert id S`) or deletions (`id ∈ S`, `S' = S.erase id`, i.e., `IsInputChange S S'`), while
virtual value deletions and unaffected steps leave the pool's point identities unchanged (`S' = S`). -/
def IsValidPoolUpdateEvent {ι : Type*} (S S' : Finset ι) : PoolUpdateEvent ι → Prop
  | .externalInsert id => id ∉ S ∧ S' = insert id S
  | .externalDelete id => id ∈ S ∧ S' = S.erase id
  | .virtualValueDelete => S' = S
  | .unaffected => S' = S

/-- Classification of an external `DynamicUpdate d` at a pool `S` transitioning to `S'`: ticks the
pool iff the inserted or deleted external identity enters or leaves `S`, and otherwise marks the
pool unaffected (`0` ticks). -/
def IsExternalPoolStep {d : ℕ} (op : DynamicUpdate d) (S S' : Finset ℕ)
    (ev : PoolUpdateEvent ℕ) : Prop :=
  match op with
  | .insert id _ _ =>
      (id ∉ S ∧ S' = insert id S ∧ ev = .externalInsert id) ∨
      (id ∉ S ∧ S' = S ∧ ev = .unaffected)
  | .delete id =>
      (id ∈ S ∧ S' = S.erase id ∧ ev = .externalDelete id) ∨
      (id ∉ S ∧ S' = S ∧ ev = .unaffected)

/-- Total number of pool clock ticks across a finite sequence of pool events. -/
def poolClockTickCount {ι : Type*} (events : List (PoolUpdateEvent ι)) : ℕ :=
  events.countP PoolUpdateEvent.isClockTick

/-! ### 2. Schedule constant `C_* = 4096`, Equation (10) leaf cutoff `L`, and exact small leaves -/

/-- Schedule constant `C_* = 4096` in Section C.2. -/
def scheduleCStar : ℕ := 4096

/-- Equation (10) leaf cutoff inequalities in `ℝ` for ambient dimension `d`, capacity `n`, depth
parameter `α`, fresh-center computation cost `C`, baseline-witness sample count `K₀`, and leaf
cutoff `L`:
`L ≥ 2^{20} C_* α^{-2}` and `L ≥ C + (d + log n) K_0 + 64 α^{-1}`. -/
def SatisfiesLeafCutoffReal (d n : ℕ) (α C K₀ : ℝ) (L : ℕ) : Prop :=
  (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ ≤ (L : ℝ) ∧
  C + ((d : ℝ) + Real.log (n : ℝ)) * K₀ + 64 * α⁻¹ ≤ (L : ℝ)

/-- Equation (10) leaf cutoff condition for integer sample count `K₀ : ℕ` and integer leaf cutoff
`L : ℕ`. -/
def SatisfiesLeafCutoffEq10 (d n : ℕ) (α C : ℝ) (K₀ L : ℕ) : Prop :=
  SatisfiesLeafCutoffReal d n α C (K₀ : ℝ) L

/-- Minimal integer leaf cutoff `L : ℕ` satisfying Equation (10) for `(d, n, α, C, K₀)`. -/
noncomputable def minLeafCutoffEq10 (d n : ℕ) (α C : ℝ) (K₀ : ℕ) : ℕ :=
  max ⌈(2 : ℝ) ^ 20 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊
      ⌈C + ((d : ℝ) + Real.log (n : ℝ)) * (K₀ : ℝ) + 64 * α⁻¹⌉₊

/-- Standing parameter assumptions for the Section C.2 schedule (with `d : ℕ` encoding `d ≥ 0`):
capacity `n ≥ 2`, lifted halfspace-depth parameter `α ∈ (0, 1/2]`, nonnegative center-computation
cost `C ≥ 0`, baseline sample count `K₀ : ℕ`, and leaf cutoff `L : ℕ` satisfying Equation (10). -/
def ValidScheduleParams (d n : ℕ) (α C : ℝ) (K₀ L : ℕ) : Prop :=
  2 ≤ n ∧
  0 < α ∧
  α ≤ 1 / 2 ∧
  0 ≤ C ∧
  SatisfiesLeafCutoffEq10 d n α C K₀ L

/-- Bundled Section C.2 schedule parameters `(d, n, α, C, K₀, L)` satisfying `ValidScheduleParams`. -/
structure ScheduleParams where
  d : ℕ
  n : ℕ
  α : ℝ
  C : ℝ
  K₀ : ℕ
  L : ℕ
  two_le_n : 2 ≤ n
  α_pos : 0 < α
  α_le_half : α ≤ 1 / 2
  C_nonneg : 0 ≤ C
  leaf_cutoff : SatisfiesLeafCutoffEq10 d n α C K₀ L

/-- Polynomial bound condition for Section C.2 schedule parameter families `f(d, n)` (such as `C`,
`K₀`, and the leaf cutoff `L`) in `(d, α(d, n)⁻¹, log n)`, with no hidden power of `n`. -/
def IsPolyScheduleQuantity (α : ℕ → ℕ → ℝ) (f : ℕ → ℕ → ℝ) : Prop :=
  ∃ (C_poly : ℝ) (deg : ℕ), 0 ≤ C_poly ∧
    ∀ d n : ℕ, 2 ≤ n →
      f d n ≤ C_poly * ((d + 1 : ℝ) ^ deg) * ((α d n)⁻¹ ^ deg) *
        ((Real.log (n : ℝ) + 1) ^ deg)

/-- Exact handling of a small leaf `S : Finset ι` (with point coordinates `pts : ι → ℝ^d`): returns
`none` when `|S| ≤ 1`, and `some (u, v)` consisting of two distinct identities `u ≠ v` in `S`
attaining the exact Euclidean diameter `‖pts u - pts v‖ = indexedEuclideanDiam S pts` when
`|S| ≥ 2`. -/
def IsExactLeafAnswer {ι : Type*} {d : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) (ans : Option (ι × ι)) : Prop :=
  if S.card ≤ 1 then
    ans = none
  else
    ∃ u v : ι,
      ans = some (u, v) ∧
      u ∈ S ∧ v ∈ S ∧ u ≠ v ∧
      ‖pts u - pts v‖ = indexedEuclideanDiam S pts

/-! ### 3. Job-start age `⌊αM/64⌋`, deadline `H = ⌊αm/C_*⌋`, and serving-only job ownership -/

/-- Age `⌊α M / 64⌋` (in root-pool clock ticks since birth, for `α > 0`) at which a serving node
born with `M` input points starts its single replacement job. -/
noncomputable def jobStartAge (α : ℝ) (M : ℕ) : ℕ :=
  ⌊α * (M : ℝ) / 64⌋₊

/-- Condition `m > 4L` under which a replacement job started at current input size `m` receives a
scheduled deadline `H = ⌊α m / C_*⌋` rather than immediately replacing the suffix by an exact leaf. -/
def NeedsScheduledReplacement (L m : ℕ) : Prop :=
  4 * L < m

/-- Deadline `H = ⌊α m / C_*⌋` (in further root-pool clock ticks, for `α > 0`) assigned to a
replacement job started when the serving node's current input size is `m > 4L`. -/
noncomputable def jobDeadlineTicks (α : ℝ) (m : ℕ) : ℕ :=
  ⌊α * (m : ℝ) / (scheduleCStar : ℝ)⌋₊

/-- Action taken when a serving node born with `M` input points reaches age `⌊α M / 64⌋` with
current input size `m`: either replace the suffix immediately by an exact leaf (`m ≤ 4L`), or start
one pending replacement job with deadline `H = ⌊α m / C_*⌋` further root-pool ticks (`m > 4L`). -/
inductive JobStartAction : Type
  | replaceImmediatelyByExactLeaf
  | startPendingJob (deadlineTicks : ℕ)
  deriving DecidableEq

/-- Job-start branching rule at age `⌊α M / 64⌋` for leaf cutoff `L` and current input size `m`. -/
noncomputable def scheduleJobStart (α : ℝ) (L m : ℕ) : JobStartAction :=
  if 4 * L < m then
    .startPendingJob (jobDeadlineTicks α m)
  else
    .replaceImmediatelyByExactLeaf

/-- Serving-node age validity threshold `age < α M / 16` for a node born with `M` input points. -/
def IsValidServingNodeAge (α : ℝ) (M age : ℕ) : Prop :=
  (age : ℝ) < α * (M : ℝ) / 16

/-- Background auxiliary structures built for an opened large level (`m > 2L + 1`):
- `radiusDictOnly`: builds the radius dictionary in the background while omitting local angular
  search indices and matchings (used at the `c = √2` endpoint);
- `radiusDictAndLocalSearch`: builds both the radius dictionary and local angular search indices in
  the background (used for `1 < c < √2`). -/
inductive BackgroundIndexMode : Type
  | radiusDictOnly
  | radiusDictAndLocalSearch
  deriving DecidableEq

/-- Background index mode determined by approximation factor `c` (`radiusDictAndLocalSearch` for
`c < √2`, and `radiusDictOnly` at `c = √2`). -/
noncomputable def backgroundIndexModeForFactor (c : ℝ) : BackgroundIndexMode :=
  open Classical in
  if c < Real.sqrt 2 then .radiusDictAndLocalSearch else .radiusDictOnly

/-- One opened fixed-ball level inside the completed prefix of a pending replacement job: retains
its birth snapshot `birthSnapshot`, stores its fixed ball `ball : ChainNode d` computed immediately
in the opening update, tracks its background auxiliary-index mode and completion status, and owns
no nested replacement job. -/
structure OpenedJobLevel (d : ℕ) (ι : Type*) where
  birthSnapshot : Finset ι
  ball : ChainNode d
  indexMode : BackgroundIndexMode
  backgroundReady : Bool

/-- Residual of root-pool input set `S_root` after removing the cores of a completed prefix of
fixed balls `completedPrefix`. -/
noncomputable def prefixResidual {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (completedPrefix : List (OpenedJobLevel d ι))
    (S_root : Finset ι) : Finset ι :=
  completedPrefix.foldl (fun S lv => lv.ball.residual pts S) S_root

/-- A pending replacement job owned by a serving node: consists of a deadline `deadlineTicks`,
remaining root-pool ticks `remainingTicks`, a completed prefix of fixed balls `completedPrefix`
(with no nested replacement jobs inside that prefix), and one current residual `currentResidual`
(together with `closedAsLeaf` recording whether that residual has been closed as an exact leaf). -/
structure PendingReplacementJob (d : ℕ) (ι : Type*) where
  deadlineTicks : ℕ
  remainingTicks : ℕ
  completedPrefix : List (OpenedJobLevel d ι)
  currentResidual : Finset ι
  closedAsLeaf : Bool

/-! ### 4. Late-opening gate `r ≤ αm/C_*` and two-stage center fallback -/

/-- Late-opening condition: when `r` root-pool ticks remain and the current residual has `m`
points, open its next level only when `r ≤ α m / C_*`. -/
def CanOpenResidualLevel (α : ℝ) (r m : ℕ) : Prop :=
  (r : ℝ) ≤ α * (m : ℝ) / (scheduleCStar : ℝ)

/-- Small-residual leaf cutoff `m ≤ 2L + 1` under which an opened residual is closed as a leaf. -/
def IsResidualLeafSize (L m : ℕ) : Prop :=
  m ≤ 2 * L + 1

/-- Large-residual condition `m > 2L + 1` under which opening the residual retains its birth
snapshot, computes a center immediately, and builds its auxiliary structures in the background. -/
def IsLargeResidualLevel (L m : ℕ) : Prop :=
  2 * L + 1 < m

/-- Late-opening schedule decision on an open residual of size `m` when `r` root-pool ticks remain:
wait if `r > α m / C_*`; close as an exact leaf if `r ≤ α m / C_*` and `m ≤ 2L + 1`; otherwise
(`r ≤ α m / C_*` and `m > 2L + 1`) open a fixed-ball level. -/
inductive ResidualScheduleAction : Type
  | wait
  | closeAsLeaf
  | openBallLevel
  deriving DecidableEq

/-- Compute the `ResidualScheduleAction` for depth parameter `α`, leaf cutoff `L`, remaining
root-pool ticks `r`, and current residual size `m`. -/
noncomputable def residualScheduleStep (α : ℝ) (L r m : ℕ) : ResidualScheduleAction :=
  open Classical in
  if CanOpenResidualLevel α r m then
    if IsResidualLeafSize L m then
      .closeAsLeaf
    else
      .openBallLevel
  else
    .wait

/-- Result of running the sampled Monte Carlo center program in an opening update: either reports
infeasibility, or returns a candidate first-coordinate center `o ∈ ℝ^d` and variance `V ∈ ℝ`. -/
inductive SampledCenterResult (d : ℕ) : Type
  | infeasible
  | candidate (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)

/-- Convert an optional lifted centerpoint `z = (o, s) ∈ ℝ^{d+1}` (`none` for infeasibility) into a
`SampledCenterResult d` with `o = liftedBase z` and `V = liftedPointVariance z = s - ‖o‖^2`. -/
noncomputable def SampledCenterResult.ofLiftedOption {d : ℕ} :
    Option (EuclideanSpace ℝ (Fin (d + 1))) → SampledCenterResult d
  | none => .infeasible
  | some z => .candidate (liftedBase z) (liftedPointVariance z)

/-- Predicate that the sampled program either reported infeasibility or returned a center with
`V < 0`, triggering Stage 1 of the fallback (`o` chosen as any birth point and provisional `V = 0`). -/
def NeedsProvisionalBirthPoint {d : ℕ} : SampledCenterResult d → Prop
  | .infeasible => True
  | .candidate _ V => V < 0

/-- Stage-1 provisional center selection given a chosen birth identity `birthPtId` (`birthPtId ∈ S_birth`):
if `res` is `.infeasible` or has `V < 0`, sets `o = pts birthPtId` and provisional `V = 0`;
otherwise keeps `(o, V)` with `V ≥ 0`. -/
noncomputable def provisionalCenter {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (birthPtId : ι) :
    SampledCenterResult d → ChainNode d
  | .infeasible =>
      { o := pts birthPtId, V := 0, V_nonneg := le_rfl }
  | .candidate o V =>
      open Classical in
      if hV : 0 ≤ V then
        { o := o, V := V, V_nonneg := hV }
      else
        { o := pts birthPtId, V := 0, V_nonneg := le_rfl }

/-- Relational Stage-1 provisional center specification over birth snapshot `S_birth`: when `res`
reports infeasibility or `V < 0`, any birth point `b ∈ S_birth` may be chosen as `o` with
provisional `V = 0`; otherwise `prov = ⟨o, V, _⟩`. -/
def IsProvisionalCenter {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_birth : Finset ι)
    (res : SampledCenterResult d) (prov : ChainNode d) : Prop :=
  match res with
  | .infeasible =>
      ∃ b ∈ S_birth, prov = { o := pts b, V := 0, V_nonneg := le_rfl }
  | .candidate o V =>
      if hV : 0 ≤ V then
        prov = { o := o, V := V, V_nonneg := hV }
      else
        ∃ b ∈ S_birth, prov = { o := pts b, V := 0, V_nonneg := le_rfl }

/-- Explicit birth-core size check on retained birth snapshot `S_birth` of size `m = S_birth.card`:
the birth core `S_birth ∩ B(N.o, √N.V)` contains at least `α m / 2` points. -/
def PassesBirthCoreCheck {d : ℕ} {ι : Type*}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (N : ChainNode d) (S_birth : Finset ι) : Prop :=
  α * (S_birth.card : ℝ) / 2 ≤ ((N.core pts S_birth).card : ℝ)

/-- Enclosing-ball fallback on retained birth snapshot `S_birth`: keeps the same first-coordinate
center `o` and uses the maximum birth radius `R_birth_max = nodeMaxRadius pts o S_birth` as the ball
radius (`V = R_birth_max ^ 2`, so `coreBall o V = B(o, R_birth_max)`). -/
noncomputable def maxBirthRadiusBall {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S_birth : Finset ι) : ChainNode d :=
  { o := o
    V := (nodeMaxRadius pts o S_birth) ^ 2
    V_nonneg := sq_nonneg _ }

/-- Stage-2 explicit birth-core check and fallback: if `PassesBirthCoreCheck α pts prov S_birth`
holds (`|C_birth| ≥ α m / 2`), keeps `prov`; if `prov` fails that check, uses the same
first-coordinate center `prov.o` with the maximum birth radius `nodeMaxRadius pts prov.o S_birth`
as the ball. -/
noncomputable def applyBirthCoreFallback {d : ℕ} {ι : Type*}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S_birth : Finset ι) (prov : ChainNode d) : ChainNode d :=
  open Classical in
  if PassesBirthCoreCheck α pts prov S_birth then
    prov
  else
    maxBirthRadiusBall pts prov.o S_birth

/-- Complete two-stage center selection and fallback for opening a large level (`m > 2L + 1`) on
retained birth snapshot `S_birth`, using `birthPtId` (`∈ S_birth`) if Stage 1 is triggered. -/
noncomputable def selectOpenedLevelBall {d : ℕ} {ι : Type*}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S_birth : Finset ι) (birthPtId : ι) (res : SampledCenterResult d) : ChainNode d :=
  applyBirthCoreFallback α pts S_birth (provisionalCenter pts birthPtId res)

/-- Relational specification of a valid fixed ball `ball` produced by the two-stage opening rule on
retained birth snapshot `S_birth` from sampled center result `res`. -/
def IsValidOpenedLevelBall {d : ℕ} {ι : Type*}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S_birth : Finset ι) (res : SampledCenterResult d) (ball : ChainNode d) : Prop :=
  ∃ prov : ChainNode d,
    IsProvisionalCenter pts S_birth res prov ∧
    ball = applyBirthCoreFallback α pts S_birth prov

/-! ### 5. Pending-job transitions, serving-chain invariants, and good center event -/

/-- Initialize a new pending replacement job on root-pool snapshot `S_root` (when `S_root.card > 4L`)
with deadline `H = ⌊α |S_root| / C_*⌋` further root-pool ticks, empty completed prefix, and
unclosed residual `S_root`. -/
noncomputable def initPendingJob {d : ℕ} {ι : Type*}
    (α : ℝ) (S_root : Finset ι) : PendingReplacementJob d ι :=
  let H := jobDeadlineTicks α S_root.card
  { deadlineTicks := H
    remainingTicks := H
    completedPrefix := []
    currentResidual := S_root
    closedAsLeaf := false }

/-- Update a pending replacement job's remaining root-pool ticks and current residual when a pool
event `ev` transitions its root pool to `S_root'`. -/
noncomputable def updatePendingJobRootPool {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (job : PendingReplacementJob d ι)
    (ev : PoolUpdateEvent ι)
    (S_root' : Finset ι) : PendingReplacementJob d ι :=
  { job with
    remainingTicks := job.remainingTicks - ev.ticks
    currentResidual := prefixResidual pts job.completedPrefix S_root' }

/-- Open a large level (`m > 2L + 1`) in a pending replacement job: retains `job.currentResidual`
as `birthSnapshot`, installs the fixed ball `ball` computed immediately in the opening update, marks
background auxiliary structures (`indexMode`) for background construction (`backgroundReady = false`),
appends the level to `completedPrefix`, and updates `currentResidual` to `ball.residual pts`. -/
noncomputable def openLargeLevelInJob {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (job : PendingReplacementJob d ι)
    (ball : ChainNode d)
    (indexMode : BackgroundIndexMode) : PendingReplacementJob d ι :=
  let lv : OpenedJobLevel d ι :=
    { birthSnapshot := job.currentResidual
      ball := ball
      indexMode := indexMode
      backgroundReady := false }
  { job with
    completedPrefix := job.completedPrefix ++ [lv]
    currentResidual := ball.residual pts job.currentResidual }

/-- Close the current residual (`m ≤ 2L + 1`) of a pending replacement job as an exact leaf. -/
def closeResidualAsLeafInJob {d : ℕ} {ι : Type*}
    (job : PendingReplacementJob d ι) : PendingReplacementJob d ι :=
  { job with closedAsLeaf := true }

/-- Structural invariant of a `PendingReplacementJob` over root-pool input set `S_root`:
`remainingTicks ≤ deadlineTicks`, `currentResidual` equals `S_root` minus the cores of all balls in
`completedPrefix`, and every opened level in `completedPrefix` has birth size `m > 2L + 1` and at
least `α m / 2` birth core points. -/
def PendingReplacementJob.WellFormed {d : ℕ} {ι : Type*}
    (job : PendingReplacementJob d ι) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_root : Finset ι) : Prop :=
  job.remainingTicks ≤ job.deadlineTicks ∧
  job.currentResidual = prefixResidual pts job.completedPrefix S_root ∧
  ∀ lv ∈ job.completedPrefix,
    IsLargeResidualLevel L lv.birthSnapshot.card ∧
    PassesBirthCoreCheck α pts lv.ball lv.birthSnapshot

/-- Readiness of a pending replacement job to replace the serving suffix at its deadline: `0`
ticks remain, its residual has been closed as a leaf, and all background auxiliary structures in
`completedPrefix` have finished building. -/
def PendingReplacementJob.IsReadyToInstall {d : ℕ} {ι : Type*}
    (job : PendingReplacementJob d ι) : Prop :=
  job.remainingTicks = 0 ∧
  job.closedAsLeaf = true ∧
  ∀ lv ∈ job.completedPrefix, lv.backgroundReady = true

/-- State of an active serving node in the main chain: stores its birth snapshot (of size `M`), its
serving `ChainNode`, its conservatively counted age `age` (elapsed job-root ticks at installation
plus subsequent serving-pool ticks, upper-bounding the true `HasNodeAge` input-change count from
`birthSnapshot`), and its single optional pending replacement job (only serving nodes own jobs). -/
structure ServingNodeState (d : ℕ) (ι : Type*) where
  birthSnapshot : Finset ι
  node : ChainNode d
  age : ℕ
  ownedJob : Option (PendingReplacementJob d ι)

/-- Schedule invariant for a serving node `st` (born with `M = st.birthSnapshot.card` input points)
on current input pool `S_cur`:
- `st.age` conservatively upper-bounds the true `HasNodeAge` input-change count from
  `st.birthSnapshot` to `S_cur` (`∃ actualAge ≤ st.age, HasNodeAge st.birthSnapshot S_cur actualAge`);
- before age `⌊α M / 64⌋`, `st` owns no job (`ownedJob = none`);
- at or after age `⌊α M / 64⌋`, `st` owns one pending job started on its age-`⌊α M / 64⌋` input
  snapshot `S_start` (reachable from `st.birthSnapshot` in `actualStartAge ≤ ⌊α M / 64⌋` input
  changes and followed by `st.age - ⌊α M / 64⌋` serving-pool input changes to `S_cur`, with
  `|S_start| > 4L`, since `|S_start| ≤ 4L` replaces the suffix immediately by an exact leaf), with
  `deadlineTicks = ⌊α |S_start| / C_*⌋` and elapsed serving-pool ticks
  `st.age - ⌊α M / 64⌋ = job.deadlineTicks - job.remainingTicks`. -/
def ServingNodeState.OwnsValidJobSchedule {d : ℕ} {ι : Type*}
    (st : ServingNodeState d ι) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_cur : Finset ι) : Prop :=
  let startAge := jobStartAge α st.birthSnapshot.card
  (∃ actualAge ≤ st.age, HasNodeAge st.birthSnapshot S_cur actualAge) ∧
  if st.age < startAge then
    st.ownedJob = none
  else
    ∃ S_start : Finset ι,
      (∃ actualStartAge ≤ startAge, HasNodeAge st.birthSnapshot S_start actualStartAge) ∧
      HasNodeAge S_start S_cur (st.age - startAge) ∧
      NeedsScheduledReplacement L S_start.card ∧
      ∃ job : PendingReplacementJob d ι,
        st.ownedJob = some job ∧
        job.deadlineTicks = jobDeadlineTicks α S_start.card ∧
        (st.age - startAge) + job.remainingTicks = job.deadlineTicks ∧
        job.WellFormed α L pts S_cur

/-- Full invariant of a serving node `st` in the chain: opened on a large birth snapshot
(`M > 2L + 1`), containing at least `α M / 2` birth core points, and satisfying
`OwnsValidJobSchedule`. -/
def ServingNodeState.WellFormed {d : ℕ} {ι : Type*}
    (st : ServingNodeState d ι) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_cur : Finset ι) : Prop :=
  IsLargeResidualLevel L st.birthSnapshot.card ∧
  PassesBirthCoreCheck α pts st.node st.birthSnapshot ∧
  st.OwnsValidJobSchedule α L pts S_cur

/-- Active serving chain together with its exact terminal leaf and maintained exact leaf answer
(only `servingNodes` carry `ownedJob` slots; levels inside pending jobs carry none). -/
structure ScheduledServingChain (d : ℕ) (ι : Type*) where
  servingNodes : List (ServingNodeState d ι)
  terminalLeaf : Finset ι
  terminalLeafAnswer : Option (ι × ι)

/-- Input pool reaching the `idx`-th serving node (or the terminal leaf at `idx = nodes.length`)
from active point set `P`. -/
noncomputable def servingChainInputAt {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (nodes : List (ServingNodeState d ι))
    (P : Finset ι) (idx : ℕ) : Finset ι :=
  (nodes.take idx).foldl (fun S st => st.node.residual pts S) P

/-- Schedule invariant of a `ScheduledServingChain` on active point set `P`: every serving node
satisfies `ServingNodeState.WellFormed` on its input pool, `terminalLeaf` is the residual after all
serving nodes, and `terminalLeafAnswer` handles `terminalLeaf` exactly. -/
def ScheduledServingChain.WellFormed {d : ℕ} {ι : Type*}
    (chain : ScheduledServingChain d ι) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P : Finset ι) : Prop :=
  (∀ idx : Fin chain.servingNodes.length,
    (chain.servingNodes[idx]).WellFormed α L pts
      (servingChainInputAt pts chain.servingNodes P idx.val)) ∧
  chain.terminalLeaf = servingChainInputAt pts chain.servingNodes P chain.servingNodes.length ∧
  IsExactLeafAnswer pts chain.terminalLeaf chain.terminalLeafAnswer

/-- Lifted centerpoint predicate on retained birth snapshot `S_birth`: `V ≥ 0` and the lifted point
`z = (o, V + ‖o‖^2) ∈ ℝ^{d+1}` is a `β`-centerpoint of `S_birth^+`. -/
def IsBirthLiftedCenterpoint {d : ℕ} {ι : Type*}
    (β : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S_birth : Finset ι) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) : Prop :=
  0 ≤ V ∧
  IsCenterpoint β (paraboloidLiftSet (fun i : S_birth => pts i.val)) (liftedPoint o (V + ‖o‖ ^ 2))

/-- Good-center outcome for a single opened large level on retained birth snapshot `S_birth` under
geometric center property `goodGeom`: the sampled program returns `.candidate o V` with `V ≥ 0`
that passes the explicit `≥ α m / 2` birth-core check (without triggering the maximum-radius
fallback) and satisfies `goodGeom o V`. -/
def IsGoodSampledCenterOutcome {d : ℕ} {ι : Type*}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S_birth : Finset ι) (goodGeom : EuclideanSpace ℝ (Fin d) → ℝ → Prop) :
    SampledCenterResult d → Prop
  | .infeasible => False
  | .candidate o V =>
      ∃ hV : 0 ≤ V,
        PassesBirthCoreCheck α pts { o := o, V := V, V_nonneg := hV } S_birth ∧
        goodGeom o V

/-- Conditional correctness assertion on the good center event `goodCenterEvent : Set Ω`: while
contraction (`PassesBirthCoreCheck`) and work bounds hold on every outcome (including fallback
outcomes), validity of the maintained factor-`c` diameter answer is asserted on `goodCenterEvent`. -/
def AssertsCorrectnessOnGoodCenterEvent {Ω : Type*} {d : ℕ}
    (c : ℝ) (goodCenterEvent : Set Ω)
    (P : Ω → DynamicPointSet d) (ans : Ω → StoredDiameterAnswer) : Prop :=
  ∀ ω ∈ goodCenterEvent, IsValidFactorCAnswer c (P ω) (ans ω)

end UL
