import Mathlib
import UL.Def.def_node_chain_blocks
set_option autoImplicit false

/-! Definition (Sec. 5.2: Core–input diameter D_C and local scale parameters) (paper p.17). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- Core–input diameter `D_C = max_{x ∈ C, y ∈ S} ‖x - y‖` for finite point sets `C, S ⊆ ℝ^d`
(in the paper, `C = S ∩ B(o, √V) ⊆ S`), equal to `0` when `C = ∅` (or `S = ∅`, which cannot occur
when `C ⊆ S` and `C ≠ ∅`). -/
noncomputable def coreInputDiam {d : ℕ}
    (C S : Finset (EuclideanSpace ℝ (Fin d))) : ℝ :=
  if h : C.Nonempty ∧ S.Nonempty then
    (C ×ˢ S).sup' (h.1.product h.2) (fun xy => ‖xy.1 - xy.2‖)
  else
    0

/-- Core–input diameter `D_C = max_{x ∈ C, y ∈ S} ‖x - y‖` of a node `(o, V)` on a finite point set
`S ⊆ ℝ^d`, where `C = S ∩ B(o, √V)` (`nodeCore id o V S`), equal to `0` when `C = ∅`. -/
noncomputable def pointNodeCoreInputDiam {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset (EuclideanSpace ℝ (Fin d))) : ℝ :=
  coreInputDiam (nodeCore id o V S) S

/-- Indexed core–input diameter `D_C = max_{x ∈ C, y ∈ S} ‖pts x - pts y‖` for finite indexed sets
`C, S : Finset ι` with coordinates `pts : ι → ℝ^d` (in the paper, `C = S ∩ B(o, √V) ⊆ S`), equal
to `0` when `C = ∅` (or `S = ∅`, which cannot occur when `C ⊆ S` and `C ≠ ∅`). -/
noncomputable def indexedCoreInputDiam {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (C S : Finset ι) : ℝ :=
  if h : C.Nonempty ∧ S.Nonempty then
    (C ×ˢ S).sup' (h.1.product h.2) (fun xy => ‖pts xy.1 - pts xy.2‖)
  else
    0

/-- Core–input diameter `D_C = max_{x ∈ C, y ∈ S} ‖pts x - pts y‖` of a node `(o, V)` on finite
indexed input set `S : Finset ι` with coordinates `pts : ι → ℝ^d`, where
`C = nodeCore pts o V S = S ∩ B(o, √V)`, equal to `0` when `C = ∅`. -/
noncomputable def nodeCoreInputDiam {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) : ℝ :=
  indexedCoreInputDiam pts (nodeCore pts o V S) S

/-- Core–input diameter `D_C` of a `ChainNode` `N` on finite indexed input set `S : Finset ι` with
coordinates `pts : ι → ℝ^d`, where `C = N.core pts S`, equal to `0` when `C = ∅`. -/
noncomputable def ChainNode.coreInputDiam {d : ℕ} {ι : Type*}
    (N : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) : ℝ :=
  nodeCoreInputDiam pts N.o N.V S

/-- Core–input diameter `D_{C_i}` at the `i`-th node (`i : Fin k`) along a chain of `k` nodes on
active indexed set `P : Finset ι`, where `S_i = chainInput pts nodes P i.castSucc` and
`C_i = chainCore pts nodes P i`. -/
noncomputable def chainCoreInputDiam {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (i : Fin k) : ℝ :=
  (nodes i).coreInputDiam pts (chainInput pts nodes P i.castSucc)

/-- Derived rational local scale parameter `κ = γ + 2e` for `e, γ ∈ ℚ`. -/
def localScaleKappa (e γ : ℚ) : ℚ :=
  γ + 2 * e

/-- Predicate for valid local scale parameters `(c, e, γ, λ, K)` with `c ∈ ℝ`, `e, γ, λ ∈ ℚ`,
and `K ∈ ℤ`: `1 < c < √2`, `e > 0`, `γ > 1`, `λ > 1`, `κ = γ + 2e < c`, `κ λ < c`, and
`K ≥ 2 / (c - 1)`. -/
def IsValidLocalScaleParams (c : ℝ) (e γ lam : ℚ) (K : ℤ) : Prop :=
  1 < c ∧
  c < Real.sqrt 2 ∧
  0 < e ∧
  1 < γ ∧
  1 < lam ∧
  (localScaleKappa e γ : ℝ) < c ∧
  (localScaleKappa e γ : ℝ) * (lam : ℝ) < c ∧
  2 / (c - 1) ≤ (K : ℝ)

/-- Bundled local scale parameters `(c, e, γ, λ, K)` from Section 5.2: real approximation factor
`1 < c < √2`, rational parameters `e > 0`, `γ > 1`, `λ > 1` satisfying `κ = γ + 2e < c` and
`κ λ < c`, and integer scale count `K ∈ ℤ` satisfying `K ≥ 2 / (c - 1)`. -/
structure LocalScaleParams where
  c : ℝ
  e : ℚ
  γ : ℚ
  lam : ℚ
  K : ℤ
  one_lt_c : 1 < c
  c_lt_sqrt_two : c < Real.sqrt 2
  e_pos : 0 < e
  one_lt_γ : 1 < γ
  one_lt_lam : 1 < lam
  κ_lt_c : (localScaleKappa e γ : ℝ) < c
  κ_mul_lam_lt_c : (localScaleKappa e γ : ℝ) * (lam : ℝ) < c
  K_ge : 2 / (c - 1) ≤ (K : ℝ)

/-- Derived rational scale factor `κ = γ + 2e` of a `LocalScaleParams` bundle. -/
def LocalScaleParams.κ (params : LocalScaleParams) : ℚ :=
  localScaleKappa params.e params.γ

end UL
