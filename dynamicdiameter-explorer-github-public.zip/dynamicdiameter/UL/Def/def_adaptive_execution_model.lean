import Mathlib
import UL.Def.def_dynamic_points_model
set_option autoImplicit false

/-! Definition (Sec. 3: Adaptive adversary, Monte Carlo, and Las Vegas guarantees) (paper p.13,
Sec. 1 pp.2–3).
Models:
1. Exposed-randomness adaptive dynamic executions starting from the empty point set `P = ∅`:
   before each external update begins, the adversary chooses a legal insertion or deletion (subject
   to `|P| ≤ n`) as an arbitrary function of the complete preceding history, including every
   previous random choice and answer; the algorithm then processes that operation using fresh
   randomness;
2. Oblivious adversaries as the special case in which the operation sequence is fixed in advance;
3. Monte Carlo `(n, t, δ)` guarantee with `δ ∈ (0, 1/2)`: with probability at least `1 - δ`, every
   answer across the execution satisfies its factor-`c` approximation guarantee;
4. Always-correct (Las Vegas) guarantee with no update horizon: every operation terminates with
   probability one, every maintained answer is valid, and for every fixed finite prefix of length
   `T ≥ 1` of an adaptive execution, the expected total work during that prefix divided by `T`
   satisfies the amortized bound (without asserting a conditional per-step bound after particular
   random choices have been exposed). -/

namespace UL

/-- Complete externally visible and exposed-randomness record of one completed update step: the
external operation, all random bits drawn by the algorithm during that step, the reusable handle
returned (on insertion), the maintained diameter answer, and the resolved external identity pair. -/
structure StepHistoryEntry (d : ℕ) : Type where
  operation : DynamicUpdate d
  randomBits : List Bool
  returnedHandle : Option ℕ
  answer : StoredDiameterAnswer
  resolvedIds : Option (ℕ × ℕ)

/-- Preceding execution history available to the adaptive adversary before the next operation. -/
abbrev ExecutionHistory (d : ℕ) : Type :=
  List (StepHistoryEntry d)

/-- An adaptive adversary specifies the next external operation as an arbitrary function of the
complete preceding history, including every previous random choice and answer. -/
abbrev AdaptiveAdversary (d : ℕ) : Type :=
  ExecutionHistory d → DynamicUpdate d

/-- An oblivious adversary is the special case in which the operation sequence is fixed in advance,
depending only on the step index `hist.length`. -/
def IsObliviousAdversary {d : ℕ} (adv : AdaptiveAdversary d) : Prop :=
  ∃ seq : ℕ → DynamicUpdate d, ∀ hist : ExecutionHistory d, adv hist = seq hist.length

/-- Execute one update `op` on `(P, st)` using fresh random bits `bs`, succeeding iff the algorithm
halts having consumed exactly `bs` and returns a legal handle transition (`some h` with
`h ∉ P.activeHandles` on insertion, `none` on deletion). -/
noncomputable def runSingleAdaptiveStep {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (P : DynamicPointSet d) (st : State)
    (op : DynamicUpdate d) (bs : List Bool) :
    Option (DynamicPointSet d × DynamicStepOutcome State) :=
  match alg.stepWithBits P.activeHandles P.handleCoords st (toInternalUpdate P op) bs with
  | none => none
  | some out =>
      match applyDynamicUpdate P op out.returnedHandle with
      | none => none
      | some P' => some (P', out)

/-- Accumulated state of a finite adaptive execution prefix starting from `P = ∅`. -/
structure AdaptivePrefixState (d : ℕ) (State : Type) : Type where
  pointSet : DynamicPointSet d
  algState : State
  history : ExecutionHistory d
  snapshots : List (DynamicPointSet d × StoredDiameterAnswer)
  stepWorks : List ℕ
  totalWork : ℕ
  maxSpace : ℕ

/-- Initial empty execution state prior to the first external update (`P = ∅`; constructing an
initial set by insertion is charged to those insertions). -/
noncomputable def initAdaptivePrefixState {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) : AdaptivePrefixState d State :=
  { pointSet := DynamicPointSet.empty d
    algState := alg.initState
    history := []
    snapshots := []
    stepWorks := []
    totalWork := alg.initWork
    maxSpace := alg.initSpace }

/-- Continue an adaptive execution from prefix state `cur` over remaining per-step fresh random bit
lists: before each step, `adv` specifies the next operation from `cur.history`, and `alg` processes
it using that step's fresh random bits. -/
noncomputable def runAdaptiveStepsFrom {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d)
    (cur : AdaptivePrefixState d State) :
    List (List Bool) → Option (AdaptivePrefixState d State)
  | [] => some cur
  | b :: tail =>
      let op := adv cur.history
      match runSingleAdaptiveStep alg cur.pointSet cur.algState op b with
      | none => none
      | some (P', out) =>
          let entry : StepHistoryEntry d :=
            { operation := op
              randomBits := b
              returnedHandle := out.returnedHandle
              answer := out.storedAnswer
              resolvedIds := resolveAnswerIdentities P' out.storedAnswer }
          let next : AdaptivePrefixState d State :=
            { pointSet := P'
              algState := out.nextState
              history := cur.history ++ [entry]
              snapshots := cur.snapshots ++ [(P', out.storedAnswer)]
              stepWorks := cur.stepWorks ++ [out.work]
              totalWork := cur.totalWork + out.work
              maxSpace := max cur.maxSpace out.peakSpace }
          runAdaptiveStepsFrom alg adv next tail

/-- Run an adaptive execution starting from `P = ∅` over a list of per-step fresh random bit lists
`bitTrace`. -/
noncomputable def runAdaptiveSteps {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d)
    (bitTrace : List (List Bool)) : Option (AdaptivePrefixState d State) :=
  runAdaptiveStepsFrom alg adv (initAdaptivePrefixState alg) bitTrace

/-- Run a fixed finite prefix of length `T` of an adaptive execution given per-step random bit
lists `trace : Fin T → List Bool`. -/
noncomputable def runAdaptivePrefix {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d) (T : ℕ)
    (trace : Fin T → List Bool) : Option (AdaptivePrefixState d State) :=
  runAdaptiveSteps alg adv (List.ofFn trace)

/-- Legality of an adaptive adversary over an unbounded horizon with capacity `n` and admissible
point domain `admissiblePts`: after every reachable execution history, the next operation specified
by `adv` is a legal insertion or deletion keeping `|P| ≤ n`. -/
def IsValidAdaptiveAdversary {d : ℕ} {State : Type}
    (n : ℕ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d) : Prop :=
  ∀ bitTrace : List (List Bool), ∀ prefSt : AdaptivePrefixState d State,
    runAdaptiveSteps alg adv bitTrace = some prefSt →
      IsLegalUpdate n admissiblePts prefSt.pointSet (adv prefSt.history)

/-- Legality of an adaptive adversary over a bounded update horizon `t` with capacity `n` and
admissible point domain `admissiblePts`. -/
def IsValidBoundedAdversary {d : ℕ} {State : Type}
    (n t : ℕ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d) : Prop :=
  ∀ bitTrace : List (List Bool), bitTrace.length < t →
    ∀ prefSt : AdaptivePrefixState d State,
      runAdaptiveSteps alg adv bitTrace = some prefSt →
        IsLegalUpdate n admissiblePts prefSt.pointSet (adv prefSt.history)

/-- Probability weight `2^{-|bs|}` of drawing a specific fair coin-flip sequence `bs : List Bool`. -/
noncomputable def bitListProb (bs : List Bool) : ENNReal :=
  ((2 : ENNReal)⁻¹) ^ bs.length

/-- Joint probability weight `∏_{s < T} 2^{-|trace s|}` of independent fresh random bit sequences
across `T` update steps. -/
noncomputable def prefixTraceProb {T : ℕ} (trace : Fin T → List Bool) : ENNReal :=
  ∏ s : Fin T, bitListProb (trace s)

/-- Probability that a single update `op` from `(P, st)` halts with a valid transition under fresh
uniform random bits. -/
noncomputable def singleStepValidHaltProb {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (P : DynamicPointSet d) (st : State)
    (op : DynamicUpdate d) : ENNReal :=
  ∑' bs : List Bool,
    if (runSingleAdaptiveStep alg P st op bs).isSome then bitListProb bs else 0

/-- Probability of an execution event over a `T`-step adaptive execution against `adv`. -/
noncomputable def adaptivePrefixEventProb {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d) (T : ℕ)
    (event : AdaptivePrefixState d State → Prop) : ENNReal :=
  open Classical in
  ∑' trace : Fin T → List Bool,
    match runAdaptivePrefix alg adv T trace with
    | some out => if event out then prefixTraceProb trace else 0
    | none => 0

/-- Expected total work `E[initWork + ∑_{i=1}^T work_i]` during a fixed finite prefix of length `T`
of an adaptive execution starting from `P = ∅`. -/
noncomputable def adaptivePrefixExpectedWork {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d) (T : ℕ) : ENNReal :=
  ∑' trace : Fin T → List Bool,
    match runAdaptivePrefix alg adv T trace with
    | some out => prefixTraceProb trace * (out.totalWork : ENNReal)
    | none => 0

/-- Every maintained answer across all completed steps of the prefix satisfies its factor-`c`
diameter approximation guarantee. -/
def AllPrefixAnswersValid {d : ℕ} {State : Type} (c : ℝ)
    (out : AdaptivePrefixState d State) : Prop :=
  ∀ snap ∈ out.snapshots, IsValidFactorCAnswer c snap.1 snap.2

/-- Monte Carlo adaptive correctness guarantee supplied with capacity `n`, update horizon `t`, and
total error probability `δ ∈ (0, 1/2)`: every reachable step up to horizon `t` terminates with
probability one, and for every execution of length `T ≤ t` against any valid adaptive adversary,
with probability at least `1 - δ`, every answer in that execution satisfies its factor-`c`
approximation guarantee. -/
def SatisfiesMonteCarloGuarantee {d : ℕ} {State : Type}
    (n t : ℕ) (δ c : ℝ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) : Prop :=
  0 < δ ∧ δ < 1 / 2 ∧
  ∀ adv : AdaptiveAdversary d,
    IsValidBoundedAdversary n t admissiblePts alg adv →
      (∀ bitTrace : List (List Bool), bitTrace.length < t →
        ∀ prefSt : AdaptivePrefixState d State,
          runAdaptiveSteps alg adv bitTrace = some prefSt →
            singleStepValidHaltProb alg prefSt.pointSet prefSt.algState
              (adv prefSt.history) = 1) ∧
      (∀ T : ℕ, T ≤ t →
        ENNReal.ofReal (1 - δ) ≤
          adaptivePrefixEventProb alg adv T (AllPrefixAnswersValid c))

/-- Bounded-horizon expected amortized work bound over adaptive executions of length `1 ≤ T ≤ t`. -/
def SatisfiesBoundedExpectedAmortizedWorkBound {d : ℕ} {State : Type}
    (n t : ℕ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) (amortizedWorkBound : ℝ) : Prop :=
  ∀ adv : AdaptiveAdversary d,
    IsValidBoundedAdversary n t admissiblePts alg adv →
      ∀ T : ℕ, 1 ≤ T → T ≤ t →
        adaptivePrefixExpectedWork alg adv T ≠ ⊤ ∧
        (adaptivePrefixExpectedWork alg adv T).toReal / (T : ℝ) ≤ amortizedWorkBound

/-- Bounded-horizon worst-case per-update work bound over adaptive executions up to `t` updates. -/
def SatisfiesBoundedWorstCaseUpdateWorkBound {d : ℕ} {State : Type}
    (n t : ℕ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) (stepWorkBound : ℝ) : Prop :=
  (alg.initWork : ℝ) ≤ stepWorkBound ∧
  ∀ adv : AdaptiveAdversary d,
    IsValidBoundedAdversary n t admissiblePts alg adv →
      ∀ T : ℕ, T ≤ t → ∀ trace : Fin T → List Bool, ∀ out : AdaptivePrefixState d State,
        runAdaptivePrefix alg adv T trace = some out →
          ∀ w ∈ out.stepWorks, (w : ℝ) ≤ stepWorkBound

/-- Bounded-horizon peak space bound over adaptive executions up to `t` updates. -/
def SatisfiesBoundedSpaceBound {d : ℕ} {State : Type}
    (n t : ℕ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) (spaceBound : ℝ) : Prop :=
  (alg.initSpace : ℝ) ≤ spaceBound ∧
  ∀ adv : AdaptiveAdversary d,
    IsValidBoundedAdversary n t admissiblePts alg adv →
      ∀ T : ℕ, T ≤ t → ∀ trace : Fin T → List Bool, ∀ out : AdaptivePrefixState d State,
        runAdaptivePrefix alg adv T trace = some out →
          (out.maxSpace : ℝ) ≤ spaceBound

/-- Unbounded-horizon expected amortized work bound: for every valid adaptive adversary and every
fixed finite prefix length `T ≥ 1` starting from `P = ∅`, the expected total work during those `T`
updates divided by `T` is at most `amortizedWorkBound`. -/
def SatisfiesExpectedAmortizedWorkBound {d : ℕ} {State : Type}
    (n : ℕ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) (amortizedWorkBound : ℝ) : Prop :=
  ∀ adv : AdaptiveAdversary d,
    IsValidAdaptiveAdversary n admissiblePts alg adv →
      ∀ T : ℕ, 1 ≤ T →
        adaptivePrefixExpectedWork alg adv T ≠ ⊤ ∧
        (adaptivePrefixExpectedWork alg adv T).toReal / (T : ℝ) ≤ amortizedWorkBound

/-- Unbounded-horizon worst-case per-update work bound across all finite prefixes of any adaptive
execution. -/
def SatisfiesUnboundedWorstCaseUpdateWorkBound {d : ℕ} {State : Type}
    (n : ℕ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) (stepWorkBound : ℝ) : Prop :=
  (alg.initWork : ℝ) ≤ stepWorkBound ∧
  ∀ adv : AdaptiveAdversary d,
    IsValidAdaptiveAdversary n admissiblePts alg adv →
      ∀ T : ℕ, ∀ trace : Fin T → List Bool, ∀ out : AdaptivePrefixState d State,
        runAdaptivePrefix alg adv T trace = some out →
          ∀ w ∈ out.stepWorks, (w : ℝ) ≤ stepWorkBound

/-- Unbounded-horizon peak space bound across all finite prefixes of any adaptive execution. -/
def SatisfiesUnboundedSpaceBound {d : ℕ} {State : Type}
    (n : ℕ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) (spaceBound : ℝ) : Prop :=
  (alg.initSpace : ℝ) ≤ spaceBound ∧
  ∀ adv : AdaptiveAdversary d,
    IsValidAdaptiveAdversary n admissiblePts alg adv →
      ∀ T : ℕ, ∀ trace : Fin T → List Bool, ∀ out : AdaptivePrefixState d State,
        runAdaptivePrefix alg adv T trace = some out →
          (out.maxSpace : ℝ) ≤ spaceBound

/-- Always-correct (Las Vegas) correctness and almost-sure termination guarantee supplied with
capacity `n` and no update horizon: every reachable legal operation terminates with probability one,
and every maintained answer on every halting execution path satisfies its factor-`c` approximation
guarantee. -/
def SatisfiesLasVegasCorrectness {d : ℕ} {State : Type}
    (n : ℕ) (c : ℝ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) : Prop :=
  ∀ adv : AdaptiveAdversary d,
    IsValidAdaptiveAdversary n admissiblePts alg adv →
      (∀ bitTrace : List (List Bool), ∀ prefSt : AdaptivePrefixState d State,
        runAdaptiveSteps alg adv bitTrace = some prefSt →
          singleStepValidHaltProb alg prefSt.pointSet prefSt.algState
            (adv prefSt.history) = 1) ∧
      (∀ T : ℕ, ∀ trace : Fin T → List Bool, ∀ out : AdaptivePrefixState d State,
        runAdaptivePrefix alg adv T trace = some out →
          AllPrefixAnswersValid c out)

/-- Full Las Vegas adaptive guarantee (with no update horizon): always-correct answers, probability-1
termination of every operation, and expected amortized work at most `amortizedWorkBound` over every
fixed finite prefix of length `T ≥ 1` starting from `P = ∅`. -/
def SatisfiesLasVegasGuarantee {d : ℕ} {State : Type}
    (n : ℕ) (c amortizedWorkBound : ℝ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (alg : DynamicDiameterStructure d State) : Prop :=
  SatisfiesLasVegasCorrectness n c admissiblePts alg ∧
  SatisfiesExpectedAmortizedWorkBound n admissiblePts alg amortizedWorkBound

end UL
