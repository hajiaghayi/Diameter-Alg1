import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_dynamic_points_model
import UL.Def.def_local_matching
import UL.Def.def_7_birth_pool
import UL.Def.def_C_2_schedule
set_option autoImplicit false

/-! Algorithm 4 (Sec. C.2: One external update and its cached diameter answer) (paper p.54).
Definitions only: no theorems, no notation, no axioms.
Models Algorithm 4 (lines 1–12) together with the standing state representations and assumptions of
Section 3 (p. 13), Section 5.1 (p. 17), Section 7.2–7.3 (pp. 32–34), and Section C.2 (pp. 52–54),
covering both `1 < c < √2` (maintaining local matchings and unmatched angular indices) and the
exact endpoint `c = √2` (omitting local matchings and angular indices). -/

namespace UL

/-! ### 1. Operating mode (`1 < c < √2` vs `c = √2`), schedule budgets, and point updates -/

/-- Operating regime of Algorithm 4:
- `endpointSqrt2`: omits local matchings and angular search indices (`BackgroundIndexMode.radiusDictOnly`),
  maintaining only pools, radius dictionaries, baseline witness pairs, and exact leaf pairs (used at
  `c = √2` in Theorem 1.2 and Lemma 7.2);
- `subSqrt2 params`: maintains pools, radius dictionaries, baseline witness pairs, exact leaf pairs,
  and local configuration matchings with unmatched angular indices for `params : LocalScaleParams`
  (`BackgroundIndexMode.radiusDictAndLocalSearch`, used for `1 < c < √2` in Theorem 1.1 and
  Section 9). -/
inductive Alg4Mode : Type
  | endpointSqrt2
  | subSqrt2 (params : LocalScaleParams)

/-- Corresponding `BackgroundIndexMode` from `UL.Def.def_C_2_schedule` for `mode : Alg4Mode`. -/
def Alg4Mode.backgroundIndexMode : Alg4Mode → BackgroundIndexMode
  | .endpointSqrt2 => .radiusDictOnly
  | .subSqrt2 _ => .radiusDictAndLocalSearch

open Classical in
/-- Active retained local configurations at variance `V` under `mode : Alg4Mode`: empty at the
`c = √2` endpoint or when `V ≤ 0`, and equal to `params.retainedConfigs V` when `mode = .subSqrt2 params`
and `0 < V`. -/
noncomputable def Alg4Mode.retainedConfigs (mode : Alg4Mode) (V : ℝ) : Finset ShellConfig :=
  match mode with
  | .endpointSqrt2 => ∅
  | .subSqrt2 params => if 0 < V then params.retainedConfigs V else ∅

/-- Equation (11) completion tick bound `⌊α^2 m / (64 C_*)⌋` within which a large background level
born on `m` points finishes its two-scan construction under the prescribed per-tick budget. -/
noncomputable def maxLevelBuildTicks (α : ℝ) (m : ℕ) : ℕ :=
  ⌊α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ))⌋₊

/-- Prescribed construction work budget `jobBudgetMult * C_* * α^{-2} * A(n)` allocated per affected
root-pool tick to a pending replacement job (Section C.2, p. 53), where `A(n)` is the birth-pool
target time from `UL.Def.def_7_birth_pool`. -/
noncomputable def prescribedJobTickBudget (jobBudgetMult α A_n : ℝ) : ℝ :=
  jobBudgetMult * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ * A_n

/-- Combined Section 7 and Section C.2 parameter and budget bundle for Algorithm 4: schedule
parameters `sched : ScheduleParams` (encoding capacity `n ≥ 2`, depth `α ∈ (0, 1/2]`, center cost
`C ≥ 0`, baseline sample count `K₀`, and Equation (10) leaf cutoff `L`), birth-pool exponents
`(σ, θ)` and polynomial overhead factors `facs : BirthPoolPolyFactors`, per-job-tick construction
multiplier `jobBudgetMult`, incremental reclamation multiplier `reclaimMult`, and record outdegree
bound `outdegreeBound`. -/
structure Alg4BudgetParams where
  sched : ScheduleParams
  σ : ℝ
  θ : ℝ
  facs : BirthPoolPolyFactors
  jobBudgetMult : ℝ
  reclaimMult : ℕ
  outdegreeBound : ℕ

/-- Validity of `Alg4BudgetParams`: valid birth-pool exponents (`n ≥ 2`, `0 ≤ σ ≤ θ`), valid
multiplicative overhead factors (`≥ 1`), positive construction budget multiplier, and positive
reclamation multiplier (`≥ 1`). -/
def Alg4BudgetParams.Valid (bp : Alg4BudgetParams) : Prop :=
  ValidBirthPoolExponents bp.sched.n bp.σ bp.θ ∧
  bp.facs.Valid ∧
  0 < bp.jobBudgetMult ∧
  1 ≤ bp.reclaimMult

/-- Target birth-pool operation time `A(n) = n^θ P_time` for `bp : Alg4BudgetParams`. -/
noncomputable def Alg4BudgetParams.targetTime (bp : Alg4BudgetParams) : ℝ :=
  bp.facs.targetTime bp.sched.n bp.θ

/-- Prescribed per-affected-tick construction work budget for a pending job under `bp`. -/
noncomputable def Alg4BudgetParams.jobTickBudget (bp : Alg4BudgetParams) : ℝ :=
  prescribedJobTickBudget bp.jobBudgetMult bp.sched.α bp.targetTime

/-- Space bound `m^{1+σ} P_space` for a retained birth pool of size `m` under `bp`. -/
noncomputable def Alg4BudgetParams.birthSpaceBound (bp : Alg4BudgetParams) (m : ℕ) : ℝ :=
  bp.facs.spaceBound m bp.σ

/-- One point insertion or deletion presented to Algorithm 4 over identity/handle type `ι` in `ℝ^d`. -/
inductive Alg4PointUpdate (d : ℕ) (ι : Type*) where
  | insert (id : ι) (pt : EuclideanSpace ℝ (Fin d))
  | delete (id : ι)

open Classical in
/-- Updated active identity set `P'` obtained by applying `upd` to `P`. -/
noncomputable def applyAlg4PointSetUpdate {d : ℕ} {ι : Type*}
    (P : Finset ι) : Alg4PointUpdate d ι → Finset ι
  | .insert id _ => insert id P
  | .delete id => P.erase id

open Classical in
/-- Updated internal coordinate table: an insertion binds the fresh/released identity `id` to `pt`
while leaving all other coordinates (including active points and retained birth snapshots) fixed; a
deletion leaves coordinates intact until all retained snapshots release `id`. -/
noncomputable def updateAlg4Coords {d : ℕ} {ι : Type*}
    (coords : ι → EuclideanSpace ℝ (Fin d)) :
    Alg4PointUpdate d ι → (ι → EuclideanSpace ℝ (Fin d))
  | .insert id pt => Function.update coords id pt
  | .delete _ => coords

/-! ### 2. Radius dictionaries, checked local matching updates, and baseline/leaf caches -/

/-- Radius dictionary state at a serving or pending level with center `o`: tracks the currently
heap-indexed active subset `indexedIds`, stored exact squared radii `‖pts i - o‖^2`, and cached
maximum-radius witness `maxWitness` with squared radius `maxDistSq`. -/
structure RadiusDictState (ι : Type*) where
  indexedIds : Finset ι
  sqRadii : ι → ℝ
  maxWitness : Option ι
  maxDistSq : ℝ

/-- Empty `RadiusDictState`. -/
def RadiusDictState.empty (ι : Type*) : RadiusDictState ι :=
  { indexedIds := ∅
    sqRadii := fun _ => 0
    maxWitness := none
    maxDistSq := 0 }

/-- Well-formedness of `dict : RadiusDictState ι` over indexed active subset `target`: `indexedIds`
equals `target`, every indexed point stores its exact squared radius to `o`, and `maxWitness` caches
an active point attaining `nodeMaxRadius pts o target` when `target` is nonempty (`none` with `0`
when `target = ∅`). -/
def RadiusDictState.WellFormedOn {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (target : Finset ι) (dict : RadiusDictState ι) : Prop :=
  dict.indexedIds = target ∧
  (∀ i ∈ dict.indexedIds, dict.sqRadii i = euclideanDistSq (pts i) o) ∧
  (dict.indexedIds = ∅ → dict.maxWitness = none ∧ dict.maxDistSq = 0) ∧
  (dict.indexedIds.Nonempty →
    ∃ y : ι,
      dict.maxWitness = some y ∧
      IsNodeMaxRadiusPoint pts o dict.indexedIds y ∧
      dict.maxDistSq = euclideanDistSq (pts y) o)

/-- Complete radius dictionary invariant on a serving node's full input pool `S`. -/
def RadiusDictState.IsComplete {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S : Finset ι) (dict : RadiusDictState ι) : Prop :=
  dict.WellFormedOn pts o S

/-- Partial radius dictionary invariant during Scan 1 of an opened pending level on input pool `S`:
`indexedIds` is the subset of currently active points whose `heapIndexed` flag is set. -/
def RadiusDictState.IsScanValid {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S : Finset ι) (dict : RadiusDictState ι) : Prop :=
  dict.indexedIds ⊆ S ∧ dict.WellFormedOn pts o dict.indexedIds

open Classical in
/-- Select an active maximum-radius witness in `target` relative to `o`, honoring `hint` whenever
`hint` already attains `nodeMaxRadius pts o target`. -/
noncomputable def chooseMaxRadiusWitness {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (target : Finset ι) (hint : Option ι) : Option ι :=
  if hT : target.Nonempty then
    match hint with
    | some y =>
        if IsNodeMaxRadiusPoint pts o target y then some y
        else if hMax : ∃ z : ι, IsNodeMaxRadiusPoint pts o target z then some (Classical.choose hMax)
        else some hT.choose
    | none =>
        if hMax : ∃ z : ι, IsNodeMaxRadiusPoint pts o target z then some (Classical.choose hMax)
        else some hT.choose
  else
    none

/-- Construct a well-formed `RadiusDictState` on `target` relative to center `o`, honoring
maximum-radius tie-breaker `hint` when valid. -/
noncomputable def buildRadiusDictOn {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (target : Finset ι) (hint : Option ι) : RadiusDictState ι :=
  let mw := chooseMaxRadiusWitness pts o target hint
  { indexedIds := target
    sqRadii := fun i => euclideanDistSq (pts i) o
    maxWitness := mw
    maxDistSq :=
      match mw with
      | none => 0
      | some y => euclideanDistSq (pts y) o }

open Classical in
/-- Update a radius dictionary under a `PoolUpdateEvent` (Section C.2, pp. 52–53):
- an external insertion indexes the new point immediately;
- an external deletion removes the record only if it is currently heap-indexed (`∈ dict.indexedIds`);
- virtual value deletions and unaffected steps leave the radius dictionary unchanged. -/
noncomputable def updateRadiusDictOnEvent {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (dict : RadiusDictState ι) (ev : PoolUpdateEvent ι) (maxHint : Option ι) :
    RadiusDictState ι :=
  match ev with
  | .externalInsert p =>
      let rSq := euclideanDistSq (pts p) o
      let nextIds := insert p dict.indexedIds
      let keepOld : Option ι :=
        match dict.maxWitness with
        | some y => if rSq ≤ dict.maxDistSq then some y else some p
        | none => some p
      buildRadiusDictOn pts o nextIds (maxHint.or keepOld)
  | .externalDelete p =>
      if p ∈ dict.indexedIds then
        buildRadiusDictOn pts o (dict.indexedIds.erase p) maxHint
      else
        dict
  | .virtualValueDelete => dict
  | .unaffected => dict

open Classical in
/-- Scan-1 batch step on a pending level's radius dictionary (Section C.2, pp. 52–53): examines a
batch of immutable `birthSnapshot` identities `scanBatch`, skipping any identity whose lifetime is
dead (`∉ S_cur`) or already heap-indexed (`∈ dict.indexedIds`), and indexing the remaining live
points. -/
noncomputable def scan1RadiusDictBatch {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S_cur : Finset ι) (dict : RadiusDictState ι)
    (scanBatch : Finset ι) (maxHint : Option ι) : RadiusDictState ι :=
  let newlyIndexed := (scanBatch ∩ S_cur) \ dict.indexedIds
  buildRadiusDictOn pts o (dict.indexedIds ∪ newlyIndexed) (maxHint.or dict.maxWitness)

open Classical in
/-- Checked positive search answer for `Attach(v)` (Section 7.3, p. 33: "Every reported positive
answer is checked against current identities"): accepts `some w` iff `w` currently belongs to the
opposite unmatched index (`st.oppositeIndexSet v.side`) and satisfies the exact weak-edge
correlation test `⟨-u_v, u_w⟩ > b` (note self-edges have nonpositive correlation `≤ 0 ≤ b` and
cannot pass); otherwise treats the answer as `none`. -/
noncomputable def sanitizeConfigAttachAnswer {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) (st : LocalMatchingState ι) (v : CopyVertex ι)
    (rawAns : Option ι) : Option ι :=
  match rawAns with
  | none => none
  | some w =>
      if w ∈ st.oppositeIndexSet v.side ∧
          attachAcceptsCorrelation o (pts v.id) (pts w) (params.thresholdB V cfg.j cfg.k cfg.ℓ) then
        some w
      else
        none

/-- Raw angular search answers supplied to Algorithm 2 across local configurations during a single
point insertion or deletion at a node. -/
structure NodeMatchingQueryAnswers (ι : Type*) where
  insertLeftAns : ShellConfig → Option ι
  insertRightAns : ShellConfig → Option ι
  deleteRepairAns : ShellConfig → List (Option ι)

/-- Empty/trivial `NodeMatchingQueryAnswers` returning `none` / `[]` everywhere (used e.g. at the
`c = √2` endpoint or when unaffected). -/
def NodeMatchingQueryAnswers.empty (ι : Type*) : NodeMatchingQueryAnswers ι :=
  { insertLeftAns := fun _ => none
    insertRightAns := fun _ => none
    deleteRepairAns := fun _ => [] }

open Classical in
/-- `InsertOriginal(p)` for one configuration `cfg` using checked positive search answers. -/
noncomputable def checkedConfigInsertOriginal {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) (st : LocalMatchingState ι) (p : ι)
    (rawLeft rawRight : Option ι) : LocalMatchingState ι :=
  let st₁ :=
    if hasApplicableLeftCopy params.m0 o V cfg.j (pts p) then
      let vL : CopyVertex ι := ⟨.left, p⟩
      attachStep pts st vL (sanitizeConfigAttachAnswer pts params o V cfg st vL rawLeft)
    else
      st
  if hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p) then
    let vR : CopyVertex ι := ⟨.right, p⟩
    attachStep pts st₁ vR (sanitizeConfigAttachAnswer pts params o V cfg st₁ vR rawRight)
  else
    st₁

open Classical in
/-- Sequential repair of surviving former partners `F` for one configuration `cfg` using checked
positive search answers (defaulting to `none` if `rawAnswers` ends early, so every newly unmatched
partner in `F` is always repaired). -/
noncomputable def checkedRepairFormerPartners {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) :
    LocalMatchingState ι → List (CopyVertex ι) → List (Option ι) → LocalMatchingState ι
  | st, [], _ => st
  | st, u :: us, rawAnswers =>
      if st.isCopyMatched u ∨ st.isCopyInIndex u then
        checkedRepairFormerPartners pts params o V cfg st us rawAnswers
      else
        let rawAns := rawAnswers.head?.join
        let rest := rawAnswers.drop 1
        let checkedAns := sanitizeConfigAttachAnswer pts params o V cfg st u rawAns
        checkedRepairFormerPartners pts params o V cfg (attachStep pts st u checkedAns) us rest

/-- `DeleteOriginal(p)` for one configuration `cfg` using checked positive search answers. -/
noncomputable def checkedConfigDeleteOriginal {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) (st : LocalMatchingState ι) (p : ι)
    (rawAnswers : List (Option ι)) : LocalMatchingState ι :=
  checkedRepairFormerPartners pts params o V cfg
    (removeCopiesFromState st p) (survivingFormerPartners st p) rawAnswers

open Classical in
/-- Apply point insertion `p` across all retained local configurations of `ball` under `mode`
(no-op at `c = √2` or when `ball.V ≤ 0`). -/
noncomputable def applyNodeMatchingInsert {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
    (states : ShellConfig → LocalMatchingState ι) (p : ι)
    (qAns : NodeMatchingQueryAnswers ι) : ShellConfig → LocalMatchingState ι :=
  match mode with
  | .endpointSqrt2 => fun _ => LocalMatchingState.empty ι
  | .subSqrt2 params =>
      fun cfg =>
        if cfg ∈ mode.retainedConfigs ball.V then
          checkedConfigInsertOriginal pts params ball.o ball.V cfg (states cfg) p
            (qAns.insertLeftAns cfg) (qAns.insertRightAns cfg)
        else
          LocalMatchingState.empty ι

open Classical in
/-- Apply point deletion `p` across all retained local configurations of `ball` under `mode`
(no-op at `c = √2` or when `ball.V ≤ 0`). -/
noncomputable def applyNodeMatchingDelete {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
    (states : ShellConfig → LocalMatchingState ι) (p : ι)
    (qAns : NodeMatchingQueryAnswers ι) : ShellConfig → LocalMatchingState ι :=
  match mode with
  | .endpointSqrt2 => fun _ => LocalMatchingState.empty ι
  | .subSqrt2 params =>
      fun cfg =>
        if cfg ∈ mode.retainedConfigs ball.V then
          checkedConfigDeleteOriginal pts params ball.o ball.V cfg (states cfg) p
            (qAns.deleteRepairAns cfg)
        else
          LocalMatchingState.empty ι

/-- Unconditional structural invariant of local matching states at `ball` over classified active
subset `target`: empty outside `mode.retainedConfigs ball.V`, and for each `cfg ∈ mode.retainedConfigs ball.V`
(under `mode = .subSqrt2 params`), `(states cfg)` satisfies `LocalMatchingState.WellFormed` and has
all matching edges in `E_weak`. -/
def ValidNodeMatchingsOn {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
    (target : Finset ι) (states : ShellConfig → LocalMatchingState ι) : Prop :=
  (∀ cfg ∉ mode.retainedConfigs ball.V, states cfg = LocalMatchingState.empty ι) ∧
  match mode with
  | .endpointSqrt2 => True
  | .subSqrt2 params =>
      ∀ cfg ∈ mode.retainedConfigs ball.V,
        (states cfg).WellFormed pts
          (params.leftVertices pts ball.o ball.V target cfg.j)
          (params.rightVertices pts ball.o ball.V target cfg.k) ∧
        (states cfg).matching ⊆ params.weakEdges pts ball.o ball.V target cfg.j cfg.k cfg.ℓ

/-- Full local matching invariant at `ball` over `target` on the good angular-search event:
every retained configuration satisfies `LocalMatchingState.SatisfiesInvariant` (including
`E_strong ∩ (U_L × U_R) = ∅`). -/
def GoodNodeMatchingsOn {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
    (target : Finset ι) (states : ShellConfig → LocalMatchingState ι) : Prop :=
  ValidNodeMatchingsOn pts mode ball target states ∧
  match mode with
  | .endpointSqrt2 => True
  | .subSqrt2 params =>
      ∀ cfg ∈ mode.retainedConfigs ball.V,
        (states cfg).SatisfiesInvariant pts
          (params.leftVertices pts ball.o ball.V target cfg.j)
          (params.rightVertices pts ball.o ball.V target cfg.k)
          (params.weakEdges pts ball.o ball.V target cfg.j cfg.k cfg.ℓ)
          (params.strongEdges pts ball.o ball.V target cfg.j cfg.k cfg.ℓ)

open Classical in
/-- Select an element of `xs` maximizing `f`, starting from `best`. -/
noncomputable def pickMaxByReal {α : Type*} (f : α → ℝ) : α → List α → α
  | best, [] => best
  | best, x :: xs =>
      if f best < f x then pickMaxByReal f x xs else pickMaxByReal f best xs

open Classical in
/-- Refresh a serving node's baseline pair on current input pool `S` (Algorithm 4, line 10;
Section 5.1, pp. 16–17): uses maximum-radius point `y ∈ S` from `dict` and takes the farthest active
sample `p*` from `y` among `samples` (defaulting to `y` if no sample in `samples` lies in `S`),
returning `(none, 0)` when `S = ∅`. Always produces an `IsActiveNodePair S` with exact cached
squared distance `‖pts y - pts p*‖^2`. -/
noncomputable def refreshBaselineFromSamples {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S : Finset ι) (dict : RadiusDictState ι) (samples : List ι) :
    Option (ι × ι) × ℝ :=
  match chooseMaxRadiusWitness pts o S dict.maxWitness with
  | none => (none, 0)
  | some y =>
      let activeSamps := samples.filter (fun p => p ∈ S)
      let pStar :=
        match activeSamps with
        | [] => y
        | s :: ss => pickMaxByReal (fun p => euclideanDistSq (pts p) (pts y)) s ss
      (some (y, pStar), euclideanDistSq (pts y) (pts pStar))

open Classical in
/-- Refresh the maximum cached local matching witness at a serving node (Algorithm 4, line 10):
takes a `storedEdge` maximizing exact squared Euclidean distance across all nonempty matchings in
`mode.retainedConfigs ball.V` (`(none, 0)` at `c = √2`, when `ball.V ≤ 0`, or when all retained
matchings are empty). -/
noncomputable def refreshMaxMatchingWitness {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
    (states : ShellConfig → LocalMatchingState ι) (hintCfg : Option ShellConfig) :
    Option (ι × ι) × ℝ :=
  let nonemptyCfgs :=
    (mode.retainedConfigs ball.V).filter (fun cfg => ((states cfg).storedEdge).isSome)
  if hNE : nonemptyCfgs.Nonempty then
    let edgeSq (cfg : ShellConfig) : ℝ :=
      match (states cfg).storedEdge with
      | none => 0
      | some (x, y) => euclideanDistSq (pts x) (pts y)
    let bestSq := nonemptyCfgs.sup' hNE edgeSq
    let isBest (cfg : ShellConfig) : Prop := cfg ∈ nonemptyCfgs ∧ edgeSq cfg = bestSq
    let chosenCfg : ShellConfig :=
      match hintCfg with
      | some c =>
          if isBest c then c
          else if hEx : ∃ c', isBest c' then Classical.choose hEx
          else hNE.choose
      | none =>
          if hEx : ∃ c', isBest c' then Classical.choose hEx
          else hNE.choose
    match (states chosenCfg).storedEdge with
    | none => (none, 0)
    | some (x, y) => (some (x, y), euclideanDistSq (pts x) (pts y))
  else
    (none, 0)

open Classical in
/-- Compute an exact diameter pair for a polynomial-size leaf `S` (Algorithm 4, line 9): returns
`(none, 0)` when `|S| ≤ 1`, and two distinct active identities `(u, v)` in `S` attaining
`indexedEuclideanDiam S pts` together with their exact squared distance when `|S| ≥ 2`. -/
noncomputable def computeExactLeafAnswer {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι)
    (hint : Option (ι × ι)) : Option (ι × ι) × ℝ :=
  if S.card ≤ 1 then
    (none, 0)
  else
    let isExact (uv : ι × ι) : Prop :=
      uv.1 ∈ S ∧ uv.2 ∈ S ∧ uv.1 ≠ uv.2 ∧
        ‖pts uv.1 - pts uv.2‖ = indexedEuclideanDiam S pts
    let chosen : Option (ι × ι) :=
      match hint with
      | some uv =>
          if isExact uv then some uv
          else if hEx : ∃ uv', isExact uv' then some (Classical.choose hEx)
          else none
      | none =>
          if hEx : ∃ uv', isExact uv' then some (Classical.choose hEx)
          else none
    match chosen with
    | none => (none, 0)
    | some (u, v) => (some (u, v), euclideanDistSq (pts u) (pts v))

/-! ### 3. Pending levels, replacement jobs, serving nodes, retirement queue, and full state -/

/-- Full state of an opened fixed-ball level inside the completed prefix of a pending replacement
job, extending `OpenedJobLevel d ι` with its true input-change age, elapsed job-root ticks, and
two-scan state (`heapIndexedIds` for Scan 1 on `radiusDict`, and `scan2Snapshot` / `classifiedIds`
for Scan 2 on the outside-ball child and `localMatchings`). -/
structure Alg4OpenedLevel (d : ℕ) (ι : Type*) where
  birthSnapshot : Finset ι
  ball : ChainNode d
  indexMode : BackgroundIndexMode
  backgroundReady : Bool
  trueInputAge : ℕ
  elapsedRootTicks : ℕ
  scan2Snapshot : Finset ι
  heapIndexedIds : Finset ι
  classifiedIds : Finset ι
  radiusDict : RadiusDictState ι
  localMatchings : ShellConfig → LocalMatchingState ι

/-- Projection of `Alg4OpenedLevel` onto `OpenedJobLevel` from `UL.Def.def_C_2_schedule`. -/
def Alg4OpenedLevel.toOpenedJobLevel {d : ℕ} {ι : Type*}
    (lv : Alg4OpenedLevel d ι) : OpenedJobLevel d ι :=
  { birthSnapshot := lv.birthSnapshot
    ball := lv.ball
    indexMode := lv.indexMode
    backgroundReady := lv.backgroundReady }

/-- Invariant of an `Alg4OpenedLevel` on its current input pool `S_lv`:
`trueInputAge ≤ elapsedRootTicks`, `HasNodeAge birthSnapshot S_lv trueInputAge`, valid Scan-1
radius dictionary on `heapIndexedIds ⊆ S_lv`, valid Scan-2 local matchings on `classifiedIds ⊆ S_lv`,
and full coverage `heapIndexedIds = S_lv ∧ classifiedIds = S_lv` once `backgroundReady = true`. -/
def Alg4OpenedLevel.WellFormed {d : ℕ} {ι : Type*}
    (lv : Alg4OpenedLevel d ι) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_lv : Finset ι) : Prop :=
  lv.indexMode = mode.backgroundIndexMode ∧
  IsLargeResidualLevel L lv.birthSnapshot.card ∧
  PassesBirthCoreCheck α pts lv.ball lv.birthSnapshot ∧
  lv.trueInputAge ≤ lv.elapsedRootTicks ∧
  HasNodeAge lv.birthSnapshot S_lv lv.trueInputAge ∧
  lv.heapIndexedIds ⊆ S_lv ∧
  lv.classifiedIds ⊆ S_lv ∧
  lv.radiusDict.WellFormedOn pts lv.ball.o lv.heapIndexedIds ∧
  ValidNodeMatchingsOn pts mode lv.ball lv.classifiedIds lv.localMatchings ∧
  (lv.backgroundReady = true → lv.heapIndexedIds = S_lv ∧ lv.classifiedIds = S_lv)

/-- Full state of a pending replacement job owned by a serving node, extending
`PendingReplacementJob d ι` with `Alg4OpenedLevel`s and the maintained exact leaf pair once
`closedAsLeaf = true`. -/
structure Alg4PendingJob (d : ℕ) (ι : Type*) where
  deadlineTicks : ℕ
  remainingTicks : ℕ
  completedPrefix : List (Alg4OpenedLevel d ι)
  currentResidual : Finset ι
  closedAsLeaf : Bool
  closedLeafAnswer : Option (ι × ι)
  closedLeafDistSq : ℝ

/-- Projection of `Alg4PendingJob` onto `PendingReplacementJob` from `UL.Def.def_C_2_schedule`. -/
def Alg4PendingJob.toPendingReplacementJob {d : ℕ} {ι : Type*}
    (job : Alg4PendingJob d ι) : PendingReplacementJob d ι :=
  { deadlineTicks := job.deadlineTicks
    remainingTicks := job.remainingTicks
    completedPrefix := job.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel
    currentResidual := job.currentResidual
    closedAsLeaf := job.closedAsLeaf }

/-- Readiness of `job : Alg4PendingJob d ι` to be installed in Line 7 (`0` remaining ticks, residual
closed as leaf, and all prefix levels `backgroundReady`). -/
def Alg4PendingJob.IsReadyToInstall {d : ℕ} {ι : Type*} (job : Alg4PendingJob d ι) : Prop :=
  job.toPendingReplacementJob.IsReadyToInstall

/-- Input pool reaching the `j`-th level inside `completedPrefix` from root pool `S_root`. -/
noncomputable def alg4PrefixInputAt {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (completedPrefix : List (Alg4OpenedLevel d ι))
    (S_root : Finset ι) (j : ℕ) : Finset ι :=
  (completedPrefix.take j).foldl (fun S lv => lv.ball.residual pts S) S_root

/-- Initialize a new `Alg4PendingJob` on root-pool snapshot `S_root` (`|S_root| > 4L`) with
deadline `H = ⌊α |S_root| / C_*⌋` further root-pool ticks (Line 9). -/
noncomputable def Alg4PendingJob.init {d : ℕ} {ι : Type*}
    (α : ℝ) (S_root : Finset ι) : Alg4PendingJob d ι :=
  let H := jobDeadlineTicks α S_root.card
  { deadlineTicks := H
    remainingTicks := H
    completedPrefix := []
    currentResidual := S_root
    closedAsLeaf := false
    closedLeafAnswer := none
    closedLeafDistSq := 0 }

/-- Invariant of an `Alg4PendingJob` on its owning serving node's current pool `S_root`. -/
def Alg4PendingJob.WellFormed {d : ℕ} {ι : Type*}
    (job : Alg4PendingJob d ι) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_root : Finset ι) : Prop :=
  job.toPendingReplacementJob.WellFormed α L pts S_root ∧
  (∀ j : Fin job.completedPrefix.length,
    let lv := job.completedPrefix[j]
    lv.elapsedRootTicks ≤ job.deadlineTicks - job.remainingTicks ∧
    lv.WellFormed mode α L pts (alg4PrefixInputAt pts job.completedPrefix S_root j.val)) ∧
  (if job.closedAsLeaf then
    IsExactLeafAnswer pts job.currentResidual job.closedLeafAnswer ∧
    job.closedLeafDistSq = (baselinePairLength pts job.closedLeafAnswer) ^ 2
  else
    job.closedLeafAnswer = none ∧ job.closedLeafDistSq = 0)

/-- Full state of an active serving node in Algorithm 4, extending `ServingNodeState d ι` with its
true input-change age `trueAge` (`≤ age`), complete radius dictionary, local configuration
matchings, cached baseline pair, cached maximum local matching witness, and optional pending job. -/
structure Alg4ServingNode (d : ℕ) (ι : Type*) where
  birthSnapshot : Finset ι
  node : ChainNode d
  trueAge : ℕ
  age : ℕ
  radiusDict : RadiusDictState ι
  localMatchings : ShellConfig → LocalMatchingState ι
  baselinePair : Option (ι × ι)
  baselineDistSq : ℝ
  maxMatchingPair : Option (ι × ι)
  maxMatchingDistSq : ℝ
  ownedJob : Option (Alg4PendingJob d ι)

/-- Projection of `Alg4ServingNode` onto `ServingNodeState` from `UL.Def.def_C_2_schedule`. -/
def Alg4ServingNode.toServingNodeState {d : ℕ} {ι : Type*}
    (st : Alg4ServingNode d ι) : ServingNodeState d ι :=
  { birthSnapshot := st.birthSnapshot
    node := st.node
    age := st.age
    ownedJob := st.ownedJob.map Alg4PendingJob.toPendingReplacementJob }

/-- Structural and schedule invariant of an `Alg4ServingNode` on current serving pool `S_cur`
(holding unconditionally on every execution outcome, including fallback and capped-failure
outcomes). -/
def Alg4ServingNode.WellFormed {d : ℕ} {ι : Type*}
    (st : Alg4ServingNode d ι) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_cur : Finset ι) : Prop :=
  st.toServingNodeState.WellFormed α L pts S_cur ∧
  st.trueAge ≤ st.age ∧
  HasNodeAge st.birthSnapshot S_cur st.trueAge ∧
  st.radiusDict.IsComplete pts st.node.o S_cur ∧
  ValidNodeMatchingsOn pts mode st.node S_cur st.localMatchings ∧
  IsActiveNodePair S_cur st.baselinePair ∧
  st.baselineDistSq = (baselinePairLength pts st.baselinePair) ^ 2 ∧
  (match st.maxMatchingPair with
  | none =>
      st.maxMatchingDistSq = 0 ∧
      ∀ cfg ∈ mode.retainedConfigs st.node.V, (st.localMatchings cfg).storedEdge = none
  | some (x, y) =>
      x ∈ S_cur ∧ y ∈ S_cur ∧ x ≠ y ∧
      st.maxMatchingDistSq = euclideanDistSq (pts x) (pts y) ∧
      (∃ cfg ∈ mode.retainedConfigs st.node.V,
        (st.localMatchings cfg).storedEdge = some (x, y)) ∧
      (∀ cfg ∈ mode.retainedConfigs st.node.V, ∀ u v : ι,
        (st.localMatchings cfg).storedEdge = some (u, v) →
          euclideanDistSq (pts u) (pts v) ≤ st.maxMatchingDistSq)) ∧
  match st.ownedJob with
  | none => True
  | some job => job.WellFormed mode α L pts S_cur

/-- Retired persistent-tree or owned index record on the incremental reclamation queue (Line 11;
Section C.2, p. 53): stores any point identities/handles directly referenced by the record and its
bounded list of outgoing child records, encoded as a non-nested right-spine inductive (`leaf` for a
record with `[]` children and `consChild` prepending one child record) with canonical constructor
and projections `RetiredRecord.node`, `RetiredRecord.retainedIds`, and `RetiredRecord.children`. -/
inductive RetiredRecord (ι : Type*) where
  | leaf (retainedIds : Finset ι)
  | consChild (head : RetiredRecord ι) (tail : RetiredRecord ι)

/-- Point identities/handles directly retained at the root of a `RetiredRecord`. -/
def RetiredRecord.retainedIds {ι : Type*} : RetiredRecord ι → Finset ι
  | .leaf ids => ids
  | .consChild _ tail => tail.retainedIds

/-- Direct outgoing child records of a `RetiredRecord`. -/
def RetiredRecord.children {ι : Type*} : RetiredRecord ι → List (RetiredRecord ι)
  | .leaf _ => []
  | .consChild c tail => c :: tail.children

/-- Canonical constructor assembling a `RetiredRecord` from its `retainedIds` and `children`. -/
def RetiredRecord.node {ι : Type*} (retainedIds : Finset ι) :
    List (RetiredRecord ι) → RetiredRecord ι
  | [] => .leaf retainedIds
  | c :: cs => .consChild c (RetiredRecord.node retainedIds cs)

@[simp] theorem RetiredRecord.retainedIds_node {ι : Type*} (ids : Finset ι) :
    ∀ cs : List (RetiredRecord ι), (RetiredRecord.node ids cs).retainedIds = ids
  | [] => rfl
  | _ :: cs => RetiredRecord.retainedIds_node ids cs

@[simp] theorem RetiredRecord.children_node {ι : Type*} (ids : Finset ι) :
    ∀ cs : List (RetiredRecord ι), (RetiredRecord.node ids cs).children = cs
  | [] => rfl
  | c :: cs => congrArg (List.cons c) (RetiredRecord.children_node ids cs)

@[simp] theorem RetiredRecord.node_eta {ι : Type*} :
    ∀ r : RetiredRecord ι, RetiredRecord.node r.retainedIds r.children = r
  | .leaf _ => rfl
  | .consChild c tail => congrArg (RetiredRecord.consChild c) (RetiredRecord.node_eta tail)

@[simp] theorem RetiredRecord.node_inj {ι : Type*} {ids₁ ids₂ : Finset ι}
    {cs₁ cs₂ : List (RetiredRecord ι)} :
    RetiredRecord.node ids₁ cs₁ = RetiredRecord.node ids₂ cs₂ ↔ ids₁ = ids₂ ∧ cs₁ = cs₂ := by
  constructor
  · intro h
    have h₁ := congrArg RetiredRecord.retainedIds h
    rw [RetiredRecord.retainedIds_node, RetiredRecord.retainedIds_node] at h₁
    have h₂ := congrArg RetiredRecord.children h
    rw [RetiredRecord.children_node, RetiredRecord.children_node] at h₂
    exact ⟨h₁, h₂⟩
  · rintro ⟨rfl, rfl⟩
    rfl

/-- Rose-tree induction principle on `RetiredRecord` via `(ids, children)`. -/
theorem RetiredRecord.recOnNode {ι : Type*} {motive : RetiredRecord ι → Prop}
    (step : ∀ (ids : Finset ι) (children : List (RetiredRecord ι)),
      (∀ c ∈ children, motive c) → motive (RetiredRecord.node ids children))
    (r : RetiredRecord ι) : motive r := by
  have children_ih : ∀ x : RetiredRecord ι, ∀ c ∈ x.children, motive c := by
    intro x
    induction x with
    | leaf _ =>
        intro _ hc
        cases hc
    | consChild c tail ih_c ih_tail =>
        intro ch hch
        rcases List.mem_cons.mp hch with h_eq | hmem
        · subst h_eq
          have hc : motive (RetiredRecord.node ch.retainedIds ch.children) :=
            step ch.retainedIds ch.children ih_c
          rwa [RetiredRecord.node_eta] at hc
        · exact ih_tail ch hmem
  have hr : motive (RetiredRecord.node r.retainedIds r.children) :=
    step r.retainedIds r.children (children_ih r)
  rwa [RetiredRecord.node_eta] at hr

/-- Structural bounded-outdegree predicate across the direct children along a `RetiredRecord` spine. -/
def RetiredRecord.childrenBounded {ι : Type*} (D_out : ℕ) : RetiredRecord ι → Prop
  | .leaf _ => True
  | .consChild c tail =>
      (c.children.length ≤ D_out ∧ c.childrenBounded D_out) ∧ tail.childrenBounded D_out

/-- Bounded-outdegree condition `children.length ≤ D_out` on a `RetiredRecord` tree. -/
def RetiredRecord.HasBoundedOutdegree {ι : Type*} (D_out : ℕ) (r : RetiredRecord ι) : Prop :=
  r.children.length ≤ D_out ∧ r.childrenBounded D_out

/-- Bounded-outdegree condition across a list of child `RetiredRecord`s. -/
def retiredChildrenHaveBoundedOutdegree {ι : Type*} (D_out : ℕ) : List (RetiredRecord ι) → Prop
  | [] => True
  | ch :: chs => ch.HasBoundedOutdegree D_out ∧ retiredChildrenHaveBoundedOutdegree D_out chs

theorem RetiredRecord.childrenBounded_iff {ι : Type*} (D_out : ℕ) :
    ∀ r : RetiredRecord ι,
      r.childrenBounded D_out ↔ retiredChildrenHaveBoundedOutdegree D_out r.children
  | .leaf _ => Iff.rfl
  | .consChild _ tail => and_congr_right (fun _ => RetiredRecord.childrenBounded_iff D_out tail)

@[simp] theorem RetiredRecord.hasBoundedOutdegree_node {ι : Type*} (D_out : ℕ)
    (ids : Finset ι) (children : List (RetiredRecord ι)) :
    (RetiredRecord.node ids children).HasBoundedOutdegree D_out ↔
      children.length ≤ D_out ∧ retiredChildrenHaveBoundedOutdegree D_out children := by
  unfold RetiredRecord.HasBoundedOutdegree
  rw [RetiredRecord.childrenBounded_iff, RetiredRecord.children_node]

/-- Total number of queued records inside a `RetiredRecord` root and its descendants. -/
def RetiredRecord.totalRecords {ι : Type*} : RetiredRecord ι → ℕ
  | .leaf _ => 1
  | .consChild c tail => c.totalRecords + tail.totalRecords

/-- Total number of queued records across `retirementQueue : List (RetiredRecord ι)`. -/
def retirementQueueRecordCount {ι : Type*} : List (RetiredRecord ι) → ℕ
  | [] => 0
  | r :: rs => r.totalRecords + retirementQueueRecordCount rs

@[simp] theorem RetiredRecord.totalRecords_node {ι : Type*} (ids : Finset ι) :
    ∀ children : List (RetiredRecord ι),
      (RetiredRecord.node ids children).totalRecords = 1 + retirementQueueRecordCount children
  | [] => rfl
  | c :: cs => by
      simp only [RetiredRecord.node, RetiredRecord.totalRecords, retirementQueueRecordCount,
        RetiredRecord.totalRecords_node ids cs]
      omega

/-- Set of point identities/handles still referenced by a `RetiredRecord` and its descendants. -/
noncomputable def RetiredRecord.referencedIds {ι : Type*} : RetiredRecord ι → Finset ι
  | .leaf ids => ids
  | .consChild c tail =>
      open Classical in
      c.referencedIds ∪ tail.referencedIds

/-- Set of point identities/handles referenced across a list of `RetiredRecord`s. -/
noncomputable def retiredListReferencedIds {ι : Type*} : List (RetiredRecord ι) → Finset ι
  | [] => ∅
  | r :: rs =>
      open Classical in
      r.referencedIds ∪ retiredListReferencedIds rs

@[simp] theorem RetiredRecord.referencedIds_node {ι : Type*} [DecidableEq ι] (ids : Finset ι) :
    ∀ children : List (RetiredRecord ι),
      (RetiredRecord.node ids children).referencedIds = ids ∪ retiredListReferencedIds children
  | [] => by
      simp only [RetiredRecord.node, RetiredRecord.referencedIds, retiredListReferencedIds,
        Finset.union_empty]
  | c :: cs => by
      simp only [RetiredRecord.node, RetiredRecord.referencedIds, retiredListReferencedIds,
        RetiredRecord.referencedIds_node ids cs]
      ext x
      simp only [Finset.mem_union]
      tauto

/-- Reclaim one record from the front of `retirementQueue`, appending its outgoing child references
to the queue and returning the updated queue together with the step's constant+outdegree work
(`1 + children.length`). -/
def reclaimOneRecord {ι : Type*} : List (RetiredRecord ι) → List (RetiredRecord ι) × ℕ
  | [] => ([], 0)
  | r :: rest => (rest ++ r.children, 1 + r.children.length)

@[simp] theorem reclaimOneRecord_node {ι : Type*} (ids : Finset ι)
    (children rest : List (RetiredRecord ι)) :
    reclaimOneRecord (.node ids children :: rest) = (rest ++ children, 1 + children.length) := by
  simp only [reclaimOneRecord, RetiredRecord.children_node]

/-- Perform up to `budgetRecords` incremental record-reclamation pops on `retirementQueue`
(Algorithm 4, line 11), returning the remaining queue and total reclamation work. -/
def performRetirementSteps {ι : Type*} :
    ℕ → List (RetiredRecord ι) → List (RetiredRecord ι) × ℕ
  | 0, q => (q, 0)
  | _ + 1, [] => ([], 0)
  | k + 1, r :: rs =>
      let (q₁, w₁) := reclaimOneRecord (r :: rs)
      let (q₂, w₂) := performRetirementSteps k q₁
      (q₂, w₁ + w₂)

@[simp] theorem performRetirementSteps_succ_node {ι : Type*} (k : ℕ) (ids : Finset ι)
    (children rs : List (RetiredRecord ι)) :
    performRetirementSteps (k + 1) (.node ids children :: rs) =
      let (q₂, w₂) := performRetirementSteps k (rs ++ children)
      (q₂, (1 + children.length) + w₂) := by
  simp only [performRetirementSteps, reclaimOneRecord_node]

/-- Complete state maintained across updates by Algorithm 4: current active set `activeSet`,
retained coordinate map `coords`, serving chain `servingNodes`, exact terminal leaf `terminalLeaf`
and its cached pair/squared distance, distinct-identity fallback pair `distinctFallbackPair` (when
`|activeSet| ≥ 2`), incremental `retirementQueue`, and O(1)-retrievable `cachedAnswer`. -/
structure Alg4State (d : ℕ) (ι : Type*) where
  activeSet : Finset ι
  coords : ι → EuclideanSpace ℝ (Fin d)
  servingNodes : List (Alg4ServingNode d ι)
  terminalLeaf : Finset ι
  terminalLeafAnswer : Option (ι × ι)
  terminalLeafDistSq : ℝ
  distinctFallbackPair : Option (ι × ι)
  retirementQueue : List (RetiredRecord ι)
  cachedAnswer : Option (ι × ι) × ℝ

/-- Initial empty `Alg4State` for `P = ∅`. -/
def Alg4State.empty (d : ℕ) (ι : Type*) : Alg4State d ι :=
  { activeSet := ∅
    coords := fun _ => 0
    servingNodes := []
    terminalLeaf := ∅
    terminalLeafAnswer := none
    terminalLeafDistSq := 0
    distinctFallbackPair := none
    retirementQueue := []
    cachedAnswer := (none, 0) }

/-- Projection of `Alg4State` onto `ScheduledServingChain` from `UL.Def.def_C_2_schedule`. -/
def Alg4State.toScheduledServingChain {d : ℕ} {ι : Type*}
    (st : Alg4State d ι) : ScheduledServingChain d ι :=
  { servingNodes := st.servingNodes.map Alg4ServingNode.toServingNodeState
    terminalLeaf := st.terminalLeaf
    terminalLeafAnswer := st.terminalLeafAnswer }

/-- Input pool reaching the `idx`-th serving node (or `terminalLeaf` at `idx = st.servingNodes.length`)
in `st : Alg4State d ι`. -/
noncomputable def Alg4State.servingInputAt {d : ℕ} {ι : Type*}
    (st : Alg4State d ι) (idx : ℕ) : Finset ι :=
  servingChainInputAt st.coords (st.servingNodes.map Alg4ServingNode.toServingNodeState)
    st.activeSet idx

open Classical in
/-- Set of all identities/handles currently referenced by `activeSet`, any live `birthSnapshot` or
`scan2Snapshot` of a serving or pending level, or any record still in `retirementQueue` (Section 7.1,
p. 32: reusable handles are reclaimed only after all retained snapshots release them). -/
noncomputable def Alg4State.liveRetainedIds {d : ℕ} {ι : Type*}
    (st : Alg4State d ι) : Finset ι :=
  let fromJobs (sn : Alg4ServingNode d ι) : Finset ι :=
    match sn.ownedJob with
    | none => ∅
    | some job =>
        job.completedPrefix.foldl
          (fun acc lv => acc ∪ lv.birthSnapshot ∪ lv.scan2Snapshot)
          job.currentResidual
  let fromNodes :=
    st.servingNodes.foldl (fun acc sn => acc ∪ sn.birthSnapshot ∪ fromJobs sn) st.activeSet
  st.retirementQueue.foldl (fun acc r => acc ∪ r.referencedIds) fromNodes

/-- Validity of an external/internal point update `upd : Alg4PointUpdate d ι` on `st : Alg4State d ι`
under capacity `n`: insertions supply a fresh or completely released identity (`∉ st.liveRetainedIds`)
without exceeding `|P| ≤ n`, and deletions specify a currently active identity (`∈ st.activeSet`). -/
def IsValidAlg4PointUpdate {d : ℕ} {ι : Type*}
    (n : ℕ) (st : Alg4State d ι) : Alg4PointUpdate d ι → Prop
  | .insert id _ => id ∉ st.liveRetainedIds ∧ st.activeSet.card + 1 ≤ n
  | .delete id => id ∈ st.activeSet

/-! ### 4. Step oracle choices and line-by-line execution of Algorithm 4 (lines 1–12) -/

/-- Prescribed per-tick construction budget choices for one opened pending level in Line 4: Scan-1
birth-record batch `scan1Batch`, Scan-2 active-classification steps `scan2Steps` (with search
answers), radius-dictionary max tie-breaker `scanMaxHint`, and flag `backgroundIndexesReady`
indicating whether background auxiliary index construction has finished once both scans complete. -/
structure PendingLevelBudgetChoices (ι : Type*) where
  scan1Batch : Finset ι
  scan2Steps : List (ι × NodeMatchingQueryAnswers ι)
  scanMaxHint : Option ι
  backgroundIndexesReady : Bool

/-- Choices for one pending replacement job during Lines 3–5: per-prefix-level routing answers,
per-prefix-level construction budget steps, sampled center candidate and fallback birth-point choice
for Line 5 if a large residual level opens, and leaf tie-breakers. -/
structure PendingJobStepChoices (d : ℕ) (ι : Type*) where
  prefixRouteQueries : List (NodeMatchingQueryAnswers ι)
  prefixRouteMaxHints : List (Option ι)
  prefixBudgetSteps : List (PendingLevelBudgetChoices ι)
  openSampledCenter : SampledCenterResult d
  openFallbackBirthId : Option ι
  leafHint : Option (ι × ι)

/-- Choices for opening one synchronous level when rebuilding a leaf that grew to `6L + 1` in
Line 9. -/
structure LeafRebuildLevelChoices (d : ℕ) (ι : Type*) where
  sampledCenter : SampledCenterResult d
  fallbackBirthId : Option ι
  radiusMaxHint : Option ι
  pointInsertOrder : List (ι × NodeMatchingQueryAnswers ι)

/-- Complete bundle of random/subroutine oracle outcomes for one execution of Algorithm 4 on a
single external update. -/
structure Alg4StepChoices (d : ℕ) (ι : Type*) where
  servingRouteQueries : List (NodeMatchingQueryAnswers ι)
  servingRadiusMaxHints : List (Option ι)
  pendingJobChoices : List (PendingJobStepChoices d ι)
  leafRebuildChoices : List (LeafRebuildLevelChoices d ι)
  terminalLeafHint : Option (ι × ι)
  baselineSamples : List (List ι)
  matchingMaxHints : List (Option ShellConfig)
  distinctPairHint : Option (ι × ι)
  stepExtraRetired : List (RetiredRecord ι)
  stepAllocatedRecords : ℕ

/-- Build retirements produced when retiring a superseded `Alg4ServingNode` (and any owned job) in
Line 7 or Line 9. -/
noncomputable def retireServingNodeRecords {d : ℕ} {ι : Type*}
    (sn : Alg4ServingNode d ι) : List (RetiredRecord ι) :=
  let jobRecs : List (RetiredRecord ι) :=
    match sn.ownedJob with
    | none => []
    | some job =>
        (.node job.currentResidual []) ::
          job.completedPrefix.map (fun lv =>
            .node lv.birthSnapshot [.node lv.scan2Snapshot []])
  (.node sn.birthSnapshot []) :: jobRecs

open Classical in
/-- Auxiliary routing of a single point update through a list of `Alg4ServingNode`s in Line 1:
changes each affected serving pool once, updates affected radius dictionaries and local matchings,
records each serving node's `PoolUpdateEvent`, and returns the resulting terminal-leaf event. -/
noncomputable def alg4Line1Aux {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    Option (PoolUpdateEvent ι) →
    List (Alg4ServingNode d ι) →
    List (NodeMatchingQueryAnswers ι) →
    List (Option ι) →
    List (Alg4ServingNode d ι × PoolUpdateEvent ι) × PoolUpdateEvent ι
  | activeEv, [], _, _ =>
      ([], activeEv.getD .unaffected)
  | activeEv, sn :: rest, qList, mHints =>
      let ev := activeEv.getD .unaffected
      let qAns := qList.head?.getD (NodeMatchingQueryAnswers.empty ι)
      let mHint := mHints.head?.join
      let sn' : Alg4ServingNode d ι :=
        match ev with
        | .externalInsert p =>
            { sn with
              trueAge := sn.trueAge + 1
              age := sn.age + 1
              radiusDict := updateRadiusDictOnEvent pts sn.node.o sn.radiusDict ev mHint
              localMatchings := applyNodeMatchingInsert pts mode sn.node sn.localMatchings p qAns }
        | .externalDelete p =>
            { sn with
              trueAge := sn.trueAge + 1
              age := sn.age + 1
              radiusDict := updateRadiusDictOnEvent pts sn.node.o sn.radiusDict ev mHint
              localMatchings := applyNodeMatchingDelete pts mode sn.node sn.localMatchings p qAns }
        | .virtualValueDelete => sn
        | .unaffected => sn
      let nextActiveEv : Option (PoolUpdateEvent ι) :=
        match ev with
        | .externalInsert p =>
            if pts p ∈ coreBall sn.node.o sn.node.V then none else some (.externalInsert p)
        | .externalDelete p =>
            if pts p ∈ coreBall sn.node.o sn.node.V then none else some (.externalDelete p)
        | .virtualValueDelete => none
        | .unaffected => none
      let (rest', leafEv) := alg4Line1Aux pts mode nextActiveEv rest (qList.drop 1) (mHints.drop 1)
      ((sn', ev) :: rest', leafEv)

open Classical in
/-- **Line 1 of Algorithm 4**: Apply the point update to the serving pools, radius dictionaries, and
local matchings. Returns the updated serving nodes paired with their `PoolUpdateEvent`s and the
updated `terminalLeaf`. -/
noncomputable def alg4Line1ApplyToServingChain {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (nodes : List (Alg4ServingNode d ι)) (terminalLeaf : Finset ι)
    (upd : Alg4PointUpdate d ι)
    (qList : List (NodeMatchingQueryAnswers ι)) (mHints : List (Option ι)) :
    List (Alg4ServingNode d ι × PoolUpdateEvent ι) × Finset ι × Bool :=
  let rootEv : PoolUpdateEvent ι :=
    match upd with
    | .insert p _ => .externalInsert p
    | .delete p => .externalDelete p
  let (nodesWithEv, leafEv) := alg4Line1Aux pts mode (some rootEv) nodes qList mHints
  let nextLeaf : Finset ι :=
    match leafEv with
    | .externalInsert p => insert p terminalLeaf
    | .externalDelete p => terminalLeaf.erase p
    | .virtualValueDelete => terminalLeaf
    | .unaffected => terminalLeaf
  (nodesWithEv, nextLeaf, leafEv.isClockTick)

open Classical in
/-- Route an arriving point change `ev` through `completedPrefix` of an affected pending replacement
job (Line 3 of Algorithm 4), updating each reached level's radius dictionary (`heapIndexedIds`),
classified set (`classifiedIds`), and local matchings without mutating the shared root pool again. -/
noncomputable def alg4Line3RoutePrefixAux {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    Option (PoolUpdateEvent ι) →
    List (Alg4OpenedLevel d ι) →
    List (NodeMatchingQueryAnswers ι) →
    List (Option ι) →
    List (Alg4OpenedLevel d ι) × PoolUpdateEvent ι
  | activeEv, [], _, _ =>
      ([], activeEv.getD .unaffected)
  | activeEv, lv :: rest, qList, mHints =>
      let ev := activeEv.getD .unaffected
      let qAns := qList.head?.getD (NodeMatchingQueryAnswers.empty ι)
      let mHint := mHints.head?.join
      let lv' : Alg4OpenedLevel d ι :=
        match ev with
        | .externalInsert p =>
            let rDict' := updateRadiusDictOnEvent pts lv.ball.o lv.radiusDict ev mHint
            let cls' := insert p lv.classifiedIds
            let lm' := applyNodeMatchingInsert pts mode lv.ball lv.localMatchings p qAns
            { lv with
              trueInputAge := lv.trueInputAge + 1
              heapIndexedIds := rDict'.indexedIds
              classifiedIds := cls'
              radiusDict := rDict'
              localMatchings := lm' }
        | .externalDelete p =>
            let rDict' := updateRadiusDictOnEvent pts lv.ball.o lv.radiusDict ev mHint
            let cls' := lv.classifiedIds.erase p
            let lm' :=
              if p ∈ lv.classifiedIds then
                applyNodeMatchingDelete pts mode lv.ball lv.localMatchings p qAns
              else
                lv.localMatchings
            { lv with
              trueInputAge := lv.trueInputAge + 1
              heapIndexedIds := rDict'.indexedIds
              classifiedIds := cls'
              radiusDict := rDict'
              localMatchings := lm' }
        | .virtualValueDelete => lv
        | .unaffected => lv
      let nextEv : Option (PoolUpdateEvent ι) :=
        match ev with
        | .externalInsert p =>
            if pts p ∈ coreBall lv.ball.o lv.ball.V then none else some (.externalInsert p)
        | .externalDelete p =>
            if pts p ∈ coreBall lv.ball.o lv.ball.V then none else some (.externalDelete p)
        | .virtualValueDelete => none
        | .unaffected => none
      let (rest', resEv) :=
        alg4Line3RoutePrefixAux pts mode nextEv rest (qList.drop 1) (mHints.drop 1)
      (lv' :: rest', resEv)

open Classical in
/-- **Line 3 of Algorithm 4**: Route the root-pool point change `rootEv` through `job.completedPrefix`
and into `job.currentResidual` (updating `closedLeafAnswer` if `job.closedAsLeaf = true`). -/
noncomputable def alg4Line3RouteThroughPrefix {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (job : Alg4PendingJob d ι) (rootEv : PoolUpdateEvent ι)
    (S_root' : Finset ι) (jc : PendingJobStepChoices d ι) : Alg4PendingJob d ι :=
  let (pref', _) :=
    alg4Line3RoutePrefixAux pts mode (some rootEv) job.completedPrefix
      jc.prefixRouteQueries jc.prefixRouteMaxHints
  let res' := prefixResidual pts (pref'.map Alg4OpenedLevel.toOpenedJobLevel) S_root'
  let (leafAns', leafSq') :=
    if job.closedAsLeaf then
      computeExactLeafAnswer pts res' jc.leafHint
    else
      (none, 0)
  { job with
    completedPrefix := pref'
    currentResidual := res'
    closedLeafAnswer := leafAns'
    closedLeafDistSq := leafSq' }

open Classical in
/-- Apply Scan-2 classification steps on one opened pending level: each active identity in
`lv.scan2Snapshot` whose `classified` flag is unset (`∉ classifiedIds`) is added to `classifiedIds`
and inserted into `localMatchings`. -/
noncomputable def applyScan2Batch {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (ball : ChainNode d) (S_lv : Finset ι) (scan2Snap : Finset ι) :
    Finset ι → (ShellConfig → LocalMatchingState ι) →
    List (ι × NodeMatchingQueryAnswers ι) →
    Finset ι × (ShellConfig → LocalMatchingState ι)
  | cls, lm, [] => (cls, lm)
  | cls, lm, (q, qAns) :: rest =>
      if q ∈ scan2Snap ∧ q ∈ S_lv ∧ q ∉ cls then
        applyScan2Batch pts mode ball S_lv scan2Snap (insert q cls)
          (applyNodeMatchingInsert pts mode ball lm q qAns) rest
      else
        applyScan2Batch pts mode ball S_lv scan2Snap cls lm rest

open Classical in
/-- Advance elapsed root ticks and perform prescribed two-scan construction work across
`completedPrefix` (Line 4 helper). -/
noncomputable def stepPrefixConstruction {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    Finset ι → List (Alg4OpenedLevel d ι) → List (PendingLevelBudgetChoices ι) →
    List (Alg4OpenedLevel d ι)
  | _, [], _ => []
  | S_lv, lv :: rest, bSteps =>
      let bChoice :=
        bSteps.head?.getD
          { scan1Batch := ∅, scan2Steps := [], scanMaxHint := none, backgroundIndexesReady := false }
      let lv1 : Alg4OpenedLevel d ι :=
        if lv.backgroundReady then
          { lv with elapsedRootTicks := lv.elapsedRootTicks + 1 }
        else
          let rDict' :=
            scan1RadiusDictBatch pts lv.ball.o S_lv lv.radiusDict
              (bChoice.scan1Batch ∩ lv.birthSnapshot) bChoice.scanMaxHint
          let (cls', lm') :=
            applyScan2Batch pts mode lv.ball S_lv lv.scan2Snapshot
              lv.classifiedIds lv.localMatchings bChoice.scan2Steps
          let scansDone : Bool :=
            decide (S_lv ⊆ rDict'.indexedIds) && decide (S_lv ⊆ cls')
          { lv with
            elapsedRootTicks := lv.elapsedRootTicks + 1
            heapIndexedIds := rDict'.indexedIds
            classifiedIds := cls'
            radiusDict := rDict'
            localMatchings := lm'
            backgroundReady := scansDone && bChoice.backgroundIndexesReady }
      lv1 :: stepPrefixConstruction pts mode (lv.ball.residual pts S_lv) rest (bSteps.drop 1)

/-- **Line 4 of Algorithm 4**: Advance the affected job's root clock (`remainingTicks - 1`, and
`elapsedRootTicks + 1` on each opened prefix level) and perform its prescribed construction budget. -/
noncomputable def alg4Line4AdvanceClockAndBuild {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (job : Alg4PendingJob d ι) (S_root' : Finset ι)
    (bSteps : List (PendingLevelBudgetChoices ι)) : Alg4PendingJob d ι :=
  { job with
    remainingTicks := job.remainingTicks - 1
    completedPrefix := stepPrefixConstruction pts mode S_root' job.completedPrefix bSteps }

open Classical in
/-- Choose a valid birth point in `S_birth` (when `S_birth.Nonempty`), honoring `hint` if `∈ S_birth`. -/
noncomputable def chooseBirthPointIn {ι : Type*}
    (S_birth : Finset ι) (hNE : S_birth.Nonempty) (hint : Option ι) : ι :=
  match hint with
  | some b => if b ∈ S_birth then b else hNE.choose
  | none => hNE.choose

open Classical in
/-- **Line 5 of Algorithm 4**: Open `job.currentResidual` only when the late-opening gate
`CanOpenResidualLevel α job.remainingTicks job.currentResidual.card` (`r ≤ α m / C_*`) holds (when
not yet closed as a leaf and all earlier prefix levels are ready): closes as an exact leaf if
`m ≤ 2L + 1`, or opens one fixed-ball level via the two-stage center fallback if `m > 2L + 1`. -/
noncomputable def alg4Line5LateOpeningGate {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (job : Alg4PendingJob d ι) (jc : PendingJobStepChoices d ι) : Alg4PendingJob d ι :=
  if job.closedAsLeaf then
    job
  else if !(job.completedPrefix.all (fun lv => lv.backgroundReady)) then
    job
  else
    match residualScheduleStep α L job.remainingTicks job.currentResidual.card with
    | .wait => job
    | .closeAsLeaf =>
        let (leafAns, leafSq) := computeExactLeafAnswer pts job.currentResidual jc.leafHint
        { job with
          closedAsLeaf := true
          closedLeafAnswer := leafAns
          closedLeafDistSq := leafSq }
    | .openBallLevel =>
        if hNE : job.currentResidual.Nonempty then
          let bId := chooseBirthPointIn job.currentResidual hNE jc.openFallbackBirthId
          let ball := selectOpenedLevelBall α pts job.currentResidual bId jc.openSampledCenter
          let newLv : Alg4OpenedLevel d ι :=
            { birthSnapshot := job.currentResidual
              ball := ball
              indexMode := mode.backgroundIndexMode
              backgroundReady := false
              trueInputAge := 0
              elapsedRootTicks := 0
              scan2Snapshot := job.currentResidual
              heapIndexedIds := ∅
              classifiedIds := ∅
              radiusDict := RadiusDictState.empty ι
              localMatchings := fun _ => LocalMatchingState.empty ι }
          { job with
            completedPrefix := job.completedPrefix ++ [newLv]
            currentResidual := ball.residual pts job.currentResidual }
        else
          job

/-- **Lines 2–6 of Algorithm 4**: For each affected serving node's pending replacement job, route
the point change through its completed prefix (Line 3), advance its root clock and perform its
prescribed construction budget (Line 4), and open its residual level only when the late-opening gate
holds (Line 5). Unaffected serving nodes do not tick or step their pending jobs. -/
noncomputable def alg4Lines2To6StepPendingJobs {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ) :
    Finset ι →
    List (Alg4ServingNode d ι × PoolUpdateEvent ι) →
    List (PendingJobStepChoices d ι) →
    List (Alg4ServingNode d ι × Bool)
  | _, [], _ => []
  | S_cur', (sn, ev) :: rest, jChoices =>
      let jc :=
        jChoices.head?.getD
          { prefixRouteQueries := []
            prefixRouteMaxHints := []
            prefixBudgetSteps := []
            openSampledCenter := .infeasible
            openFallbackBirthId := none
            leafHint := none }
      let sn' : Alg4ServingNode d ι :=
        if ev.isClockTick then
          match sn.ownedJob with
          | none => sn
          | some job =>
              let job₁ := alg4Line3RouteThroughPrefix pts mode job ev S_cur' jc
              let job₂ := alg4Line4AdvanceClockAndBuild pts mode job₁ S_cur' jc.prefixBudgetSteps
              let job₃ := alg4Line5LateOpeningGate pts mode α L job₂ jc
              { sn with ownedJob := some job₃ }
        else
          sn
      (sn', ev.isClockTick) ::
        alg4Lines2To6StepPendingJobs pts mode α L (sn'.node.residual pts S_cur')
          rest (jChoices.drop 1)

/-- **Line 8 of Algorithm 4**: Convert an installed `Alg4OpenedLevel` into an active `Alg4ServingNode`,
preserving its birth snapshot (and birth size `M`), its true input-change age `trueInputAge`, and
its conservative serving age `elapsedRootTicks` (with `ownedJob = none`, marked for cache refresh in
Line 10). -/
def installOpenedLevelAsServingNode {d : ℕ} {ι : Type*}
    (lv : Alg4OpenedLevel d ι) : Alg4ServingNode d ι :=
  { birthSnapshot := lv.birthSnapshot
    node := lv.ball
    trueAge := lv.trueInputAge
    age := lv.elapsedRootTicks
    radiusDict := lv.radiusDict
    localMatchings := lv.localMatchings
    baselinePair := none
    baselineDistSq := 0
    maxMatchingPair := none
    maxMatchingDistSq := 0
    ownedJob := none }

open Classical in
/-- **Lines 7–8 of Algorithm 4**: Install completed jobs (`IsReadyToInstall`) from highest root to
lowest, canceling obsolete descendant serving nodes and their pending/completed jobs (retiring them
onto the retirement queue), and preserving each installed center's birth size and true age. -/
noncomputable def alg4Lines7To8InstallCompletedJobs {d : ℕ} {ι : Type*} :
    List (Alg4ServingNode d ι × Bool) →
    Finset ι → Option (ι × ι) → ℝ → Bool →
    List (Alg4ServingNode d ι × Bool) × Finset ι × Option (ι × ι) × ℝ × Bool × List (RetiredRecord ι)
  | [], leaf, leafAns, leafSq, leafChanged =>
      ([], leaf, leafAns, leafSq, leafChanged, [])
  | (sn, affected) :: rest, leaf, leafAns, leafSq, leafChanged =>
      match sn.ownedJob with
      | some job =>
          if job.IsReadyToInstall then
            let retiredInstalledScans :=
              job.completedPrefix.map (fun lv => RetiredRecord.node lv.scan2Snapshot [])
            let retiredSuffix :=
              (RetiredRecord.node leaf []) ::
                (retiredInstalledScans ++
                  (({ sn with ownedJob := none } :: rest.map Prod.fst).flatMap
                    retireServingNodeRecords))
            let installedNodes :=
              job.completedPrefix.map (fun lv => (installOpenedLevelAsServingNode lv, true))
            (installedNodes, job.currentResidual, job.closedLeafAnswer, job.closedLeafDistSq,
              true, retiredSuffix)
          else
            let (rest', leaf', leafAns', leafSq', leafCh', retired) :=
              alg4Lines7To8InstallCompletedJobs rest leaf leafAns leafSq leafChanged
            ((sn, affected) :: rest', leaf', leafAns', leafSq', leafCh', retired)
      | none =>
          let (rest', leaf', leafAns', leafSq', leafCh', retired) :=
            alg4Lines7To8InstallCompletedJobs rest leaf leafAns leafSq leafChanged
          ((sn, affected) :: rest', leaf', leafAns', leafSq', leafCh', retired)

open Classical in
/-- Build local matchings synchronously on a polynomial-size leaf snapshot `S_cur` by inserting
its active points in duplicate-free order (used when rebuilding a leaf of size `6L + 1` in Line 9). -/
noncomputable def buildSyncNodeMatchings {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (ball : ChainNode d) (S_cur : Finset ι)
    (insertSteps : List (ι × NodeMatchingQueryAnswers ι)) :
    ShellConfig → LocalMatchingState ι :=
  let stepFn (acc : Finset ι × (ShellConfig → LocalMatchingState ι))
      (pq : ι × NodeMatchingQueryAnswers ι) :=
    if pq.1 ∈ S_cur ∧ pq.1 ∉ acc.1 then
      (insert pq.1 acc.1, applyNodeMatchingInsert pts mode ball acc.2 pq.1 pq.2)
    else
      acc
  let (covered, lm₁) :=
    insertSteps.foldl stepFn (∅, fun _ => LocalMatchingState.empty ι)
  let remaining := (S_cur \ covered).toList
  remaining.foldl
    (fun lm p => applyNodeMatchingInsert pts mode ball lm p (NodeMatchingQueryAnswers.empty ι))
    lm₁

open Classical in
/-- Synchronously contract an oversized leaf (`> 6L`, e.g. `6L + 1`) down to `IsResidualLeafSize L`
(`≤ 2L + 1`) within the polynomial leaf budget (Line 9; Section C.2, p. 53). Because every step
passes `PassesBirthCoreCheck α` (`α > 0`), each opened ball removes at least one point, so `fuel = S.card`
steps always reach `≤ 2L + 1`. -/
noncomputable def rebuildOversizedLeafAux {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ) :
    ℕ → Finset ι → List (LeafRebuildLevelChoices d ι) →
    List (Alg4ServingNode d ι × Bool) × Finset ι
  | 0, S_cur, _ => ([], S_cur)
  | k + 1, S_cur, choices =>
      if IsResidualLeafSize L S_cur.card then
        ([], S_cur)
      else if hNE : S_cur.Nonempty then
        let ch :=
          choices.head?.getD
            { sampledCenter := .infeasible
              fallbackBirthId := none
              radiusMaxHint := none
              pointInsertOrder := [] }
        let bId := chooseBirthPointIn S_cur hNE ch.fallbackBirthId
        let ball := selectOpenedLevelBall α pts S_cur bId ch.sampledCenter
        let rDict := buildRadiusDictOn pts ball.o S_cur ch.radiusMaxHint
        let lm := buildSyncNodeMatchings pts mode ball S_cur ch.pointInsertOrder
        let sn : Alg4ServingNode d ι :=
          { birthSnapshot := S_cur
            node := ball
            trueAge := 0
            age := 0
            radiusDict := rDict
            localMatchings := lm
            baselinePair := none
            baselineDistSq := 0
            maxMatchingPair := none
            maxMatchingDistSq := 0
            ownedJob := none }
        let S_next := ball.residual pts S_cur
        let (tailNodes, finalLeaf) :=
          rebuildOversizedLeafAux pts mode α L k S_next (choices.drop 1)
        ((sn, true) :: tailNodes, finalLeaf)
      else
        ([], S_cur)

open Classical in
/-- Scan serving nodes from highest root to lowest to start due replacement jobs (`age ≥ ⌊α M / 64⌋`):
starts an `Alg4PendingJob` if current input size `m > 4L`, or replaces the suffix immediately by an
exact leaf if `m ≤ 4L` (Line 9 helper). -/
noncomputable def startDueServingJobsAux {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (α : ℝ) (L : ℕ) :
    Finset ι →
    List (Alg4ServingNode d ι × Bool) →
    Finset ι → Option (ι × ι) → ℝ → Bool →
    List (Alg4ServingNode d ι × Bool) × Finset ι × Option (ι × ι) × ℝ × Bool × List (RetiredRecord ι)
  | _, [], leaf, leafAns, leafSq, leafCh =>
      ([], leaf, leafAns, leafSq, leafCh, [])
  | S_cur, (sn, needRefresh) :: rest, leaf, leafAns, leafSq, leafCh =>
      if sn.ownedJob.isNone ∧ jobStartAge α sn.birthSnapshot.card ≤ sn.age then
        match scheduleJobStart α L S_cur.card with
        | .startPendingJob _ =>
            let sn' := { sn with ownedJob := some (Alg4PendingJob.init α S_cur) }
            let (rest', leaf', leafAns', leafSq', leafCh', retired) :=
              startDueServingJobsAux pts α L (sn'.node.residual pts S_cur)
                rest leaf leafAns leafSq leafCh
            ((sn', needRefresh) :: rest', leaf', leafAns', leafSq', leafCh', retired)
        | .replaceImmediatelyByExactLeaf =>
            let retired :=
              (RetiredRecord.node leaf []) ::
                ((sn :: rest.map Prod.fst).flatMap retireServingNodeRecords)
            ([], S_cur, none, 0, true, retired)
      else
        let (rest', leaf', leafAns', leafSq', leafCh', retired) :=
          startDueServingJobsAux pts α L (sn.node.residual pts S_cur)
            rest leaf leafAns leafSq leafCh
        ((sn, needRefresh) :: rest', leaf', leafAns', leafSq', leafCh', retired)

/-- **Line 9 of Algorithm 4**: Start due serving-node replacement jobs (`⌊α M / 64⌋`), and handle
polynomial-size leaves exactly (rebuilding immediately if the terminal leaf grew to `6L + 1`, and
maintaining the exact diameter pair on the resulting leaf). -/
noncomputable def alg4Line9StartDueJobsAndHandleLeaves {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (P' : Finset ι)
    (nodes : List (Alg4ServingNode d ι × Bool))
    (leaf : Finset ι) (leafAns : Option (ι × ι)) (leafSq : ℝ) (leafChanged : Bool)
    (rebuildChoices : List (LeafRebuildLevelChoices d ι))
    (leafHint : Option (ι × ι)) :
    List (Alg4ServingNode d ι × Bool) × Finset ι × Option (ι × ι) × ℝ × List (RetiredRecord ι) :=
  let (nodes₁, leaf₁, leafAns₁, leafSq₁, leafCh₁, retired₁) :=
    startDueServingJobsAux pts α L P' nodes leaf leafAns leafSq leafChanged
  if 6 * L < leaf₁.card then
    let (rebuiltNodes, finalLeaf) :=
      rebuildOversizedLeafAux pts mode α L leaf₁.card leaf₁ rebuildChoices
    let (finalAns, finalSq) := computeExactLeafAnswer pts finalLeaf leafHint
    (nodes₁ ++ rebuiltNodes, finalLeaf, finalAns, finalSq,
      retired₁ ++ [RetiredRecord.node leaf₁ []])
  else if leafCh₁ then
    let (finalAns, finalSq) := computeExactLeafAnswer pts leaf₁ leafHint
    (nodes₁, leaf₁, finalAns, finalSq, retired₁)
  else
    (nodes₁, leaf₁, leafAns₁, leafSq₁, retired₁)

/-- **Line 10 of Algorithm 4**: Refresh baseline pairs and maximum cached local matching witnesses
for every affected or newly installed/rebuilt serving node. -/
noncomputable def alg4Line10RefreshAffectedCaches {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    Finset ι →
    List (Alg4ServingNode d ι × Bool) →
    List (List ι) →
    List (Option ShellConfig) →
    List (Alg4ServingNode d ι)
  | _, [], _, _ => []
  | S_cur, (sn, needRefresh) :: rest, sampLists, cfgHints =>
      let samps := sampLists.head?.getD []
      let cHint := cfgHints.head?.join
      let sn' : Alg4ServingNode d ι :=
        if needRefresh then
          let (bPair, bSq) := refreshBaselineFromSamples pts sn.node.o S_cur sn.radiusDict samps
          let (mPair, mSq) :=
            refreshMaxMatchingWitness pts mode sn.node sn.localMatchings cHint
          { sn with
            baselinePair := bPair
            baselineDistSq := bSq
            maxMatchingPair := mPair
            maxMatchingDistSq := mSq }
        else
          sn
      sn' ::
        alg4Line10RefreshAffectedCaches pts mode (sn'.node.residual pts S_cur)
          rest (sampLists.drop 1) (cfgHints.drop 1)

/-- **Line 11 of Algorithm 4**: Enqueue retired roots from the update onto `retirementQueue` and
perform the scheduled incremental retirement work (`reclaimMult * max 1 stepAllocatedRecords`
record pops). -/
def alg4Line11PerformRetirementWork {ι : Type*}
    (reclaimMult stepAllocatedRecords : ℕ)
    (prevQueue newRetired : List (RetiredRecord ι)) :
    List (RetiredRecord ι) × ℕ :=
  let budget := reclaimMult * max 1 stepAllocatedRecords
  performRetirementSteps budget (prevQueue ++ newRetired)

open Classical in
/-- Update the maintained distinct-identity fallback pair on `P'` (Section 5.1, p. 17): `none` when
`|P'| ≤ 1`, and two distinct active identities `(u, v)` in `P'` when `|P'| ≥ 2` (retaining
`prevFallback` in `O(1)` whenever both endpoints remain active in `P'`). -/
noncomputable def updateDistinctFallbackPair {ι : Type*}
    (P' : Finset ι) (prevFallback hint : Option (ι × ι)) : Option (ι × ι) :=
  if P'.card ≤ 1 then
    none
  else
    let valid (uv : ι × ι) : Prop := uv.1 ∈ P' ∧ uv.2 ∈ P' ∧ uv.1 ≠ uv.2
    match prevFallback with
    | some uv =>
        if valid uv then some uv
        else
          match hint with
          | some uv' =>
              if valid uv' then some uv'
              else if hEx : ∃ w : ι × ι, valid w then some (Classical.choose hEx)
              else none
          | none =>
              if hEx : ∃ w : ι × ι, valid w then some (Classical.choose hEx)
              else none
    | none =>
        match hint with
        | some uv' =>
            if valid uv' then some uv'
            else if hEx : ∃ w : ι × ι, valid w then some (Classical.choose hEx)
            else none
        | none =>
            if hEx : ∃ w : ι × ι, valid w then some (Classical.choose hEx)
            else none

/-- Collect all non-empty cached candidate pairs `(u, v, distSq)` across `servingNodes` (baseline
pairs and maximum local matching witnesses) and `terminalLeafAnswer`. -/
def collectCachedCandidatePairs {d : ℕ} {ι : Type*}
    (servingNodes : List (Alg4ServingNode d ι))
    (terminalLeafAnswer : Option (ι × ι)) (terminalLeafDistSq : ℝ) :
    List ((ι × ι) × ℝ) :=
  let fromNode (sn : Alg4ServingNode d ι) : List ((ι × ι) × ℝ) :=
    (match sn.baselinePair with
      | none => []
      | some uv => [(uv, sn.baselineDistSq)]) ++
    (match sn.maxMatchingPair with
      | none => []
      | some uv => [(uv, sn.maxMatchingDistSq)])
  let leafList : List ((ι × ι) × ℝ) :=
    match terminalLeafAnswer with
    | none => []
    | some uv => [(uv, terminalLeafDistSq)]
  (servingNodes.flatMap fromNode) ++ leafList

open Classical in
/-- **Line 12 of Algorithm 4**: Return the largest current cached pair (including the exact leaf's
pair), using the zero-diameter convention `(none, 0)` when `|P'| ≤ 1` and the distinct-identity
convention when `|P'| ≥ 2` and the maximum cached squared distance is zero. -/
noncomputable def alg4Line12SelectCachedAnswer {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (P' : Finset ι)
    (servingNodes : List (Alg4ServingNode d ι))
    (terminalLeafAnswer : Option (ι × ι)) (terminalLeafDistSq : ℝ)
    (distinctFallback : Option (ι × ι)) :
    Option (ι × ι) × ℝ :=
  if P'.card ≤ 1 then
    (none, 0)
  else
    let cands := collectCachedCandidatePairs servingNodes terminalLeafAnswer terminalLeafDistSq
    let bestOpt : Option ((ι × ι) × ℝ) :=
      match cands with
      | [] => none
      | c :: cs => some (pickMaxByReal Prod.snd c cs)
    match bestOpt with
    | some (uv, bestSq) =>
        if 0 < bestSq then
          (some uv, bestSq)
        else
          match distinctFallback with
          | some (d₁, d₂) => (some (d₁, d₂), euclideanDistSq (pts d₁) (pts d₂))
          | none => (some uv, bestSq)
    | none =>
        match distinctFallback with
        | some (d₁, d₂) => (some (d₁, d₂), euclideanDistSq (pts d₁) (pts d₂))
        | none => (none, 0)

/-- **Algorithm 4 (Master Dynamic Diameter Update, lines 1–12)**: Executes one external point
insertion or deletion `upd` on `st : Alg4State d ι` under `mode : Alg4Mode`, schedule parameters
`(α, L)`, reclamation multiplier `reclaimMult`, and step oracle `choices`, returning the updated
state `nextState` together with the reported cached diameter pair and squared distance. -/
noncomputable def alg4Step {d : ℕ} {ι : Type*}
    (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ)
    (st : Alg4State d ι) (upd : Alg4PointUpdate d ι)
    (choices : Alg4StepChoices d ι) :
    Alg4State d ι × (Option (ι × ι) × ℝ) :=
  let P' := applyAlg4PointSetUpdate st.activeSet upd
  let pts' := updateAlg4Coords st.coords upd
  -- Line 1: Apply the update to the serving pools, radius dictionaries, and local matchings.
  let (nodesLine1, leafLine1, leafTicked) :=
    alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints
  -- Lines 2–6: Route through affected pending jobs, advance clocks/budgets, check late-opening gate.
  let nodesLines2To6 :=
    alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
  -- Lines 7–8: Install completed jobs from highest root to lowest; preserve birth size & true age.
  let (nodesLines7To8, leafLines7To8, leafAns7To8, leafSq7To8, leafChanged7To8, retiredInstall) :=
    alg4Lines7To8InstallCompletedJobs nodesLines2To6
      leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafTicked
  -- Line 9: Start due serving-node replacement jobs; handle polynomial-size leaves exactly.
  let (nodesLine9, finalLeaf, finalLeafAns, finalLeafSq, retiredDue) :=
    alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
      nodesLines7To8 leafLines7To8 leafAns7To8 leafSq7To8 leafChanged7To8
      choices.leafRebuildChoices choices.terminalLeafHint
  -- Line 10: Refresh affected baseline pairs and maximum cached local matching witnesses.
  let finalServingNodes :=
    alg4Line10RefreshAffectedCaches pts' mode P' nodesLine9
      choices.baselineSamples choices.matchingMaxHints
  -- Line 11: Perform the scheduled retirement work.
  let allNewRetired := retiredInstall ++ retiredDue ++ choices.stepExtraRetired
  let (nextQueue, _) :=
    alg4Line11PerformRetirementWork reclaimMult choices.stepAllocatedRecords
      st.retirementQueue allNewRetired
  -- Line 12: Return the largest current cached pair (with distinct-identity fallback at length 0).
  let nextFallback :=
    updateDistinctFallbackPair P' st.distinctFallbackPair choices.distinctPairHint
  let ans :=
    alg4Line12SelectCachedAnswer pts' P' finalServingNodes finalLeafAns finalLeafSq nextFallback
  let nextState : Alg4State d ι :=
    { activeSet := P'
      coords := pts'
      servingNodes := finalServingNodes
      terminalLeaf := finalLeaf
      terminalLeafAnswer := finalLeafAns
      terminalLeafDistSq := finalLeafSq
      distinctFallbackPair := nextFallback
      retirementQueue := nextQueue
      cachedAnswer := ans }
  (nextState, ans)

/-! ### 5. Full state invariants, good-event accuracy, and `DynamicDiameterStructure` bridge -/

/-- Complete structural and schedule invariant of `st : Alg4State d ι` under capacity `n`,
`mode : Alg4Mode`, schedule parameters `(α, L)`, and retirement outdegree bound `D_out` (holding on
every execution outcome, including Monte Carlo fallback outcomes). -/
def Alg4State.WellFormed {d : ℕ} {ι : Type*}
    (st : Alg4State d ι) (n : ℕ) (mode : Alg4Mode) (α : ℝ) (L D_out : ℕ) : Prop :=
  st.activeSet.card ≤ n ∧
  st.toScheduledServingChain.WellFormed α L st.coords st.activeSet ∧
  st.terminalLeaf.card ≤ 6 * L ∧
  st.terminalLeafDistSq = (baselinePairLength st.coords st.terminalLeafAnswer) ^ 2 ∧
  (∀ idx : Fin st.servingNodes.length,
    (st.servingNodes[idx]).WellFormed mode α L st.coords (st.servingInputAt idx.val)) ∧
  (if st.activeSet.card ≤ 1 then
    st.distinctFallbackPair = none
  else
    ∃ d₁ d₂ : ι,
      st.distinctFallbackPair = some (d₁, d₂) ∧
      d₁ ∈ st.activeSet ∧ d₂ ∈ st.activeSet ∧ d₁ ≠ d₂) ∧
  (∀ r ∈ st.retirementQueue, r.HasBoundedOutdegree D_out) ∧
  st.cachedAnswer =
    alg4Line12SelectCachedAnswer st.coords st.activeSet st.servingNodes
      st.terminalLeafAnswer st.terminalLeafDistSq st.distinctFallbackPair

/-- Conditional accuracy invariant on the good Monte Carlo event for `st : Alg4State d ι`: every
active serving node's baseline pair satisfies Equation (2) (`SatisfiesNodeBaselineCond`) and, in
`subSqrt2` mode, every retained configuration matching satisfies the full boxed matching invariant
(`GoodNodeMatchingsOn`). -/
def Alg4State.SatisfiesGoodEvent {d : ℕ} {ι : Type*}
    (st : Alg4State d ι) (mode : Alg4Mode) : Prop :=
  ∀ idx : Fin st.servingNodes.length,
    let sn := st.servingNodes[idx]
    let S_cur := st.servingInputAt idx.val
    sn.node.SatisfiesBaselineCond st.coords S_cur sn.baselinePair ∧
    GoodNodeMatchingsOn st.coords mode sn.node S_cur sn.localMatchings

/-- Convert Algorithm 4's handle-indexed cached answer `(Option (ℕ × ℕ) × ℝ)` into a
`StoredDiameterAnswer` from `UL.Def.def_dynamic_points_model`. -/
def toStoredDiameterAnswer (ans : Option (ℕ × ℕ) × ℝ) : StoredDiameterAnswer :=
  { diameterHandles := ans.1
    cachedDistSq := ans.2 }

/-- Relational specification that a `DynamicDiameterStructure d State` implements Algorithm 4 (over
internal handles `ι = ℕ`) with mode `mode`, schedule/budget parameters `bp`, and state projection
`proj : State → Alg4State d ℕ`:
1. `initState` projects to `Alg4State.empty d ℕ`;
2. `cachedAnswer` reads `toStoredDiameterAnswer st.cachedAnswer` directly;
3. Every halting `stepWithBits` transition on a valid `InternalUpdate d` allocates a fresh/released
   handle `h ∉ (proj st).liveRetainedIds` on insertion (`none` on deletion) and transitions
   `proj st` to `(alg4Step mode bp.sched.α bp.sched.L bp.reclaimMult (proj st) upd choices).1` for
   some step oracle `choices`. -/
def IsAlg4DynamicRealization {d : ℕ} {State : Type}
    (mode : Alg4Mode) (bp : Alg4BudgetParams)
    (proj : State → Alg4State d ℕ)
    (alg : DynamicDiameterStructure d State) : Prop :=
  bp.Valid ∧
  proj alg.initState = Alg4State.empty d ℕ ∧
  (∀ st : State, alg.cachedAnswer st = toStoredDiameterAnswer (proj st).cachedAnswer) ∧
  ∀ (activeH : Finset ℕ) (hCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (st : State) (uop : InternalUpdate d) (bs : List Bool) (out : DynamicStepOutcome State),
    activeH = (proj st).activeSet →
    (∀ h ∈ activeH, hCoords h = (proj st).coords h) →
    alg.stepWithBits activeH hCoords st uop bs = some out →
      match uop with
      | .insert pt =>
          activeH.card + 1 ≤ bp.sched.n →
          ∃ (h : ℕ) (choices : Alg4StepChoices d ℕ),
            out.returnedHandle = some h ∧
            h ∉ (proj st).liveRetainedIds ∧
            let stepRes :=
              alg4Step mode bp.sched.α bp.sched.L bp.reclaimMult
                (proj st) (.insert h pt) choices
            proj out.nextState = stepRes.1 ∧
            out.storedAnswer = toStoredDiameterAnswer stepRes.2
      | .delete h =>
          h ∈ activeH →
          ∃ choices : Alg4StepChoices d ℕ,
            out.returnedHandle = none ∧
            let stepRes :=
              alg4Step mode bp.sched.α bp.sched.L bp.reclaimMult
                (proj st) (.delete h) choices
            proj out.nextState = stepRes.1 ∧
            out.storedAnswer = toStoredDiameterAnswer stepRes.2

end UL
