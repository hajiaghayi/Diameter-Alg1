import Mathlib
import UL.Def.def_6_search_interface
set_option autoImplicit false

/-! Definition (Sec. 6.1: Explicit filter probabilities) (paper p.22). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- The standard multivariate Gaussian probability measure `𝒩(0, I_d)` on `ℝ^d`
(`EuclideanSpace ℝ (Fin d)`), defined as the pushforward of the product of `d` independent
standard normal measures `ProbabilityTheory.gaussianReal 0 1` on `Fin d → ℝ` along the continuous
linear equivalence `(EuclideanSpace.equiv (Fin d) ℝ).symm`. -/
noncomputable def stdGaussianMeasure (d : ℕ) :
    MeasureTheory.Measure (EuclideanSpace ℝ (Fin d)) :=
  MeasureTheory.Measure.map (EuclideanSpace.equiv (Fin d) ℝ).symm
    (MeasureTheory.Measure.pi fun _ : Fin d => ProbabilityTheory.gaussianReal 0 1)

/-- Standing parameter conditions for explicit Gaussian filter probabilities in `ℝ^d`:
`d ≥ 1`, `0 < h < 1`, `h ≤ x ≤ 1`, and `t ≥ 1`. -/
def ValidGaussianFilterParams (d : ℕ) (h x t : ℝ) : Prop :=
  1 ≤ d ∧ 0 < h ∧ h < 1 ∧ h ≤ x ∧ x ≤ 1 ∧ 1 ≤ t

/-- The Gaussian data test `⟪G, p⟫ ≥ t` for `G, p ∈ ℝ^d` and threshold `t`. -/
def gaussianDataTest {d : ℕ} (t : ℝ) (G p : EuclideanSpace ℝ (Fin d)) : Prop :=
  t ≤ inner ℝ G p

/-- The Gaussian query test `⟪G, z⟫ ≥ x t` for `G, z ∈ ℝ^d` and parameters `x, t`. -/
def gaussianQueryTest {d : ℕ} (x t : ℝ) (G z : EuclideanSpace ℝ (Fin d)) : Prop :=
  x * t ≤ inner ℝ G z

/-- Marginal probability `p_u = Pr_{G ~ 𝒩(0, I_d)}[⟪G, p⟫ ≥ t]` of the data test. -/
noncomputable def gaussianDataProb {d : ℕ} (t : ℝ) (p : EuclideanSpace ℝ (Fin d)) : ℝ :=
  (stdGaussianMeasure d).real {G | gaussianDataTest t G p}

/-- Marginal probability `p_q = Pr_{G ~ 𝒩(0, I_d)}[⟪G, z⟫ ≥ x t]` of the query test. -/
noncomputable def gaussianQueryProb {d : ℕ} (x t : ℝ) (z : EuclideanSpace ℝ (Fin d)) : ℝ :=
  (stdGaussianMeasure d).real {G | gaussianQueryTest x t G z}

/-- Joint probability `Pr_{G ~ 𝒩(0, I_d)}[⟪G, p⟫ ≥ t and ⟪G, z⟫ ≥ x t]` of the data and query
tests. -/
noncomputable def gaussianJointProb {d : ℕ} (x t : ℝ) (p z : EuclideanSpace ℝ (Fin d)) : ℝ :=
  (stdGaussianMeasure d).real {G | gaussianDataTest t G p ∧ gaussianQueryTest x t G z}

/-- `p_u` is the marginal probability of the data test `⟪G, p⟫ ≥ t` across all unit vectors
`p ∈ ℝ^d`. -/
def IsGaussianDataMarginal (d : ℕ) (t p_u : ℝ) : Prop :=
  ∀ p : EuclideanSpace ℝ (Fin d), IsUnitVec p → gaussianDataProb t p = p_u

/-- `p_q` is the marginal probability of the query test `⟪G, z⟫ ≥ x t` across all unit vectors
`z ∈ ℝ^d`. -/
def IsGaussianQueryMarginal (d : ℕ) (x t p_q : ℝ) : Prop :=
  ∀ z : EuclideanSpace ℝ (Fin d), IsUnitVec z → gaussianQueryProb x t z = p_q

/-- `p₁` is a uniform lower bound on the joint probability `Pr[⟪G, p⟫ ≥ t and ⟪G, z⟫ ≥ x t]`
over all unit vectors `p, z ∈ ℝ^d` satisfying `⟪p, z⟫ ≥ h`. -/
def IsGaussianJointLowerBound (d : ℕ) (h x t p₁ : ℝ) : Prop :=
  ∀ p z : EuclideanSpace ℝ (Fin d),
    IsUnitVec p → IsUnitVec z → h ≤ inner ℝ p z → p₁ ≤ gaussianJointProb x t p z

/-- `p₂` is a uniform upper bound on the joint probability `Pr[⟪G, p⟫ ≥ t and ⟪G, z⟫ ≥ x t]`
over all unit vectors `p, z ∈ ℝ^d` satisfying `⟪p, z⟫ ≤ 0`. -/
def IsGaussianJointUpperBound (d : ℕ) (x t p₂ : ℝ) : Prop :=
  ∀ p z : EuclideanSpace ℝ (Fin d),
    IsUnitVec p → IsUnitVec z → inner ℝ p z ≤ 0 → gaussianJointProb x t p z ≤ p₂

/-- Bundled specification of `(p_u, p_q, p₁, p₂)` for explicit Gaussian filter lists in `ℝ^d`
under the standing assumptions (`d ≥ 1`, `0 < h < 1`, `h ≤ x ≤ 1`, `t ≥ 1`). -/
def IsGaussianFilterProbs (d : ℕ) (h x t p_u p_q p₁ p₂ : ℝ) : Prop :=
  ValidGaussianFilterParams d h x t ∧
  IsGaussianDataMarginal d t p_u ∧
  IsGaussianQueryMarginal d x t p_q ∧
  IsGaussianJointLowerBound d h x t p₁ ∧
  IsGaussianJointUpperBound d x t p₂

end UL
