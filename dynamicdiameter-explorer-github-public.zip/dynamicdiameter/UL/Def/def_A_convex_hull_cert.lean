import Mathlib
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_node_chain_blocks
set_option autoImplicit false

/-! Definition (Appendix A: Convex-hull certificate) (paper p.44). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- Predicate that a tuple/family of weights `w : κ → ℝ` is a convex-hull certificate for
`z ∈ ℝ^D` on a finite indexed family (block) of points `pts : κ → ℝ^D`: `w j ≥ 0` for all `j`,
`∑ j, w j = 1`, and `∑ j, w j • pts j = z`. -/
def IsConvexHullCert {D : ℕ} {κ : Type*} [Fintype κ]
    (pts : κ → EuclideanSpace ℝ (Fin D))
    (z : EuclideanSpace ℝ (Fin D))
    (w : κ → ℝ) : Prop :=
  (∀ j : κ, 0 ≤ w j) ∧
  (∑ j : κ, w j = 1) ∧
  (∑ j : κ, w j • pts j = z)

/-- Bundled convex-hull certificate for `z ∈ ℝ^D` on a finite indexed family (block) of points
`pts : κ → ℝ^D`: nonnegative weights `w : κ → ℝ` summing to one whose weighted sum is `z`. -/
structure ConvexHullCert {D : ℕ} {κ : Type*} [Fintype κ]
    (pts : κ → EuclideanSpace ℝ (Fin D))
    (z : EuclideanSpace ℝ (Fin D)) where
  w : κ → ℝ
  w_nonneg : ∀ j : κ, 0 ≤ w j
  sum_w : ∑ j : κ, w j = 1
  sum_pts : ∑ j : κ, w j • pts j = z

/-- Predicate that `z ∈ ℝ^D` admits a convex-hull certificate on the finite indexed family (block)
of points `pts : κ → ℝ^D`. -/
def HasConvexHullCert {D : ℕ} {κ : Type*} [Fintype κ]
    (pts : κ → EuclideanSpace ℝ (Fin D))
    (z : EuclideanSpace ℝ (Fin D)) : Prop :=
  ∃ w : κ → ℝ, IsConvexHullCert pts z w

/-- Predicate that `coeff : ι → ℝ` is a convex-hull certificate for `z ∈ ℝ^D` on a finite subset
(block) of identities `B : Finset ι` with point coordinates `pts : ι → ℝ^D`: `coeff i ≥ 0` on `B`,
`∑_{i ∈ B} coeff i = 1`, and `∑_{i ∈ B} coeff i • pts i = z`. -/
def IsFinsetConvexHullCert {D : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin D))
    (B : Finset ι)
    (z : EuclideanSpace ℝ (Fin D))
    (coeff : ι → ℝ) : Prop :=
  (∀ i ∈ B, 0 ≤ coeff i) ∧
  (∑ i ∈ B, coeff i = 1) ∧
  (∑ i ∈ B, coeff i • pts i = z)

/-- Bundled convex-hull certificate for `z ∈ ℝ^D` on a finite subset (block) of identities
`B : Finset ι` with point coordinates `pts : ι → ℝ^D`. -/
structure FinsetConvexHullCert {D : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin D))
    (B : Finset ι)
    (z : EuclideanSpace ℝ (Fin D)) where
  coeff : ι → ℝ
  coeff_nonneg : ∀ i ∈ B, 0 ≤ coeff i
  sum_coeff : ∑ i ∈ B, coeff i = 1
  sum_pts : ∑ i ∈ B, coeff i • pts i = z

/-- Predicate that `z ∈ ℝ^D` admits a convex-hull certificate on the finite subset (block)
`B : Finset ι` with point coordinates `pts : ι → ℝ^D`. -/
def HasFinsetConvexHullCert {D : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin D))
    (B : Finset ι)
    (z : EuclideanSpace ℝ (Fin D)) : Prop :=
  ∃ coeff : ι → ℝ, IsFinsetConvexHullCert pts B z coeff

/-- Predicate that an indexed block of birth identities `block : κ → ι` with weights `w : κ → ℝ`
is a lifted convex-hull block certificate for `z = (o, s) ∈ ℝ^{d+1}` over birth set
`P₀ : Finset ι` (with point coordinates `pts : ι → ℝ^d`): every identity in `block` belongs to
`P₀`, and `w` is a convex-hull certificate for `z` on the paraboloid-lifted block
`j ↦ paraboloidLift (pts (block j))` (whose associated variance is `liftedPointVariance z`; for
`Finset`-indexed blocks `B : Finset ι`, see `IsBlockCertificate` and `BlockCertificate`). -/
def IsIndexedBlockCertificate {d : ℕ} {ι κ : Type*} [Fintype κ]
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ι)
    (z : EuclideanSpace ℝ (Fin (d + 1)))
    (block : κ → ι) (w : κ → ℝ) : Prop :=
  (∀ j : κ, block j ∈ P₀) ∧
  IsConvexHullCert (fun j => paraboloidLift (pts (block j))) z w

/-- Bundled lifted convex-hull block certificate for `z = (o, s) ∈ ℝ^{d+1}` over birth set
`P₀ : Finset ι` on a `κ`-indexed block of birth identities `block : κ → ι` (reusing
`paraboloidLift` from `UL.Def.def_paraboloid_lift_variance`; cf. `BlockCertificate` in
`UL.Def.def_node_chain_blocks` for `Finset`-indexed blocks). -/
structure IndexedBlockCertificate {d : ℕ} {ι : Type*} (κ : Type*) [Fintype κ]
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ι)
    (z : EuclideanSpace ℝ (Fin (d + 1))) where
  block : κ → ι
  w : κ → ℝ
  mem_birth : ∀ j : κ, block j ∈ P₀
  w_nonneg : ∀ j : κ, 0 ≤ w j
  sum_w : ∑ j : κ, w j = 1
  sum_lift : ∑ j : κ, w j • paraboloidLift (pts (block j)) = z

/-- An indexed block of birth identities `block : κ → ι` is intact in current input set
`S : Finset ι` when none of its birth identities has been deleted from `S` (`∀ j, block j ∈ S`;
cf. `IsIntactBlock` in `UL.Def.def_node_chain_blocks` for `Finset`-indexed blocks). -/
def IsIntactIndexedBlock {ι κ : Type*} (block : κ → ι) (S : Finset ι) : Prop :=
  ∀ j : κ, block j ∈ S

/-- An `IndexedBlockCertificate` `cert` is intact in current input set `S` when none of its birth
identities has been deleted from `S`. -/
def IndexedBlockCertificate.IsIntact {d : ℕ} {ι κ : Type*} [Fintype κ]
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {z : EuclideanSpace ℝ (Fin (d + 1))}
    (cert : IndexedBlockCertificate κ pts P₀ z) (S : Finset ι) : Prop :=
  IsIntactIndexedBlock cert.block S

end UL
