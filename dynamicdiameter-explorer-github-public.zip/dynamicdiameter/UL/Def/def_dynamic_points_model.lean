import Mathlib
import UL.Def.def_diameter_pair
set_option autoImplicit false

/-! Definition (Sec. 3: Dynamic indexed point set and updates) (paper p.13, Sec. 1.1 p.3).
Models:
1. Active indexed point set `P` in `ℝ^d` (`EuclideanSpace ℝ (Fin d)`) with capacity `|P| ≤ n`,
   fixed coordinates per active identity until deletion, multiplicity of coordinates across
   distinct identities, fresh insertion lifetimes upon reinsertion, and reusable internal handles;
2. External insertions and deletions (supplying no future deletion time, with external name reading
   charged to that name's length);
3. Stored diameter answer maintaining two distinct active handles when `|P| ≥ 2` (including when
   all coordinates coincide and `diam(P) = 0`) together with their exact squared Euclidean distance
   cached during updates, constant-time retrieval of the identities and stored-value reference, and
   output-proportional coordinate or squared-distance writing. -/

namespace UL

/-- Exact squared Euclidean distance `‖x - y‖^2` in `ℝ^d`. -/
noncomputable def euclideanDistSq {d : ℕ} (x y : EuclideanSpace ℝ (Fin d)) : ℝ :=
  ‖x - y‖ ^ 2

/-- Active indexed point set `P` in `ℝ^d`, tracking active external identities, their fixed
coordinates until deletion, the bijection with currently active reusable internal handles returned
by the algorithm, and monotonically increasing insertion lifetimes. -/
structure DynamicPointSet (d : ℕ) : Type where
  activeIds : Finset ℕ
  coords : ℕ → EuclideanSpace ℝ (Fin d)
  activeHandles : Finset ℕ
  handleOfId : ℕ → ℕ
  idOfHandle : ℕ → ℕ
  nextLifetime : ℕ
  lifetimeOfId : ℕ → ℕ

/-- Initial empty indexed point set `P = ∅` from which executions start unless stated otherwise. -/
noncomputable def DynamicPointSet.empty (d : ℕ) : DynamicPointSet d :=
  { activeIds := ∅
    coords := fun _ => 0
    activeHandles := ∅
    handleOfId := fun id => id
    idOfHandle := fun h => h
    nextLifetime := 0
    lifetimeOfId := fun _ => 0 }

/-- Number of currently active point identities `|P|`. -/
def DynamicPointSet.card {d : ℕ} (P : DynamicPointSet d) : ℕ :=
  P.activeIds.card

/-- Euclidean diameter `diam(P) = max_{x, y ∈ P} ‖coords x - coords y‖`, equal to `0` when
`|P| ≤ 1`. -/
noncomputable def DynamicPointSet.diam {d : ℕ} (P : DynamicPointSet d) : ℝ :=
  indexedEuclideanDiam P.activeIds P.coords

/-- Coordinates indexed by active internal handle (`0` outside `activeHandles`). -/
noncomputable def DynamicPointSet.handleCoords {d : ℕ} (P : DynamicPointSet d) :
    ℕ → EuclideanSpace ℝ (Fin d) :=
  fun h => if h ∈ P.activeHandles then P.coords (P.idOfHandle h) else 0

/-- Structural invariant of `DynamicPointSet d` under capacity `n`: `|P| ≤ n`, a bijection between
`activeIds` and `activeHandles`, and distinct insertion lifetimes bounded by `nextLifetime`. -/
def DynamicPointSet.WellFormed {d : ℕ} (n : ℕ) (P : DynamicPointSet d) : Prop :=
  P.activeIds.card ≤ n ∧
  (∀ id ∈ P.activeIds, P.handleOfId id ∈ P.activeHandles ∧ P.idOfHandle (P.handleOfId id) = id) ∧
  (∀ h ∈ P.activeHandles, P.idOfHandle h ∈ P.activeIds ∧ P.handleOfId (P.idOfHandle h) = h) ∧
  (∀ id ∈ P.activeIds, P.lifetimeOfId id < P.nextLifetime) ∧
  (∀ id₁ ∈ P.activeIds, ∀ id₂ ∈ P.activeIds, P.lifetimeOfId id₁ = P.lifetimeOfId id₂ → id₁ = id₂)

/-- External update operation: an insertion supplies a new identity, an external name (whose
reading is charged to its length), and `d` coordinates (no future deletion time is supplied); a
deletion specifies a currently active identity. -/
inductive DynamicUpdate (d : ℕ) : Type
  | insert (id : ℕ) (externalName : List Bool) (pt : EuclideanSpace ℝ (Fin d))
  | delete (id : ℕ)

/-- Cost charged to reading an external name supplied by the user on insertion. -/
def externalNameReadCost {d : ℕ} : DynamicUpdate d → ℕ
  | .insert _ extName _ => extName.length
  | .delete _ => 0

/-- Legality of an external update on `P` under capacity `n` and admissible coordinate set
`admissiblePts ⊆ ℝ^d` (`Set.univ` for unrestricted real inputs, or `B`-bit rationals for rational
inputs): insertions supply a fresh identity without exceeding `|P| ≤ n`, and deletions specify a
currently active identity. -/
def IsLegalUpdate {d : ℕ} (n : ℕ) (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (P : DynamicPointSet d) : DynamicUpdate d → Prop
  | .insert id _ pt => id ∉ P.activeIds ∧ P.activeIds.card + 1 ≤ n ∧ pt ∈ admissiblePts
  | .delete id => id ∈ P.activeIds

/-- Internal update passed to the data structure after external name translation: either a point
insertion (returning a reusable internal handle) or deletion of a currently active handle. -/
inductive InternalUpdate (d : ℕ) : Type
  | insert (pt : EuclideanSpace ℝ (Fin d))
  | delete (handle : ℕ)

/-- Translate an external update on `P` into the internal handle-based update processed by the
algorithm. -/
def toInternalUpdate {d : ℕ} (P : DynamicPointSet d) : DynamicUpdate d → InternalUpdate d
  | .insert _ _ pt => .insert pt
  | .delete id => .delete (P.handleOfId id)

/-- Apply a legal external update `op` to `P` given the optional reusable handle `returnedHandle`
returned by the algorithm (`some h` with `h ∉ P.activeHandles` on insertion; `none` on deletion).
Coordinates of active identities remain fixed until deleted, deleted handles become free for reuse,
and every insertion starts a new insertion lifetime. -/
noncomputable def applyDynamicUpdate {d : ℕ} (P : DynamicPointSet d) (op : DynamicUpdate d)
    (returnedHandle : Option ℕ) : Option (DynamicPointSet d) :=
  match op, returnedHandle with
  | .insert id _ pt, some h =>
      if id ∉ P.activeIds ∧ h ∉ P.activeHandles then
        some
          { activeIds := insert id P.activeIds
            coords := Function.update P.coords id pt
            activeHandles := insert h P.activeHandles
            handleOfId := Function.update P.handleOfId id h
            idOfHandle := Function.update P.idOfHandle h id
            nextLifetime := P.nextLifetime + 1
            lifetimeOfId := Function.update P.lifetimeOfId id P.nextLifetime }
      else
        none
  | .delete id, none =>
      if id ∈ P.activeIds then
        let h := P.handleOfId id
        some
          { activeIds := P.activeIds.erase id
            coords := Function.update P.coords id 0
            activeHandles := P.activeHandles.erase h
            handleOfId := Function.update P.handleOfId id 0
            idOfHandle := Function.update P.idOfHandle h 0
            nextLifetime := P.nextLifetime
            lifetimeOfId := Function.update P.lifetimeOfId id 0 }
      else
        none
  | _, _ => none

/-- Maintained diameter answer stored by the algorithm during updates: two active handles (when
`|P| ≥ 2`) together with the exact squared Euclidean distance between their points. -/
structure StoredDiameterAnswer : Type where
  diameterHandles : Option (ℕ × ℕ)
  cachedDistSq : ℝ

/-- Resolve the stored handle pair to the corresponding pair of active external identities. -/
def resolveAnswerIdentities {d : ℕ} (P : DynamicPointSet d) (ans : StoredDiameterAnswer) :
    Option (ℕ × ℕ) :=
  ans.diameterHandles.map (fun hh => (P.idOfHandle hh.1, P.idOfHandle hh.2))

/-- Validity of a maintained factor-`c` diameter answer on `P`:
- when `|P| ≤ 1`, `diam(P) = 0`, no pair is returned (`diameterHandles = none`), and the stored
  squared distance is `0`;
- when `|P| ≥ 2`, `diameterHandles = some (h₁, h₂)` consists of two distinct active handles in `P`
  (mapping to two distinct active identities `id₁ ≠ id₂`, including when all coordinates coincide
  and `diam(P) = 0`), `cachedDistSq` equals the exact squared distance `‖coords id₁ - coords id₂‖^2`,
  and `(id₁, id₂)` is a factor-`c` diameter pair with distance in `[diam(P) / c, diam(P)]`. -/
def IsValidFactorCAnswer {d : ℕ} (c : ℝ) (P : DynamicPointSet d)
    (ans : StoredDiameterAnswer) : Prop :=
  if P.activeIds.card ≤ 1 then
    ans.diameterHandles = none ∧ ans.cachedDistSq = 0
  else
    ∃ h₁ h₂ : ℕ,
      ans.diameterHandles = some (h₁, h₂) ∧
      h₁ ∈ P.activeHandles ∧ h₂ ∈ P.activeHandles ∧ h₁ ≠ h₂ ∧
      let id₁ := P.idOfHandle h₁
      let id₂ := P.idOfHandle h₂
      ans.cachedDistSq = euclideanDistSq (P.coords id₁) (P.coords id₂) ∧
      IsIndexedFactorCDiameterPair c P.activeIds P.coords id₁ id₂

/-- Single-step halting outcome of a dynamic diameter data structure processing one update with an
exact finite list of fresh random bits. -/
structure DynamicStepOutcome (State : Type) : Type where
  nextState : State
  returnedHandle : Option ℕ
  storedAnswer : StoredDiameterAnswer
  work : ℕ
  peakSpace : ℕ

/-- Interface of a randomized dynamic diameter data structure in `ℝ^d` starting from `P = ∅`,
storing its maintained answer inside `State` during updates (`cachedAnswer`), with explicit costs
for retrieving the answer identities and stored-distance reference (`retrieveIdsAndRefCost`) and
for writing coordinates or squared distance of output length `L` (`writeOutputCost L`). -/
structure DynamicDiameterStructure (d : ℕ) (State : Type) : Type where
  initState : State
  initWork : ℕ
  initSpace : ℕ
  cachedAnswer : State → StoredDiameterAnswer
  retrieveIdsAndRefCost : ℕ
  writeOutputCost : ℕ → ℕ
  stepWithBits :
    Finset ℕ → (ℕ → EuclideanSpace ℝ (Fin d)) → State → InternalUpdate d → List Bool →
      Option (DynamicStepOutcome State)

/-- Structural invariants of a dynamic diameter structure:
1. Initial empty state caches `(none, 0)`, and every completed update stores its reported answer in
   `nextState` (`out.storedAnswer = alg.cachedAnswer out.nextState`);
2. Prefix-free random bit consumption: distinct halting random bit lists for the same state and
   update are prefix-incomparable;
3. Retrieving the stored answer's identities and a reference to its cached squared distance takes
   time at most `queryConst` (`O(1)` when `queryConst` is an absolute constant), and writing out
   coordinates or the squared distance of length `L` takes time at most `writeFactor * (L + 1)`. -/
def SatisfiesDynamicStorageAndQueryModel {d : ℕ} {State : Type}
    (queryConst writeFactor : ℕ) (alg : DynamicDiameterStructure d State) : Prop :=
  alg.cachedAnswer alg.initState = { diameterHandles := none, cachedDistSq := 0 } ∧
  (∀ activeH hCoords st uop bs out,
    alg.stepWithBits activeH hCoords st uop bs = some out →
      out.storedAnswer = alg.cachedAnswer out.nextState) ∧
  (∀ activeH hCoords st uop bs₁ bs₂ out₁ out₂,
    alg.stepWithBits activeH hCoords st uop bs₁ = some out₁ →
    alg.stepWithBits activeH hCoords st uop bs₂ = some out₂ →
    bs₁ <+: bs₂ → bs₁ = bs₂) ∧
  alg.retrieveIdsAndRefCost ≤ queryConst ∧
  (∀ L : ℕ, alg.writeOutputCost L ≤ writeFactor * (L + 1))

end UL
