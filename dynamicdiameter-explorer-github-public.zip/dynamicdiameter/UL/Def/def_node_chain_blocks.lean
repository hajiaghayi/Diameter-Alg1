import Mathlib
import UL.Def.def_core_witness_halfspaces
set_option autoImplicit false

/-! Definition (Sec. 4: Nodes, cores, residuals, age, and block certificates) (paper p.15). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- Geometric parameters `(o, V)` of a chain node in `ℝ^d`: one center `o ∈ ℝ^d` and one
nonnegative variance `V ≥ 0`. -/
structure ChainNode (d : ℕ) where
  o : EuclideanSpace ℝ (Fin d)
  V : ℝ
  V_nonneg : 0 ≤ V

open Classical in
/-- Current core `C = S ∩ B(o, √V)` of a node with center `o` and variance `V` on finite indexed
input set `S : Finset ι` (with point coordinates `pts : ι → ℝ^d`). -/
noncomputable def nodeCore {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) : Finset ι :=
  S.filter (fun i => pts i ∈ coreBall o V)

open Classical in
/-- Current residual `S \ C` of a node with center `o` and variance `V` on finite indexed input set
`S : Finset ι`, where `C = nodeCore pts o V S`. -/
noncomputable def nodeResidual {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) : Finset ι :=
  S \ nodeCore pts o V S

/-- Current core `C = S ∩ B(N.o, √N.V)` of a `ChainNode` `N` on input set `S`. -/
noncomputable def ChainNode.core {d : ℕ} {ι : Type*}
    (N : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) : Finset ι :=
  nodeCore pts N.o N.V S

/-- Current residual `S \ C` of a `ChainNode` `N` on input set `S`. -/
noncomputable def ChainNode.residual {d : ℕ} {ι : Type*}
    (N : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) : Finset ι :=
  nodeResidual pts N.o N.V S

/-- Input sets `(S_0, …, S_k)` along a chain of `k ≥ 0` nodes `nodes : Fin k → ChainNode d` on
active indexed set `P : Finset ι` (0-indexed version of the paper's `S_1, …, S_{k+1}`):
`S_0 = P`, and `S_{i+1} = S_i \ C_i` for `0 ≤ i < k`. -/
noncomputable def chainInput {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι) :
    Fin (k + 1) → Finset ι :=
  fun j =>
    let rec go : (m : ℕ) → m ≤ k → Finset ι
      | 0, _ => P
      | m + 1, hm =>
          (nodes ⟨m, Nat.lt_of_succ_le hm⟩).residual pts (go m (Nat.le_of_succ_le hm))
    go j.val (Nat.lt_succ_iff.mp j.isLt)

/-- Core `C_i = S_i ∩ B(o_i, √V_i)` of the `i`-th node (`i : Fin k`) in a chain of `k` nodes on
active indexed set `P`. -/
noncomputable def chainCore {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (i : Fin k) : Finset ι :=
  (nodes i).core pts (chainInput pts nodes P i.castSucc)

/-- Terminal leaf set `S_k` (paper's `S_{k+1}`) remaining after all `k` nodes of the chain on
active indexed set `P`. -/
noncomputable def chainTerminal {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι) :
    Finset ι :=
  chainInput pts nodes P (Fin.last k)

open Classical in
/-- Single-element change to a node's input set `S`: inserting one absent identity (`i ∉ S`) or
deleting one present identity (`i ∈ S`). -/
def IsInputChange {ι : Type*} (S S' : Finset ι) : Prop :=
  (∃ i ∉ S, S' = insert i S) ∨ (∃ i ∈ S, S' = S.erase i)

open Classical in
/-- Age of a node along an input snapshot trajectory `S_seq : Fin (T + 1) → Finset ι` starting at
the construction birth snapshot `P₀ = S_seq 0` and ending at current input `S = S_seq (Fin.last T)`:
the total count of insertions into plus deletions from the node's input across all steps. -/
noncomputable def nodeAge {ι : Type*} {T : ℕ} (S_seq : Fin (T + 1) → Finset ι) : ℕ :=
  ∑ r : Fin T, ((S_seq r.succ \ S_seq r.castSucc).card + (S_seq r.castSucc \ S_seq r.succ).card)

/-- `age` is a valid node age from construction birth snapshot `P₀` to current input `S` if `S`
is obtained from `P₀` by a sequence of `age` single-element input changes (insertions and
deletions). -/
def HasNodeAge {ι : Type*} (P₀ S : Finset ι) (age : ℕ) : Prop :=
  ∃ seq : Fin (age + 1) → Finset ι,
    seq 0 = P₀ ∧ seq (Fin.last age) = S ∧
    ∀ r : Fin age, IsInputChange (seq r.castSucc) (seq r.succ)

/-- Predicate that a subset of identities `B` with convex weights `coeff` is a block certificate
for `z = (o, s) ∈ ℝ^{d+1}` over birth set `P₀` (with coordinates `pts : ι → ℝ^d`): `B ⊆ P₀`,
`coeff i ≥ 0` on `B`, `∑_{i ∈ B} coeff i = 1`, and `∑_{i ∈ B} coeff i • (pts i)^+ = z`. -/
def IsBlockCertificate {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ι)
    (z : EuclideanSpace ℝ (Fin (d + 1)))
    (B : Finset ι) (coeff : ι → ℝ) : Prop :=
  B ⊆ P₀ ∧
  (∀ i ∈ B, 0 ≤ coeff i) ∧
  (∑ i ∈ B, coeff i = 1) ∧
  (∑ i ∈ B, coeff i • paraboloidLift (pts i) = z)

/-- Bundled block certificate for `z = (o, s) ∈ ℝ^{d+1}` over birth set `P₀`: a subset `B ⊆ P₀` of
birth identities together with explicitly stored nonnegative convex coefficients `coeff` expressing
`z` in `B`'s lifted convex hull. -/
structure BlockCertificate {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ι)
    (z : EuclideanSpace ℝ (Fin (d + 1))) where
  B : Finset ι
  coeff : ι → ℝ
  subset_birth : B ⊆ P₀
  coeff_nonneg : ∀ i ∈ B, 0 ≤ coeff i
  sum_coeff : ∑ i ∈ B, coeff i = 1
  sum_lift : ∑ i ∈ B, coeff i • paraboloidLift (pts i) = z

/-- A block of birth identities `B` is intact in current input set `S` when none of its identities
has been deleted from `S`, i.e., `B ⊆ S`. -/
def IsIntactBlock {ι : Type*} (B S : Finset ι) : Prop :=
  B ⊆ S

/-- A `BlockCertificate` `cert` is intact in current input set `S` when `cert.B ⊆ S`. -/
def BlockCertificate.IsIntact {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {z : EuclideanSpace ℝ (Fin (d + 1))}
    (cert : BlockCertificate pts P₀ z) (S : Finset ι) : Prop :=
  IsIntactBlock cert.B S

end UL
