import Mathlib
import UL.Def.def_node_baseline
import UL.Def.def_shells_configurations
set_option autoImplicit false

/-! Definition (Sec. 5.3: Local configuration matching invariant, Algorithm 2, and node estimate W) (paper p.19). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

open Classical in
/-- Matched left vertices `V_L(M) = {x ∈ V_L : ∃ y, (x, y) ∈ M}` of a bipartite edge set `M` on
active left vertex set `V_L`. -/
noncomputable def matchedLeft {ι : Type*} (V_L : Finset ι) (M : Finset (ι × ι)) : Finset ι :=
  V_L.filter (fun x => ∃ y, (x, y) ∈ M)

open Classical in
/-- Matched right vertices `V_R(M) = {y ∈ V_R : ∃ x, (x, y) ∈ M}` of a bipartite edge set `M` on
active right vertex set `V_R`. -/
noncomputable def matchedRight {ι : Type*} (V_R : Finset ι) (M : Finset (ι × ι)) : Finset ι :=
  V_R.filter (fun y => ∃ x, (x, y) ∈ M)

open Classical in
/-- Unmatched left vertices `U_L = V_L \ V_L(M) = {x ∈ V_L : ∀ y, (x, y) ∉ M}` on the left side of
a configuration. -/
noncomputable def unmatchedLeft {ι : Type*} (V_L : Finset ι) (M : Finset (ι × ι)) : Finset ι :=
  V_L.filter (fun x => ∀ y, (x, y) ∉ M)

open Classical in
/-- Unmatched right vertices `U_R = V_R \ V_R(M) = {y ∈ V_R : ∀ x, (x, y) ∉ M}` on the right side
of a configuration. -/
noncomputable def unmatchedRight {ι : Type*} (V_R : Finset ι) (M : Finset (ι × ι)) : Finset ι :=
  V_R.filter (fun y => ∀ x, (x, y) ∉ M)

/-- Predicate that `M ⊆ V_L × V_R` is a bipartite matching between active left vertex set `V_L`
and active right vertex set `V_R`: every edge in `M` has left endpoint in `V_L` and right endpoint
in `V_R`, each left vertex is incident to at most one edge of `M`, and each right vertex is
incident to at most one edge of `M` (left and right copies of the same original identity are
distinct vertices on opposite sides of the bipartition). -/
def IsBipartiteMatching {ι : Type*} (V_L V_R : Finset ι) (M : Finset (ι × ι)) : Prop :=
  M ⊆ V_L ×ˢ V_R ∧
  (∀ x y₁ y₂, (x, y₁) ∈ M → (x, y₂) ∈ M → y₁ = y₂) ∧
  (∀ x₁ x₂ y, (x₁, y) ∈ M → (x₂, y) ∈ M → x₁ = x₂)

/-- Boxed local configuration matching invariant (Section 5.3, p. 18): `M ⊆ E_weak` is a bipartite
matching between `V_L` and `V_R`, and `E_strong ∩ (U_L × U_R) = ∅` where `U_L = unmatchedLeft V_L M`
and `U_R = unmatchedRight V_R M`. -/
def SatisfiesLocalMatchingInvariant {ι : Type*}
    (V_L V_R : Finset ι) (E_weak E_strong M : Finset (ι × ι)) : Prop :=
  M ⊆ E_weak ∧
  IsBipartiteMatching V_L V_R M ∧
  Disjoint E_strong (unmatchedLeft V_L M ×ˢ unmatchedRight V_R M)

/-- Local configuration matching invariant specialized to configuration `(j, k, ℓ)` at node `(o, V)`
on finite indexed input set `S : Finset ι` with subdivision count `m_0`, parameters `(γ, λ)`, and
cutoff `K`. -/
def SatisfiesConfigMatchingInvariant {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (m0 : ℕ) (γ lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ) (S : Finset ι)
    (j k ℓ : ℕ) (M : Finset (ι × ι)) : Prop :=
  SatisfiesLocalMatchingInvariant
    (configLeftVertices pts m0 o V S j)
    (configRightVertices pts m0 o V K S k)
    (configWeakEdges pts m0 lam o V K S j k ℓ)
    (configStrongEdges pts m0 γ lam o V K S j k ℓ)
    M

/-- Local configuration matching invariant for a `LocalScaleParams` bundle at configuration
`(j, k, ℓ)`. -/
def LocalScaleParams.SatisfiesMatchingInvariant {d : ℕ} {ι : Type*}
    (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι)
    (j k ℓ : ℕ) (M : Finset (ι × ι)) : Prop :=
  SatisfiesConfigMatchingInvariant pts params.m0 params.γ params.lam o V params.K S j k ℓ M

/-- Query direction `-u_v = -radialDirection o p` used by `Attach(v)` when searching the opposite
unmatched angular index. -/
noncomputable def attachQueryDirection {d : ℕ}
    (o p : EuclideanSpace ℝ (Fin d)) : EuclideanSpace ℝ (Fin d) :=
  -radialDirection o p

/-- Exact correlation acceptance condition `⟨-u_v, u_w⟩ > b` in `Attach(v)` relative to center `o`
and weak-edge correlation threshold `b`. -/
def attachAcceptsCorrelation {d : ℕ}
    (o p q : EuclideanSpace ℝ (Fin d)) (b : ℝ) : Prop :=
  b < radialCorrelation o p q

/-- Angular search promise for `Attach(v)` querying opposite unmatched set `U_opp` in direction
`-u_v` with strong/weak correlation thresholds `(a, b)`: any returned `some w` lies in `U_opp` and
satisfies `⟨-u_v, u_w⟩ > b`, and `none` implies no `w ∈ U_opp` satisfies `⟨-u_v, u_w⟩ > a`. -/
def SatisfiesAngularSearchPromise {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (a b : ℝ) (U_opp : Finset ι) (v_id : ι) (ans : Option ι) : Prop :=
  match ans with
  | some w => w ∈ U_opp ∧ b < radialCorrelation o (pts v_id) (pts w)
  | none => ∀ w ∈ U_opp, radialCorrelation o (pts v_id) (pts w) ≤ a

/-- Angular search promise specialized to the correlation thresholds `(a, b)` of configuration
`(j, k, ℓ)` at variance `V`. -/
def SatisfiesConfigSearchPromise {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (m0 : ℕ) (γ lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (j k ℓ : ℕ) (U_opp : Finset ι) (v_id : ι) (ans : Option ι) : Prop :=
  SatisfiesAngularSearchPromise pts o
    (configThresholdA m0 γ lam V j k ℓ)
    (configThresholdB m0 lam V j k ℓ)
    U_opp v_id ans

/-- Bipartite side (`left` for `V_L`, `right` for `V_R`) of a vertex copy in a local
configuration. -/
inductive MatchingSide where
  | left
  | right
  deriving DecidableEq, Repr

/-- Opposite bipartite side (`right` for `left`, `left` for `right`). -/
def MatchingSide.opposite : MatchingSide → MatchingSide
  | .left => .right
  | .right => .left

/-- A side-tagged copy `(side, id)` of an original point identity `id : ι` in a configuration's
bipartite graph. -/
structure CopyVertex (ι : Type*) where
  side : MatchingSide
  id : ι
  deriving DecidableEq, Repr

/-- Graph-level search promise for `Attach(v)` against opposite unmatched set `U_opp` with edge
sets `E_weak, E_strong ⊆ V_L × V_R`: any returned `some w` lies in `U_opp` and forms a weak edge
in `E_weak` with `v`, and `none` implies no `w ∈ U_opp` forms a strong edge in `E_strong` with `v`. -/
def SatisfiesEdgeSearchPromise {ι : Type*}
    (E_weak E_strong : Finset (ι × ι)) (U_opp : Finset ι)
    (v : CopyVertex ι) (ans : Option ι) : Prop :=
  match v.side, ans with
  | .left, some w => w ∈ U_opp ∧ (v.id, w) ∈ E_weak
  | .left, none => ∀ w ∈ U_opp, (v.id, w) ∉ E_strong
  | .right, some w => w ∈ U_opp ∧ (w, v.id) ∈ E_weak
  | .right, none => ∀ w ∈ U_opp, (w, v.id) ∉ E_strong

/-- Stored edge record in a local configuration matching list `M`, consisting of left vertex
identity `left : ι`, right vertex identity `right : ι`, and recorded exact squared Euclidean
distance `distSq : ℝ` (`‖pts left - pts right‖^2`). -/
structure MatchingEdge (ι : Type*) where
  left : ι
  right : ι
  distSq : ℝ

/-- Ordered bipartite endpoint pair `(e.left, e.right)` of a `MatchingEdge`. -/
def MatchingEdge.pair {ι : Type*} (e : MatchingEdge ι) : ι × ι :=
  (e.left, e.right)

/-- Entry in a configuration's unmatched angular index, pairing a vertex identity `id : ι` with its
insertion lifetime tag `lifetime : ℕ`. -/
structure UnmatchedEntry (ι : Type*) where
  id : ι
  lifetime : ℕ
  deriving DecidableEq, Repr

/-- State maintained by Algorithm 2 for one local configuration matching: the matching list
`matchingList` (recording edges and their exact squared distances), the left and right unmatched
angular indices `leftUnmatchedIndex` and `rightUnmatchedIndex` (with insertion lifetimes), and
monotone counter `nextLifetime` supplying fresh insertion lifetimes. -/
structure LocalMatchingState (ι : Type*) where
  matchingList : List (MatchingEdge ι)
  leftUnmatchedIndex : List (UnmatchedEntry ι)
  rightUnmatchedIndex : List (UnmatchedEntry ι)
  nextLifetime : ℕ

/-- Initial empty `LocalMatchingState` with empty matching list and empty unmatched indices. -/
def LocalMatchingState.empty (ι : Type*) : LocalMatchingState ι :=
  { matchingList := []
    leftUnmatchedIndex := []
    rightUnmatchedIndex := []
    nextLifetime := 0 }

open Classical in
/-- Finite bipartite matching `M : Finset (ι × ι)` induced by `st.matchingList`. -/
noncomputable def LocalMatchingState.matching {ι : Type*}
    (st : LocalMatchingState ι) : Finset (ι × ι) :=
  (st.matchingList.map MatchingEdge.pair).toFinset

open Classical in
/-- Finite set of unmatched left vertex identities currently stored in `st.leftUnmatchedIndex`. -/
noncomputable def LocalMatchingState.leftIndexSet {ι : Type*}
    (st : LocalMatchingState ι) : Finset ι :=
  (st.leftUnmatchedIndex.map UnmatchedEntry.id).toFinset

open Classical in
/-- Finite set of unmatched right vertex identities currently stored in `st.rightUnmatchedIndex`. -/
noncomputable def LocalMatchingState.rightIndexSet {ι : Type*}
    (st : LocalMatchingState ι) : Finset ι :=
  (st.rightUnmatchedIndex.map UnmatchedEntry.id).toFinset

/-- Finite set of vertex identities in `st`'s unmatched index on `side`. -/
noncomputable def LocalMatchingState.sameIndexSet {ι : Type*}
    (st : LocalMatchingState ι) : MatchingSide → Finset ι
  | .left => st.leftIndexSet
  | .right => st.rightIndexSet

/-- Finite set of vertex identities in `st`'s unmatched index opposite to `side`. -/
noncomputable def LocalMatchingState.oppositeIndexSet {ι : Type*}
    (st : LocalMatchingState ι) : MatchingSide → Finset ι
  | .left => st.rightIndexSet
  | .right => st.leftIndexSet

/-- Full first `MatchingEdge` record (including recorded squared distance) in `st.matchingList`, or
`none` if empty. -/
def LocalMatchingState.storedEdgeRecord {ι : Type*}
    (st : LocalMatchingState ι) : Option (MatchingEdge ι) :=
  st.matchingList.head?

/-- `StoredEdge()` in Algorithm 2: returns the first edge `(left, right)` in the matching list, or
`none` if the matching list is empty. -/
def LocalMatchingState.storedEdge {ι : Type*}
    (st : LocalMatchingState ι) : Option (ι × ι) :=
  st.matchingList.head?.map MatchingEdge.pair

/-- Predicate that `edge : Option (ι × ι)` is a valid stored edge of matching `M`: `none` when
`M = ∅`, and `some e` with `e ∈ M` when `M ≠ ∅`. -/
def IsStoredMatchingEdge {ι : Type*} (M : Finset (ι × ι)) : Option (ι × ι) → Prop
  | none => M = ∅
  | some e => e ∈ M

/-- Whether copy `v` is active in `(V_L, V_R)` (`v.id ∈ V_L` for `.left`, `v.id ∈ V_R` for
`.right`). -/
def isCopyActive {ι : Type*} (V_L V_R : Finset ι) (v : CopyVertex ι) : Prop :=
  match v.side with
  | .left => v.id ∈ V_L
  | .right => v.id ∈ V_R

/-- Whether copy `v` is incident to an edge in `st.matchingList`. -/
def LocalMatchingState.isCopyMatched {ι : Type*}
    (st : LocalMatchingState ι) (v : CopyVertex ι) : Prop :=
  match v.side with
  | .left => ∃ e ∈ st.matchingList, e.left = v.id
  | .right => ∃ e ∈ st.matchingList, e.right = v.id

/-- Whether copy `v` is currently stored in its side's unmatched index in `st`. -/
def LocalMatchingState.isCopyInIndex {ι : Type*}
    (st : LocalMatchingState ι) (v : CopyVertex ι) : Prop :=
  match v.side with
  | .left => ∃ e ∈ st.leftUnmatchedIndex, e.id = v.id
  | .right => ∃ e ∈ st.rightUnmatchedIndex, e.id = v.id

/-- Precondition of `Attach(v)` in Algorithm 2: `v` is active, unmatched, and absent from its
unmatched index. -/
def IsAttachPrecond {ι : Type*} (V_L V_R : Finset ι)
    (st : LocalMatchingState ι) (v : CopyVertex ι) : Prop :=
  isCopyActive V_L V_R v ∧ ¬ st.isCopyMatched v ∧ ¬ st.isCopyInIndex v

/-- Structural representation invariant of `st : LocalMatchingState ι` on active vertex sets
`(V_L, V_R)` with coordinates `pts`: `matchingList` has distinct left and right endpoints in
`V_L × V_R` with exact squared distances `‖pts left - pts right‖^2`, the left and right unmatched
indices store `unmatchedLeft V_L st.matching` and `unmatchedRight V_R st.matching` without
duplicate identities, and all live unmatched-index entries have pairwise distinct insertion
lifetimes strictly below `st.nextLifetime`. -/
def LocalMatchingState.WellFormed {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (V_L V_R : Finset ι) (st : LocalMatchingState ι) : Prop :=
  (st.matchingList.map MatchingEdge.left).Nodup ∧
  (st.matchingList.map MatchingEdge.right).Nodup ∧
  (∀ e ∈ st.matchingList,
    e.left ∈ V_L ∧ e.right ∈ V_R ∧ e.distSq = ‖pts e.left - pts e.right‖ ^ 2) ∧
  (st.leftUnmatchedIndex.map UnmatchedEntry.id).Nodup ∧
  st.leftIndexSet = unmatchedLeft V_L st.matching ∧
  (st.rightUnmatchedIndex.map UnmatchedEntry.id).Nodup ∧
  st.rightIndexSet = unmatchedRight V_R st.matching ∧
  ((st.leftUnmatchedIndex ++ st.rightUnmatchedIndex).map UnmatchedEntry.lifetime).Nodup ∧
  (∀ e ∈ st.leftUnmatchedIndex, e.lifetime < st.nextLifetime) ∧
  (∀ e ∈ st.rightUnmatchedIndex, e.lifetime < st.nextLifetime)

/-- Full Algorithm 2 state invariant combining `LocalMatchingState.WellFormed` and the boxed local
matching invariant `SatisfiesLocalMatchingInvariant`. -/
def LocalMatchingState.SatisfiesInvariant {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (V_L V_R : Finset ι) (E_weak E_strong : Finset (ι × ι))
    (st : LocalMatchingState ι) : Prop :=
  st.WellFormed pts V_L V_R ∧
  SatisfiesLocalMatchingInvariant V_L V_R E_weak E_strong st.matching

open Classical in
/-- `Attach(v)` in Algorithm 2 (lines 1–6) given search answer `ans : Option ι` from querying the
opposite unmatched index in direction `-u_v` (accepting correlations `> b`): if `ans = some w`,
removes `w` from its unmatched index and inserts edge `vw` (oriented `(left, right)`) into
`matchingList` with exact squared distance `‖pts left - pts right‖^2`; if `ans = none`, inserts `v`
into its side's unmatched index with fresh insertion lifetime `st.nextLifetime`. -/
noncomputable def attachStep {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (st : LocalMatchingState ι) (v : CopyVertex ι) (ans : Option ι) :
    LocalMatchingState ι :=
  match v.side, ans with
  | .left, some w =>
    { matchingList := st.matchingList ++ [⟨v.id, w, ‖pts v.id - pts w‖ ^ 2⟩]
      leftUnmatchedIndex := st.leftUnmatchedIndex
      rightUnmatchedIndex := st.rightUnmatchedIndex.filter (fun e => e.id ≠ w)
      nextLifetime := st.nextLifetime }
  | .left, none =>
    { matchingList := st.matchingList
      leftUnmatchedIndex := st.leftUnmatchedIndex ++ [⟨v.id, st.nextLifetime⟩]
      rightUnmatchedIndex := st.rightUnmatchedIndex
      nextLifetime := st.nextLifetime + 1 }
  | .right, some w =>
    { matchingList := st.matchingList ++ [⟨w, v.id, ‖pts w - pts v.id‖ ^ 2⟩]
      leftUnmatchedIndex := st.leftUnmatchedIndex.filter (fun e => e.id ≠ w)
      rightUnmatchedIndex := st.rightUnmatchedIndex
      nextLifetime := st.nextLifetime }
  | .right, none =>
    { matchingList := st.matchingList
      leftUnmatchedIndex := st.leftUnmatchedIndex
      rightUnmatchedIndex := st.rightUnmatchedIndex ++ [⟨v.id, st.nextLifetime⟩]
      nextLifetime := st.nextLifetime + 1 }

/-- Valid transition of `Attach(v)` against graph edge sets `(E_weak, E_strong)`: `v` satisfies
`IsAttachPrecond` on `(V_L, V_R)`, and `st' = attachStep pts st v ans` for some search answer `ans`
satisfying `SatisfiesEdgeSearchPromise` on `st.oppositeIndexSet v.side`. -/
def ValidAttachEdgeStep {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (V_L V_R : Finset ι) (E_weak E_strong : Finset (ι × ι))
    (st : LocalMatchingState ι) (v : CopyVertex ι) (st' : LocalMatchingState ι) : Prop :=
  IsAttachPrecond V_L V_R st v ∧
  ∃ ans : Option ι,
    SatisfiesEdgeSearchPromise E_weak E_strong (st.oppositeIndexSet v.side) v ans ∧
    st' = attachStep pts st v ans

/-- Valid transition of `Attach(v)` against angular correlation thresholds `(a, b)` relative to
center `o`: `v` satisfies `IsAttachPrecond` on `(V_L, V_R)`, and `st' = attachStep pts st v ans`
for some search answer `ans` satisfying `SatisfiesAngularSearchPromise` on
`st.oppositeIndexSet v.side`. -/
def ValidAttachAngularStep {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (a b : ℝ) (V_L V_R : Finset ι)
    (st : LocalMatchingState ι) (v : CopyVertex ι) (st' : LocalMatchingState ι) : Prop :=
  IsAttachPrecond V_L V_R st v ∧
  ∃ ans : Option ι,
    SatisfiesAngularSearchPromise pts o a b (st.oppositeIndexSet v.side) v.id ans ∧
    st' = attachStep pts st v ans

/-- Whether a point `p ∈ ℝ^d` has an applicable left copy in a configuration with core shell `j` at
node `(o, V)` and subdivision count `m_0`: `p ∈ B(o, √V)` and `shellIndex m0 o V p = j`. -/
def hasApplicableLeftCopy {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (j : ℕ)
    (p : EuclideanSpace ℝ (Fin d)) : Prop :=
  p ∈ coreBall o V ∧ shellIndex m0 o V p = j

/-- Whether a point `p ∈ ℝ^d` has an applicable right copy in a configuration with input shell `k`
at node `(o, V)`, subdivision count `m_0`, and cutoff `K`: `‖p - o‖ ≤ K √V` and
`shellIndex m0 o V p = k`. -/
def hasApplicableRightCopy {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ) (k : ℕ)
    (p : EuclideanSpace ℝ (Fin d)) : Prop :=
  IsEligiblePoint o V K p ∧ shellIndex m0 o V p = k

open Classical in
/-- `InsertOriginal(p)` in Algorithm 2 (line 7): creates `p`'s applicable left and right copies, in
that order (`inLeft` first, then `inRight`), and calls `Attach` on each using search answers
`ansLeft` and `ansRight`. -/
noncomputable def insertOriginalStep {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (inLeft inRight : Prop)
    (st : LocalMatchingState ι) (p : ι)
    (ansLeft ansRight : Option ι) : LocalMatchingState ι :=
  let st₁ := if inLeft then attachStep pts st ⟨.left, p⟩ ansLeft else st
  if inRight then attachStep pts st₁ ⟨.right, p⟩ ansRight else st₁

/-- `InsertOriginal(p)` specialized to configuration shells `(j, k)` at node `(o, V)` with
subdivision count `m_0` and cutoff `K`. -/
noncomputable def configInsertOriginalStep {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (m0 : ℕ) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ) (j k : ℕ)
    (st : LocalMatchingState ι) (p : ι)
    (ansLeft ansRight : Option ι) : LocalMatchingState ι :=
  insertOriginalStep pts
    (hasApplicableLeftCopy m0 o V j (pts p))
    (hasApplicableRightCopy m0 o V K k (pts p))
    st p ansLeft ansRight

/-- Valid transition of `InsertOriginal(p)` from active sets `(V_L, V_R)` (`p ∉ V_L`, `p ∉ V_R`) to
updated active sets `(V_L', V_R')` and edge sets `(E_weak', E_strong')`: attaches `⟨.left, p⟩` if
`p ∈ V_L'` and then `⟨.right, p⟩` if `p ∈ V_R'`, each under `SatisfiesEdgeSearchPromise`. -/
def ValidInsertOriginalEdgeStep {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (V_L' V_R' : Finset ι) (E_weak' E_strong' : Finset (ι × ι))
    (st : LocalMatchingState ι) (p : ι) (st' : LocalMatchingState ι) : Prop :=
  ∃ st₁ : LocalMatchingState ι,
    ((p ∈ V_L' ∧ ValidAttachEdgeStep pts V_L' V_R' E_weak' E_strong' st ⟨.left, p⟩ st₁) ∨
      (p ∉ V_L' ∧ st₁ = st)) ∧
    ((p ∈ V_R' ∧ ValidAttachEdgeStep pts V_L' V_R' E_weak' E_strong' st₁ ⟨.right, p⟩ st') ∨
      (p ∉ V_R' ∧ st' = st₁))

/-- Valid transition of `InsertOriginal(p)` to updated active sets `(V_L', V_R')` under angular
correlation thresholds `(a, b)` relative to center `o`. -/
def ValidInsertOriginalAngularStep {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (a b : ℝ) (V_L' V_R' : Finset ι)
    (st : LocalMatchingState ι) (p : ι) (st' : LocalMatchingState ι) : Prop :=
  ∃ st₁ : LocalMatchingState ι,
    ((p ∈ V_L' ∧ ValidAttachAngularStep pts o a b V_L' V_R' st ⟨.left, p⟩ st₁) ∨
      (p ∉ V_L' ∧ st₁ = st)) ∧
    ((p ∈ V_R' ∧ ValidAttachAngularStep pts o a b V_L' V_R' st₁ ⟨.right, p⟩ st') ∨
      (p ∉ V_R' ∧ st' = st₁))

open Classical in
/-- Line 8 of Algorithm 2 (`DeleteOriginal(p)`): removes both copies of `p` from their unmatched
indices and from any incident matching edges in `st`. -/
noncomputable def removeCopiesFromState {ι : Type*}
    (st : LocalMatchingState ι) (p : ι) : LocalMatchingState ι :=
  { matchingList := st.matchingList.filter (fun e => e.left ≠ p ∧ e.right ≠ p)
    leftUnmatchedIndex := st.leftUnmatchedIndex.filter (fun e => e.id ≠ p)
    rightUnmatchedIndex := st.rightUnmatchedIndex.filter (fun e => e.id ≠ p)
    nextLifetime := st.nextLifetime }

open Classical in
/-- Canonical duplicate-free list `F` of surviving (`≠ p`) former partners of `p`'s left and right
copies in `st.matchingList` (at most two copies: a surviving right partner of `(p, y)` and a
surviving left partner of `(x, p)`). -/
noncomputable def survivingFormerPartners {ι : Type*}
    (st : LocalMatchingState ι) (p : ι) : List (CopyVertex ι) :=
  let rightPartners := (st.matchingList.filter (fun e => e.left = p ∧ e.right ≠ p)).map
    (fun e => CopyVertex.mk .right e.right)
  let leftPartners := (st.matchingList.filter (fun e => e.right = p ∧ e.left ≠ p)).map
    (fun e => CopyVertex.mk .left e.left)
  (rightPartners ++ leftPartners).dedup

open Classical in
/-- Finite set `F` of surviving (`≠ p`) former partners of `p`'s copies in `st.matchingList`. -/
noncomputable def survivingFormerPartnerSet {ι : Type*}
    (st : LocalMatchingState ι) (p : ι) : Finset (CopyVertex ι) :=
  (survivingFormerPartners st p).toFinset

open Classical in
/-- Line 9 of Algorithm 2: iterates through surviving former partners `F`, calling `Attach` on each
still-unmatched member (absent from `matchingList` and its unmatched index) using successive search
answers from `answers`. -/
noncomputable def repairFormerPartners {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) :
    LocalMatchingState ι → List (CopyVertex ι) → List (Option ι) → LocalMatchingState ι
  | st, [], _ => st
  | st, u :: us, answers =>
    if st.isCopyMatched u ∨ st.isCopyInIndex u then
      repairFormerPartners pts st us answers
    else
      match answers with
      | [] => st
      | ans :: rest => repairFormerPartners pts (attachStep pts st u ans) us rest

/-- `DeleteOriginal(p)` in Algorithm 2 (lines 8–9): removes both copies of `p` from their unmatched
indices or matching edges, collects the surviving former partners in `F`, and calls `Attach` on
each still-unmatched member of `F`. -/
noncomputable def deleteOriginalStep {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (st : LocalMatchingState ι) (p : ι) (answers : List (Option ι)) :
    LocalMatchingState ι :=
  repairFormerPartners pts (removeCopiesFromState st p) (survivingFormerPartners st p) answers

/-- Valid sequential repair of a list `F` of surviving former partners against updated active sets
`(V_L', V_R')` and edge sets `(E_weak', E_strong')`, calling `Attach` on each still-unmatched
member of `F`. -/
def ValidRepairEdgeSteps {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (V_L' V_R' : Finset ι) (E_weak' E_strong' : Finset (ι × ι)) :
    LocalMatchingState ι → List (CopyVertex ι) → LocalMatchingState ι → Prop
  | st, [], st' => st' = st
  | st, u :: us, st' =>
    ((st.isCopyMatched u ∨ st.isCopyInIndex u) ∧
      ValidRepairEdgeSteps pts V_L' V_R' E_weak' E_strong' st us st') ∨
    (¬ (st.isCopyMatched u ∨ st.isCopyInIndex u) ∧
      ∃ st₁ : LocalMatchingState ι,
        ValidAttachEdgeStep pts V_L' V_R' E_weak' E_strong' st u st₁ ∧
        ValidRepairEdgeSteps pts V_L' V_R' E_weak' E_strong' st₁ us st')

/-- Valid sequential repair of a list `F` of surviving former partners under angular correlation
thresholds `(a, b)` relative to center `o`. -/
def ValidRepairAngularSteps {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (a b : ℝ) (V_L' V_R' : Finset ι) :
    LocalMatchingState ι → List (CopyVertex ι) → LocalMatchingState ι → Prop
  | st, [], st' => st' = st
  | st, u :: us, st' =>
    ((st.isCopyMatched u ∨ st.isCopyInIndex u) ∧
      ValidRepairAngularSteps pts o a b V_L' V_R' st us st') ∨
    (¬ (st.isCopyMatched u ∨ st.isCopyInIndex u) ∧
      ∃ st₁ : LocalMatchingState ι,
        ValidAttachAngularStep pts o a b V_L' V_R' st u st₁ ∧
        ValidRepairAngularSteps pts o a b V_L' V_R' st₁ us st')

/-- Valid transition of `DeleteOriginal(p)` to surviving active sets `(V_L', V_R')` and edge sets
`(E_weak', E_strong')`: removes both copies of `p`, enumerates `F = survivingFormerPartnerSet st p`
in some duplicate-free order, and repairs each still-unmatched member via `Attach`. -/
def ValidDeleteOriginalEdgeStep {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (V_L' V_R' : Finset ι) (E_weak' E_strong' : Finset (ι × ι))
    (st : LocalMatchingState ι) (p : ι) (st' : LocalMatchingState ι) : Prop :=
  ∃ F : List (CopyVertex ι),
    F.Perm (survivingFormerPartners st p) ∧
    ValidRepairEdgeSteps pts V_L' V_R' E_weak' E_strong' (removeCopiesFromState st p) F st'

/-- Valid transition of `DeleteOriginal(p)` to surviving active sets `(V_L', V_R')` under angular
correlation thresholds `(a, b)` relative to center `o`. -/
def ValidDeleteOriginalAngularStep {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (a b : ℝ) (V_L' V_R' : Finset ι)
    (st : LocalMatchingState ι) (p : ι) (st' : LocalMatchingState ι) : Prop :=
  ∃ F : List (CopyVertex ι),
    F.Perm (survivingFormerPartners st p) ∧
    ValidRepairAngularSteps pts o a b V_L' V_R' (removeCopiesFromState st p) F st'

/-- Candidate length contributed by baseline length `L` and one optional stored edge
`edge : Option (ι × ι)`: `L` when `edge = none` (empty matching), and `max L ‖pts x - pts y‖` when
`edge = some (x, y)` (nonempty matching with stored edge `(x, y)`). -/
noncomputable def storedEdgeCandidate {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (L : ℝ) : Option (ι × ι) → ℝ
  | none => L
  | some (x, y) => max L ‖pts x - pts y‖

/-- Maximum `W = max ({L} ∪ {‖pts x - pts y‖ : cfg ∈ cfgs, stored cfg = some (x, y)})` of the
baseline length `L` and the original Euclidean lengths of one stored edge from each nonempty
matching across `cfgs : Finset κ` (equal to `L` when every matching in `cfgs` is empty or
`cfgs = ∅`). -/
noncomputable def matchingEstimateOn {d : ℕ} {ι κ : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (L : ℝ) (cfgs : Finset κ)
    (stored : κ → Option (ι × ι)) : ℝ :=
  if h : cfgs.Nonempty then
    cfgs.sup' h (fun cfg => storedEdgeCandidate pts L (stored cfg))
  else
    L

/-- Maximum of baseline length `L` and the original lengths of `StoredEdge()` across a finite
collection `cfgs : Finset κ` of `LocalMatchingState` instances. -/
noncomputable def stateMatchingEstimateOn {d : ℕ} {ι κ : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (L : ℝ) (cfgs : Finset κ)
    (states : κ → LocalMatchingState ι) : ℝ :=
  matchingEstimateOn pts L cfgs (fun cfg => (states cfg).storedEdge)

/-- Active local-range condition `V > 0` and `R_S ≤ K √V` at node `(o, V)` on finite input set `S`
(outside which Lemma 5.3 shows the baseline length `L` suffices). -/
def InNodeLocalRange {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ)
    (S : Finset ι) : Prop :=
  0 < V ∧ nodeMaxRadius pts o S ≤ (K : ℝ) * Real.sqrt V

open Classical in
/-- Node distance estimate `W` (Section 5.3, p. 19): equal to the maximum of the baseline length
`L` and the original Euclidean lengths `‖pts x - pts y‖` of one stored edge `stored cfg = some (x, y)`
from each nonempty matching across retained configurations `cfg ∈ retainedConfigs e γ lam K V` when
`V > 0` and `R_S ≤ K √V`, and equal to `L` otherwise. -/
noncomputable def nodeLocalEstimate {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (e γ lam : ℚ) (K : ℤ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι)
    (L : ℝ) (stored : ShellConfig → Option (ι × ι)) : ℝ :=
  if InNodeLocalRange pts o V K S then
    matchingEstimateOn pts L (retainedConfigs e γ lam K V) stored
  else
    L

/-- Node distance estimate `W` (`nodeLocalEstimate`) evaluated from `StoredEdge()` of maintained
`LocalMatchingState` instances `states : ShellConfig → LocalMatchingState ι`. -/
noncomputable def nodeStateLocalEstimate {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (e γ lam : ℚ) (K : ℤ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι)
    (L : ℝ) (states : ShellConfig → LocalMatchingState ι) : ℝ :=
  nodeLocalEstimate pts e γ lam K o V S L (fun cfg => (states cfg).storedEdge)

open Classical in
/-- Positive-variance node estimate `W` across all retained configurations (`0 < V`, without gating
on `R_S ≤ K √V`): equal to `matchingEstimateOn pts L (retainedConfigs e γ lam K V) stored` when
`0 < V`, and `L` when `V ≤ 0`. -/
noncomputable def nodeRetainedEstimate {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (e γ lam : ℚ) (K : ℤ) (V : ℝ)
    (L : ℝ) (stored : ShellConfig → Option (ι × ι)) : ℝ :=
  if 0 < V then
    matchingEstimateOn pts L (retainedConfigs e γ lam K V) stored
  else
    L

/-- Node distance estimate `W` (`nodeLocalEstimate`) for a `LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.nodeLocalEstimate {d : ℕ} {ι : Type*}
    (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι)
    (L : ℝ) (stored : ShellConfig → Option (ι × ι)) : ℝ :=
  UL.nodeLocalEstimate pts params.e params.γ params.lam params.K o V S L stored

/-- State-based node distance estimate `W` (`nodeStateLocalEstimate`) for a `LocalScaleParams`
bundle. -/
noncomputable def LocalScaleParams.nodeStateLocalEstimate {d : ℕ} {ι : Type*}
    (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι)
    (L : ℝ) (states : ShellConfig → LocalMatchingState ι) : ℝ :=
  UL.nodeStateLocalEstimate pts params.e params.γ params.lam params.K o V S L states

/-- Positive-variance node estimate `W` (`nodeRetainedEstimate`) for a `LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.nodeRetainedEstimate {d : ℕ} {ι : Type*}
    (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (L : ℝ) (stored : ShellConfig → Option (ι × ι)) : ℝ :=
  UL.nodeRetainedEstimate pts params.e params.γ params.lam params.K V L stored

/-- Node distance estimate `W` (`nodeLocalEstimate`) at a `ChainNode` `N` for a `LocalScaleParams`
bundle. -/
noncomputable def ChainNode.localEstimate {d : ℕ} {ι : Type*}
    (N : ChainNode d) (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι)
    (L : ℝ) (stored : ShellConfig → Option (ι × ι)) : ℝ :=
  params.nodeLocalEstimate pts N.o N.V S L stored

end UL
