import Mathlib
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Def.def_6_search_interface
set_option autoImplicit false

/-! Definition (Sec. C.3: Certified birth-variable search interface) (paper p.54). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-! ### 1. Polylogarithmic overhead factors and implicit direction nets -/

/-- A nonnegative factor family `P_fac : ℕ → ℕ → ℝ` (indexed by ambient dimension `d` and capacity
`n`) is `poly(d, log(2n))`-bounded if it is bounded by a bivariate polynomial `F`
(`IsBoundedByPoly2 F`) in `d` and `⌈log₂(2n)⌉` with no hidden power of `n`. -/
def IsPolyDLogNBounded (P_fac : ℕ → ℕ → ℝ) : Prop :=
  ∃ F : ℕ → ℕ → ℝ,
    IsBoundedByPoly2 F ∧
    ∀ d n : ℕ, 0 ≤ P_fac d n ∧ P_fac d n ≤ F d (Nat.clog 2 (2 * n))

/-- A nonnegative factor family `P_fac : ℕ → ℕ → ℕ → ℝ` (indexed by ambient dimension `d`,
coordinate bit-length `B`, and capacity `n`) is `poly(d, B, log(2n))`-bounded if it is bounded by a
trivariate polynomial `F` (`IsBoundedByPoly3 F`) in `d`, `B`, and `⌈log₂(2n)⌉` with no hidden
power of `n`. -/
def IsPolyDBLogNBounded (P_fac : ℕ → ℕ → ℕ → ℝ) : Prop :=
  ∃ F : ℕ → ℕ → ℕ → ℝ,
    IsBoundedByPoly3 F ∧
    ∀ d B n : ℕ, 0 ≤ P_fac d B n ∧ P_fac d B n ≤ F d B (Nat.clog 2 (2 * n))

/-- Compatibility of `q : SearchQuery ι d_s` on point set `S` in `gen : SearchGeneration ι d_s`
at nonnegative correlation margin `δ ≥ 0`: either `δ = 0` and standard compatibility
`gen.IsCompatible S q` holds (`⟪pts i, q.z⟫ ≤ 0` on rejected points), or `δ > 0` and `δ`-margin
compatibility `gen.IsMarginCompatible S δ q` holds (`⟪pts i, q.z⟫ ≤ -δ` on rejected points). -/
def IsCertifiedCompatible {ι : Type*} {d_s : ℕ}
    (gen : SearchGeneration ι d_s) (δ : ℝ) (S : Finset ι) (q : SearchQuery ι d_s) : Prop :=
  (δ = 0 ∧ gen.IsCompatible S q) ∨ gen.IsMarginCompatible S δ q

/-- A finite nonempty implicit direction net `N` of unit vectors in `ℝ^{d_s}` (fixed prior to a
generation's fresh random coins and used only in the analysis) with logarithmic cardinality
`log |N| ≤ netLogBound`. -/
def IsValidImplicitDirectionNet {d_s : ℕ}
    (N : Finset (EuclideanSpace ℝ (Fin d_s))) (netLogBound : ℝ) : Prop :=
  N.Nonempty ∧
  (∀ z ∈ N, IsUnitVec z) ∧
  0 ≤ netLogBound ∧
  Real.log (N.card : ℝ) ≤ netLogBound

/-- Padded data unit direction `(A_pad • u, B_pad) ∈ ℝ^{d+1}` from `u ∈ ℝ^d` (Sec. 5.4 / Sec. C.3). -/
noncomputable def padDataDirection {d : ℕ} (A_pad B_pad : ℝ)
    (u : EuclideanSpace ℝ (Fin d)) : EuclideanSpace ℝ (Fin (d + 1)) :=
  WithLp.toLp 2 (Fin.snoc (WithLp.ofLp (A_pad • u)) B_pad)

/-- Padded query unit direction `(A_pad • z, -B_pad) ∈ ℝ^{d+1}` from `z ∈ ℝ^d` (Sec. 5.4 / Sec. C.3). -/
noncomputable def padQueryDirection {d : ℕ} (A_pad B_pad : ℝ)
    (z : EuclideanSpace ℝ (Fin d)) : EuclideanSpace ℝ (Fin (d + 1)) :=
  WithLp.toLp 2 (Fin.snoc (WithLp.ofLp (A_pad • z)) (-B_pad))

/-- Padded-net query coverage from original unit directions in `ℝ^d` to a finite implicit net `N`
in `ℝ^{d+1}` for `gen : SearchGeneration ι (d + 1)`: data points in `gen.P₀` are padded as
`(A_pad • origPts i, B_pad)` with `A_pad > 0`, `B_pad ≥ 0`, `A_pad^2 + B_pad^2 = 1`, and every
original unit query direction `z_orig ∈ ℝ^d` rounds before padding to some unit direction
`z_hat ∈ ℝ^d` with `z_pad = (A_pad • z_hat, -B_pad) ∈ N` such that for every surviving subset
`S ⊆ gen.P₀` and exact acceptance predicate `accept : ι → Prop` rejecting only points with
`⟪origPts i, z_orig⟫ ≤ b`, the padded query `(z_pad, accept)` is `δ`-compatible on `S` and covers
every original target satisfying `⟪origPts i, z_orig⟫ ≥ a`. -/
def HasPaddedNetQueryCoverage {ι : Type*} {d : ℕ}
    (gen : SearchGeneration ι (d + 1))
    (origPts : ι → EuclideanSpace ℝ (Fin d))
    (a b A_pad B_pad δ : ℝ)
    (N : Finset (EuclideanSpace ℝ (Fin (d + 1)))) : Prop :=
  0 < A_pad ∧ 0 ≤ B_pad ∧ A_pad ^ 2 + B_pad ^ 2 = 1 ∧
  (∀ i ∈ gen.P₀, IsUnitVec (origPts i) ∧ gen.pts i = padDataDirection A_pad B_pad (origPts i)) ∧
  (∀ z ∈ N, IsUnitVec z) ∧
  (∀ z_orig : EuclideanSpace ℝ (Fin d), IsUnitVec z_orig →
    ∃ (z_hat : EuclideanSpace ℝ (Fin d))
      (hz_pad : IsUnitVec (padQueryDirection A_pad B_pad z_hat)),
      IsUnitVec z_hat ∧
      padQueryDirection A_pad B_pad z_hat ∈ N ∧
      ∀ (S : Finset ι) (accept : ι → Prop),
        gen.IsSurvivingSubset S →
        (∀ i ∈ S, ¬ accept i → inner ℝ (origPts i) z_orig ≤ b) →
          let q_pad : SearchQuery ι (d + 1) :=
            { z := padQueryDirection A_pad B_pad z_hat, unit_z := hz_pad, accept := accept }
          IsCertifiedCompatible gen δ S q_pad ∧
          (∀ i ∈ S, a ≤ inner ℝ (origPts i) z_orig → gen.IsTarget S q_pad i))

/-- General net query-coverage specification for a finite implicit net `N` on
`gen : SearchGeneration ι d_s` at compatibility margin `δ`: maps each actual query `aq : ActualQuery`
to a rounded/padded search query `toNetQuery aq` with direction in `N` and identical exact
acceptance predicate, preserving compatibility and target existence on every surviving subset
`S ⊆ gen.P₀`. -/
structure NetQueryCoverageSpec {ι : Type*} {d_s : ℕ}
    (gen : SearchGeneration ι d_s) (δ : ℝ)
    (N : Finset (EuclideanSpace ℝ (Fin d_s))) (ActualQuery : Type*) where
  isCompatibleActual : Finset ι → ActualQuery → Prop
  hasActualTarget : Finset ι → ActualQuery → Prop
  actualAccept : ActualQuery → ι → Prop
  toNetQuery : ActualQuery → SearchQuery ι d_s
  maps_into_net : ∀ aq : ActualQuery, (toNetQuery aq).z ∈ N
  preserves_accept : ∀ aq : ActualQuery, (toNetQuery aq).accept = actualAccept aq
  preserves_compatible :
    ∀ S : Finset ι, gen.IsSurvivingSubset S →
      ∀ aq : ActualQuery, isCompatibleActual S aq →
        IsCertifiedCompatible gen δ S (toNetQuery aq)
  covers_targets :
    ∀ S : Finset ι, gen.IsSurvivingSubset S →
      ∀ aq : ActualQuery, isCompatibleActual S aq →
        hasActualTarget S aq → gen.HasTarget S (toNetQuery aq)

/-! ### 2. Certified deletion-only search generation and birth-random variables `Z_z` -/

/-- Halting outcome of constructing a certified search generation at birth using fresh random bits:
produces the immutable birth state `birthState`, initial accepted inverse phase `initPhase` on the
full birth pool `P₀`, construction work `work`, and peak space `peakSpace`. -/
structure CertifiedBirthOutcome (BirthState PhaseState : Type*) where
  birthState : BirthState
  initPhase : PhaseState
  work : ℕ
  peakSpace : ℕ

/-- Halting outcome of deleting an active birth identity from a certified search generation (including
any internal inverse-phase rebuild and certification retries triggered by that deletion). -/
structure CertifiedDeleteOutcome (PhaseState : Type*) where
  nextPhase : PhaseState
  work : ℕ
  peakSpace : ℕ

/-- Deterministic outcome of executing a certified search query on a surviving subset and accepted
inverse phase: returned answer (`some i` or `none` for `NONE`), search work `work`, and peak space
`peakSpace`. -/
structure CertifiedQueryOutcome (ι : Type*) where
  answer : Option ι
  work : ℕ
  peakSpace : ℕ

/-- Outcome of running a certified search query under a deterministic work budget `cap`: either
completes within `cap` work (`completedAnswer = some ans`, `work ≤ cap`) or aborts at budget `cap`
(`completedAnswer = none`, `work = cap`). -/
structure CappedCertifiedQueryOutcome (ι : Type*) where
  completedAnswer : Option (Option ι)
  work : ℕ
  peakSpace : ℕ

/-- Abstract operational bundle of a certified deletion-only angular search generation constructed on
a fixed birth pool `gen : SearchGeneration ι d_s` (after conditioning on an execution history in
`ExecutionHistory d` at birth), with compatibility margin `δ ≥ 0`, prefix-free fresh-coin
construction and deletion/phase-rebuild transitions, deterministic query execution, and birth-level
query-label and per-birth-point incidence cost components. -/
structure CertifiedSearchGeneration (ι : Type*) (d d_s : ℕ)
    (BirthState PhaseState : Type*) where
  gen : SearchGeneration ι d_s
  δ : ℝ
  IsAcceptedBirth : ExecutionHistory d → BirthState → Prop
  IsAcceptedPhase : ExecutionHistory d → BirthState → Finset ι → PhaseState → Prop
  buildWithBits :
    ExecutionHistory d → List Bool → Option (CertifiedBirthOutcome BirthState PhaseState)
  deleteWithBits :
    ExecutionHistory d → BirthState → Finset ι → PhaseState → ι → List Bool →
      Option (CertifiedDeleteOutcome PhaseState)
  runQuery :
    BirthState → Finset ι → PhaseState → SearchQuery ι d_s → CertifiedQueryOutcome ι
  queryLabelCost : BirthState → EuclideanSpace ℝ (Fin d_s) → ℝ
  birthPointIncidenceCost : BirthState → EuclideanSpace ℝ (Fin d_s) → ι → ℝ

/-- Run `inst.runQuery bState S ph q` under deterministic work budget `cap : ℕ` (completing with
`some qOut.answer` when `qOut.work ≤ cap`, and aborting at work `cap` otherwise). -/
def CertifiedSearchGeneration.runQueryCapped
    {ι : Type*} {d d_s : ℕ} {BirthState PhaseState : Type*}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState) (S : Finset ι) (ph : PhaseState)
    (q : SearchQuery ι d_s) (cap : ℕ) : CappedCertifiedQueryOutcome ι :=
  let qOut := inst.runQuery bState S ph q
  if qOut.work ≤ cap then
    { completedAnswer := some qOut.answer, work := qOut.work, peakSpace := qOut.peakSpace }
  else
    { completedAnswer := none, work := cap, peakSpace := qOut.peakSpace }

/-- Whole-birth-pool rejected-incidence work component of `Z_z` at birth: sums the birth incidence
weights `birthPointIncidenceCost` over all birth points `i ∈ P₀` satisfying `⟪pts i, z⟫ ≤ -δ`,
independently of any later surviving subset `S ⊆ P₀`, acceptance predicate, or inverse phase. -/
noncomputable def CertifiedSearchGeneration.rejectedBirthPoolIncidenceCost
    {ι : Type*} {d d_s : ℕ} {BirthState PhaseState : Type*}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState) (z : EuclideanSpace ℝ (Fin d_s)) : ℝ :=
  open Classical in
  ∑ i ∈ inst.gen.P₀.filter (fun i => inner ℝ (inst.gen.pts i) z ≤ -inst.δ),
    inst.birthPointIncidenceCost bState z i

/-- The birth-random variable `Z_z` determined at generation birth (`bState`) for direction `z`:
counts query-label/routing cost plus rejected-incidence cost against the entire birth pool `P₀`,
independent of any later choice of surviving subset `S ⊆ P₀`, compatible exact predicate, or
accepted inverse phase. -/
noncomputable def CertifiedSearchGeneration.birthVar
    {ι : Type*} {d d_s : ℕ} {BirthState PhaseState : Type*}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState) (z : EuclideanSpace ℝ (Fin d_s)) : ℝ :=
  inst.queryLabelCost bState z + inst.rejectedBirthPoolIncidenceCost bState z

/-- Conditional probability (given `birthHist` at birth) that generation construction halts over
fresh fair coin flips `bs : List Bool`. -/
noncomputable def CertifiedSearchGeneration.birthHaltProb
    {ι : Type*} {d d_s : ℕ} {BirthState PhaseState : Type*}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (birthHist : ExecutionHistory d) : ENNReal :=
  ∑' bs : List Bool,
    if (inst.buildWithBits birthHist bs).isSome then bitListProb bs else 0

/-- Conditional probability (given `stepHist`) that deleting `i ∈ S` (including any internal
inverse-phase rebuild) halts over fresh fair coin flips `bs : List Bool`. -/
noncomputable def CertifiedSearchGeneration.deleteHaltProb
    {ι : Type*} {d d_s : ℕ} {BirthState PhaseState : Type*}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (stepHist : ExecutionHistory d) (bState : BirthState)
    (S : Finset ι) (ph : PhaseState) (i : ι) : ENNReal :=
  ∑' bs : List Bool,
    if (inst.deleteWithBits stepHist bState S ph i bs).isSome then bitListProb bs else 0

/-- Conditional expectation `E[Z_z | birthHist]` of the birth-random variable `Z_z` over the
generation's fresh birth coins `bs : List Bool` after conditioning on `birthHist`. -/
noncomputable def CertifiedSearchGeneration.birthVarExpected
    {ι : Type*} {d d_s : ℕ} {BirthState PhaseState : Type*}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (birthHist : ExecutionHistory d) (z : EuclideanSpace ℝ (Fin d_s)) : ENNReal :=
  ∑' bs : List Bool,
    match inst.buildWithBits birthHist bs with
    | some bOut => bitListProb bs * ENNReal.ofReal (inst.birthVar bOut.birthState z)
    | none => 0

/-! ### 3. Adaptive deletion and internal phase-rebuild trajectories on a birth pool -/

/-- Accumulated state of a certified generation constructed at `birthHist` and subjected to a finite
sequence of adaptive deletions (and internal phase rebuilds) of members of `P₀`. -/
structure CertifiedDeletionState (ι : Type*) (BirthState PhaseState : Type*) where
  birthState : BirthState
  birthCoins : List Bool
  survivingSet : Finset ι
  phaseState : PhaseState
  deletionLog : List (ι × List Bool)
  totalWork : ℕ
  maxSpace : ℕ

/-- An adaptive deletion policy chooses either `none` (stop / no deletion) or `some (stepHist, i)`
(delete surviving identity `i` at external history `stepHist`) as an arbitrary function of the
complete exposed birth state, birth coins, and prior deletion/phase-rebuild history. -/
abbrev CertifiedDeletionAdversary (ι : Type*) (d : ℕ) (BirthState PhaseState : Type*) :=
  CertifiedDeletionState ι BirthState PhaseState → Option (ExecutionHistory d × ι)

/-- Execute a sequence of adaptive deletion steps from `cur` over per-step fresh coin lists: when
`delAdv cur = none`, the step halts consuming `[]` with zero extra work; when
`delAdv cur = some (stepHist, i)` with `i ∈ cur.survivingSet`, it runs `deleteWithBits` on `i`. -/
noncomputable def runCertifiedDeletionStepsFrom
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (delAdv : CertifiedDeletionAdversary ι d BirthState PhaseState)
    (cur : CertifiedDeletionState ι BirthState PhaseState) :
    List (List Bool) → Option (CertifiedDeletionState ι BirthState PhaseState)
  | [] => some cur
  | bs :: rest =>
      match delAdv cur with
      | none =>
          match bs with
          | [] => runCertifiedDeletionStepsFrom inst delAdv cur rest
          | _ :: _ => none
      | some (stepHist, i) =>
          if i ∈ cur.survivingSet then
            match inst.deleteWithBits stepHist cur.birthState cur.survivingSet cur.phaseState i bs with
            | none => none
            | some dOut =>
                let next : CertifiedDeletionState ι BirthState PhaseState :=
                  { birthState := cur.birthState
                    birthCoins := cur.birthCoins
                    survivingSet := cur.survivingSet.erase i
                    phaseState := dOut.nextPhase
                    deletionLog := cur.deletionLog ++ [(i, bs)]
                    totalWork := cur.totalWork + dOut.work
                    maxSpace := max cur.maxSpace dOut.peakSpace }
                runCertifiedDeletionStepsFrom inst delAdv next rest
          else
            none

/-- Run birth construction at `birthHist` with fresh birth coins `bs₀` followed by `k` adaptive
deletion steps with per-step fresh coin lists `delTrace : Fin k → List Bool`. -/
noncomputable def runCertifiedDeletionTrajectory
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (birthHist : ExecutionHistory d)
    (delAdv : CertifiedDeletionAdversary ι d BirthState PhaseState)
    (k : ℕ) (bs₀ : List Bool) (delTrace : Fin k → List Bool) :
    Option (CertifiedDeletionState ι BirthState PhaseState) :=
  match inst.buildWithBits birthHist bs₀ with
  | none => none
  | some bOut =>
      let init : CertifiedDeletionState ι BirthState PhaseState :=
        { birthState := bOut.birthState
          birthCoins := bs₀
          survivingSet := inst.gen.P₀
          phaseState := bOut.initPhase
          deletionLog := []
          totalWork := bOut.work
          maxSpace := bOut.peakSpace }
      runCertifiedDeletionStepsFrom inst delAdv init (List.ofFn delTrace)

/-- Validity of an adaptive deletion policy `delAdv` on `inst` after `birthHist`: every requested
deletion `some (_, i)` on a reachable state deletes a currently surviving member `i ∈ st.survivingSet`. -/
def IsValidCertifiedDeletionAdversary
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (birthHist : ExecutionHistory d)
    (delAdv : CertifiedDeletionAdversary ι d BirthState PhaseState) : Prop :=
  ∀ (k : ℕ) (bs₀ : List Bool) (delTrace : Fin k → List Bool)
    (st : CertifiedDeletionState ι BirthState PhaseState),
    runCertifiedDeletionTrajectory inst birthHist delAdv k bs₀ delTrace = some st →
      ∀ stepHist : ExecutionHistory d, ∀ i : ι,
        delAdv st = some (stepHist, i) → i ∈ st.survivingSet

/-- Conditional expected total work (initial construction plus all deletions and internal phase
rebuilds over `k` adaptive deletion steps) given `birthHist` at birth. -/
noncomputable def CertifiedSearchGeneration.expectedTotalBuildAndRebuildWork
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (birthHist : ExecutionHistory d)
    (delAdv : CertifiedDeletionAdversary ι d BirthState PhaseState) (k : ℕ) : ENNReal :=
  ∑' bs₀ : List Bool, ∑' delTrace : Fin k → List Bool,
    match runCertifiedDeletionTrajectory inst birthHist delAdv k bs₀ delTrace with
    | some out => bitListProb bs₀ * prefixTraceProb delTrace * (out.totalWork : ENNReal)
    | none => 0

/-! ### 4. Certified birth-variable search interface guarantees (Sec. C.3) -/

/-- Certified birth-variable search interface for `inst` on birth pool `P₀` of size `m = inst.gen.m ≤ n`,
conditioned on a specific preceding execution history `birthHist : ExecutionHistory d` at birth and
with respect to a fixed implicit direction net `N` (fixed before the generation's fresh coins):
1. Construction and internal phase rebuilds are prefix-free, terminate almost surely (`= 1`), obey
   deterministic space bound `m^{1 + σ} P_fac`, maintain `IsAcceptedBirth` / `IsAcceptedPhase`, and
   have conditional expected total construction and phase-rebuild work at most `m A_n P_fac` across
   any adaptive deletion sequence on `P₀`;
2. Every returned query answer on any surviving subset `S ⊆ P₀`, any accepted inverse phase, and any
   `δ`-compatible exact acceptance predicate is deterministically valid (`IsCorrectAnswer`, zero
   error) within deterministic space `m^{1 + σ} P_fac`;
3. `N` is a finite unit-vector direction net with `log |N| ≤ netLogBound`, and for each `z ∈ N`,
   `Z_z = inst.birthVar bState z` has nonnegative birth query-label and whole-birth-pool
   rejected-incidence components, satisfies `E[Z_z | birthHist] ≤ A_n P_fac`, and deterministically
   upper-bounds query work on every surviving subset `S ⊆ P₀`, every `δ`-compatible exact predicate
   with direction `z`, and every accepted inverse phase. -/
def SatisfiesCertifiedBirthVarAtHistory
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    (n : ℕ) (σ A_n P_fac netLogBound : ℝ)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (birthHist : ExecutionHistory d)
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState) : Prop :=
  inst.gen.m ≤ n ∧
  0 ≤ σ ∧ 0 ≤ inst.δ ∧ 0 ≤ A_n ∧ 0 ≤ P_fac ∧
  IsValidImplicitDirectionNet N netLogBound ∧
  -- (1a) Prefix-free fresh coin consumption and almost-sure termination of birth construction
  (∀ bs₁ bs₂ : List Bool, ∀ out₁ out₂,
    inst.buildWithBits birthHist bs₁ = some out₁ →
    inst.buildWithBits birthHist bs₂ = some out₂ →
    bs₁ <+: bs₂ → bs₁ = bs₂) ∧
  inst.birthHaltProb birthHist = 1 ∧
  (∀ bs : List Bool, ∀ bOut,
    inst.buildWithBits birthHist bs = some bOut →
      inst.IsAcceptedBirth birthHist bOut.birthState ∧
      inst.IsAcceptedPhase birthHist bOut.birthState inst.gen.P₀ bOut.initPhase ∧
      (bOut.peakSpace : ℝ) ≤ (inst.gen.m : ℝ) ^ (1 + σ) * P_fac) ∧
  -- (1b) Prefix-free fresh coin consumption, almost-sure termination, and deterministic space of
  -- deletions and internal inverse-phase rebuilds
  (∀ (stepHist : ExecutionHistory d) (bState : BirthState) (S : Finset ι)
     (ph : PhaseState) (i : ι),
    inst.IsAcceptedBirth birthHist bState →
    inst.gen.IsSurvivingSubset S →
    inst.IsAcceptedPhase birthHist bState S ph →
    i ∈ S →
      (∀ bs₁ bs₂ : List Bool, ∀ out₁ out₂,
        inst.deleteWithBits stepHist bState S ph i bs₁ = some out₁ →
        inst.deleteWithBits stepHist bState S ph i bs₂ = some out₂ →
        bs₁ <+: bs₂ → bs₁ = bs₂) ∧
      inst.deleteHaltProb stepHist bState S ph i = 1 ∧
      (∀ bs : List Bool, ∀ dOut,
        inst.deleteWithBits stepHist bState S ph i bs = some dOut →
          inst.IsAcceptedPhase birthHist bState (S.erase i) dOut.nextPhase ∧
          (dOut.peakSpace : ℝ) ≤ (inst.gen.m : ℝ) ^ (1 + σ) * P_fac)) ∧
  -- (1c) Conditional expected total work of construction and internal phase rebuilds ≤ m A(n) P
  (∀ delAdv : CertifiedDeletionAdversary ι d BirthState PhaseState,
    IsValidCertifiedDeletionAdversary inst birthHist delAdv →
      ∀ k : ℕ,
        inst.expectedTotalBuildAndRebuildWork birthHist delAdv k ≠ ⊤ ∧
        (inst.expectedTotalBuildAndRebuildWork birthHist delAdv k).toReal ≤
          (inst.gen.m : ℝ) * A_n * P_fac) ∧
  -- (2) Deterministic always-correct (zero-error) query answers and deterministic query space cap
  (∀ (bState : BirthState) (S : Finset ι) (ph : PhaseState) (q : SearchQuery ι d_s),
    inst.IsAcceptedBirth birthHist bState →
    inst.gen.IsSurvivingSubset S →
    inst.IsAcceptedPhase birthHist bState S ph →
    IsCertifiedCompatible inst.gen inst.δ S q →
      let qOut := inst.runQuery bState S ph q
      inst.gen.IsCorrectAnswer S q qOut.answer ∧
      (qOut.peakSpace : ℝ) ≤ (inst.gen.m : ℝ) ^ (1 + σ) * P_fac) ∧
  -- (3) Nonnegative birth-random variables (Z_z)_{z ∈ N} with conditional expectation ≤ A(n) P
  -- deterministically upper-bounding query work across all subsets, compatible predicates, and phases
  (∀ (bState : BirthState) (z : EuclideanSpace ℝ (Fin d_s)),
    inst.IsAcceptedBirth birthHist bState → z ∈ N →
      0 ≤ inst.queryLabelCost bState z ∧
      (∀ i ∈ inst.gen.P₀, 0 ≤ inst.birthPointIncidenceCost bState z i)) ∧
  (∀ z ∈ N,
    inst.birthVarExpected birthHist z ≠ ⊤ ∧
    (inst.birthVarExpected birthHist z).toReal ≤ A_n * P_fac) ∧
  (∀ (bState : BirthState) (S : Finset ι) (ph : PhaseState) (q : SearchQuery ι d_s),
    inst.IsAcceptedBirth birthHist bState →
    inst.gen.IsSurvivingSubset S →
    inst.IsAcceptedPhase birthHist bState S ph →
    IsCertifiedCompatible inst.gen inst.δ S q →
    q.z ∈ N →
      ((inst.runQuery bState S ph q).work : ℝ) ≤ inst.birthVar bState q.z)

/-- Uniform history-conditioned certified birth-variable search interface on a fixed implicit
direction net `N`: `SatisfiesCertifiedBirthVarAtHistory` holds after conditioning on every preceding
execution history `birthHist : ExecutionHistory d`. -/
def SatisfiesCertifiedBirthVarOnNet
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    (n : ℕ) (σ A_n P_fac netLogBound : ℝ)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState) : Prop :=
  ∀ birthHist : ExecutionHistory d,
    SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N birthHist inst

/-- Complete certified birth-variable search interface for `inst` covering a query family
`ActualQuery` at `birthHist`: there exists a finite implicit direction net `N` (fixed before the
generation's fresh random coins, with `log |N| ≤ netLogBound` and query coverage `cov` for
`ActualQuery`) such that `SatisfiesCertifiedBirthVarAtHistory` holds on `N`. -/
def SatisfiesCertifiedBirthVarInterface
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    {ActualQuery : Type*}
    (n : ℕ) (σ A_n P_fac netLogBound : ℝ)
    (birthHist : ExecutionHistory d)
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (isCompatibleActual : Finset ι → ActualQuery → Prop)
    (hasActualTarget : Finset ι → ActualQuery → Prop)
    (actualAccept : ActualQuery → ι → Prop)
    (toNetQuery : ActualQuery → SearchQuery ι d_s) : Prop :=
  ∃ N : Finset (EuclideanSpace ℝ (Fin d_s)),
    SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N birthHist inst ∧
    ∃ cov : NetQueryCoverageSpec inst.gen inst.δ N ActualQuery,
      cov.isCompatibleActual = isCompatibleActual ∧
      cov.hasActualTarget = hasActualTarget ∧
      cov.actualAccept = actualAccept ∧
      cov.toNetQuery = toNetQuery

/-- Complete padded-net certified birth-variable search interface for original unit points in `ℝ^d`
embedded into `ℝ^{d+1}` (`d_s = d + 1`) at `birthHist`: there exists a finite implicit direction net
`N ⊆ ℝ^{d+1}` (fixed before the generation's fresh random coins) with `log |N| ≤ netLogBound`,
padded-net query coverage `HasPaddedNetQueryCoverage`, and `SatisfiesCertifiedBirthVarAtHistory`. -/
def SatisfiesPaddedCertifiedBirthVarInterface
    {ι : Type*} [DecidableEq ι] {d : ℕ} {BirthState PhaseState : Type*}
    (n : ℕ) (σ A_n P_fac netLogBound : ℝ)
    (origPts : ι → EuclideanSpace ℝ (Fin d))
    (a b A_pad B_pad : ℝ)
    (birthHist : ExecutionHistory d)
    (inst : CertifiedSearchGeneration ι d (d + 1) BirthState PhaseState) : Prop :=
  ∃ N : Finset (EuclideanSpace ℝ (Fin (d + 1))),
    HasPaddedNetQueryCoverage inst.gen origPts a b A_pad B_pad inst.δ N ∧
    SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N birthHist inst

/-- Specialization of `SatisfiesCertifiedBirthVarAtHistory` at standard zero-margin compatibility
(`inst.δ = 0`, where `IsCertifiedCompatible` coincides with `SearchGeneration.IsCompatible`). -/
def SatisfiesZeroMarginCertifiedBirthVarAtHistory
    {ι : Type*} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type*}
    (n : ℕ) (σ A_n P_fac netLogBound : ℝ)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (birthHist : ExecutionHistory d)
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState) : Prop :=
  inst.δ = 0 ∧ SatisfiesCertifiedBirthVarAtHistory n σ A_n P_fac netLogBound N birthHist inst

end UL
