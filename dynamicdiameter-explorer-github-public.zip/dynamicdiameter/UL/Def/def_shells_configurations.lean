import Mathlib
import UL.Def.def_local_scale_params
set_option autoImplicit false

/-! Definition (Sec. 5.2: Radial shells, inward rounding, configurations, and correlation thresholds) (paper p.18). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- Base core shell subdivision count `m_0 = ⌈1 / e⌉ ∈ ℕ` for rational rounding parameter `e ∈ ℚ`
(when `e > 0`, `m_0 ≥ 1` and `1 / m_0 ≤ e`). -/
def shellSubdiv (e : ℚ) : ℕ :=
  Nat.ceil (1 / e)

/-- Maximum eligible shell index `K m_0 ∈ ℕ` for subdivision count `m_0 : ℕ` and integer scale
cutoff `K : ℤ` (for `K ≥ 0`, `(maxShellIndex m0 K : ℤ) = K * (m0 : ℤ)`). -/
def maxShellIndex (m0 : ℕ) (K : ℤ) : ℕ :=
  K.toNat * m0

/-- Fixed radial shell radius `r_j = (j / m_0) √V` for shell index `j : ℕ`, subdivision count
`m_0 : ℕ`, and variance `V : ℝ` (used for `0 ≤ j ≤ K m_0`). -/
noncomputable def shellRadius (m0 : ℕ) (V : ℝ) (j : ℕ) : ℝ :=
  ((j : ℝ) / (m0 : ℝ)) * Real.sqrt V

/-- Eligibility condition `‖p - o‖ ≤ K √V` for a point `p ∈ ℝ^d` at node `(o, V)` with integer
scale cutoff `K : ℤ`. -/
def IsEligiblePoint {d : ℕ} (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ)
    (p : EuclideanSpace ℝ (Fin d)) : Prop :=
  ‖p - o‖ ≤ (K : ℝ) * Real.sqrt V

open Classical in
/-- Subset of eligible identities `{i ∈ S : ‖pts i - o‖ ≤ K √V}` in a finite indexed input set
`S : Finset ι` (with point coordinates `pts : ι → ℝ^d`) at node `(o, V)`. -/
noncomputable def nodeEligible {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ)
    (S : Finset ι) : Finset ι :=
  S.filter (fun i => IsEligiblePoint o V K (pts i))

/-- Subset of eligible points `{p ∈ S : ‖p - o‖ ≤ K √V}` in a finite point set `S ⊆ ℝ^d`. -/
noncomputable def pointNodeEligible {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ)
    (S : Finset (EuclideanSpace ℝ (Fin d))) : Finset (EuclideanSpace ℝ (Fin d)) :=
  nodeEligible id o V K S

/-- Radial shell number `j = ⌊m_0 ‖p - o‖ / √V⌋₊ ∈ ℕ` of a point `p ∈ ℝ^d` relative to center `o`,
variance `V`, and subdivision count `m_0`. When `V > 0` and `m_0 ≥ 1`, this is the largest integer
`j ≥ 0` with `r_j ≤ ‖p - o‖` (lying in `{0, …, K m_0}` for eligible `p` and in `{0, …, m_0}` for
`p ∈ B(o, √V)`). -/
noncomputable def shellIndex {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (p : EuclideanSpace ℝ (Fin d)) : ℕ :=
  Nat.floor ((m0 : ℝ) * ‖p - o‖ / Real.sqrt V)

/-- Exact squared-norm shell lower bound `j^2 V ≤ m_0^2 ‖p - o‖^2` (equivalent to `r_j ≤ ‖p - o‖`
when `V > 0` and `m_0 ≥ 1`). -/
def ShellRadiusLeSq {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (j : ℕ) (p : EuclideanSpace ℝ (Fin d)) : Prop :=
  (j : ℝ) ^ 2 * V ≤ (m0 : ℝ) ^ 2 * ‖p - o‖ ^ 2

/-- Exact squared-norm characterization `j^2 V ≤ m_0^2 ‖p - o‖^2 < (j + 1)^2 V` determining
membership in radial shell `j` without square roots (equivalent to `shellIndex m0 o V p = j` when
`V > 0` and `m_0 ≥ 1`). -/
def InShellBySqCmp {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (j : ℕ) (p : EuclideanSpace ℝ (Fin d)) : Prop :=
  (j : ℝ) ^ 2 * V ≤ (m0 : ℝ) ^ 2 * ‖p - o‖ ^ 2 ∧
  (m0 : ℝ) ^ 2 * ‖p - o‖ ^ 2 < ((j + 1 : ℕ) : ℝ) ^ 2 * V

/-- Unit radial direction `u_p = (p - o) / ‖p - o‖` for `p ≠ o` in `ℝ^d` (equal to `0` when
`p = o`). -/
noncomputable def radialDirection {d : ℕ}
    (o p : EuclideanSpace ℝ (Fin d)) : EuclideanSpace ℝ (Fin d) :=
  (‖p - o‖)⁻¹ • (p - o)

/-- Directional correlation `⟨-u_x, u_y⟩` between radial directions from center `o` to `x` and `y`,
appearing in `‖x̃ - ỹ‖^2 = r_j^2 + r_k^2 + 2 r_j r_k ⟨-u_x, u_y⟩` for `j, k ≥ 1`. -/
noncomputable def radialCorrelation {d : ℕ}
    (o x y : EuclideanSpace ℝ (Fin d)) : ℝ :=
  inner ℝ (-radialDirection o x) (radialDirection o y)

/-- Inward-rounded point `p̃` of `p ∈ ℝ^d` relative to center `o`, variance `V`, and subdivision
count `m_0`: rounds `p` inward along `u_p` to radius `r_j` where `j = shellIndex m0 o V p` (equal
to `o` when `j = 0` since `r_0 = 0`, and `o + r_j u_p` when `j ≥ 1`). -/
noncomputable def inwardRound {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (p : EuclideanSpace ℝ (Fin d)) :
    EuclideanSpace ℝ (Fin d) :=
  o + shellRadius m0 V (shellIndex m0 o V p) • radialDirection o p

/-- Distance scale `R_ℓ = λ^ℓ √V / 2` for scale index `ℓ : ℕ`, rational ratio `λ : ℚ`, and
variance `V : ℝ`. -/
noncomputable def distScale (lam : ℚ) (V : ℝ) (ℓ : ℕ) : ℝ :=
  (lam : ℝ) ^ ℓ * Real.sqrt V / 2

/-- First (minimal) scale index `J ∈ ℕ` satisfying `λ^J / 2 ≥ K + 1` (for `λ > 1`, the set of
such indices is nonempty, so `sInf` is the minimum `ℓ : ℕ` with `(K : ℝ) + 1 ≤ (lam : ℝ)^ℓ / 2`). -/
noncomputable def scaleCutoffIndex (lam : ℚ) (K : ℤ) : ℕ :=
  sInf {ℓ : ℕ | (K : ℝ) + 1 ≤ (lam : ℝ) ^ ℓ / 2}

/-- A configuration triple `(j, k, ℓ)` consisting of a core shell index `j : ℕ`, an input shell
index `k : ℕ`, and a distance scale index `ℓ : ℕ`. -/
@[ext]
structure ShellConfig where
  j : ℕ
  k : ℕ
  ℓ : ℕ
  deriving DecidableEq, Repr

/-- Predicate that `(j, k, ℓ)` is a valid configuration triple of a positive core shell
(`1 ≤ j ≤ m_0`), a positive input shell (`1 ≤ k ≤ K m_0`), and a distance scale (`0 ≤ ℓ ≤ J`). -/
def IsShellConfig (m0 : ℕ) (K : ℤ) (J : ℕ) (j k ℓ : ℕ) : Prop :=
  1 ≤ j ∧ j ≤ m0 ∧ 1 ≤ k ∧ (k : ℤ) ≤ K * (m0 : ℤ) ∧ ℓ ≤ J

/-- Retention condition (4) for a configuration `(j, k, ℓ)`: `r_j^2 + r_k^2 ≤ R_ℓ^2` and
`γ R_ℓ ≤ r_j + r_k`. -/
def SatisfiesRetentionCond (m0 : ℕ) (γ lam : ℚ) (V : ℝ) (j k ℓ : ℕ) : Prop :=
  shellRadius m0 V j ^ 2 + shellRadius m0 V k ^ 2 ≤ distScale lam V ℓ ^ 2 ∧
  (γ : ℝ) * distScale lam V ℓ ≤ shellRadius m0 V j + shellRadius m0 V k

/-- Predicate that `(j, k, ℓ)` is a retained configuration for parameters `(e, γ, λ, K)` at
variance `V`: a valid configuration (`1 ≤ j ≤ m_0`, `1 ≤ k ≤ K m_0`, `0 ≤ ℓ ≤ J` with
`m_0 = ⌈1/e⌉` and minimal `J` with `λ^J / 2 ≥ K + 1`) satisfying `r_j^2 + r_k^2 ≤ R_ℓ^2` and
`γ R_ℓ ≤ r_j + r_k`. -/
def IsRetainedConfig (e γ lam : ℚ) (K : ℤ) (V : ℝ) (j k ℓ : ℕ) : Prop :=
  IsShellConfig (shellSubdiv e) K (scaleCutoffIndex lam K) j k ℓ ∧
  SatisfiesRetentionCond (shellSubdiv e) γ lam V j k ℓ

/-- Predicate that `cfg : ShellConfig` is a valid configuration (`1 ≤ j ≤ m_0`, `1 ≤ k ≤ K m_0`,
`0 ≤ ℓ ≤ J`). -/
def ShellConfig.IsValid (m0 : ℕ) (K : ℤ) (J : ℕ) (cfg : ShellConfig) : Prop :=
  IsShellConfig m0 K J cfg.j cfg.k cfg.ℓ

/-- Predicate that `cfg : ShellConfig` satisfies retention condition (4). -/
def ShellConfig.SatisfiesRetention (m0 : ℕ) (γ lam : ℚ) (V : ℝ) (cfg : ShellConfig) : Prop :=
  SatisfiesRetentionCond m0 γ lam V cfg.j cfg.k cfg.ℓ

/-- Predicate that `cfg : ShellConfig` is a retained configuration for `(e, γ, λ, K)` at `V`. -/
def ShellConfig.IsRetained (e γ lam : ℚ) (K : ℤ) (V : ℝ) (cfg : ShellConfig) : Prop :=
  IsRetainedConfig e γ lam K V cfg.j cfg.k cfg.ℓ

/-- Finite set of all configuration triples `(j, k, ℓ)` with `1 ≤ j ≤ m_0`, `1 ≤ k ≤ K m_0`, and
`0 ≤ ℓ ≤ J`. -/
def allShellConfigTriples (m0 : ℕ) (K : ℤ) (J : ℕ) : Finset (ℕ × ℕ × ℕ) :=
  (Finset.Icc 1 m0) ×ˢ ((Finset.Icc 1 (maxShellIndex m0 K)) ×ˢ (Finset.Icc 0 J))

/-- Finite set of all `ShellConfig` structures with `1 ≤ j ≤ m_0`, `1 ≤ k ≤ K m_0`, and
`0 ≤ ℓ ≤ J`. -/
def allShellConfigs (m0 : ℕ) (K : ℤ) (J : ℕ) : Finset ShellConfig :=
  (allShellConfigTriples m0 K J).map
    ⟨fun t => ⟨t.1, t.2.1, t.2.2⟩, fun a b h => by
      cases a with | mk a1 a2 => cases a2 with | mk a2 a3 =>
      cases b with | mk b1 b2 => cases b2 with | mk b2 b3 =>
      cases h; rfl⟩

open Classical in
/-- Finite set of retained configuration triples `(j, k, ℓ)` for parameters `(e, γ, λ, K)` at
variance `V`. -/
noncomputable def retainedConfigTriples (e γ lam : ℚ) (K : ℤ) (V : ℝ) : Finset (ℕ × ℕ × ℕ) :=
  (allShellConfigTriples (shellSubdiv e) K (scaleCutoffIndex lam K)).filter
    (fun t => SatisfiesRetentionCond (shellSubdiv e) γ lam V t.1 t.2.1 t.2.2)

open Classical in
/-- Finite set of retained `ShellConfig` structures for parameters `(e, γ, λ, K)` at variance `V`. -/
noncomputable def retainedConfigs (e γ lam : ℚ) (K : ℤ) (V : ℝ) : Finset ShellConfig :=
  (allShellConfigs (shellSubdiv e) K (scaleCutoffIndex lam K)).filter
    (ShellConfig.SatisfiesRetention (shellSubdiv e) γ lam V)

open Classical in
/-- Subset of identities in `A : Finset ι` whose coordinates `pts i` lie in radial shell `j`. -/
noncomputable def shellSubset {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (j : ℕ) (A : Finset ι) : Finset ι :=
  A.filter (fun i => shellIndex m0 o V (pts i) = j)

/-- Active left vertex set `V_L` of a configuration in shell `j` on indexed input set `S : Finset ι`
at node `(o, V)`: the core identities `C = S ∩ B(o, √V)` lying in shell `j`. -/
noncomputable def configLeftVertices {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) (j : ℕ) : Finset ι :=
  shellSubset pts m0 o V j (nodeCore pts o V S)

/-- Active right vertex set `V_R` of a configuration in shell `k` on indexed input set `S : Finset ι`
at node `(o, V)` with cutoff `K`: the eligible input identities in `S` lying in shell `k`. -/
noncomputable def configRightVertices {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ) (S : Finset ι) (k : ℕ) : Finset ι :=
  shellSubset pts m0 o V k (nodeEligible pts o V K S)

/-- Active left vertex set `V_L` (core points in shell `j`) on a point set `S ⊆ ℝ^d`. -/
noncomputable def pointConfigLeftVertices {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset (EuclideanSpace ℝ (Fin d))) (j : ℕ) : Finset (EuclideanSpace ℝ (Fin d)) :=
  configLeftVertices id m0 o V S j

/-- Active right vertex set `V_R` (eligible input points in shell `k`) on a point set `S ⊆ ℝ^d`. -/
noncomputable def pointConfigRightVertices {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ)
    (S : Finset (EuclideanSpace ℝ (Fin d))) (k : ℕ) : Finset (EuclideanSpace ℝ (Fin d)) :=
  configRightVertices id m0 o V K S k

/-- Weak-edge distance condition `‖x̃ - ỹ‖ > R_ℓ` between rounded points `x̃` and `ỹ` at scale `ℓ`
(note `x = y` gives `‖x̃ - ỹ‖ = 0`, which is never `> R_ℓ` when `V > 0` and `λ > 0`). -/
def IsWeakRoundedPair {d : ℕ} (m0 : ℕ) (lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (ℓ : ℕ)
    (x y : EuclideanSpace ℝ (Fin d)) : Prop :=
  distScale lam V ℓ < ‖inwardRound m0 o V x - inwardRound m0 o V y‖

/-- Strong-edge distance condition `‖x̃ - ỹ‖ > γ R_ℓ` between rounded points `x̃` and `ỹ` at
scale `ℓ` (when `γ > 1` and `V > 0`, every strong edge is also a weak edge). -/
def IsStrongRoundedPair {d : ℕ} (m0 : ℕ) (γ lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (ℓ : ℕ)
    (x y : EuclideanSpace ℝ (Fin d)) : Prop :=
  (γ : ℝ) * distScale lam V ℓ < ‖inwardRound m0 o V x - inwardRound m0 o V y‖

open Classical in
/-- Bipartite weak edge set `E_weak = {(x, y) ∈ V_L × V_R : ‖x̃ - ỹ‖ > R_ℓ}` between active left
and right vertex sets `V_L, V_R : Finset ι`. -/
noncomputable def weakEdgesOn {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ) (lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (ℓ : ℕ)
    (V_L V_R : Finset ι) : Finset (ι × ι) :=
  (V_L ×ˢ V_R).filter (fun xy => IsWeakRoundedPair m0 lam o V ℓ (pts xy.1) (pts xy.2))

open Classical in
/-- Bipartite strong edge set `E_strong = {(x, y) ∈ V_L × V_R : ‖x̃ - ỹ‖ > γ R_ℓ}` between active
left and right vertex sets `V_L, V_R : Finset ι`. -/
noncomputable def strongEdgesOn {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ) (γ lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (ℓ : ℕ)
    (V_L V_R : Finset ι) : Finset (ι × ι) :=
  (V_L ×ˢ V_R).filter (fun xy => IsStrongRoundedPair m0 γ lam o V ℓ (pts xy.1) (pts xy.2))

/-- Bipartite weak edge set `E_weak` of configuration `(j, k, ℓ)` on indexed input set `S : Finset ι`
at node `(o, V)` with cutoff `K`. -/
noncomputable def configWeakEdges {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ) (lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ) (S : Finset ι)
    (j k ℓ : ℕ) : Finset (ι × ι) :=
  weakEdgesOn pts m0 lam o V ℓ
    (configLeftVertices pts m0 o V S j)
    (configRightVertices pts m0 o V K S k)

/-- Bipartite strong edge set `E_strong` of configuration `(j, k, ℓ)` on indexed input set
`S : Finset ι` at node `(o, V)` with cutoff `K`. -/
noncomputable def configStrongEdges {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ) (γ lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ) (S : Finset ι)
    (j k ℓ : ℕ) : Finset (ι × ι) :=
  strongEdgesOn pts m0 γ lam o V ℓ
    (configLeftVertices pts m0 o V S j)
    (configRightVertices pts m0 o V K S k)

/-- Bipartite weak edge set `E_weak` of configuration `(j, k, ℓ)` on a point set `S ⊆ ℝ^d`
at node `(o, V)` with cutoff `K`. -/
noncomputable def pointConfigWeakEdges {d : ℕ} (m0 : ℕ) (lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ)
    (S : Finset (EuclideanSpace ℝ (Fin d))) (j k ℓ : ℕ) :
    Finset (EuclideanSpace ℝ (Fin d) × EuclideanSpace ℝ (Fin d)) :=
  configWeakEdges id m0 lam o V K S j k ℓ

/-- Bipartite strong edge set `E_strong` of configuration `(j, k, ℓ)` on a point set `S ⊆ ℝ^d`
at node `(o, V)` with cutoff `K`. -/
noncomputable def pointConfigStrongEdges {d : ℕ} (m0 : ℕ) (γ lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ)
    (S : Finset (EuclideanSpace ℝ (Fin d))) (j k ℓ : ℕ) :
    Finset (EuclideanSpace ℝ (Fin d) × EuclideanSpace ℝ (Fin d)) :=
  configStrongEdges id m0 γ lam o V K S j k ℓ

/-- Strong-edge correlation threshold `a = (γ^2 R_ℓ^2 - r_j^2 - r_k^2) / (2 r_j r_k)` for
configuration `(j, k, ℓ)`. -/
noncomputable def configThresholdA (m0 : ℕ) (γ lam : ℚ) (V : ℝ) (j k ℓ : ℕ) : ℝ :=
  ((γ : ℝ) ^ 2 * distScale lam V ℓ ^ 2 - shellRadius m0 V j ^ 2 - shellRadius m0 V k ^ 2) /
    (2 * shellRadius m0 V j * shellRadius m0 V k)

/-- Weak-edge correlation threshold `b = (R_ℓ^2 - r_j^2 - r_k^2) / (2 r_j r_k)` for
configuration `(j, k, ℓ)`. -/
noncomputable def configThresholdB (m0 : ℕ) (lam : ℚ) (V : ℝ) (j k ℓ : ℕ) : ℝ :=
  (distScale lam V ℓ ^ 2 - shellRadius m0 V j ^ 2 - shellRadius m0 V k ^ 2) /
    (2 * shellRadius m0 V j * shellRadius m0 V k)

/-- Strong-edge correlation threshold `a` of `cfg : ShellConfig`. -/
noncomputable def ShellConfig.thresholdA (m0 : ℕ) (γ lam : ℚ) (V : ℝ) (cfg : ShellConfig) : ℝ :=
  configThresholdA m0 γ lam V cfg.j cfg.k cfg.ℓ

/-- Weak-edge correlation threshold `b` of `cfg : ShellConfig`. -/
noncomputable def ShellConfig.thresholdB (m0 : ℕ) (lam : ℚ) (V : ℝ) (cfg : ShellConfig) : ℝ :=
  configThresholdB m0 lam V cfg.j cfg.k cfg.ℓ

/-- Base core shell subdivision count `m_0 = ⌈1 / e⌉` of a `LocalScaleParams` bundle. -/
def LocalScaleParams.m0 (params : LocalScaleParams) : ℕ :=
  shellSubdiv params.e

/-- Maximum eligible shell index `K m_0` of a `LocalScaleParams` bundle. -/
def LocalScaleParams.maxShellIndex (params : LocalScaleParams) : ℕ :=
  UL.maxShellIndex params.m0 params.K

/-- Scale cutoff index `J` (minimal `ℓ : ℕ` with `λ^ℓ / 2 ≥ K + 1`) of a `LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.J (params : LocalScaleParams) : ℕ :=
  scaleCutoffIndex params.lam params.K

/-- Fixed shell radius `r_j = (j / m_0) √V` for a `LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.shellRadius (params : LocalScaleParams) (V : ℝ) (j : ℕ) : ℝ :=
  UL.shellRadius params.m0 V j

/-- Distance scale `R_ℓ = λ^ℓ √V / 2` for a `LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.distScale (params : LocalScaleParams) (V : ℝ) (ℓ : ℕ) : ℝ :=
  UL.distScale params.lam V ℓ

/-- Point eligibility `‖p - o‖ ≤ K √V` for a `LocalScaleParams` bundle. -/
def LocalScaleParams.IsEligiblePoint {d : ℕ} (params : LocalScaleParams)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (p : EuclideanSpace ℝ (Fin d)) : Prop :=
  UL.IsEligiblePoint o V params.K p

/-- Shell number `shellIndex params.m0 o V p` for a `LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.shellIndex {d : ℕ} (params : LocalScaleParams)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (p : EuclideanSpace ℝ (Fin d)) : ℕ :=
  UL.shellIndex params.m0 o V p

/-- Inward-rounded point `p̃` for a `LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.inwardRound {d : ℕ} (params : LocalScaleParams)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (p : EuclideanSpace ℝ (Fin d)) :
    EuclideanSpace ℝ (Fin d) :=
  UL.inwardRound params.m0 o V p

/-- Retained configuration predicate `(j, k, ℓ)` for a `LocalScaleParams` bundle at variance `V`. -/
def LocalScaleParams.IsRetainedConfig (params : LocalScaleParams) (V : ℝ) (j k ℓ : ℕ) : Prop :=
  UL.IsRetainedConfig params.e params.γ params.lam params.K V j k ℓ

/-- Finite set of retained `ShellConfig` structures for a `LocalScaleParams` bundle at variance `V`. -/
noncomputable def LocalScaleParams.retainedConfigs (params : LocalScaleParams) (V : ℝ) :
    Finset ShellConfig :=
  UL.retainedConfigs params.e params.γ params.lam params.K V

/-- Strong-edge correlation threshold `a` for a `LocalScaleParams` bundle at variance `V`. -/
noncomputable def LocalScaleParams.thresholdA (params : LocalScaleParams) (V : ℝ)
    (j k ℓ : ℕ) : ℝ :=
  configThresholdA params.m0 params.γ params.lam V j k ℓ

/-- Weak-edge correlation threshold `b` for a `LocalScaleParams` bundle at variance `V`. -/
noncomputable def LocalScaleParams.thresholdB (params : LocalScaleParams) (V : ℝ)
    (j k ℓ : ℕ) : ℝ :=
  configThresholdB params.m0 params.lam V j k ℓ

/-- Eligible subset `{i ∈ S : ‖pts i - o‖ ≤ K √V}` for a `LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.nodeEligible {d : ℕ} {ι : Type*} (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) : Finset ι :=
  UL.nodeEligible pts o V params.K S

/-- Active left vertex set `V_L` (core identities in shell `j`) for a `LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.leftVertices {d : ℕ} {ι : Type*} (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) (j : ℕ) : Finset ι :=
  configLeftVertices pts params.m0 o V S j

/-- Active right vertex set `V_R` (eligible input identities in shell `k`) for a
`LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.rightVertices {d : ℕ} {ι : Type*} (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) (k : ℕ) : Finset ι :=
  configRightVertices pts params.m0 o V params.K S k

/-- Bipartite weak edge set `E_weak` of configuration `(j, k, ℓ)` for a `LocalScaleParams` bundle. -/
noncomputable def LocalScaleParams.weakEdges {d : ℕ} {ι : Type*} (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) (j k ℓ : ℕ) : Finset (ι × ι) :=
  configWeakEdges pts params.m0 params.lam o V params.K S j k ℓ

/-- Bipartite strong edge set `E_strong` of configuration `(j, k, ℓ)` for a `LocalScaleParams`
bundle. -/
noncomputable def LocalScaleParams.strongEdges {d : ℕ} {ι : Type*} (params : LocalScaleParams)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) (j k ℓ : ℕ) : Finset (ι × ι) :=
  configStrongEdges pts params.m0 params.γ params.lam o V params.K S j k ℓ

end UL
