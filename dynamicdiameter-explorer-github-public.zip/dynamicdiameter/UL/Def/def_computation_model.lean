import Mathlib
set_option autoImplicit false

/-! Definition (Sec. 3: Arithmetic-RAM and rational bit-length model) (paper p.13–14, Sec. 1.1 p.3).
Defines:
1. Rational point embedding `ℚ^d → EuclideanSpace ℝ (Fin d)` and binary encoding length bounds `B`
   on numerators and denominators;
2. Memory model counting active input, persistent auxiliary structures, simultaneous rebuilds, and
   scoped temporary memory;
3. Concrete finite-word and bit-cost RAM (`BitRAMStmt`), accounting for intermediate number lengths
   (with polynomial-time rational linear programming on lifted coordinates included natively without
   assuming strongly polynomial LP);
4. Certified `k`-bit rational interval approximations `[lo, hi]` of length at most `2^{-k}` for
   fixed parameters independent of `n, d, B`, and directional rounding;
5. Concrete unit-cost Arithmetic-RAM (`ArithRAMStmt`) with unit-cost exact real field operations
   `+, -, *, /`, exact comparisons, word operations, and uniform random bit draws;
6. Suppressed polynomial factor predicates `poly_c(d, L)` (with no hidden power of `n`). -/

namespace UL

/-! ### 1. Coordinates, rational embedding, and binary encoding length `B` -/

/-- Coordinate `i` of a point `x ∈ ℝ^d` (`EuclideanSpace ℝ (Fin d)`). -/
noncomputable def euclideanCoord {d : ℕ} (x : EuclideanSpace ℝ (Fin d)) (i : Fin d) : ℝ :=
  WithLp.equiv 2 (Fin d → ℝ) x i

/-- Canonical embedding of a rational point `x ∈ ℚ^d` (`Fin d → ℚ`) into `EuclideanSpace ℝ (Fin d)`. -/
noncomputable def ratPointToEuclidean {d : ℕ} (x : Fin d → ℚ) : EuclideanSpace ℝ (Fin d) :=
  (WithLp.equiv 2 (Fin d → ℝ)).symm (fun i => (x i : ℝ))

/-- Inverse extraction of rational coordinates if `pt` lies in the image of `ratPointToEuclidean`. -/
noncomputable def euclideanToRatPoint? {d : ℕ} (pt : EuclideanSpace ℝ (Fin d)) :
    Option (Fin d → ℚ) :=
  open Classical in
  if h : ∃ q : Fin d → ℚ, ratPointToEuclidean q = pt then
    some (Classical.choose h)
  else
    none

/-- Binary digit length of a natural number `m` (`1` bit for `0`, and `⌊log₂ m⌋ + 1` bits for `m ≥ 1`). -/
def natBitLength (m : ℕ) : ℕ :=
  Nat.log 2 m + 1

/-- Signed binary encoding length of an integer `z` (`1` bit for `0`, and `1` sign bit plus
`natBitLength z.natAbs` magnitude bits for `z ≠ 0`). -/
def intBitLength (z : ℤ) : ℕ :=
  if z = 0 then 1 else 1 + natBitLength z.natAbs

/-- Total binary encoding length of a reduced rational `q = q.num / q.den`, including both its
signed numerator and its positive denominator. -/
def ratBitLength (q : ℚ) : ℕ :=
  intBitLength q.num + natBitLength q.den

/-- A rational coordinate `q ∈ ℚ` has numerator and denominator binary digit length at most `B`
(nonempty iff `B ≥ 1`, and implies `ratBitLength q ≤ 2 * B + 1`). -/
def RatCoordBitBounded (B : ℕ) (q : ℚ) : Prop :=
  natBitLength q.num.natAbs ≤ B ∧ natBitLength q.den ≤ B

/-- A rational coordinate `q ∈ ℚ` has combined numerator-and-denominator binary encoding length
`ratBitLength q` at most `B`. -/
def RatCoordEncodingBounded (B : ℕ) (q : ℚ) : Prop :=
  ratBitLength q ≤ B

/-- Every coordinate of `x ∈ ℚ^d` has numerator and denominator binary length at most `B`. -/
def RatPointBitBounded {d : ℕ} (B : ℕ) (x : Fin d → ℚ) : Prop :=
  ∀ i : Fin d, RatCoordBitBounded B (x i)

/-- Every coordinate of `x ∈ ℚ^d` has combined binary encoding length `ratBitLength (x i) ≤ B`. -/
def RatPointEncodingBounded {d : ℕ} (B : ℕ) (x : Fin d → ℚ) : Prop :=
  ∀ i : Fin d, RatCoordEncodingBounded B (x i)

/-- Subset of `EuclideanSpace ℝ (Fin d)` consisting of rational points in `ℚ^d` whose coordinates
have numerator and denominator binary length at most `B`. -/
def RatAdmissiblePointSet (d B : ℕ) : Set (EuclideanSpace ℝ (Fin d)) :=
  {p | ∃ q : Fin d → ℚ, RatPointBitBounded B q ∧ ratPointToEuclidean q = p}

/-! ### 2. RAM memory locations and stores (persistent heap + scoped temporary frames) -/

/-- Addressable memory cell location: either a persistent heap cell `(table, idx)` (storing
auxiliary structures, simultaneous rebuilds, and cached answers across updates) or a scoped
temporary cell `(depth, var, idx)` inside a subroutine's `localScope`. -/
inductive RAMCellLoc : Type
  | heap (table : ℕ) (idx : ℤ)
  | localFrame (depth : ℕ) (var : ℕ) (idx : ℤ)
  deriving DecidableEq

/-- Binary encoding length of a memory cell address. -/
def RAMCellLoc.bitLength : RAMCellLoc → ℕ
  | .heap table idx => natBitLength table + intBitLength idx
  | .localFrame depth var idx => natBitLength depth + natBitLength var + intBitLength idx

/-- Whether `loc` survives when popping local frames back to depth `keepDepth`. -/
def RAMCellLoc.keepAtDepth (keepDepth : ℕ) : RAMCellLoc → Bool
  | .heap _ _ => true
  | .localFrame d _ _ => decide (d ≤ keepDepth)

/-- Integer/word store tracking the finite set of currently live allocated cells and their values. -/
structure WordStore : Type where
  live : Finset RAMCellLoc
  vals : RAMCellLoc → ℤ

/-- Empty word store with zero allocated cells. -/
def WordStore.empty : WordStore :=
  { live := ∅, vals := fun _ => 0 }

/-- Read an integer cell (unallocated cells read as `0`). -/
def WordStore.read (ws : WordStore) (loc : RAMCellLoc) : ℤ :=
  if loc ∈ ws.live then ws.vals loc else 0

/-- Write an integer value `v` to `loc`, marking `loc` live. -/
def WordStore.write (ws : WordStore) (loc : RAMCellLoc) (v : ℤ) : WordStore :=
  { live := insert loc ws.live, vals := Function.update ws.vals loc v }

/-- Explicitly reclaim a memory cell `loc`. -/
def WordStore.free (ws : WordStore) (loc : RAMCellLoc) : WordStore :=
  { live := ws.live.erase loc, vals := Function.update ws.vals loc 0 }

/-- Reclaim all local frame cells strictly deeper than `keepDepth` upon exiting a `localScope`. -/
def WordStore.popDepth (ws : WordStore) (keepDepth : ℕ) : WordStore :=
  { live := ws.live.filter (fun loc => loc.keepAtDepth keepDepth = true)
    vals := fun loc => if loc.keepAtDepth keepDepth then ws.vals loc else 0 }

/-- Number of currently allocated word cells. -/
def WordStore.cellCount (ws : WordStore) : ℕ :=
  ws.live.card

/-- Total binary encoding size of all currently allocated word cells (addresses and contents). -/
def WordStore.bitSize (ws : WordStore) : ℕ :=
  ∑ loc ∈ ws.live, (loc.bitLength + intBitLength (ws.vals loc))

/-- Exact real number store for the Arithmetic-RAM model, tracking live real cells. -/
structure RealStore : Type where
  live : Finset RAMCellLoc
  vals : RAMCellLoc → ℝ

/-- Empty real store with zero allocated cells. -/
def RealStore.empty : RealStore :=
  { live := ∅, vals := fun _ => 0 }

/-- Read a real cell (unallocated cells read as `0`). -/
def RealStore.read (rs : RealStore) (loc : RAMCellLoc) : ℝ :=
  if loc ∈ rs.live then rs.vals loc else 0

/-- Write a real value `v` to `loc`, marking `loc` live. -/
noncomputable def RealStore.write (rs : RealStore) (loc : RAMCellLoc) (v : ℝ) : RealStore :=
  { live := insert loc rs.live, vals := Function.update rs.vals loc v }

/-- Explicitly reclaim a real cell `loc`. -/
noncomputable def RealStore.free (rs : RealStore) (loc : RAMCellLoc) : RealStore :=
  { live := rs.live.erase loc, vals := Function.update rs.vals loc 0 }

/-- Reclaim all local real cells strictly deeper than `keepDepth` upon exiting a `localScope`. -/
def RealStore.popDepth (rs : RealStore) (keepDepth : ℕ) : RealStore :=
  { live := rs.live.filter (fun loc => loc.keepAtDepth keepDepth = true)
    vals := fun loc => if loc.keepAtDepth keepDepth then rs.vals loc else 0 }

/-- Number of currently allocated real cells. -/
def RealStore.cellCount (rs : RealStore) : ℕ :=
  rs.live.card

/-! ### 3. Finite-word and rational bit-length (`B`) RAM model (`BitRAM`) -/

/-- Read-only input context for a `BitRAM` execution in ambient dimension `d`, counting active
rational input points alongside integer parameters and any extra rational inputs (such as a newly
inserted rational point or linear-program right-hand side). -/
structure BitRAMInput (d : ℕ) : Type where
  intParams : List ℤ
  activeHandles : Finset ℕ
  activeRatCoords : ℕ → Fin d → ℚ
  extraRats : List ℚ

/-- Input environment carrying only integer parameters (e.g. precision `k`). -/
def BitRAMInput.ofIntParams (params : List ℤ) : BitRAMInput 0 :=
  { intParams := params
    activeHandles := ∅
    activeRatCoords := fun _ i => Fin.elim0 i
    extraRats := [] }

/-- Number of cells occupied by the active input of a `BitRAM` execution. -/
def BitRAMInput.inputCellSpace {d : ℕ} (inp : BitRAMInput d) : ℕ :=
  inp.intParams.length + inp.activeHandles.card * (2 * d + 1) + 2 * inp.extraRats.length

/-- Binary encoding size of the active input of a `BitRAM` execution. -/
def BitRAMInput.inputBitSpace {d : ℕ} (inp : BitRAMInput d) : ℕ :=
  (inp.intParams.map intBitLength).sum +
    (∑ h ∈ inp.activeHandles,
      (natBitLength h + ∑ i : Fin d, ratBitLength (inp.activeRatCoords h i))) +
    (inp.extraRats.map ratBitLength).sum

/-- Integer expressions shared by `BitRAM` and `ArithRAM` word operations. -/
inductive IntExpr : Type
  | lit (c : ℤ)
  | dim
  | intParam (idx : IntExpr)
  | readHeap (table : ℕ) (idx : IntExpr)
  | readLocal (var : ℕ) (idx : IntExpr)
  | activeRatNum (handleExpr : IntExpr) (coordIdx : IntExpr)
  | activeRatDen (handleExpr : IntExpr) (coordIdx : IntExpr)
  | extraRatNum (idx : IntExpr)
  | extraRatDen (idx : IntExpr)
  | neg (e : IntExpr)
  | add (e₁ e₂ : IntExpr)
  | sub (e₁ e₂ : IntExpr)
  | mul (e₁ e₂ : IntExpr)
  | div (e₁ e₂ : IntExpr)
  | mod (e₁ e₂ : IntExpr)
  deriving DecidableEq

/-- Helper to index a list at a non-negative integer index with a default fallback. -/
def listGetIntD {α : Type*} (xs : List α) (idx : ℤ) (fallback : α) : α :=
  if 0 ≤ idx then
    xs.getD idx.toNat fallback
  else
    fallback

/-- Evaluate an `IntExpr`, returning `(value, unitOps, bitOps)` where `bitOps` accounts for the
binary encoding lengths of all intermediate numbers (`len₁ + len₂` for addition and subtraction,
`len₁ * len₂` for multiplication, division, and remainder). -/
def evalIntExpr {d : ℕ} (inp : BitRAMInput d) (frameDepth : ℕ) (ws : WordStore) :
    IntExpr → ℤ × ℕ × ℕ
  | .lit c => (c, 1, intBitLength c)
  | .dim => ((d : ℤ), 1, intBitLength (d : ℤ))
  | .intParam idxE =>
      let (idx, u, b) := evalIntExpr inp frameDepth ws idxE
      let v := listGetIntD inp.intParams idx 0
      (v, u + 1, b + intBitLength idx + intBitLength v)
  | .readHeap table idxE =>
      let (idx, u, b) := evalIntExpr inp frameDepth ws idxE
      let v := ws.read (.heap table idx)
      (v, u + 1, b + natBitLength table + intBitLength idx + intBitLength v)
  | .readLocal var idxE =>
      let (idx, u, b) := evalIntExpr inp frameDepth ws idxE
      let v := ws.read (.localFrame frameDepth var idx)
      (v, u + 1, b + natBitLength var + intBitLength idx + intBitLength v)
  | .activeRatNum hE cE =>
      let (h, u₁, b₁) := evalIntExpr inp frameDepth ws hE
      let (c, u₂, b₂) := evalIntExpr inp frameDepth ws cE
      let v : ℤ :=
        if _hh : 0 ≤ h ∧ h.toNat ∈ inp.activeHandles then
          if hc : 0 ≤ c ∧ c.toNat < d then
            (inp.activeRatCoords h.toNat ⟨c.toNat, hc.2⟩).num
          else 0
        else 0
      (v, u₁ + u₂ + 1, b₁ + b₂ + intBitLength h + intBitLength c + intBitLength v)
  | .activeRatDen hE cE =>
      let (h, u₁, b₁) := evalIntExpr inp frameDepth ws hE
      let (c, u₂, b₂) := evalIntExpr inp frameDepth ws cE
      let v : ℤ :=
        if _hh : 0 ≤ h ∧ h.toNat ∈ inp.activeHandles then
          if hc : 0 ≤ c ∧ c.toNat < d then
            ((inp.activeRatCoords h.toNat ⟨c.toNat, hc.2⟩).den : ℤ)
          else 1
        else 1
      (v, u₁ + u₂ + 1, b₁ + b₂ + intBitLength h + intBitLength c + intBitLength v)
  | .extraRatNum idxE =>
      let (idx, u, b) := evalIntExpr inp frameDepth ws idxE
      let q := listGetIntD inp.extraRats idx 0
      let v := q.num
      (v, u + 1, b + intBitLength idx + intBitLength v)
  | .extraRatDen idxE =>
      let (idx, u, b) := evalIntExpr inp frameDepth ws idxE
      let q := listGetIntD inp.extraRats idx 0
      let v : ℤ := (q.den : ℤ)
      (v, u + 1, b + intBitLength idx + intBitLength v)
  | .neg e =>
      let (v, u, b) := evalIntExpr inp frameDepth ws e
      (-v, u + 1, b + intBitLength v)
  | .add e₁ e₂ =>
      let (v₁, u₁, b₁) := evalIntExpr inp frameDepth ws e₁
      let (v₂, u₂, b₂) := evalIntExpr inp frameDepth ws e₂
      (v₁ + v₂, u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ + intBitLength v₂)
  | .sub e₁ e₂ =>
      let (v₁, u₁, b₁) := evalIntExpr inp frameDepth ws e₁
      let (v₂, u₂, b₂) := evalIntExpr inp frameDepth ws e₂
      (v₁ - v₂, u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ + intBitLength v₂)
  | .mul e₁ e₂ =>
      let (v₁, u₁, b₁) := evalIntExpr inp frameDepth ws e₁
      let (v₂, u₂, b₂) := evalIntExpr inp frameDepth ws e₂
      (v₁ * v₂, u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ * intBitLength v₂)
  | .div e₁ e₂ =>
      let (v₁, u₁, b₁) := evalIntExpr inp frameDepth ws e₁
      let (v₂, u₂, b₂) := evalIntExpr inp frameDepth ws e₂
      (v₁ / v₂, u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ * intBitLength v₂)
  | .mod e₁ e₂ =>
      let (v₁, u₁, b₁) := evalIntExpr inp frameDepth ws e₁
      let (v₂, u₂, b₂) := evalIntExpr inp frameDepth ws e₂
      (v₁ % v₂, u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ * intBitLength v₂)

/-- Boolean conditions on exact integers for `BitRAM`. -/
inductive BitCondExpr : Type
  | intEq (e₁ e₂ : IntExpr)
  | intLt (e₁ e₂ : IntExpr)
  | intLe (e₁ e₂ : IntExpr)
  | not (c : BitCondExpr)
  | and (c₁ c₂ : BitCondExpr)
  | or (c₁ c₂ : BitCondExpr)
  deriving DecidableEq

/-- Evaluate a `BitCondExpr`, returning `(result, unitOps, bitOps)`. -/
def evalBitCond {d : ℕ} (inp : BitRAMInput d) (frameDepth : ℕ) (ws : WordStore) :
    BitCondExpr → Bool × ℕ × ℕ
  | .intEq e₁ e₂ =>
      let (v₁, u₁, b₁) := evalIntExpr inp frameDepth ws e₁
      let (v₂, u₂, b₂) := evalIntExpr inp frameDepth ws e₂
      (decide (v₁ = v₂), u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ + intBitLength v₂)
  | .intLt e₁ e₂ =>
      let (v₁, u₁, b₁) := evalIntExpr inp frameDepth ws e₁
      let (v₂, u₂, b₂) := evalIntExpr inp frameDepth ws e₂
      (decide (v₁ < v₂), u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ + intBitLength v₂)
  | .intLe e₁ e₂ =>
      let (v₁, u₁, b₁) := evalIntExpr inp frameDepth ws e₁
      let (v₂, u₂, b₂) := evalIntExpr inp frameDepth ws e₂
      (decide (v₁ ≤ v₂), u₁ + u₂ + 1, b₁ + b₂ + intBitLength v₁ + intBitLength v₂)
  | .not c =>
      let (res, u, b) := evalBitCond inp frameDepth ws c
      (!res, u + 1, b + 1)
  | .and c₁ c₂ =>
      let (r₁, u₁, b₁) := evalBitCond inp frameDepth ws c₁
      let (r₂, u₂, b₂) := evalBitCond inp frameDepth ws c₂
      (r₁ && r₂, u₁ + u₂ + 1, b₁ + b₂ + 1)
  | .or c₁ c₂ =>
      let (r₁, u₁, b₁) := evalBitCond inp frameDepth ws c₁
      let (r₂, u₂, b₂) := evalBitCond inp frameDepth ws c₂
      (r₁ || r₂, u₁ + u₂ + 1, b₁ + b₂ + 1)

/-- Finitary structured program syntax for the finite-word and rational bit-length RAM (`BitRAM`). -/
inductive BitRAMStmt : Type
  | skip
  | writeHeap (table : ℕ) (idx : IntExpr) (val : IntExpr)
  | writeLocal (var : ℕ) (idx : IntExpr) (val : IntExpr)
  | freeHeap (table : ℕ) (idx : IntExpr)
  | freeLocal (var : ℕ) (idx : IntExpr)
  | randBitHeap (table : ℕ) (idx : IntExpr)
  | randBitLocal (var : ℕ) (idx : IntExpr)
  | seq (s₁ s₂ : BitRAMStmt)
  | ite (cond : BitCondExpr) (tBranch fBranch : BitRAMStmt)
  | whileLoop (cond : BitCondExpr) (body : BitRAMStmt)
  | repeatN (count : IntExpr) (body : BitRAMStmt)
  | localScope (body : BitRAMStmt)
  deriving DecidableEq

/-- Continuation frame for small-step `BitRAM` execution. -/
inductive BitRAMCont : Type
  | stmt (s : BitRAMStmt)
  | repeatLoop (rem : ℕ) (body : BitRAMStmt)
  | popScope (prevDepth : ℕ)

/-- Internal state during a `BitRAM` execution. -/
structure BitRAMExecState : Type where
  words : WordStore
  frameDepth : ℕ
  remainingBits : List Bool
  unitCost : ℕ
  bitCost : ℕ
  peakCellSpace : ℕ
  peakBitSpace : ℕ

/-- Halting outcome of a `BitRAM` execution after consuming an exact random bit list. -/
structure BitRAMExecOutcome : Type where
  words : WordStore
  unitCost : ℕ
  bitCost : ℕ
  peakCellSpace : ℕ
  peakBitSpace : ℕ

/-- Termination status of fuel-bounded `BitRAM` execution. -/
inductive BitRAMRunStatus : Type
  | halted (out : BitRAMExecOutcome)
  | needMoreBits
  | unusedBits
  | outOfFuel

/-- Fuel-bounded small-step operational semantics of `BitRAM`, updating peak cell space and peak
bit space (active input + persistent auxiliary structures + simultaneous rebuilds + local frames)
at every step. -/
def runBitRAMFuel {d : ℕ} (inp : BitRAMInput d) :
    ℕ → List BitRAMCont → BitRAMExecState → BitRAMRunStatus
  | _, [], st =>
      if st.remainingBits.isEmpty then
        .halted
          { words := st.words.popDepth 0
            unitCost := st.unitCost
            bitCost := st.bitCost
            peakCellSpace := st.peakCellSpace
            peakBitSpace := st.peakBitSpace }
      else
        .unusedBits
  | 0, _ :: _, _ => .outOfFuel
  | fuel + 1, item :: rest, st =>
      match item with
      | .popScope prev =>
          let ws' := st.words.popDepth prev
          runBitRAMFuel inp fuel rest { st with words := ws', frameDepth := prev }
      | .repeatLoop 0 _ =>
          runBitRAMFuel inp fuel rest st
      | .repeatLoop (rem + 1) body =>
          runBitRAMFuel inp fuel (.stmt body :: .repeatLoop rem body :: rest) st
      | .stmt s =>
          match s with
          | .skip =>
              runBitRAMFuel inp fuel rest { st with unitCost := st.unitCost + 1, bitCost := st.bitCost + 1 }
          | .writeHeap table idxE valE =>
              let (idx, u₁, b₁) := evalIntExpr inp st.frameDepth st.words idxE
              let (val, u₂, b₂) := evalIntExpr inp st.frameDepth st.words valE
              let loc := RAMCellLoc.heap table idx
              let ws' := st.words.write loc val
              let cSpace := inp.inputCellSpace + ws'.cellCount
              let bSpace := inp.inputBitSpace + ws'.bitSize
              runBitRAMFuel inp fuel rest
                { st with
                  words := ws'
                  unitCost := st.unitCost + u₁ + u₂ + 1
                  bitCost := st.bitCost + b₁ + b₂ + loc.bitLength + intBitLength val
                  peakCellSpace := max st.peakCellSpace cSpace
                  peakBitSpace := max st.peakBitSpace bSpace }
          | .writeLocal var idxE valE =>
              let (idx, u₁, b₁) := evalIntExpr inp st.frameDepth st.words idxE
              let (val, u₂, b₂) := evalIntExpr inp st.frameDepth st.words valE
              let loc := RAMCellLoc.localFrame st.frameDepth var idx
              let ws' := st.words.write loc val
              let cSpace := inp.inputCellSpace + ws'.cellCount
              let bSpace := inp.inputBitSpace + ws'.bitSize
              runBitRAMFuel inp fuel rest
                { st with
                  words := ws'
                  unitCost := st.unitCost + u₁ + u₂ + 1
                  bitCost := st.bitCost + b₁ + b₂ + loc.bitLength + intBitLength val
                  peakCellSpace := max st.peakCellSpace cSpace
                  peakBitSpace := max st.peakBitSpace bSpace }
          | .freeHeap table idxE =>
              let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
              let loc := RAMCellLoc.heap table idx
              let ws' := st.words.free loc
              runBitRAMFuel inp fuel rest
                { st with
                  words := ws'
                  unitCost := st.unitCost + u + 1
                  bitCost := st.bitCost + b + loc.bitLength }
          | .freeLocal var idxE =>
              let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
              let loc := RAMCellLoc.localFrame st.frameDepth var idx
              let ws' := st.words.free loc
              runBitRAMFuel inp fuel rest
                { st with
                  words := ws'
                  unitCost := st.unitCost + u + 1
                  bitCost := st.bitCost + b + loc.bitLength }
          | .randBitHeap table idxE =>
              match st.remainingBits with
              | [] => .needMoreBits
              | bit :: bs' =>
                  let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
                  let loc := RAMCellLoc.heap table idx
                  let v : ℤ := if bit then 1 else 0
                  let ws' := st.words.write loc v
                  let cSpace := inp.inputCellSpace + ws'.cellCount
                  let bSpace := inp.inputBitSpace + ws'.bitSize
                  runBitRAMFuel inp fuel rest
                    { st with
                      words := ws'
                      remainingBits := bs'
                      unitCost := st.unitCost + u + 1
                      bitCost := st.bitCost + b + loc.bitLength + 1
                      peakCellSpace := max st.peakCellSpace cSpace
                      peakBitSpace := max st.peakBitSpace bSpace }
          | .randBitLocal var idxE =>
              match st.remainingBits with
              | [] => .needMoreBits
              | bit :: bs' =>
                  let (idx, u, b) := evalIntExpr inp st.frameDepth st.words idxE
                  let loc := RAMCellLoc.localFrame st.frameDepth var idx
                  let v : ℤ := if bit then 1 else 0
                  let ws' := st.words.write loc v
                  let cSpace := inp.inputCellSpace + ws'.cellCount
                  let bSpace := inp.inputBitSpace + ws'.bitSize
                  runBitRAMFuel inp fuel rest
                    { st with
                      words := ws'
                      remainingBits := bs'
                      unitCost := st.unitCost + u + 1
                      bitCost := st.bitCost + b + loc.bitLength + 1
                      peakCellSpace := max st.peakCellSpace cSpace
                      peakBitSpace := max st.peakBitSpace bSpace }
          | .seq s₁ s₂ =>
              runBitRAMFuel inp fuel (.stmt s₁ :: .stmt s₂ :: rest) st
          | .ite cond tBranch fBranch =>
              let (flag, u, b) := evalBitCond inp st.frameDepth st.words cond
              let chosen := if flag then tBranch else fBranch
              runBitRAMFuel inp fuel (.stmt chosen :: rest)
                { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b }
          | .whileLoop cond body =>
              let (flag, u, b) := evalBitCond inp st.frameDepth st.words cond
              let nextStack := if flag then .stmt body :: .stmt (.whileLoop cond body) :: rest else rest
              runBitRAMFuel inp fuel nextStack
                { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b }
          | .repeatN countE body =>
              let (cnt, u, b) := evalIntExpr inp st.frameDepth st.words countE
              let nIter := if 0 ≤ cnt then cnt.toNat else 0
              runBitRAMFuel inp fuel (.repeatLoop nIter body :: rest)
                { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b }
          | .localScope body =>
              let prev := st.frameDepth
              let nextDepth := prev + 1
              let wsClean := st.words.popDepth prev
              runBitRAMFuel inp fuel (.stmt body :: .popScope prev :: rest)
                { st with words := wsClean, frameDepth := nextDepth }

/-- Unbounded execution of `prog : BitRAMStmt` consuming the exact random bit sequence `bs`.
Returns `some out` iff `prog` halts in finitely many steps having consumed every bit of `bs`. -/
noncomputable def runBitRAMWithBits {d : ℕ} (prog : BitRAMStmt) (inp : BitRAMInput d)
    (initWords : WordStore) (bs : List Bool) : Option BitRAMExecOutcome :=
  open Classical in
  let initSt : BitRAMExecState :=
    { words := initWords.popDepth 0
      frameDepth := 0
      remainingBits := bs
      unitCost := 0
      bitCost := 0
      peakCellSpace := inp.inputCellSpace + (initWords.popDepth 0).cellCount
      peakBitSpace := inp.inputBitSpace + (initWords.popDepth 0).bitSize }
  if h : ∃ fuel : ℕ, ∃ out : BitRAMExecOutcome,
      runBitRAMFuel inp fuel [.stmt prog] initSt = .halted out then
    match runBitRAMFuel inp (Nat.find h) [.stmt prog] initSt with
    | .halted out => some out
    | _ => none
  else
    none

/-! ### 4. Certified `k`-bit approximations of fixed parameters -/

/-- A rational interval `[lo, hi]` (`lo, hi : ℚ`) is a certified `k`-bit approximation of a real
parameter `α ∈ ℝ` if it is guaranteed to contain `α` and has length at most `2^{-k}`. -/
def IsCertifiedKBitApprox (α : ℝ) (k : ℕ) (lo hi : ℚ) : Prop :=
  (lo : ℝ) ≤ α ∧ α ≤ (hi : ℝ) ∧ (hi : ℝ) - (lo : ℝ) ≤ (2 : ℝ) ^ (-(k : ℤ))

/-- Lower endpoint of a certified rational interval, used when rounding downward for inequalities. -/
def roundIntervalDown (lo _hi : ℚ) : ℚ := lo

/-- Upper endpoint of a certified rational interval, used when rounding upward for inequalities. -/
def roundIntervalUp (_lo hi : ℚ) : ℚ := hi

/-- A real parameter `α ∈ ℝ` can be approximated in polynomial time by certified `k`-bit rational
intervals if a deterministic `BitRAMStmt` computes on input `k` a rational interval `[lo, hi]`
containing `α` of length at most `2^{-k}` in `poly(k)` bit-operations. -/
def IsPolyTimeApproximableParam (α : ℝ) : Prop :=
  ∃ (prog : BitRAMStmt) (C deg : ℕ),
    ∀ k : ℕ, ∃ out : BitRAMExecOutcome,
      runBitRAMWithBits prog (BitRAMInput.ofIntParams [(k : ℤ)]) WordStore.empty [] = some out ∧
      out.bitCost ≤ C * (k + 1) ^ deg ∧
      let loNum := out.words.read (.heap 0 0)
      let loDen := out.words.read (.heap 0 1)
      let hiNum := out.words.read (.heap 0 2)
      let hiDen := out.words.read (.heap 0 3)
      0 < loDen ∧ 0 < hiDen ∧
        IsCertifiedKBitApprox α k ((loNum : ℚ) / (loDen : ℚ)) ((hiNum : ℚ) / (hiDen : ℚ))

/-- Fixed approximation and space parameters (independent of `n, d, B`) are admissible if they are
either rational or polynomial-time approximable by certified `k`-bit rational intervals. -/
def IsAdmissibleFixedParam (α : ℝ) : Prop :=
  (∃ q : ℚ, (q : ℝ) = α) ∨ IsPolyTimeApproximableParam α

/-! ### 5. Unit-cost Arithmetic-RAM model (`ArithRAM`) -/

/-- Read-only input context for an `ArithRAM` execution in ambient dimension `d`, counting active
input points in `ℝ^d` alongside integer parameters and extra real values (such as the `d`
coordinates of a newly inserted point). -/
structure ArithRAMInput (d : ℕ) : Type where
  intParams : List ℤ
  activeHandles : Finset ℕ
  activeCoords : ℕ → EuclideanSpace ℝ (Fin d)
  extraReals : List ℝ

/-- Number of cells occupied by the active input of an `ArithRAM` execution. -/
def ArithRAMInput.inputCellSpace {d : ℕ} (inp : ArithRAMInput d) : ℕ :=
  inp.intParams.length + inp.activeHandles.card * (d + 1) + inp.extraReals.length

/-- View of `ArithRAMInput` integer parameters for evaluating integer index and word expressions. -/
def ArithRAMInput.toWordView {d : ℕ} (inp : ArithRAMInput d) : BitRAMInput d :=
  { intParams := inp.intParams
    activeHandles := inp.activeHandles
    activeRatCoords := fun _ _ => 0
    extraRats := [] }

/-- Exact real-valued arithmetic expressions in the unit-cost Arithmetic-RAM model (`+, -, *, /`,
integer-to-real casts, memory reads, and active or input coordinate reads; no `sqrt` primitive). -/
inductive RealExpr : Type
  | ofInt (e : IntExpr)
  | readRealHeap (table : ℕ) (idx : IntExpr)
  | readRealLocal (var : ℕ) (idx : IntExpr)
  | activePtCoord (handleExpr : IntExpr) (coordIdx : IntExpr)
  | extraReal (idx : IntExpr)
  | neg (r : RealExpr)
  | add (r₁ r₂ : RealExpr)
  | sub (r₁ r₂ : RealExpr)
  | mul (r₁ r₂ : RealExpr)
  | div (r₁ r₂ : RealExpr)
  deriving DecidableEq

/-- Persistent and local memory of an `ArithRAM` machine (word cells + exact real cells). -/
structure ArithRAMMemory : Type where
  words : WordStore
  reals : RealStore

/-- Empty `ArithRAM` memory with zero allocated word or real cells. -/
def ArithRAMMemory.empty : ArithRAMMemory :=
  { words := WordStore.empty, reals := RealStore.empty }

/-- Reclaim all local word and real cells strictly deeper than `keepDepth`. -/
def ArithRAMMemory.popDepth (mem : ArithRAMMemory) (keepDepth : ℕ) : ArithRAMMemory :=
  { words := mem.words.popDepth keepDepth, reals := mem.reals.popDepth keepDepth }

/-- Total allocated auxiliary, simultaneous-rebuild, and temporary cells in `mem`. -/
def ArithRAMMemory.cellCount (mem : ArithRAMMemory) : ℕ :=
  mem.words.cellCount + mem.reals.cellCount

/-- Evaluate a `RealExpr` at unit cost per arithmetic or read operation, returning `(value, unitOps)`. -/
noncomputable def evalRealExpr {d : ℕ} (inp : ArithRAMInput d) (frameDepth : ℕ)
    (mem : ArithRAMMemory) : RealExpr → ℝ × ℕ
  | .ofInt e =>
      let (v, u, _) := evalIntExpr inp.toWordView frameDepth mem.words e
      ((v : ℝ), u + 1)
  | .readRealHeap table idxE =>
      let (idx, u, _) := evalIntExpr inp.toWordView frameDepth mem.words idxE
      (mem.reals.read (.heap table idx), u + 1)
  | .readRealLocal var idxE =>
      let (idx, u, _) := evalIntExpr inp.toWordView frameDepth mem.words idxE
      (mem.reals.read (.localFrame frameDepth var idx), u + 1)
  | .activePtCoord hE cE =>
      let (h, u₁, _) := evalIntExpr inp.toWordView frameDepth mem.words hE
      let (c, u₂, _) := evalIntExpr inp.toWordView frameDepth mem.words cE
      let val : ℝ :=
        if _hh : 0 ≤ h ∧ h.toNat ∈ inp.activeHandles then
          if hc : 0 ≤ c ∧ c.toNat < d then
            euclideanCoord (inp.activeCoords h.toNat) ⟨c.toNat, hc.2⟩
          else 0
        else 0
      (val, u₁ + u₂ + 1)
  | .extraReal idxE =>
      let (idx, u, _) := evalIntExpr inp.toWordView frameDepth mem.words idxE
      (listGetIntD inp.extraReals idx 0, u + 1)
  | .neg r =>
      let (x, u) := evalRealExpr inp frameDepth mem r
      (-x, u + 1)
  | .add r₁ r₂ =>
      let (x₁, u₁) := evalRealExpr inp frameDepth mem r₁
      let (x₂, u₂) := evalRealExpr inp frameDepth mem r₂
      (x₁ + x₂, u₁ + u₂ + 1)
  | .sub r₁ r₂ =>
      let (x₁, u₁) := evalRealExpr inp frameDepth mem r₁
      let (x₂, u₂) := evalRealExpr inp frameDepth mem r₂
      (x₁ - x₂, u₁ + u₂ + 1)
  | .mul r₁ r₂ =>
      let (x₁, u₁) := evalRealExpr inp frameDepth mem r₁
      let (x₂, u₂) := evalRealExpr inp frameDepth mem r₂
      (x₁ * x₂, u₁ + u₂ + 1)
  | .div r₁ r₂ =>
      let (x₁, u₁) := evalRealExpr inp frameDepth mem r₁
      let (x₂, u₂) := evalRealExpr inp frameDepth mem r₂
      (x₁ / x₂, u₁ + u₂ + 1)

/-- Boolean conditions on words and exact reals in `ArithRAM` (unit-cost exact comparisons). -/
inductive ArithCondExpr : Type
  | intEq (e₁ e₂ : IntExpr)
  | intLt (e₁ e₂ : IntExpr)
  | intLe (e₁ e₂ : IntExpr)
  | realEq (r₁ r₂ : RealExpr)
  | realLt (r₁ r₂ : RealExpr)
  | realLe (r₁ r₂ : RealExpr)
  | not (c : ArithCondExpr)
  | and (c₁ c₂ : ArithCondExpr)
  | or (c₁ c₂ : ArithCondExpr)
  deriving DecidableEq

/-- Evaluate an `ArithCondExpr` at unit cost per comparison, returning `(result, unitOps)`. -/
noncomputable def evalArithCond {d : ℕ} (inp : ArithRAMInput d) (frameDepth : ℕ)
    (mem : ArithRAMMemory) : ArithCondExpr → Bool × ℕ :=
  open Classical in
  fun cond =>
    match cond with
    | .intEq e₁ e₂ =>
        let (v₁, u₁, _) := evalIntExpr inp.toWordView frameDepth mem.words e₁
        let (v₂, u₂, _) := evalIntExpr inp.toWordView frameDepth mem.words e₂
        (decide (v₁ = v₂), u₁ + u₂ + 1)
    | .intLt e₁ e₂ =>
        let (v₁, u₁, _) := evalIntExpr inp.toWordView frameDepth mem.words e₁
        let (v₂, u₂, _) := evalIntExpr inp.toWordView frameDepth mem.words e₂
        (decide (v₁ < v₂), u₁ + u₂ + 1)
    | .intLe e₁ e₂ =>
        let (v₁, u₁, _) := evalIntExpr inp.toWordView frameDepth mem.words e₁
        let (v₂, u₂, _) := evalIntExpr inp.toWordView frameDepth mem.words e₂
        (decide (v₁ ≤ v₂), u₁ + u₂ + 1)
    | .realEq r₁ r₂ =>
        let (x₁, u₁) := evalRealExpr inp frameDepth mem r₁
        let (x₂, u₂) := evalRealExpr inp frameDepth mem r₂
        (decide (x₁ = x₂), u₁ + u₂ + 1)
    | .realLt r₁ r₂ =>
        let (x₁, u₁) := evalRealExpr inp frameDepth mem r₁
        let (x₂, u₂) := evalRealExpr inp frameDepth mem r₂
        (decide (x₁ < x₂), u₁ + u₂ + 1)
    | .realLe r₁ r₂ =>
        let (x₁, u₁) := evalRealExpr inp frameDepth mem r₁
        let (x₂, u₂) := evalRealExpr inp frameDepth mem r₂
        (decide (x₁ ≤ x₂), u₁ + u₂ + 1)
    | .not c =>
        let (res, u) := evalArithCond inp frameDepth mem c
        (!res, u + 1)
    | .and c₁ c₂ =>
        let (b₁, u₁) := evalArithCond inp frameDepth mem c₁
        let (b₂, u₂) := evalArithCond inp frameDepth mem c₂
        (b₁ && b₂, u₁ + u₂ + 1)
    | .or c₁ c₂ =>
        let (b₁, u₁) := evalArithCond inp frameDepth mem c₁
        let (b₂, u₂) := evalArithCond inp frameDepth mem c₂
        (b₁ || b₂, u₁ + u₂ + 1)

/-- Finitary structured program syntax for the unit-cost Arithmetic-RAM (`ArithRAM`). -/
inductive ArithRAMStmt : Type
  | skip
  | writeWordHeap (table : ℕ) (idx : IntExpr) (val : IntExpr)
  | writeWordLocal (var : ℕ) (idx : IntExpr) (val : IntExpr)
  | freeWordHeap (table : ℕ) (idx : IntExpr)
  | freeWordLocal (var : ℕ) (idx : IntExpr)
  | writeRealHeap (table : ℕ) (idx : IntExpr) (val : RealExpr)
  | writeRealLocal (var : ℕ) (idx : IntExpr) (val : RealExpr)
  | freeRealHeap (table : ℕ) (idx : IntExpr)
  | freeRealLocal (var : ℕ) (idx : IntExpr)
  | randBitHeap (table : ℕ) (idx : IntExpr)
  | randBitLocal (var : ℕ) (idx : IntExpr)
  | seq (s₁ s₂ : ArithRAMStmt)
  | ite (cond : ArithCondExpr) (tBranch fBranch : ArithRAMStmt)
  | whileLoop (cond : ArithCondExpr) (body : ArithRAMStmt)
  | repeatN (count : IntExpr) (body : ArithRAMStmt)
  | localScope (body : ArithRAMStmt)
  deriving DecidableEq

/-- Continuation frame for small-step `ArithRAM` execution. -/
inductive ArithRAMCont : Type
  | stmt (s : ArithRAMStmt)
  | repeatLoop (rem : ℕ) (body : ArithRAMStmt)
  | popScope (prevDepth : ℕ)

/-- Internal state during an `ArithRAM` execution. -/
structure ArithRAMExecState : Type where
  mem : ArithRAMMemory
  frameDepth : ℕ
  remainingBits : List Bool
  unitCost : ℕ
  peakCellSpace : ℕ

/-- Halting outcome of an `ArithRAM` execution after consuming an exact random bit list. -/
structure ArithRAMExecOutcome : Type where
  mem : ArithRAMMemory
  unitCost : ℕ
  peakCellSpace : ℕ

/-- Termination status of fuel-bounded `ArithRAM` execution. -/
inductive ArithRAMRunStatus : Type
  | halted (out : ArithRAMExecOutcome)
  | needMoreBits
  | unusedBits
  | outOfFuel

/-- Fuel-bounded small-step operational semantics of `ArithRAM`, charging unit cost for each word
operation, exact real field operation, comparison, and uniform random bit draw, and tracking peak
cell space (active input + auxiliary structures + simultaneous rebuilds + temporary memory). -/
noncomputable def runArithRAMFuel {d : ℕ} (inp : ArithRAMInput d) :
    ℕ → List ArithRAMCont → ArithRAMExecState → ArithRAMRunStatus
  | _, [], st =>
      if st.remainingBits.isEmpty then
        .halted
          { mem := st.mem.popDepth 0
            unitCost := st.unitCost
            peakCellSpace := st.peakCellSpace }
      else
        .unusedBits
  | 0, _ :: _, _ => .outOfFuel
  | fuel + 1, item :: rest, st =>
      match item with
      | .popScope prev =>
          let mem' := st.mem.popDepth prev
          runArithRAMFuel inp fuel rest { st with mem := mem', frameDepth := prev }
      | .repeatLoop 0 _ =>
          runArithRAMFuel inp fuel rest st
      | .repeatLoop (rem + 1) body =>
          runArithRAMFuel inp fuel (.stmt body :: .repeatLoop rem body :: rest) st
      | .stmt s =>
          match s with
          | .skip =>
              runArithRAMFuel inp fuel rest { st with unitCost := st.unitCost + 1 }
          | .writeWordHeap table idxE valE =>
              let (idx, u₁, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE
              let (val, u₂, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words valE
              let mem' : ArithRAMMemory :=
                { st.mem with words := st.mem.words.write (.heap table idx) val }
              let cSpace := inp.inputCellSpace + mem'.cellCount
              runArithRAMFuel inp fuel rest
                { st with
                  mem := mem'
                  unitCost := st.unitCost + u₁ + u₂ + 1
                  peakCellSpace := max st.peakCellSpace cSpace }
          | .writeWordLocal var idxE valE =>
              let (idx, u₁, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE
              let (val, u₂, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words valE
              let mem' : ArithRAMMemory :=
                { st.mem with words := st.mem.words.write (.localFrame st.frameDepth var idx) val }
              let cSpace := inp.inputCellSpace + mem'.cellCount
              runArithRAMFuel inp fuel rest
                { st with
                  mem := mem'
                  unitCost := st.unitCost + u₁ + u₂ + 1
                  peakCellSpace := max st.peakCellSpace cSpace }
          | .freeWordHeap table idxE =>
              let (idx, u, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE
              let mem' : ArithRAMMemory :=
                { st.mem with words := st.mem.words.free (.heap table idx) }
              runArithRAMFuel inp fuel rest { st with mem := mem', unitCost := st.unitCost + u + 1 }
          | .freeWordLocal var idxE =>
              let (idx, u, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE
              let mem' : ArithRAMMemory :=
                { st.mem with words := st.mem.words.free (.localFrame st.frameDepth var idx) }
              runArithRAMFuel inp fuel rest { st with mem := mem', unitCost := st.unitCost + u + 1 }
          | .writeRealHeap table idxE valE =>
              let (idx, u₁, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE
              let (val, u₂) := evalRealExpr inp st.frameDepth st.mem valE
              let mem' : ArithRAMMemory :=
                { st.mem with reals := st.mem.reals.write (.heap table idx) val }
              let cSpace := inp.inputCellSpace + mem'.cellCount
              runArithRAMFuel inp fuel rest
                { st with
                  mem := mem'
                  unitCost := st.unitCost + u₁ + u₂ + 1
                  peakCellSpace := max st.peakCellSpace cSpace }
          | .writeRealLocal var idxE valE =>
              let (idx, u₁, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE
              let (val, u₂) := evalRealExpr inp st.frameDepth st.mem valE
              let mem' : ArithRAMMemory :=
                { st.mem with reals := st.mem.reals.write (.localFrame st.frameDepth var idx) val }
              let cSpace := inp.inputCellSpace + mem'.cellCount
              runArithRAMFuel inp fuel rest
                { st with
                  mem := mem'
                  unitCost := st.unitCost + u₁ + u₂ + 1
                  peakCellSpace := max st.peakCellSpace cSpace }
          | .freeRealHeap table idxE =>
              let (idx, u, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE
              let mem' : ArithRAMMemory :=
                { st.mem with reals := st.mem.reals.free (.heap table idx) }
              runArithRAMFuel inp fuel rest { st with mem := mem', unitCost := st.unitCost + u + 1 }
          | .freeRealLocal var idxE =>
              let (idx, u, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE
              let mem' : ArithRAMMemory :=
                { st.mem with reals := st.mem.reals.free (.localFrame st.frameDepth var idx) }
              runArithRAMFuel inp fuel rest { st with mem := mem', unitCost := st.unitCost + u + 1 }
          | .randBitHeap table idxE =>
              match st.remainingBits with
              | [] => .needMoreBits
              | bit :: bs' =>
                  let (idx, u, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE
                  let v : ℤ := if bit then 1 else 0
                  let mem' : ArithRAMMemory :=
                    { st.mem with words := st.mem.words.write (.heap table idx) v }
                  let cSpace := inp.inputCellSpace + mem'.cellCount
                  runArithRAMFuel inp fuel rest
                    { st with
                      mem := mem'
                      remainingBits := bs'
                      unitCost := st.unitCost + u + 1
                      peakCellSpace := max st.peakCellSpace cSpace }
          | .randBitLocal var idxE =>
              match st.remainingBits with
              | [] => .needMoreBits
              | bit :: bs' =>
                  let (idx, u, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE
                  let v : ℤ := if bit then 1 else 0
                  let mem' : ArithRAMMemory :=
                    { st.mem with words := st.mem.words.write (.localFrame st.frameDepth var idx) v }
                  let cSpace := inp.inputCellSpace + mem'.cellCount
                  runArithRAMFuel inp fuel rest
                    { st with
                      mem := mem'
                      remainingBits := bs'
                      unitCost := st.unitCost + u + 1
                      peakCellSpace := max st.peakCellSpace cSpace }
          | .seq s₁ s₂ =>
              runArithRAMFuel inp fuel (.stmt s₁ :: .stmt s₂ :: rest) st
          | .ite cond tBranch fBranch =>
              let (flag, u) := evalArithCond inp st.frameDepth st.mem cond
              let chosen := if flag then tBranch else fBranch
              runArithRAMFuel inp fuel (.stmt chosen :: rest) { st with unitCost := st.unitCost + u }
          | .whileLoop cond body =>
              let (flag, u) := evalArithCond inp st.frameDepth st.mem cond
              let nextStack := if flag then .stmt body :: .stmt (.whileLoop cond body) :: rest else rest
              runArithRAMFuel inp fuel nextStack { st with unitCost := st.unitCost + u }
          | .repeatN countE body =>
              let (cnt, u, _) := evalIntExpr inp.toWordView st.frameDepth st.mem.words countE
              let nIter := if 0 ≤ cnt then cnt.toNat else 0
              runArithRAMFuel inp fuel (.repeatLoop nIter body :: rest)
                { st with unitCost := st.unitCost + u }
          | .localScope body =>
              let prev := st.frameDepth
              let nextDepth := prev + 1
              let memClean := st.mem.popDepth prev
              runArithRAMFuel inp fuel (.stmt body :: .popScope prev :: rest)
                { st with mem := memClean, frameDepth := nextDepth }

/-- Unbounded execution of `prog : ArithRAMStmt` consuming the exact random bit sequence `bs`.
Returns `some out` iff `prog` halts in finitely many steps having consumed every bit of `bs`. -/
noncomputable def runArithRAMWithBits {d : ℕ} (prog : ArithRAMStmt) (inp : ArithRAMInput d)
    (initMem : ArithRAMMemory) (bs : List Bool) : Option ArithRAMExecOutcome :=
  open Classical in
  let initSt : ArithRAMExecState :=
    { mem := initMem.popDepth 0
      frameDepth := 0
      remainingBits := bs
      unitCost := 0
      peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount }
  if h : ∃ fuel : ℕ, ∃ out : ArithRAMExecOutcome,
      runArithRAMFuel inp fuel [.stmt prog] initSt = .halted out then
    match runArithRAMFuel inp (Nat.find h) [.stmt prog] initSt with
    | .halted out => some out
    | _ => none
  else
    none

/-! ### 6. Dynamic-update RAM program packages (fixed constant-time cached answer registers) -/

/-- A dynamic data structure program in the unit-cost Arithmetic-RAM model, maintaining its cached
answer in fixed registers (`heap 0 0..3` in words for returned handle and answer handles, and
`heap 0 0` in reals for exact squared distance, retrievable in `O(1)` time). -/
structure ArithRAMDynamicProgram : Type where
  initStmt : ArithRAMStmt
  updateStmt : ArithRAMStmt

/-- Read the cached diameter pair handles and exact squared distance from fixed `ArithRAMMemory`
header registers (`O(1)` constant register reads). -/
def ArithRAMDynamicProgram.readCachedAnswer (mem : ArithRAMMemory) :
    Option (ℕ × ℕ) × ℝ :=
  let hasPair := mem.words.read (.heap 0 1)
  let h₁ := mem.words.read (.heap 0 2)
  let h₂ := mem.words.read (.heap 0 3)
  let distSq := mem.reals.read (.heap 0 0)
  let pair :=
    if hasPair = 1 ∧ 0 ≤ h₁ ∧ 0 ≤ h₂ then
      some (h₁.toNat, h₂.toNat)
    else
      none
  (pair, distSq)

/-- Read the newly assigned reusable handle stored in `heap 0 0` after an insertion. -/
def ArithRAMDynamicProgram.readReturnedHandle (mem : ArithRAMMemory) : Option ℕ :=
  let h := mem.words.read (.heap 0 0)
  if 0 ≤ h then some h.toNat else none

/-- Run `initStmt` deterministically from empty memory for capacity `n` in dimension `d`. -/
noncomputable def ArithRAMDynamicProgram.evalInit (prog : ArithRAMDynamicProgram) (n d : ℕ) :
    Option ArithRAMExecOutcome :=
  let inp : ArithRAMInput d :=
    { intParams := [(n : ℤ)]
      activeHandles := ∅
      activeCoords := fun _ => 0
      extraReals := [] }
  runArithRAMWithBits prog.initStmt inp ArithRAMMemory.empty []

/-- Run `updateStmt` on one insertion (`isIns = true`, point `insPt`) or deletion (`isIns = false`,
active handle `delHandle`) with fresh random bits `bs`. -/
noncomputable def ArithRAMDynamicProgram.evalUpdate (prog : ArithRAMDynamicProgram) (n : ℕ)
    {d : ℕ} (activeHandles : Finset ℕ) (activeCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (mem : ArithRAMMemory) (isIns : Bool) (insPt : EuclideanSpace ℝ (Fin d)) (delHandle : ℕ)
    (bs : List Bool) : Option ArithRAMExecOutcome :=
  let inp : ArithRAMInput d :=
    { intParams := [(n : ℤ), if isIns then 1 else 0, if isIns then 0 else (delHandle : ℤ)]
      activeHandles := activeHandles
      activeCoords := activeCoords
      extraReals := if isIns then List.ofFn (fun i : Fin d => euclideanCoord insPt i) else [] }
  runArithRAMWithBits prog.updateStmt inp mem bs

/-- A dynamic data structure program in the finite-word and rational bit-length (`B`) `BitRAM` model,
maintaining its cached answer in fixed registers (`heap 0 0..3` for returned handle and answer
handles, and `(heap 0 4, heap 0 5)` as a constant-time reference to the exact rational squared
distance `num / den`). -/
structure BitRAMDynamicProgram : Type where
  initStmt : BitRAMStmt
  updateStmt : BitRAMStmt

/-- Read the cached diameter pair handles and exact rational squared distance `(num / den : ℝ)`
from fixed `WordStore` header registers. -/
def BitRAMDynamicProgram.readCachedAnswer (ws : WordStore) :
    Option (ℕ × ℕ) × ℝ :=
  let hasPair := ws.read (.heap 0 1)
  let h₁ := ws.read (.heap 0 2)
  let h₂ := ws.read (.heap 0 3)
  let sqNum := ws.read (.heap 0 4)
  let sqDen := ws.read (.heap 0 5)
  let pair :=
    if hasPair = 1 ∧ 0 ≤ h₁ ∧ 0 ≤ h₂ then
      some (h₁.toNat, h₂.toNat)
    else
      none
  let distSq : ℝ := if 0 < sqDen then (((sqNum : ℚ) / (sqDen : ℚ) : ℚ) : ℝ) else 0
  (pair, distSq)

/-- Read the newly assigned reusable handle stored in `heap 0 0` after an insertion. -/
def BitRAMDynamicProgram.readReturnedHandle (ws : WordStore) : Option ℕ :=
  let h := ws.read (.heap 0 0)
  if 0 ≤ h then some h.toNat else none

/-- Run `initStmt` deterministically from empty memory for capacity `n` in dimension `d`. -/
noncomputable def BitRAMDynamicProgram.evalInit (prog : BitRAMDynamicProgram) (n d : ℕ) :
    Option BitRAMExecOutcome :=
  let inp : BitRAMInput d :=
    { intParams := [(n : ℤ)]
      activeHandles := ∅
      activeRatCoords := fun _ _ => 0
      extraRats := [] }
  runBitRAMWithBits prog.initStmt inp WordStore.empty []

/-- Run `updateStmt` on rational active points and a rational insertion (`isIns = true`) or deletion
(`isIns = false`, handle `delHandle`) with fresh random bits `bs`, returning `none` if any point is
not in `ℚ^d`. -/
noncomputable def BitRAMDynamicProgram.evalUpdate (prog : BitRAMDynamicProgram) (n : ℕ)
    {d : ℕ} (activeHandles : Finset ℕ) (activeCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (ws : WordStore) (isIns : Bool) (insPt : EuclideanSpace ℝ (Fin d)) (delHandle : ℕ)
    (bs : List Bool) : Option BitRAMExecOutcome :=
  open Classical in
  if hAct : ∀ h ∈ activeHandles, (euclideanToRatPoint? (activeCoords h)).isSome then
    if isIns then
      match euclideanToRatPoint? insPt with
      | none => none
      | some qIns =>
          let ratMap : ℕ → Fin d → ℚ := fun h =>
            if hh : h ∈ activeHandles then
              (euclideanToRatPoint? (activeCoords h)).get (hAct h hh)
            else
              fun _ => 0
          let inp : BitRAMInput d :=
            { intParams := [(n : ℤ), 1, 0]
              activeHandles := activeHandles
              activeRatCoords := ratMap
              extraRats := List.ofFn qIns }
          runBitRAMWithBits prog.updateStmt inp ws bs
    else
      let ratMap : ℕ → Fin d → ℚ := fun h =>
        if hh : h ∈ activeHandles then
          (euclideanToRatPoint? (activeCoords h)).get (hAct h hh)
        else
          fun _ => 0
      let inp : BitRAMInput d :=
        { intParams := [(n : ℤ), 0, (delHandle : ℤ)]
          activeHandles := activeHandles
          activeRatCoords := ratMap
          extraRats := [] }
      runBitRAMWithBits prog.updateStmt inp ws bs
  else
    none

/-! ### 7. Suppressed polynomial factor conventions (`poly_c(d, L)`, `poly(B)`) -/

/-- Univariate polynomial upper bound `f(x) ≤ C (x + 1)^deg`. -/
def IsBoundedByPoly1 (f : ℕ → ℝ) : Prop :=
  ∃ (C : ℝ) (deg : ℕ), 0 ≤ C ∧
    ∀ x : ℕ, f x ≤ C * ((x + 1 : ℝ) ^ deg)

/-- Bivariate polynomial factor `poly_c(d, L)`: `f(d, L) ≤ C (d + 1)^deg (L + 1)^deg` whose degree
and constant may depend on fixed approximation and space parameters when quantified after them, with
no hidden dependence on `n`. -/
def IsBoundedByPoly2 (f : ℕ → ℕ → ℝ) : Prop :=
  ∃ (C : ℝ) (deg : ℕ), 0 ≤ C ∧
    ∀ d L : ℕ, f d L ≤ C * ((d + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg)

/-- Trivariate polynomial factor `poly_c(d, B, L)`: `f(d, B, L) ≤ C (d + 1)^deg (B + 1)^deg (L + 1)^deg`
for rational implementations with polynomial dependence on `B` and no hidden power of `n`. -/
def IsBoundedByPoly3 (f : ℕ → ℕ → ℕ → ℝ) : Prop :=
  ∃ (C : ℝ) (deg : ℕ), 0 ≤ C ∧
    ∀ d B L : ℕ, f d B L ≤ C * ((d + 1 : ℝ) ^ deg) * ((B + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg)

end UL
