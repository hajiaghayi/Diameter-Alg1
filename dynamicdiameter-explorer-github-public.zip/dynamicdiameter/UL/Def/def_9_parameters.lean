import Mathlib
import UL.Def.def_explicit_tradeoff_curve
import UL.Def.def_6_search_exponents
set_option autoImplicit false

/-! Definition (Sec. 9: Standing parameters and explicit tradeoff exponent) (paper p.38). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- Level count `L = ⌈log_2(2n)⌉` for Section 9 (with capacity `n ≥ 2`), reusing `g_c`, `rho_c`,
and `Q_c` from `UL.Def.def_explicit_tradeoff_curve`. -/
def L_n (n : ℕ) : ℕ :=
  Nat.clog 2 (2 * n)

end UL
