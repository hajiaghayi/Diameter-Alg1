import Mathlib
import UL.Def.def_halfspace_depth
set_option autoImplicit false

/-! Definition (Appendix A: α-net for halfspaces) (paper p.44). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- A finite subset of sampled identities `S ⊆ ι` is an `α`-net for halfspaces of a finite
indexed point population `P : ι → ℝ^D` if `S` meets every closed halfspace `H` in `ℝ^D`
containing at least an `α` fraction of `P` (counting point identities with multiplicity). -/
def IsHalfspaceNet {D : ℕ} {ι : Type*} [Fintype ι]
    (α : ℝ) (P : ι → EuclideanSpace ℝ (Fin D)) (S : Finset ι) : Prop :=
  ∀ H : Set (EuclideanSpace ℝ (Fin D)),
    IsClosedHalfspace H →
    α * (Fintype.card ι : ℝ) ≤ (pointCount P H : ℝ) →
    ∃ i ∈ S, P i ∈ H

/-- An indexed sample of identities `sample : κ → ι` (allowing repeated draws) is an `α`-net for
halfspaces of a finite indexed point population `P : ι → ℝ^D` if at least one sampled identity
lies in every closed halfspace `H` in `ℝ^D` containing at least an `α` fraction of `P`
(counting point identities with multiplicity). -/
def IsIndexedHalfspaceNet {D : ℕ} {ι κ : Type*} [Fintype ι]
    (α : ℝ) (P : ι → EuclideanSpace ℝ (Fin D)) (sample : κ → ι) : Prop :=
  ∀ H : Set (EuclideanSpace ℝ (Fin D)),
    IsClosedHalfspace H →
    α * (Fintype.card ι : ℝ) ≤ (pointCount P H : ℝ) →
    ∃ j : κ, P (sample j) ∈ H

end UL
