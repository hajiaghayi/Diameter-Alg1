import Mathlib
set_option autoImplicit false

/-! Definition (Sec. 6: The two search exponents) (paper p.21). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- Base search exponent `I_h(x) = (1 + x^2 - 2hx) / (1 - h^2)` for `0 < h < 1` and `x ∈ [h, 1]`. -/
noncomputable def I_h (h x : ℝ) : ℝ :=
  (1 + x ^ 2 - 2 * h * x) / (1 - h ^ 2)

/-- Update search exponent `u = I_h(x) - 1` (equal to `(x - h)^2 / (1 - h^2)` for `0 < h < 1`). -/
noncomputable def u_search (h x : ℝ) : ℝ :=
  I_h h x - 1

/-- Query search exponent `q = I_h(x) - x^2` (equal to `(1 - hx)^2 / (1 - h^2)` for `0 < h < 1`). -/
noncomputable def q_search (h x : ℝ) : ℝ :=
  I_h h x - x ^ 2

/-- Upper endpoint `ρ_h = (1 - h) / (1 + h)` of the update exponent range for `0 < h < 1`. -/
noncomputable def rho_h (h : ℝ) : ℝ :=
  (1 - h) / (1 + h)

/-- Angular tradeoff curve `q_h(u) = (√(1 - h^2) - h√u)^2` for `0 < h < 1` and `0 ≤ u ≤ ρ_h`. -/
noncomputable def q_h (h u : ℝ) : ℝ :=
  (Real.sqrt (1 - h ^ 2) - h * Real.sqrt u) ^ 2

end UL
