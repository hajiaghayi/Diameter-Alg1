import Mathlib
set_option autoImplicit false

/-! Definition (Sec. 6: The search interface) (paper p.21). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- A vector `v ∈ ℝ^d` (`EuclideanSpace ℝ (Fin d)`) is a unit vector if `‖v‖ = 1`. -/
def IsUnitVec {d : ℕ} (v : EuclideanSpace ℝ (Fin d)) : Prop :=
  ‖v‖ = 1

/-- Fixed initial point-set specification of a search generation in `ℝ^d`: a finite nonempty
indexed set `P₀` of `m = |P₀| ≥ 1` unit vectors `pts : ι → ℝ^d`, fixed before the generation's
random choices, together with the positive correlation threshold `0 < h < 1`. -/
structure SearchGeneration (ι : Type*) (d : ℕ) where
  P₀ : Finset ι
  pts : ι → EuclideanSpace ℝ (Fin d)
  nonempty : P₀.Nonempty
  unit_pts : ∀ i ∈ P₀, IsUnitVec (pts i)
  h : ℝ
  h_pos : 0 < h
  h_lt_one : h < 1

/-- Initial size `m = |P₀|` of a search generation. -/
def SearchGeneration.m {ι : Type*} {d : ℕ} (gen : SearchGeneration ι d) : ℕ :=
  gen.P₀.card

/-- A finite set of identities `P` is a valid surviving subset of active (current) points after
deletions of members of `P₀` if `P ⊆ P₀`. -/
def SearchGeneration.IsSurvivingSubset {ι : Type*} {d : ℕ}
    (gen : SearchGeneration ι d) (P : Finset ι) : Prop :=
  P ⊆ gen.P₀

/-- A search query in `ℝ^d` over identity type `ι`: supplies a unit vector `z ∈ ℝ^d` and an exact
acceptance test `accept : ι → Prop` (representing acceptance in the original geometry). -/
structure SearchQuery (ι : Type*) (d : ℕ) where
  z : EuclideanSpace ℝ (Fin d)
  unit_z : IsUnitVec z
  accept : ι → Prop

/-- An identity `i` is a target among the current points `P` for query vector `z` at threshold `h`
if `i ∈ P` and `⟪pts i, z⟫ ≥ h`. -/
def IsSearchTarget {ι : Type*} {d : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P : Finset ι) (h : ℝ)
    (z : EuclideanSpace ℝ (Fin d)) (i : ι) : Prop :=
  i ∈ P ∧ h ≤ inner ℝ (pts i) z

/-- Existence of a target among the current points `P` for query vector `z` at threshold `h`. -/
def HasSearchTarget {ι : Type*} {d : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P : Finset ι) (h : ℝ)
    (z : EuclideanSpace ℝ (Fin d)) : Prop :=
  ∃ i, IsSearchTarget pts P h z i

/-- Compatibility of an acceptance test `accept` with query vector `z` on point set `P`:
every rejected point `i ∈ P` satisfies `⟪pts i, z⟫ ≤ 0`. -/
def IsCompatibleTest {ι : Type*} {d : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P : Finset ι)
    (z : EuclideanSpace ℝ (Fin d)) (accept : ι → Prop) : Prop :=
  ∀ i ∈ P, ¬ accept i → inner ℝ (pts i) z ≤ 0

/-- Stronger `δ`-margin compatibility of an acceptance test `accept` with query vector `z` on
point set `P` (used by the certified construction): `δ > 0` and every rejected point `i ∈ P`
satisfies `⟪pts i, z⟫ ≤ -δ`. -/
def IsMarginCompatibleTest {ι : Type*} {d : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P : Finset ι) (δ : ℝ)
    (z : EuclideanSpace ℝ (Fin d)) (accept : ι → Prop) : Prop :=
  0 < δ ∧ ∀ i ∈ P, ¬ accept i → inner ℝ (pts i) z ≤ -δ

/-- A search answer `ans : Option ι` (`some i` for a returned identity, `none` for `NONE` when the
search finds none) is a valid required answer on current set `P` for acceptance test `accept` if
every returned identity `some i` is an accepted current identity (`i ∈ P ∧ accept i`). -/
def IsValidSearchAnswer {ι : Type*}
    (P : Finset ι) (accept : ι → Prop) (ans : Option ι) : Prop :=
  match ans with
  | some i => i ∈ P ∧ accept i
  | none => True

/-- Full correctness of a search answer `ans : Option ι` on current set `P`: `ans` is an accepted
current identity or `NONE`, and `NONE` (`ans = none`) implies that no target exists in `P`. -/
def IsCorrectSearchAnswer {ι : Type*} {d : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P : Finset ι) (h : ℝ)
    (z : EuclideanSpace ℝ (Fin d)) (accept : ι → Prop) (ans : Option ι) : Prop :=
  IsValidSearchAnswer P accept ans ∧ (ans = none → ¬ HasSearchTarget pts P h z)

/-- Target predicate on a `SearchGeneration` and `SearchQuery`. -/
def SearchGeneration.IsTarget {ι : Type*} {d : ℕ}
    (gen : SearchGeneration ι d) (P : Finset ι) (q : SearchQuery ι d) (i : ι) : Prop :=
  IsSearchTarget gen.pts P gen.h q.z i

/-- Target-existence predicate on a `SearchGeneration` and `SearchQuery`. -/
def SearchGeneration.HasTarget {ι : Type*} {d : ℕ}
    (gen : SearchGeneration ι d) (P : Finset ι) (q : SearchQuery ι d) : Prop :=
  HasSearchTarget gen.pts P gen.h q.z

/-- Compatibility of `q : SearchQuery ι d` on point set `P` in `gen : SearchGeneration ι d`. -/
def SearchGeneration.IsCompatible {ι : Type*} {d : ℕ}
    (gen : SearchGeneration ι d) (P : Finset ι) (q : SearchQuery ι d) : Prop :=
  IsCompatibleTest gen.pts P q.z q.accept

/-- Stronger `δ`-margin compatibility of `q : SearchQuery ι d` on point set `P` in
`gen : SearchGeneration ι d`. -/
def SearchGeneration.IsMarginCompatible {ι : Type*} {d : ℕ}
    (gen : SearchGeneration ι d) (P : Finset ι) (δ : ℝ) (q : SearchQuery ι d) : Prop :=
  IsMarginCompatibleTest gen.pts P δ q.z q.accept

/-- Valid required answer (`some i` an accepted current identity in `P`, or `none` for `NONE`)
for `q : SearchQuery ι d`. -/
def SearchQuery.IsValidAnswer {ι : Type*} {d : ℕ}
    (q : SearchQuery ι d) (P : Finset ι) (ans : Option ι) : Prop :=
  IsValidSearchAnswer P q.accept ans

/-- On a generation's correctness event `E : Set Ω` (where `gen` is fixed prior to the random
draw `ω : Ω`), `NONE` (`ans ω = none`) implies that no target exists in `P`. -/
def SearchGeneration.CorrectOnEvent {Ω ι : Type*} {d : ℕ}
    (gen : SearchGeneration ι d) (P : Finset ι) (q : SearchQuery ι d)
    (ans : Ω → Option ι) (E : Set Ω) : Prop :=
  ∀ ω ∈ E, ans ω = none → ¬ gen.HasTarget P q

/-- Full answer correctness (`IsCorrectSearchAnswer`) on `gen : SearchGeneration ι d` and
`q : SearchQuery ι d`. -/
def SearchGeneration.IsCorrectAnswer {ι : Type*} {d : ℕ}
    (gen : SearchGeneration ι d) (P : Finset ι) (q : SearchQuery ι d) (ans : Option ι) : Prop :=
  IsCorrectSearchAnswer gen.pts P gen.h q.z q.accept ans

end UL
