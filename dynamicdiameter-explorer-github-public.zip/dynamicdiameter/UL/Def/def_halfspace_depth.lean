import Mathlib
set_option autoImplicit false

/-! Definition (Sec. 4: Halfspace depth and α-centerpoint) (paper p.14). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

open Classical in
/-- Number of indices (identities) in a finite indexed point family `Q : ι → ℝ^k` whose point
lies in `S`, counting coincidences of coordinates with multiplicity. -/
noncomputable def pointCount {k : ℕ} {ι : Type*} [Fintype ι]
    (Q : ι → EuclideanSpace ℝ (Fin k)) (S : Set (EuclideanSpace ℝ (Fin k))) : ℕ :=
  (Finset.univ.filter (fun i : ι => Q i ∈ S)).card

/-- A closed affine halfspace in `ℝ^k`: `{x ∈ ℝ^k | ⟨v, x⟩ ≤ β}` (equivalently `≥` by negating
`v` and `β`) for some nonzero normal vector `v ≠ 0` and scalar threshold `β ∈ ℝ`. -/
def IsClosedHalfspace {k : ℕ} (H : Set (EuclideanSpace ℝ (Fin k))) : Prop :=
  ∃ v : EuclideanSpace ℝ (Fin k), v ≠ 0 ∧ ∃ β : ℝ, H = {x | inner ℝ v x ≤ β}

/-- Halfspace depth (Tukey depth) `depth_Q(z)` of `z ∈ ℝ^k` with respect to a finite indexed
point family `Q : ι → ℝ^k`: the minimum of `|Q ∩ H|` (counted with index multiplicity) over all
closed halfspaces `H` in `ℝ^k` containing `z`. -/
noncomputable def halfspaceDepth {k : ℕ} {ι : Type*} [Fintype ι]
    (Q : ι → EuclideanSpace ℝ (Fin k)) (z : EuclideanSpace ℝ (Fin k)) : ℕ :=
  sInf {n : ℕ | ∃ H : Set (EuclideanSpace ℝ (Fin k)),
    IsClosedHalfspace H ∧ z ∈ H ∧ n = pointCount Q H}

/-- A point `z ∈ ℝ^k` is an `α`-centerpoint of the finite indexed point family `Q : ι → ℝ^k`
if its halfspace depth `depth_Q(z)` is at least `α |Q|`. -/
def IsCenterpoint {k : ℕ} {ι : Type*} [Fintype ι]
    (α : ℝ) (Q : ι → EuclideanSpace ℝ (Fin k)) (z : EuclideanSpace ℝ (Fin k)) : Prop :=
  α * (Fintype.card ι : ℝ) ≤ (halfspaceDepth Q z : ℝ)

end UL
