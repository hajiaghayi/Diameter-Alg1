import Mathlib
import UL.Def.def_node_chain_blocks
set_option autoImplicit false

/-! Definition (Sec. 5.1: Node maximum radius R_S and baseline condition (2)) (paper p.16). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- Current squared Euclidean radius `‖p - o‖^2` of a point `p ∈ ℝ^d` relative to a node center
`o ∈ ℝ^d`. -/
noncomputable def nodeRadiusSq {d : ℕ} (o p : EuclideanSpace ℝ (Fin d)) : ℝ :=
  ‖p - o‖ ^ 2

/-- Node maximum radius `R_S = max_{i ∈ S} ‖pts i - o‖` of a finite active indexed input set
`S : Finset ι` (with point coordinates `pts : ι → ℝ^d`) relative to node center `o ∈ ℝ^d`,
equal to `0` when `S = ∅`. -/
noncomputable def nodeMaxRadius {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S : Finset ι) : ℝ :=
  if h : S.Nonempty then
    S.sup' h (fun i => ‖pts i - o‖)
  else
    0

/-- Node maximum radius `R_S = max_{i ∈ S} ‖pts i - N.o‖` of active input set `S` at a
`ChainNode` `N` (`0` when `S = ∅`). -/
noncomputable def ChainNode.maxRadius {d : ℕ} {ι : Type*}
    (N : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) : ℝ :=
  nodeMaxRadius pts N.o S

/-- An active identity `y` in `S` is a point with maximum radius `R_S` relative to center `o` when
`y ∈ S` and `‖pts y - o‖ = nodeMaxRadius pts o S`. -/
def IsNodeMaxRadiusPoint {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S : Finset ι) (y : ι) : Prop :=
  y ∈ S ∧ ‖pts y - o‖ = nodeMaxRadius pts o S

/-- An active identity `y` in `S` attains the maximum radius `N.maxRadius pts S` at a
`ChainNode` `N`. -/
def ChainNode.IsMaxRadiusPoint {d : ℕ} {ι : Type*}
    (N : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) (y : ι) : Prop :=
  IsNodeMaxRadiusPoint pts N.o S y

/-- Baseline length condition (Equation (2)): when `S.Nonempty`, Euclidean distance `L ≥ 0`
satisfies `L^2 ≥ V + R_S^2`, where `R_S = nodeMaxRadius pts o S`; when `S = ∅`, `L = 0`. -/
def SatisfiesBaselineLengthCond {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) (L : ℝ) : Prop :=
  if S.Nonempty then
    0 ≤ L ∧ L ^ 2 ≥ V + (nodeMaxRadius pts o S) ^ 2
  else
    L = 0

/-- An active pair `(u, v)` in `S` satisfies baseline condition (2) at center `o` and variance `V`
when `u ∈ S`, `v ∈ S`, and its Euclidean distance `L = ‖pts u - pts v‖` satisfies
`L^2 ≥ V + R_S^2` (`R_S = nodeMaxRadius pts o S`).
When `|S| = 1` and `V = 0` with `S = {y}` and `pts y = o`, `(y, y)` has `L = 0` and satisfies
`L^2 ≥ V + R_S^2`; whenever `V + R_S^2 > 0`, any witness pair `(u, v)` has `‖pts u - pts v‖^2 > 0`
and hence `u ≠ v` (two distinct active identities in `S`). -/
def IsNodeBaselinePair {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) (u v : ι) : Prop :=
  u ∈ S ∧ v ∈ S ∧ ‖pts u - pts v‖ ^ 2 ≥ V + (nodeMaxRadius pts o S) ^ 2

/-- An active pair `(u, v)` in `S` satisfies baseline condition (2) at a `ChainNode` `N`
(center `N.o ∈ ℝ^d`, variance `N.V ≥ 0`). -/
def ChainNode.IsBaselinePair {d : ℕ} {ι : Type*}
    (N : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) (u v : ι) : Prop :=
  IsNodeBaselinePair pts N.o N.V S u v

/-- Euclidean length `L ≥ 0` of a maintained optional pair `pair : Option (ι × ι)`: `0` when
`pair = none` (the `S = ∅` case), and `‖pts u - pts v‖` when `pair = some (u, v)`. -/
noncomputable def baselinePairLength {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) : Option (ι × ι) → ℝ
  | none => 0
  | some (u, v) => ‖pts u - pts v‖

/-- Structural active-pair invariant on finite input set `S`: `none` when `S = ∅`, and
`some (u, v)` with `u ∈ S` and `v ∈ S` when `S ≠ ∅`. -/
def IsActiveNodePair {ι : Type*} (S : Finset ι) : Option (ι × ι) → Prop
  | none => S = ∅
  | some (u, v) => u ∈ S ∧ v ∈ S

/-- Maintained baseline condition at center `o` and variance `V` on finite active input set `S`:
`pair` is an `IsActiveNodePair S pair` (`none` with `R_S = 0` and `L = 0` when `S = ∅`;
`some (u, v)` with `u, v ∈ S` and `L = ‖pts u - pts v‖` when `S.Nonempty`), and whenever
`S.Nonempty`, its length `L = baselinePairLength pts pair` satisfies Equation (2):
`L^2 ≥ V + R_S^2` (`R_S = nodeMaxRadius pts o S`). -/
def SatisfiesNodeBaselineCond {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (S : Finset ι) (pair : Option (ι × ι)) : Prop :=
  IsActiveNodePair S pair ∧
    (S.Nonempty → (baselinePairLength pts pair) ^ 2 ≥ V + (nodeMaxRadius pts o S) ^ 2)

/-- Maintained baseline condition at a `ChainNode` `N` (center `N.o ∈ ℝ^d`, variance `N.V ≥ 0`) on
finite active input set `S` (`pair = none` when `S = ∅`, and `pair = some (u, v)` with `u, v ∈ S`
and `‖pts u - pts v‖^2 ≥ N.V + (N.maxRadius pts S)^2` when `S.Nonempty`). -/
def ChainNode.SatisfiesBaselineCond {d : ℕ} {ι : Type*}
    (N : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι)
    (pair : Option (ι × ι)) : Prop :=
  SatisfiesNodeBaselineCond pts N.o N.V S pair

end UL
