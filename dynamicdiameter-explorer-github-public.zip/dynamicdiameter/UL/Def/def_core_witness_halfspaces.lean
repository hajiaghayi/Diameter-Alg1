import Mathlib
import UL.Def.def_paraboloid_lift_variance
set_option autoImplicit false

/-! Definition (Sec. 4: Core ball, variance witness, and lifted halfspaces) (paper p.15). Definitions only: no theorems, no notation, no axioms.
Prefer Mathlib's own notions; define something here only when Mathlib lacks it. -/

namespace UL

/-- The core ball `B(o, √V)` in `ℝ^d`: the closed Euclidean ball centered at `o` of radius `√V`. -/
noncomputable def coreBall {d : ℕ} (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) :
    Set (EuclideanSpace ℝ (Fin d)) :=
  Metric.closedBall o (Real.sqrt V)

/-- A point `p ∈ ℝ^d` is a variance witness for a query `q ∈ ℝ^d` (relative to center `o` and
variance `V`) if `‖p - q‖^2 ≥ V + ‖q - o‖^2`. -/
def IsVarianceWitness {d : ℕ} (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (q p : EuclideanSpace ℝ (Fin d)) : Prop :=
  ‖p - q‖ ^ 2 ≥ V + ‖q - o‖ ^ 2

/-- The lifted core halfspace `H_core = {(x, h) ∈ ℝ^{d+1} : h - 2⟨o, x⟩ ≤ s - 2‖o‖^2}`. -/
def coreHalfspace {d : ℕ} (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    Set (EuclideanSpace ℝ (Fin (d + 1))) :=
  {w | liftedHeight w - 2 * inner ℝ o (liftedBase w) ≤ s - 2 * ‖o‖ ^ 2}

/-- The lifted witness halfspace `H_q = {(x, h) ∈ ℝ^{d+1} : h - 2⟨q, x⟩ ≥ s - 2⟨q, o⟩}` for a
query `q ∈ ℝ^d`. -/
def witnessHalfspace {d : ℕ} (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (q : EuclideanSpace ℝ (Fin d)) : Set (EuclideanSpace ℝ (Fin (d + 1))) :=
  {w | liftedHeight w - 2 * inner ℝ q (liftedBase w) ≥ s - 2 * inner ℝ q o}

end UL
