import Mathlib
import UL.Stmt.clm_5_3_matching_invariant
set_option autoImplicit false

namespace UL

theorem W_clm_5_3_matching_invariant :
    ∃ (d : ℕ) (ι : Type)
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (o : EuclideanSpace ℝ (Fin d))
      (V : ℝ)
      (e γ lam : ℚ)
      (K : ℤ)
      (j k ℓ : ℕ),
      0 < V ∧
      0 < e ∧
      1 < γ ∧
      1 < lam ∧
      IsRetainedConfig e γ lam K V j k ℓ := by
  refine ⟨1, Fin 1, fun _ => 0, 0, 1, 1, 6 / 5, 3, 1, 1, 1, 1,
    by norm_num, by norm_num, by norm_num, by norm_num, ?_⟩
  have hm0 : shellSubdiv (1 : ℚ) = 1 := by
    norm_num [shellSubdiv]
  refine ⟨?_, ?_⟩
  · rw [hm0]
    refine ⟨le_rfl, le_rfl, le_rfl, by norm_num, ?_⟩
    unfold scaleCutoffIndex
    apply le_csInf
    · exact ⟨2, by norm_num⟩
    · intro n hn
      by_contra hlt
      have hn0 : n = 0 := by omega
      subst hn0
      norm_num at hn
  · rw [hm0]
    simp only [SatisfiesRetentionCond, shellRadius, distScale, Real.sqrt_one]
    norm_num

end UL
