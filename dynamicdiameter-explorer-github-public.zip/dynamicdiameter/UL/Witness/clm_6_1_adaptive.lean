import UL.Stmt.clm_6_1_adaptive
set_option autoImplicit false

namespace UL

theorem W_clm_6_1_adaptive :
    ∃ h_min : ℝ, ∃ h_max : ℝ, ∃ ℓ : ℕ,
      (0 < h_min) ∧ (h_min ≤ h_max) ∧ (h_max < 1) ∧ (1 ≤ ℓ) :=
  ⟨1 / 4, 3 / 4, 1, by norm_num⟩

end UL
