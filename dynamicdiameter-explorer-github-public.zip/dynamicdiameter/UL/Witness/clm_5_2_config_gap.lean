import UL.Stmt.clm_5_2_config_gap
set_option autoImplicit false

namespace UL

theorem W_clm_5_2_config_gap :
    ∃ (e γ lam : ℚ) (K : ℤ) (V : ℝ) (j k ℓ : ℕ),
      0 < e ∧
      1 < γ ∧
      1 < lam ∧
      0 < V ∧
      IsRetainedConfig e γ lam K V j k ℓ := by
  refine ⟨1, 6 / 5, 3, 1, 1, 1, 1, 1, by norm_num, by norm_num, by norm_num, by norm_num, ?_⟩
  have hm0 : shellSubdiv 1 = 1 := by
    simp [shellSubdiv]
  have hJ : 1 ≤ scaleCutoffIndex 3 1 := by
    unfold scaleCutoffIndex
    have hne : ({ℓ : ℕ | ((1 : ℤ) : ℝ) + 1 ≤ ((3 : ℚ) : ℝ) ^ ℓ / 2}).Nonempty :=
      ⟨2, by norm_num⟩
    have hmem := Nat.sInf_mem hne
    by_contra hlt
    have hzero : sInf {ℓ : ℕ | ((1 : ℤ) : ℝ) + 1 ≤ ((3 : ℚ) : ℝ) ^ ℓ / 2} = 0 := by omega
    rw [hzero] at hmem
    norm_num at hmem
  unfold IsRetainedConfig IsShellConfig SatisfiesRetentionCond shellRadius distScale
  rw [hm0]
  refine ⟨⟨le_rfl, le_rfl, le_rfl, by norm_num, hJ⟩, ?_⟩
  simp only [Real.sqrt_one]
  constructor <;> norm_num

end UL
