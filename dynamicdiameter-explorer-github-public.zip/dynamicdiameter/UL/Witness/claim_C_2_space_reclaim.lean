import UL.Stmt.claim_C_2_space_reclaim
set_option autoImplicit false

namespace UL

theorem W_claim_C_2_space_reclaim :
    ∃ (P_α : ℕ → ℕ → ℝ), ∃ (P_cfg : ℕ → ℕ → ℝ), ∃ (P_int : ℕ → ℕ → ℝ),
      IsBoundedByPoly2 P_α ∧
      (IsBoundedByPoly2 P_cfg ∧
      IsBoundedByPoly2 P_int) :=
  ⟨fun _ _ => 1, fun _ _ => 1, fun _ _ => 1,
    ⟨1, 0, by norm_num, fun _ _ => by norm_num⟩,
    ⟨⟨1, 0, by norm_num, fun _ _ => by norm_num⟩,
      ⟨1, 0, by norm_num, fun _ _ => by norm_num⟩⟩⟩

end UL
