import UL.Stmt.claim_A_2_deletion_witness
set_option autoImplicit false

namespace UL

theorem W_claim_A_2_deletion_witness :
    ∃ (d : ℕ) (s₀ : ℕ) (ι : Type)
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (P₀ : Finset ι)
      (o : EuclideanSpace ℝ (Fin d))
      (s : ℝ)
      (k : ℕ)
      (certs : Fin k → BlockCertificate pts P₀ (liftedPoint o s)),
      (1 ≤ d) ∧
      (1 ≤ s₀) ∧
      (2 * s₀ ≤ P₀.card) ∧
      (∀ p ∈ P₀, ∃ q : Fin d → ℚ, ratPointToEuclidean q = pts p) ∧
      ((P₀.card : ℝ) / (4 * (s₀ : ℝ)) ≤ (k : ℝ)) ∧
      (∀ i : Fin k, (certs i).B.card = s₀) ∧
      (∀ i j : Fin k, i ≠ j → Disjoint (certs i).B (certs j).B) := by
  let P₀ : Finset (Fin 2) := {0, 1}
  have hcardP₀ : P₀.card = 2 := by decide
  let cert0 : BlockCertificate (fun _ : Fin 2 => (0 : EuclideanSpace ℝ (Fin 1))) P₀
      (liftedPoint (0 : EuclideanSpace ℝ (Fin 1)) 0) :=
    { B := {0}
      coeff := fun _ => 1
      subset_birth := by decide
      coeff_nonneg := by
        intro _ _
        norm_num
      sum_coeff := by simp
      sum_lift := by simp [paraboloidLift] }
  refine ⟨1, 1, Fin 2, fun _ => 0, P₀, 0, 0, 1, fun _ => cert0,
    le_rfl, le_rfl, ?_, ?_, ?_, ?_, ?_⟩
  · omega
  · intro _ _
    refine ⟨0, ?_⟩
    ext i
    simp [ratPointToEuclidean]
  · rw [hcardP₀]
    norm_num
  · intro _
    simp [cert0]
  · intro i j hij
    exact False.elim (hij (Subsingleton.elim i j))

end UL
