import UL.Stmt.clm_5_1_block_witness
set_option autoImplicit false

namespace UL

theorem W_clm_5_1_block_witness :
    ∃ (d : ℕ) (ι : Type) (_ : DecidableEq ι)
      (pts : ι → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ι)
      (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
      (β : ℝ) (r₀ : ℕ)
      (certs : Fin r₀ → BlockCertificate pts P₀ (liftedPoint o s)),
      0 < β * (P₀.card : ℝ) ∧
      β * (P₀.card : ℝ) ≤ (r₀ : ℝ) ∧
      Pairwise (fun j₁ j₂ : Fin r₀ => Disjoint (certs j₁).B (certs j₂).B) := by
  refine ⟨1, PUnit, inferInstance, fun _ => 0, {PUnit.unit}, 0, 0, 1, 1,
    fun _ =>
      { B := {PUnit.unit}
        coeff := fun _ => 1
        subset_birth := Finset.Subset.refl _
        coeff_nonneg := fun _ _ => by norm_num
        sum_coeff := by simp
        sum_lift := by simp [paraboloidLift] },
    by simp, by simp, ?_⟩
  intro j₁ j₂ hne
  exact False.elim (hne (Subsingleton.elim j₁ j₂))

end UL
