import UL.Stmt.claim_C_3_sync_suffix
set_option autoImplicit false

namespace UL

theorem W_claim_C_3_sync_suffix :
    ∃ (P_α : ℕ → ℝ), ∃ (P_node : ℕ → ℕ → ℕ → ℝ),
      IsBoundedByPoly1 P_α ∧
      ((∀ d : ℕ, 1 ≤ P_α d) ∧
      (IsBoundedByPoly3 P_node ∧
      (∀ d B L : ℕ, 0 ≤ P_node d B L))) :=
  ⟨fun _ => 1, fun _ _ _ => 0,
    ⟨1, 0, by norm_num, fun _ => by norm_num⟩,
    ⟨fun _ => le_rfl,
    ⟨⟨0, 0, by norm_num, fun _ _ _ => by norm_num⟩,
      fun _ _ _ => le_rfl⟩⟩⟩

end UL
