import Mathlib
import UL.Stmt.cit_centerpoint_thm
set_option autoImplicit false

namespace UL

theorem W_cit_centerpoint_thm :
    ∃ (D : ℕ) (ι : Type) (_ : Fintype ι) (P : ι → EuclideanSpace ℝ (Fin D)),
      1 ≤ D ∧ Nonempty ι :=
  ⟨1, Fin 1, inferInstance, fun _ => 0, le_rfl, inferInstance⟩

end UL
