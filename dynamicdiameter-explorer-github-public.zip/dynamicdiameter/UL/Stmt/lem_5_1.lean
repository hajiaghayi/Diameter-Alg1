import Mathlib
import UL.Def.def_halfspace_depth
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_core_witness_halfspaces
set_option autoImplicit false

namespace UL

/-- Lemma 5.1 (paper p.16). Exactly the paper's statement, as a Prop. -/
def S_lem_5_1 : Prop :=
  ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
    (p : ι → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ι)
    (hm : 1 ≤ P₀.card) (α : ℝ) (hα : 0 < α)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (hdepth : α * (P₀.card : ℝ) ≤
      (halfspaceDepth (paraboloidLiftSet (fun i : P₀ => p i.1)) (liftedPoint o s) : ℝ)),
    let V := liftVariance o s
    let m : ℝ := P₀.card
    α * m ≤ (pointCount (fun i : P₀ => p i.1) (coreBall o V) : ℝ) ∧
    (∀ q : EuclideanSpace ℝ (Fin d),
      α * m ≤ (pointCount (fun i : P₀ => p i.1) {x | IsVarianceWitness o V q x} : ℝ)) ∧
    (∀ (a : ℕ) (ops : List (ι ⊕ ι)),
      (ops.filter Sum.isRight).length ≤ a →
      let S := ops.foldl (fun acc op =>
        match op with
        | Sum.inl j => insert j acc
        | Sum.inr j => acc.erase j) P₀
      α * m - (a : ℝ) ≤ (pointCount (fun i : ↥(P₀ ∩ S) => p i.1) (coreBall o V) : ℝ) ∧
      α * m - (a : ℝ) ≤
        (pointCount (fun i : ↥(P₀ ∩ S) => p i.1) {x | ‖x - o‖ ^ 2 ≤ V} : ℝ) ∧
      (∀ q : EuclideanSpace ℝ (Fin d),
        α * m - (a : ℝ) ≤
          (pointCount (fun i : ↥(P₀ ∩ S) => p i.1) {x | IsVarianceWitness o V q x} : ℝ)) ∧
      α * m - (a : ℝ) ≤ (pointCount (fun i : S => p i.1) (coreBall o V) : ℝ) ∧
      α * m - (a : ℝ) ≤
        (pointCount (fun i : S => p i.1) {x | ‖x - o‖ ^ 2 ≤ V} : ℝ) ∧
      (∀ q : EuclideanSpace ℝ (Fin d),
        α * m - (a : ℝ) ≤
          (pointCount (fun i : S => p i.1) {x | IsVarianceWitness o V q x} : ℝ)))

end UL
