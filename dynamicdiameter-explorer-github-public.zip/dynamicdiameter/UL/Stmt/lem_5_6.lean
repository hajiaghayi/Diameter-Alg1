import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_paraboloid_lift_variance
set_option autoImplicit false

namespace UL

/-- Lemma 5.6 (paper p.20). Exactly the paper's statement, as a Prop. -/
def S_lem_5_6 : Prop :=
  ∃ (progBit : BitRAMStmt) (progArith : ArithRAMStmt) (C deg : ℕ),
    ∀ (a b : ℚ) (g : ℝ) (e : ℚ),
      0 ≤ b →
      b < a →
      a ≤ 1 →
      0 < g →
      g ≤ (a : ℝ) - (1 + g) * (b : ℝ) →
      0 < e →
      (e : ℝ) ≤ g / 16 →
      let L_b : ℕ := ratBitLength b
      let L_e : ℕ := Nat.ceil (Real.log (1 / (e : ℝ)))
      let bound : ℕ := C * (L_b + L_e + 1) ^ deg
      let inpBit : BitRAMInput 0 :=
        { intParams := [(Nat.ceil (1 / e) : ℤ)]
          activeHandles := ∅
          activeRatCoords := fun _ i => Fin.elim0 i
          extraRats := [b] }
      let inpArith : ArithRAMInput 0 :=
        { intParams := [b.num, (b.den : ℤ), e.num, (e.den : ℤ)]
          activeHandles := ∅
          activeCoords := fun _ => 0
          extraReals := [] }
      ∃ (outBit : BitRAMExecOutcome) (outArith : ArithRAMExecOutcome),
        runBitRAMWithBits progBit inpBit WordStore.empty [] = some outBit ∧
        outBit.unitCost ≤ bound ∧
        outBit.bitCost ≤ bound ∧
        outBit.peakCellSpace ≤ bound ∧
        outBit.peakBitSpace ≤ bound ∧
        runArithRAMWithBits progArith inpArith ArithRAMMemory.empty [] = some outArith ∧
        outArith.unitCost ≤ bound ∧
        outArith.peakCellSpace ≤ bound ∧
        let A_num : ℤ := outBit.words.read (.heap 0 0)
        let A_den : ℤ := outBit.words.read (.heap 0 1)
        let B_num : ℤ := outBit.words.read (.heap 0 2)
        let B_den : ℤ := outBit.words.read (.heap 0 3)
        outArith.mem.words.read (.heap 0 0) = A_num ∧
        outArith.mem.words.read (.heap 0 1) = A_den ∧
        outArith.mem.words.read (.heap 0 2) = B_num ∧
        outArith.mem.words.read (.heap 0 3) = B_den ∧
        0 < A_den ∧
        0 < B_den ∧
        let A : ℚ := (A_num : ℚ) / (A_den : ℚ)
        let B : ℚ := (B_num : ℚ) / (B_den : ℚ)
        let h : ℝ := g - 11 * (e : ℝ)
        intBitLength A_num ≤ bound ∧
        intBitLength A_den ≤ bound ∧
        intBitLength B_num ≤ bound ∧
        intBitLength B_den ≤ bound ∧
        ratBitLength A ≤ bound ∧
        ratBitLength B ≤ bound ∧
        0 < A ∧
        0 ≤ B ∧
        A ^ 2 + B ^ 2 = 1 ∧
        ∀ (d : ℕ),
        ∀ (u z z_hat : EuclideanSpace ℝ (Fin d)),
          ‖u‖ = 1 →
          ‖z‖ = 1 →
          ‖z_hat‖ = 1 →
          ‖z_hat - z‖ ≤ (e : ℝ) / 8 →
          let padQuery : EuclideanSpace ℝ (Fin (d + 1)) := liftedPoint ((A : ℝ) • z_hat) (-(B : ℝ))
          let padData : EuclideanSpace ℝ (Fin (d + 1)) := liftedPoint ((A : ℝ) • u) (B : ℝ)
          ‖padQuery‖ = 1 ∧
          ‖padData‖ = 1 ∧
          ((a : ℝ) ≤ inner ℝ z u → h ≤ inner ℝ padQuery padData) ∧
          (inner ℝ z u ≤ (b : ℝ) → inner ℝ padQuery padData < 0)

end UL
