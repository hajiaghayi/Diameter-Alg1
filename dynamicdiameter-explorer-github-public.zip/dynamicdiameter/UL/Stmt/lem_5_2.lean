import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_node_chain_blocks
import UL.Def.def_node_baseline
set_option autoImplicit false

namespace UL

/-- Lemma 5.2 (paper p.17). Exactly the paper's statement, as a Prop. -/
def S_lem_5_2 : Prop :=
  ∀ (d : ℕ) (ι : Type) (k : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (P : Finset ι)
    (nodes : Fin k → ChainNode d)
    (basePairs : Fin k → Option (ι × ι))
    (leafPair : Option (ι × ι))
    (h_base : ∀ i : Fin k,
      (nodes i).SatisfiesBaselineCond pts (chainInput pts nodes P i.castSucc) (basePairs i))
    (h_leaf_active : IsActiveNodePair (chainTerminal pts nodes P) leafPair)
    (h_leaf_diam :
      baselinePairLength pts leafPair = indexedEuclideanDiam (chainTerminal pts nodes P) pts),
    (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty
      (Fin.lastCases (baselinePairLength pts leafPair)
        (fun i => baselinePairLength pts (basePairs i))) ∈
      Set.Icc (indexedEuclideanDiam P pts / Real.sqrt 2) (indexedEuclideanDiam P pts)

end UL
