import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_node_chain_blocks
import UL.Def.def_node_baseline
import UL.Def.def_C_2_schedule
set_option autoImplicit false

namespace UL

/-- Claim (Sec. 7.3: The exact endpoint) (paper p.33). Exactly the paper's statement, as a Prop. -/
def S_clm_7_3_las_vegas_endpoint : Prop :=
  (backgroundIndexModeForFactor (Real.sqrt 2) = .radiusDictOnly ∧
    ∀ (d n k : ℕ), 2 ≤ n →
      ∀ (P : DynamicPointSet d), P.WellFormed n →
        ∀ (nodes : Fin k → ChainNode d)
          (maxPts : Fin k → Option ℕ)
          (basePairs : Fin k → Option (ℕ × ℕ))
          (leafPair : Option (ℕ × ℕ)),
          (∀ i : Fin k,
            let S_i := chainInput P.coords nodes P.activeIds i.castSucc
            (S_i = ∅ → maxPts i = none) ∧
            (S_i.Nonempty → ∃ y : ℕ, maxPts i = some y ∧ (nodes i).IsMaxRadiusPoint P.coords S_i y)) →
          (∀ i : Fin k,
            (nodes i).SatisfiesBaselineCond P.coords
              (chainInput P.coords nodes P.activeIds i.castSucc) (basePairs i)) →
          IsExactLeafAnswer P.coords (chainTerminal P.coords nodes P.activeIds) leafPair →
            ∃ ans : StoredDiameterAnswer,
              IsValidFactorCAnswer (Real.sqrt 2) P ans ∧
              (0 < P.diam →
                ∃ (cand : Option (ℕ × ℕ)) (id₁ id₂ : ℕ),
                  (cand = leafPair ∨ ∃ i : Fin k, cand = basePairs i) ∧
                  cand = some (id₁, id₂) ∧
                  ans.diameterHandles = some (P.handleOfId id₁, P.handleOfId id₂) ∧
                  ans.cachedDistSq = euclideanDistSq (P.coords id₁) (P.coords id₂))) ∧
  (∀ (d : ℕ) (ι : Type) (pts : ι → EuclideanSpace ℝ (Fin d))
    (P₀ S : Finset ι) (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (cert : BlockCertificate pts P₀ (liftedPoint o s)) (y : ι),
    cert.IsIntact S →
    IsNodeMaxRadiusPoint pts o S y →
      ∃ p ∈ cert.B,
        IsNodeBaselinePair pts o (liftVariance o s) S p y ∧
        SatisfiesNodeBaselineCond pts o (liftVariance o s) S (some (p, y))) ∧
  (∃ (polyTime polySpace : ℕ → ℕ → ℝ) (queryConst writeFactor : ℕ),
    IsBoundedByPoly2 polyTime ∧
    IsBoundedByPoly2 polySpace ∧
    ∀ (d n t : ℕ), 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let logTerm : ℕ := Nat.ceil (Real.logb 2 ((2 * (n : ℝ) * (t : ℝ)) / δ))
        ∃ (prog : ArithRAMDynamicProgram) (initOut : ArithRAMExecOutcome),
          prog.evalInit n d = some initOut ∧
          let alg : DynamicDiameterStructure d ArithRAMMemory :=
            { initState := initOut.mem
              initWork := initOut.unitCost
              initSpace := initOut.peakCellSpace
              cachedAnswer := fun mem =>
                let ca := ArithRAMDynamicProgram.readCachedAnswer mem
                { diameterHandles := ca.1, cachedDistSq := ca.2 }
              retrieveIdsAndRefCost := 4
              writeOutputCost := fun len => len + 1
              stepWithBits := fun activeH hCoords mem uop bs =>
                let rawOut :=
                  match uop with
                  | .insert pt => prog.evalUpdate n activeH hCoords mem true pt 0 bs
                  | .delete h => prog.evalUpdate n activeH hCoords mem false 0 h bs
                rawOut.map (fun out =>
                  let ca := ArithRAMDynamicProgram.readCachedAnswer out.mem
                  { nextState := out.mem
                    returnedHandle :=
                      match uop with
                      | .insert _ => ArithRAMDynamicProgram.readReturnedHandle out.mem
                      | .delete _ => none
                    storedAnswer := { diameterHandles := ca.1, cachedDistSq := ca.2 }
                    work := out.unitCost
                    peakSpace := out.peakCellSpace }) }
          SatisfiesDynamicStorageAndQueryModel queryConst writeFactor alg ∧
          SatisfiesMonteCarloGuarantee n t δ (Real.sqrt 2) Set.univ alg ∧
          SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg
            (polyTime d logTerm) ∧
          SatisfiesBoundedSpaceBound n t Set.univ alg
            ((n : ℝ) * polySpace d logTerm)) ∧
  (∃ (spacePoly timePoly : ℕ → ℕ → ℕ → ℝ) (queryConst writeFactor : ℕ),
    IsBoundedByPoly3 spacePoly ∧ IsBoundedByPoly3 timePoly ∧
    ∀ (d n B : ℕ), 2 ≤ n → 1 ≤ B →
      let L : ℕ := Nat.clog 2 (2 * n)
      ∃ (prog : BitRAMDynamicProgram) (initOut : BitRAMExecOutcome),
        prog.evalInit n d = some initOut ∧
        let alg : DynamicDiameterStructure d WordStore :=
          { initState := initOut.words
            initWork := initOut.bitCost
            initSpace := initOut.peakBitSpace
            cachedAnswer := fun ws =>
              let ca := BitRAMDynamicProgram.readCachedAnswer ws
              { diameterHandles := ca.1, cachedDistSq := ca.2 }
            retrieveIdsAndRefCost := 5
            writeOutputCost := fun len => len + 1
            stepWithBits := fun activeH hCoords ws uop bs =>
              let rawOut :=
                match uop with
                | .insert pt => prog.evalUpdate n activeH hCoords ws true pt 0 bs
                | .delete h => prog.evalUpdate n activeH hCoords ws false 0 h bs
              rawOut.map (fun out =>
                let ca := BitRAMDynamicProgram.readCachedAnswer out.words
                { nextState := out.words
                  returnedHandle :=
                    match uop with
                    | .insert _ => BitRAMDynamicProgram.readReturnedHandle out.words
                    | .delete _ => none
                  storedAnswer := { diameterHandles := ca.1, cachedDistSq := ca.2 }
                  work := out.bitCost
                  peakSpace := out.peakBitSpace }) }
        SatisfiesDynamicStorageAndQueryModel queryConst writeFactor alg ∧
        SatisfiesLasVegasGuarantee n (Real.sqrt 2) (timePoly d B L)
          (RatAdmissiblePointSet d B) alg ∧
        SatisfiesUnboundedSpaceBound n (RatAdmissiblePointSet d B) alg
          ((n : ℝ) * spacePoly d B L))

end UL
