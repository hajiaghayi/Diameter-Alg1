import Mathlib
import UL.Def.def_shells_configurations
set_option autoImplicit false

namespace UL

/-- Claim (Sec. 5.2: Configuration correlation bounds (5)) (paper p.18). Exactly the paper's statement, as a Prop. -/
def S_clm_5_2_config_gap : Prop :=
  ∀ (e γ lam : ℚ) (K : ℤ) (V : ℝ) (j k ℓ : ℕ)
    (he : 0 < e) (hγ : 1 < γ) (hlam : 1 < lam) (hV : 0 < V)
    (hret : IsRetainedConfig e γ lam K V j k ℓ),
    let m0 : ℕ := shellSubdiv e
    let r_j : ℝ := shellRadius m0 V j
    let r_k : ℝ := shellRadius m0 V k
    let a : ℝ := configThresholdA m0 γ lam V j k ℓ
    let b : ℝ := configThresholdB m0 lam V j k ℓ
    let g : ℝ := (γ : ℝ) ^ 2 - 1
    (∀ (d : ℕ) (o x y : EuclideanSpace ℝ (Fin d)),
      shellIndex m0 o V x = j →
      shellIndex m0 o V y = k →
      (IsStrongRoundedPair m0 γ lam o V ℓ x y → a < radialCorrelation o x y) ∧
      (IsWeakRoundedPair m0 lam o V ℓ x y ↔ b < radialCorrelation o x y)) ∧
    (∀ (d : ℕ) (ι : Type) (pts : ι → EuclideanSpace ℝ (Fin d))
       (o : EuclideanSpace ℝ (Fin d)) (S : Finset ι),
      (∀ xy ∈ configStrongEdges pts m0 γ lam o V K S j k ℓ,
        a < radialCorrelation o (pts xy.1) (pts xy.2)) ∧
      (∀ x ∈ configLeftVertices pts m0 o V S j,
       ∀ y ∈ configRightVertices pts m0 o V K S k,
        ((x, y) ∈ configWeakEdges pts m0 lam o V K S j k ℓ ↔
          b < radialCorrelation o (pts x) (pts y)))) ∧
    (∃ a_rat b_rat : ℚ,
      a = (a_rat : ℝ) ∧
      b = (b_rat : ℝ) ∧
      ∀ V' : ℝ, 0 < V' →
        configThresholdA m0 γ lam V' j k ℓ = (a_rat : ℝ) ∧
        configThresholdB m0 lam V' j k ℓ = (b_rat : ℝ)) ∧
    0 ≤ b ∧
    b < a ∧
    a ≤ 1 ∧
    a - (1 + g) * b = g * ((r_j ^ 2 + r_k ^ 2) / (2 * r_j * r_k)) ∧
    g ≤ g * ((r_j ^ 2 + r_k ^ 2) / (2 * r_j * r_k))

end UL
