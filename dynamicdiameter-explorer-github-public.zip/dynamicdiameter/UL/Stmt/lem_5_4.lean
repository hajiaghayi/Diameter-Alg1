import Mathlib
import UL.Def.def_node_baseline
import UL.Def.def_shells_configurations
import UL.Def.def_local_matching
set_option autoImplicit false

namespace UL

/-- Lemma 5.4 (paper p.19). Exactly the paper's statement, as a Prop. -/
def S_lem_5_4 : Prop :=
  ∀ (d : ℕ) (ι : Type)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d))
    (V : ℝ)
    (e : ℚ)
    (S : Finset ι)
    (L : ℝ)
    (hV : 0 < V)
    (he : 0 < e)
    (hL : SatisfiesBaselineLengthCond pts o V S L),
    (∀ x ∈ S, ∀ y ∈ S,
      ‖inwardRound (shellSubdiv e) o V (pts x) - inwardRound (shellSubdiv e) o V (pts y)‖ ≤
        max (max ‖pts x - pts y‖ ‖pts x - o‖) ‖pts y - o‖ ∧
      max (max ‖pts x - pts y‖ ‖pts x - o‖) ‖pts y - o‖ ≤ max ‖pts x - pts y‖ L) ∧
    (∀ (γ lam : ℚ) (K : ℤ),
      1 < γ → 1 < lam → 0 < K →
      ∀ (M : ShellConfig → Finset (ι × ι)) (stored : ShellConfig → Option (ι × ι)),
        (∀ cfg ∈ retainedConfigs e γ lam K V,
          M cfg ⊆ configWeakEdges pts (shellSubdiv e) lam o V K S cfg.j cfg.k cfg.ℓ ∧
          IsBipartiteMatching
            (configLeftVertices pts (shellSubdiv e) o V S cfg.j)
            (configRightVertices pts (shellSubdiv e) o V K S cfg.k)
            (M cfg) ∧
          IsStoredMatchingEdge (M cfg) (stored cfg)) →
        ∀ cfg ∈ retainedConfigs e γ lam K V,
          (M cfg).Nonempty →
          distScale lam V cfg.ℓ < nodeRetainedEstimate pts e γ lam K V L stored)

end UL
