import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_dynamic_points_model
import UL.Def.def_computation_model
import UL.Def.def_node_chain_blocks
import UL.Def.def_node_baseline
import UL.Def.def_local_scale_params
import UL.Def.def_shells_configurations
import UL.Def.def_local_matching
import UL.Def.def_7_birth_pool
import UL.Def.def_C_2_schedule
import UL.Def.def_alg_4
set_option autoImplicit false

namespace UL

/-! ### Helper predicates for checked local-matching search promises -/

/-- Angular search-promise satisfaction along the sequential repair of `survivingFormerPartners`
during `checkedConfigDeleteOriginal` (at most two former partners per configuration). -/
def ValidCheckedDeletePromises {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) :
    LocalMatchingState ι → List (CopyVertex ι) → List (Option ι) → Prop
  | _, [], _ => True
  | st, u :: us, rawAnswers =>
      open Classical in
      if st.isCopyMatched u ∨ st.isCopyInIndex u then
        ValidCheckedDeletePromises pts params o V cfg st us rawAnswers
      else
        let rawAns := rawAnswers.head?.join
        SatisfiesConfigSearchPromise pts params.m0 params.γ params.lam o V
          cfg.j cfg.k cfg.ℓ (st.oppositeIndexSet u.side) u.id rawAns ∧
        let checkedAns := sanitizeConfigAttachAnswer pts params o V cfg st u rawAns
        ValidCheckedDeletePromises pts params o V cfg
          (attachStep pts st u checkedAns) us (rawAnswers.drop 1)

/-- Angular search-promise satisfaction for `checkedConfigInsertOriginal` across the at most two
applicable copies (`left` then `right`) of an inserted point `p`. -/
def ValidCheckedInsertPromises {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) (st : LocalMatchingState ι) (p : ι)
    (rawLeft rawRight : Option ι) : Prop :=
  open Classical in
  (hasApplicableLeftCopy params.m0 o V cfg.j (pts p) →
    SatisfiesConfigSearchPromise pts params.m0 params.γ params.lam o V
      cfg.j cfg.k cfg.ℓ st.rightIndexSet p rawLeft) ∧
  let st₁ :=
    if hasApplicableLeftCopy params.m0 o V cfg.j (pts p) then
      let vL : CopyVertex ι := ⟨.left, p⟩
      attachStep pts st vL (sanitizeConfigAttachAnswer pts params o V cfg st vL rawLeft)
    else
      st
  (hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p) →
    SatisfiesConfigSearchPromise pts params.m0 params.γ params.lam o V
      cfg.j cfg.k cfg.ℓ st₁.leftIndexSet p rawRight)

/-! ### Statement of Claim (Sec. 7.3: Approximation and update work) -/

/-- Claim (Sec. 7.3: Approximation and update work) (paper p.33). Exactly the paper's statement,
as a Prop:
1. Using Lemma 7.1's dynamic search interface on each unmatched-set index (`leftIndexSet` for `U_L`
   and `rightIndexSet` for `U_R`, embedded on the unit sphere in `ℝ^{d+1}` via Lemma 5.6's padding
   `(A_pad, B_pad)` with `A_pad^2 + B_pad^2 = 1`), a point update (`checkedConfigInsertOriginal` or
   `checkedConfigDeleteOriginal`) causes only constantly many matching repairs, angular searches,
   and unmatched-set updates per configuration while preserving `LocalMatchingState.SatisfiesInvariant`;
2. The number of configurations (`retainedConfigs`, `allShellConfigs`) and geometric chain levels
   (`O(β⁻¹ log n)` under chain contraction) is polynomial in `d` and the logarithmic/scale
   parameters, and multiplying the birth-pool schedules (`birthPoolTargetTime n θ` and
   `birthPoolSpaceBound m σ` for `ValidBirthPoolExponents n σ θ`, `θ ≥ σ ≥ 0`) by these polynomial
   factors preserves the claimed powers `n^θ` (update work) and `n^{1+σ}` (space);
3. For `1 < c < √2` (`params : LocalScaleParams`), positive-variance node estimates
   `params.nodeRetainedEstimate` (`0 < V`, without gating on `InNodeLocalRange`) approximate every
   core–input distance (`D_{C_i} / c ≤ W_i ≤ diam(S_i)`), and assigning any diametral pair to its
   first core along the chain (or to the exact terminal leaf if in no core) proves the global
   factor-`c` diameter guarantee (both for an arbitrary serving chain and for Algorithm 4's
   `toStoredDiameterAnswer st.cachedAnswer` on `Alg4State`) with no approximation factor multiplied
   along the chain. -/
def S_clm_7_3_global_approx : Prop :=
  open Classical in
  -- (1) Lemma 7.1 unmatched-set unit-sphere interface and constantly many matching repairs per
  -- configuration on each point insertion or deletion:
  ((∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (params : LocalScaleParams)
      (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
      (S : Finset ι) (cfg : ShellConfig) (st : LocalMatchingState ι)
      (A_pad B_pad : ℝ),
      0 < V →
      cfg ∈ params.retainedConfigs V →
      A_pad ^ 2 + B_pad ^ 2 = 1 →
      st.WellFormed pts
        (params.leftVertices pts o V S cfg.j)
        (params.rightVertices pts o V S cfg.k) →
        (∀ x ∈ st.leftIndexSet,
          pts x ≠ o ∧
          ‖radialDirection o (pts x)‖ = 1 ∧
          IsUnitVec (liftedPoint (A_pad • radialDirection o (pts x)) B_pad)) ∧
        (∀ y ∈ st.rightIndexSet,
          pts y ≠ o ∧
          ‖radialDirection o (pts y)‖ = 1 ∧
          IsUnitVec (liftedPoint (A_pad • radialDirection o (pts y)) B_pad)) ∧
        (∀ z_hat : EuclideanSpace ℝ (Fin d),
          ‖z_hat‖ = 1 → IsUnitVec (liftedPoint (A_pad • z_hat) (-B_pad)))) ∧
    (∃ C_repairs : ℕ, 1 ≤ C_repairs ∧
      ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
        (pts : ι → EuclideanSpace ℝ (Fin d))
        (params : LocalScaleParams)
        (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
        (S : Finset ι) (cfg : ShellConfig) (st : LocalMatchingState ι),
        0 < V →
        cfg ∈ params.retainedConfigs V →
        st.SatisfiesInvariant pts
          (params.leftVertices pts o V S cfg.j)
          (params.rightVertices pts o V S cfg.k)
          (params.weakEdges pts o V S cfg.j cfg.k cfg.ℓ)
          (params.strongEdges pts o V S cfg.j cfg.k cfg.ℓ) →
        (∀ (p : ι) (rawLeft rawRight : Option ι),
          p ∉ S →
          ValidCheckedInsertPromises pts params o V cfg st p rawLeft rawRight →
            let st' := checkedConfigInsertOriginal pts params o V cfg st p rawLeft rawRight
            st'.SatisfiesInvariant pts
              (params.leftVertices pts o V (insert p S) cfg.j)
              (params.rightVertices pts o V (insert p S) cfg.k)
              (params.weakEdges pts o V (insert p S) cfg.j cfg.k cfg.ℓ)
              (params.strongEdges pts o V (insert p S) cfg.j cfg.k cfg.ℓ) ∧
            (symmDiff st.leftIndexSet st'.leftIndexSet).card +
              (symmDiff st.rightIndexSet st'.rightIndexSet).card ≤ C_repairs ∧
            (symmDiff st.matching st'.matching).card ≤ C_repairs) ∧
        (∀ (p : ι) (rawAnswers : List (Option ι)),
          p ∈ S →
          (survivingFormerPartners st p).length ≤ C_repairs ∧
          checkedConfigDeleteOriginal pts params o V cfg st p rawAnswers =
            checkedConfigDeleteOriginal pts params o V cfg st p (rawAnswers.take C_repairs) ∧
          (ValidCheckedDeletePromises pts params o V cfg
              (removeCopiesFromState st p) (survivingFormerPartners st p) rawAnswers →
            let st' := checkedConfigDeleteOriginal pts params o V cfg st p rawAnswers
            st'.SatisfiesInvariant pts
              (params.leftVertices pts o V (S.erase p) cfg.j)
              (params.rightVertices pts o V (S.erase p) cfg.k)
              (params.weakEdges pts o V (S.erase p) cfg.j cfg.k cfg.ℓ)
              (params.strongEdges pts o V (S.erase p) cfg.j cfg.k cfg.ℓ) ∧
            (symmDiff st.leftIndexSet st'.leftIndexSet).card +
              (symmDiff st.rightIndexSet st'.rightIndexSet).card ≤ C_repairs ∧
            (symmDiff st.matching st'.matching).card ≤ C_repairs)))) ∧
  -- (2) Polynomial number of configurations and geometric levels, preserving the powers n^θ and n^{1+σ}:
  ((∃ (C_cfg : ℝ) (deg_cfg : ℕ), 0 < C_cfg ∧
      ∀ (params : LocalScaleParams) (V : ℝ),
        (params.retainedConfigs V).card ≤ (allShellConfigs params.m0 params.K params.J).card ∧
        (allShellConfigs params.m0 params.K params.J).card =
          params.m0 * params.maxShellIndex * (params.J + 1) ∧
        ((allShellConfigs params.m0 params.K params.J).card : ℝ) ≤
          C_cfg * (((params.e : ℝ)⁻¹ + 1) ^ deg_cfg) *
            (((params.K : ℝ) + 1) ^ deg_cfg) *
            ((((params.lam : ℝ) - 1)⁻¹ + 1) ^ deg_cfg)) ∧
    (∀ (d n k : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (P : Finset ι) (β : ℝ) (nodes : Fin k → ChainNode d),
      2 ≤ n → P.card ≤ n → 0 < β → β ≤ 1 →
      (∀ i : Fin k,
        1 ≤ (chainInput pts nodes P i.castSucc).card ∧
        ((chainInput pts nodes P i.succ).card : ℝ) ≤
          (1 - β) * ((chainInput pts nodes P i.castSucc).card : ℝ)) →
        (k : ℝ) ≤ β⁻¹ * (Real.log (n : ℝ) + 1)) ∧
    (∀ (σ θ : ℝ)
      (polySchedTime polySchedSpace polyConfigs polyLevels : ℕ → ℕ → ℝ),
      0 ≤ σ → σ ≤ θ →
      IsBoundedByPoly2 polySchedTime →
      IsBoundedByPoly2 polySchedSpace →
      IsBoundedByPoly2 polyConfigs →
      IsBoundedByPoly2 polyLevels →
      (∀ d L : ℕ,
        0 ≤ polySchedTime d L ∧ 0 ≤ polySchedSpace d L ∧
        0 ≤ polyConfigs d L ∧ 0 ≤ polyLevels d L) →
      ∃ (polyTotalTime polyTotalSpace : ℕ → ℕ → ℝ),
        IsBoundedByPoly2 polyTotalTime ∧
        IsBoundedByPoly2 polyTotalSpace ∧
        ∀ (d n L N_cfg N_lvl : ℕ),
          ValidBirthPoolExponents n σ θ →
          (N_cfg : ℝ) ≤ polyConfigs d L →
          (N_lvl : ℝ) ≤ polyLevels d L →
            (N_cfg : ℝ) * (N_lvl : ℝ) * birthPoolTargetTime n θ (polySchedTime d L) ≤
              ((n : ℝ) ^ θ) * polyTotalTime d L ∧
            ∀ (M : ℕ) (m : Fin M → ℕ),
              (∀ r : Fin M, m r ≤ n) →
              (∑ r : Fin M, (m r : ℝ)) ≤ (n : ℝ) * (N_cfg : ℝ) * (N_lvl : ℝ) →
                (∑ r : Fin M, birthPoolSpaceBound (m r) σ (polySchedSpace d L)) ≤
                  ((n : ℝ) ^ (1 + σ)) * polyTotalSpace d L)) ∧
  -- (3) Core–input approximation (via positive-variance nodeRetainedEstimate, without gating on
  -- InNodeLocalRange) and first-core global factor-c guarantee with no factor multiplied along the chain:
  ((∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (params : LocalScaleParams)
      (P : Finset ι)
      (k : ℕ) (nodes : Fin k → ChainNode d)
      (basePairs : Fin k → Option (ι × ι))
      (M : Fin k → ShellConfig → Finset (ι × ι))
      (stored : Fin k → ShellConfig → Option (ι × ι))
      (leafPair : Option (ι × ι)),
      (∀ i : Fin k,
        (nodes i).SatisfiesBaselineCond pts (chainInput pts nodes P i.castSucc) (basePairs i)) →
      (∀ i : Fin k,
        0 < (nodes i).V →
        ∀ cfg ∈ params.retainedConfigs (nodes i).V,
          params.SatisfiesMatchingInvariant pts (nodes i).o (nodes i).V
            (chainInput pts nodes P i.castSucc) cfg.j cfg.k cfg.ℓ (M i cfg) ∧
          IsStoredMatchingEdge (M i cfg) (stored i cfg)) →
      IsExactLeafAnswer pts (chainTerminal pts nodes P) leafPair →
      let nodeW : Fin k → ℝ := fun i =>
        params.nodeRetainedEstimate pts (nodes i).V
          (baselinePairLength pts (basePairs i)) (stored i)
      let W_max : ℝ :=
        (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty
          (Fin.lastCases (baselinePairLength pts leafPair) nodeW)
      (∀ i : Fin k,
        chainCoreInputDiam pts nodes P i / params.c ≤ nodeW i ∧
        nodeW i ≤ indexedEuclideanDiam (chainInput pts nodes P i.castSucc) pts) ∧
      (∀ x y : ι, x ∈ P → y ∈ P →
        (x ∈ chainTerminal pts nodes P ∧ y ∈ chainTerminal pts nodes P ∧
          ‖pts x - pts y‖ ≤ baselinePairLength pts leafPair) ∨
        (∃ i₀ : Fin k,
          (x ∈ chainCore pts nodes P i₀ ∨ y ∈ chainCore pts nodes P i₀) ∧
          (∀ j : Fin k, j < i₀ →
            x ∉ chainCore pts nodes P j ∧ y ∉ chainCore pts nodes P j) ∧
          x ∈ chainInput pts nodes P i₀.castSucc ∧
          y ∈ chainInput pts nodes P i₀.castSucc ∧
          ‖pts x - pts y‖ / params.c ≤ chainCoreInputDiam pts nodes P i₀ / params.c ∧
          chainCoreInputDiam pts nodes P i₀ / params.c ≤ nodeW i₀)) ∧
      W_max ∈ Set.Icc (indexedEuclideanDiam P pts / params.c) (indexedEuclideanDiam P pts) ∧
      (P.card ≤ 1 → leafPair = none ∧ W_max = 0) ∧
      (2 ≤ P.card →
        ∃ u v : ι,
          IsIndexedFactorCDiameterPair params.c P pts u v ∧
          (0 < W_max →
            ‖pts u - pts v‖ = W_max ∧
            (leafPair = some (u, v) ∨
              (∃ i : Fin k, basePairs i = some (u, v)) ∨
              (∃ i : Fin k, 0 < (nodes i).V ∧
                ∃ cfg ∈ params.retainedConfigs (nodes i).V,
                  stored i cfg = some (u, v)))))) ∧
    (∀ (d n L D_out : ℕ) (α : ℝ) (params : LocalScaleParams)
      (st : Alg4State d ℕ) (P : DynamicPointSet d),
      P.WellFormed n →
      P.activeHandles = st.activeSet →
      (∀ h ∈ P.activeHandles, P.handleCoords h = st.coords h) →
      st.WellFormed n (.subSqrt2 params) α L D_out →
      st.SatisfiesGoodEvent (.subSqrt2 params) →
        (∀ idx : Fin st.servingNodes.length,
          let sn := st.servingNodes[idx]
          let S_i := st.servingInputAt idx.val
          let W_i := max (baselinePairLength st.coords sn.baselinePair)
            (Real.sqrt sn.maxMatchingDistSq)
          W_i = params.nodeRetainedEstimate st.coords sn.node.V
            (baselinePairLength st.coords sn.baselinePair)
            (fun cfg => (sn.localMatchings cfg).storedEdge) ∧
          sn.node.coreInputDiam st.coords S_i / params.c ≤ W_i ∧
          W_i ≤ indexedEuclideanDiam S_i st.coords) ∧
        IsValidFactorCAnswer params.c P (toStoredDiameterAnswer st.cachedAnswer)))

end UL
