import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_node_chain_blocks
import UL.Def.def_local_matching
set_option autoImplicit false

namespace UL

open Classical in
/-- Claim (Sec. 5.3: First-core global factor-c diameter guarantee) (paper p.20). Exactly the paper's statement, as a Prop. -/
def S_clm_5_3_global_factor_c : Prop :=
  -- (1) The first-core argument from Lemma 5.2 combined with Lemma 5.5 across all nodes of a chain
  -- proves the global factor-c diameter guarantee (without multiplying c along the chain):
  (∀ (d : ℕ) (ι : Type) (k : ℕ)
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (P : Finset ι)
      (params : LocalScaleParams)
      (nodes : Fin k → ChainNode d)
      (basePairs : Fin k → Option (ι × ι))
      (M : Fin k → ShellConfig → Finset (ι × ι))
      (stored : Fin k → ShellConfig → Option (ι × ι))
      (leafPair : Option (ι × ι))
      (h_base : ∀ i : Fin k,
        (nodes i).SatisfiesBaselineCond pts (chainInput pts nodes P i.castSucc) (basePairs i))
      (h_match : ∀ i : Fin k,
        0 < (nodes i).V →
        ∀ cfg ∈ params.retainedConfigs (nodes i).V,
          params.SatisfiesMatchingInvariant pts (nodes i).o (nodes i).V
            (chainInput pts nodes P i.castSucc) cfg.j cfg.k cfg.ℓ (M i cfg) ∧
          IsStoredMatchingEdge (M i cfg) (stored i cfg))
      (h_leaf_active : IsActiveNodePair (chainTerminal pts nodes P) leafPair)
      (h_leaf_diam :
        baselinePairLength pts leafPair = indexedEuclideanDiam (chainTerminal pts nodes P) pts),
    let W_max : ℝ :=
      (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty
        (Fin.lastCases (baselinePairLength pts leafPair)
          (fun i => params.nodeRetainedEstimate pts (nodes i).V
            (baselinePairLength pts (basePairs i)) (stored i)))
    W_max ∈ Set.Icc (indexedEuclideanDiam P pts / params.c) (indexedEuclideanDiam P pts) ∧
    (2 ≤ P.card →
      ∃ x y : ι,
        IsIndexedFactorCDiameterPair params.c P pts x y ∧
        (0 < W_max →
          ‖pts x - pts y‖ = W_max ∧
          (leafPair = some (x, y) ∨
            (∃ i : Fin k, basePairs i = some (x, y)) ∨
            (∃ i : Fin k,
              0 < (nodes i).V ∧
              ∃ cfg ∈ params.retainedConfigs (nodes i).V,
                stored i cfg = some (x, y)))))) ∧
  -- (2) Each point update (insertion or deletion) causes only constantly many angular operations
  -- (angular searches and unmatched-index updates) per applicable configuration:
  (∃ C_ops : ℕ,
    ∀ (d : ℕ) (ι : Type)
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (params : LocalScaleParams)
      (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
      (S : Finset ι) (cfg : ShellConfig) (st : LocalMatchingState ι),
      0 < V →
      cfg ∈ params.retainedConfigs V →
      st.WellFormed pts
        (params.leftVertices pts o V S cfg.j)
        (params.rightVertices pts o V S cfg.k) →
      let a := params.thresholdA V cfg.j cfg.k cfg.ℓ
      let b := params.thresholdB V cfg.j cfg.k cfg.ℓ
      (∀ (p : ι), p ∉ S →
        let V_L' := params.leftVertices pts o V (insert p S) cfg.j
        let V_R' := params.rightVertices pts o V (insert p S) cfg.k
        ((¬ hasApplicableLeftCopy params.m0 o V cfg.j (pts p) ∧
            ¬ hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p)) →
          (∀ ansLeft ansRight : Option ι,
            configInsertOriginalStep pts params.m0 o V params.K cfg.j cfg.k st p ansLeft ansRight = st) ∧
          (∀ st' : LocalMatchingState ι,
            ValidInsertOriginalAngularStep pts o a b V_L' V_R' st p st' → st' = st)) ∧
        (∀ st' : LocalMatchingState ι,
          ValidInsertOriginalAngularStep pts o a b V_L' V_R' st p st' →
          (∃ copies : List (CopyVertex ι),
            copies.length ≤ C_ops ∧
            ValidRepairAngularSteps pts o a b V_L' V_R' st copies st') ∧
          (symmDiff st.leftIndexSet st'.leftIndexSet).card +
            (symmDiff st.rightIndexSet st'.rightIndexSet).card ≤ C_ops)) ∧
      (∀ (p : ι), p ∈ S →
        let V_L := params.leftVertices pts o V S cfg.j
        let V_R := params.rightVertices pts o V S cfg.k
        let V_L' := params.leftVertices pts o V (S.erase p) cfg.j
        let V_R' := params.rightVertices pts o V (S.erase p) cfg.k
        ((p ∉ V_L ∧ p ∉ V_R) →
          removeCopiesFromState st p = st ∧
          survivingFormerPartners st p = [] ∧
          (∀ st' : LocalMatchingState ι,
            ValidDeleteOriginalAngularStep pts o a b V_L' V_R' st p st' → st' = st)) ∧
        (st.leftUnmatchedIndex.filter (fun e => e.id = p)).length +
          (st.rightUnmatchedIndex.filter (fun e => e.id = p)).length +
          (survivingFormerPartners st p).length ≤ C_ops ∧
        (∀ answers : List (Option ι),
          deleteOriginalStep pts st p answers =
            deleteOriginalStep pts st p (answers.take C_ops)) ∧
        (∀ st' : LocalMatchingState ι,
          ValidDeleteOriginalAngularStep pts o a b V_L' V_R' st p st' →
          (∃ F : List (CopyVertex ι),
            F.length ≤ C_ops ∧
            ValidRepairAngularSteps pts o a b V_L' V_R' (removeCopiesFromState st p) F st') ∧
          (symmDiff st.leftIndexSet st'.leftIndexSet).card +
            (symmDiff st.rightIndexSet st'.rightIndexSet).card ≤ C_ops)))

end UL
