import Mathlib
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Def.def_C_2_schedule
import UL.Def.def_alg_4
set_option autoImplicit false

namespace UL

/-! ### 1. Execution failure-budget scale `S` (rational bit-length and arithmetic models) -/

/-- Execution scale `S = n + t + d + B + ⌈log(2/δ)⌉ + 2` in the rational bit-length model for
capacity `n`, update horizon `t`, ambient dimension `d`, input bit-length bound `B`, and target
total error probability `δ`. -/
noncomputable def execFailureScaleBit (n t d B : ℕ) (δ : ℝ) : ℕ :=
  n + t + d + B + Nat.ceil (Real.log (2 / δ)) + 2

/-- Execution scale `S = n + t + d + ⌈log(2/δ)⌉ + 2` in the arithmetic model (omitting `B`). -/
noncomputable def execFailureScaleArith (n t d : ℕ) (δ : ℝ) : ℕ :=
  n + t + d + Nat.ceil (Real.log (2 / δ)) + 2

/-- Per-event conditional failure probability budget `δ / S^{C₁}` assigned at execution scale `S`
with fixed exponent `C₁`. -/
noncomputable def perEventFailureBudget (S C₁ : ℕ) (δ : ℝ) : ℝ :=
  δ / ((S : ℝ) ^ C₁)

/-! ### 2. Capped-schedule event accounting along Algorithm 4 executions -/

/-- Per-unit capped schedule bounds for Algorithm 4: baseline witness sample count `K0`, retained
configuration cap `retainedConfigCap`, per-tick Scan-2 batch cap `scan2BatchCap`, filter
constructions per level-configuration build step `filtersPerLevelConfig`, and verification attempts
per level-configuration step `verificationsPerLevelConfig`. -/
structure CappedScheduleEventBounds : Type where
  K0 : ℕ
  retainedConfigCap : ℕ
  scan2BatchCap : ℕ
  filtersPerLevelConfig : ℕ
  verificationsPerLevelConfig : ℕ

/-- All per-unit schedule caps in `caps` are bounded by `C_sched * S ^ deg_sched`. -/
def CappedScheduleEventBounds.IsPolyBoundedInScale
    (C_sched : ℝ) (deg_sched S : ℕ) (caps : CappedScheduleEventBounds) : Prop :=
  (caps.K0 : ℝ) ≤ C_sched * ((S : ℝ) ^ deg_sched) ∧
  (caps.retainedConfigCap : ℝ) ≤ C_sched * ((S : ℝ) ^ deg_sched) ∧
  (caps.scan2BatchCap : ℝ) ≤ C_sched * ((S : ℝ) ^ deg_sched) ∧
  (caps.filtersPerLevelConfig : ℝ) ≤ C_sched * ((S : ℝ) ^ deg_sched) ∧
  (caps.verificationsPerLevelConfig : ℝ) ≤ C_sched * ((S : ℝ) ^ deg_sched)

/-- `jc : PendingJobStepChoices d ι` obeys the per-tick Scan-2 batch cap `scan2BatchCap`. -/
def PendingJobStepChoices.IsScheduleCapped {d : ℕ} {ι : Type}
    (scan2BatchCap : ℕ) (jc : PendingJobStepChoices d ι) : Prop :=
  ∀ bStep ∈ jc.prefixBudgetSteps, bStep.scan2Steps.length ≤ scan2BatchCap

/-- Step oracle `choices : Alg4StepChoices d ι` obeys the capped-schedule bounds `caps`: every
per-node baseline sample list has length `≤ caps.K0`, and every pending-job construction step
processes at most `caps.scan2BatchCap` Scan-2 records. -/
def Alg4StepChoices.IsScheduleCapped {d : ℕ} {ι : Type}
    (caps : CappedScheduleEventBounds) (choices : Alg4StepChoices d ι) : Prop :=
  (∀ samps ∈ choices.baselineSamples, samps.length ≤ caps.K0) ∧
  (∀ jc ∈ choices.pendingJobChoices, jc.IsScheduleCapped caps.scan2BatchCap)

/-- Four-tuple of relevant random/verification event counts in a step or execution: center
constructions, filter constructions, verification attempts, and witness samples. -/
structure ExecutionEventCounts : Type where
  centerConstructions : ℕ
  filterConstructions : ℕ
  verificationAttempts : ℕ
  witnessSamples : ℕ

/-- Componentwise addition of `ExecutionEventCounts`. -/
def ExecutionEventCounts.add (a b : ExecutionEventCounts) : ExecutionEventCounts :=
  { centerConstructions := a.centerConstructions + b.centerConstructions
    filterConstructions := a.filterConstructions + b.filterConstructions
    verificationAttempts := a.verificationAttempts + b.verificationAttempts
    witnessSamples := a.witnessSamples + b.witnessSamples }

/-- Total number of relevant events across all four categories. -/
def ExecutionEventCounts.total (c : ExecutionEventCounts) : ℕ :=
  c.centerConstructions + c.filterConstructions + c.verificationAttempts + c.witnessSamples

/-- Exact event counts executed during one call to `alg4Step mode α L reclaimMult st upd choices`
under capped schedule parameters `caps`:
1. `centerConstructions`: number of center balls opened via `selectOpenedLevelBall` in Line 5
   (late-opening gate across affected pending jobs) and Line 9 (synchronous oversized-leaf rebuild);
2. `filterConstructions`: filter generations constructed across newly opened centers and active
   Line-4 background prefix construction steps (up to `(1 + caps.retainedConfigCap) * caps.filtersPerLevelConfig`
   per opened center or active pending prefix level);
3. `verificationAttempts`: core-size checks (`applyBirthCoreFallback`), checked local-matching
   routing/Scan-2/leaf-rebuild repairs across retained configurations, and background filter
   verification attempts;
4. `witnessSamples`: baseline witness samples drawn across refreshed serving nodes in Line 10. -/
noncomputable def alg4StepEventCounts {d : ℕ}
    (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ)
    (caps : CappedScheduleEventBounds)
    (st : Alg4State d ℕ) (upd : Alg4PointUpdate d ℕ)
    (choices : Alg4StepChoices d ℕ) : ExecutionEventCounts :=
  let P' := applyAlg4PointSetUpdate st.activeSet upd
  let pts' := updateAlg4Coords st.coords upd
  let (nodesLine1, leafLine1, leafTicked) :=
    alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints
  let nodesLines2To6 :=
    alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
  let line5Opened : ℕ :=
    (List.zip nodesLine1 nodesLines2To6).countP (fun pair =>
      match pair.1.1.ownedJob, pair.2.1.ownedJob with
      | some jBefore, some jAfter =>
          decide (jBefore.completedPrefix.length < jAfter.completedPrefix.length)
      | _, _ => false)
  let (nodesLines7To8, leafLines7To8, leafAns7To8, leafSq7To8, leafChanged7To8, _) :=
    alg4Lines7To8InstallCompletedJobs nodesLines2To6
      leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafTicked
  let (_, leaf₁, _, _, _, _) :=
    startDueServingJobsAux pts' α L P' nodesLines7To8 leafLines7To8
      leafAns7To8 leafSq7To8 leafChanged7To8
  let line9Opened : ℕ :=
    if 6 * L < leaf₁.card then
      (rebuildOversizedLeafAux pts' mode α L leaf₁.card leaf₁ choices.leafRebuildChoices).1.length
    else
      0
  let centers := line5Opened + line9Opened
  let pendingLevels : ℕ :=
    (nodesLine1.map (fun pair =>
      match pair.1.ownedJob with
      | none => 0
      | some job => job.completedPrefix.length)).sum
  let nextSt := (alg4Step mode α L reclaimMult st upd choices).1
  let filters :=
    (centers + pendingLevels) * (1 + caps.retainedConfigCap) * caps.filtersPerLevelConfig
  let verifs :=
    centers +
      (st.servingNodes.length + pendingLevels * (1 + caps.scan2BatchCap) +
        line9Opened * leaf₁.card) * (1 + caps.retainedConfigCap) +
      (centers + pendingLevels) * (1 + caps.retainedConfigCap) * caps.verificationsPerLevelConfig
  let samples :=
    ((choices.baselineSamples.take nextSt.servingNodes.length).map List.length).sum
  { centerConstructions := centers
    filterConstructions := filters
    verificationAttempts := verifs
    witnessSamples := samples }

/-- State reached after running `alg4Step` from `cur` along a list of `(upd, choices)` pairs. -/
noncomputable def runAlg4UpdateList {d : ℕ}
    (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ) :
    Alg4State d ℕ → List (Alg4PointUpdate d ℕ × Alg4StepChoices d ℕ) → Alg4State d ℕ
  | cur, [] => cur
  | cur, (upd, ch) :: rest =>
      let next := (alg4Step mode α L reclaimMult cur upd ch).1
      runAlg4UpdateList mode α L reclaimMult next rest

/-- Validity of a sequence of `Alg4PointUpdate`s under capacity `n` starting from `cur`. -/
def ValidAlg4UpdateList {d : ℕ}
    (n : ℕ) (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ) :
    Alg4State d ℕ → List (Alg4PointUpdate d ℕ × Alg4StepChoices d ℕ) → Prop
  | _, [] => True
  | cur, (upd, ch) :: rest =>
      IsValidAlg4PointUpdate n cur upd ∧
      ValidAlg4UpdateList n mode α L reclaimMult
        (alg4Step mode α L reclaimMult cur upd ch).1 rest

/-- Cumulative `ExecutionEventCounts` along a list of `(upd, choices)` pairs starting from `cur`. -/
noncomputable def totalAlg4EventCounts {d : ℕ}
    (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ)
    (caps : CappedScheduleEventBounds) :
    Alg4State d ℕ → List (Alg4PointUpdate d ℕ × Alg4StepChoices d ℕ) → ExecutionEventCounts
  | _, [] => ⟨0, 0, 0, 0⟩
  | cur, (upd, ch) :: rest =>
      ExecutionEventCounts.add
        (alg4StepEventCounts mode α L reclaimMult caps cur upd ch)
        (totalAlg4EventCounts mode α L reclaimMult caps
          (alg4Step mode α L reclaimMult cur upd ch).1 rest)

/-! ### 3. Repeated independent capped constructor attempts and capped uniform rank sampling -/

/-- Consume the unique prefix of `remBits` on which a prefix-free coin consumer `f` halts. -/
noncomputable def consumePrefixCoinList {Out : Type}
    (f : List Bool → Option Out) (remBits : List Bool) : Option (Out × List Bool) :=
  open Classical in
  let candidates := (List.range (remBits.length + 1)).filterMap (fun k =>
    match f (remBits.take k) with
    | some v => some (v, remBits.drop k)
    | none => none)
  candidates.head?

/-- Run at most `k` independent sequential capped attempts of `attempt : List Bool → Option (Out × ℕ × ℕ)`
(returning `(value, work, peakSpace)`), stopping as soon as an attempt satisfies `isGood` and
returning `fallback` (with success flag `false`) if all `k` attempts fail, while accumulating total
work and maximum peak space across all executed attempts. -/
noncomputable def runRepeatedCappedAttempts {Out : Type}
    (attempt : List Bool → Option (Out × ℕ × ℕ))
    (isGood : Out → Prop) (fallback : Out) :
    ℕ → ℕ → ℕ → List Bool → Option (Out × Bool × ℕ × ℕ)
  | 0, accW, maxSp, [] => some (fallback, false, accW, maxSp)
  | 0, _, _, _ :: _ => none
  | k + 1, accW, maxSp, bs =>
      open Classical in
      match consumePrefixCoinList attempt bs with
      | none => none
      | some ((v, w, sp), rem) =>
          let accW' := accW + w
          let maxSp' := max maxSp sp
          if isGood v then
            if rem.isEmpty then some (v, true, accW', maxSp') else none
          else
            runRepeatedCappedAttempts attempt isGood fallback k accW' maxSp' rem

/-- Decode a list of bits `bs : List Bool` in binary (`head` most significant) into `ℕ`. -/
def decodeBitsNat : List Bool → ℕ :=
  List.foldl (fun acc b => 2 * acc + if b then 1 else 0) 0

/-- Single capped uniform rank-sampling trial on a pool of size `m ≥ 1` (Section 7.3, p. 33): draw
exactly `⌈log₂ m⌉` (`Nat.clog 2 m`) bits, decode to an integer in `{0, …, 2^{⌈log₂ m⌉} - 1}`, accept
`some ⟨val, _⟩` if `val < m`, and reject (`none`) if out of range, with unit/logarithmic bit work
`Nat.clog 2 m + 1` and space `Nat.clog 2 m + 1`. -/
def uniformRankSampleTrial (m : ℕ) (_hm : 1 ≤ m) (bs : List Bool) :
    Option (Option (Fin m) × ℕ × ℕ) :=
  let bLen := Nat.clog 2 m
  if bs.length = bLen then
    let val := decodeBitsNat bs
    if hlt : val < m then
      some (some ⟨val, hlt⟩, bLen + 1, bLen + 1)
    else
      some (none, bLen + 1, bLen + 1)
  else
    none

/-! ### 4. Sequential births conditioned on prior history and adaptive execution accounting -/

/-- Bounded-depth sequential birth controller within a single step: conditioned on the preceding
external `ExecutionHistory d` and the list of birth outcomes observed so far in the step, either
finishes with `(0 births, result)` or invokes a prefix-free single-birth constructor whose
conditional failure probability given the full prior history is at most `φ`. -/
inductive SequentialBirthController (d : ℕ) (BirthOut StepRes : Type) : Type
  | done (res : StepRes)
  | birth
      (draw : List Bool → Option BirthOut)
      (isSuccess : BirthOut → Prop)
      (next : BirthOut → SequentialBirthController d BirthOut StepRes)

/-- Well-formedness of a `SequentialBirthController` at conditional per-birth failure budget `φ`:
every invoked `draw` is prefix-free, halts with probability `1` under fresh fair bits, and fails
`isSuccess` with conditional probability at most `ENNReal.ofReal φ`. -/
def SequentialBirthController.ValidAtBudget {d : ℕ} {BirthOut StepRes : Type}
    (φ : ℝ) : SequentialBirthController d BirthOut StepRes → Prop
  | .done _ => True
  | .birth draw isSuccess next =>
      open Classical in
      (∀ u v : List Bool, (draw u).isSome → v ≠ [] → draw (u ++ v) = none) ∧
      (∑' u : List Bool, if (draw u).isSome then bitListProb u else 0) = 1 ∧
      (∑' u : List Bool,
        match draw u with
        | some out => if ¬ isSuccess out then bitListProb u else 0
        | none => 0) ≤ ENNReal.ofReal φ ∧
      (∀ out : BirthOut, (next out).ValidAtBudget φ)

/-- Execute a `SequentialBirthController` on fresh random bit list `bs`, returning `(result,
allBirthsSucceeded, birthsExecuted)` when `bs` is the exact concatenation of the fresh coin lists
consumed by each birth along the realized path. -/
noncomputable def runSequentialBirthController {d : ℕ} {BirthOut StepRes : Type} :
    SequentialBirthController d BirthOut StepRes → List Bool → Option (StepRes × Bool × ℕ)
  | .done res, [] => some (res, true, 0)
  | .done _, _ :: _ => none
  | .birth draw isSuccess next, bs =>
      open Classical in
      match consumePrefixCoinList draw bs with
      | none => none
      | some (out, rem) =>
          match runSequentialBirthController (next out) rem with
          | none => none
          | some (res, okRest, cntRest) =>
              some (res, decide (isSuccess out) && okRest, 1 + cntRest)

/-- Cumulative sum of `stepEventCount` across a multi-step adaptive execution from `cur` over
`bitTrace : List (List Bool)`. -/
noncomputable def adaptiveStepsTotalEvents {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d)
    (stepEventCount :
      DynamicPointSet d → ExecutionHistory d → State → DynamicUpdate d → List Bool → ℕ) :
    AdaptivePrefixState d State → List (List Bool) → ℕ
  | _, [] => 0
  | cur, b :: tail =>
      let op := adv cur.history
      match runSingleAdaptiveStep alg cur.pointSet cur.algState op b with
      | none => 0
      | some (P', out) =>
          let entry : StepHistoryEntry d :=
            { operation := op
              randomBits := b
              returnedHandle := out.returnedHandle
              answer := out.storedAnswer
              resolvedIds := resolveAnswerIdentities P' out.storedAnswer }
          let next : AdaptivePrefixState d State :=
            { pointSet := P'
              algState := out.nextState
              history := cur.history ++ [entry]
              snapshots := cur.snapshots ++ [(P', out.storedAnswer)]
              stepWorks := cur.stepWorks ++ [out.work]
              totalWork := cur.totalWork + out.work
              maxSpace := max cur.maxSpace out.peakSpace }
          stepEventCount cur.pointSet cur.history cur.algState op b +
            adaptiveStepsTotalEvents alg adv stepEventCount next tail

/-! ### 5. Statement of Claim (Sec. 7.3: One failure budget for the whole execution) -/

/-- Claim (Sec. 7.3: One failure budget for the whole execution) (paper p.33). Exactly the paper's
statement, as a Prop:
1. Scale `S = n + t + d + B + ⌈log(2/δ)⌉ + 2` (`execFailureScaleBit`, equal to `execFailureScaleArith`
   at `B = 0`, omitting `B` in the arithmetic model) and predetermined polynomial bound in `S` from
   the capped schedules on center constructions, filter constructions, verification attempts, and
   witness samples across any `T ≤ t` valid updates of Algorithm 4 (holding on every outcome,
   including failure outcomes);
2. Failure-outcome preservation of contraction (`selectOpenedLevelBall` satisfies `PassesBirthCoreCheck`
   even on infeasible/failed center samples) and local-matching structural/repair invariants
   (`checkedConfigInsertOriginal` and `checkedConfigDeleteOriginal` check reported positive answers
   against current identities, preserve `ValidNodeMatchingsOn` unconditionally, and trigger at most
   `2` repairs per configuration);
3. Fixed exponent `C₁` assigning per-event conditional failure probability `δ / S^{C₁}`, together
   with `O(log(S/δ))` independent capped constructor attempts (`runRepeatedCappedAttempts`) achieving
   failure probability `≤ δ / S^{C₁}` for any constant success probability `p₀ ∈ (0, 1]` while
   preserving work and space caps on failure outcomes (including capped `⌈log₂ m⌉`-bit uniform rank
   sampling with per-trial success probability `≥ 1/2` and rank-zero/first-element fallback);
4. History-conditioned sequential birth union bound: conditioning at each birth on the entire
   previous history before drawing fresh random bits, per-birth conditional failure probability
   `≤ φ` bounds multi-birth failure probability by `E[birthsExecuted * φ]`;
5. Full adaptive execution union bound over horizon `t` (`n ≥ 2`, `t ≥ 1`, `δ ∈ (0, 1/2)`):
   assigning conditional failure probability `δ / S^{C₁}` to at most `M_max ≤ C_ev S^{deg_ev}`
   events across `T ≤ t` adaptive updates yields probability at least `1 - δ` that all required
   events succeed (`SatisfiesMonteCarloGuarantee`), while per-step work and space bounds holding on
   failure outcomes yield `SatisfiesBoundedWorstCaseUpdateWorkBound` and `SatisfiesBoundedSpaceBound`. -/
def S_clm_7_3_failure_budget : Prop :=
  open Classical in
  -- (1) Scale S (omitting B in the arithmetic model) and predetermined polynomial bound in S on
  -- center constructions, filter constructions, verification attempts, and witness samples:
  ((∀ (n t d B : ℕ) (δ : ℝ),
      2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
        execFailureScaleArith n t d δ = execFailureScaleBit n t d 0 δ ∧
        5 ≤ execFailureScaleBit n t d B δ) ∧
    ∀ (C_sched : ℝ) (deg_sched : ℕ), 0 ≤ C_sched →
      ∃ (C_ev : ℝ) (deg_ev : ℕ), 0 ≤ C_ev ∧
        ∀ (d n t B : ℕ) (δ : ℝ),
          2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
            let S := execFailureScaleBit n t d B δ
            ∀ (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ)
              (caps : CappedScheduleEventBounds)
              (steps : List (Alg4PointUpdate d ℕ × Alg4StepChoices d ℕ)),
              caps.IsPolyBoundedInScale C_sched deg_sched S →
              (∀ V : ℝ, (mode.retainedConfigs V).card ≤ caps.retainedConfigCap) →
              steps.length ≤ t →
              ValidAlg4UpdateList n mode α L reclaimMult (Alg4State.empty d ℕ) steps →
              (∀ pair ∈ steps, pair.2.IsScheduleCapped caps) →
                let counts :=
                  totalAlg4EventCounts mode α L reclaimMult caps (Alg4State.empty d ℕ) steps
                (counts.centerConstructions : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev) ∧
                (counts.filterConstructions : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev) ∧
                (counts.verificationAttempts : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev) ∧
                (counts.witnessSamples : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev) ∧
                (counts.total : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev)) ∧
  -- (2) Unconditional failure-outcome guarantees on fallback centers and checked matching repairs:
  ((∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ) (S_birth : Finset ι) (bId : ι) (res : SampledCenterResult d),
      0 < α → α ≤ 1 → bId ∈ S_birth →
        let ball := selectOpenedLevelBall α pts S_birth bId res
        PassesBirthCoreCheck α pts ball S_birth ∧
        (ball.residual pts S_birth).card < S_birth.card) ∧
    (∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (params : LocalScaleParams) (ball : ChainNode d)
      (S : Finset ι) (states : ShellConfig → LocalMatchingState ι),
      ValidNodeMatchingsOn pts (.subSqrt2 params) ball S states →
        (∀ (p : ι) (qAns : NodeMatchingQueryAnswers ι),
          p ∉ S →
            ValidNodeMatchingsOn pts (.subSqrt2 params) ball (insert p S)
              (applyNodeMatchingInsert pts (.subSqrt2 params) ball states p qAns)) ∧
        (∀ (p : ι) (qAns : NodeMatchingQueryAnswers ι),
          p ∈ S →
            ValidNodeMatchingsOn pts (.subSqrt2 params) ball (S.erase p)
              (applyNodeMatchingDelete pts (.subSqrt2 params) ball states p qAns) ∧
            ∀ cfg ∈ (Alg4Mode.subSqrt2 params).retainedConfigs ball.V,
              (survivingFormerPartners (states cfg) p).length ≤ 2 ∧
              checkedConfigDeleteOriginal pts params ball.o ball.V cfg (states cfg) p
                  (qAns.deleteRepairAns cfg) =
                checkedConfigDeleteOriginal pts params ball.o ball.V cfg (states cfg) p
                  ((qAns.deleteRepairAns cfg).take 2)))) ∧
  -- (3) Fixed exponent C₁, O(log(S/δ)) independent capped constructor attempts, and capped rank sampling:
  ((∀ (C_ev : ℝ) (deg_ev : ℕ), 0 ≤ C_ev →
      ∃ C₁ : ℕ, 1 ≤ C₁ ∧
        ∀ (d n t B : ℕ) (δ : ℝ),
          2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
            let S := execFailureScaleBit n t d B δ
            let φ := perEventFailureBudget S C₁ δ
            0 < φ ∧ φ < δ ∧
            (C_ev * ((S : ℝ) ^ deg_ev)) * φ ≤ δ) ∧
    (∀ (p₀ : ℝ) (C₁ : ℕ), 0 < p₀ → p₀ ≤ 1 → 1 ≤ C₁ →
      ∃ C_try : ℝ, 0 < C_try ∧
        ∀ (d n t B : ℕ) (δ : ℝ),
          2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
            let S := execFailureScaleBit n t d B δ
            let φ := perEventFailureBudget S C₁ δ
            ∃ K_try : ℕ,
              1 ≤ K_try ∧
              (K_try : ℝ) ≤ C_try * Real.log ((S : ℝ) / δ) ∧
              (1 - p₀) ^ K_try ≤ φ ∧
              ∀ (Out : Type) (attempt : List Bool → Option (Out × ℕ × ℕ))
                (isGood : Out → Prop) (fallback : Out) (W_cap Sp_cap : ℕ),
                (∀ u v : List Bool, (attempt u).isSome → v ≠ [] → attempt (u ++ v) = none) →
                (∑' u : List Bool, if (attempt u).isSome then bitListProb u else 0) = 1 →
                (∀ (u : List Bool) (val : Out) (w sp : ℕ),
                  attempt u = some (val, w, sp) → w ≤ W_cap ∧ sp ≤ Sp_cap) →
                ENNReal.ofReal p₀ ≤
                  (open Classical in
                    ∑' u : List Bool,
                      match attempt u with
                      | some (val, _, _) => if isGood val then bitListProb u else 0
                      | none => 0) →
                let boosted := runRepeatedCappedAttempts attempt isGood fallback K_try 0 0
                (∀ u v : List Bool, (boosted u).isSome → v ≠ [] → boosted (u ++ v) = none) ∧
                (∑' u : List Bool, if (boosted u).isSome then bitListProb u else 0) = 1 ∧
                (∀ (u : List Bool) (val : Out) (ok : Bool) (w sp : ℕ),
                  boosted u = some (val, ok, w, sp) →
                    w ≤ K_try * W_cap ∧ sp ≤ Sp_cap ∧ (ok = true → isGood val)) ∧
                (∑' u : List Bool,
                  match boosted u with
                  | some (_, ok, _, _) => if ok = false then bitListProb u else 0
                  | none => 0) ≤ ENNReal.ofReal φ) ∧
    (∀ (m : ℕ) (hm : 1 ≤ m),
      let trial := uniformRankSampleTrial m hm
      (∀ u v : List Bool, (trial u).isSome → v ≠ [] → trial (u ++ v) = none) ∧
      (∑' u : List Bool, if (trial u).isSome then bitListProb u else 0) = 1 ∧
      ENNReal.ofReal (1 / 2 : ℝ) ≤
        (∑' u : List Bool,
          match trial u with
          | some (optIdx, _, _) => if optIdx.isSome then bitListProb u else 0
          | none => 0) ∧
      ∀ r₁ r₂ : Fin m,
        (∑' u : List Bool,
          match trial u with
          | some (some r, _, _) => if r = r₁ then bitListProb u else 0
          | _ => 0) =
        (∑' u : List Bool,
          match trial u with
          | some (some r, _, _) => if r = r₂ then bitListProb u else 0
          | _ => 0))) ∧
  -- (4) History-conditioned sequential birth union bound within a step:
  (∀ (d : ℕ) (BirthOut StepRes : Type) (φ : ℝ)
    (ctrl : SequentialBirthController d BirthOut StepRes),
    0 ≤ φ →
    ctrl.ValidAtBudget φ →
      let run := runSequentialBirthController ctrl
      (∀ u v : List Bool, (run u).isSome → v ≠ [] → run (u ++ v) = none) ∧
      (∑' u : List Bool, if (run u).isSome then bitListProb u else 0) = 1 ∧
      (∑' u : List Bool,
        match run u with
        | some (_, ok, _) => if ok = false then bitListProb u else 0
        | none => 0) ≤
      (∑' u : List Bool,
        match run u with
        | some (_, _, cnt) => bitListProb u * ENNReal.ofReal ((cnt : ℝ) * φ)
        | none => 0)) ∧
  -- (5) Full horizon-t adaptive conditional union bound & failure-safe work/space budgets:
  (∀ (d n t B : ℕ) (δ c stepWorkBound spaceBound C_ev : ℝ) (deg_ev C₁ M_max : ℕ)
    (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (State : Type) (alg : DynamicDiameterStructure d State)
    (GoodState : DynamicPointSet d → ExecutionHistory d → State → Prop)
    (stepEventCount :
      DynamicPointSet d → ExecutionHistory d → State → DynamicUpdate d → List Bool → ℕ),
    2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
    let S := execFailureScaleBit n t d B δ
    let φ := perEventFailureBudget S C₁ δ
    (M_max : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev) →
    (C_ev * ((S : ℝ) ^ deg_ev)) * φ ≤ δ →
    (alg.initWork : ℝ) ≤ stepWorkBound →
    (alg.initSpace : ℝ) ≤ spaceBound →
    GoodState (DynamicPointSet.empty d) [] alg.initState →
    (∀ adv : AdaptiveAdversary d,
      IsValidBoundedAdversary n t admissiblePts alg adv →
      (∀ (T : ℕ) (trace : Fin T → List Bool),
        T ≤ t →
        (runAdaptivePrefix alg adv T trace).isSome →
          adaptiveStepsTotalEvents alg adv stepEventCount
            (initAdaptivePrefixState alg) (List.ofFn trace) ≤ M_max) ∧
      (∀ (bitTrace : List (List Bool)) (prefSt : AdaptivePrefixState d State),
        bitTrace.length < t →
        runAdaptiveSteps alg adv bitTrace = some prefSt →
          let op := adv prefSt.history
          singleStepValidHaltProb alg prefSt.pointSet prefSt.algState op = 1 ∧
          (∀ (bs : List Bool) (P' : DynamicPointSet d) (out : DynamicStepOutcome State),
            runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs = some (P', out) →
              (out.work : ℝ) ≤ stepWorkBound ∧ (out.peakSpace : ℝ) ≤ spaceBound) ∧
          (GoodState prefSt.pointSet prefSt.history prefSt.algState →
            (∀ (bs : List Bool) (P' : DynamicPointSet d) (out : DynamicStepOutcome State),
              runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs = some (P', out) →
                let entry : StepHistoryEntry d :=
                  { operation := op
                    randomBits := bs
                    returnedHandle := out.returnedHandle
                    answer := out.storedAnswer
                    resolvedIds := resolveAnswerIdentities P' out.storedAnswer }
                GoodState P' (prefSt.history ++ [entry]) out.nextState →
                  IsValidFactorCAnswer c P' out.storedAnswer) ∧
            (open Classical in
              ∑' bs : List Bool,
                match runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs with
                | some (P', out) =>
                    let entry : StepHistoryEntry d :=
                      { operation := op
                        randomBits := bs
                        returnedHandle := out.returnedHandle
                        answer := out.storedAnswer
                        resolvedIds := resolveAnswerIdentities P' out.storedAnswer }
                    if ¬ GoodState P' (prefSt.history ++ [entry]) out.nextState then
                      bitListProb bs
                    else
                      0
                | none => 0) ≤
            (∑' bs : List Bool,
              if (runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs).isSome then
                bitListProb bs *
                  ENNReal.ofReal
                    ((stepEventCount prefSt.pointSet prefSt.history prefSt.algState op bs : ℝ) * φ)
              else
                0)))) →
      SatisfiesMonteCarloGuarantee n t δ c admissiblePts alg ∧
      SatisfiesBoundedWorstCaseUpdateWorkBound n t admissiblePts alg stepWorkBound ∧
      SatisfiesBoundedSpaceBound n t admissiblePts alg spaceBound)

end UL
