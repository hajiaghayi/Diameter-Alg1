import Mathlib
import UL.Def.def_halfspace_depth
set_option autoImplicit false

namespace UL

/-- VC Uniform-Convergence Theorem for Halfspaces [VC71] (paper p.45). Exactly the paper's statement, as a Prop. -/
def S_cit_vc71_halfspace_uc : Prop :=
  ∃ C₀ : ℝ, 0 < C₀ ∧
    ∀ (D : ℕ), 1 ≤ D →
    ∀ (ι : Type) [Fintype ι] [Nonempty ι] [MeasurableSpace ι] [DiscreteMeasurableSpace ι]
      (P : ι → EuclideanSpace ℝ (Fin D)),
    ∀ (r s : ℕ), 1 ≤ r → 1 ≤ s →
    ∀ (φ : ℝ), 0 < φ → φ < 1 →
      C₀ * (s : ℝ) ^ 2 * (((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ)) ≤
        (r : ℝ) * (s : ℝ) →
      let μ : Set (EuclideanSpace ℝ (Fin D)) → ℝ :=
        fun H => (pointCount P H : ℝ) / (Fintype.card ι : ℝ)
      let μ_hat : (Fin (r * s) → ι) → Set (EuclideanSpace ℝ (Fin D)) → ℝ :=
        fun ω H => (pointCount (fun t : Fin (r * s) => P (ω t)) H : ℝ) / ((r : ℝ) * (s : ℝ))
      1 - φ / 2 ≤
        (MeasureTheory.Measure.pi
          (fun _ : Fin (r * s) => (PMF.uniformOfFintype ι).toMeasure)).real
          {ω : Fin (r * s) → ι |
            (⨆ H : {H : Set (EuclideanSpace ℝ (Fin D)) // IsClosedHalfspace H},
              |μ_hat ω H.1 - μ H.1|) ≤ 1 / (2 * (s : ℝ))}

end UL
