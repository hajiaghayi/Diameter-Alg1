import Mathlib
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Def.def_6_search_interface
import UL.Def.def_C_3_birth_var
set_option autoImplicit false

namespace UL

/-- Zero-coin halting computation returning `a` iff `bs` is empty. -/
def pureWithBits {α : Type} (a : α) (bs : List Bool) : Option α :=
  if bs.isEmpty then some a else none

/-- Sequential composition of randomized bit-consuming computations `f` and `g` on `bs = bs₁ ++ bs₂`
(uniquely determined whenever `f` is prefix-free). -/
noncomputable def bindWithBits {α β : Type}
    (f : List Bool → Option α) (g : α → List Bool → Option β)
    (bs : List Bool) : Option β :=
  open Classical in
  if h : ∃ (bs₁ bs₂ : List Bool) (a : α), bs = bs₁ ++ bs₂ ∧ f bs₁ = some a then
    let bs₁ := Classical.choose h
    let h₂ := Classical.choose_spec h
    let bs₂ := Classical.choose h₂
    let h₃ := Classical.choose_spec h₂
    let a := Classical.choose h₃
    g a bs₂
  else
    none

/-- Build `R` independent certified copies of `inst` at external history `hist`, summing their
construction work. -/
noncomputable def buildRCopies
    {ι : Type} {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (hist : ExecutionHistory d) :
    ℕ → List Bool → Option (List (BirthState × PhaseState) × ℕ)
  | 0 => pureWithBits ([], 0)
  | r + 1 =>
      bindWithBits (inst.buildWithBits hist) (fun bOut =>
        bindWithBits (buildRCopies inst hist r) (fun cw =>
          pureWithBits ((bOut.birthState, bOut.initPhase) :: cw.1, bOut.work + cw.2)))

/-- Delete `i` across a list of certified copies on current surviving subset `S`, summing deletion
and internal phase-rebuild work across all copies. -/
noncomputable def deleteRCopies
    {ι : Type} {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (stepHist : ExecutionHistory d) (S : Finset ι) (i : ι) :
    List (BirthState × PhaseState) → List Bool → Option (List (BirthState × PhaseState) × ℕ)
  | [] => pureWithBits ([], 0)
  | (bSt, ph) :: rest =>
      bindWithBits (inst.deleteWithBits stepHist bSt S ph i) (fun dOut =>
        bindWithBits (deleteRCopies inst stepHist S i rest) (fun cw =>
          pureWithBits ((bSt, dOut.nextPhase) :: cw.1, dOut.work + cw.2)))

/-- Replay an ordered list of prior deletions from `S` across all copies in `copies`, summing work. -/
noncomputable def deleteRCopiesList
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (curHist : ExecutionHistory d) :
    Finset ι → List ι → List (BirthState × PhaseState) →
      List Bool → Option (List (BirthState × PhaseState) × ℕ)
  | _, [], copies => pureWithBits (copies, 0)
  | S, i :: rest, copies =>
      bindWithBits (deleteRCopies inst curHist S i copies) (fun cw₁ =>
        bindWithBits (deleteRCopiesList inst curHist (S.erase i) rest cw₁.1) (fun cw₂ =>
          pureWithBits (cw₂.1, cw₁.2 + cw₂.2)))

/-- Deterministically query copies sequentially under per-copy work cap `cap`, stopping as soon as a
copy completes within budget `cap` and summing all work spent. -/
def queryRCopiesCapped
    {ι : Type} {d d_s : ℕ} {BirthState PhaseState : Type}
    (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (S : Finset ι) (q : SearchQuery ι d_s) (cap : ℕ) :
    List (BirthState × PhaseState) → Option (Option ι) × ℕ
  | [] => (none, 0)
  | (bSt, ph) :: rest =>
      let cOut := inst.runQueryCapped bSt S ph q cap
      match cOut.completedAnswer with
      | some ans => (some ans, cOut.work)
      | none =>
          let (mAns, remWork) := queryRCopiesCapped inst S q cap rest
          (mAns, cOut.work + remWork)

/-- Live compiled bundle maintained by the horizon-free adaptive certified generation compiler for
one opened `CertifiedSearchGeneration`: maintains `R` independent copies on `survivingSet` together
with the ordered list `deletedIds` of elements deleted from `P₀` so far (used if all `R` copies
exceed `cap` and the bundle is rebuilt from fresh randomness). -/
structure CompiledCertifiedGenBundle (ι : Type) (d d_s : ℕ)
    (BirthState PhaseState : Type) : Type where
  inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState
  epochBirthHist : ExecutionHistory d
  survivingSet : Finset ι
  deletedIds : List ι
  copies : List (BirthState × PhaseState)

/-- Rebuild a fresh epoch of `R` independent copies for `bundle` at `curHist` and replay all prior
deletions `bundle.deletedIds` down to `bundle.survivingSet`, returning the refreshed bundle and
total rebuild + replay work. -/
noncomputable def rebuildCompiledBundle
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R : ℕ) (curHist : ExecutionHistory d)
    (bundle : CompiledCertifiedGenBundle ι d d_s BirthState PhaseState) :
    List Bool → Option (CompiledCertifiedGenBundle ι d d_s BirthState PhaseState × ℕ) :=
  bindWithBits (buildRCopies bundle.inst curHist R) (fun bw =>
    bindWithBits (deleteRCopiesList bundle.inst curHist bundle.inst.gen.P₀ bundle.deletedIds bw.1)
      (fun dw =>
        pureWithBits
          ({ bundle with epochBirthHist := curHist, copies := dw.1 }, bw.2 + dw.2)))

/-- Fuel-bounded execution of a compiled certified query with automatic full-bundle rebuild and
retry whenever all `R` copies abort at work cap `cap`. -/
noncomputable def runCompiledQueryFuel
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ) (curHist : ExecutionHistory d) (q : SearchQuery ι d_s) :
    ℕ → CompiledCertifiedGenBundle ι d d_s BirthState PhaseState → ℕ →
      List Bool → Option (CompiledCertifiedGenBundle ι d d_s BirthState PhaseState × Option ι × ℕ)
  | 0, _, _, _ => none
  | fuel + 1, bundle, accWork, bs =>
      let (mAns, qWork) :=
        queryRCopiesCapped bundle.inst bundle.survivingSet q cap bundle.copies
      match mAns with
      | some ans =>
          if bs.isEmpty then
            some (bundle, ans, accWork + qWork)
          else
            none
      | none =>
          bindWithBits (rebuildCompiledBundle R curHist bundle) (fun rw =>
            runCompiledQueryFuel R cap curHist q fuel rw.1
              (accWork + qWork + rw.2)) bs

/-- Execute a compiled certified query on `bundle` at `curHist`: tries up to `R` copies under budget
`cap`, and if all `R` copies abort, rebuilds a fresh `R`-copy bundle (replaying `deletedIds`) and
retries until a copy completes within `cap`. -/
noncomputable def runCompiledQuery
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ) (curHist : ExecutionHistory d)
    (bundle : CompiledCertifiedGenBundle ι d d_s BirthState PhaseState)
    (q : SearchQuery ι d_s) (bs : List Bool) :
    Option (CompiledCertifiedGenBundle ι d d_s BirthState PhaseState × Option ι × ℕ) :=
  runCompiledQueryFuel R cap curHist q (bs.length + 2) bundle 0 bs

/-- Externally visible metadata supplied when closing an external update step into
`ExecutionHistory d` (`randomBits` is populated by the compiler with the exact coins consumed during
that step). -/
structure ExternalStepSummary (d : ℕ) : Type where
  operation : DynamicUpdate d
  returnedHandle : Option ℕ
  answer : StoredDiameterAnswer
  resolvedIds : Option (ℕ × ℕ)

/-- Record of a completed compiled search query for verifying zero-error answer correctness. -/
structure CompiledQueryRecord (ι : Type) (d_s : ℕ) : Type where
  gid : ℕ
  gen : SearchGeneration ι d_s
  survivingSet : Finset ι
  query : SearchQuery ι d_s
  answer : Option ι

/-- Intra-step action issued by an adaptive search caller/controller to the certified generation
compiler during an external update step. -/
inductive SearchControllerAction (ι : Type) (d d_s : ℕ)
    (BirthState PhaseState : Type) : Type
  | openGen (inst : CertifiedSearchGeneration ι d d_s BirthState PhaseState)
  | deleteFromGen (gid : ℕ) (i : ι)
  | cancelGen (gid : ℕ)
  | queryGen (gid : ℕ) (q : SearchQuery ι d_s)
  | finishExternalStep (summary : ExternalStepSummary d)

/-- Complete state of the horizon-free adaptive certified generation compiler across unbounded
external updates. -/
structure CompiledSearchSystemState (ι : Type) (d d_s : ℕ)
    (BirthState PhaseState : Type) : Type where
  history : ExecutionHistory d
  generations : List (Option (CompiledCertifiedGenBundle ι d d_s BirthState PhaseState))
  birthSnapshots : List (ExecutionHistory d × List Bool)
  queryRecords : List (CompiledQueryRecord ι d_s)
  totalBirthCard : ℕ
  totalDeletes : ℕ
  totalCancels : ℕ
  totalQueries : ℕ
  totalSearchWork : ℕ

/-- Initial empty compiler state prior to the first external update (needs no prescribed horizon). -/
def initCompiledSearchSystemState (ι : Type) (d d_s : ℕ)
    (BirthState PhaseState : Type) :
    CompiledSearchSystemState ι d d_s BirthState PhaseState :=
  { history := []
    generations := []
    birthSnapshots := []
    queryRecords := []
    totalBirthCard := 0
    totalDeletes := 0
    totalCancels := 0
    totalQueries := 0
    totalSearchWork := 0 }

/-- An adaptive search controller chooses each intra-step search operation (opening a certified
generation, deleting a point from an active generation, canceling an obsolete generation, querying
an active generation, or finishing the external update step) as an arbitrary function of the
complete exposed compiler state and execution history. -/
structure AdaptiveSearchController (ι : Type) (d d_s : ℕ)
    (BirthState PhaseState : Type) : Type where
  nextAction :
    CompiledSearchSystemState ι d d_s BirthState PhaseState →
      SearchControllerAction ι d d_s BirthState PhaseState

/-- Structural upper bound on the number of valid intra-step controller actions during external
update step `u` (`0`-indexed) under amortized birth-cardinality factor `B_birth d n` and query
factor `Q_poly d B n`. -/
noncomputable def compiledStepActionBudget
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d B n u : ℕ) : ℕ :=
  3 * Nat.floor (((u + 1 : ℕ) : ℝ) * B_birth d n) +
    Nat.floor (((u + 1 : ℕ) : ℝ) * Q_poly d B n) + 2

/-- Fuel-bounded intra-step execution of controller actions within one external update step,
accumulating the exact random bits `accBits` drawn during the step to record in `ExecutionHistory d`. -/
noncomputable def runCompiledStepActionsFuel
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (ctrl : AdaptiveSearchController ι d d_s BirthState PhaseState) :
    ℕ → CompiledSearchSystemState ι d d_s BirthState PhaseState → List Bool →
      List Bool → Option (CompiledSearchSystemState ι d d_s BirthState PhaseState)
  | 0, _, _, _ => none
  | fuel + 1, cur, accBits, bs =>
      match ctrl.nextAction cur with
      | .finishExternalStep summary =>
          if bs.isEmpty then
            let entry : StepHistoryEntry d :=
              { operation := summary.operation
                randomBits := accBits
                returnedHandle := summary.returnedHandle
                answer := summary.answer
                resolvedIds := summary.resolvedIds }
            some { cur with history := cur.history ++ [entry] }
          else
            none
      | .openGen inst =>
          open Classical in
          if h : ∃ (bs₁ bs₂ : List Bool) (bw : List (BirthState × PhaseState) × ℕ),
              bs = bs₁ ++ bs₂ ∧ buildRCopies inst cur.history R bs₁ = some bw then
            let bs₁ := Classical.choose h
            let h₂ := Classical.choose_spec h
            let bs₂ := Classical.choose h₂
            let h₃ := Classical.choose_spec h₂
            let bw := Classical.choose h₃
            let bundle : CompiledCertifiedGenBundle ι d d_s BirthState PhaseState :=
              { inst := inst
                epochBirthHist := cur.history
                survivingSet := inst.gen.P₀
                deletedIds := []
                copies := bw.1 }
            let next : CompiledSearchSystemState ι d d_s BirthState PhaseState :=
              { cur with
                generations := cur.generations ++ [some bundle]
                birthSnapshots := cur.birthSnapshots ++ [(cur.history, bs₁)]
                totalBirthCard := cur.totalBirthCard + inst.gen.m
                totalSearchWork := cur.totalSearchWork + bw.2 }
            runCompiledStepActionsFuel R cap ctrl fuel next (accBits ++ bs₁) bs₂
          else
            none
      | .deleteFromGen gid i =>
          match cur.generations[gid]? with
          | some (some bundle) =>
              if i ∈ bundle.survivingSet then
                open Classical in
                if h : ∃ (bs₁ bs₂ : List Bool) (dw : List (BirthState × PhaseState) × ℕ),
                    bs = bs₁ ++ bs₂ ∧
                    deleteRCopies bundle.inst cur.history bundle.survivingSet i bundle.copies bs₁ =
                      some dw then
                  let bs₁ := Classical.choose h
                  let h₂ := Classical.choose_spec h
                  let bs₂ := Classical.choose h₂
                  let h₃ := Classical.choose_spec h₂
                  let dw := Classical.choose h₃
                  let bundle' : CompiledCertifiedGenBundle ι d d_s BirthState PhaseState :=
                    { bundle with
                      survivingSet := bundle.survivingSet.erase i
                      deletedIds := bundle.deletedIds ++ [i]
                      copies := dw.1 }
                  let next : CompiledSearchSystemState ι d d_s BirthState PhaseState :=
                    { cur with
                      generations := cur.generations.set gid (some bundle')
                      totalDeletes := cur.totalDeletes + 1
                      totalSearchWork := cur.totalSearchWork + dw.2 }
                  runCompiledStepActionsFuel R cap ctrl fuel next (accBits ++ bs₁) bs₂
                else
                  none
              else
                none
          | _ => none
      | .cancelGen gid =>
          match cur.generations[gid]? with
          | some (some _) =>
              let next : CompiledSearchSystemState ι d d_s BirthState PhaseState :=
                { cur with
                  generations := cur.generations.set gid none
                  totalCancels := cur.totalCancels + 1 }
              runCompiledStepActionsFuel R cap ctrl fuel next accBits bs
          | _ => none
      | .queryGen gid q =>
          match cur.generations[gid]? with
          | some (some bundle) =>
              open Classical in
              if h : ∃ (bs₁ bs₂ : List Bool)
                  (qw : CompiledCertifiedGenBundle ι d d_s BirthState PhaseState × Option ι × ℕ),
                  bs = bs₁ ++ bs₂ ∧
                  runCompiledQuery R cap cur.history bundle q bs₁ = some qw then
                let bs₁ := Classical.choose h
                let h₂ := Classical.choose_spec h
                let bs₂ := Classical.choose h₂
                let h₃ := Classical.choose_spec h₂
                let qw := Classical.choose h₃
                let qRec : CompiledQueryRecord ι d_s :=
                  { gid := gid
                    gen := bundle.inst.gen
                    survivingSet := bundle.survivingSet
                    query := q
                    answer := qw.2.1 }
                let next : CompiledSearchSystemState ι d d_s BirthState PhaseState :=
                  { cur with
                    generations := cur.generations.set gid (some qw.1)
                    queryRecords := cur.queryRecords ++ [qRec]
                    totalQueries := cur.totalQueries + 1
                    totalSearchWork := cur.totalSearchWork + qw.2.2 }
                runCompiledStepActionsFuel R cap ctrl fuel next (accBits ++ bs₁) bs₂
              else
                none
          | _ => none

/-- Execute one complete external update step from `cur` under horizon-free compiler parameters
`(R, cap)` consuming fresh random bits `bs`. -/
noncomputable def runSingleCompiledSearchStep
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d_param B n : ℕ)
    (ctrl : AdaptiveSearchController ι d d_s BirthState PhaseState)
    (cur : CompiledSearchSystemState ι d d_s BirthState PhaseState)
    (bs : List Bool) :
    Option (CompiledSearchSystemState ι d d_s BirthState PhaseState) :=
  let budget := compiledStepActionBudget B_birth Q_poly d_param B n cur.history.length
  runCompiledStepActionsFuel R cap ctrl budget cur [] bs

/-- Continue an adaptive compiled certified-search execution across a list of per-step random bit
lists `bitTrace`. -/
noncomputable def runCompiledSearchStepsFrom
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d_param B n : ℕ)
    (ctrl : AdaptiveSearchController ι d d_s BirthState PhaseState)
    (cur : CompiledSearchSystemState ι d d_s BirthState PhaseState) :
    List (List Bool) → Option (CompiledSearchSystemState ι d d_s BirthState PhaseState)
  | [] => some cur
  | bs :: rest =>
      match runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl cur bs with
      | none => none
      | some next => runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl next rest

/-- Run an adaptive compiled certified-search execution from the empty initial state over `bitTrace`
(with no prescribed horizon). -/
noncomputable def runCompiledSearchSteps
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d_param B n : ℕ)
    (ctrl : AdaptiveSearchController ι d d_s BirthState PhaseState)
    (bitTrace : List (List Bool)) :
    Option (CompiledSearchSystemState ι d d_s BirthState PhaseState) :=
  runCompiledSearchStepsFrom R cap B_birth Q_poly d_param B n ctrl
    (initCompiledSearchSystemState ι d d_s BirthState PhaseState) bitTrace

/-- Run a fixed finite prefix of `t` external updates of an adaptive compiled certified-search
execution. -/
noncomputable def runCompiledSearchPrefix
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d_param B n : ℕ)
    (ctrl : AdaptiveSearchController ι d d_s BirthState PhaseState)
    (t : ℕ) (trace : Fin t → List Bool) :
    Option (CompiledSearchSystemState ι d d_s BirthState PhaseState) :=
  runCompiledSearchSteps R cap B_birth Q_poly d_param B n ctrl (List.ofFn trace)

/-- Reachability of intra-step state `st` during external step `prefSt.history.length` from a
reachable step-boundary state `prefSt`. -/
def IsReachableIntraStepState
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d_param B n : ℕ)
    (ctrl : AdaptiveSearchController ι d d_s BirthState PhaseState)
    (st : CompiledSearchSystemState ι d d_s BirthState PhaseState) : Prop :=
  ∃ (bitTrace : List (List Bool))
    (prefSt : CompiledSearchSystemState ι d d_s BirthState PhaseState),
    runCompiledSearchSteps R cap B_birth Q_poly d_param B n ctrl bitTrace = some prefSt ∧
    ∃ (k : ℕ) (subBits : Fin k → List Bool),
      let stepOnce := fun (curAcc : CompiledSearchSystemState ι d d_s BirthState PhaseState × List Bool)
          (bs : List Bool) =>
        match ctrl.nextAction curAcc.1 with
        | .finishExternalStep _ => none
        | .openGen inst =>
            (buildRCopies inst curAcc.1.history R bs).map (fun bw =>
              let bundle : CompiledCertifiedGenBundle ι d d_s BirthState PhaseState :=
                { inst := inst
                  epochBirthHist := curAcc.1.history
                  survivingSet := inst.gen.P₀
                  deletedIds := []
                  copies := bw.1 }
              ({ curAcc.1 with
                  generations := curAcc.1.generations ++ [some bundle]
                  birthSnapshots := curAcc.1.birthSnapshots ++ [(curAcc.1.history, bs)]
                  totalBirthCard := curAcc.1.totalBirthCard + inst.gen.m
                  totalSearchWork := curAcc.1.totalSearchWork + bw.2 },
               curAcc.2 ++ bs))
        | .deleteFromGen gid i =>
            match curAcc.1.generations[gid]? with
            | some (some bundle) =>
                if i ∈ bundle.survivingSet then
                  (deleteRCopies bundle.inst curAcc.1.history bundle.survivingSet i bundle.copies bs).map
                    (fun dw =>
                      let bundle' : CompiledCertifiedGenBundle ι d d_s BirthState PhaseState :=
                        { bundle with
                          survivingSet := bundle.survivingSet.erase i
                          deletedIds := bundle.deletedIds ++ [i]
                          copies := dw.1 }
                      ({ curAcc.1 with
                          generations := curAcc.1.generations.set gid (some bundle')
                          totalDeletes := curAcc.1.totalDeletes + 1
                          totalSearchWork := curAcc.1.totalSearchWork + dw.2 },
                       curAcc.2 ++ bs))
                else none
            | _ => none
        | .cancelGen gid =>
            match curAcc.1.generations[gid]? with
            | some (some _) =>
                if bs.isEmpty then
                  some ({ curAcc.1 with
                            generations := curAcc.1.generations.set gid none
                            totalCancels := curAcc.1.totalCancels + 1 },
                        curAcc.2)
                else none
            | _ => none
        | .queryGen gid q =>
            match curAcc.1.generations[gid]? with
            | some (some bundle) =>
                (runCompiledQuery R cap curAcc.1.history bundle q bs).map (fun qw =>
                  let qRec : CompiledQueryRecord ι d_s :=
                    { gid := gid
                      gen := bundle.inst.gen
                      survivingSet := bundle.survivingSet
                      query := q
                      answer := qw.2.1 }
                  ({ curAcc.1 with
                      generations := curAcc.1.generations.set gid (some qw.1)
                      queryRecords := curAcc.1.queryRecords ++ [qRec]
                      totalQueries := curAcc.1.totalQueries + 1
                      totalSearchWork := curAcc.1.totalSearchWork + qw.2.2 },
                   curAcc.2 ++ bs))
            | _ => none
      ∃ accBits : List Bool,
        (List.ofFn subBits).foldlM stepOnce (prefSt, []) = some (st, accBits)

/-- Validity of an adaptive search controller under the certified birth-variable interface:
there exists an analysis-only implicit direction net family `netOfGen` (fixed at each generation's
birth state prior to its fresh coins, and never passed to the compiler) such that on every reachable
intra-step state `st` during external step `u = st.history.length`:
1. `openGen inst` opens a certified generation satisfying `SatisfiesCertifiedBirthVarOnNet` on its
   birth-fixed implicit net `netOfGen st.generations.length st` while keeping cumulative birth
   cardinality `∑ m ≤ (u + 1) B_birth(d, n)`;
2. `deleteFromGen gid i` deletes a currently surviving member `i ∈ bundle.survivingSet` of a live
   generation `gid`;
3. `cancelGen gid` cancels a currently live generation `gid`;
4. `queryGen gid q` queries a currently live generation `gid` (opened at birth state `birthSt`
   recorded at index `gid`) with a `δ`-compatible query whose direction lies in the generation's
   birth-fixed implicit net, while keeping cumulative queries `≤ (u + 1) Q_poly(d, B, n)`. -/
def IsValidAdaptiveSearchController
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (d_param B n R cap : ℕ) (σ A_n : ℝ)
    (P_fac netLogBound : ℕ → ℕ → ℕ → ℝ)
    (B_birth : ℕ → ℕ → ℝ)
    (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (ctrl : AdaptiveSearchController ι d d_s BirthState PhaseState) : Prop :=
  ∃ netOfBirth :
      ℕ → ExecutionHistory d → CertifiedSearchGeneration ι d d_s BirthState PhaseState →
        Finset (EuclideanSpace ℝ (Fin d_s)),
    ∀ st : CompiledSearchSystemState ι d d_s BirthState PhaseState,
      IsReachableIntraStepState R cap B_birth Q_poly d_param B n ctrl st →
        let u : ℕ := st.history.length
        match ctrl.nextAction st with
        | .finishExternalStep _ => True
        | .openGen inst =>
            let gid := st.generations.length
            SatisfiesCertifiedBirthVarOnNet n σ A_n (P_fac d_param B n)
              (netLogBound d_param B n) (netOfBirth gid st.history inst) inst ∧
            ((st.totalBirthCard + inst.gen.m : ℕ) : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * B_birth d_param n
        | .deleteFromGen gid i =>
            ∃ bundle, st.generations[gid]? = some (some bundle) ∧ i ∈ bundle.survivingSet
        | .cancelGen gid =>
            ∃ bundle, st.generations[gid]? = some (some bundle)
        | .queryGen gid q =>
            ∃ bundle birthHist birthBits,
              st.generations[gid]? = some (some bundle) ∧
              st.birthSnapshots[gid]? = some (birthHist, birthBits) ∧
              IsCertifiedCompatible bundle.inst.gen bundle.inst.δ bundle.survivingSet q ∧
              q.z ∈ netOfBirth gid birthHist bundle.inst ∧
              ((st.totalQueries + 1 : ℕ) : ℝ) ≤ ((u + 1 : ℕ) : ℝ) * Q_poly d_param B n

/-- Halting probability of a single external update step from `cur` over fresh random bits. -/
noncomputable def compiledSingleStepHaltProb
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d_param B n : ℕ)
    (ctrl : AdaptiveSearchController ι d d_s BirthState PhaseState)
    (cur : CompiledSearchSystemState ι d d_s BirthState PhaseState) : ENNReal :=
  ∑' bs : List Bool,
    if (runSingleCompiledSearchStep R cap B_birth Q_poly d_param B n ctrl cur bs).isSome then
      bitListProb bs
    else
      0

/-- Expected total certified-search work across a fixed finite adaptive prefix of `t` external
updates (with no prescribed horizon). -/
noncomputable def compiledPrefixExpectedWork
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {BirthState PhaseState : Type}
    (R cap : ℕ)
    (B_birth : ℕ → ℕ → ℝ) (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (d_param B n : ℕ)
    (ctrl : AdaptiveSearchController ι d d_s BirthState PhaseState)
    (t : ℕ) : ENNReal :=
  ∑' trace : Fin t → List Bool,
    match runCompiledSearchPrefix R cap B_birth Q_poly d_param B n ctrl t trace with
    | some out => prefixTraceProb trace * (out.totalSearchWork : ENNReal)
    | none => 0

/-- Lemma C.3 (Adaptive certified generation compiler, paper p.54).
Exactly the paper's statement, as a Prop. -/
def S_lem_C_3 : Prop :=
  ∀ (P_fac netLogBound : ℕ → ℕ → ℕ → ℝ)
    (B_birth : ℕ → ℕ → ℝ)
    (Q_poly : ℕ → ℕ → ℕ → ℝ)
    (hP_fac : IsPolyDBLogNBounded P_fac)
    (hNet : IsPolyDBLogNBounded netLogBound)
    (hBirth : IsPolyDLogNBounded B_birth)
    (hQuery : IsPolyDBLogNBounded Q_poly),
    ∃ (R_of : ℝ → ℕ) (cap_of : ℝ → ℝ → ℕ) (P_out : ℕ → ℕ → ℕ → ℝ),
      (∀ nb : ℝ, 0 ≤ nb → 1 ≤ R_of nb) ∧
      IsPolyDBLogNBounded P_out ∧
      ∀ (d d_s B n : ℕ) (ι : Type) [DecidableEq ι]
        (BirthState PhaseState : Type)
        (σ A_n : ℝ)
        (ctrl : AdaptiveSearchController ι d d_s BirthState PhaseState),
        1 ≤ d → 1 ≤ B → 2 ≤ n →
        0 ≤ σ → 0 ≤ A_n →
        -- Horizon-free compiler parameters `(R, cap)`: independent of any prefix length `t`
        let R : ℕ := R_of (netLogBound d B n)
        let cap : ℕ := cap_of A_n (P_fac d B n)
        IsValidAdaptiveSearchController d B n R cap σ A_n
          P_fac netLogBound B_birth Q_poly ctrl →
          -- (1) Prefix-free coin consumption and almost-sure termination of every external step
          (∀ (bitTrace : List (List Bool))
             (prefSt : CompiledSearchSystemState ι d d_s BirthState PhaseState),
            runCompiledSearchSteps R cap B_birth Q_poly d B n ctrl bitTrace = some prefSt →
              (∀ bs₁ bs₂ : List Bool, ∀ out₁ out₂,
                runSingleCompiledSearchStep R cap B_birth Q_poly d B n ctrl prefSt bs₁ = some out₁ →
                runSingleCompiledSearchStep R cap B_birth Q_poly d B n ctrl prefSt bs₂ = some out₂ →
                bs₁ <+: bs₂ → bs₁ = bs₂) ∧
              compiledSingleStepHaltProb R cap B_birth Q_poly d B n ctrl prefSt = 1) ∧
          -- (2) Always-correct (zero-error) search answers and expected total certified-search
          -- work ≤ t A(n) poly(d, B, log n) over every fixed finite adaptive prefix of t ≥ 1
          -- external updates, with no prescribed horizon
          (∀ (t : ℕ), 1 ≤ t →
            (∀ (trace : Fin t → List Bool)
               (out : CompiledSearchSystemState ι d d_s BirthState PhaseState),
              runCompiledSearchPrefix R cap B_birth Q_poly d B n ctrl t trace = some out →
                out.history.length = t ∧
                ∀ qRec ∈ out.queryRecords,
                  qRec.gen.IsCorrectAnswer qRec.survivingSet qRec.query qRec.answer) ∧
            compiledPrefixExpectedWork R cap B_birth Q_poly d B n ctrl t ≠ ⊤ ∧
            (compiledPrefixExpectedWork R cap B_birth Q_poly d B n ctrl t).toReal ≤
              (t : ℝ) * A_n * P_out d B n)

end UL
