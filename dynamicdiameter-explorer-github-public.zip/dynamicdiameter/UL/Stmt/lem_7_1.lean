import Mathlib
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Def.def_6_search_interface
import UL.Def.def_C_3_birth_var
import UL.Def.def_7_birth_pool
set_option autoImplicit false

namespace UL

/-! ### 1. Fully dynamic search operations and adaptive execution semantics -/

/-- Primitive operation on a fully dynamic search index over identity type `ι` in `ℝ^{d_s}`:
inserting an absent unit-vector identity, deleting a currently active identity, or executing a
search query. -/
inductive DynamicSearchOp (ι : Type) (d_s : ℕ) : Type
  | insert (id : ι)
  | delete (id : ι)
  | query (q : SearchQuery ι d_s)

/-- Legality of a primitive dynamic search operation on current active set `S : Finset ι` under
capacity `n`, coordinate map `pts : ι → ℝ^{d_s}`, and admissible query predicate `admissibleQuery`:
insertions add an absent unit-vector identity keeping `|S| ≤ n`, deletions remove an active
identity in `S`, and queries satisfy `admissibleQuery S q`. -/
def IsLegalDynamicSearchOp {ι : Type} [DecidableEq ι] {d_s : ℕ}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (admissibleQuery : Finset ι → SearchQuery ι d_s → Prop)
    (S : Finset ι) : DynamicSearchOp ι d_s → Prop
  | .insert id => id ∉ S ∧ (insert id S).card ≤ n ∧ IsUnitVec (pts id)
  | .delete id => id ∈ S
  | .query q => admissibleQuery S q

/-- Updated active search set after applying `op` to `S`. -/
def applyDynamicSearchSetOp {ι : Type} [DecidableEq ι] {d_s : ℕ}
    (S : Finset ι) : DynamicSearchOp ι d_s → Finset ι
  | .insert id => insert id S
  | .delete id => S.erase id
  | .query _ => S

/-- Single-step halting outcome of a fully dynamic search index processing one primitive operation
with an exact finite list of fresh random bits: updated state `nextState`, optional query answer
`queryAnswer` (`none` on updates, `some ans` with `ans : Option ι` on queries), operation work
`work`, and peak space `peakSpace`. -/
structure DynamicSearchStepOutcome (DynState ι : Type) : Type where
  nextState : DynState
  queryAnswer : Option (Option ι)
  work : ℕ
  peakSpace : ℕ

/-- Operational interface of a randomized fully dynamic search index over identity type `ι` in
`ℝ^{d_s}` conditioned on external histories in `ExecutionHistory d`, starting from `S = ∅`. -/
structure DynamicSearchIndex (ι : Type) (d d_s : ℕ) (DynState : Type) : Type where
  initState : DynState
  initWork : ℕ
  initSpace : ℕ
  stepWithBits :
    ExecutionHistory d → Finset ι → DynState → DynamicSearchOp ι d_s → List Bool →
      Option (DynamicSearchStepOutcome DynState ι)

/-- Externally visible and exposed-randomness record of one completed primitive operation of a
fully dynamic search index. -/
structure DynamicSearchHistoryEntry (ι : Type) (d d_s : ℕ) : Type where
  extHistory : ExecutionHistory d
  operation : DynamicSearchOp ι d_s
  randomBits : List Bool
  queryAnswer : Option (Option ι)

/-- Preceding execution history exposed to an adaptive dynamic-search adversary before choosing the
next primitive operation and external history context. -/
abbrev DynamicSearchHistory (ι : Type) (d d_s : ℕ) : Type :=
  List (DynamicSearchHistoryEntry ι d d_s)

/-- An adaptive dynamic-search adversary chooses the next external history context and primitive
search operation as an arbitrary function of the complete preceding dynamic-search history
(including all prior random bits and answers). -/
abbrev DynamicSearchAdversary (ι : Type) (d d_s : ℕ) : Type :=
  DynamicSearchHistory ι d d_s → ExecutionHistory d × DynamicSearchOp ι d_s

/-- Accumulated state of a finite adaptive execution prefix of a `DynamicSearchIndex` starting from
`S = ∅`. -/
structure DynamicSearchPrefixState (ι : Type) (d d_s : ℕ) (DynState : Type) : Type where
  activeSet : Finset ι
  dynState : DynState
  history : DynamicSearchHistory ι d d_s
  queryRecords : List (Finset ι × SearchQuery ι d_s × Option ι)
  stepWorks : List ℕ
  totalWork : ℕ
  maxSpace : ℕ

/-- Initial empty prefix state (`S = ∅`) prior to the first primitive search-set operation. -/
def initDynamicSearchPrefixState {ι : Type} {d d_s : ℕ} {DynState : Type}
    (idx : DynamicSearchIndex ι d d_s DynState) :
    DynamicSearchPrefixState ι d d_s DynState :=
  { activeSet := ∅
    dynState := idx.initState
    history := []
    queryRecords := []
    stepWorks := []
    totalWork := idx.initWork
    maxSpace := idx.initSpace }

/-- Execute one primitive operation `op` at `extHist` from `(S, st)` using fresh random bits `bs`,
checking that updates return `queryAnswer = none` and queries return `queryAnswer = some ans`. -/
def runSingleDynamicSearchStep {ι : Type} [DecidableEq ι] {d d_s : ℕ} {DynState : Type}
    (idx : DynamicSearchIndex ι d d_s DynState)
    (extHist : ExecutionHistory d) (S : Finset ι) (st : DynState)
    (op : DynamicSearchOp ι d_s) (bs : List Bool) :
    Option (Finset ι × DynamicSearchStepOutcome DynState ι) :=
  match idx.stepWithBits extHist S st op bs with
  | none => none
  | some out =>
      match op, out.queryAnswer with
      | .insert _, none => some (applyDynamicSearchSetOp S op, out)
      | .delete _, none => some (applyDynamicSearchSetOp S op, out)
      | .query _, some _ => some (S, out)
      | _, _ => none

/-- Run an adaptive sequence of dynamic search operations from `cur` over per-step fresh random bit
lists. -/
def runDynamicSearchStepsFrom {ι : Type} [DecidableEq ι] {d d_s : ℕ} {DynState : Type}
    (idx : DynamicSearchIndex ι d d_s DynState)
    (adv : DynamicSearchAdversary ι d d_s)
    (cur : DynamicSearchPrefixState ι d d_s DynState) :
    List (List Bool) → Option (DynamicSearchPrefixState ι d d_s DynState)
  | [] => some cur
  | bs :: rest =>
      let (extHist, op) := adv cur.history
      match runSingleDynamicSearchStep idx extHist cur.activeSet cur.dynState op bs with
      | none => none
      | some (S', out) =>
          let entry : DynamicSearchHistoryEntry ι d d_s :=
            { extHistory := extHist
              operation := op
              randomBits := bs
              queryAnswer := out.queryAnswer }
          let qRecs :=
            match op, out.queryAnswer with
            | .query q, some ans => cur.queryRecords ++ [(cur.activeSet, q, ans)]
            | _, _ => cur.queryRecords
          let next : DynamicSearchPrefixState ι d d_s DynState :=
            { activeSet := S'
              dynState := out.nextState
              history := cur.history ++ [entry]
              queryRecords := qRecs
              stepWorks := cur.stepWorks ++ [out.work]
              totalWork := cur.totalWork + out.work
              maxSpace := max cur.maxSpace out.peakSpace }
          runDynamicSearchStepsFrom idx adv next rest

/-- Run an adaptive dynamic search execution from `S = ∅` over `bitTrace`. -/
def runDynamicSearchSteps {ι : Type} [DecidableEq ι] {d d_s : ℕ} {DynState : Type}
    (idx : DynamicSearchIndex ι d d_s DynState)
    (adv : DynamicSearchAdversary ι d d_s)
    (bitTrace : List (List Bool)) :
    Option (DynamicSearchPrefixState ι d d_s DynState) :=
  runDynamicSearchStepsFrom idx adv (initDynamicSearchPrefixState idx) bitTrace

/-- Run a fixed finite prefix of length `T` of an adaptive dynamic search execution. -/
def runDynamicSearchPrefix {ι : Type} [DecidableEq ι] {d d_s : ℕ} {DynState : Type}
    (idx : DynamicSearchIndex ι d d_s DynState)
    (adv : DynamicSearchAdversary ι d d_s)
    (T : ℕ) (trace : Fin T → List Bool) :
    Option (DynamicSearchPrefixState ι d d_s DynState) :=
  runDynamicSearchSteps idx adv (List.ofFn trace)

/-- Validity of an adaptive dynamic-search adversary up to `maxOps` primitive operations under
capacity `n`, coordinates `pts`, and query admissibility predicate `admissibleQuery`. -/
def IsValidBoundedDynamicSearchAdversary {ι : Type} [DecidableEq ι] {d d_s : ℕ} {DynState : Type}
    (n maxOps : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (admissibleQuery : Finset ι → SearchQuery ι d_s → Prop)
    (idx : DynamicSearchIndex ι d d_s DynState)
    (adv : DynamicSearchAdversary ι d d_s) : Prop :=
  ∀ bitTrace : List (List Bool), bitTrace.length < maxOps →
    ∀ prefSt : DynamicSearchPrefixState ι d d_s DynState,
      runDynamicSearchSteps idx adv bitTrace = some prefSt →
        IsLegalDynamicSearchOp n pts admissibleQuery prefSt.activeSet (adv prefSt.history).2

/-- Probability that a single dynamic search operation halts validly under fresh fair coin flips. -/
noncomputable def singleDynamicSearchStepHaltProb
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {DynState : Type}
    (idx : DynamicSearchIndex ι d d_s DynState)
    (extHist : ExecutionHistory d) (S : Finset ι) (st : DynState)
    (op : DynamicSearchOp ι d_s) : ENNReal :=
  ∑' bs : List Bool,
    if (runSingleDynamicSearchStep idx extHist S st op bs).isSome then bitListProb bs else 0

/-- Probability of an execution event across a `T`-operation adaptive dynamic search prefix. -/
noncomputable def dynamicSearchPrefixEventProb
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {DynState : Type}
    (idx : DynamicSearchIndex ι d d_s DynState)
    (adv : DynamicSearchAdversary ι d d_s) (T : ℕ)
    (event : DynamicSearchPrefixState ι d d_s DynState → Prop) : ENNReal :=
  open Classical in
  ∑' trace : Fin T → List Bool,
    match runDynamicSearchPrefix idx adv T trace with
    | some out => if event out then prefixTraceProb trace else 0
    | none => 0

/-- Expected total work across a `T`-operation adaptive dynamic search prefix from `S = ∅`. -/
noncomputable def dynamicSearchPrefixExpectedWork
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {DynState : Type}
    (idx : DynamicSearchIndex ι d d_s DynState)
    (adv : DynamicSearchAdversary ι d d_s) (T : ℕ) : ENNReal :=
  ∑' trace : Fin T → List Bool,
    match runDynamicSearchPrefix idx adv T trace with
    | some out => prefixTraceProb trace * (out.totalWork : ENNReal)
    | none => 0

/-- Event that every compatible query executed during the prefix returned a fully correct search
answer (`IsCorrectSearchAnswer pts S h q.z q.accept ans`), while every query (compatible or not)
returned a valid answer (`IsValidSearchAnswer S q.accept ans`). -/
def AllDynamicQueryAnswersCorrect {ι : Type} {d d_s : ℕ} {DynState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h : ℝ)
    (out : DynamicSearchPrefixState ι d d_s DynState) : Prop :=
  ∀ rec ∈ out.queryRecords,
    IsValidSearchAnswer rec.1 rec.2.1.accept rec.2.2 ∧
    (IsCompatibleTest pts rec.1 rec.2.1.z rec.2.1.accept →
      IsCorrectSearchAnswer pts rec.1 h rec.2.1.z rec.2.1.accept rec.2.2)

/-! ### 2. Honest black-box execution over birth-pool primitives (no uncharged oracle bypass) -/

/-- Consume the unique prefix of `remBits` on which a prefix-free coin consumer `f` halts. -/
noncomputable def consumePrefixBits {α : Type}
    (f : List Bool → Option α) (remBits : List Bool) : Option (α × List Bool) :=
  open Classical in
  let candidates := (List.range (remBits.length + 1)).filterMap fun k =>
    match f (remBits.take k) with
    | some v => some (v, remBits.drop k)
    | none => none
  candidates.head?

/-- Lift a query `q : SearchQuery ι d_s` on original identities `ι` to lifetime-tagged records
`ι × ℕ`. -/
def liftQueryToLifetimes {ι : Type} {d_s : ℕ} (q : SearchQuery ι d_s) :
    SearchQuery (ι × ℕ) d_s :=
  { z := q.z
    unit_z := q.unit_z
    accept := fun p => q.accept p.1 }

/-- Live or pending Monte Carlo birth-pool slot hosted inside a scheduled dynamic search wrapper:
`unpaidWork` tracks remaining construction and queued deletion-replay work; a slot may serve
queries only once `unpaidWork = 0`. -/
structure HostedMCSlot (ι : Type) (d_s : ℕ) (MCBirthState MCIndexState : Type) : Type where
  slotId : ℕ
  gen : SearchGeneration (ι × ℕ) d_s
  bState : MCBirthState
  surviving : Finset (ι × ℕ)
  idxState : MCIndexState
  unpaidWork : ℕ
  spaceAlloc : ℕ

/-- Hosted table of active lifetime-tagged elements and coexisting Monte Carlo birth-pool slots. -/
structure HostedMCTable (ι : Type) (d_s : ℕ) (MCBirthState MCIndexState : Type) : Type where
  activeLifetimes : Finset (ι × ℕ)
  nextLifetime : ℕ
  nextSlotId : ℕ
  slots : List (HostedMCSlot ι d_s MCBirthState MCIndexState)

/-- Initial empty `HostedMCTable`. -/
def HostedMCTable.empty (ι : Type) (d_s : ℕ) (MCBirthState MCIndexState : Type) :
    HostedMCTable ι d_s MCBirthState MCIndexState :=
  { activeLifetimes := ∅
    nextLifetime := 0
    nextSlotId := 0
    slots := [] }

/-- Total memory cells occupied by `tbl` (active lifetime records plus all live/pending slots). -/
def HostedMCTable.currentSpace {ι : Type} {d_s : ℕ} {MCBirthState MCIndexState : Type}
    (tbl : HostedMCTable ι d_s MCBirthState MCIndexState) : ℕ :=
  tbl.activeLifetimes.card + (tbl.slots.map HostedMCSlot.spaceAlloc).sum

/-- Elementary black-box command issued by a scheduled Monte Carlo wrapper controller. -/
inductive MCWrapperCmd (ι : Type) (d_s : ℕ) (CtrlState : Type) : Type
  | openSlot (gen : SearchGeneration (ι × ℕ) d_s) (nextCtrl : CtrlState)
  | deleteFromSlot (slotId : ℕ) (rec : ι × ℕ) (nextCtrl : CtrlState)
  | payWork (slotId : ℕ) (budget : ℕ) (nextCtrl : CtrlState)
  | retireSlot (slotId : ℕ) (nextCtrl : CtrlState)
  | finishUpdate (nextCtrl : CtrlState)
  | finishQuery (servingSlotIds : List ℕ) (nextCtrl : CtrlState)

/-- Fuel-bounded operational execution of a scheduled Monte Carlo wrapper controller over black-box
`mkMC` primitives, charging every primitive build, deletion, scheduled work payment, query, and
slot space allocation directly to the dynamic operation's `work` and `peakSpace`. -/
noncomputable def runMCHostedStepFuel
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {MCBirthState MCIndexState CtrlState : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h : ℝ)
    (mkMC : SearchGeneration (ι × ℕ) d_s →
      MonteCarloSearchGeneration (ι × ℕ) d d_s MCBirthState MCIndexState)
    (stepCtrl :
      DynamicSearchOp ι d_s → CtrlState →
        HostedMCTable ι d_s MCBirthState MCIndexState →
          MCWrapperCmd ι d_s CtrlState)
    (extHist : ExecutionHistory d) (op : DynamicSearchOp ι d_s) :
    ℕ → CtrlState → HostedMCTable ι d_s MCBirthState MCIndexState → List Bool → ℕ → ℕ →
      Option (DynamicSearchStepOutcome (CtrlState × HostedMCTable ι d_s MCBirthState MCIndexState) ι)
  | 0, _, _, _, _, _ => none
  | fuel + 1, ctrl, tbl, remBits, accWork, peakSp =>
      open Classical in
      match stepCtrl op ctrl tbl with
      | .openSlot gen ctrl' =>
          if gen.m ≤ n ∧ gen.h = h ∧ gen.P₀ ⊆ tbl.activeLifetimes ∧
              (∀ p ∈ gen.P₀, gen.pts p = pts p.1) then
            match consumePrefixBits ((mkMC gen).buildWithBits extHist) remBits with
            | none => none
            | some (bOut, rem') =>
                let newSlot : HostedMCSlot ι d_s MCBirthState MCIndexState :=
                  { slotId := tbl.nextSlotId
                    gen := gen
                    bState := bOut.birthState
                    surviving := gen.P₀
                    idxState := bOut.initState
                    unpaidWork := bOut.work + gen.m
                    spaceAlloc := gen.m + bOut.peakSpace }
                let tbl' : HostedMCTable ι d_s MCBirthState MCIndexState :=
                  { tbl with
                    nextSlotId := tbl.nextSlotId + 1
                    slots := tbl.slots ++ [newSlot] }
                runMCHostedStepFuel n pts h mkMC stepCtrl extHist op fuel ctrl' tbl' rem'
                  (accWork + 1) (max peakSp tbl'.currentSpace)
          else
            none
      | .deleteFromSlot sid rec ctrl' =>
          match tbl.slots.find? (fun s => s.slotId = sid) with
          | none => none
          | some sl =>
              if rec ∈ sl.surviving ∧ rec ∉ tbl.activeLifetimes then
                match consumePrefixBits
                    ((mkMC sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.idxState rec)
                    remBits with
                | none => none
                | some (dOut, rem') =>
                    let sl' : HostedMCSlot ι d_s MCBirthState MCIndexState :=
                      { sl with
                        surviving := sl.surviving.erase rec
                        idxState := dOut.nextState
                        unpaidWork := sl.unpaidWork + dOut.work
                        spaceAlloc := max sl.spaceAlloc dOut.peakSpace }
                    let tbl' : HostedMCTable ι d_s MCBirthState MCIndexState :=
                      { tbl with
                        slots := tbl.slots.map (fun s => if s.slotId = sid then sl' else s) }
                    runMCHostedStepFuel n pts h mkMC stepCtrl extHist op fuel ctrl' tbl' rem'
                      (accWork + 1) (max peakSp tbl'.currentSpace)
              else
                none
      | .payWork sid budget ctrl' =>
          match tbl.slots.find? (fun s => s.slotId = sid) with
          | none => none
          | some sl =>
              let paid := min budget sl.unpaidWork
              let sl' := { sl with unpaidWork := sl.unpaidWork - paid }
              let tbl' :=
                { tbl with slots := tbl.slots.map (fun s => if s.slotId = sid then sl' else s) }
              runMCHostedStepFuel n pts h mkMC stepCtrl extHist op fuel ctrl' tbl' remBits
                (accWork + paid + 1) (max peakSp tbl'.currentSpace)
      | .retireSlot sid ctrl' =>
          let tbl' := { tbl with slots := tbl.slots.filter (fun s => s.slotId ≠ sid) }
          runMCHostedStepFuel n pts h mkMC stepCtrl extHist op fuel ctrl' tbl' remBits
            (accWork + 1) (max peakSp tbl'.currentSpace)
      | .finishUpdate ctrl' =>
          match op with
          | .query _ => none
          | _ =>
              if remBits.isEmpty then
                some
                  { nextState := (ctrl', tbl)
                    queryAnswer := none
                    work := accWork + 1
                    peakSpace := max peakSp tbl.currentSpace }
              else
                none
      | .finishQuery sids ctrl' =>
          match op with
          | .query q =>
              if remBits.isEmpty ∧ sids.Nodup then
                let qLifted := liftQueryToLifetimes q
                let picked := sids.filterMap (fun sid => tbl.slots.find? (fun s => s.slotId = sid))
                if picked.length = sids.length ∧
                    (∀ sl ∈ picked, sl.unpaidWork = 0 ∧ sl.surviving ⊆ tbl.activeLifetimes) ∧
                    tbl.activeLifetimes ⊆ picked.foldr (fun sl acc => sl.surviving ∪ acc) ∅ then
                  let qOuts := picked.map (fun sl =>
                    (sl.slotId, sl.surviving, (mkMC sl.gen).runQuery sl.bState sl.surviving sl.idxState qLifted))
                  let qWork := (qOuts.map (fun x => x.2.2.work + 1)).sum
                  let slots' := tbl.slots.map (fun sl =>
                    match qOuts.find? (fun x => x.1 = sl.slotId) with
                    | some (_, _, qOut) => { sl with spaceAlloc := max sl.spaceAlloc qOut.peakSpace }
                    | none => sl)
                  let tbl' := { tbl with slots := slots' }
                  let validHits := qOuts.filterMap (fun (_, surv, qOut) =>
                    match qOut.answer with
                    | some p => if p ∈ surv ∧ q.accept p.1 then some p.1 else none
                    | none => none)
                  some
                    { nextState := (ctrl', tbl')
                      queryAnswer := some validHits.head?
                      work := accWork + qWork + 1
                      peakSpace := max peakSp tbl'.currentSpace }
                else
                  none
              else
                none
          | _ => none

/-- Package of a scheduled Monte Carlo wrapper controller inducing an honest `DynamicSearchIndex`
over `mkMC`. -/
structure MCHostedController (ι : Type) (d_s : ℕ)
    (MCBirthState MCIndexState CtrlState : Type) : Type where
  initCtrl : CtrlState
  fuelBound : ℕ → ℕ
  stepCtrl :
    DynamicSearchOp ι d_s → CtrlState →
      HostedMCTable ι d_s MCBirthState MCIndexState →
        MCWrapperCmd ι d_s CtrlState

/-- Convert an `MCHostedController` into a `DynamicSearchIndex` whose `work` and `peakSpace` are
enforced by `runMCHostedStepFuel`. -/
noncomputable def MCHostedController.toDynamicSearchIndex
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {MCBirthState MCIndexState CtrlState : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h : ℝ)
    (mkMC : SearchGeneration (ι × ℕ) d_s →
      MonteCarloSearchGeneration (ι × ℕ) d d_s MCBirthState MCIndexState)
    (ctrl : MCHostedController ι d_s MCBirthState MCIndexState CtrlState) :
    DynamicSearchIndex ι d d_s (CtrlState × HostedMCTable ι d_s MCBirthState MCIndexState) :=
  { initState := (ctrl.initCtrl, HostedMCTable.empty ι d_s MCBirthState MCIndexState)
    initWork := 1
    initSpace := 1
    stepWithBits := fun extHist S st op bs =>
      let tbl0 := st.2
      if tbl0.activeLifetimes.image Prod.fst = S ∧
          tbl0.activeLifetimes.card = S.card then
        let tbl1 : HostedMCTable ι d_s MCBirthState MCIndexState :=
          match op with
          | .insert i =>
              { tbl0 with
                activeLifetimes := insert (i, tbl0.nextLifetime) tbl0.activeLifetimes
                nextLifetime := tbl0.nextLifetime + 1 }
          | .delete i =>
              { tbl0 with
                activeLifetimes := tbl0.activeLifetimes.filter (fun p => p.1 ≠ i) }
          | .query _ => tbl0
        runMCHostedStepFuel n pts h mkMC ctrl.stepCtrl extHist op
          (ctrl.fuelBound tbl1.nextLifetime) st.1 tbl1 bs 1
          (max tbl0.currentSpace tbl1.currentSpace)
      else
        none }

/-- Live certified birth-pool slot hosted inside a certified dynamic search wrapper. -/
structure HostedCertSlot (ι : Type) (d_s : ℕ) (CertBirthState CertPhaseState : Type) : Type where
  slotId : ℕ
  gen : SearchGeneration (ι × ℕ) d_s
  bState : CertBirthState
  surviving : Finset (ι × ℕ)
  phase : CertPhaseState
  spaceAlloc : ℕ

/-- Hosted table of active lifetime-tagged elements and live certified birth-pool slots. -/
structure HostedCertTable (ι : Type) (d_s : ℕ) (CertBirthState CertPhaseState : Type) : Type where
  activeLifetimes : Finset (ι × ℕ)
  nextLifetime : ℕ
  nextSlotId : ℕ
  slots : List (HostedCertSlot ι d_s CertBirthState CertPhaseState)

/-- Initial empty `HostedCertTable`. -/
def HostedCertTable.empty (ι : Type) (d_s : ℕ) (CertBirthState CertPhaseState : Type) :
    HostedCertTable ι d_s CertBirthState CertPhaseState :=
  { activeLifetimes := ∅
    nextLifetime := 0
    nextSlotId := 0
    slots := [] }

/-- Total memory cells occupied by `tbl`. -/
def HostedCertTable.currentSpace {ι : Type} {d_s : ℕ} {CertBirthState CertPhaseState : Type}
    (tbl : HostedCertTable ι d_s CertBirthState CertPhaseState) : ℕ :=
  tbl.activeLifetimes.card + (tbl.slots.map HostedCertSlot.spaceAlloc).sum

/-- Elementary black-box command issued by a certified dynamic search wrapper controller (supporting
independent copy racing with deterministic per-copy work cap and exact-scan fallback as in
Lemma C.3). -/
inductive CertWrapperCmd (ι : Type) (d_s : ℕ) (CtrlState : Type) : Type
  | openCertSlot (gen : SearchGeneration (ι × ℕ) d_s) (nextCtrl : CtrlState)
  | deleteCertSlot (slotId : ℕ) (rec : ι × ℕ) (nextCtrl : CtrlState)
  | retireCertSlot (slotId : ℕ) (nextCtrl : CtrlState)
  | finishCertUpdate (nextCtrl : CtrlState)
  | finishCertQuery (raceGroups : List (List ℕ × ℕ)) (nextCtrl : CtrlState)

open Classical in
/-- Fuel-bounded operational execution of a certified dynamic search wrapper controller over
black-box `mkCert` primitives (using `runQueryCapped` and charging exact-scan fallback work
`S_grp.card + 1` whenever all raced copies in a group abort at `cap`). -/
noncomputable def runCertHostedStepFuel
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {CertBirthState CertPhaseState CtrlState : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h : ℝ)
    (mkCert : SearchGeneration (ι × ℕ) d_s →
      CertifiedSearchGeneration (ι × ℕ) d d_s CertBirthState CertPhaseState)
    (stepCtrl :
      DynamicSearchOp ι d_s → CtrlState →
        HostedCertTable ι d_s CertBirthState CertPhaseState →
          CertWrapperCmd ι d_s CtrlState)
    (extHist : ExecutionHistory d) (op : DynamicSearchOp ι d_s) :
    ℕ → CtrlState → HostedCertTable ι d_s CertBirthState CertPhaseState → List Bool → ℕ → ℕ →
      Option (DynamicSearchStepOutcome (CtrlState × HostedCertTable ι d_s CertBirthState CertPhaseState) ι)
  | 0, _, _, _, _, _ => none
  | fuel + 1, ctrl, tbl, remBits, accWork, peakSp =>
      open Classical in
      match stepCtrl op ctrl tbl with
      | .openCertSlot gen ctrl' =>
          if gen.m ≤ n ∧ gen.h = h ∧ gen.P₀ ⊆ tbl.activeLifetimes ∧
              (∀ p ∈ gen.P₀, gen.pts p = pts p.1) then
            match consumePrefixBits ((mkCert gen).buildWithBits extHist) remBits with
            | none => none
            | some (bOut, rem') =>
                let newSlot : HostedCertSlot ι d_s CertBirthState CertPhaseState :=
                  { slotId := tbl.nextSlotId
                    gen := gen
                    bState := bOut.birthState
                    surviving := gen.P₀
                    phase := bOut.initPhase
                    spaceAlloc := gen.m + bOut.peakSpace }
                let tbl' : HostedCertTable ι d_s CertBirthState CertPhaseState :=
                  { tbl with
                    nextSlotId := tbl.nextSlotId + 1
                    slots := tbl.slots ++ [newSlot] }
                runCertHostedStepFuel n pts h mkCert stepCtrl extHist op fuel ctrl' tbl' rem'
                  (accWork + bOut.work + gen.m + 1) (max peakSp tbl'.currentSpace)
          else
            none
      | .deleteCertSlot sid rec ctrl' =>
          match tbl.slots.find? (fun s => s.slotId = sid) with
          | none => none
          | some sl =>
              if rec ∈ sl.surviving ∧ rec ∉ tbl.activeLifetimes then
                match consumePrefixBits
                    ((mkCert sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.phase rec)
                    remBits with
                | none => none
                | some (dOut, rem') =>
                    let sl' : HostedCertSlot ι d_s CertBirthState CertPhaseState :=
                      { sl with
                        surviving := sl.surviving.erase rec
                        phase := dOut.nextPhase
                        spaceAlloc := max sl.spaceAlloc dOut.peakSpace }
                    let tbl' : HostedCertTable ι d_s CertBirthState CertPhaseState :=
                      { tbl with
                        slots := tbl.slots.map (fun s => if s.slotId = sid then sl' else s) }
                    runCertHostedStepFuel n pts h mkCert stepCtrl extHist op fuel ctrl' tbl' rem'
                      (accWork + dOut.work + 1) (max peakSp tbl'.currentSpace)
              else
                none
      | .retireCertSlot sid ctrl' =>
          let tbl' := { tbl with slots := tbl.slots.filter (fun s => s.slotId ≠ sid) }
          runCertHostedStepFuel n pts h mkCert stepCtrl extHist op fuel ctrl' tbl' remBits
            (accWork + 1) (max peakSp tbl'.currentSpace)
      | .finishCertUpdate ctrl' =>
          match op with
          | .query _ => none
          | _ =>
              if remBits.isEmpty then
                some
                  { nextState := (ctrl', tbl)
                    queryAnswer := none
                    work := accWork + 1
                    peakSpace := max peakSp tbl.currentSpace }
              else
                none
      | .finishCertQuery raceGroups ctrl' =>
          match op with
          | .query q =>
              if remBits.isEmpty then
                let qLifted := liftQueryToLifetimes q
                let resolvedGroups : Option (List (Finset (ι × ℕ) × List (HostedCertSlot ι d_s CertBirthState CertPhaseState) × ℕ)) :=
                  raceGroups.mapM (fun (sids, cap) =>
                    let sls := sids.filterMap (fun sid => tbl.slots.find? (fun s => s.slotId = sid))
                    match sls with
                    | [] => none
                    | sl₀ :: _ =>
                        if sids.Nodup ∧ sls.length = sids.length ∧
                            sl₀.surviving ⊆ tbl.activeLifetimes ∧
                            (∀ sl ∈ sls, sl.surviving = sl₀.surviving) then
                          some (sl₀.surviving, sls, cap)
                        else
                          none)
                match resolvedGroups with
                | none => none
                | some grps =>
                    if tbl.activeLifetimes ⊆ grps.foldr (fun g acc => g.1 ∪ acc) ∅ then
                      let evalGroup := fun (S_grp : Finset (ι × ℕ))
                          (sls : List (HostedCertSlot ι d_s CertBirthState CertPhaseState))
                          (cap : ℕ) =>
                        let cOuts := sls.map (fun sl =>
                          (sl.slotId, (mkCert sl.gen).runQueryCapped sl.bState sl.surviving sl.phase qLifted cap))
                        let raceWork := (cOuts.map (fun x => x.2.work + 1)).sum
                        let completed := cOuts.filterMap (fun x => x.2.completedAnswer)
                        match completed with
                        | ans :: _ =>
                            let hit : Option ι :=
                              match ans with
                              | some p => if p ∈ S_grp ∧ q.accept p.1 then some p.1 else none
                              | none => none
                            (hit, raceWork, cOuts)
                        | [] =>
                            let hit : Option ι :=
                              if hex : ∃ p ∈ S_grp, q.accept p.1 then
                                some (Classical.choose hex).1
                              else
                                none
                            (hit, raceWork + S_grp.card + 1, cOuts)
                      let grpResults := grps.map (fun (S_grp, sls, cap) => evalGroup S_grp sls cap)
                      let totalQWork := (grpResults.map (fun r => r.2.1)).sum
                      let allCOuts := (grpResults.map (fun r => r.2.2)).flatten
                      let slots' := tbl.slots.map (fun sl =>
                        let sp := (allCOuts.filter (fun x => x.1 = sl.slotId)).foldl
                          (fun m x => max m x.2.peakSpace) sl.spaceAlloc
                        { sl with spaceAlloc := sp })
                      let tbl' := { tbl with slots := slots' }
                      let hits := grpResults.filterMap (fun r => r.1)
                      some
                        { nextState := (ctrl', tbl')
                          queryAnswer := some hits.head?
                          work := accWork + totalQWork + 1
                          peakSpace := max peakSp tbl'.currentSpace }
                    else
                      none
              else
                none
          | _ => none

/-- Package of a certified dynamic search wrapper controller inducing an honest `DynamicSearchIndex`
over `mkCert`. -/
structure CertHostedController (ι : Type) (d_s : ℕ)
    (CertBirthState CertPhaseState CtrlState : Type) : Type where
  initCtrl : CtrlState
  fuelBound : ℕ → ℕ
  stepCtrl :
    DynamicSearchOp ι d_s → CtrlState →
      HostedCertTable ι d_s CertBirthState CertPhaseState →
        CertWrapperCmd ι d_s CtrlState

/-- Convert a `CertHostedController` into a `DynamicSearchIndex` whose `work` and `peakSpace` are
enforced by `runCertHostedStepFuel`. -/
noncomputable def CertHostedController.toDynamicSearchIndex
    {ι : Type} [DecidableEq ι] {d d_s : ℕ} {CertBirthState CertPhaseState CtrlState : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h : ℝ)
    (mkCert : SearchGeneration (ι × ℕ) d_s →
      CertifiedSearchGeneration (ι × ℕ) d d_s CertBirthState CertPhaseState)
    (ctrl : CertHostedController ι d_s CertBirthState CertPhaseState CtrlState) :
    DynamicSearchIndex ι d d_s (CtrlState × HostedCertTable ι d_s CertBirthState CertPhaseState) :=
  { initState := (ctrl.initCtrl, HostedCertTable.empty ι d_s CertBirthState CertPhaseState)
    initWork := 1
    initSpace := 1
    stepWithBits := fun extHist S st op bs =>
      let tbl0 := st.2
      if tbl0.activeLifetimes.image Prod.fst = S ∧
          tbl0.activeLifetimes.card = S.card then
        let tbl1 : HostedCertTable ι d_s CertBirthState CertPhaseState :=
          match op with
          | .insert i =>
              { tbl0 with
                activeLifetimes := insert (i, tbl0.nextLifetime) tbl0.activeLifetimes
                nextLifetime := tbl0.nextLifetime + 1 }
          | .delete i =>
              { tbl0 with
                activeLifetimes := tbl0.activeLifetimes.filter (fun p => p.1 ≠ i) }
          | .query _ => tbl0
        runCertHostedStepFuel n pts h mkCert ctrl.stepCtrl extHist op
          (ctrl.fuelBound tbl1.nextLifetime) st.1 tbl1 bs 1
          (max tbl0.currentSpace tbl1.currentSpace)
      else
        none }

/-! ### 3. Statement of Lemma 7.1 (From frozen pools to dynamic search) -/

/-- Lemma 7.1 (paper p.31). Exactly the paper's statement, as a Prop:
From the birth-pool interface (`ValidBirthPoolExponents n σ θ`, active search-set cardinality `≤ n`
with `n ≥ 2`, `θ ≥ σ ≥ 0`, and at most `maxOps ≤ n P_life` primitive search-set operations within
one center node's lifetime), aligned frozen dyadic insertion intervals yield a fully dynamic search
index with the same time exponent `θ` and space exponent `1 + σ`, up to logarithmic factors:
1. For capped Monte Carlo birth-pool primitives (`SatisfiesMonteCarloBirthPoolUniform`), scheduled
   construction yields deterministic worst-case per-operation work
   `O(n^θ P_time (P_build + P_del + P_query) polylog(n P_life))`, deterministic all-time space
   `O(n^{1+σ} P_space polylog(n P_life))`, prefix-free probability-1 halting, and simultaneous
   adaptive query correctness probability at least `1 - 2 T δ_fail` across `T ≤ maxOps` operations;
2. For certified birth-pool primitives (`SatisfiesCertifiedBirthPoolFactorsAtHistory`), racing
   certified copies with exact-scan fallback (as in Lemma C.3) yields zero-error always-correct
   answers, deterministic all-time space
   `O(n^{1+σ} P_space poly(log(n P_life), log |N|))`, and expected amortized work
   `O(n^θ P_time (P_build + P_del + P_query) poly(log(n P_life), log |N|))` over every fixed finite
   adaptive prefix of `1 ≤ T ≤ maxOps` primitive operations. -/
def S_lem_7_1 : Prop :=
  ∃ (C_wrap : ℝ) (deg_log : ℕ),
    1 ≤ C_wrap ∧
    ∀ (d d_s n : ℕ) (ι : Type) (_ : DecidableEq ι)
      (pts : ι → EuclideanSpace ℝ (Fin d_s))
      (h : ℝ) (_ : 0 < h) (_ : h < 1)
      (σ θ : ℝ) (_ : ValidBirthPoolExponents n σ θ)
      (facs : BirthPoolPolyFactors) (_ : facs.Valid)
      (P_life : ℝ) (_ : 1 ≤ P_life)
      (maxOps : ℕ) (_ : (maxOps : ℝ) ≤ (n : ℝ) * P_life),
      -- (1) Capped Monte Carlo birth-pool primitives + scheduled construction => worst-case bounds
      (∀ (δ_fail : ℝ) (_ : 0 ≤ δ_fail) (_ : δ_fail < 1)
         (MCBirthState MCIndexState : Type)
         (mkMC : SearchGeneration (ι × ℕ) d_s →
           MonteCarloSearchGeneration (ι × ℕ) d d_s MCBirthState MCIndexState),
        (∀ gen : SearchGeneration (ι × ℕ) d_s,
          gen.m ≤ n → gen.h = h →
            (mkMC gen).gen = gen ∧
            SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen)) →
        let logFac : ℝ := (1 + Real.log (2 * (n : ℝ) * P_life)) ^ deg_log
        let stepWorkBound : ℝ :=
          C_wrap * logFac * (n : ℝ) ^ θ * facs.P_time *
            (facs.P_build + facs.P_del + facs.P_query)
        let spaceBound : ℝ :=
          C_wrap * logFac * (n : ℝ) ^ (1 + σ) * facs.P_space
        ∃ (CtrlState : Type)
          (ctrl : MCHostedController ι d_s MCBirthState MCIndexState CtrlState),
          let dynIdx := ctrl.toDynamicSearchIndex (d := d) n pts h mkMC
          -- Prefix-free coin consumption
          (∀ extHist S st op bs₁ bs₂ out₁ out₂,
            dynIdx.stepWithBits extHist S st op bs₁ = some out₁ →
            dynIdx.stepWithBits extHist S st op bs₂ = some out₂ →
            bs₁ <+: bs₂ → bs₁ = bs₂) ∧
          -- Worst-case initialization bounds
          (dynIdx.initWork : ℝ) ≤ stepWorkBound ∧
          (dynIdx.initSpace : ℝ) ≤ spaceBound ∧
          -- Adaptive execution guarantees up to `maxOps` primitive operations
          (∀ adv : DynamicSearchAdversary ι d d_s,
            IsValidBoundedDynamicSearchAdversary n maxOps pts (fun _ _ => True) dynIdx adv →
              -- Almost-sure halting at every reachable step
              (∀ bitTrace : List (List Bool), bitTrace.length < maxOps →
                ∀ prefSt,
                  runDynamicSearchSteps dynIdx adv bitTrace = some prefSt →
                    let (extHist, op) := adv prefSt.history
                    singleDynamicSearchStepHaltProb dynIdx extHist
                      prefSt.activeSet prefSt.dynState op = 1) ∧
              -- Deterministic worst-case per-operation work and all-time space bounds
              (∀ T : ℕ, T ≤ maxOps → ∀ trace : Fin T → List Bool, ∀ out,
                runDynamicSearchPrefix dynIdx adv T trace = some out →
                  (∀ w ∈ out.stepWorks, (w : ℝ) ≤ stepWorkBound) ∧
                  (out.maxSpace : ℝ) ≤ spaceBound) ∧
              -- Simultaneous adaptive query correctness across all T ≤ maxOps operations
              (∀ T : ℕ, T ≤ maxOps →
                ENNReal.ofReal (1 - 2 * (T : ℝ) * δ_fail) ≤
                  dynamicSearchPrefixEventProb dynIdx adv T
                    (AllDynamicQueryAnswersCorrect pts h)))) ∧
      -- (2) Certified birth-pool primitives => always-correct expected-amortized guarantee (via Lemma C.3)
      (∀ (δ_margin netLogBound : ℝ) (_ : 0 ≤ δ_margin) (_ : 0 ≤ netLogBound)
         (N : Finset (EuclideanSpace ℝ (Fin d_s)))
         (_ : IsValidImplicitDirectionNet N netLogBound)
         (CertBirthState CertPhaseState : Type)
         (mkCert : SearchGeneration (ι × ℕ) d_s →
           CertifiedSearchGeneration (ι × ℕ) d d_s CertBirthState CertPhaseState),
        (∀ gen : SearchGeneration (ι × ℕ) d_s,
          gen.m ≤ n → gen.h = h →
            (mkCert gen).gen = gen ∧
            (mkCert gen).δ = δ_margin ∧
            ∀ birthHist : ExecutionHistory d,
              SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
                birthHist (mkCert gen)) →
        let certAdmissible : Finset ι → SearchQuery ι d_s → Prop := fun S q =>
          q.z ∈ N ∧
          ((δ_margin = 0 ∧ IsCompatibleTest pts S q.z q.accept) ∨
            IsMarginCompatibleTest pts S δ_margin q.z q.accept)
        let logFacCert : ℝ :=
          (1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound) ^ deg_log
        let amortWorkBound : ℝ :=
          C_wrap * logFacCert * (n : ℝ) ^ θ * facs.P_time *
            (facs.P_build + facs.P_del + facs.P_query)
        let spaceBoundCert : ℝ :=
          C_wrap * logFacCert * (n : ℝ) ^ (1 + σ) * facs.P_space
        ∃ (CtrlState : Type)
          (ctrl : CertHostedController ι d_s CertBirthState CertPhaseState CtrlState),
          let dynIdx := ctrl.toDynamicSearchIndex (d := d) n pts h mkCert
          -- Prefix-free coin consumption
          (∀ extHist S st op bs₁ bs₂ out₁ out₂,
            dynIdx.stepWithBits extHist S st op bs₁ = some out₁ →
            dynIdx.stepWithBits extHist S st op bs₂ = some out₂ →
            bs₁ <+: bs₂ → bs₁ = bs₂) ∧
          (dynIdx.initSpace : ℝ) ≤ spaceBoundCert ∧
          (∀ adv : DynamicSearchAdversary ι d d_s,
            IsValidBoundedDynamicSearchAdversary n maxOps pts certAdmissible dynIdx adv →
              -- Almost-sure halting at every reachable step
              (∀ bitTrace : List (List Bool), bitTrace.length < maxOps →
                ∀ prefSt,
                  runDynamicSearchSteps dynIdx adv bitTrace = some prefSt →
                    let (extHist, op) := adv prefSt.history
                    singleDynamicSearchStepHaltProb dynIdx extHist
                      prefSt.activeSet prefSt.dynState op = 1) ∧
              -- Always-correct (zero-error) query answers and deterministic space cap on every path
              (∀ T : ℕ, T ≤ maxOps → ∀ trace : Fin T → List Bool, ∀ out,
                runDynamicSearchPrefix dynIdx adv T trace = some out →
                  (∀ rec ∈ out.queryRecords,
                    IsCorrectSearchAnswer pts rec.1 h rec.2.1.z rec.2.1.accept rec.2.2) ∧
                  (out.maxSpace : ℝ) ≤ spaceBoundCert) ∧
              -- Expected amortized work bound over every fixed finite prefix 1 ≤ T ≤ maxOps
              (∀ T : ℕ, 1 ≤ T → T ≤ maxOps →
                dynamicSearchPrefixExpectedWork dynIdx adv T ≠ ⊤ ∧
                (dynamicSearchPrefixExpectedWork dynIdx adv T).toReal / (T : ℝ) ≤
                  amortWorkBound)))

end UL
