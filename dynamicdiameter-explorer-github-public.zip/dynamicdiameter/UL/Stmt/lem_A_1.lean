import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_halfspace_depth
set_option autoImplicit false

namespace UL

open Classical in
/-- Lemma A.1 (paper p.44). Exactly the paper's statement, as a Prop. -/
def S_lem_A_1 : Prop :=
  ∃ (sizeProg prog : BitRAMStmt) (α : ℕ → ℝ → ℝ)
    (C_α : ℝ) (deg_α : ℕ) (C_alg : ℝ) (deg_alg : ℕ),
    0 < C_α ∧ 0 < C_alg ∧
    (∀ (D : ℕ), 1 ≤ D →
      ∀ (φ : ℝ), 0 < φ → φ < 1 / 2 →
        0 < α D φ ∧ α D φ ≤ 1 ∧
        (α D φ)⁻¹ ≤
          C_α * ((D : ℝ) + 1) ^ deg_α * (Real.log (1 / φ) + 1) ^ deg_α) ∧
    ∀ (D B : ℕ), 1 ≤ D → 1 ≤ B →
      ∀ (φ : ℝ), 0 < φ → φ < 1 / 2 →
        let k : ℕ := Nat.ceil (Real.logb 2 (1 / φ))
        let polyBound : ℝ :=
          C_alg * ((D : ℝ) + 1) ^ deg_alg * ((B : ℝ) + 1) ^ deg_alg *
            (Real.log (1 / φ) + 1) ^ deg_alg
        ∃ (M : ℕ) (sizeOut : BitRAMExecOutcome),
          runBitRAMWithBits sizeProg
            (BitRAMInput.ofIntParams [(D : ℤ), (B : ℤ), (k : ℤ)])
            WordStore.empty [] = some sizeOut ∧
          sizeOut.words.read (.heap 0 0) = (M : ℤ) ∧
          1 ≤ M ∧
          (M : ℝ) ≤ polyBound ∧
          (sizeOut.unitCost : ℝ) ≤ polyBound ∧
          (sizeOut.bitCost : ℝ) ≤ polyBound ∧
          (sizeOut.peakCellSpace : ℝ) ≤ polyBound ∧
          (sizeOut.peakBitSpace : ℝ) ≤ polyBound ∧
          ∀ (ι : Type) [Fintype ι] [Nonempty ι] (P : ι → Fin D → ℚ),
            (∀ i : ι, RatPointBitBounded B (P i)) →
            let sampleInp : (Fin M → ι) → BitRAMInput D := fun ω =>
              { intParams := [(B : ℤ), (k : ℤ), (M : ℤ)]
                activeHandles := Finset.range M
                activeRatCoords := fun j =>
                  if hj : j < M then P (ω ⟨j, hj⟩) else fun _ => 0
                extraRats := [] }
            (∀ ω : Fin M → ι,
              ∃ (out : BitRAMExecOutcome) (zRat : Fin D → ℚ),
                runBitRAMWithBits prog (sampleInp ω) WordStore.empty [] = some out ∧
                (out.unitCost : ℝ) ≤ polyBound ∧
                (out.bitCost : ℝ) ≤ polyBound ∧
                (out.peakCellSpace : ℝ) ≤ polyBound ∧
                (out.peakBitSpace : ℝ) ≤ polyBound ∧
                (∀ c : Fin D,
                  let zNum := out.words.read (.heap 1 (2 * (c.val : ℤ)))
                  let zDen := out.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
                  0 < zDen ∧
                  zRat c = (zNum : ℚ) / (zDen : ℚ) ∧
                  (intBitLength zNum : ℝ) ≤ polyBound ∧
                  (intBitLength zDen : ℝ) ≤ polyBound ∧
                  (ratBitLength (zRat c) : ℝ) ≤ polyBound) ∧
                ((∑ c : Fin D, ratBitLength (zRat c)) : ℝ) ≤ polyBound) ∧
            1 - φ ≤
              ((Finset.univ.filter (fun ω : Fin M → ι =>
                ∃ (out : BitRAMExecOutcome) (zRat : Fin D → ℚ),
                  runBitRAMWithBits prog (sampleInp ω) WordStore.empty [] = some out ∧
                  (∀ c : Fin D,
                    let zNum := out.words.read (.heap 1 (2 * (c.val : ℤ)))
                    let zDen := out.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
                    0 < zDen ∧ zRat c = (zNum : ℚ) / (zDen : ℚ)) ∧
                  IsCenterpoint (α D φ)
                    (fun i : ι => ratPointToEuclidean (P i))
                    (ratPointToEuclidean zRat))).card : ℝ) /
                (Fintype.card (Fin M → ι) : ℝ)

end UL
