import Mathlib
import UL.Def.def_core_witness_halfspaces
import UL.Def.def_node_chain_blocks
import UL.Def.def_node_baseline
set_option autoImplicit false

namespace UL

open Classical in
/-- Claim (Sec. 5.1: Monte Carlo baseline witness sampling) (paper p.17). Exactly the paper's statement, as a Prop. -/
def S_clm_5_1_mc_baseline : Prop :=
  ∃ (C : ℝ), 0 < C ∧
    ∀ (α ψ : ℝ), 0 < α → α ≤ 1 → 0 < ψ → ψ < 1 →
      ∃ (k : ℕ), 1 ≤ k ∧ k ≤ Nat.ceil (C * α⁻¹ * Real.log (1 / ψ)) ∧
        ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
          (pts : ι → EuclideanSpace ℝ (Fin d))
          (Hist : Type)
          (P₀ S : Hist → Finset ι) (age : Hist → ℕ)
          (o : Hist → EuclideanSpace ℝ (Fin d)) (s : Hist → ℝ),
          (∀ (y : Hist → EuclideanSpace ℝ (Fin d))
             (farthest : Hist → (Fin k → ι) → ι)
             (hist : Hist),
            1 ≤ (P₀ hist).card →
            IsCenterpoint α (paraboloidLiftSet (fun i : P₀ hist => pts i.1))
              (liftedPoint (o hist) (s hist)) →
            HasNodeAge (P₀ hist) (S hist) (age hist) →
            (age hist : ℝ) ≤ α * ((P₀ hist).card : ℝ) / 16 →
            let V := liftVariance (o hist) (s hist)
            let samples := Fintype.piFinset (fun _ : Fin k => S hist)
            (∀ samp ∈ samples,
              (∃ j : Fin k, farthest hist samp = samp j) ∧
              ∀ j : Fin k, ‖pts (samp j) - y hist‖ ≤ ‖pts (farthest hist samp) - y hist‖) →
            (S hist).Nonempty ∧
            (α / 2) * ((S hist).card : ℝ) ≤
              (((S hist).filter (fun p =>
                IsVarianceWitness (o hist) V (y hist) (pts p))).card : ℝ) ∧
            (((samples.filter (fun samp =>
                ¬ IsVarianceWitness (o hist) V (y hist)
                    (pts (farthest hist samp)))).card : ℝ) /
              (samples.card : ℝ)) ≤ ψ) ∧
          (∀ (y : Hist → ι)
             (farthest : Hist → (Fin k → ι) → ι)
             (hist : Hist),
            1 ≤ (P₀ hist).card →
            IsCenterpoint α (paraboloidLiftSet (fun i : P₀ hist => pts i.1))
              (liftedPoint (o hist) (s hist)) →
            HasNodeAge (P₀ hist) (S hist) (age hist) →
            (age hist : ℝ) ≤ α * ((P₀ hist).card : ℝ) / 16 →
            IsNodeMaxRadiusPoint pts (o hist) (S hist) (y hist) →
            let V := liftVariance (o hist) (s hist)
            let samples := Fintype.piFinset (fun _ : Fin k => S hist)
            (∀ samp ∈ samples,
              (∃ j : Fin k, farthest hist samp = samp j) ∧
              ∀ j : Fin k, ‖pts (samp j) - pts (y hist)‖ ≤ ‖pts (farthest hist samp) - pts (y hist)‖) →
            (((samples.filter (fun samp =>
                ¬ IsNodeBaselinePair pts (o hist) V (S hist) (y hist)
                    (farthest hist samp))).card : ℝ) /
              (samples.card : ℝ)) ≤ ψ)

end UL
-- Claim 5.1 Monte Carlo baseline statement.
