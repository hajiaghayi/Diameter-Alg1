import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
set_option autoImplicit false

namespace UL

/-- Lemma 7.2 (paper p.34). Exactly the paper's statement, as a Prop. -/
def S_lem_7_2 : Prop :=
  ∃ (C_time C_space : ℝ) (queryConst writeFactor : ℕ),
    0 < C_time ∧ 0 < C_space ∧
    ∀ (d n t : ℕ), 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        ∃ (prog : ArithRAMDynamicProgram) (initOut : ArithRAMExecOutcome),
          prog.evalInit n d = some initOut ∧
          let alg : DynamicDiameterStructure d ArithRAMMemory :=
            { initState := initOut.mem
              initWork := initOut.unitCost
              initSpace := initOut.peakCellSpace
              cachedAnswer := fun mem =>
                let ca := ArithRAMDynamicProgram.readCachedAnswer mem
                { diameterHandles := ca.1, cachedDistSq := ca.2 }
              retrieveIdsAndRefCost := 4
              writeOutputCost := fun L => L + 1
              stepWithBits := fun activeH hCoords mem uop bs =>
                let rawOut :=
                  match uop with
                  | .insert pt => prog.evalUpdate n activeH hCoords mem true pt 0 bs
                  | .delete h => prog.evalUpdate n activeH hCoords mem false 0 h bs
                rawOut.map (fun out =>
                  let ca := ArithRAMDynamicProgram.readCachedAnswer out.mem
                  { nextState := out.mem
                    returnedHandle :=
                      match uop with
                      | .insert _ => ArithRAMDynamicProgram.readReturnedHandle out.mem
                      | .delete _ => none
                    storedAnswer := { diameterHandles := ca.1, cachedDistSq := ca.2 }
                    work := out.unitCost
                    peakSpace := out.peakCellSpace }) }
          SatisfiesDynamicStorageAndQueryModel queryConst writeFactor alg ∧
          SatisfiesMonteCarloGuarantee n t δ (Real.sqrt 2) Set.univ alg ∧
          SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg
            (C_time * ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18)) ∧
          SatisfiesBoundedSpaceBound n t Set.univ alg
            (C_space * (n : ℝ) * ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18))

end UL
