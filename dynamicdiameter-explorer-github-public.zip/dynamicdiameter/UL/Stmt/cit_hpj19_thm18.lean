import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_halfspace_depth
import UL.Def.def_paraboloid_lift_variance
set_option autoImplicit false

namespace UL

/-- Har-Peled–Jones [HPJ19, Theorem 18] (paper p.16). Exactly the paper's statement, as a Prop. -/
def S_cit_hpj19_thm18 : Prop :=
  open Classical in
  ∃ (prog : ArithRAMStmt) (C : ℝ), 0 < C ∧
    ∀ (d : ℕ) (φ : ℝ), 0 < φ → φ < 1 / 2 →
    ∀ (ι : Type) [Fintype ι] [Nonempty ι]
      (P₀ : ι → EuclideanSpace ℝ (Fin d))
      (handle : ι ↪ ℕ)
      (N : ℕ),
      let opBound : ℝ :=
        C * ((d : ℝ) + 1) ^ 7 * (Real.log ((d : ℝ) + 2)) ^ 3 * (Real.log (2 / φ)) ^ 3
      Nat.ceil opBound ≤ N →
      let inp : (Fin N → ι) → ArithRAMInput d := fun ω =>
        { intParams := List.ofFn (fun k : Fin N => (handle (ω k) : ℤ))
          activeHandles := (Finset.univ : Finset ι).map handle
          activeCoords := fun h =>
            if hh : ∃ i : ι, handle i = h then P₀ (Classical.choose hh) else 0
          extraReals := [φ] }
      let readOutput : ArithRAMExecOutcome → EuclideanSpace ℝ (Fin (d + 1)) := fun out =>
        liftedPoint
          (WithLp.toLp 2 (fun j : Fin d => out.mem.reals.read (.heap 0 (j.val : ℤ))))
          (out.mem.reals.read (.heap 0 (d : ℤ)))
      (∀ ω : Fin N → ι,
        (∑' bs : List Bool,
          if (runArithRAMWithBits prog (inp ω) ArithRAMMemory.empty bs).isSome then
            ((2 : ENNReal)⁻¹) ^ bs.length
          else 0) = 1 ∧
        ∀ (bs : List Bool) (out : ArithRAMExecOutcome),
          runArithRAMWithBits prog (inp ω) ArithRAMMemory.empty bs = some out →
            (out.unitCost : ℝ) ≤ opBound) ∧
      ENNReal.ofReal (1 - φ) ≤
        (∑ ω : Fin N → ι,
          ∑' bs : List Bool,
            match runArithRAMWithBits prog (inp ω) ArithRAMMemory.empty bs with
            | some out =>
                if IsCenterpoint (1 / (4 * ((d : ℝ) + 3) ^ 2))
                    (paraboloidLiftSet P₀) (readOutput out) then
                  ((2 : ENNReal)⁻¹) ^ bs.length
                else 0
            | none => 0) / (Fintype.card (Fin N → ι) : ENNReal)

end UL
