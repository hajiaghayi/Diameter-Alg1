import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_6_search_interface
import UL.Def.def_6_search_exponents
import UL.Def.def_6_1_gaussian_filter
set_option autoImplicit false

namespace UL

/-- Lemma 6.3 (A capped explicit index, paper pp.22–23). Exactly the paper's statement, as a Prop. -/
def S_lem_6_3 : Prop :=
  ∀ (ℓ : ℕ) (hℓ : 1 ≤ ℓ)
    (h_min h_max : ℝ) (hh_min : 0 < h_min) (hh_le : h_min ≤ h_max) (hh_max : h_max < 1),
    ∃ (paramStmt initStmt insertStmt deleteStmt queryStmt : ArithRAMStmt)
      (P : ℕ → ℕ → ℝ) (c_succ : ℝ),
      IsBoundedByPoly2 P ∧
      0 < c_succ ∧
      ∀ (d : ℕ), 1 ≤ d →
        ∀ (ι : Type) (gen : SearchGeneration ι d) (enum : Fin gen.m ≃ ↥gen.P₀),
          h_min ≤ gen.h → gen.h ≤ h_max →
            ∀ (x : ℝ), gen.h ≤ x → x ≤ 1 →
              let m : ℕ := gen.m
              let h : ℝ := gen.h
              let poly : ℝ := P d (natBitLength m)
              let u : ℝ := u_search h x
              let q_exp : ℝ := q_search h x
              let base_exp : ℝ := I_h h x / (ℓ : ℝ)
              let dataWorkBound : ℝ := ((m : ℝ) ^ u + (m : ℝ) ^ base_exp) * poly
              let queryWorkBound : ℝ := ((m : ℝ) ^ q_exp + (m : ℝ) ^ base_exp) * poly
              let spaceBound : ℝ := ((m : ℝ) ^ (1 + u) + (m : ℝ) ^ base_exp) * poly
              let poolCoords : ℕ → EuclideanSpace ℝ (Fin d) :=
                fun k => if hk : k < m then gen.pts (enum ⟨k, hk⟩).1 else 0
              let survivingHandles : List (Fin m) → Finset (Fin m) :=
                fun dels => Finset.univ.filter (fun k => k ∉ dels)
              let survivingSet : List (Fin m) → Finset ι :=
                fun dels => open Classical in (survivingHandles dels).image (fun k => (enum k).1)
              let decodeCandidates : ArithRAMMemory → List ι :=
                fun qMem =>
                  let r : ℕ := (qMem.words.read (.heap 0 0)).toNat
                  (List.range r).filterMap (fun idx =>
                    let h_z := qMem.words.read (.heap 0 ((idx : ℤ) + 1))
                    if hh : 0 ≤ h_z ∧ h_z.toNat < m then
                      some (enum ⟨h_z.toNat, hh.2⟩).1
                    else
                      none)
              let queryAnswer : ArithRAMMemory → (ι → Prop) → Option ι :=
                fun qMem accept =>
                  open Classical in (decodeCandidates qMem).find? (fun i => decide (accept i))
              ∃ pOut : ArithRAMExecOutcome,
                runArithRAMWithBits paramStmt
                  ({ intParams := [(m : ℤ)]
                     activeHandles := ∅
                     activeCoords := fun _ => 0
                     extraReals := [h, x] } : ArithRAMInput d)
                  ArithRAMMemory.empty [] = some pOut ∧
                (pOut.unitCost : ℝ) ≤ dataWorkBound ∧
                (pOut.peakCellSpace : ℝ) ≤ spaceBound ∧
                1 ≤ pOut.mem.words.read (.heap 0 0) ∧
                let K : ℕ := (pOut.mem.words.read (.heap 0 0)).toNat
                let μ : MeasureTheory.Measure (Fin K → EuclideanSpace ℝ (Fin d)) :=
                  MeasureTheory.Measure.pi (fun _ : Fin K => stdGaussianMeasure d)
                let gaussianReals : (Fin K → EuclideanSpace ℝ (Fin d)) → List ℝ :=
                  fun ω =>
                    (List.finRange K).flatMap (fun k =>
                      List.ofFn (fun c : Fin d => euclideanCoord (ω k) c))
                let validBuildTrace :
                    (Fin K → EuclideanSpace ℝ (Fin d)) → ArithRAMMemory → Prop :=
                  fun ω builtMem =>
                    ∃ (initOut : ArithRAMExecOutcome)
                      (insMem : Fin (m + 1) → ArithRAMMemory)
                      (insOut : Fin m → ArithRAMExecOutcome),
                      runArithRAMWithBits initStmt
                        ({ intParams := [(m : ℤ), (K : ℤ)]
                           activeHandles := ∅
                           activeCoords := fun _ => 0
                           extraReals := h :: x :: gaussianReals ω } : ArithRAMInput d)
                        pOut.mem [] = some initOut ∧
                      (initOut.unitCost : ℝ) ≤ dataWorkBound ∧
                      (initOut.peakCellSpace : ℝ) ≤ spaceBound ∧
                      insMem 0 = initOut.mem ∧
                      (∀ k : Fin m,
                        runArithRAMWithBits insertStmt
                          ({ intParams := [(k.1 : ℤ)]
                             activeHandles := Finset.range (k.1 + 1)
                             activeCoords := poolCoords
                             extraReals := [] } : ArithRAMInput d)
                          (insMem k.castSucc) [] = some (insOut k) ∧
                        insMem k.succ = (insOut k).mem ∧
                        ((insOut k).unitCost : ℝ) ≤ dataWorkBound ∧
                        ((insOut k).peakCellSpace : ℝ) ≤ spaceBound) ∧
                      ((pOut.unitCost + initOut.unitCost +
                          ∑ k : Fin m, (insOut k).unitCost : ℝ) ≤ (m : ℝ) * dataWorkBound) ∧
                      builtMem = insMem (Fin.last m)
                let validDeleteTrace :
                    ArithRAMMemory → List (Fin m) → ArithRAMMemory → Prop :=
                  fun builtMem dels finalMem =>
                    ∃ (delMem : Fin (dels.length + 1) → ArithRAMMemory)
                      (delOut : Fin dels.length → ArithRAMExecOutcome),
                      delMem 0 = builtMem ∧
                      (∀ step : Fin dels.length,
                        let activeAfter : Finset ℕ :=
                          (Finset.univ.filter
                            (fun k : Fin m => k ∉ dels.take (step.1 + 1))).image Fin.val
                        runArithRAMWithBits deleteStmt
                          ({ intParams := [((dels.get step).1 : ℤ)]
                             activeHandles := activeAfter
                             activeCoords := poolCoords
                             extraReals := [] } : ArithRAMInput d)
                          (delMem step.castSucc) [] = some (delOut step) ∧
                        delMem step.succ = (delOut step).mem ∧
                        ((delOut step).unitCost : ℝ) ≤ dataWorkBound ∧
                        ((delOut step).peakCellSpace : ℝ) ≤ spaceBound) ∧
                      finalMem = delMem (Fin.last dels.length)
                let validQueryRun :
                    ArithRAMMemory → List (Fin m) → EuclideanSpace ℝ (Fin d) →
                      ArithRAMExecOutcome → Prop :=
                  fun finalMem dels z qOut =>
                    runArithRAMWithBits queryStmt
                      ({ intParams := []
                         activeHandles := (survivingHandles dels).image Fin.val
                         activeCoords := poolCoords
                         extraReals := List.ofFn (fun c : Fin d => euclideanCoord z c) } :
                        ArithRAMInput d)
                      finalMem [] = some qOut ∧
                    (qOut.peakCellSpace : ℝ) ≤ spaceBound ∧
                    0 ≤ qOut.mem.words.read (.heap 0 0) ∧
                    let r : ℕ := (qOut.mem.words.read (.heap 0 0)).toNat
                    ((qOut.unitCost + r : ℝ) ≤ queryWorkBound) ∧
                    (∀ idx : ℕ, idx < r →
                      let h_z := qOut.mem.words.read (.heap 0 ((idx : ℤ) + 1))
                      0 ≤ h_z ∧ h_z.toNat ∈ (survivingHandles dels).image Fin.val)
                (∀ ω : Fin K → EuclideanSpace ℝ (Fin d),
                  ∃ builtMem : ArithRAMMemory,
                    validBuildTrace ω builtMem ∧
                    ∀ (dels : List (Fin m)), dels.Nodup →
                      ∃ finalMem : ArithRAMMemory,
                        validDeleteTrace builtMem dels finalMem ∧
                        ∀ (z : EuclideanSpace ℝ (Fin d)), IsUnitVec z →
                          ∃ qOut : ArithRAMExecOutcome,
                            validQueryRun finalMem dels z qOut ∧
                            ∀ (q : SearchQuery ι d), q.z = z →
                              q.IsValidAnswer (survivingSet dels) (queryAnswer qOut.mem q.accept)) ∧
                (∀ (z : EuclideanSpace ℝ (Fin d)), IsUnitVec z →
                  ∀ (i_star : ι), IsSearchTarget gen.pts gen.P₀ h z i_star →
                    ∃ E : Set (Fin K → EuclideanSpace ℝ (Fin d)),
                      MeasurableSet E ∧
                      c_succ ≤ μ.real E ∧
                      ∀ ω ∈ E,
                        ∀ (builtMem : ArithRAMMemory), validBuildTrace ω builtMem →
                          ∀ (dels : List (Fin m)), dels.Nodup →
                            let P_cur := survivingSet dels
                            i_star ∈ P_cur →
                              ∀ (finalMem : ArithRAMMemory),
                                validDeleteTrace builtMem dels finalMem →
                                ∀ (qOut : ArithRAMExecOutcome),
                                  validQueryRun finalMem dels z qOut →
                                  ∀ (q : SearchQuery ι d), q.z = z → gen.IsCompatible P_cur q →
                                    let ans := queryAnswer qOut.mem q.accept
                                    ans ≠ none ∧ gen.IsCorrectAnswer P_cur q ans)

end UL
