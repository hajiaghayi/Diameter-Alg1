import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_node_baseline
import UL.Def.def_local_scale_params
import UL.Def.def_shells_configurations
import UL.Def.def_local_matching
set_option autoImplicit false

namespace UL

/-- Lemma 5.5 (paper p.19). Exactly the paper's statement, as a Prop. -/
def S_lem_5_5 : Prop :=
  ∀ (d : ℕ) (ι : Type)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d))
    (V : ℝ)
    (S : Finset ι)
    (params : LocalScaleParams)
    (basePair : Option (ι × ι))
    (M : ShellConfig → Finset (ι × ι))
    (stored : ShellConfig → Option (ι × ι))
    (hV : 0 ≤ V)
    (h_base : SatisfiesNodeBaselineCond pts o V S basePair)
    (h_match : 0 < V →
      ∀ cfg ∈ params.retainedConfigs V,
        params.SatisfiesMatchingInvariant pts o V S cfg.j cfg.k cfg.ℓ (M cfg) ∧
        IsStoredMatchingEdge (M cfg) (stored cfg)),
    nodeCoreInputDiam pts o V S / params.c ≤
      params.nodeRetainedEstimate pts V (baselinePairLength pts basePair) stored ∧
    params.nodeRetainedEstimate pts V (baselinePairLength pts basePair) stored ≤
      indexedEuclideanDiam S pts

end UL
