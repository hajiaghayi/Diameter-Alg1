import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_6_search_interface
import UL.Def.def_6_search_exponents
import UL.Def.def_6_1_gaussian_filter
set_option autoImplicit false

namespace UL

/-- Padded lift `(A (w / ‖w‖), B) ∈ ℝ^{d+1}` of a raw rational vector `w ∈ ℚ^d`. -/
noncomputable def paddedNormalizedRatVec {d : ℕ} (A B : ℚ) (w : Fin d → ℚ) :
    EuclideanSpace ℝ (Fin (d + 1)) :=
  let wE := ratPointToEuclidean w
  (WithLp.equiv 2 (Fin (d + 1) → ℝ)).symm
    (Fin.snoc (fun i : Fin d => (A : ℝ) * (euclideanCoord wE i / ‖wE‖)) (B : ℝ))

/-- Sign-and-squared rational decision predicate for `A ⟨G_{1:d}, w⟩ ≥ (a₀ - B G_{d+1}) ‖w‖`
on a raw rational vector `w ∈ ℚ^d`, rational filter `G ∈ ℚ^{d+1}`, and rational `A, B, a₀`. -/
def ratSignedSquaredCapTest {d : ℕ} (A B a₀ : ℚ) (G : Fin (d + 1) → ℚ) (w : Fin d → ℚ) : Prop :=
  let L : ℚ := A * ∑ i : Fin d, G (Fin.castSucc i) * w i
  let R : ℚ := a₀ - B * G (Fin.last d)
  let normSq : ℚ := ∑ i : Fin d, (w i) ^ 2
  (0 < R ∧ 0 ≤ L ∧ R ^ 2 * normSq ≤ L ^ 2) ∨
  (R ≤ 0 ∧ (0 ≤ L ∨ L ^ 2 ≤ R ^ 2 * normSq))

/-- Index tuple `(r, s, k)` selecting copy `r`, tensor factor `s`, and base cap `k`. -/
abbrev ExplicitCapIdx (R ℓ M₀ : ℕ) : Type :=
  Fin R × Fin ℓ × Fin M₀

/-- Discrete uniform random bit seed assigning `b` bits to each coordinate of each cap vector. -/
abbrev ExplicitBitSeed (R ℓ M₀ D b : ℕ) : Type :=
  ExplicitCapIdx R ℓ M₀ × Fin D × Fin b → Bool

/-- Eligible data base-cap indices in `(r, s)` for vector `p ∈ ℝ^D` at threshold `τ_d`. -/
noncomputable def explicitDataBaseSet {D R ℓ M₀ : ℕ}
    (F : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_d : ℝ)
    (p : EuclideanSpace ℝ (Fin D)) (r : Fin R) (s : Fin ℓ) : Finset (Fin M₀) :=
  open Classical in
  Finset.univ.filter (fun k : Fin M₀ => gaussianDataTest τ_d (F (r, s, k)) p)

/-- Eligible query base-cap indices in `(r, s)` for vector `z ∈ ℝ^D` at threshold `τ_q`. -/
noncomputable def explicitQueryBaseSet {D R ℓ M₀ : ℕ}
    (F : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_q : ℝ)
    (z : EuclideanSpace ℝ (Fin D)) (r : Fin R) (s : Fin ℓ) : Finset (Fin M₀) :=
  open Classical in
  Finset.univ.filter (fun k : Fin M₀ => gaussianDataTest τ_q (F (r, s, k)) z)

/-- Capped stored tuple set of point `i` in copy `r` (omitted when product exceeds `cap_u`). -/
noncomputable def explicitStoredTuples {ι : Type*} {D R ℓ M₀ : ℕ}
    (F : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_d : ℝ) (cap_u : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin D)) (r : Fin R) (i : ι) : Finset (Fin ℓ → Fin M₀) :=
  let prodSet := Fintype.piFinset (fun s : Fin ℓ => explicitDataBaseSet F τ_d (pts i) r s)
  if prodSet.card ≤ cap_u then prodSet else ∅

/-- Per-point construction and deletion work across all `R` copies on cap family `F`. -/
noncomputable def explicitPointDataWork {ι : Type*} {D R ℓ M₀ : ℕ}
    (F : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_d : ℝ) (cap_u : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin D)) (i : ι) : ℕ :=
  R * ℓ * M₀ * D + ∑ r : Fin R, (explicitStoredTuples F τ_d cap_u pts r i).card * ℓ

/-- Total index space (cap vectors plus nonempty bucket entries and deletion handles) on `F`. -/
noncomputable def explicitIndexSpace {ι : Type*} {D R ℓ M₀ : ℕ}
    (F : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_d : ℝ) (cap_u : ℕ)
    (gen : SearchGeneration ι D) : ℕ :=
  R * ℓ * M₀ * D +
    ∑ i ∈ gen.P₀, ∑ r : Fin R, (explicitStoredTuples F τ_d cap_u gen.pts r i).card * ℓ

/-- Capped explicit-filter query evaluation across `R` copies, stopping each copy after `cap_q`
tuples or `cap_q` rejected candidate occurrences (testing each candidate before stopping). -/
noncomputable def explicitCappedQuery {ι : Type*} [DecidableEq ι] {D R ℓ M₀ : ℕ}
    (F : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d τ_q : ℝ) (cap_u cap_q : ℕ)
    (gen : SearchGeneration ι D) (P : Finset ι) (q : SearchQuery ι D) : Option ι :=
  open Classical in
  (List.finRange R).findSome? fun r =>
    let visitedTuples :=
      (Fintype.piFinset (fun s : Fin ℓ => explicitQueryBaseSet F τ_q q.z r s)).toList.take cap_q
    let candidates := visitedTuples.flatMap fun tup =>
      ((gen.P₀ ∩ P).filter (fun i =>
        tup ∈ explicitStoredTuples F τ_d cap_u gen.pts r i)).toList
    (candidates.take (cap_q + 1)).find? (fun i => decide (q.accept i))

/-- Query work (base-cap evaluations, visited tuples, and candidate tests) across `R` copies. -/
noncomputable def explicitQueryWork {ι : Type*} [DecidableEq ι] {D R ℓ M₀ : ℕ}
    (F : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d τ_q : ℝ) (cap_u cap_q : ℕ)
    (gen : SearchGeneration ι D) (P : Finset ι) (q : SearchQuery ι D) : ℕ :=
  open Classical in
  R * ℓ * M₀ * D + ∑ r : Fin R,
    let visitedTuples :=
      (Fintype.piFinset (fun s : Fin ℓ => explicitQueryBaseSet F τ_q q.z r s)).toList.take cap_q
    let candidates := visitedTuples.flatMap fun tup =>
      ((gen.P₀ ∩ P).filter (fun i =>
        tup ∈ explicitStoredTuples F τ_d cap_u gen.pts r i)).toList
    visitedTuples.length * ℓ + (candidates.take (cap_q + 1)).length

/-- Claim (Sec. 6.1: Finite precision and exact exponents) (paper p.23). Exactly the paper's statement, as a Prop. -/
def S_clm_6_1_precision : Prop :=
  ∀ (h_min h_max : ℝ) (hh_min : 0 < h_min) (hh_le : h_min ≤ h_max) (hh_max : h_max < 1)
    (ℓ : ℕ) (hℓ : 1 ≤ ℓ),
    (∀ (d' : ℕ), 1 ≤ d' →
      ∀ (u : EuclideanSpace ℝ (Fin d')), IsUnitVec u →
      ∀ (τ Δ : ℝ), 0 ≤ Δ →
        (∀ G G_approx : EuclideanSpace ℝ (Fin d'),
          |inner ℝ (G_approx - G) u| ≤ Δ →
          inner ℝ G u ∉ Set.Icc (τ - Δ) (τ + Δ) →
          (gaussianDataTest τ G_approx u ↔ gaussianDataTest τ G u)) ∧
        (stdGaussianMeasure d').real {G | inner ℝ G u ∈ Set.Icc (τ - Δ) (τ + Δ)} ≤
          2 * Δ / Real.sqrt (2 * Real.pi)) ∧
    (∀ (d' K : ℕ), 1 ≤ d' → 1 ≤ K →
      ∀ (cmps : List (Fin K × EuclideanSpace ℝ (Fin d') × ℝ)),
        1 ≤ cmps.length →
        (∀ c ∈ cmps, IsUnitVec c.2.1) →
        ∀ (ε : ℝ), 0 < ε →
        ∀ (p_bits : ℕ),
          Real.logb 2 (cmps.length : ℝ) + Real.logb 2 (1 / ε) ≤ (p_bits : ℝ) →
          (MeasureTheory.Measure.pi (fun _ : Fin K => stdGaussianMeasure d')).real
              {G | ∃ c ∈ cmps, inner ℝ (G c.1) c.2.1 ∈
                Set.Icc (c.2.2 - (2 : ℝ) ^ (-(p_bits : ℤ)))
                        (c.2.2 + (2 : ℝ) ^ (-(p_bits : ℤ)))} ≤ ε ∧
          (∀ G G_approx : Fin K → EuclideanSpace ℝ (Fin d'),
            (∀ r : Fin K, ‖G_approx r - G r‖ ≤ (2 : ℝ) ^ (-(p_bits : ℤ))) →
            (¬ ∃ c ∈ cmps, inner ℝ (G c.1) c.2.1 ∈
              Set.Icc (c.2.2 - (2 : ℝ) ^ (-(p_bits : ℤ)))
                      (c.2.2 + (2 : ℝ) ^ (-(p_bits : ℤ)))) →
            ∀ c ∈ cmps,
              (gaussianDataTest c.2.2 (G_approx c.1) c.2.1 ↔
                gaussianDataTest c.2.2 (G c.1) c.2.1))) ∧
    (∀ (d : ℕ), 1 ≤ d →
      ∀ (A B : ℚ) (Gtilde : Fin (d + 1) → ℚ) (w : Fin d → ℚ),
        ratPointToEuclidean w ≠ 0 →
        (A ^ 2 + B ^ 2 = 1 → IsUnitVec (paddedNormalizedRatVec A B w)) ∧
        (∀ a₀ : ℚ,
          gaussianDataTest (a₀ : ℝ) (ratPointToEuclidean Gtilde) (paddedNormalizedRatVec A B w) ↔
            ratSignedSquaredCapTest A B a₀ Gtilde w) ∧
        (∀ x_q t_q : ℚ,
          gaussianQueryTest (x_q : ℝ) (t_q : ℝ)
              (ratPointToEuclidean Gtilde) (paddedNormalizedRatVec A (-B) w) ↔
            ratSignedSquaredCapTest A (-B) (x_q * t_q) Gtilde w)) ∧
    (∀ (C_net : ℝ), 0 ≤ C_net →
      ∃ (poly_prec poly_cap : ℕ → ℕ → ℝ),
        IsBoundedByPoly2 poly_prec ∧
        IsBoundedByPoly2 poly_cap ∧
        ∀ (d : ℕ), 1 ≤ d →
        ∀ (ι : Type) [DecidableEq ι] (gen : SearchGeneration ι (d + 1)),
          h_min ≤ gen.h → gen.h ≤ h_max →
          ∀ (x η ε₀ : ℝ),
            gen.h ≤ x → x ≤ 1 →
            0 < η → η ≤ 1 →
            0 < ε₀ → ε₀ < 1 →
            ∀ (Q_net : List (EuclideanSpace ℝ (Fin (d + 1)))),
              (∀ z ∈ Q_net, IsUnitVec z) →
              (Q_net.length : ℝ) ≤
                Real.exp (C_net * (d : ℝ) * Real.log (2 * (d : ℝ) / η)) →
              let L_log : ℕ :=
                Nat.ceil (Real.log (2 * (gen.m : ℝ) / ε₀) + Real.log (2 / η))
              ∃ (R M₀ cap_u cap_q b B_prec : ℕ) (t_ideal : ℝ) (τ_d τ_q : ℚ)
                (sampleCoord : (Fin b → Bool) → ℚ),
                1 ≤ R ∧ 1 ≤ M₀ ∧ 1 ≤ b ∧ 1 ≤ B_prec ∧ 1 ≤ t_ideal ∧
                (b : ℝ) ≤ poly_prec d L_log ∧
                (B_prec : ℝ) ≤ poly_prec d L_log ∧
                RatCoordBitBounded B_prec τ_d ∧
                RatCoordBitBounded B_prec τ_q ∧
                (∀ bits : Fin b → Bool, RatCoordBitBounded B_prec (sampleCoord bits)) ∧
                ((R * ℓ * M₀ : ℕ) : ℝ) ≤
                  (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ)) * poly_cap d L_log ∧
                (cap_u : ℝ) ≤
                  (gen.m : ℝ) ^ (u_search gen.h x) * poly_cap d L_log ∧
                (cap_q : ℝ) ≤
                  (gen.m : ℝ) ^ (q_search gen.h x) * poly_cap d L_log ∧
                (∀ ω : ExplicitBitSeed R ℓ M₀ (d + 1) b,
                  let F_disc : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
                    fun idx => ratPointToEuclidean (fun j =>
                      sampleCoord (fun bitIdx => ω (idx, j, bitIdx)))
                  (∀ i ∈ gen.P₀,
                    (explicitPointDataWork F_disc (τ_d : ℝ) cap_u gen.pts i : ℝ) ≤
                      ((gen.m : ℝ) ^ (u_search gen.h x) +
                        (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log) ∧
                  ((explicitIndexSpace F_disc (τ_d : ℝ) cap_u gen : ℝ) ≤
                    ((gen.m : ℝ) ^ (1 + u_search gen.h x) +
                      (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log) ∧
                  (∀ (P : Finset ι) (q : SearchQuery ι (d + 1)),
                    gen.IsSurvivingSubset P →
                    q.IsValidAnswer P
                      (explicitCappedQuery F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q) ∧
                    (explicitQueryWork F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q : ℝ) ≤
                      ((gen.m : ℝ) ^ (q_search gen.h x) +
                        (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log)) ∧
                (∃ (Ω_cpl : Type) (mΩ : MeasurableSpace Ω_cpl)
                   (μ_cpl : @MeasureTheory.Measure Ω_cpl mΩ)
                   (proj_bits : Ω_cpl → ExplicitBitSeed R ℓ M₀ (d + 1) b)
                   (proj_gauss :
                     Ω_cpl → (ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)))),
                  @MeasureTheory.IsProbabilityMeasure Ω_cpl mΩ μ_cpl ∧
                  @Measurable _ _ mΩ inferInstance proj_bits ∧
                  @Measurable _ _ mΩ inferInstance proj_gauss ∧
                  @MeasureTheory.Measure.map _ _ mΩ inferInstance proj_bits μ_cpl =
                    (PMF.uniformOfFintype (ExplicitBitSeed R ℓ M₀ (d + 1) b)).toMeasure ∧
                  @MeasureTheory.Measure.map _ _ mΩ inferInstance proj_gauss μ_cpl =
                    MeasureTheory.Measure.pi
                      (fun _ : ExplicitCapIdx R ℓ M₀ => stdGaussianMeasure (d + 1)) ∧
                  1 - ε₀ / 2 ≤ (@MeasureTheory.Measure.real Ω_cpl mΩ μ_cpl) {ω_c : Ω_cpl |
                    ∀ idx : ExplicitCapIdx R ℓ M₀,
                      let G_disc := ratPointToEuclidean (fun j =>
                        sampleCoord (fun bitIdx => proj_bits ω_c (idx, j, bitIdx)))
                      let G_id := proj_gauss ω_c idx
                      (∀ i ∈ gen.P₀,
                        gaussianDataTest (τ_d : ℝ) G_disc (gen.pts i) ↔
                          gaussianDataTest t_ideal G_id (gen.pts i)) ∧
                      (∀ z ∈ Q_net,
                        gaussianDataTest (τ_q : ℝ) G_disc z ↔
                          gaussianQueryTest x t_ideal G_id z)}) ∧
                (∃ E_good : Set (ExplicitBitSeed R ℓ M₀ (d + 1) b),
                  1 - ε₀ ≤
                    ((PMF.uniformOfFintype
                      (ExplicitBitSeed R ℓ M₀ (d + 1) b)).toMeasure).real E_good ∧
                  ∀ ω ∈ E_good,
                    let F_disc : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
                      fun idx => ratPointToEuclidean (fun j =>
                        sampleCoord (fun bitIdx => ω (idx, j, bitIdx)))
                    ∀ (P : Finset ι) (q : SearchQuery ι (d + 1)),
                      gen.IsSurvivingSubset P →
                      q.z ∈ Q_net →
                      gen.IsCompatible P q →
                      gen.IsCorrectAnswer P q
                        (explicitCappedQuery F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q)))

end UL
