import Mathlib
import UL.Def.def_dynamic_points_model
import UL.Def.def_computation_model
import UL.Def.def_node_chain_blocks
import UL.Def.def_C_2_schedule
set_option autoImplicit false

namespace UL

/-- Monotonic background-build completion step within a tick: keeps job metadata, current residual,
and each opened level's `birthSnapshot`, `ball`, and `indexMode` unchanged while allowing unready
background structures (`backgroundReady = false`) to become ready (`backgroundReady = true`). -/
def JobMarkReadyStep {d : ℕ} {ι : Type}
    (j j' : PendingReplacementJob d ι) : Prop :=
  j'.deadlineTicks = j.deadlineTicks ∧
  j'.remainingTicks = j.remainingTicks ∧
  j'.currentResidual = j.currentResidual ∧
  j'.closedAsLeaf = j.closedAsLeaf ∧
  List.Forall₂
    (fun lv lv' =>
      lv'.birthSnapshot = lv.birthSnapshot ∧
      lv'.ball = lv.ball ∧
      lv'.indexMode = lv.indexMode ∧
      (lv.backgroundReady = true → lv'.backgroundReady = true))
    j.completedPrefix j'.completedPrefix

/-- Single late-opening schedule action on an unclosed pending job whose completed prefix has all
background structures ready and whose current residual satisfies the late-opening gate
`r ≤ α m / C_*`: closes the residual as a leaf when `m ≤ 2L + 1`, or opens one fixed-ball level
via the two-stage opening rule when `m > 2L + 1`. -/
def JobGateStep {d : ℕ} {ι : Type}
    (α : ℝ) (L : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (j j' : PendingReplacementJob d ι) : Prop :=
  j.closedAsLeaf = false ∧
  (∀ lv ∈ j.completedPrefix, lv.backgroundReady = true) ∧
  CanOpenResidualLevel α j.remainingTicks j.currentResidual.card ∧
  ((IsResidualLeafSize L j.currentResidual.card ∧
      j' = closeResidualAsLeafInJob j) ∨
    (IsLargeResidualLevel L j.currentResidual.card ∧
      ∃ (res : SampledCenterResult d) (ball : ChainNode d) (mode : BackgroundIndexMode),
        IsValidOpenedLevelBall α pts j.currentResidual res ball ∧
        j' = openLargeLevelInJob pts j ball mode))

/-- End-of-tick quiescence of a pending replacement job: either its residual has been closed as a
leaf, or a background level build is currently in progress, or the late-opening gate
`r ≤ α m / C_*` does not hold. -/
def IsJobTickQuiescent {d : ℕ} {ι : Type} (α : ℝ)
    (j : PendingReplacementJob d ι) : Prop :=
  j.closedAsLeaf = true ∨
  (∃ lv ∈ j.completedPrefix, lv.backgroundReady = false) ∨
  ¬ CanOpenResidualLevel α j.remainingTicks j.currentResidual.card

/-- Unbounded within-tick transition chain allowing arbitrary interleavings of background
completions (`JobMarkReadyStep`) and late-opening gate actions (`JobGateStep`) within one tick
(without syntactically capping the number of levels opened in a tick). -/
inductive JobWithinTickChain {d : ℕ} {ι : Type}
    (α : ℝ) (L : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d)) :
    PendingReplacementJob d ι → PendingReplacementJob d ι → Prop
  | refl (j : PendingReplacementJob d ι) :
      JobWithinTickChain α L pts j j
  | markReady {j₁ j₂ j₃ : PendingReplacementJob d ι} :
      JobMarkReadyStep j₁ j₂ →
      JobWithinTickChain α L pts j₂ j₃ →
      JobWithinTickChain α L pts j₁ j₃
  | gate {j₁ j₂ j₃ : PendingReplacementJob d ι} :
      JobGateStep α L pts j₁ j₂ →
      JobWithinTickChain α L pts j₂ j₃ →
      JobWithinTickChain α L pts j₁ j₃

/-- Complete within-tick schedule pass: evolves `j` via `JobWithinTickChain` to a quiescent state
`j'` satisfying `IsJobTickQuiescent α j'`. -/
def ScheduleTickPass {d : ℕ} {ι : Type}
    (α : ℝ) (L : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (j j' : PendingReplacementJob d ι) : Prop :=
  JobWithinTickChain α L pts j j' ∧ IsJobTickQuiescent α j'

/-- Lemma C.2 (paper p.53). Exactly the paper's statement, as a Prop. -/
def S_lem_C_2 : Prop :=
  ∀ (d n : ℕ) (ι : Type)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (α C : ℝ) (K₀ L : ℕ)
    (T : ℕ)
    (S_root : Fin (T + 1) → Finset ι)
    (ev : Fin T → PoolUpdateEvent ι)
    (job : Fin (T + 1) → PendingReplacementJob d ι)
    (hα_pos : 0 < α)
    (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (h_cap : ∀ t : Fin (T + 1), (S_root t).card ≤ n)
    (h_m₀ : NeedsScheduledReplacement L (S_root 0).card)
    (h_ev : ∀ t : Fin T, IsValidPoolUpdateEvent (S_root t.castSucc) (S_root t.succ) (ev t))
    (h_deadline : poolClockTickCount (List.ofFn ev) = jobDeadlineTicks α (S_root 0).card)
    (h_init : ScheduleTickPass α L pts (initPendingJob α (S_root 0)) (job 0))
    (h_step : ∀ t : Fin T,
      if (ev t).isClockTick then
        ScheduleTickPass α L pts
          (updatePendingJobRootPool pts (job t.castSucc) (ev t) (S_root t.succ)) (job t.succ)
      else
        job t.succ = job t.castSucc)
    (h_build : ∀ (idx : ℕ) (t_open : Fin (T + 1)) (lv : OpenedJobLevel d ι),
      (∀ s : Fin (T + 1), s < t_open → (job s).completedPrefix[idx]? = none) →
      (job t_open).completedPrefix[idx]? = some lv →
      ∃ b : ℕ,
        (b : ℝ) ≤ α ^ 2 * (lv.birthSnapshot.card : ℝ) / (64 * (scheduleCStar : ℝ)) ∧
        ∀ s : Fin (T + 1),
          t_open ≤ s →
          b ≤ (job t_open).remainingTicks - (job s).remainingTicks →
          ∃ lv_s : OpenedJobLevel d ι,
            (job s).completedPrefix[idx]? = some lv_s ∧ lv_s.backgroundReady = true),
    let job_end := job (Fin.last T)
    let S_end := S_root (Fin.last T)
    let K := job_end.completedPrefix.length
    let nodes : Fin K → ChainNode d := fun i => (job_end.completedPrefix[i.val]'i.isLt).ball
    job_end.IsReadyToInstall ∧
    job_end.WellFormed α L pts S_end ∧
    (∀ i : Fin K,
      ((chainInput pts nodes S_end i.succ).card : ℝ) ≤
        (1 - α / 4) * ((chainInput pts nodes S_end i.castSucc).card : ℝ)) ∧
    (∀ (i : ℕ) (hi : i + 1 < K),
      ((job_end.completedPrefix[i + 1]'hi).birthSnapshot.card : ℝ) ≤
        (1 - α / 4) *
          ((job_end.completedPrefix[i]'(Nat.lt_of_succ_lt hi)).birthSnapshot.card : ℝ)) ∧
    job_end.currentResidual.card ≤ 3 * L + 2 ∧
    (∀ idx : Fin K,
      ∃ t_open : Fin (T + 1),
        (∀ s : Fin (T + 1), s < t_open → (job s).completedPrefix.length ≤ idx.val) ∧
        idx.val < (job t_open).completedPrefix.length ∧
        let lv := job_end.completedPrefix[idx.val]'idx.isLt
        let m := lv.birthSnapshot.card
        let elapsedTicks := poolClockTickCount ((List.ofFn ev).drop t_open.val)
        (elapsedTicks : ℝ) ≤ α * (m : ℝ) / (scheduleCStar : ℝ) ∧
        ∃ trueAge : ℕ,
          trueAge ≤ elapsedTicks ∧
          HasNodeAge lv.birthSnapshot
            (prefixResidual pts (job_end.completedPrefix.take idx.val) S_end) trueAge) ∧
    (job 0).completedPrefix.length ≤ 1 ∧
    (∀ t : Fin T,
      (job t.succ).completedPrefix.length ≤ (job t.castSucc).completedPrefix.length + (ev t).ticks)

end UL
