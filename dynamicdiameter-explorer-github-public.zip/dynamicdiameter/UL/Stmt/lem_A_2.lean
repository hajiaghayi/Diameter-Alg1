import Mathlib
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_node_chain_blocks
import UL.Def.def_A_convex_hull_cert
set_option autoImplicit false

namespace UL

/-- Lemma A.2 (paper p.45). Exactly the paper's statement, as a Prop. -/
def S_lem_A_2 : Prop :=
  ∃ (s₀ : ℕ → ℕ) (prog : BitRAMStmt)
    (timePoly spacePoly bitLenPoly : ℕ → ℕ → ℝ),
    (∀ d : ℕ, 1 ≤ s₀ d) ∧
    IsBoundedByPoly1 (fun d => (s₀ d : ℝ)) ∧
    IsBoundedByPoly2 timePoly ∧
    IsBoundedByPoly2 spacePoly ∧
    IsBoundedByPoly2 bitLenPoly ∧
    ∀ (d B : ℕ), 1 ≤ B →
      ∀ (ι : Type) [DecidableEq ι] (pts : ι → Fin d → ℚ) (P₀ : Finset ι)
        (enum : Fin P₀.card ≃ ↥P₀),
        2 * s₀ d ≤ P₀.card →
        (∀ i ∈ P₀, RatPointBitBounded B (pts i)) →
        let m : ℕ := P₀.card
        -- expUnitCost and peakCellSpace satisfy exact m * poly(d, B) RAM bounds, while
        -- expBitCost and peakBitSpace additionally bound finite-word bit-accounting with
        -- w = ⌈log₂(2m)⌉-bit handle addresses in BitRAMInput.inputBitSpace.
        let w : ℕ := Nat.clog 2 (2 * m)
        let inp : BitRAMInput d :=
          { intParams := [(m : ℤ), (B : ℤ)]
            activeHandles := Finset.range m
            activeRatCoords := fun h =>
              if hh : h < m then pts (enum ⟨h, hh⟩).1 else fun _ => 0
            extraRats := [] }
        let haltProb : ENNReal :=
          ∑' bs : List Bool,
            if (runBitRAMWithBits prog inp WordStore.empty bs).isSome then
              bitListProb bs
            else
              0
        let expUnitCost : ENNReal :=
          ∑' bs : List Bool,
            match runBitRAMWithBits prog inp WordStore.empty bs with
            | some out => bitListProb bs * (out.unitCost : ENNReal)
            | none => 0
        let expBitCost : ENNReal :=
          ∑' bs : List Bool,
            match runBitRAMWithBits prog inp WordStore.empty bs with
            | some out => bitListProb bs * (out.bitCost : ENNReal)
            | none => 0
        haltProb = 1 ∧
        expUnitCost ≠ ⊤ ∧
        expUnitCost.toReal ≤ (m : ℝ) * timePoly d B ∧
        expBitCost ≠ ⊤ ∧
        expBitCost.toReal ≤ (m : ℝ) * ((w : ℝ) ^ 2) * timePoly d B ∧
        ∀ (bs : List Bool) (out : BitRAMExecOutcome),
          runBitRAMWithBits prog inp WordStore.empty bs = some out →
            (out.peakCellSpace : ℝ) ≤ (m : ℝ) * spacePoly d B ∧
            (out.peakBitSpace : ℝ) ≤ (m : ℝ) * (w : ℝ) * spacePoly d B ∧
            ∃ (k : ℕ) (oRat : Fin d → ℚ) (sRat : ℚ)
              (blocks : Fin k → Fin (s₀ d) → ι)
              (lam : Fin k → Fin (s₀ d) → ℚ),
              out.words.read (.heap 0 0) = (k : ℤ) ∧
              (∀ c : Fin d,
                let oNum := out.words.read (.heap 1 (2 * (c.val : ℤ)))
                let oDen := out.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
                0 < oDen ∧ oRat c = (oNum : ℚ) / (oDen : ℚ) ∧
                (intBitLength oNum : ℝ) ≤ bitLenPoly d B ∧
                (intBitLength oDen : ℝ) ≤ bitLenPoly d B ∧
                (ratBitLength (oRat c) : ℝ) ≤ bitLenPoly d B) ∧
              (let sNum := out.words.read (.heap 1 (2 * (d : ℤ)))
               let sDen := out.words.read (.heap 1 (2 * (d : ℤ) + 1))
               0 < sDen ∧ sRat = (sNum : ℚ) / (sDen : ℚ) ∧
               (intBitLength sNum : ℝ) ≤ bitLenPoly d B ∧
               (intBitLength sDen : ℝ) ≤ bitLenPoly d B ∧
               (ratBitLength sRat : ℝ) ≤ bitLenPoly d B) ∧
              (∀ (b : Fin k) (j : Fin (s₀ d)),
                let flatIdx : ℤ := ((b.val * s₀ d + j.val : ℕ) : ℤ)
                (∃ idx : Fin m,
                  out.words.read (.heap 2 flatIdx) = (idx.val : ℤ) ∧
                  blocks b j = (enum idx).1) ∧
                let lamNum := out.words.read (.heap 3 (2 * flatIdx))
                let lamDen := out.words.read (.heap 3 (2 * flatIdx + 1))
                0 < lamDen ∧ lam b j = (lamNum : ℚ) / (lamDen : ℚ) ∧
                (intBitLength lamNum : ℝ) ≤ bitLenPoly d B ∧
                (intBitLength lamDen : ℝ) ≤ bitLenPoly d B ∧
                (ratBitLength (lam b j) : ℝ) ≤ bitLenPoly d B) ∧
              (m : ℝ) / (4 * (s₀ d : ℝ)) ≤ (k : ℝ) ∧
              let z : EuclideanSpace ℝ (Fin (d + 1)) :=
                liftedPoint (ratPointToEuclidean oRat) (sRat : ℝ)
              let blockSet : Fin k → Finset ι :=
                fun b => Finset.univ.image (blocks b)
              (∀ b : Fin k, (blockSet b).card = s₀ d) ∧
              (∀ b₁ b₂ : Fin k, b₁ ≠ b₂ → Disjoint (blockSet b₁) (blockSet b₂)) ∧
              (∀ b : Fin k,
                IsIndexedBlockCertificate (fun i => ratPointToEuclidean (pts i)) P₀ z
                  (blocks b) (fun j => (lam b j : ℝ)) ∧
                IsBlockCertificate (fun i => ratPointToEuclidean (pts i)) P₀ z
                  (blockSet b)
                  (fun i => ∑ j : Fin (s₀ d), if blocks b j = i then (lam b j : ℝ) else 0))

end UL
-- Lemma A.2 statement.
