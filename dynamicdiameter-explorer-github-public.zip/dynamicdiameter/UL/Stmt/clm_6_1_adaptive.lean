import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_6_search_interface
import UL.Def.def_6_search_exponents
import UL.Def.def_6_1_gaussian_filter
set_option autoImplicit false

namespace UL

open Classical in
/-- Claim (Sec. 6.1: One event for all adaptive queries) (paper p.23). Exactly the paper's statement, as a Prop. -/
def S_clm_6_1_adaptive : Prop :=
  ∀ (h_min h_max : ℝ) (hh_min : 0 < h_min) (hh_le : h_min ≤ h_max) (hh_max : h_max < 1)
    (ℓ : ℕ) (hℓ : 1 ≤ ℓ),
    ∃ (C_net C_amp C_poly p_succ : ℝ) (deg : ℕ)
      (roundProg initSeedProg insertBirthPtProg deletePtProg queryProg : ArithRAMStmt),
      0 < C_net ∧ 0 < C_amp ∧ 0 < C_poly ∧ 0 < p_succ ∧ p_succ ≤ 1 ∧
      ∀ (d : ℕ), 1 ≤ d →
      ∀ (a b : ℚ) (g : ℝ) (η : ℚ),
        (0 : ℝ) ≤ (b : ℝ) → (b : ℝ) < (a : ℝ) → (a : ℝ) ≤ 1 →
        0 < g → g ≤ (a : ℝ) - (1 + g) * (b : ℝ) →
        0 < η → (η : ℝ) ≤ g / 16 →
        let h : ℝ := g - 11 * (η : ℝ)
        h_min ≤ h → h ≤ h_max →
        let mesh : ℚ := η / (8 * (Nat.ceil (Real.sqrt (d : ℝ)) : ℚ))
        ∃ (net : Finset (EuclideanSpace ℝ (Fin d)))
          (roundLat : EuclideanSpace ℝ (Fin d) → (Fin d → ℤ))
          (A B : ℚ),
          let roundVec : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
            fun z => ratPointToEuclidean (fun c => (roundLat z c : ℚ) * mesh)
          let roundDir : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
            fun z => ‖roundVec z‖⁻¹ • roundVec z
          net.Nonempty ∧
          (∀ z_hat ∈ net, IsUnitVec z_hat ∧
            ∃ k : Fin d → ℤ, k ≠ 0 ∧
              let v := ratPointToEuclidean (fun c => (k c : ℚ) * mesh)
              z_hat = ‖v‖⁻¹ • v) ∧
          Real.log (net.card : ℝ) ≤ C_net * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ∧
          (∀ z : EuclideanSpace ℝ (Fin d), IsUnitVec z →
            roundLat z ≠ 0 ∧
            roundDir z ∈ net ∧
            ‖roundDir z - z‖ ≤ (η : ℝ) / 8 ∧
            let inp_round : ArithRAMInput d :=
              { intParams := [η.num, (η.den : ℤ)]
                activeHandles := ∅
                activeCoords := fun _ => 0
                extraReals := List.ofFn (fun c : Fin d => euclideanCoord z c) }
            ∃ out_r : ArithRAMExecOutcome,
              runArithRAMWithBits roundProg inp_round ArithRAMMemory.empty [] = some out_r ∧
              (∀ c : Fin d, out_r.mem.words.read (.heap 0 (c.val : ℤ)) = roundLat z c) ∧
              (out_r.unitCost : ℝ) ≤ C_net * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ∧
              (out_r.peakCellSpace : ℝ) ≤ C_net * (d : ℝ)) ∧
          let padData : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
            fun u => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u)) (B : ℝ))
          let padQuery : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
            fun z_hat => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • z_hat)) (-(B : ℝ)))
          0 < A ∧ 0 ≤ B ∧ A ^ 2 + B ^ 2 = 1 ∧
          (∀ u z z_hat : EuclideanSpace ℝ (Fin d),
            IsUnitVec u → IsUnitVec z → IsUnitVec z_hat →
            ‖z_hat - z‖ ≤ (η : ℝ) / 8 →
              IsUnitVec (padData u) ∧
              IsUnitVec (padQuery z_hat) ∧
              ((a : ℝ) ≤ inner ℝ z u → h ≤ inner ℝ (padQuery z_hat) (padData u)) ∧
              (inner ℝ z u ≤ (b : ℝ) → inner ℝ (padQuery z_hat) (padData u) < 0)) ∧
          ∀ (x : ℝ), h ≤ x → x ≤ 1 →
          ∀ (ε₀ : ℝ), 0 < ε₀ → ε₀ < 1 / 2 →
          ∀ (m : ℕ), 1 ≤ m →
            let u_exp : ℝ := u_search h x
            let q_exp : ℝ := q_search h x
            let I_exp : ℝ := I_h h x
            let P_factor : ℝ := C_poly * ((d : ℝ) + Real.log (2 * (m : ℝ))) ^ deg
            ∃ (R N_caps : ℕ),
              1 ≤ R ∧
              (R : ℝ) ≤ C_amp * (Real.log ((m : ℝ) / ε₀) + (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) ∧
              1 ≤ N_caps ∧
              let CopySeed : Type := Fin N_caps → EuclideanSpace ℝ (Fin (d + 1))
              let copyMeasure : MeasureTheory.Measure CopySeed :=
                MeasureTheory.Measure.pi (fun _ : Fin N_caps => stdGaussianMeasure (d + 1))
              let SeedSpace : Type := Fin R → CopySeed
              let seedMeasure : MeasureTheory.Measure SeedSpace :=
                MeasureTheory.Measure.pi (fun _ : Fin R => copyMeasure)
              let dataWorkBound : ℝ :=
                (R : ℝ) * ((m : ℝ) ^ u_exp + (m : ℝ) ^ (I_exp / (ℓ : ℝ))) * P_factor
              let queryWorkBound : ℝ :=
                (R : ℝ) * ((m : ℝ) ^ q_exp + (m : ℝ) ^ (I_exp / (ℓ : ℝ))) * P_factor
              let spaceBound : ℝ :=
                (R : ℝ) * ((m : ℝ) ^ (1 + u_exp) + (m : ℝ) ^ (I_exp / (ℓ : ℝ))) * P_factor
              let inp_seed : SeedSpace → ArithRAMInput d := fun ω =>
                { intParams :=
                    [(m : ℤ), (ℓ : ℤ), (R : ℤ), (N_caps : ℤ),
                     a.num, (a.den : ℤ), b.num, (b.den : ℤ), η.num, (η.den : ℤ)]
                  activeHandles := ∅
                  activeCoords := fun _ => 0
                  extraReals :=
                    [g, x] ++
                      (List.finRange R).flatMap (fun r =>
                        (List.finRange N_caps).flatMap (fun c =>
                          List.ofFn (fun coord : Fin (d + 1) => euclideanCoord (ω r c) coord))) }
              ∀ (ι : Type) [DecidableEq ι] (P₀ : Finset ι), P₀.card = m →
              ∀ (u_pts : ι → EuclideanSpace ℝ (Fin d)), (∀ i ∈ P₀, IsUnitVec (u_pts i)) →
                let padPts : ι → EuclideanSpace ℝ (Fin (d + 1)) := fun i => padData (u_pts i)
                ∃ (dec : Fin m → ι)
                  (builtMem : SeedSpace → ArithRAMMemory)
                  (goodSingle : EuclideanSpace ℝ (Fin d) → ι → Set CopySeed),
                  (∀ j : Fin m, dec j ∈ P₀) ∧
                  Function.Injective dec ∧
                  (∀ z_hat ∈ net, ∀ i_star ∈ P₀,
                    MeasurableSet (goodSingle z_hat i_star) ∧
                    (h ≤ inner ℝ (padPts i_star) (padQuery z_hat) →
                      p_succ ≤ copyMeasure.real (goodSingle z_hat i_star))) ∧
                  let E : Set SeedSpace :=
                    {ω | ∀ z_hat ∈ net, ∀ i_star ∈ P₀, ∃ r : Fin R, ω r ∈ goodSingle z_hat i_star}
                  let activeCoords : ℕ → EuclideanSpace ℝ (Fin d) :=
                    fun h_idx => if hh : h_idx < m then u_pts (dec ⟨h_idx, hh⟩) else 0
                  MeasurableSet E ∧
                  1 - ε₀ ≤ seedMeasure.real E ∧
                  (∀ ω : SeedSpace,
                    (∃ (out₀ : ArithRAMExecOutcome) (buildMems : Fin (m + 1) → ArithRAMMemory),
                      runArithRAMWithBits initSeedProg (inp_seed ω) ArithRAMMemory.empty [] =
                        some out₀ ∧
                      (out₀.unitCost : ℝ) ≤ dataWorkBound ∧
                      (out₀.peakCellSpace : ℝ) ≤ spaceBound ∧
                      (out₀.mem.cellCount : ℝ) ≤ spaceBound ∧
                      buildMems 0 = out₀.mem ∧
                      buildMems (Fin.last m) = builtMem ω ∧
                      ∀ j : Fin m,
                        let inp_ins : ArithRAMInput d :=
                          { intParams := [(j.val : ℤ)]
                            activeHandles := Finset.range (j.val + 1)
                            activeCoords := activeCoords
                            extraReals := [] }
                        ∃ out_ins : ArithRAMExecOutcome,
                          runArithRAMWithBits insertBirthPtProg inp_ins (buildMems j.castSucc) [] =
                            some out_ins ∧
                          out_ins.mem = buildMems j.succ ∧
                          (out_ins.unitCost : ℝ) ≤ dataWorkBound ∧
                          (out_ins.peakCellSpace : ℝ) ≤ spaceBound ∧
                          (out_ins.mem.cellCount : ℝ) ≤ spaceBound) ∧
                    (∀ ops : List (Fin m ⊕ (EuclideanSpace ℝ (Fin d) × (ι → Prop))),
                      (ops.filterMap (fun op =>
                        match op with
                        | Sum.inl j => some j
                        | Sum.inr _ => none)).Nodup →
                      (∀ op ∈ ops, ∀ z accept, op = Sum.inr (z, accept) → IsUnitVec z) →
                      ∃ execMems : Fin (ops.length + 1) → ArithRAMMemory,
                        execMems 0 = builtMem ω ∧
                        ∀ s : Fin ops.length,
                          let deletedBefore : List (Fin m) :=
                            (ops.take s.val).filterMap (fun op =>
                              match op with
                              | Sum.inl j => some j
                              | Sum.inr _ => none)
                          let curFinHandles : Finset (Fin m) :=
                            Finset.univ.filter (fun j => j ∉ deletedBefore)
                          let curHandles : Finset ℕ := curFinHandles.image Fin.val
                          let P : Finset ι := curFinHandles.image dec
                          match ops[s] with
                          | Sum.inl j =>
                              let inp_del : ArithRAMInput d :=
                                { intParams := [(j.val : ℤ)]
                                  activeHandles := curHandles.erase j.val
                                  activeCoords := activeCoords
                                  extraReals := [] }
                              ∃ out_del : ArithRAMExecOutcome,
                                runArithRAMWithBits deletePtProg inp_del (execMems s.castSucc) [] =
                                  some out_del ∧
                                out_del.mem = execMems s.succ ∧
                                (out_del.unitCost : ℝ) ≤ dataWorkBound ∧
                                (out_del.peakCellSpace : ℝ) ≤ spaceBound ∧
                                (out_del.mem.cellCount : ℝ) ≤ spaceBound
                          | Sum.inr (z, accept) =>
                              let inp_q : ArithRAMInput d :=
                                { intParams := List.ofFn (fun j : Fin m =>
                                    if accept (dec j) then (1 : ℤ) else 0)
                                  activeHandles := curHandles
                                  activeCoords := activeCoords
                                  extraReals := List.ofFn (fun c : Fin d => euclideanCoord z c) }
                              ∃ out_q : ArithRAMExecOutcome,
                                runArithRAMWithBits queryProg inp_q (execMems s.castSucc) [] =
                                  some out_q ∧
                                out_q.mem = execMems s.succ ∧
                                (out_q.unitCost : ℝ) ≤ queryWorkBound ∧
                                (out_q.peakCellSpace : ℝ) ≤ spaceBound ∧
                                (out_q.mem.cellCount : ℝ) ≤ spaceBound ∧
                                let rawAns : ℤ := out_q.mem.words.read (.heap 0 0)
                                let ans : Option ι :=
                                  if h_ans : 0 ≤ rawAns ∧ rawAns.toNat < m then
                                    some (dec ⟨rawAns.toNat, h_ans.2⟩)
                                  else
                                    none
                                IsValidSearchAnswer P accept ans ∧
                                (ω ∈ E →
                                  IsCompatibleTest padPts P (padQuery (roundDir z)) accept →
                                  IsCorrectSearchAnswer padPts P h (padQuery (roundDir z)) accept ans) ∧
                                (ω ∈ E →
                                  (∀ i ∈ P, ¬ accept i → inner ℝ z (u_pts i) ≤ (b : ℝ)) →
                                  ans = none →
                                  ∀ i ∈ P, inner ℝ z (u_pts i) < (a : ℝ))))

end UL
