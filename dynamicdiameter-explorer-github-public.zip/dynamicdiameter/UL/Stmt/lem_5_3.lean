import Mathlib
import UL.Def.def_node_chain_blocks
import UL.Def.def_node_baseline
import UL.Def.def_local_scale_params
set_option autoImplicit false

namespace UL

/-- Lemma 5.3 (paper p.17). Exactly the paper's statement, as a Prop. -/
def S_lem_5_3 : Prop :=
  ∀ (d : ℕ) (ι : Type)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d))
    (V : ℝ)
    (S : Finset ι)
    (L : ℝ)
    (c : ℝ)
    (K : ℤ)
    (hV : 0 ≤ V)
    (hL : SatisfiesBaselineLengthCond pts o V S L)
    (hc_gt : 1 < c)
    (hc_lt : c < Real.sqrt 2)
    (hK : 2 / (c - 1) ≤ (K : ℝ))
    (h_range : V = 0 ∨ nodeMaxRadius pts o S > (K : ℝ) * Real.sqrt V),
    nodeCoreInputDiam pts o V S < c * L ∨
      (nodeCoreInputDiam pts o V S = 0 ∧ L = 0)

end UL
