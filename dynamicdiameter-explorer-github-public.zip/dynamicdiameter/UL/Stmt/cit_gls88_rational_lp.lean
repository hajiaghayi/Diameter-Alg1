import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_A_convex_hull_cert
set_option autoImplicit false

namespace UL

/-- Polynomial-Time Exact Rational Linear Programming [GLS88] (paper p.45). Exactly the paper's statement, as a Prop. -/
def S_cit_gls88_rational_lp : Prop :=
  -- (1) General exact rational linear feasibility programming [GLS88]:
  -- decides feasibility of rational linear equality/inequality systems and, when feasible,
  -- returns an exact rational solution in time, workspace, and output bit length polynomial
  -- in the number of variables, constraints, and maximum input entry bit length.
  (∃ (progLP : BitRAMStmt) (C deg : ℕ),
    ∀ (nVars nEq nLe B : ℕ)
      (A_eq : Fin nEq → Fin nVars → ℚ) (b_eq : Fin nEq → ℚ)
      (A_le : Fin nLe → Fin nVars → ℚ) (b_le : Fin nLe → ℚ),
      (∀ (i : Fin nEq) (j : Fin nVars), RatCoordBitBounded B (A_eq i j)) →
      (∀ i : Fin nEq, RatCoordBitBounded B (b_eq i)) →
      (∀ (i : Fin nLe) (j : Fin nVars), RatCoordBitBounded B (A_le i j)) →
      (∀ i : Fin nLe, RatCoordBitBounded B (b_le i)) →
      let eqRows : List ℚ :=
        (List.finRange nEq).flatMap (fun i => List.ofFn (A_eq i) ++ [b_eq i])
      let leRows : List ℚ :=
        (List.finRange nLe).flatMap (fun i => List.ofFn (A_le i) ++ [b_le i])
      let inp : BitRAMInput 0 :=
        { intParams := [(nVars : ℤ), (nEq : ℤ), (nLe : ℤ)]
          activeHandles := ∅
          activeRatCoords := fun _ k => Fin.elim0 k
          extraRats := eqRows ++ leRows }
      let bound : ℕ := C * (nVars + nEq + nLe + B + 1) ^ deg
      ∃ out : BitRAMExecOutcome,
        runBitRAMWithBits progLP inp WordStore.empty [] = some out ∧
        out.unitCost ≤ bound ∧
        out.bitCost ≤ bound ∧
        out.peakCellSpace ≤ bound ∧
        out.peakBitSpace ≤ bound ∧
        let flag : ℤ := out.words.read (.heap 0 0)
        (flag = 0 ∨ flag = 1) ∧
        (flag = 1 ↔
          ∃ x : Fin nVars → ℝ,
            (∀ i : Fin nEq, ∑ j : Fin nVars, (A_eq i j : ℝ) * x j = (b_eq i : ℝ)) ∧
            (∀ i : Fin nLe, ∑ j : Fin nVars, (A_le i j : ℝ) * x j ≤ (b_le i : ℝ))) ∧
        (flag = 1 →
          let solNum : Fin nVars → ℤ := fun j => out.words.read (.heap 1 (2 * (j.val : ℤ)))
          let solDen : Fin nVars → ℤ := fun j => out.words.read (.heap 1 (2 * (j.val : ℤ) + 1))
          let xRat : Fin nVars → ℚ := fun j => (solNum j : ℚ) / (solDen j : ℚ)
          (∀ j : Fin nVars,
            0 < solDen j ∧
            intBitLength (solNum j) ≤ bound ∧
            intBitLength (solDen j) ≤ bound ∧
            RatCoordBitBounded bound (xRat j) ∧
            ratBitLength (xRat j) ≤ bound) ∧
          (∀ i : Fin nEq, ∑ j : Fin nVars, A_eq i j * xRat j = b_eq i) ∧
          (∀ i : Fin nLe, ∑ j : Fin nVars, A_le i j * xRat j ≤ b_le i))) ∧
  -- (2) Common convex-hull point LP (9) (paper p.44–45):
  -- z = ∑_{j=1}^s λ_{ij} p_{ij}, ∑_{j=1}^s λ_{ij} = 1, λ_{ij} ≥ 0 (1 ≤ i ≤ r).
  (∃ (progHull : BitRAMStmt) (C deg : ℕ),
    ∀ (D r s B : ℕ) (pts : Fin r → Fin s → Fin D → ℚ),
      (∀ (i : Fin r) (j : Fin s), RatPointBitBounded B (pts i j)) →
      let flatPts : List ℚ :=
        (List.finRange r).flatMap (fun i =>
          (List.finRange s).flatMap (fun j => List.ofFn (pts i j)))
      let inp : BitRAMInput 0 :=
        { intParams := [(D : ℤ), (r : ℤ), (s : ℤ)]
          activeHandles := ∅
          activeRatCoords := fun _ k => Fin.elim0 k
          extraRats := flatPts }
      let bound : ℕ := C * (D + r + s + B + 1) ^ deg
      ∃ out : BitRAMExecOutcome,
        runBitRAMWithBits progHull inp WordStore.empty [] = some out ∧
        out.unitCost ≤ bound ∧
        out.bitCost ≤ bound ∧
        out.peakCellSpace ≤ bound ∧
        out.peakBitSpace ≤ bound ∧
        let flag : ℤ := out.words.read (.heap 0 0)
        (flag = 0 ∨ flag = 1) ∧
        (flag = 1 ↔
          ∃ z : EuclideanSpace ℝ (Fin D),
            ∀ i : Fin r,
              HasConvexHullCert (fun j : Fin s => ratPointToEuclidean (pts i j)) z) ∧
        (flag = 1 →
          let zNum : Fin D → ℤ := fun k => out.words.read (.heap 1 (2 * (k.val : ℤ)))
          let zDen : Fin D → ℤ := fun k => out.words.read (.heap 1 (2 * (k.val : ℤ) + 1))
          let zRat : Fin D → ℚ := fun k => (zNum k : ℚ) / (zDen k : ℚ)
          let lamNum : Fin r → Fin s → ℤ :=
            fun i j => out.words.read (.heap 2 (2 * ((i.val * s + j.val : ℕ) : ℤ)))
          let lamDen : Fin r → Fin s → ℤ :=
            fun i j => out.words.read (.heap 2 (2 * ((i.val * s + j.val : ℕ) : ℤ) + 1))
          let lam : Fin r → Fin s → ℚ := fun i j => (lamNum i j : ℚ) / (lamDen i j : ℚ)
          RatPointBitBounded bound zRat ∧
          (∀ k : Fin D,
            0 < zDen k ∧
            intBitLength (zNum k) ≤ bound ∧
            intBitLength (zDen k) ≤ bound ∧
            ratBitLength (zRat k) ≤ bound) ∧
          (∀ (i : Fin r) (j : Fin s),
            0 < lamDen i j ∧
            intBitLength (lamNum i j) ≤ bound ∧
            intBitLength (lamDen i j) ≤ bound ∧
            RatCoordBitBounded bound (lam i j) ∧
            ratBitLength (lam i j) ≤ bound) ∧
          (∀ i : Fin r,
            IsConvexHullCert (fun j : Fin s => ratPointToEuclidean (pts i j))
              (ratPointToEuclidean zRat) (fun j : Fin s => (lam i j : ℝ))))) ∧
  -- (3) Single-block convex-hull certificate LP for a fixed rational target z ∈ ℚ^D (paper p.46):
  -- ∑_{j=1}^s λ_j p_j = z, ∑_{j=1}^s λ_j = 1, λ_j ≥ 0.
  (∃ (progCert : BitRAMStmt) (C deg : ℕ),
    ∀ (D s B : ℕ) (pts : Fin s → Fin D → ℚ) (zRat : Fin D → ℚ),
      (∀ j : Fin s, RatPointBitBounded B (pts j)) →
      RatPointBitBounded B zRat →
      let flatPts : List ℚ :=
        (List.finRange s).flatMap (fun j => List.ofFn (pts j))
      let inp : BitRAMInput 0 :=
        { intParams := [(D : ℤ), (s : ℤ)]
          activeHandles := ∅
          activeRatCoords := fun _ k => Fin.elim0 k
          extraRats := List.ofFn zRat ++ flatPts }
      let bound : ℕ := C * (D + s + B + 1) ^ deg
      ∃ out : BitRAMExecOutcome,
        runBitRAMWithBits progCert inp WordStore.empty [] = some out ∧
        out.unitCost ≤ bound ∧
        out.bitCost ≤ bound ∧
        out.peakCellSpace ≤ bound ∧
        out.peakBitSpace ≤ bound ∧
        let flag : ℤ := out.words.read (.heap 0 0)
        (flag = 0 ∨ flag = 1) ∧
        (flag = 1 ↔
          HasConvexHullCert (fun j : Fin s => ratPointToEuclidean (pts j))
            (ratPointToEuclidean zRat)) ∧
        (flag = 1 →
          let lamNum : Fin s → ℤ := fun j => out.words.read (.heap 1 (2 * (j.val : ℤ)))
          let lamDen : Fin s → ℤ := fun j => out.words.read (.heap 1 (2 * (j.val : ℤ) + 1))
          let lam : Fin s → ℚ := fun j => (lamNum j : ℚ) / (lamDen j : ℚ)
          (∀ j : Fin s,
            0 < lamDen j ∧
            intBitLength (lamNum j) ≤ bound ∧
            intBitLength (lamDen j) ≤ bound ∧
            RatCoordBitBounded bound (lam j) ∧
            ratBitLength (lam j) ≤ bound) ∧
          IsConvexHullCert (fun j : Fin s => ratPointToEuclidean (pts j))
            (ratPointToEuclidean zRat) (fun j : Fin s => (lam j : ℝ))))

end UL
