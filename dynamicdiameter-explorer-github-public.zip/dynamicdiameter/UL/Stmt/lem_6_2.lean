import Mathlib
import UL.Def.def_6_search_exponents
import UL.Def.def_6_1_gaussian_filter
set_option autoImplicit false

namespace UL

/-- Lemma 6.2 (paper p.22). Exactly the paper's statement, as a Prop. -/
def S_lem_6_2 : Prop :=
  ∀ (h_min h_max : ℝ) (hh_min : 0 < h_min) (hh_le : h_min ≤ h_max) (hh_max : h_max < 1),
    ∃ c_h : ℝ, 0 < c_h ∧
      ∀ (d : ℕ), 1 ≤ d →
        ∀ (h x t : ℝ), h_min ≤ h → h ≤ h_max → h ≤ x → x ≤ 1 → 1 ≤ t →
          ∃ p_u p_q p₁ p₂ : ℝ,
            IsGaussianFilterProbs d h x t p_u p_q p₁ p₂ ∧
            p_u ≤ Real.exp (-(t ^ 2 / 2)) ∧
            p_q ≤ Real.exp (-(x ^ 2 * t ^ 2 / 2)) ∧
            c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2)) ≤ p₁ ∧
            p₂ ≤ Real.exp (-((1 + x ^ 2) * t ^ 2 / 2))

end UL
