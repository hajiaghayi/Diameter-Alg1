import Mathlib
import UL.Def.def_explicit_tradeoff_curve
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_local_scale_params
import UL.Def.def_shells_configurations
import UL.Def.def_6_search_exponents
import UL.Def.def_9_parameters
set_option autoImplicit false

namespace UL

/-- Lemma 9.1 (paper p.39). Exactly the paper's statement, as a Prop. -/
def S_lem_9_1 : Prop :=
  ∀ (c : ℝ) (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2),
    ∃ (C_shell C_cfg C_h C_q h_min : ℝ),
      0 ≤ C_shell ∧
      0 ≤ C_cfg ∧
      0 ≤ C_h ∧
      0 ≤ C_q ∧
      0 < h_min ∧
      h_min ≤ g_c c ∧
      ∀ (n : ℕ), 2 ≤ n →
        let L : ℕ := L_n n
        ∀ (σ : ℝ), 0 ≤ σ → σ ≤ rho_c c →
          ∃ (params : LocalScaleParams) (h x : ℚ),
            params.c = c ∧
            (params.m0 : ℝ) ≤ C_shell * (L : ℝ) ∧
            (params.maxShellIndex : ℝ) ≤ C_shell * (L : ℝ) ∧
            ((params.J + 1 : ℕ) : ℝ) ≤ C_shell * (L : ℝ) ∧
            ((allShellConfigs params.m0 params.K params.J).card : ℝ) ≤ C_cfg * (L : ℝ) ^ 3 ∧
            (∀ V : ℝ, ((params.retainedConfigs V).card : ℝ) ≤ C_cfg * (L : ℝ) ^ 3) ∧
            (params.e : ℝ) ≤ ((params.γ : ℝ) ^ 2 - 1) / 16 ∧
            (h : ℝ) = ((params.γ : ℝ) ^ 2 - 1) - 11 * (params.e : ℝ) ∧
            h_min ≤ (h : ℝ) ∧
            (h : ℝ) ≤ g_c c ∧
            g_c c - (h : ℝ) ≤ C_h / (L : ℝ) ∧
            (∀ (V : ℝ), 0 < V →
              ∀ cfg ∈ params.retainedConfigs V,
                ∃ (A B : ℚ),
                  0 < A ∧
                  0 ≤ B ∧
                  A ^ 2 + B ^ 2 = 1 ∧
                  ∀ (d : ℕ) (u z z_bar : EuclideanSpace ℝ (Fin d)),
                    ‖u‖ = 1 →
                    ‖z‖ = 1 →
                    ‖z_bar‖ = 1 →
                    ‖z_bar - z‖ ≤ (params.e : ℝ) / 8 →
                    (params.thresholdA V cfg.j cfg.k cfg.ℓ ≤ inner ℝ z u →
                      (h : ℝ) ≤ inner ℝ
                        (liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ)))
                        (liftedPoint ((A : ℝ) • u) (B : ℝ))) ∧
                    (inner ℝ z u ≤ params.thresholdB V cfg.j cfg.k cfg.ℓ →
                      inner ℝ
                        (liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ)))
                        (liftedPoint ((A : ℝ) • u) (B : ℝ)) < 0)) ∧
            (h : ℝ) ≤ (x : ℝ) ∧
            (x : ℝ) ≤ 1 ∧
            u_search (h : ℝ) (x : ℝ) ≤ σ ∧
            q_search (h : ℝ) (x : ℝ) ≤ Q_c c σ + C_q / (L : ℝ)

end UL
