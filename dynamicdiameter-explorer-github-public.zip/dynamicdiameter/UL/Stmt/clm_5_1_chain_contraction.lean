import Mathlib
import UL.Def.def_core_witness_halfspaces
import UL.Def.def_node_chain_blocks
set_option autoImplicit false

namespace UL

/-- Claim (Sec. 5.1: Node core retention and chain contraction) (paper p.16). Exactly the paper's statement, as a Prop. -/
def S_clm_5_1_chain_contraction : Prop :=
  ∃ (c₁ C_nodes : ℝ), 0 < c₁ ∧ 0 < C_nodes ∧
    ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ), 0 < α → α ≤ 1 →
      (∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
        ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
          ∀ (age : ℕ), HasNodeAge P₀ S age →
            (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
            let V := liftVariance o s
            let C := nodeCore pts o V S
            let child := nodeResidual pts o V S
            let m : ℝ := P₀.card
            15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
            (S.card : ℝ) ≤ (1 + α / 16) * m ∧
            (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ)) ∧
      (∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
        (∀ (k : ℕ) (nodes : Fin k → ChainNode d)
            (P₀ : Fin k → Finset ι)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
            (age : Fin k → ℕ),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
          (∀ j : Fin (k + 1),
            ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
          ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
          (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1)) ∧
        (∀ (L_leaf : ℕ),
          (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
            ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
              IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
          ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
            (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) ∧
            (∀ i : Fin k,
              L_leaf < (chainInput pts nodes P i.castSucc).card ∧
              (nodes i).o = o i ∧
              (nodes i).V = liftVariance (o i) (s i) ∧
              IsCenterpoint α
                (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
                (liftedPoint (o i) (s i))) ∧
            (chainTerminal pts nodes P).card ≤ L_leaf ∧
            (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2))

end UL
