import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
set_option autoImplicit false

namespace UL

/-- Theorem 1.1 (paper p.3). Exactly the paper's statement, as a Prop. -/
def S_thm_1_1 : Prop :=
  ∀ (c : ℝ) (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2),
    ∃ (polyTime polySpace : ℕ → ℕ → ℝ) (queryConst writeFactor : ℕ),
      IsBoundedByPoly2 polyTime ∧
      IsBoundedByPoly2 polySpace ∧
      ∀ (d n t : ℕ) (δ : ℝ),
        2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
          ∃ (prog : ArithRAMDynamicProgram) (initOut : ArithRAMExecOutcome),
            prog.evalInit n d = some initOut ∧
            let logTerm : ℕ := Nat.ceil (Real.log (2 * (n : ℝ) * (t : ℝ) / δ))
            let alg : DynamicDiameterStructure d ArithRAMMemory :=
              { initState := initOut.mem
                initWork := initOut.unitCost
                initSpace := initOut.peakCellSpace
                cachedAnswer := fun mem =>
                  let ans := ArithRAMDynamicProgram.readCachedAnswer mem
                  { diameterHandles := ans.1, cachedDistSq := ans.2 }
                retrieveIdsAndRefCost := 4
                writeOutputCost := fun outLen => outLen + 1
                stepWithBits := fun activeH hCoords mem uop bs =>
                  match uop with
                  | .insert pt =>
                      (prog.evalUpdate n activeH hCoords mem true pt 0 bs).map (fun stepOut =>
                        let ans := ArithRAMDynamicProgram.readCachedAnswer stepOut.mem
                        { nextState := stepOut.mem
                          returnedHandle := ArithRAMDynamicProgram.readReturnedHandle stepOut.mem
                          storedAnswer := { diameterHandles := ans.1, cachedDistSq := ans.2 }
                          work := stepOut.unitCost
                          peakSpace := stepOut.peakCellSpace })
                  | .delete h =>
                      (prog.evalUpdate n activeH hCoords mem false 0 h bs).map (fun stepOut =>
                        let ans := ArithRAMDynamicProgram.readCachedAnswer stepOut.mem
                        { nextState := stepOut.mem
                          returnedHandle := none
                          storedAnswer := { diameterHandles := ans.1, cachedDistSq := ans.2 }
                          work := stepOut.unitCost
                          peakSpace := stepOut.peakCellSpace }) }
            SatisfiesDynamicStorageAndQueryModel queryConst writeFactor alg ∧
            SatisfiesMonteCarloGuarantee n t δ c Set.univ alg ∧
            SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg
              (((n : ℝ) ^ (2 / c ^ 2 - 1)) * polyTime d logTerm) ∧
            SatisfiesBoundedSpaceBound n t Set.univ alg
              (((n : ℝ) ^ (2 / c ^ 2)) * polySpace d logTerm)

end UL
