import Mathlib
import UL.Def.def_dynamic_points_model
import UL.Def.def_computation_model
import UL.Def.def_node_chain_blocks
import UL.Def.def_C_2_schedule
import UL.Def.def_alg_4
set_option autoImplicit false

namespace UL

/-! ### Helper definitions for Section 7.2 chain replacement schedule and two-scan invariance -/

/-- Polynomial upper bound `F d α logs ≤ C_poly * (α⁻¹ + 1)^deg * (d + 1)^deg * (1 + ∑ max 0 l)^deg`
in `α⁻¹`, ambient dimension `d`, and a finite list `logs : List ℝ` of logarithmic parameters. -/
def IsPolyInAlphaInvDimLogs (F : ℕ → ℝ → List ℝ → ℝ) : Prop :=
  ∃ (C_poly : ℝ) (deg : ℕ), 0 ≤ C_poly ∧
    ∀ (d : ℕ) (α : ℝ) (logs : List ℝ),
      0 < α → α < 1 →
        F d α logs ≤
          C_poly * ((α⁻¹ + 1) ^ deg) * ((d + 1 : ℝ) ^ deg) *
            ((1 + (logs.map (max 0)).sum) ^ deg)

/-- Initial state of an `Alg4OpenedLevel` when opened on birth snapshot `S_0` with fixed ball
`ball` under `mode : Alg4Mode` (matching `alg4Line5LateOpeningGate`). -/
def initAlg4OpenedLevel {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (S_0 : Finset ι) (ball : ChainNode d) : Alg4OpenedLevel d ι :=
  { birthSnapshot := S_0
    ball := ball
    indexMode := mode.backgroundIndexMode
    backgroundReady := false
    trueInputAge := 0
    elapsedRootTicks := 0
    scan2Snapshot := S_0
    heapIndexedIds := ∅
    classifiedIds := ∅
    radiusDict := RadiusDictState.empty ι
    localMatchings := fun _ => LocalMatchingState.empty ι }

open Classical in
/-- Single arrival-routing step on an `Alg4OpenedLevel` under `ev : PoolUpdateEvent ι` (matching
`alg4Line3RoutePrefixAux` in Line 3 of Algorithm 4): arriving insertions are indexed and classified
immediately; arriving deletions remove an identity from `radiusDict` iff heap-indexed and from
`localMatchings` / `classifiedIds` iff already classified. -/
noncomputable def applyOpenedLevelArrival {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (lv : Alg4OpenedLevel d ι) (ev : PoolUpdateEvent ι)
    (qAns : NodeMatchingQueryAnswers ι) (mHint : Option ι) : Alg4OpenedLevel d ι :=
  match ev with
  | .externalInsert p =>
      let rDict' := updateRadiusDictOnEvent pts lv.ball.o lv.radiusDict ev mHint
      let cls' := insert p lv.classifiedIds
      let lm' := applyNodeMatchingInsert pts mode lv.ball lv.localMatchings p qAns
      { lv with
        trueInputAge := lv.trueInputAge + 1
        heapIndexedIds := rDict'.indexedIds
        classifiedIds := cls'
        radiusDict := rDict'
        localMatchings := lm' }
  | .externalDelete p =>
      let rDict' := updateRadiusDictOnEvent pts lv.ball.o lv.radiusDict ev mHint
      let cls' := lv.classifiedIds.erase p
      let lm' :=
        if p ∈ lv.classifiedIds then
          applyNodeMatchingDelete pts mode lv.ball lv.localMatchings p qAns
        else
          lv.localMatchings
      { lv with
        trueInputAge := lv.trueInputAge + 1
        heapIndexedIds := rDict'.indexedIds
        classifiedIds := cls'
        radiusDict := rDict'
        localMatchings := lm' }
  | .virtualValueDelete => lv
  | .unaffected => lv

open Classical in
/-- Single root-tick two-scan construction step on an `Alg4OpenedLevel` over current input `S_lv`
(matching `stepPrefixConstruction` in Line 4 of Algorithm 4). -/
noncomputable def stepOpenedLevelBuild {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (S_lv : Finset ι) (lv : Alg4OpenedLevel d ι)
    (bChoice : PendingLevelBudgetChoices ι) : Alg4OpenedLevel d ι :=
  if lv.backgroundReady then
    { lv with elapsedRootTicks := lv.elapsedRootTicks + 1 }
  else
    let rDict' :=
      scan1RadiusDictBatch pts lv.ball.o S_lv lv.radiusDict
        (bChoice.scan1Batch ∩ lv.birthSnapshot) bChoice.scanMaxHint
    let (cls', lm') :=
      applyScan2Batch pts mode lv.ball S_lv lv.scan2Snapshot
        lv.classifiedIds lv.localMatchings bChoice.scan2Steps
    let scansDone : Bool :=
      decide (S_lv ⊆ rDict'.indexedIds) && decide (S_lv ⊆ cls')
    { lv with
      elapsedRootTicks := lv.elapsedRootTicks + 1
      heapIndexedIds := rDict'.indexedIds
      classifiedIds := cls'
      radiusDict := rDict'
      localMatchings := lm'
      backgroundReady := scansDone && bChoice.backgroundIndexesReady }

/-- Equation (11) background-completion property on one step of Algorithm 4: after Lines 2–6, every
opened pending level whose elapsed root-pool ticks have reached `maxLevelBuildTicks α m` has
completed background construction (`backgroundReady = true`). -/
def ChainSchedEq11Step {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (st : Alg4State d ι) (upd : Alg4PointUpdate d ι)
    (choices : Alg4StepChoices d ι) : Prop :=
  let P' := applyAlg4PointSetUpdate st.activeSet upd
  let pts' := updateAlg4Coords st.coords upd
  let (nodesLine1, _, _) :=
    alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints
  let nodesLines2To6 :=
    alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
  ∀ p ∈ nodesLines2To6, ∀ job : Alg4PendingJob d ι,
    p.1.ownedJob = some job →
    ∀ lv ∈ job.completedPrefix,
      maxLevelBuildTicks α lv.birthSnapshot.card ≤ lv.elapsedRootTicks →
        lv.backgroundReady = true

/-- Agreement of two `Alg4StepChoices` bundles on all fields except `prefixBudgetSteps` inside
`pendingJobChoices`. -/
def ChainSchedChoicesAgreeOnNonBudget {d : ℕ} {ι : Type}
    (base chosen : Alg4StepChoices d ι) : Prop :=
  chosen.servingRouteQueries = base.servingRouteQueries ∧
  chosen.servingRadiusMaxHints = base.servingRadiusMaxHints ∧
  chosen.leafRebuildChoices = base.leafRebuildChoices ∧
  chosen.terminalLeafHint = base.terminalLeafHint ∧
  chosen.baselineSamples = base.baselineSamples ∧
  chosen.matchingMaxHints = base.matchingMaxHints ∧
  chosen.distinctPairHint = base.distinctPairHint ∧
  chosen.stepExtraRetired = base.stepExtraRetired ∧
  chosen.stepAllocatedRecords = base.stepAllocatedRecords ∧
  ∀ i : Fin base.pendingJobChoices.length,
    ∃ jc : PendingJobStepChoices d ι,
      chosen.pendingJobChoices[i.val]? = some jc ∧
      jc.prefixRouteQueries = (base.pendingJobChoices[i]).prefixRouteQueries ∧
      jc.prefixRouteMaxHints = (base.pendingJobChoices[i]).prefixRouteMaxHints ∧
      jc.openSampledCenter = (base.pendingJobChoices[i]).openSampledCenter ∧
      jc.openFallbackBirthId = (base.pendingJobChoices[i]).openFallbackBirthId ∧
      jc.leafHint = (base.pendingJobChoices[i]).leafHint

/-- Per-tick scan batch bound `K_batch` on every `PendingLevelBudgetChoices` inside `choices`. -/
def ChainSchedScanBatchCap {d : ℕ} {ι : Type}
    (K_batch : ℕ) (choices : Alg4StepChoices d ι) : Prop :=
  ∀ jc ∈ choices.pendingJobChoices,
    ∀ bStep ∈ jc.prefixBudgetSteps,
      bStep.scan1Batch.card ≤ K_batch ∧ bStep.scan2Steps.length ≤ K_batch

/-- Number of serving nodes in `st : Alg4State d ι` that currently own a pending replacement job. -/
def Alg4State.owningReplacementJobCount {d : ℕ} {ι : Type} (st : Alg4State d ι) : ℕ :=
  (st.servingNodes.filter (fun sn => sn.ownedJob.isSome)).length

/-- Total number of serving and pending chain nodes in `st : Alg4State d ι` (all active serving
nodes plus all opened levels inside pending replacement jobs). -/
def Alg4State.totalServingAndPendingNodes {d : ℕ} {ι : Type} (st : Alg4State d ι) : ℕ :=
  st.servingNodes.length +
    (st.servingNodes.map (fun sn =>
      match sn.ownedJob with
      | none => 0
      | some job => job.completedPrefix.length)).sum

open Classical in
/-- Claim (Sec. 7.2: Replacing the geometric chain) (paper p.33). Exactly the paper's statement, as a Prop. -/
def S_clm_7_2_chain_schedule : Prop :=
  ∀ (F_C F_K₀ F_L F_loc : ℕ → ℝ → List ℝ → ℝ)
    (_hF_C : IsPolyInAlphaInvDimLogs F_C)
    (_hF_K₀ : IsPolyInAlphaInvDimLogs F_K₀)
    (_hF_L : IsPolyInAlphaInvDimLogs F_L)
    (_hF_loc : IsPolyInAlphaInvDimLogs F_loc),
    ∃ (C_ticks c_core C_depth C_batch jobBudgetMult : ℝ)
      (P_nodes P_workFactor : ℕ → ℝ → List ℝ → ℝ),
      0 < C_ticks ∧
      0 < c_core ∧ c_core < 1 ∧
      1 ≤ C_depth ∧
      1 ≤ C_batch ∧
      0 < jobBudgetMult ∧
      IsPolyInAlphaInvDimLogs P_nodes ∧
      (∀ (d : ℕ) (α : ℝ) (logs : List ℝ), 1 ≤ P_nodes d α logs) ∧
      IsPolyInAlphaInvDimLogs P_workFactor ∧
      (∀ (d : ℕ) (α : ℝ) (logs : List ℝ), 1 ≤ P_workFactor d α logs) ∧
      scheduleCStar = 4096 ∧
      ∀ (d n : ℕ) (ι : Type) (α C : ℝ) (K₀ L : ℕ),
        2 ≤ n →
        0 < α →
        α < 1 →
        0 ≤ C →
        SatisfiesLeafCutoffEq10 d n α C K₀ L →
          let D₀ : ℕ := ⌈C_depth * α⁻¹ * Real.log (2 * (n : ℝ))⌉₊
          -- (1) Late-opening gate (`r ≤ α m / 4096`) and `O(α^2 m)` tick completion bound:
          ((∀ (r m : ℕ),
              (CanOpenResidualLevel α r m ↔ (r : ℝ) ≤ α * (m : ℝ) / 4096) ∧
              (residualScheduleStep α L r m ≠ .wait ↔ (r : ℝ) ≤ α * (m : ℝ) / 4096)) ∧
            (∀ (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
               (job : Alg4PendingJob d ι) (jc : PendingJobStepChoices d ι),
              alg4Line5LateOpeningGate pts mode α L job jc ≠ job →
                job.closedAsLeaf = false ∧
                (∀ lv ∈ job.completedPrefix, lv.backgroundReady = true) ∧
                (job.remainingTicks : ℝ) ≤ α * (job.currentResidual.card : ℝ) / 4096) ∧
            (∀ m : ℕ,
              IsLargeResidualLevel L m →
                let b := maxLevelBuildTicks α m
                1 ≤ b ∧
                (b : ℝ) ≤ C_ticks * α ^ 2 * (m : ℝ) ∧
                (∀ (A_n P_loc : ℝ), 1 ≤ A_n → 1 ≤ P_loc →
                  ((m : ℝ) + (b : ℝ)) * A_n * P_loc ≤
                    (b : ℝ) * prescribedJobTickBudget jobBudgetMult α (A_n * P_loc)))) ∧
          -- (2) Verified core removes an `Ω(α)` fraction of birth input, leaving enough time
          -- (`¬ CanOpenResidualLevel α (r - b) m'`) to open its smaller child later after any
          -- first gate crossing `α m / 4096 - 2 < r ≤ α m / 4096`:
          (∀ (pts : ι → EuclideanSpace ℝ (Fin d)) (S_birth : Finset ι)
             (bId : ι) (res : SampledCenterResult d),
            bId ∈ S_birth →
              let ball := selectOpenedLevelBall α pts S_birth bId res
              PassesBirthCoreCheck α pts ball S_birth ∧
              c_core * α * (S_birth.card : ℝ) ≤ ((ball.core pts S_birth).card : ℝ) ∧
              ((ball.residual pts S_birth).card : ℝ) ≤ (1 - c_core * α) * (S_birth.card : ℝ) ∧
              (∀ (r b trueAge : ℕ) (S_after : Finset ι),
                IsLargeResidualLevel L S_birth.card →
                α * (S_birth.card : ℝ) / 4096 - 2 < (r : ℝ) →
                (r : ℝ) ≤ α * (S_birth.card : ℝ) / 4096 →
                1 ≤ b → b ≤ maxLevelBuildTicks α S_birth.card →
                trueAge ≤ b →
                HasNodeAge S_birth S_after trueAge →
                  let m' := (ball.residual pts S_after).card
                  b < r ∧
                  (m' : ℝ) ≤ (1 - α / 4) * ((S_birth.card + b : ℕ) : ℝ) ∧
                  ¬ CanOpenResidualLevel α (r - b) m')) ∧
          -- (3) Serving-node job-start rule (`⌊α M / 64⌋`, `H = ⌊α m₀ / 4096⌋` for `m₀ > 4L` else
          -- immediate exact leaf), serving-node age `< α M / 16` up to deadline,serving-only job
          -- ownership, and retention of birth snapshot and actual birth age upon chain activation:
          ((∀ m₀ : ℕ,
              scheduleJobStart α L m₀ =
                if NeedsScheduledReplacement L m₀ then
                  .startPendingJob (jobDeadlineTicks α m₀)
                else
                  .replaceImmediatelyByExactLeaf) ∧
            (∀ (M m₀ startAge elapsed : ℕ) (S_birth S_start : Finset ι),
              IsLargeResidualLevel L M →
              S_birth.card = M →
              S_start.card = m₀ →
              startAge ≤ jobStartAge α M →
              HasNodeAge S_birth S_start startAge →
              NeedsScheduledReplacement L m₀ →
              elapsed ≤ jobDeadlineTicks α m₀ →
                IsValidServingNodeAge α M (jobStartAge α M + elapsed)) ∧
            (∀ lv : Alg4OpenedLevel d ι,
              let sn := installOpenedLevelAsServingNode lv
              sn.birthSnapshot = lv.birthSnapshot ∧
              sn.node = lv.ball ∧
              sn.trueAge = lv.trueInputAge ∧
              sn.age = lv.elapsedRootTicks ∧
              sn.ownedJob = none ∧
              (IsLargeResidualLevel L lv.birthSnapshot.card →
                (lv.elapsedRootTicks : ℝ) ≤ α * (lv.birthSnapshot.card : ℝ) / 4096 →
                  sn.age < jobStartAge α sn.birthSnapshot.card ∧
                  IsValidServingNodeAge α sn.birthSnapshot.card sn.age))) ∧
          -- (4) Two scans in Section C.2 distinguish immutable birth records from current input
          -- `S_lv`, including arriving insertions and deletions during construction exactly once:
          (∀ (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
             (T : ℕ)
             (S_lv : Fin (T + 1) → Finset ι)
             (ev : Fin T → PoolUpdateEvent ι)
             (rootTick : Fin T → Bool)
             (qAns : Fin T → NodeMatchingQueryAnswers ι)
             (mHint : Fin T → Option ι)
             (bChoice : Fin T → PendingLevelBudgetChoices ι)
             (st_lv : Fin (T + 1) → Alg4OpenedLevel d ι),
            st_lv 0 = initAlg4OpenedLevel mode (S_lv 0) ball →
            (∀ t : Fin T,
              IsValidPoolUpdateEvent (S_lv t.castSucc) (S_lv t.succ) (ev t) ∧
              ((ev t).isClockTick = true → rootTick t = true) ∧
              let lv_arr :=
                applyOpenedLevelArrival pts mode (st_lv t.castSucc) (ev t) (qAns t) (mHint t)
              st_lv t.succ =
                if rootTick t = true then
                  stepOpenedLevelBuild pts mode (S_lv t.succ) lv_arr (bChoice t)
                else
                  lv_arr) →
              (∀ s : Fin (T + 1),
                (st_lv s).birthSnapshot = S_lv 0 ∧
                (st_lv s).scan2Snapshot = S_lv 0 ∧
                (st_lv s).heapIndexedIds = (st_lv s).radiusDict.indexedIds ∧
                (st_lv s).heapIndexedIds ⊆ S_lv s ∧
                (st_lv s).classifiedIds ⊆ S_lv s ∧
                S_lv s \ S_lv 0 ⊆ (st_lv s).heapIndexedIds ∧
                S_lv s \ S_lv 0 ⊆ (st_lv s).classifiedIds ∧
                (st_lv s).radiusDict.WellFormedOn pts ball.o (st_lv s).heapIndexedIds ∧
                ValidNodeMatchingsOn pts mode ball (st_lv s).classifiedIds (st_lv s).localMatchings ∧
                HasNodeAge (S_lv 0) (S_lv s) (st_lv s).trueInputAge ∧
                (st_lv s).trueInputAge ≤ (st_lv s).elapsedRootTicks ∧
                ((st_lv s).backgroundReady = true →
                  (st_lv s).heapIndexedIds = S_lv s ∧ (st_lv s).classifiedIds = S_lv s) ∧
                ((∀ x ∈ S_lv 0,
                    (∃ t : Fin T, t.succ ≤ s ∧ rootTick t = true ∧ x ∈ (bChoice t).scan1Batch) ∧
                    (∃ t : Fin T, t.succ ≤ s ∧ rootTick t = true ∧
                      x ∈ ((bChoice t).scan2Steps.map Prod.fst))) →
                  (st_lv s).heapIndexedIds = S_lv s ∧ (st_lv s).classifiedIds = S_lv s)) ∧
              (∀ t : Fin T, ∀ p : ι,
                (ev t = .externalInsert p →
                  p ∉ (st_lv t.castSucc).heapIndexedIds ∧
                  p ∉ (st_lv t.castSucc).classifiedIds ∧
                  p ∈ (st_lv t.succ).heapIndexedIds ∧
                  p ∈ (st_lv t.succ).classifiedIds) ∧
                (ev t = .externalDelete p →
                  p ∉ (st_lv t.succ).heapIndexedIds ∧
                  p ∉ (st_lv t.succ).classifiedIds)) ∧
              ((∀ (t₁ t₂ : Fin T) (p : ι),
                  ev t₁ = .externalInsert p →
                    p ∉ S_lv 0 ∧ (ev t₂ = .externalInsert p → t₁ = t₂)) →
                ∀ x : ι,
                  ((List.finRange T).filter (fun t =>
                    decide (x ∉ (st_lv t.castSucc).heapIndexedIds ∧
                      x ∈ (st_lv t.succ).heapIndexedIds))).length ≤ 1 ∧
                  ((List.finRange T).filter (fun t =>
                    decide (x ∉ (st_lv t.castSucc).classifiedIds ∧
                      x ∈ (st_lv t.succ).classifiedIds))).length ≤ 1)) ∧
          -- (5) Full Algorithm 4 execution guarantees: per-tick scan batch `⌈C_batch C_* α⁻²⌉₊`
          -- achieves Equation (11) completion (`O(α^2 m)` ticks), maintains all age/deadline/depth
          -- invariants (`D_0 = O(α⁻¹ log(2n))`), and bounds all serving/pending node counts and
          -- work budgets polynomially in `(α⁻¹, d, logs)`:
          (∀ (mode : Alg4Mode) (reclaimMult D_out T : ℕ),
            1 ≤ reclaimMult →
            1 ≤ D_out →
              -- Achievability of Equation (11) completion under per-tick batch `⌈C_batch C_* α⁻²⌉₊`
              (∀ (upd : Fin T → Alg4PointUpdate d ι)
                 (baseChoices : Fin T → Alg4StepChoices d ι),
                ∃ (choices : Fin T → Alg4StepChoices d ι)
                  (st : Fin (T + 1) → Alg4State d ι)
                  (ans : Fin T → Option (ι × ι) × ℝ),
                  st 0 = Alg4State.empty d ι ∧
                  (∀ t : Fin T,
                    ChainSchedChoicesAgreeOnNonBudget (baseChoices t) (choices t) ∧
                    ChainSchedScanBatchCap
                      ⌈C_batch * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊ (choices t) ∧
                    alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
                      (st t.succ, ans t)) ∧
                  ((∀ t : Fin T, IsValidAlg4PointUpdate n (st t.castSucc) (upd t)) →
                    ∀ t : Fin T,
                      ChainSchedEq11Step mode α L (st t.castSucc) (upd t) (choices t))) ∧
              -- Invariants and polynomial node/budget bounds along every valid execution
              (∀ (st : Fin (T + 1) → Alg4State d ι)
                 (ans : Fin T → Option (ι × ι) × ℝ)
                 (upd : Fin T → Alg4PointUpdate d ι)
                 (choices : Fin T → Alg4StepChoices d ι),
                st 0 = Alg4State.empty d ι →
                (∀ t : Fin T,
                  IsValidAlg4PointUpdate n (st t.castSucc) (upd t) ∧
                  ChainSchedEq11Step mode α L (st t.castSucc) (upd t) (choices t) ∧
                  (∀ r ∈ (choices t).stepExtraRetired, r.HasBoundedOutdegree D_out) ∧
                  alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
                    (st t.succ, ans t)) →
                  ∀ s : Fin (T + 1),
                    (st s).WellFormed n mode α L D_out ∧
                    (∀ idx : Fin (st s).servingNodes.length,
                      let sn := (st s).servingNodes[idx]
                      let S_cur := (st s).servingInputAt idx.val
                      IsValidServingNodeAge α sn.birthSnapshot.card sn.age ∧
                      HasNodeAge sn.birthSnapshot S_cur sn.trueAge ∧
                      sn.trueAge ≤ sn.age ∧
                      (sn.age < jobStartAge α sn.birthSnapshot.card → sn.ownedJob = none) ∧
                      (∀ job : Alg4PendingJob d ι,
                        sn.ownedJob = some job →
                          job.completedPrefix.length ≤ D₀ ∧
                          (job.completedPrefix.filter (fun lv => !lv.backgroundReady)).length ≤ 1)) ∧
                    (st s).servingNodes.length ≤ D₀ ∧
                    (st s).owningReplacementJobCount ≤ D₀ ∧
                    (st s).totalServingAndPendingNodes ≤ D₀ + D₀ ^ 2 ∧
                    (∀ (logs : List ℝ) (A_n P_loc : ℝ),
                      Real.log (2 * (n : ℝ)) ≤ 1 + (logs.map (max 0)).sum →
                      C ≤ F_C d α logs →
                      (K₀ : ℝ) ≤ F_K₀ d α logs →
                      (L : ℝ) ≤ F_L d α logs →
                      1 ≤ A_n →
                      1 ≤ P_loc →
                      P_loc ≤ F_loc d α logs →
                        ((D₀ : ℝ) ≤ P_nodes d α logs ∧
                         ((st s).totalServingAndPendingNodes : ℝ) ≤ P_nodes d α logs) ∧
                        (let perServingNodeBudget : ℝ :=
                           ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((K₀ : ℝ) + 1) + A_n * P_loc
                         let perPendingJobTickBudget : ℝ :=
                           prescribedJobTickBudget jobBudgetMult α (A_n * P_loc)
                         let levelOpenBudget : ℝ :=
                           C + ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((L : ℝ) + 1) + A_n * P_loc
                         let leafHandleAndRebuildBudget : ℝ :=
                           ((d : ℝ) + 1) * (((6 * L + 1 : ℕ) : ℝ) ^ 2) +
                             ((6 * L + 1 : ℕ) : ℝ) * (C + A_n * P_loc)
                         perServingNodeBudget + perPendingJobTickBudget +
                           levelOpenBudget + leafHandleAndRebuildBudget +
                           ((D₀ + 1 : ℕ) : ℝ) *
                             (perServingNodeBudget + perPendingJobTickBudget + levelOpenBudget) ≤
                             A_n * P_workFactor d α logs))))

end UL
