import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_dynamic_points_model
import UL.Def.def_computation_model
import UL.Def.def_node_chain_blocks
import UL.Def.def_local_matching
import UL.Def.def_7_birth_pool
import UL.Def.def_C_2_schedule
import UL.Def.def_alg_4
set_option autoImplicit false

namespace UL

/-! ### Helper definitions for Section C.2 chain installation, space, and reclamation -/

/-- Equation (11) background-completion property on one step of Algorithm 4: after Lines 2–6
(`alg4Lines2To6StepPendingJobs`), every opened pending level `lv` whose elapsed job-root ticks
have reached `maxLevelBuildTicks α lv.birthSnapshot.card` (`⌊α^2 m / (64 C_*)⌋₊`) has completed its
background construction (`lv.backgroundReady = true`). -/
def Alg4StepSatisfiesEq11Completion {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (st : Alg4State d ι) (upd : Alg4PointUpdate d ι)
    (choices : Alg4StepChoices d ι) : Prop :=
  let P' := applyAlg4PointSetUpdate st.activeSet upd
  let pts' := updateAlg4Coords st.coords upd
  let (nodesLine1, _, _) :=
    alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints
  let nodesLines2To6 :=
    alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
  ∀ p ∈ nodesLines2To6, ∀ job : Alg4PendingJob d ι,
    p.1.ownedJob = some job →
    ∀ lv ∈ job.completedPrefix,
      maxLevelBuildTicks α lv.birthSnapshot.card ≤ lv.elapsedRootTicks →
        lv.backgroundReady = true

/-- Agreement of two `Alg4StepChoices` bundles on all fields except the per-level two-scan
construction budget choices `prefixBudgetSteps` inside `pendingJobChoices`. -/
def Alg4StepChoicesAgreeExceptScanBudgets {d : ℕ} {ι : Type}
    (base chosen : Alg4StepChoices d ι) : Prop :=
  chosen.servingRouteQueries = base.servingRouteQueries ∧
  chosen.servingRadiusMaxHints = base.servingRadiusMaxHints ∧
  chosen.leafRebuildChoices = base.leafRebuildChoices ∧
  chosen.terminalLeafHint = base.terminalLeafHint ∧
  chosen.baselineSamples = base.baselineSamples ∧
  chosen.matchingMaxHints = base.matchingMaxHints ∧
  chosen.distinctPairHint = base.distinctPairHint ∧
  chosen.stepExtraRetired = base.stepExtraRetired ∧
  chosen.stepAllocatedRecords = base.stepAllocatedRecords ∧
  ∀ i : Fin base.pendingJobChoices.length,
    ∃ jc : PendingJobStepChoices d ι,
      chosen.pendingJobChoices[i.val]? = some jc ∧
      jc.prefixRouteQueries = (base.pendingJobChoices[i]).prefixRouteQueries ∧
      jc.prefixRouteMaxHints = (base.pendingJobChoices[i]).prefixRouteMaxHints ∧
      jc.openSampledCenter = (base.pendingJobChoices[i]).openSampledCenter ∧
      jc.openFallbackBirthId = (base.pendingJobChoices[i]).openFallbackBirthId ∧
      jc.leafHint = (base.pendingJobChoices[i]).leafHint

/-- Per-tick scan batch bound `K_batch` on every `PendingLevelBudgetChoices` inside `choices`. -/
def Alg4ChoicesRespectScanBatchCap {d : ℕ} {ι : Type}
    (K_batch : ℕ) (choices : Alg4StepChoices d ι) : Prop :=
  ∀ jc ∈ choices.pendingJobChoices,
    ∀ bStep ∈ jc.prefixBudgetSteps,
      bStep.scan1Batch.card ≤ K_batch ∧ bStep.scan2Steps.length ≤ K_batch

/-- Number of serving nodes in `st` that currently own a pending replacement job. -/
def Alg4State.owningJobNodeCount {d : ℕ} {ι : Type} (st : Alg4State d ι) : ℕ :=
  (st.servingNodes.filter (fun sn => sn.ownedJob.isSome)).length

/-- List of all retained chain snapshot cardinalities in one `Alg4ServingNode` (`birthSnapshot`,
plus `currentResidual` and every opened pending level's `birthSnapshot` and `scan2Snapshot` when a
job is owned). -/
def Alg4ServingNode.retainedSnapshotCards {d : ℕ} {ι : Type}
    (sn : Alg4ServingNode d ι) : List ℕ :=
  sn.birthSnapshot.card ::
    match sn.ownedJob with
    | none => []
    | some job =>
        job.currentResidual.card ::
          job.completedPrefix.flatMap (fun lv => [lv.birthSnapshot.card, lv.scan2Snapshot.card])

/-- List of all retained chain snapshot cardinalities across `st : Alg4State d ι` (`activeSet`,
`terminalLeaf`, and all serving/pending snapshots). -/
def Alg4State.retainedChainSnapshotCards {d : ℕ} {ι : Type} (st : Alg4State d ι) : List ℕ :=
  st.activeSet.card :: st.terminalLeaf.card ::
    st.servingNodes.flatMap Alg4ServingNode.retainedSnapshotCards

/-- Number of live chain-snapshot records held by an `Alg4ServingNode` (matching
`retireServingNodeRecords`). -/
def Alg4ServingNode.liveSnapRecords {d : ℕ} {ι : Type} (sn : Alg4ServingNode d ι) : ℕ :=
  1 + match sn.ownedJob with
    | none => 0
    | some job => 1 + 2 * job.completedPrefix.length

/-- Number of live chain-snapshot records held across `st : Alg4State d ι` (`1` for `terminalLeaf`
plus `liveSnapRecords` of each serving node). -/
def Alg4State.liveSnapRecords {d : ℕ} {ι : Type} (st : Alg4State d ι) : ℕ :=
  1 + (st.servingNodes.map Alg4ServingNode.liveSnapRecords).sum

/-- Newly retired record list `allNewRetired` produced during one execution of `alg4Step` before
Line 11's incremental reclamation pops. -/
noncomputable def alg4StepNewRetired {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (st : Alg4State d ι) (upd : Alg4PointUpdate d ι)
    (choices : Alg4StepChoices d ι) : List (RetiredRecord ι) :=
  let P' := applyAlg4PointSetUpdate st.activeSet upd
  let pts' := updateAlg4Coords st.coords upd
  let (nodesLine1, leafLine1, leafTicked) :=
    alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints
  let nodesLines2To6 :=
    alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
  let (nodesLines7To8, leafLines7To8, leafAns7To8, leafSq7To8, leafChanged7To8, retiredInstall) :=
    alg4Lines7To8InstallCompletedJobs nodesLines2To6
      leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafTicked
  let (_, _, _, _, retiredDue) :=
    alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
      nodesLines7To8 leafLines7To8 leafAns7To8 leafSq7To8 leafChanged7To8
      choices.leafRebuildChoices choices.terminalLeafHint
  retiredInstall ++ retiredDue ++ choices.stepExtraRetired

/-- Validity of a collection of local frozen angular-search generation birth cardinalities
`localGenCards : List ℕ` hosted across the live serving and pending node structures of `st`
(Section 7.1, p. 32: empty when `mode = .endpointSqrt2`; under `mode = .subSqrt2 _`, at most
`2 * 4 * numIntervalLevels` coexisting frozen snapshots — `≤ 3` serving and `≤ 1` pending per
dyadic interval length on each of the `2` sides — per retained local configuration of each live
serving or pending node, each of birth cardinality `≤ n`). -/
def IsValidLocalFrozenGenCards {d : ℕ} {ι : Type}
    (n numIntervalLevels : ℕ) (mode : Alg4Mode)
    (st : Alg4State d ι) (localGenCards : List ℕ) : Prop :=
  (∀ m ∈ localGenCards, m ≤ n) ∧
  match mode with
  | .endpointSqrt2 => localGenCards = []
  | .subSqrt2 _ =>
      let nodeCfgCount (V : ℝ) : ℕ := (mode.retainedConfigs V).card
      let servingCfgSum : ℕ :=
        (st.servingNodes.map (fun sn =>
          nodeCfgCount sn.node.V +
            match sn.ownedJob with
            | none => 0
            | some job =>
                (job.completedPrefix.map (fun lv => nodeCfgCount lv.ball.V)).sum)).sum
      localGenCards.length ≤ 8 * numIntervalLevels * servingCfgSum

/-- Claim (Sec. C.2: Chain installation invariants, total space, and incremental reclamation) (paper p.53). Exactly the paper's statement, as a Prop. -/
def S_claim_C_2_space_reclaim : Prop :=
  ∀ (P_α P_cfg P_int : ℕ → ℕ → ℝ)
    (_hP_α : IsBoundedByPoly2 P_α)
    (_hP_cfg : IsBoundedByPoly2 P_cfg)
    (_hP_int : IsBoundedByPoly2 P_int),
    ∃ (C_depth C_leaf C_batch C_endSpace : ℝ)
      (P_card P_spaceTot : ℕ → ℕ → ℝ),
      0 < C_depth ∧ 0 < C_leaf ∧ 0 < C_batch ∧ 0 < C_endSpace ∧
      IsBoundedByPoly2 P_card ∧ (∀ d L_log : ℕ, 1 ≤ P_card d L_log) ∧
      IsBoundedByPoly2 P_spaceTot ∧ (∀ d L_log : ℕ, 1 ≤ P_spaceTot d L_log) ∧
      -- (1) Power-space inequality `m^{1+σ} ≤ n^σ m`, bounded-outdegree persistent-tree / index
      -- record reclamation (`reclaimOneRecord`, `alg4Line11PerformRetirementWork`), no synchronous
      -- large-index freeing on activation, and multi-step queued-records bound
      (∀ (m n : ℕ) (σ : ℝ), m ≤ n → 0 ≤ σ →
        (m : ℝ) ^ (1 + σ) ≤ (n : ℝ) ^ σ * (m : ℝ)) ∧
      (∀ (ι : Type) (D_out : ℕ) (q : List (RetiredRecord ι)),
        (∀ r ∈ q, r.HasBoundedOutdegree D_out) →
          let (q', w) := reclaimOneRecord q
          (∀ r' ∈ q', r'.HasBoundedOutdegree D_out) ∧
          w ≤ 1 + D_out ∧
          (∀ ids children rest,
            q = .node ids children :: rest →
              q' = rest ++ children ∧
              w = 1 + children.length ∧
              retirementQueueRecordCount q' + 1 = retirementQueueRecordCount q)) ∧
      (∀ (ι : Type) (D_out reclaimMult stepAlloc : ℕ)
         (prevQueue newRetired : List (RetiredRecord ι)),
        (∀ r ∈ prevQueue, r.HasBoundedOutdegree D_out) →
        (∀ r ∈ newRetired, r.HasBoundedOutdegree D_out) →
          let (nextQueue, work) :=
            alg4Line11PerformRetirementWork reclaimMult stepAlloc prevQueue newRetired
          (∀ r ∈ nextQueue, r.HasBoundedOutdegree D_out) ∧
          work ≤ (1 + D_out) * reclaimMult * max 1 stepAlloc ∧
          retirementQueueRecordCount nextQueue =
            retirementQueueRecordCount prevQueue + retirementQueueRecordCount newRetired -
              reclaimMult * max 1 stepAlloc) ∧
      (∀ (ι : Type) (D_out reclaimMult B_live B_alloc T : ℕ)
         (liveRecs : Fin (T + 1) → ℕ)
         (allocRecs : Fin T → ℕ)
         (newRetired : Fin T → List (RetiredRecord ι))
         (queue : Fin (T + 1) → List (RetiredRecord ι)),
        1 ≤ reclaimMult →
        queue 0 = [] →
        (∀ s : Fin (T + 1), liveRecs s ≤ B_live) →
        (∀ t : Fin T,
          allocRecs t ≤ B_alloc ∧
          (∀ r ∈ newRetired t, r.HasBoundedOutdegree D_out) ∧
          liveRecs t.succ + retirementQueueRecordCount (newRetired t) ≤
            liveRecs t.castSucc + allocRecs t ∧
          queue t.succ =
            (alg4Line11PerformRetirementWork reclaimMult (allocRecs t)
              (queue t.castSucc) (newRetired t)).1) →
          (∀ s : Fin (T + 1),
            (∀ r ∈ queue s, r.HasBoundedOutdegree D_out) ∧
            retirementQueueRecordCount (queue s) + liveRecs s ≤ B_live) ∧
          (∀ t : Fin T,
            retirementQueueRecordCount (queue t.castSucc ++ newRetired t) + liveRecs t.succ ≤
              B_live + B_alloc)) ∧
      -- (2) Step-level Algorithm 4 invariants: shared root pool changed once; pending job updates
      -- its own radius dictionary and lower pools without re-applying the root change; ancestor
      -- replacement supersedes descendant jobs while surviving ancestors are unaffected; new root
      -- owns the shared input pool; newly installed nodes retain true age bounded by elapsed root
      -- ticks; affected surviving/installed caches refreshed before exposing answer (deleted
      -- identity never in published pair); leaf growing to `6L + 1` rebuilt immediately within
      -- polynomial leaf budget
      (∀ (d n : ℕ) (ι : Type) (mode : Alg4Mode) (α : ℝ) (L reclaimMult D_out : ℕ)
         (st : Alg4State d ι) (upd : Alg4PointUpdate d ι) (choices : Alg4StepChoices d ι),
        (st.WellFormed n mode α L D_out →
         IsValidAlg4PointUpdate n st upd →
          let P' := applyAlg4PointSetUpdate st.activeSet upd
          let pts' := updateAlg4Coords st.coords upd
          let (nodesLine1, leafLine1, _) :=
            alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
              choices.servingRouteQueries choices.servingRadiusMaxHints
          let nodesLines2To6 :=
            alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
          ∃ hLen1 : nodesLine1.length = st.servingNodes.length,
          ∃ hLen26 : nodesLines2To6.length = st.servingNodes.length,
            leafLine1 =
              servingChainInputAt pts'
                (nodesLine1.map (fun p => p.1.toServingNodeState)) P' st.servingNodes.length ∧
            (∀ idx : Fin st.servingNodes.length,
              let p1 := nodesLine1[idx.val]'(by omega)
              let sn₁ := p1.1
              let ev := p1.2
              let S_before := st.servingInputAt idx.val
              let S_after :=
                servingChainInputAt pts'
                  (nodesLine1.map (fun p => p.1.toServingNodeState)) P' idx.val
              IsValidPoolUpdateEvent S_before S_after ev ∧
              ev.ticks ≤ 1 ∧
              (ev.isClockTick = false →
                (nodesLines2To6[idx.val]'(by omega)).1 = st.servingNodes[idx]) ∧
              (ev.isClockTick = true →
                ∀ (job : Alg4PendingJob d ι) (jc : PendingJobStepChoices d ι),
                  sn₁.ownedJob = some job →
                    let job₁ := alg4Line3RouteThroughPrefix pts' mode job ev S_after jc
                    ∃ hPrefLen : job₁.completedPrefix.length = job.completedPrefix.length,
                      job₁.currentResidual =
                        prefixResidual pts'
                          (job₁.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_after ∧
                      ∀ j : Fin job.completedPrefix.length,
                        let lv := job.completedPrefix[j]
                        let lv₁ := job₁.completedPrefix[j.val]'(by omega)
                        let S_lv := alg4PrefixInputAt st.coords job.completedPrefix S_before j.val
                        let S_lv' := alg4PrefixInputAt pts' job₁.completedPrefix S_after j.val
                        ∃ ev_j : PoolUpdateEvent ι,
                          IsValidPoolUpdateEvent S_lv S_lv' ev_j ∧
                          ev_j.ticks ≤ 1 ∧
                          lv₁.trueInputAge = lv.trueInputAge + ev_j.ticks ∧
                          lv₁.radiusDict.IsScanValid pts' lv.ball.o S_lv' ∧
                          lv₁.classifiedIds ⊆ S_lv' ∧
                          ValidNodeMatchingsOn pts' mode lv.ball lv₁.classifiedIds
                            lv₁.localMatchings))) ∧
        (∀ (nodes26 : List (Alg4ServingNode d ι × Bool))
           (leaf1 : Finset ι) (leafAns0 : Option (ι × ι)) (leafSq0 : ℝ) (leafTicked : Bool),
          let (nodes78, leaf78, _, _, _, retired78) :=
            alg4Lines7To8InstallCompletedJobs nodes26 leaf1 leafAns0 leafSq0 leafTicked
          ((∀ p ∈ nodes26, ∀ job, p.1.ownedJob = some job → ¬ job.IsReadyToInstall) →
            nodes78 = nodes26 ∧ leaf78 = leaf1 ∧ retired78 = []) ∧
          (∀ (idx₀ : Fin nodes26.length) (job₀ : Alg4PendingJob d ι),
            (nodes26[idx₀]).1.ownedJob = some job₀ →
            job₀.IsReadyToInstall →
            (∀ i : Fin nodes26.length, i < idx₀ →
              ∀ j, (nodes26[i]).1.ownedJob = some j → ¬ j.IsReadyToInstall) →
              nodes78.take idx₀.val = nodes26.take idx₀.val ∧
              nodes78 =
                (nodes26.take idx₀.val) ++
                  job₀.completedPrefix.map (fun lv => (installOpenedLevelAsServingNode lv, true)) ∧
              leaf78 = job₀.currentResidual ∧
              (∀ (pts' : ι → EuclideanSpace ℝ (Fin d)) (P' : Finset ι),
                servingChainInputAt pts'
                  (nodes78.map (fun p => p.1.toServingNodeState)) P' idx₀.val =
                servingChainInputAt pts'
                  (nodes26.map (fun p => p.1.toServingNodeState)) P' idx₀.val) ∧
              (∀ lv ∈ job₀.completedPrefix,
                let sn_new := installOpenedLevelAsServingNode lv
                sn_new.birthSnapshot = lv.birthSnapshot ∧
                sn_new.trueAge = lv.trueInputAge ∧
                sn_new.age = lv.elapsedRootTicks ∧
                sn_new.ownedJob = none ∧
                (∀ (pts' : ι → EuclideanSpace ℝ (Fin d)) (S_lv : Finset ι),
                  lv.WellFormed mode α L pts' S_lv →
                    sn_new.trueAge ≤ sn_new.age ∧
                    HasNodeAge sn_new.birthSnapshot S_lv sn_new.trueAge)))) ∧
        (0 < α → α ≤ 1 → 1 ≤ L →
         st.WellFormed n mode α L D_out →
         IsValidAlg4PointUpdate n st upd →
          let (nextState, ans) := alg4Step mode α L reclaimMult st upd choices
          nextState.cachedAnswer = ans ∧
          IsExactLeafAnswer nextState.coords nextState.terminalLeaf
            nextState.terminalLeafAnswer ∧
          (∀ idx : Fin nextState.servingNodes.length,
            let sn' := nextState.servingNodes[idx]
            let S' := nextState.servingInputAt idx.val
            IsActiveNodePair S' sn'.baselinePair ∧
            (∀ x y : ι, sn'.maxMatchingPair = some (x, y) → x ∈ S' ∧ y ∈ S' ∧ x ≠ y)) ∧
          (if nextState.activeSet.card ≤ 1 then
            ans = (none, 0)
          else
            ∃ u v : ι,
              u ∈ nextState.activeSet ∧
              v ∈ nextState.activeSet ∧
              u ≠ v ∧
              ans = (some (u, v), euclideanDistSq (nextState.coords u) (nextState.coords v))) ∧
          (∀ p : ι, ∀ hDel : upd = .delete p,
            p ∉ nextState.activeSet ∧
            (∀ u v : ι, ans.1 = some (u, v) → u ≠ p ∧ v ≠ p) ∧
            (∀ idx : Fin nextState.servingNodes.length,
              (∀ u v : ι, (nextState.servingNodes[idx]).baselinePair = some (u, v) →
                u ≠ p ∧ v ≠ p) ∧
              (∀ u v : ι, (nextState.servingNodes[idx]).maxMatchingPair = some (u, v) →
                u ≠ p ∧ v ≠ p)))) ∧
        (0 < α → α ≤ 1 → 1 ≤ L →
          ∀ (pts' : ι → EuclideanSpace ℝ (Fin d)) (leaf₁ : Finset ι)
            (rebuildChoices : List (LeafRebuildLevelChoices d ι)),
            6 * L < leaf₁.card →
            leaf₁.card ≤ 6 * L + 1 →
              let (rebuiltNodes, finalLeaf) :=
                rebuildOversizedLeafAux pts' mode α L leaf₁.card leaf₁ rebuildChoices
              IsResidualLeafSize L finalLeaf.card ∧
              (rebuiltNodes.length : ℝ) ≤ C_leaf * α⁻¹ ∧
              rebuiltNodes.length ≤ 6 * L + 1 ∧
              ((rebuiltNodes.map (fun p => p.1.birthSnapshot.card)).sum + finalLeaf.card ^ 2 : ℝ) ≤
                C_leaf * α⁻¹ * ((L + 1 : ℝ) ^ 2) ∧
              (∀ p ∈ rebuiltNodes,
                p.2 = true ∧
                IsLargeResidualLevel L p.1.birthSnapshot.card ∧
                p.1.birthSnapshot.card ≤ 6 * L + 1 ∧
                PassesBirthCoreCheck α pts' p.1.node p.1.birthSnapshot ∧
                p.1.trueAge = 0 ∧
                p.1.age = 0 ∧
                p.1.ownedJob = none ∧
                p.1.radiusDict.IsComplete pts' p.1.node.o p.1.birthSnapshot ∧
                ValidNodeMatchingsOn pts' mode p.1.node p.1.birthSnapshot p.1.localMatchings))) ∧
      -- (3) Reachable Algorithm 4 execution invariants: `D_0 = O(α⁻¹ log n)` serving/job/level
      -- bounds, retained birth cardinalities `≤ n poly(d, log n)` including local frozen
      -- generations, total space `n^{1+σ} P`, and queued retired records included in the bound
      (∀ (d n : ℕ) (ι : Type) (mode : Alg4Mode)
         (α C σ P_space : ℝ) (K₀ L reclaimMult D_out B_alloc T : ℕ),
        2 ≤ n →
        0 < α →
        α ≤ 1 →
        0 ≤ C →
        SatisfiesLeafCutoffEq10 d n α C K₀ L →
        0 ≤ σ →
        1 ≤ P_space →
        1 ≤ reclaimMult →
        1 ≤ D_out →
          let L_log : ℕ := Nat.clog 2 (2 * n)
          let D₀ : ℕ := ⌈C_depth * α⁻¹ * Real.log (n : ℝ)⌉₊
          1 ≤ D₀ ∧
          (D₀ : ℝ) ≤ (C_depth + 2) * α⁻¹ * Real.log (n : ℝ) ∧
          -- Budget-bounded per-tick scan choices always suffice to achieve Equation (11)
          (∀ (upd : Fin T → Alg4PointUpdate d ι)
             (baseChoices : Fin T → Alg4StepChoices d ι),
            ∃ (choices : Fin T → Alg4StepChoices d ι)
              (st : Fin (T + 1) → Alg4State d ι)
              (ans : Fin T → Option (ι × ι) × ℝ),
              st 0 = Alg4State.empty d ι ∧
              (∀ t : Fin T,
                Alg4StepChoicesAgreeExceptScanBudgets (baseChoices t) (choices t) ∧
                Alg4ChoicesRespectScanBatchCap
                  ⌈C_batch * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊ (choices t) ∧
                alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
                  (st t.succ, ans t)) ∧
              ((∀ t : Fin T, IsValidAlg4PointUpdate n (st t.castSucc) (upd t)) →
                ∀ t : Fin T,
                  Alg4StepSatisfiesEq11Completion mode α L
                    (st t.castSucc) (upd t) (choices t))) ∧
          -- Full execution invariants along any trajectory satisfying Equation (11)
          (∀ (st : Fin (T + 1) → Alg4State d ι)
             (ans : Fin T → Option (ι × ι) × ℝ)
             (upd : Fin T → Alg4PointUpdate d ι)
             (choices : Fin T → Alg4StepChoices d ι),
            st 0 = Alg4State.empty d ι →
            (∀ t : Fin T,
              IsValidAlg4PointUpdate n (st t.castSucc) (upd t) ∧
              Alg4StepSatisfiesEq11Completion mode α L (st t.castSucc) (upd t) (choices t) ∧
              (∀ r ∈ (choices t).stepExtraRetired, r.HasBoundedOutdegree D_out) ∧
              alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
                (st t.succ, ans t)) →
              ∀ s : Fin (T + 1),
                (st s).WellFormed n mode α L D_out ∧
                (∀ sn ∈ (st s).servingNodes,
                  IsValidServingNodeAge α sn.birthSnapshot.card sn.age ∧
                  sn.trueAge ≤ sn.age) ∧
                (st s).servingNodes.length ≤ D₀ ∧
                (st s).owningJobNodeCount ≤ D₀ ∧
                (∀ sn ∈ (st s).servingNodes, ∀ job : Alg4PendingJob d ι,
                  sn.ownedJob = some job → job.completedPrefix.length ≤ D₀) ∧
                (∀ m ∈ (st s).retainedChainSnapshotCards, m ≤ n) ∧
                (st s).retainedChainSnapshotCards.sum ≤ (2 + 2 * D₀ + 2 * D₀ ^ 2) * n ∧
                -- Concrete retirement-queue bound on `st`
                ((∀ t : Fin T,
                  (st t.succ).liveSnapRecords +
                    retirementQueueRecordCount
                      (alg4StepNewRetired mode α L (st t.castSucc) (upd t) (choices t)) ≤
                    (st t.castSucc).liveSnapRecords + (choices t).stepAllocatedRecords ∧
                  (choices t).stepAllocatedRecords ≤ B_alloc) →
                  let B_liveSnap : ℕ := 1 + D₀ * (2 + 2 * D₀)
                  retirementQueueRecordCount (st s).retirementQueue + (st s).liveSnapRecords ≤
                    B_liveSnap ∧
                  retirementQueueRecordCount (st s).retirementQueue ≤ B_liveSnap + B_alloc) ∧
                -- Explicit endpoint (`mode = .endpointSqrt2`, `σ = 0`, no local frozen angular
                -- generations) space bound `O(n (d + 1) D_0^2 L^2)` including leaf pairs and queue
                (mode = .endpointSqrt2 →
                 retirementQueueRecordCount (st s).retirementQueue ≤
                   (D₀ + 1) ^ 2 * (L + 1) ^ 2 →
                  (((st s).activeSet.card * (d + 1) +
                    (st s).retainedChainSnapshotCards.sum * (L_log + 1) +
                    (D₀ + D₀ ^ 2) * L +
                    (st s).terminalLeaf.card ^ 2 +
                    retirementQueueRecordCount (st s).retirementQueue * (D_out + 1) : ℕ) : ℝ) ≤
                    C_endSpace * (n : ℝ) * ((d + 1 : ℝ)) * ((D₀ : ℝ) ^ 2) *
                      ((L + 1 : ℝ) ^ 2) * ((D_out + 1 : ℝ))) ∧
                -- Retained birth cardinalities sum to `n poly(d, log n)` (including local frozen
                -- generations) and total space (including queued retired records) is `n^{1+σ} P`
                (∀ (numIntervalLevels : ℕ) (localGenCards : List ℕ),
                  α⁻¹ ≤ P_α d L_log →
                  (∀ V : ℝ, ((mode.retainedConfigs V).card : ℝ) ≤ P_cfg d L_log) →
                  (numIntervalLevels : ℝ) ≤ P_int d L_log →
                  IsValidLocalFrozenGenCards n numIntervalLevels mode (st s) localGenCards →
                    let allCards : List ℕ := (st s).retainedChainSnapshotCards ++ localGenCards
                    ((allCards.sum : ℕ) : ℝ) ≤ (n : ℝ) * P_card d L_log ∧
                    (∀ qSpace : ℝ,
                      qSpace ≤ 2 * (n : ℝ) ^ (1 + σ) * P_space * P_card d L_log →
                        ((allCards.map (fun m => birthPoolSpaceBound m σ P_space)).sum +
                          qSpace) ≤
                          (n : ℝ) ^ (1 + σ) * P_space * P_spaceTot d L_log))))

end UL
