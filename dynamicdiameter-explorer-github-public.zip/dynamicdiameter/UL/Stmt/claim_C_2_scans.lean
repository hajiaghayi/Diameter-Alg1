import Mathlib
import UL.Def.def_dynamic_points_model
import UL.Def.def_computation_model
import UL.Def.def_node_chain_blocks
import UL.Def.def_local_matching
import UL.Def.def_7_birth_pool
import UL.Def.def_C_2_schedule
set_option autoImplicit false

namespace UL

/-! ### 1. Persistent balanced trees with cached subtree sizes for uniform rank sampling -/

/-- Purely functional persistent binary search tree storing per-node balance metadata `aux : ℕ`
and cached subtree cardinality `subtreeSize : ℕ` for `O(1)` size queries and `O(log |t|)` uniform
rank sampling. -/
inductive PersistentSizeTree (κ α : Type) : Type
  | nil
  | node (aux : ℕ) (subtreeSize : ℕ) (key : κ) (val : α)
      (left right : PersistentSizeTree κ α)

/-- Cached `O(1)` subtree size of a `PersistentSizeTree`. -/
def PersistentSizeTree.size {κ α : Type} : PersistentSizeTree κ α → ℕ
  | .nil => 0
  | .node _ sz _ _ _ _ => sz

/-- Tree height (longest root-to-leaf path in nodes) of a `PersistentSizeTree`. -/
def PersistentSizeTree.height {κ α : Type} : PersistentSizeTree κ α → ℕ
  | .nil => 0
  | .node _ _ _ _ l r => 1 + max l.height r.height

/-- Inorder key-value list represented by a `PersistentSizeTree`. -/
def PersistentSizeTree.toList {κ α : Type} : PersistentSizeTree κ α → List (κ × α)
  | .nil => []
  | .node _ _ k v l r => l.toList ++ [(k, v)] ++ r.toList

/-- Exact cached subtree-size invariant at every node of a `PersistentSizeTree`. -/
def PersistentSizeTree.WellSized {κ α : Type} : PersistentSizeTree κ α → Prop
  | .nil => True
  | .node _ sz _ _ l r => sz = l.size + 1 + r.size ∧ l.WellSized ∧ r.WellSized

/-- Exact cached-height and recursive AVL balance invariant (`|l.height - r.height| ≤ 1`). -/
def PersistentSizeTree.IsAVL {κ α : Type} : PersistentSizeTree κ α → Prop
  | .nil => True
  | .node h _ _ _ l r =>
      h = 1 + max l.height r.height ∧
      l.height ≤ r.height + 1 ∧
      r.height ≤ l.height + 1 ∧
      l.IsAVL ∧ r.IsAVL

/-- Full balanced-BST and cached-size invariant with height factor `C_tree`. -/
def PersistentSizeTree.WellFormed {κ α : Type} [LinearOrder κ]
    (C_tree : ℕ) (t : PersistentSizeTree κ α) : Prop :=
  t.WellSized ∧
  t.IsAVL ∧
  (t.toList.map Prod.fst).Pairwise (· < ·) ∧
  t.height ≤ C_tree * Nat.log 2 (t.size + 1)

/-- Standard BST key lookup returning `(ans, steps)` with step count along the root-to-node path. -/
def PersistentSizeTree.lookupWithSteps {κ α : Type} [LinearOrder κ] :
    PersistentSizeTree κ α → κ → Option α × ℕ
  | .nil, _ => (none, 1)
  | .node _ _ k₀ v₀ l r, k =>
      if k < k₀ then
        let res := l.lookupWithSteps k
        (res.1, res.2 + 1)
      else if k₀ < k then
        let res := r.lookupWithSteps k
        (res.1, res.2 + 1)
      else
        (some v₀, 1)

/-- Order-statistic selection by 0-indexed rank `rk` descending via cached `left.size`
(`subtreeSize`), returning `(entry?, steps)` for uniform rank sampling over `Fin t.size`. -/
def PersistentSizeTree.selectByRankWithSteps {κ α : Type} :
    PersistentSizeTree κ α → ℕ → Option (κ × α) × ℕ
  | .nil, _ => (none, 1)
  | .node _ _ k₀ v₀ l r, rk =>
      if rk < l.size then
        let res := l.selectByRankWithSteps rk
        (res.1, res.2 + 1)
      else if rk = l.size then
        (some (k₀, v₀), 1)
      else
        let res := r.selectByRankWithSteps (rk - l.size - 1)
        (res.1, res.2 + 1)

/-- Specification of persistent balanced-tree update operations `(insertTree, eraseTree)` with
cached subtree sizes and `O(log(|t| + 1))` worst-case step bounds (retaining any old `t` as an
immutable snapshot in `O(1)` time). -/
def IsPersistentBalancedSizeTreeOps (C_tree : ℕ) (κ α : Type) [LinearOrder κ]
    (insertTree : PersistentSizeTree κ α → κ → α → PersistentSizeTree κ α × ℕ)
    (eraseTree : PersistentSizeTree κ α → κ → PersistentSizeTree κ α × ℕ) : Prop :=
  PersistentSizeTree.WellFormed C_tree (.nil : PersistentSizeTree κ α) ∧
  ∀ t : PersistentSizeTree κ α,
    t.WellFormed C_tree →
      t.size = t.toList.length ∧
      (∀ k : κ,
        let res := t.lookupWithSteps k
        (∀ v : α, res.1 = some v ↔ (k, v) ∈ t.toList) ∧
        res.2 ≤ C_tree * (Nat.log 2 (t.size + 1) + 1)) ∧
      (∀ rk : Fin t.size,
        let res := t.selectByRankWithSteps rk.val
        res.1 = t.toList[rk.val]? ∧
        res.1.isSome = true ∧
        res.2 ≤ C_tree * (Nat.log 2 (t.size + 1) + 1)) ∧
      (∀ (k : κ) (v : α),
        let out := insertTree t k v
        out.1.WellFormed C_tree ∧
        (∀ kv : κ × α, kv ∈ out.1.toList ↔ kv = (k, v) ∨ (kv.1 ≠ k ∧ kv ∈ t.toList)) ∧
        out.2 ≤ C_tree * (Nat.log 2 (t.size + 1) + 1)) ∧
      (∀ k : κ,
        let out := eraseTree t k
        out.1.WellFormed C_tree ∧
        (∀ kv : κ × α, kv ∈ out.1.toList ↔ kv ∈ t.toList ∧ kv.1 ≠ k) ∧
        out.2 ≤ C_tree * (Nat.log 2 (t.size + 1) + 1))

/-! ### 2. Lifetime-tagged pool records and local dynamic angular search interface -/

open Classical in
/-- Invariant that `records : Finset (ι × ℕ)` tags each active identity in `S : Finset ι` with a
distinct insertion lifetime strictly below `nextLife`. -/
def IsValidLifetimePool {ι : Type}
    (S : Finset ι) (records : Finset (ι × ℕ)) (nextLife : ℕ) : Prop :=
  records.image Prod.fst = S ∧
  Set.InjOn Prod.fst (records : Set (ι × ℕ)) ∧
  Set.InjOn Prod.snd (records : Set (ι × ℕ)) ∧
  (∀ r ∈ records, r.2 < nextLife)

/-- Stateful local dynamic angular search interface invoked by Algorithm 2 (`InsertOriginal` and
`DeleteOriginal`) across retained configurations at a node, whose own flat background jobs (from
Lemma 7.1) are included in its per-operation work bound. -/
structure LocalDynamicSearchInterface (d : ℕ) (ι IdxState : Type) : Type where
  initIdx : IdxState
  insertUnmatched : ShellConfig → MatchingSide → ι → IdxState → IdxState × ℝ
  deleteUnmatched : ShellConfig → MatchingSide → ι → IdxState → IdxState × ℝ
  queryOpposite :
    ChainNode d → ShellConfig → MatchingSide → Finset ι → ι → IdxState →
      Option ι × IdxState × ℝ

/-- Operation-bound and angular-search promise specification for `LocalDynamicSearchInterface`:
every primitive operation (`insertUnmatched`, `deleteUnmatched`, `queryOpposite`) takes nonnegative
work at most `A_n * P_search` (including its own flat jobs), and every opposite-side query on an
unmatched set `U_opp` of size at most `n` in a positive-variance retained configuration satisfies
`SatisfiesConfigSearchPromise`. -/
def SatisfiesLocalDynamicSearchBound {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (n : ℕ) (params : LocalScaleParams) (A_n P_search : ℝ)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState) : Prop :=
  (∀ cfg side x idx,
    let out := dynSearch.insertUnmatched cfg side x idx
    0 ≤ out.2 ∧ out.2 ≤ A_n * P_search) ∧
  (∀ cfg side x idx,
    let out := dynSearch.deleteUnmatched cfg side x idx
    0 ≤ out.2 ∧ out.2 ≤ A_n * P_search) ∧
  (∀ ball cfg side U_opp v_id idx,
    let out := dynSearch.queryOpposite ball cfg side U_opp v_id idx
    0 ≤ out.2.2 ∧ out.2.2 ≤ A_n * P_search ∧
    (0 < ball.V →
      cfg ∈ params.retainedConfigs ball.V →
      U_opp.card ≤ n →
      SatisfiesConfigSearchPromise pts params.m0 params.γ params.lam
        ball.o ball.V cfg.j cfg.k cfg.ℓ U_opp v_id out.1))

/-- Canonical duplicate-free enumeration of `allShellConfigs m0 K J`. -/
def canonicalShellConfigList (m0 : ℕ) (K : ℤ) (J : ℕ) : List ShellConfig :=
  (List.range m0).flatMap (fun j0 =>
    (List.range (maxShellIndex m0 K)).flatMap (fun k0 =>
      (List.range (J + 1)).map (fun ℓ =>
        { j := j0 + 1, k := k0 + 1, ℓ := ℓ })))

open Classical in
/-- Execute `Attach(v)` in configuration `cfg` at node `ball` by invoking `dynSearch.queryOpposite`
followed by `deleteUnmatched` (on a match `some w`) or `insertUnmatched` (on `none`). -/
noncomputable def attachCopyViaSearch {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (cfg : ShellConfig)
    (st : LocalMatchingState ι) (idx : IdxState) (v : CopyVertex ι) :
    LocalMatchingState ι × IdxState × ℝ :=
  let qOut := dynSearch.queryOpposite ball cfg v.side (st.oppositeIndexSet v.side) v.id idx
  let ans := qOut.1
  let idx₁ := qOut.2.1
  let w₁ := qOut.2.2
  let updOut :=
    match ans with
    | some w => dynSearch.deleteUnmatched cfg v.side.opposite w idx₁
    | none => dynSearch.insertUnmatched cfg v.side v.id idx₁
  (attachStep pts st v ans, updOut.1, w₁ + updOut.2)

open Classical in
/-- Execute `InsertOriginal(p)` in configuration `cfg` at node `ball` via `dynSearch` (attaching
applicable left copy then applicable right copy). -/
noncomputable def insertOriginalViaSearch {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (cfg : ShellConfig)
    (st : LocalMatchingState ι) (idx : IdxState) (p : ι) :
    LocalMatchingState ι × IdxState × ℝ :=
  let leftOut :=
    if hasApplicableLeftCopy params.m0 ball.o ball.V cfg.j (pts p) then
      attachCopyViaSearch pts dynSearch ball cfg st idx ⟨.left, p⟩
    else
      (st, idx, 0)
  let rightOut :=
    if hasApplicableRightCopy params.m0 ball.o ball.V params.K cfg.k (pts p) then
      attachCopyViaSearch pts dynSearch ball cfg leftOut.1 leftOut.2.1 ⟨.right, p⟩
    else
      (leftOut.1, leftOut.2.1, 0)
  (rightOut.1, rightOut.2.1, leftOut.2.2 + rightOut.2.2)

open Classical in
/-- Repair surviving former partners `F` via `dynSearch` during `DeleteOriginal(p)`. -/
noncomputable def repairPartnersViaSearch {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (cfg : ShellConfig) :
    LocalMatchingState ι → IdxState → List (CopyVertex ι) →
      LocalMatchingState ι × IdxState × ℝ
  | st, idx, [] => (st, idx, 0)
  | st, idx, u :: us =>
      if st.isCopyMatched u ∨ st.isCopyInIndex u then
        repairPartnersViaSearch pts dynSearch ball cfg st idx us
      else
        let att := attachCopyViaSearch pts dynSearch ball cfg st idx u
        let rem := repairPartnersViaSearch pts dynSearch ball cfg att.1 att.2.1 us
        (rem.1, rem.2.1, att.2.2 + rem.2.2)

open Classical in
/-- Execute `DeleteOriginal(p)` in configuration `cfg` at node `ball` via `dynSearch`. -/
noncomputable def deleteOriginalViaSearch {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (cfg : ShellConfig)
    (st : LocalMatchingState ι) (idx : IdxState) (p : ι) :
    LocalMatchingState ι × IdxState × ℝ :=
  let dLeft :=
    if st.isCopyInIndex ⟨.left, p⟩ then
      dynSearch.deleteUnmatched cfg .left p idx
    else
      (idx, 0)
  let dRight :=
    if st.isCopyInIndex ⟨.right, p⟩ then
      dynSearch.deleteUnmatched cfg .right p dLeft.1
    else
      (dLeft.1, 0)
  let rep :=
    repairPartnersViaSearch pts dynSearch ball cfg
      (removeCopiesFromState st p) dRight.1 (survivingFormerPartners st p)
  (rep.1, rep.2.1, dLeft.2 + dRight.2 + rep.2.2)

open Classical in
/-- Commit both matching copies of `p` across every retained configuration at `ball` via
`insertOriginalViaSearch`, charging `A_n` per configuration inspected plus all dynamic search work. -/
noncomputable def insertAllRetainedConfigs {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (A_n : ℝ)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (p : ι)
    (states : ShellConfig → LocalMatchingState ι) (idx : IdxState) :
    (ShellConfig → LocalMatchingState ι) × IdxState × ℝ :=
  (canonicalShellConfigList params.m0 params.K params.J).foldl
    (fun acc cfg =>
      let curStates := acc.1
      let curIdx := acc.2.1
      let curWork := acc.2.2
      if 0 < ball.V ∧ cfg.SatisfiesRetention params.m0 params.γ params.lam ball.V then
        let out := insertOriginalViaSearch pts params dynSearch ball cfg (curStates cfg) curIdx p
        (Function.update curStates cfg out.1, out.2.1, curWork + A_n + out.2.2)
      else
        (curStates, curIdx, curWork + A_n))
    (states, idx, 0)

open Classical in
/-- Remove `p`'s copies and repair former partners across every retained configuration at `ball`
via `deleteOriginalViaSearch`, charging `A_n` per configuration inspected plus all dynamic search
work. -/
noncomputable def deleteAllRetainedConfigs {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (A_n : ℝ)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (p : ι)
    (states : ShellConfig → LocalMatchingState ι) (idx : IdxState) :
    (ShellConfig → LocalMatchingState ι) × IdxState × ℝ :=
  (canonicalShellConfigList params.m0 params.K params.J).foldl
    (fun acc cfg =>
      let curStates := acc.1
      let curIdx := acc.2.1
      let curWork := acc.2.2
      if 0 < ball.V ∧ cfg.SatisfiesRetention params.m0 params.γ params.lam ball.V then
        let out := deleteOriginalViaSearch pts dynSearch ball cfg (curStates cfg) curIdx p
        (Function.update curStates cfg out.1, out.2.1, curWork + A_n + out.2.2)
      else
        (curStates, curIdx, curWork + A_n))
    (states, idx, 0)

/-! ### 3. Two-scan level construction state machine and per-lifetime flags -/

/-- Phase of background construction for an opened large residual level:
- `scan1`: scans every immutable birth record in `remBirth` (even if dead) to accumulate
  `birthCoreCount` and `maxBirthRadius`, while indexing active unindexed records into `radiusDict`;
- `scan2`: with fixed `ball` and retained snapshot `scan2Snapshot`, scans `remScan2` to classify
  active unclassified records into `childPool` and local angular/matching records;
- `ready`: both scans complete (`ball` fixed, `radiusDict`, `childPool`, and local matchings live). -/
inductive TwoScanPhase (d : ℕ) (ι : Type) : Type
  | scan1
      (remBirth : List (ι × ℕ))
      (birthCoreCount : ℕ)
      (maxBirthRadius : ℝ)
  | scan2
      (ball : ChainNode d)
      (scan2Snapshot : List (ι × ℕ))
      (remScan2 : List (ι × ℕ))
  | ready
      (ball : ChainNode d)

/-- Full generation-local state of the two-scan level construction for one opened large residual
level, maintaining per-lifetime `heapIndexed` and `classified` flags, the current radius dictionary
`radiusDict`, the outside-ball `childPool`, and local configuration matchings `localMatchings`. -/
structure TwoScanLevelState (d : ℕ) (ι IdxState : Type) : Type where
  activeRecords : Finset (ι × ℕ)
  nextLife : ℕ
  radiusDict : Finset (ι × ℕ)
  heapIndexed : Finset ℕ
  childPool : Finset (ι × ℕ)
  classified : Finset ℕ
  localMatchings : ShellConfig → LocalMatchingState ι
  searchIdx : IdxState
  phase : TwoScanPhase d ι
  cumWork : ℝ

/-- Initial `TwoScanLevelState` at level opening on immutable `birthSnapshotList`, charging the
opening setup cost `setupWork`. -/
noncomputable def initTwoScanLevelState (d : ℕ) {ι IdxState : Type}
    (birthSnapshotList : List (ι × ℕ)) (initNextLife : ℕ) (initIdx : IdxState)
    (setupWork : ℝ) : TwoScanLevelState d ι IdxState :=
  open Classical in
  { activeRecords := birthSnapshotList.toFinset
    nextLife := initNextLife
    radiusDict := ∅
    heapIndexed := ∅
    childPool := ∅
    classified := ∅
    localMatchings := fun _ => LocalMatchingState.empty ι
    searchIdx := initIdx
    phase := .scan1 birthSnapshotList 0 0
    cumWork := setupWork }

open Classical in
/-- Atomic classification of one active record `rec = (x, ℓ)` (`rec ∈ st.activeRecords`,
`ℓ ∉ st.classified`) under fixed `ball`: commits both matching copies in every applicable retained
configuration (when `optParams = some params`), the outside-ball child entry in `childPool`, and
the `classified` flag within a single update. -/
noncomputable def classifyActiveRecordAtomically {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (n : ℕ) (A_n : ℝ)
    (optParams : Option LocalScaleParams)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (rec : ι × ℕ)
    (st : TwoScanLevelState d ι IdxState) : TwoScanLevelState d ι IdxState :=
  let childPool' :=
    if pts rec.1 ∈ coreBall ball.o ball.V then st.childPool else insert rec st.childPool
  let classified' := insert rec.2 st.classified
  let matchOut :=
    match optParams with
    | none => (st.localMatchings, st.searchIdx, (0 : ℝ))
    | some params =>
        insertAllRetainedConfigs pts params A_n dynSearch ball rec.1 st.localMatchings st.searchIdx
  let treeWork := (1 + Real.log (n : ℝ)) * A_n
  { st with
    childPool := childPool'
    classified := classified'
    localMatchings := matchOut.1
    searchIdx := matchOut.2.1
    cumWork := st.cumWork + treeWork + matchOut.2.2 }

open Classical in
/-- Atomic removal of deleted classified record(s) `delRecords` for deleted identity `id` under
fixed `ball`: removes classified record(s) from `childPool`, clears their `classified` flags, and
executes `DeleteOriginal(id)` across every retained configuration. -/
noncomputable def removeClassifiedDeletedAtomically {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (n : ℕ) (A_n : ℝ)
    (optParams : Option LocalScaleParams)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (id : ι) (delRecords : Finset (ι × ℕ))
    (st : TwoScanLevelState d ι IdxState) : TwoScanLevelState d ι IdxState :=
  let childPool' := st.childPool \ delRecords
  let classified' := st.classified \ (delRecords.image Prod.snd)
  let matchOut :=
    match optParams with
    | none => (st.localMatchings, st.searchIdx, (0 : ℝ))
    | some params =>
        deleteAllRetainedConfigs pts params A_n dynSearch ball id st.localMatchings st.searchIdx
  let treeWork := (1 + Real.log (n : ℝ)) * A_n
  { st with
    childPool := childPool'
    classified := classified'
    localMatchings := matchOut.1
    searchIdx := matchOut.2.1
    cumWork := st.cumWork + treeWork + matchOut.2.2 }

open Classical in
/-- Process an arriving `PoolUpdateEvent ι` on a `TwoScanLevelState`:
- `externalInsert id`: creates fresh lifetime `(id, nextLife)`, indexes into `radiusDict` and
  `heapIndexed` immediately, and if the ball is already fixed (`scan2` or `ready`), classifies the
  record immediately;
- `externalDelete id`: removes `id`'s active record, deletes from `radiusDict` only if its lifetime
  is in `heapIndexed`, and if the ball is fixed and its lifetime is in `classified`, removes its
  classified child and matching records;
- `virtualValueDelete` / `unaffected`: leaves the pool and level state unchanged (`0` arrival work). -/
noncomputable def applyPoolArrivalStep {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (n : ℕ) (A_n : ℝ)
    (optParams : Option LocalScaleParams)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ev : PoolUpdateEvent ι)
    (st : TwoScanLevelState d ι IdxState) : TwoScanLevelState d ι IdxState :=
  let treeWork := (1 + Real.log (n : ℝ)) * A_n
  match ev with
  | .externalInsert id =>
      let rec_new : ι × ℕ := (id, st.nextLife)
      let st₁ : TwoScanLevelState d ι IdxState :=
        { st with
          activeRecords := insert rec_new st.activeRecords
          nextLife := st.nextLife + 1
          radiusDict := insert rec_new st.radiusDict
          heapIndexed := insert rec_new.2 st.heapIndexed
          cumWork := st.cumWork + 2 * treeWork }
      match st₁.phase with
      | .scan1 _ _ _ => st₁
      | .scan2 ball _ _ =>
          classifyActiveRecordAtomically pts n A_n optParams dynSearch ball rec_new st₁
      | .ready ball =>
          classifyActiveRecordAtomically pts n A_n optParams dynSearch ball rec_new st₁
  | .externalDelete id =>
      let delRecords := st.activeRecords.filter (fun r => r.1 = id)
      let active' := st.activeRecords.filter (fun r => r.1 ≠ id)
      let isHeapIdx : Prop := ∃ r ∈ delRecords, r.2 ∈ st.heapIndexed
      let radiusDict' := if isHeapIdx then st.radiusDict \ delRecords else st.radiusDict
      let heapIndexed' :=
        if isHeapIdx then st.heapIndexed \ (delRecords.image Prod.snd) else st.heapIndexed
      let heapWork := if isHeapIdx then treeWork else 0
      let st₁ : TwoScanLevelState d ι IdxState :=
        { st with
          activeRecords := active'
          radiusDict := radiusDict'
          heapIndexed := heapIndexed'
          cumWork := st.cumWork + treeWork + heapWork }
      let isCls : Prop := ∃ r ∈ delRecords, r.2 ∈ st₁.classified
      match st₁.phase with
      | .scan1 _ _ _ => st₁
      | .scan2 ball _ _ =>
          if isCls then
            removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁
          else
            st₁
      | .ready ball =>
          if isCls then
            removeClassifiedDeletedAtomically pts n A_n optParams dynSearch ball id delRecords st₁
          else
            st₁
  | .virtualValueDelete => st
  | .unaffected => st

open Classical in
/-- Helper next state for `scan1Record`. -/
noncomputable def scan1RecordNextState {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (n : ℕ) (A_n : ℝ) (prov : ChainNode d)
    (rec : ι × ℕ) (rest : List (ι × ℕ)) (coreCnt : ℕ) (maxR : ℝ)
    (st : TwoScanLevelState d ι IdxState) : TwoScanLevelState d ι IdxState :=
  let coreCnt' := if pts rec.1 ∈ coreBall prov.o prov.V then coreCnt + 1 else coreCnt
  let maxR' := max maxR ‖pts rec.1 - prov.o‖
  let shouldIdx : Prop := rec ∈ st.activeRecords ∧ rec.2 ∉ st.heapIndexed
  let radiusDict' := if shouldIdx then insert rec st.radiusDict else st.radiusDict
  let heapIndexed' := if shouldIdx then insert rec.2 st.heapIndexed else st.heapIndexed
  let treeWork := (1 + Real.log (n : ℝ)) * A_n
  { st with
    radiusDict := radiusDict'
    heapIndexed := heapIndexed'
    phase := .scan1 rest coreCnt' maxR'
    cumWork := st.cumWork + treeWork }

open Classical in
/-- Helper next state for `fixBallAndSnapshot`. -/
noncomputable def fixBallSnapshotNextState {d : ℕ} {ι IdxState : Type}
    (α : ℝ) (n m : ℕ) (A_n : ℝ) (prov : ChainNode d)
    (coreCnt : ℕ) (maxR : ℝ) (scan2Snap : List (ι × ℕ))
    (st : TwoScanLevelState d ι IdxState) : TwoScanLevelState d ι IdxState :=
  let ball : ChainNode d :=
    if α * (m : ℝ) / 2 ≤ (coreCnt : ℝ) then
      prov
    else
      { o := prov.o, V := maxR ^ 2, V_nonneg := sq_nonneg _ }
  let treeWork := (1 + Real.log (n : ℝ)) * A_n
  { st with
    phase := .scan2 ball scan2Snap scan2Snap
    cumWork := st.cumWork + treeWork }

open Classical in
/-- Helper next state for `scan2Record`. -/
noncomputable def scan2RecordNextState {d : ℕ} {ι IdxState : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (n : ℕ) (A_n : ℝ)
    (optParams : Option LocalScaleParams)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState)
    (ball : ChainNode d) (scan2Snap : List (ι × ℕ))
    (rec : ι × ℕ) (rest : List (ι × ℕ))
    (st : TwoScanLevelState d ι IdxState) : TwoScanLevelState d ι IdxState :=
  let stAdv := { st with phase := .scan2 ball scan2Snap rest }
  if rec ∈ stAdv.activeRecords ∧ rec.2 ∉ stAdv.classified then
    classifyActiveRecordAtomically pts n A_n optParams dynSearch ball rec stAdv
  else
    { stAdv with cumWork := stAdv.cumWork + (1 + Real.log (n : ℝ)) * A_n }

open Classical in
/-- Single atomic background scan transition on a `TwoScanLevelState` (with birth size `m` and
provisional center `prov`):
- `scan1Record`: examines the next immutable birth record for `birthCoreCount` and `maxBirthRadius`
  (even if its lifetime has ended), and indexes it into `radiusDict` iff active and not yet
  heap-indexed;
- `fixBallAndSnapshot`: fixes `ball` from `birthCoreCount` and `maxBirthRadius` and retains an
  immutable snapshot `scan2Snap` of the then-current `activeRecords`;
- `scan2Record`: examines the next record of `scan2Snap`, classifying it atomically iff active and
  its `classified` flag is unset;
- `finishScan2`: transitions from `.scan2 ball scan2Snap []` to `.ready ball`. -/
inductive TwoScanBgStep {d : ℕ} {ι IdxState : Type}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (n m : ℕ) (A_n : ℝ) (prov : ChainNode d)
    (optParams : Option LocalScaleParams)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState) :
    TwoScanLevelState d ι IdxState → TwoScanLevelState d ι IdxState → Prop
  | scan1Record (st : TwoScanLevelState d ι IdxState)
      (rec : ι × ℕ) (rest : List (ι × ℕ)) (coreCnt : ℕ) (maxR : ℝ) :
      st.phase = .scan1 (rec :: rest) coreCnt maxR →
      TwoScanBgStep α pts n m A_n prov optParams dynSearch st
        (scan1RecordNextState pts n A_n prov rec rest coreCnt maxR st)
  | fixBallAndSnapshot (st : TwoScanLevelState d ι IdxState)
      (coreCnt : ℕ) (maxR : ℝ) (scan2Snap : List (ι × ℕ)) :
      st.phase = .scan1 [] coreCnt maxR →
      scan2Snap.Nodup →
      scan2Snap.toFinset = st.activeRecords →
      TwoScanBgStep α pts n m A_n prov optParams dynSearch st
        (fixBallSnapshotNextState α n m A_n prov coreCnt maxR scan2Snap st)
  | scan2Record (st : TwoScanLevelState d ι IdxState)
      (ball : ChainNode d) (scan2Snap : List (ι × ℕ))
      (rec : ι × ℕ) (rest : List (ι × ℕ)) :
      st.phase = .scan2 ball scan2Snap (rec :: rest) →
      TwoScanBgStep α pts n m A_n prov optParams dynSearch st
        (scan2RecordNextState pts n A_n optParams dynSearch ball scan2Snap rec rest st)
  | finishScan2 (st : TwoScanLevelState d ι IdxState)
      (ball : ChainNode d) (scan2Snap : List (ι × ℕ)) :
      st.phase = .scan2 ball scan2Snap [] →
      TwoScanBgStep α pts n m A_n prov optParams dynSearch st
        { st with
          phase := .ready ball
          cumWork := st.cumWork + (1 + Real.log (n : ℝ)) * A_n }

/-- Multi-step background scan chain executed within a single affected root tick. -/
inductive TwoScanBgChain {d : ℕ} {ι IdxState : Type}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d))
    (n m : ℕ) (A_n : ℝ) (prov : ChainNode d)
    (optParams : Option LocalScaleParams)
    (dynSearch : LocalDynamicSearchInterface d ι IdxState) :
    TwoScanLevelState d ι IdxState → TwoScanLevelState d ι IdxState → Prop
  | refl (st : TwoScanLevelState d ι IdxState) :
      TwoScanBgChain α pts n m A_n prov optParams dynSearch st st
  | step {st₁ st₂ st₃ : TwoScanLevelState d ι IdxState} :
      TwoScanBgStep α pts n m A_n prov optParams dynSearch st₁ st₂ →
      TwoScanBgChain α pts n m A_n prov optParams dynSearch st₂ st₃ →
      TwoScanBgChain α pts n m A_n prov optParams dynSearch st₁ st₃

/-- Node-level polynomial work factor `P_loc` dominating persistent balanced-tree / heap operations
(`1 + log n`) and, when `optParams = some params` (`BackgroundIndexMode.radiusDictAndLocalSearch`),
the configuration count times the dynamic search factor `P_search`. -/
def ValidNodeWorkFactor (n : ℕ) (optParams : Option LocalScaleParams)
    (P_search P_loc : ℝ) : Prop :=
  1 ≤ P_search ∧
  match optParams with
  | none => 1 + Real.log (n : ℝ) ≤ P_loc
  | some params =>
      1 + Real.log (n : ℝ) +
        (((allShellConfigs params.m0 params.K params.J).card + 1 : ℕ) : ℝ) * P_search ≤ P_loc

open Classical in
/-- Claim (Sec. C.2: Two-scan level construction and tick completion bound (11)) (paper p.53). Exactly the paper's statement, as a Prop. -/
def S_claim_C_2_scans : Prop :=
  (∃ C_tree : ℕ, 1 ≤ C_tree ∧
    ∀ (κ α_val : Type) [LinearOrder κ],
      ∃ (insertTree : PersistentSizeTree κ α_val → κ → α_val → PersistentSizeTree κ α_val × ℕ)
        (eraseTree : PersistentSizeTree κ α_val → κ → PersistentSizeTree κ α_val × ℕ),
        IsPersistentBalancedSizeTreeOps C_tree κ α_val insertTree eraseTree) ∧
  (∃ (C_scanWork C_tickMult : ℝ),
    1 ≤ C_scanWork ∧ 1 ≤ C_tickMult ∧
    ∀ (d n : ℕ) (ι IdxState : Type)
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α C : ℝ) (K₀ L : ℕ)
      (A_n P_search P_loc tickBudget : ℝ)
      (optParams : Option LocalScaleParams)
      (dynSearch : LocalDynamicSearchInterface d ι IdxState)
      (birthSnapshotList : List (ι × ℕ)) (initNextLife : ℕ)
      (res : SampledCenterResult d) (prov : ChainNode d)
      (T : ℕ)
      (S : Fin (T + 1) → Finset ι)
      (ev : Fin T → PoolUpdateEvent ι)
      (rootTick : Fin T → Bool)
      (_hn : 2 ≤ n)
      (_hα_pos : 0 < α)
      (_hα_le : α ≤ 1)
      (_hC_nonneg : 0 ≤ C)
      (_hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
      (_hA_n : 1 ≤ A_n)
      (_hP_loc : ValidNodeWorkFactor n optParams P_search P_loc)
      (_hSearch : ∀ params : LocalScaleParams, optParams = some params →
        SatisfiesLocalDynamicSearchBound pts n params A_n P_search dynSearch)
      (_hBirthNodup : birthSnapshotList.Nodup)
      (_hBirthPool : IsValidLifetimePool (S 0) birthSnapshotList.toFinset initNextLife)
      (_hLarge : IsLargeResidualLevel L (S 0).card)
      (_hProv : IsProvisionalCenter pts (S 0) res prov)
      (_hCap : ∀ s : Fin (T + 1), (S s).card ≤ n)
      (_hEv : ∀ t : Fin T, IsValidPoolUpdateEvent (S t.castSucc) (S t.succ) (ev t))
      (_hRootTick : ∀ t : Fin T, (ev t).isClockTick = true → rootTick t = true)
      (_hBudgetNonneg : 0 ≤ tickBudget),
      let S_birth := S 0
      let m := S_birth.card
      let fixedBall := applyBirthCoreFallback α pts S_birth prov
      let setupWork := C + ((d : ℝ) + Real.log (n : ℝ)) * (K₀ : ℝ) + A_n * P_loc
      let totalRootTicks := ((List.ofFn rootTick).filter (fun b => b = true)).length
      ∃ (st : Fin (T + 1) → TwoScanLevelState d ι IdxState) (b_req : ℕ),
        st 0 = initTwoScanLevelState d birthSnapshotList initNextLife dynSearch.initIdx setupWork ∧
        (∀ t : Fin T,
          let st_arr :=
            applyPoolArrivalStep pts n A_n optParams dynSearch (ev t) (st t.castSucc)
          if rootTick t = true then
            TwoScanBgChain α pts n m A_n prov optParams dynSearch st_arr (st t.succ) ∧
            (st t.succ).cumWork - st_arr.cumWork ≤ tickBudget
          else
            st t.succ = st_arr) ∧
        (st (Fin.last T)).cumWork ≤
          C_scanWork * ((m : ℝ) + (totalRootTicks : ℝ)) * A_n * P_loc ∧
        1 ≤ b_req ∧
        (b_req : ℝ) ≤ α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ)) ∧
        fixedBall.o = prov.o ∧
        PassesBirthCoreCheck α pts fixedBall S_birth ∧
        (∀ s : Fin (T + 1),
          IsValidLifetimePool (S s) (st s).activeRecords (st s).nextLife ∧
          (st s).radiusDict ⊆ (st s).activeRecords ∧
          (∀ r ∈ (st s).activeRecords, r ∈ (st s).radiusDict ↔ r.2 ∈ (st s).heapIndexed) ∧
          (∀ (coreCnt : ℕ) (maxR : ℝ),
            (st s).phase = .scan1 [] coreCnt maxR →
              coreCnt = (prov.core pts S_birth).card ∧
              maxR = nodeMaxRadius pts prov.o S_birth)) ∧
        (C_tickMult * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ * A_n * P_loc ≤ tickBudget →
          ∀ s : Fin (T + 1),
            b_req ≤ (((List.ofFn rootTick).take s.val).filter (fun b => b = true)).length →
              (st s).phase = .ready fixedBall) ∧
        (∀ (s : Fin (T + 1)) (ball : ChainNode d),
          (st s).phase = .ready ball →
            ball = fixedBall ∧
            (st s).radiusDict = (st s).activeRecords ∧
            (st s).radiusDict.image Prod.fst = S s ∧
            (st s).radiusDict.card = (S s).card ∧
            (st s).childPool =
              (st s).activeRecords.filter (fun r => pts r.1 ∉ coreBall fixedBall.o fixedBall.V) ∧
            (st s).childPool.image Prod.fst = fixedBall.residual pts (S s) ∧
            (st s).childPool.card = (fixedBall.residual pts (S s)).card ∧
            (∀ r ∈ (st s).activeRecords, r.2 ∈ (st s).classified) ∧
            (∀ params : LocalScaleParams, optParams = some params → 0 < fixedBall.V →
              ∀ cfg ∈ params.retainedConfigs fixedBall.V,
                ((st s).localMatchings cfg).SatisfiesInvariant pts
                  (params.leftVertices pts fixedBall.o fixedBall.V (S s) cfg.j)
                  (params.rightVertices pts fixedBall.o fixedBall.V (S s) cfg.k)
                  (params.weakEdges pts fixedBall.o fixedBall.V (S s) cfg.j cfg.k cfg.ℓ)
                  (params.strongEdges pts fixedBall.o fixedBall.V (S s) cfg.j cfg.k cfg.ℓ))) ∧
        (∀ s : Fin (T + 1),
          let b_s := (((List.ofFn rootTick).take s.val).filter (fun b => b = true)).length
          (b_s : ℝ) ≤ α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ)) →
            ((fixedBall.residual pts (S s)).card : ℝ) ≤
              (1 - α / 4) * ((m : ℝ) + (b_s : ℝ))))

end UL
