import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_dynamic_points_model
import UL.Def.def_halfspace_depth
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_core_witness_halfspaces
import UL.Def.def_node_chain_blocks
set_option autoImplicit false

namespace UL

open Classical in
/-- Claim (Appendix A: Deterministic depth and deletion survival of disjoint block certificates) (paper p.46). Exactly the paper's statement, as a Prop. -/
def S_claim_A_2_deletion_witness : Prop :=
  ∀ (d : ℕ) (hd : 1 ≤ d)
    (s₀ : ℕ) (hs₀ : 1 ≤ s₀)
    (ι : Type)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (P₀ : Finset ι)
    (hm : 2 * s₀ ≤ P₀.card)
    (hrat : ∀ p ∈ P₀, ∃ q : Fin d → ℚ, ratPointToEuclidean q = pts p)
    (o : EuclideanSpace ℝ (Fin d))
    (s : ℝ)
    (k : ℕ)
    (hk : (P₀.card : ℝ) / (4 * (s₀ : ℝ)) ≤ (k : ℝ))
    (certs : Fin k → BlockCertificate pts P₀ (liftedPoint o s))
    (hcard : ∀ i : Fin k, (certs i).B.card = s₀)
    (hdisj : ∀ i j : Fin k, i ≠ j → Disjoint (certs i).B (certs j).B),
    let z : EuclideanSpace ℝ (Fin (d + 1)) := liftedPoint o s
    let m : ℝ := P₀.card
    let β : ℝ := 1 / (4 * (s₀ : ℝ))
    let V : ℝ := liftVariance o s
    (β * m ≤ (halfspaceDepth (paraboloidLiftSet (fun p : P₀ => pts p.1)) z : ℝ)) ∧
    (∀ H : Set (EuclideanSpace ℝ (Fin (d + 1))),
      IsClosedHalfspace H → z ∈ H →
      ∀ i : Fin k, ∃ p ∈ (certs i).B, paraboloidLift (pts p) ∈ H) ∧
    (0 ≤ V) ∧
    (∀ (i : Fin k) (q : EuclideanSpace ℝ (Fin d)),
      ∑ p ∈ (certs i).B, (certs i).coeff p * ‖pts p - q‖ ^ 2 = ‖q - o‖ ^ 2 + V) ∧
    (∀ (T : ℕ) (seq : Fin (T + 1) → Finset ι),
      (T : ℝ) ≤ β * m / 16 →
      seq 0 = P₀ →
      (∀ r : Fin T, IsInputChange (seq r.castSucc) (seq r.succ)) →
      15 * β * m / 16 ≤
        ((Finset.univ.filter (fun i : Fin k =>
          ∀ t : Fin (T + 1), (certs i).IsIntact (seq t))).card : ℝ)) ∧
    (∀ (S : Finset ι) (i : Fin k),
      (certs i).IsIntact S →
      (∃ p ∈ (certs i).B, p ∈ nodeCore pts o V S) ∧
      (∀ q : EuclideanSpace ℝ (Fin d),
        ∃ p ∈ (certs i).B, p ∈ S ∧ IsVarianceWitness o V q (pts p))) ∧
    (∀ j : ι, j ∉ P₀ → ∀ i : Fin k, j ∉ (certs i).B) ∧
    (∀ (T : ℕ) (seq : Fin (T + 1) → Finset ι),
      seq 0 = P₀ →
      (∀ r : Fin T,
        (∃ j : ι, (∀ u : Fin (T + 1), u ≤ r.castSucc → j ∉ seq u) ∧
          seq r.succ = insert j (seq r.castSucc)) ∨
        (∃ j ∈ seq r.castSucc, seq r.succ = (seq r.castSucc).erase j)) →
      ∀ (i : Fin k) (t₁ t₂ : Fin (T + 1)),
        t₁ ≤ t₂ → ¬ (certs i).IsIntact (seq t₁) → ¬ (certs i).IsIntact (seq t₂)) ∧
    (∀ (n T : ℕ) (P_dyn : Fin (T + 1) → DynamicPointSet d)
       (ops : Fin T → DynamicUpdate d) (handles : Fin T → Option ℕ)
       (ltOf : ι → ℕ),
      (P_dyn 0).WellFormed n →
      (∀ p ∈ P₀, ltOf p ∈ (P_dyn 0).activeIds.image (P_dyn 0).lifetimeOfId) →
      (∀ r : Fin T,
        applyDynamicUpdate (P_dyn r.castSucc) (ops r) (handles r) = some (P_dyn r.succ)) →
      (∀ (r : Fin T) (id : ℕ) (extName : List Bool) (pt : EuclideanSpace ℝ (Fin d)),
        ops r = DynamicUpdate.insert id extName pt →
        (∀ u : Fin (T + 1), u ≤ r.castSucc → id ∈ (P_dyn u).activeIds →
          (P_dyn u).lifetimeOfId id < (P_dyn r.succ).lifetimeOfId id) ∧
        (∀ i : Fin k, (P_dyn r.succ).lifetimeOfId id ∉ ((certs i).B).image ltOf)) ∧
      (∀ (i : Fin k) (t₁ t₂ : Fin (T + 1)),
        t₁ ≤ t₂ →
        ¬ IsIntactBlock (((certs i).B).image ltOf)
            ((P_dyn t₁).activeIds.image (P_dyn t₁).lifetimeOfId) →
        ¬ IsIntactBlock (((certs i).B).image ltOf)
            ((P_dyn t₂).activeIds.image (P_dyn t₂).lifetimeOfId)))

end UL
