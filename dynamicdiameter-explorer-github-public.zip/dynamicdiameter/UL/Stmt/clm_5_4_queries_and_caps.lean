import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_6_search_interface
set_option autoImplicit false

namespace UL

/-- Claim (Sec. 5.4: Normalized lattice direction net and exact rational cap comparison) (paper p.21). Exactly the paper's statement, as a Prop. -/
def S_clm_5_4_queries_and_caps : Prop :=
  ∃ C_net : ℝ, 0 < C_net ∧
    ∀ (d : ℕ), 1 ≤ d →
    ∀ (a b : ℚ) (g : ℝ) (e A B : ℚ),
      0 ≤ b →
      b < a →
      a ≤ 1 →
      0 < g →
      g ≤ (a : ℝ) - (1 + g) * (b : ℝ) →
      0 < e →
      (e : ℝ) ≤ g / 16 →
      0 < A →
      0 ≤ B →
      A ^ 2 + B ^ 2 = 1 →
      let h : ℝ := g - 11 * (e : ℝ)
      let padData : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
        fun u => liftedPoint ((A : ℝ) • u) (B : ℝ)
      let padQuery : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
        fun z_hat => liftedPoint ((A : ℝ) • z_hat) (-(B : ℝ))
      (∀ (u z z_hat : EuclideanSpace ℝ (Fin d)),
        IsUnitVec u → IsUnitVec z → IsUnitVec z_hat →
        ‖z_hat - z‖ ≤ (e : ℝ) / 8 →
        ((a : ℝ) ≤ inner ℝ z u → h ≤ inner ℝ (padQuery z_hat) (padData u)) ∧
        (inner ℝ z u ≤ (b : ℝ) → inner ℝ (padQuery z_hat) (padData u) < 0)) →
      (∃ (N_net : Finset (EuclideanSpace ℝ (Fin d)))
         (roundLat : EuclideanSpace ℝ (Fin d) → (Fin d → ℤ))
         (δ : ℝ),
        let roundDir : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
          fun z =>
            let v := ratPointToEuclidean (fun i => (roundLat z i : ℚ))
            ‖v‖⁻¹ • v
        N_net.Nonempty ∧
        (∀ z_hat ∈ N_net, IsUnitVec z_hat ∧
          ∃ m : Fin d → ℤ, m ≠ 0 ∧
            let v := ratPointToEuclidean (fun i => (m i : ℚ))
            z_hat = ‖v‖⁻¹ • v) ∧
        Real.log (N_net.card : ℝ) ≤ C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) ∧
        (∀ z : EuclideanSpace ℝ (Fin d), IsUnitVec z →
          roundLat z ≠ 0 ∧
          roundDir z ∈ N_net ∧
          IsUnitVec (roundDir z) ∧
          ‖roundDir z - z‖ ≤ (e : ℝ) / 8) ∧
        0 < δ ∧
        (∀ (u z : EuclideanSpace ℝ (Fin d)), IsUnitVec u → IsUnitVec z →
          IsUnitVec (padData u) ∧
          IsUnitVec (padQuery (roundDir z)) ∧
          ((a : ℝ) ≤ inner ℝ z u →
            h ≤ inner ℝ (padQuery (roundDir z)) (padData u) ∧ (b : ℝ) < inner ℝ z u) ∧
          (¬ ((b : ℝ) < inner ℝ z u) →
            inner ℝ (padQuery (roundDir z)) (padData u) ≤ -δ ∧
            inner ℝ (padQuery (roundDir z)) (padData u) < 0)) ∧
        (∀ (ι : Type) (u_pts : ι → EuclideanSpace ℝ (Fin d)) (P : Finset ι),
          (∀ i ∈ P, IsUnitVec (u_pts i)) →
          ∀ (z : EuclideanSpace ℝ (Fin d)), IsUnitVec z →
            let pts_pad : ι → EuclideanSpace ℝ (Fin (d + 1)) := fun i => padData (u_pts i)
            let z_pad : EuclideanSpace ℝ (Fin (d + 1)) := padQuery (roundDir z)
            let accept : ι → Prop := fun i => (b : ℝ) < inner ℝ z (u_pts i)
            (∀ i ∈ P, (a : ℝ) ≤ inner ℝ z (u_pts i) →
              IsSearchTarget pts_pad P h z_pad i ∧ accept i) ∧
            IsCompatibleTest pts_pad P z_pad accept ∧
            IsMarginCompatibleTest pts_pad P δ z_pad accept)) ∧
      (∀ (w : Fin d → ℚ), w ≠ 0 →
       ∀ (G : Fin (d + 1) → ℚ) (a₀ : ℚ),
        let w_E : EuclideanSpace ℝ (Fin d) := ratPointToEuclidean w
        let u_w : EuclideanSpace ℝ (Fin d) := ‖w_E‖⁻¹ • w_E
        let G_E : EuclideanSpace ℝ (Fin (d + 1)) := ratPointToEuclidean G
        let G_base : EuclideanSpace ℝ (Fin d) := liftedBase G_E
        let G_last : ℚ := G (Fin.last d)
        let L_val : ℚ := A * ∑ i : Fin d, G (Fin.castSucc i) * w i
        let R_coef : ℚ := a₀ - B * G_last
        let normSq : ℚ := ∑ i : Fin d, (w i) ^ 2
        IsUnitVec u_w ∧
        IsUnitVec (padData u_w) ∧
        ((a₀ : ℝ) ≤ inner ℝ G_E (padData u_w) ↔
          ((a₀ : ℝ) - (B : ℝ) * (G_last : ℝ)) * ‖w_E‖ ≤ (A : ℝ) * inner ℝ G_base w_E) ∧
        (((a₀ : ℝ) - (B : ℝ) * (G_last : ℝ)) * ‖w_E‖ ≤ (A : ℝ) * inner ℝ G_base w_E ↔
          ((0 ≤ R_coef ∧ 0 ≤ L_val ∧ R_coef ^ 2 * normSq ≤ L_val ^ 2) ∨
           (R_coef < 0 ∧ (0 ≤ L_val ∨ L_val ^ 2 ≤ R_coef ^ 2 * normSq)))))

end UL
