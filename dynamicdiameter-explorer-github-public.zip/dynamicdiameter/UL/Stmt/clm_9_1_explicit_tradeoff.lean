import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Def.def_explicit_tradeoff_curve
import UL.Def.def_6_search_interface
import UL.Def.def_6_search_exponents
import UL.Def.def_6_1_gaussian_filter
import UL.Def.def_7_birth_pool
import UL.Def.def_9_parameters
set_option autoImplicit false

namespace UL

/-- Index tuple `(r, s, k)` selecting copy `r`, tensor factor `s`, and base cap `k`. -/
abbrev clm91ExplicitCapIdx (R ℓ M₀ : ℕ) : Type :=
  Fin R × Fin ℓ × Fin M₀

/-- Discrete uniform random bit seed assigning `b` bits to each coordinate of each cap vector. -/
abbrev clm91ExplicitBitSeed (R ℓ M₀ D b : ℕ) : Type :=
  clm91ExplicitCapIdx R ℓ M₀ × Fin D × Fin b → Bool

/-- Eligible data base-cap indices in `(r, s)` for vector `p ∈ ℝ^D` at threshold `τ_d`. -/
noncomputable def clm91ExplicitDataBaseSet {D R ℓ M₀ : ℕ}
    (F : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_d : ℝ)
    (p : EuclideanSpace ℝ (Fin D)) (r : Fin R) (s : Fin ℓ) : Finset (Fin M₀) :=
  open Classical in
  Finset.univ.filter (fun k : Fin M₀ => gaussianDataTest τ_d (F (r, s, k)) p)

/-- Eligible query base-cap indices in `(r, s)` for vector `z ∈ ℝ^D` at threshold `τ_q`. -/
noncomputable def clm91ExplicitQueryBaseSet {D R ℓ M₀ : ℕ}
    (F : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_q : ℝ)
    (z : EuclideanSpace ℝ (Fin D)) (r : Fin R) (s : Fin ℓ) : Finset (Fin M₀) :=
  open Classical in
  Finset.univ.filter (fun k : Fin M₀ => gaussianDataTest τ_q (F (r, s, k)) z)

/-- Capped stored tuple set of point `i` in copy `r` (omitted when product exceeds `cap_u`). -/
noncomputable def clm91ExplicitStoredTuples {ι : Type} {D R ℓ M₀ : ℕ}
    (F : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_d : ℝ) (cap_u : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin D)) (r : Fin R) (i : ι) : Finset (Fin ℓ → Fin M₀) :=
  let prodSet := Fintype.piFinset (fun s : Fin ℓ => clm91ExplicitDataBaseSet F τ_d (pts i) r s)
  if prodSet.card ≤ cap_u then prodSet else ∅

/-- Per-point construction and deletion work across all `R` copies on cap family `F`. -/
noncomputable def clm91ExplicitPointDataWork {ι : Type} {D R ℓ M₀ : ℕ}
    (F : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_d : ℝ) (cap_u : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin D)) (i : ι) : ℕ :=
  R * ℓ * M₀ * D + ∑ r : Fin R, (clm91ExplicitStoredTuples F τ_d cap_u pts r i).card * ℓ

/-- Total index space (cap vectors plus nonempty bucket entries and deletion handles) on `F`. -/
noncomputable def clm91ExplicitIndexSpace {ι : Type} {D R ℓ M₀ : ℕ}
    (F : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_d : ℝ) (cap_u : ℕ)
    (gen : SearchGeneration ι D) : ℕ :=
  R * ℓ * M₀ * D +
    ∑ i ∈ gen.P₀, ∑ r : Fin R, (clm91ExplicitStoredTuples F τ_d cap_u gen.pts r i).card * ℓ

/-- Capped explicit-filter query evaluation across `R` copies, stopping each copy after `cap_q`
tuples or `cap_q` rejected candidate occurrences (testing each candidate before stopping). -/
noncomputable def clm91ExplicitCappedQuery {ι : Type} [DecidableEq ι] {D R ℓ M₀ : ℕ}
    (F : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d τ_q : ℝ) (cap_u cap_q : ℕ)
    (gen : SearchGeneration ι D) (P : Finset ι) (q : SearchQuery ι D) : Option ι :=
  open Classical in
  (List.finRange R).findSome? fun r =>
    let visitedTuples :=
      (Fintype.piFinset (fun s : Fin ℓ => clm91ExplicitQueryBaseSet F τ_q q.z r s)).toList.take cap_q
    let candidates := visitedTuples.flatMap fun tup =>
      ((gen.P₀ ∩ P).filter (fun i =>
        tup ∈ clm91ExplicitStoredTuples F τ_d cap_u gen.pts r i)).toList
    (candidates.take (cap_q + 1)).find? (fun i => decide (q.accept i))

/-- Query work (base-cap evaluations, visited tuples, and candidate tests) across `R` copies. -/
noncomputable def clm91ExplicitQueryWork {ι : Type} [DecidableEq ι] {D R ℓ M₀ : ℕ}
    (F : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d τ_q : ℝ) (cap_u cap_q : ℕ)
    (gen : SearchGeneration ι D) (P : Finset ι) (q : SearchQuery ι D) : ℕ :=
  open Classical in
  R * ℓ * M₀ * D + ∑ r : Fin R,
    let visitedTuples :=
      (Fintype.piFinset (fun s : Fin ℓ => clm91ExplicitQueryBaseSet F τ_q q.z r s)).toList.take cap_q
    let candidates := visitedTuples.flatMap fun tup =>
      ((gen.P₀ ∩ P).filter (fun i =>
        tup ∈ clm91ExplicitStoredTuples F τ_d cap_u gen.pts r i)).toList
    visitedTuples.length * ℓ + (candidates.take (cap_q + 1)).length

/-- Claim (Sec. 9.1: Construction cost and the absence of an exponent loss) (paper pp.39–40).
Exactly the paper's statement, as a Prop. -/
def S_clm_9_1_explicit_tradeoff : Prop :=
  ∀ (c : ℝ) (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2),
    -- (1) Fixed tensor depth ℓ ≥ 16/ρ, uniform Gaussian probability estimates over the compact
    -- range of h from Lemma 9.1 and h ≤ x ≤ 1, and base-family exponent I_h(x)/ℓ = (1 + u)/ℓ ≤ ρ/8:
    ((∃ ℓ : ℕ, 16 / rho_c c ≤ (ℓ : ℝ)) ∧
      (∀ (h_min : ℝ), 0 < h_min → h_min ≤ g_c c →
        g_c c < 1 ∧
        ∃ c_h : ℝ, 0 < c_h ∧
          ∀ (d : ℕ), 1 ≤ d →
            ∀ (h x t : ℝ), h_min ≤ h → h ≤ g_c c → h ≤ x → x ≤ 1 → 1 ≤ t →
              ∃ p_u p_q p₁ p₂ : ℝ,
                IsGaussianFilterProbs d h x t p_u p_q p₁ p₂ ∧
                p_u ≤ Real.exp (-(t ^ 2 / 2)) ∧
                p_q ≤ Real.exp (-(x ^ 2 * t ^ 2 / 2)) ∧
                c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2)) ≤ p₁ ∧
                p₂ ≤ Real.exp (-((1 + x ^ 2) * t ^ 2 / 2))) ∧
      (∀ (ℓ : ℕ), 16 / rho_c c ≤ (ℓ : ℝ) →
        ∀ (h x : ℝ), 0 < h → h < 1 → h ≤ x → x ≤ 1 →
          I_h h x / (ℓ : ℝ) = (1 + u_search h x) / (ℓ : ℝ) ∧
          (1 + u_search h x) / (ℓ : ℝ) ≤ rho_c c / 8)) ∧
    -- (2) Birth-pool explicit index bounds (m^u + m^{ρ/8})𝒫, (m^q + m^{ρ/8})𝒫, (m^{1+u} + m^{ρ/8})𝒫,
    -- storing only nonempty full filter buckets, with the implicit direction net contributing
    -- O(d log(d/e)) to amplification rather than its cardinality to space (never enumerated):
    (∀ (ℓ : ℕ), 16 / rho_c c ≤ (ℓ : ℝ) →
      ∀ (h_min : ℝ), 0 < h_min → h_min ≤ g_c c →
        -- (2a) Implicit direction net rounded without enumeration & O(d log(d/e)) amplification:
        (∃ (C_net : ℝ) (C_amp : ℝ → ℝ) (roundProg : ArithRAMStmt),
          0 < C_net ∧
          (∀ (p_succ : ℝ), 0 < p_succ → p_succ ≤ 1 → 0 < C_amp p_succ) ∧
          ∀ (d : ℕ), 1 ≤ d →
          ∀ (a b e : ℚ) (g_γ : ℝ),
            (0 : ℝ) ≤ (b : ℝ) → (b : ℝ) < (a : ℝ) → (a : ℝ) ≤ 1 →
            0 < g_γ → g_γ ≤ (a : ℝ) - (1 + g_γ) * (b : ℝ) →
            0 < e → (e : ℝ) ≤ g_γ / 16 →
            let h : ℝ := g_γ - 11 * (e : ℝ)
            h_min ≤ h → h ≤ g_c c →
            let mesh : ℚ := e / (8 * (Nat.ceil (Real.sqrt (d : ℝ)) : ℚ))
            ∃ (net : Finset (EuclideanSpace ℝ (Fin d)))
              (roundLat : EuclideanSpace ℝ (Fin d) → (Fin d → ℤ)),
              let roundVec : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
                fun z => ratPointToEuclidean (fun coord => (roundLat z coord : ℚ) * mesh)
              let roundDir : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
                fun z => ‖roundVec z‖⁻¹ • roundVec z
              net.Nonempty ∧
              (∀ z_hat ∈ net, IsUnitVec z_hat) ∧
              Real.log (net.card : ℝ) ≤ C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) ∧
              (∀ z : EuclideanSpace ℝ (Fin d), IsUnitVec z →
                roundLat z ≠ 0 ∧
                roundDir z ∈ net ∧
                IsUnitVec (roundDir z) ∧
                ‖roundDir z - z‖ ≤ (e : ℝ) / 8 ∧
                let inp_round : ArithRAMInput d :=
                  { intParams := [e.num, (e.den : ℤ)]
                    activeHandles := ∅
                    activeCoords := fun _ => 0
                    extraReals := List.ofFn (fun coord : Fin d => euclideanCoord z coord) }
                ∃ out_r : ArithRAMExecOutcome,
                  runArithRAMWithBits roundProg inp_round ArithRAMMemory.empty [] = some out_r ∧
                  (∀ coord : Fin d, out_r.mem.words.read (.heap 0 (coord.val : ℤ)) = roundLat z coord) ∧
                  (out_r.unitCost : ℝ) ≤ C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) ∧
                  (out_r.peakCellSpace : ℝ) ≤ C_net * (d : ℝ)) ∧
              (∀ (p_succ : ℝ), 0 < p_succ → p_succ ≤ 1 →
                ∀ (m : ℕ) (ε₀ : ℝ), 1 ≤ m → 0 < ε₀ → ε₀ < 1 / 2 →
                  ∃ R : ℕ,
                    1 ≤ R ∧
                    (R : ℝ) ≤ C_amp p_succ * (Real.log ((m : ℝ) / ε₀) + (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ))) ∧
                    (1 - p_succ) ^ R * (net.card : ℝ) * (m : ℝ) ≤ ε₀)) ∧
        -- (2b) Capped explicit birth-pool index storing only nonempty full filter buckets (without
        -- enumerating Q_net), with point work ≤ (m^u + m^{ρ/8})𝒫, query work ≤ (m^q + m^{ρ/8})𝒫,
        -- and space ≤ (m^{1+u} + m^{ρ/8})𝒫:
        (∀ (C_net' : ℝ), 0 ≤ C_net' →
          ∃ (P_bp : ℕ → ℕ → ℝ),
            IsBoundedByPoly2 P_bp ∧
            ∀ (d : ℕ), 1 ≤ d →
            ∀ (ι : Type) [DecidableEq ι] (gen : SearchGeneration ι (d + 1)),
              h_min ≤ gen.h → gen.h ≤ g_c c →
              ∀ (x e ε₀ : ℝ),
                gen.h ≤ x → x ≤ 1 →
                0 < e → e ≤ 1 →
                0 < ε₀ → ε₀ < 1 →
                ∀ (Q_net : Finset (EuclideanSpace ℝ (Fin (d + 1)))),
                  (∀ z ∈ Q_net, IsUnitVec z) →
                  (Q_net.card : ℝ) ≤ Real.exp (C_net' * (d : ℝ) * Real.log (2 * (d : ℝ) / e)) →
                  let m : ℕ := gen.m
                  let u : ℝ := u_search gen.h x
                  let q : ℝ := q_search gen.h x
                  let L_log : ℕ := Nat.ceil (Real.log (2 * (m : ℝ) / ε₀) + Real.log (2 / e))
                  let P_val : ℝ := P_bp d L_log
                  ∃ (R M₀ b B_prec cap_u cap_q : ℕ) (τ_d τ_q : ℚ)
                    (sampleCoord : (Fin b → Bool) → ℚ),
                    let N_bits : ℕ := R * ℓ * M₀ * (d + 1) * b
                    ∃ (equiv : (Fin N_bits → Bool) ≃ clm91ExplicitBitSeed R ℓ M₀ (d + 1) b)
                      (idx : CappedBirthPoolIndex (Fin N_bits → Bool) ι (d + 1) (Finset ι))
                      (pointBuildWork : (Fin N_bits → Bool) → ι → ℕ)
                      (storedBuckets : (Fin N_bits → Bool) → Fin R → (Fin ℓ → Fin M₀) → Finset ι)
                      (E_good : Set (Fin N_bits → Bool)),
                      1 ≤ R ∧ 1 ≤ M₀ ∧ 1 ≤ b ∧ 1 ≤ B_prec ∧ 1 ≤ N_bits ∧
                      (b : ℝ) ≤ P_val ∧
                      (B_prec : ℝ) ≤ P_val ∧
                      RatCoordBitBounded B_prec τ_d ∧
                      RatCoordBitBounded B_prec τ_q ∧
                      (∀ bits : Fin b → Bool, RatCoordBitBounded B_prec (sampleCoord bits)) ∧
                      ((R * ℓ * M₀ : ℕ) : ℝ) ≤ (m : ℝ) ^ (rho_c c / 8) * P_val ∧
                      (cap_u : ℝ) ≤ (m : ℝ) ^ u * P_val ∧
                      (cap_q : ℝ) ≤ (m : ℝ) ^ q * P_val ∧
                      idx.gen = gen ∧
                      1 - ε₀ ≤ ((PMF.uniformOfFintype (Fin N_bits → Bool)).toMeasure).real E_good ∧
                      (∀ ω : Fin N_bits → Bool,
                        let F_disc : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
                          fun capIdx => ratPointToEuclidean (fun j =>
                            sampleCoord (fun bitIdx => equiv ω (capIdx, j, bitIdx)))
                        let nonemptyBucketEntries : ℕ :=
                          open Classical in
                          ∑ r : Fin R,
                            ∑ tup ∈ Finset.univ.filter
                                (fun (tup' : Fin ℓ → Fin M₀) => (storedBuckets ω r tup').Nonempty),
                              (storedBuckets ω r tup).card * ℓ
                        let storedReprSpace : ℕ := R * ℓ * M₀ * (d + 1) + nonemptyBucketEntries
                        (∀ (r : Fin R) (tup : Fin ℓ → Fin M₀),
                          storedBuckets ω r tup =
                            open Classical in
                            gen.P₀.filter (fun i =>
                              tup ∈ clm91ExplicitStoredTuples F_disc (τ_d : ℝ) cap_u gen.pts r i)) ∧
                        (∀ i : ι,
                          pointBuildWork ω i =
                            clm91ExplicitPointDataWork F_disc (τ_d : ℝ) cap_u gen.pts i) ∧
                        storedReprSpace =
                          clm91ExplicitIndexSpace F_disc (τ_d : ℝ) cap_u gen ∧
                        idx.IsValidState ω gen.P₀ (idx.initState ω) ∧
                        idx.buildWork ω = ∑ i ∈ gen.P₀, pointBuildWork ω i ∧
                        (∀ i ∈ gen.P₀,
                          (pointBuildWork ω i : ℝ) ≤ ((m : ℝ) ^ u + (m : ℝ) ^ (rho_c c / 8)) * P_val) ∧
                        (storedReprSpace : ℝ) ≤ ((m : ℝ) ^ (1 + u) + (m : ℝ) ^ (rho_c c / 8)) * P_val ∧
                        idx.buildPeakSpace ω ≤ storedReprSpace ∧
                        (∀ (P : Finset ι) (st : Finset ι) (i : ι),
                          gen.IsSurvivingSubset P → idx.IsValidState ω P st → i ∈ P →
                            let dOut := idx.delete ω P st i
                            idx.IsValidState ω (P.erase i) dOut.nextState ∧
                            dOut.work =
                              clm91ExplicitPointDataWork F_disc (τ_d : ℝ) cap_u gen.pts i ∧
                            (dOut.work : ℝ) ≤ ((m : ℝ) ^ u + (m : ℝ) ^ (rho_c c / 8)) * P_val ∧
                            dOut.peakSpace ≤ storedReprSpace) ∧
                        (∀ (P : Finset ι) (st : Finset ι) (qry : SearchQuery ι (d + 1)),
                          gen.IsSurvivingSubset P → idx.IsValidState ω P st →
                            let qOut := idx.runQuery ω P st qry
                            qOut.answer =
                              clm91ExplicitCappedQuery F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P qry ∧
                            qOut.work =
                              clm91ExplicitQueryWork F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P qry ∧
                            qry.IsValidAnswer P qOut.answer ∧
                            (∀ i : ι, qOut.answer = some i →
                              ∃ (r : Fin R) (tup : Fin ℓ → Fin M₀), i ∈ storedBuckets ω r tup) ∧
                            (qOut.work : ℝ) ≤ ((m : ℝ) ^ q + (m : ℝ) ^ (rho_c c / 8)) * P_val ∧
                            qOut.peakSpace ≤ storedReprSpace ∧
                            (ω ∈ E_good → qry.z ∈ Q_net → gen.IsCompatible P qry →
                              gen.IsCorrectAnswer P qry qOut.answer))))) ∧
    -- (3) Exponent bounds m^q ≤ m^{Q_c(σ)} exp(O_c(log m / L)) = O_c(m^{Q_c(σ)}) and
    -- Q_c(σ) ≥ ρ ≥ σ so both maintenance and construction fit the same update budget:
    ((∀ (C_q : ℝ), 0 ≤ C_q →
        ∃ C_pow : ℝ, 1 ≤ C_pow ∧
          ∀ (n m : ℕ) (σ q : ℝ),
            2 ≤ n → 1 ≤ m → m ≤ n →
            0 ≤ σ → σ ≤ rho_c c →
            q ≤ Q_c c σ + C_q / (L_n n : ℝ) →
              (m : ℝ) ^ q ≤ (m : ℝ) ^ (Q_c c σ) * Real.exp (C_q * Real.log (m : ℝ) / (L_n n : ℝ)) ∧
              (m : ℝ) ^ (Q_c c σ) * Real.exp (C_q * Real.log (m : ℝ) / (L_n n : ℝ)) ≤
                C_pow * (m : ℝ) ^ (Q_c c σ)) ∧
      (∀ (σ : ℝ), 0 ≤ σ → σ ≤ rho_c c →
        rho_c c ≤ Q_c c σ ∧
        ∀ (n m : ℕ) (u : ℝ),
          2 ≤ n → 1 ≤ m → m ≤ n →
          0 ≤ u → u ≤ σ →
            ValidBirthPoolParams n m σ (Q_c c σ) ∧
            (m : ℝ) ^ u + (m : ℝ) ^ (rho_c c / 8) ≤ 2 * (n : ℝ) ^ (Q_c c σ) ∧
            (m : ℝ) ^ (1 + u) + (m : ℝ) ^ (rho_c c / 8) ≤ 2 * (m : ℝ) ^ (1 + σ))) ∧
    -- (4) Dynamic composition giving update time n^{Q_c(σ)} poly_{c,σ}(d, log(2nt/δ)) and
    -- space n^{1+σ} poly_{c,σ}(d, log(2nt/δ)) across the full explicit curve 0 ≤ σ ≤ ρ:
    (∀ (σ : ℝ), 0 ≤ σ → σ ≤ rho_c c →
      ∃ (polyTime polySpace : ℕ → ℕ → ℝ) (queryConst writeFactor : ℕ),
        IsBoundedByPoly2 polyTime ∧
        IsBoundedByPoly2 polySpace ∧
        ∀ (d n t : ℕ) (δ : ℝ),
          2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
            ∃ (prog : ArithRAMDynamicProgram) (initOut : ArithRAMExecOutcome),
              prog.evalInit n d = some initOut ∧
              let logTerm : ℕ := Nat.ceil (Real.log (2 * (n : ℝ) * (t : ℝ) / δ))
              let alg : DynamicDiameterStructure d ArithRAMMemory :=
                { initState := initOut.mem
                  initWork := initOut.unitCost
                  initSpace := initOut.peakCellSpace
                  cachedAnswer := fun mem =>
                    let ans := ArithRAMDynamicProgram.readCachedAnswer mem
                    { diameterHandles := ans.1, cachedDistSq := ans.2 }
                  retrieveIdsAndRefCost := 4
                  writeOutputCost := fun outLen => outLen + 1
                  stepWithBits := fun activeH hCoords mem uop bs =>
                    match uop with
                    | .insert pt =>
                        (prog.evalUpdate n activeH hCoords mem true pt 0 bs).map (fun stepOut =>
                          let ans := ArithRAMDynamicProgram.readCachedAnswer stepOut.mem
                          { nextState := stepOut.mem
                            returnedHandle := ArithRAMDynamicProgram.readReturnedHandle stepOut.mem
                            storedAnswer := { diameterHandles := ans.1, cachedDistSq := ans.2 }
                            work := stepOut.unitCost
                            peakSpace := stepOut.peakCellSpace })
                    | .delete h =>
                        (prog.evalUpdate n activeH hCoords mem false 0 h bs).map (fun stepOut =>
                          let ans := ArithRAMDynamicProgram.readCachedAnswer stepOut.mem
                          { nextState := stepOut.mem
                            returnedHandle := none
                            storedAnswer := { diameterHandles := ans.1, cachedDistSq := ans.2 }
                            work := stepOut.unitCost
                            peakSpace := stepOut.peakCellSpace }) }
              SatisfiesDynamicStorageAndQueryModel queryConst writeFactor alg ∧
              SatisfiesMonteCarloGuarantee n t δ c Set.univ alg ∧
              SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg
                (((n : ℝ) ^ (Q_c c σ)) * polyTime d logTerm) ∧
              SatisfiesBoundedSpaceBound n t Set.univ alg
                (((n : ℝ) ^ (1 + σ)) * polySpace d logTerm)) ∧
    -- (5) Putting σ = ρ proves Theorem 1.1; explicit curve endpoints:
    (0 < rho_c c ∧
      rho_c c < 1 ∧
      Q_c c (rho_c c) = rho_c c ∧
      Q_c c (rho_c c) = 2 / c ^ 2 - 1 ∧
      1 + rho_c c = 2 / c ^ 2 ∧
      Q_c c 0 = c ^ 2 * (2 - c ^ 2))

end UL
