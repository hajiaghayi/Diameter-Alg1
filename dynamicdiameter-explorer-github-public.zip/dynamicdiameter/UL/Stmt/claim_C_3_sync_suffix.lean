import Mathlib
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
import UL.Def.def_node_chain_blocks
set_option autoImplicit false

namespace UL

/-- Halting outcome of a fresh certified node constructor (certified center constructor together
with certified angular indices, or center constructor alone with `A_n = 1` when angular indices are
omitted) after retrying any unsuccessful constructions until core and index verification succeed. -/
structure SyncBuiltNode (d : ℕ) (NodeAux : Type) : Type where
  node : ChainNode d
  s : ℝ
  aux : NodeAux
  work : ℕ

/-- Record of an earlier node constructed within the same synchronous suffix rebuild, included in
the birth history seen by subsequent node constructors in that suffix. -/
structure SyncSuffixPrefixEntry (d : ℕ) (NodeAux : Type) : Type where
  birthPool : Finset ℕ
  coins : List Bool
  built : SyncBuiltNode d NodeAux

/-- Fresh history-conditioned certified node constructor: given the complete preceding external
execution history, the prefix of nodes already constructed in the current suffix, the append-only
coordinate map on insertion lifetimes, a birth pool `P₀` of active point lifetimes, and fresh
random bits, returns the verified chain node, auxiliary certified structures, and total work
(including all retries). -/
structure SyncCertifiedNodeConstructor (d : ℕ) (NodeAux : Type) : Type where
  buildWithBits :
    ExecutionHistory d → List (SyncSuffixPrefixEntry d NodeAux) →
      (ℕ → EuclideanSpace ℝ (Fin d)) → Finset ℕ → List Bool →
        Option (SyncBuiltNode d NodeAux)

/-- Conditional specification of a fresh certified node constructor at contraction rate `α`, leaf
threshold `L_leaf`, capacity `n`, admissible point domain `admissiblePts`, factor `A_n`, and
per-node overhead `P_node`: conditionally on the entire history `(hist, sufPref)` at birth, bit
consumption is prefix-free, construction halts with probability `1` (retrying unsuccessful attempts),
every accepted node has verified `α`-centerpoint core (`V = liftVariance o s`), and conditional
expected construction work on a birth pool `P₀` of `m = |P₀|` points is at most `m A_n P_node`. -/
def IsValidSyncNodeConstructor {d : ℕ} {NodeAux : Type}
    (n L_leaf : ℕ) (α A_n P_node : ℝ)
    (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (ctor : SyncCertifiedNodeConstructor d NodeAux) : Prop :=
  ∀ (hist : ExecutionHistory d)
    (sufPref : List (SyncSuffixPrefixEntry d NodeAux))
    (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (P₀ : Finset ℕ),
    L_leaf < P₀.card →
    P₀.card ≤ n →
    (∀ lt ∈ P₀, ltCoords lt ∈ admissiblePts) →
      (∀ bs₁ bs₂ : List Bool, ∀ out₁ out₂,
        ctor.buildWithBits hist sufPref ltCoords P₀ bs₁ = some out₁ →
        ctor.buildWithBits hist sufPref ltCoords P₀ bs₂ = some out₂ →
        bs₁ <+: bs₂ → bs₁ = bs₂) ∧
      (∑' bs : List Bool,
        if (ctor.buildWithBits hist sufPref ltCoords P₀ bs).isSome then bitListProb bs else 0) = 1 ∧
      (∀ bs : List Bool, ∀ out,
        ctor.buildWithBits hist sufPref ltCoords P₀ bs = some out →
          out.node.V = liftVariance out.node.o out.s ∧
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => ltCoords i.1))
            (liftedPoint out.node.o out.s)) ∧
      (let expWork : ENNReal :=
        ∑' bs : List Bool,
          match ctor.buildWithBits hist sufPref ltCoords P₀ bs with
          | some out => bitListProb bs * (out.work : ENNReal)
          | none => 0
       expWork ≠ ⊤ ∧ expWork.toReal ≤ (P₀.card : ℝ) * A_n * P_node)

/-- Halting outcome of synchronously constructing a whole contracting chain suffix on a birth set
`S` of `M = |S|` points down to terminal leaf size at most `L_leaf`. -/
structure SyncSuffixOutcome (d : ℕ) (NodeAux : Type) : Type where
  entries : List (SyncSuffixPrefixEntry d NodeAux)
  terminalLeaf : Finset ℕ
  totalWork : ℕ

/-- Fuel-bounded synchronous suffix constructor: repeatedly invokes `ctor` on the remaining residual
until its cardinality is at most `L_leaf`. -/
noncomputable def runSyncSuffixFuel {d : ℕ} {NodeAux : Type}
    (ctor : SyncCertifiedNodeConstructor d NodeAux) (L_leaf : ℕ)
    (hist : ExecutionHistory d) (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)) :
    ℕ → List (SyncSuffixPrefixEntry d NodeAux) → Finset ℕ → ℕ → List Bool →
      Option (SyncSuffixOutcome d NodeAux)
  | 0, acc, R, accWork, bs =>
      if R.card ≤ L_leaf ∧ bs.isEmpty then
        some { entries := acc, terminalLeaf := R, totalWork := accWork }
      else
        none
  | fuel + 1, acc, R, accWork, bs =>
      open Classical in
      if R.card ≤ L_leaf then
        if bs.isEmpty then
          some { entries := acc, terminalLeaf := R, totalWork := accWork }
        else
          none
      else
        if hStep : ∃ (bs₁ bs₂ : List Bool) (out : SyncBuiltNode d NodeAux),
            bs = bs₁ ++ bs₂ ∧ ctor.buildWithBits hist acc ltCoords R bs₁ = some out then
          let bs₁ := Classical.choose hStep
          let h₂ := Classical.choose_spec hStep
          let bs₂ := Classical.choose h₂
          let h₃ := Classical.choose_spec h₂
          let out := Classical.choose h₃
          let R' := out.node.residual ltCoords R
          let entry : SyncSuffixPrefixEntry d NodeAux :=
            { birthPool := R, coins := bs₁, built := out }
          runSyncSuffixFuel ctor L_leaf hist ltCoords fuel (acc ++ [entry]) R'
            (accWork + out.work) bs₂
        else
          none

/-- Synchronous reconstruction of a suffix born on `S` (`M = |S|` points) conditioned on preceding
execution history `hist`. -/
noncomputable def runSyncSuffixBuild {d : ℕ} {NodeAux : Type}
    (ctor : SyncCertifiedNodeConstructor d NodeAux) (L_leaf : ℕ)
    (hist : ExecutionHistory d) (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (S : Finset ℕ) (bs : List Bool) : Option (SyncSuffixOutcome d NodeAux) :=
  runSyncSuffixFuel ctor L_leaf hist ltCoords S.card [] S 0 bs

/-- Conditional probability (given `hist`) that synchronous reconstruction of a suffix born on `S`
halts over fresh random bits. -/
noncomputable def syncSuffixHaltProb {d : ℕ} {NodeAux : Type}
    (ctor : SyncCertifiedNodeConstructor d NodeAux) (L_leaf : ℕ)
    (hist : ExecutionHistory d) (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (S : Finset ℕ) : ENNReal :=
  ∑' bs : List Bool,
    if (runSyncSuffixBuild ctor L_leaf hist ltCoords S bs).isSome then bitListProb bs else 0

/-- Conditional expected work (given `hist`) of synchronously rebuilding a suffix born on `S`. -/
noncomputable def syncSuffixExpectedWork {d : ℕ} {NodeAux : Type}
    (ctor : SyncCertifiedNodeConstructor d NodeAux) (L_leaf : ℕ)
    (hist : ExecutionHistory d) (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (S : Finset ℕ) : ENNReal :=
  ∑' bs : List Bool,
    match runSyncSuffixBuild ctor L_leaf hist ltCoords S bs with
    | some out => bitListProb bs * (out.totalWork : ENNReal)
    | none => 0

/-- Active internal node on the synchronously maintained chain, tracking its birth pool of active
insertion lifetimes and the set of external update step indices since its birth that changed its
input set (its age counter is `ageUpdateSteps.card`). -/
structure SyncLiveChainNode (d : ℕ) (NodeAux : Type) : Type where
  built : SyncBuiltNode d NodeAux
  birthPool : Finset ℕ
  ageUpdateSteps : Finset ℕ

/-- Explicit charging and birth-cardinality record for a triggered synchronous suffix rebuild:
charges the whole triggered suffix (born on `rootBirthCard = M` points, with contracting chain node
sizes `chainBirthCards`) to the old root's age-counter updates since its birth (`chargedUpdateSteps`),
while `canceledDescendants` deeper nodes on the replaced suffix are canceled early with zero
separate charge. -/
structure SyncTriggeredSuffixRecord : Type where
  triggerStep : ℕ
  triggerDepth : ℕ
  canceledDescendants : ℕ
  rootBirthCard : ℕ
  chainBirthCards : List ℕ
  chargedUpdateSteps : Finset ℕ
  rebuildWork : ℕ

/-- Checked answer and reusable-handle policy accompanying the synchronous chain schedule ("all
answers are checked"). -/
structure SyncCheckedAnswerPolicy (d : ℕ) (NodeAux : Type) : Type where
  allocHandle : Finset ℕ → ℕ
  checkedAnswer : DynamicPointSet d → List (SyncLiveChainNode d NodeAux) → StoredDiameterAnswer

/-- Validity of `ansPol`: allocates a fresh internal handle on insertion and outputs a verified
factor-`c` diameter answer on every well-formed point set. -/
def IsValidSyncCheckedAnswerPolicy {d : ℕ} {NodeAux : Type}
    (n : ℕ) (c : ℝ) (ansPol : SyncCheckedAnswerPolicy d NodeAux) : Prop :=
  (∀ activeH : Finset ℕ, ansPol.allocHandle activeH ∉ activeH) ∧
  (∀ (P : DynamicPointSet d) (nodes : List (SyncLiveChainNode d NodeAux)),
    P.WellFormed n → IsValidFactorCAnswer c P (ansPol.checkedAnswer P nodes))

/-- Accumulated execution state of the synchronous suffix-reconstruction schedule starting from the
empty set `P = ∅`. -/
structure SyncSchedulePrefixState (d : ℕ) (NodeAux : Type) : Type where
  pointSet : DynamicPointSet d
  ltCoords : ℕ → EuclideanSpace ℝ (Fin d)
  nodes : List (SyncLiveChainNode d NodeAux)
  leafBirthPool : Finset ℕ
  leafAgeUpdateSteps : Finset ℕ
  history : ExecutionHistory d
  snapshots : List (DynamicPointSet d × StoredDiameterAnswer)
  triggeredSuffixes : List SyncTriggeredSuffixRecord
  chainSlotCounts : List ℕ
  totalRebuildWork : ℕ

/-- Initial empty synchronous schedule state prior to the first external update (`P = ∅`). -/
noncomputable def initSyncSchedulePrefixState (d : ℕ) (NodeAux : Type) :
    SyncSchedulePrefixState d NodeAux :=
  { pointSet := DynamicPointSet.empty d
    ltCoords := fun _ => 0
    nodes := []
    leafBirthPool := ∅
    leafAgeUpdateSteps := ∅
    history := []
    snapshots := []
    triggeredSuffixes := []
    chainSlotCounts := []
    totalRebuildWork := 0 }

/-- Execute one external update under synchronous suffix reconstruction at the constant-fraction age
threshold (`age > α |P₀| / 16` on internal nodes, corresponding to `clm_5_1_chain_contraction` and
`claim_A_2_deletion_witness`, and `|S_k| > 2 L_leaf` at the terminal leaf): updates age counters on
the then-current chain, triggers at the shallowest exceeded slot (canceling deeper descendants
without separate charge), and synchronously rebuilds that suffix. -/
noncomputable def runSingleSyncScheduleStep {d : ℕ} {NodeAux : Type}
    (L_leaf : ℕ) (α : ℝ)
    (ctor : SyncCertifiedNodeConstructor d NodeAux)
    (ansPol : SyncCheckedAnswerPolicy d NodeAux)
    (cur : SyncSchedulePrefixState d NodeAux)
    (op : DynamicUpdate d) (bs : List Bool) :
    Option (SyncSchedulePrefixState d NodeAux) :=
  open Classical in
  let u : ℕ := cur.history.length
  let retHandle : Option ℕ :=
    match op with
    | .insert _ _ _ => some (ansPol.allocHandle cur.pointSet.activeHandles)
    | .delete _ => none
  match applyDynamicUpdate cur.pointSet op retHandle with
  | none => none
  | some P' =>
      let ltCoords' : ℕ → EuclideanSpace ℝ (Fin d) :=
        match op with
        | .insert _ _ pt => Function.update cur.ltCoords cur.pointSet.nextLifetime pt
        | .delete _ => cur.ltCoords
      let k : ℕ := cur.nodes.length
      let vecNodes : Fin k → ChainNode d := fun i => (cur.nodes.get i).built.node
      let oldAct : Finset ℕ := cur.pointSet.activeIds.image cur.pointSet.lifetimeOfId
      let newAct : Finset ℕ := P'.activeIds.image P'.lifetimeOfId
      let S_old : Fin (k + 1) → Finset ℕ := chainInput ltCoords' vecNodes oldAct
      let S_new : Fin (k + 1) → Finset ℕ := chainInput ltCoords' vecNodes newAct
      let updatedNodes : List (SyncLiveChainNode d NodeAux) :=
        List.ofFn (fun i : Fin k =>
          let v := cur.nodes.get i
          let age' := if S_new i.castSucc ≠ S_old i.castSucc then insert u v.ageUpdateSteps else v.ageUpdateSteps
          { v with ageUpdateSteps := age' })
      let leafAge' : Finset ℕ :=
        if S_new (Fin.last k) ≠ S_old (Fin.last k) then
          insert u cur.leafAgeUpdateSteps
        else
          cur.leafAgeUpdateSteps
      let slotTriggers : ℕ → Prop := fun j =>
        if hj : j < k then
          let vOld := cur.nodes.get ⟨j, hj⟩
          let ageCard :=
            (if S_new ⟨j, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨j, Nat.lt_succ_of_lt hj⟩ then
              insert u vOld.ageUpdateSteps
            else
              vOld.ageUpdateSteps).card
          α * (vOld.birthPool.card : ℝ) / 16 < (ageCard : ℝ)
        else
          j = k ∧ 2 * L_leaf < (S_new (Fin.last k)).card
      if hTrig : ∃ j : ℕ, j ≤ k ∧ slotTriggers j then
        let jStar : ℕ := Nat.find hTrig
        have hjLe : jStar ≤ k := (Nat.find_spec hTrig).1
        let jFin : Fin (k + 1) := ⟨jStar, Nat.lt_succ_of_le hjLe⟩
        let S_trig : Finset ℕ := S_new jFin
        let charged : Finset ℕ :=
          if hj : jStar < k then
            let vOld := cur.nodes.get ⟨jStar, hj⟩
            if S_new ⟨jStar, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨jStar, Nat.lt_succ_of_lt hj⟩ then
              insert u vOld.ageUpdateSteps
            else
              vOld.ageUpdateSteps
          else
            leafAge'
        match runSyncSuffixBuild ctor L_leaf cur.history ltCoords' S_trig bs with
        | none => none
        | some sufOut =>
            let newSuffixNodes : List (SyncLiveChainNode d NodeAux) :=
              sufOut.entries.map (fun e =>
                { built := e.built, birthPool := e.birthPool, ageUpdateSteps := ∅ })
            let finalNodes := updatedNodes.take jStar ++ newSuffixNodes
            let ans := ansPol.checkedAnswer P' finalNodes
            let entry : StepHistoryEntry d :=
              { operation := op
                randomBits := bs
                returnedHandle := retHandle
                answer := ans
                resolvedIds := resolveAnswerIdentities P' ans }
            let recEntry : SyncTriggeredSuffixRecord :=
              { triggerStep := u
                triggerDepth := jStar
                canceledDescendants := k - jStar
                rootBirthCard := S_trig.card
                chainBirthCards := sufOut.entries.map (fun e => e.birthPool.card)
                chargedUpdateSteps := charged
                rebuildWork := sufOut.totalWork }
            some
              { pointSet := P'
                ltCoords := ltCoords'
                nodes := finalNodes
                leafBirthPool := sufOut.terminalLeaf
                leafAgeUpdateSteps := ∅
                history := cur.history ++ [entry]
                snapshots := cur.snapshots ++ [(P', ans)]
                triggeredSuffixes := cur.triggeredSuffixes ++ [recEntry]
                chainSlotCounts := cur.chainSlotCounts ++ [k + 1]
                totalRebuildWork := cur.totalRebuildWork + sufOut.totalWork }
      else
        if bs.isEmpty then
          let ans := ansPol.checkedAnswer P' updatedNodes
          let entry : StepHistoryEntry d :=
            { operation := op
              randomBits := []
              returnedHandle := retHandle
              answer := ans
              resolvedIds := resolveAnswerIdentities P' ans }
          some
            { pointSet := P'
              ltCoords := ltCoords'
              nodes := updatedNodes
              leafBirthPool := cur.leafBirthPool
              leafAgeUpdateSteps := leafAge'
              history := cur.history ++ [entry]
              snapshots := cur.snapshots ++ [(P', ans)]
              triggeredSuffixes := cur.triggeredSuffixes
              chainSlotCounts := cur.chainSlotCounts ++ [k + 1]
              totalRebuildWork := cur.totalRebuildWork }
        else
          none

/-- Continue a synchronous suffix-reconstruction adaptive execution across a list of per-step fresh
random bit lists. -/
noncomputable def runSyncScheduleStepsFrom {d : ℕ} {NodeAux : Type}
    (L_leaf : ℕ) (α : ℝ)
    (ctor : SyncCertifiedNodeConstructor d NodeAux)
    (ansPol : SyncCheckedAnswerPolicy d NodeAux)
    (adv : AdaptiveAdversary d)
    (cur : SyncSchedulePrefixState d NodeAux) :
    List (List Bool) → Option (SyncSchedulePrefixState d NodeAux)
  | [] => some cur
  | bs :: tail =>
      match runSingleSyncScheduleStep L_leaf α ctor ansPol cur (adv cur.history) bs with
      | none => none
      | some next => runSyncScheduleStepsFrom L_leaf α ctor ansPol adv next tail

/-- Run a synchronous suffix-reconstruction adaptive execution starting from `P = ∅` over
`bitTrace`. -/
noncomputable def runSyncScheduleSteps {d : ℕ} {NodeAux : Type}
    (L_leaf : ℕ) (α : ℝ)
    (ctor : SyncCertifiedNodeConstructor d NodeAux)
    (ansPol : SyncCheckedAnswerPolicy d NodeAux)
    (adv : AdaptiveAdversary d)
    (bitTrace : List (List Bool)) : Option (SyncSchedulePrefixState d NodeAux) :=
  runSyncScheduleStepsFrom L_leaf α ctor ansPol adv (initSyncSchedulePrefixState d NodeAux) bitTrace

/-- Run a fixed finite prefix of `t` adaptive updates under synchronous suffix reconstruction. -/
noncomputable def runSyncSchedulePrefix {d : ℕ} {NodeAux : Type}
    (L_leaf : ℕ) (α : ℝ)
    (ctor : SyncCertifiedNodeConstructor d NodeAux)
    (ansPol : SyncCheckedAnswerPolicy d NodeAux)
    (adv : AdaptiveAdversary d) (t : ℕ)
    (trace : Fin t → List Bool) : Option (SyncSchedulePrefixState d NodeAux) :=
  runSyncScheduleSteps L_leaf α ctor ansPol adv (List.ofFn trace)

/-- Legality of an adaptive adversary against the synchronous suffix-reconstruction schedule under
capacity `n` and admissible coordinate domain `admissiblePts`. -/
def IsValidSyncAdaptiveAdversary {d : ℕ} {NodeAux : Type}
    (n L_leaf : ℕ) (α : ℝ)
    (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (ctor : SyncCertifiedNodeConstructor d NodeAux)
    (ansPol : SyncCheckedAnswerPolicy d NodeAux)
    (adv : AdaptiveAdversary d) : Prop :=
  ∀ bitTrace : List (List Bool), ∀ prefSt : SyncSchedulePrefixState d NodeAux,
    runSyncScheduleSteps L_leaf α ctor ansPol adv bitTrace = some prefSt →
      IsLegalUpdate n admissiblePts prefSt.pointSet (adv prefSt.history)

/-- Halting probability of a single synchronous update step from `cur` under fresh random bits. -/
noncomputable def syncSingleStepHaltProb {d : ℕ} {NodeAux : Type}
    (L_leaf : ℕ) (α : ℝ)
    (ctor : SyncCertifiedNodeConstructor d NodeAux)
    (ansPol : SyncCheckedAnswerPolicy d NodeAux)
    (cur : SyncSchedulePrefixState d NodeAux)
    (op : DynamicUpdate d) : ENNReal :=
  ∑' bs : List Bool,
    if (runSingleSyncScheduleStep L_leaf α ctor ansPol cur op bs).isSome then bitListProb bs else 0

/-- Expected total suffix-reconstruction work across a fixed finite prefix of `t` adaptive external
updates starting from `P = ∅`. -/
noncomputable def syncPrefixExpectedRebuildWork {d : ℕ} {NodeAux : Type}
    (L_leaf : ℕ) (α : ℝ)
    (ctor : SyncCertifiedNodeConstructor d NodeAux)
    (ansPol : SyncCheckedAnswerPolicy d NodeAux)
    (adv : AdaptiveAdversary d) (t : ℕ) : ENNReal :=
  ∑' trace : Fin t → List Bool,
    match runSyncSchedulePrefix L_leaf α ctor ansPol adv t trace with
    | some out => prefixTraceProb trace * (out.totalRebuildWork : ENNReal)
    | none => 0

/-- Claim (Sec. C.3: Synchronous suffix reconstruction and amortized birth cardinality) (paper p.54).
Exactly the paper's statement, as a Prop. -/
def S_claim_C_3_sync_suffix : Prop :=
  ∀ (P_α : ℕ → ℝ) (P_node : ℕ → ℕ → ℕ → ℝ)
    (hP_α : IsBoundedByPoly1 P_α)
    (hP_α_ge_one : ∀ d : ℕ, 1 ≤ P_α d)
    (hP_node : IsBoundedByPoly3 P_node)
    (hP_node_nonneg : ∀ d B L : ℕ, 0 ≤ P_node d B L),
    ∃ (c_chg C_sum C_charge : ℝ)
      (P_suf : ℕ → ℕ → ℕ → ℝ)
      (B_card : ℕ → ℕ → ℝ)
      (P_tot : ℕ → ℕ → ℕ → ℝ),
      0 < c_chg ∧ 0 < C_sum ∧ 0 < C_charge ∧
      IsBoundedByPoly3 P_suf ∧ (∀ d B L : ℕ, 0 ≤ P_suf d B L) ∧
      IsBoundedByPoly2 B_card ∧ (∀ d L : ℕ, 0 ≤ B_card d L) ∧
      IsBoundedByPoly3 P_tot ∧ (∀ d B L : ℕ, 0 ≤ P_tot d B L) ∧
      ∀ (d B n L_leaf : ℕ) (NodeAux : Type)
        (α c A_n : ℝ)
        (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
        (ctor : SyncCertifiedNodeConstructor d NodeAux)
        (ansPol : SyncCheckedAnswerPolicy d NodeAux),
        1 ≤ B → 2 ≤ n →
        0 < α → α ≤ 1 → 1 / P_α d ≤ α →
        1 ≤ c → 0 ≤ A_n →
        let L : ℕ := Nat.clog 2 (2 * n)
        IsValidSyncNodeConstructor n L_leaf α A_n (P_node d B L) admissiblePts ctor →
        IsValidSyncCheckedAnswerPolicy n c ansPol →
          -- (1) Conditional suffix reconstruction guarantees on any birth set S of M = |S| ≤ n points:
          -- prefix-free, halts with probability 1, contracting chain size sum is O(M / α), and
          -- conditional expected rebuild work given birth history `hist` is at most M A(n) P_suf
          (∀ (hist : ExecutionHistory d) (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)) (S : Finset ℕ),
            S.card ≤ n →
            (∀ lt ∈ S, ltCoords lt ∈ admissiblePts) →
              (∀ bs₁ bs₂ : List Bool, ∀ out₁ out₂,
                runSyncSuffixBuild ctor L_leaf hist ltCoords S bs₁ = some out₁ →
                runSyncSuffixBuild ctor L_leaf hist ltCoords S bs₂ = some out₂ →
                bs₁ <+: bs₂ → bs₁ = bs₂) ∧
              syncSuffixHaltProb ctor L_leaf hist ltCoords S = 1 ∧
              (∀ bs : List Bool, ∀ sufOut,
                runSyncSuffixBuild ctor L_leaf hist ltCoords S bs = some sufOut →
                  sufOut.terminalLeaf.card ≤ L_leaf ∧
                  ((sufOut.entries.map (fun e => (e.birthPool.card : ℝ))).sum) ≤
                    C_sum * ((S.card : ℝ) / α)) ∧
              syncSuffixExpectedWork ctor L_leaf hist ltCoords S ≠ ⊤ ∧
              (syncSuffixExpectedWork ctor L_leaf hist ltCoords S).toReal ≤
                (S.card : ℝ) * A_n * P_suf d B L) ∧
          -- (2) Adaptive dynamic execution starting from P = ∅: almost-sure step termination,
          -- checked valid answers, explicit charging to old root's Ω(α M) age-counter updates,
          -- at most O(α⁻¹ log n) charges per past external update (solely from its then-current
          -- chain, with zero separate charge for early-canceled descendants), total birth
          -- cardinality ≤ t poly(d, log n), and expected total rebuild work ≤ t A(n) P_tot
          -- over every fixed finite prefix of t ≥ 1 adaptive updates
          (∀ adv : AdaptiveAdversary d,
            IsValidSyncAdaptiveAdversary n L_leaf α admissiblePts ctor ansPol adv →
              (∀ bitTrace : List (List Bool), ∀ prefSt : SyncSchedulePrefixState d NodeAux,
                runSyncScheduleSteps L_leaf α ctor ansPol adv bitTrace = some prefSt →
                  syncSingleStepHaltProb L_leaf α ctor ansPol prefSt (adv prefSt.history) = 1) ∧
              (∀ (t : ℕ), 1 ≤ t →
                (∀ (trace : Fin t → List Bool) (out : SyncSchedulePrefixState d NodeAux),
                  runSyncSchedulePrefix L_leaf α ctor ansPol adv t trace = some out →
                    (∀ snap ∈ out.snapshots, IsValidFactorCAnswer c snap.1 snap.2) ∧
                    -- Every triggered suffix born on M points has Ω(α M) preceding age-counter
                    -- updates of its old root since birth and O(M / α) contracting chain size sum
                    (∀ rec ∈ out.triggeredSuffixes,
                      c_chg * α * (rec.rootBirthCard : ℝ) ≤ (rec.chargedUpdateSteps.card : ℝ) ∧
                      (rec.chainBirthCards.map (fun m => (m : ℝ))).sum ≤
                        C_sum * ((rec.rootBirthCard : ℝ) / α) ∧
                      ∀ u₀ ∈ rec.chargedUpdateSteps, u₀ ≤ rec.triggerStep ∧ u₀ < t) ∧
                    -- Each past external update u₀ < t is charged only via slots on step u₀'s
                    -- then-current chain, at most O(α⁻¹ log n) times
                    (∀ u₀ : ℕ, u₀ < t →
                      (out.triggeredSuffixes.filter (fun rec => u₀ ∈ rec.chargedUpdateSteps)).length ≤
                        out.chainSlotCounts.getD u₀ 0 ∧
                      (out.chainSlotCounts.getD u₀ 0 : ℝ) ≤
                        C_charge * α⁻¹ * Real.log (2 * (n : ℝ))) ∧
                    -- Total birth cardinality (both suffix roots ∑ M and all born chain nodes ∑∑ m)
                    -- over t updates is bounded by t poly(d, log(2n))
                    ((out.triggeredSuffixes.map (fun rec => (rec.rootBirthCard : ℝ))).sum ≤
                      (t : ℝ) * B_card d L) ∧
                    ((out.triggeredSuffixes.map (fun rec =>
                      (rec.chainBirthCards.map (fun m => (m : ℝ))).sum)).sum ≤
                      (t : ℝ) * B_card d L)) ∧
                syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv t ≠ ⊤ ∧
                (syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv t).toReal ≤
                  (t : ℝ) * A_n * P_tot d B L))

end UL
