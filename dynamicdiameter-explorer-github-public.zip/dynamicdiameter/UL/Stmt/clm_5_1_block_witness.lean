import Mathlib
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_node_chain_blocks
import UL.Def.def_node_baseline
set_option autoImplicit false

namespace UL

open Classical in
/-- Claim (Sec. 5.1: Zero-error block certificate variance identity and witness) (paper p.17). Exactly the paper's statement, as a Prop. -/
def S_clm_5_1_block_witness : Prop :=
  ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ι)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (β : ℝ) (r₀ : ℕ)
    (certs : Fin r₀ → BlockCertificate pts P₀ (liftedPoint o s))
    (hβm : 0 < β * (P₀.card : ℝ))
    (hr₀ : β * (P₀.card : ℝ) ≤ (r₀ : ℝ))
    (hdisj : Pairwise (fun j₁ j₂ : Fin r₀ => Disjoint (certs j₁).B (certs j₂).B)),
    let V := liftVariance o s
    (∀ (S : Finset ι) (j : Fin r₀),
      (certs j).IsIntact S →
      (∀ q : EuclideanSpace ℝ (Fin d),
        ∑ p ∈ (certs j).B, (certs j).coeff p * ‖pts p - q‖ ^ 2 = ‖q - o‖ ^ 2 + V) ∧
      (∀ q : EuclideanSpace ℝ (Fin d),
        ∃ p ∈ (certs j).B,
          p ∈ S ∧
          ‖pts p - q‖ ^ 2 ≥ ∑ p' ∈ (certs j).B, (certs j).coeff p' * ‖pts p' - q‖ ^ 2 ∧
          IsVarianceWitness o V q (pts p)) ∧
      (∀ y : ι,
        IsNodeMaxRadiusPoint pts o S y →
        ∃ p ∈ (certs j).B, IsNodeBaselinePair pts o V S y p)) ∧
    (∀ (S : Finset ι) (x : ι),
      (Finset.univ.filter (fun j : Fin r₀ =>
        (certs j).IsIntact S ∧ ¬ (certs j).IsIntact (S.erase x))).card ≤ 1) ∧
    (∀ (ops : List (ι ⊕ ι)),
      ((ops.filter Sum.isRight).length : ℝ) ≤ β * (P₀.card : ℝ) / 16 →
      let S := ops.foldl (fun acc op =>
        match op with
        | Sum.inl i => insert i acc
        | Sum.inr i => acc.erase i) P₀
      ((ops.filter Sum.isRight).length : ℝ) < (r₀ : ℝ) ∧
      ∃ j : Fin r₀, (certs j).IsIntact S)

end UL
