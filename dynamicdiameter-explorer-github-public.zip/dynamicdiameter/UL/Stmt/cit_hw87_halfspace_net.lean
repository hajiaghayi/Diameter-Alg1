import Mathlib
import UL.Def.def_A_halfspace_net
set_option autoImplicit false

namespace UL

open Classical in
/-- Haussler–Welzl Halfspace-Net Theorem [HW87] (paper p.45). Exactly the paper's statement, as a Prop. -/
def S_cit_hw87_halfspace_net : Prop :=
  ∃ C_HW : ℝ, 0 < C_HW ∧
    ∀ (D : ℕ), 1 ≤ D →
    ∀ (ι : Type) [Fintype ι] [Nonempty ι] (P : ι → EuclideanSpace ℝ (Fin D)),
    ∀ (α : ℝ), 0 < α → α ≤ 1 →
    ∀ (δ : ℝ), 0 < δ → δ < 1 →
    ∀ (s : ℕ),
      Nat.ceil (C_HW * α⁻¹ * (((D : ℝ) + 1) * Real.log (2 / α) + Real.log (2 / δ))) ≤ s →
      (1 - δ ≤ ((Finset.univ.filter (fun sample : Fin s → ι =>
          IsIndexedHalfspaceNet α P sample)).card : ℝ) /
        (Fintype.card (Fin s → ι) : ℝ)) ∧
      (s ≤ Fintype.card ι →
        1 - δ ≤ ((((Finset.univ : Finset ι).powersetCard s).filter (fun S : Finset ι =>
            IsHalfspaceNet α P S)).card : ℝ) /
          (((Finset.univ : Finset ι).powersetCard s).card : ℝ))

end UL
