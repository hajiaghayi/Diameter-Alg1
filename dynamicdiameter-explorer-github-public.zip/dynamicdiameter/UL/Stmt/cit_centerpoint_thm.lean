import Mathlib
import UL.Def.def_halfspace_depth
import UL.Def.def_A_halfspace_net
set_option autoImplicit false

namespace UL

/-- Centerpoint Theorem (paper p.45). Exactly the paper's statement, as a Prop. -/
def S_cit_centerpoint_thm : Prop :=
  ∀ (D : ℕ) (hD : 1 ≤ D) (ι : Type) [Fintype ι] [Nonempty ι]
    (P : ι → EuclideanSpace ℝ (Fin D)),
    ∃ z_star : EuclideanSpace ℝ (Fin D),
      (Fintype.card ι : ℝ) / ((D : ℝ) + 1) ≤ (halfspaceDepth P z_star : ℝ) ∧
      ∀ S : Finset ι,
        IsHalfspaceNet (1 / ((D : ℝ) + 1)) P S →
        z_star ∈ convexHull ℝ (P '' (S : Set ι))

end UL
