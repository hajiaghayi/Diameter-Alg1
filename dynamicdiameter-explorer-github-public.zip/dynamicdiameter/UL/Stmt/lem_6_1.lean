import Mathlib
import UL.Def.def_6_search_exponents
set_option autoImplicit false

namespace UL

/-- Lemma 6.1 (paper p.21). Exactly the paper's statement, as a Prop. -/
def S_lem_6_1 : Prop :=
  ∀ (h : ℝ), 0 < h → h < 1 →
    u_search h h = 0 ∧
    u_search h 1 = rho_h h ∧
    Set.image (u_search h) (Set.Icc h 1) = Set.Icc 0 (rho_h h) ∧
    ∀ (x : ℝ), h ≤ x → x ≤ 1 →
      q_search h x = q_h h (u_search h x) ∧
      q_search h x - u_search h x = 1 - x ^ 2 ∧
      1 - x ^ 2 ≥ 0

end UL
