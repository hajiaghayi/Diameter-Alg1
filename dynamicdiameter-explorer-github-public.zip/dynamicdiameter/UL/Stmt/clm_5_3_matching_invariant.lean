import Mathlib
import UL.Def.def_shells_configurations
import UL.Def.def_local_matching
set_option autoImplicit false

namespace UL

open Classical in
/-- Claim (Sec. 5.3: Local matching invariant preservation) (paper p.19). Exactly the paper's statement, as a Prop. -/
def S_clm_5_3_matching_invariant : Prop :=
  ∀ (d : ℕ) (ι : Type)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d))
    (V : ℝ)
    (e γ lam : ℚ)
    (K : ℤ)
    (j k ℓ : ℕ)
    (hV : 0 < V)
    (he : 0 < e)
    (hγ : 1 < γ)
    (hlam : 1 < lam)
    (hcfg : IsRetainedConfig e γ lam K V j k ℓ),
    let m0 := shellSubdiv e
    let a := configThresholdA m0 γ lam V j k ℓ
    let b := configThresholdB m0 lam V j k ℓ
    (∀ p : ι,
      ‖inwardRound m0 o V (pts p) - inwardRound m0 o V (pts p)‖ = 0 ∧
      ¬ IsWeakRoundedPair m0 lam o V ℓ (pts p) (pts p) ∧
      ¬ attachAcceptsCorrelation o (pts p) (pts p) b) ∧
    (∀ (S : Finset ι) (V_L V_R : Finset ι)
       (st : LocalMatchingState ι) (v : CopyVertex ι) (st' : LocalMatchingState ι),
      V_L ⊆ configLeftVertices pts m0 o V S j →
      V_R ⊆ configRightVertices pts m0 o V K S k →
      let V_L₀ := if v.side = .left then V_L.erase v.id else V_L
      let V_R₀ := if v.side = .right then V_R.erase v.id else V_R
      st.SatisfiesInvariant pts V_L₀ V_R₀
        (weakEdgesOn pts m0 lam o V ℓ V_L₀ V_R₀)
        (strongEdgesOn pts m0 γ lam o V ℓ V_L₀ V_R₀) →
      ValidAttachAngularStep pts o a b V_L V_R st v st' →
      st'.SatisfiesInvariant pts V_L V_R
        (weakEdgesOn pts m0 lam o V ℓ V_L V_R)
        (strongEdgesOn pts m0 γ lam o V ℓ V_L V_R)) ∧
    (∀ (S : Finset ι) (p : ι) (st st' : LocalMatchingState ι),
      p ∉ S →
      st.SatisfiesInvariant pts
        (configLeftVertices pts m0 o V S j)
        (configRightVertices pts m0 o V K S k)
        (configWeakEdges pts m0 lam o V K S j k ℓ)
        (configStrongEdges pts m0 γ lam o V K S j k ℓ) →
      ValidInsertOriginalAngularStep pts o a b
        (configLeftVertices pts m0 o V (insert p S) j)
        (configRightVertices pts m0 o V K (insert p S) k)
        st p st' →
      st'.SatisfiesInvariant pts
        (configLeftVertices pts m0 o V (insert p S) j)
        (configRightVertices pts m0 o V K (insert p S) k)
        (configWeakEdges pts m0 lam o V K (insert p S) j k ℓ)
        (configStrongEdges pts m0 γ lam o V K (insert p S) j k ℓ)) ∧
    (∀ (S : Finset ι) (p : ι) (st : LocalMatchingState ι),
      p ∈ S →
      st.SatisfiesInvariant pts
        (configLeftVertices pts m0 o V S j)
        (configRightVertices pts m0 o V K S k)
        (configWeakEdges pts m0 lam o V K S j k ℓ)
        (configStrongEdges pts m0 γ lam o V K S j k ℓ) →
      (survivingFormerPartnerSet st p).card ≤ 2 ∧
      (survivingFormerPartners st p).length ≤ 2 ∧
      (survivingFormerPartnerSet st p = ∅ →
        (removeCopiesFromState st p).SatisfiesInvariant pts
          (configLeftVertices pts m0 o V (S.erase p) j)
          (configRightVertices pts m0 o V K (S.erase p) k)
          (configWeakEdges pts m0 lam o V K (S.erase p) j k ℓ)
          (configStrongEdges pts m0 γ lam o V K (S.erase p) j k ℓ)) ∧
      (∀ st' : LocalMatchingState ι,
        ValidDeleteOriginalAngularStep pts o a b
          (configLeftVertices pts m0 o V (S.erase p) j)
          (configRightVertices pts m0 o V K (S.erase p) k)
          st p st' →
        st'.SatisfiesInvariant pts
          (configLeftVertices pts m0 o V (S.erase p) j)
          (configRightVertices pts m0 o V K (S.erase p) k)
          (configWeakEdges pts m0 lam o V K (S.erase p) j k ℓ)
          (configStrongEdges pts m0 γ lam o V K (S.erase p) j k ℓ))) ∧
    (∀ (S : Finset ι) (M : Finset (ι × ι)),
      SatisfiesConfigMatchingInvariant pts m0 γ lam o V K S j k ℓ M →
      (M = ∅ → configStrongEdges pts m0 γ lam o V K S j k ℓ = ∅) ∧
      ((configStrongEdges pts m0 γ lam o V K S j k ℓ).Nonempty → M.Nonempty) ∧
      (M.Nonempty → ∃ x y : ι, (x, y) ∈ M ∧
        (x, y) ∈ configWeakEdges pts m0 lam o V K S j k ℓ ∧
        x ∈ S ∧ y ∈ S ∧ x ≠ y) ∧
      (∀ e_pair ∈ M,
        e_pair ∈ configWeakEdges pts m0 lam o V K S j k ℓ ∧
        e_pair.1 ∈ S ∧ e_pair.2 ∈ S ∧ e_pair.1 ≠ e_pair.2))

end UL
